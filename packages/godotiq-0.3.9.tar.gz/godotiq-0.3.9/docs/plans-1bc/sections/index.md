<!-- PROJECT_CONFIG
runtime: python-pip
test_command: pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-value-parser-raw
section-02-test-fixtures
section-03-scene-resolver-core
section-04-world-transforms
section-05-project-index
section-06-tests
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-value-parser-raw | - | 03, 04 | Yes |
| section-02-test-fixtures | - | 03, 05, 06 | Yes |
| section-03-scene-resolver-core | 01, 02 | 04, 06 | No |
| section-04-world-transforms | 01, 03 | 06 | No |
| section-05-project-index | 02 | 06 | Yes (with 03) |
| section-06-tests | 03, 04, 05 | - | No |

## Execution Order

1. section-01-value-parser-raw, section-02-test-fixtures (parallel, no dependencies)
2. section-03-scene-resolver-core, section-05-project-index (parallel after 01+02)
3. section-04-world-transforms (after 03)
4. section-06-tests (after all)

## Section Summaries

### section-01-value-parser-raw
Add `"raw"` key to `decompose_transform3d()` return dict in `value_parser.py`. This stores the original 12-float tuple alongside the decomposed position/rotation/scale, enabling the scene resolver to reconstruct basis matrices without Euler round-tripping. Update existing test to verify the `raw` key presence.

### section-02-test-fixtures
Create the `tests/fixtures/sample_project/` directory structure with all fixture files: minimal `project.godot`, minimal `main.tscn` (instancing fdm_printer), minimal `fdm_printer.tscn` (with script/model refs and child nodes), empty `.gd` and `.glb` files. Add conftest fixtures for `sample_project_root`.

### section-03-scene-resolver-core
Implement `src/godotiq/parsers/scene_resolver.py` with:
- `ResolvedScene` and `WorldNode` dataclasses
- `resolve_scene()` function with recursive instance resolution
- `_resolve_res_path()` helper
- `_clone_node()` for efficient node copying
- Property override application
- Instance type copying
- Cycle detection and depth limiting
- Parse caching during resolution

### section-04-world-transforms
Add to `scene_resolver.py`:
- `calculate_world_transforms()` with basis matrix composition
- Internal transform representation (column-major 3x3 + origin)
- Basis multiplication and point transformation
- Euler angle reconstruction from composed world basis
- `find_nodes_by_type()`, `find_nodes_by_group()`, `find_nodes_in_radius()` query functions

### section-05-project-index
Implement `src/godotiq/parsers/project_index.py` with:
- `ProjectIndex` dataclass
- `scan_project()` with filesystem walking and .tscn parsing
- `_parse_project_godot()` for autoload/project name extraction
- Cross-reference map construction (scene_instances, script_to_scenes, resource_usage)
- `rescan_changed()` for incremental updates
- `find_asset_usage()`, `find_unused_assets()`, `get_scene_dependency_chain()` queries
- FileCache integration

### section-06-tests
Comprehensive test suite:
- `test_scene_resolver.py` — instance resolution, property overrides, depth limits, unresolved handling, world transforms, spatial queries
- `test_project_index.py` — project scanning, cross-references, autoloads, unused assets, incremental rescan, directory skipping
- Additional test for `test_value_parser.py` — verify `raw` key in decompose output
