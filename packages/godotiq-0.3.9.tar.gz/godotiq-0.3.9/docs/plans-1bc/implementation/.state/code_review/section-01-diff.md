diff --git a/src/godotiq/parsers/value_parser.py b/src/godotiq/parsers/value_parser.py
index dfba67e..f574e5a 100644
--- a/src/godotiq/parsers/value_parser.py
+++ b/src/godotiq/parsers/value_parser.py
@@ -254,7 +254,7 @@ def decompose_transform3d(
 
     rotation = (x, y, z)
 
-    return {"position": position, "rotation": rotation, "scale": scale}
+    return {"position": position, "rotation": rotation, "scale": scale, "raw": values}
 
 
 def _parse_array(s: str) -> list[object]:
diff --git a/tests/test_parsers/test_value_parser.py b/tests/test_parsers/test_value_parser.py
index c64e321..2e8dde6 100644
--- a/tests/test_parsers/test_value_parser.py
+++ b/tests/test_parsers/test_value_parser.py
@@ -168,6 +168,20 @@ class TestTransform3DDecomposition:
         result = decompose_transform3d(values)
         assert result["scale"][0] < 0
 
+    def test_decompose_transform3d_has_raw(self) -> None:
+        """Verify that decompose_transform3d() returns the original 12-float tuple under 'raw'."""
+        values = (1, 0, 0, 0, 1, 0, 0, 0, 1, -36.117, 0, -1.947)
+        result = decompose_transform3d(values)
+        assert "raw" in result
+        assert result["raw"] == values
+
+    def test_parse_value_transform3d_has_raw(self) -> None:
+        """Verify that parsing a Transform3D string includes the raw key."""
+        result = parse_value("Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 5, 0, 0)")
+        assert isinstance(result, dict)
+        assert "raw" in result
+        assert result["raw"] == (1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 5.0, 0.0, 0.0)
+
 
 class TestEdgeCases:
     """Edge cases for value parser."""
