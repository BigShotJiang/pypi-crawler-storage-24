# Sprint 1B+1C Interview Transcript

*Note: User requested autonomous execution ("proceed to accept all the edits the research etc."). Interview decisions derived from the detailed spec provided.*

## Q1: Should Scene Resolver and Project Index be in separate files or combined?

**A:** Separate files as specified: `scene_resolver.py` and `project_index.py`. They have distinct responsibilities — resolver handles single-scene expansion, index handles project-wide scanning.

## Q2: For world-space transform calculation, should we compose full 3x3 basis matrices or use simplified position-only accumulation?

**A:** Full basis matrix composition. The spec explicitly requires rotation-aware world position calculation: `world = parent_world + parent_rotation_matrix * local`. We already have `decompose_transform3d()` in value_parser.py — we need the inverse (compose/multiply) operation. Working with raw column-major 3x3 + origin avoids Euler angle gimbal issues during composition.

## Q3: How should non-.tscn instances (GLB, GLTF) be handled?

**A:** Per spec: "NON li risolviamo (non sono .tscn), ma li notiamo." Don't resolve them, but track them. Instance resolution only follows .tscn files. GLB/GLTF references are noted in instance_sources but their internal structure isn't expanded.

## Q4: For project.godot parsing, should we use Python's configparser or custom parsing?

**A:** Simple custom parsing. project.godot uses Godot's variant syntax for values (not standard INI), and we only need the [autoload] section plus project name. A few regex lines suffice — no need for configparser.

## Q5: Should addons/ be excluded from project scanning by default?

**A:** Yes, per spec test case `test_scan_skips_addons`. Also skip `.godot/` directory. Make it configurable if needed in the future, but default to skipping both.

## Q6: For the sample_project test fixture, should we copy full .tscn files or use minimal versions?

**A:** Use minimal .tscn files for the sample_project fixture. The full main.tscn is 4.1MB which is too large to duplicate. Create minimal scenes that exercise the same instance relationships. The existing test fixtures in `tests/fixtures/` can be symlinked or referenced for integration tests that need the full scene.

## Q7: What constitutes an "asset" for the Project Index?

**A:** Per spec: `.glb`, `.gltf`, `.png`, `.jpg`, `.tres` files. Track `{type, size_bytes, used_by: []}`. Type derived from extension. Size from os.path.getsize. used_by populated by scanning ext_resource entries in all parsed scenes.

## Q8: Performance targets?

**A:** Per spec: scan of 100-file project < 500ms, resolve of main.tscn < 200ms. FileCache should make incremental rescans near-instant for unchanged files.
