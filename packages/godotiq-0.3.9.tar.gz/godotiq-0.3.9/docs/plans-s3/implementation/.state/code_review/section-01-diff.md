diff --git a/tests/fixtures/sample_project/.godotiq.json b/tests/fixtures/sample_project/.godotiq.json
new file mode 100644
index 0000000..7863863
--- /dev/null
+++ b/tests/fixtures/sample_project/.godotiq.json
@@ -0,0 +1,16 @@
+{
+  "project": {
+    "name": "Sample Project",
+    "engine": "godot_4",
+    "type": "3d"
+  },
+  "conventions": {
+    "naming": "snake_case"
+  },
+  "token_optimization": {
+    "default_detail": "normal",
+    "enable_diff_cache": true,
+    "compact_output": true,
+    "max_nodes_per_response": 50
+  }
+}
diff --git a/tests/fixtures/sample_project/project.godot b/tests/fixtures/sample_project/project.godot
index 73493f5..84a161a 100644
--- a/tests/fixtures/sample_project/project.godot
+++ b/tests/fixtures/sample_project/project.godot
@@ -6,3 +6,5 @@ run/main_scene="res://scenes/main.tscn"
 [autoload]
 
 GameManager="*res://scripts/entities/printer.gd"
+EconomyManager="*res://scripts/autoloads/economy_manager.gd"
+ProgressionManager="*res://scripts/autoloads/progression_manager.gd"
diff --git a/tests/fixtures/sample_project/scripts/autoloads/economy_manager.gd b/tests/fixtures/sample_project/scripts/autoloads/economy_manager.gd
new file mode 100644
index 0000000..b68dcea
--- /dev/null
+++ b/tests/fixtures/sample_project/scripts/autoloads/economy_manager.gd
@@ -0,0 +1,45 @@
+class_name EconomyManagerClass
+extends Node
+
+var cash: float = 100.0
+var total_earned: float = 0.0
+var total_spent: float = 0.0
+
+signal cash_changed(new_amount: float, delta: float)
+signal transaction_recorded(type: String, amount: float, description: String)
+signal insufficient_funds(required: float, available: float)
+
+func _ready() -> void:
+	pass
+
+func add_cash(amount: float, description: String = "") -> void:
+	cash += amount
+	total_earned += amount
+	cash_changed.emit(cash, amount)
+
+func spend_cash(amount: float, description: String = "") -> bool:
+	if cash < amount:
+		insufficient_funds.emit(amount, cash)
+		return false
+	cash -= amount
+	total_spent += amount
+	cash_changed.emit(cash, -amount)
+	return true
+
+func can_afford(amount: float) -> bool:
+	return cash >= amount
+
+func get_profit() -> float:
+	return total_earned - total_spent
+
+func serialize() -> Dictionary:
+	return {
+		"cash": cash,
+		"total_earned": total_earned,
+		"total_spent": total_spent,
+	}
+
+func deserialize(data: Dictionary) -> void:
+	cash = data.get("cash", 100.0)
+	total_earned = data.get("total_earned", 0.0)
+	total_spent = data.get("total_spent", 0.0)
diff --git a/tests/fixtures/sample_project/scripts/autoloads/progression_manager.gd b/tests/fixtures/sample_project/scripts/autoloads/progression_manager.gd
new file mode 100644
index 0000000..d9107d9
--- /dev/null
+++ b/tests/fixtures/sample_project/scripts/autoloads/progression_manager.gd
@@ -0,0 +1,43 @@
+class_name ProgressionManagerClass
+extends Node
+
+var player_level: int = 1
+var experience: float = 0.0
+
+signal xp_gained(amount: int, new_total: float)
+signal level_up(new_level: int, unlocks: Dictionary)
+signal product_unlocked(product_id: String)
+
+func _ready() -> void:
+	pass
+
+func add_xp(amount: int) -> void:
+	experience += amount
+	xp_gained.emit(amount, experience)
+
+func get_level_unlocks(level: int) -> Dictionary:
+	return {"max_printers": level, "max_workers": level}
+
+func get_max_printers() -> int:
+	return player_level
+
+func _get_game_time() -> float:
+	if GameManager:
+		return GameManager.game_time
+	return 0.0
+
+func _check_economy() -> void:
+	if EconomyManager:
+		var profit = EconomyManager.get_profit()
+		if profit > 100.0:
+			level_up.emit(player_level + 1, {})
+
+func serialize() -> Dictionary:
+	return {
+		"player_level": player_level,
+		"experience": experience,
+	}
+
+func deserialize(data: Dictionary) -> void:
+	player_level = data.get("player_level", 1)
+	experience = data.get("experience", 0.0)
diff --git a/tests/test_parsers/test_project_index.py b/tests/test_parsers/test_project_index.py
index cfe6958..dc3d745 100644
--- a/tests/test_parsers/test_project_index.py
+++ b/tests/test_parsers/test_project_index.py
@@ -86,9 +86,11 @@ class TestScanProject:
         assert "res://scenes/equipment/fdm_printer.tscn" in scanned_index.scenes
 
     def test_scan_finds_all_scripts(self, scanned_index: ProjectIndex) -> None:
-        assert scanned_index.total_scripts == 2
+        assert scanned_index.total_scripts == 4
         assert "res://scripts/entities/printer.gd" in scanned_index.scripts
         assert "res://scripts/entities/worker.gd" in scanned_index.scripts
+        assert "res://scripts/autoloads/economy_manager.gd" in scanned_index.scripts
+        assert "res://scripts/autoloads/progression_manager.gd" in scanned_index.scripts
 
     def test_scan_finds_assets(self, scanned_index: ProjectIndex) -> None:
         assert scanned_index.total_assets >= 2
