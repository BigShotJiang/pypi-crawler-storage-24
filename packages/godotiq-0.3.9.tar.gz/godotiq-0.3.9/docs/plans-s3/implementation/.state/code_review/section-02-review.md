# Section 02 Code Review

## Issues Found

1. **HIGH**: get_scene() caching doesn't populate _tscn_scenes for index-provided scenes
2. **MEDIUM**: to_res_path() doesn't handle absolute filesystem paths
3. **MEDIUM**: resolve_file_path() misses assets tracked in index
4. **LOW-MEDIUM**: load() doesn't handle parse_gd exceptions gracefully
5. **LOW-MEDIUM**: discover_project_root() step 2 doesn't validate project.godot
6. **LOW**: test_signal_connections is vacuous assertion
7. **LOW**: Missing test for resolve_scene_spatial()
8. **LOW**: Missing test for .godotiq.json discovery path
9. **LOW**: Test count discrepancy (16 stated, 13 actual)
