# Section 02 Code Review Interview

## Triage Summary

| # | Issue | Severity | Action |
|---|-------|----------|--------|
| 1 | get_scene() caching inconsistency | HIGH | Let go: index scenes stable, _tscn_scenes for lazy extras only |
| 2 | to_res_path() absolute paths | MEDIUM | Auto-fix: handle absolute paths by stripping project_root |
| 3 | resolve_file_path() misses assets | MEDIUM | Auto-fix: added assets check |
| 4 | load() exception handling | LOW-MED | Auto-fix: wrap parse_gd in try/except |
| 5 | discover step 2 validation | LOW-MED | Let go: design intent |
| 6 | Vacuous test_signal_connections | LOW | Let go: empty dict is correct, no connect() in fixtures |
| 7 | Missing resolve_scene_spatial test | LOW | Auto-fix: added 2 tests |
| 8 | Missing .godotiq.json discovery test | LOW | Let go |
| 9 | Test count | LOW | Let go |

## Auto-Fixes Applied

### Fix 2: to_res_path handles absolute paths
Added `Path.relative_to(self.project_root)` logic for absolute paths.

### Fix 3: resolve_file_path includes assets
Added `res_path in self._index.assets` check.

### Fix 4: load() wraps parse_gd in try/except
Added `try/except Exception` with logging.warning around parse_gd calls.

### Fix 7: Added resolve_scene_spatial tests
- `test_resolve_scene_spatial`: verifies return type and caching
- `test_resolve_scene_spatial_missing`: verifies None for missing scene
- `test_to_res_path_absolute`: verifies absolute path handling
