# Section 04 Code Review Interview

## Issue Triage

### Issue 1: Crash on _index is None — AUTO-FIX
Add defensive guard at top of `_build_project_summary`.

### Issue 2: _read_main_scene re-reads project.godot — LET GO
Out of scope. Tool calls are infrequent, file is tiny. Technical debt noted.

### Issue 3: No detail parameter validation — AUTO-FIX
Normalize detail to lowercase.

### Issue 4: uses_groups doesn't break outer loop — AUTO-FIX
Add early-exit optimization for all pattern detection.

### Issue 5: Repeated imports in tests — LET GO
Necessary to avoid circular import at module level.

### Issue 6: No test for invalid detail — LET GO
After fix #3, invalid detail returns brief — reasonable default.

### Issue 7: No test for None session MCP path — LET GO
Would require MCP server harness.

### Issue 8: scene_tree returns all scenes — AUTO-FIX
Filter to top-level only (scenes not instanced by others).

### Issue 9: key_systems duplicates autoloads — LET GO
Spec-compliant; different semantic purpose.

## Fixes Applied

- **Fix #1**: Added `session._index is None` guard in `_build_project_summary`
- **Fix #3**: Normalize `detail = detail.lower()`
- **Fix #4**: Early-exit pattern detection when all flags are True
- **Fix #8**: Filter `scene_tree` to top-level scenes using `scene_instance_of`
