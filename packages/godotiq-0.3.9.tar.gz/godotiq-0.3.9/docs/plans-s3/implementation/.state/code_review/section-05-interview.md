# Section 05 Code Review Interview

## Issue Triage

| # | Severity | Action | Rationale |
|---|----------|--------|-----------|
| 1 | Major | Let go | Plan deviation is intentional and correct (lifespan_context) |
| 2 | Major | Auto-fix | Better error message for unsupported file types |
| 3 | Major | Auto-fix | Add safety field tests |
| 4 | Major | Auto-fix | Add depended_by test |
| 5 | Minor | Auto-fix | Add tscn field tests |
| 6 | Minor | Auto-fix | Add type annotations per project conventions |
| 7 | Minor | Let go | Index acts as whitelist, defense-in-depth not needed now |
| 8 | Minor | Let go | Acceptable perf for typical Godot projects |
| 9 | Nitpick | Auto-fix | Remove unused import |
| 10 | Nitpick | Let go | GdVariable has no is_private; consistent with parser design |

## Fixes Applied

- #2: Return "Unsupported file type" error for resolved but non-.gd/.tscn files
- #3: Added test_context_gd_safety verifying is_instance_valid_count and has_serialize
- #4: Added test_context_gd_depended_by verifying autoload reverse lookup
- #5: Added tests for groups_used and instanced_by on tscn scenes
- #6: Added GdScript and TscnScene type annotations to helper functions
- #9: Removed unused pytest import
