# Section 04: Tool G01 -- Project Summary

## Overview

Implement `godotiq_project_summary` -- the "one-call re-priming" tool. After context compact or new session, this is the first call an AI agent makes to recover project understanding. Returns a complete project overview with three detail levels.

**File modified:** `src/godotiq/tools/memory/__init__.py`
**Test file created:** `tests/test_tools/test_project_summary.py`

---

## Dependencies

- **Upstream:** Section 03 (server integration -- mcp instance and session access pattern)
- **Downstream:** Section 05 (file_context will be added to the same memory package)

---

## Implementation Details

### `src/godotiq/tools/memory/__init__.py`

Architecture: Four internal functions + one MCP tool wrapper:

- `_read_main_scene(session)` — reads `run/main_scene` from project.godot
- `_build_brief(session)` — project_name, engine, type, counts, autoloads
- `_build_normal(session)` — adds architecture (main_scene, autoload_details, scene_tree, key_systems) + scene_structure
- `_build_full(session)` — adds autoload_analysis, file_tree, detected_patterns
- `_build_project_summary(session, detail)` — composes the above based on detail level

### Deviations from Original Plan

1. **`lifespan_context` not `lifespan_state`** — corrected access pattern per section-03 findings
2. **Added `_index is None` guard** — defensive check returns error dict if project index not loaded (review fix #1)
3. **Detail parameter normalized** — `detail.lower()` for case-insensitive matching (review fix #3)
4. **`scene_tree` filters to top-level** — excludes scenes instanced by other scenes (review fix #8)
5. **Early-exit pattern detection** — breaks out of loops once all flags are True (review fix #4)
6. **Code in `memory/__init__.py`** — kept as package (not flat file) since memory/ already existed

### MCP Tool Registration

```python
@mcp.tool(name="godotiq_project_summary", annotations={...})
async def godotiq_project_summary(detail: str = "normal", ctx: Context = None) -> dict:
    session = ctx.request_context.lifespan_context["session"]
    ...
```

---

## Files Created/Modified

- **Modified:** `src/godotiq/tools/memory/__init__.py` — full implementation
- **Created:** `tests/test_tools/test_project_summary.py` — 26 tests

## Test Results

All 269 tests pass (243 existing + 26 new).

---

## Checklist

- [x] `src/godotiq/tools/memory/__init__.py` created with `_build_project_summary` and MCP tool
- [x] `_build_project_summary` handles "brief", "normal", "full" detail levels
- [x] brief returns: project_name, engine, type, counts, autoloads
- [x] normal adds: architecture, scene_structure
- [x] full adds: autoload_analysis, file_tree, detected_patterns
- [x] Tool registered with correct MCP annotations
- [x] `tests/test_tools/test_project_summary.py` created with all tests
- [x] All tests pass: `uv run pytest tests/ -v`
- [x] Defensive guard for `_index is None` (review fix)
- [x] `scene_tree` filters to top-level scenes only (review fix)
