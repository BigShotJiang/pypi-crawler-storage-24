<!-- PROJECT_CONFIG
runtime: python-pip
test_command: uv run pytest tests/ -v
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-test-fixtures
section-02-session-layer
section-03-server-integration
section-04-tool-project-summary
section-05-tool-file-context
section-06-tool-dependency-graph
section-07-tool-scene-map
END_MANIFEST -->

# Sprint 3: First Real MCP Tools -- Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-test-fixtures | - | 02 | Yes |
| section-02-session-layer | 01 | 03 | No |
| section-03-server-integration | 02 | 04, 05, 06, 07 | No |
| section-04-tool-project-summary | 03 | - | Yes (with 05, 06, 07) |
| section-05-tool-file-context | 03 | - | Yes (with 04, 06, 07) |
| section-06-tool-dependency-graph | 03 | - | Yes (with 04, 05, 07) |
| section-07-tool-scene-map | 03 | - | Yes (with 04, 05, 06) |

## Execution Order

1. **section-01-test-fixtures** (no dependencies -- foundation)
2. **section-02-session-layer** (after 01)
3. **section-03-server-integration** (after 02)
4. **section-04 through section-07** (parallel after 03 -- all tools are independent)

## Section Summaries

### section-01-test-fixtures
Enhance the `tests/fixtures/sample_project/` with a realistic project.godot containing 3 autoloads (GameManager, EconomyManager, ProgressionManager), matching .gd scripts with signals/functions/autoload references, and a .godotiq.json config file. The .gd files must contain enough complexity to exercise signals, emissions, connections, autoload Pattern 1 references, and cross-file dependencies. Existing fixture files are only extended, never removed.

**Files:** `tests/fixtures/sample_project/project.godot` (modify), `tests/fixtures/sample_project/scripts/autoloads/game_manager.gd` (new), `tests/fixtures/sample_project/scripts/autoloads/economy_manager.gd` (new), `tests/fixtures/sample_project/scripts/entities/printer.gd` (modify), `tests/fixtures/sample_project/scripts/entities/worker.gd` (modify), `tests/fixtures/sample_project/.godotiq.json` (new)

### section-02-session-layer
Implement `src/godotiq/session.py` with `GodotIQSession` class that orchestrates project scanning, autoload-aware .gd parsing, lazy scene resolution, and cross-reference queries. Also implements project root discovery (env var, config, walk-up). Tests in `tests/test_tools/test_session.py` verify loading, autoload detection, caching, and cross-reference methods.

**Files:** `src/godotiq/session.py` (new), `tests/test_tools/test_session.py` (new)

### section-03-server-integration
Modify `src/godotiq/server.py` to add FastMCP lifespan that creates a GodotIQSession, expose it via context, and establish the tool registration pattern. Keep godotiq_ping working. Update test infrastructure so tools can be tested without a live MCP server (direct function calls with mock session).

**Files:** `src/godotiq/server.py` (modify), `tests/test_tools/conftest.py` (new)

### section-04-tool-project-summary
Implement `godotiq_project_summary` tool in `src/godotiq/tools/memory.py` with brief/normal/full detail levels. Tests verify output fields, file counts, autoload names, and architecture overview content.

**Files:** `src/godotiq/tools/memory.py` (new implementation), `tests/test_tools/test_project_summary.py` (new)

### section-05-tool-file-context
Implement `godotiq_file_context` tool in `src/godotiq/tools/memory.py` for both .gd and .tscn files. Handles res:// and relative paths, returns dependencies, public API, signals, and scene data. Tests cover both file types, path formats, autoload detection, and missing files.

**Files:** `src/godotiq/tools/memory.py` (modify -- add file_context), `tests/test_tools/test_file_context.py` (new)

### section-06-tool-dependency-graph
Implement `godotiq_dependency_graph` tool in `src/godotiq/tools/code.py` with signal cross-referencing, autoload dependency tracking, and impact rating calculation. Tests verify graph structure, depth parameter, and bidirectional dependency tracking.

**Files:** `src/godotiq/tools/code.py` (new implementation), `tests/test_tools/test_dependency_graph.py` (new)

### section-07-tool-scene-map
Implement `godotiq_scene_map` tool in `src/godotiq/tools/spatial.py` using the scene resolver and world transforms. Supports focus node, radius filtering, detail levels, and spatial relationship computation (directions, distances). Tests verify spatial data, filtering, and detail levels.

**Files:** `src/godotiq/tools/spatial.py` (new implementation), `tests/test_tools/test_scene_map.py` (new)
