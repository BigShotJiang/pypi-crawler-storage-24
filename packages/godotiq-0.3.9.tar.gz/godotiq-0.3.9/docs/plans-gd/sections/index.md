<!-- PROJECT_CONFIG
runtime: python-pip
test_command: pytest tests/ -v
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-dataclasses-helpers
section-02-state-machine-core
section-03-body-patterns
section-04-tests-unit
section-05-tests-integration
END_MANIFEST -->

# GDScript Parser — Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-dataclasses-helpers | - | 02, 03 | Yes |
| section-02-state-machine-core | 01 | 04, 05 | No |
| section-03-body-patterns | 01 | 04, 05 | Yes (with 02) |
| section-04-tests-unit | 02, 03 | 05 | No |
| section-05-tests-integration | 04 | - | No |

## Execution Order

1. **section-01-dataclasses-helpers** (no dependencies — foundation)
2. **section-02-state-machine-core** + **section-03-body-patterns** (parallel after 01)
3. **section-04-tests-unit** (after 02 AND 03)
4. **section-05-tests-integration** (after 04)

## Section Summaries

### section-01-dataclasses-helpers
All 9 dataclasses (GdSignal, GdFunction, GdVariable, GdEnum, GdSignalConnection, GdSignalEmission, GdAutoloadRef, GdPreloadRef, GdScript) plus helper functions (_strip_comment, _split_args_depth_aware, _find_matching_paren, _parse_signal_args, _parse_func_args, _count_emit_args, _parse_enum_body). Imports, logger setup, compiled regex patterns.

**Files:** `src/godotiq/parsers/gd_parser.py` (dataclasses + helpers only, no state machine yet)

### section-02-state-machine-core
The `_parse_gd_content()` function with the state machine: TOP_LEVEL state handling for class_name, extends, signals, functions (entering IN_FUNCTION), variables (with annotation handling — same-line and buffered), enums (IN_ENUM), multiline values (IN_MULTILINE_VALUE), inner classes (IN_INNER_CLASS), property getter/setter, comment stripping, indentation tracking, static var/func handling. The `parse_gd()` public wrapper function.

**Files:** `src/godotiq/parsers/gd_parser.py` (adds state machine to section 01's foundation)

### section-03-body-patterns
IN_FUNCTION state body scanning: .connect() detection (depth-aware), .emit() detection with arg counting, autoload reference detection (direct, has_node, get_node, get_node_or_null), is_instance_valid detection, preload/load detection (all states). Autoload alternation regex compilation from known_autoloads list.

**Files:** `src/godotiq/parsers/gd_parser.py` (adds body pattern detection to section 02's state machine)

### section-04-tests-unit
Unit tests using `_parse_gd_content()` with inline strings: TestClassDeclarations, TestSignalParsing, TestFunctionParsing, TestVariableParsing, TestEnumParsing, TestSignalConnections, TestSignalEmissions, TestAutoloadRefs, TestPreloadLoad, TestIsInstanceValid, TestInnerClasses, TestEdgeCases.

**Files:** `tests/test_parsers/test_gd_parser.py` (unit tests only)

### section-05-tests-integration
Integration tests using real fixture files: TestIntegration with parametrized tests for economy_manager.gd, printer_manager.gd, game_manager.gd, progression_manager.gd, minimal fixtures. Assertions on expected counts, names, and structural correctness. Verify all 127 Sprint 0/1 tests still pass.

**Files:** `tests/test_parsers/test_gd_parser.py` (adds integration tests to section 04's unit tests)
