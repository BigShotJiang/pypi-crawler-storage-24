# Section 01 Code Review Interview

## Auto-fixes Applied

1. **Per-type bracket depth tracking** (Issue #2): Changed `_split_args_depth_aware` from single `depth` counter to separate `paren`, `bracket`, `brace` counters as the plan specifies.

2. **Safer colon stripping** (Issue #3): Changed `rstrip(':')` to `removesuffix(':')` in `_parse_func_args` to avoid stripping multiple colons.

3. **Enum value error handling** (Issue #4): Added try/except around `int()` conversion in `_parse_enum_body` so non-integer enum values (hex, expressions) default to `None` instead of crashing.

## Let Go (Not Actionable)

- Escaped quotes in `_strip_comment`: GDScript rarely uses `\"` in the patterns we scan. Out of scope.
- Triple-quoted strings: Not mentioned in plan, out of scope.
- Signal regex multiline: Documented limitation in plan.
- VAR_RE edge cases: Works for all fixture patterns. Later sections can refine.
- New dataclass importability: Addressed by section 04 tests.
- parse_gd signature change: Acknowledged in plan, backward compatible.
