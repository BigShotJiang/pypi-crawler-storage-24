# Section 02 Code Review Interview

## Auto-fixes Applied

1. **Annotation buffer cleared in steps 1-5** (Issue #2): Added `annotation_buffer = ""` after class_name, extends, signal, and enum parsing to prevent stale annotations from being applied to subsequent variables.

2. **is_preload match-scoped** (Issue #4): Changed `_PRELOAD_RE.search(raw_line)` to `raw_line[plm.start():plm.end()].startswith("preload")` for correct detection when both preload and load appear on the same line.

3. **_PROPERTY_RE widened** (Issue #5): Changed type group from `(\w[\w\[\]]*)` to `([\w.\[\], ]+?)` to support dotted types like `Printer.State` in property getter/setter declarations.

4. **Module-level Path import** (Issue #7): Moved `from pathlib import Path` to module level instead of lazy import inside `parse_gd()`.

5. **Added buffered annotation test** (Issue #10): Added `test_buffered_annotation_separate_line` to verify that `@export` on a separate line is correctly applied to the next variable.

## Let Go

- Issue #1 (rfind fragility): Works for all real GDScript patterns.
- Issue #3 (bracket depth in strings): Rare edge case, plan's best-effort approach acceptable.
- Issue #6 (phantom empty line): Harmless, tests pass correctly.
- Issue #8 (code duplication): Valid maintenance concern but not a correctness issue.
- Issue #9 (known_autoloads unused): By design — section 03 will use it.
- Issues #11-13 (extra tests): Section 04/05 will add comprehensive coverage.
