# Section 03 Code Review Interview

## Triage Summary

| # | Issue | Severity | Action |
|---|-------|----------|--------|
| 1 | `_PRELOAD_LOAD_RE` matches `download()` etc as false positive | HIGH | Auto-fix: use separate regexes with lookbehind |
| 2 | `get_node`/`get_node_or_null` duplicate concern | HIGH | Let go: verified regex doesn't match |
| 3 | Dead `_PRELOAD_RE` regex | MEDIUM | Auto-fix: use as part of fix #1 |
| 4 | Body patterns only in IN_FUNCTION | MEDIUM | Let go: design per plan |
| 5 | Signal source extraction limitations | MEDIUM | Let go: matches plan spec |
| 6 | Autoload direct captures only first match per line | MEDIUM | Auto-fix: use finditer |
| 7 | No comment stripping in IN_FUNCTION body | LOW | Auto-fix: add _strip_comment |
| 8-10 | Test coverage suggestions, node name limitations | LOW | Let go |

## Auto-Fixes Applied

### Fix 1+3: Replace combined `_PRELOAD_LOAD_RE` with separate `_PRELOAD_RE` + `_LOAD_RE`
- Remove `_PRELOAD_LOAD_RE`
- Use existing `_PRELOAD_RE` (already compiled, was dead code)
- Add `_LOAD_RE` with `(?<!\w)` negative lookbehind
- Update cross-state scanning to use both regexes independently

### Fix 6: Use finditer for autoload direct pattern
- Change `.search()` to loop over `.finditer()` matches

### Fix 7: Strip inline comments in IN_FUNCTION before pattern matching
- Add `cleaned = _strip_comment(stripped)` and use for pattern detection
