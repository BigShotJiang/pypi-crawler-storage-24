diff --git a/docs/plans-gd/implementation/deep_implement_config.json b/docs/plans-gd/implementation/deep_implement_config.json
index df8835e..2023684 100644
--- a/docs/plans-gd/implementation/deep_implement_config.json
+++ b/docs/plans-gd/implementation/deep_implement_config.json
@@ -17,6 +17,10 @@
     "section-01-dataclasses-helpers": {
       "status": "complete",
       "commit_hash": "797f3a7"
+    },
+    "section-02-state-machine-core": {
+      "status": "complete",
+      "commit_hash": "067c061"
     }
   },
   "pre_commit": {
diff --git a/src/godotiq/parsers/gd_parser.py b/src/godotiq/parsers/gd_parser.py
index 0ce2c18..005365f 100644
--- a/src/godotiq/parsers/gd_parser.py
+++ b/src/godotiq/parsers/gd_parser.py
@@ -473,6 +473,13 @@ def _parse_gd_content(
         Populated ``GdScript`` dataclass.  Never raises on malformed content.
     """
     result = GdScript()
+
+    # Compile autoload direct-pattern regex once per parse invocation
+    re_autoload_direct = None
+    if known_autoloads:
+        alt = "|".join(re.escape(name) for name in known_autoloads)
+        re_autoload_direct = re.compile(rf"\b({alt})\.(\w+)")
+
     state = _STATE_TOP_LEVEL
 
     # Function tracking
@@ -578,7 +585,108 @@ def _parse_gd_content(
                 continue
             # Body line — track last non-blank for end_line
             last_nonblank_line = lineno
-            # Section 03 will add body pattern scanning here
+
+            # --- Body pattern scanning (section 03) ---
+
+            # .connect() detection (depth-aware)
+            cm = _CONNECT_RE.search(stripped)
+            if cm:
+                before_connect = stripped[:cm.start()]
+                source_m = re.search(r"([\w.$]+)$", before_connect.rstrip())
+                signal_source = source_m.group(1) if source_m else before_connect.strip()
+                paren_pos = cm.end() - 1  # position of opening (
+                close_paren = _find_matching_paren(stripped, paren_pos)
+                if close_paren != -1:
+                    args_content = stripped[paren_pos + 1:close_paren]
+                    has_bind = ".bind(" in args_content
+                    bind_args = ""
+                    target = args_content.strip()
+                    if has_bind:
+                        bind_idx = args_content.index(".bind(")
+                        target = args_content[:bind_idx].strip()
+                        bind_start = args_content.index("(", bind_idx)
+                        bind_close = _find_matching_paren(args_content, bind_start)
+                        if bind_close != -1:
+                            bind_args = args_content[bind_start + 1:bind_close].strip()
+                    result.signal_connections.append(
+                        GdSignalConnection(
+                            signal_source=signal_source,
+                            target=target,
+                            has_bind=has_bind,
+                            bind_args=bind_args,
+                            line=lineno,
+                        )
+                    )
+
+            # .emit() detection with arg counting
+            em = _EMIT_RE.search(stripped)
+            if em:
+                signal_name = em.group(1)
+                paren_pos = em.end() - 1
+                close_paren = _find_matching_paren(stripped, paren_pos)
+                if close_paren != -1:
+                    args_str = stripped[paren_pos + 1:close_paren]
+                    result.signal_emissions.append(
+                        GdSignalEmission(
+                            signal_name=signal_name,
+                            arg_count=_count_emit_args(args_str),
+                            line=lineno,
+                        )
+                    )
+
+            # Autoload direct pattern
+            if re_autoload_direct is not None:
+                am = re_autoload_direct.search(stripped)
+                if am:
+                    result.autoload_refs.append(
+                        GdAutoloadRef(
+                            autoload_name=am.group(1),
+                            access=am.group(2),
+                            pattern="direct",
+                            line=lineno,
+                        )
+                    )
+
+            # has_node pattern
+            hm = _HAS_NODE_RE.search(stripped)
+            if hm:
+                path = hm.group(1)
+                result.autoload_refs.append(
+                    GdAutoloadRef(
+                        autoload_name=path.split("/")[-1],
+                        access="",
+                        pattern="has_node",
+                        line=lineno,
+                    )
+                )
+
+            # get_node pattern (won't match get_node_or_null due to _or_null before paren)
+            gm = _GET_NODE_RE.search(stripped)
+            if gm:
+                path = gm.group(1)
+                result.autoload_refs.append(
+                    GdAutoloadRef(
+                        autoload_name=path.split("/")[-1],
+                        access="",
+                        pattern="get_node",
+                        line=lineno,
+                    )
+                )
+
+            # get_node_or_null pattern
+            gnm = _GET_NODE_OR_NULL_RE.search(stripped)
+            if gnm:
+                full_path = gnm.group(1)
+                name = full_path.split("/")[-1]
+                result.autoload_refs.append(
+                    GdAutoloadRef(
+                        autoload_name=name,
+                        access=full_path,
+                        pattern="get_node_or_null",
+                        line=lineno,
+                    )
+                )
+
             continue
 
         # ---------------------------------------------------------------
diff --git a/tests/test_parsers/test_gd_parser.py b/tests/test_parsers/test_gd_parser.py
index cd0eb1a..d7bbadb 100644
--- a/tests/test_parsers/test_gd_parser.py
+++ b/tests/test_parsers/test_gd_parser.py
@@ -390,3 +390,198 @@ class TestEdgeCases:
         content = '@export_group("Group")\nvar plain: int = 1\n'
         result = _parse_gd_content(content)
         assert result.variables[0].annotation == ""
+
+
+# ---------------------------------------------------------------------------
+# TestSignalConnections
+# ---------------------------------------------------------------------------
+
+
+class TestSignalConnections:
+    """Tests for .connect() detection inside function bodies."""
+
+    def test_direct_connect(self) -> None:
+        content = "func _ready():\n\tmy_signal.connect(_handler)\n"
+        result = _parse_gd_content(content)
+        assert len(result.signal_connections) == 1
+        assert result.signal_connections[0].signal_source == "my_signal"
+        assert result.signal_connections[0].target == "_handler"
+        assert result.signal_connections[0].has_bind is False
+
+    def test_connect_with_bind(self) -> None:
+        content = "func _ready():\n\tmy_signal.connect(_handler.bind(some_arg))\n"
+        result = _parse_gd_content(content)
+        conn = result.signal_connections[0]
+        assert conn.has_bind is True
+        assert conn.bind_args == "some_arg"
+
+    def test_connect_with_dollar_node(self) -> None:
+        content = "func _ready():\n\t$Timer.timeout.connect(_on_timeout)\n"
+        result = _parse_gd_content(content)
+        conn = result.signal_connections[0]
+        assert conn.signal_source == "$Timer.timeout"
+        assert conn.target == "_on_timeout"
+
+    def test_connect_with_lambda(self) -> None:
+        content = "func _ready():\n\tlevel_up.connect(func(_l, _u): fired[0] = true)\n"
+        result = _parse_gd_content(content)
+        conn = result.signal_connections[0]
+        assert conn.target.startswith("func")
+
+    def test_depth_aware_connect_parsing(self) -> None:
+        content = "func _ready():\n\tif signal.connect(handler) == OK:\n\t\tpass\n"
+        result = _parse_gd_content(content)
+        conn = result.signal_connections[0]
+        assert conn.target == "handler"
+
+    def test_signal_source_captures_full_chain(self) -> None:
+        content = "func _ready():\n\tprinter.print_started.connect(_on_print_started)\n"
+        result = _parse_gd_content(content)
+        conn = result.signal_connections[0]
+        assert conn.signal_source == "printer.print_started"
+
+    def test_connect_line_number(self) -> None:
+        content = "func _ready():\n\tvar x = 1\n\tmy_signal.connect(_handler)\n"
+        result = _parse_gd_content(content)
+        assert result.signal_connections[0].line == 3
+
+
+# ---------------------------------------------------------------------------
+# TestSignalEmissions
+# ---------------------------------------------------------------------------
+
+
+class TestSignalEmissions:
+    """Tests for .emit() detection inside function bodies."""
+
+    def test_emit_no_args(self) -> None:
+        content = "func foo():\n\thealth_depleted.emit()\n"
+        result = _parse_gd_content(content)
+        assert len(result.signal_emissions) == 1
+        assert result.signal_emissions[0].signal_name == "health_depleted"
+        assert result.signal_emissions[0].arg_count == 0
+
+    def test_emit_two_args(self) -> None:
+        content = "func foo():\n\tcash_changed.emit(cash, amount)\n"
+        result = _parse_gd_content(content)
+        assert result.signal_emissions[0].arg_count == 2
+
+    def test_emit_three_args(self) -> None:
+        content = "func foo():\n\tany_print_failed.emit(id, product, reason)\n"
+        result = _parse_gd_content(content)
+        assert result.signal_emissions[0].arg_count == 3
+
+    def test_emit_with_nested_parens(self) -> None:
+        content = "func foo():\n\tmy_signal.emit(Vector2(1, 2), 3)\n"
+        result = _parse_gd_content(content)
+        assert result.signal_emissions[0].arg_count == 2
+
+
+# ---------------------------------------------------------------------------
+# TestAutoloadRefs
+# ---------------------------------------------------------------------------
+
+
+class TestAutoloadRefs:
+    """Tests for autoload singleton reference detection."""
+
+    def test_direct_autoload_with_known_autoloads(self) -> None:
+        content = "func foo():\n\tEconomyManager.spend_cash(100)\n"
+        result = _parse_gd_content(content, known_autoloads=["EconomyManager"])
+        refs = [r for r in result.autoload_refs if r.pattern == "direct"]
+        assert len(refs) >= 1
+        assert refs[0].autoload_name == "EconomyManager"
+        assert refs[0].access == "spend_cash"
+
+    def test_no_direct_detection_without_known_autoloads(self) -> None:
+        content = "func foo():\n\tEconomyManager.spend_cash(100)\n"
+        result = _parse_gd_content(content, known_autoloads=None)
+        direct = [r for r in result.autoload_refs if r.pattern == "direct"]
+        assert len(direct) == 0
+
+    def test_has_node_pattern(self) -> None:
+        content = 'func foo():\n\thas_node("/root/ProgressionManager")\n'
+        result = _parse_gd_content(content)
+        refs = [r for r in result.autoload_refs if r.pattern == "has_node"]
+        assert len(refs) == 1
+        assert refs[0].autoload_name == "ProgressionManager"
+
+    def test_get_node_pattern(self) -> None:
+        content = 'func foo():\n\tget_node("/root/ProgressionManager")\n'
+        result = _parse_gd_content(content)
+        refs = [r for r in result.autoload_refs if r.pattern == "get_node"]
+        assert len(refs) == 1
+        assert refs[0].autoload_name == "ProgressionManager"
+
+    def test_get_node_or_null_pattern(self) -> None:
+        content = 'func foo():\n\tget_tree().root.get_node_or_null("Main/Systems/PrinterSlotManager")\n'
+        result = _parse_gd_content(content)
+        refs = [r for r in result.autoload_refs if r.pattern == "get_node_or_null"]
+        assert len(refs) == 1
+
+    def test_has_node_detected_without_known_autoloads(self) -> None:
+        content = 'func foo():\n\thas_node("/root/SomeManager")\n'
+        result = _parse_gd_content(content, known_autoloads=None)
+        refs = [r for r in result.autoload_refs if r.pattern == "has_node"]
+        assert len(refs) == 1
+
+    def test_multiple_autoload_refs_separate_entries(self) -> None:
+        content = "func foo():\n\tEconomyManager.foo()\n\tResearchManager.bar()\n"
+        result = _parse_gd_content(
+            content, known_autoloads=["EconomyManager", "ResearchManager"]
+        )
+        direct = [r for r in result.autoload_refs if r.pattern == "direct"]
+        assert len(direct) >= 2
+
+
+# ---------------------------------------------------------------------------
+# TestPreloadLoad
+# ---------------------------------------------------------------------------
+
+
+class TestPreloadLoad:
+    """Tests for preload() and load() reference detection."""
+
+    def test_preload_detected(self) -> None:
+        content = 'const Scene = preload("res://scenes/player.tscn")\n'
+        result = _parse_gd_content(content)
+        assert len(result.preload_refs) == 1
+        assert result.preload_refs[0].path == "res://scenes/player.tscn"
+        assert result.preload_refs[0].is_preload is True
+
+    def test_load_detected(self) -> None:
+        content = 'func foo():\n\tvar tex = load("res://data/items.tres")\n'
+        result = _parse_gd_content(content)
+        assert len(result.preload_refs) == 1
+        assert result.preload_refs[0].is_preload is False
+
+    def test_preload_in_const_creates_both(self) -> None:
+        content = 'const MyScene = preload("res://scenes/player.tscn")\n'
+        result = _parse_gd_content(content)
+        consts = [v for v in result.variables if v.name == "MyScene"]
+        assert len(consts) == 1
+        assert len(result.preload_refs) == 1
+
+    def test_preload_in_function_body(self) -> None:
+        content = 'func foo():\n\tvar s = preload("res://foo.tscn")\n'
+        result = _parse_gd_content(content)
+        assert len(result.preload_refs) >= 1
+
+
+# ---------------------------------------------------------------------------
+# TestIsInstanceValid
+# ---------------------------------------------------------------------------
+
+
+class TestIsInstanceValid:
+    """Tests for is_instance_valid() detection."""
+
+    def test_is_instance_valid_detected(self) -> None:
+        content = "func foo():\n\tif is_instance_valid(printer):\n\t\tpass\n"
+        result = _parse_gd_content(content)
+        assert 2 in result.is_instance_valid_lines
+
+    def test_multiple_is_instance_valid(self) -> None:
+        content = "func foo():\n\tis_instance_valid(a)\n\tis_instance_valid(b)\n"
+        result = _parse_gd_content(content)
+        assert len(result.is_instance_valid_lines) >= 2
