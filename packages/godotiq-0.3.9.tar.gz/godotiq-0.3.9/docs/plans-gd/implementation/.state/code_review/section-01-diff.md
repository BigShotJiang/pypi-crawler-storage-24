diff --git a/src/godotiq/parsers/gd_parser.py b/src/godotiq/parsers/gd_parser.py
index e2f55a4..3da9f52 100644
--- a/src/godotiq/parsers/gd_parser.py
+++ b/src/godotiq/parsers/gd_parser.py
@@ -6,15 +6,65 @@ from GDScript source files.
 
 from __future__ import annotations
 
+import logging
+import re
 from dataclasses import dataclass, field
 
+logger = logging.getLogger(__name__)
+
+# ---------------------------------------------------------------------------
+# Pre-compiled regex patterns
+# ---------------------------------------------------------------------------
+
+# --- Class-level declarations ---
+_COMBINED_CLASS_EXTENDS_RE = re.compile(r"^class_name\s+(\w+)\s+extends\s+(.+)$")
+_CLASS_NAME_RE = re.compile(r"^class_name\s+(\w+)")
+_EXTENDS_RE = re.compile(r"^extends\s+(.+)$")
+
+# --- Signals ---
+_SIGNAL_RE = re.compile(r"^signal\s+(\w+)(?:\(([^)]*)\))?")
+
+# --- Functions ---
+_FUNC_START_RE = re.compile(r"^(?:static\s+)?func\s+(\w+)\s*\(")
+
+# --- Variables ---
+_VAR_RE = re.compile(
+    r"^(var|const)\s+(\w+)\s*(?::\s*([^=:]+?))?\s*(?:(?::=|=)\s*(.+))?$"
+)
+
+# --- Enums ---
+_ENUM_SINGLE_RE = re.compile(r"^enum\s+(\w+)?\s*\{([^}]*)\}")
+_ENUM_START_RE = re.compile(r"^enum\s+(\w+)?\s*\{")
+
+# --- Inner classes ---
+_INNER_CLASS_RE = re.compile(r"^class\s+(\w+)\s*(?:extends\s+[\w.]+)?\s*:")
+
+# --- Annotations ---
+_ANNOTATION_VAR_RE = re.compile(r"^(@\w+(?:\([^)]*\))?)\s+(var|const)\s+")
+_STANDALONE_ANNOTATION_RE = re.compile(r"^@(\w+)(?:\(([^)]*)\))?")
+
+# --- Body patterns ---
+_CONNECT_RE = re.compile(r"\.connect\(")
+_EMIT_RE = re.compile(r"(\w+)\.emit\(")
+_HAS_NODE_RE = re.compile(r'has_node\(\s*"(/root/[\w/]+)"\s*\)')
+_GET_NODE_RE = re.compile(r'get_node\(\s*"(/root/[\w/]+)"\s*\)')
+_GET_NODE_OR_NULL_RE = re.compile(r'get_node_or_null\(\s*"([^"]+)"\s*\)')
+_IS_INSTANCE_VALID_RE = re.compile(r"is_instance_valid\(")
+_PRELOAD_LOAD_RE = re.compile(r'(?:preload|load)\(\s*"([^"]+)"\s*\)')
+_PRELOAD_RE = re.compile(r'preload\(\s*"([^"]+)"\s*\)')
+
+# ---------------------------------------------------------------------------
+# Dataclasses
+# ---------------------------------------------------------------------------
+
 
 @dataclass
 class GdSignal:
     """A signal declaration in a GDScript file."""
 
     name: str = ""
-    args: list[str] = field(default_factory=list)
+    args: list[tuple[str, str]] = field(default_factory=list)
+    line: int = 0
 
 
 @dataclass
@@ -22,29 +72,291 @@ class GdFunction:
     """A function declaration in a GDScript file."""
 
     name: str = ""
-    args: list[str] = field(default_factory=list)
+    args: list[tuple[str, str, str]] = field(default_factory=list)
     return_type: str = ""
+    is_static: bool = False
+    is_virtual: bool = False
+    is_private: bool = False
+    line: int = 0
+    end_line: int = 0
+
+
+@dataclass
+class GdVariable:
+    """A variable or constant declaration in a GDScript file."""
+
+    name: str = ""
+    type_hint: str = ""
+    default_value: str = ""
+    is_const: bool = False
+    is_static: bool = False
+    annotation: str = ""
+    scope: str = "class"
+    line: int = 0
+
+
+@dataclass
+class GdEnum:
+    """An enum declaration in a GDScript file."""
+
+    name: str = ""
+    values: dict[str, int | None] = field(default_factory=dict)
+    line: int = 0
+
+
+@dataclass
+class GdSignalConnection:
+    """A signal .connect() call detected in a function body."""
+
+    signal_source: str = ""
+    target: str = ""
+    has_bind: bool = False
+    bind_args: str = ""
+    line: int = 0
+
+
+@dataclass
+class GdSignalEmission:
+    """A signal .emit() call detected in a function body."""
+
+    signal_name: str = ""
+    arg_count: int = 0
+    line: int = 0
+
+
+@dataclass
+class GdAutoloadRef:
+    """A reference to an autoload singleton detected in a function body."""
+
+    autoload_name: str = ""
+    access: str = ""
+    pattern: str = ""
+    line: int = 0
+
+
+@dataclass
+class GdPreloadRef:
+    """A preload() or load() call detected in the file."""
+
+    path: str = ""
+    is_preload: bool = True
+    line: int = 0
 
 
 @dataclass
 class GdScript:
     """Parsed representation of a .gd file."""
 
+    class_name: str = ""
+    extends: str = ""
     signals: list[GdSignal] = field(default_factory=list)
     functions: list[GdFunction] = field(default_factory=list)
-    extends: str = ""
+    variables: list[GdVariable] = field(default_factory=list)
+    enums: list[GdEnum] = field(default_factory=list)
+    inner_classes: list[str] = field(default_factory=list)
+    signal_connections: list[GdSignalConnection] = field(default_factory=list)
+    signal_emissions: list[GdSignalEmission] = field(default_factory=list)
+    autoload_refs: list[GdAutoloadRef] = field(default_factory=list)
+    preload_refs: list[GdPreloadRef] = field(default_factory=list)
+    is_instance_valid_lines: list[int] = field(default_factory=list)
+
+
+# ---------------------------------------------------------------------------
+# Helper functions
+# ---------------------------------------------------------------------------
+
+
+def _strip_comment(line: str) -> str:
+    """Strip inline comment from a line, respecting string literals.
+
+    Scans left-to-right tracking quote state. Strips from first unquoted ``#``.
+    Full-comment lines (leading whitespace + ``#``) are returned unchanged.
+    """
+    stripped = line.lstrip()
+    if not stripped or stripped.startswith("#"):
+        return line
+
+    in_double = False
+    in_single = False
+    for i, ch in enumerate(line):
+        if ch == '"' and not in_single:
+            in_double = not in_double
+        elif ch == "'" and not in_double:
+            in_single = not in_single
+        elif ch == "#" and not in_double and not in_single:
+            return line[:i].rstrip()
+    return line
+
+
+def _split_args_depth_aware(args_str: str) -> list[str]:
+    """Split an argument string by commas respecting nested brackets.
+
+    Tracks depth for ``()``, ``[]``, and ``{}``.  Only splits on commas at
+    depth zero.  Returns stripped strings; empty input returns an empty list.
+    """
+    args_str = args_str.strip()
+    if not args_str:
+        return []
+
+    parts: list[str] = []
+    current: list[str] = []
+    depth = 0
+
+    for ch in args_str:
+        if ch in "([{":
+            depth += 1
+            current.append(ch)
+        elif ch in ")]}":
+            depth -= 1
+            current.append(ch)
+        elif ch == "," and depth == 0:
+            parts.append("".join(current).strip())
+            current = []
+        else:
+            current.append(ch)
+
+    tail = "".join(current).strip()
+    if tail:
+        parts.append(tail)
+    return parts
+
+
+def _find_matching_paren(line: str, start: int) -> int:
+    """Return index of the closing ``)`` matching the ``(`` at *start*.
+
+    Uses depth tracking.  Returns ``-1`` if no match is found.
+    """
+    depth = 0
+    for i in range(start, len(line)):
+        if line[i] == "(":
+            depth += 1
+        elif line[i] == ")":
+            depth -= 1
+            if depth == 0:
+                return i
+    return -1
+
+
+def _parse_signal_args(args_str: str) -> list[tuple[str, str]]:
+    """Parse a signal argument string into ``(name, type_hint)`` tuples.
+
+    Untyped arguments get ``""`` as their type hint.
+    """
+    args_str = args_str.strip()
+    if not args_str:
+        return []
+
+    result: list[tuple[str, str]] = []
+    for part in args_str.split(","):
+        part = part.strip()
+        if not part:
+            continue
+        if ":" in part:
+            name, type_hint = part.split(":", 1)
+            result.append((name.strip(), type_hint.strip()))
+        else:
+            result.append((part, ""))
+    return result
+
+
+def _parse_func_args(args_str: str) -> list[tuple[str, str, str]]:
+    """Parse function arguments into ``(name, type_hint, default)`` triples.
+
+    Uses depth-aware splitting so defaults like ``Vector2(1, 2)`` are handled.
+    """
+    args_str = args_str.strip()
+    if not args_str:
+        return []
+
+    result: list[tuple[str, str, str]] = []
+    for part in _split_args_depth_aware(args_str):
+        part = part.strip()
+        if not part:
+            continue
+
+        name = part
+        type_hint = ""
+        default = ""
+
+        if "=" in part:
+            before_eq, default = part.split("=", 1)
+            default = default.strip()
+            before_eq = before_eq.strip().rstrip(":")
+            if ":" in before_eq:
+                name, type_hint = before_eq.split(":", 1)
+                name = name.strip()
+                type_hint = type_hint.strip()
+            else:
+                name = before_eq.strip()
+        elif ":" in part:
+            name, type_hint = part.split(":", 1)
+            name = name.strip()
+            type_hint = type_hint.strip()
+
+        result.append((name, type_hint, default))
+    return result
+
+
+def _count_emit_args(args_str: str) -> int:
+    """Count arguments in an ``.emit()`` call using depth-aware comma counting.
+
+    Returns 0 for empty/whitespace-only input, otherwise ``comma_count + 1``.
+    """
+    args_str = args_str.strip()
+    if not args_str:
+        return 0
+
+    count = 0
+    depth = 0
+    for ch in args_str:
+        if ch in "([{":
+            depth += 1
+        elif ch in ")]}":
+            depth -= 1
+        elif ch == "," and depth == 0:
+            count += 1
+    return count + 1
+
+
+def _parse_enum_body(body: str) -> dict[str, int | None]:
+    """Parse the body of an enum into ``{name: value}`` dict.
+
+    Entries without explicit values get ``None``.  Supports negative integers.
+    """
+    body = body.strip()
+    if not body:
+        return {}
+
+    result: dict[str, int | None] = {}
+    for part in body.split(","):
+        part = part.strip()
+        if not part:
+            continue
+        if "=" in part:
+            name, val = part.split("=", 1)
+            result[name.strip()] = int(val.strip())
+        else:
+            result[part] = None
+    return result
+
+
+# ---------------------------------------------------------------------------
+# Public API (stub — replaced in section 02)
+# ---------------------------------------------------------------------------
 
 
-def parse_gd(content: str) -> GdScript:
-    """Parse a .gd file's text content into a GdScript.
+def parse_gd(path: str, known_autoloads: list[str] | None = None) -> GdScript:
+    """Parse a .gd file into a structured GdScript representation.
 
     Args:
-        content: Raw text content of a .gd file.
+        path: Absolute or relative path to a .gd file.
+        known_autoloads: Optional list of known autoload singleton names
+                         for accurate autoload reference detection.
 
     Returns:
-        Parsed script representation.
+        Parsed GdScript dataclass with all extracted structural information.
 
     Raises:
-        NotImplementedError: Parser not yet implemented (Sprint 0 placeholder).
+        NotImplementedError: Parser not yet implemented (replaced in section 02).
     """
     raise NotImplementedError("gd parser not yet implemented")
