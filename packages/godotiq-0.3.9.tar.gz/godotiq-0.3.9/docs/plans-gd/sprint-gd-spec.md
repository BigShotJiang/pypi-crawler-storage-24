# Sprint GD: GDScript Parser

## Overview
Implement a complete GDScript (.gd) parser for GodotIQ. File: `src/godotiq/parsers/gd_parser.py`. Real .gd fixture files in `tests/fixtures/`. Package layout: `src/godotiq/`.

## Parser Requirements
The parser must extract from .gd files using regex + state machine:

### Class-Level Declarations
- `class_name` declarations
- `extends` declarations
- `enum` definitions (named and anonymous)
- `const` declarations

### Signal Definitions
- Signal declarations with typed parameters
- Support for custom types like `ProductData`, `Printer.State`

### Variable Declarations
- `@export` variables (all export hints)
- `@onready` variables
- Regular `var` declarations
- Scope tracking via indentation (class-level vs function-local)

### Function Signatures
- Parameters with types and defaults
- Return type annotations
- `static` functions
- Virtual functions (prefixed with `_`)
- Private functions (naming convention)
- `end_line` tracking for each function

### Signal Connections
All `.connect()` patterns:
- Direct: `signal.connect(method)`
- With `.bind()`: `signal.connect(method.bind(args))`
- Lambda: `signal.connect(func(): ...)`
- `$Node` references in connections

### Signal Emissions
- `.emit()` calls with argument count tracking

### Autoload References
- Direct access: `EconomyManager.method()`
- `has_node("/root/X")` pattern
- `get_tree().root.get_node_or_null()` pattern

### Other Patterns
- `is_instance_valid()` usage
- `preload()` / `load()` references

## Constraints
- Do NOT touch anything outside `gd_parser.py`
- Do NOT touch Sprint 0/1 tests
- Do NOT implement MCP tools
- Do NOT update `project_index.py`
- Success criteria: `pytest tests/ -v` → all green, including Sprint 0+1
