# Opus Review

**Model:** claude-opus-4-6
**Generated:** 2026-03-02T18:30:00Z

---

## Critical Issues (will cause incorrect behavior)

1. **Annotation buffering fails for same-line `@export var`** — Plan describes buffering annotation on one line and applying to next var line. But `@export var speed: float = 5.0` is one line (most common pattern). Buffer approach will miss ALL annotation-variable pairs.

2. **Non-const multiline values not handled** — `var session_stats: Dictionary = { ... }` spanning lines 15-24 in game_manager.gd. IN_MULTILINE_CONST only triggers for `const`, not `var`. Parser will truncate default_value.

3. **Inner class body not skipped** — No IN_INNER_CLASS state. Functions/variables inside inner classes will be added to outer class results.

4. **Inline comments corrupt default values** — `var speed: float = 5.0  # movement speed` → default_value captures `5.0  # movement speed`. Need comment stripping before regex.

5. **Function arg parsing fails on parens in defaults** — `func f(x: Vector2 = Vector2(1, 2)):` → comma-split breaks on nested parens. Need depth-aware arg splitting.

## High Priority (missing functionality)

6. **`static var` won't match variable regex** — Line starts with `static`, not `var/const`. Regex `^(var|const)` misses it.

7. **`@rpc`/`@warning_ignore` before func corrupts buffer** — Annotation buffered, then func found (not var), buffer persists and attaches to wrong var later. Only buffer `@export*` and `@onready`.

8. **`get_node("/root/X")` not detected** — Plan covers `get_node_or_null` but misses plain `get_node()` (used in game_manager.gd:117).

9. **Property getter/setter syntax unhandled** — `var health: int:` with `get:/set(value):` blocks could confuse parser.

10. **`.connect()` regex too greedy** — `(.+)\)` matches last `)` on line, not connect's closing paren.

## Medium Priority (design concerns)

11. API change from `content: str` to `path: str` should be documented. Consider private `_parse_gd_content()` for test convenience.

12. `is_virtual` and `is_private` are always identical (both check `_` prefix). Consider differentiating or removing one.

13. `end_line` computation needs to track last non-blank, non-comment line.

14. No logging (existing parsers use `logging.getLogger(__name__)`).

15. Tab-only indentation assumption may break on space-indented files.

16. Test strategy for unit tests unclear — `parse_gd(path)` requires files, inline string tests need temp files or internal content function.

17. preload inside `const` declarations: unclear if both GdVariable and GdPreloadRef are created for same line.

## Low Priority (nice-to-have)

18. Autoload boolean checks (`if EconomyManager:`) not detected by `\bNAME\.(\w+)` pattern.

19. Legacy `emit_signal("name")` pattern not detected (still valid in Godot 4.x).

20. `await signal` not tracked as signal consumption.

21. Autoload regex-per-name could use alternation for performance.

22. Multi-line function signatures not supported (document as limitation).

23. Integration test assertions should use counts/names, not line numbers.
