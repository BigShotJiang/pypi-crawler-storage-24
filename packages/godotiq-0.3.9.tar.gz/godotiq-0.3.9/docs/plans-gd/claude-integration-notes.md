# Plan Integration Notes

## Integrating (Critical fixes)

### 1. Same-line annotation handling (Issue 12)
**Integrating.** This is a real bug. In all fixture files, `@export var` and `@onready var` are on the same line. The plan must handle both same-line and separate-line annotations. Fix: parse annotation as part of the variable regex, not as a separate buffer-only step. Keep buffer as fallback for the rare separate-line case.

### 2. Multiline var values (Issue 11)
**Integrating.** Rename state to IN_MULTILINE_VALUE, trigger for both `var` and `const` with unclosed brackets.

### 3. Inner class body skipping (Issue 14)
**Integrating.** Add IN_INNER_CLASS state that tracks indent and skips all content until dedent.

### 4. Inline comment stripping (Issue 26)
**Integrating.** Add a comment-stripping pre-processing step before regex matching. Must handle `#` inside strings correctly (simple approach: don't strip if `#` is inside quotes).

### 5. Depth-aware function arg splitting (Issue 4)
**Integrating.** Use depth-aware comma splitting (like value_parser's approach) for function arguments, not naive comma split.

## Integrating (High priority)

### 6. static var detection (Issue 15)
**Integrating.** Handle `static var` and `static func` by stripping `static ` prefix and setting is_static flag before applying the main regex.

### 7. Annotation buffer scope (Issue 20)
**Integrating.** Only buffer `@export*` and `@onready` annotations. Skip `@rpc`, `@warning_ignore`, `@tool`, `@icon`, `@abstract`, `@static_unload` — they don't apply to variables.

### 8. get_node detection (Issue 8)
**Integrating.** Add `get_node("/root/X")` pattern alongside `get_node_or_null`.

### 9. .connect() regex fix (Issue 6)
**Integrating.** Use depth-aware parenthesis matching instead of greedy `(.+)\)`.

## Integrating (Medium)

### 10. Private _parse_gd_content() helper (Issue 11, 24)
**Integrating.** Add `_parse_gd_content(content: str, known_autoloads)` as internal function, `parse_gd()` is thin wrapper. This enables clean unit testing.

### 11. end_line tracking (Issue 22)
**Integrating.** Track last non-blank, non-comment line in function body for accurate end_line.

### 12. Logging (Issue 23)
**Integrating.** Add `logger = logging.getLogger(__name__)` for consistency.

### 13. Generic whitespace counting (Issue 25)
**Integrating.** Count leading whitespace chars (tabs or spaces) rather than tabs-only. GDScript standard is tabs but real files may use spaces.

### 14. Property getter/setter (Issue 19)
**Partially integrating.** Detect `var name: Type:` (trailing colon without `=`) as a property with getter/setter. Skip the body like a function. Don't decompose getter/setter internals.

## NOT Integrating

### Autoload boolean checks (Issue 18)
**Not integrating.** `if EconomyManager:` is a truthiness check, not a meaningful access pattern. The configurable autoload list approach is specifically for detecting method/property access, not existence checks. Low value.

### Legacy emit_signal() (Issue 17)
**Not integrating.** The spec explicitly targets Godot 4.x. `emit_signal()` is deprecated. Codebases still using it should migrate. Out of scope.

### await signal tracking (Issue 18)
**Not integrating.** Not in the original spec. Can be added in a future iteration without breaking the data model.

### is_virtual differentiation (Issue 21)
**Not integrating now.** Both fields start identical but serve different semantic purposes for consumers. Keeping both allows future differentiation (e.g., checking against known Godot virtuals) without API changes. The cost is one extra bool field.

### Multi-line function signatures (Issue 3)
**Not integrating.** Not present in any fixture file. Document as a known limitation. Can be added later if needed.

### @export_group standalone handling (Issue 13)
**Integrating partially.** Grouping annotations (`@export_group`, `@export_subgroup`, `@export_category`) will be recognized and discarded (not buffered). They don't attach to variables.
