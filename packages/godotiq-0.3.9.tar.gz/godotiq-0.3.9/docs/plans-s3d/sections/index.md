<!-- PROJECT_CONFIG
runtime: python-uv
test_command: pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-fixtures
section-02-extraction-helpers
section-03-animation-info-tool
section-04-animation-audit-tool
section-05-server-registration
section-06-tests-animation-info
section-07-tests-animation-audit
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-fixtures | - | 02, 03, 04, 05, 06, 07 | Yes |
| section-02-extraction-helpers | 01 | 03, 04, 06, 07 | No |
| section-03-animation-info-tool | 02 | 06 | Yes |
| section-04-animation-audit-tool | 02 | 07 | Yes |
| section-05-server-registration | 02 | 06, 07 | Yes |
| section-06-tests-animation-info | 03, 05 | - | Yes |
| section-07-tests-animation-audit | 04, 05 | - | Yes |

## Execution Order

1. section-01-fixtures (no dependencies)
2. section-02-extraction-helpers (after 01)
3. section-03-animation-info-tool, section-04-animation-audit-tool, section-05-server-registration (parallel after 02)
4. section-06-tests-animation-info, section-07-tests-animation-audit (parallel after 03+05 / 04+05)

## Section Summaries

### section-01-fixtures
Create `tests/fixtures/anim_project/` with all .tscn scenes, .gd scripts, and project.godot. Add `anim_root` and `anim_session` fixtures to conftest.py.

### section-02-extraction-helpers
Implement `_strip_string_name()`, `_extract_tscn_animations()`, `_extract_animation_libraries()`, `_extract_animation_players()`, `_extract_animation_trees()`, `_extract_code_animations()` in `src/godotiq/tools/animation/__init__.py`.

### section-03-animation-info-tool
Implement `_build_animation_info()` aggregate function and `godotiq_animation_info` MCP tool with brief/normal/full detail levels and node filtering.

### section-04-animation-audit-tool
Implement `_build_animation_audit()` and `godotiq_animation_audit` MCP tool with 7 check types across critical/warning/info severities.

### section-05-server-registration
Add `from godotiq.tools import animation` import to `src/godotiq/server.py`.

### section-06-tests-animation-info
12 tests in `tests/test_tools/test_animation_info.py` covering inline animations, code detection, AnimationTree, detail levels, node filtering, and edge cases.

### section-07-tests-animation-audit
10 tests in `tests/test_tools/test_animation_audit.py` covering all 7 audit check types, scope modes, severity ordering, and issue cap.
