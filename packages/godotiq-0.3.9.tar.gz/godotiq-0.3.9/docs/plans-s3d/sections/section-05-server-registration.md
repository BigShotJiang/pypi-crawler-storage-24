Now I have everything needed. Let me produce the section content.

# Section 05: MCP Server Registration

## Overview

This section wires the animation tools module into the GodotIQ MCP server. The animation module (`src/godotiq/tools/animation/__init__.py`) defines its tools using `@mcp.tool()` decorators (implemented in sections 03 and 04). For those decorators to execute and register the tools with the FastMCP server instance, the module must be imported at server startup. This section adds that import to `src/godotiq/server.py`, following the exact same pattern used by the existing `memory`, `code`, `spatial`, and `assets` tool modules.

## Dependencies

- **Section 02 (Extraction Helpers):** The animation module file `src/godotiq/tools/animation/__init__.py` must exist and be importable. At minimum it needs a valid Python module with the `from godotiq.server import mcp` import so the circular import chain resolves correctly.
- **Sections 03 and 04 (animation_info and animation_audit tools):** The `@mcp.tool()` decorated functions must be defined in the animation module for the registration to have any effect. However, the import itself will succeed even if those tools are not yet defined -- it just will not register any tools.

## Tests

Write these tests before making the implementation changes. They verify that the animation module is importable and that both tools end up registered on the MCP server instance.

**File:** `tests/test_tools/test_animation_registration.py` (or inline within existing test files -- see note below)

```python
"""Tests for animation tool server registration."""


def test_import_animation_module():
    """Importing godotiq.tools.animation should not raise."""
    import godotiq.tools.animation  # noqa: F401


def test_mcp_has_animation_info_tool():
    """The mcp server instance should have godotiq_animation_info registered."""
    from godotiq.server import mcp

    tool_names = [t.name for t in mcp._tool_manager.list_tools()]
    assert "godotiq_animation_info" in tool_names


def test_mcp_has_animation_audit_tool():
    """The mcp server instance should have godotiq_animation_audit registered."""
    from godotiq.server import mcp

    tool_names = [t.name for t in mcp._tool_manager.list_tools()]
    assert "godotiq_animation_audit" in tool_names
```

**Note on test placement:** These three tests can alternatively be placed at the top of `tests/test_tools/test_animation_info.py` (section 06) and `tests/test_tools/test_animation_audit.py` (section 07) if a separate file is not desired. The important thing is that they exist and run. If the `_tool_manager` attribute path differs in the installed version of FastMCP, the alternative approach is:

```python
def test_mcp_has_animation_info_tool():
    """The mcp server instance should have godotiq_animation_info registered."""
    from godotiq.server import mcp

    # FastMCP stores tools internally; check via the public list
    tools = mcp.list_tools()
    names = [t.name for t in tools]
    assert "godotiq_animation_info" in names
```

The implementer should verify which attribute or method is available on the FastMCP instance by checking how existing tests (e.g., in `tests/test_tools/`) introspect registered tools, and use the same approach.

## Implementation Details

### File to Modify: `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/server.py`

Add a single import line for the animation module in the "Tool imports" block at the bottom of the file, after the existing tool imports. The current state of that block is:

```python
# Tool imports — each module registers tools on the mcp instance
from godotiq.tools import memory  # noqa: E402, F401
from godotiq.tools import code  # noqa: E402, F401
from godotiq.tools import spatial  # noqa: E402, F401
from godotiq.tools import assets  # noqa: E402, F401
```

Add this line at the end of that block:

```python
from godotiq.tools import animation  # noqa: E402, F401
```

The `noqa: E402` suppresses the "module level import not at top of file" warning (these imports intentionally come after the `mcp = FastMCP(...)` instantiation so that the tool modules can import `mcp` from `godotiq.server` without circular import issues). The `noqa: F401` suppresses the "imported but unused" warning since the import is used purely for its side effect of registering tools.

### File to Modify: `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/animation/__init__.py`

The animation module must import the `mcp` instance from `godotiq.server` so that the `@mcp.tool()` decorators bind to the correct server. The current content is just a docstring placeholder:

```python
"""Animation Intelligence tools — state machines, timelines."""
```

The module needs at minimum these imports to support tool registration (the actual tool functions are implemented in sections 03 and 04, but the imports must be present):

```python
"""Animation Intelligence tools — state machines, timelines."""

from __future__ import annotations

from mcp.server.fastmcp import Context

from godotiq.server import mcp
from godotiq.session import GodotIQSession
```

This follows the exact same pattern used by every other tool module in the project (`code`, `spatial`, `assets`, `memory`). The `Context` import is needed by the `@mcp.tool()` decorated functions that will be defined in this module by sections 03 and 04. The `GodotIQSession` import is needed by the `_build_*` helper functions.

### Circular Import Resolution

The import chain works because of deliberate ordering in `server.py`:

1. `server.py` defines `mcp = FastMCP(...)` at module level
2. Tool imports (`from godotiq.tools import animation`) happen AFTER `mcp` is defined
3. The animation module does `from godotiq.server import mcp` which resolves because `mcp` already exists in `server.py`'s namespace by the time the tool module import executes

This is the same pattern used by all existing tool modules and is safe as long as the tool imports remain at the bottom of `server.py`, after the `mcp` instantiation.

## Verification

After making the changes, run these quick checks:

1. **Smoke test** -- verify the import chain works without errors:
   ```bash
   python -c "from godotiq.server import mcp; print('OK')"
   ```

2. **Run the registration tests:**
   ```bash
   pytest tests/test_tools/test_animation_registration.py -v
   ```
   (These will only pass fully once sections 03 and 04 are also implemented. The `test_import_animation_module` test will pass immediately after this section is complete.)

3. **Existing tests still pass** -- the new import must not break anything:
   ```bash
   pytest -v
   ```

## Summary of Changes

| File | Change |
|------|--------|
| `src/godotiq/server.py` | Added `from godotiq.tools import animation  # noqa: E402, F401` to the tool imports block |
| `tests/test_tools/test_animation_registration.py` | New file with 3 tests verifying import and tool registration |

## Implementation Notes

- **`animation/__init__.py` not modified**: The animation module already had `from godotiq.server import mcp` (added in section 03, line 680) along with all required imports. No changes needed.
- **Used `await mcp.list_tools()` (public API)** instead of `mcp._tool_manager.list_tools()` (private API) — matches existing test patterns in `test_server.py` and `test_server_integration.py`.
- **Test structure**: Used class grouping (`TestAnimationToolRegistration`) for the two async registration tests + standalone function for the import test. Matches existing patterns.
- **Code review fixes applied**: Added `from __future__ import annotations` and docstrings to async test methods for convention consistency.
- **All 399 tests pass** after changes.