# Section 06: Test Suite — animation_info (12 tests)

## Overview

12 integration tests for `godotiq_animation_info` tool covering all detail levels, node filtering, code animation detection, AnimationTree support, and error handling.

## File Created

- `tests/test_tools/test_animation_info.py` — 12 tests, all using `_build_animation_info` helper directly (consistent with project pattern).

## Tests Implemented

| # | Test | Validates |
|---|------|-----------|
| 1 | test_animation_info_inline_scene | 4 animations, metadata, normal detail excludes track_paths |
| 2 | test_animation_info_detail_brief | Names only, no track_count/length, count=4 |
| 3 | test_animation_info_detail_full | Includes track_paths |
| 4 | test_animation_info_code_animations | play_calls, anim_maps, looping_lists from character.gd |
| 5 | test_animation_info_code_only_glb | NlaTrack entries from glb_animated_entity.gd |
| 6 | test_animation_info_animation_tree | 2 states, 2 transitions from state machine |
| 7 | test_animation_info_no_animations | Empty results, zero counts |
| 8 | test_animation_info_node_filter | Correct player selected |
| 9 | test_animation_info_node_filter_not_found | Error with alternatives list |
| 10 | test_animation_info_summary_counts | Exact counts: 5 total, 4 inline, 1 code_only |
| 11 | test_animation_info_missing_scene | Error dict with scene path echo |
| 12 | test_animation_info_code_play_detection | Unit test: play/queue/travel/StringName detection |

## Code Review Fixes Applied

- Tightened `>=` to exact `==` assertions in summary counts
- Added `len(anims) == 4` in brief detail test
- Added scene path echo assertion in missing scene test
- Added normal detail excludes track_paths assertion

## Result

All 12 tests pass. Full suite: 411 tests pass.