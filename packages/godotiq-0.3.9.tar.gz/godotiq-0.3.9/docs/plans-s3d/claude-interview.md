# Sprint 3d — Interview Transcript

## Q1: AnimationNodeStateMachine fixture format
**Question:** Research found that AnimationNodeStateMachine transitions serialize as a flat array (`transitions = ["idle", "walk", SubResource(...), ...]`) not as indexed properties (`transitions/0/from`). The spec fixtures use the indexed format. Should I correct the fixtures to match the real Godot format, or keep the spec format since we control the fixture?

**Answer:** Correct to real Godot format. Use the actual engine serialization format so our parser handles real-world .tscn files.

## Q2: .tres animation resource parsing scope
**Question:** The spec mentions Source 3 (.tres animation resources). Your test project (PFT) had zero inline animations. How important is .tres resource parsing for Sprint 3d?

**Answer:** Include .tres parsing. Parse standalone .tres Animation files found in session._index.assets.

## Q3: Code animation regex detection aggressiveness
**Question:** For the `_extract_code_animations` regex scanning: should animation dict detection be aggressive or conservative?

**Answer:** Aggressive. Match any dict/array whose var name contains anim, animation, motion, clip (case-insensitive).

## Q4: Broken track validation scope
**Question:** For animation_audit `broken_track` check: validate against full resolved scene tree or immediate scene nodes only?

**Answer:** Immediate scene nodes only. Check against nodes in the same .tscn file — simpler, avoids resolver dependency.

## Q5: Test fixture organization
**Question:** Animation fixture files go in `tests/fixtures/` directly or in a subdirectory?

**Answer:** Separate `anim_project/` — new self-contained project in `tests/fixtures/anim_project/` with project.godot.
