# Sprint 3d — TDD Plan

Testing framework: pytest with pytest-asyncio, asyncio_mode="auto". Tests import private `_build_*` helpers directly. Session fixtures from conftest.py.

---

## Section 1: Test Fixtures

No tests needed — fixtures are data files. Validate by loading them with `parse_tscn()` in a smoke test.

```python
# Test: parse_tscn on each fixture file does not raise
# Test: animated_character.tscn has sub_resources of type Animation
# Test: animated_scene_tree.tscn has sub_resources of type AnimationNodeStateMachine
```

---

## Section 2: Animation Extraction Helpers

### _strip_string_name
```python
# Test: &"idle" → "idle"
# Test: "idle" → "idle" (passthrough)
# Test: non-string input → returned as-is
```

### _extract_tscn_animations
```python
# Test: animated_character.tscn → 4 animations with correct names
# Test: "idle" has length=2.0, loop_mode="linear", track_count=4, all "value" type
# Test: "walk" has 3 value + 1 method track
# Test: "attack" has track_paths including "NonExistent:position"
# Test: no_animation_scene.tscn → empty list
```

### _extract_animation_libraries
```python
# Test: animated_character.tscn → 1 library with 4 animation refs
# Test: library maps "idle" to "Animation_idle" sub_resource id
```

### _extract_animation_players
```python
# Test: animated_character.tscn → 1 player named "AnimationPlayer"
# Test: player has library_refs with default ("") key
# Test: no_animation_scene.tscn → empty list
```

### _extract_animation_trees
```python
# Test: animated_scene_tree.tscn → 1 tree with 2 states (idle, walk)
# Test: tree has 2 transitions (idle→walk, walk→idle)
# Test: animation_refs includes "idle" and "walk"
```

### _extract_code_animations
```python
# Test: character.gd content → play_calls includes "idle", "attack", "special_move"
# Test: character.gd → anim_maps with ANIM_MAP having 4 entries
# Test: character.gd → looping_lists with LOOPING_ANIMS having 2 entries
# Test: glb_animated_entity.gd → anim_maps with NlaTrack values
# Test: .play(&"name") → detected correctly (StringName syntax)
# Test: .queue("name") → included in play_calls
# Test: empty script → all empty lists, no crashes
```

---

## Section 3: Tool D01 — animation_info

Tests defined in Section 6 of the plan. Write these BEFORE implementing the tool:
```python
# Test: inline scene → animation_players populated with correct animation metadata
# Test: brief detail → only summary and names
# Test: full detail → includes track_paths
# Test: code_animations → play_calls, anim_maps, looping_lists populated
# Test: code-only GLB → code_animations with NlaTrack mapping
# Test: AnimationTree → states and transitions populated
# Test: no animations → empty results, summary all zeros
# Test: node filter match → filtered output
# Test: node filter miss → error with alternatives
# Test: summary counts unique across sources
# Test: missing scene → error
# Test: _extract_code_animations unit test
```

---

## Section 4: Tool D02 — animation_audit

Tests defined in Section 7 of the plan. Write these BEFORE implementing the tool:
```python
# Test: broken_track → critical severity for NonExistent:position
# Test: orphan_animation → warning for unused animation
# Test: missing_animation → warning for .play() of non-existent animation
# Test: no_loop_suspect → info for short idle-like non-looping animation
# Test: empty_player → warning for player with no animations
# Test: code_only → info severity
# Test: scope all → scans all scenes
# Test: scope scene → scans single scene
# Test: severity ordering → critical before warning before info
# Test: issue cap → max 50, critical preserved
```

---

## Section 5: MCP Server Registration

```python
# Test: import godotiq.tools.animation does not raise
# Test: mcp server has godotiq_animation_info tool registered
# Test: mcp server has godotiq_animation_audit tool registered
```

---

## Sections 6 & 7: Test Suites

These ARE the tests. TDD says write them first, implement until green. The test files themselves are the deliverables for these sections — no additional TDD stubs needed.
