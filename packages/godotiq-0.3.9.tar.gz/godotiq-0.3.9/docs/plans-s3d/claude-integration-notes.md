# Integration Notes — Opus Review

## Integrating

1. **`_data` dual format** — YES. Add type check: if dict, iterate directly; if string, regex parse.
2. **`_strip_string_name()` utility** — YES. Create shared helper, use in all extraction functions.
3. **Transitions array typed elements** — YES. Specify that from/to are strings (strip &"..."), transition is dict with .get("id").
4. **.tres parsing** — YES. Add basic .tres file scanning using raw text regex (same Animation sub_resource format). No parser modification needed.
5. **Missing fixtures for empty_player and no_loop_suspect** — YES. Add `empty_player_scene.tscn` fixture and an `idle_ground` animation with loop_mode=0.
6. **Broken track multi-segment paths** — YES. Split on "/" to get first segment, check against scene nodes.
7. **`.queue()` detection** — YES. Add `QUEUE_RE` pattern.
8. **`.play(&"name")` StringName** — YES. Update PLAY_RE to handle `&"name"` variant.
9. **AnimationTree animations not orphans** — YES. Exclude animation names referenced by AnimationTree states from orphan check.
10. **`tree_root`/`libraries` as parsed dicts** — YES. Use `.get("id")` on dict values instead of regex on strings.
11. **conftest anim_session fixture** — YES. Add to existing conftest.py.
12. **`:=` and `=` in regex** — YES. Update pattern to match both.

## NOT Integrating

- Nothing rejected. All feedback is actionable and correct.
