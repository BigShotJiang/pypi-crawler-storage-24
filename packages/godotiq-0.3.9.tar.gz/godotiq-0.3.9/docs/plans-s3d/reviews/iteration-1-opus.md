# Opus Review

**Model:** claude-opus-4
**Generated:** 2026-03-03T16:10:00Z

---

## Critical Issues

1. **`_data` property dual format**: TSCN parser stores `_data` as raw string (multiline) OR parsed dict (single-line). Plan Section 2.2 only handles raw string regex. Must handle both.

2. **`&"name"` StringName syntax**: Need shared `_strip_string_name()` utility used consistently across all helpers (2.1, 2.4, 2.5).

3. **Transitions array element types**: Parsed list contains mix of raw strings (`&"idle"`) and dicts (`{"type": "sub_resource", "id": ...}`). Plan under-specifies handling.

4. **.tres parsing gap**: Spec promises .tres support, plan has no helper for it. Need to address or descope.

## Significant Issues

5. Missing fixture data for `test_audit_empty_player` and `test_audit_no_loop_suspect` tests.
6. Broken track validation needs clarification for multi-segment paths like `Parent/Child:property`.
7. Missing `.queue()` call detection in regex patterns.
8. `.play(&"name")` with StringName syntax not handled by play regex.
9. AnimationTree-referenced animations should NOT be flagged as orphans.
10. `tree_root` and `libraries` property values are parsed dicts, not raw strings.

## Minor Issues

11. Need `anim_session` fixture in conftest.
12. Handle both `:=` and `=` in animation dict/array regex.
13. `anim_player` NodePath property stored as plain string after parsing.
