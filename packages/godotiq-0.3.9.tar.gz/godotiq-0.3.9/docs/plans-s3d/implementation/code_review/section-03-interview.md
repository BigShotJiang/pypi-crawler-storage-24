# Section 03 Code Review Interview

## User Decision: Fix Both Issues
User chose to fix both substantive issues from review.

## Applied Fixes

### Fix 1: Issue 5 — Add variable names to merged code_animations
- Added `anim_player_vars` and `anim_tree_vars` to `_merge_code_animations`
- Status: Applied

### Fix 2: Issue 6 — Fix false positive "code" source
- Changed `_determine_sources` to check for actual animation references (play_calls, travel_calls, anim_maps)
- Status: Applied

### Fix 3: Issues 7-8 — Consistent counts with node filter
- `inline_count` now counts from filtered player list, not unfiltered summary
- `code_only_count` set to 0 when node filter is active
- Status: Applied

### Fix 4: Issue 9 — Always include code_animations key
- `code_animations` now always present (empty dict when no scripts)
- Status: Applied

## Let Go (pattern-consistent, low impact)
- Issue 1: Server registration — handled by Section 5
- Issue 2: detail validation — pattern-consistent
- Issue 3: ctx None guard — pattern-consistent
- Issue 4: animation_count redundancy — minor, useful for quick access
- Issue 10: Mid-file import — pattern-consistent
- Issue 11: No-script edge case — correctly handled
