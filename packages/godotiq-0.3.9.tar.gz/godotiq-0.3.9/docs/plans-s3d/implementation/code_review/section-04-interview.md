# Section 04 Code Review Interview

## User Decision: Fix orphan_tree_state linking
User chose to fix tree→player linking to use specific AnimationPlayer.

## Applied Fixes

### Fix 1: Issue 1 — Add travel_calls to referenced sets
- Added `all_travel_calls` collection and included in `all_referenced`
- Ensures .travel() targets count as references for orphan detection
- Status: Applied

### Fix 2: Issue 3 — Error on scope='scene' without scene parameter
- Changed conditional to error early when scene_filter is None with scope='scene'
- Status: Applied

### Fix 3: Issue 5 — Link orphan_tree_state to specific AnimationPlayer
- Resolve `anim_player_path` to find linked player by name
- Falls back to all players if linked player not found
- Status: Applied

### Fix 4: Issue 7 — Deduplicate code_only vs missing_animation
- Skip code_only_animations for names already flagged as missing_animation
- Status: Applied

## Let Go
- Issue 2: by_severity from truncated list is fine (total_issues exists)
- Issue 4: code_anims vs script_paths guard — minor edge case
- Issue 6: GLB heuristic — nlatrack primary check sufficient
- Issues 8, 9, 10: Low impact or by design
