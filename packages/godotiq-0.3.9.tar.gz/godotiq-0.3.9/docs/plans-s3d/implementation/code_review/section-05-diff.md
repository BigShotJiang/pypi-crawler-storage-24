diff --git a/src/godotiq/server.py b/src/godotiq/server.py
index fe7b90b..38992cd 100644
--- a/src/godotiq/server.py
+++ b/src/godotiq/server.py
@@ -50,6 +50,7 @@ from godotiq.tools import memory  # noqa: E402, F401
 from godotiq.tools import code  # noqa: E402, F401
 from godotiq.tools import spatial  # noqa: E402, F401
 from godotiq.tools import assets  # noqa: E402, F401
+from godotiq.tools import animation  # noqa: E402, F401
 
 
 def main() -> None:
diff --git a/tests/test_tools/test_animation_registration.py b/tests/test_tools/test_animation_registration.py
new file mode 100644
index 0000000..776bb02
--- /dev/null
+++ b/tests/test_tools/test_animation_registration.py
@@ -0,0 +1,26 @@
+"""Tests for animation tool server registration."""
+
+import pytest
+
+from godotiq.server import mcp
+
+
+def test_import_animation_module():
+    """Importing godotiq.tools.animation should not raise."""
+    import godotiq.tools.animation  # noqa: F401
+
+
+class TestAnimationToolRegistration:
+    """Verify animation tools are registered on the MCP server."""
+
+    @pytest.mark.asyncio
+    async def test_mcp_has_animation_info_tool(self) -> None:
+        tools = await mcp.list_tools()
+        tool_names = [t.name for t in tools]
+        assert "godotiq_animation_info" in tool_names
+
+    @pytest.mark.asyncio
+    async def test_mcp_has_animation_audit_tool(self) -> None:
+        tools = await mcp.list_tools()
+        tool_names = [t.name for t in tools]
+        assert "godotiq_animation_audit" in tool_names
