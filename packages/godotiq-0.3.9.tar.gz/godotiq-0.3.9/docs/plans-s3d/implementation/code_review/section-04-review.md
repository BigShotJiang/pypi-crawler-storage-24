# Section 04 Code Review

## High Severity
1. `travel_calls` not included in `all_play_calls` or `all_referenced` — orphan/missing checks miss .travel() calls
2. `by_severity` counts only truncated list, not original totals
3. `scope='scene'` with no scene silently scans all — should error

## Medium Severity
4. `orphan_animation` guard uses `code_anims` not `script_paths` — inconsistent with _build_animation_summary
5. `orphan_tree_state` checks ALL players, not just linked player
6. GLB detection via 'nla' substring is overly broad
7. `code_only_animations` may duplicate `missing_animation` for same animation

## Low Severity
8. No input validation on `scope` parameter
9. Broken track only validates first path segment (by plan design)
10. Tests in separate section (by plan design)
