# Section 07 Code Review: tests-animation-audit

## Issues Found

### CRITICAL: Missing orphan_tree_state coverage (Check 7 of 7)
No test for `orphan_tree_state` check type. Implementation lines 907-942 are untested.

### HIGH: TestAuditCodeOnly is a no-op (if-guard)
The `if code_only:` guard means test passes even when `code_only` is empty. The `glb_entity.tscn` has no AnimationPlayer, so the check is skipped entirely.

### HIGH: Issue cap test doesn't test the cap
Never generates >50 issues. Truncation logic (lines 948-964) untested.

### MEDIUM: Loose assertions using >= instead of ==
broken_track count, scenes_scanned, animated_scenes, total_animations all use >= on deterministic fixtures.

### MEDIUM: No test for clean scene (zero issues)
No negative test for `no_animation_scene.tscn` → zero issues.

### MEDIUM: No test for truncated flag presence/absence

### LOW: missing_animation test doesn't verify severity
Should assert `severity == "warning"` for `special_move`.

### LOW: Unused pytest import

### LOW: No unit-level test for sorting/truncation logic
