# Section 02 Code Review

## Critical Issues
1. _RE_LIB_DATA regex too restrictive (\w+ vs [^"]+) for animation names with hyphens
2. _RE_STATE_NODE regex too restrictive (\w+ vs [^/]+) for state names with hyphens
3. _collect_balanced counts braces inside string literals (naive approach)
4. No tests for _build_animation_summary
5. _build_animation_summary doesn't include looping_list entries in referenced_names

## Minor Issues
6. session typed as `object` instead of GodotIQSession
7. Error handling swallows AttributeError too broadly, no logging
8. _strip_string_name doesn't strip surrounding quotes from clean strings
9. play() with variable arguments not flagged
10. _RE_DICT_DECL/_RE_ARRAY_DECL can match inside comments
