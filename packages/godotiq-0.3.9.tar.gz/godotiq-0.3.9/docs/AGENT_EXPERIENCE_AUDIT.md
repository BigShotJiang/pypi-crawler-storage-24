# GodotIQ Agent Experience Audit

**Date:** 2026-03-18
**Scope:** Prompt accuracy, tool inventory, explore tool, workflow gaps, token efficiency
**Status:** Findings only — no fixes implemented

---

## 1. PROMPT REVIEW — `src/godotiq/prompts/godot_development.md`

### 1.1 Tool Count Mismatch

| Location | Says | Actual |
|----------|------|--------|
| Line 228 — Community vs Pro section | "Pro ($19 one-time, all **35** tools)" | **36** tools registered (`@mcp.tool()` count across 8 files) |
| Line 228 — Community vs Pro section | "Community (free, **22** tools)" | 36 − 14 PRO = **22** ✅ correct |
| `license.py` comment line 33 | "14 PRO tools" | **14** in `PRO_TOOLS` frozenset ✅ correct |

**Root cause:** `godotiq_ping` (registered in `server.py`) is not listed in the Tool Reference section and was not counted when the "35 tools" figure was written. Adding `godotiq_explore` brought the total to 36, but the prompt was updated to only reflect explore (35 → still says 35, should be 36).

**Recommendation:** Update to "all 36 tools" and add `godotiq_ping` to the Tool Reference.

### 1.2 Critical Contradiction: "You CANNOT see screenshots" vs Explore Workflow

**Lines 34-37 (Section: "You CANNOT see screenshots"):**
> You receive screenshot data as base64 but you CANNOT interpret it visually. Do not pretend you can see what's in a screenshot.

**Lines 436-438 (Mandatory Workflow 4: Visual QA):**
> `godotiq_explore(mode="tour")` → autonomous visual inspection
> → Analyze each screenshot: describe what you see, note issues

These directly contradict each other. The "CANNOT see" rule was written pre-explore as a hallucination guard. The explore workflow assumes the model uses its multimodal vision on the returned images.

**Recommendation:** Refactor the "CANNOT see" section to distinguish between:
- **Single screenshots** (screenshot tool): Still ask the user to interpret, because the agent has no scene context and may hallucinate details.
- **Explore tour screenshots**: The agent should describe what it observes, because explore provides structured context (area positions, node counts, camera angles) that anchors visual interpretation.

### 1.3 Explore Tool Missing from Community vs Pro Fallback Table

The "Free Fallbacks for Each Pro Tool" table (lines 259-273) lists 13 tools but omits `godotiq_explore`. Community users calling explore get cluster analysis without screenshots (per `_preview_explore` in `license.py`), but the prompt doesn't tell the agent what to do with that data or how to fall back.

**Recommendation:** Add a row:

| Pro Tool | What It Does | Free Fallback | What You Lose |
|----------|-------------|---------------|---------------|
| `explore` | Autonomous visual inspection | `screenshot` (editor viewport) + `scene_map` for spatial layout | Automated camera positioning, multi-area tour, cluster analysis |

### 1.4 Mandatory Workflows — Minor Issues

- **Workflow 2** (line 413): Shows `godotiq_impact_check(file, action, target)` — correct, but `action` and `target` are easy to confuse. The actual valid `action` values (`"modify_function"`, `"rename_signal"`, `"add_parameter"`, `"remove_function"`, `"change_return_type"`, `"rename_class"`) are not mentioned anywhere in the prompt.
- **Workflow 4** (line 436): Says "Analyze each screenshot" but gives no guidance on what specifically to look for or how to report findings. The tool reference (line 534) does mention specifics ("lighting issues, geometry gaps, floating objects…") but this is 100 lines away from the workflow.
- **Workflow 6** (Mandatory Final QA, line 152): Does not mention `godotiq_explore` as part of the QA checklist. Explore should be step 0 or step 6b — a visual sweep before the code-level checks.

### 1.5 Error Recovery Gaps

The Error Recovery section (lines 577-588) covers 8 error codes but is missing:

| Error | When | Recovery |
|-------|------|----------|
| Explore timeout | Tour captures too many areas | Reduce `max_areas` or `screenshots_per_area` |
| Explore with game stopped | Explore called but game crashed mid-tour | Drone camera leaks — call `run(action="stop")` then `run(action="play")` and retry |
| Bridge error during explore | Connection dropped mid-capture | Explore returns partial results — check `total_screenshots` vs `total_positions_calculated` |
| `OUTPUT_TOO_LARGE` | Any tool returning massive data | Use `detail="brief"`, add `path_filter`, reduce scope |

### 1.6 `godotiq_ping` Undocumented

`godotiq_ping` is registered but absent from:
- The Tool Reference section
- The Mandatory Workflows (should be a fallback health check)
- The Community vs Pro section (returns license tier info — useful for agents to self-discover)

---

## 2. TOOL INVENTORY — Verified Registration

### 2.1 Complete Tool List (36 tools)

**UNDERSTAND — Analysis (15 tools, 12 PRO-gated):**

| # | Tool | Module | PRO | Notes |
|---|------|--------|-----|-------|
| 1 | `godotiq_project_summary` | memory | ✅ | |
| 2 | `godotiq_file_context` | memory | ✅ | |
| 3 | `godotiq_scene_map` | spatial | ✅ | |
| 4 | `godotiq_dependency_graph` | code | ✅ | |
| 5 | `godotiq_signal_map` | code | ✅ | |
| 6 | `godotiq_impact_check` | code | ✅ | |
| 7 | `godotiq_validate` | code | ✅ | |
| 8 | `godotiq_trace_flow` | flow | ✅ | |
| 9 | `godotiq_spatial_audit` | spatial | ✅ | |
| 10 | `godotiq_check_errors` | bridge | ❌ | |
| 11 | `godotiq_asset_registry` | assets | ✅ | |
| 12 | `godotiq_suggest_scale` | spatial | ✅ | |
| 13 | `godotiq_placement` | spatial | ✅ | |
| 14 | `godotiq_animation_info` | animation | ❌ | |
| 15 | `godotiq_animation_audit` | animation | ✅ | |

**EDIT — Scene & Script Modification (8 tools, 0 PRO-gated):**

| # | Tool | Module | PRO | Notes |
|---|------|--------|-----|-------|
| 16 | `godotiq_scene_tree` | bridge | ❌ | |
| 17 | `godotiq_node_ops` | bridge | ❌ | |
| 18 | `godotiq_build_scene` | bridge | ❌ | |
| 19 | `godotiq_script_ops` | bridge | ❌ | |
| 20 | `godotiq_file_ops` | bridge | ❌ | |
| 21 | `godotiq_save_scene` | bridge | ❌ | |
| 22 | `godotiq_undo_history` | bridge | ❌ | |
| 23 | `godotiq_editor_context` | bridge | ❌ | |

**PLAY & DEBUG — Runtime (12 tools, 1 PRO-gated):**

| # | Tool | Module | PRO | Notes |
|---|------|--------|-----|-------|
| 24 | `godotiq_run` | bridge | ❌ | |
| 25 | `godotiq_state_inspect` | bridge | ❌ | |
| 26 | `godotiq_verify_motion` | bridge | ❌ | |
| 27 | `godotiq_screenshot` | bridge | ❌ | |
| 28 | `godotiq_explore` | bridge | ✅ | |
| 29 | `godotiq_perf_snapshot` | bridge | ❌ | |
| 30 | `godotiq_ui_map` | bridge | ❌ | |
| 31 | `godotiq_input` | bridge | ❌ | |
| 32 | `godotiq_exec` | bridge | ❌ | |
| 33 | `godotiq_nav_query` | bridge | ❌ | |
| 34 | `godotiq_watch` | bridge | ❌ | |
| 35 | `godotiq_camera` | bridge | ❌ | |

**UTILITY (1 tool):**

| # | Tool | Module | PRO | Notes |
|---|------|--------|-----|-------|
| 36 | `godotiq_ping` | server | ❌ | Not in prompt Tool Reference |

### 2.2 Docstring Quality Assessment

**Strong docstrings** (clear purpose, actionable, tells agent when to use):
- `godotiq_state_inspect` — "CHEAPER than screenshots for checking state — use this first"
- `godotiq_exec` — "Last resort — prefer dedicated tools"
- `godotiq_node_ops` — "ALWAYS add validate:true for spatial operations"
- `godotiq_scene_tree` — "Unlike scene_map (reads .tscn from disk), this reads the editor's live state"

**Weak docstrings** (could confuse the agent):
- `godotiq_screenshot` — Says "Prefer state_inspect for data" but doesn't say what screenshot IS useful for beyond "visual confirmation." An agent needs to know: use it to show the user what the game looks like.
- `godotiq_watch` — Doesn't explain when to prefer watch over repeated state_inspect. The prompt covers this nowhere.
- `godotiq_camera` — Only says "Editor 3D camera control." Doesn't say why an agent would need this instead of just using explore or screenshot with camera_position.
- `godotiq_perf_snapshot` — Doesn't say what thresholds are concerning (e.g., < 30 FPS, > 1000 draw calls).

### 2.3 Potential Name Confusion

| Pair | Confusion Risk | Resolution |
|------|---------------|------------|
| `scene_map` vs `scene_tree` | HIGH — agent may call wrong one | `scene_map` = file parse (.tscn), `scene_tree` = live editor state. Docstrings explain this, but the prompt should have a comparison note. |
| `validate` vs `check_errors` | MEDIUM — both "check code" | `validate` = conventions (PRO), `check_errors` = compilation (free). Different scope. |
| `file_context` vs `file_ops(op="read")` | LOW | Different purposes — file_context analyzes, file_ops reads raw content. |
| `camera` vs explore camera | MEDIUM | `camera` = editor viewport, `explore` = game viewport drone. Prompt doesn't clarify this distinction. |
| `screenshot` vs `explore` | MEDIUM — both capture images | `screenshot` = single shot, `explore` = automated multi-shot tour. Prompt workflow 4 helps here. |

---

## 3. EXPLORE TOOL IMPROVEMENTS

### 3.1 Context Limit Risk (Critical)

**The dungeon test problem:** 20 screenshots at 197K characters exceeded the context window.

**Current protections:**
- `screenshots_per_area` default = 1 ✅ (already fixed)
- Warning threshold at > 25 positions ⚠️ (too high — 5 screenshots can already be 50K+ chars)
- No output size estimation before capture
- No automatic quality/scale reduction
- No `apply_output_limit` call (explore bypasses the output limit system used by other tools)

**What's missing:**

1. **Pre-capture size estimation** — Before starting the tour, estimate total output: `num_positions × avg_screenshot_bytes_at_scale_quality`. If estimated output > threshold (e.g., 80K chars), auto-reduce scale/quality or warn.

2. **Progressive capture with budget** — Set a character budget (e.g., 100K chars). After each screenshot, check running total. Stop early if budget exceeded and return partial results with a `"truncated": true` flag.

3. **Image reference mode** — For large tours, return image file paths instead of inline base64. The agent can then selectively load individual screenshots with `file_ops(op="read")`. This would require saving screenshots to a temp directory.

4. **Output limit integration** — The explore tool does not call `apply_output_limit()` like other tools. It should respect the `detail` parameter:
   - `detail="brief"`: cluster analysis only, no screenshots
   - `detail="normal"`: screenshots at reduced quality
   - `detail="full"`: full quality screenshots

### 3.2 Default Parameters Assessment

| Parameter | Default | Assessment |
|-----------|---------|------------|
| `screenshots_per_area` | 1 | ✅ Correct — overview only |
| `max_areas` | 5 | ⚠️ Could be 3 for safety — 5 areas at scale=0.5 can be 50K+ chars |
| `scale` | 0.5 | ⚠️ Higher than `screenshot` default (0.25). Consider 0.3 |
| `quality` | 0.6 | ⚠️ Higher than `screenshot` default (0.5). Consider 0.4 |
| `fov` | 70 | ✅ Standard |
| `eye_height` | 2.5 | ✅ Standard |

**Observation:** Explore's defaults (`scale=0.5, quality=0.6`) produce larger images than the regular screenshot tool (`scale=0.25, quality=0.5`). Since explore captures MULTIPLE images in one call, its per-image defaults should be MORE aggressive than screenshot, not less.

### 3.3 Missing Explore Features

1. **2D scene detection** — Explore assumes 3D (Camera3D, positions, cardinal directions). Calling it on a 2D scene will produce meaningless results or errors. No guard exists.

2. **Empty game detection** — If the game is running but the scene has no visible geometry (e.g., a UI-only scene), explore will capture blank screenshots and waste tokens. The tool should check if any MeshInstance3D/CSG nodes exist before proceeding.

3. **Partial result handling** — If 3 of 5 screenshots fail (camera move error), the agent gets 3 screenshots with no indication which areas were missed. The `area_index` field helps, but a `"missed_areas"` field would be clearer.

---

## 4. WORKFLOW GAPS

### 4.1 Post-Build Visual QA — Documented but Incomplete

Workflow 4 (line 432) documents explore for visual QA. Issues:

1. **Not integrated into Final QA checklist** — The Mandatory Final QA (line 152) has 6 steps. None mention explore. An agent following the Final QA strictly will skip visual inspection.

2. **No guidance on interpreting explore results** — The workflow says "Analyze each screenshot: describe what you see, note issues" but doesn't say:
   - What constitutes an "issue" vs acceptable
   - When to re-explore after fixes
   - How many explore iterations are acceptable before asking the user

3. **Contradiction with "CANNOT see" rule** — Covered in Section 1.2 above.

### 4.2 Multi-File Refactoring Safety — Not Documented

No workflow exists for safe multi-file refactoring. The implicit pattern should be:

```
1. impact_check(file, action, target)     → understand blast radius
2. validate(target="project")             → baseline: current issues
3. Make changes
4. validate(target="project")             → verify no new issues
5. check_errors(scope="project")          → verify compilation
6. signal_map(find="orphans")             → verify no broken signals
```

The prompt mentions `impact_check` in workflow 2 but doesn't describe the validate-before/validate-after loop. An agent doing a rename refactoring has no guidance on verification.

### 4.3 Error Recovery Patterns — Incomplete

Current coverage: 8 error codes (line 577-588). Missing patterns:

| Scenario | What Happens | What Agent Should Do |
|----------|-------------|---------------------|
| Game crashes during play-test | Bridge drops, all game-side tools fail | `run(action="stop")`, `check_errors(scope="scene")`, fix, retry |
| Explore returns 0 screenshots | Bridge was connected but camera couldn't capture | Check `game_running` in result, verify scene has 3D content |
| `apply_output_limit` truncates data | Agent gets incomplete results | Switch to `detail="brief"`, add filters, or narrow scope |
| Addon version mismatch | Addon/server protocol divergence | `ping()` to check version, re-install addon if mismatched |
| Scene too large for scene_map | 1000+ nodes, response huge | Use `focus` + `radius` to limit scope (documented) |

### 4.4 Session Recovery — Not Documented

When the agent's context window is compressed (long sessions), it loses earlier tool results. The prompt says "Don't repeat tool calls" (Efficiency Rule 3) but doesn't address what to do when prior results are evicted from context. The agent should know:
- `project_summary` and `editor_context` are cheap to re-call
- `asset_registry` and `scene_map` are expensive — use filters on re-call
- Check `_editor_state` on next bridge call instead of explicit `editor_context`

### 4.5 2D Game Workflows — Absent

The entire prompt is 3D-focused. For 2D games:
- `scene_map` still works (returns position data)
- `spatial_audit` checks are 3D-specific (overlap, floating objects) — may produce false positives in 2D
- `placement` assumes 3D constraints
- `explore` creates a Camera3D drone — meaningless in 2D
- `build_scene` grid/scatter work in 2D but examples show only 3D coordinates

---

## 5. AGENT EFFICIENCY — Token Usage Analysis

### 5.1 Highest Token-Cost Operations

| Operation | Typical Size | When It Hurts |
|-----------|-------------|---------------|
| `explore(mode="tour")` at defaults | 30K-200K chars | 5 areas × overview screenshots at scale=0.5, quality=0.6 |
| `screenshot(scale=0.5, quality=0.8)` | 10K-40K chars | Agent uses higher quality than needed |
| `asset_registry(detail="normal")` without `path_filter` | 50K-140K chars | Large projects with many assets |
| `scene_map(detail="full")` without `focus` | 20K-50K chars | Full scene dump on complex scenes |
| `scene_tree(depth=10, detail="full")` | 10K-30K chars | Deep tree on complex scenes |

### 5.2 Redundant Call Patterns

Based on the tool architecture, these are likely redundancy patterns:

1. **`editor_context` after bridge tool calls** — Every bridge tool response includes `_editor_state` with the same info. The prompt mentions this (Efficiency Rule 4) but agents frequently ignore it.

2. **`scene_map` + `scene_tree` for the same scene** — Agents often call both to "understand the scene." They should call `scene_map` for spatial analysis (before placing objects) OR `scene_tree` for live state (before editing nodes), not both.

3. **`project_summary` + `file_context` on session start** — `project_summary` gives an overview. If the agent immediately calls `file_context` on every file, the overlap is wasteful. The prompt says "call file_context BEFORE editing" which is correct — but agents call it preemptively.

4. **`validate` + `check_errors` together** — `validate` (PRO) includes convention checks. `check_errors` (free) checks compilation. They overlap on syntax issues. Community agents should use `check_errors` only. Pro agents should use `validate` only (it covers compilation too — or does it?). **This is unclear in the prompt.**

### 5.3 Detail Level Guidance

The prompt says "Default to detail='brief'" (line 200) but:

- Most tool defaults are `detail="normal"` in the function signatures
- An agent following the tool's default will get more data than the prompt recommends
- The prompt should say: "Override the tool default — always pass `detail='brief'` explicitly unless you need specific data"

**Suggestion:** Change all tool function signature defaults from `detail="normal"` to `detail="brief"`. This way agents that don't read the prompt instructions still get compact results.

### 5.4 Explore-Specific Token Waste

The explore tool is the single largest token consumer due to inline base64 images. Estimated costs:

| Configuration | Screenshots | Est. chars | Context % (200K) |
|---------------|------------|------------|-------------------|
| 5 areas, 1/area, scale=0.5, q=0.6 | 5 | ~50K | 25% |
| 5 areas, 3/area, scale=0.5, q=0.6 | 15 | ~150K | 75% |
| 5 areas, 5/area, scale=0.5, q=0.6 | 25 | ~250K | 125% ❌ overflow |
| 3 areas, 1/area, scale=0.3, q=0.4 | 3 | ~12K | 6% ✅ |

**Recommended safe defaults for explore:** `max_areas=3, screenshots_per_area=1, scale=0.3, quality=0.4` — 3 screenshots at ~4K each = ~12K chars total (6% of context).

---

## 6. SUMMARY OF RECOMMENDED FIXES

### Critical (breaks agent behavior)

| # | Issue | Section |
|---|-------|---------|
| C1 | "CANNOT see screenshots" contradicts explore workflow | 1.2 |
| C2 | Explore has no output size protection (context overflow risk) | 3.1 |
| C3 | Tool count says 35, actual is 36 | 1.1 |

### High (degrades agent effectiveness)

| # | Issue | Section |
|---|-------|---------|
| H1 | Explore not in Community fallback table | 1.3 |
| H2 | Explore not in Final QA checklist | 4.1 |
| H3 | Explore defaults (scale=0.5, q=0.6) too expensive for multi-shot tool | 3.2 |
| H4 | No multi-file refactoring workflow | 4.2 |
| H5 | `godotiq_ping` undocumented | 1.6 |
| H6 | `validate` vs `check_errors` overlap unclear | 5.2 |

### Medium (causes occasional confusion)

| # | Issue | Section |
|---|-------|---------|
| M1 | `scene_map` vs `scene_tree` naming confusion | 2.3 |
| M2 | Error recovery missing explore-specific patterns | 1.5 |
| M3 | No 2D game workflow guidance | 4.5 |
| M4 | `impact_check` valid `action` values not in prompt | 1.4 |
| M5 | `detail` defaults in code are "normal" but prompt says prefer "brief" | 5.3 |
| M6 | `camera` vs explore camera distinction unclear | 2.3 |
| M7 | Session recovery after context compression not addressed | 4.4 |

### Low (nice to have)

| # | Issue | Section |
|---|-------|---------|
| L1 | `watch` tool lacks usage guidance vs repeated `state_inspect` | 2.2 |
| L2 | `perf_snapshot` lacks threshold guidance | 2.2 |
| L3 | Explore: no 2D scene detection guard | 3.3 |
| L4 | Explore: no empty scene detection | 3.3 |
