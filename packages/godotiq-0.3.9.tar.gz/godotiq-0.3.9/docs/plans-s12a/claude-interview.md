# Interview Transcript — GodotIQ v0.1.4 Fix Sprint

## Q1: Grid offset scope — grid only or all placement modes?
**Answer:** All placement modes. Offset should shift everything in grid, scatter, and line modes.

## Q2: Dev key generation approach
**Answer:** Generate a random passphrase. User doesn't have a specific one — just needs to work like a password. I'll generate a secure random passphrase and hardcode its SHA-256 hash.

## Q3: Parent path stripping behavior
**Answer:** Strip first segment only. If the first path segment matches the root node name, strip it and keep the rest. E.g. `DungeonCrawler/Room1/Torch` → `Room1/Torch` when root is `DungeonCrawler`.

## Q4: Screenshot crop region validation
**Answer:** Clamp + warn. If region exceeds image bounds, clamp to available area but include a warning in the response about the clamping.

## Q5: Version sync source of truth
**Answer:** Build script syncs both. A pre-build hook reads pyproject.toml version and updates plugin.cfg + godotiq_server.gd ADDON_VERSION constant.

## Q6: Exec error detail — which side to improve?
**Answer:** Both sides. Improve GDScript addon to capture richer structured errors, and update Python MCP side to format them nicely.

## Q7: Implementation priority ordering
**Answer:** Impact first. Tackle the most impactful fixes first (build_scene, node_ops, exec, screenshot, input) then smaller changes (notes, packaging).

## Q8: Node_ops get_property return types
**Answer:** Typed with fallback. Try to convert Godot types to JSON-native types (Vector3→[x,y,z], Color→"#rrggbb", float→number), fall back to string for complex types.
