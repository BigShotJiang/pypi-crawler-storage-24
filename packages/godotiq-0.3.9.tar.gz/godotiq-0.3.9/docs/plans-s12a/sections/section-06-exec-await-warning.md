# Section 6: EXEC — Await Warning (Issue 6)

## Overview

Users write `await create_timer().timeout` inside `exec_code` snippets and get cryptic timeout errors with no explanation. The fix is purely Python-side: append a prominent warning to both `TOOL_DESCRIPTION` and the `exec_code()` function docstring.

## Files Modified

- `src/godotiq/tools/bridge/exec_code.py` — Added WARNING sentence to `TOOL_DESCRIPTION` constant and `Warning:` section to `exec_code()` docstring.

## Tests

- `tests/test_bridge/test_exec_code.py` — 2 new tests in `TestExecAwaitWarning` class:
  - `test_tool_description_contains_await_warning` — checks WARNING, await, timeout in TOOL_DESCRIPTION
  - `test_exec_code_docstring_contains_await_warning` — checks await, timeout in docstring

## Deviations from Plan

- Tests placed in `tests/test_bridge/test_exec_code.py` (existing test file) instead of `tests/test_tools/test_exec_code.py` (plan suggested).
- Code review skipped — change is trivial (two string additions, no logic).

## Verification

All 15 exec_code tests pass (8 original + 5 section-05 + 2 section-06).
