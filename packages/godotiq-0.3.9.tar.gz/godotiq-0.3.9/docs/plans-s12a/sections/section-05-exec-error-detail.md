# Section 5: EXEC Error Detail Extraction (Issue 5)

## Overview

Extract structured error data from GDScript compilation failures. When `GDScript.new().reload()` fails, capture line number and error message via the Logger system (Godot 4.5+) and return as `error_detail` alongside the existing `error` field.

## Files Modified

- `src/godotiq/tools/bridge/exec_code.py` — Added `_format_error_detail()` post-processor that converts bridge `error_detail` list into human-readable string (e.g., `"line 5: Expected end of statement; line 7: Invalid assignment"`). Empty/missing lists are stripped from response.
- `godot-addon/addons/godotiq/godotiq_server.gd` — In `_handle_exec_editor`: clear Logger errors before compilation, enable `capture_all` mode on Logger, compile, collect errors, adjust line numbers by -3 (prepend offset for `@tool\nextends Node\n\n`), return as `error_detail` array.
- `godot-addon/addons/godotiq/godotiq_runtime.gd` — Enhanced error message to include `error_string(err)` name (e.g., "Parse Error"). No Logger available in game process, so no `error_detail` list.
- `godot-addon/addons/godotiq/godotiq_logger.gd` — Added `capture_all` flag. When true, captures errors regardless of file extension (needed for in-memory GDScript.new() which has no file path).

## Tests

- `tests/test_bridge/test_exec_code.py` — 5 new tests in `TestExecErrorDetail` class:
  - Single error detail formatting
  - Multiple errors joined with semicolons
  - Missing error_detail passthrough
  - Empty error_detail list stripped
  - OK response unmodified

## Deviations from Plan

- Section plan file was corrupted (contained stray note). Implementation derived from sprint spec (Issue 5) and existing code analysis.
- Added Logger `capture_all` flag (code review fix) — GDScript.new() compiled in-memory has no file path, so the Logger's `.gd`/`.tscn` extension filter would drop exec compilation errors.
- Added line offset adjustment (code review fix) — subtracted 3-line prepend from Logger-captured line numbers.
- Game context only gets error code name, not structured error_detail (no Logger in game process).

## Verification

All 13 exec_code tests pass (8 existing + 5 new).
