Now I have all the context needed. Let me produce the section content.

# Section 15: CLI -- Version Warning Suppression

## Overview

When a user runs `godotiq --version`, they may see a "No Godot project found" warning on stderr before the version string prints to stdout. This is a poor experience -- `--version` should produce clean output with no spurious diagnostics.

The root cause: `cli_main()` unconditionally imports `from godotiq import __version__` at line 12 before doing anything. While the `__init__.py` import itself is lightweight (just `importlib.metadata.version()`), the broader problem is that if any import chain or future refactor triggers session/server initialization, the `logger.warning("No Godot project found. Tools will return errors.")` message in `server.py` gets emitted to stderr. Even today, the logging infrastructure in `server.py` writes to stderr via a `StreamHandler`, and any log message at WARNING level or above will appear.

The fix: detect `--version` early in `cli_main()` and short-circuit to print the version without going through the full argparse machinery that might trigger unnecessary imports. Alternatively, suppress logging before the import.

## Dependencies

- **Section 13 (version-sync)**: Section 13 creates `scripts/sync_version.py` and establishes version-sync infrastructure. This section modifies `cli.py` which reads `__version__`. The dependency is soft -- the CLI change here is independent of version syncing, but both are in the packaging batch.

## Files to Modify

- `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/cli.py` -- main implementation change
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_cli.py` -- add new test class

## Tests FIRST

Add a new test class to the existing test file at `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_cli.py`.

```python
class TestVersionWarning:
    """Verify --version suppresses warnings and produces clean output."""

    def test_version_flag_no_warning_in_stderr(self):
        """godotiq --version should NOT emit warning text to stderr."""
        # Run as subprocess to capture real stderr output from logging
        result = subprocess.run(
            [sys.executable, "-m", "godotiq", "--version"],
            capture_output=True, text=True, timeout=10,
        )
        assert result.returncode == 0
        # The key assertion: no "No Godot project found" or other warning text
        assert "warning" not in result.stderr.lower()
        assert "No Godot project" not in result.stderr

    def test_version_flag_prints_version_to_stdout(self):
        """godotiq --version should print the version string to stdout."""
        result = subprocess.run(
            [sys.executable, "-m", "godotiq", "--version"],
            capture_output=True, text=True, timeout=10,
        )
        assert result.returncode == 0
        from godotiq import __version__
        assert __version__ in result.stdout

    def test_normal_invocation_does_not_suppress_warnings(self, monkeypatch):
        """When --version is NOT in sys.argv, logging should remain at normal level."""
        # This test verifies we only suppress for --version, not globally.
        # We check that the godotiq logger level is NOT set to CRITICAL
        # during normal (non --version) operation.
        served = []
        monkeypatch.setattr("godotiq.cli._serve", lambda: served.append(True))
        monkeypatch.setattr("sys.argv", ["godotiq"])
        import logging
        godotiq_logger = logging.getLogger("godotiq")
        from godotiq.cli import cli_main
        cli_main()
        # After normal invocation, the logger should not be at CRITICAL
        assert godotiq_logger.level != logging.CRITICAL
```

These three tests cover:

1. **No warning in stderr**: The primary bug. Run `godotiq --version` as a subprocess (to get real stderr) and assert no warning text appears.
2. **Version in stdout**: The `--version` flag still correctly prints the version string.
3. **Normal invocation not suppressed**: When `--version` is absent, logging stays at normal level -- the fix must be scoped only to the version flag.

## Implementation Details

### Strategy

The cleanest approach: at the very top of `cli_main()`, before the `from godotiq import __version__` import (and before any other imports that might trigger logging), check if `--version` is the intent. If so, use `importlib.metadata.version("godotiq")` directly (bypassing the package `__init__.py` entirely) and print + exit immediately. This avoids the argparse machinery and any side-effect imports.

### Changes to `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/cli.py`

At the top of `cli_main()`, add an early exit path for `--version`:

```python
def cli_main() -> None:
    """Parse arguments and dispatch to the appropriate handler."""
    # Early exit for --version: avoid any imports that might trigger warnings
    if "--version" in sys.argv:
        from importlib.metadata import version as pkg_version
        try:
            ver = pkg_version("godotiq")
        except Exception:
            ver = "0.0.0-dev"
        print(f"godotiq {ver}")
        raise SystemExit(0)

    from godotiq import __version__
    # ... rest of the function unchanged ...
```

Key design decisions:

1. **Check `sys.argv` directly** -- this runs before argparse, before any godotiq submodule imports. The `sys` module is already imported at module level in cli.py.
2. **Use `importlib.metadata.version()` directly** -- this is the same function that `godotiq/__init__.py` uses, but calling it directly avoids importing the `godotiq` package (which could trigger side effects if `__init__.py` is ever extended).
3. **`raise SystemExit(0)`** -- matches argparse's `--version` action behavior. Existing tests already expect `SystemExit` with code 0.
4. **Keep the existing argparse `--version` registration** -- it becomes unreachable for `--version` but keeps the help text correct (`godotiq --help` still shows `--version` as an option). Alternatively, remove the argparse `add_argument("--version", ...)` line since we handle it manually -- but keeping it is harmless and ensures `--help` output remains accurate.

### Why not just suppress logging?

An alternative from the plan is to set `logging.getLogger("godotiq").setLevel(logging.CRITICAL)` when `--version` is detected. This would work, but the early-exit approach is cleaner because:

- It avoids importing `godotiq` package at all for `--version`
- It is faster (no argparse setup, no tool imports)
- It cannot accidentally suppress warnings that should be shown

### Backward Compatibility

- The `--version` flag already raises `SystemExit(0)` -- same behavior.
- The output format `"godotiq {ver}"` matches argparse's `version` action format string already defined in the existing code (`version=f"godotiq {__version__}"`).
- The existing `test_version_flag` test in `TestCliParsing` should continue to pass because it also expects `SystemExit(0)` and checks `__version__` in stdout. The early exit produces the same output.

### Existing Test Impact

The existing `TestCliParsing.test_version_flag` test uses `monkeypatch.setattr("sys.argv", ...)` and calls `cli_main()` directly. Since the early-exit path checks `sys.argv` and the monkeypatch sets it, this test will hit the new code path -- which is correct. The test expects `SystemExit(0)` and `__version__` in stdout, both of which the new path provides.

The `TestMainModule.test_python_m_version` test runs as a subprocess and checks `result.returncode == 0` and `__version__ in result.stdout` -- also compatible.

## Implementation Results

### Files Modified
- `src/godotiq/cli.py` — added early-exit `--version` path at top of `cli_main()`
- `tests/test_cli.py` — added `TestVersionWarning` class with 3 tests

### Deviations from Plan
1. **argv check tightened** (code review fix): Changed `if "--version" in sys.argv` to `if len(sys.argv) > 1 and sys.argv[1] == "--version"` to prevent hijacking subcommand arguments.
2. **Exception narrowed** (code review fix): Changed `except Exception` to `except PackageNotFoundError` for consistency with `__init__.py`.
3. **Comment added** on unreachable argparse `--version` registration explaining it's kept for `--help` display.

### Test Results
- 27/27 CLI tests passing (24 existing + 3 new)
- New tests: `test_version_flag_no_warning_in_stderr`, `test_version_flag_prints_version_to_stdout`, `test_normal_invocation_does_not_suppress_warnings`