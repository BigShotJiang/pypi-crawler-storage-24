# Section 2: BUILD_SCENE -- Scene-Derived Node Names

## Background

The `build_scene` grid and line expansion helpers use a generic "Node" prefix for auto-generated node names (e.g., `Node_0_0`, `Node_1`). When a `scene` path is provided (e.g., `res://props/torch.tscn`), the naming should derive from the filename instead, producing `torch_0_0` / `torch_1`.

## Files Modified

- `godot-addon/addons/godotiq/godotiq_server.gd` — Updated `_expand_build_grid()` and `_expand_build_line()` prefix logic

## Implementation

In both `_expand_build_grid` and `_expand_build_line`:
1. If user provides explicit `prefix` key, use it (backward compat)
2. If no explicit prefix but `scene` path is provided, derive prefix via `scene_path.get_file().get_basename()` (e.g., `res://props/torch.tscn` → `torch`)
3. Otherwise default to `"Node"`

## Backward Compatibility

- Existing callers that provide `prefix` key are unaffected
- Callers without `prefix` and without `scene` still get `"Node"` prefix
- Only callers with a `scene` but no `prefix` see the new behavior (better names)

## Test Results
- 38 existing build_scene tests pass (no Python changes needed)
