<!-- PROJECT_CONFIG
runtime: python-uv
test_command: uv run pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-build-scene-offset
section-02-build-scene-names
section-03-build-scene-parent
section-04-check-errors-confidence
section-05-exec-error-detail
section-06-exec-await-warning
section-07-asset-suggestions
section-08-scene-map-note
section-09-save-feedback
section-10-screenshot-crop
section-11-input-mouse-motion
section-12-node-ops-extensions
section-13-version-sync
section-14-dev-key-hash
section-15-cli-warning
END_MANIFEST -->

# Implementation Sections Index — GodotIQ v0.1.4

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-build-scene-offset | - | - | Yes |
| section-02-build-scene-names | - | - | Yes |
| section-03-build-scene-parent | - | - | Yes |
| section-04-check-errors-confidence | - | - | Yes |
| section-05-exec-error-detail | - | - | Yes |
| section-06-exec-await-warning | - | - | Yes |
| section-07-asset-suggestions | - | - | Yes |
| section-08-scene-map-note | - | - | Yes |
| section-09-save-feedback | - | - | Yes |
| section-10-screenshot-crop | - | - | Yes |
| section-11-input-mouse-motion | - | - | Yes |
| section-12-node-ops-extensions | - | - | Yes |
| section-13-version-sync | - | 15 | Yes |
| section-14-dev-key-hash | - | - | Yes |
| section-15-cli-warning | 13 | - | No |

## Execution Order

All sections are largely independent since they modify different tools/files. They can be batched aggressively:

1. **Batch 1** (high impact, parallel): section-01, section-02, section-03, section-05, section-12
2. **Batch 2** (medium impact, parallel): section-04, section-07, section-10, section-11
3. **Batch 3** (annotations + packaging, parallel): section-06, section-08, section-09, section-13, section-14
4. **Batch 4** (depends on version sync): section-15

## Section Summaries

### section-01-build-scene-offset
Add `offset: [x, y, z]` parameter to build_scene for all placement modes (grid, scatter, line). Python-side validation + GDScript-side position shifting.

### section-02-build-scene-names
Replace generic "Node" prefix with scene filename-derived names. Grid: `{filename}_{row}_{col}`, Scatter/Line: `{filename}_{index}`. GDScript-side change.

### section-03-build-scene-parent
Auto-strip root node name from parent path. `"DungeonCrawler/Room1"` → `"Room1"`. Improved error message with root name hint. GDScript-side change.

### section-04-check-errors-confidence
Add `confidence: "low"/"high"` to each error based on line number. Add top-level note when line-0 errors present. Python-side post-processing.

### section-05-exec-error-detail
Extract structured error data from GDScript compilation failures. Return `error_detail` with line number and message. Both Python and GDScript sides.

### section-06-exec-await-warning
Add WARNING about await/timeout to exec tool docstring and TOOL_DESCRIPTION. Python-side only, minimal change.

### section-07-asset-suggestions
When path_filter returns 0 results, return list of available asset directories as suggestions. Python-side scan of project index.

### section-08-scene-map-note
Add `note` field to scene_map response about reading from saved .tscn file. Python-side one-liner.

### section-09-save-feedback
Return `file_size_kb` and `node_count` in save_scene response. GDScript-side addition after save.

### section-10-screenshot-crop
Add optional `region: [x, y, w, h]` parameter to screenshot. GDScript-side Image.get_region() crop with clamp+warn. Python-side validation.

### section-11-input-mouse-motion
Add `mouse_motion` command type with `relative_x`/`relative_y`. GDScript-side InputEventMouseMotion dispatch. Python-side validation.

### section-12-node-ops-extensions
Add `rename` and `get_property` operations. GDScript-side handlers with typed value conversion for get_property. Python-side validation.

### section-13-version-sync
Create `scripts/sync_version.py` that reads pyproject.toml version and patches plugin.cfg + godotiq_server.gd ADDON_VERSION.

### section-14-dev-key-hash
Replace GODOTIQ_LICENSE=pro bypass with SHA-256 hashed dev key in license.py. Generate random passphrase, hardcode hash.

### section-15-cli-warning
Suppress warnings when --version flag is present in sys.argv. Early check in cli.py before imports.
