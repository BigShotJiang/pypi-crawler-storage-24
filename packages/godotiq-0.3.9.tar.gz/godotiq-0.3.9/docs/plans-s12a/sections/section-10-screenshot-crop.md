# Section 10: Screenshot Crop Region

## Spec
Add optional `region: [x, y, width, height]` parameter to screenshot. Crop captured image to that region before encoding.

## Files Modified
- `src/godotiq/tools/bridge/screenshot.py` — Added `region` parameter with validation (4 elements, positive w/h)
- `src/godotiq/tools/bridge/__init__.py` — Exposed `region` parameter in MCP tool wrapper
- `godot-addon/addons/godotiq/godotiq_server.gd` — Region crop in `_do_editor_screenshot` with clampi bounds, passed through deferred capture path
- `godot-addon/addons/godotiq/godotiq_runtime.gd` — Region crop in game-side `_take_screenshot`
- `tests/test_bridge/test_editor_screenshot.py` — 5 new tests for region parameter

## Implementation Details

### Python Side
- `region` parameter validated: must have exactly 4 elements, width and height must be positive
- Passed to bridge as `params["region"]` for both editor and game viewports
- Not included in params when None (backward compatible)

### GDScript Side (both editor and game)
- Region crop applied **before** scaling for maximum precision
- Values clamped to image bounds: `clampi(x, 0, img_width)`, width clamped to `img_width - x`
- Uses `Image.get_region(Rect2i(rx, ry, rw, rh))`

## Code Review Deviations
- Fixed critical bug: `region` variable was used before declaration in `_handle_editor_screenshot` camera-moved branch (auto-fix from review)

## Tests
- 19 tests total (5 new, 14 existing unchanged)
- `test_region_param_passed_to_editor` — region in editor params
- `test_region_param_passed_to_game` — region in game params
- `test_region_not_passed_when_none` — no region key when not provided
- `test_region_validation_wrong_length` — error for != 4 elements
- `test_region_validation_non_positive_dimensions` — error for w/h <= 0
