# Section 09: Save Scene Feedback

## Spec
Return `file_size_kb` and `node_count` in save_scene response alongside existing `saved: true`.

## Files Modified
- `godot-addon/addons/godotiq/godotiq_server.gd` — Added file size calculation and recursive node count after save
- `src/godotiq/tools/bridge/save_scene.py` — Updated docstring to document new response fields
- `tests/test_bridge/test_save_scene.py` — Added `test_feedback_fields_passthrough` test

## Implementation Details

### GDScript Side
- After `EditorInterface.save_scene()`, reads the saved file with `FileAccess` to get byte size
- Converts to KB with `maxi(1, int(f.get_length() / 1024.0))` — minimum 1 KB when file exists
- Added `_count_nodes(root)` recursive helper to count all nodes in scene tree
- Both fields added to the response dict: `file_size_kb` and `node_count`

### Python Side
- Pure passthrough — no logic changes, just docstring update
- Response fields pass through from bridge to MCP consumer

## Code Review Deviations
- Added `maxi(1, ...)` floor to file_size_kb so saved files never report 0 KB (auto-fix from review)
- Updated Python docstring to include new fields (auto-fix from review)

## Tests
- 4 tests total (1 new, 3 existing unchanged)
- `test_feedback_fields_passthrough` verifies new fields pass through from bridge mock
