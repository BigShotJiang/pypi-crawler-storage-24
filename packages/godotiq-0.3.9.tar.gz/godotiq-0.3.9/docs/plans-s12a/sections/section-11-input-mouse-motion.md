# Section 11: Input Mouse Motion

## Summary
Add `mouse_motion` command type to the input simulation tool for sending `InputEventMouseMotion` events to the running game. Essential for testing FPS camera rotation.

## Files Modified
- `godot-addon/addons/godotiq/godotiq_runtime.gd` — Added `mouse_motion` handler in `_execute_input_command()` dispatching `InputEventMouseMotion` with `relative` vector
- `src/godotiq/tools/bridge/input_sim.py` — Updated TOOL_DESCRIPTION and docstring to document new command type
- `tests/test_bridge/test_input_sim.py` — Added 3 tests: basic mouse_motion, negative values, mixed commands

## Implementation Details

### Command Format
```json
{"mouse_motion": {"relative_x": 200, "relative_y": 0}}
```

### GDScript Handler
Creates `InputEventMouseMotion`, sets `event.relative = Vector2(rel_x, rel_y)`, dispatches via `Input.parse_input_event()`. Returns `{"type": "mouse_motion", "relative_x": ..., "relative_y": ..., "ok": true}`.

### Python Side
Pure passthrough (consistent with all other command types). Docstring and TOOL_DESCRIPTION updated.

## Tests
- `test_mouse_motion_command` — Verifies basic passthrough with positive values
- `test_mouse_motion_mixed_commands` — Verifies action + mouse_motion + wait interleaving (added during code review)
- `test_mouse_motion_negative_values` — Verifies negative relative values work

## Deviations from Plan
- Section plan file was empty (0 bytes) — implemented directly from sprint spec
- No Python-side validation added — consistent with codebase pattern where input_sim.py is a pure passthrough
- No `event.velocity` field set — `event.relative` is sufficient for standard FPS camera implementations
