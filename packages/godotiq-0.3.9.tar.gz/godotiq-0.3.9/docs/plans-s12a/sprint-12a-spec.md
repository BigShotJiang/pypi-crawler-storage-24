# GodotIQ v0.1.4 Fix Sprint — 15 Issues from Real-World Dungeon Crawler Demo

## Overview
Fix 15 issues discovered during real-world testing with a dungeon crawler demo game.
Run all tests after each fix. All existing tests must pass + add new tests for each fix.

## Issues

### BUILD_SCENE

1. **GRID OFFSET**: Add `"offset": [x, y, z]` to grid config. All placed nodes should be shifted by this offset. If not provided, default to `[0, 0, 0]`. Currently grid always starts at origin.

2. **UNIQUE NAMES**: Nodes created by build_scene should never be called "BuildNode". Default naming:
   - Grid: `{scene_filename}_{row}_{col}` (e.g. `floor_0_0`, `floor_0_1`)
   - Scatter: `{scene_filename}_{index}` (e.g. `wall_0`, `wall_1`)
   - Line: `{scene_filename}_{index}`
   - If item has explicit `"name"` in config, use that instead

3. **PARENT PATH**: If parent path starts with the root node name, strip it automatically. Example: `"DungeonCrawler/Room1"` → `"Room1"` when root is `"DungeonCrawler"`. Also add hint in error message: `"root node is '{name}', use relative paths from root children"`

### CHECK_ERRORS

4. **FALSE POSITIVES**: Scripts that report "parse errors" at line 0 are almost certainly false positives (cache/reload issue). Add `"confidence": "low"` to any error with line 0 or no line number. Add `"note": "line 0 errors are often false positives — try reloading the scene"` in the response when line-0 errors are present.

### EXEC

5. **ERROR DETAIL**: When exec returns "Compilation failed (error 43)", parse the GDScript error to extract line number and message. Return `"error_detail": "line 12: Invalid set index 'fog_density' on base Environment"` instead of just the error code. Check how the addon receives compilation errors from the engine and extract maximal detail.

6. **AWAIT WARNING**: Add to exec tool docstring: `"WARNING: func run() must return synchronously or within timeout_ms. Do not use long await chains (e.g. await create_timer().timeout) as they will cause timeout."`

### ASSET_REGISTRY

7. **FUZZY MATCH**: If path_filter returns 0 results, scan the project for available directories containing assets (`.glb`, `.tscn`, `.tres`, `.png`) and return them as `"suggestions": ["dungeon_glb/", "fantasy_town_glb/"]`. This helps the agent correct the filter without guessing.

### SCENE_MAP

8. **DISK WARNING**: Add a note in the scene_map response: `"note": "reads from saved .tscn file — call godotiq_save_scene first if you have unsaved editor changes"`

### SAVE_SCENE

9. **FEEDBACK**: Return additional info: `"file_size_kb": 245, "node_count": 47` alongside the existing `"saved": true` response.

### SCREENSHOT

10. **CROP REGION**: Add optional parameter `region: [x, y, width, height]` (in pixels) to screenshot. If provided, crop the captured image to that region before encoding. This enables zooming into specific areas without increasing total response size.

### INPUT

11. **MOUSE MOTION**: Add support for `{"mouse_motion": {"relative_x": 200, "relative_y": 0}}` in the input command list. This sends `InputEventMouseMotion` to the running game. Essential for testing FPS camera rotation.

### NODE_OPS

12. **RENAME + GET_PROPERTY**: Add two new operations:
    - `{"op": "rename", "node": "BuildNode", "new_name": "Wall_North_0"}`
    - `{"op": "get_property", "node": "Room1/Torch1", "property": "position"}` → returns `{"value": [2, 0, -0.5]}`

### PACKAGING

13. **PLUGIN.CFG VERSION**: The addon `plugin.cfg` must read version from the same source as `pyproject.toml`. When building the wheel, `plugin.cfg` version should match the package version. Fix the build process so they stay in sync.

14. **DEV OVERRIDE**: Replace `GODOTIQ_LICENSE=pro` env var bypass with a hashed dev key. Generate a SHA-256 hash of a secret dev passphrase and hardcode it. The env var `GODOTIQ_DEV_KEY` must match this hash to activate pro. Remove the plain "pro" string bypass.

15. **CLI WARNING**: `godotiq --version` prints a "no project found" warning before the version number. Suppress all warnings when `--version` flag is present.

## Verification

After all fixes:
- `pytest tests/ -v` → all pass (old + new)
- Bump version to 0.1.4 in `pyproject.toml`
- Rebuild: `rm -rf dist/ build/ && .venv/bin/python -m build`
- Do NOT upload to PyPI yet
