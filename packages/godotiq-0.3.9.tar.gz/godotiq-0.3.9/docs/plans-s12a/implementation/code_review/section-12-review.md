# Code Review: Section 12 — Node Ops Extensions

## Findings

### 1. Missing docstring verification test (Low)
Plan required a test asserting docstring contains "rename" and "get_property".

### 2. Empty undo action from pure get_property batch (Medium)
get_property returns status "ok" which triggers undo commit even with no mutations.

### 3. No guard against renaming scene root (Medium)
Renaming the scene root can cause file reference issues.

### 4. Name collision not noted in response (Low)
Godot may adjust name for sibling dedup; response doesn't caveat this.

### 5. _value_to_json missing Array/Dictionary recursion (Medium)
Array/Dictionary values get str()'d instead of converted to JSON.

### 6. Color values not snapped (Low)
Inconsistency: Vector values snapped to 0.001, Color values at full precision.

### 7. Python validation uses truthiness (Low)
`not op.get("node")` conflates missing/None/empty/falsy.

### 8. No mixed batch test (Low)
No test for rename + get_property in same batch.
