diff --git a/godot-addon/addons/godotiq/godotiq_server.gd b/godot-addon/addons/godotiq/godotiq_server.gd
index e920a90..23dc928 100644
--- a/godot-addon/addons/godotiq/godotiq_server.gd
+++ b/godot-addon/addons/godotiq/godotiq_server.gd
@@ -1265,13 +1265,32 @@ func _handle_save_scene(peer_id: int, id: String, _params: Dictionary) -> void:
 
 	var scene_path: String = scene_root.scene_file_path
 
+	# Compute feedback: file size and node count
+	var file_size_kb := 0
+	if FileAccess.file_exists(scene_path):
+		var f := FileAccess.open(scene_path, FileAccess.READ)
+		if f != null:
+			file_size_kb = int(f.get_length() / 1024.0)
+			f.close()
+
+	var node_count := _count_nodes(scene_root)
+
 	send_response(peer_id, id, {
 		"saved": true,
 		"scene_path": scene_path,
 		"scene_name": scene_root.name,
+		"file_size_kb": file_size_kb,
+		"node_count": node_count,
 	})
 
 
+func _count_nodes(root: Node) -> int:
+	var count := 1
+	for child in root.get_children():
+		count += _count_nodes(child)
+	return count
+
+
 func _handle_editor_screenshot(peer_id: int, id: String, params: Dictionary) -> void:
 	# Ensure 3D viewport is active — without this, screenshot may capture Script tab
 	EditorInterface.set_main_screen_editor("3D")
diff --git a/tests/test_bridge/test_save_scene.py b/tests/test_bridge/test_save_scene.py
index a1faafb..f10fa73 100644
--- a/tests/test_bridge/test_save_scene.py
+++ b/tests/test_bridge/test_save_scene.py
@@ -15,6 +15,8 @@ class TestSaveSceneTool:
             "saved": True,
             "scene_path": "res://scenes/main.tscn",
             "scene_name": "Main",
+            "file_size_kb": 245,
+            "node_count": 47,
         })
         with patch("godotiq.tools.bridge.save_scene.get_bridge", return_value=mock_bridge):
             result = await save_scene()
@@ -25,6 +27,22 @@ class TestSaveSceneTool:
             params = call_args[1].get("params", {})
             assert params == {}
 
+    @pytest.mark.asyncio
+    async def test_feedback_fields_passthrough(self):
+        """Save response should include file_size_kb and node_count from bridge."""
+        mock_bridge = AsyncMock()
+        mock_bridge.request = AsyncMock(return_value={
+            "saved": True,
+            "scene_path": "res://scenes/main.tscn",
+            "scene_name": "Main",
+            "file_size_kb": 245,
+            "node_count": 47,
+        })
+        with patch("godotiq.tools.bridge.save_scene.get_bridge", return_value=mock_bridge):
+            result = await save_scene()
+            assert result["file_size_kb"] == 245
+            assert result["node_count"] == 47
+
     @pytest.mark.asyncio
     async def test_timeout_value(self):
         """Save should use 5.0s timeout."""
