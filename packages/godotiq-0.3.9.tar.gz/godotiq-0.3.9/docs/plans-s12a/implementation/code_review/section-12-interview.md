# Code Review Interview: Section 12 — Node Ops Extensions

## Triage Decisions

| # | Finding | Severity | Decision | Rationale |
|---|---------|----------|----------|-----------|
| 1 | Missing docstring test | Low | Let go | Low-value string regression test |
| 2 | Empty undo from get_property | Medium | **Auto-fix** | Fixed: get_property ops excluded from any_succeeded check |
| 3 | No scene root guard | Medium | Let go | Consistent with other ops (move, set_property don't guard either) |
| 4 | Name collision not noted | Low | Let go | Plan explicitly accepts this |
| 5 | Missing Array/Dict recursion | Medium | **Auto-fix** | Added recursive _value_to_json for Array and Dictionary |
| 6 | Color not snapped | Low | **Auto-fix** | Applied snapped(0.001) to Color RGBA components |
| 7 | Python truthiness | Low | Let go | Edge case won't occur with real node names |
| 8 | No mixed batch test | Low | Let go | Individual op tests sufficient |

## Auto-fixes Applied

1. `godotiq_server.gd` line 699: Added `and result.get("op", "") != "get_property"` to prevent read-only ops from creating empty undo actions.
2. `_value_to_json`: Added recursive Array and Dictionary conversion before Transform3D handler.
3. `_value_to_json`: Changed Color to use `snapped(value.r, 0.001)` etc. for consistency.

## Result

All 16 tests passing.
