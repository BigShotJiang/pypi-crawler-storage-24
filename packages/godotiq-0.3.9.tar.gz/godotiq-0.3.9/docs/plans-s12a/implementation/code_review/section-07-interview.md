# Section 07 Code Review Interview

## Triage

| # | Finding | Action | Rationale |
|---|---------|--------|-----------|
| 1 | `res:/` vs `res://` path | **Asked user** | User chose to normalize to `res://` |
| 2 | Suggestions ignore category | **Let go** | By design per plan |
| 3 | Missing brief/full detail tests | **Auto-fix** | Added 2 tests |
| 4 | Double PurePosixPath | **Auto-fix** | Single construction |
| 5 | Stricter cap test | **Let go** | Current assertion sufficient |

## Decisions

### Issue 1: res:/ normalization
**User decision:** Normalize suggestions to `res://` format.
**Applied:** Post-processing step in suggestion loop: if parent starts with `res:/` but not `res://`, restore the double slash. Test assertion restored to `res://`.

### Issue 3: Detail level coverage (auto-fix)
**Applied:** Added `test_suggestions_in_brief_detail` and `test_suggestions_in_full_detail` tests.

### Issue 4: PurePosixPath optimization (auto-fix)
**Applied:** Single `p = PurePosixPath(asset_path)` construction, then `p.suffix` and `p.parent`.
