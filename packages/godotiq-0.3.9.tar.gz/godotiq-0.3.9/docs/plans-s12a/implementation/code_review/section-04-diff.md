diff --git a/src/godotiq/tools/bridge/check_errors.py b/src/godotiq/tools/bridge/check_errors.py
index fcc466e..7f7f67c 100644
--- a/src/godotiq/tools/bridge/check_errors.py
+++ b/src/godotiq/tools/bridge/check_errors.py
@@ -17,4 +17,30 @@ async def check_errors(scope: str = "scene") -> dict:
     """
     bridge = await get_bridge()
     result = await bridge.request("check_errors", params={"scope": scope})
+    _annotate_confidence(result)
     return result
+
+
+def _annotate_confidence(result: dict) -> None:
+    """Add confidence annotations to error entries in-place.
+
+    Errors at line 0 or with missing line are likely false positives from
+    Godot's cache/reload mechanism and get confidence "low". All others
+    get "high". A top-level note is added when any low-confidence error exists.
+    """
+    errors = result.get("errors")
+    if not isinstance(errors, list):
+        return
+    has_low = False
+    for err in errors:
+        line = err.get("line")
+        if not line:  # 0, None, or missing
+            err["confidence"] = "low"
+            has_low = True
+        else:
+            err["confidence"] = "high"
+    if has_low:
+        result["note"] = (
+            "line 0 errors are often false positives "
+            "\u2014 try reloading the scene"
+        )
diff --git a/tests/test_tools/test_check_errors.py b/tests/test_tools/test_check_errors.py
index 5717251..acc6b1e 100644
--- a/tests/test_tools/test_check_errors.py
+++ b/tests/test_tools/test_check_errors.py
@@ -224,3 +224,80 @@ class TestCheckErrorsEdgeCases:
         mock_bridge.request.assert_called_once_with(
             "check_errors", params={"scope": "res://scripts/player.gd"}
         )
+
+
+class TestCheckErrorsConfidenceAnnotation:
+    """Tests for false-positive confidence annotation on check_errors results."""
+
+    async def test_line_zero_gets_low_confidence(self) -> None:
+        """Error at line 0 is annotated with confidence 'low'."""
+        mock_bridge = AsyncMock()
+        mock_bridge.request.return_value = {
+            "errors": [{"file": "res://a.gd", "line": 0, "error": "Identifier not found"}],
+            "total": 1, "scripts_checked": 5, "scope": "scene",
+        }
+        with patch("godotiq.tools.bridge.check_errors.get_bridge", return_value=mock_bridge):
+            result = await check_errors()
+        assert result["errors"][0]["confidence"] == "low"
+
+    async def test_line_nonzero_gets_high_confidence(self) -> None:
+        """Error at line 15 is annotated with confidence 'high'."""
+        mock_bridge = AsyncMock()
+        mock_bridge.request.return_value = {
+            "errors": [{"file": "res://a.gd", "line": 15, "error": "Type mismatch"}],
+            "total": 1, "scripts_checked": 5, "scope": "scene",
+        }
+        with patch("godotiq.tools.bridge.check_errors.get_bridge", return_value=mock_bridge):
+            result = await check_errors()
+        assert result["errors"][0]["confidence"] == "high"
+
+    async def test_missing_line_key_gets_low_confidence(self) -> None:
+        """Error dict with no 'line' key is annotated with confidence 'low'."""
+        mock_bridge = AsyncMock()
+        mock_bridge.request.return_value = {
+            "errors": [{"file": "res://a.gd", "error": "msg"}],
+            "total": 1, "scripts_checked": 5, "scope": "scene",
+        }
+        with patch("godotiq.tools.bridge.check_errors.get_bridge", return_value=mock_bridge):
+            result = await check_errors()
+        assert result["errors"][0]["confidence"] == "low"
+
+    async def test_mixed_errors_adds_note(self) -> None:
+        """When any error has line==0, top-level 'note' is present."""
+        mock_bridge = AsyncMock()
+        mock_bridge.request.return_value = {
+            "errors": [
+                {"file": "res://a.gd", "line": 0, "error": "Identifier not found"},
+                {"file": "res://b.gd", "line": 15, "error": "Type mismatch"},
+            ],
+            "total": 2, "scripts_checked": 10, "scope": "scene",
+        }
+        with patch("godotiq.tools.bridge.check_errors.get_bridge", return_value=mock_bridge):
+            result = await check_errors()
+        assert result["errors"][0]["confidence"] == "low"
+        assert result["errors"][1]["confidence"] == "high"
+        assert "note" in result
+
+    async def test_all_high_confidence_no_note(self) -> None:
+        """When all errors have line > 0, no top-level 'note' is added."""
+        mock_bridge = AsyncMock()
+        mock_bridge.request.return_value = {
+            "errors": [
+                {"file": "res://a.gd", "line": 10, "error": "err1"},
+                {"file": "res://b.gd", "line": 20, "error": "err2"},
+            ],
+            "total": 2, "scripts_checked": 10, "scope": "scene",
+        }
+        with patch("godotiq.tools.bridge.check_errors.get_bridge", return_value=mock_bridge):
+            result = await check_errors()
+        assert "note" not in result
+
+    async def test_empty_errors_no_crash_no_note(self) -> None:
+        """Empty errors array produces no crash and no note."""
+        mock_bridge = AsyncMock()
+        mock_bridge.request.return_value = {
+            "errors": [], "total": 0, "scripts_checked": 5, "scope": "scene",
+        }
+        with patch("godotiq.tools.bridge.check_errors.get_bridge", return_value=mock_bridge):
+            result = await check_errors()
+        assert "note" not in result
