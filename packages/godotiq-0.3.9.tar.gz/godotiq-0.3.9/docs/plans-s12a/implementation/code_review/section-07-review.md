# Section 07 Code Review: Asset Suggestions

## Summary

Implementation faithfully follows the plan. Core logic, insertion point, cap at 20, zero-result-only trigger, and three-branch injection all correct.

## Issues

### 1. `res:/` vs `res://` path inconsistency (Medium)
`PurePosixPath("res://foo/bar.glb").parent` produces `res:/foo` (single slash) for root-level assets. Test weakened from `res://` to `res:/` to accommodate this. Same latent issue exists in `by_directory` aggregation.

### 2. Suggestions ignore `category` filter (Low, by design)
When filtering by category + path, suggestions scan ALL assets ignoring category. Plan says this is intentional. No test for this interaction.

### 3. No test for suggestions at `detail="brief"` or `detail="full"` (Low)
All suggestion tests use default `detail="normal"`. No test covers the other branches.

### 4. `PurePosixPath` constructed twice per asset (Negligible)
Could use single construction: `p = PurePosixPath(asset_path)` then `p.suffix` and `p.parent`.

### 5. Cap test could be stricter (Low)
Test doesn't verify cap is actively exercised (more than 20 unique dirs).

## Verdict
Correct implementation matching plan. Issue 1 (`res:/` vs `res://`) is most actionable.
