diff --git a/src/godotiq/tools/spatial/__init__.py b/src/godotiq/tools/spatial/__init__.py
index 1fbe1c0..8952c34 100644
--- a/src/godotiq/tools/spatial/__init__.py
+++ b/src/godotiq/tools/spatial/__init__.py
@@ -277,6 +277,7 @@ def _build_scene_map(
         "root_type": root_type,
         "total_nodes": resolved.total_nodes,
         "nodes": node_dicts,
+        "note": "reads from saved .tscn file — call godotiq_save_scene first if you have unsaved editor changes",
     }
 
     # Token hints
diff --git a/tests/test_tools/test_scene_map.py b/tests/test_tools/test_scene_map.py
index c69481c..873caf4 100644
--- a/tests/test_tools/test_scene_map.py
+++ b/tests/test_tools/test_scene_map.py
@@ -317,3 +317,19 @@ class TestSceneMapErrors:
         """Missing scene returns error dict."""
         result = _build_scene_map(session, "res://nonexistent.tscn")
         assert "error" in result
+
+
+class TestSceneMapDiskNote:
+    """Tests for the disk-warning note in scene_map response."""
+
+    def test_scene_map_response_contains_note(self, session: GodotIQSession) -> None:
+        """scene_map response includes a 'note' key."""
+        result = _build_scene_map(session, "res://scenes/equipment/fdm_printer.tscn")
+        assert "note" in result
+
+    def test_scene_map_note_mentions_saved_tscn(self, session: GodotIQSession) -> None:
+        """Note text mentions 'saved .tscn file' and 'godotiq_save_scene'."""
+        result = _build_scene_map(session, "res://scenes/equipment/fdm_printer.tscn")
+        note = result["note"]
+        assert "saved .tscn file" in note
+        assert "godotiq_save_scene" in note
