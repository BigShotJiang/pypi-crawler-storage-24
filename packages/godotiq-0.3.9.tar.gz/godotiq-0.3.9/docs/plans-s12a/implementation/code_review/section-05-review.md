# Section 05 Code Review: exec-error-detail

## Critical Issues

### 1. Line number offset not adjusted (AUTO-FIX)
User code is prepended with 3 lines (`@tool\nextends Node\n\n`). Logger captures absolute line numbers, so user line 1 is reported as line 4. Must subtract 3.

### 2. Logger filter may drop exec errors (INVESTIGATE)
`GDScript.new()` without resource_path may report errors with empty file path. The Logger filter (`file.ends_with(".gd")`) would drop these. Error_detail would always be empty for exec compilation.

## Medium Issues

### 3. Race condition in clear-compile-read window (LET GO)
Unlikely in practice - window is tiny.

### 4. Game context has no error_detail (LET GO)
By design - no Logger in game process. Python handles gracefully.

### 5. Malformed entry handling (AUTO-FIX)
Add defensive casting in `_format_error_detail` for safety.

## Minor Issues
- #6-9: Test gaps, mutation, unrelated diff noise, version mismatch - all LET GO
