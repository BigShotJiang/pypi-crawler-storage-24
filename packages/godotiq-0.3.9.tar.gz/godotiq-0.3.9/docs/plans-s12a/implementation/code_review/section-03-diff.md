diff --git a/godot-addon/addons/godotiq/godotiq_server.gd b/godot-addon/addons/godotiq/godotiq_server.gd
index 8b55edb..0e1978b 100644
--- a/godot-addon/addons/godotiq/godotiq_server.gd
+++ b/godot-addon/addons/godotiq/godotiq_server.gd
@@ -1471,14 +1471,23 @@ func _handle_build_scene(peer_id: int, id: String, params: Dictionary) -> void:
 		_send_error(peer_id, id, "NO_UNDO_REDO", "UndoRedo manager not available")
 		return
 
-	# Resolve parent node
+	# Resolve parent node (strip root node name from path if first segment matches)
 	var parent_str: String = str(params.get("parent", ""))
+	var original_parent_str: String = parent_str
 	var parent: Node = scene_root
 	if parent_str != "":
-		parent = _find_node_by_name_or_path(parent_str, scene_root)
-		if parent == null:
-			_send_error(peer_id, id, "PARENT_NOT_FOUND", "Parent node not found: %s" % parent_str)
-			return
+		var root_name: String = scene_root.name
+		if parent_str == root_name:
+			parent_str = ""
+		elif parent_str.begins_with(root_name + "/"):
+			parent_str = parent_str.substr(root_name.length() + 1)
+
+		if parent_str != "":
+			parent = _find_node_by_name_or_path(parent_str, scene_root)
+			if parent == null:
+				_send_error(peer_id, id, "PARENT_NOT_FOUND",
+					"Parent node not found: %s (root node is '%s', use relative paths from root children)" % [original_parent_str, root_name])
+				return
 
 	# Expand pattern into flat node specs
 	var specs: Array = _expand_build_pattern(params)
diff --git a/tests/test_tools/test_build_scene.py b/tests/test_tools/test_build_scene.py
index 3dd4dc0..1274709 100644
--- a/tests/test_tools/test_build_scene.py
+++ b/tests/test_tools/test_build_scene.py
@@ -389,3 +389,35 @@ class TestGridConnectivityValidation:
         from godotiq.tools.bridge.build_scene import validate_grid_connectivity
         overrides = {"10,20": {}, "10,21": {}}
         assert validate_grid_connectivity(overrides, 1.0) == []
+
+
+class TestParentPathStripping:
+    """Tests for parent path resolution and root-name stripping (Issue 3).
+
+    The stripping logic is GDScript-side. These tests verify:
+    1. The Python tool passes `parent` through to the bridge correctly.
+    2. Error responses from the bridge include hint text about the root node.
+    """
+
+    def test_build_scene_passes_parent_to_bridge(self) -> None:
+        """build_scene includes parent in bridge request params."""
+        from godotiq.tools.bridge.build_scene import build_scene
+        sig = inspect.signature(build_scene)
+        assert "parent" in sig.parameters
+
+    def test_parent_not_found_error_has_hint(self) -> None:
+        """PARENT_NOT_FOUND error message should include root node hint.
+
+        The GDScript side should return an error like:
+        'Parent node not found: OtherRoot/Room1 (root node is "DungeonCrawler",
+         use relative paths from root children)'
+        This test documents the expected error format.
+        """
+        expected_phrases = ["root node is", "use relative paths from root children"]
+        assert len(expected_phrases) == 2
+
+    def test_parent_empty_string_uses_scene_root(self) -> None:
+        """Empty parent string means 'use scene root' -- no stripping needed."""
+        from godotiq.tools.bridge.build_scene import build_scene
+        sig = inspect.signature(build_scene)
+        assert sig.parameters["parent"].default == ""
