diff --git a/src/godotiq/cli.py b/src/godotiq/cli.py
index efc1eed..98904f0 100644
--- a/src/godotiq/cli.py
+++ b/src/godotiq/cli.py
@@ -9,6 +9,17 @@ from pathlib import Path
 
 def cli_main() -> None:
     """Parse arguments and dispatch to the appropriate handler."""
+    # Early exit for --version: avoid any imports that might trigger warnings
+    if "--version" in sys.argv:
+        from importlib.metadata import version as pkg_version
+
+        try:
+            ver = pkg_version("godotiq")
+        except Exception:
+            ver = "0.0.0-dev"
+        print(f"godotiq {ver}")
+        raise SystemExit(0)
+
     from godotiq import __version__
 
     parser = argparse.ArgumentParser(
diff --git a/tests/test_cli.py b/tests/test_cli.py
index 31fc01c..d718334 100644
--- a/tests/test_cli.py
+++ b/tests/test_cli.py
@@ -242,6 +242,42 @@ class TestInstallAddonLazyImport:
         assert "True" in result.stdout
 
 
+class TestVersionWarning:
+    """Verify --version suppresses warnings and produces clean output."""
+
+    def test_version_flag_no_warning_in_stderr(self):
+        """godotiq --version should NOT emit warning text to stderr."""
+        result = subprocess.run(
+            [sys.executable, "-m", "godotiq", "--version"],
+            capture_output=True, text=True, timeout=10,
+        )
+        assert result.returncode == 0
+        assert "warning" not in result.stderr.lower()
+        assert "No Godot project" not in result.stderr
+
+    def test_version_flag_prints_version_to_stdout(self):
+        """godotiq --version should print the version string to stdout."""
+        result = subprocess.run(
+            [sys.executable, "-m", "godotiq", "--version"],
+            capture_output=True, text=True, timeout=10,
+        )
+        assert result.returncode == 0
+        from godotiq import __version__
+        assert __version__ in result.stdout
+
+    def test_normal_invocation_does_not_suppress_warnings(self, monkeypatch):
+        """When --version is NOT in sys.argv, logging should remain at normal level."""
+        import logging
+
+        served = []
+        monkeypatch.setattr("godotiq.cli._serve", lambda: served.append(True))
+        monkeypatch.setattr("sys.argv", ["godotiq"])
+        godotiq_logger = logging.getLogger("godotiq")
+        from godotiq.cli import cli_main
+        cli_main()
+        assert godotiq_logger.level != logging.CRITICAL
+
+
 class TestMainModule:
     """Test python -m godotiq routing."""
 
