# Section 04 Code Review: check_errors Confidence Annotation

## Findings

### 1. Negative line numbers treated as high confidence (Medium)
`if not line` uses truthiness — `line: -1` is truthy, would get "high". An explicit `line <= 0` check would be safer.

### 2. line: None not tested (Low)
Plan explicitly lists this case. Implementation handles it (via truthiness) but no dedicated test.

### 3. Truthiness-based check is fragile (Medium)
`if not line` conflates 0, None, missing, False, empty string. More explicit comparison recommended.

### 4. Note string not asserted (Low)
Test only checks `"note" in result`, not the actual text content.

### 5. No test for missing/non-list errors key (Low)
Defensive paths in `_annotate_confidence` not tested.

### 6. Existing tests now include confidence (Info)
Pre-existing tests don't assert the new `confidence` key — acceptable.
