# Section 09 Code Review Interview

## Triage Summary

| # | Issue | Severity | Decision |
|---|-------|----------|----------|
| 1 | _count_nodes stack overflow risk | Medium | Let go — Godot scenes never reach 500+ nesting depth |
| 2 | Internal editor nodes | Medium | Let go — get_children() excludes internals by default in Godot 4 |
| 3 | Empty scene_file_path | Low-Medium | Let go — FileAccess.file_exists handles it, edge case is dialog-blocked |
| 4 | int() truncation for small files | Low | **Auto-fix** — use max(1, ...) when file exists |
| 5 | Python docstring not updated | Low | **Auto-fix** — update to list new fields |
| 6 | Redundant test | Low | Let go — extra coverage doesn't hurt |
| 7 | Backward compatibility | Medium | Let go — addon and Python package are released together |
| 8 | No GDScript tests | Low | Let go — can't test GDScript in Python test suite |

## Auto-fixes Applied

### Fix 4: File size minimum 1 KB when file exists
Change `int(f.get_length() / 1024.0)` to `maxi(1, int(f.get_length() / 1024.0))` so a saved file never reports 0 KB.

### Fix 5: Update Python docstring
Update save_scene docstring to include file_size_kb and node_count fields.
