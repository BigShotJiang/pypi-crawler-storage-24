# Section 05 Code Review Interview

## Decisions

### #1 Line number offset — AUTO-FIX (applied)
Subtract 3-line prepend offset (`@tool\nextends Node\n\n`) from Logger-captured line numbers using `maxi(line - 3, 1)`.

### #2 Logger filter for exec errors — USER CHOSE: Fix Logger filter
Added `capture_all` flag to `godotiq_logger.gd`. Server sets flag true before `script.reload()` and false after, allowing empty-path errors from in-memory GDScript compilation to be captured.

### #3 Defensive casting — AUTO-FIX (applied)
Added `isinstance(e, dict)` guard in `_format_error_detail` list comprehension.

## Let Go
- Race condition in clear-compile-read: unlikely, tiny window
- Game context no error_detail: by design, no Logger in game process
- Missing edge-case tests: main paths covered
- Input mutation: standard pattern in codebase
