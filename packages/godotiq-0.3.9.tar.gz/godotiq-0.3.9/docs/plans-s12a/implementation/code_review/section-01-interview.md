# Section 01 Code Review Interview

## Auto-fixes Applied

### 1. Line endpoint deduplication bug (HIGH)
- **Issue:** `final_pos` was constructed without offset, but `last_pos` already had offset applied. Distance comparison would always fail with non-zero offset, creating duplicate endpoint nodes.
- **Fix:** Added offset to `final_pos` construction in `_expand_build_line`.

### 2. Signature test missing `offset` (LOW)
- **Issue:** `test_build_scene_signature` didn't check for the new `offset` parameter.
- **Fix:** Added `"offset"` to the expected parameters list.

## Let Go (No Action)

- **nodes mode ignores offset:** Plan specifies grid/scatter/line. Nodes has explicit positions by design.
- **Scope creep in diff:** Pre-existing dirty tree changes, not from this section's work.
- **Mutable default arg in GDScript:** GDScript doesn't share defaults; callers always pass explicitly.
- **bool passes validation:** Irrelevant in practice (MCP sends proper types).
- **Missing line/scatter offset tests:** Validation is mode-independent; covered by grid tests.
