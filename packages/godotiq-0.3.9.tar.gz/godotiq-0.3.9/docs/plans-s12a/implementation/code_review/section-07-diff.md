diff --git a/src/godotiq/tools/assets/__init__.py b/src/godotiq/tools/assets/__init__.py
index f78eb26..1bdbb73 100644
--- a/src/godotiq/tools/assets/__init__.py
+++ b/src/godotiq/tools/assets/__init__.py
@@ -172,6 +172,17 @@ def _build_asset_registry(
     if max_results > 0:
         assets_list = assets_list[:max_results]
 
+    # Compute suggestions when path_filter yields zero results
+    suggestions: list[str] | None = None
+    if path_filter and len(assets_list) == 0:
+        asset_dirs: set[str] = set()
+        for asset_path in index.assets:
+            ext = PurePosixPath(asset_path).suffix.lower()
+            if ext in _CATEGORY_MAP:
+                parent = str(PurePosixPath(asset_path).parent)
+                asset_dirs.add(parent)
+        suggestions = sorted(asset_dirs)[:20]
+
     # Build result based on detail level
     detail = detail.lower() if detail else "normal"
 
@@ -185,6 +196,8 @@ def _build_asset_registry(
         }
         if path_filter:
             result["path_filter"] = path_filter
+        if suggestions is not None:
+            result["suggestions"] = suggestions
         return apply_output_limit(result, detail)
 
     if detail == "normal":
@@ -203,6 +216,8 @@ def _build_asset_registry(
         }
         if path_filter:
             result["path_filter"] = path_filter
+        if suggestions is not None:
+            result["suggestions"] = suggestions
         return apply_output_limit(result, detail, list_keys=["unused_list"])
 
     # Full: everything (current behavior)
@@ -221,6 +236,8 @@ def _build_asset_registry(
     }
     if path_filter:
         result["path_filter"] = path_filter
+    if suggestions is not None:
+        result["suggestions"] = suggestions
     return apply_output_limit(result, detail, list_keys=["assets", "unused_list"])
 
 
diff --git a/tests/test_tools/test_asset_registry.py b/tests/test_tools/test_asset_registry.py
index f1d3684..c999e16 100644
--- a/tests/test_tools/test_asset_registry.py
+++ b/tests/test_tools/test_asset_registry.py
@@ -196,3 +196,68 @@ class TestAssetRegistryMissingFile:
                 assert a[size_key] == 0
         finally:
             session._index.assets = original_assets
+
+
+class TestAssetRegistrySuggestionsOnEmpty:
+    """When path_filter produces 0 matches, suggestions list returned."""
+
+    def test_zero_matches_returns_suggestions(self, session: GodotIQSession) -> None:
+        """path_filter with 0 matches -> suggestions list with valid directories."""
+        result = _build_asset_registry(session, path_filter="nonexistent_folder_xyz")
+        assert result["total_assets"] == 0
+        assert "suggestions" in result
+        assert isinstance(result["suggestions"], list)
+        assert len(result["suggestions"]) >= 1
+
+    def test_suggestions_contain_only_asset_directories(self, session: GodotIQSession) -> None:
+        """Suggestions contain only directories with recognized asset files."""
+        result = _build_asset_registry(session, path_filter="nonexistent_folder_xyz")
+        assert "suggestions" in result
+        for s in result["suggestions"]:
+            assert isinstance(s, str)
+            assert s.startswith("res:/")
+
+    def test_suggestions_sorted_alphabetically(self, session: GodotIQSession) -> None:
+        """Suggestions are sorted alphabetically."""
+        result = _build_asset_registry(session, path_filter="nonexistent_folder_xyz")
+        assert "suggestions" in result
+        assert result["suggestions"] == sorted(result["suggestions"])
+
+    def test_suggestions_capped_at_20(self, session: GodotIQSession) -> None:
+        """Suggestions list capped at 20 entries."""
+        original_assets = dict(session._index.assets)
+        try:
+            for i in range(25):
+                fake_path = f"res://fake_dir_{i:02d}/model.glb"
+                session._index.assets[fake_path] = {"type": "model", "size_bytes": 10}
+            result = _build_asset_registry(session, path_filter="nonexistent_folder_xyz")
+            assert "suggestions" in result
+            assert len(result["suggestions"]) <= 20
+        finally:
+            session._index.assets = original_assets
+
+
+class TestAssetRegistryNoSuggestionsWhenMatches:
+    """When path_filter has matches, no suggestions key."""
+
+    def test_matches_no_suggestions(self, session: GodotIQSession) -> None:
+        """path_filter with matches -> no suggestions key in result."""
+        result = _build_asset_registry(session, path_filter="printers")
+        assert result["total_assets"] > 0
+        assert "suggestions" not in result
+
+
+class TestAssetRegistrySuggestionsEmptyProject:
+    """Empty project yields empty suggestions list."""
+
+    def test_empty_project_empty_suggestions(self, session: GodotIQSession) -> None:
+        """Empty project -> empty suggestions list."""
+        original_assets = dict(session._index.assets)
+        try:
+            session._index.assets = {}
+            result = _build_asset_registry(session, path_filter="anything")
+            assert result["total_assets"] == 0
+            assert "suggestions" in result
+            assert result["suggestions"] == []
+        finally:
+            session._index.assets = original_assets
