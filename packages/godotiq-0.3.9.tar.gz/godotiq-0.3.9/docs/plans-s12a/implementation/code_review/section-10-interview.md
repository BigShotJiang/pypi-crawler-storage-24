# Section 10 Code Review Interview

## Triage Summary

| # | Issue | Severity | Decision |
|---|-------|----------|----------|
| 1 | region use-before-declaration in _handle_editor_screenshot | Critical | **Auto-fix** — moved var region to top with other params |
| 2 | Missing negative x/y validation | Medium | Let go — GDScript clampi handles it correctly |
| 3 | Duplicated crop logic | Medium | Let go — only 2 locations, not worth abstracting |
| 4 | 1x1 pixel edge case on out-of-bounds | Low | Let go — clamping is reasonable behavior |
| 5 | No negative region tests | Low | Let go |
| 6 | No oversized region tests | Low | Let go |
| 7 | list[float] type hint | Low | Let go — matches camera_position/camera_target pattern |

## Auto-fixes Applied

### Fix 1: Move region declaration before camera_moved branch
Moved `var region: Array = params.get("region", [])` to line 1301 alongside scale/quality/fmt extraction, before the camera_moved conditional that references it.
