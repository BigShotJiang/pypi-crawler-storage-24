# Section 13 Code Review Interview

## Auto-fixes Applied

1. **Tri-state return for update functions** - Changed `update_plugin_cfg` and `update_server_gd` to return `bool | None` (True=modified, False=already correct, None=pattern not found). Added `_report_update` helper to handle all three cases with correct messaging.

2. **Added main() wrapper** - Extracted `if __name__` logic into a named `main()` function per spec.

3. **Print format shows old version** - Added `_extract_current` helper to read old version before updating. Output now matches spec format: `"Updated plugin.cfg: 0.1.0 -> 0.1.4"`.

4. **Removed unused pytest import** - Cleaned up test file.

## Let Go

- Generic FileNotFoundError (OS message is clear enough for standalone script)
- Missing error-path tests (5 tests cover happy paths well; error paths are straightforward)
- textwrap.dedent style (works correctly, style nit)
