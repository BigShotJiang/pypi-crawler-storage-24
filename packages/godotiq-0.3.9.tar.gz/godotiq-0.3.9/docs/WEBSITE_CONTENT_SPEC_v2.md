# GodotIQ Website Content Spec v2

> Auto-generated from codebase on 2026-03-17. All numbers verified.

---

## Quick Stats

| Metric | Verified Value |
|--------|---------------|
| Version | 0.1.9 |
| Total MCP Tools | 36 |
| Free (Community) Tools | 22 |
| Pro Tools | 14 |
| Test Count | 1,245 |
| Python Source Files | 55 |
| Lines of Python | 12,312 |
| Total Commits | 117 |
| Python Requirement | >=3.10 |
| License | MIT |
| Runtime Dependencies | `mcp>=1.0.0`, `websockets>=14.0`, `httpx>=0.27` |
| Dev Dependencies | `pytest>=7.0`, `pytest-asyncio>=0.21`, `build` |
| Build System | Hatchling |

---

## Installation

```bash
pip install godotiq
godotiq install-addon /path/to/godot/project
```

---

## Tool Reference (36 tools)

### Free Tools (22) — Community Edition

Raw operations: read, write, execute, query. No analysis or reasoning layer.

#### Infrastructure

| Tool | Description | Parameters | Requires Addon |
|------|------------|------------|----------------|
| `godotiq_ping` | Health check tool. Returns server status and version. | `detail` | No |

#### Editor & Scene Editing

| Tool | Description | Parameters | Requires Addon |
|------|------------|------------|----------------|
| `godotiq_editor_context` | Call FIRST alongside project_summary. Returns editor state: open scenes, selected nodes, is game running, project path. | `detail` | Yes |
| `godotiq_scene_tree` | Live editor scene tree — actual state with transforms, scripts, groups, visibility. Unlike scene_map (reads .tscn from disk), this reads the editor's live state. | `root`, `depth`, `filter_type`, `include`, `detail` | Yes |
| `godotiq_node_ops` | Core scene editing tool. Batch operations with Ctrl+Z undo: move, rotate, scale, set_property, add_child, delete, duplicate, reparent, rename, get_property. All ops in one call = one undo action. | `operations`, `scene`, `detail` | Yes |
| `godotiq_build_scene` | Create multiple nodes in a scene using high-level patterns. One call = many nodes with Ctrl+Z undo. Modes: grid, line, scatter, explicit list. | `target_scene`, `parent`, `detail`, `grid`, `line`, `scatter`, `nodes`, `offset` | Yes |
| `godotiq_save_scene` | Persist editor changes to disk. Call after node_ops or any scene modifications. | `detail` | Yes |
| `godotiq_undo_history` | Review what was changed. Shows undo/redo state and recent GodotIQ action history. | `detail` | Yes |
| `godotiq_camera` | Editor 3D camera control: get current position, reposition, or focus on a node. Editor-side — no game needed. | `action`, `position`, `target`, `node`, `detail` | Yes |

#### Code & Files

| Tool | Description | Parameters | Requires Addon |
|------|------------|------------|----------------|
| `godotiq_script_ops` | Read, write, or patch GDScript files with convention validation. Patch mode (find-and-replace) is safest. | `op`, `path`, `content`, `patches`, `validate_before_write`, `auto_fix`, `dry_run`, `detail` | Filesystem |
| `godotiq_file_ops` | Filesystem operations: list, read, write, move, delete, search, tree, uid_to_path, path_to_uid, rename with reference updates. Respects protected files from .godotiq.json. | `op`, `path`, `query`, `filter`, `recursive`, `context_lines`, `max_depth`, `show_sizes`, `content`, `destination`, `detail` | Filesystem |
| `godotiq_check_errors` | Check GDScript files for compilation/parse errors. | `scope` | Yes |
| `godotiq_exec` | Execute GDScript code. Last resort — prefer dedicated tools. Code MUST contain 'func run():'. | `code`, `context`, `timeout_ms`, `detail` | Yes |

#### Game Runtime

| Tool | Description | Parameters | Requires Addon |
|------|------------|------------|----------------|
| `godotiq_run` | Start or stop the Godot game. Must call play before using any game-side tools. | `action`, `scene`, `detail` | Yes |
| `godotiq_input` | Simulate player input in the running game: actions, keys, UI taps, waits. Supports signal verification and side-effect tracking. | `commands`, `track_side_effects`, `continue_on_error`, `wait_for`, `wait_for_timeout_ms`, `detail` | Yes |
| `godotiq_screenshot` | Visual verification of the game or editor viewport. Use scale=0.25, quality=0.3 for token-efficient checks. | `viewport`, `scale`, `format`, `quality`, `camera_position`, `camera_target`, `region`, `detail` | Yes |
| `godotiq_state_inspect` | Query runtime property values. Cheaper than screenshots for checking state. Supports autoload lookup, node paths, nested properties, method calls. | `queries`, `detail` | Yes |
| `godotiq_perf_snapshot` | FPS, draw calls, memory, node count from the running game. | `detail` | Yes |
| `godotiq_nav_query` | Live pathfinding via NavigationServer3D. "Can A reach B?" Returns path, distance, reachability, navmesh status. | `from_node`, `to_node`, `from_position`, `to_position`, `optimize`, `detail` | Yes |
| `godotiq_watch` | Persistent property monitoring. Start watching, then read accumulated changes over time. | `action`, `watches`, `sample_interval_ms`, `detail` | Yes |
| `godotiq_ui_map` | Map all UI elements on screen: positions, text, interactivity, visibility. Call BEFORE godotiq_input to know what's on screen. | `root`, `include_invisible`, `max_depth`, `detail` | Yes |
| `godotiq_verify_motion` | Verify a node property changes over time (proves movement/animation). Takes two snapshots separated by a sleep and compares values. | `node`, `property_name`, `duration`, `detail` | Yes |

#### Animation (Data Extraction)

| Tool | Description | Parameters | Requires Addon |
|------|------------|------------|----------------|
| `godotiq_animation_info` | Animation data for any node: tracks, keyframes, length, looping, state machine transitions. | `scene`, `node`, `detail` | Filesystem |

---

### Pro Tools (14) — Intelligence & Analysis

These tools analyze, reason, predict, and suggest. All are filesystem-only (no addon required).

| Tool | Description | Parameters |
|------|------------|------------|
| `godotiq_project_summary` | Architecture overview, autoloads, conventions, file counts. Call FIRST in every session. | `detail` |
| `godotiq_file_context` | Deep context for a file: public API, dependencies, signals, who imports it, scene usage. Call BEFORE editing any file. | `file`, `detail` |
| `godotiq_dependency_graph` | Complete dependency graph: signals emitted, listeners, imports, reverse deps, impact rating. Call before refactoring. | `file`, `depth`, `detail` |
| `godotiq_validate` | Convention check: missing type hints, missing class_name, orphan signals, naming violations. | `target`, `detail` |
| `godotiq_signal_map` | Project-wide signal wiring: who emits, who listens, orphan/missing signals. | `scope`, `find`, `detail` |
| `godotiq_trace_flow` | Trace execution flow from a function or signal through the entire codebase. Returns chain of calls, signal emissions, failure points. | `trigger`, `depth`, `detail` |
| `godotiq_impact_check` | Predict what breaks BEFORE making a change. Returns affected files, callers, risk level, safe alternatives. | `file`, `action`, `target`, `change_description`, `detail` |
| `godotiq_animation_audit` | Find animation problems: broken tracks, missing transitions, wrong loop settings, unreferenced animations. | `scope`, `scene`, `detail` |
| `godotiq_asset_registry` | Complete asset inventory: find unused assets, missing references, assets by type. | `category`, `check_usage`, `detail`, `path_filter`, `max_results` |
| `godotiq_scene_map` | Spatial understanding of a .tscn scene: positions, distances, directions, bounds. Call before placing or moving 3D objects. | `scene`, `focus`, `radius`, `include`, `detail` |
| `godotiq_spatial_audit` | Automated 3D scene linter: floating objects, scale mismatches, z-fighting, overlapping instances, extreme positions. | `scene`, `checks`, `min_severity`, `detail` |
| `godotiq_suggest_scale` | Recommend scale + position for a model based on similar assets in the scene. | `scene`, `model`, `near_node`, `intended_use`, `detail` |
| `godotiq_placement` | Find safe placement positions for new objects. Checks Marker3D slots first, then grid-searches with wall/overlap validation. Up to 3 suggestions with confidence scores. | `scene`, `near`, `near_position`, `object_type`, `constraints`, `max_suggestions`, `detail` |
| `godotiq_explore` | Autonomous visual inspection via drone camera. Tour mode clusters nodes into areas and captures overview screenshots. Inspect mode visits specific positions. | `scene`, `mode`, `positions`, `max_areas`, `screenshots_per_area`, `scale`, `quality`, `fov`, `eye_height` |

---

## Community Teaser Strings (Pro Tools)

When a Community user calls a Pro tool, the tool runs fully (analysis executes), then the result is discarded and replaced with a teaser showing real counts.

Format: `"[counts from analysis] → upgrade: godotiq.com/pro"`

| Tool | Teaser Template | Example |
|------|----------------|---------|
| `project_summary` | `"{scripts} scripts, {scenes} scenes, {autoloads} autoloads analyzed"` | "42 scripts, 18 scenes, 5 autoloads analyzed" |
| `file_context` | `"{functions} public functions, {signals} signals, depended by {deps} scripts"` | "12 public functions, 3 signals, depended by 7 scripts" |
| `dependency_graph` | `"{signals_emitted} signals emitted, {reverse_refs} reverse refs, impact: {rating}"` | "4 signals emitted, 8 reverse refs, impact: high" |
| `validate` | `"{total} issues: {errors} errors, {warnings} warnings, {info} info"` | "14 issues: 0 errors, 6 warnings, 8 info" |
| `signal_map` | `"{signals} signals, {connections} connections, {orphans} orphans"` | "23 signals, 47 connections, 3 orphans" |
| `trace_flow` | `"{steps} steps across {files} files, {failure_points} failure points"` | "8 steps across 6 files, 2 failure points" |
| `impact_check` | `"risk: {risk}, {files_affected} files affected, {callers} callers found"` | "risk: high, 5 files affected, 3 callers found" |
| `animation_audit` | `"{animations} animations scanned, {issues} issues: {critical} critical, {warnings} warnings"` | "36 animations scanned, 5 issues: 1 critical, 3 warnings" |
| `asset_registry` | `"{assets} assets cataloged, {unused} unused ({categories} categories)"` | "184 assets cataloged, 23 unused (6 categories)" |
| `scene_map` | `"{nodes} nodes mapped, bounds: {bounds}"` | "47 nodes mapped, bounds: 12x4x8m" |
| `spatial_audit` | `"{issues} issues: {warnings} warnings, {info} info across {checks} checks"` | "7 issues: 4 warnings, 3 info across 6 checks" |
| `suggest_scale` | `"{ref_models} reference models analyzed, match: {tier}"` | "5 reference models analyzed, match: same_directory" |
| `placement` | `"{candidates} positions evaluated, {valid} valid, {excluded} excluded zones"` | "48 positions evaluated, 3 valid, 2 excluded zones" |
| `explore` | `"{areas} areas found, {nodes} total nodes"` | "4 areas found, 127 total nodes" |

---

## Tool Categories

| Category | Count | Tools |
|----------|-------|-------|
| Bridge (Editor) | 17 | editor_context, scene_tree, node_ops, build_scene, save_scene, undo_history, camera, exec, run, screenshot, check_errors, input, state_inspect, perf_snapshot, nav_query, watch, verify_motion |
| Bridge (UI) | 1 | ui_map |
| Filesystem | 3 | script_ops, file_ops, animation_info |
| Infrastructure | 1 | ping |
| Analysis (Pro) | 6 | project_summary, file_context, dependency_graph, validate, signal_map, trace_flow |
| Prediction (Pro) | 1 | impact_check |
| Animation (Pro) | 1 | animation_audit |
| Assets (Pro) | 2 | asset_registry, suggest_scale |
| Spatial (Pro) | 3 | scene_map, spatial_audit, placement |
| Visual (Pro) | 1 | explore |

---

## Package Metadata

```toml
[project]
name = "godotiq"
version = "0.1.9"
description = "The definitive MCP for AI-assisted Godot development"
license = "MIT"
requires-python = ">=3.10"
dependencies = ["mcp>=1.0.0", "websockets>=14.0", "httpx>=0.27"]
keywords = ["godot", "mcp", "game-development", "ai", "godot-engine"]
classifiers = [
    "Development Status :: 4 - Beta",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "License :: OSI Approved :: MIT License",
    "Topic :: Games/Entertainment",
    "Topic :: Software Development :: Libraries",
]
```

Entry point: `godotiq = "godotiq.cli:cli_main"`

---

## Changelog (from git history, 117 commits)

### Explore & Agent Polish
- `godotiq_explore` autonomous visual inspection tool (tour + inspect modes)
- Agent prompt improvements and workflow refinements

### Sprint 12a — Quality & Polish (v0.1.9)
- CLI `--version` warning suppression
- Version sync script across pyproject.toml, plugin.cfg, godotiq_server.gd
- `node_ops` rename and get_property operations
- `input` mouse motion command
- `screenshot` crop region support
- `save_scene` feedback fields
- `scene_map` disk warning note
- `asset_registry` fuzzy match suggestions
- `exec` await/timeout warning and error detail extraction
- `check_errors` confidence annotation
- `build_scene` parent path stripping, scene-derived node names, offset parameter

### PyPI Distribution Sprint (v0.1.5–v0.1.7)
- README with PyPI installation instructions
- Build verification tests and wheel validation
- `install-addon` subcommand with file copying
- CLI module with argparse and lazy imports
- Dynamic `__version__` from package metadata
- Packaging configuration for PyPI distribution (Hatchling)

### Sprint 11a — Reliability & Runtime (v0.1.4)
- Fresh MCP development prompt
- `verify_motion` tool for proving movement/animation
- Adaptive timeout based on GLB asset count
- `node_names` field added to `build_scene` response
- Script reload handler + `script_ops` integration
- Reliable scene launch rewrite (`_handle_run`)
- `set_main_scene` GDScript handler

### Sprint 10a/10b — Error Checking & QA
- Edge case tests for `check_errors`
- Prompt updates for error checking and gameplay testing
- Python `check_errors` bridge tool and MCP registration
- Pre-run script check gate in `_handle_run`
- `check_errors` GDScript handler with script validation
- Logger + error buffer for script error capture
- QA checklist and efficiency rules added to MCP prompt
- Grid connectivity validation for `build_scene`
- Pre-flight scene checks for `node_ops` and `build_scene`
- `_editor_state` added to every bridge response for ambient context

### Sprint 9a — Build Scene
- `build_scene` creation workflow prompt
- GDScript `build_scene` handler
- Python-side `build_scene` tool with registration and timeout tests

### Sprint 8a — Output Control & Detail
- Token budget integration tests
- `detail` parameter added to all tools (brief/normal/full)
- `detail` added to placement, suggest_scale, bridge tools
- `impact_check` detail renamed to `change_description`
- Enhanced `output_limit.py`

### Sprint 7 — Prompt & Config Rewrite
- Directive agent guidance rewrite for all 36 tool docstrings
- `detail` parameter system + config system enhancement

### Sprint 6 — UI, Placement, File Ops
- UID conversion, anchor presets, script rename with reference updates
- `placement` tool: smart object placement with constraint solving
- `ui_map`: runtime UI element mapping

### Sprint 5 — Spatial Validation & Screenshot
- Spatial validator module for `node_ops` validation
- Editor screenshot with synchronous handler + WS buffer auto-downscale
- Editor screenshot and camera control
- Editor exec + save scene
- MCP prompt overhaul

### Sprint 4 — Bridge Layer
- `file_ops` filesystem tool
- `script_ops` filesystem tool
- `node_ops` Python bridge tool + GDScript handler
- `scene_tree` Python bridge tool + GDScript handler
- Protocol and plugin wiring
- WebSocket server with request dispatch
- Godot addon plugin configuration and lifecycle
- Bridge tool test suite + session manager + tool registration

### Sprint 3 — Analysis & Parsers
- `trace_flow` tool: recursive tracing, failure detection, trigger finding, signal listener map
- Spatial audit severity filtering + sibling z-fighting downgrade
- `suggest_scale` reference mode without model
- `scene_map` detail-dependent caps and compact output
- `project_summary` architectural enrichment
- `signal_map` false positive fixes from event bus pattern
- `animation_audit` tool + `animation_info` tool with test suites
- Animation extraction helpers and test fixtures
- `scene_map` tool with spatial intelligence
- `dependency_graph` tool with signal cross-referencing
- `file_context` tool for deep file analysis
- `project_summary` tool with 3 detail levels
- Server integration with FastMCP lifespan
- Session layer for unified project state
- GDScript parser: body patterns, state machine core, dataclasses

### Sprint 2 — Scene & Spatial Foundation
- Project index with cross-reference maps
- World transforms and spatial queries
- Scene resolver core
- Value parser raw key addition

### Sprint 1 — Foundation
- Sprint 0 + Sprint 1A: initial project structure, parsers, test fixtures

---

## Architecture

```
src/godotiq/                    # 55 Python files, 12,312 LOC
├── server.py                   # MCP server (FastMCP, stdio transport)
├── cli.py                      # CLI entry point (install-addon, --version)
├── config.py                   # .godotiq.json loader
├── parsers/                    # .tscn, .gd, .tres parsers
├── cache/                      # Hash-based file cache
└── tools/                      # 9 tool categories
    ├── bridge/                 # Live editor/game tools (WebSocket)
    ├── memory/                 # project_summary, file_context
    ├── code/                   # dependency_graph, validate, signal_map
    ├── flow/                   # trace_flow, impact_check
    ├── animation/              # animation_info, animation_audit
    ├── assets/                 # asset_registry, suggest_scale
    └── spatial/                # scene_map, spatial_audit, placement

godot-addon/addons/godotiq/    # Godot 4.x addon
├── godotiq_plugin.gd          # EditorPlugin lifecycle
├── godotiq_server.gd          # WebSocket server (GDScript side)
├── godotiq_runtime.gd         # Game-side autoload
├── godotiq_logger.gd          # Error capture (Godot 4.5+)
└── plugin.cfg                 # Addon metadata
```

---

## URLs

| Resource | URL |
|----------|-----|
| Homepage | https://github.com/godotiq/godotiq |
| Repository | https://github.com/godotiq/godotiq |
| Issues | https://github.com/godotiq/godotiq/issues |
| PyPI | https://pypi.org/project/godotiq/ |
