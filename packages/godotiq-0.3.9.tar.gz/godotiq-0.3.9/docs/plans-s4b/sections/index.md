<!-- PROJECT_CONFIG
runtime: python-uv
test_command: uv run pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-protocol-plugin-wiring
section-02-scene-tree-gdscript
section-03-scene-tree-python
section-04-node-ops-gdscript
section-05-node-ops-python
section-06-script-ops
section-07-file-ops
section-08-tool-registration
section-09-tests
END_MANIFEST -->

# Sprint 4b Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-protocol-plugin-wiring | - | 02, 03, 04, 05 | Yes |
| section-02-scene-tree-gdscript | 01 | 03 | No |
| section-03-scene-tree-python | 02 | 08 | Yes (with 04) |
| section-04-node-ops-gdscript | 01 | 05 | Yes (with 02) |
| section-05-node-ops-python | 04 | 08 | Yes (with 03) |
| section-06-script-ops | - | 08 | Yes |
| section-07-file-ops | - | 08 | Yes |
| section-08-tool-registration | 03, 05, 06, 07 | 09 | No |
| section-09-tests | 08 | - | No |

## Execution Order

1. section-01-protocol-plugin-wiring (no dependencies)
2. section-02-scene-tree-gdscript, section-04-node-ops-gdscript, section-06-script-ops, section-07-file-ops (parallel — 02 and 04 need 01; 06 and 07 are independent)
3. section-03-scene-tree-python, section-05-node-ops-python (parallel after their GDScript counterparts)
4. section-08-tool-registration (after all implementations)
5. section-09-tests (final)

## Section Summaries

### section-01-protocol-plugin-wiring
Add `scene_tree` and `node_ops` timeouts to `TOOL_TIMEOUTS` in `protocol.py`. Wire `undo_redo` reference from `plugin.gd` to `godotiq_server.gd`. Add `var undo_redo` to server.

### section-02-scene-tree-gdscript
Add `scene_tree` handler to `godotiq_server.gd`'s `_dispatch()`. Implement `_handle_scene_tree()`, `_walk_tree()` recursive walker with depth/filter/include support, and `_count_descendants()`. Uses `EditorInterface.get_edited_scene_root()`. Always increment `current_depth` regardless of filter match.

### section-03-scene-tree-python
Create `src/godotiq/tools/bridge/scene_tree.py`. Async function that clamps depth [1,10], sets default include list, forwards to bridge.

### section-04-node-ops-gdscript
Add `node_ops` handler to `godotiq_server.gd`. Implement `_handle_node_ops()` with single undo action grouping, `_execute_node_op()` dispatch for 8 operation types (move, rotate, scale, set_property, add_child, delete, duplicate, reparent). Implement `_find_node_by_name_or_path()`, `_find_by_name_recursive()`, `_convert_value()`. Empty undo guard when all ops fail. Recursive owner setting on duplicate children.

### section-05-node-ops-python
Create `src/godotiq/tools/bridge/node_ops.py`. Async function that validates non-empty operations list, enforces 50-operation limit, forwards to bridge.

### section-06-script-ops
Create `src/godotiq/tools/bridge/script_ops.py`. Filesystem tool with read/write/patch/create modes. Path resolution with containment validation. Protected file enforcement. Patch uniqueness checking with line numbers calculated before replacement. GDScript convention validation.

### section-07-file-ops
Create `src/godotiq/tools/bridge/file_ops.py`. Filesystem tool with list/read/write/move/delete/search/tree operations. Type filtering (scenes, scripts, images, audio, etc.). Excluded directories. Protected file checks on both source and destination for move. Path containment validation. Search with context lines, capped at 50 matches.

### section-08-tool-registration
Register all 4 tools in `src/godotiq/tools/bridge/__init__.py`. Bridge tools (scene_tree, node_ops) get BridgeConnectionError/TimeoutError/BridgeError handlers. Filesystem tools (script_ops, file_ops) get generic Exception handlers. Include MCP annotations. Add tool description note directing agent to use script_ops for .gd files.

### section-09-tests
Unit tests for all 4 tools following established patterns. Bridge tools: AsyncMock + patch for get_bridge. Filesystem tools: tmp_path + monkeypatch.setenv for GODOTIQ_PROJECT_ROOT. Test path traversal prevention, protected files, all operation modes, edge cases.
