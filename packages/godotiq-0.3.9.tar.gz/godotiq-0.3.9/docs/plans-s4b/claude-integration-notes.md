# Integration Notes — Opus Review Feedback

## Integrating (12 items)

### 1. Path traversal vulnerability (Critical)
**Action**: Add path containment validation to both script_ops and file_ops. After resolving, verify path is within project root.

### 2. Resolve plan vs interview contradictions
**Action**: The sprint spec IS the authoritative source. node_ops includes move/rotate/scale as convenience operations alongside set_property (they're not redundant — they handle type-specific logic for 3D/2D/Control). Add clarifying note to plan. plugin.gd modification IS needed despite spec's "DO NOT TOUCH" note — the spec was written before the undo_redo wiring decision.

### 5. Duplicate node owner on children
**Action**: After `node.duplicate()`, recursively set owner on all children. Critical for save persistence.

### 6. Patch mode line number bug
**Action**: Calculate line number BEFORE performing replacement, not after.

### 7. Empty undo action on all-failures
**Action**: Track whether any operations registered callbacks. If none did, skip `commit_action()`.

### 8. Unbounded recursion with filter_type
**Action**: Always increment `current_depth` regardless of filter match.

### 10. Patch interference
**Action**: Document the limitation. Patches are applied sequentially — earlier patches can affect later ones.

### 12. file_ops write vs script_ops write overlap
**Action**: Add note in file_ops tool description directing agent to use script_ops for .gd files.

### 14. file_ops move destination protection
**Action**: Check destination path against _is_protected() too.

### 17. node_ops batch size limit
**Action**: Add 50-operation limit per call.

### 18. Test fixtures use monkeypatch
**Action**: Use pytest's `monkeypatch.setenv()` instead of raw `os.environ`.

### 20. script_ops validation operator precedence
**Action**: Rewrite the fragile ternary as explicit conditional.

## NOT Integrating (15 items)

### 4. Filesystem tools under bridge/ directory
**Reason**: The sprint spec explicitly places these under `tools/bridge/`. While semantically imperfect, it follows the spec's convention of grouping all Sprint 4a/4b tools together. The `bridge/` directory already contains `editor_context.py` which is also editor-side-only. Refactoring the directory structure is out of scope for this sprint.

### 9. UndoRedo method binding style
**Reason**: The Callable-based `.bind()` syntax IS correct for Godot 4.3+ `EditorUndoRedoManager`. The research document showed UndoRedo class syntax, not EditorUndoRedoManager. No change needed.

### 11. file_ops search unbounded reads
**Reason**: Godot projects are typically small. Adding a file size limit adds complexity for marginal benefit. The 50-match cap already limits output.

### 13. GODOTIQ_PROJECT_ROOT fallback
**Reason**: Filesystem tools get project root from env var set by the MCP server. The session's discover_project_root() is for Phase 1 tools. Keeping them separate avoids coupling.

### 15. scene_tree _count_descendants full scene
**Reason**: Intentional — `total_nodes` provides scene-wide context regardless of subtree query. Useful for the AI agent to understand scene complexity.

### 16. Scene becoming null mid-operation
**Reason**: GDScript is single-threaded. The scene cannot close during a synchronous handler execution. Non-issue.

### 19. scene_tree filter produces flat structure
**Reason**: The filter skips non-matching nodes but recurses children. Matching descendants appear under their nearest matching ancestor or at the output root. This is the intended behavior — showing only relevant nodes. Path context comes from the `n` (name) field.

### 21. __init__.py registration for filesystem tools
**Reason**: The pattern is straightforward — wrap with generic Exception handler. No bridge-specific hints needed. Will be clear in implementation.

### 22. file_ops hidden files exclusion
**Reason**: Excluding hidden files is a sensible default for Godot projects. `.godotiq.json` is read by the config module, not by file_ops. The agent can use script_ops read for specific hidden files if needed.

### 23. Tests last in implementation order
**Reason**: The implementation order is a suggestion. deep-implement (which does the actual implementation) follows TDD by default and writes tests alongside each section.

### 24. _is_protected() fragile matching
**Reason**: The protected patterns are few and specific. In practice, false positives are extremely unlikely in a Godot project. A proper glob system adds complexity for minimal benefit.

### 3. Plugin.gd "DO NOT TOUCH" contradiction
**Reason**: Already addressed in item 2 above — the plan acknowledges and justifies this modification.

### 25-27. Minor documentation/edge cases
**Reason**: Too minor for plan-level changes. Will be handled during implementation.
