# Sprint 4b Interview Transcript

## Q1: Reference Documents
**Q:** The spec references `PHASE2_PLAN.md` and `DESIGN__1_.md` for full architecture and tool API specs. Should I read PHASE2_PLAN.md from the repo root? And where is DESIGN__1_.md located?

**A:** Read both files. `PHASE2_PLAN.md` is in repo root. `DESIGN.md` is also in repo root (not `DESIGN__1_.md`). These are foundational documents — always reference them.

## Q2: UndoRedo Access
**Q:** The spec shows godotiq_server.gd handlers using EditorUndoRedoManager for node_ops, set_property, and script_attach. Since server.gd extends Node (not EditorPlugin), how should it access the undo_redo manager?

**A:** Pass from plugin.gd like the debugger reference. Add `_server.undo_redo = get_undo_redo()` in plugin.gd's `_enter_tree()`.

## Q3: Testing Priority
**Q:** For testing, the Python bridge tools can be unit tested with AsyncMock. But the GDScript handlers can only be tested live. What's the testing priority?

**A:** Python unit tests only. Test Python tool wrappers with mocked bridge. GDScript is tested manually via the live bridge.

## Q4: Tool Scope (A06/A07 Redefinition)
**Q:** The DESIGN.md defines A06 as `godotiq_script_ops` and A07 as `godotiq_file_ops`, but Sprint 4b spec redefines them as `godotiq_set_property` and `godotiq_script_attach`. Which should we follow?

**A:** Follow Sprint 4b spec. It's the latest and more refined scope.

## Q5: Code Trust Level
**Q:** The Sprint 4b spec includes complete GDScript implementations. Should the plan treat these as authoritative code to implement as-is, or as guidelines?

**A:** Use as guidelines. The code is a starting point but should be reviewed and potentially adapted to match codebase patterns.

## Q6: Plugin Wiring
**Q:** Should we add `_server.undo_redo = get_undo_redo()` in `_enter_tree()` like the debugger wiring?

**A:** Yes, wire in `_enter_tree()` exactly like the debugger reference.

## Q7: node_ops Operation Scope
**Q:** Should node_ops include move/rotate/scale operations (from original DESIGN.md), or keep the Sprint 4b spec's 6 operations?

**A:** `set_property` covers transforms (position/rotation/scale) — no need in node_ops. Keep node_ops focused on structural operations (add, remove, rename, reparent, duplicate, set_visible). This gives the AI agent maximum flexibility: `node_ops` for tree structure, `set_property` for any property change.
