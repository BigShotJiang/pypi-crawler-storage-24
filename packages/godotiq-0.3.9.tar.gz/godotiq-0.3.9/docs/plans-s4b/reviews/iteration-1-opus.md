# Opus Review

**Model:** claude-opus-4
**Generated:** 2026-03-04T20:00:00Z

---

## Critical Issues (27 total, top 8 summarized)

1. **Path traversal vulnerability** — `_resolve_path()` doesn't validate resolved path stays within project root. Could allow read/write/delete of arbitrary files.
2. **Plan vs interview contradictions** — node_ops scope (move/rotate/scale included despite interview saying remove them), tool 3/4 identity (plan uses script_ops/file_ops vs interview mentioning set_property/script_attach), plugin.gd modification despite "DO NOT TOUCH" constraint.
3. **Filesystem tools misplaced under `bridge/`** — script_ops and file_ops are pure filesystem tools, should not live under tools/bridge/.
4. **Recursive directory deletion without safeguards** — file_ops delete uses shutil.rmtree with no confirmation or force flag.
5. **Duplicate node owner not set on children** — after node.duplicate(), children need owner set recursively for save persistence.
6. **Patch mode re-reads original file for line numbers** — bug: reads disk after in-memory replacement, should calculate line before replacement.
7. **Empty undo action committed on all-failures** — node_ops commits empty undo action when all operations fail, polluting undo history.
8. **Unbounded recursion when filter_type skips depth increment** — scene_tree filtered-out nodes don't increment current_depth, could cause stack overflow.

## Additional Issues

9. UndoRedo method binding style inconsistency (Callable vs obj+method)
10. Patch mode sequential application can cause interference between patches
11. file_ops search has unbounded file reads (no size limit)
12. file_ops write overlaps with script_ops write (agent could bypass validation)
13. GODOTIQ_PROJECT_ROOT fallback ignores existing discover_project_root()
14. file_ops move doesn't check destination protection
15. scene_tree _count_descendants always counts full scene
16. Missing error handling for scene becoming null mid-operation
17. node_ops batch has no size limit
18. Test fixtures use os.environ instead of monkeypatch
19. scene_tree filter type produces misleading flat structure
20. script_ops validation has fragile operator precedence
21. __init__.py registration pattern unclear for filesystem tools
22. file_ops list excludes all hidden files (too aggressive)
23. Tests last in implementation order (should be alongside)
24. _is_protected() uses fragile substring matching
25-27. Various minor documentation and edge case issues
