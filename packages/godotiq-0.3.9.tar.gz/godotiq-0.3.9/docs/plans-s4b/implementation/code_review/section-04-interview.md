# Section 04 Code Review Interview

## Auto-fixes Applied

1. **CRITICAL: _set_owner_recursive wired in** — Added `ur.add_do_method(self, "_set_owner_recursive", ...)` to `_op_add_child`, `_op_duplicate`, and `_op_reparent`. Prevents data loss on scene save.

2. **CRITICAL: Empty undo guard fixed** — Removed dangerous `clear_history()` call. Now simply skips `commit_action()` when all ops fail, which discards the action.

3. **Array bounds checking** — Added size validation for position (>= 2 for 2D, >= 3 for 3D), rotation (>= 3), and scale (>= 3) arrays. Returns error instead of crashing.

## Let Go

- **set_property null check false positive**: Rare edge case for null-valued properties. Low risk.
- **sub-path silent no-op for invalid component names**: Low risk, match falls through harmlessly.
- **delete/reparent child index not restored on undo**: Complex to implement with EditorUndoRedoManager, low visual impact.
