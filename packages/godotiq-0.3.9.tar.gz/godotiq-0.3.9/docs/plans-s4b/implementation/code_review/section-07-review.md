# Section 07 Code Review: file_ops

## Verdict: FAIL

## Critical Issues

### C2: `_is_protected` uses absolute `Path.parts` — false positives if project path contains "saves" or ".godot"
**File:** `src/godotiq/tools/bridge/file_ops.py:55-65`

The function receives a fully resolved absolute Path and checks `path.parts`. If the project root is at e.g. `/home/user/saves/my-project/`, every file would be falsely marked as protected. Fix: compute `path.relative_to(root)` first and check parts on the relative path.

## Major Issues

### M1: `_get_root()` duplicates `_resolve()` logic
**File:** `src/godotiq/tools/bridge/file_ops.py:72-77`

Plan doesn't mention a `_get_root()` helper. Root lookup is duplicated between `_resolve` and `_get_root`.

### M5: Empty query in search matches every line
**File:** `src/godotiq/tools/bridge/file_ops.py:237-290`

No validation that `query` is non-empty. Empty string matches every line of every file.

## Minor Issues

### m3: `test_tree_with_depth` doesn't verify depth limiting
### m4: `test_list_filter_scripts` assertion is fragile (uses `names.index`)
