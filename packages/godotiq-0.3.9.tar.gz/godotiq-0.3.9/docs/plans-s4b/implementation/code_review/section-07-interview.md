# Section 07 Code Review Interview

## Triage Summary

| Finding | Decision | Action |
|---------|----------|--------|
| C2: `_is_protected` absolute path false positives | Auto-fix | Use `relative_to(root)` before checking parts |
| M1: `_get_root()` duplication | Let go | Minor, keeps code readable |
| M5: Empty search query matches everything | Auto-fix | Return error when query is empty |
| m3: Weak tree depth test | Auto-fix | Assert subdirs lack children at max_depth=1 |
| m4: Fragile filter test assertion | Auto-fix | Simplify to iterate entries directly |

## Auto-fixes Applied

### Fix C2: `_is_protected` now uses relative path
Changed `_is_protected` to compute `path.relative_to(root)` and check parts on the relative path, preventing false positives when the project root is under a directory named `saves` or `.godot`.

### Fix M5: Empty search query validation
Added `if not query: return {"error": "Search query is required"}` at the top of `_op_search`.

### Fix m3: Stronger tree depth test
Added assertion that subdirectory children at `max_depth=1` don't have a `children` key.

### Fix m4: Simplified filter test assertion
Replaced `names.index(n)` pattern with direct entry iteration.
