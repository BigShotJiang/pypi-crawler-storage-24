# GodotIQ Licensing Plan

## Overview

**22 FREE** (Community) tools + **13 PRO** tools.

PRO tools run fully for all users, then discard the result for Community users
and return only a teaser string with real counts from the analysis.

---

## FREE Tools (22) — Community Edition

Raw operations: read, write, execute, query. No analysis or reasoning.
Any competitor can replicate these with Godot APIs or filesystem access.

| # | Tool | Category | What it does | Requires Addon |
|---|------|----------|-------------|----------------|
| 1 | `godotiq_ping` | infra | Health check, server status & version | No |
| 2 | `godotiq_editor_context` | bridge | Editor state: open scenes, selected nodes, game running | Yes |
| 3 | `godotiq_scene_tree` | bridge | Live editor scene tree with transforms, scripts, groups | Yes |
| 4 | `godotiq_node_ops` | bridge | Batch editing: move, rotate, scale, add, delete, duplicate, reparent | Yes |
| 5 | `godotiq_build_scene` | bridge | Create nodes via patterns (grid, line, scatter, explicit list) | Yes |
| 6 | `godotiq_save_scene` | bridge | Persist editor changes to disk | Yes |
| 7 | `godotiq_script_ops` | bridge | Read/write/patch GDScript with convention validation | Filesystem |
| 8 | `godotiq_file_ops` | bridge | Filesystem: list, read, write, move, delete, search, tree, UID lookup | Filesystem |
| 9 | `godotiq_exec` | bridge | Execute arbitrary GDScript in game or editor context | Yes |
| 10 | `godotiq_run` | bridge | Start/stop the Godot game | Yes |
| 11 | `godotiq_input` | bridge | Simulate player input: actions, keys, UI taps, waits | Yes |
| 12 | `godotiq_screenshot` | bridge | Capture visual frames from game or editor viewport | Yes |
| 13 | `godotiq_camera` | bridge | Editor 3D camera: get position, look_at, focus on node | Yes |
| 14 | `godotiq_state_inspect` | bridge | Query runtime node properties (autoloads, paths, method calls) | Yes |
| 15 | `godotiq_perf_snapshot` | bridge | Real-time performance metrics: FPS, draw calls, memory | Yes |
| 16 | `godotiq_nav_query` | bridge | Live pathfinding via NavigationServer3D | Yes |
| 17 | `godotiq_watch` | bridge | Persistent property monitoring over time | Yes |
| 18 | `godotiq_undo_history` | bridge | Undo/redo state and recent action history | Yes |
| 19 | `godotiq_check_errors` | bridge | Check GDScript files for compilation/parse errors | Yes |
| 20 | `godotiq_ui_map` | bridge | Map all UI elements: positions, text, interactivity | Yes |
| 21 | `godotiq_animation_info` | animation | Extract animation data: tracks, keyframes, state machines | Filesystem |
| 22 | `godotiq_verify_motion` | bridge | Verify node property changes over time (before/after comparison) | Yes |

---

## PRO Tools (13) — Intelligence & Analysis

These tools analyze, reason, predict, and suggest. They are GodotIQ's unique value.
No competitor offers static analysis of Godot projects at this depth.

All PRO tools are **filesystem-only** (no addon required).

| # | Tool | Category | What it does |
|---|------|----------|-------------|
| 1 | `godotiq_project_summary` | memory | Architecture overview, autoloads, conventions, signal health, patterns |
| 2 | `godotiq_file_context` | memory | Deep context for a file: public API, deps, signals, who imports it |
| 3 | `godotiq_dependency_graph` | code | Full dependency graph: imports, reverse deps, signal wiring, impact rating |
| 4 | `godotiq_validate` | code | Convention check: type hints, class_name, orphan signals, naming |
| 5 | `godotiq_signal_map` | code | Project-wide signal wiring: emitters, listeners, orphans, missing |
| 6 | `godotiq_trace_flow` | flow | Trace execution flow from function/signal through entire codebase |
| 7 | `godotiq_impact_check` | flow | Predict what breaks before making a change |
| 8 | `godotiq_animation_audit` | animation | Find animation problems: broken tracks, orphan states, wrong loops |
| 9 | `godotiq_asset_registry` | assets | Asset inventory: categorization, usage tracking, dead-asset detection |
| 10 | `godotiq_scene_map` | spatial | Spatial understanding: positions, distances, directions, bounds |
| 11 | `godotiq_spatial_audit` | spatial | 3D scene linter: floating objects, scale mismatches, z-fighting |
| 12 | `godotiq_suggest_scale` | assets | Recommend scale/position based on similar assets in scene |
| 13 | `godotiq_placement` | spatial | Find safe placement positions with constraint solving |

---

## Community Teaser Strings

When a Community user calls a PRO tool, the tool runs fully (analysis executes),
then the result is discarded and replaced with a teaser showing real counts.

Format: `"[counts from analysis] → upgrade: godotiq.com/pro"`

### Teaser Definitions

Each teaser is built from specific keys in the tool's return dict.

```
godotiq_project_summary
  "{counts.scripts} scripts, {counts.scenes} scenes, {len(autoloads)} autoloads analyzed → upgrade: godotiq.com/pro"
  Example: "42 scripts, 18 scenes, 5 autoloads analyzed → upgrade: godotiq.com/pro"

godotiq_file_context
  "{len(public_api.functions)} public functions, {len(signals_defined)} signals, depended by {len(depended_by)} scripts → upgrade: godotiq.com/pro"
  Example: "12 public functions, 3 signals, depended by 7 scripts → upgrade: godotiq.com/pro"

godotiq_dependency_graph
  "{len(emits_signals)} signals emitted, {len(referenced_by)} reverse refs, impact: {impact_rating} → upgrade: godotiq.com/pro"
  Example: "4 signals emitted, 8 reverse refs, impact: high → upgrade: godotiq.com/pro"

godotiq_validate
  "{total_issues} issues: {by_severity.error} errors, {by_severity.warning} warnings, {by_severity.info} info → upgrade: godotiq.com/pro"
  Example: "14 issues: 0 errors, 6 warnings, 8 info → upgrade: godotiq.com/pro"

godotiq_signal_map
  "{total_signals_defined} signals, {total_connections} connections, {len(orphans)} orphans → upgrade: godotiq.com/pro"
  Example: "23 signals, 47 connections, 3 orphans → upgrade: godotiq.com/pro"

godotiq_trace_flow
  "{total_steps} steps across {files_involved} files, {len(failure_points)} failure points → upgrade: godotiq.com/pro"
  Example: "8 steps across 6 files, 2 failure points → upgrade: godotiq.com/pro"

godotiq_impact_check
  "risk: {risk}, {total_files_affected} files affected, {len(callers)} callers found → upgrade: godotiq.com/pro"
  Example: "risk: high, 5 files affected, 3 callers found → upgrade: godotiq.com/pro"

godotiq_animation_audit
  "{total_animations} animations scanned, {total_issues} issues: {by_severity.critical} critical, {by_severity.warning} warnings → upgrade: godotiq.com/pro"
  Example: "36 animations scanned, 5 issues: 1 critical, 3 warnings → upgrade: godotiq.com/pro"

godotiq_asset_registry
  "{total_assets} assets cataloged, {unused_count} unused ({by_category} categories) → upgrade: godotiq.com/pro"
  Example: "184 assets cataloged, 23 unused (6 categories) → upgrade: godotiq.com/pro"

godotiq_scene_map
  "{total_nodes} nodes mapped, bounds: {spatial_summary.bounds} → upgrade: godotiq.com/pro"
  Example: "47 nodes mapped, bounds: 12x4x8m → upgrade: godotiq.com/pro"

godotiq_spatial_audit
  "{total_issues} issues: {by_severity.warning} warnings, {by_severity.info} info across {len(checks_run)} checks → upgrade: godotiq.com/pro"
  Example: "7 issues: 4 warnings, 3 info across 6 checks → upgrade: godotiq.com/pro"

godotiq_suggest_scale
  "{len(reference_models)} reference models analyzed, match: {match_tier} → upgrade: godotiq.com/pro"
  Example: "5 reference models analyzed, match: same_directory → upgrade: godotiq.com/pro"

godotiq_placement
  "{candidates_evaluated} positions evaluated, {len(suggestions)} valid, {len(excluded_zones)} excluded zones → upgrade: godotiq.com/pro"
  Example: "48 positions evaluated, 3 valid, 2 excluded zones → upgrade: godotiq.com/pro"
```

---

## Design Notes

- **Tool runs fully, result discarded.** The teaser uses real data, not estimates.
  This makes the teaser compelling ("we found 5 issues") and avoids fake counts.
- **License check is a single gate.** One `if not pro:` guard wraps the return.
  The tool function itself is unchanged.
- **`animation_info` is FREE.** It extracts data but doesn't judge.
  The audit tool does the reasoning. Agents need raw animation data to work.
- **`verify_motion` is FREE.** It's a QA utility (before/after comparison).
  The agent needs it to verify its own work. Any competitor can replicate it
  with two `state_inspect` calls and a sleep.
- **All PRO tools are filesystem-only.** They don't need the addon. This means
  PRO value works even without a running Godot editor, which is a selling point.
