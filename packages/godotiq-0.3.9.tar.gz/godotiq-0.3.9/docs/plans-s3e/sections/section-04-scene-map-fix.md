# Section 04 — scene_map: Detail-Dependent Caps and Token Hints

**Status:** IMPLEMENTED

## Overview

This section adds detail-dependent nearby node caps, compact focus-mode output, and token hint fields to `godotiq_scene_map`.

**Priority:** MEDIUM — token optimization, same file as Fix 2 but different function.

## Implementation Summary

**Files modified:**
- `src/godotiq/tools/spatial/__init__.py` — Replaced flat `_MAX_NODES_WITH_FOCUS=30` with `_MAX_NEARBY` dict (brief=10, normal=20, full=30). Focus mode now builds compact node dicts inline (brief: name/type/distance/direction only; normal: adds groups/has_script). Added `token_hint`, `nearby_count`, `nearby_capped`, `nearby_total_in_radius` to result.
- `tests/test_tools/test_scene_map.py` — Added 5 new tests in `TestSceneMapDetailCapsAndTokenHints` class

**Deviations from plan:**
- Added extra test `test_scene_map_normal_compact_output` (from code review)
- `_MAX_NODES_WITH_FOCUS` constant removed entirely (from code review auto-fix)
- `token_hint` added to all results (focus and non-focus), not just focus mode

**Tests:** 26 total (21 existing + 5 new), all passing
