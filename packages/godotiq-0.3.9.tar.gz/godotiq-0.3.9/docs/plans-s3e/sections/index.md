<!-- PROJECT_CONFIG
runtime: python-pip
test_command: pytest tests/ -v
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-signal-map-fix
section-02-spatial-audit-fix
section-03-suggest-scale-fix
section-04-scene-map-fix
section-05-project-summary-fix
END_MANIFEST -->

# Sprint 3e — Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-signal-map-fix | - | - | Yes |
| section-02-spatial-audit-fix | - | - | Yes |
| section-03-suggest-scale-fix | - | - | Yes |
| section-04-scene-map-fix | - | - | Yes |
| section-05-project-summary-fix | - | - | Yes |

All 5 fixes are fully independent — they modify different tool functions in different (or non-overlapping) files. All can run in parallel.

Note: Sections 02 and 04 both modify `src/godotiq/tools/spatial/__init__.py` but touch different functions (`godotiq_spatial_audit` vs `godotiq_scene_map`). They can safely run in parallel as long as they don't overlap lines.

## Execution Order

1. section-01 through section-05 (all parallel — no dependencies between any fixes)

## Section Summaries

### section-01-signal-map-fix
**Fix 1 — CRITICAL:** Eliminate event bus false positives in signal_map `find="missing"` mode. Build project-wide set of all defined signal names, check emissions against it. Adds 2 tests.
- Modifies: `src/godotiq/tools/code/__init__.py`
- Tests: `tests/test_tools/test_signal_map.py`

### section-02-spatial-audit-fix
**Fix 2 — HIGH:** Add `min_severity` parameter to spatial_audit, downgrade sibling z-fighting to "info". Adds severity ordering constant, filtering logic, and parent-path comparison. Adds 4 tests.
- Modifies: `src/godotiq/tools/spatial/__init__.py`
- Tests: `tests/test_tools/test_spatial_audit.py`

### section-03-suggest-scale-fix
**Fix 3 — MEDIUM:** Make `model` optional in suggest_scale, add reference mode. When model=None, search scene for nodes matching `intended_use` and return scale statistics. Adds 4 tests.
- Modifies: `src/godotiq/tools/assets/__init__.py`
- Tests: `tests/test_tools/test_suggest_scale.py`

### section-04-scene-map-fix
**Fix 4 — MEDIUM:** Detail-dependent nearby node caps (brief=10, normal=20, full=30) for focus mode. Compact brief/normal output. Add token hint fields. Adds 4 tests.
- Modifies: `src/godotiq/tools/spatial/__init__.py`
- Tests: `tests/test_tools/test_scene_map.py`

### section-05-project-summary-fix
**Fix 5 — MEDIUM:** Enrich `detail="full"` with autoload signal/reference counts, signal_health summary, and project health metrics. Adds 5 tests.
- Modifies: `src/godotiq/tools/memory/__init__.py`
- Tests: `tests/test_tools/test_project_summary.py`
