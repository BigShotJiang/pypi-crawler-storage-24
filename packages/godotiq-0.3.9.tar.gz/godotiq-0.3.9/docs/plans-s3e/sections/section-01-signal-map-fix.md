Now I have all the context I need. Let me generate the section content.

# Section 01 -- signal_map: Project-Wide Missing Signal Check

## Summary

**Priority: CRITICAL** -- Eliminate false positives in `godotiq_signal_map` when called with `find="missing"`. The current implementation only checks whether an emitted signal is defined in the *same file* that emits it, which produces false positives whenever the Godot Event Bus pattern is used (signals defined in an autoload, emitted from other files). The fix builds a project-wide set of all defined signal names and checks emissions against that set instead.

**Files modified:**
- `src/godotiq/tools/code/__init__.py` (implementation)
- `tests/test_tools/test_signal_map.py` (2 new tests)

**Dependencies:** None. This section is fully independent.

---

## Background

The `_build_signal_map` function in `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/code/__init__.py` has a `find="missing"` code path (lines 393-404) that identifies signals that are emitted but not defined. The current logic iterates over each unique emitter script for each signal name and checks whether that specific emitter script defines the signal:

```python
# Current code (lines 393-404):
# Missing: emitted but not defined in the emitting file
for emitter_path in unique_emitters:
    emitter_gd = session.get_script(emitter_path)
    if emitter_gd is None:
        continue
    emitter_defs = {s.name for s in emitter_gd.signals}
    if name not in emitter_defs:
        missing_list.append({
            "name": name,
            "emitted_in": emitter_path,
            "note": "Emitted but no signal definition found in that file",
        })
```

This per-file check is wrong for the Event Bus pattern, where `events_bus.gd` defines `signal order_accepted` but `order_manager.gd` calls `EventsBus.order_accepted.emit()`. The current code flags `order_accepted` as "missing" in `order_manager.gd` because it only looks at `order_manager.gd`'s own signal definitions.

---

## Tests (Write FIRST)

Add 2 new tests to `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_tools/test_signal_map.py`. These tests use **programmatic injection** into `session._gd_scripts` -- the same pattern already used by the existing `test_signal_map_missing` test (lines 51-61 of the current file).

**CRITICAL: Do NOT add fixture files to `tests/fixtures/sample_project/`.** Adding new `.gd` files would change signal counts that existing tests assert on (e.g., `test_signal_map_all` asserts exactly 6 defined signals and 5 emissions). Use programmatic injection only.

### Test 1: `test_signal_map_events_bus_not_missing`

Add this test to the `TestSignalMapAll` class (or a new class -- either works).

**Purpose:** Verify that a signal emitted in file A but defined in file B (the event bus pattern) is NOT reported as missing.

**Setup:**
1. Use the standard `session` fixture
2. Inject a mock `events_bus.gd` GdScript with `signals=[GdSignal(name="order_accepted", args=[], line=1), GdSignal(name="day_started", args=[], line=2)]`
3. Inject a mock `bus_emitter.gd` GdScript with `signal_emissions=[GdSignalEmission(signal_name="order_accepted", arg_count=0, line=5)]`

**Call:** `_build_signal_map(session, find="missing")`

**Assertions:**
- `"missing"` key exists in result
- No missing signal entry has `name == "order_accepted"` -- the definition in `events_bus.gd` covers the emission in `bus_emitter.gd`

**Cleanup:** Remove both injected scripts from `session._gd_scripts` in a `finally` block (same pattern as existing tests).

### Test 2: `test_signal_map_truly_missing`

**Purpose:** Verify that a signal emitted but not defined *anywhere* in the project IS correctly reported as missing.

**Setup:**
1. Use the standard `session` fixture
2. Inject a mock `broken_emitter.gd` GdScript with `signal_emissions=[GdSignalEmission(signal_name="totally_fake_signal", arg_count=0, line=10)]`
3. No script in the project defines `signal totally_fake_signal`

**Call:** `_build_signal_map(session, find="missing")`

**Assertions:**
- Exactly 1 entry in `result["missing"]` with `name == "totally_fake_signal"`
- That entry has `"emitted_in"` pointing to the broken emitter path

**Cleanup:** Remove the injected script in a `finally` block.

Both tests import `GdScript`, `GdSignal`, and `GdSignalEmission` from `godotiq.parsers.gd_parser` (same imports already used in the existing test file).

---

## Implementation

### Step 1: Add `_collect_all_defined_signals` helper

Add a new function in `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/code/__init__.py`, placed before `_build_signal_map`:

```python
def _collect_all_defined_signals(session: GodotIQSession) -> set[str]:
    """Build project-wide set of all defined signal names.

    Iterates every parsed GdScript in the session and collects
    signal names from each script's .signals list. Used by the
    find="missing" code path to avoid false positives from the
    event bus pattern.
    """
```

The implementation iterates `session._gd_scripts.values()` and collects `sig.name` from each script's `.signals` list into a single `set[str]`.

### Step 2: Modify the `find="missing"` code path in `_build_signal_map`

In the `_build_signal_map` function, the missing-signal detection logic (currently at lines 393-404) needs two changes:

1. **Before the main `for name in all_signal_names:` loop** (line 366), call `_collect_all_defined_signals(session)` to build the project-wide signal set once. This is O(S) where S is total signals across all scripts, and O(1) per lookup.

2. **Replace the per-emitter-file check** (the inner `for emitter_path in unique_emitters:` block at lines 394-404) with a check against the project-wide set. Instead of looking up each emitter's own definitions, simply check whether `name` exists in the project-wide set. If it does NOT exist in the project-wide set, then it is truly missing -- append one entry per emitter to `missing_list`.

3. **Update the note text** from `"Emitted but no signal definition found in that file"` to `"Emitted but no signal definition found in the project"`.

### What does NOT change

- The `find="all"`, `find="orphans"`, and `find="busiest"` modes remain exactly the same
- The scope filtering logic (autoloads, file:, all) remains exactly the same
- The `definitions` dict built from scoped scripts (lines 337-340) still uses `scope_scripts` -- this is for the "defined_in" field in signal entries, not for the missing check
- The project-wide signal set for the missing check always covers ALL scripts (`session._gd_scripts`), regardless of scope
- The output format for missing entries is unchanged: `name`, `emitted_in`, `note`
- The `_MAX_SIGNALS` and `_MAX_BUSIEST` constants are unchanged

### Verification

After implementation, run:
```bash
pytest tests/test_tools/test_signal_map.py -v
```

All existing tests (7 tests) plus the 2 new tests must pass. The existing `test_signal_map_missing` test (which injects `phantom_signal`) will also continue to work correctly because `phantom_signal` is not defined anywhere in the project-wide set either.

---

## Implementation Summary

**Status:** Complete
**Tests:** 9 passing (7 existing + 2 new)

### Files Modified
- `src/godotiq/tools/code/__init__.py` — Added `_collect_all_defined_signals` helper, replaced per-file missing check with project-wide set lookup
- `tests/test_tools/test_signal_map.py` — Added `TestSignalMapEventBus` class with 2 tests, removed unused imports, updated stale docstring

### Code Review Fixes Applied
- Removed unused imports (`dataclass`, `field`, `patch`) from test file
- Updated `test_signal_map_missing` docstring to reflect project-wide behavior

### Deviations from Plan
None — implementation matches plan exactly.