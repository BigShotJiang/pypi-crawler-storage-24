# Section 05 Code Review Interview

## Issue 1: Orphan count key mismatch (CRITICAL) - Auto-fixed
`get_all_signal_connections()` returns qualified keys (`EconomyManager.cash_changed`) while `get_all_signal_emissions()` returns bare names (`cash_changed`). Normalized connection keys with `rsplit(".", 1)[-1]` to match the pattern used in `signal_map` and `validate` tools.

## Issue 2: Missing `signals_emitted` field (MEDIUM) - Auto-fixed
Spec requires `signals_emitted` count per autoload. Added `len(gd.signal_emissions)` to both the normal and `gd is None` branches.

## Issue 3: No correctness test for orphan count - Auto-fixed
Added `test_signal_health_orphan_count_matches_fixture` that verifies orphan count equals the number of emitted signal names in the sample project (which has 0 code-based connections).

## Issue 4: No correctness test for scripts_without_class_name - Let go
The existing `>= 0` check is sufficient for this pass. The fixture data would make the assertion brittle.

## Issue 5: Redundant orphan_signals in health - Let go
Intentional per spec. Both `signal_health.orphan_count` and `health.orphan_signals` reference the same value.

## Issue 6: Function length - Let go
Not in scope for this hardening sprint.

## Issue 7: Test repetition - Let go
Standard pattern in this codebase.

## Added test: `test_summary_full_autoload_has_signals_emitted`
Verifies the new `signals_emitted` field exists as int on all autoload entries.
