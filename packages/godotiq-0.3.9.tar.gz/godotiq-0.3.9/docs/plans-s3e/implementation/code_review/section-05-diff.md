diff --git a/src/godotiq/tools/memory/__init__.py b/src/godotiq/tools/memory/__init__.py
index f10e881..558ddbc 100644
--- a/src/godotiq/tools/memory/__init__.py
+++ b/src/godotiq/tools/memory/__init__.py
@@ -96,13 +96,16 @@ def _build_full(session: GodotIQSession) -> dict:
     for name, script_path in idx.autoloads.items():
         gd = session.get_script(script_path)
         if gd is None:
+            referenced_by = session.get_autoload_dependents(name)
             autoload_analysis[name] = {
                 "script_path": script_path,
                 "class_name": "",
                 "extends": "",
                 "signals": [],
+                "signals_defined": 0,
                 "public_functions": [],
-                "referenced_by": session.get_autoload_dependents(name),
+                "referenced_by": referenced_by,
+                "referenced_by_count": len(referenced_by),
             }
             continue
         public_funcs = [
@@ -110,13 +113,16 @@ def _build_full(session: GodotIQSession) -> dict:
             for f in gd.functions
             if not f.is_private
         ][:_MAX_PUBLIC_FUNCTIONS]
+        referenced_by = session.get_autoload_dependents(name)
         autoload_analysis[name] = {
             "script_path": script_path,
             "class_name": gd.class_name,
             "extends": gd.extends,
             "signals": [s.name for s in gd.signals],
+            "signals_defined": len(gd.signals),
             "public_functions": public_funcs,
-            "referenced_by": session.get_autoload_dependents(name),
+            "referenced_by": referenced_by,
+            "referenced_by_count": len(referenced_by),
         }
 
     # File tree
@@ -156,11 +162,60 @@ def _build_full(session: GodotIQSession) -> dict:
         "uses_groups": uses_groups,
     }
 
+    # Signal health summary
+    all_definitions = session.get_all_signal_definitions()
+    all_emissions = session.get_all_signal_emissions()
+    all_connections = session.get_all_signal_connections()
+
+    total_defined = sum(len(v) for v in all_definitions.values())
+    total_emissions = sum(len(v) for v in all_emissions.values())
+    total_connections = sum(len(v) for v in all_connections.values())
+
+    # Orphan = emitted but never connected-to
+    orphan_count = sum(
+        1 for sig_name in all_emissions if sig_name not in all_connections
+    )
+
+    # Top signals by listener count
+    top_signals = sorted(
+        [
+            {"name": sig, "listeners": len(scripts)}
+            for sig, scripts in all_connections.items()
+        ],
+        key=lambda e: e["listeners"],
+        reverse=True,
+    )[:5]
+
+    signal_health = {
+        "total_defined": total_defined,
+        "total_emissions": total_emissions,
+        "total_connections": total_connections,
+        "orphan_count": orphan_count,
+        "top_signals": top_signals,
+    }
+
+    # Project health
+    autoload_scripts = set(idx.autoloads.values())
+    scripts_without_class_name = sum(
+        1
+        for path, gd in session._gd_scripts.items()
+        if path not in autoload_scripts and not gd.class_name
+    )
+
+    health = {
+        "orphan_signals": orphan_count,
+        "scripts_without_class_name": scripts_without_class_name,
+        "note": f"{orphan_count} signal(s) emitted but never connected to; "
+        f"{scripts_without_class_name} non-autoload script(s) without class_name",
+    }
+
     return {
         "scene_structure": scene_structure,
         "autoload_analysis": autoload_analysis,
         "file_tree": file_tree,
         "detected_patterns": detected_patterns,
+        "signal_health": signal_health,
+        "health": health,
     }
 
 
diff --git a/tests/test_tools/test_project_summary.py b/tests/test_tools/test_project_summary.py
index 0808762..2ec07a4 100644
--- a/tests/test_tools/test_project_summary.py
+++ b/tests/test_tools/test_project_summary.py
@@ -172,6 +172,114 @@ class TestProjectSummaryRequiredFields:
         assert "autoloads" in result
 
 
+class TestProjectSummaryFullAutoloadEnrichment:
+    """Fix 5a: autoload analysis includes signal/reference counts at full detail."""
+
+    def test_summary_full_autoload_has_signals_defined(self, session: GodotIQSession) -> None:
+        from godotiq.tools.memory import _build_project_summary
+
+        result = _build_project_summary(session, "full")
+        for _name, analysis in result["autoload_analysis"].items():
+            assert "signals_defined" in analysis
+            assert isinstance(analysis["signals_defined"], int)
+
+    def test_summary_full_autoload_has_referenced_by_count(self, session: GodotIQSession) -> None:
+        from godotiq.tools.memory import _build_project_summary
+
+        result = _build_project_summary(session, "full")
+        for _name, analysis in result["autoload_analysis"].items():
+            assert "referenced_by_count" in analysis
+            assert isinstance(analysis["referenced_by_count"], int)
+
+    def test_summary_full_autoload_signals_defined_matches_list(self, session: GodotIQSession) -> None:
+        from godotiq.tools.memory import _build_project_summary
+
+        result = _build_project_summary(session, "full")
+        econ = result["autoload_analysis"]["EconomyManager"]
+        assert econ["signals_defined"] == len(econ["signals"])
+
+
+class TestProjectSummaryFullSignalHealth:
+    """Fix 5b: signal_health summary at full detail."""
+
+    def test_summary_full_has_signal_health(self, session: GodotIQSession) -> None:
+        from godotiq.tools.memory import _build_project_summary
+
+        result = _build_project_summary(session, "full")
+        assert "signal_health" in result
+        sh = result["signal_health"]
+        assert "total_defined" in sh
+        assert "total_emissions" in sh
+        assert "total_connections" in sh
+        assert "orphan_count" in sh
+        assert "top_signals" in sh
+
+    def test_signal_health_top_signals_structure(self, session: GodotIQSession) -> None:
+        from godotiq.tools.memory import _build_project_summary
+
+        result = _build_project_summary(session, "full")
+        top = result["signal_health"]["top_signals"]
+        assert isinstance(top, list)
+        for entry in top:
+            assert "name" in entry
+            assert "listeners" in entry
+
+    def test_signal_health_totals_are_nonnegative(self, session: GodotIQSession) -> None:
+        from godotiq.tools.memory import _build_project_summary
+
+        result = _build_project_summary(session, "full")
+        sh = result["signal_health"]
+        assert sh["total_defined"] >= 0
+        assert sh["total_emissions"] >= 0
+        assert sh["total_connections"] >= 0
+        assert sh["orphan_count"] >= 0
+
+
+class TestProjectSummaryFullHealth:
+    """Fix 5c: project health summary at full detail."""
+
+    def test_summary_full_has_health(self, session: GodotIQSession) -> None:
+        from godotiq.tools.memory import _build_project_summary
+
+        result = _build_project_summary(session, "full")
+        assert "health" in result
+        h = result["health"]
+        assert "orphan_signals" in h
+        assert "scripts_without_class_name" in h
+        assert "note" in h
+
+    def test_health_orphan_signals_nonnegative(self, session: GodotIQSession) -> None:
+        from godotiq.tools.memory import _build_project_summary
+
+        result = _build_project_summary(session, "full")
+        assert result["health"]["orphan_signals"] >= 0
+
+    def test_health_scripts_without_class_name_nonnegative(self, session: GodotIQSession) -> None:
+        from godotiq.tools.memory import _build_project_summary
+
+        result = _build_project_summary(session, "full")
+        assert result["health"]["scripts_without_class_name"] >= 0
+
+
+class TestProjectSummaryNoExtrasAtLowerDetail:
+    """signal_health and health should NOT appear at normal or brief."""
+
+    def test_normal_no_signal_health(self, session: GodotIQSession) -> None:
+        from godotiq.tools.memory import _build_project_summary
+
+        result = _build_project_summary(session, "normal")
+        assert "signal_health" not in result
+        assert "health" not in result
+
+    def test_brief_no_signal_health(self, session: GodotIQSession) -> None:
+        from godotiq.tools.memory import _build_project_summary
+
+        result = _build_project_summary(session, "brief")
+        assert "signal_health" not in result
+        assert "health" not in result
+        assert "autoload_analysis" not in result
+
+
 class TestProjectSummaryMCPRegistration:
     """Verify the tool is registered on the MCP server."""
 
