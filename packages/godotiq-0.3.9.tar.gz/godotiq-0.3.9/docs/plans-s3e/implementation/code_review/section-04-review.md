# Section 04 Code Review: scene_map Detail-Dependent Caps

## Summary

Implementation correctly addresses all three parts of Fix 4. Main concerns: dead code, a pass branch, and weak capping test assertions.

## Issues

### 1. [MEDIUM] Dead code: `_MAX_NODES_WITH_FOCUS = 30` kept as "legacy"
No longer referenced. Should be removed.

### 2. [MEDIUM] Empty `pass` branch is code smell
`if focus_node is not None: pass` should be `if focus_node is None:` instead.

### 3. [MEDIUM] Capping test is conditional — may never exercise cap path
`test_scene_map_capped_shows_total` uses `if result.get("nearby_capped")` which passes trivially if scene has <10 nodes.

### 4. [LOW] Focus + full mode duplicates `_node_to_full()` logic
Could drift out of sync if `_node_to_full()` is updated.

### 5. [LOW] No test for full detail focus mode compact output

### 6. [LOW] `token_hint` added unconditionally but only tested in focus mode

## What Looks Good

1. `_MAX_NEARBY` dict cleanly maps detail levels to cap values
2. `nearby_capped` uses correct `>` comparison
3. `nearby_total_in_radius` correctly conditional
4. Brief and normal compact output field sets match plan
5. Non-focus mode correctly unchanged
6. Key names preserved (distance_to_focus, direction_from_focus)
