# Usage Guide — Sprint 3e Hardening Fixes

## Quick Start

All fixes are backward-compatible with default parameters matching previous behavior. No API changes required.

```bash
# Run all tests (455 expected to pass)
uv run pytest tests/ -v
```

## What Changed

### Fix 1: signal_map — No More Event Bus False Positives
```python
# Before: signals emitted via Events bus flagged as "missing"
# After: project-wide signal check eliminates false positives
result = _build_signal_map(session, find="missing")
# Only truly undefined signals appear in missing list
```

### Fix 2: spatial_audit — Severity Filtering
```python
# Default: min_severity="warning" hides sibling z-fighting (now "info")
result = _build_spatial_audit(session, scene, min_severity="warning")
# result["by_severity"]["info"] still shows count
# result["shown_issues"] < result["total_issues"] when filtered

# See everything:
result = _build_spatial_audit(session, scene, min_severity="info")
```

### Fix 3: suggest_scale — Reference Mode
```python
# New: query existing nodes without a model file
result = _build_suggest_scale(session, scene, model=None, intended_use="printer")
# result["mode"] == "reference"
# result["recommended_scale"] = median of matched node scales
```

### Fix 4: scene_map — Reduced Token Output
```python
# Brief mode now caps at 10 nearby nodes (was 30)
result = _build_scene_map(session, scene, focus=node, detail="brief")
# result["nearby_capped"] == True when cap hit
# result["nearby_total_in_radius"] shows pre-cap count
```

### Fix 5: project_summary — Architectural Context
```python
# Full detail now includes signal health and project health
result = _build_project_summary(session, detail="full")
# result["signal_health"]["orphan_count"]  — emitted but never connected
# result["signal_health"]["top_signals"]    — top 5 most-connected
# result["health"]["scripts_without_class_name"]
# result["autoload_analysis"]["EconomyManager"]["signals_defined"]
# result["autoload_analysis"]["EconomyManager"]["signals_emitted"]
```

## Files Modified

| File | Change |
|------|--------|
| `src/godotiq/tools/code/__init__.py` | Fix 1: project-wide signal collection |
| `src/godotiq/tools/spatial/__init__.py` | Fix 2: severity filtering + sibling downgrade; Fix 4: detail caps |
| `src/godotiq/tools/assets/__init__.py` | Fix 3: reference mode |
| `src/godotiq/tools/memory/__init__.py` | Fix 5: signal_health + health enrichment |
| `tests/test_tools/test_signal_map.py` | 2 new tests |
| `tests/test_tools/test_spatial_audit.py` | 4 new tests |
| `tests/test_tools/test_suggest_scale.py` | 4 new tests |
| `tests/test_tools/test_scene_map.py` | 4 new tests |
| `tests/test_tools/test_project_summary.py` | 12 new tests |
