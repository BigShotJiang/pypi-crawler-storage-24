# Sprint 3e Interview Transcript

## Q1: Fix 1 — signal_map missing check scope

**Question:** The spec says check if the signal name is defined 'anywhere in the project'. Should we also handle the case where a signal is emitted via string-based `emit_signal("name")` on a variable (not autoload)?

**Answer:** Project-wide name check is sufficient. If the signal name exists anywhere in any script, it's not "missing". Simple and covers the Events bus case.

## Q2: Fix 2 — spatial_audit severity levels

**Question:** The spec adds 'critical' to severity ordering but the current code only has 'warning' and 'info'. Should any existing checks be elevated to 'critical'?

**Answer:** Future-proofing only. No existing checks become critical. Just add the level so it's available for future use.

## Q3: Fix 5 — project_summary orphan definition

**Question:** For signal_health, should orphan_count count signals defined but never emitted, OR emitted but never connected-to?

**Answer:** Emitted but 0 connections (spec as-is). A signal that's emitted but nobody listens to it. Most actionable for debugging.

## Q4: Fix 3 — suggest_scale recommended_scale computation

**Question:** In reference mode with multiple matches at different scales, median or mode?

**Answer:** Median per-axis. Consistent with existing model-mode behavior.

## Q5: Fix 4 — scene_map cap scope

**Question:** Should detail-dependent caps (10/20/30) apply to both focus and non-focus modes?

**Answer:** Only cap focus mode. Non-focus mode is used for scene overview — keep at 50. Focus mode gets detail-dependent caps (brief=10, normal=20, full=30).
