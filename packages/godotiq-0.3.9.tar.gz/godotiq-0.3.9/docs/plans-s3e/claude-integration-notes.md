# Integration Notes — Opus Review

## Integrated

### 1. Fix severity sort direction (Fix 2) — CRITICAL
**Reviewer:** New ordering `{"critical": 3, "warning": 2, "info": 1}` reverses ascending sort.
**Action:** Use descending rank values `{"critical": 0, "warning": 1, "info": 2}` for ascending sort compatibility. Keeps the filter logic using `<=` threshold. Updated plan.

### 2. Update MCP tool signature for suggest_scale (Fix 3) — CRITICAL
**Reviewer:** The `@mcp.tool()` decorated function must also change.
**Action:** Plan already describes changing the MCP function signature. Clarified that there's only ONE function (the MCP tool IS the implementation). Updated plan.

### 3. Fixture placement (Fix 1) — Use programmatic injection
**Reviewer:** Adding to sample_project breaks existing count assertions.
**Action:** Mandate programmatic injection into session._gd_scripts. No filesystem fixtures needed for signal_map tests. Updated plan.

### 4. Parser handles `.emit()` not `emit_signal()` (Fix 1)
**Reviewer:** Parser regex only matches `signal_name.emit()`.
**Action:** Fixture scripts use `.emit()` syntax only. Updated fixture descriptions. Note: `broken_emitter.gd` must use `totally_fake_signal.emit()` — but this requires a variable reference. Actually, the emission pattern `emit_signal("name")` is captured by a DIFFERENT regex in the parser. Let me verify — but either way, the programmatic injection approach bypasses the parser entirely (inject GdScript objects with pre-built emission lists).

### 5. Nearby node key naming (Fix 4)
**Reviewer:** Plan says "distance, direction" but code uses "distance_to_focus, direction_from_focus".
**Action:** Keep existing key names. Updated test descriptions. No breaking changes.

### 6. `nearby_capped` logic (Fix 4)
**Reviewer:** Use `total_before_cap > cap` instead of `len(nearby) >= cap`.
**Action:** Agreed. Updated plan.

### 7. Input validation for `min_severity` (Fix 2)
**Reviewer:** Invalid values should be handled.
**Action:** Fall back to default "warning" for unrecognized values. Updated plan.

### 8. `referenced_by_count` already available (Fix 5)
**Reviewer:** `session.get_autoload_dependents(name)` exists, just use `len()`.
**Action:** Agreed. Updated plan to note reuse of existing method.

## NOT Integrated

### A. Scope interaction test for Fix 1
**Reviewer:** Suggested additional test for scope + project-wide lookup.
**Why not:** The existing missing signal test already tests the core fix. The scope filtering happens before the missing check — it filters which emissions to examine, not which definitions to check against. The project-wide set is always built from ALL scripts regardless of scope. A dedicated test would be nice but isn't critical. The implementor can add it if time permits.

### B. Fix 5 `scripts_without_class_name` duplication concern
**Reviewer:** Validate tool has similar logic.
**Why not:** The computation is trivial (2 lines). Sharing logic between tools/ subdirectories would require creating a shared utility, which is over-engineering for a count. Accept minor duplication.

### C. Fix 4 test for `detail="full"` cap
**Reviewer:** Missing test for full cap at 30.
**Why not:** The full cap is 30, same as the old flat cap. Existing tests cover this behavior. Adding another test adds no value.

### D. `by_check` counts after filtering
**Reviewer:** Tests should verify by_check counts aren't affected.
**Why not:** by_check counts are computed during the check phase, before filtering. They are inherently pre-filter. No ambiguity here.
