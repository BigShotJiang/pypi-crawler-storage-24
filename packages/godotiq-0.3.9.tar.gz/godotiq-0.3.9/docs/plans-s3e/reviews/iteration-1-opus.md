# Opus Review

**Model:** claude-opus-4
**Generated:** 2026-03-04T08:15:00Z

---

## Overall Assessment

Well-structured plan addressing real production problems. Sound architecture decisions and logical implementation order. Several concrete issues need attention before implementation.

## Critical Issues

### Fix 1: GD parser only supports `.emit()` not `emit_signal()`
The parser regex `(\w+)\.emit\(` only matches Godot 4 style. Fixtures must use `.emit()` exclusively. `broken_emitter.gd` using `emit_signal("totally_fake_signal")` won't be parsed.

### Fix 3: MCP tool signature must also change
The plan only mentions changing the internal function. The `@mcp.tool()` decorated function signature must also change `model: str` to `model: str | None = None` for FastMCP to generate correct JSON schema.

## Medium Issues

### Fix 2: Severity sort direction will break
New ordering `{"critical": 3, "warning": 2, "info": 1}` reverses the sort. Current ascending sort puts warning=0 first. With warning=2, ascending sort puts info=1 first. Must reverse sort or use descending rank values.

### Fix 2: `total_issues` key already exists
Current output already has `total_issues`. Semantics preserved (pre-filter count) but should be explicit.

### Fix 1: Fixture placement risk
Adding scripts to `sample_project` breaks existing signal count assertions. Must use programmatic injection or separate fixture directory.

### Fix 1: Scope interaction
Project-wide signal set must use `session._gd_scripts.values()` (all scripts), not `scope_scripts`.

### Fix 4: Nearby node key naming
Plan says "distance, direction" but code uses "distance_to_focus, direction_from_focus". Keep existing key names.

### Fix 4: `nearby_capped` edge case
`len(nearby) >= cap` is True even when no truncation occurred. Use `total_before_cap > cap`.

### Fix 5: `referenced_by_count` already available
`session.get_autoload_dependents(name)` already exists. Just use `len(referenced_by)`.

## Low Issues

- Missing input validation for `min_severity` parameter
- Missing scope interaction test for Fix 1
- Fix 5 `scripts_without_class_name` duplicates validate tool logic
- Need to update MCP tool docstrings
- Fix 4 missing test for `detail="full"` cap

## Action Items (Priority Order)

1. Fix severity sort direction (Fix 2)
2. Update MCP tool signature for suggest_scale (Fix 3)
3. Clarify fixture placement (Fix 1) — use programmatic injection
4. Confirm parser behavior and update fixture descriptions (Fix 1)
5. Resolve nearby node key naming (Fix 4)
6. Fix nearby_capped logic (Fix 4)
7. Add input validation for min_severity (Fix 2)
8. Add scope interaction test for Fix 1
9. Update MCP tool docstrings for all modified tools
