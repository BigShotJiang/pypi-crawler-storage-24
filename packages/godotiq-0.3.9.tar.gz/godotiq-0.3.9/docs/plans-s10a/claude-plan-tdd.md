# Sprint 10a: TDD Plan — Agent Efficiency & Quality Assurance

Testing framework: pytest with pytest-asyncio (asyncio_mode = "auto")
Test location: `tests/` directory, organized by category
Conventions: Pure Python unit tests with mocked bridge responses, no live Godot

---

## Section 1: Editor State in Every Response

### Tests to write BEFORE implementing

```python
# Test: _editor_state dict has required keys (open_scene, game_running, recent_errors)
# Test: open_scene is a string (path or empty)
# Test: game_running is a boolean
# Test: recent_errors is a list of strings
# Test: recent_errors contains at most 3 entries even if buffer has 10
# Test: _editor_state is present in build_scene response (mocked bridge)
# Test: _editor_state is present in node_ops response (mocked bridge)
# Test: _editor_state defaults to {} when not in bridge response (backward compat)
# Test: apply_output_limit preserves _editor_state without truncation
# Test: apply_output_limit still truncates other keys normally when _editor_state present
```

---

## Section 2: Pre-flight Scene Checks

### Tests to write BEFORE implementing

```python
# Test: preflight error message contains "godotiq_exec" when no scene open
# Test: preflight error message contains "open_scene_from_path" instruction
# Test: preflight passes when scene is open (mocked bridge returns success)
# Test: preflight error for wrong scene includes both current and expected scene names
# Test: preflight error for wrong scene suggests save before switch
# Test: preflight check does NOT auto-open scenes (no side effect)
```

Note: These test the Python-side handling of preflight error responses from the bridge. The actual GDScript preflight logic runs in Godot and is tested manually.

---

## Section 3: Grid Connectivity Validation

### Tests to write BEFORE implementing

```python
# Test: validate_grid_connectivity with empty overrides returns no warnings
# Test: validate_grid_connectivity with single override returns no warnings
# Test: validate_grid_connectivity with connected L-shaped path returns no warnings
# Test: validate_grid_connectivity with connected T-shaped path returns no warnings
# Test: validate_grid_connectivity with straight line path returns no warnings
# Test: validate_grid_connectivity with isolated tile (no neighbors) returns warning
# Test: validate_grid_connectivity with two disconnected clusters returns warnings for isolated tiles
# Test: validate_grid_connectivity skips overrides that have custom "position" key
# Test: validate_grid_connectivity parses keys as "row,col" format correctly
# Test: validate_grid_connectivity warning message includes tile coordinates
# Test: build_scene tool result includes "warnings" key after grid+overrides call
# Test: build_scene tool result has empty warnings when grid has no connectivity issues
```

---

## Section 4: MCP Prompt — QA Checklist

### Tests to write BEFORE implementing

No automated tests for prompt content — this is markdown text. Verify manually that:
- QA section exists in prompt after "Creation Workflow" and before "Error Recovery"
- All 6 steps are present
- "NEVER say I can see" constraint is included
- Prompt file loads without errors in server.py

```python
# Test: godot_development_prompt_v2.md is loadable (no syntax errors in embedded markers)
# Test: prompt contains "MANDATORY: Final QA" section header
# Test: prompt contains "spatial_audit" in QA section
# Test: prompt contains "NEVER say" or "You CANNOT see" constraint
```

---

## Section 5: MCP Prompt — Efficiency Rules

### Tests to write BEFORE implementing

```python
# Test: prompt contains "Efficiency Rules" section header
# Test: prompt contains "Don't overthink" rule
# Test: prompt contains "Batch operations" rule
# Test: prompt contains "_editor_state" reference in efficiency rules
# Test: "Efficiency Rules" appears before "Creation Workflow" in prompt (ordering check)
```
