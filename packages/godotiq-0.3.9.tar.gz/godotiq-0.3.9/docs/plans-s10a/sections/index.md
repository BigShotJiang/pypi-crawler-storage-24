<!-- PROJECT_CONFIG
runtime: python-uv
test_command: uv run pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-editor-state
section-02-preflight-checks
section-03-grid-validation
section-04-prompt-updates
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-editor-state | - | section-02 | Yes |
| section-02-preflight-checks | section-01 | - | No |
| section-03-grid-validation | - | - | Yes |
| section-04-prompt-updates | - | - | Yes |

## Execution Order

1. Batch 1 (parallel): section-01-editor-state, section-03-grid-validation, section-04-prompt-updates
2. Batch 2 (sequential): section-02-preflight-checks (depends on section-01)

## Section Summaries

### section-01-editor-state
Add `_editor_state` injection to `send_response()` and `_send_error()` in `godotiq_server.gd`. Add `_recent_errors` ring buffer, `_get_editor_state()` helper, `_record_error()` method. Wire debugger error capture in `godotiq_debugger.gd`. Add Python-side backward compatibility (default `_editor_state` to `{}` if missing). Exclude `_editor_state` from `apply_output_limit()`.

**Files**: `godot-addon/addons/godotiq/godotiq_server.gd`, `godot-addon/addons/godotiq/godotiq_debugger.gd`, `src/godotiq/tools/bridge/build_scene.py` (backward compat), output limit handling

**Tests**: _editor_state structure validation, backward compatibility, apply_output_limit preservation

### section-02-preflight-checks
Add `_preflight_scene_check()` helper to `godotiq_server.gd`. Call at top of `_handle_build_scene` and `_handle_node_ops`. Return actionable errors (no auto-open). Error responses include `_editor_state` via `_send_error()` (from section-01).

**Files**: `godot-addon/addons/godotiq/godotiq_server.gd`

**Tests**: Preflight error message content, actionable instructions

### section-03-grid-validation
Add `validate_grid_connectivity()` function to `build_scene.py` (Python-side). Pure computation on override keys — no Godot APIs. Call after bridge request for grid+overrides mode. Include `warnings` in tool result.

**Files**: `src/godotiq/tools/bridge/build_scene.py`

**Tests**: Connected paths, isolated tiles, single override, custom position exclusion, disconnected groups, warning message format

### section-04-prompt-updates
Add "Efficiency Rules" and "MANDATORY: Final QA" sections to `godot_development_prompt_v2.md`. Efficiency rules go after detail level rules. QA checklist goes after Creation Workflow, before Error Recovery.

**Files**: `src/godotiq/prompts/godot_development_prompt_v2.md`

**Tests**: Prompt contains expected section headers and key rules
