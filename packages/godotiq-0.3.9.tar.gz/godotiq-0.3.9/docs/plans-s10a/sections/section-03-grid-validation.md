Now I have a thorough understanding of all the relevant context. Let me produce the section content.

# Section 03: Grid Connectivity Validation

## Overview

This section adds a pure Python function `validate_grid_connectivity()` to `src/godotiq/tools/bridge/build_scene.py` that checks whether grid override tiles form a connected path (4-connectivity: up/down/left/right). It also integrates this validation into the `build_scene` tool wrapper so the result dict includes a `"warnings"` key after grid+overrides requests.

This section has no dependencies on other sections and can be implemented in parallel with sections 01, 02, and 04.

## Background

The `build_scene` tool supports a `grid` mode where nodes are placed in a rows x cols grid. Overrides allow specific grid cells to use different scenes, properties, or positions. The GDScript addon uses the key format `"%d,%d" % [row, col]` (e.g., `"2,3"` means row 2, column 3) for the overrides dictionary.

A common agent mistake is creating grid overrides that are supposed to form a connected path (e.g., a road network) but accidentally leave gaps or isolated tiles. This validation catches that problem on the Python side before the agent moves on, so it can fix the issue immediately.

## Files to Modify

- `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/bridge/build_scene.py` -- Add `validate_grid_connectivity()` function and integrate it into the `build_scene()` async function.
- `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/bridge/__init__.py` -- Integrate warnings passthrough in the `godotiq_build_scene` MCP tool wrapper.
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_tools/test_build_scene.py` -- Add new test classes for grid connectivity validation.

## Tests (Write First)

All tests go in `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_tools/test_build_scene.py`. Add the following test classes after the existing test classes.

### Test Class: `TestGridConnectivityValidation`

Tests for the `validate_grid_connectivity()` function directly. Import it from `godotiq.tools.bridge.build_scene`.

```python
# Test: empty overrides returns no warnings (empty list)
# Test: single override returns no warnings (valid use case, fewer than 2 overrides)
# Test: connected L-shaped path returns no warnings
#   Example overrides: {"0,0": {}, "1,0": {}, "2,0": {}, "2,1": {}, "2,2": {}}
#   This forms an L from (0,0) down to (2,0) then right to (2,2)
# Test: connected T-shaped path returns no warnings
#   Example: {"0,0": {}, "0,1": {}, "0,2": {}, "1,1": {}}
# Test: straight line path (horizontal) returns no warnings
#   Example: {"0,0": {}, "0,1": {}, "0,2": {}, "0,3": {}}
# Test: isolated tile among multiple overrides returns warning
#   Example: {"0,0": {}, "0,1": {}, "5,5": {}}
#   Tile at (5,5) has no adjacent neighbor, should produce a warning
# Test: two disconnected clusters returns warnings for isolated tiles
#   Example: {"0,0": {}, "0,1": {}, "3,3": {}, "3,4": {}}
#   Both clusters are internally connected but there are no warnings
#   because each tile has at least one neighbor within the overrides set
#   WAIT -- per the algorithm, it checks if each tile has at least one adjacent
#   override neighbor. Both clusters have internal adjacency, so NO warnings.
#   Only truly isolated tiles (no adjacent override neighbors at all) produce warnings.
# Test: single truly isolated tile with no neighbors returns warning
#   Example: {"0,0": {}, "5,5": {}}
#   Both tiles are isolated from each other (no adjacency), both get warnings
# Test: overrides with custom "position" key are excluded from validation
#   Example: {"0,0": {}, "0,1": {}, "5,5": {"position": [10, 0, 10]}}
#   Tile (5,5) has custom position so it's skipped -- no warning for it
# Test: parses keys as "row,col" format correctly (verifies integer parsing)
# Test: warning message includes the tile coordinates (e.g., "2,3" or "(2, 3)")
```

### Test Class: `TestBuildSceneWarningsPassthrough`

Tests that the `build_scene()` async function (and/or the `godotiq_build_scene` MCP wrapper) includes `"warnings"` in the result after a grid+overrides call. These tests require mocking the bridge.

```python
# Test: build_scene tool result includes "warnings" key after grid+overrides call (mocked bridge)
# Test: build_scene tool result has empty warnings list when grid has no connectivity issues
```

For the passthrough tests, mock `get_bridge()` to return a mock that resolves `bridge.request(...)` with a success dict. Then call `build_scene(grid={...})` and check the returned dict has a `"warnings"` key.

## Implementation Details

### `validate_grid_connectivity()` Function

Add this function to `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/bridge/build_scene.py`.

**Signature:**

```python
def validate_grid_connectivity(overrides: dict, spacing: float) -> list[str]:
    """Validate that override tiles form a connected path with no isolated tiles.

    Uses 4-connectivity (up/down/left/right). Overrides with a custom 'position'
    key are excluded from validation since their world-space location doesn't
    match the grid layout.

    Args:
        overrides: Dict mapping "row,col" strings to override data dicts.
        spacing: Grid cell spacing (currently unused but passed for future use).

    Returns:
        List of warning strings for isolated tiles, or empty list if all valid.
    """
```

**Algorithm:**

1. If `overrides` has fewer than 2 entries, return `[]` immediately (single override is a valid use case; nothing to check connectivity against).
2. Parse override keys to extract `(row, col)` integer pairs. Keys use `"row,col"` format (e.g., `"2,3"` means row=2, col=3). Split on `","`, convert to int. Skip keys that don't parse correctly.
3. Filter out overrides where the value dict contains a `"position"` key. These tiles have custom world-space positions, so grid adjacency checks would produce false positives.
4. If fewer than 2 tiles remain after filtering, return `[]`.
5. Build a set of all `(row, col)` tuples from the remaining overrides.
6. For each coordinate in the set, check if it has at least one adjacent neighbor in the set. Adjacent means exactly one of: `(row-1, col)`, `(row+1, col)`, `(row, col-1)`, `(row, col+1)`.
7. If a coordinate has zero adjacent neighbors in the set, add a warning string like `"Isolated tile at (row, col) has no adjacent override neighbors"`.
8. Return the list of warning strings.

**Key points:**
- Only 4-connectivity (not diagonal). This is a deliberate limitation documented in the function docstring.
- The `spacing` parameter is accepted for potential future use but not used in the current algorithm (adjacency is grid-based, not distance-based).
- Override values that contain a `"position"` key are excluded because their world-space location was explicitly set, so checking grid adjacency would produce false positives.

### Integration in `build_scene()` Async Function

Modify the `build_scene()` function in `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/bridge/build_scene.py`. After the bridge request returns successfully, check if the mode was `grid` and the grid dict contains `overrides`:

```python
async def build_scene(
    grid: dict | None = None,
    line: dict | None = None,
    scatter: dict | None = None,
    nodes: list[dict] | None = None,
    parent: str = "",
    target_scene: str = "",
) -> dict:
    # ... existing validation ...
    # ... existing bridge.request() call ...
    result = await bridge.request(...)

    # After successful bridge request, validate grid connectivity
    if grid is not None and isinstance(grid.get("overrides"), dict):
        warnings = validate_grid_connectivity(
            grid["overrides"],
            float(grid.get("spacing", 1.0)),
        )
        result["warnings"] = warnings

    return result
```

The `"warnings"` key is added to the result dict directly. An empty list means no issues. If there are issues, each entry is a human-readable warning string.

### MCP Wrapper Passthrough

The `godotiq_build_scene` wrapper in `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/bridge/__init__.py` already returns the result from `_build_scene()` (after applying output limits). The `"warnings"` key will flow through naturally since `apply_output_limit` only truncates list values when the overall output exceeds the character limit. Since warnings are typically a short list of strings, they will not be truncated in practice.

No changes to the MCP wrapper are strictly necessary, but the implementer should verify that warnings pass through by running the passthrough tests.

## Limitations

- Only checks 4-connectivity (up/down/left/right), not diagonal adjacency. A tile at `(0,0)` with only a diagonal neighbor at `(1,1)` would be flagged as isolated.
- Does not validate world-space distances -- only grid coordinate adjacency.
- Override tiles with a custom `"position"` key in their value dict are excluded from validation entirely.
- The function does not distinguish between "two internally-connected clusters that are disconnected from each other" and "fully connected." It only flags individual tiles with zero adjacent override neighbors. Two separate groups of 2+ connected tiles will NOT produce warnings (each tile in each group has at least one neighbor).