# Integration Notes — Opus Review Feedback

## Integrated (will change the plan)

### Issue #1: Inject `_editor_state` in `send_response()` itself
**Verdict: INTEGRATE.** This is the single most impactful simplification. Instead of modifying 17+ handler functions, modify `send_response()` to merge `_editor_state` into the response dict before serializing. One change, catches everything including game-forwarded responses.

### Issue #2: Handler list is inaccurate
**Verdict: INTEGRATE.** Remove the inaccurate handler list from the plan. With the `send_response()` injection approach, individual handlers don't matter.

### Issue #3: Prompt file path is wrong
**Verdict: INTEGRATE.** Fix to `src/godotiq/prompts/godot_development_prompt_v2.md`.

### Issue #4: Move grid connectivity validation to Python
**Verdict: INTEGRATE.** Move `_validate_grid_connectivity()` to `build_scene.py` on the Python side. This is pure computation on override keys and spacing — no Godot APIs needed. Enables pure Python unit testing.

### Issue #7: Remove pre-flight auto-open, return error instead
**Verdict: INTEGRATE.** Auto-opening scenes is a risky side effect (discards unsaved changes). Instead, return actionable error: "Scene 'res://X.tscn' is open but you requested 'res://Y.tscn'. Call godotiq_exec('EditorInterface.open_scene_from_path(\"res://Y.tscn\")') to switch."

### Issue #8: Fix grid key format to `"row,col"`
**Verdict: INTEGRATE.** Code uses `"%d,%d" % [row, col]`, so keys are `"row,col"`. Fix documentation.

### Issue #9: Handle overrides with custom positions
**Verdict: INTEGRATE.** Skip distance validation for overrides that specify a custom `position`. Only validate adjacency for grid-computed positions.

### Issue #10: Single override should not warn
**Verdict: INTEGRATE.** Only check connectivity when 2+ overrides exist. A single override is a valid use case.

### Issue #12: `_send_error` should also include `_editor_state`
**Verdict: INTEGRATE.** Error responses are the most important time for the agent to have context. Modify `_send_error()` to also attach `_editor_state`.

### Issue #16: Backward compatibility for `_editor_state` on Python side
**Verdict: INTEGRATE.** Python bridge should default `_editor_state` to `{}` if not present in response.

### Issue #17: Verify `apply_output_limit()` doesn't strip `_editor_state`
**Verdict: INTEGRATE.** Exclude `_editor_state` from output limiting. It's a small fixed-size dict.

## Not Integrated (reasons below)

### Issue #5: `_editor_state` increases payload
**Not integrating.** The `_editor_state` dict is tiny (~3 keys, ~200 bytes). Not worth the complexity of making it optional.

### Issue #6: `_record_error` wiring underspecified
**Not integrating as separate change.** The `send_response()` injection approach simplifies this. Error recording will be specified in the updated plan's Section 1.

### Issue #14: `_editor_state` on `_handle_editor_context` is redundant
**Not integrating.** Redundancy is acceptable and consistency is more valuable. Agent code can rely on `_editor_state` being present in EVERY response without special-casing.

### Issue #15: Thread safety
**Not integrating.** GDScript is single-threaded cooperative. No issue.

### Issue #18: File change summary incomplete
**Addressed by integrating #1, #3, #4.** The file list will be updated.

### Issue #19: "Working memory" is vague
**Not integrating.** The prompt instruction is clear enough in context — agents understand "don't repeat tool calls" means within the conversation.

### Issue #20: QA checklist is advisory
**Not integrating.** Programmatic enforcement would require changing all tool return values to include QA results. That's a future sprint. Prompt-based guidance is the right first step.

## Summary of Plan Changes

1. Section 1: Change from per-handler injection to `send_response()` injection. Also inject in `_send_error()`.
2. Section 2: Remove auto-open behavior. Return actionable error for wrong scene.
3. Section 3: Move grid validation to Python (`build_scene.py`). Fix key format. Skip custom-position overrides. Only validate 2+ overrides.
4. Section 4: Fix filename to `godot_development_prompt_v2.md`.
5. Section 5: Fix filename to `godot_development_prompt_v2.md`.
6. Add backward compatibility: Python defaults `_editor_state` to `{}` if missing.
7. Add `apply_output_limit()` exclusion for `_editor_state`.
