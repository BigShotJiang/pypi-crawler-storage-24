# Integration Notes — Opus Review Feedback

## Integrating

### #4 Session Manager Race Condition → INTEGRATE
Add `asyncio.Lock` to `get_bridge()` in session.py. Simple fix, prevents real bugs with concurrent tool calls.

### #12 Missing Cleanup Hook → INTEGRATE
Add `close_bridge()` call in server lifespan's finally block. Important for clean shutdown.

### #14 Missing Tool Annotations → INTEGRATE
Specify correct annotations per tool. `godotiq_run` is destructive. Others are open-world.

### #6 Tool Registration Clarity → INTEGRATE
Clarify: `@mcp.tool()` goes in `tools/bridge/__init__.py` (the registrar), individual files export plain async functions. Matches the pattern where `__init__.py` is the entry point.

### #1 Websockets Version → INTEGRATE
Already decided: `>=14.0`. Update all references consistently.

### #3 Config Schema → INTEGRATE
Clarify: Python side uses `GODOTIQ_ADDON_PORT` env var only. GDScript side reads `.godotiq.json` independently. No changes to `config.py`.

### #10 `_peer_tcp` Cleanup → INTEGRATE
Add cleanup of `_peer_tcp` alongside `_peers` on disconnect. Trivial fix.

### #18 GDScript Input Validation → INTEGRATE
Already in the spec code — `_handle_message()` validates JSON parsing and extracts id/method with defaults. No change needed, but good to note.

## NOT Integrating

### #2 Security Token — NOT INTEGRATING
The user explicitly decided localhost-only is sufficient (Interview Q5). This is a development tool, not production. Adding auth complicates setup for minimal benefit in the dev-tool context. Can be added in a future sprint if needed.

### #9 Viewport Parameter — NOT INTEGRATING
Keep the parameter for forward compatibility. Sprint 4b-4d will add editor viewport support. Removing it now and re-adding later is worse than having a not-yet-used parameter.

### #11 Retry Logic Scope — NOT INTEGRATING
The spec says "follow exactly." The retry catches BridgeTimeoutError and BridgeError, which is reasonable for screenshot. Connection errors propagate naturally since `get_bridge()` would fail before `request_with_retry` is called.

### #13 EngineDebugger Buffer Limits — NOT INTEGRATING
This is a runtime concern, not a plan change. The 0.5x default scale is already a guardrail. Will be tested during manual Godot testing.

### #5 _listen_loop Lifecycle — NOT INTEGRATING
Already handled in the spec code: `_listen_loop` has a try/except that catches all exceptions, fails pending futures, and sets `_connected = False`.

### #8 Polling Optimization — NOT INTEGRATING
Premature optimization. Editor already runs `_process()` on dozens of nodes. One more poll per frame is negligible.

### #15 Additional Tests — NOT INTEGRATING
The spec defines the exact tests to write. Adding more tests is scope creep. Can be added in a follow-up.

### #17 WebSocket Import Error — NOT INTEGRATING
Already in the spec code: `connection.py` has a try/except ImportError with clear message.

### #19 Protocol Versioning — NOT INTEGRATING
Good idea for future, but scope creep for Sprint 4a. The `ping` response already returns `addon_version`.

### #7, #16, #20 — NOT INTEGRATING
Low-priority cosmetic issues. Peer ID generation is specified in the spec code (incrementing counter). The addon distribution model is out of scope.
