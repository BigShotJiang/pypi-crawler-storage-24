# Sprint 4a Interview Transcript

## Q1: WebSocket Library Version Target

**Q:** The spec uses `websockets>=12.0` but research shows v14+ changed the default API significantly. Should we target `websockets>=12.0` or `websockets>=14.0`?

**A:** Use the new (v14+) and verify compatibility. Where it's not compatible, resolve it.

## Q2: MCP Context Parameter

**Q:** Should bridge tools accept `ctx: Context = None` to follow the existing tool pattern?

**A:** Include ctx parameter — consistent with existing tools, future-proof.

## Q3: WebSocket Max Message Size

**Q:** Default max_size is 1MB. Screenshots can exceed that. What size?

**A:** Set max_size=16MB — safe for any screenshot size including unscaled 4K.

## Q4: Spec Fidelity

**Q:** Follow spec code exactly or adapt where research suggests improvements?

**A:** Follow spec exactly. Copy the code as written, minimal surprises.

## Q5: WebSocket Security

**Q:** Should there be authentication on the WebSocket connection?

**A:** Localhost-only is sufficient. Binding to 127.0.0.1 is enough.

## Q6: Reconnection Behavior

**Q:** When bridge connection drops, auto-reconnect or return error?

**A:** Auto-reconnect lazily. Next tool call tries to reconnect automatically.

## Q7: Run API Design

**Q:** Add a toggle action to godotiq_run, or keep play/stop separate?

**A:** Keep play/stop separate. Matches the spec, clear and explicit.
