# Section 03 Code Review Interview

## Auto-fixes Applied

### Bug 1: JSON string parsing in runtime (CRITICAL)
Server sends `JSON.stringify(params)` — runtime now parses the JSON string before passing to `_take_screenshot`. Handles both String (from server) and Dictionary (direct call) inputs.

### Bug 2: Null texture guard
Added separate `get_texture()` null check before calling `get_image()` to prevent null dereference crash.

### Bug 3: Dimensions after resize
Now updates `w` and `h` after resize so screenshot metadata reflects actual encoded dimensions.

### Bug 4: Scale bounds validation
Added `clampf(scale, 0.1, 1.0)` to prevent zero/negative/upscale values.

### Issue 5: Old session signal disconnect
`_setup_session` now disconnects `started`/`stopped` signals from previous session before connecting to new one.

## Let Go

### Issue 6: send_to_game return bool
Would change API contract with server. Timeout fallback (5-30s) is acceptable for now. Can be improved if latency becomes an issue.

### Issue 7: Spec deviation on mapping keys
Implementation is correct for actual server code. Spec had wrong mapping.

### Issue 8: Out-of-scope Python changes
Unstaged from this commit — they belong to prior section work.
