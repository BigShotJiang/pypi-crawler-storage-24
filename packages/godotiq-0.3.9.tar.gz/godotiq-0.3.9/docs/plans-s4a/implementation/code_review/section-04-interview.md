# Section 04 Code Review Interview

## Auto-fixes Applied

### Issue 1: Duplicate event handlers on reconnect
connect() now clears game_started/game_stopped handler lists before re-registering internal handlers. User-registered handlers on other events are preserved.

### Issue 3: send() failure dangling future
Wrapped ws.send() in try/except — cleans up pending future and raises BridgeConnectionError on send failure.

### Issue 6: _game_running not reset on disconnect
disconnect() now resets _game_running=False. connect() also resets it.

## Let Go

### Issue 2: Silent exception swallow in _listen_loop
Acceptable — the finally block handles cleanup (fails pending futures, sets _connected=False). Adding logging would introduce a logging dependency for a library package.

### Issue 4: Race between request() and _listen_loop
Cooperative asyncio — ws.send() will raise on closed socket. Lock overhead not justified.

### Issue 5: Missing async tests
The spec-defined tests for section 04 are exactly what was implemented. Section 07 is dedicated to integration tests with mocked WebSocket.

### Issue 7: Mutable dict in frozen dataclass
Standard Python idiom. frozen=True prevents field reassignment which is sufficient.

### Issue 8: No __all__
Internal package, not a public API.
