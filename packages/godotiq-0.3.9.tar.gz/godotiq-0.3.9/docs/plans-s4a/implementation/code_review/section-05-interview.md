# Section 05 Code Review Interview

## Triage Summary

| # | Issue | Disposition |
|---|-------|-------------|
| 1 | Race in lazy lock init | Let go — asyncio single-threaded, coroutines yield only at await |
| 2 | Stubs raise NotImplementedError | Auto-fixed — return error dicts instead |
| 3 | No catch-all in wrappers | User chose: Add catch-all `except Exception` |
| 4 | `format` shadows builtin | Let go — matches plan, standard param name |
| 5 | Missing `__all__` | Let go — not required by project conventions |
| 6 | Port parsing no error handling | Auto-fixed — wrap with fallback to DEFAULT_PORT |
| 7 | `close_bridge` disconnect errors | Auto-fixed — wrap in try/except pass |
| 8 | `get_bridge_or_none` broad catch | Let go — matches plan intent |
| 9 | No logging in session.py | Let go — can add later |
| 10 | Keyword args not enforced | Let go — matches plan signatures |

## Fixes Applied

1. **Stubs return error dicts** (screenshot.py, run.py, perf_snapshot.py, editor_context.py): Changed from `raise NotImplementedError` to `return {"error": "Not yet implemented", "hint": "..."}`
2. **Port parsing fallback** (session.py): Wrapped `int()` in try/except, falls back to DEFAULT_PORT
3. **close_bridge error handling** (session.py): Wrapped `disconnect()` in try/except pass
4. **Catch-all in wrappers** (tools/bridge/__init__.py): Added `except Exception as e: return {"error": f"Unexpected error: {e}"}` to all 4 tool wrappers
