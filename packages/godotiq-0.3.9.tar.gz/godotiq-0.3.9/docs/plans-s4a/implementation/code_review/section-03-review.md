# Section 03 Code Review: Godot Debugger Runtime

## Critical Bugs

### 1. Runtime receives JSON string, not Dictionary
**File:** godotiq_runtime.gd line 18
**Severity:** Critical

The server sends params via `debugger.send_to_game(msg_type, [JSON.stringify(params)])` — so `data[0]` is a JSON string, not a Dictionary. The guard `data[0] is Dictionary` always evaluates false, silently dropping screenshot scale/format params.

**Fix:** Parse the JSON string before the type check.

### 2. Null pointer crash on viewport.get_texture()
**File:** godotiq_runtime.gd line 34
**Severity:** High

Guards against null viewport but not null texture. If viewport has no texture yet, this crashes.

**Fix:** Guard `get_texture()` separately.

### 3. Screenshot sends original dimensions after resize
**File:** godotiq_runtime.gd lines 42-58
**Severity:** Medium

`w` and `h` captured before resize, sent after. Metadata claims original size, payload is scaled size.

**Fix:** Update w/h after resize.

### 4. Scale bounds not validated
**File:** godotiq_runtime.gd line 44
**Severity:** Low

`scale=0.0` or negative passes the `< 1.0` guard and calls `resize(0, 0)`.

**Fix:** Clamp scale to [0.1, 1.0].

## Missing Error Handling

### 5. _setup_session doesn't disconnect old session signals
**File:** godotiq_debugger.gd line 48-55
**Severity:** Medium

If game restarts, old session signals remain connected. Could fire stale started/stopped.

**Fix:** Disconnect old session signals before storing new session.

### 6. send_to_game failures not propagated
**File:** godotiq_debugger.gd line 69-77
**Severity:** Low

When send fails, only pushes warning. Pending request hangs until timeout.

**Fix:** Return bool so server can resolve pending request immediately.

## Spec Deviations

### 7. _capture mapping keys differ from spec
Spec says `handle_game_response("screenshot", data)`, implementation uses `handle_game_response("godotiq:screenshot", data)`. Implementation is correct for actual server code — spec had wrong mapping.

### 8. Out-of-scope Python changes in staged diff
The diff includes Python file changes from prior work. Should be staged separately.
