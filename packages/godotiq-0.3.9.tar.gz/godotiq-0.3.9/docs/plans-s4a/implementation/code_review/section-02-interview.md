# Section 02 Code Review Interview

## Auto-fixes Applied

### 1. Fixed was_string_packet() ordering
- Now calls `get_packet()` first, then checks `was_string_packet()`
- Prevents packet type misclassification

### 2. Cached port in _ready()
- Added `_port` instance variable, set in `_ready()`
- `get_port()` now returns cached value instead of re-parsing config

### 3. Wired debugger reference in plugin
- Added `_server.debugger = _debugger` to `godotiq_plugin.gd`
- Without this, all game-forward requests would fail with NO_DEBUGGER

### 4. Duplicate request ID protection
- Request keys now prefixed with peer_id: `"%d:%s" % [peer_id, id]`
- Prevents two peers using the same id from overwriting each other

### 5. Fixed get_open_scenes() double call
- Cached to local variable instead of calling twice per iteration

## Let Go
- No Engine.is_editor_hint() guard — script only instantiated by EditorPlugin
- _exit_tree doesn't poll after close — Godot handles TCP teardown
- PARSE_ERROR with empty id — acceptable per spec
