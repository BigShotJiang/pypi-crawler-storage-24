# Section 04 Code Review: Python Protocol & Connection

## Medium Severity

### 1. Duplicate event handlers on reconnect
connect() appends _on_game_started/_on_game_stopped every call. Reconnect pattern causes N-fold handler accumulation.

### 2. _listen_loop silently swallows exceptions
bare `except Exception: pass` makes connection loss invisible.

### 3. send() failure leaves dangling future
If ws.send() raises, the pending future is never cleaned up.

### 4. Race between request() and _listen_loop
_connected check then ws.send() has a yield point where state could change.

### 5. Missing async test coverage
Only 9/23 tests for connection — no mocked WebSocket tests for request(), retry, listen loop, disconnect cleanup.

### 6. _game_running not reset on disconnect
is_game_running can still return True after disconnect().

## Low Severity

### 7. Frozen dataclass with mutable dict
params dict is mutable despite frozen=True.

### 8. No __all__ exports
Neither module defines __all__.
