diff --git a/godot-addon/addons/godotiq/godotiq_plugin.gd b/godot-addon/addons/godotiq/godotiq_plugin.gd
new file mode 100644
index 0000000..06d1569
--- /dev/null
+++ b/godot-addon/addons/godotiq/godotiq_plugin.gd
@@ -0,0 +1,37 @@
+@tool
+extends EditorPlugin
+## GodotIQ editor plugin — lifecycle manager for the addon.
+## Creates and wires the WebSocket server, debugger plugin, and runtime autoload.
+
+const AUTOLOAD_NAME := "GodotIQRuntime"
+const RUNTIME_PATH := "res://addons/godotiq/godotiq_runtime.gd"
+
+var _server  # WebSocket server node (godotiq_server.gd)
+var _debugger  # EditorDebuggerPlugin (godotiq_debugger.gd)
+
+
+func _enter_tree() -> void:
+	# 1. Create WebSocket server as child node
+	_server = preload("res://addons/godotiq/godotiq_server.gd").new()
+	add_child(_server)
+
+	# 2. Create debugger plugin, wire server reference, register it
+	_debugger = preload("res://addons/godotiq/godotiq_debugger.gd").new()
+	_debugger.server = _server
+	add_debugger_plugin(_debugger)
+
+	# 3. Register runtime autoload singleton
+	add_autoload_singleton(AUTOLOAD_NAME, RUNTIME_PATH)
+
+
+func _exit_tree() -> void:
+	# 1. Remove autoload singleton
+	remove_autoload_singleton(AUTOLOAD_NAME)
+
+	# 2. Remove and null debugger plugin
+	remove_debugger_plugin(_debugger)
+	_debugger = null
+
+	# 3. Free and null server node
+	_server.queue_free()
+	_server = null
diff --git a/godot-addon/addons/godotiq/plugin.cfg b/godot-addon/addons/godotiq/plugin.cfg
new file mode 100644
index 0000000..beef210
--- /dev/null
+++ b/godot-addon/addons/godotiq/plugin.cfg
@@ -0,0 +1,7 @@
+[plugin]
+
+name="GodotIQ"
+description="AI-assisted Godot development via MCP bridge"
+author="GodotIQ"
+version="2.0.0"
+script="godotiq_plugin.gd"
