diff --git a/src/godotiq/tools/bridge/editor_context.py b/src/godotiq/tools/bridge/editor_context.py
index 1f410f0..40bae3c 100644
--- a/src/godotiq/tools/bridge/editor_context.py
+++ b/src/godotiq/tools/bridge/editor_context.py
@@ -1,8 +1,33 @@
-"""Editor context tool implementation — stub for Section 06."""
+"""Editor context tool — get live editor state or filesystem fallback."""
 
 from __future__ import annotations
 
+import os
+
+from godotiq.bridge.session import get_bridge_or_none
+
 
 async def editor_context() -> dict:
-    """Get the current editor state from the Godot addon."""
-    return {"error": "Not yet implemented", "hint": "Bridge tool implementations will be available after Section 06."}
+    """Get the current editor state from the Godot addon.
+
+    Returns connected editor state (open scenes, selected nodes, game state,
+    project path) when the addon is running, or a filesystem-based fallback
+    when disconnected.
+
+    Returns:
+        Dict with editor context and addon_connected flag.
+    """
+    bridge = await get_bridge_or_none()
+
+    if bridge is not None:
+        result = await bridge.request("editor_context")
+        result["addon_connected"] = True
+        return result
+
+    project_path = os.environ.get("GODOTIQ_PROJECT_ROOT", "")
+    return {
+        "addon_connected": False,
+        "project_path": project_path,
+        "note": "GodotIQ addon not connected. Editor state unavailable. "
+                "Enable the addon in Godot to get live editor context.",
+    }
diff --git a/src/godotiq/tools/bridge/perf_snapshot.py b/src/godotiq/tools/bridge/perf_snapshot.py
index 9f8724e..e8e0a49 100644
--- a/src/godotiq/tools/bridge/perf_snapshot.py
+++ b/src/godotiq/tools/bridge/perf_snapshot.py
@@ -1,8 +1,16 @@
-"""Performance snapshot tool implementation — stub for Section 06."""
+"""Performance snapshot tool — capture runtime metrics from the Godot game."""
 
 from __future__ import annotations
 
+from godotiq.bridge.session import get_bridge
+
 
 async def perf_snapshot() -> dict:
-    """Capture a performance snapshot from the running Godot game."""
-    return {"error": "Not yet implemented", "hint": "Bridge tool implementations will be available after Section 06."}
+    """Capture a performance snapshot from the running Godot game.
+
+    Returns:
+        Dict with fps, draw_calls, triangles, objects, texture_mem, buffer_mem,
+        video_mem, total_nodes, orphan_nodes.
+    """
+    bridge = await get_bridge()
+    return await bridge.request("perf_snapshot")
diff --git a/src/godotiq/tools/bridge/run.py b/src/godotiq/tools/bridge/run.py
index ace727b..4864680 100644
--- a/src/godotiq/tools/bridge/run.py
+++ b/src/godotiq/tools/bridge/run.py
@@ -1,11 +1,29 @@
-"""Run tool implementation — stub for Section 06."""
+"""Run tool — start or stop the Godot game from the editor."""
 
 from __future__ import annotations
 
+from godotiq.bridge.session import get_bridge
+
 
 async def run(
     action: str = "play",
     scene: str = "main",
 ) -> dict:
-    """Start or stop the Godot game from the editor."""
-    return {"error": "Not yet implemented", "hint": "Bridge tool implementations will be available after Section 06."}
+    """Start or stop the Godot game from the editor.
+
+    Args:
+        action: "play" to start, "stop" to halt the running game.
+        scene: Which scene to run — "main", "current", or a res:// path.
+            Only used with action="play".
+
+    Returns:
+        Dict with action and scene fields.
+    """
+    bridge = await get_bridge()
+
+    if action == "stop":
+        await bridge.request("stop")
+        return {"action": "stop"}
+
+    await bridge.request("run", params={"scene": scene})
+    return {"action": "play", "scene": scene}
diff --git a/src/godotiq/tools/bridge/screenshot.py b/src/godotiq/tools/bridge/screenshot.py
index 312c291..119e25b 100644
--- a/src/godotiq/tools/bridge/screenshot.py
+++ b/src/godotiq/tools/bridge/screenshot.py
@@ -1,12 +1,36 @@
-"""Screenshot tool implementation — stub for Section 06."""
+"""Screenshot tool — capture viewport images from the running Godot game."""
 
 from __future__ import annotations
 
+from godotiq.bridge.session import get_bridge
+
+VALID_FORMATS = {"webp", "png", "jpg"}
+
 
 async def screenshot(
     viewport: str = "game",
     scale: float = 0.5,
     format: str = "webp",
 ) -> dict:
-    """Capture a screenshot from the running Godot game."""
-    return {"error": "Not yet implemented", "hint": "Bridge tool implementations will be available after Section 06."}
+    """Capture a screenshot from the running Godot game.
+
+    Args:
+        viewport: Which viewport to capture ("game").
+        scale: Image scale factor (0.0-1.0). Values outside range clamped to 0.5.
+        format: Image format ("webp", "png", "jpg"). Invalid values fall back to "webp".
+
+    Returns:
+        Dict with image (base64), format, width, height.
+    """
+    if scale <= 0 or scale > 1.0:
+        scale = 0.5
+    if format not in VALID_FORMATS:
+        format = "webp"
+
+    bridge = await get_bridge()
+    return await bridge.request_with_retry(
+        "screenshot",
+        params={"viewport": viewport, "scale": scale, "format": format},
+        max_retries=3,
+        retry_delay=0.5,
+    )
