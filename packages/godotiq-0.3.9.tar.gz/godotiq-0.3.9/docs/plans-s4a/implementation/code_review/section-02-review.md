# Section 02 Code Review

## HIGH: was_string_packet() called before get_packet() — packet misclassification
## HIGH: get_port() re-parses config instead of returning cached port
## HIGH: debugger reference never set by plugin (cross-section wiring gap)
## MEDIUM: Duplicate request IDs from different peers silently overwrite
## MEDIUM: EditorInterface.get_open_scenes() called twice per iteration
## LOW: No Engine.is_editor_hint() guard
## LOW: _exit_tree doesn't poll after close
## LOW: PARSE_ERROR uses empty string id
