# Section 01 Code Review Interview

## Auto-fixes Applied (no user input needed)

### 1. Added null guards in _exit_tree()
- Wrapped `remove_debugger_plugin` and `queue_free` in null checks
- Prevents crash if _enter_tree() fails partway through

### 2. Created stub files for preloaded dependencies
- `godotiq_server.gd`: minimal Node stub
- `godotiq_debugger.gd`: minimal EditorDebuggerPlugin stub with `var server`
- These will be replaced by Sections 02 and 03

### 3. Ensured trailing newline at EOF

## Let Go
- Untyped vars: intentional per spec (circular dep avoidance)
