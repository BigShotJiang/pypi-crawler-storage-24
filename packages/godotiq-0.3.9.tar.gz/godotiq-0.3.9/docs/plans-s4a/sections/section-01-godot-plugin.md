Now I have all the context I need. Let me generate the section content.

# Section 1: Godot Addon -- Plugin Configuration and Lifecycle

## Overview

This section creates the Godot editor addon directory structure and the two foundational files: the plugin configuration (`plugin.cfg`) and the EditorPlugin lifecycle manager (`godotiq_plugin.gd`). These files are pure GDScript/INI and contain no Python code.

The EditorPlugin is the root orchestrator that starts and stops all other addon components (WebSocket server, debugger plugin, runtime autoload). Sections 2 and 3 depend on this section being complete.

## Tests

There are no Python tests for this section. GDScript files are validated manually in the Godot 4.x editor by enabling the plugin in Project Settings > Plugins. Validation criteria:

- Plugin appears in the Godot editor's plugin list with name "GodotIQ" and version "2.0.0"
- Enabling the plugin does not produce errors in the Godot output console
- Disabling then re-enabling the plugin cleans up and re-creates components without errors
- The autoload "GodotIQRuntime" appears in Project Settings > Autoload when the plugin is enabled, and is removed when disabled

## Files to Create

```
godot-addon/addons/godotiq/plugin.cfg
godot-addon/addons/godotiq/godotiq_plugin.gd
```

Both files live under `/Users/salvatorefarruggio/Desktop/godotiq/godot-addon/addons/godotiq/`.

A `.gitkeep` already exists in that directory and can be removed or left in place (it is inert).

## File 1: plugin.cfg

**Path:** `/Users/salvatorefarruggio/Desktop/godotiq/godot-addon/addons/godotiq/plugin.cfg`

This is a standard Godot plugin configuration file in INI format. It declares the plugin metadata so Godot knows how to load it.

**Required fields:**

| Field | Value |
|-------|-------|
| `name` | `"GodotIQ"` |
| `description` | `"AI-assisted Godot development via MCP bridge"` |
| `author` | `"GodotIQ"` |
| `version` | `"2.0.0"` |
| `script` | `"godotiq_plugin.gd"` |

The `[plugin]` section header is required. The `script` field must point to the EditorPlugin script relative to the addon directory.

**Structure:**

```ini
[plugin]

name="GodotIQ"
description="AI-assisted Godot development via MCP bridge"
author="GodotIQ"
version="2.0.0"
script="godotiq_plugin.gd"
```

## File 2: godotiq_plugin.gd

**Path:** `/Users/salvatorefarruggio/Desktop/godotiq/godot-addon/addons/godotiq/godotiq_plugin.gd`

This is an `@tool` script extending `EditorPlugin`. It is the lifecycle manager for the entire addon -- responsible for creating, wiring, and destroying all sub-components.

### Constants

Two constants define the runtime autoload configuration:

- `AUTOLOAD_NAME = "GodotIQRuntime"` -- the name of the autoload singleton registered in the project
- `RUNTIME_PATH = "res://addons/godotiq/godotiq_runtime.gd"` -- the path to the game-side runtime script

### Instance Variables

Three private variables hold references to the managed components:

- `_server` -- the WebSocket server node (type: `godotiq_server.gd`, created in Section 2)
- `_debugger` -- the EditorDebuggerPlugin instance (type: `godotiq_debugger.gd`, created in Section 3)

### _enter_tree() Method

Called by Godot when the plugin is enabled. Performs setup in this exact order:

1. **Create WebSocket server node** -- Instantiate the server script (`godotiq_server.gd`) as a child node using `preload()` and `add_child()`. Store the reference in `_server`.
2. **Register EditorDebuggerPlugin** -- Instantiate the debugger script (`godotiq_debugger.gd`) via `preload()`. Wire the server reference by setting `_debugger.server = _server` (this cross-reference allows the debugger to forward game responses to the server). Register via `add_debugger_plugin(_debugger)`.
3. **Register runtime autoload** -- Call `add_autoload_singleton(AUTOLOAD_NAME, RUNTIME_PATH)` to register the game-side runtime script. This ensures the runtime is loaded automatically when any scene is played.

### _exit_tree() Method

Called by Godot when the plugin is disabled. Performs teardown in reverse order of setup:

1. **Remove autoload** -- Call `remove_autoload_singleton(AUTOLOAD_NAME)`
2. **Remove debugger plugin** -- Call `remove_debugger_plugin(_debugger)`, then set `_debugger = null`
3. **Free server node** -- Call `_server.queue_free()`, then set `_server = null`

Reverse order is important to avoid dangling references (the debugger holds a reference to the server, so the server must be freed last).

### Script Structure (Skeleton)

The GDScript file should follow this structure. Note that this is a skeleton showing the class layout, annotations, constants, variable declarations, and method signatures with their documented behavior:

```gdscript
@tool
extends EditorPlugin
## GodotIQ editor plugin — lifecycle manager for the addon.
## Creates and wires the WebSocket server, debugger plugin, and runtime autoload.

const AUTOLOAD_NAME := "GodotIQRuntime"
const RUNTIME_PATH := "res://addons/godotiq/godotiq_runtime.gd"

var _server  # WebSocket server node (godotiq_server.gd)
var _debugger  # EditorDebuggerPlugin (godotiq_debugger.gd)


func _enter_tree() -> void:
    # 1. Create WebSocket server as child node
    # 2. Create debugger plugin, wire server reference, register it
    # 3. Register runtime autoload singleton
    ...


func _exit_tree() -> void:
    # 1. Remove autoload singleton
    # 2. Remove and null debugger plugin
    # 3. Free and null server node
    ...
```

The `preload()` calls should reference:
- `"res://addons/godotiq/godotiq_server.gd"` for the server
- `"res://addons/godotiq/godotiq_debugger.gd"` for the debugger

Use `.new()` on the preloaded scripts to create instances. For the server, it is a `Node`-based script so it needs `add_child()` to participate in the scene tree and receive `_process()` calls. For the debugger, it is an `EditorDebuggerPlugin` that is registered via `add_debugger_plugin()` (not added as a child).

### Cross-Reference Wiring

The debugger plugin needs access to the server so it can call `server.handle_game_response()` when game-side messages arrive. This is achieved by setting an untyped `server` variable on the debugger instance:

```gdscript
_debugger.server = _server
```

The debugger declares `var server` without a type annotation to avoid circular dependency issues between the GDScript files.

## Dependencies

- **Depends on:** Nothing. This is a root section with no dependencies.
- **Blocks:** Section 2 (WebSocket Server) and Section 3 (Debugger + Runtime) both depend on this section's files existing, as they are referenced by `preload()` and as parent infrastructure.

## Important Notes

- The `@tool` annotation is mandatory -- without it, the script will not run in the editor context.
- All GDScript files use English for comments and variable names per project convention.
- The server node is created via `preload(...).new()` pattern, not `load()`, because `preload()` is resolved at parse time and catches missing files immediately.
- The `_server` variable must be added as a child of the plugin node so it receives `_process()` callbacks (needed for the WebSocket polling loop in Section 2).
- The autoload singleton path uses `res://` prefix, which points to the project root where the addon is installed.

## Implementation Notes (Post-Build)

### Files Created
- `godot-addon/addons/godotiq/plugin.cfg` — plugin metadata
- `godot-addon/addons/godotiq/godotiq_plugin.gd` — EditorPlugin lifecycle
- `godot-addon/addons/godotiq/godotiq_server.gd` — stub (replaced by Section 02)
- `godot-addon/addons/godotiq/godotiq_debugger.gd` — stub (replaced by Section 03)

### Deviations from Plan
1. **Added null guards in `_exit_tree()`**: `if _debugger:` and `if _server:` guards prevent crashes if `_enter_tree()` fails partway through (code review finding).
2. **Created stub files**: Minimal `godotiq_server.gd` and `godotiq_debugger.gd` stubs so `preload()` doesn't fail at parse time. These will be replaced by Sections 02 and 03.

## Verification

After implementing this section, verify in the Godot editor:

1. Open a Godot 4.x project that has the addon installed (copy `godot-addon/addons/godotiq/` into the project's `addons/` directory)
2. Go to Project > Project Settings > Plugins
3. "GodotIQ" should appear with version "2.0.0"
4. Enable the plugin -- no errors should appear in the Output panel
5. Check Project Settings > Autoload -- "GodotIQRuntime" should be listed
6. Disable the plugin -- "GodotIQRuntime" should be removed from Autoload, no errors