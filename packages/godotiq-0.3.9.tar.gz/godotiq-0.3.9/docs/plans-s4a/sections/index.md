<!-- PROJECT_CONFIG
runtime: python-uv
test_command: uv run pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-godot-plugin
section-02-godot-server
section-03-godot-debugger-runtime
section-04-python-protocol-connection
section-05-python-session-registration
section-06-python-bridge-tools
section-07-tests
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-godot-plugin | - | 02, 03 | Yes |
| section-02-godot-server | 01 | 03 | No |
| section-03-godot-debugger-runtime | 01, 02 | - | No |
| section-04-python-protocol-connection | - | 05, 06 | Yes |
| section-05-python-session-registration | 04 | 06 | No |
| section-06-python-bridge-tools | 05 | 07 | No |
| section-07-tests | 04, 06 | - | No |

## Execution Order

1. section-01-godot-plugin, section-04-python-protocol-connection (parallel — independent)
2. section-02-godot-server, section-05-python-session-registration (parallel — different dependency chains)
3. section-03-godot-debugger-runtime, section-06-python-bridge-tools (parallel — different chains)
4. section-07-tests (final — needs all Python sections complete)

## Section Summaries

### section-01-godot-plugin
Plugin metadata (plugin.cfg) and EditorPlugin lifecycle manager (godotiq_plugin.gd).

### section-02-godot-server
WebSocket server using TCPServer + WebSocketPeer.accept_stream(). Request dispatch, editor-side handlers, game-side forwarding.

### section-03-godot-debugger-runtime
EditorDebuggerPlugin (editor-side IPC) and game runtime autoload (screenshot, perf snapshot).

### section-04-python-protocol-connection
Bridge package init, protocol dataclasses (BridgeRequest, BridgeResponse, BridgeEvent), parse_message, timeouts. Async WebSocket client (BridgeConnection) with connect, disconnect, request, retry, events.

### section-05-python-session-registration
Bridge session manager (singleton with asyncio.Lock), tool registration in tools/bridge/__init__.py, server.py import, pyproject.toml dependency.

### section-06-python-bridge-tools
Four tool implementation files: screenshot.py, run.py, perf_snapshot.py, editor_context.py.

### section-07-tests
Test package init, test_protocol.py, test_connection.py, test_tools.py. All use mocks.
