# Work Plan: Update Popup Dialog

**Date**: 2026-03-21
**Scope**: Add an AcceptDialog popup when a new GodotIQ version is detected via PyPI check
**Files affected**: `godot-addon/addons/godotiq/godotiq_server.gd`

---

## Context

The PyPI update check already exists in `godotiq_server.gd`:
- `_check_for_update()` fires an HTTP request to PyPI on first `_ready()`
- `_on_update_check_completed()` compares versions and updates the bottom panel `status_label`
- `_update_checked: bool` prevents re-checking on plugin reload

The bottom panel behavior must remain unchanged.

## Task

Add an `AcceptDialog` popup that appears once per editor session when an update is available.

### Implementation Steps

#### 1. Add popup creation in `_on_update_check_completed()`

Inside the existing `if _is_newer_version(...)` block (line 111), after the `status_label` update:

1. Create an `AcceptDialog` instance
2. Set `title` = `"GodotIQ Update Available"`
3. Set `dialog_text` = `"GodotIQ vX.Y.Z is available (you have vA.B.C).\n\nRun in terminal:\npip install --upgrade godotiq && godotiq install-addon ."` (using `remote_version` and `ADDON_VERSION`)
4. Set `ok_button_text` = `"Got it"`
5. Add as child of the server node (`add_child(dialog)`)
6. Connect both `confirmed` and `canceled` signals to `dialog.queue_free` (cleanup on OK or window close button)
7. Call `popup_centered()` to show it

#### 2. One-per-session guarantee

Already handled: `_update_checked` flag ensures `_check_for_update()` runs only once. The callback `_on_update_check_completed` fires at most once, so the popup can only appear once per session. No additional guard needed.

### What NOT to change

- PyPI check logic (`_check_for_update`, `_on_update_check_completed` flow, `_is_newer_version`)
- Bottom panel status label update
- `ADDON_VERSION` constant
- No new dependencies

## Verification

1. Set `ADDON_VERSION` to an old value (e.g., `"0.0.1"`) temporarily
2. Enable the plugin in Godot editor
3. Confirm the popup appears with correct text and "Got it" button
4. Confirm the bottom panel also shows the update text (unchanged behavior)
5. Disable and re-enable the plugin — popup should NOT appear again (same session)
6. Restore `ADDON_VERSION` to original value

## Risk Assessment

- **Low risk**: Single file change, ~10 lines of GDScript added
- **No regressions**: Existing bottom panel logic untouched
- **No new dependencies**: Uses built-in Godot `AcceptDialog` class
