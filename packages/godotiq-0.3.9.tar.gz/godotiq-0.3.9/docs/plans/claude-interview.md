# Sprint 1 — TSCN Parser Interview Transcript

## Q1: API Signature — path vs content?
**Question**: The spec says parse_tscn takes a path, but the existing placeholder takes content (string). Should we change the signature to accept a file path (and read internally), keep the current string-based API, or provide both?

**Answer**: File path API. `parse_tscn(path: str)` reads the file and returns TscnScene. Matches spec intent and integrates naturally with FileCache.

## Q2: Euler angle units — radians or degrees?
**Question**: For Euler angle output, should rotation be in radians (like Godot internally) or degrees?

**Answer**: Radians. Matches Godot internal representation. Tools can convert to degrees for display.

## Q3: Large PackedByteArray/PackedFloat32Array values?
**Question**: Research found that main.tscn may contain large base64-encoded mesh data on single lines. How should these be handled?

**Answer**: Parse as raw string. Store the raw string value without decoding. Keeps parser fast and simple — decoded data rarely needed by tools.

## Q4: Dataclass design — extend or create new?
**Question**: The existing TscnNode dataclass is minimal. The spec requires many more fields. Should we extend the existing dataclass or create new ones alongside it?

**Answer**: Extend + add new types. Extend TscnNode with new fields AND add new dataclasses for resources, connections, etc.

## Q5: Query/utility API — methods or standalone?
**Question**: The spec mentions utility functions for integration tests (find_node_by_path, get_all_scripts, etc.). Where should these live?

**Answer**: Methods on TscnScene. `scene.find_node('path')`, `scene.get_nodes_by_group('name')`, etc. Natural API for tool implementations.

## Q6: Error handling — strict or resilient?
**Question**: What should happen when parsing encounters malformed lines?

**Answer**: Skip and warn. Log a warning, skip the malformed line/section, continue parsing. Partial results are better than no results.
