# Integration Notes — Opus Review Feedback

## Integrating

### 1. Multiline Property Values (Critical #1)
**Integrating.** Adding bracket/brace depth tracking to the parser architecture. Adding dictionary literal parsing to the value parser. This is critical for main.tscn.

### 2. Missing Fixture File (Critical #2)
**Integrating.** The user's spec says furniture_slot_placeholder.tscn should be provided. Will create the fixture file based on spec description, OR retarget tests to main.tscn sub_resources. Decision: create the fixture since it's described in the spec.

### 3. Negative Scale / Determinant Check (Critical #3)
**Integrating.** Adding determinant sign check to Transform3D decomposition Step 4-5.

### 4. Property Delimiter ` = ` (Significant #6)
**Integrating.** Specifying space-equals-space as delimiter.

### 5. Groups Array in Header (Significant #7)
**Integrating.** Adding explicit array-in-header parsing for groups attribute.

### 6. Instance ExtResource in Header (Significant #8)
**Integrating.** Specifying that header attribute values can be ExtResource references.

### 7. Blank Lines and Comments (Moderate #12)
**Integrating.** Adding explicit skip for blank lines and `;` comment lines.

### 8. Warning Mechanism (Minor #19)
**Integrating.** Using Python `logging` module with `logger = logging.getLogger(__name__)`.

### 9. File Encoding UTF-8 (Minor #16)
**Integrating.** Specifying `encoding="utf-8"` in file open.

### 10. Test Count Fix (Minor #20)
**Integrating.** Fixing count to 22 or adding one more test.

### 11. Scalar Exact Matching (Minor #15)
**Integrating.** Specifying exact string match for true/false/null.

## NOT Integrating

### unique_id Type (Significant #4)
**Not integrating.** Keeping as `int | None`. The values are numeric in all known Godot versions. If they change, it's a simple migration.

### Arbitrary Section Ordering (Significant #5)
**Not integrating for now.** Godot's serializer always outputs in order. Hand-edited files are rare. The parser will still handle any section at any time (since transitions are "next `[` header"), but won't explicitly design for backwards transitions.

### 2D Transform Decomposition (Moderate #9)
**Not integrating.** Explicitly deferred — this is a 3D-focused sprint. Transform2D values stored as tuples.

### parent_node Reference (Minor #18)
**Not integrating.** Keeping parent as str path. Avoids circular references. Tools can use find_node.

### resources Field Removal (Moderate #13)
**Integrating implicitly.** The field will be replaced by ext_resources and sub_resources.
