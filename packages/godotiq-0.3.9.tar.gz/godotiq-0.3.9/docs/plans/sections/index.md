<!-- PROJECT_CONFIG
runtime: python-pip
test_command: pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-value-parser
section-02-dataclasses
section-03-state-machine
section-04-tree-queries
section-05-fixtures-unit-tests
section-06-integration-sprint0
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-value-parser | - | 03 | Yes |
| section-02-dataclasses | - | 03, 04, 05 | Yes |
| section-03-state-machine | 01, 02 | 04, 05, 06 | No |
| section-04-tree-queries | 02, 03 | 05, 06 | No |
| section-05-fixtures-unit-tests | 01, 02, 03, 04 | 06 | No |
| section-06-integration-sprint0 | 03, 04, 05 | - | No |

## Execution Order

1. section-01-value-parser, section-02-dataclasses (parallel, no dependencies)
2. section-03-state-machine (after 01 AND 02)
3. section-04-tree-queries (after 02 AND 03)
4. section-05-fixtures-unit-tests (after all implementation sections)
5. section-06-integration-sprint0 (final)

## Section Summaries

### section-01-value-parser
Create `src/godotiq/parsers/value_parser.py` with all value type parsing logic. Includes:
- Scalar parsing (bool, int, float, null, string)
- Vector/math types (Vector2, Vector3, Color, Rect2, AABB, Quaternion, etc.)
- Reference types (ExtResource, SubResource, NodePath, StringName)
- Packed arrays (stored as raw strings)
- Array and dictionary parsing with recursive nesting
- Transform3D decomposition with YXZ Euler angles and determinant sign check
- Pre-compiled regex patterns for performance

### section-02-dataclasses
Extend `src/godotiq/parsers/tscn_parser.py` with new dataclass definitions:
- SceneHeader (format, load_steps, uid)
- ExtResource (id, type, path, uid)
- SubResource (id, type, properties)
- Connection (signal, from_node, to_node, method, flags, binds)
- Extended TscnNode (parent, instance, unique_id, groups, script, position, rotation, scale, metadata)
- Extended TscnScene (header, ext_resources, sub_resources, root, nodes, connections)
- Change parse_tscn signature from content to path-based API

### section-03-state-machine
Implement the line-by-line state machine parser in `tscn_parser.py`:
- Section header detection and parsing (regex-based)
- Header attribute parsing (quoted strings, bare ints, arrays, ExtResource refs)
- Property line parsing with ` = ` delimiter
- Multiline value accumulation via bracket/brace depth tracking
- State transitions: INITIAL → FILE_HEADER → EXT_RESOURCE → SUB_RESOURCE → NODE → CONNECTION
- Node-specific handling (script, transform, metadata extraction)
- Blank line and comment skipping
- Logging-based warnings for malformed input

### section-04-tree-queries
Implement tree reconstruction and query methods:
- Pass 2: Build parent-child hierarchy from flat node list using parent paths
- find_node(path) — traverse tree by slash-separated path
- get_nodes_by_group(group) — filter by group membership
- get_nodes_by_type(type_name) — filter by node type
- get_all_scripts() — collect unique script resource paths
- get_all_instances() — collect unique instanced scene paths
- Graceful handling of missing resource IDs

### section-05-fixtures-unit-tests
Create test fixture and write all unit tests:
- Create `tests/fixtures/furniture_slot_placeholder.tscn` (37 lines, 6 nodes)
- Write 23 unit tests in `tests/test_parsers/test_tscn_parser.py`
- Tests cover: header, resources, nodes, groups, transforms, instances, properties, metadata, edge cases
- Write `tests/test_parsers/test_value_parser.py` for value parser unit tests

### section-06-integration-sprint0
Write integration tests and update Sprint 0:
- Write 6 integration tests in `tests/test_parsers/test_tscn_integration.py`
- Update `tests/test_server.py` — change parse_tscn test from NotImplementedError to FileNotFoundError
- Run full test suite to confirm 0 failures
- Verify performance: main.tscn parsed in < 200ms
