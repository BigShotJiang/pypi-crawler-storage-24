# BILLING.md — fooddb-jp 課金アーキテクチャ

> 内部ドキュメント。Stripe 連携の構成、Webhook フロー、API キー管理の仕組み。

---

## アーキテクチャ概要

```
ユーザー
  ↓ ランディングページ「Subscribe →」
Stripe Checkout（Stripe ホスト）
  ↓ 決済完了
Stripe Webhook → POST /billing/webhook
  ↓ checkout.session.completed
API キー自動発行 → api_keys テーブルに INSERT
  ↓
ユーザーが MCP config に API キーを設定
  ↓
MCP / REST API リクエスト
  ↓ Authorization: Bearer fdb_xxx
check_rate_limit() → api_keys.requests_today +1
```

---

## 料金プラン

| プラン | 月額 | 日次上限 | 対象 |
|---|---|---|---|
| Free | ¥0 | 100 req/日 | 評価用。API キー不要 |
| Developer | $9.99 | 10,000 req/日 | 個人開発者・小規模アプリ |
| Pro | $29.99 | 100,000 req/日 | 商用アプリ・チーム |
| Admin | — | 無制限 | 内部用（MCP サーバー等） |

---

## 環境変数

```bash
# .env に設定
STRIPE_SECRET_KEY=sk_test_xxxx       # Stripe Secret Key
STRIPE_WEBHOOK_SECRET=whsec_xxxx     # Webhook Signing Secret
STRIPE_PRICE_DEVELOPER=price_xxxx    # Developer プランの Price ID
STRIPE_PRICE_PRO=price_xxxx          # Pro プランの Price ID
FOODDB_ADMIN_KEY=fdb_admin_xxxx      # 管理 API キー
FOODDB_BASE_URL=https://fooddb.navii.online
```

---

## Stripe 構成

### Products & Prices（setup_stripe_products.py で作成済み）

| Product | Price ID | 金額 | Billing |
|---|---|---|---|
| fooddb-jp Developer | `price_xxx` | $9.99/月 | Recurring (monthly) |
| fooddb-jp Pro | `price_xxx` | $29.99/月 | Recurring (monthly) |

### Webhook Events（/billing/webhook で処理）

| Event | 処理内容 |
|---|---|
| `checkout.session.completed` | API キーを自動発行、`api_keys` テーブルに INSERT |
| `customer.subscription.deleted` | `label=stripe:{subscription_id}` のキーを DELETE |
| `customer.subscription.updated` | ログ記録（プラン変更・未払い検知） |
| `invoice.payment_failed` | ログ記録（要通知実装） |

---

## API キー管理

### テーブル構造（api_keys）

```sql
CREATE TABLE api_keys (
    key TEXT PRIMARY KEY,           -- fdb_{hex32}
    plan TEXT NOT NULL DEFAULT 'developer',
    label TEXT DEFAULT '',          -- "stripe:{subscription_id}" or manual label
    email TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    requests_today INTEGER DEFAULT 0,
    last_reset TEXT NOT NULL        -- "YYYY-MM-DD"
);
```

### レート制限の仕組み

1. リクエスト受信 → `check_rate_limit()` が `Authorization: Bearer` ヘッダーを確認
2. API キーあり → `api_keys` テーブルで plan と requests_today を照合
3. `last_reset` が今日でなければ → `requests_today = 0` にリセット
4. `requests_today >= limit` なら → **429 Too Many Requests** 
5. OK なら → `requests_today += 1`
6. API キーなし → Free ティア（100 req/日、IP ベース制限は未実装）

### 管理 API

```bash
# キー発行
curl -X POST https://fooddb.navii.online/admin/keys \
  -H "X-Admin-Key: $FOODDB_ADMIN_KEY" \
  -G -d "plan=developer" -d "label=test-key" -d "email=user@example.com"

# キー一覧
curl https://fooddb.navii.online/admin/keys \
  -H "X-Admin-Key: $FOODDB_ADMIN_KEY"

# キー削除
curl -X DELETE https://fooddb.navii.online/admin/keys/fdb_xxx \
  -H "X-Admin-Key: $FOODDB_ADMIN_KEY"

# 使用量確認（ユーザー向け）
curl "https://fooddb.navii.online/billing/usage?api_key=fdb_xxx"
```

---

## MCP からの課金フロー

```
MCP Server (ユーザーのマシン)
  ↓ FOODDB_API_KEY=fdb_xxx
  ↓ httpx GET /foods/search/オートミール
  ↓ Authorization: Bearer fdb_xxx
FastAPI (Mac Mini)
  ↓ check_rate_limit()
  ↓ api_keys.requests_today += 1
  ↓ 応答
MCP Server
  ↓ JSON → テキスト整形
AI エージェント
```

**MCP 経由でも REST API 経由でも、同一の認証・課金パスを通る。**

---

## TODO

- [ ] Free ティアの IP ベースレート制限実装
- [ ] 決済成功ページで API キーを表示する HTML ページ
- [ ] メール通知（SendGrid 連携）で API キーを送信
- [ ] 使用量ダッシュボード（`/billing/dashboard` — HTML）
- [ ] 未払い時の自動キー停止（`invoice.payment_failed` → キー無効化）
- [ ] Stripe Customer Portal（キャンセル・プラン変更のセルフサービス）

---

*作成: 2026-03-21*
