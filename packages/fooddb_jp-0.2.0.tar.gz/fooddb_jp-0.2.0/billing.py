"""
fooddb-jp Stripe 課金連携モジュール

- Stripe Checkout で Developer/Pro プランを購入
- Webhook で決済完了 → APIキー自動発行
- サブスク解約 → APIキー無効化

環境変数:
    STRIPE_SECRET_KEY     - Stripe Secret Key (sk_test_... or sk_live_...)
    STRIPE_WEBHOOK_SECRET - Stripe Webhook Signing Secret (whsec_...)
    FOODDB_BASE_URL       - API の公開URL (default: https://fooddb.navii.online)
"""

import os
import secrets
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Request, HTTPException, Query
from fastapi.responses import JSONResponse, RedirectResponse
from stripe import StripeClient, SignatureVerificationError

# ── 設定 ────────────────────────────────────────────────
STRIPE_SECRET_KEY = os.environ.get("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
BASE_URL = os.environ.get("FOODDB_BASE_URL", "https://fooddb.navii.online")

logger = logging.getLogger("fooddb.billing")

# Stripe クライアント（遅延初期化）
_client: StripeClient | None = None


def get_stripe_client() -> StripeClient:
    global _client
    if _client is None:
        if not STRIPE_SECRET_KEY:
            raise HTTPException(
                status_code=503,
                detail="Stripe is not configured. Set STRIPE_SECRET_KEY."
            )
        _client = StripeClient(STRIPE_SECRET_KEY)
    return _client


# ── Stripe Product/Price ID ─────────────────────────────
# setup_stripe_products.py で作成後にここに貼る、
# または環境変数で渡す
STRIPE_PRICES = {
    "developer": os.environ.get("STRIPE_PRICE_DEVELOPER", ""),
    "pro": os.environ.get("STRIPE_PRICE_PRO", ""),
}

PLAN_LIMITS = {
    "free": 100,
    "developer": 10_000,
    "pro": 100_000,
}

# ── Router ──────────────────────────────────────────────
router = APIRouter(prefix="/billing", tags=["billing"])


@router.post("/checkout")
async def create_checkout(
    plan: str = Query(..., description="Plan: developer or pro"),
    email: str = Query("", description="Customer email (optional)"),
):
    """Stripe Checkout セッションを作成し、決済URLを返す"""
    if plan not in STRIPE_PRICES:
        raise HTTPException(status_code=400, detail=f"Invalid plan: {plan}. Use 'developer' or 'pro'.")

    price_id = STRIPE_PRICES[plan]
    if not price_id:
        raise HTTPException(
            status_code=503,
            detail=f"Price ID for '{plan}' is not configured. Run setup_stripe_products.py first."
        )

    client = get_stripe_client()

    # Checkout セッション作成
    checkout_params = {
        "mode": "subscription",
        "line_items": [{"price": price_id, "quantity": 1}],
        "success_url": f"{BASE_URL}/billing/success?session_id={{CHECKOUT_SESSION_ID}}",
        "cancel_url": f"{BASE_URL}/billing/cancel",
        "metadata": {"plan": plan},
        "subscription_data": {"metadata": {"plan": plan}},
    }
    if email:
        checkout_params["customer_email"] = email

    session = client.checkout.sessions.create(params=checkout_params)

    return {
        "checkout_url": session.url,
        "session_id": session.id,
        "plan": plan,
        "price": "$9.99/mo" if plan == "developer" else "$29.99/mo",
    }


@router.get("/success")
async def checkout_success(session_id: str = Query(...)):
    """決済成功ページ（Webhook がキーを発行済み）"""
    return {
        "status": "success",
        "message": "Payment successful! Your API key has been sent to your email.",
        "session_id": session_id,
        "note": "If you don't receive the key within a minute, contact support.",
    }


@router.get("/cancel")
async def checkout_cancel():
    """決済キャンセルページ"""
    return {
        "status": "cancelled",
        "message": "Checkout was cancelled. No charges were made.",
    }


@router.post("/webhook")
async def stripe_webhook(request: Request):
    """Stripe Webhook — 決済イベントを処理"""
    payload = await request.body()
    sig_header = request.headers.get("Stripe-Signature", "")

    if not STRIPE_WEBHOOK_SECRET:
        logger.error("STRIPE_WEBHOOK_SECRET is not configured")
        raise HTTPException(status_code=503, detail="Webhook not configured")

    client = get_stripe_client()

    try:
        event = client.construct_event(
            payload, sig_header, STRIPE_WEBHOOK_SECRET
        )
    except ValueError:
        logger.error("Invalid webhook payload")
        raise HTTPException(status_code=400, detail="Invalid payload")
    except SignatureVerificationError:
        logger.error("Invalid webhook signature")
        raise HTTPException(status_code=400, detail="Invalid signature")

    logger.info(f"Webhook event: {event.type} (id={event.id})")

    # ── イベント処理 ────────────────────────────────
    if event.type == "checkout.session.completed":
        await _handle_checkout_completed(event.data.object)

    elif event.type == "customer.subscription.deleted":
        await _handle_subscription_deleted(event.data.object)

    elif event.type == "customer.subscription.updated":
        await _handle_subscription_updated(event.data.object)

    elif event.type == "invoice.payment_failed":
        logger.warning(f"Payment failed for invoice {event.data.object.id}")

    return JSONResponse(content={"received": True}, status_code=200)


@router.get("/usage")
async def get_usage(
    api_key: str = Query(..., description="Your API key (fdb_...)"),
):
    """APIキーの使用量を確認"""
    # DB を直接参照（api.py の get_db を再利用）
    import sqlite3
    from pathlib import Path
    db_path = Path(__file__).parent / "fooddb.sqlite"
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row

    row = conn.execute(
        "SELECT * FROM api_keys WHERE key = ?", (api_key,)
    ).fetchone()
    conn.close()

    if not row:
        raise HTTPException(status_code=404, detail="API key not found")

    plan = row["plan"]
    limit = PLAN_LIMITS.get(plan, 100)

    return {
        "plan": plan,
        "requests_today": row["requests_today"],
        "limit": limit,
        "remaining": max(0, limit - row["requests_today"]),
        "label": row["label"],
        "created_at": row["created_at"],
    }


# ── 内部ハンドラ ────────────────────────────────────────

async def _handle_checkout_completed(session):
    """Checkout 完了 → APIキー発行"""
    plan = session.metadata.get("plan", "developer") if session.metadata else "developer"
    customer_email = session.customer_details.email if session.customer_details else ""
    customer_id = session.customer
    subscription_id = session.subscription

    logger.info(
        f"Checkout completed: plan={plan}, email={customer_email}, "
        f"customer={customer_id}, subscription={subscription_id}"
    )

    # APIキー発行
    api_key = f"fdb_{secrets.token_hex(16)}"
    now = datetime.now(timezone.utc).isoformat()
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    import sqlite3
    from pathlib import Path
    db_path = Path(__file__).parent / "fooddb.sqlite"
    conn = sqlite3.connect(str(db_path))

    conn.execute(
        """INSERT INTO api_keys
           (key, plan, label, email, created_at, requests_today, last_reset)
           VALUES (?, ?, ?, ?, ?, 0, ?)""",
        (api_key, plan, f"stripe:{subscription_id}", customer_email, now, today),
    )
    conn.commit()
    conn.close()

    logger.info(f"API key issued: fdb_...{api_key[-4:]} (plan={plan})")

    # TODO: メール送信（SendGrid 等）でキーを通知
    # 現時点では Stripe の metadata にキーを保存
    if subscription_id:
        try:
            client = get_stripe_client()
            client.subscriptions.update(
                subscription_id,
                params={"metadata": {"api_key_hint": f"fdb_...{api_key[-4:]}"}}
            )
        except Exception as e:
            logger.warning(f"Failed to update subscription metadata: {e}")


async def _handle_subscription_deleted(subscription):
    """サブスク解約 → APIキー無効化"""
    subscription_id = subscription.id
    logger.info(f"Subscription deleted: {subscription_id}")

    import sqlite3
    from pathlib import Path
    db_path = Path(__file__).parent / "fooddb.sqlite"
    conn = sqlite3.connect(str(db_path))

    # stripe:subscription_id のラベルでキーを探す
    result = conn.execute(
        "DELETE FROM api_keys WHERE label = ?",
        (f"stripe:{subscription_id}",),
    )
    conn.commit()
    deleted = result.rowcount
    conn.close()

    logger.info(f"Deleted {deleted} API key(s) for subscription {subscription_id}")


async def _handle_subscription_updated(subscription):
    """サブスク更新（プラン変更など）"""
    subscription_id = subscription.id
    new_plan = subscription.metadata.get("plan", "") if subscription.metadata else ""
    status = subscription.status

    logger.info(
        f"Subscription updated: {subscription_id}, "
        f"status={status}, plan={new_plan}"
    )

    if status in ("past_due", "unpaid"):
        logger.warning(f"Subscription {subscription_id} is {status}")
