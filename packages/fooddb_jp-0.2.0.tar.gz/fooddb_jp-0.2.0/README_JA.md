# fooddb-jp 🇯🇵🍱

日本食品標準成分表（八訂 増補2023年）の構造化データベース + REST API + MCP Server。

文部科学省が Excel でしか提供していない **2,541食品 × 353成分（440,441レコード）** を、
INFOODS Tagname 準拠の SQLite に変換し、API/MCP でクエリ可能にしました。

> 🌐 [English README](./README.md)

## クイックスタート

```bash
# 依存インストール
uv sync

# REST API を起動（http://localhost:8800/docs でSwagger表示）
uv run uvicorn api:app --port 8800

# MCP Server を起動（stdio モード）
uv run python mcp_server.py
```

## データ規模

| 項目 | 数値 |
|------|------|
| 食品数 | 2,541 |
| 成分タグ数 | 353（INFOODS準拠） |
| 栄養レコード数 | 440,441 |
| テーブル数 | 11（本表 + アミノ酸4 + 脂肪酸3 + 炭水化物3） |
| 日英ラベルカバー率 | 100% |
| 検索エイリアス数 | 31,504 |
| 食品名構造化 | カテゴリ27種 + サブカテゴリ44種 |
| SQLite サイズ | 43 MB |

## データソース

- **日本食品標準成分表（八訂）増補2023年** — 文部科学省
- URL: https://www.mext.go.jp/a_menu/syokuhinseibun/mext_00001.html
- 全11 Excel ファイル（本表、アミノ酸4表、脂肪酸3表、炭水化物3表）

## プロジェクト構成

```
fooddb-jp/
├── data/
│   ├── raw/                     # 元データ（文科省 Excel 11ファイル）
│   └── output/                  # 変換済みデータ
│       ├── foods_all.jsonl          # 食品マスタ
│       ├── nutrients_all.jsonl      # 成分値
│       ├── nutrient_defs_all.json   # 成分定義
│       └── nutrient_master.json     # 353タグ日英定義
├── scripts/
│   ├── convert_all.py           # Excel → SQLite 統合変換
│   ├── build_nutrient_master.py # 成分定義マスター生成
│   ├── build_aliases.py         # 検索エイリアス生成
│   ├── migrate_food_names.py    # 食品名構造化マイグレーション
│   ├── test_food_name_parse.py  # Excel原本照合テスト
│   └── legacy/                  # 旧スクリプト（2025年7月版）
├── fooddb.sqlite                # SQLite データベース
├── api.py                       # FastAPI REST API
├── mcp_server.py                # MCP Server (stdio/HTTP)
├── DEPLOY_PLAN.md               # Cloudflare デプロイ計画書
├── TODO.md                      # ロードマップ
└── pyproject.toml
```

## REST API エンドポイント

| メソッド | パス | 説明 |
|---------|------|------|
| GET | `/` | 統計情報（認証不要） |
| GET | `/foods` | 食品一覧（?q=検索&group=食品群コード&category=カテゴリ&subcategory=サブカテゴリ&base_name=ベース名） |
| GET | `/foods/{id}` | 食品詳細 + 全成分値（カテゴリ情報付き） |
| GET | `/foods/search/{query}` | あいまい検索（food_name + base_name + category 横断） |
| GET | `/nutrients` | 成分定義一覧 |
| GET | `/nutrients/{tag}` | 成分定義の詳細 |
| GET | `/ranking/{tag}` | 含有量ランキング |
| GET | `/calculate` | 栄養計算（?foods=1004:100,12004:60） |
| GET | `/groups` | 食品群一覧 |
| POST | `/admin/keys` | APIキー発行（管理者） |
| GET | `/admin/keys` | キー一覧（管理者） |
| DELETE | `/admin/keys/{key}` | キー無効化（管理者） |

## 認証 & レート制限

### 料金プラン

| プラン | レート制限 | 認証 |
|--------|-----------|------|
| **Free** | 100 req/日 | 不要 |
| **Developer** | 10,000 req/日 | APIキー |
| **Pro** | 100,000 req/日 | APIキー |

- カウンタは **UTC 00:00（日本時間 09:00）** に日次リセット
- 制限超過時は `429 Too Many Requests` を返却

### APIキーの使い方

```bash
# キー無し（Freeプラン、100 req/日）
curl https://fooddb.navii.online/foods/search/オートミール

# キーあり（Developer/Proプラン）
curl https://fooddb.navii.online/foods/search/オートミール \
  -H "Authorization: Bearer fdb_xxxxxxxxxxxxx"
```

### 管理API（キー発行・管理）

```bash
# マスターキーを環境変数で設定して起動
FOODDB_ADMIN_KEY=fdb_admin_xxxxx uv run uvicorn api:app --port 8800

# キー発行
curl -X POST "https://fooddb.navii.online/admin/keys?plan=developer&label=my-app" \
  -H "X-Admin-Key: fdb_admin_xxxxx"
# → {"key": "fdb_933ffa8c...", "plan": "developer", "limit": 10000}

# キー一覧
curl "https://fooddb.navii.online/admin/keys" \
  -H "X-Admin-Key: fdb_admin_xxxxx"

# キー無効化
curl -X DELETE "https://fooddb.navii.online/admin/keys/fdb_933ffa8c..." \
  -H "X-Admin-Key: fdb_admin_xxxxx"
```

## MCP ツール

AI エージェントから直接クエリ可能な5ツール：

| ツール | 説明 | 例 |
|--------|------|-----|
| `search_food` | 食品名あいまい検索 | 「鶏むね」「tofu」 |
| `get_food_nutrients` | 食品番号→成分値 | 11220（鶏むね皮なし） |
| `calculate_nutrition` | 栄養計算 | 「1004:100,12004:60」 |
| `nutrient_ranking` | 含有量ランキング | VITC（ビタミンC） |
| `list_food_groups` | 食品群一覧 | — |

### 表記揺れ対応

3段階ハイブリッド検索で正式名称と日常表現の差を吸収：

```
「鶏むね」
 1. LIKE検索 → ✗（DB上は「にわとり　むね」）
 2. FTS5検索 → ✗
 3. エイリアス検索 → ✗
 4. エイリアス交差検索 → ✓（「鶏」→にわとり alias AND 「むね」→食品名）
    → 7件ヒット
```

### 食品名の構造化パース

文科省の成分表では、食品名に＜＞や［］で分類情報が埋め込まれています。
これを正規表現で分解し、検索・フィルタリングに活用可能なカラムとして格納しています。

```
＜畜肉類＞　うし　［和牛肉］　かた　脂身つき　生
  → category: 畜肉類
  → base_name: うし
  → subcategory: 和牛肉
  → detail: かた　脂身つき　生
```

| カラム | 説明 | 例 |
|--------|------|-----|
| `food_name` | **原文維持**（公式名称） | `＜畜肉類＞　うし　［和牛肉］　かた　脂身つき　生` |
| `category` | ＜＞の中身（27種） | `畜肉類`, `魚類`, `調味料類` |
| `subcategory` | ［］の中身（44種） | `和牛肉`, `小麦粉`, `即席めん類` |
| `base_name` | 食品ベース名 | `うし`, `こむぎ`, `アマランサス` |
| `detail` | 残りの詳細部分 | `かた　脂身つき　生` |

```sql
-- 和牛肉だけ取得
SELECT * FROM foods WHERE subcategory = '和牛肉';  -- 30件

-- 「うし」の全部位・全品種
SELECT * FROM foods WHERE base_name = 'うし';  -- 138件
```

## 成分識別子（INFOODS Tagname）

主要タグ一覧：

| タグ | 日本語名 | 英語名 | 単位 |
|------|---------|--------|------|
| ENERC_KCAL | エネルギー | Energy | kcal |
| PROT- | たんぱく質 | Protein | g |
| FAT- | 脂質 | Total fat | g |
| CHOCDF- | 炭水化物 | Carbohydrate | g |
| FIB- | 食物繊維総量 | Dietary fiber | g |
| NA | ナトリウム | Sodium | mg |
| CA | カルシウム | Calcium | mg |
| FE | 鉄 | Iron | mg |
| VITC | ビタミンC | Vitamin C | mg |
| ... | （全353成分） | | |

> 末尾の `-` は INFOODS 規約で「分析方法不明」を意味する正式な接尾辞です。

## ライセンス

- データ: 文部科学省 — [利用規約](https://www.mext.go.jp/b_menu/1351168.htm)（出典明記で自由利用可）
- コード: MIT
