# fooddb-jp TODO

日本食品標準成分表の完全DB化 → API化 → 収益化ロードマップ

## 現在のステータス

- [x] 文科省 Excel 全11ファイル取得（本表 + アミノ酸4 + 脂肪酸3 + 炭水化物3）
- [x] INFOODS Tagname 識別子の発見・検証（Row 12 / Row 5）
- [x] クリーン変換パイプライン構築（convert.py, convert_all.py）
- [x] SQLite DB 生成（2,541食品 × 353タグ × 440,441レコード）
- [x] Gitea リポジトリ管理

---

## Phase 1: データ品質強化 🔧

DB として公開するための最低限の品質保証。

- [x] nutrient_defs テーブルに `label_jp`, `label_en`, `unit` を追加
  - 全353タグ 100% カバー済み（build_nutrient_master.py）
- [x] 食品名パース強化（`parse_food_name` の実装）
  - ＜＞カテゴリ（27種）、［］サブカテゴリ（44種）をDBに格納
  - `category`, `subcategory`, `base_name`, `detail` カラム追加
  - 全2,541件パース成功率100%、Excel原本照合10/10 PASS
  - convert_all.py にも組み込み済み（再ビルド時にも反映）
- [x] 値の品質チェック（quality_check.py — 6チェック実装）
  - 負の値: 0件 ✅
  - 質量バランス: 114件 WARNING（アルコール類=正常）
  - エネルギー整合性: 34件 WARNING（正常範囲）
  - エネルギー0+マクロ栄養素: 5件（お茶・だしのTr仕様）
  - 推定値: 18.8%（82,623/440,441）
  - 外れ値: 油脂・乾物系（実データとして正常）
- [x] テスト作成
  - 特定食品の成分値がExcel原本と一致するか検証（10品目照合OK）
- [ ] 9訂対応準備
  - 文科省の公表スケジュール監視（令和7年度中予定）
  - convert_all.py が新版にも適用可能か構造テスト

## Phase 2: GitHub 公開 🌐

先行者優位の確立。SEO と認知の獲得。

- [x] GitHub リポジトリ作成（public） → github.com/takakix2/fooddb-jp
- [x] README 英語版作成（USDA比較表付き）
- [x] SQLite ファイルの GitHub Release 公開（v2023.1）
- [x] ライセンス整理（MIT + CC BY 4.0相当）
- [x] トピックタグ + FUNDING.yml 設定
- [ ] PyPI パッケージ化検討
- [ ] サンプルクエリ集（Jupyter Notebook）

## Phase 3: REST API + 公開 🚀

Nutritionix 日本版の第一歩。

- [x] FastAPI 実装（api.py — 9エンドポイント）
  - category/subcategory/base_name フィルタ対応
  - 横断検索（food_name + base_name + category）
- [x] MCP Server 実装（mcp_server.py — 5ツール）
  - REST API 経由に統合済み（課金ゲートウェイ化: MCP → httpx → FastAPI → SQLite）
  - カテゴリ情報付きレスポンス
- [x] 表記揺れ対応（エイリアス 31,504件 + 4段階ハイブリッド検索）
- [x] 複合インデックス追加（167倍高速化）
- [x] Cloudflare Tunnel で公開（DEPLOY_PLAN.md Phase A 完了）
- [x] レート制限 + APIキー管理（実装済み: Free/Developer/Pro 3ティア）
- [x] Stripe 課金連携（billing.py — Checkout/Webhook/Usage）
  - Product/Price 作成済み（Developer $9.99, Pro $29.99）
  - Webhook: checkout.session.completed → APIキー自動発行
  - Webhook: customer.subscription.deleted → キー無効化
- [ ] OpenAPI (Swagger) ドキュメント整備

### 📊 パフォーマンス実測（Mac Mini, SQLite）

| クエリ | レイテンシ | QPS |
|--------|----------|-----|
| 食品検索 (LIKE) | 431 µs | 2,322 |
| 食品詳細 + 成分 (JOIN) | 86 µs | 11,600 |
| ランキング (ORDER BY) | 3.1 ms | 326 |
| 栄養計算 (2食品 JOIN) | 90 µs | 11,100 |
| エイリアス交差 | 3.4 ms | 298 |

### 🚀 将来のスケーリング案（トラフィック増加時）

- **事前計算テーブル**: JOINを排除し、食品×テーブル単位で JSON 化して1行 SELECT に
- **ランキング事前生成**: 成分タグごとにトップ100を事前ソート
- 年1回の更新時にバッチ再生成すればよい（静的DB）

## Phase 4: 付加価値 💎

差別化と収益化のための機能拡張。

### 📸 キラーデモ: 写真 → 栄養計算

食事の写真を撮るだけでカロリー・栄養素を自動計算する。

```
📸 食事の写真
  ↓
🤖 マルチモーダル LLM（Gemini / GPT-4o）
  「この写真の食品と概算量を列挙して」
  → [{"food": "ご飯", "amount_g": 200}, {"food": "鮭の塩焼き", "amount_g": 80}]
  ↓
🔍 fooddb-jp で食品名マッチング → food_number 特定
  ↓
📊 DB クエリ → 量を掛けて合算
  ↓
📋 「この食事は約 620 kcal。たんぱく質 32g、脂質 18g...」
```

- [ ] 食品名マッチングエンジン（LLM出力 → food_number 変換）
- [ ] デモ CLI（写真パス → 栄養計算結果）
- [ ] デモ Web UI（カメラ撮影 → リアルタイム計算）

### その他の付加価値

- [x] 食品名の表記揺れ対応（エイリアス + 交差検索で実装済み）
- [ ] バーコード（JAN コード）連携
  - 市販食品のバーコード → 成分情報
  - Open Food Facts Japan との連携
- [ ] 食品画像
  - 代表的な食品の参考画像（AI生成 or フリー素材）
- [ ] 栄養バランス計算 API
  - 1日の食事リスト → 推奨量との比較
  - 日本人の食事摂取基準（2025年版）との照合
- [x] LLM / MCP 連携（mcp_server.py で実装済み）

## Phase 5: 収益化 💰

- [ ] 料金プラン設計
  - Free: SQLite ダウンロード + API 100 req/day
  - Developer: API 10,000 req/day — $9.99/月
  - Pro: API 100,000 req/day — $29.99/月
- [ ] 決済基盤（Stripe）
- [ ] 利用規約・プライバシーポリシー
- [ ] 顧客獲得
  - 栄養管理アプリ開発者
  - 食品メーカーの品質管理部門
  - 病院・給食サービス
  - フィットネス系スタートアップ

---

## 参考

- [USDA FoodData Central](https://fdc.nal.usda.gov/) — 米国版（無料API公開）
- [Nutritionix](https://www.nutritionix.com/) — USDAデータ+独自データのAPI商用サービス
- [FAO/INFOODS Tagnames](https://www.fao.org/infoods/infoods/standards-guidelines/food-component-identifiers-tagnames/en/) — 成分識別子の国際標準
- [文科省 食品成分データベース](https://fooddb.mext.go.jp/) — 公式検索サイト（API非公開）
