# fooddb-jp 公開デプロイ実装計画書

> Cloudflare Tunnel で Mac Mini 上の FastAPI を公開し、無料/有料ティアで提供する。
> Marrow 課金基盤のリハーサルを兼ねる。

---

## 1. アーキテクチャ

```
[ユーザー] → [Cloudflare CDN/WAF]
                   ↓
             [Cloudflare Tunnel]
                   ↓
             [Mac Mini (192.168.1.10)]
                   ↓
             [FastAPI :8800]  ← 既に動作中
                   ↓
             [SQLite (43MB)]
```

### なぜ Tunnel か（D1 ではなく）

| 比較項目 | D1 方式 | Tunnel 方式 |
|----------|---------|-------------|
| コード書き直し | Python → TypeScript (Hono) | **不要**（FastAPI そのまま） |
| FTS5 互換性 | D1 で使えるか不明 | **問題なし**（ローカル SQLite） |
| Marrow との共通性 | Workers 側のみ | **アーキテクチャ全体が同じ** |
| レイテンシ | エッジ実行で最速 | Tunnel 経由（数十ms追加） |
| 可用性 | Cloudflare 管理 | Mac Mini に依存 |

**結論**: Marrow のリハーサルが目的なので、Tunnel 方式が最適。

---

## 2. 技術スタック

| レイヤー | 技術 | 役割 |
|----------|------|------|
| CDN/WAF | Cloudflare | DDoS防御、SSL終端、キャッシュ |
| Tunnel | cloudflared | Mac Mini への暗号化トンネル |
| API Server | FastAPI (api.py) | REST API（既存） |
| DB | SQLite (fooddb.sqlite) | データストア（既存） |
| レート制限 | Cloudflare WAF Rules | IP/APIキー単位 |
| 課金 | Stripe | Webhook → APIキー発行 |

---

## 3. 実装ステップ

### Phase A: Tunnel セットアップ + 公開 ✅ 完了（2026-03-19）

```
✅ 1. cloudflared v2026.3.0 確認済み（/usr/local/bin/cloudflared）
✅ 2. Cloudflare 認証完了（navii.online）
✅ 3. Tunnel 作成: fooddb-jp (ID: 1addee5b-0685-4ea8-a7a6-ded0b7af7d2a)
✅ 4. DNS 設定: fooddb.navii.online → CNAME
✅ 5. config.yml: ~/.cloudflared/config.yml
✅ 6. 動作確認: https://fooddb.navii.online/ — 4コネクション (nrt09/12/16)
□  7. systemd で常駐化（Mac Mini 移行時に実施）
```

**起動コマンド（手動）:**
```bash
# FastAPI
cd ~/Documents/MyKnowledge_vault/50_Projects/fooddb-jp
uv run uvicorn api:app --port 8800

# Tunnel
cloudflared tunnel run fooddb-jp
```

### Phase B: レート制限 + APIキー ✅ 完了（2026-03-19）

```
✅ 8. FastAPI に認証ミドルウェア実装
     - Authorization: Bearer fdb_xxxxx
     - キーの検証: ローカル SQLite テーブル
     - キー無し = Free ティア（100 req/日）

✅ 9. APIキー管理テーブル + 管理エンドポイント
     - POST /admin/keys — キー発行
     - GET  /admin/keys — キー一覧
     - DELETE /admin/keys/{key} — キー無効化
     - X-Admin-Key ヘッダーでマスター認証

✅ 10. 3ティア料金設定（Free / Developer / Pro）
      - 日次リセット（UTC 00:00）
      - 429 Too Many Requests 返却
```

### Phase C: Stripe 課金連携 ✅ 完了（2026-03-20）

```
✅ 11. Stripe Product / Price 作成
       - Product: fooddb-jp API
       - Developer: $9.99/mo (price_1TCy31BtmXXkKBDksjW5nlzY)
       - Pro: $29.99/mo (price_1TCy31BtmXXkKBDkwYFXiLgw)

✅ 12. Stripe Checkout Webhook
       - checkout.session.completed → api_keys テーブルにキー発行
       - customer.subscription.deleted → キー無効化

✅ 13. 課金エンドポイント追加（FastAPI）
       POST /billing/checkout  → Stripe Checkout URL生成
       GET  /billing/success   → 決済成功ページ
       GET  /billing/cancel    → キャンセルページ
       GET  /billing/usage     → 使用量確認

✅ 14. Webhook 受信
       POST /billing/webhook   → Stripe Signature 検証 + キー管理
```

### Phase D: 公開準備（1セッション）

```
□ 15. ドメイン設定
      - DNS + SSL は Cloudflare 自動

□ 16. ドキュメント
      - OpenAPI / Swagger（FastAPI 自動生成）
      - 登録手順・コード例

□ 17. GitHub Public Repo
      - SQLite + スクリプト = Public
      - API キーは別管理

□ 18. 告知（Product Hunt / Hacker News / Zenn）
```

---

## 4. 料金プラン

| プラン | 月額 | レート制限 | 認証 |
|--------|------|-----------|------|
| **Free** | ¥0 | 100 req/日 | 不要 |
| **Developer** | $9.99/mo | 10,000 req/日 | APIキー |
| **Pro** | $29.99/mo | 100,000 req/日 | APIキー |

---

## 5. Marrow へのフィードバック項目

| 項目 | fooddb-jp で検証 | Marrow に適用 |
|------|-----------------|---------------|
| **Tunnel セットアップ** | 手順・信頼性・レイテンシ | 同じ構成を流用 |
| **常駐化** | systemd/launchd の設定 | Marrow も同様に常駐 |
| **Cloudflare WAF** | レート制限の粒度 | APIプラン制御 |
| **Stripe Webhook** | 決済 → キー発行フロー | 課金フロー全体 |
| **可用性** | Mac Mini ダウン時の挙動 | 運用ポリシーの判断材料 |
| **レイテンシ** | Tunnel 経由の実測値 | SLA 設計の根拠 |

---

## 6. 投資対効果

| コスト | 金額 |
|--------|------|
| Cloudflare Free プラン | ¥0 |
| Tunnel | ¥0（Free プランに含む） |
| ドメイン | $10/年 |
| Stripe 手数料 | 3.6% + ¥40/件 |
| Mac Mini 電気代 | 既存インフラ |
| **合計追加費用** | **≒ ¥100/月** |

**損益分岐点**: Developer プラン 1件で黒字

---

## 7. リスク・注意事項

1. **Mac Mini の可用性**
   - 停電・再起動時に API ダウン
   - UPS + launchd 自動復帰で軽減
   - Cloudflare が 502 を返すので、カスタムエラーページを設定

2. **Tunnel のレイテンシ**
   - ローカル実測: 3-5ms（同一筐体ループバック）
   - 外部からの実測は未実施（日本国内: 10-30ms 追加の見込み）
   - 読み取り専用 + 軽量クエリなので許容範囲

3. **データ更新**
   - 成分表は年1回更新（文科省）
   - SQLite を差し替えて FastAPI 再起動のみ

4. **著作権**
   - 政府統計データ → 出典明記で自由利用可

---

*作成: 2026-03-18*
*改訂: 2026-03-19（D1方式 → Tunnel方式に変更、Phase A 完了、Phase B 完了）*
*改訂: 2026-03-20（Phase C 完了、GitHub 公開完了）*
*Status: Phase A+B+C 完了 → Phase D（ドキュメント・告知）待ち*
