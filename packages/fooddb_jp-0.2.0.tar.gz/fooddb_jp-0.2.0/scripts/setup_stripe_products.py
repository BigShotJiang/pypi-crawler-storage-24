#!/usr/bin/env python3
"""
Stripe Product & Price セットアップスクリプト

Stripe に fooddb-jp の Product と Price を作成し、
環境変数として使える Price ID を出力する。

Usage:
    STRIPE_SECRET_KEY=sk_test_... uv run python scripts/setup_stripe_products.py
"""

import os
import sys
from stripe import StripeClient

STRIPE_SECRET_KEY = os.environ.get("STRIPE_SECRET_KEY", "")

if not STRIPE_SECRET_KEY:
    print("❌ STRIPE_SECRET_KEY が設定されていません")
    print("Usage: STRIPE_SECRET_KEY=sk_test_... uv run python scripts/setup_stripe_products.py")
    sys.exit(1)

client = StripeClient(STRIPE_SECRET_KEY)


def main():
    print("🔧 Stripe Product & Price セットアップ")
    print(f"   Mode: {'TEST' if 'test' in STRIPE_SECRET_KEY else 'LIVE'}")
    print()

    # ── Product 作成 ────────────────────────────────
    print("[1/3] Product 作成...")

    # 既存の Product を検索
    existing = client.products.list(params={"limit": 100})
    product = None
    for p in existing.data:
        if p.name == "fooddb-jp API":
            product = p
            print(f"   → 既存 Product を使用: {p.id}")
            break

    if not product:
        product = client.products.create(params={
            "name": "fooddb-jp API",
            "description": (
                "Japanese Food Composition Database API — "
                "2,541 foods × 353 INFOODS-tagged nutrients. "
                "REST API access for nutrition apps, fitness platforms, "
                "and food research."
            ),
            "metadata": {
                "project": "fooddb-jp",
                "data_source": "MEXT Japan, 8th ed. 2023",
            },
        })
        print(f"   → 新規 Product 作成: {product.id}")

    # ── Price 作成 ──────────────────────────────────
    print("[2/3] Price 作成...")

    plans = [
        {
            "nickname": "Developer",
            "plan_key": "developer",
            "amount": 999,  # $9.99
            "interval": "month",
        },
        {
            "nickname": "Pro",
            "plan_key": "pro",
            "amount": 2999,  # $29.99
            "interval": "month",
        },
    ]

    price_ids = {}
    existing_prices = client.prices.list(params={"product": product.id, "limit": 100})
    existing_map = {}
    for ep in existing_prices.data:
        if ep.nickname and ep.active:
            existing_map[ep.nickname] = ep

    for plan in plans:
        if plan["nickname"] in existing_map:
            price = existing_map[plan["nickname"]]
            print(f"   → {plan['nickname']}: 既存 Price を使用 {price.id}")
        else:
            price = client.prices.create(params={
                "product": product.id,
                "nickname": plan["nickname"],
                "unit_amount": plan["amount"],
                "currency": "usd",
                "recurring": {"interval": plan["interval"]},
                "metadata": {"plan": plan["plan_key"]},
            })
            print(f"   → {plan['nickname']}: 新規 Price 作成 {price.id}")

        price_ids[plan["plan_key"]] = price.id

    # ── 結果出力 ────────────────────────────────────
    print()
    print("[3/3] セットアップ完了！")
    print()
    print("以下の環境変数を設定してください:")
    print()
    print(f'export STRIPE_SECRET_KEY="{STRIPE_SECRET_KEY}"')
    print(f'export STRIPE_PRICE_DEVELOPER="{price_ids["developer"]}"')
    print(f'export STRIPE_PRICE_PRO="{price_ids["pro"]}"')
    print()
    print("API 起動コマンド:")
    print(f'  STRIPE_SECRET_KEY="{STRIPE_SECRET_KEY}" \\')
    print(f'  STRIPE_PRICE_DEVELOPER="{price_ids["developer"]}" \\')
    print(f'  STRIPE_PRICE_PRO="{price_ids["pro"]}" \\')
    print(f'  uv run uvicorn api:app --port 8800')


if __name__ == "__main__":
    main()
