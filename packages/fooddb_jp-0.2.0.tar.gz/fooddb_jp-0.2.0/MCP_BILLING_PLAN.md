# MCP → REST API 統合計画（課金ゲートウェイ化）

> MCP Server が SQLite を直接読む構造を廃止し、REST API 経由に切り替える。
> これにより MCP 経由の利用にも認証・レート制限・課金が適用される。

---

## 1. 現状の問題

```
REST API  → FastAPI (api.py)    → 認証 ✅ → レート制限 ✅ → 課金 ✅ → SQLite
MCP Server → mcp_server.py      → 直接 SQLite 読み取り          ❌ 課金されない
```

### 影響
- MCP 経由の利用が課金対象外
- 検索ロジックが api.py と mcp_server.py に二重実装
- エイリアス検索・FTS5 ロジックの同期コスト

---

## 2. 目標アーキテクチャ

```
MCP Server (mcp_server.py)
    ↓ HTTP (httpx)
REST API (FastAPI, api.py) — https://fooddb.navii.online/
    ↓ 認証 + レート制限 + 課金
SQLite (fooddb.sqlite)
```

### 原則
- **MCP Server＝薄いラッパー**（REST API の結果を LLM 向けに整形するだけ）
- **ビジネスロジック＝REST API に一本化**
- **MCP Server は API キーを持つ**（環境変数 `FOODDB_API_KEY` で注入）

---

## 3. MCP ツール ↔ REST エンドポイント マッピング

| MCP ツール | 現在の実装 | 対応 REST エンドポイント |
|---|---|---|
| `search_food(query, limit)` | 直接 SQL（4段フォールバック） | `GET /foods/search/{query}?limit=N` |
| `get_food_nutrients(food_number, table)` | 直接 SQL（JOIN） | `GET /foods/{food_number}?table=T` |
| `calculate_nutrition(foods_and_amounts)` | 直接 SQL（JOIN + 集計） | `GET /calculate?foods=1004:100,12004:60` |
| `nutrient_ranking(tag, limit)` | 直接 SQL（ORDER BY） | `GET /ranking/{tag}?limit=N` |
| `list_food_groups()` | 直接 SQL（GROUP BY） | `GET /groups` |

**すべてのツールに対応するエンドポイントが既に存在する。** コードの書き換えのみで済む。

---

## 4. 実装ステップ

### Step 1: MCP Server 用 API キーの発行

Mac Mini 上で実行：
```bash
curl -X POST https://fooddb.navii.online/admin/keys \
  -H "X-Admin-Key: $FOODDB_ADMIN_KEY" \
  -G -d "plan=admin" -d "label=mcp-server-internal"
```

→ 発行されたキーを `.env` に追加：
```
FOODDB_API_KEY=fdb_xxxxxxxxxxxxxxxx
```

### Step 2: mcp_server.py の書き換え

**Before（直接 DB アクセス）:**
```python
import sqlite3

DB_PATH = Path(__file__).parent / "fooddb.sqlite"

def get_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

@mcp.tool()
def search_food(query: str, limit: int = 10) -> str:
    db = get_db()
    rows = db.execute("SELECT ... WHERE food_name LIKE ?", ...)
    # 100行以上の SQL ロジック
    db.close()
    return formatted_result
```

**After（REST API 経由）:**
```python
import httpx
import os

API_BASE = os.environ.get("FOODDB_API_URL", "https://fooddb.navii.online")
API_KEY = os.environ.get("FOODDB_API_KEY", "")

def _client() -> httpx.Client:
    headers = {}
    if API_KEY:
        headers["Authorization"] = f"Bearer {API_KEY}"
    return httpx.Client(base_url=API_BASE, headers=headers, timeout=10.0)

@mcp.tool()
def search_food(query: str, limit: int = 10) -> str:
    """食品名であいまい検索する。例: 'オートミール', '鶏むね', '豆腐'"""
    with _client() as c:
        res = c.get(f"/foods/search/{query}", params={"limit": limit})
        res.raise_for_status()
        data = res.json()

    if not data:
        return f"「{query}」に一致する食品は見つかりませんでした。"

    lines = [f"検索結果 ({len(data)}件):"]
    for food in data:
        parts = [f"{food['food_number']}: {food['food_name']}"]
        meta = []
        if food.get("group_name"): meta.append(food["group_name"])
        if food.get("category"): meta.append(f"＜{food['category']}＞")
        if meta: parts.append(f"({', '.join(meta)})")
        lines.append(" ".join(parts))
    return "\n".join(lines)
```

### Step 3: 各ツールの書き換え

| ツール | API コール | 整形 |
|---|---|---|
| `search_food` | `GET /foods/search/{query}` | JSON → テキスト一覧 |
| `get_food_nutrients` | `GET /foods/{number}?table=T` | JSON → 成分表テキスト |
| `calculate_nutrition` | `GET /calculate?foods=...` | JSON → 栄養素合計テキスト |
| `nutrient_ranking` | `GET /ranking/{tag}?limit=N` | JSON → ランキングテキスト |
| `list_food_groups` | `GET /groups` | JSON → グループ一覧テキスト |

### Step 4: REST API 側の微調整

現在の REST API レスポンスを確認し、MCP から使いやすい形になっているか検証。
不足があれば追加：

- [ ] `/foods/search/{query}` — カテゴリ・サブカテゴリ情報が含まれるか確認
- [ ] `/calculate` — 主要栄養素の優先表示順が API 側にもあるか確認
- [ ] エラーレスポンスの統一（404, 400 のフォーマット）

### Step 5: 依存関係の更新

```bash
uv add httpx  # mcp_server.py の新しい依存
uv remove sqlite3  # 不要になる（標準ライブラリなので実際は不要）
```

### Step 6: テスト

1. **ユニットテスト**: MCP ツールが正しい REST エンドポイントを呼ぶか
2. **統合テスト**: MCP 経由で検索 → API キーのカウンタが増加するか
3. **レート制限テスト**: Free キーで 100 回超えたら MCP も 429 になるか

```bash
# 統合テスト例
uv run python -c "
from mcp_server import search_food
result = search_food('米', 3)
print(result)
"
# → API の requests_today が +1 されていることを確認
```

### Step 7: Mac Mini へのデプロイ

```bash
# Mac Mini にSSH
ssh takaki@192.168.1.10

# コード更新
cd ~/projects/fooddb-jp
git pull

# .env に API キーを追加
echo 'FOODDB_API_KEY=fdb_xxx' >> .env

# サービス再起動（systemd）
sudo systemctl restart fooddb-api
```

---

## 5. 削除されるコード

mcp_server.py から削除される部分：
- `sqlite3` import と `DB_PATH` 定義
- `get_db()` 関数
- 各ツール内の SQL クエリ（合計 ~150行）
- エイリアス交差検索ロジック（api.py に一本化済み）

**mcp_server.py は ~260行 → ~100行 に縮小**

---

## 6. 副次効果

| Before | After |
|---|---|
| MCP は SQLite を直接読む（課金外） | **全アクセスが課金対象** |
| 検索ロジックが2箇所に存在 | **api.py に一本化** |
| mcp_server.py が DB ファイルに依存 | **URL だけ知っていれば動く** |
| Mac Mini 上でしか MCP が動かない | **どこからでも REST 経由で接続可能** |
| MCP の食品検索品質 ≠ API の検索品質 | **同一のロジックを共有** |

---

## 7. Marrow への水平展開

この「MCP = 薄いラッパー / REST API = 課金ゲートウェイ」パターンは、
Marrow の MCP Server にもそのまま適用できる：

```
Marrow MCP Server
    ↓ HTTP
Marrow REST API (Cloudflare Workers)
    ↓ 認証 + 課金 (Stripe)
Marrow Gateway (Crawler Engine)
```

fooddb-jp をこのパターンの **最初の実証例** として確立する。

---

## 8. 工数見積

| ステップ | 工数 |
|---|---|
| Step 1: API キー発行 | 1分 |
| Step 2-3: mcp_server.py 書き換え | 30分 |
| Step 4: REST API 微調整 | 15分 |
| Step 5: 依存関係更新 | 5分 |
| Step 6: テスト | 15分 |
| Step 7: デプロイ | 10分 |
| **合計** | **~1.5時間** |

---

*作成: 2026-03-21*
*Status: 計画完了 → 実装待ち*
