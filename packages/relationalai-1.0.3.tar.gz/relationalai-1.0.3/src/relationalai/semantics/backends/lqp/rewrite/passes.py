from .lqp_pass import Pass

from .deduplicate_vars import DeduplicateVars
from .constants_to_vars import ConstantsToVars
from .function_annotations import FunctionAnnotations
from .recursion_config import RecursionConfig

from v0.relationalai.semantics.metamodel.compiler import Pass as v0Pass
from v0.relationalai.semantics.metamodel import rewrite as v0_rewrite, typer as v0_typer
from v0.relationalai.semantics.lqp import rewrite as v0_lqp_rewrite

def lqp_passes() -> list[Pass]:
    return [
        RecursionConfig(),
        FunctionAnnotations(),
        DeduplicateVars(),
        ConstantsToVars(),
    ]

def v0_lqp_passes() -> list[v0Pass]:
    return [
        # v0_lqp_rewrite.FunctionAnnotations(), - migrated in #574
        v0_lqp_rewrite.AnnotateConstraints(),
        # v0_lqp_rewrite.CDC(), - Handled by the shim
        v0_typer.InferTypes(),
        v0_lqp_rewrite.PeriodMath(),
        v0_lqp_rewrite.EliminateData(),

        v0_rewrite.DNFUnionSplitter(),
        v0_lqp_rewrite.ExtractKeys(),
        v0_rewrite.FormatOutputs(),

        v0_lqp_rewrite.ExtractCommon(),
        v0_lqp_rewrite.Flatten(),
        v0_lqp_rewrite.FlattenScript(),
        v0_rewrite.HandleAggregationsAndRanks(),

        v0_lqp_rewrite.Splinter(),
        # v0_lqp_rewrite.ConstantsToVars(), - Migrated in #645
        v0_lqp_rewrite.DeduplicateVars(),# Migrated in #646, but needed to fix FormatOutputs
        v0_lqp_rewrite.QuantifyVars(),

        v0_lqp_rewrite.AlgorithmPass(),
        v0_lqp_rewrite.UnifyDefinitions(),
    ]
