from typing import Any, Union, TypeAlias
from contextlib import contextmanager
from contextvars import ContextVar
from relationalai.semantics.frontend.base import Statement, Relationship, Model, Concept, Chain

__all__ = [
    "procedure", "loop",
    "ProcedureBuilder", "LoopBuilder", "Instruction",
    "OrMonoid", "Monoid"
]

#------------------------------------------------------
# Monoid Types (only Boolean monoid supported at the moment)
#------------------------------------------------------

class Monoid():
    pass

class OrMonoid(Monoid):
    pass

#------------------------------------------------------
# Instruction Types (tagged tuples or LoopBuilder)
#------------------------------------------------------

# Instructions are tagged tuples:
#   ("assign", expr)                - define a relation
#   ("empty", relationship)         - initialize relation to empty
#   ("upsert", arity, expr)         - upsert with arity (number of keys)
#   ("monoid", arity, monoid, expr) - monoid add with arity (number of keys)
#   ("monus", arity, monoid, expr)  - monus delete with arity (number of keys)
#   ("break", conditions)           - break condition (tuple of conditions, treated as conjunction)
#   ("loop", LoopBuilder)           - a loop. could be over a relation (for-loop) or empty (while-loop)

Instruction: TypeAlias = tuple[str, Any] | tuple[str, Any, Any] | tuple[str, int, Any] | tuple[str, int, Monoid, Any]

#------------------------------------------------------
# Context Variables for tracking current builder
#------------------------------------------------------

# The current instruction container (ProcedureBuilder or LoopBuilder)
_current_container: ContextVar[Union["ProcedureBuilder", "LoopBuilder", None]] = ContextVar(
    'current_container', default=None
)

def _register_instruction(instr: Instruction) -> None:
    """Register an instruction with the current container if in context."""
    container = _current_container.get()
    if container is None: 
        raise RuntimeError("Instructions can only be used inside an procedure")
    elif isinstance(container, ProcedureBuilder) or isinstance(container, LoopBuilder):
        container._instructions.append(instr)

#------------------------------------------------------
# InstructionContext helper class
#------------------------------------------------------

class InstructionContext:
    """Represents the context behind instructions that behave like insert/deletes."""

    def __init__(self, arity: int | None = None, monoid=None):
        self.arity = arity
        self._monoid = monoid 

    def with_arity(self, arity: int):
        assert self.arity is None, "Cannot redefine arity of an instruction"
        return InstructionContext(arity=arity, monoid=self._monoid)

    def with_monoid(self, monoid: Monoid):
        assert self._monoid is None, "Cannot redefine monoid of an instruction"
        return InstructionContext(arity=self.arity, monoid=monoid)

    def upsert(self, expr: Statement) -> Instruction:
        assert self.arity is not None, "Upsert must have an integer arity. Use `with_arity(x).upsert(...)`"
        instr: Instruction = ("upsert", self.arity, expr)
        _register_instruction(instr)
        return instr

    def monoid(self, expr: Statement) -> Instruction:
        assert self.arity is not None, "Monoid must have an integer arity. Use `with_arity(x).monoid(...)`"
        assert self._monoid is not None, "Monoid must have a monoid. Use `with_monoid(x).monoid(...)`"
        instr: Instruction = ("monoid", self.arity, self._monoid, expr)
        _register_instruction(instr)
        return instr

    def monus(self, expr: Statement) -> Instruction:
        assert self.arity is not None, "Monus must have an integer arity. Use `with_arity(x).monus(...)`"
        assert self._monoid is not None, "Monus must have a monoid. Use `with_monoid(x).monus(...)`"
        instr: Instruction = ("monus", self.arity, self._monoid, expr)
        _register_instruction(instr)
        return instr

#------------------------------------------------------
# LoopBuilder
#------------------------------------------------------

class LoopBuilder:
    """Represents a loop in the engine."""

    def __init__(self, over: list[Union[Concept, Relationship]] = []):
        # TODO: Currently looping over things is not supported.
        self._over = over
        self._instructions: list[Instruction] = []

    def __str__(self):
        return self._format(indent=0)

    def _format(self, indent: int = 0) -> str:
        prefix = "  " * indent
        lines = [f"{prefix}Loop:"]
        for instr in self._instructions:
            lines.append(self._format_instruction(instr, indent + 1))
        return "\n".join(lines)

    def _format_instruction(self, instr: Instruction, indent: int) -> str:
        prefix = "  " * indent
        if isinstance(instr, LoopBuilder):
            return instr._format(indent)
        tag = instr[0]
        if tag == "assign":
            return f"{prefix}@assign {instr[1]}"
        elif tag == "empty":
            return f"{prefix}@empty {instr[1]}"
        elif tag == "upsert":
            return f"{prefix}@upsert:{instr[1]} {instr[2]}"  # type: ignore[index]
        elif tag == "monoid":
            return f"{prefix}@monoid:{instr[1]}:{instr[2]} {instr[3]}"  # type: ignore[index]
        elif tag == "monus":
            return f"{prefix}@monus:{instr[1]}:{instr[2]} {instr[3]}"  # type: ignore[index]
        elif tag == "break":
            le = f"(log_every={instr[2]}) " if instr[2] is not None else ""  # type: ignore[index]
            return f"{prefix}@break{le} {instr[1]}"
        else:
            return f"{prefix}{instr}"

#------------------------------------------------------
# ProcedureBuilder
#------------------------------------------------------

class ProcedureBuilder:
    """Builds an imperative procedure with global relationships and instructions.

    An ProcedureBuilder represents a complete procedure containing:
    - Global relationships (loop heads)
    - A sequence of instructions (assign, empty, upsert, break, or loops)
    """

    def __init__(self, model: Model, *globals: Relationship | Chain):
        self._model = model
        self._globals: tuple[Relationship | Chain, ...] = globals
        self._instructions: list[Instruction] = []

    def assign(self, expr: Statement) -> Instruction:
        instr: Instruction = ("assign", expr)
        _register_instruction(instr)
        return instr

    def empty(self, relationship: Relationship) -> Instruction:
        instr: Instruction = ("empty", relationship)
        _register_instruction(instr)
        return instr

    def break_if(self, *conditions: Statement, log_every: int | None = None) -> Instruction:
        instr: Instruction = ("break", conditions, log_every)
        _register_instruction(instr)
        return instr

    def with_arity(self, arity: int) -> InstructionContext:
        return InstructionContext(arity=arity)

    def with_monoid(self, monoid: Monoid) -> InstructionContext:
        return InstructionContext(monoid=monoid)

    def loop(self, over: list[Union[Concept, Relationship]] = []):
        return loop(over)

    def __str__(self):
        lines = ["Procedure:"]

        # Print globals
        if self._globals:
            lines.append("  Globals:")
            for rel in self._globals:
                lines.append(f"    {rel}")

        # Print instructions
        if self._instructions:
            lines.append("  Instructions:")
            for instr in self._instructions:
                lines.append(self._format_instruction(instr, indent=2))

        return "\n".join(lines)

    def _format_instruction(self, instr: Instruction, indent: int) -> str:
        prefix = "  " * indent
        if isinstance(instr, LoopBuilder):
            return instr._format(indent)
        tag = instr[0]
        if tag == "assign":
            return f"{prefix}@assign {instr[1]}"
        elif tag == "empty":
            return f"{prefix}@empty {instr[1]}"
        elif tag == "upsert":
            return f"{prefix}@upsert:{instr[1]} {instr[2]}"  # type: ignore[index]
        elif tag == "monoid":
            return f"{prefix}@monoid:{instr[1]}:{instr[2]} {instr[3]}"  # type: ignore[index]
        elif tag == "monus":
            return f"{prefix}@monus:{instr[1]}:{instr[2]} {instr[3]}"  # type: ignore[index]
        elif tag == "break":
            le = f"(log_every={instr[2]}) " if instr[2] is not None else ""  # type: ignore[index]
            return f"{prefix}@break{le} {instr[1]}"
        elif tag == "loop":
            return f"{prefix}@loop {instr[1]}"
        else:
            return f"{prefix}{instr}"

#------------------------------------------------------
# Context Managers
#------------------------------------------------------

@contextmanager
def procedure(*globals: Relationship | Chain, model: Model | None = None):
    """Context manager for defining an procedure with global relationships.

    Usage:
        with procedure(Reachable, Frontier):
            assign(...)
            empty(...)
            with loop():
                upsert(...)
                break_if(...)

    Parameters
    ----------
    *globals : Relationship
        Relationships that are modified by the procedure. Important to specify for compilation.

    Yields
    ------
    ProcedureBuilder
        The procedure builder (can be used to access the built structure).
    """
    from .. import _check_model
    model = _check_model() if model is None else model
    builder = ProcedureBuilder(model, *globals)

    model._procedure_fragment(builder)

    token = _current_container.set(builder)
    try:
        yield builder
    finally:
        _current_container.reset(token)


@contextmanager
def loop(over: list[Union[Concept, Relationship]] = []):
    """Context manager for defining a loop within an procedure.

    Usage:
        with procedure(...):
            with loop():
                # instructions inside the loop (while-loop)
                assign(...)
                break_if(...)

        with procedure(...):
            with loop(over=SomeRelation):
                # instructions inside the loop (for-loop over relation)
                ...

    Can be nested for inner loops:
        with procedure(...):
            with loop():
                with loop():
                    # nested loop
                    ...

    Parameters
    ----------
    over : optional
        Relationship to iterate over (for-loop). If None, creates a while-loop.
    """
    parent = _current_container.get()
    if parent is None:
        raise RuntimeError("loop() must be used inside procedure() or another loop()")

    loop_builder = LoopBuilder(over=over)
    instr: Instruction = ("loop", loop_builder)
    # Register this loop as an instruction in the parent container
    parent._instructions.append(instr)

    token = _current_container.set(loop_builder)
    try:
        yield loop_builder
    finally:
        _current_container.reset(token)
