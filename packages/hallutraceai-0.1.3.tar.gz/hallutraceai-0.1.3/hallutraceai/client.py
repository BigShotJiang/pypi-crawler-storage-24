"""HalluTrace AI client for tracing LLM interactions."""

from __future__ import annotations

import atexit
import json
import logging
import queue
import threading
import uuid
from typing import Any

import requests

logger = logging.getLogger("hallutraceai")


class HalluTraceError(Exception):
    """Error from HalluTrace API."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class HalluTrace:
    """Non-blocking client for the HalluTrace AI API.

    All trace calls are fire-and-forget by default — they return instantly
    and the HTTP request is sent in a background thread. Your application
    is never blocked waiting for our server.

    Usage:
        ht = HalluTrace(api_key="sk_live_...")

        # Fire-and-forget (non-blocking, returns immediately)
        ht.trace(
            session_id="chat-123",
            type="agent",
            input="What is Python?",
            output="Python is a programming language.",
            model_name="gpt-4",
        )

        # Blocking mode if you need the response
        result = ht.trace(..., blocking=True)

        # Flush pending traces before exit
        ht.flush()
    """

    DEFAULT_BASE_URL = "https://api.hallutraceai.com"

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        timeout: float = 30.0,
        max_queue_size: int = 1000,
        worker_count: int = 2,
    ):
        if not api_key:
            raise HalluTraceError("api_key is required")

        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
            "User-Agent": "hallutraceai-python/0.1.3",
        })

        # Background queue for non-blocking sends
        self._queue: queue.Queue = queue.Queue(maxsize=max_queue_size)
        self._workers: list[threading.Thread] = []
        self._shutdown = threading.Event()

        for i in range(worker_count):
            t = threading.Thread(target=self._worker_loop, daemon=True, name=f"hallutraceai-worker-{i}")
            t.start()
            self._workers.append(t)

        # Auto-flush on interpreter exit
        atexit.register(self.flush)

    def _worker_loop(self):
        """Background worker that sends queued traces."""
        while not self._shutdown.is_set():
            try:
                item = self._queue.get(timeout=0.5)
            except queue.Empty:
                continue

            if item is None:  # Shutdown sentinel
                break

            method, path, data = item
            try:
                self._send(method, path, data)
            except Exception as e:
                logger.warning("HalluTrace background send failed: %s", e)
            finally:
                self._queue.task_done()

    def _send(self, method: str, path: str, data: dict | None = None) -> dict:
        """Synchronous HTTP request (used by workers and blocking mode)."""
        url = f"{self.base_url}{path}"
        try:
            resp = self._session.request(
                method,
                url,
                json=data,
                timeout=self.timeout,
            )
        except requests.RequestException as e:
            raise HalluTraceError(f"Request failed: {e}")

        if resp.status_code >= 400:
            try:
                body = resp.json()
                detail = body.get("detail", resp.text)
            except (json.JSONDecodeError, ValueError):
                detail = resp.text
            raise HalluTraceError(
                f"API error {resp.status_code}: {detail}",
                status_code=resp.status_code,
            )

        return resp.json()

    def trace(
        self,
        session_id: str,
        message_id: str | None = None,
        type: str = "agent",
        input: str = "",
        output: str = "",
        system_prompt: str | None = None,
        rag_context: str | None = None,
        model_name: str | None = None,
        token_count: int | None = None,
        metadata: dict[str, Any] | None = None,
        blocking: bool = False,
    ) -> dict | None:
        """Send a single trace to HalluTrace.

        By default this is non-blocking (fire-and-forget). The trace is
        queued and sent in a background thread. Returns None immediately.

        Set blocking=True to wait for the server response.

        Args:
            session_id: Unique identifier for the conversation session.
            message_id: Unique message ID (auto-generated if not provided).
            type: Message type - "agent" or "tool".
            input: The user input / prompt.
            output: The LLM response.
            system_prompt: System prompt used (optional).
            rag_context: RAG context provided (optional).
            model_name: LLM model name (optional).
            token_count: Token count for the response (optional).
            metadata: Additional session metadata (optional).
            blocking: If True, wait for response. Default False.

        Returns:
            API response dict if blocking=True, else None.
        """
        if not message_id:
            message_id = f"msg_{uuid.uuid4().hex[:12]}"

        message = {
            "message_id": message_id,
            "type": type,
            "input": input,
            "output": output,
        }
        if system_prompt is not None:
            message["system_prompt"] = system_prompt
        if rag_context is not None:
            message["rag_context"] = rag_context
        if model_name is not None:
            message["model_name"] = model_name
        if token_count is not None:
            message["token_count"] = token_count

        payload: dict[str, Any] = {
            "session_id": session_id,
            "messages": [message],
        }
        if metadata:
            payload["metadata"] = metadata

        if blocking:
            return self._send("POST", "/v1/traces", payload)

        # Non-blocking: queue for background send
        try:
            self._queue.put_nowait(("POST", "/v1/traces", payload))
        except queue.Full:
            logger.warning("HalluTrace queue full, dropping trace for session %s", session_id)
        return None

    def trace_batch(
        self,
        traces: list[dict],
        blocking: bool = False,
    ) -> dict | None:
        """Send multiple traces in a single request.

        Non-blocking by default. Set blocking=True to wait for response.

        Args:
            traces: List of trace dicts, each with:
                - session_id (str): Session identifier
                - messages (list): List of message dicts
                - metadata (dict, optional): Session metadata
            blocking: If True, wait for response. Default False.

        Returns:
            API response if blocking=True, else None.
        """
        # Auto-generate message_id for messages that don't have one
        for trace in traces:
            for msg in trace.get("messages", []):
                if "message_id" not in msg or not msg["message_id"]:
                    msg["message_id"] = f"msg_{uuid.uuid4().hex[:12]}"

        data = {"traces": traces}

        if blocking:
            return self._send("POST", "/v1/traces/batch", data)

        try:
            self._queue.put_nowait(("POST", "/v1/traces/batch", data))
        except queue.Full:
            logger.warning("HalluTrace queue full, dropping batch trace")
        return None

    def flush(self, timeout: float = 10.0):
        """Wait for all queued traces to be sent.

        Call this before your application exits to ensure no traces are lost.

        Args:
            timeout: Max seconds to wait. Default 10.
        """
        try:
            self._queue.join()
        except Exception:
            pass

    def close(self):
        """Shut down background workers and close HTTP session."""
        self._shutdown.set()
        # Send sentinel values to unblock workers
        for _ in self._workers:
            try:
                self._queue.put_nowait(None)
            except queue.Full:
                pass
        for w in self._workers:
            w.join(timeout=5.0)
        self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.flush()
        self.close()
