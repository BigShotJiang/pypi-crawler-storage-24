"""AgentBeat Python SDK — lightweight client for agent monitoring."""

import time
import requests
from contextlib import contextmanager
from typing import Optional


class AgentBeat:
    """Client for sending agent telemetry to AgentBeat server."""

    def __init__(self, base_url: str, agent_slug: str, agent_token: str):
        self.base_url = base_url.rstrip("/")
        self.agent_slug = agent_slug
        self.agent_token = agent_token
        self._session = requests.Session()
        self._session.headers["X-Agent-Token"] = agent_token
        self._session.headers["Content-Type"] = "application/json"

    def _url(self, endpoint: str) -> str:
        return f"{self.base_url}/a/{self.agent_slug}/{endpoint}"

    def start(self, metadata: Optional[dict] = None) -> str:
        """Start a new run. Returns run_id."""
        payload = {"sdk_version": "python-0.1.0"}
        if metadata:
            payload["metadata"] = metadata
        resp = self._session.post(self._url("start"), json=payload, timeout=5)
        resp.raise_for_status()
        return resp.json()["run_id"]

    def complete(
        self,
        run_id: Optional[str] = None,
        items_processed: Optional[int] = None,
        items_failed: Optional[int] = None,
        cost_usd: Optional[float] = None,
        tokens_input: Optional[int] = None,
        tokens_output: Optional[int] = None,
        model: Optional[str] = None,
        confidence: Optional[float] = None,
        metadata: Optional[dict] = None,
    ):
        """Complete a run with outcome metrics."""
        payload = {}
        if run_id:
            payload["run_id"] = run_id
        if items_processed is not None:
            payload["items_processed"] = items_processed
        if items_failed is not None:
            payload["items_failed"] = items_failed
        if cost_usd is not None:
            payload["cost_usd"] = cost_usd
        if tokens_input is not None:
            payload["tokens_input"] = tokens_input
        if tokens_output is not None:
            payload["tokens_output"] = tokens_output
        if model:
            payload["model"] = model
        if confidence is not None:
            payload["confidence"] = confidence
        if metadata:
            payload["metadata"] = metadata
        resp = self._session.post(self._url("complete"), json=payload, timeout=5)
        resp.raise_for_status()
        return resp.json()

    def fail(
        self,
        run_id: Optional[str] = None,
        error_message: str = "",
        cost_usd: Optional[float] = None,
        tokens_input: Optional[int] = None,
        tokens_output: Optional[int] = None,
        model: Optional[str] = None,
        metadata: Optional[dict] = None,
    ):
        """Mark a run as failed."""
        payload = {"error_message": error_message}
        if run_id:
            payload["run_id"] = run_id
        if cost_usd is not None:
            payload["cost_usd"] = cost_usd
        if tokens_input is not None:
            payload["tokens_input"] = tokens_input
        if tokens_output is not None:
            payload["tokens_output"] = tokens_output
        if model:
            payload["model"] = model
        if metadata:
            payload["metadata"] = metadata
        resp = self._session.post(self._url("fail"), json=payload, timeout=5)
        resp.raise_for_status()
        return resp.json()

    def heartbeat(self):
        """Send a simple heartbeat ping."""
        resp = self._session.get(self._url("heartbeat"), timeout=5)
        resp.raise_for_status()

    def step(
        self,
        run_id: str,
        name: str,
        status: str = "completed",
        duration_ms: Optional[int] = None,
        cost_usd: Optional[float] = None,
        tokens_input: Optional[int] = None,
        tokens_output: Optional[int] = None,
        model: Optional[str] = None,
        error_message: Optional[str] = None,
        metadata: Optional[dict] = None,
    ):
        """Report a step within a run."""
        payload = {"run_id": run_id, "name": name, "status": status}
        if duration_ms is not None:
            payload["duration_ms"] = duration_ms
        if cost_usd is not None:
            payload["cost_usd"] = cost_usd
        if tokens_input is not None:
            payload["tokens_input"] = tokens_input
        if tokens_output is not None:
            payload["tokens_output"] = tokens_output
        if model:
            payload["model"] = model
        if error_message:
            payload["error_message"] = error_message
        if metadata:
            payload["metadata"] = metadata
        resp = self._session.post(self._url("step"), json=payload, timeout=5)
        resp.raise_for_status()
        return resp.json()

    @contextmanager
    def run(self, metadata: Optional[dict] = None):
        """Context manager for a run. Auto-completes or fails."""
        run_id = self.start(metadata=metadata)
        context = RunContext(self, run_id)
        try:
            yield context
            self.complete(
                run_id=run_id,
                items_processed=context.items_processed,
                items_failed=context.items_failed,
                cost_usd=context.cost_usd,
                tokens_input=context.tokens_input,
                tokens_output=context.tokens_output,
                model=context.model,
                confidence=context.confidence,
                metadata=context.metadata,
            )
        except Exception as e:
            self.fail(
                run_id=run_id,
                error_message=str(e),
                cost_usd=context.cost_usd,
                tokens_input=context.tokens_input,
                tokens_output=context.tokens_output,
                model=context.model,
            )
            raise


class RunContext:
    """Mutable context object for tracking metrics within a run."""

    def __init__(self, client: AgentBeat, run_id: str):
        self.client = client
        self.run_id = run_id
        self.items_processed: Optional[int] = None
        self.items_failed: Optional[int] = None
        self.cost_usd: Optional[float] = None
        self.tokens_input: Optional[int] = None
        self.tokens_output: Optional[int] = None
        self.model: Optional[str] = None
        self.confidence: Optional[float] = None
        self.metadata: Optional[dict] = None
        self._step_seq = 0

    def step(self, name: str, **kwargs):
        """Report a step within this run."""
        self._step_seq += 1
        return self.client.step(run_id=self.run_id, name=name, **kwargs)

    @contextmanager
    def timed_step(self, name: str, **kwargs):
        """Context manager that auto-times a step."""
        start = time.time()
        try:
            yield
            duration_ms = int((time.time() - start) * 1000)
            self.step(name, status="completed", duration_ms=duration_ms, **kwargs)
        except Exception as e:
            duration_ms = int((time.time() - start) * 1000)
            self.step(name, status="failed", duration_ms=duration_ms, error_message=str(e), **kwargs)
            raise

    def add_cost(self, usd: float):
        """Accumulate cost."""
        if self.cost_usd is None:
            self.cost_usd = 0
        self.cost_usd += usd

    def add_tokens(self, input_tokens: int = 0, output_tokens: int = 0):
        """Accumulate token usage."""
        if input_tokens:
            self.tokens_input = (self.tokens_input or 0) + input_tokens
        if output_tokens:
            self.tokens_output = (self.tokens_output or 0) + output_tokens
