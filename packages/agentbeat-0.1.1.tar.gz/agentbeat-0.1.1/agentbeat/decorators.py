"""Decorators for automatic run/step tracking."""

import functools
import time
from typing import Optional

from .client import AgentBeat


def track_run(
    client: AgentBeat,
    metadata: Optional[dict] = None,
):
    """Decorator that wraps a function in a monitored run.

    Usage:
        ap = AgentBeat(base_url, slug, token)

        @track_run(ap)
        def my_agent_task(ctx):
            ctx.items_processed = 50
            ctx.cost_usd = 0.12
            ctx.model = "gpt-4o"
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with client.run(metadata=metadata) as ctx:
                return func(ctx, *args, **kwargs)
        return wrapper
    return decorator


def track_step(
    client: AgentBeat,
    run_id_kwarg: str = "run_id",
    name: Optional[str] = None,
):
    """Decorator that wraps a function as a timed step.

    Usage:
        @track_step(ap, name="process_data")
        def process(run_id):
            ...
    """
    def decorator(func):
        step_name = name or func.__name__

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            rid = kwargs.get(run_id_kwarg)
            start = time.time()
            try:
                result = func(*args, **kwargs)
                duration_ms = int((time.time() - start) * 1000)
                client.step(run_id=rid, name=step_name, status="completed", duration_ms=duration_ms)
                return result
            except Exception as e:
                duration_ms = int((time.time() - start) * 1000)
                client.step(run_id=rid, name=step_name, status="failed", duration_ms=duration_ms, error_message=str(e))
                raise
        return wrapper
    return decorator
