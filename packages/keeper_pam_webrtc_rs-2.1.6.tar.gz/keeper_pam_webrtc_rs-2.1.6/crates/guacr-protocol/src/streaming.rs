// Streaming Guacamole protocol parser
//
// High-performance streaming parser for Guacamole protocol instructions.
// Operates on partial byte buffers (streaming mode), unlike GuacamoleParser
// which parses complete Bytes. Used by the WebRTC transport layer for
// incremental instruction parsing from network buffers.
//
// Moved from keeper-pam-webrtc-rs/src/channel/guacd_parser.rs

use bytes::{BufMut, Bytes, BytesMut};
use smallvec::SmallVec;
use std::str;

// Guacamole protocol constants
pub const INST_TERM: u8 = b';';
pub const ARG_SEP: u8 = b',';
pub const ELEM_SEP: u8 = b'.';

/// Represents a fully parsed Guacamole protocol instruction with owned Strings.
/// This is typically used for error messages or when detailed inspection is needed,
/// or when an owned version of the instruction is required.
#[derive(Debug, Clone, PartialEq)]
pub struct OwnedInstruction {
    pub opcode: String,
    pub args: Vec<String>,
}

impl OwnedInstruction {
    pub fn new(opcode: String, args: Vec<String>) -> Self {
        Self { opcode, args }
    }
}

/// Backwards-compatible type alias
pub type GuacdInstruction = OwnedInstruction;

/// Error type for full Guacamole protocol instruction content parsing.
/// This is used when converting a content slice to an owned OwnedInstruction.
#[derive(Debug, thiserror::Error)]
pub enum StreamingParserError {
    #[error("Invalid instruction format: {0}")]
    InvalidFormat(String),
    #[error("UTF-8 error in instruction content: {0}")]
    Utf8Error(String),
}

/// Backwards-compatible type alias
pub type GuacdParserError = StreamingParserError;

impl From<str::Utf8Error> for StreamingParserError {
    fn from(err: str::Utf8Error) -> Self {
        StreamingParserError::Utf8Error(format!("UTF-8 conversion error: {}", err))
    }
}

/// Information about a Guacamole instruction peeked from a buffer, using borrowed slices.
#[derive(Debug, PartialEq)]
pub struct PeekedInstruction<'a> {
    /// Slice of the opcode.
    pub opcode: &'a str,
    /// Vector of slices for each argument. Uses SmallVec to avoid heap allocation for up to 4 args.
    pub args: SmallVec<[&'a str; 4]>,
    /// The total length of this instruction (including the terminator ';') in the input buffer.
    pub total_length_in_buffer: usize,
    /// True if the opcode is "error".
    pub is_error_opcode: bool,
}

// Common opcode constants for fast comparison
pub const ERROR_OPCODE: &str = "error";
pub const SIZE_OPCODE: &str = "size";
pub const DISCONNECT_OPCODE: &str = "disconnect";

/// Special opcodes that need custom processing beyond normal batching
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SpecialOpcode {
    #[allow(dead_code)]
    // Error opcodes use CloseConnection action directly, kept for API consistency
    Error,
    Size,
    #[allow(dead_code)]
    // Disconnect opcode indicates guacd is closing the connection cleanly
    // Maps to CloseConnection action directly, kept for API consistency
    Disconnect,
}

impl SpecialOpcode {
    /// Get the string representation (for logging and debugging)
    pub fn as_str(&self) -> &'static str {
        match self {
            SpecialOpcode::Error => ERROR_OPCODE,
            SpecialOpcode::Size => SIZE_OPCODE,
            SpecialOpcode::Disconnect => DISCONNECT_OPCODE,
        }
    }
}

/// Result of opcode analysis - what type of special processing is needed
#[derive(Debug, PartialEq)]
pub enum OpcodeAction {
    /// Normal instruction - batch with others
    Normal,
    /// Error instruction - close connection immediately
    CloseConnection,
    /// Special instruction needing custom processing
    ProcessSpecial(SpecialOpcode),
    /// Server sync keepalive - forward to client who must respond within 15s per protocol
    ServerSync,
}

/// Error type for the peeking operation.
#[derive(Debug, PartialEq, Clone)]
pub enum PeekError {
    /// Not enough data in the buffer to form a complete instruction.
    Incomplete,
    /// The instruction format is invalid.
    InvalidFormat(String),
    /// UTF-8 error encountered while trying to interpret parts of the instruction as string slices.
    Utf8Error(String),
}

// Convert std::str::Utf8Error to PeekError for convenience in peek_instruction
impl From<str::Utf8Error> for PeekError {
    fn from(err: str::Utf8Error) -> Self {
        PeekError::Utf8Error(format!("UTF-8 conversion error: {err}"))
    }
}

/// A stateless streaming parser for the Guacamole protocol.
/// Methods operate on provided buffer slices, supporting incremental/partial parsing.
pub struct StreamingParser;

impl StreamingParser {
    /// Fast search for a delimiter byte in a slice
    #[inline(always)]
    fn find_delimiter(slice: &[u8], delimiter: u8) -> Option<usize> {
        slice.iter().position(|&b| b == delimiter)
    }

    /// Fast integer parsing for small numbers (optimized for lengths)
    /// Most Guacamole instruction lengths are < 100
    #[inline(always)]
    fn parse_length(slice: &[u8]) -> Result<usize, ()> {
        if slice.is_empty() {
            return Err(());
        }

        // Handle single-digit optimizations
        if slice.len() == 1 {
            let b = slice[0];
            if b.is_ascii_digit() {
                return Ok((b - b'0') as usize);
            }
            return Err(());
        }

        let mut result = 0usize;
        for &b in slice {
            if !b.is_ascii_digit() {
                return Err(());
            }
            result = result * 10 + (b - b'0') as usize;
            // Prevent overflow for reasonable instruction sizes
            if result > 1_000_000 {
                return Err(());
            }
        }
        Ok(result)
    }

    /// Extract a UTF-8 string of a specific character count from a byte slice
    /// According to Guacamole protocol: "This length denotes the number of Unicode characters in the value"
    /// Returns (string_slice, byte_length) or error if not enough characters available
    #[inline(always)]
    fn extract_utf8_chars(
        buffer_slice: &[u8],
        start_pos: usize,
        char_count: usize,
    ) -> Result<(&str, usize), PeekError> {
        if char_count == 0 {
            return Ok(("", 0));
        }

        if start_pos >= buffer_slice.len() {
            return Err(PeekError::Incomplete);
        }

        let remaining_slice = &buffer_slice[start_pos..];

        // SIMD optimization on x86_64
        #[cfg(target_arch = "x86_64")]
        {
            if char_count <= remaining_slice.len() && char_count <= 64 {
                return Self::simd_extract_utf8_chars(remaining_slice, char_count);
            }
        }

        // Fast path for ASCII-only content (most common case)
        if char_count <= remaining_slice.len() {
            let potential_ascii_slice = &remaining_slice[..char_count];
            if potential_ascii_slice.is_ascii() {
                let extracted_str = unsafe {
                    // SAFETY: We've verified the slice is valid ASCII, so it's valid UTF-8
                    str::from_utf8_unchecked(potential_ascii_slice)
                };
                return Ok((extracted_str, char_count));
            }
        }

        // Multi-byte UTF-8 content requiring character counting
        Self::fallback_utf8_extract(remaining_slice, char_count)
    }

    /// SIMD-optimized UTF-8 character extraction
    #[cfg(target_arch = "x86_64")]
    #[inline(always)]
    fn simd_extract_utf8_chars(
        slice: &[u8],
        char_count: usize,
    ) -> Result<(&str, usize), PeekError> {
        use std::arch::x86_64::*;

        if slice.is_empty() || char_count == 0 {
            return Ok(("", 0));
        }

        // SIMD fast path: Check if entire slice is ASCII
        let mut ascii_end = 0;
        unsafe {
            // SAFETY: SSE2 is guaranteed available on x86_64 target
            let ascii_mask = _mm_set1_epi8(0x80u8 as i8);

            while ascii_end + 16 <= slice.len() {
                // SAFETY: We've verified ascii_end + 16 <= slice.len()
                let chunk = _mm_loadu_si128(slice.as_ptr().add(ascii_end) as *const __m128i);
                let has_non_ascii = _mm_movemask_epi8(_mm_and_si128(chunk, ascii_mask));

                if has_non_ascii != 0 {
                    break;
                }
                ascii_end += 16;
            }

            // Check remaining bytes (< 16 bytes)
            while ascii_end < slice.len() && slice[ascii_end] < 0x80 {
                ascii_end += 1;
            }
        }

        // If we have enough ASCII characters, use fast path
        if ascii_end >= char_count {
            let extracted_str = unsafe {
                // SAFETY: We've verified the slice is ASCII
                str::from_utf8_unchecked(&slice[..char_count])
            };
            return Ok((extracted_str, char_count));
        }

        // For mixed ASCII/UTF-8 content, fall back
        Self::fallback_utf8_extract(slice, char_count)
    }

    /// Fast character skipping without UTF-8 validation (for hot path opcode detection)
    /// Returns byte count to skip, does NOT validate UTF-8 quality or create strings
    #[inline(always)]
    fn skip_utf8_chars(slice: &[u8], char_count: usize) -> Result<usize, PeekError> {
        let mut byte_pos = 0;
        let mut chars_found = 0;

        const UTF8_CHAR_LEN: [u8; 256] = {
            let mut table = [0u8; 256];
            let mut i = 0;
            while i < 256 {
                table[i] = if i < 0x80 {
                    1 // ASCII
                } else if i < 0xC0 {
                    0 // Invalid start byte
                } else if i < 0xE0 {
                    2 // 2-byte UTF-8
                } else if i < 0xF0 {
                    3 // 3-byte UTF-8
                } else if i < 0xF8 {
                    4 // 4-byte UTF-8
                } else {
                    0 // Invalid
                };
                i += 1;
            }
            table
        };

        while byte_pos < slice.len() && chars_found < char_count {
            let byte = slice[byte_pos];
            let char_byte_len = UTF8_CHAR_LEN[byte as usize];

            if char_byte_len == 0 {
                return Err(PeekError::Utf8Error(format!(
                    "Invalid UTF-8 start byte 0x{:02X} at position {}",
                    byte, byte_pos
                )));
            }

            if byte_pos + char_byte_len as usize > slice.len() {
                return Err(PeekError::Incomplete);
            }

            byte_pos += char_byte_len as usize;
            chars_found += 1;
        }

        if chars_found < char_count {
            return Err(PeekError::Incomplete);
        }

        Ok(byte_pos)
    }

    /// Fallback UTF-8 character extraction (non-SIMD)
    #[inline(always)]
    fn fallback_utf8_extract(slice: &[u8], char_count: usize) -> Result<(&str, usize), PeekError> {
        let mut byte_pos = 0;
        let mut chars_found = 0;

        const UTF8_CHAR_LEN: [u8; 256] = {
            let mut table = [0u8; 256];
            let mut i = 0;
            while i < 256 {
                table[i] = if i < 0x80 {
                    1 // ASCII
                } else if i < 0xC0 {
                    0 // Invalid
                } else if i < 0xE0 {
                    2 // 2-byte UTF-8
                } else if i < 0xF0 {
                    3 // 3-byte UTF-8
                } else if i < 0xF8 {
                    4 // 4-byte UTF-8
                } else {
                    0 // Invalid
                };
                i += 1;
            }
            table
        };

        while byte_pos < slice.len() && chars_found < char_count {
            let byte = slice[byte_pos];
            let char_byte_len = UTF8_CHAR_LEN[byte as usize];

            if char_byte_len == 0 {
                return Err(PeekError::Utf8Error("Invalid UTF-8 start byte".to_string()));
            }

            if byte_pos + char_byte_len as usize > slice.len() {
                return Err(PeekError::Incomplete);
            }

            // Validate multi-byte sequences
            if char_byte_len > 1 {
                let end_pos = byte_pos + char_byte_len as usize;
                if str::from_utf8(&slice[byte_pos..end_pos]).is_err() {
                    return Err(PeekError::Utf8Error(format!(
                        "Invalid UTF-8 sequence at byte position {}",
                        byte_pos
                    )));
                }
            }

            byte_pos += char_byte_len as usize;
            chars_found += 1;
        }

        if chars_found < char_count {
            return Err(PeekError::Incomplete);
        }

        // SAFETY: We've already validated all multi-byte UTF-8 sequences in the loop above
        let extracted_str = unsafe { str::from_utf8_unchecked(&slice[..byte_pos]) };

        Ok((extracted_str, byte_pos))
    }

    /// Peeks at the beginning of the `buffer_slice` to find the first complete Guacamole instruction.
    /// If successful, returns a `PeekedInstruction` containing slices that borrow from `buffer_slice`.
    /// This operation is zero-copy for the instruction's string data.
    ///
    /// Returns borrowed data that references the input buffer.
    /// Returns Ok with instruction details and total length, or Err if incomplete/invalid.
    #[inline(always)]
    pub fn peek_instruction(buffer_slice: &[u8]) -> Result<PeekedInstruction<'_>, PeekError> {
        if buffer_slice.is_empty() {
            return Err(PeekError::Incomplete);
        }

        // Fast path for sync instruction (most common)
        if buffer_slice.len() >= 7 && &buffer_slice[0..7] == b"4.sync;" {
            return Ok(PeekedInstruction {
                opcode: "sync",
                args: SmallVec::new(),
                total_length_in_buffer: 7,
                is_error_opcode: false,
            });
        }

        let mut pos = 0;
        let mut arg_slices_vec: SmallVec<[&str; 4]> = SmallVec::new();

        // Parse opcode
        let initial_pos_for_opcode_len = pos;
        let length_end_op_rel =
            Self::find_delimiter(&buffer_slice[initial_pos_for_opcode_len..], ELEM_SEP)
                .ok_or_else(|| {
                    if Self::find_delimiter(&buffer_slice[initial_pos_for_opcode_len..], INST_TERM)
                        .is_some()
                    {
                        PeekError::InvalidFormat(
                            "Malformed opcode: no length delimiter before instruction end."
                                .to_string(),
                        )
                    } else {
                        PeekError::Incomplete
                    }
                })?;

        if initial_pos_for_opcode_len + length_end_op_rel >= buffer_slice.len() {
            return Err(PeekError::Incomplete);
        }

        let opcode_len_slice = &buffer_slice
            [initial_pos_for_opcode_len..initial_pos_for_opcode_len + length_end_op_rel];

        let length_op: usize = Self::parse_length(opcode_len_slice).map_err(|_| {
            let length_str_op = str::from_utf8(opcode_len_slice).unwrap_or("<invalid>");
            PeekError::InvalidFormat(format!("Opcode length not an integer: '{length_str_op}'"))
        })?;

        pos = initial_pos_for_opcode_len + length_end_op_rel + 1;

        // Extract opcode using character count
        let (opcode_str_slice, opcode_byte_len) = if length_op == 0 {
            ("", 0)
        } else {
            Self::extract_utf8_chars(buffer_slice, pos, length_op)?
        };
        pos += opcode_byte_len;

        // Parse arguments
        while pos < buffer_slice.len() && buffer_slice[pos] == ARG_SEP {
            pos += 1; // Skip ARG_SEP

            if pos >= buffer_slice.len() {
                return Err(PeekError::Incomplete);
            }

            let initial_pos_for_arg_len = pos;
            let length_end_arg_rel =
                Self::find_delimiter(&buffer_slice[initial_pos_for_arg_len..], ELEM_SEP)
                    .ok_or_else(|| {
                        if Self::find_delimiter(&buffer_slice[initial_pos_for_arg_len..], INST_TERM)
                            .is_some()
                        {
                            PeekError::InvalidFormat(
                                "Malformed argument: no length delimiter before instruction end."
                                    .to_string(),
                            )
                        } else {
                            PeekError::Incomplete
                        }
                    })?;

            if initial_pos_for_arg_len + length_end_arg_rel >= buffer_slice.len() {
                return Err(PeekError::Incomplete);
            }

            let arg_len_slice = &buffer_slice
                [initial_pos_for_arg_len..initial_pos_for_arg_len + length_end_arg_rel];

            let length_arg: usize = Self::parse_length(arg_len_slice).map_err(|_| {
                let length_str_arg = str::from_utf8(arg_len_slice).unwrap_or("<invalid>");
                PeekError::InvalidFormat(format!(
                    "Argument length not an integer: '{length_str_arg}'"
                ))
            })?;

            pos = initial_pos_for_arg_len + length_end_arg_rel + 1;

            let (arg_str_slice, arg_byte_len) =
                Self::extract_utf8_chars(buffer_slice, pos, length_arg)?;
            arg_slices_vec.push(arg_str_slice);
            pos += arg_byte_len;
        }

        // After parsing opcode and all args, current pos should be at the terminator
        if pos == buffer_slice.len() {
            return Err(PeekError::Incomplete);
        }

        if buffer_slice[pos] == INST_TERM {
            if length_op == 0 && opcode_byte_len == 0 && arg_slices_vec.is_empty() {
                return Ok(PeekedInstruction {
                    opcode: "",
                    args: SmallVec::new(),
                    total_length_in_buffer: pos + 1,
                    is_error_opcode: false,
                });
            }

            let is_err_op = opcode_str_slice == ERROR_OPCODE;
            Ok(PeekedInstruction {
                opcode: opcode_str_slice,
                args: arg_slices_vec,
                total_length_in_buffer: pos + 1,
                is_error_opcode: is_err_op,
            })
        } else {
            Err(PeekError::InvalidFormat(format!(
                "Expected instruction terminator ';' but found '{}' at buffer position {} (instruction content was: '{}')",
                buffer_slice[pos] as char, pos, str::from_utf8(&buffer_slice[..pos]).unwrap_or("<invalid_utf8>")
            )))
        }
    }

    /// Parses a Guacamole instruction content slice (must NOT include the trailing ';')
    /// into an owned `OwnedInstruction` with `String`s.
    pub fn parse_instruction_content(
        content_slice: &[u8],
    ) -> Result<OwnedInstruction, StreamingParserError> {
        let mut args_owned = Vec::new();
        let mut pos = 0;

        if content_slice.is_empty() {
            return Ok(OwnedInstruction::new("".to_string(), vec![]));
        }
        if content_slice.len() == 2 && content_slice[0] == b'0' && content_slice[1] == ELEM_SEP {
            return Ok(OwnedInstruction::new("".to_string(), vec![]));
        }

        // Parse opcode
        let length_end_op = content_slice[pos..]
            .iter()
            .position(|&b| b == ELEM_SEP)
            .ok_or_else(|| {
                StreamingParserError::InvalidFormat(
                    "Malformed opcode: no length delimiter".to_string(),
                )
            })?;

        let length_str_op = str::from_utf8(&content_slice[pos..pos + length_end_op])?;

        let length_op: usize = length_str_op.parse().map_err(|e| {
            StreamingParserError::InvalidFormat(format!(
                "Opcode length not an integer: {e}. Original: '{length_str_op}'"
            ))
        })?;

        pos += length_end_op + 1;

        // Extract opcode using character count
        let (opcode_str_slice, opcode_byte_len) =
            Self::extract_utf8_chars(content_slice, pos, length_op).map_err(|e| match e {
                PeekError::Incomplete => StreamingParserError::InvalidFormat(
                    "Opcode value goes beyond instruction content".to_string(),
                ),
                PeekError::InvalidFormat(msg) => StreamingParserError::InvalidFormat(msg),
                PeekError::Utf8Error(msg) => StreamingParserError::Utf8Error(msg),
            })?;
        let opcode_str = opcode_str_slice.to_string();
        pos += opcode_byte_len;

        // Parse arguments
        while pos < content_slice.len() {
            if content_slice[pos] != ARG_SEP {
                return Err(StreamingParserError::InvalidFormat(format!(
                    "Expected argument separator ',' but found '{}' at content position {}",
                    content_slice[pos] as char, pos
                )));
            }
            pos += 1; // Skip ARG_SEP

            if pos >= content_slice.len() {
                return Err(StreamingParserError::InvalidFormat(
                    "Dangling comma at end of instruction content".to_string(),
                ));
            }

            let length_end_arg = content_slice[pos..]
                .iter()
                .position(|&b| b == ELEM_SEP)
                .ok_or_else(|| {
                    StreamingParserError::InvalidFormat(
                        "Malformed argument: no length delimiter".to_string(),
                    )
                })?;

            let length_str_arg = str::from_utf8(&content_slice[pos..pos + length_end_arg])?;

            let length_arg: usize = length_str_arg.parse().map_err(|e| {
                StreamingParserError::InvalidFormat(format!(
                    "Argument length not an integer: {e}. Original: '{length_str_arg}'"
                ))
            })?;

            pos += length_end_arg + 1;

            // Extract argument using character count
            let (arg_str_slice, arg_byte_len) =
                Self::extract_utf8_chars(content_slice, pos, length_arg).map_err(|e| match e {
                    PeekError::Incomplete => StreamingParserError::InvalidFormat(
                        "Argument value goes beyond instruction content".to_string(),
                    ),
                    PeekError::InvalidFormat(msg) => StreamingParserError::InvalidFormat(msg),
                    PeekError::Utf8Error(msg) => StreamingParserError::Utf8Error(msg),
                })?;
            let arg_str = arg_str_slice.to_string();
            args_owned.push(arg_str);
            pos += arg_byte_len;
        }

        Ok(OwnedInstruction::new(opcode_str, args_owned))
    }

    /// Encode an instruction into Guacamole protocol format using BytesMut.
    /// Uses character counts for lengths as specified by the Guacamole protocol.
    pub fn guacd_encode_instruction(instruction: &OwnedInstruction) -> Bytes {
        Self::encode_instruction(instruction)
    }

    /// Encode an instruction into Guacamole protocol format using BytesMut.
    /// Uses character counts for lengths as specified by the Guacamole protocol.
    pub fn encode_instruction(instruction: &OwnedInstruction) -> Bytes {
        let estimated_size = instruction.opcode.len()
            + instruction
                .args
                .iter()
                .map(|arg| arg.len() + 10)
                .sum::<usize>()
            + instruction.args.len() * 2
            + 10;
        let mut buffer = BytesMut::with_capacity(estimated_size);

        // Use character count for opcode length (not byte count)
        buffer.put_slice(instruction.opcode.chars().count().to_string().as_bytes());
        buffer.put_u8(ELEM_SEP);
        buffer.put_slice(instruction.opcode.as_bytes());

        for arg in &instruction.args {
            buffer.put_u8(ARG_SEP);
            // Use character count for argument length (not byte count)
            buffer.put_slice(arg.chars().count().to_string().as_bytes());
            buffer.put_u8(ELEM_SEP);
            buffer.put_slice(arg.as_bytes());
        }
        buffer.put_u8(INST_TERM);
        buffer.freeze()
    }

    /// Helper for tests: decodes a complete raw instruction slice into OwnedInstruction.
    /// The input slice should be a single, complete Guacamole instruction *without* the final semicolon.
    pub fn guacd_decode_for_test(
        data_without_terminator: &[u8],
    ) -> Result<OwnedInstruction, StreamingParserError> {
        Self::parse_instruction_content(data_without_terminator)
    }

    /// Ultra-fast path: Validate format and detect special opcodes.
    /// Returns (total_bytes, action_needed) with zero allocations.
    #[inline(always)]
    pub fn validate_and_detect_special(
        buffer_slice: &[u8],
    ) -> Result<(usize, OpcodeAction), PeekError> {
        if buffer_slice.is_empty() {
            return Err(PeekError::Incomplete);
        }

        // Fast path for common "4.sync;" instruction (server keepalive)
        if buffer_slice.len() >= 7 && &buffer_slice[0..7] == b"4.sync;" {
            return Ok((7, OpcodeAction::ServerSync));
        }

        let mut pos = 0;

        // Parse opcode length
        let length_end =
            Self::find_delimiter(&buffer_slice[pos..], ELEM_SEP).ok_or(PeekError::Incomplete)?;

        if pos + length_end >= buffer_slice.len() {
            return Err(PeekError::Incomplete);
        }

        let opcode_len = Self::parse_length(&buffer_slice[pos..pos + length_end])
            .map_err(|_| PeekError::InvalidFormat("Invalid opcode length".to_string()))?;

        pos += length_end + 1; // Skip past length and '.'

        // Check for special ASCII opcodes first
        let action = if opcode_len > 0 && opcode_len <= 10 && pos + opcode_len <= buffer_slice.len()
        {
            let opcode_bytes = &buffer_slice[pos..pos + opcode_len];
            match opcode_bytes {
                b"error" => OpcodeAction::CloseConnection,
                b"disconnect" => OpcodeAction::CloseConnection,
                b"size" => OpcodeAction::ProcessSpecial(SpecialOpcode::Size),
                b"sync" => OpcodeAction::ServerSync,
                _ => OpcodeAction::Normal,
            }
        } else {
            OpcodeAction::Normal
        };

        // Skip opcode bytes without validation (hot path)
        let opcode_byte_len = if opcode_len == 0 {
            0
        } else if pos + opcode_len <= buffer_slice.len()
            && buffer_slice[pos..pos + opcode_len].is_ascii()
        {
            opcode_len
        } else {
            Self::skip_utf8_chars(&buffer_slice[pos..], opcode_len)?
        };

        pos += opcode_byte_len;

        // Skip through arguments without parsing
        while pos < buffer_slice.len() && buffer_slice[pos] == ARG_SEP {
            pos += 1; // Skip ','

            if pos >= buffer_slice.len() {
                return Err(PeekError::Incomplete);
            }

            let arg_len_end = Self::find_delimiter(&buffer_slice[pos..], ELEM_SEP)
                .ok_or(PeekError::Incomplete)?;

            if pos + arg_len_end >= buffer_slice.len() {
                return Err(PeekError::Incomplete);
            }

            let arg_len = Self::parse_length(&buffer_slice[pos..pos + arg_len_end])
                .map_err(|_| PeekError::InvalidFormat("Invalid argument length".to_string()))?;

            pos += arg_len_end + 1; // Skip past length and '.'

            let arg_byte_len = if pos + arg_len <= buffer_slice.len()
                && buffer_slice[pos..pos + arg_len].is_ascii()
            {
                arg_len
            } else {
                Self::skip_utf8_chars(&buffer_slice[pos..], arg_len)?
            };
            pos += arg_byte_len;
        }

        // Check for terminator
        if pos >= buffer_slice.len() {
            return Err(PeekError::Incomplete);
        }

        if buffer_slice[pos] != INST_TERM {
            let found_char = buffer_slice[pos] as char;
            let content_so_far = str::from_utf8(&buffer_slice[..pos]).unwrap_or("<invalid_utf8>");

            let mut error_msg = format!(
                "Expected instruction terminator ';' but found '{}' at buffer position {} (instruction content was: '{}')",
                found_char, pos, content_so_far
            );

            // UTF-8 debugging: Detect potential character vs byte count issues
            if content_so_far.contains(',') {
                if let Some(args_start) = content_so_far.find(',') {
                    let args_part = &content_so_far[args_start + 1..];
                    if args_part.chars().any(|c| c as u32 > 127) {
                        let char_count = args_part.chars().count();
                        let byte_count = args_part.len();
                        if char_count != byte_count {
                            error_msg.push_str(&format!(
                                ". UTF-8 ISSUE DETECTED: Content has {} characters but {} bytes. Client may be using character count instead of byte count for argument lengths.",
                                char_count, byte_count
                            ));
                        }
                    }
                }
            }

            return Err(PeekError::InvalidFormat(error_msg));
        }

        Ok((pos + 1, action))
    }
}

// Backwards-compatible aliases: GuacdParser delegates to StreamingParser
pub type GuacdParser = StreamingParser;
