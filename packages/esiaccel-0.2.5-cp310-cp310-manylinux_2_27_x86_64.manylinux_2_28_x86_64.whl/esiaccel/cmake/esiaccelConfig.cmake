add_library(esiaccel::ESICppRuntime SHARED IMPORTED)
set_target_properties(esiaccel::ESICppRuntime PROPERTIES
  INTERFACE_INCLUDE_DIRECTORIES "${CMAKE_CURRENT_LIST_DIR}/../include"
)

if(WIN32)
  # Default to Release variant for single-config generators and as fallback.
  # Multi-config generators (Visual Studio, Xcode) use the per-config
  # IMPORTED_LOCATION_<CONFIG> properties set below.
  set_target_properties(esiaccel::ESICppRuntime PROPERTIES
    IMPORTED_LOCATION "${CMAKE_CURRENT_LIST_DIR}/../ESICppRuntime.dll"
    IMPORTED_IMPLIB "${CMAKE_CURRENT_LIST_DIR}/../ESICppRuntime.lib"
  )
  set_target_properties(esiaccel::ESICppRuntime PROPERTIES
    IMPORTED_LOCATION_RELEASE "${CMAKE_CURRENT_LIST_DIR}/../ESICppRuntime.dll"
    IMPORTED_IMPLIB_RELEASE "${CMAKE_CURRENT_LIST_DIR}/../ESICppRuntime.lib"
    IMPORTED_LOCATION_DEBUG "${CMAKE_CURRENT_LIST_DIR}/../ESICppRuntime_d.dll"
    IMPORTED_IMPLIB_DEBUG "${CMAKE_CURRENT_LIST_DIR}/../ESICppRuntime_d.lib"
  )
else()
  set_target_properties(esiaccel::ESICppRuntime PROPERTIES
    IMPORTED_LOCATION "${CMAKE_CURRENT_LIST_DIR}/../lib/libESICppRuntime.so"
  )
endif()

add_library(esiaccel::CosimRpc SHARED IMPORTED)
set_target_properties(esiaccel::CosimRpc PROPERTIES
  INTERFACE_INCLUDE_DIRECTORIES "${CMAKE_CURRENT_LIST_DIR}/../include"
  INTERFACE_LINK_LIBRARIES esiaccel::ESICppRuntime
)

if(WIN32)
  set_target_properties(esiaccel::CosimRpc PROPERTIES
    IMPORTED_LOCATION "${CMAKE_CURRENT_LIST_DIR}/../CosimRpc.dll"
    IMPORTED_IMPLIB "${CMAKE_CURRENT_LIST_DIR}/../CosimRpc.lib"
  )
  set_target_properties(esiaccel::CosimRpc PROPERTIES
    IMPORTED_LOCATION_RELEASE "${CMAKE_CURRENT_LIST_DIR}/../CosimRpc.dll"
    IMPORTED_IMPLIB_RELEASE "${CMAKE_CURRENT_LIST_DIR}/../CosimRpc.lib"
    IMPORTED_LOCATION_DEBUG "${CMAKE_CURRENT_LIST_DIR}/../CosimRpc_d.dll"
    IMPORTED_IMPLIB_DEBUG "${CMAKE_CURRENT_LIST_DIR}/../CosimRpc_d.lib"
  )
else()
  set_target_properties(esiaccel::CosimRpc PROPERTIES
    IMPORTED_LOCATION "${CMAKE_CURRENT_LIST_DIR}/../lib/libCosimRpc.so"
  )
endif()

add_library(esiaccel::CosimBackend SHARED IMPORTED)
set_target_properties(esiaccel::CosimBackend PROPERTIES
  INTERFACE_INCLUDE_DIRECTORIES "${CMAKE_CURRENT_LIST_DIR}/../include"
  INTERFACE_LINK_LIBRARIES "esiaccel::ESICppRuntime;esiaccel::CosimRpc"
)

if(WIN32)
  set_target_properties(esiaccel::CosimBackend PROPERTIES
    IMPORTED_LOCATION "${CMAKE_CURRENT_LIST_DIR}/../CosimBackend.dll"
    IMPORTED_IMPLIB "${CMAKE_CURRENT_LIST_DIR}/../CosimBackend.lib"
  )
  set_target_properties(esiaccel::CosimBackend PROPERTIES
    IMPORTED_LOCATION_RELEASE "${CMAKE_CURRENT_LIST_DIR}/../CosimBackend.dll"
    IMPORTED_IMPLIB_RELEASE "${CMAKE_CURRENT_LIST_DIR}/../CosimBackend.lib"
    IMPORTED_LOCATION_DEBUG "${CMAKE_CURRENT_LIST_DIR}/../CosimBackend_d.dll"
    IMPORTED_IMPLIB_DEBUG "${CMAKE_CURRENT_LIST_DIR}/../CosimBackend_d.lib"
  )
else()
  set_target_properties(esiaccel::CosimBackend PROPERTIES
    IMPORTED_LOCATION "${CMAKE_CURRENT_LIST_DIR}/../lib/libCosimBackend.so"
  )
endif()
