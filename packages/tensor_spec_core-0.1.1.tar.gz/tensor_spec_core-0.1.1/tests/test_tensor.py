import pytest

from tensor_spec_core.device import Device, DeviceType
from tensor_spec_core.stats import FloatStats
from tensor_spec_core.tensor import (
    BoolTensorSpec,
    ComplexTensorSpec,
    FloatTensorSpec,
    IntTensorSpec,
    Tensor,
)


def test_tensor_float32_factory():
    spec = Tensor.float32((2, 3))
    assert isinstance(spec, FloatTensorSpec)
    assert spec.shape == (2, 3)
    assert spec.dtype == "float32"
    assert spec.device is None
    assert spec.stats is None
    assert spec.state is None


def test_tensor_float64_with_device():
    spec = Tensor.float64((1, 100), Device.cuda(0))
    assert spec.dtype == "float64"
    assert spec.device is not None
    assert spec.device.device_type == DeviceType.CUDA


def test_tensor_int64_factory():
    spec = Tensor.int64((10,))
    assert isinstance(spec, IntTensorSpec)
    assert spec.dtype == "int64"


def test_tensor_bool_factory():
    spec = Tensor.bool((3, 3))
    assert isinstance(spec, BoolTensorSpec)
    assert spec.dtype == "bool"


def test_tensor_complex64_factory():
    spec = Tensor.complex64((2, 3))
    assert isinstance(spec, ComplexTensorSpec)
    assert spec.dtype == "complex64"


def test_float_tensor_spec_with_stats():
    base = Tensor.float32((4, 4))
    spec = base.with_stats(FloatStats(positive_definite=True))
    assert spec.stats is not None
    assert spec.stats.positive_definite is True
    # Original unchanged (frozen)
    assert base.stats is None


def test_float_tensor_spec_with_state():
    from tensor_spec_core.state import TensorState

    base = Tensor.float32((2, 3))
    spec = base.with_state(TensorState(need_grad=True))
    assert spec.state is not None
    assert spec.state.need_grad is True


def test_all_float_dtypes():
    for dtype in ["float16", "float32", "float64", "bfloat16"]:
        spec = getattr(Tensor, dtype)((2,))
        assert isinstance(spec, FloatTensorSpec)
        assert spec.dtype == dtype


def test_all_int_dtypes():
    for dtype in ["int8", "int16", "int32", "int64", "uint8"]:
        spec = getattr(Tensor, dtype)((2,))
        assert isinstance(spec, IntTensorSpec)
        assert spec.dtype == dtype


def test_tensor_spec_frozen():
    spec = Tensor.float32((2, 3))
    with pytest.raises(AttributeError):
        setattr(spec, "shape", (4, 5))
