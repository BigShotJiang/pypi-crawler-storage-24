"""Dash integration helpers for als_computing_icons.

Requires ``dash`` to be installed::

    pip install als-computing-icons[dash]

Example usage in a Dash app::

    from dash import Dash, html
    from als_computing_icons import motor, icon_img

    app = Dash(__name__)
    app.layout = html.Div([
        icon_img(motor, color="steelblue", width=40),
    ])
"""

from __future__ import annotations

import base64
from typing import Optional


def _svg_to_data_uri(svg: str, color: Optional[str] = None) -> str:
    """Encode an SVG string as a base64 data URI.

    Args:
        svg: Raw SVG markup string.
        color: If provided, replaces ``currentColor`` with this CSS colour
            value before encoding.  Required when the URI is used inside an
            ``<img>`` element, because ``<img>`` renders in an isolated
            context where CSS colour inheritance does not apply.

    Returns:
        A ``data:image/svg+xml;base64,…`` string.
    """
    if color is not None:
        svg = svg.replace("currentColor", color)
    encoded = base64.b64encode(svg.encode("utf-8")).decode("ascii")
    return f"data:image/svg+xml;base64,{encoded}"


def icon_src(svg: str, color: Optional[str] = None) -> str:
    """Return a base64 ``data:`` URI for the given SVG string.

    Use this when you need the raw URL, e.g. to set ``src`` on an
    ``html.Img`` component yourself or to use the icon as a CSS
    ``background-image``.

    Args:
        svg: Raw SVG markup, e.g. ``from als_computing_icons import motor``.
        color: CSS colour to substitute for ``currentColor``.  Pass ``None``
            to keep ``currentColor`` (only meaningful if the data URI is
            used somewhere that inherits CSS colour, which ``<img>`` does
            *not*).

    Returns:
        A ``data:image/svg+xml;base64,…`` string.

    Example::

        from dash import html
        from als_computing_icons import motor, icon_src

        html.Img(src=icon_src(motor, color="steelblue"), width=40)
    """
    return _svg_to_data_uri(svg, color=color)


def icon_img(svg: str, color: str = "#000000", **props) -> "dash.html.Img":  # type: ignore[name-defined]
    """Return a Dash ``html.Img`` component that displays an SVG icon.

    ``currentColor`` inside the SVG is replaced with *color* so the icon
    renders correctly inside a plain ``<img>`` element (which does not
    inherit CSS colour from the surrounding DOM).

    Args:
        svg: Raw SVG markup, e.g. ``from als_computing_icons import motor``.
        color: CSS colour string (hex, ``rgb(…)``, named colour …).
            Defaults to ``"#000000"`` (black).
        **props: Extra keyword arguments forwarded to ``dash.html.Img``,
            such as ``style``, ``className``, ``id``, ``width``,
            ``height``, ``alt``, …

    Returns:
        A ``dash.html.Img`` component.

    Raises:
        ImportError: If ``dash`` is not installed.

    Example::

        from dash import Dash, html
        from als_computing_icons import motor, icon_img

        app = Dash(__name__)
        app.layout = html.Div([
            icon_img(motor, color="steelblue", width=40, alt="Motor icon"),
        ])
    """
    try:
        from dash import html
    except ImportError as exc:
        raise ImportError(
            "dash is required to use icon_img(). "
            "Install it with:  pip install als-computing-icons[dash]"
        ) from exc

    src = _svg_to_data_uri(svg, color=color)
    return html.Img(src=src, **props)
