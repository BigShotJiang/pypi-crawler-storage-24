# Program Uninstaller

TUI application for removing packages and searching for leftovers on Linux.

## Features
- Remove packages via pacman, dnf, apt, zypper, flatpak
- Search for leftover files in ~/.config, ~/.local, ~/.cache
- Clean TUI interface

## Requirements
Python 3
PIP
Textual

## Installation
```bash
pip install program-uninstaller
```

## Usage
```bash
program-uninstaller
```
or through app menu of your DE

## Supported Package Managers
- Arch Linux (pacman)
- Fedora/RHEL (dnf)
- Debian/Ubuntu/Mint (apt)
- openSUSE (zypper)

##LICENCE
MIT
