
from setuptools import setup, find_packages
setup(
    name="syko-llm",
    version="0.1.1",
    packages=find_packages(),
    install_requires=["torch", "transformers"],
)
