# SuperOptiX utilities
