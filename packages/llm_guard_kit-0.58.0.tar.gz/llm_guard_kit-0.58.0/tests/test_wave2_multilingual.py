# tests/test_wave2_multilingual.py
"""Tests for MultilingualSCScorer (wave2 29.10)."""
from __future__ import annotations

import sys
from pathlib import Path
import pytest
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

MULTILINGUAL_MODEL = str(ROOT / "models" / "multilingual-minilm")


def _make_chain(question="What is the capital?", answer="Paris", correct=True):
    return {
        "question": question,
        "final_answer": answer,
        "steps": [{"thought": "Looking it up.",
                   "action_type": "Search",
                   "action_arg": question,
                   "observation": f"The answer is {answer}. Some more text for context."}],
        "correct": correct,
        "finished": True,
    }


def test_import():
    from llm_guard.multilingual_sc_scorer import MultilingualSCScorer
    assert MultilingualSCScorer is not None


def test_instantiates():
    from llm_guard.multilingual_sc_scorer import MultilingualSCScorer
    scorer = MultilingualSCScorer(model_path=MULTILINGUAL_MODEL)
    assert scorer.model_path == MULTILINGUAL_MODEL
    assert not scorer.is_fitted


def test_fit_returns_self():
    from llm_guard.multilingual_sc_scorer import MultilingualSCScorer
    scorer = MultilingualSCScorer(model_path=MULTILINGUAL_MODEL)
    chains = [_make_chain(correct=True) for _ in range(8)] + \
             [_make_chain(correct=False) for _ in range(8)]
    labels = np.array([0] * 8 + [1] * 8)
    result = scorer.fit(chains, labels)
    assert result is scorer
    assert scorer.is_fitted


def test_score_chain_returns_float():
    from llm_guard.multilingual_sc_scorer import MultilingualSCScorer
    scorer = MultilingualSCScorer(model_path=MULTILINGUAL_MODEL)
    chains = [_make_chain(correct=True) for _ in range(8)] + \
             [_make_chain(correct=False) for _ in range(8)]
    labels = np.array([0] * 8 + [1] * 8)
    scorer.fit(chains, labels)
    score = scorer.score_chain(_make_chain())
    assert isinstance(score, float)
    assert 0.0 <= score <= 1.0


def test_score_chain_raises_if_not_fitted():
    from llm_guard.multilingual_sc_scorer import MultilingualSCScorer
    scorer = MultilingualSCScorer(model_path=MULTILINGUAL_MODEL)
    with pytest.raises(RuntimeError):
        scorer.score_chain(_make_chain())


def test_feature_extraction_returns_array():
    from llm_guard.multilingual_sc_scorer import MultilingualSCScorer
    scorer = MultilingualSCScorer(model_path=MULTILINGUAL_MODEL)
    feat = scorer.extract_features(_make_chain())
    assert isinstance(feat, np.ndarray)
    assert feat.shape == (12,)  # 12 MFE Phase A features


def test_multilingual_query_does_not_crash():
    """Scorer should handle Arabic/Spanish/Chinese text without error."""
    from llm_guard.multilingual_sc_scorer import MultilingualSCScorer
    scorer = MultilingualSCScorer(model_path=MULTILINGUAL_MODEL)
    chains_en = [_make_chain(correct=True) for _ in range(8)] + \
                [_make_chain(correct=False) for _ in range(8)]
    labels = np.array([0] * 8 + [1] * 8)
    scorer.fit(chains_en, labels)
    arabic_chain = _make_chain(question="ما هي عاصمة فرنسا؟", answer="باريس")
    score = scorer.score_chain(arabic_chain)
    assert isinstance(score, float)
