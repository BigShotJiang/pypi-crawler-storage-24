from plyer import notification
from rpa_quaestvm.logger import Logger


def print_log(title="", message="", timeout=0, app_name="", print_console=True, log_path="logs/rpa.log"):
    logger = Logger.get_logger(log_path)
    try:
        notification.notify( title=title, message=message, app_name=app_name, timeout=timeout)
    except Exception as e:
        logger.error(f"erro no plyer para <title={title}; message={message}>: {e}")

    if print_console:
        logger.info(f"{title}: {message}")