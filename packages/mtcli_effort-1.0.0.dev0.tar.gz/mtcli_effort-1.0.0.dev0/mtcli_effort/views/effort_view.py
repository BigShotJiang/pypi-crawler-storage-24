"""
View do plugin mtcli-effort.

Responsável por:
- exibir resultados de forma textual
- garantir acessibilidade para leitores de tela
"""

from ..conf import DIGITOS


def exibir_resultado(
    symbol: str,
    bars: int,
    metricas: dict,
    sinal: str | None,
):
    """
    Exibe resultado principal da análise.

    :param symbol: ativo
    :param bars: quantidade de candles
    :param metricas: métricas calculadas
    :param sinal: sinal detectado
    """

    print("Análise de esforço versus resultado")
    print(f"Ativo {symbol}")
    print(f"Periodo analisado {bars} candles")
    print(f"Media do range {metricas['media_range']:.{DIGITOS}f}")
    print(f"Media do volume {metricas['media_volume']:.0f}")
    print(f"Relacao range por volume {metricas['relacao']:.5f}")
    print("")

    if metricas["relacao"] < 0.0001:
        print("Alto esforco com pouco resultado. Possivel absorcao.")
    else:
        print("Esforco compativel com resultado. Movimento saudavel.")

    print("")

    if sinal:
        print(f"Sinal detectado: {sinal}")
        print("")


def exibir_classificacao(classificacoes: list):
    """
    Exibe classificação dos últimos candles em ordem crescente
    (do mais antigo para o mais recente).
    """

    print("Classificacao dos ultimos candles:")

    ultimos = classificacoes[-5:]

    for idx, tipo in enumerate(ultimos, 1):
        print(f"{idx} {tipo}")
