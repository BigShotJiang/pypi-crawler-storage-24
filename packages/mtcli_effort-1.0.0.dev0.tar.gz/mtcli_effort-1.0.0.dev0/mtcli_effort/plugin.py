"""
Registro do plugin mtcli-effort no mtcli principal.
"""

from .cli import effort


def register(cli):
    """
    Registra o comando 'effort' no mtcli principal.
    """
    cli.add_command(effort, name="effort")
