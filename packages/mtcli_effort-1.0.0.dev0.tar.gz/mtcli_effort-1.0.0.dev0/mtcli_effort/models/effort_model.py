"""
Model de cálculo de esforço vs resultado.

Responsável por:
- obter candles do MetaTrader5
- calcular range (high - low)
- calcular métricas (range, volume, eficiência)
- classificar candles (força, absorção, clímax)
- detectar continuidade (H2 / L2 simplificado)
"""

from typing import List, Dict
import MetaTrader5 as mt5


# ==========================================================
# DADOS
# ==========================================================

def obter_candles(simbolo: str, timeframe: int, quantidade: int) -> List[Dict]:
    """
    Obtém candles do MT5.

    :return: lista de candles (dict-like)
    """
    rates = mt5.copy_rates_from_pos(simbolo, timeframe, 0, quantidade)

    if rates is None:
        raise RuntimeError("Erro ao obter candles do MT5.")

    return list(rates)


# ==========================================================
# MÉTRICAS BÁSICAS
# ==========================================================

def calcular_range(candle: Dict) -> float:
    return candle["high"] - candle["low"]


def calcular_corpo(candle: Dict) -> float:
    return abs(candle["close"] - candle["open"])


def proporcao_corpo(candle: Dict) -> float:
    range_ = calcular_range(candle)
    if range_ == 0:
        return 0.0
    return calcular_corpo(candle) / range_


def media(valores: List[float]) -> float:
    if not valores:
        return 0.0
    return sum(valores) / len(valores)


# ==========================================================
# MÉTRICAS GERAIS
# ==========================================================

def calcular_metricas(candles: List[Dict]) -> Dict:
    ranges = [calcular_range(c) for c in candles]
    volumes = [c["tick_volume"] for c in candles]

    media_range = media(ranges)
    media_volume = media(volumes)

    relacao = 0.0
    if media_volume > 0:
        relacao = media_range / media_volume

    return {
        "media_range": media_range,
        "media_volume": media_volume,
        "relacao": relacao,
    }


# ==========================================================
# HELPERS DE FECHAMENTO
# ==========================================================

def fechamento_proximo_maxima(candle: Dict, tolerancia: float = 0.2) -> bool:
    range_ = calcular_range(candle)
    if range_ == 0:
        return False

    distancia = candle["high"] - candle["close"]
    return (distancia / range_) <= tolerancia


def fechamento_proximo_minima(candle: Dict, tolerancia: float = 0.2) -> bool:
    range_ = calcular_range(candle)
    if range_ == 0:
        return False

    distancia = candle["close"] - candle["low"]
    return (distancia / range_) <= tolerancia


# ==========================================================
# CLASSIFICAÇÃO
# ==========================================================

def classificar_candle(candle: Dict, media_range: float, media_volume: float) -> str:
    range_ = calcular_range(candle)
    volume = candle["tick_volume"]
    corpo_prop = proporcao_corpo(candle)

    # Normalização (eficiência relativa)
    range_norm = range_ / media_range if media_range > 0 else 0
    volume_norm = volume / media_volume if media_volume > 0 else 0

    # ======================================================
    # FORÇA COMPRADORA
    # ======================================================
    if (
        range_norm > 1.5
        and volume_norm > 1.5
        and corpo_prop > 0.5
        and fechamento_proximo_maxima(candle)
        and candle["close"] > candle["open"]
    ):
        return "STRONG_BULL"

    # ======================================================
    # FORÇA VENDEDORA
    # ======================================================
    if (
        range_norm > 1.5
        and volume_norm > 1.5
        and corpo_prop > 0.5
        and fechamento_proximo_minima(candle)
        and candle["close"] < candle["open"]
    ):
        return "STRONG_BEAR"

    # ======================================================
    # ABSORÇÃO (esforço > resultado)
    # ======================================================
    if volume_norm > range_norm:
        return "ABSORPTION"

    # ======================================================
    # CLÍMAX
    # ======================================================
    if range_norm > 2 and volume_norm > 2:
        return "CLIMAX"

    return "NEUTRAL"


def classificar_candles(
    candles: List[Dict],
    media_range: float,
    media_volume: float,
) -> List[str]:
    """
    Classifica todos os candles usando métricas já calculadas.
    """
    return [
        classificar_candle(c, media_range, media_volume)
        for c in candles
    ]


# ==========================================================
# CONTINUIDADE
# ==========================================================

def detectar_continuacao(
    candles: List[Dict],
    classificacoes: List[str],
) -> str | None:

    if len(candles) < 2:
        return None

    c1, c2 = candles[-2], candles[-1]
    t1, t2 = classificacoes[-2], classificacoes[-1]

    if (
        t1 == "STRONG_BULL"
        and t2 == "STRONG_BULL"
        and c2["close"] > c1["high"]
    ):
        return "CONTINUACAO_COMPRA"

    if (
        t1 == "STRONG_BEAR"
        and t2 == "STRONG_BEAR"
        and c2["close"] < c1["low"]
    ):
        return "CONTINUACAO_VENDA"

    return None
