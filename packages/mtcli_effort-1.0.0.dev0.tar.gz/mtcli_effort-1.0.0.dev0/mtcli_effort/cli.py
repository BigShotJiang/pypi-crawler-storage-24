"""
CLI do plugin mtcli-effort.

Responsável por:
- definir comando CLI
- validar parâmetros de entrada
- acionar o controller
"""

import click

from mtcli.logger import setup_logger
from mtcli.domain.timeframe import Timeframe

from .controllers.effort_controller import executar
from .conf import (
    SYMBOL,
    TIMEFRAME,
    BARS,
)

log = setup_logger(__name__)


@click.command(name="effort")
@click.version_option(package_name="mtcli-effort")
@click.option(
    "-s",
    "--symbol",
    default=SYMBOL,
    show_default=True,
    help="Código do ativo.",
)
@click.option(
    "-t",
    "--timeframe",
    default=TIMEFRAME,
    show_default=True,
    help="Timeframe base (ex: M1, M5, H1).",
)
@click.option(
    "-b",
    "--bars",
    default=BARS,
    show_default=True,
    help="Quantidade de candles.",
)
def effort(symbol: str, timeframe: str, bars: int):
    """
    Comando CLI para análise de esforço vs resultado.
    """

    # ------------------------------------------
    # Validações
    # ------------------------------------------
    if not symbol.strip():
        raise click.BadParameter("symbol inválido.")

    if bars <= 0:
        raise click.BadParameter("bars deve ser maior que zero.")

    try:
        tf_enum = Timeframe.from_string(timeframe)
    except ValueError as e:
        raise click.BadParameter(str(e))

    log.debug(
        f"CLI acionada | symbol={symbol} timeframe={timeframe} bars={bars}"
    )

    # ------------------------------------------
    # Execução
    # ------------------------------------------
    try:
        executar(symbol, tf_enum.mt5_const, bars)

    except Exception as e:
        log.exception(f"Erro ao executar comando effort: {e}")
        raise click.ClickException(str(e))
