"""
Controller do plugin mtcli-effort.

Responsável por:
- orquestrar fluxo entre model e view
- executar análise de esforço vs resultado
"""

from mtcli.logger import setup_logger
from mtcli.mt5_context import mt5_conexao

from ..models.effort_model import (
    obter_candles,
    calcular_metricas,
    classificar_candles,
    detectar_continuacao,
)

from ..views.effort_view import (
    exibir_resultado,
    exibir_classificacao,
)

log = setup_logger(__name__)


def executar(symbol: str, timeframe: int, bars: int):
    """
    Executa pipeline completo da análise.

    :param symbol: ativo
    :param timeframe: timeframe MT5
    :param bars: quantidade de candles
    """

    log.info(
        f"Iniciando análise effort | symbol={symbol} timeframe={timeframe} bars={bars}"
    )

    # ------------------------------------------
    # Conexão padrão MT5 (context manager)
    # ------------------------------------------
    with mt5_conexao():
        # ------------------------------------------
        # Obter dados
        # ------------------------------------------
        candles = obter_candles(symbol, timeframe, bars)

        if not candles:
            log.error("Nenhum candle retornado.")
            raise RuntimeError("Nenhum candle retornado.")

        log.debug(f"{len(candles)} candles obtidos com sucesso.")

        # ------------------------------------------
        # Métricas
        # ------------------------------------------
        metricas = calcular_metricas(candles)

        log.debug(
            f"Métricas calculadas | "
            f"range_medio={metricas['media_range']:.2f} "
            f"volume_medio={metricas['media_volume']:.2f}"
        )

        # ------------------------------------------
        # Classificação
        # ------------------------------------------
        classificacoes = classificar_candles(
            candles,
            metricas["media_range"],
            metricas["media_volume"],
        )

        log.debug("Classificação de candles concluída.")

        # ------------------------------------------
        # Continuação
        # ------------------------------------------
        sinal = detectar_continuacao(candles, classificacoes)

        log.info(f"Sinal detectado: {sinal}")

        # ------------------------------------------
        # Saída (view)
        # ------------------------------------------

        exibir_resultado(
            symbol=symbol,
            bars=bars,
            metricas=metricas,
            sinal=sinal,
        )

        exibir_classificacao(classificacoes)

    log.info("Análise effort finalizada com sucesso.")
