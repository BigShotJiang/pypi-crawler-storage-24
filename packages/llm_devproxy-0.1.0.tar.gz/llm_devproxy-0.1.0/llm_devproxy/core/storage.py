"""
SQLite storage layer.
Every API call is automatically persisted. Nothing is lost.
"""

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from .models import RequestRecord, Session, CostLimit


class Storage:
    def __init__(self, db_path: str = ".llm_devproxy.db"):
        self.db_path = Path(db_path)
        self._init_db()

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_db(self):
        with self._conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS sessions (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    last_accessed TEXT NOT NULL,
                    description TEXT DEFAULT '',
                    tags TEXT DEFAULT '[]',
                    total_cost_usd REAL DEFAULT 0.0,
                    step_count INTEGER DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS requests (
                    id TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL,
                    step_id INTEGER DEFAULT 0,
                    parent_id TEXT,
                    branch_name TEXT DEFAULT 'main',
                    timestamp TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    model TEXT NOT NULL,
                    prompt_hash TEXT NOT NULL,
                    request_body TEXT NOT NULL,
                    response_body TEXT NOT NULL,
                    input_tokens INTEGER DEFAULT 0,
                    output_tokens INTEGER DEFAULT 0,
                    cost_usd REAL DEFAULT 0.0,
                    is_cached INTEGER DEFAULT 0,
                    tags TEXT DEFAULT '[]',
                    memo TEXT DEFAULT '',
                    FOREIGN KEY (session_id) REFERENCES sessions(id)
                );

                CREATE TABLE IF NOT EXISTS cost_limits (
                    scope TEXT PRIMARY KEY,
                    limit_usd REAL NOT NULL,
                    current_usd REAL DEFAULT 0.0,
                    action TEXT DEFAULT 'mock',
                    reset_at TEXT
                );

                CREATE INDEX IF NOT EXISTS idx_requests_session
                    ON requests(session_id);
                CREATE INDEX IF NOT EXISTS idx_requests_prompt_hash
                    ON requests(prompt_hash);
                CREATE INDEX IF NOT EXISTS idx_requests_timestamp
                    ON requests(timestamp);
            """)

    # ── Sessions ──────────────────────────────────────────────

    def save_session(self, session: Session) -> Session:
        with self._conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO sessions
                (id, name, created_at, last_accessed, description, tags,
                 total_cost_usd, step_count)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                session.id, session.name,
                session.created_at.isoformat(),
                session.last_accessed.isoformat(),
                session.description,
                json.dumps(session.tags, ensure_ascii=False),
                session.total_cost_usd,
                session.step_count,
            ))
        return session

    def get_session(self, session_id: str) -> Optional[Session]:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM sessions WHERE id = ?", (session_id,)
            ).fetchone()
        return self._row_to_session(row) if row else None

    def get_session_by_name(self, name: str) -> Optional[Session]:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM sessions WHERE name = ?", (name,)
            ).fetchone()
        return self._row_to_session(row) if row else None

    def list_sessions(self, limit: int = 20) -> list[Session]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM sessions ORDER BY last_accessed DESC LIMIT ?",
                (limit,)
            ).fetchall()
        return [self._row_to_session(r) for r in rows]

    def update_session_stats(self, session_id: str, cost: float):
        with self._conn() as conn:
            conn.execute("""
                UPDATE sessions
                SET total_cost_usd = total_cost_usd + ?,
                    step_count = step_count + 1,
                    last_accessed = ?
                WHERE id = ?
            """, (cost, datetime.now(timezone.utc).isoformat(), session_id))

    # ── Requests ──────────────────────────────────────────────

    def save_request(self, record: RequestRecord) -> RequestRecord:
        with self._conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO requests
                (id, session_id, step_id, parent_id, branch_name,
                 timestamp, provider, model, prompt_hash,
                 request_body, response_body,
                 input_tokens, output_tokens, cost_usd,
                 is_cached, tags, memo)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                record.id, record.session_id, record.step_id,
                record.parent_id, record.branch_name,
                record.timestamp.isoformat(),
                record.provider, record.model, record.prompt_hash,
                json.dumps(record.request_body, ensure_ascii=False),
                json.dumps(record.response_body, ensure_ascii=False),
                record.input_tokens, record.output_tokens,
                record.cost_usd, int(record.is_cached),
                json.dumps(record.tags, ensure_ascii=False), record.memo,
            ))
        return record

    def find_cached(self, prompt_hash: str, model: str) -> Optional[RequestRecord]:
        """キャッシュヒットを探す（同じhash + modelの最新を返す）"""
        with self._conn() as conn:
            row = conn.execute("""
                SELECT * FROM requests
                WHERE prompt_hash = ? AND model = ? AND is_cached = 0
                ORDER BY timestamp DESC LIMIT 1
            """, (prompt_hash, model)).fetchone()
        return self._row_to_request(row) if row else None

    def get_requests_by_session(
        self, session_id: str, branch: str = "main"
    ) -> list[RequestRecord]:
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT * FROM requests
                WHERE session_id = ? AND branch_name = ?
                ORDER BY step_id ASC
            """, (session_id, branch)).fetchall()
        return [self._row_to_request(r) for r in rows]

    def get_request_at_step(
        self, session_id: str, step_id: int, branch: str = "main"
    ) -> Optional[RequestRecord]:
        with self._conn() as conn:
            row = conn.execute("""
                SELECT * FROM requests
                WHERE session_id = ? AND step_id = ? AND branch_name = ?
                ORDER BY timestamp DESC LIMIT 1
            """, (session_id, step_id, branch)).fetchone()
        return self._row_to_request(row) if row else None

    def search_requests(self, keyword: str, limit: int = 20) -> list[RequestRecord]:
        """プロンプト内容でキーワード検索"""
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT * FROM requests
                WHERE request_body LIKE ?
                ORDER BY timestamp DESC LIMIT ?
            """, (f"%{keyword}%", limit)).fetchall()
        return [self._row_to_request(r) for r in rows]

    def add_tag(self, request_id: str, tag: str):
        with self._conn() as conn:
            row = conn.execute(
                "SELECT tags FROM requests WHERE id = ?", (request_id,)
            ).fetchone()
            if row:
                tags = json.loads(row["tags"])
                if tag not in tags:
                    tags.append(tag)
                conn.execute(
                    "UPDATE requests SET tags = ? WHERE id = ?",
                    (json.dumps(tags, ensure_ascii=False), request_id)
                )

    def add_memo(self, request_id: str, memo: str):
        with self._conn() as conn:
            conn.execute(
                "UPDATE requests SET memo = ? WHERE id = ?",
                (memo, request_id)
            )

    # ── Cost ──────────────────────────────────────────────────

    def get_daily_cost(self) -> float:
        today = datetime.now(timezone.utc).date().isoformat()
        with self._conn() as conn:
            row = conn.execute("""
                SELECT SUM(cost_usd) as total FROM requests
                WHERE timestamp LIKE ? AND is_cached = 0
            """, (f"{today}%",)).fetchone()
        return row["total"] or 0.0

    def get_session_cost(self, session_id: str) -> float:
        with self._conn() as conn:
            row = conn.execute("""
                SELECT SUM(cost_usd) as total FROM requests
                WHERE session_id = ? AND is_cached = 0
            """, (session_id,)).fetchone()
        return row["total"] or 0.0

    # ── Compress old records ───────────────────────────────────

    def compress_old_records(self, older_than_days: int = 30):
        """古いレスポンス本文を圧縮（メタデータは保持）"""
        cutoff = (
            datetime.now(timezone.utc) - timedelta(days=older_than_days)
        ).isoformat()
        with self._conn() as conn:
            conn.execute("""
                UPDATE requests
                SET response_body = '{"compressed": true}'
                WHERE timestamp < ? AND response_body != '{"compressed": true}'
            """, (cutoff,))

    # ── Converters ────────────────────────────────────────────

    def _row_to_session(self, row) -> Session:
        return Session(
            id=row["id"],
            name=row["name"],
            created_at=datetime.fromisoformat(row["created_at"]),
            last_accessed=datetime.fromisoformat(row["last_accessed"]),
            description=row["description"],
            tags=json.loads(row["tags"]),
            total_cost_usd=row["total_cost_usd"],
            step_count=row["step_count"],
        )

    def _row_to_request(self, row) -> RequestRecord:
        return RequestRecord(
            id=row["id"],
            session_id=row["session_id"],
            step_id=row["step_id"],
            parent_id=row["parent_id"],
            branch_name=row["branch_name"],
            timestamp=datetime.fromisoformat(row["timestamp"]),
            provider=row["provider"],
            model=row["model"],
            prompt_hash=row["prompt_hash"],
            request_body=json.loads(row["request_body"]),
            response_body=json.loads(row["response_body"]),
            input_tokens=row["input_tokens"],
            output_tokens=row["output_tokens"],
            cost_usd=row["cost_usd"],
            is_cached=bool(row["is_cached"]),
            tags=json.loads(row["tags"]),
            memo=row["memo"],
        )
