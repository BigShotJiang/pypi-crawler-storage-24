"""Allow running as: python -m cloudsense_customer_compass"""

from .server import main

main()
