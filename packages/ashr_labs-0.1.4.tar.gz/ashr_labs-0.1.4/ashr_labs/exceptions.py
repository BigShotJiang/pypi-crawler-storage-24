"""
Custom exceptions for the Ashr Labs SDK.
"""


class AshrLabsError(Exception):
    """Base exception for all Ashr Labs errors."""

    def __init__(self, message: str, status_code: int | None = None, response: dict | None = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AuthenticationError(AshrLabsError):
    """Raised when API key authentication fails."""
    pass


class AuthorizationError(AshrLabsError):
    """Raised when the API key lacks permission for the requested operation."""
    pass


class NotFoundError(AshrLabsError):
    """Raised when a requested resource is not found."""
    pass


class ValidationError(AshrLabsError):
    """Raised when request validation fails."""
    pass


class RateLimitError(AshrLabsError):
    """Raised when rate limits are exceeded."""
    pass


class ServerError(AshrLabsError):
    """Raised when the server encounters an internal error."""
    pass
