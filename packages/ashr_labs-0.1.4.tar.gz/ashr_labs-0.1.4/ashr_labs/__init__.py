"""
Ashr Labs Python SDK

A Python client library for interacting with the Ashr Labs API.
"""

from .client import AshrLabsClient
from .exceptions import (
    AshrLabsError,
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    ValidationError,
    RateLimitError,
    ServerError,
)
from .models import (
    User,
    Tenant,
    Session,
    Dataset,
    Run,
    Request,
    APIKey,
    ToolCall,
    ExpectedResponse,
    Action,
    Scenario,
    PentestDatasetConfig,
    PENTEST_CATEGORIES,
)
from .run_builder import RunBuilder, TestBuilder
from .comparators import (
    strip_markdown,
    tokenize,
    fuzzy_str_match,
    extract_tool_args,
    compare_tool_args,
    text_similarity,
)
from .eval import EvalRunner, Agent
from .pentest import PentestRunner, PentestResult, build_pentest_request_config

__version__ = "0.1.4"
__all__ = [
    # Client
    "AshrLabsClient",
    # Exceptions
    "AshrLabsError",
    "AuthenticationError",
    "AuthorizationError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    # Models
    "User",
    "Tenant",
    "Session",
    "Dataset",
    "Run",
    "Request",
    "APIKey",
    "ToolCall",
    "ExpectedResponse",
    "Action",
    "Scenario",
    "PentestDatasetConfig",
    "PENTEST_CATEGORIES",
    # Builders
    "RunBuilder",
    "TestBuilder",
    # Comparators
    "strip_markdown",
    "tokenize",
    "fuzzy_str_match",
    "extract_tool_args",
    "compare_tool_args",
    "text_similarity",
    # Eval
    "EvalRunner",
    "Agent",
    # Pentest
    "PentestRunner",
    "PentestResult",
    "build_pentest_request_config",
]
