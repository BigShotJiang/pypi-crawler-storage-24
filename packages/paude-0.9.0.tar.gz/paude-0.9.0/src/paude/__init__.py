"""Paude - Podman wrapper for running Claude Code in isolated containers."""

__version__ = "0.9.0"
