"""Tests for paude."""
