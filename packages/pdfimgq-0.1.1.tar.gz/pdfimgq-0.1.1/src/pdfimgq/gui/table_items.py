from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QTableWidgetItem

from .utils import parse_float


class NumericItem(QTableWidgetItem):

    def __init__(self, text: str, value: float | None) -> None:
        super().__init__(text)
        self._missing = value is None
        self._value = float(value) if value is not None else 0.0
        self.setTextAlignment(int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter))


    def __lt__(self, other: QTableWidgetItem) -> bool:
        if isinstance(other, NumericItem):
            if self._missing and not other._missing:
                return False
            if not self._missing and other._missing:
                return True
            if self._missing and other._missing:
                return super().__lt__(other)
            return self._value < other._value

        other_val = parse_float(other.text())
        if other_val is None:
            return super().__lt__(other)

        if self._missing:
            return False
        return self._value < other_val