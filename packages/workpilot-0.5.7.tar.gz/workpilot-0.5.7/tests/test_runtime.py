from pathlib import Path

from workpilot.config.schema import AgentConfig, AgentsConfig, AppConfig
from workpilot.runtime import Runtime


def test_runtime_applies_agents_default_overrides(tmp_path: Path):
    cfg = AppConfig(
        agents=AgentsConfig(
            default=AgentConfig(max_iterations=25),
        )
    )

    rt = Runtime(cfg, workspace=tmp_path)

    assert rt.agent._config.max_iterations == 25


def test_runtime_entrypoint_named_agent_still_wins(tmp_path: Path):
    cfg = AppConfig(
        entrypoint="reviewer",
        agents=AgentsConfig(
            default=AgentConfig(max_iterations=25),
            agents={
                "reviewer": AgentConfig(max_iterations=7, tools=["read_file", "list_dir"]),
            },
        ),
    )

    rt = Runtime(cfg, workspace=tmp_path)

    assert rt.agent._config.max_iterations == 7
