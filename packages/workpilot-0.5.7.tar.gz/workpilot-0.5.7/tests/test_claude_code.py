"""Tests for Claude Code delegate tools (Agent SDK)."""

import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from workpilot.agent.tools.claude_code import (
    ClaudeCodeService,
    ClaudeCodeStatusTool,
    ClaudeCodeTool,
    ClaudeTask,
    TaskStatus,
)
from workpilot.config.schema import ClaudeCodeToolConfig

WORKSPACE = Path(__file__).parent.parent


def make_config(**overrides) -> ClaudeCodeToolConfig:
    defaults = {"enabled": True, "task_timeout": 30, "max_concurrent": 2}
    defaults.update(overrides)
    return ClaudeCodeToolConfig(**defaults)


def make_bus() -> MagicMock:
    bus = MagicMock()
    bus.publish_outbound = AsyncMock()
    return bus


# ── ClaudeCodeService tests ──────────────────────────────────────────────────


class TestClaudeCodeService:
    @pytest.fixture
    def service(self):
        return ClaudeCodeService(WORKSPACE, make_bus(), make_config())

    def test_task_type_prompts(self, service):
        """All documented task types have prompts."""
        for tt in ("code", "review", "test", "refactor", "research"):
            assert tt in service._TASK_TYPE_PROMPTS

    def test_resolve_model_override(self, service):
        """Explicit model override takes priority."""
        assert service._resolve_model("code", "opus") == "opus"

    def test_resolve_model_policy(self, service):
        """Falls back to model_policy when no override."""
        assert service._resolve_model("test", None) == "sonnet"
        assert service._resolve_model("code", None) == "sonnet"

    def test_resolve_model_default(self, service):
        """Unknown task_type falls back to default_model."""
        assert service._resolve_model("unknown_type", None) == "sonnet"

    def test_build_prompt_basic(self, service):
        ct = ClaudeTask(task_id="t1", task="Fix the bug", task_type="code")
        user_prompt, system_prompt = service._build_prompt(ct, [])
        assert "Fix the bug" in user_prompt
        assert "Implement" in system_prompt

    def test_build_prompt_with_files(self, service):
        ct = ClaudeTask(task_id="t2", task="Review auth", task_type="review")
        user_prompt, system_prompt = service._build_prompt(ct, ["src/auth.py", "src/login.py"])
        assert "src/auth.py" in user_prompt
        assert "src/login.py" in user_prompt
        assert "Focus on these files" in user_prompt

    @pytest.mark.asyncio
    async def test_validate_sdk(self, service):
        """SDK validation succeeds when claude_agent_sdk is importable."""
        pytest.importorskip("claude_agent_sdk")
        await service._validate_sdk()
        assert service._sdk_validated is True

    @pytest.mark.asyncio
    async def test_submit_wait_mode(self, service):
        """Wait mode returns result directly."""
        with (
            patch.object(service, "_validate_sdk", new_callable=AsyncMock),
            patch.object(service, "_execute_sdk", new_callable=AsyncMock) as mock_exec,
        ):
            # Simulate _execute_sdk setting the task result
            async def set_done(ct, *args, **kwargs):
                ct.result = "Done!"
                ct.status = TaskStatus.DONE

            mock_exec.side_effect = set_done

            result = await service.submit(
                task_desc="Fix the bug",
                task_type="code",
                files=[],
                model_override=None,
                mode="wait",
                notify_channel="cli",
                notify_channel_id="cli",
                notify_thread_id=None,
            )
        assert result == "Done!"

    @pytest.mark.asyncio
    async def test_submit_background_mode(self, service):
        """Background mode returns task submission message."""
        with (
            patch.object(service, "_validate_sdk", new_callable=AsyncMock),
            patch.object(service, "_execute_sdk", new_callable=AsyncMock) as mock_exec,
        ):

            async def set_done(ct, *args, **kwargs):
                ct.result = "Review complete"
                ct.status = TaskStatus.DONE

            mock_exec.side_effect = set_done

            result = await service.submit(
                task_desc="Review the auth module",
                task_type="review",
                files=["src/auth.py"],
                model_override=None,
                mode="background",
                notify_channel="teams",
                notify_channel_id="ch1",
                notify_thread_id=None,
            )
        assert "Task submitted" in result
        assert "review" in result
        assert "teams" in result

        # Wait for background task to complete deterministically
        task_ids = list(service._tasks.keys())
        assert len(task_ids) == 1
        bg = service._tasks[task_ids[0]]
        if bg.asyncio_task:
            await bg.asyncio_task

    @pytest.mark.asyncio
    async def test_submit_sdk_error(self, service):
        """SDK error results in failed task."""
        with (
            patch.object(service, "_validate_sdk", new_callable=AsyncMock),
            patch.object(service, "_execute_sdk", new_callable=AsyncMock) as mock_exec,
        ):
            mock_exec.side_effect = RuntimeError("Authentication required")

            result = await service.submit(
                task_desc="Do something",
                task_type="code",
                files=[],
                model_override=None,
                mode="wait",
                notify_channel="cli",
                notify_channel_id="cli",
                notify_thread_id=None,
            )
        assert "failed" in result.lower()

    @pytest.mark.asyncio
    async def test_stop_cancels_tasks(self, service):
        """Stop cancels in-flight tasks."""
        ct = ClaudeTask(task_id="x1", task="test", task_type="code")
        ct.status = TaskStatus.RUNNING

        # Create a real asyncio Task that's still running (not done)
        async def hang_forever():
            await asyncio.sleep(3600)

        real_task = asyncio.create_task(hang_forever())
        ct.asyncio_task = real_task
        service._tasks["x1"] = ct

        await service.stop()
        assert ct.status == TaskStatus.FAILED
        assert "shutting down" in ct.error
        assert real_task.cancelled()

    def test_list_tasks(self, service):
        service._tasks["a"] = ClaudeTask(task_id="a", task="t1", task_type="code")
        service._tasks["b"] = ClaudeTask(task_id="b", task="t2", task_type="review")
        assert len(service.list_tasks()) == 2

    def test_get_task(self, service):
        ct = ClaudeTask(task_id="abc", task="test", task_type="code")
        service._tasks["abc"] = ct
        assert service.get_task("abc") is ct
        assert service.get_task("nonexistent") is None


# ── ClaudeCodeTool tests ─────────────────────────────────────────────────────


class TestClaudeCodeTool:
    @pytest.fixture
    def tool(self):
        service = MagicMock()
        service.submit = AsyncMock(return_value="Task submitted (id=abc123)")
        return ClaudeCodeTool(service)

    def test_name(self, tool):
        assert tool.name == "claude_code"

    def test_metadata(self, tool):
        assert tool.metadata.risk_level == "medium"
        assert tool.metadata.approval == "auto"

    def test_parameters_schema(self, tool):
        params = tool.parameters
        assert params["type"] == "object"
        assert "task" in params["properties"]
        assert "task" in params["required"]
        assert "task_type" in params["properties"]
        assert "research" in params["properties"]["task_type"]["enum"]

    @pytest.mark.asyncio
    async def test_execute_valid(self, tool):
        result = await tool.execute(task="Fix the bug", task_type="code", mode="background")
        assert "submitted" in result.lower()

    @pytest.mark.asyncio
    async def test_execute_empty_task(self, tool):
        result = await tool.execute(task="", task_type="code")
        assert "error" in result.lower()

    @pytest.mark.asyncio
    async def test_execute_invalid_task_type(self, tool):
        result = await tool.execute(task="do stuff", task_type="invalid")
        assert "error" in result.lower()

    @pytest.mark.asyncio
    async def test_execute_invalid_mode(self, tool):
        result = await tool.execute(task="do stuff", task_type="code", mode="invalid")
        assert "error" in result.lower()


# ── ClaudeCodeStatusTool tests ───────────────────────────────────────────────


class TestClaudeCodeStatusTool:
    @pytest.fixture
    def service(self):
        svc = MagicMock()
        svc.list_tasks.return_value = [
            ClaudeTask(
                task_id="abc",
                task="review auth",
                task_type="review",
                model="sonnet",
                status=TaskStatus.DONE,
                result="Looks good!",
            ),
            ClaudeTask(
                task_id="def",
                task="write tests",
                task_type="test",
                model="haiku",
                status=TaskStatus.RUNNING,
            ),
        ]
        svc.get_task.return_value = svc.list_tasks.return_value[0]
        return svc

    @pytest.fixture
    def tool(self, service):
        return ClaudeCodeStatusTool(service)

    def test_name(self, tool):
        assert tool.name == "claude_code_status"

    def test_metadata(self, tool):
        assert tool.metadata.approval == "never"

    @pytest.mark.asyncio
    async def test_list_all(self, tool):
        result = await tool.execute()
        assert "abc" in result
        assert "def" in result
        assert "review" in result
        assert "sonnet" in result

    @pytest.mark.asyncio
    async def test_get_single(self, tool):
        result = await tool.execute(task_id="abc")
        assert "abc" in result
        assert "Looks good" in result

    @pytest.mark.asyncio
    async def test_no_tasks(self, tool):
        tool._service.list_tasks.return_value = []
        result = await tool.execute()
        assert "No Claude Code tasks found" in result

    @pytest.mark.asyncio
    async def test_task_not_found(self, tool):
        tool._service.get_task.return_value = None
        result = await tool.execute(task_id="nonexistent")
        assert "error" in result.lower()


# ── Config tests ─────────────────────────────────────────────────────────────


class TestClaudeCodeConfig:
    def test_defaults(self):
        config = ClaudeCodeToolConfig()
        assert config.enabled is True
        assert config.default_model == "sonnet"
        assert config.max_concurrent == 3
        assert config.task_timeout == 1800
        assert config.dangerously_skip_permissions is False
        assert config.setting_sources == ["user", "project", "local"]
        assert config.use_plugins is True

    def test_model_policy_defaults(self):
        config = ClaudeCodeToolConfig()
        assert config.model_policy.code == "sonnet"
        assert config.model_policy.test == "sonnet"
        assert config.model_policy.research == "sonnet"

    def test_custom_config(self):
        config = ClaudeCodeToolConfig(
            default_model="opus",
            max_concurrent=5,
            task_timeout=300,
        )
        assert config.default_model == "opus"
        assert config.max_concurrent == 5
        assert config.task_timeout == 300
