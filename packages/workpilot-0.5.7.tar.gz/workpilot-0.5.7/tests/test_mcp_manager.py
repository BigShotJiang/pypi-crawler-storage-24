"""Tests for MCPManager — lifecycle, progressive loading, namespace, Agency."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, PropertyMock, patch

import pytest

from workpilot.agent.tools.registry import ToolRegistry
from workpilot.config.schema import MCPServerConfig
from workpilot.mcp.manager import MCPManager
from workpilot.mcp.types import ConnectionState


def _cfg(command: str = "agency", args: list[str] | None = None, **kwargs: Any) -> MCPServerConfig:
    return MCPServerConfig(command=command, args=args or ["mcp", "icm"], **kwargs)


def _descriptors(*names: str) -> list[dict[str, Any]]:
    return [
        {
            "name": n,
            "description": f"Tool {n}",
            "inputSchema": {
                "type": "object",
                "properties": {"id": {"type": "string"}},
                "required": ["id"],
            },
        }
        for n in names
    ]


def _patch_client(descriptors: list[dict[str, Any]] | None = None):
    """Patch MCPClient so connect() succeeds and list_tools() returns descriptors."""
    mock_cls = patch("workpilot.mcp.manager.MCPClient")

    def _setup(mock_class):
        instance = AsyncMock()
        type(instance).is_connected = PropertyMock(return_value=True)
        type(instance).name = PropertyMock(return_value="test")
        instance.list_tools = AsyncMock(return_value=descriptors or [])
        instance.call_tool = AsyncMock(return_value="result")
        mock_class.return_value = instance
        return instance

    return mock_cls, _setup


async def _agency_ok() -> tuple[bool, str]:
    return True, "authenticated"


# Also patch Agency auth check to always pass
_PATCH_AGENCY = patch(
    "workpilot.mcp.manager.pre_connect_agency_check",
    side_effect=_agency_ok,
)


# ── Connection Lifecycle ─────────────────────────────────────────────────────


class TestConnectServer:
    @pytest.mark.asyncio
    async def test_connect_success(self) -> None:
        configs = {"icm": _cfg()}
        registry = ToolRegistry()
        mgr = MCPManager(configs, registry)

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await mgr.connect_server("icm")

        assert mgr._states["icm"] == ConnectionState.CONNECTED
        # ≤5 tools → auto-describe returns tool signatures
        assert "MCP_icm_get_incident" in result

    @pytest.mark.asyncio
    async def test_connect_unknown_server(self) -> None:
        mgr = MCPManager({}, ToolRegistry())
        result = await mgr.connect_server("nonexistent")
        assert "Unknown" in result

    @pytest.mark.asyncio
    async def test_connect_already_connected_skips(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")
            result = await mgr.connect_server("icm")

        assert "already connected" in result

    @pytest.mark.asyncio
    async def test_connect_force_reconnect(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")
            await mgr.connect_server("icm", force=True)

        assert mgr._states["icm"] == ConnectionState.CONNECTED

    @pytest.mark.asyncio
    async def test_connect_failure(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls = patch("workpilot.mcp.manager.MCPClient")
        with mock_cls as mc, _PATCH_AGENCY:
            instance = AsyncMock()
            instance.connect = AsyncMock(side_effect=ConnectionError("refused"))
            mc.return_value = instance
            result = await mgr.connect_server("icm")

        assert "Failed" in result
        assert mgr._states["icm"] == ConnectionState.DISCONNECTED


# ── Progressive Loading ──────────────────────────────────────────────────────


class TestProgressiveLoading:
    @pytest.mark.asyncio
    async def test_large_server_connect_caches_but_no_register(self) -> None:
        """Servers with >5 tools: connect caches but does NOT register."""
        configs = {"icm": _cfg()}
        registry = ToolRegistry()
        mgr = MCPManager(configs, registry)

        many_tools = _descriptors(*[f"tool_{i}" for i in range(10)])
        mock_cls, setup = _patch_client(many_tools)
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await mgr.connect_server("icm")

        # Tools are cached
        assert len(mgr._tool_cache["icm"]) == 10
        # But NOT registered (>5 tools → no auto-describe)
        assert registry.get("MCP_icm_tool_0") is None
        # Summary returned
        assert "Tools: 10" in result

    @pytest.mark.asyncio
    async def test_small_server_connect_auto_describes(self) -> None:
        """Servers with ≤5 tools: connect auto-describes and registers."""
        configs = {"icm": _cfg()}
        registry = ToolRegistry()
        mgr = MCPManager(configs, registry)

        mock_cls, setup = _patch_client(_descriptors("get_incident", "list_incidents"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await mgr.connect_server("icm")

        # Auto-described → tools registered
        assert registry.get("MCP_icm_get_incident") is not None
        assert "MCP_icm_get_incident" in result

    @pytest.mark.asyncio
    async def test_describe_registers_large_server(self) -> None:
        """Describe on large server registers tools."""
        configs = {"icm": _cfg()}
        registry = ToolRegistry()
        mgr = MCPManager(configs, registry)

        many_tools = _descriptors(*[f"tool_{i}" for i in range(10)])
        mock_cls, setup = _patch_client(many_tools)
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")
            result = await mgr.describe_server("icm")

        assert registry.get("MCP_icm_tool_0") is not None
        assert "MCP_icm_tool_0" in result

    @pytest.mark.asyncio
    async def test_describe_auto_connects(self) -> None:
        """describe on unconnected server auto-connects first."""
        configs = {"icm": _cfg()}
        registry = ToolRegistry()
        mgr = MCPManager(configs, registry)

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await mgr.describe_server("icm")

        assert "MCP_icm_get_incident" in result
        assert mgr._states["icm"] == ConnectionState.CONNECTED

    @pytest.mark.asyncio
    async def test_describe_idempotent(self) -> None:
        """Calling describe twice doesn't double-register."""
        configs = {"icm": _cfg()}
        registry = ToolRegistry()
        mgr = MCPManager(configs, registry)

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.describe_server("icm")
            await mgr.describe_server("icm")  # second call

        assert len(mgr._registered_tools["icm"]) == 1


# ── Disconnect ───────────────────────────────────────────────────────────────


class TestDisconnect:
    @pytest.mark.asyncio
    async def test_disconnect_unregisters_tools(self) -> None:
        configs = {"icm": _cfg()}
        registry = ToolRegistry()
        mgr = MCPManager(configs, registry)

        mock_cls, setup = _patch_client(_descriptors("get_incident", "list_incidents"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            # ≤5 tools → auto-describe registers them
            await mgr.connect_server("icm")

        assert registry.get("MCP_icm_get_incident") is not None

        await mgr.disconnect_server("icm")

        assert registry.get("MCP_icm_get_incident") is None
        assert registry.get("MCP_icm_list_incidents") is None
        assert mgr._states["icm"] == ConnectionState.DISCONNECTED

    @pytest.mark.asyncio
    async def test_disconnect_all(self) -> None:
        configs = {"icm": _cfg(), "kusto": _cfg(args=["mcp", "kusto"])}
        registry = ToolRegistry()
        mgr = MCPManager(configs, registry)

        mock_cls, setup = _patch_client(_descriptors("tool_a"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")
            await mgr.connect_server("kusto")

        await mgr.disconnect_all()

        assert mgr._states["icm"] == ConnectionState.DISCONNECTED
        assert mgr._states["kusto"] == ConnectionState.DISCONNECTED
        assert len(mgr._clients) == 0


# ── Discovery ────────────────────────────────────────────────────────────────


class TestDiscovery:
    @pytest.mark.asyncio
    async def test_list_servers(self) -> None:
        configs = {
            "icm": _cfg(),
            "github": _cfg(command="npx", args=["-y", "server"]),
        }
        mgr = MCPManager(configs, ToolRegistry())

        servers = mgr.list_servers()

        assert len(servers) == 2
        icm = next(s for s in servers if s.name == "icm")
        github = next(s for s in servers if s.name == "github")
        assert icm.is_agency is True
        assert github.is_agency is False
        assert icm.state == ConnectionState.IDLE

    @pytest.mark.asyncio
    async def test_get_connected_servers(self) -> None:
        configs = {"icm": _cfg(), "kusto": _cfg(args=["mcp", "kusto"])}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("tool_a"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")

        assert mgr.get_connected_servers() == ["icm"]

    def test_agency_servers(self) -> None:
        configs = {
            "icm": _cfg(),
            "github": _cfg(command="npx", args=[]),
        }
        mgr = MCPManager(configs, ToolRegistry())
        assert mgr.agency_servers() == ["icm"]


# ── System Prompt Summary ────────────────────────────────────────────────────


class TestSystemPromptSummary:
    def test_empty_when_no_connections(self) -> None:
        mgr = MCPManager({"icm": _cfg()}, ToolRegistry())
        assert mgr.build_system_prompt_summary() == ""

    @pytest.mark.asyncio
    async def test_includes_connected_servers(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("get_incident", "list_incidents"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")

        summary = mgr.build_system_prompt_summary()

        assert "MCP servers connected:" in summary
        assert "icm" in summary

    @pytest.mark.asyncio
    async def test_summary_line_length(self) -> None:
        """Each server line in system prompt should be reasonable length."""
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")

        summary = mgr.build_system_prompt_summary()
        for line in summary.splitlines():
            assert len(line) <= 120  # reasonable per-line limit


# ── Namespace ────────────────────────────────────────────────────────────────


class TestManagerNamespace:
    @pytest.mark.asyncio
    async def test_custom_namespace_override(self) -> None:
        configs = {"my-long-server": _cfg(namespace="short")}
        registry = ToolRegistry()
        mgr = MCPManager(configs, registry)

        mock_cls, setup = _patch_client(_descriptors("get_data"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            # ≤5 tools → connect auto-describes and registers
            await mgr.connect_server("my-long-server")

        assert registry.get("MCP_short_get_data") is not None
        assert registry.get("my-long-server.get_data") is None


# ── Describe Filter ──────────────────────────────────────────────────────────


class TestDescribeFilter:
    @pytest.mark.asyncio
    async def test_filter_by_name(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(
            _descriptors("get_incident", "list_incidents", "create_ticket", "search_logs")
        )
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")
            result = await mgr.describe_server("icm", keyword="incident")

        assert "MCP_icm_get_incident" in result
        assert "MCP_icm_list_incidents" in result
        assert "MCP_icm_create_ticket" not in result
        assert "MCP_icm_search_logs" not in result
        assert "2/4" in result

    @pytest.mark.asyncio
    async def test_filter_by_description(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        descs = [
            {
                "name": "tool_a",
                "description": "Query incidents",
                "inputSchema": {"type": "object", "properties": {}},
            },
            {
                "name": "tool_b",
                "description": "Send email",
                "inputSchema": {"type": "object", "properties": {}},
            },
        ]
        mock_cls, setup = _patch_client(descs)
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")
            result = await mgr.describe_server("icm", keyword="incident")

        assert "MCP_icm_tool_a" in result
        assert "MCP_icm_tool_b" not in result

    @pytest.mark.asyncio
    async def test_filter_case_insensitive(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("GetIncident", "ListLogs"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")
            result = await mgr.describe_server("icm", keyword="INCIDENT")

        assert "MCP_icm_GetIncident" in result
        assert "MCP_icm_ListLogs" not in result

    @pytest.mark.asyncio
    async def test_filter_no_match(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")
            result = await mgr.describe_server("icm", keyword="nonexistent")

        assert "no matches" in result.lower()

    @pytest.mark.asyncio
    async def test_no_filter_returns_all(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("get_incident", "list_incidents"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")
            result = await mgr.describe_server("icm")

        assert "MCP_icm_get_incident" in result
        assert "MCP_icm_list_incidents" in result
        assert "2/2" in result


# ── Disabled Servers ─────────────────────────────────────────────────────────


class TestDisabledServers:
    @pytest.mark.asyncio
    async def test_connect_disabled_server_rejected(self) -> None:
        configs = {"icm": _cfg(enabled=False)}
        mgr = MCPManager(configs, ToolRegistry())

        result = await mgr.connect_server("icm")

        assert "disabled" in result
        assert mgr._states["icm"] == ConnectionState.IDLE

    def test_list_servers_shows_disabled(self) -> None:
        configs = {"icm": _cfg(), "old": _cfg(enabled=False)}
        mgr = MCPManager(configs, ToolRegistry())

        servers = mgr.list_servers()

        enabled = [s for s in servers if s.enabled]
        disabled = [s for s in servers if not s.enabled]
        assert len(enabled) == 1
        assert len(disabled) == 1
        assert disabled[0].name == "old"


# ── System Prompt with Description ───────────────────────────────────────────


class TestSystemPromptDescription:
    @pytest.mark.asyncio
    async def test_uses_config_description(self) -> None:
        configs = {"icm": _cfg(description="incident management")}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")

        summary = mgr.build_system_prompt_summary()

        assert "incident management" in summary

    @pytest.mark.asyncio
    async def test_fallback_to_tool_names_without_description(self) -> None:
        configs = {"icm": _cfg()}  # no description
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")

        summary = mgr.build_system_prompt_summary()

        assert "icm" in summary
        assert "get_incident" in summary


# ── Agency Servers Helper ────────────────────────────────────────────────────


class TestAgencyServers:
    def test_agency_servers(self) -> None:
        configs = {
            "icm": _cfg(),
            "github": _cfg(command="npx", args=[]),
            "kusto": _cfg(),
        }
        mgr = MCPManager(configs, ToolRegistry())

        result = mgr.agency_servers()

        assert "icm" in result
        assert "kusto" in result
        assert "github" not in result
