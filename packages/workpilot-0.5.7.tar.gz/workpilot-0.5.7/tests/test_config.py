"""Tests for configuration system."""

from pathlib import Path
from unittest.mock import patch

from workpilot.config.loader import (
    _deep_merge,
    _load_builtin_workpilot_config,
    _resolve_local_override,
    _substitute_env,
    load_config,
)
from workpilot.config.schema import AgentConfig, AppConfig, ShellConfig


class TestSubstituteEnv:
    def test_replaces_variables(self):
        assert _substitute_env("Hello ${NAME}!", {"NAME": "World"}) == "Hello World!"

    def test_missing_variable_becomes_empty(self):
        assert _substitute_env("Key: ${MISSING}", {}) == "Key: "

    def test_multiple_substitutions(self):
        assert _substitute_env("${A}/${B}", {"A": "foo", "B": "bar"}) == "foo/bar"

    def test_no_variables(self):
        assert _substitute_env("plain text", {"FOO": "bar"}) == "plain text"


class TestDeepMerge:
    def test_flat_merge(self):
        assert _deep_merge({"a": 1, "b": 2}, {"b": 3, "c": 4}) == {"a": 1, "b": 3, "c": 4}

    def test_nested_merge(self):
        result = _deep_merge({"a": {"x": 1, "y": 2}}, {"a": {"y": 3, "z": 4}})
        assert result == {"a": {"x": 1, "y": 3, "z": 4}}

    def test_override_arrays(self):
        assert _deep_merge({"a": [1, 2]}, {"a": [3, 4]}) == {"a": [3, 4]}


class TestAppConfig:
    def test_default_config(self):
        config = AppConfig()
        assert config.name == "workpilot"
        assert config.agents.default.model == "auto"
        assert config.security.audit.enabled is True
        assert config.tools.filesystem.restrict_to_workspace is True

    def test_custom_agent(self):
        config = AppConfig(agents={"default": AgentConfig(model="openai/gpt-4o")})
        assert config.agents.default.model == "openai/gpt-4o"

    def test_shell_deny_patterns(self):
        shell = ShellConfig()
        assert len(shell.deny_patterns) > 0
        assert any("rm" in p for p in shell.deny_patterns)


class TestLoadConfig:
    def test_loads_defaults_when_no_file(self, tmp_path: Path):
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            config = load_config()
        assert isinstance(config, AppConfig)
        assert config.name == "workpilot"

    def test_loads_builtin_root_workpilot_yaml(self, tmp_path: Path):
        with patch("pathlib.Path.home", return_value=tmp_path):
            raw = _load_builtin_workpilot_config()
        assert raw["name"] == "workpilot"

    def test_bundled_config_exists_in_defaults(self):
        """Ensure workpilot/defaults/workpilot.yaml is the single source of truth."""
        from importlib.resources import files

        resource = files("workpilot.defaults").joinpath("workpilot.yaml")
        text = resource.read_text(encoding="utf-8")
        assert "entrypoint" in text

    def test_merges_builtin_home_and_home_local_configs(self, tmp_path: Path):
        home = tmp_path / "home"
        home_wp = home / ".workpilot"
        home_wp.mkdir(parents=True, exist_ok=True)
        (home_wp / "workpilot.yaml").write_text(
            "name: home-project\nlogging:\n  level: INFO\nagents:\n  default:\n    model: openai/gpt-4o\n",
            encoding="utf-8",
        )
        local_dir = home / ".workpilot"
        local_dir.mkdir(parents=True, exist_ok=True)
        (local_dir / "workpilot.local.yaml").write_text(
            "logging:\n  level: DEBUG\nagents:\n  default:\n    max_iterations: 30\n",
            encoding="utf-8",
        )

        with patch("pathlib.Path.home", return_value=home):
            config = load_config()

        assert config.name == "home-project"
        assert config.logging.level.value == "DEBUG"
        assert config.agents.default.model == "openai/gpt-4o"
        assert config.agents.default.max_iterations == 30

    def test_loads_yaml(self, tmp_path: Path):
        yaml_content = """
name: test-project
agents:
  default:
    model: openai/gpt-4o
"""
        (tmp_path / "workpilot.yaml").write_text(yaml_content)
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            config = load_config(tmp_path)
        assert config.name == "test-project"
        assert config.agents.default.model == "openai/gpt-4o"

    def test_local_override_merges(self, tmp_path: Path):
        """workpilot.local.yaml values override base config."""
        (tmp_path / "workpilot.yaml").write_text("name: base-project\nlogging:\n  level: INFO\n")
        (tmp_path / "workpilot.local.yaml").write_text("logging:\n  level: DEBUG\n")
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            config = load_config(tmp_path)
        assert config.name == "base-project"
        assert config.logging.level.value == "DEBUG"

    def test_local_override_deep_merges(self, tmp_path: Path):
        """Nested keys from local file merge without clobbering siblings."""
        (tmp_path / "workpilot.yaml").write_text(
            "agents:\n  default:\n    model: openai/gpt-4o\n    max_iterations: 20\n"
        )
        (tmp_path / "workpilot.local.yaml").write_text(
            "agents:\n  default:\n    max_iterations: 30\n"
        )
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            config = load_config(tmp_path)
        assert config.agents.default.model == "openai/gpt-4o"
        assert config.agents.default.max_iterations == 30

    def test_no_local_file_works(self, tmp_path: Path):
        """Absence of local override file should not cause errors."""
        (tmp_path / "workpilot.yaml").write_text("name: solo\n")
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            config = load_config(tmp_path)
        assert config.name == "solo"

    def test_local_file_naming_for_config_yaml(self, tmp_path: Path):
        """config.yaml resolves to config.local.yaml, not workpilot.local.yaml."""
        (tmp_path / "config.yaml").write_text("name: base\n")
        (tmp_path / "config.local.yaml").write_text("name: overridden\n")
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            config = load_config(tmp_path)
        assert config.name == "overridden"

    def test_explicit_config_does_not_merge_home_local_override(self, tmp_path: Path):
        home = tmp_path / "home"
        home_wp = home / ".workpilot"
        home_wp.mkdir(parents=True, exist_ok=True)
        (home_wp / "workpilot.local.yaml").write_text(
            "logging:\n  level: DEBUG\n", encoding="utf-8"
        )

        project = tmp_path / "project"
        project.mkdir()
        (project / "workpilot.yaml").write_text(
            "name: project\nlogging:\n  level: INFO\n", encoding="utf-8"
        )

        with patch("pathlib.Path.home", return_value=home):
            config = load_config(project)

        assert config.name == "project"
        assert config.logging.level.value == "INFO"


class TestResolveLocalOverride:
    def test_derives_local_path(self, tmp_path: Path):
        base = tmp_path / "workpilot.yaml"
        base.write_text("")
        local = tmp_path / "workpilot.local.yaml"
        local.write_text("")
        assert _resolve_local_override(base) == local

    def test_returns_none_when_missing(self, tmp_path: Path):
        base = tmp_path / "workpilot.yaml"
        base.write_text("")
        assert _resolve_local_override(base) is None

    def test_yml_extension(self, tmp_path: Path):
        base = tmp_path / "config.yml"
        base.write_text("")
        local = tmp_path / "config.local.yml"
        local.write_text("")
        assert _resolve_local_override(base) == local
