"""Tests for the unified ToolsTool — MCP server management path."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, PropertyMock, patch

import pytest

from workpilot.agent.tools.registry import ToolRegistry
from workpilot.agent.tools.tools import ToolsTool
from workpilot.config.schema import MCPServerConfig
from workpilot.mcp.manager import MCPManager


def _cfg(**kwargs: Any) -> MCPServerConfig:
    return MCPServerConfig(command="agency", args=["mcp", "icm"], **kwargs)


def _descriptors(*names: str) -> list[dict[str, Any]]:
    return [
        {
            "name": n,
            "description": f"Tool {n}",
            "inputSchema": {
                "type": "object",
                "properties": {"id": {"type": "string"}},
                "required": ["id"],
            },
        }
        for n in names
    ]


async def _agency_ok() -> tuple[bool, str]:
    return True, "ok"


_PATCH_AGENCY = patch("workpilot.mcp.manager.pre_connect_agency_check", side_effect=_agency_ok)


def _patch_client(descriptors: list[dict[str, Any]] | None = None):
    mock_cls = patch("workpilot.mcp.manager.MCPClient")

    def _setup(mc):
        inst = AsyncMock()
        type(inst).is_connected = PropertyMock(return_value=True)
        type(inst).name = PropertyMock(return_value="test")
        inst.list_tools = AsyncMock(return_value=descriptors or [])
        inst.call_tool = AsyncMock(return_value="result")
        inst.list_resources = AsyncMock(return_value=[])
        inst.list_prompts = AsyncMock(return_value=[])
        inst.read_resource = AsyncMock(return_value="resource content")
        inst.get_prompt = AsyncMock(return_value="rendered prompt")
        type(inst).capabilities = PropertyMock(
            return_value=type(
                "C",
                (),
                {
                    "tools": True,
                    "resources": False,
                    "prompts": False,
                    "streaming": False,
                    "logging": False,
                    "list_changed": False,
                },
            )()
        )
        mc.return_value = inst
        return inst

    return mock_cls, _setup


def _make_tool(configs: dict[str, MCPServerConfig] | None = None) -> tuple[ToolsTool, ToolRegistry]:
    registry = ToolRegistry()
    mgr = MCPManager(configs or {}, registry)
    tool = ToolsTool(registry=registry, mcp_manager=mgr)
    registry.register(tool)
    return tool, registry


class TestMetadata:
    def test_name(self) -> None:
        tool, _ = _make_tool()
        assert tool.name == "tools"

    def test_approval_never(self) -> None:
        tool, _ = _make_tool()
        assert tool.metadata.approval == "never"

    def test_parameters_include_all_fields(self) -> None:
        tool, _ = _make_tool()
        props = tool.parameters["properties"]
        assert set(props.keys()) == {"name", "action", "query", "arguments"}
        assert set(props["action"]["enum"]) == {
            "enable",
            "disable",
            "describe",
            "status",
            "resources",
            "prompts",
        }


class TestListAll:
    @pytest.mark.asyncio
    async def test_no_args_lists_mcp_servers(self) -> None:
        configs = {"icm": _cfg(), "kusto": MCPServerConfig(command="agency", args=["mcp", "kusto"])}
        tool, _ = _make_tool(configs)
        result = await tool.execute()
        assert "MCP_icm" in result
        assert "MCP_kusto" in result

    @pytest.mark.asyncio
    async def test_no_servers_shows_no_mcp_section(self) -> None:
        tool, _ = _make_tool()
        result = await tool.execute()
        assert "MCP servers:" not in result


class TestMCPConnect:
    @pytest.mark.asyncio
    async def test_connect_small_server_auto_describes(self) -> None:
        """≤5 tools → connect returns full tool signatures (auto-describe)."""
        tool, registry = _make_tool({"icm": _cfg()})

        mock_cls, setup = _patch_client(_descriptors("get_incident", "list_incidents"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(name="MCP_icm")

        assert "MCP_icm_get_incident" in result
        assert "MCP_icm_list_incidents" in result
        assert registry.get("MCP_icm_get_incident") is not None

    @pytest.mark.asyncio
    async def test_connect_large_server_returns_summary(self) -> None:
        """>5 tools → connect returns summary, not full signatures."""
        tool, _ = _make_tool({"icm": _cfg()})

        many_tools = _descriptors(*[f"tool_{i}" for i in range(10)])
        mock_cls, setup = _patch_client(many_tools)
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(name="MCP_icm")

        assert "Tools: 10" in result
        assert "describe" in result.lower()

    @pytest.mark.asyncio
    async def test_enable_is_default_action(self) -> None:
        tool, _ = _make_tool({"icm": _cfg()})

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(name="MCP_icm")

        assert "icm" in result


class TestMCPDescribe:
    @pytest.mark.asyncio
    async def test_describe_auto_connects(self) -> None:
        """describe on unconnected server auto-connects first."""
        tool, registry = _make_tool({"icm": _cfg()})

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(name="MCP_icm", action="describe")

        assert "MCP_icm_get_incident" in result
        assert registry.get("MCP_icm_get_incident") is not None

    @pytest.mark.asyncio
    async def test_describe_with_filter(self) -> None:
        tool, _ = _make_tool({"icm": _cfg()})

        mock_cls, setup = _patch_client(
            _descriptors("get_incident", "list_incidents", "create_user")
        )
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(name="MCP_icm", action="describe", query="incident")

        assert "MCP_icm_get_incident" in result
        assert "MCP_icm_list_incidents" in result
        assert "MCP_icm_create_user" not in result

    @pytest.mark.asyncio
    async def test_describe_unknown_server(self) -> None:
        tool, _ = _make_tool()
        result = await tool.execute(name="MCP_nonexistent", action="describe")
        assert "Unknown" in result


class TestMCPResources:
    @pytest.mark.asyncio
    async def test_read_resource(self) -> None:
        tool, _ = _make_tool({"icm": _cfg()})

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await tool.execute(name="MCP_icm")  # connect
            result = await tool.execute(name="MCP_icm", action="resources", query="icm://schema")

        assert "resource content" in result

    @pytest.mark.asyncio
    async def test_resources_no_query_shows_describe(self) -> None:
        """resources without query → falls back to describe."""
        tool, _ = _make_tool({"icm": _cfg()})

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(name="MCP_icm", action="resources")

        assert "MCP server 'icm'" in result


class TestMCPPrompts:
    @pytest.mark.asyncio
    async def test_get_prompt(self) -> None:
        tool, _ = _make_tool({"icm": _cfg()})

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await tool.execute(name="MCP_icm")  # connect
            result = await tool.execute(
                name="MCP_icm",
                action="prompts",
                query="triage",
                arguments={"severity": "2"},
            )

        assert "rendered prompt" in result

    @pytest.mark.asyncio
    async def test_prompts_no_query_shows_describe(self) -> None:
        tool, _ = _make_tool({"icm": _cfg()})

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(name="MCP_icm", action="prompts")

        assert "MCP server 'icm'" in result


class TestMCPOther:
    @pytest.mark.asyncio
    async def test_disable_disconnects(self) -> None:
        tool, registry = _make_tool({"icm": _cfg()})

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await tool.execute(name="MCP_icm", action="describe")  # connect + register

        assert registry.get("MCP_icm_get_incident") is not None
        result = await tool.execute(name="MCP_icm", action="disable")

        assert "Disconnected" in result
        assert registry.get("MCP_icm_get_incident") is None

    @pytest.mark.asyncio
    async def test_status_action(self) -> None:
        tool, _ = _make_tool({"icm": _cfg()})
        result = await tool.execute(name="MCP_icm", action="status")
        assert "icm" in result
        assert "idle" in result

    @pytest.mark.asyncio
    async def test_unknown_action(self) -> None:
        tool, _ = _make_tool({"icm": _cfg()})
        result = await tool.execute(name="MCP_icm", action="invalid")
        assert "Unknown action" in result


class TestBuiltinTools:
    @pytest.mark.asyncio
    async def test_enable_builtin_tool(self) -> None:
        """Enable a standard-tier built-in tool."""
        from workpilot.agent.tools.git import GitTool
        from workpilot.security.sandbox import Sandbox

        registry = ToolRegistry()
        sandbox = Sandbox.__new__(Sandbox)
        registry.register(GitTool(sandbox))
        tool = ToolsTool(registry=registry)
        registry.register(tool)

        # git is standard tier — should not be in schemas initially
        schemas = registry.get_schemas()
        schema_names = {s["function"]["name"] for s in schemas}
        assert "git" not in schema_names

        # Enable via tools()
        result = await tool.execute(name="git")
        assert "Enabled" in result
        assert "args" in result  # shows parameters

        # Now should be in schemas
        schemas = registry.get_schemas()
        schema_names = {s["function"]["name"] for s in schemas}
        assert "git" in schema_names

    @pytest.mark.asyncio
    async def test_disable_core_tool_blocked(self) -> None:
        tool, _ = _make_tool()
        result = await tool.execute(name="tools", action="disable")
        assert "Cannot disable" in result

    @pytest.mark.asyncio
    async def test_unknown_tool(self) -> None:
        tool, _ = _make_tool()
        result = await tool.execute(name="nonexistent")
        assert "Unknown tool" in result
