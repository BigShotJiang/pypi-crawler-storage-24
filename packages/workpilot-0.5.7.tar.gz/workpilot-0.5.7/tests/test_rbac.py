"""Tests for the RBAC / PolicyEngine module."""

from workpilot.config.schema import (
    AutonomyLevel,
    RiskLevel,
    SecurityConfig,
    SecurityOverrides,
    SecurityProfile,
)
from workpilot.security.rbac import PolicyEngine

# ── Helpers ──────────────────────────────────────────────────────────────────


def _make_engine(
    profile: SecurityProfile = SecurityProfile.STANDARD,
    tool_overrides: dict[str, int] | None = None,
    agent_overrides: dict[str, dict] | None = None,
) -> PolicyEngine:
    """Build a PolicyEngine with the given profile and overrides."""
    overrides = SecurityOverrides(
        tools=tool_overrides or {},
        agents=agent_overrides or {},
    )
    config = SecurityConfig(profile=profile, overrides=overrides)
    return PolicyEngine(config)


# ── Profile defaults ─────────────────────────────────────────────────────────


class TestProfileDefaults:
    """Test that each SecurityProfile maps operations to the right autonomy level."""

    def test_open_profile_read_autonomous(self):
        engine = _make_engine(SecurityProfile.OPEN)
        level = engine.get_autonomy_level("read_file", "read")
        assert level == AutonomyLevel.AUTONOMOUS

    def test_open_profile_write_autonomous(self):
        engine = _make_engine(SecurityProfile.OPEN)
        level = engine.get_autonomy_level("write_file", "write")
        assert level == AutonomyLevel.AUTONOMOUS

    def test_open_profile_external_autonomous(self):
        engine = _make_engine(SecurityProfile.OPEN)
        level = engine.get_autonomy_level("http_request", "push")
        assert level == AutonomyLevel.AUTONOMOUS

    def test_open_profile_dangerous_forbidden(self):
        engine = _make_engine(SecurityProfile.OPEN)
        level = engine.get_autonomy_level("shell", "rm_rf")
        assert level == AutonomyLevel.FORBIDDEN

    def test_standard_profile_read_autonomous(self):
        engine = _make_engine(SecurityProfile.STANDARD)
        level = engine.get_autonomy_level("read_file", "read")
        assert level == AutonomyLevel.AUTONOMOUS

    def test_standard_profile_write_notify(self):
        engine = _make_engine(SecurityProfile.STANDARD)
        level = engine.get_autonomy_level("write_file", "write")
        assert level == AutonomyLevel.NOTIFY

    def test_standard_profile_external_approval(self):
        engine = _make_engine(SecurityProfile.STANDARD)
        level = engine.get_autonomy_level("http_request", "push")
        assert level == AutonomyLevel.APPROVAL

    def test_controlled_profile_external_approval(self):
        engine = _make_engine(SecurityProfile.CONTROLLED)
        level = engine.get_autonomy_level("http_request", "push")
        assert level == AutonomyLevel.APPROVAL

    def test_restricted_profile_read_notify(self):
        engine = _make_engine(SecurityProfile.RESTRICTED)
        level = engine.get_autonomy_level("read_file", "read")
        assert level == AutonomyLevel.NOTIFY

    def test_restricted_profile_write_approval(self):
        engine = _make_engine(SecurityProfile.RESTRICTED)
        level = engine.get_autonomy_level("write_file", "write")
        assert level == AutonomyLevel.APPROVAL


# ── get_autonomy_level with overrides ────────────────────────────────────────


class TestAutonomyLevelOverrides:
    def test_tool_override_takes_precedence_over_profile(self):
        engine = _make_engine(
            SecurityProfile.STANDARD,
            tool_overrides={"shell": AutonomyLevel.AUTONOMOUS},
        )
        level = engine.get_autonomy_level("shell", "read")
        # Tool override should return AUTONOMOUS regardless of profile
        assert level == AutonomyLevel.AUTONOMOUS

    def test_agent_override_takes_precedence_over_tool(self):
        engine = _make_engine(
            SecurityProfile.STANDARD,
            tool_overrides={"shell": AutonomyLevel.APPROVAL},
            agent_overrides={"code-bot": {"shell": AutonomyLevel.AUTONOMOUS}},
        )
        level = engine.get_autonomy_level("shell", "read", agent_name="code-bot")
        assert level == AutonomyLevel.AUTONOMOUS

    def test_agent_override_not_matched_falls_to_tool_override(self):
        engine = _make_engine(
            SecurityProfile.STANDARD,
            tool_overrides={"shell": AutonomyLevel.APPROVAL},
            agent_overrides={"code-bot": {"git": AutonomyLevel.AUTONOMOUS}},
        )
        # agent "code-bot" has no shell override -> fall to tool override
        level = engine.get_autonomy_level("shell", "read", agent_name="code-bot")
        assert level == AutonomyLevel.APPROVAL

    def test_unknown_agent_falls_through_to_profile(self):
        engine = _make_engine(SecurityProfile.OPEN)
        level = engine.get_autonomy_level("read_file", "read", agent_name="unknown-bot")
        assert level == AutonomyLevel.AUTONOMOUS

    def test_unknown_operation_defaults_to_write_category(self):
        engine = _make_engine(SecurityProfile.STANDARD)
        # An unknown operation should map to "write" category via _classify_operation
        level = engine.get_autonomy_level("shell", "some_unknown_operation")
        assert level == AutonomyLevel.NOTIFY  # STANDARD profile: write -> NOTIFY


# ── check_permission ─────────────────────────────────────────────────────────


class TestCheckPermission:
    def test_allowed_returns_true(self):
        engine = _make_engine(SecurityProfile.OPEN)
        allowed, level = engine.check_permission("read_file", "read")
        assert allowed is True
        assert level == AutonomyLevel.AUTONOMOUS

    def test_forbidden_returns_false(self):
        engine = _make_engine(SecurityProfile.OPEN)
        allowed, level = engine.check_permission("shell", "rm_rf")
        assert allowed is False
        assert level == AutonomyLevel.FORBIDDEN

    def test_approval_returns_true(self):
        engine = _make_engine(SecurityProfile.STANDARD)
        allowed, level = engine.check_permission("http_request", "push")
        assert allowed is True
        assert level == AutonomyLevel.APPROVAL


# ── classify_risk ────────────────────────────────────────────────────────────


class TestClassifyRisk:
    def test_known_tool_returns_static_risk(self):
        engine = _make_engine()
        risk = engine.classify_risk("read_file", {})
        assert risk == RiskLevel.LOW

    def test_shell_with_dangerous_args_returns_critical(self):
        engine = _make_engine()
        risk = engine.classify_risk("shell", {"command": "rm -rf /"})
        assert risk == RiskLevel.CRITICAL

    def test_shell_with_safe_command_returns_high(self):
        engine = _make_engine()
        risk = engine.classify_risk("shell", {"command": "ls -la"})
        assert risk == RiskLevel.HIGH  # shell is HIGH by default

    def test_git_force_push_returns_critical(self):
        engine = _make_engine()
        risk = engine.classify_risk("git", {"operation": "force_push"})
        assert risk == RiskLevel.CRITICAL

    def test_git_with_force_flag_returns_critical(self):
        engine = _make_engine()
        risk = engine.classify_risk("git", {"flags": "--force"})
        assert risk == RiskLevel.CRITICAL

    def test_write_file_to_sensitive_path_returns_critical(self):
        engine = _make_engine()
        risk = engine.classify_risk("write_file", {"path": "/home/user/.ssh/id_rsa"})
        assert risk == RiskLevel.CRITICAL

    def test_write_file_to_safe_path_returns_medium(self):
        engine = _make_engine()
        risk = engine.classify_risk("write_file", {"path": "/tmp/output.txt"})
        assert risk == RiskLevel.MEDIUM

    def test_unknown_tool_returns_medium(self):
        engine = _make_engine()
        risk = engine.classify_risk("some_custom_tool", {})
        assert risk == RiskLevel.MEDIUM
