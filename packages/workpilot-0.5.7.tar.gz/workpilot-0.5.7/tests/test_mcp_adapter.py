"""Tests for MCP tool adapter and registration into the ToolRegistry."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, PropertyMock

import pytest

from workpilot.agent.tools.registry import PROTECTED_TOOLS, ToolRegistry
from workpilot.mcp.adapter import MCPToolAdapter, register_mcp_tools

# ── Helpers ──────────────────────────────────────────────────────────────────


def _make_descriptor(
    name: str = "mcp_echo",
    description: str = "Echo input back",
    input_schema: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a minimal MCP tool descriptor."""
    return {
        "name": name,
        "description": description,
        "inputSchema": input_schema
        or {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Text to echo"},
            },
            "required": ["text"],
        },
    }


def _make_mock_client(
    *,
    name: str = "test-server",
    connected: bool = True,
    tools: list[dict[str, Any]] | None = None,
) -> AsyncMock:
    """Create a mock MCPClient."""
    client = AsyncMock()
    type(client).name = PropertyMock(return_value=name)
    type(client).is_connected = PropertyMock(return_value=connected)
    client.list_tools = AsyncMock(return_value=tools or [])
    client.call_tool = AsyncMock(return_value="tool result")
    return client


# ── MCPToolAdapter ───────────────────────────────────────────────────────────


class TestMCPToolAdapter:
    def test_name_from_descriptor(self) -> None:
        adapter = MCPToolAdapter(_make_descriptor(name="my_tool"), _make_mock_client())
        assert adapter.name == "my_tool"

    def test_description_from_descriptor(self) -> None:
        adapter = MCPToolAdapter(_make_descriptor(description="Does stuff"), _make_mock_client())
        assert adapter.description == "Does stuff"

    def test_parameters_from_input_schema(self) -> None:
        schema = {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        }
        adapter = MCPToolAdapter(_make_descriptor(input_schema=schema), _make_mock_client())
        assert adapter.parameters == schema

    def test_default_parameters_when_no_schema(self) -> None:
        descriptor = {"name": "bare_tool"}
        adapter = MCPToolAdapter(descriptor, _make_mock_client())
        assert adapter.parameters["type"] == "object"

    def test_metadata_category_is_mcp(self) -> None:
        adapter = MCPToolAdapter(_make_descriptor(), _make_mock_client())
        assert adapter.metadata.category == "mcp"

    def test_metadata_approval_is_auto(self) -> None:
        adapter = MCPToolAdapter(_make_descriptor(), _make_mock_client())
        assert adapter.metadata.approval == "auto"

    def test_metadata_risk_level_medium(self) -> None:
        adapter = MCPToolAdapter(_make_descriptor(), _make_mock_client())
        assert adapter.metadata.risk_level == "medium"

    def test_validate_passes_when_required_present(self) -> None:
        adapter = MCPToolAdapter(_make_descriptor(), _make_mock_client())
        assert adapter.validate({"text": "hello"}) == []

    def test_validate_fails_when_required_missing(self) -> None:
        adapter = MCPToolAdapter(_make_descriptor(), _make_mock_client())
        errors = adapter.validate({})
        assert len(errors) == 1
        assert "text" in errors[0]

    def test_to_openai_schema(self) -> None:
        adapter = MCPToolAdapter(_make_descriptor(), _make_mock_client())
        schema = adapter.to_openai_schema()
        assert schema["type"] == "function"
        assert schema["function"]["name"] == "mcp_echo"
        assert "parameters" in schema["function"]

    @pytest.mark.asyncio
    async def test_execute_calls_mcp_client(self) -> None:
        client = _make_mock_client()
        adapter = MCPToolAdapter(_make_descriptor(), client)
        result = await adapter.execute(text="hello")
        client.call_tool.assert_awaited_once_with("mcp_echo", {"text": "hello"})
        assert result == "tool result"

    @pytest.mark.asyncio
    async def test_execute_returns_error_when_disconnected(self) -> None:
        client = _make_mock_client(connected=False)
        adapter = MCPToolAdapter(_make_descriptor(), client)
        result = await adapter.execute(text="hello")
        assert "disconnected" in result.lower()
        client.call_tool.assert_not_awaited()


# ── register_mcp_tools ──────────────────────────────────────────────────────


class TestRegisterMCPTools:
    @pytest.mark.asyncio
    async def test_registers_tools_from_server(self) -> None:
        descriptors = [
            _make_descriptor(name="mcp_read"),
            _make_descriptor(name="mcp_write"),
        ]
        client = _make_mock_client(tools=descriptors)
        registry = ToolRegistry()

        registered = await register_mcp_tools(registry, client)

        assert registered == ["mcp_read", "mcp_write"]
        assert registry.get("mcp_read") is not None
        assert registry.get("mcp_write") is not None

    @pytest.mark.asyncio
    async def test_skips_protected_tool_names(self) -> None:
        # Pick a known protected name
        protected_name = next(iter(PROTECTED_TOOLS))
        descriptors = [
            _make_descriptor(name=protected_name),
            _make_descriptor(name="safe_tool"),
        ]
        client = _make_mock_client(tools=descriptors)
        registry = ToolRegistry()

        registered = await register_mcp_tools(registry, client)

        assert registered == ["safe_tool"]
        assert registry.get(protected_name) is None
        assert registry.get("safe_tool") is not None

    @pytest.mark.asyncio
    async def test_skips_tools_with_empty_name(self) -> None:
        descriptors = [{"name": "", "description": "bad"}]
        client = _make_mock_client(tools=descriptors)
        registry = ToolRegistry()

        registered = await register_mcp_tools(registry, client)

        assert registered == []

    @pytest.mark.asyncio
    async def test_handles_list_tools_failure(self) -> None:
        client = _make_mock_client()
        client.list_tools = AsyncMock(side_effect=RuntimeError("connection lost"))
        registry = ToolRegistry()

        registered = await register_mcp_tools(registry, client)

        assert registered == []

    @pytest.mark.asyncio
    async def test_registered_tools_have_mcp_category(self) -> None:
        descriptors = [_make_descriptor(name="mcp_tool")]
        client = _make_mock_client(tools=descriptors)
        registry = ToolRegistry()

        await register_mcp_tools(registry, client)

        tool = registry.get("mcp_tool")
        assert tool is not None
        assert tool.metadata.category == "mcp"

    @pytest.mark.asyncio
    async def test_schemas_included_in_registry_output(self) -> None:
        descriptors = [_make_descriptor(name="mcp_tool")]
        client = _make_mock_client(tools=descriptors)
        registry = ToolRegistry()

        await register_mcp_tools(registry, client)

        schemas = registry.get_schemas()
        assert len(schemas) == 1
        assert schemas[0]["function"]["name"] == "mcp_tool"

    @pytest.mark.asyncio
    async def test_empty_server_returns_empty(self) -> None:
        client = _make_mock_client(tools=[])
        registry = ToolRegistry()

        registered = await register_mcp_tools(registry, client)

        assert registered == []
        assert registry.list_tools() == []

    @pytest.mark.asyncio
    async def test_restricted_profile_sets_approval_always(self) -> None:
        """When security_profile='restricted', all MCP tools get approval='always'."""
        descriptors = [
            _make_descriptor(name="mcp_a"),
            _make_descriptor(name="mcp_b"),
        ]
        client = _make_mock_client(tools=descriptors)
        registry = ToolRegistry()

        registered = await register_mcp_tools(registry, client, security_profile="restricted")

        assert registered == ["mcp_a", "mcp_b"]
        for name in registered:
            tool = registry.get(name)
            assert tool is not None
            assert tool.metadata.approval == "always"

    @pytest.mark.asyncio
    async def test_skips_namespace_collision_with_existing_tool(self) -> None:
        """When a non-protected tool is already registered, skip and log a warning."""
        # Pre-register a tool with the same name
        existing = MCPToolAdapter(_make_descriptor(name="overlap_tool"), _make_mock_client())
        registry = ToolRegistry()
        registry.register(existing)

        # Now try to register an MCP tool with the same name from a different server
        descriptors = [_make_descriptor(name="overlap_tool")]
        client = _make_mock_client(name="second-server", tools=descriptors)

        registered = await register_mcp_tools(registry, client)

        assert registered == []
        # The original tool should still be there (not replaced)
        assert registry.get("overlap_tool") is existing


class TestMCPToolAdapterExecuteErrors:
    @pytest.mark.asyncio
    async def test_execute_handles_connection_error(self) -> None:
        """ConnectionError from call_tool returns error string, attempts disconnect."""
        client = _make_mock_client()
        client.call_tool = AsyncMock(side_effect=ConnectionError("server gone"))
        adapter = MCPToolAdapter(_make_descriptor(name="broken"), client)

        result = await adapter.execute(text="hello")

        assert isinstance(result, str)
        assert "failed" in result.lower()
        client.disconnect.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_execute_handles_timeout_error(self) -> None:
        """TimeoutError from call_tool returns error string but does NOT disconnect."""
        client = _make_mock_client()
        client.call_tool = AsyncMock(side_effect=TimeoutError("timed out"))
        adapter = MCPToolAdapter(_make_descriptor(name="slow"), client)

        result = await adapter.execute(text="hello")

        assert isinstance(result, str)
        assert "failed" in result.lower()
        # TimeoutError should NOT disconnect — health monitor handles reconnects
        client.disconnect.assert_not_awaited()


class TestMCPToolAdapterCustomApproval:
    def test_custom_approval_parameter(self) -> None:
        """MCPToolAdapter with approval='always' should reflect in metadata."""
        adapter = MCPToolAdapter(_make_descriptor(), _make_mock_client(), approval="always")
        assert adapter.metadata.approval == "always"
