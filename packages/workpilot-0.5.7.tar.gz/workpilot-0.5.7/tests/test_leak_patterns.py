"""Tests for credential pattern leak detection (workpilot.security.leak).

Covers every pattern with realistic examples, false-positive avoidance,
redact_credentials(), and LeakScanner hook integration.
"""

from __future__ import annotations

import pytest

from workpilot.security.leak import detect_credentials, redact_credentials

# ---------------------------------------------------------------------------
# Realistic credential samples for parametrized tests
# ---------------------------------------------------------------------------

_JWT = (
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
    "eyJzdWIiOiIxMjM0NTY3ODkwIn0."
    "dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
)

_AWS_ACCESS = "AKIAIOSFODNN7EXAMPLE"
_AWS_SECRET = "aws_secret_access_key='wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY'"

_GH_PAT = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn"
_GH_PAT_V2 = "github_pat_11ABCDEF_abcdefghijklmnopqrstuvwxyz1234567890"

_OPENAI = "sk-proj-abcdefghijklmnopqrstuvwxyz123456"
_OPENAI_LEGACY = "sk-abcdefghijklmnopqrstuvwxyz1234567890ab"

_SLACK = "xoxb-" + "0000000TEST-0000000FAKE0-ABCDEFabcdef000TESTONLY"  # noqa: S105
_GOOGLE = "AIzaSyA-1234567890abcdefghijklmnopqrstuvw"
_STRIPE_LIVE = "sk_live_" + "0" * 24  # noqa: S105
_STRIPE_TEST = "pk_test_" + "0" * 24  # noqa: S105
_PRIVATE_KEY = (
    "-----BEGIN RSA PRIVATE KEY-----\n"
    "MIIBogIBAAJBALRiMLAH0123456789abcdefABCDEFtest\n"
    "only-not-a-real-key-0123456789abcdefghijklmnop==\n"
    "-----END RSA PRIVATE KEY-----"
)
_AZURE_STORAGE = (
    "DefaultEndpointsProtocol=https;"
    "AccountName=myaccount;"
    "AccountKey=" + "abc123def456ghi789" + ";"
    "EndpointSuffix=core.windows.net"
)
_HEX_64 = "a" * 80  # 80-char hex string (matches min threshold)

# ---------------------------------------------------------------------------
# Pattern detection tests
# ---------------------------------------------------------------------------


class TestDetectCredentials:
    """Each credential type should be detected with a realistic sample."""

    @pytest.mark.parametrize(
        ("label", "sample", "expected_type"),
        [
            ("JWT", _JWT, "JWT"),
            ("AWS Access Key", _AWS_ACCESS, "AWS Access Key"),
            ("AWS Secret Key", _AWS_SECRET, "AWS Secret Key"),
            ("GitHub PAT (ghp)", _GH_PAT, "GitHub PAT"),
            ("GitHub PAT (github_pat)", _GH_PAT_V2, "GitHub PAT"),
            ("OpenAI Key (proj)", _OPENAI, "OpenAI Key"),
            ("OpenAI Key (legacy)", _OPENAI_LEGACY, "OpenAI Key"),
            ("Slack Token", _SLACK, "Slack Token"),
            ("Google API Key", _GOOGLE, "Google API Key"),
            ("Stripe Live Key", _STRIPE_LIVE, "Stripe Key"),
            ("Stripe Test Key", _STRIPE_TEST, "Stripe Key"),
            ("Private Key (full PEM)", _PRIVATE_KEY, "Private Key"),
            ("Azure Storage", _AZURE_STORAGE, "Azure Storage"),
            ("High-Entropy Hex (64)", _HEX_64, "High-Entropy Hex"),
        ],
        ids=lambda v: v if isinstance(v, str) and len(v) < 30 else None,
    )
    def test_pattern_detected(self, label: str, sample: str, expected_type: str) -> None:
        findings = detect_credentials(sample)
        types = [t for t, _ in findings]
        assert expected_type in types, f"Expected '{expected_type}' in {types} for {label}"

    def test_multiple_credentials_in_one_text(self) -> None:
        text = f"Token: {_JWT}\nKey: {_AWS_ACCESS}\nPAT: {_GH_PAT}"
        findings = detect_credentials(text)
        types = {t for t, _ in findings}
        assert {"JWT", "AWS Access Key", "GitHub PAT"} <= types

    def test_preview_truncated(self) -> None:
        findings = detect_credentials(_JWT)
        assert len(findings) >= 1
        _cred_type, preview = findings[0]
        assert preview.endswith("...")
        assert len(preview) <= 11  # 8 chars + "..."

    def test_clean_text_no_findings(self) -> None:
        assert detect_credentials("Hello world, nothing to see here.") == []

    def test_empty_string(self) -> None:
        assert detect_credentials("") == []


# ---------------------------------------------------------------------------
# False-positive avoidance
# ---------------------------------------------------------------------------


class TestFalsePositiveAvoidance:
    """Ensure normal content does not trigger false positives."""

    def test_normal_sha256_hash_ignored(self) -> None:
        # SHA-256 is 64 hex chars -- but it should only match if NOT bordered
        # by alphanumeric characters.
        sha = "abc123" + "a" * 64 + "xyz"
        findings = detect_credentials(sha)
        hex_findings = [t for t, _ in findings if t == "High-Entropy Hex"]
        assert hex_findings == [], "Bordered hex should not match"

    def test_short_hex_ignored(self) -> None:
        # 32-char hex (MD5) should NOT trigger the 64+ hex pattern
        md5 = "d41d8cd98f00b204e9800998ecf8427e"
        findings = detect_credentials(md5)
        hex_findings = [t for t, _ in findings if t == "High-Entropy Hex"]
        assert hex_findings == []

    def test_normal_base64_not_jwt(self) -> None:
        # Base64 that doesn't start with eyJ should not match JWT
        b64 = "aGVsbG8gd29ybGQ=.dGVzdA==.Zm9vYmFy"
        findings = detect_credentials(b64)
        jwt_findings = [t for t, _ in findings if t == "JWT"]
        assert jwt_findings == []

    def test_sk_prefix_short_not_matched(self) -> None:
        # "sk-" followed by < 32 chars should not match OpenAI pattern
        short = "sk-short"
        findings = detect_credentials(short)
        openai_findings = [t for t, _ in findings if t == "OpenAI Key"]
        assert openai_findings == []

    def test_normal_prose_no_match(self) -> None:
        prose = (
            "The system should authenticate users via OAuth 2.0 flows. "
            "Tokens are stored securely in the database and rotated weekly."
        )
        assert detect_credentials(prose) == []


# ---------------------------------------------------------------------------
# Redaction tests
# ---------------------------------------------------------------------------


class TestRedactCredentials:
    """Test that redact_credentials replaces matched patterns correctly."""

    def test_jwt_redacted(self) -> None:
        text = f"Authorization: Bearer {_JWT}"
        result = redact_credentials(text)
        assert "[REDACTED:JWT]" in result
        assert "eyJ" not in result

    def test_aws_access_key_redacted(self) -> None:
        text = f"aws_access_key_id = {_AWS_ACCESS}"
        result = redact_credentials(text)
        assert "[REDACTED:AWS Access Key]" in result
        assert "AKIA" not in result

    def test_github_pat_redacted(self) -> None:
        text = f"GITHUB_TOKEN={_GH_PAT}"
        result = redact_credentials(text)
        assert "[REDACTED:GitHub PAT]" in result
        assert "ghp_" not in result

    def test_openai_key_redacted(self) -> None:
        text = f"OPENAI_API_KEY={_OPENAI}"
        result = redact_credentials(text)
        assert "[REDACTED:OpenAI Key]" in result

    def test_private_key_redacted(self) -> None:
        # The regex matches the full PEM block (BEGIN through END).
        text = f"Key:\n{_PRIVATE_KEY}\nTrailing text"
        result = redact_credentials(text)
        assert "[REDACTED:Private Key]" in result
        assert "BEGIN" not in result
        assert "END" not in result
        # The key body (between BEGIN and END) must also be removed.
        assert "MIIBogIBAAJ" not in result

    def test_multiple_secrets_redacted(self) -> None:
        text = f"jwt={_JWT} key={_AWS_ACCESS}"
        result = redact_credentials(text)
        assert "[REDACTED:JWT]" in result
        assert "[REDACTED:AWS Access Key]" in result

    def test_clean_text_unchanged(self) -> None:
        text = "No secrets here, just normal text."
        assert redact_credentials(text) == text

    def test_azure_storage_redacted(self) -> None:
        text = f"CONNECTION_STRING={_AZURE_STORAGE}"
        result = redact_credentials(text)
        assert "[REDACTED:Azure Storage]" in result
        # The full connection string including AccountKey must be redacted
        assert "AccountKey" not in result
        assert "AccountName" not in result

    def test_stripe_key_redacted(self) -> None:
        text = f"STRIPE_KEY={_STRIPE_LIVE}"
        result = redact_credentials(text)
        assert "[REDACTED:Stripe Key]" in result


# ---------------------------------------------------------------------------
# LeakScanner hook integration
# ---------------------------------------------------------------------------


class TestLeakScannerHookIntegration:
    """Test that LeakScanner hook correctly detects credential patterns."""

    @pytest.mark.asyncio
    async def test_clean_output_allows(self) -> None:
        from workpilot.hooks.handlers import LeakScanner
        from workpilot.hooks.manager import HookVerdict, PostToolHookContext

        scanner = LeakScanner()
        ctx = PostToolHookContext(
            tool_name="shell",
            args={"command": "ls"},
            result="file1.py\nfile2.py",
        )
        result = await scanner(ctx)
        assert result.verdict == HookVerdict.ALLOW

    @pytest.mark.asyncio
    async def test_jwt_in_output_detected(self) -> None:
        from workpilot.hooks.handlers import LeakScanner
        from workpilot.hooks.manager import HookVerdict, PostToolHookContext

        scanner = LeakScanner()
        ctx = PostToolHookContext(
            tool_name="shell",
            args={"command": "curl"},
            result=f"Response: {_JWT}",
        )
        # LeakScanner logs a warning but still allows (detection, not blocking)
        result = await scanner(ctx)
        assert result.verdict == HookVerdict.ALLOW

    @pytest.mark.asyncio
    async def test_aws_key_in_output_detected(self) -> None:
        from workpilot.hooks.handlers import LeakScanner
        from workpilot.hooks.manager import HookVerdict, PostToolHookContext

        scanner = LeakScanner()
        ctx = PostToolHookContext(
            tool_name="read_file",
            args={"path": ".env"},
            result=f"AWS_KEY={_AWS_ACCESS}",
        )
        result = await scanner(ctx)
        assert result.verdict == HookVerdict.ALLOW

    @pytest.mark.asyncio
    async def test_redactor_cleans_jwt(self) -> None:
        from workpilot.hooks.handlers import Redactor
        from workpilot.hooks.manager import PostToolHookContext

        redactor = Redactor()
        ctx = PostToolHookContext(
            tool_name="shell",
            args={},
            result=f"token={_JWT}",
        )
        result = await redactor(ctx)
        # The result data should have the JWT redacted
        cleaned_ctx = result.data
        assert "eyJ" not in cleaned_ctx.result
        assert "[REDACTED:JWT]" in cleaned_ctx.result

    @pytest.mark.asyncio
    async def test_outbound_leak_scanner_redacts(self) -> None:
        from workpilot.hooks.handlers import OutboundLeakScanner
        from workpilot.hooks.manager import MessageHookContext

        scanner = OutboundLeakScanner()
        ctx = MessageHookContext(
            content=f"Here is your key: {_GH_PAT}",
            channel="cli",
        )
        result = await scanner(ctx)
        cleaned_ctx = result.data
        assert "ghp_" not in cleaned_ctx.content
        assert "[REDACTED:GitHub PAT]" in cleaned_ctx.content
