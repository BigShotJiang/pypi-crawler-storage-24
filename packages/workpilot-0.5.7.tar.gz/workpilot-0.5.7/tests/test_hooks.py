"""Tests for hook manager."""

import pytest

from workpilot.hooks.manager import HookManager


class TestHookManager:
    @pytest.mark.asyncio
    async def test_dispatch_single_hook(self):
        mgr = HookManager()

        async def double(data: int) -> int:
            return data * 2

        mgr.register("before-request", double)
        result = await mgr.dispatch("before-request", 5)
        assert result == 10

    @pytest.mark.asyncio
    async def test_chain_hooks(self):
        mgr = HookManager()

        async def add_one(data: int) -> int:
            return data + 1

        async def double(data: int) -> int:
            return data * 2

        mgr.register("transform", add_one)
        mgr.register("transform", double)

        result = await mgr.dispatch("transform", 5)
        assert result == 12  # (5 + 1) * 2

    @pytest.mark.asyncio
    async def test_no_hooks_returns_data(self):
        mgr = HookManager()
        result = await mgr.dispatch("empty", {"key": "val"})
        assert result == {"key": "val"}

    @pytest.mark.asyncio
    async def test_error_continues_chain(self):
        mgr = HookManager()

        async def failing(data: str) -> str:
            raise ValueError("oops")

        async def append(data: str) -> str:
            return data + "-ok"

        mgr.register("test", failing)
        mgr.register("test", append)

        result = await mgr.dispatch("test", "start")
        assert result == "start-ok"

    def test_has(self):
        mgr = HookManager()
        assert not mgr.has("test")
        mgr.register("test", lambda x: x)
        assert mgr.has("test")
