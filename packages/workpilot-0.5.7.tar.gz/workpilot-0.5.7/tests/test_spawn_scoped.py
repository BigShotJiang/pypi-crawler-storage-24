"""Tests for agent-aware spawn — scoped registry, agent discovery, permissions."""

from workpilot.agent.context import ContextBuilder
from workpilot.agent.tools.base import Tool
from workpilot.agent.tools.registry import ToolRegistry
from workpilot.agents.builtin import get_builtin_agents, merge_agents
from workpilot.config.schema import AgentConfig, AuditConfig
from workpilot.security.audit import AuditLogger

# ── Scoped Registry ─────────────────────────────────────────────────────────


class _DummyTool(Tool):
    def __init__(self, tool_name: str):
        self._name = tool_name

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return f"Dummy {self._name}"

    @property
    def parameters(self) -> dict:
        return {"type": "object", "properties": {}}

    async def execute(self, **kwargs) -> str:
        return f"executed {self._name}"


class TestScopedCopy:
    def test_scoped_copy_filters_tools(self):
        registry = ToolRegistry()
        registry.register(_DummyTool("shell"))
        registry.register(_DummyTool("read_file"))
        registry.register(_DummyTool("spawn"))
        registry.register(_DummyTool("notify"))

        scoped = registry.scoped_copy(["read_file"])
        assert [t.name for t in scoped.list_tools()] == ["read_file"]

    def test_scoped_copy_empty_list(self):
        registry = ToolRegistry()
        registry.register(_DummyTool("shell"))
        scoped = registry.scoped_copy([])
        assert scoped.list_tools() == []

    def test_scoped_copy_preserves_audit(self):
        audit = AuditLogger(AuditConfig(enabled=False))
        registry = ToolRegistry(audit=audit)
        registry.register(_DummyTool("shell"))
        scoped = registry.scoped_copy(["shell"])
        assert scoped._audit is audit

    def test_scoped_copy_custom_audit(self):
        audit1 = AuditLogger(AuditConfig(enabled=False))
        audit2 = AuditLogger(AuditConfig(enabled=False))
        registry = ToolRegistry(audit=audit1)
        registry.register(_DummyTool("shell"))
        scoped = registry.scoped_copy(["shell"], audit=audit2)
        assert scoped._audit is audit2

    def test_scoped_copy_excludes_spawn_and_notify(self):
        """Verify the pattern used in Runtime._spawn_agent."""
        registry = ToolRegistry()
        for name in ["shell", "read_file", "write_file", "spawn", "notify"]:
            registry.register(_DummyTool(name))

        agent_tools = ["shell", "read_file", "write_file", "spawn", "notify"]
        excluded = {"spawn", "notify"}
        scoped_tools = [t for t in agent_tools if t not in excluded]
        scoped = registry.scoped_copy(scoped_tools)

        tool_names = {t.name for t in scoped.list_tools()}
        assert "spawn" not in tool_names
        assert "notify" not in tool_names
        assert "shell" in tool_names
        assert "read_file" in tool_names


# ── Agent Discovery Table ───────────────────────────────────────────────────


class TestAgentDiscovery:
    def test_discovery_table_includes_explorer(self, tmp_path):
        agents = get_builtin_agents()
        ctx = ContextBuilder(
            AgentConfig(),
            tmp_path,
            available_agents=agents,
        )
        prompt = ctx.build_system_prompt()
        assert "Available Sub-Agents" in prompt
        assert "explorer" in prompt
        assert "Fast codebase search" in prompt

    def test_discovery_table_excludes_internal(self, tmp_path):
        agents = get_builtin_agents()
        ctx = ContextBuilder(
            AgentConfig(),
            tmp_path,
            available_agents=agents,
        )
        prompt = ctx.build_system_prompt()
        assert "security" not in prompt.split("Available Sub-Agents")[1]

    def test_discovery_table_excludes_default(self, tmp_path):
        agents = get_builtin_agents()
        ctx = ContextBuilder(
            AgentConfig(),
            tmp_path,
            available_agents=agents,
        )
        table_section = ctx._build_agent_discovery()
        # "default" should not appear as a row
        lines = table_section.split("\n")
        data_rows = [
            row for row in lines if row.startswith("| ") and "Agent" not in row and "---" not in row
        ]
        for row in data_rows:
            assert not row.startswith("| default")

    def test_no_agents_no_table(self, tmp_path):
        ctx = ContextBuilder(AgentConfig(), tmp_path, available_agents={})
        prompt = ctx.build_system_prompt()
        assert "Available Sub-Agents" not in prompt

    def test_user_agent_appears_in_discovery(self, tmp_path):
        agents = get_builtin_agents()
        agents["coder"] = AgentConfig(
            name="Coder",
            description="Code implementation specialist.",
            model="auto",
            tools=["shell", "read_file", "write_file", "edit_file"],
            max_iterations=25,
        )
        ctx = ContextBuilder(
            AgentConfig(),
            tmp_path,
            available_agents=agents,
        )
        prompt = ctx.build_system_prompt()
        assert "coder" in prompt
        assert "Code implementation" in prompt


# ── Spawn Agent Lookup ───────────────────────────────────────────────────────


class TestSpawnAgentLookup:
    def test_builtin_agents_always_available(self):
        """Built-in agents available even with empty user config."""
        builtin = get_builtin_agents()
        user = {}
        merged = merge_agents(builtin, user)
        assert "explorer" in merged
        assert "security" in merged

    def test_unknown_agent_not_in_merged(self):
        builtin = get_builtin_agents()
        merged = merge_agents(builtin, {})
        assert "nonexistent" not in merged

    def test_explorer_has_correct_tools(self):
        builtin = get_builtin_agents()
        explorer = builtin["explorer"]
        assert set(explorer.tools) == {"read_file", "list_dir", "search_files"}
