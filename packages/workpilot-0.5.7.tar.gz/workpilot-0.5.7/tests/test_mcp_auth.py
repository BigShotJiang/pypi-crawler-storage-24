"""Tests for MCP auth — bearer, OAuth, Agency detection."""

from __future__ import annotations

import os
from unittest.mock import AsyncMock, patch

import pytest

from workpilot.config.schema import MCPAuthConfig, MCPServerConfig
from workpilot.mcp.auth import (
    _resolve_bearer_token,
    resolve_auth_headers,
)

# ── Bearer Token ─────────────────────────────────────────────────────────────


class TestBearerToken:
    def test_token_from_config(self) -> None:
        auth = MCPAuthConfig(type="bearer", token="my-secret-token")
        assert _resolve_bearer_token(auth) == "my-secret-token"

    def test_token_from_env(self) -> None:
        auth = MCPAuthConfig(type="bearer", token_env="TEST_MCP_TOKEN")
        with patch.dict(os.environ, {"TEST_MCP_TOKEN": "env-token"}):
            assert _resolve_bearer_token(auth) == "env-token"

    def test_token_missing(self) -> None:
        auth = MCPAuthConfig(type="bearer")
        assert _resolve_bearer_token(auth) is None

    def test_token_env_missing(self) -> None:
        auth = MCPAuthConfig(type="bearer", token_env="NONEXISTENT_VAR")
        assert _resolve_bearer_token(auth) is None


# ── resolve_auth_headers ─────────────────────────────────────────────────────


class TestResolveAuthHeaders:
    @pytest.mark.asyncio
    async def test_stdio_returns_empty(self) -> None:
        """Stdio servers handle auth internally — no headers."""
        config = MCPServerConfig(command="agency", args=["mcp", "icm"])
        headers = await resolve_auth_headers(config)
        assert headers == {}

    @pytest.mark.asyncio
    async def test_none_auth_returns_empty(self) -> None:
        config = MCPServerConfig(url="https://mcp.example.com")
        headers = await resolve_auth_headers(config)
        assert headers == {}

    @pytest.mark.asyncio
    async def test_bearer_with_token(self) -> None:
        config = MCPServerConfig(
            url="https://mcp.example.com",
            auth=MCPAuthConfig(type="bearer", token="my-token"),
        )
        headers = await resolve_auth_headers(config)
        assert headers == {"Authorization": "Bearer my-token"}

    @pytest.mark.asyncio
    async def test_bearer_with_env(self) -> None:
        config = MCPServerConfig(
            url="https://mcp.example.com",
            auth=MCPAuthConfig(type="bearer", token_env="TEST_TOKEN"),
        )
        with patch.dict(os.environ, {"TEST_TOKEN": "env-val"}):
            headers = await resolve_auth_headers(config)
        assert headers == {"Authorization": "Bearer env-val"}

    @pytest.mark.asyncio
    async def test_bearer_missing_token_returns_empty(self) -> None:
        config = MCPServerConfig(
            url="https://mcp.example.com",
            auth=MCPAuthConfig(type="bearer"),  # no token or token_env
        )
        headers = await resolve_auth_headers(config)
        assert headers == {}

    @pytest.mark.asyncio
    async def test_oauth_missing_credentials_returns_empty(self) -> None:
        config = MCPServerConfig(
            url="https://mcp.example.com",
            auth=MCPAuthConfig(type="oauth"),  # no client_id/secret
        )
        headers = await resolve_auth_headers(config)
        assert headers == {}

    @pytest.mark.asyncio
    async def test_oauth_with_credentials(self) -> None:
        """OAuth client credentials flow — mock the HTTP call."""
        config = MCPServerConfig(
            url="https://mcp.example.com",
            auth=MCPAuthConfig(
                type="oauth",
                client_id="test-client",
                client_secret="test-secret",
                scopes=["https://graph.microsoft.com/.default"],
            ),
        )

        from unittest.mock import MagicMock

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = lambda: None
        mock_response.json.return_value = {
            "access_token": "oauth-token-123",
            "token_type": "Bearer",
        }

        with patch("workpilot.mcp.auth.httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            headers = await resolve_auth_headers(config)

        assert headers == {"Authorization": "Bearer oauth-token-123"}
        mock_client.post.assert_awaited_once()
        # Verify correct parameters were sent
        call_kwargs = mock_client.post.call_args
        assert call_kwargs[1]["data"]["grant_type"] == "client_credentials"
        assert call_kwargs[1]["data"]["client_id"] == "test-client"
        assert call_kwargs[1]["data"]["client_secret"] == "test-secret"

    @pytest.mark.asyncio
    async def test_oauth_http_error_returns_empty(self) -> None:
        """OAuth token exchange fails — returns empty headers."""
        config = MCPServerConfig(
            url="https://mcp.example.com",
            auth=MCPAuthConfig(
                type="oauth",
                client_id="test-client",
                client_secret="test-secret",
                scopes=["scope"],
            ),
        )

        import httpx

        with patch("workpilot.mcp.auth.httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(side_effect=httpx.HTTPError("connection failed"))
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            headers = await resolve_auth_headers(config)

        assert headers == {}

    @pytest.mark.asyncio
    async def test_unknown_auth_type_returns_empty(self) -> None:
        """Unknown auth type is handled gracefully."""
        config = MCPServerConfig(url="https://mcp.example.com")
        # Force an unknown type by bypassing Pydantic validation
        config.auth = MCPAuthConfig()
        object.__setattr__(config.auth, "type", "kerberos")

        headers = await resolve_auth_headers(config)
        assert headers == {}
