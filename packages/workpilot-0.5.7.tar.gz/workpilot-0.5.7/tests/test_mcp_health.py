"""Tests for MCP health monitor and auto-reconnect."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, PropertyMock, patch

import pytest

from workpilot.agent.tools.registry import ToolRegistry
from workpilot.config.schema import MCPServerConfig
from workpilot.mcp.health import MCPHealthMonitor
from workpilot.mcp.manager import MCPManager


def _cfg(**kwargs: Any) -> MCPServerConfig:
    return MCPServerConfig(command="agency", args=["mcp", "icm"], **kwargs)


def _descriptors(*names: str) -> list[dict[str, Any]]:
    return [
        {"name": n, "description": f"Tool {n}", "inputSchema": {"type": "object", "properties": {}}}
        for n in names
    ]


async def _agency_ok() -> tuple[bool, str]:
    return True, "ok"


_PATCH_AGENCY = patch("workpilot.mcp.manager.pre_connect_agency_check", side_effect=_agency_ok)


def _patch_client(descriptors: list[dict[str, Any]] | None = None):
    mock_cls = patch("workpilot.mcp.manager.MCPClient")

    def _setup(mc):
        inst = AsyncMock()
        type(inst).is_connected = PropertyMock(return_value=True)
        type(inst).name = PropertyMock(return_value="test")
        inst.list_tools = AsyncMock(return_value=descriptors or [])
        inst.call_tool = AsyncMock(return_value="result")
        mc.return_value = inst
        return inst

    return mock_cls, _setup


class TestHealthMonitorBasics:
    @pytest.mark.asyncio
    async def test_check_server_healthy(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")

        monitor = MCPHealthMonitor(mgr, ping_timeout=5.0)
        # Client mock returns tools successfully → healthy
        result = await monitor.check_server("icm")
        assert result is True

    @pytest.mark.asyncio
    async def test_check_server_unhealthy(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")

        # Make list_tools fail
        mgr._clients["icm"].list_tools = AsyncMock(side_effect=ConnectionError("dead"))

        monitor = MCPHealthMonitor(mgr, ping_timeout=5.0)
        result = await monitor.check_server("icm")
        assert result is False

    @pytest.mark.asyncio
    async def test_check_server_not_connected(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        monitor = MCPHealthMonitor(mgr)
        result = await monitor.check_server("icm")
        assert result is False

    @pytest.mark.asyncio
    async def test_stop_monitoring(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())
        monitor = MCPHealthMonitor(mgr, default_interval=3600)

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")

        await monitor.start_monitoring("icm")
        assert "icm" in monitor._tasks

        monitor.stop_monitoring("icm")
        assert "icm" not in monitor._tasks

    @pytest.mark.asyncio
    async def test_stop_all(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())
        monitor = MCPHealthMonitor(mgr, default_interval=3600)

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")

        await monitor.start_monitoring("icm")
        monitor.stop_all()
        assert len(monitor._tasks) == 0

    @pytest.mark.asyncio
    async def test_start_monitoring_idempotent(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())
        monitor = MCPHealthMonitor(mgr, default_interval=3600)

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")

        await monitor.start_monitoring("icm")
        task1 = monitor._tasks["icm"]
        await monitor.start_monitoring("icm")
        task2 = monitor._tasks["icm"]
        assert task1 is task2  # Same task, not duplicated

        monitor.stop_all()


class TestManagerHealthIntegration:
    @pytest.mark.asyncio
    async def test_connect_starts_health_monitor(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")

        assert mgr._health_monitor is not None
        assert "icm" in mgr._health_monitor._tasks

        await mgr.disconnect_all()

    @pytest.mark.asyncio
    async def test_disconnect_stops_health_monitor(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await mgr.connect_server("icm")

        monitor = mgr._health_monitor
        assert "icm" in monitor._tasks

        await mgr.disconnect_server("icm")
        assert "icm" not in monitor._tasks
