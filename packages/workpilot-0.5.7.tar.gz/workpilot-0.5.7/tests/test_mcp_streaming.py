"""Tests for MCP streaming tool results."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, PropertyMock

import pytest

from workpilot.mcp.adapter import MCPToolAdapter
from workpilot.mcp.client import MCPClient


def _desc(name: str = "slow_query") -> dict[str, Any]:
    return {
        "name": name,
        "description": "Slow query",
        "inputSchema": {"type": "object", "properties": {}},
    }


def _mock_client(connected: bool = True) -> AsyncMock:
    client = AsyncMock()
    type(client).name = PropertyMock(return_value="test")
    type(client).is_connected = PropertyMock(return_value=connected)
    client.call_tool = AsyncMock(return_value="full result")
    return client


class TestClientStreaming:
    @pytest.mark.asyncio
    async def test_call_tool_streaming_fallback(self) -> None:
        """Streaming falls back to single-chunk yield."""
        client = MCPClient(command="echo", args=["test"], name="test")
        client._transport = AsyncMock()
        client._send_request = AsyncMock(
            return_value={
                "result": {
                    "content": [{"type": "text", "text": "query result"}],
                },
            }
        )

        chunks: list[str] = []
        async for chunk in client.call_tool_streaming("query", {"sql": "SELECT 1"}):
            chunks.append(chunk)

        assert len(chunks) == 1
        assert "query result" in chunks[0]


class TestAdapterStreaming:
    def test_streaming_flag_default_false(self) -> None:
        adapter = MCPToolAdapter(_desc(), _mock_client())
        assert adapter.metadata.streaming is False

    def test_streaming_flag_set(self) -> None:
        adapter = MCPToolAdapter(_desc(), _mock_client(), streaming=True)
        assert adapter.metadata.streaming is True

    @pytest.mark.asyncio
    async def test_execute_streaming_fallback(self) -> None:
        """Adapter streaming yields single chunk when server doesn't stream."""
        client = _mock_client()

        # Make call_tool_streaming yield single chunk
        async def _fake_stream(name, args):
            yield "full result"

        client.call_tool_streaming = _fake_stream

        adapter = MCPToolAdapter(_desc(), client, streaming=True)

        chunks: list[str] = []
        async for chunk in adapter.execute_streaming():
            chunks.append(chunk)

        assert chunks == ["full result"]

    @pytest.mark.asyncio
    async def test_execute_streaming_disconnected(self) -> None:
        client = _mock_client(connected=False)
        adapter = MCPToolAdapter(_desc(), client, streaming=True)

        chunks: list[str] = []
        async for chunk in adapter.execute_streaming():
            chunks.append(chunk)

        assert len(chunks) == 1
        assert "disconnected" in chunks[0].lower()

    @pytest.mark.asyncio
    async def test_execute_streaming_error(self) -> None:
        client = _mock_client()

        async def _fail_stream(name, args):
            raise ConnectionError("lost")
            yield  # make it a generator

        client.call_tool_streaming = _fail_stream

        adapter = MCPToolAdapter(_desc(), client, streaming=True, server_name="icm")

        chunks: list[str] = []
        async for chunk in adapter.execute_streaming():
            chunks.append(chunk)

        assert len(chunks) == 1
        assert "failed" in chunks[0].lower()
