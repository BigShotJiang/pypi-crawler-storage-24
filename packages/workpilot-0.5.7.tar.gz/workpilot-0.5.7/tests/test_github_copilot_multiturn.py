"""
Multi-turn tool call integration tests for GitHub Copilot models.

Tests a realistic agentic loop:
  1. User asks a question requiring tool use
  2. Model returns tool_calls with arguments
  3. We execute the tool and return results
  4. Model produces a final answer based on results

Run: pytest tests/test_github_copilot_multiturn.py -v -s
"""

from __future__ import annotations

import json
import os
from typing import Any

import pytest
from pydantic import SecretStr

from workpilot.config.schema import GitHubCopilotConfig, ProvidersConfig
from workpilot.providers.client import OpenAIProvider

# ---------------------------------------------------------------------------
# Token setup
# ---------------------------------------------------------------------------

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")
if not GITHUB_TOKEN:
    try:
        import yaml  # type: ignore

        for path in ("workpilot.local.yaml", "../workpilot.local.yaml"):
            try:
                with open(path) as f:
                    _local = yaml.safe_load(f) or {}
                GITHUB_TOKEN = (
                    (_local.get("providers") or {}).get("github_copilot", {}).get("token", "")
                ) or ""
                break
            except FileNotFoundError:
                continue
    except Exception:
        pass

skip_live = pytest.mark.skipif(
    not GITHUB_TOKEN or os.environ.get("SKIP_LIVE_TESTS") == "1",
    reason="No GITHUB_TOKEN or SKIP_LIVE_TESTS=1",
)


def _provider() -> OpenAIProvider:
    return OpenAIProvider(
        ProvidersConfig(github_copilot=GitHubCopilotConfig(token=SecretStr(GITHUB_TOKEN)))
    )


# ---------------------------------------------------------------------------
# Tool definitions & executor
# ---------------------------------------------------------------------------

TOOLS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get current weather for a city",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {"type": "string", "description": "City name"},
                    "unit": {
                        "type": "string",
                        "enum": ["celsius", "fahrenheit"],
                        "description": "Temperature unit",
                    },
                },
                "required": ["city"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "calculate",
            "description": "Evaluate an arithmetic expression",
            "parameters": {
                "type": "object",
                "properties": {
                    "expression": {"type": "string", "description": "e.g. '(23 + 17) * 2'"},
                },
                "required": ["expression"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "lookup_person",
            "description": "Look up a person by name and return their details",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "fields": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Fields to return: age, role, department",
                    },
                },
                "required": ["name"],
            },
        },
    },
]


def _execute_tool(name: str, arguments: dict[str, Any]) -> str:
    """Fake tool executor — deterministic results for testing."""
    if name == "get_weather":
        city = arguments.get("city", "Unknown")
        unit = arguments.get("unit", "celsius")
        temp = 22 if unit == "celsius" else 72
        return json.dumps({"city": city, "temp": temp, "unit": unit, "condition": "sunny"})

    if name == "calculate":
        expr = arguments.get("expression", "0")
        try:
            result = eval(expr, {"__builtins__": {}})  # noqa: S307
        except Exception as e:
            result = f"error: {e}"
        return json.dumps({"expression": expr, "result": result})

    if name == "lookup_person":
        name_val = arguments.get("name", "")
        fields = arguments.get("fields", ["age", "role"])
        data: dict[str, Any] = {
            "name": name_val,
            "age": 35,
            "role": "Senior Engineer",
            "department": "Platform",
        }
        return json.dumps({f: data[f] for f in fields if f in data} | {"name": name_val})

    return json.dumps({"error": f"unknown tool: {name}"})


async def _run_multiturn(
    provider: OpenAIProvider,
    model: str,
    user_message: str,
    max_turns: int = 4,
    **kwargs: Any,
) -> dict[str, Any]:
    """Run a multi-turn tool loop. Returns a summary dict."""
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": "You are a helpful assistant. Use tools when needed."},
        {"role": "user", "content": user_message},
    ]
    turns: list[dict[str, Any]] = []

    for turn in range(max_turns):
        response = await provider.complete(
            model=model,
            messages=messages,
            tools=TOOLS,
            max_tokens=256,
            **kwargs,
        )
        turns.append(
            {
                "turn": turn + 1,
                "content": response.content,
                "tool_calls": [
                    {"name": tc.name, "args": tc.arguments} for tc in response.tool_calls
                ],
                "finish_reason": response.finish_reason,
                "reasoning": bool(response.reasoning_content),
            }
        )

        if not response.tool_calls:
            # Final answer reached
            break

        # Append assistant message with tool_calls
        messages.append(
            {
                "role": "assistant",
                "content": response.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": json.dumps(tc.arguments),
                        },
                    }
                    for tc in response.tool_calls
                ],
            }
        )

        # Execute each tool and append results
        for tc in response.tool_calls:
            result = _execute_tool(tc.name, tc.arguments)
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": result,
                }
            )

    return {
        "model": model,
        "turns": turns,
        "final_answer": turns[-1]["content"] if turns else "",
        "total_turns": len(turns),
    }


# ---------------------------------------------------------------------------
# Chat Completions models — multi-turn tests
# ---------------------------------------------------------------------------

_CHAT_MODELS = [
    "github/gpt-5.2",
    "github/gpt-5.1",
    "github/gpt-5-mini",
    "github/claude-sonnet-4.6",
    "github/claude-haiku-4.5",
    "github/claude-opus-4.6",
]

_RESPONSES_MODELS = [
    "github/gpt-5.4",
    "github/gpt-5.3-codex",
]


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", _CHAT_MODELS)
async def test_multiturn_weather_query(model: str) -> None:
    """Single tool call: get weather, then answer."""
    provider = _provider()
    result = await _run_multiturn(
        provider,
        model,
        "What's the weather like in Tokyo right now? Give me celsius.",
    )
    assert result["total_turns"] >= 2, f"{model}: expected at least 2 turns"
    tool_turn = result["turns"][0]
    assert tool_turn["tool_calls"], f"{model}: no tool call in turn 1"
    assert tool_turn["tool_calls"][0]["name"] == "get_weather"
    assert "tokyo" in str(tool_turn["tool_calls"][0]["args"]).lower()
    # Some reasoning models may return empty text after a single tool call —
    # the important thing is the tool was called and the conversation completed.
    _print_result(result)


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", _CHAT_MODELS)
async def test_multiturn_calculate_with_args(model: str) -> None:
    """Tool call with complex expression argument."""
    provider = _provider()
    result = await _run_multiturn(
        provider,
        model,
        "Calculate (144 / 12) + (7 * 8) and tell me the result.",
    )
    tool_turn = result["turns"][0]
    # Some smart models answer simple arithmetic directly without tool calls.
    # Accept either: tool was called, OR model gave a correct direct answer.
    if tool_turn["tool_calls"]:
        assert tool_turn["tool_calls"][0]["name"] == "calculate"
        args = tool_turn["tool_calls"][0]["args"]
        assert "expression" in args, f"{model}: missing expression arg"
        if result["final_answer"] and result["final_answer"].strip():
            assert "68" in result["final_answer"], (
                f"{model}: expected '68', got: {result['final_answer']!r}"
            )
    else:
        answer = result["final_answer"]
        assert answer, f"{model}: no tool call and no direct answer"
        assert "68" in answer, f"{model}: direct answer missing '68': {answer!r}"
    _print_result(result)


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", _CHAT_MODELS)
async def test_multiturn_lookup_with_fields(model: str) -> None:
    """Tool call with array parameter (fields)."""
    provider = _provider()
    result = await _run_multiturn(
        provider,
        model,
        "Look up Alice's role and department.",
    )
    tool_turn = result["turns"][0]
    assert tool_turn["tool_calls"], f"{model}: no tool call"
    tc = tool_turn["tool_calls"][0]
    assert tc["name"] == "lookup_person"
    assert "alice" in str(tc["args"].get("name", "")).lower()
    # fields should be an array
    fields = tc["args"].get("fields")
    if fields is not None:
        assert isinstance(fields, list), f"{model}: fields should be a list"
    assert result["final_answer"], f"{model}: empty final answer"
    _print_result(result)


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", _CHAT_MODELS)
async def test_multiturn_sequential_tools(model: str) -> None:
    """Two sequential tool calls in one conversation."""
    provider = _provider()
    result = await _run_multiturn(
        provider,
        model,
        "First calculate 15 * 4, then look up Bob's age. Give me both results in your answer.",
        max_turns=6,
    )
    _print_result(result)

    tool_names = [tc["name"] for turn in result["turns"] for tc in turn["tool_calls"]]
    assert len(tool_names) >= 2, f"{model}: expected >=2 tool calls, got {tool_names}"
    assert "calculate" in tool_names, f"{model}: missing calculate"
    assert "lookup_person" in tool_names, f"{model}: missing lookup_person"
    assert result["final_answer"], f"{model}: empty final answer"
    _print_result(result)


# ---------------------------------------------------------------------------
# Responses API models — multi-turn tests
# ---------------------------------------------------------------------------


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", _RESPONSES_MODELS)
async def test_responses_api_multiturn_weather(model: str) -> None:
    """Responses API model: single tool call with parameters."""
    provider = _provider()
    result = await _run_multiturn(
        provider,
        model,
        "What is the weather in Paris in fahrenheit?",
    )
    assert result["total_turns"] >= 2, f"{model}: expected >=2 turns"
    tool_turn = result["turns"][0]
    assert tool_turn["tool_calls"], f"{model}: no tool call"
    tc = tool_turn["tool_calls"][0]
    assert tc["name"] == "get_weather"
    assert "paris" in str(tc["args"].get("city", "")).lower()
    assert tc["args"].get("unit") == "fahrenheit"
    _print_result(result)


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", _RESPONSES_MODELS)
async def test_responses_api_multiturn_calculate(model: str) -> None:
    """Responses API model: calculate with expression argument."""
    provider = _provider()
    result = await _run_multiturn(
        provider,
        model,
        "What is (100 - 37) * 3?",
    )
    tool_turn = result["turns"][0]
    if tool_turn["tool_calls"]:
        assert tool_turn["tool_calls"][0]["name"] == "calculate"
        if result["final_answer"] and result["final_answer"].strip():
            assert "189" in result["final_answer"], (
                f"{model}: expected '189', got: {result['final_answer']!r}"
            )
    else:
        answer = result["final_answer"]
        assert answer, f"{model}: no tool call and no direct answer"
        assert "189" in answer, f"{model}: direct answer missing '189': {answer!r}"
    _print_result(result)


# ---------------------------------------------------------------------------
# Reasoning effort test (gpt-5.4 specific)
# ---------------------------------------------------------------------------


@skip_live
@pytest.mark.asyncio
async def test_gpt54_reasoning_effort_tool_call() -> None:
    """gpt-5.4 with reasoning_effort=low: tool call should still work,
    reasoning_content may be populated."""
    provider = _provider()
    result = await _run_multiturn(
        provider,
        "github/gpt-5.4",
        "Calculate the sum of the first 10 prime numbers.",
        reasoning_effort="low",
    )
    turns = result["turns"]
    tool_names = [tc["name"] for t in turns for tc in t["tool_calls"]]
    # With reasoning_effort=low, gpt-5.4 may compute prime sums directly.
    # Accept either: tool used, OR correct answer given directly.
    if tool_names:
        assert "calculate" in tool_names, f"unexpected tool: {tool_names}"
    else:
        assert result["final_answer"], "no tool call and no direct answer"
    _print_result(result)


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _safe(text: str, limit: int = 120) -> str:
    """Truncate and encode to ASCII for Windows cp1252 console safety."""
    return text[:limit].replace("\n", " ").encode("ascii", "replace").decode("ascii")


def _print_result(result: dict[str, Any]) -> None:
    print(f"\n{'-' * 60}")
    print(f"Model: {result['model']}  ({result['total_turns']} turns)")
    for t in result["turns"]:
        tools = [f"{tc['name']}({tc['args']})" for tc in t["tool_calls"]]
        reasoning = " [reasoning]" if t["reasoning"] else ""
        print(f"  Turn {t['turn']}: tools={tools or '-'}  finish={t['finish_reason']}{reasoning}")
        if t["content"]:
            print(f"    -> {_safe(t['content'])}")
    print(f"  Final: {_safe(result['final_answer'], 200)!r}")
