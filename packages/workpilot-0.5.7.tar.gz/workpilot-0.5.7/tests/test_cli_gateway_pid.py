"""Tests for _check_gateway_running() and helpers in workpilot.cli.commands."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from workpilot.cli.commands import (
    _check_gateway_running,
    _is_port_listening,
)

# ── _is_port_listening ────────────────────────────────────────────────────────


def test_is_port_listening_true() -> None:
    with patch("socket.create_connection") as mock_conn:
        mock_conn.return_value.__enter__ = MagicMock(return_value=None)
        mock_conn.return_value.__exit__ = MagicMock(return_value=False)
        assert _is_port_listening(3003) is True


def test_is_port_listening_false() -> None:
    with patch("socket.create_connection", side_effect=OSError):
        assert _is_port_listening(3003) is False


# ── _check_gateway_running: file-not-found / corrupt ─────────────────────────


def test_no_pid_file(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr(
        "workpilot.cli.commands._gateway_pid_file", lambda: tmp_path / "gateway.pid"
    )
    assert _check_gateway_running() is None


def test_corrupt_pid_file(tmp_path, monkeypatch) -> None:
    pid_file = tmp_path / "gateway.pid"
    pid_file.write_text("not json", encoding="utf-8")
    monkeypatch.setattr("workpilot.cli.commands._gateway_pid_file", lambda: pid_file)
    assert _check_gateway_running() is None
    assert not pid_file.exists()


# ── _check_gateway_running: invalid pid/port values ──────────────────────────


@pytest.mark.parametrize(
    "pid, port",
    [
        (-1, 3003),  # negative pid — os.kill(-1,0) signals all processes on POSIX
        (0, 3003),  # pid=0 is invalid
        (1234, 0),  # port=0
        (1234, 65536),  # port out of range
        (1234, -1),  # port negative
    ],
)
def test_invalid_pid_or_port_cleans_up(tmp_path, monkeypatch, pid, port) -> None:
    pid_file = tmp_path / "gateway.pid"
    pid_file.write_text(json.dumps({"pid": pid, "port": port}), encoding="utf-8")
    monkeypatch.setattr("workpilot.cli.commands._gateway_pid_file", lambda: pid_file)
    assert _check_gateway_running() is None
    assert not pid_file.exists()


# ── _check_gateway_running: port not listening → stale ───────────────────────


def test_port_not_listening_removes_pid_file(tmp_path, monkeypatch) -> None:
    pid_file = tmp_path / "gateway.pid"
    pid_file.write_text(json.dumps({"pid": 9999, "port": 3003}), encoding="utf-8")
    monkeypatch.setattr("workpilot.cli.commands._gateway_pid_file", lambda: pid_file)
    with patch("workpilot.cli.commands._is_port_listening", return_value=False):
        assert _check_gateway_running() is None
    assert not pid_file.exists()


# ── _check_gateway_running: port listening, process alive ────────────────────


def test_gateway_running_returns_pid_and_port(tmp_path, monkeypatch) -> None:
    pid_file = tmp_path / "gateway.pid"
    pid_file.write_text(json.dumps({"pid": 1234, "port": 3003}), encoding="utf-8")
    monkeypatch.setattr("workpilot.cli.commands._gateway_pid_file", lambda: pid_file)
    with (
        patch("workpilot.cli.commands._is_port_listening", return_value=True),
        patch("os.kill"),  # no-op: process alive
    ):
        result = _check_gateway_running()
    assert result == (1234, 3003)


def test_process_gone_removes_pid_file(tmp_path, monkeypatch) -> None:
    pid_file = tmp_path / "gateway.pid"
    pid_file.write_text(json.dumps({"pid": 1234, "port": 3003}), encoding="utf-8")
    monkeypatch.setattr("workpilot.cli.commands._gateway_pid_file", lambda: pid_file)
    with (
        patch("workpilot.cli.commands._is_port_listening", return_value=True),
        patch("os.kill", side_effect=ProcessLookupError),
    ):
        assert _check_gateway_running() is None
    assert not pid_file.exists()


# ── _check_gateway_running: Windows PermissionError + tasklist ───────────────


def test_windows_tasklist_python_process_returns_running(tmp_path, monkeypatch) -> None:
    pid_file = tmp_path / "gateway.pid"
    pid_file.write_text(json.dumps({"pid": 1234, "port": 3003}), encoding="utf-8")
    monkeypatch.setattr("workpilot.cli.commands._gateway_pid_file", lambda: pid_file)
    mock_result = MagicMock()
    mock_result.stdout = '"python.exe","1234","Console","1","50,000 K"'
    with (
        patch("workpilot.cli.commands._is_port_listening", return_value=True),
        patch("os.kill", side_effect=PermissionError),
        patch("os.name", "nt"),
        patch("subprocess.run", return_value=mock_result),
    ):
        result = _check_gateway_running()
    assert result == (1234, 3003)


def test_windows_tasklist_non_python_removes_pid_file(tmp_path, monkeypatch) -> None:
    pid_file = tmp_path / "gateway.pid"
    pid_file.write_text(json.dumps({"pid": 1234, "port": 3003}), encoding="utf-8")
    monkeypatch.setattr("workpilot.cli.commands._gateway_pid_file", lambda: pid_file)
    mock_result = MagicMock()
    mock_result.stdout = '"notepad.exe","1234","Console","1","10,000 K"'
    with (
        patch("workpilot.cli.commands._is_port_listening", return_value=True),
        patch("os.kill", side_effect=PermissionError),
        patch("os.name", "nt"),
        patch("subprocess.run", return_value=mock_result),
    ):
        assert _check_gateway_running() is None
    assert not pid_file.exists()


def test_windows_tasklist_failure_removes_pid_file(tmp_path, monkeypatch) -> None:
    pid_file = tmp_path / "gateway.pid"
    pid_file.write_text(json.dumps({"pid": 1234, "port": 3003}), encoding="utf-8")
    monkeypatch.setattr("workpilot.cli.commands._gateway_pid_file", lambda: pid_file)
    with (
        patch("workpilot.cli.commands._is_port_listening", return_value=True),
        patch("os.kill", side_effect=PermissionError),
        patch("os.name", "nt"),
        patch("subprocess.run", side_effect=Exception("tasklist failed")),
    ):
        assert _check_gateway_running() is None
    assert not pid_file.exists()
