"""Tests for tool progress streaming — issue #47."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.agent.tools.registry import ToolRegistry
from workpilot.agent.tools.shell import ShellTool
from workpilot.bus.events import StreamingChunk
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import FileSystemConfig, ShellConfig
from workpilot.security.sandbox import Sandbox

# ── Helpers ──────────────────────────────────────────────────────────────────


class StreamingMockTool(Tool):
    """A mock tool that opts into streaming and calls _progress."""

    @property
    def name(self) -> str:
        return "streaming_mock"

    @property
    def description(self) -> str:
        return "A mock streaming tool"

    @property
    def parameters(self) -> dict[str, Any]:
        return {"type": "object", "properties": {"input": {"type": "string"}}}

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(streaming=True)

    async def execute(self, **kwargs: Any) -> str:
        if self._progress:
            await self._progress("step 1\n")
            await self._progress("step 2\n")
        return "done"


class NonStreamingMockTool(Tool):
    """A mock tool that does NOT opt into streaming."""

    @property
    def name(self) -> str:
        return "nonstreaming_mock"

    @property
    def description(self) -> str:
        return "A non-streaming mock tool"

    @property
    def parameters(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}}

    async def execute(self, **kwargs: Any) -> str:
        return "result"


@pytest.fixture
def sandbox(tmp_path: Path) -> Sandbox:
    return Sandbox(
        tmp_path,
        shell_config=ShellConfig(timeout=5),
        fs_config=FileSystemConfig(restrict_to_workspace=True),
    )


# ── Tests ────────────────────────────────────────────────────────────────────


class TestProgressCallbackInjection:
    """Test that set_progress_callback works correctly on the Tool ABC."""

    def test_default_progress_is_none(self):
        tool = StreamingMockTool()
        assert tool._progress is None

    def test_set_and_clear_callback(self):
        tool = StreamingMockTool()

        async def dummy(text: str) -> None:
            pass

        tool.set_progress_callback(dummy)
        assert tool._progress is dummy
        tool.set_progress_callback(None)
        assert tool._progress is None


class TestStreamingChunkEmission:
    """Test that the registry emits StreamingChunk(chunk_type='tool_progress') via the bus."""

    @pytest.mark.asyncio
    async def test_streaming_tool_emits_chunks(self):
        bus = MessageBus()
        chunks: list[StreamingChunk] = []

        async def capture(msg: Any) -> None:
            if isinstance(msg, StreamingChunk):
                chunks.append(msg)

        bus.on_outbound(capture)

        registry = ToolRegistry()
        registry.register(StreamingMockTool())

        result = await registry.execute(
            "streaming_mock",
            {"input": "test"},
            bus=bus,
            channel="test_channel",
            channel_id="test_id",
        )

        assert result == "done"
        assert len(chunks) == 2
        assert chunks[0].content == "step 1\n"
        assert chunks[0].chunk_type == "tool_progress"
        assert chunks[0].channel == "test_channel"
        assert chunks[0].channel_id == "test_id"
        assert chunks[1].content == "step 2\n"

    @pytest.mark.asyncio
    async def test_callback_cleared_after_execution(self):
        bus = MessageBus()
        registry = ToolRegistry()
        tool = StreamingMockTool()
        registry.register(tool)

        await registry.execute(
            "streaming_mock",
            {},
            bus=bus,
            channel="ch",
            channel_id="cid",
        )

        # Callback should be cleared after execution
        assert tool._progress is None

    @pytest.mark.asyncio
    async def test_no_chunks_without_bus(self):
        """When no bus/channel is provided, streaming tools still work normally."""
        registry = ToolRegistry()
        tool = StreamingMockTool()
        registry.register(tool)

        result = await registry.execute("streaming_mock", {"input": "test"})
        assert result == "done"
        assert tool._progress is None


class TestNonStreamingToolUnaffected:
    """Non-streaming tools should not receive a progress callback."""

    @pytest.mark.asyncio
    async def test_non_streaming_no_callback(self):
        bus = MessageBus()
        chunks: list[StreamingChunk] = []

        async def capture(msg: Any) -> None:
            if isinstance(msg, StreamingChunk):
                chunks.append(msg)

        bus.on_outbound(capture)

        registry = ToolRegistry()
        tool = NonStreamingMockTool()
        registry.register(tool)

        result = await registry.execute(
            "nonstreaming_mock",
            {},
            bus=bus,
            channel="ch",
            channel_id="cid",
        )

        assert result == "result"
        assert len(chunks) == 0
        assert tool._progress is None


class TestShellToolStreaming:
    """Test ShellTool line-by-line progress streaming."""

    @pytest.mark.asyncio
    async def test_shell_streams_stdout_lines(self, sandbox: Sandbox):
        bus = MessageBus()
        chunks: list[StreamingChunk] = []

        async def capture(msg: Any) -> None:
            if isinstance(msg, StreamingChunk):
                chunks.append(msg)

        bus.on_outbound(capture)

        registry = ToolRegistry()
        tool = ShellTool(sandbox)
        registry.register(tool)

        result = await registry.execute(
            "shell",
            {"command": "echo line1 && echo line2 && echo line3"},
            bus=bus,
            channel="test",
            channel_id="tid",
        )

        # All three lines should be in the final result
        assert "line1" in result
        assert "line2" in result
        assert "line3" in result

        # Progress chunks should have been emitted for each line
        assert len(chunks) >= 3
        progress_text = "".join(c.content for c in chunks)
        assert "line1" in progress_text
        assert "line2" in progress_text
        assert "line3" in progress_text
        # All chunks should be tool_progress type
        assert all(c.chunk_type == "tool_progress" for c in chunks)

    @pytest.mark.asyncio
    async def test_shell_works_without_streaming(self, sandbox: Sandbox):
        """Shell tool still works normally without bus (backward compat)."""
        registry = ToolRegistry()
        tool = ShellTool(sandbox)
        registry.register(tool)

        result = await registry.execute("shell", {"command": "echo hello"})
        assert "hello" in result

    @pytest.mark.asyncio
    async def test_shell_metadata_streaming_flag(self, sandbox: Sandbox):
        tool = ShellTool(sandbox)
        assert tool.metadata.streaming is True
