"""Tests for MCP namespace prefixing, per-server config, and approval resolution."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, PropertyMock

import pytest

from workpilot.agent.tools.registry import ToolRegistry
from workpilot.config.schema import MCPServerConfig
from workpilot.mcp.adapter import (
    MCPToolAdapter,
    register_mcp_tools,
    resolve_approval,
)


def _desc(name: str = "get_incident", description: str = "Get incident") -> dict[str, Any]:
    return {
        "name": name,
        "description": description,
        "inputSchema": {"type": "object", "properties": {}},
    }


def _mock_client(
    name: str = "test-server",
    connected: bool = True,
    tools: list[dict[str, Any]] | None = None,
) -> AsyncMock:
    client = AsyncMock()
    type(client).name = PropertyMock(return_value=name)
    type(client).is_connected = PropertyMock(return_value=connected)
    client.list_tools = AsyncMock(return_value=tools or [])
    client.call_tool = AsyncMock(return_value="result")
    return client


# ── Namespace Prefixing ──────────────────────────────────────────────────────


class TestNamespacePrefixing:
    def test_adapter_with_server_name(self) -> None:
        adapter = MCPToolAdapter(_desc("get_incident"), _mock_client(), server_name="icm")
        assert adapter.name == "MCP_icm_get_incident"

    def test_adapter_without_server_name(self) -> None:
        adapter = MCPToolAdapter(_desc("get_incident"), _mock_client())
        assert adapter.name == "get_incident"

    def test_description_prefixed(self) -> None:
        adapter = MCPToolAdapter(
            _desc(description="Get incident"), _mock_client(), server_name="icm"
        )
        assert adapter.description == "[MCP:icm] Get incident"

    def test_description_not_prefixed_without_server(self) -> None:
        adapter = MCPToolAdapter(_desc(description="Get incident"), _mock_client())
        assert adapter.description == "Get incident"

    @pytest.mark.asyncio
    async def test_execute_uses_raw_name(self) -> None:
        """MCP call_tool should use the un-prefixed name."""
        client = _mock_client()
        adapter = MCPToolAdapter(_desc("get_incident"), client, server_name="icm")
        await adapter.execute()
        client.call_tool.assert_awaited_once_with("get_incident", {})

    def test_openai_schema_uses_namespaced_name(self) -> None:
        adapter = MCPToolAdapter(_desc("get_incident"), _mock_client(), server_name="icm")
        schema = adapter.to_openai_schema()
        assert schema["function"]["name"] == "MCP_icm_get_incident"

    @pytest.mark.asyncio
    async def test_register_with_namespace(self) -> None:
        tools = [_desc("get_incident"), _desc("list_incidents")]
        client = _mock_client(tools=tools)
        registry = ToolRegistry()

        registered = await register_mcp_tools(registry, client, server_name="icm")

        assert registered == ["MCP_icm_get_incident", "MCP_icm_list_incidents"]
        assert registry.get("MCP_icm_get_incident") is not None
        assert registry.get("get_incident") is None  # raw name not registered

    @pytest.mark.asyncio
    async def test_register_without_namespace_backward_compat(self) -> None:
        tools = [_desc("get_incident")]
        client = _mock_client(tools=tools)
        registry = ToolRegistry()

        registered = await register_mcp_tools(registry, client)

        assert registered == ["get_incident"]

    @pytest.mark.asyncio
    async def test_namespace_eliminates_cross_server_collision(self) -> None:
        """Two servers both expose 'search' — no collision with namespacing."""
        client_a = _mock_client(name="icm", tools=[_desc("search")])
        client_b = _mock_client(name="kusto", tools=[_desc("search")])
        registry = ToolRegistry()

        reg_a = await register_mcp_tools(registry, client_a, server_name="icm")
        reg_b = await register_mcp_tools(registry, client_b, server_name="kusto")

        assert reg_a == ["MCP_icm_search"]
        assert reg_b == ["MCP_kusto_search"]
        assert registry.get("MCP_icm_search") is not None
        assert registry.get("MCP_kusto_search") is not None

    @pytest.mark.asyncio
    async def test_namespaced_tools_skip_protected_check(self) -> None:
        """With namespace, even 'shell' is OK since it becomes 'icm.shell'."""
        tools = [_desc("shell")]
        client = _mock_client(tools=tools)
        registry = ToolRegistry()

        registered = await register_mcp_tools(registry, client, server_name="icm")

        assert registered == ["MCP_icm_shell"]


# ── unregister_prefix ────────────────────────────────────────────────────────


class TestUnregisterPrefix:
    def test_removes_matching_tools(self) -> None:
        registry = ToolRegistry()
        for name in ["MCP_icm_get", "MCP_icm_list", "MCP_kusto_query", "shell"]:
            adapter = MCPToolAdapter(_desc(name), _mock_client())
            registry.register(adapter)

        removed = registry.unregister_prefix("MCP_icm_")
        assert sorted(removed) == ["MCP_icm_get", "MCP_icm_list"]
        assert registry.get("MCP_icm_get") is None
        assert registry.get("MCP_kusto_query") is not None
        assert registry.get("shell") is not None

    def test_no_match_returns_empty(self) -> None:
        registry = ToolRegistry()
        removed = registry.unregister_prefix("nonexistent.")
        assert removed == []


# ── Per-Server Config ────────────────────────────────────────────────────────


class TestPerServerConfig:
    def test_agency_default_timeout(self) -> None:
        cfg = MCPServerConfig(command="agency", args=["mcp", "icm"])
        adapter = MCPToolAdapter(
            _desc(), _mock_client(), server_name="icm", timeout=cfg.timeout or 60
        )
        assert adapter.metadata.timeout == 60

    def test_explicit_timeout_override(self) -> None:
        adapter = MCPToolAdapter(_desc(), _mock_client(), server_name="icm", timeout=120)
        assert adapter.metadata.timeout == 120

    def test_risk_level_override(self) -> None:
        adapter = MCPToolAdapter(_desc(), _mock_client(), server_name="icm", risk_level="high")
        assert adapter.metadata.risk_level == "high"

    @pytest.mark.asyncio
    async def test_register_with_server_config(self) -> None:
        cfg = MCPServerConfig(command="agency", args=["mcp", "icm"], timeout=90, risk_level="high")
        tools = [_desc("get_incident")]
        client = _mock_client(tools=tools)
        registry = ToolRegistry()

        registered = await register_mcp_tools(
            registry, client, server_name="icm", server_config=cfg
        )

        assert registered == ["MCP_icm_get_incident"]
        tool = registry.get("MCP_icm_get_incident")
        assert tool is not None
        assert tool.metadata.timeout == 90
        assert tool.metadata.risk_level == "high"


# ── Approval Resolution ─────────────────────────────────────────────────────


class TestApprovalResolution:
    def test_default_profile_returns_auto(self) -> None:
        assert resolve_approval(None, "standard") == "auto"

    def test_restricted_profile_returns_always(self) -> None:
        assert resolve_approval(None, "restricted") == "always"

    def test_open_profile_returns_never(self) -> None:
        assert resolve_approval(None, "open") == "never"

    def test_server_can_tighten(self) -> None:
        assert resolve_approval("always", "standard") == "always"

    def test_server_cannot_relax(self) -> None:
        assert resolve_approval("never", "standard") == "auto"  # can't relax from auto

    def test_server_cannot_relax_restricted(self) -> None:
        assert resolve_approval("auto", "restricted") == "always"  # can't relax from always

    def test_server_auto_on_open(self) -> None:
        assert resolve_approval("auto", "open") == "auto"  # tightening from never

    def test_none_profile_defaults_to_standard(self) -> None:
        assert resolve_approval(None, None) == "auto"

    @pytest.mark.asyncio
    async def test_register_with_restricted_profile_and_server_config(self) -> None:
        """restricted profile + server approval=auto → always (can't relax)."""
        cfg = MCPServerConfig(command="agency", args=["mcp", "icm"], approval="auto")
        tools = [_desc("get_incident")]
        client = _mock_client(tools=tools)
        registry = ToolRegistry()

        await register_mcp_tools(
            registry, client, server_name="icm", server_config=cfg, security_profile="restricted"
        )

        tool = registry.get("MCP_icm_get_incident")
        assert tool is not None
        assert tool.metadata.approval == "always"
