"""Tests for MCP resources and prompts — MCPClient methods."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from workpilot.mcp.client import MCPClient

# ── MCPClient Resources ──────────────────────────────────────────────────────


class TestClientResources:
    @pytest.mark.asyncio
    async def test_list_resources_with_capability(self) -> None:
        """Client with resources capability calls resources/list."""
        client = MCPClient(command="echo", args=["test"], name="test")
        client._server_capabilities = {"resources": {}}
        client._transport = AsyncMock()  # mark as connected
        client._send_request = AsyncMock(
            return_value={
                "result": {
                    "resources": [
                        {"uri": "icm://schema", "name": "Schema"},
                    ],
                },
            }
        )

        resources = await client.list_resources()

        assert len(resources) == 1
        assert resources[0]["uri"] == "icm://schema"
        client._send_request.assert_awaited_once_with("resources/list", {})

    @pytest.mark.asyncio
    async def test_list_resources_without_capability(self) -> None:
        client = MCPClient(command="echo", args=["test"], name="test")
        client._server_capabilities = {"tools": {}}  # no resources
        client._transport = AsyncMock()

        resources = await client.list_resources()

        assert resources == []

    @pytest.mark.asyncio
    async def test_read_resource(self) -> None:
        client = MCPClient(command="echo", args=["test"], name="test")
        client._server_capabilities = {"resources": {}}
        client._transport = AsyncMock()
        client._send_request = AsyncMock(
            return_value={
                "result": {
                    "contents": [{"uri": "icm://schema", "text": '{"type": "object"}'}],
                },
            }
        )

        content = await client.read_resource("icm://schema")

        assert '{"type": "object"}' in content


# ── MCPClient Prompts (unit-level with mocked internals) ─────────────────────


class TestClientPrompts:
    @pytest.mark.asyncio
    async def test_list_prompts_with_capability(self) -> None:
        client = MCPClient(command="echo", args=["test"], name="test")
        client._server_capabilities = {"prompts": {}}
        client._transport = AsyncMock()
        client._send_request = AsyncMock(
            return_value={
                "result": {
                    "prompts": [
                        {"name": "triage", "description": "Triage checklist"},
                    ],
                },
            }
        )

        prompts = await client.list_prompts()

        assert len(prompts) == 1
        assert prompts[0]["name"] == "triage"

    @pytest.mark.asyncio
    async def test_list_prompts_without_capability(self) -> None:
        client = MCPClient(command="echo", args=["test"], name="test")
        client._server_capabilities = {"tools": {}}
        client._transport = AsyncMock()

        prompts = await client.list_prompts()

        assert prompts == []

    @pytest.mark.asyncio
    async def test_get_prompt(self) -> None:
        client = MCPClient(command="echo", args=["test"], name="test")
        client._server_capabilities = {"prompts": {}}
        client._transport = AsyncMock()
        client._send_request = AsyncMock(
            return_value={
                "result": {
                    "messages": [
                        {"role": "user", "content": {"type": "text", "text": "Triage sev2"}},
                    ],
                },
            }
        )

        result = await client.get_prompt("triage", {"severity": "2"})

        assert "Triage sev2" in result
        client._send_request.assert_awaited_once_with(
            "prompts/get", {"name": "triage", "arguments": {"severity": "2"}}
        )
