"""
Live integration tests for GitHub Copilot models.

Requires a valid GitHub token in workpilot.local.yaml or GITHUB_TOKEN env var.
Run:  pytest tests/test_github_copilot_live.py -v -s
Skip: set SKIP_LIVE_TESTS=1
"""

from __future__ import annotations

import os

import pytest
import pytest_asyncio  # noqa: F401
from pydantic import SecretStr

from workpilot.config.schema import GitHubCopilotConfig, ProvidersConfig
from workpilot.providers.client import OpenAIProvider, _should_prefer_responses_api

# ---------------------------------------------------------------------------
# Skip guard
# ---------------------------------------------------------------------------

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN") or ""

# Try to load from local yaml if no env var
if not GITHUB_TOKEN:
    try:
        import yaml  # type: ignore

        _local = {}
        for path in ("workpilot.local.yaml", "../workpilot.local.yaml"):
            try:
                with open(path) as f:
                    _local = yaml.safe_load(f) or {}
                break
            except FileNotFoundError:
                continue
        GITHUB_TOKEN = (
            (_local.get("providers") or {}).get("github_copilot", {}).get("token", "")
        ) or ""
    except Exception:
        pass

skip_live = pytest.mark.skipif(
    not GITHUB_TOKEN or os.environ.get("SKIP_LIVE_TESTS") == "1",
    reason="No GITHUB_TOKEN available or SKIP_LIVE_TESTS=1",
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SIMPLE_MESSAGES = [{"role": "user", "content": "Reply with exactly: OK"}]

TOOL_MESSAGES = [{"role": "user", "content": "What is 2+2? Use the calculate tool."}]

CALCULATE_TOOL = [
    {
        "type": "function",
        "function": {
            "name": "calculate",
            "description": "Evaluate a simple arithmetic expression",
            "parameters": {
                "type": "object",
                "properties": {"expression": {"type": "string"}},
                "required": ["expression"],
            },
        },
    }
]


def _make_provider() -> OpenAIProvider:
    providers = ProvidersConfig(github_copilot=GitHubCopilotConfig(token=SecretStr(GITHUB_TOKEN)))
    return OpenAIProvider(providers)


# ---------------------------------------------------------------------------
# Routing sanity checks (no network)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "model,expect_responses_api",
    [
        # GitHub Copilot — Chat Completions models
        ("github/gpt-5.1", False),
        ("github/gpt-5.2", False),
        ("github/gpt-5-mini", False),
        ("github/claude-sonnet-4.6", False),
        ("github/claude-haiku-4.5", False),
        ("github/claude-opus-4.6", False),
        # GitHub Copilot — Responses API only (codex, pro, and gpt-5.4)
        # gpt-5.4 GA on Copilot 2026-03-05; Copilot endpoint rejects /chat/completions
        ("github/gpt-5.4", True),
        ("github_copilot/gpt-5.4", True),  # LiteLLM-style prefix also handled
        ("github/gpt-5.3-codex", True),
        ("github/gpt-5.1-codex-max", True),
        # OpenAI direct — gpt-5.4 uses Chat Completions (different from Copilot behaviour)
        ("openai/gpt-5.4", False),
        ("openai/gpt-5.4-pro", True),
        ("openai/gpt-5.2-pro", True),
        ("openai/gpt-5.2-codex", True),
    ],
)
def test_routing_classification(model: str, expect_responses_api: bool) -> None:
    """Verify Chat Completions vs Responses API routing without network calls."""
    result = _should_prefer_responses_api(model)
    assert result is expect_responses_api, (
        f"{model!r}: expected responses_api={expect_responses_api}, got {result}"
    )


# ---------------------------------------------------------------------------
# Chat Completions models
# ---------------------------------------------------------------------------

_CHAT_MODELS = [
    "github/gpt-5.2",
    "github/gpt-5.1",
    # gpt-5.4 is in _CODEX_MODELS (Responses API) for live tests
    "github/gpt-5-mini",
    "github/claude-sonnet-4.6",
    "github/claude-haiku-4.5",
    "github/claude-opus-4.6",
]


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", _CHAT_MODELS)
async def test_chat_completion_simple(model: str) -> None:
    """Each Chat Completions model returns a non-empty content response."""
    provider = _make_provider()
    response = await provider.complete(
        model=model,
        messages=SIMPLE_MESSAGES,
        max_tokens=16,
    )
    print(f"\n{model}: {response.content!r}  [{response.finish_reason}]")
    assert response.content, f"{model}: empty content"
    assert response.finish_reason in ("stop", "length")
    assert response.prompt_tokens > 0
    assert response.completion_tokens > 0


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", _CHAT_MODELS)
async def test_chat_completion_tool_call(model: str) -> None:
    """Each Chat Completions model issues a tool call when given a tool."""
    provider = _make_provider()
    response = await provider.complete(
        model=model,
        messages=TOOL_MESSAGES,
        tools=CALCULATE_TOOL,
        max_tokens=64,
    )
    print(
        f"\n{model}: content={response.content!r}  "
        f"tool_calls={[tc.name for tc in response.tool_calls]}"
    )
    assert response.tool_calls, f"{model}: expected at least one tool call"
    assert response.tool_calls[0].name == "calculate"
    assert response.finish_reason == "tool_calls"


@skip_live
@pytest.mark.asyncio
async def test_gpt54_multi_choice_preamble_captured() -> None:
    """gpt-5.4 via Responses API may return preamble text alongside tool_calls
    as separate output items — verify both are captured correctly."""
    provider = _make_provider()
    response = await provider.complete(
        model="github/gpt-5.4",
        messages=TOOL_MESSAGES,
        tools=CALCULATE_TOOL,
        max_tokens=128,
    )
    print(
        f"\ngpt-5.4 preamble: {response.content!r}\n"
        f"tool_calls: {[tc.name for tc in response.tool_calls]}"
    )
    assert response.tool_calls, "gpt-5.4: tool_call missing"
    assert response.finish_reason == "tool_calls"


# ---------------------------------------------------------------------------
# Responses API (Codex) models
# ---------------------------------------------------------------------------

_RESPONSES_API_MODELS = [
    "github/gpt-5.4",  # GA 2026-03-05; Copilot endpoint is Responses API only
    "github/gpt-5.3-codex",
    "github/gpt-5.1-codex-max",
]


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", _RESPONSES_API_MODELS)
async def test_responses_api_simple(model: str) -> None:
    """gpt-5.4 and codex models route directly to Responses API and return
    a valid response (content or tool_calls). codex-max is an agentic model
    and may return empty content for simple chat prompts — that is acceptable."""
    provider = _make_provider()
    response = await provider.complete(
        model=model,
        messages=SIMPLE_MESSAGES,
        max_tokens=32,
    )
    print(f"\n{model}: {response.content!r}  [{response.finish_reason}]")
    # codex-max may return empty on non-coding prompts; just verify no exception
    assert response.finish_reason in ("stop", "length", "tool_calls"), (
        f"{model}: unexpected finish_reason {response.finish_reason!r}"
    )


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", _RESPONSES_API_MODELS)
async def test_responses_api_tool_call(model: str) -> None:
    """gpt-5.4 and codex models issue tool calls via the Responses API."""
    provider = _make_provider()
    response = await provider.complete(
        model=model,
        messages=TOOL_MESSAGES,
        tools=CALCULATE_TOOL,
        max_tokens=128,
    )
    print(
        f"\n{model}: content={response.content!r}  "
        f"tool_calls={[tc.name for tc in response.tool_calls]}"
    )
    assert response.tool_calls, f"{model}: expected tool call from Responses API"
    assert response.tool_calls[0].name == "calculate"
    assert response.finish_reason == "tool_calls"
