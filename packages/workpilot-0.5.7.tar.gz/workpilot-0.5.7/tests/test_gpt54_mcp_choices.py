"""
Focused validation: gpt-5.4 multi-choice MCP tool calls with parameters.

gpt-5.4 on GitHub Copilot uses Responses API. This test verifies:
1. Single tool call — args preserved
2. Parallel tool calls — both captured from Responses API output items
3. Tool call with nested/array params — no argument corruption
4. Multi-turn chain — call_id round-trips correctly
5. Content + tool_calls in same response — both captured
"""

from __future__ import annotations

import json
import os
from typing import Any

import pytest
from pydantic import SecretStr

from workpilot.config.schema import GitHubCopilotConfig, ProvidersConfig
from workpilot.providers.client import OpenAIProvider

# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")
if not GITHUB_TOKEN:
    try:
        import yaml  # type: ignore

        for path in ("workpilot.local.yaml", "../workpilot.local.yaml"):
            try:
                with open(path) as f:
                    _d = yaml.safe_load(f) or {}
                GITHUB_TOKEN = ((_d.get("providers") or {}).get("github_copilot") or {}).get(
                    "token", ""
                ) or ""
                if GITHUB_TOKEN:
                    break
            except FileNotFoundError:
                continue
    except Exception:
        pass

skip_live = pytest.mark.skipif(
    not GITHUB_TOKEN or os.environ.get("SKIP_LIVE_TESTS") == "1",
    reason="No GITHUB_TOKEN or SKIP_LIVE_TESTS=1",
)
MODEL = "github/gpt-5.4"


def _provider() -> OpenAIProvider:
    return OpenAIProvider(
        ProvidersConfig(github_copilot=GitHubCopilotConfig(token=SecretStr(GITHUB_TOKEN)))
    )


# ---------------------------------------------------------------------------
# MCP tools
# ---------------------------------------------------------------------------

TOOLS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "mcp__fs__read_file",
            "description": "Read a file",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "encoding": {"type": "string", "enum": ["utf-8", "latin-1"]},
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "mcp__fs__write_file",
            "description": "Write content to a file",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "content": {"type": "string"},
                    "create_dirs": {"type": "boolean"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "mcp__git__commit",
            "description": "Stage files and create a git commit",
            "parameters": {
                "type": "object",
                "properties": {
                    "message": {"type": "string"},
                    "files": {"type": "array", "items": {"type": "string"}},
                    "author": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "email": {"type": "string"},
                        },
                        "required": ["name", "email"],
                    },
                },
                "required": ["message", "files"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "mcp__search__grep",
            "description": "Search files for a pattern",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {"type": "string"},
                    "paths": {"type": "array", "items": {"type": "string"}},
                    "case_sensitive": {"type": "boolean", "default": True},
                    "max_results": {"type": "integer", "default": 50},
                },
                "required": ["pattern", "paths"],
            },
        },
    },
]


def _exec(name: str, args: dict[str, Any]) -> str:
    if name == "mcp__fs__read_file":
        return json.dumps({"content": f"# {args['path']}\nprint('hello')\n", "bytes": 28})
    if name == "mcp__fs__write_file":
        return json.dumps({"written": len(args.get("content", "")), "path": args["path"]})
    if name == "mcp__git__commit":
        return json.dumps({"sha": "a1b2c3d", "message": args["message"], "files": args["files"]})
    if name == "mcp__search__grep":
        return json.dumps(
            {
                "matches": [
                    {"file": args["paths"][0], "line": 5, "text": f"  {args['pattern']}()"},
                ],
                "total": 1,
            }
        )
    return json.dumps({"error": f"unknown: {name}"})


def _s(text: str, n: int = 200) -> str:
    return text[:n].encode("ascii", "replace").decode()


async def _loop(
    provider: OpenAIProvider,
    messages: list[dict[str, Any]],
    max_turns: int = 5,
) -> list[dict[str, Any]]:
    turns = []
    for _ in range(max_turns):
        r = await provider.complete(model=MODEL, messages=messages, tools=TOOLS, max_tokens=512)
        turn = {
            "tool_calls": [
                {"name": tc.name, "args": tc.arguments, "id": tc.id} for tc in r.tool_calls
            ],
            "content": r.content,
            "finish": r.finish_reason,
            "reasoning": bool(r.reasoning_content),
        }
        turns.append(turn)
        if not r.tool_calls:
            break
        messages.append(
            {
                "role": "assistant",
                "content": r.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.name, "arguments": json.dumps(tc.arguments)},
                    }
                    for tc in r.tool_calls
                ],
            }
        )
        for tc in r.tool_calls:
            messages.append(
                {"role": "tool", "tool_call_id": tc.id, "content": _exec(tc.name, tc.arguments)}
            )
    return turns


def _dump(label: str, turns: list[dict[str, Any]]) -> None:
    print(f"\n=== {label} ===")
    for i, t in enumerate(turns, 1):
        tools = [
            f"{c['name']}(id={c['id'][:8]}.. args={json.dumps(c['args'])[:100]})"
            for c in t["tool_calls"]
        ]
        flags = []
        if t["reasoning"]:
            flags.append("reasoning")
        print(f"  T{i}: finish={t['finish']}  {' '.join(flags)}")
        for tool in tools:
            print(f"       tool: {tool}")
        if t["content"]:
            print(f"       text: {_s(t['content'])}")


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@skip_live
@pytest.mark.asyncio
async def test_gpt54_single_tool_args_preserved() -> None:
    """Single tool call — path + encoding preserved exactly."""
    provider = _provider()
    turns = await _loop(
        provider,
        [
            {"role": "system", "content": "Use tools as requested."},
            {"role": "user", "content": "Read /workspace/config.py with latin-1 encoding."},
        ],
    )
    _dump("single tool: path+encoding", turns)

    calls = [c for t in turns for c in t["tool_calls"]]
    assert calls, "no tool call"
    tc = calls[0]
    assert tc["name"] == "mcp__fs__read_file"
    assert tc["args"].get("path") == "/workspace/config.py", f"path wrong: {tc['args']}"
    assert tc["args"].get("encoding") == "latin-1", f"encoding wrong: {tc['args']}"


@skip_live
@pytest.mark.asyncio
async def test_gpt54_parallel_tool_calls() -> None:
    """Parallel tool calls — both captured from Responses API output items."""
    provider = _provider()
    turns = await _loop(
        provider,
        [
            {"role": "system", "content": "Use tools. Call them in parallel when independent."},
            {"role": "user", "content": "Read /workspace/a.py and /workspace/b.py simultaneously."},
        ],
    )
    _dump("parallel reads", turns)

    calls = [c for t in turns for c in t["tool_calls"]]
    read_calls = [c for c in calls if c["name"] == "mcp__fs__read_file"]
    assert len(read_calls) >= 2, (
        f"expected >=2 read calls, got {len(read_calls)}: {[c['args'] for c in read_calls]}"
    )
    paths = {c["args"].get("path") for c in read_calls}
    assert any("a.py" in p for p in paths), f"a.py not found in paths: {paths}"
    assert any("b.py" in p for p in paths), f"b.py not found in paths: {paths}"
    # call IDs must be unique
    ids = [c["id"] for c in read_calls]
    assert len(set(ids)) == len(ids), f"duplicate call IDs: {ids}"


@skip_live
@pytest.mark.asyncio
async def test_gpt54_array_param_preserved() -> None:
    """Tool call with array 'files' and nested 'author' object."""
    provider = _provider()
    turns = await _loop(
        provider,
        [
            {"role": "system", "content": "Use tools as requested."},
            {
                "role": "user",
                "content": "Create a git commit with message 'fix: provider routing' "
                "staging files ['src/provider.py', 'tests/test_provider.py'], "
                "author name 'Alice' email 'alice@example.com'.",
            },
        ],
    )
    _dump("git commit (array + nested object)", turns)

    calls = [c for t in turns for c in t["tool_calls"]]
    commit_calls = [c for c in calls if c["name"] == "mcp__git__commit"]
    assert commit_calls, "no git commit call"
    args = commit_calls[0]["args"]

    assert "message" in args, "missing message"
    assert "fix" in args["message"].lower() or "provider" in args["message"].lower()

    files = args.get("files", [])
    assert isinstance(files, list), f"files should be list, got {type(files)}"
    assert len(files) >= 2, f"expected >=2 files, got {files}"
    files_str = " ".join(files)
    assert "provider.py" in files_str, f"provider.py missing: {files}"

    author = args.get("author")
    if author:
        assert isinstance(author, dict), "author should be dict"
        assert "alice" in str(author.get("name", "")).lower()
        assert "alice" in str(author.get("email", "")).lower()


@skip_live
@pytest.mark.asyncio
async def test_gpt54_array_paths_and_bool_param() -> None:
    """Tool call with array 'paths' and boolean 'case_sensitive'."""
    provider = _provider()
    turns = await _loop(
        provider,
        [
            {"role": "system", "content": "Use tools as requested."},
            {
                "role": "user",
                "content": "Search case-insensitively for 'TODO' in "
                "['/workspace/main.py', '/workspace/utils.py']. Limit to 20 results.",
            },
        ],
    )
    _dump("grep (array paths + bool + int)", turns)

    calls = [c for t in turns for c in t["tool_calls"]]
    grep_calls = [c for c in calls if c["name"] == "mcp__search__grep"]
    assert grep_calls, "no grep call"
    args = grep_calls[0]["args"]

    assert "TODO" in args.get("pattern", "").upper()
    paths = args.get("paths", [])
    assert isinstance(paths, list), "paths should be list"
    assert len(paths) >= 2, f"expected >=2 paths: {paths}"
    # case_sensitive should be False (asked case-insensitively)
    cs = args.get("case_sensitive")
    assert cs is False or cs is None, f"expected case_sensitive=False, got {cs!r}"
    # max_results
    mr = args.get("max_results")
    if mr is not None:
        assert mr == 20, f"expected max_results=20, got {mr}"


@skip_live
@pytest.mark.asyncio
async def test_gpt54_multiturn_callid_roundtrip() -> None:
    """Multi-turn: call_id from response round-trips correctly in tool result."""
    provider = _provider()
    turns = await _loop(
        provider,
        [
            {"role": "system", "content": "Use tools step by step."},
            {
                "role": "user",
                "content": "Search for 'def test_' in /workspace/tests/test_provider.py, "
                "then read that file.",
            },
        ],
        max_turns=6,
    )
    _dump("multiturn call_id round-trip", turns)

    all_calls = [c for t in turns for c in t["tool_calls"]]
    names = [c["name"] for c in all_calls]
    assert "mcp__search__grep" in names, "missing grep"
    assert "mcp__fs__read_file" in names, "missing read_file"
    assert len(turns) >= 2, f"expected >=2 turns, got {len(turns)}"


@skip_live
@pytest.mark.asyncio
async def test_gpt54_content_and_toolcalls_captured() -> None:
    """Responses API may emit a text item alongside tool call items.
    Verify both content and tool_calls are captured from the output array."""
    provider = _provider()
    turns = await _loop(
        provider,
        [
            {"role": "system", "content": "Think aloud before using tools."},
            {"role": "user", "content": "Read /workspace/main.py and summarize what it does."},
        ],
    )
    _dump("content + tool_calls", turns)

    # Turn 1: must have at least a tool call
    t1 = turns[0]
    assert t1["tool_calls"], "T1: no tool call"
    assert t1["tool_calls"][0]["name"] == "mcp__fs__read_file"

    # Final turn: must have a summary answer
    final = turns[-1]["content"]
    assert final, "no final answer"
    # Answer should reference the file or its content
    assert any(kw in final.lower() for kw in ["main.py", "hello", "print", "file", "workspace"]), (
        f"unexpected final answer: {_s(final)}"
    )
