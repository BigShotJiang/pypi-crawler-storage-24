"""Tests for GitHub OAuth Device Code Flow."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from workpilot.security.github_auth import (
    DEFAULT_CLIENT_ID,
    GitHubAuthError,
    github_device_login,
)


def _make_response(json_data: dict, status_code: int = 200) -> MagicMock:
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data
    resp.raise_for_status.return_value = None
    return resp


class TestGitHubDeviceLogin:
    """Tests for the github_device_login function."""

    @patch("workpilot.security.github_auth.time.sleep", return_value=None)
    @patch("workpilot.security.github_auth.httpx.Client")
    def test_happy_path(self, mock_client_cls: MagicMock, _mock_sleep: MagicMock) -> None:
        """Device code → poll → token received."""
        device_resp = _make_response(
            {
                "device_code": "dc_123",
                "user_code": "ABCD-1234",
                "verification_uri": "https://github.com/login/device",
                "expires_in": 900,
                "interval": 5,
            }
        )
        token_resp = _make_response(
            {
                "access_token": "gho_test_token_abc",
                "token_type": "bearer",
                "scope": "read:user",
            }
        )

        mock_http = MagicMock()
        mock_http.post.side_effect = [device_resp, token_resp]
        mock_http.__enter__ = MagicMock(return_value=mock_http)
        mock_http.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_http

        console = MagicMock()
        token = github_device_login(client_id="test-id", console=console)

        assert token == "gho_test_token_abc"

    @patch("workpilot.security.github_auth.time.sleep", return_value=None)
    @patch("workpilot.security.github_auth.httpx.Client")
    def test_authorization_pending_then_success(
        self,
        mock_client_cls: MagicMock,
        _mock_sleep: MagicMock,
    ) -> None:
        """Polls through authorization_pending before getting token."""
        device_resp = _make_response(
            {
                "device_code": "dc_456",
                "user_code": "EFGH-5678",
                "verification_uri": "https://github.com/login/device",
                "expires_in": 900,
                "interval": 5,
            }
        )
        pending_resp = _make_response({"error": "authorization_pending"})
        token_resp = _make_response(
            {
                "access_token": "gho_after_pending",
                "token_type": "bearer",
            }
        )

        mock_http = MagicMock()
        mock_http.post.side_effect = [device_resp, pending_resp, pending_resp, token_resp]
        mock_http.__enter__ = MagicMock(return_value=mock_http)
        mock_http.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_http

        token = github_device_login(client_id="test-id", console=MagicMock())
        assert token == "gho_after_pending"

    @patch("workpilot.security.github_auth.time.sleep", return_value=None)
    @patch("workpilot.security.github_auth.httpx.Client")
    def test_slow_down_increases_interval(
        self,
        mock_client_cls: MagicMock,
        mock_sleep: MagicMock,
    ) -> None:
        """slow_down response increases the polling interval."""
        device_resp = _make_response(
            {
                "device_code": "dc_789",
                "user_code": "IJKL-9012",
                "verification_uri": "https://github.com/login/device",
                "expires_in": 900,
                "interval": 5,
            }
        )
        slow_resp = _make_response({"error": "slow_down", "interval": 10})
        token_resp = _make_response(
            {
                "access_token": "gho_slow",
                "token_type": "bearer",
            }
        )

        mock_http = MagicMock()
        mock_http.post.side_effect = [device_resp, slow_resp, token_resp]
        mock_http.__enter__ = MagicMock(return_value=mock_http)
        mock_http.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_http

        token = github_device_login(client_id="test-id", console=MagicMock())
        assert token == "gho_slow"

        # First sleep is initial interval (5), second is increased (10)
        sleep_calls = [c.args[0] for c in mock_sleep.call_args_list]
        assert sleep_calls[0] == 5
        assert sleep_calls[1] == 10

    @patch("workpilot.security.github_auth.time.sleep", return_value=None)
    @patch("workpilot.security.github_auth.httpx.Client")
    def test_access_denied_raises(
        self,
        mock_client_cls: MagicMock,
        _mock_sleep: MagicMock,
    ) -> None:
        """access_denied terminates with GitHubAuthError."""
        device_resp = _make_response(
            {
                "device_code": "dc_denied",
                "user_code": "DENY-0000",
                "verification_uri": "https://github.com/login/device",
                "expires_in": 900,
                "interval": 5,
            }
        )
        denied_resp = _make_response(
            {
                "error": "access_denied",
                "error_description": "The user denied the request",
            }
        )

        mock_http = MagicMock()
        mock_http.post.side_effect = [device_resp, denied_resp]
        mock_http.__enter__ = MagicMock(return_value=mock_http)
        mock_http.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_http

        with pytest.raises(GitHubAuthError, match="user denied"):
            github_device_login(client_id="test-id", console=MagicMock())

    @patch("workpilot.security.github_auth.time.sleep", return_value=None)
    @patch("workpilot.security.github_auth.httpx.Client")
    def test_expired_token_raises(
        self,
        mock_client_cls: MagicMock,
        _mock_sleep: MagicMock,
    ) -> None:
        """expired_token terminates with GitHubAuthError."""
        device_resp = _make_response(
            {
                "device_code": "dc_expired",
                "user_code": "EXPR-0000",
                "verification_uri": "https://github.com/login/device",
                "expires_in": 900,
                "interval": 5,
            }
        )
        expired_resp = _make_response(
            {
                "error": "expired_token",
                "error_description": "The device code has expired",
            }
        )

        mock_http = MagicMock()
        mock_http.post.side_effect = [device_resp, expired_resp]
        mock_http.__enter__ = MagicMock(return_value=mock_http)
        mock_http.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_http

        with pytest.raises(GitHubAuthError, match="expired"):
            github_device_login(client_id="test-id", console=MagicMock())

    @patch("workpilot.security.github_auth.httpx.Client")
    def test_bad_device_code_response_raises(
        self,
        mock_client_cls: MagicMock,
    ) -> None:
        """Missing device_code in initial response raises."""
        bad_resp = _make_response({"error": "bad_client_id"})

        mock_http = MagicMock()
        mock_http.post.return_value = bad_resp
        mock_http.__enter__ = MagicMock(return_value=mock_http)
        mock_http.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_http

        with pytest.raises(GitHubAuthError, match="Failed to initiate"):
            github_device_login(client_id="bad-id", console=MagicMock())

    def test_default_client_id(self) -> None:
        """DEFAULT_CLIENT_ID matches the VS Code Copilot client ID."""
        assert DEFAULT_CLIENT_ID == "Iv1.b507a08c87ecfe98"
