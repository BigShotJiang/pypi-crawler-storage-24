"""Tests for OpenAI provider runtime fallback behavior."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

import pytest
from pydantic import SecretStr

from workpilot.config.schema import GitHubCopilotConfig, ProviderConfig, ProvidersConfig
from workpilot.providers.client import OpenAIProvider


class _FakeStream:
    def __init__(self, chunks):
        self._chunks = chunks

    def __aiter__(self):
        return self

    async def __anext__(self):
        if not self._chunks:
            raise StopAsyncIteration
        return self._chunks.pop(0)


class _FailingStream:
    def __aiter__(self):
        return self

    async def __anext__(self):
        raise RuntimeError("stream failed before first chunk")


@pytest.mark.asyncio
async def test_complete_falls_back_to_next_model_on_error():
    providers = ProvidersConfig(openai=ProviderConfig(api_key=SecretStr("sk-test")))
    provider = OpenAIProvider(providers)
    calls: list[str] = []

    class _FakeCompletions:
        async def create(self, **kwargs):
            model = kwargs["model"]
            calls.append(model)
            if model == "o1":
                raise RuntimeError("primary model failed")
            return SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(content="fallback ok", tool_calls=[]),
                        finish_reason="stop",
                    )
                ],
                usage=SimpleNamespace(prompt_tokens=3, completion_tokens=2),
                model=f"openai/{model}",
            )

    fake_client = SimpleNamespace(chat=SimpleNamespace(completions=_FakeCompletions()))

    with patch.object(OpenAIProvider, "_build_client", return_value=fake_client):
        response = await provider.complete(
            model="reasoning",
            messages=[{"role": "user", "content": "hello"}],
        )

    assert response.content == "fallback ok"
    assert response.model == "openai/gpt-4o"
    assert calls == ["o1", "gpt-4o"]


@pytest.mark.asyncio
async def test_stream_falls_back_when_stream_creation_fails():
    providers = ProvidersConfig(openai=ProviderConfig(api_key=SecretStr("sk-test")))
    provider = OpenAIProvider(providers)
    calls: list[str] = []

    class _FakeCompletions:
        async def create(self, **kwargs):
            model = kwargs["model"]
            calls.append(model)
            if model == "o1":
                raise RuntimeError("stream primary failed")
            chunk = SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        delta=SimpleNamespace(content="hi"),
                        finish_reason="stop",
                    )
                ],
                model=f"openai/{model}",
            )
            return _FakeStream([chunk])

    fake_client = SimpleNamespace(chat=SimpleNamespace(completions=_FakeCompletions()))

    with patch.object(OpenAIProvider, "_build_client", return_value=fake_client):
        chunks = []
        async for chunk in provider.stream(
            model="reasoning",
            messages=[{"role": "user", "content": "hello"}],
        ):
            chunks.append(chunk)

    assert [c.content for c in chunks] == ["hi"]
    assert chunks[0].model == "openai/gpt-4o"
    assert calls == ["o1", "gpt-4o"]


@pytest.mark.asyncio
async def test_github_gpt54_routes_directly_to_responses_api():
    """github/gpt-5.4 is in _GITHUB_COPILOT_RESPONSES_ONLY and must go directly
    to Responses API without attempting /chat/completions first."""
    providers = ProvidersConfig(
        github_copilot=GitHubCopilotConfig(token=SecretStr("")),
        openai=ProviderConfig(api_key=SecretStr("sk-test")),
    )
    provider = OpenAIProvider(providers)
    calls: list[tuple[str, str]] = []

    class _FakeResponses:
        async def create(self, **kwargs):
            calls.append(("responses", kwargs["model"]))
            return SimpleNamespace(
                model="github/gpt-5.4",
                output_text="ok via responses",
                output=[],
                usage=SimpleNamespace(input_tokens=2, output_tokens=3),
            )

    fake_client = SimpleNamespace(responses=_FakeResponses())

    with (
        patch(
            "workpilot.providers.client.resolve_credentials",
            return_value={"api_key": "test"},
        ),
        patch.object(OpenAIProvider, "_build_client", return_value=fake_client),
    ):
        response = await provider.complete(
            model="github/gpt-5.4",
            messages=[{"role": "user", "content": "hello"}],
        )

    assert response.content == "ok via responses"
    assert response.model == "github/gpt-5.4"
    assert calls == [("responses", "gpt-5.4")]


@pytest.mark.asyncio
async def test_auto_switches_to_responses_api_on_unsupported_error():
    """A chat-first model that gets rejected with unsupported_api_for_model
    falls back to the Responses API automatically."""
    providers = ProvidersConfig(openai=ProviderConfig(api_key=SecretStr("sk-test")))
    provider = OpenAIProvider(providers)
    calls: list[tuple[str, str]] = []

    class _FakeChatCompletions:
        async def create(self, **kwargs):
            calls.append(("chat", kwargs["model"]))
            raise RuntimeError(
                'Error code: 400 - {"error": {"message": "not accessible via the /chat/completions endpoint", "code": "unsupported_api_for_model"}}'
            )

    class _FakeResponses:
        async def create(self, **kwargs):
            calls.append(("responses", kwargs["model"]))
            return SimpleNamespace(
                model="openai/gpt-5.2",
                output_text="ok via responses",
                output=[],
                usage=SimpleNamespace(input_tokens=2, output_tokens=3),
            )

    fake_client = SimpleNamespace(
        chat=SimpleNamespace(completions=_FakeChatCompletions()),
        responses=_FakeResponses(),
    )

    with (
        patch(
            "workpilot.providers.client.resolve_credentials",
            return_value={"api_key": "test"},
        ),
        patch(
            "workpilot.providers.client.resolve_model_chain",
            return_value=["openai/gpt-5.2"],
        ),
        patch.object(OpenAIProvider, "_build_client", return_value=fake_client),
    ):
        response = await provider.complete(
            model="openai/gpt-5.2",
            messages=[{"role": "user", "content": "hello"}],
        )

    assert response.content == "ok via responses"
    assert calls == [("chat", "gpt-5.2"), ("responses", "gpt-5.2")]


@pytest.mark.asyncio
async def test_pro_and_codex_models_use_responses_api_directly():
    """gpt-5.4-pro and codex variants go directly to Responses API without
    attempting Chat Completions first."""
    providers = ProvidersConfig(openai=ProviderConfig(api_key=SecretStr("sk-test")))
    provider = OpenAIProvider(providers)
    calls: list[tuple[str, str]] = []

    class _FakeResponses:
        async def create(self, **kwargs):
            calls.append(("responses", kwargs["model"]))
            return SimpleNamespace(
                model=kwargs["model"],
                output_text="pro response",
                output=[],
                usage=SimpleNamespace(input_tokens=1, output_tokens=2),
            )

    fake_client = SimpleNamespace(responses=_FakeResponses())

    with (
        patch(
            "workpilot.providers.client.resolve_credentials",
            return_value={"api_key": "test"},
        ),
        patch.object(OpenAIProvider, "_build_client", return_value=fake_client),
    ):
        for model in ("openai/gpt-5.4-pro", "openai/gpt-5.1-codex", "openai/gpt-5.2-pro"):
            calls.clear()
            response = await provider.complete(
                model=model,
                messages=[{"role": "user", "content": "hello"}],
            )
            assert response.content == "pro response"
            assert len(calls) == 1 and calls[0][0] == "responses"


@pytest.mark.asyncio
async def test_responses_api_parses_function_calls_and_message_text():
    """Responses API output items (function_call + message) are parsed correctly.
    Uses gpt-5.4-pro which routes directly to /responses without trying chat first."""
    providers = ProvidersConfig(
        github_copilot=GitHubCopilotConfig(token=SecretStr("")),
        openai=ProviderConfig(api_key=SecretStr("sk-test")),
    )
    provider = OpenAIProvider(providers)

    function_call = SimpleNamespace(
        type="function_call",
        call_id="call_1",
        name="lookup_user",
        arguments='{"uid": "42"}',
    )
    message_part = SimpleNamespace(type="output_text", text="assistant text")
    message_item = SimpleNamespace(type="message", content=[message_part])

    class _FakeResponses:
        async def create(self, **kwargs):
            return SimpleNamespace(
                model="github/gpt-5.4-pro",
                output_text="",
                output=[function_call, message_item],
                usage=SimpleNamespace(input_tokens=9, output_tokens=4),
            )

    fake_client = SimpleNamespace(responses=_FakeResponses())

    with (
        patch(
            "workpilot.providers.client.resolve_credentials",
            return_value={"api_key": "test"},
        ),
        patch.object(OpenAIProvider, "_build_client", return_value=fake_client),
    ):
        response = await provider.complete(
            model="github/gpt-5.4-pro",
            messages=[{"role": "user", "content": "hello"}],
        )

    assert response.content == "assistant text"
    assert response.model == "github/gpt-5.4-pro"
    assert response.prompt_tokens == 9
    assert response.completion_tokens == 4
    assert len(response.tool_calls) == 1
    assert response.tool_calls[0].name == "lookup_user"
    assert response.tool_calls[0].arguments == {"uid": "42"}


@pytest.mark.asyncio
async def test_gpt54_multi_choice_preamble_and_tool_calls():
    """GPT-5.4 Chat Completions with reasoning active returns a preamble text in
    choices[0] (finish_reason='stop') and tool_calls in choices[1]
    (finish_reason='tool_calls'). Both must be captured."""
    providers = ProvidersConfig(openai=ProviderConfig(api_key=SecretStr("sk-test")))
    provider = OpenAIProvider(providers)

    class _FakeCompletions:
        async def create(self, **kwargs):
            return SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(
                            content="I'll look up the file first.",
                            tool_calls=None,
                        ),
                        finish_reason="stop",
                    ),
                    SimpleNamespace(
                        message=SimpleNamespace(
                            content=None,
                            tool_calls=[
                                SimpleNamespace(
                                    id="call_abc",
                                    function=SimpleNamespace(
                                        name="read_file",
                                        arguments='{"path": "main.py"}',
                                    ),
                                )
                            ],
                        ),
                        finish_reason="tool_calls",
                    ),
                ],
                usage=SimpleNamespace(prompt_tokens=10, completion_tokens=20),
                model="gpt-5.4",
            )

    fake_client = SimpleNamespace(chat=SimpleNamespace(completions=_FakeCompletions()))

    with (
        patch(
            "workpilot.providers.client.resolve_credentials",
            return_value={"api_key": "test"},
        ),
        patch(
            "workpilot.providers.client.resolve_model_chain",
            return_value=["openai/gpt-5.4"],
        ),
        patch.object(OpenAIProvider, "_build_client", return_value=fake_client),
    ):
        response = await provider.complete(
            model="openai/gpt-5.4",
            messages=[{"role": "user", "content": "read main.py"}],
        )

    assert response.content == "I'll look up the file first."
    assert response.finish_reason == "tool_calls"
    assert len(response.tool_calls) == 1
    assert response.tool_calls[0].name == "read_file"
    assert response.tool_calls[0].arguments == {"path": "main.py"}


@pytest.mark.asyncio
async def test_gpt5_uses_max_completion_tokens():
    """gpt-5.x family rejects max_tokens; the provider must send
    max_completion_tokens instead."""
    providers = ProvidersConfig(openai=ProviderConfig(api_key=SecretStr("sk-test")))
    provider = OpenAIProvider(providers)
    received_kwargs: dict = {}

    class _FakeCompletions:
        async def create(self, **kwargs):
            received_kwargs.update(kwargs)
            return SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(content="ok", tool_calls=None),
                        finish_reason="stop",
                    )
                ],
                usage=SimpleNamespace(prompt_tokens=1, completion_tokens=1),
                model="gpt-5.4",
            )

    fake_client = SimpleNamespace(chat=SimpleNamespace(completions=_FakeCompletions()))

    with (
        patch(
            "workpilot.providers.client.resolve_credentials",
            return_value={"api_key": "test"},
        ),
        patch(
            "workpilot.providers.client.resolve_model_chain",
            return_value=["openai/gpt-5.4"],
        ),
        patch.object(OpenAIProvider, "_build_client", return_value=fake_client),
    ):
        await provider.complete(
            model="openai/gpt-5.4",
            messages=[{"role": "user", "content": "hi"}],
            max_tokens=512,
        )

    assert "max_completion_tokens" in received_kwargs
    assert received_kwargs["max_completion_tokens"] == 512
    assert "max_tokens" not in received_kwargs


@pytest.mark.asyncio
async def test_stream_falls_back_when_first_stream_breaks_before_output():
    providers = ProvidersConfig(openai=ProviderConfig(api_key=SecretStr("sk-test")))
    provider = OpenAIProvider(providers)

    class _FirstCompletions:
        async def create(self, **kwargs):
            return _FailingStream()

    class _SecondCompletions:
        async def create(self, **kwargs):
            chunk = SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        delta=SimpleNamespace(content="fallback stream ok"),
                        finish_reason="stop",
                    )
                ],
                model="openai/gpt-4o",
            )
            return _FakeStream([chunk])

    first_client = SimpleNamespace(chat=SimpleNamespace(completions=_FirstCompletions()))
    second_client = SimpleNamespace(chat=SimpleNamespace(completions=_SecondCompletions()))

    def _client_for_model(resolved_model: str, creds: dict[str, str]):
        del creds
        if resolved_model == "openai/o1":
            return first_client
        return second_client

    with (
        patch(
            "workpilot.providers.client.resolve_credentials",
            return_value={"api_key": "test"},
        ),
        patch(
            "workpilot.providers.client.resolve_model_chain",
            return_value=["openai/o1", "openai/gpt-4o"],
        ),
        patch.object(OpenAIProvider, "_build_client", side_effect=_client_for_model),
    ):
        chunks = []
        async for chunk in provider.stream(
            model="reasoning",
            messages=[{"role": "user", "content": "hello"}],
        ):
            chunks.append(chunk)

    assert len(chunks) == 1
    assert chunks[0].content == "fallback stream ok"
    assert chunks[0].model == "openai/gpt-4o"
