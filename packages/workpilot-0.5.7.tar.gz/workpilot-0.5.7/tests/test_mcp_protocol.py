"""Tests for MCP protocol negotiation, capability detection, and tool change notifications."""

from __future__ import annotations

import asyncio
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from workpilot.mcp.client import SUPPORTED_VERSIONS, MCPClient

# ── Helpers ──────────────────────────────────────────────────────────────────


def _mock_transport(
    *,
    init_response: dict[str, Any] | None = None,
    init_error: bool = False,
) -> AsyncMock:
    """Create a mock transport that returns an initialize response."""
    transport = AsyncMock()
    transport.start = AsyncMock()
    transport.close = AsyncMock()

    if init_response is None and not init_error:
        init_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "protocolVersion": "2025-03-26",
                "capabilities": {
                    "tools": {"listChanged": True, "streaming": False},
                    "resources": {},
                    "prompts": {},
                },
                "serverInfo": {"name": "test-server", "version": "1.0"},
            },
        }

    if init_error:
        transport.receive = AsyncMock(side_effect=ConnectionError("refused"))
    else:
        # First receive returns init response, then blocks
        transport.receive = AsyncMock(side_effect=[init_response, asyncio.CancelledError()])

    return transport


# ── Protocol Negotiation ─────────────────────────────────────────────────────


class TestProtocolNegotiation:
    def test_supported_versions_list(self) -> None:
        assert len(SUPPORTED_VERSIONS) >= 2
        assert "2025-03-26" in SUPPORTED_VERSIONS
        assert "2024-11-05" in SUPPORTED_VERSIONS
        # Newest first
        assert SUPPORTED_VERSIONS[0] == "2025-03-26"

    @pytest.mark.asyncio
    async def test_connect_stores_protocol_version(self) -> None:
        transport = _mock_transport()
        client = MCPClient(command="echo", args=["test"], name="test")
        client._transport_factory = lambda: transport

        await client.connect()

        assert client.protocol_version == "2025-03-26"
        await client.disconnect()

    @pytest.mark.asyncio
    async def test_connect_stores_server_capabilities(self) -> None:
        transport = _mock_transport()
        client = MCPClient(command="echo", args=["test"], name="test")
        client._transport_factory = lambda: transport

        await client.connect()

        caps = client.capabilities
        assert caps.tools is True
        assert caps.resources is True
        assert caps.prompts is True
        assert caps.list_changed is True
        assert caps.streaming is False
        await client.disconnect()

    @pytest.mark.asyncio
    async def test_connect_with_old_protocol(self) -> None:
        """Server returns older protocol version."""
        response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "old-server"},
            },
        }
        transport = _mock_transport(init_response=response)
        client = MCPClient(command="echo", args=["test"], name="test")
        client._transport_factory = lambda: transport

        await client.connect()

        assert client.protocol_version == "2024-11-05"
        caps = client.capabilities
        assert caps.tools is True
        assert caps.resources is False
        await client.disconnect()

    @pytest.mark.asyncio
    async def test_connect_with_no_capabilities(self) -> None:
        response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "serverInfo": {"name": "bare-server"},
            },
        }
        transport = _mock_transport(init_response=response)
        client = MCPClient(command="echo", args=["test"], name="test")
        client._transport_factory = lambda: transport

        await client.connect()

        caps = client.capabilities
        assert caps.tools is False
        assert caps.resources is False
        assert caps.prompts is False
        await client.disconnect()

    def test_capabilities_before_connect(self) -> None:
        client = MCPClient(command="echo", args=["test"], name="test")
        caps = client.capabilities
        assert caps.tools is False
        assert client.protocol_version is None


# ── Tool Change Notifications ────────────────────────────────────────────────


class TestToolChangeNotifications:
    @pytest.mark.asyncio
    async def test_on_tools_changed_callback(self) -> None:
        """Server sends notifications/tools/list_changed → callback invoked."""
        callback = MagicMock()

        notification = {
            "jsonrpc": "2.0",
            "method": "notifications/tools/list_changed",
        }
        init_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "protocolVersion": "2025-03-26",
                "capabilities": {"tools": {"listChanged": True}},
                "serverInfo": {"name": "test"},
            },
        }

        transport = AsyncMock()
        transport.start = AsyncMock()
        transport.close = AsyncMock()
        transport.receive = AsyncMock(
            side_effect=[init_response, notification, asyncio.CancelledError()]
        )

        client = MCPClient(command="echo", args=["test"], name="test")
        client._transport_factory = lambda: transport
        client.set_on_tools_changed(callback)

        await client.connect()
        # Give the receive loop time to process the notification
        await asyncio.sleep(0.05)

        callback.assert_called_once()
        await client.disconnect()

    @pytest.mark.asyncio
    async def test_no_callback_no_error(self) -> None:
        """Tool change notification without callback doesn't crash."""
        notification = {
            "jsonrpc": "2.0",
            "method": "notifications/tools/list_changed",
        }
        init_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "protocolVersion": "2025-03-26",
                "capabilities": {"tools": {"listChanged": True}},
                "serverInfo": {"name": "test"},
            },
        }

        transport = AsyncMock()
        transport.start = AsyncMock()
        transport.close = AsyncMock()
        transport.receive = AsyncMock(
            side_effect=[init_response, notification, asyncio.CancelledError()]
        )

        client = MCPClient(command="echo", args=["test"], name="test")
        client._transport_factory = lambda: transport
        # No callback set

        await client.connect()
        await asyncio.sleep(0.05)
        # Should not crash
        await client.disconnect()

    def test_set_on_tools_changed(self) -> None:
        client = MCPClient(command="echo", args=["test"], name="test")
        cb = MagicMock()
        client.set_on_tools_changed(cb)
        assert client._on_tools_changed is cb

        client.set_on_tools_changed(None)
        assert client._on_tools_changed is None
