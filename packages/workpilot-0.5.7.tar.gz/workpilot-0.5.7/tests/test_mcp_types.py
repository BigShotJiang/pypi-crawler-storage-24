"""Tests for MCP types and enhanced MCPServerConfig."""

from __future__ import annotations

import pytest

from workpilot.config.schema import MCPAuthConfig, MCPServerConfig
from workpilot.mcp.types import ConnectionState, MCPCapabilities, ServerInfo


class TestConnectionState:
    def test_all_states_exist(self) -> None:
        assert len(ConnectionState) == 6
        names = {s.value for s in ConnectionState}
        assert names == {
            "idle",
            "connecting",
            "connected",
            "reconnecting",
            "disconnected",
            "failed",
        }


class TestMCPCapabilities:
    def test_defaults_all_false(self) -> None:
        caps = MCPCapabilities()
        assert not caps.tools
        assert not caps.resources
        assert not caps.prompts
        assert not caps.streaming
        assert not caps.list_changed

    def test_from_server_response_tools_only(self) -> None:
        caps = MCPCapabilities.from_server_response({"tools": {"listChanged": True}})
        assert caps.tools is True
        assert caps.list_changed is True
        assert caps.resources is False
        assert caps.prompts is False

    def test_from_server_response_full(self) -> None:
        caps = MCPCapabilities.from_server_response(
            {
                "tools": {"listChanged": False, "streaming": True},
                "resources": {},
                "prompts": {},
                "logging": {},
            }
        )
        assert caps.tools is True
        assert caps.resources is True
        assert caps.prompts is True
        assert caps.streaming is True
        assert caps.logging is True
        assert caps.list_changed is False

    def test_from_server_response_empty(self) -> None:
        caps = MCPCapabilities.from_server_response({})
        assert caps.tools is False
        assert caps.resources is False


class TestServerInfo:
    def test_basic_creation(self) -> None:
        info = ServerInfo(
            name="icm", state=ConnectionState.CONNECTED, is_agency=True, tool_count=23
        )
        assert info.name == "icm"
        assert info.state == ConnectionState.CONNECTED
        assert info.is_agency is True
        assert info.tool_count == 23
        assert info.protocol_version is None
        assert info.error is None


class TestMCPServerConfig:
    def test_existing_fields_unchanged(self) -> None:
        cfg = MCPServerConfig(command="npx", args=["-y", "server"], env={"KEY": "val"})
        assert cfg.command == "npx"
        assert cfg.args == ["-y", "server"]
        assert cfg.env == {"KEY": "val"}

    def test_new_fields_default_none(self) -> None:
        cfg = MCPServerConfig(command="npx")
        assert cfg.timeout is None
        assert cfg.risk_level is None
        assert cfg.approval is None
        assert cfg.namespace is None

    def test_is_agency_true(self) -> None:
        cfg = MCPServerConfig(command="agency", args=["mcp", "icm"])
        assert cfg.is_agency is True

    def test_is_agency_false_for_npx(self) -> None:
        cfg = MCPServerConfig(command="npx")
        assert cfg.is_agency is False

    def test_is_agency_false_for_http(self) -> None:
        cfg = MCPServerConfig(url="https://example.com")
        assert cfg.is_agency is False

    def test_per_server_overrides(self) -> None:
        cfg = MCPServerConfig(
            command="agency",
            args=["mcp", "icm"],
            timeout=60,
            risk_level="high",
            approval="always",
            namespace="incidents",
        )
        assert cfg.timeout == 60
        assert cfg.risk_level == "high"
        assert cfg.approval == "always"
        assert cfg.namespace == "incidents"

    def test_auth_defaults_to_none(self) -> None:
        cfg = MCPServerConfig(command="npx")
        assert cfg.auth.type == "none"
        assert cfg.auth.token is None

    def test_auth_bearer(self) -> None:
        cfg = MCPServerConfig(
            url="https://mcp.example.com",
            auth=MCPAuthConfig(type="bearer", token_env="MY_TOKEN"),
        )
        assert cfg.auth.type == "bearer"
        assert cfg.auth.token_env == "MY_TOKEN"

    def test_description_within_limit(self) -> None:
        cfg = MCPServerConfig(command="agency", description="ICM — incident management")
        assert cfg.description == "ICM — incident management"

    def test_description_at_100_chars(self) -> None:
        desc = "x" * 100
        cfg = MCPServerConfig(command="agency", description=desc)
        assert len(cfg.description) == 100

    def test_description_over_100_chars_rejected(self) -> None:
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            MCPServerConfig(command="agency", description="x" * 101)

    def test_enabled_default_true(self) -> None:
        cfg = MCPServerConfig(command="agency")
        assert cfg.enabled is True

    def test_enabled_false(self) -> None:
        cfg = MCPServerConfig(command="agency", enabled=False)
        assert cfg.enabled is False

    def test_agency_descriptions_all_within_limit(self) -> None:
        """All curated Agency descriptions must be ≤100 chars."""
        from workpilot.cli.mcp import _AGENCY_DESCRIPTIONS

        for name, desc in _AGENCY_DESCRIPTIONS.items():
            assert len(desc) <= 100, f"{name}: {len(desc)} chars — '{desc}'"
            # Also verify it passes Pydantic validation
            cfg = MCPServerConfig(command="agency", description=desc)
            assert cfg.description == desc

    def test_backward_compatible_minimal(self) -> None:
        """Existing minimal config (just command+args) still works."""
        cfg = MCPServerConfig(command="agency", args=["mcp", "icm"])
        assert cfg.command == "agency"
        assert cfg.args == ["mcp", "icm"]
        assert cfg.timeout is None
        assert cfg.auth.type == "none"
        assert cfg.is_agency is True
