from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from workpilot.cli.commands import app

runner = CliRunner()


def test_init_defaults_to_home_workpilot_dir(tmp_path: Path) -> None:
    home = tmp_path / "home"

    with patch("pathlib.Path.home", return_value=home):
        result = runner.invoke(
            app,
            ["init"],
            input="n\nauto\nstandard\nn\nn\nn\n",
        )

    assert result.exit_code == 0, result.output
    assert (home / ".workpilot" / "workpilot.local.yaml").is_file()


def test_init_writes_to_explicit_directory(tmp_path: Path) -> None:
    target = tmp_path / "project"

    result = runner.invoke(
        app,
        ["init", "--dir", str(target)],
        input="n\nauto\nstandard\nn\nn\nn\n",
    )

    assert result.exit_code == 0, result.output
    assert (target / "workpilot.local.yaml").is_file()
