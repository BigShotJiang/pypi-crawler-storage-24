"""Tests for session manager."""

from pathlib import Path

import pytest

from workpilot.session.manager import SessionManager


@pytest.fixture
def session_mgr(tmp_path: Path) -> SessionManager:
    return SessionManager(data_dir=tmp_path)


class TestSessionManager:
    def test_get_or_create_id(self, session_mgr: SessionManager):
        sid = session_mgr.get_or_create_id("cli", "user1")
        assert sid == "cli:user1"

    def test_add_and_get_messages(self, session_mgr: SessionManager):
        sid = "test:session"
        session_mgr.add_message(sid, {"role": "user", "content": "hello"})
        session_mgr.add_message(sid, {"role": "assistant", "content": "hi"})

        messages = session_mgr.get_messages(sid)
        assert len(messages) == 2
        assert messages[0]["content"] == "hello"
        assert messages[1]["content"] == "hi"

    def test_clear(self, session_mgr: SessionManager):
        sid = "test:clear"
        session_mgr.add_message(sid, {"role": "user", "content": "msg"})
        session_mgr.clear(sid)
        assert session_mgr.get_messages(sid) == []

    def test_trim(self, session_mgr: SessionManager):
        sid = "test:trim"
        for i in range(10):
            session_mgr.add_message(sid, {"role": "user", "content": f"msg-{i}"})

        trimmed = session_mgr.trim(sid, keep_last=3)
        assert len(trimmed) == 7
        remaining = session_mgr.get_messages(sid)
        assert len(remaining) == 3
        assert remaining[0]["content"] == "msg-7"

    def test_persistence(self, tmp_path: Path):
        mgr1 = SessionManager(data_dir=tmp_path)
        mgr1.add_message("test:persist", {"role": "user", "content": "persisted"})

        # New manager reading from same directory
        mgr2 = SessionManager(data_dir=tmp_path)
        messages = mgr2.get_messages("test:persist")
        assert len(messages) == 1
        assert messages[0]["content"] == "persisted"

    def test_generate_id(self, session_mgr: SessionManager):
        id1 = session_mgr.generate_id()
        id2 = session_mgr.generate_id()
        assert id1 != id2
        assert len(id1) == 36  # UUID format
