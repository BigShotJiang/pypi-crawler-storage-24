"""Tests for the ContextBuilder module."""

from pathlib import Path
from unittest.mock import patch

from workpilot.agent.context import ContextBuilder
from workpilot.config.schema import AgentConfig
from workpilot.skills.loader import Skill

# ── Basic context building ───────────────────────────────────────────────────


class TestContextBuilder:
    def test_empty_system_prompt(self, tmp_path: Path):
        config = AgentConfig(instructions="")
        builder = ContextBuilder(config, tmp_path)
        prompt = builder.build_system_prompt()
        # Identity block is always present
        assert isinstance(prompt, str)
        assert "WorkPilot" in prompt

    def test_instructions_included(self, tmp_path: Path):
        config = AgentConfig(instructions="You are a helpful coding assistant.")
        builder = ContextBuilder(config, tmp_path)
        prompt = builder.build_system_prompt()
        assert "You are a helpful coding assistant." in prompt

    def test_soul_file_included(self, tmp_path: Path):
        soul_content = "I am WorkPilot, an enterprise AI assistant."
        home = tmp_path / "home"
        wp = home / ".workpilot"
        wp.mkdir(parents=True, exist_ok=True)
        (wp / "SOUL.md").write_text(soul_content, encoding="utf-8")

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=home):
            prompt = builder.build_system_prompt()
        assert soul_content in prompt

    def test_user_file_included(self, tmp_path: Path):
        user_content = "User prefers dark mode and concise output."
        home = tmp_path / "home"
        wp = home / ".workpilot"
        wp.mkdir(parents=True, exist_ok=True)
        (wp / "USER.md").write_text(user_content, encoding="utf-8")

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=home):
            prompt = builder.build_system_prompt()
        assert user_content in prompt

    def test_agents_file_included(self, tmp_path: Path):
        agents_content = "Coordinator assigns tasks to sub-agents."
        home = tmp_path / "home"
        wp = home / ".workpilot"
        wp.mkdir(parents=True, exist_ok=True)
        (wp / "AGENTS.md").write_text(agents_content, encoding="utf-8")

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=home):
            prompt = builder.build_system_prompt()
        assert agents_content in prompt

    def test_custom_soul_file_path(self, tmp_path: Path):
        custom_soul = tmp_path / "custom" / "MYSOUL.md"
        custom_soul.parent.mkdir(parents=True, exist_ok=True)
        custom_soul.write_text("Custom personality.", encoding="utf-8")

        config = AgentConfig(soul_file=str(custom_soul))
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            prompt = builder.build_system_prompt()
        assert "Custom personality." in prompt

    def test_relative_soul_file_path(self, tmp_path: Path):
        (tmp_path / "my_soul.md").write_text("Relative soul.", encoding="utf-8")

        config = AgentConfig(soul_file="my_soul.md")
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            prompt = builder.build_system_prompt()
        assert "Relative soul." in prompt

    def test_identity_block_always_present(self, tmp_path: Path):
        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            prompt = builder.build_system_prompt()
        assert "# WorkPilot" in prompt  # from bundled SOUL.md
        assert "## Environment" in prompt
        assert "# Tools" in prompt  # from bundled TOOLS.md

    def test_tools_md_with_heading_no_double_wrap(self, tmp_path: Path):
        home = tmp_path / "home"
        wp = home / ".workpilot"
        wp.mkdir(parents=True, exist_ok=True)
        (wp / "TOOLS.md").write_text("# Tool Notes\nUse shell for builds.", encoding="utf-8")

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=home):
            prompt = builder.build_system_prompt()
        assert "# Tool Notes" in prompt
        assert "Use shell for builds." in prompt
        # Should NOT double-wrap with "## Guidelines"
        assert prompt.count("Tool Notes") == 1

    def test_tools_md_no_heading_gets_wrapper(self, tmp_path: Path):
        home = tmp_path / "home"
        wp = home / ".workpilot"
        wp.mkdir(parents=True, exist_ok=True)
        (wp / "TOOLS.md").write_text("Use shell for builds.", encoding="utf-8")

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=home):
            prompt = builder.build_system_prompt()
        assert "## Guidelines" in prompt
        assert "Use shell for builds." in prompt
        # Wrapper heading should appear exactly once
        assert prompt.count("## Guidelines") == 1

    def test_section_separator(self, tmp_path: Path):
        config = AgentConfig(instructions="Some instructions.")
        builder = ContextBuilder(config, tmp_path)
        prompt = builder.build_system_prompt()
        assert "\n\n---\n\n" in prompt


# ── Prompt modes ────────────────────────────────────────────────────────────


class TestPromptModes:
    def test_minimal_mode_has_identity(self, tmp_path: Path):
        config = AgentConfig(instructions="Be concise.")
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            prompt = builder.build_system_prompt(mode="minimal")
        assert "## Environment" in prompt
        assert "Be concise." in prompt

    def test_minimal_mode_excludes_memory(self, tmp_path: Path):
        wp = tmp_path / ".workpilot"
        wp.mkdir(parents=True, exist_ok=True)
        (wp / "MEMORY.md").write_text("Important facts.", encoding="utf-8")

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)
        prompt = builder.build_system_prompt(mode="minimal")
        assert "Important facts." not in prompt

    def test_minimal_mode_includes_tools_md(self, tmp_path: Path):
        home = tmp_path / "home"
        wp = home / ".workpilot"
        wp.mkdir(parents=True, exist_ok=True)
        (wp / "TOOLS.md").write_text("# Tools\nTool notes.", encoding="utf-8")

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=home):
            prompt = builder.build_system_prompt(mode="minimal")
        assert "Tool notes." in prompt

    def test_minimal_mode_excludes_skills(self, tmp_path: Path):
        skill = Skill(
            name="review",
            description="Code review",
            content="Check for bugs.",
            mode="always",
        )

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path, skills=[skill])
        prompt = builder.build_system_prompt(mode="minimal")
        assert "Check for bugs." not in prompt

    def test_full_mode_is_default(self, tmp_path: Path):
        config = AgentConfig(instructions="Hello.")
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            full = builder.build_system_prompt()
            explicit_full = builder.build_system_prompt(mode="full")
        assert full == explicit_full


# ── Memory files ─────────────────────────────────────────────────────────────


class TestContextBuilderMemory:
    def test_workspace_memory_included(self, tmp_path: Path):
        wp = tmp_path / ".workpilot"
        wp.mkdir(parents=True, exist_ok=True)
        (wp / "MEMORY.md").write_text("Project uses Python 3.11.", encoding="utf-8")

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=tmp_path):
            prompt = builder.build_system_prompt()
        assert "Long-term Memory" in prompt
        assert "Python 3.11" in prompt

    def test_shared_memory_included(self, tmp_path: Path):
        shared_dir = tmp_path / ".workpilot" / "memory" / "shared"
        shared_dir.mkdir(parents=True, exist_ok=True)
        (shared_dir / "MEMORY.md").write_text("Shared team knowledge.", encoding="utf-8")

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=tmp_path):
            prompt = builder.build_system_prompt()
        assert "Shared Memory" in prompt
        assert "Shared team knowledge." in prompt

    def test_missing_memory_file_ok(self, tmp_path: Path):
        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)
        # Should not raise even if MEMORY.md does not exist
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            prompt = builder.build_system_prompt()
        assert isinstance(prompt, str)

    def test_memory_capped_at_8kb(self, tmp_path: Path):
        large_memory = "x" * 20000
        wp = tmp_path / ".workpilot"
        wp.mkdir(parents=True, exist_ok=True)
        (wp / "MEMORY.md").write_text(large_memory, encoding="utf-8")

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)
        with patch("pathlib.Path.home", return_value=tmp_path):
            prompt = builder.build_system_prompt()
        # Memory should be capped, not include full 20000 chars
        assert "x" * 100 in prompt  # memory IS loaded
        assert len(prompt) < 20000 + 2000  # but capped

    # ── Skills in context ────────────────────────────────────────────────────────

    def test_builtin_soul_fallback_when_home_file_missing(self, tmp_path: Path):
        builder = ContextBuilder(AgentConfig(), tmp_path)
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            prompt = builder.build_system_prompt()
        assert "How I Work" in prompt
        assert "Accuracy" in prompt

    def test_builtin_agents_fallback_when_home_file_missing(self, tmp_path: Path):
        builder = ContextBuilder(AgentConfig(), tmp_path)
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            prompt = builder.build_system_prompt()
        assert "Agent Rules" in prompt
        assert "Delegation" in prompt

    def test_bundled_tools_fallback(self, tmp_path: Path):
        builder = ContextBuilder(AgentConfig(), tmp_path)
        with patch("pathlib.Path.home", return_value=tmp_path / "home"):
            prompt = builder.build_system_prompt()
        # Bundled TOOLS.md (Guidelines) loaded as fallback
        assert "Guidelines" in prompt


class TestContextBuilderSkills:
    def test_always_skills_included(self, tmp_path: Path):
        skill = Skill(
            name="review",
            description="Code review guidelines",
            content="Always check for security issues.",
            mode="always",
        )

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path, skills=[skill])
        prompt = builder.build_system_prompt()
        assert "Skill: review" in prompt
        assert "Always check for security issues." in prompt

    def test_available_skills_show_summary(self, tmp_path: Path):
        skill = Skill(
            name="deploy",
            description="Deployment guide",
            content="Run kubectl apply.",
            mode="available",
            triggers=["deploy", "release"],
        )

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path, skills=[skill])
        prompt = builder.build_system_prompt()
        # Full content should NOT be in prompt
        assert "Run kubectl apply." not in prompt
        # Plain text summary should be present (nanobot pattern)
        assert "Available Skills" in prompt
        assert "deploy: Deployment guide" in prompt
        assert "read_file" in prompt

    def test_available_skills_content_excluded(self, tmp_path: Path):
        skill = Skill(
            name="deploy",
            description="Deployment guide",
            content="Run kubectl apply.",
            mode="available",
        )

        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path, skills=[skill])
        prompt = builder.build_system_prompt()
        # 'available' mode skills should NOT have full content injected
        assert "Run kubectl apply." not in prompt

    def test_set_skills(self, tmp_path: Path):
        config = AgentConfig()
        builder = ContextBuilder(config, tmp_path)

        always_skill = Skill(
            name="coding",
            description="Coding guidelines",
            content="Follow PEP 8.",
            mode="always",
        )
        builder.set_skills([always_skill])
        prompt = builder.build_system_prompt()
        assert "Follow PEP 8." in prompt


# ── build_messages ───────────────────────────────────────────────────────────


class TestBuildMessages:
    def test_basic_message_list(self, tmp_path: Path):
        config = AgentConfig(instructions="Be helpful.")
        builder = ContextBuilder(config, tmp_path)

        messages = builder.build_messages([], "Hello!")

        # Should have system + user messages
        assert len(messages) == 2
        assert messages[0]["role"] == "system"
        assert "Be helpful." in messages[0]["content"]
        assert messages[1]["role"] == "user"
        # User message now has runtime context prepended
        assert "Hello!" in messages[1]["content"]
        assert "Runtime Context" in messages[1]["content"]

    def test_history_preserved(self, tmp_path: Path):
        config = AgentConfig(instructions="Be helpful.")
        builder = ContextBuilder(config, tmp_path)

        history = [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": "Hello!"},
        ]
        messages = builder.build_messages(history, "How are you?")

        # system + 2 history + 1 user = 4
        assert len(messages) == 4
        assert messages[0]["role"] == "system"
        assert messages[1]["role"] == "user"
        assert messages[1]["content"] == "Hi"
        assert messages[2]["role"] == "assistant"
        assert messages[3]["role"] == "user"
        assert "How are you?" in messages[3]["content"]

    def test_ordering_system_then_history_then_user(self, tmp_path: Path):
        config = AgentConfig(instructions="System prompt.")
        builder = ContextBuilder(config, tmp_path)

        history = [{"role": "user", "content": "previous"}]
        messages = builder.build_messages(history, "current")

        roles = [m["role"] for m in messages]
        assert roles == ["system", "user", "user"]
        assert "current" in messages[-1]["content"]

    def test_system_prompt_always_included(self, tmp_path: Path):
        """Identity block ensures system prompt is never empty."""
        config = AgentConfig(instructions="")
        builder = ContextBuilder(config, tmp_path)

        messages = builder.build_messages([], "Hello")

        # System prompt is always present due to identity block
        assert messages[0]["role"] == "system"
        assert "WorkPilot" in messages[0]["content"]
        assert len(messages) == 2

    def test_runtime_context_has_channel(self, tmp_path: Path):
        config = AgentConfig(instructions="Test.")
        builder = ContextBuilder(config, tmp_path)

        messages = builder.build_messages([], "Hello!", channel="teams", channel_id="chat123")

        user_msg = messages[-1]["content"]
        assert "Channel: teams" in user_msg
        assert "Chat ID: chat123" in user_msg

    def test_minimal_mode_in_messages(self, tmp_path: Path):
        config = AgentConfig(instructions="Sub-agent task.")
        builder = ContextBuilder(config, tmp_path)

        messages = builder.build_messages([], "Do something.", mode="minimal")

        assert messages[0]["role"] == "system"
        assert "Sub-agent task." in messages[0]["content"]
        # Minimal mode should not have memory, skills, etc.
