"""Tests for typing indicator support across channels and agent loop.

Covers:
- BaseChannel.send_typing() default no-op
- TeamsChannel.send_typing() sends a typing activity
- CloudChannel.send_typing() enqueues a typing frame
- AgentLoop emits TYPING_STARTED / TYPING_STOPPED events
- ChannelManager dispatches typing events to the correct channel
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from workpilot.agent.loop import AgentLoop
from workpilot.bus.events import EventType, InboundMessage
from workpilot.bus.queue import MessageBus
from workpilot.channels.base import BaseChannel
from workpilot.channels.manager import ChannelManager
from workpilot.config.schema import AgentConfig, AuditConfig
from workpilot.providers.base import LLMChunk, LLMResponse
from workpilot.security.audit import AuditLogger
from workpilot.session.manager import SessionManager

# ── Helpers ───────────────────────────────────────────────────────────────────


def _make_provider(responses: list[LLMResponse]) -> AsyncMock:
    """Create a mock LLM provider that returns pre-defined responses."""
    provider = AsyncMock()
    provider.complete = AsyncMock(side_effect=responses)

    stream_iter = iter(responses)

    async def _stream(**kwargs):
        r = next(stream_iter)
        yield LLMChunk(content=r.content, finish_reason=r.finish_reason, model=r.model)

    provider.stream = _stream
    return provider


def _make_tool_registry():
    """Minimal tool registry."""
    from workpilot.agent.tools.base import Tool
    from workpilot.agent.tools.registry import ToolRegistry

    class MockTool(Tool):
        @property
        def name(self) -> str:
            return "shell"

        @property
        def description(self) -> str:
            return "Run a shell command"

        @property
        def parameters(self) -> dict:
            return {
                "type": "object",
                "properties": {"command": {"type": "string"}},
                "required": ["command"],
            }

        async def execute(self, **kwargs) -> str:
            return f"executed: {kwargs.get('command', '')}"

    registry = ToolRegistry()
    registry.register(MockTool())
    return registry


def _make_loop(provider: AsyncMock, tmp_path: Path) -> AgentLoop:
    return AgentLoop(
        config=AgentConfig(max_iterations=5),
        provider=provider,
        tool_registry=_make_tool_registry(),
        bus=MessageBus(),
        session_manager=SessionManager(tmp_path),
        audit=AuditLogger(AuditConfig(enabled=False)),
        workspace=tmp_path,
    )


def _make_msg(
    content: str = "hello", channel: str = "cloud", channel_id: str = "conv-1"
) -> InboundMessage:
    return InboundMessage(
        channel=channel,
        channel_id=channel_id,
        sender_id="user-1",
        sender_name="Test User",
        content=content,
    )


# ── BaseChannel.send_typing (no-op) ──────────────────────────────────────────


class TestBaseChannelTyping:
    @pytest.mark.asyncio
    async def test_send_typing_noop(self):
        """BaseChannel.send_typing() should be a no-op (no error)."""

        class DummyChannel(BaseChannel):
            @property
            def name(self) -> str:
                return "dummy"

            async def start(self) -> None:
                pass

            async def stop(self) -> None:
                pass

            async def send(self, channel_id, content, **kwargs):
                pass

        ch = DummyChannel(MessageBus())
        # Should not raise
        await ch.send_typing("some-channel-id")


# ── TeamsChannel.send_typing ──────────────────────────────────────────────────


class TestTeamsChannelTyping:
    @pytest.mark.asyncio
    async def test_send_typing_posts_activity(self):
        """TeamsChannel.send_typing() sends a typing activity via Bot Framework."""
        from workpilot.channels.teams import TeamsChannel

        bus = MessageBus()
        channel = TeamsChannel(
            bus,
            app_id="test-app",
            app_password="test-pw",  # noqa: S106
            tenant_id="test-tenant",
        )

        # Mock token acquisition and HTTP client
        channel._token = "mock-token"
        channel._token_expires = 9999999999.0

        mock_response = MagicMock()
        mock_response.is_success = True

        with patch("workpilot.channels.teams.httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await channel.send_typing(
                "conv-123", service_url="https://smba.trafficmanager.net/teams/"
            )

            mock_client.post.assert_called_once()
            call_args = mock_client.post.call_args
            assert "/v3/conversations/conv-123/activities" in call_args[0][0]
            assert call_args[1]["json"]["type"] == "typing"


# ── CloudChannel.send_typing ─────────────────────────────────────────────────


class TestCloudChannelTyping:
    @pytest.mark.asyncio
    async def test_send_typing_enqueues_frame(self):
        """CloudChannel.send_typing() puts a typing frame on the send queue."""
        import json

        from workpilot.channels.cloud import CloudChannel

        bus = MessageBus()

        # Use bypass_token to skip MSAL initialization
        channel = CloudChannel(
            bus,
            url="wss://test/connect",
            tenant_id="test-tenant",
            client_id="abcdefgh-1234",
            scope="api://test/.default",
            bypass_token="test-token",  # noqa: S106
        )

        await channel.send_typing("conv-456")

        # Verify a typing frame was enqueued
        assert not channel._send_queue.empty()
        frame = json.loads(channel._send_queue.get_nowait())
        assert frame["type"] == "typing"
        assert frame["channel_id"] == "conv-456"


# ── Event types ───────────────────────────────────────────────────────────────


class TestTypingEventTypes:
    def test_typing_events_exist(self):
        """TYPING_STARTED and TYPING_STOPPED event types are defined."""
        assert EventType.TYPING_STARTED == "typing.started"
        assert EventType.TYPING_STOPPED == "typing.stopped"


# ── ChannelManager typing dispatch ────────────────────────────────────────────


class TestChannelManagerTyping:
    @pytest.mark.asyncio
    async def test_typing_event_dispatches_to_channel(self):
        """ChannelManager routes TYPING_STARTED events to channel.send_typing()."""
        bus = MessageBus()
        manager = ChannelManager(bus)

        mock_channel = AsyncMock(spec=BaseChannel)
        mock_channel.name = "cloud"
        mock_channel.send_typing = AsyncMock()

        manager._channels["cloud"] = mock_channel

        # Emit typing event — EventBus fires handlers as background tasks
        bus.events.emit(
            EventType.TYPING_STARTED,
            {"channel": "cloud", "channel_id": "conv-1", "metadata": {}},
        )

        # Give the background task a moment to run
        await asyncio.sleep(0.1)

        mock_channel.send_typing.assert_called_once_with("conv-1")

    @pytest.mark.asyncio
    async def test_typing_event_ignores_unknown_channel(self):
        """TYPING_STARTED for unknown channel should not raise."""
        bus = MessageBus()
        ChannelManager(bus)  # registers event handlers on the bus

        # No channels registered — should not raise
        bus.events.emit(
            EventType.TYPING_STARTED,
            {"channel": "nonexistent", "channel_id": "conv-1", "metadata": {}},
        )
        await asyncio.sleep(0.1)


# ── AgentLoop typing integration ─────────────────────────────────────────────


class TestAgentLoopTyping:
    @pytest.mark.asyncio
    async def test_typing_events_emitted_for_cloud_channel(self, tmp_path):
        """Agent loop emits TYPING_STARTED for non-CLI channels."""
        provider = _make_provider([LLMResponse(content="hello", tool_calls=[])])
        loop = _make_loop(provider, tmp_path)

        events_emitted: list[tuple[EventType, dict]] = []

        async def capture(event_type, payload):
            events_emitted.append((event_type, payload))

        loop._bus.events.on(EventType.TYPING_STARTED, capture)
        loop._bus.events.on(EventType.TYPING_STOPPED, capture)

        msg = _make_msg(channel="cloud", channel_id="conv-1")
        await loop._process_message(msg)

        # Give background tasks time to fire
        await asyncio.sleep(0.2)

        started = [e for e in events_emitted if e[0] == EventType.TYPING_STARTED]
        stopped = [e for e in events_emitted if e[0] == EventType.TYPING_STOPPED]

        # At least one TYPING_STARTED should have fired
        assert len(started) >= 1
        assert started[0][1]["channel"] == "cloud"
        assert started[0][1]["channel_id"] == "conv-1"

        # TYPING_STOPPED should have fired once
        assert len(stopped) == 1

    @pytest.mark.asyncio
    async def test_no_typing_for_cli_channel(self, tmp_path):
        """Agent loop should NOT emit typing events for CLI channel."""
        provider = _make_provider([LLMResponse(content="hi", tool_calls=[])])
        loop = _make_loop(provider, tmp_path)

        events_emitted: list[tuple[EventType, dict]] = []

        async def capture(event_type, payload):
            events_emitted.append((event_type, payload))

        loop._bus.events.on(EventType.TYPING_STARTED, capture)
        loop._bus.events.on(EventType.TYPING_STOPPED, capture)

        msg = _make_msg(channel="cli", channel_id="terminal")
        await loop._process_message(msg)
        await asyncio.sleep(0.2)

        assert len(events_emitted) == 0

    @pytest.mark.asyncio
    async def test_typing_stops_on_error(self, tmp_path):
        """Typing indicator stops even when agent loop raises an error."""
        provider = AsyncMock()
        provider.complete = AsyncMock(side_effect=RuntimeError("LLM failure"))
        loop = _make_loop(provider, tmp_path)
        # Override provider after construction
        loop._provider = provider

        stopped: list[dict] = []

        async def capture_stop(event_type, payload):
            stopped.append(payload)

        loop._bus.events.on(EventType.TYPING_STOPPED, capture_stop)

        msg = _make_msg(channel="teams", channel_id="conv-err")
        await loop._process_message(msg)
        await asyncio.sleep(0.2)

        assert len(stopped) == 1
        assert stopped[0]["channel"] == "teams"

    @pytest.mark.asyncio
    async def test_start_typing_returns_none_for_cli(self, tmp_path):
        """_start_typing() returns None for CLI channel (no task created)."""
        provider = _make_provider([])
        loop = _make_loop(provider, tmp_path)

        task = loop._start_typing("cli", "terminal")
        assert task is None

    @pytest.mark.asyncio
    async def test_start_typing_returns_task_for_cloud(self, tmp_path):
        """_start_typing() returns an asyncio.Task for non-CLI channels."""
        provider = _make_provider([])
        loop = _make_loop(provider, tmp_path)

        task = loop._start_typing("cloud", "conv-1")
        assert isinstance(task, asyncio.Task)

        # Clean up
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    @pytest.mark.asyncio
    async def test_stop_typing_cancels_task(self, tmp_path):
        """_stop_typing() cancels the background task."""
        provider = _make_provider([])
        loop = _make_loop(provider, tmp_path)

        task = loop._start_typing("cloud", "conv-1")
        assert not task.done()

        loop._stop_typing(task, "cloud", "conv-1")
        await asyncio.sleep(0.05)
        assert task.done()
