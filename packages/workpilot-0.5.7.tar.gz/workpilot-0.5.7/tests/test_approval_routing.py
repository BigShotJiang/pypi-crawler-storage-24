"""
Tests for human-in-the-loop approval routing & per-user allowlist.

Covers:
- AllowlistManager: load/save, exact match, regex match, no match, add/remove
- ApprovalManager: async wait + resolve from another task, timeout auto-approve/reject
- ApprovalGate: allowlisted → skip classifier, escalate → block-and-wait → approve/deny
- CLI prompt: mock input(), verify y/n/always paths
- Teams Adaptive Card: verify JSON structure
- Approval command routing: /approve, /deny, /always intercepted
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from workpilot.bus.events import EventType, InboundMessage
from workpilot.config.schema import ApprovalConfig
from workpilot.hooks.manager import HookVerdict, PreToolHookContext
from workpilot.security.allowlist import AllowlistEntry, AllowlistManager
from workpilot.security.approval import ApprovalManager, ApprovalRequest, ApprovalStatus
from workpilot.security.approval_format import (
    CLIApprovalFormatter,
    CloudApprovalFormatter,
    TeamsApprovalFormatter,
    get_approval_formatter,
)
from workpilot.security.classifier import ClassifyResult

# ═══════════════════════════════════════════════════════════════════════════
# AllowlistEntry
# ═══════════════════════════════════════════════════════════════════════════


class TestAllowlistEntry:
    def test_exact_match_no_pattern(self) -> None:
        entry = AllowlistEntry(tool_name="shell")
        assert entry.matches("shell", {"command": "ls"})
        assert not entry.matches("git", {"command": "ls"})

    def test_regex_pattern_match(self) -> None:
        entry = AllowlistEntry(tool_name="shell", arg_pattern=r'"command":\s*"ls')
        assert entry.matches("shell", {"command": "ls -la"})
        assert not entry.matches("shell", {"command": "rm -rf /"})

    def test_invalid_regex(self) -> None:
        entry = AllowlistEntry(tool_name="shell", arg_pattern="[invalid")
        assert not entry.matches("shell", {"command": "ls"})


# ═══════════════════════════════════════════════════════════════════════════
# AllowlistManager
# ═══════════════════════════════════════════════════════════════════════════


class TestAllowlistManager:
    def test_load_save_cycle(self, tmp_path: Path) -> None:
        path = tmp_path / "allowlist.json"
        mgr = AllowlistManager(path)
        assert mgr.list_entries() == []

        mgr.add("shell", added_by="test", note="testing")
        assert len(mgr.list_entries()) == 1

        # Reload from disk
        mgr2 = AllowlistManager(path)
        assert len(mgr2.list_entries()) == 1
        assert mgr2.list_entries()[0].tool_name == "shell"

    def test_check_hit(self, tmp_path: Path) -> None:
        mgr = AllowlistManager(tmp_path / "al.json")
        mgr.add("read_file")
        assert mgr.check("read_file", {"path": "/foo"})
        assert not mgr.check("write_file", {"path": "/foo"})

    def test_check_regex(self, tmp_path: Path) -> None:
        mgr = AllowlistManager(tmp_path / "al.json")
        mgr.add("shell", arg_pattern=r'"command":\s*"git')
        assert mgr.check("shell", {"command": "git status"})
        assert not mgr.check("shell", {"command": "rm -rf /"})

    def test_remove(self, tmp_path: Path) -> None:
        mgr = AllowlistManager(tmp_path / "al.json")
        mgr.add("shell")
        mgr.add("git")
        assert len(mgr.list_entries()) == 2
        removed = mgr.remove(0)
        assert removed.tool_name == "shell"
        assert len(mgr.list_entries()) == 1

    def test_remove_invalid_index(self, tmp_path: Path) -> None:
        mgr = AllowlistManager(tmp_path / "al.json")
        with pytest.raises(IndexError):
            mgr.remove(5)

    def test_load_corrupted(self, tmp_path: Path) -> None:
        path = tmp_path / "al.json"
        path.write_text("not json", encoding="utf-8")
        mgr = AllowlistManager(path)
        assert mgr.list_entries() == []


# ═══════════════════════════════════════════════════════════════════════════
# ApprovalManager — async wait/resolve
# ═══════════════════════════════════════════════════════════════════════════


class TestApprovalManagerAsync:
    @pytest.mark.asyncio
    async def test_wait_and_resolve(self) -> None:
        config = ApprovalConfig(timeout_seconds=60)
        mgr = ApprovalManager(config)

        request = await mgr.request_approval(
            tool_name="shell", args={"command": "ls"}, agent_name="default", channel="cli"
        )

        async def _resolve_later() -> None:
            await asyncio.sleep(0.05)
            mgr.resolve(request.id, approved=True, resolver="test-user")

        asyncio.create_task(_resolve_later())
        resolved = await mgr.wait_for_resolution(request.id)
        assert resolved.status == ApprovalStatus.APPROVED
        assert resolved.resolver == "test-user"

    @pytest.mark.asyncio
    async def test_auto_approve_timeout(self) -> None:
        config = ApprovalConfig(timeout_seconds=60)
        mgr = ApprovalManager(config)

        request = await mgr.request_approval(
            tool_name="shell", args={}, agent_name="default", channel="cli"
        )

        # Low auto-approve timeout to speed up test
        resolved = await mgr.wait_for_resolution(request.id, auto_approve_timeout=0)
        assert resolved.status == ApprovalStatus.APPROVED
        assert resolved.resolver == "auto-approve-timeout"

    @pytest.mark.asyncio
    async def test_reject_on_timeout(self) -> None:
        config = ApprovalConfig(timeout_seconds=0)  # Immediate timeout
        mgr = ApprovalManager(config)

        request = await mgr.request_approval(
            tool_name="shell", args={}, agent_name="default", channel="cli"
        )

        resolved = await mgr.wait_for_resolution(request.id, auto_approve_timeout=None)
        assert resolved.status == ApprovalStatus.TIMEOUT
        assert resolved.resolver == "timeout"


# ═══════════════════════════════════════════════════════════════════════════
# ApprovalGate
# ═══════════════════════════════════════════════════════════════════════════


class TestApprovalGate:
    @pytest.mark.asyncio
    async def test_no_classifier_allows(self) -> None:
        from workpilot.hooks.handlers import ApprovalGate

        gate = ApprovalGate(classifier=None)
        ctx = PreToolHookContext(tool_name="shell", args={"command": "ls"})
        result = await gate(ctx)
        assert result.verdict == HookVerdict.ALLOW

    @pytest.mark.asyncio
    async def test_allowlist_skips_classifier(self) -> None:
        from workpilot.hooks.handlers import ApprovalGate

        classifier = MagicMock()
        classifier.classify = AsyncMock(return_value=ClassifyResult("deny", "high", "blocked"))

        allowlist = MagicMock()
        allowlist.check = MagicMock(return_value=True)

        gate = ApprovalGate(classifier, allowlist=allowlist)
        ctx = PreToolHookContext(tool_name="shell", args={"command": "ls"})
        result = await gate(ctx)
        assert result.verdict == HookVerdict.ALLOW
        # Classifier should NOT have been called
        classifier.classify.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_classifier_allow(self) -> None:
        from workpilot.hooks.handlers import ApprovalGate

        classifier = MagicMock()
        classifier.classify = AsyncMock(return_value=ClassifyResult("allow", "low", "safe"))

        gate = ApprovalGate(classifier)
        ctx = PreToolHookContext(tool_name="shell", args={"command": "ls"})
        result = await gate(ctx)
        assert result.verdict == HookVerdict.ALLOW

    @pytest.mark.asyncio
    async def test_classifier_deny(self) -> None:
        from workpilot.hooks.handlers import ApprovalGate

        classifier = MagicMock()
        classifier.classify = AsyncMock(return_value=ClassifyResult("deny", "critical", "danger"))

        gate = ApprovalGate(classifier)
        ctx = PreToolHookContext(tool_name="shell", args={"command": "rm -rf /"})
        result = await gate(ctx)
        assert result.verdict == HookVerdict.REJECT

    @pytest.mark.asyncio
    async def test_escalate_no_manager_rejects(self) -> None:
        from workpilot.hooks.handlers import ApprovalGate

        classifier = MagicMock()
        classifier.classify = AsyncMock(
            return_value=ClassifyResult("escalate", "medium", "uncertain")
        )

        gate = ApprovalGate(classifier, approval_manager=None)
        ctx = PreToolHookContext(tool_name="shell", args={"command": "curl example.com"})
        result = await gate(ctx)
        assert result.verdict == HookVerdict.REJECT

    @pytest.mark.asyncio
    async def test_escalate_cli_approve(self) -> None:
        from workpilot.hooks.handlers import ApprovalGate

        classifier = MagicMock()
        classifier.classify = AsyncMock(
            return_value=ClassifyResult("escalate", "medium", "needs review")
        )

        config = ApprovalConfig(timeout_seconds=60)
        approval_mgr = ApprovalManager(config)

        gate = ApprovalGate(
            classifier,
            approval_manager=approval_mgr,
            auto_approve_timeout=180,
        )

        ctx = PreToolHookContext(
            tool_name="shell",
            args={"command": "curl example.com"},
            channel="cli",
        )

        with patch("builtins.input", return_value="y"):
            result = await gate(ctx)
        assert result.verdict == HookVerdict.ALLOW

    @pytest.mark.asyncio
    async def test_escalate_cli_deny(self) -> None:
        from workpilot.hooks.handlers import ApprovalGate

        classifier = MagicMock()
        classifier.classify = AsyncMock(return_value=ClassifyResult("escalate", "high", "risky"))

        config = ApprovalConfig(timeout_seconds=60)
        approval_mgr = ApprovalManager(config)

        gate = ApprovalGate(
            classifier,
            approval_manager=approval_mgr,
            auto_approve_timeout=180,
        )

        ctx = PreToolHookContext(
            tool_name="shell",
            args={"command": "rm -rf /tmp"},
            channel="cli",
        )

        with patch("builtins.input", return_value="n"):
            result = await gate(ctx)
        assert result.verdict == HookVerdict.REJECT

    @pytest.mark.asyncio
    async def test_escalate_cli_always_adds_allowlist(self) -> None:
        from workpilot.hooks.handlers import ApprovalGate

        classifier = MagicMock()
        classifier.classify = AsyncMock(return_value=ClassifyResult("escalate", "low", "review"))

        config = ApprovalConfig(timeout_seconds=60)
        approval_mgr = ApprovalManager(config)
        allowlist = MagicMock()
        allowlist.check = MagicMock(return_value=False)

        gate = ApprovalGate(
            classifier,
            approval_manager=approval_mgr,
            allowlist=allowlist,
        )

        ctx = PreToolHookContext(
            tool_name="web_fetch",
            args={"url": "https://example.com"},
            channel="cli",
        )

        with patch("builtins.input", return_value="always"):
            result = await gate(ctx)
        assert result.verdict == HookVerdict.ALLOW
        allowlist.add.assert_called_once()

    @pytest.mark.asyncio
    async def test_user_message_passed_to_classifier(self) -> None:
        from workpilot.hooks.handlers import ApprovalGate

        classifier = MagicMock()
        classifier.classify = AsyncMock(return_value=ClassifyResult("allow", "low", "ok"))

        gate = ApprovalGate(classifier)
        ctx = PreToolHookContext(
            tool_name="browser",
            args={"url": "https://example.com"},
            user_message="Open example.com in the browser",
        )
        await gate(ctx)

        # Verify user_message was passed as context
        call_kwargs = classifier.classify.call_args
        context = call_kwargs.kwargs.get("context") or call_kwargs[1].get("context")
        assert context is not None
        assert context["user_message"] == "Open example.com in the browser"


# ═══════════════════════════════════════════════════════════════════════════
# Approval Formatters
# ═══════════════════════════════════════════════════════════════════════════


class TestApprovalFormatters:
    def _make_request(self) -> ApprovalRequest:
        return ApprovalRequest(
            id="abc123",
            tool_name="shell",
            args={"command": "curl example.com"},
        )

    def _make_classify_result(self) -> ClassifyResult:
        return ClassifyResult("escalate", "medium", "uncertain command")

    def test_cli_formatter(self) -> None:
        fmt = CLIApprovalFormatter()
        text = fmt.format_request(self._make_request(), self._make_classify_result(), 180)
        assert isinstance(text, str)
        assert "shell" in text
        assert "abc123" in text
        assert "180s" in text

    def test_teams_formatter_adaptive_card(self) -> None:
        fmt = TeamsApprovalFormatter()
        card = fmt.format_request(self._make_request(), self._make_classify_result())
        assert isinstance(card, dict)
        assert card["type"] == "message"
        attachments = card["attachments"]
        assert len(attachments) == 1
        content = attachments[0]["content"]
        assert content["type"] == "AdaptiveCard"
        actions = content["actions"]
        assert len(actions) == 3
        assert actions[0]["title"] == "Approve"
        assert actions[1]["title"] == "Deny"
        assert actions[2]["title"] == "Always Allow"
        assert actions[0]["data"]["approval_request_id"] == "abc123"

    def test_cloud_formatter(self) -> None:
        fmt = CloudApprovalFormatter()
        data = fmt.format_request(self._make_request(), self._make_classify_result(), 60)
        assert isinstance(data, dict)
        assert data["type"] == "approval_request"
        assert data["request_id"] == "abc123"
        assert data["auto_timeout"] == 60

    def test_factory(self) -> None:
        assert isinstance(get_approval_formatter("cli"), CLIApprovalFormatter)
        assert isinstance(get_approval_formatter("teams"), TeamsApprovalFormatter)
        assert isinstance(get_approval_formatter("cloud"), CloudApprovalFormatter)
        assert isinstance(get_approval_formatter("web"), CloudApprovalFormatter)


# ═══════════════════════════════════════════════════════════════════════════
# Approval command routing
# ═══════════════════════════════════════════════════════════════════════════


class TestApprovalRouting:
    @pytest.mark.asyncio
    async def test_approve_command_routed(self) -> None:
        """Verify /approve command resolves the pending request."""
        from workpilot.agent.loop import AgentLoop

        config = ApprovalConfig(timeout_seconds=60)
        approval_mgr = ApprovalManager(config)

        # Create a pending request
        request = await approval_mgr.request_approval(
            tool_name="shell", args={}, agent_name="default", channel="cli"
        )

        # Build a minimal AgentLoop with approval_manager
        bus = MagicMock()
        bus.publish_outbound = AsyncMock()

        loop = AgentLoop.__new__(AgentLoop)
        loop._approval_manager = approval_mgr
        loop._allowlist = None
        loop._bus = bus

        msg = InboundMessage(
            channel="cli",
            channel_id="test",
            sender_id="user1",
            content=f"/approve {request.id}",
        )

        result = await loop._try_route_approval(msg)
        assert result is True
        bus.publish_outbound.assert_awaited_once()
        # Request should be resolved
        assert request.id not in approval_mgr._pending

    @pytest.mark.asyncio
    async def test_deny_command_routed(self) -> None:
        from workpilot.agent.loop import AgentLoop

        config = ApprovalConfig(timeout_seconds=60)
        approval_mgr = ApprovalManager(config)

        request = await approval_mgr.request_approval(
            tool_name="shell", args={}, agent_name="default", channel="cli"
        )

        bus = MagicMock()
        bus.publish_outbound = AsyncMock()

        loop = AgentLoop.__new__(AgentLoop)
        loop._approval_manager = approval_mgr
        loop._allowlist = None
        loop._bus = bus

        msg = InboundMessage(
            channel="cli",
            channel_id="test",
            sender_id="user1",
            content=f"/deny {request.id}",
        )

        result = await loop._try_route_approval(msg)
        assert result is True

    @pytest.mark.asyncio
    async def test_metadata_approval_action(self) -> None:
        """Verify structured approval_action in metadata is routed."""
        from workpilot.agent.loop import AgentLoop

        config = ApprovalConfig(timeout_seconds=60)
        approval_mgr = ApprovalManager(config)

        request = await approval_mgr.request_approval(
            tool_name="browser", args={}, agent_name="default", channel="teams"
        )

        bus = MagicMock()
        bus.publish_outbound = AsyncMock()

        loop = AgentLoop.__new__(AgentLoop)
        loop._approval_manager = approval_mgr
        loop._allowlist = None
        loop._bus = bus

        msg = InboundMessage(
            channel="teams",
            channel_id="conv1",
            sender_id="user1",
            content="",
            metadata={
                "approval_action": "approve",
                "approval_request_id": request.id,
            },
        )

        result = await loop._try_route_approval(msg)
        assert result is True

    @pytest.mark.asyncio
    async def test_non_approval_not_intercepted(self) -> None:
        from workpilot.agent.loop import AgentLoop

        loop = AgentLoop.__new__(AgentLoop)
        loop._approval_manager = MagicMock()
        loop._allowlist = None
        loop._bus = MagicMock()

        msg = InboundMessage(
            channel="cli",
            channel_id="test",
            sender_id="user1",
            content="Hello, world!",
        )

        result = await loop._try_route_approval(msg)
        assert result is False


# ═══════════════════════════════════════════════════════════════════════════
# Event types
# ═══════════════════════════════════════════════════════════════════════════


class TestApprovalEvents:
    def test_event_types_exist(self) -> None:
        assert EventType.APPROVAL_REQUESTED == "approval.requested"
        assert EventType.APPROVAL_RESOLVED == "approval.resolved"


# ═══════════════════════════════════════════════════════════════════════════
# Config schema additions
# ═══════════════════════════════════════════════════════════════════════════


class TestConfigSchema:
    def test_approval_config_defaults(self) -> None:
        config = ApprovalConfig()
        assert config.auto_approve_timeout == 180
        assert config.timeout_seconds == 900

    def test_allowlist_config(self) -> None:
        from workpilot.config.schema import AllowlistConfig

        config = AllowlistConfig()
        assert config.enabled is True
        assert config.path is None

    def test_security_config_has_allowlist(self) -> None:
        from workpilot.config.schema import SecurityConfig

        config = SecurityConfig()
        assert config.allowlist.enabled is True
