"""Tests for MCP transport abstractions and MCP auth resolution."""

import pytest
from pydantic import SecretStr

from workpilot.mcp.transport import HttpTransport, StdioTransport

# ── Transport abstractions ───────────────────────────────────────────────────


class TestStdioTransport:
    def test_initialization(self):
        transport = StdioTransport("node", args=["server.js"])
        assert transport._command == "node"
        assert transport._args == ["server.js"]

    def test_default_args(self):
        transport = StdioTransport("python")
        assert transport._args == []

    def test_is_running_false_initially(self):
        transport = StdioTransport("echo")
        assert transport.is_running is False


class TestHttpTransport:
    def test_initialization(self):
        transport = HttpTransport("https://mcp.example.com/api")
        assert transport._url == "https://mcp.example.com/api"

    def test_url_trailing_slash_stripped(self):
        transport = HttpTransport("https://mcp.example.com/api/")
        assert transport._url == "https://mcp.example.com/api"

    def test_headers_stored(self):
        transport = HttpTransport(
            "https://mcp.example.com/api",
            headers={"Authorization": "Bearer token123"},
        )
        assert transport._headers["Authorization"] == "Bearer token123"

    def test_default_headers_empty(self):
        transport = HttpTransport("https://mcp.example.com/api")
        assert transport._headers == {}

    def test_parse_sse_event_valid(self):
        block = 'data: {"jsonrpc": "2.0", "id": 1, "result": {}}'
        result = HttpTransport._parse_sse_event(block)
        assert result is not None
        assert result["jsonrpc"] == "2.0"

    def test_parse_sse_event_multiline(self):
        block = 'data: {"jsonrpc": "2.0",\ndata:  "id": 1,\ndata:  "result": {}}'
        # Multi-line data merging: lines are joined
        result = HttpTransport._parse_sse_event(block)
        assert result is not None

    def test_parse_sse_event_no_data(self):
        block = "event: ping"
        result = HttpTransport._parse_sse_event(block)
        assert result is None

    def test_parse_sse_event_invalid_json(self):
        block = "data: not-valid-json"
        result = HttpTransport._parse_sse_event(block)
        assert result is None


# ── github_copilot auth type ─────────────────────────────────────────────────


class TestGithubCopilotAuth:
    """resolve_auth_headers with auth.type == 'github_copilot'."""

    def _make_server_config(self, extra_auth: dict | None = None):
        from workpilot.config.schema import MCPAuthConfig, MCPServerConfig

        auth = MCPAuthConfig(type="github_copilot", **(extra_auth or {}))
        return MCPServerConfig(url="https://api.githubcopilot.com/mcp/", auth=auth)

    def _make_providers(self, token: str | None):
        from workpilot.config.schema import GitHubCopilotConfig, ProvidersConfig

        return ProvidersConfig(
            github_copilot=GitHubCopilotConfig(token=SecretStr(token) if token else None)
        )

    @pytest.mark.asyncio
    async def test_priority_1_providers_token(self):
        """providers.github_copilot.token is used first."""
        from workpilot.mcp.auth import resolve_auth_headers

        config = self._make_server_config()
        providers = self._make_providers("ghu_from_providers")
        headers = await resolve_auth_headers(config, providers)
        assert headers == {"Authorization": "Bearer ghu_from_providers"}

    @pytest.mark.asyncio
    async def test_priority_2_explicit_token_env(self, monkeypatch):
        """auth.token_env is used when providers token is absent."""
        from workpilot.mcp.auth import resolve_auth_headers

        monkeypatch.setenv("MY_GH_TOKEN", "ghu_from_env_var")
        config = self._make_server_config({"token_env": "MY_GH_TOKEN"})
        providers = self._make_providers(None)  # no provider token
        headers = await resolve_auth_headers(config, providers)
        assert headers == {"Authorization": "Bearer ghu_from_env_var"}

    @pytest.mark.asyncio
    async def test_priority_3_github_token_env(self, monkeypatch):
        """GITHUB_TOKEN env var is the final fallback."""
        from workpilot.mcp.auth import resolve_auth_headers

        monkeypatch.setenv("GITHUB_TOKEN", "ghu_fallback")
        monkeypatch.delenv("MY_GH_TOKEN", raising=False)
        config = self._make_server_config()
        providers = self._make_providers(None)
        headers = await resolve_auth_headers(config, providers)
        assert headers == {"Authorization": "Bearer ghu_fallback"}

    @pytest.mark.asyncio
    async def test_providers_token_takes_priority_over_env(self, monkeypatch):
        """providers.token beats GITHUB_TOKEN env."""
        from workpilot.mcp.auth import resolve_auth_headers

        monkeypatch.setenv("GITHUB_TOKEN", "ghu_env_should_not_be_used")
        config = self._make_server_config()
        providers = self._make_providers("ghu_from_providers_wins")
        headers = await resolve_auth_headers(config, providers)
        assert headers == {"Authorization": "Bearer ghu_from_providers_wins"}

    @pytest.mark.asyncio
    async def test_no_token_returns_empty(self, monkeypatch):
        """No token anywhere → empty headers with warning (no crash)."""
        from workpilot.mcp.auth import resolve_auth_headers

        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        config = self._make_server_config()
        providers = self._make_providers(None)
        headers = await resolve_auth_headers(config, providers)
        assert headers == {}

    @pytest.mark.asyncio
    async def test_no_providers_falls_back_to_env(self, monkeypatch):
        """providers=None falls back directly to GITHUB_TOKEN."""
        from workpilot.mcp.auth import resolve_auth_headers

        monkeypatch.setenv("GITHUB_TOKEN", "ghu_no_providers")
        config = self._make_server_config()
        headers = await resolve_auth_headers(config, providers=None)
        assert headers == {"Authorization": "Bearer ghu_no_providers"}
