"""Tests for terminal UX improvements (PR #96 / issue #84).

Covers:
- CLIChannel.send: HTML escaping and fallback to sys.stdout
- History file path is under get_data_dir()
"""

from __future__ import annotations

import sys
from unittest.mock import MagicMock, patch

import pytest

from workpilot.bus.queue import MessageBus
from workpilot.channels.cli import CLIChannel
from workpilot.utils.helpers import get_data_dir

# ── CLIChannel.send ───────────────────────────────────────────────────────────


class TestCLIChannelSend:
    @pytest.mark.asyncio
    async def test_send_escapes_html_special_chars(self, capsys):
        """Agent responses with <, >, & must not be misinterpreted as HTML tags."""
        bus = MagicMock(spec=MessageBus)
        ch = CLIChannel(bus)

        printed: list[str] = []

        def _fake_print_formatted_text(text, **kwargs):
            from prompt_toolkit.formatted_text import HTML

            if isinstance(text, HTML):
                # capture the raw HTML value
                printed.append(text.value)

        with patch("prompt_toolkit.shortcuts.print_formatted_text", _fake_print_formatted_text):
            await ch.send("cli", "Score: 5 > 3 & x < 10")

        assert len(printed) == 1
        html = printed[0]
        # Special chars must be escaped
        assert "&gt;" in html
        assert "&amp;" in html
        assert "&lt;" in html
        # Raw chars must NOT appear inside content area
        content_part = html.split("assistant&gt;")[1]
        assert "<" not in content_part.replace("</", "").replace("<b>", "").replace("<green>", "")

    @pytest.mark.asyncio
    async def test_send_fallback_writes_to_stdout(self, capsys):
        """When prompt_toolkit.shortcuts raises, output falls back to sys.stdout."""
        bus = MagicMock(spec=MessageBus)
        ch = CLIChannel(bus)

        with patch(
            "prompt_toolkit.shortcuts.print_formatted_text",
            side_effect=ImportError("not available"),
        ):
            await ch.send("cli", "hello world")

        captured = capsys.readouterr()
        assert "hello world" in captured.out

    @pytest.mark.asyncio
    async def test_send_fallback_flushes_stdout(self):
        """Fallback path must flush stdout so output appears immediately."""
        bus = MagicMock(spec=MessageBus)
        ch = CLIChannel(bus)

        with (
            patch(
                "prompt_toolkit.shortcuts.print_formatted_text",
                side_effect=ValueError("output error"),
            ),
            patch.object(sys.stdout, "write"),
            patch.object(sys.stdout, "flush") as mock_flush,
        ):
            await ch.send("cli", "test")
            mock_flush.assert_called_once()


# ── History file path ─────────────────────────────────────────────────────────


class TestHistoryPath:
    def test_history_file_under_data_dir(self):
        """cli_history must be stored inside get_data_dir(), not a temp or cwd path."""
        expected = get_data_dir() / "cli_history"
        # Verify the path is reachable and under the data directory
        assert expected.parent == get_data_dir()
        assert expected.name == "cli_history"
