"""Tests for SearchFilesTool — content search and name search modes."""

from __future__ import annotations

from pathlib import Path

import pytest

from workpilot.agent.tools.filesystem import SearchFilesTool
from workpilot.config.schema import FileSystemConfig, ShellConfig
from workpilot.security.sandbox import Sandbox


@pytest.fixture
def sandbox(tmp_path: Path) -> Sandbox:
    return Sandbox(
        tmp_path,
        shell_config=ShellConfig(),
        fs_config=FileSystemConfig(restrict_to_workspace=True),
    )


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    """Create a workspace with sample files for searching."""
    # Python files
    (tmp_path / "app.py").write_text("import os\n\ndef main():\n    print('hello')\n")
    (tmp_path / "utils.py").write_text("def helper():\n    return 42\n\ndef another():\n    pass\n")

    # Nested directory
    sub = tmp_path / "src"
    sub.mkdir()
    (sub / "models.py").write_text("class User:\n    name: str\n\nclass Admin(User):\n    pass\n")
    (sub / "config.yaml").write_text("key: value\nport: 8080\n")

    # Text file
    (tmp_path / "readme.txt").write_text("Welcome to WorkPilot\nAn enterprise AI assistant\n")

    return tmp_path


class TestSearchFilesToolMetadata:
    def test_name(self, sandbox: Sandbox) -> None:
        tool = SearchFilesTool(sandbox)
        assert tool.name == "search_files"

    def test_metadata_low_risk(self, sandbox: Sandbox) -> None:
        tool = SearchFilesTool(sandbox)
        assert tool.metadata.risk_level == "low"
        assert tool.metadata.approval == "never"

    def test_parameters_schema(self, sandbox: Sandbox) -> None:
        tool = SearchFilesTool(sandbox)
        params = tool.parameters
        assert params["type"] == "object"
        assert "pattern" in params["properties"]
        assert "mode" in params["properties"]
        assert "path" in params["properties"]
        assert "file_pattern" in params["properties"]
        assert "max_results" in params["properties"]
        assert params["required"] == ["pattern"]

    def test_openai_schema(self, sandbox: Sandbox) -> None:
        tool = SearchFilesTool(sandbox)
        schema = tool.to_openai_schema()
        assert schema["type"] == "function"
        assert schema["function"]["name"] == "search_files"
        assert "parameters" in schema["function"]


class TestContentSearch:
    async def test_basic_content_search(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="def main")
        assert "app.py" in result
        assert "def main" in result

    async def test_regex_search(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern=r"class \w+")
        assert "models.py" in result
        assert "User" in result

    async def test_search_with_context(self, sandbox: Sandbox, workspace: Path) -> None:
        """Matches should include 1 line before and 1 line after."""
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="return 42")
        assert "utils.py" in result
        # The match line should be marked with >
        assert ">" in result
        # Context line (def helper) should appear
        assert "helper" in result

    async def test_search_with_file_pattern(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        # Only search .py files
        result = await tool.execute(pattern="key", file_pattern="*.py")
        # config.yaml has "key: value" but should be excluded by file_pattern
        assert "config.yaml" not in result

    async def test_search_in_subdirectory(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="class User", path="src")
        assert "models.py" in result

    async def test_no_content_matches(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="nonexistent_string_xyz")
        assert "No matches" in result

    async def test_max_results_content(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        # Search for something that appears multiple times
        result = await tool.execute(pattern="def ", max_results=1)
        assert "1 match" in result

    async def test_invalid_regex(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="[invalid")
        assert "Invalid regex" in result

    async def test_default_mode_is_content(self, sandbox: Sandbox, workspace: Path) -> None:
        """When mode is not specified, it defaults to content search."""
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="import os")
        assert "app.py" in result

    async def test_skips_binary_files(self, sandbox: Sandbox, workspace: Path) -> None:
        """Binary files should be skipped without error."""
        # Create a binary file
        (workspace / "image.bin").write_bytes(b"\x00\x01\x02\xff\xfe\xfd")
        tool = SearchFilesTool(sandbox)
        # Should not crash; just skip the binary file
        result = await tool.execute(pattern="anything")
        assert "Error" not in result


class TestNameSearch:
    async def test_basic_name_search(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="*.py", mode="name")
        assert "app.py" in result
        assert "utils.py" in result
        assert "models.py" in result

    async def test_name_search_specific(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="*.yaml", mode="name")
        assert "config.yaml" in result
        assert ".py" not in result

    async def test_name_search_no_matches(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="*.rs", mode="name")
        assert "No files matching" in result

    async def test_name_search_max_results(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="*.py", mode="name", max_results=1)
        # Should only have 1 file path in results
        assert "1 file" in result

    async def test_name_search_in_subdirectory(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="*.py", mode="name", path="src")
        assert "models.py" in result
        # app.py and utils.py are in parent, should not appear
        assert "app.py" not in result
        assert "utils.py" not in result


class TestSandboxEnforcement:
    async def test_path_escape_blocked(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="secret", path="../../etc")
        assert "BLOCKED" in result

    async def test_not_a_directory(self, sandbox: Sandbox, workspace: Path) -> None:
        tool = SearchFilesTool(sandbox)
        result = await tool.execute(pattern="test", path="app.py")
        assert "Not a directory" in result
