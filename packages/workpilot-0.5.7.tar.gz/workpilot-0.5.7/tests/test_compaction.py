"""Tests for context compaction — 3-tier context window management."""

import pytest

from workpilot.agent.compaction import (
    CompactionTier,
    ContextCompactor,
    build_summary_prompt,
    check_threshold,
    compact_tier3,
    compact_with_llm,
    estimate_tokens,
)


class TestEstimateTokens:
    def test_empty_messages(self):
        assert estimate_tokens([]) == 0

    def test_text_message(self):
        msgs = [{"role": "user", "content": "hello world"}]
        tokens = estimate_tokens(msgs)
        # 2 words × 1.3 = 2.6 → 2
        assert tokens == 2

    def test_tool_calls_add_tokens(self):
        msgs = [
            {
                "role": "assistant",
                "content": "ok",
                "tool_calls": [{"id": "1"}, {"id": "2"}],
            }
        ]
        tokens = estimate_tokens(msgs)
        # 1 word + 2 tool_calls × 50 words = 101 words × 1.3 = 131
        assert tokens == 131

    def test_none_content_is_zero(self):
        msgs = [{"role": "assistant", "content": None}]
        assert estimate_tokens(msgs) == 0

    def test_multiple_messages(self):
        msgs = [
            {"role": "user", "content": "one two three"},  # 3 words
            {"role": "assistant", "content": "four five"},  # 2 words
        ]
        tokens = estimate_tokens(msgs)
        # 5 words × 1.3 = 6.5 → 6
        assert tokens == 6


class TestCheckThreshold:
    def test_under_80_is_none(self):
        # 10 words × 1.3 = 13 tokens, limit 100 → 13% usage
        msgs = [{"role": "user", "content": " ".join(["word"] * 10)}]
        assert check_threshold(msgs, 100) == CompactionTier.NONE

    def test_at_80_is_tier1(self):
        # Need ~80% of 100 tokens → ~80 tokens → ~61 words
        msgs = [{"role": "user", "content": " ".join(["word"] * 62)}]
        assert check_threshold(msgs, 100) == CompactionTier.TIER1

    def test_at_85_is_tier2(self):
        msgs = [{"role": "user", "content": " ".join(["word"] * 66)}]
        assert check_threshold(msgs, 100) == CompactionTier.TIER2

    def test_at_95_is_tier3(self):
        msgs = [{"role": "user", "content": " ".join(["word"] * 74)}]
        assert check_threshold(msgs, 100) == CompactionTier.TIER3

    def test_zero_limit_is_none(self):
        msgs = [{"role": "user", "content": "anything"}]
        assert check_threshold(msgs, 0) == CompactionTier.NONE


class TestCompactTier3:
    def test_keeps_system_messages(self):
        msgs = [
            {"role": "system", "content": "You are an assistant"},
            {"role": "user", "content": "msg1"},
            {"role": "assistant", "content": "resp1"},
            {"role": "user", "content": "msg2"},
            {"role": "assistant", "content": "resp2"},
            {"role": "user", "content": "msg3"},
            {"role": "assistant", "content": "resp3"},
        ]
        result = compact_tier3(msgs, keep_recent=2)
        # System msg + compaction notice + last 2 non-system
        assert result[0]["role"] == "system"
        assert result[0]["content"] == "You are an assistant"
        assert "[Context compacted" in result[1]["content"]
        assert result[-1]["content"] == "resp3"
        assert result[-2]["content"] == "msg3"

    def test_no_compaction_when_few_messages(self):
        msgs = [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        result = compact_tier3(msgs, keep_recent=3)
        assert result == msgs  # unchanged

    def test_keep_recent_3(self):
        msgs = [{"role": "user", "content": f"msg{i}"} for i in range(10)]
        result = compact_tier3(msgs, keep_recent=3)
        non_system = [m for m in result if "[Context compacted" not in m.get("content", "")]
        assert len(non_system) == 3
        assert non_system[-1]["content"] == "msg9"


class TestBuildSummaryPrompt:
    def test_includes_role_and_content(self):
        msgs = [
            {"role": "user", "content": "Find the bug in auth.py"},
            {"role": "assistant", "content": "I found an issue on line 42"},
        ]
        prompt = build_summary_prompt(msgs)
        assert "[user]" in prompt
        assert "[assistant]" in prompt
        assert "auth.py" in prompt
        assert "Summary:" in prompt

    def test_truncates_long_content(self):
        msgs = [{"role": "user", "content": "x" * 500}]
        prompt = build_summary_prompt(msgs)
        assert "..." in prompt


class TestCompactWithLlm:
    @pytest.mark.asyncio
    async def test_summarizes_older_messages(self):
        class MockProvider:
            async def complete(self, **kwargs):
                class Resp:
                    content = "Summary: user asked about auth, agent found bug on line 42."

                return Resp()

        msgs = [
            {"role": "system", "content": "system prompt"},
            {"role": "user", "content": "msg1"},
            {"role": "assistant", "content": "resp1"},
            {"role": "user", "content": "msg2"},
            {"role": "assistant", "content": "resp2"},
            {"role": "user", "content": "msg3"},
            {"role": "assistant", "content": "resp3"},
        ]
        result = await compact_with_llm(msgs, MockProvider(), "auto", keep_recent=2)
        # system + summary + 2 recent
        assert result[0]["content"] == "system prompt"
        assert "compacted" in result[1]["content"]
        assert result[-1]["content"] == "resp3"
        assert result[-2]["content"] == "msg3"

    @pytest.mark.asyncio
    async def test_falls_back_to_truncation_on_error(self):
        class FailProvider:
            async def complete(self, **kwargs):
                raise RuntimeError("LLM unavailable")

        msgs = [{"role": "user", "content": f"msg{i}"} for i in range(10)]
        result = await compact_with_llm(msgs, FailProvider(), "auto", keep_recent=3)
        # Fallback to tier3 truncation
        non_notice = [m for m in result if "[Context compacted" not in m.get("content", "")]
        assert len(non_notice) == 3


class TestContextCompactor:
    @pytest.mark.asyncio
    async def test_no_compaction_under_threshold(self):
        compactor = ContextCompactor(context_limit=100_000)
        msgs = [{"role": "user", "content": "short message"}]
        result = await compactor.maybe_compact(msgs)
        assert result == msgs  # unchanged

    @pytest.mark.asyncio
    async def test_tier3_without_provider(self):
        # Many messages to exceed 95% of a small context limit, no provider → truncation
        compactor = ContextCompactor(context_limit=100, provider=None)
        msgs = [
            {"role": "user", "content": f"message {i} with several words here"} for i in range(15)
        ]
        result = await compactor.maybe_compact(msgs)
        assert any("[Context compacted" in m.get("content", "") for m in result)

    @pytest.mark.asyncio
    async def test_tier1_with_provider(self):
        class MockProvider:
            async def complete(self, **kwargs):
                class Resp:
                    content = "Summary of conversation."

                return Resp()

        # Many messages to hit ~80% of a small context limit
        compactor = ContextCompactor(context_limit=100, provider=MockProvider(), model="fast")
        msgs = [
            {"role": "system", "content": "sys"},
            *[
                {"role": "user", "content": f"message number {i} with enough words to fill context"}
                for i in range(12)
            ],
        ]
        result = await compactor.maybe_compact(msgs)
        assert any("compacted" in m.get("content", "") for m in result)
