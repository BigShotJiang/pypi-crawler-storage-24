"""
Tests for SSRF protection — shared module and tool integration.

Covers:
  1. Shared check_url_safety() — private IPs, localhost, metadata, IPv6,
     DNS rebinding, userinfo, bad schemes, valid URLs.
  2. HttpRequestTool — blocks unsafe URLs before making requests.
  3. BrowserTool._validate_url — delegates to shared module.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from workpilot.agent.tools.browser import BrowserTool
from workpilot.agent.tools.web import HttpRequestTool
from workpilot.config.schema import BrowserConfig
from workpilot.security.ssrf import (
    _BLOCKED_HOSTNAME_SUFFIXES,
    _BLOCKED_HOSTNAMES,
    _BLOCKED_NETWORKS,
    check_url_safety,
)

# ═══════════════════════════════════════════════════════════════════════════════
# 1. Shared SSRF module — check_url_safety()
# ═══════════════════════════════════════════════════════════════════════════════


class TestCheckUrlSafety:
    """Unit tests for the shared SSRF validator."""

    # ── Scheme checks ────────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_http_allowed(self) -> None:
        result = await check_url_safety("http://example.com")
        assert result is None

    @pytest.mark.asyncio
    async def test_https_allowed(self) -> None:
        result = await check_url_safety("https://example.com")
        assert result is None

    @pytest.mark.asyncio
    async def test_ftp_blocked(self) -> None:
        result = await check_url_safety("ftp://example.com")
        assert result is not None
        assert "scheme" in result.lower()

    @pytest.mark.asyncio
    async def test_file_scheme_blocked(self) -> None:
        result = await check_url_safety("file:///etc/passwd")
        assert result is not None
        assert "scheme" in result.lower()

    @pytest.mark.asyncio
    async def test_javascript_scheme_blocked(self) -> None:
        result = await check_url_safety("javascript:alert(1)")
        assert result is not None
        assert "scheme" in result.lower()

    # ── Userinfo rejection ───────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_userinfo_blocked(self) -> None:
        result = await check_url_safety("http://user:pass@example.com")
        assert result is not None
        assert "user:password" in result.lower()

    @pytest.mark.asyncio
    async def test_username_only_blocked(self) -> None:
        result = await check_url_safety("http://admin@example.com")
        assert result is not None
        assert "user:password" in result.lower()

    # ── Blocked hostnames ────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_localhost_blocked(self) -> None:
        result = await check_url_safety("http://localhost")
        assert result is not None
        assert "blocked" in result.lower()

    @pytest.mark.asyncio
    async def test_localhost_with_port_blocked(self) -> None:
        result = await check_url_safety("http://localhost:8080")
        assert result is not None
        assert "blocked" in result.lower()

    @pytest.mark.asyncio
    async def test_metadata_google_blocked(self) -> None:
        result = await check_url_safety("http://metadata.google.internal/computeMetadata")
        assert result is not None
        assert "blocked" in result.lower()

    @pytest.mark.asyncio
    async def test_dot_local_suffix_blocked(self) -> None:
        result = await check_url_safety("http://myhost.local")
        assert result is not None
        assert "blocked" in result.lower()

    @pytest.mark.asyncio
    async def test_dot_localhost_suffix_blocked(self) -> None:
        result = await check_url_safety("http://evil.localhost")
        assert result is not None
        assert "blocked" in result.lower()

    @pytest.mark.asyncio
    async def test_dot_internal_suffix_blocked(self) -> None:
        result = await check_url_safety("http://service.internal")
        assert result is not None
        assert "blocked" in result.lower()

    # ── Literal private IP checks ────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_loopback_ip_blocked(self) -> None:
        result = await check_url_safety("http://127.0.0.1")
        assert result is not None
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_loopback_alt_blocked(self) -> None:
        result = await check_url_safety("http://127.0.0.2")
        assert result is not None
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_10_network_blocked(self) -> None:
        result = await check_url_safety("http://10.0.0.1")
        assert result is not None
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_172_16_network_blocked(self) -> None:
        result = await check_url_safety("http://172.16.0.1")
        assert result is not None
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_192_168_network_blocked(self) -> None:
        result = await check_url_safety("http://192.168.1.1")
        assert result is not None
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_link_local_blocked(self) -> None:
        result = await check_url_safety("http://169.254.169.254/latest/meta-data/")
        assert result is not None
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_cgnat_blocked(self) -> None:
        result = await check_url_safety("http://100.64.0.1")
        assert result is not None
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_zero_network_blocked(self) -> None:
        result = await check_url_safety("http://0.0.0.0")
        assert result is not None
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_ipv6_loopback_blocked(self) -> None:
        result = await check_url_safety("http://[::1]")
        assert result is not None
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_ipv6_unique_local_blocked(self) -> None:
        result = await check_url_safety("http://[fd00::1]")
        assert result is not None
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_ipv6_link_local_blocked(self) -> None:
        result = await check_url_safety("http://[fe80::1]")
        assert result is not None
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_ipv4_mapped_ipv6_loopback_blocked(self) -> None:
        """IPv4-mapped IPv6 like ::ffff:127.0.0.1 must not bypass SSRF checks."""
        result = await check_url_safety("http://[::ffff:127.0.0.1]")
        assert result is not None
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_ipv4_mapped_ipv6_private_blocked(self) -> None:
        """IPv4-mapped IPv6 like ::ffff:10.0.0.1 must not bypass SSRF checks."""
        result = await check_url_safety("http://[::ffff:10.0.0.1]")
        assert result is not None
        assert "SSRF" in result

    # ── DNS resolution to private IP (rebinding) ─────────────────────────

    @pytest.mark.asyncio
    async def test_dns_resolving_to_private_ip_blocked(self) -> None:
        """Hostname that DNS-resolves to a private IP should be blocked."""
        fake_result = [(2, 1, 6, "", ("10.0.0.1", 0))]
        with patch("workpilot.security.ssrf.asyncio") as mock_asyncio:
            mock_loop = AsyncMock()
            mock_loop.getaddrinfo.return_value = fake_result
            mock_asyncio.get_running_loop.return_value = mock_loop
            result = await check_url_safety("http://evil-rebind.example.com")
        assert result is not None
        assert "DNS rebinding" in result

    @pytest.mark.asyncio
    async def test_dns_resolving_to_loopback_blocked(self) -> None:
        """Hostname resolving to 127.0.0.1 should be blocked."""
        fake_result = [(2, 1, 6, "", ("127.0.0.1", 0))]
        with patch("workpilot.security.ssrf.asyncio") as mock_asyncio:
            mock_loop = AsyncMock()
            mock_loop.getaddrinfo.return_value = fake_result
            mock_asyncio.get_running_loop.return_value = mock_loop
            result = await check_url_safety("http://sneaky.example.com")
        assert result is not None
        assert "DNS rebinding" in result

    @pytest.mark.asyncio
    async def test_dns_resolving_to_public_ip_allowed(self) -> None:
        """Hostname resolving to a public IP should pass."""
        fake_result = [(2, 1, 6, "", ("93.184.216.34", 0))]
        with patch("workpilot.security.ssrf.asyncio") as mock_asyncio:
            mock_loop = AsyncMock()
            mock_loop.getaddrinfo.return_value = fake_result
            mock_asyncio.get_running_loop.return_value = mock_loop
            result = await check_url_safety("http://example.com")
        assert result is None

    # ── Valid URLs pass through ──────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_valid_public_url(self) -> None:
        result = await check_url_safety("https://example.com/path?q=1")
        assert result is None

    @pytest.mark.asyncio
    async def test_valid_public_ip(self) -> None:
        """Public IP like 8.8.8.8 should pass literal IP check."""
        # Mock DNS so we don't depend on real resolution
        fake_result = [(2, 1, 6, "", ("8.8.8.8", 0))]
        with patch("workpilot.security.ssrf.asyncio") as mock_asyncio:
            mock_loop = AsyncMock()
            mock_loop.getaddrinfo.return_value = fake_result
            mock_asyncio.get_running_loop.return_value = mock_loop
            result = await check_url_safety("http://8.8.8.8")
        assert result is None

    @pytest.mark.asyncio
    async def test_missing_hostname(self) -> None:
        result = await check_url_safety("http://")
        assert result is not None
        assert "hostname" in result.lower()

    # ── Constants are consistent ─────────────────────────────────────────

    def test_blocked_networks_count(self) -> None:
        assert len(_BLOCKED_NETWORKS) >= 10

    def test_blocked_hostnames(self) -> None:
        assert "localhost" in _BLOCKED_HOSTNAMES
        assert "metadata.google.internal" in _BLOCKED_HOSTNAMES

    def test_blocked_suffixes(self) -> None:
        assert ".localhost" in _BLOCKED_HOSTNAME_SUFFIXES
        assert ".local" in _BLOCKED_HOSTNAME_SUFFIXES
        assert ".internal" in _BLOCKED_HOSTNAME_SUFFIXES


# ═══════════════════════════════════════════════════════════════════════════════
# 2. HttpRequestTool — SSRF integration
# ═══════════════════════════════════════════════════════════════════════════════


class TestHttpToolSsrf:
    """Verify HttpRequestTool blocks unsafe URLs."""

    @pytest.mark.asyncio
    async def test_blocks_localhost(self) -> None:
        http = HttpRequestTool()
        result = await http.execute(url="http://localhost:8080/admin")
        assert "BLOCKED" in result

    @pytest.mark.asyncio
    async def test_blocks_private_ip(self) -> None:
        http = HttpRequestTool()
        result = await http.execute(url="http://10.0.0.1/internal")
        assert "BLOCKED" in result

    @pytest.mark.asyncio
    async def test_blocks_metadata_endpoint(self) -> None:
        http = HttpRequestTool()
        result = await http.execute(url="http://169.254.169.254/latest/meta-data/")
        assert "BLOCKED" in result

    @pytest.mark.asyncio
    async def test_blocks_ipv6_loopback(self) -> None:
        http = HttpRequestTool()
        result = await http.execute(url="http://[::1]:8080")
        assert "BLOCKED" in result

    @pytest.mark.asyncio
    async def test_blocks_userinfo(self) -> None:
        http = HttpRequestTool()
        result = await http.execute(url="http://admin:secret@example.com")
        assert "BLOCKED" in result

    @pytest.mark.asyncio
    async def test_still_rejects_bad_scheme(self) -> None:
        http = HttpRequestTool()
        result = await http.execute(url="ftp://example.com")
        # The basic URL check fires before SSRF (starts with http/https)
        assert "Error" in result

    @pytest.mark.asyncio
    async def test_follows_redirects_disabled(self) -> None:
        """Confirm follow_redirects=False by checking a 301 returns the redirect status."""
        http = HttpRequestTool()
        # Mock the httpx client to return a 302 redirect response instead of
        # making a real network call to httpbin.org (which is flaky in CI).
        mock_response = AsyncMock()
        mock_response.status_code = 302
        mock_response.headers = {"Location": "https://httpbin.org/get"}
        mock_response.text = ""
        mock_response.elapsed = __import__("datetime").timedelta(milliseconds=50)
        mock_response.aclose = AsyncMock()

        mock_client = AsyncMock()
        mock_client.request = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("httpx.AsyncClient", return_value=mock_client):
            result = await http.execute(url="https://httpbin.org/redirect/1")
        # Should contain 302 (not followed)
        assert "302" in result


# ═══════════════════════════════════════════════════════════════════════════════
# 3. BrowserTool._validate_url — shared SSRF delegation
# ═══════════════════════════════════════════════════════════════════════════════


class TestBrowserToolSsrf:
    """Verify BrowserTool._validate_url uses the shared SSRF module."""

    @pytest.mark.asyncio
    async def test_validate_url_blocks_localhost(self) -> None:
        config = BrowserConfig(enabled=True, browser="chromium", headless=True)
        bt = BrowserTool(config)
        with pytest.raises(ValueError, match="blocked"):
            await bt._validate_url("http://localhost:3000")

    @pytest.mark.asyncio
    async def test_validate_url_blocks_private_ip(self) -> None:
        config = BrowserConfig(enabled=True, browser="chromium", headless=True)
        bt = BrowserTool(config)
        with pytest.raises(ValueError, match="SSRF"):
            await bt._validate_url("http://192.168.1.1")

    @pytest.mark.asyncio
    async def test_validate_url_allows_public(self) -> None:
        config = BrowserConfig(enabled=True, browser="chromium", headless=True)
        bt = BrowserTool(config)
        # Should not raise
        await bt._validate_url("https://example.com")

    @pytest.mark.asyncio
    async def test_validate_url_allowed_domains_still_works(self) -> None:
        config = BrowserConfig(
            enabled=True,
            browser="chromium",
            headless=True,
            allowed_domains=["example.com"],
        )
        bt = BrowserTool(config)
        # Allowed domain passes
        await bt._validate_url("https://example.com")
        # Disallowed domain fails
        with pytest.raises(ValueError, match="not in allowed_domains"):
            await bt._validate_url("https://google.com")
