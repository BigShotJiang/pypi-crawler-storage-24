"""Tests for the skills loader module."""

from pathlib import Path
from unittest.mock import patch

from workpilot.skills.loader import Skill, SkillLoader, _parse_skill_file

# ── Skill dataclass ──────────────────────────────────────────────────────────


class TestSkillDataclass:
    def test_creation_with_defaults(self):
        skill = Skill(name="test", description="A test skill", content="body")
        assert skill.name == "test"
        assert skill.description == "A test skill"
        assert skill.content == "body"
        assert skill.mode == "available"
        assert skill.triggers == []
        assert skill.requires_bins == []
        assert skill.requires_env == []

    def test_creation_with_always_mode(self):
        skill = Skill(
            name="always_skill",
            description="Always loaded",
            content="content",
            mode="always",
        )
        assert skill.mode == "always"

    def test_matches_trigger(self):
        skill = Skill(
            name="review",
            description="Code review",
            content="Review guidelines",
            triggers=["review", "code review", "audit"],
        )
        assert skill.matches("Please review this code") is True
        assert skill.matches("audit the module") is True
        assert skill.matches("fix the bug") is False

    def test_matches_case_insensitive(self):
        skill = Skill(
            name="review",
            description="desc",
            content="body",
            triggers=["Review"],
        )
        assert skill.matches("please REVIEW this") is True

    def test_matches_no_triggers(self):
        skill = Skill(name="plain", description="desc", content="body")
        assert skill.matches("anything") is False

    def test_check_requirements_bins_missing(self):
        skill = Skill(
            name="test",
            description="desc",
            content="body",
            requires_bins=["nonexistent_binary_xyz"],
        )
        missing = skill.check_requirements()
        assert "nonexistent_binary_xyz" in missing
        assert not skill.available

    def test_check_requirements_env_missing(self):
        skill = Skill(
            name="test",
            description="desc",
            content="body",
            requires_env=["NONEXISTENT_ENV_VAR_XYZ"],
        )
        missing = skill.check_requirements()
        assert "NONEXISTENT_ENV_VAR_XYZ" in missing
        assert not skill.available

    def test_check_requirements_all_met(self):
        with patch("shutil.which", return_value="/usr/bin/python"):
            skill = Skill(
                name="test",
                description="desc",
                content="body",
                requires_bins=["python"],
            )
            assert skill.available

    def test_check_requirements_env_met(self):
        with patch.dict("os.environ", {"MY_TEST_VAR": "value"}):
            skill = Skill(
                name="test",
                description="desc",
                content="body",
                requires_env=["MY_TEST_VAR"],
            )
            assert skill.available


# ── Frontmatter parsing ─────────────────────────────────────────────────────


class TestParseFrontmatter:
    def test_nanobot_format(self, tmp_path: Path):
        """Test the metadata.workpilot namespace format."""
        skill_file = tmp_path / "test.md"
        skill_file.write_text(
            "---\n"
            "name: github-pr\n"
            "description: Create a pull request\n"
            "metadata:\n"
            "  workpilot:\n"
            "    activation:\n"
            "      keywords: [pr, pull request, create pr]\n"
            "    requires:\n"
            "      bins: [gh]\n"
            "      env: [GITHUB_TOKEN]\n"
            "    always: false\n"
            "---\n"
            "## Instructions\n\nCreate a PR.\n",
            encoding="utf-8",
        )

        skill = _parse_skill_file(skill_file)
        assert skill is not None
        assert skill.name == "github-pr"
        assert skill.description == "Create a pull request"
        assert skill.mode == "available"
        assert "pr" in skill.triggers
        assert "pull request" in skill.triggers
        assert "gh" in skill.requires_bins
        assert "GITHUB_TOKEN" in skill.requires_env
        assert "## Instructions" in skill.content

    def test_nanobot_json_metadata(self, tmp_path: Path):
        """Test nanobot's single-line JSON metadata format."""
        skill_file = tmp_path / "test.md"
        skill_file.write_text(
            "---\n"
            "name: github\n"
            'description: "Interact with GitHub using the gh CLI."\n'
            'metadata: {"nanobot":{"emoji":"🐙","requires":{"bins":["gh"]}}}\n'
            "---\n"
            "# GitHub Skill\n\nUse gh CLI.\n",
            encoding="utf-8",
        )

        skill = _parse_skill_file(skill_file)
        assert skill is not None
        assert skill.name == "github"
        assert "gh" in skill.requires_bins
        assert skill.mode == "available"

    def test_openclaw_namespace(self, tmp_path: Path):
        """Test OpenClaw's metadata.openclaw namespace."""
        skill_file = tmp_path / "test.md"
        skill_file.write_text(
            "---\n"
            "name: todoist\n"
            "description: Manage Todoist tasks\n"
            "metadata:\n"
            "  openclaw:\n"
            "    requires:\n"
            "      env: [TODOIST_API_KEY]\n"
            "      bins: [curl]\n"
            "    always: true\n"
            "    emoji: '✅'\n"
            "---\n"
            "body\n",
            encoding="utf-8",
        )

        skill = _parse_skill_file(skill_file)
        assert skill is not None
        assert skill.name == "todoist"
        assert skill.mode == "always"
        assert "curl" in skill.requires_bins
        assert "TODOIST_API_KEY" in skill.requires_env

    def test_nanobot_always_true(self, tmp_path: Path):
        skill_file = tmp_path / "test.md"
        skill_file.write_text(
            "---\n"
            "name: always-skill\n"
            "description: Always loaded\n"
            "metadata:\n"
            "  workpilot:\n"
            "    always: true\n"
            "---\n"
            "body\n",
            encoding="utf-8",
        )

        skill = _parse_skill_file(skill_file)
        assert skill is not None
        assert skill.mode == "always"

    def test_legacy_flat_format(self, tmp_path: Path):
        """Backward compat: flat mode/triggers still works."""
        skill_file = tmp_path / "test.md"
        skill_file.write_text(
            "---\n"
            "name: test-skill\n"
            "description: A test skill\n"
            "mode: always\n"
            "triggers: [build, compile]\n"
            "---\n"
            "## Instructions\n\nDo the thing.\n",
            encoding="utf-8",
        )

        skill = _parse_skill_file(skill_file)
        assert skill is not None
        assert skill.name == "test-skill"
        assert skill.description == "A test skill"
        assert skill.mode == "always"
        assert "build" in skill.triggers
        assert "compile" in skill.triggers
        assert "## Instructions" in skill.content

    def test_missing_frontmatter(self, tmp_path: Path):
        skill_file = tmp_path / "no_front.md"
        skill_file.write_text("Just a plain markdown file.", encoding="utf-8")

        skill = _parse_skill_file(skill_file)
        assert skill is None

    def test_invalid_yaml_frontmatter(self, tmp_path: Path):
        skill_file = tmp_path / "bad_yaml.md"
        skill_file.write_text(
            "---\nname: [unclosed bracket\n---\nbody\n",
            encoding="utf-8",
        )

        skill = _parse_skill_file(skill_file)
        assert skill is None

    def test_defaults_name_to_stem(self, tmp_path: Path):
        skill_file = tmp_path / "my-skill.md"
        skill_file.write_text(
            "---\ndescription: No name given\n---\nbody\n",
            encoding="utf-8",
        )

        skill = _parse_skill_file(skill_file)
        assert skill is not None
        assert skill.name == "my-skill"

    def test_defaults_mode_to_available(self, tmp_path: Path):
        skill_file = tmp_path / "default_mode.md"
        skill_file.write_text(
            "---\nname: skill1\n---\nbody\n",
            encoding="utf-8",
        )

        skill = _parse_skill_file(skill_file)
        assert skill is not None
        assert skill.mode == "available"

    def test_invalid_mode_defaults_to_available(self, tmp_path: Path):
        skill_file = tmp_path / "bad_mode.md"
        skill_file.write_text(
            "---\nname: skill1\nmode: garbage\n---\nbody\n",
            encoding="utf-8",
        )

        skill = _parse_skill_file(skill_file)
        assert skill is not None
        assert skill.mode == "available"

    def test_triggers_as_comma_separated_string(self, tmp_path: Path):
        skill_file = tmp_path / "comma_triggers.md"
        skill_file.write_text(
            "---\nname: skill1\ntriggers: build, compile, deploy\n---\nbody\n",
            encoding="utf-8",
        )

        skill = _parse_skill_file(skill_file)
        assert skill is not None
        assert "build" in skill.triggers
        assert "compile" in skill.triggers
        assert "deploy" in skill.triggers


# ── SkillLoader ──────────────────────────────────────────────────────────────


class TestSkillLoader:
    def _create_skill_file(self, directory: Path, name: str, mode: str = "available") -> Path:
        """Helper: create a .md skill file in a directory."""
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"{name}.md"
        path.write_text(
            f"---\n"
            f"name: {name}\n"
            f"description: The {name} skill\n"
            f"mode: {mode}\n"
            f"triggers: [{name}]\n"
            f"---\n"
            f"Instructions for {name}.\n",
            encoding="utf-8",
        )
        return path

    def test_load_from_workspace_skills_dir(self, tmp_path: Path):
        skills_dir = tmp_path / "skills"
        self._create_skill_file(skills_dir, "alpha", "always")
        self._create_skill_file(skills_dir, "beta", "available")

        loader = SkillLoader(tmp_path)
        skills = loader.load_all()

        # Should find bundled skills (from package) + the 2 workspace skills
        ws_names = {s.name for s in skills if s.name in ("alpha", "beta")}
        assert "alpha" in ws_names
        assert "beta" in ws_names

    def test_load_from_custom_skills_dir(self, tmp_path: Path):
        custom_dir = tmp_path / "my_skills"
        self._create_skill_file(custom_dir, "gamma")

        loader = SkillLoader(tmp_path, skills_dir=custom_dir)
        skills = loader.load_all()

        gamma = [s for s in skills if s.name == "gamma"]
        assert len(gamma) == 1

    def test_get_always_loaded(self, tmp_path: Path):
        skills_dir = tmp_path / "skills"
        self._create_skill_file(skills_dir, "always_skill", "always")
        self._create_skill_file(skills_dir, "avail_skill", "available")

        loader = SkillLoader(tmp_path)
        loader.load_all()

        always = loader.get_always_loaded()
        always_names = {s.name for s in always}
        assert "always_skill" in always_names
        # avail_skill should NOT appear in always-loaded
        assert "avail_skill" not in always_names

    def test_get_available(self, tmp_path: Path):
        skills_dir = tmp_path / "skills"
        self._create_skill_file(skills_dir, "always_skill", "always")
        self._create_skill_file(skills_dir, "avail_skill", "available")

        loader = SkillLoader(tmp_path)
        loader.load_all()

        available = loader.get_available()
        avail_names = {s.name for s in available}
        assert "avail_skill" in avail_names
        assert "always_skill" not in avail_names

    def test_find_by_trigger(self, tmp_path: Path):
        skills_dir = tmp_path / "skills"
        self._create_skill_file(skills_dir, "deploy")
        self._create_skill_file(skills_dir, "review")

        loader = SkillLoader(tmp_path)
        loader.load_all()

        matches = loader.find_by_trigger("please deploy the service")
        deploy_found = any(s.name == "deploy" for s in matches)
        assert deploy_found

    def test_find_by_trigger_no_match(self, tmp_path: Path):
        skills_dir = tmp_path / "skills"
        self._create_skill_file(skills_dir, "deploy")

        loader = SkillLoader(tmp_path)
        loader.load_all()

        matches = loader.find_by_trigger("fix the bug")
        assert not any(s.name == "deploy" for s in matches)

    def test_lazy_loading(self, tmp_path: Path):
        skills_dir = tmp_path / "skills"
        self._create_skill_file(skills_dir, "lazy_skill")

        loader = SkillLoader(tmp_path)
        # Do NOT call load_all explicitly
        # get_always_loaded should trigger lazy loading
        result = loader.get_always_loaded()
        assert isinstance(result, list)

    def test_deduplication_by_name(self, tmp_path: Path):
        """Later sources override earlier ones with the same name."""
        skills_dir = tmp_path / "skills"
        self._create_skill_file(skills_dir, "test_skill")
        # Create a second skill with the same name in a custom dir
        custom_dir = tmp_path / ".workpilot" / "skills"
        self._create_skill_file(custom_dir, "test_skill")

        loader = SkillLoader(tmp_path)
        skills = loader.load_all()

        test_skills = [s for s in skills if s.name == "test_skill"]
        assert len(test_skills) == 1

    def test_loads_bundled_skills(self, tmp_path: Path):
        """Loader should discover bundled skills from the package."""
        loader = SkillLoader(tmp_path)
        skills = loader.load_all()

        # The package ships with bundled skills (review, github, ado, office)
        bundled_names = {"review", "github", "ado", "office"}
        loaded_names = {s.name for s in skills}
        # At least some bundled skills should be loaded
        assert len(bundled_names & loaded_names) > 0

    def test_source_path_set(self, tmp_path: Path):
        """Skills should have source_path set for read_file discovery."""
        skills_dir = tmp_path / "skills"
        self._create_skill_file(skills_dir, "pathtest")

        loader = SkillLoader(tmp_path)
        skills = loader.load_all()

        pathtest = [s for s in skills if s.name == "pathtest"]
        assert len(pathtest) == 1
        assert "pathtest.md" in pathtest[0].source_path
