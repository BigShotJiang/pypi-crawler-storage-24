"""
MCP-style tool call tests for specific GitHub Copilot models.

Tests realistic MCP tool schemas (nested objects, arrays, enums, optional fields)
across a multi-turn agentic loop.

Run: pytest tests/test_mcp_tool_calls.py -v -s
"""

from __future__ import annotations

import json
import os
from typing import Any

import pytest
from pydantic import SecretStr

from workpilot.config.schema import GitHubCopilotConfig, ProvidersConfig
from workpilot.providers.client import OpenAIProvider

# ---------------------------------------------------------------------------
# Token
# ---------------------------------------------------------------------------

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")
if not GITHUB_TOKEN:
    try:
        import yaml  # type: ignore

        for path in ("workpilot.local.yaml", "../workpilot.local.yaml"):
            try:
                with open(path) as f:
                    _d = yaml.safe_load(f) or {}
                GITHUB_TOKEN = ((_d.get("providers") or {}).get("github_copilot") or {}).get(
                    "token", ""
                )
                if GITHUB_TOKEN:
                    break
            except FileNotFoundError:
                continue
    except Exception:
        pass

skip_live = pytest.mark.skipif(
    not GITHUB_TOKEN or os.environ.get("SKIP_LIVE_TESTS") == "1",
    reason="No GITHUB_TOKEN or SKIP_LIVE_TESTS=1",
)

MODELS = [
    "github/gpt-5.2",
    "github/gpt-5.3-codex",
    "github/gpt-5.4",
    "github/claude-haiku-4.5",
    "github/gpt-5-mini",
]


def _provider() -> OpenAIProvider:
    return OpenAIProvider(
        ProvidersConfig(github_copilot=GitHubCopilotConfig(token=SecretStr(GITHUB_TOKEN)))
    )


# ---------------------------------------------------------------------------
# MCP-style tool definitions  (realistic schemas from WorkPilot MCP servers)
# ---------------------------------------------------------------------------

MCP_TOOLS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "mcp__filesystem__read_file",
            "description": "Read contents of a file at the given path",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Absolute or relative path to file"},
                    "encoding": {
                        "type": "string",
                        "enum": ["utf-8", "latin-1", "utf-16"],
                        "description": "File encoding (default utf-8)",
                    },
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "mcp__filesystem__list_directory",
            "description": "List files and subdirectories at a path",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "recursive": {"type": "boolean", "description": "Include subdirectories"},
                    "pattern": {
                        "type": "string",
                        "description": "Glob pattern filter, e.g. '*.py'",
                    },
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "mcp__github__search_issues",
            "description": "Search GitHub issues and pull requests",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo": {"type": "string", "description": "owner/repo"},
                    "query": {"type": "string", "description": "Search query"},
                    "state": {
                        "type": "string",
                        "enum": ["open", "closed", "all"],
                        "default": "open",
                    },
                    "labels": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Filter by labels",
                    },
                    "limit": {"type": "integer", "minimum": 1, "maximum": 100, "default": 10},
                },
                "required": ["repo", "query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "mcp__azure_devops__create_work_item",
            "description": "Create a work item (bug/task/story) in Azure DevOps",
            "parameters": {
                "type": "object",
                "properties": {
                    "project": {"type": "string"},
                    "type": {
                        "type": "string",
                        "enum": ["Bug", "Task", "User Story", "Epic"],
                    },
                    "title": {"type": "string"},
                    "description": {"type": "string"},
                    "assigned_to": {"type": "string", "description": "Email of assignee"},
                    "tags": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "priority": {
                        "type": "integer",
                        "enum": [1, 2, 3, 4],
                        "description": "1=Critical, 2=High, 3=Medium, 4=Low",
                    },
                },
                "required": ["project", "type", "title"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "mcp__graph__send_email",
            "description": "Send an email via Microsoft Graph / Outlook",
            "parameters": {
                "type": "object",
                "properties": {
                    "to": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Recipient email addresses",
                    },
                    "subject": {"type": "string"},
                    "body": {"type": "string"},
                    "cc": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "CC recipients (optional)",
                    },
                    "importance": {
                        "type": "string",
                        "enum": ["low", "normal", "high"],
                        "default": "normal",
                    },
                    "attachments": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "filename": {"type": "string"},
                                "path": {"type": "string"},
                            },
                            "required": ["filename", "path"],
                        },
                    },
                },
                "required": ["to", "subject", "body"],
            },
        },
    },
]


# ---------------------------------------------------------------------------
# Fake MCP executor
# ---------------------------------------------------------------------------


def _exec_mcp(name: str, args: dict[str, Any]) -> str:
    if name == "mcp__filesystem__read_file":
        return json.dumps(
            {
                "content": "# main.py\nprint('hello world')\n",
                "size": 32,
                "encoding": args.get("encoding", "utf-8"),
            }
        )
    if name == "mcp__filesystem__list_directory":
        return json.dumps({"entries": ["main.py", "README.md", "tests/", "workpilot/"], "total": 4})
    if name == "mcp__github__search_issues":
        return json.dumps(
            {
                "issues": [
                    {
                        "number": 42,
                        "title": "Fix provider routing bug",
                        "state": "open",
                        "labels": args.get("labels", []),
                    },
                    {"number": 37, "title": "Add Azure support", "state": "open"},
                ],
                "total": 2,
            }
        )
    if name == "mcp__azure_devops__create_work_item":
        return json.dumps(
            {
                "id": 1234,
                "url": "https://dev.azure.com/org/project/_workitems/edit/1234",
                "state": "New",
            }
        )
    if name == "mcp__graph__send_email":
        return json.dumps(
            {"status": "sent", "message_id": "AAkAL...", "recipients": args.get("to", [])}
        )
    return json.dumps({"error": f"unknown tool: {name}"})


def _safe(text: str, limit: int = 160) -> str:
    return text[:limit].replace("\n", " ").encode("ascii", "replace").decode("ascii")


# ---------------------------------------------------------------------------
# Multi-turn loop
# ---------------------------------------------------------------------------


async def _run(
    provider: OpenAIProvider,
    model: str,
    user_msg: str,
    system: str = "You are a helpful assistant. Use the provided MCP tools when needed.",
    max_turns: int = 4,
    **kwargs: Any,
) -> dict[str, Any]:
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system},
        {"role": "user", "content": user_msg},
    ]
    turns: list[dict[str, Any]] = []

    for _ in range(max_turns):
        response = await provider.complete(
            model=model, messages=messages, tools=MCP_TOOLS, max_tokens=512, **kwargs
        )
        turns.append(
            {
                "tool_calls": [
                    {"name": tc.name, "args": tc.arguments} for tc in response.tool_calls
                ],
                "content": response.content,
                "finish_reason": response.finish_reason,
            }
        )
        if not response.tool_calls:
            break

        messages.append(
            {
                "role": "assistant",
                "content": response.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.name, "arguments": json.dumps(tc.arguments)},
                    }
                    for tc in response.tool_calls
                ],
            }
        )
        for tc in response.tool_calls:
            messages.append(
                {"role": "tool", "tool_call_id": tc.id, "content": _exec_mcp(tc.name, tc.arguments)}
            )

    return {"turns": turns, "final": turns[-1]["content"] if turns else ""}


def _show(model: str, scenario: str, result: dict[str, Any]) -> None:
    print(f"\n[{model}] {scenario}")
    for i, t in enumerate(result["turns"], 1):
        tools = [f"{c['name']}({json.dumps(c['args'])[:80]})" for c in t["tool_calls"]]
        print(f"  T{i}: {tools or '(no tool)'}  [{t['finish_reason']}]")
        if t["content"]:
            print(f"      -> {_safe(t['content'])}")


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", MODELS)
async def test_mcp_read_file_with_path(model: str) -> None:
    """Tool call with string path parameter."""
    provider = _provider()
    result = await _run(provider, model, "Read the file at /workspace/main.py")
    _show(model, "read_file", result)

    tool_calls = [c for t in result["turns"] for c in t["tool_calls"]]
    assert tool_calls, f"{model}: no tool call"
    tc = tool_calls[0]
    assert tc["name"] == "mcp__filesystem__read_file"
    assert "path" in tc["args"]
    assert "main.py" in tc["args"]["path"]


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", MODELS)
async def test_mcp_list_directory_with_pattern(model: str) -> None:
    """Tool call with optional boolean + string glob parameters."""
    provider = _provider()
    result = await _run(
        provider, model, "List all Python files recursively in the /workspace directory."
    )
    _show(model, "list_dir(recursive+pattern)", result)

    tool_calls = [c for t in result["turns"] for c in t["tool_calls"]]
    assert tool_calls, f"{model}: no tool call"
    tc = tool_calls[0]
    assert tc["name"] == "mcp__filesystem__list_directory"
    assert "path" in tc["args"]
    # Model should set recursive=True and/or pattern for Python files
    args = tc["args"]
    has_py = (
        args.get("recursive") is True
        or "*.py" in str(args.get("pattern", ""))
        or ".py" in str(args.get("pattern", ""))
    )
    assert has_py, f"{model}: expected recursive=True or *.py pattern, got {args}"


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", MODELS)
async def test_mcp_github_search_with_labels_array(model: str) -> None:
    """Tool call with array parameter (labels)."""
    provider = _provider()
    result = await _run(
        provider,
        model,
        "Search for open bug issues labeled 'critical' or 'priority' in the repo BerriAI/litellm.",
    )
    _show(model, "github_search(labels=array)", result)

    tool_calls = [c for t in result["turns"] for c in t["tool_calls"]]
    assert tool_calls, f"{model}: no tool call"
    tc = tool_calls[0]
    assert tc["name"] == "mcp__github__search_issues"
    assert "repo" in tc["args"]
    assert "berriai" in tc["args"]["repo"].lower() or "litellm" in tc["args"]["repo"].lower()
    assert "query" in tc["args"]
    # state should be "open" or labels should be set
    state = tc["args"].get("state", "open")
    assert state in ("open", "all", None, ""), f"{model}: unexpected state {state!r}"


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", MODELS)
async def test_mcp_create_work_item_nested(model: str) -> None:
    """Tool call with enum fields + optional array (tags) + integer priority."""
    provider = _provider()
    result = await _run(
        provider,
        model,
        "Create a high-priority Bug work item in the 'WorkPilot' Azure DevOps project "
        "titled 'Provider fallback fails silently' and tag it with 'backend' and 'provider'.",
    )
    _show(model, "create_work_item(enum+array+int)", result)

    tool_calls = [c for t in result["turns"] for c in t["tool_calls"]]
    assert tool_calls, f"{model}: no tool call"
    tc = tool_calls[0]
    assert tc["name"] == "mcp__azure_devops__create_work_item"
    args = tc["args"]
    assert "project" in args
    assert "workpilot" in args["project"].lower()
    assert args.get("type") == "Bug"
    assert "title" in args
    assert "fallback" in args["title"].lower() or "provider" in args["title"].lower()
    # priority should be 1 or 2 for "high"
    priority = args.get("priority")
    if priority is not None:
        assert priority in (1, 2), f"{model}: expected priority 1 or 2, got {priority}"


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", MODELS)
async def test_mcp_send_email_with_cc_and_importance(model: str) -> None:
    """Tool call with required array (to), optional array (cc), enum (importance)."""
    provider = _provider()
    result = await _run(
        provider,
        model,
        "Send an urgent email to alice@contoso.com and bob@contoso.com, "
        "CC to manager@contoso.com, "
        "subject 'Prod incident - provider down', "
        "body 'The LLM provider is returning 503 errors. Investigating now.'",
    )
    _show(model, "send_email(to[]+cc[]+importance)", result)

    tool_calls = [c for t in result["turns"] for c in t["tool_calls"]]
    assert tool_calls, f"{model}: no tool call"
    tc = tool_calls[0]
    assert tc["name"] == "mcp__graph__send_email"
    args = tc["args"]

    # to: must be a list with both recipients
    to = args.get("to", [])
    assert isinstance(to, list), f"{model}: 'to' should be a list, got {type(to)}"
    to_str = " ".join(to).lower()
    assert "alice" in to_str, f"{model}: alice missing from 'to': {to}"
    assert "bob" in to_str, f"{model}: bob missing from 'to': {to}"

    assert "subject" in args
    assert "body" in args

    # importance should be "high" for "urgent"
    importance = args.get("importance", "normal")
    assert importance in ("high", "normal"), f"{model}: unexpected importance {importance!r}"


@skip_live
@pytest.mark.asyncio
@pytest.mark.parametrize("model", MODELS)
async def test_mcp_multiturn_list_then_read(model: str) -> None:
    """Two sequential MCP tool calls: list directory, then read a specific file."""
    provider = _provider()
    result = await _run(
        provider,
        model,
        "First list the /workspace directory, then read the main.py file you find there.",
        max_turns=6,
    )
    _show(model, "list -> read (sequential)", result)

    all_calls = [c for t in result["turns"] for c in t["tool_calls"]]
    names = [c["name"] for c in all_calls]
    assert "mcp__filesystem__list_directory" in names, f"{model}: missing list_directory"
    assert "mcp__filesystem__read_file" in names, f"{model}: missing read_file"
