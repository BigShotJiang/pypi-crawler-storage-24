"""Tests for built-in agent configurations."""

from workpilot.agents.builtin import get_builtin_agents, merge_agents
from workpilot.config.schema import AgentConfig


class TestGetBuiltinAgents:
    def test_returns_three_agents(self):
        agents = get_builtin_agents()
        assert set(agents.keys()) == {"default", "explorer", "security"}

    def test_all_are_agent_config(self):
        agents = get_builtin_agents()
        for name, config in agents.items():
            assert isinstance(config, AgentConfig), f"{name} is not AgentConfig"

    def test_all_marked_builtin(self):
        agents = get_builtin_agents()
        for name, config in agents.items():
            assert config.metadata.get("builtin") is True, f"{name} not marked builtin"


class TestDefaultAgent:
    def test_has_all_tools(self):
        agent = get_builtin_agents()["default"]
        assert "spawn" in agent.tools
        assert "notify" in agent.tools
        assert "shell" in agent.tools
        assert "gh_copilot" in agent.tools
        assert "gh_copilot_status" in agent.tools
        assert "gh_copilot_models" in agent.tools
        assert "tools" in agent.tools
        assert "claude_code" in agent.tools
        assert "claude_code_status" in agent.tools
        assert len(agent.tools) == 19

    def test_max_iterations_40(self):
        assert get_builtin_agents()["default"].max_iterations == 40

    def test_memory_writable(self):
        assert get_builtin_agents()["default"].memory_writable is True

    def test_can_spawn(self):
        agent = get_builtin_agents()["default"]
        assert agent.permissions is not None
        assert agent.permissions.allow_spawn is True

    def test_spawn_depth_2(self):
        assert get_builtin_agents()["default"].max_spawn_depth == 2

    def test_model_auto(self):
        assert get_builtin_agents()["default"].model == "auto"


class TestExplorerAgent:
    def test_model_fast(self):
        assert get_builtin_agents()["explorer"].model == "fast"

    def test_read_only_tools(self):
        agent = get_builtin_agents()["explorer"]
        assert set(agent.tools) == {"read_file", "list_dir", "search_files"}

    def test_no_write_permissions(self):
        agent = get_builtin_agents()["explorer"]
        assert agent.permissions is not None
        assert agent.permissions.allow_shell is False
        assert agent.permissions.allow_file_write is False
        assert agent.permissions.allow_network is False
        assert agent.permissions.allow_spawn is False

    def test_memory_not_writable(self):
        assert get_builtin_agents()["explorer"].memory_writable is False

    def test_low_iterations(self):
        assert get_builtin_agents()["explorer"].max_iterations == 15

    def test_short_timeout(self):
        assert get_builtin_agents()["explorer"].timeout == 120

    def test_has_instructions(self):
        agent = get_builtin_agents()["explorer"]
        assert "codebase explorer" in agent.instructions.lower()


class TestSecurityAgent:
    def test_model_fast(self):
        assert get_builtin_agents()["security"].model == "fast"

    def test_no_tools(self):
        assert get_builtin_agents()["security"].tools == ["read_file", "list_dir"]

    def test_max_iterations(self):
        assert get_builtin_agents()["security"].max_iterations == 2

    def test_short_timeout(self):
        assert get_builtin_agents()["security"].timeout == 55

    def test_no_permissions(self):
        agent = get_builtin_agents()["security"]
        assert agent.permissions is not None
        assert agent.permissions.allow_shell is False
        assert agent.permissions.allow_file_read is False
        assert agent.permissions.allow_network is False

    def test_marked_internal(self):
        agent = get_builtin_agents()["security"]
        assert agent.metadata.get("internal") is True

    def test_has_json_instructions(self):
        agent = get_builtin_agents()["security"]
        assert "JSON" in agent.instructions


class TestMergeAgents:
    def test_user_agent_added(self):
        builtin = get_builtin_agents()
        user = {"dba": AgentConfig(name="DBA", tools=["shell", "read_file"])}
        merged = merge_agents(builtin, user)
        assert "dba" in merged
        assert "default" in merged

    def test_user_overrides_builtin_field(self):
        builtin = get_builtin_agents()
        user = {"explorer": AgentConfig(max_iterations=30)}
        merged = merge_agents(builtin, user)
        assert merged["explorer"].max_iterations == 30
        # Other fields preserved
        assert merged["explorer"].model == "fast"

    def test_disabled_agent_excluded(self):
        builtin = get_builtin_agents()
        user = {"explorer": AgentConfig(enabled=False)}
        merged = merge_agents(builtin, user)
        assert "explorer" not in merged
        assert "default" in merged

    def test_empty_user_returns_all_builtin(self):
        builtin = get_builtin_agents()
        merged = merge_agents(builtin, {})
        assert set(merged.keys()) == {"default", "explorer", "security"}
