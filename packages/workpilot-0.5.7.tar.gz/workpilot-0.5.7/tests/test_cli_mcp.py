"""Tests for workpilot mcp CLI subcommands."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml
from typer.testing import CliRunner

from workpilot.cli.commands import app
from workpilot.cli.mcp import _discover_agency_servers

runner = CliRunner()


@pytest.fixture
def config_file(tmp_path: Path) -> Path:
    """Create a minimal workpilot.yaml with MCP servers."""
    cfg = {
        "name": "test",
        "entrypoint": "main",
        "tools": {
            "mcp_servers": {
                "icm": {
                    "command": "agency",
                    "args": ["mcp", "icm"],
                    "timeout": 60,
                },
                "github": {
                    "command": "npx",
                    "args": ["-y", "@modelcontextprotocol/server-github"],
                    "env": {"GITHUB_TOKEN": "ghp_xxx"},
                },
            },
        },
    }
    p = tmp_path / "workpilot.yaml"
    p.write_text(yaml.dump(cfg, default_flow_style=False), encoding="utf-8")
    return p


@pytest.fixture
def empty_config(tmp_path: Path) -> Path:
    """Create a minimal workpilot.yaml with no MCP servers."""
    cfg = {"name": "test", "entrypoint": "main"}
    p = tmp_path / "workpilot.yaml"
    p.write_text(yaml.dump(cfg, default_flow_style=False), encoding="utf-8")
    return p


# ── mcp list ─────────────────────────────────────────────────────────────────


class TestMCPList:
    def test_list_servers(self, config_file: Path) -> None:
        result = runner.invoke(app, ["mcp", "list", "-c", str(config_file)])
        assert result.exit_code == 0
        assert "icm" in result.output
        assert "github" in result.output
        assert "stdio" in result.output

    def test_list_shows_agency_status(self, config_file: Path) -> None:
        result = runner.invoke(app, ["mcp", "list", "-c", str(config_file)])
        assert "agency" in result.output  # icm shows as agency

    def test_list_empty(self, empty_config: Path) -> None:
        result = runner.invoke(app, ["mcp", "list", "-c", str(empty_config)])
        assert result.exit_code == 0
        assert "No MCP servers" in result.output


# ── mcp add ──────────────────────────────────────────────────────────────────


class TestMCPAdd:
    def test_add_stdio(self, empty_config: Path) -> None:
        result = runner.invoke(
            app,
            [
                "mcp",
                "add",
                "-c",
                str(empty_config),
                "myserver",
                "--",
                "npx",
                "-y",
                "some-package",
            ],
        )
        assert result.exit_code == 0
        assert "added" in result.output

        raw = yaml.safe_load(empty_config.read_text())
        srv = raw["tools"]["mcp_servers"]["myserver"]
        assert srv["command"] == "npx"
        assert srv["args"] == ["-y", "some-package"]

    def test_add_with_env(self, empty_config: Path) -> None:
        result = runner.invoke(
            app,
            [
                "mcp",
                "add",
                "-c",
                str(empty_config),
                "-e",
                "KEY=val",
                "-e",
                "SECRET=123",
                "myserver",
                "--",
                "python",
                "server.py",
            ],
        )
        assert result.exit_code == 0

        raw = yaml.safe_load(empty_config.read_text())
        srv = raw["tools"]["mcp_servers"]["myserver"]
        assert srv["env"]["KEY"] == "val"
        assert srv["env"]["SECRET"] == "123"

    def test_add_with_timeout(self, empty_config: Path) -> None:
        result = runner.invoke(
            app,
            [
                "mcp",
                "add",
                "-c",
                str(empty_config),
                "--timeout",
                "90",
                "myserver",
                "--",
                "agency",
                "mcp",
                "icm",
            ],
        )
        assert result.exit_code == 0

        raw = yaml.safe_load(empty_config.read_text())
        assert raw["tools"]["mcp_servers"]["myserver"]["timeout"] == 90

    def test_add_http(self, empty_config: Path) -> None:
        result = runner.invoke(
            app,
            [
                "mcp",
                "add",
                "-c",
                str(empty_config),
                "--transport",
                "http",
                "corp-api",
                "--url",
                "https://mcp.corp.com/api",
            ],
        )
        assert result.exit_code == 0

        raw = yaml.safe_load(empty_config.read_text())
        srv = raw["tools"]["mcp_servers"]["corp-api"]
        assert srv["url"] == "https://mcp.corp.com/api"
        assert "command" not in srv

    def test_add_refuses_duplicate(self, config_file: Path) -> None:
        result = runner.invoke(
            app,
            [
                "mcp",
                "add",
                "-c",
                str(config_file),
                "icm",
                "--",
                "echo",
                "test",
            ],
        )
        assert result.exit_code == 1
        assert "already exists" in result.output

    def test_add_force_overwrites(self, config_file: Path) -> None:
        result = runner.invoke(
            app,
            [
                "mcp",
                "add",
                "-c",
                str(config_file),
                "--force",
                "icm",
                "--",
                "new-cmd",
                "arg1",
            ],
        )
        assert result.exit_code == 0

        raw = yaml.safe_load(config_file.read_text())
        assert raw["tools"]["mcp_servers"]["icm"]["command"] == "new-cmd"

    def test_add_stdio_no_command_errors(self, empty_config: Path) -> None:
        result = runner.invoke(
            app,
            [
                "mcp",
                "add",
                "-c",
                str(empty_config),
                "myserver",
            ],
        )
        assert result.exit_code == 1
        assert "requires a command" in result.output

    def test_add_with_namespace(self, empty_config: Path) -> None:
        result = runner.invoke(
            app,
            [
                "mcp",
                "add",
                "-c",
                str(empty_config),
                "--namespace",
                "incidents",
                "myserver",
                "--",
                "agency",
                "mcp",
                "icm",
            ],
        )
        assert result.exit_code == 0

        raw = yaml.safe_load(empty_config.read_text())
        assert raw["tools"]["mcp_servers"]["myserver"]["namespace"] == "incidents"


# ── mcp add-json ─────────────────────────────────────────────────────────────


class TestMCPAddJson:
    def test_add_json_stdio(self, empty_config: Path) -> None:
        json_str = json.dumps({"command": "agency", "args": ["mcp", "icm"], "timeout": 60})
        result = runner.invoke(
            app,
            [
                "mcp",
                "add-json",
                "-c",
                str(empty_config),
                "icm",
                json_str,
            ],
        )
        assert result.exit_code == 0

        raw = yaml.safe_load(empty_config.read_text())
        srv = raw["tools"]["mcp_servers"]["icm"]
        assert srv["command"] == "agency"
        assert srv["timeout"] == 60

    def test_add_json_http(self, empty_config: Path) -> None:
        json_str = json.dumps(
            {
                "url": "https://mcp.corp.com/api",
                "auth": {"type": "bearer", "token_env": "TOKEN"},
            }
        )
        result = runner.invoke(
            app,
            [
                "mcp",
                "add-json",
                "-c",
                str(empty_config),
                "corp-api",
                json_str,
            ],
        )
        assert result.exit_code == 0

        raw = yaml.safe_load(empty_config.read_text())
        assert raw["tools"]["mcp_servers"]["corp-api"]["url"] == "https://mcp.corp.com/api"

    def test_add_json_invalid(self, empty_config: Path) -> None:
        result = runner.invoke(
            app,
            [
                "mcp",
                "add-json",
                "-c",
                str(empty_config),
                "bad",
                "not-valid-json",
            ],
        )
        assert result.exit_code == 1
        assert "Invalid JSON" in result.output

    def test_add_json_refuses_duplicate(self, config_file: Path) -> None:
        result = runner.invoke(
            app,
            [
                "mcp",
                "add-json",
                "-c",
                str(config_file),
                "icm",
                '{"command":"echo"}',
            ],
        )
        assert result.exit_code == 1
        assert "already exists" in result.output

    def test_add_json_force(self, config_file: Path) -> None:
        result = runner.invoke(
            app,
            [
                "mcp",
                "add-json",
                "-c",
                str(config_file),
                "--force",
                "icm",
                '{"command":"new-cmd"}',
            ],
        )
        assert result.exit_code == 0

        raw = yaml.safe_load(config_file.read_text())
        assert raw["tools"]["mcp_servers"]["icm"]["command"] == "new-cmd"


# ── mcp remove ───────────────────────────────────────────────────────────────


class TestMCPRemove:
    def test_remove(self, config_file: Path) -> None:
        result = runner.invoke(app, ["mcp", "remove", "-c", str(config_file), "icm"])
        assert result.exit_code == 0
        assert "removed" in result.output

        raw = yaml.safe_load(config_file.read_text())
        assert "icm" not in raw["tools"]["mcp_servers"]

    def test_remove_not_found(self, config_file: Path) -> None:
        result = runner.invoke(app, ["mcp", "remove", "-c", str(config_file), "nonexistent"])
        assert result.exit_code == 1
        assert "not found" in result.output


# ── mcp get ──────────────────────────────────────────────────────────────────


class TestMCPGet:
    def test_get_stdio(self, config_file: Path) -> None:
        result = runner.invoke(app, ["mcp", "get", "-c", str(config_file), "icm"])
        assert result.exit_code == 0
        assert "icm" in result.output
        assert "stdio" in result.output
        assert "agency mcp icm" in result.output
        assert "Agency" in result.output
        assert "60s" in result.output

    def test_get_not_found(self, config_file: Path) -> None:
        result = runner.invoke(app, ["mcp", "get", "-c", str(config_file), "nonexistent"])
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_get_raw_json(self, config_file: Path) -> None:
        result = runner.invoke(app, ["mcp", "get", "-c", str(config_file), "--raw", "icm"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["command"] == "agency"
        assert data["timeout"] == 60

    def test_get_shows_env(self, config_file: Path) -> None:
        result = runner.invoke(app, ["mcp", "get", "-c", str(config_file), "github"])
        assert result.exit_code == 0
        assert "GITHUB_TOKEN" in result.output


# ── _discover_agency_servers ─────────────────────────────────────────────────


class TestDiscoverAgencyServers:
    def test_parses_help_output(self) -> None:
        help_text = (
            "Usage: agency mcp [OPTIONS] COMMAND\n\n"
            "Commands:\n"
            "  icm               Launch ICM MCP server via HTTP proxy\n"
            "  ado               Launch Azure DevOps MCP server via npx\n"
            "  kusto             Launch Azure Kusto MCP server\n"
            "  calculator        Launch a local calculator MCP\n"
            "  stack             Launch a local first-in, first-out Stack MCP\n"
            "  msft-learn        Launch Microsoft Learn MCP server\n"
            "  help              Show help\n"
            "  npx               Run via npx\n"
            "\nOptions:\n"
            "  --help  Show this message\n"
        )
        mock_result = MagicMock()
        mock_result.stdout = help_text
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result):
            servers = _discover_agency_servers("/usr/bin/agency")

        names = [s[0] for s in servers]
        assert names == ["icm", "ado", "kusto"]
        assert "help" not in names
        assert "npx" not in names
        assert "calculator" not in names
        assert "stack" not in names
        assert "msft-learn" not in names
        # Curated description used
        assert "incident" in servers[0][1].lower()  # icm

    def test_empty_output(self) -> None:
        mock_result = MagicMock()
        mock_result.stdout = "Usage: agency mcp\n"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result):
            servers = _discover_agency_servers("/usr/bin/agency")

        assert servers == []


# ── mcp add-agency ───────────────────────────────────────────────────────────


class TestMCPAddAgency:
    def _patch_agency(self, discovered: list[tuple[str, str]]):
        """Patch Agency CLI discovery, connection test, and arg resolution."""
        return [
            patch("workpilot.cli.mcp._ensure_agency_installed", return_value="/usr/bin/agency"),
            patch("workpilot.cli.mcp._discover_agency_servers", return_value=discovered),
            patch("workpilot.cli.mcp._test_agency_server", return_value=(True, "5 tools")),
            patch("workpilot.cli.mcp._resolve_server_args", return_value=["--org", "test"]),
        ]

    def _local_path(self, config_path: Path) -> Path:
        """Derive .local.yaml path from config path."""
        return config_path.parent / f"{config_path.stem}.local{config_path.suffix}"

    def test_add_agency_all_flag(self, empty_config: Path) -> None:
        """--all adds all discovered servers to .local.yaml."""
        patches = self._patch_agency(
            [("icm", "ICM server"), ("ado", "ADO server"), ("kusto", "Kusto server")]
        )
        for p in patches:
            p.start()
        try:
            result = runner.invoke(app, ["mcp", "add-agency", "-c", str(empty_config), "--all"])
        finally:
            for p in patches:
                p.stop()

        assert result.exit_code == 0
        assert "Added 3" in result.output

        local = self._local_path(empty_config)
        raw = yaml.safe_load(local.read_text())
        assert "icm" in raw["tools"]["mcp_servers"]
        assert raw["tools"]["mcp_servers"]["icm"]["command"] == "agency"
        assert raw["tools"]["mcp_servers"]["icm"]["args"] == ["mcp", "icm"]

    def test_add_agency_skips_existing(self, config_file: Path) -> None:
        """icm already in config_file → only kusto available."""
        patches = self._patch_agency([("icm", "ICM server"), ("kusto", "Kusto server")])
        for p in patches:
            p.start()
        try:
            result = runner.invoke(app, ["mcp", "add-agency", "-c", str(config_file), "--all"])
        finally:
            for p in patches:
                p.stop()

        assert result.exit_code == 0
        assert "Added 1" in result.output
        assert "Already configured" in result.output or "already configured" in result.output

    def test_add_agency_dry_run(self, empty_config: Path) -> None:
        patches = self._patch_agency([("icm", "ICM server"), ("ado", "ADO server")])
        for p in patches:
            p.start()
        try:
            result = runner.invoke(
                app, ["mcp", "add-agency", "-c", str(empty_config), "--all", "--dry-run"]
            )
        finally:
            for p in patches:
                p.stop()

        assert result.exit_code == 0
        assert "dry-run" in result.output

        # Nothing written to local file
        local = self._local_path(empty_config)
        assert not local.is_file()

    def test_add_agency_no_servers_found(self, empty_config: Path) -> None:
        patches = self._patch_agency([])
        for p in patches:
            p.start()
        try:
            result = runner.invoke(app, ["mcp", "add-agency", "-c", str(empty_config)])
        finally:
            for p in patches:
                p.stop()

        assert result.exit_code == 0
        assert "No MCP servers" in result.output

    def test_add_agency_all_already_configured(self, config_file: Path) -> None:
        """All discovered servers already in config → nothing to do."""
        patches = self._patch_agency([("icm", "ICM server"), ("github", "GitHub server")])
        for p in patches:
            p.start()
        try:
            result = runner.invoke(app, ["mcp", "add-agency", "-c", str(config_file)])
        finally:
            for p in patches:
                p.stop()

        assert result.exit_code == 0
        assert "already configured" in result.output

    def test_add_agency_interactive_confirm_defaults(self, empty_config: Path) -> None:
        """Interactive mode: press Enter — no-param servers selected, param servers not."""
        patches = self._patch_agency(
            [("icm", "ICM server"), ("ado", "ADO server"), ("teams", "Teams server")]
        )
        for p in patches:
            p.start()
        try:
            result = runner.invoke(app, ["mcp", "add-agency", "-c", str(empty_config)], input="\n")
        finally:
            for p in patches:
                p.stop()

        assert result.exit_code == 0
        local = self._local_path(empty_config)
        raw = yaml.safe_load(local.read_text())
        servers = raw["tools"]["mcp_servers"]
        # icm and teams have no required params → selected by default
        assert "icm" in servers
        assert "teams" in servers
        # ado needs --organization → NOT selected by default
        assert "ado" not in servers


# ── _save_mcp_servers edge cases ─────────────────────────────────────────────


class TestSaveMcpServers:
    def test_creates_section_in_empty_file(self, tmp_path: Path) -> None:
        from workpilot.cli.mcp import _save_mcp_servers

        p = tmp_path / "workpilot.yaml"
        # File doesn't exist yet
        servers = {"icm": {"command": "agency", "args": ["mcp", "icm"]}}
        _save_mcp_servers(p, servers)

        content = p.read_text()
        assert "tools:" in content
        assert "mcp_servers:" in content
        assert "icm:" in content

    def test_updates_existing_section(self, tmp_path: Path) -> None:
        from workpilot.cli.mcp import _save_mcp_servers

        p = tmp_path / "workpilot.yaml"
        p.write_text(
            "name: test\n\ntools:\n  mcp_servers:\n    icm:\n"
            '      command: "agency"\n      args: ["mcp", "icm"]\n\nchannels:\n  cli:\n',
            encoding="utf-8",
        )

        servers = {
            "icm": {"command": "agency", "args": ["mcp", "icm"]},
            "teams": {"command": "agency", "args": ["mcp", "teams"]},
        }
        _save_mcp_servers(p, servers)

        content = p.read_text()
        assert "icm:" in content
        assert "teams:" in content
        assert "channels:" in content  # preserved

    def test_idempotent_write(self, tmp_path: Path) -> None:
        from workpilot.cli.mcp import _save_mcp_servers

        p = tmp_path / "workpilot.yaml"
        p.write_text("name: test\n\nchannels:\n  cli:\n", encoding="utf-8")

        servers = {"icm": {"command": "agency", "args": ["mcp", "icm"]}}
        _save_mcp_servers(p, servers)
        content1 = p.read_text()
        _save_mcp_servers(p, servers)
        content2 = p.read_text()

        assert content1 == content2  # second write produces same result

    def test_preserves_other_content(self, tmp_path: Path) -> None:
        from workpilot.cli.mcp import _save_mcp_servers

        p = tmp_path / "workpilot.yaml"
        original = "name: test\nsecurity:\n  profile: standard\n\nchannels:\n  cli:\n"
        p.write_text(original, encoding="utf-8")

        servers = {"icm": {"command": "agency", "args": ["mcp", "icm"]}}
        _save_mcp_servers(p, servers)

        content = p.read_text()
        assert "name: test" in content
        assert "security:" in content
        assert "profile: standard" in content
        assert "channels:" in content
