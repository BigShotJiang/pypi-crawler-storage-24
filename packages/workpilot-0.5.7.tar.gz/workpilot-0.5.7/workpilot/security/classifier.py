"""Security Agent -- fast LLM classifier for tool approval.

Evaluates whether a tool call is safe to execute by sending a redacted
summary to a fast model.  Results are cached for 5 minutes to avoid
redundant LLM calls for identical tool+args combinations.

Profile shortcuts:
  - open      -> allow everything (no LLM call)
  - restricted -> deny everything (no LLM call)
  - standard / controlled -> call the classifier
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot.config.schema import SecurityProfile

if TYPE_CHECKING:
    from workpilot.providers.base import LLMProvider

# ── Regex patterns for secret-like values ────────────────────────────────────

_SECRET_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"(?i)(password|passwd|pwd)\b"),
    re.compile(r"(?i)(secret|token|api_?key|auth)\b"),
    re.compile(r"(?i)(bearer\s+\S+)"),
    re.compile(r"eyJ[A-Za-z0-9_-]{10,}"),  # JWT
    re.compile(r"ghp_[A-Za-z0-9]{36}"),  # GitHub PAT
    re.compile(r"sk-[A-Za-z0-9]{20,}"),  # OpenAI key
    re.compile(r"AKIA[A-Z0-9]{16}"),  # AWS access key
    re.compile(r"xox[bprs]-[A-Za-z0-9-]+"),  # Slack token
]

# Keys whose values are always redacted regardless of pattern match
_SENSITIVE_ARG_KEYS = frozenset(
    {
        "password",
        "secret",
        "token",
        "api_key",
        "apikey",
        "auth",
        "authorization",
        "credentials",
        "private_key",
        "access_token",
        "refresh_token",
    }
)

# ── System prompt for the classifier ─────────────────────────────────────────

_CLASSIFIER_SYSTEM_PROMPT = (
    "You are a security classifier for an AI coding assistant. "
    "Evaluate whether a tool call is safe to execute.\n"
    'Respond with JSON only: {"decision": "allow|deny|escalate", '
    '"risk": "low|medium|high|critical", "reason": "brief explanation"}\n'
    "- allow: safe to execute\n"
    "- deny: clearly dangerous or policy-violating\n"
    "- escalate: uncertain, needs human review"
)


# ── Data types ───────────────────────────────────────────────────────────────


@dataclass
class ClassifyResult:
    """Result of a security classification."""

    decision: str  # "allow" | "deny" | "escalate"
    risk: str  # "low" | "medium" | "high"
    reason: str


# ── Classifier ───────────────────────────────────────────────────────────────


class SecurityClassifier:
    """Fast LLM classifier for tool-call approval.

    Parameters
    ----------
    provider:
        An LLMProvider used to call the fast model.
    profile:
        Security profile name (``open``, ``standard``, ``controlled``,
        ``restricted``).  Determines whether the classifier is bypassed
        or invoked.
    """

    CACHE_TTL = 300  # seconds (5 minutes)
    CACHE_MAX_SIZE = 1024  # max entries before eviction sweep
    TIMEOUT = 30.0  # seconds — accommodates slower initial provider connection/auth

    def __init__(self, provider: LLMProvider, profile: str | SecurityProfile = "standard") -> None:
        self._provider = provider
        self._profile = profile.value if isinstance(profile, SecurityProfile) else profile
        self._cache: dict[str, tuple[ClassifyResult, float]] = {}

    # ── Public API ───────────────────────────────────────────────────────

    async def classify(
        self,
        tool_name: str,
        args: dict[str, Any],
        context: dict[str, Any] | None = None,
        tool_risk: str | None = None,
    ) -> ClassifyResult:
        """Classify a tool call as allow / deny / escalate.

        Returns immediately for ``open`` (allow) and ``restricted`` (deny)
        profiles.  For ``standard`` profile, low-risk tools are allowed
        without an LLM call.  For ``controlled`` profiles the fast model
        is always called.  Results are cached for ``CACHE_TTL`` seconds.

        Parameters
        ----------
        tool_risk:
            The tool's declared risk level (e.g. ``"low"``, ``"medium"``).
            When the profile is ``standard`` and *tool_risk* is ``"low"``,
            the classifier returns allow without an LLM call.
        """
        # 1. Open profile -- skip classification entirely
        if self._profile == SecurityProfile.OPEN.value:
            return ClassifyResult("allow", "low", "open profile")

        # 2. Restricted profile -- escalate everything for human approval
        if self._profile == SecurityProfile.RESTRICTED.value:
            return ClassifyResult(
                "escalate", "high", "restricted profile -- human approval required"
            )

        # 3. Standard profile + low-risk tool -- skip LLM call
        if self._profile == SecurityProfile.STANDARD.value and tool_risk == "low":
            return ClassifyResult("allow", "low", "low-risk tool in standard profile")

        # 4. Check cache
        cache_key = self._cache_key(tool_name, args, tool_risk)
        cached = self._cache.get(cache_key)
        if cached and (time.monotonic() - cached[1]) < self.CACHE_TTL:
            return cached[0]

        # 5. Redact sensitive args
        redacted_args = self._redact_args(args)

        # 6. Build classifier prompt
        prompt = self._build_prompt(tool_name, redacted_args, context)

        # 7. Call fast model with timeout
        try:
            result = await asyncio.wait_for(self._call_llm(prompt), timeout=self.TIMEOUT)
        except (TimeoutError, Exception) as exc:
            logger.warning("Security classifier timeout/error for {}: {}", tool_name, exc)
            result = ClassifyResult(
                "escalate", "medium", f"Classifier unavailable: {type(exc).__name__}"
            )

        # 8. Cache and return
        self._cache[cache_key] = (result, time.monotonic())
        if len(self._cache) > self.CACHE_MAX_SIZE:
            self._evict_expired()
        return result

    # ── Internals ────────────────────────────────────────────────────────

    def _evict_expired(self) -> None:
        """Remove expired entries from the cache.

        After evicting expired entries, if the cache is still over
        ``CACHE_MAX_SIZE``, remove oldest entries by timestamp until
        under the limit.
        """
        now = time.monotonic()
        expired = [k for k, (_, ts) in self._cache.items() if (now - ts) >= self.CACHE_TTL]
        for k in expired:
            del self._cache[k]

        # If still over max, evict oldest entries by timestamp
        if len(self._cache) > self.CACHE_MAX_SIZE:
            sorted_keys = sorted(self._cache, key=lambda k: self._cache[k][1])
            excess = len(self._cache) - self.CACHE_MAX_SIZE
            for k in sorted_keys[:excess]:
                del self._cache[k]

    async def _call_llm(self, prompt: str) -> ClassifyResult:
        """Send the classification prompt to the fast model."""
        messages = [
            {"role": "system", "content": _CLASSIFIER_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ]
        response = await self._provider.complete(
            model="fast",
            messages=messages,
            max_tokens=200,
        )
        return self._parse_response(response.content)

    def _build_prompt(
        self,
        tool_name: str,
        args: dict[str, Any],
        context: dict[str, Any] | None,
    ) -> str:
        """Build a human-readable classification request."""
        parts = [
            f"Tool: {tool_name}",
            f"Arguments: {json.dumps(args, default=str)}",
        ]
        if context:
            # Redact context values to prevent secret leakage into LLM prompt
            redacted_context = self._redact_args(context)
            parts.append(f"Context: {json.dumps(redacted_context, default=str)}")
        parts.append("Is this tool call safe to execute?")
        return "\n".join(parts)

    def _redact_args(self, args: dict[str, Any]) -> dict[str, Any]:
        """Replace values that look like secrets with ``[REDACTED]``.

        Recursively handles nested dicts and lists.
        """
        redacted: dict[str, Any] = {}
        for key, value in args.items():
            if key.lower() in _SENSITIVE_ARG_KEYS:
                redacted[key] = "[REDACTED]"
            elif isinstance(value, str) and self._looks_like_secret(value):
                redacted[key] = "[REDACTED]"
            elif isinstance(value, dict):
                redacted[key] = self._redact_args(value)
            elif isinstance(value, list):
                redacted[key] = self._redact_list(value)
            else:
                redacted[key] = value
        return redacted

    def _redact_list(self, items: list[Any]) -> list[Any]:
        """Recursively redact secrets inside a list."""
        result: list[Any] = []
        for item in items:
            if isinstance(item, str) and self._looks_like_secret(item):
                result.append("[REDACTED]")
            elif isinstance(item, dict):
                result.append(self._redact_args(item))
            elif isinstance(item, list):
                result.append(self._redact_list(item))
            else:
                result.append(item)
        return result

    @staticmethod
    def _looks_like_secret(value: str) -> bool:
        """Return ``True`` if *value* matches any known secret pattern."""
        return any(pat.search(value) for pat in _SECRET_PATTERNS)

    def _parse_response(self, content: str) -> ClassifyResult:
        """Parse JSON ``{decision, risk, reason}`` from the LLM response.

        Falls back to ``escalate`` on malformed output.
        """
        try:
            data = json.loads(content)
            decision = data.get("decision", "escalate")
            if decision not in ("allow", "deny", "escalate"):
                decision = "escalate"
            risk = data.get("risk", "medium")
            if risk not in ("low", "medium", "high", "critical"):
                risk = "high"
            reason = str(data.get("reason", ""))
            return ClassifyResult(decision, risk, reason)
        except (json.JSONDecodeError, TypeError, AttributeError):
            return ClassifyResult(
                "escalate", "medium", f"Malformed classifier response: {content!r}"
            )

    @staticmethod
    def _cache_key(tool_name: str, args: dict[str, Any], tool_risk: str | None = None) -> str:
        """Deterministic hash of tool name + sorted args + risk level."""
        payload = json.dumps(
            {"tool": tool_name, "args": sorted(args.items()), "risk": tool_risk},
            default=str,
        ).encode()
        return hashlib.md5(payload).hexdigest()  # noqa: S324
