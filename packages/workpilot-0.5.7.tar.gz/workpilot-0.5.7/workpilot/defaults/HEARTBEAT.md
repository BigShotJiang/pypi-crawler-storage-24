# Heartbeat

Check the following. Reply HEARTBEAT_OK if nothing to report.
If action is needed, fix it and notify the user via notify(channel='*').

## System
- Is MEMORY.md over 6KB? If so, summarize and trim older entries.
- Are there session files older than 30 days? If so, report count.
- Check for WorkPilot updates once per day: pip index versions workpilot

## Security
- Scan MEMORY.md for accidentally stored secrets (API keys, tokens, passwords). Remove if found.

## User Profile
- Scan workspace for languages and frameworks, update USER.md ## Tech Stack if changed.
- Review recent conversations, infer user's role language/style and preferences, update USER.md ## Preferences.
