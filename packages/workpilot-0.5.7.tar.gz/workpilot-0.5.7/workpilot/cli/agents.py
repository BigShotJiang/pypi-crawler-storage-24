"""Agents CLI subcommands — workpilot agents list|add."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.table import Table

from workpilot.cli.commands import (
    _load_config_safe,
    agents_app,
    console,
)


@agents_app.command("list")
def agents_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """List all configured agents."""
    cfg = _load_config_safe(config, profile)

    table = Table(title="Configured Agents")
    table.add_column("Name", style="bold")
    table.add_column("Model")
    table.add_column("Max Iter")
    table.add_column("Tools")
    table.add_column("Entrypoint")

    entry = cfg.entrypoint
    table.add_row(
        "default",
        cfg.agents.default.model,
        str(cfg.agents.default.max_iterations),
        ", ".join(cfg.agents.default.tools),
        "[green]yes[/green]" if entry == "default" else "",
    )
    for name, ag in cfg.agents.agents.items():
        table.add_row(
            name,
            ag.model,
            str(ag.max_iterations),
            ", ".join(ag.tools),
            "[green]yes[/green]" if entry == name else "",
        )
    console.print(table)


@agents_app.command("add")
def agents_add(
    name: str = typer.Argument(..., help="Agent name"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add a new agent interactively (appends to workpilot.yaml)."""
    import yaml

    config_path = Path(config)
    if config_path.is_dir():
        for candidate in ("workpilot.yaml", "workpilot.yml"):
            p = config_path / candidate
            if p.exists():
                config_path = p
                break
        else:
            console.print("[red]No workpilot.yaml found in directory.[/red]")
            raise typer.Exit(1)

    if not config_path.is_file():
        console.print(f"[red]Config file not found:[/red] {config_path}")
        raise typer.Exit(1)

    # Interactive prompts for agent settings
    model: str = typer.prompt("Model", default="auto")
    instructions: str = typer.prompt("Instructions", default="You are a helpful assistant.")
    max_iterations: int = int(typer.prompt("Max iterations", default="25"))

    # Load existing YAML, inject the agent, write back
    raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    agents_section = raw.setdefault("agents", {})
    agents_section[name] = {
        "model": model,
        "instructions": instructions,
        "max_iterations": max_iterations,
        "tools": [
            "shell",
            "read_file",
            "write_file",
            "edit_file",
            "list_dir",
            "git",
            "http_request",
        ],
    }
    config_path.write_text(
        yaml.dump(raw, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    console.print(f"[green]Agent '{name}' added to {config_path}[/green]")
