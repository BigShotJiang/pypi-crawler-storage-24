"""Cron CLI subcommands — workpilot cron list|add|remove|enable|disable|status|history."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.table import Table

from workpilot.cli.commands import (
    _load_config_safe,
    console,
    cron_app,
)


def _cron_config_path(config: str) -> Path:
    """Resolve and validate the config file path for cron mutations."""
    p = Path(config)
    if p.is_dir():
        for candidate in ("workpilot.yaml", "workpilot.yml"):
            if (p / candidate).exists():
                return p / candidate
        console.print("[red]No workpilot.yaml found.[/red]")
        raise typer.Exit(1)
    if not p.is_file():
        console.print(f"[red]Config not found:[/red] {p}")
        raise typer.Exit(1)
    return p


@cron_app.command("list")
def cron_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """List configured cron jobs."""
    cfg = _load_config_safe(config)

    if not cfg.cron.enabled:
        console.print("[dim]Cron service is disabled.[/dim]")
        console.print("  Set [bold]cron.enabled: true[/bold] in workpilot.yaml")
        return

    jobs = cfg.cron.jobs
    if not jobs:
        console.print("[dim]No cron jobs configured.[/dim]")
        return

    table = Table(title="Cron Jobs")
    table.add_column("Name", style="bold")
    table.add_column("Schedule")
    table.add_column("Agent")
    table.add_column("Prompt")
    table.add_column("Enabled")

    for name, job in jobs.items():
        prompt_preview = job.prompt[:50] + "..." if len(job.prompt) > 50 else job.prompt
        table.add_row(
            name,
            str(job.schedule),
            job.agent,
            prompt_preview,
            "[green]yes[/green]" if job.enabled else "[red]no[/red]",
        )

    console.print(table)


@cron_app.command("add")
def cron_add(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add a cron job interactively."""
    import yaml

    config_path = Path(config)
    if config_path.is_dir():
        for candidate in ("workpilot.yaml", "workpilot.yml"):
            p = config_path / candidate
            if p.exists():
                config_path = p
                break
        else:
            console.print("[red]No workpilot.yaml found.[/red]")
            raise typer.Exit(1)

    if not config_path.is_file():
        console.print(f"[red]Config file not found:[/red] {config_path}")
        raise typer.Exit(1)

    name: str = typer.prompt("Job name")
    schedule: str = typer.prompt("Cron schedule (e.g. '0 9 * * 1-5' for weekdays at 9am)")
    agent_name: str = typer.prompt("Agent name", default="default")
    prompt: str = typer.prompt("Prompt")

    raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    cron_section = raw.setdefault("cron", {})
    cron_section["enabled"] = True
    jobs_section = cron_section.setdefault("jobs", {})
    jobs_section[name] = {
        "schedule": schedule,
        "agent": agent_name,
        "prompt": prompt,
        "enabled": True,
    }

    config_path.write_text(
        yaml.dump(raw, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    console.print(f"[green]Cron job '{name}' added to {config_path}[/green]")


@cron_app.command("remove")
def cron_remove(
    job_id: str = typer.Argument(..., help="Job name to remove"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Remove a cron job from config."""
    import yaml

    path = _cron_config_path(config)
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    jobs = raw.get("cron", {}).get("jobs", {})
    if job_id not in jobs:
        console.print(f"[red]Job not found:[/red] {job_id}")
        raise typer.Exit(1)
    if not yes:
        typer.confirm(f"Remove job '{job_id}'?", abort=True)
    del jobs[job_id]
    path.write_text(yaml.dump(raw, default_flow_style=False, sort_keys=False), encoding="utf-8")
    console.print(f"[green]Removed job:[/green] {job_id}")


@cron_app.command("enable")
def cron_enable(
    job_id: str = typer.Argument(..., help="Job name to enable"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Enable a disabled cron job."""
    import yaml

    path = _cron_config_path(config)
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    jobs = raw.get("cron", {}).get("jobs", {})
    if job_id not in jobs:
        console.print(f"[red]Job not found:[/red] {job_id}")
        raise typer.Exit(1)
    jobs[job_id]["enabled"] = True
    path.write_text(yaml.dump(raw, default_flow_style=False, sort_keys=False), encoding="utf-8")
    console.print(f"[green]Enabled job:[/green] {job_id}")


@cron_app.command("disable")
def cron_disable(
    job_id: str = typer.Argument(..., help="Job name to disable"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Disable a cron job without removing it."""
    import yaml

    path = _cron_config_path(config)
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    jobs = raw.get("cron", {}).get("jobs", {})
    if job_id not in jobs:
        console.print(f"[red]Job not found:[/red] {job_id}")
        raise typer.Exit(1)
    jobs[job_id]["enabled"] = False
    path.write_text(yaml.dump(raw, default_flow_style=False, sort_keys=False), encoding="utf-8")
    console.print(f"[yellow]Disabled job:[/yellow] {job_id}")


@cron_app.command("status")
def cron_status(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show scheduler health and job counts."""
    cfg = _load_config_safe(config)
    enabled = cfg.cron.enabled
    jobs = cfg.cron.jobs
    enabled_count = sum(1 for j in jobs.values() if getattr(j, "enabled", True))

    table = Table(title="Cron Status")
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("Enabled", "[green]yes[/green]" if enabled else "[red]no[/red]")
    table.add_row("Total jobs", str(len(jobs)))
    table.add_row("Enabled jobs", str(enabled_count))
    table.add_row("Disabled jobs", str(len(jobs) - enabled_count))
    console.print(table)


@cron_app.command("history")
def cron_history(
    job_id: str | None = typer.Argument(None, help="Job name (omit for all jobs)"),
    lines: int = typer.Option(20, "--lines", "-n", help="Max entries to show per job"),
) -> None:
    """Show execution history for cron jobs."""
    import json as _json

    from workpilot.utils.helpers import get_data_dir

    runs_dir = get_data_dir() / "cron" / "runs"
    if not runs_dir.exists():
        console.print("[dim]No cron run history found.[/dim]")
        return

    files = sorted(runs_dir.glob("*.jsonl"))
    if job_id:
        safe = job_id.replace("/", "_").replace(":", "_")
        files = [f for f in files if f.stem == safe or f.stem == job_id]
        if not files:
            console.print(f"[red]No history for job:[/red] {job_id}")
            return

    for path in files:
        records = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                try:
                    records.append(_json.loads(line))
                except Exception:
                    pass
        records = records[-lines:]
        if not records:
            continue

        table = Table(title=f"Job: {path.stem}")
        table.add_column("Run ID", style="dim")
        table.add_column("Started")
        table.add_column("Status")
        table.add_column("Duration")
        table.add_column("Result preview")
        for r in records:
            status = r.get("status", "?")
            colour = "green" if status == "success" else "red"
            table.add_row(
                r.get("run_id", "?")[:12],
                r.get("triggered_at", "?")[:19],
                f"[{colour}]{status}[/{colour}]",
                f"{r.get('duration_s', 0):.1f}s",
                (r.get("result_preview") or r.get("error", ""))[:60],
            )
        console.print(table)
