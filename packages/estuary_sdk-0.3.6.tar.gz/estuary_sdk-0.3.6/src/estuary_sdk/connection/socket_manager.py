from __future__ import annotations

import asyncio
import logging
from typing import Any

import socketio
from estuary_sdk._utils.event_emitter import AsyncEventEmitter
from estuary_sdk.errors import ErrorCode, EstuaryError
from estuary_sdk.types import (
    AgentConversationComplete,
    AgentTurnComplete,
    AgentTurnText,
    AgentTurnVoice,
    BotResponse,
    BotVoice,
    CameraCaptureRequest,
    ConnectionState,
    EstuaryConfig,
    InterruptData,
    LiveKitTokenResponse,
    MemoryUpdatedEvent,
    QuotaExceededData,
    SessionInfo,
    SttResponse,
)

logger = logging.getLogger("estuary_sdk")


class SocketManager(AsyncEventEmitter):
    """Manages the Socket.IO connection to the Estuary gateway."""

    def __init__(self, config: EstuaryConfig) -> None:
        super().__init__()
        self._config = config
        self._sio = socketio.AsyncClient(
            reconnection=False,  # We handle reconnection ourselves
            logger=config.debug,
            engineio_logger=config.debug,
        )
        self._state = ConnectionState.DISCONNECTED
        self._session: SessionInfo | None = None
        self._reconnect_attempt = 0
        self._reconnecting = False
        self._register_handlers()

    @property
    def is_connected(self) -> bool:
        return self._state == ConnectionState.CONNECTED

    @property
    def state(self) -> ConnectionState:
        return self._state

    @property
    def session(self) -> SessionInfo | None:
        return self._session

    @property
    def sio(self) -> socketio.AsyncClient:
        return self._sio

    async def connect(self) -> SessionInfo:
        """Connect to the server, authenticate, and return session info."""
        if self._state == ConnectionState.CONNECTED:
            if self._session:
                return self._session
            raise EstuaryError("Already connected but no session", ErrorCode.UNKNOWN)

        self._set_state(ConnectionState.CONNECTING)

        session_future: asyncio.Future[SessionInfo] = asyncio.get_event_loop().create_future()
        error_future: asyncio.Future[str] = asyncio.get_event_loop().create_future()

        def on_session(data: Any) -> None:
            if not session_future.done():
                session_future.set_result(data)

        def on_auth_error(data: Any) -> None:
            msg = (
                data.get("error", "Authentication failed") if isinstance(data, dict) else str(data)
            )
            if not error_future.done():
                error_future.set_result(msg)

        self.once("session_info", on_session)
        self.once("auth_error", on_auth_error)

        try:
            auth = {
                "api_key": self._config.api_key,
                "character_id": self._config.character_id,
                "player_id": self._config.player_id,
                "audio_sample_rate": self._config.audio_sample_rate,
                "realtime_memory": self._config.realtime_memory,
            }
            url = self._config.server_url.rstrip("/")
            await self._sio.connect(
                url,
                namespaces=["/sdk"],
                auth=auth,
                transports=["websocket"],
            )
        except Exception as e:
            self._set_state(ConnectionState.ERROR)
            raise EstuaryError(
                f"Connection failed: {e}",
                ErrorCode.CONNECTION_FAILED,
                details=e,
            ) from e

        # Wait for session_info or auth_error
        done, _ = await asyncio.wait(
            [
                asyncio.ensure_future(session_future),
                asyncio.ensure_future(error_future),
            ],
            timeout=15.0,
            return_when=asyncio.FIRST_COMPLETED,
        )

        if error_future.done():
            self._set_state(ConnectionState.ERROR)
            await self._sio.disconnect()
            raise EstuaryError(
                error_future.result(),
                ErrorCode.AUTH_FAILED,
            )

        if session_future.done():
            self._session = session_future.result()
            self._reconnect_attempt = 0
            self._set_state(ConnectionState.CONNECTED)
            logger.info("Connected: session=%s", self._session.session_id)
            return self._session

        # Timeout
        self._set_state(ConnectionState.ERROR)
        await self._sio.disconnect()
        raise EstuaryError(
            "Connection timed out waiting for session_info", ErrorCode.CONNECTION_TIMEOUT
        )

    async def disconnect(self) -> None:
        """Disconnect from the server."""
        self._reconnecting = False
        if self._sio.connected:
            await self._sio.disconnect()
        self._session = None
        self._set_state(ConnectionState.DISCONNECTED)

    def emit_event(self, event: str, data: Any = None) -> None:
        """Fire-and-forget emit to the /sdk namespace."""
        if not self._sio.connected:
            logger.warning("Cannot emit '%s': not connected", event)
            return
        asyncio.ensure_future(self._sio.emit(event, data, namespace="/sdk"))

    def _set_state(self, state: ConnectionState) -> None:
        if self._state != state:
            self._state = state
            asyncio.ensure_future(self.emit("connection_state_changed", state))

    def _register_handlers(self) -> None:
        ns = "/sdk"

        @self._sio.on("session_info", namespace=ns)
        async def on_session_info(data: Any) -> None:
            parsed = SessionInfo.from_dict(data)
            self._session = parsed
            await self.emit("session_info", parsed)

        @self._sio.on("auth_error", namespace=ns)
        async def on_auth_error(data: Any) -> None:
            msg = data.get("error", str(data)) if isinstance(data, dict) else str(data)
            await self.emit("auth_error", msg)

        @self._sio.on("error", namespace=ns)
        async def on_error(data: Any) -> None:
            msg = data.get("message", str(data)) if isinstance(data, dict) else str(data)
            await self.emit("error", EstuaryError(msg))

        @self._sio.on("bot_response", namespace=ns)
        async def on_bot_response(data: Any) -> None:
            await self.emit("bot_response", BotResponse.from_dict(data))

        @self._sio.on("bot_voice", namespace=ns)
        async def on_bot_voice(data: Any) -> None:
            await self.emit("bot_voice", BotVoice.from_dict(data))

        @self._sio.on("stt_response", namespace=ns)
        async def on_stt_response(data: Any) -> None:
            await self.emit("stt_response", SttResponse.from_dict(data))

        @self._sio.on("interrupt", namespace=ns)
        async def on_interrupt(data: Any) -> None:
            await self.emit("interrupt", InterruptData.from_dict(data))

        @self._sio.on("quota_exceeded", namespace=ns)
        async def on_quota_exceeded(data: Any) -> None:
            await self.emit("quota_exceeded", QuotaExceededData.from_dict(data))

        @self._sio.on("camera_capture", namespace=ns)
        async def on_camera_capture(data: Any) -> None:
            await self.emit("camera_capture_request", CameraCaptureRequest.from_dict(data))

        @self._sio.on("livekit_token", namespace=ns)
        async def on_livekit_token(data: Any) -> None:
            await self.emit("livekit_token", LiveKitTokenResponse.from_dict(data))

        @self._sio.on("livekit_ready", namespace=ns)
        async def on_livekit_ready(data: Any) -> None:
            room = data.get("room", "") if isinstance(data, dict) else ""
            await self.emit("livekit_ready", room)

        @self._sio.on("livekit_error", namespace=ns)
        async def on_livekit_error(data: Any) -> None:
            msg = data.get("error", str(data)) if isinstance(data, dict) else str(data)
            await self.emit("livekit_error", msg)

        @self._sio.on("voice_started", namespace=ns)
        async def on_voice_started(data: Any) -> None:
            await self.emit("voice_started")

        @self._sio.on("voice_stopped", namespace=ns)
        async def on_voice_stopped(data: Any) -> None:
            await self.emit("voice_stopped")

        @self._sio.on("voice_error", namespace=ns)
        async def on_voice_error(data: Any) -> None:
            msg = data.get("error", str(data)) if isinstance(data, dict) else str(data)
            await self.emit("voice_error", msg)

        @self._sio.on("memory_updated", namespace=ns)
        async def on_memory_updated(data: Any) -> None:
            await self.emit("memory_updated", MemoryUpdatedEvent.from_dict(data))

        @self._sio.on("agent_turn_text", namespace=ns)
        async def on_agent_turn_text(data: Any) -> None:
            await self.emit("agent_turn_text", AgentTurnText.from_dict(data))

        @self._sio.on("agent_turn_voice", namespace=ns)
        async def on_agent_turn_voice(data: Any) -> None:
            await self.emit("agent_turn_voice", AgentTurnVoice.from_dict(data))

        @self._sio.on("agent_turn_complete", namespace=ns)
        async def on_agent_turn_complete(data: Any) -> None:
            await self.emit("agent_turn_complete", AgentTurnComplete.from_dict(data))

        @self._sio.on("agent_conversation_complete", namespace=ns)
        async def on_agent_conversation_complete(data: Any) -> None:
            await self.emit(
                "agent_conversation_complete",
                AgentConversationComplete.from_dict(data),
            )

        @self._sio.on("disconnect", namespace=ns)
        async def on_disconnect() -> None:
            logger.info("Disconnected from server")
            prev_state = self._state
            self._set_state(ConnectionState.DISCONNECTED)
            await self.emit("disconnected", "transport_close")
            if (
                prev_state == ConnectionState.CONNECTED
                and self._config.auto_reconnect
                and not self._reconnecting
            ):
                asyncio.ensure_future(self._auto_reconnect())

    async def _auto_reconnect(self) -> None:
        """Attempt automatic reconnection with exponential backoff."""
        self._reconnecting = True
        self._set_state(ConnectionState.RECONNECTING)

        while self._reconnecting and self._reconnect_attempt < self._config.max_reconnect_attempts:
            self._reconnect_attempt += 1
            delay = self._config.reconnect_delay * (2 ** (self._reconnect_attempt - 1))
            logger.info(
                "Reconnect attempt %d/%d in %.1fs",
                self._reconnect_attempt,
                self._config.max_reconnect_attempts,
                delay,
            )
            await self.emit("reconnecting", self._reconnect_attempt)
            await asyncio.sleep(delay)

            if not self._reconnecting:
                break

            try:
                await self.connect()
                self._reconnecting = False
                return
            except EstuaryError:
                logger.warning("Reconnect attempt %d failed", self._reconnect_attempt)

        self._reconnecting = False
        self._set_state(ConnectionState.ERROR)
        await self.emit(
            "error",
            EstuaryError(
                "Max reconnection attempts reached",
                ErrorCode.CONNECTION_FAILED,
            ),
        )
