from __future__ import annotations

import asyncio
import base64
import logging

from estuary_sdk.connection.socket_manager import SocketManager
from estuary_sdk.errors import ErrorCode, EstuaryError
from estuary_sdk.types import VoiceMode

logger = logging.getLogger("estuary_sdk")


class WebSocketVoiceManager:
    """Voice manager that streams audio over Socket.IO WebSocket.

    Supports two modes:
    - CONTINUOUS: Audio streams continuously after start(). Server uses VAD
      for turn detection.
    - PUSH_TO_TALK: Audio only streams between start_recording() and
      stop_recording() calls. stop_recording() signals end-of-turn.
    """

    def __init__(
        self,
        socket_manager: SocketManager,
        sample_rate: int = 24000,
        voice_mode: VoiceMode = VoiceMode.CONTINUOUS,
        start_timeout: float = 10.0,
    ) -> None:
        self._socket = socket_manager
        self._sample_rate = sample_rate
        self._voice_mode = voice_mode
        self._start_timeout = start_timeout
        self._active = False
        self._muted = False
        self._recording = False
        self._recorder_task: asyncio.Task[None] | None = None

    @property
    def is_muted(self) -> bool:
        return self._muted

    @property
    def is_active(self) -> bool:
        return self._active

    async def start(self) -> None:
        """Start voice session. Emits start_voice and waits for server confirmation."""
        if self._active:
            logger.warning("Voice already active")
            return

        loop = asyncio.get_event_loop()
        started_future: asyncio.Future[None] = loop.create_future()
        error_future: asyncio.Future[str] = loop.create_future()

        def on_started() -> None:
            if not started_future.done():
                started_future.set_result(None)

        def on_error(msg: str) -> None:
            if not error_future.done():
                error_future.set_result(msg)

        self._socket.once("voice_started", on_started)
        self._socket.once("voice_error", on_error)

        self._socket.emit_event("start_voice")

        done, _ = await asyncio.wait(
            [
                asyncio.ensure_future(started_future),
                asyncio.ensure_future(error_future),
            ],
            timeout=self._start_timeout,
            return_when=asyncio.FIRST_COMPLETED,
        )

        # Clean up whichever listener didn't fire
        if not started_future.done():
            self._socket.off("voice_started", on_started)
        if not error_future.done():
            self._socket.off("voice_error", on_error)

        if error_future.done():
            raise EstuaryError(
                f"Voice start failed: {error_future.result()}",
                ErrorCode.VOICE_START_FAILED,
            )

        if started_future.done():
            self._active = True
            logger.debug("Voice started (mode=%s)", self._voice_mode.value)
            return

        # Timeout
        raise EstuaryError(
            "Timed out waiting for voice_started confirmation",
            ErrorCode.VOICE_START_FAILED,
        )

    async def stop(self) -> None:
        """Stop voice session. Emits stop_voice to end STT on server."""
        if not self._active:
            return

        if self._recording:
            await self.stop_recording()

        self._active = False
        self._socket.emit_event("stop_voice")
        logger.debug("Voice stopped")

    async def start_recording(self) -> None:
        """Begin streaming audio (PTT mode).

        In continuous mode, this is a no-op since audio streams continuously.
        In PTT mode, this begins the audio capture window.
        """
        if not self._active:
            logger.warning("Cannot start recording: voice not active")
            return

        if self._voice_mode == VoiceMode.CONTINUOUS:
            return

        if self._recording:
            logger.warning("Already recording")
            return

        self._recording = True
        # In PTT mode, start_voice begins each recording segment
        self._socket.emit_event("start_voice")
        logger.debug("PTT recording started")

    async def stop_recording(self) -> None:
        """Stop streaming audio (PTT mode).

        Emits stop_voice to signal end-of-turn, then re-emits start_voice
        to keep the STT session ready for the next recording.
        """
        if not self._active or not self._recording:
            return

        if self._voice_mode == VoiceMode.CONTINUOUS:
            return

        self._recording = False
        # Signal end-of-turn
        self._socket.emit_event("stop_voice")
        logger.debug("PTT recording stopped (end of turn)")

    async def send_audio(self, audio: bytes) -> None:
        """Send raw PCM16 audio bytes to the server as base64.

        Args:
            audio: Raw PCM16 audio bytes (16-bit signed integer, mono).
        """
        if not self._active:
            return
        if self._muted:
            return
        if self._voice_mode == VoiceMode.PUSH_TO_TALK and not self._recording:
            return

        encoded = base64.b64encode(audio).decode("ascii")
        self._socket.emit_event("stream_audio", {"audio": encoded})

    def toggle_mute(self) -> None:
        """Toggle audio mute state."""
        self._muted = not self._muted
        logger.debug("Mute toggled: %s", self._muted)

    async def dispose(self) -> None:
        """Clean up resources."""
        if self._active:
            await self.stop()
        self._recording = False
