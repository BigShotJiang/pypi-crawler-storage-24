from __future__ import annotations

import asyncio
import logging
from typing import Any

import aiohttp
from estuary_sdk.errors import ErrorCode, EstuaryError
from estuary_sdk.types import RetryConfig

logger = logging.getLogger("estuary_sdk")


class RestClient:
    """HTTP client for Estuary REST API endpoints."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float = 60.0,
        retry_config: RetryConfig | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout
        self._retry_config = retry_config
        self._session: aiohttp.ClientSession | None = None

    def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers={"X-API-Key": self._api_key},
            )
        return self._session

    async def get(self, path: str, params: dict[str, Any] | None = None, headers: dict[str, str] | None = None) -> dict[str, Any]:
        return await self._request("GET", path, params=params, headers=headers)

    async def post(
        self,
        path: str,
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("POST", path, json=body, headers=headers)

    async def put(self, path: str, body: dict[str, Any] | None = None) -> dict[str, Any]:
        return await self._request("PUT", path, json=body)

    async def patch(self, path: str, body: dict[str, Any] | None = None) -> dict[str, Any]:
        return await self._request("PATCH", path, json=body)

    async def delete(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        return await self._request("DELETE", path, params=params)

    async def post_form(
        self,
        path: str,
        data: aiohttp.FormData,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """POST multipart form data (e.g. file uploads).

        File uploads are NOT retried (not idempotent). Timeout still applies.
        """
        url = f"{self._base_url}{path}"
        session = self._get_session()
        client_timeout = aiohttp.ClientTimeout(total=self._timeout)
        try:
            async with session.post(
                url, data=data, headers=headers, timeout=client_timeout
            ) as resp:
                if resp.status >= 400:
                    text = await resp.text()
                    raise EstuaryError(
                        f"REST POST {path} failed ({resp.status}): {text}",
                        ErrorCode.REST_ERROR,
                        details={"status": resp.status, "body": text},
                    )
                return await resp.json()  # type: ignore[no-any-return]
        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            raise EstuaryError(
                f"REST request failed: {e}",
                ErrorCode.REST_ERROR,
                details=e,
            ) from e

    @staticmethod
    def _sanitize_params(params: dict[str, Any] | None) -> dict[str, Any] | None:
        """Convert bool values in query params to lowercase strings.

        aiohttp/yarl only accepts str, int, and float in query params.
        Python bool values (True/False) cause a TypeError, so we convert
        them to their lowercase string equivalents ("true"/"false").
        """
        if params is None:
            return None
        return {k: str(v).lower() if isinstance(v, bool) else v for k, v in params.items()}

    async def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        url = f"{self._base_url}{path}"
        session = self._get_session()
        client_timeout = aiohttp.ClientTimeout(total=self._timeout)
        retry = self._retry_config
        max_attempts = 1 + (retry.max_retries if retry else 0)

        last_error: Exception | None = None
        for attempt in range(max_attempts):
            try:
                async with session.request(
                    method,
                    url,
                    params=self._sanitize_params(params),
                    json=json,
                    headers=headers,
                    timeout=client_timeout,
                ) as resp:
                    if resp.status >= 400:
                        text = await resp.text()
                        if retry and resp.status in retry.retry_on_status and attempt < max_attempts - 1:
                            delay = retry.backoff_factor * (2**attempt)
                            logger.warning(
                                "REST %s %s returned %d, retrying in %.1fs (attempt %d/%d)",
                                method,
                                path,
                                resp.status,
                                delay,
                                attempt + 1,
                                max_attempts,
                            )
                            await asyncio.sleep(delay)
                            continue
                        raise EstuaryError(
                            f"REST {method} {path} failed ({resp.status}): {text}",
                            ErrorCode.REST_ERROR,
                            details={"status": resp.status, "body": text},
                        )
                    return await resp.json()  # type: ignore[no-any-return]
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                last_error = e
                if retry and attempt < max_attempts - 1:
                    delay = retry.backoff_factor * (2**attempt)
                    logger.warning(
                        "REST %s %s failed (%s), retrying in %.1fs (attempt %d/%d)",
                        method,
                        path,
                        type(e).__name__,
                        delay,
                        attempt + 1,
                        max_attempts,
                    )
                    await asyncio.sleep(delay)
                    continue
                raise EstuaryError(
                    f"REST request failed: {e}",
                    ErrorCode.REST_ERROR,
                    details=e,
                ) from e

        # Should not reach here, but just in case
        raise EstuaryError(
            f"REST request failed after {max_attempts} attempts",
            ErrorCode.REST_ERROR,
            details=last_error,
        )

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None
