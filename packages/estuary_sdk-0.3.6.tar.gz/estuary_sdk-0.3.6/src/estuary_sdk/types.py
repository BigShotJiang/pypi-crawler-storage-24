from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Literal


class ConnectionState(str, Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    ERROR = "error"


class VoiceMode(str, Enum):
    CONTINUOUS = "continuous"
    PUSH_TO_TALK = "push_to_talk"


VoiceTransport = Literal["websocket", "livekit", "auto"]


@dataclass
class RetryConfig:
    """Configuration for HTTP request retries."""

    max_retries: int = 3
    backoff_factor: float = 1.0
    retry_on_status: tuple[int, ...] = (500, 502, 503, 504)


# ---------------------------------------------------------------------------
# Agent-to-agent conversation event types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AgentTurnText:
    """Streaming text from an agent during an agent-to-agent conversation."""

    agent_id: str = ""
    text: str = ""
    chunk_index: int = 0
    turn_number: int = 0
    is_final: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AgentTurnText:
        return cls(
            agent_id=data.get("agent_id", ""),
            text=data.get("text", ""),
            chunk_index=data.get("chunk_index", 0),
            turn_number=data.get("turn_number", 0),
            is_final=data.get("is_final", False),
        )


@dataclass(frozen=True)
class AgentTurnVoice:
    """Streaming voice audio from an agent during an agent-to-agent conversation."""

    agent_id: str = ""
    audio: str = ""
    chunk_index: int = 0
    turn_number: int = 0
    is_final: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AgentTurnVoice:
        return cls(
            agent_id=data.get("agent_id", ""),
            audio=data.get("audio", ""),
            chunk_index=data.get("chunk_index", 0),
            turn_number=data.get("turn_number", 0),
            is_final=data.get("is_final", False),
        )


@dataclass(frozen=True)
class AgentTurnComplete:
    """Emitted when an agent finishes a turn in an agent-to-agent conversation."""

    agent_id: str = ""
    text: str = ""
    turn_number: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AgentTurnComplete:
        return cls(
            agent_id=data.get("agent_id", ""),
            text=data.get("text", ""),
            turn_number=data.get("turn_number", 0),
        )


@dataclass(frozen=True)
class AgentConversationComplete:
    """Emitted when an agent-to-agent conversation finishes."""

    winner_agent_id: str = ""
    reason: str = ""
    total_turns: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AgentConversationComplete:
        return cls(
            winner_agent_id=data.get("winner_agent_id", ""),
            reason=data.get("reason", ""),
            total_turns=data.get("total_turns", 0),
        )


@dataclass
class EstuaryConfig:
    server_url: str
    api_key: str
    character_id: str
    player_id: str
    audio_sample_rate: int = 24000
    auto_reconnect: bool = True
    max_reconnect_attempts: int = 5
    reconnect_delay: float = 1.0
    debug: bool = False
    voice_transport: VoiceTransport = "websocket"
    realtime_memory: bool = False


@dataclass(frozen=True)
class SessionInfo:
    session_id: str
    conversation_id: str
    character_id: str
    player_id: str
    livekit_token: str | None = None
    livekit_url: str | None = None
    livekit_room: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SessionInfo:
        return cls(
            session_id=data.get("session_id", ""),
            conversation_id=data.get("conversation_id", ""),
            character_id=data.get("character_id", ""),
            player_id=data.get("player_id", ""),
            livekit_token=data.get("livekitToken"),
            livekit_url=data.get("livekitUrl"),
            livekit_room=data.get("livekitRoom"),
        )


@dataclass(frozen=True)
class BotResponse:
    text: str = ""
    is_final: bool = False
    partial: str = ""
    message_id: str = ""
    chunk_index: int = 0
    is_interjection: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BotResponse:
        return cls(
            text=data.get("text", ""),
            is_final=data.get("is_final", False),
            partial=data.get("partial", ""),
            message_id=data.get("message_id", ""),
            chunk_index=data.get("chunk_index", 0),
            is_interjection=data.get("is_interjection", False),
        )


@dataclass(frozen=True)
class BotVoice:
    audio: str = ""
    message_id: str = ""
    chunk_index: int = 0
    is_final: bool = False
    is_livekit: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BotVoice:
        return cls(
            audio=data.get("audio", ""),
            message_id=data.get("message_id", ""),
            chunk_index=data.get("chunk_index", 0),
            is_final=data.get("is_final", False),
            is_livekit=data.get("is_livekit", False),
        )


@dataclass(frozen=True)
class SttResponse:
    text: str = ""
    is_final: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SttResponse:
        return cls(
            text=data.get("text", ""),
            is_final=data.get("is_final", False),
        )


@dataclass(frozen=True)
class InterruptData:
    message_id: str | None = None
    reason: str | None = None
    interrupted_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> InterruptData:
        return cls(
            message_id=data.get("message_id"),
            reason=data.get("reason"),
            interrupted_at=data.get("interrupted_at"),
        )


@dataclass(frozen=True)
class QuotaExceededData:
    message: str = ""
    current: int = 0
    limit: int = 0
    remaining: int = 0
    tier: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> QuotaExceededData:
        return cls(
            message=data.get("message", ""),
            current=data.get("current", 0),
            limit=data.get("limit", 0),
            remaining=data.get("remaining", 0),
            tier=data.get("tier", ""),
        )


@dataclass(frozen=True)
class LiveKitTokenResponse:
    token: str = ""
    url: str = ""
    room: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LiveKitTokenResponse:
        return cls(
            token=data.get("token", ""),
            url=data.get("url", ""),
            room=data.get("room", ""),
        )


@dataclass(frozen=True)
class CameraCaptureRequest:
    request_id: str = ""
    text: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CameraCaptureRequest:
        return cls(
            request_id=data.get("request_id", ""),
            text=data.get("text"),
        )


@dataclass(frozen=True)
class MemoryData:
    """Memory data from the server. Uses camelCase keys matching Memory.to_dict()."""

    id: str = ""
    user_id: str = ""
    agent_id: str = ""
    player_id: str = ""
    content: str = ""
    memory_type: str = ""
    confidence: float = 1.0
    status: str = "active"
    source_conversation_id: str = ""
    source_quote: str = ""
    source: str = "text_chat"
    topic: str = ""
    secondary_topics: list[str] = field(default_factory=list)
    last_accessed_at: str | None = None
    access_count: int = 0
    extracted_at: str | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemoryData:
        """Parse from wire format (camelCase keys from Memory.to_dict())."""
        return cls(
            id=data.get("id", ""),
            user_id=data.get("userId", ""),
            agent_id=data.get("agentId", ""),
            player_id=data.get("playerId", ""),
            content=data.get("content", ""),
            memory_type=data.get("memoryType", ""),
            confidence=data.get("confidence", 1.0),
            status=data.get("status", "active"),
            source_conversation_id=data.get("sourceConversationId", ""),
            source_quote=data.get("sourceQuote", ""),
            source=data.get("source", "text_chat"),
            topic=data.get("topic", ""),
            secondary_topics=data.get("secondaryTopics", []),
            last_accessed_at=data.get("lastAccessedAt"),
            access_count=data.get("accessCount", 0),
            extracted_at=data.get("extractedAt"),
            created_at=data.get("createdAt"),
            updated_at=data.get("updatedAt"),
        )


@dataclass(frozen=True)
class MemoryUpdatedEvent:
    agent_id: str = ""
    player_id: str = ""
    memories_extracted: int = 0
    facts_extracted: int = 0
    conversation_id: str = ""
    new_memories: list[MemoryData] = field(default_factory=list)
    timestamp: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemoryUpdatedEvent:
        return cls(
            agent_id=data.get("agent_id", ""),
            player_id=data.get("player_id", ""),
            memories_extracted=data.get("memories_extracted", 0),
            facts_extracted=data.get("facts_extracted", 0),
            conversation_id=data.get("conversation_id", ""),
            new_memories=[MemoryData.from_dict(m) for m in data.get("new_memories", [])],
            timestamp=data.get("timestamp", ""),
        )


@dataclass(frozen=True)
class GeneratedCharacter:
    """Response from the image-to-character generation endpoint.

    Maps the camelCase keys from Agent.to_dict().
    """

    id: str = ""
    name: str = ""
    tagline: str = ""
    personality: str = ""
    background: str = ""
    appearance: str = ""
    avatar: str | None = None
    voice_preset: str | None = None
    generated_voice_id: str | None = None
    model_url: str | None = None
    model_preview_url: str | None = None
    model_status: str | None = None
    source_image_url: str | None = None
    player_id: str | None = None
    is_active: bool = True
    created_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GeneratedCharacter:
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            tagline=data.get("tagline", ""),
            personality=data.get("personality", ""),
            background=data.get("background", ""),
            appearance=data.get("appearance", ""),
            avatar=data.get("avatar"),
            voice_preset=data.get("voicePreset"),
            generated_voice_id=data.get("generatedVoiceId"),
            model_url=data.get("modelUrl"),
            model_preview_url=data.get("modelPreviewUrl"),
            model_status=data.get("modelStatus"),
            source_image_url=data.get("sourceImageUrl"),
            player_id=data.get("playerId"),
            is_active=data.get("isActive", True),
            created_at=data.get("createdAt"),
        )


@dataclass(frozen=True)
class ModelStatus:
    """Response from the model-status polling endpoint."""

    model_status: str | None = None
    model_preview_url: str | None = None
    model_url: str | None = None
    thumbnail_url: str | None = None
    progress: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ModelStatus:
        return cls(
            model_status=data.get("modelStatus"),
            model_preview_url=data.get("modelPreviewUrl"),
            model_url=data.get("modelUrl"),
            thumbnail_url=data.get("thumbnailUrl"),
            progress=data.get("progress", 0),
        )


@dataclass(frozen=True)
class ActionParameter:
    """Parameter for a character action."""

    name: str = ""
    type: str = "string"
    required: bool = False
    description: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ActionParameter:
        return cls(
            name=data.get("name", ""),
            type=data.get("type", "string"),
            required=data.get("required", False),
            description=data.get("description"),
        )


@dataclass(frozen=True)
class AgentAction:
    """An action the character can perform."""

    name: str = ""
    description: str | None = None
    parameters: list[ActionParameter] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AgentAction:
        return cls(
            name=data.get("name", ""),
            description=data.get("description"),
            parameters=[ActionParameter.from_dict(p) for p in data.get("parameters", [])],
        )


@dataclass(frozen=True)
class Character:
    """Character returned by the Characters API. Uses snake_case keys (Pydantic serialization)."""

    id: str = ""
    name: str = ""
    tagline: str | None = None
    personality: str | None = None
    background: str | None = None
    avatar: str | None = None
    system_prompt: str | None = None

    # Voice
    voice_preset: str | None = None
    tts_provider: str = "elevenlabs"
    tts_model: str = "eleven_flash_v2_5"
    tts_voice: str | None = None
    tts_speed: float = 1.0

    # VLM
    vlm_model: str = "gpt-4.1-mini"

    # LLM
    llm_provider: str = "openai"
    llm_model: str = "gpt-5-mini"
    llm_temperature: float = 0.7
    llm_max_tokens: int = 2048
    llm_verbosity: str = "medium"

    # STT
    stt_provider: str = "deepgram"
    stt_language: str = "en"

    # VAD
    vad_sensitivity: float = 0.5
    vad_min_speech_duration_ms: int = 250

    # Runtime
    text_only: bool = True
    verbose: bool = False

    # Actions
    actions: list[AgentAction] = field(default_factory=list)

    # Ownership
    player_id: str | None = None

    # Metadata
    is_public: bool = False
    is_active: bool = False
    launch_status: str = "stopped"
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Character:
        """Parse from wire format (snake_case keys from Pydantic serialization)."""
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            tagline=data.get("tagline"),
            personality=data.get("personality"),
            background=data.get("background"),
            avatar=data.get("avatar"),
            system_prompt=data.get("system_prompt"),
            voice_preset=data.get("voice_preset"),
            tts_provider=data.get("tts_provider", "elevenlabs"),
            tts_model=data.get("tts_model", "eleven_flash_v2_5"),
            tts_voice=data.get("tts_voice"),
            tts_speed=data.get("tts_speed", 1.0),
            vlm_model=data.get("vlm_model", "gpt-4.1-mini"),
            llm_provider=data.get("llm_provider", "openai"),
            llm_model=data.get("llm_model", "gpt-5-mini"),
            llm_temperature=data.get("llm_temperature", 0.7),
            llm_max_tokens=data.get("llm_max_tokens", 2048),
            llm_verbosity=data.get("llm_verbosity", "medium"),
            stt_provider=data.get("stt_provider", "deepgram"),
            stt_language=data.get("stt_language", "en"),
            vad_sensitivity=data.get("vad_sensitivity", 0.5),
            vad_min_speech_duration_ms=data.get("vad_min_speech_duration_ms", 250),
            text_only=data.get("text_only", True),
            verbose=data.get("verbose", False),
            actions=[AgentAction.from_dict(a) for a in data.get("actions", [])],
            player_id=data.get("player_id"),
            is_public=data.get("is_public", False),
            is_active=data.get("is_active", False),
            launch_status=data.get("launch_status", "stopped"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )


@dataclass(frozen=True)
class CharacterListResponse:
    """Paginated character list."""

    characters: list[Character] = field(default_factory=list)
    total: int = 0
    limit: int = 20
    offset: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CharacterListResponse:
        return cls(
            characters=[Character.from_dict(c) for c in data.get("characters", [])],
            total=data.get("total", 0),
            limit=data.get("limit", 20),
            offset=data.get("offset", 0),
        )


# ---------------------------------------------------------------------------
# Memory / Graph response models
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MemoryListResponse:
    """Paginated memory list."""

    memories: list[MemoryData] = field(default_factory=list)
    total: int = 0
    limit: int = 50
    offset: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemoryListResponse:
        return cls(
            memories=[MemoryData.from_dict(m) for m in data.get("memories", [])],
            total=data.get("total", 0),
            limit=data.get("limit", 50),
            offset=data.get("offset", 0),
        )


@dataclass(frozen=True)
class TimelineEntry:
    """A single date group in the memory timeline."""

    date: str = ""
    memories: list[MemoryData] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TimelineEntry:
        return cls(
            date=data.get("date", ""),
            memories=[MemoryData.from_dict(m) for m in data.get("memories", [])],
        )


@dataclass(frozen=True)
class MemoryTimeline:
    """Memory timeline grouped by date."""

    timeline: list[TimelineEntry] = field(default_factory=list)
    total_memories: int = 0
    group_by: str = "day"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemoryTimeline:
        return cls(
            timeline=[TimelineEntry.from_dict(t) for t in data.get("timeline", [])],
            total_memories=data.get("totalMemories", 0),
            group_by=data.get("groupBy", "day"),
        )


@dataclass(frozen=True)
class MemoryStats:
    """Memory statistics."""

    total_active: int = 0
    total_superseded: int = 0
    total_decayed: int = 0
    by_type: dict[str, int] = field(default_factory=dict)
    core_facts: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemoryStats:
        return cls(
            total_active=data.get("totalActive", 0),
            total_superseded=data.get("totalSuperseded", 0),
            total_decayed=data.get("totalDecayed", 0),
            by_type=data.get("byType", {}),
            core_facts=data.get("coreFacts", 0),
        )


@dataclass(frozen=True)
class CoreFact:
    """A core fact derived from memories. Uses camelCase keys."""

    id: str = ""
    user_id: str = ""
    agent_id: str = ""
    player_id: str = ""
    fact_key: str = ""
    fact_value: str = ""
    source_memory_id: str | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CoreFact:
        return cls(
            id=data.get("id", ""),
            user_id=data.get("userId", ""),
            agent_id=data.get("agentId", ""),
            player_id=data.get("playerId", ""),
            fact_key=data.get("factKey", ""),
            fact_value=data.get("factValue", ""),
            source_memory_id=data.get("sourceMemoryId"),
            created_at=data.get("createdAt"),
            updated_at=data.get("updatedAt"),
        )


@dataclass(frozen=True)
class CoreFactsResponse:
    """Response from the core facts endpoint."""

    core_facts: list[CoreFact] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CoreFactsResponse:
        return cls(
            core_facts=[CoreFact.from_dict(f) for f in data.get("coreFacts", [])],
        )


@dataclass(frozen=True)
class MemorySearchResult:
    """A single search result with score."""

    memory: MemoryData = field(default_factory=MemoryData)
    score: float = 0.0
    similarity_score: float = 0.0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemorySearchResult:
        return cls(
            memory=MemoryData.from_dict(data.get("memory", {})),
            score=data.get("score", 0.0),
            similarity_score=data.get("similarityScore", 0.0),
        )


@dataclass(frozen=True)
class MemorySearchResponse:
    """Response from memory search."""

    results: list[MemorySearchResult] = field(default_factory=list)
    query: str = ""
    total: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemorySearchResponse:
        return cls(
            results=[MemorySearchResult.from_dict(r) for r in data.get("results", [])],
            query=data.get("query", ""),
            total=data.get("total", 0),
        )


@dataclass(frozen=True)
class MemoryDeleteResponse:
    """Response from memory deletion."""

    message: str = ""
    deleted_count: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemoryDeleteResponse:
        return cls(
            message=data.get("message", ""),
            deleted_count=data.get("deletedCount", 0),
        )


@dataclass(frozen=True)
class GraphNode:
    """A node in the memory knowledge graph.

    Union-style: optional fields per node type (user/cluster/memory/entity).
    """

    id: str = ""
    type: str = ""
    # User node
    label: str | None = None
    # Cluster node
    memory_count: int | None = None
    level: int | None = None
    parent_cluster_id: str | None = None
    child_cluster_ids: list[str] = field(default_factory=list)
    pending_label: bool = False
    # Memory node
    content: str | None = None
    memory_type: str | None = None
    confidence: float | None = None
    created_at: str | None = None
    topic: str | None = None
    # Entity node
    entity_type: str | None = None
    name: str | None = None
    mention_count: int | None = None
    extra_data: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GraphNode:
        return cls(
            id=data.get("id", ""),
            type=data.get("type", ""),
            label=data.get("label"),
            memory_count=data.get("memoryCount"),
            level=data.get("level"),
            parent_cluster_id=data.get("parentClusterId"),
            child_cluster_ids=data.get("childClusterIds", []),
            pending_label=data.get("pendingLabel", False),
            content=data.get("content"),
            memory_type=data.get("memoryType"),
            confidence=data.get("confidence"),
            created_at=data.get("createdAt"),
            topic=data.get("topic"),
            entity_type=data.get("entityType"),
            name=data.get("name"),
            mention_count=data.get("mentionCount"),
            extra_data=data.get("extraData", {}),
        )


@dataclass(frozen=True)
class GraphEdge:
    """An edge in the memory knowledge graph."""

    source: str = ""
    target: str = ""
    type: str = ""
    # Relationship edges
    relationship_type: str | None = None
    label: str | None = None
    confidence: float | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GraphEdge:
        return cls(
            source=data.get("source", ""),
            target=data.get("target", ""),
            type=data.get("type", ""),
            relationship_type=data.get("relationshipType"),
            label=data.get("label"),
            confidence=data.get("confidence"),
        )


@dataclass(frozen=True)
class GraphStats:
    """Statistics for the memory graph."""

    total_memories: int = 0
    total_entities: int = 0
    cluster_count: int = 0
    clusters: dict[str, int] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GraphStats:
        return cls(
            total_memories=data.get("totalMemories", 0),
            total_entities=data.get("totalEntities", 0),
            cluster_count=data.get("clusterCount", 0),
            clusters=data.get("clusters", {}),
        )


@dataclass(frozen=True)
class MemoryGraph:
    """The full memory knowledge graph."""

    nodes: list[GraphNode] = field(default_factory=list)
    edges: list[GraphEdge] = field(default_factory=list)
    stats: GraphStats = field(default_factory=GraphStats)
    stale: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemoryGraph:
        return cls(
            nodes=[GraphNode.from_dict(n) for n in data.get("nodes", [])],
            edges=[GraphEdge.from_dict(e) for e in data.get("edges", [])],
            stats=GraphStats.from_dict(data.get("stats", {})),
            stale=data.get("stale", False),
        )


# ---------------------------------------------------------------------------
# Players API response models
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Pagination:
    """Pagination metadata for paged endpoints."""

    page: int = 1
    limit: int = 100
    total: int = 0
    has_more: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Pagination:
        return cls(
            page=data.get("page", 1),
            limit=data.get("limit", 100),
            total=data.get("total", 0),
            has_more=data.get("hasMore", False),
        )


@dataclass(frozen=True)
class PlayerConversation:
    """A player's conversation. Uses camelCase keys from PlayerConversation.to_dict()."""

    id: str = ""
    character_id: str = ""
    player_id: str = ""
    api_key_id: str | None = None
    created_at: str | None = None
    last_activity: str | None = None
    message_count: int = 0
    last_memory_extraction_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PlayerConversation:
        return cls(
            id=data.get("id", ""),
            character_id=data.get("characterId", ""),
            player_id=data.get("playerId", ""),
            api_key_id=data.get("apiKeyId"),
            created_at=data.get("createdAt"),
            last_activity=data.get("lastActivity"),
            message_count=data.get("messageCount", 0),
            last_memory_extraction_at=data.get("lastMemoryExtractionAt"),
        )


@dataclass(frozen=True)
class PlayerConversationList:
    """Paginated list of player conversations."""

    conversations: list[PlayerConversation] = field(default_factory=list)
    total: int = 0
    limit: int = 50
    offset: int = 0
    sort_by: str = "last_activity"
    sort_order: str = "desc"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PlayerConversationList:
        return cls(
            conversations=[
                PlayerConversation.from_dict(c) for c in data.get("conversations", [])
            ],
            total=data.get("total", 0),
            limit=data.get("limit", 50),
            offset=data.get("offset", 0),
            sort_by=data.get("sortBy", "last_activity"),
            sort_order=data.get("sortOrder", "desc"),
        )


@dataclass(frozen=True)
class PlayerStats:
    """Player statistics. Uses camelCase keys."""

    total_conversations: int = 0
    total_messages: int = 0
    first_activity: str | None = None
    last_activity: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PlayerStats:
        return cls(
            total_conversations=data.get("totalConversations", 0),
            total_messages=data.get("totalMessages", 0),
            first_activity=data.get("firstActivity"),
            last_activity=data.get("lastActivity"),
        )


@dataclass(frozen=True)
class PlayerMessage:
    """A single message in a player conversation. Uses camelCase keys."""

    id: int = 0
    conversation_id: str = ""
    role: str = ""
    content: str = ""
    timestamp: str | None = None
    image_url: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PlayerMessage:
        return cls(
            id=data.get("id", 0),
            conversation_id=data.get("conversationId", ""),
            role=data.get("role", ""),
            content=data.get("content", ""),
            timestamp=data.get("timestamp"),
            image_url=data.get("imageUrl"),
        )


@dataclass(frozen=True)
class PlayerMessageList:
    """Paginated list of player messages."""

    messages: list[PlayerMessage] = field(default_factory=list)
    pagination: Pagination = field(default_factory=Pagination)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PlayerMessageList:
        return cls(
            messages=[PlayerMessage.from_dict(m) for m in data.get("messages", [])],
            pagination=Pagination.from_dict(data.get("pagination", {})),
        )
