from __future__ import annotations

import struct
import threading
from typing import Any
from unittest.mock import MagicMock, patch

import numpy as np
import pytest

import estuary_sdk.audio.recorder as recorder_mod
from estuary_sdk.audio.recorder import AudioRecorder


def _make_recorder_mocked() -> tuple[AudioRecorder, MagicMock, Any]:
    """Create an AudioRecorder with mocked sounddevice (no PortAudio needed).

    Returns (recorder, mock_sd, cleanup_fn).
    """
    orig_has = recorder_mod.HAS_AUDIO
    recorder_mod.HAS_AUDIO = True
    mock_sd = MagicMock()
    recorder_mod.sd = mock_sd  # type: ignore[attr-defined]

    recorder = AudioRecorder.__new__(AudioRecorder)
    recorder._target_rate = 24000
    recorder._device_rate = 24000
    recorder._device_rate_resolved = False
    recorder._on_audio = None
    recorder._stream = None
    recorder._recording = False
    recorder._loop = None
    recorder._in_flight_count = 0
    recorder._in_flight_lock = threading.Lock()
    recorder._drain_event = None

    def cleanup() -> None:
        recorder_mod.HAS_AUDIO = orig_has

    return recorder, mock_sd, cleanup


class TestResolveDeviceRate:
    """Tests for _resolve_device_rate() sample rate negotiation."""

    def test_target_rate_supported(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            mock_sd.check_input_settings = lambda **kw: None
            assert recorder._resolve_device_rate() == 24000
        finally:
            cleanup()

    def test_fallback_to_48k(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            def check_input_settings(**kwargs: object) -> None:
                rate = kwargs["samplerate"]
                if rate == 24000:
                    raise Exception("unsupported")

            mock_sd.check_input_settings = check_input_settings
            assert recorder._resolve_device_rate() == 48000
        finally:
            cleanup()

    def test_fallback_to_44100(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            supported = {44100}

            def check_input_settings(**kwargs: object) -> None:
                if kwargs["samplerate"] not in supported:
                    raise Exception("unsupported")

            mock_sd.check_input_settings = check_input_settings
            assert recorder._resolve_device_rate() == 44100
        finally:
            cleanup()

    def test_no_supported_rate_raises(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            def check_input_settings(**kwargs: object) -> None:
                raise Exception("unsupported")

            mock_sd.check_input_settings = check_input_settings
            with pytest.raises(RuntimeError, match="No supported input sample rate"):
                recorder._resolve_device_rate()
        finally:
            cleanup()


    def test_caches_device_rate(self) -> None:
        """Second call to _resolve_device_rate() returns cached value without probing."""
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            call_count = 0

            def check_input_settings(**kwargs: object) -> None:
                nonlocal call_count
                call_count += 1

            mock_sd.check_input_settings = check_input_settings
            rate1 = recorder._resolve_device_rate()
            rate2 = recorder._resolve_device_rate()
            assert rate1 == rate2
            assert call_count == 1  # Only probed once
            assert recorder._device_rate_resolved is True
        finally:
            cleanup()


class TestResampleInt16:
    """Tests for _resample_int16() static method."""

    def test_integer_ratio_decimation(self) -> None:
        # 48kHz -> 16kHz = factor 3
        samples_48k = np.array([100, 200, 300, 400, 500, 600], dtype=np.int16)
        data = samples_48k.tobytes()

        result = AudioRecorder._resample_int16(data, 48000, 16000)

        out = np.frombuffer(result, dtype=np.int16)
        assert len(out) == 2  # 6 / 3
        np.testing.assert_array_equal(out, [100, 400])

    def test_integer_ratio_2x(self) -> None:
        # 32kHz -> 16kHz = factor 2
        samples = np.array([10, 20, 30, 40], dtype=np.int16)
        result = AudioRecorder._resample_int16(samples.tobytes(), 32000, 16000)
        out = np.frombuffer(result, dtype=np.int16)
        assert len(out) == 2
        np.testing.assert_array_equal(out, [10, 30])

    def test_non_integer_ratio_output_length(self) -> None:
        # 44100 -> 16000: non-integer ratio
        n_samples = 882  # 20ms at 44.1kHz
        samples = np.arange(n_samples, dtype=np.int16)
        result = AudioRecorder._resample_int16(samples.tobytes(), 44100, 16000)
        out = np.frombuffer(result, dtype=np.int16)
        expected_len = int(n_samples * 16000 / 44100)
        assert len(out) == expected_len

    def test_no_resample_needed(self) -> None:
        # Same rate — integer ratio factor 1
        samples = np.array([1, 2, 3, 4], dtype=np.int16)
        result = AudioRecorder._resample_int16(samples.tobytes(), 16000, 16000)
        out = np.frombuffer(result, dtype=np.int16)
        np.testing.assert_array_equal(out, samples)

    def test_96k_decimation(self) -> None:
        # 96kHz -> 16kHz = factor 6
        samples = np.arange(12, dtype=np.int16)
        result = AudioRecorder._resample_int16(samples.tobytes(), 96000, 16000)
        out = np.frombuffer(result, dtype=np.int16)
        assert len(out) == 2
        np.testing.assert_array_equal(out, [0, 6])


class TestDeviceSampleRateProperty:
    def test_default_matches_target(self) -> None:
        recorder, _, cleanup = _make_recorder_mocked()
        try:
            assert recorder.device_sample_rate == 24000
        finally:
            cleanup()


class TestIsRecordingProperty:
    def test_defaults_to_false(self) -> None:
        recorder, _, cleanup = _make_recorder_mocked()
        try:
            assert recorder.is_recording is False
        finally:
            cleanup()

    def test_true_when_recording(self) -> None:
        recorder, _, cleanup = _make_recorder_mocked()
        try:
            recorder._recording = True
            assert recorder.is_recording is True
        finally:
            cleanup()


class TestStopIdempotent:
    @pytest.mark.asyncio
    async def test_stop_when_not_recording(self) -> None:
        recorder, _, cleanup = _make_recorder_mocked()
        try:
            await recorder.stop()  # should not raise
            assert recorder.is_recording is False
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_stop_cleans_up_stream(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            mock_stream = MagicMock()
            recorder._stream = mock_stream
            recorder._recording = True
            await recorder.stop()
            assert recorder.is_recording is False
            assert recorder._stream is None
            mock_stream.stop.assert_called_once()
            mock_stream.close.assert_called_once()
        finally:
            cleanup()


class TestDrainBehavior:
    @pytest.mark.asyncio
    async def test_drain_no_in_flight(self) -> None:
        """drain() with no in-flight chunks completes immediately."""
        import asyncio

        recorder, _, cleanup = _make_recorder_mocked()
        try:
            recorder._recording = True
            recorder._loop = asyncio.get_event_loop()
            await recorder.drain(timeout=0.1)
            assert recorder.is_recording is False
            assert recorder._drain_event is None
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_drain_timeout_with_in_flight(self) -> None:
        """drain() times out when in-flight chunks never complete."""
        import asyncio

        recorder, _, cleanup = _make_recorder_mocked()
        try:
            recorder._recording = True
            recorder._loop = asyncio.get_event_loop()
            recorder._in_flight_count = 5
            await recorder.drain(timeout=0.05)
            # Should complete without error (timeout is caught internally)
            assert recorder.is_recording is False
        finally:
            cleanup()


class TestCandidateInputDevices:
    def test_always_includes_none(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            mock_sd.default.device = None
            mock_sd.query_devices.return_value = []
            candidates = recorder._candidate_input_devices()
            assert None in candidates
        finally:
            cleanup()

    def test_includes_explicit_default_device(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            mock_sd.default.device = (3, 1)
            mock_sd.query_devices.return_value = [
                {"name": "D0", "max_input_channels": 0},
                {"name": "D1", "max_input_channels": 0},
                {"name": "D2", "max_input_channels": 0},
                {"name": "D3", "max_input_channels": 2},
            ]
            candidates = recorder._candidate_input_devices()
            assert 3 in candidates
        finally:
            cleanup()

    def test_includes_first_available_input_device(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            mock_sd.default.device = (-1, -1)
            mock_sd.query_devices.return_value = [
                {"name": "Output", "max_input_channels": 0},
                {"name": "Mic", "max_input_channels": 1},
            ]
            candidates = recorder._candidate_input_devices()
            assert 1 in candidates
        finally:
            cleanup()

    def test_scalar_default_device(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            mock_sd.default.device = 2
            mock_sd.query_devices.return_value = [
                {"name": "D0", "max_input_channels": 0},
                {"name": "D1", "max_input_channels": 0},
                {"name": "D2", "max_input_channels": 1},
            ]
            candidates = recorder._candidate_input_devices()
            assert 2 in candidates
        finally:
            cleanup()


class TestFirstAvailableInputDevice:
    def test_returns_first_with_input_channels(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            mock_sd.query_devices.return_value = [
                {"name": "Out", "max_input_channels": 0},
                {"name": "Mic", "max_input_channels": 2},
                {"name": "Mic2", "max_input_channels": 1},
            ]
            assert recorder._first_available_input_device() == 1
        finally:
            cleanup()

    def test_returns_none_when_no_input_devices(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            mock_sd.query_devices.return_value = [
                {"name": "Out", "max_input_channels": 0},
            ]
            assert recorder._first_available_input_device() is None
        finally:
            cleanup()

    def test_returns_none_on_query_failure(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            mock_sd.query_devices.side_effect = Exception("no audio subsystem")
            assert recorder._first_available_input_device() is None
        finally:
            cleanup()


class TestOpenStream:
    def test_opens_with_correct_params(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            recorder._device_rate = 48000
            recorder._open_stream(device=None)
            mock_sd.InputStream.assert_called_once()
            kwargs = mock_sd.InputStream.call_args[1]
            assert kwargs["samplerate"] == 48000
            assert kwargs["channels"] == 1
            assert kwargs["dtype"] == "int16"
            assert "device" not in kwargs
        finally:
            cleanup()

    def test_opens_with_specific_device(self) -> None:
        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            recorder._open_stream(device=3)
            kwargs = mock_sd.InputStream.call_args[1]
            assert kwargs["device"] == 3
        finally:
            cleanup()


class TestStartWithDeviceFallback:
    @pytest.mark.asyncio
    async def test_start_success_on_first_device(self) -> None:
        import asyncio

        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            recorder._loop = asyncio.get_event_loop()
            mock_sd.check_input_settings = lambda **kw: None
            mock_sd.default.device = None
            mock_sd.query_devices.return_value = []

            mock_stream = MagicMock()
            mock_sd.InputStream.return_value = mock_stream

            await recorder.start()
            assert recorder.is_recording is True
            mock_stream.start.assert_called_once()
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_start_already_recording_is_noop(self) -> None:
        recorder, _, cleanup = _make_recorder_mocked()
        try:
            recorder._recording = True
            await recorder.start()  # should return immediately
            assert recorder.is_recording is True
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_start_falls_back_on_device_failure(self) -> None:
        import asyncio

        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            recorder._loop = asyncio.get_event_loop()
            mock_sd.check_input_settings = lambda **kw: None
            mock_sd.default.device = (0, 1)
            mock_sd.query_devices.return_value = [
                {"name": "Mic", "max_input_channels": 1},
            ]

            call_count = 0
            mock_stream_ok = MagicMock()

            def fake_input_stream(**kwargs: Any) -> MagicMock:
                nonlocal call_count
                call_count += 1
                if call_count == 1:
                    raise OSError("device busy")
                return mock_stream_ok

            mock_sd.InputStream = fake_input_stream

            await recorder.start()
            assert recorder.is_recording is True
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_start_raises_when_all_devices_fail(self) -> None:
        import asyncio

        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            recorder._loop = asyncio.get_event_loop()
            mock_sd.check_input_settings = lambda **kw: None
            mock_sd.default.device = None
            mock_sd.query_devices.return_value = []
            mock_sd.InputStream.side_effect = OSError("no devices")

            with pytest.raises(RuntimeError, match="No usable input audio device"):
                await recorder.start()
        finally:
            cleanup()


class TestFastResume:
    """Tests for PTT fast-resume: drain() keeps stream, start() resumes instantly."""

    @pytest.mark.asyncio
    async def test_drain_keeps_stream_open(self) -> None:
        import asyncio

        recorder, _, cleanup = _make_recorder_mocked()
        try:
            mock_stream = MagicMock()
            recorder._stream = mock_stream
            recorder._recording = True
            recorder._loop = asyncio.get_event_loop()
            await recorder.drain(timeout=0.1)
            assert recorder.is_recording is False
            assert recorder._stream is mock_stream  # Stream NOT closed
            mock_stream.stop.assert_not_called()
            mock_stream.close.assert_not_called()
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_start_resumes_with_existing_stream(self) -> None:
        import asyncio

        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            mock_stream = MagicMock()
            recorder._stream = mock_stream
            recorder._recording = False
            recorder._loop = asyncio.get_event_loop()

            await recorder.start()
            assert recorder.is_recording is True
            # Should NOT have opened a new stream
            mock_sd.InputStream.assert_not_called()
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_drain_then_start_is_instant(self) -> None:
        """Full PTT cycle: start -> drain -> start resumes without device probe."""
        import asyncio

        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            recorder._loop = asyncio.get_event_loop()
            mock_sd.check_input_settings = lambda **kw: None
            mock_sd.default.device = None
            mock_sd.query_devices.return_value = []

            mock_stream = MagicMock()
            mock_sd.InputStream.return_value = mock_stream

            # First start — opens stream
            await recorder.start()
            assert recorder.is_recording is True
            assert mock_sd.InputStream.call_count == 1

            # Drain — keeps stream open
            await recorder.drain(timeout=0.1)
            assert recorder.is_recording is False
            assert recorder._stream is mock_stream

            # Second start — resumes instantly
            await recorder.start()
            assert recorder.is_recording is True
            assert mock_sd.InputStream.call_count == 1  # No new stream opened
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_stop_closes_stream_after_drain(self) -> None:
        import asyncio

        recorder, _, cleanup = _make_recorder_mocked()
        try:
            mock_stream = MagicMock()
            recorder._stream = mock_stream
            recorder._recording = True
            recorder._loop = asyncio.get_event_loop()

            await recorder.drain(timeout=0.1)
            assert recorder._stream is mock_stream  # Still open

            await recorder.stop()
            assert recorder._stream is None  # Now closed
            mock_stream.stop.assert_called_once()
            mock_stream.close.assert_called_once()
        finally:
            cleanup()


class TestAudioCallback:
    def test_callback_skipped_when_not_recording(self) -> None:
        recorder, _, cleanup = _make_recorder_mocked()
        try:
            recorder._recording = False
            recorder._on_audio = MagicMock()
            indata = np.zeros(320, dtype=np.int16)
            recorder._audio_callback(indata, 320, None, None)
            # _on_audio should NOT be called
            assert recorder._in_flight_count == 0
        finally:
            cleanup()

    def test_callback_skipped_when_no_handler(self) -> None:
        recorder, _, cleanup = _make_recorder_mocked()
        try:
            recorder._recording = True
            recorder._on_audio = None
            indata = np.zeros(320, dtype=np.int16)
            recorder._audio_callback(indata, 320, None, None)
            assert recorder._in_flight_count == 0
        finally:
            cleanup()


class TestHandleAudioDone:
    def test_decrements_in_flight_count(self) -> None:
        import concurrent.futures

        recorder, _, cleanup = _make_recorder_mocked()
        try:
            recorder._in_flight_count = 3
            fut: concurrent.futures.Future[None] = concurrent.futures.Future()
            fut.set_result(None)
            recorder._handle_audio_done(fut)
            assert recorder._in_flight_count == 2
        finally:
            cleanup()

    def test_does_not_go_negative(self) -> None:
        import concurrent.futures

        recorder, _, cleanup = _make_recorder_mocked()
        try:
            recorder._in_flight_count = 0
            fut: concurrent.futures.Future[None] = concurrent.futures.Future()
            fut.set_result(None)
            recorder._handle_audio_done(fut)
            assert recorder._in_flight_count == 0
        finally:
            cleanup()

    def test_handles_exception_in_callback(self) -> None:
        import concurrent.futures

        recorder, _, cleanup = _make_recorder_mocked()
        try:
            recorder._in_flight_count = 1
            fut: concurrent.futures.Future[None] = concurrent.futures.Future()
            fut.set_exception(RuntimeError("callback error"))
            recorder._handle_audio_done(fut)  # should not raise
            assert recorder._in_flight_count == 0
        finally:
            cleanup()


class TestAsyncThreadOffload:
    """Verify ALSA work is offloaded to worker threads."""

    @pytest.mark.asyncio
    async def test_cold_start_offloads_to_thread(self) -> None:
        """start() cold path should run _start_cold in asyncio.to_thread."""
        import asyncio

        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            recorder._loop = asyncio.get_event_loop()
            mock_sd.check_input_settings = lambda **kw: None
            mock_sd.default.device = None
            mock_sd.query_devices.return_value = []
            mock_stream = MagicMock()
            mock_sd.InputStream.return_value = mock_stream

            with patch("asyncio.to_thread", wraps=asyncio.to_thread) as mock_to_thread:
                await recorder.start()
                mock_to_thread.assert_called_once_with(recorder._start_cold)
            assert recorder.is_recording is True
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_fast_resume_does_not_use_thread(self) -> None:
        """start() fast-resume path should NOT call to_thread."""
        import asyncio

        recorder, mock_sd, cleanup = _make_recorder_mocked()
        try:
            mock_stream = MagicMock()
            recorder._stream = mock_stream
            recorder._recording = False

            with patch("asyncio.to_thread") as mock_to_thread:
                await recorder.start()
                mock_to_thread.assert_not_called()
            assert recorder.is_recording is True
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_stop_offloads_stream_close_to_thread(self) -> None:
        """stop() should close stream in a worker thread."""
        import asyncio

        recorder, _, cleanup = _make_recorder_mocked()
        try:
            mock_stream = MagicMock()
            recorder._stream = mock_stream
            recorder._recording = True

            with patch("asyncio.to_thread", wraps=asyncio.to_thread) as mock_to_thread:
                await recorder.stop()
                mock_to_thread.assert_called_once()
            assert recorder._stream is None
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_stop_without_stream_skips_thread(self) -> None:
        """stop() with no stream should not call to_thread."""
        recorder, _, cleanup = _make_recorder_mocked()
        try:
            recorder._recording = True

            with patch("asyncio.to_thread") as mock_to_thread:
                await recorder.stop()
                mock_to_thread.assert_not_called()
        finally:
            cleanup()


class TestHasAudioGuard:
    def test_raises_import_error_without_audio(self) -> None:
        orig = recorder_mod.HAS_AUDIO
        try:
            recorder_mod.HAS_AUDIO = False
            with pytest.raises(ImportError, match="sounddevice and numpy"):
                AudioRecorder(sample_rate=24000, on_audio=None)
        finally:
            recorder_mod.HAS_AUDIO = orig
