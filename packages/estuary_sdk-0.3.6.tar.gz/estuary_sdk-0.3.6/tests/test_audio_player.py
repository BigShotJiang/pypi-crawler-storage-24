from __future__ import annotations

import asyncio
import base64
import threading
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

import estuary_sdk.audio.player as player_mod
from estuary_sdk.audio.player import AudioPlayer
from estuary_sdk.types import BotVoice


def _make_player_mocked() -> tuple[AudioPlayer, MagicMock, Any]:
    """Create an AudioPlayer with mocked sounddevice (no PortAudio needed).

    Returns (player, mock_sd, cleanup_fn).
    """
    orig_has = player_mod.HAS_AUDIO
    player_mod.HAS_AUDIO = True
    mock_sd = MagicMock()
    player_mod.sd = mock_sd  # type: ignore[attr-defined]

    player = AudioPlayer.__new__(AudioPlayer)
    player._sample_rate = 24000
    player._on_event = None
    player._lock = threading.Lock()
    player._buffer = bytearray()
    player._bytes_written = 0
    player._bytes_consumed = 0
    from collections import deque

    player._markers = deque()
    player._stream = None
    player._loop = None
    player._silence_frames = 0
    player._current_message_id = None

    def cleanup() -> None:
        player_mod.HAS_AUDIO = orig_has

    return player, mock_sd, cleanup


class TestPlayerAsyncStart:
    """Tests for AudioPlayer.start() pre-opening the stream."""

    @pytest.mark.asyncio
    async def test_start_opens_stream_in_thread(self) -> None:
        """start() should open the output stream via to_thread."""
        player, mock_sd, cleanup = _make_player_mocked()
        try:
            mock_stream = MagicMock()
            mock_sd.RawOutputStream.return_value = mock_stream

            with patch("asyncio.to_thread", wraps=asyncio.to_thread) as mock_to_thread:
                await player.start()
                mock_to_thread.assert_called_once_with(player._ensure_stream)
            assert player._stream is not None
            mock_stream.start.assert_called_once()
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_start_is_idempotent(self) -> None:
        """Calling start() when stream is already open is a no-op."""
        player, mock_sd, cleanup = _make_player_mocked()
        try:
            player._stream = MagicMock()

            with patch("asyncio.to_thread") as mock_to_thread:
                await player.start()
                mock_to_thread.assert_not_called()
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_enqueue_works_without_start(self) -> None:
        """Backward compat: enqueue() works even if start() was never called."""
        player, mock_sd, cleanup = _make_player_mocked()
        try:
            mock_stream = MagicMock()
            mock_sd.RawOutputStream.return_value = mock_stream

            voice = BotVoice(
                audio=base64.b64encode(b"\x00" * 100).decode(),
                message_id="m1",
                is_final=False,
            )
            player.enqueue(voice)
            assert player._stream is not None
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_play_raw_works_without_start(self) -> None:
        """Backward compat: play_raw() works even if start() was never called."""
        player, mock_sd, cleanup = _make_player_mocked()
        try:
            mock_stream = MagicMock()
            mock_sd.RawOutputStream.return_value = mock_stream

            player.play_raw(b"\x00" * 100)
            assert player._stream is not None
        finally:
            cleanup()


class TestPlayerDispose:
    @pytest.mark.asyncio
    async def test_dispose_offloads_stream_close_to_thread(self) -> None:
        """dispose() should close stream via to_thread."""
        player, _, cleanup = _make_player_mocked()
        try:
            mock_stream = MagicMock()
            player._stream = mock_stream

            with patch("asyncio.to_thread", wraps=asyncio.to_thread) as mock_to_thread:
                await player.dispose()
                mock_to_thread.assert_called_once()
            assert player._stream is None
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_dispose_without_stream_skips_thread(self) -> None:
        """dispose() with no stream should not call to_thread."""
        player, _, cleanup = _make_player_mocked()
        try:
            with patch("asyncio.to_thread") as mock_to_thread:
                await player.dispose()
                mock_to_thread.assert_not_called()
        finally:
            cleanup()


class TestPlayerClear:
    def test_clear_stops_stream(self) -> None:
        player, _, cleanup = _make_player_mocked()
        try:
            mock_stream = MagicMock()
            player._stream = mock_stream
            player.clear()
            assert player._stream is None
            mock_stream.abort.assert_called_once()
            mock_stream.close.assert_called_once()
        finally:
            cleanup()

    def test_clear_resets_buffer_state(self) -> None:
        player, _, cleanup = _make_player_mocked()
        try:
            player._buffer = bytearray(b"\x01\x02\x03")
            player._bytes_written = 3
            player._bytes_consumed = 1
            player.clear()
            assert len(player._buffer) == 0
            assert player._bytes_written == 0
            assert player._bytes_consumed == 0
        finally:
            cleanup()


class TestScheduleStop:
    @pytest.mark.asyncio
    async def test_schedule_stop_uses_to_thread(self) -> None:
        """_schedule_stop should schedule _stop_stream via asyncio.to_thread."""
        player, _, cleanup = _make_player_mocked()
        try:
            mock_stream = MagicMock()
            player._stream = mock_stream

            player._schedule_stop()
            # Give the scheduled future a chance to run
            await asyncio.sleep(0.05)
            assert player._stream is None
        finally:
            cleanup()
