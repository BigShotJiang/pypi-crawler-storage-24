"""Tests for EstuaryClient public API surface."""

import asyncio
from typing import Any
from unittest.mock import MagicMock

import pytest
from estuary_sdk import ErrorCode, EstuaryClient, EstuaryConfig, EstuaryError
from estuary_sdk.types import BotResponse, ConnectionState


@pytest.fixture
def config() -> EstuaryConfig:
    return EstuaryConfig(
        server_url="http://localhost:4001",
        api_key="est_test_key",
        character_id="test-char-id",
        player_id="test-player",
    )


def _make_connected_client(config: EstuaryConfig) -> EstuaryClient:
    """Create an EstuaryClient and pretend it is connected."""
    client = EstuaryClient(config)
    client._socket._state = ConnectionState.CONNECTED
    client._socket.emit_event = MagicMock()
    return client


class TestEstuaryClientInit:
    def test_creates_client(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        assert not client.is_connected
        assert client.session is None
        assert not client.is_voice_active
        assert not client.is_muted

    def test_config_defaults(self) -> None:
        config = EstuaryConfig(
            server_url="http://localhost:4001",
            api_key="key",
            character_id="char",
            player_id="player",
        )
        assert config.audio_sample_rate == 24000
        assert config.auto_reconnect is True
        assert config.max_reconnect_attempts == 5
        assert config.reconnect_delay == 1.0
        assert config.debug is False
        assert config.voice_transport == "websocket"
        assert config.realtime_memory is False


class TestEstuaryClientNotConnected:
    def test_send_text_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            client.send_text("hello")
        assert exc_info.value.code == ErrorCode.NOT_CONNECTED

    def test_interrupt_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            client.interrupt()
        assert exc_info.value.code == ErrorCode.NOT_CONNECTED

    def test_send_camera_image_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            client.send_camera_image("base64data", "image/jpeg")
        assert exc_info.value.code == ErrorCode.NOT_CONNECTED

    def test_memory_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            _ = client.memory
        assert exc_info.value.code == ErrorCode.NOT_CONNECTED

    @pytest.mark.asyncio
    async def test_start_voice_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            await client.start_voice()
        assert exc_info.value.code == ErrorCode.NOT_CONNECTED

    @pytest.mark.asyncio
    async def test_start_recording_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            await client.start_recording()
        assert exc_info.value.code == ErrorCode.VOICE_NOT_ACTIVE

    @pytest.mark.asyncio
    async def test_send_audio_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            await client.send_audio(b"\x00")
        assert exc_info.value.code == ErrorCode.VOICE_NOT_ACTIVE


class TestEstuaryClientContextManager:
    @pytest.mark.asyncio
    async def test_context_manager(self, config: EstuaryConfig) -> None:
        async with EstuaryClient(config) as client:
            assert not client.is_connected
        # After exit, client should be cleaned up (no error)


class TestSendTextPayload:
    def test_send_text_basic(self, config: EstuaryConfig) -> None:
        client = _make_connected_client(config)
        client.send_text("hello")
        event, payload = client._socket.emit_event.call_args[0]
        assert event == "text"
        assert payload["text"] == "hello"
        assert "textOnly" not in payload

    def test_send_text_text_only(self, config: EstuaryConfig) -> None:
        client = _make_connected_client(config)
        client.send_text("hello", text_only=True)
        event, payload = client._socket.emit_event.call_args[0]
        assert event == "text"
        assert payload["textOnly"] is True


class TestInterruptPayload:
    def test_interrupt_no_message_id(self, config: EstuaryConfig) -> None:
        client = _make_connected_client(config)
        client.interrupt()
        event, payload = client._socket.emit_event.call_args[0]
        assert event == "client_interrupt"
        assert payload == {}

    def test_interrupt_with_message_id(self, config: EstuaryConfig) -> None:
        client = _make_connected_client(config)
        client.interrupt(message_id="msg-42")
        event, payload = client._socket.emit_event.call_args[0]
        assert event == "client_interrupt"
        assert payload["message_id"] == "msg-42"


class TestSendCameraImagePayload:
    def test_camera_image_minimal(self, config: EstuaryConfig) -> None:
        client = _make_connected_client(config)
        client.send_camera_image("base64data", "image/jpeg")
        event, payload = client._socket.emit_event.call_args[0]
        assert event == "camera_image"
        assert payload["image"] == "base64data"
        assert payload["mime_type"] == "image/jpeg"
        assert "request_id" not in payload
        assert "text" not in payload

    def test_camera_image_with_optional_fields(self, config: EstuaryConfig) -> None:
        client = _make_connected_client(config)
        client.send_camera_image("b64", "image/png", request_id="req-1", text="What is this?")
        event, payload = client._socket.emit_event.call_args[0]
        assert payload["request_id"] == "req-1"
        assert payload["text"] == "What is this?"


class TestUpdatePreferencesPayload:
    def test_update_preferences(self, config: EstuaryConfig) -> None:
        client = _make_connected_client(config)
        client.update_preferences(enable_vision_acknowledgment=True)
        event, payload = client._socket.emit_event.call_args[0]
        assert event == "update_preferences"
        assert payload["enableVisionAcknowledgment"] is True

    def test_update_preferences_no_args(self, config: EstuaryConfig) -> None:
        client = _make_connected_client(config)
        client.update_preferences()
        event, payload = client._socket.emit_event.call_args[0]
        assert event == "update_preferences"
        assert payload == {}


class TestNotifyAudioPlaybackComplete:
    def test_with_message_id(self, config: EstuaryConfig) -> None:
        client = _make_connected_client(config)
        client.notify_audio_playback_complete(message_id="msg-7")
        event, payload = client._socket.emit_event.call_args[0]
        assert event == "audio_playback_complete"
        assert payload["message_id"] == "msg-7"

    def test_without_message_id(self, config: EstuaryConfig) -> None:
        client = _make_connected_client(config)
        client.notify_audio_playback_complete()
        event, payload = client._socket.emit_event.call_args[0]
        assert event == "audio_playback_complete"
        assert payload == {}


class TestClientProperties:
    def test_generate_available_before_connect(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        assert client.generate is not None

    def test_characters_available_before_connect(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        assert client.characters is not None

    def test_players_unavailable_before_connect(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            _ = client.players
        assert exc_info.value.code == ErrorCode.NOT_CONNECTED

    def test_toggle_mute_no_voice(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        client.toggle_mute()  # should not raise when no voice active


class TestClientEventForwarding:
    @pytest.mark.asyncio
    async def test_bot_response_forwarded(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        received: list[BotResponse] = []
        client.on("bot_response", lambda r: received.append(r))

        response = BotResponse(text="Hi!", is_final=True, message_id="m1")
        await client._socket.emit("bot_response", response)

        assert len(received) == 1
        assert received[0].text == "Hi!"

    @pytest.mark.asyncio
    async def test_agent_events_forwarded(self, config: EstuaryConfig) -> None:
        from estuary_sdk.types import AgentTurnText

        client = EstuaryClient(config)
        received: list[Any] = []
        client.on("agent_turn_text", lambda e: received.append(e))

        event = AgentTurnText(agent_id="a1", text="Attack!", turn_number=1)
        await client._socket.emit("agent_turn_text", event)

        assert len(received) == 1
        assert received[0].agent_id == "a1"


class TestSendTextAndWaitNonFinal:
    @pytest.mark.asyncio
    async def test_ignores_non_final_responses(self, config: EstuaryConfig) -> None:
        """send_text_and_wait should ignore partial (non-final) responses."""
        client = _make_connected_client(config)

        async def simulate_responses() -> None:
            await asyncio.sleep(0.02)
            # Emit a partial response first
            partial = BotResponse(text="Hel", is_final=False, message_id="m1", chunk_index=0)
            await client.emit("bot_response", partial)
            await asyncio.sleep(0.02)
            # Then emit the final response
            final = BotResponse(text="Hello there!", is_final=True, message_id="m1", chunk_index=3)
            await client.emit("bot_response", final)

        task = asyncio.create_task(simulate_responses())
        result = await client.send_text_and_wait("hello", timeout=5.0)
        await task
        assert result.text == "Hello there!"
        assert result.is_final is True
