"""CLI module for fubot."""
