
# entity in dataclass format

from dataclasses import dataclass
from typing import Optional, List
from uuid import UUID
from .entity1_exceptions import *
from .entity1_schemas import FileData, BaseEntity

@dataclass
class Entity1Entity(BaseEntity):
    """
    Entidad del dominio para entity1.

    Esta clase representa la lógica de negocio central y las reglas asociadas 
    con entity1 en el sistema.
    """

    domain_value_error_class = Entity1ValueError

    class Meta:
        required_fields = {"name", "email", "related_id"} # Requeridos para la creación (from_dict)
        readonly_fields = {"id", "uuid", "created_at", "updated_at"} # Prohibidos siempre en creacion (from_dict) / actualizaciones (update)
        protected_fields = {"related_id"} # Prohibidos en actualizaciones (update)
        special_update_fields = {"relations", "photo"} # Prohibidos en actualizaciones (update), requieren manejo especial externo
        readonly_and_protected_fields = readonly_fields.union(protected_fields)        
    
    # Identificadores
    id: Optional[int] = None  # ID relacionado con la base de datos
    uuid: Optional[UUID] = None

    # Atributos principales
    name: Optional[str] = None  # Atributo opcional
    email: Optional[str] = None  # Atributo opcional
    role: Optional[str] = None  # Atributo opcional
    status: Optional[str] = None  # Atributo opcional
    photo: Optional[dict] = None  # Atributo opcional

    # Relaciones
    related_id: Optional[int] = None  # ID de una entidad relacionada (opcional)

    # Relaciones Many-to-Many o Reverse FK
    relations: Optional[List[int]] = None  # Lista de IDs de entidades relacionadas

    # Descomentar si se quiere hacer una validacion estricta
    #def __post_init__(self):
    #    self._run_validation()

    
    def validate(self) -> None:
        """
        Valida la entidad antes de guardar o procesar.

        Lanza excepciones si las reglas de negocio no se cumplen.
        - Consistencia interna de los atributos
        - Validaciones intrínsecas al momento de creación/modificación
        """
        # Validaciones de ejemplo
        if not self.name or len(self.name) < 3:
            raise self.domain_value_error_class(field="name", detail="name must be at least 3 characters")

        if self.email and len(self.email) > 500:
            raise self.domain_value_error_class(field="email", detail="email must not exceed 500 characters")

        if self.relations and not all(isinstance(x, int) for x in self.relations):
            raise self.domain_value_error_class(field="relations", detail="relations must be a list of integers")            
  


'''
Guía para añadir nuevos campos a entidades Dataclass:

- ✅ **Atributos opcionales**: usa `Optional[Tipo] = None`
- ✅ **Listas/Dicts por defecto**: usa `field(default_factory=list)` o `field(default_factory=dict)`
- ✅ **Atributos obligatorios**: define sin valor por defecto → fallará si no se proporciona
- ✅ **Valores por defecto simples**: asigna directamente (`is_active: bool = True`)
- ✅ **Fechas/horas**: usa `str` en formato ISO (ej. "2023-10-05T14:48:00Z") → convierte a datetime al usar
- ✅ **Archivos/URLs**: usa Optional[dict] o crea submodelos si es complejo

Ejemplos:

    # Atributos simples opcionales
    name: Optional[str] = None
    email: Optional[str] = None
    price: Optional[float] = None
    quantity: Optional[int] = None
    is_featured: Optional[bool] = None

    # Atributos con valor por defecto (no None)
    is_active: bool = True
    rating: float = 0.0

    # Colecciones con valor por defecto (¡nunca asignes [] o {} directamente!)
    categories: List[str] = field(default_factory=list)
    config: Dict[str, Any] = field(default_factory=dict)
    items: List[Dict[str, Any]] = field(default_factory=list)

    # Fechas (usa str en formato ISO)
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    # Relaciones (IDs)
    related_id: Optional[int] = None # Identificador externo (ideal para relaciones 1-a-1 con otras entidades o FK)
    relations: Optional[List[int]] = None # Lista de identificadores externos (ideal para relaciones 1-a-M o M-a-M)

    # Referencias UUID a otras entidades (solo son refencias)
    external_uuid: Optional[str] = None  # UUID externo (para relaciones 1-a-1)
    relations_uuids: Optional[List[str]] = None  # Lista de UUIDs externos  (para relaciones 1-a-M o M-a-M)

    # Objetos complejos (mejor usar dict)
    image: Optional[dict] = None
    address: Optional[dict] = None

⚠️ Importante:
- Los campos se validan automáticamente al crear la instancia
- Para validaciones personalizadas, usa `@dataclass` o `@field_validator`
'''
