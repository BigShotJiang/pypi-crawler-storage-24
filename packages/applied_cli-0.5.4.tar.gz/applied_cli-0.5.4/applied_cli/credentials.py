"""Local credential storage for CLI."""

import json
import os
from pathlib import Path
from typing import TypedDict


class Credentials(TypedDict, total=False):
    """Stored credentials structure."""

    api_token: str
    shop_id: str
    base_url: str


def get_config_dir() -> Path:
    """Get the config directory path."""
    return Path.home() / ".config" / "applied-labs"


def get_credentials_file() -> Path:
    """Get the credentials file path."""
    return get_config_dir() / "credentials.json"


def load_credentials() -> Credentials | None:
    """Load credentials from disk."""
    creds_file = get_credentials_file()
    if not creds_file.exists():
        return None

    try:
        with open(creds_file) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def save_credentials(credentials: Credentials) -> None:
    """Save credentials to disk with secure permissions."""
    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)

    creds_file = get_credentials_file()
    with open(creds_file, "w") as f:
        json.dump(credentials, f, indent=2)

    # Set file permissions to 600 (owner read/write only)
    os.chmod(creds_file, 0o600)


def clear_credentials() -> None:
    """Remove stored credentials."""
    creds_file = get_credentials_file()
    if creds_file.exists():
        creds_file.unlink()
