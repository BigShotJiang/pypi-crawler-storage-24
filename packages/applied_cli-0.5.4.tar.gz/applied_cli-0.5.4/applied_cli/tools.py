"""MCP tool implementations using AppliedClient.

These functions wrap the client methods with formatting logic,
suitable for both MCP tools and CLI commands.
"""

from applied_cli.client import AppliedClient
from applied_cli.formatters import select_fields, to_csv, to_json


async def agent_list(
    client: AppliedClient,
    output_format: str = "csv",
) -> str:
    """
    List all AI agents in the workspace.

    Args:
        client: Authenticated AppliedClient
        output_format: 'csv' (default, token-efficient) or 'json'

    Returns:
        List of agents with id, name, modality, description
    """
    agents = await client.list_agents()
    mapped = [
        {
            "id": a.get("id"),
            "name": a.get("name"),
            "modality": a.get("modality"),
            "description": a.get("description", ""),
        }
        for a in agents
    ]

    if output_format == "csv":
        return to_csv(mapped, ["id", "name", "modality", "description"])
    return to_json(mapped)


async def taxonomy_list(
    client: AppliedClient,
    taxonomy_type: str = "all",
    output_format: str = "csv",
) -> str:
    """
    List conversation taxonomy: topics, intents, and flags.

    Args:
        client: Authenticated AppliedClient
        taxonomy_type: 'all' (default), 'topics', 'intents', or 'flags'
        output_format: 'csv' or 'json'

    Returns:
        Topics (categories), intents (sub-categories), flags (markers)
    """
    choices = await client.list_taxonomy(taxonomy_type)
    items = [
        {
            "id": c.get("id"),
            "name": c.get("name"),
            "type": (
                "flag"
                if c.get("is_flag")
                else ("intent" if c.get("parent_choice_id") else "topic")
            ),
        }
        for c in choices
    ]

    if output_format == "csv":
        return to_csv(items, ["id", "name", "type"])
    return to_json(items)


async def conversation_query(
    client: AppliedClient,
    filters: dict | None = None,
    fields: list[str] | None = None,
    limit: int = 20,
    output_format: str = "csv",
) -> str:
    """
    Query conversations with filters and field selection.

    Args:
        client: Authenticated AppliedClient
        filters: Filter conditions, e.g.:
            {"resolution": "escalated"}
            {"resolution": ["escalated", "soft"]}
            {"created_at": {"gte": "2024-01-01", "lte": "2024-01-31"}}
        fields: Fields to return, e.g. ["id", "title", "contact.email"]
        limit: Max results (default 20, max 100)
        output_format: 'csv' or 'json'

    Returns:
        Matching conversations
    """
    results = await client.query_conversations(filters=filters, limit=limit)

    if fields:
        results = select_fields(results, fields)

    if output_format == "csv":
        return f"# {len(results)} results\n" + to_csv(results, fields)
    return to_json({"count": len(results), "results": results})


async def conversation_get(
    client: AppliedClient,
    conversation_id: str,
    include_messages: bool = False,
    message_limit: int = 50,
) -> str:
    """
    Get a single conversation by ID.

    Args:
        client: Authenticated AppliedClient
        conversation_id: The conversation UUID
        include_messages: Include message transcript (default: False)
        message_limit: Max messages to include (default: 50)

    Returns:
        Conversation details and optionally messages
    """
    conv = await client.get_conversation(conversation_id)
    result = f"# Conversation {conversation_id}\n{to_json(conv)}"

    if include_messages:
        messages = await client.get_messages(conversation_id, limit=message_limit)
        result += f"\n\n# Messages ({len(messages)})\n"
        for m in messages:
            role = m.get("role", "unknown")
            content = str(m.get("content", ""))[:500]
            result += f"\n[{role}] {content}"

    return result


async def ticket_query(
    client: AppliedClient,
    filters: dict | None = None,
    limit: int = 20,
    output_format: str = "csv",
) -> str:
    """
    Query tickets with filters.

    Args:
        client: Authenticated AppliedClient
        filters: Filter conditions, e.g. {"status": "open"}
        limit: Max results (default 20)
        output_format: 'csv' or 'json'

    Returns:
        Matching tickets
    """
    results = await client.query_tickets(filters=filters, limit=limit)
    mapped = [
        {
            "id": t.get("id"),
            "name": t.get("name"),
            "status": t.get("status"),
            "priority": t.get("priority"),
        }
        for t in results
    ]

    if output_format == "csv":
        return f"# {len(mapped)} tickets\n" + to_csv(
            mapped, ["id", "name", "status", "priority"]
        )
    return to_json(mapped)


async def knowledge_list(
    client: AppliedClient,
    kb_type: str | None = None,
    search: str | None = None,
    limit: int = 50,
    output_format: str = "csv",
) -> str:
    """
    List knowledge base items (Q&A, escalation rules, context, exact responses).

    Args:
        client: Authenticated AppliedClient
        kb_type: Filter by type - 'qa', 'context', 'escalate', 'exact'
        search: Full-text search query
        limit: Max results (default 50)
        output_format: 'csv' or 'json'

    Returns:
        Knowledge base items
    """
    results = await client.list_knowledge(kb_type=kb_type, search=search, limit=limit)
    mapped = [
        {
            "id": r.get("id"),
            "type": r.get("type"),
            "question": str(r.get("question", ""))[:100],
            "active": r.get("active"),
        }
        for r in results
    ]

    if output_format == "csv":
        return to_csv(mapped, ["id", "type", "question", "active"])
    return to_json(mapped)


# -----------------------------------------------------------------------------
# Flow Management
# -----------------------------------------------------------------------------


async def flow_list(
    client: AppliedClient,
    agent_id: str | None = None,
    status: str | None = None,
    output_format: str = "csv",
) -> str:
    """
    List flows for an agent.

    Args:
        client: Authenticated AppliedClient
        agent_id: Filter by agent ID (recommended)
        status: Filter by status - 'Active', 'Draft', or 'Archived'
        output_format: 'csv' or 'json'

    Returns:
        List of flows with id, name, type, trigger, status, updated_at
    """
    flows = await client.list_flows(agent_id=agent_id, status=status)
    mapped = [
        {
            "id": f.get("id"),
            "name": f.get("name"),
            "type": f.get("type"),
            "trigger": f.get("trigger"),
            "status": f.get("status"),
            "updated_at": f.get("updated_at", "")[:19],
        }
        for f in flows
    ]

    if output_format == "csv":
        return to_csv(mapped, ["id", "name", "type", "trigger", "status", "updated_at"])
    return to_json(mapped)


async def flow_get(
    client: AppliedClient,
    flow_id: str,
) -> str:
    """
    Get a flow with its full graph (nodes and edges).

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID

    Returns:
        Flow metadata, nodes table, and edges table
    """
    flow = await client.get_flow(flow_id)
    graph = flow.get("graph", {})
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])

    # Format header
    result = f"# Flow: {flow.get('name')}\n"
    result += f"id: {flow.get('id')}\n"
    result += f"type: {flow.get('type')}\n"
    result += f"trigger: {flow.get('trigger')}\n"
    result += f"status: {flow.get('status')}\n"
    if flow.get("description"):
        result += f"description: {flow.get('description')}\n"
    if flow.get("prompt"):
        result += f"purpose: {flow.get('prompt')}\n"

    # Format nodes
    result += f"\n## Nodes ({len(nodes)})\n"
    node_rows = [
        {
            "id": n.get("id"),
            "type": n.get("type", n.get("data", {}).get("name", "")),
            "description": n.get("data", {}).get("description", "")[:50],
        }
        for n in nodes
    ]
    result += to_csv(node_rows, ["id", "type", "description"])

    # Format edges
    result += f"\n## Edges ({len(edges)})\n"
    edge_rows = [
        {
            "id": e.get("id"),
            "source": e.get("source"),
            "target": e.get("target"),
            "source_handle": e.get("sourceHandle", ""),
            "target_handle": e.get("targetHandle", ""),
            "label": e.get("data", {}).get("label", ""),
        }
        for e in edges
    ]
    result += to_csv(
        edge_rows, ["id", "source", "target", "source_handle", "target_handle", "label"]
    )

    return result


async def flow_create(
    client: AppliedClient,
    agent_id: str,
    name: str,
    flow_type: str = "conversational",
    trigger: str = "llm.call",
    description: str = "",
) -> str:
    """
    Create a new flow.

    Args:
        client: Authenticated AppliedClient
        agent_id: The agent to attach the flow to
        name: Flow name
        flow_type: 'conversational' (default) or 'operational'
        trigger: 'llm.call' (conversation trigger), 'conversation.end', etc.
        description: Optional flow description

    Returns:
        Created flow with auto-generated trigger and escalation nodes
    """
    flow = await client.create_flow(
        agent_id=agent_id,
        name=name,
        flow_type=flow_type,
        trigger=trigger,
        description=description,
    )

    result = f"# Created Flow: {flow.get('name')}\n"
    result += f"id: {flow.get('id')}\n"
    result += f"type: {flow.get('type')}\n"
    result += f"trigger: {flow.get('trigger')}\n"
    result += f"status: {flow.get('status')}\n"
    result += "\nUse flow_get to see the auto-generated nodes."

    return result


async def flow_update(
    client: AppliedClient,
    flow_id: str,
    name: str | None = None,
    description: str | None = None,
    prompt: str | None = None,
    status: str | None = None,
) -> str:
    """
    Update a flow's properties.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        name: New name
        description: New description
        prompt: Flow purpose (used for routing)
        status: 'Active', 'Draft', or 'Archived'

    Returns:
        Updated flow
    """
    updates = {}
    if name is not None:
        updates["name"] = name
    if description is not None:
        updates["description"] = description
    if prompt is not None:
        updates["prompt"] = prompt
    if status is not None:
        updates["status"] = status

    flow = await client.update_flow(flow_id, **updates)

    return f"# Updated Flow: {flow.get('name')}\nstatus: {flow.get('status')}"


async def flow_delete(
    client: AppliedClient,
    flow_id: str,
) -> str:
    """
    Delete a flow.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID

    Returns:
        Success message
    """
    await client.delete_flow(flow_id)
    return f"Flow {flow_id} deleted successfully."


# -----------------------------------------------------------------------------
# Node Management
# -----------------------------------------------------------------------------


async def flow_node_create(
    client: AppliedClient,
    flow_id: str,
    executor_type: str,
    description: str = "",
    prompt: str = "",
    metadata: dict | None = None,
) -> str:
    """
    Add a node to a flow.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        executor_type: Node type - 'completion', 'structured_completion',
            'branch', 'loop', 'http_request', 'code', 'memory', etc.
        description: Node description
        prompt: Prompt for LLM nodes
        metadata: Node configuration as dict (input_schema, output_schema, etc.)

    Returns:
        Created node with generated ID
    """
    node = await client.create_node(
        flow_id=flow_id,
        name=executor_type,
        description=description,
        prompt=prompt,
        metadata=metadata,
    )

    result = "# Created Node\n"
    result += f"id: {node.get('id')}\n"
    result += f"name: {node.get('name')}\n"
    if description:
        result += f"description: {description}\n"

    return result


async def flow_node_update(
    client: AppliedClient,
    flow_id: str,
    node_id: str,
    description: str | None = None,
    prompt: str | None = None,
    metadata: dict | None = None,
) -> str:
    """
    Update a node's configuration.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        node_id: The node UUID
        description: New description
        prompt: New prompt
        metadata: New metadata (merged with existing)

    Returns:
        Updated node
    """
    updates = {}
    if description is not None:
        updates["description"] = description
    if prompt is not None:
        updates["prompt"] = prompt
    if metadata is not None:
        updates["metadata"] = metadata

    node = await client.update_node(flow_id, node_id, **updates)

    return f"# Updated Node: {node.get('name')}\nid: {node.get('id')}"


async def flow_node_delete(
    client: AppliedClient,
    flow_id: str,
    node_id: str,
) -> str:
    """
    Remove a node from a flow.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        node_id: The node UUID

    Returns:
        Success message
    """
    await client.delete_node(flow_id, node_id)
    return f"Node {node_id} deleted successfully."


# -----------------------------------------------------------------------------
# Edge Management
# -----------------------------------------------------------------------------


async def flow_edge_create(
    client: AppliedClient,
    flow_id: str,
    source_node_id: str,
    target_node_id: str,
    source_handle: str | None = None,
    target_handle: str | None = None,
    label: str | None = None,
) -> str:
    """
    Connect two nodes with an edge.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        source_node_id: Source node UUID
        target_node_id: Target node UUID
        source_handle: Output handle name (for branching)
        target_handle: Input handle name (for mapping)
        label: Edge label/condition

    Returns:
        Created edge
    """
    edge = await client.create_edge(
        flow_id=flow_id,
        source_node_id=source_node_id,
        target_node_id=target_node_id,
        source_handle=source_handle,
        target_handle=target_handle,
        label=label,
    )

    result = "# Created Edge\n"
    result += f"id: {edge.get('id')}\n"
    result += f"source: {edge.get('source')}\n"
    result += f"target: {edge.get('target')}\n"

    return result


async def flow_edge_update(
    client: AppliedClient,
    flow_id: str,
    edge_id: str,
    label: str | None = None,
    metadata: dict | None = None,
) -> str:
    """
    Update an edge's properties.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        edge_id: The edge UUID
        label: New label/condition
        metadata: New metadata

    Returns:
        Updated edge
    """
    updates = {}
    if label is not None:
        updates["label"] = label
    if metadata is not None:
        updates["metadata"] = metadata

    edge = await client.update_edge(flow_id, edge_id, **updates)

    return f"# Updated Edge\nid: {edge.get('id')}"


async def flow_edge_delete(
    client: AppliedClient,
    flow_id: str,
    edge_id: str,
) -> str:
    """
    Remove an edge from a flow.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        edge_id: The edge UUID

    Returns:
        Success message
    """
    await client.delete_edge(flow_id, edge_id)
    return f"Edge {edge_id} deleted successfully."


# -----------------------------------------------------------------------------
# Flow Execution
# -----------------------------------------------------------------------------


async def flow_run(
    client: AppliedClient,
    flow_id: str,
    trigger_data: dict | None = None,
) -> str:
    """
    Execute a flow with test input.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        trigger_data: Trigger input data, e.g.:
            {"message": "Hello"}
            {"message": "Help me", "contact": {"email": "user@example.com"}}
            {"conversation_id": "uuid-of-existing-conversation"}

    Returns:
        Flow run ID, status, and actions summary
    """
    run = await client.run_flow(flow_id, trigger_data)

    result = f"# Flow Run: {run.get('id')}\n"
    result += f"status: {run.get('status')}\n"
    result += f"started_at: {run.get('started_at')}\n"
    result += f"ended_at: {run.get('ended_at')}\n"

    actions = run.get("actions", [])
    if actions:
        result += f"\n## Actions ({len(actions)})\n"
        action_rows = [
            {
                "node": a.get("tool", {}).get("name", ""),
                "status": a.get("status"),
            }
            for a in actions
        ]
        result += to_csv(action_rows, ["node", "status"])

    return result


async def flow_run_list(
    client: AppliedClient,
    flow_id: str | None = None,
    conversation_id: str | None = None,
    status: str | None = None,
    limit: int = 20,
    output_format: str = "csv",
) -> str:
    """
    List recent flow runs.

    Args:
        client: Authenticated AppliedClient
        flow_id: Filter by flow UUID
        conversation_id: Filter by conversation UUID
        status: Filter by status - 'Running', 'Success', 'Failed'
        limit: Max results (default 20)
        output_format: 'csv' or 'json'

    Returns:
        List of flow runs
    """
    runs = await client.list_flow_runs(
        flow_id=flow_id,
        conversation_id=conversation_id,
        status=status,
        limit=limit,
    )
    mapped = [
        {
            "id": r.get("id"),
            "flow_name": r.get("flow", {}).get("name", ""),
            "conversation_id": r.get("conversation_id", ""),
            "status": r.get("status"),
            "started_at": r.get("started_at", "")[:19],
            "duration": r.get("duration"),
        }
        for r in runs
    ]

    if output_format == "csv":
        return to_csv(
            mapped,
            ["id", "flow_name", "conversation_id", "status", "started_at", "duration"],
        )
    return to_json(mapped)


async def flow_run_get(
    client: AppliedClient,
    flow_run_id: str,
) -> str:
    """
    Get a flow run with execution trace.

    Args:
        client: Authenticated AppliedClient
        flow_run_id: The flow run UUID

    Returns:
        Run details, execution trace (spans), and errors
    """
    run = await client.get_flow_run(flow_run_id)

    # Header
    flow = run.get("flow", {})
    result = f"# Flow Run: {run.get('id')}\n"
    result += f"flow: {flow.get('name')} ({flow.get('id')})\n"
    result += f"status: {run.get('status')}\n"
    result += f"started_at: {run.get('started_at')}\n"
    result += f"ended_at: {run.get('ended_at')}\n"
    if run.get("duration"):
        result += f"duration: {run.get('duration')}s\n"

    # Execution trace from spans (API returns snake_case field names)
    spans = run.get("spans", [])
    if spans:
        result += f"\n## Execution Trace ({len(spans)} spans)\n"
        for i, span in enumerate(spans, 1):
            name = span.get("span_name", "")
            duration = span.get("duration", 0)
            status = span.get("status_code", "")
            status_msg = span.get("status_message", "")
            attrs = span.get("span_attributes", {})

            status_str = "OK" if "OK" in str(status) else "ERROR"
            result += f"{i}. [{name}] {duration:.2f}s - {status_str}"
            if status_msg:
                result += f" - {status_msg}"
            result += "\n"

            # Show executor output for executor_run spans
            if name == "executor_run" and attrs.get("output"):
                output = str(attrs.get("output", ""))[:500]
                result += f"   Output: {output}\n"

    # Actions
    actions = run.get("actions", [])
    if actions:
        result += f"\n## Actions ({len(actions)})\n"
        action_rows = [
            {
                "node": a.get("tool", {}).get("name", ""),
                "status": a.get("status"),
                "cost": a.get("cost", 0),
            }
            for a in actions
        ]
        result += to_csv(action_rows, ["node", "status", "cost"])

    # Errors section with detailed debugging info
    errors = [s for s in spans if "ERROR" in str(s.get("status_code", ""))]
    if errors:
        result += "\n## Errors\n"
        for err in errors:
            attrs = err.get("span_attributes", {})
            node_name = attrs.get("tool_name") or attrs.get("toolName") or "unknown"
            error_msg = err.get("status_message", "")

            result += f"**Node:** {node_name}\n"
            if error_msg:
                result += f"**Error:** {error_msg}\n"

            # Include relevant span attributes for debugging
            if attrs.get("output"):
                result += f"**Output:** {str(attrs.get('output'))[:500]}\n"
            if attrs.get("input"):
                result += f"**Input:** {str(attrs.get('input'))[:300]}\n"
            result += "\n"

    return result


async def conversation_spans(
    client: AppliedClient,
    conversation_id: str,
) -> str:
    """
    Get OpenTelemetry spans for a conversation.

    Args:
        client: Authenticated AppliedClient
        conversation_id: The conversation UUID

    Returns:
        Execution trace with spans, errors, and debugging info
    """
    spans = await client.get_spans("conversations", conversation_id)

    if not spans:
        return f"No spans found for conversation {conversation_id}"

    result = f"# Conversation Spans: {conversation_id}\n"
    result += f"Total spans: {len(spans)}\n"

    result += "\n## Execution Trace\n"
    for i, span in enumerate(spans, 1):
        name = span.get("span_name", "")
        scope = span.get("scope_name", "")
        duration = span.get("duration", 0)
        status = span.get("status_code", "")
        status_msg = span.get("status_message", "")
        attrs = span.get("span_attributes", {})

        # Build span identifier
        span_label = name or attrs.get("tool_name", "") or scope or "unknown"
        status_str = "OK" if "OK" in str(status) else "ERROR"

        result += f"{i}. [{span_label}] {duration:.2f}s - {status_str}"
        if status_msg:
            result += f"\n   Message: {status_msg}"
        result += "\n"

        # Show key attributes for debugging
        if attrs.get("output"):
            result += f"   Output: {str(attrs.get('output'))[:300]}\n"

    # Errors section
    errors = [s for s in spans if "ERROR" in str(s.get("status_code", ""))]
    if errors:
        result += "\n## Errors\n"
        for err in errors:
            attrs = err.get("span_attributes", {})
            node_name = attrs.get("tool_name") or err.get("span_name") or "unknown"
            error_msg = err.get("status_message", "")

            result += f"**Node:** {node_name}\n"
            if error_msg:
                result += f"**Error:** {error_msg}\n"
            result += "\n"

    return result


async def executor_list(
    client: AppliedClient,
    output_format: str = "csv",
) -> str:
    """
    List available node types (executors).

    Args:
        client: Authenticated AppliedClient (not used, list is hardcoded)
        output_format: 'csv' or 'json'

    Returns:
        Available executor types with descriptions
    """
    # Hardcoded list of common executors
    executors = [
        {
            "name": "completion",
            "description": "LLM completion node - generates free-form text response",
            "use_case": "Generate responses, summaries, or any text output",
        },
        {
            "name": "structured_completion",
            "description": "LLM completion with structured JSON output",
            "use_case": "Extract data, classify, or generate typed responses",
        },
        {
            "name": "branch",
            "description": "Conditional branching based on LLM decision",
            "use_case": "Route flow based on user intent or conditions",
        },
        {
            "name": "loop",
            "description": "Loop over a list and execute nodes for each item",
            "use_case": "Process multiple items, batch operations",
        },
        {
            "name": "http_request",
            "description": "Make HTTP API calls",
            "use_case": "Integrate with external APIs",
        },
        {
            "name": "code",
            "description": "Execute Python code",
            "use_case": "Data transformation, calculations",
        },
        {
            "name": "memory",
            "description": "Store/retrieve data in conversation memory",
            "use_case": "Remember user preferences, context",
        },
        {
            "name": "global",
            "description": "Global handler for escalation or failure",
            "use_case": "Catch-all for errors or escalation intents",
        },
        {
            "name": "end_flow",
            "description": "Explicitly end the flow",
            "use_case": "Terminate flow execution",
        },
        {
            "name": "_escalate_conversation",
            "description": "Escalate conversation to human agent",
            "use_case": "Hand off to support team",
        },
        {
            "name": "handoff",
            "description": "Hand off to another flow or agent",
            "use_case": "Transfer to specialized flow",
        },
        {
            "name": "search",
            "description": "Search knowledge base",
            "use_case": "Find relevant documentation or Q&A",
        },
    ]

    if output_format == "csv":
        return to_csv(executors, ["name", "description", "use_case"])
    return to_json(executors)
