"""Allow running as: python -m h2ogpte_migration"""

from h2ogpte_migration.cli import main

if __name__ == '__main__':
    main()
