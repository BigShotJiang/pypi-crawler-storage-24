"""
h2oGPTe Migration Tool

A CLI tool for migrating h2oGPTe collections.
"""

__version__ = "1.1.0"
