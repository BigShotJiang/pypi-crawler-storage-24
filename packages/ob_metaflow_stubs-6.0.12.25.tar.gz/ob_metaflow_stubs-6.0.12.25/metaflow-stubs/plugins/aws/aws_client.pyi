######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.21.1+obcheckpoint(0.2.10);<unk>(<unk>);ob(v1)                                     #
# Generated on 2026-03-16T23:47:56.011960                                                            #
######################################################################################################

from __future__ import annotations



cached_aws_sandbox_creds: None

cached_provider_class: None

class Boto3ClientProvider(object, metaclass=type):
    @staticmethod
    def get_client(module, with_error = False, role_arn = None, session_vars = None, client_params = None):
        ...
    ...

def get_aws_client(module, with_error = False, role_arn = None, session_vars = None, client_params = None):
    ...

