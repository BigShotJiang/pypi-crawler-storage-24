######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.21.1+obcheckpoint(0.2.10);<unk>(<unk>);ob(v1)                                     #
# Generated on 2026-03-16T23:47:55.941090                                                            #
######################################################################################################

from __future__ import annotations



MEM_COLOR: str

GPU_COLOR: str

def build_data_json(readings: dict, config: dict) -> dict:
    ...

