######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.21.1+obcheckpoint(0.2.10);<unk>(<unk>);ob(v1)                                     #
# Generated on 2026-03-16T23:47:55.948132                                                            #
######################################################################################################

from __future__ import annotations


from ...plugins.apps.core.exceptions import AppDeploymentException as AppDeploymentException
from ...plugins.apps.core.exceptions import AppCrashLoopException as AppCrashLoopException
from ...plugins.apps.core.exceptions import AppReadinessException as AppReadinessException
from ...plugins.apps.core.exceptions import AppConcurrentUpgradeException as AppConcurrentUpgradeException
from ...plugins.apps.core.exceptions import AppUpgradeInProgressException as AppUpgradeInProgressException
from ...plugins.apps.core.exceptions import AppCreationFailedException as AppCreationFailedException
from ...plugins.apps.core.exceptions import AppNotFoundException as AppNotFoundException
from ...plugins.apps.core.exceptions import AppDeletedDuringDeploymentException as AppDeletedDuringDeploymentException
from ...plugins.apps.core.exceptions import OuterboundsBackendUnhealthyException as OuterboundsBackendUnhealthyException

