######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.21.1+obcheckpoint(0.2.10);<unk>(<unk>);ob(v1)                                     #
# Generated on 2026-03-16T23:47:56.027439                                                            #
######################################################################################################

from __future__ import annotations

import enum
import typing
if typing.TYPE_CHECKING:
    import enum


class Spinners(enum.Enum, metaclass=enum.EnumType):
    def __new__(cls, value):
        ...
    ...

