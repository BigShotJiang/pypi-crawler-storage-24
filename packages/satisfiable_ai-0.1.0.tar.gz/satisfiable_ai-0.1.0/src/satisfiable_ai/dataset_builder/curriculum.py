"""
Pure text-first curriculum configuration.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from typing import Dict, List, Sequence

from .sources import ALL_SOURCES, CODE_SOURCES, DataSource, LAW_SOURCES, MATH_SOURCES, MED_SOURCES, PROOF_SOURCES, REASONING_SOURCES


class Phase(Enum):
    FOUNDATION = auto()
    EXECUTION = auto()
    DOMAIN = auto()
    CONSOLIDATE = auto()


@dataclass(frozen=True)
class PhaseConfig:
    phase: Phase
    sources: List[DataSource]
    token_budget: int
    mix_weights: List[float] | None
    unresolved_budget: float = 0.10
    description: str = ""

    @property
    def frontier_budget(self) -> float:
        return self.unresolved_budget

    @property
    def total_source_tokens(self) -> int:
        return sum(source.estimated_tokens for source in self.sources)

    @property
    def overage_ratio(self) -> float:
        if self.total_source_tokens == 0:
            return 1.0
        return self.token_budget / self.total_source_tokens


@dataclass(frozen=True)
class CurriculumSchedule:
    phases: List[PhaseConfig]

    def by_phase(self, phase: Phase) -> PhaseConfig:
        for config in self.phases:
            if config.phase == phase:
                return config
        raise KeyError(phase)


EXPECTED_FRONTIER_RATE: Dict[Phase, float] = {
    Phase.FOUNDATION: 0.05,
    Phase.EXECUTION: 0.10,
    Phase.DOMAIN: 0.12,
    Phase.CONSOLIDATE: 0.15,
}


def default_schedule() -> CurriculumSchedule:
    phases = [
        PhaseConfig(
            phase=Phase.FOUNDATION,
            sources=MATH_SOURCES + REASONING_SOURCES,
            token_budget=5_000_000_000,
            mix_weights=None,
            unresolved_budget=0.05,
            description="Broad math + reasoning base before task specialization.",
        ),
        PhaseConfig(
            phase=Phase.EXECUTION,
            sources=CODE_SOURCES + PROOF_SOURCES,
            token_budget=750_000_000,
            mix_weights=None,
            unresolved_budget=0.10,
            description="Executable code plus formal proof text.",
        ),
        PhaseConfig(
            phase=Phase.DOMAIN,
            sources=MED_SOURCES + LAW_SOURCES,
            token_budget=500_000_000,
            mix_weights=None,
            unresolved_budget=0.12,
            description="High-value domain text once the core verifier behavior is learned.",
        ),
        PhaseConfig(
            phase=Phase.CONSOLIDATE,
            sources=list(ALL_SOURCES),
            token_budget=1_000_000_000,
            mix_weights=None,
            unresolved_budget=0.15,
            description="Joint text-only consolidation across all public domains.",
        ),
    ]
    return CurriculumSchedule(phases=phases)


def build_domain_schedule(domains: Sequence[str], token_budget_per_domain: int = 100_000_000) -> CurriculumSchedule:
    chosen_domains = set(domains)
    selected = [source for source in ALL_SOURCES if source.domain in chosen_domains]
    by_domain: Dict[str, List[DataSource]] = {}
    for source in selected:
        by_domain.setdefault(source.domain, []).append(source)

    phases = [
        PhaseConfig(
            phase=Phase.CONSOLIDATE,
            sources=sources,
            token_budget=token_budget_per_domain,
            mix_weights=None,
            unresolved_budget=0.10,
            description=f"Focused schedule for {domain}.",
        )
        for domain, sources in sorted(by_domain.items())
    ]
    return CurriculumSchedule(phases=phases)


def expected_frontier_rate(phase: Phase) -> float:
    return EXPECTED_FRONTIER_RATE[phase]
