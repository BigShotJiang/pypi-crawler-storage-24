"""
Text dataset builder surface.

- sources.py    -> pure registry/config
- curriculum.py -> pure scheduling/config
- runtime.py    -> optional HuggingFace/PyTorch backend
"""

from __future__ import annotations

from importlib import import_module
from typing import Any

from .curriculum import CurriculumSchedule, Phase, PhaseConfig, build_domain_schedule, default_schedule
from .sources import (
    ALL_SOURCES,
    CODE_SOURCES,
    DataSource,
    LAW_SOURCES,
    MATH_SOURCES,
    MED_SOURCES,
    PROOF_SOURCES,
    REASONING_SOURCES,
)

_RUNTIME_EXPORTS = {
    "VerifiedSample",
    "VerifiedDataset",
    "StreamingVerifiedDataset",
    "load_verified_sources",
    "interleave_sources",
}


def __getattr__(name: str) -> Any:
    if name in _RUNTIME_EXPORTS:
        mod = import_module(".runtime", __name__)
        return getattr(mod, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "ALL_SOURCES", "CODE_SOURCES", "DataSource",
    "LAW_SOURCES", "MATH_SOURCES", "MED_SOURCES",
    "PROOF_SOURCES", "REASONING_SOURCES",
    "CurriculumSchedule", "Phase", "PhaseConfig",
    "build_domain_schedule", "default_schedule",
    "VerifiedSample", "VerifiedDataset", "StreamingVerifiedDataset",
    "load_verified_sources", "interleave_sources",
]
