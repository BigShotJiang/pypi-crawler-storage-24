"""
Pure text source registry.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional


@dataclass(frozen=True)
class DataSource:
    name: str
    hf_path: str
    hf_subset: Optional[str] = None
    split: str = "train"
    text_key: str = "text"
    estimated_tokens: int = 0
    domain: str = "logic"
    priority: int = 1
    requires_verification: bool = True
    filter_terms: Optional[List[str]] = None
    answer_key: Optional[str] = None
    local_path: Optional[str] = None
    local_format: str = "jsonl"


MATH_SOURCES = [
    DataSource(
        name="open_math_instruct_2",
        hf_path="nvidia/OpenMathInstruct-2",
        text_key="problem",
        estimated_tokens=4_200_000_000,
        domain="math",
        priority=3,
    ),
    DataSource(
        name="prm800k",
        hf_path="openai/prm800k-solutions",
        hf_subset="phase2_train",
        text_key="question",
        estimated_tokens=500_000_000,
        domain="math",
        priority=3,
    ),
    DataSource(
        name="gsm8k",
        hf_path="openai/gsm8k",
        hf_subset="main",
        text_key="question",
        estimated_tokens=3_000_000,
        domain="math",
        priority=1,
    ),
    DataSource(
        name="math_hendrycks",
        hf_path="hendrycks/competition_math",
        text_key="problem",
        estimated_tokens=20_000_000,
        domain="math",
        priority=1,
    ),
]

CODE_SOURCES = [
    DataSource(
        name="code_contests",
        hf_path="deepmind/code_contests",
        text_key="description",
        estimated_tokens=26_000_000,
        domain="code",
        priority=2,
    ),
    DataSource(
        name="apps",
        hf_path="codeparrot/apps",
        text_key="question",
        estimated_tokens=10_000_000,
        domain="code",
        priority=2,
    ),
    DataSource(
        name="mbpp",
        hf_path="google-research-datasets/mbpp",
        text_key="text",
        estimated_tokens=500_000,
        domain="code",
        priority=1,
    ),
    DataSource(
        name="humaneval",
        hf_path="openai/openai_humaneval",
        split="test",
        text_key="prompt",
        estimated_tokens=500_000,
        domain="code",
        priority=1,
    ),
]

PROOF_SOURCES = [
    DataSource(
        name="lean_workbook",
        hf_path="internlm/Lean-Workbook",
        text_key="formal_statement",
        estimated_tokens=10_000_000,
        domain="proof",
        priority=3,
    ),
    DataSource(
        name="minif2f",
        hf_path="cat-searcher/minif2f-lean4",
        text_key="formal_statement",
        estimated_tokens=1_000_000,
        domain="proof",
        priority=2,
    ),
]

REASONING_SOURCES = [
    DataSource(
        name="aqua_rat",
        hf_path="deepmind/aqua_rat",
        hf_subset="raw",
        text_key="question",
        estimated_tokens=5_000_000,
        domain="math",
        priority=2,
    ),
    DataSource(
        name="ai2_arc",
        hf_path="allenai/ai2_arc",
        hf_subset="ARC-Challenge",
        text_key="question",
        estimated_tokens=1_000_000,
        domain="logic",
        priority=1,
    ),
    DataSource(
        name="natural_reasoning",
        hf_path="facebook/natural_reasoning",
        text_key="question",
        estimated_tokens=900_000_000,
        domain="logic",
        priority=2,
    ),
    DataSource(
        name="countdown_tasks",
        hf_path="Jiayi-Pan/Countdown-Tasks-3to4",
        text_key="question",
        estimated_tokens=2_000_000,
        domain="math",
        priority=3,
    ),
]

MED_SOURCES = [
    DataSource(
        name="pubmed_qa",
        hf_path="qiaojin/PubMedQA",
        hf_subset="pqa_labeled",
        text_key="question",
        answer_key="final_decision",
        estimated_tokens=5_000_000,
        domain="med",
        priority=2,
    ),
    DataSource(
        name="medmcqa",
        hf_path="openlifescienceai/medmcqa",
        text_key="question",
        answer_key="exp",
        estimated_tokens=20_000_000,
        domain="med",
        priority=2,
    ),
    DataSource(
        name="medqa_usmle",
        hf_path="GBaker/MedQA-USMLE-4-options",
        text_key="question",
        answer_key="answer",
        estimated_tokens=8_000_000,
        domain="med",
        priority=3,
    ),
]

LAW_SOURCES = [
    DataSource(
        name="casehold",
        hf_path="casehold/casehold",
        hf_subset="all",
        text_key="citing_prompt",
        estimated_tokens=30_000_000,
        domain="law",
        priority=3,
    ),
    DataSource(
        name="pile_of_law",
        hf_path="pile-of-law/pile-of-law",
        hf_subset="r_legaladvice",
        text_key="text",
        estimated_tokens=200_000_000,
        domain="law",
        priority=2,
    ),
    DataSource(
        name="lexglue_ecthr",
        hf_path="coastalcph/lex_glue",
        hf_subset="ecthr_a",
        text_key="text",
        estimated_tokens=15_000_000,
        domain="law",
        priority=2,
    ),
]

ALL_SOURCES = (
    MATH_SOURCES
    + CODE_SOURCES
    + PROOF_SOURCES
    + REASONING_SOURCES
    + MED_SOURCES
    + LAW_SOURCES
)
