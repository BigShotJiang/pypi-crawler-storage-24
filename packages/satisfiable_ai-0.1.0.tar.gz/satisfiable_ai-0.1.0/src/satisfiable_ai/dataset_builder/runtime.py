"""
Optional HuggingFace/PyTorch runtime for verified text datasets.
"""

from __future__ import annotations

import json
import logging
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

try:
    import torch as _torch
    from torch.utils.data import Dataset as _Dataset, IterableDataset as _IterableDataset
except (ModuleNotFoundError, ImportError, RuntimeError) as exc:
    _torch = None
    _Dataset = object  # type: ignore[assignment]
    _IterableDataset = object  # type: ignore[assignment]
    _TORCH_IMPORT_ERROR: BaseException | None = exc
else:
    _TORCH_IMPORT_ERROR = None

from satisfaction_suffices.verifier.verify import VerificationGate, VerificationResult, Verdict, get_gate
from .sources import ALL_SOURCES, DataSource

logger = logging.getLogger(__name__)


def _require_torch() -> Any:
    if _torch is None:
        raise RuntimeError(
            "PyTorch dataset/tensor support is unavailable in this environment. "
            "Install a healthy torch build with: uv pip install -e \".[torch]\""
        ) from _TORCH_IMPORT_ERROR
    return _torch


@dataclass
class VerifiedSample:
    text: str
    source: str
    domain: str
    verification: VerificationResult
    answer: Optional[str] = None
    tokens: Optional[List[int]] = None

    @property
    def is_verified(self) -> bool:
        return self.verification.verdict == Verdict.VERIFIED

    @property
    def is_frontier(self) -> bool:
        return self.verification.is_frontier

    @property
    def is_contradiction(self) -> bool:
        return self.verification.is_contradiction


class VerifiedDataset(_Dataset):
    def __init__(
        self,
        samples: List[Dict[str, Any]],
        *,
        text_key: str = "text",
        domain: str = "logic",
        source_name: str = "unknown",
        gate: Optional[VerificationGate] = None,
        strict: bool = True,
        tokenizer: Optional[Any] = None,
        max_seq_len: int = 2048,
    ) -> None:
        self.gate = gate or get_gate()
        self.strict = strict
        self.tokenizer = tokenizer
        self.max_seq_len = max_seq_len
        self.verified: List[VerifiedSample] = []
        self.frontier: List[VerifiedSample] = []
        self.rejected: List[VerifiedSample] = []

        for sample in samples:
            text = sample.get(text_key, "")
            if not isinstance(text, str) or not text.strip():
                continue

            result = self.gate.verify(text, domain=domain)
            verified = VerifiedSample(
                text=text,
                source=source_name,
                domain=domain,
                verification=result,
                answer=str(sample.get("answer", "")) or None,
            )
            if self.tokenizer is not None:
                verified.tokens = self.tokenizer.encode(text)[: self.max_seq_len]

            if result.verdict == Verdict.VERIFIED:
                self.verified.append(verified)
            elif result.is_frontier:
                self.frontier.append(verified)
                if not strict:
                    self.verified.append(verified)
            else:
                self.rejected.append(verified)

    def __len__(self) -> int:
        return len(self.verified)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        sample = self.verified[idx]
        out: Dict[str, Any] = {"text": sample.text, "domain": sample.domain}
        if sample.answer is not None:
            out["answer"] = sample.answer
        if sample.tokens is not None:
            torch = _require_torch()
            out["input_ids"] = torch.tensor(sample.tokens, dtype=torch.long)
        return out


class StreamingVerifiedDataset(_IterableDataset):
    def __init__(
        self,
        source: DataSource,
        *,
        gate: Optional[VerificationGate] = None,
        tokenizer: Optional[Any] = None,
        max_seq_len: int = 2048,
        strict: bool = True,
    ) -> None:
        self.source = source
        self.gate = gate or get_gate()
        self.tokenizer = tokenizer
        self.max_seq_len = max_seq_len
        self.strict = strict

    def __iter__(self) -> Iterator[Dict[str, Any]]:
        if self.source.local_path:
            yield from self._iter_local()
            return

        try:
            from datasets import load_dataset
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                "Streaming HuggingFace loading requires datasets. "
                "Install with: uv pip install -e \".[datasets]\""
            ) from exc

        dataset = load_dataset(
            self.source.hf_path,
            self.source.hf_subset,
            split=self.source.split,
            streaming=True,
        )
        for sample in dataset:
            text = sample.get(self.source.text_key, "")
            answer = sample.get(self.source.answer_key, "") if self.source.answer_key else None
            yield from self._process_text(text, answer=answer)

    def _iter_local(self) -> Iterator[Dict[str, Any]]:
        local = Path(self.source.local_path or "")
        if not local.exists():
            raise FileNotFoundError(f"Local source not found: {local}")

        files: List[Path]
        if local.is_file():
            files = [local]
        elif self.source.local_format == "jsonl":
            files = sorted(local.rglob("*.jsonl"))
        elif self.source.local_format == "txt":
            files = sorted(local.rglob("*.txt"))
        else:
            raise ValueError(f"Unsupported local_format: {self.source.local_format}")

        for path in files:
            if self.source.local_format == "jsonl":
                with path.open("r", encoding="utf-8") as handle:
                    for line in handle:
                        line = line.strip()
                        if not line:
                            continue
                        obj = json.loads(line)
                        text = obj.get(self.source.text_key, "")
                        answer = obj.get(self.source.answer_key, "") if self.source.answer_key else None
                        yield from self._process_text(text, answer=answer)
            elif self.source.local_format == "txt":
                content = path.read_text(encoding="utf-8", errors="ignore")
                for part in [chunk.strip() for chunk in content.split("\n\n") if chunk.strip()]:
                    yield from self._process_text(part)

    def _process_text(self, text: Any, answer: Any = None) -> Iterator[Dict[str, Any]]:
        if isinstance(text, list):
            text = " ".join(str(item) for item in text if item)
        if not isinstance(text, str) or not text.strip():
            return

        if self.source.filter_terms:
            text_lower = text.lower()
            if not any(term.lower() in text_lower for term in self.source.filter_terms):
                return

        if self.source.requires_verification:
            result = self.gate.verify(text, domain=self.source.domain)
            if result.is_rejected:
                return
            if result.is_frontier and self.strict:
                return

        out: Dict[str, Any] = {"text": text, "domain": self.source.domain}
        if answer not in (None, ""):
            out["answer"] = str(answer)
        if self.tokenizer is not None:
            tokens = self.tokenizer.encode(text)[: self.max_seq_len]
            torch = _require_torch()
            out["input_ids"] = torch.tensor(tokens, dtype=torch.long)
        yield out


def load_verified_sources(
    sources: Optional[List[DataSource]] = None,
    *,
    gate: Optional[VerificationGate] = None,
    tokenizer: Optional[Any] = None,
    max_seq_len: int = 2048,
    strict: bool = True,
) -> List[StreamingVerifiedDataset]:
    chosen_sources = list(sources or ALL_SOURCES)
    chosen_sources.sort(key=lambda source: source.priority, reverse=True)
    gate = gate or get_gate()
    return [
        StreamingVerifiedDataset(
            source=source,
            gate=gate,
            tokenizer=tokenizer,
            max_seq_len=max_seq_len,
            strict=strict,
        )
        for source in chosen_sources
    ]


def interleave_sources(
    datasets: List[StreamingVerifiedDataset],
    weights: Optional[List[float]] = None,
) -> Iterator[Dict[str, Any]]:
    if not datasets:
        return iter(())

    if weights is None:
        weights = [dataset.source.priority for dataset in datasets]
    if len(weights) != len(datasets):
        raise ValueError("weights length must match datasets length")

    iterators = [iter(dataset) for dataset in datasets]
    active = list(range(len(iterators)))
    base_weights = list(weights)

    while active:
        active_weights = [base_weights[i] for i in active]
        index = random.choices(active, weights=active_weights, k=1)[0]
        try:
            yield next(iterators[index])
        except StopIteration:
            active.remove(index)
