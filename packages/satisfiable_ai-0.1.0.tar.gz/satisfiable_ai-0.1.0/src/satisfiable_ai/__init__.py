"""
satisfiable-ai — HuggingFace dataset wrappers for SAT-verified training data.

Core verification and logic live in ``satisfaction-suffices``.
This package provides dataset loading, curriculum ordering, and training
integration on top of that foundation.

    from satisfiable_ai.dataset_builder import DataSource, default_schedule
    from satisfiable_ai import VerifiedDataset
"""

from satisfaction_suffices import (
    BoolExpr,
    BoolOp,
    CDCLSolver,
    ClauseStatus,
    CodeConstraintExtractor,
    ConstraintExtractor,
    LogicConstraintExtractor,
    MathConstraintExtractor,
    PartialConstraintEvaluator,
    PrefixFeasibilityResult,
    ProofConstraintExtractor,
    SATReward,
    TextTo3SAT,
    TseitinEncoder,
    VerificationError,
    VerificationGate,
    VerificationResult,
    Verdict,
    evaluate_partial,
    get_gate,
    must_verify,
    sat_score,
    solve_cnf,
    text_to_3sat,
    text_to_3sat_grouped,
    tokens_to_3sat,
    verify,
)
from .dataset_builder import (
    ALL_SOURCES,
    CODE_SOURCES,
    DataSource,
    LAW_SOURCES,
    MATH_SOURCES,
    MED_SOURCES,
    PROOF_SOURCES,
    REASONING_SOURCES,
    CurriculumSchedule,
    Phase,
    PhaseConfig,
    build_domain_schedule,
    default_schedule,
)

__version__ = "0.1.0"

__all__ = [
    # Dataset sources
    "ALL_SOURCES", "CODE_SOURCES", "DataSource",
    "LAW_SOURCES", "MATH_SOURCES", "MED_SOURCES",
    "PROOF_SOURCES", "REASONING_SOURCES",
    # Curriculum
    "CurriculumSchedule", "Phase", "PhaseConfig",
    "build_domain_schedule", "default_schedule",
    # Runtime (lazy — imported on demand from dataset_builder)
    "VerifiedDataset", "StreamingVerifiedDataset",
    "load_verified_sources", "interleave_sources",
    # Verifier re-exports (convenience)
    "verify", "must_verify", "get_gate", "Verdict",
    "VerificationGate", "VerificationResult", "VerificationError",
]
