from __future__ import annotations

import json
from pathlib import Path

from satisfiable_ai.dataset_builder import (
    DataSource,
    StreamingVerifiedDataset,
    VerifiedDataset,
    interleave_sources,
    load_verified_sources,
)


def test_verified_dataset_filters_frontier_when_strict() -> None:
    dataset = VerifiedDataset(
        samples=[
            {"text": "if A then B. A."},
            {"text": "A. not A."},
        ],
        domain="logic",
        source_name="local",
        strict=True,
    )
    assert len(dataset) == 1
    assert len(dataset.frontier) == 1
    row = dataset[0]
    assert row["domain"] == "logic"
    assert "input_ids" not in row


def test_streaming_local_jsonl_and_loader(tmp_path: Path) -> None:
    data_path = tmp_path / "samples.jsonl"
    rows = [
        {"text": "if A then B. A."},
        {"text": "A. not A."},
    ]
    with data_path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row) + "\n")

    source = DataSource(
        name="local_logic",
        hf_path="",
        local_path=str(data_path),
        local_format="jsonl",
        text_key="text",
        domain="logic",
        priority=2,
    )
    dataset = StreamingVerifiedDataset(source, strict=True)
    out = list(dataset)
    assert len(out) == 1
    assert out[0]["domain"] == "logic"

    wrapped = load_verified_sources([source], strict=True)
    interleaved = list(interleave_sources(wrapped))
    assert len(interleaved) == 1
