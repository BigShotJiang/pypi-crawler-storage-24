from __future__ import annotations

from satisfiable_ai.dataset_builder import Phase, build_domain_schedule, default_schedule


def test_default_schedule_contains_expected_phases() -> None:
    schedule = default_schedule()
    assert schedule.by_phase(Phase.FOUNDATION).token_budget > 0
    assert schedule.by_phase(Phase.CONSOLIDATE).sources


def test_build_domain_schedule_filters_domains() -> None:
    schedule = build_domain_schedule(["law", "med"], token_budget_per_domain=123)
    assert schedule.phases
    for phase in schedule.phases:
        assert phase.token_budget == 123
        assert {source.domain for source in phase.sources} <= {"law", "med"}
