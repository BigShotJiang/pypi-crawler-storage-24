def print_flag():
    print("flag{I_Th1nk_y0u_got_th3_wr0ng_p4ck4ge}")
    return None