# PiIlow

## Objective

This is a small package for CTF purposes. It tries to be have simmilar name of "Pillow" package just to illutsrate supply chain attack.

You can find the right package [here](https://pypi.org/project/pillow/)