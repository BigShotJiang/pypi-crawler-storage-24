from setuptools import setup

setup(name='project1003202652',
      version='0.0',
      description='Gaussian and Binomial distributions',
      packages=['project1003202652'],
      author_email='germusi@mail.ru',
      zip_safe=False)