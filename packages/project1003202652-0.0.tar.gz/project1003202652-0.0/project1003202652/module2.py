def func1():
    return 'Hello from SVO'