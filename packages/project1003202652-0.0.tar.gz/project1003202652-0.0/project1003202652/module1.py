def func1():
    return 'Hello from RTU MIREA'