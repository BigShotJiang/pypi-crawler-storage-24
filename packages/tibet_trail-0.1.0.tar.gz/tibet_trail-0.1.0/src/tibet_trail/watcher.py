"""
Poll-based file watcher for TIBET audit trail files.

Watches a JSONL file for new tokens appended at the end.
"""

import os
import time
import threading
from pathlib import Path
from typing import Callable, Optional

from tibet_core.token import Token


class TrailWatcher:
    """
    Poll-based file watcher for JSONL audit trail files.

    Detects new lines appended to the file and parses them as tokens.

    Args:
        path: Path to JSONL file to watch.
        interval: Poll interval in seconds (default: 1.0).
    """

    def __init__(self, path: str, interval: float = 1.0):
        self.path = Path(path)
        self.interval = interval

    def watch(
        self,
        callback: Callable[[Token], None],
        stop_event: Optional[threading.Event] = None,
    ) -> None:
        """
        Watch for new tokens (blocking).

        Reads from the current end of file and calls callback
        for each new token that appears.

        Args:
            callback: Called with each new Token.
            stop_event: Optional threading.Event to signal stop.
                        If None, runs until KeyboardInterrupt.
        """
        # Wait for file to exist
        file_existed = self.path.exists()
        while not self.path.exists():
            if stop_event and stop_event.is_set():
                return
            time.sleep(self.interval)

        # If file existed before watch started, seek to end.
        # If file was just created, start from beginning (offset 0).
        offset = self.path.stat().st_size if file_existed else 0

        while True:
            if stop_event and stop_event.is_set():
                break

            try:
                current_size = self.path.stat().st_size
            except OSError:
                time.sleep(self.interval)
                continue

            if current_size > offset:
                with open(self.path, "r", encoding="utf-8") as f:
                    f.seek(offset)
                    new_data = f.read()
                    offset = f.tell()

                for line in new_data.splitlines():
                    line = line.strip()
                    if line:
                        try:
                            token = Token.from_json(line)
                            callback(token)
                        except Exception:
                            pass  # Skip malformed lines

            time.sleep(self.interval)
