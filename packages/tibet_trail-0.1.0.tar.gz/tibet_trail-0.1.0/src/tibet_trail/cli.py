"""
CLI interface for tibet-trail.

Provides 7 subcommands: log, search, trace, watch, verify, stats, export.
"""

import argparse
import sys
from pathlib import Path

from .reader import TrailReader
from .formatter import (
    format_table,
    format_token_text,
    format_token_json,
    format_chain,
    format_stats,
    format_verify,
)


def _is_tty() -> bool:
    """Check if stdout is a terminal (for ANSI color support)."""
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def cmd_log(args: argparse.Namespace) -> None:
    """Show recent tokens."""
    reader = TrailReader(args.file)
    tokens = reader.log(n=args.n)
    if not tokens:
        print("No tokens found.")
        return
    color = _is_tty() and args.format == "text"
    print(format_table(tokens, fmt=args.format, color=color))


def cmd_search(args: argparse.Namespace) -> None:
    """Search tokens."""
    reader = TrailReader(args.file)
    tokens = reader.search(
        action=args.action,
        actor=args.actor,
        since=args.since,
        limit=args.n,
    )
    if not tokens:
        print("No matching tokens found.")
        return
    color = _is_tty() and args.format == "text"
    print(format_table(tokens, fmt=args.format, color=color))


def cmd_trace(args: argparse.Namespace) -> None:
    """Trace provenance chain."""
    reader = TrailReader(args.file)
    tokens = reader.trace(args.token_id, max_depth=args.depth)
    if not tokens:
        print(f"Token not found: {args.token_id}")
        return
    color = _is_tty()
    if args.format == "json":
        import json
        print(json.dumps([t.to_dict() for t in tokens], indent=2, default=str))
    else:
        print(f"Chain length: {len(tokens)}")
        print(format_chain(tokens, color=color))


def cmd_watch(args: argparse.Namespace) -> None:
    """Watch for new tokens (live tail)."""
    reader = TrailReader(args.file)
    color = _is_tty()

    filter_actor = getattr(args, "filter_actor", None)

    def on_token(token):
        if filter_actor and token.actor != filter_actor:
            return
        if args.format == "json":
            print(format_token_json(token))
        else:
            print(format_token_text(token, color=color))

    print(f"Watching {args.file} (Ctrl+C to stop)...")
    try:
        reader.tail(on_token, interval=getattr(args, "interval", 1.0))
    except KeyboardInterrupt:
        print("\nStopped.")


def cmd_verify(args: argparse.Namespace) -> None:
    """Verify file integrity."""
    reader = TrailReader(args.file)
    result = reader.verify(key=args.key)
    color = _is_tty()
    print(format_verify(result, color=color))
    if not result["integrity"]:
        sys.exit(1)


def cmd_stats(args: argparse.Namespace) -> None:
    """Show audit trail statistics."""
    reader = TrailReader(args.file)
    stats = reader.stats()
    if args.format == "json":
        import json
        print(json.dumps(stats, indent=2, default=str))
    else:
        color = _is_tty()
        print(format_stats(stats, color=color))


def cmd_export(args: argparse.Namespace) -> None:
    """Export tokens to file."""
    reader = TrailReader(args.file)
    tokens = reader.log(n=0) or reader.store.all()
    color = False  # No color for file export

    output = format_table(tokens, fmt=args.format, color=color)

    outpath = Path(args.output)
    outpath.write_text(output, encoding="utf-8")
    print(f"Exported {len(tokens)} tokens to {outpath}")


def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser."""
    parser = argparse.ArgumentParser(
        prog="tibet-trail",
        description="CLI audit trail reader for TIBET provenance tokens",
    )
    parser.add_argument("--version", action="version", version="tibet-trail 0.1.0")

    sub = parser.add_subparsers(dest="command", help="Available commands")

    # log
    p_log = sub.add_parser("log", help="Show recent tokens")
    p_log.add_argument("file", help="Path to JSONL audit trail file")
    p_log.add_argument("-n", type=int, default=20, help="Number of tokens (default: 20)")
    p_log.add_argument("--format", choices=["text", "json", "csv"], default="text")

    # search
    p_search = sub.add_parser("search", help="Search tokens")
    p_search.add_argument("file", help="Path to JSONL audit trail file")
    p_search.add_argument("--action", help="Action pattern (regex supported)")
    p_search.add_argument("--actor", help="Actor to filter by")
    p_search.add_argument("--since", help="Time filter (e.g., 1h, 2d, 30m)")
    p_search.add_argument("-n", type=int, default=100, help="Max results (default: 100)")
    p_search.add_argument("--format", choices=["text", "json", "csv"], default="text")

    # trace
    p_trace = sub.add_parser("trace", help="Trace provenance chain")
    p_trace.add_argument("file", help="Path to JSONL audit trail file")
    p_trace.add_argument("token_id", help="Token ID to trace")
    p_trace.add_argument("--depth", type=int, default=100, help="Max chain depth (default: 100)")
    p_trace.add_argument("--format", choices=["text", "json"], default="text")

    # watch
    p_watch = sub.add_parser("watch", help="Watch for new tokens (live tail)")
    p_watch.add_argument("file", help="Path to JSONL audit trail file")
    p_watch.add_argument("--filter-actor", help="Only show tokens from this actor")
    p_watch.add_argument("--interval", type=float, default=1.0, help="Poll interval in seconds")
    p_watch.add_argument("--format", choices=["text", "json"], default="text")

    # verify
    p_verify = sub.add_parser("verify", help="Verify file integrity")
    p_verify.add_argument("file", help="Path to JSONL audit trail file")
    p_verify.add_argument("--key", help="HMAC key as hex string")

    # stats
    p_stats = sub.add_parser("stats", help="Show audit trail statistics")
    p_stats.add_argument("file", help="Path to JSONL audit trail file")
    p_stats.add_argument("--format", choices=["text", "json"], default="text")

    # export
    p_export = sub.add_parser("export", help="Export tokens to file")
    p_export.add_argument("file", help="Path to JSONL audit trail file")
    p_export.add_argument("output", help="Output file path")
    p_export.add_argument("--format", choices=["csv", "json", "text"], default="csv")

    return parser


def main(argv=None) -> None:
    """Main entry point."""
    parser = build_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        sys.exit(1)

    commands = {
        "log": cmd_log,
        "search": cmd_search,
        "trace": cmd_trace,
        "watch": cmd_watch,
        "verify": cmd_verify,
        "stats": cmd_stats,
        "export": cmd_export,
    }

    try:
        commands[args.command](args)
    except FileNotFoundError:
        print(f"Error: File not found: {args.file}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
