"""
tibet-trail — CLI audit trail reader for TIBET provenance tokens.

Reads, searches, and monitors JSONL audit trails written by tibet-core FileStore.
"""

__version__ = "0.1.0"

from .reader import TrailReader
from .formatter import format_token_text, format_token_json, format_tokens_csv, format_table
from .timeparse import parse_relative_time
from .watcher import TrailWatcher

__all__ = [
    "TrailReader",
    "TrailWatcher",
    "format_token_text",
    "format_token_json",
    "format_tokens_csv",
    "format_table",
    "parse_relative_time",
]
