"""
TrailReader — High-level audit trail reader.

Wraps FileStore and Chain to provide a simple API for reading,
searching, and verifying TIBET audit trails.
"""

import re
from typing import Callable, Dict, Any, List, Optional

from tibet_core.token import Token
from tibet_core.store import FileStore
from tibet_core.chain import Chain

from .timeparse import parse_relative_time
from .watcher import TrailWatcher


class TrailReader:
    """
    Read and query a TIBET audit trail file.

    Args:
        path: Path to JSONL audit trail file.
    """

    def __init__(self, path: str):
        self.path = path
        self.store = FileStore(path)
        self.chain = Chain(self.store)

    def log(self, n: int = 20) -> List[Token]:
        """
        Get the last N tokens.

        Args:
            n: Number of tokens to return (default: 20)

        Returns:
            List of tokens (newest last)
        """
        all_tokens = self.store.all()
        return all_tokens[-n:]

    def search(
        self,
        action: Optional[str] = None,
        actor: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 100,
    ) -> List[Token]:
        """
        Search tokens with filtering.

        Args:
            action: Regex pattern to match action field
            actor: Exact actor match
            since: Relative time ("1h", "2d") or ISO timestamp
            limit: Max results

        Returns:
            Matching tokens
        """
        # Parse relative time if provided
        since_ts = None
        if since:
            since_ts = parse_relative_time(since)

        # If action is a regex pattern, we do manual filtering
        if action and _is_regex(action):
            pattern = re.compile(action)
            all_tokens = self.store.find(actor=actor, since=since_ts, limit=0) if actor or since_ts else self.store.all()
            # Filter for since manually if limit=0 isn't supported
            if since_ts:
                all_tokens = [t for t in all_tokens if t.timestamp >= since_ts]
            if actor:
                all_tokens = [t for t in all_tokens if t.actor == actor]
            results = [t for t in all_tokens if pattern.search(t.action)]
            return results[-limit:]

        return self.store.find(action=action, actor=actor, since=since_ts, limit=limit)

    def trace(self, token_id: str, max_depth: int = 100) -> List[Token]:
        """
        Trace provenance chain for a token.

        Args:
            token_id: Starting token ID
            max_depth: Maximum chain depth

        Returns:
            List of tokens from newest to oldest
        """
        return self.chain.trace(token_id, max_depth=max_depth)

    def verify(self, key: Optional[str] = None) -> Dict[str, Any]:
        """
        Verify file integrity.

        Args:
            key: Optional HMAC key as hex string

        Returns:
            Verification result dict
        """
        if key:
            # FileStore.verify_file() doesn't accept key, so verify manually
            key_bytes = bytes.fromhex(key)
            valid = 0
            invalid = []
            for token in self.store.all():
                if token.verify(key_bytes):
                    valid += 1
                else:
                    invalid.append(token.token_id)
            return {
                "valid": valid,
                "invalid": len(invalid),
                "corrupted_ids": invalid,
                "integrity": len(invalid) == 0,
            }
        return self.store.verify_file()

    def stats(self) -> Dict[str, Any]:
        """
        Get audit trail statistics.

        Returns:
            Dict with counts, unique actors/actions, time range
        """
        tokens = self.store.all()
        if not tokens:
            return {
                "total": 0,
                "actor_count": 0,
                "action_count": 0,
                "actors": [],
                "actions": [],
                "first_timestamp": None,
                "last_timestamp": None,
            }

        actors = sorted(set(t.actor for t in tokens))
        actions = sorted(set(t.action for t in tokens))

        return {
            "total": len(tokens),
            "actor_count": len(actors),
            "action_count": len(actions),
            "actors": actors,
            "actions": actions,
            "first_timestamp": tokens[0].timestamp,
            "last_timestamp": tokens[-1].timestamp,
        }

    def tail(self, callback: Callable[[Token], None], interval: float = 1.0) -> None:
        """
        Watch for new tokens (blocking).

        Args:
            callback: Called for each new token
            interval: Poll interval in seconds
        """
        watcher = TrailWatcher(self.path, interval=interval)
        watcher.watch(callback)


def _is_regex(s: str) -> bool:
    """Check if a string looks like a regex pattern."""
    return bool(set(s) & set(".*+?[](){}^$|\\"))
