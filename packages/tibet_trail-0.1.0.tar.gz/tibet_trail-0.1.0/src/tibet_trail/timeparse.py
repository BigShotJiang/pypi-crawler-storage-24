"""
Human-friendly relative time parsing.

Supports suffixes: s (seconds), m (minutes), h (hours), d (days), w (weeks).
ISO timestamps pass through unchanged.
"""

import re
from datetime import datetime, timedelta, timezone

_PATTERN = re.compile(r"^(\d+)([smhdw])$")

_UNITS = {
    "s": "seconds",
    "m": "minutes",
    "h": "hours",
    "d": "days",
    "w": "weeks",
}


def parse_relative_time(s: str) -> str:
    """
    Parse a relative time string into an ISO timestamp.

    Args:
        s: Relative time like "1h", "30m", "2d", "1w"
           or an ISO timestamp (passed through).

    Returns:
        ISO format timestamp string.

    Raises:
        ValueError: If the string cannot be parsed.
    """
    s = s.strip()

    match = _PATTERN.match(s)
    if match:
        amount = int(match.group(1))
        unit = match.group(2)
        delta = timedelta(**{_UNITS[unit]: amount})
        dt = datetime.now(timezone.utc) - delta
        return dt.isoformat()

    # Try ISO timestamp passthrough
    try:
        datetime.fromisoformat(s)
        return s
    except (ValueError, TypeError):
        pass

    raise ValueError(f"Cannot parse time: {s!r}. Use format like '1h', '30m', '2d', '1w' or ISO timestamp.")
