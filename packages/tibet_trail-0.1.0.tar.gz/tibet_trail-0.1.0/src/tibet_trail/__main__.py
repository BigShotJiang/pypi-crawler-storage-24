"""Allow running as: python -m tibet_trail"""
from .cli import main

main()
