"""
Output formatters for TIBET tokens.

Supports text (human-readable), JSON, and CSV output formats.
"""

import csv
import io
import json
from typing import Dict, Any, List

from tibet_core.token import Token


# ANSI color codes
_RESET = "\033[0m"
_DIM = "\033[2m"
_BOLD = "\033[1m"
_CYAN = "\033[36m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_RED = "\033[31m"


def _ts_short(ts: str) -> str:
    """Shorten ISO timestamp for display."""
    # "2024-12-17T14:30:00.123456+00:00" -> "2024-12-17 14:30:00"
    return ts.replace("T", " ")[:19]


def format_token_text(token: Token, color: bool = True) -> str:
    """
    Format a single token as human-readable text.

    Format: [timestamp] action (actor) — erachter
    """
    ts = _ts_short(token.timestamp)
    erachter = token.erachter or ""

    if color:
        parts = [
            f"{_DIM}[{ts}]{_RESET}",
            f"{_BOLD}{token.action}{_RESET}",
            f"{_CYAN}({token.actor}){_RESET}",
        ]
        if erachter:
            parts.append(f"— {erachter}")
        return " ".join(parts)

    parts = [f"[{ts}]", token.action, f"({token.actor})"]
    if erachter:
        parts.append(f"— {erachter}")
    return " ".join(parts)


def format_token_json(token: Token) -> str:
    """Format a single token as pretty JSON."""
    return json.dumps(token.to_dict(), indent=2, default=str)


def format_tokens_csv(tokens: List[Token]) -> str:
    """Format tokens as CSV with header."""
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["token_id", "timestamp", "action", "actor", "erachter", "state", "parent_id"])
    for t in tokens:
        state = t.state.value if hasattr(t.state, "value") else str(t.state)
        writer.writerow([t.token_id, t.timestamp, t.action, t.actor, t.erachter, state, t.parent_id or ""])
    return output.getvalue()


def format_table(tokens: List[Token], fmt: str = "text", color: bool = True) -> str:
    """
    Format a list of tokens in the given format.

    Args:
        tokens: List of Token objects
        fmt: Output format — "text", "json", or "csv"
        color: Enable ANSI colors (text format only)

    Returns:
        Formatted string
    """
    if fmt == "json":
        return json.dumps([t.to_dict() for t in tokens], indent=2, default=str)
    elif fmt == "csv":
        return format_tokens_csv(tokens)
    else:
        return "\n".join(format_token_text(t, color=color) for t in tokens)


def format_stats(stats: Dict[str, Any], color: bool = True) -> str:
    """Format statistics as human-readable text."""
    lines = []

    if color:
        lines.append(f"{_BOLD}Audit Trail Statistics{_RESET}")
        lines.append(f"{'─' * 40}")
        lines.append(f"  Total tokens:   {_GREEN}{stats.get('total', 0)}{_RESET}")
        lines.append(f"  Unique actors:  {_CYAN}{stats.get('actor_count', 0)}{_RESET}")
        lines.append(f"  Unique actions: {_YELLOW}{stats.get('action_count', 0)}{_RESET}")
        if stats.get("actors"):
            lines.append(f"  Actors:         {', '.join(stats['actors'])}")
        if stats.get("actions"):
            lines.append(f"  Actions:        {', '.join(stats['actions'])}")
        if stats.get("first_timestamp"):
            lines.append(f"  First token:    {_ts_short(stats['first_timestamp'])}")
        if stats.get("last_timestamp"):
            lines.append(f"  Last token:     {_ts_short(stats['last_timestamp'])}")
    else:
        lines.append("Audit Trail Statistics")
        lines.append("─" * 40)
        lines.append(f"  Total tokens:   {stats.get('total', 0)}")
        lines.append(f"  Unique actors:  {stats.get('actor_count', 0)}")
        lines.append(f"  Unique actions: {stats.get('action_count', 0)}")
        if stats.get("actors"):
            lines.append(f"  Actors:         {', '.join(stats['actors'])}")
        if stats.get("actions"):
            lines.append(f"  Actions:        {', '.join(stats['actions'])}")
        if stats.get("first_timestamp"):
            lines.append(f"  First token:    {_ts_short(stats['first_timestamp'])}")
        if stats.get("last_timestamp"):
            lines.append(f"  Last token:     {_ts_short(stats['last_timestamp'])}")

    return "\n".join(lines)


def format_chain(tokens: List[Token], color: bool = True) -> str:
    """Format a provenance chain with arrows showing lineage."""
    if not tokens:
        return "Empty chain"

    lines = []
    for i, t in enumerate(tokens):
        ts = _ts_short(t.timestamp)
        erachter = t.erachter or ""

        if color:
            prefix = "  → " if i > 0 else "    "
            line = f"{prefix}{_DIM}[{ts}]{_RESET} {_BOLD}{t.action}{_RESET} {_CYAN}({t.actor}){_RESET}"
            if erachter:
                line += f" — {erachter}"
            line += f" {_DIM}[{t.token_id[:12]}…]{_RESET}"
        else:
            prefix = "  → " if i > 0 else "    "
            line = f"{prefix}[{ts}] {t.action} ({t.actor})"
            if erachter:
                line += f" — {erachter}"
            line += f" [{t.token_id[:12]}…]"

        lines.append(line)

    return "\n".join(lines)


def format_verify(result: Dict[str, Any], color: bool = True) -> str:
    """Format verification result."""
    lines = []
    integrity = result.get("integrity", False)

    if color:
        lines.append(f"{_BOLD}Integrity Verification{_RESET}")
        lines.append(f"{'─' * 40}")
        status = f"{_GREEN}PASS{_RESET}" if integrity else f"{_RED}FAIL{_RESET}"
        lines.append(f"  Status:    {status}")
        lines.append(f"  Valid:     {_GREEN}{result.get('valid', 0)}{_RESET}")
        lines.append(f"  Invalid:   {_RED}{result.get('invalid', 0)}{_RESET}")
        if result.get("corrupted_ids"):
            lines.append(f"  Corrupted: {', '.join(result['corrupted_ids'])}")
    else:
        lines.append("Integrity Verification")
        lines.append("─" * 40)
        status = "PASS" if integrity else "FAIL"
        lines.append(f"  Status:    {status}")
        lines.append(f"  Valid:     {result.get('valid', 0)}")
        lines.append(f"  Invalid:   {result.get('invalid', 0)}")
        if result.get("corrupted_ids"):
            lines.append(f"  Corrupted: {', '.join(result['corrupted_ids'])}")

    return "\n".join(lines)
