"""Tests for watcher module."""

import threading
import time

import pytest

from tibet_core.token import Token, create_token_id

from tibet_trail.watcher import TrailWatcher


@pytest.fixture
def watch_file(tmp_path):
    """Create an empty JSONL file for watching."""
    path = tmp_path / "watch.jsonl"
    path.touch()
    return str(path)


def _make_token(action="test", actor="tester"):
    return Token(
        token_id=create_token_id(),
        action=action,
        timestamp="2024-12-17T14:30:00+00:00",
        actor=actor,
        erachter="test",
    )


class TestTrailWatcher:
    def test_detects_new_tokens(self, watch_file):
        """Watcher should detect new tokens appended to file."""
        watcher = TrailWatcher(watch_file, interval=0.1)
        stop = threading.Event()
        received = []

        def on_token(token):
            received.append(token)
            if len(received) >= 2:
                stop.set()

        # Start watcher in background
        thread = threading.Thread(target=watcher.watch, args=(on_token, stop))
        thread.daemon = True
        thread.start()

        # Give watcher time to start
        time.sleep(0.2)

        # Append tokens
        t1 = _make_token(action="first")
        t2 = _make_token(action="second")
        with open(watch_file, "a") as f:
            f.write(t1.to_json() + "\n")
            f.write(t2.to_json() + "\n")

        # Wait for detection
        stop.wait(timeout=3)
        thread.join(timeout=2)

        assert len(received) >= 2
        assert received[0].action == "first"
        assert received[1].action == "second"

    def test_stop_event(self, watch_file):
        """Watcher should stop when stop_event is set."""
        watcher = TrailWatcher(watch_file, interval=0.1)
        stop = threading.Event()

        thread = threading.Thread(target=watcher.watch, args=(lambda t: None, stop))
        thread.daemon = True
        thread.start()

        time.sleep(0.2)
        stop.set()
        thread.join(timeout=2)
        assert not thread.is_alive()

    def test_skips_malformed_lines(self, watch_file):
        """Watcher should skip lines that aren't valid JSON."""
        watcher = TrailWatcher(watch_file, interval=0.1)
        stop = threading.Event()
        received = []

        def on_token(token):
            received.append(token)
            stop.set()

        thread = threading.Thread(target=watcher.watch, args=(on_token, stop))
        thread.daemon = True
        thread.start()

        time.sleep(0.2)

        valid = _make_token(action="valid")
        with open(watch_file, "a") as f:
            f.write("not valid json\n")
            f.write(valid.to_json() + "\n")

        stop.wait(timeout=3)
        thread.join(timeout=2)

        assert len(received) == 1
        assert received[0].action == "valid"

    def test_waits_for_file(self, tmp_path):
        """Watcher should wait if file doesn't exist yet."""
        path = str(tmp_path / "future.jsonl")
        watcher = TrailWatcher(path, interval=0.1)
        stop = threading.Event()
        received = []

        def on_token(token):
            received.append(token)
            stop.set()

        thread = threading.Thread(target=watcher.watch, args=(on_token, stop))
        thread.daemon = True
        thread.start()

        time.sleep(0.3)

        # Create file with a token
        t = _make_token()
        with open(path, "w") as f:
            f.write(t.to_json() + "\n")

        stop.wait(timeout=3)
        thread.join(timeout=2)
        assert len(received) == 1

    def test_ignores_existing_content(self, watch_file):
        """Watcher should only see new content, not existing."""
        # Write initial content
        t_old = _make_token(action="old")
        with open(watch_file, "w") as f:
            f.write(t_old.to_json() + "\n")

        watcher = TrailWatcher(watch_file, interval=0.1)
        stop = threading.Event()
        received = []

        def on_token(token):
            received.append(token)
            stop.set()

        thread = threading.Thread(target=watcher.watch, args=(on_token, stop))
        thread.daemon = True
        thread.start()

        time.sleep(0.2)

        # Append new token
        t_new = _make_token(action="new")
        with open(watch_file, "a") as f:
            f.write(t_new.to_json() + "\n")

        stop.wait(timeout=3)
        thread.join(timeout=2)

        assert len(received) == 1
        assert received[0].action == "new"
