"""Tests for formatter module."""

import json

from tibet_core.token import Token, create_token_id

from tibet_trail.formatter import (
    format_token_text,
    format_token_json,
    format_tokens_csv,
    format_table,
    format_stats,
    format_chain,
    format_verify,
)


def _make_token(action="test.action", actor="test:actor", erachter="test intent", **kwargs):
    """Helper to create a test token."""
    return Token(
        token_id=kwargs.get("token_id", create_token_id()),
        action=action,
        timestamp=kwargs.get("timestamp", "2024-12-17T14:30:00+00:00"),
        actor=actor,
        erachter=erachter,
        parent_id=kwargs.get("parent_id"),
    )


class TestFormatTokenText:
    def test_basic_format(self):
        token = _make_token()
        result = format_token_text(token, color=False)
        assert "[2024-12-17 14:30:00]" in result
        assert "test.action" in result
        assert "(test:actor)" in result
        assert "— test intent" in result

    def test_no_erachter(self):
        token = _make_token(erachter="")
        result = format_token_text(token, color=False)
        assert "—" not in result

    def test_with_color(self):
        token = _make_token()
        result = format_token_text(token, color=True)
        assert "\033[" in result  # Contains ANSI codes


class TestFormatTokenJson:
    def test_valid_json(self):
        token = _make_token()
        result = format_token_json(token)
        data = json.loads(result)
        assert data["action"] == "test.action"
        assert data["actor"] == "test:actor"


class TestFormatTokensCsv:
    def test_csv_header(self):
        tokens = [_make_token(), _make_token(action="other")]
        result = format_tokens_csv(tokens)
        lines = result.strip().splitlines()
        assert lines[0].strip() == "token_id,timestamp,action,actor,erachter,state,parent_id"
        assert len(lines) == 3

    def test_csv_values(self):
        token = _make_token()
        result = format_tokens_csv([token])
        assert "test.action" in result
        assert "test:actor" in result


class TestFormatTable:
    def test_text_format(self):
        tokens = [_make_token(), _make_token(action="second")]
        result = format_table(tokens, fmt="text", color=False)
        assert "test.action" in result
        assert "second" in result

    def test_json_format(self):
        tokens = [_make_token()]
        result = format_table(tokens, fmt="json", color=False)
        data = json.loads(result)
        assert isinstance(data, list)
        assert data[0]["action"] == "test.action"

    def test_csv_format(self):
        tokens = [_make_token()]
        result = format_table(tokens, fmt="csv", color=False)
        assert "token_id,timestamp" in result


class TestFormatStats:
    def test_stats_display(self):
        stats = {
            "total": 42,
            "actor_count": 3,
            "action_count": 5,
            "actors": ["alice", "bob"],
            "actions": ["login", "logout"],
            "first_timestamp": "2024-12-01T00:00:00",
            "last_timestamp": "2024-12-17T14:30:00",
        }
        result = format_stats(stats, color=False)
        assert "42" in result
        assert "alice" in result
        assert "Audit Trail Statistics" in result


class TestFormatChain:
    def test_chain_display(self):
        t1 = _make_token(token_id="tibet_001_abc", action="init")
        t2 = _make_token(token_id="tibet_002_def", action="process", parent_id="tibet_001_abc")
        result = format_chain([t2, t1], color=False)
        assert "init" in result
        assert "process" in result
        assert "→" in result

    def test_empty_chain(self):
        result = format_chain([], color=False)
        assert "Empty chain" in result


class TestFormatVerify:
    def test_pass(self):
        result = format_verify({"valid": 10, "invalid": 0, "integrity": True, "corrupted_ids": []}, color=False)
        assert "PASS" in result
        assert "10" in result

    def test_fail(self):
        result = format_verify({"valid": 8, "invalid": 2, "integrity": False, "corrupted_ids": ["a", "b"]}, color=False)
        assert "FAIL" in result
        assert "a, b" in result
