"""Tests for CLI module."""

import json
import os

import pytest

from tibet_core.token import Token
from tibet_core.store import FileStore

from tibet_trail.cli import main, build_parser


@pytest.fixture
def trail_file(tmp_path):
    """Create a test JSONL file."""
    path = str(tmp_path / "cli_test.jsonl")
    store = FileStore(path)
    for i in range(5):
        token = Token(
            token_id=f"tibet_cli_{i:04d}",
            action=f"action_{i}",
            timestamp=f"2024-12-17T14:{i:02d}:00+00:00",
            actor="test:cli",
            erachter=f"cli test {i}",
            parent_id=f"tibet_cli_{i-1:04d}" if i > 0 else None,
        )
        store.add(token)
    return path


class TestBuildParser:
    def test_parser_created(self):
        parser = build_parser()
        assert parser.prog == "tibet-trail"

    def test_version(self, capsys):
        with pytest.raises(SystemExit) as exc:
            main(["--version"])
        assert exc.value.code == 0
        captured = capsys.readouterr()
        assert "0.1.0" in captured.out


class TestLogCommand:
    def test_log_text(self, trail_file, capsys):
        main(["log", trail_file])
        captured = capsys.readouterr()
        assert "action_0" in captured.out

    def test_log_json(self, trail_file, capsys):
        main(["log", trail_file, "--format", "json"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert isinstance(data, list)
        assert len(data) == 5

    def test_log_csv(self, trail_file, capsys):
        main(["log", trail_file, "--format", "csv"])
        captured = capsys.readouterr()
        assert "token_id,timestamp" in captured.out

    def test_log_n(self, trail_file, capsys):
        main(["log", trail_file, "-n", "2", "--format", "json"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert len(data) == 2


class TestSearchCommand:
    def test_search_actor(self, trail_file, capsys):
        main(["search", trail_file, "--actor", "test:cli", "--format", "json"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert len(data) == 5

    def test_search_no_results(self, trail_file, capsys):
        main(["search", trail_file, "--actor", "nonexistent"])
        captured = capsys.readouterr()
        assert "No matching" in captured.out


class TestTraceCommand:
    def test_trace(self, trail_file, capsys):
        main(["trace", trail_file, "tibet_cli_0003"])
        captured = capsys.readouterr()
        assert "Chain length: 4" in captured.out
        assert "action_3" in captured.out
        assert "action_0" in captured.out

    def test_trace_json(self, trail_file, capsys):
        main(["trace", trail_file, "tibet_cli_0002", "--format", "json"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert len(data) == 3

    def test_trace_not_found(self, trail_file, capsys):
        main(["trace", trail_file, "nonexistent"])
        captured = capsys.readouterr()
        assert "not found" in captured.out


class TestVerifyCommand:
    def test_verify_pass(self, trail_file, capsys):
        main(["verify", trail_file])
        captured = capsys.readouterr()
        assert "PASS" in captured.out


class TestStatsCommand:
    def test_stats_text(self, trail_file, capsys):
        main(["stats", trail_file])
        captured = capsys.readouterr()
        assert "5" in captured.out
        assert "test:cli" in captured.out

    def test_stats_json(self, trail_file, capsys):
        main(["stats", trail_file, "--format", "json"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["total"] == 5


class TestExportCommand:
    def test_export_csv(self, trail_file, tmp_path, capsys):
        outpath = str(tmp_path / "export.csv")
        main(["export", trail_file, outpath, "--format", "csv"])
        captured = capsys.readouterr()
        assert "Exported 5 tokens" in captured.out
        assert os.path.exists(outpath)
        with open(outpath) as f:
            content = f.read()
        assert "token_id,timestamp" in content

    def test_export_json(self, trail_file, tmp_path, capsys):
        outpath = str(tmp_path / "export.json")
        main(["export", trail_file, outpath, "--format", "json"])
        assert os.path.exists(outpath)
        with open(outpath) as f:
            data = json.loads(f.read())
        assert len(data) == 5
