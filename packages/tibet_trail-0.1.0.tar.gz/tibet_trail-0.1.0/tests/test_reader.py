"""Tests for reader module."""

import os
import tempfile

import pytest

from tibet_core.token import Token, create_token_id, TokenState
from tibet_core.store import FileStore

from tibet_trail.reader import TrailReader


@pytest.fixture
def trail_file(tmp_path):
    """Create a temporary JSONL file with test tokens."""
    path = str(tmp_path / "test_audit.jsonl")
    store = FileStore(path)
    for i in range(10):
        token = Token(
            token_id=f"tibet_test_{i:04d}",
            action=f"action_{i % 3}",
            timestamp=f"2024-12-17T14:{i:02d}:00+00:00",
            actor=f"actor_{i % 2}",
            erachter=f"intent {i}",
            parent_id=f"tibet_test_{i-1:04d}" if i > 0 else None,
        )
        store.add(token)
    return path


class TestTrailReaderLog:
    def test_log_default(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.log()
        assert len(tokens) == 10  # less than default 20

    def test_log_limited(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.log(n=3)
        assert len(tokens) == 3
        # Should be the last 3
        assert tokens[0].token_id == "tibet_test_0007"

    def test_log_more_than_available(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.log(n=100)
        assert len(tokens) == 10

    def test_log_empty_file(self, tmp_path):
        path = str(tmp_path / "empty.jsonl")
        open(path, "w").close()
        reader = TrailReader(path)
        assert reader.log() == []


class TestTrailReaderSearch:
    def test_search_by_actor(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.search(actor="actor_0")
        assert all(t.actor == "actor_0" for t in tokens)
        assert len(tokens) == 5

    def test_search_by_action(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.search(action="action_0")
        assert all(t.action == "action_0" for t in tokens)

    def test_search_by_action_regex(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.search(action="action_[01]")
        actions = {t.action for t in tokens}
        assert actions <= {"action_0", "action_1"}

    def test_search_by_since(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.search(since="2024-12-17T14:05:00+00:00")
        assert all(t.timestamp >= "2024-12-17T14:05:00+00:00" for t in tokens)

    def test_search_combined(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.search(actor="actor_0", action="action_0")
        assert all(t.actor == "actor_0" and t.action == "action_0" for t in tokens)

    def test_search_no_results(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.search(actor="nonexistent")
        assert tokens == []


class TestTrailReaderTrace:
    def test_trace_chain(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.trace("tibet_test_0005")
        assert len(tokens) == 6  # 0005 -> 0004 -> ... -> 0000
        assert tokens[0].token_id == "tibet_test_0005"
        assert tokens[-1].token_id == "tibet_test_0000"

    def test_trace_root(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.trace("tibet_test_0000")
        assert len(tokens) == 1

    def test_trace_nonexistent(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.trace("nonexistent")
        assert tokens == []

    def test_trace_max_depth(self, trail_file):
        reader = TrailReader(trail_file)
        tokens = reader.trace("tibet_test_0009", max_depth=3)
        assert len(tokens) == 3


class TestTrailReaderVerify:
    def test_verify_valid(self, trail_file):
        reader = TrailReader(trail_file)
        result = reader.verify()
        assert result["integrity"] is True
        assert result["valid"] == 10
        assert result["invalid"] == 0

    def test_verify_empty(self, tmp_path):
        path = str(tmp_path / "empty.jsonl")
        open(path, "w").close()
        reader = TrailReader(path)
        result = reader.verify()
        assert result["integrity"] is True


class TestTrailReaderStats:
    def test_stats(self, trail_file):
        reader = TrailReader(trail_file)
        stats = reader.stats()
        assert stats["total"] == 10
        assert stats["actor_count"] == 2
        assert stats["action_count"] == 3
        assert "actor_0" in stats["actors"]
        assert "actor_1" in stats["actors"]
        assert stats["first_timestamp"] == "2024-12-17T14:00:00+00:00"
        assert stats["last_timestamp"] == "2024-12-17T14:09:00+00:00"

    def test_stats_empty(self, tmp_path):
        path = str(tmp_path / "empty.jsonl")
        open(path, "w").close()
        reader = TrailReader(path)
        stats = reader.stats()
        assert stats["total"] == 0
