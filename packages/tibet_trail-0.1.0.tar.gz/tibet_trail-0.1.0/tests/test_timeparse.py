"""Tests for timeparse module."""

import pytest
from datetime import datetime, timedelta, timezone

from tibet_trail.timeparse import parse_relative_time


class TestParseRelativeTime:
    """Test human-friendly time parsing."""

    def test_seconds(self):
        result = parse_relative_time("30s")
        dt = datetime.fromisoformat(result)
        expected = datetime.now(timezone.utc) - timedelta(seconds=30)
        assert abs((dt - expected).total_seconds()) < 2

    def test_minutes(self):
        result = parse_relative_time("5m")
        dt = datetime.fromisoformat(result)
        expected = datetime.now(timezone.utc) - timedelta(minutes=5)
        assert abs((dt - expected).total_seconds()) < 2

    def test_hours(self):
        result = parse_relative_time("1h")
        dt = datetime.fromisoformat(result)
        expected = datetime.now(timezone.utc) - timedelta(hours=1)
        assert abs((dt - expected).total_seconds()) < 2

    def test_days(self):
        result = parse_relative_time("2d")
        dt = datetime.fromisoformat(result)
        expected = datetime.now(timezone.utc) - timedelta(days=2)
        assert abs((dt - expected).total_seconds()) < 2

    def test_weeks(self):
        result = parse_relative_time("1w")
        dt = datetime.fromisoformat(result)
        expected = datetime.now(timezone.utc) - timedelta(weeks=1)
        assert abs((dt - expected).total_seconds()) < 2

    def test_iso_passthrough(self):
        iso = "2024-12-17T14:30:00+00:00"
        assert parse_relative_time(iso) == iso

    def test_iso_naive_passthrough(self):
        iso = "2024-12-17T14:30:00"
        assert parse_relative_time(iso) == iso

    def test_invalid_raises(self):
        with pytest.raises(ValueError):
            parse_relative_time("invalid")

    def test_whitespace_stripped(self):
        result = parse_relative_time("  1h  ")
        dt = datetime.fromisoformat(result)
        expected = datetime.now(timezone.utc) - timedelta(hours=1)
        assert abs((dt - expected).total_seconds()) < 2

    def test_zero_value(self):
        result = parse_relative_time("0h")
        dt = datetime.fromisoformat(result)
        expected = datetime.now(timezone.utc)
        assert abs((dt - expected).total_seconds()) < 2
