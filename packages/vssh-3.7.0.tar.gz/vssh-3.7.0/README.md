# vssh

**Distributed SSH transport and file transfer daemon with zero external dependencies.**

Part of [MeshPOP](https://mpop.dev) — Layer 2 (Transport)

- Zero external dependencies — pure Python stdlib
- 50+ MB/s file transfer across WireGuard mesh
- MCP server for AI agent integration

## Install

```bash
pip install vssh
```

## Usage

```bash
# Execute remote command
vssh exec relay1 "uptime"

# Transfer file at 50+ MB/s
vssh put relay1 ./deploy.tar.gz /opt/deploy.tar.gz

# Check connection status
vssh status
```

## MCP Setup

```json
{
  "mcpServers": {
    "vssh": { "command": "vssh-mcp" }
  }
}
```

Gives AI agents: `vssh_exec`, `vssh_put`, `vssh_get`, `vssh_status`, `vssh_keys`, `vssh_speed_test`

## Links

- Main project: [github.com/meshpop/mpop](https://github.com/meshpop/mpop)
- Website: [mpop.dev](https://mpop.dev)
- PyPI: [pypi.org/project/vssh](https://pypi.org/project/vssh/)

## License

MIT
