# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowTagQuotaRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'cluster_id': 'str',
        'auto_scaling_policy_tags': 'bool'
    }

    attribute_map = {
        'cluster_id': 'cluster_id',
        'auto_scaling_policy_tags': 'auto_scaling_policy_tags'
    }

    def __init__(self, cluster_id=None, auto_scaling_policy_tags=None):
        r"""ShowTagQuotaRequest

        The model defined in huaweicloud sdk

        :param cluster_id: 集群ID。
        :type cluster_id: str
        :param auto_scaling_policy_tags: 是否查询弹性伸缩策略标签
        :type auto_scaling_policy_tags: bool
        """
        
        

        self._cluster_id = None
        self._auto_scaling_policy_tags = None
        self.discriminator = None

        self.cluster_id = cluster_id
        if auto_scaling_policy_tags is not None:
            self.auto_scaling_policy_tags = auto_scaling_policy_tags

    @property
    def cluster_id(self):
        r"""Gets the cluster_id of this ShowTagQuotaRequest.

        集群ID。

        :return: The cluster_id of this ShowTagQuotaRequest.
        :rtype: str
        """
        return self._cluster_id

    @cluster_id.setter
    def cluster_id(self, cluster_id):
        r"""Sets the cluster_id of this ShowTagQuotaRequest.

        集群ID。

        :param cluster_id: The cluster_id of this ShowTagQuotaRequest.
        :type cluster_id: str
        """
        self._cluster_id = cluster_id

    @property
    def auto_scaling_policy_tags(self):
        r"""Gets the auto_scaling_policy_tags of this ShowTagQuotaRequest.

        是否查询弹性伸缩策略标签

        :return: The auto_scaling_policy_tags of this ShowTagQuotaRequest.
        :rtype: bool
        """
        return self._auto_scaling_policy_tags

    @auto_scaling_policy_tags.setter
    def auto_scaling_policy_tags(self, auto_scaling_policy_tags):
        r"""Sets the auto_scaling_policy_tags of this ShowTagQuotaRequest.

        是否查询弹性伸缩策略标签

        :param auto_scaling_policy_tags: The auto_scaling_policy_tags of this ShowTagQuotaRequest.
        :type auto_scaling_policy_tags: bool
        """
        self._auto_scaling_policy_tags = auto_scaling_policy_tags

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowTagQuotaRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
