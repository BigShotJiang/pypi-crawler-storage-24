# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class JobSubmitResult:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'job_id': 'str',
        'state': 'str'
    }

    attribute_map = {
        'job_id': 'job_id',
        'state': 'state'
    }

    def __init__(self, job_id=None, state=None):
        r"""JobSubmitResult

        The model defined in huaweicloud sdk

        :param job_id: 作业ID。
        :type job_id: str
        :param state: 作业提交状态。 枚举值： - COMPLETE：作业提交完成。 - FAILED：作业提交失败。
        :type state: str
        """
        
        

        self._job_id = None
        self._state = None
        self.discriminator = None

        if job_id is not None:
            self.job_id = job_id
        if state is not None:
            self.state = state

    @property
    def job_id(self):
        r"""Gets the job_id of this JobSubmitResult.

        作业ID。

        :return: The job_id of this JobSubmitResult.
        :rtype: str
        """
        return self._job_id

    @job_id.setter
    def job_id(self, job_id):
        r"""Sets the job_id of this JobSubmitResult.

        作业ID。

        :param job_id: The job_id of this JobSubmitResult.
        :type job_id: str
        """
        self._job_id = job_id

    @property
    def state(self):
        r"""Gets the state of this JobSubmitResult.

        作业提交状态。 枚举值： - COMPLETE：作业提交完成。 - FAILED：作业提交失败。

        :return: The state of this JobSubmitResult.
        :rtype: str
        """
        return self._state

    @state.setter
    def state(self, state):
        r"""Sets the state of this JobSubmitResult.

        作业提交状态。 枚举值： - COMPLETE：作业提交完成。 - FAILED：作业提交失败。

        :param state: The state of this JobSubmitResult.
        :type state: str
        """
        self._state = state

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, JobSubmitResult):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
