"""
Thin httpx wrapper for the Agent Deploy REST API.
Token and base URL are read from environment variables.
"""

import os
import sys

import httpx

BASE_URL = os.environ.get("AGENT_DEPLOY_URL", "https://agent-deploy.org/api").rstrip("/")
_TOKEN = os.environ.get("AGENT_DEPLOY_TOKEN", "")

TIMEOUT = 120.0


def _headers() -> dict:
    return {"Authorization": f"Bearer {_TOKEN}"}


def _log(method: str, path: str, res: httpx.Response) -> None:
    print(f"[agent-deploy-mcp] {method} {path} → {res.status_code}", file=sys.stderr, flush=True)


def get(path: str, **kwargs) -> httpx.Response:
    res = httpx.get(f"{BASE_URL}{path}", headers=_headers(), timeout=TIMEOUT, **kwargs)
    _log("GET", path, res)
    return res


def post(path: str, **kwargs) -> httpx.Response:
    res = httpx.post(f"{BASE_URL}{path}", headers=_headers(), timeout=TIMEOUT, **kwargs)
    _log("POST", path, res)
    return res


def patch(path: str, **kwargs) -> httpx.Response:
    res = httpx.patch(f"{BASE_URL}{path}", headers=_headers(), timeout=TIMEOUT, **kwargs)
    _log("PATCH", path, res)
    return res


def delete(path: str, **kwargs) -> httpx.Response:
    res = httpx.delete(f"{BASE_URL}{path}", headers=_headers(), timeout=TIMEOUT, **kwargs)
    _log("DELETE", path, res)
    return res
