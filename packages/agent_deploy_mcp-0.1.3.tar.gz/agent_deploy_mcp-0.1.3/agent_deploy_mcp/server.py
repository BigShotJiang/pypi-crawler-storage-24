"""
Agent Deploy MCP Server

Exposes the Agent Deploy platform as MCP tools so any compatible AI client
(Claude Code, Claude Desktop, Cursor, etc.) can deploy and manage apps via
natural language.

Environment variables:
  AGENT_DEPLOY_URL    Base URL of the Agent Deploy API (default: https://agent-deploy.org)
  AGENT_DEPLOY_TOKEN  Bearer token — copy from Settings → Auth token
"""

import json
import os

from mcp.server.fastmcp import FastMCP

from agent_deploy_mcp import client

mcp = FastMCP("Agent Deploy")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ok(data) -> str:
    return json.dumps(data, indent=2, default=str)


def _err(res) -> str:
    try:
        detail = res.json().get("detail", res.text)
    except Exception:
        detail = res.text
    return f"Error {res.status_code}: {detail}"


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def list_apps() -> str:
    """List all apps belonging to the authenticated user, including live container statuses."""
    res = client.get("/apps")
    if not res.is_success:
        return _err(res)
    return _ok(res.json())


@mcp.tool()
def get_app(external_id: str) -> str:
    """Get full details for a single app including its Docker images.

    Args:
        external_id: The app's external_id from list_apps.
    """
    res = client.get(f"/apps/{external_id}")
    if not res.is_success:
        return _err(res)
    return _ok(res.json())


@mcp.tool()
def create_app(name: str, slug: str, app_type: str) -> str:
    """Create a new app record. Does not deploy anything — use deploy_app afterwards.

    Args:
        name:     Human-readable display name, e.g. "My Portfolio".
        slug:     URL-safe identifier, e.g. "my-portfolio". Must be unique per user.
        app_type: One of: web, api, fullstack, static.
    """
    res = client.post("/apps", json={"name": name, "slug": slug, "type": app_type})
    if not res.is_success:
        return _err(res)
    return _ok(res.json())


@mcp.tool()
def deploy_app(external_id: str, project_path: str) -> str:
    """Deploy a project directory to an existing app.

    BEFORE calling this tool you MUST ensure:

    1. A Dockerfile or docker-compose.yml exists in the project root.
       The Dockerfile must handle ALL build steps internally — do not pre-build
       on the host. Use multi-stage builds where compilation is needed, e.g.:

       TypeScript / React / Vite / Next.js:
         FROM node:20-alpine AS build
         WORKDIR /app
         COPY package*.json ./
         RUN npm ci
         COPY . .
         RUN npm run build
         FROM nginx:alpine
         COPY --from=build /app/dist /usr/share/nginx/html
         EXPOSE 80

       Python / FastAPI / Flask:
         FROM python:3.12-slim
         WORKDIR /app
         COPY requirements.txt .
         RUN pip install --no-cache-dir -r requirements.txt
         COPY . .
         CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]

       Full-stack (frontend + backend + db): use docker-compose.yml with a
       separate service per tier. Every service that serves custom content
       MUST use a 'build:' key pointing to a Dockerfile — never a bare
       'image:' key alone. A bare 'image: nginx:alpine' with no 'build:'
       will deploy an empty nginx container (default welcome page). Example:

         services:
           frontend:
             build:
               context: ./frontend
               dockerfile: Dockerfile
           backend:
             build: ./backend
           db:
             image: postgres:16
             environment:
               POSTGRES_PASSWORD: secret

    2. The Dockerfile output port matches the service — nginx uses 80, FastAPI
       defaults to 8000. Expose the correct port with EXPOSE.

    This tool returns a shell script — run it with the Bash tool. Do NOT zip
    or upload the file yourself.

    Args:
        external_id:  The app's external_id from list_apps or create_app.
        project_path: Absolute path to the project directory on the host.
    """
    token = os.environ.get("AGENT_DEPLOY_TOKEN", "")
    base_url = os.environ.get("AGENT_DEPLOY_URL", "https://agent-deploy.org/api").rstrip("/")
    auth = f'-H "Authorization: Bearer {token}"' if token else ""
    zip_path = f"/tmp/agent-deploy-{external_id}.zip"

    script = f"""
# 1. Validate Docker configuration is present
if [ ! -f "{project_path}/Dockerfile" ] && [ ! -f "{project_path}/docker-compose.yml" ] && [ ! -f "{project_path}/docker-compose.yaml" ]; then
  echo "ERROR: No Dockerfile or docker-compose.yml found in {project_path}."
  echo "The Dockerfile must include all build steps (e.g. npm run build for JS/TS apps)."
  exit 1
fi

# 2. Warn if a JS/TS project has no build step in Dockerfile
if [ -f "{project_path}/package.json" ] && [ -f "{project_path}/Dockerfile" ]; then
  if ! grep -q "npm run build\\|yarn build\\|pnpm build" "{project_path}/Dockerfile"; then
    echo "WARNING: package.json detected but no build step found in Dockerfile."
    echo "For TypeScript/JSX apps, add 'RUN npm run build' to your Dockerfile."
  fi
fi

# 3. Warn if a compose service uses a bare image without a build context
for compose_file in "{project_path}/docker-compose.yml" "{project_path}/docker-compose.yaml"; do
  if [ -f "$compose_file" ]; then
    if grep -q "image:\\s*nginx" "$compose_file" && ! grep -B5 "image:\\s*nginx" "$compose_file" | grep -q "build:"; then
      echo "WARNING: docker-compose.yml has a service using 'image: nginx' without a 'build:' section."
      echo "This will deploy an empty nginx container (default welcome page)."
      echo "Add a 'build:' key pointing to a Dockerfile with a multi-stage build."
    fi
  fi
done

# 4. Zip the project (excluding build artefacts and hidden files)
cd "{project_path}" && zip -r "{zip_path}" . \\
  --exclude "*.git*" \\
  --exclude "node_modules/*" \\
  --exclude "__pycache__/*" \\
  --exclude "*.pyc" \\
  --exclude ".env" \\
  --exclude "*.DS_Store"

# 5. Upload and deploy
curl -s -X POST "{base_url}/apps/upload" \\
  {auth} \\
  -F "external_id={external_id}" \\
  -F "file=@{zip_path}"

# 6. Clean up
rm -f "{zip_path}"
""".strip()

    return (
        f"Run the following script using the Bash tool:\n\n{script}\n\n"
        "Then call get_app_status to monitor the deployment."
    )


@mcp.tool()
def get_app_status(external_id: str) -> str:
    """Get live container statuses for every service in an app.

    Returns a mapping of image_type → {status, started_at}.
    Status values: running, exited, restarting, paused, dead, not_started.

    Args:
        external_id: The app's external_id from list_apps.
    """
    res = client.get(f"/apps/{external_id}/status")
    if not res.is_success:
        return _err(res)
    return _ok(res.json())


@mcp.tool()
def get_logs(external_id: str, image_type: str, limit: int = 30) -> str:
    """Fetch the most recent log lines for a container.

    Args:
        external_id: The app's external_id from list_apps.
        image_type: Service name, e.g. frontend, backend, db, worker.
        limit:      Number of log lines to return (default 30, max 200).
    """
    res = client.get(
        f"/apps/{external_id}/images/{image_type}/logs",
        params={"limit": limit},
    )
    if not res.is_success:
        return _err(res)
    entries = res.json()
    if not entries:
        return "No logs found for this container."
    lines = [f"[{e['timestamp']}] {e['log_str']}" for e in entries]
    return "\n".join(lines)


@mcp.tool()
def analyze_logs(external_id: str, image_type: str) -> str:
    """Get a plain-English AI summary of the last 20 log lines for a container.

    Args:
        external_id: The app's external_id from list_apps.
        image_type: Service name, e.g. frontend, backend, db, worker.
    """
    res = client.get(f"/apps/{external_id}/images/{image_type}/logs/analyze")
    if not res.is_success:
        return _err(res)
    analysis = res.json().get("analysis")
    if not analysis:
        return "Analysis unavailable."
    return analysis


@mcp.tool()
def restart_app(external_id: str) -> str:
    """Restart all containers for an app.

    Args:
        external_id: The app's external_id from list_apps.
    """
    res = client.post(f"/apps/{external_id}/restart")
    if not res.is_success:
        return _err(res)
    return _ok(res.json())


@mcp.tool()
def set_app_visibility(external_id: str, public: bool) -> str:
    """Make an app public or private.

    Args:
        external_id: The app's external_id from list_apps.
        public: True to make public, False to make private.
    """
    res = client.patch(f"/apps/{external_id}", json={"is_public": public})
    if not res.is_success:
        return _err(res)
    return f"App {external_id} is now {'public' if public else 'private'}."


@mcp.tool()
def update_app(external_id: str, name: str | None = None, slug: str | None = None, app_type: str | None = None) -> str:
    """Update an app's name, slug, or type. Only provided fields are changed.

    Args:
        external_id: The app's external_id from list_apps.
        name:     New display name (optional).
        slug:     New URL slug (optional). Must be unique per user.
        app_type: New type: web, api, fullstack, static (optional).
    """
    payload = {k: v for k, v in {"name": name, "slug": slug, "type": app_type}.items() if v is not None}
    if not payload:
        return "No fields provided — nothing to update."
    res = client.patch(f"/apps/{external_id}", json=payload)
    if not res.is_success:
        return _err(res)
    return _ok(res.json())


@mcp.tool()
def delete_app(external_id: str) -> str:
    """Soft-delete an app. Containers are stopped and the app is removed from the dashboard.

    Args:
        external_id: The app's external_id from list_apps.
    """
    res = client.delete(f"/apps/{external_id}")
    if not res.is_success:
        return _err(res)
    return f"App {external_id} deleted successfully."


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
