# Copyright 2019-2026 SURF.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from pydantic import Field
from pydantic_settings import BaseSettings


class Oauth2LibSettings(BaseSettings):
    """Common settings for applications depending on oauth2-lib."""

    ENVIRONMENT: str = "local"
    SERVICE_NAME: str = ""
    MUTATIONS_ENABLED: bool = False
    ENVIRONMENT_IGNORE_MUTATION_DISABLED: list[str] = Field(
        default_factory=list, description="Environments for which to allow unauthenticated mutations"
    )
    OAUTH2_ACTIVE: bool = True
    OAUTH2_AUTHORIZATION_ACTIVE: bool = True
    OAUTH2_RESOURCE_SERVER_ID: str = ""
    OAUTH2_RESOURCE_SERVER_SECRET: str = ""
    OAUTH2_TOKEN_URL: str = ""
    OIDC_BASE_URL: str = ""
    OIDC_CONF_URL: str = ""
    OPA_URL: str = ""


oauth2lib_settings = Oauth2LibSettings()
