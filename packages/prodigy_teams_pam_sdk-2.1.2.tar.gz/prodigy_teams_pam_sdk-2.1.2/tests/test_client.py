from datetime import datetime, timezone
from uuid import UUID

import pytest
from uuid_utils import uuid7

from prodigy_teams_pam_sdk import AccessTokenCredential, Client
from prodigy_teams_pam_sdk.ty import Page


@pytest.fixture
def client() -> Client:
    cred = AccessTokenCredential(access_token="")
    client = Client("https://app.explosion.rocks", cred)
    return client


def test_client_init(client: Client):
    assert client.base_url == "https://app.explosion.rocks"


def test_all_iterates_across_pages(client: Client, monkeypatch: pytest.MonkeyPatch):
    project_a = client.project.Summary(
        id=UUID(str(uuid7())),
        created=datetime.now(timezone.utc),
        updated=datetime.now(timezone.utc),
        org_id=UUID(str(uuid7())),
        name="a",
        description="",
    )
    project_b = client.project.Summary(
        id=UUID(str(uuid7())),
        created=datetime.now(timezone.utc),
        updated=datetime.now(timezone.utc),
        org_id=UUID(str(uuid7())),
        name="b",
        description="",
    )
    pages = [
        Page[type(project_a)](
            items=[project_a],
            next_cursor=str(project_a.id),
            has_more=True,
        ),
        Page[type(project_b)](
            items=[project_b],
            next_cursor=None,
            has_more=False,
        ),
    ]
    seen_requests: list[tuple[str | None, int | None]] = []

    def fake_read_all_page(
        *_args,
        after: str | None = None,
        size: int | None = None,
        **_kwargs,
    ):
        seen_requests.append((after, size))
        return pages.pop(0)

    monkeypatch.setattr(client.project, "_read_all_page", fake_read_all_page)

    items = list(client.project.all(page_size=1))

    assert [item.name for item in items] == ["a", "b"]
    assert seen_requests == [(None, 1), (str(project_a.id), 1)]


def test_all_pages_exposes_page_objects(
    client: Client, monkeypatch: pytest.MonkeyPatch
):
    project = client.project.Summary(
        id=UUID(str(uuid7())),
        created=datetime.now(timezone.utc),
        updated=datetime.now(timezone.utc),
        org_id=UUID(str(uuid7())),
        name="only-page",
        description="",
    )
    page = Page[type(project)](items=[project], next_cursor=None, has_more=False)

    monkeypatch.setattr(
        client.project, "_read_all_page", lambda *_args, **_kwargs: page
    )

    pages = list(client.project.all().pages())

    assert len(pages) == 1
    assert pages[0].items[0].name == "only-page"


def test_all_latest_iterates_across_pages(
    client: Client, monkeypatch: pytest.MonkeyPatch
):
    package_a = client.package.Summary(
        id=UUID(str(uuid7())),
        created=datetime.now(timezone.utc),
        updated=datetime.now(timezone.utc),
        name="a",
        version="1.0.0",
        environment="cpu",
        recipe_count=0,
    )
    package_b = client.package.Summary(
        id=UUID(str(uuid7())),
        created=datetime.now(timezone.utc),
        updated=datetime.now(timezone.utc),
        name="b",
        version="1.0.0",
        environment="cpu",
        recipe_count=0,
    )
    pages = [
        Page[type(package_a)](
            items=[package_a],
            next_cursor=str(package_a.id),
            has_more=True,
        ),
        Page[type(package_b)](
            items=[package_b],
            next_cursor=None,
            has_more=False,
        ),
    ]
    seen_requests: list[tuple[str | None, int | None]] = []

    def fake_read_all_latest_page(
        *_args,
        after: str | None = None,
        size: int | None = None,
        **_kwargs,
    ):
        seen_requests.append((after, size))
        return pages.pop(0)

    monkeypatch.setattr(
        client.package, "_read_all_latest_page", fake_read_all_latest_page
    )

    items = list(
        client.package.all_latest(body=client.package.ListingLatest(), page_size=1)
    )

    assert [item.name for item in items] == ["a", "b"]
    assert seen_requests == [(None, 1), (str(package_a.id), 1)]


def test_all_rejects_conflicting_page_sizes(client: Client):
    with pytest.raises(ValueError, match="page_size or size"):
        client.project.all(page_size=1, size=2)
