# Tuya quirks library

[![PyPI](https://img.shields.io/pypi/v/tuya-device-handlers.svg)][pypi_]
[![Python Version](https://img.shields.io/pypi/pyversions/tuya-device-handlers)][python version]
[![License](https://img.shields.io/pypi/l/tuya-device-handlers)][license]

[![Read the documentation at https://tuya-device-handlers.readthedocs.io/](https://img.shields.io/readthedocs/tuya-device-handlers/latest.svg?label=Read%20the%20Docs)][read the docs]
[![Tests](https://github.com/home-assistant-libs/tuya-device-handlers/workflows/Tests/badge.svg)][tests]
[![Codecov](https://codecov.io/gh/home-assistant-libs/tuya-device-handlers/branch/main/graph/badge.svg)][codecov]

[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)][pre-commit]
[![ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)][ruff]

[pypi_]: https://pypi.org/project/tuya-device-handlers/
[python version]: https://pypi.org/project/tuya-device-handlers
[read the docs]: https://tuya-device-handlers.readthedocs.io/
[tests]: https://github.com/home-assistant-libs/tuya-device-handlers/actions?workflow=Tests
[codecov]: https://app.codecov.io/gh/home-assistant-libs/tuya-device-handlers
[pre-commit]: https://github.com/pre-commit/pre-commit
[ruff]: https://github.com/astral-sh/ruff

## Features

- TODO

## Requirements

- TODO

## Installation

You can install _Tuya quirks library_ via [pip] from [PyPI]:

```console
$ pip install tuya-device-handlers
```

## Usage

Please see the [Command-line Reference] for details.

## Contributing

Contributions are very welcome.
To learn more, see the [Contributor Guide].

## License

Distributed under the terms of the [MIT license][license],
_Tuya quirks library_ is free and open source software.

## Issues

If you encounter any problems,
please [file an issue] along with a detailed description.

## Credits

This project was generated from [@cjolowicz]'s [Hypermodern Python Cookiecutter] template.

[@cjolowicz]: https://github.com/cjolowicz
[pypi]: https://pypi.org/
[hypermodern python cookiecutter]: https://github.com/cjolowicz/cookiecutter-hypermodern-python
[file an issue]: https://github.com/home-assistant-libs/tuya-device-handlers/issues
[pip]: https://pip.pypa.io/

<!-- github-only -->

[license]: https://github.com/home-assistant-libs/tuya-device-handlers/blob/main/LICENSE
[contributor guide]: https://github.com/home-assistant-libs/tuya-device-handlers/blob/main/CONTRIBUTING.md
[command-line reference]: https://tuya-device-handlers.readthedocs.io/en/latest/usage.html
