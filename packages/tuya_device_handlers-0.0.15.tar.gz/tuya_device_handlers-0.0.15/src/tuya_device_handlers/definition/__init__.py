"""Tuya entity definition."""
