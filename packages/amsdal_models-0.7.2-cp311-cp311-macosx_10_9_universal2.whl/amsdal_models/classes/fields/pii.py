from __future__ import annotations

import types
import typing
from typing import TYPE_CHECKING
from typing import Annotated
from typing import Any
from typing import Protocol

from pydantic import Field
from pydantic.fields import FieldInfo

if TYPE_CHECKING:
    from amsdal_models.classes.model import TypeModel

PIIStr = Annotated[str, Field(json_schema_extra={'pii': True})]


class CryptoService(Protocol):
    def encrypt(self, values: list[str]) -> list[str]: ...
    def decrypt(self, values: list[str]) -> list[str]: ...
    async def aencrypt(self, values: list[str]) -> list[str]: ...
    async def adecrypt(self, values: list[str]) -> list[str]: ...


_crypto_service_holder: dict[str, CryptoService | None] = {'service': None}


def register_crypto_service(service: CryptoService | None) -> None:
    _crypto_service_holder['service'] = service


def get_crypto_service() -> CryptoService | None:
    return _crypto_service_holder['service']


def get_pii_fields(model_class: type[TypeModel]) -> list[str]:
    pii_fields = []
    hints = typing.get_type_hints(model_class, include_extras=True)

    for name, field_info in model_class.model_fields.items():
        extra = getattr(field_info, 'json_schema_extra', None)
        if isinstance(extra, dict) and extra.get('pii'):
            pii_fields.append(name)
        elif _annotation_has_pii(hints.get(name)):
            pii_fields.append(name)
    return pii_fields


def _annotation_has_pii(annotation: Any) -> bool:
    if annotation is None:
        return False

    origin = typing.get_origin(annotation)
    args = typing.get_args(annotation)

    if origin is Annotated:
        for meta in args[1:]:
            if isinstance(meta, FieldInfo):
                extra = getattr(meta, 'json_schema_extra', None)
                if isinstance(extra, dict) and extra.get('pii'):
                    return True
        return False

    if origin is typing.Union or isinstance(annotation, types.UnionType):
        return any(_annotation_has_pii(arg) for arg in args)

    return False
