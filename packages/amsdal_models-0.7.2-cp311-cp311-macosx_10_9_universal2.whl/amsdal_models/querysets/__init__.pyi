from amsdal_utils.query.utils import Q as Q

__all__ = ['Q']
