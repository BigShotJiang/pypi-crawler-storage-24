from amsdal_utils.query.utils import Q

__all__ = ['Q']
