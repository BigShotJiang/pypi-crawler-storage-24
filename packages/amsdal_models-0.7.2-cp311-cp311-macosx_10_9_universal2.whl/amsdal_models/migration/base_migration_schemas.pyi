import abc
from abc import ABC, abstractmethod
from amsdal_models.builder.class_source_builder import ClassSourceBuilder as ClassSourceBuilder
from amsdal_models.builder.utils import ModelModuleInfo as ModelModuleInfo
from amsdal_models.classes.model import Model as Model
from amsdal_utils.models.enums import ModuleType as ModuleType, Versions
from amsdal_utils.schemas.schema import ObjectSchema as ObjectSchema
from typing import Any

_SYNTHETIC_MODULE_NAME: str

class BaseMigrationSchemas(ABC, metaclass=abc.ABCMeta):
    """
    Abstract base class for migration schemas.

    This class provides the interface for managing and compiling database schema migrations.
    It includes methods for registering, unregistering, and compiling classes, as well as
    managing class versions.
    """
    _classes: dict[str, type[Model]]
    _classes_versions: dict[str, dict[str, type[Model]]]
    _buffered_classes: list[tuple[str, ObjectSchema, ModuleType]]
    _models_ready: bool
    _eval_namespace: dict[str, Any]
    def __init__(self) -> None: ...
    @property
    def classes_namespace(self) -> dict[str, type[Model]]: ...
    def get_model(self, name: str) -> type[Model]:
        """
        Retrieves a fully-resolved model type ready for queries.

        On first call after compilation, registers a synthetic module for
        forward-ref resolution, resolves all deferred PKs/FKs, and registers
        classes in ClassManager so runtime code (ReferenceLoader etc.) can
        find them.

        Args:
            name (str): The name of the class whose model type is to be retrieved.

        Returns:
            type[Model]: The model type associated with the given class name.
        """
    def _prepare_models(self) -> None:
        """One-time setup that makes compiled migration classes fully usable."""
    def _register_synthetic_module(self) -> None:
        """Register a synthetic module in sys.modules and set __module__ on
        each compiled class to point to it.

        Compiled classes get __module__='builtins' from eval(), which breaks
        typing.get_type_hints() — it can't find forward refs like
        'BaseProductInfo' or 'StateOptions' in builtins. By creating a module
        that contains all compiled classes and eval namespace names (enums etc.),
        forward-ref resolution works correctly everywhere.
        """
    def _resolve_all_deferred_keys(self) -> None:
        """Resolve deferred primary keys and foreign keys on all compiled classes.

        PKs are resolved first because FK column names depend on the target
        model's primary key fields.
        """
    def _register_classes_in_class_manager(self) -> None:
        """Register compiled classes in ClassManager so that ReferenceLoader
        and other runtime code can find them without filesystem imports."""
    def registered_model_names(self) -> list[str]:
        """
        Returns a list of registered model names.
        This method retrieves the names of all registered model classes.
        It filters the classes to include only those that are subclasses of the Model class.

        Returns:
            list[str]: A list of registered model names.
        """
    @abstractmethod
    def register_model(self, class_name: str, object_schema: ObjectSchema, module_type: ModuleType, class_version: str | Versions = ...) -> None: ...
    @abstractmethod
    def unregister_model(self, class_name: str) -> None: ...
    @abstractmethod
    def compile_buffered_classes(self) -> None: ...
    @abstractmethod
    def compile_classes(self, class_schemas: list[tuple[str, ObjectSchema, ModuleType]], namespace: dict[str, Any]) -> list[tuple[str, type[Model]]]: ...
    @staticmethod
    def register_model_version(class_name: str, class_version: str | Versions) -> None:
        """
        Registers a specific version of a model class.

        This method registers a specific version of a model class using the ClassVersionManager.

        Args:
            class_name (str): The name of the class to register the version for.
            class_version (str | Versions): The version of the class to be registered.

        Returns:
            None
        """

class DefaultMigrationSchemas(BaseMigrationSchemas):
    """
    Default implementation of the BaseMigrationSchemas.

    This class provides the default implementation for managing and compiling database schema migrations.
    It includes methods for registering, unregistering, and compiling classes, as well as managing class versions.
    """
    def register_model(self, class_name: str, object_schema: ObjectSchema, module_type: ModuleType, class_version: str | Versions = ...) -> None:
        """
        Registers a model class for migration.

        This method registers a model class for migration by adding it to the buffered classes
        and registering its latest version.

        Args:
            class_name (str): The name of the class to be registered.
            object_schema (ObjectSchema): The schema of the object to be registered.
            module_type (SchemaTypes): The type of the schema.

        Returns:
            None
        """
    _models_ready: bool
    def compile_buffered_classes(self) -> None:
        """
        Compiles all buffered classes for migration.

        This method compiles all classes that have been buffered for migration and updates the
        internal class dictionary with the compiled class types. It clears the buffer after
        compilation.

        Returns:
            None
        """
    def unregister_model(self, class_name: str) -> None:
        """
        Unregisters a model class from the migration schemas.

        This method removes the specified model class from the internal class dictionary,
        effectively unregistering it from the migration schemas.

        Args:
            class_name (str): The name of the class to be unregistered.

        Returns:
            None
        """
    def compile_classes(self, class_schemas: list[tuple[str, ObjectSchema, ModuleType]], namespace: dict[str, Any]) -> list[tuple[str, type[Model]]]: ...
    @staticmethod
    def _sort_schemas(class_schemas: list[tuple[str, ObjectSchema, ModuleType]]) -> list[tuple[str, ObjectSchema, ModuleType]]: ...
    @staticmethod
    def _resolve_class_inheritance(schema: ObjectSchema) -> type | str: ...

def _make_migration_builtins(namespace: dict[str, Any]) -> dict[str, Any]:
    """Create builtins with a custom __import__ that prevents filesystem model
    imports from overwriting compiled migration classes.

    Model files contain custom_code with imports like
    ``from models.carrier import Carrier``. During eval(), these would load
    the current filesystem class, replacing the migration-compiled version.
    This hook intercepts such imports and returns the compiled class instead.

    Non-model imports (enums, utilities, third-party packages) pass through
    to the real import unchanged.
    """
