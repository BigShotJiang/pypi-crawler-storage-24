from tamar_model_client.schemas.inputs.tencentcloud_vod.video_generation import TencentCloudVodVideoInput

__all__ = ["TencentCloudVodVideoInput"]
