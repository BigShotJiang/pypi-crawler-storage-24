"""
BytePlus SeeDANCE Schemas（兼容 1.5 pro / 2.0 / 2.0 fast）

支持模型：
- seedance-1-5-pro-251215       (Seedance 1.5 pro)
- doubao-seedance-2-0-260128    (Seedance 2.0)
- doubao-seedance-2-0-fast-260128 (Seedance 2.0 fast)

官方 API: POST https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks
"""

from typing import Optional, List, Dict, Literal
from pydantic import BaseModel, Field, field_validator, model_validator

from tamar_model_client.utils import is_seedance_v2


# ==================== Request Schemas ====================

class ContentItem(BaseModel):
    """Content 数组项

    1.5: 支持 text、image_url
    2.0: 额外支持 video_url、audio_url、role 字段
    """

    type: Literal["text", "image_url", "video_url", "audio_url"] = Field(
        ...,
        description="内容类型：text、image_url、video_url（2.0）、audio_url（2.0）"
    )

    text: Optional[str] = Field(
        None,
        description="文本内容（type=text 时使用）"
    )

    image_url: Optional[Dict[str, str]] = Field(
        None,
        description="图像URL（type=image_url 时使用）。格式: {'url': 'https://...'}"
    )

    # ===== Seedance 2.0 新增 =====
    video_url: Optional[Dict[str, str]] = Field(
        None,
        description="视频URL（type=video_url 时使用，仅 2.0）。格式: {'url': 'https://...'}"
    )

    audio_url: Optional[Dict[str, str]] = Field(
        None,
        description="音频URL（type=audio_url 时使用，仅 2.0）。格式: {'url': 'https://...'}"
    )

    role: Optional[str] = Field(
        None,
        description=(
            "媒体文件的位置或用途。\n"
            "图片: first_frame（首帧）、last_frame（尾帧）、reference_image（参考图，仅 2.0）\n"
            "视频: reference_video（参考视频，仅 2.0）\n"
            "音频: reference_audio（参考音频，仅 2.0）"
        )
    )

    @field_validator('image_url', mode='before')
    @classmethod
    def convert_image_string_to_dict(cls, v):
        if isinstance(v, str):
            return {'url': v}
        return v

    @field_validator('video_url', mode='before')
    @classmethod
    def convert_video_string_to_dict(cls, v):
        if isinstance(v, str):
            return {'url': v}
        return v

    @field_validator('audio_url', mode='before')
    @classmethod
    def convert_audio_string_to_dict(cls, v):
        if isinstance(v, str):
            return {'url': v}
        return v


class BytePlusSeeDANCEInput(BaseModel):
    """BytePlus SeeDANCE 请求参数（兼容 1.5 pro / 2.0 / 2.0 fast）

    通用功能：文生视频、图生视频-首帧/首尾帧、有声视频
    2.0 新增：多模态参考（图+视频+音频）、编辑视频、延长视频、联网搜索
    """

    # ==================== 基础参数 ====================
    model: str = Field(
        ...,
        description=(
            "模型 ID（必填）:\n"
            "- seedance-1-5-pro-251215\n"
            "- doubao-seedance-2-0-260128\n"
            "- doubao-seedance-2-0-fast-260128"
        )
    )

    content: List[ContentItem] = Field(
        ...,
        description=(
            "输入内容数组。1.5 支持文本+图片；2.0 额外支持视频+音频。\n"
            "注意: 2.0 不可单独输入音频，应至少包含1个参考视频或图片"
        )
    )

    # ==================== 任务配置参数 ====================
    callback_url: Optional[str] = Field(
        None,
        description="回调通知地址。任务状态变化时发送回调请求"
    )

    return_last_frame: Optional[bool] = Field(
        None,
        description="是否返回生成视频的最后一帧图像（PNG 格式，无水印）。默认值: false"
    )

    service_tier: Optional[str] = Field(
        None,
        description=(
            "服务层级（仅 1.5 支持，2.0 暂不支持）。\n"
            "- default: 在线推理\n"
            "- flex: 离线推理（价格 50%）"
        )
    )

    execution_expires_after: Optional[int] = Field(
        None,
        description="任务过期时间阈值（秒）。默认: 172800（48小时），范围: [3600, 259200]"
    )

    generate_audio: Optional[bool] = Field(
        True,
        description=(
            "控制生成的视频是否包含与画面同步的声音。\n"
            "- true: 自动生成人声、音效及背景音乐\n"
            "- false: 输出无声视频\n"
            "默认值: true"
        )
    )

    # ==================== 视频规格参数 ====================
    resolution: Optional[str] = Field(
        None,
        description="视频分辨率。1.5: 480p/720p/1080p; 2.0: 480p/720p。默认: 720p"
    )

    ratio: Optional[str] = Field(
        None,
        description=(
            "视频宽高比。可选: 16:9, 4:3, 1:1, 3:4, 9:16, 21:9, adaptive\n"
            "默认: 2.0 为 adaptive; 1.5 文生视频为 16:9"
        )
    )

    duration: Optional[int] = Field(
        None,
        description=(
            "视频时长（秒）。1.5: [2,12]; 2.0: [4,15]。-1 表示模型自主选择。\n"
            "默认值: 5"
        )
    )

    # ===== 仅 1.5 支持（2.0 暂不支持） =====
    frames: Optional[int] = Field(
        None,
        description="视频帧数（仅 1.5，2.0 暂不支持）。范围: [29, 289]，格式 25+4n"
    )

    framepersecond: Optional[int] = Field(
        None,
        description="视频帧率（仅 1.5）。可选值: 24。默认: 24"
    )

    camerafixed: Optional[bool] = Field(
        None,
        description="是否固定相机（仅 1.5，2.0 暂不支持）。默认: false"
    )

    # ===== 通用 =====
    seed: Optional[int] = Field(
        None,
        description="随机种子。范围: [-1, 2^32-1]，-1 表示随机。默认: -1"
    )

    watermark: Optional[bool] = Field(
        None,
        description="是否添加水印。默认: false"
    )

    # ===== 仅 2.0 新增 =====
    tools: Optional[List[Dict[str, str]]] = Field(
        None,
        description=(
            "配置模型调用的工具（仅 2.0，仅文生视频）。\n"
            "格式: [{'type': 'web_search'}]"
        )
    )

    # ==================== 系统内部参数 ====================
    enable_async_task: Optional[bool] = Field(
        True,
        description="是否启用异步任务处理（视频生成为长时间任务，建议启用）"
    )

    index: Optional[int] = Field(
        None,
        description="批量任务时的索引，用于标识任务在批次中的位置"
    )

    # ==================== 业务校验 ====================
    @model_validator(mode='after')
    def validate_request(self):
        v2 = is_seedance_v2(self.model)
        content_types = {item.type for item in self.content}

        # tools (web_search) 仅限文生视频（content 只有 text）
        if self.tools and content_types - {"text"}:
            raise ValueError("tools (web_search) 仅支持文生视频场景，content 不能包含图片/视频/音频")

        # 音频不能单独输入，至少需要图片或视频
        if "audio_url" in content_types and not (content_types & {"image_url", "video_url"}):
            raise ValueError("不可单独输入音频，应至少包含1个参考视频或图片")

        # role 条件校验：video_url 必须有 role=reference_video，audio_url 必须有 role=reference_audio
        for item in self.content:
            if item.type == "video_url" and not item.role:
                raise ValueError("video_url 类型必须指定 role（当前仅支持 reference_video）")
            if item.type == "audio_url" and not item.role:
                raise ValueError("audio_url 类型必须指定 role（当前仅支持 reference_audio）")

        if v2:
            # 2.0 分辨率仅 480p/720p
            if self.resolution and self.resolution not in ("480p", "720p"):
                raise ValueError(f"Seedance 2.0 仅支持 480p/720p 分辨率，收到: {self.resolution}")

            # 2.0 时长 [4,15] 或 -1
            if self.duration is not None and self.duration != -1 and not (4 <= self.duration <= 15):
                raise ValueError(f"Seedance 2.0 时长范围 [4,15] 或 -1，收到: {self.duration}")

            # 2.0 不支持的参数
            if self.frames is not None:
                raise ValueError("Seedance 2.0 暂不支持 frames 参数")
            if self.camerafixed is not None:
                raise ValueError("Seedance 2.0 暂不支持 camerafixed 参数")
            if self.service_tier is not None:
                raise ValueError("Seedance 2.0 暂不支持 service_tier 参数")

            # 图片数量上限 9 张
            image_count = sum(1 for item in self.content if item.type == "image_url")
            if image_count > 9:
                raise ValueError(f"Seedance 2.0 最多支持 9 张图片，收到: {image_count}")

            # 视频数量上限 3 个
            video_count = sum(1 for item in self.content if item.type == "video_url")
            if video_count > 3:
                raise ValueError(f"Seedance 2.0 最多支持 3 个参考视频，收到: {video_count}")

            # 音频数量上限 3 个
            audio_count = sum(1 for item in self.content if item.type == "audio_url")
            if audio_count > 3:
                raise ValueError(f"Seedance 2.0 最多支持 3 个参考音频，收到: {audio_count}")

            # 互斥场景：首帧/首尾帧 vs 多模态参考
            roles = [item.role for item in self.content if item.role]
            has_frame_roles = bool({"first_frame", "last_frame"} & set(roles))
            has_ref_roles = bool({"reference_image", "reference_video", "reference_audio"} & set(roles))
            if has_frame_roles and has_ref_roles:
                raise ValueError(
                    "图生视频-首帧/首尾帧 与 多模态参考生视频 为互斥场景，不可混用 "
                    "first_frame/last_frame 和 reference_image/reference_video/reference_audio"
                )

        return self
