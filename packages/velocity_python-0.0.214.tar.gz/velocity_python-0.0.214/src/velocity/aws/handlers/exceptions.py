class AppError(Exception):
    pass


class AccessError(AppError):
    pass


class AlertError(AppError):
    def __init__(
        self,
        message=None,
        *,
        title: str | None = None,
        toast: bool = False,
        variant: str | None = None,
        **payload,
    ):
        # Backwards compatible:
        # - AlertError("msg") keeps args[0] as a string
        # - AlertError({"message": "msg"}) keeps args[0] as that dict
        if (
            isinstance(message, str)
            and title is None
            and toast is False
            and variant is None
            and not payload
        ):
            super().__init__(message)
            return

        if isinstance(message, dict) and title is None and toast is False and variant is None and not payload:
            super().__init__(message)
            return

        data: dict = {}
        if isinstance(message, dict):
            data.update(message)
        elif message is not None:
            data["message"] = message

        if title is not None:
            data["title"] = title
        if toast:
            data["toast"] = True
        if variant is not None:
            data["variant"] = variant
        if payload:
            data.update(payload)

        super().__init__(data)

    def get_payload(self):
        data = self.args[0]
        if isinstance(data, str):
            return {"message": data}
        elif isinstance(data, dict):
            return data
        return {"message": "No message was supplied to AlertError"}
