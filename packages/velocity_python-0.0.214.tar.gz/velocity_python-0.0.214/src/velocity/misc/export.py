from datetime import date, datetime, time, timedelta
from decimal import Decimal
from io import BytesIO
from typing import Dict, List
import base64
import re

import openpyxl
from openpyxl.styles import Alignment, Border, Font, NamedStyle, Side
from openpyxl.utils import get_column_letter


NUMBER_FORMAT_RE = re.compile(r"[#0?][#0?,]*(?:\.[#0?]+)?")


def extract(d: dict, keys: List[str]) -> List:
    """Extract values from a dictionary based on a list of keys."""
    return [d.get(key) for key in keys]


def _stringify_cell_value(value) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    return str(value)


def _select_number_format_section(format_code: str, value) -> str:
    sections = format_code.split(";")
    if not sections:
        return format_code
    if value < 0 and len(sections) > 1:
        return sections[1]
    if value == 0 and len(sections) > 2:
        return sections[2]
    return sections[0]


def _clean_number_format(format_code: str) -> str:
    cleaned = []
    in_quotes = False
    idx = 0
    while idx < len(format_code):
        char = format_code[idx]
        if char == '"':
            in_quotes = not in_quotes
        elif in_quotes:
            cleaned.append(char)
        elif char == "\\":
            idx += 1
            if idx < len(format_code):
                cleaned.append(format_code[idx])
        elif char in {"_", "*"}:
            idx += 1
        elif char == "[":
            end = format_code.find("]", idx + 1)
            if end == -1:
                break
            idx = end
        else:
            cleaned.append(char)
        idx += 1
    return "".join(cleaned)


def _format_numeric_value(value, format_code: str) -> str:
    section = _clean_number_format(_select_number_format_section(format_code, value))
    if not section or section.lower() == "general":
        return str(value)

    match = NUMBER_FORMAT_RE.search(section)
    if not match:
        return str(value)

    pattern = match.group(0)
    prefix = section[: match.start()]
    suffix = section[match.end() :]
    percent_multiplier = section.count("%")
    scaled_value = abs(value) * (100**percent_multiplier)
    decimal_places = len(pattern.split(".", 1)[1]) if "." in pattern else 0
    use_grouping = "," in pattern.split(".", 1)[0]

    if use_grouping:
        number = f"{scaled_value:,.{decimal_places}f}"
    else:
        number = f"{scaled_value:.{decimal_places}f}"

    if value < 0 and len(format_code.split(";")) == 1 and "-" not in prefix and "(" not in prefix:
        prefix = f"-{prefix}"

    return f"{prefix}{number}{suffix}"


def _display_value(cell) -> str:
    value = cell.value
    if value is None:
        return ""
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (datetime, date, time, timedelta)):
        return str(value)
    if isinstance(value, (int, float, Decimal)):
        return _format_numeric_value(value, cell.number_format)
    return str(value)


def autosize_columns(ws, fixed: Dict[str, float] | None = None):
    """Autosize columns in the worksheet based on content length."""
    fixed = fixed or {}
    for col in ws.columns:
        max_length = 0
        for cell in col:
            try:
                display_value = _display_value(cell)
                if len(display_value) > max_length:
                    max_length = len(display_value)
            except Exception:
                continue
        adjusted_width = (max_length + 2) * 1.2
        col_letter = get_column_letter(col[0].column)
        ws.column_dimensions[col_letter].width = fixed.get(col_letter, adjusted_width)


def create_spreadsheet(
    headers: List[str],
    rows: List[List],
    fileorbuffer,
    styles: Dict[str, str] | None = None,
    merge: List[str] | None = None,
    formats: Dict[str, str] | None = None,
    named_styles: List[NamedStyle] | None = None,
    freeze_panes: str = "A2",
    dimensions: dict = None,
    auto_size: bool = True,
):
    """Create an Excel spreadsheet with specified headers, rows, and styles."""
    styles = styles or {}
    merge = merge or []
    formats = formats or {}
    named_styles = named_styles or []

    wb = openpyxl.Workbook()
    ws = wb.active

    # Define default named styles
    def get_named_styles():
        named_styles = {
            "col_header": NamedStyle(
                name="col_header",
                font=Font(bold=True),
                border=Border(bottom=Side(style="medium", color="000000")),
            ),
            "sum_total": NamedStyle(
                name="sum_total",
                border=Border(bottom=Side(style="double", color="000000")),
            ),
            "sub_total": NamedStyle(
                name="sub_total",
                font=Font(bold=True),
                border=Border(bottom=Side(style="thin", color="000000")),
            ),
            "bold": NamedStyle(name="bold", font=Font(bold=True)),
            "align_right": NamedStyle(
                name="align_right",
                font=Font(bold=True),
                border=Border(top=Side(style="thin", color="000000")),
                alignment=Alignment(horizontal="right", vertical="center"),
            ),
            "align_left": NamedStyle(
                name="align_left",
                font=Font(bold=True),
                border=Border(top=Side(style="thin", color="000000")),
                alignment=Alignment(horizontal="left", vertical="center"),
            ),
            "align_right_double": NamedStyle(
                name="align_right_double",
                font=Font(bold=True),
                border=Border(top=Side(style="double", color="000000")),
                alignment=Alignment(horizontal="right", vertical="center"),
            ),
            "align_left_double": NamedStyle(
                name="align_left_double",
                font=Font(bold=True),
                border=Border(top=Side(style="double", color="000000")),
                alignment=Alignment(horizontal="left", vertical="center"),
            ),
        }
        return named_styles

    # Add default and user-defined styles
    local_styles = get_named_styles()
    for style in named_styles:
        local_styles[style.name] = style
    for style in local_styles.values():
        wb.add_named_style(style)

    # Add headers and rows
    ws.append(headers)
    for row in rows:
        ws.append(row)

    # Set freeze panes
    ws.freeze_panes = freeze_panes

    for cell, format_code in formats.items():
        ws[cell].number_format = format_code

    # Auto-size columns if enabled
    if auto_size:
        autosize_columns(ws, fixed={})

    # Set row and column dimensions if provided
    if dimensions:
        for key, val in dimensions.get("rows", {}).items():
            ws.row_dimensions[key].height = val
        for key, val in dimensions.get("columns", {}).items():
            ws.column_dimensions[key].width = val

    # Apply cell styles, merges, and formats
    for cell, style_name in styles.items():
        if style_name in local_styles:
            ws[cell].style = local_styles[style_name]
    for cell_range in merge:
        ws.merge_cells(cell_range)

    # Save workbook to the provided file or buffer
    wb.save(fileorbuffer)


def get_downloadable_spreadsheet(
    headers: List[str],
    rows: List[List],
    styles: Dict[str, str] | None = None,
    merge: List[str] | None = None,
    formats: Dict[str, str] | None = None,
    named_styles: List[NamedStyle] | None = None,
    freeze_panes: str = "A2",
    dimensions: dict = None,
    auto_size: bool = True,
) -> str:
    """Generate a downloadable spreadsheet encoded in base64."""
    buffer = BytesIO()
    create_spreadsheet(
        headers,
        rows,
        buffer,
        styles,
        merge,
        formats,
        named_styles,
        freeze_panes,
        dimensions,
        auto_size,
    )
    return base64.b64encode(buffer.getvalue()).decode()
