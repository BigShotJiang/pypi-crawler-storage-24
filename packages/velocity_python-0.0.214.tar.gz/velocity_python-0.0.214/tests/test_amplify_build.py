from velocity.aws.amplify_build import (
    BackendDeploymentConfig,
    build_environment_variables,
    get_amplify_app_id_and_branch,
)


class FakeAmplifyProject:
    def get_merged_env_vars(self, branch):
        return {"EXISTING": branch}

    def get_region(self):
        return "us-east-1"


def test_backend_deployment_config_resolves_queue_timeout_and_memory_size():
    config = BackendDeploymentConfig(
        queue_name_template="clients-queue-{branch}",
        short_timeout_tokens=("Events", "Data"),
        memory_size_by_token={"QueueHandler": 1024, "Events": 512},
    )

    assert config.resolve_queue_name("Demo") == "clients-queue-demo"
    assert config.resolve_timeout("ClientEvents-demo") == 60
    assert config.resolve_timeout("ClientUtility-demo") == 900
    assert config.resolve_memory_size("ClientQueueHandler-demo") == 1024
    assert config.resolve_memory_size("ClientEvents-demo") == 512
    assert config.resolve_memory_size("ClientUtility-demo") is None


def test_build_environment_variables_reads_project_metadata(tmp_path, monkeypatch):
    amplify_dir = tmp_path / "amplify" / "backend"
    amplify_dir.mkdir(parents=True)
    (amplify_dir / "amplify-meta.json").write_text('{"UserPoolId": "us-east-1_demoPool",}')

    monkeypatch.setenv("AWS_JOB_ID", "job-123")
    app = FakeAmplifyProject()

    env_vars = build_environment_variables(
        app,
        "demo",
        "clients-queue-demo",
        project_root=tmp_path,
    )

    assert env_vars["EXISTING"] == "demo"
    assert env_vars["SqsWorkQueue"] == "clients-queue-demo"
    assert env_vars["AWS_JOB_ID"] == "job-123"
    assert env_vars["AWS_USER_POOL_ID"] == "us-east-1_demoPool"
    assert env_vars["USER_BRANCH"] == "demo"
    assert env_vars["REACT_APP_USER_BRANCH"] == "demo"
    assert env_vars["USER_REGION"] == "us-east-1"
    assert env_vars["LOGLEVEL"] == "INFO"
    assert "BUILD_DATETIME" in env_vars


def test_get_amplify_app_id_and_branch_uses_team_provider_info(tmp_path, monkeypatch):
    team_provider_path = tmp_path / "amplify"
    team_provider_path.mkdir(parents=True)
    (team_provider_path / "team-provider-info.json").write_text(
        '{"demo": {"awscloudformation": {"AmplifyAppId": "app-123"}}}'
    )

    monkeypatch.setenv("AWS_BRANCH", "demo")
    monkeypatch.delenv("AWS_APP_ID", raising=False)

    app_id, branch = get_amplify_app_id_and_branch(tmp_path)

    assert app_id == "app-123"
    assert branch == "demo"