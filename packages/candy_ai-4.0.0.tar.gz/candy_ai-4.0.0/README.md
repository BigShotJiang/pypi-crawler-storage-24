# 🍬 candy-ai v4

Client Python pour **cedric-8EF** — moteur IA multi-personnalités.  
**Zéro configuration.** URL récupérée automatiquement.  
**Bannière ASCII** au démarrage. **Système de profils** complet.

---

## Installation

```bash
pip install candy-ai
```

---

## Démarrage immédiat

```python
from candy import Coding

print(Coding.ask("Write a quicksort in Python"))
```

Au premier import, le terminal affiche automatiquement :

```
   ██████╗ █████╗ ███╗   ██╗██████╗ ██╗   ██╗
  ██╔════╝██╔══██╗████╗  ██║██╔══██╗╚██╗ ██╔╝
  ██║     ███████║██╔██╗ ██║██║  ██║ ╚████╔╝
  ██║     ██╔══██║██║╚██╗██║██║  ██║  ╚██╔╝
  ╚██████╗██║  ██║██║ ╚████║██████╔╝   ██║
   ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝    ╚═╝
  ⚡ cedric-8EF Engine  •  50 personalities
```

> Pour désactiver : `CANDY_NO_BANNER=1 python script.py`

---

## Profils

```python
from candy import cfg, Coding, Math, Full

# Créer des profils
cfg.A.lang         = "FR"
cfg.A.max_tokens   = 2000
cfg.A.style        = "detailed"
cfg.A.tone         = "encouraging"
cfg.A.expertise    = "beginner"

cfg.B.lang         = "EN"
cfg.B.max_tokens   = 300
cfg.B.style        = "technical"
cfg.B.expertise    = "expert"

cfg.default.lang   = "FR"   # utilisé sans .use()

# Utiliser
print(Coding.ask("Explique les générateurs"))      # → default
print(Math.use("A").ask("Résous ∫x²sin(x)dx"))    # → profil A
print(Coding.use("B").ask("Optimise ce code"))     # → profil B
```

---

## Presets rapides

```python
from candy import cfg, Coding, Tutor

# Applique un preset prédéfini
cfg.A = cfg.preset("coder")           # technique, expert, markdown
cfg.B = cfg.preset("french_beginner") # FR, détaillé, encourageant
cfg.C = cfg.preset("quick")           # très court, direct

# Presets disponibles :
# french_beginner  french_expert  english_beginner  english_expert
# quick  academic  creative  teacher  coder  journalist

print(Coding.use("A").ask("Write a Redis client"))
print(Tutor.use("B").ask("C'est quoi une variable ?"))
```

---

## Tous les paramètres par profil

| Paramètre | Défaut | Valeurs |
|-----------|--------|---------|
| `lang` | `"EN"` | `FR EN ES DE IT PT ZH JA AR RU NL PL SV TR KO HI VI ID CS RO` |
| `max_tokens` | `1024` | `100` → `4096` |
| `temperature` | `0.7` | `0.0` (factuel) → `1.5` (créatif) |
| `style` | `"default"` | `default` `concise` `detailed` `bullet` `academic` `casual` `technical` `eli5` |
| `tone` | `"neutral"` | `neutral` `encouraging` `strict` `humorous` `empathetic` `socratic` |
| `output_format` | `"text"` | `text` `markdown` `json` `html` |
| `expertise` | `"intermediate"` | `beginner` `intermediate` `expert` |
| `include_examples` | `True` | `True` / `False` |
| `safe_mode` | `True` | `True` / `False` |
| `timeout` | `120` | secondes |
| `cache_url` | `True` | `True` / `False` |

---

## Streaming

```python
from candy import cfg, Writing

cfg.A.lang  = "FR"
cfg.A.style = "casual"

# Option 1 — itérer manuellement
for token in Writing.use("A").stream("Écris une histoire de pirates"):
    print(token, end="", flush=True)

# Option 2 — stream_print() fait tout automatiquement
Writing.use("A").stream_print("Écris une histoire de pirates")
```

---

## Contexte

```python
from candy import Analytic

data = "Mois,Revenu\nJan,12000\nFév,15400\nMar,9800"
print(Analytic.use("A").ask("Quelle tendance ?", context=data))
```

---

## Utilitaires

```python
from candy import Coding

# Vérifier si l'API est en ligne
print(Coding.is_online())      # True / False

# Mesurer la latence
print(Coding.ping())           # 142.3 (ms)

# Quota journalier
print(Coding.quota())          # {'quota_remaining': 488, ...}

# Voir tous les profils définis
from candy import list_profiles
print(list_profiles())         # ['default', 'A', 'B', 'rapide']

# Inspecter un profil
print(cfg.A)                   # affiche tous les paramètres
print(cfg)                     # résumé de tous les profils

# Réinitialiser un profil
cfg.A.reset()

# Lister les presets disponibles
print(cfg.list_presets())
```

---

## Combiner plusieurs personnalités

```python
from candy import cfg, Coding, Debugger, Reviewer

cfg.A = cfg.preset("coder")
cfg.A.lang = "FR"

code   = Coding.use("A").ask("Écris un client REST en Python")
bugs   = Debugger.use("A").ask("Trouve les bugs", context=code)
review = Reviewer.use("A").ask("Évalue ce code", context=code)

print(code)
print(bugs)
print(review)
```

---

## Réponse avec métadonnées

```python
data = Coding.use("A").ask_with_meta("Hello")
print(data["response"])
print("Quota restant :", data["quota_remaining"])
print("IP :", data["ip"])
```

---

## Les 50 personnalités

`Math` `Coding` `Reflexion` `Analytic` `Full` `Science` `Writing` `History`
`Law` `Medicine` `Finance` `Marketing` `Security` `Design` `Language`
`Psychology` `Education` `Research` `Business` `Productivity` `Cooking`
`Travel` `Music` `Film` `Sports` `Philosophy` `Environment` `Architecture`
`Automotive` `Astronomy` `Biology` `Chemistry` `Physics` `Engineering`
`Entrepreneur` `Ethics` `Geopolitics` `Crypto` `AI` `DevOps` `Database`
`GameDev` `Comic` `Storyteller` `Translator` `Summarizer` `Debugger`
`Reviewer` `Planner` `Tutor`

---

Propulsé par **cedric-8EF** · Quota 500 req/jour · MIT License
