"""
🍬 candy v4 — Python client for cedric-8EF
"""

# ── Bannière ASCII au premier import ────────────────────────────────────────
from .banner import show_banner
show_banner()

# ── Config & utilitaires ─────────────────────────────────────────────────────
from .config import config as cfg, get_profile, list_profiles
from .client import CandyClient, CandyUnavailableError, CandyQuotaError, CandyTimeoutError

# ── 50 personnalités ─────────────────────────────────────────────────────────
from .modules.math import Math
from .modules.reflexion import Reflexion
from .modules.coding import Coding
from .modules.analytic import Analytic
from .modules.full import Full
from .modules.science import Science
from .modules.writing import Writing
from .modules.history import History
from .modules.law import Law
from .modules.medicine import Medicine
from .modules.finance import Finance
from .modules.marketing import Marketing
from .modules.security import Security
from .modules.design import Design
from .modules.language import Language
from .modules.psychology import Psychology
from .modules.education import Education
from .modules.research import Research
from .modules.business import Business
from .modules.productivity import Productivity
from .modules.cooking import Cooking
from .modules.travel import Travel
from .modules.music import Music
from .modules.film import Film
from .modules.sports import Sports
from .modules.philosophy import Philosophy
from .modules.environment import Environment
from .modules.architecture import Architecture
from .modules.automotive import Automotive
from .modules.astronomy import Astronomy
from .modules.biology import Biology
from .modules.chemistry import Chemistry
from .modules.physics import Physics
from .modules.engineering import Engineering
from .modules.entrepreneur import Entrepreneur
from .modules.ethics import Ethics
from .modules.geopolitics import Geopolitics
from .modules.crypto import Crypto
from .modules.ai import AI
from .modules.devops import DevOps
from .modules.database import Database
from .modules.gamedev import GameDev
from .modules.comic import Comic
from .modules.storyteller import Storyteller
from .modules.translator import Translator
from .modules.summarizer import Summarizer
from .modules.debugger import Debugger
from .modules.reviewer import Reviewer
from .modules.planner import Planner
from .modules.tutor import Tutor

__version__ = "4.0.0"
__author__  = "cedric-8EF"

__all__ = [
    # Config
    "cfg", "get_profile", "list_profiles",
    # Exceptions
    "CandyClient", "CandyUnavailableError", "CandyQuotaError", "CandyTimeoutError",
    # Personnalités
    "Math","Reflexion","Coding","Analytic","Full","Science","Writing",
    "History","Law","Medicine","Finance","Marketing","Security","Design",
    "Language","Psychology","Education","Research","Business","Productivity",
    "Cooking","Travel","Music","Film","Sports","Philosophy","Environment",
    "Architecture","Automotive","Astronomy","Biology","Chemistry","Physics",
    "Engineering","Entrepreneur","Ethics","Geopolitics","Crypto","AI","DevOps",
    "Database","GameDev","Comic","Storyteller","Translator","Summarizer",
    "Debugger","Reviewer","Planner","Tutor",
]
