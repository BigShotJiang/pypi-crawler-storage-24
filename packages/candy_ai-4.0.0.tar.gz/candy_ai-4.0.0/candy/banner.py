"""
candy.banner — Affiche le logo CANDY au démarrage
"""

import sys
import os

_BANNER = """
\033[95m   ██████╗ █████╗ ███╗   ██╗██████╗ ██╗   ██╗
\033[95m  ██╔════╝██╔══██╗████╗  ██║██╔══██╗╚██╗ ██╔╝
\033[96m  ██║     ███████║██╔██╗ ██║██║  ██║ ╚████╔╝ 
\033[96m  ██║     ██╔══██║██║╚██╗██║██║  ██║  ╚██╔╝  
\033[94m  ╚██████╗██║  ██║██║ ╚████║██████╔╝   ██║   
\033[94m   ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝    ╚═╝  \033[0m
\033[90m  ─────────────────────────────────────────────
\033[97m  ⚡ cedric-8EF Engine  •  50 personalities
\033[90m  ─────────────────────────────────────────────\033[0m
"""

_shown = False

def show_banner():
    global _shown
    if _shown:
        return
    # Ne pas afficher si pas dans un terminal (ex: notebook, CI)
    if not sys.stdout.isatty():
        _shown = True
        return
    # Ne pas afficher si CANDY_NO_BANNER=1
    if os.environ.get("CANDY_NO_BANNER") == "1":
        _shown = True
        return
    print(_BANNER)
    _shown = True
