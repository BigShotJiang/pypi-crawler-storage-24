"""SignalNet Python SDK — interact with the SignalNet quant signal platform."""

from signalnet.client import SignalNet
from signalnet.exceptions import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    SignalNetError,
    ValidationError,
)

__version__ = "0.1.1"
__all__ = [
    "SignalNet",
    "SignalNetError",
    "AuthenticationError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
    "__version__",
]
