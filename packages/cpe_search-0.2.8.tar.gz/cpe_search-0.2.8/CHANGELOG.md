# Changelog
This file keeps track of all notable changes between the different versions of cpe_search.

## v0.2.8 - 2026-03-10
### Fixed
- Improve over-restrictive filtering of potential CPEs
- Fix get_all_cpes(...) function

## v0.2.7 - 2026-02-12
### Changed
- Remove arguably erroneous query correction

### Fixed
- Fix fuzzy search for JS libraries

## v0.2.6 - 2026-02-10
### Added
- Added a progress bar when downloading data from NVD

### Changed
- Increase rate limit for NVD download
- Adjusted DB name restrictions for Windows
- Disabled DB name checking with SQLite

### Fixed
- Made update process more resilient to NVD errors

## v0.2.5 - 2026-01-27
### Added
- Added an abbreviation for Alibaba ACK

### Changed
- Slightly adjusted weights of new search algorithm.

### Fixed
- Fixed another small performance issue

## v0.2.4 - 2026-01-27
### Fixed
- Fixed a small performance issue

## v0.2.3 - 2026-01-26
### Changed
- Slightly adjusted weights of new search algorithm.

### Fixed
- Fixed bad search if a versionless search was issued.

## v0.2.2 - 2026-01-26
### Added
- If a query without version is detected, create and use CPE without version

## v0.2.1 - 2026-01-26
### Fixed
- Improve performance of new search algorithm

## v0.2.0 - 2026-01-25
### Added
- Improve search algorithm by favoring "popularity" and matching version

## v0.1.9 - 2026-01-08
### Changed
- Update README with information about database download.

## v0.1.8 - 2026-01-08
### Added
- Added GitHub workflow to build CPE database and attach it to the latest release
- Added feature to download CPE database from latest GitHub release
- Added CLI argument to print cpe_search version

## v0.1.7 - 2025-12-22
### Added
- Improve CPE creation with subversion parts

## v0.1.6 - 2025-12-06
### Fixed
- Fix bugs from last update

## v0.1.5 - 2025-12-06
### Fixed
- Remove duplicate CPEs in results
- Remove created CPEs where a patch/subversion was contained in the CPE twice

## v0.1.4 - 2025-11-27
### Fixed
- Fixed bug with `-` and `_` in queries preventing valid CPE matches

## v0.1.3 - 2025-11-21
### Fixed
- Skip retrieval of deprecatedBy CPEs if NVD's dictionary does not contain this data

## v0.1.2 - 2025-11-18
### Fixed
- GitHub workflow to publish PyPI package uses more recent action versions

## v0.1.1 - 2025-11-18
### Added
- GitHub workflow to automatically publish a package to PyPI on new release

## v0.1.0 - 2025-11-17
### Added
- Initial release
