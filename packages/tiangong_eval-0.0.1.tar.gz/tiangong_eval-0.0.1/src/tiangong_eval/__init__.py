"""
TianGong Eval -- Agent evaluation and tribulation testing framework.
"""
__version__ = "0.0.1"
