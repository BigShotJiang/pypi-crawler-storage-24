# tiangong-eval

> TianGong Eval -- Agent evaluation and tribulation testing framework.

Part of the [TianGong](https://github.com/JinNing6/TianGong) ecosystem.

## Status

Planning -- This package is under active development. Stay tuned!

## License

MIT
