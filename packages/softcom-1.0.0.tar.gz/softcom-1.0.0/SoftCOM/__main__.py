"""
 Entry point for `python -m SoftCOM`
"""
from .softcom import main

main()
