"""
Tests for the NomadicML video client.
"""
import csv
from io import StringIO
import pytest
from unittest.mock import patch, MagicMock, mock_open
from nomadicml import NomadicML
from nomadicml.types import VideoSource
from nomadicml.video import AnalysisType, CustomCategory
from nomadicml.exceptions import ValidationError, APIError
import time

class TestVideoClient:
    """Test cases for the NomadicML video client."""

    @pytest.fixture
    def client(self):
        """Create a NomadicML client for testing."""
        return NomadicML(api_key="test_api_key")

    def test_upload_video_with_missing_path(self, client):
        """Test upload_video with missing file_path."""
        with pytest.raises(ValidationError):
            client.video._upload_video("")

    def test_upload_gcs_requires_integration_id(self, client):
        class DummyHelper:
            def list(self, *, type=None):
                return []

        client.__dict__["cloud_integrations"] = DummyHelper()
        with pytest.raises(ValidationError):
            client.video.upload("gs://fleet/video.mp4")

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_s3_does_not_require_integration_id(self, mock_make_request, client):
        class DummyHelper:
            def list(self, *, type=None):
                return []

        client.__dict__["cloud_integrations"] = DummyHelper()
        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-no-int"}
        mock_make_request.return_value = mock_response

        result = client.video.upload("s3://fleet/video.mp4", wait_for_uploaded=False)
        assert result == {"import_job_id": "ij-no-int", "status": "importing"}
        call_kwargs = mock_make_request.call_args.kwargs
        assert call_kwargs["json_data"] == {
            "keys": ["video.mp4"],
            "collection": client.collection_name,
            "folder_id": None,
            "scope": "user",
            "bucket": "fleet",
        }

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_hf_bucket_uses_bucket_only_backend_resolution(self, mock_make_request, client):
        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-hf-int"}
        mock_make_request.return_value = mock_response

        result = client.video.upload(
            "hf://buckets/JohnnyMnenonic/test/incoming/front.mp4",
            wait_for_uploaded=False,
        )

        assert result == {"import_job_id": "ij-hf-int", "status": "importing"}
        call_kwargs = mock_make_request.call_args.kwargs
        assert call_kwargs == {
            "method": "POST",
            "endpoint": "/api/hf-buckets/upload",
            "json_data": {
                "files": ["incoming/front.mp4"],
                "collection": client.collection_name,
                "folder_id": None,
                "scope": "user",
                "bucket": "JohnnyMnenonic/test",
            },
        }

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_hf_bucket_public_bucket_uses_bucket_only_backend_resolution(self, mock_make_request, client):
        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-hf-public"}
        mock_make_request.return_value = mock_response

        result = client.video.upload(
            "hf://buckets/JohnnyMnenonic/test/incoming/front.mp4",
            wait_for_uploaded=False,
        )

        assert result == {"import_job_id": "ij-hf-public", "status": "importing"}
        call_kwargs = mock_make_request.call_args.kwargs
        assert call_kwargs == {
            "method": "POST",
            "endpoint": "/api/hf-buckets/upload",
            "json_data": {
                "files": ["incoming/front.mp4"],
                "collection": client.collection_name,
                "folder_id": None,
                "scope": "user",
                "bucket": "JohnnyMnenonic/test",
            },
        }

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_hf_bucket_with_explicit_integration_id(self, mock_make_request, client):
        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-hf-explicit"}
        mock_make_request.return_value = mock_response

        result = client.video.upload(
            "hf://buckets/JohnnyMnenonic/test/incoming/front.mp4",
            integration_id="hf-int-1",
            wait_for_uploaded=False,
        )

        assert result == {"import_job_id": "ij-hf-explicit", "status": "importing"}
        call_kwargs = mock_make_request.call_args.kwargs
        assert call_kwargs == {
            "method": "POST",
            "endpoint": "/api/hf-buckets/upload",
            "json_data": {
                "integration_id": "hf-int-1",
                "files": ["incoming/front.mp4"],
                "collection": client.collection_name,
                "folder_id": None,
                "scope": "user",
                "bucket": "JohnnyMnenonic/test",
            },
        }

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_hf_bucket_preserves_custom_collection_name(self, mock_make_request):
        client = NomadicML(api_key="test_api_key", collection_name="videos_dev")
        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-hf-custom"}
        mock_make_request.return_value = mock_response

        result = client.video.upload(
            "hf://buckets/JohnnyMnenonic/test/incoming/front.mp4",
            wait_for_uploaded=False,
        )

        assert result == {"import_job_id": "ij-hf-custom", "status": "importing"}
        call_kwargs = mock_make_request.call_args.kwargs
        assert call_kwargs["json_data"]["collection"] == "videos_dev"

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_gcs_success(self, mock_make_request, client):
        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-123"}
        mock_make_request.return_value = mock_response

        result = client.upload(
            "gs://fleet/videos/run1.mp4",
            gcs_integration_id="int1",
            wait_for_uploaded=False,
        )

        assert result == {"import_job_id": "ij-123", "status": "importing"}
        assert mock_make_request.call_count == 1
        call_kwargs = mock_make_request.call_args.kwargs
        assert call_kwargs == {
            "method": "POST",
            "endpoint": "/api/gcs/upload",
            "json_data": {
                "integration_id": "int1",
                "files": ["videos/run1.mp4"],
                "collection": client.collection_name,
                "folder_id": None,
                "scope": "user",
            },
        }

    def test_upload_gcs_rejects_multiple_buckets(self, client):
        with pytest.raises(ValidationError):
            client.video.upload(
                ["gs://one/video1.mp4", "gs://two/video2.mp4"],
                gcs_integration_id="int1",
                wait_for_uploaded=False,
            )

    def test_upload_gcs_rejects_non_mp4(self, client):
        with pytest.raises(ValidationError):
            client.video.upload(
                "gs://fleet/video.mov",
                gcs_integration_id="int1",
                wait_for_uploaded=False,
            )

    def test_upload_s3_rejects_non_mp4(self, client):
        with pytest.raises(ValidationError):
            client.video.upload(
                "s3://fleet/video.mov",
                integration_id="int1",
                wait_for_uploaded=False,
            )

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_gcs_autodetect_integration(self, mock_make_request, client):
        class DummyHelper:
            def list(self, *, type=None):
                return [{"id": "auto1", "bucket": "fleet"}]

        client.__dict__["cloud_integrations"] = DummyHelper()

        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-auto1"}
        mock_make_request.return_value = mock_response

        result = client.upload("gs://fleet/videos/run1.mp4", wait_for_uploaded=False)
        assert result == {"import_job_id": "ij-auto1", "status": "importing"}
        call_kwargs = mock_make_request.call_args.kwargs
        assert call_kwargs["json_data"]["integration_id"] == "auto1"

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_gcs_autodetect_ambiguous(self, mock_make_request, client):
        class DummyHelper:
            def list(self, *, type=None):
                return [
                    {"id": "auto1", "bucket": "fleet"},
                    {"id": "auto2", "bucket": "fleet"},
                ]

        client.__dict__["cloud_integrations"] = DummyHelper()

        mock_error = APIError(400, "bucket mismatch", {"detail": "wrong bucket"})
        success_response = MagicMock()
        success_response.json.return_value = {"import_job_id": "ij-auto2"}
        mock_make_request.side_effect = [mock_error, success_response]

        result = client.upload("gs://fleet/videos/run1.mp4", wait_for_uploaded=False)
        assert result == {"import_job_id": "ij-auto2", "status": "importing"}
        assert mock_make_request.call_count == 2
        last_call_kwargs = mock_make_request.call_args.kwargs
        assert last_call_kwargs["json_data"]["integration_id"] == "auto2"

    def test_upload_gcs_autodetect_missing(self, client):
        class DummyHelper:
            def list(self, *, type=None):
                return []

        client.__dict__["cloud_integrations"] = DummyHelper()

        with pytest.raises(ValidationError):
            client.video.upload("gs://fleet/videos/run1.mp4", wait_for_uploaded=False)

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_s3_success(self, mock_make_request, client):
        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-s3-int2"}
        mock_make_request.return_value = mock_response

        result = client.upload(
            "s3://archive/uploads/run1.mp4",
            integration_id="int2",
            wait_for_uploaded=False,
        )

        assert result == {"import_job_id": "ij-s3-int2", "status": "importing"}
        call_kwargs = mock_make_request.call_args.kwargs
        assert call_kwargs == {
            "method": "POST",
            "endpoint": "/api/s3/upload",
            "json_data": {
                "integration_id": "int2",
                "keys": ["uploads/run1.mp4"],
                "collection": client.collection_name,
                "folder_id": None,
                "scope": "user",
                "bucket": "archive",
            },
        }

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_s3_autodetect_integration(self, mock_make_request, client):
        class DummyHelper:
            def list(self, *, type=None):
                return [{"id": "auto-s3", "bucket": "archive"}]

        client.__dict__["cloud_integrations"] = DummyHelper()

        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-s3-auto"}
        mock_make_request.return_value = mock_response

        result = client.upload("s3://archive/uploads/run1.mp4", wait_for_uploaded=False)
        assert result == {"import_job_id": "ij-s3-auto", "status": "importing"}
        call_kwargs = mock_make_request.call_args.kwargs
        assert call_kwargs["json_data"] == {
            "keys": ["uploads/run1.mp4"],
            "collection": client.collection_name,
            "folder_id": None,
            "scope": "user",
            "bucket": "archive",
        }

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_s3_autodetect_missing_falls_back_to_bucket_only(self, mock_make_request, client):
        class DummyHelper:
            def list(self, *, type=None):
                return []

        client.__dict__["cloud_integrations"] = DummyHelper()

        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-s3-fallback"}
        mock_make_request.return_value = mock_response

        result = client.video.upload("s3://archive/uploads/run1.mp4", wait_for_uploaded=False)

        assert result == {"import_job_id": "ij-s3-fallback", "status": "importing"}
        call_kwargs = mock_make_request.call_args.kwargs
        assert call_kwargs == {
            "method": "POST",
            "endpoint": "/api/s3/upload",
            "json_data": {
                "keys": ["uploads/run1.mp4"],
                "collection": client.collection_name,
                "folder_id": None,
                "scope": "user",
                "bucket": "archive",
            },
        }

    @patch("nomadicml.video.VideoClient._wait_for_uploaded")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_cloud_ignores_wait_for_uploaded(self, mock_make_request, mock_wait_for_uploaded, client):
        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-wait-ignored"}
        mock_make_request.return_value = mock_response

        result = client.video.upload("s3://archive/uploads/run1.mp4", wait_for_uploaded=True)

        assert result == {"import_job_id": "ij-wait-ignored", "status": "importing"}
        mock_wait_for_uploaded.assert_not_called()

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_multi_view_cloud_s3_uses_sets_payload(self, mock_make_request, client):
        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-mv-s3"}
        mock_make_request.return_value = mock_response

        result = client.video.upload(
            [
                {
                    "front": "s3://archive/uploads/set1/front.mp4",
                    "left": "s3://archive/uploads/set1/left.mp4",
                    "right": "s3://archive/uploads/set1/right.mp4",
                },
                {
                    "front": "s3://archive/uploads/set2/front.mp4",
                    "rear": "s3://archive/uploads/set2/rear.mp4",
                },
            ],
            wait_for_uploaded=False,
        )

        assert result == {"import_job_id": "ij-mv-s3", "status": "importing"}
        call_kwargs = mock_make_request.call_args.kwargs
        assert call_kwargs["method"] == "POST"
        assert call_kwargs["endpoint"] == "/api/s3/upload"
        assert call_kwargs["json_data"] == {
            "sets": [
                {
                    "views": {
                        "front": "s3://archive/uploads/set1/front.mp4",
                        "left": "s3://archive/uploads/set1/left.mp4",
                        "right": "s3://archive/uploads/set1/right.mp4",
                    }
                },
                {
                    "views": {
                        "front": "s3://archive/uploads/set2/front.mp4",
                        "rear": "s3://archive/uploads/set2/rear.mp4",
                    }
                },
            ],
            "collection": client.collection_name,
            "folder_id": None,
            "scope": "user",
            "bucket": "archive",
        }

    @patch("nomadicml.video.logger.warning")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_multi_view_cloud_wait_for_uploaded_warns(self, mock_make_request, mock_warning, client):
        class DummyHelper:
            def list(self, *, type=None):
                return [{"id": "gcs-int", "bucket": "fleet"}]

        client.__dict__["cloud_integrations"] = DummyHelper()
        mock_response = MagicMock()
        mock_response.json.return_value = {"import_job_id": "ij-mv-gcs"}
        mock_make_request.return_value = mock_response

        result = client.video.upload(
            {"front": "gs://fleet/set/front.mp4", "left": "gs://fleet/set/left.mp4"},
            wait_for_uploaded=True,
        )

        assert result == {"import_job_id": "ij-mv-gcs", "status": "importing"}
        mock_warning.assert_called()

    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_import_job(self, mock_make_request, client):
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "job_id": "ij_meta",
            "total": 100,
        }
        mock_make_request.return_value = mock_response

        result = client.video.get_import_job("ij_meta")

        assert result["job_id"] == "ij_meta"
        assert result["total"] == 100
        call_args = mock_make_request.call_args
        assert call_args.args == ("GET", "/api/import-jobs/ij_meta")

    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_import_job_videos(self, mock_make_request, client):
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "import_job_id": "ij_vids",
            "videos": [
                {"video_id": "v1", "status": "UPLOADED", "import_source_uri": "s3://bucket/a.mp4"},
                {"video_id": "v2", "status": "PROCESSING", "import_source_uri": "s3://bucket/b.mp4"},
            ],
            "video_count": 2,
            "has_more": True,
            "next_cursor": "v2",
        }
        mock_make_request.return_value = mock_response

        result = client.video.get_import_job_videos("ij_vids", limit=2, cursor="v0")

        assert result["import_job_id"] == "ij_vids"
        assert result["videos"][0]["video_id"] == "v1"
        assert result["next_cursor"] == "v2"
        call_args = mock_make_request.call_args
        assert call_args.args == ("GET", "/api/import-jobs/ij_vids/videos")
        assert call_args.kwargs["params"] == {"limit": 2, "cursor": "v0"}

    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_import_job_uploaded_video_ids_alias(self, mock_make_request, client):
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "import_job_id": "ij_alias",
            "videos": [{"video_id": "v1", "status": "UPLOADED", "import_source_uri": "s3://bucket/a.mp4"}],
            "video_count": 1,
            "has_more": False,
            "next_cursor": None,
        }
        mock_make_request.return_value = mock_response

        result = client.video.get_import_job_uploaded_video_ids("ij_alias", limit=1)

        assert result["import_job_id"] == "ij_alias"
        assert result["video_count"] == 1

    def test_upload_cannot_mix_cloud_providers(self, client):
        with pytest.raises(ValidationError):
            client.video.upload([
                "gs://fleet/a.mp4",
                "s3://archive/b.mp4",
            ], integration_id="int1")

    def test_upload_conflicting_integration_ids(self, client):
        with pytest.raises(ValidationError):
            client.video.upload(
                "gs://fleet/a.mp4",
                integration_id="one",
                gcs_integration_id="two",
                wait_for_uploaded=False,
            )

    # Override the actual validate_file_path in the module namespace
    @patch("nomadicml.video.validate_file_path")
    @patch("nomadicml.video.VideoClient.get_user_id")
    @patch("nomadicml.utils.get_filename_from_path")
    @patch("nomadicml.utils.get_file_mime_type")
    @patch("builtins.open", new_callable=mock_open, read_data=b"fake video data")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_video_file_success(self, mock_make_request, mock_open_file,
                                   mock_get_mime_type, mock_get_filename,
                                   mock_get_user_id, mock_validate_path, client):
        """Test successful video file upload."""
        # Setup mocks
        mock_validate_path.return_value = None  # Just ensure it doesn't raise an exception
        mock_get_filename.return_value = "test_video.mp4"
        mock_get_mime_type.return_value = "video/mp4"
        mock_get_user_id.return_value = "test_user"
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success", "video_id": "test_video_id"}
        mock_make_request.return_value = mock_response
        
        # Call the method
        result = client.video._upload_video(file_path="/path/to/test_video.mp4")
        
        # Assertions
        assert result == {"status": "success", "video_id": "test_video_id"}
        mock_validate_path.assert_called_once_with("/path/to/test_video.mp4")
        mock_make_request.assert_called_once()

        # Verify SDK headers were included
        call_args = mock_make_request.call_args
        # Headers should be passed through kwargs or in the actual request call
        called_kwargs = call_args.kwargs
        assert called_kwargs["data"]["scope"] == "user"

    @patch("nomadicml.video.validate_file_path")
    @patch("nomadicml.video.VideoClient.get_user_id")
    @patch("nomadicml.utils.get_filename_from_path")
    @patch("nomadicml.utils.get_file_mime_type")
    @patch("builtins.open", new_callable=mock_open, read_data=b"fake video data")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_video_file_with_org_scope(self, mock_make_request, mock_open_file,
                                         mock_get_mime_type, mock_get_filename,
                                         mock_get_user_id, mock_validate_path, client):
        mock_validate_path.return_value = None
        mock_get_filename.return_value = "test_video.mp4"
        mock_get_mime_type.return_value = "video/mp4"
        mock_get_user_id.return_value = "test_user"

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success", "video_id": "test_video_id"}
        mock_make_request.return_value = mock_response

        client.video._upload_video(
            file_path="/path/to/test_video.mp4",
            folder="Marketing",
            scope="org",
        )

        called_kwargs = mock_make_request.call_args.kwargs
        assert called_kwargs["data"]["scope"] == "org"

    @patch("nomadicml.video.get_file_mime_type")
    @patch("builtins.open", new_callable=mock_open, read_data=b"fake video data")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_video_with_custom_name_internal(self, mock_make_request, mock_open_file,
                                                    mock_get_mime_type, client):
        """Test that custom name is used as filename in multipart upload (internal method)."""
        mock_get_mime_type.return_value = "video/mp4"

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success", "video_id": "test_video_id"}
        mock_make_request.return_value = mock_response

        client.video._upload_video(
            file_path="/path/to/original_video.mp4",
            name="Custom Name.mp4",
        )

        # Verify the custom name was used in the multipart upload
        call_kwargs = mock_make_request.call_args.kwargs
        filename_in_upload = call_kwargs["files"]["file"][0]
        assert filename_in_upload == "Custom Name.mp4"

    @patch("nomadicml.video.get_file_mime_type")
    @patch("builtins.open", new_callable=mock_open, read_data=b"fake video data")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_with_custom_name_public_api(self, mock_make_request, mock_open_file,
                                                mock_get_mime_type, client):
        """Test that custom name flows through the public upload() method."""
        mock_get_mime_type.return_value = "video/mp4"

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success", "video_id": "vid_123"}
        mock_make_request.return_value = mock_response

        # Call the public upload() method with name parameter
        result = client.video.upload(
            "/path/to/my_video.mp4",
            name="Fleet Vehicle 42.mp4",
            wait_for_uploaded=False,  # Skip waiting to simplify test
        )

        # Verify the custom name was passed through to the HTTP request
        call_kwargs = mock_make_request.call_args.kwargs
        filename_in_upload = call_kwargs["files"]["file"][0]
        assert filename_in_upload == "Fleet Vehicle 42.mp4"
        assert result["video_id"] == "vid_123"

    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_url_with_custom_name(self, mock_make_request, client):
        """Test that custom name is passed as custom_name form field for URL uploads."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success", "video_id": "test_video_id"}
        mock_make_request.return_value = mock_response

        client.video._upload_video(
            file_path="https://example.com/video.mp4",
            name="custom_name.mp4",
        )

        call_kwargs = mock_make_request.call_args.kwargs
        assert call_kwargs["data"]["custom_name"] == "custom_name.mp4"
        assert call_kwargs["data"]["video_url"] == "https://example.com/video.mp4"

    def test_upload_name_rejected_for_batch(self, client):
        """Test that top-level name parameter is rejected for batch uploads."""
        with pytest.raises(ValidationError, match="name parameter is not supported for batch uploads"):
            client.video.upload(
                ["video1.mp4", "video2.mp4"],
                name="custom_name.mp4",
            )

    @patch("nomadicml.video.get_file_mime_type")
    @patch("builtins.open", new_callable=mock_open, read_data=b"fake video data")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_upload_batch_with_dict_names(self, mock_make_request, mock_open_file,
                                          mock_get_mime_type, client):
        """Test that dict syntax allows per-video names in batch uploads."""
        mock_get_mime_type.return_value = "video/mp4"
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success", "video_id": "vid_123"}
        mock_make_request.return_value = mock_response

        client.video.upload(
            [
                {"video": "/path/video1.mp4", "name": "scene_1.mp4"},
                {"video": "/path/video2.mp4", "name": "scene_2.mp4"},
            ],
            wait_for_uploaded=False,
        )

        # Should have made 2 upload requests
        assert mock_make_request.call_count == 2

        # Check that custom names were used
        calls = mock_make_request.call_args_list
        filenames = [call.kwargs["files"]["file"][0] for call in calls]
        assert "scene_1.mp4" in filenames
        assert "scene_2.mp4" in filenames

    def test_upload_name_rejected_for_cloud_imports(self, client):
        """Test that name parameter is rejected for cloud imports."""
        class DummyHelper:
            def list(self, *, type=None):
                return [{"id": "int123", "bucket_name": "fleet"}]

        client.__dict__["cloud_integrations"] = DummyHelper()
        with pytest.raises(ValidationError, match="name parameter is not supported for cloud imports"):
            client.video.upload(
                "gs://fleet/video.mp4",
                name="custom_name.mp4",
            )

    @patch("nomadicml.client.requests.request")
    def test_sdk_headers_included(self, mock_request, client):
        """Test that SDK identification headers are included in requests."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success"}
        mock_request.return_value = mock_response
        
        # Make a request
        client._make_request("GET", "/test")
        
        # Verify headers were included
        call_args = mock_request.call_args
        headers = call_args[1]["headers"]
        assert headers["X-Client-Type"] == "SDK"
        assert "X-Client-Version" in headers
        assert "NomadicML-Python-SDK" in headers["User-Agent"]

    @patch("nomadicml.client.NomadicML._make_request")
    def test_analyze_video_success(self, mock_make_request, client):
        """Test successful video analysis."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success", "analysis_id": "test_analysis_id"}
        mock_make_request.return_value = mock_response
        
        # Call the method
        result = client.video.analyze_video("test_video_id")
        
        # Assertions
        assert result == {"status": "success", "analysis_id": "test_analysis_id"}
        mock_make_request.assert_called_once_with(
            method="POST",
            endpoint="/api/analyze-video/test_video_id",
            data={
                "firebase_collection_name": client.collection_name,
                "model_id": "Nomadic-VL-XLarge",
            },
        )

    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_video_status_success(self, mock_make_request, client):
        """Test successful video status retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "completed", "progress": 100}
        mock_make_request.return_value = mock_response
        
        # Call the method
        result = client.video.get_video_status("test_video_id")
        
        # Assertions
        assert result == {"status": "completed", "progress": 100}
        mock_make_request.assert_called_once_with(
            "GET",
            "/api/video/test_video_id/status",
            params={"firebase_collection_name": client.collection_name}
        )

    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_video_analysis_success(self, mock_make_request, client):
        """Test successful video analysis retrieval.""" 
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"events": [], "summary": "No events detected"}
        mock_make_request.return_value = mock_response
        
        # Call the method
        result = client.video.get_video_analysis("test_video_id")
        
        # Assertions
        assert result == {"events": [], "summary": "No events detected"}
        mock_make_request.assert_called_once_with(
            "GET",
            "/api/video/test_video_id/analysis",
            params={"firebase_collection_name": client.collection_name}
        )

    @patch("nomadicml.client.NomadicML._make_request")
    def test_delete_video_success(self, mock_make_request, client):
        """Test successful video deletion."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "deleted"}
        mock_make_request.return_value = mock_response
        
        # Call the method
        result = client.video.delete_video("test_video_id")
        
        # Assertions
        assert result == {"status": "deleted"}
        mock_make_request.assert_called_once_with(
            "DELETE",
            "/api/video/test_video_id",
            params={"firebase_collection_name": client.collection_name}
        )

    @patch("nomadicml.client.NomadicML._make_request")
    def test_my_videos_success(self, mock_make_request, client):
        """Test successful video list retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = [{"video_id": "test_video_1"}, {"video_id": "test_video_2"}]
        mock_make_request.return_value = mock_response

        # Call the method
        result = client.video.my_videos()

        # Assertions
        assert result == [{"video_id": "test_video_1"}, {"video_id": "test_video_2"}]
        mock_make_request.assert_called_once_with(
            "GET",
            "/api/videos",
            params={"firebase_collection_name": client.collection_name}
        )

    @patch("nomadicml.video.VideoClient._submit_batch")
    def test_analyze_many_returns_batch_links_on_start(self, mock_submit, client):
        mock_submit.return_value = {"batch_id": "batch123"}

        response = client.video._analyze_many(
            ["vid1", "vid2"],
            analysis_type=AnalysisType.ASK,
            model_id="Nomadic-VL-XLarge",
            timeout=30,
            wait_for_completion=False,
            search_query=None,
            custom_event="Did the driver stop?",
            custom_category=CustomCategory.DRIVING,
            concept_ids=None,
            return_subset=False,
            is_thumbnail=False,
            use_enhanced_motion_analysis=False,
        )

        assert set(response.keys()) == {"batch_metadata", "results"}
        metadata = response["batch_metadata"]
        assert metadata["batch_id"] == "batch123"
        assert metadata["batch_viewer_url"].endswith("/use-cases/rapid-review/batch-view/batch123")
        assert metadata["batch_viewer_url"].startswith("http")
        assert metadata["batch_type"] == "ask"

        results = response["results"]
        assert len(results) == 2
        for entry in results:
            assert entry["video_id"] in {"vid1", "vid2"}
            assert entry["analysis_id"] is None
            assert entry["mode"] == "rapid_review"
            assert entry["status"] == "started"
        mock_submit.assert_called_once()

    @patch("nomadicml.video.VideoClient._extract_summary", side_effect=["summary-one", "summary-two"])
    @patch("nomadicml.video.VideoClient._parse_api_events", side_effect=[[{"id": 1}], [{"id": 2}]])
    @patch("nomadicml.video.VideoClient.get_video_analysis")
    @patch("nomadicml.video.VideoClient._poll_batch_status")
    @patch("nomadicml.video.VideoClient._submit_batch")
    def test_analyze_many_waits_for_completion(
        self,
        mock_submit,
        mock_poll,
        mock_get_analysis,
        mock_parse,
        mock_summary,
        client,
    ):
        mock_submit.return_value = {"batch_id": "batchXYZ"}
        mock_poll.return_value = {
            "status": "completed",
            "aggregated_progress": {"total": 2, "completed": 2},
            "videos": [
                {"video_id": "vid1", "status": "completed", "analysis_id": "analysis-1"},
                {"video_id": "vid2", "status": "completed", "analysis_id": "analysis-2"},
            ],
        }
        mock_get_analysis.side_effect = [
            {
                "analysis": {"analysis_id": "analysis-1", "status": "COMPLETED"},
                "metadata": {"visual_analysis": {"status": {"status": "COMPLETED"}}},
            },
            {
                "analysis": {"analysis_id": "analysis-2", "status": "COMPLETED"},
                "metadata": {"visual_analysis": {"status": {"status": "COMPLETED"}}},
            },
        ]

        response = client.video._analyze_many(
            ["vid1", "vid2"],
            analysis_type=AnalysisType.ASK,
            model_id="Nomadic-VL-XLarge",
            timeout=30,
            wait_for_completion=True,
            search_query=None,
            custom_event="Check intersections",
            custom_category=CustomCategory.DRIVING,
            concept_ids=None,
            return_subset=False,
            is_thumbnail=False,
            use_enhanced_motion_analysis=False,
        )

        assert set(response.keys()) == {"batch_metadata", "results"}
        metadata = response["batch_metadata"]
        assert metadata["batch_id"] == "batchXYZ"
        assert metadata["batch_viewer_url"].endswith("/use-cases/rapid-review/batch-view/batchXYZ")
        assert metadata["batch_viewer_url"].startswith("http")
        assert metadata["batch_type"] == "ask"

        results = response["results"]
        assert [entry["analysis_id"] for entry in results] == ["analysis-1", "analysis-2"]
        assert all(entry["mode"] == "rapid_review" for entry in results)
        assert all(entry["status"] == "completed" for entry in results)
        assert results[0]["events"] == [{"id": 1}]
        assert results[1]["events"] == [{"id": 2}]
        assert results[0]["summary"] == "summary-one"
        assert results[1]["summary"] == "summary-two"
        mock_submit.assert_called_once()
        mock_poll.assert_called_once()
        assert mock_get_analysis.call_count == 2
        assert mock_parse.call_count == 2

    @patch("nomadicml.video.VideoClient.get_video_analysis")
    @patch("nomadicml.video.VideoClient._poll_batch_status")
    @patch("nomadicml.video.VideoClient._submit_batch")
    def test_analyze_many_missing_pointer_failure(
        self,
        mock_submit,
        mock_poll,
        mock_get_analysis,
        client,
    ):
        mock_submit.return_value = {"batch_id": "batchNoPtr"}
        mock_poll.return_value = {
            "status": "completed",
            "videos": [
                {"video_id": "vid-missing", "status": "completed"},
            ],
        }

        response = client.video._analyze_many(
            ["vid-missing"],
            analysis_type=AnalysisType.ASK,
            model_id="Nomadic-VL-XLarge",
            timeout=30,
            wait_for_completion=True,
            search_query=None,
            custom_event="Check intersections",
            custom_category=CustomCategory.DRIVING,
            concept_ids=None,
            return_subset=False,
            is_thumbnail=False,
            use_enhanced_motion_analysis=False,
        )

        result = response["results"][0]
        assert result["video_id"] == "vid-missing"
        assert result["status"] == "failed"
        assert result["analysis_id"] is None
        assert "analysis pointer" in result["error"]
        mock_get_analysis.assert_not_called()

    @patch("nomadicml.video.VideoClient._parse_api_events")
    @patch("nomadicml.video.VideoClient._fetch_batch_analyses_bulk")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_batch_analysis_filter_skips_empty_results_by_default(
        self,
        mock_make_request,
        mock_fetch_batch_analyses_bulk,
        mock_parse_api_events,
        client,
    ):
        status_response = MagicMock()
        status_response.json.return_value = {
            "status": "completed",
            "videos": [
                {"video_id": "vid1", "analysis_id": "analysis-1", "status": "completed"},
                {"video_id": "vid2", "analysis_id": "analysis-2", "status": "completed"},
            ],
            "config": {"analysis_kind": "rapid_review", "prompt": "test prompt", "category": "driving"},
        }
        mock_make_request.return_value = status_response
        mock_fetch_batch_analyses_bulk.return_value = {
            "vid1": {"analysis_id": "analysis-1", "analysis": {"status": "completed"}},
            "vid2": {"analysis_id": "analysis-2", "analysis": {"status": "completed"}},
        }
        mock_parse_api_events.side_effect = [
            [{"approval": "approved", "label": "approved-event", "t_start": "00:01", "t_end": "00:02"}],
            [{"approval": "pending", "label": "pending-event", "t_start": "00:03", "t_end": "00:04"}],
        ]

        response = client.video.get_batch_analysis("batch-123", filter="approved")

        assert len(response["results"]) == 1
        assert response["results"][0]["video_id"] == "vid1"
        assert response["results"][0]["events"][0]["approval"] == "approved"
        mock_fetch_batch_analyses_bulk.assert_called_once_with("batch-123", ["vid1", "vid2"], include_source_uri=True)

    @patch("nomadicml.video.VideoClient._parse_api_events")
    @patch("nomadicml.video.VideoClient._fetch_batch_analyses_bulk")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_batch_analysis_without_filter_keeps_empty_results(
        self,
        mock_make_request,
        mock_fetch_batch_analyses_bulk,
        mock_parse_api_events,
        client,
    ):
        status_response = MagicMock()
        status_response.json.return_value = {
            "status": "completed",
            "videos": [
                {"video_id": "vid1", "analysis_id": "analysis-1", "status": "completed"},
                {"video_id": "vid2", "analysis_id": "analysis-2", "status": "completed"},
            ],
            "config": {"analysis_kind": "rapid_review"},
        }
        mock_make_request.return_value = status_response
        mock_fetch_batch_analyses_bulk.return_value = {
            "vid1": {"analysis_id": "analysis-1", "analysis": {"status": "completed"}},
            "vid2": {"analysis_id": "analysis-2", "analysis": {"status": "completed"}},
        }
        mock_parse_api_events.side_effect = [
            [{"approval": "approved", "label": "approved-event", "t_start": "00:01", "t_end": "00:02"}],
            [],
        ]

        response = client.video.get_batch_analysis("batch-123")

        assert len(response["results"]) == 2
        assert response["results"][0]["video_id"] == "vid1"
        assert response["results"][0]["events"][0]["approval"] == "approved"
        assert response["results"][1]["video_id"] == "vid2"
        assert response["results"][1]["events"] == []

    @patch("nomadicml.video.VideoClient._fetch_batch_analyses_bulk")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_batch_analysis_agent_uses_detected_events_fallback(
        self,
        mock_make_request,
        mock_fetch_batch_analyses_bulk,
        client,
    ):
        status_response = MagicMock()
        status_response.json.return_value = {
            "status": "completed",
            "videos": [
                {"video_id": "vid1", "analysis_id": "analysis-1", "status": "completed"},
            ],
            "config": {"analysis_kind": "edge_agent"},
        }
        mock_make_request.return_value = status_response
        mock_fetch_batch_analyses_bulk.return_value = {
            "vid1": {
                "analysis_id": "analysis-1",
                "analysis": {
                    "status": "completed",
                    "events": [],
                    "detected_events": [
                        {
                            "t_start": "00:01",
                            "t_end": "00:02",
                            "category": "lane_change",
                            "label": "lane change",
                            "approval": "approved",
                        }
                    ],
                },
            },
        }

        response = client.video.get_batch_analysis("batch-123")

        assert len(response["results"]) == 1
        assert len(response["results"][0]["events"]) == 1
        assert response["results"][0]["events"][0]["label"] == "lane change"

    @patch("nomadicml.video.VideoClient._fetch_batch_analyses_bulk")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_batch_analysis_ask_adds_overlay_unix_timestamp_and_keeps_time_keys(
        self,
        mock_make_request,
        mock_fetch_batch_analyses_bulk,
        client,
    ):
        status_response = MagicMock()
        status_response.json.return_value = {
            "status": "completed",
            "videos": [
                {"video_id": "vid1", "analysis_id": "analysis-1", "status": "completed"},
            ],
            "config": {"analysis_kind": "rapid_review", "prompt": "test prompt", "category": "driving"},
        }
        mock_make_request.return_value = status_response
        mock_fetch_batch_analyses_bulk.return_value = {
            "vid1": {
                "analysis_id": "analysis-1",
                "analysis": {
                    "status": "completed",
                    "events": [
                        {
                            "type": "lane_change",
                            "time": "t=1.00",
                            "end_time": "t=2.00",
                            "description": "lane change",
                            "severity": "medium",
                            "aiAnalysis": "Detected lane change",
                            "approval": "approved",
                            "frame_timestamp_start": "2025-09-19 19:22:42.000 UTC",
                            "frame_timestamp_end": "2025-09-19 19:22:44.000 UTC",
                            "unix_timestamp_start": 1758310.0,
                            "unix_timestamp_end": 1758312.0,
                        }
                    ],
                },
            },
        }

        response = client.video.get_batch_analysis("batch-123")

        event = response["results"][0]["events"][0]
        assert event["t_start"] == "00:01"
        assert event["t_end"] == "00:02"
        assert "start_time" not in event
        assert "end_time" not in event
        assert "unix_timestamp_start" not in event
        assert "unix_timestamp_end" not in event
        assert event["overlay"]["frame_timestamp"] == {
            "start": "2025-09-19 19:22:42.000 UTC",
            "end": "2025-09-19 19:22:44.000 UTC",
        }
        assert event["overlay"]["unix_timestamp"] == {
            "start": 1758310.0,
            "end": 1758312.0,
        }

    @patch("nomadicml.video.VideoClient._fetch_batch_analyses_bulk")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_batch_analysis_agent_ui_events_convert_only_for_batch_path(
        self,
        mock_make_request,
        mock_fetch_batch_analyses_bulk,
        client,
    ):
        status_response = MagicMock()
        status_response.json.return_value = {
            "status": "completed",
            "videos": [
                {"video_id": "vid1", "analysis_id": "analysis-1", "status": "completed"},
            ],
            "config": {"analysis_kind": "edge_agent"},
        }
        mock_make_request.return_value = status_response
        mock_fetch_batch_analyses_bulk.return_value = {
            "vid1": {
                "analysis_id": "analysis-1",
                "analysis": {
                    "status": "completed",
                    "events": [
                        {
                            "type": "obstruction",
                            "time": "t=12.00",
                            "end_time": "t=15.00",
                            "description": "Dashboard obstruction",
                            "severity": "high",
                            "aiAnalysis": "Object blocks the lower view",
                            "approval": "approved",
                            "frame_timestamp_start": "2025-09-19 19:22:42.000 UTC",
                            "frame_timestamp_end": "2025-09-19 19:22:45.000 UTC",
                            "unix_timestamp_start": 1758310.0,
                            "unix_timestamp_end": 1758313.0,
                        }
                    ],
                },
            },
        }

        response = client.video.get_batch_analysis("batch-123")

        event = response["results"][0]["events"][0]
        assert event["t_start"] == "00:12"
        assert event["t_end"] == "00:15"
        assert "start_time" not in event
        assert "end_time" not in event
        assert "unix_timestamp_start" not in event
        assert "unix_timestamp_end" not in event
        assert event["overlay"]["unix_timestamp"] == {
            "start": 1758310.0,
            "end": 1758313.0,
        }

    @patch("nomadicml.video.VideoClient._parse_api_events")
    @patch("nomadicml.video.VideoClient._fetch_batch_analyses_bulk")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_batch_analysis_as_csv_is_event_only(
        self,
        mock_make_request,
        mock_fetch_batch_analyses_bulk,
        mock_parse_api_events,
        client,
    ):
        status_response = MagicMock()
        status_response.json.return_value = {
            "status": "completed",
            "videos": [
                {"video_id": "vid1", "analysis_id": "analysis-1", "status": "completed"},
                {"video_id": "vid2", "analysis_id": "analysis-2", "status": "completed"},
            ],
            "config": {"analysis_kind": "rapid_review"},
        }
        mock_make_request.return_value = status_response
        mock_fetch_batch_analyses_bulk.return_value = {
            "vid1": {"analysis_id": "analysis-1", "analysis": {"status": "completed"}, "import_source_uri": "s3://bucket/a.mp4"},
            "vid2": {"analysis_id": "analysis-2", "analysis": {"status": "completed"}, "import_source_uri": "s3://bucket/b.mp4"},
        }
        mock_parse_api_events.side_effect = [
            [{"approval": "approved", "label": "approved-event", "t_start": "00:01", "t_end": "00:02"}],
            [],
        ]

        csv_text = client.video.get_batch_analysis("batch-123", as_csv=True)

        assert isinstance(csv_text, str)
        rows = list(csv.DictReader(StringIO(csv_text)))
        assert len(rows) == 1
        assert rows[0]["Video ID"] == "vid1"
        assert rows[0]["Analysis ID"] == "analysis-1"
        assert rows[0]["Approval Status"] == "approved"

    @patch("nomadicml.video.VideoClient._parse_api_events")
    @patch("nomadicml.video.VideoClient._fetch_batch_analyses_bulk")
    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_batch_analysis_as_csv_respects_filter(
        self,
        mock_make_request,
        mock_fetch_batch_analyses_bulk,
        mock_parse_api_events,
        client,
    ):
        status_response = MagicMock()
        status_response.json.return_value = {
            "status": "completed",
            "videos": [
                {"video_id": "vid1", "analysis_id": "analysis-1", "status": "completed"},
            ],
            "config": {"analysis_kind": "rapid_review"},
        }
        mock_make_request.return_value = status_response
        mock_fetch_batch_analyses_bulk.return_value = {
            "vid1": {"analysis_id": "analysis-1", "analysis": {"status": "completed"}},
        }
        mock_parse_api_events.return_value = [
            {"approval": "approved", "label": "approved-event", "t_start": "00:01", "t_end": "00:02"},
            {"approval": "rejected", "label": "rejected-event", "t_start": "00:03", "t_end": "00:04"},
        ]

        csv_text = client.video.get_batch_analysis("batch-123", filter="approved", as_csv=True)

        rows = list(csv.DictReader(StringIO(csv_text)))
        assert len(rows) == 1
        assert rows[0]["Approval Status"] == "approved"

    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_batch_analysis_as_csv_empty_batch_returns_csv_string(
        self,
        mock_make_request,
        client,
    ):
        status_response = MagicMock()
        status_response.json.return_value = {
            "status": "completed",
            "videos": [],
            "config": {"analysis_kind": "rapid_review"},
        }
        mock_make_request.return_value = status_response

        csv_text = client.video.get_batch_analysis("batch-empty", as_csv=True)

        assert isinstance(csv_text, str)
        rows = list(csv.DictReader(StringIO(csv_text)))
        assert rows == []
        assert csv_text.splitlines()[0].startswith("Query,Video Name,Approval Status,Timestamp")

    def test_parse_api_events_general_agent_keeps_legacy_shape(self, client):
        payload = {
            "analysis": {
                "events": [
                    {
                        "type": "obstruction",
                        "time": "t=12.00",
                        "end_time": "t=15.00",
                        "description": "Dashboard obstruction",
                    }
                ]
            }
        }

        events = client.video._parse_api_events(payload, analysis_type=AnalysisType.GENERAL_AGENT)

        assert events == [
            {
                "label": "Dashboard obstruction",
                "start_time": 12.0,
                "end_time": 15.0,
            }
        ]

    def test_batch_results_to_csv_matches_web_field_fallbacks(self, client):
        payload = {
            "batch_metadata": {
                "batch_id": "batch-123",
                "batch_viewer_url": "https://example.com/batch/123",
            },
            "results": [
                {
                    "video_id": "vid1",
                    "analysis_id": "analysis-1",
                    "status": "completed",
                    "events": [
                        {
                            "time": "t=12.00",
                            "end_time": "t=15.00",
                            "type": "lane_change",
                            "description": "lane_change",
                            "aiAnalysis": "From 05:00 to 05:01, a silver SUV is observed parked and stationary.",
                        }
                    ],
                }
            ],
        }

        csv_text = client.video._batch_results_to_csv(payload)
        rows = list(csv.DictReader(StringIO(csv_text)))

        assert len(rows) == 1
        assert rows[0]["Approval Status"] == "pending"
        assert rows[0]["Timestamp"] == "t=12.00-t=15.00"
        assert rows[0]["Category"] == "lane_change"
        assert rows[0]["Label"] == ""
        assert rows[0]["AI Analysis"].startswith("From 05:00 to 05:01")

    def test_batch_results_to_csv_prefers_overlay_unix_timestamp(self, client):
        payload = {
            "batch_metadata": {
                "batch_id": "batch-123",
                "batch_viewer_url": "https://example.com/batch/123",
            },
            "results": [
                {
                    "video_id": "vid1",
                    "analysis_id": "analysis-1",
                    "status": "completed",
                    "events": [
                        {
                            "t_start": "00:01",
                            "t_end": "00:02",
                            "category": "lane_change",
                            "label": "lane change",
                            "unix_timestamp_start": 10.0,
                            "unix_timestamp_end": 20.0,
                            "overlay": {
                                "unix_timestamp": {"start": 30.0, "end": 40.0},
                            },
                        }
                    ],
                }
            ],
        }

        csv_text = client.video._batch_results_to_csv(payload)
        rows = list(csv.DictReader(StringIO(csv_text)))

        assert len(rows) == 1
        assert rows[0]["Timestamp"] == "00:01-00:02"
        assert rows[0]["unix_timestamp_start"] == "30.0"
        assert rows[0]["unix_timestamp_end"] == "40.0"

    def test_batch_results_to_csv_does_not_fallback_to_frame_timestamp_strings(self, client):
        payload = {
            "batch_metadata": {
                "batch_id": "batch-123",
                "batch_viewer_url": "https://example.com/batch/123",
            },
            "results": [
                {
                    "video_id": "vid1",
                    "analysis_id": "analysis-1",
                    "status": "completed",
                    "events": [
                        {
                            "t_start": "00:50",
                            "t_end": "00:55",
                            "category": "Driving",
                            "label": "Traffic Signal Over Roadway",
                            "overlay": {
                                "frame_timestamp": {
                                    "start": "2025-09-23 21:24:400 UTC",
                                    "end": "2025-09-23 21:31:400 UTC",
                                }
                            },
                        }
                    ],
                }
            ],
        }

        csv_text = client.video._batch_results_to_csv(payload)
        rows = list(csv.DictReader(StringIO(csv_text)))

        assert len(rows) == 1
        assert rows[0]["Timestamp"] == "00:50-00:55"
        assert rows[0]["unix_timestamp_start"] == ""
        assert rows[0]["unix_timestamp_end"] == ""

    def test_batch_results_to_csv_matches_json_overlay_unix_timestamp_contract(self, client):
        payload = {
            "batch_metadata": {
                "batch_id": "batch-123",
                "batch_viewer_url": "https://example.com/batch/123",
            },
            "results": [
                {
                    "video_id": "vid1",
                    "analysis_id": "analysis-1",
                    "status": "completed",
                    "events": [
                        {
                            "t_start": "00:01",
                            "t_end": "00:02",
                            "category": "lane_change",
                            "label": "lane change",
                            "overlay": {
                                "frame_timestamp": {
                                    "start": "2025-09-19 19:22:42.000 UTC",
                                    "end": "2025-09-19 19:22:44.000 UTC",
                                },
                                "unix_timestamp": {"start": 1758309762.0, "end": 1758309764.0},
                            },
                        },
                        {
                            "t_start": "00:50",
                            "t_end": "00:55",
                            "category": "Driving",
                            "label": "Traffic Signal Over Roadway",
                            "overlay": {
                                "frame_timestamp": {
                                    "start": "2025-09-23 21:24:400 UTC",
                                    "end": "2025-09-23 21:31:400 UTC",
                                }
                            },
                        },
                    ],
                }
            ],
        }

        json_events = payload["results"][0]["events"]
        csv_text = client.video._batch_results_to_csv(payload)
        rows = list(csv.DictReader(StringIO(csv_text)))

        assert len(rows) == len(json_events) == 2

        assert json_events[0]["overlay"]["unix_timestamp"] == {
            "start": 1758309762.0,
            "end": 1758309764.0,
        }
        assert rows[0]["unix_timestamp_start"] == "1758309762.0"
        assert rows[0]["unix_timestamp_end"] == "1758309764.0"

        assert "unix_timestamp" not in json_events[1]["overlay"]
        assert rows[1]["unix_timestamp_start"] == ""
        assert rows[1]["unix_timestamp_end"] == ""

    def test_get_api_events_ignores_non_dict_nested_payloads(self, client):
        analysis_payload = {
            "analysis": {
                "events": [],
                "detected_events": [{"label": "lane change", "t_start": "00:01", "t_end": "00:02"}],
                "result": ["unexpected-list"],
                "visual_analysis": "unexpected-string",
            }
        }

        events = client.video._get_api_events(analysis_payload, analysis_type=AnalysisType.GENERAL_AGENT)

        assert isinstance(events, list)
        assert len(events) == 1
        assert events[0]["label"] == "lane change"

    def test_batch_results_to_csv_preserves_zero_start_time(self, client):
        payload = {
            "batch_metadata": {"batch_id": "batch-123", "batch_viewer_url": "https://example.com/batch/123"},
            "results": [
                {
                    "video_id": "vid1",
                    "analysis_id": "analysis-1",
                    "status": "completed",
                    "events": [
                        {
                            "start_time": 0.0,
                            "end_time": 5.0,
                            "type": "hard_brake",
                            "description": "hard brake",
                        }
                    ],
                }
            ],
        }

        csv_text = client.video._batch_results_to_csv(payload)
        rows = list(csv.DictReader(StringIO(csv_text)))

        assert len(rows) == 1
        assert rows[0]["Timestamp"] == "0.0-5.0"

    def test_wait_for_analysis_timeout(self, client):
        """Test that wait_for_analysis raises TimeoutError when analysis doesn't complete."""
        with patch.object(client.video, 'get_video_status') as mock_get_status:
            mock_get_status.return_value = {"status": "processing"}
            
            with pytest.raises(TimeoutError):
                client.video.wait_for_analysis("test_video_id", timeout=1, poll_interval=0.1)

    @patch("nomadicml.video.VideoClient.get_video_status")
    def test_wait_for_analysis_success(self, mock_get_status, client):
        """Test successful wait_for_analysis."""
        # First call returns processing, second call returns completed
        mock_get_status.side_effect = [
            {"status": "processing"},
            {"status": "completed", "analysis": {"events": []}}
        ]
        
        result = client.video.wait_for_analysis("test_video_id", timeout=10, poll_interval=0.1)
        
        assert result["status"] == "completed"
        assert mock_get_status.call_count == 2

    @patch("nomadicml.client.NomadicML._make_request")
    def test_create_or_get_folder_success(self, mock_make_request, client):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"id": "folder1", "name": "Marketing", "scope": "org"}
        mock_make_request.return_value = mock_response

        data = client.video.create_or_get_folder("Marketing", scope="org")

        assert data == {"id": "folder1", "name": "Marketing", "scope": "org"}
        mock_make_request.assert_called_once_with(
            method="POST",
            endpoint="/api/folders/create-or-get",
            json_data={"name": "Marketing", "scope": "org"},
        )

    @patch("nomadicml.client.NomadicML._make_request")
    def test_create_folder_success(self, mock_make_request, client):
        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {"id": "folder1", "name": "Marketing", "scope": "user"}
        mock_make_request.return_value = mock_response

        data = client.video.create_folder("Marketing")

        assert data == {"id": "folder1", "name": "Marketing", "scope": "user"}
        mock_make_request.assert_called_once_with(
            method="POST",
            endpoint="/api/folders",
            json_data={"name": "Marketing", "scope": "user"},
        )

    @patch("nomadicml.client.NomadicML._make_request")
    def test_get_folder_success_user(self, mock_make_request, client):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "folder1",
            "name": "Marketing",
            "org_id": None,
            "scope": "user",
            "description": "desc",
            "created_at": None,
            "created_by": "user1",
            "video_count": None,
        }
        mock_make_request.return_value = mock_response

        data = client.video.get_folder("Marketing")

        assert data["id"] == "folder1"
        assert data["name"] == "Marketing"
        assert data["scope"] == "user"
        mock_make_request.assert_called_once_with(
            method="GET",
            endpoint="/api/folders/get",
            params={"name": "Marketing", "scope": "user"},
        )

    def test_create_or_get_folder_invalid_scope(self, client):
        with pytest.raises(ValidationError):
            client.video.create_or_get_folder("Marketing", scope="invalid")

    def test_create_or_get_folder_empty_name(self, client):
        with pytest.raises(ValidationError):
            client.video.create_or_get_folder(" ")
