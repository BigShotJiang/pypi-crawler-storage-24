# ByteDance Volcengine EMR, Copyright 2024.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The module contains models for the tosfs package."""
from typing import Optional


class DeletingObject:
    """Object to be deleted."""

    def __init__(self, key: str, version_id: Optional[str] = None):
        """Initialize a DeletingObject for batch delete."""
        self.key = key
        self.version_id = version_id
