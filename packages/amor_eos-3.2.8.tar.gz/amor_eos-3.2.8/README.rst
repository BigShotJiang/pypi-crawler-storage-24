*************************************************************
EOS - The AMOR focusing reflectometry data reduction software
*************************************************************

.. image:: https://img.shields.io/pypi/v/amor-eos.svg
        :target: https://pypi.python.org/pypi/amor-eos/


Software repository for the neutron reflectometer Amor at the Paul Scherrer Institut, Switzerland

Reduction of the raw files (.hdf) to reflectivity files in one of the representations of the **ORSO reflectivity file format**:

  eos --help

visualisation of the content of a raw file (.hdf):

  events2histogram.py

:TODO: real readme for final system needed.

Installation
============

Python Environment
------------------

Create a [virtual python environment](https://docs.python.org/3/library/venv.html) (>3.8) and install the PyPI package:

  pip install amor-eos

Windows Binary
--------------

On Windows you can use the binary eos.exe that you find in the
[Gitea Releases](https://gitea.psi.ch/sinq-reflectometry/eos/releases/latest) section.

Either extract it to the folder where you analyze your data or choose a common location and make sure
that is in the system PATH to be able to run the program from command line.
