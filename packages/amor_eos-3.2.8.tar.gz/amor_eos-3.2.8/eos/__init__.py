"""
Package to handle data redction at AMOR instrument to be used by __main__.py script.
"""

__version__ = '3.2.8'
__date__    = '2026-03-18'
