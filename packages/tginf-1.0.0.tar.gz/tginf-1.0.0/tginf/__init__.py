"""
Telegram Info Module - Get information about Telegram users, groups, and channels

Usage as tool:
    >>> from tginp import TelegramInfoTool
    >>> tool = TelegramInfoTool()
    >>> profile, error = tool.get_profile("username")
    >>> print(profile.name)

Usage as bot:
    >>> from tginp import run_bot
    >>> run_bot(token="YOUR_BOT_TOKEN")

CLI usage:
    $ tginp username
    $ tginp --bot TOKEN
"""

from .core import TelegramInfoTool, TelegramProfile, ProfileType
from .bot import run_bot
from .cli import main as cli_main
from .config import __version__, __author__, __description__, __license__

__version__ = "1.0.0"
__author__ = "Aotpy"
__description__ = "Telegram Profile Information Tool"
__license__ = "MIT"

__all__ = [
    'TelegramInfoTool',
    'TelegramProfile', 
    'ProfileType',
    'run_bot',
    'cli_main'
]

def bot(token: str, api_base_url: str = "https://tobi-tg-api.vercel.app"):
    return run_bot(token=token, api_base_url=api_base_url)

def start():
    cli_main()