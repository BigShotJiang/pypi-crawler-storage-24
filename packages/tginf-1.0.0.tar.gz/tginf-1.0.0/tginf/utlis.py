import re
from typing import Optional

def validate_username(username: str) -> bool:
    if not username:
        return False
    
    username = username.lstrip('@')
    pattern = r'^[a-zA-Z0-9_]{5,32}$'
    return bool(re.match(pattern, username))

def extract_username(text: str) -> Optional[str]:
    match = re.search(r'@?([a-zA-Z0-9_]{5,32})\b', text)
    if match:
        return match.group(1)
    return None

def format_number(num: int) -> str:
    if num < 1000:
        return str(num)
    elif num < 1000000:
        return f"{num/1000:.1f}K"
    elif num < 1000000000:
        return f"{num/1000000:.1f}M"
    else:
        return f"{num/1000000000:.1f}B"