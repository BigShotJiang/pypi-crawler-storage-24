import telebot
import logging
from typing import Optional
import os
from dotenv import load_dotenv

from .core import TelegramInfoTool
from .config import DEVELOPER_INFO, BOT_COMMANDS

load_dotenv()

logger = logging.getLogger(__name__)

class TelegramInfoBot:
    def __init__(self, token: str, api_base_url: str = "https://tobi-tg-api.vercel.app"):
        self.token = token
        self.bot = telebot.TeleBot(token)
        self.tool = TelegramInfoTool(api_base_url=api_base_url)
        self.developer_info = DEVELOPER_INFO
        
        self._register_handlers()
    
    def _register_handlers(self):
        @self.bot.message_handler(commands=['start', 'help'])
        def start_command(message):
            welcome = f"""
🤖 **Telegram Info Bot**

Commands:
/info [username] - Get profile info
/id - Get current chat ID
/about - About this bot

Examples:
/info Aotpy
/info @telegram

━━━━━━━━━━━━━━━━━━━━━━━
👨‍💻 {self.developer_info['Developer']}
📢 {self.developer_info['Channel']}
            """
            self.bot.reply_to(message, welcome, parse_mode="Markdown")
        
        @self.bot.message_handler(commands=['about'])
        def about_command(message):
            about = f"""
ℹ️ **About This Bot**

**Telegram Info Bot v1.0.0**
{__import__('tginf').__description__}

**Features:**
• User/Group/Channel details
• Profile photos
• Member counts
• Chat IDs

**Developer:** {self.developer_info['Developer']}
**Channel:** {self.developer_info['Channel']}
**License:** MIT
            """
            self.bot.reply_to(message, about, parse_mode="Markdown")
        
        @self.bot.message_handler(commands=['id'])
        def id_command(message):
            chat_id = message.chat.id
            chat_type = message.chat.type
            self.bot.reply_to(
                message, 
                f"📌 **Chat Information**\n\nID: `{chat_id}`\nType: {chat_type}",
                parse_mode="Markdown"
            )
        
        @self.bot.message_handler(commands=['info'])
        def info_command(message):
            try:
                parts = message.text.split()
                
                if len(parts) < 2:
                    self.bot.reply_to(
                        message,
                        "❌ **Usage:** `/info [username]`\nExample: `/info Aotpy`",
                        parse_mode="Markdown"
                    )
                    return
                
                query = parts[1].strip()
                
                self.bot.send_chat_action(message.chat.id, 'upload_photo')
                
                processing = self.bot.reply_to(message, "⏳ Fetching information...")
                
                profile, error = self.tool.get_profile(query)
                
                if error:
                    self.bot.edit_message_text(
                        f"❌ {error}",
                        message.chat.id,
                        processing.message_id
                    )
                    return
                
                text = self.tool.format_profile_text(profile)
                
                if profile.photo_url:
                    photo = self.tool.download_photo(profile.photo_url)
                    if photo:
                        self.bot.delete_message(message.chat.id, processing.message_id)
                        photo.name = 'profile.jpg'
                        self.bot.send_photo(
                            message.chat.id,
                            photo,
                            caption=text,
                            parse_mode="Markdown"
                        )
                        return
                
                self.bot.edit_message_text(
                    text,
                    message.chat.id,
                    processing.message_id,
                    parse_mode="Markdown"
                )
                
            except Exception as e:
                logger.error(f"Error in info command: {e}")
                self.bot.reply_to(message, f"❌ Error: {str(e)}")
        
        @self.bot.message_handler(func=lambda m: True)
        def default_handler(message):
            if message.chat.type == 'private':
                self.bot.reply_to(
                    message,
                    "❌ Unknown command. Use /help for available commands.",
                    parse_mode="Markdown"
                )
    
    def run(self, polling: bool = True):
        logger.info(f"Starting bot with token: {self.token[:10]}...")
        
        self.bot.set_my_commands([
            telebot.types.BotCommand(cmd["command"], cmd["description"])
            for cmd in BOT_COMMANDS
        ])
        
        if polling:
            logger.info("Bot is running... Press Ctrl+C to stop")
            try:
                self.bot.infinity_polling()
            except KeyboardInterrupt:
                logger.info("Bot stopped by user")
            except Exception as e:
                logger.error(f"Bot error: {e}")

def run_bot(token: Optional[str] = None, api_base_url: str = "https://tobi-tg-api.vercel.app"):
    if token is None:
        token = os.getenv("BOT_TOKEN")
        if not token:
            print("❌ Error: No bot token provided!")
            print("Set BOT_TOKEN environment variable or pass token parameter")
            return
    
    bot = TelegramInfoBot(token, api_base_url)
    bot.run()