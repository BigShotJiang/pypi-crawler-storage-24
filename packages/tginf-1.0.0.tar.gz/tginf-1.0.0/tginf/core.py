import requests
import logging
from io import BytesIO
from typing import Dict, Any, Optional, Tuple, Union
from dataclasses import dataclass, field
from enum import Enum
import json
from functools import lru_cache
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class ProfileType(Enum):
    USER = "user"
    GROUP = "group"
    SUPERGROUP = "supergroup"
    CHANNEL = "channel"

@dataclass
class TelegramProfile:
    username: Optional[str] = None
    chat_id: Optional[Union[int, str]] = None
    name: Optional[str] = None
    bio: Optional[str] = None
    profile_type: str = "user"
    photo_url: Optional[str] = None
    member_count: Optional[Union[int, str]] = None
    is_bot: bool = False
    verified: Optional[str] = None
    restricted: Optional[str] = None
    features: Optional[list] = None
    deep_link: Optional[str] = None
    public_link: Optional[str] = None
    chat_id_type: Optional[str] = None
    source: str = "api"
    
    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> 'TelegramProfile':
        return cls(
            username=data.get('username'),
            chat_id=data.get('chat_id'),
            name=data.get('name', 'N/A'),
            bio=data.get('bio', 'No bio available'),
            profile_type=data.get('profile_type', 'user'),
            photo_url=data.get('photo_url'),
            member_count=data.get('member_count', 'N/A'),
            is_bot=data.get('is_bot', False),
            source="api"
        )
    
    @classmethod
    def from_scraping_response(cls, data: Dict[str, Any]) -> 'TelegramProfile':
        return cls(
            username=data.get('username'),
            chat_id=data.get('chat_id', 'N/A'),
            chat_id_type=data.get('chat_id_type', 'N/A'),
            name=data.get('name', 'N/A'),
            bio=data.get('bio', 'No description/bio available'),
            profile_type=data.get('profile_type', 'unknown'),
            photo_url=data.get('photo_url'),
            member_count=data.get('member_count_raw', 'N/A'),
            verified=data.get('verified', 'N/A'),
            restricted=data.get('restricted', 'N/A'),
            features=data.get('features', ['Standard']),
            deep_link=data.get('deep_link', '#'),
            public_link=data.get('public_link', '#'),
            source="web_scraping"
        )
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'username': self.username,
            'chat_id': self.chat_id,
            'name': self.name,
            'bio': self.bio,
            'profile_type': self.profile_type,
            'photo_url': self.photo_url,
            'member_count': self.member_count,
            'is_bot': self.is_bot,
            'source': self.source
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)

class TelegramInfoTool:
    def __init__(self, api_base_url: str = "https://tobi-tg-api.vercel.app", use_cache: bool = True):
        self.api_base_url = api_base_url.rstrip('/')
        self.developer_info = {
            "Developer": "t.me/Aotpy",
            "Channel": "t.me/obitostuffs"
        }
        self.use_cache = use_cache
        self._cache = {}
        self._cache_ttl = timedelta(minutes=5)
    
    def _get_cache_key(self, query: str) -> str:
        return query.lower().strip()
    
    def _get_from_cache(self, query: str) -> Optional[TelegramProfile]:
        if not self.use_cache:
            return None
        
        key = self._get_cache_key(query)
        if key in self._cache:
            profile, timestamp = self._cache[key]
            if datetime.now() - timestamp < self._cache_ttl:
                return profile
            else:
                del self._cache[key]
        return None
    
    def _add_to_cache(self, query: str, profile: TelegramProfile):
        if not self.use_cache:
            return
        
        key = self._get_cache_key(query)
        self._cache[key] = (profile, datetime.now())
    
    def clear_cache(self):
        self._cache.clear()
    
    def get_profile(self, username_or_id: str, timeout: int = 15) -> Tuple[Optional[TelegramProfile], Optional[str]]:
        cached = self._get_from_cache(username_or_id)
        if cached:
            logger.debug(f"Cache hit for {username_or_id}")
            return cached, None
        
        try:
            query = username_or_id.strip().lstrip('@')
            
            response = requests.get(
                f"{self.api_base_url}/info?user={query}",
                timeout=timeout
            )
            
            if response.status_code != 200:
                return None, f"API Error: HTTP {response.status_code}"
            
            data = response.json()
            
            if "error" in data:
                return None, f"API Error: {data['error']}"
            
            if data.get("source") == "web_scraping":
                profile = TelegramProfile.from_scraping_response(data)
            else:
                profile = TelegramProfile.from_api_response(data)
            
            self._add_to_cache(username_or_id, profile)
            
            return profile, None
            
        except requests.exceptions.Timeout:
            return None, "Request timed out"
        except requests.exceptions.ConnectionError:
            return None, "Failed to connect to API"
        except requests.exceptions.RequestException as e:
            return None, f"Request failed: {str(e)}"
        except json.JSONDecodeError:
            return None, "Invalid JSON response from API"
        except Exception as e:
            logger.error(f"Unexpected error in get_profile: {e}")
            return None, f"Unexpected error: {str(e)}"
    
    def download_photo(self, photo_url: str, timeout: int = 10) -> Optional[BytesIO]:
        try:
            response = requests.get(photo_url, timeout=timeout)
            if response.status_code == 200:
                return BytesIO(response.content)
        except Exception as e:
            logger.error(f"Failed to download photo: {e}")
        return None
    
    def format_profile_text(self, profile: TelegramProfile, include_dev_credit: bool = True) -> str:
        dev_credit = ""
        if include_dev_credit:
            dev_credit = f"\n━━━━━━━━━━━━━━━━━━━━━━━\n👨‍💻 Dev: {self.developer_info['Developer']}\n📢 Channel: {self.developer_info['Channel']}"
        
        username_display = f"@{profile.username}" if profile.username else "No username"
        bot_tag = "🤖 BOT" if profile.is_bot else ""
        
        if profile.source == "web_scraping":
            profile_type = profile.profile_type.upper()
            features = ', '.join(profile.features) if profile.features else 'Standard'
            
            if "SUPERGROUP" in profile_type or "CHANNEL" in profile_type or str(profile.chat_id).startswith('-100'):
                text = f"""
🔍 SUPERGROUP/CHANNEL ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━
📢 {username_display}

🆔 {profile.chat_id} ({profile.chat_id_type})
━━━━━━━━━━━━━━━━━━━━━━━

📛 {profile.name}

📝 {profile.bio}

👥 {profile.member_count}
━━━━━━━━━━━━━━━━━━━━━━━

🔰 {features}

✅ {profile.verified}
🔒 {profile.restricted}
━━━━━━━━━━━━━━━━━━━━━━━

🔗 [Telegram]({profile.deep_link}) | [Web]({profile.public_link}){dev_credit}
━━━━━━━━━━━━━━━━━━━━━━━
                """
            
            elif "GROUP" in profile_type:
                text = f"""
🔍 GROUP ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━
👥 {username_display}

🆔 {profile.chat_id} ({profile.chat_id_type})
━━━━━━━━━━━━━━━━━━━━━━━

📛 {profile.name}

📝 {profile.bio}

👥 {profile.member_count}
━━━━━━━━━━━━━━━━━━━━━━━

🔗 [Telegram]({profile.deep_link}) | [Web]({profile.public_link}){dev_credit}
━━━━━━━━━━━━━━━━━━━━━━━
                """
            
            else:
                text = f"""
🔍 USER ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━
👤 {username_display}

🆔 {profile.chat_id} ({profile.chat_id_type})
━━━━━━━━━━━━━━━━━━━━━━━

📛 {profile.name}

📝 {profile.bio}
━━━━━━━━━━━━━━━━━━━━━━━

🔗 [Telegram]({profile.deep_link}) | [Web]({profile.public_link}) | [DM](tg://openmessage?user_id={profile.chat_id}){dev_credit}
━━━━━━━━━━━━━━━━━━━━━━━
                """
        
        else:
            if profile.profile_type in ["supergroup", "channel"]:
                text = f"""
🔍 {profile.profile_type.upper()} ANALYSIS {bot_tag}
━━━━━━━━━━━━━━━━━━━━━━━
📢 {username_display}

🆔 {profile.chat_id}
━━━━━━━━━━━━━━━━━━━━━━━

📛 {profile.name}

📝 {profile.bio}

👥 {profile.member_count}
━━━━━━━━━━━━━━━━━━━━━━━

🔗 [Open](tg://resolve?domain={profile.username}){f'?domain={profile.username}' if profile.username else f'?user_id={profile.chat_id}'}){dev_credit}
━━━━━━━━━━━━━━━━━━━━━━━
                """
            
            elif profile.profile_type == "group":
                text = f"""
🔍 GROUP ANALYSIS {bot_tag}
━━━━━━━━━━━━━━━━━━━━━━━
👥 {username_display}

🆔 {profile.chat_id}
━━━━━━━━━━━━━━━━━━━━━━━

📛 {profile.name}

📝 {profile.bio}

👥 {profile.member_count}
━━━━━━━━━━━━━━━━━━━━━━━

🔗 [Open](tg://resolve?domain={profile.username}){f'?domain={profile.username}' if profile.username else f'?user_id={profile.chat_id}'}){dev_credit}
━━━━━━━━━━━━━━━━━━━━━━━
                """
            
            else:
                text = f"""
🔍 USER ANALYSIS {bot_tag}
━━━━━━━━━━━━━━━━━━━━━━━
👤 {username_display}

🆔 {profile.chat_id}
━━━━━━━━━━━━━━━━━━━━━━━

📛 {profile.name}

📝 {profile.bio}
━━━━━━━━━━━━━━━━━━━━━━━

🔗 [Open](tg://resolve?domain={profile.username}){f'?domain={profile.username}' if profile.username else f'?user_id={profile.chat_id}'}) | [DM](tg://openmessage?user_id={profile.chat_id}){dev_credit}
━━━━━━━━━━━━━━━━━━━━━━━
                """
        
        return text.strip()
    
    def get_profile_with_photo(self, username_or_id: str) -> Tuple[Optional[TelegramProfile], Optional[BytesIO], Optional[str]]:
        profile, error = self.get_profile(username_or_id)
        
        if error:
            return None, None, error
        
        photo_bytes = None
        if profile and profile.photo_url:
            photo_bytes = self.download_photo(profile.photo_url)
        
        return profile, photo_bytes, None