import argparse
import sys
import os
from typing import Optional

from .core import TelegramInfoTool
from .config import __version__, __description__, DEFAULT_API_URL

def print_banner():
    banner = f"""
╔════════════════════════════════╗
║    TGINF v{__version__}     ║
║    {__description__}    ║
║    Developer: @Aotpy           ║
║    Channel: @obitostuffs       ║
╚════════════════════════════════╝
    """
    print(banner)

def save_photo(photo_bytes, username: str, output_dir: str = "."):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    filename = os.path.join(output_dir, f"{username}_photo.jpg")
    with open(filename, "wb") as f:
        f.write(photo_bytes.getvalue())
    return filename

def interactive_mode(tool: TelegramInfoTool):
    print_banner()
    print("Interactive Mode - Type 'quit' to exit\n")
    
    while True:
        query = input("\nEnter username (without @): ").strip()
        
        if query.lower() in ['quit', 'exit', 'q']:
            print("Goodbye!")
            break
        
        if not query:
            continue
        
        print(f"\n🔍 Fetching info for @{query}...")
        
        profile, photo, error = tool.get_profile_with_photo(query)
        
        if error:
            print(f"❌ Error: {error}")
            continue
        
        print(tool.format_profile_text(profile))
        
        if photo:
            filename = save_photo(photo, query)
            print(f"📸 Profile photo saved: {filename}")
        else:
            print("ℹ️ No profile photo available")

def main(args: Optional[list] = None):
    parser = argparse.ArgumentParser(
        description="Telegram Profile Information Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  tginf username              # Get info for username
  tginf --bot TOKEN           # Run as Telegram bot
  tginf -i                     # Interactive mode
  tginf -o photos/ username   # Save photo to custom directory
  tginf --json username       # Output as JSON
        """
    )
    
    parser.add_argument(
        'username',
        nargs='?',
        help='Telegram username to lookup'
    )
    
    parser.add_argument(
        '-b', '--bot',
        metavar='TOKEN',
        help='Run as Telegram bot with given token'
    )
    
    parser.add_argument(
        '-i', '--interactive',
        action='store_true',
        help='Run in interactive mode'
    )
    
    parser.add_argument(
        '-o', '--output',
        metavar='DIR',
        default='.',
        help='Directory to save photos (default: current directory)'
    )
    
    parser.add_argument(
        '-j', '--json',
        action='store_true',
        help='Output as JSON'
    )
    
    parser.add_argument(
        '--no-cache',
        action='store_true',
        help='Disable caching'
    )
    
    parser.add_argument(
        '--api',
        metavar='URL',
        default=DEFAULT_API_URL,
        help=f'API base URL (default: {DEFAULT_API_URL})'
    )
    
    parser.add_argument(
        '-v', '--version',
        action='version',
        version=f'tginf v{__version__}'
    )
    
    args = parser.parse_args(args)
    
    if args.bot:
        from .bot import run_bot
        print_banner()
        print(f"Starting bot with token: {args.bot[:10]}...")
        run_bot(token=args.bot, api_base_url=args.api)
        return
    
    tool = TelegramInfoTool(api_base_url=args.api, use_cache=not args.no_cache)
    
    if args.interactive or not args.username:
        interactive_mode(tool)
        return
    
    print_banner()
    print(f"🔍 Fetching info for @{args.username}...\n")
    
    profile, photo, error = tool.get_profile_with_photo(args.username)
    
    if error:
        print(f"❌ Error: {error}")
        sys.exit(1)
    
    if args.json:
        import json
        data = profile.to_dict()
        if photo:
            data['photo_data'] = f"<photo bytes: {len(photo.getvalue())}>"
        print(json.dumps(data, indent=2))
    else:
        print(tool.format_profile_text(profile))
        
        if photo:
            filename = save_photo(photo, args.username, args.output)
            print(f"\n📸 Profile photo saved: {filename}")
        else:
            print("\nℹ️ No profile photo available")

if __name__ == "__main__":
    main()