__version__ = "1.0.0"
__author__ = "Aotpy"
__description__ = "Telegram Profile Information Tool"
__license__ = "MIT"

DEFAULT_API_URL = "https://tobi-tg-api.vercel.app"

DEVELOPER_INFO = {
    "Developer": "t.me/Aotpy",
    "Channel": "t.me/obitostuffs"
}

DEFAULT_CACHE_TTL = 300
DEFAULT_CACHE_ENABLED = True

DEFAULT_API_TIMEOUT = 15
DEFAULT_PHOTO_TIMEOUT = 10

BOT_COMMANDS = [
    {"command": "start", "description": "Welcome message"},
    {"command": "help", "description": "Show help"},
    {"command": "info", "description": "Get info about user/group/channel"},
    {"command": "id", "description": "Get current chat ID"},
    {"command": "about", "description": "About this bot"},
]