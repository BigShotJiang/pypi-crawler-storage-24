# My sire, that is an Outlier!

**Outlier detection for semi-normal distributions.**

Most outlier detection methods assume your data is fully normal. But what if it's only *half* normal — a clear peak with one meaningful tail? `my-sire-that-is-an-outlier` handles exactly that.

## How it works

1. Find the **peak** of your distribution (via KDE or max value)
2. Take the **tail-side** data (everything at or below the peak)
3. **Mirror** it across the peak to create a synthetic full normal distribution
4. Compute **mean and std** of the synthetic distribution
5. Flag anything below `mean − threshold × std` as an **outlier**

## Installation

```bash
pip install my-sire-that-is-an-outlier
```

## Quick start

```python
from my_sire_that_is_an_outlier import find_outliers

# Example: exam scores — most students score high, outliers at the low end
scores = [95, 97, 92, 88, 91, 99, 100, 94, 96, 72, 65, 55, 48]

result = find_outliers(scores, method="mode", threshold=2)

print(result["outliers"])   # array([48])
print(result["cutoff"])     # e.g. 62.4
```

## API

```python
find_outliers(data, method="mode", threshold=2.0)
```

| Parameter   | Type                              | Default  | Description                                      |
|-------------|-----------------------------------|----------|--------------------------------------------------|
| `data`      | list / np.ndarray / pd.Series     | required | 1-D numeric data. NaNs are ignored.              |
| `method`    | `"mode"` or `"max"`              | `"mode"` | How to locate the peak of the distribution.      |
| `threshold` | float                             | `2.0`    | Sigmas below the mirror mean to cut off at.      |

### Return value

A `dict` with:

| Key            | Description                                              |
|----------------|----------------------------------------------------------|
| `outliers`     | `np.ndarray` of values identified as outliers            |
| `cutoff`       | The threshold value — points below this are outliers     |
| `mirror_mean`  | Mean of the synthetic mirrored distribution              |
| `mirror_std`   | Std dev of the synthetic mirrored distribution           |

### `method` parameter

- **`"mode"`** *(default)* — uses KDE to find the most-dense region of the data as the peak. Best for real-world, noisy data.
- **`"max"`** — uses the maximum value as the peak. Useful when your data is naturally bounded at the top (e.g. a 100-point exam, property values with a known ceiling).

### `threshold` parameter

Controls sensitivity. A value of `2.0` means any point more than 2 standard deviations below the mirror mean is flagged. Increase for fewer (more extreme) outliers; decrease for more.

## When to use this

`my-sire-that-is-an-outlier` works well when your data:

- Has a clear, single peak
- Has one natural tail (skewed left or right)
- Is **not** bimodal or uniformly distributed

Examples: exam scores, property values, response times, sensor readings with a hard ceiling.

## License

MIT
