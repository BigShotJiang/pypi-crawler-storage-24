"""Tests for HTTP client."""

import asyncio
import time
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from virtualdojo.client import SyncVirtualDojoClient, VirtualDojoClient
from virtualdojo.config import Credentials, Profile
from virtualdojo.exceptions import (
    APIError,
    AuthenticationError,
    NetworkError,
    NotLoggedInError,
    TokenExpiredError,
)


def _run(coro):
    """Helper to run async coroutines in tests."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


def _make_client(mock_profile, mock_creds, token="tok", **cred_kwargs):
    """Helper to create a client with mocked config."""
    mock_profile.return_value = Profile(name="test", server="https://s.com", tenant="t")
    mock_creds.return_value = Credentials(
        profile_name="test", token=token, **cred_kwargs
    )
    return VirtualDojoClient("test")


class TestVirtualDojoClientInit:
    def test_init_defaults(self):
        client = VirtualDojoClient()
        assert client._profile_name is None
        assert client._timeout == 30.0

    def test_init_with_args(self):
        client = VirtualDojoClient("test", timeout=60.0)
        assert client._profile_name == "test"
        assert client._timeout == 60.0


class TestVirtualDojoClientProperties:
    @patch("virtualdojo.client.get_current_profile")
    def test_profile_property(self, mock_get):
        mock_get.return_value = Profile(name="test", server="https://x.com", tenant="t")
        client = VirtualDojoClient("test")
        assert client.profile.name == "test"
        assert client.profile.name == "test"
        mock_get.assert_called_once()

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_credentials_property(self, mock_profile, mock_creds):
        mock_profile.return_value = Profile(name="test", server="s", tenant="t")
        mock_creds.return_value = Credentials(profile_name="test", token="tok")
        client = VirtualDojoClient("test")
        assert client.credentials.token == "tok"

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_credentials_not_logged_in(self, mock_profile, mock_creds):
        mock_profile.return_value = Profile(name="test", server="s", tenant="t")
        mock_creds.return_value = None
        client = VirtualDojoClient("test")
        with pytest.raises(NotLoggedInError):
            _ = client.credentials

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_credentials_no_token(self, mock_profile, mock_creds):
        mock_profile.return_value = Profile(name="test", server="s", tenant="t")
        mock_creds.return_value = Credentials(profile_name="test", token=None)
        client = VirtualDojoClient("test")
        with pytest.raises(NotLoggedInError):
            _ = client.credentials


class TestTokenExpiration:
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_token_not_expired(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds, expires_at=time.time() + 3600)
        assert client._is_token_expired() is False

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_token_expired(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds, expires_at=time.time() - 60)
        assert client._is_token_expired() is True

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_token_no_expiry(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds, expires_at=None)
        assert client._is_token_expired() is False


class TestGetHeaders:
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_headers(self, mock_profile, mock_creds):
        mock_profile.return_value = Profile(name="test", server="s", tenant="t1")
        mock_creds.return_value = Credentials(profile_name="test", token="my-token")
        client = VirtualDojoClient("test")
        headers = client._get_headers()
        assert headers["Authorization"] == "Bearer my-token"
        assert headers["X-Tenant-ID"] == "t1"
        assert headers["Content-Type"] == "application/json"


class TestRefreshToken:
    @patch("virtualdojo.client.config_manager")
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_refresh_no_refresh_token(self, mock_profile, mock_creds, mock_cm):
        client = _make_client(mock_profile, mock_creds, refresh_token=None)
        assert _run(client._refresh_token()) is False

    @patch("virtualdojo.client.config_manager")
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_refresh_api_key(self, mock_profile, mock_creds, mock_cm):
        client = _make_client(
            mock_profile, mock_creds, token_type="api_key", refresh_token="ref"
        )
        assert _run(client._refresh_token()) is False

    @patch("virtualdojo.client.config_manager")
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_refresh_success(self, mock_profile, mock_creds, mock_cm):
        client = _make_client(
            mock_profile, mock_creds, token_type="jwt", refresh_token="refresh-tok"
        )
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "new-tok",
            "expires_in": 1800,
            "refresh_token": "new-refresh",
        }

        async def _fake_post(*args, **kwargs):
            return mock_response

        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            result = _run(client._refresh_token())
            assert result is True
            assert client._credentials.token == "new-tok"
            assert client._credentials.refresh_token == "new-refresh"
            mock_cm.save_credentials.assert_called_once()

    @patch("virtualdojo.client.config_manager")
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_refresh_success_no_new_refresh(self, mock_profile, mock_creds, mock_cm):
        client = _make_client(
            mock_profile, mock_creds, token_type="jwt", refresh_token="refresh-tok"
        )
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"access_token": "new-tok"}

        async def _fake_post(*args, **kwargs):
            return mock_response

        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            result = _run(client._refresh_token())
            assert result is True
            assert client._credentials.refresh_token == "refresh-tok"

    @patch("virtualdojo.client.config_manager")
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_refresh_non_200(self, mock_profile, mock_creds, mock_cm):
        client = _make_client(
            mock_profile, mock_creds, token_type="jwt", refresh_token="refresh-tok"
        )
        mock_response = MagicMock()
        mock_response.status_code = 401

        async def _fake_post(*args, **kwargs):
            return mock_response

        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            assert _run(client._refresh_token()) is False

    @patch("virtualdojo.client.config_manager")
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_refresh_exception(self, mock_profile, mock_creds, mock_cm):
        client = _make_client(
            mock_profile, mock_creds, token_type="jwt", refresh_token="refresh-tok"
        )
        with patch("httpx.AsyncClient") as mock_http:
            mock_http.return_value.__aenter__ = AsyncMock(
                side_effect=Exception("network error")
            )
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            assert _run(client._refresh_token()) is False


class TestAsyncContextManager:
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_aenter_token_not_expired(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds, expires_at=time.time() + 3600)

        async def _test():
            async with client:
                assert client._client is not None
            assert client._client is None

        _run(_test())

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_aenter_token_expired_refresh_fails(self, mock_profile, mock_creds):
        client = _make_client(
            mock_profile, mock_creds, expires_at=time.time() - 60, refresh_token=None
        )

        async def _test():
            with pytest.raises(TokenExpiredError):
                async with client:
                    pass

        _run(_test())

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_aexit_no_client(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        client._client = None
        _run(client.__aexit__(None, None, None))
        assert client._client is None


class TestHandleResponse:
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_200_ok(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        response = MagicMock()
        response.status_code = 200
        _run(client._handle_response(response))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_401_no_refresh(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds, refresh_token=None)
        response = MagicMock()
        response.status_code = 401
        with pytest.raises(AuthenticationError):
            _run(client._handle_response(response))

    @patch("virtualdojo.client.config_manager")
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_401_with_refresh_success(self, mock_profile, mock_creds, mock_cm):
        client = _make_client(
            mock_profile, mock_creds, token_type="jwt", refresh_token="ref-tok"
        )
        client._client = MagicMock()
        client._client.headers = {"Authorization": "Bearer old"}
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"access_token": "new-tok", "expires_in": 1800}

        async def _fake_post(*args, **kwargs):
            return mock_resp

        response = MagicMock()
        response.status_code = 401
        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            with pytest.raises(TokenExpiredError):
                _run(client._handle_response(response))
            assert "new-tok" in client._client.headers["Authorization"]

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_400_with_json(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        response = MagicMock()
        response.status_code = 400
        response.json.return_value = {"detail": "Bad request"}
        with pytest.raises(APIError):
            _run(client._handle_response(response))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_500_no_json(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        response = MagicMock()
        response.status_code = 500
        response.json.side_effect = Exception("not json")
        response.text = "Internal Server Error"
        with pytest.raises(APIError):
            _run(client._handle_response(response))


class TestRequest:
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_client_not_initialized(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        with pytest.raises(RuntimeError, match="Client not initialized"):
            _run(client._request("GET", "/test"))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_request_success(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": "test"}
        mock_response.content = b'{"data": "test"}'
        mock_http_client = AsyncMock()
        mock_http_client.request.return_value = mock_response
        client._client = mock_http_client
        result = _run(client._request("GET", "/test", params={"a": 1}))
        assert result == {"data": "test"}

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_request_empty_response(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_response.content = b""
        mock_http_client = AsyncMock()
        mock_http_client.request.return_value = mock_response
        client._client = mock_http_client
        result = _run(client._request("DELETE", "/test"))
        assert result == {}

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_request_token_expired_retry(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds, refresh_token=None)
        call_count = 0

        async def _fake_request(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise TokenExpiredError()
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = {"ok": True}
            mock_resp.content = b'{"ok": true}'
            return mock_resp

        mock_http_client = MagicMock()
        mock_http_client.request = _fake_request
        mock_http_client.headers = {"Authorization": "Bearer tok"}
        client._client = mock_http_client
        result = _run(client._request("GET", "/test"))
        assert result == {"ok": True}

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_request_token_expired_no_retry_left(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)

        async def _fake_request(*args, **kwargs):
            raise TokenExpiredError()

        mock_http_client = MagicMock()
        mock_http_client.request = _fake_request
        mock_http_client.headers = {"Authorization": "Bearer tok"}
        client._client = mock_http_client
        with pytest.raises(TokenExpiredError):
            _run(client._request("GET", "/test", retry_count=0))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_request_connect_error(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)

        async def _fake_request(*args, **kwargs):
            raise httpx.ConnectError("connection refused")

        mock_http_client = MagicMock()
        mock_http_client.request = _fake_request
        client._client = mock_http_client
        with pytest.raises(NetworkError, match="Could not connect"):
            _run(client._request("GET", "/test"))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_request_timeout(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)

        async def _fake_request(*args, **kwargs):
            raise httpx.ReadTimeout("timed out")

        mock_http_client = MagicMock()
        mock_http_client.request = _fake_request
        client._client = mock_http_client
        with pytest.raises(NetworkError, match="timed out"):
            _run(client._request("GET", "/test"))


class TestAsyncMethods:
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_get(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"data": "x"}
        mock_resp.content = b'{"data": "x"}'
        mock_http_client = AsyncMock()
        mock_http_client.request.return_value = mock_resp
        client._client = mock_http_client
        assert _run(client.get("/test", params={"a": 1})) == {"data": "x"}

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_post(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"id": "1"}
        mock_resp.content = b'{"id": "1"}'
        mock_http_client = AsyncMock()
        mock_http_client.request.return_value = mock_resp
        client._client = mock_http_client
        assert _run(client.post("/test", {"name": "x"})) == {"id": "1"}

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_put(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {}
        mock_resp.content = b"{}"
        mock_http_client = AsyncMock()
        mock_http_client.request.return_value = mock_resp
        client._client = mock_http_client
        assert _run(client.put("/test", {"x": 1})) == {}

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_delete(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = b""
        mock_http_client = AsyncMock()
        mock_http_client.request.return_value = mock_resp
        client._client = mock_http_client
        assert _run(client.delete("/test")) == {}

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_patch(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"ok": True}
        mock_resp.content = b'{"ok": true}'
        mock_http_client = AsyncMock()
        mock_http_client.request.return_value = mock_resp
        client._client = mock_http_client
        assert _run(client.patch("/test", {"a": 1})) == {"ok": True}


class TestUpload:
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_upload_not_initialized(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        with pytest.raises(RuntimeError, match="Client not initialized"):
            _run(client.upload("/upload", "/tmp/test.txt"))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_upload_success(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds)
        mock_http_client = MagicMock()
        mock_http_client.headers = {"Authorization": "Bearer tok", "X-Tenant-ID": "t"}
        client._client = mock_http_client
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"id": "file-1"}
        mock_response.content = b'{"id": "file-1"}'

        async def _fake_post(*args, **kwargs):
            return mock_response

        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            result = _run(
                client.upload(
                    "/upload",
                    str(test_file),
                    filename="custom.txt",
                    folder_id="folder-1",
                    auto_generate_embeddings=False,
                )
            )
            assert result == {"id": "file-1"}

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_upload_no_folder(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds)
        mock_http_client = MagicMock()
        mock_http_client.headers = {"Authorization": "Bearer tok", "X-Tenant-ID": "t"}
        client._client = mock_http_client
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"id": "file-1"}
        mock_response.content = b'{"id": "file-1"}'

        async def _fake_post(*args, **kwargs):
            return mock_response

        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            result = _run(client.upload("/upload", str(test_file)))
            assert result == {"id": "file-1"}

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_upload_empty_response(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds)
        mock_http_client = MagicMock()
        mock_http_client.headers = {"Authorization": "Bearer tok", "X-Tenant-ID": "t"}
        client._client = mock_http_client
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = b""

        async def _fake_post(*args, **kwargs):
            return mock_response

        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            assert _run(client.upload("/upload", str(test_file))) == {}

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_upload_token_expired_retry(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds, refresh_token=None)
        mock_http_client = MagicMock()
        mock_http_client.headers = {"Authorization": "Bearer tok", "X-Tenant-ID": "t"}
        client._client = mock_http_client
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello")
        call_count = 0

        async def _fake_post(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise TokenExpiredError()
            resp = MagicMock()
            resp.status_code = 200
            resp.json.return_value = {"id": "f1"}
            resp.content = b'{"id": "f1"}'
            return resp

        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            result = _run(client.upload("/upload", str(test_file)))
            assert result == {"id": "f1"}

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_upload_token_expired_no_retry(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds)
        mock_http_client = MagicMock()
        mock_http_client.headers = {"Authorization": "Bearer tok", "X-Tenant-ID": "t"}
        client._client = mock_http_client
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello")

        async def _fake_post(*args, **kwargs):
            raise TokenExpiredError()

        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            with pytest.raises(TokenExpiredError):
                _run(client.upload("/upload", str(test_file), retry_count=0))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_upload_connect_error(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds)
        mock_http_client = MagicMock()
        mock_http_client.headers = {"Authorization": "Bearer tok", "X-Tenant-ID": "t"}
        client._client = mock_http_client
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello")

        async def _fake_post(*args, **kwargs):
            raise httpx.ConnectError("refused")

        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            with pytest.raises(NetworkError, match="Could not connect"):
                _run(client.upload("/upload", str(test_file)))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_upload_timeout(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds)
        mock_http_client = MagicMock()
        mock_http_client.headers = {"Authorization": "Bearer tok", "X-Tenant-ID": "t"}
        client._client = mock_http_client
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello")

        async def _fake_post(*args, **kwargs):
            raise httpx.ReadTimeout("timed out")

        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            with pytest.raises(NetworkError, match="timed out"):
                _run(client.upload("/upload", str(test_file)))


class TestDownload:
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_download_not_initialized(self, mock_profile, mock_creds):
        client = _make_client(mock_profile, mock_creds)
        with pytest.raises(RuntimeError, match="Client not initialized"):
            _run(client.download("/download", "/tmp/out.txt"))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_download_success(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds)
        out_path = str(tmp_path / "out.txt")
        mock_response = AsyncMock()
        mock_response.status_code = 200
        mock_response.headers = {"content-length": "5"}

        async def _aiter_bytes():
            yield b"hello"

        mock_response.aiter_bytes = _aiter_bytes

        class _StreamCM:
            async def __aenter__(self_inner):
                return mock_response

            async def __aexit__(self_inner, *args):
                pass

        mock_http_client = MagicMock()
        mock_http_client.stream = lambda *a, **kw: _StreamCM()
        client._client = mock_http_client
        result = _run(client.download("/download", out_path))
        assert result == 5
        with open(out_path) as f:
            assert f.read() == "hello"

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_download_with_progress(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds)
        out_path = str(tmp_path / "out.txt")
        mock_response = AsyncMock()
        mock_response.status_code = 200
        mock_response.headers = {"content-length": "10"}

        async def _aiter_bytes():
            yield b"hello"
            yield b"world"

        mock_response.aiter_bytes = _aiter_bytes

        class _StreamCM:
            async def __aenter__(self_inner):
                return mock_response

            async def __aexit__(self_inner, *args):
                pass

        mock_http_client = MagicMock()
        mock_http_client.stream = lambda *a, **kw: _StreamCM()
        client._client = mock_http_client
        progress_calls = []
        result = _run(
            client.download(
                "/download",
                out_path,
                progress_callback=lambda d, t: progress_calls.append((d, t)),
            )
        )
        assert result == 10
        assert progress_calls[-1] == (10, 10)

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_download_401_no_refresh(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds, refresh_token=None)
        out_path = str(tmp_path / "out.txt")
        mock_response = AsyncMock()
        mock_response.status_code = 401

        class _StreamCM:
            async def __aenter__(self_inner):
                return mock_response

            async def __aexit__(self_inner, *args):
                pass

        mock_http_client = MagicMock()
        mock_http_client.stream = lambda *a, **kw: _StreamCM()
        client._client = mock_http_client
        with pytest.raises(AuthenticationError):
            _run(client.download("/download", out_path))

    @patch("virtualdojo.client.config_manager")
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_download_401_with_refresh(
        self, mock_profile, mock_creds, mock_cm, tmp_path
    ):
        client = _make_client(
            mock_profile, mock_creds, token_type="jwt", refresh_token="ref"
        )
        out_path = str(tmp_path / "out.txt")
        client._client = MagicMock()
        client._client.headers = {"Authorization": "Bearer old"}
        mock_response = AsyncMock()
        mock_response.status_code = 401

        class _StreamCM:
            async def __aenter__(self_inner):
                return mock_response

            async def __aexit__(self_inner, *args):
                pass

        client._client.stream = lambda *a, **kw: _StreamCM()
        mock_refresh_resp = MagicMock()
        mock_refresh_resp.status_code = 200
        mock_refresh_resp.json.return_value = {
            "access_token": "new-tok",
            "expires_in": 1800,
        }

        async def _fake_post(*args, **kwargs):
            return mock_refresh_resp

        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            with pytest.raises(TokenExpiredError):
                _run(client.download("/download", out_path))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_download_400_with_json(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds)
        out_path = str(tmp_path / "out.txt")
        mock_response = AsyncMock()
        mock_response.status_code = 404
        mock_response.aread = AsyncMock(return_value=b'{"detail": "Not found"}')

        class _StreamCM:
            async def __aenter__(self_inner):
                return mock_response

            async def __aexit__(self_inner, *args):
                pass

        mock_http_client = MagicMock()
        mock_http_client.stream = lambda *a, **kw: _StreamCM()
        client._client = mock_http_client
        with pytest.raises(APIError):
            _run(client.download("/download", out_path))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_download_400_no_json(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds)
        out_path = str(tmp_path / "out.txt")
        mock_response = AsyncMock()
        mock_response.status_code = 500
        mock_response.aread = AsyncMock(return_value=b"not json")

        class _StreamCM:
            async def __aenter__(self_inner):
                return mock_response

            async def __aexit__(self_inner, *args):
                pass

        mock_http_client = MagicMock()
        mock_http_client.stream = lambda *a, **kw: _StreamCM()
        client._client = mock_http_client
        with pytest.raises(APIError):
            _run(client.download("/download", out_path))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_download_connect_error(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds)
        out_path = str(tmp_path / "out.txt")

        class _StreamCM:
            async def __aenter__(self_inner):
                raise httpx.ConnectError("refused")

            async def __aexit__(self_inner, *args):
                pass

        mock_http_client = MagicMock()
        mock_http_client.stream = lambda *a, **kw: _StreamCM()
        client._client = mock_http_client
        with pytest.raises(NetworkError, match="Could not connect"):
            _run(client.download("/download", out_path))

    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_download_timeout(self, mock_profile, mock_creds, tmp_path):
        client = _make_client(mock_profile, mock_creds)
        out_path = str(tmp_path / "out.txt")

        class _StreamCM:
            async def __aenter__(self_inner):
                raise httpx.ReadTimeout("timed out")

            async def __aexit__(self_inner, *args):
                pass

        mock_http_client = MagicMock()
        mock_http_client.stream = lambda *a, **kw: _StreamCM()
        client._client = mock_http_client
        with pytest.raises(NetworkError, match="timed out"):
            _run(client.download("/download", out_path))


class TestSyncClient:
    def test_init(self):
        client = SyncVirtualDojoClient("test", timeout=60.0)
        assert client._profile_name == "test"
        assert client._timeout == 60.0

    @patch("virtualdojo.client.VirtualDojoClient")
    def test_get(self, mock_cls):
        mock_instance = AsyncMock()
        mock_instance.get.return_value = {"data": "test"}
        mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_instance)
        mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        client = SyncVirtualDojoClient("test")
        assert client.get("/test", params={"a": 1}) == {"data": "test"}

    @patch("virtualdojo.client.VirtualDojoClient")
    def test_post(self, mock_cls):
        mock_instance = AsyncMock()
        mock_instance.post.return_value = {"id": "1"}
        mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_instance)
        mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        client = SyncVirtualDojoClient("test")
        assert client.post("/test", {"data": "x"}) == {"id": "1"}

    @patch("virtualdojo.client.VirtualDojoClient")
    def test_put(self, mock_cls):
        mock_instance = AsyncMock()
        mock_instance.put.return_value = {}
        mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_instance)
        mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        client = SyncVirtualDojoClient("test")
        assert client.put("/test", {"data": "x"}) == {}

    @patch("virtualdojo.client.VirtualDojoClient")
    def test_delete(self, mock_cls):
        mock_instance = AsyncMock()
        mock_instance.delete.return_value = {}
        mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_instance)
        mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        client = SyncVirtualDojoClient("test")
        assert client.delete("/test") == {}

    @patch("virtualdojo.client.VirtualDojoClient")
    def test_upload(self, mock_cls):
        mock_instance = AsyncMock()
        mock_instance.upload.return_value = {"id": "file-1"}
        mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_instance)
        mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        client = SyncVirtualDojoClient("test")
        result = client.upload(
            "/upload",
            "/tmp/test.txt",
            folder_id="f1",
            filename="x.txt",
            auto_generate_embeddings=False,
        )
        assert result == {"id": "file-1"}

    @patch("virtualdojo.client.VirtualDojoClient")
    def test_download(self, mock_cls):
        mock_instance = AsyncMock()
        mock_instance.download.return_value = 1024
        mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_instance)
        mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        client = SyncVirtualDojoClient("test")
        assert (
            client.download("/download", "/tmp/out.txt", progress_callback=print)
            == 1024
        )

    def test_run_async_no_event_loop(self):
        client = SyncVirtualDojoClient("test")

        async def _coro():
            return 42

        assert client._run_async(_coro()) == 42

    def test_run_async_creates_new_loop_on_runtime_error(self):
        client = SyncVirtualDojoClient("test")

        async def _coro():
            return 99

        with patch("asyncio.get_event_loop", side_effect=RuntimeError("no loop")):
            assert client._run_async(_coro()) == 99


class TestHandleResponse401ClientNone:
    @patch("virtualdojo.client.config_manager")
    @patch("virtualdojo.client.get_current_credentials")
    @patch("virtualdojo.client.get_current_profile")
    def test_401_refresh_success_client_none(self, mock_profile, mock_creds, mock_cm):
        """Test 401 handling when _client is None during refresh."""
        client = _make_client(
            mock_profile, mock_creds, token_type="jwt", refresh_token="ref-tok"
        )
        # _client is None (not set)
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"access_token": "new-tok", "expires_in": 1800}

        async def _fake_post(*args, **kwargs):
            return mock_resp

        response = MagicMock()
        response.status_code = 401
        with patch("httpx.AsyncClient") as mock_http:
            mock_ctx = AsyncMock()
            mock_ctx.post = _fake_post
            mock_http.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
            mock_http.return_value.__aexit__ = AsyncMock(return_value=False)
            with pytest.raises(TokenExpiredError):
                _run(client._handle_response(response))
