"""Generic API command for VirtualDojo CLI."""

import json
from urllib.parse import urlparse

import typer

from ..client import SyncVirtualDojoClient
from ..utils.output import print_error, print_raw_json

app = typer.Typer(help="Make raw API requests", no_args_is_help=True)


def _validate_path(path: str) -> str:
    """Validate that the path is relative and safe (no SSRF)."""
    parsed = urlparse(path)
    if parsed.scheme or parsed.netloc:
        print_error(
            "Absolute URLs are not allowed. Use a relative path like /api/v1/...",
            hint="The request is always sent to your configured server.",
        )
        raise typer.Exit(1)
    # Ensure leading slash
    if not path.startswith("/"):
        path = "/" + path
    return path


def _parse_json_data(data: str | None) -> dict | None:
    """Parse a JSON string into a dict."""
    if data is None:
        return None
    try:
        parsed = json.loads(data)
    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON data: {e}")
        raise typer.Exit(1) from None
    if not isinstance(parsed, dict):
        print_error("JSON data must be an object (not an array or scalar).")
        raise typer.Exit(1)
    return parsed


@app.command("get")
def api_get(
    path: str = typer.Argument(help="API path, e.g. /api/v1/health"),
    profile: str | None = typer.Option(None, "--profile", "-p"),
) -> None:
    """Make a GET request to the VirtualDojo API.

    Query parameters can be included in the path.

    Examples:
        vdojo api get /api/v1/health
        vdojo api get "/ai/token-usage/by-user?start_date=2026-02-01&end_date=2026-02-27"
    """
    path = _validate_path(path)
    try:
        client = SyncVirtualDojoClient(profile)
        result = client.get(path)
        print_raw_json(result)
    except Exception as e:
        if hasattr(e, "message"):
            print_error(e.message, getattr(e, "hint", None))
        else:
            print_error(str(e))
        raise typer.Exit(1) from None


@app.command("post")
def api_post(
    path: str = typer.Argument(help="API path"),
    data: str | None = typer.Option(
        None, "--data", "-d", help='JSON body, e.g. \'{"key": "value"}\''
    ),
    profile: str | None = typer.Option(None, "--profile", "-p"),
) -> None:
    """Make a POST request to the VirtualDojo API.

    Examples:
        vdojo api post /api/v1/some-endpoint -d '{"name": "test"}'
    """
    path = _validate_path(path)
    body = _parse_json_data(data)
    try:
        client = SyncVirtualDojoClient(profile)
        result = client.post(path, body)
        print_raw_json(result)
    except Exception as e:
        if hasattr(e, "message"):
            print_error(e.message, getattr(e, "hint", None))
        else:
            print_error(str(e))
        raise typer.Exit(1) from None


@app.command("put")
def api_put(
    path: str = typer.Argument(help="API path"),
    data: str | None = typer.Option(
        None, "--data", "-d", help='JSON body, e.g. \'{"key": "value"}\''
    ),
    profile: str | None = typer.Option(None, "--profile", "-p"),
) -> None:
    """Make a PUT request to the VirtualDojo API.

    Examples:
        vdojo api put /api/v1/some-endpoint/123 -d '{"name": "updated"}'
    """
    path = _validate_path(path)
    body = _parse_json_data(data)
    try:
        client = SyncVirtualDojoClient(profile)
        result = client.put(path, body)
        print_raw_json(result)
    except Exception as e:
        if hasattr(e, "message"):
            print_error(e.message, getattr(e, "hint", None))
        else:
            print_error(str(e))
        raise typer.Exit(1) from None


@app.command("patch")
def api_patch(
    path: str = typer.Argument(help="API path"),
    data: str | None = typer.Option(
        None, "--data", "-d", help='JSON body, e.g. \'{"key": "value"}\''
    ),
    profile: str | None = typer.Option(None, "--profile", "-p"),
) -> None:
    """Make a PATCH request to the VirtualDojo API.

    Examples:
        vdojo api patch /api/v1/some-endpoint/123 -d '{"status": "active"}'
    """
    path = _validate_path(path)
    body = _parse_json_data(data)
    try:
        client = SyncVirtualDojoClient(profile)
        result = client.patch(path, body)
        print_raw_json(result)
    except Exception as e:
        if hasattr(e, "message"):
            print_error(e.message, getattr(e, "hint", None))
        else:
            print_error(str(e))
        raise typer.Exit(1) from None


@app.command("delete")
def api_delete(
    path: str = typer.Argument(help="API path"),
    profile: str | None = typer.Option(None, "--profile", "-p"),
) -> None:
    """Make a DELETE request to the VirtualDojo API.

    Examples:
        vdojo api delete /api/v1/some-endpoint/123
    """
    path = _validate_path(path)
    try:
        client = SyncVirtualDojoClient(profile)
        result = client.delete(path)
        print_raw_json(result)
    except Exception as e:
        if hasattr(e, "message"):
            print_error(e.message, getattr(e, "hint", None))
        else:
            print_error(str(e))
        raise typer.Exit(1) from None
