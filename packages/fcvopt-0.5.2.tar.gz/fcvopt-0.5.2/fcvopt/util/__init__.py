# Initialize directory
