"""
this module will contain the homogenizator that performs homogenization
by interpolating between known states
"""

import abc
from functools import lru_cache
from typing import Callable, Dict, Sequence, Set, Tuple

import dorban
import numpy as np
from coremaker.materials import Mixture
from coreoperator import OperationalState
from dorban.current_calculator import CurrentCalculator
from dorban.materials import CrossSectionData
from isotopes import ZAID

from dorbanadapter.homogenizator import Homogenizator
from dorbanadapter.homogenous_geometry import (
    Assembly,
    AssemblyType,
    HomogeneousGeometry,
)
from dorbanadapter.utils import find_density

DiffusionData = Tuple[np.array, ...]

State = Tuple[Tuple[Sequence, Dict[ZAID, CrossSectionData], DiffusionData]]


class Interpolator(Homogenizator, metaclass=abc.ABCMeta):
    r"""
    A Homogenizator that uses interpolation of cross section from a finite number
    of situation
    Parameters
    parameters - sequence of parameters to use in interpolation, for example
                    depletion and temperature
    known_states - Dict of states for every assembly type in which the material
                    cross sections are known
    use_transport - the way to handle the diffusion coefficient interpolation,
                    False - like the cross sections D=\sum a_iD_i
                    True - interpolation of the transport cross section
                            and then inverting D=1/(\sum a_i/D_i)
                    the default is False
    current_calculator- sub class of dorban.CurrentCalculator
    """

    parameters = []

    def __init__(
        self,
        interesting_isotopes: Set[ZAID],
        known_states: Dict[AssemblyType, Sequence[State]],
        current_calculation_method: CurrentCalculator,
        use_transport: bool = False,
    ):
        super().__init__(interesting_isotopes, current_calculation_method)
        self.use_transport = use_transport
        self.known_states = known_states

    @property
    @abc.abstractmethod
    def interpolators(self) -> Dict[AssemblyType, Callable]:
        pass

    @lru_cache()
    def interpolate(self, values: Tuple, type: AssemblyType) -> np.array:
        """
        function that gets the values of the parameters and an assembly type
        returns the interpolation coefficients
        Parameters
        ----------
        values - the values of the parameters for which the cross sections should
                be computed
        known_situations - dict whose keys are sets of values for which the
                            the desired answer is known


        Returns
        -------
        array of the interpolation coefficients
        """
        values = tuple(np.round(v, 10) for v in values)
        try:
            return np.array(self.interpolators[type](values)).flatten()
        except KeyError:
            return np.ones(1)

    @abc.abstractmethod
    def extract_parameters(
        self, rmodel: OperationalState, cell: Assembly, mixture: Mixture
    ) -> Tuple:
        """
        function to extract the values of the parameters that describe a given
        core state in a given assembly
        Parameters
        ----------
        rmodel - the given core state
        cell - the given assemly
        mixture- the homogeneous mixture in the assembly

        Returns
        -------
        tuple of the values relevant for interpolation in this assembly, the orrder
        of the parameters is according to the order in self.parameters but
        some of them might be missing, for example there will be no parameter for
        depletion in an area that doesn't burn even if depletion appears in
        self.parameters
        """
        pass

    def _homogenize_cross_sections(
        self,
        interpolation: Sequence[float],
        isotopes: Set[ZAID],
        mixture: Mixture,
        assembly: Assembly,
        assembly_type: AssemblyType,
        library: Dict[Tuple[ZAID, Assembly], CrossSectionData],
    ):
        """
        function that computes the macroscopic cross section at some assembly,
        it also adds to the library all the microscopic cross sections at this
        assembly.
        Notice that this function edits the library
        """
        macroscopic = 0
        for isotope in isotopes:
            mat = sum(
                [
                    coef * self.known_states[assembly_type][i][1][isotope]
                    for i, coef in enumerate(interpolation)
                ]
            )
            density_num = find_density(mixture, isotope)
            library[(isotope, assembly)] = mat
            macroscopic = macroscopic + mat * density_num
        return macroscopic

    def _homogenize_diffusion_data(
        self,
        interpolation: np.array,
        assembly: Assembly,
        assembly_type: AssemblyType,
        diffusion_data_shape: Sequence[Tuple[int, ...]],
        diff_data: Sequence[np.array],
    ):
        """
        this function updates the diff_data array to have the data related to the
        diffusion computation at the given assembly, the diffusion data will always
        include diffusion coefficient but might also include discontinuityy factors,higher oreder
        diffusion coefficients and more.
        Notice - this function edits diff_data
        """
        if self.use_transport:
            for i, shape in enumerate(diffusion_data_shape):
                diff_data[i][assembly.indices] = 1 / sum(
                    tuple(
                        coef * 1 / self.known_states[assembly_type][j][2][i]
                        for j, coef in enumerate(interpolation)
                    )
                )
        else:
            for i, shape in enumerate(diffusion_data_shape):
                diff_data[i][assembly.indices] = sum(
                    tuple(
                        coef * self.known_states[assembly_type][j][2][i]
                        for j, coef in enumerate(interpolation)
                    )
                )

    def _construct_calculator(self, macro, diff_geometry, diff_data):
        return self.current_calculation_method(diff_data[0])

    def __call__(
        self, rmodel: OperationalState, homogenous_geometry: HomogeneousGeometry
    ) -> Tuple[dorban.Core, Dict[Tuple[ZAID, Assembly], CrossSectionData]]:
        # make preperations

        macro = np.zeros(homogenous_geometry.cells_num, dtype=object)
        cross_sections = {}
        diffusion_data_shape = tuple(
            x.shape for x in list(self.known_states.values())[0][0][2]
        )
        diff_data = tuple(
            np.zeros(shape=np.concatenate([[homogenous_geometry.cells_num], s]))
            for s in diffusion_data_shape
        )
        mixtures = homogenous_geometry.compute_mixtures(rmodel.core)
        for assembly in homogenous_geometry.assemblies:
            # compute the properties of each assembly at the given state
            mixture = mixtures[assembly]
            values = self.extract_parameters(rmodel, assembly, mixture)
            assembly_type = homogenous_geometry.get_type(assembly, rmodel.core)
            interpolation = self.interpolate(values, assembly_type)
            relevant_isotopes = self.interesting_isotopes.intersection(
                self.known_states[assembly_type][0][1].keys()
            )
            relevant_isotopes.add(ZAID(0, 0, 0))
            macro[assembly.indices] = self._homogenize_cross_sections(
                interpolation,
                relevant_isotopes,
                mixture,
                assembly,
                assembly_type,
                cross_sections,
            )
            self._homogenize_diffusion_data(
                interpolation, assembly, assembly_type, diffusion_data_shape, diff_data
            )
        calculator = self._construct_calculator(macro, homogenous_geometry, diff_data)
        return dorban.Core(
            macro, macro[0].E, homogenous_geometry.diffusion_model, calculator
        ), cross_sections
