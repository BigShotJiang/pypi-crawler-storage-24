from abc import ABCMeta
from typing import Callable, Dict, Sequence, Set, Tuple

import numpy as np
from coremaker.materials import Mixture
from coreoperator import OperationalState
from dorban.current_calculator import CurrentCalculator
from dorban.materials import CrossSectionData
from isotopes import ZAID
from scipy.interpolate import LinearNDInterpolator, interp1d

from dorbanadapter.homogenous_geometry import Assembly, AssemblyType
from dorbanadapter.interpolator import DiffusionData, Interpolator, State
from dorbanadapter.utils import find_density


class ConstantInterpolator(Interpolator):
    """
    "Interpolator" where the cross sections are constant. No interpolation
    is happening
    """

    def __init__(self, interesting_isotopes: Set[ZAID],
                 known_states: Dict[AssemblyType, Sequence[Tuple[
                     Sequence, Dict[ZAID, CrossSectionData], DiffusionData]]],
                 current_calculation_method: CurrentCalculator,
                 use_transport: bool = False):
        super(ConstantInterpolator, self).__init__(interesting_isotopes,
                                                   known_states,
                                                   current_calculation_method,
                                                   use_transport)
        self._interpolators = dict.fromkeys(self.known_states.keys(),
                                            no_interpolation)

    @property
    def interpolators(self) -> Dict[AssemblyType, Callable]:
        return self._interpolators

    def extract_parameters(self, rmodel: OperationalState,
                           cell: Assembly,
                           mixture: Mixture) -> Tuple:
        return 0,


class LinearInterpolator(Interpolator, metaclass=ABCMeta):
    """
    interpolator that uses linear interpolation on some parameters
    """

    def __init__(self, interesting_isotopes: Set[ZAID],
                 known_states: Dict[AssemblyType, Sequence[State]],
                 current_calculation_method: CurrentCalculator,
                 use_transport: bool = False):
        super(LinearInterpolator, self).__init__(interesting_isotopes,
                                                 known_states,
                                                 current_calculation_method,
                                                 use_transport)
        self.set_interpolators()

    def set_interpolators(self):
        """
        sets the interpolators to be Scipy's LinearNDInterpolator with rescale
         set to True.
        .. warning::
            The interpolators doesn't function correctly when rescale is turned off
        """
        self._interpolators = {assembly_type: LinearNDInterpolator(
            np.array([state[0] for state in states]), np.eye(len(states)),
            rescale=True)
            for assembly_type, states in self.known_states.items()}

    @property
    def interpolators(self) -> Dict[AssemblyType, LinearNDInterpolator]:
        return self._interpolators


class DepletionLinearInterpolator(LinearInterpolator):
    """
    Interpolator that uses only the combined depletion of specific isotopes
    for interpolation and does it linearly.
    """
    parameters = ["depletion"]

    def __init__(self, interesting_isotopes: Set[ZAID],
                 known_states: Dict[AssemblyType, Sequence[State]], depleting_isotopes: Sequence[ZAID],
                 current_calculation_method,
                 use_transport: bool = False):
        super().__init__(interesting_isotopes, known_states,
                         current_calculation_method,
                         use_transport)
        self.depleting_isotopes = depleting_isotopes

    def set_interpolators(self):
        self._interpolators = {}
        for assembly_type, states in self.known_states.items():
            if len(states) == 1:
                self._interpolators[assembly_type] = no_interpolation
            else:
                self._interpolators[assembly_type] = interp1d(
                    [state[0] for state in states], np.eye(len(states)))

    def extract_parameters(self, rmodel: OperationalState,
                           cell: Assembly,
                           mixture: Mixture) -> Tuple:
        return max(
            [find_density(mixture, isotope) for
             isotope in self.depleting_isotopes]),


class DTBInterpolator(LinearInterpolator):
    """
    this is an interpolator that uses the deplition, temperature and
    boron concentraion for the interpolation
    """
    parameters = ["depletion", "sqrt of temperature", 'boron_concentration']

    def __init__(self, interesting_isotopes: Set[ZAID],
                 known_states: Dict[AssemblyType, Sequence[State]],
                  depleting_isotopes: Sequence[ZAID],
                 current_calculation_method,
                 use_transport: bool = False):
        super().__init__(interesting_isotopes, known_states,
                         current_calculation_method,
                         use_transport)
        self.depleting_isotopes = depleting_isotopes

    def extract_parameters(self, rmodel: OperationalState,
                           cell: Assembly, mixture: Mixture) -> Tuple:
        density = np.sum(
            [find_density(mixture, isotope) for
             isotope in self.depleting_isotopes])
        if density:
            return (density, mixture.temperature,
                    rmodel.history.current_params["boron_concentration"])
        return (mixture.temperature,
                rmodel.history.current_params["boron_concentration"])


def no_interpolation(params):
    return [1]