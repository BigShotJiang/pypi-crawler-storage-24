import bisect
from typing import Sequence

import numpy as np
from coremaker.materials import Mixture
from dorban import Core as HomogenousCore
from dorban.utils import intersect_partitions
from isotopes import ZAID
from more_itertools import pairwise
from reactions import Reaction, ReactionRate

ReactionModel = dict[str, dict[Reaction, ReactionRate]]


def find_density(mixture: Mixture, isotope: ZAID) -> float:
    """
    function to find the density of an isotope from the data of mixtures at
    all assemblies.
    """
    if isotope == ZAID(0, 0, 0):  # happens when an isotope is a fake one
        return 1
    try:
        return mixture[isotope]
    except KeyError:
        return 0


def find_indices(partition: np.array, refined_partition: np.array) -> Sequence[int]:
    """
    gets a partition and a refinement of her in cummelative form and
     finds the indices in the refined partition each section of the
     cruder partition corresponds to.
    Returns
    -------
    sequence whose i-th value is the amount of indices in the refined partition
    which correspond to the part up to the ith section of the given partition.
    Examples
    ----------
    >>> partition=[1,4,7,8]
    >>> refined=[1,2,4,6,7,7.8,8]
    >>> find_indices(partition,refined)
    array([0, 1, 3, 5, 7])
    """
    return np.hstack([[0], np.searchsorted(refined_partition, partition, side="right")])


def refined_by(given_partition, wanted_partition):
    """
    gets 2 partition, one and finds how one needs to bisect each section of the
    first partition to get a refinment of a second partiton.
    It is used when you have a given partition, and you want to do a computation
    in another unrelated partition, then you need to find how to bisect the given
    partition
    to get a refinment of the one you want.
    Parameters

    Examples
    ---------
    >>> x=np.array([1,2,2])
    >>> y=np.array([2,2,1])
    >>> refined_by(x,y)
    [array([1.]), array([0.5, 0.5]), array([0.5, 0.5])]
    """
    refined = intersect_partitions([given_partition, wanted_partition])
    crefined = np.cumsum(refined)
    split = []
    for h1, h2 in pairwise(np.hstack([[0], np.cumsum(given_partition)])):
        left = bisect.bisect_right(crefined, h1)
        right = bisect.bisect_right(crefined, h2)
        split.append(refined[left:right] / np.sum(refined[left:right]))
    return split


def normalize_flux(flux: np.array, homogenous_core: HomogenousCore, true_power: float):
    """
    function to normalize the flux so the power will be correct
    """
    power = np.dot(
        flux,
        np.hstack(
            [
                isotope.kappa * homogenous_core.geometry.volumes[cell]
                for cell, isotope in enumerate(homogenous_core.isotopes)
            ]
        ),
    )
    assert power != 0
    flux *= true_power / power
    return flux


def _normalize(x: np.array):
    return x / np.linalg.norm(x, ord=1)


def change_reactions_power(rates: ReactionModel, power_ratio: float):
    return {
        comp: {
            reaction: ReactionRate(
                comp, reaction, rate.mean * power_ratio, rate.std * power_ratio
            )
            for reaction, rate in reactions.items()
        }
        for comp, reactions in rates.items()
    }
