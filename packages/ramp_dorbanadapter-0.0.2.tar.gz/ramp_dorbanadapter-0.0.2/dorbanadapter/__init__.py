"""
This package is used for generating homogeneous data for diffusion calculation
using the DORBAN code from a heterogeneous data in the ramp format
"""
