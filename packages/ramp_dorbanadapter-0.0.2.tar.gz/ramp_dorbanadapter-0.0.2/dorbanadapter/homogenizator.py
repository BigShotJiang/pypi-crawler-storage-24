import abc
from typing import Dict, Set, Tuple

import dorban
from coreoperator import OperationalState
from dorban.current_calculator import CurrentCalculator
from dorban.materials import CrossSectionData
from isotopes import ZAID

from dorbanadapter.homogenous_geometry import Assembly, HomogeneousGeometry


class Homogenizator(metaclass=abc.ABCMeta):
    """
    Class that creates a homogeneous model from a heterogeneous one and a
    homogeneous geometry
    """

    def __init__(self, interesting_isotopes: Set[ZAID],current_calculation_method:CurrentCalculator):
        """
        Parameters
        ----------
        interesting_isotopes - isotopes to follow ( for example in burnup calculation)
        current_calculation_method - class to define how to compute the currents
        """
        self.current_calculation_method = current_calculation_method
        self.interesting_isotopes = interesting_isotopes

    @abc.abstractmethod
    def __call__(self, rmodel: OperationalState,
                    homogenous_geometry: HomogeneousGeometry) -> Tuple[
        dorban.Core,Dict[Tuple[ZAID, Assembly], CrossSectionData]]:
        """
        generates a homogenous model and a dict that maps ZAID isotopes to their
        cross sections
        """
        pass
