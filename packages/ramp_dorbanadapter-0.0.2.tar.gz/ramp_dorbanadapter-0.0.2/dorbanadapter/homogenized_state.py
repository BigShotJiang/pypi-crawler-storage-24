"""
In a homogenized state, the operations which are related to water should be implemented in a different way.
This happens because most of the mixtures are solids homogenized with water.
For example when changing the density of the water, the density of the solids homogenized with the water shouldn't
change.
"""
from copy import deepcopy
from typing import Optional

from coremaker.core import Core
from coremaker.materials.mixture import Mixture as ConcreteMixture
from coremaker.materials.water import _H2O
from coreoperator import History, OperationalState
from coreoperator.operational_state import Filter, degC
from isotopes import H1, H2, O16, O17, O18, H, O
from packaging.version import Version


def _has_mixture(path,comp):
    return comp.mixture is not None

class HomogenizedState(OperationalState):

    def __init__(self, *, design_name: str, history: History,
                 release: Version, core: Core, water_isotopes=(H1, H2, O16, O17, O, H, O18)):
        super().__init__(design_name=design_name, history=history, release=release, core=core)
        self.water_isotopes = water_isotopes

    def new_temperature(self, temperature: degC,
                        *,
                        to_change: Optional[Filter] = None,
                        change_water_density: bool = True,
                        history_name: str = 'temperature',iswater: Filter = _has_mixture) -> "OperationalState":
        new_core = self.new_core()
        new_history = deepcopy(self.history)
        _to_change = (lambda x: to_change(*x)) if to_change else None
        for path, node in filter(_to_change, new_core.nodes):
            if node.mixture:
                mixture = node.mixture
                factor = 1.
                if change_water_density and iswater(path, node):
                    factor = _H2O(temperature) / _H2O(mixture.temperature)
                node.mixture = ConcreteMixture(
                node.mixture.isotopes | {iso: nd * factor for iso, nd in mixture.items() if iso in self.water_isotopes},
                    temperature, mixture.sab)
        new_history.append({history_name: temperature})
        return self.copy(core=new_core, history=new_history)


    def new_water_temperature(self,
                              temperature: degC, *,
                              history_name: str = 'water_temperature'
                              , iswater: Filter =  _has_mixture
                              ) -> "OperationalState":
        new_core = self.new_core()
        new_history = deepcopy(self.history)
        # I don't know why it doesn't get that the filter and nodes fit well.
        # TODO: Figure out why this is type checked wrong.
        for _, node in new_core.nodes:  # type: ignore
            if iswater(_, node):
                mixture = node.mixture
                factor = _H2O(temperature) / _H2O(mixture.temperature)
                node.mixture = ConcreteMixture(
                    node.mixture.isotopes | {iso: nd * factor for iso, nd in mixture.items() if
                                             iso in self.water_isotopes},
                    temperature, mixture.sab)
        new_history.append({history_name: temperature})
        return self.copy(core=new_core, history=new_history)

    def new_water_density_factor(self, factor: float,
                                 history_name: str = 'water_density_factor',
                                 iswater: Filter = _has_mixture
                                 ) -> "OperationalState":
        new_core = self.new_core()
        new_history = deepcopy(self.history)

        # TODO: Check why the type check ignore is necessary
        for _, node in new_core.nodes:
            if iswater(_, node):
                mixture = node.mixture
                node.mixture = ConcreteMixture(
                    node.mixture.isotopes | {iso: nd * factor for iso, nd in mixture.items() if iso in self.water_isotopes},
                    mixture.temperature, mixture.sab)

        new_history.append({history_name: factor})
        return self.copy(core=new_core, history=new_history)

