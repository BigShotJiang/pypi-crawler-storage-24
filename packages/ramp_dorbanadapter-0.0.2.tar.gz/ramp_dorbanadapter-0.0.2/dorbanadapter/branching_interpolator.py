from typing import Callable, Dict, Sequence, Set, Tuple

import dorban
from coreoperator import OperationalState
from dorban.current_calculator import CurrentCalculator
from dorban.materials import CrossSectionData
from isotopes import ZAID

from dorbanadapter.homogenizator import Homogenizator
from dorbanadapter.homogenous_geometry import Assembly, HomogeneousGeometry
from dorbanadapter.interpolator import Interpolator


class BranchingInterpolator(Homogenizator):

    def __init__(self, interesting_isotopes: Set[ZAID],
                 current_calculation_method: CurrentCalculator,
                 interpolators: Sequence[Interpolator],
                 conditions: Sequence[Callable]):
        super().__init__(interesting_isotopes, current_calculation_method)
        self.interpolators = interpolators
        self.conditions = conditions

    def __call__(self, rmodel: OperationalState,
                 homogenous_geometry: HomogeneousGeometry) -> Tuple[
        dorban.Core, Dict[Tuple[ZAID, Assembly], CrossSectionData]]:
        """
        generates a homogenous model and a dict that maps ZAID isotopes to their
        cross sections
        """
        for intepolator, condition in zip(self.interpolators, self.conditions):
            if condition(rmodel):
                return intepolator(rmodel, homogenous_geometry)
        raise ValueError("All conditions returned False")
