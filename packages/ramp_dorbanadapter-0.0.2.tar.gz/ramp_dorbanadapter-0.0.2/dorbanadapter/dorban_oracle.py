"""
this module contains the 'adapter' for the DORBAN code, using a DorbanOracle
you can compute RAMP cores with the DORBAN code.
"""
from functools import lru_cache, partial
from itertools import chain
from pathlib import PurePath
from typing import Callable, Dict, Tuple

import numpy as np
from corecompute.oracle import OracleResult
from corecompute.query import KQuery, Query, ReactionScore, Score, VolumeQuery
from corecompute.result import KResult
from coremaker.protocols.component import Component
from coreoperator.operational_state import OperationalState
from dorban import Core
from dorban.materials import CrossSectionData
from dorban.solve_equation import solve_k
from isotopes import ZAID
from reactions import ReactionRate, ReactionType, Typus
from reactions.typus import ProdTypus

from dorbanadapter.homogenizator import Homogenizator
from dorbanadapter.homogenous_geometry import Assembly, HomogeneousGeometry
from dorbanadapter.utils import _normalize, find_density

cs_dict = {typus: lambda x: x.absorb if not x.isfissile else x.absorb - x.fission for typus in
           chain(iter(Typus), iter(ProdTypus))} | {Typus.NFission: lambda x: x.fission,
                                                   Typus.NElastic: lambda x: np.sum(x.scatter, axis=0),
                                                   Typus.NHeating: lambda x: x.kappa,
                                                   'fission': lambda x: x.fission,
                                                   'kappa': lambda x: x.kappa,
                                                   'kappa-fission': lambda x: x.kappa,
                                                   'q-fission-prompt': lambda x: x.kappa,
                                                   'absorption': lambda x: x.absorb,
                                                   'flux': lambda x: np.ones_like(x.total)}


class DorbanOracle:
    """
    An Oracle that uses the DORBAN diffusion code to solve for the flux and
    compute the reaction rates.
    """

    def __init__(self, homogenizator: Homogenizator,
                 settings_factory=None,
                 geometry_factory=None):
        self.settings_factory = settings_factory
        self.geometry_factory = geometry_factory
        self.homogenizator = homogenizator
        self.direct = partial(_call,
                              homogenizator=self.homogenizator, geometry_factory=self.geometry_factory,
                              settings_factory=self.settings_factory)

    def __call__(self, state: OperationalState,
                 *queries: Query) -> OracleResult:
        return _call(state, *queries, geometry_factory=self.geometry_factory, settings_factory=self.settings_factory,
                     homogenizator=self.homogenizator)


def _call(state: OperationalState,
          *queries: Query, geometry_factory,
          settings_factory, homogenizator: Homogenizator, prefix=None, force_continuity=False) -> OracleResult:
    geometry = geometry_factory(state)
    settings = settings_factory(geometry)
    homogenous_core, cross_sections = homogenizator(state, geometry)
    named_components = dict(state.core.named_components)
    if force_continuity:
        try:
            homogenous_core.current_calc.df = np.ones_like(homogenous_core.current_calc.df)
        except AttributeError:
            pass
    k, flux = solve_k(homogenous_core, settings)
    flux = np.reshape(flux,
                      (homogenous_core.geometry.cells, homogenous_core.E))
    results = {}
    get_cs = lru_cache(partial(get_cross_section,
                               cross_sections=cross_sections,
                               E=homogenous_core.E))
    compute_rate = partial(_compute_score,
                           homogenous_core=homogenous_core,
                           geometry=geometry, homogenizator=homogenizator,
                           flux=flux, get_cs=get_cs)
    for query in queries:
        if isinstance(query, KQuery):
            results[query] = [KResult(k, settings.k_tol), ]
            continue
        elif isinstance(query, VolumeQuery):
            answers = [compute_rate(name=name, score=score, component=named_components[name]) for score in
                       query.scores for name in query.names]
            results[query] = answers
        else:
            raise ValueError(f"Queries of type {type(query)} are not supported by the DorbanOracle")
    return results


def _compute_score(name: PurePath, component: Component,
                   score: Score | ReactionScore,
                   homogenous_core: Core,
                   geometry: HomogeneousGeometry,
                   homogenizator: Homogenizator, flux: np.array,
                   get_cs: Callable) -> ReactionRate:
    """
    function to compute reaction rate in a component, in units of 1/s
    Parameters
    ----------
    get_cs - function to get the cross sections of the assemblies
    """
    site = str(name).split("/")[0]
    match score:
        case ReactionScore():
            if score.reaction.parent not in homogenizator.interesting_isotopes:
                return ReactionRate(name, score.reaction, 0, 0)
            else:
                isotope = score.reaction.parent
                event = score.reaction.typus
                value = _get_score(isotope, event, score.volume_specific, score.density_specific, geometry,
                                   component, site, homogenous_core, flux, get_cs)
                # TODO: how to report the error? It shouldn't be 0
                return {'component': name,
                        'score': score,
                        'value': value,
                        'error': 0,
                        'particle': 'neutron'}
        case Score():
            if score.name == 'flux':
                value = _get_score(ZAID(0, 0, 0), score.name, score.volume_specific, False, geometry,
                                   component, site, homogenous_core, flux, get_cs)
            else:
                value = sum(_get_score(isotope, score.name, score.volume_specific, False, geometry,
                                       component, site, homogenous_core, flux, get_cs) for isotope in
                            component.mixture.isotopes.keys() | [ZAID(0, 0, 0)])
            return {'component': name,
                    'score': score,
                    'value': value,
                    'error': 0,
                    'particle': 'neutron'}


def _get_score(isotope: ZAID, event: Typus | str, volume_specific, density_specific, geometry, component,
               site,
               homogenous_core, flux, get_cs) -> float:
    value = 0
    for assembly, per in geometry.find_component(component, site).items():
        value += np.sum(per * np.diag(
            _normalize(homogenous_core.geometry.volumes[assembly.indices])) @ \
                        flux[assembly.indices] @ \
                        get_cs(event=event, isotope=isotope, assembly=assembly))
    if not volume_specific:
        value *= component.geometry.volume
    if not density_specific:
        value *= find_density(component.mixture, isotope)
    return value


def get_cross_section(event: ReactionType | str,
                      isotope: ZAID,
                      cross_sections: Dict[
                          Tuple[ZAID, Assembly], CrossSectionData],
                      assembly: Assembly, E: int) -> np.array:
    """
    functions that find the microscopic cross sections of a reaction in an
    assembly
    Parameters
    ----------
    cross_sections - dict of microscopic cross section data, for each
                    isotope and assembly returns the CrossSectionData of
                    the isotope in the assembly
    E - the number of energy groups

    Returns
    -------
    array of length E which represent the microscopic cross section of the
    given reaction in the given assembly
    """
    try:
        cross_section = cross_sections[(isotope, assembly)]
    except KeyError:  # happens when an isotope is not followed
        return np.zeros(E)
    try:
        return cs_dict[event](cross_section)
    except KeyError:
        return cross_section.data[cross_section.special_cross_sections[event]]
