from dataclasses import dataclass
from typing import Dict, Hashable, Iterable, Optional, Protocol, Sequence

from coremaker.materials import Mixture
from coremaker.protocols.component import Component
from coremaker.protocols.core import Core, Site
from coremaker.protocols.geometry import Geometry
from dorban.geometry.geometry import FiniteGeometry

AssemblyType = Hashable


@dataclass
class Assembly:
    """
    Assembly is a part of a core that is consider homogeneous in the diffusion
    model. It can be characetarized both by a location in the core, and by the
    indices of the cells in the diffusion models in which it is located. It acts
    as a translator between geometrical location and indices,
    Parameters
    location- a location in the core that is made homogenous in the diffusion
              model
    indices - the indices of the cells in the diffusion module to which
                this assembly corresponds to
    """
    location: Geometry
    indices: Sequence[int]
    site: Optional[Site] = None
    _type: Optional[str] = None

    def __hash__(self):
        return hash(tuple(self.indices))


class HomogeneousGeometry(Protocol):
    """
    class that represents a homogeneous geometry which is connected to the
    real geometry but can be converted to the diffusion calculation geometry
    """

    @property
    def diffusion_model(self) -> FiniteGeometry:
        """
        the model of the geometry to be used in the diffusion computation
        """
        raise NotImplementedError

    @property
    def assemblies(self) -> Iterable[Assembly]:
        """
        Iterable of all assemblies in the core
        """
        raise NotImplementedError

    @property
    def sites_assemblies(self) -> Dict[Site, Sequence[Assembly]]:
        """
        dict of assemblies at each site
        """
        raise NotImplementedError

    @property
    def outer_cells(self) -> Sequence[Assembly]:
        """
        assemblies which are not in a site
        """
        raise NotImplementedError

    @property
    def cells_num(self) -> int:
        """
        the number of cells in the diffusion model
        """
        raise NotImplementedError

    def find_component(self, component: Component, site: Site) -> Dict[Assembly, float]:
        """
        method that gets a component  and finds all the assemblies in which
        the component is located and returns sequence of the assemblies and
        the percentage of the component inside each assembly

        Returns
        -------
        dict whose key is an Assembly and whose value is the percentage of the
         component that is inside the assembly
        """
        raise NotImplementedError

    def get_type(self, assembly: Assembly, core: Core) -> AssemblyType:
        """
        method to find the type of the assembly
        """
        raise NotImplementedError

    def compute_mixtures(self, core: Core) -> Dict[Assembly, Mixture]:
        """
        computes the average mixture inside each assembly
        """
        raise NotImplementedError
