# Dorban Adapter
This package is an adapter Dorban to work as an Oracle for the ramp
project.

## Installation
One has to use both conda and pip.

1. Use `conda` to update the environment according to "requirements.yml"
1. pip install this package


