"""
tests for the interpolation methods
"""
import numpy as np
from scipy.interpolate import LinearNDInterpolator


def test_linear_interpolator():
    states = np.array([[1.9820000e-05, 50., 0.],
                       [2.1655332e-06, 50., 0.],
                       [1.97599454e-05, 50., 0.],
                       [2.1655332e-06, 20., 0.],
                       [2.1655332e-06, 20., 2.5]])
    interpolator = LinearNDInterpolator(states, np.eye(len(states)),rescale=True)
    for i, state in enumerate(states):
        x = np.zeros(len(states))
        x[i] = 1
        inter = interpolator(state)[0]
        assert np.allclose(inter, x)
