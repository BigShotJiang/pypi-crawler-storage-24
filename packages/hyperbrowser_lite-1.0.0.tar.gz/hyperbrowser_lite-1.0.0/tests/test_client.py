"""Tests for client classes."""

from __future__ import annotations

import os
from unittest.mock import patch

import pytest

from hyperbrowser_lite import AsyncHyperbrowserCloud, HyperbrowserCloud
from hyperbrowser_lite.sessions import AsyncSessionsResource, SessionsResource


class TestHyperbrowserCloud:
    def test_init_with_api_key(self):
        client = HyperbrowserCloud(api_key="test-key")
        assert isinstance(client.sessions, SessionsResource)
        client.close()

    def test_init_from_env(self):
        with patch.dict(os.environ, {"HYPERBROWSER_API_KEY": "env-key"}):
            client = HyperbrowserCloud()
            assert isinstance(client.sessions, SessionsResource)
            client.close()

    def test_init_raises_without_key(self):
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ValueError, match="api_key must be provided"):
                HyperbrowserCloud()

    def test_contexts_returns_none(self):
        client = HyperbrowserCloud(api_key="test-key")
        assert client.contexts is None
        client.close()

    def test_capabilities(self):
        client = HyperbrowserCloud(api_key="test-key")
        assert "proxy" in client.capabilities
        assert "fingerprint" in client.capabilities
        assert "recording" in client.capabilities
        client.close()

    def test_context_manager(self):
        with HyperbrowserCloud(api_key="test-key") as client:
            assert isinstance(client.sessions, SessionsResource)

    def test_custom_base_url(self):
        client = HyperbrowserCloud(api_key="key", base_url="https://custom.api.com")
        assert client._http._client.base_url == "https://custom.api.com"
        client.close()

    def test_custom_timeout(self):
        client = HyperbrowserCloud(api_key="key", timeout=30.0)
        client.close()


class TestAsyncHyperbrowserCloud:
    def test_init_with_api_key(self):
        client = AsyncHyperbrowserCloud(api_key="test-key")
        assert isinstance(client.sessions, AsyncSessionsResource)

    def test_init_raises_without_key(self):
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ValueError, match="api_key must be provided"):
                AsyncHyperbrowserCloud()

    def test_contexts_returns_none(self):
        client = AsyncHyperbrowserCloud(api_key="test-key")
        assert client.contexts is None

    def test_capabilities(self):
        client = AsyncHyperbrowserCloud(api_key="test-key")
        assert client.capabilities == ["proxy", "fingerprint", "recording"]

    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        async with AsyncHyperbrowserCloud(api_key="test-key") as client:
            assert isinstance(client.sessions, AsyncSessionsResource)


class TestBackwardCompatibility:
    def test_hyperbrowser_alias(self):
        from hyperbrowser_lite import Hyperbrowser
        assert Hyperbrowser is HyperbrowserCloud

    def test_async_hyperbrowser_alias(self):
        from hyperbrowser_lite import AsyncHyperbrowser
        assert AsyncHyperbrowser is AsyncHyperbrowserCloud
