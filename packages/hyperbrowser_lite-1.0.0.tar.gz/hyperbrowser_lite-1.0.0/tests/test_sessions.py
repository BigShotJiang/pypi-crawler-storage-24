"""Tests for session CRUD resources."""

from __future__ import annotations

from typing import Any

import pytest

from hyperbrowser_lite.exceptions import SessionNotFoundError, TimeoutError
from hyperbrowser_lite.models import (
    FingerprintConfig,
    ManagedProxyConfig,
    ProxyConfig,
    RecordingConfig,
    ViewportConfig,
)
from hyperbrowser_lite.sessions import SessionsResource, _build_create_body, _to_session_info

from .conftest import SAMPLE_SESSION_RESPONSE, FakeAsyncHttp, FakeSyncHttp


class TestToSessionInfo:
    def test_maps_fields(self):
        info = _to_session_info(SAMPLE_SESSION_RESPONSE)
        assert info.session_id == "sess-abc-123"
        assert info.cdp_url == "wss://connect.hyperbrowser.ai/devtools/browser/abc123?token=xyz"
        assert info.status == "active"
        assert info.inspect_url == "https://live.hyperbrowser.ai/session/sess-abc-123"

    def test_extra_fields_in_metadata(self):
        info = _to_session_info(SAMPLE_SESSION_RESPONSE)
        assert info.metadata["teamId"] == "team-456"
        assert info.metadata["token"] == "xyz-token-789"
        assert info.metadata["proxyDataConsumed"] == "0"

    def test_delete_fn_attached(self):
        called = False

        def _delete():
            nonlocal called
            called = True

        info = _to_session_info(SAMPLE_SESSION_RESPONSE, delete_fn=_delete)
        info.__exit__(None, None, None)
        assert called


class TestBuildCreateBody:
    def test_empty_body(self):
        body = _build_create_body("normal", None, None, None, None, {})
        assert body == {}

    def test_stealth_mode(self):
        body = _build_create_body("stealth", None, None, None, None, {})
        assert body["useStealth"] is True
        assert "useUltraStealth" not in body

    def test_ultra_stealth_mode(self):
        body = _build_create_body("ultra_stealth", None, None, None, None, {})
        assert body["useUltraStealth"] is True
        assert "useStealth" not in body

    def test_managed_proxy(self):
        proxy = ManagedProxyConfig(country="US")
        body = _build_create_body("normal", proxy, None, None, None, {})
        assert body["useProxy"] is True
        assert body["proxyCountry"] == "US"

    def test_managed_proxy_with_city(self):
        proxy = ManagedProxyConfig(country="US", city="New York")
        body = _build_create_body("normal", proxy, None, None, None, {})
        assert body["proxyCountry"] == "US"
        assert body["proxyCity"] == "New York"

    def test_custom_proxy(self):
        proxy = ProxyConfig(server="http://proxy:8080", username="u", password="p")
        body = _build_create_body("normal", proxy, None, None, None, {})
        assert body["useProxy"] is True
        assert body["proxyServer"] == "http://proxy:8080"
        assert body["proxyServerUsername"] == "u"
        assert body["proxyServerPassword"] == "p"

    def test_custom_proxy_no_auth(self):
        proxy = ProxyConfig(server="http://proxy:8080")
        body = _build_create_body("normal", proxy, None, None, None, {})
        assert body["useProxy"] is True
        assert body["proxyServer"] == "http://proxy:8080"
        assert "proxyServerUsername" not in body
        assert "proxyServerPassword" not in body

    def test_recording_enabled(self):
        rec = RecordingConfig(enabled=True)
        body = _build_create_body("normal", None, rec, None, None, {})
        assert body["enableWebRecording"] is True

    def test_recording_disabled(self):
        rec = RecordingConfig(enabled=False)
        body = _build_create_body("normal", None, rec, None, None, {})
        assert "enableWebRecording" not in body

    def test_fingerprint_locale(self):
        fp = FingerprintConfig(locale="zh-CN")
        body = _build_create_body("normal", None, None, fp, None, {})
        assert body["locales"] == ["zh-CN"]

    def test_fingerprint_viewport(self):
        fp = FingerprintConfig(viewport=ViewportConfig(width=1920, height=1080))
        body = _build_create_body("normal", None, None, fp, None, {})
        assert body["screen"] == {"width": 1920, "height": 1080}

    def test_fingerprint_auto_is_noop(self):
        body = _build_create_body("normal", None, None, "auto", None, {})
        assert body == {}

    def test_vendor_params_passthrough(self):
        body = _build_create_body(
            "normal", None, None, None, None,
            {"solve_captchas": True, "adblock": True, "timeout_minutes": 30},
        )
        assert body["solveCaptchas"] is True
        assert body["adblock"] is True
        assert body["timeoutMinutes"] == 30

    def test_unknown_vendor_params_ignored(self):
        body = _build_create_body(
            "normal", None, None, None, None,
            {"unknown_param": "x", "adblock": True},
        )
        assert "unknown_param" not in body
        assert "unknownParam" not in body
        assert body["adblock"] is True


class TestSessionsResourceCreate:
    def test_create_returns_session_info(self, sample_response: dict[str, Any]):
        http = FakeSyncHttp(responses={
            "POST /api/session": sample_response,
        })
        sessions = SessionsResource(http)
        info = sessions.create()
        assert info.session_id == "sess-abc-123"
        assert info.cdp_url == "wss://connect.hyperbrowser.ai/devtools/browser/abc123?token=xyz"
        assert info.status == "active"

    def test_create_polls_when_no_cdp_url(self, sample_response: dict[str, Any]):
        no_cdp = {**sample_response, "wsEndpoint": None}
        call_count = 0

        def _get_response():
            nonlocal call_count
            call_count += 1
            if call_count >= 2:
                return sample_response
            return no_cdp

        http = FakeSyncHttp(responses={
            "POST /api/session": no_cdp,
            "GET /api/session/sess-abc-123": _get_response,
        })
        sessions = SessionsResource(http)

        import unittest.mock
        with unittest.mock.patch("hyperbrowser_lite.sessions.time.sleep"):
            info = sessions.create()

        assert info.cdp_url == "wss://connect.hyperbrowser.ai/devtools/browser/abc123?token=xyz"

    def test_create_context_manager(self, sample_response: dict[str, Any]):
        http = FakeSyncHttp(responses={
            "POST /api/session": sample_response,
            "PUT /api/session/sess-abc-123/stop": {},
        })
        sessions = SessionsResource(http)

        with sessions.create() as session:
            assert session.session_id == "sess-abc-123"

        # Verify delete (stop) was called
        stop_calls = [c for c in http.calls if "stop" in c[1]]
        assert len(stop_calls) == 1


class TestSessionsResourceGet:
    def test_get(self, sample_response: dict[str, Any]):
        http = FakeSyncHttp(responses={
            "GET /api/session/sess-abc-123": sample_response,
        })
        sessions = SessionsResource(http)
        info = sessions.get("sess-abc-123")
        assert info.session_id == "sess-abc-123"


class TestSessionsResourceList:
    def test_list_array_response(self, sample_response: dict[str, Any]):
        http = FakeSyncHttp(responses={
            "GET /api/sessions": [sample_response, sample_response],
        })
        sessions = SessionsResource(http)
        result = sessions.list()
        assert len(result) == 2
        assert all(s.session_id == "sess-abc-123" for s in result)

    def test_list_wrapped_response(self, sample_response: dict[str, Any]):
        http = FakeSyncHttp(responses={
            "GET /api/sessions": {
                "sessions": [sample_response],
                "totalCount": 1,
                "page": 1,
                "perPage": 10,
            },
        })
        sessions = SessionsResource(http)
        result = sessions.list()
        assert len(result) == 1


class TestSessionsResourceDelete:
    def test_delete_success(self):
        http = FakeSyncHttp(responses={
            "PUT /api/session/sess-abc-123/stop": {},
        })
        sessions = SessionsResource(http)
        sessions.delete("sess-abc-123")  # should not raise

    def test_delete_idempotent_on_404(self):
        http = FakeSyncHttp(responses={
            "PUT /api/session/sess-abc-123/stop": SessionNotFoundError("not found"),
        })
        sessions = SessionsResource(http)
        sessions.delete("sess-abc-123")  # should not raise


class TestAsyncSessionsResource:
    @pytest.mark.asyncio
    async def test_create(self, sample_response: dict[str, Any]):
        from hyperbrowser_lite.sessions import AsyncSessionsResource

        http = FakeAsyncHttp(responses={
            "POST /api/session": sample_response,
        })
        sessions = AsyncSessionsResource(http)
        info = await sessions.create()
        assert info.session_id == "sess-abc-123"

    @pytest.mark.asyncio
    async def test_get(self, sample_response: dict[str, Any]):
        from hyperbrowser_lite.sessions import AsyncSessionsResource

        http = FakeAsyncHttp(responses={
            "GET /api/session/sess-abc-123": sample_response,
        })
        sessions = AsyncSessionsResource(http)
        info = await sessions.get("sess-abc-123")
        assert info.session_id == "sess-abc-123"

    @pytest.mark.asyncio
    async def test_delete_idempotent(self):
        from hyperbrowser_lite.sessions import AsyncSessionsResource

        http = FakeAsyncHttp(responses={
            "PUT /api/session/sess-abc-123/stop": SessionNotFoundError("gone"),
        })
        sessions = AsyncSessionsResource(http)
        await sessions.delete("sess-abc-123")  # should not raise

    @pytest.mark.asyncio
    async def test_list(self, sample_response: dict[str, Any]):
        from hyperbrowser_lite.sessions import AsyncSessionsResource

        http = FakeAsyncHttp(responses={
            "GET /api/sessions": [sample_response],
        })
        sessions = AsyncSessionsResource(http)
        result = await sessions.list()
        assert len(result) == 1
