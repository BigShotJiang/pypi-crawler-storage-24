"""Session CRUD resources for Hyperbrowser cloud browser SDK."""

from __future__ import annotations

import time
from typing import Any

from .exceptions import SessionNotFoundError, TimeoutError
from .models import (
    ContextAttach,
    FingerprintConfig,
    ManagedProxyConfig,
    ProxyConfig,
    RecordingConfig,
    SessionInfo,
    ViewportConfig,
    map_status,
)

_CDP_POLL_INITIAL = 0.5
_CDP_POLL_MAX = 3.0
_CDP_POLL_TIMEOUT = 30.0

# Vendor params that pass through to the Hyperbrowser API (snake_case → camelCase).
_VENDOR_PARAM_MAP: dict[str, str] = {
    "timeout_minutes": "timeoutMinutes",
    "solve_captchas": "solveCaptchas",
    "adblock": "adblock",
    "trackers": "trackers",
    "annoyances": "annoyances",
    "profile": "profile",
    "extension_ids": "extensionIds",
    "region": "region",
    "accept_cookies": "acceptCookies",
    "browser_args": "browserArgs",
    "url_blocklist": "urlBlocklist",
    "save_downloads": "saveDownloads",
    "locales": "locales",
    "operating_systems": "operatingSystems",
    "device": "device",
    "platform": "platform",
    "static_ip_id": "staticIpId",
    "enable_log_capture": "enableLogCapture",
    "enable_window_manager": "enableWindowManager",
    "view_only_live_view": "viewOnlyLiveView",
}


def _to_session_info(
    data: dict[str, Any],
    delete_fn: Any = None,
) -> SessionInfo:
    """Map Hyperbrowser API response dict to SessionInfo."""
    info = SessionInfo(
        session_id=data.get("id", ""),
        cdp_url=data.get("wsEndpoint"),
        status=map_status(data.get("status", "active")),
        created_at=data.get("createdAt"),
        inspect_url=data.get("liveUrl"),
        metadata={
            k: v
            for k, v in data.items()
            if k not in {
                "id",
                "wsEndpoint",
                "status",
                "createdAt",
                "liveUrl",
            }
        },
    )
    if delete_fn is not None:
        info.set_delete_fn(delete_fn)
    return info


def _build_create_body(
    browser_mode: str,
    proxy: ProxyConfig | ManagedProxyConfig | None,
    recording: RecordingConfig | None,
    fingerprint: FingerprintConfig | str | None,
    context: ContextAttach | None,
    vendor_params: dict[str, Any],
) -> dict[str, Any]:
    """Build the JSON body for POST /api/session."""
    body: dict[str, Any] = {}

    # Browser mode
    if browser_mode == "stealth":
        body["useStealth"] = True
    elif browser_mode == "ultra_stealth":
        body["useUltraStealth"] = True

    # Proxy
    if isinstance(proxy, ProxyConfig):
        body["useProxy"] = True
        body["proxyServer"] = proxy.server
        if proxy.username:
            body["proxyServerUsername"] = proxy.username
        if proxy.password:
            body["proxyServerPassword"] = proxy.password
    elif isinstance(proxy, ManagedProxyConfig):
        body["useProxy"] = True
        body["proxyCountry"] = proxy.country.upper()
        if proxy.city:
            body["proxyCity"] = proxy.city

    # Recording
    if recording is not None and recording.enabled:
        body["enableWebRecording"] = True

    # Fingerprint
    if isinstance(fingerprint, FingerprintConfig):
        if fingerprint.locale:
            body["locales"] = [fingerprint.locale]
        if fingerprint.viewport:
            body["screen"] = {
                "width": fingerprint.viewport.width,
                "height": fingerprint.viewport.height,
            }
    # fingerprint="auto" → no-op (Hyperbrowser handles internally)

    # Vendor params passthrough (snake_case → camelCase)
    for snake_key, camel_key in _VENDOR_PARAM_MAP.items():
        if snake_key in vendor_params:
            body[camel_key] = vendor_params[snake_key]

    return body


class SessionsResource:
    """Synchronous session CRUD operations."""

    def __init__(self, http: Any) -> None:
        self._http = http

    def create(
        self,
        *,
        browser_mode: str = "normal",
        proxy: ProxyConfig | ManagedProxyConfig | None = None,
        recording: RecordingConfig | None = None,
        fingerprint: FingerprintConfig | str | None = None,
        context: ContextAttach | None = None,
        **vendor_params: Any,
    ) -> SessionInfo:
        """Create a browser session.

        Returns a SessionInfo with cdp_url ready for connection.
        Polls for cdp_url if not immediately available (up to 30s).
        """
        body = _build_create_body(
            browser_mode, proxy, recording, fingerprint, context, vendor_params
        )
        data = self._http.request("POST", "/api/session", json=body)

        session_id = data.get("id", "")

        # Poll for cdp_url if not immediately available
        if not data.get("wsEndpoint"):
            data = self._poll_for_cdp_url(session_id)

        def _delete() -> None:
            self.delete(session_id)

        return _to_session_info(data, delete_fn=_delete)

    def get(self, session_id: str) -> SessionInfo:
        """Get session info by ID."""
        data = self._http.request("GET", f"/api/session/{session_id}")
        return _to_session_info(data)

    def list(self, **filters: Any) -> list[SessionInfo]:
        """List sessions, optionally filtered."""
        params = filters if filters else None
        data = self._http.request("GET", "/api/sessions", params=params)
        if isinstance(data, list):
            return [_to_session_info(item) for item in data]
        # Hyperbrowser wraps in {"sessions": [...], "totalCount": ..., ...}
        items = data.get("sessions") or data.get("items") or []
        return [_to_session_info(item) for item in items]

    def delete(self, session_id: str) -> None:
        """Stop (close) a session. Idempotent — ignores 404."""
        try:
            self._http.request("PUT", f"/api/session/{session_id}/stop")
        except SessionNotFoundError:
            pass  # Already stopped

    def _poll_for_cdp_url(self, session_id: str) -> dict[str, Any]:
        """Poll GET until wsEndpoint is available."""
        deadline = time.monotonic() + _CDP_POLL_TIMEOUT
        interval = _CDP_POLL_INITIAL

        while True:
            data = self._http.request("GET", f"/api/session/{session_id}")
            if data.get("wsEndpoint"):
                return data

            if time.monotonic() + interval > deadline:
                raise TimeoutError(
                    f"cdp_url not available after {_CDP_POLL_TIMEOUT}s for session {session_id}"
                )

            time.sleep(interval)
            interval = min(interval * 2, _CDP_POLL_MAX)


class AsyncSessionsResource:
    """Asynchronous session CRUD operations."""

    def __init__(self, http: Any) -> None:
        self._http = http

    async def create(
        self,
        *,
        browser_mode: str = "normal",
        proxy: ProxyConfig | ManagedProxyConfig | None = None,
        recording: RecordingConfig | None = None,
        fingerprint: FingerprintConfig | str | None = None,
        context: ContextAttach | None = None,
        **vendor_params: Any,
    ) -> SessionInfo:
        """Create a browser session (async).

        Returns a SessionInfo with cdp_url ready for connection.
        Polls for cdp_url if not immediately available (up to 30s).
        """
        body = _build_create_body(
            browser_mode, proxy, recording, fingerprint, context, vendor_params
        )
        data = await self._http.request("POST", "/api/session", json=body)

        session_id = data.get("id", "")

        if not data.get("wsEndpoint"):
            data = await self._poll_for_cdp_url(session_id)

        def _delete() -> None:
            # For async context manager, we need a sync shim.
            # Users should prefer explicit await client.sessions.delete().
            import asyncio

            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None

            if loop and loop.is_running():
                loop.create_task(self.delete(session_id))
            else:
                asyncio.run(self.delete(session_id))

        return _to_session_info(data, delete_fn=_delete)

    async def get(self, session_id: str) -> SessionInfo:
        """Get session info by ID (async)."""
        data = await self._http.request("GET", f"/api/session/{session_id}")
        return _to_session_info(data)

    async def list(self, **filters: Any) -> list[SessionInfo]:
        """List sessions (async), optionally filtered."""
        params = filters if filters else None
        data = await self._http.request("GET", "/api/sessions", params=params)
        if isinstance(data, list):
            return [_to_session_info(item) for item in data]
        items = data.get("sessions") or data.get("items") or []
        return [_to_session_info(item) for item in items]

    async def delete(self, session_id: str) -> None:
        """Stop (close) a session (async). Idempotent — ignores 404."""
        try:
            await self._http.request("PUT", f"/api/session/{session_id}/stop")
        except SessionNotFoundError:
            pass

    async def _poll_for_cdp_url(self, session_id: str) -> dict[str, Any]:
        """Poll GET until wsEndpoint is available (async)."""
        import asyncio

        deadline = time.monotonic() + _CDP_POLL_TIMEOUT
        interval = _CDP_POLL_INITIAL

        while True:
            data = await self._http.request(
                "GET", f"/api/session/{session_id}"
            )
            if data.get("wsEndpoint"):
                return data

            if time.monotonic() + interval > deadline:
                raise TimeoutError(
                    f"cdp_url not available after {_CDP_POLL_TIMEOUT}s for session {session_id}"
                )

            await asyncio.sleep(interval)
            interval = min(interval * 2, _CDP_POLL_MAX)
