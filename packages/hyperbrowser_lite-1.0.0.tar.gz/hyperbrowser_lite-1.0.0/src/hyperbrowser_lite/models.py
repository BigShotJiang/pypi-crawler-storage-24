"""Data models for cloud browser SDK."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Callable

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Status mapping: Hyperbrowser → spec
# ---------------------------------------------------------------------------

_STATUS_MAP: dict[str, str] = {
    # Hyperbrowser already uses spec-aligned statuses.
    # This map exists only for forward-compatibility if new statuses appear.
    "active": "active",
    "closed": "closed",
    "error": "error",
}


def map_status(hyperbrowser_status: str) -> str:
    """Map a Hyperbrowser status string to the unified spec status.

    Hyperbrowser natively uses "active", "closed", "error" — so this is
    effectively a pass-through.
    """
    return _STATUS_MAP.get(hyperbrowser_status, hyperbrowser_status)


# ---------------------------------------------------------------------------
# Configuration models
# ---------------------------------------------------------------------------


class ManagedProxyConfig(BaseModel):
    """Managed proxy configuration — provider handles the proxy.

    Hyperbrowser supports 200+ countries via ISO country codes directly.
    """

    country: str
    city: str | None = None


class ProxyConfig(BaseModel):
    """Custom proxy configuration (server + credentials).

    Hyperbrowser supports custom proxy servers via proxyServer params.
    """

    server: str
    username: str | None = None
    password: str | None = None


class RecordingConfig(BaseModel):
    """Recording configuration."""

    enabled: bool = True


class ViewportConfig(BaseModel):
    """Viewport dimensions."""

    width: int = 1920
    height: int = 1080
    device_scale_factor: float = 1.0
    is_mobile: bool = False


class FingerprintConfig(BaseModel):
    """Browser fingerprint configuration. All fields optional."""

    user_agent: str | None = None
    viewport: ViewportConfig | None = None
    locale: str | None = None
    timezone: str | None = None
    webgl_vendor: str | None = None
    webgl_renderer: str | None = None
    platform: str | None = None


class ContextAttach(BaseModel):
    """Context attachment for session creation."""

    context_id: str
    mode: str = "read_write"


# ---------------------------------------------------------------------------
# SessionInfo
# ---------------------------------------------------------------------------


class SessionInfo(BaseModel):
    """Browser session information returned by create/get/list."""

    session_id: str
    cdp_url: str | None = None
    status: str = "active"
    created_at: datetime | None = None
    inspect_url: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    # Internal: deletion callback for context manager support.
    # Excluded from serialization.
    _delete_fn: Callable[[], None] | None = None

    model_config = {"arbitrary_types_allowed": True}

    def set_delete_fn(self, fn: Callable[[], None]) -> None:
        """Attach a deletion callback for context manager support."""
        object.__setattr__(self, "_delete_fn", fn)

    # --- Context manager protocol ---

    def __enter__(self) -> "SessionInfo":
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        fn = getattr(self, "_delete_fn", None)
        if fn is not None:
            fn()
