"""Hyperbrowser Cloud Browser SDK — minimal interface for browser session lifecycle.

Quick Start
-----------
::

    from hyperbrowser_lite import HyperbrowserCloud

    client = HyperbrowserCloud(api_key="hb-...")  # or set HYPERBROWSER_API_KEY env var

    # Create a cloud browser session
    session = client.sessions.create()
    print(session.cdp_url)   # wss://...
    print(session.session_id)

    # Use with Playwright (or any CDP client)
    # NOTE: Hyperbrowser CDP uses token-based wsEndpoint URLs — no auth headers needed.
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser = pw.chromium.connect_over_cdp(session.cdp_url)
        page = browser.contexts[0].new_page()
        page.goto("https://example.com")

    # Cleanup
    client.sessions.delete(session.session_id)

    # Or use context manager for auto-cleanup:
    with client.sessions.create() as session:
        ...  # session auto-deleted on exit

API Reference
-------------

Client Classes
~~~~~~~~~~~~~~
- ``HyperbrowserCloud(api_key, *, base_url, timeout, max_retries)``  — Sync client
- ``AsyncHyperbrowserCloud(api_key, *, base_url, timeout, max_retries)`` — Async client
- ``Hyperbrowser`` / ``AsyncHyperbrowser`` — Backward-compatible aliases

Client Properties
~~~~~~~~~~~~~~~~~
- ``client.sessions``     — SessionsResource for CRUD operations
- ``client.contexts``     — Always None (use profiles for persistence)
- ``client.capabilities`` — Returns ``["proxy", "fingerprint", "recording"]``

Session CRUD (``client.sessions``)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- ``create(*, browser_mode, proxy, recording, fingerprint, context, **vendor_params) -> SessionInfo``
- ``get(session_id) -> SessionInfo``
- ``list(**filters) -> list[SessionInfo]``
- ``delete(session_id) -> None``  (idempotent, safe to call multiple times)

Vendor Parameters (pass via ``**vendor_params`` in ``create()``)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- ``timeout_minutes: int``         — Session timeout in minutes
- ``solve_captchas: bool``         — Enable captcha solving
- ``adblock: bool``                — Enable ad blocking
- ``trackers: bool``               — Block trackers
- ``annoyances: bool``             — Block annoyances
- ``profile: dict``                — Session profile (``{"id": "..."}`` for persistence)
- ``extension_ids: list[str]``     — Browser extension IDs
- ``region: str``                  — Deploy region (e.g. ``"us-central"``)
- ``accept_cookies: bool``         — Auto-accept cookie banners
- ``browser_args: list[str]``      — Extra browser CLI arguments
- ``url_blocklist: list[str]``     — URLs to block
- ``save_downloads: bool``         — Persist downloaded files

Example with features::

    session = client.sessions.create(
        browser_mode="stealth",
        proxy=ManagedProxyConfig(country="US"),
        recording=RecordingConfig(enabled=True),
        fingerprint=FingerprintConfig(locale="en-US"),
        solve_captchas=True,
        adblock=True,
        timeout_minutes=30,
    )

Feature Support Matrix
~~~~~~~~~~~~~~~~~~~~~~
=========================  =========  ==================================================
Feature                    Supported  Notes
=========================  =========  ==================================================
Custom proxy server        Yes        ``ProxyConfig(server, username, password)``
Managed proxy (200+ ctry)  Yes        ``ManagedProxyConfig(country="US")``
Stealth mode               Yes        ``browser_mode="stealth"``
Ultra stealth mode         Yes        ``browser_mode="ultra_stealth"``
Browser fingerprint        Yes        ``FingerprintConfig(locale=..., viewport=...)``
Session recording          Yes        ``RecordingConfig(enabled=True)``
Captcha solving            Yes        ``solve_captchas=True``
Ad blocking                Yes        ``adblock=True``
Extensions                 Yes        ``extension_ids=[...]``
Region selection           Yes        ``region="us-central"``
Browser profiles           Yes        ``profile={"id": "..."}`` (vendor param)
Context persistence        No         Use profiles instead
=========================  =========  ==================================================

SessionInfo Fields
~~~~~~~~~~~~~~~~~~
- ``session_id: str``           — Unique session identifier
- ``cdp_url: str | None``       — CDP WebSocket URL (wss://)
- ``status: str``               — "active", "closed", or "error"
- ``created_at: datetime | None``
- ``inspect_url: str | None``   — Live view URL for debugging
- ``metadata: dict``            — Vendor-specific data (teamId, token, proxyDataConsumed, etc.)

Proxy Configuration
~~~~~~~~~~~~~~~~~~~
- ``ManagedProxyConfig(country="US")``                      — Managed proxy with country
- ``ManagedProxyConfig(country="US", city="New York")``     — Managed proxy with city
- ``ProxyConfig(server="http://proxy:8080")``               — Custom proxy server
- ``ProxyConfig(server, username="u", password="p")``       — Custom proxy with auth

CDP Authentication
~~~~~~~~~~~~~~~~~~
Hyperbrowser's CDP WebSocket endpoint uses token-based URLs (the ``wsEndpoint``
contains an embedded auth token). **No additional headers are needed** for the
WebSocket connection::

    browser = pw.chromium.connect_over_cdp(session.cdp_url)  # No headers needed

Exception Hierarchy
~~~~~~~~~~~~~~~~~~~
::

    CloudBrowserError          # Base exception
    ├── AuthenticationError    # 401/403 — invalid or expired API key
    ├── QuotaExceededError     # 429 — rate limit (has .retry_after attribute)
    ├── SessionNotFoundError   # 404 — session doesn't exist
    ├── ProviderError          # 5xx — server error (has .status_code, .request_id)
    ├── TimeoutError           # Operation timed out
    └── NetworkError           # Connection failure
"""

from .client import AsyncHyperbrowserCloud, HyperbrowserCloud
from .exceptions import (
    AuthenticationError,
    CloudBrowserError,
    NetworkError,
    ProviderError,
    QuotaExceededError,
    SessionNotFoundError,
    TimeoutError,
)
from .models import (
    ContextAttach,
    FingerprintConfig,
    ManagedProxyConfig,
    ProxyConfig,
    RecordingConfig,
    SessionInfo,
    ViewportConfig,
)

# Backward compatibility aliases
Hyperbrowser = HyperbrowserCloud
AsyncHyperbrowser = AsyncHyperbrowserCloud

__all__ = [
    # Clients
    "HyperbrowserCloud",
    "AsyncHyperbrowserCloud",
    "Hyperbrowser",
    "AsyncHyperbrowser",
    # Models
    "SessionInfo",
    "ContextAttach",
    "FingerprintConfig",
    "ViewportConfig",
    "ProxyConfig",
    "ManagedProxyConfig",
    "RecordingConfig",
    # Exceptions
    "CloudBrowserError",
    "AuthenticationError",
    "QuotaExceededError",
    "SessionNotFoundError",
    "ProviderError",
    "TimeoutError",
    "NetworkError",
]
