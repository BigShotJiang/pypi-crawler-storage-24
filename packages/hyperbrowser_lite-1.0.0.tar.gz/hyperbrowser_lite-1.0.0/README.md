# hyperbrowser-lite

Minimal Python SDK for [Hyperbrowser](https://www.hyperbrowser.ai/) cloud browser sessions. Only does one thing: **create a cloud browser, return a CDP URL, clean up when done**.

Part of the [cloud-browser-sdk-spec](https://github.com/ayanami-browser-pilot) unified interface for cloud browser providers.

## Install

```bash
pip install hyperbrowser-lite
```

## Quick Start

```python
from hyperbrowser_lite import HyperbrowserCloud

client = HyperbrowserCloud(api_key="hb-...")  # or set HYPERBROWSER_API_KEY env var

# Create a cloud browser session
session = client.sessions.create()
print(session.cdp_url)      # wss://connect-us-west-2.hyperbrowser.ai/?token=...
print(session.session_id)   # UUID

# Connect with Playwright
# Hyperbrowser CDP uses token-based URLs — no auth headers needed
from playwright.sync_api import sync_playwright

with sync_playwright() as pw:
    browser = pw.chromium.connect_over_cdp(session.cdp_url)
    page = browser.contexts[0].new_page()
    page.goto("https://example.com")
    print(page.title())

# Clean up
client.sessions.delete(session.session_id)
```

### Context Manager (auto-cleanup)

```python
with client.sessions.create() as session:
    # use session.cdp_url ...
    pass
# session automatically deleted on exit
```

### Async

```python
from hyperbrowser_lite import AsyncHyperbrowserCloud

async with AsyncHyperbrowserCloud(api_key="hb-...") as client:
    session = await client.sessions.create()
    print(session.cdp_url)
    await client.sessions.delete(session.session_id)
```

## API

### Client

```python
HyperbrowserCloud(api_key=None, *, base_url=None, timeout=60.0, max_retries=2)
AsyncHyperbrowserCloud(api_key=None, *, base_url=None, timeout=60.0, max_retries=2)
```

- `api_key` — defaults to `HYPERBROWSER_API_KEY` env var
- `base_url` — defaults to `https://api.hyperbrowser.ai`

### Sessions (`client.sessions`)

| Method | Description |
|--------|-------------|
| `create(**kwargs) -> SessionInfo` | Create cloud browser, returns CDP URL |
| `get(session_id) -> SessionInfo` | Get session status |
| `list(**filters) -> list[SessionInfo]` | List sessions |
| `delete(session_id) -> None` | Stop session (idempotent) |

### `create()` Parameters

```python
session = client.sessions.create(
    # Browser mode — controls anti-detection
    browser_mode="stealth",        # or "ultra_stealth" (enterprise), default "normal"

    # Proxy — managed or custom
    proxy=ManagedProxyConfig(country="US"),
    # proxy=ProxyConfig(server="http://proxy:8080", username="u", password="p"),

    # Recording — ON by default, explicitly enable/disable
    recording=RecordingConfig(enabled=True),

    # Fingerprint — locale and viewport
    fingerprint=FingerprintConfig(locale="en-US", viewport=ViewportConfig(1920, 1080)),

    # Vendor params
    solve_captchas=True,     # paid plan required
    adblock=True,            # block ads, faster page loads
    trackers=True,           # block tracking scripts
    annoyances=True,         # block cookie banners, newsletter popups
    timeout_minutes=30,
    extension_ids=["ext-123"],
    region="us-central",
)
```

### SessionInfo Fields

| Field | Type | Description |
|-------|------|-------------|
| `session_id` | `str` | Unique identifier (UUID) |
| `cdp_url` | `str \| None` | CDP WebSocket URL (`wss://connect-{region}.hyperbrowser.ai/?token=...`) |
| `status` | `str` | `"active"`, `"closed"`, or `"error"` |
| `created_at` | `datetime \| None` | Creation timestamp |
| `inspect_url` | `str \| None` | Live view URL — open in browser to watch session in real-time |
| `metadata` | `dict` | Vendor-specific data (see below) |

#### Metadata Contents

The `metadata` dict contains Hyperbrowser-specific fields from the API response:

| Key | Description |
|-----|-------------|
| `teamId` | Team identifier |
| `token` | JWT auth token (embedded in `cdp_url`) |
| `sessionUrl` | Dashboard URL for this session |
| `launchState` | Full launch configuration (see Feature Details below) |
| `proxyDataConsumed` | Proxy bandwidth consumed |
| `liveDomain` | WebSocket server domain |
| `webdriverEndpoint` | WebDriver protocol endpoint |
| `computerActionEndpoint` | Computer action API endpoint |

### CDP WebSocket Authentication

Hyperbrowser's CDP WebSocket endpoint uses **token-based URLs** — the `wsEndpoint` contains an embedded JWT token. **No additional headers are needed**:

```python
# Playwright — just connect directly
browser = pw.chromium.connect_over_cdp(session.cdp_url)

# Works with any CDP client (Playwright, Puppeteer, Selenium, raw websockets)
```

This is different from providers like Skyvern which require `x-api-key` headers on the WebSocket handshake.

## Feature Details

All features are verified against the live Hyperbrowser API. The `launchState` in `metadata` confirms which features are active.

### Stealth Mode (`browser_mode="stealth"`)

Hides browser automation fingerprints so anti-bot systems cannot easily detect the session:
- `navigator.webdriver` returns `false`
- Chrome DevTools Protocol detection signatures are masked
- Other automation hints are suppressed

**Verified**: `launchState.useStealth` changes from `false` to `true`. Available on free plan.

### Ultra Stealth Mode (`browser_mode="ultra_stealth"`)

Enhanced stealth with additional anti-detection measures beyond standard stealth.

**Requires enterprise plan** — returns HTTP 402 on free plan.

### Recording (`RecordingConfig`)

Records DOM mutations during the session (similar to [rrweb](https://github.com/rrweb-io/rrweb)). After the session ends, the recording can be retrieved via the Hyperbrowser dashboard or API for playback.

**Important**: Recording is **enabled by default** (`enableWebRecording: true`). Passing `RecordingConfig(enabled=True)` is redundant unless you previously disabled it. Video recording (`enableVideoWebRecording`) is a separate feature and is off by default.

### Ad Blocking (`adblock=True`)

Built-in ad blocker that removes ads (banners, popups, video ads) from pages:
- Faster page loads — fewer network requests
- Cleaner pages — no ad popups interfering with automation
- Less bandwidth — reduces `proxyDataConsumed`

Related options: `trackers=True` (blocks tracking scripts), `annoyances=True` (blocks cookie banners, newsletter popups).

**Verified**: `launchState.adblock` changes to `true`. Available on free plan.

### Captcha Solving (`solve_captchas=True`)

Automatically solves CAPTCHAs encountered during browsing.

**Requires paid plan** — returns HTTP 402 on free plan.

### Feature Support Matrix

| Feature | Free Plan | Paid Plan | Enterprise | Usage |
|---------|-----------|-----------|------------|-------|
| Custom proxy server | ? | ? | ? | `ProxyConfig(server=...)` |
| Managed proxy (200+ countries) | ? | ? | ? | `ManagedProxyConfig(country="US")` |
| Stealth mode | Yes | Yes | Yes | `browser_mode="stealth"` |
| Ultra stealth mode | No | No | Yes | `browser_mode="ultra_stealth"` |
| Browser fingerprint | Yes | Yes | Yes | `FingerprintConfig(locale=..., viewport=...)` |
| Session recording (DOM) | Yes (default ON) | Yes | Yes | `RecordingConfig(enabled=True)` |
| Video recording | ? | ? | ? | Vendor param: `enable_video_web_recording=True` |
| Captcha solving | No | Yes | Yes | `solve_captchas=True` |
| Ad blocking | Yes | Yes | Yes | `adblock=True` |
| Tracker blocking | Yes | Yes | Yes | `trackers=True` |
| Annoyance blocking | Yes | Yes | Yes | `annoyances=True` |
| Extensions | Yes | Yes | Yes | `extension_ids=[...]` |
| Region selection | Yes | Yes | Yes | `region="us-central"` |
| Browser profiles | Yes | Yes | Yes | `profile={"id": "..."}` |
| Context persistence | N/A | N/A | N/A | Use profiles instead |

> `?` = not tested (requires proxy configuration / paid features)

### Exceptions

```
CloudBrowserError
├── AuthenticationError     # 401/403 — invalid or expired API key
├── QuotaExceededError      # 429 — rate limit (has .retry_after)
├── SessionNotFoundError    # 404 — session not found
├── ProviderError           # 5xx — server error (has .status_code, .request_id)
├── TimeoutError            # Operation timeout
└── NetworkError            # Connection failure
```

Note: Plan-restricted features return **HTTP 402** (mapped to `CloudBrowserError`), not 403.

### Backward Compatibility

```python
from hyperbrowser_lite import Hyperbrowser       # alias for HyperbrowserCloud
from hyperbrowser_lite import AsyncHyperbrowser  # alias for AsyncHyperbrowserCloud
```

## License

MIT
