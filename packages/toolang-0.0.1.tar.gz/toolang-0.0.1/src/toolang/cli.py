from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence

from toolang import __version__


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="toolang", description="toolang")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = list(sys.argv[1:] if argv is None else argv)
    parser.parse_args(args)

    if not args:
        parser.print_help()

    return 0
