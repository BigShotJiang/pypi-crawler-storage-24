# toolang

toolang

## Install

```bash
pip install toolang
```

## Usage

```bash
toolang
toolang --help
toolang --version
```
