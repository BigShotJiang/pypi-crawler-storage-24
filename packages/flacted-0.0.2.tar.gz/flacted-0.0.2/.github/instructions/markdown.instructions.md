---
applyTo: '**/*.md'
---

# Markdown guidelines

- `MD033`: `<kbd>` tags are allowed. Other raw HTML is not.
- `MD024`: Headers do not have to be unique if they are in different sections.
- Line length limit is 100 characters. Does not apply to tables.
- Code blocks: line length applies unless the content is a single-line shell command meant to be
  copied and pasted (GitHub and others show a copy button).
- Word-wrap prose at 100 characters. Do not break inside inline code, links, or URLs.
- Run `yarn prettier -w` before `yarn markdownlint-cli2` - prettier fixes tables, trailing
  whitespace, and other structural issues automatically.
- Do not disable rules with `<!-- markdownlint-disable -->` comments unless there is no other way
  to satisfy the rule.
- Spell-check with `yarn cspell`.
- CHANGELOG follows Keep a Changelog format with reverse-chronological versions and sections: Added,
  Changed, Fixed, Removed.
