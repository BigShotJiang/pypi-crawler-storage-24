"""Reserved namespace. See https://pypi.org/project/pmtvs/"""
__version__ = "0.0.2"
