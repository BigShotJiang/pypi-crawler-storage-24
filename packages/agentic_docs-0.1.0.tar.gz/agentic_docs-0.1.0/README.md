# agentic-docs

A truly agentic, CI-native API documentation system powered by Claude.

It watches your feature branches, detects API changes through structured git diff analysis, and automatically generates accurate Word + Markdown documentation — with Claude driving every decision via native tool-use, zero hallucination, and zero manual effort.

---

## What problem does this solve?

In most engineering teams, API documentation is written manually, updated inconsistently, and drifts away from the actual code within weeks. This system eliminates that entirely:

- **No manual doc writing.** Push a branch → docs are generated automatically.
- **No hallucination.** Claude only sees structured JSON extracted from your diff — never the full repo.
- **No stale docs.** Every merge to your development branch triggers a fresh, grounded documentation run.
- **Truly agentic.** Claude decides which tools to call, in what order, whether to retry, and when it is done — not hardcoded `if/else` logic.
- **Self-improving.** The agent stores and retrieves insights across runs via semantic memory — naming conventions, auth patterns, and style preferences accumulate over time.
- **Quality-assured.** A built-in critic agent and quality evaluator score drafts before they're written, catching issues beyond structural validation.
- **Enterprise-safe.** Output is validated against structured data before any file is written.

---

## What does it generate?

For every feature branch with API changes, it produces two files inside your target repo's `docs/` folder:

```
docs/
├── payment-v2-api-docs.md    ← Markdown (readable anywhere)
└── payment-v2-api-docs.docx  ← Word document (enterprise-ready)
```

The document contains only the sections relevant to the changes:

```
# Feature: payment-v2

## Overview
## New APIs
## Modified APIs
## Removed APIs
## Contract Changes
## Authentication Impact
## Frontend Impact
## Backward Compatibility
## Migration Notes
```

---

## Supported Frameworks

The extractor layer detects API changes in:

| Framework | Language | Detection method |
|-----------|----------|-----------------|
| **Django** | Python | `path()`, `re_path()` URL patterns, DRF `@api_view`, `ViewSet`, `router.register()` |
| **FastAPI** | Python | `@app.get`, `@router.post` decorator patterns, Pydantic model extraction |
| **Flask** | Python | `@app.route()`, `@app.get()` / `@bp.post()` shorthand (Flask 2.0+), `add_url_rule()` |

---

## What makes this agentic

Most "AI-powered" documentation tools are just prompt wrappers — you feed them code, they return text. This system is different in five concrete ways.

### 1. It plans its own work

The agent is given a goal, not a script. On every run it calls `create_plan` to decide its own goal and steps. If it discovers something unexpected mid-run (a framework it didn't anticipate, auth changes it missed), it calls `revise_plan` and adjusts — no fixed sequence imposed from outside.

```
Traditional automation:   step 1 → step 2 → step 3 → write output
This agent:               goal → plan → discover → revise plan → discover more → write output
```

### 2. It decides which tools to use and when

The agent has 14 tools available. It chooses which ones to call, in what order, and how many times — based on what it observes, not a hardcoded call sequence. A run with only FastAPI changes will never call the Django extractor. A run where the diff is self-explanatory skips `read_file` entirely. Nothing is called unless Claude decides it's needed.

### 3. It self-evaluates and fixes its own errors

Before writing anything, Claude submits its draft to a **Critic agent** (a separate Claude instance) for quality scores across five dimensions, and to an **Evaluator** for developer experience scoring. It reads the feedback and revises.

Then it runs `validate_documentation` — a deterministic rule engine that checks for invented endpoints, speculative language, and missing headers. If validation fails, Claude reads the specific errors, figures out which part of the draft caused them, fixes only those parts, and re-validates. It does not start over.

```
draft → critic scores → revise → evaluate → revise → validate → fix errors → validate → write
```

### 4. It remembers and learns across runs

Every run updates `.agent/skills/` — a set of Markdown files that accumulate naming conventions, auth patterns, versioning decisions, and endpoint changelogs. Before the next run starts, the agent auto-searches this memory using keywords from the branch name and changed files, and injects relevant sections into its context.

Over time the agent gets better at your codebase — it knows your naming conventions, your auth strategy, your documentation style — without any manual configuration.

### 5. It decides when it is done (including "nothing to do")

The loop only ends when Claude calls a terminal tool. If no API-related files changed, Claude calls `signal_no_change` and exits cleanly — no files written, no tokens wasted on drafting. If it reaches the turn limit without calling a terminal tool, the run fails rather than producing partial output.

There is no implicit "done" state. The agent is always responsible for its own termination.

---

### What this is NOT

| Characteristic | Traditional script | This agent |
|---|---|---|
| Execution model | Fixed steps, hardcoded order | Goal-driven, dynamic tool selection |
| Error handling | Try/catch, retry same action | Reads errors, reasons about cause, fixes specifically |
| Output quality | Whatever the prompt produces | Critic-reviewed, evaluator-scored, validator-checked |
| Memory | Stateless per run | Persistent skill memory, improves over time |
| Decision to skip | `if len(changes) == 0: return` | Claude observes the delta and decides `signal_no_change` |
| Sub-agents | None | Spawns Critic and Evaluator when it judges quality checks are needed |

---

## How the agent works

The system is genuinely agentic: Claude drives the loop via Anthropic's native tool-use API. It decides which tools to call, in what order, whether to retry on validation failure, and when it is done.

### System overview

There are **three Claude-powered actors** in the system. The Primary Agent is the only true agent — it has tools, state, and a multi-turn loop. The Critic and Evaluator are stateless, single-shot LLM-as-judge calls that the Primary Agent invokes through its tools when it decides a quality check is needed.

---

#### 1. Primary Agent (the documentation agent)

| Property | Value |
|----------|-------|
| **File** | `core/agent_loop.py` |
| **Model** | `claude-opus-4-6` (configurable via `model` in config) |
| **Type** | Multi-turn, tool-using autonomous agent |
| **Max turns** | 20 (configurable via `maxTurns`) |
| **Tools** | 14 tools across 5 categories |

**What it does:**
This is the brain of the system. It receives a goal-oriented system prompt and 14 tools, then autonomously decides how to approach the documentation task. It plans its own steps, explores the codebase, extracts API changes, searches memory for past patterns, drafts documentation, requests quality reviews, validates against ground truth, and writes the final output.

**Inputs:**

| Input | Source | Description |
|-------|--------|-------------|
| System prompt | `core/agent_loop.py` | Goal-oriented instructions with hard rules (no hallucination, feature header required, etc.) |
| Branch name | `git` via `Orchestrator` | e.g. `feature/payment-v2` — used for context and feature name derivation |
| Base branch | Config (`baseBranch`) | e.g. `main` — the branch to diff against |
| Auto-context | `MemoryManager.get_auto_context()` | Keywords from branch name and file paths are used to pre-search memory; relevant sections are injected into the first message |
| 14 tool definitions | `core/tools/definitions.py` | Tool schemas sent to Claude via Anthropic's native tool-use API |

**Outputs:**

| Output | Description |
|--------|-------------|
| `GENERATED` | Documentation was written — `.md` + `.docx` files produced |
| `NO_API_CHANGE` | No API changes found — no files written |
| `FAILED` | Error occurred (API failure, max turns exceeded, agent ended without terminal tool) |
| Token usage | Cumulative `inputTokens` + `outputTokens` across all turns |

**State accumulated across turns** (held in `ToolExecutor`):
- `changed_files` — list of API-related changed files
- `merged_delta` — accumulated `ExtractedApiDelta` from all `extract_api_changes` calls
- `plan` — goal + steps + revision count

---

#### 2. Critic Agent

| Property | Value |
|----------|-------|
| **File** | `core/critic.py` |
| **Model** | `claude-sonnet-4-20250514` (lighter, cheaper) |
| **Type** | Single-shot LLM call (no tools, no loop, no state) |
| **Triggered by** | Primary Agent calling the `critique_documentation` tool |

**What it does:**
Receives a documentation draft and the API delta (ground truth), then evaluates the draft on five quality dimensions. Returns structured scores and actionable suggestions. The Primary Agent uses this feedback to improve the draft before final validation.

**Inputs:**

| Input | Source | Description |
|-------|--------|-------------|
| Critic system prompt | `core/critic.py` | Instructions to evaluate completeness, clarity, accuracy, structure, tone |
| Documentation draft | Primary Agent (via tool call) | The markdown draft to review |
| API delta (JSON) | `ToolExecutor._merged_delta` serialized | The ground truth delta so the critic can check accuracy |

**Output (JSON):**

```json
{
    "scores": {
        "completeness": 8,
        "clarity": 9,
        "accuracy": 7,
        "structure": 8,
        "tone": 9
    },
    "overallScore": 8,
    "suggestions": [
        "Add request body schema for POST /api/payments",
        "Include error response codes for the DELETE endpoint"
    ],
    "summary": "Well-structured draft with minor completeness gaps."
}
```

| Dimension | What it measures |
|-----------|-----------------|
| **Completeness** | Are all endpoints documented with request/response details? |
| **Clarity** | Is the writing clear, concise, and unambiguous? |
| **Accuracy** | Does the documentation match the API delta (no invented details)? |
| **Structure** | Is the document well-organized with consistent formatting? |
| **Tone** | Is the tone professional and appropriate for developer docs? |

---

#### 3. Quality Evaluator

| Property | Value |
|----------|-------|
| **File** | `core/evaluator.py` |
| **Model** | `claude-sonnet-4-20250514` (lighter, cheaper) |
| **Type** | Single-shot LLM call (no tools, no loop, no state) |
| **Triggered by** | Primary Agent calling the `evaluate_quality` tool |

**What it does:**
Evaluates the documentation from a developer experience perspective — is it useful for someone integrating this API? Optionally loads existing docs from the output directory and checks whether the new documentation matches the established style.

**Inputs:**

| Input | Source | Description |
|-------|--------|-------------|
| Evaluator system prompt | `core/evaluator.py` | Instructions to score audience fit, completeness, code examples, consistency |
| Documentation draft | Primary Agent (via tool call) | The markdown to evaluate |
| Existing docs (optional) | `docs/*.md` files on disk | When `compareWithExisting: true`, up to 5000 chars of existing markdown docs are loaded for style comparison |

**Output (JSON):**

```json
{
    "qualityScore": 7,
    "dimensions": {
        "targetAudienceFit": 8,
        "completeness": 7,
        "codeExamples": 5,
        "consistency": 8,
        "styleConsistency": 7
    },
    "suggestions": [
        "Add cURL examples for the new endpoints",
        "Include response time expectations for bulk operations"
    ],
    "summary": "Good developer-facing documentation, would benefit from code examples."
}
```

| Dimension | What it measures |
|-----------|-----------------|
| **Target Audience Fit** | Is it appropriate for developers integrating this API? |
| **Completeness** | Are all endpoints, parameters, and responses documented? |
| **Code Examples** | Are there useful, correct code examples or cURL snippets? |
| **Consistency** | Is formatting, naming, and style consistent throughout? |
| **Style Consistency** | Does the new doc match the style of existing docs? (only when comparing) |

---

#### How the agents interact

```
┌──────────────────────────────────────────────────────────┐
│                    PRIMARY AGENT                         │
│                    (claude-opus-4-6)                      │
│                                                          │
│  Multi-turn loop · 14 tools · stateful                   │
│                                                          │
│  The Primary Agent decides IF and WHEN to call           │
│  the Critic and Evaluator. They are tools, not           │
│  autonomous actors.                                      │
│                                                          │
│       ┌──────────────────┐    ┌──────────────────┐       │
│       │ critique_        │    │ evaluate_        │       │
│       │ documentation    │    │ quality          │       │
│       │ (tool call)      │    │ (tool call)      │       │
│       └────────┬─────────┘    └────────┬─────────┘       │
└────────────────│──────────────────────│───────────────────┘
                 │                      │
        ┌────────▼─────────┐   ┌────────▼─────────┐
        │  CRITIC AGENT    │   │  QUALITY          │
        │  (claude-sonnet) │   │  EVALUATOR        │
        │                  │   │  (claude-sonnet)  │
        │  IN:             │   │                   │
        │  • draft markdown│   │  IN:              │
        │  • API delta JSON│   │  • draft markdown │
        │                  │   │  • existing docs  │
        │  OUT:            │   │    (optional)     │
        │  • 5 scores      │   │                   │
        │  • suggestions   │   │  OUT:             │
        │  • summary       │   │  • quality score  │
        │                  │   │  • 4-5 dim scores │
        │  No tools.       │   │  • suggestions    │
        │  No loop.        │   │  • summary        │
        │  No state.       │   │                   │
        │  One call in,    │   │  No tools.        │
        │  one response    │   │  No loop.         │
        │  out.            │   │  No state.        │
        └──────────────────┘   └───────────────────┘
```

### Flow diagram

```
                            ┌─────────────────┐
                            │  PR merged into  │
                            │  development     │
                            └────────┬────────┘
                                     │
                                     ▼
                          ┌─────────────────────┐
                          │   CI / CLI trigger   │
                          │   (bin/cli.py)       │
                          └────────┬────────────┘
                                   │
                                   ▼
                    ┌──────────────────────────────┐
                    │      Orchestrator (L5)        │
                    │  1. Init skill memory         │
                    │  2. Resolve branch name       │
                    │  3. Wire ToolExecutor +       │
                    │     AgentLoop                 │
                    └──────────────┬───────────────┘
                                   │
                          ┌────────▼────────┐
                          │  Auto-Context    │
                          │  Retrieval       │
                          │  (branch name +  │
                          │  file keywords → │
                          │  search memory)  │
                          └────────┬────────┘
                                   │
          ┌────────────────────────▼─────────────────────────┐
          │                                                  │
          │         PRIMARY AGENT (claude-opus-4-6)          │
          │         Multi-turn loop · max 20 turns           │
          │         14 tools available                       │
          │                                                  │
          │  ┌─────────────────────────────────────────────┐ │
          │  │  PHASE 1: Planning                          │ │
          │  │  ┌───────────┐                              │ │
          │  │  │create_plan│ → goal + ordered steps       │ │
          │  │  └───────────┘                              │ │
          │  └─────────────────────────────────────────────┘ │
          │                       │                          │
          │                       ▼                          │
          │  ┌─────────────────────────────────────────────┐ │
          │  │  PHASE 2: Exploration & Extraction          │ │
          │  │                                             │ │
          │  │  get_changed_files                          │ │
          │  │       │                                     │ │
          │  │       ▼                                     │ │
          │  │  extract_api_changes (per framework)        │ │
          │  │       │          ┌──────────────┐           │ │
          │  │       ├─────────►│ L2 Extractor │ (ground   │ │
          │  │       │          │ (no LLM)     │  truth)   │ │
          │  │       │          └──────────────┘           │ │
          │  │       ▼                                     │ │
          │  │  read_file / search_codebase (optional)     │ │
          │  │       → supplementary context only          │ │
          │  └─────────────────────────────────────────────┘ │
          │                       │                          │
          │                       ▼                          │
          │  ┌─────────────────────────────────────────────┐ │
          │  │  PHASE 3: Memory                            │ │
          │  │                                             │ │
          │  │  search_memory → ranked past patterns       │ │
          │  │  read_memory   → full skill file            │ │
          │  │  store_memory  → save new insights          │ │
          │  └─────────────────────────────────────────────┘ │
          │                       │                          │
          │              ┌────────▼────────┐                 │
          │              │ API changes     │                 │
          │              │ found?          │                 │
          │              └───┬─────────┬───┘                 │
          │              No  │         │  Yes                │
          │                  ▼         ▼                     │
          │    ┌──────────────┐  ┌──────────────────────┐    │
          │    │signal_no_    │  │ Draft documentation  │    │
          │    │change        │  └──────────┬───────────┘    │
          │    │              │             │                │
          │    │  (TERMINAL)  │             ▼                │
          │    └──────────────┘  ┌──────────────────────┐    │
          │                     │ PHASE 4: Quality Loop │    │
          │                     │                       │    │
          │                     │         ┌─────────────┤    │
          │                     │         │             │    │
          │                     │         ▼             │    │
          │                     │  ┌─────────────┐     │    │
          │                     │  │  critique_   │     │    │
          │                     │  │  documenta-  │─ ─ ─│─ ─ ─ ─ ┐
          │                     │  │  tion        │     │    │    │
          │                     │  └──────┬──────┘     │    │    │
          │                     │         │            │    │    ▼
          │                     │         ▼            │    │  ┌─────────────────┐
          │                     │  ┌─────────────┐    │    │  │  CRITIC AGENT   │
          │                     │  │ evaluate_   │    │    │  │  (claude-sonnet) │
          │                     │  │ quality     │─ ─ │─ ─ │──│                 │
          │                     │  └──────┬──────┘    │    │  │  Single-shot    │
          │                     │         │           │    │  │  Returns:       │
          │                     │         ▼           │    │  │  • scores (1-10)│
          │                     │  ┌─────────────┐   │    │  │  • suggestions  │
          │                     │  │ validate_   │   │    │  └─────────────────┘
          │                     │  │ documenta-  │   │    │
          │                     │  │ tion        │   │    │  ┌─────────────────┐
          │                     │  └──┬──────┬───┘   │    │  │  QUALITY        │
          │                     │     │      │       │    │  │  EVALUATOR      │
          │                     │     │ Errors?      │    │  │  (claude-sonnet) │
          │                     │     │      │       │    │  │                 │
          │                     │   Valid  Has       │    │  │  Single-shot    │
          │                     │     │   errors     │    │  │  Returns:       │
          │                     │     │      │       │    │  │  • quality score│
          │                     │     │      ▼       │    │  │  • dimensions   │
          │                     │     │ ┌──────────┐ │    │  │  • suggestions  │
          │                     │     │ │revise_   │ │    │  └─────────────────┘
          │                     │     │ │plan +    │ │    │
          │                     │     │ │fix draft │ │    │
          │                     │     │ └────┬─────┘ │    │
          │                     │     │      └───────┘    │
          │                     │     │   (retry loop)    │
          │                     │     │                   │
          │                     └─────│───────────────────┘
          │                           │                     │
          │                           ▼                     │
          │                  ┌──────────────────┐           │
          │                  │write_documentation│           │
          │                  │                  │           │
          │                  │   (TERMINAL)     │           │
          │                  └──────────────────┘           │
          │                                                 │
          └─────────────────────────────────────────────────┘
                                   │
                                   ▼
                    ┌──────────────────────────────┐
                    │   Document Generator (L7)     │
                    │   → feature-api-docs.md       │
                    │   → feature-api-docs.docx     │
                    └──────────────┬───────────────┘
                                   │
                                   ▼
                    ┌──────────────────────────────┐
                    │   Auto-commit & push          │
                    │   (if autoCommit: true)       │
                    └──────────────────────────────┘
```

### Tool catalogue

Claude has access to **14 tools** across five categories:

#### Exploration & Analysis

| Tool | Description |
|------|-------------|
| `get_changed_files` | Returns API-related changed files with diff previews |
| `extract_api_changes` | Runs a framework extractor; returns structured JSON delta. Results accumulate across calls |
| `read_file` | Reads any file in the repo with line offset/limit. Path traversal protected |
| `search_codebase` | Regex search across repo files with glob filter. Skips `.git`, `node_modules`, etc. |

#### Planning

| Tool | Description |
|------|-------------|
| `create_plan` | Agent formulates a goal and ordered steps. Stored in executor state |
| `revise_plan` | Agent revises steps mid-execution with a reason. Tracks revision count |

#### Memory

| Tool | Description |
|------|-------------|
| `read_memory` | Returns one skill file capped at 3 000 chars |
| `search_memory` | Keyword-based search across all skill files. Returns ranked sections |
| `store_memory` | Agent stores insights (naming conventions, patterns, decisions) for future runs |

#### Quality Assurance

| Tool | Description |
|------|-------------|
| `validate_documentation` | Validates draft against the delta; returns `valid`, `errors[]`, `warnings[]` |
| `critique_documentation` | Separate Claude instance scores completeness, clarity, accuracy, structure, tone (1-10 each) |
| `evaluate_quality` | LLM-based scoring for audience fit, completeness, code examples, consistency. Optional style comparison |

#### Terminal Actions

| Tool | Description |
|------|-------------|
| `write_documentation` | **Terminal.** Writes `.md` + `.docx`, updates memory. Loop exits after this |
| `signal_no_change` | **Terminal.** Claude calls when no API changes found. Loop exits |

### Decisions Claude makes

Rather than following a fixed script, Claude reasons at each step and makes real choices:

**How to approach the task**
Claude creates its own plan with `create_plan`, deciding the goal and steps. When it discovers new information mid-run, it calls `revise_plan` to adjust — no rigid sequence imposed from outside.

**Which frameworks to extract**
After seeing the changed file list, the agent picks which `extract_api_changes` calls to make. A branch with Django URL patterns gets only the `django` extractor called — Flask and FastAPI are skipped entirely.

**Whether to explore beyond the diff**
Claude can `read_file` to understand how an endpoint works or `search_codebase` to find related types, middleware, or auth configuration. L2 extraction remains the ground truth — these tools provide supplementary context.

**Whether to consult memory**
Claude searches skill memory with `search_memory` for relevant patterns, or reads specific files with `read_memory`. It also stores new insights with `store_memory` — naming conventions, auth strategies, and documentation preferences accumulate across runs.

**Whether any documentation is needed at all**
If `extract_api_changes` returns empty deltas across all frameworks, Claude calls `signal_no_change` and the loop exits cleanly — no files written, no API cost beyond the extraction turns.

**What sections to include**
Claude omits sections that have no data. A branch with only new endpoints produces no "Removed APIs" or "Migration Notes" sections. A branch with only auth changes produces no "New APIs" section.

**How to improve quality before writing**
Claude can submit drafts to `critique_documentation` for a critic review (scores 1-10 on five dimensions) and `evaluate_quality` for quality scoring. It uses this feedback to refine the documentation before final validation.

**How to fix validation errors**
When `validate_documentation` returns errors — an invented endpoint, a missing `# Feature:` header, speculative language — Claude reads the error list, revises the specific parts of its draft that caused them, and re-validates. It does not re-run extraction or restart; it reasons about the diff between what it wrote and what the validator rejected.

**When it is done**
The loop ends only when Claude calls a terminal tool (`write_documentation` or `signal_no_change`). If it reaches `end_turn` without doing so, the run fails — there is no implicit "done" state imposed from outside.

### Agentic capabilities

| Capability | How it works |
|------------|-------------|
| **Goal-based planning** | Claude creates and revises its own plan (`create_plan`, `revise_plan`) |
| **Codebase exploration** | Claude reads files and searches code beyond the diff (`read_file`, `search_codebase`) |
| **Semantic memory** | Claude searches, reads, and stores insights across runs (`search_memory`, `store_memory`) |
| **Auto-context retrieval** | Branch name and file paths are used to auto-retrieve relevant memory before the loop starts |
| **Multi-agent critique** | A separate Claude instance reviews drafts for quality (`critique_documentation`) |
| **Self-evaluation** | LLM-based quality scoring with style consistency checks (`evaluate_quality`) |
| **Dynamic tool selection** | Claude decides which tools to call and in what order based on what it observes |
| **Self-directed retry** | Claude receives validation errors and reasons about how to fix them |

---

## Requirements

- Python >= 3.10
- Git (must be run inside a git repository)
- An LLM API key — [Anthropic](https://console.anthropic.com/), [OpenAI](https://platform.openai.com/), [DeepSeek](https://platform.deepseek.com/), [Groq](https://console.groq.com/), [Mistral](https://console.mistral.ai/), or any OpenAI-compatible provider
- (Optional) A private Git repo for shared global memory across projects

---

## Quick Start

Everything needed to go from zero to auto-generated docs on every feature merge.

### Step 1 — Install the package

```bash
# Anthropic (Claude)
pip install agentic-docs[anthropic]

# OpenAI / DeepSeek / Groq / Mistral / any OpenAI-compatible provider
pip install agentic-docs[openai]

# Both providers
pip install agentic-docs[all]
```

### Step 2 — Set environment variables

Set these in your shell (local) or as CI secrets (GitHub Actions):

```bash
# Required
export AGENTIC_DOCS_PROVIDER=anthropic          # or: openai, deepseek, groq, mistral, ...
export AGENTIC_DOCS_MODEL=claude-opus-4-6       # or: gpt-4o, deepseek-chat, ...
export AGENTIC_DOCS_MAX_INPUT_TOKENS=100000
export AGENTIC_DOCS_MAX_OUTPUT_TOKENS=8000
export ANTHROPIC_API_KEY=sk-ant-...             # matches your provider

# Optional — override defaults
export AGENTIC_DOCS_BASE_BRANCH=development     # branch to diff against (default: main)
export AGENTIC_DOCS_OUTPUT_DIR=docs             # where to write .md + .docx (default: docs)
```

### Step 3 — Initialise your repository

Run this **once** inside the repo you want to document:

```bash
cd my-api-project
agentic-docs init
```

This creates the skill memory directory and output directory:

```
my-api-project/
├── .agent/
│   └── skills/
│       ├── agentic-system-master.md   ← run history
│       ├── api-patterns.md            ← endpoint changelog memory
│       ├── auth-patterns.md           ← auth convention memory
│       └── versioning.md              ← version change memory
└── docs/                              ← generated .md and .docx files go here
```

> Commit `.agent/skills/` to git — it is the agent's persistent memory and improves quality across runs.

### Step 4 — Add the GitHub Actions workflow

Copy the template into your target repository:

```bash
mkdir -p .github/workflows
cp /path/to/vidura-document-agent-py/templates/github-action.yml \
   .github/workflows/agentic-docs.yml
```

Then edit the `branches` list to match your team's predefined target branch:

```yaml
on:
  pull_request:
    types: [closed]
    branches:
      - development   # ← your target branch here
```

### Step 5 — Add secrets and variables in GitHub

Go to your repository → **Settings → Secrets and variables → Actions**:

| Type | Name | Value |
|------|------|-------|
| Secret | `ANTHROPIC_API_KEY` | your API key |
| Variable | `AGENTIC_DOCS_PROVIDER` | `anthropic` |
| Variable | `AGENTIC_DOCS_MODEL` | `claude-opus-4-6` |
| Variable | `AGENTIC_DOCS_MAX_INPUT_TOKENS` | `100000` |
| Variable | `AGENTIC_DOCS_MAX_OUTPUT_TOKENS` | `8000` |

### Step 6 — Merge a feature branch

```bash
git checkout -b feature/payment-v2
# make your API changes ...
git push origin feature/payment-v2
# open a PR → squash merge into development
```

The Action fires automatically. Within minutes, `docs/payment-v2-api-docs.md` and `docs/payment-v2-api-docs.docx` are committed to `development`.

---

## Packaging

This tool is distributed as a Python package. To package it from source:

```bash
# Clone / navigate to the project
cd vidura-document-agent-py

# Install build tools
pip install build

# Build source distribution + wheel
python -m build
# Produces: dist/agentic_docs-0.1.0.tar.gz and dist/agentic_docs-0.1.0-py3-none-any.whl
```

To publish to a package registry:

```bash
# Install twine
pip install twine

# Public PyPI
twine upload dist/*

# Private registry (e.g. Artifactory or private PyPI)
twine upload --repository-url https://your-registry-url dist/*
```

> Before publishing, update the `name` field in `pyproject.toml` from `agentic-docs` to your own package name (e.g. `yourcompany-agentic-docs`).

---

## Installation

### With Anthropic (Claude)

```bash
pip install agentic-docs[anthropic]
```

### With OpenAI-compatible providers (OpenAI, DeepSeek, Groq, Mistral, Together, etc.)

```bash
pip install agentic-docs[openai]
```

### Everything (both providers)

```bash
pip install agentic-docs[all]
```

### From a local build (before publishing)

```bash
pip install dist/agentic_docs-0.1.0-py3-none-any.whl
```

### Editable install (for development)

```bash
pip install -e ".[all]"
```

### Verify installation

```bash
agentic-docs --version
# agentic-docs, version 0.1.0
```

---

## Init options

```bash
agentic-docs init [options]

Options:
  --output-dir TEXT    Override output directory (default from AGENTIC_DOCS_OUTPUT_DIR or docs)
  --memory-dir TEXT    Override skill memory dir (default from AGENTIC_DOCS_MEMORY_DIR or .agent/skills)
```

---

## Running the agent

### Locally

```bash
# Set your API key (whichever provider you configured)
export ANTHROPIC_API_KEY=sk-ant-...   # for anthropic
export OPENAI_API_KEY=sk-...          # for openai
export DEEPSEEK_API_KEY=sk-...        # for deepseek
export GROQ_API_KEY=gsk_...           # for groq
# Pattern: {PROVIDER}_API_KEY (auto-detected)

# Run on the current branch
agentic-docs run

# With verbose logging (shows each agent turn and tool call)
agentic-docs run --verbose

# Override base branch (defaults to AGENTIC_DOCS_BASE_BRANCH or main)
agentic-docs run --base-branch development

# Skip auto-commit for this run only
agentic-docs run --no-commit
```

### Verbose output

With `--verbose` you can follow exactly what Claude is doing:

```
[INFO]  Agent turn 1/20
[INFO]  Tool call: create_plan
[INFO]  Plan created: Document payment-v2 API changes (4 steps)
[INFO]  Agent turn 2/20
[INFO]  Tool call: get_changed_files
[INFO]  Changed files: 6 total, 2 API-related
[INFO]  Agent turn 3/20
[INFO]  Tool call: extract_api_changes
[INFO]  Agent turn 4/20
[INFO]  Tool call: search_memory
[INFO]  Agent turn 5/20
[INFO]  Tool call: read_file
[INFO]  Agent turn 6/20
[INFO]  Tool call: critique_documentation
[DEBUG] Critic score: 8/10
[INFO]  Agent turn 7/20
[INFO]  Tool call: validate_documentation
[INFO]  Agent turn 8/20
[INFO]  Tool call: write_documentation
[OK]    Documentation written -> docs/payment-v2-api-docs.docx
[INFO]  Agent completed in 8 turns
```

### Run options

```bash
agentic-docs run [options]

Options:
  -v, --verbose           Enable debug logging
  --repo TEXT             Repository root path (default: current directory)
  --base-branch TEXT      Override AGENTIC_DOCS_BASE_BRANCH
  --no-commit             Skip auto-commit even if not disabled in env
```

### Exit codes

| Code | Meaning |
|------|---------|
| `0` | Success — docs generated, or no API changes detected |
| `1` | Failure — validation failed, max turns exceeded, or API error |

---

## Configuration (environment variables only)

All settings come from the environment. No config file in the repo.

### Required

| Variable | Description |
|----------|-------------|
| `AGENTIC_DOCS_PROVIDER` | LLM provider: `anthropic`, `openai`, `deepseek`, `groq`, `mistral`, `together`, `openrouter`, `ollama`, or any OpenAI-compatible name. |
| `AGENTIC_DOCS_MODEL` | Model ID (e.g. `gpt-4o`, `claude-opus-4-6`, `deepseek-chat`, `llama-3.1-70b-versatile`). |
| `AGENTIC_DOCS_MAX_INPUT_TOKENS` | Max total input tokens for the run. Positive integer. |
| `AGENTIC_DOCS_MAX_OUTPUT_TOKENS` | Max total output tokens for the run. Positive integer. |
| `{PROVIDER}_API_KEY` | API key. Derived from provider (e.g. `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `DEEPSEEK_API_KEY`). |

### Optional (defaults)

| Variable | Default | Description |
|----------|--------|-------------|
| `AGENTIC_DOCS_BASE_BRANCH` | `main` | Branch to diff against. |
| `AGENTIC_DOCS_OUTPUT_DIR` | `docs` | Directory for generated `.md` and `.docx` files. |
| `AGENTIC_DOCS_MEMORY_DIR` | `.agent/skills` | Local skill memory directory. |
| `AGENTIC_DOCS_MAX_TURNS` | `20` | Max agent loop turns (1–50). |
| `AGENTIC_DOCS_FRAMEWORKS` | `django,fastapi,flask` | Comma-separated: which extractors to run. |
| `AGENTIC_DOCS_LANGUAGES` | (empty) | Comma-separated language hints (e.g. `python`). |
| `AGENTIC_DOCS_NO_AUTO_COMMIT` | (unset) | Set to `1` or `true` to disable auto-commit. |
| `AGENTIC_DOCS_COMMIT_MESSAGE` | `docs: auto-generate...` | Commit message template; `{feature}` is replaced. |
| `AGENTIC_DOCS_CRITIC_PROVIDER` / `AGENTIC_DOCS_CRITIC_MODEL` | (inherit) | Optional cheaper provider/model for critic. |
| `AGENTIC_DOCS_EVALUATOR_PROVIDER` / `AGENTIC_DOCS_EVALUATOR_MODEL` | (inherit) | Optional provider/model for evaluator. |

### Global memory (optional, env only)

| Variable | Description |
|----------|-------------|
| `AGENTIC_DOCS_GLOBAL_MEMORY_REPO` | Git repo URL for shared cross-project memory. Set to enable. |
| `AGENTIC_DOCS_GLOBAL_MEMORY_TOKEN` | Git access token for private repos (e.g. GitHub PAT). |
| `AGENTIC_DOCS_GLOBAL_MEMORY_BRANCH` | Branch in the memory repo (default: `main`). |

---

## CI/CD Reference (GitHub Actions)

The full workflow template is at `templates/github-action.yml`. See [Quick Start](#quick-start) for the setup walkthrough.

### How it works

```
main ──────────────────────────────────────────────────────
       └── feature/payment-v2
              │  (agent runs here, diffs vs development)
              │
              ▼ squash merged
development ──────────────────── [squash commit] ← docs committed here
```

- Triggers on `pull_request: closed` + `merged == true` into your target branch
- Checks out the **feature branch HEAD** (`github.event.pull_request.head.sha`) — not the post-merge commit
- Diffs against `github.base_ref` (the target branch), so it captures exactly what the feature introduced
- Works correctly with squash merge: the feature branch is checked out before squashing

### Configuring the target branch

Edit the `branches` list in the workflow file:

```yaml
on:
  pull_request:
    types: [closed]
    branches:
      - development   # or: sandbox, staging, qa — whatever your team uses
```

### Full workflow YAML

```yaml
name: Agentic API Documentation

on:
  pull_request:
    types: [closed]
    branches:
      - development

permissions:
  contents: write

jobs:
  generate-docs:
    if: github.event.pull_request.merged == true
    runs-on: ubuntu-latest

    steps:
      - name: Checkout feature branch
        uses: actions/checkout@v4
        with:
          ref: ${{ github.event.pull_request.head.sha }}
          fetch-depth: 0
          token: ${{ secrets.GITHUB_TOKEN }}

      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
          cache: 'pip'

      - run: pip install agentic-docs

      - name: Run documentation agent
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
          AGENTIC_DOCS_PROVIDER: ${{ vars.AGENTIC_DOCS_PROVIDER }}
          AGENTIC_DOCS_MODEL: ${{ vars.AGENTIC_DOCS_MODEL }}
          AGENTIC_DOCS_MAX_INPUT_TOKENS: ${{ vars.AGENTIC_DOCS_MAX_INPUT_TOKENS }}
          AGENTIC_DOCS_MAX_OUTPUT_TOKENS: ${{ vars.AGENTIC_DOCS_MAX_OUTPUT_TOKENS }}
        run: agentic-docs run --verbose --no-commit --base-branch ${{ github.base_ref }}

      - name: Commit docs to ${{ github.base_ref }}
        if: success()
        run: |
          git config user.name  "github-actions[bot]"
          git config user.email "github-actions[bot]@users.noreply.github.com"
          git fetch origin ${{ github.base_ref }}
          git checkout ${{ github.base_ref }}
          git checkout ${{ github.event.pull_request.head.sha }} -- docs/
          git add docs/
          git diff --staged --quiet || git commit -m "docs: ${{ github.event.pull_request.title }}"
          git push origin ${{ github.base_ref }}
```

---

## Inputs summary

| Input | Where | Example |
|-------|-------|---------|
| Feature branch name | Git | `feature/payment-v2` → feature name becomes `payment-v2` |
| Changed source files | Git diff | Django URL patterns, FastAPI decorators, Flask routes |
| Base branch | Env / CLI flag | `AGENTIC_DOCS_BASE_BRANCH` or `--base-branch` |
| Model | Env | `AGENTIC_DOCS_PROVIDER` + `AGENTIC_DOCS_MODEL` |
| Token budgets | Env | `AGENTIC_DOCS_MAX_INPUT_TOKENS` + `AGENTIC_DOCS_MAX_OUTPUT_TOKENS` |
| API key | Environment variable | `ANTHROPIC_API_KEY` |
| Skill memory | `.agent/skills/` | Accumulated from previous runs; read on-demand by Claude |

---

## Output summary

| Output | Location | Format |
|--------|----------|--------|
| API documentation | `docs/<feature>-api-docs.md` | Markdown |
| API documentation | `docs/<feature>-api-docs.docx` | Word document |
| Skill memory update | `.agent/skills/*.md` | Markdown (appended after write_documentation) |
| Git commit | Current branch | `docs: auto-generate API documentation for <feature>` |
| Exit signal | stdout / exit code | `NO_API_CHANGE` (exit 0) or `GENERATED` (exit 0) or failure (exit 1) |

---

## What is skill memory?

The agent has a **two-tier memory** system:

### Local memory (per-project)

The `.agent/skills/` directory is the agent's long-term memory for your repository. It is committed to git and accumulates across every run.

| File | What it stores |
|------|---------------|
| `agentic-system-master.md` | High-level summary of every run (feature name, counts) |
| `api-patterns.md` | Incremental changelog of all endpoint changes |
| `auth-patterns.md` | Auth convention changes detected over time |
| `versioning.md` | API version change history |

### Global memory (shared, optional)

When the admin sets `AGENTIC_DOCS_GLOBAL_MEMORY_REPO`, the agent also reads from and writes to a shared private Git repo. This is useful for:
- Company-wide conventions that apply across all repos
- Common authentication patterns
- Documentation style guides

Global memory files (stored in the Git repo):

| File | What it stores |
|------|---------------|
| `common-patterns.md` | Cross-project API conventions and reusable patterns |
| `auth-strategies.md` | Company-wide authentication strategies |
| `style-guide.md` | Documentation formatting and writing conventions |

### How the agent interacts with memory

1. **Auto-context retrieval** — Before the agent loop starts, keywords from the branch name and changed file paths are used to search *both* local and global memory. Relevant sections are injected into the initial message automatically.
2. **On-demand search** — The agent calls `search_memory` with `scope: "all"` (both tiers), `"project"`, or `"global"` to find specific patterns.
3. **Agent-driven storage** — The agent calls `store_memory` with `scope: "project"` for repo-specific insights, or `scope: "global"` for cross-project patterns that benefit all repositories.

Files are automatically pruned when they exceed 8 000 characters, keeping the header and the most recent entries.

### Setting up global memory (admin only)

Global memory is configured only via environment variables. No config file.

1. Create a private Git repo (e.g. `github.com/your-org/agentic-docs-memory`)
2. Set environment variables on the CI runner (or admin env):

```bash
AGENTIC_DOCS_GLOBAL_MEMORY_REPO=https://github.com/your-org/agentic-docs-memory.git
AGENTIC_DOCS_GLOBAL_MEMORY_TOKEN=ghp_xxxxxxxxxxxx  # for private repos
AGENTIC_DOCS_GLOBAL_MEMORY_BRANCH=main            # optional, default main
```

The repo structure (created automatically on first run):

```
agentic-docs-memory/
├── common-patterns.md
├── auth-strategies.md
└── style-guide.md
```

> The end user never sees the repo URL. They just run the agent and it's smarter because of shared knowledge.

---

## Cost control

The agent is designed to be cost-efficient by default:

1. **Structured extraction** — Claude receives a small JSON object from `extract_api_changes`, not raw source files.
2. **On-demand memory** — Claude searches and reads memory only when it determines historical context is needed.
3. **Early exit** — if no API-related files changed, Claude calls `signal_no_change` and the loop exits without generating anything.
4. **Self-directed retry** — Claude re-validates its own draft and fixes errors before writing; no blind retries with the same prompt.
5. **Lightweight critic/evaluator** — critic and evaluator use `claude-sonnet` (not Opus) to keep review costs low.
6. **Configurable turn cap** — the loop exits after `maxTurns` (default 20, configurable), preventing runaway API spend.

Typical cost per run: **< $0.05** with `claude-opus-4-6` for a medium-sized feature.

---

## Architecture

The codebase is organised into eight layers, built and called in strict dependency order:

```
L2 (Extraction) → L1 (CLI shell) → L3 (Memory) → L4 (Token control)
  → L5 (Orchestration) → L6 (Validation) → L7 (Documents) → L8 (CI)
```

| Layer | Location | Role |
|-------|----------|------|
| **LLM** | `core/llm/` | Provider abstraction: `LLMProvider` ABC with Anthropic and OpenAI implementations. Tool-schema translation. |
| **Storage** | `core/storage/` | Memory store abstraction: `MemoryStore` ABC with local filesystem and Git repo backends. |
| **L2** | `core/extractor/`, `core/git.py` | Deterministic diff + AST extraction. No LLM. Output is ground truth for all downstream layers. |
| **L1** | `bin/cli.py` | Click CLI: `init` (writes config + `.agent/skills/`), `run` (loads config, runs Orchestrator). |
| **L3** | `core/memory.py` | Two-tier skill memory: local (`.agent/skills/`) + optional global (Git repo). Append-only, pruned when > 8k chars. |
| **L4** | `core/agent_loop.py` | Token budgets (input + output) enforced per-turn. Old messages compacted. Budget warning injected at 85%. |
| **L5** | `core/orchestrator.py`, `core/agent_loop.py`, `core/tools/`, `core/critic.py`, `core/evaluator.py` | Orchestrator shell → AgentLoop → ToolExecutor dispatches 14 tools. Critic and evaluator use configurable providers/models. |
| **L6** | `core/validator.py` | Validates LLM output against L2 delta. Validation failure → exit 1, no commit. |
| **L7** | `core/document.py` | Writes `.md` + `.docx` from validated content. |
| **L8** | `templates/github-action.yml`, `pyproject.toml` scripts | CI workflow and `agentic-docs` CLI entry point. |

**Design invariants:** L2 produces the only ground truth. All LLM calls go through the `LLMProvider` abstraction — the agent loop is provider-agnostic. Token budgets (input + output) are enforced every turn with automatic message compaction and budget warnings. Memory is two-tier (local + optional Git-backed global), append-only and pruned. ToolExecutor is stateful within a run. Critic and evaluator can use different providers/models for cost optimization.

---

## Project structure

```
vidura-document-agent-py/
├── bin/
│   └── cli.py                         # CLI entry point (init + run commands)
├── core/
│   ├── config.py                      # Config loading/saving with Pydantic validation
│   ├── git.py                         # Git diff analysis (L2)
│   ├── logger.py                      # Colorama-based logger
│   ├── memory.py                      # Two-tier skill memory manager (L3)
│   ├── agent_loop.py                  # Provider-agnostic multi-turn tool-use loop (L4+L5)
│   ├── orchestrator.py                # Thin shell: providers → memory → AgentLoop (L5)
│   ├── critic.py                      # Critic agent: single-shot quality review (L5)
│   ├── evaluator.py                   # Quality evaluator: LLM-based scoring (L5)
│   ├── validator.py                   # Output grounding validation (L6)
│   ├── document.py                    # Markdown + DOCX generation (L7)
│   ├── llm/                           # LLM provider abstraction
│   │   ├── __init__.py                # Public API exports
│   │   ├── base.py                    # LLMProvider ABC, LLMResponse, ToolCall types
│   │   ├── anthropic_provider.py      # Anthropic Claude implementation
│   │   ├── openai_provider.py         # OpenAI GPT implementation
│   │   └── factory.py                 # create_provider(), resolve_api_key()
│   ├── storage/                       # Memory store abstraction
│   │   ├── __init__.py                # Public API exports
│   │   ├── memory_store.py            # MemoryStore ABC
│   │   ├── local_store.py             # Local filesystem backend
│   │   └── git_store.py               # Git repo backend for global memory
│   ├── tools/
│   │   ├── definitions.py             # Tool catalogue (14 tools as dicts)
│   │   └── executor.py                # ToolExecutor: stateful tool dispatcher
│   └── extractor/
│       ├── types.py                   # Shared types (ExtractedApiDelta, ApiEndpoint, ...)
│       ├── django_ext.py              # Django URL pattern + DRF extractor
│       ├── fastapi_ext.py             # FastAPI route extractor
│       ├── flask_ext.py               # Flask route extractor
│       └── __init__.py                # Extractor coordinator
├── templates/
│   └── github-action.yml              # Drop-in GitHub Actions workflow
├── tests/
│   └── test_validator.py              # Validator unit tests
└── pyproject.toml                     # Dependencies, build config, entry point
```

---

## Development

For contributors working on the repo:

```bash
# Install
pip install -e ".[all]"

# Run in development
python -m bin.cli run --verbose
# or: agentic-docs run --verbose

# Build distribution
pip install build && python -m build
```

Set `ANTHROPIC_API_KEY` when running the agent locally.

---

## License

MIT
