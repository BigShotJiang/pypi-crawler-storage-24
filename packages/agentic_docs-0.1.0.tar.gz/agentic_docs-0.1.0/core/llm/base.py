"""Abstract LLM provider interface and normalized response types."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolCall:
    """A single tool call requested by the LLM."""

    id: str
    name: str
    input: dict


@dataclass
class TokenUsage:
    """Token usage for a single LLM call."""

    input_tokens: int = 0
    output_tokens: int = 0


@dataclass
class ToolCallResult:
    """Result of executing a tool call, to be sent back to the LLM."""

    tool_call_id: str
    content: str


@dataclass
class LLMResponse:
    """Provider-agnostic response from any LLM."""

    content: str
    stop_reason: str  # "end_turn" | "tool_use" | "max_tokens"
    tool_calls: list[ToolCall] = field(default_factory=list)
    usage: TokenUsage = field(default_factory=TokenUsage)
    _raw: Any = None  # provider-specific payload for message history


class LLMProvider(ABC):
    """Abstract interface that all LLM providers must implement."""

    @abstractmethod
    def chat(
        self,
        system: str,
        messages: list,
        tools: list[dict] | None = None,
        max_tokens: int = 8192,
    ) -> LLMResponse:
        """Send a chat request and return a normalized response."""

    @abstractmethod
    def build_assistant_message(self, response: LLMResponse) -> Any:
        """Format the LLM response as an assistant message for conversation history."""

    @abstractmethod
    def build_tool_result_messages(self, results: list[ToolCallResult]) -> list:
        """Format tool execution results as message(s) for conversation history."""

    @abstractmethod
    def get_tool_definitions(self, canonical_tools: list[dict]) -> list:
        """Convert canonical (Anthropic-style) tool definitions to provider-specific format.

        Canonical format per tool:
            {"name": str, "description": str, "input_schema": {"type": "object", "properties": {…}, "required": […]}}
        """
