"""Factory for creating LLM providers from configuration."""

from __future__ import annotations

import os

from core.llm.base import LLMProvider

# Well-known providers and their default base URLs / env vars.
# "anthropic" is handled separately (uses its own SDK).
# All others use the OpenAI-compatible SDK with a base_url.
KNOWN_PROVIDERS: dict[str, dict] = {
    "anthropic": {"base_url": None, "env_var": "ANTHROPIC_API_KEY"},
    "openai": {"base_url": None, "env_var": "OPENAI_API_KEY"},
    "deepseek": {"base_url": "https://api.deepseek.com", "env_var": "DEEPSEEK_API_KEY"},
    "groq": {"base_url": "https://api.groq.com/openai/v1", "env_var": "GROQ_API_KEY"},
    "mistral": {"base_url": "https://api.mistral.ai/v1", "env_var": "MISTRAL_API_KEY"},
    "together": {"base_url": "https://api.together.xyz/v1", "env_var": "TOGETHER_API_KEY"},
    "openrouter": {"base_url": "https://openrouter.ai/api/v1", "env_var": "OPENROUTER_API_KEY"},
    "ollama": {"base_url": "http://localhost:11434/v1", "env_var": "OLLAMA_API_KEY"},
}


def get_env_var_for_provider(provider: str) -> str:
    """Return the expected environment-variable name for a provider's API key."""
    known = KNOWN_PROVIDERS.get(provider)
    if known:
        return known["env_var"]
    return f"{provider.upper().replace('-', '_')}_API_KEY"


def get_base_url_for_provider(provider: str) -> str | None:
    """Return the default base_url for a known provider, or None."""
    known = KNOWN_PROVIDERS.get(provider)
    if known:
        return known.get("base_url")
    return None


def resolve_api_key(provider: str) -> str:
    """Resolve an API key from environment variables.

    Looks for {PROVIDER}_API_KEY (e.g. OPENAI_API_KEY, DEEPSEEK_API_KEY).
    API keys are NEVER stored in project config — always set as env vars by the admin.
    """
    env_var = get_env_var_for_provider(provider)
    value = os.environ.get(env_var)
    if not value:
        raise RuntimeError(
            f"No API key found. Set '{env_var}' as an environment variable."
        )
    return value


def resolve_api_base(provider: str) -> str | None:
    """Resolve custom API base URL.

    Resolution order:
      1. AGENTIC_DOCS_{PROVIDER}_API_BASE env var (e.g. AGENTIC_DOCS_DEEPSEEK_API_BASE)
      2. Known provider default (e.g. https://api.deepseek.com for deepseek)
      3. None (use SDK default)
    """
    env_var = f"AGENTIC_DOCS_{provider.upper().replace('-', '_')}_API_BASE"
    from_env = os.environ.get(env_var)
    if from_env:
        return from_env
    return get_base_url_for_provider(provider)


def create_provider(
    provider: str,
    model: str,
    api_key: str,
    base_url: str | None = None,
) -> LLMProvider:
    """Instantiate an LLM provider.

    * ``provider == "anthropic"`` → Anthropic SDK.
    * Everything else → OpenAI-compatible SDK (works with OpenAI, DeepSeek,
      Groq, Mistral, Together, OpenRouter, Ollama, and any other provider
      that implements the OpenAI chat-completions API).

    Args:
        provider: Provider name (free-form string).
        model:    Model identifier (e.g. "gpt-4o", "deepseek-chat").
        api_key:  Resolved API key.
        base_url: Optional API base URL override.  When *None*, a sensible
                  default is used for known providers.
    """
    if provider == "anthropic":
        from core.llm.anthropic_provider import AnthropicProvider

        return AnthropicProvider(api_key=api_key, model=model)

    # Everything else uses the OpenAI-compatible provider
    from core.llm.openai_provider import OpenAIProvider

    effective_base_url = base_url or get_base_url_for_provider(provider)
    return OpenAIProvider(api_key=api_key, model=model, base_url=effective_base_url)
