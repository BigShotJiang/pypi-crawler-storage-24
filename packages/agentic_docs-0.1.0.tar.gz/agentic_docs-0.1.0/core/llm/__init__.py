"""LLM provider abstraction layer — supports Anthropic, OpenAI, and any OpenAI-compatible provider."""

from core.llm.base import LLMProvider, LLMResponse, TokenUsage, ToolCall, ToolCallResult
from core.llm.factory import (
    KNOWN_PROVIDERS,
    create_provider,
    get_base_url_for_provider,
    get_env_var_for_provider,
    resolve_api_base,
    resolve_api_key,
)

__all__ = [
    "LLMProvider",
    "LLMResponse",
    "ToolCall",
    "ToolCallResult",
    "TokenUsage",
    "KNOWN_PROVIDERS",
    "create_provider",
    "get_base_url_for_provider",
    "get_env_var_for_provider",
    "resolve_api_base",
    "resolve_api_key",
]
