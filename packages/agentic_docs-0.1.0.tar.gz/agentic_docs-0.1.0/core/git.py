"""Git analysis layer (L2). Runs git commands to produce ChangedFile[]."""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

from core.extractor.types import ChangedFile
from core.logger import logger

# File extensions that can contain API definitions
API_EXTENSIONS = {".ts", ".js", ".py", ".java", ".kt", ".graphql", ".gql"}

API_PATH_PATTERNS = [
    re.compile(r"[\\/](routes?|controllers?|handlers?|api|endpoints?|views?|resources?|routers?)[\\/]", re.IGNORECASE),
    re.compile(r"\.(routes?|controller|handler|resource|router)\.(ts|js|py|java|kt)$", re.IGNORECASE),
    re.compile(r"schema\.(graphql|gql)$", re.IGNORECASE),
]


def _run_git(cmd: str, cwd: str) -> str:
    """Run a git command and return stdout as a string."""
    result = subprocess.run(
        cmd,
        shell=True,
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git command failed: {cmd}\n{result.stderr.strip()}")
    return result.stdout


class GitAnalyzer:
    def __init__(self, repo_path: str | None = None) -> None:
        self.repo_path = repo_path or str(Path.cwd())

    def get_current_branch(self) -> str:
        try:
            return _run_git("git rev-parse --abbrev-ref HEAD", self.repo_path).strip()
        except RuntimeError:
            raise RuntimeError("Failed to get current branch — is this a git repository?")

    def get_changed_files(self, base_branch: str) -> list[ChangedFile]:
        """Returns files changed between the merge-base of baseBranch and HEAD."""
        #diff_base = self._resolve_merge_base(base_branch)
        diff_base = "HEAD~1"

        logger.debug(f"Diff base resolved to: {diff_base}")

        try:
            #name_status = _run_git(f"git diff --name-status {diff_base}", self.repo_path)
            name_status = _run_git(f"git diff --name-status {diff_base} HEAD",self.repo_path)
        except RuntimeError as err:
            raise RuntimeError(f"git diff failed: {err}")

        changed_files: list[ChangedFile] = []
        for line in name_status.strip().split("\n"):
            if not line.strip():
                continue
            parts = line.split("\t")
            status_code = parts[0]
            file_path = parts[-1]  # handles renames (R100\told\tnew)
            if not file_path:
                continue

            status = self._parse_status_code(status_code)
            changed_files.append(
                ChangedFile(
                    path=file_path,
                    status=status,
                    diff=self._get_file_diff(diff_base, file_path),
                    content=self._read_file_content(file_path) if status != "deleted" else None,
                )
            )

        logger.debug(f"Total changed files: {len(changed_files)}")
        return changed_files

    def filter_api_files(self, files: list[ChangedFile]) -> list[ChangedFile]:
        """Filter to only API-related changed files."""
        result: list[ChangedFile] = []
        for f in files:
            ext = os.path.splitext(f.path)[1].lower()
            # Always allow Python → FastAPI chance

            if ext == ".py":

                result.append(f)

                continue

            if ext not in API_EXTENSIONS:
                continue
            # Accept any .graphql/.gql file
            if ext in (".graphql", ".gql"):
                result.append(f)
                continue
            # Accept files in API-adjacent paths
            if any(p.search(f.path) for p in API_PATH_PATTERNS):
                result.append(f)
        return result

    # ─── Private helpers ──────────────────────────────────────────────────────

    def _resolve_merge_base(self, base_branch: str) -> str:
        try:
            return _run_git(f"git merge-base {base_branch} HEAD", self.repo_path).strip()
        except RuntimeError:
            return base_branch

    @staticmethod
    def _parse_status_code(code: str) -> str:
        if code.startswith("A"):
            return "added"
        if code.startswith("D"):
            return "deleted"
        return "modified"

    def _get_file_diff(self, diff_base: str, file_path: str) -> str:
        try:
            return _run_git(f'git diff {diff_base} -- "{file_path}"', self.repo_path)
        except RuntimeError:
            return ""

    def _read_file_content(self, file_path: str) -> str | None:
        try:
            abs_path = Path(self.repo_path) / file_path
            if abs_path.exists():
                return abs_path.read_text(encoding="utf-8")
        except Exception:
            pass
        return None

    def get_repo_metadata(self) -> dict:
        """Collect repository metadata for documentation."""
        try:
            branch = _run_git("git rev-parse --abbrev-ref HEAD", self.repo_path).strip()
            current_commit = _run_git("git rev-parse HEAD", self.repo_path).strip()

            try:
                previous_commit = _run_git("git rev-parse HEAD~1", self.repo_path).strip()
            except RuntimeError:
                previous_commit = "N/A"

            author = _run_git("git log -1 --pretty=format:%an", self.repo_path).strip()

            commit_message = _run_git(
                "git log -1 --pretty=format:%s",
                self.repo_path,
            ).strip()

            commit_time = _run_git(
                "git log -1 --pretty=format:%cd --date=iso",
                self.repo_path,
            ).strip()

            repo_name = Path(self.repo_path).name

            return {
                "repo_name": repo_name,
                "branch_name": branch,
                "authors": author,
                "previous_commit": previous_commit,
                "current_commit": current_commit,
                "commit_message": commit_message,
                "commit_time": commit_time,
            }

        except Exception as e:
            logger.warn(f"Failed to collect repo metadata: {e}")
            return {
                "repo_name": "unknown",
                "branch_name": "unknown",
                "authors": "unknown",
                "previous_commit": "unknown",
                "current_commit": "unknown",
                "commit_message": "unknown",
                "commit_time": "unknown",
            }