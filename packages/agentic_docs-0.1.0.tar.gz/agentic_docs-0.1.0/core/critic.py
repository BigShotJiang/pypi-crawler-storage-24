"""Critic agent — single-shot LLM call for documentation quality review."""

from __future__ import annotations

import json

from core.llm.base import LLMProvider
from core.logger import logger

CRITIC_SYSTEM_PROMPT = """\
You are a senior technical writer reviewing API documentation for production use. \
Your quality bar: a developer should be able to integrate this API correctly \
using only this document, without asking any follow-up questions.

You are given the documentation draft and the API delta (the ground truth of what changed). \
Score each dimension 1–10 using the rubrics below.

## Scoring rubrics

**Completeness (1–10)**
- 10: Every endpoint has method + path, auth requirements, all parameters (path/query/body) \
with types and examples, full response schema with example JSON, all non-2xx error codes.
- 7: Most endpoints documented; 1–2 minor fields or error codes missing.
- 5: Endpoints listed but schemas, examples, or error codes largely absent.
- 1: Endpoints named only, no useful detail.

**Clarity (1–10)**
- 10: A developer unfamiliar with the codebase can integrate immediately. \
Every field's purpose is obvious. Examples use realistic, domain-appropriate values.
- 7: Mostly clear; minor ambiguities that could be resolved by inference.
- 5: Some sections require guesswork; vague field descriptions or unclear types.
- 1: Confusing, jargon-heavy, contradictory, or impossible to follow.

**Accuracy (1–10)**
- 10: Every detail matches the API delta exactly. No invented fields, paths, or behaviours.
- 7: Mostly accurate; minor discrepancies (slightly wrong type, off-by-one status code).
- 5: Some invented or assumed details not present in the delta.
- 1: Significant fabrication — endpoints, fields, or behaviours not in the delta.

**Structure (1–10)**
- 10: Logical section order, consistent heading levels, parameters in tables, \
cURL examples for every new endpoint, breaking changes prominently called out with migration steps.
- 7: Well organised; minor formatting inconsistencies.
- 5: Inconsistent structure; some sections hard to scan.
- 1: Unstructured wall of text; no clear sections.

**Developer Experience (1–10)**
- 10: Realistic example values (not `string`, `123`), runnable cURL snippets with \
correct auth headers, types stated explicitly (`string (UUID)`, `integer (Unix ms timestamp)`), \
breaking changes flagged with before/after migration examples.
- 7: Good examples; 1–2 missing auth headers or generic placeholders.
- 5: Examples present but use generic placeholders or missing auth; types unclear.
- 1: No examples; types vague; unusable for integration.

## Output format

Respond ONLY with valid JSON — no prose, no markdown, no explanation outside the JSON:
{
    "scores": {
        "completeness": <1-10>,
        "clarity": <1-10>,
        "accuracy": <1-10>,
        "structure": <1-10>,
        "developerExperience": <1-10>
    },
    "overallScore": <1-10>,
    "criticalIssues": ["<issue that would cause integration failure — name the exact endpoint/field>"],
    "suggestions": ["<specific, actionable suggestion naming the exact endpoint or field>"],
    "summary": "<one-sentence overall assessment>"
}

## Rules
- Suggestions must be specific: name the endpoint and field (e.g. \
  "POST /api/payments is missing the request body schema for amount and currency").
- List critical issues separately — these are blockers for developer integration.
- Never invent issues that are not present in the draft.
- Score 1 for the worst real documentation; reserve 0 for parse/API failure only."""


class CriticAgent:
    """Single-shot LLM call that critiques a documentation draft."""

    def __init__(self, provider: LLMProvider) -> None:
        self.provider = provider

    def critique(self, documentation: str, delta_summary: str) -> dict:
        """Critique a documentation draft against the API delta.

        Args:
            documentation: The markdown draft to critique.
            delta_summary: JSON-serialized API delta for accuracy checks.

        Returns:
            dict with scores, suggestions, and summary.
        """
        user_message = (
            "Review this API documentation draft.\n\n"
            f"## API Delta (ground truth)\n```json\n{delta_summary}\n```\n\n"
            f"## Documentation Draft\n```markdown\n{documentation}\n```"
        )

        try:
            response = self.provider.chat(
                system=CRITIC_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_message}],
                max_tokens=2048,
            )

            result = json.loads(response.content)
            logger.debug(f"Critic score: {result.get('overallScore', 'N/A')}/10")
            return result

        except json.JSONDecodeError:
            logger.warn("Critic returned non-JSON response")
            return _fallback("Critic review could not parse response.")
        except Exception as err:
            logger.warn(f"Critic call failed: {err}")
            return _fallback(f"Critic review failed: {err}")


def _fallback(summary: str) -> dict:
    return {
        "scores": {
            "completeness": 0,
            "clarity": 0,
            "accuracy": 0,
            "structure": 0,
            "developerExperience": 0,
        },
        "overallScore": 0,
        "criticalIssues": [],
        "suggestions": [summary],
        "summary": summary,
    }
