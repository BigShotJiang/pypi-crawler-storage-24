"""Local file-system memory store (preserves original behaviour)."""

from __future__ import annotations

from pathlib import Path

from core.logger import logger
from core.storage.memory_store import MemoryStore


class LocalMemoryStore(MemoryStore):
    """Reads / writes skill files to a local directory."""

    def __init__(self, base_dir: str | Path) -> None:
        self.base_dir = Path(base_dir)

    def read(self, filename: str) -> str:
        try:
            return (self.base_dir / filename).read_text(encoding="utf-8")
        except Exception:
            return ""

    def write(self, filename: str, content: str) -> None:
        try:
            (self.base_dir / filename).write_text(content, encoding="utf-8")
        except Exception as err:
            logger.warn(f"Failed to write {filename}: {err}")

    def append(self, filename: str, content: str) -> None:
        try:
            with open(self.base_dir / filename, "a", encoding="utf-8") as f:
                f.write(content + "\n")
        except Exception as err:
            logger.warn(f"Failed to append to {filename}: {err}")

    def exists(self, filename: str) -> bool:
        return (self.base_dir / filename).exists()

    def list_files(self) -> list[str]:
        if not self.base_dir.exists():
            return []
        return [f.name for f in self.base_dir.iterdir() if f.is_file() and f.suffix == ".md"]

    def initialize(self, initial_content: dict[str, str]) -> None:
        self.base_dir.mkdir(parents=True, exist_ok=True)
        for filename, content in initial_content.items():
            if not self.exists(filename):
                self.write(filename, content)
                logger.debug(f"Initialized skill file: {filename}")
