"""Abstract memory store interface for skill memory backends."""

from __future__ import annotations

from abc import ABC, abstractmethod


class MemoryStore(ABC):
    """Backend-agnostic interface for reading and writing skill memory files."""

    @abstractmethod
    def read(self, filename: str) -> str:
        """Read a skill file. Returns empty string if not found."""

    @abstractmethod
    def write(self, filename: str, content: str) -> None:
        """Overwrite a skill file with new content."""

    @abstractmethod
    def append(self, filename: str, content: str) -> None:
        """Append content to a skill file."""

    @abstractmethod
    def exists(self, filename: str) -> bool:
        """Check whether a skill file exists."""

    @abstractmethod
    def list_files(self) -> list[str]:
        """List all .md skill files in the store."""

    @abstractmethod
    def initialize(self, initial_content: dict[str, str]) -> None:
        """Create skill files that don't yet exist, seeding them with *initial_content*."""
