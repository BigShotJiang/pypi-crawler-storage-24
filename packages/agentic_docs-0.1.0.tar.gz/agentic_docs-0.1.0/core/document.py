"""Document generation (L7). Writes both Markdown and DOCX."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from docx import Document
from docx.shared import Pt, Twips

from core.logger import logger

# import pypandoc
from datetime import datetime

@dataclass
class DocumentOutput:
    markdown_path: str
    docx_path: str

@dataclass
class DocumentMetadata:
    uploaded_by: str
    repo_name: str
    project_name: str
    branch_name: str
    authors: str
    previous_commit: str
    current_commit: str
    commit_message: str
    commit_time: str
    version: str
    changed_files: list[str]

@dataclass
class ParsedSection:
    type: str  # h1, h2, h3, h4, code, bullet, text
    content: str | list[list[str]]
    level: int = 0


class DocumentGenerator:
    async def generate(
        self,
        markdown_content: str,
        feature_name: str,
        output_dir: str,
        metadata: DocumentMetadata,
    ) -> DocumentOutput:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        file_name = re.sub(r"[^a-zA-Z0-9-]", "-", feature_name)
        timestamp = datetime.now().strftime("%Y%m%d-%H%M")

        markdown_path = str(output_path / f"{file_name}-api-docs-{timestamp}.md")
        docx_path = str(output_path / f"{file_name}-api-docs-{timestamp}.docx")

        Path(markdown_path).write_text(markdown_content, encoding="utf-8")
        logger.debug(f"Markdown written: {markdown_path}")

        self._generate_docx(markdown_content, docx_path, metadata)
        logger.debug(f"DOCX written: {docx_path}")

        return DocumentOutput(markdown_path=markdown_path, docx_path=docx_path)

    # ─── Private helpers ──────────────────────────────────────────────────────

    def _generate_docx(self, markdown: str, output_path: str, metadata: DocumentMetadata) -> None:
       
        sections = self._parse_markdown(markdown)
        doc = Document()

        doc.core_properties.author = metadata.authors
        doc.core_properties.title = metadata.project_name
        doc.core_properties.subject = metadata.repo_name
        doc.core_properties.comments = f"Branch: {metadata.branch_name}"

        # Set document title from first heading
        first_line = markdown.strip().split("\n")[0]
        title_text = re.sub(r"^#+\s*", "", first_line)
        doc.core_properties.title = title_text
        doc.core_properties.author = "agentic-docs"

        for s in sections:
            if s.type == "h1":
                p = doc.add_heading(s.content, level=1)
                pf = p.paragraph_format
                pf.space_before = Twips(480)
                pf.space_after = Twips(240)

                meta_lines = [
                            f"Version: {metadata.version}",
                            f"Uploaded By: {metadata.uploaded_by}",
                            f"Repository: {metadata.repo_name}",
                            f"Project: {metadata.project_name}",
                            f"Branch: {metadata.branch_name}",
                            f"Authors: {metadata.authors}",
                            f"Previous Commit: {metadata.previous_commit}",
                            f"Current Commit: {metadata.current_commit}",
                            f"Commit Message: {metadata.commit_message}",
                            f"Commit Time: {metadata.commit_time}",
                        ]
                for line in meta_lines:
                    mp = doc.add_paragraph(line)
                    mp.paragraph_format.space_after = Twips(60)

                doc.add_paragraph("Changed Files:")

                for file in metadata.changed_files:
                    p = doc.add_paragraph(style="List Bullet")
                    p.add_run(file)

            elif s.type == "h2":
                p = doc.add_heading(s.content, level=2)
                pf = p.paragraph_format
                pf.space_before = Twips(360)
                pf.space_after = Twips(160)

            elif s.type == "h3":
                p = doc.add_heading(s.content, level=3)
                pf = p.paragraph_format
                pf.space_before = Twips(240)
                pf.space_after = Twips(120)

            elif s.type == "h4":
                p = doc.add_heading(s.content, level=4)

            elif s.type == "code":
                p = doc.add_paragraph()

                # for line in s.content.split("\n"):
                run = p.add_run(s.content)
                run.font.name = "Courier New"
                run.font.size = Pt(9)

                pf = p.paragraph_format
                pf.left_indent = Twips(360)
                pf.space_before = Twips(120)
                pf.space_after = Twips(120)

            elif s.type == "bullet":
                p = doc.add_paragraph(style="List Bullet")

                if s.level > 0:
                    p.paragraph_format.left_indent = Twips(360 * (s.level + 1))

                self._add_inline_formatting(p, s.content)

                pf = p.paragraph_format
                pf.space_before = Twips(60)
                pf.space_after = Twips(60)

            elif s.type == "text":
                p = doc.add_paragraph()
                self._add_inline_formatting(p, s.content)
                pf = p.paragraph_format
                pf.space_before = Twips(120)
                pf.space_after = Twips(120)
            
            # elif s.type == "table":
            #     rows = s.content
            #     cols = max(len(r) for r in rows)
            #     table = doc.add_table(rows=len(rows), cols=cols)

            #     for i, row in enumerate(rows):
            #         for j, cell in enumerate(row):
            #             table.cell(i, j).text = cell

            #     table.style = "Table Grid"

        doc.save(output_path)

    @staticmethod
    def _parse_markdown(markdown: str) -> list[ParsedSection]:
        result: list[ParsedSection] = []
        in_code = False
        code_lines: list[str] = []

        for line in markdown.split("\n"):
            if line.lstrip().startswith("```"):
                if in_code:
                    result.append(ParsedSection(type="code", content="\n".join(code_lines)))
                    code_lines.clear()
                    in_code = False
                else:
                    in_code = True
                continue

            if in_code:
                code_lines.append(line)
                continue

            if line.startswith("# "):
                result.append(ParsedSection(type="h1", content=line[2:].strip()))
            elif line.startswith("## "):
                result.append(ParsedSection(type="h2", content=line[3:].strip()))
            elif line.startswith("### "):
                result.append(ParsedSection(type="h3", content=line[4:].strip()))
            elif line.startswith("#### "):
                result.append(ParsedSection(type="h4", content=line[5:].strip()))
            elif re.match(r"^\s{0,3}[-*+]\s+", line):
                indent_match = re.match(r"^(\s*)", line)
                indent = len(indent_match.group(1)) if indent_match else 0
                content = re.sub(r"^\s*[-*+]\s+", "", line).strip()
                result.append(ParsedSection(type="bullet", content=content, level=indent // 2))
            elif line.strip():
                result.append(ParsedSection(type="text", content=line.strip()))

        # Flush unclosed code block
        if code_lines:
            result.append(ParsedSection(type="code", content="\n".join(code_lines)))

        return result

    def _add_inline_formatting(self, paragraph, text: str):
        """
        Render **bold** and `inline code` formatting.
        """

        tokens = re.split(r"(\*\*.*?\*\*|`.*?`)", text)

        for token in tokens:
            if token.startswith("**") and token.endswith("**"):
                run = paragraph.add_run(token[2:-2])
                run.bold = True

            # elif token.startswith("`") and token.endswith("`"):
            #     run = paragraph.add_run(token[1:-1])
            #     run.font.name = "Courier New"

            else:
                paragraph.add_run(token)

    # def _normalize_tables(self, markdown: str) -> str:
    #     """
    #     Ensure Markdown tables are aligned and have separator row for Pandoc.
    #     """
    #     lines = markdown.split("\n")
    #     fixed = []
    #     i = 0
    #     while i < len(lines):
    #         line = lines[i]
    #         stripped = line.lstrip()
    #         if stripped.startswith("|"):
    #             # Add separator row if missing
    #             if i + 1 >= len(lines) or not re.match(r"^\|[- :]+", lines[i+1]):
    #                 cols = [c.strip() for c in stripped.strip("|").split("|")]
    #                 sep = "|" + "|".join(["---"] * len(cols)) + "|"
    #                 fixed.append(stripped)
    #                 fixed.append(sep)
    #                 i += 1
    #                 continue
    #             else:
    #                 fixed.append(stripped)
    #         else:
    #             fixed.append(line)
    #         i += 1
    #     return "\n".join(fixed)