"""Stateful tool dispatcher (L5). Executes tool calls and accumulates state across agent turns."""

from __future__ import annotations

import fnmatch
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from core.config import AgentConfig
from core.document import DocumentGenerator
from core.extractor import extract_api_delta
from core.extractor.types import ChangedFile, ExtractedApiDelta
from core.git import GitAnalyzer
from core.llm.base import LLMProvider
from core.logger import logger
from core.memory import GLOBAL_SKILL_FILES, MemoryManager
from core.validator import DocumentValidator

import getpass
from core.document import DocumentMetadata

ToolName = Literal[
    "get_changed_files",
    "extract_api_changes",
    "read_memory",
    "store_draft",
    "validate_documentation",
    "write_documentation",
    "signal_no_change",
    "read_file",
    "search_codebase",
    "create_plan",
    "revise_plan",
    "search_memory",
    "store_memory",
    "critique_documentation",
    "evaluate_quality",
]

TerminalStatus = Literal["GENERATED", "NO_API_CHANGE"]

TERMINAL_TOOLS: set[str] = {"write_documentation", "signal_no_change"}

SEARCH_SKIP_DIRS = {".git", "node_modules", "__pycache__", "venv", ".venv", ".tox", "dist", "build"}


@dataclass
class ToolResult:
    """Result of a tool execution."""

    content: str
    is_terminal: bool
    terminal_status: TerminalStatus | None = None
    output_path: str | None = None
    feature_name: str | None = None


@dataclass
class AgentPlan:
    """Agent's self-created plan for the documentation run."""

    goal: str
    steps: list[str]
    revision_count: int = 0


# Skill-name → filename maps
_LOCAL_SKILL_MAP = {
    "api-patterns": "api-patterns.md",
    "auth-patterns": "auth-patterns.md",
    "versioning": "versioning.md",
    "master": "agentic-system-master.md",
}

_GLOBAL_SKILL_MAP = {
    "common-patterns": GLOBAL_SKILL_FILES["common-patterns"],
    "auth-strategies": GLOBAL_SKILL_FILES["auth-strategies"],
    "style-guide": GLOBAL_SKILL_FILES["style-guide"],
}


class ToolExecutor:
    """Stateful dispatcher that executes tool calls and accumulates state
    (changed_files, merged_delta, plan) across multiple agent turns."""

    def __init__(
        self,
        repo_path: str,
        config: AgentConfig,
        branch: str,
        memory: MemoryManager,
        critic_provider: LLMProvider | None = None,
        evaluator_provider: LLMProvider | None = None,
    ) -> None:
        self.repo_path = repo_path
        self.config = config
        self.branch = branch
        self._memory = memory
        self._critic_provider = critic_provider
        self._evaluator_provider = evaluator_provider

        self._changed_files: list[ChangedFile] = []
        self._merged_delta: ExtractedApiDelta | None = None
        self._plan: AgentPlan | None = None
        self._current_draft: str = ""

        self._git = GitAnalyzer(repo_path)
        self._validator = DocumentValidator()
        self._doc_gen = DocumentGenerator()

        self._critic = None
        self._evaluator = None

        self._memory_writes = 0 #new
        self._draft_revisions = 0 #new
        self._file_reads = 0 #new

    def is_terminal(self, tool_name: str) -> bool:
        return tool_name in TERMINAL_TOOLS

    async def execute(self, tool_name: str, tool_input: dict) -> ToolResult:
        logger.info(f"Tool call: {tool_name}")

        handlers = {
            "get_changed_files": lambda: self._get_changed_files(),
            "extract_api_changes": lambda: self._extract_api_changes(tool_input.get("framework", "fastapi")),
            "read_memory": lambda: self._read_memory(
                tool_input.get("skill", "master"),
                tool_input.get("scope", "project"),
            ),
            "store_draft": lambda: self._store_draft(tool_input.get("documentation", "")),
            "validate_documentation": lambda: self._validate_documentation(),
            "signal_no_change": lambda: self._signal_no_change(tool_input.get("reason", "")),
            "read_file": lambda: self._read_file(
                tool_input.get("path", ""),
                tool_input.get("offset", 0),
                tool_input.get("limit", 100),
            ),
            "search_codebase": lambda: self._search_codebase(
                tool_input.get("pattern", ""),
                tool_input.get("glob"),
                tool_input.get("maxResults", 20),
            ),
            "create_plan": lambda: self._create_plan(
                tool_input.get("goal", ""),
                tool_input.get("steps", []),
            ),
            "revise_plan": lambda: self._revise_plan(
                tool_input.get("reason", ""),
                tool_input.get("updatedSteps", []),
            ),
            "search_memory": lambda: self._search_memory(
                tool_input.get("query", ""),
                tool_input.get("maxResults", 5),
                tool_input.get("scope", "all"),
            ),
            "store_memory": lambda: self._store_memory(
                tool_input.get("category", "general"),
                tool_input.get("title", ""),
                tool_input.get("content", ""),
                tool_input.get("scope", "project"),
            ),
            "critique_documentation": lambda: self._critique_documentation(),

            "evaluate_quality": lambda: self._evaluate_quality(
              tool_input.get("compare_with_existing", False),
),
        }

        if tool_name == "write_documentation":
            return await self._write_documentation(
                tool_input.get("featureName", ""),
            )

        handler = handlers.get(tool_name)
        if handler:
            return handler()

        return ToolResult(
            content=json.dumps({"error": f"Unknown tool: {tool_name}"}),
            is_terminal=False,
        )

    def get_merged_delta(self) -> ExtractedApiDelta | None:
        return self._merged_delta

    # ─── Original tool handlers ───────────────────────────────────────────────

    def _get_changed_files(self) -> ToolResult:
        all_changed = self._git.get_changed_files(self.config.base_branch)
        self._changed_files = self._git.filter_api_files(all_changed)

        logger.info(f"Changed files: {len(all_changed)} total, {len(self._changed_files)} API-related")

        preview = [
            {
                "path": f.path,
                "status": f.status,
                "diffPreview": "\n".join(f.diff.split("\n")[:10]),
            }
            for f in self._changed_files
        ]

        return ToolResult(
            content=json.dumps({"total": len(all_changed), "apiRelated": len(self._changed_files), "files": preview}),
            is_terminal=False,
        )

    def _extract_api_changes(self, framework: str) -> ToolResult:

        if not self._changed_files:
            return ToolResult(
                content=json.dumps({
                    "error": "No changed files available. Call get_changed_files first."
                }),
                is_terminal=False,
            )

        delta = extract_api_delta(
            self._changed_files,
            self.branch,
            self.branch,
            self.config.base_branch,
            [framework],
        )

        if self._merged_delta is None:
            self._merged_delta = delta
        else:
            self._merged_delta.new.extend(delta.new)
            self._merged_delta.modified.extend(delta.modified)
            self._merged_delta.removed.extend(delta.removed)
            self._merged_delta.contract_changes.extend(delta.contract_changes)
            self._merged_delta.auth_changes.extend(delta.auth_changes)
            self._merged_delta.versioning_changes.extend(delta.versioning_changes)

        logger.debug(
            f"[{framework}] new: {len(delta.new)}, modified: {len(delta.modified)}, removed: {len(delta.removed)}"
        )

        delta_dict = self._delta_to_dict(delta)

        return ToolResult(
            content=json.dumps({
                "delta": delta_dict,
                "message": (
                    "Structured API changes extracted. "
                    "You now have the ground truth for documentation. "
                    "Next step: create documentation draft using store_draft."
                )
            }),
            is_terminal=False,
        )

    def _read_memory(self, skill: str, scope: str = "project") -> ToolResult:
        if scope == "global":
            filename = _GLOBAL_SKILL_MAP.get(skill)
            if not filename:
                valid = ", ".join(_GLOBAL_SKILL_MAP.keys())
                return ToolResult(
                    content=json.dumps({"error": f"Unknown global skill: '{skill}'. Valid: {valid}"}),
                    is_terminal=False,
                )
            if not self._memory.has_global:
                return ToolResult(
                    content=json.dumps({"error": "Global memory is not configured."}),
                    is_terminal=False,
                )
        else:
            filename = _LOCAL_SKILL_MAP.get(skill)
            if not filename:
                valid = ", ".join(_LOCAL_SKILL_MAP.keys())
                return ToolResult(
                    content=json.dumps({"error": f"Unknown skill: '{skill}'. Valid: {valid}"}),
                    is_terminal=False,
                )

        raw = self._memory.read_skill(filename, scope=scope)
        content = raw[:3000] + "\n...[truncated]" if len(raw) > 3000 else raw

        return ToolResult(content=content, is_terminal=False)

    def _store_draft(self, documentation: str) -> ToolResult:
        if not documentation.strip():
            return ToolResult(
                content=json.dumps({"error": "Documentation draft cannot be empty."}),
                is_terminal=False,
            )

        # Track number of revisions
        self._draft_revisions += 1

        # Limit infinite draft rewrites
        if self._draft_revisions > 2:
            logger.warn("Draft revision limit reached. Forcing workflow forward.")

            return ToolResult(
                content=json.dumps({
                    "skipped": True,
                    "revision": self._draft_revisions,
                    "message": (
                        "Maximum draft revisions reached. "
                        "Proceed to writing documentation using write_documentation."
                    )
                }),
                is_terminal=False,
            )

        self._current_draft = documentation
        char_count = len(documentation)

        logger.info(f"Draft stored (revision {self._draft_revisions}, {char_count} chars)")

        return ToolResult(
            content=json.dumps({
                "stored": True,
                "revision": self._draft_revisions,
                "charCount": char_count,
                "message": (
                    "Draft stored successfully. "
                    "Next step: validate_documentation or critique_documentation."
                ),
            }),
            is_terminal=False,
        )

    def _validate_documentation(self) -> ToolResult:
        if not self._current_draft:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": ["No draft available. Call store_draft first."],
                    "warnings": [],
                    "message": "Call store_draft before validate_documentation.",
                }),
                is_terminal=False,
            )

        if not self._merged_delta:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": ["No API delta available. Call extract_api_changes first."],
                    "warnings": [],
                    "message": "Call extract_api_changes before validate_documentation.",
                }),
                is_terminal=False,
            )

        result = self._validator.validate(self._current_draft, self._merged_delta)

        message = (
            "Documentation is valid. You may now call write_documentation."
            if result.valid
            else f"Validation failed with {len(result.errors)} error(s). Fix before writing: {'; '.join(result.errors)}"
        )

        return ToolResult(
            content=json.dumps({
                "valid": result.valid,
                "errors": result.errors,
                "warnings": result.warnings,
                "message": message,
            }),
            is_terminal=False,
        )

    async def _write_documentation(self, feature_name: str) -> ToolResult:

        if not self._changed_files:
            logger.warn("No commits or changed files detected for this run.")
            
        if not self._current_draft:
            return ToolResult(
                content=json.dumps({
                    "success": False,
                    "error": "No draft available. Call store_draft before writing.",
                }),
                is_terminal=True,
                terminal_status="GENERATED",
            )

        if not self._merged_delta:
            return ToolResult(
                content=json.dumps({
                    "success": False,
                    "error": "No API delta available. Call extract_api_changes before writing.",
                }),
                is_terminal=True,
                terminal_status="GENERATED",
            )

        output_dir = str(Path(self.repo_path) / self.config.output_dir)

        # Collect repository metadata
        git_meta = self._git.get_repo_metadata()
        changed_files = [f"{f.path} ({f.status})" for f in self._changed_files]

        metadata = DocumentMetadata(
            uploaded_by=getpass.getuser(),
            repo_name=git_meta["repo_name"],
            project_name=git_meta["repo_name"],
            branch_name=git_meta["branch_name"],
            authors=git_meta["authors"],
            previous_commit=git_meta["previous_commit"],
            current_commit=git_meta["current_commit"],
            commit_message=git_meta["commit_message"],
            commit_time=git_meta["commit_time"],
            version=f"v1.0-{git_meta['current_commit'][:7]}",
            changed_files=changed_files,
        )

        # Generate documentation with metadata
        output = await self._doc_gen.generate(
            self._current_draft,
            feature_name,
            output_dir,
            metadata,
        )

        self._memory.update_from_delta(self._merged_delta)

        logger.success(f"Documentation written -> {output.docx_path}")

        return ToolResult(
            content=json.dumps({"success": True, "markdownPath": output.markdown_path, "docxPath": output.docx_path}),
            is_terminal=True,
            terminal_status="GENERATED",
            output_path=output.docx_path,
            feature_name=feature_name,
        )

    def _signal_no_change(self, reason: str) -> ToolResult:
        logger.success(f"NO_API_CHANGE: {reason}")
        return ToolResult(
            content=json.dumps({"noChange": True, "reason": reason}),
            is_terminal=True,
            terminal_status="NO_API_CHANGE",
        )

    # ─── Agentic tool handlers ────────────────────────────────────────────────

    def _read_file(self, path: str, offset: int = 0, limit: int = 100) -> ToolResult:

            # ── File read limiter ─────────────────────────────
        if self._file_reads >= 3:
            return ToolResult(
                content=json.dumps({
                    "skipped": True,
                    "reason": "Maximum file reads reached. Continue with documentation."
                }),
                is_terminal=False,
            )

        self._file_reads += 1
        # ──────────────────────────────────────────────────
        limit = min(max(limit, 1), 300)
        offset = max(offset, 0)

        repo_root = Path(self.repo_path).resolve()
        target = (repo_root / path).resolve()

        if not str(target).startswith(str(repo_root)):
            return ToolResult(
                content=json.dumps({"error": "Path traversal not allowed."}),
                is_terminal=False,
            )

        if not target.exists():
            return ToolResult(
                content=json.dumps({"error": f"File not found: {path}"}),
                is_terminal=False,
            )

        if not target.is_file():
            return ToolResult(
                content=json.dumps({"error": f"Not a file: {path}"}),
                is_terminal=False,
            )

        try:
            lines = target.read_text(encoding="utf-8", errors="replace").split("\n")
            total_lines = len(lines)
            selected = lines[offset : offset + limit]

            numbered = [f"{offset + i + 1}: {line}" for i, line in enumerate(selected)]

            return ToolResult(
                content=json.dumps({
                    "path": path,
                    "totalLines": total_lines,
                    "offset": offset,
                    "linesReturned": len(selected),
                    "content": "\n".join(numbered),
                }),
                is_terminal=False,
            )
        except Exception as err:
            return ToolResult(
                content=json.dumps({"error": f"Failed to read file: {err}"}),
                is_terminal=False,
            )

    def _search_codebase(self, pattern: str, glob_filter: str | None = None, max_results: int = 20) -> ToolResult:
        max_results = min(max(max_results, 1), 50)

        try:
            compiled = re.compile(pattern, re.IGNORECASE)
        except re.error as err:
            return ToolResult(
                content=json.dumps({"error": f"Invalid regex: {err}"}),
                is_terminal=False,
            )

        repo_root = Path(self.repo_path)
        matches: list[dict] = []

        for file_path in repo_root.rglob("*"):
            if len(matches) >= max_results:
                break

            parts = file_path.relative_to(repo_root).parts
            if any(part in SEARCH_SKIP_DIRS for part in parts):
                continue

            if not file_path.is_file():
                continue

            rel_path = str(file_path.relative_to(repo_root)).replace("\\", "/")

            if glob_filter and not fnmatch.fnmatch(rel_path, glob_filter):
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            for i, line in enumerate(content.split("\n"), start=1):
                if compiled.search(line):
                    matches.append({
                        "file": rel_path,
                        "line": i,
                        "content": line.strip()[:200],
                    })
                    if len(matches) >= max_results:
                        break

        return ToolResult(
            content=json.dumps({"pattern": pattern, "totalMatches": len(matches), "matches": matches}),
            is_terminal=False,
        )

    def _create_plan(self, goal: str, steps: list[str]) -> ToolResult:
        self._plan = AgentPlan(goal=goal, steps=steps)
        logger.info(f"Plan created: {goal} ({len(steps)} steps)")

        return ToolResult(
            content=json.dumps({
                "planCreated": True,
                "goal": goal,
                "steps": steps,
                "message": "Plan registered. Proceed with execution. Call revise_plan if you need to adjust.",
            }),
            is_terminal=False,
        )

    def _revise_plan(self, reason: str, updated_steps: list[str]) -> ToolResult:
        if not self._plan:
            return ToolResult(
                content=json.dumps({"error": "No plan exists. Call create_plan first."}),
                is_terminal=False,
            )

        self._plan.steps = updated_steps
        self._plan.revision_count += 1
        logger.info(f"Plan revised (#{self._plan.revision_count}): {reason}")

        return ToolResult(
            content=json.dumps({
                "planRevised": True,
                "reason": reason,
                "revisionNumber": self._plan.revision_count,
                "updatedSteps": updated_steps,
            }),
            is_terminal=False,
        )

    def _search_memory(self, query: str, max_results: int = 5, scope: str = "all") -> ToolResult:
        results = self._memory.search_memory(query, max_results=max_results, scope=scope)

        if not results:
            return ToolResult(
                content=json.dumps({
                    "query": query,
                    "scope": scope,
                    "totalResults": 0,
                    "results": [],
                    "message": "No matching memory sections found.",
                }),
                is_terminal=False,
            )

        return ToolResult(
            content=json.dumps({
                "query": query,
                "scope": scope,
                "totalResults": len(results),
                "results": [{"source": r.source, "score": r.score, "section": r.section} for r in results],
            }),
            is_terminal=False,
        )

    def _store_memory(self, category: str, title: str, content: str, scope: str = "project") -> ToolResult:

        if self._memory_writes >= 2:
            return ToolResult(
                content=json.dumps({
                    "skipped": True,
                    "reason": "Memory limit reached for this run.",
                    "nextAction": "Proceed to documentation drafting using store_draft."
                }),
                is_terminal=False,
            )

        self._memory_writes += 1

        if scope == "global" and not self._memory.has_global:
            return ToolResult(
                content=json.dumps({"error": "Global memory is not configured. Use scope 'project' instead."}),
                is_terminal=False,
            )

        self._memory.store_memory(category, title, content, scope=scope)

        return ToolResult(
            content=json.dumps({
                "stored": True,
                "category": category,
                "scope": scope,
                "title": title,
                "message": "Memory stored. Continue documentation workflow."
            }),
            is_terminal=False,
        )

    def _critique_documentation(self) -> ToolResult:
        if not self._current_draft:
            return ToolResult(
                content=json.dumps({"error": "No draft available. Call store_draft first."}),
                is_terminal=False,
            )

        if not self._critic_provider:
            return ToolResult(
                content=json.dumps({"error": "Critic agent is not configured (no LLM provider available)."}),
                is_terminal=False,
            )

        if not self._merged_delta:
            return ToolResult(
                content=json.dumps({"error": "No API delta available. Call extract_api_changes first."}),
                is_terminal=False,
            )

        if self._critic is None:
            from core.critic import CriticAgent

            self._critic = CriticAgent(self._critic_provider)

        delta_summary = json.dumps(self._delta_to_dict(self._merged_delta))
        result = self._critic.critique(self._current_draft, delta_summary)

        return ToolResult(
            content=json.dumps(result),
            is_terminal=False,
        )

    def _evaluate_quality(self, compare_with_existing: bool = False) -> ToolResult:
        if not self._current_draft:
            return ToolResult(
                content=json.dumps({"error": "No draft available. Call store_draft first."}),
                is_terminal=False,
            )

        if not self._evaluator_provider:
            return ToolResult(
                content=json.dumps({"error": "Quality evaluator is not configured (no LLM provider available)."}),
                is_terminal=False,
            )

        # Skip evaluator for small changes — critic review is sufficient
        if self._merged_delta:
            total_endpoints = (
                len(self._merged_delta.new)
                + len(self._merged_delta.modified)
                + len(self._merged_delta.removed)
            )
            if total_endpoints <= 2:
                return ToolResult(
                    content=json.dumps({
                        "skipped": True,
                        "reason": f"Only {total_endpoints} endpoint(s) changed — critic review is sufficient for small deltas.",
                        "qualityScore": None,
                    }),
                    is_terminal=False,
                )

        if self._evaluator is None:
            from core.evaluator import QualityEvaluator

            self._evaluator = QualityEvaluator(self._evaluator_provider)

        output_dir = str(Path(self.repo_path) / self.config.output_dir)
        result = self._evaluator.evaluate(self._current_draft, output_dir, compare_with_existing)

        return ToolResult(
            content=json.dumps(result),
            is_terminal=False,
        )

    # ─── Serialization helpers ────────────────────────────────────────────────

    @staticmethod
    def _delta_to_dict(delta: ExtractedApiDelta) -> dict:
        def endpoint_dict(ep):
            d = {"method": ep.method, "path": ep.path}
            if ep.handler:
                d["handler"] = ep.handler
            if ep.request_schema:
                d["requestSchema"] = [
                    {"name": s.name, "type": s.type, "required": s.required}
                    for s in ep.request_schema
                ]
            if ep.response_schema:
                d["responseSchema"] = [
                    {"name": s.name, "type": s.type, "required": s.required}
                    for s in ep.response_schema
                ]
            if ep.auth:
                d["auth"] = {"type": ep.auth.type}
                if ep.auth.scopes:
                    d["auth"]["scopes"] = ep.auth.scopes
            if ep.tags:
                d["tags"] = ep.tags
            return d

        return {
            "feature": delta.feature,
            "branch": delta.branch,
            "baseBranch": delta.base_branch,
            "timestamp": delta.timestamp,
            "new": [endpoint_dict(e) for e in delta.new],
            "modified": [
                {
                    "before": endpoint_dict(m.before),
                    "after": endpoint_dict(m.after),
                    "changeType": m.change_type,
                }
                for m in delta.modified
            ],
            "removed": [endpoint_dict(e) for e in delta.removed],
            "contractChanges": [
                {"endpoint": c.endpoint, "changeType": c.change_type, "description": c.description}
                for c in delta.contract_changes
            ],
            "authChanges": [
                {"file": a.file, "type": a.type, "description": a.description} for a in delta.auth_changes
            ],
            "versioningChanges": [
                {"type": v.type, "description": v.description} for v in delta.versioning_changes
            ],
        }
