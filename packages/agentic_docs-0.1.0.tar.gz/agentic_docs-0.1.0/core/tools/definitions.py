"""Tool catalogue exposed to the LLM during the agent loop.
Each tool wraps a deterministic L2/L3/L6/L7 operation.
"""

TOOL_DEFINITIONS: list[dict] = [
    {
        "name": "get_changed_files",
        "description": (
            "Get files changed between the current branch and the base branch. "
            "Returns a list of changed files with their status and a short diff preview. "
            "Always call this first before any other tool."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "extract_api_changes",
        "description": (
            "Extract structured API changes from the changed files for a specific framework. "
            "Run this for each relevant framework (django, fastapi, flask). "
            "Results are accumulated across multiple calls."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "framework": {
                    "type": "string",
                    "enum": ["django", "fastapi", "flask"],
                    "description": "The Python framework to extract API changes for",
                },
            },
            "required": ["framework"],
        },
    },
    {
        "name": "read_memory",
        "description": (
            "Read a skill memory file. "
            "Project scope: api-patterns, auth-patterns, versioning, master (repo-specific). "
            "Global scope: common-patterns, auth-strategies, style-guide (shared cross-project)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "skill": {
                    "type": "string",
                    "description": (
                        "Skill file to read. "
                        "Project: api-patterns | auth-patterns | versioning | master. "
                        "Global: common-patterns | auth-strategies | style-guide."
                    ),
                },
                "scope": {
                    "type": "string",
                    "enum": ["project", "global"],
                    "description": "Memory scope (default: project)",
                },
            },
            "required": ["skill"],
        },
    },
    {
        "name": "store_draft",
        "description": (
            "Store your documentation draft for use by quality and writing tools. "
            "Call this once with your full markdown draft. Subsequent calls to "
            "validate_documentation, critique_documentation, evaluate_quality, "
            "and write_documentation will automatically use the stored draft. "
            "Call again to update the draft after revisions."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "documentation": {
                    "type": "string",
                    "description": "The full markdown documentation draft",
                },
            },
            "required": ["documentation"],
        },
    },
    {
        "name": "validate_documentation",
        "description": (
            "Validate the stored draft against the extracted API delta. "
            "Returns valid (boolean), errors[], and warnings[]. "
            "Fix all errors before calling write_documentation. "
            "Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "write_documentation",
        "description": (
            "Write the stored draft to disk as both .md and .docx files. "
            "This is a TERMINAL action — the agent loop exits after this call. "
            "Only call after validate_documentation returns valid=true with no errors. "
            "Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "featureName": {
                    "type": "string",
                    "description": (
                        'The feature name used for the output filename (e.g. "user-auth", "payment-api")'
                    ),
                },
            },
            "required": ["featureName"],
        },
    },
    {
        "name": "signal_no_change",
        "description": (
            "Signal that no API changes were found and no documentation is needed. "
            "This is a TERMINAL action — the agent loop exits after this call. "
            "Call only after running extract_api_changes and finding no endpoints changed."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "reason": {
                    "type": "string",
                    "description": "Brief explanation of why no API changes were found",
                },
            },
            "required": ["reason"],
        },
    },
    # ─── Agentic enhancements ─────────────────────────────────────────────────
    {
        "name": "read_file",
        "description": (
            "Read an arbitrary file from the repository for additional context. "
            "Use this to explore source code beyond the diff when you need to understand "
            "how an endpoint works, what types are used, or how auth is configured. "
            "L2 extraction remains the ground truth — this is supplementary."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Relative path from the repo root (e.g. 'src/routes/users.ts')",
                },
                "offset": {
                    "type": "integer",
                    "description": "Line offset to start reading from (0-based, default 0)",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of lines to return (default 100, max 300)",
                },
            },
            "required": ["path"],
        },
    },
    {
        "name": "search_codebase",
        "description": (
            "Search the repository codebase using a regex pattern. "
            "Returns matching lines with file paths and line numbers. "
            "Use this to find usages, imports, type definitions, or related code."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Regex pattern to search for",
                },
                "glob": {
                    "type": "string",
                    "description": "Optional glob filter for file paths (e.g. '*.py', 'src/**/*.ts')",
                },
                "maxResults": {
                    "type": "integer",
                    "description": "Maximum number of matching lines to return (default 20, max 50)",
                },
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "create_plan",
        "description": (
            "Create a goal-oriented plan for the documentation task. "
            "Formulate a high-level goal and ordered steps. "
            "Call this early to structure your approach. You can revise later."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "goal": {
                    "type": "string",
                    "description": "The high-level goal for this documentation run",
                },
                "steps": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Ordered list of steps to achieve the goal",
                },
            },
            "required": ["goal", "steps"],
        },
    },
    {
        "name": "revise_plan",
        "description": (
            "Revise the current plan mid-execution. "
            "Use this when you discover new information that changes the approach."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "reason": {
                    "type": "string",
                    "description": "Why the plan needs to change",
                },
                "updatedSteps": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "The revised ordered list of steps",
                },
            },
            "required": ["reason", "updatedSteps"],
        },
    },
    {
        "name": "search_memory",
        "description": (
            "Search across skill memory files using keywords. "
            "Returns ranked sections matching the query. "
            "Set scope to 'all' to search both project and global memory."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Keywords to search for in skill memory",
                },
                "maxResults": {
                    "type": "integer",
                    "description": "Maximum number of sections to return (default 5)",
                },
                "scope": {
                    "type": "string",
                    "enum": ["project", "global", "all"],
                    "description": "Which memory scope to search (default: all)",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "store_memory",
        "description": (
            "Store a new insight or pattern in skill memory for future runs. "
            "Use scope 'project' for repo-specific patterns (naming, auth, versioning). "
            "Use scope 'global' for cross-project insights (company-wide conventions, common patterns)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "category": {
                    "type": "string",
                    "enum": ["api", "auth", "versioning", "general", "style"],
                    "description": "Which skill category to store under",
                },
                "content": {
                    "type": "string",
                    "description": "The insight or pattern to remember",
                },
                "title": {
                    "type": "string",
                    "description": "Short title for this memory entry",
                },
                "scope": {
                    "type": "string",
                    "enum": ["project", "global"],
                    "description": "Where to store: project (local repo) or global (shared across projects)",
                },
            },
            "required": ["category", "content", "title"],
        },
    },
    {
        "name": "critique_documentation",
        "description": (
            "Submit the stored draft for critic review by a separate LLM instance. "
            "Returns scores (1-10) for completeness, clarity, accuracy, structure, and tone, "
            "plus actionable suggestions. Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "evaluate_quality",
        "description": (
            "Evaluate the quality of the stored draft using LLM-based scoring. "
            "Returns a quality score and dimension-level scores for target audience fit, "
            "completeness, code examples, and consistency. Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "compareWithExisting": {
                    "type": "boolean",
                    "description": "Whether to compare against existing docs in the output dir for style consistency",
                },
            },
            "required": [],
        },
    },
]

# Tools available before a draft exists — excludes quality/writing tools that need store_draft
_QUALITY_TOOL_NAMES = {
    "critique_documentation",
    "evaluate_quality",
    "validate_documentation",
    "write_documentation",
}

EXPLORATION_TOOLS: list[dict] = [t for t in TOOL_DEFINITIONS if t["name"] not in _QUALITY_TOOL_NAMES]
