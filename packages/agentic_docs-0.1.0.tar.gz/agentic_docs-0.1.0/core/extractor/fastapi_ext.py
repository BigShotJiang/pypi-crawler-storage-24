"""FastAPI decorator extractor."""

from __future__ import annotations

import re

from core.extractor.types import (
    ApiEndpoint,
    AuthRequirement,
    ChangedFile,
    ModifiedEndpoint,
    SchemaField,
    PathParam,
    QueryParam
)

# @app.get("/path") | @router.post("/path/{id}")
ROUTE_PATTERN = re.compile(
    r"@(?:app|router)\s*\.\s*(get|post|put|patch|delete|head|options)\s*\(\s*['\"]([^'\"]+)['\"]",
    re.IGNORECASE,
)


class FastApiExtractor:
    def detect(self, files: list[ChangedFile]) -> list[ChangedFile]:
        return [f for f in files if f.path.endswith(".py") and self._looks_like_fastapi(f.diff + (f.content or ""))]

    def extract(self, file: ChangedFile, full_content: str) -> dict:
        added = self._parse_routes(self._diff_lines(file.diff, "+"), full_content)
        removed = self._parse_routes(self._diff_lines(file.diff, "-"), "")
        return self._categorise(added, removed)

    # ─── Private helpers ────────────────────────────────────────────────────────

    @staticmethod
    def _looks_like_fastapi(src: str) -> bool:
        pattern = r"from\s+fastapi\s+import|@(?:app|router)\.(get|post|put|patch|delete)"
        return bool(re.search(pattern, src, re.IGNORECASE))

    @staticmethod
    def _diff_lines(diff: str, marker: str) -> str:
        triple = marker * 3
        return "\n".join(
            line[1:] for line in diff.split("\n") if line.startswith(marker) and not line.startswith(triple)
        )

    def _parse_routes(self, src: str, full_content: str) -> list[ApiEndpoint]:
        results: list[ApiEndpoint] = []
        for m in ROUTE_PATTERN.finditer(src):
            path = m.group(2)

            results.append(
                ApiEndpoint(
                    method=m.group(1).upper(),
                    path=path,
                    request_schema=self._extract_pydantic_fields(full_content, m.start()),
                    response_schema=self._extract_response_schema(full_content, m.start()),
                    params=self._extract_path_params(path),
                    query=self._extract_query_params(full_content, m.start()),
                    auth=self._detect_auth(full_content, m.start()),
                )
            )
        print("FASTAPI EXTRACTED:", results)
        return results

    @staticmethod
    def _extract_pydantic_fields(src: str, pos: int) -> list[SchemaField]:
        """Attempt to pull field names/types from a Pydantic BaseModel near the route."""
        ctx = src[pos : pos + 1000]
        fields: list[SchemaField] = []
        for m in re.finditer(
            r"^\s+(\w+)\s*:\s*(Optional\[[\w\[\], ]+\]|List\[[\w\[\], ]+\]|str|int|float|bool|[\w]+)",
            ctx,
            re.MULTILINE,
        ):
            fields.append(
                SchemaField(name=m.group(1), type=m.group(2), required=not m.group(2).startswith("Optional"))
            )
            if len(fields) >= 12:
                break
        return fields

    @staticmethod
    def _detect_auth(src: str, pos: int) -> AuthRequirement:
        ctx = src[max(0, pos - 400) : pos + 400]
        if re.search(r"Depends\s*\(\s*(?:get_current_user|oauth2_scheme|bearer)", ctx, re.IGNORECASE):
            return AuthRequirement(type="bearer")
        if re.search(r"api_key|APIKey", ctx, re.IGNORECASE):
            return AuthRequirement(type="api-key")
        return AuthRequirement(type="none")

    @staticmethod
    def _categorise(added: list[ApiEndpoint], removed: list[ApiEndpoint]) -> dict:
        new_eps: list[ApiEndpoint] = []
        modified: list[ModifiedEndpoint] = []
        removed_eps: list[ApiEndpoint] = []

        for ep in added:
            prev = next((r for r in removed if r.path == ep.path and r.method == ep.method), None)
            if prev:
                modified.append(ModifiedEndpoint(before=prev, after=ep, change_type="request-schema"))
            else:
                new_eps.append(ep)

        for ep in removed:
            if not any(a.path == ep.path and a.method == ep.method for a in added):
                removed_eps.append(ep)

        return {
            "new": new_eps,
            "modified": modified,
            "removed": removed_eps,
            "contract_changes": [],
            "auth_changes": [],
            "versioning_changes": [],
        }

    def _extract_path_params(self, path: str) -> list[PathParam]:
        params: list[PathParam] = []

        for p in re.findall(r"{(\w+)}", path):
            params.append(PathParam(name=p, type="string"))

        return params
    
    def _extract_query_params(self, src: str, pos: int) -> list[QueryParam]:
        ctx = src[pos:pos+400]

        params: list[QueryParam] = []

        for m in re.finditer(r"(\w+)\s*:\s*(Optional\[[^\]]+\]|List\[[^\]]+\]|int|str|float|bool)\s*=", ctx):
            name = m.group(1)
            typ = m.group(2)

            params.append(
                QueryParam(
                    name=name,
                    type=typ.replace("Optional[", "").replace("]", ""),
                    required="Optional" not in typ
                )
            )

        return params
    
    def _extract_response_schema(self, src: str, pos: int) -> list[SchemaField] | None:
        ctx = src[pos:pos+400]

        m = re.search(r"response_model\s*=\s*(\w+)", ctx)

        if not m:
            return None

        model = m.group(1)

        return [SchemaField(name="body", type=model, required=True)]