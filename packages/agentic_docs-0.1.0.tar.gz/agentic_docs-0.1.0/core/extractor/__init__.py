from core.extractor.django_ext import DjangoExtractor
from core.extractor.fastapi_ext import FastApiExtractor
from core.extractor.flask_ext import FlaskExtractor
from core.extractor.types import ChangedFile, ExtractedApiDelta, Framework
from core.logger import logger

EXTRACTORS: dict[str, object] = {
    "django": DjangoExtractor(),
    "fastapi": FastApiExtractor(),
    "flask": FlaskExtractor(),
}


def extract_api_delta(
    changed_files: list[ChangedFile],
    feature: str,
    branch: str,
    base_branch: str,
    frameworks: list[Framework] | None = None,
) -> ExtractedApiDelta:
    """
    L2 entry point.
    Takes changed files from git, runs all relevant extractors,
    and returns a fully structured ExtractedApiDelta.
    """
    if frameworks is None:
        frameworks = ["django", "fastapi", "flask"]

    from datetime import datetime, timezone

    delta = ExtractedApiDelta(
        feature=feature,
        branch=branch,
        base_branch=base_branch,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )

    for framework in frameworks:
        if framework == "unknown":
            continue
        extractor = EXTRACTORS.get(framework)
        if extractor is None:
            continue

        relevant = extractor.detect(changed_files)
        logger.debug(f"[{framework}] matched {len(relevant)} file(s)")

        for file in relevant:
            partial = extractor.extract(file, file.content or "")
            delta.new.extend(partial.get("new", []))
            delta.modified.extend(partial.get("modified", []))
            delta.removed.extend(partial.get("removed", []))
            delta.contract_changes.extend(partial.get("contract_changes", []))
            delta.auth_changes.extend(partial.get("auth_changes", []))
            delta.versioning_changes.extend(partial.get("versioning_changes", []))

    logger.debug(
        f"Extraction summary — new: {len(delta.new)}, modified: {len(delta.modified)}, removed: {len(delta.removed)}"
    )
    return delta


def has_api_changes(delta: ExtractedApiDelta) -> bool:
    return (
        len(delta.new) > 0
        or len(delta.modified) > 0
        or len(delta.removed) > 0
        or len(delta.contract_changes) > 0
        or len(delta.auth_changes) > 0
    )
