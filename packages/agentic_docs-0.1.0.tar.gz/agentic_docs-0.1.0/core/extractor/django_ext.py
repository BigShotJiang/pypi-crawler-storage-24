"""Django URL pattern extractor.

Detects:
  - path("api/users/", views.UserListView.as_view())
  - path("api/users/<int:pk>/", views.UserDetailView)
  - re_path(r"^api/orders/(?P<order_id>\\d+)/$", views.order_detail)
  - @api_view(["GET", "POST"])  (DRF function-based views)
  - class UserViewSet(ModelViewSet)  (DRF viewsets with router.register)
  - router.register(r"users", UserViewSet)
"""

from __future__ import annotations

import re

from core.extractor.types import (
    ApiEndpoint,
    AuthRequirement,
    ChangedFile,
    ModifiedEndpoint,
)

# path("api/users/", ...) | path("api/users/<int:pk>/", ...)
PATH_PATTERN = re.compile(
    r"""(?:re_)?path\s*\(\s*[r]?['"]([^'"]+)['"]""",
    re.IGNORECASE,
)

# @api_view(["GET", "POST"])
API_VIEW_PATTERN = re.compile(
    r"@api_view\s*\(\s*\[([^\]]+)\]",
    re.IGNORECASE,
)

# router.register(r"users", UserViewSet)
ROUTER_REGISTER_PATTERN = re.compile(
    r"router\s*\.\s*register\s*\(\s*[r]?['\"]([^'\"]+)['\"]",
    re.IGNORECASE,
)

# class UserViewSet(ModelViewSet) | class UserView(APIView)
DRF_CLASS_PATTERN = re.compile(
    r"class\s+(\w+)\s*\(.*(?:ViewSet|APIView|GenericAPIView|ModelViewSet|ReadOnlyModelViewSet|CreateAPIView|ListAPIView|RetrieveAPIView|UpdateAPIView|DestroyAPIView)",
    re.IGNORECASE,
)

# HTTP method decorators: @action(detail=True, methods=["post"])
ACTION_PATTERN = re.compile(
    r"@action\s*\([^)]*methods\s*=\s*\[([^\]]+)\][^)]*(?:detail\s*=\s*(True|False))?",
    re.IGNORECASE,
)

URLPATTERNS_METHODS = {
    "List": ["GET"],
    "Create": ["POST"],
    "Retrieve": ["GET"],
    "Update": ["PUT", "PATCH"],
    "Destroy": ["DELETE"],
    "ListCreate": ["GET", "POST"],
    "RetrieveUpdate": ["GET", "PUT", "PATCH"],
    "RetrieveDestroy": ["GET", "DELETE"],
    "RetrieveUpdateDestroy": ["GET", "PUT", "PATCH", "DELETE"],
}


class DjangoExtractor:
    def detect(self, files: list[ChangedFile]) -> list[ChangedFile]:
        return [
            f
            for f in files
            if f.path.endswith(".py") and self._looks_like_django(f.diff + (f.content or ""))
        ]

    def extract(self, file: ChangedFile, full_content: str) -> dict:
        added = self._parse_routes(self._diff_lines(file.diff, "+"), full_content)
        removed = self._parse_routes(self._diff_lines(file.diff, "-"), "")
        return self._categorise(added, removed)

    # ─── Private helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _looks_like_django(src: str) -> bool:
        return bool(
            re.search(
                r"from\s+django|from\s+rest_framework|urlpatterns|@api_view|ViewSet|APIView|router\.register",
                src,
                re.IGNORECASE,
            )
        )

    @staticmethod
    def _diff_lines(diff: str, marker: str) -> str:
        triple = marker * 3
        return "\n".join(
            line[1:] for line in diff.split("\n") if line.startswith(marker) and not line.startswith(triple)
        )

    def _parse_routes(self, src: str, full_content: str) -> list[ApiEndpoint]:
        results: list[ApiEndpoint] = []

        # 1) path() / re_path() entries
        for m in PATH_PATTERN.finditer(src):
            raw_path = m.group(1)
            path = self._normalise_path(raw_path)
            methods = self._infer_methods_from_context(src, m.start())
            auth = self._detect_auth(full_content or src, m.start())

            if methods:
                for method in methods:
                    results.append(ApiEndpoint(method=method, path=path, auth=auth))
            else:
                results.append(ApiEndpoint(method="GET", path=path, auth=auth))

        # 2) @api_view(["GET", "POST"]) — DRF function-based views
        for m in API_VIEW_PATTERN.finditer(src):
            methods_str = m.group(1)
            methods = [s.strip().strip("'\"").upper() for s in methods_str.split(",")]
            func_name = self._find_function_after(src, m.end())
            path = f"/{func_name}/" if func_name else "/unknown/"
            auth = self._detect_auth(full_content or src, m.start())
            for method in methods:
                if method in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"):
                    results.append(ApiEndpoint(method=method, path=path, handler=func_name, auth=auth))

        # 3) router.register(r"users", UserViewSet)
        for m in ROUTER_REGISTER_PATTERN.finditer(src):
            prefix = m.group(1).strip("/")
            path = f"/api/{prefix}/" if prefix else "/api/"
            auth = self._detect_auth(full_content or src, m.start())
            for method in ("GET", "POST"):
                results.append(ApiEndpoint(method=method, path=path, auth=auth))
            results.append(ApiEndpoint(method="GET", path=f"{path}{{id}}/", auth=auth))
            results.append(ApiEndpoint(method="PUT", path=f"{path}{{id}}/", auth=auth))
            results.append(ApiEndpoint(method="DELETE", path=f"{path}{{id}}/", auth=auth))

        return results

    @staticmethod
    def _normalise_path(raw: str) -> str:
        path = raw.strip("/")
        path = re.sub(r"\(\?P<(\w+)>[^)]+\)", r"{\1}", path)
        path = re.sub(r"<(?:\w+:)?(\w+)>", r"{\1}", path)
        return f"/{path}/" if path else "/"

    @staticmethod
    def _infer_methods_from_context(src: str, pos: int) -> list[str]:
        ctx = src[max(0, pos - 300) : pos + 300]
        for class_suffix, methods in URLPATTERNS_METHODS.items():
            if class_suffix in ctx:
                return methods
        return []

    @staticmethod
    def _find_function_after(src: str, pos: int) -> str | None:
        rest = src[pos : pos + 300]
        m = re.search(r"def\s+(\w+)", rest)
        return m.group(1) if m else None

    @staticmethod
    def _detect_auth(src: str, pos: int) -> AuthRequirement:
        ctx = src[max(0, pos - 400) : pos + 400]
        if re.search(r"IsAuthenticated|permission_classes|IsAdminUser|TokenAuthentication", ctx, re.IGNORECASE):
            return AuthRequirement(type="bearer")
        if re.search(r"SessionAuthentication|login_required", ctx, re.IGNORECASE):
            return AuthRequirement(type="basic")
        if re.search(r"APIKey|api_key", ctx, re.IGNORECASE):
            return AuthRequirement(type="api-key")
        return AuthRequirement(type="none")

    @staticmethod
    def _categorise(added: list[ApiEndpoint], removed: list[ApiEndpoint]) -> dict:
        new_eps: list[ApiEndpoint] = []
        modified: list[ModifiedEndpoint] = []
        removed_eps: list[ApiEndpoint] = []

        for ep in added:
            prev = next((r for r in removed if r.path == ep.path and r.method == ep.method), None)
            if prev:
                modified.append(ModifiedEndpoint(before=prev, after=ep, change_type="request-schema"))
            else:
                new_eps.append(ep)

        for ep in removed:
            if not any(a.path == ep.path and a.method == ep.method for a in added):
                removed_eps.append(ep)

        return {
            "new": new_eps,
            "modified": modified,
            "removed": removed_eps,
            "contract_changes": [],
            "auth_changes": [],
            "versioning_changes": [],
        }
