"""Multi-turn agent loop (L5). Drives the LLM through tool calls until a terminal tool is called."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from typing import Literal

from core.config import AgentConfig
from core.llm.base import LLMProvider, ToolCallResult
from core.logger import logger
from core.memory import MemoryManager
from core.tools.definitions import EXPLORATION_TOOLS, TOOL_DEFINITIONS
from core.tools.executor import ToolExecutor

DEFAULT_MAX_TURNS = 20

# When cumulative usage hits this fraction of the budget, warn the agent to wrap up
BUDGET_WARNING_THRESHOLD = 0.85

# Number of recent turns to keep in full detail; older turns get compacted
FULL_CONTEXT_WINDOW = 3

SYSTEM_PROMPT = """\
You are a senior API documentation engineer with deep expertise in REST APIs, developer \
experience, and technical writing. Your goal is to analyze code changes on a feature branch \
and produce documentation that a developer could use to integrate the API immediately — \
precise, complete, and requiring zero follow-up questions.

## Tools

You have tools for exploration, planning, memory, quality assurance, and writing. \
Refer to the tool definitions for details.

Memory scopes: **project** (per-repo patterns) and **global** (cross-project shared knowledge). \
Use `store_memory` with `scope: "global"` only for insights that apply across all projects.

## Process

**Step 1 — Plan**
Always call `create_plan` first. State a clear goal and 4–6 concrete steps based on what you know.

**Step 2 — Discover changes**
Call `get_changed_files`, then call `extract_api_changes` for each relevant framework:
- `urls.py`, `views.py`, `serializers.py` → django
- `routers.py`, `@app.get/post/...` decorators → fastapi
- `routes.py`, `@bp.route`, `@app.route` → flask
Skip any framework not represented in the changed files.

**Step 3 — Investigate deeply**
If schemas, auth, or parameter details are unclear from the diff alone, use `read_file` to check:
- Request/response schemas (Pydantic models, DRF serializers, TypedDicts)
- Authentication decorators and permission classes
- Path and query parameter types, constraints, validation
- Error responses and status codes
Use `search_codebase` to find shared middleware, auth dependencies, or reusable validators.

**Step 4 — Check memory**
Call `search_memory` with keywords from the branch name and endpoint paths. Past runs may \
contain naming conventions, auth patterns, or style preferences that apply here.

**Step 5 — Draft documentation**
Write a complete first draft. See "Documentation Standards" below for what each section must contain. \
Call `store_draft` once with your full markdown draft. Quality and writing tools use the stored draft \
automatically — you do not need to pass the documentation text again.

**Step 6 — Quality loop**
- Call `critique_documentation` — read every score and suggestion carefully
- Call `evaluate_quality` — check developer experience scores
- Revise the draft to address all flagged issues — call `store_draft` again with the updated draft
- If overall critic score < 8, revise and re-critique before proceeding

**Step 7 — Validate and write**
Call `validate_documentation`. If it returns errors, fix only the specific issues flagged — \
update the draft with `store_draft` and re-validate. Then call `write_documentation`.

## Documentation Standards

Write for a developer who has never seen this codebase and needs to integrate the API today.

# Required sections (include only if supporting data exists)

## `# Feature: <name>` — Always required. Derive from branch name (strip `feature/`, `feat/`, etc.)

Immediately after the feature heading include:

Generated Date: YYYY-MM-DD

## `## Overview`
2–4 sentences. What does this feature do? What business problem does it solve? Who calls it?

### Base URL
```
https://<host>/<api-prefix>
```
> For local development: `http://localhost:<port>/<api-prefix>`

### Rate Limiting
If a global RATE_LIMIT configuration is present in the codebase,
document the request limit and time window.

Example:
Rate Limit: 100 requests per minute per token

Headers:
- X-RateLimit-Limit
- X-RateLimit-Remaining
- Retry-After

### Environments
List available environments.

Example:

- **Development**
  - URL: https://dev-api.example.com

- **Staging**
  - URL: https://staging-api.example.com

- **Production**
  - URL: https://api.example.com

### Common HTTP Status Codes

- **200 OK**
  - Successful GET / PUT

- **201 Created**
  - Successful POST creating a resource

- **204 No Content**
  - Successful DELETE

- **400 Bad Request**
  - Missing or invalid request body / query params

- **401 Unauthorized**
  - Missing or invalid authentication token

- **403 Forbidden**
  - Authenticated but insufficient permissions

- **404 Not Found**
  - Resource does not exist

- **409 Conflict**
  - Duplicate resource or state conflict

- **422 Unprocessable Entity**
  - Validation errors on the payload

- **429 Too Many Requests**
  - Rate limit exceeded

- **500 Internal Server Error**
  - Unhandled server-side exception

## `## New APIs` (for each new endpoint)

Use `### METHOD /path` as the heading. Include:
- One-line description of what the endpoint does

### Endpoint Subsection Structure
Each endpoint must follow this subsection structure:

#### Authentication
Describe the authentication method required.
Include:
- Auth type (Bearer, API Key, Session, etc.)
- Header name and location
- Example header value
Example:

```bash
Authorization: Bearer <token>

#### Path Parameters
Describe parameters using bullet lists instead of tables.

Example:

- **report_id**
  - Type: string (UUID v4)
  - Required: Yes
  - Description: Unique identifier for the report
  - Example: report_123XYZ


#### Query Parameters
Use the same bullet list structure as Path Parameters.

#### Pagination (if applicable)

If the endpoint supports pagination (e.g. `page`, `limit`, `offset`, `cursor`),
document the pagination parameters and response fields.

Example:

GET /api/test/results?page=1&limit=20

Example Response:

```json
{
  "page": 1,
  "limit": 20,
  "total": 120,
  "data": []
}

#### Request Body— content-type, full JSON schema \
  (field name, type, required/optional, description), Example JSON payload in fenced code block with json label
- **Response** — success status code, full response schema, Example JSON response in fenced code block (json)
- **Errors** — all non-2xx status codes with meaning and when they occur
- **cURL example** — runnable command with realistic placeholder values and correct auth header

## Modified APIs (for each changed endpoint)
- What specifically changed (not just "modified" — e.g. "added optional `status` query parameter", \
  "response now includes `metadata` object")
- For contract changes: before/after comparison
- Breaking or non-breaking? If breaking, what must callers change?

**`## Removed APIs`** (for deleted endpoints)
- Which endpoint was removed
- Recommended replacement or migration path

**`## Authentication Changes`** (if auth requirements changed)
- What changed and why it matters to callers

**`## Breaking Changes`** (if any change is breaking)
- Explicit list, one item per breaking change
- Code example showing required caller-side migration

**`## Migration Notes`** (if callers need to update integrations)
Step-by-step instructions with before/after code examples.

### Writing standards
- Use `METHOD /path` inline code for every endpoint reference (e.g. `POST /api/v2/payments`)
- Use realistic example values — not `string`, `123` — use `user_01HXYZ`, `2025-03-05T14:30:00Z`
- State types explicitly: `string (UUID v4)`, `integer (Unix ms timestamp)`, `boolean`
- Every cURL example must include the auth header if the endpoint is authenticated
- Always use bullet lists for parameters instead of tables.
- Omit sections with no data — never write empty sections or placeholder text

## Hard Rules (NEVER violate)
- ONLY document endpoints present in `extract_api_changes` output — never infer or invent endpoints
- Documentation MUST begin with `# Feature: <featureName>` — no exceptions
- Always call `validate_documentation` before `write_documentation`
- L2 extraction is ground truth — `read_file` and `search_codebase` provide context only
- Never speculate: if a field's type or response schema is unclear, use `read_file` to find it; \
  if still unknown, state "Refer to implementation" rather than guessing
- If no API-related files changed across all frameworks, call `signal_no_change` immediately

## Markdown Formatting Rules

- Always use proper heading levels (`#`, `##`, `###`, `####`) for feature, overview, endpoints, and subsections.
- Use fenced code blocks for all JSON and cURL examples with language labels (`json`, `bash`).
- Include a short label above each code block (e.g., "Example JSON Request", "Example Response JSON").
- Do not merge multiple sections under the same heading; each subsection gets its own heading.
- Separate multiple endpoints with a horizontal rule `---` to improve DOCX readability.
"""

RunStatus = Literal["NO_API_CHANGE", "GENERATED", "FAILED", "VALIDATION_FAILED"]


@dataclass
class RunResult:
    status: RunStatus
    feature_name: str | None = None
    output_path: str | None = None
    error: str | None = None
    usage: dict | None = None


def _estimate_tokens(text: str) -> int:
    """Quick token estimate: ~4 chars per token."""
    return math.ceil(len(text) / 4)


def _estimate_message_tokens(messages: list) -> int:
    """Rough token count for the entire message list."""
    total = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total += _estimate_tokens(content)
        elif isinstance(content, list):
            for block in content:
                if isinstance(block, dict):
                    total += _estimate_tokens(json.dumps(block))
                else:
                    total += _estimate_tokens(str(block))
        else:
            total += _estimate_tokens(str(content))
    return total


class AgentLoop:
    def __init__(
        self,
        executor: ToolExecutor,
        config: AgentConfig,
        provider: LLMProvider,
        memory: MemoryManager,
    ) -> None:
        self.executor = executor
        self.config = config
        self.provider = provider
        self._memory = memory

    async def run(self, branch: str, base_branch: str) -> RunResult:
        max_turns = self.config.max_turns
        max_in = self.config.max_input_tokens
        max_out = self.config.max_output_tokens

        initial_parts = [
            f"Analyze branch '{branch}' against '{base_branch}'. "
            f"Explore the changes, extract API modifications, and generate comprehensive documentation."
        ]

        if self.config.languages:
            initial_parts.append(
                f"\nCode languages in this project: {', '.join(self.config.languages)}"
            )

        auto_context = self._memory.get_auto_context(branch, [])
        if auto_context:
            initial_parts.append(f"\n\n{auto_context}")

        messages: list = [
            {"role": "user", "content": "\n".join(initial_parts)},
        ]

        total_usage = {"inputTokens": 0, "outputTokens": 0}
        budget_warning_sent = False

        for turn in range(1, max_turns + 1):
            logger.info(f"Agent turn {turn}/{max_turns}")

            # ── Progressive tool availability ────────────────────────────────
            # tool_set = TOOL_DEFINITIONS if self.executor._current_draft else EXPLORATION_TOOLS
            if self.executor._current_draft or self.executor._merged_delta:
                tool_set = TOOL_DEFINITIONS
            else:
                tool_set = EXPLORATION_TOOLS

            tools = self.provider.get_tool_definitions(tool_set)

            # ── Budget check before calling the LLM ──────────────────────────
            if total_usage["inputTokens"] >= max_in:
                logger.error(f"Input token budget exhausted ({total_usage['inputTokens']}/{max_in})")
                return RunResult(
                    status="FAILED",
                    error=f"Input token budget exhausted: {total_usage['inputTokens']}/{max_in}",
                    usage=total_usage,
                )
            if total_usage["outputTokens"] >= max_out:
                logger.error(f"Output token budget exhausted ({total_usage['outputTokens']}/{max_out})")
                return RunResult(
                    status="FAILED",
                    error=f"Output token budget exhausted: {total_usage['outputTokens']}/{max_out}",
                    usage=total_usage,
                )

            # ── Warn agent when approaching budget ───────────────────────────
            in_pct = total_usage["inputTokens"] / max_in
            out_pct = total_usage["outputTokens"] / max_out
            if not budget_warning_sent and (in_pct >= BUDGET_WARNING_THRESHOLD or out_pct >= BUDGET_WARNING_THRESHOLD):
                budget_warning_sent = True
                messages.append({
                    "role": "user",
                    "content": (
                        f"[SYSTEM] Token budget warning: input {total_usage['inputTokens']}/{max_in} "
                        f"({in_pct:.0%}), output {total_usage['outputTokens']}/{max_out} ({out_pct:.0%}). "
                        "Wrap up now — validate and write documentation immediately, or signal no change."
                    ),
                })
                logger.warn(f"Budget warning injected: input {in_pct:.0%}, output {out_pct:.0%}")

            # ── Compact old messages to save tokens ──────────────────────────
            if turn > FULL_CONTEXT_WINDOW + 1:
                messages = self._compact_old_messages(messages)

            # ── Calculate per-turn output cap ────────────────────────────────
            remaining_out = max_out - total_usage["outputTokens"]
            per_turn_max = min(8_192, max(1_024, remaining_out))

            # ── Call LLM ─────────────────────────────────────────────────────
            try:
                response = self.provider.chat(
                    system=SYSTEM_PROMPT,
                    messages=messages,
                    tools=tools,
                    max_tokens=per_turn_max,
                )
            except Exception as err:
                return RunResult(
                    status="FAILED",
                    error=f"LLM API error on turn {turn}: {err}",
                    usage=total_usage,
                )

            total_usage["inputTokens"] += response.usage.input_tokens
            total_usage["outputTokens"] += response.usage.output_tokens
            logger.debug(
                f"Turn {turn} — stop: {response.stop_reason}, "
                f"in: {response.usage.input_tokens}, out: {response.usage.output_tokens} | "
                f"cumulative in: {total_usage['inputTokens']}/{max_in}, out: {total_usage['outputTokens']}/{max_out}"
            )

            messages.append(self.provider.build_assistant_message(response))

            # ── end_turn without terminal tool ────────────────────────────────
            # if response.stop_reason == "end_turn":
            #     logger.warn("Agent reached end_turn without calling a terminal tool")
            #     return RunResult(
            #         status="FAILED",
            #         error="Agent ended without writing documentation or signaling no change",
            #         usage=total_usage,
            #     )
            if response.stop_reason == "end_turn":
                logger.warn("Agent returned end_turn without terminal tool. Forcing completion step.")

                messages.append({
                    "role": "user",
                    "content": (
                        "You must finish the workflow now.\n\n"
                        "If API changes exist:\n"
                        "1. Call validate_documentation\n"
                        "2. Then call write_documentation\n\n"
                        "If no API changes exist:\n"
                        "Call signal_no_change.\n\n"
                        "Do NOT respond with text. You must call a tool."
                    ),
                })

                continue


            if response.stop_reason != "tool_use":
                return RunResult(
                    status="FAILED",
                    error=f"Unexpected stop_reason: {response.stop_reason}",
                    usage=total_usage,
                )

            # ── Dispatch tool calls ───────────────────────────────────────────
            tool_results: list[ToolCallResult] = []
            terminal_result: RunResult | None = None

            for tc in response.tool_calls:
                result = await self.executor.execute(tc.name, tc.input)

                tool_results.append(
                    ToolCallResult(tool_call_id=tc.id, content=result.content)
                )

                if result.is_terminal and terminal_result is None:
                    terminal_result = RunResult(
                        status="GENERATED" if result.terminal_status == "GENERATED" else "NO_API_CHANGE",
                        feature_name=result.feature_name,
                        output_path=result.output_path,
                        usage=total_usage,
                    )

            messages.extend(self.provider.build_tool_result_messages(tool_results))

            if terminal_result:
                logger.info(
                    f"Agent completed in {turn} turn(s) | "
                    f"tokens: {total_usage['inputTokens']} in + {total_usage['outputTokens']} out"
                )
                return terminal_result

        logger.error(f"Agent exceeded maximum turns ({max_turns})")
        return RunResult(
            status="FAILED",
            error=f"Agent exceeded maximum turns ({max_turns})",
            usage=total_usage,
        )

    @staticmethod
    def _compact_old_messages(messages: list) -> list:
        """Compact tool results from older turns to reduce token usage.

        Keeps the first message (initial user context) and the last
        FULL_CONTEXT_WINDOW pairs of (assistant + tool_result) messages in full.
        Older tool results are replaced with a one-line summary.
        """
        if len(messages) <= (FULL_CONTEXT_WINDOW * 2 + 1):
            return messages

        keep_tail = FULL_CONTEXT_WINDOW * 2
        first_msg = messages[0]
        middle = messages[1:-keep_tail]
        tail = messages[-keep_tail:]

        compacted: list = [first_msg]
        for msg in middle:
            role = msg.get("role", "")
            content = msg.get("content", "")

            if role == "user" and isinstance(content, list):
                # Tool result block — compact it
                summaries = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "tool_result":
                        raw = block.get("content", "")
                        summary = _summarize_tool_result(raw)
                        summaries.append({
                            "type": "tool_result",
                            "tool_use_id": block.get("tool_use_id", ""),
                            "content": summary,
                        })
                    else:
                        summaries.append(block)
                compacted.append({"role": "user", "content": summaries})
            elif role == "tool":
                # OpenAI-style tool result — compact it
                raw = msg.get("content", "")
                compacted.append({
                    "role": "tool",
                    "tool_call_id": msg.get("tool_call_id", ""),
                    "content": _summarize_tool_result(raw),
                })
            elif role == "assistant":
                compacted.append(_compact_assistant_message(msg))
            else:
                compacted.append(msg)

        compacted.extend(tail)
        return compacted


def _compact_assistant_message(msg: dict) -> dict:
    """Compact large documentation content in assistant tool_use blocks."""
    content = msg.get("content")

    # Anthropic format: content is a list of blocks
    if isinstance(content, list):
        compacted_blocks = []
        for block in content:
            if (
                isinstance(block, dict)
                and block.get("type") == "tool_use"
                and isinstance(block.get("input"), dict)
                and isinstance(block["input"].get("documentation"), str)
                and len(block["input"]["documentation"]) > 500
            ):
                new_block = {**block, "input": {**block["input"], "documentation": "[draft — see store_draft]"}}
                compacted_blocks.append(new_block)
            else:
                compacted_blocks.append(block)
        return {**msg, "content": compacted_blocks}

    # OpenAI format: tool_calls list with function.arguments JSON
    tool_calls = msg.get("tool_calls")
    if isinstance(tool_calls, list):
        compacted_calls = []
        for tc in tool_calls:
            func = tc.get("function", {})
            args_str = func.get("arguments", "")
            if isinstance(args_str, str) and "documentation" in args_str and len(args_str) > 500:
                try:
                    args = json.loads(args_str)
                    if isinstance(args.get("documentation"), str) and len(args["documentation"]) > 500:
                        args["documentation"] = "[draft — see store_draft]"
                        tc = {**tc, "function": {**func, "arguments": json.dumps(args)}}
                except (json.JSONDecodeError, TypeError):
                    pass
            compacted_calls.append(tc)
        return {**msg, "tool_calls": compacted_calls}

    return msg


def _summarize_tool_result(raw: str) -> str:
    """Produce a one-line summary of a tool result to save tokens."""
    if len(raw) <= 200:
        return raw

    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return raw[:150] + "...[compacted]"

    if "total" in data and "apiRelated" in data:
        return json.dumps({"total": data["total"], "apiRelated": data["apiRelated"]})

    if "new" in data and "modified" in data:
        return json.dumps({
            "feature": data.get("feature", ""),
            "new": len(data.get("new", [])),
            "modified": len(data.get("modified", [])),
            "removed": len(data.get("removed", [])),
        })

    if "valid" in data:
        return json.dumps({
            "valid": data["valid"],
            "errors": len(data.get("errors", [])),
            "warnings": len(data.get("warnings", [])),
        })

    if "planCreated" in data or "planRevised" in data:
        return json.dumps({"ok": True})

    if "totalResults" in data:
        return json.dumps({"totalResults": data["totalResults"]})

    if "overallScore" in data or "qualityScore" in data:
        score_key = "overallScore" if "overallScore" in data else "qualityScore"
        return json.dumps({score_key: data[score_key], "suggestions": len(data.get("suggestions", []))})

    if "stored" in data and "charCount" in data:
        return json.dumps({"stored": True, "charCount": data["charCount"]})

    if "stored" in data:
        return json.dumps({"stored": True})

    if "skipped" in data:
        return json.dumps({"skipped": True})

    if "noChange" in data:
        return raw

    return raw[:150] + "...[compacted]"
