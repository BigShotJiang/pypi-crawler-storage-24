"""Quality evaluator — LLM-based documentation quality scoring."""

from __future__ import annotations

import json
from pathlib import Path

from core.llm.base import LLMProvider
from core.logger import logger

EVALUATOR_SYSTEM_PROMPT = """\
You are a developer experience (DX) evaluator. Assess API documentation from the perspective \
of an engineer who needs to integrate this API into their application — someone who did not \
write the code and has no access to the codebase.

Your core question: **Could a developer open this document and successfully integrate \
the API without asking a single question?**

## Scoring rubrics (1–10 per dimension)

**Target Audience Fit (1–10)**
- 10: Written entirely for integrating developers. Precise types, auth instructions, \
error handling guidance, no internal implementation details leaked.
- 7: Mostly developer-facing; occasional internal jargon or missing context.
- 5: Mixed internal/external perspective; unclear who the audience is.
- 1: Written for engineers who built it, not engineers integrating it.

**Completeness (1–10)**
- 10: Every endpoint documented with all parameters (required + optional), full response schemas, \
all error codes with meaning and recovery guidance.
- 7: All endpoints present; 1–2 optional parameters or minor error codes missing.
- 5: Some endpoints thin — missing body schema, query params, or response details.
- 1: Skeleton only — endpoints listed but no actionable detail.

**Code Examples (1–10)**
- 10: Every new and modified endpoint has a runnable cURL example with realistic placeholder \
values and the correct auth header. Breaking changes show before + after examples.
- 7: Most endpoints have examples; 1–2 missing or missing auth header.
- 5: Examples present but use generic placeholders (`string`, `123`, `example`) or missing auth.
- 1: No examples, or examples that would fail if run.

**Consistency (1–10)**
- 10: Uniform formatting throughout — same heading style for every endpoint, same table \
structure for parameters, same JSON formatting, same terminology.
- 7: Minor inconsistencies that don't impact usability.
- 5: Noticeable variance between sections; some endpoints formatted differently.
- 1: Each section formatted differently; no consistent pattern.

**Style Consistency (1–10, null if no existing docs provided)**
- 10: Indistinguishable from existing documentation in tone, structure, and formatting.
- 7: Minor style differences that a reader would notice but not be bothered by.
- 5: Noticeably different style that breaks reading flow.
- 1: Completely different style — feels like a different product's docs.

## Output format

Respond ONLY with valid JSON — no prose, no markdown outside the JSON:
{
    "qualityScore": <1-10 overall>,
    "dimensions": {
        "targetAudienceFit": <1-10>,
        "completeness": <1-10>,
        "codeExamples": <1-10>,
        "consistency": <1-10>,
        "styleConsistency": <1-10 or null>
    },
    "integratorBlockers": ["<anything preventing successful integration — name the endpoint/field>"],
    "suggestions": ["<specific suggestion a developer would care about — name the endpoint/field>"],
    "summary": "<one-sentence assessment from an integrating developer's perspective>"
}

## Rules
- Evaluate from a developer integration perspective only — not a code review perspective
- `integratorBlockers` = issues that would cause incorrect integration or runtime failures
- `styleConsistency` must be null if no existing docs were provided for comparison
- Suggestions must be specific: name the endpoint and field, not "add more examples" """


class QualityEvaluator:
    """LLM-based quality scoring for generated documentation."""

    def __init__(self, provider: LLMProvider) -> None:
        self.provider = provider

    def evaluate(
        self,
        documentation: str,
        output_dir: str | None = None,
        compare_with_existing: bool = False,
    ) -> dict:
        """Evaluate documentation quality.

        Args:
            documentation: The markdown to evaluate.
            output_dir: Path to output directory for existing doc comparison.
            compare_with_existing: Whether to load existing docs for style comparison.

        Returns:
            dict with qualityScore, dimensions, suggestions, summary.
        """
        parts = [f"## Documentation to Evaluate\n```markdown\n{documentation}\n```"]

        if compare_with_existing and output_dir:
            existing = self._load_existing_docs(output_dir)
            if existing:
                parts.append(
                    f"\n## Existing Documentation (for style comparison)\n```markdown\n{existing}\n```"
                )

        user_message = "\n".join(parts)

        try:
            response = self.provider.chat(
                system=EVALUATOR_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_message}],
                max_tokens=2048,
            )

            result = json.loads(response.content)
            logger.debug(f"Quality score: {result.get('qualityScore', 'N/A')}/10")
            return result

        except json.JSONDecodeError:
            logger.warn("Evaluator returned non-JSON response")
            return self._fallback_result("Evaluator could not parse response.")
        except Exception as err:
            logger.warn(f"Evaluator call failed: {err}")
            return self._fallback_result(f"Evaluator failed: {err}")

    @staticmethod
    def _load_existing_docs(output_dir: str, max_chars: int = 5000) -> str:
        out = Path(output_dir)
        if not out.exists():
            return ""

        docs: list[str] = []
        total = 0
        for md_file in sorted(out.glob("*.md")):
            try:
                content = md_file.read_text(encoding="utf-8")
                if total + len(content) > max_chars:
                    remaining = max_chars - total
                    if remaining > 200:
                        docs.append(f"### {md_file.name}\n{content[:remaining]}...[truncated]")
                    break
                docs.append(f"### {md_file.name}\n{content}")
                total += len(content)
            except Exception:
                continue

        return "\n\n".join(docs)

    @staticmethod
    def _fallback_result(summary: str) -> dict:
        return {
            "qualityScore": 0,
            "dimensions": {
                "targetAudienceFit": 0,
                "completeness": 0,
                "codeExamples": 0,
                "consistency": 0,
                "styleConsistency": None,
            },
            "integratorBlockers": [],
            "suggestions": [summary],
            "summary": summary,
        }
