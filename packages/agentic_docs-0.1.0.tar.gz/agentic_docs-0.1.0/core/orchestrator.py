"""Agent orchestration layer (L5). Thin shell that bootstraps and delegates to AgentLoop."""

from __future__ import annotations

import subprocess

from core.agent_loop import AgentLoop, RunResult
from core.config import AgentConfig, load_global_memory_config
from core.git import GitAnalyzer
from core.llm import LLMProvider, create_provider, resolve_api_base, resolve_api_key
from core.logger import logger
from core.memory import MemoryManager
from core.storage.memory_store import MemoryStore
from core.tools.executor import ToolExecutor


class Orchestrator:
    def __init__(self, repo_path: str, config: AgentConfig) -> None:
        self.repo_path = repo_path
        self.config = config

        # ── Resolve primary API key (from env var) and build LLM provider ────
        self._api_key = resolve_api_key(config.provider)
        base_url = resolve_api_base(config.provider)
        self._provider = create_provider(config.provider, config.model, self._api_key, base_url=base_url)

        # ── Build critic / evaluator providers (may differ from primary) ─────
        self._critic_provider = self._build_secondary_provider(
            config.critic_provider, config.critic_model,
        )
        self._evaluator_provider = self._build_secondary_provider(
            config.evaluator_provider, config.evaluator_model,
        )

        # ── Git analyser ─────────────────────────────────────────────────────
        self._git = GitAnalyzer(repo_path)

        # ── Global memory (admin-managed, loaded from central config) ────────
        self._global_store = self._build_global_store()

        # ── Memory manager (local + optional global) ─────────────────────────
        self._memory = MemoryManager(
            repo_path,
            config.memory_dir,
            global_store=self._global_store,
        )

    async def run(self) -> RunResult:
        logger.info("════════════════ Agent Loop Start ════════════════")

        self._memory.initialize()

        branch = self._git.get_current_branch()
        logger.info(f"Branch: {branch}")

        executor = ToolExecutor(
            self.repo_path,
            self.config,
            branch,
            memory=self._memory,
            critic_provider=self._critic_provider,
            evaluator_provider=self._evaluator_provider,
        )

        agent_loop = AgentLoop(
            executor,
            self.config,
            self._provider,
            memory=self._memory,
        )

        result = await agent_loop.run(branch, self.config.base_branch)

        if (
            result.status == "GENERATED"
            and self.config.auto_commit
            and result.output_path
            and result.feature_name
        ):
            md_path = result.output_path.replace(".docx", ".md")
            self._auto_commit(md_path, result.output_path, result.feature_name)

        logger.info("════════════════ Agent Loop Complete ════════════════")
        return result

    # ─── Private helpers ──────────────────────────────────────────────────────

    def _build_secondary_provider(
        self,
        provider_name: str | None,
        model_name: str | None,
    ) -> LLMProvider:
        """Build an LLM provider for critic or evaluator.

        Falls back to the primary provider/model when not explicitly configured.
        API key is always resolved from the env var for that provider.
        """
        effective_provider = provider_name or self.config.provider
        effective_model = model_name or self.config.model

        if effective_provider == self.config.provider:
            key = self._api_key
        else:
            key = resolve_api_key(effective_provider)

        base_url = resolve_api_base(effective_provider)
        return create_provider(effective_provider, effective_model, key, base_url=base_url)

    @staticmethod
    def _build_global_store() -> MemoryStore | None:
        gm = load_global_memory_config()
        if not gm.enabled:
            return None

        if not gm.repo_url:
            logger.warn("Global memory enabled but no repo URL configured — skipping.")
            return None

        from core.storage.git_store import GitMemoryStore

        logger.info(f"Global memory: git repo ({gm.branch})")
        return GitMemoryStore(
            repo_url=gm.repo_url,
            branch=gm.branch,
            token=gm.token,
        )

    # def _auto_commit(self, md_path: str, docx_path: str, feature_name: str) -> None:
    #     try:
    #         message = self.config.commit_message.replace("{feature}", feature_name)
    #         subprocess.run(
    #             f'git add "{md_path}" "{docx_path}"',
    #             shell=True,
    #             cwd=self.repo_path,
    #             capture_output=True,
    #             check=True,
    #         )
    #         subprocess.run(
    #             f'git commit -m "{message}"',
    #             shell=True,
    #             cwd=self.repo_path,
    #             capture_output=True,
    #             check=True,
    #         )
    #         logger.success(f"Auto-committed: {message}")
    #     except subprocess.CalledProcessError as err:
    #         logger.warn(f"Auto-commit skipped: {err}")
    def _auto_commit(self, md_path: str, docx_path: str, feature_name: str) -> None:
        try:
            import os

            message = self.config.commit_message.replace("{feature}", feature_name)

            # Convert to repo-relative paths
            md_rel = os.path.relpath(md_path, self.repo_path)
            docx_rel = os.path.relpath(docx_path, self.repo_path)

            subprocess.run(
                ["git", "add", md_rel, docx_rel],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=True,
            )

            subprocess.run(
                ["git", "commit", "-m", message],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=True,
            )

            logger.success(f"Auto-committed: {message}")

        except subprocess.CalledProcessError as err:
            logger.warn(
                f"Auto-commit skipped:\nSTDOUT: {err.stdout}\nSTDERR: {err.stderr}"
            )

