"""Validation guard (L6). Checks LLM output against the structured delta."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from core.extractor.types import ApiEndpoint, ExtractedApiDelta
from core.logger import logger


@dataclass
class ValidationResult:
    valid: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


# Patterns that signal the LLM invented content beyond the structured data
SPECULATIVE_PATTERNS: list[re.Pattern] = [
    re.compile(r"(?:may|might|could)\s+(?:want to|consider|think about)", re.IGNORECASE),
    re.compile(r"in\s+the\s+(?:near\s+)?future", re.IGNORECASE),
    re.compile(r"it\s+is\s+(?:recommended|suggested)\s+that\s+you", re.IGNORECASE),
    re.compile(r"you\s+(?:should|might want to|could)\s+(?:also|consider)", re.IGNORECASE),
    re.compile(r"note:\s+this\s+is\s+not\s+yet\s+implemented", re.IGNORECASE),
]

VALID_METHODS = {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}


class DocumentValidator:
    def validate(self, documentation: str, delta: ExtractedApiDelta) -> ValidationResult:
        errors: list[str] = []
        warnings: list[str] = []

        # ── Rule 1: Required header ──────────────────────────────────────────────
        if f"# Feature: {delta.feature}" not in documentation:
            errors.append(f"Missing required header: # Feature: {delta.feature}")

        # ── Rule 2: No speculative content ───────────────────────────────────────
        for pat in SPECULATIVE_PATTERNS:
            if pat.search(documentation):
                errors.append(f"Speculative language detected (pattern: {pat.pattern})")

        # ── Rule 3: No invented endpoints ────────────────────────────────────────
        all_ground_truth = self._all_endpoints(delta)
        documented = self._extract_documented_endpoints(documentation)

        for doc in documented:
            found = any(
                ep.method == doc["method"] and self._paths_match(ep.path, doc["path"]) for ep in all_ground_truth
            )
            if not found:
                errors.append(f"Invented endpoint not in structured data: {doc['method']} {doc['path']}")

        # ── Rule 4: Coverage warnings (non-blocking) ─────────────────────────────
        for ep in delta.new:
            covered = any(d["method"] == ep.method and self._paths_match(d["path"], ep.path) for d in documented)
            if not covered:
                warnings.append(f"New endpoint not mentioned in docs: {ep.method} {ep.path}")

        # ── Rule 5: No invalid HTTP methods ─────────────────────────────────────
        for m in re.finditer(r"`([A-Z]+)\s+/[^\s`]*`", documentation):
            if m.group(1) not in VALID_METHODS:
                errors.append(f"Invalid HTTP method in documentation: {m.group(1)}")

        logger.debug(f"Validation — errors: {len(errors)}, warnings: {len(warnings)}")
        return ValidationResult(valid=len(errors) == 0, errors=errors, warnings=warnings)

    # ─── Private helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _all_endpoints(delta: ExtractedApiDelta) -> list[ApiEndpoint]:
        return [
            *delta.new,
            *(m.after for m in delta.modified),
            *(m.before for m in delta.modified),
            *delta.removed,
        ]

    @staticmethod
    def _extract_documented_endpoints(doc: str) -> list[dict[str, str]]:
        results: list[dict[str, str]] = []
        # Matches: `GET /api/v1/users` or **POST /payments/refund**
        for m in re.finditer(r"[`*]{0,2}(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+(/[^\s`*\"']+)[`*]{0,2}", doc):
            results.append({"method": m.group(1), "path": m.group(2)})
        return results

    @staticmethod
    def _paths_match(a: str, b: str) -> bool:
        """Normalise path params: /users/:id == /users/{id}"""

        def norm(p: str) -> str:
            p = re.sub(r":[a-zA-Z_]\w*", "{p}", p)
            p = re.sub(r"\{[^}]+\}", "{p}", p)
            return p

        return norm(a) == norm(b) or a == b
