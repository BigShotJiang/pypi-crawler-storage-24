"""Skill memory manager (L3). Two-tier memory: local (per-project) + optional global (Git repo)."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from core.extractor.types import ExtractedApiDelta
from core.logger import logger
from core.storage.local_store import LocalMemoryStore
from core.storage.memory_store import MemoryStore

MAX_SKILL_CHARS = 8_000

# ── Local (per-project) skill files ──────────────────────────────────────────

SKILL_FILES = {
    "master": "agentic-system-master.md",
    "api": "api-patterns.md",
    "auth": "auth-patterns.md",
    "versioning": "versioning.md",
}

INITIAL_CONTENT: dict[str, str] = {
    SKILL_FILES["master"]: """# Agentic Documentation System — Master Memory

## Purpose
Track API patterns, conventions, and architectural decisions for this repository.

## API Conventions
(Populated incrementally from repository analysis)

## Documentation Style
(Populated from generated docs)
""",
    SKILL_FILES["api"]: """# API Patterns Memory

## Endpoint Conventions
(Populated incrementally)

## Naming Conventions
(Populated incrementally)

## Common Request/Response Shapes
(Populated incrementally)
""",
    SKILL_FILES["auth"]: """# Authentication Patterns Memory

## Auth Strategy
(Populated incrementally)

## Protected Routes Pattern
(Populated incrementally)
""",
    SKILL_FILES["versioning"]: """# API Versioning Memory

## Versioning Strategy
(Populated incrementally)

## Current Version
(Populated incrementally)

## Version History
(Populated incrementally)
""",
}

# ── Global (cross-project) skill files ───────────────────────────────────────

GLOBAL_SKILL_FILES = {
    "common-patterns": "common-patterns.md",
    "auth-strategies": "auth-strategies.md",
    "style-guide": "style-guide.md",
}

GLOBAL_INITIAL_CONTENT: dict[str, str] = {
    GLOBAL_SKILL_FILES["common-patterns"]: """# Common API Patterns — Global Memory

## Shared Conventions
(Populated from agent runs across projects)

## Reusable Patterns
(Populated incrementally)
""",
    GLOBAL_SKILL_FILES["auth-strategies"]: """# Authentication Strategies — Global Memory

## Common Auth Patterns
(Populated from agent runs across projects)

## Provider-Specific Notes
(Populated incrementally)
""",
    GLOBAL_SKILL_FILES["style-guide"]: """# Documentation Style Guide — Global Memory

## Writing Style
(Populated from agent runs across projects)

## Formatting Conventions
(Populated incrementally)
""",
}


@dataclass
class MemorySearchResult:
    """A ranked section from a skill memory file."""

    source: str  # e.g. "project:api-patterns.md" or "global:style-guide.md"
    section: str
    score: float


@dataclass
class SkillMemory:
    master: str
    api: str
    auth: str
    versioning: str


class MemoryManager:
    """Manages two tiers of memory:

    * **local** (per-project) — stored on the filesystem inside the repo.
    * **global** (shared)     — stored in a Git repo (optional, admin-managed).
    """

    def __init__(
        self,
        repo_path: str,
        memory_dir: str = ".agent/skills",
        global_store: MemoryStore | None = None,
    ) -> None:
        self._local = LocalMemoryStore(Path(repo_path) / memory_dir)
        self._global = global_store
        self.skills_dir = Path(repo_path) / memory_dir  # backward compat

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def initialize(self) -> None:
        """Create skill files that don't yet exist. Safe to call repeatedly."""
        self._local.initialize(INITIAL_CONTENT)
        if self._global:
            self._global.initialize(GLOBAL_INITIAL_CONTENT)

    # ── Read ──────────────────────────────────────────────────────────────────

    def read_all(self) -> SkillMemory:
        return SkillMemory(
            master=self._local.read(SKILL_FILES["master"]),
            api=self._local.read(SKILL_FILES["api"]),
            auth=self._local.read(SKILL_FILES["auth"]),
            versioning=self._local.read(SKILL_FILES["versioning"]),
        )

    def read_skill(self, filename: str, scope: str = "project") -> str:
        """Read a single skill file from the given scope."""
        if scope == "global" and self._global:
            return self._global.read(filename)
        return self._local.read(filename)

    # ── Update from delta ─────────────────────────────────────────────────────

    def update_from_delta(self, delta: ExtractedApiDelta) -> None:
        """Incrementally update local skills from the latest extraction delta."""
        date = delta.timestamp[:10]

        if delta.new or delta.modified or delta.removed:
            lines_parts = [f"\n## {delta.feature} ({date})"]
            lines_parts.extend(f"- NEW: `{e.method} {e.path}`" for e in delta.new)
            lines_parts.extend(f"- MODIFIED: `{e.after.method} {e.after.path}`" for e in delta.modified)
            lines_parts.extend(f"- REMOVED: `{e.method} {e.path}`" for e in delta.removed)
            self._local.append(SKILL_FILES["api"], "\n".join(lines_parts))

        if delta.auth_changes:
            lines = f"\n## Auth change — {delta.feature} ({date})\n" + "\n".join(
                f"- {a.type}: {a.description}" for a in delta.auth_changes
            )
            self._local.append(SKILL_FILES["auth"], lines)

        if delta.versioning_changes:
            lines = f"\n## Version change — {delta.feature} ({date})\n" + "\n".join(
                f"- {v.type}: {v.description}" for v in delta.versioning_changes
            )
            self._local.append(SKILL_FILES["versioning"], lines)

        self._local.append(
            SKILL_FILES["master"],
            f"\n## {delta.feature} ({date})\n"
            f"- new: {len(delta.new)}, modified: {len(delta.modified)}, removed: {len(delta.removed)}\n",
        )

        self._prune_store(self._local, list(SKILL_FILES.values()))

    # ── Token-budgeted context ────────────────────────────────────────────────

    def get_token_budgeted_context(self, max_tokens: int) -> str:
        mem = self.read_all()
        combined = (
            f"## API Patterns\n{mem.api}\n\n"
            f"## Auth Patterns\n{mem.auth}\n\n"
            f"## Versioning\n{mem.versioning}"
        )

        char_budget = max_tokens * 4
        if len(combined) <= char_budget:
            return combined
        return combined[:char_budget] + "\n...[truncated for token budget]"

    # ── Search ────────────────────────────────────────────────────────────────

    def search_memory(
        self, query: str, max_results: int = 5, scope: str = "all"
    ) -> list[MemorySearchResult]:
        """Keyword search across skill files.

        scope: "project" | "global" | "all"
        """
        terms = [t.lower() for t in re.split(r"\W+", query) if len(t) >= 2]
        if not terms:
            return []

        results: list[MemorySearchResult] = []

        if scope in ("project", "all"):
            results.extend(
                self._search_store(self._local, terms, "project", list(SKILL_FILES.values()))
            )

        if scope in ("global", "all") and self._global:
            global_files = self._global.list_files() or list(GLOBAL_SKILL_FILES.values())
            results.extend(self._search_store(self._global, terms, "global", global_files))

        results.sort(key=lambda r: r.score, reverse=True)
        return results[:max_results]

    # ── Store ─────────────────────────────────────────────────────────────────

    def store_memory(
        self,
        category: str,
        title: str,
        content: str,
        scope: str = "project",
    ) -> None:
        """Write a new insight to the appropriate skill file.

        scope: "project" writes to local, "global" writes to the shared Git repo.
        """
        entry = f"\n## {title}\n{content}\n"

        if scope == "global" and self._global:
            global_file_map = {
                "api": GLOBAL_SKILL_FILES["common-patterns"],
                "auth": GLOBAL_SKILL_FILES["auth-strategies"],
                "style": GLOBAL_SKILL_FILES["style-guide"],
                "general": GLOBAL_SKILL_FILES["common-patterns"],
            }
            filename = global_file_map.get(category, GLOBAL_SKILL_FILES["common-patterns"])
            self._global.append(filename, entry)
            self._prune_store(self._global, list(GLOBAL_SKILL_FILES.values()))
            logger.debug(f"Stored global memory: [{category}] {title}")
        else:
            local_file_map = {
                "api": SKILL_FILES["api"],
                "auth": SKILL_FILES["auth"],
                "versioning": SKILL_FILES["versioning"],
                "general": SKILL_FILES["master"],
            }
            filename = local_file_map.get(category, SKILL_FILES["master"])
            self._local.append(filename, entry)
            self._prune_store(self._local, list(SKILL_FILES.values()))
            logger.debug(f"Stored memory: [{category}] {title}")

    # ── Auto-context ──────────────────────────────────────────────────────────

    def get_auto_context(
        self, branch: str, changed_files: list[str], max_chars: int = 2000
    ) -> str:
        """Extract keywords from branch name + file paths, search memory,
        and return relevant context for injection into the initial message.

        Capped to *max_chars* to prevent bloating the conversation history.
        """
        branch_parts = re.split(r"[/_\-]", branch)
        file_parts: list[str] = []
        for fp in changed_files:
            file_parts.extend(re.split(r"[/_\-.\\\\/]", fp))

        all_keywords = set(
            w.lower()
            for w in branch_parts + file_parts
            if len(w) >= 3
            and w.lower() not in {"the", "and", "for", "src", "lib", "api", "main", "feature"}
        )

        if not all_keywords:
            return ""

        query = " ".join(list(all_keywords)[:10])
        results = self.search_memory(query, max_results=3, scope="all")

        if not results:
            return ""

        context_parts = ["## Relevant Memory Context"]
        total = len(context_parts[0])
        for r in results:
            header = f"\n### From {r.source} (relevance: {r.score:.0f})"
            entry = header + "\n" + r.section
            if total + len(entry) > max_chars:
                remaining = max_chars - total - 30
                if remaining > 100:
                    context_parts.append(entry[:remaining] + "\n...[capped]")
                break
            context_parts.append(entry)
            total += len(entry)

        return "\n".join(context_parts)

    @property
    def has_global(self) -> bool:
        return self._global is not None

    # ─── Private helpers ──────────────────────────────────────────────────────

    def _search_store(
        self,
        store: MemoryStore,
        terms: list[str],
        scope_label: str,
        filenames: list[str],
    ) -> list[MemorySearchResult]:
        results: list[MemorySearchResult] = []
        for filename in filenames:
            content = store.read(filename)
            if not content:
                continue

            sections = re.split(r"(?=^## )", content, flags=re.MULTILINE)
            for section in sections:
                section = section.strip()
                if not section:
                    continue

                lower_section = section.lower()
                score = sum(lower_section.count(term) for term in terms)
                if score > 0:
                    results.append(
                        MemorySearchResult(
                            source=f"{scope_label}:{filename}",
                            section=section[:1000],
                            score=score,
                        )
                    )
        return results

    def _prune_store(self, store: MemoryStore, filenames: list[str]) -> None:
        for filename in filenames:
            content = store.read(filename)
            if len(content) <= MAX_SKILL_CHARS:
                continue

            lines = content.split("\n")
            header = "\n".join(lines[:8])
            keep_from = int(len(lines) * 0.4)
            pruned = f"{header}\n\n...(older entries pruned)...\n\n" + "\n".join(lines[keep_from:])
            store.write(filename, pruned)
            logger.debug(f"Pruned skill: {filename}")
