"""Configuration from environment variables only. No project or admin config files."""

from __future__ import annotations

import os
from typing import Literal

from pydantic import BaseModel, Field

Framework = Literal["django", "fastapi", "flask"]


# ── Agent config (all from env) ─────────────────────────────────────────────
# Required env: AGENTIC_DOCS_PROVIDER, AGENTIC_DOCS_MODEL, AGENTIC_DOCS_MAX_INPUT_TOKENS, AGENTIC_DOCS_MAX_OUTPUT_TOKENS
# Optional env: AGENTIC_DOCS_BASE_BRANCH, AGENTIC_DOCS_OUTPUT_DIR, AGENTIC_DOCS_MEMORY_DIR, etc.


def _env(key: str, default: str | None = None) -> str | None:
    return os.environ.get(key) or default


def _env_int(key: str, default: int | None = None) -> int | None:
    v = os.environ.get(key)
    if v is None:
        return default
    try:
        return int(v)
    except ValueError:
        return default


def _env_bool(key: str, default: bool = False) -> bool:
    v = os.environ.get(key)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes")


def _env_list(key: str, default: list[str] | None = None) -> list[str]:
    v = os.environ.get(key)
    if not v:
        return default or []
    return [s.strip() for s in v.split(",") if s.strip()]


class AgentConfig(BaseModel):
    # ── LLM provider (required — from env) ───────────────────────────────────
    provider: str = Field(..., description="LLM provider")
    model: str = Field(..., description="Model ID")

    max_input_tokens: int = Field(..., gt=0, alias="maxInputTokens")
    max_output_tokens: int = Field(..., gt=0, alias="maxOutputTokens")

    base_branch: str = Field(default="main", alias="baseBranch")
    output_dir: str = Field(default="docs", alias="outputDir")

    critic_provider: str | None = Field(default=None, alias="criticProvider")
    critic_model: str | None = Field(default=None, alias="criticModel")
    evaluator_provider: str | None = Field(default=None, alias="evaluatorProvider")
    evaluator_model: str | None = Field(default=None, alias="evaluatorModel")

    languages: list[str] = Field(default_factory=list)
    auto_commit: bool = Field(default=True, alias="autoCommit")
    commit_message: str = Field(
        default="docs: auto-generate API documentation for {feature}",
        alias="commitMessage",
    )
    frameworks: list[Framework] = Field(default=["django", "fastapi", "flask"])
    memory_dir: str = Field(default=".agent/skills", alias="memoryDir")
    max_turns: int = Field(default=20, gt=0, le=50, alias="maxTurns")

    model_config = {"populate_by_name": True}


def load_config(repo_path: str | None = None) -> AgentConfig:
    """Build AgentConfig from environment variables only.

    Required:
        AGENTIC_DOCS_PROVIDER, AGENTIC_DOCS_MODEL,
        AGENTIC_DOCS_MAX_INPUT_TOKENS, AGENTIC_DOCS_MAX_OUTPUT_TOKENS
    Optional (with defaults): AGENTIC_DOCS_BASE_BRANCH, AGENTIC_DOCS_OUTPUT_DIR, etc.
    """
    provider = _env("AGENTIC_DOCS_PROVIDER")
    model = _env("AGENTIC_DOCS_MODEL")
    max_in = _env_int("AGENTIC_DOCS_MAX_INPUT_TOKENS")
    max_out = _env_int("AGENTIC_DOCS_MAX_OUTPUT_TOKENS")

    if not provider or not model:
        raise ValueError(
            "Set AGENTIC_DOCS_PROVIDER and AGENTIC_DOCS_MODEL in the environment."
        )
    if max_in is None or max_in <= 0:
        raise ValueError(
            "Set AGENTIC_DOCS_MAX_INPUT_TOKENS to a positive integer."
        )
    if max_out is None or max_out <= 0:
        raise ValueError(
            "Set AGENTIC_DOCS_MAX_OUTPUT_TOKENS to a positive integer."
        )

    frameworks_raw = _env_list("AGENTIC_DOCS_FRAMEWORKS", ["django", "fastapi", "flask"])
    frameworks: list[Framework] = []
    for f in frameworks_raw:
        if f in ("django", "fastapi", "flask"):
            frameworks.append(f)
    if not frameworks:
        frameworks = ["django", "fastapi", "flask"]

    return AgentConfig(
        provider=provider,
        model=model,
        maxInputTokens=max_in,
        maxOutputTokens=max_out,
        baseBranch=_env("AGENTIC_DOCS_BASE_BRANCH") or "main",
        outputDir=_env("AGENTIC_DOCS_OUTPUT_DIR") or "docs",
        memoryDir=_env("AGENTIC_DOCS_MEMORY_DIR") or ".agent/skills",
        maxTurns=_env_int("AGENTIC_DOCS_MAX_TURNS") or 20,
        autoCommit=not _env_bool("AGENTIC_DOCS_NO_AUTO_COMMIT", False),
        commitMessage=_env("AGENTIC_DOCS_COMMIT_MESSAGE") or "docs: auto-generate API documentation for {feature}",
        languages=_env_list("AGENTIC_DOCS_LANGUAGES"),
        frameworks=frameworks,
        criticProvider=_env("AGENTIC_DOCS_CRITIC_PROVIDER"),
        criticModel=_env("AGENTIC_DOCS_CRITIC_MODEL"),
        evaluatorProvider=_env("AGENTIC_DOCS_EVALUATOR_PROVIDER"),
        evaluatorModel=_env("AGENTIC_DOCS_EVALUATOR_MODEL"),
    )


# ── Global memory (env only) ──────────────────────────────────────────────────
# AGENTIC_DOCS_GLOBAL_MEMORY_REPO, AGENTIC_DOCS_GLOBAL_MEMORY_TOKEN, AGENTIC_DOCS_GLOBAL_MEMORY_BRANCH


class GlobalMemoryConfig(BaseModel):
    """Git-backed shared global memory. Configured only via environment variables."""

    enabled: bool = False
    repo_url: str = Field(default="", alias="repoUrl")
    branch: str = "main"
    token: str | None = None

    model_config = {"populate_by_name": True}


def load_global_memory_config() -> GlobalMemoryConfig:
    """Load global memory from environment variables only.

    Set AGENTIC_DOCS_GLOBAL_MEMORY_REPO (Git repo URL) to enable.
    Optional: AGENTIC_DOCS_GLOBAL_MEMORY_TOKEN, AGENTIC_DOCS_GLOBAL_MEMORY_BRANCH (default: main).
    """
    repo_url = os.environ.get("AGENTIC_DOCS_GLOBAL_MEMORY_REPO")
    if not repo_url:
        return GlobalMemoryConfig(enabled=False)
    return GlobalMemoryConfig(
        enabled=True,
        repoUrl=repo_url,
        branch=os.environ.get("AGENTIC_DOCS_GLOBAL_MEMORY_BRANCH", "main"),
        token=os.environ.get("AGENTIC_DOCS_GLOBAL_MEMORY_TOKEN"),
    )
