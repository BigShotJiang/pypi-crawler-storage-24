"""Pydantic models for structured LLM output."""

from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class NodeIR(BaseModel):
    """Node representation for IR generation."""

    id: str = Field(..., pattern="^[a-zA-Z0-9_-]+$")
    type: str = Field(..., description="Node type from registry")
    purpose: str = Field(..., min_length=10, max_length=200, description="What this node does in the workflow context")
    params: dict[str, Any] = Field(default_factory=dict)


class EdgeIR(BaseModel):
    """Edge representation for IR generation."""

    from_node: str = Field(..., alias="from")
    to_node: str = Field(..., alias="to")
    action: str = Field(default="default")

    model_config = ConfigDict(
        populate_by_name=True,  # Allow both field names and aliases during parsing
        use_enum_values=True,
        # Note: json_encoders is deprecated in Pydantic V2
        # Custom serialization should be handled via field serializers if needed
        alias_generator=None,
        # In Pydantic V2, by_alias is used for serialization control
        # populate_by_name allows accepting aliases during parsing
    )


class FlowIR(BaseModel):
    """Flow IR for planner output generation."""

    ir_version: str = Field(default="0.1.0", pattern=r"^\d+\.\d+\.\d+$")
    nodes: list[NodeIR] = Field(..., min_length=1)
    edges: list[EdgeIR] = Field(default_factory=list)
    start_node: Optional[str] = None
    # Task 21 fields: workflows can declare their expected inputs/outputs
    inputs: Optional[dict[str, Any]] = None
    outputs: Optional[dict[str, Any]] = None

    model_config = ConfigDict(
        # Ensure nested models also use aliases properly during serialization
        # populate_by_name allows accepting both field names and aliases during parsing
        populate_by_name=True,
    )


class FlatFlowIR(BaseModel):
    """Flattened Flow IR without $defs - compatible with Gemini/OpenAI.

    This version uses list[Any] to avoid additionalProperties which Gemini rejects.

    Drawback: Minimal validation on nested structures, but can be validated after
    parsing by converting to FlowIR.
    """

    ir_version: str = Field(default="0.1.0", pattern=r"^\d+\.\d+\.\d+$")
    nodes: list[Any] = Field(
        ..., min_length=1, description="List of node objects with id, type, purpose, and params fields"
    )
    edges: list[Any] = Field(
        default_factory=list, description="List of edge objects with 'from' and 'to' fields (and optional action)"
    )
    start_node: Optional[str] = None
    inputs: Optional[Any] = None
    outputs: Optional[Any] = None

    model_config = ConfigDict(
        populate_by_name=True,
    )

    def to_dict(self) -> dict:
        """Convert to dict for validation with existing schema."""
        return self.model_dump(by_alias=True, exclude_none=True)


class WorkflowMetadata(BaseModel):
    """Structured metadata for workflow discovery and reuse.

    Critical for Path A success - enables workflows to be found
    with natural language variations.
    """

    suggested_name: str = Field(
        description="Concise, searchable name in kebab-case (max 50 chars)",
        max_length=50,
        pattern="^[a-z0-9]+(?:-[a-z0-9]+)*$",
    )

    description: str = Field(
        description="Comprehensive description for discovery (100-500 chars)", min_length=100, max_length=500
    )

    search_keywords: list[str] = Field(
        description="Alternative terms users might search for", min_length=2, max_length=20
    )

    capabilities: list[str] = Field(
        description="What this workflow can do (bullet points)", min_length=2, max_length=20
    )

    typical_use_cases: list[str] = Field(description="When/why someone would use this", min_length=1, max_length=3)

    @field_validator("search_keywords")
    @classmethod
    def validate_keywords(cls, v: list[str]) -> list[str]:
        """Ensure keywords are unique and lowercase."""
        return list(dict.fromkeys(keyword.lower() for keyword in v))

    @field_validator("suggested_name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Ensure name is lowercase kebab-case."""
        return v.lower().replace("_", "-")
