"""Instruction resources for AI agents building pflow workflows.

This module exposes agent instructions as MCP resources that agents can
read to learn best practices, patterns, and the workflow building process.

Two variants are provided:
- Regular agents: Full system access (settings, traces, library)
- Sandbox agents: Isolated environments (no settings/trace access)
"""

import logging
from pathlib import Path

from ..server import mcp

logger = logging.getLogger(__name__)


# Paths to agent instructions
def _get_instructions_path(filename: str) -> Path:
    """Get path to instructions file, checking multiple locations.

    Priority order:
    1. Package resources (shipped with pflow)
    2. User customization directory (optional overrides)
    3. Dev fallback (old location, for backward compat during migration)

    Args:
        filename: Name of the instruction file (e.g., "mcp-agent-instructions.md")

    Returns:
        Path to the instruction file (may not exist)
    """
    # 1. Try package resources (production/installed)
    # From: src/pflow/mcp_server/resources/instruction_resources.py
    # To:   src/pflow/mcp_server/resources/instructions/{filename}
    resource_path = Path(__file__).parent / "instructions" / filename
    if resource_path.exists():
        return resource_path

    # 2. Try user home (for custom instructions)
    user_path = Path.home() / ".pflow" / "instructions" / filename
    if user_path.exists():
        return user_path

    # 3. Dev fallback (old location, for backward compat during migration)
    # Need to go up 5 levels: resources/ -> mcp_server/ -> pflow/ -> src/ -> project_root/
    project_root = Path(__file__).parent.parent.parent.parent.parent
    dev_path = project_root / ".pflow" / "instructions" / filename
    if dev_path.exists():
        return dev_path

    # Return resource path as default (will trigger fallback message if missing)
    return resource_path


MCP_AGENT_INSTRUCTIONS_PATH = _get_instructions_path("mcp-agent-instructions.md")
SANDBOX_AGENT_INSTRUCTIONS_PATH = _get_instructions_path("mcp-sandbox-agent-instructions.md")


@mcp.resource(
    "pflow://instructions",
    name="Agent Instructions",
    title="Complete Workflow Building Guide (READ FIRST)",
    description="""Complete agent instructions for building pflow workflows (shares user's system access with the user).

    ⚠️ IMPORTANT: Read this resource before building new workflows!

    This version is for agents with FULL system access:
    - ✅ Can read/write ~/.pflow/settings.json
    - ✅ Can access trace files in ~/.pflow/debug/
    - ✅ Have pflow cli installed and configured in their environment (check with `pflow --version`)

    This is a comprehensive guide covering:
    - The 10-step development loop (discover → design → build → test → save)
    - When to discover vs build new workflows (always discover first!)
    - Critical patterns (use templates for extraction, code nodes for transformation)
    - Workflow structure (.pflow.md markdown format) and constraints (sequential execution only)
    - Template syntax and variables (${input}, ${node.output})
    - Node selection (code node > shell+jq for data transforms, LLM only for interpretation)
    - Authentication and credential management
    - Common patterns and complete examples (batch processing, pipelines, orchestration)
    - Troubleshooting and debugging techniques
    - What workflows CANNOT do (no parallel paths, loops, or state) and what they CAN (conditional branching)

    The instructions are organized into sections:
    1. Foundation & Mental Model - Core concepts
    2. Node & Tool Selection - Decision rules
    3. The Development Loop - 10 steps to follow
    4. Technical Reference - Workflow format, templates, parameters
    5. Testing & Debugging - Validate and fix
    6. Workflow Patterns - Real examples
    7. Troubleshooting - Debug errors
    8. Quick Reference - Cheat sheets

    Note: You do NOT need to read this before using workflow_discover or workflow_execute
    if a workflow matches the user's request perfectly. This resource is only for when
    you need to BUILD a new workflow.

    For sandboxed/isolated environments (no pflow cli installed), use pflow://instructions/sandbox instead.
    """,
)
def get_instructions() -> str:
    """Complete agent instructions for building pflow workflows (full system access).

    This version is for agents with FULL system access to the user's system:
    - Can read/write ~/.pflow/settings.json
    - Can access trace files in ~/.pflow/debug/
    - Have pflow CLI installed and configured

    For sandboxed/isolated environments, use pflow://instructions/sandbox instead.
    """
    try:
        if not MCP_AGENT_INSTRUCTIONS_PATH.exists():
            logger.warning(f"Instructions file not found at {MCP_AGENT_INSTRUCTIONS_PATH}")
            return _regular_fallback_message()

        content = MCP_AGENT_INSTRUCTIONS_PATH.read_text(encoding="utf-8")
        logger.debug(f"Successfully loaded instructions ({len(content)} bytes)")
        return content

    except Exception as e:
        logger.error(f"Failed to read instructions from {MCP_AGENT_INSTRUCTIONS_PATH}: {e}", exc_info=True)
        return _regular_fallback_message()


@mcp.resource(
    "pflow://instructions/sandbox",
    name="Sandbox Agent Instructions",
    title="Workflow Building Guide for Isolated Environments",
    description="""Agent instructions for sandboxed/isolated environments (restricted access).

    ⚠️ Use this version for SANDBOXED agents with restricted system access:
    - ❌ NO access to trace files in ~/.pflow/debug/
    - ❌ Dont have pflow cli installed and configured in their environment (check with `pflow --version` if you are unsure)

    Key differences for sandboxed environments:
    - Have to send workflow markdown content instead of file path when using workflow_validate, workflow_execute, workflow_save tools
    - No trace debugging (rely on workflow error outputs only)
    - Work entirely within sandbox constraints

    This guide covers the same workflow building process as regular instructions,
    but adapted for isolated environments where system access is restricted.

    Use cases:
    - Containerized agents
    - Web-based AI assistants like Claude Desktop, ChatGPT Desktop etc.
    - Any environment without shared access to the users system

    For agents with user's system access, use pflow://instructions instead.
    """,
)
def get_sandbox_instructions() -> str:
    """Agent instructions for sandboxed/isolated environments (restricted access).

    Use this version for SANDBOXED agents with restricted system access:
    - NO access to ~/.pflow/settings.json (can't read/write API keys)
    - NO access to trace files in ~/.pflow/debug/
    - Don't have pflow CLI installed in their environment
    - Must send workflow markdown content instead of file paths

    Use cases: containerized agents, web-based AI assistants, CI/CD environments,
    multi-tenant systems, or any environment without shared access to the user's system.

    For agents with full system access, use pflow://instructions instead.
    """
    try:
        if not SANDBOX_AGENT_INSTRUCTIONS_PATH.exists():
            logger.warning(f"Sandbox instructions file not found at {SANDBOX_AGENT_INSTRUCTIONS_PATH}")
            return _sandbox_fallback_message()

        content = SANDBOX_AGENT_INSTRUCTIONS_PATH.read_text(encoding="utf-8")
        logger.debug(f"Successfully loaded sandbox instructions ({len(content)} bytes)")
        return content

    except Exception as e:
        logger.error(f"Failed to read sandbox instructions from {SANDBOX_AGENT_INSTRUCTIONS_PATH}: {e}", exc_info=True)
        return _sandbox_fallback_message()


def _regular_fallback_message() -> str:
    """Fallback message for regular agents when instructions unavailable.

    Provides full CLI command reference including settings and trace access.
    """
    return """# Agent Instructions Not Available

The instruction file could not be loaded from `~/.pflow/instructions/mcp-agent-instructions.md`.

## Alternative Resources

Use these MCP tools to discover what you need:

### Discovery Tools (Use These First!)
- `workflow_discover(query="your task description")` - Find existing workflows
- `registry_discover(task="what you need to build")` - Find nodes with LLM selection

### Browse Tools
- `workflow_list()` - Browse all saved workflows
- `registry_describe(nodes=["node1", "node2"])` - Get specific node specs
- `registry_list(filter_pattern="keyword")` - Search for nodes by keyword

### Execution & Management Tools
- `workflow_execute(workflow="workflow.pflow.md", parameters={...})` - Run a workflow
- `workflow_validate(workflow="workflow.pflow.md")` - Validate before running
- `workflow_save(workflow="./workflow.pflow.md", name="name")` - Save to library
- `registry_run(node_type="node", parameters={...})` - Test a node's output structure

### Settings & Configuration (CLI — settings MCP tools are disabled)
- `pflow settings set-env KEY value` - Store API keys securely
- `pflow settings show` - Show all settings

## Key Principles (Quick Reference)

1. **Always discover first**: Run `workflow_discover()` before building new
2. **Use templates for extraction, code nodes for transformation**: Never use LLM for structured data extraction
3. **Sequential by default**: Workflows run top-to-bottom; use `on-error:` and code node `next` for conditional branching
4. **Test MCP nodes**: Always test with `registry_run()` when accessing specific fields
5. **Templates**: Use `${input}` for workflow inputs, `${node.output}` for node outputs
6. **Store credentials**: Use `pflow settings set-env` for API keys (CLI command)

## Manual Setup

If the file is missing:
1. Check if `~/.pflow/instructions/` directory exists
2. Reinstall pflow: `pip install --upgrade pflow`
3. File an issue if problem persists: https://github.com/spinje/pflow/issues

## Troubleshooting

If you're seeing this message but the file should exist:
- Verify path: `ls -la ~/.pflow/instructions/mcp-agent-instructions.md`
- Check permissions: File should be readable
- Check pflow installation: `pflow --version`
"""


def _sandbox_fallback_message() -> str:
    """Fallback message for sandbox agents when instructions unavailable.

    Excludes settings commands and trace access - focuses on self-contained workflows.
    """
    return """# Sandbox Agent Instructions Not Available

The instruction file could not be loaded from `~/.pflow/instructions/mcp-sandbox-agent-instructions.md`.

## Key Principles for Sandboxed Environments

1. **Avoid passing credentials as workflow inputs**:
   - NO `~/.pflow/settings.json access`, ask user to set environment variables instead by using the `pflow settings set-env` cli command or other means

2. **Send workflow markdown content instead of file path**
   - This is applicable for workflow_validate, workflow_execute, workflow_save tools
   - Don't assume shared access to the user's system where pflow is installed

3. **No trace debugging**: Use workflow outputs for debugging
   - Add explicit output nodes to capture intermediate data
   - Return useful error messages in workflow outputs

4. **Sequential by default**: Use `- on-error:` and code node `next` for conditional branching
   - Default flow is top-to-bottom; branching overrides with `- next:`, `- on-error:`, or `next: str = "target"` in code
   - No parallel paths (use batch for concurrent operations)

## Example: Credentials as Workflow Inputs and saving to file

````markdown
# API Fetch and Save

Fetch data from an API and save the response to a file.

## Inputs

### api_token

API authentication token.

- type: string
- required: true

### api_url

API URL to fetch data from.

- type: string
- required: true

### output_file

Path to save the API response data.

- type: string
- required: true

## Steps

### call-api

Call the API with authentication.

- type: http
- url: ${api_url}
- method: GET
- auth_token: ${api_token}

### save-to-file

Save the API response data to a file.

- type: write-file
- file_path: ${output_file}
- content: ${call-api.response.data}

## Outputs

### result-file-path

Path to file where API response data was saved.

- source: ${save-to-file.file-path}
````

**Run with**:
```bash
# Avoid this
pflow workflow.pflow.md api_token=YOUR_KEY_HERE api_url=https://api.example.com/data

# If credentials are set as environment variables, use this (no api_token input required)
pflow workflow.pflow.md api_url=https://api.example.com/data
```



## Troubleshooting

In sandboxed environments:
- Settings.json is NOT accessible (by design)
- Trace files are NOT accessible (by design)
- Workflow library may be isolated or restricted
- Focus on creating self-contained workflows
"""
