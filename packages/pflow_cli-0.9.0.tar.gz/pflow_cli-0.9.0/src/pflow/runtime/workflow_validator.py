"""Workflow validation functions for pflow runtime.

This module contains validation functions extracted from the compiler to improve
code organization and separation of concerns. These functions validate workflow
IR structure and prepare inputs with defaults.

Key functions:
- validate_ir_structure: Validates basic IR structure (nodes, edges arrays)
- prepare_inputs: Validates inputs and returns defaults to apply
"""

import logging
import os
from typing import Any

from pflow.core.param_coercion import coerce_input_to_declared_type
from pflow.core.validation_utils import get_parameter_validation_error, is_valid_parameter_name

logger = logging.getLogger(__name__)


def _resolve_missing_input(
    input_name: str,
    input_spec: dict[str, Any],
    settings_env: dict[str, str],
) -> tuple[Any | None, str | None, bool]:
    """Resolve value for a missing input from fallback sources.

    Checks in order: os.environ → settings_env → workflow default → None.

    Args:
        input_name: Name of the input parameter
        input_spec: Input specification with type, required, default, etc.
        settings_env: Environment variables from settings.json

    Returns:
        tuple: (resolved_value, source, is_from_settings_env) where:
            - resolved_value: The value to use, or None if required and missing
            - source: Description of where value came from, or None if missing required
            - is_from_settings_env: True if value came from settings_env
    """
    # Check shell environment variables first (transient session values)
    if input_name in os.environ:
        logger.debug(
            f"Using shell environment variable for input '{input_name}'",
            extra={"phase": "input_validation", "input": input_name},
        )
        return os.environ[input_name], "os.environ", False

    # Check settings.env (persistent configuration)
    if input_name in settings_env:
        logger.debug(
            f"Using value from settings.env for input '{input_name}'",
            extra={"phase": "input_validation", "input": input_name},
        )
        return settings_env[input_name], "settings_env", True

    # No environment fallback - check if required or has default
    is_required = input_spec.get("required", True)
    if is_required:
        return None, None, False  # Signal: missing required input

    # Optional input - use default or None
    if "default" in input_spec:
        default_value = input_spec.get("default")
        logger.debug(
            f"Applying default value for optional input '{input_name}'",
            extra={"phase": "input_validation", "input": input_name, "default": default_value},
        )
        return default_value, "default", False

    # Optional without default → None
    logger.debug(
        f"Optional input '{input_name}' not provided, using None as default",
        extra={"phase": "input_validation", "input": input_name},
    )
    return None, "implicit_none", False


def _coerce_provided_input(
    input_name: str,
    input_spec: dict[str, Any],
    provided_value: Any,
) -> tuple[Any, bool]:
    """Coerce a provided input value to its declared type if needed.

    Args:
        input_name: Name of the input parameter
        input_spec: Input specification containing type declaration
        provided_value: The value provided by the user

    Returns:
        tuple: (coerced_value, was_coerced) where:
            - coerced_value: The value after coercion (or original if no coercion)
            - was_coerced: True if the value was actually coerced to a different type
    """
    declared_type = input_spec.get("type")
    if not declared_type:
        logger.debug(
            f"Input '{input_name}' provided (no type declared)",
            extra={"phase": "input_validation", "input": input_name},
        )
        return provided_value, False

    # Don't coerce None values - they represent "no value" and should be preserved
    # (e.g., optional inputs without defaults resolve to None)
    if provided_value is None:
        logger.debug(
            f"Input '{input_name}' is None (preserving)",
            extra={"phase": "input_validation", "input": input_name},
        )
        return None, False

    coerced_value = coerce_input_to_declared_type(provided_value, declared_type, input_name=input_name)

    # Explicit coercion check - don't rely on identity which is fragile
    # (e.g., string normalization could create new objects even when type matches)
    was_coerced = coerced_value is not provided_value
    if was_coerced:
        logger.debug(
            f"Input '{input_name}' coerced from {type(provided_value).__name__} to {type(coerced_value).__name__}",
            extra={
                "phase": "input_validation",
                "input": input_name,
                "declared_type": declared_type,
            },
        )
    else:
        logger.debug(
            f"Input '{input_name}' provided (type matches)",
            extra={"phase": "input_validation", "input": input_name},
        )
    return coerced_value, was_coerced


def validate_ir_structure(ir_dict: dict[str, Any]) -> None:
    """Validate basic IR structure (nodes, edges arrays).

    This performs minimal structural validation to ensure the IR has
    the required top-level keys. Full validation should be done by
    the IR schema validator before compilation.

    Args:
        ir_dict: The IR dictionary to validate

    Raises:
        CompilationError: If required keys are missing or have wrong types
    """
    from .compiler import CompilationError

    logger.debug("Validating IR structure", extra={"phase": "validation"})

    # Check for required 'nodes' key
    if "nodes" not in ir_dict:
        raise CompilationError(
            "Missing 'nodes' key in IR", phase="validation", suggestion="IR must contain 'nodes' array"
        )

    # Check nodes is a list
    if not isinstance(ir_dict["nodes"], list):
        raise CompilationError(
            f"'nodes' must be an array, got {type(ir_dict['nodes']).__name__}",
            phase="validation",
            suggestion="Ensure 'nodes' is an array of node objects",
        )

    # Check for required 'edges' key
    if "edges" not in ir_dict:
        raise CompilationError(
            "Missing 'edges' key in IR", phase="validation", suggestion="IR must contain 'edges' array (can be empty)"
        )

    # Check edges is a list
    if not isinstance(ir_dict["edges"], list):
        raise CompilationError(
            f"'edges' must be an array, got {type(ir_dict['edges']).__name__}",
            phase="validation",
            suggestion="Ensure 'edges' is an array of edge objects",
        )

    logger.debug(
        "IR structure validated",
        extra={"phase": "validation", "node_count": len(ir_dict["nodes"]), "edge_count": len(ir_dict["edges"])},
    )


def prepare_inputs(
    workflow_ir: dict[str, Any], provided_params: dict[str, Any], settings_env: dict[str, str] | None = None
) -> tuple[list[tuple[str, str, str]], dict[str, Any], set[str]]:
    """Validate workflow inputs and return defaults to apply.

    This function validates that all required inputs are present in provided_params,
    determines default values for missing optional inputs, and validates input names
    are valid Python identifiers. Unlike the original _validate_inputs, this function
    does NOT mutate provided_params - it returns defaults to be applied by the caller.

    Args:
        workflow_ir: The workflow IR dictionary containing input declarations
        provided_params: Parameters provided for workflow execution (NOT modified)
        settings_env: Environment variables from settings.env (optional)

    Returns:
        tuple: (errors, defaults_to_apply, env_param_names) where:
            - errors: List of (message, path, suggestion) tuples for ValidationError
            - defaults_to_apply: Dict of default values to apply for missing optional inputs
            - env_param_names: Set of parameter names that came from settings.env

    Precedence order:
        1. provided_params (CLI arguments) - highest priority
        2. Shell environment variables (os.environ)
        3. settings_env (from settings.json)
        4. workflow input defaults (from IR)
        5. Error if required and not provided

    Note:
        This function was renamed from _validate_inputs to prepare_inputs to better
        reflect its dual purpose of validation and default preparation.
    """
    errors: list[tuple[str, str, str]] = []
    defaults: dict[str, Any] = {}
    env_param_names: set[str] = set()
    settings_env = settings_env or {}

    # Extract input declarations (backward compatible with workflows without inputs)
    inputs = workflow_ir.get("inputs", {})

    # If no inputs declared, nothing to validate
    if not inputs:
        logger.debug("No inputs declared for workflow", extra={"phase": "input_validation"})
        return errors, defaults, env_param_names

    # Check for multiple stdin: true inputs (only one allowed)
    stdin_inputs = [name for name, spec in inputs.items() if spec.get("stdin") is True]
    if len(stdin_inputs) > 1:
        errors.append((
            f'Multiple inputs marked with "stdin": true: {", ".join(stdin_inputs)}',
            "inputs",
            "Only one input can receive piped stdin",
        ))

    logger.debug(
        "Validating workflow inputs", extra={"phase": "input_validation", "declared_inputs": list(inputs.keys())}
    )

    # Validate each declared input
    for input_name, input_spec in inputs.items():
        # Validate the input name (now more permissive than Python identifiers)
        if not is_valid_parameter_name(input_name):
            error_msg = get_parameter_validation_error(input_name, "input")
            errors.append((
                error_msg,
                f"inputs.{input_name}",
                "Avoid shell special characters like $, |, >, <, &, ;",
            ))
            continue

        # Check if input is provided
        if input_name not in provided_params:
            resolved_value, source, is_from_settings = _resolve_missing_input(input_name, input_spec, settings_env)
            if source is None:
                # Missing required input
                description = input_spec.get("description", "No description provided")
                errors.append((
                    f"Workflow requires input '{input_name}': {description}",
                    f"inputs.{input_name}",
                    "",  # No suggestion needed - agent knows how to pass parameters
                ))
            else:
                # Apply coercion to env/settings/defaults values too
                # (e.g., env var "42" should become int 42 if declared type is "integer")
                coerced_value, _ = _coerce_provided_input(input_name, input_spec, resolved_value)
                defaults[input_name] = coerced_value
                if is_from_settings:
                    env_param_names.add(input_name)
        else:
            # Input is provided - coerce to declared type if needed
            provided_value = provided_params[input_name]
            coerced_value, was_coerced = _coerce_provided_input(input_name, input_spec, provided_value)
            if was_coerced:
                defaults[input_name] = coerced_value

    logger.debug(
        "Input validation complete", extra={"phase": "input_validation", "final_params": list(provided_params.keys())}
    )

    return errors, defaults, env_param_names
