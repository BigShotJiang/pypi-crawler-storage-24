"""MCP (Model Context Protocol) CLI commands for pflow.

This Click group is invoked by main_wrapper.py when it detects "mcp" as the first
positional argument. The wrapper manipulates sys.argv to remove "mcp" before calling
this group, allowing normal Click command processing for the subcommands.

Architecture: main_wrapper.py -> mcp() group -> individual commands (add, list, sync, etc.)
"""

import hashlib
import json
import logging
import sys
import time
from typing import Optional

import click

from pflow.core.suggestion_utils import find_similar_items, format_did_you_mean
from pflow.mcp import MCPRegistrar, MCPServerManager

logger = logging.getLogger(__name__)


@click.group(name="mcp")
def mcp() -> None:
    """Manage MCP server connections."""
    pass


def _is_json_string(value: str) -> bool:
    """Check if a string looks like JSON (starts with { or [)."""
    stripped = value.strip()
    return stripped.startswith("{") or stripped.startswith("[")


def _is_server_config(config: dict) -> bool:
    """Check if a dict looks like a server config (has command/url, not nested servers)."""
    return "command" in config or "url" in config


def _add_from_json_string(manager: MCPServerManager, json_str: str) -> list[str]:
    """Add servers from a raw JSON string.

    Supports three formats:
    1. Full MCP format: {"mcpServers": {"name": {...}}}
    2. Direct server map: {"name": {"command": ...}}
    3. Single server (name as key): {"github": {"command": "npx", ...}}

    Args:
        manager: MCPServerManager instance
        json_str: Raw JSON string with MCP config

    Returns:
        List of added server names

    Raises:
        ValueError: If JSON is invalid or missing required fields
    """
    try:
        config = json.loads(json_str)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}") from e

    # Format 1: Full MCP format with mcpServers wrapper
    if "mcpServers" in config:
        return manager.add_servers_from_config(config)

    # Format 2 & 3: Direct server map (one or more servers)
    # Check if all values are server configs (have command or url)
    if all(isinstance(v, dict) and _is_server_config(v) for v in config.values()):
        wrapped = {"mcpServers": config}
        return manager.add_servers_from_config(wrapped)

    raise ValueError(
        "Invalid JSON format. Expected one of:\n"
        '  {"mcpServers": {"name": {...}}}  - Full MCP format\n'
        '  {"name": {"command": "...", ...}}  - Direct server config'
    )


@mcp.command(name="add")
@click.argument("config_sources", nargs=-1, required=True)
def add(config_sources: tuple) -> None:
    """Add MCP servers from config files or raw JSON.

    Examples:
        # Add from config file:
        pflow mcp add ./github.mcp.json

        # Add from raw JSON (simple format):
        pflow mcp add '{"github": {"command": "npx", "args": ["-y", "@modelcontextprotocol/server-github"]}}'

        # Add HTTP server:
        pflow mcp add '{"slack": {"type": "http", "url": "https://mcp.example.com/slack"}}'

        # Add from raw JSON (full MCP format, compatible with Claude Desktop):
        pflow mcp add '{"mcpServers": {"github": {"command": "npx", "args": ["-y", "@modelcontextprotocol/server-github"]}}}'

    Supported JSON formats:
        # Simple (recommended for CLI):
        {"server-name": {"command": "...", "args": [...]}}

        # Full MCP format (compatible with config files):
        {"mcpServers": {"server-name": {...}}}
    """
    from pathlib import Path

    manager = MCPServerManager()
    total_added = []

    for config_source in config_sources:
        try:
            # Check if it's a JSON string or a file path
            if _is_json_string(config_source):
                # Handle raw JSON string
                added_servers = _add_from_json_string(manager, config_source)
                source_name = "JSON input"
            else:
                # Handle file path
                config_path = Path(config_source)
                if not config_path.exists():
                    click.echo(f"Error: File not found: {config_path}", err=True)
                    sys.exit(1)
                added_servers = manager.add_servers_from_file(config_path)
                source_name = config_path.name

            total_added.extend(added_servers)

            if added_servers:
                click.echo(f"✓ Added/updated {len(added_servers)} server(s) from {source_name}:")
                for server_name in added_servers:
                    click.echo(f"  - {server_name}")
            else:
                click.echo(f"⚠ No servers found in {source_name}")

        except ValueError as e:
            click.echo(f"Error: {e}", err=True)
            sys.exit(1)
        except Exception as e:
            click.echo(f"Error: Failed to add servers: {e}", err=True)
            sys.exit(1)

    if total_added:
        click.echo(f"\nSuccessfully configured {len(total_added)} MCP server(s).")
        click.echo("Run 'pflow mcp sync --all' to discover available tools from all servers.")
    else:
        click.echo("No servers were added.")


def _format_http_server(config: dict) -> list[str]:
    """Format HTTP server configuration for display.

    Args:
        config: Server configuration dictionary

    Returns:
        List of formatted output lines
    """
    lines = []
    lines.append(f"    URL: {config.get('url', 'N/A')}")

    if config.get("auth"):
        auth = config["auth"]
        lines.append(f"    Auth Type: {auth.get('type', 'N/A')}")

    if config.get("headers"):
        headers_str = ", ".join(f"{k}={v}" for k, v in config["headers"].items())
        lines.append(f"    Headers: {headers_str}")

    if config.get("timeout"):
        lines.append(f"    Timeout: {config['timeout']}s")

    return lines


def _format_stdio_server(config: dict) -> list[str]:
    """Format stdio server configuration for display.

    Args:
        config: Server configuration dictionary

    Returns:
        List of formatted output lines
    """
    command = config.get("command", "")
    args = " ".join(config.get("args", []))
    return [f"    Command: {command} {args}".rstrip()]


def _format_server_output(name: str, config: dict) -> None:
    """Format and display a single server's configuration.

    Args:
        name: Server name
        config: Server configuration dictionary
    """
    click.echo(f"\n  {name}:")
    transport = config.get("type", "stdio")
    click.echo(f"    Transport: {transport}")

    # Format transport-specific configuration
    lines = _format_http_server(config) if transport == "http" else _format_stdio_server(config)

    for line in lines:
        click.echo(line)

    # Format common configuration
    if config.get("env"):
        env_str = ", ".join(f"{k}={v}" for k, v in config["env"].items())
        click.echo(f"    Environment: {env_str}")

    if "created_at" in config:
        click.echo(f"    Created: {config['created_at']}")

    if "updated_at" in config:
        click.echo(f"    Updated: {config['updated_at']}")


@mcp.command(name="list")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def list_servers(output_json: bool) -> None:
    """List all configured MCP servers."""
    manager = MCPServerManager()

    try:
        servers = manager.get_all_servers()

        if output_json:
            click.echo(json.dumps(servers, indent=2))
            return

        if not servers:
            click.echo("No MCP servers configured.")
            click.echo("Add one with: pflow mcp add <name> <command>")
            return

        click.echo("Configured MCP servers:")
        for name, config in servers.items():
            _format_server_output(name, config)

    except Exception as e:
        click.echo(f"Error: Failed to list servers: {e}", err=True)
        sys.exit(1)


@mcp.command(name="remove")
@click.argument("name")
@click.option("--force", "-f", is_flag=True, help="Remove without confirmation")
def remove(name: str, force: bool) -> None:
    """Remove an MCP server configuration."""
    manager = MCPServerManager()
    registrar = MCPRegistrar(registry=None, manager=manager)

    try:
        # Check if server exists
        if not manager.get_server(name):
            click.echo(f"Error: Server '{name}' not found", err=True)
            sys.exit(1)

        # Count registered tools
        registered_tools = registrar.list_registered_tools(name)

        # Confirm removal
        if not force:
            msg = f"Remove server '{name}'?"
            if registered_tools:
                msg += f" This will also remove {len(registered_tools)} registered tools."
            if not click.confirm(msg):
                click.echo("Cancelled.")
                return

        # Remove tools from registry
        if registered_tools:
            removed = registrar.remove_server_tools(name)
            click.echo(f"  Removed {removed} tools from registry")

        # Remove server configuration
        if manager.remove_server(name):
            click.echo(f"✓ Removed MCP server '{name}'")
        else:
            click.echo(f"Warning: Server '{name}' was not found", err=True)

    except Exception as e:
        click.echo(f"Error: Failed to remove server: {e}", err=True)
        sys.exit(1)


def _validate_sync_arguments(name: Optional[str], all_servers: bool) -> None:
    """Validate sync command arguments.

    Args:
        name: Server name to sync
        all_servers: Whether to sync all servers

    Raises:
        SystemExit: If arguments are invalid
    """
    if not name and not all_servers:
        click.echo("Error: Specify a server name or use --all", err=True)
        sys.exit(1)

    if name and all_servers:
        click.echo("Error: Cannot specify both server name and --all", err=True)
        sys.exit(1)


def _sync_all_servers(manager: MCPServerManager, registrar: MCPRegistrar) -> None:
    """Sync tools from all configured servers.

    Args:
        manager: MCPServerManager instance
        registrar: MCPRegistrar instance
    """
    import json

    from pflow.registry import Registry

    servers = manager.list_servers()
    if not servers:
        click.echo("No MCP servers configured.")
        return

    click.echo(f"Syncing {len(servers)} servers...")
    results = registrar.sync_all_servers()

    total_discovered = 0
    total_registered = 0

    for result in results:
        server = result["server"]
        discovered = result["tools_discovered"]
        registered = result["tools_registered"]

        total_discovered += discovered
        total_registered += registered

        if "error" in result:
            click.echo(f"  ✗ {server}: {result['error']}", err=True)
        else:
            click.echo(f"  ✓ {server}: {discovered} discovered, {registered} registered")

    click.echo(f"\nTotal: {total_discovered} tools discovered, {total_registered} registered")

    # Update sync metadata after successful sync
    registry = Registry()
    registry.set_metadata("mcp_last_sync_time", time.time())

    # Store hash of current servers
    current_servers = sorted(servers)
    servers_hash = hashlib.sha256(json.dumps(current_servers).encode()).hexdigest()
    registry.set_metadata("mcp_servers_hash", servers_hash)


def _sync_single_server(name: str, manager: MCPServerManager, registrar: MCPRegistrar) -> None:
    """Sync tools from a single server.

    Args:
        name: Server name to sync
        manager: MCPServerManager instance
        registrar: MCPRegistrar instance

    Raises:
        SystemExit: If server not found or sync fails
    """
    if not manager.get_server(name):
        click.echo(f"Error: Server '{name}' not found", err=True)
        sys.exit(1)

    click.echo(f"Syncing server '{name}'...")
    result = registrar.sync_server(name)

    if "error" in result:
        click.echo(f"Error: {result['error']}", err=True)
        sys.exit(1)

    discovered = result["tools_discovered"]
    registered = result["tools_registered"]

    click.echo(f"✓ Discovered {discovered} tools")
    click.echo(f"✓ Registered {registered} tools in pflow registry")

    _display_registered_tools(name, registered, registrar)


def _display_registered_tools(server_name: str, registered_count: int, registrar: MCPRegistrar) -> None:
    """Display list of registered tools for a server.

    Args:
        server_name: Name of the server
        registered_count: Number of tools registered
        registrar: MCPRegistrar instance
    """
    if registered_count > 0:
        tools = registrar.list_registered_tools(server_name)
        click.echo("\nRegistered tools:")
        for tool_name in tools[:10]:  # Show first 10
            click.echo(f"  - {tool_name}")
        if len(tools) > 10:
            click.echo(f"  ... and {len(tools) - 10} more")


@mcp.command(name="sync")
@click.argument("name", required=False)
@click.option("--all", "-a", "all_servers", is_flag=True, help="Sync all configured servers")
def sync(name: Optional[str], all_servers: bool) -> None:
    """Discover and register tools from MCP servers.

    Examples:
        pflow mcp sync github        # Sync specific server
        pflow mcp sync --all         # Sync all servers
    """
    _validate_sync_arguments(name, all_servers)

    manager = MCPServerManager()
    registrar = MCPRegistrar(registry=None, manager=manager)

    try:
        if all_servers:
            _sync_all_servers(manager, registrar)
        else:
            if name:
                _sync_single_server(name, manager, registrar)
            else:
                click.echo("Error: No server name provided", err=True)
                return

    except Exception as e:
        click.echo(f"Error: Failed to sync: {e}", err=True)
        sys.exit(1)


def _get_tools_info_as_json(registrar: MCPRegistrar, tool_names: list[str]) -> str:
    """Get tools info and format as JSON."""
    tools_info = []
    for tool_name in tool_names:
        info = registrar.get_tool_info(tool_name)
        if info:
            tools_info.append(info)
    return json.dumps(tools_info, indent=2)


def _display_server_tools(registrar: MCPRegistrar, server: str, tool_names: list[str]) -> None:
    """Display tools for a specific server."""
    if not tool_names:
        click.echo(f"No tools registered for server '{server}'")
        click.echo(f"Run 'pflow mcp sync {server}' to discover tools")
        return

    click.echo(f"Registered tools for '{server}':")
    for tool_name in tool_names:
        info = registrar.get_tool_info(tool_name)
        if info:
            click.echo(f"\n  {tool_name}:")
            click.echo(f"    {info['description']}")
            if info["params"]:
                click.echo(f"    Parameters: {', '.join(p['key'] for p in info['params'])}")


def _group_tools_by_server(tool_names: list[str]) -> dict[str, list[str]]:
    """Group tool names by their server prefix."""
    tools_by_server: dict[str, list[str]] = {}
    for tool_name in tool_names:
        parts = tool_name.split("-", 2)
        if len(parts) >= 3:
            server_name = parts[1]
            if server_name not in tools_by_server:
                tools_by_server[server_name] = []
            tools_by_server[server_name].append(tool_name)
    return tools_by_server


def _display_all_tools_grouped(registrar: MCPRegistrar, tool_names: list[str]) -> None:
    """Display all tools grouped by server."""
    if not tool_names:
        click.echo("No MCP tools registered")
        click.echo("Run 'pflow mcp sync --all' to discover tools")
        return

    tools_by_server = _group_tools_by_server(tool_names)
    click.echo("Registered MCP tools:")

    for server_name, server_tools in sorted(tools_by_server.items()):
        click.echo(f"\n  {server_name} ({len(server_tools)} tools):")

        # Show first 5 tools
        for tool_name in server_tools[:5]:
            info = registrar.get_tool_info(tool_name)
            if info:
                click.echo(f"    - {tool_name}: {info['description'][:60]}...")

        # Show count of remaining tools
        if len(server_tools) > 5:
            click.echo(f"    ... and {len(server_tools) - 5} more")


@mcp.command(name="tools")
@click.argument("server", required=False)
@click.option("--all", "-a", "all_servers", is_flag=True, help="List tools from all servers")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def tools(server: Optional[str], all_servers: bool, output_json: bool) -> None:
    """List registered MCP tools.

    Examples:
        pflow mcp tools              # List all MCP tools
        pflow mcp tools github       # List tools from specific server
        pflow mcp tools --json       # Output as JSON
    """
    registrar = MCPRegistrar()

    try:
        if server:
            # List tools from specific server
            tool_names = registrar.list_registered_tools(server)

            if output_json:
                click.echo(_get_tools_info_as_json(registrar, tool_names))
            else:
                _display_server_tools(registrar, server, tool_names)
        else:
            # List all MCP tools
            tool_names = registrar.list_registered_tools()

            if output_json:
                click.echo(_get_tools_info_as_json(registrar, tool_names))
            else:
                _display_all_tools_grouped(registrar, tool_names)

    except Exception as e:
        click.echo(f"Error: Failed to list tools: {e}", err=True)
        sys.exit(1)


def _format_tool_header(tool_info: dict) -> None:
    """Format and display tool header information."""
    click.echo(f"Tool: {tool_info['node_name']}")
    click.echo(f"Server: {tool_info['server']}")
    click.echo(f"Tool Name: {tool_info['tool']}")
    click.echo(f"Description: {tool_info['description']}")
    click.echo(f"Module: {tool_info['module']}")
    click.echo(f"Class: {tool_info['class_name']}")


def _format_parameters(params: list[dict], title: str = "Parameters") -> None:
    """Format and display parameters or inputs."""
    if params:
        click.echo(f"\n{title}:")
        for param in params:
            required = " (required)" if param.get("required") else ""
            desc = f" - {param.get('description', '')}" if param.get("description") else ""
            click.echo(f"  - {param['key']}: {param['type']}{required}{desc}")
    else:
        click.echo(f"\n{title}: None")


def _format_outputs(outputs: list[dict]) -> None:
    """Format and display outputs."""
    if outputs:
        click.echo("\nOutputs:")
        for output in outputs:
            desc = f" - {output.get('description', '')}" if output.get("description") else ""
            click.echo(f"  - {output['key']}: {output['type']}{desc}")


def _suggest_similar_tools(registrar: MCPRegistrar, tool: str) -> None:
    """Suggest similar tools when a tool is not found."""
    all_tools = registrar.list_registered_tools()

    # Find similar tools using shared utility
    suggestions = find_similar_items(tool, all_tools, max_results=5, method="substring")

    # Format and display message
    message = format_did_you_mean(tool, suggestions, item_type="tool", fallback_items=all_tools, max_fallback=10)

    click.echo(f"\n{message}")


@mcp.command(name="info")
@click.argument("tool")
def info(tool: str) -> None:
    """Show detailed information about an MCP tool.

    Example:
        pflow mcp info mcp-github-create-issue
    """
    registrar = MCPRegistrar()

    try:
        tool_info = registrar.get_tool_info(tool)

        if not tool_info:
            click.echo(f"Error: Tool '{tool}' not found", err=True)
            _suggest_similar_tools(registrar, tool)
            sys.exit(1)

        _format_tool_header(tool_info)
        _format_parameters(tool_info["params"])
        _format_outputs(tool_info["outputs"])

        # Add .pflow.md usage snippet
        tool_name = tool_info["node_name"]
        click.echo("\nUsage in .pflow.md:\n")
        click.echo("    ### step-name")
        click.echo("")
        click.echo("    Describe what this step does and why.")
        click.echo("")
        click.echo(f"    - type: {tool_name}")
        params = tool_info.get("params", [])
        shown = 0
        for param in params[:3]:
            key = param.get("key", "")
            if key:
                # First param gets a literal, subsequent get template refs
                ptype = param.get("type", "str").lower()
                if shown == 0:
                    placeholder = "value"
                elif ptype in ("int", "integer", "number"):
                    placeholder = "0"
                elif ptype in ("bool", "boolean"):
                    placeholder = "true"
                else:
                    placeholder = "${previous-step.response}"
                click.echo(f"    - {key}: {placeholder}")
                shown += 1

    except Exception as e:
        click.echo(f"Error: Failed to get tool info: {e}", err=True)
        sys.exit(1)


@mcp.command(name="serve")
@click.option("--debug", is_flag=True, help="Enable debug logging")
def serve(debug: bool) -> None:
    """Run pflow as an MCP server (stdio transport).

    This starts an MCP server that exposes pflow's workflow building and
    execution capabilities as programmatic tools for AI agents.

    The server uses stdio transport where:
    - stdin: Receives JSON-RPC requests from clients
    - stdout: Sends JSON-RPC responses (protocol only)
    - stderr: All logging output

    Example:
        # Start the server (usually done by AI agents automatically)
        pflow mcp serve

        # With debug logging
        pflow mcp serve --debug

    The server exposes 13 tools for agents to:
    - Discover existing workflows and nodes
    - Execute workflows with structured output
    - Validate workflows before execution
    - Save workflows to the global library
    - Configure settings and API keys

    Note: This command is typically invoked by AI agents/clients,
    not directly by users.
    """
    import sys

    try:
        from pflow.mcp_server.main import main as mcp_server_main
    except ImportError:
        click.echo(
            "Error: MCP server dependencies not installed.\n"
            "Install with: pip install 'pflow[mcp]' or pip install 'mcp[cli]>=1.17.0'",
            err=True,
        )
        sys.exit(1)

    # Run the MCP server (synchronous - FastMCP manages its own event loop)
    try:
        mcp_server_main(debug=debug)
    except KeyboardInterrupt:
        # Clean exit on Ctrl+C
        sys.exit(0)
    except Exception as e:
        click.echo(f"Error: MCP server failed: {e}", err=True)
        sys.exit(1)
