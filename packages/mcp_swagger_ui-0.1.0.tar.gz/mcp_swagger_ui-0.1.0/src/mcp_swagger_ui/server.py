from __future__ import annotations

from typing import Any, Callable, Optional

from fastapi import APIRouter, Depends, FastAPI
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.responses import HTMLResponse, JSONResponse

from .openapi_like import generate_openapi_like


def create_docs_router(
    mcp: Any,
    *,
    title: str = "MCP Docs",
    version: str = "1.0.0",
    openapi_path: str = "/openapi.json",
    auth_dependency: Optional[Callable[..., Any]] = None,
) -> APIRouter:
    """Create an APIRouter that exposes Swagger-like docs for a FastMCP instance."""
    dependencies = [Depends(auth_dependency)] if auth_dependency is not None else []
    router = APIRouter(dependencies=dependencies)

    @router.get("/", response_class=HTMLResponse)
    async def docs_home() -> HTMLResponse:
        return get_swagger_ui_html(
            openapi_url=f"./{openapi_path.lstrip('/')}",
            title=title,
        )

    @router.get(openapi_path, response_class=JSONResponse)
    async def docs_openapi() -> JSONResponse:
        payload = await generate_openapi_like(mcp=mcp, title=title, version=version)
        return JSONResponse(payload)

    return router


def mount_mcp_docs(
    app: FastAPI,
    mcp: Any,
    *,
    mount_path: str = "/mcp-docs",
    title: str = "MCP Docs",
    version: str = "1.0.0",
    auth_dependency: Optional[Callable[..., Any]] = None,
) -> None:
    """Mount docs endpoints under a subpath, e.g. /mcp-docs and /mcp-docs/openapi.json."""
    router = create_docs_router(
        mcp,
        title=title,
        version=version,
        openapi_path="/openapi.json",
        auth_dependency=auth_dependency,
    )
    app.include_router(router, prefix=mount_path.rstrip("/"))
