from __future__ import annotations

from typing import Any, Dict

from .introspection import collect_all


async def generate_openapi_like(
    mcp: Any, title: str = "MCP API Docs", version: str = "1.0.0"
) -> Dict[str, Any]:
    registries = await collect_all(mcp)
    paths: Dict[str, Any] = {}

    for kind in ("tools", "prompts", "resources"):
        for item in registries[kind]:
            route = f"/{kind}/{item.name}"
            paths[route] = {
                "get": {
                    "summary": f"Inspect {kind[:-1]} `{item.name}`",
                    "description": item.description or f"{kind[:-1].capitalize()} definition",
                    "tags": [kind],
                    "x-mcp-kind": item.category,
                    "x-mcp-metadata": item.metadata,
                    "requestBody": {
                        "required": False,
                        "content": {
                            "application/json": {
                                "schema": item.input_schema or {"type": "object"},
                            }
                        },
                    },
                    "responses": {
                        "200": {
                            "description": "Success",
                            "content": {
                                "application/json": {
                                    "schema": item.output_schema or {"type": "object"},
                                }
                            },
                        }
                    },
                }
            }

    return {
        "openapi": "3.1.0",
        "info": {
            "title": title,
            "version": version,
            "description": "Auto-generated Swagger-like documentation for FastMCP registries.",
        },
        "paths": paths,
        "x-mcp": {
            "tools": [item.name for item in registries["tools"]],
            "prompts": [item.name for item in registries["prompts"]],
            "resources": [item.name for item in registries["resources"]],
        },
    }
