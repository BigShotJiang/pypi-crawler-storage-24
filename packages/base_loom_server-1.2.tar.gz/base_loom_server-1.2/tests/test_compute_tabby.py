import pytest

from base_loom_server.compute_tabby import (
    TabbyMetric,
    compute_tabby_metric,
    compute_tabby_shaft_word1,
    compute_tabby_shaft_word1_simple,
    compute_tabby_shaft_word2,
    compute_tabby_shaft_words,
)

# Dict of field name: default value
EXPECTED_DEFAULTS = dict(
    pick_number=0,
    pick_repeat_number=1,
    end_number0=0,
    end_number1=0,
    end_repeat_number=1,
)


def test_known_values() -> None:
    """Get the shaft set for a specified 1-based pick_number."""
    # Explicit values use 1-based shafts, for readability,
    # but internally the threading array uses 0-based shafts.
    # If expected_tabby_metric == 0 use len(threading),
    # which is only appropriate for perfect interlacement.
    for (
        threading_1based,
        expected_tabby_shaft_word1,
        expected_missing_transitions,
        expected_longest_float_length,
        expected_num_longest_floats,
    ) in (
        # Fully interlaced
        ([1, 2], 0b01, 0, 1, 0),
        ([1, 2, 3, 4, 3, 2, 1], 0b0101, 0, 1, 0),
        ([1, 2, 3, 4, 1, 2, 3], 0b0101, 0, 1, 0),
        ([4, 3, 2, 1, 2, 3, 4], 0b0101, 0, 1, 0),
        ([2, 3, 4, 5, 4, 3, 2], 0b01010, 0, 1, 0),
        ([3, 4, 5, 6, 5, 4, 3], 0b010100, 0, 1, 0),
        ([1, 10, 3, 6], 0b0000000101, 0, 1, 0),
        ([2, 5, 4, 9], 0b000001010, 0, 1, 0),
        ([2, 1, 2, 3, 4, 5], 0b01010, 0, 1, 0),
        # Some repeating warp ends; ignoring those
        # the fabric is fully interlaced.
        ([6, 5, 4, 3, 3, 4, 5], 0b010100, 1, 2, 1),
        ([5, 4, 3, 2, 2, 3, 4], 0b01010, 1, 2, 1),
        ([1, 1, 2, 2], 0b01, 2, 2, 2),
        ([1, 1, 2, 2, 3, 3, 3], 0b010, 4, 3, 1),
        # Overshot (perfect interlacemet)
        ([1, 2, 1, 2, 3, 2, 3, 4, 3, 4, 1, 4, 1], 0b0101, 0, 1, 0),
        # Bronson lace (perfect interlacemet)
        ([1, 2, 1, 2, 1, 3, 1, 3, 1, 4, 1, 4], 0b0001, 0, 1, 0),
        # Canvas weave
        ([1, 2, 2, 1, 4, 3, 3, 4], 0b0101, 2, 2, 2),
        # Diversified plain weave (various forms)
        # The first two forms
        ([2, 3, 1, 2, 4, 1, 2, 5, 1], 0b00011, 2, 2, 2),
        ([1, 2, 3, 1, 2, 4, 1, 2, 5], 0b00010, 2, 2, 2),  # the standard 0b00011 has one fewer transitions
        ([1, 3, 1, 2, 4, 2, 1, 5, 1], 0b01001, 0, 1, 0),  # the simple algorithm works
        ([2, 3, 2, 1, 4, 1, 2, 5, 2], 0b01010, 0, 1, 0),  # the simple algorithm works
        # Other cases where the simple algorithm does not work.
        ([1, 2, 3, 1, 2, 3], 0b010, 1, 2, 1),
        ([1, 2, 4, 2, 3, 1], 0b0010, 1, 2, 1),
    ):
        if expected_num_longest_floats == 0:
            expected_num_longest_floats = len(threading_1based)  # noqa: PLW2901

        expected_tabby_metric = TabbyMetric(
            missing_transitions=expected_missing_transitions,
            longest_float_length=expected_longest_float_length,
            num_longest_floats=expected_num_longest_floats,
            tabby_shaft_word=expected_tabby_shaft_word1,
        )
        threading = [shaft - 1 for shaft in threading_1based]

        max_shaft_number = max(threading) + 1
        expected_shaft_word2 = ~expected_tabby_shaft_word1 & (2**max_shaft_number - 1)

        tabby_shaft_word1 = compute_tabby_shaft_word1(threading=threading)
        tabby_shaft_word2 = compute_tabby_shaft_word2(
            tabby_shaft_word1=tabby_shaft_word1, threading=threading
        )
        tabby_metric = compute_tabby_metric(tabby_shaft_word1, threading=threading)

        if expected_tabby_metric != tabby_metric:
            print(  # noqa: T201
                f"Failed for {threading_1based=}: "
                f"{tabby_shaft_word1=:b}, {expected_tabby_shaft_word1=:b}\n"
                f"         {tabby_metric=}\n{expected_tabby_metric=}",
            )

        assert tabby_shaft_word1 == expected_tabby_shaft_word1
        assert tabby_shaft_word2 == expected_shaft_word2
        assert tabby_metric == expected_tabby_metric

        assert expected_tabby_shaft_word1, expected_shaft_word2 == compute_tabby_shaft_words(threading)


def test_invalid_values() -> None:
    # Smallest valid tabby shaft word
    valid_tabby_shaft_word = 0b1

    # Use 0-based threading (unlike in test_known_values),
    # as readability of the exact shafts used is less important
    for threading in (
        # Need at least two threaded warp ends
        [],
        [0],
        [1],
        # Need at least two different threaded shafts
        [0, 0],
        [1, 1],
        [5, 5],
    ):
        with pytest.raises(ValueError):
            compute_tabby_shaft_word1(threading=threading)
        with pytest.raises(ValueError):
            compute_tabby_shaft_word1_simple(threading=threading)
        with pytest.raises(ValueError):
            compute_tabby_shaft_words(threading=threading)
        if len(threading) == 0:
            # No warp ends are threaded
            with pytest.raises(ValueError):
                compute_tabby_shaft_word2(tabby_shaft_word1=valid_tabby_shaft_word, threading=threading)
        else:
            # Raise no shafts on tabby 1
            with pytest.raises(ValueError):
                compute_tabby_shaft_word2(tabby_shaft_word1=0, threading=threading)

            # Raise all shafts on tabby 1, so none are raised on tabby 2
            max_threaded_shaft_number = max(threading) + 1
            all_shafts_up = 2**max_threaded_shaft_number - 1
            with pytest.raises(ValueError):
                compute_tabby_shaft_word2(tabby_shaft_word1=all_shafts_up, threading=threading)

    for threading in (
        # Need at least two threaded warp ends
        [],
        [0],
        [1],
    ):
        with pytest.raises(ValueError):
            compute_tabby_metric(tabby_shaft_word=valid_tabby_shaft_word, threading=threading)
