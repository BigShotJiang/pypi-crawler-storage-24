# Settings

<div>
<img src="../images/screen_shots/settings_safari_macos.jpg" width="300" alt="Settings: Safari on macOS">
<img src="../images/screen_shots/settings_safari_iphone_mini.jpg" width="150" alt="Settings: Safari on iPhone mini">
</div>

The Settings mode allows you to specify settings that apply to all weaving patterns.
Settings are automatically saved, and should survive rebooting the loom server.

Settings include:

* **Language**: which language to use.
  Note that this is always the first setting, and the settings panel is always the 3rd tab.
  So if the page is a language you don't recognize, click on the first pop-up menu in the settings panel to choose a different language.

  Your help to improve existing translations or add new languages would be much appreciated.
  Read [Translations](translations.md) for more information.

  Note that changing the languages reloads the page. This should be fast and harmless.

* **Loom name**: the name of the loom, as it appears in the display.
  Use any name you like; it is just for display.

* **Direction control**: specify how to change direction (weaving or unweaving, threading or unthreading).
  See [Weave Direction](weaving.md#weave-direction) for more information.
  This setting is not shown for Séguin looms and others that support changing direction from both software and a button on the loom.

* **Warp thread 1**: specify whether to display Warp thread 1 on the right or left
  in the [Weaving](weaving.md) and [Threading](threading.md) pattern displays.
  However, this is as seen *from the front of the loom*.
  If you specify threading front-to-back, the threading pattern is displayed as seen from the back of the loom,
  so end 1 will be on the opposite side than what you specify here.

* **Threading**: specify whether you prefer to thread right-to-left or left-to-right, and front-to-back or back-to-front.
  Specifying front-to-back simply changes the Threading pattern display to appear as if you are sitting behind the castle:
  shaft 1 is displayed at the top and Warp thread 1 is displayed on the opposite side of that specified in "Warp thread 1`".

* **Default threading group size**: specify the threading group size for newly uploaded patterns.
  This setting has no effect on any pattern files that are already loaded;
  use the "Group size" control in the [Threading](threading.md) panel to change those.

  Unless the threading is trivial, I suggest using a group size of 1 (only lift one shaft at a time).
  It is a bit slower, but much safer.

* **WiFi network**: specify which WiFi network the loom server runs.
  This setting is only available if the loom server is run with a special command-line argument
  (and typically only if the loom server is a box that is hard to connect to).

  Choosing one of the hotspots makes the loom server run its own WiFI network
  (to which you must connect) instead of joining your network.
  Be very careful entering a WiFi password; if you get it wrong the loom may end up running a hotspot, or, worse in a state where you have to connect a monitor and keyboard to the server to fix the WiFi.

Below the settings you will find a table showing version numbers of the main software packages.
Please include this information in any bug reports or feature requests:

* The loom-specific package, e.g. toika_loom_server. This is rarely updated.
* base_loom_server: this package does most of the work of driving the loom and displaying state.
  New features and bug fixes usually appear here.
* dtx_to_wif: this reads WIF, .dtx, and .wto files.
  If you have an issue uploading a weaving file, this is the place to look for an update or to report a bug.

Finally, the current loom connection state is shown, since you must be connected to the loom to change settings.
