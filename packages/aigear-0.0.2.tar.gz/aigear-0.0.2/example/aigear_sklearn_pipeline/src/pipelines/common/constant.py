gcs_switch = False
