"""MCP tool handlers for video download and transcription."""

import json
import logging
import os

import httpx
from mcp.types import TextContent

logger = logging.getLogger(__name__)

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")

VIDEO_API_BASE = f"{CRAWLNEST_API_URL}/api/video"


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY
    return headers


def _error_response(error: str, details: str | None = None) -> list[TextContent]:
    resp: dict = {"success": False, "error": error}
    if details:
        resp["details"] = details
    return [TextContent(type="text", text=json.dumps(resp))]


async def handle_download_video(arguments: dict) -> list[TextContent]:
    """Get video metadata and download URLs from a tweet or Reddit post.

    Note: Returns metadata/URLs (not the binary stream) since MCP is text-based.
    """
    url = arguments.get("url")
    platform = arguments.get("platform")
    if not url or not platform:
        return _error_response("url and platform are required")

    payload: dict = {"url": url, "platform": platform}
    if arguments.get("quality"):
        payload["quality"] = arguments["quality"]

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{VIDEO_API_BASE}/metadata",
                json=payload,
                headers=_headers(),
                timeout=60.0,
            )
            if response.status_code != 200:
                return _error_response(
                    f"Video API returned HTTP {response.status_code}",
                    details=response.text,
                )
            data = response.json()
            return [TextContent(type="text", text=json.dumps({"success": True, **data}))]

    except httpx.TimeoutException:
        return _error_response("Request timed out")
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API", details=str(e))


async def handle_transcribe_video(arguments: dict) -> list[TextContent]:
    """Transcribe audio from a tweet or Reddit video post.

    Returns transcript text — no video is downloaded or saved.
    Uses a generous static timeout to cover the full API pipeline:
    video resolution → audio extraction → Whisper transcription.
    The API handles its own internal dynamic timeout for the Whisper call.
    """
    url = arguments.get("url")
    platform = arguments.get("platform")
    if not url or not platform:
        return _error_response("url and platform are required")

    payload: dict = {"url": url, "platform": platform}
    if arguments.get("language"):
        payload["language"] = arguments["language"]
    if arguments.get("response_format"):
        payload["response_format"] = arguments["response_format"]

    # Generous static timeout covering the full pipeline. No metadata pre-fetch
    # — calling /metadata before /transcribe causes double video resolution
    # (two FxTwitter/proxy calls in quick succession) which blocks the second
    # download. The API handles its own dynamic Whisper timeout internally.
    # 1800s (30 min) covers videos up to ~15-20 min comfortably.
    timeout = 1800.0

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{VIDEO_API_BASE}/transcribe",
                json=payload,
                headers=_headers(),
                timeout=timeout,
            )
            if response.status_code != 200:
                return _error_response(
                    f"Video API returned HTTP {response.status_code}",
                    details=response.text,
                )
            data = response.json()
            return [TextContent(type="text", text=json.dumps({"success": True, **data}))]

    except httpx.TimeoutException:
        return _error_response(
            "Request timed out — video may be too long for transcription"
        )
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API", details=str(e))
