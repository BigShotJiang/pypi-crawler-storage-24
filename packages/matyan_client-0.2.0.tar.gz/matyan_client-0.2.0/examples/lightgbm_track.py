"""Minimal LightGBM training with Matyan and maximal tracking.

MatyanCallback logs evaluation metrics; after train() we use the same callback's
.experiment to call shared helpers for images, text, distributions,
figures, audio, log messages, and file artifacts.

Usage:
    pip install matyan-client[lightgbm] numpy plotly
    python examples/lightgbm_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import lightgbm as lgb
import numpy as np
from _tracking_helpers import (
    track_audio_sample,
    track_file_artifact,
    track_log_messages,
    track_loss_figure,
    track_sample_distribution,
    track_sample_images,
    track_text,
)

from matyan_client.adapters.lightgbm import MatyanCallback

N_ROUNDS = 4


def main() -> None:
    np.random.seed(42)
    n = 200
    X = np.random.randn(n, 4).astype("float32")
    y = (X[:, 0] + X[:, 1] > 0).astype(int)
    train_data = lgb.Dataset(X, label=y)

    matyan_callback = MatyanCallback(experiment="lightgbm-maximal")
    callbacks = [matyan_callback]

    lgb.train(
        {"objective": "binary", "metric": "binary_logloss", "verbose": -1},
        train_data,
        num_boost_round=N_ROUNDS,
        callbacks=callbacks,
    )

    run = matyan_callback.experiment
    run["hparams.n_rounds"] = N_ROUNDS
    track_log_messages(run)
    track_sample_images(run, step=0, count=2)
    track_sample_distribution(run, "sample_dist", step=0)
    track_text(run, "note", "LightGBM maximal tracking example", step=0)
    track_audio_sample(run, "tones", step=0)
    track_loss_figure(
        run,
        [0.6 - i * 0.08 for i in range(4)],
        [0.62 - i * 0.08 for i in range(4)],
        step=0,
    )
    track_file_artifact(run, "lightgbm_artifact.txt")
    run.log_info("LightGBM training finished.")
    matyan_callback.close()


if __name__ == "__main__":
    main()
