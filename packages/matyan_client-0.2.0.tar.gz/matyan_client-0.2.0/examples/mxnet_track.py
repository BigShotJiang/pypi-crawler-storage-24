"""Minimal MXNet Gluon Estimator training with Matyan and maximal tracking.

MatyanLoggingHandler tracks metrics; we subclass it and override train_end to
call shared helpers when training ends (run is available via self.experiment).

Usage:
    pip install matyan-client[mxnet] numpy plotly mxnet
    python examples/mxnet_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _tracking_helpers import (
    track_audio_sample,
    track_file_artifact,
    track_log_messages,
    track_loss_figure,
    track_sample_distribution,
    track_sample_images,
    track_text,
)
from loguru import logger

try:
    from mxnet import gluon, init, nd
    from mxnet.gluon import nn
    from mxnet.gluon.contrib.estimator import Estimator
    from mxnet.metric import Loss
except (ImportError, OSError):
    logger.error(
        "MXNet is not available (missing dependency or native library, e.g. libarmpl on ARM64).",
    )
    sys.exit(123)

from matyan_client.adapters.mxnet import MatyanLoggingHandler


class MaximalTrackingHandler(MatyanLoggingHandler):
    """Calls shared tracking helpers at train_end."""

    def train_end(self, estimator, *args, **kwargs) -> None:
        run = self.experiment
        track_log_messages(run)
        track_sample_images(run, step=0, count=2)
        track_sample_distribution(run, "sample_dist", step=0)
        track_text(run, "note", "MXNet maximal tracking example", step=0)
        track_audio_sample(run, "tones", step=0)
        track_loss_figure(
            run,
            [0.5, 0.4, 0.3],
            [0.52, 0.42, 0.32],
            step=0,
        )
        track_file_artifact(run, "mxnet_artifact.txt")
        run.log_info("MXNet training finished.")
        super().train_end(estimator, *args, **kwargs)


def main() -> None:
    net = nn.Sequential()
    net.add(nn.Dense(64, activation="relu"), nn.Dense(10))
    net.initialize(init.Xavier())
    loss = gluon.loss.SoftmaxCrossEntropyLoss()
    train_metric = Loss("train_ce")
    val_metric = Loss("val_ce")

    # Minimal synthetic data
    X = nd.random.randn(32, 8)
    y = nd.random.randint(0, 10, shape=(32,))
    dataset = gluon.data.ArrayDataset(X, y)
    dataloader = gluon.data.DataLoader(dataset, batch_size=8)

    trainer = gluon.Trainer(
        net.collect_params(),
        "sgd",
        {"learning_rate": 0.01},
    )
    estimator = Estimator(
        net=net,
        loss=loss,
        train_metrics=train_metric,
        val_metrics=val_metric,
        trainer=trainer,
    )
    handler = MaximalTrackingHandler(
        log_interval="epoch",
        experiment_name="mxnet-maximal",
    )
    estimator.fit(dataloader, epochs=2, event_handlers=[handler])


if __name__ == "__main__":
    main()
