"""Shared tracking helpers for adapter example scripts.

Framework-agnostic helpers that log maximal data types (images, text,
distributions, figures, audio, log messages, file artifacts) to a Matyan Run.

Usage:
    from examples._tracking_helpers import (
        track_sample_images,
        track_sample_distribution,
        track_text,
        track_audio_sample,
        track_loss_figure,
        track_log_messages,
        track_file_artifact,
    )
    run = adapter.experiment
    track_sample_images(run, step=0)
    track_file_artifact(run)
"""

from __future__ import annotations

import contextlib
import os
import tempfile
from typing import TYPE_CHECKING

import numpy as np
import plotly.graph_objects as go

from matyan_client.objects import Audio, Distribution, Figure, Image, Text

if TYPE_CHECKING:
    from matyan_client import Run


def track_sample_images(run: Run, step: int = 0, count: int = 3) -> None:
    """Log synthetic sample images (small numpy arrays) to the run."""
    for i in range(count):
        # 8x8 grayscale placeholder
        img = (np.random.rand(8, 8) * 255).astype(np.uint8)

        run.track(
            Image(img, caption=f"synthetic sample {i}"),
            name="sample_images",
            step=step + i,
        )


def track_sample_distribution(run: Run, name: str = "sample_dist", step: int = 0) -> None:
    """Log a synthetic distribution (list of samples) to the run."""
    samples = [0.1 * i + 0.05 for i in range(100)]
    run.track(Distribution(samples=samples, bin_count=16), name=name, step=step)


def track_text(run: Run, name: str, text: str, step: int = 0) -> None:
    """Log a text value to the run."""
    run.track(Text(text), name=name, step=step)


def track_audio_sample(run: Run, name: str = "audio_tones", step: int = 0) -> None:
    """Log synthetic sine-wave audio clips to the run."""
    rate = 22050
    duration = 0.3
    t = np.linspace(0, duration, int(rate * duration), dtype=np.float32)
    freqs = [261.63, 329.63, 392.00]
    for i, freq in enumerate(freqs):
        wave = np.sin(2 * np.pi * freq * t)
        run.track(
            Audio(wave, format_="wav", caption=f"{freq:.0f}Hz", rate=rate),
            name=name,
            step=step + i,
        )


def track_loss_figure(
    run: Run,
    train_values: list[float],
    val_values: list[float],
    step: int = 0,
) -> None:
    """Log a plotly figure (e.g. loss curve). No-op if plotly is not installed."""
    fig = go.Figure()
    epochs = list(range(len(train_values)))
    fig.add_trace(go.Scatter(x=epochs, y=train_values, mode="lines+markers", name="train"))
    fig.add_trace(go.Scatter(x=epochs, y=val_values, mode="lines+markers", name="val"))
    fig.update_layout(title="Loss Curve", xaxis_title="Epoch", yaxis_title="Loss")
    run.track(Figure(fig), name="loss_curve", step=step)


def track_log_messages(run: Run) -> None:
    """Emit sample log_info and log_warning messages."""
    run.log_info("Example info message from adapter script")
    run.log_warning("Example warning message from adapter script")


def track_file_artifact(run: Run, name: str = "artifact.txt") -> None:
    """Write a small temp file and log it as an artifact via run.log_artifact."""
    content = b"Matyan adapter example artifact\n"
    with tempfile.NamedTemporaryFile(mode="wb", suffix=".txt", delete=False) as f:
        f.write(content)
        path = f.name
    try:
        run.log_artifact(path, name=name)
    finally:
        with contextlib.suppress(OSError):
            os.unlink(path)
