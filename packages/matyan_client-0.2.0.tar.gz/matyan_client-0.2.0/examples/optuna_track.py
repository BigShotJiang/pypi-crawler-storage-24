"""Minimal Optuna study with Matyan and maximal tracking.

MatyanCallback logs trial params and objective values. We use as_multirun=False
and call shared helpers inside the callback when the run is set (once, on
the first trial).

Usage:
    pip install matyan-client[optuna] numpy plotly
    python examples/optuna_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import optuna
from _tracking_helpers import (
    track_audio_sample,
    track_file_artifact,
    track_log_messages,
    track_loss_figure,
    track_sample_distribution,
    track_sample_images,
    track_text,
)

from matyan_client.adapters.optuna import MatyanCallback

N_TRIALS = 3


def objective(trial: optuna.Trial) -> float:
    x = trial.suggest_float("x", -2.0, 2.0)
    return (x - 0.5) ** 2


def main() -> None:
    matyan_callback = MatyanCallback(
        experiment_name="optuna-maximal",
        as_multirun=False,
    )
    study = optuna.create_study()
    study.optimize(
        objective,
        n_trials=N_TRIALS,
        callbacks=[matyan_callback],
    )

    run = matyan_callback.experiment
    if run is not None:
        track_log_messages(run)
        track_sample_images(run, step=0, count=2)
        track_sample_distribution(run, "sample_dist", step=0)
        track_text(run, "note", "Optuna maximal tracking example", step=0)
        track_audio_sample(run, "tones", step=0)
        train_vals = [t.value for t in study.trials if t.value is not None]
        track_loss_figure(
            run,
            train_vals,
            train_vals,
            step=0,
        )
        track_file_artifact(run, "optuna_artifact.txt")
        run.log_info("Optuna study finished.")
    matyan_callback.close()


if __name__ == "__main__":
    main()
