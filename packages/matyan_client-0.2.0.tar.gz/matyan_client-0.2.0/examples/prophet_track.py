"""Minimal Prophet fit with Matyan and maximal tracking.

MatyanLogger is passed to model.fit(logger=...); after fit() we use
logger.experiment to call shared helpers for images, text, distributions,
figures, audio, log messages, and file artifacts.

Usage:
    pip install matyan-client[prophet] numpy plotly prophet
    python examples/prophet_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd
from _tracking_helpers import (
    track_audio_sample,
    track_file_artifact,
    track_log_messages,
    track_loss_figure,
    track_sample_distribution,
    track_sample_images,
    track_text,
)
from prophet import Prophet

from matyan_client.adapters.prophet import MatyanLogger


def main() -> None:
    # Minimal daily series for a few days
    dates = pd.date_range("2020-01-01", periods=14, freq="D")
    df = pd.DataFrame({"ds": dates, "y": [10.0 + i * 0.1 for i in range(14)]})

    model = Prophet()
    matyan_logger = MatyanLogger(model, experiment="prophet-maximal")
    model.fit(df)

    run = matyan_logger.experiment
    track_log_messages(run)
    track_sample_images(run, step=0, count=2)
    track_sample_distribution(run, "sample_dist", step=0)
    track_text(run, "note", "Prophet maximal tracking example", step=0)
    track_audio_sample(run, "tones", step=0)
    track_loss_figure(
        run,
        [10.0, 10.5, 11.0],
        [10.2, 10.6, 11.1],
        step=0,
    )
    track_file_artifact(run, "prophet_artifact.txt")
    run.log_info("Prophet fit finished.")


if __name__ == "__main__":
    main()
