"""Minimal PyTorch Ignite training with Matyan and maximal tracking.

MatyanLogger is attached to the trainer and logs metrics; we attach an event
handler for COMPLETED (or EPOCH_COMPLETED) to call shared helpers using
logger.experiment.

Usage:
    pip install matyan-client[pytorch_ignite] numpy plotly torch pytorch-ignite omegaconf
    python examples/pytorch_ignite_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import torch
from _tracking_helpers import (
    track_audio_sample,
    track_file_artifact,
    track_log_messages,
    track_loss_figure,
    track_sample_distribution,
    track_sample_images,
    track_text,
)
from ignite.engine import Engine, Events
from ignite.metrics import Loss
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from matyan_client.adapters.pytorch_ignite import MatyanLogger, OutputHandler

EPOCHS = 2
BATCH_SIZE = 8


def create_trainer(model, optimizer, device):
    def step_fn(engine, batch):
        model.train()
        x, y = batch
        x, y = x.to(device), y.to(device)
        optimizer.zero_grad()
        out = model(x)
        loss = nn.functional.cross_entropy(out, y)
        loss.backward()
        optimizer.step()
        return (out, y)

    return Engine(step_fn)


def main() -> None:
    device = torch.device("cpu")
    model = nn.Sequential(
        nn.Flatten(),
        nn.Linear(16, 32),
        nn.ReLU(),
        nn.Linear(32, 2),
    ).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    train_loss = Loss(nn.functional.cross_entropy)
    X = torch.randn(64, 4, 4)
    y = torch.randint(0, 2, (64,))
    loader = DataLoader(
        TensorDataset(X, y),
        batch_size=BATCH_SIZE,
        shuffle=True,
    )
    trainer = create_trainer(model, optimizer, device)
    train_loss.attach(trainer, "loss")

    matyan_logger = MatyanLogger(experiment="pytorch-ignite-maximal")
    matyan_logger.attach(
        trainer,
        OutputHandler(
            tag="train",
            metric_names=["loss"],
            global_step_transform=lambda e, _: e.state.iteration,
        ),
        event_name=Events.EPOCH_COMPLETED,
    )

    def run_helpers(engine):
        run = matyan_logger.experiment
        track_log_messages(run)
        track_sample_images(run, step=engine.state.epoch, count=2)
        track_sample_distribution(run, "sample_dist", step=engine.state.epoch)
        track_text(run, "note", "PyTorch Ignite maximal tracking example", step=engine.state.epoch)
        track_audio_sample(run, "tones", step=engine.state.epoch)
        track_loss_figure(
            run,
            [0.6 - engine.state.epoch * 0.1],
            [0.62 - engine.state.epoch * 0.1],
            step=engine.state.epoch,
        )
        track_file_artifact(run, "pytorch_ignite_artifact.txt")
        run.log_info("PyTorch Ignite training finished.")

    trainer.add_event_handler(Events.COMPLETED, run_helpers)

    trainer.run(loader, max_epochs=EPOCHS)
    matyan_logger.close()


if __name__ == "__main__":
    main()
