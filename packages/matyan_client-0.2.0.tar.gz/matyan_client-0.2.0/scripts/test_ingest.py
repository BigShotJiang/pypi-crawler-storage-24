#!/usr/bin/env python3
"""Simple test script that ingests sample data via the matyan_client Run API.

Requires:
  - matyan-backend  running on :53800
  - matyan-frontier running on :53801
  - ingestion worker running
  - RustFS (S3)     running on :9000

Usage:
    cd matyan-client
    uv run python scripts/test_ingest.py
"""

from __future__ import annotations

import math
import random
import struct
import tempfile
import time
import zlib
from pathlib import Path

import httpx
from loguru import logger

from matyan_client import Audio, Distribution, Figure, Image, Run, Text


def make_png_bytes(width: int = 8, height: int = 8, color: tuple[int, int, int] = (120, 80, 200)) -> bytes:
    """Generate a minimal valid PNG (uncompressed, no dependencies)."""

    def chunk(chunk_type: bytes, data: bytes) -> bytes:
        raw = chunk_type + data
        return struct.pack(">I", len(data)) + raw + struct.pack(">I", zlib.crc32(raw) & 0xFFFFFFFF)

    ihdr_data = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    raw_rows = b""
    for _ in range(height):
        raw_rows += b"\x00" + bytes(color) * width
    idat_data = zlib.compress(raw_rows)

    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr_data) + chunk(b"IDAT", idat_data) + chunk(b"IEND", b"")


def make_wav_bytes(duration_s: float = 0.5, freq_hz: float = 440.0, rate: int = 22050) -> bytes:
    """Generate a minimal valid WAV file with a sine tone."""
    num_samples = int(rate * duration_s)
    samples = []
    for i in range(num_samples):
        t = i / rate
        val = int(32767 * 0.5 * math.sin(2 * math.pi * freq_hz * t))
        samples.append(max(-32768, min(32767, val)))

    data_bytes = struct.pack(f"<{len(samples)}h", *samples)
    byte_rate = rate * 2
    data_size = len(data_bytes)

    header = b"RIFF"
    header += struct.pack("<I", 36 + data_size)
    header += b"WAVE"
    header += b"fmt "
    header += struct.pack("<IHHIIHH", 16, 1, 1, rate, byte_rate, 2, 16)
    header += b"data"
    header += struct.pack("<I", data_size)
    return header + data_bytes


def make_plotly_dict(title: str, xs: list[float], ys: list[float]) -> dict:
    """Build a plotly-compatible JSON dict (no plotly dependency needed)."""
    return {
        "data": [{"type": "scatter", "x": xs, "y": ys, "mode": "lines+markers"}],
        "layout": {"title": {"text": title}, "xaxis": {"title": "x"}, "yaxis": {"title": "y"}},
    }


def ingest_scalars(run: Run, num_steps: int = 50) -> None:
    """Track loss + accuracy for train and val subsets."""
    t0 = time.monotonic()
    for step in range(num_steps):
        train_loss = 2.0 * math.exp(-0.05 * step) + 0.02 * random.gauss(0, 1)
        train_acc = 1.0 - train_loss / 3.0 + 0.01 * random.gauss(0, 1)
        val_loss = 2.2 * math.exp(-0.04 * step) + 0.03 * random.gauss(0, 1)
        val_acc = 1.0 - val_loss / 3.0 + 0.015 * random.gauss(0, 1)

        run.track(train_loss, name="loss", step=step, context={"subset": "train"})
        run.track(train_acc, name="accuracy", step=step, context={"subset": "train"})
        run.track(val_loss, name="loss", step=step, context={"subset": "val"})
        run.track(val_acc, name="accuracy", step=step, context={"subset": "val"})

    elapsed = time.monotonic() - t0
    logger.info("Tracked {} steps of 4 metrics in {:.3f}s", num_steps, elapsed)


def ingest_log_messages(run: Run) -> None:
    """Emit structured log records (visible on the Messages tab)."""
    run.log_info("Training started", optimizer="adam", lr=0.001)
    run.log_info("Loaded dataset", num_samples=50000, split="train")
    run.log_info("Model has 11.7M parameters")
    run.log_warning("Learning rate might be too high for this architecture")
    run.log_info("Epoch 1/10 completed", train_loss=1.82, val_loss=1.95)
    run.log_info("Epoch 5/10 completed", train_loss=0.45, val_loss=0.52)
    run.log_warning("Validation loss plateaued for 3 epochs, consider early stopping")
    run.log_error("NaN detected in gradient for layer conv3, clipping applied")
    run.log_info("Epoch 10/10 completed", train_loss=0.12, val_loss=0.18)
    run.log_info("Best checkpoint saved", epoch=8, val_loss=0.15)
    run.log_info("Training finished", total_time_s=342.7)
    run.log_debug("Freed GPU memory: 2.4 GiB")
    logger.info("Emitted 12 log messages")


def ingest_custom_objects(run: Run) -> None:
    """Track text, distribution, figure, image, and audio objects."""
    predictions = ["cat", "dog", "bird", "fish", "horse"]
    for i, pred in enumerate(predictions):
        run.track(
            Text(f"Prediction: {pred} (confidence: {random.uniform(0.7, 0.99):.2f})"),
            name="predictions",
            step=i,
        )
    logger.info("Tracked {} text predictions", len(predictions))

    for step in range(5):
        mean = step * 0.1
        samples = [random.gauss(mean, 1.0) for _ in range(500)]
        run.track(Distribution(samples, bin_count=64), name="weight_dist", step=step)
    logger.info("Tracked 5 distribution snapshots")

    xs = [i * 0.1 for i in range(100)]
    run.track(
        Figure(make_plotly_dict("Sin curve", xs, [math.sin(x) for x in xs])),
        name="sin_plot",
        step=0,
    )
    run.track(
        Figure(make_plotly_dict("Cos curve", xs, [math.cos(x) for x in xs])),
        name="cos_plot",
        step=0,
    )
    logger.info("Tracked 2 figure objects")

    colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)]
    for i, color in enumerate(colors):
        png = make_png_bytes(width=16, height=16, color=color)
        run.track(Image(png, caption=f"color-{i}", format_="PNG"), name="samples", step=i)
    logger.info("Tracked {} images", len(colors))

    freqs = [261.63, 329.63, 392.00]  # C4, E4, G4
    for i, freq in enumerate(freqs):
        wav = make_wav_bytes(duration_s=0.3, freq_hz=freq)
        run.track(Audio(wav, format_="wav", caption=f"tone-{freq:.0f}Hz"), name="tones", step=i)
    logger.info("Tracked {} audio clips", len(freqs))


def ingest_file_artifact(run: Run) -> None:
    """Upload a raw file artifact via log_artifact() -> presigned S3 URL."""
    with tempfile.NamedTemporaryFile(suffix=".txt", delete=False, mode="w") as f:
        f.write("This is a test artifact file.\n")
        f.write("It demonstrates log_artifact() uploading to S3.\n")
        f.write(f"Run hash: {run.hash}\n")
        tmp_path = f.name

    run.log_artifact(tmp_path, name="test_artifact.txt")
    logger.info("Uploaded file artifact via log_artifact()")

    Path(tmp_path).unlink()


def verify_via_backend(run_hash: str) -> None:
    """Query the backend REST API and log what was ingested."""
    logger.info("Waiting 3s for ingestion pipeline to finish…")
    time.sleep(3)

    client = httpx.Client(base_url="http://localhost:53800", timeout=10)
    try:
        resp = client.get(f"/api/v1/rest/runs/{run_hash}/info/")
        if resp.status_code == 200:
            info = resp.json()
            logger.info("Run info from backend:")
            logger.info("  name: {}", info.get("props", {}).get("name"))
            logger.info("  experiment: {}", info.get("props", {}).get("experiment"))
            logger.info("  params keys: {}", list(info.get("params", {}).keys()))
            traces = info.get("traces", {})
            for seq_type, items in traces.items():
                names = [t.get("name") for t in items]
                logger.info("  {} traces: {}", seq_type, names)
        else:
            logger.warning("Backend returned status {} for run info", resp.status_code)
    finally:
        client.close()


def main() -> None:
    logger.info("=== Test ingest: matyan_client Run API ===")

    run = Run(
        experiment="test-ingest",
        system_tracking_interval=10,
        log_system_params=True,
        capture_terminal_logs=True,
    )
    logger.info("Created run: {}", run.hash)

    run["hparams"] = {
        "lr": 0.001,
        "batch_size": 32,
        "optimizer": "adam",
        "architecture": "resnet18",
        "dropout": 0.3,
    }
    run.name = "test-ingest-run"
    run.description = "Sample data ingested via test script"
    run.add_tag("test")
    logger.info("Set hparams, name, description, tag")

    ingest_scalars(run)
    ingest_log_messages(run)
    ingest_custom_objects(run)
    ingest_file_artifact(run)

    run.close()
    logger.info("Run closed")

    verify_via_backend(run.hash)

    logger.info("=== Test ingest complete ===")
    logger.info("Run hash: {} — check the UI at http://localhost:8000/runs/{}", run.hash, run.hash)


if __name__ == "__main__":
    main()
