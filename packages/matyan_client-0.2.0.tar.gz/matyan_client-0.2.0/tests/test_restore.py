"""Tests for the client-side restore-reingest module."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from matyan_client.restore import restore_reingest

if TYPE_CHECKING:
    from pathlib import Path


def _make_backup(tmp_path: Path, *, runs: dict | None = None, entities: list | None = None) -> Path:
    """Build a minimal backup directory for testing."""
    backup_dir = tmp_path / "backup"
    backup_dir.mkdir()
    (backup_dir / "runs").mkdir()

    run_hashes = []
    for rh, run_data in (runs or {}).items():
        run_hashes.append(rh)
        run_dir = backup_dir / "runs" / rh
        run_dir.mkdir()
        (run_dir / "run.json").write_text(json.dumps(run_data.get("meta", {"name": f"Run {rh}", "active": True})))
        (run_dir / "attrs.json").write_text(json.dumps(run_data.get("attrs", {})))
        (run_dir / "traces.json").write_text(json.dumps(run_data.get("traces", [])))
        (run_dir / "contexts.json").write_text(json.dumps(run_data.get("contexts", {"0": {}})))
        if "sequences" in run_data:
            with (run_dir / "sequences.jsonl").open("w") as f:
                for rec in run_data["sequences"]:
                    f.write(json.dumps(rec) + "\n")
        else:
            (run_dir / "sequences.jsonl").write_text("")
        if "blobs" in run_data:
            for blob_rel, blob_data in run_data["blobs"].items():
                blob_path = run_dir / "blobs" / blob_rel
                blob_path.parent.mkdir(parents=True, exist_ok=True)
                blob_path.write_bytes(blob_data)

    if entities:
        with (backup_dir / "entities.jsonl").open("w") as f:
            for e in entities:
                f.write(json.dumps(e) + "\n")

    manifest = {
        "format_version": 1,
        "created_at": "2026-01-01T00:00:00",
        "run_count": len(run_hashes),
        "run_hashes": run_hashes,
        "entity_counts": {},
        "blob_count": 0,
        "blob_bytes": 0,
        "filters": {},
        "include_blobs": True,
    }
    (backup_dir / "manifest.json").write_text(json.dumps(manifest))
    return backup_dir


class TestDryRun:
    def test_dry_run_counts(self, tmp_path: Path) -> None:
        backup_dir = _make_backup(
            tmp_path,
            runs={
                "r1": {
                    "sequences": [
                        {"ctx_id": 0, "name": "loss", "step": 0, "value": 1.0},
                        {"ctx_id": 0, "name": "loss", "step": 1, "value": 0.9},
                    ],
                },
            },
            entities=[{"entity_type": "experiment", "data": {"name": "exp1"}}],
        )

        result = restore_reingest(str(backup_dir), dry_run=True)

        assert result.runs_processed == 1
        assert result.sequence_records_sent == 2
        assert result.entities_processed == 1
        assert result.blobs_uploaded == 0
        assert result.errors == []


class TestValidation:
    def test_invalid_backup_raises(self, tmp_path: Path) -> None:
        backup_dir = tmp_path / "empty"
        backup_dir.mkdir()
        with pytest.raises(FileNotFoundError, match=r"No manifest.json"):
            restore_reingest(str(backup_dir))


class TestRestoreRun:
    @patch("matyan_client.restore.WsTransport")
    @patch("matyan_client.restore.HttpTransport")
    def test_restore_single_run_sends_correct_messages(
        self,
        mock_http_cls: MagicMock,
        mock_ws_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_http = MagicMock()
        mock_http.close = MagicMock()
        mock_http_cls.return_value = mock_http

        mock_ws = MagicMock()
        mock_ws.wait_for_flush = MagicMock()
        mock_ws.close = MagicMock()
        mock_ws_cls.return_value = mock_ws

        backup_dir = _make_backup(
            tmp_path,
            runs={
                "run1": {
                    "meta": {"name": "Test Run", "active": False, "description": "desc"},
                    "attrs": {"hparams": {"lr": 0.01}, "custom": "val"},
                    "traces": [
                        {"context_id": 0, "name": "loss", "dtype": "float", "last": 0.5, "last_step": 1},
                    ],
                    "contexts": {"0": {}},
                    "sequences": [
                        {"ctx_id": 0, "name": "loss", "step": 0, "value": 1.0},
                        {"ctx_id": 0, "name": "loss", "step": 1, "value": 0.5},
                    ],
                },
            },
        )

        result = restore_reingest(str(backup_dir))

        assert result.runs_processed == 1
        assert result.sequence_records_sent == 2
        assert result.errors == []

        mock_http.clear_run_tombstone.assert_called_once_with("run1")
        mock_ws.send_create_run.assert_called_once_with(force_resume=True)
        mock_ws.send_set_run_property.assert_any_call(name="Test Run", description="desc")
        mock_ws.send_log_hparams.assert_any_call({"hparams": {"lr": 0.01}})
        mock_ws.send_log_hparams.assert_any_call({"custom": "val"})
        assert mock_ws.send_log_metric.call_count == 2
        mock_ws.send_finish_run.assert_called_once()

    @patch("matyan_client.restore.WsTransport")
    @patch("matyan_client.restore.HttpTransport")
    def test_active_run_no_finish(
        self,
        mock_http_cls: MagicMock,
        mock_ws_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_http = MagicMock()
        mock_http.close = MagicMock()
        mock_http_cls.return_value = mock_http

        mock_ws = MagicMock()
        mock_ws.wait_for_flush = MagicMock()
        mock_ws.close = MagicMock()
        mock_ws_cls.return_value = mock_ws

        backup_dir = _make_backup(
            tmp_path,
            runs={"run2": {"meta": {"name": "Active", "active": True}}},
        )

        result = restore_reingest(str(backup_dir))
        assert result.runs_processed == 1
        mock_ws.send_finish_run.assert_not_called()


class TestRestoreEntities:
    @patch("matyan_client.restore.WsTransport")
    @patch("matyan_client.restore.HttpTransport")
    def test_entities_created_via_http(
        self,
        mock_http_cls: MagicMock,
        mock_ws_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_http = MagicMock()
        mock_http.close = MagicMock()
        mock_http_cls.return_value = mock_http

        mock_ws = MagicMock()
        mock_ws.wait_for_flush = MagicMock()
        mock_ws.close = MagicMock()
        mock_ws_cls.return_value = mock_ws

        backup_dir = _make_backup(
            tmp_path,
            runs={"r1": {}},
            entities=[
                {"entity_type": "experiment", "data": {"name": "exp1"}},
                {"entity_type": "tag", "data": {"name": "tag1", "color": "red"}},
            ],
        )

        result = restore_reingest(str(backup_dir))
        assert result.entities_processed == 2
        mock_http.create_experiment.assert_called_once_with("exp1")
        mock_http.create_tag.assert_called_once_with("tag1", color="red", description=None)


class TestRestoreLogTypes:
    @patch("matyan_client.restore.WsTransport")
    @patch("matyan_client.restore.HttpTransport")
    def test_log_terminal_line(
        self,
        mock_http_cls: MagicMock,
        mock_ws_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_http = MagicMock()
        mock_http.close = MagicMock()
        mock_http_cls.return_value = mock_http

        mock_ws = MagicMock()
        mock_ws.wait_for_flush = MagicMock()
        mock_ws.close = MagicMock()
        mock_ws_cls.return_value = mock_ws

        backup_dir = _make_backup(
            tmp_path,
            runs={
                "r1": {
                    "traces": [{"context_id": 0, "name": "logs", "dtype": "logs", "last": 0, "last_step": 0}],
                    "sequences": [{"ctx_id": 0, "name": "logs", "step": 0, "value": "hello world"}],
                },
            },
        )

        result = restore_reingest(str(backup_dir))
        assert result.sequence_records_sent == 1
        mock_ws.send_log_terminal_line.assert_called_once_with("hello world", 0)

    @patch("matyan_client.restore.WsTransport")
    @patch("matyan_client.restore.HttpTransport")
    def test_custom_object(
        self,
        mock_http_cls: MagicMock,
        mock_ws_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_http = MagicMock()
        mock_http.close = MagicMock()
        mock_http_cls.return_value = mock_http

        mock_ws = MagicMock()
        mock_ws.wait_for_flush = MagicMock()
        mock_ws.close = MagicMock()
        mock_ws_cls.return_value = mock_ws

        img_val = {"type": "image", "format": "png", "width": 10, "height": 10}
        backup_dir = _make_backup(
            tmp_path,
            runs={
                "r1": {
                    "traces": [{"context_id": 0, "name": "imgs", "dtype": "images", "last": None, "last_step": 0}],
                    "contexts": {"0": {"subset": "train"}},
                    "sequences": [{"ctx_id": 0, "name": "imgs", "step": 0, "value": img_val}],
                },
            },
        )

        result = restore_reingest(str(backup_dir))
        assert result.sequence_records_sent == 1
        mock_ws.send_log_custom_object.assert_called_once_with(
            name="imgs",
            value=img_val,
            step=0,
            epoch=None,
            context={"subset": "train"},
            dtype="images",
        )


class TestRestoreWithBlobs:
    @patch("matyan_client.restore.httpx.put")
    @patch("matyan_client.restore.WsTransport")
    @patch("matyan_client.restore.HttpTransport")
    def test_restore_uploads_blobs(
        self,
        mock_http_cls: MagicMock,
        mock_ws_cls: MagicMock,
        mock_httpx_put: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_http = MagicMock()
        mock_http.close = MagicMock()
        mock_http.presign_artifact.return_value = {
            "upload_url": "http://s3/presigned",
            "s3_key": "r1/my_image.png",
        }
        mock_http_cls.return_value = mock_http

        mock_ws = MagicMock()
        mock_ws.wait_for_flush = MagicMock()
        mock_ws.close = MagicMock()
        mock_ws_cls.return_value = mock_ws

        backup_dir = _make_backup(
            tmp_path,
            runs={
                "r1": {
                    "meta": {"name": "Blob Run", "active": False},
                    "traces": [{"context_id": 0, "name": "loss", "dtype": "float", "last": 0.5, "last_step": 0}],
                    "sequences": [{"ctx_id": 0, "name": "loss", "step": 0, "value": 0.5}],
                    "blobs": {
                        "my_image.png": b"\x89PNG-test-blob-content",
                    },
                },
            },
        )

        result = restore_reingest(str(backup_dir))
        assert result.runs_processed == 1
        assert result.blobs_uploaded == 1
        mock_http.presign_artifact.assert_called_once()
        mock_httpx_put.assert_called_once()
        mock_ws.send_blob_ref.assert_called_once()

    @patch("matyan_client.restore.WsTransport")
    @patch("matyan_client.restore.HttpTransport")
    def test_restore_skip_blobs(
        self,
        mock_http_cls: MagicMock,
        mock_ws_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_http = MagicMock()
        mock_http.close = MagicMock()
        mock_http_cls.return_value = mock_http

        mock_ws = MagicMock()
        mock_ws.wait_for_flush = MagicMock()
        mock_ws.close = MagicMock()
        mock_ws_cls.return_value = mock_ws

        backup_dir = _make_backup(
            tmp_path,
            runs={
                "r1": {
                    "blobs": {"file.bin": b"\x00\x01"},
                },
            },
        )

        result = restore_reingest(str(backup_dir), skip_blobs=True)
        assert result.blobs_uploaded == 0
        mock_http.presign_artifact.assert_not_called()

    def test_dry_run_counts_blobs(self, tmp_path: Path) -> None:
        backup_dir = _make_backup(
            tmp_path,
            runs={
                "r1": {
                    "sequences": [{"ctx_id": 0, "name": "loss", "step": 0, "value": 1.0}],
                    "blobs": {
                        "a.bin": b"aaa",
                        "b.bin": b"bbb",
                    },
                },
            },
        )

        result = restore_reingest(str(backup_dir), dry_run=True)
        assert result.runs_processed == 1
        assert result.blobs_uploaded == 2
        assert result.sequence_records_sent == 1
