"""Tests for matyan_client.objects.Figure."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import plotly.graph_objects as go
import pytest

from matyan_client.objects.figure import Figure


class TestFigure:
    def test_from_dict(self) -> None:
        fig = Figure({"data": [], "layout": {}})
        assert fig.data == {"data": [], "layout": {}}

    def test_json(self) -> None:
        fig = Figure({"x": 1})
        j = fig.json()
        assert j == {"type": "figure", "data": {"x": 1}}

    def test_repr(self) -> None:
        fig = Figure({"a": 1, "b": 2})
        assert "Figure" in repr(fig)

    def test_from_plotly_figure(self) -> None:
        plotly_fig = go.Figure(data=[go.Scatter(x=[1, 2], y=[3, 4])])
        fig = Figure(plotly_fig)
        assert "data" in fig.data

    def test_from_matplotlib_via_plotly(self) -> None:
        mock_mpl_fig = MagicMock()
        mock_mpl_fig.savefig = MagicMock()

        mock_plotly_fig = MagicMock()
        mock_plotly_fig.to_json.return_value = '{"data": [1]}'

        with patch("plotly.tools.mpl_to_plotly", return_value=mock_plotly_fig):
            fig = Figure(mock_mpl_fig)
            assert fig.data == {"data": [1]}

    def test_unsupported_type(self) -> None:
        with pytest.raises(TypeError, match="Unsupported figure type"):
            Figure(12345)

    def test_matplotlib_conversion_failure_and_no_dict(self) -> None:
        mock_mpl_fig = MagicMock()
        mock_mpl_fig.savefig = MagicMock()

        with (
            patch("plotly.tools.mpl_to_plotly", side_effect=ValueError("fail")),
            pytest.raises(TypeError, match="Unsupported figure type"),
        ):
            Figure(mock_mpl_fig)

    def test_matplotlib_conversion_failure_falls_back_to_dict(self) -> None:
        class DictLikeFig(dict):
            def savefig(self, *_a: Any, **_kw: Any) -> None:  # noqa: ANN401
                pass

        obj = DictLikeFig(data=[], layout={})
        with patch("plotly.tools.mpl_to_plotly", side_effect=TypeError("fail")):
            fig = Figure(obj)
            assert fig.data == {"data": [], "layout": {}}
