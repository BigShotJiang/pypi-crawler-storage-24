"""Tests for matyan_client.objects.Image."""

from __future__ import annotations

import base64
import builtins
from typing import TYPE_CHECKING, Any

import numpy as np
import PIL.Image as PILImage
import pytest

from matyan_client.objects.image import Image

if TYPE_CHECKING:
    from pathlib import Path


class TestImage:
    def test_from_bytes(self) -> None:
        raw = b"\x89PNG\r\n\x1a\nfakedata"
        img = Image(raw, caption="test")
        assert img.size == len(raw)
        assert img.caption == "test"
        assert img.width is None
        assert img.height is None

    def test_from_file_path_str(self, tmp_path: Path) -> None:
        p = tmp_path / "test.png"
        p.write_bytes(b"fakeimage")
        img = Image(str(p))
        assert img.size == 9

    def test_from_file_path_pathlib(self, tmp_path: Path) -> None:
        p = tmp_path / "test.png"
        p.write_bytes(b"fakeimage")
        img = Image(p)
        assert img.size == 9

    def test_from_pil_image(self) -> None:
        pil = PILImage.new("RGB", (10, 20), color="red")
        img = Image(pil, format_="PNG")
        assert img.width == 10
        assert img.height == 20
        assert img.size > 0
        assert img.format == "PNG"

    def test_from_numpy_array(self) -> None:
        arr = np.zeros((8, 16, 3), dtype=np.uint8)
        img = Image(arr)
        assert img.width == 16
        assert img.height == 8
        assert img.size > 0

    def test_unsupported_type(self) -> None:
        with pytest.raises(TypeError, match="Unsupported image type"):
            Image(12345)  # ty:ignore[invalid-argument-type]

    def test_numpy_without_pil(self, monkeypatch: pytest.MonkeyPatch) -> None:

        real_import = builtins.__import__

        def _no_pil(name: str, *args: Any, **kwargs: Any) -> Any:  # noqa: ANN401
            if name == "PIL.Image":
                msg = "no PIL"
                raise ImportError(msg)
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", _no_pil)
        arr = np.zeros((4, 4, 3), dtype=np.uint8)
        with pytest.raises(ImportError, match="Pillow is required"):
            Image(arr)

    def test_json(self) -> None:
        raw = b"hello"
        img = Image(raw, caption="cap", format_="JPEG")
        j = img.json()
        assert j["type"] == "image"
        assert j["format"] == "JPEG"
        assert j["caption"] == "cap"
        assert base64.b64decode(j["data"]) == raw

    def test_repr(self) -> None:
        img = Image(b"x", caption="c")
        r = repr(img)
        assert "Image" in r
        assert "size=1" in r

    def test_quality_and_optimize(self) -> None:
        pil = PILImage.new("RGB", (4, 4), color="blue")
        img_q50 = Image(pil, quality=50, optimize=True)
        img_q100 = Image(pil, quality=100, optimize=False)
        assert img_q50.size > 0
        assert img_q100.size > 0
