"""Platform adapters for automatic experiment tracking with popular ML frameworks.

Each adapter module contains a callback/logger class that plugs into the
framework's training loop and logs metrics, hyperparameters, and system
information to Matyan.

All framework dependencies are optional; importing a specific adapter will
raise ``RuntimeError`` with installation instructions if the framework is
missing.

Quick-start examples::

    # Keras
    from matyan_client.adapters.keras import MatyanCallback
    model.fit(..., callbacks=[MatyanCallback(experiment="my-exp")])

    # PyTorch Lightning
    from matyan_client.adapters.pytorch_lightning import MatyanLogger
    trainer = Trainer(logger=MatyanLogger(experiment="my-exp"))

    # Hugging Face Transformers
    from matyan_client.adapters.hugging_face import MatyanCallback
    trainer = Trainer(..., callbacks=[MatyanCallback(experiment="my-exp")])
"""
