"""Synchronous HTTP transport for backend REST API calls."""

from __future__ import annotations

import struct
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any

import httpx
from loguru import logger

if TYPE_CHECKING:
    from collections.abc import Iterator


class HttpTransport:
    """Thin wrapper around ``httpx.Client`` pointed at the matyan-backend."""

    def __init__(self, base_url: str, timeout: float = 30.0) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def close(self) -> None:
        self._client.close()

    # ------------------------------------------------------------------
    # Generic helpers
    # ------------------------------------------------------------------

    def get(self, path: str, **params: Any) -> Any:  # noqa: ANN401
        resp = self._client.get(path, params=params)
        resp.raise_for_status()
        return resp.json()

    def put(self, path: str, json: dict | None = None) -> Any:  # noqa: ANN401
        resp = self._client.put(path, json=json or {})
        resp.raise_for_status()
        return resp.json()

    def post(self, path: str, json: dict | list | None = None) -> Any:  # noqa: ANN401
        resp = self._client.post(path, json=json or {})
        resp.raise_for_status()
        return resp.json()

    def post_no_content(self, path: str, json: dict | list | None = None) -> None:
        """POST that expects a 204 No Content response (no JSON body)."""
        resp = self._client.post(path, json=json)
        resp.raise_for_status()

    def delete(self, path: str) -> Any:  # noqa: ANN401
        resp = self._client.delete(path)
        resp.raise_for_status()
        return resp.json()

    def get_version(self) -> dict | None:
        """Fetch component version from the backend or frontier (same path).

        :returns: JSON with ``version`` and ``component`` (and optionally
            ``fdb_api_version`` for backend), or ``None`` if unreachable.
        """
        try:
            return self.get("/api/v1/rest/version/")
        except (httpx.HTTPError, httpx.TimeoutException):
            logger.debug("get_version failed", exc_info=True)
            return None

    @contextmanager
    def get_stream(self, path: str, **params: Any) -> Iterator[httpx.Response]:  # noqa: ANN401
        with self._client.stream("GET", path, params=params) as resp:
            yield resp

    # ------------------------------------------------------------------
    # Run operations
    # ------------------------------------------------------------------

    def get_run_info(self, run_hash: str, sequence: tuple[str, ...] = ()) -> dict:
        params: dict[str, Any] = {}
        if sequence:
            params["sequence"] = list(sequence)
        return self.get(f"/api/v1/rest/runs/{run_hash}/info/", **params)

    def update_run(self, run_hash: str, **fields: Any) -> dict:  # noqa: ANN401
        return self.put(f"/api/v1/rest/runs/{run_hash}/", json=fields)

    def delete_run(self, run_hash: str) -> dict:
        return self.delete(f"/api/v1/rest/runs/{run_hash}/")

    def delete_runs_batch(self, run_hashes: list[str]) -> dict:
        return self.post("/api/v1/rest/runs/delete-batch/", json=run_hashes)

    def clear_run_tombstone(self, run_hash: str) -> None:
        self.post_no_content(f"/api/v1/rest/runs/{run_hash}/clear-tombstone/")

    def add_tag_to_run(self, run_hash: str, tag_name: str) -> dict:
        return self.post(f"/api/v1/rest/runs/{run_hash}/tags/new/", json={"tag_name": tag_name})

    def remove_tag_from_run(self, run_hash: str, tag_id: str) -> dict:
        return self.delete(f"/api/v1/rest/runs/{run_hash}/tags/{tag_id}/")

    # ------------------------------------------------------------------
    # Run logs / log records
    # ------------------------------------------------------------------

    def get_run_logs(self, run_id: str, record_range: str = "") -> list[tuple[int, Any]]:
        """Fetch terminal log lines for a run.

        :param run_id: Run hash.
        :param record_range: Optional ``start:stop`` range string.
        :returns: List of ``(step, value)`` tuples.
        """
        params: dict[str, Any] = {}
        if record_range:
            params["record_range"] = record_range
        try:
            resp = self._client.get(f"/api/v1/rest/runs/{run_id}/logs/", params=params, timeout=120)
            resp.raise_for_status()
            return _decode_streaming_kv_pairs(resp.content)
        except (httpx.HTTPError, struct.error, UnicodeDecodeError):
            logger.exception("get_run_logs failed for {}", run_id)
            return []

    def get_run_log_records(self, run_id: str, record_range: str = "") -> tuple[int, list[tuple[int, Any]]]:
        """Fetch structured log records for a run.

        :param run_id: Run hash.
        :param record_range: Optional ``start:stop`` range string.
        :returns: ``(total_count, [(step, value), ...])`` where *total_count*
            is the full record count reported by the backend.
        """
        params: dict[str, Any] = {}
        if record_range:
            params["record_range"] = record_range
        try:
            resp = self._client.get(f"/api/v1/rest/runs/{run_id}/log-records/", params=params, timeout=120)
            resp.raise_for_status()
            return _decode_log_records_response(resp.content)
        except (httpx.HTTPError, struct.error, UnicodeDecodeError):
            logger.exception("get_run_log_records failed for {}", run_id)
            return 0, []

    # ------------------------------------------------------------------
    # Metric get-batch
    # ------------------------------------------------------------------

    def get_run_metric_batch(
        self,
        run_id: str,
        traces: list[dict],
        record_range: str = "",
        record_density: int = 50,
    ) -> list[dict]:
        """Fetch metric series for specific traces of a single run.

        :param run_id: Run hash.
        :param traces: List of ``{"name": ..., "context": {...}}`` dicts.
        :param record_range: Optional step range (``"start,end"``).
        :param record_density: Maximum number of points per trace.
        :returns: List of ``{"name", "context", "iters", "values"}`` dicts.
        """
        params: dict[str, Any] = {"record_density": record_density}
        if record_range:
            params["record_range"] = record_range
        try:
            resp = self._client.post(
                f"/api/v1/rest/runs/{run_id}/metric/get-batch/",
                json=traces,
                params=params,
                timeout=120,
            )
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError:
            logger.exception("get_run_metric_batch failed for {}", run_id)
            return []

    # ------------------------------------------------------------------
    # Blob batch (custom objects: images, audios, …)
    # ------------------------------------------------------------------

    def get_blob_batch(self, seq_type: str, blob_uris: list[str]) -> dict[str, bytes]:
        """Download blob data for a batch of encrypted blob URIs.

        :param seq_type: Sequence type plural (``images``, ``audios``, etc.).
        :param blob_uris: List of encrypted blob URI strings.
        :returns: Mapping from URI to raw blob bytes. URIs that the backend
            could not resolve are silently omitted.
        """
        if not blob_uris:
            return {}
        try:
            resp = self._client.post(
                f"/api/v1/rest/runs/{seq_type}/get-batch/",
                json=blob_uris,
                timeout=120,
            )
            resp.raise_for_status()
            return _decode_blob_batch_response(resp.content)
        except (httpx.HTTPError, struct.error, UnicodeDecodeError):
            logger.exception("get_blob_batch failed for {}", seq_type)
            return {}

    # ------------------------------------------------------------------
    # Search / query (streaming endpoints)
    # ------------------------------------------------------------------

    def search_runs(self, query: str = "", limit: int | None = None, offset: str | None = None) -> list[dict]:
        """Call the run search endpoint and collect decoded results.

        The backend returns a streaming binary-encoded response.  For the
        client SDK we use a simplified approach: call the endpoint and let
        httpx buffer the full response.
        """
        params: dict[str, Any] = {"q": query}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        try:
            resp = self._client.get("/api/v1/rest/runs/search/run/", params=params, timeout=120)
            resp.raise_for_status()
            return _decode_streaming_response(resp.content)
        except (httpx.HTTPError, struct.error, UnicodeDecodeError):
            logger.exception("search_runs failed")
            return []

    def search_metrics(self, query: str = "", **params: Any) -> list[dict]:  # noqa: ANN401
        return self.search_sequence("metric", query=query, **params)

    def search_sequence(self, seq_type: str, query: str = "", **params: Any) -> list[dict]:  # noqa: ANN401
        params["q"] = query
        try:
            resp = self._client.get(f"/api/v1/rest/runs/search/{seq_type}/", params=params, timeout=120)
            resp.raise_for_status()
            return _decode_streaming_response(resp.content)
        except (httpx.HTTPError, struct.error, UnicodeDecodeError):
            logger.exception("search_%s failed", seq_type)
            return []

    # ------------------------------------------------------------------
    # Experiments
    # ------------------------------------------------------------------

    def list_experiments(self) -> list[dict]:
        return self.get("/api/v1/rest/experiments/")

    def create_experiment(self, name: str) -> dict:
        return self.post("/api/v1/rest/experiments/", json={"name": name})

    def delete_experiment(self, uuid: str) -> dict:
        return self.delete(f"/api/v1/rest/experiments/{uuid}/")

    # ------------------------------------------------------------------
    # Tags
    # ------------------------------------------------------------------

    def list_tags(self) -> list[dict]:
        return self.get("/api/v1/rest/tags/")

    def create_tag(self, name: str, *, color: str | None = None, description: str | None = None) -> dict:
        payload: dict[str, Any] = {"name": name}
        if color is not None:
            payload["color"] = color
        if description is not None:
            payload["description"] = description
        return self.post("/api/v1/rest/tags/", json=payload)

    # ------------------------------------------------------------------
    # Project
    # ------------------------------------------------------------------

    def get_project_info(self) -> dict:
        return self.get("/api/v1/rest/projects/")

    # ------------------------------------------------------------------
    # Presigned URLs (frontier REST)
    # ------------------------------------------------------------------

    def presign_artifact(
        self,
        frontier_url: str,
        run_id: str,
        artifact_path: str,
        content_type: str = "application/octet-stream",
    ) -> dict:
        """Request a presigned S3 upload URL from the frontier (URL generation only).

        The client must send blob_ref over WebSocket after a successful upload
        to notify the backend.
        """
        resp = httpx.post(
            f"{frontier_url}/api/v1/rest/artifacts/presign",
            json={"run_id": run_id, "artifact_path": artifact_path, "content_type": content_type},
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()


def _decode_streaming_response(content: bytes) -> list[dict]:
    """Decode the backend's Aim binary streaming format into Python dicts.

    Wire format (repeating):
        [4-byte LE key_len][key_bytes][4-byte LE val_len][val_bytes]

    Path encoding:  keys separated by 0xFE sentinel.
        - String key: UTF-8 bytes terminated by 0xFE
        - Integer key: 0xFE + 8-byte BE int64 + 0xFE

    Value encoding: 1-byte type prefix + payload.
        0=None  1=Bool(1B)  2=Int(LE i64)  3=Float(LE f64)
        4=String(UTF-8)  5=Bytes  6=ArrayFlag  7=ObjectFlag
    """
    if not content:
        return []

    flat: list[tuple[list[str | int], object]] = []
    pos = 0
    size = len(content)

    while pos + 8 <= size:
        key_len = _unpack_le_i(content, pos)
        pos += 4
        if pos + key_len + 4 > size:
            break
        raw_key = content[pos : pos + key_len]
        pos += key_len

        val_len = _unpack_le_i(content, pos)
        pos += 4
        if pos + val_len > size:
            break
        raw_val = content[pos : pos + val_len]
        pos += val_len

        path = _decode_path(raw_key)
        value = _decode_value(raw_val)
        flat.append((path, value))

    return _fold_tree(flat)


_SENTINEL = 0xFE
_STRUCT_LE_I = struct.Struct("<I")
_STRUCT_LE_Q = struct.Struct("<q")
_STRUCT_LE_D = struct.Struct("<d")
_STRUCT_BE_Q = struct.Struct(">q")

_TYPE_NONE = 0
_TYPE_BOOL = 1
_TYPE_INT = 2
_TYPE_FLOAT = 3
_TYPE_STRING = 4
_TYPE_BYTES = 5
_TYPE_ARRAY = 6
_TYPE_OBJECT = 7


def _unpack_le_i(buf: bytes, offset: int) -> int:
    return _STRUCT_LE_I.unpack_from(buf, offset)[0]


def _decode_path(raw: bytes) -> list[str | int]:
    """Decode a 0xFE-delimited path back into a list of string/int keys."""
    parts: list[str | int] = []
    i = 0
    length = len(raw)
    while i < length:
        if raw[i] == _SENTINEL:
            if i + 9 <= length and raw[i + 1] != _SENTINEL:
                int_val = _STRUCT_BE_Q.unpack_from(raw, i + 1)[0]
                parts.append(int_val)
                i += 9
                if i < length and raw[i] == _SENTINEL:
                    i += 1
            else:
                i += 1
        else:
            try:
                end = raw.index(_SENTINEL, i)
            except ValueError:
                end = length
            parts.append(raw[i:end].decode("utf-8", errors="replace"))
            i = end + 1
    return parts


_SKIP = object()


def _decode_value(raw: bytes) -> object:  # noqa: PLR0911
    """Decode a type-prefixed value.

    Returns ``_SKIP`` for structural markers (ArrayFlag/ObjectFlag) that
    don't carry data and should not be inserted into the result tree.
    """
    if not raw:
        return _SKIP
    tag = raw[0]
    payload = raw[1:]
    if tag == _TYPE_NONE:
        return None
    if tag == _TYPE_BOOL:
        return bool(payload[0]) if payload else False
    if tag == _TYPE_INT:
        return _STRUCT_LE_Q.unpack(payload[:8])[0] if len(payload) >= 8 else 0
    if tag == _TYPE_FLOAT:
        return _STRUCT_LE_D.unpack(payload[:8])[0] if len(payload) >= 8 else 0.0
    if tag == _TYPE_STRING:
        return payload.decode("utf-8", errors="replace")
    if tag == _TYPE_BYTES:
        return payload
    if tag in (_TYPE_ARRAY, _TYPE_OBJECT):
        return _SKIP
    return _SKIP


def _set_nested(root: dict, path: list[str | int], value: object) -> None:
    """Set a value in a nested dict tree, creating intermediate dicts."""
    node: Any = root
    for key in path[:-1]:
        if isinstance(node, dict):
            if key not in node:
                node[key] = {}
            node = node[key]
        else:
            return
    if isinstance(node, dict) and path:
        node[path[-1]] = value


def _fold_tree(flat: list[tuple[list[str | int], object]]) -> list[dict]:
    """Reassemble flattened (path, value) pairs into nested dicts.

    The top-level key is usually the run hash; each top-level key becomes
    one dict in the returned list.
    """
    root: dict = {}
    for path, value in flat:
        if not path:
            continue
        if isinstance(path[0], str) and path[0].startswith("progress_"):
            continue
        if value is not _SKIP:
            _set_nested(root, path, value)

    results: list[dict] = []
    for key, val in root.items():
        if isinstance(val, dict):
            val["hash"] = key
            results.append(val)
        else:
            results.append({"hash": key, "data": val})
    return results


# ---------------------------------------------------------------------------
# Decoders for per-run streaming endpoints (logs, log records, blob batch)
# ---------------------------------------------------------------------------


def _decode_flat_pairs(content: bytes) -> list[tuple[list[str | int], object]]:
    """Low-level decoder: extract ``(path, value)`` pairs from Aim binary stream."""
    if not content:
        return []
    pairs: list[tuple[list[str | int], object]] = []
    pos = 0
    size = len(content)
    while pos + 8 <= size:
        key_len = _unpack_le_i(content, pos)
        pos += 4
        if pos + key_len + 4 > size:
            break
        raw_key = content[pos : pos + key_len]
        pos += key_len
        val_len = _unpack_le_i(content, pos)
        pos += 4
        if pos + val_len > size:
            break
        raw_val = content[pos : pos + val_len]
        pos += val_len
        path = _decode_path(raw_key)
        value = _decode_value(raw_val)
        if value is not _SKIP:
            pairs.append((path, value))
    return pairs


def _decode_streaming_kv_pairs(content: bytes) -> list[tuple[int, Any]]:
    """Decode a streaming response of ``{step: value}`` trees into (step, value) pairs.

    Used by the run-logs endpoint where each streamed chunk is a single
    ``{<step>: <line>}`` tree.
    """
    result: list[tuple[int, Any]] = []
    for path, value in _decode_flat_pairs(content):
        if len(path) == 1 and isinstance(path[0], int):
            result.append((path[0], value))
    return result


def _decode_log_records_response(content: bytes) -> tuple[int, list[tuple[int, Any]]]:
    """Decode the log-records streaming response.

    The first tree contains ``log_records_count``; subsequent trees are
    ``{step: value}`` pairs.
    """
    total_count = 0
    records: list[tuple[int, Any]] = []
    for path, value in _decode_flat_pairs(content):
        if len(path) == 1 and path[0] == "log_records_count" and isinstance(value, int):
            total_count = value
        elif len(path) == 1 and isinstance(path[0], int):
            records.append((path[0], value))
        elif len(path) >= 2 and isinstance(path[0], int):
            root: dict = {}
            _set_nested(root, list(path), value)
            key = path[0]
            existing = next((v for s, v in records if s == key), None)
            if existing is not None and isinstance(existing, dict):
                existing.update(root.get(key, {}))
            else:
                records.append((key, root.get(key, value)))
    return total_count, records


def _decode_blob_batch_response(content: bytes) -> dict[str, bytes]:
    """Decode the blob-batch streaming response into ``{uri: blob_bytes}``."""
    blobs: dict[str, bytes] = {}
    for path, value in _decode_flat_pairs(content):
        if len(path) == 1 and isinstance(path[0], str) and isinstance(value, bytes):
            blobs[path[0]] = value
    return blobs
