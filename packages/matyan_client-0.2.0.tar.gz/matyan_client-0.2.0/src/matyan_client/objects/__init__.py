"""Custom object types for tracking with :class:`~matyan_client.run.Run`.

This package provides wrapper types that can be passed to :meth:`Run.track`:
:class:`Image`, :class:`Audio`, :class:`Text`, :class:`Distribution`, and
:class:`Figure`. Each exposes a :meth:`json` method used for serialization
and (for images/audio) optional blob upload to S3.
"""

from .audio import Audio
from .distribution import Distribution
from .figure import Figure
from .image import Image
from .text import Text

__all__ = ["Audio", "Distribution", "Figure", "Image", "Text"]
