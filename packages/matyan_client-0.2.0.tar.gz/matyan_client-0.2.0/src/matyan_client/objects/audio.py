"""Audio custom object for tracking with :meth:`Run.track`."""

from __future__ import annotations

import base64
import io
import struct
from pathlib import Path
from typing import TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:
    from types import ModuleType

    import numpy as np

    AudioInput = bytes | str | Path | io.IOBase | np.ndarray


class Audio:
    """A tracked audio value for use with :meth:`Run.track`.

    Accepts file path, raw bytes, I/O stream, or numpy array (converted to WAV).
    For numpy arrays, samples are normalized to 16-bit PCM if needed.

    :param data: Audio source: path (str or Path), bytes, file-like, or 1D/2D numpy array.
    :param format_: File format (e.g. ``wav``, ``mp3``); inferred from path if omitted.
    :param caption: Optional caption for the UI.
    :param rate: Sample rate in Hz; used when encoding numpy arrays (default 22050).

    Usage::

        run.track(Audio("recording.wav", caption="sample"), name="audio", step=0)
    """

    def __init__(
        self,
        data: AudioInput,
        format_: str = "",
        caption: str = "",
        rate: int | None = None,
    ) -> None:
        self._caption = caption
        self._rate = rate
        self._format = format_
        self._data_bytes = self._encode(data)

    def _encode(self, data: AudioInput) -> bytes:
        """Convert the input to raw bytes (file/bytes/stream → read; numpy → WAV)."""
        if isinstance(data, bytes):
            return data

        if isinstance(data, (str, Path)):
            p = Path(data)
            if not self._format:
                self._format = p.suffix.lstrip(".")
            return p.read_bytes()

        if isinstance(data, io.IOBase):
            return data.read()

        np: ModuleType | None = None

        try:
            import numpy as np  # noqa: PLC0415
        except ImportError:
            logger.debug("numpy unavailable; audio tracking disabled")

        if np is not None and isinstance(data, np.ndarray):
            return self._numpy_to_wav(data)

        msg = f"Unsupported audio type: {type(data).__name__}"
        raise TypeError(msg)

    def _numpy_to_wav(self, arr: np.ndarray) -> bytes:
        """Encode a numpy array as 16-bit PCM WAV in a bytes buffer."""
        import numpy as np  # noqa: PLC0415

        self._format = "wav"
        rate = self._rate or 22050
        if arr.dtype != np.int16:
            peak = np.abs(arr).max()
            arr = (arr / peak * 32767).astype(np.int16) if peak > 0 else arr.astype(np.int16)

        buf = io.BytesIO()
        num_channels = 1 if arr.ndim == 1 else arr.shape[1]
        data_bytes = arr.tobytes()
        byte_rate = rate * num_channels * 2
        block_align = num_channels * 2
        data_size = len(data_bytes)

        buf.write(b"RIFF")
        buf.write(struct.pack("<I", 36 + data_size))
        buf.write(b"WAVE")
        buf.write(b"fmt ")
        buf.write(struct.pack("<IHHIIHH", 16, 1, num_channels, rate, byte_rate, block_align, 16))
        buf.write(b"data")
        buf.write(struct.pack("<I", data_size))
        buf.write(data_bytes)
        return buf.getvalue()

    @property
    def caption(self) -> str:
        """Optional caption for the audio in the UI."""
        return self._caption

    @property
    def format(self) -> str:
        """Audio format (e.g. ``wav``, ``mp3``)."""
        return self._format

    def json(self) -> dict:
        """Return a dict suitable for serialization (type, base64 data, format, caption, rate)."""
        return {
            "type": "audio",
            "data": base64.b64encode(self._data_bytes).decode(),
            "format": self._format,
            "caption": self._caption,
            "rate": self._rate,
        }

    def __repr__(self) -> str:
        return f"Audio(format={self._format!r}, size={len(self._data_bytes)}, caption={self._caption!r})"
