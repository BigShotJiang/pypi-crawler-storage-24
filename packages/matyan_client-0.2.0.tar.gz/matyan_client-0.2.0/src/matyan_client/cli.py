import importlib.metadata

import click


@click.group()
def main() -> None:
    """Matyan client CLI."""


def _get_client_version() -> str:
    """Return the installed matyan-client package version."""
    try:
        return importlib.metadata.version("matyan-client")
    except importlib.metadata.PackageNotFoundError:
        return "0.0.0.dev0"


@main.command(name="status")
@click.option("--backend-url", default=None, help="Backend URL (default from MATYAN_BACKEND_URL)")
@click.option("--frontier-url", default=None, help="Frontier URL (default from MATYAN_FRONTIER_URL); if set, show frontier row")
def status_cmd(backend_url: str | None, frontier_url: str | None) -> None:
    """Show component versions (backend, optional frontier, client) in a Cilium-style table."""
    from matyan_client.config import SETTINGS  # noqa: PLC0415
    from matyan_client.transport.http import HttpTransport  # noqa: PLC0415

    _backend_url = backend_url or SETTINGS.backend_url
    _frontier_url = frontier_url or SETTINGS.frontier_url

    backend_http = HttpTransport(_backend_url, timeout=5.0)
    backend_info = backend_http.get_version()
    backend_http.close()

    frontier_info: dict | None = None
    if _frontier_url:
        frontier_http = HttpTransport(_frontier_url, timeout=5.0)
        frontier_info = frontier_http.get_version()
        frontier_http.close()

    click.echo("Matyan components")
    status_ok = "OK"
    status_unreachable = "unreachable"
    status_local = "(local)"

    if backend_info:
        click.echo(f"  Backend    {status_ok:<12} {backend_info.get('version', '-')}")
    else:
        click.echo(f"  Backend    {status_unreachable:<12} -")

    if _frontier_url:
        if frontier_info:
            click.echo(f"  Frontier   {status_ok:<12} {frontier_info.get('version', '-')}")
        else:
            click.echo(f"  Frontier   {status_unreachable:<12} -")

    click.echo(f"  Client     {status_local:<12} {_get_client_version()}")


@main.command(name="restore-reingest")
@click.argument("backup_path")
@click.option("--backend-url", default=None, help="Backend URL (default from MATYAN_BACKEND_URL)")
@click.option("--frontier-url", default=None, help="Frontier URL (default from MATYAN_FRONTIER_URL)")
@click.option("--skip-entities", is_flag=True, default=False, help="Skip restoring experiments/tags")
@click.option("--skip-blobs", is_flag=True, default=False, help="Skip uploading blobs to S3")
@click.option("--dry-run", is_flag=True, default=False, help="Validate backup and report; do not write")
def restore_reingest_cmd(
    backup_path: str,
    backend_url: str | None,
    frontier_url: str | None,
    skip_entities: bool,
    skip_blobs: bool,
    dry_run: bool,
) -> None:
    """Restore a backup archive by replaying through the ingestion pipeline."""
    from matyan_client.restore import restore_reingest  # noqa: PLC0415

    result = restore_reingest(
        backup_path,
        backend_url=backend_url,
        frontier_url=frontier_url,
        skip_entities=skip_entities,
        skip_blobs=skip_blobs,
        dry_run=dry_run,
    )

    if dry_run:
        click.echo(
            f"[dry-run] Would restore: {result.runs_processed} run(s), "
            f"{result.entities_processed} entity/ies, "
            f"{result.sequence_records_sent} sequence record(s), "
            f"{result.blobs_uploaded} blob(s)",
        )
    else:
        click.echo(
            f"Restored: {result.runs_processed} run(s), "
            f"{result.entities_processed} entity/ies, "
            f"{result.sequence_records_sent} sequence record(s), "
            f"{result.blobs_uploaded} blob(s)",
        )
        if result.errors:
            click.echo(f"Errors ({len(result.errors)}):")
            for err in result.errors:
                click.echo(f"  - {err}")


@main.command(name="backup")
@click.argument("output_path")
@click.option("--backend-url", default=None, help="Backend URL (default from MATYAN_BACKEND_URL)")
@click.option("--runs", default=None, help="Comma-separated run hashes to back up")
@click.option("--experiment", default=None, help="Back up all runs in this experiment")
@click.option("--since", default=None, help="Back up runs created after this ISO datetime")
@click.option("--no-blobs", is_flag=True, default=False, help="Skip downloading blobs")
@click.option("--compress", is_flag=True, default=False, help="Produce .tar.gz archive")
def backup_cmd(
    output_path: str,
    backend_url: str | None,
    runs: str | None,
    experiment: str | None,
    since: str | None,
    no_blobs: bool,
    compress: bool,
) -> None:
    """Create a backup via the backend REST API (no FDB access needed)."""
    from matyan_client.backup import run_backup  # noqa: PLC0415

    run_hashes = [h.strip() for h in runs.split(",") if h.strip()] if runs else None

    result = run_backup(
        output_path,
        backend_url=backend_url,
        run_hashes=run_hashes,
        experiment=experiment,
        since=since,
        include_blobs=not no_blobs,
        compress=compress,
    )

    if result.backup_path:
        click.echo(f"Backup location: {result.backup_path}")


@main.group()
def convert() -> None:
    """Convert logs from other experiment trackers to Matyan backup format."""


@convert.command()
@click.argument("input_dir")
@click.argument("output_path")
@click.option("--experiment", default=None, help="Assign all converted runs to this experiment")
@click.option("--compress", is_flag=True, default=False, help="Produce .tar.gz archive")
@click.option("--workers", default=None, type=int, help="Parallel workers (default: CPU count)")
def tensorboard(input_dir: str, output_path: str, experiment: str | None, compress: bool, workers: int | None) -> None:
    """Convert TensorBoard event logs to a Matyan backup archive."""
    from matyan_client.convert.tensorboard import convert_tensorboard  # noqa: PLC0415

    convert_tensorboard(input_dir, output_path, experiment=experiment, compress=compress, workers=workers)


if __name__ == "__main__":
    main()
