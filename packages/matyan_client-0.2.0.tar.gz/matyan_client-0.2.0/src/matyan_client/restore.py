"""Restore a backup archive by replaying data through the normal client transport.

Reads a Matyan backup directory (manifest + per-run JSON/JSONL files) and
pushes the data to the backend via the REST API and frontier WebSocket, i.e.
the same path as live training.
"""

from __future__ import annotations

import json
import tarfile
import tempfile
from pathlib import Path
from typing import Any

import httpx
from loguru import logger
from matyan_api_models.backup import BackupManifest

from .config import SETTINGS
from .transport.http import HttpTransport
from .transport.ws import WsTransport

_NON_METRIC_DTYPES = frozenset(
    {
        "images",
        "texts",
        "distributions",
        "audios",
        "figures",
        "logs",
        "log_records",
    }
)
_LOG_DTYPES = frozenset({"logs", "log_records"})
_CUSTOM_OBJECT_DTYPES = frozenset({"images", "texts", "distributions", "audios", "figures"})


def _load_json(path: Path) -> Any:  # noqa: ANN401
    return json.loads(path.read_text())


def _resolve_backup_dir(backup_path: str) -> Path:
    path = Path(backup_path)
    if path.suffix == ".gz" or path.name.endswith(".tar.gz"):
        tmpdir = tempfile.mkdtemp()
        with tarfile.open(path, "r:gz") as tar:
            tar.extractall(tmpdir)  # noqa: S202
        extracted = [d for d in Path(tmpdir).iterdir() if d.is_dir()]
        if not extracted:
            msg = "Archive contains no directories"
            raise ValueError(msg)
        return extracted[0]
    return path


class RestoreResult:
    """Accumulates stats during restore."""

    def __init__(self) -> None:
        self.runs_processed: int = 0
        self.entities_processed: int = 0
        self.sequence_records_sent: int = 0
        self.blobs_uploaded: int = 0
        self.errors: list[str] = []


def restore_reingest(
    backup_path: str,
    *,
    backend_url: str | None = None,
    frontier_url: str | None = None,
    skip_entities: bool = False,
    skip_blobs: bool = False,
    dry_run: bool = False,
) -> RestoreResult:
    """Restore a backup by replaying through the client transport layer."""
    backup_dir = _resolve_backup_dir(backup_path)
    manifest = BackupManifest.read(backup_dir)
    errors = manifest.validate(backup_dir)
    if errors:
        msg = f"Backup validation failed: {'; '.join(errors)}"
        raise ValueError(msg)

    result = RestoreResult()
    _backend_url = backend_url or SETTINGS.backend_url
    _frontier_url = frontier_url or SETTINGS.frontier_url

    if dry_run:
        result.entities_processed = _count_entities(backup_dir) if not skip_entities else 0
        for rh in manifest.run_hashes:
            run_dir = backup_dir / "runs" / rh
            if run_dir.is_dir():
                result.runs_processed += 1
                result.sequence_records_sent += _count_sequence_records(run_dir)
                if not skip_blobs:
                    result.blobs_uploaded += _count_blobs(run_dir)
        return result

    http = HttpTransport(_backend_url)
    try:
        if not skip_entities:
            result.entities_processed = _restore_entities(http, backup_dir)

        for rh in manifest.run_hashes:
            run_dir = backup_dir / "runs" / rh
            if not run_dir.is_dir():
                result.errors.append(f"Run directory missing: {rh}")
                continue
            try:
                _restore_run(http, _frontier_url, rh, run_dir, skip_blobs=skip_blobs, result=result)
                result.runs_processed += 1
            except Exception:
                logger.exception("Failed to restore run {}", rh)
                result.errors.append(f"Failed to restore run: {rh}")
    finally:
        http.close()

    return result


def _count_entities(backup_dir: Path) -> int:
    entities_path = backup_dir / "entities.jsonl"
    if not entities_path.exists():
        return 0
    count = 0
    with entities_path.open() as f:
        for line in f:
            if line.strip():
                count += 1
    return count


def _count_sequence_records(run_dir: Path) -> int:
    seq_path = run_dir / "sequences.jsonl"
    if not seq_path.exists():
        return 0
    count = 0
    with seq_path.open() as f:
        for line in f:
            if line.strip():
                count += 1
    return count


def _count_blobs(run_dir: Path) -> int:
    blobs_dir = run_dir / "blobs"
    if not blobs_dir.exists():
        return 0
    return sum(1 for _ in blobs_dir.rglob("*") if _.is_file())


def _restore_entities(http: HttpTransport, backup_dir: Path) -> int:
    entities_path = backup_dir / "entities.jsonl"
    if not entities_path.exists():
        return 0

    count = 0
    with entities_path.open() as f:
        for raw_line in f:
            stripped = raw_line.strip()
            if not stripped:
                continue
            record = json.loads(stripped)
            etype = record["entity_type"]
            data = record["data"]
            try:
                _restore_entity(http, etype, data)
                count += 1
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code == 409:
                    logger.debug("Entity already exists: {} {}", etype, data.get("name", ""))
                    count += 1
                else:
                    logger.warning("Failed to restore entity {} {}: {}", etype, data.get("name", ""), exc)
    return count


def _restore_entity(http: HttpTransport, entity_type: str, data: dict) -> None:
    if entity_type == "experiment":
        http.create_experiment(data["name"])
    elif entity_type == "tag":
        http.create_tag(data["name"], color=data.get("color"), description=data.get("description"))
    elif entity_type in ("dashboard", "dashboard_app", "report", "note"):
        logger.debug("Skipping entity type {} (not supported via REST reingest)", entity_type)


def _restore_run(
    http: HttpTransport,
    frontier_url: str,
    run_hash: str,
    run_dir: Path,
    *,
    skip_blobs: bool,
    result: RestoreResult,
) -> None:
    meta = _load_json(run_dir / "run.json")
    attrs = _load_json(run_dir / "attrs.json")
    traces = _load_json(run_dir / "traces.json")
    contexts = _load_json(run_dir / "contexts.json")

    http.clear_run_tombstone(run_hash)

    ws = WsTransport(frontier_url, run_hash)
    try:
        ws.send_create_run(force_resume=True)

        _send_properties(ws, meta)
        _send_hparams(ws, attrs)

        if not skip_blobs:
            result.blobs_uploaded += _upload_blobs(http, ws, frontier_url, run_hash, run_dir)

        trace_map = {(t["context_id"], t["name"]): t for t in traces}
        result.sequence_records_sent += _send_sequences(ws, run_dir, trace_map, contexts)

        if not meta.get("active", True):
            ws.send_finish_run()

        ws.wait_for_flush(timeout=30.0)
    finally:
        ws.close()


def _send_properties(ws: WsTransport, meta: dict) -> None:
    kwargs: dict[str, Any] = {}
    if meta.get("name"):
        kwargs["name"] = meta["name"]
    if meta.get("description"):
        kwargs["description"] = meta["description"]
    if meta.get("is_archived"):
        kwargs["archived"] = meta["is_archived"]
    if kwargs:
        ws.send_set_run_property(**kwargs)

    exp_name = meta.get("experiment_name")
    if exp_name:
        ws.send_set_run_property(experiment=exp_name)


def _send_hparams(ws: WsTransport, attrs: dict) -> None:
    hparams = attrs.get("hparams")
    if hparams and isinstance(hparams, dict):
        ws.send_log_hparams({"hparams": hparams})

    for key, val in attrs.items():
        if key in ("hparams", "__blobs__"):
            continue
        ws.send_log_hparams({key: val})


def _upload_blobs(
    http: HttpTransport,
    ws: WsTransport,
    frontier_url: str,
    run_hash: str,
    run_dir: Path,
) -> int:
    blobs_dir = run_dir / "blobs"
    if not blobs_dir.exists():
        return 0

    count = 0
    for blob_path in blobs_dir.rglob("*"):
        if not blob_path.is_file():
            continue
        relative = blob_path.relative_to(blobs_dir)
        artifact_path = str(relative)
        s3_key = f"{run_hash}/{relative}"

        try:
            presign = http.presign_artifact(frontier_url, run_hash, artifact_path)
            upload_url = presign["upload_url"]
            data = blob_path.read_bytes()
            httpx.put(upload_url, content=data, timeout=60)
            ws.send_blob_ref(s3_key=s3_key, artifact_path=artifact_path)
            count += 1
        except Exception:
            logger.exception("Failed to upload blob {}", artifact_path)

    return count


def _send_sequences(
    ws: WsTransport,
    run_dir: Path,
    trace_map: dict[tuple[int, str], dict],
    contexts: dict[str, dict],
) -> int:
    seq_path = run_dir / "sequences.jsonl"
    if not seq_path.exists():
        return 0

    count = 0
    with seq_path.open() as f:
        for raw_line in f:
            stripped = raw_line.strip()
            if not stripped:
                continue
            rec = json.loads(stripped)
            ctx_id = rec["ctx_id"]
            name = rec["name"]
            trace = trace_map.get((ctx_id, name), {})
            dtype = trace.get("dtype", "float")
            ctx_dict = contexts.get(str(ctx_id), {})

            if dtype in _LOG_DTYPES:
                _send_log_record(ws, rec, dtype)
            elif dtype in _CUSTOM_OBJECT_DTYPES:
                ws.send_log_custom_object(
                    name=name,
                    value=rec["value"],
                    step=rec["step"],
                    epoch=rec.get("epoch"),
                    context=ctx_dict or None,
                    dtype=dtype,
                )
            else:
                ws.send_log_metric(
                    name=name,
                    value=rec["value"],
                    step=rec["step"],
                    epoch=rec.get("epoch"),
                    context=ctx_dict or None,
                    dtype=dtype,
                )
            count += 1

    return count


def _send_log_record(ws: WsTransport, rec: dict, dtype: str) -> None:
    value = rec["value"]
    if dtype == "logs":
        line = value if isinstance(value, str) else str(value)
        ws.send_log_terminal_line(line, rec["step"])
    elif isinstance(value, dict):
        ws.send_log_record(
            message=value.get("message", ""),
            level=_log_level_to_int(value.get("log_level", "INFO")),
            timestamp=value.get("timestamp", 0.0),
            logger_info=value.get("logger_info"),
            extra_args=value.get("args"),
        )
    else:
        ws.send_log_record(
            message=str(value),
            level=20,
            timestamp=0.0,
        )


_LOG_LEVELS = {"DEBUG": 10, "INFO": 20, "WARNING": 30, "ERROR": 40, "CRITICAL": 50}


def _log_level_to_int(level: str | int) -> int:
    if isinstance(level, int):
        return level
    return _LOG_LEVELS.get(str(level).upper(), 20)
