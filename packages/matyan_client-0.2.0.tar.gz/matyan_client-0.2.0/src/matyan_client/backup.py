"""Client-side backup: export runs via the backend REST API.

Produces the same directory layout as ``matyan-backend backup`` so the
archive can be consumed by either ``matyan-backend restore`` (direct) or
``matyan restore-reingest`` (client replay).

No FoundationDB or S3 access is required — all data is read through the
public HTTP API exposed by matyan-backend.
"""

from __future__ import annotations

import json
import shutil
import tarfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import click
from loguru import logger
from matyan_api_models.backup import BackupManifest
from matyan_api_models.context import context_to_id

from .config import SETTINGS
from .transport.http import HttpTransport

# Mapping from traces-overview bucket name to the dtype stored in traces.json
_BUCKET_TO_DTYPE: dict[str, str] = {
    "metric": "float",
    "images": "image",
    "texts": "text",
    "distributions": "distribution",
    "audios": "audio",
    "figures": "figure",
}

# Reverse: dtype → bucket name (search URL path)
_DTYPE_TO_BUCKET: dict[str, str] = {v: k for k, v in _BUCKET_TO_DTYPE.items()}

# Custom-object buckets that require blob download
_BLOB_BUCKETS = frozenset({"images", "audios"})

# All custom-object buckets (sequence search types)
_CUSTOM_BUCKETS = frozenset({"images", "texts", "distributions", "audios", "figures"})


@dataclass
class BackupResult:
    """Accumulated stats from a backup run."""

    backup_path: Path | None = None
    run_count: int = 0
    sequence_records: int = 0
    entity_counts: dict[str, int] = field(default_factory=dict)
    blob_count: int = 0
    blob_bytes: int = 0


# ---------------------------------------------------------------------------
# JSON helpers
# ---------------------------------------------------------------------------


def _json_default(obj: object) -> str:
    if isinstance(obj, bytes):
        return obj.hex()
    if isinstance(obj, datetime):
        return obj.isoformat()
    msg = f"Object of type {type(obj).__name__} is not JSON serializable"
    raise TypeError(msg)


def _dump_json(data: Any, path: Path) -> None:  # noqa: ANN401
    path.write_text(json.dumps(data, default=_json_default, ensure_ascii=False) + "\n")


# ---------------------------------------------------------------------------
# Entity export
# ---------------------------------------------------------------------------


def _export_entities(http: HttpTransport, backup_dir: Path) -> dict[str, int]:
    """Write ``entities.jsonl`` with experiments and tags."""
    counts: dict[str, int] = {}
    path = backup_dir / "entities.jsonl"
    with path.open("w") as f:
        experiments = http.list_experiments()
        counts["experiment"] = len(experiments)
        for exp in experiments:
            f.write(json.dumps({"entity_type": "experiment", "data": exp}, default=_json_default) + "\n")

        tags = http.list_tags()
        counts["tag"] = len(tags)
        for tag in tags:
            f.write(json.dumps({"entity_type": "tag", "data": tag}, default=_json_default) + "\n")
    return counts


# ---------------------------------------------------------------------------
# Per-run export helpers
# ---------------------------------------------------------------------------


def _build_run_meta(props: dict) -> dict:
    """Convert ``/info/`` props into a ``run.json``-compatible meta dict.

    The restore module reads keys: ``name``, ``description``, ``active``,
    ``is_archived``, ``experiment_name``.
    """
    exp = props.get("experiment") or {}
    meta: dict[str, Any] = {
        "name": props.get("name"),
        "description": props.get("description"),
        "active": props.get("active", False),
        "is_archived": props.get("archived", False),
        "created_at": props.get("creation_time", 0),
    }
    if exp.get("name"):
        meta["experiment_name"] = exp["name"]
        meta["experiment_id"] = exp.get("id")
    end_time = props.get("end_time")
    if end_time is not None:
        meta["finalized_at"] = end_time
    return meta


def _build_traces_and_contexts(
    traces_overview: dict[str, list],
) -> tuple[list[dict], dict[str, dict]]:
    """Derive ``traces.json`` and ``contexts.json`` from the /info/ response.

    Returns ``(traces_list, contexts_map)`` in the same shape as
    ``export_run.py`` writes them (backend backup).
    """
    traces: list[dict] = []
    contexts: dict[str, dict] = {}

    for bucket, items in traces_overview.items():
        dtype = _BUCKET_TO_DTYPE.get(bucket, bucket)
        for item in items:
            ctx = item.get("context") or {}
            ctx_id = context_to_id(ctx)
            name = item.get("name", "")
            trace_entry: dict[str, Any] = {
                "name": name,
                "context_id": ctx_id,
                "dtype": dtype,
            }
            if "last_value" in item:
                trace_entry["last"] = item["last_value"]
            traces.append(trace_entry)
            ctx_key = str(ctx_id)
            if ctx_key not in contexts:
                contexts[ctx_key] = ctx
    return traces, contexts


def _export_metrics(
    http: HttpTransport,
    run_hash: str,
    traces: list[dict],
    contexts: dict[str, dict],
) -> list[dict]:
    """Fetch all metric series via get-batch and return sequence records."""
    metric_traces = [t for t in traces if t.get("dtype") == "float"]
    if not metric_traces:
        return []

    batch_req = [{"name": t["name"], "context": contexts.get(str(t["context_id"]), {})} for t in metric_traces]

    results = http.get_run_metric_batch(run_hash, batch_req, record_density=50_000)

    records: list[dict] = []
    for r in results:
        name = r["name"]
        ctx = r.get("context") or {}
        ctx_id = context_to_id(ctx)
        iters = r.get("iters", [])
        values = r.get("values", [])
        for step, val in zip(iters, values, strict=False):
            records.append({"ctx_id": ctx_id, "name": name, "step": step, "value": val})
    return records


def _export_custom_objects(
    http: HttpTransport,
    run_hash: str,
    traces: list[dict],
    run_dir: Path,
    result: BackupResult,
) -> list[dict]:
    """Export custom-object sequences, downloading blobs where needed."""
    records: list[dict] = []
    custom_traces_by_bucket: dict[str, list[dict]] = {}
    for t in traces:
        dtype = t.get("dtype", "")
        bucket = _DTYPE_TO_BUCKET.get(dtype)
        if bucket and bucket in _CUSTOM_BUCKETS:
            custom_traces_by_bucket.setdefault(bucket, []).append(t)

    for bucket in custom_traces_by_bucket:
        search_results = http.search_sequence(bucket, query=f'run.hash == "{run_hash}"')
        if not search_results:
            continue

        blob_uris: list[str] = []
        uri_to_loc: dict[str, tuple[int, str, int, int]] = {}

        for run_data in search_results:
            if run_data.get("hash") != run_hash:
                continue
            traces_data = run_data.get("traces", [])
            if isinstance(traces_data, dict):
                traces_data = list(traces_data.values())
            for trace_data in traces_data:
                if not isinstance(trace_data, dict):
                    continue
                name = trace_data.get("name", "")
                ctx = trace_data.get("context") or {}
                ctx_id = context_to_id(ctx)
                values_list = trace_data.get("values", [])
                iters_list = trace_data.get("iters", [])
                for step, val in zip(iters_list, values_list, strict=False):
                    if isinstance(val, list):
                        for sub_idx, sub_val in enumerate(val):
                            _process_custom_value(
                                sub_val,
                                ctx_id,
                                name,
                                step,
                                sub_idx,
                                records,
                                blob_uris,
                                uri_to_loc,
                            )
                    else:
                        _process_custom_value(
                            val,
                            ctx_id,
                            name,
                            step,
                            0,
                            records,
                            blob_uris,
                            uri_to_loc,
                        )

        if blob_uris and bucket in _BLOB_BUCKETS:
            _download_blobs(http, bucket, blob_uris, run_dir, result)

    return records


def _process_custom_value(
    val: Any,  # noqa: ANN401
    ctx_id: int,
    name: str,
    step: int,
    index: int,
    records: list[dict],
    blob_uris: list[str],
    uri_to_loc: dict[str, tuple[int, str, int, int]],
) -> None:
    """Process a single custom-object value, collecting blob URIs if present."""
    record: dict[str, Any] = {"ctx_id": ctx_id, "name": name, "step": step, "value": val}
    records.append(record)
    if isinstance(val, dict) and "blob_uri" in val:
        uri = val["blob_uri"]
        blob_uris.append(uri)
        uri_to_loc[uri] = (ctx_id, name, step, index)


def _download_blobs(
    http: HttpTransport,
    seq_type: str,
    blob_uris: list[str],
    run_dir: Path,
    result: BackupResult,
) -> None:
    """Download blobs via the blob-batch endpoint and write to disk."""
    blobs_dir = run_dir / "blobs"
    batch_size = 50
    for i in range(0, len(blob_uris), batch_size):
        batch = blob_uris[i : i + batch_size]
        blob_map = http.get_blob_batch(seq_type, batch)
        for uri, data in blob_map.items():
            if not data:
                continue
            safe_name = uri.replace("/", "_").replace("\\", "_")[:200]
            blob_path = blobs_dir / safe_name
            blob_path.parent.mkdir(parents=True, exist_ok=True)
            blob_path.write_bytes(data)
            result.blob_count += 1
            result.blob_bytes += len(data)


def _export_logs(
    http: HttpTransport,
    run_hash: str,
    traces: list[dict],
    contexts: dict[str, dict],
) -> tuple[list[dict], list[dict]]:
    """Fetch log and log-record sequences, adding traces entries as needed.

    Returns ``(records, extra_traces)`` — extra traces to append to
    ``traces.json`` for logs/log_records dtypes (since they are hidden
    from the /info/ traces overview).
    """
    records: list[dict] = []
    extra_traces: list[dict] = []

    log_pairs = http.get_run_logs(run_hash, record_range="")
    if log_pairs:
        for step, val in log_pairs:
            records.append({"ctx_id": 0, "name": "logs", "step": step, "value": val})
        has_log_trace = any(t["name"] == "logs" and t.get("dtype") == "logs" for t in traces)
        if not has_log_trace:
            last_step = log_pairs[-1][0] if log_pairs else 0
            extra_traces.append(
                {
                    "name": "logs",
                    "context_id": 0,
                    "dtype": "logs",
                    "last": 0.0,
                    "last_step": last_step,
                },
            )
            if "0" not in contexts:
                contexts["0"] = {}

    _total, rec_pairs = http.get_run_log_records(run_hash, record_range="")
    if rec_pairs:
        for step, val in rec_pairs:
            records.append({"ctx_id": 0, "name": "__log_records", "step": step, "value": val})
        has_lr_trace = any(t["name"] == "__log_records" and t.get("dtype") in ("log_records", "logs") for t in traces)
        if not has_lr_trace:
            last_step = rec_pairs[-1][0] if rec_pairs else 0
            extra_traces.append(
                {
                    "name": "__log_records",
                    "context_id": 0,
                    "dtype": "log_records",
                    "last": 0.0,
                    "last_step": last_step,
                },
            )
            if "0" not in contexts:
                contexts["0"] = {}

    return records, extra_traces


def _export_run(
    http: HttpTransport,
    run_hash: str,
    backup_dir: Path,
    result: BackupResult,
) -> None:
    """Export a single run from the backend API into the backup directory."""
    run_dir = backup_dir / "runs" / run_hash
    run_dir.mkdir(parents=True, exist_ok=True)

    info = http.get_run_info(run_hash)
    props = info.get("props", {})
    params = info.get("params", {})
    if isinstance(params, dict):
        params.pop("__blobs__", None)
    traces_overview = info.get("traces", {})

    meta = _build_run_meta(props)
    meta["hash"] = run_hash
    _dump_json(meta, run_dir / "run.json")

    _dump_json(params, run_dir / "attrs.json")

    traces, contexts = _build_traces_and_contexts(traces_overview)

    all_records: list[dict] = []

    all_records.extend(_export_metrics(http, run_hash, traces, contexts))

    all_records.extend(
        _export_custom_objects(http, run_hash, traces, run_dir, result),
    )

    log_records, extra_traces = _export_logs(http, run_hash, traces, contexts)
    all_records.extend(log_records)
    traces.extend(extra_traces)

    _dump_json(traces, run_dir / "traces.json")
    _dump_json(contexts, run_dir / "contexts.json")

    seq_path = run_dir / "sequences.jsonl"
    with seq_path.open("w") as f:
        for rec in all_records:
            f.write(json.dumps(rec, default=_json_default, ensure_ascii=False) + "\n")

    result.sequence_records += len(all_records)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def run_backup(
    output_path: str,
    *,
    backend_url: str | None = None,
    run_hashes: list[str] | None = None,
    experiment: str | None = None,
    since: str | None = None,
    include_blobs: bool = True,
    compress: bool = False,
) -> BackupResult:
    """Create a backup of runs from the backend REST API.

    :param output_path: Directory to write the backup into.
    :param backend_url: Backend base URL; defaults to ``MATYAN_BACKEND_URL``.
    :param run_hashes: Explicit list of run hashes; if omitted, all runs
        (optionally filtered by *experiment* / *since*) are included.
    :param experiment: Back up only runs from this experiment name.
    :param since: Back up runs created after this ISO datetime string.
    :param include_blobs: Download S3 blobs for custom objects (default True).
    :param compress: Produce a ``.tar.gz`` archive instead of a directory.
    :returns: :class:`BackupResult` with statistics.
    """
    url = backend_url or SETTINGS.backend_url
    http = HttpTransport(url, timeout=120.0)
    result = BackupResult()

    try:
        timestamp = datetime.now(tz=timezone.utc).strftime("%Y%m%d-%H%M%S")
        backup_dir = Path(output_path) / f"matyan-backup-{timestamp}"
        backup_dir.mkdir(parents=True, exist_ok=True)
        (backup_dir / "runs").mkdir(exist_ok=True)

        hashes = _resolve_run_hashes(http, run_hashes=run_hashes, experiment=experiment, since=since)
        if not hashes:
            click.echo("No runs matched the given filters.")
            manifest = BackupManifest(
                created_at=datetime.now(tz=timezone.utc).isoformat(),
                include_blobs=include_blobs,
                filters=_build_filters(run_hashes, experiment, since),
            )
            manifest.write(backup_dir)
            result.backup_path = _finalise(backup_dir, compress)
            return result

        click.echo(f"Backing up {len(hashes)} run(s) via REST API...")

        click.echo("Exporting entities...")
        entity_counts = _export_entities(http, backup_dir)
        result.entity_counts = entity_counts
        for etype, count in entity_counts.items():
            if count:
                click.echo(f"  {etype}: {count}")

        for i, rh in enumerate(hashes, 1):
            click.echo(f"  [{i}/{len(hashes)}] Exporting run {rh}...")
            try:
                _export_run(http, rh, backup_dir, result)
                result.run_count += 1
            except Exception:
                logger.exception("Failed to export run {}", rh)
                click.echo(f"  WARNING: Failed to export run {rh}, skipping.")

        manifest = BackupManifest(
            created_at=datetime.now(tz=timezone.utc).isoformat(),
            run_count=result.run_count,
            run_hashes=[rh for rh in hashes if (backup_dir / "runs" / rh).is_dir()],
            entity_counts=entity_counts,
            blob_count=result.blob_count,
            blob_bytes=result.blob_bytes,
            filters=_build_filters(run_hashes, experiment, since),
            include_blobs=include_blobs,
        )
        manifest.write(backup_dir)

        click.echo(
            f"\nBackup complete: {result.run_count} run(s), "
            f"{result.sequence_records} sequence records, "
            f"{result.blob_count} blob(s) ({result.blob_bytes:,} bytes)",
        )

        result.backup_path = _finalise(backup_dir, compress)
    finally:
        http.close()

    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_run_hashes(
    http: HttpTransport,
    *,
    run_hashes: list[str] | None = None,
    experiment: str | None = None,
    since: str | None = None,
) -> list[str]:
    if run_hashes:
        return run_hashes

    query = ""
    if experiment:
        query = f'run.experiment == "{experiment}"'
    if since:
        ts = datetime.fromisoformat(since).timestamp()
        frag = f"run.created_at > {ts}"
        query = f"{query} and {frag}" if query else frag

    runs = http.search_runs(query=query)
    return [r.get("hash", r.get("run_id", "")) for r in runs if r.get("hash") or r.get("run_id")]


def _build_filters(
    run_hashes: list[str] | None,
    experiment: str | None,
    since: str | None,
) -> dict:
    filters: dict = {}
    if run_hashes:
        filters["runs"] = run_hashes
    if experiment:
        filters["experiment"] = experiment
    if since:
        filters["since"] = since
    return filters


def _finalise(backup_dir: Path, compress: bool) -> Path:
    if not compress:
        click.echo(f"Backup directory: {backup_dir}")
        return backup_dir

    archive_path = backup_dir.with_suffix(".tar.gz")
    click.echo(f"Compressing to {archive_path}...")
    with tarfile.open(archive_path, "w:gz") as tar:
        tar.add(backup_dir, arcname=backup_dir.name)
    shutil.rmtree(backup_dir)
    click.echo(f"Archive: {archive_path}")
    return archive_path
