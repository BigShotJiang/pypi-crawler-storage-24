"""Aim-compatible Repo class for querying and managing experiment data.

This module provides :class:`Repo`, the client for talking to the matyan-backend
REST API. Use it to list runs, query with MatyanQL, fetch run info, and perform
delete operations. All operations are HTTP-based; use :class:`~matyan_client.run.Run`
for creating runs and tracking metrics.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import httpx
from loguru import logger

from .config import SETTINGS
from .run import Run
from .transport.http import HttpTransport

if TYPE_CHECKING:
    from collections.abc import Iterator


class Repo:
    """Repository client that talks to the matyan-backend REST API.

    Provides run listing, MatyanQL queries, run/experiment deletion, and
    aggregation helpers. The backend URL is taken from the argument or
    from ``MATYAN_BACKEND_URL`` if not provided.

    :param url: Backend base URL (e.g. ``http://localhost:53800``); None to use settings.

    Usage::

        repo = Repo("http://localhost:53800")
        for run_info in repo.iter_runs():
            print(run_info)
    """

    def __init__(self, url: str | None = None) -> None:
        self._url = url or SETTINGS.backend_url
        self._http = HttpTransport(self._url)

    # ------------------------------------------------------------------
    # Class methods (Aim compatibility)
    # ------------------------------------------------------------------

    @classmethod
    def default_repo(cls) -> Repo:
        """Return a Repo instance using the default backend URL from settings."""
        return cls()

    @classmethod
    def from_path(cls, path: str) -> Repo:
        """Return a Repo instance with the given URL (Aim compatibility: path is the backend URL).

        :param path: Backend URL (e.g. ``http://localhost:53800``).
        """
        return cls(url=path)

    @staticmethod
    def is_remote_path(path: str) -> bool:
        """Return True if the path looks like an HTTP(S) URL (Aim compatibility)."""
        return path.startswith(("http://", "https://"))

    @property
    def is_remote_repo(self) -> bool:
        """True; matyan Repo always uses a remote backend."""
        return True

    # ------------------------------------------------------------------
    # Run access
    # ------------------------------------------------------------------

    def get_run(self, run_hash: str) -> Run | None:
        """Return a read-only Run proxy for the given run hash.

        :param run_hash: Run hash (hex string) of the run.
        :returns: A read-only :class:`Run` instance, or None if the run does not exist or the request fails.
        """
        try:
            info = self._http.get_run_info(run_hash)
            if not info:
                return None
            return Run(run_hash=run_hash, repo=self._url, read_only=True)
        except httpx.HTTPError:
            logger.debug("Run not found or unreachable", run_hash=run_hash)
            return None

    def run_exists(self, run_hash: str) -> bool:
        """Return True if a run with the given hash exists in the backend."""
        return self.get_run(run_hash) is not None

    def iter_runs(self) -> Iterator[dict]:
        """Iterate over all runs as info dicts (hash, props, etc.).

        :returns: Iterator of run info dicts from the backend.
        """
        results = self._http.search_runs(query="")
        yield from results

    def list_all_runs(self) -> list[str]:
        """Return run hashes for all runs in the repository.

        :returns: List of run hash strings.
        """
        runs = self._http.search_runs(query="")
        return [r.get("hash", r.get("run_id", "")) for r in runs]

    def list_active_runs(self) -> list[str]:
        """Return run hashes for runs that are still active (not finalized).

        :returns: List of run hash strings.
        """
        runs = self._http.search_runs(query="run.active == True")
        return [r.get("hash", r.get("run_id", "")) for r in runs]

    def total_runs_count(self) -> int:
        """Return the total number of runs in the repository."""
        return len(self.list_all_runs())

    # ------------------------------------------------------------------
    # Querying
    # ------------------------------------------------------------------

    _DEFAULT_PAGE_LIMIT = 50

    def query_runs(
        self,
        query: str = "",
        paginated: bool = False,
        offset: str | None = None,
        limit: int = _DEFAULT_PAGE_LIMIT,
    ) -> list[dict] | Iterator[list[dict]]:
        """Query runs with an optional MatyanQL expression.

        :param query: MatyanQL query string; empty string means all runs.
        :param paginated: If True, return an iterator of pages (lists of run dicts); else a single list.
        :param offset: Optional run hash to start after (for pagination).
        :param limit: Max runs per page when paginated.
        :returns: Either a list of run info dicts, or an iterator of such lists when paginated.
        """
        if not paginated:
            return self._http.search_runs(query=query, offset=offset)
        return self._iter_run_pages(query=query, limit=limit, offset=offset)

    def _iter_run_pages(
        self,
        query: str,
        limit: int,
        offset: str | None,
    ) -> Iterator[list[dict]]:
        """Yield pages of run info dicts for the given query (used by query_runs when paginated)."""
        while True:
            page = self._http.search_runs(query=query, limit=limit, offset=offset)
            if not page:
                break
            yield page
            if len(page) < limit:
                break
            last = page[-1]
            offset = last.get("hash", last.get("run_id"))

    def query_metrics(self, query: str = "") -> list[dict]:
        """Run a MatyanQL metric query and return the result list."""
        return self._http.search_metrics(query=query)

    def query_images(self, query: str = "") -> list[dict]:
        """Query image sequences with an optional MatyanQL filter."""
        return self._http.search_sequence("images", query=query)

    def query_audios(self, query: str = "") -> list[dict]:
        """Query audio sequences with an optional MatyanQL filter."""
        return self._http.search_sequence("audios", query=query)

    def query_figure_objects(self, query: str = "") -> list[dict]:
        """Query figure sequences with an optional MatyanQL filter."""
        return self._http.search_sequence("figures", query=query)

    def query_distributions(self, query: str = "") -> list[dict]:
        """Query distribution sequences with an optional MatyanQL filter."""
        return self._http.search_sequence("distributions", query=query)

    def query_texts(self, query: str = "") -> list[dict]:
        """Query text sequences with an optional MatyanQL filter."""
        return self._http.search_sequence("texts", query=query)

    # ------------------------------------------------------------------
    # Run management
    # ------------------------------------------------------------------

    def delete_run(self, run_hash: str) -> bool:
        """Delete a single run by hash (backend and async side effects).

        :param run_hash: Run hash of the run to delete.
        :returns: True if the request succeeded, False on HTTP error.
        """
        try:
            self._http.delete_run(run_hash)
        except httpx.HTTPError:
            logger.warning("Failed to delete run", run_hash=run_hash)
            return False
        else:
            return True

    def delete_runs(self, run_hashes: list[str]) -> tuple[bool, list[str]]:
        """Delete multiple runs by hash.

        :param run_hashes: List of run hashes to delete.
        :returns: A tuple (all_succeeded, list of hashes that failed to delete).
        """
        failed = [rh for rh in run_hashes if not self.delete_run(rh)]
        return len(failed) == 0, failed

    # ------------------------------------------------------------------
    # Experiment management
    # ------------------------------------------------------------------

    def delete_experiment(self, exp_id: str) -> bool:
        """Delete an experiment by ID (backend and async side effects).

        :param exp_id: Experiment UUID or identifier.
        :returns: True if the request succeeded, False on HTTP error.
        """
        try:
            self._http.delete_experiment(exp_id)
        except httpx.HTTPError:
            logger.warning("Failed to delete experiment", exp_id=exp_id)
            return False
        else:
            return True

    # ------------------------------------------------------------------
    # Info aggregation
    # ------------------------------------------------------------------

    def collect_sequence_info(self, sequence_types: tuple[str, ...] = ("metric",)) -> dict[str, dict[str, list]]:
        """Collect trace/sequence info for the given types across all runs.

        :param sequence_types: Tuple of sequence type names (e.g. ``("metric", "images")``).
        :returns: Dict mapping run hash to dict of sequence type to list of trace info.
        """
        result: dict[str, dict[str, list]] = {}
        for run_data in self.iter_runs():
            rh = run_data.get("hash", run_data.get("run_id", ""))
            if not rh:
                continue
            try:
                info = self._http.get_run_info(rh)
                traces = info.get("traces", {})
                for seq_type in sequence_types:
                    if seq_type in traces:
                        if rh not in result:
                            result[rh] = {}
                        result[rh][seq_type] = traces[seq_type]
            except httpx.HTTPError:
                logger.debug("Failed to fetch sequence info", run_hash=rh)
                continue
        return result

    def collect_params_info(self) -> dict:
        """Collect params (e.g. hyperparameters) for every run.

        :returns: Dict mapping run hash to params dict (nested key-value structure).
        """
        params: dict = {}
        for run_data in self.iter_runs():
            rh = run_data.get("hash", run_data.get("run_id", ""))
            if not rh:
                continue
            try:
                info = self._http.get_run_info(rh)
                params[rh] = info.get("params", {})
            except httpx.HTTPError:
                logger.debug("Failed to fetch params info", run_hash=rh)
                continue
        return params

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def available_sequence_types() -> list[str]:
        """Return the list of sequence type names supported for queries."""
        return ["metric", "images", "figures", "texts", "audios", "distributions"]

    def close(self) -> None:
        """Close the underlying HTTP client and release resources."""
        self._http.close()

    def __repr__(self) -> str:
        """Return a short string representation of the repo (URL)."""
        return f"Repo(url={self._url!r})"
