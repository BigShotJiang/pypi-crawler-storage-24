from __future__ import annotations

import time
from typing import Optional

from ..base import BaseProvider, ProviderResult


class DefendProvider(BaseProvider):
    name = "defend"
    supports_modules = False

    async def evaluate(
        self,
        text: str,
        session_id: Optional[str] = None,  # noqa: ARG002
        modules: list | None = None,  # noqa: ARG002
    ) -> ProviderResult:
        from ...models.defend_qwen import get_defend_classifier

        start = time.perf_counter()
        classifier = get_defend_classifier()
        output = classifier.classify(text)
        latency_ms = int((time.perf_counter() - start) * 1000)

        action = "block" if output.is_injection else "pass"

        return ProviderResult(
            action=action,
            provider=self.name,
            score=output.probability,
            reason=None,
            modules_triggered=[],
            latency_ms=latency_ms,
        )

