"""Initializer of Auto Instrumentation of LiteLLM Functions"""

from typing import Collection
import importlib.metadata
from opentelemetry.instrumentation.instrumentor import BaseInstrumentor
from wrapt import wrap_function_wrapper

from openlit.instrumentation.litellm.litellm import completion, embedding
from openlit.instrumentation.litellm.async_litellm import acompletion, aembedding

_instruments = ("litellm >= 1.52.6",)


class LiteLLMInstrumentor(BaseInstrumentor):
    """
    An instrumentor for LiteLLM client library.
    """

    def instrumentation_dependencies(self) -> Collection[str]:
        return _instruments

    def _instrument(self, **kwargs):
        application_name = kwargs.get("application_name", "default")
        environment = kwargs.get("environment", "default")
        tracer = kwargs.get("tracer")
        metrics = kwargs.get("metrics_dict")
        pricing_info = kwargs.get("pricing_info", {})
        capture_message_content = kwargs.get("capture_message_content", False)
        disable_metrics = kwargs.get("disable_metrics")
        event_provider = kwargs.get("event_provider")
        version = importlib.metadata.version("litellm")

        for target_module in ["litellm", "litellm.main"]:
            # Chat completions
            wrap_function_wrapper(
                target_module,
                "completion",
                completion(
                    version,
                    environment,
                    application_name,
                    tracer,
                    pricing_info,
                    capture_message_content,
                    metrics,
                    disable_metrics,
                    event_provider,
                ),
            )

            # Async chat completions
            wrap_function_wrapper(
                target_module,
                "acompletion",
                acompletion(
                    version,
                    environment,
                    application_name,
                    tracer,
                    pricing_info,
                    capture_message_content,
                    metrics,
                    disable_metrics,
                    event_provider,
                ),
            )

            # Embeddings
            wrap_function_wrapper(
                target_module,
                "embedding",
                embedding(
                    version,
                    environment,
                    application_name,
                    tracer,
                    pricing_info,
                    capture_message_content,
                    metrics,
                    disable_metrics,
                    event_provider,
                ),
            )

            # Async embeddings
            wrap_function_wrapper(
                target_module,
                "aembedding",
                aembedding(
                    version,
                    environment,
                    application_name,
                    tracer,
                    pricing_info,
                    capture_message_content,
                    metrics,
                    disable_metrics,
                    event_provider,
                ),
            )

    def _uninstrument(self, **kwargs):
        pass
