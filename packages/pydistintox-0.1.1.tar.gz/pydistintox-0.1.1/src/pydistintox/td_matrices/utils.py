# standard library imports
from pathlib import Path
import logging
import sys

# third-party imports
import spacy

# no intra-package imports to prevent circular imports!


# application-specific import
from pydistintox.common import utils as common_utils
from pydistintox.common import config as common_config


""" logging """
def log_corp(
        corp: list[tuple[str,list[str]]]
    )-> None:

    ids = {id for id, lemma in corp}

    logging.info(
        f'The corpus contains {str(len(ids))} documents '
        f'in {str(len(corp))} chunks. '
    )

""" Spacy specific functions """
def load_spacy_model(
        model: str
    )-> spacy.language.Language:

    try:
        nlp=spacy.load(
            model, 
            disable='ner'
        )
        logging.debug(f'loaded spacy model: {model}')
        return nlp
    
    except OSError as e:
        logging.critical(
            f'Error {e} \n'
            f'Please run the following command:       \n\n'
            f'pip install $(spacy info {model} --url) \n\n\n'
            f'If you are working with uv in an activated virtual environment run: \n\n'
            f'uv pip install $(spacy info {model} --url) \n\n'
        )
        raise


""" storing results"""
def store_list(
        list: list,
        path: Path,
    ) -> None:  

    with open(path, 'w') as file:
        for element in list:
            file.write(f'{element}\n')

    logging.debug(f'wrote list of len {len(list)} to {path}.')
    return