# standard library imports
import logging
from pathlib import Path

# third-party imports
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import spacy

# intra-package importss
from .config import (
    DEFAULT_CHUNK_LENGTH
)
from .create_matrices import (
    create_matrices
)
from .parsing import (
    create_corp,
    extract_lemmas,
    chunk_lemmas,
    parse,
)
from .io_utils import (
    write_doc,
    load_corp_from_dir,
)
from .config import (
    DummyScaler,
    measures_available,
)
from .utils import (
    load_spacy_model,
    log_corp,
)
from .tfidf_measures import (
    calculate_measure,
    build_gensim_dictionary_from_lemmas,
    get_values,
    docs_to_bow,
)

# application-specific importss
from pydistintox.common import utils as common_utils
from pydistintox.common import config as common_config




def parse_corp(
        corp: list[tuple[str, str]],
        spacy_model: spacy.language.Language,
        chunk_length: int,
        do_save_nlp: bool,
        save_path_dir: Path | None = None,
    ) -> list[tuple[str, list[str]]]:
    """Processes texts into spaCy Docs (with chunking if needed)."""

    # checks
    if do_save_nlp: 
        assert isinstance(save_path_dir,Path)
        if not common_utils.dir_is_empty(save_path_dir):
            error_message = (
                f'Caution! The output directory for NLP is not empty. \n'
                f'Please clean {save_path_dir} first!')
            logging.error(error_message)
            raise FileExistsError(error_message)
    
    parsed_corp = []  
    for filename, content in corp:

        spacy_doc = parse(content,spacy_model)

        if do_save_nlp:
            assert isinstance(save_path_dir,Path)
            logging.info(f'Create json for {filename}')
            write_doc(
                dir= save_path_dir,
                file_name=filename,
                spacy_doc=spacy_doc,
            )

        lemmas = extract_lemmas(spacy_doc)
        chunked_lemmas = chunk_lemmas(
            lemmas,
            chunk_length,
        )

        for i, chunk in enumerate(chunked_lemmas):
            parsed_corp.append(
                (f"{filename}_{i}", chunk)
            )

    return parsed_corp


def compute_td_matrices_and_measures(
        config: common_config.Config
    )->tuple[
        common_config.Matrices,
        dict[str,np.ndarray],
        list[str]
    ]:
    """ 
    parses texts, then creates a whole corpus of lemmata
    calculates six TF-IDF measures of given the texts.
    """

    logging.debug(f'Started {compute_td_matrices_and_measures.__name__}')

    """Preprocessing"""
    # Spacy model used for nlp
    spacy_model = load_spacy_model(config.spacy_model_name)


    if not(config.skip_nlp):
        # gather texts
        corp_tar = create_corp(config.target)
        corp_ref = create_corp(config.reference)
        if config.save_nlp:
            assert isinstance(config.save_nlp, Path)
            output_tar = config.save_nlp / 'tar'
            output_ref = config.save_nlp / 'ref'
            do_save_nlp = True
        else:
            do_save_nlp = False
            output_tar = None
            output_ref = None
            
        # parse corps
        parsed_corp_tar = parse_corp(
            corp_tar,
            spacy_model,
            chunk_length=DEFAULT_CHUNK_LENGTH,
            do_save_nlp=do_save_nlp,
            save_path_dir=output_tar,
        )
        parsed_corp_ref = parse_corp(
            corp_ref,
            spacy_model,
            chunk_length=DEFAULT_CHUNK_LENGTH,
            do_save_nlp=do_save_nlp,
            save_path_dir=output_ref,
        )
    else:  # skip nlp, so load corp from json
        # load lemmas from json
        logging.info('Loading lemmas from json of target corpus')
        parsed_corp_tar = load_corp_from_dir(
            path_dir=config.target,
            spacy_model=spacy_model,
        )
        logging.info('Loading lemmas from json of reference corpus')
        parsed_corp_ref = load_corp_from_dir(
            path_dir=config.reference,
            spacy_model=spacy_model,
        )

    # logging
    logging.info('\n\n\n Target corpus\n')
    log_corp(parsed_corp_tar)
    logging.info('\n\n\n Reference corpus')
    log_corp(parsed_corp_ref)

    all_lemmas = parsed_corp_tar + parsed_corp_ref
    gensim_dictionary = build_gensim_dictionary_from_lemmas(all_lemmas) 
    bow = docs_to_bow(all_lemmas,gensim_dictionary)
    terms = get_values(gensim_dictionary)

    """create absolute, binary and relative matrices"""
    matrices_sp = create_matrices(
        corp_lemma_tar=parsed_corp_tar, 
        corp_lemma_ref=parsed_corp_ref,
        bow_corpus=bow
    )

    """calculate tf-idf measures """   
    # Scaler is fitted per-measure, so *absolute* scaled values are not comparable across measures.
    # However, *relative rankings within a measure* (e.g., term A > term B in 'nfn') remain valid.
    # We accept this limitation because only intra-measure ranks are used for further analysis. 
    # logging.debug(f'got terms {terms[0]+terms[1]+terms[2]}...')

    scores_tf_idf = {}
    scaler = MinMaxScaler(feature_range=(-1,1)) if config.scaling else DummyScaler()

    tf_idf_measures_to_calculate = common_utils.intersect_lists(
        config.measures_to_calculate, 
        measures_available
    )
    measures_in_sequence = common_utils.get_measure_names(
        measures_available=measures_available,
        measures_input=tf_idf_measures_to_calculate,
    )

    for measure in measures_in_sequence:
        result = calculate_measure(
            parsed_corp_tar,
            parsed_corp_ref,
            gensim_dictionary,
            bow,
            measure,
            scaler,
        )
        scores_tf_idf[measure] = result
    
    return matrices_sp, scores_tf_idf, terms