# standard library import
import logging
from typing import cast

# third-party imports
from gensim import (
    matutils, 
    models, 
    utils
)
from gensim.corpora import Dictionary
import numpy as np
import pandas as pd
from scipy import sparse as sp

# intra-package importss 


def extract_documents(
        corp:list[tuple[str,list[str]]],# see output load_lemmas_from_path
    )-> list[list[str]]:
    return [x[1] for x in corp]


def build_gensim_dictionary (documents)->Dictionary:
    return Dictionary(documents)


def build_gensim_dictionary_from_lemmas(
        corp:list[tuple[str,list[str]]],# see output load_lemmas_from_path
    )->Dictionary:
    return build_gensim_dictionary(extract_documents(corp))

def docs_to_bow(
    corp: list[tuple[str, list[str]]],
    dictionary: Dictionary
) -> list[tuple[int, int]]:
    
    documents = extract_documents(corp)
    bow_corpus = [
        dictionary.doc2bow(d, allow_update=False)
        for d in documents
    ]

    return cast(
        list[tuple[int, int]],  # forcing the returning type (for pylance mostly)
        bow_corpus  # the returned value
    )


def get_values(
        dictionary: Dictionary
    ) -> list[str]:
    """
    Get the terms from a gensim dictionary.
    Since the object is changed from view_object to list,
    subsequent changes in the dictionary will not affect get_values.
    """

    view_object = dictionary.values()
    return  list(view_object)


def initialize_tfidf(
        corpus: list[list[str]], 
        smartparas: str, 
        len_target: int, 
        len_ref: int
    )-> tuple[sp.csc_array,sp.csc_array]:
    """
    Returns matrices for target and reference corpus
    with tfidf-model for corpus with smartirs parameters.
    """

    model = models.TfidfModel(
        corpus, 
        smartirs=smartparas, 
        slope=0.0
    )  # argument slope takes float not bool

    len_vocab = len(utils.dict_from_corpus(corpus))
    target_tfidf_corp = model[corpus[0:len_target]]
    ref_tfidf_corp = model[corpus[len_target:]]
    
    # Convert corpus into a dense numpy 2D array, 
    # with documents as columns. (TDM)
    tdm_matrix_tar = matutils.corpus2csc(
        target_tfidf_corp,
        num_terms = len_vocab,
        num_docs=len_target
    )
    tdm_matrix_ref = matutils.corpus2csc(
        ref_tfidf_corp,
        num_terms = len_vocab,
        num_docs=len_ref
    )

    # gensim exports in old csc_matrix format
    # transform into new csc_array format
    tdm_tar = sp.csc_array(tdm_matrix_tar)
    tdm_ref = sp.csc_array(tdm_matrix_ref)

    return (tdm_tar, tdm_ref)


def tfidf_diff(
        tdm_tar: sp.csc_array, 
        tdm_ref: sp.csc_array, 
        corp_dictionary: Dictionary,
        scaler,
    )-> pd.Series:
    """
    Calculate the difference between
    tfidf matrix in target and reference corpus
    Use mean for deriving vector from matrix
    """

    vec_tar = tdm_tar.mean(axis=1)
    vec_ref = tdm_ref.mean(axis=1)

    vec_diff = vec_tar - vec_ref
    vec_diff_scaled = scaler.fit_transform(vec_diff.reshape(-1, 1))
    
    diff_result = pd.Series(
        data=[x[0] for x in vec_diff_scaled],
        index=get_values(corp_dictionary),
        dtype=float
    )

    return diff_result  # (diff_result.sort_values(ascending=False)) # no sorting here!


def calculate_measure(
        corp_tar: list[tuple[str,list[str]]], 
        corp_ref: list[tuple[str,list[str]]],
        dictionary: Dictionary,
        bow,  # add type
        measure: str,
        scaler,
    )->pd.Series:

    logging.info(f'calculate {measure}.')

    len_tar = len(corp_tar)
    len_ref = len(corp_ref)
    
    logging.debug(
        f'input tar of len {len_tar} '
        f'and input ref of len {len_ref}.'
    )

    # nfn: absolute term frequency, 
    # idf, no document normalization'
    tup = initialize_tfidf(
        bow,
        measure, 
        len_tar,
        len_ref
    )
    diff = tfidf_diff(
        tup[0], 
        tup[1], 
        dictionary, 
        scaler
    )
    
    return diff