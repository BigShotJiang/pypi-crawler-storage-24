# third-party imports
import numpy as np

# application-specific imports
from pydistintox.common.config import SparseMatrix

# intra-package imports
from .measures import (
    calculate_Eta_deviation_of_proportions,
    calculate_original_Zeta,
    calculate_ratio_of_relative_frequencies,
    calculate_Zeta_log2_transformed,
    calculate_chi_squared_test,
    calculate_log_likelihood_ratio_test,
    calculate_welch_t_test,
    calculate_wilkoxon_rank_sum_test,
)


"""measures"""

# caution: the oder of the following dict detemines
# order in which the measures are calculated
mapping_of_names_and_measure_functions = {
        'welch_t_value' : calculate_welch_t_test,  # needs dense matrices
        'ranksumtest_value' : calculate_wilkoxon_rank_sum_test,  # is faster with dense
        'chi_square_value' : calculate_chi_squared_test,  # is faster with dense
        'eta_sg0' : calculate_Eta_deviation_of_proportions,
        'zeta_sd0' : calculate_original_Zeta,
        'rrf_dr0' : calculate_ratio_of_relative_frequencies,
        'zeta_sd2' : calculate_Zeta_log2_transformed,
        'LLR_value' : calculate_log_likelihood_ratio_test,
}

measures_available = list(mapping_of_names_and_measure_functions.keys())

# list of measures (not used)
# measures =[
#     'zeta_sd0',
#     'zeta_sd2',
#      'rrf_dr0', 
#      'eta_sg0', 
#      'welch_t_value', 
#      'ranksumtest_value', 
#      'chi_square_value', 
#      'LLR_value'
#      # 'tf_idf'
# ]

# names_of_td_matrices = [
#     'abs_tar',
#     'abs_ref',
#     'bin_tar',
#     'bin_ref',
#     'rel_tar',
#     'rel_ref',
# ]