# standard library imports
import logging
from pathlib import Path

# third-party imports
import numpy as np
import pandas as pd
from scipy.stats import kendalltau

# application-specific imports
import pydistintox.common.config as common_config
from pydistintox.common.config import (
    SparseMatrix,
    Config
)
import pydistintox.common.utils as common_utils
from pydistintox.common.utils import (
    handle_errors,
)

# intra-package imports
from .config import (
    measures_available,
    mapping_of_names_and_measure_functions,
)
from .measures import (
    get_indicators,
    scale_results,
)
from .utils import (
    log_shapes,
)


def calculate_scores(
        matrices: common_config.Matrices,  # containing also docprops and relative
        config: Config,
    )-> dict[str, np.ndarray]:
    """
    This is the main funktion, doing all the calculation.
    it takes and gives out a dictionary containing these keys:
    ['zeta_sd0', 'zeta_sd2', 'rrf_dr0', 
    'eta_sg0', 'welch_t_value', 'ranksumtest_value', 
    'chi_square_value', 'LLR_value', 'tf_idf']
    This function implements several distinctive measures.
    """

    logging.info('Starting to calculate scores...')
    logging.debug(f'Measures requested: {config.measures_to_calculate}')
    
    """ Preprocessing """

    non_tf_idf_measures_to_calculate = common_utils.intersect_lists(
        config.measures_to_calculate, 
        measures_available
    )
    measures_in_sequence = common_utils.get_measure_names(
        measures_input=non_tf_idf_measures_to_calculate,
        measures_available=measures_available,
    )
    logging.debug(
        f'measures in sequence: \n'
        f'{measures_in_sequence}'
    )

    log_shapes(matrices)

    """ Gather data for analysis"""
    # data is stored in a dictionary
    # which will be given to the calulation

    # calculate indicators (docprops / relative frequencies)
    data = common_config.CalculationData(
        matrices,
        get_indicators(matrices)
    )

    # save parameters
    data.set_params(
        segmentlength=config.segmentlength,
        logaddition=config.logaddition,
        divaddition=config.divaddition,
    )

    """ Start calculation"""
    result = {}

    for measure_name in measures_in_sequence:
        # load function for measure
        fct = mapping_of_names_and_measure_functions[measure_name]
        # execute function
        result_measure = handle_errors(
            fct,
            data,
        )

        # save results only in resutlt dictionary if:
        if result_measure is not None:
            logging.debug(f'{measure_name} is None')
            result[measure_name] = result_measure

    logging.debug(f'Scores calculated: \n {result.keys()}')
    # For the time beeing, dense matrices are necessary for welch's t-Test only
    # However, if they are generated, Chi-squared test and Wilcoxon rank-sum test
    # use these dense matrices, since they make the computation faster.

    dense_absolute_matrices_loaded = (
        data.matrices.abs_dense_tar is not None and data.matrices.abs_dense_ref is not None
    )
    logging.debug(
        f'dense_absolute_matrices_loaded = {dense_absolute_matrices_loaded}'
    )
    
    # results of tfidf measures are given by the other package td_matrices
    not_computed = set(measures_in_sequence).difference(set(result.keys()))
    logging.debug(f"Results calculated for: {', '.join(result.keys())}")
    if not_computed:
        logging.info(f"Could not compute {', '.join(not_computed)}")

    # scaling
    if config.scaling:
        scale_results(
            result,
        )

    logging.debug(
        f'statistical measures calculated \n'
        f' {calculate_scores.__name__} finished')

    return result


def calculate_rank_correlation(
        results: dict[str,np.ndarray],
    )-> tuple[np.ndarray, list[str]]:
    """
    Calculates the Kendall rank correlation coefficients 
    between all pairs of measures in the input dictionary.
    It returns them as a 2-d matrix (np.ndarray)

    As the input arrays are uniformly scaled, only rank correlation is meaningful.
    The resulting matrix is symmetric, with each entry representing the correlation between two measures.
    """

    index = list(results.keys())
    number_of_measures = len(results.keys())
    rows,cols = number_of_measures, number_of_measures
    matrix = np.empty((rows,cols))

    # fill matrix
    for i in range(rows):
        for j in range(cols):
            key_i = index[i]
            array_i = results[key_i]
            key_j = index[j]
            array_j = results[key_j]
            tau, p_value =kendalltau(array_i,array_j)  # p_value not used
            matrix[i,j] = tau
    return matrix, index