# standard library imports
import logging

# third-party imports
import numpy as np
from scipy import stats
import scipy.sparse as sp
from sklearn import preprocessing as prp

# application-specific imports
from pydistintox.common.utils import (
    SparseMatrix,
    handle_errors    
)
import pydistintox.common.config as common_config


def scale(
        scaler:prp.MinMaxScaler, 
        array: np.ndarray
    )-> np.ndarray:

    array = scaler.fit_transform(
        array.reshape(-1, 1)
    )
    array = array.flatten()

    return array


def scale_results(
        scores: dict[str, np.ndarray],
    ) -> np.ndarray:
    scaler = handle_errors(
        prp.MinMaxScaler, 
        feature_range = (-1,1),
    )

    for measure_name in scores.keys():
        try:
            scores[measure_name] = scale(
                scaler=scaler,
                array=scores[measure_name],
            )
        except KeyError:
            logging.debug(f'{measure_name} not in scores.')

    return scores


def get_indicators(
        matrices: common_config.Matrices
        ) -> common_config.Indicators:
    """ 
    Takes a dictionary of matrices, calculates the indicators/docprops
    for bin / rel matrices and returns result as dictionary.
    Only matrices have a name like rel_ref, indicators get longer names.
    """
 
    # we calculate docprops only for binary matrices
    indicators = common_config.Indicators(
        # for binary matrices (containing only 0 and 1)
        docprops_tar = matrices.bin_tar.mean(axis=1) ,
        docprops_ref = matrices.bin_ref.mean(axis=1),
        # for relative matrices multiply with 1000
        relative_tar = matrices.rel_tar.mean(axis=1) * 1000,
        relative_ref = matrices.rel_ref.mean(axis=1) * 1000,
    )
    logging.debug(f'calculated indicators')
    return indicators


""" statistical measures """

# Original Zeta
def calculate_original_Zeta(
        data: common_config.CalculationData
    ) -> np.ndarray:
    """ 
    sd0 - Subtraction, docprops, untransformed a.k.a. 'original Zeta'
    """
    logging.info("---calculating   'original Zeta'---")
       
    # sd0 - Subtraction, docprops, untransformed a.k.a. 'original Zeta'
    return data.indicators.docprops_tar - data.indicators.docprops_ref


# Zeta Log Two
def calculate_Zeta_log2_transformed(
        data: common_config.CalculationData,
    ) -> np.ndarray:

    docprops_tar = data.indicators.docprops_tar
    docprops_ref = data.indicators.docprops_ref
    logaddition = data.logaddition
    return np.log2(docprops_tar + logaddition) - np.log2(docprops_ref + logaddition)


# Ratio of Relative Frequencies
def calculate_ratio_of_relative_frequencies(
        data: common_config.CalculationData,
    )-> np.ndarray:

    divaddition = data.divaddition

    # make sure we dont change input:
    relative_tar, relative_ref = data.indicators.relative_tar.copy(), data.indicators.relative_ref.copy()

    relative_tar = relative_tar + divaddition
    relative_ref = relative_ref + divaddition

    return relative_tar/relative_ref


# DP Gries / Eta Deviation of Proportions
def DP_Gries(
        absolute_csc: sp.csc_array,
        segmentlength: int, 
        absolute_csr: sp.csr_array | None = None
    )-> np.ndarray:
    """
    This function implements Gries 'deviation of proportions' 
    (Gries, 2008. DOI: https://doi.org/10.1075/ijcl.13.4.02gri)
    """

    # Ignore division by zero warnings
    np.seterr(divide='ignore')

    # csr is optional, if not given, csc is used
    if absolute_csr is None:
        absolute_csr = absolute_csc
    else:
        # check if csr is in correct format
        if absolute_csr.format != 'csr':
            logging.warning('Input matrix must be in Compressed Sparse Row (CSR) format.')

    # Check if csc matrices are in the correct format
    if absolute_csc.format != 'csc':
        logging.warning('Input matrix must be in Compressed Sparse Column (CSC) format.')

    segnum = absolute_csc.shape[1]
    seglens = [segmentlength] * segnum
    crpsize = sum(seglens)
    totalfreqs = np.sum(absolute_csr, axis=1)
    expprops = np.array(seglens) / crpsize
    totalfreqs= totalfreqs[:, np.newaxis]
    obsprops = absolute_csc / totalfreqs
    obsprops = np.nan_to_num(obsprops)
    devprops = (np.sum(abs(expprops - obsprops), axis=1) /2 )  # / (1 - min(expprops1))

    return devprops


def calculate_Eta_deviation_of_proportions(
        data: common_config.CalculationData,
    ) -> np.ndarray:

    devprops_tar = handle_errors(
        DP_Gries, 
        data.matrices.abs_tar, 
        data.segmentlength
    )
    devprops_ref = handle_errors(
        DP_Gries, 
        data.matrices.abs_ref, 
        data.segmentlength
    )

    diff = devprops_tar - devprops_ref
    
    return diff * -1


# Welch t Test
def welch_t_test(
        absolute_dense_tar, 
        absolute_dense_ref, 
        p_value = False
    ) -> np.ndarray:
    """
    This function implements Welch's t-test 
    (https://en.wikipedia.org/wiki/Welch%27s_t-test)
    Columns represent documents and rows represents features.
    """

    welch_t_results = stats.ttest_ind(
        absolute_dense_tar.T, 
        absolute_dense_ref.T, 
        equal_var = False
    )    
    results = {
        't_value': welch_t_results[0], 
        'p_value': welch_t_results[1]
    }

    if np.any(np.isnan(results['t_value'])):
       nan_count = np.isnan(results['t_value']).sum()
       logging.warning(f'There are {nan_count} NaN values included in the results.')

    if p_value == True:
        return results
    
    # determine whether t_value contains infinite values
    welch_t_value = results['t_value']
    pos_inf = np.isposinf(welch_t_value)
    neg_inf = np.isneginf(welch_t_value)

    # Set positive infinite values to (max without Inf) * 10
    if np.any(pos_inf):
        logging.warning('Positive infinite values found in welch_t_value. Setting them to max * 10.')
        # Setze positive Inf-Werte auf max * 10
        welch_t_value[pos_inf] = np.nanmax(welch_t_value[~np.isinf(welch_t_value)]) * 10 

    # Set negative infinite values to (min without Inf) / 10
    if np.any(neg_inf):
        logging.warning('Negative infinite values found in welch_t_value. Setting them to min / 10.')
        min_val = np.nanmin(welch_t_value[~neg_inf])
        welch_t_value[neg_inf] = min_val / 10

    return welch_t_value


def calculate_welch_t_test(
        data: common_config.CalculationData,
    ) -> np.ndarray | None:

    logging.info("---calculating   'welchs-t-test'---")
    # SciPy only takes dense matrices, so we convert the sparse matrices to dense
    # This is memory-intensive but faster.
    try:
        data.matrices.abs_dense_tar = data.matrices.abs_tar.toarray()
        data.matrices.abs_dense_ref = data.matrices.abs_ref.toarray()
        result = handle_errors(
            welch_t_test,
            data.matrices.abs_dense_tar, 
            data.matrices.abs_dense_ref
        )

        # If the matrices are loaded we can use them in Wilcoxon rank-sum test as well.
        # dense_absolute_matrices_loaded = True
        logging.debug('Dense matrices have been successfully loaded.')
        
        return result
    
    except MemoryError as e:
        logging.error(
            e, 
            'while calculating Welch-t-test'
        )
        logging.error(
            'Probably RAM was not sufficient to generate dense TD-matrices. '
            'Computation will continue without them.'
        )
        dense_absolute_matrices_loaded = False
        logging.debug(f'dense matrices loaded: {dense_absolute_matrices_loaded}')
        return
    


# Wilkoxon Rank Sum Test
def wilcoxon_ranksum(
        absolute_tar, 
        absolute_ref, 
        p_value=False
    ) -> None | np.ndarray | dict[str, np.ndarray]:
    """
    csr-Matrices are expected. This is memory efficient, 
    but slow for repeated toarray() calls.
    """

    number_of_terms = absolute_tar.shape[0]
    ranksum_count = 0
    ranksumtest_value = []
    ranksum_p_value = []
    result = {}
    
    while ranksum_count < number_of_terms:
        if sp.issparse(absolute_tar) and sp.issparse(absolute_ref):
            row_tar = absolute_tar[[ranksum_count],:].toarray().flatten()
            row_ref = absolute_ref[[ranksum_count],:].toarray().flatten() 
        else:
            row_tar = absolute_tar[ranksum_count, :].flatten()
            row_ref = absolute_ref[ranksum_count, :].flatten()
            
        ranksum_row_result = stats.ranksums(
            row_tar, 
            row_ref)
        ranksumtest_value.append(ranksum_row_result[0])
        ranksum_p_value.append(ranksum_row_result[1])
        ranksum_count+=1

    result['ranksumtest_value'] = np.array(ranksumtest_value)
    result['p_value'] = np.array(ranksum_p_value)

    if p_value == False:
        return result['ranksumtest_value']
    
    if p_value == True:
        return result


def calculate_wilkoxon_rank_sum_test(
        data: common_config.CalculationData,
    ) -> np.ndarray:

    logging.info("---calculating   'Wilcoxon rank-sum test'---")
    try:
        # If the dense matrices are already loaded, we can use them directly
        result = handle_errors(
            wilcoxon_ranksum,
            data.matrices.abs_dense_tar,
            data.matrices.abs_dense_ref
        )
        logging.debug(
            f'calculate_wilkoxon_rank_sum_test used '
            f"{type(data.matrices.abs_dense_tar)} absolute matrices"
        )        
        return result
    except KeyError:
        # Otherwise we use the sparse matrices
        result = handle_errors(
            wilcoxon_ranksum,
            data.matrices.abs_tar, 
            data.matrices.abs_ref
        )
        logging.debug(
            f'calculate_wilkoxon_rank_sum_test used '
            f"{type(data.matrices.abs_tar)} absolute matrices"
        )
        return result
    

# Chi Squared Test
def chisquare_test (
        absfreq_csr_tar, 
        absfreq_csr_ref, 
        p_value = False
    ) -> None | np.ndarray | dict[str,np.ndarray]:
    """
    This function implements Chi-squared test 
    (https://en.wikipedia.org/wiki/Chi-squared_test)
    The input 'absfreq_csr_tar' and 'absoulte2' should be 2 dataframes. 
    Columns represent documents and rows represents features.
    """

    number_of_terms = absfreq_csr_tar.shape[0]
    result = {}
    chisquare_value = []
    chisquare_p_value = []
    chisquare_count = 0
    corpus_tar = absfreq_csr_tar.sum()
    corpus_ref = absfreq_csr_ref.sum()
    corpus_total = corpus_tar + corpus_ref
    absfreq_tar_sum = absfreq_csr_tar.sum(axis = 1)
    absfreq_ref_sum = absfreq_csr_ref.sum(axis = 1)

    while chisquare_count < number_of_terms:
        obs_tar = absfreq_tar_sum[chisquare_count]
        obs_ref = absfreq_ref_sum[chisquare_count]
        obs_total = obs_tar + obs_ref

        if obs_total != 0:
            exp_tar = (corpus_tar * obs_total) / (corpus_total)
            exp_ref = obs_total - exp_tar  # Forces exp_tar + exp_ref = obs_total
            # This uses manual sum adjustment. exp_ref originally was:
            # exp_ref = (corpus_ref * (obs_tar + obs_ref) ) / (corpus_total)

            chisquare_row_result = stats.chisquare([obs_tar, obs_ref], f_exp= [exp_tar, exp_ref])
            chisquare_value.append(chisquare_row_result[0])
            chisquare_p_value.append(chisquare_row_result[1])
        else:
            chisquare_value.append(np.nan)
            chisquare_p_value.append(np.nan)

        chisquare_count+=1

    result['chisquare_value']= np.array(chisquare_value)
    result['p_value'] = np.array(chisquare_p_value)

    if p_value == False:
        return result['chisquare_value']
    
    if p_value == True:
        return result
    


def calculate_chi_squared_test(
        data: common_config.CalculationData,
    ) -> np.ndarray:

    logging.info("---calculating   'Chi-squared test'---")
    try:
        # If the dense matrices are already loaded, we can use them directly
        result = handle_errors(
            chisquare_test,
            data.matrices.abs_dense_tar, 
            data.matrices.abs_dense_ref
        )

        return result
    except KeyError:  # dense matrices not loaded
        result = handle_errors(
            chisquare_test,
            data.matrices.abs_tar, 
            data.matrices.abs_ref
        )

        return result


# Log Likelihood ratio test
def LLR_test (
        absfreq_csr_tar, 
        absfreq_csr_ref, 
        p_value = False
    ) -> None | np.ndarray | dict[str,np.ndarray]:
    """
    This function implements Chi-squared test 
    (https://en.wikipedia.org/wiki/Chi-squared_test)
    The input 'absfreq_csr_tar' and 'absoulte2' should be 2 dataframes. 
    Columns represent documents and rows represents features.
    """

    number_of_terms = absfreq_csr_tar.shape[0]
    result = {}
    LLR_value = []
    LLR_p_value = []
    LLR_count = 0
    corpus_tar = absfreq_csr_tar.sum()
    corpus_ref = absfreq_csr_ref.sum()
    absfreq_tar_sum = absfreq_csr_tar.sum(axis = 1)
    absfreq_ref_sum = absfreq_csr_ref.sum(axis = 1)

    while LLR_count < number_of_terms:
        obs1 = absfreq_tar_sum[LLR_count]
        obs2 = absfreq_ref_sum[LLR_count]
        total = obs1 + obs2

        exp1 = (corpus_tar * total) / (corpus_tar + corpus_ref)
        exp2 = total - exp1  # Erzwingt exp1 + exp2 = total
        # This uses manual sum adjustment. exp2 originally was:
        # exp2 = (corpus_ref * (obs1 + obs2) ) / (corpus_tar + corpus_ref)
        
        LLR_row_result = stats.power_divergence([obs1, obs2], f_exp= [exp1, exp2], lambda_='log-likelihood')
        LLR_value.append(LLR_row_result[0])
        LLR_p_value.append(LLR_row_result[1])
        LLR_count+=1

    result['LLR_value']= np.array(LLR_value)
    result['p_value'] = np.array(LLR_p_value)

    if p_value == False:
        return result['LLR_value']
    
    if p_value == True:
        return result


def calculate_log_likelihood_ratio_test(
        data: common_config.CalculationData
    ) -> np.ndarray:
        
    logging.info("---calculating   'Log-likelihood-Ratio test'---")
    result = handle_errors(
        LLR_test,
        data.matrices.abs_tar, 
        data.matrices.abs_ref
    )   

    return result