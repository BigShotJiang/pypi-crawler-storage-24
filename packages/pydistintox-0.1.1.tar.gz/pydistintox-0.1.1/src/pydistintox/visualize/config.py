# standard library imports
import csv
from typing import Literal


CSV_EXPORT_CONFIG = {
    'quoting': csv.QUOTE_ALL,
    'quotechar': '"',
    'doublequote': True,
    'escapechar': '\\',
    'sep': ',',  # Default separator
    'encoding': 'utf-8',  # Default encoding
}


HEATMAP_CONFIG = {
    'sort' : {
        'field': 'Correlation',
        'op': 'mean',
        'order': 'descending' ,
    },
    'size': {
        'width': 500,
        'height': 500,
        },
}


