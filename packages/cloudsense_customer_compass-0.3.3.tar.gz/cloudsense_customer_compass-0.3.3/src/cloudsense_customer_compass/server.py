"""CloudSense Customer Compass MCP server.

Run with: python -m cloudsense_customer_compass.server
Or via CLI: cloudsense-customer-compass
"""

import asyncio
import logging
import sys

from anyio import BrokenResourceError, ClosedResourceError
from mcp.server import Server
from mcp.server.stdio import stdio_server
import mcp.types as types

from . import __version__
from .tools import connect_lma, find_customer, get_customer_licenses

logger = logging.getLogger(__name__)

server = Server("cloudsense-customer-compass")

TOOLS = {
    "connect_lma": connect_lma,
    "find_customer": find_customer,
    "get_customer_licenses": get_customer_licenses,
}

SERVER_INSTRUCTIONS = (
    "You are connected to the CloudSense Customer Compass MCP server.\n\n"
    "SAFETY: This server is STRICTLY READ-ONLY against customer Salesforce orgs. "
    "NEVER deploy, push, insert, update, delete, or modify anything in the org.\n\n"
    "WORKFLOW:\n"
    "1. connect_lma -- Connect to the License Management Portal (FIRST step)\n"
    "2. find_customer -- Search for a customer by name, confirm selection\n"
    "3. get_customer_licenses -- Pass account_id and account_name from "
    "find_customer to retrieve license and org summary\n"
    "4. (more tools coming soon)\n\n"
    "STATE: Only LMA connection info is persisted between calls. "
    "Customer-specific data (account_id, account_name) must be passed "
    "explicitly from find_customer output to downstream tools.\n\n"
    "ORG RESOLUTION: If the user mentions an org, pass it as org_alias. "
    "If not, omit — the tool uses defaults or state.\n"
)


@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name=mod.TOOL_DEFINITION["name"],
            description=mod.TOOL_DEFINITION["description"],
            inputSchema=mod.TOOL_DEFINITION["inputSchema"],
        )
        for mod in TOOLS.values()
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    tool_module = TOOLS.get(name)
    if tool_module is None:
        return [types.TextContent(
            type="text",
            text=f"STATUS: ERROR\n\nUnknown tool: {name}",
        )]
    try:
        result = await tool_module.run(arguments)
    except Exception as e:
        logger.exception("Tool '%s' failed with unhandled exception", name)
        error_type = type(e).__name__
        error_detail = str(e)
        result = (
            f"STATUS: UNEXPECTED_ERROR\n\n"
            f"Tool `{name}` failed with {error_type}: {error_detail}\n\n"
            f"Diagnose the error and tell the user what went wrong in "
            f"plain language. Common causes:\n"
            f"- 'SfCliError' or 'TimeoutExpired': Salesforce CLI issue — "
            f"check if the org is still authorized, or if sf CLI is "
            f"installed and on PATH.\n"
            f"- 'FileNotFoundError': A required file or command is missing.\n"
            f"- 'JSONDecodeError': The CLI returned unexpected output.\n"
            f"- 'SafetyViolationError': The command was blocked by the "
            f"read-only safety policy.\n\n"
            f"Ask the user if they'd like to try again or need help "
            f"resolving the issue."
        )
    return [types.TextContent(type="text", text=result)]


def _is_disconnect(exc: BaseException) -> bool:
    if isinstance(exc, (BrokenResourceError, ClosedResourceError)):
        return True
    if isinstance(exc, BaseExceptionGroup):
        return all(_is_disconnect(e) for e in exc.exceptions)
    return False


async def _run_server():
    logger.info("CloudSense Customer Compass v%s starting...", __version__)
    try:
        async with stdio_server() as (read_stream, write_stream):
            init_options = server.create_initialization_options()
            init_options.instructions = SERVER_INSTRUCTIONS
            await server.run(read_stream, write_stream, init_options)
    except BaseExceptionGroup as eg:
        if _is_disconnect(eg):
            logger.info("Client disconnected — shutting down.")
        else:
            raise
    except (BrokenResourceError, ClosedResourceError):
        logger.info("Client disconnected — shutting down.")


def main():
    logging.basicConfig(level=logging.INFO)
    try:
        asyncio.run(_run_server())
    except KeyboardInterrupt:
        pass
    except (BrokenPipeError, EOFError):
        logger.info("Pipe closed — exiting.")
    sys.exit(0)


if __name__ == "__main__":
    main()
