
class GenericViewException(Exception):
    pass
