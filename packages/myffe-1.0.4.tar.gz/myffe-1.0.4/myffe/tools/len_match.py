﻿from myffe.tools.color_printer import ColorPrinter


def len_match(list1, list2):
    if len(list1) != len(list2):
        ColorPrinter.print_error(f'错误: 列数量 ({len(list1)}) 与方法数量 ({len(list2)}) 不匹配')
        return False
    return True
