import numpy as np

def ok_input(input_type, max_value=np.inf, min_value=-np.inf):
    """
    交互式输入验证
    
    提供类型安全的交互式输入功能，支持整数、浮点数和字符串输入，
    自动进行范围验证和错误处理。
    
    Args:
        input_type (str): 输入类型，支持'int'、'float'或'str'
        max_value (float): 最大值限制，仅适用于数字类型，默认为正无穷
        min_value (float): 最小值限制，仅适用于数字类型，默认为负无穷
        
    Returns:
        int, float or str: 验证通过的用户输入值
        
    Raises:
        ValueError: 当输入类型不匹配或超出范围时
        
    Example:
        # 输入整数
        n_estimators = ok_input('int', min_value=1, max_value=1000)
        
        # 输入浮点数
        learning_rate = ok_input('float', min_value=0.01, max_value=1.0)
        
        # 输入字符串
        name = ok_input('str')
    """
    
    # 对于字符串类型，使用普通的input函数
    if input_type == 'str':
        return input('请输入字符串：')
    
    # 对于数字类型，进行类型转换和范围验证
    while True:
        try:
            if input_type == 'int':
                value = int(input(f'请输入{input_type}({min_value}-{max_value}之间的整数)：'))
                if value <= min_value or value >= max_value:
                    print(f'输入错误请输入{min_value}-{max_value}之间的整数')
                    continue
            elif input_type == 'float':
                value = float(input(f'请输入{input_type}({min_value}-{max_value}之间的小数)：'))
                if value <= min_value or value >= max_value:
                    print(f'输入错误请输入{min_value}-{max_value}之间的小数')
                    continue
            else:
                print('输入错误请输入int、float或str')
                continue
            return value
        except ValueError:
            print(f'输入错误请输入有效的{input_type}')
            continue