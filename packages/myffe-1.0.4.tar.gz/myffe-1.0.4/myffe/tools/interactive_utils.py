from myffe.tools.interactive import interactive
from myffe.tools.color_printer import ColorPrinter

def get_interactive_choice(title, description, auto_test=False):
    """获取用户的交互式选择
    
    Args:
        title: 交互标题
        description: 交互描述
        auto_test: 是否自动测试模式
    
    Returns:
        bool: 是否使用智能推荐
    """
    inter_choice = False
    
    if auto_test:
        print("\033[31m下面进行测试使用智能推荐\033[0m")
        inter_choice = True
    else:
        inter_tem = interactive(['ok', 'no'], title=title, description=description, min_select=1, max_select=1).run()
        if not inter_tem:
            inter_choice = False
        else:
            inter_tem = inter_tem[0]
            if inter_tem == 'ok':
                inter_choice = True
            else:
                inter_choice = False
    
    return inter_choice
