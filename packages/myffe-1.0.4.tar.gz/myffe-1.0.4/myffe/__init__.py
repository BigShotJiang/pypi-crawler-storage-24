# myffe - Feature Engineering Framework
# 版本: 1.0.4
# 主要功能: 完整的特征工程工具链，支持数据清洗、特征提取、样本处理等

"""
myffe (My First Feature Engine) v1.0.4

myffe 是 "My First Feature Engine" 的缩写，一个工业级的特征工程框架，提供完整的特征工程工具链，支持数据清洗、特征提取、样本处理等功能。

核心特性:
- 模块化设计，易于扩展
- 支持多种数据预处理方法
- 提供预定义的特征工程路线
- 支持自动参数推荐
- 工业级封装，外部接口简洁易用
- 纯Python实现，跨平台兼容

使用示例:

```python
from myffe import FFE, process_data

# 简单使用 - 直接处理数据
import pandas as pd
data = pd.read_csv('data.csv')
processed_data = process_data(data, 'label', route_number=1)

# 高级使用 - 自定义配置
ffe = FFE()
console, tools = ffe.create_pipeline('label', route_number=3)
result = console(tools, data, save_path='processed_data.csv')
```
"""


# 内部模块导入
from .core.FFE_config import FFE_config
from .core.FFE_console import FFE_console
from .core.master_judge import evaluate_dataset, print_evaluation_result
from .tools.system_validator import SystemValidator
from .tools.Loggerv1_1 import logger, set_logging_enabled, set_logging_mode, set_logging_path, get_logging_status
from .route.src.auto_route import auto_routes
from .route.src.predefined_routes import get_route_params, show_available_routes, show_routes_visual
from .route.src.route_config import RouteConfig
from .tools.visualize_route import visualize_route
from .tools.data_description import describe_data

# 外部接口封装
class FFE:
    """
    特征工程框架主类
    提供简洁的外部接口，内部实现复杂逻辑
    """
    
    def __init__(self, log_level='info'):
        """
        初始化FFE框架
        
        Args:
            log_level: 日志级别，默认为'info'
        """
        self.log_level = log_level
        set_logging_enabled(True)
    
    def create_pipeline(self, data_label, route_number=None, route=None, use_modin=False, **kwargs):
        """
        创建特征工程流水线

        Args:
            data_label (str): 标签列名称
            route_number (int, optional): 预定义路线编号
            route (dict, optional): auto_detect_route 产生的参数字典
            use_modin (bool): 是否使用 Modin 进行数据处理，默认为 False
            **kwargs: 其他参数，如batch_size等

        Returns:
            tuple: (console, clean_tools) - 控制台实例和预处理工具字典
        """
        # 如果传入了 route 参数（来自 auto_detect_route），优先使用
        if route is not None:
            config = FFE_config(route)
            tools_list = list(route.keys())
            clean_tools = config(tools_list)
        # 如果指定了路线编号，使用预定义路线
        elif route_number is not None:
            params = get_route_params(route_number)
            if params:
                config = FFE_config(params)
                tools_list = list(params.keys())
                clean_tools = config(tools_list)
            else:
                raise ValueError(f"无效的路线编号: {route_number}")
        else:
            # 默认使用基础路线
            params = get_route_params(1)
            config = FFE_config(params)
            clean_tools = config(list(params.keys()))
        
        # 创建控制台实例
        console = FFE_console(data_label=data_label, use_modin=use_modin, **kwargs)
        
        return console, clean_tools
    
    def auto_detect_route(self, data, label_columns=None, drop_threshold=0.5):
        """
        自动检测数据并推荐特征工程路线
        
        Args:
            data (DataFrame): 输入数据
            label_columns (list, optional): 标签列名称
            drop_threshold (float, optional): 缺失值阈值
        
        Returns:
            dict: 推荐的特征工程参数
        """
        auto_route = auto_routes(label_columns=label_columns)
        # 保存数据到临时文件
        import tempfile
        import os
        
        with tempfile.NamedTemporaryFile(suffix='.csv', delete=False) as temp:
            temp_path = temp.name
            data.to_csv(temp_path, index=False)
        
        try:
            route = auto_route(temp_path)
        finally:
            os.unlink(temp_path)
        
        return route
    
    def validate_system(self):
        """
        验证系统状态
        
        Returns:
            dict: 系统状态验证结果
        """
        validator = SystemValidator()
        return validator.validate_all()

# 便捷函数
def process_data(data, data_label, route_number=None, route=None, save_path='./processed_data.csv', use_modin=False, **kwargs):
    """
    处理数据的便捷函数

    Args:
        data (DataFrame): 输入数据
        data_label (str): 标签列名称
        route_number (int, optional): 预定义路线编号
        route (dict, optional): auto_detect_route 产生的参数字典
        save_path (str): 处理后数据的保存路径
        use_modin (bool): 是否使用 Modin 进行数据处理，默认为 False
        **kwargs: 其他参数

    Returns:
        DataFrame: 处理后的数据
    """
    ffe = FFE()
    console, clean_tools = ffe.create_pipeline(data_label, route_number=route_number, route=route, use_modin=use_modin, **kwargs)
    console(clean_tools, data, save_path=save_path, describe_data=True)
    return console.data

def get_recommended_route(data, label_columns=None):
    """
    获取推荐的特征工程路线
    
    Args:
        data (DataFrame): 输入数据
        label_columns (list, optional): 标签列名称
    
    Returns:
        dict: 推荐的特征工程参数
    """
    ffe = FFE()
    return ffe.auto_detect_route(data, label_columns)

# 导出接口
__all__ = [
    'FFE',
    'FFE_config',
    'FFE_console',
    'SystemValidator',
    'logger',
    'set_logging_enabled',
    'set_logging_mode',
    'set_logging_path',
    'get_logging_status',
    'get_route_params',
    'show_available_routes',
    'show_routes_visual',
    'auto_routes',
    'RouteConfig',
    'visualize_route',
    'describe_data',
    'evaluate_dataset',
    'print_evaluation_result',
    'process_data',
    'get_recommended_route'
]

# 版本信息
__version__ = '1.0.4'
