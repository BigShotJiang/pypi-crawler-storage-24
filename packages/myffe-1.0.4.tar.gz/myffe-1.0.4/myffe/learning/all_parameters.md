# myffe 预处理模块参数文档

本文档汇总了 myffe 框架中所有预处理模块的参数配置信息，按照模块分类展示，包括所有可能的占位参数。

## 1. 缺失值处理 (nan_preprocessing.py)

### 主要参数结构
```python
shortcut_nan = {
    'nan_ways': [
        {
            'col': '列名',  # 要处理的列名
            'method': '处理方法',  # 可选值：'fill_nan_knn', 'fill_nan_mean', 'fill_nan_mode', 'fill_nan_forward', 'fill_nan_backward', 'fill_nan_intelligent', 'fill_nan_ei', 'drop_col_high_missing', 'specify_fill'
            # 所有占位参数
            'drop_threshold': 0.5,  # 高缺失值删除阈值
            'knn_n_neighbors': 5,  # KNN 近邻数量
            'ei_model_type': 'linear',  # EI 模型类型
            'poly_degree': 2,  # 多项式特征阶数
            'fill_value': ''  # 自定义填充值
        }
    ]
}
```

### 方法特定参数

#### KNN 填充
```python
{
    'col': '列名',
    'method': 'fill_nan_knn',
    'knn_n_neighbors': 5,  # KNN 近邻数量
    'drop_threshold': 0.5,  # 占位参数
    'ei_model_type': 'linear',  # 占位参数
    'poly_degree': 2,  # 占位参数
    'fill_value': ''  # 占位参数
}
```

#### 均值填充
```python
{
    'col': '列名',
    'method': 'fill_nan_mean',
    'drop_threshold': 0.5,  # 占位参数
    'knn_n_neighbors': 5,  # 占位参数
    'ei_model_type': 'linear',  # 占位参数
    'poly_degree': 2,  # 占位参数
    'fill_value': ''  # 占位参数
}
```

#### 众数填充
```python
{
    'col': '列名',
    'method': 'fill_nan_mode',
    'drop_threshold': 0.5,  # 占位参数
    'knn_n_neighbors': 5,  # 占位参数
    'ei_model_type': 'linear',  # 占位参数
    'poly_degree': 2,  # 占位参数
    'fill_value': ''  # 占位参数
}
```

#### 前向填充
```python
{
    'col': '列名',
    'method': 'fill_nan_forward',
    'drop_threshold': 0.5,  # 占位参数
    'knn_n_neighbors': 5,  # 占位参数
    'ei_model_type': 'linear',  # 占位参数
    'poly_degree': 2,  # 占位参数
    'fill_value': ''  # 占位参数
}
```

#### 后向填充
```python
{
    'col': '列名',
    'method': 'fill_nan_backward',
    'drop_threshold': 0.5,  # 占位参数
    'knn_n_neighbors': 5,  # 占位参数
    'ei_model_type': 'linear',  # 占位参数
    'poly_degree': 2,  # 占位参数
    'fill_value': ''  # 占位参数
}
```

#### 智能填充
```python
{
    'col': '列名',
    'method': 'fill_nan_intelligent',
    'drop_threshold': 0.5,  # 占位参数
    'knn_n_neighbors': 5,  # 占位参数
    'ei_model_type': 'linear',  # 占位参数
    'poly_degree': 2,  # 占位参数
    'fill_value': ''  # 占位参数
}
```

#### EI 填充
```python
{
    'col': '列名',
    'method': 'fill_nan_ei',
    'ei_model_type': 'linear',  # EI 模型类型，可选值：'linear', 'ridge', 'lasso', 'random_forest', 'gradient_boosting'
    'poly_degree': 2,  # 多项式特征阶数
    'drop_threshold': 0.5,  # 占位参数
    'knn_n_neighbors': 5,  # 占位参数
    'fill_value': ''  # 占位参数
}
```

#### 删除高缺失值列
```python
{
    'col': '列名',
    'method': 'drop_col_high_missing',
    'drop_threshold': 0.5,  # 高缺失值删除阈值
    'knn_n_neighbors': 5,  # 占位参数
    'ei_model_type': 'linear',  # 占位参数
    'poly_degree': 2,  # 占位参数
    'fill_value': ''  # 占位参数
}
```

#### 自定义填充
```python
{
    'col': '列名',
    'method': 'specify_fill',
    'fill_value': 0,  # 自定义填充值
    'drop_threshold': 0.5,  # 占位参数
    'knn_n_neighbors': 5,  # 占位参数
    'ei_model_type': 'linear',  # 占位参数
    'poly_degree': 2,  # 占位参数
}
```

## 2. 异常值检测 (outlier_preprocessing.py)

### 主要参数结构
```python
shortcut_outlier = {
    'outlier_choice': '检测方法',  # 可选值：'thres_sigma_auto', 'boxplot', 'isolation_forest', 'multivariate'
    'row_drop_thres': 3.0,  # 行删除阈值
    'auto_drop_row': False,  # 是否自动删除行
    'outlier_action': '处理方式',  # 可选值：'drop', 'replace'
    'contamination': 0.1,  # 异常值比例
    'specify_auto_drop_row_extr': 'auto',  # 检测列指定方式
    'specify_row': None  # 指定行
}
```

### 方法特定参数

#### Thres Sigma Auto 方法
```python
{
    'outlier_choice': 'thres_sigma_auto',
    'row_drop_thres': 3.0,  # 标准差倍数阈值
    'outlier_action': 'drop',  # 处理方式
    'auto_drop_row': False,  # 占位参数
    'contamination': 0.1,  # 占位参数
    'specify_auto_drop_row_extr': 'auto',  # 检测列指定方式
    'specify_row': None  # 占位参数
}
```

#### Boxplot 方法
```python
{
    'outlier_choice': 'boxplot',
    'outlier_action': 'drop',  # 处理方式
    'row_drop_thres': 3.0,  # 占位参数
    'auto_drop_row': False,  # 占位参数
    'contamination': 0.1,  # 占位参数
    'specify_auto_drop_row_extr': 'auto',  # 检测列指定方式
    'specify_row': None  # 占位参数
}
```

#### Isolation Forest 方法
```python
{
    'outlier_choice': 'isolation_forest',
    'contamination': 0.1,  # 异常值比例
    'outlier_action': 'drop',  # 处理方式
    'row_drop_thres': 3.0,  # 占位参数
    'auto_drop_row': False,  # 占位参数
    'specify_auto_drop_row_extr': 'auto',  # 检测列指定方式
    'specify_row': None  # 占位参数
}
```

#### Multivariate 方法
```python
{
    'outlier_choice': 'multivariate',
    'contamination': 0.1,  # 异常值比例
    'outlier_action': 'drop',  # 处理方式
    'row_drop_thres': 3.0,  # 占位参数
    'auto_drop_row': False,  # 占位参数
    'specify_auto_drop_row_extr': 'auto',  # 检测列指定方式
    'specify_row': None  # 占位参数
}
```

## 3. 字符串处理 (str_preprocessing.py)

### 主要参数结构
```python
shortcut_str = {
    'str_ways': [
        {
            'col': '列名',  # 要处理的列名
            'method': '处理方法'  # 可选值：'tfidf', 'label_encoding', 'drop'
        }
    ],
    'tfidf_min_df': 1,  # TF-IDF 最小文档频率
    'tfidf_max_df': 1.0,  # TF-IDF 最大文档频率
    'use_chinese_tokenizer': False  # 是否使用中文分词
}
```

## 4. 时间特征提取 (time_preprocessing.py)

### 主要参数结构
```python
shortcut_time = {
    'time_ways': [
        {
            'col': '列名',  # 时间列名
            'format': '时间格式',  # 例如：'%Y-%m-%d %H:%M:%S'
            'extract_features': ['year', 'month', 'day', 'hour', 'minute', 'second', 'dayofweek', 'quarter']  # 要提取的特征
        }
    ]
}
```

## 5. 归一化处理 (normalized_preprocessing.py)

### 主要参数结构
```python
shortcut_normalized = {
    'normalized_ways': [
        {
            'col': '列名',  # 要归一化的列名
            'method': '归一化方法'  # 可选值：'minmax', 'robust', 'maxabs'
        }
    ]
}
```

### 方法特定参数

#### MinMax 归一化
```python
{
    'col': '列名',
    'method': 'minmax',
    'feature_range': (0, 1)  # 归一化范围
}
```

#### Robust 归一化
```python
{
    'col': '列名',
    'method': 'robust',
    'quantile_range': (25.0, 75.0)  # 分位数范围
}
```

#### MaxAbs 归一化
```python
{
    'col': '列名',
    'method': 'maxabs'
}
```

## 6. 标准化处理 (standard_preprocessing.py)

### 主要参数结构
```python
shortcut_standard = {
    'standard_ways': [
        {
            'col': '列名',  # 要标准化的列名
            'method': '标准化方法'  # 可选值：'zscore', 'robust'
        }
    ]
}
```

### 方法特定参数

#### Z-score 标准化
```python
{
    'col': '列名',
    'method': 'zscore',
    'with_mean': True,  # 是否减去均值
    'with_std': True  # 是否除以标准差
}
```

#### Robust 标准化
```python
{
    'col': '列名',
    'method': 'robust',
    'with_centering': True,  # 是否中心化
    'with_scaling': True,  # 是否缩放
    'quantile_range': (25.0, 75.0)  # 分位数范围
}
```

## 7. 样本处理 (sample_preprocessing.py)

### 主要参数结构
```python
shortcut_sample = {
    'sample_ways': [
        {
            'method': ['处理方法'],  # 可选值：'multi_class_balance', 'MY_high_sample', 'skip'
            # 所有占位参数
            'balance_method': 'oversample',  # 平衡方法
            'random_state': 42,  # 随机种子
            'high_sample_selection': 'RandomOverSampler',  # 高级采样方法选择
            'smote_k_neighbors': 5,  # SMOTE 邻居数
            'adasyn_n_neighbors': 5,  # ADASYN 邻居数
            'borderline_smote_k_neighbors': 5,  # BorderlineSMOTE 邻居数
            'svm_smote_k_neighbors': 5,  # SVMSMOTE 邻居数
            'enn_n_neighbors': 5  # EditedNearestNeighbours 邻居数
        }
    ]
}
```

### 方法特定参数

#### 多分类平衡
```python
{
    'method': ['multi_class_balance'],
    'balance_method': 'oversample',  # 平衡方法，可选值：'oversample', 'undersample'
    'random_state': 42,  # 随机种子
    'high_sample_selection': 'RandomOverSampler',  # 占位参数
    'smote_k_neighbors': 5,  # 占位参数
    'adasyn_n_neighbors': 5,  # 占位参数
    'borderline_smote_k_neighbors': 5,  # 占位参数
    'svm_smote_k_neighbors': 5,  # 占位参数
    'enn_n_neighbors': 5  # 占位参数
}
```

#### 高级采样
```python
{
    'method': ['MY_high_sample'],
    'high_sample_selection': 'SMOTE',  # 高级采样方法选择
    'smote_k_neighbors': 5,  # SMOTE 邻居数
    'adasyn_n_neighbors': 5,  # 占位参数
    'borderline_smote_k_neighbors': 5,  # 占位参数
    'svm_smote_k_neighbors': 5,  # 占位参数
    'enn_n_neighbors': 5,  # 占位参数
    'balance_method': 'oversample',  # 占位参数
    'random_state': 42  # 占位参数
}
```

#### 跳过采样
```python
{
    'method': ['skip'],
    'balance_method': 'oversample',  # 占位参数
    'random_state': 42,  # 占位参数
    'high_sample_selection': 'RandomOverSampler',  # 占位参数
    'smote_k_neighbors': 5,  # 占位参数
    'adasyn_n_neighbors': 5,  # 占位参数
    'borderline_smote_k_neighbors': 5,  # 占位参数
    'svm_smote_k_neighbors': 5,  # 占位参数
    'enn_n_neighbors': 5  # 占位参数
}
```

## 8. 相关性分析和特征工程 (relative_preprocessing.py)

### 主要参数结构
```python
shortcut_relative = {
    # 线性特征组合
    'linear_cols': ['列名1', '列名2'],  # 用于线性组合的列
    'linear_threshold': 0.75,  # 线性组合相关系数阈值
    
    # 非线性特征构建
    'feature_cols': ['列名1', '列名2'],  # 用于特征构建的列
    'feature_threshold': 0.75,  # 特征构建 R² 阈值
    'relation_func': 'func1',  # 特征构建函数类型，可选值：'func1', 'func2', 'func3', 'func4', 'func5'
    
    # 特征重要性评估
    'n_features': 10,  # 特征重要性评估保留的特征数量
    
    # 降维处理
    'pca_cols': ['列名1', '列名2'],  # 用于降维的列
    'n_components': 10,  # 降维后的维度
    'kernel_selection': 'pca'  # 降维方法，可选值：'pca', 'lda', 'kernel'
}
```

## 9. 指定行列删除 (specify_preprocessing.py)

### 主要参数结构
```python
shortcut_specify = {
    'drop_row': [0, 1, 2],  # 要删除的行索引
    'drop_col': ['列名1', '列名2']  # 要删除的列名
}
```

## 10. 整体配置结构

### 完整配置示例
```python
config = {
    'label': '标签列名',
    'nan': shortcut_nan,
    'outlier': shortcut_outlier,
    'str': shortcut_str,
    'time': shortcut_time,
    'normalized': shortcut_normalized,
    'standard': shortcut_standard,
    'sample': shortcut_sample,
    'relative': shortcut_relative,
    'specify': shortcut_specify
}
```

### 跳过处理
对于任何预处理模块，如果不需要进行处理，可以将其参数设置为 'skip'：

```python
config = {
    'label': '标签列名',
    'nan': 'skip',  # 跳过缺失值处理
    'outlier': shortcut_outlier,
    # 其他模块配置...
}
```