﻿"""
这个文件用来配置参数，包括路由参数、清理参数、可视化参数等。
"""

import sys
import os

# 添加MFM目录到路径
current_dir = os.path.dirname(os.path.abspath(__file__))
route_dir = os.path.dirname(current_dir)
ffe_dir = os.path.dirname(route_dir)
mfm_dir = os.path.dirname(os.path.dirname(ffe_dir))  # 向上两级目录，得到 D:\HP\pythonwork\MFM
if mfm_dir not in sys.path:
    sys.path.append(mfm_dir)

from myffe.tools.color_printer import ColorPrinter


class RouteConfig:
    """路由配置类"""
    def __init__(self):
        pass
    
    def __call__(self, tools, data):
        self.tools = tools
        self.data = data
        return self.start()
    
    def start(self):
        """开始路由配置"""
        self.params = {}
        ColorPrinter.print_info("开始路由配置")
        
        # 配置各个工具的参数
        self.params['nan_preprocessing'] = self.get_nan_params()
        self.params['specify_preprocessing'] = self.get_drop_params()
        self.params['sample_preprocessing'] = self.get_sample_params()
        self.params['standard_preprocessing'] = self.get_standard_params()
        self.params['normalized_preprocessing'] = self.get_normalize_params()
        self.params['relative_preprocessing'] = self.get_relative_params()
        self.params['str_preprocessing'] = self.get_str_params()
        self.params['outlier_preprocessing'] = self.get_outlier_params()
        self.params['time_preprocessing'] = self.get_time_params()
        
        ColorPrinter.print_success("路由配置完成")
        return self.params
    
    def get_nan_params(self):
        """获取NaN参数"""
        from MFM.FFE.FFEv3_2.route.py_tools.nan_py import nan_py
        nan_processor = nan_py(self.data)
        return nan_processor()
    
    def get_drop_params(self):
        """获取指定行列删除参数"""
        from MFM.FFE.FFEv3_2.route.py_tools.specify_py import specify_py
        specify_processor = specify_py(self.data)
        return specify_processor()

    def get_sample_params(self):
        """获取采样参数"""
        from MFM.FFE.FFEv3_2.route.py_tools.sample_py import sample_py
        sample_processor = sample_py(self.data)
        return sample_processor()

    def get_standard_params(self):
        """获取标准化参数"""
        from MFM.FFE.FFEv3_2.route.py_tools.standard_py import standard_py
        standard_processor = standard_py(self.data)
        return standard_processor()
    
    def get_normalize_params(self):
        """获取归一化参数"""
        from MFM.FFE.FFEv3_2.route.py_tools.normalize_py import normalize_py
        normalize_processor = normalize_py(self.data)
        return normalize_processor()
    
    def get_relative_params(self):
        """获取相对参数"""
        from MFM.FFE.FFEv3_2.route.py_tools.relative_py import relative_py
        relative_processor = relative_py(self.data)
        return relative_processor()

    def get_str_params(self):
        """获取字符串参数"""
        from MFM.FFE.FFEv3_2.route.py_tools.str_py import str_py
        str_processor = str_py(self.data)
        return str_processor()
    
    def get_outlier_params(self):
        """获取异常值参数"""
        from MFM.FFE.FFEv3_2.route.py_tools.outlier_py import outlier_py
        outlier_processor = outlier_py(self.data)
        return outlier_processor()
    
    def get_time_params(self):
        """获取时间参数"""
        from MFM.FFE.FFEv3_2.route.py_tools.time_py import time_py
        time_processor = time_py(self.data)
        return time_processor()




































