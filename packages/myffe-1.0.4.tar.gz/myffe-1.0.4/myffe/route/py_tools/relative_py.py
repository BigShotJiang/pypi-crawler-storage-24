import pandas as pd
import numpy as np
from scipy import stats
from myffe.tools.interactive import interactive
from myffe.tools.color_printer import ColorPrinter
from myffe.route.py_tools.function.relativefunction import calculate_correlation_matrix, analyze_correlation_features, analyze_data_features

def analyze_relative_distribution(data, selected_cols=None, label_col=None):
    """分析数据的相关性分布，推荐适合的特征工程方法
    
    Args:
        data: pandas DataFrame，输入数据
        selected_cols: list，用户选择的列，默认为 None（使用所有数值列）
        label_col: str，标签列名称，默认为 None
    
    Returns:
        dict: 包含特征工程参数的字典
    """
    # 初始化处理路线
    relative_route = {}
    # 找出数值列
    numeric_columns = data.select_dtypes(include=['number']).columns.tolist()
    
    # 排除标签列
    if label_col and label_col in numeric_columns:
        numeric_columns.remove(label_col)
    
    # 使用用户选择的列或所有数值列
    if selected_cols is None:
        selected_cols = numeric_columns
    else:
        # 从用户选择的列中排除标签列
        if label_col and label_col in selected_cols:
            selected_cols.remove(label_col)
    
    # 构建参数配置
    relative_params = {
        'linear_cols': selected_cols,
        'linear_threshold': 0.75,
        'feature_cols': selected_cols,
        'feature_threshold': 0.75,
        'relation_func': 'func1',
        'pca_cols': selected_cols,
        'n_components': 10,
        'kernel_selection': 'pca',
        'n_features': 10
    }
    
    relative_route['relative_preprocessing'] = relative_params
    
    return relative_route

def relative_py(data, auto_test=False, label_col=None):
    """Python实现的相关性分析和特征工程
    
    Args:
        data: pandas DataFrame，输入数据
        auto_test: bool，是否自动测试模式，默认为 False
        label_col: str，标签列名称，默认为 None
    
    Returns:
        dict: 包含特征工程参数的字典
    """
    # 找出数值列
    numeric_columns = data.select_dtypes(include=['number']).columns.tolist()
    
    # 排除标签列
    if label_col and label_col in numeric_columns:
        numeric_columns.remove(label_col)
    
    # 如果不是自动测试模式，先分析所有列生成推荐，再让用户选择
    if not auto_test and numeric_columns:
#region 显示标题
        ColorPrinter.print("\n" + "=" * 80, 'cyan')
        ColorPrinter.print("相关性分析和特征工程", 'cyan')
        ColorPrinter.print("=" * 80, 'cyan')
#endregion
        
        # 先分析所有数值列，生成初始推荐
        initial_analysis = analyze_relative_distribution(data, label_col=label_col)
        relative_params = initial_analysis['relative_preprocessing']
        
#region 显示初始推荐结果
        ColorPrinter.print_info("\n初始推荐结果（基于所有数值列）:")
        ColorPrinter.print_info("- 将自动执行以下特征工程方法（如果参数存在）:")
        ColorPrinter.print_info("  - 线性特征组合 (linear_plus)")
        ColorPrinter.print_info("  - 非线性特征构建 (feature_plus)")
        ColorPrinter.print_info("  - 特征重要性评估 (feature_importance)")
        ColorPrinter.print_info("  - 降维处理 (pca_lda_kernel)")
#endregion
        
#region 显示数据特征
        ColorPrinter.print_info(f"- 数值列数量: {len(numeric_columns)}")
        ColorPrinter.print_info(f"- 数据行数: {len(data)}")
        ColorPrinter.print("\n" + "=" * 80, 'cyan')
#endregion
        
        # 运行交互式选择器并获取选择结果
        selected_cols = interactive(
            options=numeric_columns,
            title="请选择要进行相关性分析的列",
            description="选择您需要处理的列。使用上下箭头键移动，按 'm' 选择/取消选择，按 Enter 确认",
            min_select=2,  # 至少选择2列进行相关性分析
            max_select=len(numeric_columns)
        ).run()
        ColorPrinter.print_success(f"\n已选择列: {selected_cols}")
        
        # 根据用户选择的列重新生成推荐
        final_result = analyze_relative_distribution(data, selected_cols, label_col=label_col)
        
        # 显示最终推荐结果
        final_params = final_result['relative_preprocessing']
        ColorPrinter.print_info("\n最终推荐结果（基于选择的列）:")
        ColorPrinter.print_info("- 将自动执行以下特征工程方法（如果参数存在）:")
        ColorPrinter.print_info("  - 线性特征组合 (linear_plus)")
        ColorPrinter.print_info("  - 非线性特征构建 (feature_plus)")
        ColorPrinter.print_info("  - 特征重要性评估 (feature_importance)")
        ColorPrinter.print_info("  - 降维处理 (pca_lda_kernel)")
        
        return final_result
    else:
        # 自动测试模式或没有数值列，使用所有数值列
        return analyze_relative_distribution(data, label_col=label_col)


if __name__ == "__main__":
    """测试相关性分析和特征工程"""
    import pandas as pd
    import numpy as np
    import argparse
    
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='测试相关性分析和特征工程')
    parser.add_argument('--interactive', action='store_true', help='运行交互式测试')
    args = parser.parse_args()
    
    # 生成测试数据
    np.random.seed(42)
    data = pd.DataFrame({
        'feature1': np.random.normal(0, 1, 100),
        'feature2': np.random.normal(0, 1, 100),
        'feature3': np.random.normal(0, 1, 100),
        'feature4': np.random.normal(0, 1, 100),
        'feature5': np.random.normal(0, 1, 100),
        'label': np.random.randint(0, 2, 100)
    })
    
    # 测试自动模式
    ColorPrinter.print("测试自动模式:", 'cyan')
    result_auto = relative_py(data, auto_test=True, label_col='label')
    ColorPrinter.print_success(f"自动模式结果: {result_auto}")
    
    # 测试交互式模式（需要用户输入）
    if args.interactive:
        ColorPrinter.print("\n运行交互式测试:", 'cyan')
        ColorPrinter.print_info("请按照提示选择要进行相关性分析的列")
        result_interactive = relative_py(data, auto_test=False, label_col='label')
        ColorPrinter.print_success(f"交互式模式结果: {result_interactive}")
    else:
        ColorPrinter.print("\n测试交互式模式:", 'cyan')
        ColorPrinter.print_info("注意：交互式模式需要用户输入，在命令行中运行以下命令进行交互式测试：")
        ColorPrinter.print_info("python relative_py.py --interactive")
        # 为了避免阻塞测试，这里注释掉交互式测试
        # result_interactive = relative_py(data, auto_test=False, label_col='label')
        # ColorPrinter.print_success(f"交互式模式结果: {result_interactive}")
    
    # 测试无标签列情况
    ColorPrinter.print("\n测试无标签列情况:", 'cyan')
    result_no_label = relative_py(data, auto_test=True)
    ColorPrinter.print_success(f"无标签列结果: {result_no_label}")
    
    # 测试自定义选择列情况
    ColorPrinter.print("\n测试自定义选择列情况:", 'cyan')
    result_custom_cols = analyze_relative_distribution(data, selected_cols=['feature1', 'feature2', 'feature3'], label_col='label')
    ColorPrinter.print_success(f"自定义选择列结果: {result_custom_cols}")
    
    # 手动测试：直接构建参数并测试
    ColorPrinter.print("\n手动测试:", 'cyan')
    ColorPrinter.print_info("手动构建特征工程参数并测试")
    
    # 手动构建参数
    manual_params = {
        'relative_preprocessing': {
            'linear_cols': ['feature1', 'feature2', 'feature3'],
            'linear_threshold': 0.7,
            'feature_cols': ['feature1', 'feature2', 'feature3'],
            'feature_threshold': 0.7,
            'relation_func': 'func1',
            'pca_cols': ['feature1', 'feature2', 'feature3', 'feature4', 'feature5'],
            'n_components': 3,
            'kernel_selection': 'pca',
            'n_features': 4
        }
    }
    
    ColorPrinter.print_success(f"手动构建的参数: {manual_params}")
    ColorPrinter.print_info("这些参数可以直接用于RelativePreprocessing类")
