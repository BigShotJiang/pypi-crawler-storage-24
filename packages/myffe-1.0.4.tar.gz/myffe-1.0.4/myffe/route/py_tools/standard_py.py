import pandas as pd
import numpy as np
from scipy import stats
import time

# 导入所需模块
import sys
import os

# 添加MFM目录到路径
current_dir = os.path.dirname(os.path.abspath(__file__))
# py_tools -> route -> FFEv3_2 -> FFE -> MFM -> 根目录
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))))
if root_dir not in sys.path:
    sys.path.append(root_dir)

from myffe.tools.interactive import interactive
from myffe.tools.color_printer import ColorPrinter
from myffe.tools.len_match import len_match
from myffe.tools.visualize_route import visualize_route
from myffe.tools.interactive_utils import get_interactive_choice
from myffe.route.tools_py.scaler_selector import get_best_scaler

def analyze_standardization(data, auto_test=False):
    """分析数据的标准化需求，为每列推荐适合的标准化方法
    
    Args:
        data: pandas DataFrame，输入数据
        auto_test: bool，是否自动测试模式，默认为 False
    
    Returns:
        dict: 包含标准化参数的字典，使用嵌套字典列表结构
    """
    standard_params = {
        'standard_ways': []
    }

    scaler_methods = ["Z-score标准化", "Min-Max标准化", "MaxAbs标准化", "RobustScaler标准化", "QuantileTransformer标准化", "均值归一化", "单位长度归一化", "自定义缩放", "skip"]
    
    # 筛选出数值列
    numeric_columns = data.select_dtypes(include=['number']).columns.tolist()
    
    if not numeric_columns:
        ColorPrinter.print_info("数据中没有需要标准化的数值列")
        return {'standard_preprocessing': 'skip'}
    
    inter_standard = get_interactive_choice(
        title="智能推荐？",
        description="选择'ok'将自动为所有数值列推荐最佳标准化方法，选择'no'需要手动选择",
        auto_test=auto_test
    )
    
    if not inter_standard:
        while True:
            # 重置参数列表
            standard_params['standard_ways'] = []
            
            selected_cols = interactive(numeric_columns , title="请按上下箭头选择，回车确认标准化处理列,点击'm'键进行多选择", description="选择要进行标准化处理的列，可以多选", min_select=1, max_select=len(numeric_columns)).run()
            time.sleep(2)
            ColorPrinter.print_success('你已选择标准化处理列：' + str(selected_cols))
            
            # 为每列选择标准化方法
            for col in selected_cols:
                selected_method = interactive(scaler_methods, title=f"请按上下箭头选择，回车确认{col}的标准化方法", description="Z-score标准化:基于均值和标准差, Min-Max标准化:缩放到0-1范围, MaxAbs标准化:基于最大值, RobustScaler标准化:对异常值不敏感, QuantileTransformer标准化:将数据映射到均匀分布, 均值归一化:减去均值, 单位长度归一化:缩放到单位范数, 自定义缩放:根据数据特性自定义, skip:不进行标准化处理", min_select=1, max_select=1).run()
                # 确保返回值是单个字符串
                method = selected_method[0]
                standard_params['standard_ways'].append({'col': col, 'method': method})
                time.sleep(2)
                ColorPrinter.print_success(f'你已选择{col}的标准化方法：{method}')
            
            break
    else:
        # 智能推荐模式
        for col in numeric_columns:
            col_data = data[col].astype(str).tolist()
            best_method = get_best_scaler(col_data)
            standard_params['standard_ways'].append({'col': col, 'method': best_method})
            ColorPrinter.print_info(f"为列 '{col}' 推荐标准化方法：{best_method}")
    
    result = {
        'standard_preprocessing': standard_params
    }
    visualize_route(result)
    return result

def standard_py(data, auto_test=False):
    """Python备用方案
    
    Args:
        data: pandas DataFrame，输入数据
        auto_test: bool，是否自动测试模式，默认为 False
    
    Returns:
        dict: 包含标准化参数的字典
    """
    return analyze_standardization(data, auto_test=auto_test)

if __name__ == "__main__":
    # 测试代码
    import pandas as pd
    import numpy as np
    
    # 创建测试数据
    np.random.seed(42)
    data = pd.DataFrame({
        'numeric_col1': np.random.normal(100, 10, 20),
        'numeric_col2': np.random.normal(50, 5, 20),
        'numeric_col3': np.random.uniform(0, 100, 20)
    })
    
    ColorPrinter.print_info("测试数据:")
    ColorPrinter.print_any(data.head(), color='white')
    ColorPrinter.print_any("\n数据统计:", color='blue')
    ColorPrinter.print_any(data.describe(), color='white')
    
    # 测试标准化处理
    ColorPrinter.print_info("\n测试标准化处理:")
    result = standard_py(data)
    ColorPrinter.print_success("处理结果:")
    ColorPrinter.print_any(result, color='white')




"""
这个输入data数据
这里这个函数最终会在self.route里添加一个
下面格式的字典
'standard_preprocessing': {
    'standard_ways': [
        {'col': '列名', 'method': '标准化方法'},
        {'col': '列名', 'method': 'skip'}  # 跳过该列
    ]
}

method的取值有
    "Z-score标准化"   # Z-score标准化
    "Min-Max标准化"   # Min-Max标准化
    "MaxAbs标准化"   # MaxAbs标准化
    "RobustScaler标准化"   # RobustScaler标准化
    "QuantileTransformer标准化"   # QuantileTransformer标准化，将数据映射到均匀分布
    "均值归一化"   # 均值归一化，减去均值
    "单位长度归一化"   # 单位长度归一化，缩放到单位范数
    "自定义缩放"   # 自定义缩放，根据数据特性自定义
    "skip"   # 跳过标准化处理
"""

