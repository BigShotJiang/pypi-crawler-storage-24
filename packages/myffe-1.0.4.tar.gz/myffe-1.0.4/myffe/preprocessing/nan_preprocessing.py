"""
NanPreprocessing module for handling missing values in datasets.

Imports logging functionality from myffe.tools.Loggerv1_1 import log_class

__init__ receives important parameter shortcut_nan (missing value processing parameters)
__call__ receives important parameter data (dataset for missing value processing)

Uses shortcut_nan with:
- nan_missing_process_choice (missing value processing method)
  (options: fill_nan_mean, fill_nan_median, fill_nan_mode, fill_nan_forward, fill_nan_backward, fill_nan_intelligent, drop_col_high_missing, fill_nan_knn, skip)
- drop_threshold (missing value processing threshold) (range 0-1, default 0.75)
- knn_n_neighbors (KNN neighbors for missing value processing) (default 5)
"""
import sys
import os

# Add project root directory to Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..')))

from myffe.tools.Loggerv1_1 import log_class
from myffe.tools.color_printer import ColorPrinter
from myffe.tools.evaluation_decorator import with_evaluation
from myffe.preprocessing.function.nanfunction.knn import fill_nan_knn
from myffe.preprocessing.function.nanfunction.intelligent import fill_nan_intelligent
from myffe.preprocessing.function.nanfunction.EI import fill_nan_ei
from myffe.preprocessing.function.nanfunction.drop import drop_high_missing_single_col

@log_class(type='use')
class NanPreprocessing:
    def __init__(self, shortcut_nan=None, label_col=None):            
        self.shortcut_nan = shortcut_nan
        self.label_col = label_col

    @with_evaluation
    def __call__(self, data):
#提前退出
#region 
        import pandas as pd
        if self.shortcut_nan is None:
            ColorPrinter.print_error('错误: 缺少必要的参数 shortcut_nan')
            return data
        if self.shortcut_nan =='skip':
            ColorPrinter.print_error('错误: 缺少必要的参数 shortcut_nan')
            return data
#endregion 
#数据信息展示
#region 
        data_size = data.memory_usage(deep=True).sum() / (1024 * 1024)  # Convert to MB
        ColorPrinter.print_info(f'数据大小: {data_size:.2f} MB')
        ColorPrinter.print_info(f'数据行数: {len(data)} 行')
        self.data = data
        ColorPrinter.print_info('下面进行缺失值处理')
#endregion 
#正式处理
#region 
        processed_data = self.nan_preprocessing_switch(data)
        
        # 只返回特征列，不包含标签列
        return processed_data
#endregion 

    def nan_preprocessing_switch(self, data):        
        #参数获取
        #region 
        import pandas as pd
        nan_ways = self.shortcut_nan.get('nan_ways', [])
        #endregion 

        #参数完整性检查
        #region 
        if not nan_ways:
            ColorPrinter.print_error('错误: 缺少必要的参数 nan_ways')
            return data
        #endregion 

        #创建数据副本
        #region 
        processed_data = data.copy()
        ColorPrinter.print_info('已创建数据副本，开始处理缺失值')
        #endregion 

        #参数展示
        #region 
        ColorPrinter.print_info(f"处理列数: {len(nan_ways)}")
        #endregion 

        #列处理循环
        #region 
        for col_config in nan_ways:
            col = col_config.get('col')
            method = col_config.get('method')
            
            if col in processed_data.columns:
                ColorPrinter.print_info(f"处理列: {col}, 方法: {method}")
                if method == 'skip':         
                    continue
                elif method == 'drop_col_high_missing':
                    # 获取当前列的drop_threshold参数
                    drop_threshold = col_config.get('drop_threshold', 0.75)
                    #构建临时参数字典
                    temp_params = {
                        'drop_threshold': drop_threshold
                    }
                    processed_data = drop_high_missing_single_col(processed_data, col, temp_params)
                elif method == 'fill_nan_knn':
                    if processed_data[col].isna().sum() > 0:
                        # 获取当前列的knn_n_neighbors参数
                        knn_n_neighbors = col_config.get('knn_n_neighbors', 5)
                        # 构建临时参数字典
                        temp_params = {
                            'knn_n_neighbors': knn_n_neighbors
                        }
                        # 直接传递label_col参数，让函数内部处理
                        processed_data = fill_nan_knn(processed_data, target_col=col, shortcut_nan=temp_params, label_col=self.label_col)
                elif method == 'fill_nan_mean':    
                    processed_data[col] = processed_data[col].fillna(processed_data[col].mean())
                    ColorPrinter.print_info(f'fill nan mean: {col}')
                elif method == 'fill_nan_median':    
                    processed_data[col] = processed_data[col].fillna(processed_data[col].median())
                    ColorPrinter.print_info(f'fill nan median: {col}')
                elif method == 'fill_nan_mode':    
                    mode_value = processed_data[col].mode().iloc[0] if not processed_data[col].mode().empty else None
                    if mode_value is not None:
                        processed_data[col] = processed_data[col].fillna(mode_value)
                        ColorPrinter.print_info(f'fill nan mode: {col} = {mode_value}')
                elif method == 'fill_nan_forward':    
                    processed_data[col] = processed_data[col].ffill()
                    ColorPrinter.print_info(f'fill nan forward: {col}')
                elif method == 'fill_nan_backward':    
                    processed_data[col] = processed_data[col].bfill()
                    ColorPrinter.print_info(f'fill nan backward: {col}')
                elif method == 'fill_nan_intelligent':    
                    # 直接传递label_col参数，让函数内部处理
                    processed_data = fill_nan_intelligent(processed_data, target_col=col, label_col=self.label_col)
                    ColorPrinter.print_info(f'fill nan intelligent: {col}')
                elif method == 'fill_nan_ei':    
                    # 获取当前列的模型类型和多项式阶数
                    model_type = col_config.get('ei_model_type', 'linear')
                    poly_degree = col_config.get('poly_degree', 2)
                    
                    # 直接传递label_col参数，让函数内部处理
                    processed_data = fill_nan_ei(processed_data, target_col=col, poly_degree=poly_degree, model_type=model_type, label_col=self.label_col)
                    ColorPrinter.print_info(f'fill nan ei: {col} (model: {model_type}, degree: {poly_degree})')
                elif method == 'specify_fill':    
                    # 获取填充值
                    fill_value = col_config.get('fill_value')
                    if fill_value is not None:
                        processed_data[col] = processed_data[col].fillna(fill_value)
                        ColorPrinter.print_info(f'fill nan with specified value: {col} = {fill_value}')
                    else:
                        ColorPrinter.print_error(f'列 {col} 没有指定填充值')
            else:
                ColorPrinter.print_error(f'指定的列不存在')
                continue
        #endregion 
        return processed_data
    

    







"""
Parameter documentation:

shortcut_nan parameter dictionary:
    - nan_ways: List of column processing configurations
      Type: list of dictionaries
      Default: []
      Description: List of dictionaries, each containing processing configuration for a column
      Each dictionary in nan_ways contains:
        - col: Column name
          Type: string
          Description: Name of the column to process
        - method: Processing method
          Type: string
          Optional values: 'fill_nan_mean', 'fill_nan_median', 'fill_nan_mode', 'fill_nan_forward', 'fill_nan_backward', 'fill_nan_intelligent', 'drop_col_high_missing', 'fill_nan_knn', 'fill_nan_ei', 'specify_fill', 'skip'
          Description: Processing method for the column
        - Additional method-specific parameters:
          - For 'drop_col_high_missing':
            - drop_threshold: Missing value ratio threshold (0.0 - 1.0, default: 0.5)
          - For 'fill_nan_knn':
            - knn_n_neighbors: Number of neighbors (>= 1, default: 5)
          - For 'fill_nan_ei':
            - ei_model_type: Model type ('linear', 'ridge', 'lasso', 'random_forest', 'gradient_boosting', default: 'linear')
            - poly_degree: Polynomial degree (>= 1, default: 2)
          - For 'specify_fill':
            - fill_value: User-specified fill value

Method descriptions:
  - 'fill_nan_mean': Fill missing values with mean
  - 'fill_nan_median': Fill missing values with median
  - 'fill_nan_mode': Fill missing values with mode
  - 'fill_nan_forward': Fill missing values with forward fill
  - 'fill_nan_backward': Fill missing values with backward fill
  - 'fill_nan_intelligent': Fill missing values with intelligent imputation
  - 'drop_col_high_missing': Drop columns with high missing value ratio
  - 'fill_nan_knn': Fill missing values with KNN algorithm
  - 'fill_nan_ei': Fill missing values with ensemble imputation algorithm
  - 'specify_fill': Fill missing values with user-specified values
  - 'skip': Skip missing value processing for this column

Parameter processing logic:
  - Each column's processing configuration is independent and contained in a dictionary within the nan_ways list
  - All possible parameters are included in the configuration as placeholders, regardless of the selected method
  - Unselected parameters are placeheld with default values to ensure consistent configuration structure
  - This design makes the configuration structure more uniform, facilitating subsequent processing and maintenance

Usage example:
    # Apply different missing value processing methods to different columns
    nan_params = {
        'nan_ways': [
            {
                'col': 'numeric_col1',
                'method': 'fill_nan_knn',
                'knn_n_neighbors': 5
            },
            {
                'col': 'numeric_col2',
                'method': 'drop_col_high_missing',
                'drop_threshold': 0.4
            },
            {
                'col': 'categorical_col',
                'method': 'fill_nan_mode'
            },
            {
                'col': 'datetime_col',
                'method': 'fill_nan_forward'
            }
        ]
    }
    nan_processor = NanPreprocessing(shortcut_nan=nan_params, label_col='label')
    cleaned_data = nan_processor(data)
"""


if __name__ == "__main__":
    import pandas as pd
    import numpy as np
    
    ColorPrinter.print_any("=" * 60)
    ColorPrinter.print_info("缺失值处理测试程序")
    ColorPrinter.print_any("=" * 60)
    
    # 创建包含缺失值的测试数据
    np.random.seed(42)
    test_data = pd.DataFrame({
        'feature1': [1, 2, np.nan, 4, 5, np.nan, 7, 8, 9, 10],
        'feature2': [np.nan, 12, 13, np.nan, 15, 16, np.nan, 18, 19, 20],
        'feature3': [21, 22, 23, 24, 25, 26, 27, 28, np.nan, 30],
        'label': ['A', 'B', 'A', 'B', 'A', 'B', 'A', 'B', 'A', 'B']
    })
    
    ColorPrinter.print_any("\n原始数据:")
    ColorPrinter.print_any(test_data)
    ColorPrinter.print_any("\n缺失值统计:")
    ColorPrinter.print_any(test_data.isnull().sum())
    
    # 测试不同的缺失值处理方式
    test_cases = [
        {
            'nan_ways': [
                {'col': 'feature1', 'method': 'fill_nan_mean'},
                {'col': 'feature2', 'method': 'fill_nan_mean'},
                {'col': 'feature3', 'method': 'fill_nan_mean'}
            ]
        },
        {
            'nan_ways': [
                {'col': 'feature1', 'method': 'fill_nan_median'},
                {'col': 'feature2', 'method': 'fill_nan_median'},
                {'col': 'feature3', 'method': 'fill_nan_median'}
            ]
        },
        {
            'nan_ways': [
                {'col': 'feature1', 'method': 'fill_nan_knn', 'knn_n_neighbors': 3},
                {'col': 'feature2', 'method': 'fill_nan_knn', 'knn_n_neighbors': 3},
                {'col': 'feature3', 'method': 'fill_nan_knn', 'knn_n_neighbors': 3}
            ]
        },
        {
            'nan_ways': [
                {'col': 'feature1', 'method': 'fill_nan_forward'},
                {'col': 'feature2', 'method': 'fill_nan_forward'},
                {'col': 'feature3', 'method': 'fill_nan_forward'}
            ]
        },
        {
            'nan_ways': [
                {'col': 'feature1', 'method': 'fill_nan_backward'},
                {'col': 'feature2', 'method': 'fill_nan_backward'},
                {'col': 'feature3', 'method': 'fill_nan_backward'}
            ]
        },
        {
            'nan_ways': [
                {'col': 'feature1', 'method': 'fill_nan_intelligent'},
                {'col': 'feature2', 'method': 'fill_nan_intelligent'},
                {'col': 'feature3', 'method': 'fill_nan_intelligent'}
            ]
        }
    ]
    
    for i, params in enumerate(test_cases, 1):
        ColorPrinter.print_any(f"\n{'=' * 60}")
        ColorPrinter.print_info(f"测试 {i}: {params['nan_ways'][0]['method']}")
        ColorPrinter.print_any('=' * 60)
        
        nan_processor = NanPreprocessing(shortcut_nan=params, label_col='label')
        cleaned_data = nan_processor(test_data.copy())
        
        ColorPrinter.print_any("\n处理后的数据:")
        ColorPrinter.print_any(cleaned_data)
        ColorPrinter.print_any("\n处理后缺失值统计:")
        ColorPrinter.print_any(cleaned_data.isnull().sum())
    
    # 全面渗透测试套件
    ColorPrinter.print_any(f"\n{'=' * 80}")
    ColorPrinter.print_info("全面渗透测试套件")
    ColorPrinter.print_any('=' * 80)
    
    # 测试1: 列级参数测试
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试1: 列级参数测试")
    ColorPrinter.print_any('-' * 60)
    
    test_data_col_level = pd.DataFrame({
        'col1': [1, 2, np.nan, 4, 5, 6, 7, 8, 9, 10],
        'col2': [11, 12, 13, np.nan, 15, 16, 17, 18, 19, 20],
        'col3': [21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
        'label': ['A', 'B', 'A', 'B', 'A', 'B', 'A', 'B', 'A', 'B']
    })
    
    params_col_level = {
        'nan_ways': [
            {'col': 'col1', 'method': 'fill_nan_mean'},
            {'col': 'col2', 'method': 'fill_nan_median'},
            {'col': 'col3', 'method': 'fill_nan_mode'}
        ]
    }
    
    nan_processor_col_level = NanPreprocessing(shortcut_nan=params_col_level, label_col='label')
    result_col_level = nan_processor_col_level(test_data_col_level.copy())
    
    ColorPrinter.print_any("\n处理结果:")
    ColorPrinter.print_any(result_col_level)
    ColorPrinter.print_any(f"\n数据形状变化: {test_data_col_level.shape} -> {result_col_level.shape}")
    ColorPrinter.print_info("期望：col1均值填充，col2中位数填充，col3众数填充")
    
    # 测试2: 前向和后向填充测试
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试2: 前向和后向填充测试")
    ColorPrinter.print_any('-' * 60)
    
    test_data_forward_backward = pd.DataFrame({
        'col1': [1, np.nan, np.nan, 4, 5, 6, 7, 8, 9, 10],
        'col2': [11, 12, 13, 14, np.nan, np.nan, 17, 18, 19, 20],
        'label': ['A', 'B', 'A', 'B', 'A', 'B', 'A', 'B', 'A', 'B']
    })
    
    params_forward_backward = {
        'nan_ways': [
            {'col': 'col1', 'method': 'fill_nan_forward'},
            {'col': 'col2', 'method': 'fill_nan_backward'}
        ]
    }
    
    nan_processor_forward_backward = NanPreprocessing(shortcut_nan=params_forward_backward, label_col='label')
    result_forward_backward = nan_processor_forward_backward(test_data_forward_backward.copy())
    
    ColorPrinter.print_any("\n处理结果:")
    ColorPrinter.print_any(result_forward_backward)
    ColorPrinter.print_info("期望：col1前向填充，col2后向填充")
    
    # 测试3: 智能填充测试
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试3: 智能填充测试")
    ColorPrinter.print_any('-' * 60)
    
    test_data_intelligent = pd.DataFrame({
        'col1': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        'col2': [1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 7.7, 8.8, 9.9, 10.1],
        'col3': [1, 2, np.nan, 4, 5, 6, 7, 8, 9, 10],
        'label': ['A', 'B', 'A', 'B', 'A', 'B', 'A', 'B', 'A', 'B']
    })
    
    params_intelligent = {
        'nan_ways': [
            {'col': 'col3', 'method': 'fill_nan_intelligent'}
        ]
    }
    
    nan_processor_intelligent = NanPreprocessing(shortcut_nan=params_intelligent, label_col='label')
    result_intelligent = nan_processor_intelligent(test_data_intelligent.copy())
    
    ColorPrinter.print_any("\n处理结果:")
    ColorPrinter.print_any(result_intelligent)
    ColorPrinter.print_info("期望：col3使用col1或col2进行智能填充")
    
    # 测试4: 删除高缺失值列测试
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试4: 删除高缺失值列测试")
    ColorPrinter.print_any('-' * 60)
    
    test_data_drop_col = pd.DataFrame({
        'col1': [1, 2, np.nan, 4, 5, 6, 7, 8, 9, 10],
        'col2': [11, 12, np.nan, 14, 15, np.nan, 17, 18, np.nan, 20],
        'col3': [21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
        'label': ['A', 'B', 'A', 'B', 'A', 'B', 'A', 'B', 'A', 'B']
    })
    
    params_drop_col = {
        'nan_ways': [
            {'col': 'col1', 'method': 'drop_col_high_missing', 'drop_threshold': 0.3},
            {'col': 'col2', 'method': 'drop_col_high_missing', 'drop_threshold': 0.3},
            {'col': 'col3', 'method': 'drop_col_high_missing', 'drop_threshold': 0.3}
        ]
    }
    
    nan_processor_drop_col = NanPreprocessing(shortcut_nan=params_drop_col, label_col='label')
    result_drop_col = nan_processor_drop_col(test_data_drop_col.copy())
    
    ColorPrinter.print_any("\n处理结果:")
    ColorPrinter.print_any(result_drop_col)
    ColorPrinter.print_any(f"\n数据形状变化: {test_data_drop_col.shape} -> {result_drop_col.shape}")
    ColorPrinter.print_info("期望：删除col2（缺失值比例33.3% > 30%阈值）")
    
    # 测试5: KNN填充测试
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试5: KNN填充测试")
    ColorPrinter.print_any('-' * 60)
    
    test_data_knn = pd.DataFrame({
        'col1': [1, 2, np.nan, 4, 5, 6, 7, 8, 9, 10],
        'col2': [11, 12, 13, np.nan, 15, 16, 17, 18, 19, 20],
        'col3': [21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
        'label': ['A', 'B', 'A', 'B', 'A', 'B', 'A', 'B', 'A', 'B']
    })
    
    params_knn = {
        'nan_ways': [
            {'col': 'col1', 'method': 'fill_nan_knn', 'knn_n_neighbors': 3},
            {'col': 'col2', 'method': 'fill_nan_knn', 'knn_n_neighbors': 3}
        ]
    }
    
    nan_processor_knn = NanPreprocessing(shortcut_nan=params_knn, label_col='label')
    result_knn = nan_processor_knn(test_data_knn.copy())
    
    ColorPrinter.print_any("\n处理结果:")
    ColorPrinter.print_any(result_knn)
    ColorPrinter.print_info("期望：col1和col2使用KNN填充缺失值")
    
    # 测试6: 组合处理测试
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试6: 组合处理测试")
    ColorPrinter.print_any('-' * 60)
    
    test_data_combined = pd.DataFrame({
        'col1': [1, 2, np.nan, 4, 5, 6, 7, 8, 9, 10],
        'col2': [11, 12, 13, np.nan, 15, 16, 17, 18, 19, 20],
        'col3': [21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
        'label': ['A', 'B', 'A', 'B', 'A', 'B', 'A', 'B', 'A', 'B']
    })
    
    params_combined = {
        'nan_ways': [
            {'col': 'col1', 'method': 'fill_nan_mean'},
            {'col': 'col2', 'method': 'fill_nan_median'},
            {'col': 'col3', 'method': 'fill_nan_mode'}
        ]
    }
    
    nan_processor_combined = NanPreprocessing(shortcut_nan=params_combined, label_col='label')
    result_combined = nan_processor_combined(test_data_combined.copy())
    
    ColorPrinter.print_any("\n处理结果:")
    ColorPrinter.print_any(result_combined)
    ColorPrinter.print_info("期望：col1均值填充，col2中位数填充，col3众数填充")
    
    # 测试7: 边界情况测试 - 无缺失值
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试7: 边界情况测试 - 无缺失值")
    ColorPrinter.print_any('-' * 60)
    
    test_data_no_missing = pd.DataFrame({
        'col1': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        'col2': [11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
        'label': ['A', 'B', 'A', 'B', 'A', 'B', 'A', 'B', 'A', 'B']
    })
    
    params_no_missing = {
        'nan_ways': [
            {'col': 'col1', 'method': 'fill_nan_mean'},
            {'col': 'col2', 'method': 'fill_nan_mean'}
        ]
    }
    
    nan_processor_no_missing = NanPreprocessing(shortcut_nan=params_no_missing, label_col='label')
    result_no_missing = nan_processor_no_missing(test_data_no_missing.copy())
    
    ColorPrinter.print_any("\n处理结果:")
    ColorPrinter.print_any(result_no_missing)
    ColorPrinter.print_info("期望：数据保持不变，无缺失值处理")
    
    # 测试8: 边界情况测试 - 全部缺失值
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试8: 边界情况测试 - 全部缺失值")
    ColorPrinter.print_any('-' * 60)
    
    test_data_all_missing = pd.DataFrame({
        'col1': [np.nan, np.nan, np.nan, np.nan, np.nan],
        'col2': [np.nan, np.nan, np.nan, np.nan, np.nan],
        'label': ['A', 'B', 'A', 'B', 'A']
    })
    
    params_all_missing = {
        'nan_ways': [
            {'col': 'col1', 'method': 'fill_nan_mean'},
            {'col': 'col2', 'method': 'fill_nan_mean'}
        ]
    }
    
    nan_processor_all_missing = NanPreprocessing(shortcut_nan=params_all_missing, label_col='label')
    result_all_missing = nan_processor_all_missing(test_data_all_missing.copy())
    
    ColorPrinter.print_any("\n处理结果:")
    ColorPrinter.print_any(result_all_missing)
    ColorPrinter.print_info("期望：均值填充，但可能无法计算均值")
    
    # 测试9: 异常情况测试 - 空数据
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试9: 异常情况测试 - 空数据")
    ColorPrinter.print_any('-' * 60)
    
    test_data_empty = pd.DataFrame({
        'col1': [],
        'col2': [],
        'label': []
    })
    
    params_empty = {
        'nan_ways': [
            {'col': 'col1', 'method': 'fill_nan_mean'},
            {'col': 'col2', 'method': 'fill_nan_mean'}
        ]
    }
    
    try:
        nan_processor_empty = NanPreprocessing(shortcut_nan=params_empty, label_col='label')
        result_empty = nan_processor_empty(test_data_empty.copy())
        
        ColorPrinter.print_any("\n处理结果:")
        ColorPrinter.print_any(result_empty)
        ColorPrinter.print_info("期望：空数据保持不变")
    except Exception as e:
        ColorPrinter.print_error(f"异常处理: {e}")
        ColorPrinter.print_info("期望：空数据应该能正常处理")
    
    # 测试10: 不同数据类型测试
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试10: 不同数据类型测试")
    ColorPrinter.print_any('-' * 60)
    
    test_data_types = pd.DataFrame({
        'numeric_col': [1, 2, np.nan, 4, 5],
        'string_col': ['A', 'B', np.nan, 'D', 'E'],
        'float_col': [1.1, 2.2, np.nan, 4.4, 5.5],
        'int_col': [10, 20, np.nan, 40, 50],
        'label': ['A', 'B', 'A', 'B', 'A']
    })
    
    params_types = {
        'nan_ways': [
            {'col': 'numeric_col', 'method': 'fill_nan_mean'},
            {'col': 'string_col', 'method': 'fill_nan_mode'},
            {'col': 'float_col', 'method': 'fill_nan_mean'},
            {'col': 'int_col', 'method': 'fill_nan_median'}
        ]
    }
    
    nan_processor_types = NanPreprocessing(shortcut_nan=params_types, label_col='label')
    result_types = nan_processor_types(test_data_types.copy())
    
    ColorPrinter.print_any("\n处理结果:")
    ColorPrinter.print_any(result_types)
    ColorPrinter.print_info("期望：数值列均值填充，字符串列众数填充")
    
    # 测试11: 大数据集测试
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试11: 大数据集测试")
    ColorPrinter.print_any('-' * 60)
    
    np.random.seed(42)
    large_data_size = 10000
    test_data_large = pd.DataFrame({
        'feature1': np.random.randn(large_data_size),
        'feature2': np.random.randn(large_data_size),
        'feature3': np.random.randn(large_data_size),
        'label': np.random.choice(['A', 'B'], large_data_size)
    })
    
    # 随机添加缺失值
    missing_indices1 = np.random.choice(large_data_size, int(large_data_size * 0.1), replace=False)
    missing_indices2 = np.random.choice(large_data_size, int(large_data_size * 0.15), replace=False)
    test_data_large.loc[missing_indices1, 'feature1'] = np.nan
    test_data_large.loc[missing_indices2, 'feature2'] = np.nan
    
    params_large = {
        'nan_ways': [
            {'col': 'feature1', 'method': 'fill_nan_mean'},
            {'col': 'feature2', 'method': 'fill_nan_mean'},
            {'col': 'feature3', 'method': 'fill_nan_mean'}
        ]
    }
    
    nan_processor_large = NanPreprocessing(shortcut_nan=params_large, label_col='label')
    result_large = nan_processor_large(test_data_large.copy())
    
    ColorPrinter.print_any(f"\n处理结果（数据大小: {large_data_size} 行）:")
    ColorPrinter.print_any(f"原始缺失值: {test_data_large.isnull().sum().sum()}")
    ColorPrinter.print_any(f"处理后缺失值: {result_large.isnull().sum().sum()}")
    ColorPrinter.print_info("期望：所有缺失值被填充")
    
    # 测试12: 极端阈值测试
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试12: 极端阈值测试")
    ColorPrinter.print_any('-' * 60)
    
    test_data_threshold = pd.DataFrame({
        'col1': [1, 2, np.nan, 4, 5, 6, 7, 8, 9, 10],
        'col2': [11, 12, np.nan, 14, 15, np.nan, 17, 18, np.nan, 20],
        'col3': [21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
        'label': ['A', 'B', 'A', 'B', 'A', 'B', 'A', 'B', 'A', 'B']
    })
    
    params_threshold_low = {
        'nan_ways': [
            {'col': 'col1', 'method': 'drop_col_high_missing', 'drop_threshold': 0.1},
            {'col': 'col2', 'method': 'drop_col_high_missing', 'drop_threshold': 0.1},
            {'col': 'col3', 'method': 'drop_col_high_missing', 'drop_threshold': 0.1}
        ]
    }
    
    params_threshold_high = {
        'nan_ways': [
            {'col': 'col1', 'method': 'drop_col_high_missing', 'drop_threshold': 0.9},
            {'col': 'col2', 'method': 'drop_col_high_missing', 'drop_threshold': 0.9},
            {'col': 'col3', 'method': 'drop_col_high_missing', 'drop_threshold': 0.9}
        ]
    }
    
    nan_processor_threshold_low = NanPreprocessing(shortcut_nan=params_threshold_low, label_col='label')
    result_threshold_low = nan_processor_threshold_low(test_data_threshold.copy())
    
    nan_processor_threshold_high = NanPreprocessing(shortcut_nan=params_threshold_high, label_col='label')
    result_threshold_high = nan_processor_threshold_high(test_data_threshold.copy())
    
    ColorPrinter.print_any("\n低阈值（0.1）结果:")
    ColorPrinter.print_any(f"删除列数: {test_data_threshold.shape[1] - result_threshold_low.shape[1]}")
    ColorPrinter.print_any("高阈值（0.9）结果:")
    ColorPrinter.print_any(f"删除列数: {test_data_threshold.shape[1] - result_threshold_high.shape[1]}")
    
    # 测试13: 标签列保护测试
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试13: 标签列保护测试")
    ColorPrinter.print_any('-' * 60)
    
    test_data_label = pd.DataFrame({
        'feature1': [1, 2, np.nan, 4, 5],
        'feature2': [11, 12, np.nan, 14, 15],
        'label': [np.nan, 'B', np.nan, 'B', 'A']  # 标签列也有缺失值
    })
    
    params_label = {
        'nan_ways': [
            {'col': 'feature1', 'method': 'fill_nan_mean'},
            {'col': 'feature2', 'method': 'fill_nan_mean'}
        ]
    }
    
    nan_processor_label = NanPreprocessing(shortcut_nan=params_label, label_col='label')
    result_label = nan_processor_label(test_data_label.copy())
    
    ColorPrinter.print_any("\n处理结果:")
    ColorPrinter.print_any(result_label)
    ColorPrinter.print_info("期望：标签列的缺失值不被处理")
    
    # 测试14: 多列同时处理测试
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试14: 多列同时处理测试")
    ColorPrinter.print_any('-' * 60)
    
    test_data_multi = pd.DataFrame({
        'col1': [1, 2, np.nan, 4, 5, 6, 7, 8, 9, 10],
        'col2': [11, 12, 13, np.nan, 15, 16, 17, 18, 19, 20],
        'col3': [21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
        'col4': [31, 32, 33, 34, 35, 36, 37, 38, 39, 40],
        'col5': [41, 42, 43, 44, 45, 46, 47, 48, 49, 50],
        'label': ['A', 'B', 'A', 'B', 'A', 'B', 'A', 'B', 'A', 'B']
    })
    
    params_multi = {
        'nan_ways': [
            {'col': 'col1', 'method': 'fill_nan_mean'},
            {'col': 'col2', 'method': 'fill_nan_median'},
            {'col': 'col3', 'method': 'fill_nan_mode'},
            {'col': 'col4', 'method': 'fill_nan_forward'},
            {'col': 'col5', 'method': 'fill_nan_backward'}
        ]
    }
    
    nan_processor_multi = NanPreprocessing(shortcut_nan=params_multi, label_col='label')
    result_multi = nan_processor_multi(test_data_multi.copy())
    
    ColorPrinter.print_any("\n处理结果:")
    ColorPrinter.print_any(f"数据形状: {test_data_multi.shape} -> {result_multi.shape}")
    ColorPrinter.print_info("期望：每列使用不同的填充方法")
    
    # 测试15: 性能测试
    ColorPrinter.print_any(f"\n{'-' * 60}")
    ColorPrinter.print_info("测试15: 性能测试")
    ColorPrinter.print_any('-' * 60)
    
    import time
    test_data_perf = pd.DataFrame({
        'feature1': np.random.randn(5000),
        'feature2': np.random.randn(5000),
        'feature3': np.random.randn(5000),
        'label': np.random.choice(['A', 'B'], 5000)
    })
    
    # 随机添加缺失值
    for col in ['feature1', 'feature2', 'feature3']:
        missing_indices = np.random.choice(5000, int(5000 * 0.1), replace=False)
        test_data_perf.loc[missing_indices, col] = np.nan
    
    params_perf = {
        'nan_ways': [
            {'col': 'feature1', 'method': 'fill_nan_mean'},
            {'col': 'feature2', 'method': 'fill_nan_mean'},
            {'col': 'feature3', 'method': 'fill_nan_mean'}
        ]
    }
    
    nan_processor_perf = NanPreprocessing(shortcut_nan=params_perf, label_col='label')
    
    start_time = time.time()
    result_perf = nan_processor_perf(test_data_perf.copy())
    end_time = time.time()
    
    ColorPrinter.print_any(f"\n处理时间: {end_time - start_time:.4f} 秒")
    ColorPrinter.print_any(f"数据大小: {len(test_data_perf)} 行")
    ColorPrinter.print_any(f"原始缺失值: {test_data_perf.isnull().sum().sum()}")
    ColorPrinter.print_any(f"处理后缺失值: {result_perf.isnull().sum().sum()}")
    
    ColorPrinter.print_any("\n" + "=" * 80)
    ColorPrinter.print_success("全面渗透测试完成！")
    ColorPrinter.print_any("=" * 80)
