import sys
import os

# 添加项目根目录到Python路径
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..')))

from myffe.tools.Loggerv1_1 import log_class
from myffe.tools.color_printer import ColorPrinter
from myffe.tools.evaluation_decorator import with_evaluation

@log_class(type='use')
class SpecifyPreprocessing:
    """指定行列删除处理器"""
    def __init__(self, shortcut_specify=None):
        """初始化处理器
        
        Args:
            shortcut_specify: 参数字典，包含 drop_row 和 drop_col
        """
        self.shortcut_specify = shortcut_specify

    @with_evaluation
    def __call__(self, data):
        """执行指定行列删除
        
        Args:
            data: 输入数据
            data_label: 标签列名（未使用）
            
        Returns:
            处理后的数据
        """
#region 检查参数
        if not self.shortcut_specify:
            ColorPrinter.print_warning('没有指定任何处理参数')
            return data
        
        # 处理 'skip' 情况
        if self.shortcut_specify == 'skip':
            ColorPrinter.print_info('跳过指定行列删除，因为参数配置为 "skip"')
            return data

#endregion
#region 获取参数
        drop_row = self.shortcut_specify.get('drop_row')
        drop_col = self.shortcut_specify.get('drop_col')
#endregion
#region 处理行列删除
        if drop_row:
            data = self._process_drop_row(data, drop_row)
        if drop_col:
            data = self._process_drop_col(data, drop_col)
#endregion
        return data

    def _process_drop_row(self, data, drop_row):
        """处理行删除
        
        Args:
            data: 输入数据
            drop_row: 要删除的行索引
            
        Returns:
            处理后的数据
        """
# region 转换为整数
        try:
            drop_row = [int(row) for row in drop_row]
        except ValueError:
            ColorPrinter.print_warning("警告: 行索引必须是整数，跳过行删除")
            return data
#endregion
#region 删除存在的行
        existing_rows = [row for row in drop_row if row in data.index]
        if existing_rows:
            data.drop(existing_rows, axis=0, inplace=True)
            ColorPrinter.print_success(f'删除了行: {existing_rows}')
        else:
            ColorPrinter.print_warning('没有找到要删除的行')
        return data
#endregion
    def _process_drop_col(self, data, drop_col):
        """处理列删除
        
        Args:
            data: 输入数据
            drop_col: 要删除的列名
            
        Returns:
            处理后的数据
        """
#region 删除存在的列
        drop_col = [col for col in drop_col if col in data.columns]
        
        if drop_col:
            data.drop(drop_col, axis=1, inplace=True)
            ColorPrinter.print_success(f'删除了列: {drop_col}')
        else:
            ColorPrinter.print_warning('没有找到要删除的列')
        return data
#endregion






if __name__ == "__main__":
    import pandas as pd
    import numpy as np
    
    print("=" * 60)
    print("指定行列删除测试程序")
    print("=" * 60)
    
    # 创建测试数据
    np.random.seed(42)
    test_data = pd.DataFrame({
        'feature1': np.random.randint(1, 100, 10),
        'feature2': np.random.randint(1, 100, 10),
        'feature3': np.random.randint(1, 100, 10),
        'feature4': np.random.randint(1, 100, 10),
        'label': ['A', 'B', 'A', 'B', 'A', 'B', 'A', 'B', 'A', 'B']
    })
    
    print("\n原始数据:")
    print(test_data)
    print(f"\n数据形状: {test_data.shape}")
    
    # 测试不同的删除方式
    test_cases = [
        {
            'params': {
                'drop_col': ['feature1', 'feature2']
            },
            'description': '删除指定列'
        },
        {
            'params': {
                'drop_col': ['feature3']
            },
            'description': '删除单个列'
        },
        {
            'params': {
                'drop_row': [0, 1, 2]
            },
            'description': '删除指定行'
        },
        {
            'params': {
                'drop_row': [5]
            },
            'description': '删除单个行'
        },
        {
            'params': {
                'drop_col': ['feature4']
            },
            'description': '删除标签列以外的列'
        },
        {
            'params': {
                'drop_row': [0, 1],
                'drop_col': ['feature1', 'feature2']
            },
            'description': '同时删除行和列'
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{'=' * 60}")
        print(f"测试 {i}: {test_case['description']}")
        print('=' * 60)
        print(f"参数: {test_case['params']}")
        
        specify_processor = SpecifyPreprocessing(shortcut_specify=test_case['params'])
        try:
            processed_data = specify_processor(test_data.copy(), 'label')
            
            print("\n处理后的数据:")
            print(processed_data)
            print(f"\n处理后的数据形状: {processed_data.shape}")
        except Exception as e:
            print(f"\n处理出错: {e}")
    
    print("\n" + "=" * 60)
    print("测试完成！")
    print("=" * 60)
