from factory import Faker, LazyFunction, SubFactory, post_generation
from factory.django import DjangoModelFactory as FactoryDjangoModelFactory

from ..caluma_core.factories import DjangoModelFactory
from ..caluma_form.factories import DocumentFactory, FormFactory
from . import models


class TaskFactory(DjangoModelFactory):
    slug = Faker("slug")
    name = Faker("multilang", faker_provider="name")
    type = Faker("word", ext_word_list=models.Task.TYPE_CHOICES)
    address_groups = None
    control_groups = None
    description = Faker("multilang", faker_provider="text")
    meta = LazyFunction(lambda: {})
    is_archived = False
    form = SubFactory(FormFactory)
    lead_time = None
    is_multiple_instance = False
    continue_async = False

    class Meta:
        model = models.Task


class WorkflowFactory(DjangoModelFactory):
    slug = Faker("slug")
    name = Faker("multilang", faker_provider="name")
    description = Faker("multilang", faker_provider="text")
    meta = LazyFunction(lambda: {})
    is_published = False
    is_archived = False
    allow_all_forms = False

    class Meta:
        model = models.Workflow


class WorkflowStartTasksFactory(FactoryDjangoModelFactory):
    workflow = SubFactory(WorkflowFactory)
    task = SubFactory(TaskFactory)

    class Meta:
        model = models.Workflow.start_tasks.through


class WorkflowAllowFormsFactory(FactoryDjangoModelFactory):
    form = SubFactory(FormFactory)
    workflow = SubFactory(WorkflowFactory)

    class Meta:
        model = models.Workflow.allow_forms.through


class FlowFactory(DjangoModelFactory):
    next = Faker("slug")

    class Meta:
        model = models.Flow


class TaskFlowFactory(DjangoModelFactory):
    workflow = SubFactory(WorkflowFactory)
    task = SubFactory(TaskFactory)
    flow = SubFactory(FlowFactory)
    redoable = None

    class Meta:
        model = models.TaskFlow


class CaseFactory(DjangoModelFactory):
    workflow = SubFactory(WorkflowFactory)
    status = models.Case.STATUS_RUNNING
    meta = LazyFunction(lambda: {})
    document = SubFactory(DocumentFactory)

    @post_generation
    def parent_work_item(obj, create, extracted, **kwargs):
        # Create reverse one-to-one related object when passed as a param
        if extracted is None:
            return

        parent_work_item = extracted
        parent_work_item.child_case = obj
        parent_work_item.save()

    class Meta:
        model = models.Case
        skip_postgeneration_save = True


class WorkItemFactory(DjangoModelFactory):
    name = Faker("multilang", faker_provider="name")
    description = Faker("multilang", faker_provider="text")
    closed_at = None
    closed_by_user = None
    closed_by_group = None
    deadline = None
    status = models.WorkItem.STATUS_READY
    meta = LazyFunction(lambda: {})
    addressed_groups = LazyFunction(lambda: [])
    controlling_groups = LazyFunction(lambda: [])
    assigned_users = LazyFunction(lambda: [])
    task = SubFactory(TaskFactory)
    case = SubFactory(CaseFactory)
    child_case = SubFactory(CaseFactory)
    document = SubFactory(DocumentFactory)
    previous_work_item = None

    class Meta:
        model = models.WorkItem
