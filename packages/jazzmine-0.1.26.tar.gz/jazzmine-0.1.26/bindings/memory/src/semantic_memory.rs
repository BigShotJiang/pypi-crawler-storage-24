#![allow(deprecated, non_local_definitions, unsafe_op_in_unsafe_fn)]

use pyo3::prelude::*;
use pyo3::types::PyDict;
use pyo3_asyncio::tokio::future_into_py;
use qdrant_client::qdrant::{
    Condition, Filter, SearchPoints, ScoredPoint, ScrollPoints, Value as QdrantValue,
    with_payload_selector::SelectorOptions, WithPayloadSelector,
    SparseVector, Vector, Vectors, NamedVectors, PointStruct, PointId,
};
use qdrant_client::qdrant::vector;
use std::collections::HashMap;
use std::sync::Arc;
use uuid::Uuid;

use tokenizers::Tokenizer;
use crate::init::QdrantManager;
use hf_hub::api::sync::ApiBuilder;


// ── Python-exposed struct ─────────────────────────────────────────────────────

/// BM25-only memory for domain terminology, abbreviations, and company jargon.
///
/// Unlike EpisodicMemory and ProceduralMemory (dense + BM25 + RRF),
/// SemanticMemory uses sparse BM25 search only. This is intentional:
///
///   • Domain terms are keyword-dense by nature — "JWT", "KYC", "k8s".
///     Dense embeddings add noise, not signal, for exact and near-exact term lookup.
///   • Entries are user-defined key→value pairs. Token overlap between the
///     stored text and query is the correct matching criterion.
///   • BM25 with IDF weighting naturally handles term frequency and rarity,
///     so uncommon internal project names ("ProjectAthena") score highly when
///     mentioned, while common words ("the", "is") are downweighted.
///
/// Entry identity is deterministic:
///   entry_id = UUID5(NAMESPACE_DNS, "{agent_id}::{key.to_lowercase()}")
///
/// This means upsert is always idempotent (same key overwrites its own point),
/// and forget() needs no prior query — the UUID is computed, then deleted directly.
#[pyclass]
pub struct SemanticMemory {
    client:          Arc<qdrant_client::Qdrant>,
    tokenizer:       Arc<Tokenizer>,
    collection_name: String,
}


// ── Python methods ────────────────────────────────────────────────────────────

#[pymethods]
impl SemanticMemory {

    #[new]
    #[pyo3(signature = (qdrant_manager, tokenizer_path=None, tokenizer_model_id=None, cache_dir=None))]
    pub fn new(
        qdrant_manager: Py<QdrantManager>,
        tokenizer_path: Option<String>,
        tokenizer_model_id: Option<String>,
        cache_dir: Option<String>,
    ) -> PyResult<Self> {
        Python::with_gil(|py| {
            let mgr             = qdrant_manager.borrow(py);
            let client          = mgr.client();
            let collection_name = mgr.semantic_collection_name();

            let tokenizer = if let Some(path) = tokenizer_path.as_ref().map(|p| p.trim()).filter(|p| !p.is_empty()) {
                Tokenizer::from_file(path)
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                        format!("Failed to load tokenizer from '{}': {}", path, e)
                    ))?
            } else {
                let model_id = tokenizer_model_id
                    .as_ref()
                    .map(|m| m.trim())
                    .filter(|m| !m.is_empty())
                    .ok_or_else(|| PyErr::new::<pyo3::exceptions::PyValueError, _>(
                        "SemanticMemory requires tokenizer_path or tokenizer_model_id."
                    ))?;

                let mut builder = ApiBuilder::new().with_progress(false);
                if let Some(dir) = cache_dir.as_ref().map(|d| d.trim()).filter(|d| !d.is_empty()) {
                    builder = builder.with_cache_dir(std::path::PathBuf::from(dir));
                }
                let api = builder.build().map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("Failed to initialize Hugging Face API client: {}", e)
                ))?;
                let tok_path = api
                    .model(model_id.to_string())
                    .get("tokenizer.json")
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                        format!("Failed to download tokenizer.json for model '{}': {}", model_id, e)
                    ))?;

                Tokenizer::from_file(tok_path)
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                        format!("Failed to load downloaded tokenizer for model '{}': {}", model_id, e)
                    ))?
            };

            Ok(SemanticMemory { client, tokenizer: Arc::new(tokenizer), collection_name })
        })
    }


    // ── memorize ─────────────────────────────────────────────────────────────

    /// Store or overwrite a term definition.
    ///
    /// Indexed BM25 text = key + value + aliases + description joined.
    /// This ensures all surface forms and meanings are searchable.
    ///
    /// `category` is a free-form classifier. Recommended values:
    ///   "abbreviation"   — JWT, KYC, PII, k8s, ORM
    ///   "jargon"         — internal project names, team names, business terms
    ///   "technical"      — language/framework-specific terms and patterns
    ///   "domain"         — industry-specific terminology (fintech, healthcare…)
    ///   "custom"         — anything else
    ///
    /// `aliases` — alternative spellings or forms, also indexed for recall.
    ///   ["json web token", "json-web-token"] for "JWT"
    ///
    /// `description` — optional longer explanation, also BM25-indexed but
    ///   not returned as the primary definition.
    #[pyo3(signature = (key, value, category, agent_id, aliases=None, description=None))]
    pub fn memorize<'py>(
        &self,
        py:          Python<'py>,
        key:         String,
        value:       String,
        category:    String,
        agent_id:    String,
        aliases:     Option<Vec<String>>,
        description: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let client          = Arc::clone(&self.client);
        let tokenizer       = Arc::clone(&self.tokenizer);
        let collection_name = self.collection_name.clone();
        let aliases         = aliases.unwrap_or_default();
        let description     = description.unwrap_or_default();

        future_into_py(py, async move {
            // ── BM25 indexing text ────────────────────────────────────────────
            // Index all surface forms: key name, definition, every alias, description.
            // This maximises recall: searching "json web token" still finds "JWT".
            let mut bm25_parts = vec![key.clone(), value.clone()];
            bm25_parts.extend(aliases.iter().cloned());
            if !description.is_empty() {
                bm25_parts.push(description.clone());
            }
            let bm25_text = bm25_parts.join(" ");

            let (bm25_indices, bm25_values) = tokenize_bm25(&tokenizer, &bm25_text)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("BM25 tokenization failed for key '{}': {}", key, e)
                ))?;

            // ── Deterministic UUID ────────────────────────────────────────────
            // Same agent_id + same key → same UUID → upsert overwrites in place.
            // Key is lowercased so "JWT" and "jwt" resolve to the same entry.
            let entry_id = Uuid::new_v5(
                &Uuid::NAMESPACE_DNS,
                format!("{}::{}", agent_id, key.to_lowercase()).as_bytes(),
            ).to_string();

            // ── Sparse-only vectors ───────────────────────────────────────────
            let mut vectors_map = HashMap::new();
            vectors_map.insert("bm25".to_string(), Vector {
                data:          Vec::new(),
                indices:       None,
                vectors_count: None,
                vector:        Some(vector::Vector::Sparse(SparseVector {
                    indices: bm25_indices,
                    values:  bm25_values,
                })),
            });

            // ── Payload ───────────────────────────────────────────────────────
            let mut payload: HashMap<String, QdrantValue> = HashMap::new();
            payload.insert("key".into(),      QdrantValue::from(key.clone()));
            payload.insert("value".into(),    QdrantValue::from(value));
            payload.insert("category".into(), QdrantValue::from(category));
            payload.insert("agent_id".into(), QdrantValue::from(agent_id));
            payload.insert("description".into(), QdrantValue::from(description));
            payload.insert("entry_id".into(), QdrantValue::from(entry_id.clone()));
            payload.insert(
                "aliases".into(),
                QdrantValue::from(
                    aliases.into_iter().map(QdrantValue::from).collect::<Vec<_>>()
                ),
            );

            let point = PointStruct {
                id: Some(PointId {
                    point_id_options: Some(
                        qdrant_client::qdrant::point_id::PointIdOptions::Uuid(entry_id)
                    ),
                }),
                vectors: Some(Vectors {
                    vectors_options: Some(
                        qdrant_client::qdrant::vectors::VectorsOptions::Vectors(
                            NamedVectors { vectors: vectors_map }
                        )
                    ),
                }),
                payload,
            };

            client.upsert_points(qdrant_client::qdrant::UpsertPoints {
                collection_name: collection_name.clone(),
                points:          vec![point],
                wait:            Some(true),
                ..Default::default()
            })
            .await
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                format!("Upsert failed for key '{}': {}", key, e)
            ))?;

            Ok(())
        })
    }


    // ── recall ────────────────────────────────────────────────────────────────

    /// Retrieve the top-k most relevant term definitions matching the query.
    ///
    /// BM25 only — scores reflect token overlap between the query and the
    /// indexed key + value + aliases + description text.
    ///
    /// Works for:
    ///   • Direct term lookup:   "JWT"  → finds the JWT entry
    ///   • Definition lookup:    "JSON web token" → finds JWT via aliases
    ///   • Contextual lookup:    full sentence containing domain terms
    ///   • Fuzzy via aliases:    "json-web-token" → finds JWT if listed as alias
    ///
    /// `score_threshold` — optional minimum BM25 score. Useful for ignoring
    ///   low-confidence matches when extracting terms from a paragraph.
    ///   Typical meaningful threshold: 1.0–3.0 depending on corpus size.
    ///
    /// Returns list[dict] sorted by score descending:
    ///   key, value, category, aliases, description, agent_id, entry_id, score
    #[pyo3(signature = (query, agent_id, top_k = 5, score_threshold = None))]
    pub fn recall<'py>(
        &self,
        py:              Python<'py>,
        query:           String,
        agent_id:        String,
        top_k:           u64,
        score_threshold: Option<f32>,
    ) -> PyResult<&'py PyAny> {
        let client          = Arc::clone(&self.client);
        let tokenizer       = Arc::clone(&self.tokenizer);
        let collection_name = self.collection_name.clone();

        future_into_py(py, async move {
            let (bm25_idx, bm25_vals) = tokenize_bm25(&tokenizer, &query)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("BM25 query tokenization failed: {}", e)
                ))?;

            let filter = agent_id_filter(&agent_id);

            let search = SearchPoints {
                collection_name: collection_name.clone(),
                sparse_indices:  Some(qdrant_client::qdrant::SparseIndices { data: bm25_idx }),
                vector:          bm25_vals,
                vector_name:     Some("bm25".to_string()),
                filter:          Some(filter),
                limit:           top_k,
                with_payload:    Some(WithPayloadSelector {
                    selector_options: Some(SelectorOptions::Enable(true)),
                }),
                score_threshold,
                ..Default::default()
            };

            let result = client.search_points(search)
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("BM25 search failed: {}", e)
                ))?;

            Python::with_gil(|py| {
                result.result.iter()
                    .map(|point| term_to_pydict(py, point))
                    .collect::<PyResult<Vec<_>>>()
                    .map(|v| v.into_py(py))
            })
        })
    }


    // ── forget ────────────────────────────────────────────────────────────────

    /// Delete a single term by key + agent_id.
    ///
    /// The UUID is computed deterministically — no Qdrant query needed.
    /// Deleting a non-existent key is a no-op (Qdrant delete is idempotent).
    #[pyo3(signature = (key, agent_id))]
    pub fn forget<'py>(
        &self,
        py:       Python<'py>,
        key:      String,
        agent_id: String,
    ) -> PyResult<&'py PyAny> {
        let client          = Arc::clone(&self.client);
        let collection_name = self.collection_name.clone();

        future_into_py(py, async move {
            let ids = vec![entry_point_id(&agent_id, &key)];
            delete_by_ids(&client, &collection_name, ids).await
        })
    }


    // ── forget_many ───────────────────────────────────────────────────────────

    /// Delete multiple terms in a single batch Qdrant call.
    ///
    /// Used to retire a batch of deprecated terms (e.g. after a rebrand,
    /// or when clearing an entire domain glossary before re-importing).
    #[pyo3(signature = (keys, agent_id))]
    pub fn forget_many<'py>(
        &self,
        py:       Python<'py>,
        keys:     Vec<String>,
        agent_id: String,
    ) -> PyResult<&'py PyAny> {
        let client          = Arc::clone(&self.client);
        let collection_name = self.collection_name.clone();

        future_into_py(py, async move {
            if keys.is_empty() {
                return Ok(());
            }
            let ids: Vec<PointId> = keys.iter()
                .map(|k| entry_point_id(&agent_id, k))
                .collect();
            delete_by_ids(&client, &collection_name, ids).await
        })
    }


    // ── list_all ──────────────────────────────────────────────────────────────

    /// Scroll all term definitions for a given agent, optionally filtered by category.
    ///
    /// Returns list[dict] sorted alphabetically by key.
    /// Fields: key, value, category, aliases, description, entry_id, agent_id
    #[pyo3(signature = (agent_id, category = None))]
    pub fn list_all<'py>(
        &self,
        py:       Python<'py>,
        agent_id: String,
        category: Option<String>,
    ) -> PyResult<&'py PyAny> {
        let client          = Arc::clone(&self.client);
        let collection_name = self.collection_name.clone();

        future_into_py(py, async move {
            let mut must = vec![keyword_condition("agent_id", &agent_id)];
            if let Some(cat) = category {
                must.push(keyword_condition("category", &cat));
            }

            let scroll_result = client.scroll(ScrollPoints {
                collection_name: collection_name.clone(),
                filter:          Some(Filter { must, ..Default::default() }),
                limit:           Some(10_000),
                with_payload:    Some(WithPayloadSelector {
                    selector_options: Some(SelectorOptions::Enable(true)),
                }),
                with_vectors:    Some(qdrant_client::qdrant::WithVectorsSelector {
                    selector_options: Some(
                        qdrant_client::qdrant::with_vectors_selector::SelectorOptions::Enable(false)
                    ),
                }),
                ..Default::default()
            })
            .await
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                format!("Scroll failed: {}", e)
            ))?;

            Python::with_gil(|py| {
                // Collect as (sort_key, dict) pairs so we can sort before returning
                let mut entries: Vec<(String, PyObject)> = scroll_result.result.iter()
                    .map(|point| {
                        let dict = PyDict::new(py);

                        // String scalar fields
                        for field in &["key", "value", "category", "description", "entry_id", "agent_id"] {
                            let v = str_payload(&point.payload, field);
                            dict.set_item(*field, v)?;
                        }

                        // List field: aliases
                        let aliases = list_payload(&point.payload, "aliases");
                        dict.set_item("aliases", aliases)?;

                        let sort_key = str_payload(&point.payload, "key").to_lowercase();
                        Ok((sort_key, dict.to_object(py)))
                    })
                    .collect::<PyResult<Vec<_>>>()?;

                entries.sort_by(|a, b| a.0.cmp(&b.0));
                Ok(entries.into_iter().map(|(_, obj)| obj).collect::<Vec<_>>().into_py(py))
            })
        })
    }


    // ── entry_count ───────────────────────────────────────────────────────────

    /// Return the exact number of term definitions stored for a given agent.
    #[pyo3(signature = (agent_id))]
    pub fn entry_count<'py>(
        &self,
        py:       Python<'py>,
        agent_id: String,
    ) -> PyResult<&'py PyAny> {
        let client          = Arc::clone(&self.client);
        let collection_name = self.collection_name.clone();

        future_into_py(py, async move {
            let count_result = client.count(qdrant_client::qdrant::CountPoints {
                collection_name: collection_name.clone(),
                filter:          Some(agent_id_filter(&agent_id)),
                exact:           Some(true),
                ..Default::default()
            })
            .await
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                format!("Count failed: {}", e)
            ))?;

            let count = count_result.result.map(|r| r.count).unwrap_or(0);
            Python::with_gil(|py| Ok(count.into_py(py)))
        })
    }
}


// ── BM25 tokenization ────────────────────────────────────────────────────────

/// Tokenize `text` into a sparse (indices, values) pair for BM25 search.
/// Term frequency counts are used as raw values; Qdrant applies IDF weighting
/// at query time via the Modifier::Idf configured on the collection.
fn tokenize_bm25(tokenizer: &Tokenizer, text: &str) -> Result<(Vec<u32>, Vec<f32>), String> {
    let encoding = tokenizer.encode(text, true)
        .map_err(|e| format!("Tokenization failed: {}", e))?;

    let ids = encoding.get_ids();
    let mut counts: std::collections::HashMap<u32, f32> = std::collections::HashMap::new();
    for &id in ids {
        *counts.entry(id).or_insert(0.0) += 1.0;
    }

    let mut pairs: Vec<(u32, f32)> = counts.into_iter().collect();
    pairs.sort_by_key(|(id, _)| *id);
    let (indices, values) = pairs.into_iter().unzip();
    Ok((indices, values))
}

// ── private helpers ───────────────────────────────────────────────────────────

/// Compute deterministic entry UUID: UUID5(NAMESPACE_DNS, "{agent_id}::{key.to_lowercase()}")
fn entry_point_id(agent_id: &str, key: &str) -> PointId {
    let uuid = Uuid::new_v5(
        &Uuid::NAMESPACE_DNS,
        format!("{}::{}", agent_id, key.to_lowercase()).as_bytes(),
    ).to_string();
    PointId {
        point_id_options: Some(
            qdrant_client::qdrant::point_id::PointIdOptions::Uuid(uuid)
        ),
    }
}

/// Build a simple keyword match Condition on a payload field.
fn keyword_condition(field: &str, value: &str) -> Condition {
    Condition {
        condition_one_of: Some(
            qdrant_client::qdrant::condition::ConditionOneOf::Field(
                qdrant_client::qdrant::FieldCondition {
                    key: field.to_string(),
                    r#match: Some(qdrant_client::qdrant::Match {
                        match_value: Some(
                            qdrant_client::qdrant::r#match::MatchValue::Keyword(value.to_string())
                        ),
                    }),
                    ..Default::default()
                },
            )
        ),
    }
}

/// Filter by agent_id — used in every operation that touches Qdrant.
fn agent_id_filter(agent_id: &str) -> Filter {
    Filter {
        must: vec![keyword_condition("agent_id", agent_id)],
        ..Default::default()
    }
}

/// Batch delete a list of PointIds in a single Qdrant call.
async fn delete_by_ids(
    client:          &qdrant_client::Qdrant,
    collection_name: &str,
    ids:             Vec<PointId>,
) -> PyResult<()> {
    client.delete_points(qdrant_client::qdrant::DeletePoints {
        collection_name: collection_name.to_string(),
        points: Some(qdrant_client::qdrant::PointsSelector {
            points_selector_one_of: Some(
                qdrant_client::qdrant::points_selector::PointsSelectorOneOf::Points(
                    qdrant_client::qdrant::PointsIdsList { ids }
                )
            ),
        }),
        ..Default::default()
    })
    .await
    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
        format!("Batch delete failed: {}", e)
    ))?;
    Ok(())
}

/// Extract a string scalar field from a Qdrant payload map.
fn str_payload<'a>(payload: &'a HashMap<String, QdrantValue>, key: &str) -> &'a str {
    payload.get(key)
        .and_then(|v| {
            if let Some(qdrant_client::qdrant::value::Kind::StringValue(s)) = &v.kind {
                Some(s.as_str())
            } else { None }
        })
        .unwrap_or("")
}

/// Extract a list-of-strings field from a Qdrant payload map.
fn list_payload(payload: &HashMap<String, QdrantValue>, key: &str) -> Vec<String> {
    payload.get(key)
        .and_then(|v| {
            if let Some(qdrant_client::qdrant::value::Kind::ListValue(l)) = &v.kind {
                Some(l.values.iter()
                    .filter_map(|item| {
                        if let Some(qdrant_client::qdrant::value::Kind::StringValue(s)) = &item.kind {
                            Some(s.clone())
                        } else { None }
                    })
                    .collect())
            } else { None }
        })
        .unwrap_or_default()
}

/// Convert a ScoredPoint to a Python dict for recall results.
fn term_to_pydict<'py>(py: Python<'py>, point: &ScoredPoint) -> PyResult<&'py PyDict> {
    let dict = PyDict::new(py);
    dict.set_item("score", point.score)?;
    for field in &["key", "value", "category", "description", "entry_id", "agent_id"] {
        dict.set_item(*field, str_payload(&point.payload, field))?;
    }
    dict.set_item("aliases", list_payload(&point.payload, "aliases"))?;
    Ok(dict)
}