use std::{
    collections::{HashMap, HashSet},
    fs,
    path::PathBuf,
    sync::{Arc, Mutex},
    time::{Duration, Instant},
};

use candle_core::{DType, Device, Tensor};
use candle_nn::VarBuilder;
use candle_transformers::models::bert::{BertModel, Config as BertConfig};
use hf_hub::api::sync::ApiBuilder;
use lru::LruCache;
use reqwest::blocking::Client as HttpClient;
use serde_json::json;
use tokenizers::Tokenizer;
use tokio::sync::{mpsc, oneshot};

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Priority {
    High,
    Normal,
}

struct EmbedRequest {
    text: String,
    priority: Priority,
    sender: oneshot::Sender<Result<Vec<f32>, String>>,
}

#[derive(Clone)]
pub struct EmbedderMetrics {
    pub total_requests: u64,
    pub total_batches: u64,
    pub total_errors: u64,
    pub cache_hits: u64,
    pub cache_misses: u64,
}

/// Configuration for local Rust-native Hugging Face inference.
#[derive(Clone, Debug)]
pub struct LocalConfig {
    pub model_id: String,
    pub cache_dir: Option<String>,
}

/// Supported remote providers.
#[derive(Clone, Debug, PartialEq)]
pub enum Provider {
    OpenAI,
    AzureOpenAI,
    Gemini,
    Cohere,
    HuggingFace,
    Mistral,
    Together,
    VoyageAI,
    JinaAI,
    Nomic,
    OpenRouter,
    DeepInfra,
}

impl Provider {
    pub fn from_str(s: &str) -> Self {
        match s.to_lowercase().as_str() {
            "azure" | "azure_openai" | "azure-openai" => Provider::AzureOpenAI,
            "gemini" | "google" | "google_gemini" | "google-gemini" => Provider::Gemini,
            "cohere" => Provider::Cohere,
            "huggingface" | "hf" => Provider::HuggingFace,
            "mistral" => Provider::Mistral,
            "together" | "togetherai" | "together-ai" => Provider::Together,
            "voyage" | "voyageai" | "voyage-ai" => Provider::VoyageAI,
            "jina" | "jinaai" | "jina-ai" => Provider::JinaAI,
            "nomic" => Provider::Nomic,
            "openrouter" | "open_router" | "open-router" => Provider::OpenRouter,
            "deepinfra" | "deep_infra" | "deep-infra" => Provider::DeepInfra,
            _ => Provider::OpenAI,
        }
    }

    fn is_openai_compatible(&self) -> bool {
        matches!(
            self,
            Provider::OpenAI
                | Provider::Mistral
                | Provider::Together
                | Provider::VoyageAI
                | Provider::JinaAI
                | Provider::Nomic
                | Provider::OpenRouter
                | Provider::DeepInfra
        )
    }
}

/// Configuration for remote API embedding backends.
#[derive(Clone, Debug)]
pub struct RemoteConfig {
    pub provider: Provider,
    pub api_key: String,
    pub base_url: String,
    pub model_name: String,
}

struct LocalModel {
    model: BertModel,
    device: Device,
    model_id: String,
}

enum Backend {
    Uninitialized,
    LocalHf(LocalModel),
    RemoteHttp {
        client: HttpClient,
        config: RemoteConfig,
    },
}

pub struct Embedder {
    tokenizer: Arc<Tokenizer>,
    backend: Arc<Mutex<Backend>>,
    hidden_size: usize,
    max_batch: usize,
    batch_queue: mpsc::UnboundedSender<EmbedRequest>,
    shutdown: Arc<Mutex<bool>>,
    cache: Arc<Mutex<LruCache<String, Vec<f32>>>>,
    metrics: Arc<Mutex<EmbedderMetrics>>,
}

impl Embedder {
    pub fn new(
        tokenizer_path: Option<String>,
        tokenizer_model_id: Option<String>,
        cache_dir: Option<String>,
        hidden_size: usize,
        max_batch: usize,
    ) -> Result<Self, String> {
        if hidden_size == 0 || hidden_size > 4096 {
            return Err("hidden_size must be between 1 and 4096".to_string());
        }
        if max_batch < 2 {
            return Err("max_batch must be at least 2 for efficient batching".to_string());
        }

        let tokenizer = load_tokenizer(tokenizer_path, tokenizer_model_id, cache_dir)?;

        let (tx, rx) = mpsc::unbounded_channel();
        let shutdown = Arc::new(Mutex::new(false));
        let cache = Arc::new(Mutex::new(LruCache::new(
            std::num::NonZeroUsize::new(1000).unwrap(),
        )));
        let metrics = Arc::new(Mutex::new(EmbedderMetrics {
            total_requests: 0,
            total_batches: 0,
            total_errors: 0,
            cache_hits: 0,
            cache_misses: 0,
        }));

        let embedder = Self {
            tokenizer: Arc::new(tokenizer),
            backend: Arc::new(Mutex::new(Backend::Uninitialized)),
            hidden_size,
            max_batch,
            batch_queue: tx,
            shutdown: Arc::clone(&shutdown),
            cache: Arc::clone(&cache),
            metrics: Arc::clone(&metrics),
        };

        embedder.spawn_batcher_thread(rx);
        Ok(embedder)
    }

    pub fn setup_local(&self, config: LocalConfig) -> Result<(), String> {
        let model = load_local_model(&config.model_id, config.cache_dir.as_deref())?;

        // Fast startup validation to fail early on invalid model artifacts.
        let _ = embed_local(&model, &self.tokenizer, &["test".to_string()], self.hidden_size)?;

        *self.backend.lock().unwrap() = Backend::LocalHf(model);
        Ok(())
    }

    pub fn setup_remote(&self, config: RemoteConfig) -> Result<(), String> {
        let client = HttpClient::builder()
            .timeout(Duration::from_secs(30))
            .build()
            .map_err(|e| format!("Client build error: {e}"))?;

        *self.backend.lock().unwrap() = Backend::RemoteHttp { client, config };
        Ok(())
    }

    pub fn compute_sparse_vector(&self, text: &str) -> Result<(Vec<u32>, Vec<f32>), String> {
        let encoding = self
            .tokenizer
            .encode(text, true)
            .map_err(|e| format!("Tokenization failed: {e}"))?;

        let ids = encoding.get_ids();
        let mut counts: HashMap<u32, f32> = HashMap::new();
        for &id in ids {
            *counts.entry(id).or_insert(0.0) += 1.0;
        }

        let mut pairs: Vec<(u32, f32)> = counts.into_iter().collect();
        pairs.sort_by_key(|(id, _)| *id);
        let (indices, values): (Vec<u32>, Vec<f32>) = pairs.into_iter().unzip();
        Ok((indices, values))
    }

    pub async fn embed(&self, text: &str) -> Result<Vec<f32>, String> {
        self.embed_with_priority(text, Priority::Normal).await
    }

    pub async fn embed_high_priority(&self, text: &str) -> Result<Vec<f32>, String> {
        self.embed_with_priority(text, Priority::High).await
    }

    async fn embed_with_priority(&self, text: &str, priority: Priority) -> Result<Vec<f32>, String> {
        {
            let mut cache = self.cache.lock().unwrap();
            if let Some(cached) = cache.get(text) {
                self.metrics.lock().unwrap().cache_hits += 1;
                return Ok(cached.clone());
            }
            self.metrics.lock().unwrap().cache_misses += 1;
        }
        self.metrics.lock().unwrap().total_requests += 1;

        let (tx, rx) = oneshot::channel();
        self.batch_queue
            .send(EmbedRequest {
                text: text.to_string(),
                priority,
                sender: tx,
            })
            .map_err(|_| "Shutdown".to_string())?;

        let result = tokio::time::timeout(Duration::from_secs(60), rx)
            .await
            .map_err(|_| "Timeout".to_string())?
            .map_err(|_| "Dropped".to_string())??;

        {
            let mut cache = self.cache.lock().unwrap();
            cache.put(text.to_string(), result.clone());
        }
        Ok(result)
    }

    pub async fn embed_batch(&self, texts: Vec<String>) -> Result<Vec<Vec<f32>>, String> {
        self.embed_batch_with_priority(texts, Priority::Normal).await
    }

    async fn embed_batch_with_priority(
        &self,
        texts: Vec<String>,
        priority: Priority,
    ) -> Result<Vec<Vec<f32>>, String> {
        if texts.is_empty() {
            return Ok(vec![]);
        }
        let len = texts.len();
        let mut set = tokio::task::JoinSet::new();

        for (i, text) in texts.into_iter().enumerate() {
            let embedder_clone = self.clone_for_task();
            set.spawn(async move { (i, embedder_clone.embed_with_priority(&text, priority).await) });
        }

        let mut out: Vec<Option<Vec<f32>>> = vec![None; len];
        while let Some(res) = set.join_next().await {
            let (i, r) = res.map_err(|e| format!("Join error: {e}"))?;
            out[i] = Some(r?);
        }
        Ok(out.into_iter().flatten().collect())
    }

    fn clone_for_task(&self) -> Self {
        Self {
            tokenizer: Arc::clone(&self.tokenizer),
            backend: Arc::clone(&self.backend),
            hidden_size: self.hidden_size,
            max_batch: self.max_batch,
            batch_queue: self.batch_queue.clone(),
            shutdown: Arc::clone(&self.shutdown),
            cache: Arc::clone(&self.cache),
            metrics: Arc::clone(&self.metrics),
        }
    }

    pub fn shutdown(&self) {
        *self.shutdown.lock().unwrap() = true;
    }

    pub fn clear_cache(&self) {
        self.cache.lock().unwrap().clear();
    }

    pub fn get_metrics(&self) -> EmbedderMetrics {
        self.metrics.lock().unwrap().clone()
    }

    fn spawn_batcher_thread(&self, mut rx: mpsc::UnboundedReceiver<EmbedRequest>) {
        let tokenizer = Arc::clone(&self.tokenizer);
        let backend = Arc::clone(&self.backend);
        let hidden = self.hidden_size;
        let shutdown = Arc::clone(&self.shutdown);
        let metrics = Arc::clone(&self.metrics);
        let max_batch = self.max_batch;

        std::thread::spawn(move || {
            let mut batch_high = Vec::new();
            let mut txs_high = Vec::new();
            let mut batch_norm = Vec::new();
            let mut txs_norm = Vec::new();
            let mut last = Instant::now();

            loop {
                if *shutdown.lock().unwrap() {
                    break;
                }

                let deadline = Instant::now() + Duration::from_millis(5);
                while Instant::now() < deadline {
                    match rx.try_recv() {
                        Ok(req) => {
                            if req.priority == Priority::High {
                                batch_high.push(req.text);
                                txs_high.push(req.sender);
                            } else {
                                batch_norm.push(req.text);
                                txs_norm.push(req.sender);
                            }
                            if batch_high.len() >= max_batch || batch_norm.len() >= max_batch {
                                break;
                            }
                        }
                        Err(mpsc::error::TryRecvError::Empty) => break,
                        Err(mpsc::error::TryRecvError::Disconnected) => return,
                    }
                }

                if !batch_high.is_empty() {
                    Self::process_batch(
                        &mut batch_high,
                        &mut txs_high,
                        &backend,
                        &tokenizer,
                        hidden,
                        &metrics,
                    );
                    last = Instant::now();
                }
                if !batch_norm.is_empty() && (batch_high.is_empty() && last.elapsed() > Duration::from_millis(50)) {
                    Self::process_batch(
                        &mut batch_norm,
                        &mut txs_norm,
                        &backend,
                        &tokenizer,
                        hidden,
                        &metrics,
                    );
                    last = Instant::now();
                }
                std::thread::sleep(Duration::from_millis(1));
            }
        });
    }

    fn process_batch(
        batch: &mut Vec<String>,
        receivers: &mut Vec<oneshot::Sender<Result<Vec<f32>, String>>>,
        backend: &Arc<Mutex<Backend>>,
        tokenizer: &Tokenizer,
        hidden: usize,
        metrics: &Arc<Mutex<EmbedderMetrics>>,
    ) {
        let mut guard = backend.lock().unwrap();
        metrics.lock().unwrap().total_batches += 1;

        let result = match &mut *guard {
            Backend::LocalHf(model) => embed_local(model, tokenizer, batch, hidden),
            Backend::RemoteHttp { client, config } => embed_remote(client, config, batch),
            Backend::Uninitialized => Err("Uninitialized backend".to_string()),
        };

        match result {
            Ok(emb) => {
                for (tx, e) in receivers.drain(..).zip(emb.into_iter()) {
                    let _ = tx.send(Ok(e));
                }
            }
            Err(e) => {
                metrics.lock().unwrap().total_errors += 1;
                for tx in receivers.drain(..) {
                    let _ = tx.send(Err(e.clone()));
                }
            }
        }
        batch.clear();
    }
}

fn hf_api(cache_dir: Option<&str>) -> Result<hf_hub::api::sync::Api, String> {
    let mut builder = ApiBuilder::new().with_progress(false);
    if let Some(dir) = cache_dir {
        let path = PathBuf::from(dir);
        if !path.exists() {
            fs::create_dir_all(&path)
                .map_err(|e| format!("Failed to create HF cache dir {path:?}: {e}"))?;
        }
        builder = builder.with_cache_dir(path);
    }
    builder.build().map_err(|e| format!("Failed to build HF API client: {e}"))
}

fn download_file(model_id: &str, cache_dir: Option<&str>, filename: &str) -> Result<PathBuf, String> {
    let api = hf_api(cache_dir)?;
    api.model(model_id.to_string())
        .get(filename)
        .map_err(|e| format!("Failed to fetch '{filename}' for model '{model_id}': {e}"))
}

fn load_tokenizer(
    tokenizer_path: Option<String>,
    tokenizer_model_id: Option<String>,
    cache_dir: Option<String>,
) -> Result<Tokenizer, String> {
    if let Some(path) = tokenizer_path {
        let p = path.trim();
        if !p.is_empty() {
            return Tokenizer::from_file(p)
                .map_err(|e| format!("Failed to load tokenizer from '{p}': {e}"));
        }
    }

    let model_id = tokenizer_model_id
        .as_ref()
        .map(|s| s.trim())
        .filter(|s| !s.is_empty())
        .ok_or_else(|| {
            "Tokenizer is required but no tokenizer_path or tokenizer_model_id was provided"
                .to_string()
        })?;

    let tok_file = download_file(model_id, cache_dir.as_deref(), "tokenizer.json")?;
    Tokenizer::from_file(tok_file)
        .map_err(|e| format!("Failed to load tokenizer for model '{model_id}': {e}"))
}

fn resolve_weight_files(model_id: &str, cache_dir: Option<&str>) -> Result<Vec<PathBuf>, String> {
    if let Ok(single) = download_file(model_id, cache_dir, "model.safetensors") {
        return Ok(vec![single]);
    }

    let index_path = download_file(model_id, cache_dir, "model.safetensors.index.json")?;
    let raw = fs::read_to_string(&index_path)
        .map_err(|e| format!("Failed reading safetensors index {index_path:?}: {e}"))?;
    let parsed: serde_json::Value = serde_json::from_str(&raw)
        .map_err(|e| format!("Invalid safetensors index JSON {index_path:?}: {e}"))?;

    let Some(weight_map) = parsed.get("weight_map").and_then(|v| v.as_object()) else {
        return Err(format!(
            "Invalid safetensors index for model '{model_id}': missing 'weight_map'"
        ));
    };

    let mut shards = HashSet::new();
    for file_name in weight_map.values().filter_map(|v| v.as_str()) {
        shards.insert(file_name.to_string());
    }

    if shards.is_empty() {
        return Err(format!(
            "No safetensor shards listed in model.safetensors.index.json for '{model_id}'"
        ));
    }

    let mut shard_paths = Vec::with_capacity(shards.len());
    for shard in shards {
        shard_paths.push(download_file(model_id, cache_dir, &shard)?);
    }
    shard_paths.sort();
    Ok(shard_paths)
}

fn load_local_model(model_id: &str, cache_dir: Option<&str>) -> Result<LocalModel, String> {
    let config_path = download_file(model_id, cache_dir, "config.json")?;
    let cfg_raw = fs::read_to_string(&config_path)
        .map_err(|e| format!("Failed reading config for model '{model_id}': {e}"))?;
    let config: BertConfig = serde_json::from_str(&cfg_raw)
        .map_err(|e| format!("Invalid config.json for model '{model_id}': {e}"))?;

    let weight_files = resolve_weight_files(model_id, cache_dir)?;
    let device = Device::Cpu;

    let vb = unsafe {
        VarBuilder::from_mmaped_safetensors(&weight_files, DType::F32, &device)
            .map_err(|e| format!("Failed loading safetensors for model '{model_id}': {e}"))?
    };

    let model = BertModel::load(vb, &config)
        .map_err(|e| format!("Failed to initialize local model '{model_id}': {e}"))?;

    Ok(LocalModel {
        model,
        device,
        model_id: model_id.to_string(),
    })
}

fn embed_local(
    local: &LocalModel,
    tokenizer: &Tokenizer,
    texts: &[String],
    expected_hidden_size: usize,
) -> Result<Vec<Vec<f32>>, String> {
    let encodings = tokenizer
        .encode_batch(texts.to_vec(), true)
        .map_err(|e| format!("Tokenization failed: {e}"))?;

    let token_ids = encodings
        .iter()
        .map(|enc| Tensor::new(enc.get_ids(), &local.device))
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| format!("Failed to build token tensors: {e}"))?;

    let attention_mask = encodings
        .iter()
        .map(|enc| Tensor::new(enc.get_attention_mask(), &local.device))
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| format!("Failed to build attention mask tensors: {e}"))?;

    let token_ids = Tensor::stack(&token_ids, 0)
        .map_err(|e| format!("Failed stacking token tensors: {e}"))?;
    let attention_mask = Tensor::stack(&attention_mask, 0)
        .map_err(|e| format!("Failed stacking attention mask tensors: {e}"))?;
    let token_type_ids = token_ids
        .zeros_like()
        .map_err(|e| format!("Failed to build token_type_ids: {e}"))?;

    let hidden = local
        .model
        .forward(&token_ids, &token_type_ids, Some(&attention_mask))
        .map_err(|e| format!("Local inference failed for model '{}': {e}", local.model_id))?;

    let hidden_3d = hidden
        .to_vec3::<f32>()
        .map_err(|e| format!("Failed to read model output: {e}"))?;
    let mask_2d = attention_mask
        .to_vec2::<u32>()
        .map_err(|e| format!("Failed to read attention mask: {e}"))?;

    if hidden_3d.len() != mask_2d.len() {
        return Err("Local inference returned mismatched output and mask batch sizes".to_string());
    }

    let mut out = Vec::with_capacity(hidden_3d.len());
    for (seq_hidden, seq_mask) in hidden_3d.into_iter().zip(mask_2d.into_iter()) {
        if seq_hidden.len() != seq_mask.len() {
            return Err("Local inference returned mismatched sequence lengths".to_string());
        }

        let mut pooled = vec![0f32; seq_hidden.first().map(|v| v.len()).unwrap_or(0)];
        let mut count = 0f32;

        for (token_vec, m) in seq_hidden.into_iter().zip(seq_mask.into_iter()) {
            if m == 0 {
                continue;
            }
            count += 1.0;
            for (j, v) in token_vec.into_iter().enumerate() {
                pooled[j] += v;
            }
        }

        let inv = 1.0f32 / count.max(1.0);
        let mut norm = 0f32;
        for v in &mut pooled {
            *v *= inv;
            norm += *v * *v;
        }
        let inv_norm = 1.0f32 / norm.sqrt().max(1e-12);
        for v in &mut pooled {
            *v *= inv_norm;
        }

        if expected_hidden_size != 0 && pooled.len() != expected_hidden_size {
            return Err(format!(
                "Model output dimension mismatch: got {}, expected {}. Adjust memory.vector_size to match the model.",
                pooled.len(), expected_hidden_size
            ));
        }

        out.push(pooled);
    }

    Ok(out)
}

fn embed_remote(client: &HttpClient, config: &RemoteConfig, texts: &[String]) -> Result<Vec<Vec<f32>>, String> {
    let cleaned_texts: Vec<String> = texts.iter().map(|t| t.replace("\n", " ")).collect();
    let url = config.base_url.trim_end_matches('/');

    let (endpoint, payload) = if config.provider.is_openai_compatible() {
        (
            format!("{url}/embeddings"),
            json!({
                "input": cleaned_texts,
                "model": config.model_name
            }),
        )
    } else {
        match config.provider {
            Provider::AzureOpenAI => (
                format!("{url}/embeddings"),
                json!({ "input": cleaned_texts }),
            ),
            Provider::Gemini => (
                format!("{url}/models/{}:batchEmbedContents", config.model_name),
                json!({
                    "requests": cleaned_texts
                        .iter()
                        .map(|text| json!({ "content": { "parts": [{ "text": text }] } }))
                        .collect::<Vec<_>>()
                }),
            ),
            Provider::Cohere => (
                format!("{url}/embed"),
                json!({
                    "texts": cleaned_texts,
                    "model": config.model_name,
                    "input_type": "search_query"
                }),
            ),
            Provider::HuggingFace => (
                format!("{url}/models/{}/feature-extraction", config.model_name),
                json!({
                    "inputs": cleaned_texts,
                    "options": { "wait_for_model": true }
                }),
            ),
            _ => unreachable!("OpenAI-compatible providers are handled above"),
        }
    };

    let mut req = client
        .post(&endpoint)
        .header("Content-Type", "application/json")
        .json(&payload);

    if !config.api_key.is_empty() {
        match config.provider {
            Provider::AzureOpenAI => req = req.header("api-key", &config.api_key),
            Provider::Gemini => req = req.query(&[("key", config.api_key.as_str())]),
            _ => req = req.header("Authorization", format!("Bearer {}", config.api_key)),
        }
    }

    let resp = req
        .send()
        .map_err(|e| format!("HTTP request failed: {e}"))?;

    if !resp.status().is_success() {
        return Err(format!(
            "API Error {}: {}",
            resp.status(),
            resp.text().unwrap_or_default()
        ));
    }

    let body: serde_json::Value = resp
        .json()
        .map_err(|e| format!("JSON parse error: {e}"))?;

    if config.provider.is_openai_compatible() || config.provider == Provider::AzureOpenAI {
        let data = body
            .get("data")
            .and_then(|v| v.as_array())
            .ok_or("Invalid OpenAI response: missing 'data'")?;

        let mut embeddings = Vec::new();
        for item in data {
            let vec = item
                .get("embedding")
                .and_then(|v| v.as_array())
                .ok_or("Invalid OpenAI response: missing 'embedding'")?;
            embeddings.push(vec.iter().map(|v| v.as_f64().unwrap_or(0.0) as f32).collect());
        }
        Ok(embeddings)
    } else {
        match config.provider {
            Provider::Gemini => {
                if let Some(items) = body.get("embeddings").and_then(|v| v.as_array()) {
                    let mut out = Vec::new();
                    for item in items {
                        let values = item
                            .get("values")
                            .and_then(|v| v.as_array())
                            .ok_or("Invalid Gemini response: missing embedding values")?;
                        out.push(values.iter().map(|v| v.as_f64().unwrap_or(0.0) as f32).collect());
                    }
                    return Ok(out);
                }

                if let Some(values) = body
                    .get("embedding")
                    .and_then(|v| v.get("values"))
                    .and_then(|v| v.as_array())
                {
                    let vec = values.iter().map(|v| v.as_f64().unwrap_or(0.0) as f32).collect();
                    return Ok(vec![vec]);
                }

                Err("Invalid Gemini response: missing embeddings".to_string())
            }
            Provider::Cohere => {
                let embeddings = body
                    .get("embeddings")
                    .and_then(|v| v.as_array())
                    .ok_or("Invalid Cohere response: missing 'embeddings'")?;

                let mut out = Vec::new();
                for vec in embeddings {
                    let f32_vec = vec
                        .as_array()
                        .ok_or("Cohere embedding not an array")?
                        .iter()
                        .map(|v| v.as_f64().unwrap_or(0.0) as f32)
                        .collect();
                    out.push(f32_vec);
                }
                Ok(out)
            }
            Provider::HuggingFace => {
                let arr = body.as_array().ok_or("Invalid HF response: expected array")?;
                let mut out = Vec::new();
                for vec in arr {
                    let f32_vec = vec
                        .as_array()
                        .ok_or("HF embedding not an array")?
                        .iter()
                        .map(|v| v.as_f64().unwrap_or(0.0) as f32)
                        .collect();
                    out.push(f32_vec);
                }
                Ok(out)
            }
            _ => unreachable!("OpenAI-compatible providers are handled above"),
        }
    }
}
