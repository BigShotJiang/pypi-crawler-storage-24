use pyo3::prelude::*;

mod init;
mod embed;
mod provider_utils;
mod episodic_memory;
mod procedural_memory;
mod semantic_memory;

pub use init::QdrantManager;
pub use embed::Embedder;
pub use episodic_memory::EpisodicMemory;
pub use procedural_memory::ProceduralMemory;
pub use semantic_memory::SemanticMemory;

#[pymodule]
fn memory(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_class::<QdrantManager>()?;
    m.add_class::<EpisodicMemory>()?;
    m.add_class::<ProceduralMemory>()?;
    m.add_class::<SemanticMemory>()?;
    Ok(())
}