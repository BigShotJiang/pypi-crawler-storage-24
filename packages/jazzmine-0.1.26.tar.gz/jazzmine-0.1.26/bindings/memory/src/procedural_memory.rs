#![allow(deprecated, non_local_definitions, unsafe_op_in_unsafe_fn)]

use pyo3::prelude::*;
use pyo3::types::PyDict;
use pyo3_asyncio::tokio::future_into_py;
use qdrant_client::qdrant::{
    Condition, Filter, SearchPoints, ScoredPoint, Value as QdrantValue,
    with_payload_selector::SelectorOptions, WithPayloadSelector,
    Vector, DenseVector, SparseVector, Vectors, NamedVectors, PointStruct, PointId,
};
use qdrant_client::qdrant::vector;
use std::collections::HashMap;
use std::sync::Arc;
use uuid::Uuid;

use crate::embed::{Embedder, LocalConfig, RemoteConfig};
use crate::init::QdrantManager;
use crate::provider_utils::resolve_remote_provider_config;

// ── Python-exposed struct ─────────────────────────────────────────────────────

#[pyclass]
pub struct ProceduralMemory {
    client:          Arc<qdrant_client::Qdrant>,
    embedder:        Arc<Embedder>,
    collection_name: String,
}

// ── Internal ranked result ────────────────────────────────────────────────────

#[derive(Debug, Clone)]
struct RankedFlow {
    score:   f32,
    payload: HashMap<String, QdrantValue>,
}

// ── Python methods ────────────────────────────────────────────────────────────

#[pymethods]
impl ProceduralMemory {

    #[new]
    #[pyo3(signature = (
        qdrant_manager,
        tokenizer_path = None,
        tokenizer_model_id = None,
        local_model_id = None,
        local_cache_dir = None,
        api_key     = None,
        base_url    = None,
        model_name  = None,
        provider    = "openai".to_string(),
        hidden_size = 384,
        max_batch   = 8
    ))]
    pub fn new(
        qdrant_manager: Py<QdrantManager>,
        tokenizer_path: Option<String>,
        tokenizer_model_id: Option<String>,
        local_model_id: Option<String>,
        local_cache_dir: Option<String>,
        api_key:     Option<String>,
        base_url:    Option<String>,
        model_name:  Option<String>,
        provider:    Option<String>,
        hidden_size: usize,
        max_batch:   usize,
    ) -> PyResult<Self> {
        Python::with_gil(|py| {

            let mgr = qdrant_manager.borrow(py);
            let client           = mgr.client();
            let collection_name       = mgr.flows_collection_name();

            let tokenizer_model_fallback = tokenizer_model_id
                .clone()
                .or_else(|| local_model_id.clone())
                .or_else(|| model_name.clone())
                .or_else(|| Some("BAAI/bge-small-en-v1.5".to_string()));

            let embedder = Arc::new(
                Embedder::new(
                    tokenizer_path,
                    tokenizer_model_fallback,
                    local_cache_dir.clone(),
                    hidden_size,
                    max_batch,
                )
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))?,
            );

            if let Some(model_id) = local_model_id {
                // Local setup — model name drives HF download/cache
                embedder.setup_local(LocalConfig {
                    model_id,
                    cache_dir: local_cache_dir,
                })
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                        format!("Local setup failed: {}", e)
                    ))?;

            } else if let Some(key) = api_key {
                // Remote setup — api_key is the only required parameter
                let (prov, url, model) = resolve_remote_provider_config(provider, base_url, model_name);
                embedder.setup_remote(RemoteConfig {
                    provider: prov, api_key: key, base_url: url, model_name: model,
                })
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("Remote setup failed: {}", e)
                ))?;

            } else {
                return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                    "Must provide either 'local_model_id' (local Rust model) or 'api_key' (remote)."
                ));
            }

            Ok(ProceduralMemory { client, embedder, collection_name })
        })
    }

    // ── memorize ─────────────────────────────────────────────────────────────

    #[pyo3(signature = (
        embedding_text,
        flow_id,
        flow_name,
        flow_type,
        description,
        condition,
        agent_id,
        desired_effects,
        checksum
    ))]
    pub fn memorize<'py>(
        &self,
        py: Python<'py>,
        embedding_text: String,
        flow_id:        String,
        flow_name:      String,
        flow_type:      String,
        description:     String,
        condition:       String,
        agent_id:        String,
        desired_effects: Vec<String>,
        checksum:        String,
    ) -> PyResult<&'py PyAny> {
        let embedder        = Arc::clone(&self.embedder);
        let client          = Arc::clone(&self.client);
        let collection_name = self.collection_name.clone();

        future_into_py(py, async move {
            // Dense + sparse embeddings
            let dense = embedder.embed_high_priority(&embedding_text).await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("Dense embedding failed: {}", e)
                ))?;

            let (bm25_indices, bm25_values) = embedder.compute_sparse_vector(&embedding_text)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("Sparse vector failed: {}", e)
                ))?;

            // Use flow_id as the Qdrant point UUID — upsert is naturally idempotent
            let point_uuid = Uuid::parse_str(&flow_id)
                .unwrap_or_else(|_| Uuid::new_v4())
                .to_string();

            // Build named vectors map
            let mut vectors_map = HashMap::new();
            vectors_map.insert("flow".to_string(), Vector {
                data:          Vec::new(),
                indices:       None,
                vectors_count: None,
                vector:        Some(vector::Vector::Dense(DenseVector { data: dense })),
            });
            vectors_map.insert("bm25".to_string(), Vector {
                data:          Vec::new(),
                indices:       None,
                vectors_count: None,
                vector:        Some(vector::Vector::Sparse(SparseVector {
                    indices: bm25_indices,
                    values:  bm25_values,
                })),
            });

            // Build payload
            let mut payload = HashMap::new();
            payload.insert("flow_id".into(),        QdrantValue::from(flow_id.clone()));
            payload.insert("flow_name".into(),      QdrantValue::from(flow_name));
            payload.insert("flow_type".into(),      QdrantValue::from(flow_type));
            payload.insert("description".into(),    QdrantValue::from(description));
            payload.insert("condition".into(),      QdrantValue::from(condition));
            payload.insert("agent_id".into(), QdrantValue::from(agent_id));
            payload.insert(
                "desired_effects".into(),
                QdrantValue::from(
                    desired_effects.into_iter().map(QdrantValue::from).collect::<Vec<_>>()
                ),
            );
            payload.insert("checksum".into(), QdrantValue::from(checksum));

            let point = PointStruct {
                id: Some(PointId {
                    point_id_options: Some(
                        qdrant_client::qdrant::point_id::PointIdOptions::Uuid(point_uuid)
                    ),
                }),
                vectors: Some(Vectors {
                    vectors_options: Some(
                        qdrant_client::qdrant::vectors::VectorsOptions::Vectors(
                            NamedVectors { vectors: vectors_map }
                        )
                    ),
                }),
                payload,
            };

            client.upsert_points(qdrant_client::qdrant::UpsertPoints {
                collection_name: collection_name.clone(),
                points:          vec![point],
                ..Default::default()
            })
            .await
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                format!("Upsert failed: {}", e)
            ))?;

            Ok(())
        })
    }

    // ── update_memory ─────────────────────────────────────────────────────────

    /// Re-embed and replace a flow whose definition has changed.
    /// Delegates to memorize — same upsert-by-flow_id semantics.
    #[pyo3(signature = (
        embedding_text,
        flow_id,
        flow_name,
        flow_type,
        description,
        condition,
        agent_id,
        desired_effects,
        checksum
    ))]
    pub fn update_memory<'py>(
        &self,
        py: Python<'py>,
        embedding_text: String,
        flow_id:        String,
        flow_name:      String,
        flow_type:      String,
        description:     String,
        condition:       String,
        agent_id:        String,
        desired_effects: Vec<String>,
        checksum:        String,
    ) -> PyResult<&'py PyAny> {
        self.memorize(
            py,
            embedding_text,
            flow_id,
            flow_name,
            flow_type,
            description,
            condition,
            agent_id,
            desired_effects,
            checksum,
        )
    }

    // ── recall ────────────────────────────────────────────────────────────────

    /// Retrieve the top-k most relevant flows for a query.
    ///
    /// Returns list[dict] with keys:
    ///   flow_id, flow_name, flow_type, description, condition,
    ///   flow_id, flow_name, flow_type, description, condition, agent_id, score
    #[pyo3(signature = (query, agent_id, top_k = 3, rrf_k = 60))]
    pub fn recall<'py>(
        &self,
        py:       Python<'py>,
        query:    String,
        agent_id: String,
        top_k:    u64,
        rrf_k:    u64, // RRF k parameter — higher means more score contribution from lower-ranked results, default 60 is a common choice in literature
    ) -> PyResult<&'py PyAny> {
        let embedder        = Arc::clone(&self.embedder);
        let client          = Arc::clone(&self.client);
        let collection_name = self.collection_name.clone();

        let stage1_limit = (top_k * 4).max(10);

        future_into_py(py, async move {
            // 1. Embed query
            let dense_query = embedder.embed_high_priority(&query).await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("Query embedding failed: {}", e)
                ))?;
            let (bm25_idx, bm25_vals) = embedder.compute_sparse_vector(&query)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("Sparse query failed: {}", e)
                ))?;

            // 2. Filter by agent_id
            let filter = Filter {
                must: vec![Condition {
                    condition_one_of: Some(
                        qdrant_client::qdrant::condition::ConditionOneOf::Field(
                            qdrant_client::qdrant::FieldCondition {
                                key: "agent_id".to_string(),
                                r#match: Some(qdrant_client::qdrant::Match {
                                    match_value: Some(
                                        qdrant_client::qdrant::r#match::MatchValue::Keyword(
                                            agent_id.clone(),
                                        )
                                    ),
                                }),
                                ..Default::default()
                            },
                        )
                    ),
                }],
                ..Default::default()
            };

            // 3. Dense + BM25 searches concurrently
            let dense_search = SearchPoints {
                collection_name: collection_name.clone(),
                vector:          dense_query.clone(),
                vector_name:     Some("flow".to_string()),
                filter:          Some(filter.clone()),
                limit:           stage1_limit,
                with_payload:    Some(WithPayloadSelector {
                    selector_options: Some(SelectorOptions::Enable(true)),
                }),
                ..Default::default()
            };

            let bm25_search = SearchPoints {
                collection_name: collection_name.clone(),
                sparse_indices:  Some(qdrant_client::qdrant::SparseIndices { data: bm25_idx }),
                vector:          bm25_vals,
                vector_name:     Some("bm25".to_string()),
                filter:          Some(filter),
                limit:           stage1_limit,
                with_payload:    Some(WithPayloadSelector {
                    selector_options: Some(SelectorOptions::Enable(true)),
                }),
                ..Default::default()
            };

            let (dense_res, bm25_res) = tokio::try_join!(
                client.search_points(dense_search),
                client.search_points(bm25_search),
            ).map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                format!("Search failed: {}", e)
            ))?;

            // 4. RRF fusion — equal weights for dense and BM25
            let rrf_k_f = rrf_k as f32;
            let mut score_map: HashMap<String, (f32, HashMap<String, QdrantValue>)> = HashMap::new();

            for (rank, point) in dense_res.result.into_iter().enumerate() {
                if let Some(id) = extract_point_id(&point) {
                    let rrf = 1.0 / (rrf_k_f + (rank + 1) as f32);
                    score_map.entry(id)
                        .and_modify(|(s, _)| *s += rrf)
                        .or_insert((rrf, point.payload));
                }
            }
            for (rank, point) in bm25_res.result.into_iter().enumerate() {
                if let Some(id) = extract_point_id(&point) {
                    let rrf = 1.0 / (rrf_k_f + (rank + 1) as f32);
                    score_map.entry(id)
                        .and_modify(|(s, _)| *s += rrf)
                        .or_insert((rrf, point.payload));
                }
            }

            // 5. Sort by RRF score descending.
            let mut ranked: Vec<RankedFlow> = score_map.into_iter()
                .map(|(_, (score, payload))| RankedFlow { score, payload })
                .collect();


            ranked.sort_by(|a, b| {
                b.score.partial_cmp(&a.score)
                    .unwrap_or(std::cmp::Ordering::Equal)
            });

            ranked.truncate(top_k as usize);

            // 6. Convert to Python dicts
            Python::with_gil(|py| {
                ranked.iter()
                    .map(|f| flow_to_pydict(py, f))
                    .collect::<PyResult<Vec<_>>>()
                    .map(|v| v.into_py(py))
            })
        })
    }

    // ── list_flows ────────────────────────────────────────────────────────────

    /// Scroll all flows stored for a given agent_id.
    /// Returns list[dict] with keys: flow_id, flow_name, flow_type, checksum.
    /// Used by sync_registry() at startup to detect new, changed, and deleted flows.
    #[pyo3(signature = (agent_id))]
    pub fn list_flows<'py>(
        &self,
        py:       Python<'py>,
        agent_id: String,
    ) -> PyResult<&'py PyAny> {
        let client          = Arc::clone(&self.client);
        let collection_name = self.collection_name.clone();

        future_into_py(py, async move {
            let filter = Filter {
                must: vec![Condition {
                    condition_one_of: Some(
                        qdrant_client::qdrant::condition::ConditionOneOf::Field(
                            qdrant_client::qdrant::FieldCondition {
                                key: "agent_id".to_string(),
                                r#match: Some(qdrant_client::qdrant::Match {
                                    match_value: Some(
                                        qdrant_client::qdrant::r#match::MatchValue::Keyword(
                                            agent_id.clone(),
                                        )
                                    ),
                                }),
                                ..Default::default()
                            },
                        )
                    ),
                }],
                ..Default::default()
            };

            let scroll_result = client.scroll(qdrant_client::qdrant::ScrollPoints {
                collection_name: collection_name.clone(),
                filter:          Some(filter),
                limit:           Some(10_000),
                with_payload:    Some(WithPayloadSelector {
                    selector_options: Some(SelectorOptions::Enable(true)),
                }),
                with_vectors:    Some(qdrant_client::qdrant::WithVectorsSelector {
                    selector_options: Some(
                        qdrant_client::qdrant::with_vectors_selector::SelectorOptions::Enable(false)
                    ),
                }),
                ..Default::default()
            })
            .await
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                format!("Scroll failed: {}", e)
            ))?;

            Python::with_gil(|py| {
                scroll_result.result.iter()
                    .map(|point| {
                        let dict = PyDict::new(py);
                        // Extract point UUID as flow_id
                        let fid = point.id.as_ref()
                            .and_then(|id| id.point_id_options.as_ref())
                            .and_then(|opts| match opts {
                                qdrant_client::qdrant::point_id::PointIdOptions::Uuid(u) => Some(u.clone()),
                                qdrant_client::qdrant::point_id::PointIdOptions::Num(n) => Some(n.to_string()),
                            })
                            .unwrap_or_default();
                        dict.set_item("flow_id", fid)?;
                        // Extract key payload fields for sync
                        for key in &["flow_name", "flow_type", "checksum"] {
                            let val = point.payload.get(*key)
                                .and_then(|v| {
                                    if let Some(qdrant_client::qdrant::value::Kind::StringValue(s)) = &v.kind {
                                        Some(s.as_str())
                                    } else { None }
                                })
                                .unwrap_or("");
                            dict.set_item(*key, val)?;
                        }
                        Ok(dict.as_ref())
                    })
                    .collect::<PyResult<Vec<_>>>()
                    .map(|v| v.into_py(py))
            })
        })
    }

    // ── delete_flow ───────────────────────────────────────────────────────────

    /// Delete a single flow from the collection by its flow_id (point UUID).
    /// Called by sync_registry() to remove flows that no longer exist in code.
    #[pyo3(signature = (flow_id))]
    pub fn delete_flow<'py>(
        &self,
        py:      Python<'py>,
        flow_id: String,
    ) -> PyResult<&'py PyAny> {
        let client          = Arc::clone(&self.client);
        let collection_name = self.collection_name.clone();

        future_into_py(py, async move {
            let point_id = qdrant_client::qdrant::PointId {
                point_id_options: Some(
                    qdrant_client::qdrant::point_id::PointIdOptions::Uuid(flow_id.clone())
                ),
            };

            client.delete_points(qdrant_client::qdrant::DeletePoints {
                collection_name: collection_name.clone(),
                points: Some(qdrant_client::qdrant::PointsSelector {
                    points_selector_one_of: Some(
                        qdrant_client::qdrant::points_selector::PointsSelectorOneOf::Points(
                            qdrant_client::qdrant::PointsIdsList { ids: vec![point_id] }
                        )
                    ),
                }),
                ..Default::default()
            })
            .await
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                format!("Delete failed for flow_id '{}': {}", flow_id, e)
            ))?;

            Ok(())
        })
    }

    }


// ── helpers ───────────────────────────────────────────────────────────────────

fn extract_point_id(point: &ScoredPoint) -> Option<String> {
    point.id.as_ref().and_then(|id| {
        id.point_id_options.as_ref().and_then(|opts| match opts {
            qdrant_client::qdrant::point_id::PointIdOptions::Uuid(u) => Some(u.clone()),
            qdrant_client::qdrant::point_id::PointIdOptions::Num(n) => Some(n.to_string()),
        })
    })
}

fn flow_to_pydict<'py>(py: Python<'py>, flow: &RankedFlow) -> PyResult<&'py PyDict> {
    let dict = PyDict::new(py);
    dict.set_item("score", flow.score)?;
    for (key, value) in &flow.payload {
        dict.set_item(key.as_str(), qdrant_value_to_py(py, value)?)?;
    }
    Ok(dict)
}

fn qdrant_value_to_py(py: Python, value: &QdrantValue) -> PyResult<PyObject> {
    match &value.kind {
        Some(qdrant_client::qdrant::value::Kind::StringValue(s))  => Ok(s.to_object(py)),
        Some(qdrant_client::qdrant::value::Kind::IntegerValue(i)) => Ok(i.to_object(py)),
        Some(qdrant_client::qdrant::value::Kind::DoubleValue(d))  => Ok(d.to_object(py)),
        Some(qdrant_client::qdrant::value::Kind::BoolValue(b))    => Ok(b.to_object(py)),
        Some(qdrant_client::qdrant::value::Kind::ListValue(l))    => {
            let list: Vec<PyObject> = l.values.iter()
                .map(|v| qdrant_value_to_py(py, v))
                .collect::<PyResult<_>>()?;
            Ok(list.to_object(py))
        }
        _ => Ok(py.None()),
    }
}