use crate::embed::Provider;

pub fn resolve_remote_provider_config(
    provider: Option<String>,
    base_url: Option<String>,
    model_name: Option<String>,
) -> (Provider, String, String) {
    let provider_str = provider.unwrap_or_else(|| "openai".to_string());
    let prov = Provider::from_str(&provider_str);

    let url = base_url.unwrap_or_else(|| default_base_url(&prov));
    let model = model_name.unwrap_or_else(|| default_model_name(&prov));
    (prov, url, model)
}

fn default_base_url(provider: &Provider) -> String {
    match provider {
        Provider::OpenAI => "https://api.openai.com/v1".to_string(),
        Provider::AzureOpenAI => "https://YOUR_RESOURCE_NAME.openai.azure.com/openai/deployments/YOUR_DEPLOYMENT_NAME?api-version=2024-02-15-preview".to_string(),
        Provider::Gemini => "https://generativelanguage.googleapis.com/v1beta".to_string(),
        Provider::Cohere => "https://api.cohere.com/v1".to_string(),
        Provider::HuggingFace => "https://api-inference.huggingface.co".to_string(),
        Provider::Mistral => "https://api.mistral.ai/v1".to_string(),
        Provider::Together => "https://api.together.xyz/v1".to_string(),
        Provider::VoyageAI => "https://api.voyageai.com/v1".to_string(),
        Provider::JinaAI => "https://api.jina.ai/v1".to_string(),
        Provider::Nomic => "https://api-atlas.nomic.ai/v1".to_string(),
        Provider::OpenRouter => "https://openrouter.ai/api/v1".to_string(),
        Provider::DeepInfra => "https://api.deepinfra.com/v1/openai".to_string(),
    }
}

fn default_model_name(provider: &Provider) -> String {
    match provider {
        Provider::OpenAI => "text-embedding-3-small".to_string(),
        Provider::AzureOpenAI => "text-embedding-3-small".to_string(),
        Provider::Gemini => "gemini-embedding-001".to_string(),
        Provider::Cohere => "embed-english-v3.0".to_string(),
        Provider::HuggingFace => "BAAI/bge-m3".to_string(),
        Provider::Mistral => "mistral-embed".to_string(),
        Provider::Together => "togethercomputer/m2-bert-80M-32k-retrieval".to_string(),
        Provider::VoyageAI => "voyage-3-lite".to_string(),
        Provider::JinaAI => "jina-embeddings-v3".to_string(),
        Provider::Nomic => "nomic-embed-text-v1.5".to_string(),
        Provider::OpenRouter => "openai/text-embedding-3-small".to_string(),
        Provider::DeepInfra => "BAAI/bge-large-en-v1.5".to_string(),
    }
}