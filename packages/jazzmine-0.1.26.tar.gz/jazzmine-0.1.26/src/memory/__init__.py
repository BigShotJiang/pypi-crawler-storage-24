"""Python package wrapper for the Rust ``memory`` extension module.

Maturin mixed-layout expects the module path to exist under ``python-source``.
This package keeps ``import memory`` working while shipping ``src/jazzmine`` in
the same wheel.
"""

from importlib import import_module

_ext = import_module("memory.memory")
globals().update({name: getattr(_ext, name) for name in dir(_ext) if not name.startswith("_")})
