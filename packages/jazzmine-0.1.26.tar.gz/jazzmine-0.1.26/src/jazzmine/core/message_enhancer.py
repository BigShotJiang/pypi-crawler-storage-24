import json
import logging
from jazzmine.core.llm import BaseLLM, LLMResponse, MessagePart
from jazzmine.core.message_store import MessageStore, Message, MessageRole
from jazzmine.core.message_store.models import Entity

logger = logging.getLogger(__name__)

ENHANCEMENT_SYSTEM_PROMPT = """You are a message enhancement engine for an AI conversational agent.

Given a raw user message and its conversation context, return a JSON object with these fields:

- enhanced_query   : the message with all pronouns and vague references replaced by their explicit referents from context. If already unambiguous, return it unchanged. Max 3 sentences.
- sentiment_score  : float in [-1.0, 1.0]. Reflects emotional tone only — not topic. Neutral factual questions score 0.0. Only go negative for clear frustration or dissatisfaction.
- intent           : a short free-form label describing what the user wants (e.g. "ask_product_specs", "book_appointment", "request_refund").
- entities         : list of entities mentioned or resolved in the message. Each entry is { "name": "<entity name>", "attributes": ["<attr>", ...] }. Can be anything — people, places, products, documents, dates, concepts. Use an empty list if none.
- is_cancellation  : true if the user is retracting or cancelling a previous request, false otherwise. The enhanced_query must explicitly name what is being cancelled when true.
- is_continuation  : true if this message continues the same topic or task as the recent history. false if the user has moved on to a different subject, intent, or task — even partially. Signals that use the word "actually", redirect with "by the way", or introduce a completely new domain (e.g. switching from product questions to travel booking, from tech support to scheduling) should be false. When there is no prior history, set true.

Respond with ONLY a raw JSON object. No markdown, no explanation."""


class EnhancementError(Exception):
    pass


class MessageEnhancer:

    def __init__(
        self,
        llm:            BaseLLM,
        message_store:  MessageStore,
        history_window: int = 8,
    ):
        self.llm            = llm
        self.message_store  = message_store
        # How many recent messages to fetch before trimming to the current
        # episode boundary. Must cover the realistic worst-case episode length.
        # 8 is the default — enough for the episode-boundary trimmer in all
        # but the most extreme same-topic conversations. Increase if episodes
        # regularly run longer than 4 user+assistant turn pairs.
        self._history_window = history_window

    async def enhance_message(self, message: Message) -> Message:
        # Fetch a moderate window then trim to the current episode boundary.
        # n=8 is enough for the trimmer to find the episode start in all but
        # the most extreme same-topic conversations — and fetching 20 messages
        # only to discard most of them wastes a round-trip to the message store.
        raw_history = await self.message_store.get_immediate_context(
            message.conversation_id, n=self._history_window
        )
        conversation_history = self._trim_to_current_episode(raw_history)

        message_parts = self._build_message_parts(message, conversation_history)

        try:
            llm_response: LLMResponse = await self.llm.agenerate(message_parts)
            parsed = self._parse_llm_response(llm_response.text)
        except EnhancementError:
            logger.warning("Enhancement failed for message %s — using safe defaults.", message.id)
            parsed = _safe_defaults(message.original_content)

        message.enhanced_message = parsed["enhanced_query"]
        message.sentiment_score  = parsed["sentiment_score"]
        message.intent           = parsed["intent"]
        message.entities         = parsed["entities"]
        message.is_cancellation  = parsed["is_cancellation"]
        message.is_continuation  = parsed["is_continuation"]
        await self.message_store.update_message(message)
        return message

    # ------------------------------------------------------------------ private

    @staticmethod
    def _trim_to_current_episode(history: list[Message]) -> list[Message]:
        """
        Return messages from the start of the current episode.
        The current episode begins at the last message where is_continuation=False.
        That message is included (it's the first of its episode).
        """
        boundary = 0
        for i, msg in enumerate(history):
            if not msg.is_continuation:
                boundary = i
        return history[boundary:]

    def _build_message_parts(self, message: Message, conversation_history: list[Message]) -> list[MessagePart]:
        return [
            MessagePart(role="system", content=ENHANCEMENT_SYSTEM_PROMPT),
            MessagePart(role="user",   content=self._build_user_content(message, conversation_history)),
        ]

    def _build_user_content(self, message: Message, conversation_history: list[Message]) -> str:
        parts = ["<enhancement_request>"]
        parts.append(f"  <raw_message>{_escape(message.original_content)}</raw_message>")

        if message.explicit_context:
            parts.append("  <explicit_context>")
            for idx, snippet in enumerate(message.explicit_context, start=1):
                parts.append(f'    <snippet index="{idx}">{_escape(snippet)}</snippet>')
            parts.append("  </explicit_context>")
        else:
            parts.append("  <explicit_context/>")

        if conversation_history:
            parts.append("  <current_episode_history>")
            for msg in conversation_history:
                role = msg.role.value if isinstance(msg.role, MessageRole) else str(msg.role)
                content = msg.enhanced_message or msg.original_content
                parts.append(f'    <turn role="{role}">{_escape(content)}</turn>')
            parts.append("  </current_episode_history>")
        else:
            parts.append("  <current_episode_history/>")

        parts.append("</enhancement_request>")
        return "\n".join(parts)

    @staticmethod
    def _parse_llm_response(raw_text: str) -> dict:
        text = raw_text.strip()
        if text.startswith("```"):
            text = text.split("```")[1]
            if text.lower().startswith("json"):
                text = text[4:]
            text = text.strip()

        try:
            data = json.loads(text)
        except json.JSONDecodeError as exc:
            raise EnhancementError(f"Non-JSON response: {raw_text!r}") from exc

        for key in ("enhanced_query", "sentiment_score", "intent", "entities",
                    "is_cancellation", "is_continuation"):
            if key not in data:
                raise EnhancementError(f"Missing key '{key}': {data}")

        score = float(data["sentiment_score"])
        score = max(-1.0, min(1.0, score))

        raw_entities = data.get("entities", [])
        if not isinstance(raw_entities, list):
            raw_entities = []
        entities = []
        for item in raw_entities:
            if not isinstance(item, dict) or "name" not in item:
                continue
            entities.append(Entity(
                name=str(item["name"]),
                attributes=[str(a) for a in item.get("attributes", []) if a],
            ))

        return {
            "enhanced_query":  str(data["enhanced_query"]).strip(),
            "sentiment_score": score,
            "intent":          str(data["intent"]),
            "entities":        entities,
            "is_cancellation": bool(data["is_cancellation"]),
            "is_continuation": bool(data["is_continuation"]),
        }


def _safe_defaults(original_content: str) -> dict:
    return {
        "enhanced_query":  original_content,
        "sentiment_score": 0.0,
        "intent":          "unknown",
        "entities":        [],
        "is_cancellation": False,
        "is_continuation": True,
    }


def _escape(text: str) -> str:
    return (
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
    )