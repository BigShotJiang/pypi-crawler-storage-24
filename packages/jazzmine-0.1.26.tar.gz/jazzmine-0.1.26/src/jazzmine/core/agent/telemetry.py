from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from jazzmine.core.message_store.models import (
    ConfirmationEvent,
    FlowEvent,
    LLMCallRecord,
    ScriptGenAttempt,
    SlotEvent,
    TaskEmission,
    ToolTrace,
)
from jazzmine.core.tools.orchestrator import RunRecord


@dataclass
class TurnTelemetry:
    started_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))
    llm_calls: list[LLMCallRecord] = field(default_factory=list)
    task_emissions: list[TaskEmission] = field(default_factory=list)
    tool_traces: list[ToolTrace] = field(default_factory=list)
    slot_events: list[SlotEvent] = field(default_factory=list)
    confirmation_events: list[ConfirmationEvent] = field(default_factory=list)
    flow_events: list[FlowEvent] = field(default_factory=list)

    def record_llm_ok(self, purpose: str, response: Any, latency_ms: int) -> None:
        self.llm_calls.append(
            LLMCallRecord(
                purpose=purpose,
                model=getattr(response, "model", ""),
                prompt_tokens=getattr(response.usage, "prompt_tokens", 0),
                completion_tokens=getattr(response.usage, "completion_tokens", 0),
                total_tokens=getattr(response.usage, "total_tokens", 0),
                latency_ms=latency_ms,
                timestamp_ms=int(time.time() * 1000),
                success=True,
            )
        )

    def record_llm_error(self, purpose: str, error: Exception, model: str = "") -> None:
        self.llm_calls.append(
            LLMCallRecord(
                purpose=purpose,
                model=model,
                latency_ms=0,
                timestamp_ms=int(time.time() * 1000),
                success=False,
                error=str(error),
            )
        )

    def add_tool_trace(self, run: RunRecord, task_index: int, description: str) -> None:
        self.tool_traces.append(run_record_to_tool_trace(run, task_index, description))

    def total_prompt_tokens(self) -> int:
        gen = sum(sum(a.prompt_tokens for a in tt.generation_attempts) for tt in self.tool_traces)
        return sum(c.prompt_tokens for c in self.llm_calls) + gen

    def total_completion_tokens(self) -> int:
        gen = sum(sum(a.completion_tokens for a in tt.generation_attempts) for tt in self.tool_traces)
        return sum(c.completion_tokens for c in self.llm_calls) + gen


def run_record_to_tool_trace(run: RunRecord, task_index: int, description: str) -> ToolTrace:
    gen_attempts: list[ScriptGenAttempt] = []

    if run.mode == "plan":
        for a in run.attempts:
            gen_attempts.append(
                ScriptGenAttempt(
                    attempt=a.attempt,
                    prompt_tokens=a.prompt_tokens,
                    completion_tokens=a.completion_tokens,
                    latency_ms=a.generation_latency_ms,
                    success=bool(a.success) and not bool(a.ast_violations),
                    parse_error=("; ".join(a.ast_violations) if a.ast_violations else None),
                )
            )
    else:
        global_attempt = 0
        for step in run.steps:
            for a in step.attempts:
                global_attempt += 1
                gen_attempts.append(
                    ScriptGenAttempt(
                        attempt=global_attempt,
                        prompt_tokens=a.prompt_tokens,
                        completion_tokens=a.completion_tokens,
                        latency_ms=a.generation_latency_ms,
                        success=bool(a.success) and not bool(a.ast_violations),
                        parse_error=("; ".join(a.ast_violations) if a.ast_violations else None),
                    )
                )

    all_scripts = run.all_scripts
    final_script = all_scripts[-1] if all_scripts else None

    gen_total_tokens = run.total_prompt_tokens + run.total_completion_tokens
    gen_latency_ms = sum(a.latency_ms for a in gen_attempts)

    exec_latency_ms = 0
    if run.mode == "plan" and run.attempts:
        exec_latency_ms = run.attempts[-1].duration_ms
    else:
        for step in run.steps:
            if step.final_attempt:
                exec_latency_ms += step.final_attempt.duration_ms

    all_intermediates: list[dict] = []
    if run.mode == "plan":
        for a in run.attempts:
            all_intermediates.extend(a.intermediates)
    else:
        for step in run.steps:
            for a in step.attempts:
                all_intermediates.extend(a.intermediates)

    return ToolTrace(
        task_index=task_index,
        sandbox=run.sandbox_name,
        mode=run.mode,
        description=description,
        generation_attempts=gen_attempts,
        final_script=final_script,
        generation_total_tokens=gen_total_tokens,
        generation_latency_ms=gen_latency_ms,
        execution_id=run.run_id,
        success=run.success,
        final_data=run.final_data,
        intermediates=all_intermediates,
        error=run.error,
        traceback=run.last_traceback(),
        execution_latency_ms=exec_latency_ms,
        total_latency_ms=run.total_ms,
    )
