from __future__ import annotations

import time
from dataclasses import dataclass

from jazzmine.core.tools.sandbox.config import ExecutionMode


@dataclass
class AgentConfig:
    name: str
    personality: str
    agent_id: str
    has_tools: bool = True
    default_sandbox_name: str = "default"
    default_execution_mode: ExecutionMode = ExecutionMode.PLAN
    max_task_calls_per_turn: int = 8
    max_interactive_steps: int = 10
    episodic_same_conv_limit: int = 3
    episodic_prev_conv_limit: int = 2
    semantic_top_k: int = 8


@dataclass
class AgentTurnResult:
    response:      str
    message_id:    str
    trace_id:      str
    invoked_flows: list[str]
    invoked_tools: list[str]
    errors:        list[str]
    turn_number:   int
    is_blocked:    bool = False   # True when input or output was blocked by SecurityGuard


def now_ms() -> int:
    return int(time.time() * 1000)