from __future__ import annotations

import time
from typing import TYPE_CHECKING

from jazzmine.core.conversation_summarizer import ConversationSummarizer
from jazzmine.core.flows import FlowSelector
from jazzmine.core.llm import BaseLLM, MessagePart
from jazzmine.core.message_enhancer import MessageEnhancer
from jazzmine.core.message_store import MessageStore
from jazzmine.core.tools.orchestrator import LLMCallResult, ToolOrchestrator
from jazzmine.core.tools.registry import ToolRegistry
from jazzmine.core.working_memory import WorkingMemoryStore

from jazzmine.core.agent.agent_logger import AgentLogger
from jazzmine.core.agent.core import Agent
from jazzmine.core.security_guard import SecurityGuard, NOOP_GUARD
from jazzmine.core.agent.types import AgentConfig


def build_agent(
    config: AgentConfig,
    llm: BaseLLM,
    message_store: MessageStore,
    wm_store: WorkingMemoryStore,
    enhancer: MessageEnhancer,
    episodic_memory,
    semantic_memory,
    flow_selector: FlowSelector,
    summarizer: ConversationSummarizer,
    tool_registry: ToolRegistry,
    pool,
    max_retries:    int                  = 3,
    on_intermediate                      = None,
    script_gen_llm: BaseLLM | None       = None,
    logger:         AgentLogger | None   = None,
    security_guard: SecurityGuard | None = None,
) -> Agent:
    gen_llm = script_gen_llm or llm

    async def llm_caller(prompt: str) -> LLMCallResult:
        t0 = time.monotonic()
        response = await gen_llm.agenerate([MessagePart(role="user", content=prompt)])
        latency = int((time.monotonic() - t0) * 1000)
        return LLMCallResult(
            text              = response.text,
            prompt_tokens     = response.usage.prompt_tokens,
            completion_tokens = response.usage.completion_tokens,
            total_tokens      = response.usage.total_tokens,
            latency_ms        = latency,
            model             = response.model,
        )

    orchestrator = ToolOrchestrator(
        registry        = tool_registry,
        pool            = pool,
        llm_call        = llm_caller,
        max_retries     = max_retries,
        on_intermediate = on_intermediate,
        logger          = logger,
    )

    return Agent(
        config            = config,
        llm               = llm,
        script_gen_llm    = script_gen_llm,
        message_store     = message_store,
        wm_store          = wm_store,
        enhancer          = enhancer,
        episodic_memory   = episodic_memory,
        semantic_memory   = semantic_memory,
        flow_selector     = flow_selector,
        summarizer        = summarizer,
        tool_orchestrator = orchestrator,
        tool_registry     = tool_registry,
        logger            = logger,
        security_guard    = security_guard or NOOP_GUARD,
    )