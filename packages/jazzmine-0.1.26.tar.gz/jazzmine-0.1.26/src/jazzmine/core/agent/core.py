from __future__ import annotations

import asyncio
import json
import logging
import time
from uuid import uuid4

from jazzmine.core.conversation_summarizer import ConversationSummarizer
from jazzmine.core.flows import FlowSelector
from jazzmine.core.llm import BaseLLM, MessagePart
from jazzmine.core.message_enhancer import MessageEnhancer
from jazzmine.core.message_store import MessageStore
from jazzmine.core.message_store.models import (
    ConfirmationEvent,
    Conversation,
    FlowEvent,
    Message,
    MessageRole,
    SlotEvent,
    TaskEmission,
    ToolTrace,
    TurnTrace,
)
from jazzmine.core.tools.orchestrator import ToolExecutionResult, ToolOrchestrator
from jazzmine.core.tools.registry import ToolRegistry
from jazzmine.core.tools.sandbox.config import ExecutionMode
from jazzmine.core.working_memory import (
    ActiveFlowState,
    ConversationStatus,
    FlowStatus,
    ToolCallRecord,
    WorkingMemory,
    WorkingMemoryStore,
)

from jazzmine.core.agent.agent_logger import AgentLogger                
from jazzmine.core.agent.parsers import (
    _CANCEL_RE,
    _CONFIRM_RE,
    _FLOW_COMPLETE_RE,
    _TASK_RE,
    extract_response,
    parse_task_request,
)
from jazzmine.core.agent.prompts import (
    _CONFIRMATION_INSTRUCTION,
    _SLOT_COLLECTION_INSTRUCTION,
    _SLOT_EXTRACTION_SYSTEM,
    _SYSTEM_PROMPT_NO_TOOLS_TEMPLATE,
    _SYSTEM_PROMPT_TEMPLATE,
)
from jazzmine.core.agent.telemetry import TurnTelemetry
from jazzmine.core.agent.types import AgentConfig, AgentTurnResult, now_ms
from jazzmine.core.security_guard import SecurityGuard, NOOP_GUARD

log = logging.getLogger(__name__)


class Agent:
    def __init__(
        self,
        config: AgentConfig,
        llm: BaseLLM,
        message_store: MessageStore,
        wm_store: WorkingMemoryStore,
        enhancer: MessageEnhancer,
        episodic_memory,
        semantic_memory,
        flow_selector: FlowSelector,
        summarizer: ConversationSummarizer,
        tool_orchestrator: ToolOrchestrator,
        tool_registry: ToolRegistry,
        script_gen_llm: BaseLLM | None = None,
        logger: AgentLogger | None = None,
        security_guard: SecurityGuard | None = None,
    ) -> None:
        self.config = config
        self.llm = llm
        self.script_gen_llm = script_gen_llm or llm
        self.message_store = message_store
        self.wm_store = wm_store
        self.enhancer = enhancer
        self.episodic_memory = episodic_memory
        self.semantic_memory = semantic_memory
        self.flow_selector = flow_selector
        self.summarizer = summarizer
        self.tool_orchestrator = tool_orchestrator
        self.tool_registry = tool_registry
        self._logger = logger or AgentLogger.noop()  # (never None)
        self.security: SecurityGuard = security_guard or NOOP_GUARD

        tmpl = _SYSTEM_PROMPT_TEMPLATE if config.has_tools else _SYSTEM_PROMPT_NO_TOOLS_TEMPLATE
        self._system_prompt: str = tmpl.format(
            name=config.name,
            personality=config.personality.rstrip(".") + ".",
        )
        self._tools_context_block: str = self._build_tools_context_block()
        self._background_tasks: set[asyncio.Task] = set()

    async def drain(self) -> None:
        if not self._background_tasks:
            return
        pending = list(self._background_tasks)
        log.debug("drain(): waiting for %d background task(s)", len(pending))
        await asyncio.gather(*pending, return_exceptions=True)
        self._background_tasks.clear()

    def _build_known_data_section(self, wm: WorkingMemory) -> str:
        lines: list[str] = []

        ct = wm.current_turn
        if ct and ct.tool_calls:
            for rec in ct.tool_calls:
                if rec.success and rec.result_summary:
                    lines.append(f"  <result turn=\"current\" tool=\"{rec.tool_name}\">{rec.result_summary}</r>")

        if wm.active_flow:
            for rec in wm.active_flow.tool_call_history:
                if ct and rec in ct.tool_calls:
                    continue
                if rec.success and rec.result_summary:
                    lines.append(f"  <result turn=\"t{rec.turn_number}\" tool=\"{rec.tool_name}\">{rec.result_summary}</r>")

        for fr in wm.flow_history[-6:]:
            for summary in fr.tool_summaries:
                if summary:
                    lines.append(f"  <result flow=\"{fr.flow_name}\">{summary}</r>")

        if ct and ct.episode_short_summaries:
            for s in ct.episode_short_summaries[:3]:
                lines.append(f"  <episode>{s}</episode>")

        if not lines:
            return ""

        return "<known_data>\n" + "\n".join(lines) + "\n</known_data>"

    def _build_tools_context_block(self) -> str:
        sandbox_names = self.tool_registry.all_sandbox_names()
        if not sandbox_names:
            return ""
        sandbox_blocks: list[str] = []
        for sname in sorted(sandbox_names):
            tools_xml = self.tool_registry.build_tools_prompt(sname)
            if tools_xml:
                sandbox_blocks.append(
                    f'  <sandbox name="{sname}">\n'
                    + "\n".join("    " + ln for ln in tools_xml.splitlines())
                    + "\n  </sandbox>"
                )
        if not sandbox_blocks:
            return ""
        return "<available_sandboxes>\n" + "\n".join(sandbox_blocks) + "\n</available_sandboxes>"

    async def chat(
        self,
        user_id: str,
        conversation_id: str,
        content: str,
        explicit_context: list[str] | None = None,
    ) -> AgentTurnResult:
        telemetry = TurnTelemetry()
        errors: list[str] = []

        await self._ensure_conversation(user_id, conversation_id, content)

        user_message = self._create_user_message(user_id, conversation_id, content, explicit_context)
        await self.message_store.store_message(user_message)

        # ── Input security gate ───────────────────────────────────────────────
        # Runs before any LLM call, memory recall, or enhancement.
        # On block: flags the message in the store, returns early with the
        # configured block message. No LLM call is made.
        if self.security.has_input_gate:
            input_result = await self.security.check_input(content)
            if input_result.is_blocked:
                log.info(
                    "Input blocked by %s for message %s (score=%.4f).",
                    input_result.blocked_by, user_message.id, input_result.score,
                )
                await self.message_store.flag_message(user_message.id)
                self._logger.security_block(
                    direction  = "input",
                    blocked_by = input_result.blocked_by or "unknown",
                    score      = input_result.score,
                    message_id = user_message.id,
                ) if hasattr(self._logger, "security_block") else None
                return AgentTurnResult(
                    response      = input_result.block_message or self.security._input_block_message,
                    message_id    = user_message.id,
                    trace_id      = user_message.id,
                    invoked_flows = [],
                    invoked_tools = [],
                    errors        = [
                        f"input_blocked:{input_result.blocked_by}:score={input_result.score:.4f}"
                    ],
                    turn_number   = 0,
                    is_blocked    = True,
                )

        wm = await self.wm_store.get_or_create(conversation_id, user_id, self.config.agent_id)
        turn_number = wm.turn_number + 1

        # ── Correlation ID ── ─────────────────────────────────────────────────
        # Use the user message ID as the trace_id — it is stored in the DB
        # and links every log event back to the exact message that triggered it.
        trace_id = user_message.id

        with self._logger.turn_context(
            trace_id        = trace_id,
            conversation_id = conversation_id,
            user_id         = user_id,
            agent_id        = self.config.agent_id,
            turn_number     = turn_number,
        ):
            return await self._chat_inner(
                user_message      = user_message,
                wm                = wm,
                turn_number       = turn_number,
                trace_id          = trace_id,
                telemetry         = telemetry,
                errors            = errors,
                explicit_context  = explicit_context,
            )

    async def _chat_inner(
        self,
        user_message,
        wm,
        turn_number:      int,
        trace_id:         str,
        telemetry:        TurnTelemetry,
        errors:           list[str],
        explicit_context: list[str] | None,
    ) -> AgentTurnResult:
        """
        Core turn logic — runs inside the turn_context() block so every
        log call here and in any component it awaits carries the trace_id.
        """
        conversation_id = user_message.conversation_id
        user_id         = user_message.user_id

        # ── Turn start ────────────────────────────────────────────────────────
        self._logger.turn_start(
            content_len = len(user_message.original_content),
            has_tools   = self.config.has_tools,
            has_memory  = not _is_noop_memory(self.episodic_memory),
        )
        log.debug("Stored user message %s.", user_message.id)

        pre_turn_status  = wm.status
        has_confirmation = wm.has_pending_confirmation

        # ── Message enhancement ───────────────────────────────────────────────
        try:
            user_message = await self.enhancer.enhance_message(user_message)
        except Exception as exc:
            log.warning("Enhancement failed for message %s: %s", user_message.id, exc)
            errors.append(f"enhancement_failed: {exc}")
            self._logger.agent_error("enhancement", str(exc))

        # ── Memory recall ─────────────────────────────────────────────────────
        t_mem = time.monotonic()
        try:
            episode_raw, semantic_terms = await asyncio.gather(
                self.episodic_memory.recall(
                    query=(user_message.enhanced_message or user_message.original_content),
                    user_id=user_id,
                    agent_id=self.config.agent_id,
                    conversation_id=conversation_id,
                    same_conversation_limit=self.config.episodic_same_conv_limit,
                    previous_conversation_limit=self.config.episodic_prev_conv_limit,
                ),
                self.semantic_memory.recall(
                    query=(user_message.enhanced_message or user_message.original_content),
                    agent_id=self.config.agent_id,
                    top_k=self.config.semantic_top_k,
                ),
            )
            same_episodes = episode_raw.get("same_conversation", [])
            prev_episodes = episode_raw.get("previous_conversations", [])
        except Exception as exc:
            log.warning("Memory recall failed: %s", exc)
            errors.append(f"memory_recall_failed: {exc}")
            self._logger.agent_error("memory_recall", str(exc))
            same_episodes, prev_episodes, semantic_terms = [], [], []

        self._logger.memory_recall(
            same_conv_episodes = len(same_episodes),
            prev_conv_episodes = len(prev_episodes),
            semantic_terms     = len(semantic_terms) if semantic_terms else 0,
            latency_ms         = int((time.monotonic() - t_mem) * 1000),
        )

        topic_shift_pending = not user_message.is_continuation

        leaf_flow_active = (
            pre_turn_status == ConversationStatus.IN_FLOW
            and wm.active_flow is not None
            and wm.active_flow.flow_type == "flow"
            and wm.active_flow.status == FlowStatus.ACTIVE
            and not wm.active_flow.slots
        )

        should_select = (
            (pre_turn_status == ConversationStatus.IDLE
             or (topic_shift_pending and leaf_flow_active))
            and not has_confirmation
        )

        # ── Flow selection ────────────────────────────────────────────────────
        selection = None
        if should_select:
            episode_summaries = [
                ep["short_summary"]
                for ep in same_episodes + prev_episodes
                if ep.get("short_summary")
            ]
            try:
                selection = await self.flow_selector.select(
                    enhanced_query=(user_message.enhanced_message or user_message.original_content),
                    episode_summaries=episode_summaries,
                )
                if selection.unresolved_ids:
                    log.warning(
                        "FlowSelector: unresolved IDs (stale Qdrant / hallucination): %s",
                        selection.unresolved_ids,
                    )
                # Log the chosen flow (if any)
                if selection.chosen_flows:
                    chosen = selection.chosen_flows[0]
                    self._logger.flow_selected(
                        flow_name = chosen.name,
                        flow_type = getattr(chosen, "flow_type", "flow"),
                        score     = getattr(chosen, "score", 0.0),
                        method    = "selector",
                    )
            except Exception as exc:
                log.warning("FlowSelector failed: %s", exc)
                errors.append(f"flow_selection_failed: {exc}")
                self._logger.agent_error("flow_selection", str(exc))

        from jazzmine.core.working_memory import TurnCache

        cache = TurnCache.from_enhancer_and_selector(
            turn_number    = turn_number,
            enhanced_msg   = user_message,
            same_episodes  = same_episodes,
            prev_episodes  = prev_episodes,
            semantic_terms = semantic_terms,
            selection      = selection,
        )
        wm = await self.wm_store.begin_turn(conversation_id, cache)

        if (
            topic_shift_pending and leaf_flow_active
            and wm.active_flow is not None
            and wm.active_flow.flow_type == "flow"
            and wm.active_flow.status == FlowStatus.ACTIVE
        ):
            old_id, old_name, old_type = (
                wm.active_flow.flow_id, wm.active_flow.flow_name, wm.active_flow.flow_type
            )
            wm = await self.wm_store.complete_flow(conversation_id)
            telemetry.flow_events.append(
                FlowEvent(flow_id=old_id, flow_name=old_name, flow_type=old_type, event="topic_shifted")
            )
            self._logger.flow_event(flow_name=old_name, flow_type=old_type, event_type="topic_shifted")
            log.info("Turn %d: completed leaf flow '%s' on topic shift.", turn_number, old_name)

        if selection and selection.chosen_flows and not wm.is_in_flow:
            chosen_flow = selection.chosen_flows[0]
            flow_state  = ActiveFlowState.from_flow(chosen_flow, turn_number)
            wm          = await self.wm_store.start_flow(conversation_id, flow_state)
            telemetry.flow_events.append(
                FlowEvent(
                    flow_id=flow_state.flow_id, flow_name=flow_state.flow_name,
                    flow_type=flow_state.flow_type, event="started",
                )
            )
            self._logger.flow_event(
                flow_name  = flow_state.flow_name,
                flow_type  = flow_state.flow_type,
                event_type = "started",
            )
            log.info(
                "Started flow '%s' (type=%s) at turn %d.",
                flow_state.flow_name, flow_state.flow_type, turn_number,
            )

        if wm.has_pending_confirmation:
            special_instruction = _CONFIRMATION_INSTRUCTION
        elif wm.status == ConversationStatus.COLLECTING_SLOTS:
            await self._extract_slots(wm, user_message, telemetry)
            wm = await self.wm_store.get(conversation_id)
            special_instruction = (
                _SLOT_COLLECTION_INSTRUCTION
                if wm.status == ConversationStatus.COLLECTING_SLOTS
                else ""
            )
        else:
            special_instruction = ""

        turn_context = self._build_turn_context(wm, special_instruction)
        response_raw, task_records, reasoning_steps = await self._run_agent_loop(
            wm, turn_context, errors, telemetry
        )

        if wm.has_pending_confirmation:
            pc_question = wm.pending_confirmation.action_description
            if _CONFIRM_RE.search(response_raw):
                wm = await self.wm_store.confirm_action(conversation_id)
                telemetry.confirmation_events.append(
                    ConfirmationEvent(
                        question=pc_question, outcome="confirmed",
                        resolved_at_turn=turn_number,
                    )
                )
            elif _CANCEL_RE.search(response_raw):
                wm = await self.wm_store.cancel_flow(conversation_id)
                cancelled_name = wm.flow_history[-1].flow_name if wm.flow_history else "unknown"
                cancelled_id   = wm.flow_history[-1].flow_id   if wm.flow_history else ""
                cancelled_type = wm.flow_history[-1].flow_type if wm.flow_history else ""
                telemetry.confirmation_events.append(
                    ConfirmationEvent(
                        question=pc_question, outcome="cancelled",
                        resolved_at_turn=turn_number,
                    )
                )
                telemetry.flow_events.append(
                    FlowEvent(
                        flow_id=cancelled_id, flow_name=cancelled_name,
                        flow_type=cancelled_type, event="cancelled",
                    )
                )
                self._logger.flow_event(
                    flow_name=cancelled_name, flow_type=cancelled_type, event_type="cancelled"
                )

        if _FLOW_COMPLETE_RE.search(response_raw):
            wm = await self.wm_store.get(conversation_id)
            if wm.active_flow and wm.active_flow.status == FlowStatus.ACTIVE:
                fid, fname, ftype = (
                    wm.active_flow.flow_id, wm.active_flow.flow_name, wm.active_flow.flow_type
                )
                wm = await self.wm_store.complete_flow(conversation_id)
                telemetry.flow_events.append(
                    FlowEvent(flow_id=fid, flow_name=fname, flow_type=ftype, event="completed")
                )
                self._logger.flow_event(flow_name=fname, flow_type=ftype, event_type="completed")

        wm = await self.wm_store.get(conversation_id)

        if wm.active_flow:
            af = wm.active_flow
            _should_complete = (
                af.is_sequential_complete
                or af.all_branches_done
                or (
                    af.flow_type == "flow"
                    and af.status == FlowStatus.ACTIVE
                    and not af.slots
                    and wm.current_turn is not None
                    and wm.current_turn.tool_calls
                    and any(r.success for r in wm.current_turn.tool_calls)
                )
            )
            if _should_complete:
                fid, fname, ftype = af.flow_id, af.flow_name, af.flow_type
                wm = await self.wm_store.complete_flow(conversation_id)
                telemetry.flow_events.append(
                    FlowEvent(flow_id=fid, flow_name=fname, flow_type=ftype, event="completed")
                )
                self._logger.flow_event(flow_name=fname, flow_type=ftype, event_type="completed")

        clean_response = extract_response(response_raw)
        invoked_tools  = [r.tool_name for r in task_records]
        invoked_flows  = self._collect_invoked_flow_names(wm, turn_number)

        # ── Output security gate ──────────────────────────────────────────────
        # Runs on the agent's generated response before it is stored or returned.
        # On block: the real response is discarded. The block message is returned
        # instead and the assistant message is NOT stored (so no hallucinated or
        # unsafe content ever reaches the persistent message store).
        if self.security.has_output_gate:
            output_result = await self.security.check_output(clean_response)
            if output_result.is_blocked:
                log.info(
                    "Output blocked by %s for turn %d (score=%.4f).",
                    output_result.blocked_by, turn_number, output_result.score,
                )
                self._logger.security_block(
                    direction  = "output",
                    blocked_by = output_result.blocked_by or "unknown",
                    score      = output_result.score,
                    message_id = user_message.id,
                ) if hasattr(self._logger, "security_block") else None
                return AgentTurnResult(
                    response      = output_result.block_message or self.security._output_block_message,
                    message_id    = user_message.id,
                    trace_id      = user_message.id,
                    invoked_flows = invoked_flows,
                    invoked_tools = invoked_tools,
                    errors        = errors + [
                        f"output_blocked:{output_result.blocked_by}:score={output_result.score:.4f}"
                    ],
                    turn_number   = turn_number,
                    is_blocked    = True,
                )

        assistant_message = self._create_assistant_message(
            user_id       = user_id,
            conversation_id = conversation_id,
            content       = clean_response,
            invoked_flows = invoked_flows,
            invoked_tools = invoked_tools,
            reasoning_steps = reasoning_steps,
            errors        = errors,
        )
        await self.message_store.store_message(assistant_message)

        ended_at_ms = int(time.time() * 1000)

        if wm.active_flow and wm.active_flow.slots:
            for slot in wm.active_flow.slots.values():
                telemetry.slot_events.append(
                    SlotEvent(
                        flow_name          = wm.active_flow.flow_name,
                        slot_name          = slot.name,
                        slot_type          = slot.type,
                        required           = slot.required,
                        value              = slot.value,
                        collected          = slot.collected,
                        collected_at_turn  = (slot.collected_at_turn if slot.collected else None),
                        validation_error   = (slot.validation_error or None),
                    )
                )
        elif wm.flow_history:
            for fr in reversed(wm.flow_history):
                if fr.ended_at_turn == turn_number and fr.slot_values:
                    for sname, sval in fr.slot_values.items():
                        telemetry.slot_events.append(
                            SlotEvent(
                                flow_name        = fr.flow_name,
                                slot_name        = sname,
                                slot_type        = "unknown",
                                required         = False,
                                value            = sval,
                                collected        = True,
                                collected_at_turn = turn_number,
                            )
                        )
                    break

        ct = wm.current_turn
        trace = TurnTrace(
            message_id               = assistant_message.id,
            conversation_id          = conversation_id,
            user_id                  = user_id,
            agent_id                 = self.config.agent_id,
            turn_number              = turn_number,
            started_at_ms            = telemetry.started_at_ms,
            ended_at_ms              = ended_at_ms,
            total_latency_ms         = ended_at_ms - telemetry.started_at_ms,
            total_prompt_tokens      = telemetry.total_prompt_tokens(),
            total_completion_tokens  = telemetry.total_completion_tokens(),
            total_tokens             = (
                telemetry.total_prompt_tokens() + telemetry.total_completion_tokens()
            ),
            llm_calls                = telemetry.llm_calls,
            task_emissions           = telemetry.task_emissions,
            tool_traces              = telemetry.tool_traces,
            slot_events              = telemetry.slot_events,
            confirmation_events      = telemetry.confirmation_events,
            flow_events              = telemetry.flow_events,
            reasoning_steps          = reasoning_steps,
            errors                   = errors,
            detected_intent          = (ct.intent if ct else "unknown"),
            detected_entities        = (
                [e["name"] for e in (ct.raw_entities or [])] if ct else []
            ),
            sentiment_score          = (ct.sentiment_score if ct else 0.0),
            is_continuation          = (ct.is_continuation if ct else True),
            is_cancellation          = (ct.is_cancellation if ct else False),
        )

        try:
            await self.message_store.store_turn_trace(trace)
        except Exception as exc:
            log.warning(
                "Failed to persist TurnTrace for message %s: %s — continuing.",
                assistant_message.id, exc,
            )
            self._logger.agent_error("turn_trace", str(exc))

        await self.wm_store.end_turn(
            conversation_id = conversation_id,
            agent_response  = clean_response,
            agent_intent    = (ct.intent if ct else "respond"),
            topic_summary   = (ct.enhanced_query[:80] if ct else ""),
        )

        # ── Turn end — full telemetry summary ─────────────────────────────────
        self._logger.turn_end(
            total_latency_ms        = ended_at_ms - telemetry.started_at_ms,
            total_prompt_tokens     = telemetry.total_prompt_tokens(),
            total_completion_tokens = telemetry.total_completion_tokens(),
            invoked_flows           = invoked_flows,
            invoked_tools           = invoked_tools,
            errors                  = errors,
            response_len            = len(clean_response),
        )

        task = asyncio.create_task(self._safe_summarize(conversation_id, user_id))
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)

        return AgentTurnResult(
            response       = clean_response,
            message_id     = assistant_message.id,
            trace_id       = trace.id,
            invoked_flows  = invoked_flows,
            invoked_tools  = invoked_tools,
            errors         = errors,
            turn_number    = turn_number,
        )

    async def _run_agent_loop(
        self,
        wm:           WorkingMemory,
        turn_context: str,
        errors:       list[str],
        telemetry:    TurnTelemetry,
    ) -> tuple[str, list[ToolCallRecord], list[str]]:
        messages: list[MessagePart] = [
            MessagePart(role="system", content=self._system_prompt),
            MessagePart(role="user",   content=turn_context),
        ]
        task_records:    list[ToolCallRecord] = []
        reasoning_steps: list[str]           = []
        parsed = None

        for call_index in range(self.config.max_task_calls_per_turn):
            t_llm = time.monotonic()
            try:
                llm_response = await self.llm.agenerate(messages)
            except Exception as exc:
                telemetry.record_llm_error("agent_loop", exc)
                errors.append(f"agent_llm_failed: {exc}")
                self._logger.agent_error("agent_llm", str(exc))
                return (
                    "<response>I encountered an error and cannot respond right now.</response>",
                    task_records, reasoning_steps,
                )
            llm_latency = int((time.monotonic() - t_llm) * 1000)
            telemetry.record_llm_ok("agent_loop", llm_response, llm_latency)

            # Emit structured LLM call event
            self._logger.llm_call(
                purpose           = "agent_loop",
                model             = getattr(llm_response, "model", ""),
                prompt_tokens     = getattr(llm_response.usage, "prompt_tokens", 0),
                completion_tokens = getattr(llm_response.usage, "completion_tokens", 0),
                latency_ms        = llm_latency,
                success           = True,
            )

            text = llm_response.text
            reasoning_fragment = _TASK_RE.split(text)[0].strip()
            if reasoning_fragment and parsed is not None:
                reasoning_steps.append(reasoning_fragment)

            parsed = parse_task_request(text)
            if parsed is None:
                return text, task_records, reasoning_steps

            sandbox_raw, mode_raw, task_description = parsed
            sandbox_name = sandbox_raw or self.config.default_sandbox_name
            mode = (
                ExecutionMode(mode_raw)
                if mode_raw in (ExecutionMode.PLAN.value, ExecutionMode.INTERACTIVE.value)
                else self.config.default_execution_mode
            )

            task_index = call_index + 1
            telemetry.task_emissions.append(
                TaskEmission(
                    task_index   = task_index,
                    sandbox      = sandbox_name,
                    mode         = mode.value,
                    description  = task_description,
                    timestamp_ms = int(time.time() * 1000),
                )
            )

            # Emit task dispatched event BEFORE execution (useful for latency attribution)
            self._logger.task_dispatched(
                task_index   = task_index,
                sandbox      = sandbox_name,
                mode         = mode.value,
                task_preview = task_description,
            )

            tool_result = await self._execute_sandbox_task(
                task_description, sandbox_name, mode, errors
            )

            if tool_result.run_record is not None:
                telemetry.add_tool_trace(
                    run=tool_result.run_record,
                    task_index=task_index,
                    description=task_description,
                )

            # Emit tool result summary
            self._logger.tool_result(
                sandbox        = sandbox_name,
                success        = tool_result.success,
                total_attempts = tool_result.attempts,
                total_ms       = tool_result.total_ms,
                mode           = mode.value,
                error          = tool_result.error,
            )

            record = ToolCallRecord(
                tool_name      = sandbox_name,
                arguments      = {"task": task_description, "mode": mode.value},
                result         = tool_result.final_data,
                result_summary = (
                    f"Sandbox '{sandbox_name}' {'succeeded' if tool_result.success else 'failed'}: "
                    + (
                        json.dumps(tool_result.final_data, default=str)
                        if tool_result.success
                        else (tool_result.error or "unknown error")
                    )
                ),
                success        = tool_result.success,
                error          = tool_result.error or "",
                turn_number    = wm.turn_number,
                call_index     = call_index,
                step           = (wm.active_flow.current_step if wm.active_flow else None),
            )
            wm = await self.wm_store.record_tool_call(wm.conversation_id, record)
            task_records.append(record)

            if (
                tool_result.success
                and wm.active_flow
                and wm.active_flow.flow_type == "sequentialflow"
            ):
                await self.wm_store.advance_sequential_step(
                    conversation_id = wm.conversation_id,
                    step_result     = {
                        "step":       wm.active_flow.current_step,
                        "flow_id":    wm.active_flow.flow_id,
                        "flow_name":  wm.active_flow.flow_name,
                        "success":    True,
                        "summary":    record.result_summary,
                    },
                )
                wm = await self.wm_store.get(wm.conversation_id)

            if not tool_result.success:
                errors.append(f"sandbox_task_failed:{sandbox_name}: {tool_result.error}")

            messages.append(MessagePart(role="assistant", content=text))
            messages.append(MessagePart(role="user",      content=tool_result.to_agent_context()))

        messages.append(
            MessagePart(
                role    = "user",
                content = (
                    "You have used the maximum number of task delegations for this turn. "
                    "Respond to the user with what you have gathered so far. "
                    "Do not request any more task executions."
                ),
            )
        )

        t_llm = time.monotonic()
        try:
            final = await self.llm.agenerate(messages)
        except Exception as exc:
            telemetry.record_llm_error("agent_loop", exc)
            errors.append(f"agent_final_llm_failed: {exc}")
            self._logger.agent_error("agent_llm", str(exc))
            return (
                "<response>I encountered an error generating a response.</response>",
                task_records, reasoning_steps,
            )
        llm_latency = int((time.monotonic() - t_llm) * 1000)
        telemetry.record_llm_ok("agent_loop", final, llm_latency)
        self._logger.llm_call(
            purpose           = "agent_loop",
            model             = getattr(final, "model", ""),
            prompt_tokens     = getattr(final.usage, "prompt_tokens", 0),
            completion_tokens = getattr(final.usage, "completion_tokens", 0),
            latency_ms        = llm_latency,
            success           = True,
        )
        return final.text, task_records, reasoning_steps

    async def _execute_sandbox_task(
        self,
        task_description: str,
        sandbox_name:     str,
        mode:             ExecutionMode,
        errors:           list[str],
    ) -> ToolExecutionResult:
        if self.tool_registry.get_sandbox(sandbox_name) is None:
            available = self.tool_registry.all_sandbox_names()
            msg = (
                f"Sandbox '{sandbox_name}' is not registered. "
                f"Available sandboxes: {available}"
            )
            log.warning(msg)
            errors.append(f"unknown_sandbox:{sandbox_name}")
            return ToolExecutionResult(success=False, error=msg, sandbox_name=sandbox_name)

        try:
            if mode == ExecutionMode.INTERACTIVE:
                return await self.tool_orchestrator.execute_interactive(
                    task         = task_description,
                    sandbox_name = sandbox_name,
                    max_steps    = self.config.max_interactive_steps,
                )
            return await self.tool_orchestrator.execute(
                task=task_description, sandbox_name=sandbox_name
            )
        except Exception as exc:
            msg = f"ToolOrchestrator raised an exception: {exc}"
            log.exception(msg)
            errors.append(f"orchestrator_exception:{sandbox_name}")
            self._logger.agent_error("orchestrator", str(exc))
            return ToolExecutionResult(success=False, error=msg, sandbox_name=sandbox_name)

    def _build_turn_context(self, wm: WorkingMemory, special_instruction: str) -> str:
        ct = wm.current_turn
        sections: list[str] = []

        flow_attr = ""
        if wm.active_flow:
            flow_attr = (
                f' flow="{wm.active_flow.flow_name}" step="{wm.active_flow.current_step}"'
            )
        sections.append(
            f'<state status="{wm.status.value}" turn="{wm.turn_number}"{flow_attr}/>'
        )

        if ct and ct.retrieved_semantic_terms:
            term_lines = "\n".join(
                f"  {t['key']}: {t['value']}"
                for t in ct.retrieved_semantic_terms[: self.config.semantic_top_k]
            )
            sections.append(f"<domain_terms>\n{term_lines}\n</domain_terms>")

        entities = wm.salient_entities[:6]
        if entities:
            ent_lines = "\n".join(
                "  " + e.name
                + (f" [{', '.join(e.attributes[:3])}]" if e.attributes else "")
                for e in entities
            )
            sections.append(f"<entities_in_context>\n{ent_lines}\n</entities_in_context>")

        if (
            self._tools_context_block
            and wm.status not in (
                ConversationStatus.COLLECTING_SLOTS,
                ConversationStatus.AWAITING_CONFIRMATION,
            )
            and not wm.has_pending_confirmation
        ):
            sections.append(self._tools_context_block)

        if wm.active_flow and ct and ct.combined_flow_prompt:
            sections.append(ct.combined_flow_prompt)

        pending = wm.pending_slots
        if pending:
            slot_lines: list[str] = []
            for s in pending:
                line = (
                    f'  <slot name="{s.name}" type="{s.type}" required="{s.required}">'
                    f"{s.description}"
                )
                if s.validation_error:
                    line += f" [previous value invalid: {s.validation_error}]"
                line += "</slot>"
                slot_lines.append(line)
            sections.append(
                "<pending_slots>\n" + "\n".join(slot_lines) + "\n</pending_slots>"
            )

        if wm.pending_confirmation:
            pc = wm.pending_confirmation
            sections.append(
                f'<pending_confirmation action="{pc.action_description}">\n'
                "  Output <confirm/> if the user agrees, <cancel/> if not.\n"
                "</pending_confirmation>"
            )

        tool_sections = wm.build_prompt_tool_sections()
        if tool_sections:
            sections.append(tool_sections)

        known_data = self._build_known_data_section(wm)
        if known_data:
            sections.append(known_data)

        query = (ct.enhanced_query if ct else "") or ""
        sections.append(f"<user_message>{query}</user_message>")

        if special_instruction:
            sections.append(f"<instruction>{special_instruction}</instruction>")

        return "\n\n".join(s for s in sections if s)

    async def _extract_slots(
        self,
        wm:        WorkingMemory,
        message:   Message,
        telemetry: TurnTelemetry,
    ) -> None:
        pending = wm.pending_slots
        if not pending:
            return

        slot_descriptions = "\n".join(
            f"- {s.name} ({s.type}, {'required' if s.required else 'optional'}): {s.description}"
            for s in pending
        )
        content = (
            f"Pending parameters:\n{slot_descriptions}\n\n"
            f"User message: {message.enhanced_message or message.original_content}"
        )

        t_llm = time.monotonic()
        try:
            extraction_response = await self.llm.agenerate(
                [
                    MessagePart(role="system", content=_SLOT_EXTRACTION_SYSTEM),
                    MessagePart(role="user",   content=content),
                ]
            )
        except Exception as exc:
            telemetry.record_llm_error("slot_extraction", exc)
            self._logger.llm_call(
                purpose="slot_extraction", model="", prompt_tokens=0,
                completion_tokens=0, latency_ms=0, success=False, error=str(exc),
            )
            log.warning("Slot extraction LLM call failed: %s", exc)
            return
        llm_latency = int((time.monotonic() - t_llm) * 1000)
        telemetry.record_llm_ok("slot_extraction", extraction_response, llm_latency)
        self._logger.llm_call(
            purpose           = "slot_extraction",
            model             = getattr(extraction_response, "model", ""),
            prompt_tokens     = getattr(extraction_response.usage, "prompt_tokens", 0),
            completion_tokens = getattr(extraction_response.usage, "completion_tokens", 0),
            latency_ms        = llm_latency,
            success           = True,
        )

        raw = extraction_response.text.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.lower().startswith("json"):
                raw = raw[4:]
            raw = raw.strip()

        try:
            extracted: dict = json.loads(raw)
        except Exception as exc:
            log.warning("Slot extraction JSON parse failed: %s", exc)
            return

        for slot_name, value in extracted.items():
            if not isinstance(slot_name, str) or value is None:
                continue
            await self.wm_store.collect_slot(
                conversation_id=wm.conversation_id,
                slot_name=slot_name,
                value=value,
            )
            log.debug("Collected slot '%s' = %r", slot_name, value)

    async def _ensure_conversation(
        self, user_id: str, conversation_id: str, first_message: str
    ) -> Conversation:
        existing = await self.message_store.get_conversation_by_id(conversation_id)
        if existing is not None:
            existing.last_updated_at = now_ms()
            await self.message_store.update_conversation(existing)
            return existing

        title = (first_message[:57] + "…") if len(first_message) > 60 else first_message
        conversation = Conversation(
            id              = conversation_id,
            user_id         = user_id,
            agent_id        = self.config.agent_id,
            title           = title,
            created_at      = now_ms(),
            last_updated_at = now_ms(),
        )
        await self.message_store.store_conversation(conversation)
        log.info("Created conversation %s.", conversation_id)
        return conversation

    def _create_user_message(
        self,
        user_id:          str,
        conversation_id:  str,
        content:          str,
        explicit_context: list[str] | None,
    ) -> Message:
        return Message(
            id               = str(uuid4()),
            conversation_id  = conversation_id,
            user_id          = user_id,
            role             = MessageRole.USER,
            original_content = content,
            explicit_context = explicit_context,
            timestamp        = now_ms(),
        )

    def _create_assistant_message(
        self,
        user_id:         str,
        conversation_id: str,
        content:         str,
        invoked_flows:   list[str],
        invoked_tools:   list[str],
        reasoning_steps: list[str],
        errors:          list[str],
    ) -> Message:
        return Message(
            id               = str(uuid4()),
            conversation_id  = conversation_id,
            user_id          = user_id,
            role             = MessageRole.ASSISTANT,
            original_content = content,
            invoked_flows    = invoked_flows or None,
            invoked_tools    = invoked_tools or None,
            reasoning_steps  = reasoning_steps or None,
            errors           = errors or None,
            timestamp        = now_ms(),
        )

    def _collect_invoked_flow_names(
        self, wm: WorkingMemory, turn_number: int
    ) -> list[str]:
        names: list[str] = []
        if wm.active_flow:
            names.append(wm.active_flow.flow_name)
        elif wm.flow_history:
            last = wm.flow_history[-1]
            if last.ended_at_turn == turn_number:
                names.append(last.flow_name)
        return names

    async def _safe_summarize(self, conversation_id: str, user_id: str) -> None:
        try:
            await self.summarizer.maybe_summarize(
                conversation_id = conversation_id,
                user_id         = user_id,
                agent_id        = self.config.agent_id,
            )
        except Exception as exc:
            log.warning(
                "Background summarisation failed for conversation %s: %s",
                conversation_id, exc,
            )


# ── Helpers ────────────────────────────────────────────────────────────────────

def _is_noop_memory(episodic_memory: object) -> bool:
    """True when the memory object is a no-op stub (no real Qdrant backend)."""
    return type(episodic_memory).__name__ in ("_NoopEpisodicMemory", "NoopEpisodicMemory")