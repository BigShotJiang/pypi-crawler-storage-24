from abc import ABC, abstractmethod

from jazzmine.core.message_store.models import Message, Conversation, TurnTrace


class MessageStore(ABC):

    @classmethod
    async def initialize(cls, config: dict) -> "MessageStore":
        from jazzmine.core.message_store.stores.json_store     import JSONMessageStore
        from jazzmine.core.message_store.stores.postgres_store import PostgresMessageStore
        from jazzmine.core.message_store.stores.mongodb_store  import MongoDBMessageStore
        """
        Factory.  config keys:
          - storage  : "json" | "postgres" | "mongodb"  (default: "json")
          - json     → path: str  (default: "messages.json")
          - postgres → dsn: str   e.g. "postgresql://user:pass@host/db"
                         pool_min: int (default 2), pool_max: int (default 10)
          - mongodb  → uri: str, db: str (default "chatbot")
        """
        storage = config.get("storage", "json").lower()
        store_map = {
            "json":     JSONMessageStore,
            "postgres": PostgresMessageStore,
            "mongodb":  MongoDBMessageStore,
        }
        if storage not in store_map:
            raise ValueError(
                f"Unsupported storage: {storage!r}. Choose from {list(store_map)}"
            )
        store = store_map[storage](config)
        await store._init()
        return store

    @abstractmethod
    async def _init(self) -> None:
        """Set up connections, tables/collections, indexes."""

    @abstractmethod
    async def close(self) -> None:
        """Release all connections/resources."""

    # ── conversations ─────────────────────────────────────────────────────────

    @abstractmethod
    async def store_conversation(self, conversation: Conversation) -> None:
        """Persist a conversation. Idempotent on id."""

    @abstractmethod
    async def get_conversation_by_id(self, conversation_id: str) -> Conversation | None:
        pass

    @abstractmethod
    async def get_conversations_by_user_id(self, user_id: str) -> list[Conversation]:
        """Returns all conversations for a user ordered by last_updated_at DESC."""

    @abstractmethod
    async def get_conversations_by_agent_id(self, agent_id: str) -> list[Conversation]:
        pass

    @abstractmethod
    async def update_conversation(self, conversation: Conversation) -> None:
        """Full replace by id."""

    @abstractmethod
    async def delete_conversation(self, conversation_id: str) -> None:
        """Delete conversation record AND all its messages AND all its turn traces."""

    # ── messages ──────────────────────────────────────────────────────────────

    @abstractmethod
    async def store_message(self, message: Message) -> None:
        """Persist a single message. Idempotent on id."""

    @abstractmethod
    async def store_messages(self, messages: list[Message]) -> None:
        """Bulk persist. More efficient than repeated store_message calls."""

    @abstractmethod
    async def get_message_by_id(self, message_id: str) -> Message | None:
        pass

    @abstractmethod
    async def get_messages_by_ids(self, message_ids: list[str]) -> list[Message]:
        pass

    @abstractmethod
    async def get_messages_by_conversation_id(self, conversation_id: str) -> list[Message]:
        """Returns messages ordered by timestamp ASC."""

    @abstractmethod
    async def get_messages_by_user_id(self, user_id: str) -> list[Message]:
        """Returns all messages for a user ordered by timestamp ASC."""

    @abstractmethod
    async def get_immediate_context(self, conversation_id: str, n: int) -> list[Message]:
        """Returns the n most recent messages for a conversation, ordered timestamp ASC."""

    @abstractmethod
    async def update_message(self, message: Message) -> None:
        """Full replace by id."""

    @abstractmethod
    async def delete_message(self, message_id: str) -> None:
        pass

    @abstractmethod
    async def flag_message(self, message_id: str) -> None:
        pass

    # ── turn traces ───────────────────────────────────────────────────────────
    #
    # TurnTrace records are the primary audit surface.  Every assistant Message
    # has exactly one TurnTrace linked to it via message_id.  The trace contains
    # the full execution record: LLM calls with token counts and latencies, tool
    # traces with generated scripts and execution results, slot collection
    # events, confirmation gate resolutions, flow lifecycle transitions, and
    # every reasoning step the agent emitted.
    #
    # Storage architecture by backend:
    #   Postgres  — dedicated `turn_traces` table; nested arrays in JSONB columns
    #               with GIN indexes for script/error search; scalar columns for
    #               all queryable aggregates (tokens, latency, intent, etc.)
    #   MongoDB   — dedicated `turn_traces` collection; document per trace;
    #               compound indexes on conversation_id+turn_number and
    #               agent_id+started_at_ms for audit range queries
    #   JSON      — `turn_traces` dict in the same file, keyed by trace id;
    #               indexed by message_id for O(1) lookup

    @abstractmethod
    async def store_turn_trace(self, trace: TurnTrace) -> None:
        """
        Persist a TurnTrace.  Idempotent on id (upsert semantics).
        Call this after the assistant Message has been stored so the FK
        constraint (Postgres) or the linked message_id is valid.
        """

    @abstractmethod
    async def get_turn_trace_by_id(self, trace_id: str) -> TurnTrace | None:
        """Return a single trace by its own id."""

    @abstractmethod
    async def get_turn_trace_by_message_id(self, message_id: str) -> TurnTrace | None:
        """
        Return the trace linked to an assistant Message.
        Returns None if the message has no trace (e.g. it is a user message).
        """

    @abstractmethod
    async def get_turn_traces_by_conversation_id(
        self, conversation_id: str
    ) -> list[TurnTrace]:
        """
        Return all traces for a conversation ordered by turn_number ASC.
        Provides the full turn-by-turn audit trail for a conversation thread.
        """

    @abstractmethod
    async def get_turn_traces_by_agent_id(
        self,
        agent_id: str,
        limit:    int = 100,
        offset:   int = 0,
    ) -> list[TurnTrace]:
        """
        Return the most recent traces for an agent, ordered started_at_ms DESC.
        Supports paginated audit dashboards and cost-monitoring queries.
        """