import asyncio
import json
import os

from jazzmine.core.message_store.base import MessageStore
from jazzmine.core.message_store.models import Conversation, Message, TurnTrace


class JSONMessageStore(MessageStore):
    """
    In-memory dicts backed by a single JSON file.
    Reads are served from memory. Writes flush atomically under a lock.
    Suitable for development / low-volume use.

    File layout:
        {
          "conversations": [...],
          "messages":      [...],
          "turn_traces":   [...]   ← one entry per assistant turn
        }

    In-memory indexes:
        _messages       : message_id → raw dict    (primary)
        _conversations  : conversation_id → raw dict
        _traces         : trace_id → raw dict      (primary)
        _trace_by_msg   : message_id → trace_id    (secondary — O(1) lookup by message)

    All four indexes are rebuilt from the JSON file at startup so they are
    always consistent.  Any write flushes all four sections atomically.
    """

    def __init__(self, config: dict):
        self._path           = config.get("path", "messages.json")
        self._messages:      dict[str, dict] = {}   # message_id → raw dict
        self._conversations: dict[str, dict] = {}   # conversation_id → raw dict
        self._traces:        dict[str, dict] = {}   # trace_id → raw dict
        self._trace_by_msg:  dict[str, str]  = {}   # message_id → trace_id
        self._lock = asyncio.Lock()

    async def _init(self) -> None:
        if os.path.exists(self._path):
            data = await asyncio.to_thread(self._read_file)
            self._messages      = {r["id"]: r for r in data.get("messages", [])}
            self._conversations = {r["id"]: r for r in data.get("conversations", [])}
            raw_traces          = data.get("turn_traces", [])
            self._traces        = {r["id"]: r for r in raw_traces}
            self._trace_by_msg  = {r["message_id"]: r["id"] for r in raw_traces}

    def _read_file(self) -> dict:
        with open(self._path) as f:
            return json.load(f)

    def _write_file(self) -> None:
        tmp = self._path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(
                {
                    "conversations": list(self._conversations.values()),
                    "messages":      list(self._messages.values()),
                    "turn_traces":   list(self._traces.values()),
                },
                f,
            )
        os.replace(tmp, self._path)   # atomic rename

    async def _flush(self) -> None:
        await asyncio.to_thread(self._write_file)

    async def close(self) -> None:
        async with self._lock:
            await self._flush()

    # ── conversations ─────────────────────────────────────────────────────────

    async def store_conversation(self, conversation: Conversation) -> None:
        async with self._lock:
            self._conversations[conversation.id] = conversation.model_dump(mode="json")
            await self._flush()

    async def get_conversation_by_id(self, conversation_id: str) -> Conversation | None:
        d = self._conversations.get(conversation_id)
        return Conversation.model_validate(d) if d else None

    async def get_conversations_by_user_id(self, user_id: str) -> list[Conversation]:
        rows = [v for v in self._conversations.values() if v["user_id"] == user_id]
        rows.sort(key=lambda x: x["last_updated_at"], reverse=True)
        return [Conversation.model_validate(r) for r in rows]

    async def get_conversations_by_agent_id(self, agent_id: str) -> list[Conversation]:
        rows = [v for v in self._conversations.values() if v["agent_id"] == agent_id]
        rows.sort(key=lambda x: x["last_updated_at"], reverse=True)
        return [Conversation.model_validate(r) for r in rows]

    async def update_conversation(self, conversation: Conversation) -> None:
        await self.store_conversation(conversation)

    async def delete_conversation(self, conversation_id: str) -> None:
        async with self._lock:
            self._conversations.pop(conversation_id, None)
            # Cascade: collect message ids that belong to this conversation
            msg_ids = {
                k for k, v in self._messages.items()
                if v["conversation_id"] == conversation_id
            }
            for mid in msg_ids:
                self._messages.pop(mid, None)
                # Cascade: remove the trace linked to each message
                trace_id = self._trace_by_msg.pop(mid, None)
                if trace_id:
                    self._traces.pop(trace_id, None)
            await self._flush()

    # ── messages ──────────────────────────────────────────────────────────────

    async def store_message(self, message: Message) -> None:
        async with self._lock:
            self._messages[message.id] = message.model_dump(mode="json")
            await self._flush()

    async def store_messages(self, messages: list[Message]) -> None:
        async with self._lock:
            for m in messages:
                self._messages[m.id] = m.model_dump(mode="json")
            await self._flush()

    async def update_message(self, message: Message) -> None:
        await self.store_message(message)

    async def delete_message(self, message_id: str) -> None:
        async with self._lock:
            self._messages.pop(message_id, None)
            trace_id = self._trace_by_msg.pop(message_id, None)
            if trace_id:
                self._traces.pop(trace_id, None)
            await self._flush()

    async def flag_message(self, message_id: str) -> None:
        async with self._lock:
            if message_id in self._messages:
                self._messages[message_id]["is_flagged"] = True
                await self._flush()

    async def get_message_by_id(self, message_id: str) -> Message | None:
        d = self._messages.get(message_id)
        return Message.model_validate(d) if d else None

    async def get_messages_by_ids(self, message_ids: list[str]) -> list[Message]:
        return [
            Message.model_validate(self._messages[mid])
            for mid in message_ids
            if mid in self._messages
        ]

    async def get_messages_by_conversation_id(self, conversation_id: str) -> list[Message]:
        rows = [v for v in self._messages.values() if v["conversation_id"] == conversation_id]
        return [Message.model_validate(r) for r in sorted(rows, key=lambda x: x["timestamp"])]

    async def get_messages_by_user_id(self, user_id: str) -> list[Message]:
        rows = [v for v in self._messages.values() if v["user_id"] == user_id]
        return [Message.model_validate(r) for r in sorted(rows, key=lambda x: x["timestamp"])]

    async def get_immediate_context(self, conversation_id: str, n: int) -> list[Message]:
        rows = [
            v for v in self._messages.values()
            if v["conversation_id"] == conversation_id and not v.get("is_flagged", False)
        ]
        rows.sort(key=lambda x: x["timestamp"])
        return [Message.model_validate(r) for r in rows[-n:]]

    # ── turn traces ───────────────────────────────────────────────────────────

    async def store_turn_trace(self, trace: TurnTrace) -> None:
        async with self._lock:
            doc = trace.model_dump(mode="json")
            # If this trace_id already exists with a different message_id
            # (shouldn't happen, but defensive), clean up the old secondary index.
            old = self._traces.get(trace.id)
            if old and old.get("message_id") != trace.message_id:
                self._trace_by_msg.pop(old["message_id"], None)
            # If another trace already owns this message_id, replace it.
            old_trace_id = self._trace_by_msg.get(trace.message_id)
            if old_trace_id and old_trace_id != trace.id:
                self._traces.pop(old_trace_id, None)
            self._traces[trace.id]              = doc
            self._trace_by_msg[trace.message_id] = trace.id
            await self._flush()

    async def get_turn_trace_by_id(self, trace_id: str) -> TurnTrace | None:
        d = self._traces.get(trace_id)
        return TurnTrace.model_validate(d) if d else None

    async def get_turn_trace_by_message_id(self, message_id: str) -> TurnTrace | None:
        trace_id = self._trace_by_msg.get(message_id)
        if trace_id is None:
            return None
        d = self._traces.get(trace_id)
        return TurnTrace.model_validate(d) if d else None

    async def get_turn_traces_by_conversation_id(
        self, conversation_id: str
    ) -> list[TurnTrace]:
        rows = [
            v for v in self._traces.values()
            if v["conversation_id"] == conversation_id
        ]
        rows.sort(key=lambda x: x["turn_number"])
        return [TurnTrace.model_validate(r) for r in rows]

    async def get_turn_traces_by_agent_id(
        self,
        agent_id: str,
        limit:    int = 100,
        offset:   int = 0,
    ) -> list[TurnTrace]:
        rows = [v for v in self._traces.values() if v["agent_id"] == agent_id]
        rows.sort(key=lambda x: x["started_at_ms"], reverse=True)
        return [TurnTrace.model_validate(r) for r in rows[offset : offset + limit]]