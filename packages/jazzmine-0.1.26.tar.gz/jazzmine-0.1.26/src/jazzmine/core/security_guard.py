"""
security_guard.py
─────────────────
Runtime security orchestrator for a Jazzmine Agent.

Holds zero-or-one input gate (input_moderator XOR toxicity_detector),
zero-or-one output gate (output_moderator), and zero-or-one file
sanitizer. All instances are injected at build time — the guard itself
is stateless between calls.

Design constraints
──────────────────
• input_moderator and toxicity_detector are MUTUALLY EXCLUSIVE.
  One classifies via a fine-tuned transformer; the other uses an XGBoost
  feature-based model. Both cannot run on the same input simultaneously
  because they are redundant and would require reconciling two independent
  label spaces.

• All moderator calls run off the event loop via asyncio.to_thread() so
  that PyTorch / ONNX inference never blocks the agent's async main loop.

• BaseModerator.classify_async() passes the ModerationRequest TypedDict
  as the first positional arg to classify(), but every concrete moderator
  (JazzmineInputModerator, JazzmineOutputModerator) defines classify(text: str).
  The guard calls asyncio.to_thread(moderator.classify, text_str) directly,
  bypassing the mismatched classify_async wrapper without touching the
  existing codebase.

• The file sanitizer is NOT invoked in the chat() flow — it is a utility
  the caller uses explicitly on uploaded files before passing content to
  the agent.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Optional

log = logging.getLogger(__name__)

# ── Labels emitted by the HuggingFace-based moderators ──────────────────────
_UNSAFE_LABEL = "LABEL_1"


# ── Result type returned from every security check ───────────────────────────

@dataclass
class SecurityResult:
    """
    Outcome of one security check (input or output).

    is_blocked      True when the content was classified as unsafe and
                    should not be processed further.
    blocked_by      Which component triggered the block. One of:
                      "input_moderator"    — HF transformer on user input
                      "toxicity_detector"  — XGBoost detector on user input
                      "output_moderator"   — HF transformer on agent output
                    None when is_blocked is False.
    score           Raw confidence score (0.0–1.0) from the classifier.
                    For toxicity_detector this is the toxicity probability.
                    For moderators this is the confidence of the top label.
    block_message   The human-readable message to return to the user.
                    None when is_blocked is False.
    latency_ms      Wall-clock time spent in the security check.
    error           Non-fatal error message when a check failed gracefully.
                    When set, is_blocked is always False (fail-open).
    """
    is_blocked:    bool
    blocked_by:    Optional[str]  = None
    score:         float          = 0.0
    block_message: Optional[str]  = None
    latency_ms:    int            = 0
    error:         Optional[str]  = None

    @classmethod
    def safe(cls, latency_ms: int = 0) -> "SecurityResult":
        return cls(is_blocked=False, latency_ms=latency_ms)

    @classmethod
    def blocked(
        cls,
        by:      str,
        score:   float,
        message: str,
        latency_ms: int = 0,
    ) -> "SecurityResult":
        return cls(
            is_blocked    = True,
            blocked_by    = by,
            score         = round(score, 4),
            block_message = message,
            latency_ms    = latency_ms,
        )

    @classmethod
    def errored(cls, error: str, latency_ms: int = 0) -> "SecurityResult":
        """Fail-open: a check error never blocks the user."""
        return cls(is_blocked=False, error=error, latency_ms=latency_ms)


# ── SecurityGuard ─────────────────────────────────────────────────────────────

class SecurityGuard:
    """
    Thin, stateless runtime wrapper that runs the configured security
    components in the correct order for each agent turn.

    Instantiated once during AgentBuilder.build() and injected into Agent.

    Parameters
    ──────────
    input_moderator
        BaseModerator subclass instance (HF transformer). Runs on raw
        user content before any agent processing.
        Mutually exclusive with toxicity_detector.

    toxicity_detector
        JazzmineToxicityDetector instance (XGBoost + feature pipeline).
        Runs on raw user content before any agent processing.
        Mutually exclusive with input_moderator.

    output_moderator
        BaseModerator subclass instance (HF transformer). Runs on the
        agent's generated response before it is returned to the caller.

    file_sanitizer
        BaseSanitizer subclass instance. NOT invoked in the chat() flow.
        Exposed as .sanitizer for callers to use on uploaded files.

    input_confidence_threshold
        Minimum confidence score for a LABEL_1 prediction to be treated
        as a block. Allows tuning precision vs. recall. Default 0.5.

    output_confidence_threshold
        Same threshold for the output moderator. Default 0.5.

    input_block_message
        Response text returned to the user when their input is blocked.

    output_block_message
        Response text returned to the user when the agent output is blocked.

    moderation_timeout
        Maximum seconds to wait for any single moderation call.
        On timeout: fail-open (user is not blocked). Default 10.0.

    fail_open
        True  (default) — if moderation raises an exception or times out,
                          treat the content as safe and continue.
        False           — if moderation raises, re-raise the exception.
                          Use for high-security deployments.
    """

    # ── Default block messages — professional, non-alarming ──────────────────
    _DEFAULT_INPUT_BLOCK = (
        "I'm unable to process this message as it was flagged by our "
        "content safety system. Please rephrase your request and try again. "
        "If you believe this was a mistake, please contact support."
    )
    _DEFAULT_OUTPUT_BLOCK = (
        "I wasn't able to generate a safe response for your request. "
        "Please try rephrasing or ask something different."
    )

    def __init__(
        self,
        *,
        input_moderator:              Any | None  = None,
        toxicity_detector:            Any | None  = None,
        output_moderator:             Any | None  = None,
        file_sanitizer:               Any | None  = None,
        input_confidence_threshold:   float       = 0.5,
        output_confidence_threshold:  float       = 0.5,
        input_block_message:          str         = _DEFAULT_INPUT_BLOCK,
        output_block_message:         str         = _DEFAULT_OUTPUT_BLOCK,
        moderation_timeout:           float       = 10.0,
        fail_open:                    bool        = True,
    ) -> None:
        self._input_moderator             = input_moderator
        self._toxicity_detector           = toxicity_detector
        self._output_moderator            = output_moderator
        self.sanitizer                    = file_sanitizer   # public for callers
        self._input_threshold             = input_confidence_threshold
        self._output_threshold            = output_confidence_threshold
        self._input_block_message         = input_block_message
        self._output_block_message        = output_block_message
        self._timeout                     = moderation_timeout
        self._fail_open                   = fail_open

    # ── Properties ────────────────────────────────────────────────────────────

    @property
    def has_input_gate(self) -> bool:
        return self._input_moderator is not None or self._toxicity_detector is not None

    @property
    def has_output_gate(self) -> bool:
        return self._output_moderator is not None

    @property
    def has_sanitizer(self) -> bool:
        return self.sanitizer is not None

    @property
    def is_noop(self) -> bool:
        """True when no security component is configured (all checks are skipped)."""
        return not self.has_input_gate and not self.has_output_gate and not self.has_sanitizer

    # ── Input check ───────────────────────────────────────────────────────────

    async def check_input(self, content: str) -> SecurityResult:
        """
        Run the configured input-side security check on user content.

        Returns SecurityResult.safe() if no input gate is configured.
        Fails open on timeout / exception (unless fail_open=False).

        Called by Agent.chat() immediately after the user message is
        stored, before any enhancement, memory recall, or LLM calls.
        """
        if not self.has_input_gate:
            return SecurityResult.safe()

        t0 = time.monotonic()

        # ── Path A: HF transformer moderator ─────────────────────────────────
        if self._input_moderator is not None:
            try:
                label, score = await asyncio.wait_for(
                    asyncio.to_thread(self._input_moderator.classify, content),
                    timeout=self._timeout,
                )
                latency = int((time.monotonic() - t0) * 1000)
                if label == _UNSAFE_LABEL and score >= self._input_threshold:
                    log.info(
                        "Input moderation: blocked (score=%.4f threshold=%.2f)",
                        score, self._input_threshold,
                    )
                    return SecurityResult.blocked(
                        by      = "input_moderator",
                        score   = score,
                        message = self._input_block_message,
                        latency_ms = latency,
                    )
                log.debug(
                    "Input moderation: safe (label=%s score=%.4f latency=%dms)",
                    label, score, latency,
                )
                return SecurityResult.safe(latency_ms=latency)

            except asyncio.TimeoutError:
                latency = int((time.monotonic() - t0) * 1000)
                log.warning(
                    "Input moderation timed out after %dms — failing open.", latency
                )
                if not self._fail_open:
                    raise
                return SecurityResult.errored(
                    error      = f"input_moderator timed out after {latency}ms",
                    latency_ms = latency,
                )
            except Exception as exc:
                latency = int((time.monotonic() - t0) * 1000)
                log.warning("Input moderation error: %s — failing open.", exc)
                if not self._fail_open:
                    raise
                return SecurityResult.errored(
                    error      = f"input_moderator raised {type(exc).__name__}: {exc}",
                    latency_ms = latency,
                )

        # ── Path B: XGBoost toxicity detector ────────────────────────────────
        if self._toxicity_detector is not None:
            try:
                is_toxic, score = await asyncio.wait_for(
                    asyncio.to_thread(self._toxicity_detector.predict, content),
                    timeout=self._timeout,
                )
                latency = int((time.monotonic() - t0) * 1000)
                # predict() already applies the detector's own threshold internally
                # (returns is_toxic=True when score >= detector.threshold).
                # We honour that decision rather than re-applying our own threshold
                # so users don't need to configure two thresholds for the detector.
                if is_toxic:
                    log.info(
                        "Toxicity detector: blocked (score=%.4f threshold=%.2f)",
                        score, self._toxicity_detector.threshold,
                    )
                    return SecurityResult.blocked(
                        by      = "toxicity_detector",
                        score   = score,
                        message = self._input_block_message,
                        latency_ms = latency,
                    )
                log.debug(
                    "Toxicity detector: safe (score=%.4f latency=%dms)",
                    score, latency,
                )
                return SecurityResult.safe(latency_ms=latency)

            except asyncio.TimeoutError:
                latency = int((time.monotonic() - t0) * 1000)
                log.warning(
                    "Toxicity detection timed out after %dms — failing open.", latency
                )
                if not self._fail_open:
                    raise
                return SecurityResult.errored(
                    error      = f"toxicity_detector timed out after {latency}ms",
                    latency_ms = latency,
                )
            except Exception as exc:
                latency = int((time.monotonic() - t0) * 1000)
                log.warning("Toxicity detection error: %s — failing open.", exc)
                if not self._fail_open:
                    raise
                return SecurityResult.errored(
                    error      = f"toxicity_detector raised {type(exc).__name__}: {exc}",
                    latency_ms = latency,
                )

        return SecurityResult.safe()

    # ── Output check ──────────────────────────────────────────────────────────

    async def check_output(self, content: str) -> SecurityResult:
        """
        Run the configured output moderator on the agent's generated response.

        Returns SecurityResult.safe() if no output gate is configured.
        Fails open on timeout / exception (unless fail_open=False).

        Called by Agent._chat_inner() immediately after the LLM response
        is generated and before it is stored or returned to the caller.
        """
        if not self.has_output_gate:
            return SecurityResult.safe()

        t0 = time.monotonic()
        try:
            label, score = await asyncio.wait_for(
                asyncio.to_thread(self._output_moderator.classify, content),
                timeout=self._timeout,
            )
            latency = int((time.monotonic() - t0) * 1000)
            if label == _UNSAFE_LABEL and score >= self._output_threshold:
                log.info(
                    "Output moderation: blocked (score=%.4f threshold=%.2f)",
                    score, self._output_threshold,
                )
                return SecurityResult.blocked(
                    by      = "output_moderator",
                    score   = score,
                    message = self._output_block_message,
                    latency_ms = latency,
                )
            log.debug(
                "Output moderation: safe (label=%s score=%.4f latency=%dms)",
                label, score, latency,
            )
            return SecurityResult.safe(latency_ms=latency)

        except asyncio.TimeoutError:
            latency = int((time.monotonic() - t0) * 1000)
            log.warning(
                "Output moderation timed out after %dms — failing open.", latency
            )
            if not self._fail_open:
                raise
            return SecurityResult.errored(
                error      = f"output_moderator timed out after {latency}ms",
                latency_ms = latency,
            )
        except Exception as exc:
            latency = int((time.monotonic() - t0) * 1000)
            log.warning("Output moderation error: %s — failing open.", exc)
            if not self._fail_open:
                raise
            return SecurityResult.errored(
                error      = f"output_moderator raised {type(exc).__name__}: {exc}",
                latency_ms = latency,
            )

    # ── Repr ──────────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        parts = []
        if self._input_moderator is not None:
            parts.append(f"input_moderator={type(self._input_moderator).__name__}")
        if self._toxicity_detector is not None:
            parts.append(f"toxicity_detector={type(self._toxicity_detector).__name__}")
        if self._output_moderator is not None:
            parts.append(f"output_moderator={type(self._output_moderator).__name__}")
        if self.sanitizer is not None:
            parts.append(f"sanitizer={type(self.sanitizer).__name__}")
        return f"<SecurityGuard {', '.join(parts) or 'noop'}>"


# ── Module-level noop singleton ───────────────────────────────────────────────
# Returned by AgentBuilder when no .security() call was made.
# Zero overhead: all has_*_gate properties return False.

NOOP_GUARD = SecurityGuard()