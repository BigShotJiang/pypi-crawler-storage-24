"""
flow_selector.py
────────────────
Two-stage flow resolution:

  Stage 1 — Selection (metadata only, no build_prompt)
    Candidate dicts from ProceduralMemory.recall() are formatted into a
    compact XML block and fed to the LLM. The LLM picks one or more flow
    ids from the candidates based on what the user actually needs.

  Stage 2 — Load (build_prompt on chosen flows)
    For each chosen id, look up the flow object in the registry and call
    build_prompt(verbose=False) to get the full execution prompt.

The registry is the only place that connects a flow_id back to a live
flow object. Qdrant is purely the semantic index.

Changes from original:
  - Compressed SELECTOR_SYSTEM_PROMPT (~45% fewer tokens, same behaviour).
    desired_effects field in the candidates XML still does the disambiguation.
  - build_prompt now called with verbose=False to reduce token footprint of
    the combined_prompt injected into the agent context.
"""

import json
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from jazzmine.core.flows import BaseFlow
from jazzmine.core.llm import BaseLLM, MessagePart

if TYPE_CHECKING:
    from memory import ProceduralMemory

logger = logging.getLogger(__name__)

# ── Selector prompt ────────────────────────────────────────────────────────────
# Compressed: ~100 tokens vs ~200 in the original.
# Rules preserved: pick best match, allow multi-select for distinct intents,
# empty list when nothing fits, no invented ids.

SELECTOR_SYSTEM_PROMPT = """Select which flow(s) to execute for the user's request given the candidate flows below.

Rules:
1. Pick the flow(s) whose condition best matches the request. Use desired_effects to break ties.
2. Pick multiple only when the request clearly requires distinct parallel or sequential actions.
3. Return [] if no candidate fits.
4. Only use ids from the candidates — never invent ids.

Return ONLY a raw JSON array of flow ids, e.g. ["id1"]. No explanation, no markdown.
"""


def _build_candidates_xml(candidates: list[dict]) -> str:
    """
    Format Qdrant metadata dicts into a compact XML block for the selector prompt.
    Uses only the fields that matter for selection.
    """
    lines = ["<candidate_flows>"]
    for c in candidates:
        lines.append(
            f'  <candidate id="{c["flow_id"]}" type="{c.get("flow_type", "flow")}">'
        )
        lines.append(f'    <name>{c["flow_name"]}</name>')
        lines.append(f'    <description>{c["description"]}</description>')
        lines.append(f'    <condition>{c["condition"]}</condition>')
        effects = c.get("desired_effects") or []
        if effects:
            lines.append("    <desired_effects>")
            for effect in effects:
                lines.append(f"      <effect>{effect}</effect>")
            lines.append("    </desired_effects>")
        lines.append("  </candidate>")
    lines.append("</candidate_flows>")
    return "\n".join(lines)


def _build_selector_user_content(
    enhanced_query:    str,
    candidates:        list[dict],
    episode_summaries: list[str],
) -> str:
    parts = [f"<user_request>{enhanced_query}</user_request>", ""]

    if episode_summaries:
        parts.append("<recent_context>")
        for s in episode_summaries:
            parts.append(f"  <episode>{s}</episode>")
        parts.append("</recent_context>")
        parts.append("")

    parts.append(_build_candidates_xml(candidates))
    return "\n".join(parts)


# ── Result dataclass ──────────────────────────────────────────────────────────

@dataclass
class FlowSelectionResult:
    chosen_flows:    list[BaseFlow]   # live flow objects, build_prompt-ready
    chosen_prompts:  list[str]        # build_prompt(verbose=False) for each
    combined_prompt: str              # all prompts joined — drop into context
    unresolved_ids:  list[str]        # ids LLM picked but not in registry (stale)
    candidates:      list[dict]       # raw Qdrant dicts used for selection


# ── Main selector ─────────────────────────────────────────────────────────────

class FlowSelector:

    def __init__(
        self,
        llm:           BaseLLM,
        flow_registry: dict[str, BaseFlow],
        proc_mem:      "ProceduralMemory | None" = None,
        agent_id:      str = "",
        top_k:         int = 3,
        rrf_k:         int = 10,
    ):
        self.llm           = llm
        self.flow_registry = flow_registry
        self.proc_mem      = proc_mem
        self.agent_id      = agent_id
        self.top_k         = top_k
        self.rrf_k         = rrf_k
        # Cache flow.build_prompt(verbose=False) per flow id.
        # Flow definitions never change at runtime, so calling build_prompt on
        # every selection is wasteful. The cache is keyed by flow.id (stable
        # uuid5) rather than flow name to survive any hypothetical name change.
        self._prompt_cache: dict[str, str] = {}

    async def select(
        self,
        enhanced_query:    str,
        candidates:        list[dict] | None = None,
        episode_summaries: list[str] | None = None,
    ) -> FlowSelectionResult:
        """
        Stage 1: recall candidates from Qdrant using an episode-augmented query.
        Stage 2: LLM picks flow ids from the metadata XML.
        Stage 3: resolve ids → flow objects → build_prompt(verbose=False).
        """
        episode_summaries = episode_summaries or []

        # Internal recall with augmented query if candidates not provided.
        if candidates is None:
            if self.proc_mem is None or not self.agent_id:
                logger.debug(
                    "FlowSelector internal recall unavailable (proc_mem=%s, agent_id=%r); "
                    "returning empty selection.",
                    self.proc_mem is not None,
                    self.agent_id,
                )
                return FlowSelectionResult([], [], "", [], [])
            candidates = await self._recall(enhanced_query, episode_summaries)

        if not candidates:
            return FlowSelectionResult([], [], "", [], candidates or [])

        # Fast path: single candidate, skip LLM call.
        if len(candidates) == 1:
            chosen_ids = [candidates[0]["flow_id"]]
        else:
            chosen_ids = await self._llm_select(
                enhanced_query, candidates, episode_summaries
            )

        # Stage 2: registry lookup + build_prompt (verbose=False for token savings).
        chosen_flows:   list[BaseFlow] = []
        chosen_prompts: list[str]      = []
        unresolved:     list[str]      = []

        for fid in chosen_ids:
            flow = self.flow_registry.get(fid)
            if flow is None:
                logger.warning(
                    "Flow id '%s' chosen by LLM but not found in registry — "
                    "may be a stale Qdrant entry or hallucination.",
                    fid,
                )
                unresolved.append(fid)
                continue
            if fid not in self._prompt_cache:
                self._prompt_cache[fid] = flow.build_prompt(verbose=False)
            prompt = self._prompt_cache[fid]
            chosen_flows.append(flow)
            chosen_prompts.append(prompt)

        # Fallback: LLM returned nothing valid → use top candidate.
        if not chosen_flows and candidates:
            fallback_id = candidates[0]["flow_id"]
            fallback    = self.flow_registry.get(fallback_id)
            if fallback:
                logger.info(
                    "No valid selection — falling back to top candidate '%s'.",
                    fallback_id,
                )
                if fallback_id not in self._prompt_cache:
                    self._prompt_cache[fallback_id] = fallback.build_prompt(verbose=False)
                chosen_flows   = [fallback]
                chosen_prompts = [self._prompt_cache[fallback_id]]

        combined = "\n\n".join(chosen_prompts)
        return FlowSelectionResult(
            chosen_flows, chosen_prompts, combined, unresolved, candidates
        )

    # ── private ───────────────────────────────────────────────────────────────

    async def _recall(
        self,
        enhanced_query:    str,
        episode_summaries: list[str],
    ) -> list[dict]:
        """
        Build an episode-augmented query and recall from Qdrant.
        Concatenating episode summaries helps the embedding model find the
        correct flows for vague messages like "I need help with that".
        """
        if episode_summaries:
            augmented = enhanced_query + " " + " ".join(episode_summaries)
        else:
            augmented = enhanced_query

        return await self.proc_mem.recall(
            query    = augmented,
            agent_id = self.agent_id,
            top_k    = self.top_k,
            rrf_k    = self.rrf_k,
        )

    async def _llm_select(
        self,
        enhanced_query:    str,
        candidates:        list[dict],
        episode_summaries: list[str],
    ) -> list[str]:
        user_content = _build_selector_user_content(
            enhanced_query, candidates, episode_summaries
        )

        try:
            response = await self.llm.agenerate([
                MessagePart(role="system", content=SELECTOR_SYSTEM_PROMPT),
                MessagePart(role="user",   content=user_content),
            ])
            raw = response.text.strip()

            # Strip markdown fences if the model wrapped the JSON.
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.lower().startswith("json"):
                    raw = raw[4:]
                raw = raw.strip()

            ids = json.loads(raw)
            if not isinstance(ids, list):
                raise ValueError(f"Expected list, got {type(ids)}")

            return [str(i).strip() for i in ids if str(i).strip()]

        except (json.JSONDecodeError, ValueError) as exc:
            logger.warning(
                "Selector LLM returned unparseable output: %s — falling back.", exc
            )
            return []