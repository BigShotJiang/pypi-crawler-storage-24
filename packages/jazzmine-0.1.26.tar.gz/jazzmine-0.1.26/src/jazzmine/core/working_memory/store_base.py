from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from typing import Any

from jazzmine.core.working_memory.enums import ConversationStatus, FlowStatus
from jazzmine.core.working_memory.records import (
    FlowRecord,
    PendingConfirmation,
    Slot,
    ToolCallRecord,
    TopicShift,
    WorkspaceEntity,
)
from jazzmine.core.working_memory.state import ActiveFlowState, TurnCache, WorkingMemory

logger = logging.getLogger(__name__)


class WorkingMemoryStore(ABC):
    @abstractmethod
    async def get(self, conversation_id: str) -> WorkingMemory | None:
        ...

    @abstractmethod
    async def save(self, wm: WorkingMemory) -> None:
        ...

    @abstractmethod
    async def delete(self, conversation_id: str) -> None:
        ...

    async def get_or_create(
        self,
        conversation_id: str,
        user_id: str,
        agent_id: str,
    ) -> WorkingMemory:
        wm = await self.get(conversation_id)
        if wm is None:
            wm = WorkingMemory(conversation_id=conversation_id, user_id=user_id, agent_id=agent_id)
            await self.save(wm)
        return wm

    async def begin_turn(
        self,
        conversation_id: str,
        turn_cache: TurnCache,
    ) -> WorkingMemory:
        wm = await self._require(conversation_id)
        wm.turn_number = turn_cache.turn_number
        wm.current_turn = turn_cache
        wm.last_updated = time.time()

        self._merge_entities(wm, turn_cache.raw_entities, turn_cache.turn_number)
        self._evict_stale_entities(wm, turn_cache.turn_number)

        if not turn_cache.is_continuation:
            wm.topic_history.append(TopicShift(turn_number=turn_cache.turn_number, intent=turn_cache.intent))

        if wm.pending_confirmation is not None:
            if wm.pending_confirmation.is_expired(turn_cache.turn_number):
                logger.info(
                    "PendingConfirmation for flow '%s' expired — auto-cancelling.",
                    wm.pending_confirmation.flow_id,
                )
                wm.pending_confirmation = None
                if wm.active_flow and wm.active_flow.status == FlowStatus.AWAITING_CONFIRMATION:
                    self._do_cancel_flow(wm, turn_cache.turn_number)

        if turn_cache.is_cancellation and wm.is_in_flow:
            logger.info(
                "is_cancellation=True — auto-cancelling active flow '%s'.",
                wm.active_flow.flow_name,
            )
            self._do_cancel_flow(wm, turn_cache.turn_number)

        self._sync_status(wm)
        await self.save(wm)
        return wm

    async def end_turn(
        self,
        conversation_id: str,
        agent_response: str,
        agent_intent: str,
        topic_summary: str = "",
    ) -> WorkingMemory:
        wm = await self._require(conversation_id)
        wm.last_agent_response = agent_response
        wm.last_agent_intent = agent_intent
        wm.last_updated = time.time()

        if wm.topic_history and not wm.topic_history[-1].summary:
            wm.topic_history[-1].summary = topic_summary or agent_intent

        await self.save(wm)
        return wm

    async def start_flow(
        self,
        conversation_id: str,
        flow_state: ActiveFlowState,
    ) -> WorkingMemory:
        wm = await self._require(conversation_id)
        if wm.is_in_flow:
            logger.warning(
                "Starting flow '%s' while '%s' is still active (status=%s). "
                "Resolve the current flow before starting a new one.",
                flow_state.flow_name,
                wm.active_flow.flow_name,
                wm.active_flow.status.value,
            )
        wm.active_flow = flow_state
        wm.last_updated = time.time()
        self._sync_status(wm)
        await self.save(wm)
        return wm

    async def advance_sequential_step(
        self,
        conversation_id: str,
        step_result: dict,
    ) -> WorkingMemory:
        wm = await self._require(conversation_id)
        if wm.active_flow is None:
            logger.warning("advance_sequential_step: no active flow.")
            return wm
        wm.active_flow.step_results.append(step_result)
        wm.active_flow.current_step += 1
        wm.last_updated = time.time()
        await self.save(wm)
        return wm

    async def record_branch_result(
        self,
        conversation_id: str,
        branch_id: str,
        result: dict,
    ) -> WorkingMemory:
        wm = await self._require(conversation_id)
        if wm.active_flow is None:
            logger.warning("record_branch_result: no active flow.")
            return wm
        if branch_id not in wm.active_flow.branch_results:
            logger.warning("Unknown branch_id '%s' for flow '%s'.", branch_id, wm.active_flow.flow_name)
            return wm
        wm.active_flow.branch_results[branch_id] = result
        wm.last_updated = time.time()
        await self.save(wm)
        return wm

    async def set_condition_branch(
        self,
        conversation_id: str,
        branch: str,
    ) -> WorkingMemory:
        wm = await self._require(conversation_id)
        if wm.active_flow is None:
            logger.warning("set_condition_branch: no active flow.")
            return wm
        wm.active_flow.condition_branch_taken = branch
        wm.last_updated = time.time()
        await self.save(wm)
        return wm

    async def record_tool_call(
        self,
        conversation_id: str,
        record: ToolCallRecord,
    ) -> WorkingMemory:
        wm = await self._require(conversation_id)

        if wm.current_turn is not None:
            record.call_index = len(wm.current_turn.tool_calls)
            wm.current_turn.tool_calls.append(record)
        else:
            logger.warning(
                "record_tool_call called with no active TurnCache — "
                "call begin_turn() before recording tool calls."
            )

        if wm.active_flow is not None:
            wm.active_flow.tool_call_history.append(record)

        wm.last_updated = time.time()
        await self.save(wm)
        return wm

    async def register_slots(
        self,
        conversation_id: str,
        slots: list[Slot],
    ) -> WorkingMemory:
        wm = await self._require(conversation_id)
        if wm.active_flow is None:
            logger.warning("register_slots: no active flow.")
            return wm
        for slot in slots:
            if slot.name not in wm.active_flow.slots:
                wm.active_flow.slots[slot.name] = slot
        wm.active_flow.status = FlowStatus.COLLECTING_SLOTS
        self._sync_status(wm)
        wm.last_updated = time.time()
        await self.save(wm)
        return wm

    async def collect_slot(
        self,
        conversation_id: str,
        slot_name: str,
        value: Any,
        validation_error: str = "",
    ) -> WorkingMemory:
        wm = await self._require(conversation_id)
        if wm.active_flow is None or slot_name not in wm.active_flow.slots:
            logger.warning("collect_slot: slot '%s' not found in active flow.", slot_name)
            return wm

        slot = wm.active_flow.slots[slot_name]

        if validation_error:
            slot.collected = False
            slot.value = None
            slot.validation_error = validation_error
        else:
            slot.collected = True
            slot.value = value
            slot.collected_at_turn = wm.turn_number
            slot.validation_error = ""
            if wm.active_flow.all_slots_collected:
                wm.active_flow.status = FlowStatus.ACTIVE

        self._sync_status(wm)
        wm.last_updated = time.time()
        await self.save(wm)
        return wm

    async def request_confirmation(
        self,
        conversation_id: str,
        confirmation: PendingConfirmation,
    ) -> WorkingMemory:
        wm = await self._require(conversation_id)
        wm.pending_confirmation = confirmation
        if wm.active_flow:
            wm.active_flow.status = FlowStatus.AWAITING_CONFIRMATION
        self._sync_status(wm)
        wm.last_updated = time.time()
        await self.save(wm)
        return wm

    async def confirm_action(self, conversation_id: str) -> WorkingMemory:
        wm = await self._require(conversation_id)
        wm.pending_confirmation = None
        if wm.active_flow and wm.active_flow.status == FlowStatus.AWAITING_CONFIRMATION:
            wm.active_flow.status = FlowStatus.ACTIVE
        self._sync_status(wm)
        wm.last_updated = time.time()
        await self.save(wm)
        return wm

    async def complete_flow(self, conversation_id: str) -> WorkingMemory:
        wm = await self._require(conversation_id)
        if wm.active_flow is None:
            return wm
        wm.active_flow.status = FlowStatus.COMPLETED
        self._archive_active_flow(wm, wm.turn_number)
        wm.active_flow = None
        wm.pending_confirmation = None
        self._sync_status(wm)
        wm.last_updated = time.time()
        await self.save(wm)
        return wm

    async def cancel_flow(self, conversation_id: str) -> WorkingMemory:
        wm = await self._require(conversation_id)
        self._do_cancel_flow(wm, wm.turn_number)
        await self.save(wm)
        return wm

    async def fail_flow(self, conversation_id: str) -> WorkingMemory:
        wm = await self._require(conversation_id)
        if wm.active_flow is None:
            return wm
        wm.active_flow.status = FlowStatus.FAILED
        self._archive_active_flow(wm, wm.turn_number)
        wm.active_flow = None
        wm.pending_confirmation = None
        self._sync_status(wm)
        wm.last_updated = time.time()
        await self.save(wm)
        return wm

    async def _require(self, conversation_id: str) -> WorkingMemory:
        wm = await self.get(conversation_id)
        if wm is None:
            raise KeyError(
                f"No working memory for conversation '{conversation_id}'. "
                "Call get_or_create() first."
            )
        return wm

    @staticmethod
    def _do_cancel_flow(wm: WorkingMemory, current_turn: int) -> None:
        if wm.active_flow is None:
            return
        wm.active_flow.status = FlowStatus.CANCELLED
        WorkingMemoryStore._archive_active_flow(wm, current_turn)
        wm.active_flow = None
        wm.pending_confirmation = None
        WorkingMemoryStore._sync_status(wm)
        wm.last_updated = time.time()

    @staticmethod
    def _archive_active_flow(wm: WorkingMemory, ended_at_turn: int) -> None:
        if wm.active_flow is None:
            return
        tool_summaries = [
            r.result_summary
            for r in wm.active_flow.tool_call_history
            if r.success and r.result_summary
        ]
        wm.flow_history.append(
            FlowRecord(
                flow_id=wm.active_flow.flow_id,
                flow_name=wm.active_flow.flow_name,
                flow_type=wm.active_flow.flow_type,
                status=wm.active_flow.status.value,
                started_at_turn=wm.active_flow.started_at_turn,
                ended_at_turn=ended_at_turn,
                slot_values=wm.active_flow.collected_slot_values,
                tool_summaries=tool_summaries,
            )
        )

    @staticmethod
    def _merge_entities(
        wm: WorkingMemory,
        entities: list[dict],
        turn: int,
    ) -> None:
        for raw in entities:
            name = raw.get("name", "").strip()
            if not name:
                continue
            attrs = raw.get("attributes", [])
            if name in wm.entity_workspace:
                e = wm.entity_workspace[name]
                e.last_seen_turn = turn
                e.mention_count += 1
                seen = set(e.attributes)
                for a in attrs:
                    if a not in seen:
                        e.attributes.append(a)
                        seen.add(a)
            else:
                wm.entity_workspace[name] = WorkspaceEntity(
                    name=name,
                    attributes=list(attrs),
                    first_seen_turn=turn,
                    last_seen_turn=turn,
                    mention_count=1,
                )

    @staticmethod
    def _evict_stale_entities(wm: WorkingMemory, current_turn: int) -> None:
        stale = [
            name
            for name, e in wm.entity_workspace.items()
            if (current_turn - e.last_seen_turn) > wm.entity_max_age_turns
        ]
        for name in stale:
            del wm.entity_workspace[name]
        if stale:
            logger.debug("Evicted stale entities: %s", stale)

    @staticmethod
    def _sync_status(wm: WorkingMemory) -> None:
        if wm.active_flow is None:
            wm.status = ConversationStatus.IDLE
        elif wm.active_flow.status == FlowStatus.COLLECTING_SLOTS:
            wm.status = ConversationStatus.COLLECTING_SLOTS
        elif wm.active_flow.status == FlowStatus.AWAITING_CONFIRMATION:
            wm.status = ConversationStatus.AWAITING_CONFIRMATION
        elif wm.active_flow.status == FlowStatus.ACTIVE:
            wm.status = ConversationStatus.IN_FLOW
        else:
            wm.status = ConversationStatus.IDLE
