from __future__ import annotations

import asyncio
import json
import logging
import random
import uuid
from contextlib import asynccontextmanager
from typing import Any

from jazzmine.core.working_memory.records import PendingConfirmation, ToolCallRecord
from jazzmine.core.working_memory.state import ActiveFlowState, TurnCache, WorkingMemory
from jazzmine.core.working_memory.store_base import WorkingMemoryStore

logger = logging.getLogger(__name__)

_LUA_RELEASE = (
    "if redis.call('get',KEYS[1])==ARGV[1] then "
    "return redis.call('del',KEYS[1]) "
    "else return 0 end"
)


class RedisWorkingMemoryStore(WorkingMemoryStore):
    KEY_PREFIX = "wm:"
    LOCK_PREFIX = "wm_lock:"
    LOCK_TIMEOUT = 15

    def __init__(self, redis_client, ttl_seconds: int = 3600) -> None:
        self._redis = redis_client
        self._ttl = ttl_seconds

    def _key(self, cid: str) -> str:
        return f"{self.KEY_PREFIX}{cid}"

    @asynccontextmanager
    async def _distributed_lock(self, conversation_id: str):
        token = str(uuid.uuid4())
        lock_key = f"{self.LOCK_PREFIX}{conversation_id}"
        acquired = False
        poll = 0.02

        deadline = asyncio.get_event_loop().time() + self.LOCK_TIMEOUT

        while not acquired:
            remaining = deadline - asyncio.get_event_loop().time()
            if remaining <= 0:
                raise TimeoutError(
                    f"Could not acquire working-memory lock for conversation "
                    f"'{conversation_id}' within {self.LOCK_TIMEOUT}s. "
                    "Possible causes: deadlock, clock skew, or LOCK_TIMEOUT too low "
                    "relative to LLM latency. Check logs for 'lock expired' warnings."
                )
            acquired = await self._redis.set(lock_key, token, nx=True, ex=self.LOCK_TIMEOUT)
            if not acquired:
                delay = min(poll + random.uniform(0, poll * 0.5), remaining, 0.2)
                await asyncio.sleep(delay)
                poll = min(poll * 1.5, 0.2)

        try:
            yield
        finally:
            released = await self._redis.eval(_LUA_RELEASE, 1, lock_key, token)
            if not released:
                logger.warning(
                    "Working-memory lock for '%s' expired before release "
                    "(held > %ss). The operation may have raced with another "
                    "worker.  Increase LOCK_TIMEOUT if this recurs.",
                    conversation_id,
                    self.LOCK_TIMEOUT,
                )

    async def get(self, conversation_id: str) -> WorkingMemory | None:
        raw = await self._redis.get(self._key(conversation_id))
        if raw is None:
            return None
        try:
            return WorkingMemory.from_dict(json.loads(raw))
        except (json.JSONDecodeError, KeyError, TypeError) as exc:
            logger.error("Corrupted working memory for '%s': %s — deleting.", conversation_id, exc)
            await self.delete(conversation_id)
            return None

    async def save(self, wm: WorkingMemory) -> None:
        await self._redis.set(
            self._key(wm.conversation_id),
            json.dumps(wm.to_dict()),
            ex=self._ttl,
        )

    async def delete(self, conversation_id: str) -> None:
        await self._redis.delete(
            self._key(conversation_id),
            f"{self.LOCK_PREFIX}{conversation_id}",
        )

    def active_count(self) -> int:
        raise NotImplementedError(
            "active_count() requires a synchronous SCAN — use "
            "the async variant or maintain a separate counter key."
        )

    async def get_or_create(
        self,
        conversation_id: str,
        user_id: str,
        agent_id: str,
    ) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().get_or_create(conversation_id, user_id, agent_id)

    async def begin_turn(
        self,
        conversation_id: str,
        turn_cache: TurnCache,
    ) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().begin_turn(conversation_id, turn_cache)

    async def end_turn(
        self,
        conversation_id: str,
        agent_response: str,
        agent_intent: str,
        topic_summary: str = "",
    ) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().end_turn(conversation_id, agent_response, agent_intent, topic_summary)

    async def start_flow(
        self,
        conversation_id: str,
        flow_state: ActiveFlowState,
    ) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().start_flow(conversation_id, flow_state)

    async def advance_sequential_step(
        self,
        conversation_id: str,
        step_result: dict,
    ) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().advance_sequential_step(conversation_id, step_result)

    async def record_branch_result(
        self,
        conversation_id: str,
        branch_id: str,
        result: dict,
    ) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().record_branch_result(conversation_id, branch_id, result)

    async def set_condition_branch(
        self,
        conversation_id: str,
        branch: str,
    ) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().set_condition_branch(conversation_id, branch)

    async def record_tool_call(
        self,
        conversation_id: str,
        record: ToolCallRecord,
    ) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().record_tool_call(conversation_id, record)

    async def register_slots(
        self,
        conversation_id: str,
        slots: list,
    ) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().register_slots(conversation_id, slots)

    async def collect_slot(
        self,
        conversation_id: str,
        slot_name: str,
        value: Any,
        validation_error: str = "",
    ) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().collect_slot(conversation_id, slot_name, value, validation_error)

    async def request_confirmation(
        self,
        conversation_id: str,
        confirmation: PendingConfirmation,
    ) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().request_confirmation(conversation_id, confirmation)

    async def confirm_action(self, conversation_id: str) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().confirm_action(conversation_id)

    async def complete_flow(self, conversation_id: str) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().complete_flow(conversation_id)

    async def cancel_flow(self, conversation_id: str) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().cancel_flow(conversation_id)

    async def fail_flow(self, conversation_id: str) -> WorkingMemory:
        async with self._distributed_lock(conversation_id):
            return await super().fail_flow(conversation_id)
