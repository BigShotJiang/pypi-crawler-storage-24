from __future__ import annotations

import asyncio

from jazzmine.core.working_memory.state import WorkingMemory
from jazzmine.core.working_memory.store_base import WorkingMemoryStore


class InMemoryWorkingMemoryStore(WorkingMemoryStore):
    """Dict-backed store for single-process deployments."""

    def __init__(self) -> None:
        self._store: dict[str, WorkingMemory] = {}
        self._locks: dict[str, asyncio.Lock] = {}

    def _lock_for(self, cid: str) -> asyncio.Lock:
        if cid not in self._locks:
            self._locks[cid] = asyncio.Lock()
        return self._locks[cid]

    async def get(self, conversation_id: str) -> WorkingMemory | None:
        async with self._lock_for(conversation_id):
            return self._store.get(conversation_id)

    async def save(self, wm: WorkingMemory) -> None:
        async with self._lock_for(wm.conversation_id):
            self._store[wm.conversation_id] = wm

    async def delete(self, conversation_id: str) -> None:
        async with self._lock_for(conversation_id):
            self._store.pop(conversation_id, None)
        self._locks.pop(conversation_id, None)

    def active_count(self) -> int:
        return len(self._store)
