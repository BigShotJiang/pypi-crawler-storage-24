from __future__ import annotations

from enum import Enum


class FlowStatus(str, Enum):
    """Lifecycle state of a flow tracked in ActiveFlowState."""

    ACTIVE = "active"
    COLLECTING_SLOTS = "collecting_slots"
    AWAITING_CONFIRMATION = "awaiting_confirmation"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    FAILED = "failed"


class ConversationStatus(str, Enum):
    """Coarse conversation state used by routing and prompt construction."""

    IDLE = "idle"
    IN_FLOW = "in_flow"
    COLLECTING_SLOTS = "collecting_slots"
    AWAITING_CONFIRMATION = "awaiting_confirmation"
    ERROR = "error"
