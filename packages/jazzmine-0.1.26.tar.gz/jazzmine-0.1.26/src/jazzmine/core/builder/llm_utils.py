from __future__ import annotations

import logging
from typing import Any, Callable, Coroutine

from jazzmine.core.builder.errors import ConfigError

log = logging.getLogger(__name__)

def _build_llm(cfg: Any) -> Any:
    """Dispatch on provider config type and construct the correct BaseLLM."""
    p = cfg.provider

    if p == "openai":
        from jazzmine.core.llm.providers.openai_compatible import OpenAICompatibleLLM
        return OpenAICompatibleLLM(
            model          = cfg.model,
            api_key        = cfg.api_key,
            base_url       = cfg.base_url,
            temperature    = cfg.temperature,
            max_tokens     = cfg.max_tokens,
            timeout        = cfg.timeout,
            top_p          = cfg.top_p,
            chat_endpoint  = cfg.chat_endpoint,
        )

    if p == "anthropic":
        from jazzmine.core.llm.providers.anthropic import AnthropicLLM
        return AnthropicLLM(
            model       = cfg.model,
            api_key     = cfg.api_key,
            base_url    = cfg.base_url,
            temperature = cfg.temperature,
            max_tokens  = cfg.max_tokens,
            timeout     = cfg.timeout,
        )

    if p == "gemini":
        from jazzmine.core.llm.providers.google import GeminiLLM
        return GeminiLLM(
            model       = cfg.model,
            api_key     = cfg.api_key,
            base_url    = cfg.base_url,
            temperature = cfg.temperature,
            max_tokens  = cfg.max_tokens,
            timeout     = cfg.timeout,
        )

    if p == "azure":
        from jazzmine.core.llm.providers.azure import AzureOpenAILLM
        return AzureOpenAILLM(
            api_key         = cfg.api_key,
            endpoint        = cfg.endpoint,
            deployment_name = cfg.deployment_name,
            api_version     = cfg.api_version,
            temperature     = cfg.temperature,
            max_tokens      = cfg.max_tokens,
            timeout         = cfg.timeout,
        )

    if p == "cohere":
        from jazzmine.core.llm.providers.cohere import CohereLLM
        return CohereLLM(
            api_key     = cfg.api_key,
            model       = cfg.model,
            temperature = cfg.temperature,
            max_tokens  = cfg.max_tokens,
            timeout     = cfg.timeout,
        )

    if p == "bedrock":
        from jazzmine.core.llm.providers.bedrock import BedrockLLM
        return BedrockLLM(
            model       = cfg.model,
            region_name = cfg.region_name,
            temperature = cfg.temperature,
            max_tokens  = cfg.max_tokens,
        )

    if p == "local":
        from jazzmine.core.llm.providers.local import LocalLLM
        return LocalLLM(
            binary_path = cfg.binary_path,
            model       = cfg.model,
            temperature = cfg.temperature,
            max_tokens  = cfg.max_tokens,
        )

    raise ConfigError(f"Unknown LLM provider {p!r}.")


def _validate_llm_cfg(cfg: Any, label: str, errors: list) -> None:
    """
    Run provider-specific validation on an LLM config object.
    Common fields (temperature, max_tokens, timeout) are always checked.
    Provider-specific required fields are checked by provider.
    `label` is "llm" or "script_gen_llm" — used in error messages.
    """
    if cfg is None:
        return

    # Common fields
    model = getattr(cfg, "model", "")
    if not str(model).strip():
        errors.append(f"{label}.model cannot be empty.")
    t = getattr(cfg, "temperature", 0.5)
    if not (0.0 <= t <= 2.0):
        errors.append(f"{label}.temperature {t!r} must be in [0.0, 2.0].")
    mt = getattr(cfg, "max_tokens", 1)
    if mt < 1:
        errors.append(f"{label}.max_tokens {mt!r} must be >= 1.")
    to = getattr(cfg, "timeout", 1.0)
    if to <= 0:
        errors.append(f"{label}.timeout {to!r} must be > 0.")

    p = getattr(cfg, "provider", "unknown")

    # Provider-specific required fields
    if p in ("openai", "anthropic", "gemini", "cohere"):
        api_key = getattr(cfg, "api_key", "")
        if not str(api_key).strip():
            errors.append(f"{label}.api_key cannot be empty.")

    if p in ("openai", "anthropic", "gemini"):
        base_url = getattr(cfg, "base_url", "")
        if not str(base_url).strip():
            errors.append(f"{label}.base_url cannot be empty.")

    if p == "azure":
        for field_name in ("api_key", "endpoint", "deployment_name"):
            v = getattr(cfg, field_name, "")
            if not str(v).strip():
                errors.append(f"{label}.{field_name} cannot be empty.")

    if p == "bedrock":
        region = getattr(cfg, "region_name", "")
        if not str(region).strip():
            errors.append(f"{label}.region_name cannot be empty.")

    if p == "local":
        bp = getattr(cfg, "binary_path", "")
        if not str(bp).strip():
            errors.append(f"{label}.binary_path cannot be empty.")

    if p == "openai":
        ep = getattr(cfg, "chat_endpoint", "")
        if not str(ep).strip():
            errors.append(f"{label}.chat_endpoint cannot be empty.")
        top_p = getattr(cfg, "top_p", None)
        if top_p is not None and not (0.0 <= top_p <= 1.0):
            errors.append(f"{label}.top_p {top_p!r} must be in [0.0, 1.0].")


def _closer(llm: Any) -> Callable[[], Coroutine]:
    async def _close():
        try:
            llm.close()
            await llm.aclose()
        except Exception as exc:
            log.warning("LLM close raised: %s", exc)

    return _close
