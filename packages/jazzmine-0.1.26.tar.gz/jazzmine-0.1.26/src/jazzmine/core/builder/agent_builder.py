from __future__ import annotations

import logging
import hashlib
import json
import tempfile
from pathlib import Path
from typing import Any, Callable

from jazzmine.core.agent.agent_logger import AgentLogger

from jazzmine.core.builder.configs import (
    AgentSettings,
    CORSConfig,
    DomainTerm,
    EmbeddingConfig,              
    FileMount,
    LLMConfig,
    MemoryConfig,
    MongoDBStorage,
    PostgresStorage,
    SandboxSpec,
    SecurityConfig,
    ServerConfig,
    StorageConfig,
    JsonStorage,
)
from jazzmine.core.builder.errors import ConfigError
from jazzmine.core.builder.llm_utils import _build_llm, _closer, _validate_llm_cfg
from jazzmine.core.builder.memory_stubs import _NoopEpisodicMemory, _NoopSemanticMemory
from jazzmine.core.builder.server import AgentServer
from jazzmine.core.builder.startup import StartupDisplay
from jazzmine.core.builder.teardown import Teardown

log = logging.getLogger(__name__)

# Default output directory for embedding models
_DEFAULT_MODELS_ROOT = Path.home() / ".jazzmine" / "models"


class AgentBuilder:
    """
    Fluent builder for a Jazzmine Agent.

    Every fluent method returns self for chaining.
    build() is the only async method.

    Validation runs synchronously at the start of build() — config errors
    are raised before any connections are opened.
    """

    def __init__(
        self,
        name:        str,
        agent_id:    str,
        personality: str,
    ) -> None:
        if not name.strip():
            raise ConfigError("name cannot be empty.")
        if not agent_id.strip():
            raise ConfigError("agent_id cannot be empty.")
        if not personality.strip():
            raise ConfigError("personality cannot be empty.")

        self._name        = name
        self._agent_id    = agent_id
        self._personality = personality
        self._version     = ""

        # Config objects
        self._llm_cfg:    Any | None = None
        self._sg_llm_cfg: Any | None = None
        self._mem_cfg:       MemoryConfig | None  = None
        self._embed_cfg:     EmbeddingConfig | None = None   
        self._storage_cfg:   StorageConfig         = JsonStorage()
        self._sandbox_specs: list[SandboxSpec]     = []
        self._flows:         list[Any]             = []
        self._domain_terms:  list[DomainTerm]      = []
        self._settings:      AgentSettings         = AgentSettings()
        self._on_intermediate: Callable | None     = None
        self._startup_display: StartupDisplay | None = None
        self._logging_cfg: dict | None             = None
        self._sec_cfg:     SecurityConfig | None   = None
        self._server_cfg:  ServerConfig | None     = None
        self._agent_server: AgentServer | None     = None

        # Escape-hatch overrides (pre-built instances)
        self._o_llm:            Any | None = None
        self._o_sg_llm:         Any | None = None
        self._o_msg_store:      Any | None = None
        self._o_wm_store:       Any | None = None
        self._o_registry:       Any | None = None
        self._o_enhancer:       Any | None = None
        self._o_summarizer:     Any | None = None
        self._o_flow_selector:  Any | None = None
        self._o_episodic:       Any | None = None
        self._o_semantic:       Any | None = None
        self._o_pool:           Any | None = None

    # ── Config fluent methods ─────────────────────────────────────────────────

    def llm(self, config: "LLMConfig") -> "AgentBuilder":
        """
        Configure the primary LLM — used for reasoning, flow selection,
        slot extraction, message enhancement, and conversation summarisation.
        """
        self._llm_cfg = config
        return self

    def script_gen_llm(self, config: "LLMConfig") -> "AgentBuilder":
        """
        Separate LLM used exclusively for script generation inside the
        ToolOrchestrator. Falls back to the primary LLM when not called.
        """
        self._sg_llm_cfg = config
        return self

    def embeddings(
        self,
        model_id: str = "BAAI/bge-small-en-v1.5",
        cache_dir: str = "",
        tokenizer_only: bool = False,
        force_rebuild: bool = False,
    ) -> "AgentBuilder":
        """
        Configure and automatically set up embeddings.

        Local embeddings run directly in Rust using the Hugging Face model name.
        No ONNX export is used. The model/tokenizer are downloaded to a cache
        directory and then reused.

        ── Model ──────────────────────────────────────────────────────────────
        model_id      HuggingFace model ID.
                      Default "BAAI/bge-small-en-v1.5" (384-dim, recommended).

                      If you change this, also update vector_size in .memory()
                      to match the model's output dimension:
                        384-dim  BAAI/bge-small-en-v1.5  (default)
                                 sentence-transformers/all-MiniLM-L6-v2
                        768-dim  BAAI/bge-base-en-v1.5
                                 sentence-transformers/all-mpnet-base-v2
                        1024-dim BAAI/bge-large-en-v1.5

        ── Cache directory ────────────────────────────────────────────────────
        cache_dir     Where to cache model and tokenizer files.
                      Default: ~/.jazzmine/models/<model-slug>/
                      Created automatically. Safe to share across agents.

        ── Mode ───────────────────────────────────────────────────────────────
        tokenizer_only
                      False (default) = use local Rust-native embeddings.

                      True = download the tokenizer only.
                      Use this when embedding is handled by a remote API
                      (embed_api_key in .memory()) but BM25 sparse vectors
                      still need a local tokenizer for hybrid search.

        ── Cache ──────────────────────────────────────────────────────────────
        force_rebuild True = re-download model/tokenizer even if files exist.
                      False (default) = skip if cache_dir already contains
                      the expected files (fast startup on second run).

        ── Example — fully local (default) ────────────────────────────────────
            agent, td = await (
                AgentBuilder("Aria", agent_id="...", personality="...")
                .llm(OpenAILLMConfig(...))
                .embeddings()                          # ← auto-download + cache
                .memory(qdrant_url="http://localhost:6334")
                .build()
            )

        ── Example — remote API, local BM25 ───────────────────────────────────
            agent, td = await (
                AgentBuilder("Aria", agent_id="...", personality="...")
                .llm(OpenAILLMConfig(...))
                .embeddings(tokenizer_only=True)       # ← tokenizer for BM25
                .memory(
                    qdrant_url="http://localhost:6334",
                    embed_api_key="sk-...",            # ← remote embeddings
                    embed_provider="openai",
                    vector_size=1536,                  # ← match remote model
                )
                .build()
            )
        """
        self._embed_cfg = EmbeddingConfig(
            model_id=model_id.strip(),
            cache_dir=cache_dir.strip(),
            tokenizer_only=tokenizer_only,
            force_rebuild=force_rebuild,
        )
        return self

    def memory(
        self,
        qdrant_url:               str,
        tokenizer_path:           str       = "",
        tokenizer_model_id:       str|None  = None,
        # Qdrant connection
        collection_prefix:        str       = "jazzmine",
        qdrant_api_key:           str|None  = None,
        # Qdrant collection tuning
        vector_size:              int       = 384,
        distance_metric:          str       = "cosine",
        use_indexing:             bool      = True,
        quantization:             int|None  = 8,
        on_disk:                  bool      = False,
        replication_factor:       int       = 1,
        shard_number:             int       = 1,
        indexing_threshold:       int       = 2000,
        flush_interval_sec:       int       = 15,
        max_optimization_threads: int       = 1,
        use_sparse_vectors:       bool      = True,
        # Local embedding backend
        local_model_id:           str|None  = None,
        local_cache_dir:          str|None  = None,
        max_batch:                int       = 8,
        # Remote embedding backend
        embed_provider:           str       = "openai",
        embed_api_key:            str|None  = None,
        embed_base_url:           str|None  = None,
        embed_model_name:         str|None  = None,
    ) -> "AgentBuilder":
        """
        Enable Qdrant-backed long-term memory (episodic, procedural, semantic).

        When not called, all three memory systems are replaced with no-op stubs
        and the agent runs without persistent memory across conversations.

        tokenizer_path is optional when .embeddings() is called.
        tokenizer_model_id can also be provided to download tokenizer.json
        directly from Hugging Face for BM25 sparse vectors.

        Embedding backend — choose exactly one:
        ──────────────────────────────────────
        AUTO   call .embeddings() before .memory() to have AgentBuilder
               download and configure the embedding backend automatically.
               You usually do not need tokenizer_path/local_model_id manually.

        LOCAL  set local_model_id to a Hugging Face model name.
               Rust downloads/caches model files and runs inference locally.

        REMOTE set embed_api_key (and optionally embed_provider, embed_base_url,
               embed_model_name). tokenizer_path or tokenizer_model_id is still
               needed for BM25. Use .embeddings(tokenizer_only=True) to
               auto-resolve it.
        """
        self._mem_cfg = MemoryConfig(
            qdrant_url               = qdrant_url,
            tokenizer_path           = tokenizer_path,
            tokenizer_model_id       = tokenizer_model_id,
            collection_prefix        = collection_prefix,
            qdrant_api_key           = qdrant_api_key,
            vector_size              = vector_size,
            distance_metric          = distance_metric,
            use_indexing             = use_indexing,
            quantization             = quantization,
            on_disk                  = on_disk,
            replication_factor       = replication_factor,
            shard_number             = shard_number,
            indexing_threshold       = indexing_threshold,
            flush_interval_sec       = flush_interval_sec,
            max_optimization_threads = max_optimization_threads,
            use_sparse_vectors       = use_sparse_vectors,
            local_model_id           = local_model_id,
            local_cache_dir          = local_cache_dir,
            max_batch                = max_batch,
            embed_provider           = embed_provider,
            embed_api_key            = embed_api_key,
            embed_base_url           = embed_base_url,
            embed_model_name         = embed_model_name,
        )
        return self

    def storage(self, config: StorageConfig) -> "AgentBuilder":
        """
        Set the MessageStore backend.

        Pass one of the typed storage config objects:
            .storage(JsonStorage(path="./store.json"))
            .storage(PostgresStorage(dsn="postgresql://user:pass@host/db"))
            .storage(MongoDBStorage(uri="mongodb://localhost:27017", db="jazzmine"))

        Defaults to JsonStorage() with an auto-created temp file if not called.
        """
        self._storage_cfg = config
        return self

    def sandbox(
        self,
        name:             str,
        python_version:   str                        = "3.11",
        cpu_quota:        float                      = 0.5,
        memory_mb:        int                        = 256,
        memory_swap_mb:   int                        = -1,
        pids_limit:       int                        = 64,
        timeout_sec:      int                        = 30,
        max_output_bytes: int                        = 1_048_576,
        scratch_size_mb:  int                        = 128,
        pool_size:        int                        = 1,
        allowed_hosts:    list[str]                  | None = None,
        allowed_ports:    dict[str, list[int]]       | None = None,
        default_port:     int                        = 443,
        file_mounts:      list["FileMount"]          | None = None,
        secrets:          dict[str, str]             | None = None,
        pip_packages:     list[str]                  | None = None,
        execution_mode:   str                        = "plan",
    ) -> "AgentBuilder":
        """Register a sandbox environment. Call multiple times for multiple sandboxes."""
        self._sandbox_specs.append(SandboxSpec(
            name             = name,
            python_version   = python_version,
            cpu_quota        = cpu_quota,
            memory_mb        = memory_mb,
            memory_swap_mb   = memory_swap_mb,
            pids_limit       = pids_limit,
            timeout_sec      = timeout_sec,
            max_output_bytes = max_output_bytes,
            scratch_size_mb  = scratch_size_mb,
            pool_size        = pool_size,
            allowed_hosts    = allowed_hosts or [],
            allowed_ports    = allowed_ports or {},
            default_port     = default_port,
            file_mounts      = file_mounts or [],
            secrets          = secrets or {},
            pip_packages     = pip_packages or [],
            execution_mode   = execution_mode,
        ))
        return self

    def flows(self, flows: list[Any]) -> "AgentBuilder":
        """
        Register flow definitions.

        Important: hold a strong reference to the returned flows list in
        your calling scope. BaseFlow.registry uses a WeakValueDictionary.
        """
        self._flows = list(flows)
        return self

    def domain_terms(self, terms: list[DomainTerm]) -> "AgentBuilder":
        """
        Seed semantic memory with domain-specific jargon and abbreviations.

        Each term is a tuple: (key, value, category, aliases, description).
        """
        self._domain_terms = list(terms)
        return self

    def settings(self, **kwargs) -> "AgentBuilder":
        """Override any AgentSettings field by name."""
        for k, v in kwargs.items():
            if not hasattr(self._settings, k):
                raise ConfigError(
                    f"Unknown settings field: {k!r}. "
                    f"Valid fields: {sorted(vars(self._settings).keys())}"
                )
            setattr(self._settings, k, v)
        return self

    def version(self, version: str) -> "AgentBuilder":
        """Set a human-friendly agent version shown in the startup display."""
        self._version = version.strip()
        return self

    def on_intermediate(self, callback: Callable) -> "AgentBuilder":
        """Register a callback invoked on each sandbox intermediate event."""
        self._on_intermediate = callback
        return self

    def logging(self, config: dict) -> "AgentBuilder":
        """
        Configure structured logging for the agent.

        Accepts a jazzmine-logging config dict. When called, every turn emits
        structured JSON events to the configured sinks with a correlation trace_id.
        """
        self._logging_cfg = config
        return self

    def security(self, config: "SecurityConfig") -> "AgentBuilder":
        """
        Enable the SecurityGuard for this agent.

        Pass a SecurityConfig instance with your chosen components:

            from jazzmine.security import JazzmineInputModerator, JazzmineOutputModerator
            from jazzmine.core.builder import SecurityConfig

            # Default models from HuggingFace Hub
            agent, teardown = await (
                AgentBuilder(...)
                .llm(...)
                .security(SecurityConfig(
                    input_moderator  = JazzmineInputModerator(),
                    output_moderator = JazzmineOutputModerator(),
                ))
                .build()
            )

            # Toxicity detector instead of input moderator (mutually exclusive)
            from jazzmine.security import JazzmineToxicityDetector
            .security(SecurityConfig(
                toxicity_detector = JazzmineToxicityDetector(threshold=0.6),
                output_moderator  = JazzmineOutputModerator(),
            ))

            # Custom thresholds and messages
            .security(SecurityConfig(
                input_moderator             = JazzmineInputModerator(),
                input_confidence_threshold  = 0.7,
                input_block_message         = "Your message could not be processed.",
                moderation_timeout          = 5.0,
                fail_open                   = False,   # high-security: raise on error
            ))

            # Custom BaseModerator subclass
            .security(SecurityConfig(input_moderator=MyCustomModerator()))

        Components overview:
          input_moderator     HF transformer on user input (MUTUALLY EXCLUSIVE with
                              toxicity_detector — ConfigError if both are set).
          toxicity_detector   XGBoost feature-based detector on user input.
          output_moderator    HF transformer on the agent's generated response.
          file_sanitizer      Not used in chat() — exposed as agent.security.sanitizer
                              for callers to run on uploaded files manually.

        Behaviour when triggered:
          • User input blocked   → user message flagged in the store, turn returns
                                   AgentTurnResult with response=input_block_message
                                   and is_blocked=True. No LLM call is made.
          • Output blocked       → assistant response discarded, turn returns
                                   AgentTurnResult with response=output_block_message
                                   and is_blocked=True. Message is NOT stored.
          • Moderation error     → fail_open=True  (default) → continue as safe.
                                   fail_open=False → exception propagates to caller.

        When .security() is not called, the agent runs with NOOP_GUARD — all
        has_*_gate properties return False and zero overhead is incurred.
        """
        self._sec_cfg = config
        return self

    def server(self, config: "ServerConfig") -> "AgentBuilder":
        """
        Attach a FastAPI / uvicorn HTTP server to the agent.

        The server is started automatically at the end of build() and shut down
        gracefully as part of the Teardown sequence (before agent.drain()).

        The running server is accessible via builder.agent_server after build()
        returns. This is useful for integration tests that need the effective
        bound port.

        Endpoints created
        ─────────────────
          POST  {chat_endpoint}         Full chat turn (waits for complete response).
          POST  {chat_endpoint}/stream  Same, streamed as Server-Sent Events.
          GET   {health_endpoint}       Liveness probe — always returns 200 OK.
          GET   {info_endpoint}         Agent metadata (name, ID, capabilities).
          GET   /                       Redirects to docs or /info.

        Authentication
        ──────────────
        Set ServerConfig.api_key to require Bearer-token auth on every endpoint.
        When None (default) all requests are accepted without authentication.

        Requires:
            pip install "fastapi[standard]" uvicorn[standard] pydantic
        """
        self._server_cfg = config
        return self

    @property
    def agent_server(self) -> "AgentServer | None":
        """
        The running AgentServer instance, available after build() returns.
        None if .server() was not called.

        Useful in tests to inspect the effective bound port:
            builder = AgentBuilder(...)
            agent, td = await builder.server(ServerConfig(port=0)).build()
            port = builder.agent_server.effective_port
        """
        return self._agent_server

    # ── Escape hatches — inject pre-built instances ───────────────────────────

    def with_llm(self, llm: Any)                 -> "AgentBuilder": self._o_llm           = llm; return self
    def with_script_gen_llm(self, llm: Any)      -> "AgentBuilder": self._o_sg_llm        = llm; return self
    def with_message_store(self, s: Any)          -> "AgentBuilder": self._o_msg_store     = s;   return self
    def with_wm_store(self, s: Any)               -> "AgentBuilder": self._o_wm_store      = s;   return self

    def redis_wm(
        self,
        redis_client: Any,
        ttl_seconds:  int = 3600,
    ) -> "AgentBuilder":
        """Use Redis-backed working memory instead of the default in-process store."""
        from jazzmine.core.working_memory import RedisWorkingMemoryStore
        self._o_wm_store = RedisWorkingMemoryStore(
            redis_client=redis_client,
            ttl_seconds=ttl_seconds,
        )
        return self

    def with_registry(self, r: Any)               -> "AgentBuilder": self._o_registry      = r;   return self
    def with_enhancer(self, e: Any)               -> "AgentBuilder": self._o_enhancer      = e;   return self
    def with_summarizer(self, s: Any)             -> "AgentBuilder": self._o_summarizer    = s;   return self
    def with_flow_selector(self, s: Any)          -> "AgentBuilder": self._o_flow_selector = s;   return self
    def with_episodic_memory(self, m: Any)        -> "AgentBuilder": self._o_episodic      = m;   return self
    def with_semantic_memory(self, m: Any)        -> "AgentBuilder": self._o_semantic      = m;   return self
    def with_pool(self, p: Any)                   -> "AgentBuilder": self._o_pool          = p;   return self

    # ══════════════════════════════════════════════════════════════════════════
    # Validation
    # ══════════════════════════════════════════════════════════════════════════

    def _validate(self) -> None:
        """
        Synchronous config validation — called at the very start of build()
        before any connections are opened. Raises ConfigError with a clear
        message describing every problem found.
        """
        errors: list[str] = []

        # LLM required
        if self._o_llm is None and self._llm_cfg is None:
            errors.append(
                "No LLM configured. Call .llm(<ProviderLLMConfig(...)>) "
                "or .with_llm(instance)."
            )

        _validate_llm_cfg(self._llm_cfg, "llm", errors)
        _validate_llm_cfg(self._sg_llm_cfg, "script_gen_llm", errors)

        # ── Embedding config ───────────────────────────────────────────────────
        self._validate_embed_cfg(errors)

        # ── Memory config ──────────────────────────────────────────────────────
        if self._mem_cfg is not None:
            m = self._mem_cfg
            # tokenizer source: required UNLESS .embeddings() will resolve it
            has_tokenizer_path = bool(m.tokenizer_path.strip())
            has_tokenizer_model = bool((m.tokenizer_model_id or "").strip())
            if not has_tokenizer_path and not has_tokenizer_model and self._embed_cfg is None:
                errors.append(
                    "memory requires a tokenizer source for BM25. "
                    "Set tokenizer_path= or tokenizer_model_id= in .memory(), "
                    "or call .embeddings() to resolve it automatically."
                )
            if m.vector_size < 1:
                errors.append(f"memory.vector_size {m.vector_size!r} must be >= 1.")

            # Embedding backend consistency
            has_local     = bool(m.local_model_id)
            has_remote    = bool(m.embed_api_key)
            has_auto      = self._embed_cfg is not None

            if not has_auto:
                # Manual mode: exactly one backend must be set
                if not has_local and not has_remote:
                    errors.append(
                        "memory: no embedding backend configured. Options:\n"
                        "  • Call .embeddings() for automatic local setup.\n"
                        "  • Set local_model_id in .memory() for manual local setup.\n"
                        "  • Set embed_api_key in .memory() for a remote API."
                    )
                if has_local and has_remote:
                    errors.append(
                        "memory: set either local_model_id (local Rust model) or "
                        "embed_api_key (remote API), not both."
                    )
            else:
                # Auto mode: validate consistency with embed_cfg
                embed_is_local = not self._embed_cfg.tokenizer_only
                if embed_is_local and has_remote:
                    errors.append(
                        "Conflict: .embeddings(tokenizer_only=False) sets up local embeddings "
                        "but embed_api_key is also set in .memory(). "
                        "Use .embeddings(tokenizer_only=True) when using a remote API, "
                        "or remove embed_api_key to use local embeddings."
                    )
                if not embed_is_local and not has_remote:
                    errors.append(
                        ".embeddings(tokenizer_only=True) requires embed_api_key in "
                        ".memory() — the remote embedding provider must be specified."
                    )
                if has_local:
                    errors.append(
                        "Do not set local_model_id in .memory() when .embeddings() is "
                        "also called — local model is resolved automatically."
                    )

            # Qdrant tuning
            if not m.qdrant_url.strip():
                errors.append("memory.qdrant_url cannot be empty.")
            if m.quantization is not None and m.quantization not in (4, 8):
                errors.append(
                    f"memory.quantization must be None, 4, or 8 (got {m.quantization!r})."
                )
            if m.distance_metric not in ("cosine", "euclidean", "dot"):
                errors.append(
                    f"memory.distance_metric {m.distance_metric!r} must be "
                    "'cosine', 'euclidean', or 'dot'."
                )
            if m.replication_factor < 1:
                errors.append("memory.replication_factor must be >= 1.")
            if m.shard_number < 1:
                errors.append("memory.shard_number must be >= 1.")
            if m.indexing_threshold < 1:
                errors.append("memory.indexing_threshold must be >= 1.")
            if m.flush_interval_sec < 1:
                errors.append("memory.flush_interval_sec must be >= 1.")
            if m.max_optimization_threads < 0:
                errors.append("memory.max_optimization_threads must be >= 0.")
            if m.max_batch < 2:
                errors.append(
                    f"memory.max_batch must be >= 2 (got {m.max_batch!r}). "
                    "The batcher thread needs at least 2 slots."
                )
            # Remote-specific validation
            if has_remote:
                valid_providers = {
                    "openai", "azure", "azure_openai", "gemini", "google",
                    "cohere", "huggingface", "hf", "mistral", "together",
                    "togetherai", "voyage", "voyageai", "jina", "jinaai",
                    "nomic", "openrouter", "deepinfra",
                }
                if m.embed_provider.lower() not in valid_providers:
                    errors.append(
                        f"memory.embed_provider {m.embed_provider!r} is not recognised. "
                        f"Valid values: {sorted(valid_providers)}"
                    )

        # ── Storage config ─────────────────────────────────────────────────────
        cfg = self._storage_cfg
        if isinstance(cfg, PostgresStorage):
            if not cfg.dsn.strip():
                errors.append("storage.dsn cannot be empty for PostgresStorage.")
            if cfg.pool_min < 1:
                errors.append(f"storage.pool_min {cfg.pool_min!r} must be >= 1.")
            if cfg.pool_max < cfg.pool_min:
                errors.append(
                    f"storage.pool_max {cfg.pool_max!r} must be >= pool_min {cfg.pool_min!r}."
                )
        elif isinstance(cfg, MongoDBStorage):
            if not cfg.uri.strip():
                errors.append("storage.uri cannot be empty for MongoDBStorage.")
            if not cfg.db.strip():
                errors.append("storage.db cannot be empty for MongoDBStorage.")

        # ── Sandbox specs ──────────────────────────────────────────────────────
        seen_names: set[str] = set()
        for spec in self._sandbox_specs:
            n = spec.name or "<unnamed>"
            if not spec.name.strip():
                errors.append("sandbox name cannot be empty.")
            elif spec.name in seen_names:
                errors.append(f"Duplicate sandbox name: {spec.name!r}.")
            else:
                seen_names.add(spec.name)
            if spec.memory_mb < 64:
                errors.append(f"sandbox {n!r}: memory_mb must be >= 64 (got {spec.memory_mb}).")
            if spec.memory_swap_mb != -1 and spec.memory_swap_mb <= spec.memory_mb:
                errors.append(
                    f"sandbox {n!r}: memory_swap_mb ({spec.memory_swap_mb}) must be "
                    f"> memory_mb ({spec.memory_mb}) or -1 for unlimited."
                )
            if spec.pids_limit < 1:
                errors.append(f"sandbox {n!r}: pids_limit must be >= 1 (got {spec.pids_limit}).")
            if spec.timeout_sec < 1:
                errors.append(f"sandbox {n!r}: timeout_sec must be >= 1 (got {spec.timeout_sec}).")
            if spec.max_output_bytes < 1024:
                errors.append(
                    f"sandbox {n!r}: max_output_bytes must be >= 1024 "
                    f"(got {spec.max_output_bytes})."
                )
            if spec.cpu_quota <= 0:
                errors.append(f"sandbox {n!r}: cpu_quota must be > 0 (got {spec.cpu_quota}).")
            if spec.pool_size < 1:
                errors.append(f"sandbox {n!r}: pool_size must be >= 1 (got {spec.pool_size}).")
            if spec.scratch_size_mb < 16:
                errors.append(
                    f"sandbox {n!r}: scratch_size_mb must be >= 16 "
                    f"(got {spec.scratch_size_mb})."
                )
            if spec.default_port < 1 or spec.default_port > 65535:
                errors.append(
                    f"sandbox {n!r}: default_port {spec.default_port} out of range [1, 65535]."
                )
            for host, ports in spec.allowed_ports.items():
                for port in ports:
                    if port < 1 or port > 65535:
                        errors.append(
                            f"sandbox {n!r}: allowed_ports[{host!r}] contains "
                            f"invalid port {port}."
                        )
            for fm in spec.file_mounts:
                if not fm.host_path.strip():
                    errors.append(f"sandbox {n!r}: FileMount.host_path cannot be empty.")
                if not fm.container_path.strip():
                    errors.append(f"sandbox {n!r}: FileMount.container_path cannot be empty.")
            for pkg in spec.pip_packages:
                if not pkg.strip():
                    errors.append(f"sandbox {n!r}: pip_packages contains a blank entry.")
            if spec.execution_mode not in ("plan", "interactive"):
                errors.append(
                    f"sandbox {n!r}: execution_mode {spec.execution_mode!r} must be "
                    f"'plan' or 'interactive'."
                )

        # ── Settings ───────────────────────────────────────────────────────────
        s = self._settings
        if s.default_execution_mode not in ("plan", "interactive"):
            errors.append(
                f"settings.default_execution_mode {s.default_execution_mode!r} must be "
                f"'plan' or 'interactive'."
            )
        if s.max_task_calls_per_turn < 1:
            errors.append("settings.max_task_calls_per_turn must be >= 1.")
        if s.max_interactive_steps < 1:
            errors.append("settings.max_interactive_steps must be >= 1.")
        if s.max_retries < 1:
            errors.append("settings.max_retries must be >= 1.")
        if s.enhancer_history_window < 2:
            errors.append(
                f"settings.enhancer_history_window must be >= 2 "
                f"(got {s.enhancer_history_window})."
            )
        if s.summarizer_trigger < 1:
            errors.append("settings.summarizer_trigger must be >= 1.")
        if s.episode_overlap >= s.max_episode_size:
            errors.append(
                f"settings.episode_overlap ({s.episode_overlap}) must be < "
                f"max_episode_size ({s.max_episode_size})."
            )
        if s.min_episode_size < 1:
            errors.append("settings.min_episode_size must be >= 1.")
        if s.flow_top_k < 1:
            errors.append("settings.flow_top_k must be >= 1.")
        if s.pool_max_overflow < 0:
            errors.append(
                f"settings.pool_max_overflow must be >= 0 (got {s.pool_max_overflow})."
            )

        # ── Domain terms shape ─────────────────────────────────────────────────
        for i, term in enumerate(self._domain_terms):
            if not isinstance(term, (list, tuple)) or len(term) != 5:
                errors.append(
                    f"domain_terms[{i}] must be a 5-tuple "
                    f"(key, value, category, aliases, description). Got: {term!r}"
                )

        # ── Security config ────────────────────────────────────────────────────
        if self._sec_cfg is not None:
            sc = self._sec_cfg

            # Mutual exclusivity: input_moderator XOR toxicity_detector
            if sc.input_moderator is not None and sc.toxicity_detector is not None:
                errors.append(
                    "security: input_moderator and toxicity_detector are mutually "
                    "exclusive. Set one or the other, not both. "
                    "input_moderator uses a HuggingFace transformer; "
                    "toxicity_detector uses XGBoost + feature pipeline."
                )

            # BaseModerator interface check
            for attr, label in [
                (sc.input_moderator,  "input_moderator"),
                (sc.output_moderator, "output_moderator"),
            ]:
                if attr is not None and not callable(getattr(attr, "classify", None)):
                    errors.append(
                        f"security.{label} must be a BaseModerator subclass instance "
                        f"(has a .classify(text) method). Got: {type(attr).__name__}"
                    )

            # Toxicity detector interface check
            if sc.toxicity_detector is not None:
                if not callable(getattr(sc.toxicity_detector, "predict", None)):
                    errors.append(
                        "security.toxicity_detector must have a .predict(text) method. "
                        f"Got: {type(sc.toxicity_detector).__name__}"
                    )

            # File sanitizer interface check
            if sc.file_sanitizer is not None:
                if not callable(getattr(sc.file_sanitizer, "sanitize", None)):
                    errors.append(
                        "security.file_sanitizer must be a BaseSanitizer subclass "
                        f"instance (has a .sanitize() method). Got: {type(sc.file_sanitizer).__name__}"
                    )

            # Threshold ranges
            if not (0.0 <= sc.input_confidence_threshold <= 1.0):
                errors.append(
                    f"security.input_confidence_threshold must be in [0.0, 1.0] "
                    f"(got {sc.input_confidence_threshold!r})."
                )
            if not (0.0 <= sc.output_confidence_threshold <= 1.0):
                errors.append(
                    f"security.output_confidence_threshold must be in [0.0, 1.0] "
                    f"(got {sc.output_confidence_threshold!r})."
                )
            if sc.moderation_timeout <= 0:
                errors.append(
                    f"security.moderation_timeout must be > 0 "
                    f"(got {sc.moderation_timeout!r})."
                )

            # Block messages must be non-empty strings
            if not sc.input_block_message.strip():
                errors.append("security.input_block_message cannot be empty.")
            if not sc.output_block_message.strip():
                errors.append("security.output_block_message cannot be empty.")

        # ── Server config ────────────────────────────────────────────────────
        self._validate_server_cfg(errors)

        if errors:
            bullet = "\n  • ".join(errors)
            raise ConfigError(f"AgentBuilder validation failed:\n  • {bullet}")

    def _validate_server_cfg(self, errors: list[str]) -> None:
        """
        Validate ServerConfig — called from _validate() before any I/O.
        All errors are appended to `errors` so they surface as a single
        ConfigError alongside any other validation failures.
        """
        cfg = self._server_cfg
        if cfg is None:
            return

        # Port
        if not (1 <= cfg.port <= 65_535):
            errors.append(
                f"server.port {cfg.port!r} must be in the range 1 - 65535."
            )

        # Host
        if not cfg.host.strip():
            errors.append("server.host cannot be empty.")

        # Endpoint paths
        for attr in ("chat_endpoint", "health_endpoint", "info_endpoint"):
            val = getattr(cfg, attr, "")
            if not val.startswith("/"):
                errors.append(
                    f"server.{attr} must start with '/'. Got: {val!r}"
                )

        # Endpoint uniqueness
        paths = [cfg.chat_endpoint, cfg.health_endpoint, cfg.info_endpoint]
        if len(paths) != len(set(paths)):
            errors.append(
                "server.chat_endpoint, health_endpoint, and info_endpoint "
                "must all be distinct paths."
            )

        # /stream suffix collision
        stream_path = cfg.chat_endpoint.rstrip("/") + "/stream"
        if stream_path in paths:
            errors.append(
                f"server: the auto-generated stream path '{stream_path}' "
                "conflicts with another endpoint. Rename chat_endpoint."
            )

        # Request limits
        if cfg.request_timeout <= 0:
            errors.append(
                f"server.request_timeout must be > 0 (got {cfg.request_timeout!r})."
            )
        if cfg.max_message_length < 1:
            errors.append(
                f"server.max_message_length must be >= 1 "
                f"(got {cfg.max_message_length!r})."
            )

        # SSL - must be provided in pairs
        has_cert = bool(cfg.ssl_certfile)
        has_key  = bool(cfg.ssl_keyfile)
        if has_cert != has_key:
            errors.append(
                "server.ssl_certfile and server.ssl_keyfile must both be set "
                "or both be None - you cannot provide only one."
            )
        if has_cert:
            import os
            if not os.path.isfile(cfg.ssl_certfile):
                errors.append(
                    f"server.ssl_certfile {cfg.ssl_certfile!r} does not exist "
                    "or is not a file."
                )
            if not os.path.isfile(cfg.ssl_keyfile):
                errors.append(
                    f"server.ssl_keyfile {cfg.ssl_keyfile!r} does not exist "
                    "or is not a file."
                )

        # Log level
        valid_levels = {"critical", "error", "warning", "info", "debug", "trace"}
        if cfg.log_level.lower() not in valid_levels:
            errors.append(
                f"server.log_level {cfg.log_level!r} is not valid. "
                f"Choose from: {', '.join(sorted(valid_levels))}."
            )

        # Server tuning
        if cfg.backlog < 1:
            errors.append(
                f"server.backlog must be >= 1 (got {cfg.backlog!r})."
            )
        if cfg.timeout_keep_alive < 0:
            errors.append(
                f"server.timeout_keep_alive must be >= 0 "
                f"(got {cfg.timeout_keep_alive!r})."
            )
        if cfg.limit_concurrency is not None and cfg.limit_concurrency < 1:
            errors.append(
                f"server.limit_concurrency must be >= 1 or None "
                f"(got {cfg.limit_concurrency!r})."
            )

        # CORS - credentials + wildcard origin is a browser security error
        cors = cfg.cors
        if cors.allow_credentials and cors.origins == ["*"]:
            errors.append(
                "server.cors: allow_credentials=True is incompatible with "
                "origins=['*']. List the exact origin(s) explicitly, e.g. "
                "origins=['https://app.example.com']."
            )
        if not cors.origins:
            errors.append("server.cors.origins cannot be an empty list.")
        if cfg.api_key is not None and cfg.api_key.strip() == "":
            errors.append(
                "server.api_key cannot be a blank string. "
                "Set it to a non-empty secret or None to disable auth."
            )

    def _validate_embed_cfg(self, errors: list[str]) -> None:
        """Validate EmbeddingConfig independently. Called from _validate()."""
        cfg = self._embed_cfg
        if cfg is None:
            return

        if not cfg.model_id.strip():
            errors.append("embeddings.model_id cannot be empty.")

        if cfg.cache_dir:
            p = Path(cfg.cache_dir)
            if p.exists() and not p.is_dir():
                errors.append(
                    f"embeddings.cache_dir {cfg.cache_dir!r} already exists "
                    "but is a file, not a directory."
                )

        if self._mem_cfg is None and cfg is not None:
            # Warn but don't fail — user might add .memory() later in a subclass
            log.warning(
                ".embeddings() called without .memory() — embedding setup will "
                "run but memory is disabled. Add .memory(qdrant_url=...) to enable it."
            )

    # ══════════════════════════════════════════════════════════════════════════
    # build()
    # ══════════════════════════════════════════════════════════════════════════

    async def build(self) -> tuple[Any, Teardown]:
        """
        Validate config, wire all components, start the pool, populate memory,
        sync flows, and return (Agent, Teardown).

        If .embeddings() was called, downloads/exports the model before memory
        is initialised. Outputs are cached; second run is instant.

        Teardown callbacks fire in LIFO order:
          agent.drain → pool.shutdown → llm.close(s) → store.close → tmp cleanup
        """
        # ── Validation (synchronous, before any I/O) ──────────────────────────
        self._validate()

        td = Teardown()
        s  = self._settings

        _sd = self._startup_display or StartupDisplay(
            agent_name=self._name,
            version=self._version,
        )
        self._startup_display = _sd
        _sd.print_banner()

        async def _sd_done():
            _sd.print_teardown_done()
        td.register(_sd_done)

        _sd._on_build_start()

        # ── Embeddings — resolve tokenizer and model BEFORE memory init ────────
        if self._embed_cfg is not None:
            await self._build_embeddings(_sd)

        # ── LLMs ──────────────────────────────────────────────────────────────
        reasoning_llm  = self._o_llm    or _build_llm(self._llm_cfg)
        script_gen_llm = self._o_sg_llm or (_build_llm(self._sg_llm_cfg) if self._sg_llm_cfg else None)

        td.register(_closer(reasoning_llm))
        if script_gen_llm is not None:
            td.register(_closer(script_gen_llm))

        _llm_label = getattr(self._llm_cfg, "model", "") or "custom"
        _sd.event("Primary LLM", _llm_label)
        if script_gen_llm is not None and self._sg_llm_cfg is not None:
            _sg_label = getattr(self._sg_llm_cfg, "model", "") or "custom"
            _sd.event("Script gen LLM", _sg_label)

        # ── Tool registry ─────────────────────────────────────────────────────
        from jazzmine.core.tools.registry import ToolRegistry
        registry = self._o_registry or ToolRegistry.get_default()

        _n_tools = len(registry.all_tools())
        _n_sandboxes = len(registry.all_sandbox_names())
        _tool_report = self._tool_registry_change_report(registry)
        _sd.event(
            "Tool registry",
            (
                f"{_n_tools} tools · {_n_sandboxes} sandbox(es) "
                f"(created: {_tool_report['created']}, "
                f"updated: {_tool_report['updated']}, "
                f"deleted: {_tool_report['deleted']})"
            ),
        )
        if _tool_report["created_names"] or _tool_report["updated_names"] or _tool_report["deleted_names"]:
            _sd.event(
                "Tool changes",
                (
                    f"created: {','.join(_tool_report['created_names']) or '-'}; "
                    f"updated: {','.join(_tool_report['updated_names']) or '-'}; "
                    f"deleted: {','.join(_tool_report['deleted_names']) or '-'}"
                ),
            )

        # ── Determine has_tools ───────────────────────────────────────────────
        has_tools = bool(self._sandbox_specs) or bool(registry.all_sandbox_names())

        # ── Sandbox pool ──────────────────────────────────────────────────────
        pool = self._o_pool
        if pool is None and has_tools:
            pool = await self._build_pool(registry, td)
            for _spec in self._sandbox_specs:
                _sd.event(
                    "Sandbox pool",
                    f"{_spec.name}  ×{_spec.pool_size} containers",
                )

        # ── Message store ─────────────────────────────────────────────────────
        msg_store = self._o_msg_store or await self._build_message_store(td)

        _store_type = type(self._storage_cfg).__name__.replace("Storage", "")
        _sd.event("Message store", _store_type)

        # ── Working memory ────────────────────────────────────────────────────
        from jazzmine.core.working_memory import InMemoryWorkingMemoryStore
        wm_store = self._o_wm_store or InMemoryWorkingMemoryStore()

        _wm_label = (
            "Redis"
            if type(wm_store).__name__ == "RedisWorkingMemoryStore"
            else "in-process"
        )
        _sd.event("Working memory", _wm_label)

        # ── Long-term memory ──────────────────────────────────────────────────
        episodic, proc_mem, sem_mem = await self._build_memory()
        has_real_memory = not isinstance(episodic, _NoopEpisodicMemory)

        if has_real_memory and self._mem_cfg is not None:
            _qdrant_host = self._mem_cfg.qdrant_url.replace("http://", "").replace("https://", "")
            _sd.event("Long-term memory", f"Qdrant @ {_qdrant_host}")
        else:
            _sd.event("Long-term memory", "disabled", warning=True)

        # ── Domain terms ──────────────────────────────────────────────────────
        if self._domain_terms and has_real_memory:
            _sem_report = await self._sync_domain_terms(sem_mem)
            log.info(
                "Domain terms synced: created=%d updated=%d deleted=%d unchanged=%d",
                _sem_report["created"], _sem_report["updated"],
                _sem_report["deleted"], _sem_report["unchanged"],
            )
            _sd.event(
                "Domain terms",
                (
                    f"created: {_sem_report['created']}, "
                    f"updated: {_sem_report['updated']}, "
                    f"deleted: {_sem_report['deleted']}, "
                    f"unchanged: {_sem_report['unchanged']}"
                ),
            )

        # ── Flow sync ─────────────────────────────────────────────────────────
        if self._flows and has_real_memory and proc_mem is not None:
            from jazzmine.core.flows import sync_registry as _sync
            _flow_report = await _sync(proc_mem, agent_id=self._agent_id, verbose=False)
            log.info(
                "Synced %d flow(s) to Qdrant. created=%d updated=%d deleted=%d skipped=%d",
                len(self._flows),
                len(_flow_report.created), len(_flow_report.updated),
                len(_flow_report.deleted), len(_flow_report.skipped),
            )
            _sd.event(
                "Flows",
                (
                    f"created: {len(_flow_report.created)}, "
                    f"updated: {len(_flow_report.updated)}, "
                    f"deleted: {len(_flow_report.deleted)}, "
                    f"unchanged: {len(_flow_report.skipped)}"
                ),
            )
            if _flow_report.created or _flow_report.updated or _flow_report.deleted:
                def _emit_flow_change_group(group: str, names: list[str]) -> None:
                    chunk_size = 4
                    for i in range(0, len(names), chunk_size):
                        chunk = ", ".join(names[i:i + chunk_size])
                        if i == 0:
                            _sd.event("Flow changes", f"{group}: {chunk}")
                        else:
                            _sd.event("", f"{group} (cont.): {chunk}")

                _emit_flow_change_group("created", sorted(_flow_report.created))
                _emit_flow_change_group("updated", sorted(_flow_report.updated))
                _emit_flow_change_group("deleted", sorted(_flow_report.deleted))
        elif self._flows:
            _sd.event("Flows", f"{len(self._flows)} flows registered")

        # ── Flow selector ─────────────────────────────────────────────────────
        from jazzmine.core.flows import FlowSelector, BaseFlow
        flow_selector = self._o_flow_selector or FlowSelector(
            llm           = reasoning_llm,
            flow_registry = BaseFlow.registry,
            proc_mem      = proc_mem if has_real_memory else None,
            agent_id      = self._agent_id,
            top_k         = s.flow_top_k,
            rrf_k         = s.flow_rrf_k,
        )

        # ── Message enhancer ──────────────────────────────────────────────────
        from jazzmine.core.message_enhancer import MessageEnhancer
        enhancer = self._o_enhancer or MessageEnhancer(
            llm            = reasoning_llm,
            message_store  = msg_store,
            history_window = s.enhancer_history_window,
        )

        # ── Conversation summariser ───────────────────────────────────────────
        from jazzmine.core.conversation_summarizer import ConversationSummarizer
        summarizer = self._o_summarizer or ConversationSummarizer(
            llm              = reasoning_llm,
            episodic_memory  = episodic,
            message_store    = msg_store,
            trigger          = s.summarizer_trigger,
            max_episode_size = s.max_episode_size,
            min_episode_size = s.min_episode_size,
            overlap          = s.episode_overlap,
        )

        # ── AgentConfig ───────────────────────────────────────────────────────
        from jazzmine.core.agent import AgentConfig, build_agent
        from jazzmine.core.tools.sandbox.config import ExecutionMode

        default_sandbox = (
            s.default_sandbox_name
            or (self._sandbox_specs[0].name if self._sandbox_specs
                else next(iter(registry.all_sandbox_names()), "default"))
        )
        exec_mode = (
            ExecutionMode.INTERACTIVE
            if s.default_execution_mode == "interactive"
            else ExecutionMode.PLAN
        )

        config = AgentConfig(
            name                     = self._name,
            personality              = self._personality,
            agent_id                 = self._agent_id,
            has_tools                = has_tools,
            default_sandbox_name     = default_sandbox,
            default_execution_mode   = exec_mode,
            max_task_calls_per_turn  = s.max_task_calls_per_turn,
            max_interactive_steps    = s.max_interactive_steps,
            episodic_same_conv_limit = s.episodic_same_conv_limit,
            episodic_prev_conv_limit = s.episodic_prev_conv_limit,
            semantic_top_k           = s.semantic_top_k,
        )

        # ── Logger ────────────────────────────────────────────────────────────
        if self._logging_cfg is not None:
            _agent_logger = AgentLogger.from_config(
                config     = self._logging_cfg,
                agent_name = self._name.lower().replace(" ", "_"),
            )
            await _agent_logger.start()

            async def _logger_shutdown():
                await _agent_logger.shutdown()

            td.register(_logger_shutdown)
        else:
            _agent_logger = AgentLogger.noop()

        # ── Security guard ────────────────────────────────────────────────────
        from jazzmine.core.security_guard import SecurityGuard, NOOP_GUARD
        if self._sec_cfg is not None:
            sc = self._sec_cfg
            security_guard = SecurityGuard(
                input_moderator             = sc.input_moderator,
                toxicity_detector           = sc.toxicity_detector,
                output_moderator            = sc.output_moderator,
                file_sanitizer              = sc.file_sanitizer,
                input_confidence_threshold  = sc.input_confidence_threshold,
                output_confidence_threshold = sc.output_confidence_threshold,
                input_block_message         = sc.input_block_message,
                output_block_message        = sc.output_block_message,
                moderation_timeout          = sc.moderation_timeout,
                fail_open                   = sc.fail_open,
            )
            # ── Startup display — security section ────────────────────────────
            _sd.section("Security")
            _input_gate = (
                type(sc.input_moderator).__name__  if sc.input_moderator  is not None else
                type(sc.toxicity_detector).__name__ if sc.toxicity_detector is not None else
                None
            )
            if _input_gate:
                _sd.event(
                    "Input gate",
                    f"{_input_gate}  "
                    f"threshold={sc.input_confidence_threshold:.2f}  "
                    f"fail_open={sc.fail_open}",
                )
            else:
                _sd.event("Input gate", "none", warning=True)

            if sc.output_moderator is not None:
                _sd.event(
                    "Output gate",
                    f"{type(sc.output_moderator).__name__}  "
                    f"threshold={sc.output_confidence_threshold:.2f}",
                )
            else:
                _sd.event("Output gate", "none", warning=True)

            if sc.file_sanitizer is not None:
                _sd.event("File sanitizer", type(sc.file_sanitizer).__name__)

            if sc.toxicity_detector is not None and hasattr(sc.toxicity_detector, "threshold"):
                _sd.event(
                    "Detector threshold",
                    f"{sc.toxicity_detector.threshold:.2f}",
                )
        else:
            security_guard = NOOP_GUARD
            _sd.event("Security", "disabled — NOOP_GUARD", warning=True)

        # ── Agent ─────────────────────────────────────────────────────────────
        agent = build_agent(
            config          = config,
            llm             = reasoning_llm,
            script_gen_llm  = script_gen_llm,
            message_store   = msg_store,
            wm_store        = wm_store,
            enhancer        = enhancer,
            episodic_memory = episodic,
            semantic_memory = sem_mem,
            flow_selector   = flow_selector,
            summarizer      = summarizer,
            tool_registry   = registry,
            pool            = pool,
            max_retries     = s.max_retries,
            on_intermediate = self._on_intermediate,
            logger          = _agent_logger,
            security_guard  = security_guard,
        )

        # ── Teardown (registered in dependency order — LIFO on run) ───────────
        async def _drain():
            await agent.drain()
            _sd.teardown_event("Background tasks", "drained")
        td.register(_drain)

        if pool is not None:
            async def _pool_stop():
                await pool.shutdown()
                _sd.teardown_event("Sandbox pool", "stopped")
            td.register(_pool_stop)

        async def _store_close():
            await msg_store.close()
            _sd.teardown_event("Message store", "closed")
        td.register(_store_close)

        # ── HTTP server ───────────────────────────────────────────────────────
        # Registered between _store_close and _sd_start so that teardown
        # LIFO order is: print_teardown_start → stop server → close store
        # → stop pool → drain agent → sd_done.
        if self._server_cfg is not None:
            self._agent_server = await self._build_server(agent, td, _sd)

        async def _sd_start():
            _sd.print_teardown_start()
        td.register(_sd_start)

        log.info(
            "Agent '%s' ready (has_tools=%s, has_memory=%s).",
            self._name, has_tools, has_real_memory,
        )
        _sd._on_build_done()
        _sd.print_ready()
        return agent, td

    # ══════════════════════════════════════════════════════════════════════════
    # Private: embedding model setup
    # ══════════════════════════════════════════════════════════════════════════

    @staticmethod
    def _embed_model_slug(model_id: str) -> str:
        """Normalize Hugging Face model IDs for directory names."""
        return model_id.replace("/", "-")

    @staticmethod
    def _resolve_embed_output_dir(cfg: EmbeddingConfig) -> Path:
        """Return the resolved output directory Path, creating it if needed."""
        if cfg.cache_dir:
            out = Path(cfg.cache_dir)
        else:
            out = _DEFAULT_MODELS_ROOT / AgentBuilder._embed_model_slug(cfg.model_id)
        out.mkdir(parents=True, exist_ok=True)
        return out

    async def _build_embeddings(self, _sd: StartupDisplay) -> None:
        """
        Resolve local cache paths and patch memory config with model/tokenizer IDs.

        This is always called BEFORE _build_memory() so the memory layer sees
        the resolved paths.

        Actual model/tokenizer download is performed by the Rust memory layer.
        """
        cfg = self._embed_cfg
        assert cfg is not None  # guaranteed by build() guard

        slug    = self._embed_model_slug(cfg.model_id)
        out_dir = self._resolve_embed_output_dir(cfg)

        tokenizer_json = out_dir / "tokenizer.json"
        mode_label = "tokenizer only" if cfg.tokenizer_only else "local rust model"

        # ── Cache check ───────────────────────────────────────────────────────
        is_cached = tokenizer_json.exists() and not cfg.force_rebuild

        if is_cached:
            _sd.event(
                "Embeddings",
                f"{cfg.model_id}  [{mode_label}]  (cached)",
            )
            log.info("Embedding model cache hit: %s", out_dir)
        else:
            action = "Preparing tokenizer" if cfg.tokenizer_only else "Preparing local model cache"
            _sd.event("Embeddings", f"{action}  ·  {cfg.model_id}  ...")
            log.info("Embedding cache preparation: model=%s dir=%s", cfg.model_id, out_dir)

            if cfg.force_rebuild and out_dir.exists():
                for item in out_dir.iterdir():
                    if item.is_file():
                        item.unlink()

            _sd.event(
                "Embeddings",
                f"{cfg.model_id}  [{mode_label}]  →  {out_dir}",
            )
            log.info("Embedding model ready: %s", out_dir)

        # ── Patch mem_cfg ─────────────────────────────────────────────────────
        if self._mem_cfg is not None:
            if cfg.tokenizer_only:
                self._mem_cfg.tokenizer_model_id = cfg.model_id
            else:
                self._mem_cfg.local_model_id = cfg.model_id
                self._mem_cfg.tokenizer_model_id = cfg.model_id
            self._mem_cfg.local_cache_dir = str(out_dir)
            if tokenizer_json.exists():
                self._mem_cfg.tokenizer_path = str(tokenizer_json)

        log.debug(
            "Embedding paths resolved: tokenizer=%s local_model_id=%s",
            tokenizer_json,
            cfg.model_id if not cfg.tokenizer_only else "N/A (tokenizer-only)",
        )

    # ══════════════════════════════════════════════════════════════════════════
    # Private helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _tool_registry_change_report(self, registry: Any) -> dict[str, Any]:
        state_path = Path.cwd() / ".jazzmine_tool_registry_state.json"

        current_tools: dict[str, str] = {
            rt.tool.name: rt.checksum for rt in registry.all_tools()
        }
        current_sandboxes: dict[str, str] = {
            name: registry.sandbox_checksum(name) for name in registry.all_sandbox_names()
        }

        previous_tools: dict[str, str] = {}
        previous_sandboxes: dict[str, str] = {}
        try:
            if state_path.exists():
                payload = json.loads(state_path.read_text(encoding="utf-8"))
                previous_tools = dict(payload.get("tools", {}))
                previous_sandboxes = dict(payload.get("sandboxes", {}))
        except Exception:
            pass

        created_names = sorted([k for k in current_tools if k not in previous_tools])
        updated_names = sorted([
            k for k in current_tools
            if k in previous_tools and current_tools[k] != previous_tools[k]
        ])
        deleted_names = sorted([k for k in previous_tools if k not in current_tools])

        sandbox_created = sorted([f"sandbox:{k}" for k in current_sandboxes if k not in previous_sandboxes])
        sandbox_updated = sorted([
            f"sandbox:{k}" for k in current_sandboxes
            if k in previous_sandboxes and current_sandboxes[k] != previous_sandboxes[k]
        ])
        sandbox_deleted = sorted([f"sandbox:{k}" for k in previous_sandboxes if k not in current_sandboxes])

        created_names.extend(sandbox_created)
        updated_names.extend(sandbox_updated)
        deleted_names.extend(sandbox_deleted)

        try:
            state_path.write_text(
                json.dumps(
                    {"tools": current_tools, "sandboxes": current_sandboxes},
                    sort_keys=True, ensure_ascii=True, indent=2,
                ),
                encoding="utf-8",
            )
        except Exception:
            pass

        return {
            "created": len(created_names),
            "updated": len(updated_names),
            "deleted": len(deleted_names),
            "created_names": created_names,
            "updated_names": updated_names,
            "deleted_names": deleted_names,
        }

    def _semantic_term_checksum(
        self, key: str, value: str, category: str,
        aliases: list[str], description: str,
    ) -> str:
        payload = {
            "key": key.strip().lower(),
            "value": value.strip(),
            "category": category.strip(),
            "aliases": sorted([a.strip() for a in aliases]),
            "description": description.strip(),
        }
        canonical = json.dumps(payload, sort_keys=True, ensure_ascii=True)
        return hashlib.sha256(canonical.encode()).hexdigest()[:16]

    async def _sync_domain_terms(self, sem_mem: Any) -> dict[str, int]:
        desired: dict[str, tuple] = {}
        for key, value, category, aliases, description in self._domain_terms:
            desired[key.strip().lower()] = (value, category, aliases, description)

        created = updated = deleted = unchanged = 0

        can_list   = hasattr(sem_mem, "list_all")
        can_forget = hasattr(sem_mem, "forget")

        if not can_list:
            for key, value, category, aliases, description in self._domain_terms:
                await sem_mem.memorize(
                    key=key, value=value, category=category,
                    agent_id=self._agent_id, aliases=aliases, description=description,
                )
            return {"created": 0, "updated": len(self._domain_terms), "deleted": 0, "unchanged": 0}

        existing_rows = await sem_mem.list_all(agent_id=self._agent_id)
        existing: dict[str, dict] = {}
        for row in existing_rows:
            row_key = str(row.get("key", "")).strip().lower()
            if row_key:
                existing[row_key] = row

        for key, (value, category, aliases, description) in desired.items():
            if key not in existing:
                await sem_mem.memorize(
                    key=key, value=value, category=category,
                    agent_id=self._agent_id, aliases=aliases, description=description,
                )
                created += 1
                continue

            row = existing[key]
            old_cs = self._semantic_term_checksum(
                key=row.get("key", ""), value=row.get("value", ""),
                category=row.get("category", ""),
                aliases=list(row.get("aliases", []) or []),
                description=row.get("description", ""),
            )
            new_cs = self._semantic_term_checksum(
                key=key, value=value, category=category,
                aliases=aliases, description=description,
            )

            if old_cs != new_cs:
                await sem_mem.memorize(
                    key=key, value=value, category=category,
                    agent_id=self._agent_id, aliases=aliases, description=description,
                )
                updated += 1
            else:
                unchanged += 1

        if can_forget:
            for key in existing:
                if key not in desired:
                    await sem_mem.forget(key=key, agent_id=self._agent_id)
                    deleted += 1

        return {"created": created, "updated": updated, "deleted": deleted, "unchanged": unchanged}

    async def _build_message_store(self, td: Teardown) -> Any:
        from jazzmine.core.message_store import MessageStore
        cfg = self._storage_cfg

        if isinstance(cfg, JsonStorage) and not cfg.path:
            f = tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w")
            f.write("{}"); f.close()
            _tmp_path = f.name
            cfg = JsonStorage(path=_tmp_path)
            async def _rm_tmp():
                import os
                try: os.unlink(_tmp_path)
                except OSError: pass
            td.register(_rm_tmp)

        return await MessageStore.initialize(cfg.to_init_config())

    async def _build_server(
        self,
        agent: Any,
        td: "Teardown",
        _sd: "StartupDisplay",
    ) -> "AgentServer":
        """
        Instantiate and start the AgentServer, emit startup display events,
        and register a teardown callback to stop it gracefully.

        Called from build() when self._server_cfg is not None.
        """
        import time as _time

        cfg = self._server_cfg
        assert cfg is not None
        t0  = _time.monotonic()

        server = AgentServer(
            agent         = agent,
            config        = cfg,
            agent_version = self._version,
        )

        _sd.section("HTTP Server")

        try:
            await server.start()
        except Exception as exc:
            raise RuntimeError(
                f"AgentServer failed to start on {cfg.host}:{cfg.port}: {exc}"
            ) from exc

        ms = int((_time.monotonic() - t0) * 1000)

        scheme   = "https" if cfg.ssl_certfile else "http"
        base_url = f"{scheme}://{cfg.host}:{server.effective_port}"

        _sd.event("Bind address",    f"{cfg.host}:{server.effective_port}", ms=ms)
        _sd.event("Chat endpoint",   f"POST  {base_url}{cfg.chat_endpoint}")
        _sd.event("Stream endpoint", f"POST  {base_url}{cfg.chat_endpoint}/stream")
        _sd.event("Health endpoint", f"GET   {base_url}{cfg.health_endpoint}")
        _sd.event("Info endpoint",   f"GET   {base_url}{cfg.info_endpoint}")

        if cfg.docs_url:
            _sd.event("Swagger UI",  f"GET   {base_url}{cfg.docs_url}")
        if cfg.redoc_url:
            _sd.event("ReDoc",       f"GET   {base_url}{cfg.redoc_url}")

        auth_status = (
            "Bearer token" if cfg.api_key else "disabled - open access"
        )
        _sd.event(
            "Authentication",
            auth_status,
            warning = (cfg.api_key is None),
        )

        _cors = cfg.cors
        cors_label = (
            "all origins (*)"
            if _cors.origins == ["*"]
            else f"{len(_cors.origins)} origin(s): " + ", ".join(_cors.origins[:3])
            + (" ..." if len(_cors.origins) > 3 else "")
        )
        _sd.event("CORS origins", cors_label)

        if cfg.ssl_certfile:
            _sd.event("TLS", f"{cfg.ssl_certfile}")

        # ── Teardown callback ─────────────────────────────────────────────────
        async def _server_stop() -> None:
            await server.stop()
            _sd.teardown_event("HTTP server", "stopped")

        td.register(_server_stop)

        return server

    async def _build_memory(self) -> tuple[Any, Any, Any]:
        """
        Returns (episodic, proc_mem, sem_mem).

        Paths/model IDs in self._mem_cfg tokenizer/local fields are already
        resolved by _build_embeddings() at this point when .embeddings()
        was called.
        """
        noop_episodic = _NoopEpisodicMemory()
        noop_semantic = _NoopSemanticMemory()

        if self._mem_cfg is None:
            return (
                self._o_episodic or noop_episodic,
                None,
                self._o_semantic or noop_semantic,
            )

        cfg = self._mem_cfg
        try:
            import memory as mem
        except ImportError as exc:
            raise ImportError(
                "The 'memory' Rust extension is required for Qdrant-backed memory. "
                "Install jazzmine-memory or omit .memory() to run without it."
            ) from exc

        qdrant = mem.QdrantManager(
            cfg.qdrant_url,
            cfg.vector_size,
            use_indexing             = cfg.use_indexing,
            quantization             = cfg.quantization,
            on_disk                  = cfg.on_disk,
            api_key                  = cfg.qdrant_api_key,
            distance_metric          = cfg.distance_metric,
            collection_prefix        = cfg.collection_prefix,
            replication_factor       = cfg.replication_factor,
            shard_number             = cfg.shard_number,
            indexing_threshold       = cfg.indexing_threshold,
            flush_interval_sec       = cfg.flush_interval_sec,
            max_optimization_threads = cfg.max_optimization_threads,
            use_sparse_vectors       = cfg.use_sparse_vectors,
        )
        await qdrant.ensure_conversation_summaries_collection()
        await qdrant.ensure_flows_collection()
        await qdrant.ensure_semantic_collection()

        embed_kwargs: dict = dict(
            hidden_size = cfg.vector_size,
            max_batch   = cfg.max_batch,
        )
        tokenizer_model_id = cfg.tokenizer_model_id or cfg.local_model_id or cfg.embed_model_name
        if cfg.local_model_id is not None:
            embed_kwargs["local_model_id"] = cfg.local_model_id
            if cfg.local_cache_dir:
                embed_kwargs["local_cache_dir"] = cfg.local_cache_dir
        else:
            embed_kwargs["api_key"]  = cfg.embed_api_key
            embed_kwargs["provider"] = cfg.embed_provider
            if cfg.embed_base_url:
                embed_kwargs["base_url"]   = cfg.embed_base_url
            if cfg.embed_model_name:
                embed_kwargs["model_name"] = cfg.embed_model_name

        if tokenizer_model_id:
            embed_kwargs["tokenizer_model_id"] = tokenizer_model_id

        episodic = self._o_episodic or mem.EpisodicMemory(
            qdrant, cfg.tokenizer_path, **embed_kwargs
        )
        proc_mem = mem.ProceduralMemory(
            qdrant, cfg.tokenizer_path, **embed_kwargs
        )
        sem_mem  = self._o_semantic or mem.SemanticMemory(
            qdrant,
            cfg.tokenizer_path,
            tokenizer_model_id=tokenizer_model_id,
            cache_dir=cfg.local_cache_dir,
        )
        return episodic, proc_mem, sem_mem

    async def _build_pool(self, registry: Any, td: Teardown) -> Any:
        from jazzmine.core.tools.sandbox.config import (
            SandboxConfig, ResourceLimits, NetworkPolicy, ExecutionMode,
        )
        from jazzmine.core.tools.sandbox.builder import SandboxBuilder
        from jazzmine.core.tools.sandbox.pool   import SandboxPool

        all_secrets: dict[str, str] = {}
        spec = None  # kept for pool kwargs below

        for spec in self._sandbox_specs:
            sc = SandboxConfig(
                name            = spec.name,
                python_version  = spec.python_version,
                dependencies    = spec.pip_packages,
                resource_limits = ResourceLimits(
                    cpu_quota             = spec.cpu_quota,
                    memory_mb             = spec.memory_mb,
                    memory_swap_mb        = spec.memory_swap_mb,
                    pids_limit            = spec.pids_limit,
                    execution_timeout_sec = spec.timeout_sec,
                    max_output_bytes      = spec.max_output_bytes,
                ),
                network_policy  = NetworkPolicy(
                    allowed_hosts = spec.allowed_hosts,
                    allowed_ports = spec.allowed_ports,
                    default_port  = spec.default_port,
                ),
                resources       = [fm.to_file_resource() for fm in spec.file_mounts],
                secrets         = list(spec.secrets.keys()),
                execution_mode  = (
                    ExecutionMode.INTERACTIVE
                    if spec.execution_mode == "interactive"
                    else ExecutionMode.PLAN
                ),
                pool_size       = spec.pool_size,
                scratch_size_mb = spec.scratch_size_mb,
            )
            registry.register_sandbox(config=sc)
            all_secrets.update(spec.secrets)

        builder = SandboxBuilder(registry)
        pool    = SandboxPool(
            registry      = registry,
            builder       = builder,
            secrets       = all_secrets,
            max_overflow  = spec.pool_max_overflow if spec else 10,
            host_path_map = spec.pool_host_path_map or None if spec else None,
        )

        names = [spec.name for spec in self._sandbox_specs] or None
        await pool.startup(sandbox_names=names)
        log.info(
            "Sandbox pool started: %s",
            ", ".join(spec.name for spec in self._sandbox_specs),
        )
        return pool