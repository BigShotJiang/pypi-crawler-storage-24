from __future__ import annotations

class _NoopEpisodicMemory:
    """
    Satisfies the EpisodicMemory interface when Qdrant is not configured.
    ConversationSummarizer calls memorize(); Agent calls recall().
    Both are harmless no-ops — the agent simply has no cross-turn recall.
    """
    async def recall(self, *a, **kw) -> dict:
        # Match EpisodicMemory.recall() shape expected by Agent._chat_inner.
        return {
            "same_conversation": [],
            "previous_conversations": [],
        }
    async def memorize(self, *a, **kw) -> None: pass


class _NoopSemanticMemory:
    """
    Satisfies the SemanticMemory interface when Qdrant is not configured.
    Agent calls recall() per turn for domain terms.
    """
    async def recall(self, *a, **kw)   -> list: return []
    async def memorize(self, *a, **kw) -> None: pass


# ══════════════════════════════════════════════════════════════════════════════
