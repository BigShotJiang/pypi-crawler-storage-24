"""
tool_registry.py
────────────────
@tool decorator and ToolRegistry.

Usage:

    from jazzmine.core.tools.tool_registry import tool, ToolRegistry
    from jazzmine.core.tools.tool_types import ToolParameter, ToolResponse

    @tool(
        description="Search the web for current information.",
        parameters=[
            ToolParameter("query",    "str",  description="Search query",  required=True),
            ToolParameter("max_results", "int", default=5),
        ],
        dependencies=["httpx"],
        secrets=["SEARCH_API_KEY"],
        sandbox="default",
    )
    async def search_web(query: str, max_results: int = 5) -> ToolResponse:
        ...

The decorated function can still be called normally from the host (e.g. in tests).
The decorator registers it in the module-level ToolRegistry, extracts its source
for injection into the container, and computes a checksum to detect stale images.
"""

from __future__ import annotations

import ast
import functools
import hashlib
import inspect
import textwrap
from typing import Any, Callable, Dict, List, Optional

from jazzmine.core.tools.types import Tool, ToolParameter, ToolResponse
from jazzmine.core.tools.sandbox.config import SandboxConfig


# ── Registered tool record ─────────────────────────────────────────────────────

class RegisteredTool:
    """Everything the system needs to know about one tool."""

    def __init__(
        self,
        tool:          Tool,
        fn:            Callable,
        source:        str,
        dependencies:  List[str],
        secrets:       List[str],
        sandbox_name:  str,
    ):
        self.tool         = tool
        self.fn           = fn
        self.source       = source
        self.dependencies = dependencies
        self.secrets      = secrets
        self.sandbox_name = sandbox_name
        self.checksum     = self._compute_checksum()

    def _compute_checksum(self) -> str:
        content = self.source + "|".join(sorted(self.dependencies))
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    def __repr__(self) -> str:
        return (
            f"<RegisteredTool name={self.tool.name!r} "
            f"sandbox={self.sandbox_name!r} checksum={self.checksum}>"
        )


# ── Source extraction helpers ──────────────────────────────────────────────────

def _extract_source(fn: Callable) -> str:
    """
    Extract the raw source of a function, strip indentation, and validate
    that it is syntactically valid Python before registration.

    Decorator lines (@tool(...)) are stripped so that comments or whitespace
    differences on the decorator line don't change the checksum and trigger
    unnecessary image rebuilds.

    Raises ValueError at decoration time — fail fast, not at execution time.
    """
    try:
        raw = inspect.getsource(fn)
    except (OSError, TypeError) as e:
        raise ValueError(
            f"Cannot extract source for '{fn.__name__}': {e}. "
            "Functions defined in interactive sessions (REPL, Jupyter) "
            "or via exec() cannot be used as tools."
        ) from e

    source = textwrap.dedent(raw)

    # Strip leading decorator lines so @tool(...) comments don't affect checksum
    lines = source.splitlines()
    first_def = next(
        (i for i, l in enumerate(lines)
         if l.lstrip().startswith("def ") or l.lstrip().startswith("async def ")),
        0,
    )
    source = "\n".join(lines[first_def:])

    # Validate syntax immediately — catch errors before image build
    try:
        ast.parse(source)
    except SyntaxError as e:
        raise ValueError(
            f"Syntax error in tool '{fn.__name__}': {e}"
        ) from e

    return source


def _validate_return_type(fn: Callable, name: str) -> None:
    """
    Warn if the function does not have a ToolResponse return annotation.
    This is not enforced (some tools return plain dicts) but strongly suggested.
    """
    hints = fn.__annotations__
    ret   = hints.get("return")
    if ret is not None and getattr(ret, "__name__", None) != "ToolResponse":
        import warnings
        warnings.warn(
            f"Tool '{name}' has return annotation '{ret}' instead of ToolResponse. "
            "The container executor expects ToolResponse-compatible objects.",
            stacklevel=4,
        )


# ── ToolRegistry ───────────────────────────────────────────────────────────────

class ToolRegistry:
    """
    Singleton registry that stores all @tool-decorated functions.

    Access via the module-level `registry` instance, or inject a fresh
    ToolRegistry() for testing.
    """

    def __init__(self) -> None:
        self._tools:    Dict[str, RegisteredTool] = {}
        self._sandboxes: Dict[str, SandboxConfig] = {}

    # ── Registration ──────────────────────────────────────────────────────────

    def register(self, registered: RegisteredTool) -> None:
        name = registered.tool.name
        if name in self._tools:
            existing = self._tools[name]
            if existing.checksum != registered.checksum:
                # Updated definition — replace silently
                self._tools[name] = registered
            # Identical checksum — no-op
        else:
            self._tools[name] = registered

    def register_sandbox(self, config: SandboxConfig) -> None:
        """
        Register a sandbox configuration.
        Call this before decorating tools that reference this sandbox by name.
        """
        self._sandboxes[config.name] = config

    # ── Lookup ────────────────────────────────────────────────────────────────

    def get(self, name: str) -> Optional[RegisteredTool]:
        return self._tools.get(name)

    def get_sandbox(self, name: str) -> Optional[SandboxConfig]:
        return self._sandboxes.get(name)

    def tools_for_sandbox(self, sandbox_name: str) -> List[RegisteredTool]:
        return [t for t in self._tools.values() if t.sandbox_name == sandbox_name]

    def all_tools(self) -> List[RegisteredTool]:
        return list(self._tools.values())

    def all_sandbox_names(self) -> List[str]:
        """Return all sandbox names that have at least one tool registered."""
        return list({t.sandbox_name for t in self._tools.values()})

    # ── Dependency aggregation ─────────────────────────────────────────────────

    def aggregate_dependencies(self, sandbox_name: str) -> List[str]:
        """
        Merge sandbox-level deps + all tool deps for a given sandbox.
        Result is deduplicated and stable-sorted for deterministic image builds.
        """
        sandbox = self._sandboxes.get(sandbox_name)
        base    = sandbox.dependencies if sandbox else []

        tool_deps: List[str] = []
        for t in self.tools_for_sandbox(sandbox_name):
            tool_deps.extend(t.dependencies)

        return list(dict.fromkeys(base + tool_deps))

    def aggregate_secrets(self, sandbox_name: str) -> List[str]:
        """All secret names required by any tool in the sandbox."""
        sandbox = self._sandboxes.get(sandbox_name)
        base    = sandbox.secrets if sandbox else []

        tool_secrets: List[str] = []
        for t in self.tools_for_sandbox(sandbox_name):
            tool_secrets.extend(t.secrets)

        return list(dict.fromkeys(base + tool_secrets))

    # ── Checksum ──────────────────────────────────────────────────────────────

    def sandbox_checksum(self, sandbox_name: str) -> str:
        """
        Checksum over all tool sources + deps for a sandbox.
        Changes when any tool in the sandbox is updated — triggers image rebuild.
        """
        tools = sorted(
            self.tools_for_sandbox(sandbox_name),
            key=lambda t: t.tool.name,
        )
        content = "|".join(f"{t.tool.name}:{t.checksum}" for t in tools)
        content += "|deps:" + ",".join(self.aggregate_dependencies(sandbox_name))
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    # ── Prompt building ───────────────────────────────────────────────────────

    def build_tools_prompt(self, sandbox_name: Optional[str] = None) -> str:
        """
        Build the XML tools block injected into the agent's system prompt.
        Optionally filtered to a single sandbox.
        """
        tools = (
            self.tools_for_sandbox(sandbox_name)
            if sandbox_name
            else self.all_tools()
        )
        blocks = [t.tool.build_prompt() for t in sorted(tools, key=lambda t: t.tool.name)]
        return "\n\n".join(blocks)
    
    @classmethod
    def get_default(cls) -> "ToolRegistry":
        """Return the module-level singleton registry instance."""
        import sys
        return sys.modules[__name__].registry


    def __repr__(self) -> str:
        return (
            f"<ToolRegistry tools={list(self._tools.keys())} "
            f"sandboxes={list(self._sandboxes.keys())}>"
        )


# ── Module-level singleton ─────────────────────────────────────────────────────

registry = ToolRegistry()

# Register the default sandbox so tools with no explicit sandbox assignment work
registry.register_sandbox(SandboxConfig.default("default"))


# ── @tool decorator ────────────────────────────────────────────────────────────

def tool(
    description:  str,
    parameters:   Optional[List[ToolParameter]] = None,
    dependencies: Optional[List[str]]           = None,
    secrets:      Optional[List[str]]           = None,
    sandbox:      str                           = "default",
    name:         Optional[str]                 = None,
    _registry:    ToolRegistry                  = registry,
) -> Callable:
    """
    Decorator that registers a function as an agent-callable tool.

    Parameters
    ----------
    description  : What the tool does. Shown to the agent in the tools prompt.
    parameters   : List of ToolParameter objects describing the function's args.
    dependencies : pip packages this tool requires inside the container.
    secrets      : Names of environment variables this tool needs (e.g. ["STRIPE_KEY"]).
    sandbox      : Which sandbox to run this tool in. Must be registered first.
    name         : Override the tool name (defaults to function.__name__).

    Notes
    -----
    - The function MUST be defined at module level (not inside another function)
      so that inspect.getsource() can reliably extract its source.
    - The function can still be called normally from the host for testing.
    - Both sync and async functions are supported. Inside the container, async
      tools are called with asyncio.run() automatically.
    """
    def decorator(fn: Callable) -> Callable:
        tool_name = name or fn.__name__

        _validate_return_type(fn, tool_name)
        source = _extract_source(fn)

        tool_obj = Tool(
            name        = tool_name,
            description = description,
            parameters  = parameters or [],
        )

        registered = RegisteredTool(
            tool         = tool_obj,
            fn           = fn,
            source       = source,
            dependencies = dependencies or [],
            secrets      = secrets or [],
            sandbox_name = sandbox,
        )

        _registry.register(registered)

        @functools.wraps(fn)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            return await fn(*args, **kwargs)

        @functools.wraps(fn)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            return fn(*args, **kwargs)

        wrapper = async_wrapper if inspect.iscoroutinefunction(fn) else sync_wrapper
        wrapper._registered_tool = registered  # type: ignore[attr-defined]
        return wrapper

    return decorator