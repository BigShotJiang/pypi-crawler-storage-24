"""
tool_orchestrator.py
────────────────────
Top-level orchestrator.

PLAN mode:        full script generated upfront, retried on failure.
INTERACTIVE mode: one step at a time, each step retried independently.

Every execution produces a RunRecord attached to ToolExecutionResult.run_record.
The caller is responsible for persisting it — the orchestrator only builds it.

Logging
───────
The orchestrator emits two structured events per attempt via AgentLogger:
  script_generated  — after the LLM produces a script body (win or AST fail)
  script_executed   — after the container runs the script (win or runtime fail)

Because agent.chat() binds correlation fields (trace_id, conversation_id,
user_id, turn) via structlog.contextvars before calling the orchestrator,
all of these events carry those fields automatically — no parameter passing.

RunRecord hierarchy
───────────────────
RunRecord
  run_id        — unique ID for this execution
  sandbox_name
  mode          — "plan" | "interactive"
  task
  started_at    — unix timestamp
  finished_at   — unix timestamp
  success
  final_data
  error
  total_ms
  total_prompt_tokens      — sum across all script-generation LLM calls
  total_completion_tokens  — sum across all script-generation LLM calls

  plan mode:
    attempts: List[AttemptRecord]
      attempt               — 1-based counter
      script                — full assembled script (preamble + LLM body + postamble)
      ast_violations        — list of violation strings (empty if passed)
      success
      final_data
      intermediates
      logs
      error
      traceback
      duration_ms           — container execution time
      generation_latency_ms — time spent waiting for the LLM to generate the script
      prompt_tokens         — tokens in the generation prompt
      completion_tokens     — tokens in the generated script body
      model                 — LLM model string used for this generation call

  interactive mode:
    steps: List[StepRecord]
      step          — 1-based step number
      attempts: List[AttemptRecord]  (same as above, one per retry)
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Coroutine, Dict, List, Optional, TYPE_CHECKING

from jazzmine.core.tools.sandbox.config import ExecutionMode
from jazzmine.core.tools.sandbox.pool import SandboxPool
from jazzmine.core.tools.executor import ExecutionResult, IntermediateCallback, ScriptExecutor
from jazzmine.core.tools.generator import ScriptGenerator
from jazzmine.core.tools.registry import ToolRegistry

if TYPE_CHECKING:
    from jazzmine.core.agent.agent_logger import AgentLogger

log = logging.getLogger(__name__)


# ── LLM call result ────────────────────────────────────────────────────────────

@dataclass
class LLMCallResult:
    """
    Return value from LLMCaller.  Carries the generated text alongside
    usage and timing so the orchestrator can record telemetry without
    any extra API calls.
    """
    text:              str
    prompt_tokens:     int   = 0
    completion_tokens: int   = 0
    total_tokens:      int   = 0
    latency_ms:        int   = 0
    model:             str   = ""


# ── Record types ───────────────────────────────────────────────────────────────

@dataclass
class AttemptRecord:
    """One script generation + execution attempt."""
    attempt_id:            str
    attempt:               int
    script:                str
    ast_violations:        List[str]               = field(default_factory=list)
    success:               Optional[bool]          = None
    final_data:            Optional[Any]           = None
    intermediates:         List[Dict[str, Any]]    = field(default_factory=list)
    logs:                  List[Dict[str, str]]    = field(default_factory=list)
    error:                 Optional[str]           = None
    traceback:             Optional[str]           = None
    duration_ms:           int                     = 0
    generation_latency_ms: int                     = 0
    prompt_tokens:         int                     = 0
    completion_tokens:     int                     = 0
    model:                 str                     = ""


@dataclass
class StepRecord:
    """One interactive step, which may have been retried multiple times."""
    step_id:  str
    step:     int
    attempts: List[AttemptRecord] = field(default_factory=list)

    @property
    def final_attempt(self) -> Optional[AttemptRecord]:
        return self.attempts[-1] if self.attempts else None

    @property
    def succeeded(self) -> bool:
        return bool(self.final_attempt and self.final_attempt.success)


@dataclass
class RunRecord:
    """Complete record of one orchestrator.execute() or execute_interactive() call."""
    run_id:                  str
    sandbox_name:            str
    mode:                    str
    task:                    str
    started_at:              float
    finished_at:             float                     = 0.0
    success:                 bool                      = False
    final_data:              Optional[Any]             = None
    error:                   Optional[str]             = None
    total_ms:                int                       = 0
    total_prompt_tokens:     int                       = 0
    total_completion_tokens: int                       = 0
    attempts:                List[AttemptRecord]       = field(default_factory=list)
    steps:                   List[StepRecord]          = field(default_factory=list)

    @property
    def all_scripts(self) -> List[str]:
        if self.mode == "plan":
            return [a.script for a in self.attempts]
        return [a.script for step in self.steps for a in step.attempts]

    @property
    def total_attempts(self) -> int:
        if self.mode == "plan":
            return len(self.attempts)
        return sum(len(s.attempts) for s in self.steps)

    def _all_attempts(self) -> List[AttemptRecord]:
        if self.mode == "plan":
            return list(self.attempts)
        return [a for s in self.steps for a in s.attempts]

    def last_traceback(self) -> Optional[str]:
        for a in reversed(self._all_attempts()):
            if a.traceback:
                return a.traceback
        return None


# ── ToolExecutionResult ────────────────────────────────────────────────────────

@dataclass
class ToolExecutionResult:
    success:       bool
    final_data:    Optional[Any]            = None
    intermediates: List[Dict[str, Any]]     = field(default_factory=list)
    logs:          List[Dict[str, str]]     = field(default_factory=list)
    error:         Optional[str]            = None
    attempts:      int                      = 0
    total_ms:      int                      = 0
    sandbox_name:  str                      = "default"
    run_record:    Optional[RunRecord]      = None

    def to_agent_context(self) -> str:
        run_id = self.run_record.run_id if self.run_record else "unknown"
        if self.success:
            data_str = json.dumps(self.final_data, indent=2, default=str)
            parts = [
                f'<tool_execution success="true" attempts="{self.attempts}" '
                f'ms="{self.total_ms}" run_id="{run_id}">',
                "  <r>", f"    {data_str}", "  </r>",
            ]
            if self.intermediates:
                parts.append("  <intermediates>")
                for i, item in enumerate(self.intermediates, 1):
                    parts.append(f'    <step index="{i}" label="{item["label"]}">')
                    parts.append(f'      {json.dumps(item["data"], default=str)}')
                    parts.append("    </step>")
                parts.append("  </intermediates>")
            parts.append("</tool_execution>")
            return "\n".join(parts)
        return (
            f'<tool_execution success="false" attempts="{self.attempts}" '
            f'ms="{self.total_ms}" run_id="{run_id}">\n'
            f"  <e>{self.error}</e>\n"
            f"</tool_execution>"
        )


LLMCaller = Callable[[str], Coroutine[Any, Any, LLMCallResult]]


# ── ToolOrchestrator ───────────────────────────────────────────────────────────

class ToolOrchestrator:

    def __init__(
        self,
        registry:        ToolRegistry,
        pool:            SandboxPool,
        llm_call:        LLMCaller,
        max_retries:     int                             = 3,
        on_intermediate: Optional[IntermediateCallback] = None,
        logger:          "Optional[AgentLogger]"        = None,  
    ) -> None:
        self._registry        = registry
        self._pool            = pool
        self._llm_call        = llm_call
        self._max_retries     = max_retries
        self._on_intermediate = on_intermediate
        self._logger          = logger  # (may be None — all calls are guarded)
        self._generator       = ScriptGenerator(registry)

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _log_script_generated(
        self,
        sandbox:           str,
        attempt:           int,
        call_result:       LLMCallResult,
        ast_violations:    List[str],
    ) -> None:
        """Emit script_generated event if a logger is configured."""
        if self._logger is None:
            return
        self._logger.script_generated(
            sandbox           = sandbox,
            attempt           = attempt,
            prompt_tokens     = call_result.prompt_tokens,
            completion_tokens = call_result.completion_tokens,
            latency_ms        = call_result.latency_ms,
            model             = call_result.model,
            ast_violations    = ast_violations or None,
        )

    def _log_script_executed(
        self,
        sandbox:     str,
        attempt:     int,
        result:      ExecutionResult,
    ) -> None:
        """Emit script_executed event if a logger is configured."""
        if self._logger is None:
            return
        result_keys = (
            list(result.final_data.keys())
            if isinstance(result.final_data, dict)
            else None
        )
        self._logger.script_executed(
            sandbox     = sandbox,
            attempt     = attempt,
            success     = result.success,
            duration_ms = result.duration_ms,
            error       = result.error,
            result_keys = result_keys,
        )

    # ── PLAN mode ──────────────────────────────────────────────────────────────

    async def execute(
        self,
        task:          str,
        sandbox_name:  str                      = "default",
        extra_context: Optional[Dict[str, Any]] = None,
    ) -> ToolExecutionResult:
        config = self._registry.get_sandbox(sandbox_name)
        if config is None:
            return ToolExecutionResult(
                success=False,
                error=f"No sandbox registered with name '{sandbox_name}'",
                sandbox_name=sandbox_name,
            )

        t_start    = time.monotonic()
        run_record = RunRecord(
            run_id       = str(uuid.uuid4()),
            sandbox_name = sandbox_name,
            mode         = "plan",
            task         = task,
            started_at   = time.time(),
        )

        all_intermediates: List[Dict[str, Any]] = []
        all_logs:          List[Dict[str, str]] = []
        previous_script:   Optional[str]        = None
        previous_error:    Optional[str]        = None

        for attempt_num in range(1, self._max_retries + 2):
            log.info(
                "Script generation attempt %d/%d for task: %.60r",
                attempt_num, self._max_retries + 1, task,
            )

            prompt = self._generator.build_prompt(
                task            = task,
                sandbox_name    = sandbox_name,
                previous_script = previous_script,
                previous_error  = previous_error,
                attempt         = attempt_num,
            )

            # ── LLM generation ────────────────────────────────────────────────
            try:
                call_result: LLMCallResult = await self._llm_call(prompt)
            except Exception as exc:
                _finalise(run_record, False, None,
                          f"LLM script generation failed: {exc}", t_start)
                return _make_result(run_record, all_intermediates, all_logs,
                                    attempt_num, sandbox_name)

            body        = call_result.text
            full_script = self._generator.assemble_script(body, sandbox_name)
            previous_script = full_script

            run_record.total_prompt_tokens     += call_result.prompt_tokens
            run_record.total_completion_tokens += call_result.completion_tokens

            attempt_record = AttemptRecord(
                attempt_id            = str(uuid.uuid4()),
                attempt               = attempt_num,
                script                = full_script,
                generation_latency_ms = call_result.latency_ms,
                prompt_tokens         = call_result.prompt_tokens,
                completion_tokens     = call_result.completion_tokens,
                model                 = call_result.model,
            )
            run_record.attempts.append(attempt_record)

            # ── AST validation ─────────────────────────────────────────────────
            violations = self._generator.validate(full_script, sandbox_name)
            self._log_script_generated(sandbox_name, attempt_num, call_result, violations)

            if violations:
                previous_error = self._generator.validation_error_message(violations)
                log.warning("AST validation failed (attempt %d): %s", attempt_num, violations)
                attempt_record.ast_violations = violations
                attempt_record.success        = False
                attempt_record.error          = previous_error
                if attempt_num > self._max_retries:
                    _finalise(run_record, False, None, previous_error, t_start)
                    return _make_result(run_record, all_intermediates, all_logs,
                                        attempt_num, sandbox_name)
                continue

            # ── Execute ───────────────────────────────────────────────────────
            executor = ScriptExecutor(
                limits          = config.resource_limits,
                mode            = config.execution_mode,
                on_intermediate = self._on_intermediate,
            )
            async with self._pool.checkout(sandbox_name) as container:
                result: ExecutionResult = await executor.run(
                    container        = container,
                    script           = full_script,
                    required_secrets = self._registry.aggregate_secrets(sandbox_name),
                )

            self._log_script_executed(sandbox_name, attempt_num, result)

            attempt_record.success       = result.success
            attempt_record.final_data    = result.final_data
            attempt_record.intermediates = result.intermediates
            attempt_record.logs          = result.logs
            attempt_record.error         = result.error
            attempt_record.traceback     = result.traceback
            attempt_record.duration_ms   = result.duration_ms

            all_intermediates.extend(result.intermediates)
            all_logs.extend(result.logs)

            if result.success:
                _finalise(run_record, True, result.final_data, None, t_start)
                return _make_result(run_record, all_intermediates, all_logs,
                                    attempt_num, sandbox_name)

            error_parts = [result.error or "Unknown execution error"]
            if result.traceback:
                error_parts.append(f"\nTraceback:\n{result.traceback}")
            previous_error = "\n".join(error_parts)
            log.warning("Script execution failed (attempt %d): %r", attempt_num, result.error)
            if attempt_num > self._max_retries:
                break

        _finalise(run_record, False, None,
                  f"All {self._max_retries + 1} attempts failed. "
                  f"Last error: {previous_error}", t_start)
        return _make_result(run_record, all_intermediates, all_logs,
                            self._max_retries + 1, sandbox_name)

    # ── INTERACTIVE mode ───────────────────────────────────────────────────────

    async def execute_interactive(
        self,
        task:         str,
        sandbox_name: str = "default",
        max_steps:    int = 10,
    ) -> ToolExecutionResult:
        config = self._registry.get_sandbox(sandbox_name)
        if config is None:
            return ToolExecutionResult(
                success=False, error=f"No sandbox '{sandbox_name}'",
                sandbox_name=sandbox_name,
            )

        t_start    = time.monotonic()
        run_record = RunRecord(
            run_id       = str(uuid.uuid4()),
            sandbox_name = sandbox_name,
            mode         = "interactive",
            task         = task,
            started_at   = time.time(),
        )

        all_intermediates: List[Dict[str, Any]] = []
        all_logs:          List[Dict[str, str]] = []
        step_history:      List[Dict[str, Any]] = []
        required_secrets   = self._registry.aggregate_secrets(sandbox_name)

        executor = ScriptExecutor(
            limits          = config.resource_limits,
            mode            = ExecutionMode.INTERACTIVE,
            on_intermediate = self._on_intermediate,
        )

        async with self._pool.checkout(sandbox_name) as container:

            for step_num in range(1, max_steps + 1):
                step_record = StepRecord(
                    step_id = str(uuid.uuid4()),
                    step    = step_num,
                )
                run_record.steps.append(step_record)

                step_previous_script: Optional[str] = None
                step_previous_error:  Optional[str] = None

                force_finish = _detect_loop(step_history)
                if force_finish:
                    log.warning(
                        "Step %d: loop detected (last 2 steps identical). "
                        "Forcing emit_result() this step.", step_num,
                    )

                for attempt_num in range(1, self._max_retries + 2):
                    step_prompt = self._build_interactive_prompt(
                        task            = task,
                        sandbox_name    = sandbox_name,
                        step            = step_num,
                        max_steps       = max_steps,
                        history         = step_history,
                        previous_script = step_previous_script,
                        previous_error  = step_previous_error,
                        attempt         = attempt_num,
                        force_finish    = force_finish,
                    )

                    # ── LLM generation ────────────────────────────────────────
                    try:
                        call_result: LLMCallResult = await self._llm_call(step_prompt)
                    except Exception as exc:
                        _finalise(run_record, False, None,
                                  f"LLM call failed on step {step_num} attempt {attempt_num}: {exc}",
                                  t_start)
                        return _make_result(run_record, all_intermediates, all_logs,
                                            step_num, sandbox_name)

                    body = call_result.text
                    run_record.total_prompt_tokens     += call_result.prompt_tokens
                    run_record.total_completion_tokens += call_result.completion_tokens

                    step_script = self._generator.assemble_script(body, sandbox_name)

                    if force_finish:
                        collected = {
                            k: v
                            for h in step_history if not h["error"]
                            for k, v in h["result"].items()
                        }
                        collected_assignment = (
                            f"collected = {json.dumps(collected, default=str)}\n"
                        )
                        step_script = step_script.replace(
                            "# ─────────────────────────────────────────────────────────────────────────────\n\n",
                            "# ─────────────────────────────────────────────────────────────────────────────\n\n"
                            + collected_assignment,
                            1,
                        )

                    step_previous_script = step_script

                    attempt_record = AttemptRecord(
                        attempt_id            = str(uuid.uuid4()),
                        attempt               = attempt_num,
                        script                = step_script,
                        generation_latency_ms = call_result.latency_ms,
                        prompt_tokens         = call_result.prompt_tokens,
                        completion_tokens     = call_result.completion_tokens,
                        model                 = call_result.model,
                    )
                    step_record.attempts.append(attempt_record)

                    # ── AST validation ─────────────────────────────────────────
                    violations = self._generator.validate(step_script, sandbox_name)
                    self._log_script_generated(sandbox_name, attempt_num, call_result, violations)

                    if violations:
                        step_previous_error = self._generator.validation_error_message(violations)
                        log.warning(
                            "Step %d attempt %d AST violations: %s",
                            step_num, attempt_num, violations,
                        )
                        attempt_record.ast_violations = violations
                        attempt_record.success        = False
                        attempt_record.error          = step_previous_error
                        if attempt_num > self._max_retries:
                            _finalise(run_record, False, None, step_previous_error, t_start)
                            return _make_result(run_record, all_intermediates, all_logs,
                                                step_num, sandbox_name)
                        continue

                    # ── Execute ───────────────────────────────────────────────
                    result = await executor.run(
                        container        = container,
                        script           = step_script,
                        required_secrets = required_secrets,
                        execution_id     = (
                            f"step-{step_num}-attempt-{attempt_num}-{uuid.uuid4().hex[:8]}"
                        ),
                    )

                    self._log_script_executed(sandbox_name, attempt_num, result)

                    attempt_record.success       = result.success
                    attempt_record.final_data    = result.final_data
                    attempt_record.intermediates = result.intermediates
                    attempt_record.logs          = result.logs
                    attempt_record.error         = result.error
                    attempt_record.traceback     = result.traceback
                    attempt_record.duration_ms   = result.duration_ms

                    all_intermediates.extend(result.intermediates)
                    all_logs.extend(result.logs)

                    if result.success:
                        if result.final_data is not None:
                            _finalise(run_record, True, result.final_data, None, t_start)
                            return _make_result(run_record, all_intermediates, all_logs,
                                                step_num, sandbox_name)

                        if not result.intermediates:
                            step_previous_error = (
                                "The script ran without errors but produced no output. "
                                "It called a tool but never called emit_intermediate() "
                                "or emit_result(), so the result was silently discarded.\n\n"
                                "You MUST:\n"
                                "  1. Assign the tool return value:  r = tool_name(...)\n"
                                "  2. Check success:                 if not r.success: emit_result({'error': r.message})\n"
                                "  3. Extract from .data:            value = r.data['key']\n"
                                "  4. Emit something:                emit_intermediate('label', value)\n"
                                "                              OR    emit_result({'answer': value})\n\n"
                                "A script that calls a tool without capturing or emitting "
                                "its result makes zero progress."
                            )
                            log.warning(
                                "Step %d attempt %d: script produced no output. Retrying.",
                                step_num, attempt_num,
                            )
                            attempt_record.success = False
                            attempt_record.error   = step_previous_error

                            if attempt_num > self._max_retries:
                                _finalise(run_record, False, None,
                                          f"Step {step_num} failed after {attempt_num} attempt(s): "
                                          f"{step_previous_error}", t_start)
                                return _make_result(run_record, all_intermediates, all_logs,
                                                    step_num, sandbox_name)
                            continue

                        step_result_summary = {
                            item["label"]: item["data"]
                            for item in result.intermediates
                        }
                        step_history.append({
                            "step":   step_num,
                            "result": step_result_summary,
                            "error":  None,
                        })
                        log.info("Step %d complete: %s", step_num, step_result_summary)
                        break

                    # Step execution failed
                    error_parts = [result.error or "Unknown execution error"]
                    if result.traceback:
                        error_parts.append(f"\nTraceback:\n{result.traceback}")
                    step_previous_error = "\n".join(error_parts)
                    log.warning(
                        "Step %d attempt %d failed: %r",
                        step_num, attempt_num, result.error,
                    )

                    if attempt_num > self._max_retries:
                        step_history.append({
                            "step":   step_num,
                            "result": None,
                            "error":  step_previous_error,
                        })
                        _finalise(run_record, False, None,
                                  f"Step {step_num} failed after {attempt_num} attempt(s). "
                                  f"Last error: {step_previous_error}", t_start)
                        return _make_result(run_record, all_intermediates, all_logs,
                                            step_num, sandbox_name)

        _finalise(run_record, False, None,
                  f"Reached max_steps={max_steps} without a final result", t_start)
        return _make_result(run_record, all_intermediates, all_logs,
                            max_steps, sandbox_name)

    # ── Interactive prompt ─────────────────────────────────────────────────────

    def _build_interactive_prompt(
        self,
        task:            str,
        sandbox_name:    str,
        step:            int,
        max_steps:       int,
        history:         List[Dict[str, Any]],
        previous_script: Optional[str] = None,
        previous_error:  Optional[str] = None,
        attempt:         int           = 1,
        force_finish:    bool          = False,
    ) -> str:
        tools_prompt = self._generator._get_tools_prompt(sandbox_name)

        history_block = ""
        if history:
            lines = ["\nCOLLECTED DATA FROM PREVIOUS STEPS"]
            for h in history:
                if h["error"]:
                    lines.append(f"Step {h['step']}: FAILED — {h['error']}")
                else:
                    lines.append(f"Step {h['step']}: {json.dumps(h['result'], default=str)}")
            lines.append("Do NOT re-fetch data already shown above.")
            history_block = "\n".join(lines)

        retry_block = ""
        if attempt > 1 and previous_script and previous_error:
            retry_block = (
                f"\nPREVIOUS ATTEMPT FAILED\nScript:\n{previous_script}\n"
                f"Error:\n{previous_error}\nFix the error.\n"
            )

        if force_finish:
            collected = {
                k: v
                for h in history if not h["error"]
                for k, v in h["result"].items()
            }
            collected_json = json.dumps(collected, indent=2, default=str)
            return (
                f"Interactive session — step {step}/{max_steps}. LOOP DETECTED.\n"
                "You already have all the data. Do NOT call any more tools.\n\n"
                f"TASK: {task}\n\n"
                f"ALL COLLECTED DATA:\n{collected_json}\n\n"
                "The dict above is available as `collected` in your script.\n"
                f"collected = {collected_json}\n\n"
                "Write a script that calls emit_result({{...}}) using only `collected`. No tool calls.\n"
            )

        has_data = any(h for h in history if not h["error"] and h["result"])
        answer_reminder = ""
        if has_data:
            answer_reminder = (
                "\nIf COLLECTED DATA already answers the task, "
                "call emit_result() directly — no more tool calls needed.\n"
            )

        return (
            f"Interactive session — step {step}/{max_steps} (attempt {attempt}).\n"
            "Write ONE script. It runs. You see the result. Then write the NEXT script.\n"
            "Use tools only for NEW data. When you have enough, call emit_result().\n\n"
            f"TASK: {task}\n"
            f"{history_block}\n"
            f"{answer_reminder}\n"
            f"{retry_block}\n"
            "RULES\n"
            "1. Script body only — no markdown, no imports, no code fences.\n"
            "2. No forbidden calls: exec, eval, compile, open, __import__, exit, input.\n"
            "3. Tool returns .success (bool), .message (str), .data (dict). Check .success first.\n"
            "4. .data[\"key\"] gives the list/value — never .data[0]. Index the list: items = r.data[\"key\"]; items[0].\n"
            "5. Never hardcode assumptions about tool output — emit intermediate results and inspect them in the next step.\n"
            "6. End with EXACTLY ONE of:\n"
            "   emit_intermediate(label, value) — more steps needed.\n"
            "   emit_result(dict)               — task fully complete.\n"
            "7. Do NOT repeat tool calls for data already in COLLECTED DATA.\n\n"
            f"AVAILABLE TOOLS\n{tools_prompt}\n"
        )


# ── Helpers ────────────────────────────────────────────────────────────────────

def _detect_loop(history: List[Dict[str, Any]], window: int = 2) -> bool:
    successful = [h for h in history if not h["error"] and h["result"]]
    if len(successful) < window:
        return False
    last      = successful[-window:]
    serialised = [json.dumps(h["result"], sort_keys=True) for h in last]
    return len(set(serialised)) == 1


def _finalise(
    record:     RunRecord,
    success:    bool,
    final_data: Optional[Any],
    error:      Optional[str],
    t_start:    float,
) -> None:
    record.success     = success
    record.final_data  = final_data
    record.error       = error
    record.finished_at = time.time()
    record.total_ms    = _ms(t_start)


def _make_result(
    record:            RunRecord,
    all_intermediates: List[Dict[str, Any]],
    all_logs:          List[Dict[str, str]],
    attempts:          int,
    sandbox_name:      str,
) -> ToolExecutionResult:
    return ToolExecutionResult(
        success        = record.success,
        final_data     = record.final_data,
        intermediates  = all_intermediates,
        logs           = all_logs,
        error          = record.error,
        attempts       = attempts,
        total_ms       = record.total_ms,
        sandbox_name   = sandbox_name,
        run_record     = record,
    )


def _ms(t_start: float) -> int:
    return int((time.monotonic() - t_start) * 1000)