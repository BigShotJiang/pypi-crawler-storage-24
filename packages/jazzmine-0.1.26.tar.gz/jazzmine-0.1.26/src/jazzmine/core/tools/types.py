"""
tool_types.py
─────────────
Core tool type definitions.
These are the user-facing classes for defining tools, their parameters, and responses.
This file mirrors what the user already has — included here so the package is self-contained.
"""

from typing import Optional, List, Any, Literal


class ToolParameter:

    def __init__(self, name: str, type: str, description: Optional[str] = None,
                 default: Optional[Any] = None, required: bool = False,
                 options: Optional[List[Any]] = None, examples: Optional[List[Any]] = None,
                 source: Literal['context', 'history', 'all'] = 'all',
                 display_name: Optional[str] = None):
        self.name         = name
        self.type         = type
        self.description  = description
        self.default      = default
        self.required     = required
        self.options      = options
        self.examples     = examples
        self.source       = source
        self.display_name = display_name

    def to_dict(self) -> dict:
        return {
            "name":         self.name,
            "type":         self.type,
            "description":  self.description,
            "default":      self.default,
            "required":     self.required,
            "options":      self.options,
            "examples":     self.examples,
            "source":       self.source,
            "display_name": self.display_name,
        }

    def build_prompt(self) -> str:
        prompt_parts = [
            f'<parameter name="{self.name}" type="{self.type}" required="{self.required}">',
        ]
        if self.description:
            prompt_parts += [
                '  <description>',
                f'    {self.description}',
                '  </description>', '',
            ]
        if self.default is not None:
            prompt_parts += [
                '  <default>',
                '  <!-- Use ONLY when no user input is provided -->',
                f'    {self.default}',
                '  </default>', '',
            ]
        if self.options:
            prompt_parts += ['  <options>', '  <!-- Choose ONLY from these options -->']
            for opt in self.options:
                prompt_parts.append(f'    <option>{opt}</option>')
            prompt_parts += ['  </options>', '']
        if self.examples:
            prompt_parts += ['  <examples>']
            for ex in self.examples:
                prompt_parts.append(f'    <example>{ex}</example>')
            prompt_parts += ['  </examples>', '']
        if self.source:
            prompt_parts += [
                f'  <source>{self.source}</source>',
            ]
            if self.display_name:
                prompt_parts += [
                    f'  <display_name>{self.display_name}</display_name>', '',
                ]
        prompt_parts.append('</parameter>')
        return '\n'.join(prompt_parts)


class ToolResponse:

    def __init__(self, success: bool, message: Optional[str] = None,
                 data: Optional[Any] = None):
        self.success = success
        self.message = message
        self.data    = data

    def to_dict(self) -> dict:
        return {"success": self.success, "message": self.message, "data": self.data}

    def build_prompt(self) -> str:
        parts = [f'<tool_response success="{self.success}">']
        if self.message:
            parts += [
                '  <message>',
                f'    {self.message}',
                '  </message>', '',
            ]
        if self.data:
            parts += [
                '  <data>',
                f'    {self.data}',
                '  </data>', '',
            ]
        parts.append('</tool_response>')
        return '\n'.join(parts)


class Tool:

    def __init__(self, name: str, description: str,
                 parameters: Optional[List[ToolParameter]] = None):
        self.name        = name
        self.description = description
        self.parameters  = parameters or []

    def to_dict(self) -> dict:
        return {
            "name":        self.name,
            "description": self.description,
            "parameters":  [p.to_dict() for p in self.parameters],
        }

    def build_prompt(self) -> str:
        parts = [
            f'<tool name="{self.name}">',
            '  <description>',
            f'    {self.description}',
            '  </description>', '',
        ]
        if self.parameters:
            parts.append('  <parameters>')
            for param in self.parameters:
                for line in param.build_prompt().split('\n'):
                    parts.append('    ' + line)
                parts.append('')
            parts.append('  </parameters>')
        parts.append('</tool>')
        return '\n'.join(parts)