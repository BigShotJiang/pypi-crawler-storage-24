from jazzmine.core.llm.types import LLMUsage

def estimate_tokens(text: str) -> int:
    # Conservative heuristic (≈ GPT-style BPE)
    return max(1, len(text) // 4)

def normalize_usage(
    prompt: str,
    completion: str,
    provider_usage: dict | None,
) -> LLMUsage:
    if provider_usage:
        return LLMUsage(
            prompt_tokens=provider_usage.get("prompt_tokens", 0),
            completion_tokens=provider_usage.get("completion_tokens", 0),
            total_tokens=provider_usage.get("total_tokens", 0),
            cost=provider_usage.get("cost"),
        )

    prompt_tokens = estimate_tokens(prompt)
    completion_tokens = estimate_tokens(completion)

    return LLMUsage(
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=prompt_tokens + completion_tokens,
    )