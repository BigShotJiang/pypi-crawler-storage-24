import httpx
from .openai_compatible import OpenAICompatibleLLM

class AzureOpenAILLM(OpenAICompatibleLLM):
    def __init__(
        self,
        api_key: str,
        endpoint: str,
        deployment_name: str,
        api_version: str = "2024-02-15-preview",
        **kwargs,
    ):
        azure_base_url = f"{endpoint.rstrip('/')}/openai/deployments/{deployment_name}"
        
        super().__init__(
            api_key="", 
            base_url=azure_base_url, 
            chat_endpoint="/chat/completions",
            model=deployment_name, 
            **kwargs
        )
        
        # Override with Azure-specific Auth logic
        headers = {"api-key": api_key, "Content-Type": "application/json"}
        params = {"api-version": api_version}

        self.client.headers = httpx.Headers(headers)
        self.client.params = params
        
        self.aclient.headers = httpx.Headers(headers)
        self.aclient.params = params