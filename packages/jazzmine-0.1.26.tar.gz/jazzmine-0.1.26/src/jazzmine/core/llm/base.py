from abc import ABC, abstractmethod
from typing import Iterable, AsyncIterator, Iterator, Optional, List

from jazzmine.core.llm.types import LLMResponse, MessagePart

class BaseLLM(ABC):
    def __init__(
        self,
        model: str,
        temperature: Optional[float] = 0.0,
        max_tokens: Optional[int] = None,
        timeout: Optional[float] = None,
        **kwargs
    ):
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout = timeout

    # ---------- SYNC ----------
    @abstractmethod
    def generate(self, messages: List[MessagePart], *, stop: Optional[Iterable[str]] = None, **kwargs) -> LLMResponse:
        pass

    @abstractmethod
    def stream(self, messages: List[MessagePart], *, stop: Optional[Iterable[str]] = None, **kwargs) -> Iterator[str]:
        pass

    # ---------- ASYNC ----------
    @abstractmethod
    async def agenerate(self, messages: List[MessagePart], *, stop: Optional[Iterable[str]] = None, **kwargs) -> LLMResponse:
        pass

    @abstractmethod
    async def astream(self, messages: List[MessagePart], *, stop: Optional[Iterable[str]] = None, **kwargs) -> AsyncIterator[str]:
        pass

    # ---------- RESOURCE MANAGEMENT ----------
    def close(self):
        """Clean up synchronous resources (TCP connections)."""
        if hasattr(self, 'client') and hasattr(self.client, 'close'):
            self.client.close()

    async def aclose(self):
        """Clean up asynchronous resources."""
        if hasattr(self, 'aclient') and hasattr(self.aclient, 'aclose'):
            await self.aclient.aclose()

    def health_check(self) -> bool:
        return True
    
    # Context manager support
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.aclose()