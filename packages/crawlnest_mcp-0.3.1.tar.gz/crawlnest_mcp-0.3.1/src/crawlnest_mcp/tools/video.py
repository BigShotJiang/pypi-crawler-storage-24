"""MCP tool handlers for video download and transcription."""

import json
import logging
import os

import httpx
from mcp.types import TextContent

logger = logging.getLogger(__name__)

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")

VIDEO_API_BASE = f"{CRAWLNEST_API_URL}/api/video"


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY
    return headers


def _error_response(error: str, details: str | None = None) -> list[TextContent]:
    resp: dict = {"success": False, "error": error}
    if details:
        resp["details"] = details
    return [TextContent(type="text", text=json.dumps(resp))]


async def handle_download_video(arguments: dict) -> list[TextContent]:
    """Get video metadata and download URLs from a tweet or Reddit post.

    Note: Returns metadata/URLs (not the binary stream) since MCP is text-based.
    """
    url = arguments.get("url")
    platform = arguments.get("platform")
    if not url or not platform:
        return _error_response("url and platform are required")

    payload: dict = {"url": url, "platform": platform}
    if arguments.get("quality"):
        payload["quality"] = arguments["quality"]

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{VIDEO_API_BASE}/metadata",
                json=payload,
                headers=_headers(),
                timeout=60.0,
            )
            if response.status_code != 200:
                return _error_response(
                    f"Video API returned HTTP {response.status_code}",
                    details=response.text,
                )
            data = response.json()
            return [TextContent(type="text", text=json.dumps({"success": True, **data}))]

    except httpx.TimeoutException:
        return _error_response("Request timed out")
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API", details=str(e))


def _calculate_transcribe_timeout(duration_ms: int | None) -> float:
    """Calculate dynamic timeout based on video duration.

    Mirrors the API's internal logic: Whisper processes at ~0.7x realtime on GPU,
    so 1.5x duration gives comfortable headroom. Adds extra buffer for audio
    extraction + network overhead on top of the transcription time.

    Returns timeout in seconds.
    """
    base_timeout = 180.0  # minimum 3 minutes
    if not duration_ms or duration_ms <= 0:
        return base_timeout

    duration_sec = duration_ms / 1000
    # 1.5x for Whisper processing + 60s buffer for audio extraction & network
    dynamic_timeout = (duration_sec * 1.5) + 60
    return max(base_timeout, dynamic_timeout)


async def handle_transcribe_video(arguments: dict) -> list[TextContent]:
    """Transcribe audio from a tweet or Reddit video post.

    Returns transcript text — no video is downloaded or saved.
    Dynamically scales timeout based on video duration fetched from metadata.
    """
    url = arguments.get("url")
    platform = arguments.get("platform")
    if not url or not platform:
        return _error_response("url and platform are required")

    payload: dict = {"url": url, "platform": platform}
    if arguments.get("language"):
        payload["language"] = arguments["language"]
    if arguments.get("response_format"):
        payload["response_format"] = arguments["response_format"]

    duration_ms: int | None = None

    try:
        async with httpx.AsyncClient() as client:
            # Step 1: Fetch metadata to get video duration for dynamic timeout
            try:
                meta_response = await client.post(
                    f"{VIDEO_API_BASE}/metadata",
                    json={"url": url, "platform": platform},
                    headers=_headers(),
                    timeout=60.0,
                )
                if meta_response.status_code == 200:
                    meta = meta_response.json()
                    duration_ms = meta.get("duration_ms")
                    logger.info(
                        f"Video duration: {duration_ms}ms"
                        if duration_ms
                        else "Video duration unknown"
                    )
            except (httpx.TimeoutException, httpx.RequestError):
                logger.warning("Failed to fetch metadata for timeout calculation, using default")

            # Step 2: Calculate timeout based on duration
            timeout = _calculate_transcribe_timeout(duration_ms)
            logger.info(f"Transcribe timeout: {timeout:.0f}s (duration: {duration_ms}ms)")

            # Step 3: Call transcribe with dynamic timeout
            response = await client.post(
                f"{VIDEO_API_BASE}/transcribe",
                json=payload,
                headers=_headers(),
                timeout=timeout,
            )
            if response.status_code != 200:
                return _error_response(
                    f"Video API returned HTTP {response.status_code}",
                    details=response.text,
                )
            data = response.json()
            return [TextContent(type="text", text=json.dumps({"success": True, **data}))]

    except httpx.TimeoutException:
        duration_info = f" ({duration_ms / 1000:.0f}s video)" if duration_ms else ""
        return _error_response(
            f"Request timed out{duration_info} — video may be too long for transcription"
        )
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API", details=str(e))
