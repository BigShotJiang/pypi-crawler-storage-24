from django.core.management.base import CommandError
from ..services import (
    list_failed_tasks,
    get_task,
    retry_task,
    retry_all_failed_tasks,
    get_exception_summary,
)


class FailedTaskManagementMixin:
    """Mixin that provides functionality for managing failed Celery tasks."""

    def add_failed_task_arguments(self, parser):
        """Configure subcommands and arguments for task management."""
        subparsers = parser.add_subparsers(dest='subcommand')

        # List subcommand
        list_parser = subparsers.add_parser('list', help='List failed tasks')
        list_parser.add_argument('--limit', type=int, default=50, help='Max number of tasks to show')
        list_parser.add_argument('--task-name', type=str, help='Filter by task name')
        list_parser.add_argument('--since', type=str, help='Filter by date')

        # Show subcommand
        show_parser = subparsers.add_parser('show', help='Show task details')
        show_parser.add_argument('task_id', help='Task ID to display')

        # Retry subcommand
        retry_parser = subparsers.add_parser('retry', help='Retry failed tasks')
        retry_parser.add_argument('task_id', nargs='?', help='Task ID to retry')
        retry_parser.add_argument('--all', action='store_true', help='Retry all failed tasks')
        retry_parser.add_argument('--limit', type=int, default=50, help='Max tasks to retry when using --all')
        retry_parser.add_argument('--task-name', type=str, help='Filter by task name when using --all')
        retry_parser.add_argument('--since', type=str, help='Filter by date when using --all')

    def handle_failed_task_command(self, options):
        """Execute the appropriate subcommand based on options."""
        subcommand = options.get('subcommand')

        command_map = {
            'list': self.list_failed_tasks,
            'show': self.show_failed_task,
            'retry': self.retry_failed_tasks,
        }

        handler = command_map.get(subcommand)
        if not handler:
            raise CommandError('Specify a subcommand: list, show, retry')

        handler(options)

    def list_failed_tasks(self, options):
        """List failed tasks based on provided filters."""
        tasks, total = list_failed_tasks(
            limit=options['limit'],
            task_name=options.get('task_name'),
            since=options.get('since'),
        )

        if not tasks:
            self.stdout.write(self.style.WARNING('No failed tasks found.'))
            return

        self.stdout.write(self.style.SUCCESS(
            f'\nFound {total} failed task(s) (showing {len(tasks)}):\n'
        ))

        for task in tasks:
            summary = get_exception_summary(task)
            self.stdout.write(
                f'Task ID: {task.task_id} | '
                f'Status: {task.status} | '
                f'Date done: {task.date_done} | '
                f'Summary: {summary}'
            )

    def show_failed_task(self, options):
        """Display details of a specific task."""
        task_id = options['task_id']

        try:
            task = get_task(task_id)
        except Exception as e:
            raise CommandError(f"Task not found: {task_id}") from e

        self.stdout.write(
            f'Task ID: {task.task_id} | '
            f'Status: {task.status} | '
            f'Args: {task.task_args} | '
            f'Kwargs: {task.task_kwargs} | '
            f'Result: {task.result} | '
            f'Date done: {task.date_done} | '
            f'Traceback: {task.traceback}'
        )

    def retry_failed_tasks(self, options):
        """Retry one or all failed tasks."""
        if options['all']:
            self._retry_all_tasks(options)
        else:
            self._retry_single_task(options)

    def _retry_all_tasks(self, options):
        """Retry all failed tasks based on filters."""
        results = retry_all_failed_tasks(
            limit=options['limit'],
            task_name=options.get('task_name'),
            since=options.get('since'),
        )

        self.stdout.write(self.style.SUCCESS(
            f"Successfully requeued: {results['success']} task(s)"
        ))

        if results['errors']:
            self.stdout.write(self.style.ERROR(
                f"Errors: {results['errors']}"
            ))

    def _retry_single_task(self, options):
        """Retry a specific task."""
        task_id = options.get('task_id')

        if not task_id:
            raise CommandError('Please provide a task_id or use --all')

        try:
            task = get_task(task_id)
            result = retry_task(task)
            self.stdout.write(self.style.SUCCESS(
                f'Requeued successfully → New Task ID: {result.id}'
            ))
        except Exception as e:
            raise CommandError(f"Failed to retry task {task_id}: {e}") from e