import copy

from rest_framework import serializers

from . import AbstractSerializer
from ..timestamp_field import TimestampField

class BaseModelSerializer(AbstractSerializer, serializers.ModelSerializer):
    id = serializers.ReadOnlyField(source="pk")
    created = TimestampField(read_only=True, required=False)
    modified = TimestampField(read_only=True, required=False)

    class Meta:
        fields = "__all__"

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        meta = getattr(cls, "Meta", None)
        if (
            meta is not None
            and "fields" not in meta.__dict__
            and "exclude" not in meta.__dict__
        ):
            meta.fields = "__all__"