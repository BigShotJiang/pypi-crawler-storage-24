"""VMware Storage — vSphere datastore, iSCSI, and vSAN management."""

__version__ = "1.3.4"
