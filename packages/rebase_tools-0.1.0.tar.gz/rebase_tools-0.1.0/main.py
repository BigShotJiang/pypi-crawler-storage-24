def main():
    print("Hello from rebase-tools!")


if __name__ == "__main__":
    main()
