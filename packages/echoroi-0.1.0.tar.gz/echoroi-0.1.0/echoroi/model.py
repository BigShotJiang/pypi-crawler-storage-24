"""U-Net model architecture for echocardiographic ROI segmentation."""


import tensorflow as tf
from tensorflow.keras import layers, models

# ── Registered custom metrics ─────────────────────────────────────────
# Decorated so Keras .keras format can serialize / deserialize them.
_register = getattr(
    getattr(tf.keras, "saving", None),
    "register_keras_serializable",
    tf.keras.utils.register_keras_serializable,
)


@_register(package="echoroi")
def dice_coefficient(y_true, y_pred, smooth=1e-6):
    """Dice coefficient metric for segmentation."""
    y_true_f = tf.keras.backend.flatten(y_true)
    y_pred_f = tf.keras.backend.flatten(y_pred)
    intersection = tf.keras.backend.sum(y_true_f * y_pred_f)
    return (2.0 * intersection + smooth) / (
        tf.keras.backend.sum(y_true_f) + tf.keras.backend.sum(y_pred_f) + smooth
    )


@_register(package="echoroi")
def iou_score(y_true, y_pred, smooth=1e-6):
    """IoU (Intersection over Union) metric for segmentation."""
    y_true_f = tf.keras.backend.flatten(y_true)
    y_pred_f = tf.keras.backend.flatten(y_pred)
    intersection = tf.keras.backend.sum(y_true_f * y_pred_f)
    union = tf.keras.backend.sum(y_true_f) + tf.keras.backend.sum(y_pred_f) - intersection
    return (intersection + smooth) / (union + smooth)


# ── Composite loss: BCE + Dice + Total Variation ──────────────────────
# The combination addresses three complementary objectives:
#   BCE  – stable per-pixel gradient signal
#   Dice – region-overlap optimisation, robust to class imbalance
#   TV   – penalises high-frequency mask edges, encouraging the smooth
#          fan-shaped sector boundaries typical of ultrasound probes

def _dice_loss(y_true, y_pred, smooth=1e-6):
    """1 − Dice: differentiable region-overlap loss."""
    intersection = tf.reduce_sum(y_true * y_pred)
    union = tf.reduce_sum(y_true) + tf.reduce_sum(y_pred)
    return 1.0 - (2.0 * intersection + smooth) / (union + smooth)


def _total_variation_loss(y_pred):
    """Encourage smooth, continuous masks by penalising jagged edges."""
    dx = tf.abs(y_pred[:, 1:, :, :] - y_pred[:, :-1, :, :])
    dy = tf.abs(y_pred[:, :, 1:, :] - y_pred[:, :, :-1, :])
    return tf.reduce_mean(dx) + tf.reduce_mean(dy)


@_register(package="echoroi")
def bce_dice_tv_loss(y_true, y_pred,
                    w_bce=1.0, w_dice=1.0, alpha_tv=1e-4):
    """Composite loss combining BCE, Dice, and Total-Variation terms.

    .. math::

        \\mathcal{L} = w_{bce}\\,\\mathrm{BCE}
                     + w_{dice}\\,\\mathrm{DiceLoss}
                     + \\alpha_{tv}\\,\\mathrm{TV}(\\hat{y})

    The TV regulariser is the key ingredient for producing the smooth,
    fan-shaped sector boundaries characteristic of echocardiographic
    ultrasound, while the Dice term handles foreground/background class
    imbalance.
    """
    bce = tf.keras.losses.binary_crossentropy(y_true, y_pred)
    dsc = _dice_loss(y_true, y_pred)
    tv = _total_variation_loss(y_pred)
    return w_bce * bce + w_dice * dsc + alpha_tv * tv


class UNetModel:
    """U-Net model class for ultrasound ROI segmentation."""

    def __init__(self, input_shape: tuple[int, int, int] = (256, 256, 1), num_classes: int = 1):
        """Initialize U-Net model.

        Args:
            input_shape: Input image shape (height, width, channels)
            num_classes: Number of output classes (1 for binary segmentation)
        """
        self.input_shape = input_shape
        self.num_classes = num_classes
        self.model = None

    def build_model(self) -> tf.keras.Model:
        """Build U-Net architecture with encoder-decoder structure.

        Returns:
            Compiled Keras model
        """
        inputs = layers.Input(shape=self.input_shape)

        # Encoder path
        c1 = layers.Conv2D(64, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(inputs)
        c1 = layers.Dropout(0.1)(c1)
        c1 = layers.Conv2D(64, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c1)
        p1 = layers.MaxPooling2D((2, 2))(c1)

        c2 = layers.Conv2D(128, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(p1)
        c2 = layers.Dropout(0.1)(c2)
        c2 = layers.Conv2D(128, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c2)
        p2 = layers.MaxPooling2D((2, 2))(c2)

        c3 = layers.Conv2D(256, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(p2)
        c3 = layers.Dropout(0.2)(c3)
        c3 = layers.Conv2D(256, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c3)
        p3 = layers.MaxPooling2D((2, 2))(c3)

        c4 = layers.Conv2D(512, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(p3)
        c4 = layers.Dropout(0.2)(c4)
        c4 = layers.Conv2D(512, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c4)
        p4 = layers.MaxPooling2D(pool_size=(2, 2))(c4)

        # Bottleneck
        c5 = layers.Conv2D(1024, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(p4)
        c5 = layers.Dropout(0.3)(c5)
        c5 = layers.Conv2D(1024, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c5)

        # Decoder path
        u6 = layers.Conv2DTranspose(512, (2, 2), strides=(2, 2), padding='same')(c5)
        u6 = layers.concatenate([u6, c4])
        c6 = layers.Conv2D(512, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(u6)
        c6 = layers.Dropout(0.2)(c6)
        c6 = layers.Conv2D(512, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c6)

        u7 = layers.Conv2DTranspose(256, (2, 2), strides=(2, 2), padding='same')(c6)
        u7 = layers.concatenate([u7, c3])
        c7 = layers.Conv2D(256, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(u7)
        c7 = layers.Dropout(0.2)(c7)
        c7 = layers.Conv2D(256, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c7)

        u8 = layers.Conv2DTranspose(128, (2, 2), strides=(2, 2), padding='same')(c7)
        u8 = layers.concatenate([u8, c2])
        c8 = layers.Conv2D(128, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(u8)
        c8 = layers.Dropout(0.1)(c8)
        c8 = layers.Conv2D(128, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c8)

        u9 = layers.Conv2DTranspose(64, (2, 2), strides=(2, 2), padding='same')(c8)
        u9 = layers.concatenate([u9, c1], axis=3)
        c9 = layers.Conv2D(64, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(u9)
        c9 = layers.Dropout(0.1)(c9)
        c9 = layers.Conv2D(64, (3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c9)

        outputs = layers.Conv2D(self.num_classes, (1, 1), activation='sigmoid', name="segmentation_output")(c9)

        self.model = models.Model(inputs=[inputs], outputs=[outputs])
        return self.model

    def compile_model(self, learning_rate: float = 1e-4) -> tf.keras.Model:
        """Compile the model with optimizer, loss, and metrics.

        Uses a composite BCE + Dice + Total-Variation loss
        (``bce_dice_tv_loss``) that balances per-pixel accuracy,
        region overlap, and boundary smoothness.

        Args:
            learning_rate: Learning rate for Adam optimizer

        Returns:
            Compiled model
        """
        if self.model is None:
            self.build_model()

        self.model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
            loss=bce_dice_tv_loss,
            metrics=['accuracy', dice_coefficient, iou_score]
        )
        return self.model

    def get_model(self) -> tf.keras.Model:
        """Get the model instance.

        Returns:
            The Keras model instance
        """
        if self.model is None:
            self.compile_model()
        return self.model

    def load_weights(self, weights_path: str) -> None:
        """Load pre-trained weights.

        Args:
            weights_path: Path to the weights file
        """
        if self.model is None:
            self.build_model()
        self.model.load_weights(weights_path)

    def save_model(self, model_path: str) -> None:
        """Save the complete model.

        Args:
            model_path: Path to save the model
        """
        if self.model is None:
            raise ValueError("Model not built yet. Call build_model() first.")
        self.model.save(model_path)


def load_pretrained_model(model_path: str, compile: bool = False) -> tf.keras.Model:
    """Load a pre-trained U-Net model.

    By default the model is loaded without recompilation (``compile=False``),
    which is sufficient for inference and avoids deserialisation issues
    with custom metrics across different Keras versions.  Pass
    ``compile=True`` if you need to resume training.
    """
    custom_objects = {
        "dice_coefficient": dice_coefficient,
        "iou_score": iou_score,
        "bce_dice_tv_loss": bce_dice_tv_loss,
    }
    return tf.keras.models.load_model(
        model_path, custom_objects=custom_objects, compile=compile,
    )
