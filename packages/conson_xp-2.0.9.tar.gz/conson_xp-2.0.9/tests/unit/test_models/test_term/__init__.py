"""Tests for term models."""
