"""Utilities for discovering NVIDIA pip-installed runtime libraries."""

from __future__ import annotations

import ctypes
import logging
import os
import platform
import site
import sys
from typing import Iterable, List, Optional, Sequence


NVIDIA_PIP_LIB_SUBDIRS: Sequence[str] = (
    os.path.join("nvidia", "cuda_nvrtc", "lib"),
    os.path.join("nvidia", "cuda_runtime", "lib"),
    os.path.join("nvidia", "nvjitlink", "lib"),
)


def _dedupe_ordered(paths: Iterable[str]) -> List[str]:
    """Return unique paths while preserving first-seen order."""
    unique_paths: List[str] = []
    seen = set()
    for path in paths:
        if not path or path in seen:
            continue
        seen.add(path)
        unique_paths.append(path)
    return unique_paths


def _library_path_variable(system: str) -> Optional[str]:
    if system == "Linux":
        return "LD_LIBRARY_PATH"
    if system == "Darwin":
        return "DYLD_LIBRARY_PATH"
    if system == "Windows":
        return "PATH"
    return None


def _nvrtc_library_candidates(system: str) -> Sequence[str]:
    if system == "Linux":
        return ("libnvrtc.so.12", "libnvrtc.so")
    if system == "Darwin":
        return ("libnvrtc.12.dylib", "libnvrtc.dylib")
    return ()


def is_nvrtc_loadable(system: Optional[str] = None) -> bool:
    """Return True if NVRTC can already be loaded via the dynamic loader."""
    resolved_system = system or platform.system()
    candidates = _nvrtc_library_candidates(resolved_system)
    if not candidates:
        return True

    for library_name in candidates:
        try:
            ctypes.CDLL(library_name)
            return True
        except OSError:
            continue
    return False


def _site_package_locations(system: str) -> List[str]:
    """Collect likely site-packages paths (system, user, and venv fallback)."""
    locations: List[str] = []

    try:
        locations.extend(site.getsitepackages())
    except (AttributeError, TypeError):
        pass

    try:
        user_site = site.getusersitepackages()
        if user_site:
            locations.append(user_site)
    except (AttributeError, TypeError):
        pass

    if system == "Windows":
        locations.append(os.path.join(sys.prefix, "Lib", "site-packages"))
    else:
        locations.append(
            os.path.join(
                sys.prefix,
                "lib",
                f"python{sys.version_info.major}.{sys.version_info.minor}",
                "site-packages",
            )
        )

    return _dedupe_ordered(locations)


def _discover_nvidia_library_dirs(system: str) -> List[str]:
    """Find NVIDIA pip-package lib directories under discovered site-packages roots."""
    candidates: List[str] = []
    for site_root in _site_package_locations(system):
        for rel_path in NVIDIA_PIP_LIB_SUBDIRS:
            path = os.path.join(site_root, rel_path)
            if os.path.isdir(path):
                candidates.append(path)

    return _dedupe_ordered(candidates)


def _prepend_env_paths(path_var_name: str, new_dirs: Sequence[str]) -> List[str]:
    """Prepend new directories to the selected runtime library environment variable."""
    if not new_dirs:
        return []

    current = os.environ.get(path_var_name, "")
    existing_paths = [p for p in current.split(os.pathsep) if p]

    dirs_to_add = [p for p in new_dirs if p not in existing_paths]
    if not dirs_to_add:
        return []

    merged = dirs_to_add + existing_paths
    os.environ[path_var_name] = os.pathsep.join(merged)
    return dirs_to_add


def _preload_nvrtc_from_dirs(dirs: List[str], system: str, logger: Optional[logging.Logger] = None) -> bool:
    """Preload NVRTC shared library via ctypes from discovered directories.
    
    Setting LD_LIBRARY_PATH after process start does NOT affect dlopen().
    We must explicitly load the library so it's in the process's loaded library cache.
    """
    candidates = _nvrtc_library_candidates(system)
    for lib_dir in dirs:
        for lib_name in candidates:
            lib_path = os.path.join(lib_dir, lib_name)
            if os.path.isfile(lib_path):
                try:
                    ctypes.CDLL(lib_path, mode=ctypes.RTLD_GLOBAL)
                    if logger:
                        logger.info("Preloaded NVRTC library: %s", lib_path)
                    return True
                except OSError:
                    continue
    return False


def ensure_nvrtc_library_path(logger: Optional[logging.Logger] = None) -> List[str]:
    """Ensure NVIDIA pip library paths are discoverable before first NVRTC usage.

    Returns:
        List of directories that were added to LD_LIBRARY_PATH / DYLD_LIBRARY_PATH / PATH.
    """
    system = platform.system()
    path_var_name = _library_path_variable(system)

    if path_var_name is None:
        return []

    if is_nvrtc_loadable(system=system):
        return []

    nvidia_lib_dirs = _discover_nvidia_library_dirs(system=system)
    added_dirs = _prepend_env_paths(path_var_name, nvidia_lib_dirs)

    if added_dirs:
        active_logger = logger or logging.getLogger(__name__)
        active_logger.info(
            "Added NVIDIA runtime library directories to %s: %s",
            path_var_name,
            ", ".join(added_dirs),
        )
        # Preload NVRTC directly since LD_LIBRARY_PATH changes don't affect
        # already-running processes (dlopen uses the path from process start)
        _preload_nvrtc_from_dirs(added_dirs, system, active_logger)

    return added_dirs
