"""
Epochly API endpoints configuration.

Centralizes all API endpoint definitions for the Epochly system.

Environment variables (in precedence order):
  EPOCHLY_API_URL         -- canonical base URL for all API calls (preferred)
  EPOCHLY_API_ENDPOINT    -- deprecated alias; use EPOCHLY_API_URL instead
  EPOCHLY_LENS_API_URL    -- base URL for Lens PLG endpoint (default: https://api.epochly.com)
  EPOCHLY_DISABLE_TELEMETRY -- set to '1' to opt out of telemetry
"""

import os
import logging
from typing import Dict, Optional
from urllib.parse import urlparse, urlunparse

logger = logging.getLogger(__name__)


class APIEndpoints:
    """Manages API endpoint configuration for Epochly."""

    # Default to custom domain, fallback to direct AWS endpoint
    DEFAULT_BASE_URL = "https://api.epochly.com"
    FALLBACK_BASE_URL = os.environ.get(
        'EPOCHLY_FALLBACK_API_URL',
        'https://6g2po3kxnd.execute-api.us-west-2.amazonaws.com/prod',
    )

    # Allow override via environment variable; strip trailing slash for safety
    BASE_URL = os.environ.get('EPOCHLY_API_URL', DEFAULT_BASE_URL).rstrip('/')

    # API endpoints
    ENDPOINTS = {
        # Trial system
        'trial_activation': f"{BASE_URL}/trial/activate",
        'trial_confirmation': f"{BASE_URL}/trial/confirm",
        'trial_status': f"{BASE_URL}/trial/status",
        'trial_validation': f"{BASE_URL}/trial/validate",
        'license_validation': f"{BASE_URL}/validate-license",

        # Compatibility system
        'compatibility_report': f"{BASE_URL}/compatibility/report",
        'compatibility_sync': f"{BASE_URL}/compatibility/sync",
        'compatibility_get': f"{BASE_URL}/compatibility/get",

        # Node management
        'node_cleanup': f"{BASE_URL}/node/cleanup",

        # Telemetry
        'telemetry': f"{BASE_URL}/telemetry/metrics",
        'critical_event': f"{BASE_URL}/critical-event",

        # Device management (multi-device licensing)
        'device_register': f"{BASE_URL}/v1/devices/register",
        'device_sync': f"{BASE_URL}/v1/devices/sync",
        'device_list': f"{BASE_URL}/v1/devices/list",
        'device_remove': f"{BASE_URL}/v1/devices/remove",
        'device_rename': f"{BASE_URL}/v1/devices/rename",
    }

    @classmethod
    def get_endpoint(cls, name: str) -> str:
        """
        Get endpoint URL by name.

        Args:
            name: Endpoint name

        Returns:
            Full endpoint URL

        Raises:
            KeyError: If endpoint name not found
        """
        if name not in cls.ENDPOINTS:
            raise KeyError(f"Unknown endpoint: {name}")
        return cls.ENDPOINTS[name]

    @classmethod
    def get_headers(cls, include_auth: bool = False, api_key: Optional[str] = None) -> Dict[str, str]:
        """
        Get standard headers for API requests.

        Args:
            include_auth: Whether to include authentication headers
            api_key: Optional API key for protected endpoints

        Returns:
            Dictionary of headers
        """
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'Epochly/1.0'
        }

        if include_auth and api_key:
            headers['X-Epochly-API-Key'] = api_key

        return headers

    @classmethod
    def use_fallback(cls):
        """Switch to fallback URL if custom domain fails.

        Uses proper URL parsing (not .split('.com')) to avoid corrupting
        URLs that contain '.com' in the hostname (e.g. amazonaws.com).
        """
        cls.BASE_URL = cls.FALLBACK_BASE_URL
        fallback_parsed = urlparse(cls.FALLBACK_BASE_URL)

        for key in cls.ENDPOINTS:
            original_parsed = urlparse(cls.ENDPOINTS[key])
            # Build new URL: fallback scheme+host+port, keep original path/query/fragment
            new_url = urlunparse((
                fallback_parsed.scheme,
                fallback_parsed.netloc,
                original_parsed.path,
                original_parsed.params,
                original_parsed.query,
                original_parsed.fragment,
            ))
            cls.ENDPOINTS[key] = new_url

    @classmethod
    def test_connectivity(cls) -> bool:
        """
        Test connectivity to API endpoint.

        Returns:
            True if API is reachable
        """
        import requests

        try:
            # Test with a simple OPTIONS request
            response = requests.options(
                f"{cls.BASE_URL}/trial/activate",
                timeout=5
            )
            return response.status_code == 200
        except (requests.RequestException, OSError):
            # Try fallback
            try:
                cls.use_fallback()
                response = requests.options(
                    f"{cls.BASE_URL}/trial/activate",
                    timeout=5
                )
                return response.status_code == 200
            except (requests.RequestException, OSError):
                return False


# Convenience function for importing
def get_api_endpoint(name: str) -> str:
    """Get API endpoint URL by name."""
    return APIEndpoints.get_endpoint(name)


def get_request_source() -> str:
    """
    Determine the source of the current request for traffic tagging.

    Returns one of:
      - "ci"         when running inside CI/CD (GitHub Actions, test mode, etc.)
      - The value of EPOCHLY_SOURCE env var if explicitly set
      - "production" for normal end-user usage

    The returned value is sent as the X-Epochly-Source header on all API
    requests so that Lambda handlers can tag, filter, and short-circuit
    CI traffic to keep production DynamoDB tables clean.
    """
    # Explicit override takes highest priority
    explicit = os.environ.get('EPOCHLY_SOURCE', '').strip()
    if explicit:
        return explicit

    # Detect CI environments
    ci_indicators = (
        os.environ.get('EPOCHLY_TEST_MODE', '0') == '1',
        os.environ.get('CI', '').lower() in ('true', '1'),
        os.environ.get('GITHUB_ACTIONS', '').lower() in ('true', '1'),
        os.environ.get('GITLAB_CI', '').lower() in ('true', '1'),
        os.environ.get('JENKINS_URL', '') != '',
        os.environ.get('TRAVIS', '').lower() in ('true', '1'),
    )
    if any(ci_indicators):
        return 'ci'

    return 'production'
