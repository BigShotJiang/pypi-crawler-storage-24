"""Custom exceptions for the interception subsystem."""


class OperationBelowThresholdError(RuntimeError):
    """Raised when an operation's data size is below the routing threshold.
    
    This is expected control flow, not an error — small operations are
    intentionally routed to the original function to avoid overhead.
    """
    pass
