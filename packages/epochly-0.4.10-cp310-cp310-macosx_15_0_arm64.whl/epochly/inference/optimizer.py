"""
PrePostOptimizer - Pre/post-processing parallelization and caching.

Parallelizes tokenization across ThreadExecutor, caches tokenized
results via LRU with xxhash64 keys, and manages pinned memory
for CPU->GPU transfers.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import contextvars
import logging
import threading
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

try:
    import xxhash as _xxhash

    def _hash_text(text: str) -> str:
        return _xxhash.xxh64(text.encode()).hexdigest()
except ImportError:
    import hashlib

    def _hash_text(text: str) -> str:
        return hashlib.sha256(text.encode()).hexdigest()[:16]

from .frameworks.base_adapter import InferenceAdapter

logger = logging.getLogger(__name__)


@dataclass
class PrePostConfig:
    """Configuration for PrePostOptimizer."""

    token_cache_size: int = 10_000
    max_parallel_workers: int = 4


class PrePostOptimizer:
    """Parallelize and cache pre/post-processing steps.

    Thread-safe. LRU cache for tokenized results. Parallel decoding
    for post-processing outputs.
    """

    def __init__(
        self,
        thread_executor: Any,
        sub_executor: Optional[Any] = None,
        config: Optional[PrePostConfig] = None,
    ) -> None:
        self._thread_executor = thread_executor
        self._sub_executor = sub_executor
        self._config = config or PrePostConfig()
        self._token_cache: OrderedDict[str, Any] = OrderedDict()
        self._cache_maxsize = self._config.token_cache_size
        self._cache_hits = 0
        self._cache_misses = 0
        self._lock = threading.Lock()

    def tokenize_cached(self, tokenizer: Any, text: str) -> Any:
        """Tokenize text with LRU caching.

        Cache key is xxhash64 of the input text. Returns cached
        result on hit, computes and caches on miss.

        Note: Under concurrent access, two threads may both miss the cache
        for the same key and both call tokenizer.encode(). The second write
        is harmless (idempotent result, LRU ordering updated). The miss
        counter may be slightly overcounted. This is acceptable because
        tokenizer.encode() is pure/idempotent and the lock is released
        during the potentially slow encode call to avoid blocking other
        cache lookups.
        """
        key = _hash_text(text)

        with self._lock:
            if key in self._token_cache:
                self._cache_hits += 1
                # Move to end (most recently used)
                self._token_cache.move_to_end(key)
                return self._token_cache[key]

        # Cache miss: tokenize
        result = tokenizer.encode(text)

        with self._lock:
            self._cache_misses += 1
            self._token_cache[key] = result
            self._token_cache.move_to_end(key)
            # Evict LRU entries if over capacity
            while len(self._token_cache) > self._cache_maxsize:
                self._token_cache.popitem(last=False)

        return result

    def batch_tokenize(self, tokenizer: Any, texts: List[str]) -> List[Any]:
        """Tokenize a batch of texts with caching and parallelization.

        Deduplicates inputs, serves cached results immediately, and
        parallelizes uncached tokenization across ThreadExecutor.
        Each work item gets its own copy_context() to propagate
        RequestContext across thread boundaries.
        """
        # Partition into cached hits and uncached misses
        cached: Dict[str, Any] = {}
        uncached: List[Tuple[str, str]] = []
        seen_keys: set = set()

        for text in texts:
            key = _hash_text(text)
            if key in seen_keys:
                continue
            seen_keys.add(key)
            with self._lock:
                if key in self._token_cache:
                    self._cache_hits += 1
                    self._token_cache.move_to_end(key)
                    cached[key] = self._token_cache[key]
                else:
                    uncached.append((key, text))

        # Parallelize uncached tokenization via ThreadExecutor
        if uncached and self._thread_executor is not None:
            executor = self._thread_executor
            has_submit = hasattr(executor, "submit") or hasattr(executor, "submit_task")
            if has_submit:
                futures: List[Tuple[str, str, Any]] = []
                for key, text in uncached:
                    ctx = contextvars.copy_context()
                    if hasattr(executor, "submit"):
                        future = executor.submit(ctx.run, tokenizer.encode, text)
                    else:
                        future = executor.submit_task(ctx.run, tokenizer.encode, text)
                    futures.append((key, text, future))

                for key, text, future in futures:
                    try:
                        result = future.result() if hasattr(future, "result") else future
                        cached[key] = result
                        with self._lock:
                            self._cache_misses += 1
                            self._token_cache[key] = result
                            self._token_cache.move_to_end(key)
                            while len(self._token_cache) > self._cache_maxsize:
                                self._token_cache.popitem(last=False)
                    except Exception:
                        # Fallback to sequential on executor failure
                        cached[key] = tokenizer.encode(text)
                        with self._lock:
                            self._cache_misses += 1
                            self._token_cache[key] = cached[key]
                            self._token_cache.move_to_end(key)
                            while len(self._token_cache) > self._cache_maxsize:
                                self._token_cache.popitem(last=False)
            else:
                # Executor without submit - fall back to sequential
                for key, text in uncached:
                    cached[key] = self.tokenize_cached(tokenizer, text)
        else:
            # No executor - sequential tokenization
            for key, text in uncached:
                cached[key] = self.tokenize_cached(tokenizer, text)

        return [cached[_hash_text(t)] for t in texts]

    def batch_decode(
        self, decode_fn: Callable, outputs: List[Any]
    ) -> List[str]:
        """Decode a batch of outputs sequentially.

        Applies decode_fn to each output in order.
        """
        if not outputs:
            return []

        return [decode_fn(output) for output in outputs]

    def pin_transfer_buffers(
        self, adapter: InferenceAdapter, batch_size: int
    ) -> None:
        """Pre-allocate pinned host memory for CPU->GPU transfers.

        Pinned memory avoids page faults during DMA transfer.
        """
        input_shape = adapter.get_expected_input_shape(batch_size)
        adapter.pin_host_buffer(input_shape)

    @property
    def cache_size(self) -> int:
        """Current number of entries in the token cache."""
        with self._lock:
            return len(self._token_cache)

    def get_cache_stats(self) -> dict:
        """Return cache hit/miss statistics."""
        with self._lock:
            total = self._cache_hits + self._cache_misses
            return {
                "hits": self._cache_hits,
                "misses": self._cache_misses,
                "hit_rate": self._cache_hits / total if total > 0 else 0.0,
                "size": len(self._token_cache),
                "capacity": self._cache_maxsize,
            }
