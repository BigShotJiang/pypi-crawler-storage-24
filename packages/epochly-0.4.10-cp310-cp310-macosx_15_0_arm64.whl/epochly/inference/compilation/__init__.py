"""
Model compilation and optimization.

v1: torch.compile beta (golden-validated swap only)
v2: ONNX export, quantization (gated behind calibration + canary)

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""
