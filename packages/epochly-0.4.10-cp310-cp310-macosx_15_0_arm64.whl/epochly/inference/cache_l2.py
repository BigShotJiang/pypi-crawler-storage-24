"""
L2Cache - SQLite WAL + AES-256-GCM encrypted persistent cache tier.

Provides persistent caching for inference results with:
- SQLite in WAL mode for concurrent read access
- Optional AES-256-GCM per-row encryption (via cryptography library)
- TTL enforcement via expiry column
- Tenant-isolated key prefixes
- Thread-safe operations

When the cryptography library is not available, falls back to
unencrypted storage with a logged warning.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import os
import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Guard cryptography import for AES-256-GCM encryption
_cryptography_available = False
_AESGCM = None
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM as _AESGCM_cls

    _cryptography_available = True
    _AESGCM = _AESGCM_cls
except ImportError:
    logger.debug(
        "cryptography library not available; L2 cache encryption disabled"
    )


@dataclass
class L2CacheConfig:
    """Configuration for the L2 SQLite cache."""

    db_path: str = "~/.epochly/inference_cache/cache.db"
    ttl_seconds: float = 86400.0  # 24 hours
    encryption_key: Optional[bytes] = None  # 32-byte key for AES-256-GCM


class L2Cache:
    """SQLite WAL-mode persistent cache with optional AES-256-GCM encryption.

    Stores binary values keyed by string. Each row has a created_at
    timestamp for TTL enforcement. Encryption is per-row: each value
    is independently encrypted with a unique nonce.

    Thread-safe: uses a threading lock around all SQLite operations
    and counter mutations to prevent data races.
    """

    def __init__(self, config: Optional[L2CacheConfig] = None) -> None:
        self._config = config or L2CacheConfig()
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0

        # Set up encryption
        self._cipher: Optional[object] = None
        if self._config.encryption_key is not None and _cryptography_available:
            if len(self._config.encryption_key) != 32:
                raise ValueError(
                    "AES-256-GCM requires a 32-byte encryption key, "
                    f"got {len(self._config.encryption_key)} bytes"
                )
            self._cipher = _AESGCM(self._config.encryption_key)
        elif self._config.encryption_key is not None and not _cryptography_available:
            logger.warning(
                "Encryption key provided but cryptography library not available. "
                "L2 cache will store data UNENCRYPTED."
            )

        # Initialize SQLite database
        db_path = Path(self._config.db_path).expanduser()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._db_path = str(db_path)

        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS cache (
                key TEXT PRIMARY KEY,
                value BLOB NOT NULL,
                created_at REAL NOT NULL
            )
            """
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_cache_created ON cache(created_at)"
        )
        self._conn.commit()

    @property
    def journal_mode(self) -> str:
        """Return the current SQLite journal mode."""
        with self._lock:
            cursor = self._conn.execute("PRAGMA journal_mode")
            return cursor.fetchone()[0]

    def put(self, key: str, value: bytes) -> None:
        """Store a value in the cache.

        If encryption is configured, the value is encrypted with
        AES-256-GCM before storage. Each row gets a unique 12-byte
        nonce prepended to the ciphertext.

        Args:
            key: Cache key (string).
            value: Raw value (bytes).
        """
        stored = self._encrypt(value) if self._cipher is not None else value
        now = time.time()

        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO cache (key, value, created_at) VALUES (?, ?, ?)",
                (key, stored, now),
            )
            self._conn.commit()

    def get(self, key: str) -> Optional[bytes]:
        """Retrieve a value from the cache.

        Returns None if the key is not found, expired, or decryption fails.

        All state reads (SQLite query), TTL checks, TTL-expiry deletes,
        and counter mutations are performed under a single lock acquisition
        to prevent TOCTOU races where a concurrent put() for the same key
        could be silently deleted by a stale TTL-expiry delete.

        Args:
            key: Cache key (string).

        Returns:
            Raw value (bytes) or None.
        """
        with self._lock:
            cursor = self._conn.execute(
                "SELECT value, created_at FROM cache WHERE key = ?", (key,)
            )
            row = cursor.fetchone()

            if row is None:
                self._misses += 1
                return None

            stored_value, created_at = row

            # TTL check -- delete expired entry under same lock to avoid
            # racing with a concurrent put() for the same key
            if (time.time() - created_at) > self._config.ttl_seconds:
                self._conn.execute("DELETE FROM cache WHERE key = ?", (key,))
                self._conn.commit()
                self._misses += 1
                return None

            # Decrypt if encryption is configured (cipher is immutable after init)
            if self._cipher is not None:
                result = self._decrypt(stored_value)
                if result is None:
                    self._misses += 1
                else:
                    self._hits += 1
                return result

            self._hits += 1
            return stored_value

    def delete(self, key: str) -> None:
        """Remove a single key from the cache."""
        with self._lock:
            self._conn.execute("DELETE FROM cache WHERE key = ?", (key,))
            self._conn.commit()

    def clear_prefix(self, prefix: str) -> None:
        """Remove all keys matching a prefix (for tenant isolation).

        Uses parameterized LIKE query to prevent SQL injection.

        Args:
            prefix: Key prefix to match (e.g., "tenant_a:").
        """
        # Escape SQL LIKE wildcards in the prefix to prevent
        # injection of LIKE pattern characters (%, _)
        escaped = prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        with self._lock:
            self._conn.execute(
                "DELETE FROM cache WHERE key LIKE ? ESCAPE '\\'",
                (escaped + "%",),
            )
            self._conn.commit()

    def _get_raw(self, key: str) -> Optional[bytes]:
        """Retrieve raw stored bytes without decryption (for testing).

        Args:
            key: Cache key.

        Returns:
            Raw stored bytes or None.
        """
        with self._lock:
            cursor = self._conn.execute(
                "SELECT value FROM cache WHERE key = ?", (key,)
            )
            row = cursor.fetchone()
        return row[0] if row is not None else None

    def get_stats(self) -> dict:
        """Return cache hit/miss statistics."""
        with self._lock:
            cursor = self._conn.execute("SELECT COUNT(*) FROM cache")
            size = cursor.fetchone()[0]
            hits = self._hits
            misses = self._misses

        total = hits + misses
        return {
            "hits": hits,
            "misses": misses,
            "hit_rate": hits / total if total > 0 else 0.0,
            "size": size,
        }

    def close(self) -> None:
        """Close the database connection."""
        with self._lock:
            self._conn.close()

    def _encrypt(self, plaintext: bytes) -> bytes:
        """Encrypt data with AES-256-GCM.

        Format: 12-byte nonce || ciphertext+tag
        The nonce is generated randomly for each encryption.

        Args:
            plaintext: Data to encrypt.

        Returns:
            Nonce prepended to ciphertext (bytes).
        """
        nonce = os.urandom(12)
        ciphertext = self._cipher.encrypt(nonce, plaintext, None)
        return nonce + ciphertext

    def _decrypt(self, data: bytes) -> Optional[bytes]:
        """Decrypt data encrypted with AES-256-GCM.

        Expected format: 12-byte nonce || ciphertext+tag

        Args:
            data: Encrypted data with prepended nonce.

        Returns:
            Decrypted plaintext, or None if decryption fails.
        """
        if len(data) < 12:
            logger.warning("Encrypted data too short for AES-256-GCM nonce")
            return None

        nonce = data[:12]
        ciphertext = data[12:]

        try:
            return self._cipher.decrypt(nonce, ciphertext, None)
        except Exception as exc:
            logger.warning("AES-256-GCM decryption failed: %s", exc)
            return None
