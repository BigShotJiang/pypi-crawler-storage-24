"""
DynamicMicroBatcher - Request micro-batching for inference.

Collects individual requests into batches for more efficient GPU
utilization. Auto-tunes batch size from GPU memory headroom.

NOT continuous batching (vLLM/TGI own that). This collects discrete
requests into batches before a single forward pass.

Keyed sub-queues: requests are partitioned by BatchKey so only
compatible requests are batched together.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional

from ..context import BatchKey
from ..frameworks.base_adapter import InferenceAdapter
from .batch_optimizer import BatchOptimizer
from .request_queue import InferenceRequest, PriorityRequestQueue

logger = logging.getLogger(__name__)


@dataclass
class MicroBatcherConfig:
    """Configuration for DynamicMicroBatcher."""

    max_batch_size: int = 32
    max_queue_depth: int = 1024
    max_wait_ms: float = 50.0
    gpu_headroom_pct: int = 20


class DynamicMicroBatcher:
    """Request micro-batching with keyed sub-queues.

    Collects individual inference requests, partitions by BatchKey,
    and processes them in batches for GPU efficiency.

    Designed for single-consumer use (one batch processing loop).
    """

    def __init__(
        self,
        model: Any,
        adapter: InferenceAdapter,
        config: Optional[MicroBatcherConfig] = None,
    ) -> None:
        self._model = model
        self._adapter = adapter
        self._config = config or MicroBatcherConfig()
        self._queues: Dict[BatchKey, PriorityRequestQueue] = {}
        self._default_queue = PriorityRequestQueue(
            maxsize=self._config.max_queue_depth
        )
        self._queue_lock = asyncio.Lock()
        self._batch_optimizer = BatchOptimizer()
        self._batch_worker: Optional[asyncio.Task] = None
        self._shutdown = False

    @property
    def queue_depth(self) -> int:
        """Total requests across all queues."""
        total = self._default_queue.qsize()
        for q in self._queues.values():
            total += q.qsize()
        return total

    async def start(self) -> None:
        """Start the batch processing loop. Idempotent — safe to call twice."""
        if self._batch_worker is not None and not self._batch_worker.done():
            return
        self._shutdown = False
        self._batch_worker = asyncio.create_task(self._batch_loop())

    async def stop(self) -> None:
        """Stop the batch processing loop."""
        self._shutdown = True
        if self._batch_worker is not None:
            self._batch_worker.cancel()
            try:
                await self._batch_worker
            except asyncio.CancelledError:
                pass
            self._batch_worker = None

    async def infer(
        self,
        input_data: Any,
        priority: int = 1,
        batch_key: Optional[BatchKey] = None,
    ) -> Any:
        """Submit an inference request and wait for the result.

        Priority: 0=real-time (<100ms), 1=interactive (<1s), 2=batch.
        """
        future = asyncio.get_running_loop().create_future()
        request = InferenceRequest(
            input=input_data, priority=priority, future=future
        )

        if batch_key is not None:
            async with self._queue_lock:
                if batch_key not in self._queues:
                    self._queues[batch_key] = PriorityRequestQueue(
                        maxsize=self._config.max_queue_depth
                    )
                queue = self._queues[batch_key]
            await queue.put(request)
        else:
            await self._default_queue.put(request)

        return await future

    async def _batch_loop(self) -> None:
        """Main batch processing loop.

        Round-robins across non-empty queues to prevent starvation.
        """
        while not self._shutdown:
            processed = False

            # Collect all active queues
            all_queues = [("default", self._default_queue)]
            async with self._queue_lock:
                all_queues.extend(
                    (str(k), q) for k, q in self._queues.items()
                )

            for name, queue in all_queues:
                if queue.qsize() == 0:
                    continue

                batch = await queue.collect_batch(
                    max_size=self._config.max_batch_size,
                    max_wait_ms=self._config.max_wait_ms,
                )
                if not batch:
                    continue

                processed = True
                try:
                    collated = self._adapter.collate_batch(
                        [r.input for r in batch]
                    )
                    outputs = self._adapter.forward_batch(
                        self._model, collated
                    )
                    split_outputs = self._adapter.split_batch(
                        outputs, len(batch)
                    )
                    # Validate output count matches batch size
                    if len(split_outputs) < len(batch):
                        err = RuntimeError(
                            f"Adapter returned {len(split_outputs)} outputs "
                            f"for {len(batch)} requests"
                        )
                        for request in batch:
                            if not request.future.done():
                                request.future.set_exception(err)
                        continue
                    for request, output in zip(batch, split_outputs):
                        if not request.future.done():
                            request.future.set_result(output)
                except Exception as e:
                    for request in batch:
                        if not request.future.done():
                            request.future.set_exception(e)

            # Prune empty keyed sub-queues to prevent unbounded growth
            if not processed:
                async with self._queue_lock:
                    empty_keys = [
                        k for k, q in self._queues.items() if q.qsize() == 0
                    ]
                    for k in empty_keys:
                        del self._queues[k]
                await asyncio.sleep(0.001)
