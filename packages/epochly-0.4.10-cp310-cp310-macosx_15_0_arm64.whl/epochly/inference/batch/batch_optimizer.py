"""
BatchOptimizer - Batch size auto-tuning and adaptive timeout.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Optional

from ..frameworks.base_adapter import InferenceAdapter

logger = logging.getLogger(__name__)


@dataclass
class BatchConfig:
    """Configuration for batch optimization."""

    max_batch_size: int = 0  # 0 = auto-calibrate
    max_queue_depth: int = 1024
    max_wait_ms: float = 50.0
    target_latency_ms: float = 100.0
    gpu_headroom_pct: int = 20


class BatchOptimizer:
    """Batch size auto-tuning and adaptive timeout calculation.

    Uses binary search to find optimal batch size from GPU memory,
    and adaptive timeout based on queue depth ratio.
    """

    def __init__(self, config: Optional[BatchConfig] = None) -> None:
        self._config = config or BatchConfig()

    def adaptive_timeout(self, depth_ratio: float) -> float:
        """Calculate adaptive timeout based on queue depth ratio.

        - Queue depth > 80% capacity: max_wait * 0.25
        - Queue depth > 50%: max_wait * 0.5
        - Otherwise: max_wait (default 50ms)
        """
        max_wait = self._config.max_wait_ms
        if depth_ratio > 0.8:
            return max_wait * 0.25
        if depth_ratio > 0.5:
            return max_wait * 0.5
        return max_wait

    def calibrate_batch_size(
        self, model: Any, adapter: InferenceAdapter, gpu_memory_free: int
    ) -> int:
        """Binary search for max batch size that fits in GPU memory.

        Algorithm:
        1. Estimate model weight memory
        2. Available = gpu_memory_free - model_memory
        3. Reserve headroom
        4. Per-sample memory from single forward pass
        5. Max batch = usable / per_sample
        6. Validate with actual forward pass
        """
        if self._config.max_batch_size > 0:
            return self._config.max_batch_size

        model_memory = adapter.estimate_model_memory(model)
        available = gpu_memory_free - model_memory
        usable = int(available * (1.0 - self._config.gpu_headroom_pct / 100.0))

        per_sample = adapter.measure_per_sample_memory(model)
        if per_sample <= 0:
            return 1

        candidate = max(1, usable // per_sample)

        # Verify batch_size=1 works at all
        if not adapter.try_forward_with_batch(model, 1):
            logger.warning("Model cannot execute even batch_size=1")
            return 0

        # Binary search validation
        lo, hi = 1, candidate
        validated = 1
        while lo <= hi:
            mid = (lo + hi) // 2
            if adapter.try_forward_with_batch(model, mid):
                validated = mid
                lo = mid + 1
            else:
                hi = mid - 1

        return validated
