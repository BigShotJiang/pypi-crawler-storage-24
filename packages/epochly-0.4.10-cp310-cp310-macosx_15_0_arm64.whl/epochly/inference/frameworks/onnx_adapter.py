"""
OnnxAdapter - ONNX InferenceSession wrapping.

ONNX Runtime inference goes through session.run() and
session.run_with_iobinding(). Neither uses __call__. Both must
be intercepted.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import hashlib
import logging
import time
from typing import Any, List, Optional, Tuple

import numpy as np

from .base_adapter import GoldenOutput, ModelInfo, ModelType
from .inference_proxy import InferenceProxy

logger = logging.getLogger(__name__)


class OnnxAdapter:
    """Adapter for ONNX Runtime InferenceSession.

    Wraps session.run() as the primary entry point and
    session.run_with_iobinding() as an intercepted method.
    """

    def __init__(self, ort_module: Any) -> None:
        self._ort = ort_module
        self._session_cls = getattr(ort_module, "InferenceSession", None)

    # -- Detection and classification --

    def detect(self, obj: Any) -> bool:
        """Returns True if obj is an ONNX Runtime InferenceSession."""
        if self._session_cls is None:
            return False
        return isinstance(obj, self._session_cls)

    def get_model_classes(self) -> List[type]:
        """Return InferenceSession for isinstance detection."""
        if self._session_cls is None:
            return []
        return [self._session_cls]

    def get_model_info(self, model: Any) -> ModelInfo:
        """Extract ONNX model metadata from session."""
        inputs = model.get_inputs()
        outputs = model.get_outputs()

        # Infer architecture from graph name or metadata
        meta = model.get_modelmeta()
        arch = getattr(meta, "graph_name", "onnx_model") or "onnx_model"

        # Estimate parameter count from graph metadata
        param_count = 0
        custom_map = getattr(meta, "custom_metadata_map", {})
        if "param_count" in custom_map:
            try:
                param_count = int(custom_map["param_count"])
            except (ValueError, TypeError):
                pass

        # Determine device from session providers
        providers = model.get_providers()
        device = "cpu"
        if any("CUDA" in p for p in providers):
            device = "cuda"
        elif any("TensorRT" in p for p in providers):
            device = "tensorrt"

        # Determine dtype from first input
        dtype = "unknown"
        if inputs:
            dtype = inputs[0].type or "unknown"

        return ModelInfo(
            architecture=arch,
            parameter_count=param_count,
            dtype=dtype,
            device=device,
            framework="onnxruntime",
            model_class="onnxruntime.InferenceSession",
        )

    def classify_model(self, model: Any) -> ModelType:
        """Classify ONNX model by input/output structure and metadata."""
        inputs = model.get_inputs()
        outputs = model.get_outputs()

        if not inputs or not outputs:
            return ModelType.UNKNOWN

        # Check model metadata for hints
        meta = model.get_modelmeta()
        custom_map = getattr(meta, "custom_metadata_map", {})
        if "model_type" in custom_map:
            type_str = custom_map["model_type"].lower()
            for mt in ModelType:
                if mt.value == type_str:
                    return mt

        # Heuristic: check output shapes
        # Embedding models typically have high-dimensional output (>=128)
        # Classifiers typically have low-dimensional output (<128)
        if len(outputs) == 1:
            out_shape = outputs[0].shape
            if out_shape and len(out_shape) == 2:
                last_dim = out_shape[-1]
                if last_dim and isinstance(last_dim, int):
                    if last_dim >= 128:
                        return ModelType.EMBEDDING
                    else:
                        return ModelType.CLASSIFIER

        return ModelType.ENCODER

    # -- Proxy and interception --

    def wrap_forward(self, model: Any, optimizer: Any = None,
                     profiler: Any = None) -> InferenceProxy:
        """Return a proxy that intercepts session.run() and run_with_iobinding().

        Primary entry point: session.run()
        Intercepted: run_with_iobinding() for GPU-resident I/O
        """
        # ONNX users call session.run() and session.run_with_iobinding(),
        # NOT session(). Both must be intercepted via _intercepted_methods
        # because __getattr__ checks intercepted_methods BEFORE delegating.
        # invoke_fn handles proxy(...) calls; intercepted handles proxy.run(...).
        invoke_fn = model.run
        intercepted = {"run": model.run}
        if hasattr(model, "run_with_iobinding"):
            intercepted["run_with_iobinding"] = model.run_with_iobinding

        return InferenceProxy(
            model=model,
            invoke_fn=invoke_fn,
            adapter=self,
            intercepted_methods=intercepted,
            optimizer=optimizer,
            profiler=profiler,
        )

    # -- Input introspection --

    def get_input_shape(self, inputs: Any) -> Tuple[int, ...]:
        """Extract input shape from ONNX feed dict or array."""
        if isinstance(inputs, dict):
            for v in inputs.values():
                if hasattr(v, "shape"):
                    return tuple(v.shape)
        if hasattr(inputs, "shape"):
            return tuple(inputs.shape)
        return (1,)

    def get_input_dtype(self, inputs: Any) -> str:
        """Extract input dtype."""
        if isinstance(inputs, dict):
            for v in inputs.values():
                if hasattr(v, "dtype"):
                    return str(v.dtype)
        if hasattr(inputs, "dtype"):
            return str(inputs.dtype)
        return "unknown"

    def infer_batch_size(self, args: tuple) -> int:
        """Infer batch size from session.run() arguments.

        session.run(output_names, input_feed) where input_feed is a dict.
        """
        if len(args) >= 2:
            feed = args[1]
            if isinstance(feed, dict):
                for v in feed.values():
                    if hasattr(v, "shape") and len(v.shape) > 0:
                        return v.shape[0]
        return 1

    # -- Inference execution --

    def run_inference(self, model: Any, inputs: Any) -> Any:
        """Run a single forward pass via session.run()."""
        if isinstance(inputs, dict):
            output_names = [o.name for o in model.get_outputs()]
            return model.run(output_names, inputs)
        # If inputs is a numpy array, wrap in dict with first input name
        input_names = [i.name for i in model.get_inputs()]
        if len(input_names) > 0:
            feed = {input_names[0]: inputs}
            output_names = [o.name for o in model.get_outputs()]
            return model.run(output_names, feed)
        return None

    def run_generation(self, model: Any, inputs: Any) -> Any:
        """Run generation for ONNX models.

        ONNX Runtime is single-pass (no autoregressive generate concept).
        Falls back to run_inference.
        """
        return self.run_inference(model, inputs)

    def forward_batch(self, model: Any, collated: Any) -> Any:
        """Run a batched forward pass."""
        return self.run_inference(model, collated)

    def try_forward_with_batch(self, model: Any, batch_size: int) -> bool:
        """Attempt forward pass at given batch size."""
        try:
            inputs = model.get_inputs()
            if not inputs:
                return False

            feed = {}
            for inp in inputs:
                shape = list(inp.shape)
                # Replace dynamic dims with batch_size.
                # Dynamic dims in ONNX can be strings, None, or 0.
                for i, dim in enumerate(shape):
                    if isinstance(dim, str) or dim is None or dim == 0:
                        shape[i] = batch_size if i == 0 else 1

                dtype_str = inp.type
                np_dtype = _ort_type_to_numpy(dtype_str)
                feed[inp.name] = np.random.randn(*shape).astype(np_dtype)

            output_names = [o.name for o in model.get_outputs()]
            model.run(output_names, feed)
            return True
        except Exception:
            return False

    # -- Batching --

    def collate_batch(self, inputs: List[Any]) -> Any:
        """Collate individual inputs into batched array."""
        if not inputs:
            return inputs
        if isinstance(inputs[0], dict):
            # Merge feed dicts by stacking arrays
            keys = inputs[0].keys()
            collated = {}
            for k in keys:
                arrays = [inp[k] for inp in inputs]
                collated[k] = np.concatenate(arrays, axis=0)
            return collated
        if isinstance(inputs[0], np.ndarray):
            return np.concatenate(inputs, axis=0)
        return inputs

    def split_batch(self, output: Any, batch_size: int) -> List[Any]:
        """Split batched output into individual results."""
        if isinstance(output, (list, tuple)):
            # ONNX returns list of output arrays
            if len(output) > 0 and isinstance(output[0], np.ndarray):
                return [
                    [arr[i:i + 1] for arr in output]
                    for i in range(min(batch_size, output[0].shape[0]))
                ]
            return output
        if isinstance(output, np.ndarray):
            return [output[i:i + 1] for i in range(min(batch_size, output.shape[0]))]
        return [output]

    # -- GPU timing and memory --

    def create_timing_event(self) -> Any:
        """Create a timing event for ONNX Runtime inference.

        ONNX Runtime does not expose CUDA events through its Python API.
        Returns a wall-clock timestamp. The profiler records this as
        gpu_time, which for ONNX is an approximation (wall time includes
        CPU overhead). For GPU-executed sessions, this overestimates
        slightly; for CPU sessions, it IS the execution time.
        """
        return time.perf_counter()

    def resolve_timing_event(self, event: Any) -> float:
        """Resolve wall-clock timing event to elapsed SECONDS.

        Note: For ONNX Runtime, this is wall time, not GPU kernel time.
        See create_timing_event() for details.
        """
        if event is None:
            return 0.0
        return time.perf_counter() - event

    def get_gpu_utilization(self) -> float:
        """Current GPU compute utilization via NVML."""
        try:
            import pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            util = pynvml.nvmlDeviceGetUtilizationRates(handle)
            pynvml.nvmlShutdown()
            return util.gpu / 100.0
        except Exception:
            return 0.0

    def get_gpu_memory_utilization(self) -> float:
        """Current GPU memory utilization via NVML."""
        try:
            import pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
            pynvml.nvmlShutdown()
            return mem.used / mem.total if mem.total > 0 else 0.0
        except Exception:
            return 0.0

    def estimate_model_memory(self, model: Any) -> int:
        """Estimate memory from ONNX model size."""
        # ONNX Runtime doesn't expose parameter count directly
        # Use the metadata if available
        meta = model.get_modelmeta()
        custom_map = getattr(meta, "custom_metadata_map", {})
        if "model_size_bytes" in custom_map:
            try:
                return int(custom_map["model_size_bytes"])
            except (ValueError, TypeError):
                pass
        return 0

    def measure_per_sample_memory(self, model: Any) -> int:
        """Measure additional memory per sample."""
        return 0  # Not easily measurable for ORT

    # -- Pinned memory --

    def get_expected_input_shape(self, batch_size: int) -> Tuple[int, ...]:
        return (batch_size, 1)

    def pin_host_buffer(self, shape: Tuple[int, ...]) -> None:
        pass  # ONNX Runtime manages its own memory arena

    # -- Golden capture and validation --

    def capture_golden(self, model: Any, n: int) -> List[GoldenOutput]:
        """Generate n reference outputs using random inputs."""
        goldens = []
        inputs = model.get_inputs()
        if not inputs:
            return goldens

        for _ in range(n):
            feed = {}
            for inp in inputs:
                shape = list(inp.shape)
                for i, dim in enumerate(shape):
                    if isinstance(dim, str) or dim is None or dim == 0:
                        shape[i] = 1
                np_dtype = _ort_type_to_numpy(inp.type)
                feed[inp.name] = np.random.randn(*shape).astype(np_dtype)

            output_names = [o.name for o in model.get_outputs()]
            try:
                output = model.run(output_names, feed)
            except Exception:
                continue

            goldens.append(
                GoldenOutput(
                    inputs=feed,
                    outputs=output,
                    metadata={
                        "model_type": self.classify_model(model).value,
                        "dtype": inputs[0].type,
                    },
                )
            )
        return goldens

    def outputs_match(self, expected: Any, actual: Any, tolerance: float) -> bool:
        """Verify outputs within tolerance using numpy.allclose."""
        if isinstance(expected, list) and isinstance(actual, list):
            if len(expected) != len(actual):
                return False
            # Compare each pair; require at least one comparison to succeed
            comparisons = 0
            for e, a in zip(expected, actual):
                if isinstance(e, np.ndarray) and isinstance(a, np.ndarray):
                    if not np.allclose(e, a, atol=tolerance, rtol=1e-3):
                        return False
                    comparisons += 1
                else:
                    if e != a:
                        return False
                    comparisons += 1
            return comparisons > 0
        if isinstance(expected, np.ndarray) and isinstance(actual, np.ndarray):
            return bool(np.allclose(expected, actual, atol=tolerance, rtol=1e-3))
        return expected == actual

    def detach_to_cpu(self, tensor: Any) -> Any:
        """ONNX outputs are already numpy arrays on CPU."""
        if isinstance(tensor, list):
            return [np.array(t) if not isinstance(t, np.ndarray) else t.copy()
                    for t in tensor]
        if isinstance(tensor, np.ndarray):
            return tensor.copy()
        return tensor

    def extract_logits(self, outputs: Any) -> Optional[Any]:
        """Extract logits from ONNX output list."""
        if isinstance(outputs, list) and len(outputs) > 0:
            return outputs[0]
        return None

    # -- Tensor conversion --

    def to_numpy(self, tensor: Any) -> Any:
        if isinstance(tensor, np.ndarray):
            return tensor
        if isinstance(tensor, list) and tensor:
            return np.array(tensor[0]) if isinstance(tensor[0], np.ndarray) else np.array(tensor)
        return np.array(tensor)

    def to_token_ids(self, outputs: Any) -> List[int]:
        if isinstance(outputs, list) and outputs:
            arr = outputs[0]
            if isinstance(arr, np.ndarray):
                return arr.flatten().astype(int).tolist()
        return []

    def max_abs_error(self, expected: Any, actual: Any) -> float:
        exp_arr = self.to_numpy(expected)
        act_arr = self.to_numpy(actual)
        return float(np.max(np.abs(exp_arr.astype(float) - act_arr.astype(float))))

    # -- Compilation (v1 beta) --

    def compile(self, model: Any, config: Any) -> Any:
        """ONNX Runtime graph optimization (not torch.compile)."""
        return None  # ORT optimization is configured at session creation

    def hash_model(self, model: Any) -> str:
        h = hashlib.sha256()
        meta = model.get_modelmeta()
        h.update(getattr(meta, "graph_name", "").encode())
        h.update(str(getattr(meta, "version", 0)).encode())
        return h.hexdigest()[:16]

    def get_input_shape_signature(self, model: Any) -> str:
        inputs = model.get_inputs()
        parts = []
        for inp in inputs:
            parts.append(f"{inp.name}:{inp.shape}")
        return "_".join(parts)


def _ort_type_to_numpy(ort_type: str) -> type:
    """Convert ONNX Runtime type string to numpy dtype."""
    type_map = {
        "tensor(float)": np.float32,
        "tensor(float16)": np.float16,
        "tensor(bfloat16)": np.float32,  # numpy has no bfloat16; use float32
        "tensor(double)": np.float64,
        "tensor(int8)": np.int8,
        "tensor(int16)": np.int16,
        "tensor(int32)": np.int32,
        "tensor(int64)": np.int64,
        "tensor(uint8)": np.uint8,
        "tensor(uint16)": np.uint16,
        "tensor(uint32)": np.uint32,
        "tensor(uint64)": np.uint64,
        "tensor(bool)": np.bool_,
        "tensor(string)": np.object_,
    }
    return type_map.get(ort_type, np.float32)
