"""
InferenceOTelExporter - OpenTelemetry metric export for inference.

Maps InferenceMetrics, CostEstimator, and safety data to OTel
instrument names defined in spec Section 8.1.

This exporter produces a dict of {instrument_name: value} for
integration with OTel SDKs. The actual OTel SDK integration
(meter provider, periodic reader) is left to the deployment layer.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class InferenceOTelExporter:
    """Maps inference metrics to OTel instrument names.

    Produces a dict of {instrument_name: value} matching the
    spec Section 8.1 instrument definitions.

    Only instruments with available data are included in the output.
    Instruments without data are omitted rather than reported as zero
    to avoid misleading dashboard displays.
    """

    # All OTel instrument names from spec Section 8.1
    INSTRUMENT_NAMES = [
        "epochly.inference.latency",
        "epochly.inference.throughput",
        "epochly.inference.ttft",
        "epochly.inference.batch_util",
        "epochly.inference.gpu_mem",
        "epochly.inference.gpu_util",
        "epochly.inference.cache_hit",
        "epochly.inference.level",
        "epochly.inference.cost_baseline_1k",
        "epochly.inference.cost_optimized_1k",
        "epochly.inference.savings_projected_hourly",
        "epochly.inference.preprocess",
        "epochly.inference.quant_delta",
        # Safety metrics (spec Section 10.12)
        "epochly.inference.safety.canary_result",
        "epochly.inference.safety.canary_duration",
        "epochly.inference.safety.cb_state",
        "epochly.inference.safety.cb_trips",
        "epochly.inference.safety.drift_score",
        "epochly.inference.safety.drift_alerts",
        "epochly.inference.safety.fallbacks",
        "epochly.inference.safety.active_level",
        "epochly.inference.safety.shadow_latency",
        "epochly.inference.safety.golden_count",
        "epochly.inference.safety.hysteresis_blocks",
    ]

    def export(self, metrics: Any) -> Dict[str, Any]:
        """Export InferenceMetrics data as OTel-named dict.

        Only includes instruments for which real data is available.
        Instruments that cannot be computed from current metrics state
        are omitted from the output.

        Args:
            metrics: InferenceMetrics instance

        Returns:
            Dict mapping OTel instrument names to current values.
        """
        all_metrics = metrics.get_all_metrics()
        cache_stats = metrics.get_cache_stats()

        result: Dict[str, Any] = {}

        # Request-level metrics
        request_count = all_metrics.get("requests", {}).get("count", 0)
        if request_count > 0:
            result["epochly.inference.latency"] = all_metrics["requests"]["avg_latency_ms"]

        # Per-model metrics (aggregate across models)
        total_batch = 0
        total_count = 0
        for model_id, model_data in all_metrics.get("models", {}).items():
            total_count += model_data.get("count", 0)
            stats = metrics.get_model_stats(model_id)
            if stats:
                total_batch += stats.get("avg_batch_size", 0) * stats.get("count", 0)

        if total_count > 0:
            result["epochly.inference.batch_util"] = total_batch / total_count

        # GPU metrics (from latest model stats)
        for model_id in all_metrics.get("models", {}):
            stats = metrics.get_model_stats(model_id)
            if stats:
                gpu_mem = stats.get("avg_gpu_memory", 0)
                gpu_util = stats.get("avg_gpu_utilization", 0)
                if gpu_mem > 0:
                    result["epochly.inference.gpu_mem"] = gpu_mem * 100
                if gpu_util > 0:
                    result["epochly.inference.gpu_util"] = gpu_util * 100
                break  # Use first model for GPU metrics

        # Cache hit rate (always available if cache is tracked)
        cache_hit_rate = cache_stats.get("hit_rate", 0)
        total_cache_ops = cache_stats.get("hits", 0) + cache_stats.get("misses", 0)
        if total_cache_ops > 0:
            result["epochly.inference.cache_hit"] = cache_hit_rate

        return result

    def export_cost(self, cost_estimator: Any) -> Dict[str, Any]:
        """Export CostEstimator data as OTel-named dict."""
        base_cost, opt_cost = cost_estimator.cost_per_1k_requests
        return {
            "epochly.inference.cost_baseline_1k": base_cost,
            "epochly.inference.cost_optimized_1k": opt_cost,
            "epochly.inference.savings_projected_hourly": cost_estimator.projected_hourly_savings,
        }

    def export_safety(
        self,
        breakers: Optional[Dict[str, Any]] = None,
        drift_monitor: Optional[Any] = None,
        golden_store: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """Export safety system metrics as OTel-named dict.

        Only includes instruments with actual data from the safety subsystem.
        """
        result: Dict[str, Any] = {}

        if breakers:
            total_trips = 0
            for name, breaker in breakers.items():
                state_map = {"closed": 0, "open": 1, "half_open": 2}
                result["epochly.inference.safety.cb_state"] = state_map.get(
                    breaker.state.value, -1
                )
                total_trips += breaker.total_trips
            result["epochly.inference.safety.cb_trips"] = total_trips

        if drift_monitor:
            diag = drift_monitor.get_diagnostics()
            ewma_scores = diag.get("ewma_scores", {})
            if ewma_scores:
                result["epochly.inference.safety.drift_score"] = sum(
                    sum(v.values()) for v in ewma_scores.values()
                )

        if golden_store:
            counts = golden_store.get_all_sample_counts()
            total_golden = sum(counts.values())
            if total_golden > 0:
                result["epochly.inference.safety.golden_count"] = total_golden

        return result
