"""
CostEstimator - Per-request GPU cost estimation and savings projection.

Calculates cost savings by comparing optimized vs baseline GPU-seconds
per request, scaled to observed traffic volume.

This is engineering telemetry, not finance-grade billing.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

# Default on-demand GPU pricing (configurable)
_GPU_PRICING = {
    "A100_40GB": 3.40,
    "A100_80GB": 4.10,
    "A10G": 1.21,
    "H100": 5.50,
    "L4": 0.81,
    "T4": 0.53,
}

_DEFAULT_RATE = 1.00  # $/hour fallback for unknown GPUs


class CostEstimator:
    """Per-request GPU cost estimation and savings projection.

    Thread-safe.
    """

    def __init__(
        self, gpu_name: str, custom_rate: Optional[float] = None
    ) -> None:
        self._rate_per_hour = custom_rate if custom_rate and custom_rate > 0 else self._match_gpu_rate(gpu_name)
        self._rate_per_second = self._rate_per_hour / 3600.0
        self._baseline_gpu_seconds: float = 0.0
        self._optimized_gpu_seconds: float = 0.0
        self._request_count: int = 0
        self._observation_start: float = time.time()
        self._lock = threading.Lock()

    def _match_gpu_rate(self, gpu_name: str) -> float:
        """Match GPU name to pricing. Falls back to default rate."""
        # Try exact match first
        if gpu_name in _GPU_PRICING:
            return _GPU_PRICING[gpu_name]
        # Try case-insensitive partial match
        gpu_lower = gpu_name.lower()
        for name, rate in _GPU_PRICING.items():
            if name.lower() in gpu_lower or gpu_lower in name.lower():
                return rate
        logger.warning(
            "Unknown GPU '%s', using default rate $%.2f/hr", gpu_name, _DEFAULT_RATE
        )
        return _DEFAULT_RATE

    def record_inference(
        self, baseline_gpu_seconds: float, optimized_gpu_seconds: float
    ) -> None:
        """Record a single inference for cost tracking."""
        with self._lock:
            self._baseline_gpu_seconds += baseline_gpu_seconds
            self._optimized_gpu_seconds += optimized_gpu_seconds
            self._request_count += 1

    @property
    def gpu_seconds_per_request(self) -> Tuple[float, float]:
        """(baseline, optimized) GPU-seconds per request."""
        with self._lock:
            if self._request_count == 0:
                return 0.0, 0.0
            return (
                self._baseline_gpu_seconds / self._request_count,
                self._optimized_gpu_seconds / self._request_count,
            )

    @property
    def cost_per_1k_requests(self) -> Tuple[float, float]:
        """(baseline, optimized) cost per 1K requests in USD."""
        base_per_req, opt_per_req = self.gpu_seconds_per_request
        return (
            base_per_req * self._rate_per_second * 1000,
            opt_per_req * self._rate_per_second * 1000,
        )

    @property
    def observed_requests_per_hour(self) -> float:
        """Observed request rate based on actual traffic."""
        with self._lock:
            elapsed_hours = max(
                (time.time() - self._observation_start) / 3600.0, 1 / 3600
            )
            return self._request_count / elapsed_hours

    @property
    def projected_hourly_savings(self) -> float:
        """Projected USD savings per hour at observed traffic volume.

        Single lock acquisition for consistent snapshot of all counters.
        """
        with self._lock:
            if self._request_count == 0:
                return 0.0
            saved_per_request = (
                self._baseline_gpu_seconds - self._optimized_gpu_seconds
            ) / self._request_count
            elapsed_hours = max(
                (time.time() - self._observation_start) / 3600.0, 1 / 3600
            )
            requests_per_hour = self._request_count / elapsed_hours
        return saved_per_request * self._rate_per_second * requests_per_hour

    @property
    def projected_monthly_savings(self) -> float:
        """Projected USD savings per month (730 hours) at observed traffic."""
        return self.projected_hourly_savings * 730
