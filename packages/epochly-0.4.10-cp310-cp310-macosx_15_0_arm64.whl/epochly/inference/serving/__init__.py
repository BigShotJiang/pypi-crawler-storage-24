"""
Serving-layer integrations for AI inference.

Provides ASGI middleware, FastAPI dependency helper, and runtime companions.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""
