"""
LLMCompanionAdapter - Control layer for vLLM/TGI deployments.

Does NOT replace the LLM runtime's core optimizations (continuous
batching, attention kernels, KV-cache management). Instead provides:
- Admission control via async semaphore
- Request caching (identical prompt deduplication)
- Cost attribution and savings reporting

Uses stdlib urllib.request for HTTP forwarding when httpx/aiohttp
are not available.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import asyncio
import collections
import hashlib
import json
import logging
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Prefer httpx for async HTTP, fall back to stdlib urllib
_httpx_available = False
_httpx: Any = None
try:
    import httpx as _httpx

    _httpx_available = True
except ImportError:
    logger.debug("httpx not available; using stdlib urllib for LLM companion HTTP")


@dataclass
class LLMCompanionConfig:
    """Configuration for LLM companion mode."""

    max_concurrent_requests: int = 64
    cache_enabled: bool = True
    cache_max_size: int = 10_000
    default_timeout_seconds: float = 120.0
    api_path: str = "/v1/completions"


class _LRUPromptCache:
    """Async-safe LRU cache for prompt deduplication.

    Bounded by max_size entries. Uses collections.OrderedDict for
    O(1) lookups and O(1) LRU eviction via move_to_end().
    """

    def __init__(self, max_size: int) -> None:
        self._max_size = max_size
        self._store: collections.OrderedDict[str, str] = collections.OrderedDict()
        self._lock = asyncio.Lock()

    async def get(self, key: str) -> Optional[str]:
        """Look up a cached response by key."""
        async with self._lock:
            if key in self._store:
                # Move to end (most recently used) -- O(1)
                self._store.move_to_end(key)
                return self._store[key]
            return None

    async def put(self, key: str, value: str) -> None:
        """Store a response in the cache."""
        async with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                self._store[key] = value
            else:
                if len(self._store) >= self._max_size:
                    # Evict LRU entry (first item) -- O(1)
                    self._store.popitem(last=False)
                self._store[key] = value


class LLMCompanionAdapter:
    """Control and visibility layer for vLLM/TGI deployments.

    Sits between the application and the LLM runtime, providing:

    1. Admission control: Limits concurrent requests to the runtime
       via an asyncio.Semaphore. Prevents overloading the GPU.

    2. Request caching: Identical prompts with identical parameters
       return cached results. The cache key is derived from the prompt
       text and all generation parameters.

    3. Cost attribution: Tracks total requests, cache hits, and
       per-request latencies for cost reporting.

    The companion does NOT:
    - Replace continuous batching (vLLM/TGI handle this)
    - Manage attention kernels or KV-cache
    - Modify model weights or precision
    """

    def __init__(
        self,
        runtime_url: str,
        config: Optional[LLMCompanionConfig] = None,
    ) -> None:
        self._runtime_url = runtime_url.rstrip("/")
        self._config = config or LLMCompanionConfig()
        self._admission = asyncio.Semaphore(self._config.max_concurrent_requests)
        self._cache: Optional[_LRUPromptCache] = None
        if self._config.cache_enabled:
            self._cache = _LRUPromptCache(self._config.cache_max_size)

        # In-flight request coalescing: concurrent identical prompts share one backend call
        self._inflight: Dict[str, asyncio.Task] = {}
        self._inflight_lock = asyncio.Lock()

        # Metrics (safe under single event loop -- asyncio is single-threaded)
        self._total_requests = 0
        self._cache_hits = 0
        self._total_latency_ms = 0.0
        self._error_count = 0

    async def generate(self, prompt: str, **kwargs: Any) -> str:
        """Generate a completion via the LLM runtime.

        Flow:
        1. Check cache for identical (prompt + params) -> return cached
        2. Acquire admission semaphore
        3. Forward request to runtime
        4. Cache and return result

        Args:
            prompt: The input prompt text.
            **kwargs: Generation parameters (temperature, max_tokens, etc.)

        Returns:
            Generated text from the LLM runtime.
        """
        self._total_requests += 1
        start = time.perf_counter()

        # Check cache
        cache_key = self._make_cache_key(prompt, kwargs)
        if self._cache is not None:
            cached = await self._cache.get(cache_key)
            if cached is not None:
                self._cache_hits += 1
                elapsed = (time.perf_counter() - start) * 1000
                self._total_latency_ms += elapsed
                return cached

        # In-flight coalescing: if an identical request is already in progress,
        # await its result instead of making a duplicate backend call.
        # IMPORTANT: lock is released BEFORE await to allow concurrent waiters.
        existing_task = None
        async with self._inflight_lock:
            if cache_key in self._inflight:
                existing_task = self._inflight[cache_key]

        if existing_task is not None:
            # Coalesce: await the shared task (lock is NOT held)
            result = await existing_task
            self._cache_hits += 1
            elapsed = (time.perf_counter() - start) * 1000
            self._total_latency_ms += elapsed
            return result

        # No in-flight request — create one
        async with self._inflight_lock:
            # Double-check after re-acquiring lock
            if cache_key in self._inflight:
                existing_task = self._inflight[cache_key]
            else:
                task = asyncio.create_task(
                    self._execute_and_cache(cache_key, prompt, kwargs)
                )
                self._inflight[cache_key] = task

        if existing_task is not None:
            result = await existing_task
            self._cache_hits += 1
            elapsed = (time.perf_counter() - start) * 1000
            self._total_latency_ms += elapsed
            return result

        try:
            result = await task
        finally:
            async with self._inflight_lock:
                self._inflight.pop(cache_key, None)

        elapsed = (time.perf_counter() - start) * 1000
        self._total_latency_ms += elapsed
        return result

    async def _execute_and_cache(
        self, cache_key: str, prompt: str, kwargs: dict
    ) -> str:
        """Execute a backend call with admission control and cache the result."""
        async with self._admission:
            result = await self._forward_to_runtime(prompt, **kwargs)

        if self._cache is not None:
            await self._cache.put(cache_key, result)

        return result

    async def _forward_to_runtime(self, prompt: str, **kwargs: Any) -> str:
        """Forward a generation request to the LLM runtime.

        Uses httpx for async HTTP if available, otherwise falls back
        to stdlib urllib.request in a thread executor.

        Args:
            prompt: The input prompt text.
            **kwargs: Generation parameters.

        Returns:
            Generated text from the runtime response.

        Raises:
            RuntimeError: If the request fails.
        """
        url = f"{self._runtime_url}{self._config.api_path}"
        payload = {"prompt": prompt, **kwargs}

        if _httpx_available:
            return await self._forward_httpx(url, payload)
        return await self._forward_urllib(url, payload)

    async def _forward_httpx(self, url: str, payload: dict) -> str:
        """Forward using httpx async client."""
        async with _httpx.AsyncClient(
            timeout=self._config.default_timeout_seconds
        ) as client:
            try:
                response = await client.post(url, json=payload)
                response.raise_for_status()
                data = response.json()
                return self._extract_text(data)
            except Exception as exc:
                self._error_count += 1
                raise RuntimeError(
                    f"LLM runtime request failed: {exc}"
                ) from exc

    async def _forward_urllib(self, url: str, payload: dict) -> str:
        """Forward using stdlib urllib in a thread executor."""
        loop = asyncio.get_running_loop()

        def _sync_request() -> str:
            req_data = json.dumps(payload).encode("utf-8")
            request = urllib.request.Request(
                url,
                data=req_data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            try:
                with urllib.request.urlopen(
                    request, timeout=self._config.default_timeout_seconds
                ) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    return self._extract_text(data)
            except urllib.error.URLError as exc:
                raise RuntimeError(
                    f"LLM runtime request failed: {exc}"
                ) from exc

        try:
            return await loop.run_in_executor(None, _sync_request)
        except Exception:
            self._error_count += 1
            raise

    @staticmethod
    def _extract_text(response_data: dict) -> str:
        """Extract generated text from runtime response.

        Handles both OpenAI-compatible and TGI response formats.

        Args:
            response_data: JSON response from the runtime.

        Returns:
            Generated text string.
        """
        # OpenAI-compatible format
        if "choices" in response_data:
            choices = response_data["choices"]
            if choices and isinstance(choices, list):
                choice = choices[0]
                if "text" in choice:
                    return choice["text"]
                if "message" in choice and "content" in choice["message"]:
                    return choice["message"]["content"]

        # TGI format
        if "generated_text" in response_data:
            return response_data["generated_text"]

        # Fallback: return the whole response as string
        return json.dumps(response_data)

    @staticmethod
    def _make_cache_key(prompt: str, kwargs: dict) -> str:
        """Create a deterministic cache key from prompt and parameters.

        Uses SHA-256 hash of the prompt and sorted kwargs to ensure
        consistent key generation regardless of parameter order.

        Args:
            prompt: The input prompt text.
            kwargs: Generation parameters.

        Returns:
            Hex digest cache key.
        """
        key_data = json.dumps(
            {"prompt": prompt, "params": kwargs},
            sort_keys=True,
            default=str,
        )
        return hashlib.sha256(key_data.encode("utf-8")).hexdigest()

    def get_stats(self) -> dict:
        """Return companion statistics for cost attribution.

        Returns:
            Dict with total_requests, cache_hits, avg_latency_ms, error_count.
        """
        return {
            "total_requests": self._total_requests,
            "cache_hits": self._cache_hits,
            "cache_hit_rate": (
                self._cache_hits / self._total_requests
                if self._total_requests > 0
                else 0.0
            ),
            "avg_latency_ms": (
                self._total_latency_ms / self._total_requests
                if self._total_requests > 0
                else 0.0
            ),
            "error_count": self._error_count,
        }
