"""
ASGI Middleware for Python inference services.

ASGI-first: works with any ASGI framework (FastAPI, Starlette, Litestar).
FastAPI is the primary test target.

Provides:
- RequestContext via contextvars for per-request timing attribution
- Timing decomposition: queue, handler, serialize, model-call
- Concurrency limiting via semaphore

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
import uuid
from typing import Any, Callable, Optional

from ..context import RequestContext, reset_request_context, set_request_context

logger = logging.getLogger(__name__)


class EpochlyInferenceMiddleware:
    """ASGI middleware for inference service observability and control.

    Installs via: ``app.add_middleware(EpochlyInferenceMiddleware)``

    Timing semantics:
    - queue_ms: time waiting for concurrency semaphore
    - app_wall_ms: total wall time of downstream ASGI app
    - serialize_ms: time from first response body chunk to last
    - total_ms: queue_ms + app_wall_ms (end-to-end middleware time)

    IMPORTANT: serialize_ms is a sub-interval of app_wall_ms, NOT additive.
    """

    def __init__(
        self,
        app: Any,
        max_concurrency: int = 64,
        config: Any = None,
    ) -> None:
        self._app = app
        self._max_concurrency = max_concurrency
        self._concurrency = asyncio.Semaphore(max_concurrency)
        self._config = config
        self._request_count = 0
        self._total_latency_ms = 0.0
        self._stats_lock = threading.Lock()

    async def __call__(
        self, scope: dict, receive: Callable, send: Callable
    ) -> None:
        """ASGI interface.

        Note:
        - scope["headers"] is a list of [name, value] byte pairs, NOT a dict
        - ASGI middleware does not receive a response object
        """
        if scope["type"] != "http":
            await self._app(scope, receive, send)
            return

        start = time.perf_counter()

        # Extract traceparent from ASGI headers
        trace_id = None
        for header_name, header_value in scope.get("headers", []):
            if header_name == b"traceparent":
                trace_id = header_value.decode("latin-1")
                break

        # Set request context for downstream attribution
        ctx = RequestContext(
            request_id=str(uuid.uuid4()),
            endpoint=scope.get("path", "/"),
            enqueue_time=start,
            trace_id=trace_id,
        )
        token = set_request_context(ctx)

        # Queue time: time waiting for concurrency semaphore
        queue_start = time.perf_counter()

        try:
            async with self._concurrency:
                admit_time = time.perf_counter()
                ctx.timings["queue_ms"] = (admit_time - queue_start) * 1000

                # Send wrapper: captures serialize timing
                first_body_time: Optional[float] = None
                last_body_time: Optional[float] = None

                async def timed_send(message: dict) -> None:
                    nonlocal first_body_time, last_body_time
                    if message.get("type") == "http.response.body":
                        now = time.perf_counter()
                        if first_body_time is None:
                            first_body_time = now
                        last_body_time = now
                    await send(message)

                handler_start = time.perf_counter()
                await self._app(scope, receive, timed_send)
                handler_end = time.perf_counter()

                ctx.timings["app_wall_ms"] = (handler_end - handler_start) * 1000
                if first_body_time is not None and last_body_time is not None:
                    ctx.timings["serialize_ms"] = (
                        last_body_time - first_body_time
                    ) * 1000
        finally:
            reset_request_context(token)

            elapsed = time.perf_counter() - start
            elapsed_ms = elapsed * 1000

            with self._stats_lock:
                self._request_count += 1
                self._total_latency_ms += elapsed_ms

            logger.debug(
                "Request %s to %s completed in %.1fms "
                "(queue: %.1fms, app: %.1fms, serialize: %.1fms, model_calls: %d)",
                ctx.request_id,
                ctx.endpoint,
                elapsed_ms,
                ctx.timings.get("queue_ms", 0),
                ctx.timings.get("app_wall_ms", 0),
                ctx.timings.get("serialize_ms", 0),
                ctx.model_calls,
            )

    @property
    def request_count(self) -> int:
        """Total requests processed."""
        with self._stats_lock:
            return self._request_count

    @property
    def avg_latency_ms(self) -> float:
        """Average total latency in milliseconds."""
        with self._stats_lock:
            if self._request_count == 0:
                return 0.0
            return self._total_latency_ms / self._request_count
