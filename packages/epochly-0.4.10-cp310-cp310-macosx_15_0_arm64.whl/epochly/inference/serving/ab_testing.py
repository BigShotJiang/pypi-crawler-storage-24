"""
ABModelComparison - A/B testing for model variants.

Routes a configurable percentage of traffic to model B (challenger),
compares outputs using workload-specific validators, and reports
metrics for each variant.

Supports two modes:
  - Split mode (default): Each request goes to either A or B based on
    traffic_split probability.
  - Shadow mode: Both models run for every request, but only model A's
    result is returned. Both results are recorded for comparison.

Also provides:
  - Statistical significance via Welch's t-test (scipy optional).
  - GradualRollout for staged traffic ramping with health checks.
  - MultiModelComparison for A/B/n testing with weighted traffic.

Thread-safe: all metric recording is protected by a lock.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import math
import random
import statistics
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional, Tuple

try:
    from scipy.stats import ttest_ind as _scipy_ttest_ind
except ImportError:
    _scipy_ttest_ind = None

logger = logging.getLogger(__name__)

# Maximum number of latency samples retained per model
_MAX_LATENCY_SAMPLES = 10_000

# Z critical values for common confidence levels
_Z_CRIT_TABLE = {
    0.80: 1.282,
    0.85: 1.440,
    0.90: 1.645,
    0.95: 1.960,
    0.99: 2.576,
    0.995: 2.807,
    0.999: 3.291,
}


def _z_crit_for_confidence(confidence_level: float) -> float:
    """Get z critical value for a confidence level.

    Uses lookup table for common values, interpolates otherwise.
    """
    if confidence_level in _Z_CRIT_TABLE:
        return _Z_CRIT_TABLE[confidence_level]
    # Linear interpolation between nearest table entries
    levels = sorted(_Z_CRIT_TABLE.keys())
    for i in range(len(levels) - 1):
        if levels[i] <= confidence_level <= levels[i + 1]:
            frac = (confidence_level - levels[i]) / (levels[i + 1] - levels[i])
            return _Z_CRIT_TABLE[levels[i]] + frac * (
                _Z_CRIT_TABLE[levels[i + 1]] - _Z_CRIT_TABLE[levels[i]]
            )
    return 1.96  # Fallback to 95%


@dataclass
class _ModelMetrics:
    """Internal per-model metrics accumulator.

    All fields are mutated under the parent ABModelComparison lock.
    """

    request_count: int = 0
    total_latency_ms: float = 0.0
    latencies: Deque[float] = field(default_factory=lambda: deque(maxlen=_MAX_LATENCY_SAMPLES))
    error_count: int = 0

    def record(self, latency_ms: float) -> None:
        """Record a single inference latency."""
        self.request_count += 1
        self.total_latency_ms += latency_ms
        self.latencies.append(latency_ms)

    def record_error(self) -> None:
        """Record an inference error."""
        self.error_count += 1

    def to_dict(self) -> dict:
        """Export metrics as a dictionary."""
        avg = self.total_latency_ms / self.request_count if self.request_count > 0 else 0.0
        return {
            "request_count": self.request_count,
            "total_latency_ms": self.total_latency_ms,
            "avg_latency_ms": avg,
            "error_count": self.error_count,
        }


# ---------------------------------------------------------------------------
# Welch's t-test fallback (when scipy is not available)
# ---------------------------------------------------------------------------


def _welch_ttest_manual(
    sample_a: List[float], sample_b: List[float],
    confidence_level: float = 0.95,
) -> Tuple[Optional[float], Tuple[Optional[float], Optional[float]]]:
    """Compute Welch's t-test without scipy.

    Returns (p_value, (ci_lower, ci_upper)) for the difference of means.
    Returns (None, (None, None)) when data is insufficient.
    """
    n_a = len(sample_a)
    n_b = len(sample_b)

    if n_a < 2 or n_b < 2:
        return None, (None, None)

    mean_a = sum(sample_a) / n_a
    mean_b = sum(sample_b) / n_b

    var_a = sum((x - mean_a) ** 2 for x in sample_a) / (n_a - 1)
    var_b = sum((x - mean_b) ** 2 for x in sample_b) / (n_b - 1)

    se_a = var_a / n_a
    se_b = var_b / n_b
    se_diff = math.sqrt(se_a + se_b)

    if se_diff == 0:
        # Both samples have zero variance - identical distributions
        return 1.0, (0.0, 0.0)

    t_stat = (mean_a - mean_b) / se_diff

    # Welch-Satterthwaite degrees of freedom
    numerator = (se_a + se_b) ** 2
    denominator = (se_a ** 2 / (n_a - 1)) + (se_b ** 2 / (n_b - 1))
    if denominator == 0:
        return 1.0, (0.0, 0.0)
    df = numerator / denominator

    # Two-tailed p-value approximation via normal CDF for large df
    # For df > 30, t-distribution approximates normal
    abs_t = abs(t_stat)
    if df > 30:
        # Normal approximation: P(|Z| > t) using Abramowitz & Stegun 26.2.17
        p_value = 2.0 * _normal_sf(abs_t)
    else:
        # Rough t-distribution approximation
        p_value = 2.0 * _t_sf(abs_t, df)

    # Confidence interval for difference of means
    z_crit = _z_crit_for_confidence(confidence_level)
    ci_lower = (mean_a - mean_b) - z_crit * se_diff
    ci_upper = (mean_a - mean_b) + z_crit * se_diff

    return max(0.0, min(1.0, p_value)), (ci_lower, ci_upper)


def _normal_sf(x: float) -> float:
    """Survival function (1 - CDF) of standard normal distribution.

    Uses Abramowitz & Stegun 26.2.17 rational approximation.
    Accurate to ~1e-5 for all x.
    """
    if x < 0:
        return 1.0 - _normal_sf(-x)

    b0 = 0.2316419
    b1 = 0.319381530
    b2 = -0.356563782
    b3 = 1.781477937
    b4 = -1.821255978
    b5 = 1.330274429

    t = 1.0 / (1.0 + b0 * x)
    phi = math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)
    poly = t * (b1 + t * (b2 + t * (b3 + t * (b4 + t * b5))))
    return phi * poly


def _t_sf(x: float, df: float) -> float:
    """Rough survival function approximation for Student's t-distribution.

    Uses the normal approximation with a correction for finite degrees
    of freedom. Good enough for p-value estimation in A/B testing.
    """
    # Cornish-Fisher expansion: z = x * (1 - 1/(4*df))
    z = x * (1.0 - 1.0 / (4.0 * max(df, 1)))
    return _normal_sf(z)


# ---------------------------------------------------------------------------
# ABModelComparison
# ---------------------------------------------------------------------------


class ABModelComparison:
    """A/B testing for model variants.

    Routes a configurable percentage of traffic to model B (challenger),
    compares outputs using workload-specific validators, and reports
    metrics for each variant.

    Args:
        model_a: The production (champion) model callable.
        model_b: The challenger model callable.
        adapter: InferenceAdapter for running inference.
        traffic_split: Fraction of traffic routed to model B (0.0 to 1.0).
        shadow: If True, run both models for every request but only return
                model A's result. Useful for safe comparison without
                affecting user-facing latency distribution.

    Raises:
        ValueError: If traffic_split is outside [0.0, 1.0].
    """

    def __init__(
        self,
        model_a: Any,
        model_b: Any,
        adapter: Any,
        traffic_split: float = 0.1,
        shadow: bool = False,
    ) -> None:
        if not (0.0 <= traffic_split <= 1.0):
            raise ValueError(
                f"traffic_split must be between 0.0 and 1.0 (inclusive), got {traffic_split}"
            )

        self._model_a = model_a
        self._model_b = model_b
        self._adapter = adapter
        self._traffic_split = traffic_split
        self._shadow = shadow

        self._metrics_a = _ModelMetrics()
        self._metrics_b = _ModelMetrics()
        self._lock = threading.Lock()

    def infer(self, input_data: Any, **kwargs: Any) -> Any:
        """Route request to A or B based on traffic split.

        In shadow mode, both models run and model A's result is returned.
        In split mode, exactly one model runs per request.

        Args:
            input_data: Input to pass to the model via the adapter.
            **kwargs: Additional keyword arguments forwarded to run_inference.

        Returns:
            Model output from the selected model (or model A in shadow mode).
        """
        if self._shadow:
            return self._run_shadow(input_data, **kwargs)
        return self._run_split(input_data, **kwargs)

    def _run_split(self, input_data: Any, **kwargs: Any) -> Any:
        """Run a single model based on traffic split probability."""
        use_b = random.random() < self._traffic_split

        if use_b:
            return self._run_model(
                self._model_b, input_data, self._metrics_b, **kwargs
            )
        return self._run_model(
            self._model_a, input_data, self._metrics_a, **kwargs
        )

    def _run_shadow(self, input_data: Any, **kwargs: Any) -> Any:
        """Run both models, return model A's result.

        Model B runs after model A to avoid adding latency to the
        critical path in synchronous execution.
        """
        result_a = self._run_model(
            self._model_a, input_data, self._metrics_a, **kwargs
        )
        # Shadow execution of model B (errors recorded by _run_model, not raised)
        try:
            self._run_model(
                self._model_b, input_data, self._metrics_b, **kwargs
            )
        except Exception:
            # _run_model already recorded the error; just log and suppress
            logger.debug(
                "Shadow model B inference failed (non-critical)", exc_info=True
            )

        return result_a

    def _run_model(
        self, model: Any, input_data: Any, metrics: _ModelMetrics, **kwargs: Any
    ) -> Any:
        """Run inference on a model and record latency metrics.

        Args:
            model: The model callable.
            input_data: Input data for inference.
            metrics: The _ModelMetrics accumulator to record to.

        Returns:
            Model output.
        """
        start = time.perf_counter()
        try:
            result = self._adapter.run_inference(model, input_data)
        except Exception:
            with self._lock:
                metrics.record_error()
            raise
        elapsed_ms = (time.perf_counter() - start) * 1000.0

        with self._lock:
            metrics.record(elapsed_ms)

        return result

    def get_comparison_report(self) -> dict:
        """Return comparison metrics between A and B.

        Returns a dictionary with:
            - model_a: metrics dict (request_count, avg_latency_ms, etc.)
            - model_b: metrics dict
            - traffic_split: configured traffic split ratio
            - total_requests: sum of A and B request counts
            - shadow: whether shadow mode is enabled
        """
        with self._lock:
            a_dict = self._metrics_a.to_dict()
            b_dict = self._metrics_b.to_dict()
            total = a_dict["request_count"] + b_dict["request_count"]

        return {
            "model_a": a_dict,
            "model_b": b_dict,
            "traffic_split": self._traffic_split,
            "total_requests": total,
            "shadow": self._shadow,
        }

    def compute_significance(
        self, confidence_level: float = 0.95
    ) -> Dict[str, Any]:
        """Compute statistical significance of latency difference using Welch's t-test.

        Compares model A's latency distribution against model B's to
        determine if the observed difference is statistically significant.

        Uses scipy.stats.ttest_ind when available, falls back to a manual
        Welch's t-test implementation.

        Args:
            confidence_level: Desired confidence level for the interval
                (default 0.95 for 95% CI).

        Returns:
            Dictionary with:
                - p_value: Two-tailed p-value (None if insufficient data)
                - confidence_interval: (lower, upper) tuple for the
                  difference in means (None tuple if insufficient data)
                - significant: True if p_value < (1 - confidence_level)
                  (None if insufficient data)
                - sample_sizes: {"model_a": n_a, "model_b": n_b}
        """
        with self._lock:
            samples_a = list(self._metrics_a.latencies)
            samples_b = list(self._metrics_b.latencies)

        alpha = 1.0 - confidence_level

        if len(samples_a) < 2 or len(samples_b) < 2:
            return {
                "p_value": None,
                "confidence_interval": (None, None),
                "significant": None,
                "sample_sizes": {
                    "model_a": len(samples_a),
                    "model_b": len(samples_b),
                },
            }

        if _scipy_ttest_ind is not None:
            stat_result = _scipy_ttest_ind(samples_a, samples_b, equal_var=False)
            p_value = float(stat_result.pvalue)
            # Compute CI manually
            mean_diff = statistics.mean(samples_a) - statistics.mean(samples_b)
            var_a = statistics.variance(samples_a)
            var_b = statistics.variance(samples_b)
            se = math.sqrt(var_a / len(samples_a) + var_b / len(samples_b))
            z_crit = _z_crit_for_confidence(confidence_level)
            ci = (mean_diff - z_crit * se, mean_diff + z_crit * se)
        else:
            p_value, ci = _welch_ttest_manual(samples_a, samples_b, confidence_level)

        significant = p_value < alpha if p_value is not None else None

        return {
            "p_value": p_value,
            "confidence_interval": ci,
            "significant": significant,
            "sample_sizes": {
                "model_a": len(samples_a),
                "model_b": len(samples_b),
            },
        }


# ---------------------------------------------------------------------------
# GradualRollout
# ---------------------------------------------------------------------------


_DEFAULT_ROLLOUT_STEPS = [1.0, 5.0, 10.0, 25.0, 50.0, 100.0]


class GradualRollout:
    """Staged traffic ramping with health checks at each step.

    Gradually increases the traffic percentage from initial_pct to
    target_pct through predefined steps. At each step, a health
    check must pass before advancing to the next.

    Default steps: 1% -> 5% -> 10% -> 25% -> 50% -> 100%

    Args:
        initial_pct: Starting traffic percentage.
        target_pct: Target traffic percentage.
        step_duration_sec: Minimum time at each step before advancing.
        steps: Optional custom step percentages. Must be sorted ascending.

    Thread-safe.
    """

    def __init__(
        self,
        initial_pct: float,
        target_pct: float,
        step_duration_sec: float,
        steps: Optional[List[float]] = None,
    ) -> None:
        self._steps = steps if steps is not None else list(_DEFAULT_ROLLOUT_STEPS)
        self._target_pct = target_pct
        self._step_duration_sec = step_duration_sec
        self._lock = threading.Lock()

        # Find starting step index (clamp to last step if initial_pct exceeds all)
        self._step_idx = len(self._steps) - 1  # Default to last step
        for i, step_val in enumerate(self._steps):
            if step_val >= initial_pct:
                self._step_idx = i
                break

        self._current_pct = self._steps[self._step_idx]
        self._step_started_at = time.monotonic()

    @property
    def current_pct(self) -> float:
        """Current traffic percentage."""
        with self._lock:
            return self._current_pct

    @property
    def steps(self) -> List[float]:
        """Configured rollout steps."""
        return list(self._steps)

    @property
    def is_complete(self) -> bool:
        """Whether the rollout has reached the target percentage."""
        with self._lock:
            return self._current_pct >= self._target_pct

    def advance_step(self, health_ok: bool) -> bool:
        """Attempt to advance to the next rollout step.

        Advances only if:
        1. health_ok is True
        2. The rollout has not already reached the target

        Args:
            health_ok: Whether the health check at the current step passed.

        Returns:
            True if advanced to next step, False otherwise.
        """
        if not health_ok:
            return False

        with self._lock:
            if self._current_pct >= self._target_pct:
                return False

            # Enforce minimum dwell time at current step
            elapsed = time.monotonic() - self._step_started_at
            if elapsed < self._step_duration_sec:
                return False

            next_idx = self._step_idx + 1
            if next_idx >= len(self._steps):
                return False

            self._step_idx = next_idx
            self._current_pct = min(self._steps[next_idx], self._target_pct)
            self._step_started_at = time.monotonic()
            return True


# ---------------------------------------------------------------------------
# MultiModelComparison (A/B/n)
# ---------------------------------------------------------------------------


class MultiModelComparison:
    """A/B/n testing for N models with weighted traffic distribution.

    Extends the standard A/B testing pattern to support N model variants
    with configurable traffic weights. Useful for testing multiple
    model versions simultaneously.

    Args:
        models: Mapping from model name to model callable.
        weights: Mapping from model name to traffic weight (must sum to ~1.0).
        adapter: InferenceAdapter for running inference.

    Raises:
        ValueError: If weights don't sum to ~1.0 or keys don't match models.

    Thread-safe.
    """

    def __init__(
        self,
        models: Dict[str, Any],
        weights: Dict[str, float],
        adapter: Any,
    ) -> None:
        if set(models.keys()) != set(weights.keys()):
            raise ValueError(
                f"Model keys {set(models.keys())} must match weight keys {set(weights.keys())}"
            )

        weight_sum = sum(weights.values())
        if abs(weight_sum - 1.0) > 0.01:
            raise ValueError(
                f"Traffic weights must sum to ~1.0, got {weight_sum:.3f}"
            )

        self._models = dict(models)
        self._weights = dict(weights)
        self._adapter = adapter

        # Build sorted name list and cumulative weights for efficient routing
        self._names: List[str] = sorted(models.keys())
        self._cumulative_weights: List[float] = []
        cum = 0.0
        for name in self._names:
            cum += self._weights[name]
            self._cumulative_weights.append(cum)

        self._metrics: Dict[str, _ModelMetrics] = {
            name: _ModelMetrics() for name in self._names
        }
        self._lock = threading.Lock()

    def _select_model(self) -> str:
        """Select a model name based on weighted traffic distribution."""
        r = random.random()
        for i, cum_weight in enumerate(self._cumulative_weights):
            if r < cum_weight:
                return self._names[i]
        return self._names[-1]

    def infer(self, input_data: Any, **kwargs: Any) -> Any:
        """Route request to a model based on weighted traffic distribution.

        Args:
            input_data: Input to pass to the model via the adapter.
            **kwargs: Additional keyword arguments forwarded to run_inference.

        Returns:
            Model output from the selected model.
        """
        model_name = self._select_model()
        model = self._models[model_name]
        metrics = self._metrics[model_name]

        start = time.perf_counter()
        try:
            result = self._adapter.run_inference(model, input_data)
        except Exception:
            with self._lock:
                metrics.record_error()
            raise
        elapsed_ms = (time.perf_counter() - start) * 1000.0

        with self._lock:
            metrics.record(elapsed_ms)

        return result

    def get_comparison_report(self) -> dict:
        """Return comparison metrics across all models.

        Returns:
            Dictionary with:
                - models: Dict mapping model name to metrics dict
                - weights: Configured traffic weights
                - total_requests: Sum of all model request counts
        """
        with self._lock:
            model_dicts = {
                name: metrics.to_dict() for name, metrics in self._metrics.items()
            }
            total = sum(m["request_count"] for m in model_dicts.values())

        return {
            "models": model_dicts,
            "weights": dict(self._weights),
            "total_requests": total,
        }
