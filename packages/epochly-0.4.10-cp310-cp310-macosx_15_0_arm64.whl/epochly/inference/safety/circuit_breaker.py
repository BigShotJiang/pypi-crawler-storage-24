"""
CircuitBreaker - Per-optimization circuit breaker state machine.

Each optimization technique has its own circuit breaker. A failure
in one optimization does not disable unrelated optimizations.

State machine:
    CLOSED --(failure_threshold failures)--> OPEN
    OPEN --(reset_timeout expires)--> HALF_OPEN
    HALF_OPEN --(success_threshold successes)--> CLOSED
    HALF_OPEN --(any failure)--> OPEN (reset timer)

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional

logger = logging.getLogger(__name__)


class CircuitState(Enum):
    """Circuit breaker states."""

    CLOSED = "closed"  # Optimization active, monitoring for failures
    OPEN = "open"  # Optimization disabled due to failures
    HALF_OPEN = "half_open"  # Testing if optimization has recovered


@dataclass
class CircuitBreakerConfig:
    """Configuration for CircuitBreaker."""

    failure_threshold: int = 3  # Failures before OPEN
    success_threshold: int = 5  # Successes in HALF_OPEN before CLOSED
    reset_timeout_sec: float = 300.0  # Time in OPEN before trying HALF_OPEN
    observation_window_sec: float = 60.0  # Window for counting failures


class CircuitBreaker:
    """Per-optimization circuit breaker.

    Thread-safe. Each optimization type gets its own breaker:
    - torch_compile
    - dynamic_micro_batching
    - prepost_parallel
    - request_cache
    """

    def __init__(
        self, name: str, config: Optional[CircuitBreakerConfig] = None
    ) -> None:
        self._name = name
        self._config = config or CircuitBreakerConfig()
        self._state = CircuitState.CLOSED
        self._failure_timestamps: List[float] = []
        self._consecutive_successes = 0
        self._last_opened_at: Optional[float] = None
        self._total_trips = 0
        self._lock = threading.Lock()

    @property
    def name(self) -> str:
        """Name of the optimization this breaker protects."""
        return self._name

    @property
    def state(self) -> CircuitState:
        """Current circuit state with timeout-based OPEN->HALF_OPEN transition.

        Single lock acquisition covers both the timeout check and the
        state read, eliminating the TOCTOU window between them.
        """
        with self._lock:
            if (
                self._state == CircuitState.OPEN
                and self._last_opened_at is not None
            ):
                elapsed = time.time() - self._last_opened_at
                if elapsed >= self._config.reset_timeout_sec:
                    self._state = CircuitState.HALF_OPEN
                    self._consecutive_successes = 0
                    logger.info(
                        "Circuit breaker '%s' transitioning OPEN -> HALF_OPEN "
                        "after %.1fs timeout",
                        self._name,
                        elapsed,
                    )
            return self._state

    @property
    def total_trips(self) -> int:
        """Total number of times this breaker has tripped to OPEN."""
        return self._total_trips

    def is_allowed(self) -> bool:
        """Check if the optimization is allowed to execute."""
        state = self.state
        if state == CircuitState.CLOSED:
            return True
        if state == CircuitState.HALF_OPEN:
            return True  # Allow probe request
        return False  # OPEN: blocked

    def record_success(self) -> None:
        """Record a successful optimization execution."""
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                self._consecutive_successes += 1
                if self._consecutive_successes >= self._config.success_threshold:
                    self._state = CircuitState.CLOSED
                    self._failure_timestamps.clear()
                    logger.info(
                        "Circuit breaker '%s' recovered: HALF_OPEN -> CLOSED "
                        "after %d consecutive successes",
                        self._name,
                        self._consecutive_successes,
                    )

    def record_success_and_check_recovery(self) -> bool:
        """Record success and atomically check if breaker recovered.

        Returns True if the breaker transitioned from HALF_OPEN to CLOSED
        on this call. Single lock acquisition eliminates TOCTOU between
        checking state and recording success.
        """
        with self._lock:
            if self._state != CircuitState.HALF_OPEN:
                return False

            self._consecutive_successes += 1
            if self._consecutive_successes >= self._config.success_threshold:
                self._state = CircuitState.CLOSED
                self._failure_timestamps.clear()
                logger.info(
                    "Circuit breaker '%s' recovered: HALF_OPEN -> CLOSED "
                    "after %d consecutive successes",
                    self._name,
                    self._consecutive_successes,
                )
                return True
            return False

    def record_failure(self, error: Optional[Exception] = None) -> None:
        """Record a failed optimization execution."""
        with self._lock:
            now = time.time()

            if self._state == CircuitState.HALF_OPEN:
                # Any failure in HALF_OPEN -> back to OPEN
                self._state = CircuitState.OPEN
                self._last_opened_at = now
                self._total_trips += 1
                self._consecutive_successes = 0
                logger.warning(
                    "Circuit breaker '%s' tripped again: HALF_OPEN -> OPEN "
                    "(error: %s)",
                    self._name,
                    error,
                )
                return

            # OPEN: ignore failures (already tripped, waiting for timeout)
            if self._state == CircuitState.OPEN:
                return

            # CLOSED: track failures within observation window
            self._failure_timestamps.append(now)

            # Prune failures outside observation window
            window_start = now - self._config.observation_window_sec
            self._failure_timestamps = [
                t for t in self._failure_timestamps if t >= window_start
            ]

            if len(self._failure_timestamps) >= self._config.failure_threshold:
                self._state = CircuitState.OPEN
                self._last_opened_at = now
                self._total_trips += 1
                logger.warning(
                    "Circuit breaker '%s' tripped: CLOSED -> OPEN "
                    "(%d failures in %.0fs window, error: %s)",
                    self._name,
                    len(self._failure_timestamps),
                    self._config.observation_window_sec,
                    error,
                )

    def reset(self) -> None:
        """Manually reset the circuit breaker to CLOSED."""
        with self._lock:
            self._state = CircuitState.CLOSED
            self._failure_timestamps.clear()
            self._consecutive_successes = 0
            self._last_opened_at = None

    def get_diagnostics(self) -> dict:
        """Return diagnostic information about this breaker."""
        with self._lock:
            return {
                "name": self._name,
                "state": self._state.value,
                "total_trips": self._total_trips,
                "recent_failures": len(self._failure_timestamps),
                "consecutive_successes": self._consecutive_successes,
                "last_opened_at": self._last_opened_at,
            }
