"""
Epochly AI Inference Accelerator

Provides inference profiling, safe optimization, and serving integration
for Python AI inference pipelines.

Zero cost if no ML framework is detected: this module uses lazy initialization
and adds <0.1ms to import time when no ML frameworks are present.

Usage:
    import epochly

    # Framework detection is automatic via import hooks
    model = MyModel().to("cuda").eval()
    model = epochly.wrap(model)  # Returns InferenceProxy for profiling

    # Serving integration (FastAPI)
    from epochly.inference.serving import EpochlyInferenceMiddleware
    app.add_middleware(EpochlyInferenceMiddleware)

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

# Lazy imports: nothing is loaded until explicitly accessed
# This ensures zero overhead when no ML framework is present


def _get_detector():
    """Lazy accessor for the InferenceDetector singleton."""
    from .detector import InferenceDetector
    return InferenceDetector.instance()


def _get_inference_proxy_class():
    """Lazy accessor for InferenceProxy class."""
    from .frameworks.inference_proxy import InferenceProxy
    return InferenceProxy


__all__ = [
    "InferenceDetector",
    "InferenceProxy",
    "RequestContext",
    "BatchKey",
]


def __getattr__(name: str):
    """Module-level lazy attribute access."""
    if name == "InferenceDetector":
        from .detector import InferenceDetector
        return InferenceDetector
    if name == "InferenceProxy":
        from .frameworks.inference_proxy import InferenceProxy
        return InferenceProxy
    if name == "RequestContext":
        from .context import RequestContext
        return RequestContext
    if name == "BatchKey":
        from .context import BatchKey
        return BatchKey
    raise AttributeError(f"module 'epochly.inference' has no attribute {name!r}")
