"""
Epochly telemetry package.

On first import, fires an anonymous community-tier telemetry event
(non-blocking, fire-and-forget) unless opted out via
``EPOCHLY_DISABLE_TELEMETRY=1``.
"""

from epochly.telemetry.anonymous import maybe_send_anonymous_telemetry

# Fire anonymous telemetry on import (background thread, fail-silent)
try:
    maybe_send_anonymous_telemetry()
except Exception:
    pass
