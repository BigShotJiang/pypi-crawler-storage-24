"""
Epochly CLI command executor.

Handles running Python command strings with Epochly acceleration (like python -c).
"""

import os
import subprocess
import sys

from epochly.utils.logger import get_logger


async def run_command(args) -> int:
    """
    Run a Python command string with Epochly acceleration (like python -c).

    Args:
        args: Parsed command line arguments containing:
            - command: Python code to execute
            - All standard Epochly configuration options

    Returns:
        Exit code from the command execution
    """
    logger = get_logger(__name__)

    if not args.command:
        print("Error: No command specified for -c", file=sys.stderr)
        return 1

    # Set up environment variables for Epochly
    env = os.environ.copy()

    # Add src directory to PYTHONPATH so subprocess can import epochly
    src_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    env['PYTHONPATH'] = src_path + os.pathsep + env.get('PYTHONPATH', '')

    # Set optimization level -- CLI args always take precedence over environment.
    if hasattr(args, 'no_optimize') and args.no_optimize:
        env['EPOCHLY_LEVEL'] = '0'
    else:
        env['EPOCHLY_LEVEL'] = str(args.level if hasattr(args, 'level') else 3)

    # Set all configuration environment variables (same as run_module)
    if hasattr(args, 'verbose') and args.verbose:
        env['EPOCHLY_VERBOSE'] = '1'

    # Set memory pool configuration
    if hasattr(args, 'pin_pool') and args.pin_pool:
        env['EPOCHLY_PIN_POOL'] = args.pin_pool
    if hasattr(args, 'allowed_pools') and args.allowed_pools:
        env['EPOCHLY_ALLOWED_POOLS'] = args.allowed_pools

    # Set core usage limits
    if hasattr(args, 'max_cores') and args.max_cores:
        env['EPOCHLY_MAX_CORES'] = str(args.max_cores)
    if hasattr(args, 'max_cores_percent') and args.max_cores_percent:
        env['EPOCHLY_MAX_CORES_PERCENT'] = str(args.max_cores_percent)
    if hasattr(args, 'reserve_cores') and args.reserve_cores:
        env['EPOCHLY_RESERVE_CORES'] = str(args.reserve_cores)

    # Set advanced analysis options
    if hasattr(args, 'profile') and args.profile:
        env['EPOCHLY_PROFILING'] = '1'
    if hasattr(args, 'benchmark') and args.benchmark:
        env['EPOCHLY_BENCHMARK'] = '1'
    if hasattr(args, 'check') and args.check:
        env['EPOCHLY_CHECK'] = '1'
    if hasattr(args, 'explain') and args.explain:
        env['EPOCHLY_EXPLAIN'] = '1'

    # Set runtime configuration
    if hasattr(args, 'workers') and args.workers is not None:
        env['EPOCHLY_WORKERS'] = str(args.workers)
    if hasattr(args, 'mode') and args.mode:
        env['EPOCHLY_MODE'] = args.mode
    if hasattr(args, 'debug') and args.debug:
        env['EPOCHLY_DEBUG'] = '1'

    # Create wrapper code to initialize Epochly before executing command
    cli_level = args.level if hasattr(args, 'level') else 3
    force_flag = getattr(args, 'force', False)
    wrapper_code = f"""
import os
import logging

# Suppress Epochly initialization logs only - user code logging still works
logging.getLogger('epochly').setLevel(logging.CRITICAL)

_epochly_module = None
# Initialize Epochly (only if not disabled)
if os.environ.get('EPOCHLY_DISABLE') != '1':
    import epochly as _epochly_module
    # Respect EPOCHLY_LEVEL environment variable if set
    _env_level = os.environ.get('EPOCHLY_LEVEL')
    _force = os.environ.get('EPOCHLY_FORCE_LEVEL', '').lower() in ('1', 'true', 'yes') or {force_flag}
    if _env_level is not None:
        # Use environment variable - this takes precedence over CLI default
        _epochly_module.configure(enhancement_level=int(_env_level), force=_force)
    else:
        # No environment variable - use CLI-specified configuration
        _epochly_module.configure(enhancement_level={cli_level}, force=_force)

try:
    # Execute the user's command using exec() to handle multi-line commands correctly
    # Direct embedding breaks indentation for commands with newlines
    # Note: Using double underscores to minimize collision risk with user code
    __epochly_internal_user_code__ = {repr(args.command)}
    exec(__epochly_internal_user_code__, {{'__name__': '__main__'}})
finally:
    # Explicit shutdown to ensure clean process exit
    # Without this, Level 4 GPU processes may hang during interpreter finalization
    if _epochly_module is not None:
        try:
            _epochly_module.shutdown()
        except Exception:
            pass  # Ignore shutdown errors
"""

    # Timeout for subprocess execution (in seconds).
    # Override with EPOCHLY_TIMEOUT env var; defaults to 300 (5 minutes).
    try:
        SUBPROCESS_TIMEOUT = int(os.environ.get('EPOCHLY_TIMEOUT', '300'))
    except ValueError:
        SUBPROCESS_TIMEOUT = 300

    # Run the command with Epochly
    try:
        result = subprocess.run(
            [sys.executable, '-c', wrapper_code],
            env=env,
            capture_output=True,  # Capture output for proper propagation
            text=True,
            timeout=SUBPROCESS_TIMEOUT
        )

        # Forward captured output to maintain current behavior
        if result.stdout:
            print(result.stdout, end='')
        if result.stderr:
            print(result.stderr, end='', file=sys.stderr)

        if hasattr(args, 'verbose') and args.verbose:
            print(f"\nCommand execution completed with exit code {result.returncode}")

        return result.returncode

    except subprocess.TimeoutExpired as e:
        # Process hung - output what we captured before timeout
        if e.stdout:
            print(e.stdout if isinstance(e.stdout, str) else e.stdout.decode('utf-8', errors='replace'), end='')
        if e.stderr:
            print(e.stderr if isinstance(e.stderr, str) else e.stderr.decode('utf-8', errors='replace'), end='', file=sys.stderr)
        print(f"\nError: Command timed out after {SUBPROCESS_TIMEOUT} seconds", file=sys.stderr)
        return 124  # Standard timeout exit code
    except KeyboardInterrupt:
        print("\nCommand execution interrupted by user", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"Error running command: {e}", file=sys.stderr)
        return 1
