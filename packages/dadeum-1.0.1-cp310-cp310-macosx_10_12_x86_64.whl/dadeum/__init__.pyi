def clean(text: str) -> str:
    """dirty 한글 텍스트를 clean 텍스트로 변환합니다.

    노이즈 문자 제거 + 양방향 Max-Match 띄어쓰기 복원을 수행합니다.

    Args:
        text: dirty 텍스트 (노이즈 공백/특수문자 포함)

    Returns:
        정리된 clean 텍스트
    """
    ...
