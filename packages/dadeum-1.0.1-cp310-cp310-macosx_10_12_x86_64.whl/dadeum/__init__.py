from .dadeum import *

__doc__ = dadeum.__doc__
if hasattr(dadeum, "__all__"):
    __all__ = dadeum.__all__