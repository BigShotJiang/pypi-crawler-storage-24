===========================
Welcome to rectangle-packer
===========================

|PyPI-Versions| |PyPI-Wheel| |Build-Status| |Read-the-Docs| |GitHub-License|

|PyPI-Downloads|

.. docs:start:landing_intro

**Primary use:** Given a set of rectangles with fixed orientations,
find a bounding box of minimum area that contains them all with no
overlap.

This project is inspired by Matt Perdeck's blog post `Fast Optimizing
Rectangle Packing Algorithm for Building CSS Sprites`_.

* The latest documentation is available on `Read the Docs`_.
* The source code is available on `GitHub`_.

.. docs:end:landing_intro


.. docs:start:landing_installation

Installation
============

Install the latest version from `PyPI`_:

.. code:: sh

    $ python3 -m pip install rectangle-packer

Or `clone the repository`_ and install it with:

.. code:: sh

    $ python3 -m pip install .

.. docs:end:landing_installation


.. docs:start:landing_usage

Basic usage
===========

.. code:: python

    # Import the module
    >>> import rpack

    # Create a bunch of rectangles (width, height)
    >>> sizes = [(58, 206), (231, 176), (35, 113), (46, 109)]

    # Pack
    >>> positions = rpack.pack(sizes)

    # The result will be a list of (x, y) positions:
    >>> positions
    [(0, 0), (58, 0), (289, 0), (289, 113)]

The output positions are the lower-left corner coordinates of each
input rectangle.

These positions yield a packing with no overlaps and an enclosing area
that is as small as possible (best effort).

``rpack.pack`` also accepts optional ``max_width`` and ``max_height``
arguments if the packing must fit inside a specific bounding box.  When
the constraint cannot be satisfied a :py:exc:`rpack.PackingImpossibleError`
is raised.  For example, the following call forces all rectangles to fit
within a width of ``300``::

    >>> rpack.pack(sizes, max_width=300)
    [(0, 0), (58, 0), (289, 0), (289, 113)]

If the width constraint is too small, ``PackingImpossibleError`` is
raised.

.. note::

    * You must use **positive integers** as rectangle width and height.

    * The module name is **rpack** which is an abbreviation of the package
      name at PyPI (rectangle-packer).

    * The computational time required by ``rpack.pack`` increases by
      the number *and* size of input rectangles.  If this becomes a problem,
      you might need to implement your own `divide-and-conquer algorithm`_.

.. docs:end:landing_usage


Examples
========

**Example A:**

.. figure:: doc/_static/img/packing_best_10.svg
   :alt: pack10
   :align: center

**Example B:**

.. figure:: doc/_static/img/packing_phi.svg
   :alt: packphi
   :align: center


**Example C:** Sometimes the input rectangles simply cannot be packed
very efficiently. Here's an example that demonstrates a low packing
density:

.. figure:: doc/_static/img/packing_worst_10.svg
   :alt: pack10bad
   :align: center


**Example D:** The image below, contributed by Paul Brodersen, illustrates
a solution to a problem discussed at stackoverflow_.

.. image:: doc/_static/img/kLat8.png
    :alt: PaulBrodersenExampleImage
    :align: center
    :width: 450px


.. _Read the Docs: https://rectangle-packer.readthedocs.io/en/latest/
.. _GitHub: https://github.com/Penlect/rectangle-packer
.. _`Fast Optimizing Rectangle Packing Algorithm for Building CSS Sprites`: http://www.codeproject.com/Articles/210979/Fast-optimizing-rectangle-packing-algorithm-for-bu
.. _`clone the repository`: https://github.com/Penlect/rectangle-packer
.. _stackoverflow: https://stackoverflow.com/a/53156709/2912349
.. _PyPI: https://pypi.org/project/rectangle-packer/
..  _`divide-and-conquer algorithm`: https://en.wikipedia.org/wiki/Divide-and-conquer_algorithm

.. |PyPI-Versions| image:: https://img.shields.io/pypi/pyversions/rectangle-packer.svg
   :target: https://pypi.org/project/rectangle-packer

.. |PyPI-Wheel| image:: https://img.shields.io/pypi/wheel/rectangle-packer.svg
   :target: https://pypi.org/project/rectangle-packer

.. |Build-Status| image:: https://github.com/Penlect/rectangle-packer/actions/workflows/build_wheels.yml/badge.svg?branch=master
   :target: https://github.com/Penlect/rectangle-packer/actions/workflows/build_wheels.yml

.. |Read-the-Docs| image:: https://img.shields.io/readthedocs/rectangle-packer.svg
   :target: https://rectangle-packer.readthedocs.io/en/latest

.. |GitHub-License| image:: https://img.shields.io/github/license/Penlect/rectangle-packer.svg
   :target: https://raw.githubusercontent.com/Penlect/rectangle-packer/travis/LICENSE.md

.. |PyPI-Downloads| image:: https://img.shields.io/pypi/dm/rectangle-packer.svg
   :target: https://pypi.org/project/rectangle-packer
