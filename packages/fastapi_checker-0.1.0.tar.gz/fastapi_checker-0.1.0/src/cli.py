import argparse
from src.core.main import FastAPIChecker


def main():
    parser = argparse.ArgumentParser(
        description="FastAPI Checker",
        usage="fastapi_checker [OPTIONS]",
    )

    parser.add_argument(
        "-c",
        "--config",
        type=str,
        help="Path to your config-file",
        default="fa_checker.yaml",
    )
    args = parser.parse_args()

    checker = FastAPIChecker(config_path=args.config)
    checker.run()


if __name__ == "__main__":
    main()
