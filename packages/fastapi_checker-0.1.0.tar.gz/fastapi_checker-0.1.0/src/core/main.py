import logging
from typing import Any, Dict

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from tabulate import tabulate

from src.config import read_config
from src.core.parser import parse_app, parse_middleware, parse_routers

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger(__name__)


class FastAPIChecker:
    def __init__(self, config_path: str = "fa_checker.yaml", config: Dict[str, Any] = None):
        self.config = config or read_config(config_path) or {}
        self.console = Console()
        self.main_file_path = self._get_main_file_path()

    def _get_main_file_path(self):
        settings = self.config.get("checker_settings", {})
        path = settings.get("main_file_path")
        if not path:
            logger.error("Main file path not found in config!")
        return path

        

    def draw_info(self, routers: list, middleware: dict, app: dict):
        tables = []

        if app:
            a_table = Table(title="App Info", box=box.ROUNDED)
            a_table.add_column("Value", style="yellow")
            a_table.add_column("Option", style="white")
            for key, val in app.items():
                a_table.add_row(key, str(val).strip("'"))
            tables.append(a_table)
            
        if middleware and "CORS" in middleware:
            m_table = Table(title="CORS Middleware", box=box.ROUNDED)
            m_table.add_column("Option", style="yellow")
            m_table.add_column("Value")
            for key, val in middleware["CORS"].items():
                m_table.add_row(key, str(val).strip("'"))
            tables.append(m_table)
            
        if routers:
            r_table = Table(title="Routers", box=box.ROUNDED)
            r_table.add_column("Router", style="cyan")
            r_table.add_column("Prefix", style="green")
            for item in routers:
                prefix = item.get("details", {}).get("prefix", "N/A").strip("'")
                r_table.add_row(item["router"], prefix)
            tables.append(r_table)

        

        if tables:
            self.console.print(Columns(tables, equal=False, expand=False))

    def draw_header(self):
        header_text = Text("FA CHECKER", style="bold white")
        header_text.append("\nFastAPI Project Analyzer", style="italic dim white")

        self.console.print(
            Panel(
                header_text,
                subtitle="v0.1.0",
                subtitle_align="right",
                border_style="bright_blue",
                box=box.DOUBLE_EDGE,
                padding=(1, 2),
            )
        )

    def run(self):
        if not self.main_file_path:
            return

        self.draw_header()
        
        try:
            app_data = parse_app(self.main_file_path)
            middleware_data = parse_middleware(self.main_file_path)
            routers_data = parse_routers(self.main_file_path)
            
            self.draw_info(routers_data, middleware_data, app_data)
        except Exception as e:
            logger.exception(f"Error during analysis: {e}")
