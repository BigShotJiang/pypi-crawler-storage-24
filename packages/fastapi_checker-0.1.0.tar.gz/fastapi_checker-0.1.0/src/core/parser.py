import ast
import os

def _get_tree(file_path: str):
    if not os.path.exists(file_path):
        print(f"ERROR: File not found: {file_path}")
        return None
    with open(file_path, "r", encoding="utf-8") as f:
        return ast.parse(f.read())

def parse_app(main_file_path: str):
    tree = _get_tree(main_file_path)
    if not tree: return {}

    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                # Проверяем, что переменная называется 'app'
                if isinstance(target, ast.Name) and target.id == 'app':
                    # Проверяем, что вызывается FastAPI (напрямую или через модуль)
                    if isinstance(node.value, ast.Call):
                        func_name = ast.unparse(node.value.func)
                        if 'FastAPI' in func_name:
                            return {
                                kw.arg: ast.unparse(kw.value).strip("'\"") 
                                for kw in node.value.keywords
                            }
    return {}

def parse_routers(main_file_path: str):
    tree = _get_tree(main_file_path)
    if not tree: return []

    routers = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            # Ищем вызов .include_router()
            if isinstance(node.func, ast.Attribute) and node.func.attr == "include_router":
                router_name = ast.unparse(node.args[0]) if node.args else "Unknown"
                details = {kw.arg: ast.unparse(kw.value).strip("'\"") for kw in node.keywords}
                routers.append({"router": router_name, "details": details})
    return routers

def parse_middleware(main_file_path: str):
    tree = _get_tree(main_file_path)
    if not tree: return {}

    local_vars = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    local_vars[target.id] = ast.unparse(node.value)

    result = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Attribute) and node.func.attr == "add_middleware":
                call_str = ast.unparse(node)
                if "CORSMiddleware" in call_str:
                    cors = {}
                    for kw in node.keywords:
                        raw_val = ast.unparse(kw.value)
                        cors[kw.arg] = local_vars.get(raw_val, raw_val).strip("'\"")
                    result["CORS"] = cors
    return result
