import logging
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)


def read_config(config_path: str):
    """
    by default path is - fa_ckecker.yaml
    """
    if Path(config_path).exists():
        with open(config_path, "r", encoding="utf-8") as file:
            data = yaml.safe_load(file)
            return data or {}
    else:
        logger.error("!!! Config file not found !!!")
        return {}
