# FastAPI Checker 🔍

A lightweight static analysis tool designed to inspect FastAPI applications using Python's `ast` module. It extracts app configurations, CORS middleware settings, and registered routers without executing the code.

## 🛠 Installation

The project uses `uv` for dependency management:

~~~bash
# Clone the repository
git clone https://github.com/MarkLevkovich/fastapi_checker
cd fastapi_checker

# Sync dependencies
uv sync
~~~

## 📖 Usage

Run the checker by providing a configuration file:

~~~bash
# Run via module with a config file
uv run python -m src.cli -c fa_checker.yaml
~~~

## ⚙️ Configuration

Create a `fa_checker.yaml` to define your project settings:

~~~yaml
checker_settings:
  main_file_path: "src/main.py"
~~~


---
*Created for automated FastAPI project auditing.*
### NOW IN DEV!
