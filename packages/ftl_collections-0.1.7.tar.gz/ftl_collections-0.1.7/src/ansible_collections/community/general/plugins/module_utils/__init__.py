# Extracted from Ansible collection
