# 🍬 candy-ai v9

Client Python pour **cedric-8EF** — moteur IA multi-personnalités.  
Zéro configuration · 50 personnalités · **Helper agent** · Profils · Conversations · Batch · Streaming

---

## Installation

```bash
pip install candy-ai
```

---

## Démarrage immédiat

```python
from candy import Coding
print(Coding.ask("Write a quicksort in Python"))
```

---

## 🤖 Helper — Génère du code candy prêt à l'emploi

Helper génère automatiquement du code candy-ai via des **templates garantis**.  
100% candy — aucune librairie externe, jamais.

```python
from candy import Helper

# Voir les templates disponibles
Helper.list()

# Générer du code (retourne un string)
code = Helper.write("livre", sujet="Napoléon", lang="FR", chapitres=20)
print(code)

# Afficher le code numéroté et coloré
Helper.preview("chatbot", lang="FR", module="Full")

# Générer ET exécuter directement
Helper.run("livre", sujet="La Révolution française", lang="FR", chapitres=20)
```

### Templates disponibles

| Template | Description | Paramètres principaux |
|----------|-------------|----------------------|
| `livre` | Livre de N chapitres | `sujet`, `lang`, `chapitres`, `fichier` |
| `traduction` | Traduire vers plusieurs langues | `texte`, `langues` (liste de codes) |
| `chatbot` | Chatbot interactif en boucle | `lang`, `module`, `style`, `tone` |
| `pipeline` | Coding → Debugger → Reviewer | `tache`, `lang` |
| `batch` | Plusieurs questions d'un coup | `questions` (liste), `module`, `lang` |
| `résumé` | Résumer un texte | `lang`, `fichier_sortie` |
| `question` | Poser une question à une personnalité | `module`, `lang`, `style` |

### Exemples Helper

```python
from candy import Helper

# Livre
Helper.run("livre", sujet="La Seconde Guerre mondiale", lang="FR", chapitres=20)

# Traduction en 4 langues
Helper.run("traduction",
    texte="Bonjour, comment allez-vous ?",
    langues=["ES", "DE", "JA", "AR"]
)

# Chatbot de maths
Helper.run("chatbot", lang="FR", module="Math", tone="encouraging")

# Pipeline de dev
Helper.run("pipeline", tache="un gestionnaire de fichiers CSV", lang="FR")

# Batch
Helper.run("batch",
    questions=["C'est quoi Python ?", "C'est quoi une liste ?"],
    module="Coding", lang="FR"
)
```

---

## Profils

```python
from candy import cfg, Coding, Math

cfg.A.lang         = "FR"
cfg.A.max_tokens   = 2000
cfg.A.style        = "detailed"
cfg.A.tone         = "encouraging"
cfg.A.expertise    = "beginner"

cfg.A = cfg.preset("french_beginner")   # preset rapide
cfg.default.lang   = "FR"

print(Coding.ask("Hello"))
print(Math.use("A").ask("C'est quoi pi ?"))
```

**Presets :** `french_beginner` `french_expert` `english_beginner` `english_expert`
`quick` `academic` `creative` `teacher` `coder` `journalist` `storyteller` `analyst` `coach` `debug`

---

## Tous les paramètres par profil

| Paramètre | Défaut | Valeurs |
|-----------|--------|---------|
| `lang` | `"EN"` | `FR EN ES DE IT PT ZH JA AR RU NL PL SV TR KO HI VI ID CS RO` |
| `max_tokens` | `1024` | `100` → `4096` |
| `temperature` | `0.7` | `0.0` → `1.5` |
| `style` | `"default"` | `default concise detailed bullet academic casual technical eli5` |
| `tone` | `"neutral"` | `neutral encouraging strict humorous empathetic socratic` |
| `output_format` | `"text"` | `text markdown json html` |
| `expertise` | `"intermediate"` | `beginner intermediate expert` |
| `include_examples` | `True` | `True / False` |
| `safe_mode` | `True` | `True / False` |
| `timeout` | `120` | secondes |
| `retry` | `1` | tentatives en cas d'échec |
| `verbose` | `False` | affiche les infos de requête |

---

## Conversations multi-tours

```python
session = Coding.chat(profile="A")
print(session.say("Explique les décorateurs"))
print(session.say("Donne un exemple"))
session.save("chat.json")
session.show_history()
```

---

## Batch

```python
réponses = Coding.use("A").batch(["Q1 ?", "Q2 ?", "Q3 ?"])
```

---

## Streaming

```python
Writing.use("A").stream_print("Écris une histoire")
```

---

## Utilitaires

```python
Coding.is_online()    # True/False
Coding.ping()         # latence ms
Coding.quota()        # quota restant
cfg.A.reset()         # remet aux défauts
cfg.list_presets()    # liste les presets
```

---

## Les 50 personnalités

`Math` `Coding` `Reflexion` `Analytic` `Full` `Science` `Writing` `History`
`Law` `Medicine` `Finance` `Marketing` `Security` `Design` `Language`
`Psychology` `Education` `Research` `Business` `Productivity` `Cooking`
`Travel` `Music` `Film` `Sports` `Philosophy` `Environment` `Architecture`
`Automotive` `Astronomy` `Biology` `Chemistry` `Physics` `Engineering`
`Entrepreneur` `Ethics` `Geopolitics` `Crypto` `AI` `DevOps` `Database`
`GameDev` `Comic` `Storyteller` `Translator` `Summarizer` `Debugger`
`Reviewer` `Planner` `Tutor`

---

Propulsé par **cedric-8EF** · Quota 500 req/jour · MIT License
