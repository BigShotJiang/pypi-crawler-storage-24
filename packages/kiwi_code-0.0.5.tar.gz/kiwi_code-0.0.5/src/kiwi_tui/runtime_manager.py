"""Shared helpers for managing per-directory kiwi-runtime processes.

Each working directory gets its own runtime, identified by a hash of the
absolute path.  State is stored under ~/.autobots-tui/runtimes/<key>/:
    pid  — PID of the running process
    log  — stdout/stderr of the runtime
    cwd  — the working directory this runtime is scoped to
"""

import hashlib
import os
import signal
import time
from pathlib import Path

RUNTIMES_DIR = Path.home() / ".autobots-tui" / "runtimes"


def runtime_key(cwd: str | None = None) -> str:
    """Generate a short hash key for a working directory."""
    if cwd is None:
        cwd = os.getcwd()
    return hashlib.sha256(os.path.realpath(cwd).encode()).hexdigest()[:12]


def runtime_dir(cwd: str | None = None) -> Path:
    """Return the runtime state directory for a given working directory."""
    d = RUNTIMES_DIR / runtime_key(cwd)
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_running_pid(cwd: str | None = None) -> int | None:
    """Return PID of a running runtime for the directory, or None."""
    pid_path = runtime_dir(cwd) / "pid"
    if not pid_path.exists():
        return None
    try:
        pid = int(pid_path.read_text().strip())
        os.kill(pid, 0)
        return pid
    except (ValueError, ProcessLookupError, PermissionError):
        pid_path.unlink(missing_ok=True)
        return None


def save_pid(pid: int, cwd: str | None = None) -> None:
    """Record a runtime PID and its working directory."""
    if cwd is None:
        cwd = os.getcwd()
    rd = runtime_dir(cwd)
    (rd / "pid").write_text(str(pid))
    (rd / "cwd").write_text(os.path.realpath(cwd))


def log_path(cwd: str | None = None) -> Path:
    """Return the log file path for a directory's runtime."""
    return runtime_dir(cwd) / "log"


def token_path(cwd: str | None = None) -> Path:
    """Return the shared token file path for a directory's runtime."""
    return runtime_dir(cwd) / "token"


def refresh_token_path(cwd: str | None = None) -> Path:
    """Return the shared refresh token file path for a directory's runtime."""
    return runtime_dir(cwd) / "refresh_token"


def save_token(token: str, cwd: str | None = None) -> None:
    """Write a refreshed access token so the runtime can pick it up."""
    tp = token_path(cwd)
    tp.write_text(token)
    tp.chmod(0o600)


def save_refresh_token(token: str, cwd: str | None = None) -> None:
    """Write the refresh token so the runtime can refresh on its own."""
    tp = refresh_token_path(cwd)
    tp.write_text(token)
    tp.chmod(0o600)


def read_token(cwd: str | None = None) -> str | None:
    """Read the shared access token (returns None if missing)."""
    tp = token_path(cwd)
    if not tp.exists():
        return None
    try:
        return tp.read_text().strip() or None
    except OSError:
        return None


def read_refresh_token(cwd: str | None = None) -> str | None:
    """Read the shared refresh token (returns None if missing)."""
    tp = refresh_token_path(cwd)
    if not tp.exists():
        return None
    try:
        return tp.read_text().strip() or None
    except OSError:
        return None


def stop_runtime(cwd: str | None = None) -> bool:
    """Stop the runtime for a directory. Returns True if a process was stopped."""
    pid = get_running_pid(cwd)
    if not pid:
        return False

    try:
        os.kill(pid, signal.SIGTERM)
        for _ in range(20):
            time.sleep(0.1)
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                break
        else:
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    except ProcessLookupError:
        pass

    pid_path = runtime_dir(cwd) / "pid"
    pid_path.unlink(missing_ok=True)
    return True


def list_all() -> list[dict]:
    """List all known runtimes with their status."""
    if not RUNTIMES_DIR.exists():
        return []

    results = []
    for entry in sorted(RUNTIMES_DIR.iterdir()):
        if not entry.is_dir():
            continue
        cwd_file = entry / "cwd"
        pid_file = entry / "pid"
        if not cwd_file.exists():
            continue

        cwd = cwd_file.read_text().strip()
        pid = None
        running = False
        if pid_file.exists():
            try:
                pid = int(pid_file.read_text().strip())
                os.kill(pid, 0)
                running = True
            except (ValueError, ProcessLookupError, PermissionError):
                pid_file.unlink(missing_ok=True)
                pid = None

        results.append({
            "key": entry.name,
            "cwd": cwd,
            "pid": pid,
            "running": running,
        })
    return results


def stop_all() -> int:
    """Stop all running runtimes. Returns count of processes stopped."""
    count = 0
    for rt in list_all():
        if rt["running"]:
            if stop_runtime(rt["cwd"]):
                count += 1
    return count
