"""Kiwi Runtime — terminal agent that connects to the server via WebSocket."""

__version__ = "0.1.0"
