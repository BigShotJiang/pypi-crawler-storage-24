"""Jinja2 SQL templates for output parameter handling."""
