"""
Validate runner -- orchestrates the full validation pipeline.

1. Resolve Snowflake executor from the injected registry
2. Discover test YAML files and filter to those with ``target`` steps
3. Load baselines from ``VALIDATION.BASELINE_ROWS`` table (stage-first)
4. For each YAML test case: materialize baseline + actual into temp tables,
   compare via the data-validation framework's Snowflake-native validators
5. Write results to ``VALIDATION.RESULTS``
"""

from __future__ import annotations

import logging
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase

from test_runner.common.baseline import compute_params_hash
from test_runner.common.config import TestRunnerConfig
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import DatabaseExecutor, DatabaseExecutorFactory
from test_runner.common.dependency_classifier import enrich_test_files
from test_runner.common.discovery import discover_test_files
from test_runner.common.models import (
    MAX_DETAIL_LENGTH,
    MAX_SUMMARY_LENGTH,
    BaselineData,
    TestFile,
    ValidationCaseResult,
    ValidationDifference,
    ValidationStats,
    ValidationSteps,
    truncate,
)
from test_runner.common.template import (
    build_parameters,
    render_output_fetch_statements,
    render_validate_outputs_sql,
    render_validate_resultset_sql,
)

from .baseline_loader import create_baseline_loader
from .comparator import compare_results, errors_match
from .deploy import deploy_snowpark_validator
from .results_writer import write_results_batch, write_results_local

LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Console output
# ---------------------------------------------------------------------------

_SEP = "\u2550" * 60


def _print_header(source: str) -> None:
    print(f"\n{_SEP}")
    print("  VALIDATING SNOWFLAKE AGAINST BASELINES")
    print(f"  Baseline source: {source}")
    print(f"{_SEP}\n")


def _print_case(
    procedure: str,
    status: str,
    match_type: str,
    error: str,
    differences: list[ValidationDifference | str] | None = None,
) -> None:
    icon = "\u2705" if status == "PASS" else "\u274c"
    detail = match_type
    if error:
        detail = f"{match_type}: {truncate(error, MAX_SUMMARY_LENGTH)}"
    print(f"{icon} {status} {procedure} -- {detail}")
    if status not in ("PASS",) and differences:
        for i, diff in enumerate(differences[:5]):
            if isinstance(diff, ValidationDifference):
                print(f"    [{i}] level={diff.level}  type={diff.type}  detail={truncate(diff.detail, MAX_DETAIL_LENGTH)}")
            else:
                print(f"    [{i}] {truncate(str(diff), MAX_DETAIL_LENGTH)}")


def _print_summary(stats: ValidationStats) -> None:
    print(f"\n{_SEP}")
    print(f"  SUMMARY: {stats.total} test cases")
    print(f"  Passed: {stats.passed}  Failed: {stats.failed}  Errors: {stats.errors}")
    if stats.no_baseline:
        print(f"  No baseline: {stats.no_baseline}")
    print(f"{_SEP}\n")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_validate(
    config: TestRunnerConfig,
    factory_registry: dict[DatabaseDialect, DatabaseExecutorFactory],
    project_root: str | Path,
    snowflake_connection: Optional[str] = None,
    baseline_dir: Optional[str | Path] = None,
    baseline_stage: Optional[str] = None,
    pattern: str = ".*",
    create_schema: bool = False,
    connection_override: DatabaseExecutor | None = None,
    output_dir: Optional[str | Path] = None,
    dump_baseline_and_actual: bool = False,
) -> ValidationStats:
    """Execute the full validation pipeline.

    Baselines are loaded from the ``BASELINE_ROWS`` table first; if empty, falls
    back to the implicit stage ``@{database}.VALIDATION.BASELINES``.
    *dump_baseline_and_actual* requires *output_dir* and writes per-case row dumps.
    """
    project_root = Path(project_root)
    regex = re.compile(pattern)

    sf_factory = factory_registry.get(DatabaseDialect.SNOWFLAKE)
    if sf_factory is None:
        raise ValueError("No executor factory registered for Snowflake.")

    executor: Optional[DatabaseExecutor] = None
    owns_executor = connection_override is None
    if connection_override is not None:
        executor = connection_override
    else:
        target_raw = dict(config.target_connection_raw)
        if snowflake_connection:
            target_raw["name"] = snowflake_connection
        if not target_raw.get("name"):
            raise ValueError(
                "Validate requires a Snowflake connection. Provide --connection "
                "or set target_connection.name in settings/test_config.yaml."
            )
        target_raw.setdefault("mode", "name")
        sf_config = sf_factory.build_config(target_raw)
        executor = sf_factory.create_executor(sf_config)

    connector = executor.connector
    if connector is None:
        raise ValueError(
            "Validate requires a Snowflake connector. "
            "The executor must provide a connector property."
        )

    try:
        if create_schema:
            deploy_snowpark_validator(connector, config.validation_database)

        test_files = discover_test_files(project_root, config.selectors)
        test_files = [
            tf for tf in test_files
            if tf.target is not None
            and (regex.search(tf.procedure_name) or regex.search(tf.file_path))
        ]

        enrich_test_files(test_files, project_root)

        if not test_files:
            print("No test YAML files with target steps found.")
            return ValidationStats()

        loader = create_baseline_loader(
            connector=connector,
            database=config.validation_database,
            baseline_dir=Path(baseline_dir) if baseline_dir else None,
            baseline_stage=baseline_stage,
            project_root=project_root,
        )
        t0 = time.monotonic()
        baselines = loader.load()
        LOGGER.info("[timing] baseline load: %.3fs  (%d entries, source=%s)",
                    time.monotonic() - t0, len(baselines), loader.source_label)
        baseline_index: dict[tuple[str, str], BaselineData] = {
            (bl.procedure, bl.params_hash): bl for bl in baselines
        }

        _print_header(loader.source_label)

        stats = ValidationStats()
        all_results: list[ValidationCaseResult] = []
        format_literal = sf_factory.create_literal_formatter().format_literal

        for test_file in test_files:
            for case_idx, test_case in enumerate(test_file.test_cases):
                t_case = time.monotonic()
                result = _validate_case(
                    test_file=test_file,
                    test_case=test_case,
                    baseline_index=baseline_index,
                    connector=connector,
                    executor=executor,
                    format_literal=format_literal,
                    config=config,
                    dump_baseline_and_actual=dump_baseline_and_actual,
                )
                LOGGER.info("[timing] case %s (%s): %.3fs  status=%s",
                            result.procedure, result.params_hash,
                            time.monotonic() - t_case, result.status)
                all_results.append(result)

                stats.total += 1
                if result.status == "PASS":
                    stats.passed += 1
                elif result.status == "NO_BASELINE":
                    stats.no_baseline += 1
                elif result.status == "ERROR":
                    stats.errors += 1
                else:
                    stats.failed += 1

                _print_case(
                    result.procedure, result.status,
                    result.match_type, result.error,
                    differences=result.differences or None,
                )

        if all_results:
            result_dicts = [r.to_dict() for r in all_results]
            # Write local output first -- it pops _baseline_rows/_actual_rows from
            # each result dict and saves them as separate files.  write_results_batch
            # must run afterwards so the Snowflake insert never sees those keys.
            if output_dir:
                try:
                    write_results_local(result_dicts, Path(output_dir))
                except Exception as exc:
                    print(f"Warning: failed to write local results to {output_dir}: {exc}")

            t_write = time.monotonic()
            try:
                write_results_batch(connector, result_dicts, config.validation_database)
                LOGGER.info("[timing] write_results_batch: %.3fs", time.monotonic() - t_write)
            except Exception as exc:
                print(f"Warning: failed to write results to VALIDATION.RESULTS: {exc}")

        _print_summary(stats)
        return stats

    finally:
        if owns_executor and executor is not None:
            executor.close()


# ---------------------------------------------------------------------------
# Internal: validate a single test case
# ---------------------------------------------------------------------------

def _validate_case(
    test_file: TestFile,
    test_case: list[Any],
    baseline_index: dict[tuple[str, str], BaselineData],
    connector: ConnectorBase,
    executor: DatabaseExecutor,
    format_literal: Callable[[Any], str],
    config: TestRunnerConfig,
    dump_baseline_and_actual: bool = False,
) -> ValidationCaseResult:
    """Validate one test case from a YAML file against its baseline."""
    parameters = build_parameters(test_file.parameter_names, test_case)
    params_hash = compute_params_hash(parameters)
    procedure = test_file.procedure_name

    result = ValidationCaseResult(
        procedure=procedure,
        params_hash=params_hash,
        params=parameters,
        status="",
        metadata={
            "modifies_data": test_file.modifies_data,
            "affected_tables": test_file.affected_tables,
            "source_checksum": test_file.source_checksum,
            "converted_checksum": test_file.converted_checksum,
        },
        executed_at=datetime.now(timezone.utc).isoformat(),
    )

    baseline = baseline_index.get((procedure, params_hash))
    if baseline is None:
        result.status = "NO_BASELINE"
        result.error = f"No baseline found for {procedure} (params_hash={params_hash})"
        return result

    assert test_file.target is not None
    target_sql = render_validate_resultset_sql(
        test_file.target, test_case, format_literal,
    )

    fetch_stmts = render_output_fetch_statements(
        test_file.target, test_case, "snowflake",
    )

    rendered_steps = ValidationSteps(
        run=test_file.target.run,
        pre_execute=test_file.target.pre_execute,
        output_parameters=test_file.target.output_parameters,
        output_tables=test_file.target.output_tables,
    )

    outputs_sql: str | None = None
    if test_file.target.output_parameters:
        outputs_sql = render_validate_outputs_sql(
            test_file.target, test_case, format_literal,
        )

    # Handle error baselines
    if not baseline.success:
        capture_result = executor.execute(target_sql, steps=rendered_steps)
        if not capture_result.success:
            if errors_match(baseline.error or "", capture_result.error or ""):
                result.status = "PASS"
                result.match_type = "error_match"
            else:
                result.status = "FAIL"
                result.match_type = "error_mismatch"
                result.error = (
                    f"Baseline: {truncate(baseline.error or '', MAX_SUMMARY_LENGTH)}, "
                    f"Actual: {truncate(capture_result.error or '', MAX_SUMMARY_LENGTH)}"
                )
        else:
            result.status = "FAIL"
            result.error = f"Baseline errored: {truncate(baseline.error or '', MAX_SUMMARY_LENGTH)}"
        return result

    outputs_only = bool(
        not baseline.row_counts and outputs_sql
    )

    comparison = compare_results(
        config=config,
        connector=connector,
        rendered_sql=target_sql,
        params_hash=params_hash,
        procedure_name=procedure,
        baseline=baseline,
        dump_baseline_and_actual=dump_baseline_and_actual,
        fetch_stmts=fetch_stmts or None,
        outputs_sql=outputs_sql,
        outputs_only=outputs_only,
    )

    result.status = "PASS" if comparison.match else "FAIL"
    result.match_type = comparison.match_type
    result.match_level = comparison.match_level
    result.differences = list(comparison.differences[:5])

    if comparison.in_memory_diff is not None:
        result.in_memory_diff = comparison.in_memory_diff

    if comparison.baseline_rows is not None:
        result.baseline_rows = comparison.baseline_rows
    if comparison.actual_rows is not None:
        result.actual_rows = comparison.actual_rows

    if not comparison.match and comparison.differences:
        first = comparison.differences[0]
        if isinstance(first, ValidationDifference):
            result.error = first.detail
        else:
            result.error = str(first)

    return result
