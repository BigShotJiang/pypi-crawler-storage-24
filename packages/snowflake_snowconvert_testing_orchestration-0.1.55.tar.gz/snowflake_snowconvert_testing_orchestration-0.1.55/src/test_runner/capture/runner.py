"""
Capture runner -- orchestrates the full baseline-capture pipeline.

1. Resolve the source executor factory from the injected registry
2. Discover test YAML files from ``artifacts/**/test/*.yml``
3. For each test file / test case:
   a. Render the SQL template with dialect-specific literal formatting
   b. Execute on the source database
   c. Save baseline JSON to disk
4. Optionally upload baselines to a Snowflake stage
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

from test_runner.common.baseline import write_baseline
from test_runner.common.config import TestRunnerConfig
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import DatabaseExecutor, DatabaseExecutorFactory
from test_runner.common.dependency_classifier import enrich_test_files
from test_runner.common.discovery import discover_test_files
from test_runner.common.models import BaselineData, TestCaseStats, TestFile, ValidationSteps
from test_runner.common.template import (
    build_parameters,
    render_capture_sql,
    render_full_sql,
    render_output_fetch_statements,
)
from .stage_uploader import StageUploader


# ---------------------------------------------------------------------------
# Console output helpers
# ---------------------------------------------------------------------------

_SEPARATOR = "\u2550" * 60


def _print_header(dialect: str, baseline_dir: Path, stage: str = "") -> None:
    print(f"\n{_SEPARATOR}")
    print(f"  CAPTURING BASELINES FROM {dialect.upper()}")
    if stage:
        print(f"  Stage:  {stage}")
    print(f"  Output: {baseline_dir}")
    print(f"{_SEPARATOR}\n")


def _print_case_result(procedure: str, case_idx: int, result: BaselineData) -> None:
    icon = "\u2705" if result.success else "\u274c"
    if result.success:
        parts: list[str] = []
        if result.output_params:
            n = len(result.output_params)
            parts.append(f"{n} output param{'s' if n != 1 else ''}")
        if result.row_counts:
            if len(result.row_counts) == 1:
                parts.append(f"{result.row_counts[0]} rows")
            else:
                total = sum(result.row_counts)
                parts.append(f"{total} rows ({len(result.row_counts)} sets)")
        suffix = ", ".join(parts) if parts else "0 rows"
    else:
        suffix = f"ERROR: {result.error}"
    print(f"{icon} {procedure} (case {case_idx + 1}) -> {suffix}")


def _print_summary(stats: TestCaseStats) -> None:
    print(f"\n{_SEPARATOR}")
    print(f"  CAPTURED {stats.total} BASELINES")
    if stats.failed:
        print(f"  {stats.succeeded} succeeded, {stats.failed} failed")
    print(f"{_SEPARATOR}\n")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_capture(
    config: TestRunnerConfig,
    factory_registry: dict[DatabaseDialect, DatabaseExecutorFactory],
    project_root: str | Path,
    baseline_dir: Optional[str | Path] = None,
    snowflake_connection: Optional[str] = None,
    executor_override: Optional[DatabaseExecutor] = None,
    format_literal_override: Optional[Callable[[Any], str]] = None,
) -> TestCaseStats:
    """Execute the full capture pipeline.

    Baselines are always written to disk.  When a Snowflake connection is
    available they are also uploaded to the implicit internal stage
    ``@{validation_database}.VALIDATION.BASELINES`` and materialized
    into the ``BASELINE_ROWS`` table.

    Args:
        config: Loaded test runner configuration.
        factory_registry: Dialect -> factory mapping (injected).
        project_root: Path to the SCAI project root.
        baseline_dir: Override directory for baseline files.
        snowflake_connection: Snowflake connection name for stage upload.
        executor_override: Pre-built executor (for testing).
        format_literal_override: Override the SQL literal formatter (for testing).

    Returns:
        :class:`TestCaseStats` with totals and the list of written baseline paths.
    """
    project_root = Path(project_root)

    # -- resolve factory from registry ---------------------------------------
    factory: Optional[DatabaseExecutorFactory] = None

    if executor_override is None:
        if not config.source_connection_raw:
            raise ValueError(
                "Capture requires 'source_connection' in settings/test_config.yaml."
            )
        factory = factory_registry.get(config.source_dialect)
        if factory is None:
            raise ValueError(
                f"No executor factory for dialect '{config.source_dialect.value}'."
            )

    # -- literal formatter (dialect-specific) --------------------------------
    if format_literal_override is not None:
        format_literal = format_literal_override
    elif factory is not None:
        format_literal = factory.create_literal_formatter().format_literal
    else:
        from test_runner.common.template import format_sql_literal
        format_literal = format_sql_literal

    # -- baseline directory --------------------------------------------------
    if baseline_dir is None:
        baseline_dir = project_root / ".scai" / "baselines"
    baseline_dir = Path(baseline_dir)

    capture_date = datetime.now(timezone.utc)

    # -- discover test files -------------------------------------------------
    test_files = discover_test_files(project_root, config.selectors)
    if not test_files:
        print("No test files found in artifacts/**/test/*.yml")
        return TestCaseStats()

    enrich_test_files(test_files, project_root)

    # -- create source executor -----------------------------------------------
    executor = executor_override
    owns_executor = executor is None
    if executor is None and factory is not None:
        source_config = factory.build_config(config.source_connection_raw)
        executor = factory.create_executor(source_config)

    if executor is None:
        raise RuntimeError("No executor available. Provide source_connection or executor_override.")

    # -- stage uploader (uses provided stage or implicit default) --------------
    uploader: Optional[StageUploader] = None
    stage = f"@{config.validation_database}.VALIDATION.BASELINES"
    sf_factory = factory_registry.get(DatabaseDialect.SNOWFLAKE)
    if sf_factory is not None:
        target_raw = dict(config.target_connection_raw) if config.target_connection_raw else {}
        if snowflake_connection:
            target_raw["name"] = snowflake_connection
        if target_raw.get("name"):
            target_raw.setdefault("mode", "name")
            sf_config = sf_factory.build_config(target_raw)
            sf_executor = sf_factory.create_executor(sf_config)
            if sf_executor.connector is not None:
                uploader = StageUploader(
                    sf_executor.connector, stage, config.validation_database,
                )

    # -- run -----------------------------------------------------------------
    stats = TestCaseStats()

    _print_header(config.source_dialect.value, baseline_dir, stage if uploader else "")

    try:
        for test_file in test_files:
            _capture_test_file(
                test_file=test_file,
                executor=executor,
                format_literal=format_literal,
                baseline_dir=baseline_dir,
                capture_date=capture_date,
                stats=stats,
                dialect=config.source_dialect.value,
            )
    finally:
        if owns_executor:
            executor.close()

    # -- stage upload -----------------------------------------------------------
    if uploader is not None:
        try:
            date_folder = capture_date.strftime("%Y%m%d")
            upload_root = baseline_dir / date_folder
            if upload_root.exists():
                count = uploader.upload_directory(upload_root, date_folder)
                print(f"\nUploaded {count} baselines to {stage}")
        finally:
            uploader.close()

    _print_summary(stats)
    return stats


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------

def _capture_test_file(
    test_file: TestFile,
    executor: DatabaseExecutor,
    format_literal: Callable[[Any], str],
    baseline_dir: Path,
    capture_date: datetime,
    stats: TestCaseStats,
    dialect: str = "sqlserver",
) -> None:
    """Capture all test cases for a single test file."""
    outputs = test_file.source.output_parameters
    for case_idx, test_case in enumerate(test_file.test_cases):
        sql = render_capture_sql(test_file.source, test_case, dialect, format_literal)

        fetch_stmts = render_output_fetch_statements(
            test_file.source, test_case, dialect,
        )

        rendered_steps = ValidationSteps(
            run=test_file.source.run,
            pre_execute=test_file.source.pre_execute,
            output_parameters=outputs,
            output_tables=test_file.source.output_tables,
            output_cursors=test_file.source.output_cursors,
        )

        result = executor.execute(
            sql, steps=rendered_steps, fetch_stmts=fetch_stmts or None,
        )

        parameters = build_parameters(test_file.parameter_names, test_case)

        baseline = BaselineData.from_capture(
            procedure=test_file.procedure_name,
            parameters=parameters,
            result=result,
        )

        path = write_baseline(baseline, baseline_dir, case_idx, capture_date)

        stats.total += 1
        if result.success:
            stats.succeeded += 1
        else:
            stats.failed += 1
        stats.baseline_files.append(str(path))

        _print_case_result(test_file.procedure_name, case_idx, baseline)
