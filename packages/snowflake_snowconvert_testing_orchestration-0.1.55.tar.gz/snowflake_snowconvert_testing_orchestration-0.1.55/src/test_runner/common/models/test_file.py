"""Parsed test YAML file produced by ``scai test seed``."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from .validation_steps import ValidationSteps


@dataclass
class TestFile:
    """A parsed test YAML file produced by ``scai test seed``."""

    file_path: str
    """Absolute path to the YAML file on disk."""

    source: ValidationSteps
    """Source-side execution steps (used by capture)."""

    test_cases: list[list[Any]]
    """List of test cases; each is an array of positional values."""

    target: Optional[ValidationSteps] = None
    """Target-side execution steps (used by validate). Optional."""

    procedure_name: str = ""
    """Procedure name extracted from the source ``run`` template."""

    parameter_names: list[str] = field(default_factory=list)
    """Parameter names extracted from the source ``run`` template."""

    modifies_data: Optional[bool] = None
    """Override flag indicating this procedure modifies data."""

    affected_tables: Optional[list[str]] = None
    """Override list of affected tables."""

    source_checksum: Optional[str] = None
    """BLAKE3 checksum of the source procedure file, computed at test-run time."""

    converted_checksum: Optional[str] = None
    """BLAKE3 checksum of the converted procedure file, computed at test-run time."""
