"""Result of executing a test case."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class TestCaseResult:
    """Result of executing a single test case."""

    result_sets: list[list[dict[str, Any]]] = field(default_factory=list)
    """List of result sets; each is a list of row dicts."""

    row_counts: list[int] = field(default_factory=list)
    """Row count for each result set."""

    column_types: list[dict[str, str]] = field(default_factory=list)
    """Column types per result set (``COLUMN_NAME`` -> canonical type label).

    Populated at capture time from live Python values so the types survive
    JSON serialization.  Used by the validate step for schema comparison.
    """

    output_params: Optional[dict[str, Any]] = None
    """Output parameter values captured after execution (name -> value).
    Populated when the procedure has OUTPUT parameters and the executor
    retrieves them via a second result set."""

    output_param_types: Optional[dict[str, str]] = None
    """Column types for output parameters (name -> Snowflake type).
    Populated alongside ``output_params`` so the validate step can cast
    baseline values to their original types."""

    success: bool = True
    """Whether the execution completed without error."""

    error: Optional[str] = None
    """Error message if execution failed."""
