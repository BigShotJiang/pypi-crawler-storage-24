"""Tests for test_runner.discovery."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from test_runner.common.config import SelectorsConfig
from test_runner.common.discovery import (
    _parse_steps,
    discover_test_files,
    extract_all_parameter_names,
    extract_parameter_names,
    extract_procedure_name,
)

FIXTURES_DIR = Path(__file__).parent / "fixtures"


# ---------------------------------------------------------------------------
# extract_procedure_name
# ---------------------------------------------------------------------------


class TestExtractProcedureName:
    def test_execute_with_db_schema_proc(self):
        assert extract_procedure_name("EXECUTE master.dbo.GetProducts") == "master.dbo.GetProducts"

    def test_exec_with_schema_proc(self):
        assert extract_procedure_name("EXEC RPT.GetProducts @lspId = {0}") == "RPT.GetProducts"

    def test_call_syntax(self):
        assert extract_procedure_name("CALL RPT.GetProducts({0}, {1})") == "RPT.GetProducts"

    def test_no_match(self):
        assert extract_procedure_name("SELECT * FROM dbo.Products") == ""

    def test_case_insensitive(self):
        assert extract_procedure_name("exec dbo.GetProducts") == "dbo.GetProducts"


# ---------------------------------------------------------------------------
# extract_parameter_names
# ---------------------------------------------------------------------------


class TestExtractParameterNames:
    def test_basic_params(self):
        template = "EXEC dbo.P @a = {0}, @b = {1}"
        assert extract_parameter_names(template) == ["a", "b"]

    def test_no_params(self):
        assert extract_parameter_names("EXECUTE dbo.GetProducts") == []

    def test_mixed_spacing(self):
        template = "EXEC dbo.P @x={0}, @y ={1}, @z = {2}"
        assert extract_parameter_names(template) == ["x", "y", "z"]


# ---------------------------------------------------------------------------
# discover_test_files
# ---------------------------------------------------------------------------


class TestDiscoverTestFiles:
    def test_discovers_files(self, tmp_project: Path):
        files = discover_test_files(tmp_project)
        assert len(files) == 2
        names = {f.procedure_name for f in files}
        assert "master.dbo.GetProducts" in names
        assert "master.dbo.GetCustomerOrders" in names

    def test_extracts_test_cases(self, tmp_project: Path):
        files = discover_test_files(tmp_project)
        orders = next(f for f in files if "GetCustomerOrders" in f.procedure_name)
        assert len(orders.test_cases) == 3
        assert orders.test_cases[0] == [1001, "active"]

    def test_extracts_parameter_names(self, tmp_project: Path):
        files = discover_test_files(tmp_project)
        orders = next(f for f in files if "GetCustomerOrders" in f.procedure_name)
        assert orders.parameter_names == ["customerId", "status"]

    def test_no_artifacts_dir(self, tmp_path: Path):
        files = discover_test_files(tmp_path)
        assert files == []

    def test_selector_schema_filter(self, tmp_project_with_rpt: Path):
        """Only RPT files when schemas filter is ['RPT']."""
        selectors = SelectorsConfig(schemas=["RPT"])
        files = discover_test_files(tmp_project_with_rpt, selectors)
        assert len(files) == 1
        assert "RPT" in files[0].file_path.upper()

    def test_selector_exclude(self, tmp_project: Path):
        selectors = SelectorsConfig(exclude=["getproducts.a1b2c3d4"])
        files = discover_test_files(tmp_project, selectors)
        assert len(files) == 1
        assert "GetCustomerOrders" in files[0].procedure_name

    def test_rpt_schema_procedure(self, tmp_project_with_rpt: Path):
        files = discover_test_files(tmp_project_with_rpt)
        rpt_file = next(f for f in files if f.parameter_names and "lspId" in f.parameter_names)
        assert rpt_file.parameter_names == ["lspId", "locId", "fromDate"]
        assert len(rpt_file.test_cases) == 2

    def test_discovers_output_parameters(self, tmp_project_with_output_params: Path):
        files = discover_test_files(tmp_project_with_output_params)
        details = next(f for f in files if "GetProductDetails" in f.procedure_name)
        assert details.source.output_parameters == ["@productName", "@unitPrice"]
        assert details.target is not None
        assert details.target.output_parameters == ["PRODUCTNAME", "UNITPRICE"]

    def test_output_params_parameter_names_include_all(
        self, tmp_project_with_output_params: Path,
    ):
        files = discover_test_files(tmp_project_with_output_params)
        details = next(f for f in files if "GetProductDetails" in f.procedure_name)
        assert details.parameter_names == ["productId", "productName", "unitPrice"]


# ---------------------------------------------------------------------------
# extract_all_parameter_names
# ---------------------------------------------------------------------------


class TestExtractAllParameterNames:
    def test_run_only(self):
        names = extract_all_parameter_names("EXEC dbo.P @a = {0}, @b = {1}")
        assert names == ["a", "b"]

    def test_run_and_pre_execute(self):
        names = extract_all_parameter_names(
            "EXEC dbo.P @id = {0}, @out = @out OUTPUT",
            pre_execute="DECLARE @out VARCHAR(MAX) = {1};",
        )
        assert names == ["id", "out"]

    def test_multiple_pre_execute_params(self):
        names = extract_all_parameter_names(
            "EXEC dbo.P @id = {0}",
            pre_execute="DECLARE @a INT = {1};\nDECLARE @b INT = {2};",
        )
        assert names == ["id", "a", "b"]

    def test_snowflake_let_syntax(self):
        names = extract_all_parameter_names(
            "CALL DBO.P({0}, :X, :Y)",
            pre_execute="LET X VARCHAR := {1};\nLET Y DECIMAL := {2};",
        )
        assert names == ["X", "Y"]

    def test_no_pre_execute(self):
        names = extract_all_parameter_names("EXEC dbo.P @a = {0}")
        assert names == ["a"]

    def test_empty_run_no_pre_execute(self):
        names = extract_all_parameter_names("EXECUTE dbo.GetProducts")
        assert names == []


# ---------------------------------------------------------------------------
# _parse_steps with output.parameters
# ---------------------------------------------------------------------------


class TestParseStepsOutputParameters:
    def test_parses_output_parameters(self):
        raw = {
            "run": "EXEC dbo.P @id = {0}",
            "output": {
                "parameters": ["@out1", "@out2"],
            },
        }
        steps = _parse_steps(raw)
        assert steps is not None
        assert steps.output_parameters == ["@out1", "@out2"]
        assert steps.output_tables is None

    def test_parses_output_tables(self):
        raw = {
            "run": "EXEC dbo.P",
            "output": {
                "tables": ["#temp"],
            },
        }
        steps = _parse_steps(raw)
        assert steps is not None
        assert steps.output_parameters is None
        assert steps.output_tables == ["#temp"]
        assert steps.output_cursors is None

    def test_parses_output_cursors(self):
        raw = {
            "run": "CALL get_sales({0}, {1})",
            "output": {
                "cursors": ["{1}"],
            },
        }
        steps = _parse_steps(raw)
        assert steps is not None
        assert steps.output_cursors == ["{1}"]
        assert steps.output_tables is None
        assert steps.output_parameters is None

    def test_parses_combined_output(self):
        raw = {
            "run": "CALL proc({0}, {1}, {2})",
            "output": {
                "parameters": ["total"],
                "cursors": ["{2}"],
            },
        }
        steps = _parse_steps(raw)
        assert steps is not None
        assert steps.output_parameters == ["total"]
        assert steps.output_cursors == ["{2}"]

    def test_no_output_section(self):
        raw = {"run": "EXEC dbo.P @a = {0}"}
        steps = _parse_steps(raw)
        assert steps is not None
        assert steps.output_parameters is None
        assert steps.output_tables is None
        assert steps.output_cursors is None
