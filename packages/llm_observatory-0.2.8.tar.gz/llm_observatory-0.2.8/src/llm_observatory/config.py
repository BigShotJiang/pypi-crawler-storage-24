"""Global SDK configuration."""

import os

_config = {
    "api_key": None,
    "base_url": None,
    "flush_interval": 5.0,
    "flush_batch_size": 50,
    "max_queue_size": 1000,
    "enabled": True,
    "redact_messages": False,
}


def configure(
    api_key: str | None = None,
    base_url: str | None = None,
    flush_interval: float = 5.0,
    flush_batch_size: int = 50,
    max_queue_size: int = 1000,
    enabled: bool = True,
    redact_messages: bool = False,
) -> None:
    _config["api_key"] = api_key or os.environ.get("LLM_OBSERVATORY_API_KEY")
    _config["base_url"] = base_url or os.environ.get("LLM_OBSERVATORY_BASE_URL")
    _config["flush_interval"] = flush_interval
    _config["flush_batch_size"] = flush_batch_size
    _config["max_queue_size"] = max_queue_size
    _config["redact_messages"] = redact_messages

    enabled_env = os.environ.get("LLM_OBSERVATORY_ENABLED")
    if enabled_env is not None:
        _config["enabled"] = enabled_env.lower() not in ("0", "false", "no")
    else:
        _config["enabled"] = enabled

    # Invalidate the transport singleton so it picks up new settings
    from llm_observatory.transport import shutdown_transport
    shutdown_transport()


def get_config() -> dict:
    return _config
