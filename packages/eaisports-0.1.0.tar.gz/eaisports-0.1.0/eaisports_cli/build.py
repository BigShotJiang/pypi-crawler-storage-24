"""
EAISports Build Command -- game-building orchestrator.

Launches an AI-powered build session that:
1. Creates a game output directory under ~/.eaisports/games/{slug}/
2. Scaffolds a React + Vite project structure
3. Spins up an AIAgent with build-specific system prompt
4. Runs the agent conversation loop
5. On completion, attempts nudge (skill extraction) and flush (memory flush)

Usage (from CLI):
    eaisports build                       # interactive -- asks what to build
    eaisports build my-trivia-game        # provide slug upfront
    eaisports build --skill trivia        # start with a skill template
    eaisports build --resume my-game      # resume previous session
"""

import json
import logging
import os
import re
import sys
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


# =========================================================================
# Slug helpers
# =========================================================================

def _slugify(text: str) -> str:
    """Convert arbitrary text into a URL-safe slug.

    Lowercase, replace spaces/underscores with hyphens, strip anything
    that isn't alphanumeric or a hyphen, collapse repeated hyphens.
    """
    text = text.lower().strip()
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"[^a-z0-9-]", "", text)
    text = re.sub(r"-{2,}", "-", text)
    return text.strip("-") or "untitled-game"


def _prompt_for_slug() -> str:
    """Interactively ask the user for a game name and slugify it."""
    try:
        from prompt_toolkit import prompt as pt_prompt
        raw = pt_prompt("  Game name (e.g. 'Space Trivia'): ").strip()
    except (ImportError, KeyboardInterrupt, EOFError):
        raw = input("  Game name (e.g. 'Space Trivia'): ").strip()
    if not raw:
        raw = "untitled-game"
    return _slugify(raw)


# =========================================================================
# Project scaffolding
# =========================================================================

_INDEX_HTML = """\
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>{slug}</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
"""

_PACKAGE_JSON = """\
{{
  "name": "{slug}",
  "private": true,
  "version": "0.1.0",
  "type": "module",
  "scripts": {{
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  }},
  "dependencies": {{
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  }},
  "devDependencies": {{
    "vite": "^5.0.0",
    "@vitejs/plugin-react": "^4.2.0"
  }}
}}
"""

_VITE_CONFIG = """\
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
  },
});
"""

_MAIN_JSX = """\
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
"""

_APP_JSX = """\
import React from 'react';

function App() {{
  return (
    <div style={{{{ textAlign: 'center', padding: '2rem' }}}}>
      <h1>Hello from {slug}</h1>
      <p>Start building your game!</p>
    </div>
  );
}}

export default App;
"""

_INDEX_CSS = """\
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
    Oxygen, Ubuntu, Cantarell, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  min-height: 100vh;
  background: #0a0a0a;
  color: #ededed;
}

#root {
  min-height: 100vh;
}
"""


def _scaffold_project(game_dir: Path, slug: str) -> None:
    """Create the React + Vite project skeleton in *game_dir*.

    Writes only files that don't already exist so that ``--resume``
    doesn't clobber user edits.
    """
    files = {
        "index.html": _INDEX_HTML.format(slug=slug),
        "package.json": _PACKAGE_JSON.format(slug=slug),
        "vite.config.js": _VITE_CONFIG,
        "src/main.jsx": _MAIN_JSX,
        "src/App.jsx": _APP_JSX.format(slug=slug),
        "src/styles/index.css": _INDEX_CSS,
    }

    # Create directories (including empty placeholder dirs)
    for d in ("src/components", "src/data", "src/styles"):
        (game_dir / d).mkdir(parents=True, exist_ok=True)

    # Write files (skip existing for resume safety)
    for rel_path, content in files.items():
        target = game_dir / rel_path
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
            logger.debug("Wrote %s", target)
        else:
            logger.debug("Skipped existing %s", target)


# =========================================================================
# Build session
# =========================================================================

def run_build_session(
    slug: Optional[str] = None,
    budget: Optional[int] = None,
    resume_slug: Optional[str] = None,
    skill_name: Optional[str] = None,
    model: Optional[str] = None,
) -> None:
    """Run an end-to-end game build session.

    Parameters
    ----------
    slug:
        Game directory name. If *None*, the user is prompted interactively.
    budget:
        Max agent iterations. Falls back to config value or 50.
    resume_slug:
        If set, resume a previous build in ``~/.eaisports/games/{resume_slug}/``.
    skill_name:
        Optional skill to seed the build with.
    model:
        Model override for this session.
    """
    from eaisports_cli.config import load_config, get_eaisports_home
    from eaisports_cli.colors import Colors, color

    config = load_config()
    home = get_eaisports_home()

    # -- Resolve slug
    if resume_slug:
        slug = resume_slug
        game_dir = home / "games" / slug
        if not game_dir.exists():
            print(color(f"  No game found at {game_dir}", Colors.RED))
            sys.exit(1)
        print(color(f"  Resuming build: {slug}", Colors.CYAN))
    else:
        if not slug:
            slug = _prompt_for_slug()
        slug = _slugify(slug)
        game_dir = home / "games" / slug
        game_dir.mkdir(parents=True, exist_ok=True)
        print(color(f"  Creating game: {slug}", Colors.CYAN))

    # -- Scaffold
    _scaffold_project(game_dir, slug)
    print(color(f"  Game directory: {game_dir}", Colors.DIM))

    # -- Session tracking
    from eaisports_state import SessionDB

    session_db = SessionDB()
    parent_session_id = None
    session_id = str(uuid.uuid4())

    meta_path = game_dir / ".build_meta.json"
    if resume_slug and meta_path.exists():
        try:
            prev_meta = json.loads(meta_path.read_text(encoding="utf-8"))
            parent_session_id = prev_meta.get("session_id")
            if parent_session_id:
                print(color(f"  Resuming session: {parent_session_id[:8]}...", Colors.DIM))
        except (json.JSONDecodeError, KeyError):
            logger.debug("Could not read previous build meta, starting fresh session")

    # -- Resolve model
    effective_model = model or config.get("model", "anthropic/claude-opus-4.6")

    # -- Resolve budget
    effective_budget = budget or config.get("build_budget", 50)

    # -- Build system prompt
    from agent.build_prompt import build_game_prompt

    build_prompt = build_game_prompt(
        slug=slug,
        game_dir=str(game_dir),
        skill_name=skill_name,
    )

    # -- Register session in DB (before AIAgent, which also tries create_session
    #    but silently skips if it already exists due to duplicate primary key)
    try:
        session_db.create_session(
            session_id=session_id,
            source="build",
            model=effective_model,
            system_prompt=build_prompt,
            parent_session_id=parent_session_id,
        )
    except Exception as exc:
        logger.debug("Session DB create_session failed: %s", exc)

    # -- Create agent
    from run_agent import AIAgent

    agent = AIAgent(
        model=effective_model,
        max_iterations=effective_budget,
        enabled_toolsets=["file", "terminal", "web", "skills"],
        save_trajectories=True,
        platform="cli",
        ephemeral_system_prompt=build_prompt,
        session_id=session_id,
        session_db=session_db,
    )

    # -- Prepare initial message
    if skill_name:
        initial_message = (
            f"Build a game called '{slug}' using the '{skill_name}' skill template. "
            f"All files go in {game_dir}. The project is already scaffolded with "
            f"React + Vite. Start by examining the skill template, then implement "
            f"the game."
        )
    else:
        initial_message = (
            f"Build a game called '{slug}'. All files go in {game_dir}. "
            f"The project is already scaffolded with React + Vite (index.html, "
            f"package.json, vite.config.js, src/main.jsx, src/App.jsx). "
            f"Ask me what kind of game I want, then build it step by step."
        )

    print(color(f"  Model: {effective_model}", Colors.DIM))
    print(color(f"  Budget: {effective_budget} iterations", Colors.DIM))
    print()

    # -- Run the conversation
    end_reason = "completed"
    try:
        result = agent.run_conversation(user_message=initial_message)
        print()
        print(color("  Build session complete.", Colors.GREEN))
    except KeyboardInterrupt:
        print()
        print(color("  Build session interrupted.", Colors.YELLOW))
        result = None
        end_reason = "interrupted"

    # -- End session in DB
    try:
        session_db.end_session(session_id, end_reason)
    except Exception as exc:
        logger.debug("Session DB end_session failed: %s", exc)

    # -- Save build metadata
    try:
        meta = {
            "session_id": session_id,
            "built_at": datetime.now().isoformat(),
            "slug": slug,
            "skill_used": skill_name,
            "model": effective_model,
        }
        if parent_session_id:
            meta["parent_session_id"] = parent_session_id
        meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    except Exception as exc:
        logger.debug("Failed to write build meta: %s", exc)

    # -- Post-build: nudge (skill extraction) and flush (memory)
    try:
        from eaisports_cli.nudge import run_nudge
        run_nudge(slug=slug, game_dir=str(game_dir))
    except (ImportError, Exception) as exc:
        logger.debug("Nudge skipped: %s", exc)

    try:
        from eaisports_cli.flush import run_flush
        run_flush(slug=slug)
    except (ImportError, Exception) as exc:
        logger.debug("Flush skipped: %s", exc)
