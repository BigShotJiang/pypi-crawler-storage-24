"""
EAISports initialization wizard.

Runs on `eaisports init` — guides creators through first-time setup:
1. Welcome + system check
2. API provider & key setup
3. Model selection
4. Wallet connect
5. Default skills installation
6. Memory file creation
"""

import os
import sys
from pathlib import Path
from typing import Optional

from eaisports_cli.colors import Colors, color


def run_init_wizard():
    """Run the full EAISports init wizard."""
    _print_welcome()

    # Step 1: Check if already initialized
    from eaisports_cli.config import load_config, save_config, get_config_path
    config = load_config()
    config_path = get_config_path()

    if config_path.exists():
        print(color("  EAISports is already initialized.", Colors.YELLOW))
        print(color(f"  Config: {config_path}", Colors.DIM))
        print()

        try:
            from prompt_toolkit import prompt
            answer = prompt("  Re-run setup? (y/N): ").strip().lower()
            if answer not in ("y", "yes"):
                print(color("  → No changes made.", Colors.DIM))
                return
        except (KeyboardInterrupt, EOFError):
            print()
            return

    print()

    # Step 2: API Provider & Key
    print(color("  Step 1/4: API Provider", Colors.CYAN + Colors.BOLD))
    _setup_api_key(config)

    # Step 3: Model Selection
    print()
    print(color("  Step 2/4: Model Selection", Colors.CYAN + Colors.BOLD))
    _setup_models(config)

    # Step 4: Wallet Connect
    print()
    print(color("  Step 3/4: Wallet Connect", Colors.CYAN + Colors.BOLD))
    _setup_wallet(config)

    # Step 5: Create memory files + install default skills
    print()
    print(color("  Step 4/4: Workspace Setup", Colors.CYAN + Colors.BOLD))
    _setup_workspace(config)

    # Save config
    save_config(config)

    # Done
    print()
    print(color("  ┌─────────────────────────────────────────────────┐", Colors.GREEN))
    print(color("  │         EAISports is ready to go!               │", Colors.GREEN))
    print(color("  └─────────────────────────────────────────────────┘", Colors.GREEN))
    print()
    print(color("  Next steps:", Colors.BOLD))
    print(color("    eaisports chat       — Start a chat session", Colors.DIM))
    print(color("    eaisports build      — Build a game (coming soon)", Colors.DIM))
    print(color("    eaisports skills list — Browse available skills", Colors.DIM))
    print()


def _print_welcome():
    """Print the welcome banner."""
    print()
    print(color("  ╔═══════════════════════════════════════════════════╗", Colors.CYAN))
    print(color("  ║                                                   ║", Colors.CYAN))
    print(color("  ║        Welcome to EAISports                       ║", Colors.CYAN))
    print(color("  ║        AI-Powered Game Building CLI                ║", Colors.CYAN))
    print(color("  ║                                                   ║", Colors.CYAN))
    print(color("  ╚═══════════════════════════════════════════════════╝", Colors.CYAN))
    print()
    print(color("  This wizard will set up your environment in 4 quick steps.", Colors.DIM))


def _setup_api_key(config: dict):
    """Set up API provider and key."""
    from eaisports_cli.config import get_env_value, save_env_value

    print(color("  EAISports uses OpenRouter for AI model access.", Colors.DIM))
    print(color("  Get your API key at: https://openrouter.ai/keys", Colors.DIM))
    print()

    # Check if already configured
    existing = get_env_value("OPENROUTER_API_KEY")
    if existing:
        print(color("  ✓ API key already configured.", Colors.GREEN))
        return

    try:
        from prompt_toolkit import prompt as pt_prompt
        api_key = pt_prompt("  OpenRouter API key (Enter to skip): ", is_password=True).strip()
        if api_key:
            save_env_value("OPENROUTER_API_KEY", api_key)
            print(color("  ✓ API key saved.", Colors.GREEN))
        else:
            print(color("  → Skipped. Set it later: export OPENROUTER_API_KEY=your_key", Colors.DIM))
    except (KeyboardInterrupt, EOFError):
        print()
        print(color("  → Skipped.", Colors.DIM))
    except Exception as e:
        print(color(f"  ⚠ Could not set up API key: {e}", Colors.YELLOW))
        print(color("  → You can set it later: export OPENROUTER_API_KEY=your_key", Colors.DIM))


def _setup_models(config: dict):
    """Configure model routing."""
    from prompt_toolkit import prompt as pt_prompt

    models = config.get("models", {})
    primary = models.get("primary", "anthropic/claude-sonnet-4")
    auxiliary = models.get("auxiliary", "google/gemini-2.0-flash-001")

    print(color(f"  Primary model (game building): {primary}", Colors.DIM))
    print(color(f"  Auxiliary model (quick tasks):  {auxiliary}", Colors.DIM))
    print()

    try:
        answer = pt_prompt("  Keep defaults? (Y/n): ").strip().lower()
        if answer in ("n", "no"):
            new_primary = pt_prompt(f"  Primary model [{primary}]: ").strip()
            if new_primary:
                config.setdefault("models", {})["primary"] = new_primary

            new_aux = pt_prompt(f"  Auxiliary model [{auxiliary}]: ").strip()
            if new_aux:
                config.setdefault("models", {})["auxiliary"] = new_aux

            print(color("  ✓ Models updated.", Colors.GREEN))
        else:
            print(color("  ✓ Using default models.", Colors.GREEN))
    except (KeyboardInterrupt, EOFError):
        print()
        print(color("  → Using defaults.", Colors.DIM))


def _setup_wallet(config: dict):
    """Set up Solana wallet."""
    from eaisports_cli.wallet import prompt_wallet_connect

    address = prompt_wallet_connect()
    if address:
        config["wallet_address"] = address


def _setup_workspace(config: dict):
    """Create memory files and install default skills."""
    home = Path(os.environ.get("EAISPORTS_HOME", Path.home() / ".eaisports"))

    # Create directories
    agent_dir = home / "agent"
    agent_dir.mkdir(parents=True, exist_ok=True)

    games_dir = home / "games"
    games_dir.mkdir(parents=True, exist_ok=True)

    # Create memory file
    memory_file = agent_dir / "memory.md"
    if not memory_file.exists():
        memory_file.write_text(
            "# Creator Memory\n\n"
            "This file stores what the EAISports agent learns about you and your preferences.\n"
            "It's updated automatically after each build session.\n\n"
            "## Preferences\n\n"
            "## Past Games\n\n"
            "## Patterns\n\n"
        )
        print(color(f"  ✓ Created {memory_file}", Colors.GREEN))
    else:
        print(color(f"  → Memory file exists: {memory_file}", Colors.DIM))

    # Create creator profile
    creator_file = home / "creator.md"
    if not creator_file.exists():
        wallet = config.get("wallet_address", "not connected")
        creator_file.write_text(
            f"# Creator Profile\n\n"
            f"Wallet: {wallet}\n\n"
            f"## About\n\n"
            f"## Style Preferences\n\n"
            f"## Favorite Skills\n\n"
        )
        print(color(f"  ✓ Created {creator_file}", Colors.GREEN))
    else:
        print(color(f"  → Creator profile exists: {creator_file}", Colors.DIM))

    # Note about skills
    print(color("  ✓ Default skills (interactive-fiction, trivia, puzzle-logic, game-ui) are bundled.", Colors.GREEN))

    # Set output dir
    config.setdefault("build", {})["output_dir"] = str(games_dir)
    print(color(f"  ✓ Game output directory: {games_dir}", Colors.GREEN))
