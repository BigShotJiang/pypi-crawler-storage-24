"""Tests for flowra.ext.mlflow — MLflow tracing via span-hooks."""

import dataclasses
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any
from unittest.mock import MagicMock, patch

from flowra.agent import AgentInfo, AgentSpan, ExecutionContext, ExecutionFrame, HookEmitter, HookSubscription, StepSpan
from flowra.agent.flow import fork_flowing_context, restore_flowing_context
from flowra.ext.mlflow import install_mlflow_tracing
from flowra.lib.observability import LLMCallSpan, ToolCallSpan
from flowra.llm import (
    AssistantMessage,
    LLMRequest,
    LLMResponse,
    StopReason,
    TextBlock,
    ToolResultBlock,
    ToolUseBlock,
    Usage,
)


def _make_agent_info(name: str = "test", path: str = "test") -> AgentInfo:
    return AgentInfo(name=name, path=path, source_type=None, parent=None)


def _make_context(agent_info: AgentInfo | None = None) -> ExecutionContext:
    agent = agent_info or _make_agent_info()
    frame = ExecutionFrame(agent=agent, spec=None, tag=None)
    return ExecutionContext(frame=frame, stack=(frame,))


@contextmanager
def _flowing() -> Iterator[None]:
    """Fork the flowing context (simulates what engine does around span operations)."""
    token = fork_flowing_context()
    try:
        yield
    finally:
        restore_flowing_context(token)


def _emitter(sub: HookSubscription, agent_info: AgentInfo | None = None) -> HookEmitter:
    ctx = _make_context(agent_info)
    return HookEmitter(sub.get_handlers(), ctx, span_handlers=sub.get_span_handlers())


def _mock_live_span(**kwargs: Any) -> MagicMock:
    span = MagicMock()
    span.trace_id = kwargs.get("trace_id", "trace-1")
    span.span_id = kwargs.get("span_id", "span-1")
    return span


class _MockContext:
    """Captures LiveSpan mocks created by side_effect for later assertions."""

    def __init__(self) -> None:
        self.spans: list[MagicMock] = []


def _install(hooks: HookSubscription, **kwargs: Any) -> tuple[MagicMock, _MockContext]:
    """Install tracing with mocked mlflow. Returns (mock_start_span, context).

    The patch stays active (not exited) so that handler closures see the mock.
    """
    ctx = _MockContext()
    _counter = [0]

    def _fake_start_span(**kw: Any) -> MagicMock:
        _counter[0] += 1
        parent = kw.get("parent_span")
        trace_id = parent.trace_id if parent else f"trace-{_counter[0]}"
        span = _mock_live_span(trace_id=trace_id, span_id=f"span-{_counter[0]}")
        ctx.spans.append(span)
        return span

    patcher = patch("flowra.ext.mlflow.mlflow")
    mock_mlflow = patcher.start()
    mock_mlflow.MlflowClient.return_value.get_experiment_by_name.return_value = MagicMock(experiment_id="exp-1")
    mock_mlflow.start_span_no_context.side_effect = _fake_start_span
    install_mlflow_tracing(hooks, **kwargs)
    return mock_mlflow.start_span_no_context, ctx


class TestInstallMlflowTracing:
    def test_registers_span_handlers(self) -> None:
        hooks = HookSubscription()
        _install(hooks)
        assert hooks.has_span_handlers(AgentSpan)
        assert not hooks.has_span_handlers(StepSpan)  # off by default
        assert hooks.has_span_handlers(LLMCallSpan)
        assert hooks.has_span_handlers(ToolCallSpan)

    def test_trace_steps_option(self) -> None:
        hooks = HookSubscription()
        _install(hooks, trace_steps=True)
        assert hooks.has_span_handlers(StepSpan)

    def test_disable_agents(self) -> None:
        hooks = HookSubscription()
        _install(hooks, trace_agents=False)
        assert not hooks.has_span_handlers(AgentSpan)


class TestAgentSpanTracing:
    async def test_root_agent_creates_span(self) -> None:
        hooks = HookSubscription()
        mock_start, _mctx = _install(hooks)

        agent_info = _make_agent_info(path="my_agent")
        emitter = _emitter(hooks, agent_info)

        span = AgentSpan(agent_info=agent_info, spec=None)

        with _flowing():
            await emitter.open_span(span)
            mock_start.assert_called_once()
            kw = mock_start.call_args[1]
            assert kw["name"] == "my_agent"
            assert kw["span_type"] == "AGENT"
            assert kw["parent_span"] is None  # root

            span.result = "done"
            await emitter.close_span(span)

    async def test_child_agent_has_parent(self) -> None:
        hooks = HookSubscription()
        mock_start, _mctx = _install(hooks)

        parent_info = _make_agent_info(path="parent")
        child_info = _make_agent_info(path="parent/child")

        parent_emitter = _emitter(hooks, parent_info)
        child_emitter = _emitter(hooks, child_info)

        parent_span = AgentSpan(agent_info=parent_info, spec=None)
        child_span = AgentSpan(agent_info=child_info, spec=None)

        with _flowing():
            await parent_emitter.open_span(parent_span)

            with _flowing():
                await child_emitter.open_span(child_span)

                # Second call should have parent_span set
                assert mock_start.call_count == 2
                child_kw = mock_start.call_args_list[1][1]
                assert child_kw["name"] == "parent/child"
                assert child_kw["parent_span"] is not None  # has a parent

                await child_emitter.close_span(child_span)

            await parent_emitter.close_span(parent_span)

    async def test_resume_span_includes_is_resume(self) -> None:
        hooks = HookSubscription()
        mock_start, _mctx = _install(hooks)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        span = AgentSpan(agent_info=agent_info, spec=None, is_resume=True)

        with _flowing():
            await emitter.open_span(span)
            kw = mock_start.call_args[1]
            assert kw["inputs"]["is_resume"] is True
            await emitter.close_span(span)


class TestSessionId:
    async def test_static_session_id(self) -> None:
        hooks = HookSubscription()
        mock_start, _mctx = _install(hooks, session_id="my-session-42")

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        with _flowing():
            await emitter.open_span(AgentSpan(agent_info=agent_info, spec=None))
            kw = mock_start.call_args[1]
            assert kw["metadata"] == {"mlflow.trace.session": "my-session-42"}

    async def test_callable_session_id(self) -> None:
        hooks = HookSubscription()
        current_session = ["session-A"]
        mock_start, _mctx = _install(hooks, session_id=lambda: current_session[0])

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        with _flowing():
            await emitter.open_span(AgentSpan(agent_info=agent_info, spec=None))
            kw = mock_start.call_args[1]
            assert kw["metadata"] == {"mlflow.trace.session": "session-A"}

    async def test_no_session_id(self) -> None:
        hooks = HookSubscription()
        mock_start, _mctx = _install(hooks)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        with _flowing():
            await emitter.open_span(AgentSpan(agent_info=agent_info, spec=None))
            kw = mock_start.call_args[1]
            assert kw["metadata"] is None

    async def test_session_id_only_on_root(self) -> None:
        hooks = HookSubscription()
        mock_start, _mctx = _install(hooks, session_id="sess-1")

        parent_info = _make_agent_info(path="parent")
        child_info = _make_agent_info(path="parent/child")
        parent_emitter = _emitter(hooks, parent_info)
        child_emitter = _emitter(hooks, child_info)

        with _flowing():
            await parent_emitter.open_span(AgentSpan(agent_info=parent_info, spec=None))

            with _flowing():
                await child_emitter.open_span(AgentSpan(agent_info=child_info, spec=None))

        # Root has metadata, child does not
        root_kw = mock_start.call_args_list[0][1]
        child_kw = mock_start.call_args_list[1][1]
        assert root_kw["metadata"] == {"mlflow.trace.session": "sess-1"}
        assert child_kw["metadata"] is None


class TestLLMCallSpanTracing:
    async def test_llm_span_created_under_agent(self) -> None:
        hooks = HookSubscription()
        mock_start, _mctx = _install(hooks)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        agent_span = AgentSpan(agent_info=agent_info, spec=None)

        with _flowing():
            await emitter.open_span(agent_span)

            request = LLMRequest(model="anthropic/claude-test", messages=[], tools=[])
            llm_span = LLMCallSpan(request=request)

            with _flowing():
                await emitter.open_span(llm_span)

                assert mock_start.call_count == 2
                kw = mock_start.call_args_list[1][1]
                assert "llm_call" in kw["name"]
                assert kw["span_type"] == "CHAT_MODEL"
                assert kw["attributes"]["mlflow.message.format"] == "openai"

                llm_span.response = LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="hello")]),
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5, cost_usd=0.001),
                )
                await emitter.close_span(llm_span)

            await emitter.close_span(agent_span)

    async def test_llm_span_without_parent_is_noop(self) -> None:
        hooks = HookSubscription()
        mock_start, _mctx = _install(hooks)

        # No flowing context → LLM handler returns None
        emitter = _emitter(hooks)
        request = LLMRequest(model="test/model", messages=[], tools=[])
        llm_span = LLMCallSpan(request=request)
        await emitter.open_span(llm_span)
        await emitter.close_span(llm_span)

        mock_start.assert_not_called()


class TestToolCallSpanTracing:
    async def test_tool_span_created_under_agent(self) -> None:
        hooks = HookSubscription()
        mock_start, _mctx = _install(hooks)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        agent_span = AgentSpan(agent_info=agent_info, spec=None)

        with _flowing():
            await emitter.open_span(agent_span)

            tool_use = ToolUseBlock(id="tu-1", name="calculate", input={"a": 1})
            tool_span = ToolCallSpan(tool_use=tool_use)

            with _flowing():
                await emitter.open_span(tool_span)

                kw = mock_start.call_args_list[1][1]
                assert kw["name"] == "tool:calculate"
                assert kw["span_type"] == "TOOL"

                tool_span.result = ToolResultBlock(tool_use_id="tu-1", content="2")
                await emitter.close_span(tool_span)

            await emitter.close_span(agent_span)


class TestStepSpanTracing:
    async def test_step_span_when_enabled(self) -> None:
        hooks = HookSubscription()
        mock_start, _mctx = _install(hooks, trace_steps=True)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        agent_span = AgentSpan(agent_info=agent_info, spec=None)

        with _flowing():
            await emitter.open_span(agent_span)

            step_span = StepSpan(agent_info=agent_info, step="process", spec=None)

            with _flowing():
                await emitter.open_span(step_span)

                kw = mock_start.call_args_list[1][1]
                assert kw["name"] == "process"
                assert kw["span_type"] == "CHAIN"

                step_span.result = "ok"
                await emitter.close_span(step_span)

            await emitter.close_span(agent_span)


class TestPreviewProtocol:
    async def test_preview_used_for_spec_and_result(self) -> None:
        """Objects with __preview__() get clean text instead of str()."""

        @dataclasses.dataclass(frozen=True)
        class MySpec:
            query: str

            def __preview__(self) -> str:
                return self.query

        @dataclasses.dataclass(frozen=True)
        class MyResult:
            answer: str

            def __preview__(self) -> str:
                return self.answer

        hooks = HookSubscription()
        mock_start, mctx = _install(hooks)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        span = AgentSpan(agent_info=agent_info, spec=MySpec(query="hello world"))
        with _flowing():
            await emitter.open_span(span)

            # inputs should use __preview__
            kw = mock_start.call_args[1]
            assert kw["inputs"]["spec"] == "hello world"

            span.result = MyResult(answer="42")
            await emitter.close_span(span)

        live_span = mctx.spans[0]
        outputs = live_span.set_outputs.call_args[0][0]
        assert outputs["result"] == "42"

    async def test_str_fallback_without_preview(self) -> None:
        """Objects without __preview__() fall back to str()."""
        hooks = HookSubscription()
        mock_start, _mctx = _install(hooks)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        span = AgentSpan(agent_info=agent_info, spec="plain string spec")
        with _flowing():
            await emitter.open_span(span)

            kw = mock_start.call_args[1]
            assert kw["inputs"]["spec"] == "plain string spec"
            await emitter.close_span(span)


class TestTracePreview:
    async def test_set_trace_preview_called_for_root(self) -> None:
        """Root agent span sets request_preview/response_preview on the trace."""
        hooks = HookSubscription()
        _mock_start, _mctx = _install(hooks)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        span = AgentSpan(agent_info=agent_info, spec="test query")
        with _flowing():
            await emitter.open_span(span)
            span.result = "test answer"
            await emitter.close_span(span)


class TestErrorHandling:
    async def test_error_passed_to_outputs(self) -> None:
        hooks = HookSubscription()
        _mock_start, mctx = _install(hooks)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        span = AgentSpan(agent_info=agent_info, spec=None)
        with _flowing():
            await emitter.open_span(span)
            await emitter.close_span(span, error=RuntimeError("boom"))

        live_span = mctx.spans[0]
        live_span.set_outputs.assert_called_once()
        outputs = live_span.set_outputs.call_args[0][0]
        assert "boom" in outputs["error"]
        live_span.end.assert_called_once()


class TestSiblingChildren:
    """Verify that Spawn sibling children get the same parent (not chained)."""

    async def test_siblings_have_same_parent(self) -> None:
        hooks = HookSubscription()
        mock_start, _mctx = _install(hooks)

        # Parent agent + step
        parent_info = _make_agent_info(path="root_agent")
        parent_emitter = _emitter(hooks, parent_info)

        parent_agent_span = AgentSpan(agent_info=parent_info, spec=None)

        # Now two sibling children — opened sequentially (simulating Spawn)
        child0_info = _make_agent_info(path="root_agent/tool_call")
        child1_info = _make_agent_info(path="root_agent/tool_call")

        child0_emitter = _emitter(hooks, child0_info)
        child1_emitter = _emitter(hooks, child1_info)

        with _flowing():
            await parent_emitter.open_span(parent_agent_span)

            # Each child in its own nested _flowing() — simulating engine fork/restore per child
            with _flowing():
                await child0_emitter.open_span(AgentSpan(agent_info=child0_info, spec=None))

            with _flowing():
                await child1_emitter.open_span(AgentSpan(agent_info=child1_info, spec=None))

        # Both should have the SAME parent — the root agent span
        assert mock_start.call_count == 3
        root_mlflow_span = _mctx.spans[0]
        child0_kw = mock_start.call_args_list[1][1]
        child1_kw = mock_start.call_args_list[2][1]

        assert child0_kw["parent_span"] is root_mlflow_span
        assert child1_kw["parent_span"] is root_mlflow_span
