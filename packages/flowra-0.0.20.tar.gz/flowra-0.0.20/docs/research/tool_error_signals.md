# Tool Error Signals & Escalation — Research (March 2026)

Research date: 2026-03-23

## Problem

When an LLM generates a tool call that fails (unknown tool, schema validation
error, execution error), all three cases were previously reported identically:
`ToolResultBlock(is_error=True, content="Error: ...")`. There was no way to
distinguish failure types in hooks or parent agents.

This matters for production scenarios where a cheap/fast model handles most
cases but occasionally fails. The system needs to detect failure patterns and
react — switch to a stronger model for one call, or escalate to a parent agent
that re-routes the entire conversation to a smarter mode.

## Scenario

```
Router Agent
  │
  ├─ receives user message
  ├─ classifies → "create invoice" mode
  └─ GotoAgent(InvoiceAgent, model="fast")
       │
       └─ Tool Loop (cheap model)
            ├─ LLM call → tool:ask_customer(question="...")
            ├─ Schema validation fails (wrong params)
            │   → signal: schema_validation_error
            ├─ LLM retry → tool:ask_customer(question="...")
            ├─ Schema validation fails again
            │   → signal: schema_validation_error (2nd)
            │   → observer: threshold reached → interrupt!
            └─ Interrupted
       │
       ├─ Parent sees: interrupted + reason = "model_too_weak"
       └─ GotoAgent(InvoiceAgent, model="strong")
```

## What was implemented

### ToolErrorKind enum (flowra.tools)

`ToolErrorKind` is a `StrEnum` in `flowra/tools/types.py`:

```python
class ToolErrorKind(enum.StrEnum):
    UNKNOWN_TOOL = "unknown_tool"
    SCHEMA_VALIDATION = "schema_validation"
    EXECUTION = "execution"
```

### error_kind on ToolResult (tools layer)

`ToolResult` has `error_kind: ToolErrorKind | None = None`. Set automatically
in all error paths:

| `ToolErrorKind` | Where set |
|---|---|
| `UNKNOWN_TOOL` | `ToolRegistry.execute()` (unknown tool), `McpConnection.call_tool()` (unknown/removed tool), `ToolCallAgent` (denied by filter) |
| `SCHEMA_VALIDATION` | `ToolRegistry.execute()` (catches `jsonschema.ValidationError`) |
| `EXECUTION` | `ToolRegistry.execute()` (handler exception), `McpConnection` (JSON-RPC error, transport failure) |

`ToolResultBlock` (LLM layer) intentionally has no `error_kind` — the LLM
doesn't need it. Classification stays on the tools and observability layers.

### error_kind on ToolCallSpan and AfterToolCallEvent

`error_kind` is available to consumers through two paths:

- **`ToolCallSpan.error_kind`** — for span-hooks (MLflow, OTel). Set by
  `ToolCallAgent` before closing the span. OTel records it as
  `flowra.tool.error_kind`, MLflow adds it to span outputs.
- **`AfterToolCallEvent.error_kind`** — for regular hooks. Flows through
  `ToolCallResult.error_kind` from `ToolCallAgent` to `ToolLoopAgent`.

### Observability move

Spans (`LLMCallSpan`, `ToolCallSpan`) and streaming events (`TextDeltaEvent`,
`ThinkingDeltaEvent`) moved from `flowra.llm.observability` to
`flowra.lib.observability`. They bridge LLM and tools layers, so they belong
in `lib`.

### InterruptControl

New service injected into agents via DI. Allows interrupting execution
from within the hierarchy:

```python
class InterruptControl:
    def interrupt(self) -> None:
        """Interrupt this agent and all its children."""

    def interrupt_children(self) -> None:
        """Interrupt only spawned children, not this agent."""
```

Naming convention: `InterruptToken` (observe), `InterruptTokenSource` (own),
`InterruptControl` (act).

### Interrupted binding in steps

Engine no longer filters `Interrupted` from child results before binding.
Steps that declare `Interrupted` in their union type receive it directly:

```python
@step
async def check_result(
    self,
    result: Annotated[ChatResult | Interrupted, step_arg.CHILD("chat")],
) -> ChatResult | Spawn:
    if isinstance(result, Interrupted):
        # handle escalation
```

If the step doesn't declare `Interrupted` in the type (e.g. `WorkResult | None`),
the binding falls through to nullable → `None` (backward compatible).
If the type is non-nullable and doesn't include `Interrupted`, auto-propagation
kicks in as before.

## Recipe: model fallback on schema validation error

All primitives exist. A user can build model fallback with ~20 lines:

```python
class ModelFallbackOnError:
    def __init__(self, fallback_model: str):
        self._fallback_model = fallback_model
        self._use_fallback = False

    def install(self, hooks: HookSubscription):
        hooks.on(AfterToolCallEvent, self._on_after)
        hooks.on(PrepareLLMRequestEvent, self._on_prepare)

    def _on_after(self, event: Event[AfterToolCallEvent]):
        if event.data.error_kind == ToolErrorKind.SCHEMA_VALIDATION:
            self._use_fallback = True

    def _on_prepare(self, event: Event[PrepareLLMRequestEvent]):
        if self._use_fallback:
            event.data.request = dataclasses.replace(
                event.data.request, model=self._fallback_model
            )
            self._use_fallback = False
```

## Recipe: escalation via InterruptControl

For scenarios where a tool detects it needs a smarter model. See
`examples/escalation.py` for the full working example.

Key components:

1. **TierService** — shared service with current tier and `InterruptControl`.
   Tools call `request_escalation()` to signal the need for a smarter model.
2. **EscalationAgent** — parent agent that spawns ChatAgent with fast model.
   Catches `Interrupted` from child, switches to smart model, respawns.
3. **AfterToolCallEvent hook** — logs `error_kind` signals for observability.

```python
class TierService:
    def __init__(self, tier, interrupt_control, reason_slot):
        ...

    def request_escalation(self, reason: str) -> None:
        self.__reason_slot.set(reason)
        self.__interrupt_control.interrupt_children()
```

The tool just sends a signal — it doesn't know or care what happens next:

```python
@tool("analyze_document", "...")
def analyze_document(params: AnalyzeInput, tier_service: TierService) -> str:
    if params.depth != "basic" and tier_service.tier == "fast":
        tier_service.request_escalation("requires smart model")
        raise ValueError("requires smart model")
    return f"Analysis result..."
```

## All primitives

| Primitive | Notes |
|---|---|
| `ToolErrorKind` | `StrEnum` in `flowra.tools` |
| `ToolResult.error_kind` | Set on all error paths in `ToolRegistry` and `McpConnection` |
| `ToolCallSpan.error_kind` | For span-hooks (MLflow, OTel) |
| `AfterToolCallEvent.error_kind` | For regular hooks |
| `InterruptControl` | Injected via DI — `interrupt()` and `interrupt_children()` |
| `Interrupted` binding in steps | Steps with `| Interrupted` in union type receive it directly |
| `PrepareLLMRequestEvent` | Can replace `request.model` |
| `InterruptToken` per child | Per-node tokens via `Spawn` |
| DI services shared parent↔child | Via `ServiceLocator` |
| `FlowingContextVar` | For per-node signal state |
