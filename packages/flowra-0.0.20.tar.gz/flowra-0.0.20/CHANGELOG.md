# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com),
and this project adheres to [Semantic Versioning](https://semver.org).

## [0.0.20] - 2026-03-23

### Added
- **`ToolErrorKind`** (`flowra.tools`). `StrEnum` classifying tool call failures:
  `UNKNOWN_TOOL`, `SCHEMA_VALIDATION`, `EXECUTION`. Available on `ToolResult.error_kind`,
  `AfterToolCallEvent.error_kind`, and `ToolCallSpan.error_kind`.
- **`InterruptControl`** (`flowra.agent`). New DI service with `interrupt()` (self + children)
  and `interrupt_children()` (children only). Enables in-hierarchy interruption patterns
  like model escalation.
- **`Interrupted` binding in steps**. Steps declaring `| Interrupted` in their union type
  now receive interrupted child results directly instead of auto-propagation.
- **Escalation example** (`examples/escalation.py`). Demonstrates fast model → interrupt →
  smart model pattern using `InterruptControl`, `TierService`, and `AfterToolCallEvent`.
  Run with `make escalation`.

### Changed
- **Observability types moved** from `flowra.llm` to `flowra.lib.observability`:
  `LLMCallSpan`, `ToolCallSpan`, `TextDeltaEvent`, `ThinkingDeltaEvent`.
  Import: `from flowra.lib.observability import LLMCallSpan, ToolCallSpan`.
- **MLflow/OTel** now record `error_kind` on tool spans — MLflow in outputs,
  OTel as `flowra.tool.error_kind` attribute.

## [0.0.19] - 2026-03-22

### Added
- **OpenTelemetry tracing** (`flowra.ext.otel`). Span-hook integration using GenAI
  semantic conventions (`gen_ai.operation.name`, `gen_ai.provider.name`,
  `gen_ai.usage.*`, etc.). Works with any OTel backend — Jaeger, Grafana Tempo,
  Datadog, etc. Optional dependency: `flowra[otel]`.
- **Tracing guide** (`docs/ext/tracing-guide.md`). Describes four setup options:
  MLflow only, OTel only, both independently, MLflow with OTel export — with
  trade-offs and configuration for each.

## [0.0.18] - 2026-03-22

### Added
- **`FlowingContextVar`** (`flowra.agent.flow.flowing`). Typed variables that flow
  with agent execution — the engine manages lifecycle (fork/restore for sibling
  isolation, snapshot/apply for asyncio task inheritance). Any integration can
  create flowing vars to store contextual data that propagates correctly through
  the execution tree.

### Changed
- **MLflow handler rewritten** to use `FlowingContextVar` for parent span tracking.
  Fixes sibling span chaining bug in Spawn (children now correctly appear as parallel
  siblings, not a nested chain). Removes internal `InMemoryTraceManager` dependency,
  uses public `mlflow.update_current_trace()` for trace previews.
  Adds `set_span_in_context()`/`detach_span_from_context()` for W3C `traceparent`
  propagation — external services can now attach their traces as children.

## [0.0.17] - 2026-03-22

### Added
- **`AnthropicToolSearch`** (`flowra.lib.anthropic`). Deferred tool loading for
  large tool sets — marks tools with `defer_loading: true`, adds server-side
  search tool (BM25 or regex). Reduces token usage by ~85% with 50+ tools.

### Changed
- **Moved Anthropic extensions** from `flowra.ext.anthropic` to `flowra.lib.anthropic` —
  split into `cache.py`, `tool_search.py`, `presets.py`. Not an ext (no extra deps).

## [0.0.16] - 2026-03-21

### Added
- **`transient: bool` field on `LLMData`.** All blocks, messages, and `Tool` inherit this
  general-purpose hint that marks content as non-permanent. Used by caching extensions to
  skip transient content when placing cache breakpoints.
- **`PrepareLLMRequestEvent` hook.** Emitted after `LLMRequest` is built but before the LLM
  call. Allows hooks to modify the request (e.g. for prompt caching, tool deferral).
- **Composable Anthropic caching extensions** (`flowra.lib.anthropic`). Hook bundles that set
  `cache_control` via `PrepareLLMRequestEvent`: `AnthropicCacheAllSystemMessages`,
  `AnthropicCacheNonTransientSystemMessages`, `AnthropicCacheAllTools`,
  `AnthropicCacheAllMessages`, `AnthropicCacheNonTransientMessages`,
  `AnthropicCacheHistoryMessages`, and composite presets `ANTHROPIC_CACHE_ALL`
  and `ANTHROPIC_CACHE_SESSION`.
- **`Tool` inherits from `LLMData`.** Tool definitions now have `metadata`, `extra`, and
  `transient` fields.
- **Providers pass through `extra` during serialization.** `AnthropicVertexProvider` merges
  `block.extra` into output dicts (`**block.extra`), enabling direct use of provider-specific
  fields like `cache_control`.

### Removed
- **`cache: bool` field** from all blocks (`TextBlock`, `ImageBlock`, `ToolUseBlock`,
  `ToolResultBlock`, `ThinkingBlock`) and `Tool`. Use `extra={"cache_control": ...}` or
  the `flowra.lib.anthropic` hook bundles instead.
- **`CacheConfig` / cache strategy system.** Removed `CacheConfig`, `CACHE_ALL`,
  `CACHE_SESSION`, `CACHE_MANUAL`, `NO_CACHE`, and all individual strategy functions.
  Replaced by composable hook bundles in `flowra.lib.anthropic`.

### Changed
- **Separated system messages in `LLMRequest`.** `LLMRequest` now has `system: list[SystemMessage]`
  and `messages: list[UserMessage | AssistantMessage]` instead of a single mixed `messages: list[Message]`.
  Providers no longer extract system messages at runtime — the split is enforced by types.
- **Renamed config fields.** `ToolLoopConfig`: `system` + `history` (was `session_messages`).
  `ChatConfig`: `system` (was `system_messages`). `LLMCallSpec`: `system` + `messages`.
- **Renamed `SaveTurnMessagesEvent`** → `SaveHistoryEvent`.
- **MLflow integration** — replaced `Any` types with proper `LLMRequest`, `Message`, `AssistantMessage`;
  rewrote message conversion with exhaustive `match/case`.

## [0.0.15] - 2026-03-19

### Added
- **Multi-agent patterns cookbook** (`docs/patterns.md`). Recipes with minimal code
  examples: router, pipeline, fan-out/fan-in, race (first wins), feedback loop,
  partial results (WhenN), timeout composition.
- **`LLMResponse.extra` for provider-specific data.** All providers now populate
  `extra` with `provider_stop_reason` (raw stop reason string) and `id` (response ID
  where available). Use for debugging and logging.

### Changed
- **Unified `TextDeltaEvent` / `ThinkingDeltaEvent`.** Both agents (`ToolLoopAgent`,
  `LLMCallAgent`) now share a single definition from `flowra.llm`. Removed the
  `context: ToolLoopAgentContext` field — use `event.context` (ExecutionContext) instead.
  Import: `from flowra.llm import TextDeltaEvent, ThinkingDeltaEvent`.

## [0.0.14] - 2026-03-19

### Added
- **MLflow tracing integration** (`flowra/ext/mlflow.py`). `install_mlflow_tracing(hooks)`
  subscribes to span-hooks (`AgentSpan`, `StepSpan`, `LLMCallSpan`, `ToolCallSpan`) and
  maps them to MLflow traces with structured chat UI (OpenAI-format messages, tools, usage).
  Session tracking via `session_id` parameter for multi-turn chat grouping.
  Optional dependency: `flowra[mlflow]`.
- **`__preview__()` protocol for readable trace summaries.** Objects implementing
  `__preview__() -> str` get clean text in MLflow's list/session view instead of
  `str()`. `ChatSpec`, `ChatResult`, `ToolLoopSpec`, `ToolLoopResult` implement it
  out of the box.

## [0.0.13] - 2026-03-19

### Added
- **Span-hooks: observability primitive with guaranteed enter/exit.** New mechanism
  alongside existing hooks, specifically for observability. Register via
  `hooks.on_span(SpanType, handler)`. Handler receives the mutable span object on
  enter, returns exit callback `(error=None)`. Later subscribers are "more outer".
  Exception-safe — exit handlers always run. `open_span()`/`close_span()` for
  long-lived spans, `async with emitter.span()` for simple cases.
- **Engine-level span types.** `AgentSpan` (agent lifecycle) and `StepSpan`
  (individual step invocations). Engine opens/closes spans at all lifecycle points:
  node creation, GotoStep, GotoAgent, Spawn, completion, interruption.
- **`LLMCallSpan`** and **`ToolCallSpan`** (`flowra.llm`) — shared span types for
  LLM calls and tool calls.

### Removed
- **`BeforeLLMCallEvent` / `AfterLLMCallEvent`** from both `tool_loop` and `llm_call`.
  Replaced by `LLMCallSpan` span-hook.

## [0.0.12] - 2026-03-18

### Added
- **`CostBreakdown` for detailed cost reporting.** New `CostBreakdown` dataclass with
  per-category cost fields: `input`, `output`, `cache_read`, `cache_creation`, and a
  `total` property. Added `cost: CostBreakdown | None` field to `Usage` alongside the
  existing `cost_usd`. All pricing modules now return `CostBreakdown`, and all providers
  populate both fields.
- **`tools/sync_pricing.py`** — script to sync pricing tables from litellm's
  `model_prices_and_context_window.json`. Dry-run by default, `--apply` to update files.

### Changed
- **Pricing modules return `CostBreakdown` instead of `float`.** `estimate_cost()` in
  `anthropic`, `openai`, and `google` pricing modules now returns `CostBreakdown | None`.
- **Updated pricing tables (March 2026).** Added GPT-5.4 mini/nano. Fixed OpenAI
  cache_read prices to match litellm data.

## [0.0.11] - 2026-03-17

### Added
- **`LLMProvider.aclose()` and async context manager.** All providers now support
  `async with provider:` for proper resource cleanup. Providers that create their
  own client close it automatically; pass `owns_client=True` to transfer ownership
  of an externally created client.

### Changed
- **Split `HookRegistry` into `HookSubscription` + `HookEmitter`.** `HookRegistry` is removed.
  Users create `HookSubscription` (register handlers via `on()`), pass it in services.
  Agents receive `HookEmitter` (emit events, check handlers) via DI. Runtime creates
  `HookEmitter` from subscription handlers + `ExecutionContext` automatically.
- **Unified `flowra.agent` package.** Merged `flowra.agent` and `flowra.runtime` into a
  single `flowra.agent` package. All public symbols (`AgentRuntime`, `InMemorySessionStorage`,
  `FileSessionStorage`, `InterruptTokenSource`, etc.) are now imported from `flowra.agent`.
  The `flowra.runtime` package is removed. New subpackage structure: `definition/`, `flow/`,
  `state/`, `storage/`, `runtime/`, `services.py`.
- **New public symbols.** `ExecutionContext`, `ExecutionFrame`, `AgentInfo`, `InterruptedError`,
  `with_interrupt` added to `flowra.agent` public API.
- **`FORK` storage key for explicit scope forking.** `CallStep` without `storage_key` now
  shares the parent's scope (same state). Use `storage_key=FORK` to get an isolated copy
  of the parent's state (previous default behavior). `NEW_SCOPE` and explicit string keys
  still create fresh scopes. `FORK` is also available for `GotoStep`.

### Fixed
- **Schema formatting shows type names in unions.** `format_schema_for_llm` now adds
  `// TypeName` comments after `{` for objects with a `title` field. This helps LLMs
  (especially Anthropic, which uses prompt-based structured output) correctly distinguish
  union variants like `Dog | Cat` instead of merging their fields.

## [0.0.10] - 2026-03-15

### Changed
- **`NoSpec`/`NoResult` replaced with `None`.** Use `Agent[None, MyResult]` instead of
  `Agent[NoSpec, MyResult]`, and `Agent[MySpec, None]` instead of `Agent[MySpec, NoResult]`.
  The sentinel classes are removed.
- **`ServiceLocator.provide()` infers type.** `sl.provide(LLMConfig(...))` now works —
  the type is inferred from `type(value)`. The two-argument form `sl.provide(LLMConfig, ...)`
  still works for providing by base type.

## [0.0.9] - 2026-03-15

### Changed
- **Agent spec injection via constructor.** Agent spec (`S` from `Agent[S, R]`) is now
  passed to the agent's `__init__` by type matching at compile time. Spec is NOT a service —
  it does not leak into child agents via `parent_services`.
  ```python
  class Researcher(Agent[ResearchSpec, ResearchResult]):
      def __init__(self, spec: ResearchSpec, sl: ServiceLocator) -> None:
          sl.provide(LLMConfig, LLMConfig(model=spec.model))
  ```
- **Removed `FromAgentSpec`.** Agent spec is no longer available as a step parameter binding
  source. Use the constructor to receive the spec and store it on `self` if needed in steps.
- **Binding markers → UPPER_CASE sentinels.** `FromSpec`, `FromChild`, `FromChildren`
  replaced with `step_arg.SPEC`, `step_arg.CHILD`. `FromChildren` removed — `list[T]` hint
  handles list mode automatically. `FromToolInput`, `FromToolService` replaced with
  `tool_arg.INPUT`, `tool_arg.SERVICE`. New `agent_arg.SPEC`, `agent_arg.SERVICE` for
  agent constructor binding.
- **Removed `HookContext` and `HookProvider`.** `HookContext` replaced entirely by
  `ExecutionContext`. `HookProvider` protocol removed — use `registry.on()` directly.
- `LLMCallResult` now includes `elapsed: float` — wall-clock seconds for the LLM call.

### Added
- `LLMCallAgent` — pre-built agent for single LLM calls. Messages in, response out,
  no tool loop, no session history. Auto-switches to streaming when `TextDeltaEvent`
  or `ThinkingDeltaEvent` handlers are registered. Own hook events independent from
  `ToolLoopAgent`.
- `ExecutionContext` — automatic execution metadata on every emitted event. Two navigable hierarchies:
  - **Execution stack** (`ExecutionContext.stack`): runtime call chain from root to emitting agent.
    Each `ExecutionFrame` carries `agent: AgentInfo`, `spec`, and `tag`.
  - **Registration hierarchy** (`AgentInfo.parent`): agent's position in the name tree.
    Each `AgentInfo` has `name`, `path`, `source_type`, and `parent`.
  - `HookRegistry.with_context()` creates a new registry sharing handlers but stamping
    a different context — the runtime uses this to give each execution node its own context.
- `ExecutionContext` stack navigation helpers: `find_spec(type)`, `get_spec(type)`,
  `find_frame(spec_type=, agent_type=)`, `get_frame(spec_type=, agent_type=)` — search the
  execution stack from current frame upward. `get_*` variants raise `LookupError` on miss.
- `Event.context` is now always `ExecutionContext` (no longer optional). `HookRegistry.emit()`
  raises `RuntimeError` if called without context — ensures events are only emitted within runtime.

## [0.0.8] - 2026-03-14

### Changed
- Renamed interrupt exception: `Interrupted` → `InterruptedError`. The old name `Interrupted`
  is now a frozen dataclass result type (used for interrupt propagation through the execution tree).
- Renamed internal module `flowra/agent/agent_def.py` → `flowra/agent/model.py`.
- **Per-node interrupt tokens.** Each execution node gets its own `InterruptToken` with
  parent→child cascade. `InterruptedError` is caught per-node and converted to `Interrupted()`
  result. `runtime.run()` returns `Interrupted()` instead of `None` on interrupt.
- **Interrupted auto-propagation.** `Interrupted` results flow up the execution tree.
  Parent join-steps receive `None` for interrupted children's nullable parameters;
  if binding fails due to missing results, the parent auto-propagates `Interrupted()`.

### Added
- `Interrupted` frozen dataclass — typed result for interrupted agents (`reason: str | None`).
- **Composable spawn strategies**: `WhenAll`, `WhenAny`, `WhenN` combinators for `Spawn`.
  `Spawn` now accepts positional `SpawnNode` args (alongside the existing `children=` keyword).
  Combinators are nestable: `Spawn(WhenAny(WhenAll(a, b), c), then="join")`.
- `timeout(seconds=, minutes=)` helper — shortcut for a timeout child agent.
  Returns `TimeoutExpired(seconds=...)` on expiry, `Interrupted()` if cancelled.
- `TimeoutExpired` frozen dataclass — result type for the built-in timeout agent.

## [0.0.7] - 2026-03-13

### Changed
- Slots are now created in the agent constructor via `store.slot(Scalar[int], "key")`
  instead of declarative `slot("key")` class attributes. `AgentStore` now provides the
  `slot()` method; the old `slot()` sentinel and `SlotMarker` are removed.
- **Annotated-based step parameter binding.** Step parameters now bind by matching type
  annotations against available values (step spec, child outputs). Optional
  `step_arg` markers (`step_arg.SPEC`, `step_arg.CHILD`, `step_arg.CHILD`) narrow binding
  to a specific source. Replaces the old `StepSpec`/`AgentResult` base class approach —
  user types no longer need to inherit from marker classes. All step parameter and return
  types (other than action types and `None`) must be dataclasses.
- `NoSpec` / `NoResult` are now standalone sentinels (not frozen dataclasses).
- `Agent[S, R]` generic parameters no longer require `StepSpec`/`AgentResult` bounds.

### Added
- `step_arg.SPEC`, `step_arg.CHILD`, `step_arg.CHILD` markers for `Annotated`-based step parameter binding.
- `ChildOutput` bridge type for passing child results with tags between runtime and agent.
- `tag` field on `CallStep` and `CallAgent` — labels a child so the join step can bind
  its result by tag via `step_arg.CHILD("tag")`.
- `allowed_tools` / `denied_tools` now support wildcard patterns via `fnmatch`
  (e.g. `{"mcp_*"}`, `{"debug_?"}`).
- **Exception-based interrupts** (.NET `CancellationToken` pattern):
  `InterruptToken.check()` raises `Interrupted` (like `ThrowIfCancellationRequested`),
  `with_interrupt()` raises `Interrupted` instead of silently ending the loop.
  Uncaught `Interrupted` from any step is caught by the engine — the entire execution
  tree completes immediately and `runtime.run()` returns `None`. Agents and tools can
  catch `Interrupted` explicitly for graceful partial results; `ToolCallAgent` catches
  it from tool execution and returns an error `ToolResultBlock`.

## [0.0.6] - 2026-03-12

### Changed
- Renamed `ToolLoopConfig.max_iterations` → `max_llm_calls` (and `ToolLoopStatus.MAX_ITERATIONS`
  → `MAX_LLM_CALLS`) to avoid confusion with the new runtime-level `max_iterations`.
- Unified sentinel values: `Scalar` and `AgentRuntime` now use shared `Unset`/`UNSET`
  from `flowra._sentinel` instead of per-module private sentinels.

### Added
- **Agents as tools**: `@agent_tool` decorator exposes an agent class as a tool that
  the LLM can call autonomously. `get_agent_tool()` extracts the tool for registry,
  `make_agent_tool()` builds one programmatically. The LLM sees a regular tool; behind
  the scenes, the sub-agent is spawned with its own system prompt and tool loop.
- **Runtime limits**: `AgentRuntime` now supports `max_iterations` (engine advance steps)
  and `timeout` (seconds). Both can be set as defaults in the constructor and overridden
  per `run()`/`resume()` call.
- `format_schema_for_llm` now handles array-style `type` (e.g. `["string", "null"]`).

## [0.0.5] - 2026-03-11

### Changed
- **Agents as black boxes**: agents now have a single entry point (`@step(entry=True)`),
  a typed spec (`S`), and a typed result (`R`) via `Agent[S, R]`. You run an agent —
  not a step of an agent. Steps are internal implementation details.
- **Explicit control flow separation**: split `Goto`/`Call` into `GotoStep`/`GotoAgent`
  and `CallStep`/`CallAgent` — internal step navigation vs external agent invocation.
- **Compile-time validation**: compiler extracts spec/result types from `Agent[S, R]`,
  validates entry step spec matches generic `S`, enforces single entry per agent,
  resolves `TypeAlias` unions.
- `NoSpec` / `NoResult` sentinels for agents that don't need spec or result types.
- `runtime.run()` no longer accepts `step=` parameter — entry point is determined
  by the agent itself.

### Fixed
- `cache_last_session_message` now correctly clears cache hints from turn messages.

## [0.0.4] - 2026-03-09

### Fixed
- **JSON schema response cleanup**: `AnthropicVertexProvider` now returns a single `TextBlock`
  with clean JSON when `json_schema` is set — markdown fences and thinking blocks are stripped.
  Previously, validated JSON was cleaned internally but the original (fenced) text was returned.
- `validate_json_schema` now returns `(error, cleaned_text)` tuple so callers get the
  fence-stripped text.

## [0.0.3] - 2026-03-08

### Changed
- **Hook system redesign**: replaced `ToolLoopHooks`/`ChatHooks` (24 Protocol classes, 12 executor
  functions, 5 result dataclasses) with generic `HookRegistry` + `Event[T]` pattern. Supports
  multiple handlers per event, `HookProvider` for distributable hook sets, and `propagate_to()`
  for parent/child isolation. Hook events are plain mutable dataclasses with result fields.
- `ToolLoopSpec.meta` / `ChatSpec.meta` renamed to `metadata`.

## [0.0.2] - 2026-03-08

### Added
- **Streaming**: `LLMProvider.stream()` method returns `AsyncIterator[StreamEvent]` with `TextDelta`, `ThinkingDelta`, and `ContentComplete` events. All three built-in providers implement real-time streaming. Default fallback calls `call()` and yields `ContentComplete`.
- **Anthropic thinking**: `AnthropicVertexAdditionalConfig` with `thinking_budget_tokens` enables extended thinking on Claude models. Thinking blocks are now parsed from Anthropic responses (`ThinkingBlock`).
- **Streaming hooks**: `on_text_delta` and `on_thinking_delta` hooks in `ToolLoopHooks`. When set, the agent automatically uses `stream()` instead of `call()`. Streaming respects `InterruptToken` — exits immediately even if the LLM is blocked.
- **`with_interrupt`**: Generic async iterator wrapper that races `__anext__()` against `InterruptToken.wait()` via `asyncio.wait(FIRST_COMPLETED)`. Used internally by `ToolLoopAgent` for streaming; available as `from flowra.agent import with_interrupt`.
- **Thinking model entry**: `anthropic/sonnet-4-5-think` in example model registry with 4000 token thinking budget.
- **Console/TUI streaming**: `--stream` flag for `console_chat.py` and `tui_chat.py` examples.

## [0.0.1] - 2026-03-07

Initial release.

### Added
- State machine agents with `@step` methods, `Goto`, `Spawn`, and stored values (`Scalar`, `AppendOnlyList`)
- Provider-agnostic LLM abstraction (`LLMProvider`, `LLMRequest`, `LLMResponse`)
- LLM providers: `AnthropicVertexProvider`, `GoogleVertexProvider`, `OpenAIProvider`
- Tool integration: `@tool` decorator, MCP server support, DI into tool handlers
- Execution engine with persistence, crash recovery, and cooperative interrupts
- Pre-built agents: `ChatAgent` (multi-turn chat) and `ToolLoopAgent` (tool loop with hooks)
- `ChatHooks` with `on_save_turn_messages` for transient message filtering
- Optional provider dependencies via extras: `flowra[anthropic]`, `flowra[openai]`, `flowra[google]`, `flowra[all]`
- Python 3.12, 3.13, 3.14 support
