"""Span-hooks demo — prints a tree of spans to the console.

Usage:
    uv run python examples/span_demo.py
"""

import asyncio
import pathlib
from typing import Any

from examples.app_agent import AppAgent, AppConfig
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate
from flowra.agent import AgentRuntime, AgentSpan, HookSubscription, InMemorySessionStorage, StepSpan
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.lib.observability import LLMCallSpan, ToolCallSpan
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry, get_local_tool

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()

_INDENT = [0]


def _log(prefix: str, name: str, detail: str = "") -> None:
    indent = "  " * _INDENT[0]
    suffix = f"  {detail}" if detail else ""
    print(f"{indent}{prefix} {name}{suffix}")


def _on_agent_span(span: AgentSpan) -> Any:
    _log("▶", f"agent:{span.agent_info.path}", f"spec={_short(span.spec)}")
    _INDENT[0] += 1

    def on_end(error: BaseException | None = None) -> None:
        _INDENT[0] -= 1
        if error:
            _log("✘", f"agent:{span.agent_info.path}", f"error={error}")
        else:
            _log("◀", f"agent:{span.agent_info.path}", f"result={_short(span.result)}")

    return on_end


def _on_step_span(span: StepSpan) -> Any:
    _log("→", f"step:{span.step}", f"spec={_short(span.spec)}")
    _INDENT[0] += 1

    def on_end(error: BaseException | None = None) -> None:
        _INDENT[0] -= 1
        _log("←", f"step:{span.step}", f"result={_short(span.result)}")

    return on_end


def _on_llm_span(span: LLMCallSpan) -> Any:
    model = span.request.model.split("/")[-1]
    _log("🤖", f"llm_call ({model})")

    def on_end(error: BaseException | None = None) -> None:
        if span.response:
            usage = span.response.usage
            tokens = f"{usage.input_tokens}in/{usage.output_tokens}out" if usage else "?"
            cost = f"${usage.cost_usd:.4f}" if usage and usage.cost_usd else ""
            _log("  ", f"→ {span.response.stop_reason}  {tokens}  {cost}")

    return on_end


def _on_tool_span(span: ToolCallSpan) -> Any:
    _log("🔧", f"tool:{span.tool_use.name}", f"input={_short(span.tool_use.input)}")

    def on_end(error: BaseException | None = None) -> None:
        if span.result:
            prefix = "error" if span.result.is_error else "result"
            _log("  ", f"→ {prefix}: {span.result.content[:80]}")

    return on_end


def _short(obj: Any, max_len: int = 60) -> str:
    s = str(obj)
    return s[:max_len] + "..." if len(s) > max_len else s


async def main() -> None:
    router = create_router()

    async with await ToolRegistry.create([get_local_tool(calculate)]) as registry:
        app_config = AppConfig(
            default_model=DEFAULT_MODEL,
            system=lambda: [
                SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)]),
            ],
        )

        hooks = HookSubscription()
        hooks.on_span(AgentSpan, _on_agent_span)
        hooks.on_span(StepSpan, _on_step_span)
        hooks.on_span(LLMCallSpan, _on_llm_span)
        hooks.on_span(ToolCallSpan, _on_tool_span)

        runtime = AgentRuntime(
            agents={"app": AppAgent},
            storage=InMemorySessionStorage(),
            services={
                ToolRegistry: registry,
                AppConfig: app_config,
                HookSubscription: hooks,
                LLMProvider: router,
            },
        )

        print("Question: What is 2+2? Use the calculator tool.\n")
        result = await runtime.run(
            agent=AppAgent,
            spec=ChatSpec(user_message="What is 2+2? Use the calculator tool."),
        )

        if isinstance(result, ChatResult):
            print(f"\n{'=' * 60}")
            print(f"Answer: {result.response}")
            if result.usage:
                print(f"Total: {result.usage.input_tokens}in/{result.usage.output_tokens}out", end="")
                if result.usage.cost_usd:
                    print(f"  ${result.usage.cost_usd:.4f}", end="")
                print()


if __name__ == "__main__":
    asyncio.run(main())
