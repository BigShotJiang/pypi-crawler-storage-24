"""Issue #8 regression test for heavy dependency call-site audit."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def test_issue8_dependency_audit_gate_passes() -> None:
    """Audit script should pass on current declaration/import boundary."""
    repo_root = Path(__file__).resolve().parents[1]
    proc = subprocess.run(
        [sys.executable, "tools/dependency_audit.py", "--check"],
        cwd=repo_root,
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, f"stdout:\n{proc.stdout}\n\nstderr:\n{proc.stderr}"
