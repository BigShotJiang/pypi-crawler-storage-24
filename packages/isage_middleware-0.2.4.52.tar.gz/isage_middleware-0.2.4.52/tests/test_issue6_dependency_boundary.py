"""Issue #6 regression tests for dependency boundary split."""

from __future__ import annotations

import importlib
import tomllib
from pathlib import Path


def _load_pyproject() -> dict:
    pyproject_path = Path(__file__).resolve().parents[1] / "pyproject.toml"
    with pyproject_path.open("rb") as f:
        return tomllib.load(f)


def test_heavy_dependencies_not_in_default_dependency_set() -> None:
    """Core dependency set must not include heavy capability stacks."""
    data = _load_pyproject()
    dependencies = set(data["project"]["dependencies"])

    forbidden_prefixes = {
        "transformers",
        "tokenizers",
        "huggingface-hub",
        "scipy",
        "bm25s",
        "rank-bm25",
        "PyStemmer",
        "isage-vdb",
        "faiss-cpu",
        "isage-neuromem",
        "isage-flow",
        "isage-tsdb",
    }

    for dep in dependencies:
        base = dep.split(">=")[0].split("<")[0].split("==")[0]
        assert base not in forbidden_prefixes


def test_capability_optional_groups_exist() -> None:
    """Capability groups must be explicitly declared in optional dependencies."""
    data = _load_pyproject()
    optional = data["project"]["optional-dependencies"]

    for group in [
        "capability-ml",
        "capability-vector",
        "capability-memory",
        "capability-stream",
        "capability-all",
    ]:
        assert group in optional
        assert len(optional[group]) > 0


def test_agentic_is_core_dependency() -> None:
    """Agentic runtime is required and must stay in core dependencies."""
    data = _load_pyproject()
    dependencies = data["project"]["dependencies"]

    assert any(dep.startswith("isage-agentic") for dep in dependencies)


def test_tools_root_no_longer_exports_heavy_symbols() -> None:
    """Heavy tools should not be exported from tools package root."""
    tools_module = importlib.import_module("sage.middleware.operators.tools")

    assert "ImageCaptioner" not in tools_module.__all__
    assert "text_detector" not in tools_module.__all__
