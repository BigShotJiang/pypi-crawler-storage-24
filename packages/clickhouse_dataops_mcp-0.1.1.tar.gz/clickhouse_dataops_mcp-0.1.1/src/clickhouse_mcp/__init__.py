"""ClickHouse MCP Server — DataOps-focused query advisor for ClickHouse."""

__version__ = "0.1.1"
