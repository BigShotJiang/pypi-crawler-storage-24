# Copyright (c) 2017-2026 Juancarlo Añez (apalala@gmail.com)
# SPDX-License-Identifier: BSD-4-Clause
from __future__ import annotations

import argparse

from .common import pathlist_from_patterns
from .parproc import parproc_visual


def parallel_test_run(parse, options):
    def pysearch(pattern):
        if pattern.endswith('.py'):
            return pattern
        else:
            if not pattern.endswith('/'):
                pattern += '/'
            if '**' not in pattern:
                pattern += '**/'
            return pattern + '*.py'

    try:
        patterns = [pysearch(p) for p in options._patterns]
        filepaths = pathlist_from_patterns(
            patterns,
            sizesort=options.sort,
            ignore=options.ignore,
        )

        kwargs = vars(options)
        kwargs.pop('patterns', None)
        kwargs.pop('sort', None)
        kwargs.pop('ignore', None)
        parallel = not kwargs.pop('serial', False)

        filepaths = sorted(filepaths, key=lambda p: -p.stat().st_size)
        return parproc_visual(parse, filepaths, parallel=parallel, **kwargs)

    except KeyboardInterrupt:
        if options.verbose:
            raise


def parse_args():
    argparser = argparse.ArgumentParser(
        prog=__package__,
        # description=DESCRIPTION,
        add_help=False,
    )

    argparser.add_argument(
        'patterns',
        nargs='+',
        metavar='PATTERNS',
        help='filename patterns',
    )
    argparser.add_argument(
        '--help',
        '-h',
        help='show this help message and exit',
        action='help',
    )
    argparser.add_argument(
        '--ignore',
        '-i',
        metavar='PATTERN',
        help='ignore these patterns',
        action='append',
    )
    argparser.add_argument(
        '--sort',
        '-s',
        help='sort files by size',
        action='store_true',
    )
    argparser.add_argument(
        '--serial',
        '-S',
        help='do not run in parallel',
        action='store_true',
    )
    argparser.add_argument(
        '--trace',
        '-t',
        help='produce verbose output for a parse',
        action='store_true',
    )
    argparser.add_argument(
        '--verbose',
        '-v',
        help='output exceptions as they happen',
        action='store_true',
    )
    argparser.add_argument(
        '--exitfirst',
        '-x',
        help='output exceptions as they happen',
        action='store_true',
    )
    return argparser.parse_args()


def generic_main(parse):
    return parallel_test_run(parse, parse_args())
