# Copyright (c) 2017-2026 Juancarlo Añez (apalala@gmail.com)
# SPDX-License-Identifier: BSD-4-Clause
from __future__ import annotations

from typing import Any

from .. import grammars as g
from ..util import join_lists, regexpp, unicode_display_len as ulen
from ..walkers import NodeWalker
from .railmath import (
    ETX,
    Rails,
    assert_one_length,
    lay_out,
    loop,
    stopnloop,
    weld,
)


def tracks(model: g.Model):
    walker = RailroadNodeWalker()
    return walker.walk(model)


def text(model: g.Model) -> str:
    return '\n'.join(line.rstrip() for line in tracks(model))


def draw(model: g.Model):
    for line in tracks(model):
        print(line.rstrip())


class RailroadNodeWalker(NodeWalker):
    def __init__(self):
        super().__init__()

    def walk(self, node: Any, *args, **kwargs) -> Any:
        return list(super().walk(node))

    def walk_default(self, node: g.Model) -> Rails:
        return [f' <{node!r}> ']

    def walk_box(self, b: g.Box) -> Rails:
        return self.walk(b.exp)

    def walk_grammar(self, grammar: g.Grammar) -> Rails:
        return join_lists(*(self.walk(r) for r in grammar.rules))

    def walk_rule(self, rule: g.Rule) -> Rails:
        decorators = ''
        if rule.decorators:
            decorators = ' '.join(f'@{d}' for d in rule.decorators) + ' '

        params = ''
        if rule.params:
            params = ','.join(p for p in rule.params)

        kwparams = ''
        if rule.kwparams:
            kwparams = ','.join(f'{k}={v}' for k, v in rule.kwparams.items())  # type: ignore

        if params and kwparams:
            params = f'{params}, {kwparams}'
        elif kwparams:
            params = kwparams

        if params:
            params = f'[{params}]'

        leftrec = ''
        if rule.is_leftrec:
            leftrec = '⟳'
        elif not rule.is_memoizable:
            leftrec = '⊬'

        base = ''
        if rule.base:
            base = f"≤({rule.base})"

        out = [f'{decorators}{leftrec}{rule.name}{base}{params} ●─']
        out = weld(out, self.walk(rule.exp))
        out = weld(out, ['─■'])
        out += [' ' * ulen(out[0])]
        return assert_one_length(out)

    def walk_optional(self, optional: g.Optional) -> Rails:
        out = weld(['→'], self.walk(optional.exp))
        return lay_out([out, ['→']])

    def walk_closure(self, closure: g.Closure) -> Rails:
        return loop(self.walk_box(closure))

    def walk_positive_closure(self, closure: g.Closure) -> Rails:
        return stopnloop(self.walk_box(closure))

    def walk_join(self, join: g.Join) -> Rails:
        sep = weld(self.walk(join.sep), [' ✂ ─'])
        out = weld(sep, self.walk(join.exp))
        return loop(out)

    def walk_positive_join(self, join: g.PositiveJoin) -> Rails:
        sep = weld(self.walk(join.sep), [' ✂ ─'])
        out = weld(sep, self.walk(join.exp))
        return stopnloop(out)

    def walk_choice(self, choice: g.Choice) -> Rails:
        return lay_out([self.walk(o) for o in choice.options])

    def walk_option(self, option: g.Option) -> Rails:
        return self.walk(option.exp)

    def walk_sequence(self, s: g.Sequence) -> Rails:
        return weld(*(self.walk(e) for e in s.sequence))

    def walk_call(self, call: g.Call) -> Rails:
        return [f"{call.name}"]

    def walk_pattern(self, pattern: g.Pattern) -> Rails:
        pat = regexpp(pattern.pattern).replace("r'", "").rstrip("'")
        return [f"/{pat}/─"]

    def walk_token(self, token: g.Token) -> Rails:
        return [f"{token.token!r}"]

    def walk_eof(self, _eof: g.EOF) -> Rails:
        return [f"⇥{ETX} "]

    def walk_lookahead(self, la: g.Lookahead) -> Rails:
        out = weld(['─ &['], self.walk(la.exp))
        out = weld(out, [']'])
        return out

    def walk_negative_lookahead(self, la: g.NegativeLookahead) -> Rails:
        out = weld(['─ !['], self.walk(la.exp))
        out = weld(out, [']'])
        return out

    def walk_void(self, _v: g.Void) -> Rails:
        return [" ∅ "]

    def walk_cut(self, _cut: g.Cut) -> Rails:
        return [" ✂ ─"]

    def walk_fail(self, _f: g.Fail) -> Rails:
        return [" ⚠ "]

    def walk_constant(self, constant: g.Constant) -> Rails:
        return [f'`{constant.literal}`']

    def walk_dot(self, _dot: g.Dot):
        return [" ∀ "]

    def walk_group(self, group: g.Group):
        return self.walk_box(group)

    def walk_alert(self, alert: g.Alert):
        return [f'{'^' * alert.level}`{alert.literal}`']

    def walk_skip_to(self, skipto: g.SkipTo):
        return weld([' ->('], self.walk(skipto.exp), [')'])

    def walk_rule_include(self, include: g.RuleInclude):
        return [f' >({include.rule.name}) ']

    def walk_based_rule(self, rule: g.BasedRule):
        out = [f'{rule.name} < {rule.baserule}●─']
        out = weld(out, self.walk(rule.rhs))
        if ETX not in out:
            out = weld(out, ['─■'])
        out += [' ' * ulen(out[0])]
        return assert_one_length(out)

    def walk_named(self, named: g.Named) -> Rails:
        return weld([f' `{named.name}`('], self.walk(named.exp), [')'])

    def walk_named_list(self, named: g.NamedList) -> Rails:
        return weld([f' `{named.name}`]+('], self.walk(named.exp), [')'])

    def walk_override(self, override: g.Override) -> Rails:
        return weld([' @('], self.walk(override.exp), [')'])

    def walk_override_list(self, override: g.OverrideList):
        return weld([' @+('], self.walk(override.exp), [')'])

    def walk_empty_closure(self, _v: g.EmptyClosure) -> Rails:
        return [' {∅}']
