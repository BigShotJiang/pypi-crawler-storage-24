License
-------

.. include:: LICENSE
