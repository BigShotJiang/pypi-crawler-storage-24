# Copyright (c) 2017-2026 Juancarlo Añez (apalala@gmail.com)
# SPDX-License-Identifier: BSD-4-Clause
from __future__ import annotations

import unittest

from tatsu.tool import compile
from tatsu.util import trim


class PrettyTests(unittest.TestCase):
    def test_pretty(self):
        grammar = r"""
            start = lisp ;
            lisp = sexp | list | symbol;
            sexp[SExp]: '(' cons:lisp '.' ~ cdr:lisp ')' ;
            list[List]: '(' @:{lisp}* ')' ;
            symbol[Symbol]: /[^\s().]+/ ;
        """

        pretty = trim(r"""
            start: lisp

            lisp: sexp | list | symbol

            sexp[SExp]: '(' cons=lisp '.' ~ cdr=lisp ')'

            list[List]: '(' ={lisp} ')'

            symbol[Symbol]: /[^\s().]+/

        """)

        pretty_lean = trim(r"""
            start: lisp

            lisp: sexp | list | symbol

            sexp: '(' lisp '.' ~ lisp ')'

            list: '(' {lisp} ')'

            symbol: /[^\s().]+/

        """)

        model = compile(grammar=grammar)

        self.assertEqual(pretty, model.pretty())

        self.assertEqual(pretty_lean, model.pretty_lean())

    def test_slashed_pattern(self):
        grammar = """
            start: ?"[a-z]+/[0-9]+" $

        """
        model = compile(grammar=grammar)
        ast = model.parse('abc/123')
        self.assertEqual('abc/123', ast)
        print(model.pretty())
        self.assertEqual(trim(grammar), model.pretty())
