import numbers
from dataclasses import dataclass

from ..._scisuit import (
	multivariate_cronbach, 
	multivariate_itemanal_squaredmultcorrel, 
	multivariate_itemanal_adjtotalcorrel)

from ...util import to_table
from ...settings import roundf




@dataclass
class cronbach_Result:
	_labels: list[str]
	omitted: list[float]
	alpha: float
	
	
	def __OmittedItems(self):
		s = "Omitted Items \n"

		data = []
		for i, lbl in enumerate(self._labels):
			data.append([lbl, self.omitted[i]])
		
		s += to_table(data)
		return s


	def __str__(self):
		s = "Cronbach's Alpha \n"
		s += str(roundf(self.alpha)) + "\n"
		s += "\n"
		s += self.__OmittedItems()

		return s
		


def cronbach(
		Items:list[list[numbers.Real]], 
		labels:list[str] = [], 
		standardize = False)->cronbach_Result:
	"""
	Computes Cronbach's Alpha  

	---
	Items: The data section - each sublist is considered as a column of a table  
	labels: The labels of the items  
	standardize: Should standardize items' data  
	"""
	dct = multivariate_cronbach(Items, standardize)

	ListLabels = ["Item " + str(i+1) for i in range(len(Items))] if len(labels) == 0 else labels
	assert len(ListLabels) == len(Items), "if provided labels length must be equal to number of items"
		
	return cronbach_Result(
		alpha=dct["alpha"], 
		omitted=dct["omitted"], 
		_labels = ListLabels)




def squaredmultcorrel(Items:list[list[numbers.Real]])->list[numbers.Real]:
	"""
	Computes Squared Multiple Correlations for all omitted items  

	Items: The data section - each sublist is considered as a column of a table  
	
	---
	returns a list of omitted items in the given order with the `Items` data
	"""
	return multivariate_itemanal_squaredmultcorrel(Items)



def adjtotalcorrel(Items:list[list[numbers.Real]])->list[numbers.Real]:
	"""
	Computes Item Adjusted Total Correlations for all omitted items  

	Items: The data section - each sublist is considered as a column of a table  
	
	---
	returns a list of omitted items in the given order with the `Items` data
	"""
	return multivariate_itemanal_adjtotalcorrel(Items)