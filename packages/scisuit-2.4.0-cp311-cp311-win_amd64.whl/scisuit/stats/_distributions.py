from numbers import Real
from typing import Iterable

import numpy as _np


from .._scisuit import (
    # Beta distribution
    c_stat_dbeta, c_stat_pbeta, c_stat_qbeta,
    
    # Binomial distribution
    c_stat_dbinom, c_stat_pbinom, c_stat_qbinom,
    
    # Negative binomial distribution
    c_stat_dnbinom, c_stat_pnbinom, c_stat_qnbinom,
    
    # Multinomial distribution
    c_stat_dmultinom,
    
    # Chi-squared distribution
    c_stat_dchisq, c_stat_pchisq, c_stat_qchisq,
    
    # Exponential distribution
    c_stat_dexp, c_stat_pexp, c_stat_qexp,
    
    # F-distribution
    c_stat_df, c_stat_pf, c_stat_qf,
    
    # Gamma distribution
    c_stat_dgamma, c_stat_pgamma, c_stat_qgamma,
    
    # Geometric distribution
    c_stat_dgeom, c_stat_pgeom, c_stat_qgeom,
    
    # Hypergeometric distribution
    c_stat_dhyper, c_stat_phyper, c_stat_qhyper,
    
    # Normal distribution
    c_stat_dnorm, c_stat_pnorm, c_stat_qnorm,
    
    # Log-normal distribution
    c_stat_dlnorm, c_stat_plnorm, c_stat_qlnorm,
    
    # Pareto distribution
    c_stat_dpareto, c_stat_ppareto, c_stat_qpareto,
    
    # Poisson distribution
    c_stat_dpois, c_stat_ppois, c_stat_qpois,
    
    # Smirnov distribution
    c_stat_psmirnov,
    
    # Student's t-distribution
    c_stat_dt, c_stat_pt, c_stat_qt,
    
    # Uniform distribution
    c_stat_dunif, c_stat_punif, c_stat_qunif,
    
    # Weibull distribution
    c_stat_dweibull, c_stat_pweibull, c_stat_qweibull,
    
    # Wilcoxon signed-rank distribution
    c_stat_dsignrank, c_stat_psignrank, c_stat_qsignrank,
)




# ----- Standard Beta Distribution  -------

def dbeta(x:Iterable|Real, shape1:Real, shape2:Real)->list|Real:
	"""
	shape1, shape2: similar to alpha and beta
	"""
	assert shape1>0, "shape1>0 expected"
	assert shape2>0, "shape2>0 expected"
	return c_stat_dbeta(x, shape1, shape2)


def pbeta(q:Iterable|Real, shape1:Real, shape2:Real)->list|Real:
	"""
	shape1, shape2: similar to alpha and beta
	"""
	assert shape1>0, "shape1>0 expected"
	assert shape2>0, "shape2>0 expected"

	return c_stat_pbeta(q, shape1, shape2)


def qbeta(p:Iterable|Real, shape1:Real, shape2:Real)->list|Real:
	"""
	shape1, shape2: similar to alpha and beta
	"""
	assert shape1>0, "shape1>0 expected"
	assert shape2>0, "shape2>0 expected"

	return c_stat_qbeta(p, shape1, shape2)
	

def rbeta(n:int, shape1:Real, shape2:Real)->list:
	"""
	shape1, shape2: similar to alpha and beta
	"""
	assert n>0 ,"n>0 expected"
	assert shape1>0, "shape1>0 expected"
	assert shape2>0, "shape2>0 expected"

	return _np.random.beta(size=n, a=shape1, b=shape2).tolist()



# ----- Binomial Distribution  -------

def dbinom(x:Iterable|Real, size:int, prob:Real)->list|Real:
	"""
	size: number of trials
	prob: probability of success in each trial
	"""
	return c_stat_dbinom(x, size, prob)


def pbinom(q:Iterable|Real, size:int, prob:Real)->list|Real:
	"""
	size: number of trials
	prob: probability of success in each trial
	"""
	assert size>0, "size>0 expected"
	assert prob>=0 and prob<=1, "prob in [0, 1] expected"

	return c_stat_pbinom(q, size, prob)


def qbinom(p:Iterable|Real, size:int, prob:Real)->list|Real:
	"""
	size: number of trials
	prob: probability of success in each trial
	"""
	assert size>0, "size>0 expected"
	assert prob>=0 and prob<=1, "prob in [0, 1] expected"

	return c_stat_qbinom(p, size, prob)
	

def rbinom(n:int, size:int, prob:Real)->list:
	"""
	size: number of trials
	prob: probability of success in each trial
	"""
	assert n>0 ,"n>0 expected"
	assert size>0, "size>0 expected"
	assert prob>=0 and prob<=1, "prob in [0, 1] expected"

	return _np.random.binomial(size=n, n=size, p=prob).tolist()




# ----- Negative-Binomial Distribution  -------

def dnbinom(x:Iterable|Real, size:int, prob:Real)->list|Real:
	"""
	x: quantiles representing number of failures
	size: target for number of successful trials
	prob: probability of success in each trial
	"""
	assert size>0, "size>0 expected"
	assert prob>=0 and prob<=1, "prob in [0, 1] expected"

	return c_stat_dnbinom(x, size, prob)


def pnbinom(q:Iterable|Real, size:int, prob:Real)->list|Real:
	"""
	q: quantiles representing number of failures
	size: target for number of successful trials
	prob: probability of success in each trial
	"""
	assert size>0, "size>0 expected"
	assert prob>=0 and prob<=1, "prob in [0, 1] expected"

	return c_stat_pnbinom(q, size, prob)


def qnbinom(p:Iterable|Real, size:int, prob:Real)->list|Real:
	"""
	p: probabilities
	size: target for number of successful trials
	prob: probability of success in each trial
	"""
	assert size>0, "size>0 expected"
	assert prob>=0 and prob<=1, "prob in [0, 1] expected"

	return c_stat_qnbinom(p, size, prob)


def rnbinom(n:int, size:int, prob:Real)->list:
	"""
	size: target for number of successful trials
	prob: probability of success in each trial
	"""
	assert n>0 ,"n>0 expected"
	assert size>0, "size>0 expected"
	assert prob>=0 and prob<=1, "prob in [0, 1] expected"

	return _np.random.negative_binomial(size=n, n=size, p=prob).tolist()



# ----- Multinomial Distribution  -------

def dmultinom(x:Iterable, size:int, prob:Iterable)->Real:
	"""
	x: quantiles 
	size: number of trials
	prob: probabilities of success in each trial

	## Note:
	Internally sum of probabilities is normalized to 1.0
	"""

	assert sum(x) == size, "sum(x) == size expected."
	assert size>0, "size>0 expected"

	return c_stat_dmultinom(x, size, prob)


def rmultinom(n:int, size:int, prob:Iterable)->list:
	"""
	size: number of trials
	prob: probabilities of success in each trial

	returns 2D list, where list[i] corresponds to prob[i]

	## Note:
	Sum of probabilities is normalized to 1.0
	"""
	assert size>0, "size>0 expected"
	assert len(prob)>1, "For single prob value use rbinom function"

	Sum = sum(prob) 
	assert Sum>0, "sum of probabilities must be >0"

	return [rbinom(n, size, p/Sum) for p in prob]




# ----- Chi-Square Distribution  -------

def dchisq(x:Iterable|Real, df:int)->list|Real:
	"""
	df: degrees of freedom
	"""
	assert df>0, "df>0 expected"
	return c_stat_dchisq(x, df)


def pchisq(q:Iterable|Real, df:int)->list|Real:
	"""
	df: degrees of freedom
	"""
	assert df>0, "df>0 expected"	
	return c_stat_pchisq(q, df)


def qchisq(p:Iterable|Real, df:int)->list|Real:
	"""
	df: degrees of freedom
	"""
	assert df>0, "df>0 expected"
	return c_stat_qchisq(p, df)


def rchisq(n:int, df)->list:
	"""
	df: degrees of freedom
	"""
	assert n>0 ,"n>0 expected"
	assert df>0, "df>0 expected"

	return _np.random.chisquare(size=n, df = df).tolist()



# ----- Exponential Distribution  -------

def dexp(x:Iterable|Real, rate = 1.0)->list|Real:
	"""
	x: quantiles
	rate: 1/mean, where mean is the waiting time for the next event recurrence
	"""
	return c_stat_dexp(x, rate)


def pexp(q:Iterable|Real, rate = 1.0)->list|Real:
	"""
	q: quantiles
	rate: 1/mean, where mean is the waiting time for the next event recurrence
	"""
	return c_stat_pexp(q,  rate)


def qexp(p:Iterable|Real, rate = 1.0)->list|Real:
	"""
	p: probabilities
	rate: 1/mean, where mean is the waiting time for the next event recurrence
	"""
	return c_stat_qexp(p, rate)


def rexp(n:int, rate=1.0)->list:
	"""
	rate: 1/mean, where mean is the waiting time for the next event recurrence
	"""
	assert n>0 ,"n>0 expected"
	assert rate>0, "rate>0 expected"

	return _np.random.exponential(size=n, scale=1/rate).tolist()



# ----- F Distribution  -------

def df(x:Iterable|Real, df1:int, df2:int)->list|Real:
	"""
	df1: degrees of freedom, numerator
	df2: degrees of freedom, denominator
	"""
	assert df1>0, "df1>0 expected"
	assert df2>0, "df2>0 expected"

	return c_stat_df(x, df1, df2)


def pf(q:Iterable|Real, df1:int, df2:int)->list|Real:
	"""
	df1: degrees of freedom, numerator
	df2: degrees of freedom, denominator
	"""
	assert df1>0, "df1>0 expected"
	assert df2>0, "df2>0 expected"

	return c_stat_pf(q, df1, df2)

def qf(p:Iterable|Real, df1:int, df2:int)->list|Real:
	"""
	df1: degrees of freedom, numerator
	df2: degrees of freedom, denominator
	"""
	assert df1>0, "df1>0 expected"
	assert df2>0, "df2>0 expected"

	return c_stat_qf(p, df1, df2)


def rf(n:int, df1, df2)->list:
	"""
	df1: degrees of freedom, numerator
	df2: degrees of freedom, denominator
	"""
	assert n>0 ,"n>0 expected"
	assert df1>0, "df1>0 expected"
	assert df2>0, "df2>0 expected"

	return _np.random.f(size=n, dfnum=df1, dfden=df2).tolist()




# ----- Gamma Distribution  -------

def dgamma(x:Iterable|Real, shape:Real, scale = 1.0)->list|Real:
	"""
	x: quantile	
	shape: waiting time for the rth event to occur
	scale: average waiting time for the next event recurrence
	"""
	return c_stat_dgamma(x, shape, scale)


def pgamma(q:Iterable|Real, shape:Real, scale = 1.0)->list|Real:
	"""
	q: quantile
	shape: waiting time for the rth event to occur
	scale: average waiting time for the next event recurrence
	"""
	return c_stat_pgamma(q, shape, scale)


def qgamma(p:Iterable|Real, shape:Real, scale = 1.0)->list|Real:
	"""
	p: probabilities
	shape: waiting time for the rth event to occur
	scale: average waiting time for the next event recurrence
	"""
	return c_stat_qgamma(p, shape, scale)


def rgamma(n:int, shape:Real, scale=1.0)->list:
	"""
	Draw samples from gamma distribution
	"""
	assert n>0 ,"n>0 expected"
	assert shape>0, "shape>0 expected"
	assert scale>0, "scale>0 expected"

	return _np.random.gamma(size=n, scale=scale, shape=shape).tolist()




# ----- Geometric Distribution  -------

def dgeom(x:Iterable|Real, prob:Real)->list|Real:
	"""
	x: Number of failures before success occurs.
	prob: probability of success in each trial.
	"""
	return c_stat_dgeom(x, prob)


def pgeom(q:Iterable|Real, prob:Real)->list|Real:
	"""
	q: Number of failures before success occurs.
	prob: probability of success in each trial.
	"""
	return c_stat_pgeom(q, prob)


def qgeom(p:Iterable|Real, prob:Real)->list|Real:
	"""
	p: probabilities
	prob: probability of success in each trial.
	"""
	return c_stat_qgeom(p, prob)


def rgeom(n:int, prob:Real)->list:
	"""
	Draw samples from geometric distribution
	"""
	assert n>0 ,"n>0 expected"
	assert prob>=0 and prob<=1, "prob in [0, 1] expected"

	return _np.random.geometric(size=n, p=prob).tolist()




# ----- Hypergeometric Distribution  -------

def dhyper(x:Iterable|Real, m:int, n:int, k:int)->list|Real:
	"""
	m: number of good samples in the urn
	n: number of bad samples in the urn
	k: samples drawn from the urn
	"""
	return c_stat_dhyper(x, m, n, k)


def phyper(q:Iterable|Real, m:int, n:int, k:int)->list|Real:
	"""
	m: number of good samples in the urn
	n: number of bad samples in the urn
	k: samples drawn from the urn
	"""
	return c_stat_phyper(q, m, n, k)


def qhyper(p:Iterable|Real, m:int, n:int, k:int)->list|Real:
	"""
	m: number of good samples in the urn
	n: number of bad samples in the urn
	k: samples drawn from the urn
	"""
	return c_stat_qhyper(p, m, n, k)


def rhyper(nn:int, m:int, n:int, k:int)->list:
	"""
	m: number of good samples in the urn
	n: number of bad samples in the urn
	k: samples drawn from the urn
	"""
	assert nn>0 ,"nn>0 expected"
	assert m>0, "m>0 expected"
	assert n>0, "n>0 expected"
	assert k>0, "k>0 expected"

	return _np.random.hypergeometric(size=nn, ngood=m, nbad=n, nsample=k)




# ----- Normal Distribution  -------

def dnorm(x:Iterable|Real, mean=0.0, sd=1.0)->list|Real:
	"""
	mean: mean value of the distribution
	sd: standard deviation of the distribution
	"""
	return c_stat_dnorm(x, mean, sd)


def pnorm(q:Iterable|Real, mean=0.0, sd=1.0)->list|Real:
	"""
	mean: mean value of the distribution
	sd: standard deviation of the distribution
	"""
	return c_stat_pnorm(q, mean, sd)


def qnorm(p:Iterable|Real, mean=0.0, sd=1.0)->list|Real:
	"""
	mean: mean value of the distribution
	sd: standard deviation of the distribution
	"""
	return c_stat_qnorm(p, mean, sd)


def rnorm(n:int, mean=0.0, sd=1.0)->list:
	"""
	mean: mean value of the distribution
	sd: standard deviation of the distribution
	"""
	assert n>0 ,"n>0 expected"
	assert sd>0, "sd>0 expected"

	return _np.random.normal(size=n, loc=mean, scale=sd).tolist()




# ----- Log Normal Distribution  -------

def dlnorm(x:Iterable|Real, meanlog=0.0, sdlog=1.0)->list|Real:
	"""
	meanlog: mean value of the distribution
	sdlog: standard deviation of the distribution
	"""
	return c_stat_dlnorm(x, meanlog, sdlog)


def plnorm(q:Iterable|Real, meanlog=0.0, sdlog=1.0)->list|Real:
	"""
	mean: mean value of the distribution
	sd: standard deviation of the distribution
	"""
	return c_stat_plnorm(q, meanlog, sdlog)


def qlnorm(p:Iterable|Real, meanlog=0.0, sdlog=1.0)->list|Real:
	"""
	mean: mean value of the distribution
	sd: standard deviation of the distribution
	"""
	return c_stat_qlnorm(p, meanlog, sdlog)


def rlnorm(n:int, meanlog=0.0, sdlog=1.0)->list:
	"""
	mean: mean value of the distribution
	sd: standard deviation of the distribution
	"""
	assert n>0 ,"n>0 expected"
	assert sdlog>0, "sd>0 expected"

	return _np.random.lognormal(size=n, mean=meanlog, sigma=sdlog).tolist()




# ----- Pareto Distribution  -------

def dpareto(x:Iterable|Real, location:Real, shape=1.0)->list|Real:
	"""
	location: location parameter
	shape: shape parameter
	"""
	assert location>0 and shape>0, "'location' and 'shape' must be positive"
	return c_stat_dpareto(x, location, shape)


def ppareto(q:Iterable|Real, location:Real, shape=1.0)->list|Real:
	"""
	location: location parameter
	shape: shape parameter
	"""
	assert location>0 and shape>0, "'location' and 'shape' must be positive"
	return c_stat_ppareto(q, location, shape)


def qpareto(p:Iterable|Real, location:Real, shape=1.0)->list|Real:
	"""
	location: location parameter
	shape: shape parameter
	"""
	assert location>0 and shape>0, "'location' and 'shape' must be positive"
	return c_stat_qpareto(p, location, shape)


def rpareto(n:int, location:Real, shape=1.0)->list:
	"""
	location: location parameter
	shape: shape parameter
	"""
	assert location>0 and shape>0, "'location' and 'shape' must be positive"
	assert n>0 ,"n>0 expected"
	
	return (_np.random.pareto(size=n, a=shape)*location).tolist()




# ----- Poisson Distribution  -------

def dpois(x:Iterable|Real, mu:Real)->list|Real:
	return c_stat_dpois(x, mu)


def ppois(q:Iterable|Real, mu:Real)->list|Real:
	return c_stat_ppois(q, mu)


def qpois(p:Iterable|Real, mu:Real)->list|Real:
	return c_stat_qpois(p, mu)


def rpois(n:int, mu = 1)->list:
	"""
	Draw samples from Poisson distribution
	"""
	assert n>0 ,"n>0 expected"
	assert mu>0, "mu>0 expected"

	return _np.random.poisson(size=n, lam=mu).tolist()



#---- Kolmogorov-Smirnov Dist --------

def psmirnov(q:Iterable|Real, n:int)->list|Real:
	"""
	n: size of the sample
	"""
	assert isinstance(n, int), "n must be int"
	assert n>0, "n>0 expected"

	return c_stat_psmirnov(q, n)


# ----- t Distribution  -------

def dt(x:Iterable|Real, df:int)->list|Real:
	"""
	df: degrees of freedom
	"""
	assert df>0, "df>0 expected"

	return c_stat_dt(x, df)


def pt(q:Iterable|Real, df:int)->list|Real:
	"""
	df: degrees of freedom
	"""
	assert df>0, "df>0 expected"

	return c_stat_pt(q, df)


def qt(p:Iterable|Real, df:int)->list|Real:
	"""
	df: degrees of freedom
	"""
	assert df>0, "df>0 expected"

	return c_stat_qt(p, df)


def rt(n:int, df)->list:
	"""
	df: degrees of freedom
	"""
	assert n>0 ,"n>0 expected"
	assert df>0, "df1>0 expected"

	return _np.random.standard_t(size=n, df=df).tolist()




# ----- Uniform Distribution  -------

def dunif(x:Iterable|Real, min=0.0, max=1.0)->list|Real:
	"""
	min: minimum bound
	max: maximum bound
	"""
	assert max>min, "max>min expected"

	return c_stat_dunif(x, min, max)


def punif(q:Iterable|Real, min=0.0, max=1.0)->list|Real:
	"""
	min: minimum bound
	max: maximum bound
	"""
	assert max>min, "max>min expected"

	return c_stat_punif(q, min, max)


def qunif(p:Iterable|Real, min=0.0, max=1.0)->list|Real:
	"""
	min: minimum bound
	max: maximum bound
	"""
	assert max>min, "max>min expected"

	return c_stat_qunif(p, min, max)


def runif(n:int, min=0.0, max=1.0)->list:
	"""
	min: minimum bound
	max: maximum bound
	"""
	assert max>min, "max>min expected"
	assert n>0 ,"n>0 expected"

	return _np.random.uniform(size=n, low=min, high=max).tolist()



# ----- Weibull Distribution  -------

def dweibull(x:Iterable|Real, shape:Real, scale = 1.0)->list|Real:
	"""
	x: quantile	
	shape: known as Weibull-slope
	scale: characteristic life
	"""
	assert shape>0, "shape>0 expected"
	assert scale>0, "scale>0 expected"

	return c_stat_dweibull(x, shape, scale)


def pweibull(q:Iterable|Real, shape:Real, scale = 1.0)->list|Real:
	"""
	q: quantile
	shape: known as Weibull-slope
	scale: characteristic life
	"""
	assert shape>0, "shape>0 expected"
	assert scale>0, "scale>0 expected"

	return c_stat_pweibull(q, shape, scale)


def qweibull(p:Iterable|Real, shape:Real, scale = 1.0)->list|Real:
	"""
	p: probabilities
	shape: known as Weibull-slope
	scale: characteristic life
	"""
	assert shape>0, "shape>0 expected"
	assert scale>0, "scale>0 expected"
	
	return c_stat_qweibull(p, shape, scale)


def rweibull(n:int, shape:Real, scale=1.0)->list:
	"""
	Draw samples from weibull distribution
	"""
	assert n>0 ,"n>0 expected"
	assert shape>0, "shape>0 expected"
	assert scale>0, "scale>0 expected"

	return (scale*_np.random.weibull(size=n, a=shape, )).tolist()


# ----- Wilcoxon Sign Rank Distribution  -------

def dsignrank(x:Iterable|Real, n:int)->list|Real:
	return c_stat_dsignrank(x, n)


def psignrank(q:Iterable|Real, n:int)->list|Real:
	return c_stat_psignrank(q, n)


def qsignrank(p:Iterable|Real, n:int)->list|Real:
	return c_stat_qsignrank(p, n)

