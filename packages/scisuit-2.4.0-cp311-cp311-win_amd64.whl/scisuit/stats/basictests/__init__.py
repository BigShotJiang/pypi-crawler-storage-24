from ._test_cor import cor_test, cortest_Result

from ._test_normality import \
	anderson, ADTestRes, \
	ks_1samp, Ks1SampletestResult, \
	shapiro, ShapiroTestResult

from ._test_outliers import dixon_qratio, dixonqratioResult, grubbs, grubbsResult
from ._poisson1sample import test_poisson1sample, test_poisson1sample_Result

from ._test_t import test_t, test_t1_result, test_t2_result, test_tpaired_result
from ._test_z import test_z, test_z1_Result, test_z2_Result

from ._test_variance import test_variance, testvar_onesample_Result, testvar_twosample_Result


