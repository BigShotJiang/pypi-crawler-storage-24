import numbers
from dataclasses import dataclass
from typing import Iterable


from ..._scisuit import nonparam_mannwhitney





@dataclass
class test_mannwhitney_Result:
	acl: None|float
	ci:None|tuple[float, float]
	pvalue:float
	U:float
	W:float
	median_xy:tuple[float, float]

	def __str__(self):
		s = "Mann-Whitney Test \n"
		s += f"Medians: x={self.median_xy[0]}, y={self.median_xy[1]} \n"
		s += f"p-value = {self.pvalue} \n \n"
		s += f"U-statistics = {self.U} \n"
		s += f"W-statistics = {self.W} \n"
		if self.ci != None:
			s += f"Achieved Conf (%) = {self.acl*100} \n"
			s += f"CI = ({self.ci[0]}, {self.ci[1]})"
		return s


def test_mannwhitney(
		x:Iterable, 
		y:Iterable,
		md = 0.0,  
		confint=True,
		alternative="two.sided", 
		conflevel=0.95)->test_mannwhitney_Result:
	"""
	returns Mann-Whitney test class.  

	x, y: Samples  
	md: Hypothesized difference between x and y  
	confint: Should compute confidence intervals?  
	alternative: "two.sided", "less", "greater"   
	conflevel:	Confidence level, [0,1]  
	"""

	assert conflevel>0.0 or conflevel<1.0, "conflevel must be in range (0, 1)"
	assert isinstance(x, Iterable), "x must be Iterable"
	assert isinstance(y, Iterable), "x must be Iterable"
	assert isinstance(md, numbers.Real), "md must be real number"
	assert isinstance(confint, bool), "confint must be bool"
	assert isinstance(alternative, str), "alternative must be str"

	assert alternative in ["two.sided", "less", "greater"], "alternative must be two.sided, less or greater"

	dct =  nonparam_mannwhitney(x, y, md, confint, conflevel, alternative)
	
	return test_mannwhitney_Result(
		acl=dct["acl"] if confint else None,
		ci=(dct["ci_first"], dct["ci_second"]) if confint else None,
		pvalue=dct["pvalue"],
		U=dct["statistics_u"],
		W=dct["statistics_w"],
		median_xy=(dct["median_x"], dct["median_y"]))
	

 