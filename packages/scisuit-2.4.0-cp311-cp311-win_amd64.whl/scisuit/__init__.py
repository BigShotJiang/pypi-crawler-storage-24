from importlib.metadata import version, PackageNotFoundError

try:
	__version__ = version("scisuit")
except PackageNotFoundError:
	__version__ = "unknown"