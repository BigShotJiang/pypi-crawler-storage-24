import js

# Setup the JS registry once
if not hasattr(js, "py_registry"):
	js.py_registry = js.Object.fromEntries([])



from ._app import App
from ._button import Button
from ._input import Checkbox, Radio, Textbox

from ._label import Label

from ._output import Output

from ._select import Select
from ._textarea import Textarea
from ._table import TableCell, TableRow, Table
from ._panels import HPanel, VPanel