import js
from ._element import Element

class Button(Element):
	"""An HTML Button element"""
	def __init__(self, value:str, id:str|None=None, name=""):
		super().__init__(id=id, name=name)
		self.value = value
			

	def onClick(self, func:callable):
		self._add_proxy_func(func=func)
	
	def render(self):
		click_attr = f'onclick="py_registry.{self.id}(event)"' if hasattr(js.py_registry, self.id) else ""

		return f'<button name="{self.name}" id="{self.id}" style="{self.style}" {click_attr}>{self.value}</button>'