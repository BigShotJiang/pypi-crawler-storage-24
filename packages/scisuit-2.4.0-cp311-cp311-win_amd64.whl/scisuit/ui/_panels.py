import js
from ._element import Element

class PanelBase(Element):
	"""An HTML Div element"""
	def __init__(self, elems:list[Element], id:str|None=None, name=""):
		super().__init__(id=id, name=name)
		self._elems = elems
	

	def add(self, elem: Element):
		self._elems.append(elem)
	

	def remove(self, elem: Element, update=True)->bool:
		"""
		removes an element from the container  
		if removed returns True
		"""
		assert isinstance(elem, Element), "elem must be of type Element"

		self._elems.remove(elem)

		if not update:
			return True
		
		obj = js.document.getElementById(elem.id)
		if obj:
			obj.remove()
			return True
		
		return False
	

	def update(self):
		"""Update panel after dynamically adding rows"""

		#delete the inner HTML
		obj = js.document.getElementById(self.id)

		#update with the rows
		obj.innerHTML = " ".join([e.render() for e in self._elems])
	


class HPanel(PanelBase):
	"""Horizontal panel - In essence an HTML Div element"""
	def __init__(self, elems:list[Element], halign:str="start", valign:str="center", gap="3px", id:str|None=None, name=""):
		"""
		elems: Elements  
		halign: horizontal alignment - "start", "center", "end"  
		valign: vertical alignment - "start", "center", "end" 

		For more options check justify-content and align-items
		"""
		super().__init__(elems=elems, id=id, name=name)
		self._elems = elems
		self._halign = halign if halign != "" else "start"
		self._valign = valign if valign != "" else "center"
		self._gap = gap if gap!= "" else "3px"
	
	

	def render(self):
		defaultStyle = f'display:flex; gap:{self._gap}; justify-content:{self._halign}; align-items:{self._valign}'

		return f"""
		<div 
			name="{self.name}"
			id="{self.id}" 
			style="{defaultStyle}; {self.style}">
			{" ".join([e.render() if isinstance(e, Element) else e for e in self._elems])}
		</div>
		"""
	

class VPanel(PanelBase):
	"""Vertical panel - In essence an HTML Div element"""
	def __init__(self, elems:list[Element], halign:str="start", valign:str="center", gap="3px", id:str|None=None, name=""):
		"""
		elems: Elements  
		halign: horizontal alignment - "start", "center", "end"  
		valign: vertical alignment - "start", "center", "end" 

		For more options check justify-content and align-items
		"""
		super().__init__(elems=elems, id=id, name=name)
		self._elems = elems
		self._halign = halign if halign != "" else "start"
		self._valign = valign if valign != "" else "center"
		self._gap = gap if gap!= "" else "3px"
	
	

	def render(self):
		defaultStyle = f'display:flex; flex-direction: column; gap:{self._gap}; justify-content:{self._valign}; align-items:{self._halign}'

		return f"""
		<div 
			name="{self.name}"
			id="{self.id}" 
			style="{defaultStyle}; {self.style}">
			{" ".join([e.render() if isinstance(e, Element) else e for e in self._elems])}
		</div>
		"""