import js
from ._element import Element

class Label(Element):
	"""An HTML span element"""
	def __init__(self, label:str, id=None, name=""):
		super().__init__(id=id, name=name)
		self._label = label
			
	@property
	def label(self)->str:
		return self._label
	
	@label.setter
	def label(self, newLabel:str):
		self._label = newLabel
		obj = js.document.getElementById(self.id)
		obj.innerHTML = newLabel
	
	def render(self):
		return f'<span id="{self.id}" style="{self.style}">{self._label}</span>'