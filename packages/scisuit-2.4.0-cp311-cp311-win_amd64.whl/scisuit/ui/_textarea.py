
import js
from ._element import Element

class Textarea(Element):
	"""An HTML textarea element"""
	
	def __init__(self, value:str, readonly=False, id=None, name=""):
		"""
		value: the actual value in the textbox  
		readonly: can user edit the control
		"""
		super().__init__(id=id, name=name)
		self._value = value
		self._readonly = readonly


	@property
	def value(self):
		return self._value
		

	@value.setter
	def value(self, newValue:str)->None:
		self._value = newValue
		obj = js.document.getElementById(self.id)
		if(obj != None):
			obj.value = newValue

	
	def render(self):
		name = f'name={self.name}' if self.name != "" else ""
		readonly = "readonly" if self._readonly else ""
		
		return f'<textarea {name} {readonly} style="{self.style}" id="{self.id}">{self._value}</textarea>'