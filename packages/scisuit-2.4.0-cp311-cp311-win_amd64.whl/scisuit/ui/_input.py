
import js
from ._element import Element

class Checkbox(Element):
	"""An HTML Input element of type checkbox with associated label"""
	def __init__(self, label, id=None, name=""):
		super().__init__(id=id, name=name)
		self._label = label
			

	def onClick(self, func:callable):
		self._add_proxy_func(func=func)

	@property
	def checked(self)->bool:
		obj = js.document.getElementById(self.id)
		if(obj != None):
			return obj.checked
		return False
		
	@checked.setter
	def checked(self, state:bool):
		obj = js.document.getElementById(self.id)
		if(obj != None):
			obj.checked = state
		
	
	def render(self):
		change_attr = f'onclick="py_registry.{self.id}(event)"' if hasattr(js.py_registry, self.id) else ""
		return f"""
		<div style="display:flex; gap:0.1em; {self.style}">
		<input type="checkbox" name="{self.name}" id="{self.id}" {change_attr}/>
		<label for="{self.id}">{self.label}</label>
		</div>
		"""




""" ---------------------------------------------------------------------------"""




class Radio(Element):
	"""An HTML Input element of type radio with associated label"""
	def __init__(self, label, id=None, name=""):
		super().__init__(id=id, name=name)
		self.label = label
			

	def onClick(self, func:callable):
		self._add_proxy_func(func=func)

	@property
	def checked(self):
		obj = js.document.getElementById(self.id)
		if(obj != None):
			return obj.checked
		
	@checked.setter
	def checked(self, state):
		obj = js.document.getElementById(self.id)
		if(obj != None):
			obj.checked = state
		
	
	def render(self):
		change_attr = f'onclick="py_registry.{self.id}(event)"' if hasattr(js.py_registry, self.id) else ""
		
		return f"""
		<div style="display:flex; gap:0.1em; {self.style}">
		<input type="radio" name="{self.name}" id="{self.id}" {change_attr}/>
		<label for="{self.id}">{self.label}</label>
		</div>
		"""
	





""" --------------------------------------------------------------------  """





class Textbox(Element):
	"""An HTML Input element of type checkbox with associated label"""

	def __init__(self, initvalue, placeholder="", id=None, name=""):
		"""
		value: the actual value in the textbox  
		placeholder: the placeholder value
		"""
		super().__init__(id=id, name=name)
		self._initvalue = initvalue
		self._placeholder = placeholder


	def onInput(self, func:callable):
		self._add_proxy_func(func=func)


	@property
	def value(self):
		obj = js.document.getElementById(self.id)
		if(obj != None):
			return obj.value
		return ""
		
		
	@value.setter
	def value(self, newValue:str)->None:
		obj = js.document.getElementById(self.id)
		if(obj != None):
			obj.value = newValue
	
	
	def render(self):
		input_attr = f'oninput="py_registry.{self.id}(event)"' if hasattr(js.py_registry, self.id) else ""
		return f"""<input 
					type="text" 
					style="{self.style}"
					placeholder="{self._placeholder}" 
					name="{self.name}" 
					id="{self.id}" 
					{input_attr}
					value="{self._initvalue}"/>"""