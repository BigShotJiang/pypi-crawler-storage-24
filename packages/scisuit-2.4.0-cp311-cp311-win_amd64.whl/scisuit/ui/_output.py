import js
from ._element import Element

class Output(Element):
	"""An HTML Div element"""
	def __init__(self, id:str|None=None, name=""):
		super().__init__(id=id, name=name)
	

	def print(self, html:str):
		"""writes the html string (replaces the contents)"""
		obj = js.document.getElementById(self.id)
		obj.innerHTML = html
	

	def println(self, html:str, sep="br", style=""):
		"""
		Appends the html to the existing contents (by default Line Break before appending)
		  
		sep: The separating html element (p or br)  
		style: style of the tag (meaningful for HTMLParagraphElement)
		"""
		obj = js.document.getElementById(self.id)
		existing = obj.innerHTML

		existing += f'<p style="{style}">&nbsp;</p>' if sep.lower() == "p" else "<br/>"
		existing += html

		obj.innerHTML = existing

	
	def clear(self):
		"""clear the contents (equivalent to print(""))"""
		self.print("")
	

	def table(self, data:list[list[str]], transpose=False, header:list[str]=[], style="", cell_style=""):
		"""
		A utility function to append a table  
		  
		data: Each sub-list represents a row  
		transpose: transpose the data? (must be balanced)  
		header: header elements of the table (thead section)  
		style: table style  
		cell_style: style of each cell
		"""
		head_elems = "".join([f'<th style="{cell_style}">{e}</th>' for e in header])

		_data = data
		if transpose:
			_data = [list(row) for row in zip(*data)]

		body_elems = "<tbody>"
		for row in _data:
			body_elems += "<tr>"
			body_elems += "".join([f'<td style="{cell_style}">{e}</td>' for e in row])
			body_elems += "</tr>"
		body_elems += "</tbody>"

		html = f'<table style="{style}">'
		html += f'<thead><tr>{head_elems}</tr></thead>'
		html += body_elems
		html += "</table>"
	
		obj = js.document.getElementById(self.id)
		obj.innerHTML += html
	

	def render(self):
		return f'<div name="{self.name}" id="{self.id}" style="{self.style}"></div>'