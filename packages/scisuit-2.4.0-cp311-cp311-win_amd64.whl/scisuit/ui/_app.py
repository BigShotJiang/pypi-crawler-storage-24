import js
from ._element import Element


class App(Element):
	def run(self, target_id=None):
		html = self.render()
		fragment = js.document.createRange().createContextualFragment(html)

		if target_id:
			js.document.getElementById(target_id).appendChild(fragment)
		else:
			js.document.body.appendChild(fragment)
	

	def remove(self, elem: Element|str)->bool:
		"""
		removes an element from the DOM tree  
		  
		elem: 
		  1. type Element (except Table cell and table row) 
		  2. type str (the id of the element)  

		if removed returns True
		"""
		assert isinstance(elem, Element|str), "elem must be of type Element|str"
		id = elem.id if isinstance(elem, Element) else elem
		obj = js.document.getElementById(id)
		if obj:
			obj.remove()
			return True
		return False