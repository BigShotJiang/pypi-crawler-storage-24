
import js
from ._element import Element

class Select(Element):
	"""An HTML select element"""

	def __init__(self, label:str, id=None, name=""):
		"""
		value: the actual value in the textbox  
		placeholder: the placeholder value
		"""
		super().__init__(id=id, name=name)
		self._label = label
		self._values:list[str] = []

	
	def onChange(self, func:callable):
		self._add_proxy_func(func=func)


	def add(self, value:str, label:str, selected=False, style=""):
		"""Adds HTML option element"""
		sel = "selected" if selected else ""
		self._values.append(f'<option value="{value}" style="{style}" {sel}>{label}</option>')

	
	def selectedIndex(self)->int|None:
		obj = js.document.getElementById(self.id)
		if(obj != None):
			return obj.selectedIndex
		return None
	
	
	def value(self)->str|None:
		obj = js.document.getElementById(self.id)
		if(obj != None):
			return obj.value
		return None

	
	def render(self):
		changeattr = f'onchange="py_registry.{self.id}(event)"' if hasattr(js.py_registry, self.id) else ""
		
		return f"""
		<div style="display:flex; gap:0.1em; {self.style}">
		   <label for="{self.id}">{self._label}</label>
		   <select name="{self.name}" id="{self.id}" {changeattr}>
		      {"\n".join([e for e in self._values])}
		   </select>
		</div>
		"""