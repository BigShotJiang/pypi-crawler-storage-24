
import js
from ._element import Element


class TableCell(Element):
	def __init__(self, value:str|Element, rowspan=1, colspan=1, id=None, name=""):
		super().__init__(id=id, name=name)
		self._value = value
		self._rowspan = rowspan
		self._colspan = colspan
		
	def render(self):
		v = self._value.render() if isinstance(self._value, Element) else self._value
		spanx, spany = f"rowspan={self._rowspan}", f"colspan={self._colspan}"

		return f'<td {spanx} {spany} style="{self.style}" id="{self.id}">{v}</td>'



class TableRow(Element):
	def __init__(self, cells:list[str|TableCell|Element]=None, id=None, name=""):
		super().__init__(id=id, name=name)
		
		self._cells = [] if cells==None else cells
	
	def add(self, elem: TableCell | Element | str, style=""):
		"""Add a table cell, an element or a valid html string (with tags properly starting and closing)"""
		assert isinstance(elem, TableCell|Element|str), "parameter must be TableCell or Element or str"

		if isinstance(elem, TableCell):
			elem.style = style
			self._cells.append(elem)
		elif isinstance(elem, str):
			self._cells.append(f'<td style="{style}">{elem}</td>')
		elif isinstance(elem, Element):
			self._cells.append(f'<td style="{style}">{elem.render()}</td>')
		
	def render(self):
		html = ""
		for e in self._cells:
			if isinstance(e, TableCell):
				html += e.render()
			elif isinstance(e, str):
				html += f'<td>{e}</td>'
			elif isinstance(e, Element):
				html += f'<td>{e.render()}</td>'
			
		return f'<tr style="{self.style}">{html}</tr>'




class Table(Element):
	def __init__(self, rows:list[TableRow], id=None, name=""):
		super().__init__(id=id, name=name)
		self._rows = rows
	

	def add(self, row: TableRow):
		"""appends a row"""
		assert isinstance(row, TableRow), "row must be TableRow"
		self._rows.append(row)


	def insert(self, row:TableRow, index):
		"""Insert row before index"""
		assert isinstance(row, TableRow), "row must be TableRow"
		assert index>=0 and index<len(self._rows), "Invalid row index"

		self._rows.insert(index)
	

	def delrow(self, index, update=True)->bool:
		"""
		deletes a row from the table  

		index:  row index (starts from 0)  
		update: should update the table immediately?

		if removed returns True
		"""
		assert index>=0 and index<len(self._rows), "Invalid row index"
		self._rows.pop(index)

		if not update:
			return True
		
		obj = js.document.getElementById(self.id)
		if obj:
			obj.deleteRow(index)
			return True
		
		return False
	

	def update(self):
		"""Update table after dynamically changing rows"""

		#delete the inner HTML
		obj = js.document.getElementById(self.id)

		#update with the rows
		obj.innerHTML = " ".join([e.render() for e in self._rows])
	

	def nrows(self)->int:
		"""Number of existing rows (before or after updating)"""
		return len(self._rows)
	

	def render(self):
		return f'<table style="{self.style}" id="{self.id}">{" ".join([e.render() for e in self._rows])}</table>'
