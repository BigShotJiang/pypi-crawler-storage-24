import uuid
import js
from pyodide.ffi import create_proxy

from typing import Self



class Element:
	def __init__(self, name="", id=None):
		
		self._id = f"id_{uuid.uuid4().hex[:8]}" if id==None else id
		self._name = name

		self._children = []
		self._proxies = []

		self._style:str = ""


	def add(self, child:str | Self):
		self._children.append(child)
		return self
	
	@property
	def id(self):
		return self._id
	
	@id.setter
	def id(self, newId):
		self._id = newId


	@property
	def name(self):
		return self._name
	
	@name.setter
	def name(self, newName):
		self._name = newName


	@property
	def style(self):
		return self._style
	
	@style.setter
	def style(self, newStyle):
		self._style = newStyle

	

	def _add_proxy_func(self, func:callable):
		# Clean up the old proxy if it exists to prevent memory leaks
		if hasattr(js.py_registry, self.id):
			old_proxy = getattr(js.py_registry, self.id)
			old_proxy.destroy()

		# Create the new proxy
		proxy = create_proxy(func)
		
		# Store and register
		self._proxies.append(proxy)
		setattr(js.py_registry, self.id, proxy)


	def render(self):
		inner = "".join([c.render() if isinstance(c, Element) else str(c) for c in self._children])
		return f'<div>{inner}</div>'