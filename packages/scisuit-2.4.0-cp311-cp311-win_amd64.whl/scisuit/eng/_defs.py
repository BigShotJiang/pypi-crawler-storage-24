from numbers import Real

class Dielectric:
	def __init__(self, constant:Real, loss:Real) -> None:
		self._Constant =constant
		self._Loss = loss
	
	@property
	def constant(self):
		return self._Constant

	@property
	def loss(self):
		return self._Loss