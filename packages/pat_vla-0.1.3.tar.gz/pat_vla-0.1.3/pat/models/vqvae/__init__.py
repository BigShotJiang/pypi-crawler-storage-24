from .models.vqvae import VQVAE
from .models.multivqvae import MultiVQVAE
