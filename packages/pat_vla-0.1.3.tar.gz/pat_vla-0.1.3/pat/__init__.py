"""
PAT (Policy Action Tokenizer) Package

Unified action tokenizer interface supporting multiple backends:
- UAT (ActionCodec): Transformer-based, supports multi-embodiment
- OAT (Object-Action Transformer): Register-based transformer encoder
- VQVAE: CNN-based, efficient encoding
- MultiVQVAE: Multi-action space separated encoding
"""

from pat.normalization import ActionNormalizer
from pat.models.pat_tokenizer import (
    PATTokenizer,
    PATConfig,
    ActionSpaceConfig,
    TokenizerType,
    ArmMode,
    create_uat_tokenizer,
    create_oat_tokenizer,
    create_vqvae_tokenizer,
    create_multivqvae_tokenizer,
)

__all__ = [
    # Normalization
    "ActionNormalizer",
    # PAT Tokenizer
    "PATTokenizer",
    "PATConfig",
    "ActionSpaceConfig",
    "TokenizerType",
    "ArmMode",
    "create_uat_tokenizer",
    "create_oat_tokenizer",
    "create_vqvae_tokenizer",
    "create_multivqvae_tokenizer",
]

# Internal modules (for package use only, not exposed in __all__)
# - pat.normalization: used by PATTokenizer
# - pat.utils: optional utilities (not required by models)
