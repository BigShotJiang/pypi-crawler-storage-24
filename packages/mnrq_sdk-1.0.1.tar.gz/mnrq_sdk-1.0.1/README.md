# MNRQ Python SDK

Official Python SDK for the MNRQ Developer API.

## Install

```bash
pip install mnrq-sdk
```

## Usage

```python
from mnrq_sdk import MnrqClient

client = MnrqClient(
    api_key="<YOUR_API_KEY>",
    base_url="https://menuraq.com",
)

business = client.get_business()
menus = client.get_menus(limit=10)
promotions = client.get_promotions(active_only=True)
render = client.get_template_render(menu_slug="main-menu", mode="iframe")

print(business["data"]["business"]["name"], len(menus["data"]), len(promotions["data"]))
print(render["data"]["embed_code"])
```

Legacy compatibility is preserved: `MenuraqClient` is still exported as an alias.

## Secure write example (`write:menu-items` scope required)

```python
client.update_menu_item(
    "item_uuid_here",
    {
        "title": "Spicy Chicken Deluxe",
        "price": 18.5,
        "available": True,
    },
)
```

## Build package

```bash
python -m pip install --upgrade build
python -m build
```

## Publish to PyPI

```bash
python -m pip install --upgrade twine
twine upload dist/*
```

For private hosting, upload to an internal PyPI server (e.g., Artifactory, Nexus, or GitHub Packages).

## Publish checklist

1. Confirm `pyproject.toml` package name is `mnrq-sdk`.
2. Build artifacts with `python -m build`.
3. Verify locally:
```bash
pip install dist/mnrq_sdk-*.whl
python -c "from mnrq_sdk import MnrqClient; print('ok')"
```
4. Upload with a PyPI token:
```bash
twine upload -u __token__ -p <PYPI_TOKEN> dist/*
```
