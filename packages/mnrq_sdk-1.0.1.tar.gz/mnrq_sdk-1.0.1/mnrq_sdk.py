from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import requests

class MnrqApiError(Exception):
    def __init__(
        self,
        status_code: int,
        message: str,
        code: Optional[str] = None,
        request_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.request_id = request_id
        self.details = details or {}


@dataclass
class MnrqClient:
    api_key: str
    base_url: str
    timeout: float = 20.0

    def __post_init__(self) -> None:
        if not self.api_key:
            raise ValueError("api_key is required")
        if not self.base_url:
            raise ValueError("base_url is required")

        self.base_url = self.base_url.rstrip("/")

    def _request(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        method: str = "GET",
        json_body: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        response = requests.request(
            method=method,
            url=f"{self.base_url}{path}",
            params={k: v for k, v in (params or {}).items() if v is not None},
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            json=json_body,
            timeout=self.timeout,
        )

        try:
            payload = response.json()
        except ValueError:
            payload = None

        if response.status_code >= 400 or not payload or not payload.get("ok"):
            error = (payload or {}).get("error", {})
            raise MnrqApiError(
                status_code=response.status_code,
                message=error.get("message") or f"Request failed ({response.status_code})",
                code=error.get("code"),
                request_id=(payload or {}).get("request_id") or response.headers.get("x-request-id"),
                details=error.get("details") if isinstance(error.get("details"), dict) else None,
            )

        return payload

    def get_business(self) -> Dict[str, Any]:
        return self._request("/api/v1/business")

    def get_api_info(self) -> Dict[str, Any]:
        return self._request("/api/v1")

    def get_branches(self, include_inactive: bool = False) -> Dict[str, Any]:
        return self._request("/api/v1/branches", params={"include_inactive": include_inactive})

    def get_menus(
        self,
        limit: int = 20,
        offset: int = 0,
        status: Optional[str] = None,
        include_items: bool = False,
    ) -> Dict[str, Any]:
        return self._request(
            "/api/v1/menus",
            params={
                "limit": limit,
                "offset": offset,
                "status": status,
                "include_items": include_items,
            },
        )

    def get_menu(self, menu_id: str, include_analytics: bool = False) -> Dict[str, Any]:
        if not menu_id:
            raise ValueError("menu_id is required")
        return self._request(
            f"/api/v1/menus/{menu_id}",
            params={"include_analytics": include_analytics},
        )

    def get_menu_items(
        self,
        menu_id: Optional[str] = None,
        category_id: Optional[str] = None,
        available: Optional[bool] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> Dict[str, Any]:
        return self._request(
            "/api/v1/menu-items",
            params={
                "menu_id": menu_id,
                "category_id": category_id,
                "available": available,
                "limit": limit,
                "offset": offset,
            },
        )

    def get_analytics(
        self,
        menu_id: Optional[str] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        include_daily: bool = True,
    ) -> Dict[str, Any]:
        return self._request(
            "/api/v1/analytics",
            params={
                "menu_id": menu_id,
                "date_from": date_from,
                "date_to": date_to,
                "include_daily": include_daily,
            },
        )

    def get_promotions(
        self,
        menu_id: Optional[str] = None,
        active_only: bool = True,
        limit: int = 25,
        offset: int = 0,
    ) -> Dict[str, Any]:
        return self._request(
            "/api/v1/promotions",
            params={
                "menu_id": menu_id,
                "active_only": active_only,
                "limit": limit,
                "offset": offset,
            },
        )

    def get_promotion(self, promotion_id: str) -> Dict[str, Any]:
        if not promotion_id:
            raise ValueError("promotion_id is required")
        return self._request(f"/api/v1/promotions/{promotion_id}")

    def get_template_render(
        self,
        menu_id: Optional[str] = None,
        menu_slug: Optional[str] = None,
        mode: str = "iframe",
    ) -> Dict[str, Any]:
        if not menu_id and not menu_slug:
            raise ValueError("menu_id or menu_slug is required")
        return self._request(
            "/api/v1/templates/render",
            params={
                "menu_id": menu_id,
                "menu_slug": menu_slug,
                "mode": mode,
            },
        )

    def update_menu_item(self, item_id: str, patch: Dict[str, Any]) -> Dict[str, Any]:
        if not item_id:
            raise ValueError("item_id is required")
        if not isinstance(patch, dict) or len(patch) == 0:
            raise ValueError("patch must be a non-empty object")

        return self._request(
            f"/api/v1/menu-items/{item_id}",
            method="PATCH",
            json_body=patch,
        )


# Backward-compatible aliases for legacy imports.
MenuraqApiError = MnrqApiError
MenuraqClient = MnrqClient

__all__ = [
    "MnrqClient",
    "MnrqApiError",
    "MenuraqClient",
    "MenuraqApiError",
]
