cpu = 'cpu'
cuda = 'cuda'