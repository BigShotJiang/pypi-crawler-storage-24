from __future__ import annotations

import argparse

from sagellm_workstation.server import run_server


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="sagellm-workstation")
    subparsers = parser.add_subparsers(dest="command")

    serve = subparsers.add_parser("serve", help="Start the workstation web UI")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=None)
    serve.add_argument("--no-browser", action="store_true")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command in (None, "serve"):
        run_server(host=args.host, port=args.port, open_browser=not args.no_browser)
        return

    parser.error(f"unsupported command: {args.command}")