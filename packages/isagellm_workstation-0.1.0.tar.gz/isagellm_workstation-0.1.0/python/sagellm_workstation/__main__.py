from sagellm_workstation.cli import main


if __name__ == "__main__":
    main()