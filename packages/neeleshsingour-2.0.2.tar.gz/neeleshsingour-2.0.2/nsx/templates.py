# nsx/templates.py

# 1. यूजर की app.py का टेम्पलेट (एकदम छोटा और प्रोफेशनल)
APP_PY_TEMPLATE = """from nsx.ns14engine import run_nsx_app

if __name__ == '__main__':
    run_nsx_app()
"""

# 2. App.nsx (Router / Splash Screen)
APP_NSX_TEMPLATE = """def render():
    return f'''
    <style>
        body {{ 
            background: #111122; 
            color: white; 
            font-family: sans-serif; 
            text-align: center; 
            padding-top: 20%; 
        }}
        .loader {{
            border: 4px solid #f3f3f3;
            border-top: 4px solid #61dafb;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }}
        @keyframes spin {{ 0% {{ transform: rotate(0deg); }} 100% {{ transform: rotate(360deg); }} }}
    </style>
    <body>
        <div class="loader"></div>
        <h1>NSX Framework Load हो रहा है...</h1>
        <script>
            // 1.5 सेकंड बाद ऑटोमैटिक होम स्क्रीन पर भेजें
            setTimeout(() => {{ 
                window.pywebview.api.navigate('HomeScreen'); 
            }}, 1500);
        </script>
    </body>
    '''
"""

# 3. HomeScreen.nsx (डेटा भेजने वाली स्क्रीन)
HOME_NSX_TEMPLATE = """def render():
    return f'''
    <body style="background:#111122; color:white; text-align:center; font-family:sans-serif; padding:50px;">
        <h1 style="color:#61dafb;">🏠 Home Screen</h1>
        <p>अपना नाम लिखें और Profile देखें:</p>
        <br>
        <input type="text" id="username" placeholder="Name यहाँ लिखें..." 
               style="padding:12px; border-radius:8px; border:none; width:250px; font-size:16px;">
        <br><br>
        <button onclick="window.pywebview.api.navigate('ProfileScreen', {{'user_name': document.getElementById('username').value}})" 
                style="padding:12px 25px; background:#10b981; color:white; border:none; border-radius:8px; cursor:pointer; font-weight:bold; font-size:16px;">
            Profile पर जाएँ 🚀
        </button>
    </body>
    '''
"""

# 4. ProfileScreen.nsx (डेटा रिसीव करने वाली स्क्रीन)
PROFILE_NSX_TEMPLATE = """def render():
    # 'props' से डेटा निकालना (Home Screen से भेजा गया)
    user = props.get("user_name", "Guest")
    
    return f'''
    <body style="background:#0a0a1a; color:white; text-align:center; font-family:sans-serif; padding:50px;">
        <div style="background:#1a1a2e; padding:40px; border-radius:20px; border:1px solid #61dafb; display:inline-block;">
            <h1 style="margin-bottom:10px;">👤 User Profile</h1>
            <hr style="border:0.5px solid #333;">
            <h2 style="color:#61dafb; font-size:32px;">स्वागत है, {user}!</h2>
            <p style="color:#888;">यह डेटा 'Props' के ज़रिए दूसरी स्क्रीन से आया है।</p>
            <br>
            <button onclick="window.pywebview.api.navigate('HomeScreen')" 
                    style="background:none; border:1px solid #61dafb; color:#61dafb; padding:8px 20px; border-radius:5px; cursor:pointer;">
                ← वापस जाएँ
            </button>
        </div>
    </body>
    '''
"""