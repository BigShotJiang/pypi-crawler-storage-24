# nsx/ns14engine.py
import webview
import os
import sys

def get_resource_path(relative_path):
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

class BackendAPI:
    def __init__(self):
        self.window = None

    def set_window(self, window):
        self.window = window

    def navigate(self, screen_name, params=None):
        # 1. सुरक्षा के लिए चेक: क्या विंडो रेडी है?
        if self.window:
            print(f"📡 Navigating to: {screen_name} | Params: {params}")
            html = compile_nsx(f"src/{screen_name}.nsx", params)
            self.window.load_html(html)
        else:
            print("⚠️ Error: Window अभी लोड नहीं हुई है!")

def compile_nsx(file_path, props=None):
    full_path = get_resource_path(file_path)
    
    # 2. अगर फाइल न मिले तो क्रैश होने के बजाय साफ़ एरर दिखे
    if not os.path.exists(full_path):
        return f"""
        <body style="background:#221111; color:white; text-align:center; padding-top:20%;">
            <h1>❌ 404: File Not Found</h1>
            <p>फाइल नहीं मिली: <code>{file_path}</code></p>
            <button onclick="window.pywebview.api.navigate('HomeScreen')">Go Home</button>
        </body>
        """

    with open(full_path, "r", encoding="utf-8") as f:
        nsx_code = f.read()
    
    # ✅ यहाँ तुमने सिंगल { } कर दिया है, अब TypeError नहीं आएगा!
    env = {"props": props} if props else {"props": {}}
    
    try:
        # यहाँ 'globals' और 'locals' दोनों के लिए env पास करना अच्छा रहता है
        exec(nsx_code, env, env) 
        if "render" in env:
            return env["render"]()
    except Exception as e:
        return f"<h1 style='color:red;'>Rendering Error: {e}</h1>"
    
    return "<h1>Error: render() missing!</h1>"

def run_nsx_app():
    api = BackendAPI()
    
    # पहली स्क्रीन लोड करना
    initial_html = compile_nsx('src/App.nsx')
    
    window = webview.create_window(
        'NSX Professional App', 
        html=initial_html, 
        js_api=api, 
        width=900, 
        height=700, 
        background_color='#111122'
    )
    
    api.set_window(window)
    webview.start()