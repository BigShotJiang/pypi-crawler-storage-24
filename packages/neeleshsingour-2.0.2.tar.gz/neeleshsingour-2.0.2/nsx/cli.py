import os
import sys
import time
import subprocess
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# 💡 Import Fix: अगर पैकेज के अंदर से चल रहा है या सीधे, दोनों को हैंडल करेगा
try:
    from .templates import APP_PY_TEMPLATE, APP_NSX_TEMPLATE, HOME_NSX_TEMPLATE, PROFILE_NSX_TEMPLATE
except ImportError:
    # अगर आप सीधे 'python cli.py' चलाकर टेस्ट कर रहे हैं
    import templates
    APP_PY_TEMPLATE = templates.APP_PY_TEMPLATE
    APP_NSX_TEMPLATE = templates.APP_NSX_TEMPLATE
    HOME_NSX_TEMPLATE = templates.HOME_NSX_TEMPLATE
    PROFILE_NSX_TEMPLATE = templates.PROFILE_NSX_TEMPLATE

# ---------------------------------------------------------
# 🧩 VS CODE EXTENSION — SILENT INSTALL (नया और सुरक्षित तरीका)
# ---------------------------------------------------------
def setup_vscode_extension():
    print("✨ NSX Framework: VS Code एक्सटेंशन चेक किया जा रहा है...")
    try:
        # 'shell=True' और 'stdout/stderr' को पाइप करने से नया विंडो नहीं खुलेगा
        subprocess.run(
            "code --install-extension NeeleshSingour.neeleshsingour --force",
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        print("✅ VS Code Extension बैकग्राउंड में रेडी हो गया है!")
    except Exception as e:
        print(f"⚠️ एक्सटेंशन इंस्टॉल नहीं हो सका (शायद VS Code PATH में नहीं है)।")

# ---------------------------------------------------------
# 🔥 1. HOT RELOADING LOGIC
# ---------------------------------------------------------
class ReloadHandler(FileSystemEventHandler):
    def __init__(self):
        self.process = None
        self.start_process()

    def start_process(self):
        # app.py को अलग प्रोसेस में चलाना
        self.process = subprocess.Popen([sys.executable, "app.py"])

    def on_modified(self, event):
        if event.src_path.endswith((".py", ".nsx", ".html", ".css", ".js")):
            print(f"\n🔄 बदलाव मिला: {os.path.basename(event.src_path)}")
            if self.process:
                self.process.terminate()
            time.sleep(0.5) # छोटा सा पॉज़ ताकि फाइल पूरी तरह सेव हो जाए
            self.start_process()

def start_app_with_reload():
    if not os.path.exists("app.py"):
        print("❌ Error: 'app.py' नहीं मिली! क्या आप प्रोजेक्ट फोल्डर के अंदर हैं?")
        return
    
    print("🔥 NSX Hot Reloading Active! 'src/App.nsx' में कोडिंग शुरू करें...")
    event_handler = ReloadHandler()
    observer = Observer()
    observer.schedule(event_handler, path='.', recursive=True)
    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        if event_handler.process:
            event_handler.process.terminate()
    observer.join()

# ---------------------------------------------------------
# 🛠️ 2. MAIN CLI FUNCTION
# ---------------------------------------------------------
def main():
    if len(sys.argv) < 2:
        print("⚡ NSX Framework: Use 'nsx create <name>' to start.")
        sys.exit(1)

    cmd = sys.argv[1].lower()

    if cmd == "create":
        if len(sys.argv) < 3:
            print("❌ गलती: प्रोजेक्ट का नाम भी लिखें! (उदा: nsx create my_app)")
            sys.exit(1)
        
        project_name = sys.argv[2]
        
        try:
            print(f"🚀 प्रोजेक्ट '{project_name}' बनाया जा रहा है...")
            
            # 1. फोल्डर्स बनाना
            os.makedirs(f"{project_name}/src", exist_ok=True)
            
            # 2. फाइल्स लिखना
            files = {
                "app.py": APP_PY_TEMPLATE,
                "src/App.nsx": APP_NSX_TEMPLATE,
                "src/HomeScreen.nsx": HOME_NSX_TEMPLATE,
                "src/ProfileScreen.nsx": PROFILE_NSX_TEMPLATE
            }

            for path, content in files.items():
                with open(os.path.join(project_name, path), "w", encoding="utf-8") as f:
                    f.write(content)
            
            print(f"✅ फाइलें सफलतापूर्वक बन गई हैं!")
            
            # 3. एक्सटेंशन इंस्टॉल करना (चुपचाप)
            setup_vscode_extension()
            
            print(f"\n🎉 सब तैयार है! अब ये टाइप करें:\n   cd {project_name}\n   nsx start")

        except Exception as e:
            print(f"❌ प्रोजेक्ट बनाने में एरर आया: {e}")

    elif cmd == "start":
        start_app_with_reload()

    elif cmd == "build":
        print("📦 PyInstaller के साथ बिल्ड शुरू हो रहा है...")
        # (आपका पुराना बिल्ड कोड यहाँ डाल सकते हैं)

if __name__ == "__main__":
    main()