# setup.py
from setuptools import setup, find_packages

setup(
    name="neeleshsingour",           # 👈 तुम्हारा यूनिक ब्रांड नाम
    version="2.0.2",                 # पहला स्टेबल वर्ज़न
    packages=find_packages(),
    description="A simple Python Desktop Framework with HTML/CSS/JS and SQLite Support",
    long_description="A framework to build lightweight desktop apps using Python and Web technologies.",
    long_description_content_type="text/markdown",
    author="Neelesh Singour",
    install_requires=[
        "pywebview",
        "pyinstaller",
        "watchdog",
    ],
    entry_points={
        "console_scripts": [
            "nsx = nsx.cli:main",     # 👈 कमांड अभी भी 'nsx' ही रहेगा (आसान रखने के लिए)
            
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
    ],
)