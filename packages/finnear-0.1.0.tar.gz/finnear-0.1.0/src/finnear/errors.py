class FinnearError(Exception):
    pass


class AuthenticationError(FinnearError):
    def __init__(self, message: str = "Invalid or missing API key") -> None:
        super().__init__(message)


class ValidationError(FinnearError):
    def __init__(self, message: str) -> None:
        super().__init__(message)


class ApiError(FinnearError):
    def __init__(self, message: str, status: int) -> None:
        super().__init__(message)
        self.status = status
