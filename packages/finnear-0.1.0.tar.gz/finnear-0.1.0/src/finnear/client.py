from __future__ import annotations

import json
import urllib.request
import urllib.error

from finnear.errors import ApiError, AuthenticationError, FinnearError, ValidationError
from finnear.types import EventPayload, EventResponse

DEFAULT_BASE_URL = "https://finnear.com"


class Finnear:
    def __init__(self, *, api_key: str, base_url: str = DEFAULT_BASE_URL) -> None:
        if not api_key:
            raise FinnearError("api_key is required")

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")

    def track(self, event: EventPayload) -> EventResponse:
        url = f"{self._base_url}/webhook/ingest"
        data = json.dumps(event.to_dict()).encode()

        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._api_key}",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req) as resp:
                body = json.loads(resp.read().decode())
                return EventResponse.from_dict(body)
        except urllib.error.HTTPError as exc:
            try:
                error_body = json.loads(exc.read().decode())
                message = error_body.get("error", "Unknown error")
            except (json.JSONDecodeError, ValueError):
                message = exc.reason or "Unknown error"

            if exc.code == 401:
                raise AuthenticationError(message) from exc
            if exc.code == 400:
                raise ValidationError(message) from exc
            raise ApiError(message, exc.code) from exc
