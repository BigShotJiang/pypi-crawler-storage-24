from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class EventPayload:
    channel: str
    title: str
    description: str | None = None
    emoji: str | None = None
    user_id: str | None = None
    metadata: dict[str, str] | None = None

    def to_dict(self) -> dict[str, object]:
        data: dict[str, object] = {
            "channel": self.channel,
            "title": self.title,
        }
        if self.description is not None:
            data["description"] = self.description
        if self.emoji is not None:
            data["emoji"] = self.emoji
        if self.user_id is not None:
            data["userId"] = self.user_id
        if self.metadata is not None:
            data["metadata"] = self.metadata
        return data


@dataclass
class EventResponse:
    event_id: str = field(default="")

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> EventResponse:
        return cls(event_id=str(data.get("eventId", "")))
