"""Shared Stage-A context request contract.

Centralises the JSON schema and request-type constraints so that run_eval
prompts, patcher system prompts, docs, and tests stay aligned.
"""

from __future__ import annotations

STAGE_A_ALLOWED_REQUEST_TYPES: tuple[str, ...] = ("file", "search", "frame")

# Compact, single-line schema string for system messages.
STAGE_A_REQUEST_SCHEMA_COMPACT = (
    '{"diagnosis":"one-sentence root-cause hypothesis",'
    '"missing_fact":"specific fact needed, or null",'
    '"need_more_context":true,'
    '"need_snapshot":false,'
    '"need_compact_context":false,'
    '"requests":[{"type":"file","path":"relative/path.py"},'
    '{"type":"search","path":"relative/path.py","pattern":"literal_text"},'
    '{"type":"frame","index":1}],'
    '"snapshot_justification":"one short sentence (only when need_snapshot=true)",'
    '"compact_context_reason":"one short sentence (only when need_compact_context=true)",'
    '"sufficiency_rationale":"one short sentence"}'
)

# Pretty-printed schema snippet for multi-line prompt contracts.
STAGE_A_REQUEST_SCHEMA_PRETTY = (
    "{\n"
    '  "diagnosis": "one-sentence root-cause hypothesis",\n'
    '  "missing_fact": "specific fact needed, or null",\n'
    '  "need_more_context": true,\n'
    '  "need_snapshot": false,\n'
    '  "need_compact_context": false,\n'
    '  "requests": [\n'
    '    {"type":"file","path":"relative/path.py"},\n'
    '    {"type":"search","path":"relative/path.py","pattern":"literal_text"},\n'
    '    {"type":"frame","index":1}\n'
    "  ],\n"
    '  "snapshot_justification":"one short sentence (only when need_snapshot=true)",\n'
    '  "compact_context_reason":"one short sentence (only when need_compact_context=true)",\n'
    '  "sufficiency_rationale":"one short sentence"\n'
    "}"
)


def stage_a_allowed_request_types_text() -> str:
    """Return the allowed Stage-A request types as a comma-separated string."""
    return ", ".join(STAGE_A_ALLOWED_REQUEST_TYPES)


__all__ = [
    "STAGE_A_ALLOWED_REQUEST_TYPES",
    "STAGE_A_REQUEST_SCHEMA_COMPACT",
    "STAGE_A_REQUEST_SCHEMA_PRETTY",
    "stage_a_allowed_request_types_text",
]
