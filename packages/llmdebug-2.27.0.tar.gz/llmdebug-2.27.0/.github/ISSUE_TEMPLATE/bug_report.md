---
name: Bug Report
about: Report a bug in llmdebug
labels: bug
---

## Description

<!-- A clear, concise description of the bug. -->

## Steps to reproduce

```python
# Minimal reproducer
```

## Expected behavior

<!-- What you expected to happen. -->

## Actual behavior

<!-- What actually happened. Include tracebacks or error messages. -->

## Environment

- Python version:
- OS:
- llmdebug version:
- Installation extras (cli/mcp/toon):

## Debug snapshot output (optional)

<!-- If relevant, attach the output of: -->
<!-- llmdebug show --json --detail context -->

<details>
<summary>Snapshot</summary>

```json

```

</details>

## Additional context

<!-- Anything else: related issues, screenshots, config files. -->
