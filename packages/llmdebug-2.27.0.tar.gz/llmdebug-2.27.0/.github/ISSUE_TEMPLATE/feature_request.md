---
name: Feature Request
about: Suggest an enhancement
labels: enhancement
---

## Description

<!-- A clear, concise description of the feature. -->

## Motivation / Use case

<!-- Why is this needed? What problem does it solve? -->

## Proposed solution

<!-- How should it work? Include API sketches or CLI examples if applicable. -->

## Alternatives considered

<!-- Other approaches you've thought about and why they're less ideal. -->

## Additional context

<!-- Links, references, related issues. -->
