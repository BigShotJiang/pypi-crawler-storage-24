## Description

<!-- What does this PR do and why? -->

## Related issues

<!-- Closes #XX -->

## Type of change

- [ ] `feat` — new feature
- [ ] `fix` — bug fix
- [ ] `docs` — documentation only
- [ ] `test` — tests only
- [ ] `refactor` — no behavior change
- [ ] `chore` — tooling, CI, dependencies

## Checklist

- [ ] Tests added or updated for the change
- [ ] Docs updated (if user-visible behavior changed)
- [ ] `just check` passes (lint + typecheck + tests)
- [ ] Commit message follows [Conventional Commits](https://www.conventionalcommits.org/)

See [CONTRIBUTING.md](../CONTRIBUTING.md) for quality gates and local dev setup.
