# Changelog

## 0.1.4

- Add Development section to README

## 0.1.1

- Re-release for PyPI publishing

## 0.1.0 (2026-03-15)

- Initial release
- Parse, compare, and validate semver strings
- Bump major, minor, and patch versions
- Range matching with `>=`, `<`, `^`, and `~` operators
- Sort version string lists
- Generate next pre-release versions
