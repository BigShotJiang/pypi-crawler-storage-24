import json
import string
from pathlib import Path

import pytest as pytest
from fuzzywuzzy import fuzz, process
from pymultirole_plugins.v1.schema import Document, DocumentList, Sentence

from pyannotators_spacyner.spacyner import (
    SciSpacyLinker,
    SpacyModelSize,
    SpacyModelType,
    SpacyNERAnnotator,
    SpacyNERParameters,
    document_language,
)


def test_document_language():
    doc_with_lang = Document(text="hello", metadata={"language": "en"})
    assert document_language(doc_with_lang) == "en"
    assert document_language(doc_with_lang, "fr") == "en"

    doc_no_lang = Document(text="hello", metadata={"other": "value"})
    assert document_language(doc_no_lang) is None
    assert document_language(doc_no_lang, "fr") == "fr"

    doc_no_meta = Document(text="hello")
    assert document_language(doc_no_meta) is None
    assert document_language(doc_no_meta, "de") == "de"


def test_parameters_defaults():
    params = SpacyNERParameters()
    assert params.model_type == SpacyModelType.base
    assert params.model_size == SpacyModelSize.sm
    assert params.scispacy_linker is None
    assert params.mapping is None
    assert params.types_filter == ""
    assert params.mention_threshold == 0.85
    assert params.mention_max == 1


def test_missing_language_raises():
    annotator = SpacyNERAnnotator()
    parameters = SpacyNERParameters()
    with pytest.raises(AttributeError, match="language"):
        annotator.annotate([Document(text="Hello world.")], parameters)


def test_unsupported_language_raises():
    annotator = SpacyNERAnnotator()
    parameters = SpacyNERParameters()
    with pytest.raises(AttributeError, match="language"):
        annotator.annotate([Document(text="Bonjour.", metadata={"language": "xx"})], parameters)


def test_multiple_documents():
    annotator = SpacyNERAnnotator()
    parameters = SpacyNERParameters()
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text="Paris is the capital of France.",
                metadata={"language": "en"},
            ),
            Document(
                text="Emmanuel Macron is the president.",
                metadata={"language": "en"},
            ),
        ],
        parameters,
    )
    assert len(docs) == 2
    assert len(docs[0].annotations) > 0
    assert len(docs[1].annotations) > 0
    labels_doc0 = {a.label for a in docs[0].annotations}
    assert "GPE" in labels_doc0
    labels_doc1 = {a.label for a in docs[1].annotations}
    assert "PERSON" in labels_doc1


def test_presegmented_document():
    annotator = SpacyNERAnnotator()
    parameters = SpacyNERParameters()
    text = "Paris is in France. Emmanuel Macron is the president."
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text=text,
                sentences=[Sentence(start=0, end=19), Sentence(start=20, end=len(text))],
                metadata={"language": "en"},
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    assert len(doc0.annotations) > 0
    # All annotation offsets must be within the full text bounds
    for ann in doc0.annotations:
        assert ann.start >= 0
        assert ann.end <= len(text)
        assert doc0.text[ann.start : ann.end] == ann.text


def test_spacyner():
    model = SpacyNERAnnotator.get_model()
    model_class = model.model_construct().__class__
    assert model_class == SpacyNERParameters
    annotator = SpacyNERAnnotator()
    parameters = SpacyNERParameters()
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text="Paris is the capital of France and Emmanuel Macron is the president of the French Republic.",
                metadata={"language": "en"},
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    assert len(doc0.annotations) == 4
    paris = doc0.annotations[0]
    france = doc0.annotations[1]
    macron = doc0.annotations[2]
    republic = doc0.annotations[3]
    assert paris.label == "GPE"
    assert france.label == "GPE"
    assert macron.label == "PERSON"
    assert republic.label == "GPE"

    parameters.mapping = {"location": ["LOC", "GPE"], "person": ["PERSON"], "organization": ["ORG"]}
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text="Paris is the capital of France and Emmanuel Macron is the president of the French Republic.",
                metadata={"language": "en"},
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    assert len(doc0.annotations) == 4
    paris = doc0.annotations[0]
    france = doc0.annotations[1]
    macron = doc0.annotations[2]
    republic = doc0.annotations[3]
    assert paris.labelName == "location"
    assert france.labelName == "location"
    assert macron.labelName == "person"
    assert republic.labelName == "location"


@pytest.mark.skip(reason="Requires scispacy model download")
def test_scispacyner():
    testdir = Path(__file__).parent / "data"
    model = SpacyNERAnnotator.get_model()
    model_class = model.model_construct().__class__
    assert model_class == SpacyNERParameters
    annotator = SpacyNERAnnotator()
    parameters = SpacyNERParameters(
        model_type=SpacyModelType.sci, model_size=SpacyModelSize.sm, scispacy_linker=SciSpacyLinker.mesh
    )
    # docs: List[Document] = annotator.annotate([Document(
    #     text="Myeloid derived suppressor cells (MDSC) are immature myeloid cells with immunosuppressive activity.\nThey accumulate in tumor-bearing mice and humans with different types of cancer, including hepatocellular carcinoma (HCC).",
    #     metadata={'language': 'en'})], parameters)
    # doc0 = docs[0]
    # assert len(doc0.annotations) == 12

    parameters.model_size = SpacyModelSize.scibert
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text="""Comorbidities in COVID-19 patients often lead to more severe outcomes. The disease-specific molecular events, which may induce susceptibility to Severe Acute Respiratory Syndrome Coronavirus 2 (SARS-CoV-2) infection, are being investigated. To assess this, we retrieved array-based gene expression datasets from patients of 30 frequently occurring acute, chronic, or infectious diseases. Comparative analyses of the datasets were performed after quantile normalization and log2 transformation. Among the 78 host genes prominently implicated in COVID-19 infection, ACE2 (receptor for SARS-CoV-2) was positively regulated in several cases, namely, leukemia, psoriasis, lung cancer, non-alcoholic fatty liver disease (NAFLD), breast cancer, and pulmonary arterial hypertension (PAH). FURIN was positively regulated in some cases, such as leukemia, psoriasis, NAFLD, lung cancer, and type II diabetes (T2D), while TMPRSS2 was positively regulated in only 3 cases, namely, leukemia, lung cancer, and T2D. Genes encoding various interferons, cytokines, chemokines, and mediators of JAK-STAT pathway were positively regulated in leukemia, NAFLD, and T2D cases. Among the 161 genes that are positively regulated in the lungs of COVID-19 patients, 99-111 genes in leukemia (including various studied subtypes), 77 genes in NAFLD, and 48 genes in psoriasis were also positively regulated. Because of the high similarity in gene expression patterns, the patients of leukemia, NAFLD, T2D, psoriasis, and PAH may need additional preventive care against acquiring SARS-CoV-2 infections. Further, two genes CARBONIC ANHYDRASE 11 (CA11) and CLUSTERIN (CLU) were positively regulated in the lungs of patients infected with either SARS-CoV-2, or SARS-CoV or Middle East Respiratory Syndrome Coronavirus (MERS-CoV).""",
                metadata={"language": "en"},
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    assert len(doc0.annotations) == 103
    dl = DocumentList(root=docs)
    json_file = testdir / "negid2.json"
    with json_file.open("w") as fout:
        print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


def to_camel_case(s):
    return s[0].lower() + string.capwords(s, sep="_").replace("_", "")[1:] if s else s


@pytest.mark.skip(reason="Not a test")
def test_scai():
    annotator = SpacyNERAnnotator()
    parameters = SpacyNERParameters(
        model_type="sci",
        scispacy_linker="umls",
        types_filter=",".join(
            [
                "T028",
                "T116",
                "T123",
                "T126",
                "T043",
                "T047",
                "T121",
                "T109",
                "T026",
                "T025",
                "T129",
                "T192",
                "T044",
                "T048",
                "T043",
                "T131",
                "T125",
                "T043",
                "T130",
                "T196",
                "T005",
                "T008",
                "T010",
                "T012",
                "T013",
                "T014",
                "T015",
                "T016",
                "T017",
                "T018",
                "T021",
                "T022",
                "T023",
                "T024",
                "T025",
                "T026",
            ]
        ),
    )
    parameters = SpacyNERParameters(model="en_core_sci_sm", scispacy_linker="umls")
    testdir = Path(__file__).parent / "data"
    json_file = testdir / "all_bell_relations.json"
    with json_file.open("r") as fin:
        docs = json.load(fin)
    docs = [Document(**doc) for doc in docs]
    docs = annotator.annotate(docs, parameters)
    json_file = testdir / f"all_bell_relations_annotated_{parameters.scispacy_linker.value}.json"
    dl = DocumentList(root=docs)
    with json_file.open("w") as fout:
        print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


def find_in_forms(el, forms):
    for k in el:
        if "name" in el[k]:
            name = el[k]["name"]
            if name.lower() in forms:
                return k
    return None


def fuzzy_find_in_forms(el, forms, threshold=85):
    for k in el:
        if isinstance(el[k], dict):
            if "name" in el[k]:
                name = el[k]["name"]
                extracted = process.extractOne(name.lower(), forms, scorer=fuzz.WRatio)
                if extracted[1] > threshold:
                    copy_el = {k1: v1 for k1, v1 in el.items() if k1 in ["function", k]}
                    return copy_el
        elif k == "members" and isinstance(el[k], list):
            for subel in el[k]:
                ret = fuzzy_find_in_forms(subel, forms, threshold)
                if ret is not None:
                    return ret
    return None
