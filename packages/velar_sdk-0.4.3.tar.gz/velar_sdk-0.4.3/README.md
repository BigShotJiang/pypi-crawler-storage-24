# Velar Python SDK

Deploy ML models to GPUs with one command.

## Installation

```bash
pip install velar-sdk
```

## Quick Start

```bash
velar login          # authenticate via browser
velar deploy app:app # deploy to GPU cloud
```

**Full documentation:** [velar.run/docs](https://velar.run/docs)

## Links

- [Documentation](https://velar.run/docs)
- [Dashboard](https://velar.run/dashboard)
- [Pricing](https://velar.run/pricing)
