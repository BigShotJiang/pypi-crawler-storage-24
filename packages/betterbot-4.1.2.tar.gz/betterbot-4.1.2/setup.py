from setuptools import setup, find_packages

setup(
    name="betterbot",
    version="4.1.2",
    packages=["betterbot", "betterbot/gateway_client/command_related", "betterbot/gateway_client", "betterbot/rest_client", "betterbot/rest_client/rest_handlers", "betterbot/gateway_client/connection", "betterbot/gateway_client/event_related", "betterbot/gateway_client/handlers"],  # Explicitly list top-level packages
)