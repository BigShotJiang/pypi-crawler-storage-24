# ruff: noqa: D100
# type: ignore

#########################################
# Start the script (and install Pyxel): #
#   uvx pyxel-sim run run_model.py      #
#########################################

import numpy as np
import xarray as xr

import pyxel

print(f"Pyxel version: {pyxel.__version__=}")

# Load the configuration file
config = pyxel.load("config.yaml")

# Run Pyxel
datatree: xr.DataTree = pyxel.run_mode(config)

image = np.array(datatree["/bucket/image"])

datatree["/bucket/image"].plot()
