# ruff: noqa: B905,D100,TC002
#  Copyright (c) European Space Agency, 2020.
#
#  This file is subject to the terms and conditions defined in file 'LICENCE.txt', which
#  is part of this Pyxel package. No part of the package, including
#  this file, may be copied, modified, propagated, or distributed except according to
#  the terms contained in the file ‘LICENCE.txt’.

#########################################
# Start the script (and install Pyxel): #
#   uvx pyxel-sim demo                  #
#########################################

# type: ignore

import base64
import datetime
import io
import os
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import panel as pn
import param
import PIL
import xarray as xr
from bokeh.models.formatters import PrintfTickFormatter
from PIL import Image, ImageDraw

import pyxel
import pyxel.gui.demo
from pyxel import Configuration

pn.extension(design="material", sizing_mode="stretch_width")


PYXEL_DEMO_FOLDER = Path(pyxel.gui.demo.__path__[0])

HEIGHT = 500  # Height of the displayed output image, in pixels
WIDTH = 600  # Width of the framed image column, in pixels
TIMEOUT = 800  # Webcam polling interval, in milliseconds

# Human-readable label for each Pyxel data bucket (used in UI and image overlay)
BUCKET_LABELS = {
    "photon": "Photon [ph]",
    "charge": "Charge [e-]",
    "pixel": "Pixel [e-]",
    "signal": "Signal [V]",
    "image": "Image [adu]",
}

# Physical unit string for each Pyxel data bucket (used in image overlay statistics)
BUCKET_UNITS = {
    "photon": "ph",
    "charge": "e-",
    "pixel": "e-",
    "signal": "V",
    "image": "adu",
}


class Characteristics(pn.viewable.Viewer):
    """Panel component exposing the CCD detector's physical characteristics.

    Parameters
    ----------
    full_well_capacity : float
        Maximum number of electrons a pixel can hold before saturation, in e⁻.
        Must be in the range (0, 150 000).
    quantum_efficiency : float
        Fraction of incident photons converted to electrons. Range: (0, 1].
    temperature : float
        Detector operating temperature in Kelvin. Range: (0, 400).
    """

    full_well_capacity = param.Number(
        default=100_000.0,
        bounds=(0, 150_000.0),
        step=1_000,
        inclusive_bounds=(False, False),
        doc="Full Well Capacity",
    )
    quantum_efficiency = param.Number(
        default=0.9,
        bounds=(0.0, 1.0),
        step=0.01,
        doc="Quantum efficiency",
    )
    temperature = param.Number(
        default=173.0,
        bounds=(0.0, 400.0),
        step=1,
        inclusive_bounds=(False, False),
        doc="Detector temperature in Kelvin",
    )

    def __panel__(self):
        """Return a Card widget containing sliders for all characteristics."""
        return pn.Card(
            pn.Param(
                self,
                widgets={
                    "full_well_capacity": {
                        "widget_type": pn.widgets.EditableFloatSlider,
                        "format": PrintfTickFormatter(format="%f e⁻"),
                    },
                    "temperature": {
                        "widget_type": pn.widgets.FloatSlider,
                        "format": PrintfTickFormatter(format="%f K"),
                    },
                },
            ),
            title="Detector parameters",
            styles={"border": "2px solid black", "border_radius": "6px"},
        )


class ModelsParams(pn.viewable.Viewer):
    """Panel component exposing tunable parameters shared across Pyxel models.

    Parameters
    ----------
    multiplier : float
        Scaling factor applied to the photon array produced by ``load_image``.
        A value of 1.0 leaves the photon counts unchanged.
    """

    multiplier = param.Number(
        default=1.0,
        bounds=(0.0, 100.0),
        step=0.1,
        doc="Multiplicative scaling factor applied to the photon array",
    )

    def __panel__(self):
        """Return a Card widget containing a slider for the multiplier."""
        return pn.Card(
            pn.Param(
                self,
                widgets={
                    "multiplier": {
                        "widget_type": pn.widgets.EditableFloatSlider,
                        "name": "Factor for photons",
                    }
                },
            ),
            title="Models Parameters",
            styles={"border": "2px solid green", "border_radius": "8px"},
        )


class PyxelModels(pn.viewable.Viewer):
    """Pyxel pipeline controller and Panel component.

    Loads a Pyxel configuration from ``config.yaml``, applies user-selected
    detector characteristics and optional models (dark current, cosmics,
    DC crosstalk), runs the full pipeline on each webcam frame, and returns
    the resulting data from all pipeline buckets.

    Parameters
    ----------
    characteristics : Characteristics
        Detector physical characteristics (FWC, QE, temperature).
    pyxel_models : list of str or None
        Names of optional models to enable.  Supported values:
        ``"dark_current"``, ``"cosmix"``, ``"dc_crosstalk"``.
    models_params : ModelsParams
        Extra model parameters (e.g. photon multiplier).
    bucket : str
        Name of the Pyxel data bucket to display in the main image panel.
        One of ``"photon"``, ``"charge"``, ``"pixel"``, ``"signal"``, ``"image"``.
    """

    characteristics = param.ClassSelector(
        class_=Characteristics,
        default_factory=Characteristics,
    )
    pyxel_models = param.ListSelector(
        objects=["dark_current", "cosmix", "dc_crosstalk"],
        doc="Pyxel models",
    )
    models_params = param.ClassSelector(
        class_=ModelsParams, default_factory=ModelsParams
    )
    bucket = param.Selector(
        default="image",
        objects=list(BUCKET_LABELS.keys()),
        doc="Pyxel data container to display",
    )

    def __init__(self, **params):
        super().__init__(**params)
        self.view = self.create_view()

        self._config: Configuration = pyxel.load(PYXEL_DEMO_FOLDER / "config.yaml")

    def __panel__(self):
        """Generate Panel's content."""
        return self.view

    # @pn.io.profile("processing")
    def apply(self, image: str) -> dict[str, np.ndarray] | None:
        """Run the Pyxel pipeline on a single webcam frame.

        Configures the pipeline from the current parameter values, injects the
        provided JPEG image as the photon source, executes the pipeline and
        extracts data from every bucket.

        Parameters
        ----------
        image : str
            Base64-encoded JPEG data URL (``data:image/jpeg;base64,...``).

        Returns
        -------
        dict of {str: numpy.ndarray or None}
            Mapping from bucket name to its 2-D array of values, or ``None``
            if the bucket is not available in the current pipeline configuration.
        """
        if not image.startswith("data:image/jpeg"):
            return

        # Enable / disable optional models based on user selection
        self._config.pipeline.charge_generation.dark_current.enabled = (
            self.pyxel_models is not None and "dark_current" in self.pyxel_models
        )
        self._config.pipeline.charge_generation.cosmix.enabled = (
            self.pyxel_models is not None and "cosmix" in self.pyxel_models
        )
        self._config.pipeline.charge_measurement.dc_crosstalk.enabled = (
            self.pyxel_models is not None and "dc_crosstalk" in self.pyxel_models
        )

        # Inject the current frame and multiplier into the photon model
        self._config.pipeline.photon_collection.load_image.arguments.image_file = image
        self._config.pipeline.photon_collection.load_image.arguments.multiplier = (
            self.models_params.multiplier
        )

        # Propagate detector characteristics ---
        self._config.detector.characteristics.full_well_capacity = (
            self.characteristics.full_well_capacity
        )
        self._config.detector.characteristics.quantum_efficiency = (
            self.characteristics.quantum_efficiency
        )
        self._config.detector.environment.temperature = self.characteristics.temperature

        # Execute the pipeline ---
        dt: xr.DataTree = pyxel.run_mode(self._config)

        # Extract the first time step from every bucket; store None if absent
        buckets = {}
        for name in BUCKET_LABELS:
            try:
                buckets[name] = np.array(dt[f"/bucket/{name}"].isel(time=0))
            except Exception:
                buckets[name] = None

        return buckets

    def create_view(self):
        """Build the sidebar control panel for pipeline configuration.

        Returns
        -------
        panel.Column
            A column containing the detector characteristics card,
            the model selection toggle buttons, and the model parameters card.
        """
        model_descriptions = pn.pane.Markdown(
            """
            | Model | Description |
            |---|---|
            | **dark_current** | Thermal electrons generated even without light |
            | **cosmix** | Energetic particle hits (protons) leaving trails on the detector |
            | **dc_crosstalk** | Signal leaking between neighbouring readout channels |
            """,
            sizing_mode="stretch_width",
        )
        return pn.Column(
            self.characteristics,
            pn.Card(
                pn.Param(
                    self,
                    name="",
                    parameters=["pyxel_models"],
                    widgets={"pyxel_models": pn.widgets.CheckButtonGroup},
                ),
                model_descriptions,
                title="Optional Models",
                styles={"border": "2px solid grey", "border_radius": "6px"},
            ),
            self.models_params,
        )


class Timer(pn.viewable.Viewer):
    """Panel component that displays rolling execution-time trend indicators.

    Each named metric is shown as a ``pn.indicators.Trend`` sparkline keeping
    the last 10 measurements.

    Parameters
    ----------
    _trends : dict
        Internal mapping from metric name to its ``Trend`` indicator widget.
    """

    _trends = param.Dict()

    def __init__(self, **params):
        super().__init__()
        self.last_updates: dict[str, float] = {}
        self._trends: dict = {}
        self._layout = pn.Row(**params)

    def time_it(self, name: str, func, *args, **kwargs):
        """Execute *func* and record its wall-clock duration under *name*.

        Parameters
        ----------
        name : str
            Label shown in the trend indicator.
        func : callable
            Function to time.
        *args, **kwargs
            Forwarded to *func*.

        Returns
        -------
        object
            The return value of *func*.
        """
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        self._report(name=name, duration=round(end - start, 2))
        return result

    def inc_it(self, name: str) -> None:
        """Record the elapsed time since the previous call to ``inc_it(name)``.

        Useful for measuring the overall update frequency of a repeating event.

        Parameters
        ----------
        name : str
            Label shown in the trend indicator.
        """
        start = self.last_updates.get(name, time.time())
        end = time.time()
        self._report(name=name, duration=round(end - start, 2))
        self.last_updates[name] = end

    def _report(self, name: str, duration: float) -> None:
        """Create or update the trend indicator for *name*.

        Parameters
        ----------
        name : str
            Metric label.
        duration : float
            Measured duration in seconds.
        """
        if name not in self._trends:
            self._trends[name] = pn.indicators.Trend(
                name=name,
                data={"x": [1], "y": [duration]},
                height=100,
                width=150,
                sizing_mode="fixed",
            )
            self.param.trigger("_trends")
        else:
            trend = self._trends[name]
            next_x = max(trend.data["x"]) + 1
            trend.stream({"x": [next_x], "y": [duration]}, rollover=10)

    @param.depends("_trends")
    def _panel(self):
        self._layout[:] = list(self._trends.values())
        return self._layout

    def __panel__(self):
        """Generate Panel's content."""
        return pn.panel(self._panel)


class WebcamInterface(pn.viewable.Viewer):
    """Main application component: webcam capture → Pyxel pipeline → display.

    Captures JPEG frames from the browser webcam at a configurable interval,
    resizes them to 320x240 pixels, passes them through the Pyxel CCD
    simulation pipeline via :class:`PyxelModels`, and updates:

    * the central image pane with the normalised selected bucket array,
      annotated with per-bucket statistics,
    * a 2x3 matplotlib histogram grid for all available buckets.

    A "Generate code" button in the sidebar exports the current configuration
    to a timestamped sub-folder of ``generated/``.

    Parameters
    ----------
    video_stream : pn.widgets.VideoStream
        Hidden widget that polls the browser webcam.
    model : PyxelModels
        The active Pyxel pipeline controller.
    """

    video_stream = param.ClassSelector(
        class_=pn.widgets.VideoStream,
        constant=True,
        doc="The source VideoStream",
    )
    model = param.Selector(doc="The currently selected model")

    def __init__(self, timeout: int = TIMEOUT, paused: bool = False, **params):
        """Initialise the interface and build all child components.

        Parameters
        ----------
        timeout : int, optional
            Webcam polling interval in milliseconds.
        paused : bool, optional
            If ``True``, the video stream starts paused.
        **params
            Additional keyword arguments forwarded to ``pn.viewable.Viewer``.
        """
        super().__init__(
            video_stream=pn.widgets.VideoStream(
                timeout=timeout,
                paused=paused,
                height=0,
                width=0,
                visible=False,
                format="jpeg",
            ),
            **params,
        )
        self.image = pn.pane.JPG(height=HEIGHT, sizing_mode="stretch_width")
        self._updating = False
        # Raw JPEG bytes of the last resized frame sent to the pipeline
        self._last_image_bytes: bytes | None = None

        self.model = PyxelModels()
        self.timer = Timer(sizing_mode="stretch_width")
        self._save_btn = pn.widgets.Button(
            name="Generate code",
            button_type="success",
            sizing_mode="stretch_width",
        )
        self._save_btn.on_click(self._on_save)
        self.settings = self._create_settings()

        self._mpl_panel: pn.pane.Matplotlib = pn.pane.Matplotlib(
            plt.Figure(figsize=(10, 12)),
            sizing_mode="stretch_both",
        )
        self._panel = self._create_panel()

        # Root folder for exported configurations
        self._generated_folder: Path = Path("generated")

    def _create_settings(self) -> pn.Column:
        """Build the sidebar column (stream controls, timer, model settings, export button).

        Returns
        -------
        panel.Column
        """
        intro = pn.pane.Markdown(
            """
            ## What is Pyxel?
            **Pyxel** is an open-source detector simulation framework developed at ESA.
            It models the full signal chain of imaging detectors (CCD, CMOS, …):

            **Photons** → **Charges** → **Pixels** → **Signal** → **Image**

            Point your webcam at any scene and watch the CCD simulation run live!

            🔗 [esa.gitlab.io/pyxel](https://esa.gitlab.io/pyxel)
            """,
            sizing_mode="stretch_width",
            styles={"background": "#f0f4ff", "border-radius": "6px", "padding": "8px"},
        )
        return pn.Column(
            intro,
            pn.Param(
                self.video_stream,
                parameters=["paused", "timeout"],
                default_layout=pn.Row,
                sizing_mode="stretch_width",
                widgets={
                    "timeout": {
                        "widget_type": pn.widgets.IntSlider,
                        "start": 10,
                        "end": 2000,
                        "step": 10,
                    }
                },
            ),
            self.timer,
            self.model.view,
            self._save_btn,
        )

    def _create_panel(self) -> pn.Row:
        """Build the main content row (framed image + histogram panel).

        Returns
        -------
        panel.Row
        """
        return pn.Row(
            self.video_stream,
            pn.Column(
                # Horizontal bucket selector sits above the image
                pn.Param(
                    self.model,
                    parameters=["bucket"],
                    widgets={
                        "bucket": {
                            "widget_type": pn.widgets.RadioButtonGroup,
                            "button_type": "primary",
                            "button_style": "outline",
                            "orientation": "horizontal",
                            "sizing_mode": "stretch_width",
                        }
                    },
                    show_name=False,
                ),
                self.image,
                pn.pane.HTML(
                    """
                    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@700&display=swap" rel="stylesheet">
                    <div style="text-align:center; font-family:'Orbitron',sans-serif; font-size:2.4rem; letter-spacing:0.15em; color:steelblue;">
                        PyXel
                    </div>
                """
                ),
                width=WIDTH,
                sizing_mode="fixed",
                styles={
                    "border": "3px solid steelblue",
                    "border_radius": "6px",
                    "padding": "8px",
                },
            ),
            self._mpl_panel,
            sizing_mode="stretch_both",
            align="start",
        )

    def __panel__(self):
        """Generate Panel's content."""
        return self._panel

    def _on_save(self, event) -> None:
        """Export the current pipeline configuration and last frame to disk.

        Creates a timestamped sub-folder inside ``self._generated_folder``,
        writes the Pyxel YAML configuration (with ``image_file`` replaced by
        ``image.jpg``) and the last captured JPEG frame.  On macOS the folder
        is opened in Finder automatically.

        Parameters
        ----------
        event : param.parameterized.Event
            Button click event (unused).
        """
        temp_folder = Path(tempfile.mkdtemp(prefix="pyxel"))
        folder = (
            temp_folder
            / self._generated_folder
            / datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        )

        # Serialise config and replace the inline base64 image with a file reference
        yaml_content = self.model._config.to_yaml()
        yaml_content = re.sub(r"image_file:.*", "image_file: image.jpg", yaml_content)

        folder.mkdir(parents=True, exist_ok=True)
        folder.joinpath("config.yaml").write_text(yaml_content)

        shutil.copyfile(
            src=PYXEL_DEMO_FOLDER.joinpath("run_model.py"),
            dst=folder.joinpath("run_model.py"),
        )

        if self._last_image_bytes is not None:
            folder.joinpath("image.jpg").write_bytes(self._last_image_bytes)

        if sys.platform == "darwin":
            os.system(f"open {folder.as_posix()}")

    @param.depends("video_stream.value", watch=True)
    def _handle_stream(self) -> None:
        """React to a new webcam frame and update the display.

        Triggered automatically whenever ``video_stream.value`` changes.
        Decodes the incoming JPEG, resizes it to 320 * 240, runs the Pyxel
        pipeline, overlays statistics on the selected bucket image, and
        redraws the histogram grid.
        """
        if self._updating:
            return

        self._updating = True
        if self.model and self.video_stream.value:
            data_base64: str = self.video_stream.value

            if data_base64.startswith("data:image/jpeg;base64,"):
                # Decode, resize and re-encode the webcam frame
                base64_encoded: str = data_base64.removeprefix(
                    "data:image/jpeg;base64,"
                )
                base64_decoded = base64.b64decode(base64_encoded)

                image = Image.open(io.BytesIO(base64_decoded))
                resized_image = image.resize((320, 240))

                buff = io.BytesIO()
                resized_image.save(buff, format="JPEG")
                self._last_image_bytes = buff.getvalue()
                resized_base64_encoded: bytes = base64.b64encode(self._last_image_bytes)

                try:
                    buckets = self.timer.time_it(
                        name="Model",
                        func=self.model.apply,
                        image=f"data:image/jpeg;base64,{resized_base64_encoded.decode()}",
                    )

                    # Display the selected bucket as a normalised JPEG ---
                    selected = buckets.get(self.model.bucket)
                    if selected is not None:
                        arr = np.asarray(selected, dtype=float)
                        vmax = arr.max()
                        # Normalise to 8-bit for display; avoid division by zero
                        arr_8b = (
                            (arr * 255.0 / vmax).astype(np.uint8)
                            if vmax > 0
                            else arr.astype(np.uint8)
                        )
                        pil_img = PIL.Image.fromarray(arr_8b).convert("RGB")
                        draw = ImageDraw.Draw(pil_img)
                        unit = BUCKET_UNITS[self.model.bucket]
                        text = (
                            f"{BUCKET_LABELS[self.model.bucket]}\n"
                            f"min:  {arr.min():.3f} {unit}\n"
                            f"max:  {arr.max():.3f} {unit}\n"
                            f"mean: {arr.mean():.3f} {unit}"
                        )
                        # Draw a semi-transparent background behind the text
                        x, y = 6, 6
                        bbox = draw.textbbox((x, y), text)
                        pad = 3
                        draw.rectangle(
                            (
                                bbox[0] - pad,
                                bbox[1] - pad,
                                bbox[2] + pad,
                                bbox[3] + pad,
                            ),
                            fill=(0, 0, 0, 180),
                        )
                        draw.text((x, y), text, fill=(255, 255, 0))
                        self.image.object = pil_img

                    # Histograms for all available buckets (2 cols * 3 rows) ---
                    available = {k: v for k, v in buckets.items() if v is not None}
                    ncols, nrows = 2, 3
                    fig = plt.Figure(figsize=(8, 4 * nrows))
                    axes = fig.subplots(nrows=nrows, ncols=ncols)
                    axes_flat = axes.flatten()

                    for ax, (name, data) in zip(axes_flat, available.items()):
                        ax.hist(np.ravel(data), bins=50)
                        ax.set(title=BUCKET_LABELS[name])
                        ax.set_box_aspect(1.0)
                        # Highlight the currently selected bucket
                        if name == self.model.bucket:
                            ax.set_facecolor("#e8f4fd")

                    # Hide any unused subplots in the grid
                    for ax in axes_flat[len(available) :]:
                        ax.set_visible(False)

                    fig.tight_layout()
                    self._mpl_panel.object = fig
                except PIL.UnidentifiedImageError:
                    print("unidentified image")

            self.timer.inc_it("Last Update")
        self._updating = False


# Dry run: warm up the pipeline without a real image to pre-load Pyxel models
try:
    cfg: Configuration = pyxel.load(PYXEL_DEMO_FOLDER / "config.yaml")
    cfg.pipeline.photon_collection.load_image.enabled = False
    _ = pyxel.run_mode(cfg)
except Exception:
    pass

# Build the application layout

component = WebcamInterface()
app = pn.template.FastListTemplate(
    site="Pyxel",
    title="Live CCD Simulation",
    sidebar=[component.settings],
    main=[component],
)

# Enable dual-mode execution
if pn.state.served:
    # Served mode: 'panel serve demo.py'
    app.servable()
elif __name__ == "__main__":
    # Script mode: 'python demo.py'
    app.show(port=5007)
