#  Copyright (c) European Space Agency, 2020.
#
#  This file is subject to the terms and conditions defined in file 'LICENCE.txt', which
#  is part of this Pyxel package. No part of the package, including
#  this file, may be copied, modified, propagated, or distributed except according to
#  the terms contained in the file ‘LICENCE.txt’.
"""Module for focal plane array."""

from dataclasses import dataclass
from typing import TYPE_CHECKING, Union

import numpy as np

from pyxel.detectors import APD, CCD, CMOS, MKID
from pyxel.exposure import Exposure
from pyxel.pipelines import DetectionPipeline, ModelFunction

if TYPE_CHECKING:
    from pyxel.calibration import Calibration
    from pyxel.data_structure import Photon
    from pyxel.observation import Observation


@dataclass
class Position:
    """Position class."""

    x: int
    y: int
    angle: float


@dataclass
class Tile:
    """Tile class."""

    pipeline: DetectionPipeline

    detector: CCD | CMOS | MKID | APD


class Geometry:
    """Geometry class for focal plane array."""

    def __init__(self, focal_plane_array: "FocalPlaneArray"):
        self._fpa = focal_plane_array

    @property
    def row(self):
        det_info: np.ndarray = self._fpa._det_info_summary()
        return self._fpa._get_rows(det_info)

    @property
    def col(self):
        det_info: np.ndarray = self._fpa._det_info_summary()
        return self._fpa._get_columns(det_info)


class FocalPlaneArray:
    """Focal plane array class."""

    def __init__(
        self,
        exposure: Exposure,  # TODO: Add observation and calibration and rename it
        position: dict[int | str, Position],
        scene_generation: list[ModelFunction] | None,
        photon_collection: list[ModelFunction] | None,
        detectors: dict[int | str, Tile],
    ):
        self.exposure = exposure
        self.position = position
        self.scene_generation = scene_generation
        self.photon_collection: list[ModelFunction] | None = photon_collection
        self.detectors = detectors

        self.geometry = Geometry(self)

        self._photon: Photon | None = None

    # @property
    # def photon(self) -> Photon:
    #     """Get the information of detected photon (in ph or ph/nm)."""
    #     if not self._photon:
    #         raise RuntimeError("Photon array is not initialized ! ")
    #     return self._photon
    #
    # @photon.setter
    # def photon(self, obj: ArrayLike | Photon) -> None:
    #     """Set the photon information for the detector."""
    #     if isinstance(obj, Photon):
    #         self._photon = obj
    #     else:
    #         self._photon.array = obj

    def _det_info_summary(self) -> np.ndarray:
        number_of_detectors = len(self.detectors)

        det_info = np.array(
            (
                [self.position[i].x for i in range(1, (number_of_detectors + 1))],
                [self.position[i].y for i in range(1, (number_of_detectors + 1))],
                [self.position[i].angle for i in range(1, (number_of_detectors + 1))],
                [
                    self.detectors[i].detector.geometry.row
                    for i in range(1, (number_of_detectors + 1))
                ],
                [
                    self.detectors[i].detector.geometry.col
                    for i in range(1, (number_of_detectors + 1))
                ],
            )
        )

        angle_for_swap = {90, 270}

        for i in range(len(det_info[2])):
            if det_info[2][i] in angle_for_swap:
                det_info[3][i], det_info[4][i] = det_info[4][i], det_info[3][i]

        return det_info

    def _get_rows(self, det_info: np.ndarray) -> int:
        largest_y_value = max(det_info[1])
        largest_y_indices = [
            i for i, x in enumerate(det_info[1]) if x == largest_y_value
        ]

        largest_values_rot_row = [det_info[3][i] for i in largest_y_indices]

        idx_compare_row = (largest_y_indices, largest_values_rot_row)
        idx_compare_row_transpose = np.swapaxes(idx_compare_row, 0, 1)

        find_idx_fpa_row = np.argmax(idx_compare_row_transpose[:, 1])
        final_idx_fpa_row = idx_compare_row_transpose[find_idx_fpa_row][0]
        det_idx_fpa_row = final_idx_fpa_row + 1

        # fpa_row = (det_info[1][det_idx_fpa_row - 1]) + (
        #     (det_info[3][det_idx_fpa_row - 1]) - 1
        # )

        fpa_row = (det_info[1][det_idx_fpa_row - 1]) + (
            det_info[3][det_idx_fpa_row - 1]
        )

        return int(fpa_row)

    def _get_columns(self, det_info) -> int:
        largest_x_value = max(det_info[0])
        largest_x_indices = [
            i for i, x in enumerate(det_info[0]) if x == largest_x_value
        ]

        largest_values_rot_col = [det_info[4][i] for i in largest_x_indices]

        idx_compare_col = (largest_x_indices, largest_values_rot_col)
        idx_compare_col_transpose = np.swapaxes(idx_compare_col, 0, 1)

        find_idx_fpa_col = np.argmax(idx_compare_col_transpose[:, 1])
        final_idx_fpa_col = idx_compare_col_transpose[find_idx_fpa_col][0]
        det_idx_fpa_col = final_idx_fpa_col + 1

        # fpa_col = (det_info[0][det_idx_fpa_col - 1]) + (
        #     (det_info[4][det_idx_fpa_col - 1]) - 1
        # )

        fpa_col = (det_info[0][det_idx_fpa_col - 1]) + (
            det_info[4][det_idx_fpa_col - 1]
        )

        return int(fpa_col)

    @property
    def running_mode(self) -> Union[Exposure, "Observation", "Calibration"]:
        raise NotImplementedError

    def to_yaml(self) -> str:
        raise NotImplementedError

    @property
    def header(self):
        raise NotImplementedError

    @property
    def photon(self):
        raise NotImplementedError

    @property
    def time_step(self):
        raise NotImplementedError

    @property
    def characteristics(self):
        raise NotImplementedError
