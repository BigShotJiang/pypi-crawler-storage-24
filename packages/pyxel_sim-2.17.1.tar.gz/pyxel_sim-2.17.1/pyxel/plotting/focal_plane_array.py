#  Copyright (c) European Space Agency, 2020.
#
#  This file is subject to the terms and conditions defined in file 'LICENCE.txt', which
#  is part of this Pyxel package. No part of the package, including
#  this file, may be copied, modified, propagated, or distributed except according to
#  the terms contained in the file 'LICENCE.txt'.

"""Visualization of focal plane arrays with matplotlib.

This module provides functions to create matplotlib figures representing
a :class:`~pyxel.focal_plane_array.FocalPlaneArray`, showing the spatial
arrangement and orientation of detector tiles on the focal plane.

Examples
--------
Plot from a loaded focal plane array:

>>> import pyxel
>>> from pyxel.plotting.focal_plane_array import plot_focal_plane_array
>>> fpa = pyxel.load("focal_plane_array.yaml")
>>> fig = plot_focal_plane_array(fpa, figsize=(8, 8))
>>> fig.savefig("fpa_layout.png")
"""

import matplotlib.pyplot as plt
import mpl_toolkits.axisartist.floating_axes as floating_axes
import numpy as np
from matplotlib.ticker import MultipleLocator
from matplotlib.transforms import Affine2D
from mpl_toolkits.axisartist.grid_finder import MaxNLocator

from pyxel.focal_plane_array import FocalPlaneArray


def _create_focal_plane_figure(
    figsize: tuple[int, int] = (5, 5),
    ylim: tuple[int, int] = (0, 100),
    xlim: tuple[int, int] = (0, 100),
    num_x_major_locator: int = 10,
    num_y_major_locator: int = 10,
    num_x_minor_locator: int = 5,
    num_y_minor_locator: int = 5,
    origin: tuple[int, int] = (0, 0),
) -> tuple[plt.Figure, plt.Axes]:
    """Create a new Matplotlib figure and axis for a focal plane array.

    Sets up a matplotlib axis to display a focal plane array with gridlines,
    axis labels, and origin markers. Customizes tick locators for major and
    minor grid divisions along both axes.

    Parameters
    ----------
    figsize : tuple[int, int], optional
        Figure size as (width, height) in inches. Default is (5, 5).
    ylim : tuple[int, int], optional
        Y-axis limits as (min, max). Default is (0, 100).
    xlim : tuple[int, int], optional
        X-axis limits as (min, max). Default is (0, 100).
    num_x_major_locator : int, optional
        Number of major tick divisions along X-axis. Default is 10.
    num_y_major_locator : int, optional
        Number of major tick divisions along Y-axis. Default is 10.
    num_x_minor_locator : int, optional
        Number of minor tick divisions between major ticks on X-axis. Default is 5.
    num_y_minor_locator : int, optional
        Number of minor tick divisions between major ticks on Y-axis. Default is 5.
    origin : tuple[int, int], optional
        Origin coordinates as (y, x) for the focal plane center. Default is (0, 0).

    Examples
    --------
    Create a focal plane visualization and add detectors:

    >>> fig, ax = _create_focal_plane_figure(figsize=(8, 8), xlim=(-200, 200))
    >>> detector1 = _add_detector(fig, ax, name="Det1", center=(0, 50), size=(50, 50))
    >>> detector2 = _add_detector(fig, ax, name="Det2", center=(0, -50), size=(50, 50))
    >>> plt.show()
    """
    fig, ax = plt.subplots(nrows=1, ncols=1, figsize=figsize)

    unit: str = "pixel"

    # Extract axis limits
    y_min, y_max = ylim
    x_min, x_max = xlim

    # Calculate total size of each axis for tick spacing calculations
    y_size = y_max - y_min
    x_size = x_max - x_min

    # Configure axis appearance and limits
    ax.set(
        xlim=xlim,
        ylim=ylim,
        aspect=1.0,  # TODO: Change the aspect ration ?
        xlabel=f"X [{unit}]",
        ylabel=f"Y [{unit}]",
    )

    # Add dashed grid lines for reference
    ax.grid(linewidth=0.75, linestyle="--")

    # Configure X-axis tick locators for major and minor divisions
    major_x_interval = max(x_size // num_x_major_locator, 1)
    minor_x_interval = max(major_x_interval // num_x_minor_locator, 1)
    ax.xaxis.set(
        major_locator=MultipleLocator(major_x_interval),
        minor_locator=MultipleLocator(minor_x_interval),
    )

    # Configure Y-axis tick locators for major and minor divisions
    major_y_interval = max(y_size // num_y_major_locator, 1)
    minor_y_interval = max(major_y_interval // num_y_minor_locator, 1)
    ax.yaxis.set(
        major_locator=MultipleLocator(major_y_interval),
        minor_locator=MultipleLocator(minor_y_interval),
    )

    # Hide axis spines for a cleaner appearance
    for spine in ax.spines.values():
        spine.set_visible(False)

    # Add origin crosshairs using annotated arrows
    origin_y, origin_x = origin

    # Vertical arrow pointing upward from origin
    ax.annotate(
        "",
        xy=(origin_x, y_max),
        xytext=(origin_x, origin_y),
        arrowprops={"arrowstyle": "->", "linewidth": 1.5},
    )

    # Horizontal arrow pointing rightward from origin
    ax.annotate(
        "",
        xy=(x_max, origin_y),
        xytext=(origin_x, origin_y),
        arrowprops={"arrowstyle": "->", "linewidth": 1.5},
    )

    # Plot origin point as a small black dot
    ax.scatter([origin_x], [origin_y], s=10 * 2, facecolor="black", edgecolor="None")

    return fig, ax


def _to_normalized_figure_coords(
    fig: plt.Figure,
    fpa_ax: plt.Axes,
    data_coord: tuple[float, float],
) -> np.ndarray:
    """Convert data coordinates to normalized figure coordinates.

    Transforms a point from the focal plane axis data coordinate system to the
    normalized figure coordinate system.

    Parameters
    ----------
    fig : plt.Figure
        The matplotlib figure containing the focal plane axis.
    fpa_ax : plt.Axes
        The focal plane array axis from which to transform coordinates.
    data_coord : tuple[float, float]
        A point in data coordinates as (x, y).

    Returns
    -------
    np.ndarray
        A 2-element array containing the normalized figure coordinates as [x, y],
        where values range from 0 to 1.

    Examples
    --------
    >>> fig, ax = _create_focal_plane_figure(xlim=(0, 100), ylim=(0, 100))
    >>> data_point = (50, 50)  # Center of focal plane
    >>> norm_coords = _to_normalized_figure_coords(fig, ax, data_point)
    >>> print(norm_coords)
    [0.5, 0.5]
    """
    # Transform from data coordinates to figure coordinates
    figure_coord = fpa_ax.transData.transform(data_coord)

    # Transform from figure coordinates to normalized figure coordinates (0-1 range)
    normalized_figure_coord = fig.transFigure.inverted().transform(figure_coord)

    return normalized_figure_coord


def _add_detector(
    fig: plt.Figure,
    fpa_ax: plt.Axes,
    name: str,
    # center: tuple[int, int],
    size: tuple[int, int],
    x: int,
    y: int,
    rotated_rows: int,
    rotated_cols: int,
    orientation: float = 0,
) -> plt.Axes:
    """Create a new detector subplot positioned and rotated within the focal plane.

    Adds a floating detector subplot to an existing focal plane figure. The detector
    is positioned at the specified center coordinates with custom rotation and size.
    Each detector displays its own coordinate system with origin crosshairs and labels.

    Parameters
    ----------
    fig : plt.Figure
        The matplotlib figure containing the focal plane axis.
    fpa_ax : plt.Axes
        The focal plane array axis where the detector will be positioned.
    name : str
        Label/identifier for the detector (e.g., "Det1", "CCD-A"). Displayed at the
        detector center.
    center : tuple[int, int]
        Center position (y, x) of the detector in focal plane coordinates.
        This defines where the detector is located on the focal plane.
    size : tuple[int, int]
        Detector dimensions as (height, width) in pixels.
    orientation : float, optional
        Rotation angle in degrees (counter-clockwise). Default is 0 (no rotation).

    Returns
    -------
    plt.Axes
        The configured detector axis.
    """

    # Convert data coordinates (DC) to normalized figure coordinates (NFC)
    # data_to_display = fpa_ax.transData.transform
    # display_to_figure = fig.transFigure.inverted().transform
    # data_to_figure = lambda x: display_to_figure(data_to_display(x))

    size_x, size_y = size

    # See: https://matplotlib.org/stable/gallery/axisartist/demo_floating_axes.html
    # Create corners of a normalized detector rectangle centered at origin
    # detector_corners = (
    #     np.array(size)
    #     / 2
    #     * np.array([(-1, -1), (+1, -1), (+1, +1), (-1, +1), (-1, -1)])
    # )

    # # Apply rotation transformation to detector corners
    # rotation = Affine2D().rotate_deg(orientation)
    # rotated_detectors = np.array(center) + rotation.transform(detector_corners)
    rotated_detectors = np.array(
        [
            [x, y],
            [x + rotated_cols, y],
            [x + rotated_cols, y + rotated_rows],
            [x, y + rotated_rows],
            [x, y],
        ]
    )

    # Calculate bounding box of rotated detector in normalized figure coordinates
    xmin, ymin = _to_normalized_figure_coords(
        fig=fig,
        fpa_ax=fpa_ax,
        data_coord=(rotated_detectors[:, 0].min(), rotated_detectors[:, 1].min()),
    )
    xmax, ymax = _to_normalized_figure_coords(
        fig=fig,
        fpa_ax=fpa_ax,
        data_coord=(rotated_detectors[:, 0].max(), rotated_detectors[:, 1].max()),
    )

    # Create coordinate transformation for the floating subplot
    transform = Affine2D().scale(1, 1).rotate_deg(orientation)
    helper = floating_axes.GridHelperCurveLinear(
        transform,
        extremes=(0, size_y, 0, size_x),
        grid_locator1=MaxNLocator(nbins=10),
        grid_locator2=MaxNLocator(nbins=10),
    )

    # Create floating subplot at the detector location
    ax_detector = floating_axes.FloatingSubplot(
        fig,
        111,
        grid_helper=helper,
        zorder=0,
    )

    # Position the detector axis within the figure
    ax_detector.set_position((xmin, ymin, xmax - xmin, ymax - ymin))

    # Configure axis visibility (show ticks but hide labels)
    ax_detector.axis["bottom"].major_ticks.set_tick_out(True)
    ax_detector.axis["bottom"].major_ticklabels.set_visible(False)
    ax_detector.axis["top"].major_ticks.set_visible(False)
    ax_detector.axis["left"].major_ticks.set_tick_out(True)
    ax_detector.axis["left"].major_ticklabels.set_visible(False)
    ax_detector.axis["right"].major_ticks.set_visible(False)

    # Make the axis background transparent to show underlying image
    ax_detector.patch.set_visible(False)

    # Get auxiliary axis for rotated coordinate system
    aux = ax_detector.get_aux_axes(transform)

    # Add axis labels (X, Y) with rotation
    aux.text(
        size_y / 2,
        0,
        "X",
        horizontalalignment="left",
        verticalalignment="top",
        size=10,
        rotation=orientation,
        rotation_mode="default",
    )
    aux.text(
        0,
        size_x / 2,
        "Y",
        horizontalalignment="right",
        verticalalignment="top",
        size=10,
        rotation=orientation,
        rotation_mode="default",
    )

    # Add detector name label at center
    aux.text(
        size_y / 2,
        size_x / 2,
        name,
        horizontalalignment="center",
        verticalalignment="center",
        size=10,
        rotation=orientation,
        rotation_mode="default",
    )

    # Add origin crosshairs for detector coordinate system
    # X-axis arrow (horizontal)
    aux.annotate(
        text="",
        xy=(size_y, 0),
        xytext=(0, 0),
        arrowprops={"arrowstyle": "->", "linewidth": 1.5, "color": "brown"},
    )

    # Y-axis arrow (vertical, 30 pixels)
    aux.annotate(
        text="",
        xy=(0, 30),
        xytext=(0, 0),
        arrowprops={"arrowstyle": "->", "linewidth": 1.5, "color": "brown"},
    )

    # Plot detector origin point as a small black dot
    aux.scatter([0], [0], s=10 * 2, facecolor="black", edgecolor="None")

    fig.add_subplot(ax_detector)

    return ax_detector


def plot_focal_plane_array(
    fpa: FocalPlaneArray,
    figsize: tuple[int, int] = (5, 5),
) -> plt.Figure:
    """Visualize a focal plane array with all its detectors.

    Creates a comprehensive matplotlib visualization of a focal plane array showing
    the spatial arrangement and orientation of all detectors within the focal plane.
    Each detector is rendered as a sub-axis with its own coordinate system, allowing
    clear visualization of detector positions, sizes, and orientations.

    Parameters
    ----------
    fpa : FocalPlaneArray
        The focal plane array object containing detector definitions, geometries,
        positions, and orientations. Must have:
        - `geometry` attribute with `col` (width) and `row` (height) properties
        - `position` dict mapping detector keys to position objects with `x`, `y`,
          and `angle` attributes
        - `detectors` dict mapping detector keys to detector objects with geometry info
    figsize : tuple[int, int], optional
        Figure size as (width, height) in inches. Default is (5, 5).
        Larger sizes provide more detail and are recommended for complex focal planes
        with many detectors.

    Returns
    -------
    plt.Figure
        A matplotlib Figure object containing the focal plane visualization.
    """
    # Extract focal plane geometry dimensions
    # fpa_num_cols, fpa_num_rows = fpa.geometry.col, fpa.geometry.row
    fpa_num_cols, fpa_num_rows = 7, 7

    # Create base focal plane figure with appropriate scale
    # The figure dimensions span from (0,0) to (num_cols, num_rows) in pixel coordinates
    fig, fpa_ax = _create_focal_plane_figure(
        figsize=figsize,
        ylim=(0, fpa_num_rows),
        xlim=(0, fpa_num_cols),
        origin=(0, 0),
    )

    det_info_summary = fpa._det_info_summary()
    detector_id = 0

    # Iterate through all detectors in the focal plane array and add them to the figure
    for detector_key, detector_position in fpa.position.items():
        x, y, _angle, rotated_rows, rotated_cols = det_info_summary[:, detector_id]
        detector_id = detector_id + 1

        # Retrieve the detector geometry (size in pixels)
        detector_geometry = fpa.detectors[detector_key].detector.geometry

        # Add the detector as a floating subplot positioned at its location
        # with its specified size and orientation
        _ = _add_detector(
            fig,
            fpa_ax=fpa_ax,
            name=str(detector_key),
            # center=(
            #     (detector_position.y + (detector_geometry.row / 2)),
            #     (detector_position.x + (detector_geometry.col / 2)),
            # ),
            size=(detector_geometry.row, detector_geometry.col),
            x=x,
            y=y,
            rotated_rows=rotated_rows,
            rotated_cols=rotated_cols,
            orientation=detector_position.angle,
        )

    return fig
