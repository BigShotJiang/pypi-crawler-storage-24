# -*- coding: utf-8 -*-
# project/dreamtools-dreamgeeker/image_manager.py
_all_ = ['ImageManager', 'TYPE_IMG_JPEG', 'TYPE_IMG_PNG', 'TYPE_IMG_GIF', 'TYPE_IMG_WEBP', 'TYPE_MIME','TYPE_IMG_SVG']

import copy
import os
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageFile, ImageDraw
from PIL.ExifTags import TAGS
from PIL.TiffImagePlugin import ImageFileDirectory_v2

from . import file_manager
from .controller_manager import ControllerEngine
from .tracking_manager import TrackingManager
import cv2
import numpy as np

TYPE_IMG_JPEG = 'JPEG'
TYPE_IMG_PNG = 'PNG'
TYPE_IMG_GIF = 'GIF'
TYPE_IMG_WEBP = 'WEBP'
TYPE_IMG_SVG = "SVG"
TYPE_MIME = {
    TYPE_IMG_JPEG: "image/jpeg",
    TYPE_IMG_PNG: "image/png",
    TYPE_IMG_WEBP: "image/webp",
    TYPE_IMG_GIF: "image/gif"
}
"""
Class CImagine
=============================

Class permettant le traitement d'une image png convertit en jpg avec prise en charge de la transparence (fond blanc)


pathfile : dreamtools-dreamgeeker/pyimaging

"""

MAX_SIZE = 640
MIN_SIZE = 200


class ImageManager(object):
    size_max: int
    size_thumb_max: int

    def __init__(self, src, dest, size_max=MAX_SIZE, size_thumb_max=MIN_SIZE):
        """
        Preparation image  pour traitement
        ==================================
        Les images sont convertit au format JPEG

        :param int size_max: taille maximum d'une image
        :param int size_thumb_max: taille miniature et minimum

        """
        # Chargement image
        if isinstance(src, (bytes, bytearray)):
            self.img = Image.open(BytesIO(src))
            self.extension = self.img.format.upper()

        elif isinstance(src, Path):
            self.extension = src.suffix.replace('.', '').upper()
            self.img = Image.open(src)

        else:
            self.extension = file_manager.file_extension(src).upper()
            self.img = Image.open(src)

        if self.extension == "JPG":
            self.extension = TYPE_IMG_JPEG

        if self.extension not in [TYPE_IMG_JPEG, TYPE_IMG_PNG, TYPE_IMG_GIF, TYPE_IMG_WEBP]:
            raise ValueError("Format image non supporté")

        self.size_max = size_max
        self.size_thumb_max = size_thumb_max

        self.exif = None

        self._size = self.img.size
        self._format = (self.img.format or self.extension).lower()

        self.file = file_manager.file_extension_less(dest)  # on s'assure de retirer l'extension

        if self.img.mode not in ("RGB", "RGBA"):
            self.img = self.img.convert("RGBA")

        self.resize()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        try:
            self.img.close()
        except Exception:
            pass

    @property
    def _size(self):
        return self.w, self.h

    @_size.setter
    def _size(self, s):
        self.w, self.h = s

    def image_to_rgb(self):
        if self.img.mode != 'RGB':
            self.img = self.img.convert('RGB')
            self.extension = TYPE_IMG_JPEG

    def white_background(self):
        """
        Retourne l'image avec un fond blanc appliqué si l'image comporte de la transparence.
        :return: PIL.Image avec fond blanc
        """

        # Si l'image a un canal alpha (RGBA), on l’utilise comme masque
        if self.img.mode in ("RGBA", "LA"):
            bg = Image.new("RGB", self._size, (255, 255, 255))
            bg.paste(self.img, (0, 0), self.img)
            return bg

        if self.img.mode != "RGB":
            return self.img.convert("RGB")

        return self.img

    def redraw_border(self, shape="rect", wc=False):
        """
            fs = '/home/dreamgeeker/Images/2151910934.jpg'
            fs_out = '/home/dreamgeeker/Images/tests.jpg'

            imager = ImageManager(fs, fs_out.format('circ'))
            imager.img = imager.redraw_border('circ')
            imager.save('png')
            imager = ImageManager(fs, fs_out.format('circ_border'))
            imager.img = imager.redraw_border('circ', True)
            imager.save('png')"""

        padding = 5 if wc else 0
        diameter = 2 * padding
        box = (self.img.width + diameter, self.img.height + diameter)

        if shape == "rect":
            bg = Image.new("RGB", box, (255, 255, 255))
            bg.paste(self.white_background(), (padding, padding))
        else:  # shape == "circ":
            self.img = self.img.convert("RGBA")
            bg = Image.new("RGBA", box, (0, 0, 0, 0))
            if wc:
                draw = ImageDraw.Draw(bg)
                draw.ellipse((0, 0, box[0], box[1]), fill=(255, 255, 255, 255))

            # Masque circulaire
            mask = Image.new("L", self.img.size, 0)
            draw = ImageDraw.Draw(mask)
            draw.ellipse((0, 0, self.img.width, self.img.height), fill=255)

            pos_x = padding
            pos_y = padding

            # Coller l'image sur le cercle blanc au centre
            bg.paste(self.img, (pos_x, pos_y), mask)

        return bg

    def resize(self, width: int = None, height: int = None):
        """
        Redimensionne l'image en conservant le ratio.

        - Si width et height fournis → cover automatique
        - Si width ou height seul → resize proportionnel
        - Si aucun → resize selon size_max
        """

        # Cas cover : les deux dimensions fournies
        if width and height:
            self.cover(width, height)
            return

        # Calcul proportionnel selon width ou height
        if width:
            # Si l'image est déjà plus petite ou égale → rien à faire
            if self.w <= width:
                width = self.w
                height = self.h
            else:
                ratio = width / self.w
                height = int(self.h * ratio)

        elif height:
            if self.h <= height:
                width = self.w
                height = self.h
            else:
                ratio = height / self.h
                width = int(self.w * ratio)

        else:
            # Limiter selon size_max
            if max(self.w, self.h) <= self.size_max:
                width, height = self.w, self.h
            else:
                coeff = max(self.w, self.h) / self.size_max
                width = int(self.w / coeff)
                height = int(self.h / coeff)

        # Si aucune modification → ne rien faire
        if (width, height) == self.img.size:
            return

        # Convertir en RGB ou RGBA si nécessaire
        if self.img.mode not in ("RGB", "RGBA"):
            self.img = self.img.convert("RGB")

        # Redimensionnement progressif
        self.img = self.resize_progressive(self.img, width, height)

        self._size = self.img.size
    def resize_progressive(self,img, target_width, target_height):
        w, h = img.size
        while w/2 > target_width and h/2 > target_height:
            w, h = w//2, h//2
            img = img.resize((w, h), Image.Resampling.LANCZOS)
        img = img.resize((target_width, target_height), Image.Resampling.LANCZOS)
        return img

    def recadre(self, w, h):
        """"""
        for coeff in range(2, 11):
            if w % coeff == 0 and h % coeff == 0:
                w //= coeff
                h //= coeff
                w, h = self.recadre(w, h)
                break

        return w, h

    def detect_face_focus(self):
        # conversion PIL → OpenCV
        img_cv = cv2.cvtColor(np.array(self.img), cv2.COLOR_RGB2BGR)

        gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)

        face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        )

        faces = face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.2,
            minNeighbors=5,
            minSize=(30, 30)
        )

        if len(faces) == 0:
            return 0.5, 0.4  # fallback (légèrement haut)

        # prendre le plus grand visage
        x, y, w, h = max(faces, key=lambda f: f[2] * f[3])

        center_x = x + w / 2
        center_y = y + h / 2

        # normalisation (0 → 1)
        focus_x = center_x / self.w
        focus_y = center_y / self.h

        return focus_x, focus_y
    def cover(self, width: int, height: int, focus_x=0.5, focus_y=0.5):
        """
        Redimensionne l'image pour couvrir entièrement la zone demandée
        puis recadre au centre. Qualité maximale.
        """

        ratio = max(width / self.w, height / self.h)

        new_w = int(self.w * ratio)
        new_h = int(self.h * ratio)

        focus_y = 0.35 if self.h > self.w else 0.5

        # resize haute qualité
        img = self.img.resize((new_w, new_h), Image.Resampling.LANCZOS)

        # crop centré
        left = (new_w - width) // 2
        top = (new_h - height) // 2

        # position du focus dans l'image redimensionnée
        focus_px = int(new_w * focus_x)
        focus_py = int(new_h * focus_y)

        # calcul du crop autour du focus
        left = max(0, min(focus_px - width // 2, new_w - width))
        top = max(0, min(focus_py - height // 2, new_h - height))

        self.img = img.crop((left, top, left + width, top + height))

        self._size = self.img.size

    def rationalize(self, r_w: int, r_h: int):
        """ Redimensionnement de l'image au format jpg"""
        w = self.w
        h = w * r_h // r_w

        self.img = self.img.resize((w, h), Image.Resampling.LANCZOS)

        self._size = self.img.size

    def save(self, frm: str | None = None):
        """ Thumb Image
        :param frm:
        """

        frm = frm.lower() if frm else self._format
        file_name = self.file + '.' + frm
        frm = frm.upper()

        # certaines conversions nécessitent convert()
        if frm == 'JPEG' and self.img.mode in ('RGBA', 'LA'):
            # JPEG ne supporte pas alpha → convertir en RGB
            background = Image.new("RGB", self.img.size, (255, 255, 255))
            background.paste(self.img, mask=self.img.split()[-1])  # utiliser l'alpha comme masque
            self.img = background

        file_manager.makedirs(file_manager.parent_directory(file_name))

        if frm == TYPE_IMG_PNG and self.exif:
            self.img.save(file_name, exif=self.exif,  compress_level=6, optimize=True)
        else:
            self.img.save(file_name, format=frm, quality=90, optimize=True)
    def generate_bytes(self, q=90):
        buffer = BytesIO()
        fmt = "JPEG" if self.extension in ("JPG", "JPEG") else self.extension
        self.img.save(buffer, format=fmt, quality=q, optimize=True, subsampling=0)

        data = buffer.getvalue()
        mime = TYPE_MIME.get(self.extension, TYPE_IMG_JPEG)
        return mime, data

    def generate_thumb(self):
        """ Thumb Image       """
        path_file = ''
        if not path_file:
            for ext in ('.jpg', '.jpeg', '.png', '.svg', '.webp', ''):
                if Path(self.file + ext).exists():
                    return ImageManager(self.file + ext, self.file + "_thumb", self.size_thumb_max, self.size_thumb_max)
                    break
        path_file = getattr(self.img, 'filename', 'None')
        if path_file and Path(path_file).exists():
            return ImageManager(path_file, self.file + "_thumb", self.size_thumb_max, self.size_thumb_max)


    def save_thumb_image(self, frm: str = TYPE_IMG_JPEG):
        """ Thumb Image
        """
        thumb =  self.generate_thumb()
        thumb.save(frm=frm)

    def to_badge(self):
        """Redimensionnement de l'image

        :return:
        """
        thumb = copy.deepcopy(self)
        thumb.img = thumb.redraw_border('circ', wc=True)
        thumb.img.thumbnail((64, 64))
        thumb.file += "_ico"

        return thumb

    def save_image_jpeg(self):
        self.image_to_rgb()
        self.save(frm=TYPE_IMG_JPEG)

    def protected(self, artist, description):
        """Ajoute un nom d'artist et le copyright d'une image"""

        _TAGS_r = dict(((v, k) for k, v in TAGS.items()))

        # Image File Directory
        ifd = ImageFileDirectory_v2()
        ifd[_TAGS_r["Artist"]] = artist
        ifd[_TAGS_r["Copyright"]] = 'Tous droits réservés'
        ifd[_TAGS_r["Description"]] = description

        out = BytesIO()
        ifd.save(out)

        self.exif = b"Exif\x00\x00" + out.getvalue()
        self.save(frm=TYPE_IMG_JPEG)

    @staticmethod
    def directory_parsing(main_directory: str):
        """
        Redimensionne toutes les images contenu dans un répertoire donné + thumb
        :param main_directory:
        """
        for f in os.listdir(main_directory):
            f_path = os.path.join(main_directory, f)
            if os.path.isfile(f_path):
                imager = ImageManager(f_path, f_path)
                imager.save()
                imager.save_thumb_image()

    @staticmethod
    def treat_uploading(fs, fp):
        """
        Enregistrement d'une image uploaded (byte)

        :param file fs: filestream from flask request
        :param str fp: filepath d'enregistrement
        :return:
        """
        import uuid

        tmp = uuid.uuid1().int >> 64
        tmp_image = file_manager.path_build(ControllerEngine.TMP_DIR, str(tmp))

        try:
            TrackingManager.flag(f'[imgrecorder] Image temp recording : {tmp}')
            fs.save(tmp_image)

            TrackingManager.flag(f'[imgrecorder] Image treatment: {tmp} | {fp}')
            o = ImageManager(tmp_image, fp)
            o.save()

            TrackingManager.flag('[imgrecorder] Image thumbing')
            o.save_thumb_image()

            file_manager.remove_file(tmp_image)

            return True
        except Exception as e:
            TrackingManager.exception_tracking(e, '[imgrecorder] Aïe')
            return False

    @staticmethod
    def get_file_size(i_p):
        """

        :param i_p: image_path
        :return:
        """
        size_bytes = None
        try:
            # Obtenir la taille du fichier image en octets
            size_bytes = os.path.getsize(i_p)
        finally:
            return size_bytes  # Retourne None si la taille ne peut pas être obtenue
