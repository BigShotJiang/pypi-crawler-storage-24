"""Pacote de rotas do DenAI."""

from .chat import router as chat_router
from .conversations import router as conversations_router
from .memories import router as memories_router
from .models import router as models_router
from .plans import router as plans_router
from .plugins import router as plugins_router
from .questions import router as questions_router
from .rag import router as rag_router
from .ui import router as ui_router

all_routers = [
    ui_router,
    chat_router,
    conversations_router,
    models_router,
    memories_router,
    plans_router,
    plugins_router,
    rag_router,
    questions_router,
]

__all__ = ["all_routers"]
