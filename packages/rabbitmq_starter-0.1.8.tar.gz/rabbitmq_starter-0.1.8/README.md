## Flask中使用案例

一、.env 配置文件
```python
RABBITMQ_HOST=192.168.0.177
RABBITMQ_PORT=5672
RABBITMQ_USER_NAME=admin
RABBITMQ_PASS_WORD=LdeZYqzS809VbQfV
```

二、main.py
````python
import logging
import time

from flask import Flask

from rabbitmq_starter import MQProducer, mq_listener

app = Flask(__name__)

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')


@mq_listener("order_queue")
def handle_order(data):
    # raise Exception("handle_order")
    logging.info(f"process order_queue1,data:{data}")


@mq_listener("order_queue_delay")
def order_queue_delay(data):
    # raise Exception("order_queue_delay")
    logging.info(f"process order_queue_delay,data:{data},time:{time.time()}")


@app.route("/")
def hello():
    return "Hello Flask"


@app.route("/send_msg")
def send_msg():
    MQProducer.send(
        "order_queue",
        {"order_id": 1}
    )
    return "send_msg"


@app.route("/send_delay_msg")
def send_delay_msg():
    MQProducer.send_delay(
        "order_queue_delay",
        {"order_id": 3},
        10000
    )
    return "send_delay_msg"
````