import yaml
import re
import base64
import mimetypes
from pathlib import Path
from typing import Dict, Tuple, Any, Optional

FRONTMATTER_REGEX = re.compile(r"^---\n(.*?)\n---\n?(.*)", re.DOTALL)

VALID_VISIBILITY = ('public', 'private')
VALID_OUTPUT_TYPES = ('text', 'image', 'audio')

# Limites (espelham os do backend)
MAX_SLUG_LENGTH = 100
MAX_TITLE_LENGTH = 200
MAX_SHORT_DESCRIPTION_LENGTH = 500
MAX_FILE_SIZE_MB = 10
MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024


def parse_prompt_file(file_path: Path) -> Dict[str, Any]:
    """
    Parses a markdown prompt file with YAML frontmatter.

    Expected format:
    ---
    slug: my-prompt
    title: My Prompt Title
    version: 1.0.0
    description: Short description (max 500 chars)
    long_description: |
      Longer description in markdown...
    tags:
      - tag1
    visibility: public        # public | private
    content_hidden: false
    output_type: text         # text | image | audio
    area: Copywriting
    language: pt-br           # auto-detected if omitted
    files:
      - path: assets/cover.png
        is_public: true
    system_prompt: |
      System context...
    config: {}
    ---

    User template content...
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    match = FRONTMATTER_REGEX.match(content)
    if not match:
        raise ValueError(f"File {file_path} is missing valid YAML frontmatter (--- delimiters).")

    yaml_block = match.group(1)
    body = match.group(2).strip()

    try:
        metadata = yaml.safe_load(yaml_block) or {}
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in {file_path}: {e}")

    # Slug: fallback to filename stem
    if 'slug' not in metadata or not metadata['slug']:
        metadata['slug'] = file_path.stem

    # Validate slug length
    slug = str(metadata['slug'])
    if len(slug) > MAX_SLUG_LENGTH:
        raise ValueError(f"Slug '{slug}' exceeds {MAX_SLUG_LENGTH} characters.")

    # Validate title length
    title = metadata.get('title', '')
    if title and len(str(title)) > MAX_TITLE_LENGTH:
        raise ValueError(f"Title in {file_path} exceeds {MAX_TITLE_LENGTH} characters.")

    # Validate short description length
    description = metadata.get('description', '')
    if description and len(str(description)) > MAX_SHORT_DESCRIPTION_LENGTH:
        raise ValueError(
            f"Description in {file_path} exceeds {MAX_SHORT_DESCRIPTION_LENGTH} characters. "
            f"Use 'long_description' for longer content."
        )

    # Validate and normalize visibility
    visibility = metadata.get('visibility', 'private')
    if visibility not in VALID_VISIBILITY:
        raise ValueError(
            f"Invalid visibility '{visibility}' in {file_path}. "
            f"Must be one of: {', '.join(VALID_VISIBILITY)}"
        )

    # Validate output_type
    output_type = metadata.get('output_type', 'text')
    if output_type not in VALID_OUTPUT_TYPES:
        raise ValueError(
            f"Invalid output_type '{output_type}' in {file_path}. "
            f"Must be one of: {', '.join(VALID_OUTPUT_TYPES)}"
        )

    # Validate files list
    files = metadata.get('files', [])
    if files:
        if not isinstance(files, list):
            raise ValueError(f"'files' in {file_path} must be a list.")
        for f_entry in files:
            if not isinstance(f_entry, dict) or 'path' not in f_entry:
                raise ValueError(
                    f"Each entry in 'files' must have a 'path' key. Got: {f_entry}"
                )

    return {
        'meta': metadata,
        'content': body
    }


def load_files_for_push(meta: Dict, base_dir: Path) -> list:
    """
    Reads files referenced in the frontmatter 'files' list and encodes them as base64.
    Files must be inside the collection's 'assets/' folder.

    Returns a list of dicts ready to include in the push payload.
    """
    files_payload = []
    for f_entry in meta.get('files', []):
        rel_path = f_entry.get('path', '')
        is_public = f_entry.get('is_public', False)

        # Resolve file path relative to collection root (where prompthub.yaml is)
        file_path = base_dir / rel_path

        if not file_path.exists():
            raise ValueError(
                f"File referenced in frontmatter not found: '{rel_path}'\n"
                f"  Expected at: {file_path}\n"
                f"  Make sure the file exists in the 'assets/' folder."
            )

        file_size = file_path.stat().st_size
        if file_size > MAX_FILE_SIZE_BYTES:
            raise ValueError(
                f"File '{rel_path}' exceeds the maximum size of {MAX_FILE_SIZE_MB}MB "
                f"(found {file_size / 1024 / 1024:.1f}MB)."
            )

        mime_type, _ = mimetypes.guess_type(str(file_path))
        mime_type = mime_type or 'application/octet-stream'

        with open(file_path, 'rb') as f:
            content_b64 = base64.b64encode(f.read()).decode('utf-8')

        files_payload.append({
            'path': rel_path,
            'is_public': bool(is_public),
            'filename': file_path.name,
            'mime_type': mime_type,
            'size': file_size,
            'content_b64': content_b64,
        })

    return files_payload


def save_pulled_files(files_data: list, base_dir: Path) -> list:
    """
    Downloads/saves files from a pull response into the 'assets/' folder.

    Args:
        files_data: List of file dicts from the server (with 'url', 'path', etc.)
        base_dir: Collection root directory

    Returns:
        List of file entries for the frontmatter.
    """
    import requests

    frontmatter_files = []
    assets_dir = base_dir / 'assets'

    for f_data in files_data:
        rel_path = f_data.get('path', '')
        url = f_data.get('url', '')
        is_public = f_data.get('is_public', False)
        filename = f_data.get('filename', Path(rel_path).name)

        # Ensure assets/ directory exists
        if rel_path.startswith('assets/'):
            target_path = base_dir / rel_path
        else:
            assets_dir.mkdir(parents=True, exist_ok=True)
            target_path = assets_dir / filename
            rel_path = f'assets/{filename}'

        target_path.parent.mkdir(parents=True, exist_ok=True)

        if url:
            try:
                response = requests.get(url, timeout=30)
                response.raise_for_status()
                with open(target_path, 'wb') as f:
                    f.write(response.content)
            except Exception as e:
                print(f"  Warning: Could not download file '{rel_path}': {e}")
                continue

        frontmatter_files.append({
            'path': rel_path,
            'is_public': bool(is_public),
        })

    return frontmatter_files


def parse_repo_string(repo_str: str) -> Tuple[str, Optional[str]]:
    """
    Parses a repository string which can be:
    1. A full URL: http://domain/username/collections/slug
    2. A shorthand: username/slug
    3. Just a slug: slug
    Returns (slug, username)
    """
    if 'http' in repo_str:
        repo_str = repo_str.rstrip('/')
        parts = repo_str.split('/')
        if 'collections' in parts:
            idx = parts.index('collections')
            if idx > 0 and idx < len(parts) - 1:
                username = parts[idx - 1]
                slug = parts[idx + 1]
                return slug, username
        return parts[-1], None

    if '/' in repo_str:
        parts = repo_str.split('/')
        if len(parts) == 2:
            return parts[1], parts[0]

    return repo_str, None


def get_project_config(root: Path = Path('.')) -> Optional[Dict]:
    config_path = root / 'prompthub.yaml'
    if not config_path.exists():
        return None
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)


def create_project_config(name: str, author: str = None, root: Path = Path('.')):
    config = {
        'project': name,
        'version': '0.1.0',
        'include': ['**/*.prompt.md'],
        'exclude': ['node_modules/**', '.git/**', 'assets/**']
    }
    if author:
        config['author'] = author

    with open(root / 'prompthub.yaml', 'w') as f:
        yaml.safe_dump(config, f, sort_keys=False)


def dump_prompt_file(file_path: Path, data: Dict):
    """
    Writes a prompt data dictionary to a markdown file with YAML frontmatter.
    Reconstructs the format expected by parse_prompt_file.

    The data dict (from server pull) supports these keys:
      slug, title, version, description, long_description,
      visibility (or is_public for legacy), content_hidden,
      output_type, language, area, tags, config,
      files (list of {path, is_public}),
      content: {system, user}
    """
    # Build frontmatter
    meta = {}

    # Required
    meta['slug'] = data.get('slug', '')
    meta['version'] = data.get('version', '0.0.1')

    # Title
    if data.get('title'):
        meta['title'] = data['title']

    # Descriptions
    if data.get('description'):
        meta['description'] = data['description']
    if data.get('long_description'):
        meta['long_description'] = data['long_description']

    # Visibility: normalize from is_public (legacy) or visibility field
    if 'visibility' in data:
        meta['visibility'] = data['visibility']
    elif 'is_public' in data:
        meta['visibility'] = 'public' if data['is_public'] else 'private'
    else:
        meta['visibility'] = 'private'

    # Optional boolean flags
    if data.get('content_hidden'):
        meta['content_hidden'] = True

    # Output type (only include if non-default)
    output_type = data.get('output_type', 'text')
    if output_type and output_type != 'text':
        meta['output_type'] = output_type

    # Language
    if data.get('language'):
        meta['language'] = data['language']

    # Taxonomy
    if data.get('tags'):
        meta['tags'] = data['tags']
    if data.get('area'):
        meta['area'] = data['area']

    # Files list (for reconstructing frontmatter on pull)
    if data.get('files'):
        meta['files'] = data['files']

    # System prompt
    content_block = data.get('content', {})
    system_text = content_block.get('system', '') if isinstance(content_block, dict) else ''
    user_text = content_block.get('user', '') if isinstance(content_block, dict) else ''

    if system_text:
        meta['system_prompt'] = system_text

    # Config
    if data.get('config'):
        meta['config'] = data['config']

    # Clean up None/empty values (but keep False booleans)
    meta = {k: v for k, v in meta.items() if v is not None and v != '' and v != [] and v != {}}

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write("---\n")
        yaml.safe_dump(meta, f, sort_keys=False, allow_unicode=True, default_flow_style=False)
        f.write("---\n\n")
        f.write(user_text or '')
