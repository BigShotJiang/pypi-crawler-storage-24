"""
VEOX Public Evolution Client
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Sklearn-style interface for launching and monitoring evolutionary algorithm jobs.

    from veox import VeoxEvolver

    evolver = VeoxEvolver("binary")
    evolver.fit(max_generations=10)
    print(evolver.best_pipeline_)

"""

from .evolver import VeoxEvolver, EvolutionResult, Champion

__all__ = ["VeoxEvolver", "EvolutionResult", "Champion"]
__version__ = "1.0.0"
