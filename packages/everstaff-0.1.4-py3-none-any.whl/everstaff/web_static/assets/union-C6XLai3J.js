import{c as r,d as e}from"./_baseUniq-D92XpgEc.js";import{av as s,aw as t}from"./index-T3Kiq0US.js";var o=s(function(a){return r(e(a,1,t,!0))});export{o as u};
