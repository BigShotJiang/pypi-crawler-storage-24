import{ab as o,ac as n}from"./index-T3Kiq0US.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
