#****************************************************************************
#* package_gh_rls.py
#*
#* Copyright 2023 Matthew Ballance and Contributors
#*
#* Licensed under the Apache License, Version 2.0 (the "License"); you may 
#* not use this file except in compliance with the License.  
#* You may obtain a copy of the License at:
#*
#*   http://www.apache.org/licenses/LICENSE-2.0
#*
#* Unless required by applicable law or agreed to in writing, software 
#* distributed under the License is distributed on an "AS IS" BASIS, 
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  
#* See the License for the specific language governing permissions and 
#* limitations under the License.
#*
#* Created on:
#*     Author: 
#*
#****************************************************************************
import os
import fnmatch
import httpx
import json
import logging
import re
import platform
import subprocess
import shutil
import dataclasses as dc
from typing import Optional
from ..proj_info import ProjInfo
from ..cache import Cache
from ..utils import note
from .package_http import PackageHttp

_logger = logging.getLogger("ivpm.pkg_types.package_gh_rls")

@dc.dataclass
class PackageGhRls(PackageHttp):
    version : str = "latest"
    file : Optional[str] = None
    prerelease : bool = False  # Whether to include prerelease releases when selecting
    source : bool = False  # Whether to force fetching source archive instead of binary
    resolved_version : str = None  # actual release tag after fetch

    def process_options(self, opts, si):
        super().process_options(opts, si)

        # Strip trailing slashes to avoid API URL formatting issues
        self.url = self.url.rstrip('/')

        if self.url.find("github.com") == -1:
            raise Exception("GitHub release URL must be specified. URL %s doesn't contain github.com" % self.url)
        
        if "version" in opts.keys():
            self.version = opts["version"]

        if "file" in opts.keys():
            self.file = opts["file"]

        if "prerelease" in opts.keys():
            self.prerelease = bool(opts["prerelease"])

        if "source" in opts.keys():
            self.source = bool(opts["source"])


    def update(self, update_info):
        # Report this package for cache statistics
        # GitHub release packages are cacheable if cache=True, editable if cache is not True
        is_cacheable = self.cache is True
        is_editable = self.cache is not True  # Could be cached but isn't
        update_info.report_package(cacheable=is_cacheable, editable=is_editable)

        pkg_dir = os.path.join(update_info.deps_dir, self.name)

        if os.path.isdir(pkg_dir) or os.path.islink(pkg_dir):
            note("Skipping %s, since it is already loaded" % self.name)
            return

        # Query release metadata
        rls_info, rls, file_url, forced_ext = self._resolve_release()
        # Get version from release tag for caching
        release_tag = rls.get("tag_name", "")
        self.resolved_version = release_tag

        # Check if caching is enabled
        if self.cache is True:
            return self._update_with_cache(update_info, pkg_dir, file_url, forced_ext, release_tag)
        elif self.cache is False:
            return self._update_no_cache_readonly(update_info, pkg_dir, file_url, forced_ext)
        else:
            return self._update_normal(update_info, pkg_dir, file_url, forced_ext)

    def _repo_base_url(self):
        """Return the base GitHub API URL for this package's repo."""
        github_com_idx = self.url.find("github.com")
        return "https://api.github.com/repos/" + self.url[github_com_idx + len("github.com") + 1:]

    def _github_headers(self):
        """Return headers for GitHub API requests, including auth token if available."""
        headers = {"Accept": "application/vnd.github+json"}
        token = os.environ.get("GITHUB_TOKEN")
        if token:
            headers["Authorization"] = "Bearer " + token
        return headers

    def _fetch_tags(self):
        """Fetch tags from GitHub API and normalize them to release-like dicts."""
        tags_url = self._repo_base_url() + "/tags"
        resp = httpx.get(tags_url, headers=self._github_headers(), follow_redirects=True)
        if resp.status_code != 200:
            return []
        tags = json.loads(resp.content)
        # Normalize tags to look like release dicts so existing version-selection
        # logic can be reused.  Tags only provide source archives, no binary assets.
        normalized = []
        for t in tags:
            normalized.append({
                "tag_name": t["name"],
                "prerelease": False,
                "assets": [],
                "tarball_url": t.get("tarball_url"),
                "zipball_url": t.get("zipball_url"),
                "_is_tag": True,
            })
        return normalized

    def _resolve_release(self):
        """Query GitHub API and resolve the release and asset to download.
        
        Returns:
            Tuple of (rls_info, rls, file_url, forced_ext)
        """
        releases_url = self._repo_base_url() + "/releases"
        rls_info_resp = httpx.get(releases_url, headers=self._github_headers(), follow_redirects=True)

        if rls_info_resp.status_code != 200:
            raise Exception("Failed to fetch release info: %d" % rls_info_resp.status_code)

        rls_info = json.loads(rls_info_resp.content)

        # Select release per version specification
        rls = None
        if self.version == "latest":
            for r in rls_info:
                if r["prerelease"] and not self.prerelease:
                    continue
                # Skip releases with no usable assets (no assets, or all with broken untagged URLs)
                if not self.source and not self._filter_valid_assets(r.get("assets", [])): 
                    continue
                rls = r
                break
            if rls is None:
                # No formal releases — fall back to most recent tag
                tags = self._fetch_tags()
                if tags:
                    rls = tags[0]
                    rls_info = tags
                else:
                    raise Exception("Failed to find latest release (prerelease=%s)" % self.prerelease)
        else:
            _logger.debug("%s: searching %d releases for version '%s'",
                          self.name, len(rls_info), self.version)
            rls = self._select_release_by_version(rls_info)
            if rls is None:
                _logger.debug("%s: version '%s' not found in releases, falling back to tags",
                              self.name, self.version)
                # Not found in releases — try tags
                tags = self._fetch_tags()
                rls = self._select_release_by_version(tags)
                if rls is None:
                    raise Exception(f"No release or tag matches version spec '{self.version}'")
                _logger.debug("%s: matched version '%s' via tag (no binary assets available)",
                              self.name, self.version)
                rls_info = tags
            else:
                _logger.debug("%s: matched version '%s' as release tag=%s prerelease=%s assets=%d",
                              self.name, self.version, rls.get("tag_name",""),
                              rls.get("prerelease"), len(rls.get("assets", [])))

        # Determine file to download
        file_url = None
        forced_ext = None

        assets = rls.get("assets", [])
        if self.file is not None:
            # Filter assets to those whose name starts with the basename or matches it as a pattern
            filtered = [
                a for a in assets
                if (lambda nm: nm.startswith(self.file) or fnmatch.fnmatch(nm, self.file))(
                    a.get("name") or os.path.basename(a.get("browser_download_url", ""))
                )
            ]
            if not filtered:
                names = [a.get("name") or os.path.basename(a.get("browser_download_url", "")) for a in assets]
                raise Exception(f"No assets matching basename '{self.file}' found in release. Available assets: {', '.join(names)}")
            assets = filtered

        # If source=true, skip binary detection and go straight to source
        has_binaries = self._has_binary_assets(assets) if not self.source else False
        if not has_binaries:
            file_url, forced_ext = self._choose_source_url(rls)
            if file_url is None:
                if len(assets) == 1 and "browser_download_url" in assets[0]:
                    file_url = assets[0]["browser_download_url"]
                else:
                    raise Exception("No suitable source artifact found")
        else:
            sysname, machine, glibc = self._get_system_info()
            norm_arch = self._normalize_arch(sysname, machine)

            selected = None
            if sysname == "linux":
                if glibc is None:
                    raise Exception("Cannot determine glibc version on Linux.")
                selected = self._select_linux_asset(assets, norm_arch, glibc)
                if selected is None:
                    found = []
                    for a in assets:
                        nm = (a.get("name") or os.path.basename(a.get("browser_download_url", ""))).lower()
                        tag = self._parse_manylinux(nm)
                        if tag is not None:
                            found.append(f"manylinux_{tag[0]}_{tag[1]}_{tag[2]}")
                    if not found:
                        names = [a.get("name") or os.path.basename(a.get("browser_download_url", "")) for a in assets]
                        raise Exception(f"No suitable Linux binary found for arch={norm_arch} glibc={glibc[0]}.{glibc[1]}. Available assets: {', '.join(names)}")
                    else:
                        raise Exception(f"No suitable Linux manylinux binary found for arch={norm_arch} glibc={glibc[0]}.{glibc[1]}. Available manylinux tags: {', '.join(sorted(set(found)))}")
            elif sysname == "darwin":
                selected = self._select_macos_asset(assets, norm_arch)
                if selected is None:
                    names = [a.get("name") or os.path.basename(a.get("browser_download_url", "")) for a in assets]
                    raise Exception(f"No suitable macOS binary found for arch={norm_arch}. Available assets: {', '.join(names)}")
            elif sysname == "windows":
                selected = self._select_windows_asset(assets, norm_arch)
                if selected is None:
                    names = [a.get("name") or os.path.basename(a.get("browser_download_url", "")) for a in assets]
                    raise Exception(f"No suitable Windows binary found for arch={norm_arch}. Available assets: {', '.join(names)}")
            else:
                raise Exception(f"Unsupported platform: {sysname}")

            file_url = selected["browser_download_url"]

        return rls_info, rls, file_url, forced_ext

    def _determine_src_type(self, file_url, forced_ext):
        """Determine the source type for unpacking."""
        if forced_ext is not None:
            ext = forced_ext
        else:
            ext = os.path.splitext(file_url)[1]
            if ext == "":
                ext = ".tar.gz"

        if ext == ".tgz":
            self.src_type = ".tar.gz"
        else:
            self.src_type = ext
            if self.src_type in [".gz", ".xz", ".bz2"]:
                pdot = file_url.rfind('.')
                pdot = file_url.rfind('.', 0, pdot - 1)
                self.src_type = file_url[pdot:]

    def _update_with_cache(self, update_info, pkg_dir, file_url, forced_ext, release_tag):
        """Update using the cache."""
        note("loading package %s with cache" % self.name)

        # Use release tag as version identifier for caching
        # Include platform info for binary releases to cache per-platform
        sysname, machine, _ = self._get_system_info()
        norm_arch = self._normalize_arch(sysname, machine)
        version = f"{release_tag}_{sysname}_{norm_arch}"

        cache = update_info.cache
        if cache is None:
            cache = Cache()

        if not cache.is_enabled():
            note("IVPM_CACHE not set - falling back to no-cache mode for %s" % self.name)
            return self._update_no_cache_readonly(update_info, pkg_dir, file_url, forced_ext)

        if cache.has_version(self.name, version):
            note("Cache hit for %s at version %s" % (self.name, version))
            cache.link_to_deps(self.name, version, update_info.deps_dir)
            update_info.report_cache_hit()
            return

        note("Cache miss for %s - downloading" % self.name)
        update_info.report_cache_miss()

        # Download to temp location
        temp_dir = os.path.join(update_info.deps_dir, f".cache_temp_{self.name}")
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)

        self._determine_src_type(file_url, forced_ext)
        filename = os.path.basename(file_url)
        if forced_ext is not None and not filename.endswith(forced_ext):
            filename = filename + forced_ext
        download_dst = os.path.join(update_info.deps_dir, filename)
        self._download_file(file_url, download_dst)

        self._install(download_dst, temp_dir)
        os.unlink(download_dst)

        cache.store_version(self.name, version, temp_dir)
        cache.link_to_deps(self.name, version, update_info.deps_dir)

    def _update_no_cache_readonly(self, update_info, pkg_dir, file_url, forced_ext):
        """Download and make read-only (cache=False)."""
        note("loading package %s (no cache, read-only)" % self.name)

        self._update_normal(update_info, pkg_dir, file_url, forced_ext)
        self._make_readonly(pkg_dir)

    def _update_normal(self, update_info, pkg_dir, file_url, forced_ext):
        """Normal download without caching."""
        self._determine_src_type(file_url, forced_ext)

        filename = os.path.basename(file_url)
        if forced_ext is not None and not filename.endswith(forced_ext):
            filename = filename + forced_ext
        download_dst = os.path.join(update_info.deps_dir, filename)
        self._download_file(file_url, download_dst)

        self._install(download_dst, pkg_dir)
        os.unlink(download_dst)

    def _parse_version_tuple(self, v):
        m = re.match(r'v?(\d+(?:\.\d+)*)', v or '')
        if not m:
            return None
        return tuple(int(p) for p in m.group(1).split('.'))

    def _cmp_versions(self, a, b):
        la = len(a); lb = len(b)
        for i in range(max(la, lb)):
            ai = a[i] if i < la else 0
            bi = b[i] if i < lb else 0
            if ai != bi:
                return 1 if ai > bi else -1
        return 0

    def _select_release_by_version(self, releases):
        # When the user specifies an explicit version, prerelease status is irrelevant:
        # there can only be one release with a given tag, whether it is marked prerelease
        # or not.  Filtering it out would cause a silent fall-through to the tag list
        # which has no binary assets, resulting in an unintended source download.
        spec = self.version.strip()
        m = re.match(r'(>=|<=|>|<)\s*v?(\d+(?:\.\d+)*)$', spec)
        if m:
            op = m.group(1)
            tgt = self._parse_version_tuple(m.group(2))
            best = None
            for r in releases:
                rv = self._parse_version_tuple(r.get("tag_name",""))
                if rv is None:
                    continue
                if r.get("prerelease") and not self.prerelease:
                    continue
                c = self._cmp_versions(rv, tgt)
                ok = False
                if op == ">": ok = c > 0
                elif op == ">=": ok = c >= 0
                elif op == "<": ok = c < 0
                elif op == "<=": ok = c <= 0
                if not ok:
                    continue
                _logger.debug("Version range %s: candidate release %s (prerelease=%s)",
                              spec, r.get("tag_name",""), r.get("prerelease"))
                if op in (">", ">="):
                    best = r
                    break
                else: # < or <= : keep highest satisfying
                    if best is None:
                        best = r
                    else:
                        b_v = self._parse_version_tuple(best.get("tag_name",""))
                        if self._cmp_versions(rv, b_v) > 0:
                            best = r
            return best
        # Exact match (allow optional leading v)
        for r in releases:
            tag = r.get("tag_name","")
            if tag == spec or tag == f"v{spec}" or spec == tag.lstrip('v'):
                _logger.debug("Exact version match: found release %s (prerelease=%s)",
                              tag, r.get("prerelease"))
                return r
        tgt = self._parse_version_tuple(spec)
        if tgt:
            for r in releases:
                rv = self._parse_version_tuple(r.get("tag_name",""))
                if rv == tgt:
                    _logger.debug("Numeric version match: found release %s (prerelease=%s)",
                                  r.get("tag_name",""), r.get("prerelease"))
                    return r
        return None

    # Helper methods for asset selection and platform detection

    def _normalize_arch(self, system, machine):
        system = (system or "").lower()
        m = (machine or "").lower()
        if system == "linux":
            if m in ("x86_64", "amd64"):
                return "x86_64"
            if m in ("aarch64", "arm64"):
                return "aarch64"
            if m.startswith("armv7"):
                return "armv7l"
            return m
        elif system == "darwin":
            if m in ("arm64", "aarch64"):
                return "arm64"
            return "x86_64" if m in ("x86_64", "amd64") else m
        elif system == "windows":
            return "x86_64" if m in ("x86_64", "amd64") else m
        else:
            return m

    def _get_linux_distro_info(self):
        """
        Get Linux distribution information.
        Returns (distro_name, version_str) or (None, None) if unable to determine.
        """
        try:
            if os.path.exists("/etc/os-release"):
                with open("/etc/os-release", "r") as f:
                    content = f.read()
                    distro_id = None
                    version_id = None
                    for line in content.split('\n'):
                        if line.startswith("ID="):
                            distro_id = line.split("=", 1)[1].strip().strip('"').lower()
                        elif line.startswith("VERSION_ID="):
                            version_id = line.split("=", 1)[1].strip().strip('"')
                    if distro_id and version_id:
                        return (distro_id, version_id)
        except Exception:
            pass
        return (None, None)

    def _get_system_info(self):
        sysname = platform.system().lower()
        machine = platform.machine()
        glibc = None
        if sysname == "linux":
            libc_name, libc_ver = platform.libc_ver()
            ver_t = None
            if libc_ver:
                try:
                    parts = libc_ver.split(".")
                    major = int(parts[0]) if len(parts) > 0 else 0
                    minor = int(parts[1]) if len(parts) > 1 else 0
                    ver_t = (major, minor)
                except Exception:
                    ver_t = None
            if ver_t is None:
                try:
                    # Fallback to parsing ldd --version
                    out = subprocess.check_output(["ldd", "--version"], stderr=subprocess.STDOUT, text=True)
                    m = re.search(r"(\d+)\.(\d+)", out)
                    if m:
                        ver_t = (int(m.group(1)), int(m.group(2)))
                except Exception:
                    ver_t = None
            glibc = ver_t
        return sysname, machine, glibc

    def _parse_manylinux(self, name):
        """
        Parse manylinux tag from a filename.
        Returns (glibc_major, glibc_minor, arch) or None
        """
        n = (name or "").lower()
        m = re.search(r"manylinux_(\d+)_(\d+)_([a-z0-9_]+)", n)
        if m:
            return (int(m.group(1)), int(m.group(2)), m.group(3))
        m = re.search(r"manylinux(1|2010|2014)_([a-z0-9_]+)", n)
        if m:
            legacy = m.group(1)
            arch = m.group(2)
            if legacy == "1":
                return (2, 5, arch)       # manylinux1 -> glibc 2.5
            elif legacy == "2010":
                return (2, 12, arch)      # manylinux2010 -> glibc 2.12
            elif legacy == "2014":
                return (2, 17, arch)      # manylinux2014 -> glibc 2.17
        return None

    def _parse_linux_os_specific(self, name):
        """
        Parse OS-specific Linux naming pattern (e.g., ubuntu-22.04-x86_64, ubuntu-24.04-aarch64).
        Returns (distro, version, arch) or None if not an OS-specific binary.
        """
        n = (name or "").lower()
        # Match patterns like: ubuntu-22.04-x86_64, ubuntu-24.04-aarch64, debian-11-x86_64
        m = re.search(r"(ubuntu|debian|fedora|centos|rhel|alpine)[_-](\d+(?:\.\d+)?)[_-]([a-z0-9_]+)", n)
        if m:
            distro = m.group(1)
            version = m.group(2)
            arch = m.group(3)
            # Normalize arch names
            if arch in ("x86_64", "amd64"):
                arch = "x86_64"
            elif arch in ("aarch_64", "aarch64", "arm64"):
                arch = "aarch64"
            elif arch.startswith("armv7"):
                arch = "armv7l"
            return (distro, version, arch)
        return None

    def _parse_linux_generic(self, name):
        """
        Parse generic Linux naming pattern (e.g., protobuf style: protoc-33.2-linux-x86_64.zip).
        Returns arch or None if not a Linux binary.
        """
        n = (name or "").lower()
        # Match patterns like: linux-x86_64, linux-aarch64, linux_x86_64, etc.
        m = re.search(r"linux[_-]([a-z0-9_]+)", n)
        if m:
            arch = m.group(1)
            # Normalize arch names
            if arch in ("x86_64", "amd64", "x64"):
                return "x86_64"
            elif arch in ("aarch_64", "aarch64", "arm64"):
                return "aarch64"
            elif arch.startswith("armv7"):
                return "armv7l"
            return arch
        return None

    def _select_linux_asset(self, assets, arch, glibc):
        # First, check if there are OS-specific assets
        os_specific_assets = []
        for a in assets:
            nm = (a.get("name") or os.path.basename(a.get("browser_download_url", ""))).lower()
            parsed = self._parse_linux_os_specific(nm)
            if parsed is not None:
                os_specific_assets.append((parsed, a))
        
        # If OS-specific packages exist, we must find a matching one (when source=false)
        if os_specific_assets:
            distro, distro_ver = self._get_linux_distro_info()
            if distro is None or distro_ver is None:
                # Can't determine distro, list available OS-specific packages
                available = []
                for (d, v, a), _ in os_specific_assets:
                    available.append(f"{d}-{v}-{a}")
                raise Exception(
                    f"OS-specific packages found but unable to determine Linux distribution. "
                    f"Available: {', '.join(sorted(set(available)))}. "
                    f"Consider setting source=true to download source instead."
                )
            
            # Try to find exact match
            for (pkg_distro, pkg_ver, pkg_arch), asset in os_specific_assets:
                if pkg_distro == distro and pkg_ver == distro_ver and pkg_arch == arch:
                    return asset
            
            # No exact match found - report available options
            available = []
            for (d, v, a), _ in os_specific_assets:
                available.append(f"{d}-{v}-{a}")
            raise Exception(
                f"No OS-specific package found for {distro}-{distro_ver}-{arch}. "
                f"Available: {', '.join(sorted(set(available)))}. "
                f"Consider setting source=true to download source instead."
            )
        
        # No OS-specific assets, try manylinux-tagged assets (preferred for glibc compatibility)
        candidates = []
        for a in assets:
            nm = (a.get("name") or os.path.basename(a.get("browser_download_url", ""))).lower()
            tag = self._parse_manylinux(nm)
            if tag is None:
                continue
            if tag[2] != arch:
                continue
            ver = (tag[0], tag[1])
            candidates.append((ver, a))
        if candidates:
            eligible = [(ver, a) for (ver, a) in candidates if ver <= glibc]
            if eligible:
                eligible.sort(key=lambda x: x[0])
                return eligible[-1][1]
        
        # Fallback: try generic Linux naming pattern (e.g., protobuf style)
        for a in assets:
            nm = (a.get("name") or os.path.basename(a.get("browser_download_url", ""))).lower()
            parsed_arch = self._parse_linux_generic(nm)
            if parsed_arch == arch:
                return a
        
        return None

    def _select_macos_asset(self, assets, arch):
        # Minimal heuristic: look for mac-related tags and arch token
        keys = ("macos", "darwin", "osx")
        for a in assets:
            nm = (a.get("name") or os.path.basename(a.get("browser_download_url", ""))).lower()
            if any(k in nm for k in keys):
                if arch in nm or (arch == "arm64" and "aarch64" in nm) or (arch == "x86_64" and "amd64" in nm):
                    return a
        # Fallback: any mac-related asset
        for a in assets:
            nm = (a.get("name") or os.path.basename(a.get("browser_download_url", ""))).lower()
            if any(k in nm for k in keys):
                return a
        return None

    def _select_windows_asset(self, assets, arch):
        keys = ("windows", "win64", "win32", "win")
        arch_aliases = [arch]
        if arch == "x86_64":
            arch_aliases += ["amd64"]
        for a in assets:
            nm = (a.get("name") or os.path.basename(a.get("browser_download_url", ""))).lower()
            if any(k in nm for k in keys) and any(alias in nm for alias in arch_aliases):
                return a
        # Fallback to any windows asset
        for a in assets:
            nm = (a.get("name") or os.path.basename(a.get("browser_download_url", ""))).lower()
            if any(k in nm for k in keys):
                return a
        return None

    def _has_binary_assets(self, assets):
        for a in assets:
            nm = (a.get("name") or os.path.basename(a.get("browser_download_url", ""))).lower()
            if self._parse_linux_os_specific(nm) is not None:
                return True
            if self._parse_manylinux(nm) is not None:
                return True
            if self._parse_linux_generic(nm) is not None:
                return True
            if any(k in nm for k in ("macos", "darwin", "osx", "windows", "win64", "win32", "win")):
                return True
        return False

    def _filter_valid_assets(self, assets):
        """Filter out assets with broken untagged URLs (draft artifacts that weren't re-published)."""
        return [a for a in assets if "untagged-" not in a.get("browser_download_url", "")]

    def _choose_source_url(self, rls):
        """Return (url, forced_ext) for the source archive of a release, or (None, None)."""
        # Prefer tarball over zipball
        tarball = rls.get("tarball_url")
        if tarball:
            return tarball, ".tar.gz"
        zipball = rls.get("zipball_url")
        if zipball:
            return zipball, ".zip"
        return None, None

    @staticmethod
    def create(name, opts, si) -> 'PackageGhRls':
        pkg = PackageGhRls(name)
        pkg.process_options(opts, si)
        return pkg
