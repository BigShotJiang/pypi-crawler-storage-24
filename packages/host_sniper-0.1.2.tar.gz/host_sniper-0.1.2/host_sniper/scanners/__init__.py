"""Host Sniper scanners"""
