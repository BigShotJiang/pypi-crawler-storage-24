"""Host Sniper utilities"""
