"""Host Sniper core scanners"""
