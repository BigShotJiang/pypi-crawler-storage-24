from typing import Optional, Dict, Any, List

from pydantic import Field

from thestage.services.clients.thestage_api.dtos.base_response import TheStageBasePaginatedResponse, \
    TheStageBaseResponse


class InstanceRentedTerminateResponse(TheStageBaseResponse):
    terminatedInstanceRentedPublicIds: Optional[List[str]] = Field(None, alias='terminatedInstanceRentedPublicIds')
    failedInstanceRentedPublicIds: Optional[List[str]] = Field(None, alias='failedInstanceRentedPublicIds')
