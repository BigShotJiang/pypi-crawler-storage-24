from thestage.services.clients.thestage_api.dtos.base_response import BaseResponseWarning
from rich import print


def print_warning(warning: BaseResponseWarning):
    colored_warning = f"[{warning.colorHex}]{warning.message}[/]"
    print(colored_warning)
