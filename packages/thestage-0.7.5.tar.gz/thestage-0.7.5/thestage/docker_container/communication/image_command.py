import typer

from thestage.cli_command import CliCommand
from thestage.cli_command_helper import get_command_metadata, check_command_permission
from thestage.controllers.utils_controller import validate_config_and_get_service_factory
from thestage.docker_container.business.container_service import ContainerService
from thestage.i18n.translation import __

app = typer.Typer(no_args_is_help=True, help=__("Manage Docker images"))

@app.command(name='ls', help=__("List available docker images"), **get_command_metadata(CliCommand.CONTAINER_LS))
def list_available_images(
        row: int = typer.Option(
            5,
            '--row',
            '-r',
            help=__("Set number of rows displayed per page"),
            is_eager=False,
        ),
        page: int = typer.Option(
            1,
            '--page',
            '-p',
            help=__("Set starting page for displaying output"),
            is_eager=False,
        ),
):
    command_name = CliCommand.CONTAINER_IMAGE_LS
    check_command_permission(command_name)

    service_factory = validate_config_and_get_service_factory()
    container_service: ContainerService = service_factory.get_container_service()

    container_service.print_docker_image_list(
        row=row,
        page=page,
    )

    typer.echo(__("Images listing complete"))
    raise typer.Exit(0)