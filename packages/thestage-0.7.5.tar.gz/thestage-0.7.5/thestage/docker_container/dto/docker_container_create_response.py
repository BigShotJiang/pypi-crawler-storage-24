from typing import Optional

from pydantic import Field, ConfigDict

from thestage.services.clients.thestage_api.dtos.base_response import TheStageBaseResponse


class DockerContainerCreateResult(TheStageBaseResponse):
    model_config = ConfigDict(populate_by_name=True)

    docker_container_public_id: Optional[str] = Field(None, alias='dockerContainerPublicId')
