from typing import Optional

from thestage.docker_container.dto.container_response import DockerImageDto
from thestage.docker_container.dto.image_entity import DockerImageEntity
from thestage.services.abstract_mapper import AbstractMapper


class ImageMapper(AbstractMapper):
    def build_entity(self, item: DockerImageDto) -> Optional[DockerImageEntity]:
        if not item:
            return None

        return DockerImageEntity(
            image=item.image or '',
            tag=item.tag or '',
        )
