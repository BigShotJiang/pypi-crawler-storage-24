from typing import Optional, List

from pydantic import BaseModel, Field


class BaseResponseWarning(BaseModel):
    colorHex: str = Field(None, alias="colorHex")
    message: Optional[str] = Field(None, alias='message')

class TheStageBaseResponse(BaseModel):
    message: Optional[str] = Field(None, alias='message')
    isSuccess: Optional[bool] = Field(None, alias='isSuccess')
    fieldsWithError: Optional[List[str]] = Field(None, alias='fieldsWithError')
    warningsImmediate: Optional[List[BaseResponseWarning]] = Field(None, alias='warningsImmediate')
    warningsOnExit: Optional[List[BaseResponseWarning]] = Field(None, alias='warningsOnExit')


# TODO: add Generic then back doing that
class TheStageBasePaginatedResponse(TheStageBaseResponse):
    fieldsWithError: List[str] = Field(None, alias='fieldsWithError')
