from typing import List, Optional

from pydantic import Field, ConfigDict, BaseModel


class DeleteProjectRequest(BaseModel):
    model_config = ConfigDict(use_enum_values=True)

    projectPublicId: Optional[str] = Field(None, alias='projectPublicId')
    projectSlug: Optional[str] = Field(None, alias='projectSlug')