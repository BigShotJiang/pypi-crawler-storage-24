from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class ProjectEntity(BaseModel):
    model_config = ConfigDict(
        populate_by_name=True,
        use_enum_values=True,
    )

    public_id: Optional[str] = Field(None, alias='ID')
    slug: Optional[str] = Field(None, alias='NAME')
    status: Optional[str] = Field(None, alias='STATUS')
    last_commit_hash: Optional[str] = Field(None, alias='LAST COMMIT HASH')
