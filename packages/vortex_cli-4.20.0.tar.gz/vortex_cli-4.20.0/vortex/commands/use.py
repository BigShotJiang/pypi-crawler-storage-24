from __future__ import annotations

import configparser
import logging

from vortex.workspace import Workspace

logger = logging.getLogger("vortex")


def use(workspace: Workspace, server_name: str) -> int:
    config = configparser.ConfigParser()
    config.read(workspace.server_config_file)

    available_servers = config.sections()
    if server_name not in available_servers:
        logger.error(
            f"Server '{server_name}' not found in config. "
            f"Available servers: {available_servers}"
        )
        return 1

    config.set(config.default_section, "default", server_name)
    with open(workspace.server_config_file, "w") as f:
        config.write(f)

    logger.info(f"Default server set to '{server_name}'")
    return 0
