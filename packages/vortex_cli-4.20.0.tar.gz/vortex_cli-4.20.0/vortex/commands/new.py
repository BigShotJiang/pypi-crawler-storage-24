from __future__ import annotations

import argparse
import asyncio
import base64
import logging
import mimetypes
from collections.abc import Iterable
from typing import Any

import tabulate

from vortex.colour import Colour
from vortex.models import DesignObject
from vortex.models import DesignObjectAmbiguousError
from vortex.models import DesignObjectNotFound
from vortex.models import DesignObjectParam
from vortex.models import DesignType
from vortex.models import PuakmaApplication
from vortex.models import PuakmaServer
from vortex.soap import AppDesigner
from vortex.util import render_apps
from vortex.util import render_objects
from vortex.workspace import Workspace

logger = logging.getLogger("vortex")


def _prep_new_object(
    name: str,
    app: PuakmaApplication,
    design_type: DesignType,
    content_type: str | None = None,
    comment: str | None = None,
    inherit_from: str | None = None,
    parent_page: str | None = None,
    open_action: str | None = None,
    save_action: str | None = None,
) -> DesignObject:
    content_type = design_type.content_type() or content_type
    _ext = mimetypes.guess_extension(content_type) if content_type else None
    if _ext is None or content_type is None:
        raise ValueError(f"Unable to determine file type for '{content_type}'")
    design_source = base64.b64encode(design_type.source_template(name)).decode()
    params = []
    if open_action is not None:
        params.append(DesignObjectParam("OpenAction", open_action))
    if save_action is not None:
        params.append(DesignObjectParam("SaveAction", save_action))
    if parent_page is not None:
        params.append(DesignObjectParam("ParentPage", parent_page))

    return DesignObject(
        -1,
        name,
        app,
        design_type,
        content_type,
        "",
        design_source,
        comment=comment,
        inherit_from=inherit_from,
        params=params,
    )


def _prepare_new_objects(
    name: str,
    app: PuakmaApplication,
    design_type: DesignType,
    content_type: str | None = None,
    comment: str | None = None,
    inherit_from: str | None = None,
    parent_page: str | None = None,
    open_action: str | None = None,
    save_action: str | None = None,
) -> list[DesignObject]:
    objs: list[DesignObject] = []

    if open_action:
        try:
            app.lookup_design_obj(open_action)
        except DesignObjectNotFound:
            objs.append(_prep_new_object(open_action, app, DesignType.ACTION))

    if save_action:
        try:
            app.lookup_design_obj(save_action)
        except DesignObjectNotFound:
            objs.append(_prep_new_object(save_action, app, DesignType.ACTION))

    try:
        _, _new_obj = app.lookup_design_obj(name)
    except DesignObjectNotFound:
        objs.append(
            _prep_new_object(
                name,
                app,
                design_type,
                content_type,
                comment,
                inherit_from,
                parent_page,
                open_action,
                save_action,
            )
        )
    else:
        raise ValueError(f"Design Object {_new_obj} already exists in {app}")
    return objs


def _validate_args_for_type(
    design_type: DesignType,
    **kwargs: Any,
) -> bool:
    _kwarg_keys = {k for k, _v in kwargs.items() if _v is not None}
    valid_args_map = {
        DesignType.PAGE: {"parent_page", "open_action", "save_action", "content_type"},
        DesignType.RESOURCE: {"content_type"},
    }
    valid_args = valid_args_map.get(design_type, set())
    if not _kwarg_keys.issubset(valid_args):
        invalid_keys = _kwarg_keys - valid_args
        logger.error(
            f"Invalid arguments provided for type '{design_type.name}': {invalid_keys}"
        )
        return False
    return True


async def _acreate_or_update_obj(
    workspace: Workspace,
    app_designer: AppDesigner,
    obj: DesignObject,
    recreate_params: bool,
) -> int:
    ok = await obj.acreate_or_update(app_designer)
    if ok:
        if recreate_params and obj.params:
            # No way to know if this way successful for not so
            # assume success always i guess
            await app_designer.aclear_design_object_params(obj.id)
            # Create the params again, hopefully clearing them worked
            # and we dont get duplicates
            await obj.acreate_params(app_designer)
        await asyncio.to_thread(obj.save, workspace)
    return 0 if ok else 1


async def _acreate_or_update_objects(
    workspace: Workspace,
    server: PuakmaServer,
    objs: Iterable[DesignObject],
    recreate_params: bool,
) -> int:
    async with server as s:
        await s.server_designer.ainitiate_connection()
        tasks = []
        for obj in objs:
            task = asyncio.create_task(
                _acreate_or_update_obj(workspace, s.app_designer, obj, recreate_params)
            )
            tasks.append(task)
        ret = 0
        for done in asyncio.as_completed(tasks):
            try:
                ret |= await done
            except (asyncio.CancelledError, Exception):
                for task in tasks:
                    task.cancel()
                raise
        return ret


def _validate_update_objs(
    workspace: Workspace,
    server: PuakmaServer,
    design_obj_ids: list[int],
    *,
    yes: bool = False,
    **kwargs: Any,
) -> tuple[tuple[DesignObject, ...], bool]:
    _universal_keys = ("name", "design_type", "comment", "inherit_from")
    objs = []
    rows = []
    for obj_id in design_obj_ids:
        _, obj = workspace.lookup_design_obj(server, obj_id)
        non_universal_kwargs = dict(kwargs)
        for k in _universal_keys:
            non_universal_kwargs.pop(k)
        if not _validate_args_for_type(obj.design_type, **non_universal_kwargs):
            exit(1)
        row_headers = ["ID", "Application", "Name"]
        row = [str(obj.id), str(obj.app), obj.name]
        param_name_map = {
            "open_action": "OpenAction",
            "save_action": "SaveAction",
            "parent_page": "ParentPage",
        }
        recreate_params = False
        for key, value in kwargs.items():
            if hasattr(obj, key) and value is not None:
                row_headers.append(Colour.colour(f"new_{key}", Colour.YELLOW))
                row.append(f"{getattr(obj, key)} -> {value}")
                if key in param_name_map:
                    param = DesignObjectParam(param_name_map[key], value)
                    obj.update_or_append_param(param)
                    recreate_params = True
                else:
                    setattr(obj, key, value)
        rows.append(row)
        objs.append(obj)

    _updated = Colour.colour("UPDATED", Colour.GREEN)
    print(f"The following Design Object(s) will be {_updated}:\n")
    print(tabulate.tabulate(rows, headers=row_headers))
    if not yes and input("\n[Y/y] to continue:") not in ["Y", "y"]:
        exit(1)

    return tuple(objs), recreate_params


def _update_objects(
    workspace: Workspace,
    server: PuakmaServer,
    design_obj_ids: list[int],
    *,
    yes: bool = False,
    **kwargs: Any,
) -> int:
    try:
        updated_objs, recreate_params = _validate_update_objs(
            workspace, server, design_obj_ids, yes=yes, **kwargs
        )
    except (DesignObjectNotFound, DesignObjectAmbiguousError) as e:
        logger.error(e)
        return 1

    with workspace.exclusive_lock():
        ret = asyncio.run(
            _acreate_or_update_objects(workspace, server, updated_objs, recreate_params)
        )
        apps = {obj.app for obj in updated_objs}
        for app in apps:
            new_app_objs = [obj for obj in updated_objs if obj.app == app]
            for new_obj in new_app_objs:
                idx, _ = app.lookup_design_obj(new_obj.name)
                app.design_objects[idx] = new_obj
            workspace.mkdir(app)
        return ret


def _new_object(
    workspace: Workspace,
    server: PuakmaServer,
    name: str,
    app_id: int,
    design_type: DesignType,
    content_type: str | None = None,
    comment: str | None = None,
    inherit_from: str | None = None,
    parent_page: str | None = None,
    open_action: str | None = None,
    save_action: str | None = None,
    *,
    yes: bool = False,
) -> int:
    if not _validate_args_for_type(
        design_type,
        parent_page=parent_page,
        open_action=open_action,
        save_action=save_action,
    ):
        return 1

    _show_params = True if parent_page or open_action or save_action else False
    app = workspace.lookup_app(server, app_id)
    try:
        objs = _prepare_new_objects(
            name,
            app,
            design_type,
            content_type,
            comment,
            inherit_from,
            parent_page,
            open_action,
            save_action,
        )
    except (ValueError, DesignObjectAmbiguousError) as e:
        logger.error(e)
        return 1
    _created = Colour.colour("CREATED", Colour.GREEN)
    print(f"The following Design Object(s) will be {_created}:\n")
    render_objects(objs, show_params=_show_params)
    if not yes and input("\n[Y/y] to continue:") not in ["Y", "y"]:
        return 1

    recreate_params = True if parent_page or open_action or save_action else False
    with workspace.exclusive_lock():
        asyncio.run(
            _acreate_or_update_objects(workspace, server, objs, recreate_params)
        )
        app.design_objects.extend(objs)
        workspace.mkdir(app)
        return 0


def _new_app(
    server: PuakmaServer,
    group: str,
    name: str,
    inherit_from: str | None,
    template_name: str | None,
    description: str | None,
    *,
    yes: bool = False,
) -> int:
    app = PuakmaApplication(-1, name, group, inherit_from, template_name, server.host)
    print("The following Application will be created:\n")
    render_apps([app], show_inherited=True)
    if not yes and input("\n[Y/y] to continue:") not in ["Y", "y"]:
        return 1

    with server as s:
        app.id = s.app_designer.save_application(
            app.id,
            app.group,
            app.name,
            app.inherit_from,
            app.template_name,
            description,
        )
    logger.info(f"Created Application {app} [{app.id}]")
    return 0


def _new_keyword(
    workspace: Workspace,
    server: PuakmaServer,
    app_id: int,
    name: str,
    values: list[str],
) -> int:
    app = workspace.lookup_app(server, app_id)
    with server as s:
        keyword_id = s.app_designer.save_keyword(app.id, -1, name, values)
    logger.info(f"Created Keyword '{name}' [{keyword_id}]")
    return 0


def _pick_from_list(prompt: str, options: list[str]) -> str:
    print(f"\n{prompt}")
    for i, option in enumerate(options, 1):
        print(f"  {i}. {option}")
    while True:
        choice = input("Enter number: ").strip()
        try:
            idx = int(choice)
            if 1 <= idx <= len(options):
                return options[idx - 1]
        except ValueError:
            pass
        print(f"Invalid choice. Please enter a number between 1 and {len(options)}.")


def _new_object_wizard(
    workspace: Workspace,
    server: PuakmaServer,
    *,
    yes: bool = False,
) -> int:
    # Step 1: List locally cloned apps for user to pick from
    print("Creating a new Design Object...\n")
    apps = workspace.listapps(server)
    if not apps:
        logger.error(
            "No locally cloned applications found. Run 'vortex clone <app_id>' first."
        )
        return 1

    app_labels = [f"[{app.id}] {app}" for app in apps]
    chosen_label = _pick_from_list("Select an application:", app_labels)
    chosen_idx = app_labels.index(chosen_label)
    chosen_app = apps[chosen_idx]

    # Reload the app from local workspace to get design objects
    app = workspace.lookup_app(server, chosen_app.id)

    # Step 2: Pick design type
    design_type_names = [t.name.lower() for t in DesignType if t != DesignType.ERROR]
    chosen_type_name = _pick_from_list("Select a design type:", design_type_names)
    design_type = DesignType.from_name(chosen_type_name)

    # Step 3: Ask for name
    name = ""
    while not name.strip():
        name = input("\nEnter object name: ").strip()
        if not name:
            print("Name cannot be empty.")

    # Step 4: content_type — RESOURCE only (PAGE auto-sets text/html, others don't support it)
    content_type = None
    if design_type == DesignType.RESOURCE:
        content_type = input(
            "Enter content type (e.g. text/javascript, text/css): "
        ).strip()
        if not content_type:
            logger.error("Content type is required for resource type.")
            return 1

    # Step 5: parent_page, open_action, save_action — PAGE only
    parent_page = None
    open_action = None
    save_action = None
    if design_type == DesignType.PAGE:
        parent_page = (
            input("Enter parent page (optional, press Enter to skip): ").strip() or None
        )
        open_action = (
            input("Enter open action (optional, press Enter to skip): ").strip() or None
        )
        save_action = (
            input("Enter save action (optional, press Enter to skip): ").strip() or None
        )

    return _new_object(
        workspace,
        server,
        name=name,
        app_id=app.id,
        design_type=design_type,
        content_type=content_type,
        parent_page=parent_page,
        open_action=open_action,
        save_action=save_action,
        yes=yes,
    )


def _new_app_wizard(
    server: PuakmaServer,
    *,
    yes: bool = False,
) -> int:
    print("Creating a new Application...\n")

    # Step 1: Ask for app name
    name = ""
    while not name.strip():
        name = input("Enter application name: ").strip()
        if not name:
            print("Name cannot be empty.")

    # Step 2: Ask for group (show existing groups if available)
    # Note: Do NOT use 'with server as s:' here — the context manager closes the
    # underlying httpx client on exit, which would break the subsequent _new_app() call.
    try:
        apps = server.fetch_all_apps([], [], [], False, False, False)
        existing_groups = sorted({app.group for app in apps if app.group})
        if existing_groups:
            print("\nExisting groups:")
            for i, group in enumerate(existing_groups, 1):
                print(f"  {i}. {group}")
            print(f"  {len(existing_groups) + 1}. (enter a new group)")
            while True:
                choice = input("Enter number or group name: ").strip()
                try:
                    idx = int(choice)
                    if 1 <= idx <= len(existing_groups):
                        group = existing_groups[idx - 1]
                        break
                    elif idx == len(existing_groups) + 1:
                        group = input("Enter new group name: ").strip()
                        break
                except ValueError:
                    group = choice
                    break
                print(
                    f"Invalid choice. Please enter a number between "
                    f"1 and {len(existing_groups) + 1}, or a group name."
                )
        else:
            group = input("Enter application group: ").strip()
    except Exception:
        group = input("Enter application group: ").strip()

    # Step 3: Ask for optional description
    description = (
        input("Enter description (optional, press Enter to skip): ").strip() or None
    )

    return _new_app(
        server,
        group,
        name,
        inherit_from=None,
        template_name=None,
        description=description,
        yes=yes,
    )


def new(workspace: Workspace, server: PuakmaServer, args: argparse.Namespace) -> int:
    yes = getattr(args, "yes", False)
    if args.subcommand in ("obj", "object"):
        if getattr(args, "update_ids", None):
            return _update_objects(
                workspace,
                server,
                args.update_ids,
                yes=yes,
                name=args.name,
                design_type=args.design_type,
                content_type=args.content_type,
                comment=args.comment,
                inherit_from=args.inherit_from,
                parent_page=args.parent_page,
                open_action=args.open_action,
                save_action=args.save_action,
            )
        elif not (args.name and args.app_id and args.design_type):
            return _new_object_wizard(workspace, server, yes=yes)
        else:
            return _new_object(
                workspace,
                server,
                name=args.name,
                app_id=args.app_id,
                design_type=args.design_type,
                content_type=args.content_type,
                comment=args.comment,
                inherit_from=args.inherit_from,
                parent_page=args.parent_page,
                open_action=args.open_action,
                save_action=args.save_action,
                yes=yes,
            )
    elif args.subcommand == "app":
        if not (args.name and args.group):
            return _new_app_wizard(server, yes=yes)
        return _new_app(
            server,
            args.group,
            args.name,
            args.inherit_from,
            args.template,
            args.description,
            yes=yes,
        )
    elif args.subcommand in ("kw", "keyword"):
        return _new_keyword(
            workspace,
            server,
            args.app_id,
            args.name,
            args.values,
        )
    raise NotImplementedError(f"Subcommand '{args.subcommand}' is not implemented.")
