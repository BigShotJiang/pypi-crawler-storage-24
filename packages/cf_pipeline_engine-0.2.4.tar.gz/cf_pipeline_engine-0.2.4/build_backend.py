"""PEP 517 backend wrapper for cf_pipeline_engine.

On Windows, local editable installs must use the MSVC toolchain so downstream
linking stays compatible with the packaged cf_datahive native consumer surface.
"""

from __future__ import annotations

import os
import subprocess
import sys
from typing import Any

from scikit_build_core import build as _backend


_WINDOWS_PATH_BLOCKLIST = ("msys64", "mingw", "rtools")
_MSVC_VCVARS_CANDIDATES = (
    ("ProgramFiles(x86)", r"Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"),
    ("ProgramFiles", r"Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"),
    ("ProgramFiles(x86)", r"Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"),
    ("ProgramFiles", r"Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"),
)
_MSVC_ENV_READY = False


def _is_windows() -> bool:
    return sys.platform.startswith("win")


def _scrub_conflicting_path_entries() -> None:
    current_path = os.environ.get("PATH", "")
    if not current_path:
        return

    filtered_parts: list[str] = []
    seen: set[str] = set()
    for entry in current_path.split(";"):
        normalized = entry.strip()
        if not normalized:
            continue
        lowered = normalized.lower()
        if any(blocked in lowered for blocked in _WINDOWS_PATH_BLOCKLIST):
            continue
        if lowered in seen:
            continue
        seen.add(lowered)
        filtered_parts.append(normalized)
    os.environ["PATH"] = ";".join(filtered_parts)


def _find_vcvars64() -> str | None:
    for env_key, suffix in _MSVC_VCVARS_CANDIDATES:
        root = os.environ.get(env_key)
        if not root:
            continue
        expanded = os.path.join(root, suffix)
        if os.path.exists(expanded):
            return expanded
    return None


def _load_vcvars_environment(vcvars_path: str) -> None:
    completed = subprocess.run(
        f'call "{vcvars_path}" && set',
        check=True,
        capture_output=True,
        text=True,
        shell=True,
    )
    for line in completed.stdout.splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ[key] = value
    os.environ["CC"] = "cl"
    os.environ["CXX"] = "cl"


def _ensure_windows_msvc_toolchain() -> None:
    global _MSVC_ENV_READY

    if _MSVC_ENV_READY or not _is_windows():
        return

    if os.environ.get("CC", "").lower() == "cl" and os.environ.get("CXX", "").lower() == "cl":
        _MSVC_ENV_READY = True
        return

    _scrub_conflicting_path_entries()
    vcvars_path = _find_vcvars64()
    if vcvars_path is None:
        _MSVC_ENV_READY = True
        return

    _load_vcvars_environment(vcvars_path)
    _MSVC_ENV_READY = True


def _call_backend(name: str, *args: Any, **kwargs: Any) -> Any:
    _ensure_windows_msvc_toolchain()
    return getattr(_backend, name)(*args, **kwargs)


def build_wheel(wheel_directory: str, config_settings: Any = None, metadata_directory: str | None = None) -> str:
    return _call_backend("build_wheel", wheel_directory, config_settings, metadata_directory)


def build_editable(wheel_directory: str, config_settings: Any = None, metadata_directory: str | None = None) -> str:
    return _call_backend("build_editable", wheel_directory, config_settings, metadata_directory)


def build_sdist(sdist_directory: str, config_settings: Any = None) -> str:
    return _call_backend("build_sdist", sdist_directory, config_settings)


def get_requires_for_build_wheel(config_settings: Any = None) -> list[str]:
    return _call_backend("get_requires_for_build_wheel", config_settings)


def get_requires_for_build_editable(config_settings: Any = None) -> list[str]:
    return _call_backend("get_requires_for_build_editable", config_settings)


def get_requires_for_build_sdist(config_settings: Any = None) -> list[str]:
    return _call_backend("get_requires_for_build_sdist", config_settings)


def prepare_metadata_for_build_wheel(metadata_directory: str, config_settings: Any = None) -> str:
    return _call_backend("prepare_metadata_for_build_wheel", metadata_directory, config_settings)


def prepare_metadata_for_build_editable(metadata_directory: str, config_settings: Any = None) -> str:
    return _call_backend("prepare_metadata_for_build_editable", metadata_directory, config_settings)