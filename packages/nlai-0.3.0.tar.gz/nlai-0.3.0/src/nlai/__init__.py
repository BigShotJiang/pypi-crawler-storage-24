# SPDX-License-Identifier: Apache-2.0
"""NLAI: evidence-gated claims, continuity anchors, and receipts for agent workflows.

Language is a proposal, not an authority.

Public API:
    gate(text, *, anchors=None, prior_claims=None) → GateResult
    GateResult, Receipt, Anchor, Claim, Violation, Evidence
    attach_evidence, contest_claim, find_contradictions
    canonical_json, content_hash, verify_receipt
"""

from .anchors import Anchor, Violation, check_text
from .canonical import canonical_json, content_hash, subject_hash
from .claims import Claim, extract_claims, assertiveness_score, attach_evidence, contest_claim
from .contradictions import find_contradictions
from .evidence import Evidence, VALID_EVIDENCE_KINDS
from .gate import GateResult, gate
from .receipt import Receipt, create_receipt, verify_receipt
from .resolver import resolve_verdict

__all__ = [
    # The gate function
    "gate",
    # Data types
    "GateResult",
    "Receipt",
    "Anchor",
    "Claim",
    "Violation",
    "Evidence",
    # Evidence operations
    "VALID_EVIDENCE_KINDS",
    "attach_evidence",
    "contest_claim",
    "find_contradictions",
    # Utilities
    "canonical_json",
    "content_hash",
    "subject_hash",
    "verify_receipt",
    "create_receipt",
    "extract_claims",
    "assertiveness_score",
    "check_text",
    "resolve_verdict",
]
