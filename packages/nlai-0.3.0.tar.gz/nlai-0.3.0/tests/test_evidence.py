# SPDX-License-Identifier: Apache-2.0
"""Tests for Evidence dataclass."""

import pytest

from nlai import Evidence, VALID_EVIDENCE_KINDS


class TestEvidence:
    """Evidence dataclass behavior."""

    def test_frozen(self):
        e = Evidence(kind="receipt", reference="abc123")
        with pytest.raises(AttributeError):
            e.kind = "other"  # type: ignore[misc]

    def test_invalid_kind(self):
        with pytest.raises(ValueError, match="Invalid evidence kind"):
            Evidence(kind="magic", reference="abc")

    def test_empty_reference(self):
        with pytest.raises(ValueError, match="non-empty"):
            Evidence(kind="receipt", reference="")

    def test_empty_source_ok(self):
        e = Evidence(kind="receipt", reference="abc123")
        assert e.source == ""

    def test_all_valid_kinds(self):
        for kind in VALID_EVIDENCE_KINDS:
            e = Evidence(kind=kind, reference="ref")
            assert e.kind == kind

    def test_to_dict(self):
        e = Evidence(kind="citation", reference="https://example.com", source="web")
        d = e.to_dict()
        assert d == {"kind": "citation", "reference": "https://example.com", "source": "web"}

    def test_roundtrip(self):
        e = Evidence(kind="test_result", reference="exit 0", source="pytest")
        d = e.to_dict()
        e2 = Evidence.from_dict(d)
        assert e == e2

    def test_from_dict_missing_source(self):
        d = {"kind": "receipt", "reference": "abc123"}
        e = Evidence.from_dict(d)
        assert e.source == ""
