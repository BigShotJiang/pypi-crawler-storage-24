# SPDX-License-Identifier: Apache-2.0
"""Golden fixture parity tests.

These tests verify that nlai's canonical JSON and content hashing
produce byte-identical results to governor's canonical vectors.

The vectors in tests/fixtures/canonical_vectors.json are vendored
from agent_gov/libs/receipt_v1/tests/data/canonical_vectors.json.
If governor updates its vectors, these tests will fail, forcing
an explicit update (not silent drift).
"""

import json
from pathlib import Path

import pytest

from nlai import canonical_json, content_hash, verify_receipt, Receipt

FIXTURES = Path(__file__).parent / "fixtures"
VECTORS = json.loads((FIXTURES / "canonical_vectors.json").read_text())


class TestCanonicalVectorParity:
    """Byte-for-byte parity with governor's canonical JSON vectors."""

    @pytest.mark.parametrize(
        "vector",
        VECTORS["vectors"],
        ids=[v["name"] for v in VECTORS["vectors"]],
    )
    def test_canonical_json_matches(self, vector):
        """canonical_json(input) == expected canonical UTF-8 bytes."""
        result = canonical_json(vector["input"])
        expected = vector["canonical_utf8"].encode("utf-8")
        assert result == expected, (
            f"Vector {vector['name']}: "
            f"got {result!r}, expected {expected!r}"
        )

    @pytest.mark.parametrize(
        "vector",
        VECTORS["vectors"],
        ids=[v["name"] for v in VECTORS["vectors"]],
    )
    def test_content_hash_matches(self, vector):
        """content_hash(canonical_bytes) == expected SHA-256 hex."""
        canonical_bytes = vector["canonical_utf8"].encode("utf-8")
        result = content_hash(canonical_bytes)
        assert result == vector["sha256"], (
            f"Vector {vector['name']}: "
            f"got {result}, expected {vector['sha256']}"
        )

    @pytest.mark.parametrize(
        "vector",
        VECTORS["vectors"],
        ids=[v["name"] for v in VECTORS["vectors"]],
    )
    def test_roundtrip_hash(self, vector):
        """canonical_json(input) → content_hash matches expected SHA-256."""
        result_bytes = canonical_json(vector["input"])
        result_hash = content_hash(result_bytes)
        assert result_hash == vector["sha256"]


class TestCrossVersionReceipt:
    """Frozen receipt from 0.1.0 must still verify with current code."""

    def test_v010_receipt_verifies(self):
        """Receipt created with 0.1.0-style evidence still verifies."""
        fixture = json.loads((FIXTURES / "receipt_v010.json").read_text())
        receipt = Receipt.from_dict(fixture)
        assert verify_receipt(receipt) is True

    def test_v010_receipt_id_stable(self):
        """Receipt ID hasn't changed across versions."""
        fixture = json.loads((FIXTURES / "receipt_v010.json").read_text())
        receipt = Receipt.from_dict(fixture)
        assert receipt.receipt_id == fixture["receipt_id"]

    def test_v010_evidence_hash_reproducible(self):
        """Can reproduce evidence_hash from the frozen evidence dict."""
        fixture = json.loads((FIXTURES / "receipt_v010.json").read_text())
        evidence_bytes = canonical_json(fixture["evidence"])
        evidence_hash = content_hash(evidence_bytes)
        assert evidence_hash == fixture["evidence_hash"]

    def test_v010_subject_hash_reproducible(self):
        """Can reproduce subject_hash from the frozen subject text."""
        from nlai.canonical import subject_hash
        fixture = json.loads((FIXTURES / "receipt_v010.json").read_text())
        s_hash = subject_hash("text", fixture["subject_text"].encode("utf-8"))
        assert s_hash == fixture["subject_hash"]
