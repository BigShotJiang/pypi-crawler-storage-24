from . import models

class RipeRestApiError(Exception):
    pass

class RipeRestApiServerError(RipeRestApiError):
    def __init__(self, http_status: int, messages: models.ErrorMessages | None):
        self.http_status = http_status
        self.ripe_messages = messages

class RipeRestApiInvalidPrimaryKeyError(RipeRestApiError):
    pass

class RipeRestApiUnexpectedResponseError(RipeRestApiError):
    def __init__(self, response: models.WhoisResources):
        self.response = response

class RipeRestApiUnexpectedInputError(RipeRestApiError):
    pass
