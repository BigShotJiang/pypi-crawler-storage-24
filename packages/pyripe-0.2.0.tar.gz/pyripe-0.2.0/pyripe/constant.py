from typing import Literal, Dict

RipeSource = Literal["TEST", "RIPE"]

API_ENDPOINT: Dict[RipeSource, str] = {
    "TEST": "https://rest-test.db.ripe.net",
    "RIPE": "https://rest.db.ripe.net"
}

PRIMARY_OBJECTS_TYPE = [
    "aut-num",
    "domain",
    "inet6num",
    "inetnum",
    "route",
    "route6",
    "as-set",
    "filter-set",
    "inet-rtr",
    "peering-set",
    "route-set",
    "rtr-set"
]
PrimaryRipeObjectType = Literal[*PRIMARY_OBJECTS_TYPE]

SECONDARY_OBJECTS_TYPE = [
    "as-block",
    "irt",
    "key-cert",
    "mntner",
    "organisation",
    "person",
    "poem",
    "poetic-form",
    "role"
]
SecondaryRipeObjectType = Literal[*SECONDARY_OBJECTS_TYPE]

ALL_OBJECTS_TYPE = PRIMARY_OBJECTS_TYPE + SECONDARY_OBJECTS_TYPE
RipeObjectType = Literal[*ALL_OBJECTS_TYPE]
