from __future__ import annotations

import sys
from typing import TextIO

from .profiler import RequestProfiler
from .render import render_trace


class WaterfallMiddleware:
    def __init__(
        self,
        app,
        *,
        stream: TextIO | None = None,
        width: int = 60,
        hotspot_count: int = 5,
        max_nodes: int = 5000,
        collapse_below_percent: float = 0.1,
        collapse_chain_self_below_percent: float = 0.1,
        include_paths: list[str] | None = None,
        exclude_paths: list[str] | None = None,
    ) -> None:
        self.app = app
        self.stream = stream if stream is not None else sys.stdout
        self.width = width
        self.hotspot_count = hotspot_count
        self.max_nodes = max_nodes
        self.collapse_below_percent = collapse_below_percent
        self.collapse_chain_self_below_percent = (
            collapse_chain_self_below_percent
        )
        self.include_paths = include_paths
        self.exclude_paths = exclude_paths

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        method = scope.get("method", "HTTP")
        path = scope.get("path", "/")
        status_code = 500
        profiler = RequestProfiler(
            method,
            path,
            max_nodes=self.max_nodes,
            include_paths=self.include_paths,
            exclude_paths=self.exclude_paths,
        )

        async def send_wrapper(message) -> None:
            nonlocal status_code
            if message["type"] == "http.response.start":
                status_code = message["status"]
            await send(message)

        profiler.start()
        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            trace = profiler.stop(status_code=status_code)
            self.stream.write(
                render_trace(
                    trace,
                    width=self.width,
                    hotspot_count=self.hotspot_count,
                    collapse_below_percent=self.collapse_below_percent,
                    collapse_chain_self_below_percent=(
                        self.collapse_chain_self_below_percent
                    ),
                )
            )
            self.stream.write("\n")
            self.stream.flush()
