"""
保险客户分析MCP服务器 - 基于CoT思维链的客户价值评估
"""
import json
import logging
import os
from typing import Dict, Any, List, Optional

from mcp.server.fastmcp import FastMCP
from insurance_analysis_mcp.analyzer import InsuranceCustomerAnalyzer

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("insurance-analysis-mcp")

mcp = FastMCP(
    "insurance-analysis-mcp",
    instructions="""这是一个保险客户分析工具，使用CoT（Chain of Thought）思维链进行客户价值评估。

功能包括：
1. 分析客户挽回价值和续保概率
2. 提供详细的多维度分析报告
3. 生成可执行的行动建议

使用方法：
- 调用 analyze_customer_retention_value 工具来分析客户是否值得挽留
- 需要提供客户基本信息、保单数据和理赔记录

【重要：参数传递规范】
    三个参数均为 JSON 对象（dict），具体结构如下：

    customer_data（必填）= {
        "customer_id": "C00000001",
        "name": "张三",
        "level": "VIP",
        "total_premium": 125000.00,
        "registration_date": "2020-01-15"
    }

    policy_data（选填）= {
        "policies": [
            {"policy_id": "P001", "policy_type": "寿险", "premium": 50000, "end_date": "2025-12-31"},
            {"policy_id": "P002", "policy_type": "车险", "premium": 8000, "end_date": "2025-06-30"}
        ]
    }

    claim_data（选填）= {
        "claims": [
            {"claim_id": "CLM001", "claim_amount": 15000, "claim_date": "2024-03-20", "status": "已结案"}
        ]
    }

    工具会自动处理以下格式差异：
    - 数字字符串 → 数值（"125000.00" → 125000.0）
    - 包装字典   → 列表（{"policies": [...]} → [...]）
    - 纯列表     → 直接使用（[{...}, {...}]）
    - 单条记录   → 列表（{...} → [{...}]）
    - JSON字符串 → 解析后处理

    无需模型手动转换，直接传递数据库原始返回值即可。
"""
)

analyzer = InsuranceCustomerAnalyzer()


@mcp.tool()
async def analyze_customer_retention_value(
    customer_data: Dict[str, Any],
    policy_data: Optional[Any] = None,
    claim_data: Optional[Any] = None
) -> str:
    """
    分析客户挽回价值和续保概率。

    本工具接收客户信息、保单数据、理赔数据，通过 CoT 思维链进行多维度分析，
    输出包含价值评估、风险评估、忠诚度评估、潜力评估的完整报告。

    Args:
        customer_data: 客户基本信息（必填），应为字典，包含以下字段：
            - customer_id (str): 客户ID，如 "C00000001"
            - name (str): 客户姓名
            - level (str): 客户等级，如 "VIP" / "普通" / "潜力"
            - total_premium (number|str): 累计保费，数值或数字字符串均可
            - registration_date (str): 注册日期，如 "2020-01-15"

        policy_data: 保单数据（选填），支持以下任意格式（工具自动识别并转换）：
            - 推荐格式：{"policies": [{"policy_id":"P001", "policy_type":"寿险", "premium":50000, "end_date":"2025-12-31"}, ...]}
            - 纯列表：[{"policy_id":"P001", ...}, ...]
            - 单条记录：{"policy_id":"P001", ...}
            - null 或不传：视为无保单数据

        claim_data: 理赔数据（选填），支持以下任意格式（工具自动识别并转换）：
            - 推荐格式：{"claims": [{"claim_id":"CLM001", "claim_amount":15000, "claim_date":"2024-03-20"}, ...]}
            - 纯列表：[{"claim_id":"CLM001", ...}, ...]
            - 单条记录：{"claim_id":"CLM001", ...}
            - null 或不传：视为无理赔数据

    Returns:
        JSON格式的详细分析报告，包含分析过程和最终建议
    """
    try:
        customer_data = _ensure_dict(customer_data, "customer_data")
        policy_list = _unwrap_to_list(policy_data, "policy_data")
        claim_list = _unwrap_to_list(claim_data, "claim_data")

        logger.info(f"开始分析客户 {customer_data.get('customer_id', 'unknown')}")

        result = await analyzer.analyze_customer_retention_value(
            customer_data=customer_data,
            policy_data=policy_list,
            claim_data=claim_list
        )

        logger.info(f"完成分析客户 {customer_data.get('customer_id', 'unknown')}")
        return result

    except ValueError as e:
        logger.error(f"参数格式错误: {e}")
        return json.dumps({
            "success": False,
            "error": f"参数格式错误: {e}",
            "hint": "请检查参数格式。customer_data 应为字典；policy_data 推荐格式为 {\"policies\": [...]}；claim_data 推荐格式为 {\"claims\": [...]}"
        }, ensure_ascii=False, indent=2)

    except Exception as e:
        logger.error(f"分析发生错误: {e}", exc_info=True)
        return json.dumps({
            "success": False,
            "error": f"分析过程中发生错误: {e}"
        }, ensure_ascii=False, indent=2)


def _ensure_dict(value: Any, field_name: str) -> Dict[str, Any]:
    """将 str / dict 安全转换为 dict，其他类型抛出 ValueError"""
    if value is None:
        raise ValueError(f"{field_name} 不能为空")
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        value = value.strip()
        if not value:
            raise ValueError(f"{field_name} 不能为空字符串")
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
            raise ValueError(f"{field_name} JSON解析后不是对象类型，实际类型: {type(parsed).__name__}")
        except json.JSONDecodeError as e:
            raise ValueError(f"{field_name} 不是合法JSON: {e}")
    raise ValueError(f"{field_name} 类型不支持: {type(value).__name__}，期望 dict 或 JSON 字符串")


def _unwrap_to_list(value: Any, field_name: str) -> List[Dict[str, Any]]:
    """
    智能解包：将各种格式统一转换为 List[Dict]

    支持：
    - None / 空字符串               → []
    - [...]                         → 直接使用（过滤非dict元素）
    - {"policies":[...]}            → 取列表值（自动识别包装键）
    - {"claims":[...]}              → 取列表值
    - {"policy_id":..., ...}        → 包装为 [单条记录]
    - '[{...}]' JSON字符串          → 解析后递归处理
    """
    if value is None:
        return []

    if isinstance(value, str):
        value = value.strip()
        if not value:
            return []
        try:
            value = json.loads(value)
        except json.JSONDecodeError as e:
            raise ValueError(f"{field_name} 不是合法JSON: {e}")

    if isinstance(value, list):
        result: List[Dict[str, Any]] = []
        for i, item in enumerate(value):
            if isinstance(item, dict):
                result.append(item)
            elif isinstance(item, str):
                try:
                    parsed = json.loads(item)
                    if isinstance(parsed, dict):
                        result.append(parsed)
                        logger.info(f"✅ {field_name}[{i}] JSON字符串已解析为dict")
                    else:
                        logger.warning(f"⚠️ {field_name}[{i}] JSON解析后非dict，已跳过")
                except json.JSONDecodeError:
                    logger.warning(f"⚠️ {field_name}[{i}] 不是合法JSON字符串，已跳过: {repr(item)[:80]}")
            else:
                logger.warning(f"⚠️ {field_name}[{i}] 类型为 {type(item).__name__}，已跳过")
        return result

    if isinstance(value, dict):
        WRAPPER_KEYS = {"policies", "claims", "data", "items", "records", "list"}
        for key in WRAPPER_KEYS:
            if key in value and isinstance(value[key], list):
                logger.info(f"✅ {field_name} 自动解包包装键 '{key}'，共 {len(value[key])} 条")
                return [item for item in value[key] if isinstance(item, dict)]

        logger.info(f"✅ {field_name} 收到单条记录，自动包装为列表")
        return [value]

    raise ValueError(
        f"{field_name} 类型不支持: {type(value).__name__}，"
        f"请传入列表、字典或JSON字符串"
    )


@mcp.tool()
async def get_analysis_framework_info() -> str:
    """
    获取分析框架信息，包括使用的CoT思维链方法说明
    """
    framework_info = {
        "framework_name": "Insurance Customer Analysis with CoT Reasoning",
        "methodology": "Chain of Thought (CoT)",
        "analysis_steps": [
            {
                "step": 1,
                "name": "需求理解",
                "description": "明确用户想分析什么，识别需要调用的数据"
            },
            {
                "step": 2,
                "name": "数据收集与整理",
                "description": "获取客户、保单、理赔等基础数据并计算关键指标"
            },
            {
                "step": 3,
                "name": "多维度分析",
                "dimensions": [
                    "价值贡献评估",
                    "风险水平评估",
                    "客户忠诚度评估",
                    "未来发展潜力评估"
                ]
            },
            {
                "step": 4,
                "name": "综合判断",
                "description": "基于加权评分给出总体评价和挽留建议"
            },
            {
                "step": 5,
                "name": "行动建议",
                "description": "提供具体的优先行动项和ROI预估"
            }
        ],
        "evaluation_criteria": {
            "value_contribution": "年化保费、VIP状态、保单数量",
            "risk_assessment": "理赔率、理赔频次",
            "loyalty_evaluation": "合作年限、保单多样性、VIP状态",
            "potential_assessment": "当前价值、产品多样性、到期保单数"
        },
        "output_format": {
            "retention_recommendation": ["重点挽留", "建议挽留", "选择性挽留", "不建议重点挽留"],
            "confidence_level": ["高", "中", "低"],
            "estimated_probability": "百分比形式表示续保可能性"
        }
    }

    return json.dumps(framework_info, ensure_ascii=False, indent=2)


def main():
    """MCP服务器主入口"""
    logger.info("启动保险客户分析MCP服务器...")
    logger.info("服务器支持基于CoT思维链的客户价值评估")

    transport_mode = os.getenv("MCP_TRANSPORT_MODE", "stdio")

    if transport_mode == "sse":
        from mcp.transport.sse import ServerSentEventsTransport
        transport = ServerSentEventsTransport()
        mcp.run(transport=transport)
    else:
        mcp.run()


if __name__ == "__main__":
    main()
