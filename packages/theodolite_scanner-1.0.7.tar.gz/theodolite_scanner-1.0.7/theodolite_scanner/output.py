"""Discovery results JSON builder.

Builds the output JSON from scan findings, compatible with the
Theodolite /discovery/import endpoint.
"""

from __future__ import annotations

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from theodolite_scanner.classifier import Finding


def build_results_json(
    provider: str,
    source: str,
    findings: list[Finding],
    total_assets_discovered: int,
    assets_scanned: int,
    scan_type: str = "full",
    scanner_version: str = "1.0.0",
) -> dict[str, Any]:
    """Build the discovery results JSON from scan findings.

    Args:
        provider: Cloud provider (azure, aws, gcp)
        source: Source identifier (e.g. account URL + container)
        findings: List of Finding objects from classifier
        total_assets_discovered: Total blobs/objects enumerated
        assets_scanned: Number actually scanned
        scan_type: quick, full, incremental, random
        scanner_version: Version string

    Returns:
        Results dict ready for JSON serialization or API upload
    """
    findings_by_category: dict[str, int] = {}
    findings_by_type: dict[str, int] = {}
    findings_by_severity: dict[str, int] = {}
    total_breach_cost = 0

    for f in findings:
        cat = f.category.value
        findings_by_category[cat] = findings_by_category.get(cat, 0) + 1

        dt = f.data_type.value
        findings_by_type[dt] = findings_by_type.get(dt, 0) + 1

        sev = f.severity.value
        findings_by_severity[sev] = findings_by_severity.get(sev, 0) + 1

        total_breach_cost += f.estimated_breach_cost

    return {
        "scanner_version": scanner_version,
        "scan_timestamp": datetime.now(timezone.utc).isoformat(),
        "provider": provider,
        "source": source,
        "scan_type": scan_type,
        "total_assets_discovered": total_assets_discovered,
        "assets_scanned": assets_scanned,
        "total_findings": len(findings),
        "findings_by_category": findings_by_category,
        "findings_by_type": findings_by_type,
        "findings_by_severity": findings_by_severity,
        "estimated_breach_cost": total_breach_cost,
        "findings": [f.to_dict() for f in findings],
    }


def write_results_file(results_dict: dict[str, Any], output_path: str) -> None:
    """Write results dict to a JSON file."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(results_dict, f, indent=2, default=str)
