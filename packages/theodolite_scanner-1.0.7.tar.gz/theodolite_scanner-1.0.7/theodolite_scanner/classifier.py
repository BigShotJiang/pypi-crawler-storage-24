"""Standalone classification engine for detecting sensitive data.

Extracted from the Theodolite server-side classifier for use in the
standalone CLI scanner. Produces results identical to server-side scans.

NER (spaCy) and custom pattern support are optional — install with:
  pip install theodolite-scanner[ner]     # adds spaCy
  pip install theodolite-scanner[all]     # everything
"""

import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional
from uuid import UUID, uuid4

logger = logging.getLogger(__name__)


class DataCategory(str, Enum):
    """Categories of sensitive data."""

    PII = "pii"
    PHI = "phi"
    FINANCIAL = "financial"
    CREDENTIALS = "credentials"
    INTELLECTUAL_PROPERTY = "intellectual_property"
    CUSTOM = "custom"


class DataType(str, Enum):
    """Specific types of sensitive data."""

    # PII
    SSN = "ssn"
    DRIVERS_LICENSE = "drivers_license"
    PASSPORT = "passport"
    EMAIL = "email"
    PHONE = "phone"
    ADDRESS = "address"
    DATE_OF_BIRTH = "date_of_birth"
    FULL_NAME = "full_name"

    # PHI
    MEDICAL_RECORD = "medical_record"
    HEALTH_INSURANCE_ID = "health_insurance_id"
    DIAGNOSIS_CODE = "diagnosis_code"

    # Financial
    CREDIT_CARD = "credit_card"
    BANK_ACCOUNT = "bank_account"
    ROUTING_NUMBER = "routing_number"
    TAX_ID = "tax_id"

    # Credentials
    API_KEY = "api_key"
    PASSWORD = "password"
    SSH_KEY = "ssh_key"
    OAUTH_TOKEN = "oauth_token"
    PRIVATE_KEY = "private_key"

    # Custom
    CUSTOM = "custom"


class Severity(str, Enum):
    """Severity levels based on data type sensitivity."""

    CRITICAL = "critical"  # PHI, background checks
    HIGH = "high"  # SSN, financial
    MEDIUM = "medium"  # Credit cards (PCI regulated)
    LOW = "low"  # Email, phone
    INFO = "info"  # Non-sensitive matches


# Estimated breach cost per record by data type (IBM Data Breach Report 2024)
BREACH_COST_PER_RECORD = {
    # PHI is most expensive - HIPAA violations
    DataType.MEDICAL_RECORD: 400,
    DataType.HEALTH_INSURANCE_ID: 400,
    DataType.DIAGNOSIS_CODE: 350,
    # Background/criminal - FCRA violations
    DataType.PASSPORT: 300,
    DataType.DRIVERS_LICENSE: 250,
    # PII - state privacy laws
    DataType.SSN: 166,
    DataType.DATE_OF_BIRTH: 150,
    DataType.TAX_ID: 150,
    DataType.FULL_NAME: 100,
    DataType.ADDRESS: 100,
    # Financial - PCI-DSS
    DataType.CREDIT_CARD: 150,
    DataType.BANK_ACCOUNT: 150,
    DataType.ROUTING_NUMBER: 100,
    # Credentials - operational impact
    DataType.PRIVATE_KEY: 200,
    DataType.SSH_KEY: 200,
    DataType.API_KEY: 150,
    DataType.OAUTH_TOKEN: 150,
    DataType.PASSWORD: 100,
    # Lower sensitivity
    DataType.EMAIL: 50,
    DataType.PHONE: 50,
    DataType.CUSTOM: 100,
}


def get_severity_for_type(data_type: DataType) -> Severity:
    """Get severity level based on data type."""
    critical_types = {
        DataType.MEDICAL_RECORD,
        DataType.HEALTH_INSURANCE_ID,
        DataType.DIAGNOSIS_CODE,
        DataType.PASSPORT,
    }
    high_types = {
        DataType.SSN,
        DataType.DRIVERS_LICENSE,
        DataType.PRIVATE_KEY,
        DataType.SSH_KEY,
        DataType.TAX_ID,
    }
    medium_types = {
        DataType.CREDIT_CARD,
        DataType.BANK_ACCOUNT,
        DataType.ROUTING_NUMBER,
        DataType.API_KEY,
        DataType.OAUTH_TOKEN,
        DataType.PASSWORD,
        DataType.DATE_OF_BIRTH,
    }
    low_types = {
        DataType.EMAIL,
        DataType.PHONE,
        DataType.ADDRESS,
        DataType.FULL_NAME,
    }

    if data_type in critical_types:
        return Severity.CRITICAL
    elif data_type in high_types:
        return Severity.HIGH
    elif data_type in medium_types:
        return Severity.MEDIUM
    elif data_type in low_types:
        return Severity.LOW
    else:
        return Severity.INFO


@dataclass
class Finding:
    """Represents a single classification finding.

    PRIVACY BY DESIGN: This class stores only location metadata, NOT the actual
    sensitive data. The matched_text is used transiently during scanning for
    validation and deduplication, but is never persisted or transmitted.
    """

    id: UUID
    asset_id: UUID
    data_type: DataType
    category: DataCategory
    severity: Severity
    confidence: float  # 0.0 - 1.0
    location: str  # File path, table name, etc.
    line_number: Optional[int] = None
    column_number: Optional[int] = None
    field_name: Optional[str] = None
    pattern_name: Optional[str] = None
    detected_at: datetime = field(default_factory=datetime.utcnow)

    # Count of occurrences when LOW-severity findings are collapsed per file
    occurrence_count: int = 1

    # TRANSIENT - used during scanning only, never persisted
    _matched_text: str = field(default="", repr=False)

    @classmethod
    def create(
        cls,
        asset_id: UUID,
        data_type: DataType,
        category: DataCategory,
        confidence: float,
        matched_text: str,
        location: str,
        **kwargs: Any,
    ) -> "Finding":
        """Factory method to create a finding."""
        return cls(
            id=uuid4(),
            asset_id=asset_id,
            data_type=data_type,
            category=category,
            severity=get_severity_for_type(data_type),
            confidence=confidence,
            location=location,
            _matched_text=matched_text,
            **kwargs,
        )

    @property
    def matched_text(self) -> str:
        """Access transient matched_text for deduplication (not persisted)."""
        return self._matched_text

    @property
    def estimated_breach_cost(self) -> int:
        """Estimated cost if this record is breached (IBM Data Breach Report)."""
        return BREACH_COST_PER_RECORD.get(self.data_type, 100)

    def to_dict(self) -> dict:
        """Convert to dictionary for output.

        SECURITY: Intentionally excludes all sensitive data — only location metadata.
        """
        return {
            "data_type": self.data_type.value,
            "category": self.category.value,
            "severity": self.severity.value,
            "confidence": self.confidence,
            "location": self.location,
            "line_number": self.line_number,
            "pattern_name": self.pattern_name,
            "estimated_breach_cost": self.estimated_breach_cost,
            "occurrence_count": self.occurrence_count,
        }


@dataclass
class Pattern:
    """A pattern for detecting sensitive data."""

    name: str
    data_type: DataType
    category: DataCategory
    regex: re.Pattern[str]
    validator: Optional[Callable[[str], bool]] = None
    confidence_base: float = 0.8
    context_patterns: List[str] = field(default_factory=list)


@dataclass
class ClassificationConfig:
    """Configuration for the classifier."""

    confidence_threshold: float = 0.75  # Raised from 0.7 to eliminate borderline FPs
    context_window: int = 100
    enable_ner: bool = True
    spacy_model: str = "en_core_web_sm"
    custom_patterns_path: Optional[str] = None
    custom_patterns_dir: Optional[str] = None


class Classifier:
    """Classification engine with pattern, NER, and custom pattern support.

    Matches the server-side classifier behavior so scanner results are
    identical to server-side scans.
    """

    def __init__(self, config: Optional[ClassificationConfig] = None) -> None:
        self.config = config or ClassificationConfig()
        self._patterns: List[Pattern] = []
        self._ner_processor = None
        self._custom_loader = None

        self._load_builtin_patterns()

        # Initialize NER if enabled
        if self.config.enable_ner:
            self._init_ner()

        # Load custom patterns if configured
        if self.config.custom_patterns_path or self.config.custom_patterns_dir:
            self._load_custom_patterns()

    def _load_builtin_patterns(self) -> None:
        """Load built-in detection patterns."""
        from theodolite_scanner.patterns import pii, phi, financial, credentials

        self._patterns.extend(pii.get_patterns())
        self._patterns.extend(phi.get_patterns())
        self._patterns.extend(financial.get_patterns())
        self._patterns.extend(credentials.get_patterns())

    def _init_ner(self) -> None:
        """Initialize the NER processor (requires spaCy)."""
        try:
            from theodolite_scanner.ner import NERProcessor, NERConfig

            ner_config = NERConfig(model_name=self.config.spacy_model)
            self._ner_processor = NERProcessor(config=ner_config)
            logger.info("NER processor initialized")
        except Exception as e:
            logger.warning(f"Could not initialize NER processor: {e}")
            self._ner_processor = None

    def _load_custom_patterns(self) -> None:
        """Load custom patterns from configured paths."""
        try:
            from theodolite_scanner.custom import CustomPatternLoader, CustomPatternConfig
            from pathlib import Path

            config = CustomPatternConfig()
            self._custom_loader = CustomPatternLoader(config=config)

            # Load from file
            if self.config.custom_patterns_path:
                path = Path(self.config.custom_patterns_path).resolve()
                self._custom_loader.load_from_file(path)

            # Load from directory
            if self.config.custom_patterns_dir:
                dir_path = Path(self.config.custom_patterns_dir).resolve()
                self._custom_loader.load_from_directory(dir_path)

            logger.info(f"Loaded {self._custom_loader.pattern_count} custom patterns")

        except Exception as e:
            logger.warning(f"Could not load custom patterns: {e}")
            self._custom_loader = None

    def classify_text(
        self,
        text: str,
        asset_id: Optional[UUID] = None,
        location: str = "unknown",
        categories: Optional[List[str]] = None,
    ) -> List[Finding]:
        """Classify text for sensitive data (synchronous).

        Args:
            text: Text content to classify
            asset_id: ID of the source asset (optional)
            location: Location description for findings
            categories: Optional list of categories to check

        Returns:
            List of findings
        """
        if asset_id is None:
            asset_id = uuid4()

        findings = []

        # Filter patterns by category if specified
        patterns = self._patterns
        if categories:
            category_set = {DataCategory(c) for c in categories}
            patterns = [p for p in patterns if p.category in category_set]

        # Pattern-based detection
        for pattern in patterns:
            pattern_findings = self._find_pattern_matches(
                text=text,
                pattern=pattern,
                asset_id=asset_id,
                location=location,
            )
            findings.extend(pattern_findings)

        # NER-based detection (names, dates, locations that patterns miss)
        if self._ner_processor and self.config.enable_ner:
            ner_findings = self._find_ner_matches(
                text=text,
                asset_id=asset_id,
                location=location,
                categories=categories,
            )
            findings.extend(ner_findings)

        # Custom pattern detection
        if self._custom_loader:
            custom_findings = self._find_custom_matches(
                text=text,
                asset_id=asset_id,
                location=location,
                categories=categories,
            )
            findings.extend(custom_findings)

        # Deduplicate overlapping findings
        findings = self._deduplicate_findings(findings)

        # Filter by confidence threshold
        findings = [
            f for f in findings if f.confidence >= self.config.confidence_threshold
        ]

        # Per-file dedup for LOW severity types (email, phone, address, full_name):
        # Collapse all findings of the same data_type into a single finding with occurrence_count
        findings = self._collapse_low_severity(findings)

        # Per-asset finding cap: if a single file produces >50 findings,
        # keep top 50 by confidence to prevent a single large file from dominating
        if len(findings) > 50:
            logger.warning(
                "Asset %s produced %d findings, capping at 50",
                location, len(findings),
            )
            findings.sort(key=lambda f: -f.confidence)
            findings = findings[:50]

        return findings

    def _find_pattern_matches(
        self,
        text: str,
        pattern: Pattern,
        asset_id: UUID,
        location: str,
    ) -> List[Finding]:
        """Find all matches of a pattern in text."""
        findings = []

        for match in pattern.regex.finditer(text):
            matched_text = match.group()

            # Run validator if present
            if pattern.validator and not pattern.validator(matched_text):
                continue

            # Calculate confidence
            confidence = pattern.confidence_base

            # Boost confidence if context patterns are found
            context_start = max(0, match.start() - self.config.context_window)
            context_end = min(len(text), match.end() + self.config.context_window)
            context = text[context_start:context_end]

            for ctx_pattern in pattern.context_patterns:
                if re.search(ctx_pattern, context, re.IGNORECASE):
                    confidence = min(1.0, confidence + 0.1)

            # Calculate line number
            line_number = text[: match.start()].count("\n") + 1

            finding = Finding.create(
                asset_id=asset_id,
                data_type=pattern.data_type,
                category=pattern.category,
                confidence=confidence,
                matched_text=matched_text,
                location=location,
                line_number=line_number,
                pattern_name=pattern.name,
            )

            findings.append(finding)

        return findings

    def _find_ner_matches(
        self,
        text: str,
        asset_id: UUID,
        location: str,
        categories: Optional[List[str]] = None,
    ) -> List[Finding]:
        """Find matches using NER (Named Entity Recognition)."""
        if not self._ner_processor:
            return []

        findings = []

        try:
            # Process text with NER
            entities = self._ner_processor.process(text)

            # Map to classification findings
            ner_findings = self._ner_processor.map_to_classification(entities, text)

            # Convert to Finding objects
            for nf in ner_findings:
                # Filter by category if specified
                if categories:
                    try:
                        cat = DataCategory(nf["category"])
                        if cat not in {DataCategory(c) for c in categories}:
                            continue
                    except ValueError:
                        continue

                # Map data_type string to enum
                try:
                    data_type = DataType(nf["data_type"])
                except ValueError:
                    data_type = DataType.CUSTOM

                try:
                    category = DataCategory(nf["category"])
                except ValueError:
                    category = DataCategory.CUSTOM

                # Calculate line number
                line_number = text[: nf["start"]].count("\n") + 1

                finding = Finding.create(
                    asset_id=asset_id,
                    data_type=data_type,
                    category=category,
                    confidence=nf["confidence"],
                    matched_text=nf["matched_text"],
                    location=location,
                    line_number=line_number,
                    pattern_name=f"ner:{nf.get('entity_label', 'unknown')}",
                )

                findings.append(finding)

        except Exception as e:
            logger.warning(f"NER processing error: {e}")

        return findings

    def _find_custom_matches(
        self,
        text: str,
        asset_id: UUID,
        location: str,
        categories: Optional[List[str]] = None,
    ) -> List[Finding]:
        """Find matches using custom YAML patterns."""
        if not self._custom_loader:
            return []

        findings = []
        compiled_patterns = self._custom_loader.get_compiled_patterns()

        for pattern in compiled_patterns:
            # Filter by category if specified
            if categories:
                try:
                    cat = DataCategory(pattern.category)
                    if cat not in {DataCategory(c) for c in categories}:
                        continue
                except ValueError:
                    continue

            for match in pattern.regex.finditer(text):
                matched_text = match.group()

                # Run validator if present
                if pattern.validator and not pattern.validator(matched_text):
                    continue

                # Calculate confidence with context boost
                confidence = pattern.confidence
                context_start = max(0, match.start() - self.config.context_window)
                context_end = min(len(text), match.end() + self.config.context_window)
                context = text[context_start:context_end]

                for ctx_pattern in pattern.context_patterns:
                    if re.search(ctx_pattern, context, re.IGNORECASE):
                        confidence = min(1.0, confidence + 0.1)

                # Map data_type string to enum
                try:
                    data_type = DataType(pattern.data_type)
                except ValueError:
                    data_type = DataType.CUSTOM

                try:
                    category = DataCategory(pattern.category)
                except ValueError:
                    category = DataCategory.CUSTOM

                # Calculate line number
                line_number = text[: match.start()].count("\n") + 1

                finding = Finding.create(
                    asset_id=asset_id,
                    data_type=data_type,
                    category=category,
                    confidence=confidence,
                    matched_text=matched_text,
                    location=location,
                    line_number=line_number,
                    pattern_name=f"custom:{pattern.name}",
                )

                findings.append(finding)

        return findings

    def _deduplicate_findings(self, findings: List[Finding]) -> List[Finding]:
        """Remove duplicate or overlapping findings.

        Uses aggressive deduplication:
        1. Exact text+location+type matches
        2. Normalized text with same type in same file
        3. Overlapping position ranges with same type
        """
        if not findings:
            return findings

        sorted_findings = sorted(
            findings,
            key=lambda f: (-f.confidence, f.line_number or 0, f.data_type.value)
        )

        seen_exact = set()
        seen_normalized = set()
        seen_positions: Dict[tuple, list] = {}

        deduplicated = []

        for finding in sorted_findings:
            matched_text = finding._matched_text or ""
            normalized_text = matched_text.strip().lower()

            file_path = finding.location.split(":")[0] if ":" in finding.location else finding.location

            exact_key = (matched_text, finding.location, finding.data_type)
            if exact_key in seen_exact:
                continue

            normalized_key = (normalized_text, file_path, finding.data_type)
            if normalized_key in seen_normalized:
                continue

            position_key = (file_path, finding.data_type)
            line_num = finding.line_number or 0

            is_position_duplicate = False
            if position_key in seen_positions:
                for existing_line, existing_hash in seen_positions[position_key]:
                    if abs(existing_line - line_num) <= 3:
                        text_hash = hash(normalized_text[:50])
                        if existing_hash == text_hash:
                            is_position_duplicate = True
                            break

            if is_position_duplicate:
                continue

            seen_exact.add(exact_key)
            seen_normalized.add(normalized_key)

            if position_key not in seen_positions:
                seen_positions[position_key] = []
            seen_positions[position_key].append((line_num, hash(normalized_text[:50])))

            deduplicated.append(finding)

        return deduplicated

    @staticmethod
    def _collapse_low_severity(findings: List[Finding]) -> List[Finding]:
        """Collapse LOW-severity findings of the same type into one with occurrence_count.

        A spreadsheet with 50 email addresses becomes 1 email finding with occurrence_count=50.
        Only applies to LOW severity (email, phone, address, full_name).
        """
        low_types = {Severity.LOW}
        collapsed: List[Finding] = []
        low_buckets: Dict[DataType, List[Finding]] = {}

        for f in findings:
            if f.severity in low_types:
                low_buckets.setdefault(f.data_type, []).append(f)
            else:
                collapsed.append(f)

        for data_type, bucket in low_buckets.items():
            if len(bucket) <= 1:
                collapsed.extend(bucket)
            else:
                # Keep the highest-confidence finding, set occurrence_count
                bucket.sort(key=lambda f: -f.confidence)
                representative = bucket[0]
                representative.occurrence_count = len(bucket)
                collapsed.append(representative)

        return collapsed

    def get_pattern_count(self) -> int:
        """Get total number of loaded patterns."""
        return len(self._patterns)

    def get_patterns_by_category(self) -> Dict[str, int]:
        """Get pattern counts by category."""
        counts: Dict[str, int] = {}
        for pattern in self._patterns:
            cat = pattern.category.value
            counts[cat] = counts.get(cat, 0) + 1
        return counts
