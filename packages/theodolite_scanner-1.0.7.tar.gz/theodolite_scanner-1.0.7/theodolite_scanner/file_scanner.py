"""Standalone file content scanner for extracting text from various file formats.

Extracted from the Theodolite server-side scanner. Simplified to work with
raw bytes/file paths instead of the Asset/BaseScanner framework.
"""

from __future__ import annotations

import io
import logging
import zipfile
from pathlib import Path
from typing import Any, Optional

from theodolite_scanner.text_utils import extract_text_from_binary, normalize_text

logger = logging.getLogger(__name__)


# File extensions and their handlers
TEXT_EXTENSIONS = {
    ".txt", ".csv", ".json", ".xml", ".yaml", ".yml",
    ".md", ".rst", ".log", ".sql", ".py", ".js", ".ts",
    ".html", ".htm", ".css", ".env", ".ini", ".cfg", ".conf",
    ".sh", ".bash", ".zsh", ".ps1", ".bat", ".cmd",
    ".java", ".c", ".cpp", ".h", ".hpp", ".cs", ".go", ".rs",
    ".rb", ".php", ".pl", ".swift", ".kt", ".scala",
}

PDF_EXTENSIONS = {".pdf"}

OFFICE_EXTENSIONS = {
    ".docx", ".doc",
    ".xlsx", ".xls",
    ".pptx", ".ppt",
}

RTF_EXTENSIONS = {".rtf"}

ALL_SUPPORTED_EXTENSIONS = TEXT_EXTENSIONS | PDF_EXTENSIONS | OFFICE_EXTENSIONS | RTF_EXTENSIONS


def can_extract(filename: str, max_size_bytes: int = 100 * 1024 * 1024, size_bytes: Optional[int] = None) -> bool:
    """Check if a file can be scanned based on extension and size."""
    ext = Path(filename).suffix.lower()
    if ext not in ALL_SUPPORTED_EXTENSIONS:
        return False
    if size_bytes is not None and size_bytes > max_size_bytes:
        return False
    return True


def extract_text(content: bytes, filename: str) -> Optional[str]:
    """Extract text from file content based on filename extension.

    Args:
        content: Raw file bytes
        filename: Original filename (used to determine format)

    Returns:
        Extracted text, or None if extraction fails
    """
    ext = Path(filename).suffix.lower()

    try:
        if ext in TEXT_EXTENSIONS:
            return _extract_text(content)
        elif ext in PDF_EXTENSIONS:
            return _extract_pdf(content)
        elif ext == ".docx":
            return _extract_docx(content)
        elif ext == ".xlsx":
            return _extract_xlsx(content)
        elif ext == ".pptx":
            return _extract_pptx(content)
        elif ext in RTF_EXTENSIONS:
            return _extract_rtf(content)
    except Exception as e:
        logger.debug("extraction_failed: %s — %s", filename, e)

    return None


def _extract_text(content: bytes) -> Optional[str]:
    """Extract text from plain text content."""
    text, _, _ = extract_text_from_binary(content)
    return text if text.strip() else None


def _extract_pdf(content: bytes) -> Optional[str]:
    """Extract text from PDF content."""
    try:
        import pypdf
    except ImportError:
        logger.warning("pypdf not installed — run: pip install 'theodolite-scanner[pdf]'")
        return None

    text_parts = []
    reader = pypdf.PdfReader(io.BytesIO(content))

    for page in reader.pages:
        text = page.extract_text()
        if text:
            text_parts.append(text)

    return "\n\n".join(text_parts) if text_parts else None


def _extract_docx(content: bytes) -> Optional[str]:
    """Extract text from Word documents (.docx)."""
    try:
        from docx import Document
    except ImportError:
        logger.warning("python-docx not installed — run: pip install 'theodolite-scanner[office]'")
        return None

    doc = Document(io.BytesIO(content))
    text_parts = []

    for para in doc.paragraphs:
        if para.text.strip():
            text_parts.append(para.text)

    for table in doc.tables:
        for row in table.rows:
            row_text = []
            for cell in row.cells:
                if cell.text.strip():
                    row_text.append(cell.text.strip())
            if row_text:
                text_parts.append(" | ".join(row_text))

    return "\n".join(text_parts) if text_parts else None


def _extract_xlsx(content: bytes) -> Optional[str]:
    """Extract text from Excel documents (.xlsx)."""
    try:
        import openpyxl
    except ImportError:
        logger.warning("openpyxl not installed — run: pip install 'theodolite-scanner[office]'")
        return None

    workbook = openpyxl.load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    text_parts = []

    for sheet_name in workbook.sheetnames:
        sheet = workbook[sheet_name]
        text_parts.append(f"=== Sheet: {sheet_name} ===")

        for row in sheet.iter_rows(values_only=True):
            row_values = [str(cell) if cell is not None else "" for cell in row]
            if any(v.strip() for v in row_values):
                text_parts.append(" | ".join(row_values))

    workbook.close()
    return "\n".join(text_parts) if text_parts else None


def _extract_pptx(content: bytes) -> Optional[str]:
    """Extract text from PowerPoint documents (.pptx)."""
    try:
        from pptx import Presentation
    except ImportError:
        logger.warning("python-pptx not installed — run: pip install 'theodolite-scanner[office]'")
        return None

    prs = Presentation(io.BytesIO(content))
    text_parts = []

    for slide_num, slide in enumerate(prs.slides, 1):
        slide_text = [f"=== Slide {slide_num} ==="]

        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text.strip():
                slide_text.append(shape.text)

            if shape.has_table:
                for row in shape.table.rows:
                    row_text = []
                    for cell in row.cells:
                        if cell.text.strip():
                            row_text.append(cell.text.strip())
                    if row_text:
                        slide_text.append(" | ".join(row_text))

        if len(slide_text) > 1:
            text_parts.extend(slide_text)

    return "\n".join(text_parts) if text_parts else None


def _extract_rtf(content: bytes) -> Optional[str]:
    """Extract text from RTF content."""
    try:
        from striprtf.striprtf import rtf_to_text
    except ImportError:
        logger.warning("striprtf not installed for RTF extraction")
        return None

    try:
        rtf_content = content.decode("utf-8")
    except UnicodeDecodeError:
        rtf_content = content.decode("latin-1")

    text = rtf_to_text(rtf_content)
    return text if text.strip() else None
