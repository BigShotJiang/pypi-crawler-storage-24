"""Sensitive data detection patterns.

Provides comprehensive patterns for detecting:
- PII (Personally Identifiable Information)
- PHI (Protected Health Information)
- Financial data (credit cards, bank accounts)
- Credentials (API keys, passwords, SSH keys)
"""

from theodolite_scanner.patterns import pii, phi, financial, credentials

__all__ = ["pii", "phi", "financial", "credentials"]
