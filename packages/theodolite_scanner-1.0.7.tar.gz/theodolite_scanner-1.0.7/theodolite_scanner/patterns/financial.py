"""Financial data detection patterns.

Comprehensive patterns for detecting financial data:
- Credit Card Numbers (Visa, Mastercard, Amex, Discover, JCB, UnionPay)
- Bank Account Numbers (US, UK, IBAN)
- Routing/Sort Codes (US ABA, UK Sort Code)
- Tax IDs (EIN, ITIN, VAT)
- Financial Account Identifiers
- Cryptocurrency Addresses
"""

from __future__ import annotations

import re

from theodolite_scanner.classifier import DataCategory, DataType, Pattern


# =============================================================================
# Validation Functions
# =============================================================================

def luhn_checksum(number: str) -> bool:
    """Validate number using Luhn algorithm."""
    digits = [int(d) for d in number if d.isdigit()]
    if len(digits) < 13:
        return False

    odd_digits = digits[-1::-2]
    even_digits = digits[-2::-2]

    checksum = sum(odd_digits)
    for d in even_digits:
        checksum += sum(divmod(d * 2, 10))

    return checksum % 10 == 0


def validate_credit_card(number: str) -> bool:
    """Validate credit card number."""
    digits = re.sub(r"[^0-9]", "", number)

    # Check length
    if len(digits) < 13 or len(digits) > 19:
        return False

    # Check Luhn
    if not luhn_checksum(digits):
        return False

    # Note: We intentionally do NOT reject test card numbers (4111111111111111, etc.)
    # because for a security scanner, finding test cards in production data is still
    # a sensitive data finding worth flagging.

    # Check for obviously fake patterns (all same digit)
    if digits == digits[0] * len(digits):
        return False

    return True


def validate_routing_number(number: str) -> bool:
    """Validate US bank routing number using ABA checksum."""
    digits = re.sub(r"[^0-9]", "", number)

    if len(digits) != 9:
        return False

    # First two digits indicate Federal Reserve Bank district (01-12, 21-32)
    first_two = int(digits[:2])
    valid_ranges = list(range(1, 13)) + list(range(21, 33)) + [61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 80]
    if first_two not in valid_ranges:
        return False

    # ABA routing number checksum
    weights = [3, 7, 1, 3, 7, 1, 3, 7, 1]
    total = sum(int(d) * w for d, w in zip(digits, weights))

    return total % 10 == 0


def validate_iban(iban: str) -> bool:
    """Validate IBAN using ISO 7064 Mod 97-10 checksum."""
    iban = iban.upper().replace(" ", "").replace("-", "")

    if len(iban) < 15 or len(iban) > 34:
        return False

    # Move first 4 characters to end
    rearranged = iban[4:] + iban[:4]

    # Replace letters with numbers (A=10, B=11, ... Z=35)
    numeric = ""
    for char in rearranged:
        if char.isdigit():
            numeric += char
        else:
            numeric += str(ord(char) - 55)  # A=10, B=11, etc.

    # Check mod 97
    return int(numeric) % 97 == 1


def validate_uk_sort_code(code: str) -> bool:
    """Basic validation of UK sort code format."""
    digits = re.sub(r"[^0-9]", "", code)
    return len(digits) == 6


def validate_swift_bic(code: str) -> bool:
    """Validate SWIFT/BIC code - reject common English words."""
    code = code.upper().replace(" ", "").replace("-", "")

    if len(code) not in (8, 11):
        return False

    # First 4 chars: bank code (letters only)
    if not code[:4].isalpha():
        return False

    # Chars 5-6: country code (must be valid ISO country)
    valid_country_codes = {
        "AD", "AE", "AF", "AG", "AL", "AM", "AO", "AR", "AT", "AU", "AZ",
        "BA", "BB", "BD", "BE", "BF", "BG", "BH", "BI", "BJ", "BN", "BO", "BR", "BS", "BT", "BW", "BY", "BZ",
        "CA", "CD", "CF", "CG", "CH", "CI", "CL", "CM", "CN", "CO", "CR", "CU", "CV", "CY", "CZ",
        "DE", "DJ", "DK", "DM", "DO", "DZ",
        "EC", "EE", "EG", "ER", "ES", "ET",
        "FI", "FJ", "FR",
        "GA", "GB", "GD", "GE", "GH", "GM", "GN", "GQ", "GR", "GT", "GW", "GY",
        "HK", "HN", "HR", "HT", "HU",
        "ID", "IE", "IL", "IN", "IQ", "IR", "IS", "IT",
        "JM", "JO", "JP",
        "KE", "KG", "KH", "KI", "KM", "KN", "KP", "KR", "KW", "KZ",
        "LA", "LB", "LC", "LI", "LK", "LR", "LS", "LT", "LU", "LV", "LY",
        "MA", "MC", "MD", "ME", "MG", "MK", "ML", "MM", "MN", "MO", "MR", "MT", "MU", "MV", "MW", "MX", "MY", "MZ",
        "NA", "NE", "NG", "NI", "NL", "NO", "NP", "NZ",
        "OM",
        "PA", "PE", "PG", "PH", "PK", "PL", "PR", "PS", "PT", "PW", "PY",
        "QA",
        "RO", "RS", "RU", "RW",
        "SA", "SB", "SC", "SD", "SE", "SG", "SI", "SK", "SL", "SM", "SN", "SO", "SR", "SS", "ST", "SV", "SY", "SZ",
        "TD", "TG", "TH", "TJ", "TL", "TM", "TN", "TO", "TR", "TT", "TW", "TZ",
        "UA", "UG", "US", "UY", "UZ",
        "VA", "VC", "VE", "VN", "VU",
        "WS",
        "YE",
        "ZA", "ZM", "ZW",
    }
    country = code[4:6]
    if country not in valid_country_codes:
        return False

    # Chars 7-8: location code - must be alphanumeric
    if not code[6:8].isalnum():
        return False

    # Real SWIFT codes typically have digits in positions 7-8 or end with digits
    # Pure alphabetic codes that look like English words are likely false positives
    has_digit = any(c.isdigit() for c in code[6:])

    # If 11 chars, last 3 are branch code
    if len(code) == 11:
        if not code[8:11].isalnum():
            return False

    # CRITICAL: Reject all-letter codes that could be English words
    # Real SWIFT codes like "BOFAUS3N" have digits; pure letter codes are rare
    # and when they exist, they don't spell common words
    if code.isalpha():
        # Check against extensive list of common English words/patterns
        common_words = {
            # Programming terms
            "ABSTRACT", "ARGUMENT", "ASSIGNED", "AUTOLOAD", "BACKSTOP",
            "BALANCED", "BASELINE", "BEHAVIOR", "BRANDING", "BRACKETS",
            "BRIDGING", "BUILDING", "BUSINESS", "CALLBACK", "CARDINAS",
            "CARDINAL", "CASCADED", "CATEGORY", "CENTERED", "CHANGING",
            "CHAPTERS", "CHARTING", "CHECKING", "CHILDREN", "CIRCULAR",
            "CLEANING", "CLEARING", "CLICKING", "CLIPPING", "CLUSTERS",
            "COALESCE", "COLLAPSE", "COLORING", "COMBINED", "COMEBACK",
            "COMMANDS", "COMMENTS", "COMMITED", "COMPILED", "COMPLETE",
            "COMPOUND", "COMPRESS", "COMPUTED", "CONCEPTS", "CONCLUDE",
            "CONCRETE", "CONDITIO", "CONFIGUR", "CONFIRMS", "CONFLICT",
            "CONNECTS", "CONSOLES", "CONSTANT", "CONTAINS", "CONTENTS",
            "CONTEXTS", "CONTINUE", "CONTRACT", "CONTROLS", "CONVERTS",
            "COPYABLE", "COUNTING", "COVERAGE", "CREATING", "CRITICAL",
            "CROSSING", "CURRENTS", "DATABASE", "DATATYPE", "DEBUGGIN",
            "DECLARED", "DECODING", "DECREASE", "DEFAULTS", "DEFERRED",
            "DEGRADED", "DELEGATE", "DELETING", "DELIVERS", "DEPLOYED",
            "DESCRIBE", "DESIGNED", "DETAILED", "DETECTED", "DIAGRAMS",
            "DIALECTS", "DIALOGUE", "DIFFEREN", "DIRECTED", "DISABLED",
            "DISCOUNT", "DISCOVER", "DISPATCH", "DISPLACE", "DISPLAYS",
            "DISTINCT", "DISTRICT", "DIVIDEND", "DOCUMENT", "DOMINATE",
            "DOWNLOAD", "DRAGGING", "DRAWABLE", "DROPDOWN", "DURATION",
            "DYNAMICS", "EARLIEST", "ECONOMIC", "EDITABLE", "EDITINGS",
            "EDUCATIO", "EFFECTIV", "ELEMENTS", "EMBEDDED", "EMERGING",
            "EMPLOYED", "EMULATED", "ENABLING", "ENCLOSED", "ENCODING",
            "ENCOUNTE", "ENDPOINT", "ENFORCED", "ENGAGING", "ENHANCED",
            "ENSURING", "ENTERING", "ENTIRELY", "ENTITIES", "ENTITLES",
            "ENVELOPE", "ENVIRONM", "EPISODES", "EQUALITY", "EQUIPPED",
            "ESCAPIGN", "ESSENTIA", "ESTABLIS", "ESTIMATE", "EVALUATE",
            "EVENTUAL", "EVIDENCE", "EVOLVING", "EXAMPLES", "EXCEEDED",
            "EXCHANGE", "EXCLUDED", "EXECUTED", "EXERCISE", "EXISTING",
            "EXPANDED", "EXPECTED", "EXPLICIT", "EXPLORED", "EXPORTED",
            "EXPOSURE", "EXTENDED", "EXTERNAL", "EXTRACTS", "FACTORED",
            "FAILOVER", "FAMILIAR", "FEATURED", "FEEDBACK", "FETCHING",
            "FILENAME", "FILEPATH", "FILESIZE", "FILTERED", "FINALIZE",
            "FINISHED", "FIXATION", "FLAGGING", "FLEXIBLE", "FLOATING",
            "FLOODING", "FOCUSING", "FOLLOWIN", "FOOTNOTE", "FORECAST",
            "FORENAME", "FORENSIC", "FORMATTE", "FORMERLY", "FORMULAE",
            "FOUNDING", "FRACTION", "FRAGMENT", "FRAMEWOR", "FREEZING",
            "FREQUENT", "FRONTEND", "FUNCTION", "GENERATE", "GETTINGS",
            "GLOBALLY", "GRABBING", "GRADIENT", "GRAPHICS", "GREATEST",
            "GREETING", "GROUPING", "GUIDANCE", "HANDLEIN", "HANDLING",
            "HAPPENIN", "HARDCODE", "HARDWARE", "HEADLINE", "HEALTHCA",
            "HELPINGS", "HIERARCH", "HIGHLIGH", "HOMEPAGE", "HORIZONT",
            "HOSTNAME", "HUNDREDS", "HYPERLIN", "IDENTIFY", "IDENTITY",
            "IGNORANT", "IGNORING", "ILLUSORY", "IMAGESIN", "IMAGININ",
            "IMMEDIAT", "IMPACTED", "IMPLEMEN", "IMPLICIT", "IMPORTED",
            "IMPOSING", "IMPROVED", "INACTIVE", "INCIDENT", "INCLUDED",
            "INCOMING", "INCREASE", "INCREMEN", "INDEXING", "INDICATO",
            "INDIRECT", "INDIVIDU", "INDUSTRY", "INFORMEL", "INHERENT",
            "INHERITS", "INITIALI", "INJECTED", "INPUTING", "INSERTED",
            "INSIDERS", "INSTANCE", "INSTRUCT", "INTEGRAL", "INTEGRAT",
            "INTENDED", "INTERACT", "INTEREST", "INTERNAL", "INTERPRE",
            "INTERVAL", "INTRODUC", "INVASION", "INVERTED", "INVESTIG",
            "INVOKING", "INVOLVED", "ISOLATED", "ISSUESIN", "ITERABLE",
            "ITERATOR", "JOININGS", "JOURNALS", "JUDGMENT", "KEYBOARD",
            "KEYWORDS", "KNOWNFOR", "LABELING", "LANGUAGE", "LASTNAME",
            "LAUNCHED", "LAUNCHIN", "LAYERING", "LAYOUTS", "LEADINGS",
            "LEARNING", "LEFTMOST", "LEVERAGE", "LICENSED", "LIFETIME",
            "LIGHTING", "LIMITING", "LINEARLY", "LISTENER", "LISTINGS",
            "LITERALS", "LOADINGS", "LOCALHOS", "LOCALIZE", "LOCATING",
            "LOCATION", "LOCKINGS", "LOGGEDIN", "LOGGINGS", "LOOKINGS",
            "MAINTAIN", "MAJORITY", "MANAGING", "MANIFEST", "MANUALLY",
            "MAPPINGS", "MARGINAL", "MARKDOWN", "MARKINGS", "MATCHING",
            "MATERIAL", "MAXIMISE", "MAXIMIZE", "MEANINGS", "MEASURED",
            "MEASURES", "MEETINGS", "MEMOIZED", "MEMORING", "MEMORIZE",
            "MENTIONS", "MERCHANT", "MESSAGES", "METADATA", "MIGRATED",
            "MINIMIZE", "MISMATCH", "MODIFIED", "MODIFIER", "MODIFIES",
            "MODULATE", "MONETARY", "MONITORS", "MORTGAGE", "MOUNTING",
            "MOVEMENT", "MULTIPLE", "MUTATION", "NAMELESS", "NAMESPAC",
            "NAVIGATE", "NEATINGS", "NEGATIVE", "NETWORKS", "NODEINFO",
            "NODELIST", "NORMALLY", "NOTIFIED", "NOTATION", "NOTEBOOK",
            "NUMBERED", "NUMERALS", "NUMEROUS", "OBJECTID", "OBJECTIV",
            "OBSCURED", "OBSERVED", "OBSERVER", "OBTAINED", "OBSOLETE",
            "OCCASION", "OCCURRED", "OFFERING", "OFFICIAL", "OFFPRINT",
            "OFFSETIN", "OMITTING", "ONESHOTS", "ONLINING", "OPENINGS",
            "OPERATED", "OPERATIN", "OPERATOR", "OPINIONS", "OPPONENT",
            "OPPOSING", "OPTIMISE", "OPTIMIZE", "OPTIONAL", "ORDERING",
            "ORDINALS", "ORGANISE", "ORGANIZE", "ORIENTED", "ORIGINAL",
            "OTHERING", "OUTCOMES", "OUTLINED", "OUTLINER", "OUTLYING",
            "OUTPRINT", "OUTWARDS", "OVERFLOW", "OVERHEAD", "OVERLAID",
            "OVERLAPS", "OVERLOAD", "OVERRIDE", "OVERRODE", "OVERVIEW",
            "PAINTING", "PANELING", "PARALLEL", "PARAMETE", "PARENTED",
            "PARENTID", "PARSABLE", "PARSEINT", "PARSINGS", "PARTIALS",
            "PARTNERS", "PASSWORD", "PATHNAME", "PATTERNS", "PAYMENTS",
            "PEDAGOGI", "PENDLING", "PENDINGS", "PERFORMS", "PERIODIC",
            "PERSONAL", "PIPELINE", "PLACEHOL", "PLANFORM", "PLANNING",
            "PLATFORM", "PLAYBACK", "PLAYLIST", "PLOTTING", "POINTING",
            "POLICIES", "POLISHED", "POLITICS", "POPULATE", "PORTIONS",
            "POSITION", "POSITIVE", "POSSIBLE", "POSTCEDE", "POSTCODE",
            "POSTPONE", "POTENTIA", "POWERFUL", "PRACTICE", "PREACHED",
            "PRECEDED", "PRECIOUS", "PRECISE", "PRECLUDE", "PREDICAT",
            "PREDICTS", "PREFETCH", "PREFIXED", "PREFORMS", "PRELOADE",
            "PREMISED", "PREPARED", "PREPRINT", "PRESENCE", "PRESENTS",
            "PRESERVE", "PRESSING", "PRESSURE", "PRESUMES", "PREVENTS",
            "PREVIEWS", "PREVIOUS", "PRIINTES", "PRIMARLY", "PRIMEVAL",
            "PRINCESS", "PRINCIPA", "PRINTOUT", "PRINTING", "PRIORITY",
            "PROBABLE", "PROBLEMS", "PROCEEDS", "PROCESSE", "PROCURED",
            "PRODUCED", "PRODUCER", "PRODUCES", "PRODUCTS", "PROFESSI",
            "PROFILES", "PROGNAME", "PROGRAMS", "PROGRESS", "PROJECTS",
            "PROLOGUE", "PROMISED", "PROMOTED", "PROMPTIN", "PRONOUNS",
            "PROPERLY", "PROPERTY", "PROPOSAL", "PROPOSED", "PROTECTE",
            "PROTOCOL", "PROVIDED", "PROVIDER", "PROVIDES", "PROVINCE",
            "PROXYING", "PUBLISHI", "PURCHASE", "PURSUING", "PUSHINGS",
            "QUALIFIE", "QUANTIFY", "QUANTITY", "QUESTION", "QUEUEING",
            "RANDOMLY", "RANKINGS", "REACTING", "READABLE", "READINGS",
            "REALIGNS", "REALIZED", "REASONED", "REBASING", "REBOOTED",
            "RECALLED", "RECEIVER", "RECEIVES", "RECENTLY", "RECHARGE",
            "RECOMMIT", "RECORDED", "RECORDER", "RECOVERS", "RECOVERY",
            "RECREATE", "REDIRECT", "REDUCING", "REFERENC", "REFERRED",
            "REFLECTS", "REFORMAT", "REFORMER", "REFRESHE", "REFUNDED",
            "REFUSING", "REGARDIN", "REGISTER", "REGISTRY", "REGULATE",
            "REJECTED", "RELATING", "RELATION", "RELATIVE", "RELEASED",
            "RELEASER", "RELEASES", "RELEVANT", "RELIABLE", "RELIANCE",
            "RELIEVED", "RELOADED", "RELOGINS", "REMAINED", "REMAININ",
            "REMARKED", "REMEMBER", "REMINDED", "REMINDER", "REMOTELY",
            "REMOVALS", "REMOVING", "RENAMING", "RENDERED", "RENDERER",
            "RENEWING", "REORDERS", "REPAIRED", "REPEATED", "REPLACED",
            "REPLACES", "REPLAYED", "REPLICAS", "REPORTED", "REPORTER",
            "REPOSITO", "REPRESEN", "REPRINTS", "REQUESTS", "REQUIRED",
            "REQUIRES", "REROUTED", "RESEARCH", "RESERVED", "RESETTIN",
            "RESIDENT", "RESIGNED", "RESIZING", "RESOLVED", "RESOLVER",
            "RESOLVES", "RESORTED", "RESOURCE", "RESPONDS", "RESPONSE",
            "RESTAGIN", "RESTARTS", "RESTORED", "RESTRICK", "RESTRICT",
            "RESULTED", "RESULTED", "RESUMING", "RETAINED", "RETAINER",
            "RETIRING", "RETRIEVE", "RETURNED", "RETURNIN", "REVEALED",
            "REVERSAL", "REVERSED", "REVERSIN", "REVIEWED", "REVIEWER",
            "REVISION", "REVIVING", "REVOLVED", "REWRITER", "RIGHTFUL",
            "RIGOROUR", "ROADMAPS", "ROTATING", "ROTATION", "ROUTINGS",
            "RUNNABLE", "RUNTIMES", "SABOTAGE", "SAMPLING", "SCENARIO",
            "SCHEDULE", "SCHEMING", "SCHOLARS", "SCOFFERS", "SCRAMBLE",
            "SCRATCHI", "SCREENIN", "SCRIPTED", "SCROLLED", "SEARCHED",
            "SEARCHES", "SEASONAL", "SECONDLY", "SECTIONS", "SECURING",
            "SECURITY", "SEGMENTS", "SELECTED", "SELECTOR", "SELFTEST",
            "SEMANTIC", "SEMINARS", "SENATORS", "SENSIBLE", "SENTENCE",
            "SENTINAL", "SENTINEL", "SEPARATE", "SEQUENCE", "SERIALIZ",
            "SERVICES", "SESSIONS", "SETTINGS", "SETTLING", "SEVERELY",
            "SHARDING", "SHELLING", "SHELVING", "SHIFTING", "SHIPMENT",
            "SHIPPING", "SHORTCUT", "SHORTEST", "SHOWINGS", "SHUTTING",
            "SIBLINGS", "SIDEBARS", "SIGNATUR", "SIMPLEST", "SIMPLIFY",
            "SIMULATE", "SINGULAR", "SITUATED", "SKELETON", "SKIPPING",
            "SLIDEOUT", "SNAPSHOT", "SOFTWARE", "SOLUTION", "SOMEBODY",
            "SOMETIME", "SOMEWHAT", "SORTABLE", "SORTINGS", "SOURCING",
            "SPACINGS", "SPANNING", "SPARKLED", "SPAWNING", "SPEAKING",
            "SPECIALI", "SPECIFIC", "SPECIMEN", "SPECTRAL", "SPELLING",
            "SPENDING", "SPINNING", "SPLICING", "SPLITTED", "SPOOFING",
            "SPOTTING", "SPRAYING", "SPREADIN", "SQUASHED", "STABBING",
            "STACKING", "STAFFING", "STAGINGS", "STANDARD", "STANDING",
            "STARTING", "STARVING", "STATEFUL", "STATEMEN", "STATISTI",
            "STEALING", "STEERING", "STEPPING", "STICKING", "STOPPING",
            "STORAGES", "STORMING", "STRAIGHT", "STRANDED", "STRANGER",
            "STRATEGY", "STREAMIN", "STRENGTH", "STRESSED", "STRICTLY",
            "STRIKING", "STRIPPED", "STROKING", "STRONGER", "STRONGLY",
            "STRUCTUR", "STUBBING", "STUDYING", "STUNNING", "STYLEDIN",
            "SUBJECTS", "SUBMITIN", "SUBORDIN", "SUBSCRIB", "SUBSET",
            "SUBTITLE", "SUBTOTAL", "SUBTRACT", "SUCCEEDS", "SUCCEEDI",
            "SUFFIXED", "SUGGESTS", "SUITABLE", "SUMMARIS", "SUMMARIZ",
            "SUMMATED", "SUPERIOR", "SUPPLANT", "SUPPLEME", "SUPPLIED",
            "SUPPLIER", "SUPPLIES", "SUPPORTS", "SUPPOSED", "SUPPRESS",
            "SURNAMED", "SURPRISE", "SURROUND", "SURVEYED", "SURVIVED",
            "SURVIVOR", "SUSPENDE", "SUSPENDS", "SUSTAINS", "SWITCHED",
            "SWITCHER", "SWITCHES", "SYMBOLIC", "SYMPATHY", "SYMPTOMS",
            "SYNDROME", "SYNONYMS", "SYNTACTI", "SYSTEMIC", "TABINDEX",
            "TAILORED", "TAKEOVER", "TALENTED", "TANGIBLE", "TARGETED",
            "TASKLIST", "TAXONOMY", "TEACHING", "TEAMMATE", "TEAMWORK",
            "TECHNICA", "TECHNIQU", "TELEGRAM", "TELEPHON", "TEMPLATE",
            "TEMPORAL", "TENDENCY", "TERMINAL", "TERMINAT", "TERRIFIC",
            "TERTIARY", "TESTABLE", "TESTCASE", "TESTDATA", "TESTINGS",
            "TEXTAREA", "TEXTBOOK", "TEXTILES", "TEXTURES", "THANKFUL",
            "THEATERS", "THEOREMS", "THEORIES", "THINKING", "THOROUGH",
            "THOUGHTS", "THOUSAND", "THREADED", "THREATEN", "THRESOLD",
            "THRIVING", "THROTTLE", "THROWING", "TIMESTAM", "TITLEBAR",
            "TOGETHER", "TOGGLING", "TOLERANT", "TOMORROW", "TOOLINGS",
            "TOOLTIPS", "TOPNOTCH", "TOPOLOGY", "TOUCHING", "TOUGHEST",
            "TRACKING", "TRADEOFF", "TRAFFICS", "TRAILING", "TRAINERS",
            "TRAINING", "TRANSFER", "TRANSFOR", "TRANSIEN", "TRANSLAT",
            "TRANSMIT", "TRANSPOR", "TRAVERSE", "TREATING", "TREATMEN",
            "TREBLING", "TRENDING", "TRIALING", "TRIANGLE", "TRIGGERS",
            "TRIMMING", "TROUBLED", "TROUBLES", "TRUNCATE", "TRUSTING",
            "TRUTHFUL", "TUNEABLE", "TUTORIAL", "TWEAKING", "TWINNING",
            "TYPECAST", "TYPENAME", "ULTIMATE", "UMBRELLA", "UNBIASED",
            "UNCOMMON", "UNCOUPLE", "UNDERFED", "UNDERLIE", "UNDERLIN",
            "UNDERPAY", "UNDERPIN", "UNDERRUN", "UNDERWAY", "UNDOINGS",
            "UNESCAPE", "UNEXPECT", "UNFROZEN", "UNGUIDED", "UNIFYING",
            "UNIQUEID", "UNIQUELY", "UNITTEST", "UNIVERAL", "UNIVERSE",
            "UNLIKELY", "UNLISTED", "UNLOCKED", "UNMASKED", "UNMOUNTS",
            "UNPACKED", "UNQUOTED", "UNREADAB", "UNRESOLV", "UNSIGNED",
            "UNSORTED", "UNSTABLE", "UNSTAGED", "UNSTYLED", "UNTESTED",
            "UNUSABLE", "UNWANTED", "UPDATING", "UPGRADED", "UPGRADER",
            "UPGRADES", "UPLOADED", "UPLOADER", "UPSTREAM", "USAGINGS",
            "USERBASE", "USERNAME", "UTILISED", "UTILIZED", "UTILIZES",
            "VACATION", "VALIDATE", "VALUATED", "VARIABLE", "VARIANCE",
            "VARIANTS", "VARIEDLY", "VELOCITY", "VENDORED", "VENTURES",
            "VERBATIM", "VERBOSED", "VERIFIER", "VERIFIES", "VERSIONE",
            "VERTICAL", "VIEWABLE", "VIEWINGS", "VIEWPORT", "VIOLATED",
            "VIOLATES", "VIRTUALI", "VISIBILITY", "VISITINGS", "VISITORS",
            "VOLATILE", "VOUCHERS", "WAITINGS", "WALKOVER", "WARNINGS",
            "WARRANTY", "WATCHDOG", "WATCHFUL", "WATCHING", "WATERLOG",
            "WEEKDAYS", "WEIGHTED", "WELCOMES", "WHENEVER", "WHEREVER",
            "WILDLIFE", "WILDCARD", "WILLIAMS", "WINDOWED", "WIPEOUTS",
            "WITHDRAW", "WITHHOLD", "WITHINGS", "WONDERED", "WORKABLE",
            "WORKFLOW", "WORKINGS", "WORKLOAD", "WRAPPERS", "WRAPPING",
            "WRITINGS", "WRONGFUL", "YIELDING", "YOURSELF", "YOUNGEST",
            "YULETIDE", "ZEALOTRY", "ZEPPELIN", "ZIPFILES", "ZOMBIING",
        }

        # Check if the 8-letter code is a common word
        if code in common_words:
            return False

        # Also check first 8 chars for 11-char codes
        if len(code) == 11 and code[:8] in common_words:
            return False

        # Additional heuristic: if first 4 chars form a common word prefix, reject
        common_prefixes = {
            "ABST", "BACK", "BASE", "BOOK", "CARD", "CASE", "CODE", "DATA",
            "DOWN", "DROP", "EDIT", "FILE", "FIND", "FOOT", "FORM", "FULL",
            "GRID", "HAND", "HEAD", "HIGH", "HOME", "INFO", "ITEM", "KEEP",
            "LAND", "LAST", "LEFT", "LINE", "LIST", "LOAD", "LONG", "LOOK",
            "MAIN", "MAKE", "MARK", "MENU", "META", "MODE", "MORE", "MOVE",
            "NAME", "NEED", "NEWS", "NEXT", "NODE", "NOTE", "OPEN", "OVER",
            "PAGE", "PATH", "PICK", "PLAY", "PORT", "POST", "PREV", "READ",
            "REAL", "REDO", "RULE", "SAME", "SAVE", "SELF", "SEND", "SHOW",
            "SIDE", "SIZE", "SKIP", "SLOW", "SORT", "STAR", "STOP", "SYNC",
            "TABS", "TAKE", "TASK", "TEST", "TEXT", "THIS", "TIME", "TYPE",
            "UNDO", "UNIT", "USER", "VIEW", "WAIT", "WALK", "WARN", "WORK",
            "WRAP", "YEAR", "ZERO", "ZONE",
            # Common word suffixes that could end up as bank code
            "ABIL", "TING", "NESS", "MENT", "TION", "INGS", "ABLE", "IBLE",
        }
        if code[:4] in common_prefixes:
            return False

    return True


def validate_bank_account_number(number: str) -> bool:
    """Validate bank account number - reject obvious non-account patterns."""
    digits = re.sub(r"[^0-9]", "", number)

    if len(digits) < 8 or len(digits) > 17:
        return False

    # Reject sequential numbers
    if digits == "".join(str(i % 10) for i in range(len(digits))):
        return False
    if digits == "".join(str((9 - i) % 10) for i in range(len(digits))):
        return False

    # Reject repeated digits
    if len(set(digits)) == 1:
        return False

    # Reject if it looks like a consecutive year range (e.g., 20202021, 20222023)
    # Only reject when both halves are years AND they're consecutive (YYYY followed by YYYY+1)
    if len(digits) == 8:
        first_half = int(digits[:4])
        second_half = int(digits[4:])
        if (1990 <= first_half <= 2050 and
                second_half == first_half + 1):
            return False

    return True


# =============================================================================
# Pattern Definitions
# =============================================================================

def get_patterns() -> list[Pattern]:
    """Get all financial data detection patterns."""
    return [
        # =====================================================================
        # Credit Card Numbers
        # =====================================================================

        # Visa (starts with 4)
        Pattern(
            name="credit_card_visa",
            data_type=DataType.CREDIT_CARD,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b4\d{3}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b"
            ),
            validator=validate_credit_card,
            confidence_base=0.90,
            context_patterns=[
                r"visa",
                r"card",
                r"credit",
                r"debit",
                r"payment",
                r"pan",
            ],
        ),

        # Mastercard (starts with 51-55 or 2221-2720)
        Pattern(
            name="credit_card_mastercard",
            data_type=DataType.CREDIT_CARD,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b(?:5[1-5]\d{2}|222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)"
                r"[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b"
            ),
            validator=validate_credit_card,
            confidence_base=0.90,
            context_patterns=[
                r"mastercard",
                r"card",
                r"credit",
                r"debit",
                r"payment",
                r"pan",
            ],
        ),

        # American Express (starts with 34 or 37)
        Pattern(
            name="credit_card_amex",
            data_type=DataType.CREDIT_CARD,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b3[47]\d{2}[\s-]?\d{6}[\s-]?\d{5}\b"
            ),
            validator=validate_credit_card,
            confidence_base=0.90,
            context_patterns=[
                r"amex",
                r"american\s*express",
                r"card",
                r"credit",
                r"payment",
            ],
        ),

        # Discover (starts with 6011, 622126-622925, 644-649, 65)
        Pattern(
            name="credit_card_discover",
            data_type=DataType.CREDIT_CARD,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b(?:6011|65\d{2}|64[4-9]\d)[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b"
            ),
            validator=validate_credit_card,
            confidence_base=0.90,
            context_patterns=[
                r"discover",
                r"card",
                r"credit",
                r"payment",
            ],
        ),

        # JCB (starts with 3528-3589)
        Pattern(
            name="credit_card_jcb",
            data_type=DataType.CREDIT_CARD,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b35(?:2[89]|[3-8]\d)[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b"
            ),
            validator=validate_credit_card,
            confidence_base=0.90,
            context_patterns=[
                r"jcb",
                r"card",
                r"credit",
                r"payment",
                r"japan",
            ],
        ),

        # UnionPay (starts with 62)
        Pattern(
            name="credit_card_unionpay",
            data_type=DataType.CREDIT_CARD,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b62\d{2}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4,7}\b"
            ),
            validator=validate_credit_card,
            confidence_base=0.85,
            context_patterns=[
                r"unionpay",
                r"union\s*pay",
                r"china",
                r"card",
                r"credit",
            ],
        ),

        # Diners Club (starts with 300-305, 36, 38, 39)
        Pattern(
            name="credit_card_diners",
            data_type=DataType.CREDIT_CARD,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b(?:30[0-5]\d|36\d{2}|3[89]\d{2})[\s-]?\d{6}[\s-]?\d{4}\b"
            ),
            validator=validate_credit_card,
            confidence_base=0.90,
            context_patterns=[
                r"diners",
                r"carte\s*blanche",
                r"card",
                r"credit",
            ],
        ),

        # Generic credit card (fallback)
        Pattern(
            name="credit_card_generic",
            data_type=DataType.CREDIT_CARD,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b"
            ),
            validator=validate_credit_card,
            confidence_base=0.70,
            context_patterns=[
                r"card\s*number",
                r"credit\s*card",
                r"debit\s*card",
                r"payment\s*card",
                r"pan\b",
                r"primary\s*account",
            ],
        ),

        # CVV/CVC (Card Verification Value)
        Pattern(
            name="cvv_cvc",
            data_type=DataType.CREDIT_CARD,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b\d{3,4}\b"
            ),
            confidence_base=0.20,  # Very low - just 3-4 digits
            context_patterns=[
                r"cvv",
                r"cvc",
                r"cvv2",
                r"cid",
                r"security\s*code",
                r"card\s*verification",
            ],
        ),

        # =====================================================================
        # Bank Account Numbers
        # =====================================================================

        # US Bank Account Number
        Pattern(
            name="bank_account_us",
            data_type=DataType.BANK_ACCOUNT,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b\d{8,17}\b"
            ),
            validator=validate_bank_account_number,
            confidence_base=0.35,  # Slightly higher base
            context_patterns=[
                r"account\s*(?:number|#|no\.?)",
                r"checking\s*(?:account)?",
                r"savings\s*(?:account)?",
                r"bank\s*account",
                r"acct\.?\s*(?:no\.?|#)?",
                r"deposit\s*account",
                r"direct\s*deposit",
                r"wire\s*transfer",
                r"ach",
                r"banking",
                r"financial",
            ],
        ),

        # UK Bank Account Number
        Pattern(
            name="bank_account_uk",
            data_type=DataType.BANK_ACCOUNT,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b\d{8}\b"
            ),
            confidence_base=0.25,
            context_patterns=[
                r"account\s*number",
                r"uk\s*bank",
                r"current\s*account",
                r"sort\s*code",
            ],
        ),

        # US Routing Number (ABA)
        Pattern(
            name="routing_number_us",
            data_type=DataType.ROUTING_NUMBER,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b\d{9}\b"
            ),
            validator=validate_routing_number,
            confidence_base=0.70,
            context_patterns=[
                r"routing",
                r"aba",
                r"transit",
                r"bank",
                r"wire",
                r"ach",
                r"direct\s*deposit",
                r"financial",
                r"transfer",
                r"account",
            ],
        ),

        # UK Sort Code
        Pattern(
            name="sort_code_uk",
            data_type=DataType.ROUTING_NUMBER,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b\d{2}[-\s]?\d{2}[-\s]?\d{2}\b"
            ),
            validator=validate_uk_sort_code,
            confidence_base=0.55,
            context_patterns=[
                r"sort\s*code",
                r"uk\s*bank",
                r"branch\s*code",
            ],
        ),

        # IBAN (International Bank Account Number)
        Pattern(
            name="iban",
            data_type=DataType.BANK_ACCOUNT,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b[A-Z]{2}\d{2}[\s-]?[A-Z0-9]{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?[\dA-Z]{0,16}\b"
            ),
            validator=validate_iban,
            confidence_base=0.85,
            context_patterns=[
                r"iban",
                r"international\s*bank",
                r"bank\s*account",
                r"sepa",
            ],
        ),

        # SWIFT/BIC Code
        Pattern(
            name="swift_bic",
            data_type=DataType.BANK_ACCOUNT,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}(?:[A-Z0-9]{3})?\b"
            ),
            validator=validate_swift_bic,
            confidence_base=0.70,
            context_patterns=[
                r"swift",
                r"bic",
                r"bank\s*(?:code|identifier)",
                r"wire\s*transfer",
            ],
        ),

        # =====================================================================
        # Tax Identification Numbers
        # =====================================================================

        # EIN (Employer Identification Number) - US
        Pattern(
            name="ein_us",
            data_type=DataType.TAX_ID,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b\d{2}[-\s]?\d{7}\b"
            ),
            confidence_base=0.50,
            context_patterns=[
                r"ein\b",
                r"employer\s*id",
                r"tax\s*id",
                r"federal\s*id",
                r"fein",
                r"employer\s*identification",
            ],
        ),

        # VAT Number (EU)
        Pattern(
            name="vat_eu",
            data_type=DataType.TAX_ID,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b(?:ATU|BE[01]|BG|HR|CY|CZ|DK|EE|FI|FR[A-Z0-9]{2}|DE|EL|HU|IE|IT|LV|LT|LU|MT|NL|PL|PT|RO|SK|SI|ES[A-Z]|SE)\d{8,12}\b"
            ),
            confidence_base=0.80,
            context_patterns=[
                r"vat",
                r"value\s*added\s*tax",
                r"tax\s*registration",
                r"eu\s*vat",
            ],
        ),

        # UK VAT Number
        Pattern(
            name="vat_uk",
            data_type=DataType.TAX_ID,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\bGB\s?\d{3}\s?\d{4}\s?\d{2}(?:\s?\d{3})?\b"
            ),
            confidence_base=0.80,
            context_patterns=[
                r"vat",
                r"uk\s*vat",
                r"hmrc",
            ],
        ),

        # =====================================================================
        # Financial Account Identifiers
        # =====================================================================

        # Brokerage Account Number
        Pattern(
            name="brokerage_account",
            data_type=DataType.BANK_ACCOUNT,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b[A-Z]{0,3}\d{8,12}\b"
            ),
            confidence_base=0.35,
            context_patterns=[
                r"brokerage",
                r"trading\s*account",
                r"investment\s*account",
                r"securities",
                r"portfolio",
            ],
        ),

        # CUSIP (Committee on Uniform Securities Identification Procedures)
        Pattern(
            name="cusip",
            data_type=DataType.CUSTOM,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b[A-Z0-9]{9}\b"
            ),
            confidence_base=0.40,
            context_patterns=[
                r"cusip",
                r"security\s*id",
                r"bond",
                r"stock",
                r"equity",
            ],
        ),

        # ISIN (International Securities Identification Number)
        Pattern(
            name="isin",
            data_type=DataType.CUSTOM,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b[A-Z]{2}[A-Z0-9]{9}\d\b"
            ),
            confidence_base=0.75,
            context_patterns=[
                r"isin",
                r"security",
                r"international\s*securities",
            ],
        ),

        # =====================================================================
        # Cryptocurrency Addresses
        # =====================================================================

        # Bitcoin Address (Legacy P2PKH)
        Pattern(
            name="bitcoin_address_legacy",
            data_type=DataType.CUSTOM,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b"
            ),
            confidence_base=0.70,
            context_patterns=[
                r"bitcoin",
                r"btc",
                r"wallet",
                r"crypto",
                r"address",
            ],
        ),

        # Bitcoin Address (Bech32/SegWit)
        Pattern(
            name="bitcoin_address_segwit",
            data_type=DataType.CUSTOM,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\bbc1[ac-hj-np-z02-9]{39,59}\b"
            ),
            confidence_base=0.80,
            context_patterns=[
                r"bitcoin",
                r"btc",
                r"wallet",
                r"segwit",
            ],
        ),

        # Ethereum Address
        Pattern(
            name="ethereum_address",
            data_type=DataType.CUSTOM,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b0x[a-fA-F0-9]{40}\b"
            ),
            confidence_base=0.85,
            context_patterns=[
                r"ethereum",
                r"eth",
                r"wallet",
                r"crypto",
                r"erc-?20",
            ],
        ),

        # =====================================================================
        # Payment and Transaction Data
        # =====================================================================

        # Magnetic Stripe Track Data (Track 1)
        Pattern(
            name="magstripe_track1",
            data_type=DataType.CREDIT_CARD,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\%B\d{13,19}\^[A-Z\s/]+\^\d{4}\d*\?"
            ),
            confidence_base=0.95,
            context_patterns=[
                r"track\s*1",
                r"magnetic",
                r"stripe",
                r"swipe",
            ],
        ),

        # Magnetic Stripe Track Data (Track 2)
        Pattern(
            name="magstripe_track2",
            data_type=DataType.CREDIT_CARD,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r";\d{13,19}=\d{4}\d*\?"
            ),
            confidence_base=0.95,
            context_patterns=[
                r"track\s*2",
                r"magnetic",
                r"stripe",
                r"swipe",
            ],
        ),

        # PayPal Transaction ID
        Pattern(
            name="paypal_transaction",
            data_type=DataType.CUSTOM,
            category=DataCategory.FINANCIAL,
            regex=re.compile(
                r"\b[A-Z0-9]{17}\b"
            ),
            confidence_base=0.35,
            context_patterns=[
                r"paypal",
                r"transaction\s*id",
                r"payment",
            ],
        ),
    ]
