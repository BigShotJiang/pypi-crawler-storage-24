"""Upload scan results to the Theodolite API."""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)


def upload_results(
    results: dict[str, Any],
    api_url: str,
    token: str,
    timeout: float = 120.0,
) -> dict[str, Any]:
    """POST discovery scan results to the Theodolite import endpoint.

    Args:
        results: The discovery results dict from build_results_json().
        api_url: Base URL of the Theodolite API (e.g. https://api.theodolite.io).
        token: Bearer token for authentication.
        timeout: HTTP request timeout in seconds.

    Returns:
        The import response dict from the API.

    Raises:
        SystemExit: On HTTP errors.
    """
    url = f"{api_url.rstrip('/')}/api/v1/discovery/import"

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }

    try:
        resp = httpx.post(url, json=results, headers=headers, timeout=timeout)
        resp.raise_for_status()
        return resp.json()
    except httpx.HTTPStatusError as exc:
        body = exc.response.text
        logger.error("Upload failed (%d): %s", exc.response.status_code, body)
        raise SystemExit(f"Upload failed ({exc.response.status_code}): {body}")
    except httpx.RequestError as exc:
        logger.error("Connection error: %s", exc)
        raise SystemExit(f"Connection error: {exc}")
