"""Named Entity Recognition (NER) for sensitive data detection.

This module provides spaCy-based NER for detecting sensitive data entities
that may not be caught by regex patterns alone, such as:
- Person names
- Organization names
- Location information
- Dates (potential DOB)
- Medical entities

Ported from the Theodolite backend classifier to keep scanner results
consistent with server-side scans.
"""

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Iterator, List, Optional, Tuple

logger = logging.getLogger(__name__)


class EntityType(str, Enum):
    """Entity types detected by NER."""

    # spaCy standard entities
    PERSON = "PERSON"
    NORP = "NORP"  # Nationalities, religious, political groups
    FAC = "FAC"  # Facilities
    ORG = "ORG"  # Organizations
    GPE = "GPE"  # Geo-political entities
    LOC = "LOC"  # Locations
    PRODUCT = "PRODUCT"
    EVENT = "EVENT"
    WORK_OF_ART = "WORK_OF_ART"
    LAW = "LAW"
    LANGUAGE = "LANGUAGE"
    DATE = "DATE"
    TIME = "TIME"
    PERCENT = "PERCENT"
    MONEY = "MONEY"
    QUANTITY = "QUANTITY"
    ORDINAL = "ORDINAL"
    CARDINAL = "CARDINAL"

    # Custom entities for sensitive data
    MEDICAL_CONDITION = "MEDICAL_CONDITION"
    MEDICATION = "MEDICATION"
    PROCEDURE = "PROCEDURE"
    ANATOMY = "ANATOMY"
    EMAIL_ADDRESS = "EMAIL_ADDRESS"
    PHONE_NUMBER = "PHONE_NUMBER"
    IP_ADDRESS = "IP_ADDRESS"
    URL = "URL"


@dataclass
class Entity:
    """Represents a detected entity."""

    text: str
    label: str
    start: int
    end: int
    confidence: float
    context: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class NERConfig:
    """Configuration for NER processing."""

    # Model settings
    model_name: str = "en_core_web_sm"
    enable_gpu: bool = False

    # Processing settings
    batch_size: int = 1000
    max_text_length: int = 1000000

    # Entity filtering
    min_confidence: float = 0.5
    excluded_labels: List[str] = field(default_factory=lambda: ["CARDINAL", "ORDINAL", "QUANTITY"])

    # Context settings
    context_window: int = 100


class EntityMapper:
    """Maps NER entities to data classification types."""

    # Mapping from spaCy labels to (DataType, DataCategory, base_confidence)
    SPACY_TO_DATA_TYPE: Dict[str, Tuple[str, str, float]] = {
        "PERSON": ("full_name", "pii", 0.55),  # Lowered: needs "patient"/"employee" context to fire
        "DATE": ("date_of_birth", "pii", 0.5),  # Lower confidence, needs context
        "GPE": ("address", "pii", 0.4),  # Geo entities could be part of address
        "LOC": ("address", "pii", 0.4),
        "FAC": ("address", "pii", 0.35),
        "ORG": ("organization", "pii", 0.3),  # Lower confidence for orgs
    }

    # Context patterns that boost confidence for DOB detection
    DOB_CONTEXT_PATTERNS = [
        r"\b(born|birthday|birth\s*date|dob|d\.o\.b|date\s*of\s*birth)\b",
        r"\b(age|years?\s*old)\b",
    ]

    # Context patterns that indicate address
    ADDRESS_CONTEXT_PATTERNS = [
        r"\b(address|street|avenue|blvd|boulevard|road|lane|drive|court|apt|apartment|suite|floor|zip|postal)\b",
        r"\b(city|state|province|country|county)\b",
        r"\b(home|work|office|residence|mailing)\b",
    ]

    # Context patterns for names
    NAME_CONTEXT_PATTERNS = [
        r"\b(name|patient|client|customer|user|employee|applicant|beneficiary)\b",
        r"\b(first\s*name|last\s*name|full\s*name|given\s*name|surname|middle\s*name)\b",
        r"\b(mr\.|mrs\.|ms\.|dr\.|prof\.)\b",
    ]

    @classmethod
    def map_entity(
        cls,
        entity: Entity,
        context: str = "",
    ) -> Tuple[Optional[str], Optional[str], float]:
        """Map an entity to a data type and category with confidence.

        Returns:
            Tuple of (data_type, category, confidence) or (None, None, 0) if not mapped
        """
        if entity.label not in cls.SPACY_TO_DATA_TYPE:
            return None, None, 0.0

        data_type, category, base_confidence = cls.SPACY_TO_DATA_TYPE[entity.label]

        # Apply context-based confidence adjustments
        confidence = base_confidence

        if entity.label == "DATE":
            # Check for DOB context
            for pattern in cls.DOB_CONTEXT_PATTERNS:
                if re.search(pattern, context, re.IGNORECASE):
                    confidence = min(1.0, confidence + 0.25)
                    break
            else:
                # Without DOB context, don't classify as sensitive
                return None, None, 0.0

        elif entity.label in ("GPE", "LOC", "FAC"):
            # Check for address context
            for pattern in cls.ADDRESS_CONTEXT_PATTERNS:
                if re.search(pattern, context, re.IGNORECASE):
                    confidence = min(1.0, confidence + 0.3)
                    break
            else:
                # Without address context, don't classify as PII
                return None, None, 0.0

        elif entity.label == "PERSON":
            # Boost confidence for names in PII context
            for pattern in cls.NAME_CONTEXT_PATTERNS:
                if re.search(pattern, context, re.IGNORECASE):
                    confidence = min(1.0, confidence + 0.15)
                    break

        return data_type, category, confidence


class CustomEntityRuler:
    """Custom entity ruler for sensitive data patterns not in standard NER."""

    def __init__(self) -> None:
        """Initialize the custom entity ruler."""
        self._patterns: List[Tuple[str, str, re.Pattern]] = []
        self._load_default_patterns()

    def _load_default_patterns(self) -> None:
        """Load default sensitive data patterns."""
        patterns = [
            # Medical conditions (common patterns)
            (
                "MEDICAL_CONDITION",
                EntityType.MEDICAL_CONDITION.value,
                re.compile(
                    r"\b(diabetes|hypertension|cancer|asthma|HIV|AIDS|"
                    r"depression|anxiety|COPD|arthritis|hepatitis|"
                    r"pneumonia|tuberculosis|malaria|epilepsy|"
                    r"Alzheimer'?s?|Parkinson'?s?|multiple sclerosis|MS|"
                    r"lupus|fibromyalgia|autism|ADHD|schizophrenia|"
                    r"bipolar disorder|heart disease|stroke|leukemia|"
                    r"lymphoma|melanoma|cirrhosis)\b",
                    re.IGNORECASE,
                ),
            ),
            # Medications (common patterns)
            (
                "MEDICATION",
                EntityType.MEDICATION.value,
                re.compile(
                    r"\b(aspirin|ibuprofen|acetaminophen|metformin|"
                    r"lisinopril|atorvastatin|metoprolol|omeprazole|"
                    r"losartan|amlodipine|simvastatin|levothyroxine|"
                    r"gabapentin|sertraline|fluoxetine|escitalopram|"
                    r"prednisone|amoxicillin|azithromycin|ciprofloxacin|"
                    r"hydrocodone|oxycodone|tramadol|morphine|fentanyl|"
                    r"insulin|warfarin|clopidogrel|furosemide|"
                    r"pantoprazole|duloxetine|venlafaxine|trazodone)\b",
                    re.IGNORECASE,
                ),
            ),
        ]

        for name, label, pattern in patterns:
            self._patterns.append((name, label, pattern))

    def find_entities(self, text: str) -> Iterator[Entity]:
        """Find custom entities in text.

        Args:
            text: Text to search

        Yields:
            Entity objects for each match
        """
        for name, label, pattern in self._patterns:
            for match in pattern.finditer(text):
                yield Entity(
                    text=match.group(),
                    label=label,
                    start=match.start(),
                    end=match.end(),
                    confidence=0.85,  # High confidence for pattern matches
                    metadata={"source": "custom_ruler", "pattern_name": name},
                )


class NERProcessor:
    """Main NER processor for sensitive data detection."""

    def __init__(self, config: Optional[NERConfig] = None) -> None:
        """Initialize the NER processor.

        Args:
            config: NER configuration
        """
        self.config = config or NERConfig()
        self._nlp = None
        self._custom_ruler = CustomEntityRuler()
        self._entity_mapper = EntityMapper()
        self._spacy_available = None

    def _download_model(self, model_name: str) -> bool:
        """Auto-download a spaCy model if not installed."""
        try:
            from spacy.cli import download
            logger.info(f"Downloading spaCy model '{model_name}' (one-time setup)...")
            download(model_name)
            return True
        except Exception as e:
            logger.warning(f"Could not auto-download spaCy model: {e}")
            return False

    def _load_model(self) -> Any:
        """Load the spaCy model, auto-downloading on first run if needed."""
        if self._nlp is not None:
            return self._nlp

        if self._spacy_available is False:
            return None

        try:
            import spacy

            # Try loading the configured model, auto-download if missing
            try:
                self._nlp = spacy.load(self.config.model_name)
                logger.info(f"spaCy model loaded: {self.config.model_name}")
            except OSError:
                # Model not found — try to download it automatically
                if self._download_model(self.config.model_name):
                    try:
                        self._nlp = spacy.load(self.config.model_name)
                    except OSError:
                        logger.error(f"Failed to load model after download: {self.config.model_name}")
                        self._spacy_available = False
                        return None
                else:
                    self._spacy_available = False
                    return None

            # Enable GPU if configured and available
            if self.config.enable_gpu:
                if spacy.prefer_gpu():
                    logger.info("GPU enabled for spaCy")

            # Set max text length
            self._nlp.max_length = self.config.max_text_length
            self._spacy_available = True

            return self._nlp

        except ImportError:
            logger.warning("spaCy not installed. Install with: pip install theodolite-scanner")
            self._spacy_available = False
            return None

    def process(self, text: str) -> List[Entity]:
        """Process text and extract entities.

        Args:
            text: Text to process

        Returns:
            List of detected entities
        """
        entities = []

        # Process with spaCy
        nlp = self._load_model()
        if nlp:
            spacy_entities = self._process_with_spacy(text, nlp)
            entities.extend(spacy_entities)

        # Process with custom ruler
        custom_entities = list(self._custom_ruler.find_entities(text))
        entities.extend(custom_entities)

        # Deduplicate and merge
        entities = self._deduplicate_entities(entities)

        return entities

    def _process_with_spacy(self, text: str, nlp: Any) -> List[Entity]:
        """Process text with spaCy NER.

        Args:
            text: Text to process
            nlp: spaCy model

        Returns:
            List of entities
        """
        entities = []

        # Handle text longer than max_length by chunking
        max_length = nlp.max_length
        chunks = []

        if len(text) > max_length:
            # Split into chunks, trying to break at sentence boundaries
            current_pos = 0
            while current_pos < len(text):
                chunk_end = min(current_pos + max_length, len(text))

                # Try to find a sentence boundary
                if chunk_end < len(text):
                    for i in range(chunk_end, max(current_pos, chunk_end - 1000), -1):
                        if text[i] in ".!?\n":
                            chunk_end = i + 1
                            break

                chunks.append((current_pos, text[current_pos:chunk_end]))
                current_pos = chunk_end
        else:
            chunks = [(0, text)]

        # Process each chunk
        for offset, chunk in chunks:
            try:
                doc = nlp(chunk)

                for ent in doc.ents:
                    # Skip excluded labels
                    if ent.label_ in self.config.excluded_labels:
                        continue

                    # Extract context
                    context_start = max(0, ent.start_char - self.config.context_window)
                    context_end = min(len(chunk), ent.end_char + self.config.context_window)
                    context = chunk[context_start:context_end]

                    entity = Entity(
                        text=ent.text,
                        label=ent.label_,
                        start=offset + ent.start_char,
                        end=offset + ent.end_char,
                        confidence=0.7,  # Base confidence for spaCy
                        context=context,
                        metadata={
                            "source": "spacy",
                            "model": self.config.model_name,
                        },
                    )

                    entities.append(entity)
            except Exception as e:
                logger.warning(f"Error processing chunk with spaCy: {e}")

        return entities

    def _deduplicate_entities(self, entities: List[Entity]) -> List[Entity]:
        """Remove duplicate or overlapping entities.

        Args:
            entities: List of entities

        Returns:
            Deduplicated list
        """
        if not entities:
            return entities

        # Sort by start position, then by length (longer first)
        sorted_entities = sorted(
            entities,
            key=lambda e: (e.start, -(e.end - e.start)),
        )

        deduplicated = []
        last_end = -1

        for entity in sorted_entities:
            # Skip if this entity overlaps with a previous one
            if entity.start < last_end:
                continue

            deduplicated.append(entity)
            last_end = entity.end

        return deduplicated

    def map_to_classification(
        self,
        entities: List[Entity],
        text: str,
    ) -> List[Dict[str, Any]]:
        """Map entities to classification findings.

        Args:
            entities: List of detected entities
            text: Original text for context extraction

        Returns:
            List of classification findings
        """
        findings = []

        for entity in entities:
            # Get context
            context_start = max(0, entity.start - self.config.context_window)
            context_end = min(len(text), entity.end + self.config.context_window)
            context = text[context_start:context_end]

            # Map to data type
            data_type, category, confidence = self._entity_mapper.map_entity(
                entity, context
            )

            if data_type is None:
                # Check custom entity types
                custom_mapping = self._map_custom_entity(entity.label)
                if custom_mapping:
                    data_type, category, confidence = custom_mapping
                else:
                    continue

            # Adjust confidence based on entity confidence
            final_confidence = entity.confidence * confidence

            if final_confidence < self.config.min_confidence:
                continue

            finding = {
                "data_type": data_type,
                "category": category,
                "confidence": final_confidence,
                "matched_text": entity.text,
                "start": entity.start,
                "end": entity.end,
                "context": context,
                "source": "ner",
                "entity_label": entity.label,
                "metadata": entity.metadata,
            }

            findings.append(finding)

        return findings

    def _map_custom_entity(
        self,
        label: str,
    ) -> Optional[Tuple[str, str, float]]:
        """Map custom entity labels to classification types.

        Args:
            label: Entity label

        Returns:
            Tuple of (data_type, category, confidence) or None
        """
        custom_mapping = {
            EntityType.MEDICAL_CONDITION.value: ("diagnosis_code", "phi", 0.9),
            EntityType.MEDICATION.value: ("medical_record", "phi", 0.85),
            EntityType.PROCEDURE.value: ("medical_record", "phi", 0.85),
        }

        return custom_mapping.get(label)


def get_ner_processor(config: Optional[NERConfig] = None) -> NERProcessor:
    """Get a configured NER processor.

    Args:
        config: Optional NER configuration

    Returns:
        Configured NERProcessor
    """
    return NERProcessor(config=config)
