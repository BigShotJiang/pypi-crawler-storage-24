"""Scan orchestrator — enumerate objects, download, extract text, classify.

Supports two modes per provider:
1. Auto-discover: credentials → find all buckets/containers automatically
2. Explicit: bucket/container name → scan a single known target

Providers: Azure Blob Storage, AWS S3, Google Cloud Storage.
"""

from __future__ import annotations

import logging
import random
from typing import Optional

import click

from theodolite_scanner.classifier import Classifier, Finding
from theodolite_scanner.file_scanner import can_extract, extract_text
from theodolite_scanner.text_utils import truncate_for_scanning

logger = logging.getLogger(__name__)

# Severity colors for terminal output
_SEV_COLORS = {
    "critical": "red",
    "high": "red",
    "medium": "yellow",
    "low": "white",
}


def _format_size(size_bytes: int | None) -> str:
    """Format bytes into human-readable string."""
    if not size_bytes:
        return "0 B"
    for unit in ("B", "KB", "MB", "GB"):
        if abs(size_bytes) < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def _apply_sampling(
    items: list,
    scan_type: str,
    sample_percentage: int,
) -> list:
    """Apply sampling to a list of scannable items."""
    if scan_type == "quick":
        sample_pct = 5
    elif scan_type == "random":
        sample_pct = sample_percentage
    else:
        sample_pct = 100

    if sample_pct < 100 and len(items) > 0:
        sample_count = max(1, int(len(items) * sample_pct / 100))
        items = random.sample(items, sample_count)
        click.echo(f"    Sampling {len(items)} objects ({sample_pct}%)")

    return items


def _classify_and_report(
    classifier: Classifier,
    text: str,
    location: str,
    categories: list[str] | None,
    all_findings: list[Finding],
) -> int:
    """Classify text, print findings, return count."""
    findings = classifier.classify_text(
        text=text,
        location=location,
        categories=categories,
    )
    all_findings.extend(findings)

    if findings:
        click.echo(click.style(f" — {len(findings)} finding(s)!", fg="red"))
        for f in findings:
            sev_color = _SEV_COLORS.get(f.severity.value, "white")
            click.echo(
                f"          "
                + click.style(f"[{f.severity.value.upper()}]", fg=sev_color)
                + f" {f.data_type.value} ({f.category.value})"
                + f" — confidence {f.confidence:.0%}"
                + f", line {f.line_number}"
            )
    else:
        click.echo(click.style(" — clean", fg="green"))

    return len(findings)


# ===========================================================================
# Azure Blob Storage
# ===========================================================================


def discover_containers(
    client_id: str,
    tenant_id: str,
    client_secret: str,
    subscription_id: str | None = None,
) -> list[dict]:
    """Discover all blob containers across Azure subscriptions."""
    try:
        from azure.identity import ClientSecretCredential
        from azure.mgmt.resource import SubscriptionClient
        from azure.mgmt.storage import StorageManagementClient
    except ImportError:
        raise SystemExit(
            "Azure management SDK not installed. Run: pip install 'theodolite-scanner[azure]'"
        )

    credential = ClientSecretCredential(
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret,
    )

    # Get subscriptions
    click.echo("  Authenticating with Azure...")
    if subscription_id:
        sub_ids = [subscription_id]
        click.echo(f"  Using subscription: {subscription_id}")
    else:
        sub_client = SubscriptionClient(credential)
        subs = list(sub_client.subscriptions.list())
        sub_ids = [s.subscription_id for s in subs]
        click.echo(f"  Found {len(sub_ids)} subscription(s)")
        for s in subs:
            click.echo(f"    • {s.display_name} ({s.subscription_id})")

    containers = []

    for sub_id in sub_ids:
        click.echo()
        click.echo(f"  Discovering storage accounts in {sub_id[:8]}...")
        storage_client = StorageManagementClient(credential, sub_id)

        try:
            accounts = list(storage_client.storage_accounts.list())
            click.echo(f"  Found {len(accounts)} storage account(s)")

            for account in accounts:
                parts = account.id.split("/")
                resource_group = parts[4] if len(parts) > 4 else "unknown"
                account_url = f"https://{account.name}.blob.core.windows.net"

                click.echo(f"    {account.name} ({account.location})")

                try:
                    account_containers = list(
                        storage_client.blob_containers.list(resource_group, account.name)
                    )
                    for ctr in account_containers:
                        containers.append({
                            "subscription_id": sub_id,
                            "storage_account": account.name,
                            "container_name": ctr.name,
                            "resource_group": resource_group,
                            "account_url": account_url,
                        })
                        click.echo(f"      └── {ctr.name}")
                except Exception as e:
                    click.echo(
                        click.style(f"      └── Could not list containers: {e}", fg="yellow")
                    )
        except Exception as e:
            click.echo(
                click.style(f"    Could not list storage accounts: {e}", fg="yellow")
            )

    click.echo()
    click.echo(f"  Total: {len(containers)} container(s) across all accounts")
    return containers


def scan_container(
    account_url: str,
    container: str,
    credential,
    scan_type: str = "full",
    sample_percentage: int = 5,
    categories: list[str] | None = None,
    max_file_size_mb: int = 100,
    on_progress: callable | None = None,
    classifier: Classifier | None = None,
    progress_offset: int = 0,
    progress_total_override: int | None = None,
) -> tuple[list[Finding], int, int]:
    """Scan a single Azure Blob container for sensitive data."""
    from azure.storage.blob import BlobServiceClient

    blob_service = BlobServiceClient(account_url=account_url, credential=credential)
    container_client = blob_service.get_container_client(container)

    # Enumerate blobs
    click.echo(f"    Listing blobs...")
    all_blobs = []
    max_size_bytes = max_file_size_mb * 1024 * 1024

    for blob in container_client.list_blobs():
        all_blobs.append(blob)

    total_discovered = len(all_blobs)

    # Filter to supported extensions
    scannable_blobs = [
        b for b in all_blobs
        if can_extract(b.name, max_size_bytes, b.size)
    ]

    skipped = total_discovered - len(scannable_blobs)
    click.echo(
        f"    {total_discovered} blobs found, "
        f"{len(scannable_blobs)} scannable"
        + (f", {skipped} skipped (unsupported/too large)" if skipped else "")
    )

    scannable_blobs = _apply_sampling(scannable_blobs, scan_type, sample_percentage)

    if classifier is None:
        classifier = Classifier()

    all_findings: list[Finding] = []
    assets_scanned = 0
    container_findings_count = 0

    for i, blob in enumerate(scannable_blobs):
        try:
            size_str = _format_size(blob.size)
            click.echo(
                f"    [{i+1}/{len(scannable_blobs)}] {blob.name} ({size_str})",
                nl=False,
            )

            blob_client = container_client.get_blob_client(blob.name)
            content = blob_client.download_blob().readall()

            text = extract_text(content, blob.name)
            if not text:
                click.echo(" — no text extracted")
                continue

            text = truncate_for_scanning(text)
            location = f"{container}/{blob.name}"
            count = _classify_and_report(classifier, text, location, categories, all_findings)
            assets_scanned += 1
            container_findings_count += count

            if on_progress:
                display_scanned = progress_offset + assets_scanned
                display_total = progress_total_override or len(scannable_blobs)
                on_progress(display_scanned, display_total, blob.name)

        except Exception as e:
            click.echo(click.style(f" — error: {e}", fg="yellow"))

    click.echo(
        f"    Done: {assets_scanned} scanned, "
        + click.style(f"{container_findings_count} findings", fg="red" if container_findings_count else "green")
    )
    return all_findings, total_discovered, assets_scanned


def run_azure_scan(
    account_url: str,
    container: str,
    scan_type: str = "full",
    sample_percentage: int = 5,
    categories: Optional[list[str]] = None,
    max_file_size_mb: int = 100,
    on_progress: Optional[callable] = None,
) -> tuple[list[Finding], int, int]:
    """Scan a single Azure Blob container using DefaultAzureCredential."""
    try:
        from azure.identity import DefaultAzureCredential
    except ImportError:
        raise SystemExit(
            "Azure SDK not installed. Run: pip install 'theodolite-scanner[azure]'"
        )

    credential = DefaultAzureCredential()
    return scan_container(
        account_url=account_url,
        container=container,
        credential=credential,
        scan_type=scan_type,
        sample_percentage=sample_percentage,
        categories=categories,
        max_file_size_mb=max_file_size_mb,
        on_progress=on_progress,
    )


def run_azure_discover_scan(
    client_id: str,
    tenant_id: str,
    client_secret: str,
    subscription_id: str | None = None,
    scan_type: str = "full",
    sample_percentage: int = 5,
    categories: list[str] | None = None,
    max_file_size_mb: int = 100,
    on_progress: callable | None = None,
) -> tuple[list[Finding], int, int, list[dict]]:
    """Auto-discover all Azure containers and scan them."""
    try:
        from azure.identity import ClientSecretCredential
    except ImportError:
        raise SystemExit(
            "Azure SDK not installed. Run: pip install 'theodolite-scanner[azure]'"
        )

    # Phase 1: Discover
    click.echo()
    click.echo("=" * 60)
    click.echo("  Phase 1: Discovering storage accounts & containers")
    click.echo("=" * 60)
    click.echo()

    containers = discover_containers(
        client_id=client_id,
        tenant_id=tenant_id,
        client_secret=client_secret,
        subscription_id=subscription_id,
    )

    if not containers:
        click.echo(click.style("  No blob containers found.", fg="yellow"))
        return [], 0, 0, []

    # Phase 2: Scan
    click.echo()
    click.echo("=" * 60)
    click.echo(f"  Phase 2: Scanning {len(containers)} container(s) for sensitive data")
    click.echo("=" * 60)

    credential = ClientSecretCredential(
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret,
    )

    classifier = Classifier()

    all_findings: list[Finding] = []
    total_discovered = 0
    total_scanned = 0

    for idx, ctr in enumerate(containers):
        click.echo()
        click.echo(
            f"  [{idx+1}/{len(containers)}] "
            f"{ctr['storage_account']}/{ctr['container_name']}"
        )

        findings, discovered, scanned = scan_container(
            account_url=ctr["account_url"],
            container=ctr["container_name"],
            credential=credential,
            scan_type=scan_type,
            sample_percentage=sample_percentage,
            categories=categories,
            max_file_size_mb=max_file_size_mb,
            on_progress=on_progress,
            classifier=classifier,
            progress_offset=total_scanned,
        )

        all_findings.extend(findings)
        total_discovered += discovered
        total_scanned += scanned

    click.echo()
    click.echo("=" * 60)
    click.echo(
        f"  All done: {len(containers)} containers, "
        f"{total_scanned} files scanned, "
        f"{len(all_findings)} findings"
    )
    click.echo("=" * 60)
    return all_findings, total_discovered, total_scanned, containers


# ===========================================================================
# AWS S3
# ===========================================================================


def discover_s3_buckets(
    access_key_id: str | None = None,
    secret_access_key: str | None = None,
    region: str = "us-east-1",
    profile: str | None = None,
) -> list[dict]:
    """Discover all S3 buckets accessible to the credentials."""
    try:
        import boto3
    except ImportError:
        raise SystemExit(
            "AWS SDK not installed. Run: pip install 'theodolite-scanner[aws]'"
        )

    click.echo("  Authenticating with AWS...")

    session_kwargs: dict = {}
    if profile:
        session_kwargs["profile_name"] = profile
    if access_key_id and secret_access_key:
        session_kwargs["aws_access_key_id"] = access_key_id
        session_kwargs["aws_secret_access_key"] = secret_access_key
    session_kwargs["region_name"] = region

    session = boto3.Session(**session_kwargs)
    s3 = session.client("s3")

    try:
        response = s3.list_buckets()
    except Exception as e:
        click.echo(click.style(f"  Could not list buckets: {e}", fg="yellow"))
        return []

    buckets = []
    for b in response.get("Buckets", []):
        name = b["Name"]
        created = b.get("CreationDate", "")
        click.echo(f"    • {name} (created: {created})")

        # Get bucket region
        try:
            loc = s3.get_bucket_location(Bucket=name)
            bucket_region = loc.get("LocationConstraint") or "us-east-1"
        except Exception:
            bucket_region = region

        buckets.append({
            "bucket_name": name,
            "region": bucket_region,
        })

    click.echo()
    click.echo(f"  Total: {len(buckets)} bucket(s)")
    return buckets


def scan_s3_bucket(
    bucket: str,
    region: str = "us-east-1",
    access_key_id: str | None = None,
    secret_access_key: str | None = None,
    profile: str | None = None,
    prefix: str | None = None,
    scan_type: str = "full",
    sample_percentage: int = 5,
    categories: list[str] | None = None,
    max_file_size_mb: int = 100,
    on_progress: callable | None = None,
    classifier: Classifier | None = None,
    progress_offset: int = 0,
    progress_total_override: int | None = None,
) -> tuple[list[Finding], int, int]:
    """Scan a single S3 bucket for sensitive data."""
    try:
        import boto3
    except ImportError:
        raise SystemExit(
            "AWS SDK not installed. Run: pip install 'theodolite-scanner[aws]'"
        )

    session_kwargs: dict = {}
    if profile:
        session_kwargs["profile_name"] = profile
    if access_key_id and secret_access_key:
        session_kwargs["aws_access_key_id"] = access_key_id
        session_kwargs["aws_secret_access_key"] = secret_access_key
    session_kwargs["region_name"] = region

    session = boto3.Session(**session_kwargs)
    s3 = session.client("s3")

    # Enumerate objects
    click.echo(f"    Listing objects...")
    all_objects = []
    max_size_bytes = max_file_size_mb * 1024 * 1024

    paginator = s3.get_paginator("list_objects_v2")
    page_kwargs: dict = {"Bucket": bucket}
    if prefix:
        page_kwargs["Prefix"] = prefix

    for page in paginator.paginate(**page_kwargs):
        for obj in page.get("Contents", []):
            # Skip directory markers
            if obj["Key"].endswith("/"):
                continue
            all_objects.append(obj)

    total_discovered = len(all_objects)

    # Filter to supported extensions
    scannable = [
        o for o in all_objects
        if can_extract(o["Key"], max_size_bytes, o.get("Size", 0))
    ]

    skipped = total_discovered - len(scannable)
    click.echo(
        f"    {total_discovered} objects found, "
        f"{len(scannable)} scannable"
        + (f", {skipped} skipped (unsupported/too large)" if skipped else "")
    )

    scannable = _apply_sampling(scannable, scan_type, sample_percentage)

    if classifier is None:
        classifier = Classifier()

    all_findings: list[Finding] = []
    assets_scanned = 0
    bucket_findings_count = 0

    for i, obj in enumerate(scannable):
        key = obj["Key"]
        try:
            size_str = _format_size(obj.get("Size", 0))
            click.echo(
                f"    [{i+1}/{len(scannable)}] {key} ({size_str})",
                nl=False,
            )

            response = s3.get_object(Bucket=bucket, Key=key)
            content = response["Body"].read()

            text = extract_text(content, key)
            if not text:
                click.echo(" — no text extracted")
                continue

            text = truncate_for_scanning(text)
            location = f"{bucket}/{key}"
            count = _classify_and_report(classifier, text, location, categories, all_findings)
            assets_scanned += 1
            bucket_findings_count += count

            if on_progress:
                display_scanned = progress_offset + assets_scanned
                display_total = progress_total_override or len(scannable)
                on_progress(display_scanned, display_total, key)

        except Exception as e:
            click.echo(click.style(f" — error: {e}", fg="yellow"))

    click.echo(
        f"    Done: {assets_scanned} scanned, "
        + click.style(f"{bucket_findings_count} findings", fg="red" if bucket_findings_count else "green")
    )
    return all_findings, total_discovered, assets_scanned


def run_aws_scan(
    bucket: str,
    region: str = "us-east-1",
    access_key_id: str | None = None,
    secret_access_key: str | None = None,
    profile: str | None = None,
    prefix: str | None = None,
    scan_type: str = "full",
    sample_percentage: int = 5,
    categories: Optional[list[str]] = None,
    max_file_size_mb: int = 100,
    on_progress: Optional[callable] = None,
) -> tuple[list[Finding], int, int]:
    """Scan a single S3 bucket."""
    return scan_s3_bucket(
        bucket=bucket,
        region=region,
        access_key_id=access_key_id,
        secret_access_key=secret_access_key,
        profile=profile,
        prefix=prefix,
        scan_type=scan_type,
        sample_percentage=sample_percentage,
        categories=categories,
        max_file_size_mb=max_file_size_mb,
        on_progress=on_progress,
    )


def run_aws_discover_scan(
    access_key_id: str | None = None,
    secret_access_key: str | None = None,
    region: str = "us-east-1",
    profile: str | None = None,
    prefix: str | None = None,
    scan_type: str = "full",
    sample_percentage: int = 5,
    categories: list[str] | None = None,
    max_file_size_mb: int = 100,
    on_progress: callable | None = None,
) -> tuple[list[Finding], int, int, list[dict]]:
    """Auto-discover all S3 buckets and scan them."""
    # Phase 1: Discover
    click.echo()
    click.echo("=" * 60)
    click.echo("  Phase 1: Discovering S3 buckets")
    click.echo("=" * 60)
    click.echo()

    buckets = discover_s3_buckets(
        access_key_id=access_key_id,
        secret_access_key=secret_access_key,
        region=region,
        profile=profile,
    )

    if not buckets:
        click.echo(click.style("  No S3 buckets found.", fg="yellow"))
        return [], 0, 0, []

    # Phase 2: Scan
    click.echo()
    click.echo("=" * 60)
    click.echo(f"  Phase 2: Scanning {len(buckets)} bucket(s) for sensitive data")
    click.echo("=" * 60)

    classifier = Classifier()

    all_findings: list[Finding] = []
    total_discovered = 0
    total_scanned = 0

    for idx, b in enumerate(buckets):
        click.echo()
        click.echo(f"  [{idx+1}/{len(buckets)}] s3://{b['bucket_name']}")

        findings, discovered, scanned = scan_s3_bucket(
            bucket=b["bucket_name"],
            region=b["region"],
            access_key_id=access_key_id,
            secret_access_key=secret_access_key,
            profile=profile,
            prefix=prefix,
            scan_type=scan_type,
            sample_percentage=sample_percentage,
            categories=categories,
            max_file_size_mb=max_file_size_mb,
            on_progress=on_progress,
            classifier=classifier,
            progress_offset=total_scanned,
        )

        all_findings.extend(findings)
        total_discovered += discovered
        total_scanned += scanned

    click.echo()
    click.echo("=" * 60)
    click.echo(
        f"  All done: {len(buckets)} buckets, "
        f"{total_scanned} files scanned, "
        f"{len(all_findings)} findings"
    )
    click.echo("=" * 60)
    return all_findings, total_discovered, total_scanned, buckets


# ===========================================================================
# Google Cloud Storage
# ===========================================================================


def discover_gcs_buckets(
    project: str | None = None,
    credentials_file: str | None = None,
) -> list[dict]:
    """Discover all GCS buckets accessible to the credentials."""
    try:
        from google.cloud import storage
    except ImportError:
        raise SystemExit(
            "GCP SDK not installed. Run: pip install 'theodolite-scanner[gcp]'"
        )

    click.echo("  Authenticating with GCP...")

    client = _get_gcs_client(project=project, credentials_file=credentials_file)

    try:
        bucket_list = list(client.list_buckets())
    except Exception as e:
        click.echo(click.style(f"  Could not list buckets: {e}", fg="yellow"))
        return []

    buckets = []
    for b in bucket_list:
        click.echo(f"    • {b.name} (location: {b.location})")
        buckets.append({
            "bucket_name": b.name,
            "location": b.location or "",
            "project": project or "",
        })

    click.echo()
    click.echo(f"  Total: {len(buckets)} bucket(s)")
    return buckets


def _get_gcs_client(
    project: str | None = None,
    credentials_file: str | None = None,
):
    """Build a GCS client from credentials."""
    from google.cloud import storage

    if credentials_file:
        from google.oauth2 import service_account
        credentials = service_account.Credentials.from_service_account_file(credentials_file)
        detected_project = project or getattr(credentials, "project_id", None)
        return storage.Client(project=detected_project, credentials=credentials)

    # Default credentials (ADC / gcloud auth)
    return storage.Client(project=project)


def scan_gcs_bucket(
    bucket_name: str,
    project: str | None = None,
    credentials_file: str | None = None,
    prefix: str | None = None,
    scan_type: str = "full",
    sample_percentage: int = 5,
    categories: list[str] | None = None,
    max_file_size_mb: int = 100,
    on_progress: callable | None = None,
    classifier: Classifier | None = None,
    progress_offset: int = 0,
    progress_total_override: int | None = None,
    _client=None,
) -> tuple[list[Finding], int, int]:
    """Scan a single GCS bucket for sensitive data."""
    try:
        from google.cloud import storage
    except ImportError:
        raise SystemExit(
            "GCP SDK not installed. Run: pip install 'theodolite-scanner[gcp]'"
        )

    client = _client or _get_gcs_client(project=project, credentials_file=credentials_file)
    bucket = client.bucket(bucket_name)

    # Enumerate blobs
    click.echo(f"    Listing objects...")
    all_blobs = []
    max_size_bytes = max_file_size_mb * 1024 * 1024

    for blob in bucket.list_blobs(prefix=prefix):
        # Skip directory markers
        if blob.name.endswith("/"):
            continue
        all_blobs.append(blob)

    total_discovered = len(all_blobs)

    # Filter to supported extensions
    scannable = [
        b for b in all_blobs
        if can_extract(b.name, max_size_bytes, b.size)
    ]

    skipped = total_discovered - len(scannable)
    click.echo(
        f"    {total_discovered} objects found, "
        f"{len(scannable)} scannable"
        + (f", {skipped} skipped (unsupported/too large)" if skipped else "")
    )

    scannable = _apply_sampling(scannable, scan_type, sample_percentage)

    if classifier is None:
        classifier = Classifier()

    all_findings: list[Finding] = []
    assets_scanned = 0
    bucket_findings_count = 0

    for i, blob in enumerate(scannable):
        try:
            size_str = _format_size(blob.size)
            click.echo(
                f"    [{i+1}/{len(scannable)}] {blob.name} ({size_str})",
                nl=False,
            )

            content = blob.download_as_bytes()

            text = extract_text(content, blob.name)
            if not text:
                click.echo(" — no text extracted")
                continue

            text = truncate_for_scanning(text)
            location = f"{bucket_name}/{blob.name}"
            count = _classify_and_report(classifier, text, location, categories, all_findings)
            assets_scanned += 1
            bucket_findings_count += count

            if on_progress:
                display_scanned = progress_offset + assets_scanned
                display_total = progress_total_override or len(scannable)
                on_progress(display_scanned, display_total, blob.name)

        except Exception as e:
            click.echo(click.style(f" — error: {e}", fg="yellow"))

    click.echo(
        f"    Done: {assets_scanned} scanned, "
        + click.style(f"{bucket_findings_count} findings", fg="red" if bucket_findings_count else "green")
    )
    return all_findings, total_discovered, assets_scanned


def run_gcp_scan(
    bucket: str,
    project: str | None = None,
    credentials_file: str | None = None,
    prefix: str | None = None,
    scan_type: str = "full",
    sample_percentage: int = 5,
    categories: Optional[list[str]] = None,
    max_file_size_mb: int = 100,
    on_progress: Optional[callable] = None,
) -> tuple[list[Finding], int, int]:
    """Scan a single GCS bucket."""
    return scan_gcs_bucket(
        bucket_name=bucket,
        project=project,
        credentials_file=credentials_file,
        prefix=prefix,
        scan_type=scan_type,
        sample_percentage=sample_percentage,
        categories=categories,
        max_file_size_mb=max_file_size_mb,
        on_progress=on_progress,
    )


def run_gcp_discover_scan(
    project: str | None = None,
    credentials_file: str | None = None,
    prefix: str | None = None,
    scan_type: str = "full",
    sample_percentage: int = 5,
    categories: list[str] | None = None,
    max_file_size_mb: int = 100,
    on_progress: callable | None = None,
) -> tuple[list[Finding], int, int, list[dict]]:
    """Auto-discover all GCS buckets and scan them."""
    # Phase 1: Discover
    click.echo()
    click.echo("=" * 60)
    click.echo("  Phase 1: Discovering GCS buckets")
    click.echo("=" * 60)
    click.echo()

    buckets = discover_gcs_buckets(
        project=project,
        credentials_file=credentials_file,
    )

    if not buckets:
        click.echo(click.style("  No GCS buckets found.", fg="yellow"))
        return [], 0, 0, []

    # Phase 2: Scan
    click.echo()
    click.echo("=" * 60)
    click.echo(f"  Phase 2: Scanning {len(buckets)} bucket(s) for sensitive data")
    click.echo("=" * 60)

    client = _get_gcs_client(project=project, credentials_file=credentials_file)
    classifier = Classifier()

    all_findings: list[Finding] = []
    total_discovered = 0
    total_scanned = 0

    for idx, b in enumerate(buckets):
        click.echo()
        click.echo(f"  [{idx+1}/{len(buckets)}] gs://{b['bucket_name']}")

        findings, discovered, scanned = scan_gcs_bucket(
            bucket_name=b["bucket_name"],
            prefix=prefix,
            scan_type=scan_type,
            sample_percentage=sample_percentage,
            categories=categories,
            max_file_size_mb=max_file_size_mb,
            on_progress=on_progress,
            classifier=classifier,
            progress_offset=total_scanned,
            _client=client,
        )

        all_findings.extend(findings)
        total_discovered += discovered
        total_scanned += scanned

    click.echo()
    click.echo("=" * 60)
    click.echo(
        f"  All done: {len(buckets)} buckets, "
        f"{total_scanned} files scanned, "
        f"{len(all_findings)} findings"
    )
    click.echo("=" * 60)
    return all_findings, total_discovered, total_scanned, buckets
