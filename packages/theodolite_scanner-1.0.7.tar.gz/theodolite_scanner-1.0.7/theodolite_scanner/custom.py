"""Custom pattern loader for YAML-defined patterns.

This module allows loading custom sensitive data patterns from YAML files,
enabling users to define their own detection rules.

Ported from the Theodolite backend classifier to keep scanner results
consistent with server-side scans.
"""

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

logger = logging.getLogger(__name__)


@dataclass
class CustomPatternConfig:
    """Configuration for custom patterns."""

    patterns_dir: Optional[Path] = None
    patterns_file: Optional[Path] = None
    enable_validation: bool = True


@dataclass
class CustomPattern:
    """A custom pattern loaded from YAML."""

    name: str
    regex: str
    data_type: str
    category: str
    confidence: float = 0.8
    description: str = ""
    context_patterns: List[str] = field(default_factory=list)
    validator: Optional[str] = None  # Name of validator function
    enabled: bool = True
    tags: List[str] = field(default_factory=list)

    def to_compiled_pattern(self) -> "CompiledCustomPattern":
        """Compile this pattern for matching."""
        compiled_regex = re.compile(self.regex, re.IGNORECASE | re.MULTILINE)
        validator_func = self._get_validator_function()

        return CompiledCustomPattern(
            name=self.name,
            regex=compiled_regex,
            data_type=self.data_type,
            category=self.category,
            confidence=self.confidence,
            context_patterns=self.context_patterns,
            validator=validator_func,
            description=self.description,
            tags=self.tags,
        )

    def _get_validator_function(self) -> Optional[Callable[[str], bool]]:
        """Get the validator function by name."""
        if not self.validator:
            return None

        validators = get_builtin_validators()
        return validators.get(self.validator)


@dataclass
class CompiledCustomPattern:
    """A compiled custom pattern ready for matching."""

    name: str
    regex: re.Pattern
    data_type: str
    category: str
    confidence: float
    context_patterns: List[str]
    validator: Optional[Callable[[str], bool]]
    description: str
    tags: List[str]


def get_builtin_validators() -> Dict[str, Callable[[str], bool]]:
    """Get built-in validator functions for custom patterns."""

    def luhn_check(card_number: str) -> bool:
        """Validate credit card number using Luhn algorithm."""
        digits = re.sub(r"[^0-9]", "", card_number)
        if len(digits) < 13 or len(digits) > 19:
            return False

        total = 0
        reverse_digits = digits[::-1]
        for i, digit in enumerate(reverse_digits):
            d = int(digit)
            if i % 2 == 1:
                d *= 2
                if d > 9:
                    d -= 9
            total += d

        return total % 10 == 0

    def ssn_check(ssn: str) -> bool:
        """Validate SSN format (basic check)."""
        digits = re.sub(r"[^0-9]", "", ssn)
        if len(digits) != 9:
            return False

        # Check for invalid SSNs
        area = int(digits[:3])
        group = int(digits[3:5])
        serial = int(digits[5:])

        # Invalid area numbers
        if area == 0 or area == 666 or area >= 900:
            return False

        # All zeros in any group is invalid
        if group == 0 or serial == 0:
            return False

        return True

    def email_check(email: str) -> bool:
        """Validate email format."""
        email_pattern = re.compile(
            r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        )
        return bool(email_pattern.match(email))

    def phone_check(phone: str) -> bool:
        """Validate phone number (basic check)."""
        digits = re.sub(r"[^0-9]", "", phone)
        return 10 <= len(digits) <= 15

    def ip_address_check(ip: str) -> bool:
        """Validate IPv4 address."""
        parts = ip.split(".")
        if len(parts) != 4:
            return False

        for part in parts:
            try:
                num = int(part)
                if num < 0 or num > 255:
                    return False
            except ValueError:
                return False

        return True

    def iban_check(iban: str) -> bool:
        """Validate IBAN format."""
        iban = iban.replace(" ", "").upper()
        if len(iban) < 15 or len(iban) > 34:
            return False

        # Move first 4 chars to end
        rearranged = iban[4:] + iban[:4]

        # Convert letters to numbers (A=10, B=11, etc.)
        numeric = ""
        for char in rearranged:
            if char.isdigit():
                numeric += char
            else:
                numeric += str(ord(char) - 55)

        # Check mod 97
        return int(numeric) % 97 == 1

    return {
        "luhn": luhn_check,
        "ssn": ssn_check,
        "email": email_check,
        "phone": phone_check,
        "ip_address": ip_address_check,
        "iban": iban_check,
    }


class CustomPatternLoader:
    """Loader for custom patterns from YAML files."""

    def __init__(self, config: Optional[CustomPatternConfig] = None) -> None:
        """Initialize the pattern loader.

        Args:
            config: Configuration for loading patterns
        """
        self.config = config or CustomPatternConfig()
        self._patterns: List[CustomPattern] = []
        self._compiled_patterns: List[CompiledCustomPattern] = []
        self._yaml_available = None

    def load_from_file(self, file_path: Union[Path, str]) -> List[CustomPattern]:
        """Load patterns from a YAML file.

        Args:
            file_path: Path to the YAML file

        Returns:
            List of loaded patterns
        """
        if not self._check_yaml_available():
            logger.warning("PyYAML not installed. Install with: pip install pyyaml")
            return []

        import yaml

        file_path = Path(file_path)
        if not file_path.exists():
            logger.warning(f"Pattern file not found: {file_path}")
            return []

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)

            patterns = self._parse_patterns(data)
            self._patterns.extend(patterns)

            logger.info(f"Loaded {len(patterns)} patterns from {file_path}")
            return patterns

        except Exception as e:
            logger.error(f"Error loading patterns from {file_path}: {e}")
            return []

    def load_from_directory(self, dir_path: Union[Path, str]) -> List[CustomPattern]:
        """Load patterns from all YAML files in a directory.

        Args:
            dir_path: Path to the directory

        Returns:
            List of all loaded patterns
        """
        dir_path = Path(dir_path)
        if not dir_path.exists():
            logger.warning(f"Pattern directory not found: {dir_path}")
            return []

        all_patterns = []

        for yaml_file in dir_path.glob("*.yaml"):
            patterns = self.load_from_file(yaml_file)
            all_patterns.extend(patterns)

        for yml_file in dir_path.glob("*.yml"):
            patterns = self.load_from_file(yml_file)
            all_patterns.extend(patterns)

        return all_patterns

    def _parse_patterns(self, data: Dict[str, Any]) -> List[CustomPattern]:
        """Parse patterns from YAML data.

        Expected format:
        patterns:
          - name: my_pattern
            regex: "\\d{4}-\\d{4}"
            data_type: custom
            category: custom
            confidence: 0.8
            context_patterns:
              - "account"
              - "number"
            validator: luhn
            enabled: true
        """
        if not data or "patterns" not in data:
            return []

        patterns = []
        for pattern_data in data.get("patterns", []):
            try:
                pattern = CustomPattern(
                    name=pattern_data.get("name", "unnamed"),
                    regex=pattern_data.get("regex", ""),
                    data_type=pattern_data.get("data_type", "custom"),
                    category=pattern_data.get("category", "custom"),
                    confidence=float(pattern_data.get("confidence", 0.8)),
                    description=pattern_data.get("description", ""),
                    context_patterns=pattern_data.get("context_patterns", []),
                    validator=pattern_data.get("validator"),
                    enabled=pattern_data.get("enabled", True),
                    tags=pattern_data.get("tags", []),
                )

                # Validate regex compiles
                if self.config.enable_validation:
                    try:
                        re.compile(pattern.regex)
                    except re.error as e:
                        logger.warning(f"Invalid regex in pattern '{pattern.name}': {e}")
                        continue

                if pattern.enabled:
                    patterns.append(pattern)

            except Exception as e:
                logger.warning(f"Error parsing pattern: {e}")
                continue

        return patterns

    def get_compiled_patterns(self) -> List[CompiledCustomPattern]:
        """Get all patterns compiled and ready for matching.

        Returns:
            List of compiled patterns
        """
        if not self._compiled_patterns and self._patterns:
            self._compiled_patterns = [
                p.to_compiled_pattern() for p in self._patterns
            ]

        return self._compiled_patterns

    def _check_yaml_available(self) -> bool:
        """Check if PyYAML is available."""
        if self._yaml_available is not None:
            return self._yaml_available

        try:
            import yaml  # noqa: F401
            self._yaml_available = True
        except ImportError:
            self._yaml_available = False

        return self._yaml_available

    def load_from_string(self, yaml_content: str) -> List[CustomPattern]:
        """Load patterns from a YAML string.

        Args:
            yaml_content: YAML content as a string

        Returns:
            List of loaded patterns
        """
        if not self._check_yaml_available():
            logger.warning("PyYAML not installed. Install with: pip install pyyaml")
            return []

        import yaml

        try:
            data = yaml.safe_load(yaml_content)
            patterns = self._parse_patterns(data)
            self._patterns.extend(patterns)
            return patterns

        except Exception as e:
            logger.error(f"Error parsing YAML content: {e}")
            return []

    @property
    def pattern_count(self) -> int:
        """Get the number of loaded patterns."""
        return len(self._patterns)

    def clear(self) -> None:
        """Clear all loaded patterns."""
        self._patterns.clear()
        self._compiled_patterns.clear()


def get_custom_pattern_loader(config: Optional[CustomPatternConfig] = None) -> CustomPatternLoader:
    """Get a configured custom pattern loader.

    Args:
        config: Optional configuration

    Returns:
        Configured CustomPatternLoader
    """
    return CustomPatternLoader(config=config)
