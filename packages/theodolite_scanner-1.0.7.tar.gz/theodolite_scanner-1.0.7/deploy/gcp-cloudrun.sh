#!/bin/bash
#
# Theodolite Scanner — GCP Cloud Run Job deployment
#
# Runs the scanner as a Cloud Run job in your GCP project.
# The job runs in the same region as your GCS buckets,
# so there are no egress fees. It stops when done.
#
# Usage:
#   chmod +x gcp-cloudrun.sh
#   ./gcp-cloudrun.sh
#
# Or paste the 'gcloud run jobs create' command below into GCP Cloud Shell.
#
# Prerequisites:
#   - gcloud CLI authenticated, or run from GCP Cloud Shell
#   - A GCP project with Cloud Run API enabled
#

set -e

echo "=== Theodolite Scanner — GCP Deployment ==="
echo ""

# Collect inputs
read -p "GCP Project ID: " PROJECT_ID
read -p "Region (e.g. us-central1, us-east1): " REGION
read -p "Theodolite API token: " -s API_TOKEN
echo ""
read -p "Scan type [full/quick] (default: full): " SCAN_TYPE
SCAN_TYPE=${SCAN_TYPE:-full}
read -p "Service account JSON file path (leave blank for default creds): " SA_FILE
read -p "Specific bucket to scan (leave blank to discover all): " BUCKET_NAME

echo ""
echo "Creating Cloud Run job..."

# Build the scan command
SCAN_CMD="pip install -q theodolite-scanner[gcp] && theodolite-scan -p gcp --project $PROJECT_ID --scan-type $SCAN_TYPE --upload https://api.theodolite.io --token \$API_TOKEN -o /tmp/findings.json"

if [ -n "$BUCKET_NAME" ]; then
    SCAN_CMD="$SCAN_CMD --bucket $BUCKET_NAME"
fi

gcloud run jobs create theodolite-scanner \
    --project "$PROJECT_ID" \
    --region "$REGION" \
    --image python:3.12-slim \
    --memory 2Gi \
    --cpu 1 \
    --max-retries 0 \
    --task-timeout 3600 \
    --set-env-vars "API_TOKEN=$API_TOKEN" \
    --command "/bin/bash" \
    --args "-c,$SCAN_CMD"

echo ""
echo "Running the job..."

gcloud run jobs execute theodolite-scanner \
    --project "$PROJECT_ID" \
    --region "$REGION" \
    --wait

echo ""
echo "Scan complete. Results uploaded to your Theodolite dashboard."
echo ""
echo "Clean up:"
echo "  gcloud run jobs delete theodolite-scanner --project $PROJECT_ID --region $REGION -q"
