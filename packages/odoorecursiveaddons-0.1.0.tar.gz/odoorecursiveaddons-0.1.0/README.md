# OdooRecursiveAddons

Expande `addons_path` recursivamente desde el archivo de configuracion de Odoo.

## Instalacion

```bash
pip install odoorecursiveaddons

### Use
    from odoorecursiveaddons import expand_addons_path_recursive_from_config

    paths = expand_addons_path_recursive_from_config()
    print(paths)  
```


## odoo.conf
[options]
addons_path_recursive = /ruta/a/mis/addons,/otra/ruta# OdooRecursiveAddons

Expande `addons_path` recursivamente desde el archivo de configuracion de Odoo.

## Instalacion

``` bash
pip install odoorecursiveaddons
```

Expands `addons_path` recursively from Odoo configuration file.

## Installation

The function searches for directories containing Odoo modules (`__manifest__.py` or `__openerp__.py`) recursively.


pypi-AgEIcHlwaS5vcmcCJGQ4MmRlNTNlLTQ5NzgtNGE1Ny1iMjFhLTA3M2M3ZjgwOTI0YQACKlszLCI5NjI1YWY4OC0wODk0LTRjMDItYWVkMS04N2E4ODFiM2ZlY2IiXQAABiDQ_uoSPjt7ZO9EOI8n0_mmSZPieG691f_R3K2DLnNMzg