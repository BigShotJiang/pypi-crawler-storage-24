"""Shared property service package."""
