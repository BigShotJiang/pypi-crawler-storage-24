"""Demo UI routes."""

