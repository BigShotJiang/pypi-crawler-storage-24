# System Architecture Analysis

## Overview

- **Project**: proxy
- **Language**: python
- **Files**: 127
- **Lines**: 39560
- **Functions**: 1298
- **Classes**: 112
- **Avg CC**: 3.7
- **Critical (CC≥10)**: 87

## Architecture

### docs/open-webui-tools/ (1 files, 90L, 9 functions)

- `proxym_tools.py` — 90L, 9 methods, CC↑1

### frontend/ (1 files, 6L, 0 functions)

- `proxym-dashboard.jsx` — 6L, 0 methods, CC↑0

### htmlcov/ (1 files, 735L, 65 functions)

- `coverage_html_cb_dd2e7eb5.js` — 735L, 65 methods, CC↑21

### root/ (1 files, 14L, 0 functions)

- `project.sh` — 14L, 0 methods, CC↑0

### scripts/ (7 files, 1202L, 17 functions)

- `seed_sprint8.py` — 229L, 1 methods, CC↑10
- `proxym-voice-chat.py` — 73L, 3 methods, CC↑5
- `evaluate_llm_work.sh` — 169L, 2 methods, CC↑0
- `jetson-entrypoint.sh` — 43L, 0 methods, CC↑0
- `proxym-voice-server.sh` — 64L, 0 methods, CC↑0
- _2 more files_

### services/vscode/ (1 files, 333L, 1 functions)

- `entrypoint.sh` — 333L, 1 methods, CC↑0

### src/proxym/ (5 files, 785L, 26 functions)

- `main.py` — 224L, 2 methods, CC↑11
- `ctl.py` — 277L, 15 methods, CC↑7
- `storage.py` — 130L, 6 methods, CC↑6
- `config.py` — 151L, 3 methods, CC↑3
- `__init__.py` — 3L, 0 methods, CC↑0

### src/proxym/accounts/ (1 files, 398L, 20 functions)

- `__init__.py` — 398L, 20 methods, CC↑15

### src/proxym/api/ (18 files, 2699L, 128 functions)

- `_diag_providers.py` — 60L, 1 methods, CC↑19
- `_diag_agent.py` — 221L, 3 methods, CC↑14
- `_diag_roo.py` — 81L, 1 methods, CC↑14
- `_diag_vscode.py` — 143L, 2 methods, CC↑14
- `completions.py` — 262L, 12 methods, CC↑13
- _13 more files_

### src/proxym/cache/ (1 files, 333L, 10 functions)

- `__init__.py` — 333L, 10 methods, CC↑9

### src/proxym/cli/ (16 files, 2096L, 99 functions)

- `smart_defaults.py` — 109L, 4 methods, CC↑13
- `tickets.py` — 311L, 13 methods, CC↑12
- `diagnostics.py` — 151L, 7 methods, CC↑11
- `_client.py` — 39L, 3 methods, CC↑9
- `chat.py` — 215L, 12 methods, CC↑9
- _11 more files_

### src/proxym/cli/_groups/ (12 files, 1415L, 114 functions)

- `do_ctl.py` — 182L, 8 methods, CC↑8
- `projects_ctl.py` — 205L, 8 methods, CC↑8
- `tickets_ctl.py` — 226L, 18 methods, CC↑7
- `tools_ctl.py` — 179L, 13 methods, CC↑6
- `accounts_ctl.py` — 86L, 8 methods, CC↑1
- _7 more files_

### src/proxym/context/ (5 files, 613L, 24 functions)

- `detector.py` — 208L, 9 methods, CC↑9
- `session.py` — 247L, 12 methods, CC↑7
- `tool_selector.py` — 101L, 2 methods, CC↑5
- `_context.py` — 33L, 1 methods, CC↑3
- `__init__.py` — 24L, 0 methods, CC↑0

### src/proxym/dashboard/ (11 files, 2116L, 114 functions)

- `_tools_api.py` — 517L, 20 methods, CC↑21
- `tickets.py` — 401L, 23 methods, CC↑17
- `panel.jsx` — 53L, 7 methods, CC↑14
- `_system.py` — 175L, 6 methods, CC↑13
- `_projects_api.py` — 197L, 9 methods, CC↑10
- _6 more files_

### src/proxym/dashboard/components/ (17 files, 4892L, 367 functions)

- `tasks.jsx` — 569L, 49 methods, CC↑51
- `tools.jsx` — 1074L, 68 methods, CC↑49
- `tickets.jsx` — 711L, 33 methods, CC↑35
- `logs.jsx` — 158L, 9 methods, CC↑34
- `vms.jsx` — 275L, 30 methods, CC↑32
- _12 more files_

### src/proxym/dashboard/components/diagnostics/ (5 files, 211L, 16 functions)

- `DiagConfig.jsx` — 59L, 4 methods, CC↑29
- `DiagExtensions.jsx` — 51L, 3 methods, CC↑20
- `DiagAgent.jsx` — 51L, 3 methods, CC↑11
- `DiagInfrastructure.jsx` — 28L, 2 methods, CC↑10
- `helpers.jsx` — 22L, 4 methods, CC↑4

### src/proxym/dashboard/hooks/ (1 files, 287L, 35 functions)

- `useDashboardData.js` — 287L, 35 methods, CC↑9

### src/proxym/dashboard/utils/ (1 files, 34L, 12 functions)

- `formatters.js` — 34L, 12 methods, CC↑7

### src/proxym/mcp/ (10 files, 1014L, 36 functions)

- `client.py` — 151L, 4 methods, CC↑6
- `router.py` — 95L, 4 methods, CC↑5
- `_tools_tickets.py` — 198L, 5 methods, CC↑4
- `_tools_vm.py` — 195L, 6 methods, CC↑4
- `registry.py` — 113L, 8 methods, CC↑4
- _5 more files_

### src/proxym/middleware/ (1 files, 70L, 4 functions)

- `__init__.py` — 70L, 4 methods, CC↑6

### src/proxym/observability/ (4 files, 953L, 37 functions)

- `repair_agent.py` — 341L, 9 methods, CC↑14
- `__init__.py` — 308L, 8 methods, CC↑9
- `watchdog.py` — 211L, 13 methods, CC↑7
- `health_events.py` — 93L, 7 methods, CC↑6

### src/proxym/projects/ (1 files, 299L, 14 functions)

- `__init__.py` — 299L, 14 methods, CC↑21

### src/proxym/providers/ (1 files, 331L, 4 functions)

- `__init__.py` — 331L, 4 methods, CC↑8

### src/proxym/router/ (2 files, 622L, 28 functions)

- `__init__.py` — 357L, 14 methods, CC↑9
- `strategy.py` — 265L, 14 methods, CC↑9

### src/proxym/tools/ (3 files, 1055L, 40 functions)

- `executor.py` — 268L, 14 methods, CC↑10
- `__init__.py` — 421L, 13 methods, CC↑7
- `adapters.py` — 366L, 13 methods, CC↑7

### src/proxym/virt/ (13 files, 1601L, 69 functions)

- `_config.py` — 94L, 1 methods, CC↑9
- `_vm_config.py` — 220L, 7 methods, CC↑9
- `browser_profiles.py` — 325L, 11 methods, CC↑9
- `_lifecycle.py` — 236L, 12 methods, CC↑7
- `_state.py` — 94L, 5 methods, CC↑7
- _8 more files_

### src/proxym/virt/profiles/ (1 files, 69L, 4 functions)

- `__init__.py` — 69L, 4 methods, CC↑5

### src/proxym/watch/ (2 files, 150L, 5 functions)

- `__init__.py` — 146L, 5 methods, CC↑5
- `client.py` — 4L, 0 methods, CC↑0

## Key Exports

- **TableExport** (function, CC=17) ⚠ split
- **TaskJobBadge** (function, CC=17) ⚠ split
- **TasksPanel** (function, CC=51) ⚠ split
- **TableExport** (function, CC=16) ⚠ split
- **JobRow** (function, CC=23) ⚠ split
- **JobDetailsPanel** (function, CC=39) ⚠ split
- **TicketDispatchTable** (function, CC=47) ⚠ split
- **ToolHealthPanel** (function, CC=18) ⚠ split
- **ToolsPanel** (function, CC=49) ⚠ split
- **TicketCard** (function, CC=16) ⚠ split
- **TicketHistoryItem** (function, CC=17) ⚠ split
- **TicketDetailPanel** (function, CC=35) ⚠ split
- **TicketsPanel** (function, CC=28) ⚠ split
- **LogPanel** (function, CC=34) ⚠ split
- **VMsPanel** (function, CC=32) ⚠ split
- **DiagRooConfig** (function, CC=29) ⚠ split
- **DiagnosticsPanel** (function, CC=26) ⚠ split
- **VoiceChat** (function, CC=24) ⚠ split
- **table** (function, CC=21) ⚠ split
- **table_body_rows** (function, CC=21) ⚠ split
- **no_rows** (function, CC=21) ⚠ split
- **footer** (function, CC=21) ⚠ split
- **ratio_columns** (function, CC=21) ⚠ split
- **filter_handler** (function, CC=21) ⚠ split
- **tools_healthcheck** (function, CC=21) ⚠ split
- **AddProjectForm** (function, CC=21) ⚠ split
- **ProjectRegistry** (class, CC̄=5.4)
  - `_enrich_local` CC=21 ⚠ split
- **DiagExtensions** (function, CC=20) ⚠ split
- **check_providers_config** (function, CC=19) ⚠ split
- **Sprint** (class, CC̄=7.0)
- **TicketManager** (class, CC̄=4.5)
  - `_apply_filters` CC=17 ⚠ split
  - `update_ticket` CC=16 ⚠ split
- **AccountCredentials** (class, CC̄=5.0)
- **AccountManager** (class, CC̄=4.4)
  - `_load` CC=15 ⚠ split
- **RepairAgent** (class, CC̄=5.4)
- **ProjectsConfig** (class, CC̄=9.0)
- **AiderAdapter** (class, CC̄=5.0)
- **ShellAdapter** (class, CC̄=5.0)
- **_StateMixin** (class, CC̄=5.0)
- **_SnapshotMixin** (class, CC̄=5.0)

## Hotspots (High Fan-Out)

- **useDashboardData** — fan-out=31: Orchestrates 31 calls
- **VoiceChat** — fan-out=31: Orchestrates 31 calls
- **run_all_tests** — fan-out=28: Run all diagnostic tests and return comprehensive status.
- **chat_completions** — fan-out=27: OpenAI-compatible chat completions with intelligent routing.

Extra headers:
  X
- **TicketsPanel** — fan-out=27: Orchestrates 27 calls
- **TicketDispatchTable** — fan-out=26: 26-way dispatch
- **create_ticket** — fan-out=23: Create a new ticket. Accepts 'task' (new) or 'title' (legacy).

## Refactoring Priorities

| # | Action | Impact | Effort |
|---|--------|--------|--------|
| 1 | Split DiagnosticsPanel (CC=26 → target CC<10) | high | low |
| 2 | Split LogPanel (CC=34 → target CC<10) | high | low |
| 3 | Split VMsPanel (CC=32 → target CC<10) | high | low |
| 4 | Split TasksPanel (CC=51 → target CC<10) | high | low |
| 5 | Split TicketDetailPanel (CC=35 → target CC<10) | high | low |
| 6 | Split TicketsPanel (CC=28 → target CC<10) | high | low |
| 7 | Split JobDetailsPanel (CC=39 → target CC<10) | high | low |
| 8 | Split TicketDispatchTable (CC=47 → target CC<10) | high | low |
| 9 | Split ToolsPanel (CC=49 → target CC<10) | high | low |
| 10 | Split DiagRooConfig (CC=29 → target CC<10) | high | low |

## Context for LLM

When suggesting changes:
1. Start from hotspots and high-CC functions
2. Follow refactoring priorities above
3. Maintain public API surface — keep backward compatibility
4. Prefer minimal, incremental changes

