"""Dashboard API: web panel + CLI endpoints for managing accounts, VMs, and costs.

Mounted at /dashboard/ on the main proxy app.
"""
from __future__ import annotations

from fastapi import APIRouter

from proxym.dashboard._accounts import router as accounts_router
from proxym.dashboard._accounts import list_accounts
from proxym.dashboard._costs import router as costs_router
from proxym.dashboard._costs import cost_summary
from proxym.dashboard._system import router as system_router
from proxym.dashboard._system import get_logs
from proxym.dashboard._projects_api import router as projects_router
from proxym.dashboard._tickets_api import router as tickets_router
from proxym.dashboard._tools_api import router as tools_router
from proxym.dashboard._vms import router as vms_router
from proxym.dashboard._vms import list_vms, start_vm, stop_vm, snapshot_vm

# Main dashboard router
router = APIRouter(prefix="/dashboard", tags=["dashboard"])

# Include all sub-routers
router.include_router(accounts_router)
router.include_router(vms_router)
router.include_router(costs_router)
router.include_router(projects_router)
router.include_router(tickets_router)
router.include_router(tools_router)
router.include_router(system_router)
