"""Frontend-serving endpoints: dashboard UI, JSX, JS, config — extracted from main.py."""

import os

import structlog
from fastapi import APIRouter, Request
from fastapi.responses import Response

from proxym.config import get_settings

logger = structlog.get_logger()

router = APIRouter()

_HERE = os.path.dirname(os.path.abspath(__file__))
_SRC_ROOT = os.path.dirname(_HERE)  # src/proxym/
_MIME_JS = "text/javascript"
_MIME_JS_UTF8 = "text/javascript; charset=utf-8"


def _serve_file(paths: list[str], media_type: str, charset_header: str | None = None) -> Response:
    """Try paths in order; return content from first found file."""
    for file_path in paths:
        try:
            with open(file_path, "r") as f:
                content = f.read()
            headers = {"Content-Type": charset_header} if charset_header else {}
            return Response(content=content, media_type=media_type, headers=headers)
        except FileNotFoundError:
            continue
        except Exception as e:
            logger.error("serve_file_error", error=str(e), path=file_path)
            continue
    logger.error("serve_file_not_found", paths=paths)
    return Response(content="// file not found", media_type=media_type, status_code=404)


def _serve_concat_files(paths: list[str], media_type: str, charset_header: str | None = None) -> Response:
    parts: list[str] = []
    missing: list[str] = []
    for file_path in paths:
        try:
            with open(file_path, "r") as f:
                parts.append(f.read())
        except FileNotFoundError:
            missing.append(file_path)
        except Exception as e:
            logger.error("serve_file_error", error=str(e), path=file_path)
            missing.append(file_path)

    if missing:
        logger.error("serve_concat_files_not_found", paths=missing)
        return Response(content="// file not found", media_type=media_type, status_code=404)

    content = "\n\n".join(parts) + "\n"
    headers = {"Content-Type": charset_header} if charset_header else {}
    return Response(content=content, media_type=media_type, headers=headers)


@router.get("/")
async def root_redirect():
    """Redirect root to dashboard."""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/dashboard-ui")


@router.get("/dashboard-ui")
async def dashboard_ui():
    """Serve the React dashboard UI."""
    paths = [
        "frontend/dashboard.html",
        "/app/frontend/dashboard.html",
    ]
    resp = _serve_file(paths, "text/html", "text/html; charset=utf-8")
    if resp.status_code == 404:
        return Response(
            content="<h1>Dashboard Error</h1><p>Could not load dashboard: HTML file not found</p>",
            status_code=500,
            media_type="text/html",
        )
    return resp


@router.get("/dashboard-hook.js")
async def dashboard_hook_js():
    """Serve the useDashboardData hook (plain JS, no Babel needed)."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "hooks", "useDashboardData.js")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-api.js")
async def dashboard_api_js():
    """Serve the dashboard API client (plain JS, no Babel needed)."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "api.js")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-formatters.js")
async def dashboard_formatters_js():
    """Serve formatters utility (plain JS, no Babel needed)."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "utils", "formatters.js")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-ui-components.jsx")
async def dashboard_ui_jsx():
    """Serve UI primitives: StatusBadge, CostBar, Card, StateBadge."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "ui.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-models.jsx")
async def dashboard_models_jsx():
    """Serve ModelsTable component."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "models.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-accounts.jsx")
async def dashboard_accounts_jsx():
    """Serve Accounts components."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "accounts.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-layout.jsx")
async def dashboard_layout_jsx():
    """Serve layout components: DashboardHeader, TabNav."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "layout.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-overview.jsx")
async def dashboard_overview_jsx():
    """Serve overview components: CostSummary, BudgetCards, SystemCard, ProvidersCard, OverviewTab."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "overview.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-vms.jsx")
async def dashboard_vms_jsx():
    """Serve VMs components with sort/selection hooks."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "vms.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-logs.jsx")
async def dashboard_logs_jsx():
    """Serve LogPanel with useLogFilter hook."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "logs.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-voice-schemas.jsx")
async def dashboard_voice_schemas_jsx():
    """Serve VoiceChat action/tool schemas."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "voice_schemas.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-voice-engine.jsx")
async def dashboard_voice_engine_jsx():
    """Serve VoiceChat engine helpers (apiCall, matchDSL, etc.)."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "voice_engine.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-voice.jsx")
async def dashboard_voice_jsx():
    """Serve VoiceChat component (Web Speech API STT/TTS + LLM chat)."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "voice.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-projects.jsx")
async def dashboard_projects_jsx():
    """Serve ProjectsPanel component (project management)."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "projects.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-tickets.jsx")
async def dashboard_tickets_jsx():
    """Serve TicketsPanel component (tickets & sprints management)."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "tickets.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-diag-helpers.jsx")
async def dashboard_diag_helpers_jsx():
    """Serve diagnostics shared helpers: _diagBadge, _diagWarnBadge, _diagRow."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "diagnostics", "helpers.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-diag-infrastructure.jsx")
async def dashboard_diag_infrastructure_jsx():
    """Serve DiagVSCode + DiagProxy cards."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "diagnostics", "DiagInfrastructure.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-diag-config.jsx")
async def dashboard_diag_config_jsx():
    """Serve DiagRooConfig + DiagProviders cards."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "diagnostics", "DiagConfig.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-diag-extensions.jsx")
async def dashboard_diag_extensions_jsx():
    """Serve DiagExtensions + DiagCopilot cards."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "diagnostics", "DiagExtensions.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-diag-agent.jsx")
async def dashboard_diag_agent_jsx():
    """Serve DiagAgentSetup + DiagAgentTest cards."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "diagnostics", "DiagAgent.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-tools.jsx")
async def dashboard_tools_jsx():
    """Serve ToolsPanel component (tool registry, dispatch, job queue)."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "tools.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-home.jsx")
async def dashboard_home_jsx():
    """Serve HomeTab: QuickDo, health/budget/queue cards, recent activity."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "home.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-tasks.jsx")
async def dashboard_tasks_jsx():
    """Serve TasksPanel: unified tickets + tools board with inline logs."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "tasks.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-system.jsx")
async def dashboard_system_jsx():
    """Serve SystemPanel: merged models + providers + diagnostics."""
    return _serve_file(
        [os.path.join(_SRC_ROOT, "dashboard", "components", "system.jsx")],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/dashboard-diagnostics.jsx")
async def dashboard_diagnostics_jsx():
    """Serve DiagnosticsPanel for testing VS Code, proxy, and agent."""
    base = os.path.join(_SRC_ROOT, "dashboard", "components")
    return _serve_concat_files(
        [
            os.path.join(base, "diagnostics", "helpers.jsx"),
            os.path.join(base, "diagnostics", "DiagInfrastructure.jsx"),
            os.path.join(base, "diagnostics", "DiagConfig.jsx"),
            os.path.join(base, "diagnostics", "DiagExtensions.jsx"),
            os.path.join(base, "diagnostics", "DiagAgent.jsx"),
            os.path.join(base, "diagnostics.jsx"),
        ],
        _MIME_JS,
        _MIME_JS_UTF8,
    )


@router.get("/proxym-dashboard.jsx")
async def dashboard_jsx():
    """Serve the React dashboard JSX entry point."""
    return _serve_file(
        [
            os.path.join(_SRC_ROOT, "dashboard", "panel.jsx"),
            "frontend/proxym-dashboard.jsx",
            "/app/frontend/proxym-dashboard.jsx",
        ],
        _MIME_JS, _MIME_JS_UTF8,
    )


@router.get("/config")
async def get_frontend_config(request: Request):
    """Return configuration for frontend."""
    settings = get_settings()
    
    # Use Host header to get the actual port
    host_header = request.headers.get("host", "localhost:4000")
    if ":" in host_header:
        host, port = host_header.split(":")
        scheme = request.url.scheme
    else:
        host = host_header
        port = settings.port
        scheme = "http"
    
    api_url = f"{scheme}://{host}:{port}"
    
    return {
        "api_url": api_url,
        "api_key": settings.master_key,
        "debug": settings.debug,
        "dashboard_api_url": settings.dashboard_api_url,
        "default_proxy_url": settings.default_proxy_url,
        "monthly_budget_usd": settings.monthly_budget_usd,
        "daily_budget_usd": settings.daily_budget_usd,
        "max_request_cost_usd": settings.max_request_cost_usd,
        "available_providers": list(settings.available_providers().keys()),
        "redis_url": settings.redis_url,
        "ollama_base_url": settings.ollama_base_url,
        "watch_dir": settings.watch_dir,
        "max_context_tokens": settings.max_context_tokens,
        "delta_threshold": settings.delta_threshold,
    }
