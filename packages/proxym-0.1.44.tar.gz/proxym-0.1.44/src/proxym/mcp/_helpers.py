"""Shared helpers for MCP tool modules — lazy imports to avoid circular deps."""
from __future__ import annotations


def _get_dashboard():
    """Lazy-import dashboard VM and account managers."""
    from proxym.dashboard._vms import _vms
    from proxym.dashboard._accounts import _accounts
    return _vms, _accounts


def _get_tickets():
    """Lazy-import ticket manager."""
    from proxym.dashboard._tickets_api import _tickets
    return _tickets()


def _get_orchestrator():
    """Lazy-import VM orchestrator."""
    from proxym.virt import VMOrchestrator
    return VMOrchestrator
