"""Click wrappers: vscode group — split from ctl.py."""
from __future__ import annotations

import click

from proxym.cli import vscode as vscode_cli


def _make_args(ctx: click.Context, **kwargs):
    from proxym.ctl import _make_args as _ma
    return _ma(ctx, **kwargs)


@click.group(name="vscode")
def vscode():
    """Manage VS Code Web service."""
    pass


@vscode.command(name="start")
@click.pass_context
def vscode_start(ctx: click.Context):
    """Start VS Code Web (docker compose up vscode)."""
    args = _make_args(ctx)
    vscode_cli.cmd_vscode_start(args)


@vscode.command(name="stop")
@click.pass_context
def vscode_stop(ctx: click.Context):
    """Stop VS Code Web."""
    args = _make_args(ctx)
    vscode_cli.cmd_vscode_stop(args)


@vscode.command(name="open")
@click.pass_context
def vscode_open(ctx: click.Context):
    """Open VS Code Web in browser."""
    args = _make_args(ctx)
    vscode_cli.cmd_vscode_open(args)


@vscode.command(name="logs")
@click.pass_context
def vscode_logs(ctx: click.Context):
    """Show VS Code Web logs."""
    args = _make_args(ctx)
    vscode_cli.cmd_vscode_logs(args)


@vscode.command(name="status")
@click.pass_context
def vscode_status_cmd(ctx: click.Context):
    """Show VS Code Web container status."""
    args = _make_args(ctx)
    vscode_cli.cmd_vscode_status(args)


@vscode.command(name="build")
@click.pass_context
def vscode_build(ctx: click.Context):
    """Rebuild VS Code Web image."""
    args = _make_args(ctx)
    vscode_cli.cmd_vscode_build(args)
