"""Click wrappers: browser group — split from ctl.py."""
from __future__ import annotations

import click

from proxym.cli import browser as browser_cli


def _make_args(ctx: click.Context, **kwargs):
    from proxym.ctl import _make_args as _ma
    return _ma(ctx, **kwargs)


@click.group(name="browser")
def browser():
    """Manage browser profiles."""
    pass


@browser.command(name="list")
@click.pass_context
def browser_list(ctx: click.Context):
    """List host browser profiles."""
    args = _make_args(ctx)
    browser_cli.cmd_browser_list(args)


@browser.command(name="assign")
@click.argument("profile")
@click.option("--account", required=True, help="Account ID")
@click.pass_context
def browser_assign(ctx: click.Context, profile: str, account: str):
    """Assign profile to account."""
    args = _make_args(ctx, profile=profile, account=account)
    browser_cli.cmd_browser_assign(args)


@browser.command(name="sync")
@click.argument("vm_id")
@click.pass_context
def browser_sync(ctx: click.Context, vm_id: str):
    """Sync browser profile host <-> VM."""
    args = _make_args(ctx, vm_id=vm_id)
    browser_cli.cmd_browser_sync(args)


@browser.command(name="snapshot")
@click.argument("vm_id")
@click.pass_context
def browser_snapshot(ctx: click.Context, vm_id: str):
    """Save browser state from VM."""
    args = _make_args(ctx, vm_id=vm_id)
    browser_cli.cmd_browser_snapshot(args)
