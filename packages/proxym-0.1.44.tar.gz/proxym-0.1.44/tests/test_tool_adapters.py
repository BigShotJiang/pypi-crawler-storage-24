"""Tests for tool adapters — build_args and get_adapter."""

import pytest
from unittest.mock import patch, MagicMock

from proxym.tools import ToolDefinition, ToolCategory, ToolCapability, ToolRegistry
from proxym.tools.adapters import (
    AiderAdapter,
    ClaudeCodeAdapter,
    BaseAdapter,
    ToolResult,
    get_adapter,
    register_adapter,
    _ADAPTER_MAP,
)


@pytest.fixture(autouse=True)
def reset_registry():
    ToolRegistry._instance = None
    yield
    ToolRegistry._instance = None


# ── ToolResult ────────────────────────────────────────────

class TestToolResult:
    def test_success_on_zero_exit(self):
        r = ToolResult(tool="aider", ticket_id="T-1", exit_code=0)
        assert r.success is True

    def test_failure_on_nonzero_exit(self):
        r = ToolResult(tool="aider", ticket_id="T-1", exit_code=1, stderr="err")
        assert r.success is False

    def test_summary_keys(self):
        r = ToolResult(tool="x", ticket_id="T-1", exit_code=0, stdout="ok", duration_s=1.5)
        s = r.summary()
        assert s["tool"] == "x"
        assert s["success"] is True
        assert s["duration_s"] == 1.5
        assert s["stdout_lines"] == 1


# ── AiderAdapter ──────────────────────────────────────────

class TestAiderAdapter:
    def _make(self):
        tool = ToolRegistry.get().get_tool("aider")
        return AiderAdapter(tool)

    def test_basic_args(self):
        a = self._make()
        args = a.build_args("fix the bug", "/tmp/proj")
        assert args[0] == "aider"
        assert "--yes-always" in args
        assert "--no-auto-commits" in args
        assert "--message" in args
        assert "fix the bug" in args

    def test_architect_mode(self):
        a = self._make()
        args = a.build_args("design API", "/tmp", mode="architect")
        assert "--architect" in args

    def test_model_override(self):
        a = self._make()
        args = a.build_args("x", "/tmp", model="claude-sonnet-4-20250514")
        assert "--model" in args
        idx = args.index("--model")
        assert args[idx + 1] == "claude-sonnet-4-20250514"

    def test_files_passed(self):
        a = self._make()
        args = a.build_args("fix", "/tmp", files=["src/main.py", "src/util.py"])
        assert "src/main.py" in args
        assert "src/util.py" in args


# ── ClaudeCodeAdapter ─────────────────────────────────────

class TestClaudeCodeAdapter:
    def _make(self):
        tool = ToolRegistry.get().get_tool("claude-code")
        return ClaudeCodeAdapter(tool)

    def test_basic_args(self):
        a = self._make()
        args = a.build_args("implement feature", "/tmp/proj")
        assert args[0] == "claude"
        assert "--print" in args
        assert "--dangerously-skip-permissions" in args
        assert "implement feature" in args

    def test_model_override(self):
        a = self._make()
        args = a.build_args("x", "/tmp", model="opus")
        assert "--model" in args
        idx = args.index("--model")
        assert args[idx + 1] == "opus"


# ── get_adapter / register_adapter ────────────────────────

class TestGetAdapter:
    def test_returns_aider_adapter(self):
        adapter = get_adapter("aider")
        assert adapter is not None
        assert isinstance(adapter, AiderAdapter)

    def test_returns_claude_adapter(self):
        adapter = get_adapter("claude-code")
        assert adapter is not None
        assert isinstance(adapter, ClaudeCodeAdapter)

    def test_returns_none_for_unknown(self):
        assert get_adapter("nonexistent-tool-xyz") is None

    def test_returns_none_for_tool_without_adapter(self):
        # browser has no adapter
        assert get_adapter("browser") is None

    def test_register_custom_adapter(self):
        class MyAdapter(BaseAdapter):
            def build_args(self, prompt, project_dir, mode="", model="", files=None):
                return ["echo", prompt]

        tool = ToolDefinition(name="my-custom", category=ToolCategory.CUSTOM, binary="echo")
        ToolRegistry.get().register(tool)
        register_adapter("my-custom", MyAdapter)

        adapter = get_adapter("my-custom")
        assert adapter is not None
        assert isinstance(adapter, MyAdapter)
        assert adapter.build_args("hello", "/tmp") == ["echo", "hello"]

        # Cleanup
        ToolRegistry.get().unregister("my-custom")
        _ADAPTER_MAP.pop("my-custom", None)


# ── BaseAdapter.run — binary not found ────────────────────

class TestBaseAdapterRun:
    @pytest.mark.asyncio
    async def test_run_binary_not_found(self):
        tool = ToolDefinition(
            name="missing", category=ToolCategory.AGENT_CLI,
            binary="nonexistent-binary-xyz-12345",
        )
        adapter = AiderAdapter(tool)
        result = await adapter.run("test", "/tmp", ticket_id="T-1")
        assert result.exit_code == 127
        assert "not found" in result.stderr
