import polars as pl

lf = pl.scan_parquet("diag.parquet")
lf_death = pl.scan_parquet("death.parquet")

lf_death = lf_death.rename(
    {"PNR": "case:concept:name", "DODDATO": "start_timestamp"}
).with_columns(
    pl.lit("DØD").alias("concept:name"),
    pl.col("start_timestamp").cast(pl.Datetime("us")),
)

# 1. Deduplication & Sorting
lf = (
    pl.concat([lf, lf_death], how="diagonal")
    .sort("start_timestamp")  # Ensures keep='first' grabs the earliest
    .unique(subset=["case:concept:name", "concept:name"], keep="first")
    .sort(
        ["case:concept:name", "start_timestamp"]
    )  # Groups data physically for cache-friendly window functions
)

# 2. Combined Window Functions (No Temp Columns)

lf = lf.with_columns(
    pl.col("start_timestamp")
    .diff()
    .over("case:concept:name")
    .filter(pl.col("concept:name") != "DØD")
    .mean()
    .over("case:concept:name")
    .alias("case:avg_inter_diagnosis_time"),
    pl.when(
        (pl.col("concept:name") == "DØD") & (pl.len().over("case:concept:name") > 1)
    )
    .then(
        pl.col("start_timestamp")
        - pl.col("start_timestamp").shift(1).over("case:concept:name")
    )
    .otherwise(None)
    .alias("case:time_to_death_from_last_diag"),
)

# 3. Aggregation without maintain_order
lf_variants = lf.group_by("case:concept:name").agg(
    pl.col("concept:name").sort_by("start_timestamp").str.join(">").alias("variants"),
    pl.col("case:avg_inter_diagnosis_time").first(),
    pl.col(
        "case:time_to_death_from_last_diag"
    ).last(),  # .last() is safer here since DØD is the last event
)

# 4. Inline KPI Calculation
lf_variants = lf_variants.with_columns(
    pl.col("variants")
    .str.contains("DØD")
    .mean()  # Boolean mean implicitly calculates the ratio
    .over(
        pl.col("variants").str.replace(r">DØD$", "")
    )  # Group by the expression directly
    .alias("mortality_kpi")
)

# 5. Summary
lf_summary = lf_variants.group_by("variants").agg(
    pl.col("mortality_kpi").first().alias("mortality_kpi"),
    pl.len().alias("count"),
    pl.col("case:avg_inter_diagnosis_time").mean().alias("avg_inter_diagnosis_time"),
    pl.col("case:time_to_death_from_last_diag")
    .mean()
    .alias("avg_inter_diagnosis_time_to_death"),
)

# 6. Broadcast
patient_kpi_map = lf_variants.select(
    "case:concept:name", pl.col("mortality_kpi").alias("case:mortality_kpi")
)
lf = lf.join(patient_kpi_map, on="case:concept:name", how="left")
