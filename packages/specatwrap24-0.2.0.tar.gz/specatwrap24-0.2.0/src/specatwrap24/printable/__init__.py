"""
CLI command to print Python files from the printable folder.

This allows easy copying of scripts on the remote protected machine.
"""

from pathlib import Path

import click


@click.command("print")
@click.argument("filename", required=False)
@click.option("--list", "-l", is_flag=True, help="List all available printable files")
def print_file(filename: str | None, list: bool) -> None:
    """
    Print Python files from the printable folder to stdout.

    This command helps transfer code to the restricted environment by printing
    file contents that can be easily copied.

    Usage:

        specatwrap print diagnosis_kpi > diagnosis_kpi.py

        specatwrap print --list

    \b
    Arguments:
        FILENAME: Name of the file to print (without .py extension)
    """
    printable_dir = Path(__file__).parent

    # List available files
    if list:
        python_files = sorted(printable_dir.glob("*.py"))
        python_files = [f for f in python_files if f.name != "__init__.py"]

        if not python_files:
            click.echo("No printable files available.")
            return

        click.echo("Available printable files:")
        for file in python_files:
            click.echo(f"  - {file.stem}")
        return

    # Print specific file
    if not filename:
        click.echo(
            "Error: Please provide a filename or use --list to see available files."
        )
        click.echo("Usage: specatwrap print <filename>")
        click.echo("       specatwrap print --list")
        raise click.Abort()

    # Add .py extension if not present
    if not filename.endswith(".py"):
        filename = f"{filename}.py"

    file_path = printable_dir / filename

    if not file_path.exists():
        click.echo(f"Error: File '{filename}' not found in printable folder.")
        click.echo("\nUse 'specatwrap print --list' to see available files.")
        raise click.Abort()

    # Read and print the file
    try:
        content = file_path.read_text()
        click.echo(content)
    except Exception as e:
        click.echo(f"Error reading file: {e}")
        raise click.Abort()
