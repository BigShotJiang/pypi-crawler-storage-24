#!/usr/bin/env python3
"""Custom exceptions and error taxonomy helpers for the AIP SDK.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ErrorDescriptor:
    """Canonical metadata for a surfaced SDK failure."""

    category: str
    error_code: str
    retryable: bool


_UNKNOWN_ERROR_DESCRIPTOR = ErrorDescriptor(
    category="unknown",
    error_code="SDK_UNKNOWN_ERROR",
    retryable=False,
)
_NETWORK_ERROR_DESCRIPTOR = ErrorDescriptor(
    category="network",
    error_code="SDK_NETWORK_UNREACHABLE",
    retryable=True,
)
_TIMEOUT_ERROR_DESCRIPTOR = ErrorDescriptor(
    category="timeout",
    error_code="SDK_TIMEOUT",
    retryable=True,
)
_RATE_LIMIT_ERROR_DESCRIPTOR = ErrorDescriptor(
    category="rate_limit",
    error_code="SDK_RATE_LIMITED",
    retryable=True,
)
_AUTH_ERROR_DESCRIPTOR = ErrorDescriptor(
    category="auth",
    error_code="SDK_AUTH_FAILED",
    retryable=False,
)
_PERMISSION_ERROR_DESCRIPTOR = ErrorDescriptor(
    category="permission",
    error_code="SDK_PERMISSION_DENIED",
    retryable=False,
)
_VALIDATION_ERROR_DESCRIPTOR = ErrorDescriptor(
    category="validation",
    error_code="SDK_INVALID_REQUEST",
    retryable=False,
)
_CONFLICT_ERROR_DESCRIPTOR = ErrorDescriptor(
    category="conflict",
    error_code="SDK_RESOURCE_CONFLICT",
    retryable=False,
)
_SERVER_ERROR_DESCRIPTOR = ErrorDescriptor(
    category="server",
    error_code="SDK_SERVER_ERROR",
    retryable=True,
)


def _coerce_retryable_from_payload(payload: Any) -> bool | None:
    """Read an explicit retryable hint from structured payloads when present."""
    if isinstance(payload, Mapping):
        retryable = payload.get("retryable")
        if isinstance(retryable, bool):
            return retryable
    return None


def get_error_descriptor_for_status(status_code: int | None) -> ErrorDescriptor:
    """Return canonical error metadata for an HTTP status code."""
    if status_code is None:
        return _UNKNOWN_ERROR_DESCRIPTOR

    mapping = {
        400: _VALIDATION_ERROR_DESCRIPTOR,
        401: _AUTH_ERROR_DESCRIPTOR,
        403: _PERMISSION_ERROR_DESCRIPTOR,
        408: _TIMEOUT_ERROR_DESCRIPTOR,
        409: _CONFLICT_ERROR_DESCRIPTOR,
        422: _VALIDATION_ERROR_DESCRIPTOR,
        429: _RATE_LIMIT_ERROR_DESCRIPTOR,
        500: _SERVER_ERROR_DESCRIPTOR,
        502: _SERVER_ERROR_DESCRIPTOR,
        503: _SERVER_ERROR_DESCRIPTOR,
        504: _TIMEOUT_ERROR_DESCRIPTOR,
    }
    return mapping.get(status_code, _UNKNOWN_ERROR_DESCRIPTOR)


def extract_request_id(headers: Mapping[str, Any] | None) -> str | None:
    """Extract a request correlation identifier from headers when available."""
    if headers is None:
        return None

    for header_name in ("x-request-id", "X-Request-Id"):
        value = headers.get(header_name)
        if isinstance(value, str):
            cleaned = value.strip()
            if cleaned:
                return cleaned
    return None


class AIPError(Exception):
    """Base exception for AIP SDK."""

    pass


class APIError(AIPError):
    """Base API exception with canonical taxonomy and rich context."""

    default_error_descriptor = _UNKNOWN_ERROR_DESCRIPTOR

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        error_type: str | None = None,
        payload: Any = None,
        request_id: str | None = None,
        error_code: str | None = None,
        category: str | None = None,
        retryable: bool | None = None,
    ):
        """Initialize the API error.

        Args:
            message: The error message.
            status_code: HTTP status code.
            error_type: Type of error.
            payload: Additional error payload.
            request_id: Request identifier.
            error_code: Canonical SDK error code.
            category: Canonical SDK error category.
            retryable: Whether callers may retry safely.
        """
        super().__init__(message)
        descriptor = self._resolve_descriptor(status_code)
        payload_retryable = _coerce_retryable_from_payload(payload)

        self.status_code = status_code
        self.error_type = error_type
        self.payload = payload
        self.request_id = request_id
        self.category = category or descriptor.category
        self.error_code = error_code or descriptor.error_code
        if retryable is not None:
            self.retryable = retryable
        elif payload_retryable is not None:
            self.retryable = payload_retryable
        else:
            self.retryable = descriptor.retryable

    @classmethod
    def _resolve_descriptor(cls, status_code: int | None) -> ErrorDescriptor:
        """Resolve default metadata from status code or subclass defaults."""
        if status_code is not None:
            return get_error_descriptor_for_status(status_code)
        return cls.default_error_descriptor


class NetworkError(APIError):
    """Network connectivity failed before receiving an HTTP response."""

    default_error_descriptor = _NETWORK_ERROR_DESCRIPTOR


class AuthenticationError(APIError):
    """Authentication failed."""

    default_error_descriptor = _AUTH_ERROR_DESCRIPTOR


class ValidationError(APIError):
    """Validation failed."""

    default_error_descriptor = _VALIDATION_ERROR_DESCRIPTOR


class ForbiddenError(APIError):
    """Access forbidden."""

    default_error_descriptor = _PERMISSION_ERROR_DESCRIPTOR


class NotFoundError(APIError):
    """Resource not found."""

    default_error_descriptor = _UNKNOWN_ERROR_DESCRIPTOR


class ConflictError(APIError):
    """Resource conflict."""

    default_error_descriptor = _CONFLICT_ERROR_DESCRIPTOR


class AmbiguousResourceError(APIError):
    """Multiple resources match the query."""

    default_error_descriptor = _CONFLICT_ERROR_DESCRIPTOR


class ServerError(APIError):
    """Server error."""

    default_error_descriptor = _SERVER_ERROR_DESCRIPTOR


class RateLimitError(APIError):
    """Rate limit exceeded."""

    default_error_descriptor = _RATE_LIMIT_ERROR_DESCRIPTOR


class TimeoutError(APIError):
    """Request timeout."""

    default_error_descriptor = _TIMEOUT_ERROR_DESCRIPTOR


class AgentTimeoutError(TimeoutError):
    """Agent execution timeout with specific duration information."""

    def __init__(self, timeout_seconds: float, agent_name: str | None = None):
        """Initialize the agent timeout error.

        Args:
            timeout_seconds: The timeout duration in seconds.
            agent_name: Optional name of the agent that timed out.
        """
        agent_info = f" for agent '{agent_name}'" if agent_name else ""
        message = f"Agent execution timed out after {timeout_seconds} seconds{agent_info}"
        super().__init__(message)
        self.timeout_seconds = timeout_seconds
        self.agent_name = agent_name


def get_exception_class_for_status(status_code: int | None) -> type[APIError]:
    """Return the compatibility exception class for an HTTP status code."""
    mapping = {
        400: ValidationError,
        401: AuthenticationError,
        403: ForbiddenError,
        404: NotFoundError,
        408: TimeoutError,
        409: ConflictError,
        422: ValidationError,
        429: RateLimitError,
        500: ServerError,
        502: ServerError,
        503: ServerError,
        504: TimeoutError,
    }
    return mapping.get(status_code, ValidationError)
