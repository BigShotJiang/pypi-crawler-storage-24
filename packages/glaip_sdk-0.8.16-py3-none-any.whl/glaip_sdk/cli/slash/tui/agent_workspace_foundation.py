"""Reusable design primitives for `/agents` workspace surfaces.

This module centralizes shared style primitives used by the gated workspace
shell and future `/agents` TUI pages. Keeping these helpers outside the app
class avoids copy/paste drift across roadmap PRs.
"""

from __future__ import annotations

import os
from collections.abc import Sequence
from datetime import UTC, datetime

from glaip_sdk.branding import INFO, PRIMARY, SECONDARY_DARK, SECONDARY_LIGHT, SUCCESS, WARNING, AIPBranding

# Local design tokens for workspace surfaces
# These complement the global branding palette with surface-specific depths
SCREEN = "#060a10"
PANEL = "#101923"
PANEL_ALT = "#0d141d"
TEXT = "#d9e4f2"
MUTED = "#8fa4ba"
WORKSPACE_BLUE = "#a5b5c9"


def get_workspace_logo_text() -> str:
    """Get the workspace logo text, checking env var at call time."""
    if os.environ.get("AIP_ROBOT_LOGO") == "1":
        logo_lines = AIPBranding.AIP_ROBOT_LOGO.splitlines()
        return "\n".join(logo_lines[:6])
    # Default original logo
    logo_lines = [
        " ██████╗ ██╗         █████╗ ██╗██████╗",
        "██╔════╝ ██║        ██╔══██╗██║██╔══██╗",
        "██║  ███╗██║        ███████║██║██████╔╝",
        "██║   ██║██║        ██╔══██║██║██╔═══╝",
        "╚██████╔╝███████╗   ██║  ██║██║██║",
        " ╚═════╝ ╚══════╝   ╚═╝  ╚═╝╚═╝╚═╝",
    ]
    return "\n".join(logo_lines)


def _workspace_logo_text() -> str:
    """Legacy function - now delegates to get_workspace_logo_text()."""
    return get_workspace_logo_text()


AGENT_WORKSPACE_THEME = {
    "screen": SCREEN,
    "panel": PANEL,
    "panel_alt": PANEL_ALT,
    "border": SECONDARY_DARK,
    "text": TEXT,
    "muted": MUTED,
    "accent": SECONDARY_LIGHT,
    "heading": WARNING,
    "success": SUCCESS,
    "info": INFO,
    "tools": SECONDARY_LIGHT,
    "mcps": SECONDARY_LIGHT,
    "workspace": WORKSPACE_BLUE,
    "brand": PRIMARY,
    "account": SUCCESS,
}


AGENT_WORKSPACE_LOGO_TEXT = _workspace_logo_text()

MODEL_LABEL_PLACEHOLDER = "Resolution pending"


def workspace_label(*, cwd: str | None = None, home: str | None = None) -> str:
    """Return workspace label with home collapsed to `~` when possible."""
    cwd_value = cwd if cwd is not None else os.getcwd()
    home_value = home if home is not None else os.path.expanduser("~")
    if cwd_value.startswith(home_value):
        return "~" + cwd_value[len(home_value) :]
    return os.path.basename(cwd_value) or cwd_value


def format_summary_rows(
    rows: Sequence[tuple[str, str]],
    *,
    key_color: str,
    value_color: str | None = None,
    muted_color: str | None = None,
) -> str:
    """Format summary key/value rows using shared key-color styling."""
    if value_color is None and muted_color is not None:
        value_color = muted_color
    if value_color:
        return "\n".join(f"[{key_color}]{key}:[/] [{value_color}]{value}[/]" for key, value in rows)
    return "\n".join(f"[{key_color}]{key}:[/] {value}" for key, value in rows)


def format_utc_timestamp(raw: str) -> str:
    """Normalize an ISO-like timestamp into `YYYY-MM-DD HH:MM:SS UTC`."""
    value = (raw or "").strip()
    if not value:
        return "-"

    normalized = value.replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(normalized)
    except ValueError:
        return value

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    else:
        dt = dt.astimezone(UTC)
    return dt.strftime("%Y-%m-%d %H:%M:%S UTC")
