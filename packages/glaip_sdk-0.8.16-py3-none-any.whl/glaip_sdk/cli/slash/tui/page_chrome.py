"""Page chrome contract for unified placeholders, tips, and footer actions across TUI screens.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from secrets import SystemRandom
from typing import Literal

PageMode = Literal["home", "agent", "runs", "accounts", "schedules"]

_TIP_RANDOM = SystemRandom()

DEFAULT_TIP_ROTATE_SECONDS = 8.0


@dataclass(frozen=True)
class FooterAction:
    """A single footer action binding for TUI pages."""

    key: str
    label: str
    action_name: str


class FooterActionRegistry:
    """Registry of common footer actions available across TUI pages."""

    CLOSE = FooterAction(key="ctrl+c", label="Close", action_name="app.quit")
    BACK = FooterAction(key="esc", label="Close", action_name="escape")
    DETAILS = FooterAction(key="ctrl+b", label="Details", action_name="toggle_sidebar")
    COMMAND_PALETTE = FooterAction(key="ctrl+p", label="Commands", action_name="show_palette")

    _REGISTRY: dict[str, FooterAction] = {
        "close": CLOSE,
        "back": BACK,
        "details": DETAILS,
        "command_palette": COMMAND_PALETTE,
    }

    @classmethod
    def get(cls, key: str) -> FooterAction | None:
        """Get a footer action by its key."""
        return cls._REGISTRY.get(key.lower())

    @classmethod
    def all(cls) -> list[FooterAction]:
        """Get all registered footer actions."""
        return list(cls._REGISTRY.values())


@dataclass
class PageChrome:
    """Unified chrome configuration for a TUI page."""

    mode: PageMode
    placeholder: str
    tips: tuple[str, ...] = field(default_factory=tuple)
    visible_actions: tuple[FooterAction, ...] = field(default_factory=tuple)
    tip_rotate_seconds: float = DEFAULT_TIP_ROTATE_SECONDS

    def get_random_tip(self) -> str:
        """Return a random tip from the tips list."""
        if not self.tips:
            return ""
        return _TIP_RANDOM.choice(self.tips)

    def get_initial_tip_index(self) -> int:
        """Return a random initial tip index for rotation."""
        if not self.tips:
            return 0
        return _TIP_RANDOM.randint(0, len(self.tips) - 1)


WORKSPACE_TIP_TEXT = "Tip: Type / to browse commands. Ctrl+B toggles agent details."
HOME_TIP_TEXT = "Tip: Type / to browse commands. Use /agents to jump into an agent workspace."

WORKSPACE_TIP_TEXTS: tuple[str, ...] = (
    WORKSPACE_TIP_TEXT,
    "Tip: Press Ctrl+P to open the Commands menu for shortcuts, slash commands, and page-specific actions.",
    "Tip: Press Esc once to arm back/exit. Press Esc or Enter again to confirm leaving the workspace.",
    "Tip: Use /runs to inspect recent agent activity without leaving the workspace.",
    "Tip: Use /models to change the active model without leaving the agent workspace.",
    "Tip: Use /prompt to edit the active agent instruction without leaving the workspace.",
    "Tip: Use /tools or /mcps, then review Current vs Pending before you apply.",
    "Tip: Space toggles rows in /tools and /mcps. Apply or Enter opens confirmation before saving.",
    "Tip: Use /status for quick diagnostics and /details when you want the full current agent snapshot.",
    "Tip: Use /schedules to review or manage recurring agent runs from the same workspace.",
)

HOME_TIP_TEXTS: tuple[str, ...] = (
    HOME_TIP_TEXT,
    "Tip: Type / to browse available commands.",
    "Tip: Use /accounts to manage your connected accounts.",
    "Tip: Use /status to check connection diagnostics.",
)

HOME_PLACEHOLDER = "Type / for commands. Press Ctrl+C to exit."

AGENT_PLACEHOLDER = "Type a message to run an agent. / for commands, Ctrl+B for details."


HOME_CHROME = PageChrome(
    mode="home",
    placeholder=HOME_PLACEHOLDER,
    tips=HOME_TIP_TEXTS,
    visible_actions=(FooterActionRegistry.COMMAND_PALETTE,),
    tip_rotate_seconds=DEFAULT_TIP_ROTATE_SECONDS,
)


AGENT_CHROME = PageChrome(
    mode="agent",
    placeholder=AGENT_PLACEHOLDER,
    tips=WORKSPACE_TIP_TEXTS,
    visible_actions=(
        FooterActionRegistry.DETAILS,
        FooterActionRegistry.COMMAND_PALETTE,
    ),
    tip_rotate_seconds=DEFAULT_TIP_ROTATE_SECONDS,
)


def get_page_chrome(mode: PageMode) -> PageChrome:
    """Get the PageChrome for a given mode."""
    if mode == "home":
        return HOME_CHROME
    if mode == "agent":
        return AGENT_CHROME
    if mode == "runs":
        return PageChrome(
            mode="runs",
            placeholder="Type to filter runs. / for commands.",
            tips=(
                "Tip: Use arrow keys to navigate runs.",
                "Tip: Press Enter to view run details.",
            ),
            visible_actions=(
                FooterActionRegistry.BACK,
                FooterActionRegistry.COMMAND_PALETTE,
            ),
        )
    if mode == "accounts":
        return PageChrome(
            mode="accounts",
            placeholder="Type to filter accounts. / for commands.",
            tips=(
                "Tip: Use arrow keys to navigate accounts.",
                "Tip: Press Enter to select an account.",
            ),
            visible_actions=(
                FooterActionRegistry.BACK,
                FooterActionRegistry.COMMAND_PALETTE,
            ),
        )
    if mode == "schedules":
        return PageChrome(
            mode="schedules",
            placeholder="Type to filter schedules. / for commands.",
            tips=(
                "Tip: Use arrow keys to navigate schedules.",
                "Tip: Press Enter to view schedule details.",
            ),
            visible_actions=(
                FooterActionRegistry.BACK,
                FooterActionRegistry.COMMAND_PALETTE,
            ),
        )
    return HOME_CHROME
