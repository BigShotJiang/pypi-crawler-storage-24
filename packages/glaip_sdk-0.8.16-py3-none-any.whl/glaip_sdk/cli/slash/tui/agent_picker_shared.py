# pyright: reportGeneralTypeIssues=false
"""Shared picker helpers for `/agents` workspace overlays."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, ClassVar, cast

try:  # pragma: no cover - optional dependency guard
    from textual.binding import Binding
    from textual.containers import Horizontal, Vertical
    from textual.screen import ModalScreen as _TextualModalScreen
    from textual.widgets import Button, DataTable, Input, Static
except Exception:  # pragma: no cover - optional dependency fallback
    Binding = None  # type: ignore[assignment]
    Horizontal = None  # type: ignore[assignment]
    Vertical = None  # type: ignore[assignment]
    _TextualModalScreen = None  # type: ignore[assignment]
    Button = None  # type: ignore[assignment]
    DataTable = None  # type: ignore[assignment]
    Input = None  # type: ignore[assignment]
    Static = None  # type: ignore[assignment]


TEXTUAL_SUPPORTED = all(item is not None for item in (_TextualModalScreen, Button, DataTable, Input, Static))

_ScreenBase = cast(Any, _TextualModalScreen) if _TextualModalScreen is not None else cast(Any, object)
InputType = cast(Any, Input)
DataTableType = cast(Any, DataTable)
StaticType = cast(Any, Static)
ButtonType = cast(Any, Button)
HorizontalType = cast(Any, Horizontal)
VerticalType = cast(Any, Vertical)

CHECKMARK = "✓"


@dataclass(frozen=True)
class PickerOption:
    """One selectable picker option."""

    id: str
    label: str
    detail: str = ""
    search_text: str = ""


@dataclass(frozen=True)
class PickerLayoutConfig:
    """Static layout configuration shared across picker screens."""

    prefix: str
    card_width: int
    card_height: int
    columns: tuple[str, ...]
    apply_label: str = "Apply"


def build_picker_css(screen_name: str, layout: PickerLayoutConfig) -> str:
    """Return the shared modal CSS with picker-specific ids and sizing."""
    prefix = layout.prefix
    return f"""
    {screen_name} {{
        align: center middle;
        background: rgba(6, 10, 16, 0.78);
    }}

    #{prefix}-card {{
        width: {layout.card_width};
        max-width: 96vw;
        height: {layout.card_height};
        border: round #40b4e5;
        background: #101923;
        padding: 1 2;
        layout: vertical;
    }}

    #{prefix}-title {{
        color: #f2b266;
        text-style: bold;
        margin-bottom: 1;
    }}

    #{prefix}-search {{
        margin-bottom: 1;
    }}

    #{prefix}-summary {{
        color: #d7e4f2;
        background: #142131;
        border: round #28455f;
        padding: 0 1;
        height: 3;
        margin-bottom: 1;
    }}

    #{prefix}-table {{
        height: 1fr;
        margin-bottom: 1;
    }}

    #{prefix}-status {{
        color: #8fa4ba;
        margin-bottom: 1;
    }}

    .{prefix}-actions {{
        height: auto;
        align-horizontal: right;
    }}
    """


def filter_picker_options(options: tuple[PickerOption, ...], query: str) -> list[PickerOption]:
    """Return options matching a case-insensitive query."""
    normalized = str(query or "").strip().lower()
    if not normalized:
        return list(options)
    return [option for option in options if normalized in _picker_search_blob(option)]


def summarize_picker_labels(labels: list[str], *, empty: str = "none", max_items: int = 4) -> str:
    """Summarize labels for compact picker status displays."""
    normalized = [str(label).strip() for label in labels if str(label).strip()]
    if not normalized:
        return empty
    preview = normalized[:max_items]
    suffix = "" if len(normalized) <= max_items else f", +{len(normalized) - max_items} more"
    return ", ".join(preview) + suffix


def _picker_search_blob(option: PickerOption) -> str:
    return " ".join(
        part.strip().lower()
        for part in (option.label, option.detail, option.search_text)
        if isinstance(part, str) and part.strip()
    )


if TEXTUAL_SUPPORTED:

    class PickerSearchInput(Input):
        """Search input that forwards navigation and cancel keys to the picker."""

        def on_key(self, event: Any) -> None:  # pragma: no cover - exercised in integration-style tests
            """Route escape and navigation keys to the active picker screen."""
            screen = getattr(self, "screen", None)
            if screen is None:
                return
            if event.key == "escape":
                action = getattr(screen, "action_cancel", None)
                if callable(action):
                    action()
                event.prevent_default()
                event.stop()
                return
            if event.key == "up":
                action = getattr(screen, "action_move_up", None)
                if callable(action):
                    action()
                event.prevent_default()
                event.stop()
                return
            if event.key == "down":
                action = getattr(screen, "action_move_down", None)
                if callable(action):
                    action()
                event.prevent_default()
                event.stop()
                return
            if event.key == "enter":
                action = getattr(screen, "action_apply", None)
                if callable(action):
                    action()
                event.prevent_default()
                event.stop()
                return
            base_on_key = getattr(Input, "on_key", None)
            if callable(base_on_key):
                base_on_key(self, event)

    class PickerDataTable(DataTable):
        """Data table that guarantees Escape closes the picker."""

        def on_key(self, event: Any) -> None:  # pragma: no cover - exercised in integration-style tests
            """Ensure Escape dismisses the picker even when the table has focus."""
            if event.key == "escape":
                screen = getattr(self, "screen", None)
                action = getattr(screen, "action_cancel", None)
                if callable(action):
                    action()
                event.prevent_default()
                event.stop()
                return
            base_on_key = getattr(DataTable, "on_key", None)
            if callable(base_on_key):
                base_on_key(self, event)


else:  # pragma: no cover - fallback for optional dependency absence
    PickerSearchInput = cast(Any, object)
    PickerDataTable = cast(Any, object)


PickerSearchInputType = cast(Any, PickerSearchInput)
PickerDataTableType = cast(Any, PickerDataTable)


class BaseAgentPickerScreen(_ScreenBase):  # type: ignore[misc]
    """Common layout and keyboard behavior shared by agent picker modals."""

    LAYOUT: ClassVar[PickerLayoutConfig]

    if Binding:
        BINDINGS = [
            Binding("escape", "cancel", "Cancel", priority=True),
            Binding("enter", "apply", "Apply", priority=True),
            Binding("up", "move_up", "Up", priority=True, show=False),
            Binding("down", "move_down", "Down", priority=True, show=False),
        ]
    else:  # pragma: no cover - optional dependency missing
        BINDINGS = []

    def __init__(self, *, title: str, search_placeholder: str) -> None:
        """Store the shared picker title and search placeholder."""
        super().__init__()
        self._title = title
        self._search_placeholder = search_placeholder

    def compose(self) -> Any:  # type: ignore[override]
        """Compose the shared picker search, summary, table, and actions."""
        if not TEXTUAL_SUPPORTED:
            return  # pragma: no cover  # type: ignore[return-value]
        with VerticalType(id=self._picker_id("card")):
            yield StaticType(self._title, id=self._picker_id("title"))
            yield PickerSearchInputType(placeholder=self._search_placeholder, id=self._picker_id("search"))
            yield StaticType("", id=self._picker_id("summary"))
            yield PickerDataTableType(id=self._picker_id("table"), cursor_type="row", zebra_stripes=True)
            yield StaticType("", id=self._picker_id("status"))
            with HorizontalType(classes=f"{self.LAYOUT.prefix}-actions"):
                yield ButtonType(self.LAYOUT.apply_label, variant="primary", id=self._picker_id("apply"))
                yield ButtonType("Cancel", id=self._picker_id("cancel"))

    def on_mount(self) -> None:
        """Initialize the shared table columns and focus the search field."""
        table = self.query_one(f"#{self._picker_id('table')}", DataTableType)
        table.add_columns(*self.LAYOUT.columns)
        table.cursor_type = "row"
        self._refresh_table()
        self.query_one(f"#{self._picker_id('search')}", InputType).focus()

    def _picker_id(self, suffix: str) -> str:
        """Build a stable widget id from the picker layout prefix."""
        return f"{self.LAYOUT.prefix}-{suffix}"

    def _selected_option_id(self) -> str | None:
        filtered_options = self._filtered_options
        if not filtered_options:
            return None
        table = self.query_one(f"#{self._picker_id('table')}", DataTableType)
        coord = getattr(table, "cursor_coordinate", None)
        if coord is None:
            cursor_row = 0
        elif hasattr(coord, "row"):
            try:
                cursor_row = int(getattr(coord, "row"))
            except (ValueError, TypeError):
                cursor_row = 0
        else:
            try:
                cursor_row = int(coord[0])
            except Exception:
                cursor_row = 0
        if cursor_row < 0 or cursor_row >= len(filtered_options):
            return None
        return filtered_options[cursor_row].id

    def _set_cursor_for_option(self, option_id: str | None) -> None:
        filtered_options = self._filtered_options
        if not filtered_options:
            return
        table = self.query_one(f"#{self._picker_id('table')}", DataTableType)
        target_index = 0
        if option_id:
            for index, option in enumerate(filtered_options):
                if option.id == option_id:
                    target_index = index
                    break
        try:
            table.move_cursor(row=target_index, column=0)
        except Exception:
            table.cursor_coordinate = (target_index, 0)

    def action_move_up(self) -> None:
        """Move the highlighted row upward."""
        self._move_cursor(-1)

    def action_move_down(self) -> None:
        """Move the highlighted row downward."""
        self._move_cursor(1)

    def _move_cursor(self, delta: int) -> None:
        filtered_options = self._filtered_options
        if not filtered_options:
            return
        table = self.query_one(f"#{self._picker_id('table')}", DataTableType)
        coord = getattr(table, "cursor_coordinate", None)
        if coord is None:
            cursor_row = 0
        elif hasattr(coord, "row"):
            try:
                cursor_row = int(getattr(coord, "row"))
            except (ValueError, TypeError):
                cursor_row = 0
        else:
            try:
                cursor_row = int(coord[0])
            except Exception:
                cursor_row = 0
        next_row = max(0, min(len(filtered_options) - 1, cursor_row + delta))
        try:
            table.move_cursor(row=next_row, column=0)
        except Exception:
            table.cursor_coordinate = (next_row, 0)
        self._refresh_summary()
        self._refresh_status()

    def action_cancel(self) -> None:
        """Dismiss the picker without applying changes."""
        self.dismiss(None)

    def on_input_changed(self, event: Any) -> None:
        """Re-filter rows whenever the picker search input changes."""
        if getattr(event.input, "id", "") != self._picker_id("search"):
            return
        self._refresh_table()

    def on_data_table_cursor_row_changed(self, event: Any) -> None:
        """Refresh summary and status when the highlighted row changes."""
        if getattr(event.data_table, "id", "") != self._picker_id("table"):
            return
        self._refresh_summary()
        self._refresh_status()

    def on_button_pressed(self, event: Any) -> None:
        """Route apply and cancel button presses to picker actions."""
        button_id = getattr(event.button, "id", "")
        if button_id == self._picker_id("apply"):
            self.action_apply()
            return
        if button_id == self._picker_id("cancel"):
            self.action_cancel()


__all__ = [
    "BaseAgentPickerScreen",
    "ButtonType",
    "CHECKMARK",
    "DataTableType",
    "HorizontalType",
    "InputType",
    "PickerDataTable",
    "PickerDataTableType",
    "PickerLayoutConfig",
    "PickerOption",
    "PickerSearchInput",
    "PickerSearchInputType",
    "StaticType",
    "TEXTUAL_SUPPORTED",
    "VerticalType",
    "build_picker_css",
    "filter_picker_options",
    "summarize_picker_labels",
]
