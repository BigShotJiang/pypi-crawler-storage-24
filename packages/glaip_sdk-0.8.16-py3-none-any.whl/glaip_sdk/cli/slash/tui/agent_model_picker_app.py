# pyright: reportGeneralTypeIssues=false
"""Model picker overlay for the `/agents` workspace."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from rich.text import Text as RichText

from glaip_sdk.cli.slash.tui.agent_picker_confirm_modal import AgentPickerConfirmModal
from glaip_sdk.cli.slash.tui.agent_picker_shared import (
    CHECKMARK,
    TEXTUAL_SUPPORTED,
    BaseAgentPickerScreen,
    DataTableType,
    PickerDataTable,
    PickerLayoutConfig,
    PickerOption,
    PickerSearchInput,
    StaticType,
    build_picker_css,
    filter_picker_options,
    summarize_picker_labels,
)

MODEL_LAYOUT = PickerLayoutConfig(
    prefix="model-picker",
    card_width=92,
    card_height=28,
    columns=("Sel", "Model", "Info"),
    apply_label="Apply",
)


@dataclass(frozen=True)
class AgentModelPickerInput:
    """Payload used to render the model picker."""

    title: str
    search_placeholder: str
    options: tuple[PickerOption, ...]
    selected_id: str | None = None


class AgentModelPickerScreen(BaseAgentPickerScreen):
    """Modal model picker with search and keyboard navigation."""

    LAYOUT = MODEL_LAYOUT
    CSS = build_picker_css("AgentModelPickerScreen", MODEL_LAYOUT)

    def __init__(self, payload: AgentModelPickerInput) -> None:
        """Store the model picker payload and current selection context."""
        super().__init__(title=payload.title, search_placeholder=payload.search_placeholder)
        self._payload = payload
        self._filtered_options: list[PickerOption] = list(payload.options)
        self._current_option_id: str | None = payload.selected_id

    def _refresh_table(self) -> None:
        query = self.query_one(f"#{self._picker_id('search')}").value if self.is_mounted else ""
        self._filtered_options = filter_picker_options(self._payload.options, query)
        table = self.query_one(f"#{self._picker_id('table')}", DataTableType)
        table.clear(columns=False)
        for option in self._filtered_options:
            is_current = option.id == self._payload.selected_id
            state_cell = RichText(CHECKMARK, style="bold #7dd3a0") if is_current else RichText("", style="#5b738a")
            label_style = "bold #f5fbff" if is_current else "#d7e4f2"
            info_style = "#b9c8d6" if is_current else "#8fa4ba"
            table.add_row(
                state_cell,
                RichText(option.label, style=label_style),
                RichText(option.detail or "-", style=info_style),
            )
        self._set_cursor_for_option(self._current_option_id)
        self._refresh_summary()
        self._refresh_status()

    def _selected_option_label(self) -> str:
        selected_id = self._selected_option_id()
        for options in (self._filtered_options, self._payload.options):
            for option in options:
                if option.id == selected_id:
                    return option.label
        return "none"

    def _current_option_label(self) -> str:
        for option in self._payload.options:
            if option.id == self._payload.selected_id:
                return option.label
        return "none"

    def _selected_option_detail(self) -> str:
        selected_id = self._selected_option_id()
        for options in (self._filtered_options, self._payload.options):
            for option in options:
                if option.id == selected_id:
                    return option.detail or "-"
        return "-"

    def _refresh_summary(self) -> None:
        current_label = self._current_option_label()
        highlighted_label = self._selected_option_label()
        apply_label = current_label if highlighted_label == "none" else highlighted_label
        apply_prefix = "Apply keeps" if apply_label == current_label else "Apply switches to"
        summary = RichText()
        summary.append("Current: ", style="bold #8fa4ba")
        summary.append(current_label, style="bold #f5fbff")
        summary.append("\n")
        summary.append(f"{apply_prefix}: ", style="bold #8fa4ba")
        summary.append(apply_label, style="bold #7dd3a0" if apply_label != current_label else "#f5fbff")
        self.query_one(f"#{self._picker_id('summary')}", StaticType).update(summary)

    def _refresh_status(self) -> None:
        if not self._filtered_options:
            text = "No matching models. Adjust search or press Esc to cancel."
        else:
            text = f"{len(self._filtered_options)} model(s) shown. Apply or Enter opens confirmation, Esc cancels."
        self.query_one(f"#{self._picker_id('status')}", StaticType).update(text)

    def action_apply(self) -> None:
        """Open confirmation and dismiss only after a confirmed model change."""
        selected_id = self._selected_option_id()
        if not selected_id:
            self.dismiss(None)
            return
        if selected_id == (self._payload.selected_id or ""):
            self.dismiss(selected_id)
            return

        lines = [
            f"Current: {self._current_option_label()}",
            f"Pending: {self._selected_option_label()}",
        ]
        selected_detail = self._selected_option_detail()
        if selected_detail and selected_detail != "-":
            lines.append(f"Model info: {selected_detail}")
        self.app.push_screen(
            AgentPickerConfirmModal(
                title="Confirm model change",
                lines=tuple(lines),
                confirm_label="Change Model",
            ),
            lambda confirmed: self._confirm_apply_selection(selected_id, confirmed),
        )

    def _confirm_apply_selection(self, selected_id: str, confirmed: bool | None) -> None:
        if confirmed:
            self.dismiss(selected_id)

    def on_data_table_row_selected(self, event: Any) -> None:
        """Refresh model picker summary/status without applying on row activation."""
        if getattr(event.data_table, "id", "") != self._picker_id("table"):
            return
        self._refresh_summary()
        self._refresh_status()


__all__ = [
    "AgentModelPickerInput",
    "AgentModelPickerScreen",
    "CHECKMARK",
    "PickerDataTable",
    "PickerOption",
    "PickerSearchInput",
    "TEXTUAL_SUPPORTED",
    "filter_picker_options",
    "summarize_picker_labels",
]
