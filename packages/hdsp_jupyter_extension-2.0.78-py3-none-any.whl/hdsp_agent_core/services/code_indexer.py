"""Codebase Indexer — Python ast + 정규식 기반 코드 시맨틱 청킹 + Qdrant 로컬 적재.

사용자 로컬 코드베이스를 파싱하여 함수/클래스/메서드 단위로 Qdrant 로컬 DB에 적재.
Chat 모드에서 코드 관련 질문 시 자동 검색.
"""

from __future__ import annotations

import ast
import hashlib
import logging
import os
import re
import uuid
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 상수
# ---------------------------------------------------------------------------

CODEBASE_QDRANT_PATH = os.path.expanduser("~/.codebuff/rag/codebase")
COLLECTION_NAME = "code_search"

SUPPORTED_EXTENSIONS = {".py", ".sql"}

EXCLUDED_EXTENSIONS = {
    ".whl",
    ".jar",
    ".pyc",
    ".pyo",
    ".so",
    ".dll",
    ".exe",
    ".bin",
    ".egg",
    ".class",
    ".o",
    ".a",
    ".lib",
    ".dylib",
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".bmp",
    ".ico",
    ".svg",
    ".zip",
    ".tar",
    ".gz",
    ".bz2",
    ".7z",
    ".rar",
    ".pdf",
    ".doc",
    ".docx",
    ".xls",
    ".xlsx",
    ".ppt",
    ".db",
    ".sqlite",
    ".sqlite3",
    ".map",
    ".min.js",
    ".min.css",
    ".lock",
    ".log",
}

EXCLUDED_DIRS = {
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    ".git",
    "dist",
    "build",
    ".egg-info",
    ".tox",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".ipynb_checkpoints",
}

MAX_FILE_SIZE = 1_000_000  # 1MB
MAX_CHUNK_SIZE = 2000  # 2000자 초과 시 분할
MIN_CHUNK_SIZE = 50  # 50자 미만은 병합


# ---------------------------------------------------------------------------
# CodeIndexer
# ---------------------------------------------------------------------------


class CodeIndexer:
    """Python ast + 정규식 기반 코드 인덱서. Qdrant 로컬 전용."""

    def __init__(self, embedding_service: Any):
        self._embedding = embedding_service
        self._client = None
        self._gitignore_spec = None
        self._observer = None

    # ------------------------------------------------------------------
    # Qdrant 초기화
    # ------------------------------------------------------------------

    def _ensure_client(self):
        """Qdrant 로컬 client lazy 초기화."""
        if self._client is not None:
            return
        from qdrant_client import QdrantClient

        Path(CODEBASE_QDRANT_PATH).mkdir(parents=True, exist_ok=True)
        self._client = QdrantClient(path=CODEBASE_QDRANT_PATH)
        logger.info("CodeIndexer: Qdrant local client at %s", CODEBASE_QDRANT_PATH)

    def _ensure_collection(self):
        """code_search 컬렉션 생성 (없으면)."""
        self._ensure_client()
        from qdrant_client.models import Distance, VectorParams

        existing = {c.name for c in self._client.get_collections().collections}
        if COLLECTION_NAME not in existing:
            self._client.create_collection(
                collection_name=COLLECTION_NAME,
                vectors_config=VectorParams(
                    size=self._embedding.dimension,
                    distance=Distance.COSINE,
                ),
            )
            logger.info(
                "Created collection: %s (dim=%d)",
                COLLECTION_NAME,
                self._embedding.dimension,
            )

    # ------------------------------------------------------------------
    # 파일 수집
    # ------------------------------------------------------------------

    def _load_gitignore(self, root: Path):
        """프로젝트 .gitignore 로드."""
        self._gitignore_spec = None
        try:
            import pathspec

            gitignore = root / ".gitignore"
            if gitignore.is_file():
                self._gitignore_spec = pathspec.PathSpec.from_lines(
                    "gitwildmatch", gitignore.read_text().splitlines()
                )
        except ImportError:
            logger.debug("pathspec not installed, .gitignore ignored")

    def _is_excluded(self, fp: Path, root: Path) -> str:
        """파일 제외 여부 + 사유 반환. 빈 문자열이면 포함."""
        rel = fp.relative_to(root)
        for part in rel.parts[:-1]:
            if part in EXCLUDED_DIRS or part.startswith("."):
                return f"dir:{part}"
        if fp.suffix.lower() in EXCLUDED_EXTENSIONS:
            return f"extension:{fp.suffix}"
        try:
            if fp.stat().st_size > MAX_FILE_SIZE:
                return f"size:{fp.stat().st_size}"
        except OSError:
            return "os_error"
        if self._gitignore_spec and self._gitignore_spec.match_file(str(rel)):
            return "gitignore"
        return ""

    def _collect_files(self, root: Path) -> Tuple[List[Path], List[Tuple[Path, str]]]:
        """디렉토리 스캔. (포함 파일, [(제외 파일, 사유)]) 반환."""
        included: List[Path] = []
        excluded: List[Tuple[Path, str]] = []

        for fp in sorted(root.rglob("*")):
            if not fp.is_file() or fp.name.startswith("."):
                continue
            reason = self._is_excluded(fp, root)
            if reason:
                excluded.append((fp, reason))
            elif fp.suffix.lower() in SUPPORTED_EXTENSIONS:
                included.append(fp)

        return included, excluded

    @staticmethod
    def _file_hash(fp: Path) -> str:
        """SHA256 해시 (앞 16자)."""
        return f"sha256:{hashlib.sha256(fp.read_bytes()).hexdigest()[:16]}"

    # ------------------------------------------------------------------
    # Python AST 파싱
    # ------------------------------------------------------------------

    def _parse_python(self, content: str, file_path: str) -> List[Dict[str, Any]]:
        """Python ast 모듈로 시맨틱 블록 추출."""
        try:
            tree = ast.parse(content)
        except SyntaxError:
            logger.warning(
                "SyntaxError parsing %s, falling back to line chunking", file_path
            )
            return self._fallback_chunk(content, file_path, "python")

        lines = content.splitlines()
        chunks: List[Dict[str, Any]] = []
        header_end = 0  # 모듈 레벨 코드 끝 위치

        for node in ast.iter_child_nodes(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                text = self._get_node_source(node, lines)
                chunks.append(
                    {
                        "content": text,
                        "symbol_name": node.name,
                        "symbol_type": "function",
                        "line_start": node.lineno,
                        "line_end": node.end_lineno or node.lineno,
                    }
                )
                header_end = max(header_end, node.lineno - 1)

            elif isinstance(node, ast.ClassDef):
                text = self._get_node_source(node, lines)
                if len(text) > MAX_CHUNK_SIZE:
                    chunks.extend(self._split_class(node, lines, file_path))
                else:
                    chunks.append(
                        {
                            "content": text,
                            "symbol_name": node.name,
                            "symbol_type": "class",
                            "line_start": node.lineno,
                            "line_end": node.end_lineno or node.lineno,
                        }
                    )
                header_end = max(header_end, node.lineno - 1)

        # 모듈 헤더 (import, 상수, 전역 변수)
        if header_end > 0:
            header = "\n".join(lines[:header_end]).strip()
            if len(header) > MIN_CHUNK_SIZE:
                chunks.insert(
                    0,
                    {
                        "content": header,
                        "symbol_name": "(module)",
                        "symbol_type": "module",
                        "line_start": 1,
                        "line_end": header_end,
                    },
                )

        return chunks

    def _split_class(
        self, class_node: ast.ClassDef, lines: List[str], file_path: str
    ) -> List[Dict[str, Any]]:
        """큰 클래스를 메서드 단위로 분할."""
        class_name = class_node.name
        # 클래스 헤더: class 선언 + docstring
        class_header_lines = []
        for i in range(class_node.lineno - 1, min(class_node.lineno + 5, len(lines))):
            class_header_lines.append(lines[i])
            # docstring 끝 감지
            stripped = lines[i].strip()
            if stripped.endswith('"""') or stripped.endswith("'''"):
                if i > class_node.lineno - 1:
                    break

        class_header = "\n".join(class_header_lines)
        chunks: List[Dict[str, Any]] = []

        for node in ast.iter_child_nodes(class_node):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                method_text = self._get_node_source(node, lines)
                # 클래스 헤더 + 메서드
                full_text = f"{class_header}\n\n    {method_text}"
                chunks.append(
                    {
                        "content": full_text,
                        "symbol_name": f"{class_name}.{node.name}",
                        "symbol_type": "method",
                        "line_start": node.lineno,
                        "line_end": node.end_lineno or node.lineno,
                    }
                )

        if not chunks:
            # 메서드 없는 클래스
            text = self._get_node_source(class_node, lines)
            chunks.append(
                {
                    "content": text,
                    "symbol_name": class_name,
                    "symbol_type": "class",
                    "line_start": class_node.lineno,
                    "line_end": class_node.end_lineno or class_node.lineno,
                }
            )

        return chunks

    @staticmethod
    def _get_node_source(node: ast.AST, lines: List[str]) -> str:
        """AST 노드의 소스 코드 추출. 데코레이터 포함."""
        start = node.lineno - 1
        end = node.end_lineno if node.end_lineno else node.lineno

        # 데코레이터 포함
        if hasattr(node, "decorator_list") and node.decorator_list:
            first_decorator = node.decorator_list[0]
            start = first_decorator.lineno - 1

        return "\n".join(lines[start:end])

    # ------------------------------------------------------------------
    # SQL 파싱
    # ------------------------------------------------------------------

    def _parse_sql(self, content: str, file_path: str) -> List[Dict[str, Any]]:
        """SQL 파일을 세미콜론 기준으로 분할."""
        statements = re.split(r";\s*\n", content)
        chunks: List[Dict[str, Any]] = []
        line = 1

        for stmt in statements:
            stmt = stmt.strip()
            if not stmt or len(stmt) < 10:
                line += stmt.count("\n") + 1
                continue

            upper = stmt.upper().lstrip()
            if upper.startswith("SELECT"):
                sym_type = "query"
            elif upper.startswith("CREATE"):
                sym_type = "ddl"
            elif upper.startswith(("INSERT", "UPDATE", "DELETE", "MERGE")):
                sym_type = "dml"
            else:
                sym_type = "sql"

            name_match = re.search(
                r"(?:TABLE|VIEW|INDEX|FUNCTION|PROCEDURE)\s+"
                r"(?:IF\s+NOT\s+EXISTS\s+)?(\S+)",
                stmt,
                re.IGNORECASE,
            )
            symbol_name = name_match.group(1) if name_match else f"({sym_type})"

            end_line = line + stmt.count("\n")
            chunks.append(
                {
                    "content": stmt + ";",
                    "symbol_name": symbol_name,
                    "symbol_type": sym_type,
                    "line_start": line,
                    "line_end": end_line,
                }
            )
            line = end_line + 1

        return chunks

    # ------------------------------------------------------------------
    # 폴백 청킹
    # ------------------------------------------------------------------

    def _fallback_chunk(
        self, content: str, file_path: str, language: str
    ) -> List[Dict[str, Any]]:
        """구문 분석 실패 시 라인 기반 청킹."""
        lines = content.split("\n")
        chunks: List[Dict[str, Any]] = []
        current: List[str] = []
        start_line = 1

        for i, line in enumerate(lines, 1):
            current.append(line)
            if len("\n".join(current)) > 1000:
                chunks.append(
                    {
                        "content": "\n".join(current),
                        "symbol_name": "(block)",
                        "symbol_type": "block",
                        "line_start": start_line,
                        "line_end": i,
                    }
                )
                current = []
                start_line = i + 1

        if current:
            text = "\n".join(current)
            if len(text.strip()) > MIN_CHUNK_SIZE:
                chunks.append(
                    {
                        "content": text,
                        "symbol_name": "(block)",
                        "symbol_type": "block",
                        "line_start": start_line,
                        "line_end": len(lines),
                    }
                )

        return chunks

    # ------------------------------------------------------------------
    # 인덱싱 (전체)
    # ------------------------------------------------------------------

    async def index_codebase(
        self, root_dir: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """전체 코드베이스 인덱싱 (기존 데이터 삭제 후 재적재)."""
        root = Path(root_dir)
        if not root.is_dir():
            yield {"status": "error", "error": f"Not a directory: {root_dir}"}
            return

        self._load_gitignore(root)
        self._ensure_client()

        # 기존 컬렉션 삭제 후 재생성
        try:
            self._client.delete_collection(COLLECTION_NAME)
        except Exception:
            pass
        self._ensure_collection()

        included, excluded = self._collect_files(root)

        # 제외 파일 메타데이터 적재
        if excluded:
            await self._upsert_excluded_files(excluded, root)

        # 코드 파일 파싱 + 임베딩 + 적재
        total_chunks = 0
        for i, fp in enumerate(included):
            yield {
                "status": "running",
                "current": i + 1,
                "total": len(included),
                "file": fp.name,
            }

            try:
                chunks = self._parse_file(fp, root)
                if not chunks:
                    continue

                await self._upsert_chunks(chunks, fp, root)
                total_chunks += len(chunks)
            except Exception as e:
                logger.warning("CodeIndexer error %s: %s", fp, e)
                yield {"status": "error", "file": fp.name, "error": str(e)}

        yield {
            "status": "complete",
            "total_files": len(included),
            "excluded_files": len(excluded),
            "total_chunks": total_chunks,
        }

    # ------------------------------------------------------------------
    # 증분 업데이트
    # ------------------------------------------------------------------

    async def update_codebase(
        self, root_dir: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """증분 업데이트: 변경/추가/삭제된 파일만 처리."""
        root = Path(root_dir)
        self._load_gitignore(root)
        self._ensure_collection()

        included, _ = self._collect_files(root)

        # 기존 Qdrant 데이터 조회
        existing_hashes: Dict[str, str] = {}  # file_path → file_hash
        existing_ids: Dict[str, List[str]] = {}  # file_path → [point_ids]
        scroll_result = self._client.scroll(
            collection_name=COLLECTION_NAME,
            limit=100000,
            with_payload=True,
            with_vectors=False,
        )
        for pt in scroll_result[0]:
            fp = pt.payload.get("file_path", "")
            if not fp:
                continue
            existing_ids.setdefault(fp, []).append(str(pt.id))
            fh = pt.payload.get("file_hash", "")
            if fh:
                existing_hashes[fp] = fh

        current_paths = {str(fp.relative_to(root)) for fp in included}
        added = 0
        updated = 0
        deleted = 0

        # 삭제된 파일
        from qdrant_client.models import PointIdsList

        # excluded_file 타입 포인트는 삭제 대상에서 제외
        excluded_paths: set[str] = set()
        for pt in scroll_result[0]:
            if pt.payload.get("symbol_type") == "excluded_file":
                excluded_paths.add(pt.payload.get("file_path", ""))

        for old_path, point_ids in existing_ids.items():
            if old_path in excluded_paths:
                continue  # 제외 파일 메타데이터는 유지
            if old_path not in current_paths:
                self._client.delete(
                    collection_name=COLLECTION_NAME,
                    points_selector=PointIdsList(points=point_ids),
                )
                deleted += 1

        # 변경/추가
        for i, fp in enumerate(included):
            rel_path = str(fp.relative_to(root))
            new_hash = self._file_hash(fp)

            if rel_path in existing_hashes and existing_hashes[rel_path] == new_hash:
                continue

            yield {
                "status": "running",
                "current": i + 1,
                "total": len(included),
                "file": fp.name,
            }

            # 기존 포인트 삭제
            if rel_path in existing_ids:
                self._client.delete(
                    collection_name=COLLECTION_NAME,
                    points_selector=PointIdsList(points=existing_ids[rel_path]),
                )

            try:
                chunks = self._parse_file(fp, root)
                if chunks:
                    await self._upsert_chunks(chunks, fp, root)
                    if rel_path in existing_hashes:
                        updated += 1
                    else:
                        added += 1
            except Exception as e:
                yield {"status": "error", "file": fp.name, "error": str(e)}

        yield {
            "status": "complete",
            "added": added,
            "updated": updated,
            "deleted": deleted,
        }

    # ------------------------------------------------------------------
    # 삭제 / 상태 / 검색
    # ------------------------------------------------------------------

    def delete_codebase(self):
        """code_search 컬렉션 전체 삭제."""
        self._ensure_client()
        try:
            self._client.delete_collection(COLLECTION_NAME)
            logger.info("Deleted collection: %s", COLLECTION_NAME)
        except Exception:
            pass

    def get_status(self) -> Dict[str, Any]:
        """인덱싱 상태 조회. dirty 플래그 포함."""
        dirty = self.is_dirty()
        self._ensure_client()
        try:
            existing = {c.name for c in self._client.get_collections().collections}
            if COLLECTION_NAME not in existing:
                return {"indexed": False, "total_points": 0, "dirty": dirty}
            count = self._client.count(COLLECTION_NAME).count
            return {"indexed": True, "total_points": count, "dirty": dirty}
        except Exception:
            return {"indexed": False, "total_points": 0, "dirty": dirty}

    def clear_dirty(self):
        """dirty 플래그 리셋. update 완료 후 호출."""
        self._dirty = False

    async def search(self, query: str, top_k: int = 10, score_threshold: float = 0.5) -> List[Dict[str, Any]]:
        """코드 검색."""
        self._ensure_client()
        try:
            existing = {c.name for c in self._client.get_collections().collections}
            if COLLECTION_NAME not in existing:
                return []
        except Exception:
            return []

        query_vec = await self._embedding.embed_query(query)
        results = self._client.query_points(
            collection_name=COLLECTION_NAME,
            query=query_vec,
            limit=top_k,
            score_threshold=score_threshold,
            with_payload=True,
        )
        return [
            {
                "content": pt.payload.get("content", ""),
                "file_path": pt.payload.get("file_path", ""),
                "symbol_name": pt.payload.get("symbol_name", ""),
                "symbol_type": pt.payload.get("symbol_type", ""),
                "line_start": pt.payload.get("line_start", 0),
                "line_end": pt.payload.get("line_end", 0),
                "language": pt.payload.get("language", ""),
                "score": round(pt.score, 4),
            }
            for pt in results.points
            if pt.payload.get("symbol_type") != "excluded_file"
        ]

    # ------------------------------------------------------------------
    # Watchdog 자동 증분
    # ------------------------------------------------------------------

    def start_watcher(self, root_dir: str):
        """파일 변경 감시 시작. dirty 플래그만 설정 (업데이트는 polling으로 실행)."""
        try:
            from watchdog.events import FileSystemEventHandler
            from watchdog.observers import Observer
        except ImportError:
            logger.warning("watchdog not installed, auto-update disabled")
            return

        if self._observer:
            self.stop_watcher()

        class _Handler(FileSystemEventHandler):
            def __init__(self, indexer_ref):
                self._indexer = indexer_ref

            def on_any_event(self, event):
                if event.is_directory:
                    return
                src = Path(event.src_path)
                if src.suffix.lower() not in SUPPORTED_EXTENSIONS:
                    return
                self._indexer._dirty = True

        self._dirty = False
        self._observer = Observer()
        self._observer.schedule(_Handler(self), root_dir, recursive=True)
        self._observer.start()
        logger.info("CodeIndexer: watcher started for %s", root_dir)

    def stop_watcher(self):
        """파일 변경 감시 중지."""
        if self._observer:
            self._observer.stop()
            self._observer.join()
            self._observer = None
            self._dirty = False
            logger.info("CodeIndexer: watcher stopped")

    def is_dirty(self) -> bool:
        """변경 감지 여부 확인. polling에서 호출."""
        return getattr(self, "_dirty", False)

    # ------------------------------------------------------------------
    # 내부 헬퍼
    # ------------------------------------------------------------------

    def _parse_file(self, fp: Path, root: Path) -> List[Dict[str, Any]]:
        """파일 파싱 → 청크 리스트."""
        content = fp.read_text(encoding="utf-8", errors="replace")
        rel_path = str(fp.relative_to(root))

        if fp.suffix.lower() == ".py":
            return self._parse_python(content, rel_path)
        elif fp.suffix.lower() == ".sql":
            return self._parse_sql(content, rel_path)
        return []

    async def _upsert_chunks(self, chunks: List[Dict[str, Any]], fp: Path, root: Path):
        """청크 임베딩 + Qdrant upsert."""
        from qdrant_client.models import PointStruct

        rel_path = str(fp.relative_to(root))
        file_hash = self._file_hash(fp)
        lang = fp.suffix.lstrip(".")

        texts: List[str] = []
        payloads: List[Dict[str, Any]] = []

        for chunk in chunks:
            embed_text = (
                f"[{rel_path} > {chunk['symbol_name']} ({chunk['symbol_type']})]\n"
                f"{chunk['content']}"
            )
            texts.append(embed_text)
            payloads.append(
                {
                    "content": chunk["content"],
                    "file_path": rel_path,
                    "symbol_name": chunk["symbol_name"],
                    "symbol_type": chunk["symbol_type"],
                    "line_start": chunk["line_start"],
                    "line_end": chunk["line_end"],
                    "language": lang,
                    "file_hash": file_hash,
                    "_embed_text": embed_text,
                }
            )

        embeddings = await self._embedding.embed_texts(texts)

        points = [
            PointStruct(id=str(uuid.uuid4()), vector=vec, payload=payload)
            for vec, payload in zip(embeddings, payloads)
        ]
        self._client.upsert(collection_name=COLLECTION_NAME, points=points)

    async def _upsert_excluded_files(
        self, excluded: List[Tuple[Path, str]], root: Path
    ):
        """제외 파일 메타데이터만 적재."""
        from qdrant_client.models import PointStruct

        texts: List[str] = []
        payloads: List[Dict[str, Any]] = []

        for fp, reason in excluded:
            rel_path = str(fp.relative_to(root))
            try:
                size = fp.stat().st_size
            except OSError:
                size = 0
            texts.append(f"[excluded] {rel_path}")
            payloads.append(
                {
                    "content": "",
                    "file_path": rel_path,
                    "symbol_name": "",
                    "symbol_type": "excluded_file",
                    "language": "",
                    "file_size": size,
                    "excluded_reason": reason,
                    "line_start": 0,
                    "line_end": 0,
                }
            )

        embeddings = await self._embedding.embed_texts(texts)

        points = [
            PointStruct(id=str(uuid.uuid4()), vector=vec, payload=payload)
            for vec, payload in zip(embeddings, payloads)
        ]
        self._client.upsert(collection_name=COLLECTION_NAME, points=points)
