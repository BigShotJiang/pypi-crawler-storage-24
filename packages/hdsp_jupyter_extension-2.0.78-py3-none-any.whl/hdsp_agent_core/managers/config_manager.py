"""
Configuration Manager - Handle extension settings persistence

Singleton manager for configuration persistence across sessions.
Includes both admin (LLM/server) and user (workspace/preferences) settings.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Dict, Any


def _is_masked_api_key(value: str) -> bool:
    """Check if a value looks like a masked API key (e.g., 'sk-o...b459').

    Masked keys are produced by _mask_api_key(): key[:4] + '...' + key[-4:]
    resulting in 11-char strings, or '***' for short keys.
    Real API keys are typically 30+ chars and don't contain '...'.
    """
    if not isinstance(value, str) or not value:
        return False
    if value == "***":
        return True
    return "..." in value and len(value) < 20


def _strip_masked_keys(incoming: dict, existing: dict) -> dict:
    """Replace masked API key values in incoming config with existing real values.

    When the frontend sends back masked keys (e.g., 'sk-o...b459'), this function
    restores the real values from the existing config to prevent data corruption.
    """
    import copy

    cleaned = copy.deepcopy(incoming)
    for key, value in list(cleaned.items()):
        if isinstance(value, dict):
            existing_section = existing.get(key, {})
            if isinstance(existing_section, dict):
                # Restore real apiKey if incoming is masked
                if "apiKey" in value and _is_masked_api_key(value["apiKey"]):
                    if "apiKey" in existing_section and not _is_masked_api_key(
                        existing_section["apiKey"]
                    ):
                        value["apiKey"] = existing_section["apiKey"]
                    else:
                        del value["apiKey"]
                # Restore real keys in keys array (e.g., keys[].key)
                if "keys" in value and isinstance(value["keys"], list):
                    existing_keys = existing_section.get("keys", [])
                    existing_keys_by_id = {
                        k.get("id"): k
                        for k in existing_keys
                        if isinstance(k, dict) and "id" in k
                    }
                    for item in value["keys"]:
                        if (
                            isinstance(item, dict)
                            and "key" in item
                            and _is_masked_api_key(item["key"])
                        ):
                            existing_item = existing_keys_by_id.get(item.get("id"))
                            if (
                                existing_item
                                and "key" in existing_item
                                and not _is_masked_api_key(existing_item["key"])
                            ):
                                item["key"] = existing_item["key"]
        elif key == "apiKey" and _is_masked_api_key(value):
            if key in existing and not _is_masked_api_key(existing[key]):
                cleaned[key] = existing[key]
            else:
                del cleaned[key]
    return cleaned


class ConfigManager:
    """Manage configuration persistence"""

    _instance = None
    _config_file = None

    @staticmethod
    def get_env_llm_config() -> dict | None:
        """K8s secret 환경변수에서 LLM 설정 읽기. 설정되지 않으면 None."""
        endpoint = os.environ.get("VLLM_ENDPOINT")
        api_key = os.environ.get("VLLM_API_KEY")
        model = os.environ.get("VLLM_MODEL")
        if not (endpoint and api_key):
            return None

        config = {
            "provider": "vllm",
            "vllm": {
                "endpoint": endpoint,
                "apiKey": api_key,
                "model": model or "default",
            },
            "summarization": {
                "enabled": os.environ.get("SUMMARIZATION_ENABLED", "false").lower()
                == "true",
                "provider": "vllm",
                "endpoint": os.environ.get("SUMMARIZATION_ENDPOINT", ""),
                "apiKey": os.environ.get("SUMMARIZATION_API_KEY", ""),
                "model": os.environ.get("SUMMARIZATION_MODEL"),
            },
            "embedding": {
                "provider": "vllm",
                "endpoint": os.environ.get("EMBEDDING_ENDPOINT", ""),
                "apiKey": os.environ.get("EMBEDDING_API_KEY", ""),
                "model": os.environ.get("EMBEDDING_MODEL", "text-embedding-3-small"),
            },
        }
        return config

    def __init__(self):
        try:
            # 1순위: 환경변수
            jupyter_config_dir = os.environ.get("JUPYTER_CONFIG_DIR")

            # 2순위: 홈 디렉토리 ~/.jupyter
            if not jupyter_config_dir:
                # expanduser가 실패할 경우를 대비
                try:
                    jupyter_config_dir = os.path.expanduser("~/.jupyter")
                except Exception:
                    jupyter_config_dir = None

            # 경로가 유효한지 체크하고, 없으면 생성 시도
            if jupyter_config_dir:
                config_path = Path(jupyter_config_dir)
                try:
                    config_path.mkdir(parents=True, exist_ok=True)
                    self._config_file = config_path / "hdsp_agent_config.json"
                except Exception as e:
                    print(f"Warning: Cannot write to {jupyter_config_dir}: {e}")
                    self._config_file = None

            # 3순위 (비상용): 쓰기 실패했거나 경로가 없으면 /tmp 사용
            if not self._config_file:
                tmp_dir = Path(tempfile.gettempdir()) / "jupyter_hdsp_agent"
                tmp_dir.mkdir(parents=True, exist_ok=True)
                self._config_file = tmp_dir / "hdsp_agent_config.json"
                print(f"Using temporary config path: {self._config_file}")

        except Exception as e:
            # 최악의 경우: 메모리에서만 동작하도록 가짜 경로 설정 (서버 다운 방지)
            print(f"Critical Error in ConfigManager init: {e}")
            self._config_file = Path("/tmp/hdsp_agent_config_fallback.json")

        self._config = self._load_config()

    @classmethod
    def get_instance(cls):
        """Get singleton instance"""
        if cls._instance is None:
            cls._instance = ConfigManager()
        return cls._instance

    @classmethod
    def reset_instance(cls):
        """Reset singleton instance (for testing)"""
        cls._instance = None

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        if not self._config_file.exists():
            return self._default_config()

        try:
            with open(self._config_file, "r") as f:
                loaded = json.load(f)
                # Merge with defaults to ensure all keys exist
                defaults = self._default_config()
                defaults.update(loaded)
                self._migrate_legacy_providers(defaults)
                self._sanitize_masked_keys(defaults)
                return defaults
        except (json.JSONDecodeError, IOError) as e:
            print(f"Error loading config: {e}")
            return self._default_config()

    def _migrate_legacy_providers(self, config: Dict[str, Any]):
        """Auto-migrate gemini/openai provider to vllm."""
        changed = False
        if config.get("provider") in ("gemini", "openai"):
            config["provider"] = "vllm"
            changed = True
        for key in ("gemini", "openai"):
            if key in config:
                del config[key]
                changed = True
        summ = config.get("summarization")
        if isinstance(summ, dict) and summ.get("provider") in ("gemini", "openai"):
            summ["provider"] = "vllm"
            changed = True
        if changed:
            self._persist(config)

    def _sanitize_masked_keys(self, config: Dict[str, Any]):
        """마스킹된 API 키를 빈 문자열로 교체하고 파일에 반영."""
        changed = False
        for section_key in ("vllm", "summarization", "embedding"):
            section = config.get(section_key)
            if isinstance(section, dict):
                api_key = section.get("apiKey", "")
                if _is_masked_api_key(api_key):
                    section["apiKey"] = ""
                    changed = True
        if changed:
            print(
                "[ConfigManager] WARNING: 마스킹된 API 키가 감지되어 제거되었습니다. "
                "설정에서 API 키를 다시 입력하세요."
            )
            self._persist(config)

    def _persist(self, config: Dict[str, Any]):
        """Write config dict to file."""
        try:
            self._config_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self._config_file, "w") as f:
                json.dump(config, f, indent=2)
        except IOError as e:
            print(f"Warning: Failed to persist migrated config: {e}")

    def _default_config(self) -> Dict[str, Any]:
        """Get default configuration (merged admin + user schema)"""
        return {
            # LLM Provider Settings
            "provider": "vllm",
            "vllm": {
                "endpoint": "https://openrouter.ai/api/v1",
                "apiKey": "",
                "model": "openai/gpt-4o",
            },
            # Summarization LLM
            "summarization": {
                "enabled": False,
                "provider": "vllm",
                "model": None,
                "endpoint": "",
                "apiKey": "",
            },
            # Embedding
            "embedding": {
                "provider": "openai",
                "model": "text-embedding-3-small",
                "apiKey": "",
                "endpoint": "",
            },
            # RAG
            "rag": {
                "enabled": True,
                "knowledgeBasePath": None,
                "qdrantMode": "local",
                "qdrantUrl": "http://localhost:6333",
                "qdrantPath": None,
                "collectionName": "hdsp_docs",
                "embeddingBackend": "vllm",
                "vllmEndpoint": "http://localhost:8000",
                "vllmModel": "qwen3-embedding-8b",
                "vllmDimension": 4096,
                "vllmApiKey": "",
            },
            # Server Settings
            "idleTimeout": 3600,
            "maxOutputTokens": 4096,
            # Prompts (None = use defaults)
            "prompts": {
                "chat_system_prompt": None,  # Chat 모드 기본 프롬프트 (None = 기본값)
                "chat_rag_prompt": None,  # RAG 검색 가이드 프롬프트 (None = 기본값)
                "planner": None,
                "python_expert": None,
                "python_developer": None,  # backward compat alias
                "researcher": None,
                "athena_query": None,
                "mwaa_expert": None,
                "emr_expert": None,
                "lambda_expert": None,
                "spring_expert": None,
            },
            # Guardrails
            "guardrails": {
                "enableInput": True,
                "enableOutput": True,
                "maxInputLength": 50000,
                "maxCodeLength": 10000,
            },
            # User Settings
            "workspaceRoot": "",
            "temperature": 0.0,
            "autoApprove": False,
        }

    def get_config(self) -> Dict[str, Any]:
        """Get current configuration"""
        # Reload config from file to ensure we have the latest
        self._config = self._load_config()
        return self._config.copy()

    def save_config(self, config: Dict[str, Any]):
        """Save configuration to file - no validation"""
        # Strip masked API keys to prevent overwriting real keys
        config = _strip_masked_keys(config, self._config)
        # Merge with existing config
        self._config.update(config)

        # Ensure config directory exists
        self._config_file.parent.mkdir(parents=True, exist_ok=True)

        # Write to file
        try:
            with open(self._config_file, "w") as f:
                json.dump(self._config, f, indent=2)
        except IOError as e:
            raise RuntimeError(f"Failed to save config: {e}")

    def get(self, key: str, default=None):
        """Get specific config value"""
        return self._config.get(key, default)

    def set(self, key: str, value: Any):
        """Set specific config value"""
        self._config[key] = value
        self.save_config(self._config)

    def update_config(self, updates: Dict[str, Any]):
        """Update configuration with partial updates (deep merge for nested dicts)"""
        # Strip masked API keys to prevent overwriting real keys
        updates = _strip_masked_keys(updates, self._config)
        for key, value in updates.items():
            if (
                key in self._config
                and isinstance(self._config[key], dict)
                and isinstance(value, dict)
            ):
                self._config[key].update(value)
            else:
                self._config[key] = value
        self.save_config(self._config)

    def get_admin_config(self) -> Dict[str, Any]:
        """Get admin configuration (all server settings)."""
        config = self.get_config()
        return config.copy()

    def update_admin_config(self, updates: Dict[str, Any]):
        """Update admin configuration."""
        self.update_config(updates)

    def get_user_config(self) -> Dict[str, Any]:
        """Get user configuration (workspace, temperature, autoApprove)."""
        config = self.get_config()
        return {
            "workspaceRoot": config.get("workspaceRoot", ""),
            "temperature": config.get("temperature", 0.0),
            "autoApprove": config.get("autoApprove", False),
        }

    def update_user_config(self, updates: Dict[str, Any]):
        """Update user configuration (only allowed fields)."""
        allowed_fields = {"workspaceRoot", "temperature", "autoApprove"}
        filtered_updates = {k: v for k, v in updates.items() if k in allowed_fields}
        if filtered_updates:
            self.update_config(filtered_updates)


def get_config_manager() -> ConfigManager:
    """Get the singleton ConfigManager instance"""
    return ConfigManager.get_instance()
