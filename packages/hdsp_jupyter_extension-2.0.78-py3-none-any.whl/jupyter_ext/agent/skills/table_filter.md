## 테이블 검색 Pre-Filtering 가이드

{filter_guide}

## rag_search에서 filters 사용법

filters는 Qdrant payload 기반 사전 필터링입니다. 벡터 검색 전에 조건 매칭 포인트만 남깁니다.
위 샘플 값에 있는 필드명과 값만 사용하세요. 사용자가 명시하지 않은 값을 추측하지 마세요.

필터 형식: {{"field": "필드명", "value": "값"}}

예시:
[{{"query": "카드 거래", "collection": "enterprise_tables", "filters": [{{"field": "db_name", "value": "위 샘플에서 확인한 실제 DB명"}}]}}]

**주의**: 사용자가 특정 DB명/도메인/팀명을 언급하지 않았다면 filters 없이 검색하세요.
필터를 잘못 사용하면 결과가 0건이 될 수 있습니다.
