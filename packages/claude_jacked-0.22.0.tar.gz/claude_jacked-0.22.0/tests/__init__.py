"""Tests for Smart Fork."""
