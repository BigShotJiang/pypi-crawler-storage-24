from abstra_internals.controllers.execution.consumer import ConsumerController
from abstra_internals.controllers.main import MainController
from abstra_internals.environment import DEFAULT_PORT, RABBITMQ_CONNECTION_URI
from abstra_internals.logger import AbstraLogger
from abstra_internals.repositories.consumer import (
    ProductionControlConsumer,
    RabbitConsumer,
)
from abstra_internals.repositories.factory import build_prod_repositories
from abstra_internals.settings import SettingsController
from abstra_internals.signals import SignalHandlers
from abstra_internals.utils.packages import get_local_package_version


def run():
    SignalHandlers.init()
    AbstraLogger.init("cloud")
    AbstraLogger.warning(
        f"[abstra-worker] Running abstra version {get_local_package_version()}"
    )
    SettingsController.set_root_path(".")
    SettingsController.set_server_port(DEFAULT_PORT)

    if not RABBITMQ_CONNECTION_URI:
        raise Exception("RABBITMQ_CONNECTION_URI not found")

    controller = MainController(repositories=build_prod_repositories())

    with RabbitConsumer(RABBITMQ_CONNECTION_URI) as consumer:
        with ProductionControlConsumer(RABBITMQ_CONNECTION_URI) as control_consumer:
            SignalHandlers.register_sigterm_callback(consumer.stop_iter)
            SignalHandlers.register_sigterm_callback(control_consumer.stop_iter)
            ConsumerController(controller, consumer, control_consumer).start_loop()


if __name__ == "__main__":
    run()
