from typing import Any
import logging
import os
import uuid
from datetime import datetime, timezone

import qnexus as qnx
from qnexus.models.language import Language
from qnexus.client.devices import DeviceStateEnum
from pytket import Circuit
from pytket.extensions.qiskit import qiskit_to_tk
from pytket.backends.backendinfo import BackendInfo
from qiskit import QuantumCircuit


from qbraid import QPROGRAM
from qbraid.runtime import DeviceStatus, QuantumDevice, TargetProfile
from qbraid.programs import ExperimentType, ProgramSpec
from metriq_gym.quantinuum.job import QuantinuumJob

logger = logging.getLogger(__name__)


def _get_quantinuum_backend_info(device_name: str) -> BackendInfo:
    """Fetch backend_info for a Quantinuum device from the Nexus API.

    Args:
        device_name: The Quantinuum device name (e.g., 'H2-2').

    Returns:
        The backend_info object from the Nexus API.

    Raises:
        ValueError: If the device is not found in the Quantinuum device list.
    """
    df = qnx.devices.get_all(issuers=[qnx.devices.IssuerEnum.QUANTINUUM]).df()
    matching_rows = df.loc[df["device_name"] == device_name]

    if matching_rows.empty:
        available_devices = df["device_name"].tolist()
        raise ValueError(
            f"Device '{device_name}' not found in Quantinuum device list. "
            f"Available devices: {available_devices}"
        )

    row = matching_rows.iloc[0]
    return row["backend_info"]


def _profile(device_id: str, backend_info: BackendInfo) -> TargetProfile:
    return TargetProfile(
        device_id=device_id,
        # TODO: find a property to distinguish real vs. simulator
        simulator="E" in device_id.upper(),
        experiment_type=ExperimentType.GATE_MODEL,
        num_qubits=len(backend_info.architecture.nodes),
        program_spec=ProgramSpec(Circuit),
        basis_gates=None,
        provider_name="quantinuum",
        extra={},
    )


class QuantinuumDevice(QuantumDevice):
    def __init__(self, *, provider, device_id: str) -> None:
        self._backend_info = _get_quantinuum_backend_info(device_id)
        super().__init__(_profile(device_id, self._backend_info))
        self._provider = provider

    def status(self) -> DeviceStatus:
        # Query this each time to get the most up-to-date status"""
        cfg = qnx.models.QuantinuumConfig(device_name=self.profile.device_id)
        status = qnx.devices.status(cfg)
        if status in (DeviceStateEnum.ONLINE, DeviceStateEnum.RESERVED_ONLINE):
            return DeviceStatus.ONLINE
        elif status in (DeviceStateEnum.MAINTENANCE, DeviceStateEnum.RESERVED_MAINTENANCE):
            return DeviceStatus.UNAVAILABLE
        else:
            return DeviceStatus.OFFLINE

    def run(self, run_input: QPROGRAM, *args, **kwargs):
        # Override base run to avoid iterating single circuits as sequences
        return self.submit(run_input, *args, **kwargs)

    def transform(self, run_input: QPROGRAM):
        # Always return a list of pytket Circuits
        if isinstance(run_input, list) or isinstance(run_input, tuple):
            return [item for c in run_input for item in self.transform(c)]
        if isinstance(run_input, Circuit):
            return [run_input]
        if isinstance(run_input, QuantumCircuit):
            return [qiskit_to_tk(run_input)]
        raise TypeError(
            f"Unsupported run_input type {type(run_input)}; expected pytket.Circuit or qiskit.QuantumCircuit"
        )

    def submit(self, run_input: QPROGRAM, *, shots: int | None = None, **_: Any) -> QuantinuumJob:
        project = qnx.projects.get_or_create(
            name=os.getenv("QUANTINUUM_NEXUS_PROJECT_NAME", "metriq-gym")
        )
        backend_config = qnx.QuantinuumConfig(device_name=self.profile.device_id)

        circuits_list = self.transform(run_input)

        def unique(label: str) -> str:
            ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
            return f"metriq-gym {label} {ts}-{uuid.uuid4().hex[:6]}"

        circuit_refs = [
            qnx.circuits.upload(name=unique(f"circuit-{i}"), circuit=c, project=project)
            for i, c in enumerate(circuits_list)
        ]

        opt = int(os.getenv("QUANTINUUM_NEXUS_OPT_LEVEL", "1"))
        compile_job = qnx.start_compile_job(
            programs=circuit_refs,
            name=unique("compile"),
            optimisation_level=opt,
            backend_config=backend_config,
            project=project,
        )
        # NOTE: This is a blocking wait that occurs during dispatch.
        # Depending on queue and program size, compilation may take time.
        print(
            f"Waiting for Quantinuum compilation job {getattr(compile_job, 'id', getattr(compile_job, 'job_id', str(compile_job)))} to complete..."
        )
        qnx.jobs.wait_for(compile_job)
        compiled_refs = [item.get_output() for item in qnx.jobs.results(compile_job)]

        nshots = int(shots or 1000)
        execute_job = qnx.start_execute_job(
            programs=compiled_refs,
            name=unique("execute"),
            n_shots=[nshots] * len(compiled_refs),
            backend_config=backend_config,
            project=project,
            language=Language.QIR,
        )
        job_id = (
            getattr(execute_job, "id", None)
            or getattr(execute_job, "job_id", None)
            or str(execute_job)
        )
        return QuantinuumJob(str(job_id), device=self)
