# mytools

My personal data science toolkit. Install once, use everywhere.

## Install

**Locally (recommended):**
```bash
pip install -e /path/to/mytools
```

**From GitHub:**
```bash
pip install git+https://github.com/yourusername/mytools.git
```

## Usage

```python
from mytools import *

# All packages instantly available
df = pd.read_csv("data.csv")
arr = np.array([1, 2, 3])
model = RandomForestClassifier()
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Custom helpers
df = load_csv("data.csv")
quick_summary(df)
plot_distribution(df, "price")
report = missing_report(df)
df_encoded = encode_categoricals(df, strategy="label")
```

## Packages Included

| Category      | Packages                                          |
|--------------|---------------------------------------------------|
| Core          | numpy, pandas, scipy                              |
| Visualization | matplotlib, seaborn, plotly                       |
| ML            | scikit-learn, xgboost                             |
| Notebooks     | jupyter, ipykernel                                |
| Utilities     | python-dotenv, tqdm, rich                         |

## Custom Functions (utils.py)

| Function               | Description                                  |
|-----------------------|----------------------------------------------|
| `load_csv(path)`       | Load CSV and print shape + preview           |
| `quick_summary(df)`    | Full overview: dtypes, missing, stats        |
| `missing_report(df)`   | DataFrame of missing counts + percentages    |
| `plot_distribution(df, col)` | Histogram + boxplot side by side       |
| `encode_categoricals(df)` | Label or one-hot encode all object cols   |

## Adding New Packages

1. Add to `install_requires` in `setup.py`
2. Add `import` statement in `mytools/__init__.py`
3. Run `pip install -e .` again

## Adding Custom Functions

1. Write your function in `mytools/utils.py`
2. Export it in `mytools/__init__.py`:
   ```python
   from .utils import your_function_name
   ```