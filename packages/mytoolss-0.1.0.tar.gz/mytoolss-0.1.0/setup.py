from setuptools import setup, find_packages

setup(
    name="mytoolss",
    version="0.1.0",
    author="Your Name",
    author_email="you@example.com",
    description="My personal data science toolkit",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        # Core data science
        "numpy",
        "pandas",
        "scipy",

        # Visualization
        "matplotlib",
        "seaborn",
        "plotly",

        # Machine learning
        "scikit-learn",
        "xgboost",

        # Notebooks
        "jupyter",
        "ipykernel",

        # Utilities
        "python-dotenv",
        "tqdm",
        "rich",
    ],
)