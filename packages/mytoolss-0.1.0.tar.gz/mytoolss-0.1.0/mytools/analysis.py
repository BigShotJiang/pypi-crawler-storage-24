from mytools import *        # ← this one line replaces 20 imports

df = load_csv("data.csv")
quick_summary(df)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
model = RandomForestClassifier()
model.fit(X_train, y_train)

print(accuracy_score(y_test, model.predict(X_test)))