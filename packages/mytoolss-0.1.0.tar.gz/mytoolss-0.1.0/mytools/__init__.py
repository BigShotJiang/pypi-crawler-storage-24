# ============================================================
# mytools — Personal Data Science Toolkit
# Usage: from mytools import *
# ============================================================

# --- Core ---
import numpy as np
import pandas as pd
import scipy

# --- Visualization ---
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

# --- Machine Learning ---
import sklearn
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, MinMaxScaler, LabelEncoder, OneHotEncoder
from sklearn.linear_model import LinearRegression, LogisticRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, GradientBoostingClassifier
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.svm import SVC, SVR
from sklearn.metrics import (
    accuracy_score,
    mean_squared_error,
    mean_absolute_error,
    r2_score,
    classification_report,
    confusion_matrix,
)
import xgboost as xgb

# --- Standard Library ---
import os
import sys
import json
import math
import time
import random
import datetime
import warnings
from pathlib import Path
from collections import Counter, defaultdict

# --- Utilities ---
from dotenv import load_dotenv
from tqdm import tqdm
from rich import print as rprint

# --- Custom Helpers ---
from .utils import load_csv, quick_summary, plot_distribution, missing_report, encode_categoricals

# Suppress common warnings for cleaner output
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

print("✅ mytools loaded — all packages ready!")