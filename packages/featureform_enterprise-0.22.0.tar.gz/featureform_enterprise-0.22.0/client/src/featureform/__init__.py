# To properly display pending deprecation warnings for the ResourceClient
# and ServingClient classes, we need to set the formatwarning function
# to a custom function to avoid the default behavior of printing the
# the absolute path to the file where the warning was raised. Additionally,
# we need to set the default filter to 'default' to avoid the default
# behavior of ignoring all warnings.
# TODO: Remove this code once the ResourceClient and ServingClient classes
# are deprecated.
import warnings


def custom_warning_formatter(message, category, filename, lineno, file=None, line=None):
    return f"{category.__name__}: {message}\n"


warnings.formatwarning = custom_warning_formatter
warnings.simplefilter("default")

from .client import Client
from .client import ResourceClient as _ResourceClient
from .config.catalogs import SnowflakeCatalog, SnowflakeDynamicTableConfig, UnityCatalog
from .config.offline_stores import SnowflakeKeyPairConfig
from .enums import (
    AggregateFunction,
    ComputationMode,
    DataResourceType,
    FilePrefix,
    Initialize,
    JoinStrategy,
    RefreshMode,
    ResourceType,
    TableFormat,
    TrainingSetType,
)
from .register import *
from .resources import (
    AWSAssumeRoleCredentials,
    AWSStaticCredentials,
    BasicCredentials,
    DailyPartition,
    DatabricksClusterConfig,
    DatabricksCredentials,
    EMRCredentials,
    EMRServerlessCredentials,
    EntityMapping,
    EntityMappings,
    FeaturesSchema,
    GCPCredentials,
    GlueCatalog,
    HashPartition,
    KerberosCredentials,
    MaterializationOptions,
    PostgresConfig,
    RedisTLSConfig,
    SparkCredentials,
)
from .serving import ServingClient

ServingClient = ServingClient
ResourceClient = _ResourceClient
Client = Client

# Executor Credentials
DatabricksClusterConfig = DatabricksClusterConfig
DatabricksCredentials = DatabricksCredentials
EMRCredentials = EMRCredentials
EMRServerlessCredentials = EMRServerlessCredentials
SparkCredentials = SparkCredentials

# Cloud Provider Credentials
AWSStaticCredentials = AWSStaticCredentials
AWSAssumeRoleCredentials = AWSAssumeRoleCredentials
GCPCredentials = GCPCredentials
GlueCatalog = GlueCatalog
UnityCatalog = UnityCatalog
SnowflakeCatalog = SnowflakeCatalog
SnowflakeDynamicTableConfig = SnowflakeDynamicTableConfig

# HDFS Credentials
BasicCredentials = BasicCredentials
KerberosCredentials = KerberosCredentials

# Feature Views
MaterializationOptions = MaterializationOptions
JoinStrategy = JoinStrategy
FeaturesSchema = FeaturesSchema
EntityMappings = EntityMappings
EntityMapping = EntityMapping

# Partitioning
DailyPartition = DailyPartition
HashPartition = HashPartition

# Provider Configs
PostgresConfig = PostgresConfig
RedisTLSConfig = RedisTLSConfig
SnowflakeKeyPairConfig = SnowflakeKeyPairConfig

# Class API
# Label now uses the Label factory function from label_api which returns:
# - LabelBuilder when called with no args (fluent builder API)
# - LabelColumnResource when called with args (legacy API)
from .registrar.label_api import Label as Label

Variants = Variants
Embedding = EmbeddingColumnResource

# Feature API v2 - re-exported from feature_api module
# The Feature factory function and FeatureBuilder class are imported from register.py
# which in turn imports from registrar.feature_api
Feature = Feature
FeatureBuilder = FeatureBuilder

# Column specification types - for multi-feature registration
Col = Col
alias = alias

# Realtime Feature API - re-exported from registrar.realtime_feature module
FeatureInput = FeatureInput
RealtimeInput = RealtimeInput
RealtimeBuiltFeature = RealtimeBuiltFeature
RealtimeFeatureConfig = RealtimeFeatureConfig

set_run = set_run
get_run = get_run

# Enums
AggregateFunction = AggregateFunction
DataResourceType = DataResourceType
ResourceType = ResourceType
TableFormat = TableFormat
FilePrefix = FilePrefix
TrainingSetType = TrainingSetType
ComputationMode = ComputationMode
JoinStrategy = JoinStrategy
RefreshMode = RefreshMode
Initialize = Initialize

# Constants
ONE_DAY_TARGET_LAG = ONE_DAY_TARGET_LAG
LIFETIME_WINDOW = LIFETIME_WINDOW
