# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""
Constants for Featureform resources.
"""

# StreamChannels (e.g., KafkaTopic) use a fixed variant since they don't
# support versioning. This constant is used internally when registering
# the associated SourceVariant and when resolving streaming inputs.
# From the user's perspective, streaming inputs have no variant.
STREAM_CHANNEL_VARIANT = "default"
