from __future__ import annotations

import contextlib
import logging
import subprocess
from pathlib import Path

logger = logging.getLogger("python_checkup")


class GitError(Exception):
    """Raised when a git command fails."""


def get_changed_files(
    project_root: Path,
    *,
    base: str = "main",
) -> list[Path]:
    """Get Python files changed between current branch and base.

    Uses merge-base to find the common ancestor, then lists files
    changed since that point. This matches what a PR would show.

    Returns empty list if not in a git repo or if git commands fail.
    """
    try:
        # Step 1: Verify we're in a git repo
        _run_git(["rev-parse", "--git-dir"], cwd=project_root)

        # Step 2: Get current branch name (for logging)
        current_branch = _run_git(
            ["rev-parse", "--abbrev-ref", "HEAD"],
            cwd=project_root,
        ).strip()
        logger.debug("Current branch: %s", current_branch)

        # Step 3: Find merge-base (common ancestor)
        try:
            merge_base = _run_git(
                ["merge-base", base, "HEAD"],
                cwd=project_root,
            ).strip()
            logger.debug("Merge base with %s: %s", base, merge_base[:10])
        except GitError:
            logger.warning(
                "Could not find merge-base with '%s'. Comparing directly against '%s'.",
                base,
                base,
            )
            merge_base = base

        # Step 4: Get changed files (committed)
        # --diff-filter=ACMR: Added, Copied, Modified, Renamed
        output = _run_git(
            [
                "diff",
                "--name-only",
                "--diff-filter=ACMR",
                "--relative",
                merge_base,
            ],
            cwd=project_root,
        )

        # Also include uncommitted changes (staged + unstaged)
        uncommitted = _run_git(
            [
                "diff",
                "--name-only",
                "--diff-filter=ACMR",
                "--relative",
                "HEAD",
            ],
            cwd=project_root,
        )

        # Combine and deduplicate
        all_files = set(output.strip().split("\n")) | set(
            uncommitted.strip().split("\n")
        )

        # Step 5: Filter to Python files that exist
        python_files: list[Path] = []
        for f in sorted(all_files):
            f = f.strip()
            if not f or not f.endswith(".py"):
                continue
            full_path = project_root / f
            if full_path.is_file():
                python_files.append(full_path)

        logger.info(
            "Found %d changed Python files (branch: %s, base: %s)",
            len(python_files),
            current_branch,
            base,
        )
        return python_files

    except GitError as e:
        logger.warning("Git diff failed: %s. Falling back to full scan.", e)
        return []


_COMMON_BASE_BRANCHES = ("main", "master", "develop", "development")


def get_pr_changed_files(
    project_root: Path,
    *,
    pr_number: int,
    remote: str = "origin",
) -> tuple[list[Path], str]:
    """Fetch a GitHub PR locally and return its changed Python files.

    Works without a GitHub API token -- uses the ``pull/<N>/head`` refspec
    that GitHub exposes for every PR.

    Returns ``(python_files, base_branch)`` so the caller can display which
    base was used.  Raises :class:`GitError` on failure.
    """
    # Step 1: Verify git repo
    _run_git(["rev-parse", "--git-dir"], cwd=project_root)

    # Step 2: Fetch the PR head into a local ref
    pr_ref = f"refs/pull/{pr_number}/head"
    local_ref = f"pr-{pr_number}"
    logger.info("Fetching PR #%d from %s...", pr_number, remote)
    _run_git(
        ["fetch", remote, f"{pr_ref}:{local_ref}"],
        cwd=project_root,
    )

    try:
        pr_sha = _run_git(
            ["rev-parse", local_ref],
            cwd=project_root,
        ).strip()
        logger.debug("PR #%d HEAD: %s", pr_number, pr_sha[:10])

        # Step 3: Detect the base branch by finding which common branch
        # has the closest merge-base
        base_branch = _detect_pr_base(project_root, local_ref, remote)

        # Step 4: Find merge-base and diff
        merge_base = _run_git(
            ["merge-base", f"{remote}/{base_branch}", local_ref],
            cwd=project_root,
        ).strip()
        logger.debug("Merge base with %s: %s", base_branch, merge_base[:10])

        output = _run_git(
            [
                "diff",
                "--name-only",
                "--diff-filter=ACMR",
                "--relative",
                merge_base,
                local_ref,
            ],
            cwd=project_root,
        )

        # Step 5: Filter to Python files that exist on the PR branch
        # We use `git show <ref>:<path>` to check existence without checkout
        python_files: list[Path] = []
        for f in sorted(set(output.strip().split("\n"))):
            f = f.strip()
            if not f or not f.endswith(".py"):
                continue
            # Verify the file exists in the PR ref
            try:
                _run_git(["cat-file", "-e", f"{local_ref}:{f}"], cwd=project_root)
                python_files.append(project_root / f)
            except GitError:
                continue

        logger.info(
            "PR #%d: %d changed Python files (base: %s/%s)",
            pr_number,
            len(python_files),
            remote,
            base_branch,
        )
        return python_files, base_branch

    finally:
        # Clean up the local ref
        with contextlib.suppress(GitError):
            _run_git(["branch", "-D", local_ref], cwd=project_root)


def _detect_pr_base(
    project_root: Path,
    pr_ref: str,
    remote: str,
) -> str:
    """Heuristically detect which remote branch is the PR's base.

    Tries common branch names and picks the one whose merge-base is
    closest to the PR head (i.e. fewest commits ahead).
    """
    best_branch = "main"
    best_distance = float("inf")

    for branch in _COMMON_BASE_BRANCHES:
        remote_ref = f"{remote}/{branch}"
        try:
            _run_git(["rev-parse", "--verify", remote_ref], cwd=project_root)
        except GitError:
            continue

        try:
            merge_base = _run_git(
                ["merge-base", remote_ref, pr_ref],
                cwd=project_root,
            ).strip()

            # Count commits between merge-base and PR head
            log_output = _run_git(
                ["rev-list", "--count", f"{merge_base}..{pr_ref}"],
                cwd=project_root,
            ).strip()
            distance = int(log_output)

            if distance < best_distance:
                best_distance = distance
                best_branch = branch
        except (GitError, ValueError):
            continue

    logger.debug(
        "Detected PR base branch: %s (distance: %s)", best_branch, best_distance
    )
    return best_branch


def _run_git(args: list[str], cwd: Path) -> str:
    """Run a git command and return stdout.

    Raises GitError if the command fails.
    """
    try:
        result = subprocess.run(  # nosec B603 B607
            ["git", *args],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except FileNotFoundError as exc:
        raise GitError("git is not installed or not on PATH") from exc
    except subprocess.TimeoutExpired as exc:
        raise GitError(f"git {args[0]} timed out") from exc

    if result.returncode != 0:
        raise GitError(
            f"git {' '.join(args)} failed "
            f"(exit {result.returncode}): "
            f"{result.stderr.strip()}"
        )

    return result.stdout
