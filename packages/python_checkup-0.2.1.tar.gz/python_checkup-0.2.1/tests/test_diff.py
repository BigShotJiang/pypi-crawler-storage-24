from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any, cast
from unittest.mock import patch

import pytest

from python_checkup.diff import GitError, get_changed_files, get_pr_changed_files


class TestGetChangedFiles:
    def test_returns_empty_when_not_git_repo(self, tmp_path: Path) -> None:
        """Non-git directories return empty list."""
        result = get_changed_files(tmp_path, base="main")
        assert result == []

    @patch("python_checkup.diff._run_git")
    def test_returns_python_files_only(self, mock_git: object) -> None:
        """Non-Python files are filtered out."""

        def side_effect(args: list[str], cwd: Path) -> str:
            if args[0] == "rev-parse" and args[1] == "--git-dir":
                return ".git"
            if args[0] == "rev-parse" and args[1] == "--abbrev-ref":
                return "feature-branch"
            if args[0] == "merge-base":
                return "abc123"
            if args[0] == "diff":
                return "src/app.py\nsrc/views.py\nREADME.md\npackage.json\n"
            return ""

        cast(Any, mock_git).side_effect = side_effect

        root = Path("/tmp/test_project")
        with patch.object(Path, "is_file", return_value=True):
            files = get_changed_files(root, base="main")

        py_files = [f for f in files if str(f).endswith(".py")]
        non_py = [f for f in files if not str(f).endswith(".py")]
        assert len(non_py) == 0
        assert len(py_files) == 2

    @patch("python_checkup.diff._run_git")
    def test_handles_no_changes(self, mock_git: object) -> None:
        """Empty diff returns empty list."""

        def side_effect(args: list[str], cwd: Path) -> str:
            if args[0] == "rev-parse" and args[1] == "--git-dir":
                return ".git"
            if args[0] == "rev-parse" and args[1] == "--abbrev-ref":
                return "main"
            if args[0] == "merge-base":
                return "abc123"
            if args[0] == "diff":
                return ""
            return ""

        cast(Any, mock_git).side_effect = side_effect
        files = get_changed_files(Path("/tmp/test"), base="main")
        assert files == []


class TestGitIntegration:
    """Integration tests that require a real git repo."""

    def test_real_git_repo(self, tmp_path: Path) -> None:
        """Test with an actual git repository."""
        subprocess.run(
            ["git", "init"],
            cwd=tmp_path,
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.email", "test@test.com"],
            cwd=tmp_path,
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test"],
            cwd=tmp_path,
            capture_output=True,
        )

        # Create and commit a file on main
        (tmp_path / "existing.py").write_text("x = 1\n")
        subprocess.run(
            ["git", "add", "."],
            cwd=tmp_path,
            capture_output=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "initial"],
            cwd=tmp_path,
            capture_output=True,
        )
        subprocess.run(
            ["git", "branch", "-M", "main"],
            cwd=tmp_path,
            capture_output=True,
        )

        # Create a branch and add a new file
        subprocess.run(
            ["git", "checkout", "-b", "feature"],
            cwd=tmp_path,
            capture_output=True,
        )
        (tmp_path / "new_file.py").write_text("y = 2\n")
        subprocess.run(
            ["git", "add", "."],
            cwd=tmp_path,
            capture_output=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "add feature"],
            cwd=tmp_path,
            capture_output=True,
        )

        files = get_changed_files(tmp_path, base="main")
        filenames = [f.name for f in files]
        assert "new_file.py" in filenames
        assert "existing.py" not in filenames


class TestGetPrChangedFiles:
    """Unit tests for get_pr_changed_files using mocked git."""

    @patch("python_checkup.diff._run_git")
    def test_fetches_pr_ref_and_returns_files(self, mock_git: object) -> None:
        """PR fetch returns only Python files from the diff."""

        def side_effect(args: list[str], cwd: Path) -> str:
            cmd = args[0]
            if cmd == "rev-parse":
                if args[1] == "--git-dir":
                    return ".git"
                if args[1] == "--verify":
                    # Only origin/main exists
                    if "main" in args[2]:
                        return "abc123"
                    raise GitError("not found")
                # rev-parse pr-99
                return "def456"
            if cmd == "fetch":
                return ""
            if cmd == "merge-base":
                return "aaa111"
            if cmd == "rev-list":
                return "3"
            if cmd == "diff":
                return "app.py\nutils.py\nREADME.md\n"
            if cmd == "cat-file":
                # All files exist in the PR ref
                return ""
            if cmd == "branch":
                return ""
            return ""

        cast(Any, mock_git).side_effect = side_effect

        files, base = get_pr_changed_files(Path("/tmp/test_project"), pr_number=99)
        assert base == "main"
        filenames = [f.name for f in files]
        assert "app.py" in filenames
        assert "utils.py" in filenames
        assert "README.md" not in filenames

    @patch("python_checkup.diff._run_git")
    def test_pr_fetch_failure_raises(self, mock_git: object) -> None:
        """GitError propagates when fetch fails."""

        def side_effect(args: list[str], cwd: Path) -> str:
            if args[0] == "rev-parse" and args[1] == "--git-dir":
                return ".git"
            if args[0] == "fetch":
                raise GitError("Could not resolve PR ref")
            return ""

        cast(Any, mock_git).side_effect = side_effect

        with pytest.raises(GitError, match="Could not resolve PR ref"):
            get_pr_changed_files(Path("/tmp/test"), pr_number=999)

    @patch("python_checkup.diff._run_git")
    def test_detects_develop_base(self, mock_git: object) -> None:
        """Base detection picks the branch with the smallest distance."""
        call_count = {"merge_base": 0}

        def side_effect(args: list[str], cwd: Path) -> str:
            cmd = args[0]
            if cmd == "rev-parse":
                if args[1] == "--git-dir":
                    return ".git"
                if args[1] == "--verify":
                    # Both main and develop exist
                    return "abc"
                return "def456"
            if cmd == "fetch":
                return ""
            if cmd == "merge-base":
                call_count["merge_base"] += 1
                return f"base{call_count['merge_base']}"
            if cmd == "rev-list":
                # main has distance 10, develop has distance 2
                if call_count["merge_base"] <= 1:
                    return "10"  # main
                return "2"  # develop (or master)
            if cmd == "diff":
                return "app.py\n"
            if cmd == "cat-file":
                return ""
            if cmd == "branch":
                return ""
            return ""

        cast(Any, mock_git).side_effect = side_effect

        files, base = get_pr_changed_files(Path("/tmp/test_project"), pr_number=5)
        # master has distance 2 which is less than main's 10
        assert base in ("master", "develop", "development")

    @patch("python_checkup.diff._run_git")
    def test_cleanup_runs_on_success(self, mock_git: object) -> None:
        """The temp branch ref is deleted after successful operation."""
        branch_deleted = {"called": False}

        def side_effect(args: list[str], cwd: Path) -> str:
            cmd = args[0]
            if cmd == "rev-parse":
                if args[1] == "--git-dir":
                    return ".git"
                if args[1] == "--verify":
                    if "main" in args[2]:
                        return "abc"
                    raise GitError("nope")
                return "def456"
            if cmd == "fetch":
                return ""
            if cmd == "merge-base":
                return "aaa"
            if cmd == "rev-list":
                return "1"
            if cmd == "diff":
                return ""
            if cmd == "branch" and args[1] == "-D":
                branch_deleted["called"] = True
                return ""
            return ""

        cast(Any, mock_git).side_effect = side_effect

        get_pr_changed_files(Path("/tmp/test"), pr_number=7)
        assert branch_deleted["called"]
