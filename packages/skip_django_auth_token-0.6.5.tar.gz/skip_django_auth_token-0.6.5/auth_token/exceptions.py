class KeyGeneratorError(Exception):
    pass
