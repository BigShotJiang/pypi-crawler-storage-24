"""
CPU Backend Wrapper for Crayon
================================

This module wraps the compiled C++ extension for CPU tokenization.
"""

import sys
import os
import importlib.util

def _load_cpu_extension():
    """Load the compiled CPU extension with platform-specific naming."""
    
    # Determine the extension filename based on platform
    if sys.platform == "win32":
        # Windows: look for .pyd files with version info
        ext_files = [f for f in os.listdir(os.path.dirname(__file__)) 
                   if f.startswith('crayon_cpu') and f.endswith('.pyd')]
        if ext_files:
            ext_file = ext_files[0]  # Use the first one found
        else:
            raise ImportError("No compiled CPU extension found (.pyd file)")
    else:
        # Linux/macOS: look for .so files
        ext_files = [f for f in os.listdir(os.path.dirname(__file__)) 
                   if f.startswith('crayon_cpu') and f.endswith('.so')]
        if ext_files:
            ext_file = ext_files[0]
        else:
            raise ImportError("No compiled CPU extension found (.so file)")
    
    # Load the extension
    ext_path = os.path.join(os.path.dirname(__file__), ext_file)
    spec = importlib.util.spec_from_file_location('crayon_cpu_ext', ext_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load extension from {ext_path}")
    
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

# Load the extension
try:
    _cpu_ext = _load_cpu_extension()
except ImportError as e:
    raise ImportError(
        f"Failed to import CPU extension: {e}\n"
        "This suggests the C++ extension was not compiled correctly.\n"
        "Try reinstalling with: pip install --force-reinstall xerv-crayon"
    )

# Export the required functions
tokenize = _cpu_ext.tokenize
load_dat = _cpu_ext.load_dat

# Export hardware info if available
if hasattr(_cpu_ext, 'get_hardware_info'):
    get_hardware_info = _cpu_ext.get_hardware_info
else:
    def get_hardware_info():
        return "CPU Backend [Standard]"

__all__ = ['tokenize', 'load_dat', 'get_hardware_info']
