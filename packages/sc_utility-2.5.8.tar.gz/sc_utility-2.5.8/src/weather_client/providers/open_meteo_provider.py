"""WeatherClient provider for Open-Meteo weather API.

Open-Meteo is a free, open-source weather API that provides comprehensive weather data
without requiring an API key. It offers current conditions, hourly forecasts, and daily
forecasts with a wide range of meteorological variables.

Documentation: https://open-meteo.com/en/docs
"""
from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

import requests

from weather_client.models import (
    SkyCondition,
    Temperature,
    WeatherData,
    WeatherReading,
    WeatherStation,
    Wind,
)

# WMO Weather interpretation codes (WW)
# https://open-meteo.com/en/docs
_WEATHER_CODE_MAP: dict[int, tuple[str, str]] = {
    0: ("Clear sky", "clear"),
    1: ("Mainly clear", "mainly clear"),
    2: ("Partly cloudy", "partly cloudy"),
    3: ("Overcast", "overcast"),
    45: ("Fog", "fog"),
    48: ("Depositing rime fog", "fog"),
    51: ("Light drizzle", "drizzle"),
    53: ("Moderate drizzle", "drizzle"),
    55: ("Dense drizzle", "drizzle"),
    56: ("Light freezing drizzle", "drizzle"),
    57: ("Dense freezing drizzle", "drizzle"),
    61: ("Slight rain", "rain"),
    63: ("Moderate rain", "rain"),
    65: ("Heavy rain", "heavy rain"),
    66: ("Light freezing rain", "rain"),
    67: ("Heavy freezing rain", "heavy rain"),
    71: ("Slight snow", "snow"),
    73: ("Moderate snow", "snow"),
    75: ("Heavy snow", "snow"),
    77: ("Snow grains", "snow"),
    80: ("Slight rain showers", "shower rain"),
    81: ("Moderate rain showers", "shower rain"),
    82: ("Violent rain showers", "shower rain"),
    85: ("Slight snow showers", "snow"),
    86: ("Heavy snow showers", "snow"),
    95: ("Thunderstorm", "thunderstorm"),
    96: ("Thunderstorm with slight hail", "thunderstorm"),
    99: ("Thunderstorm with heavy hail", "thunderstorm"),
}

_SKY_ICONS: list[tuple[str, str]] = [
    # Exact / most-specific first
    ("thunderstorm", "⛈️"),
    ("heavy rain", "🌧️"),
    ("shower rain", "🌧️"),
    ("rain", "🌧️"),
    ("drizzle", "🌦️"),
    ("snow", "❄️"),
    ("sleet", "🌨️"),
    ("fog", "🌫️"),
    ("mist", "🌫️"),
    ("haze", "🌫️"),
    ("smoke", "🌫️"),
    ("sand", "🌫️"),
    ("dust", "🌫️"),
    ("overcast", "☁️"),
    ("broken clouds", "⛅"),
    ("scattered clouds", "⛅"),
    ("partly cloudy", "⛅"),
    ("few clouds", "🌤️"),
    ("mainly clear", "🌤️"),
    ("clear", "☀️"),
]

_COMPASS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
            "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]


class OpenMeteoProvider:
    """Provider for Open-Meteo weather API."""

    def fetch(self, lat: float, lon: float) -> WeatherData:
        """Fetch weather data from Open-Meteo.

        Args:
            lat (float): Latitude of the location.
            lon (float): Longitude of the location.

        Returns:
            A WeatherData object containing the current reading, hourly and daily forecasts, and weather station info.
        """
        url = self._build_api_url(lat, lon)
        data = self._fetch_api_data(url)

        local_tz = datetime.now().astimezone().tzinfo
        utc_now = datetime.now(UTC)
        time_now = datetime.now(tz=local_tz)

        current_reading = self._parse_current_weather(data, utc_now, time_now)
        hourly = self._parse_hourly_forecast(data, time_now)
        daily = self._parse_daily_forecast(data, time_now)

        # Update current reading's sunrise/sunset from daily data
        daily_data = data.get("daily", {})
        daily_sunrises = daily_data.get("sunrise", [])
        daily_sunsets = daily_data.get("sunset", [])
        if daily_data and daily_sunrises and daily_sunsets:
            sunrise_str = daily_sunrises[0] if daily_sunrises else None
            sunset_str = daily_sunsets[0] if daily_sunsets else None
            current_reading.sunrise = datetime.fromisoformat(sunrise_str).astimezone() if sunrise_str else None
            current_reading.sunset = datetime.fromisoformat(sunset_str).astimezone() if sunset_str else None

        # Loop through the hourly records and set sunrise and sunset for any that match the daily sunrise/sunset times
        for hour in hourly:
            hour.sunrise = current_reading.sunrise
            hour.sunset = current_reading.sunset

        station = WeatherStation(
            source="Open-Meteo",
            latitude=data.get("latitude", lat),
            longitude=data.get("longitude", lon),
            timezone_name=data.get("timezone"),
            timezone_offset=data.get("utc_offset_seconds"),
        )

        return WeatherData(
            current=current_reading,
            hourly=hourly,
            daily=daily,
            station=station,
            as_at=datetime.now(tz=local_tz),
        )

    @staticmethod
    def _build_api_url(lat: float, lon: float) -> str:
        """Build the Open-Meteo API URL with all required parameters.

        Args:
            lat (float): Latitude of the location.
            lon (float): Longitude of the location.

        Returns:
            str: The complete API URL.
        """
        current_params = [
            "temperature_2m",
            "relative_humidity_2m",
            "apparent_temperature",
            "precipitation",
            "rain",
            "weather_code",
            "cloud_cover",
            "pressure_msl",
            "surface_pressure",
            "wind_speed_10m",
            "wind_direction_10m",
            "wind_gusts_10m",
        ]

        hourly_params = [
            "temperature_2m",
            "relative_humidity_2m",
            "apparent_temperature",
            "precipitation_probability",
            "precipitation",
            "rain",
            "weather_code",
            "pressure_msl",
            "cloud_cover",
            "visibility",
            "wind_speed_10m",
            "wind_direction_10m",
            "wind_gusts_10m",
            "dew_point_2m",
            "uv_index",
        ]

        daily_params = [
            "weather_code",
            "temperature_2m_max",
            "temperature_2m_min",
            "apparent_temperature_max",
            "apparent_temperature_min",
            "sunrise",
            "sunset",
            "precipitation_sum",
            "rain_sum",
            "precipitation_probability_max",
            "wind_speed_10m_max",
            "wind_gusts_10m_max",
            "wind_direction_10m_dominant",
        ]

        return (
            "https://api.open-meteo.com/v1/forecast"
            f"?latitude={lat}&longitude={lon}"
            f"&current={','.join(current_params)}"
            f"&hourly={','.join(hourly_params)}"
            f"&daily={','.join(daily_params)}"
            "&temperature_unit=celsius"
            "&wind_speed_unit=kmh"
            "&precipitation_unit=mm"
            "&timezone=auto"
        )

    @staticmethod
    def _fetch_api_data(url: str) -> dict[str, Any]:
        """Fetch data from the Open-Meteo API.

        Args:
            url (str): The API URL to fetch from.

        Raises:
            RuntimeError: If the API request fails.

        Returns:
            dict[str, Any]: The parsed JSON response.
        """
        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            error_msg = f"HTTP error accessing Open-Meteo API: {e}"
            raise RuntimeError(error_msg) from e
        except requests.exceptions.RequestException as e:
            error_msg = f"Open-Meteo request failed: {e}"
            raise RuntimeError(error_msg) from e

    def _parse_current_weather(self, data: dict[str, Any], utc_now: datetime, time_now: datetime) -> WeatherReading:
        """Parse current weather data from API response.

        Args:
            data (dict[str, Any]): The API response data.
            utc_now (datetime): Current UTC time.
            time_now (datetime): Current local time.

        Returns:
            WeatherReading: The current weather reading.
        """
        current_data = data.get("current", {})
        current_time_str = current_data.get("time")
        if current_time_str:
            local_time = datetime.fromisoformat(current_time_str).replace(tzinfo=time_now.tzinfo)
            utc_time = local_time.astimezone(UTC)
        else:
            utc_time = utc_now
            local_time = time_now

        # Get daily data for current day's high/low
        daily_data = data.get("daily", {})
        today_max = None
        today_min = None
        if daily_data and daily_data.get("time"):
            today_max = daily_data.get("temperature_2m_max", [None])[0]
            today_min = daily_data.get("temperature_2m_min", [None])[0]

        weather_code = current_data.get("weather_code", 0)
        title, description_key = _WEATHER_CODE_MAP.get(weather_code, ("Unknown", "unknown"))

        current_sky = SkyCondition(
            title=title,
            description=title,
            icon=self._sky_to_icon(description_key),
            icon_code=str(weather_code),
            icon_png_url=None,
            cloud_cover=current_data.get("cloud_cover") / 100 if current_data.get("cloud_cover") is not None else None,
            visibility=None,
            uv_index=None,
        )

        return WeatherReading(
            utc_time=utc_time,
            local_time=local_time,
            temperature=Temperature(
                reading=current_data.get("temperature_2m") or 0.0,
                high=today_max,
                low=today_min,
                feels_like=current_data.get("apparent_temperature"),
            ),
            sky=current_sky,
            wind=Wind(
                speed=current_data.get("wind_speed_10m") or 0.0,
                deg=current_data.get("wind_direction_10m"),
                direction=self._deg_to_compass(current_data.get("wind_direction_10m")),
                gust=current_data.get("wind_gusts_10m"),
            ),
            summary=title,
            precip_probability=None,
            rain=current_data.get("rain"),
            pressure=current_data.get("pressure_msl"),
            humidity=current_data.get("relative_humidity_2m") / 100 if current_data.get("relative_humidity_2m") is not None else None,
            dew_point=None,
            sunrise=None,
            sunset=None,
        )

    def _parse_hourly_forecast(self, data: dict[str, Any], time_now: datetime) -> list[WeatherReading]:
        """Parse hourly forecast data from API response.

        Args:
            data (dict[str, Any]): The API response data.
            time_now (datetime): Current local time.

        Returns:
            list[WeatherReading]: List of hourly weather readings.
        """
        hourly: list[WeatherReading] = []
        hourly_data = data.get("hourly", {})
        hourly_times = hourly_data.get("time", [])

        for i, time_str in enumerate(hourly_times):
            local_ts = datetime.fromisoformat(time_str).replace(tzinfo=time_now.tzinfo)
            if local_ts < time_now:
                continue

            utc_ts = local_ts.astimezone(UTC)
            hour_weather_code = self._get_index(hourly_data.get("weather_code"), i) or 0
            hour_title, hour_desc_key = _WEATHER_CODE_MAP.get(hour_weather_code, ("Unknown", "unknown"))

            hour_sky = SkyCondition(
                title=hour_title,
                description=hour_title,
                icon=self._sky_to_icon(hour_desc_key),
                icon_code=str(hour_weather_code),
                icon_png_url=None,
                cloud_cover=self._get_index(hourly_data.get("cloud_cover"), i) / 100 if self._get_index(hourly_data.get("cloud_cover"), i) is not None else None,
                visibility=self._get_index(hourly_data.get("visibility"), i),
                uv_index=self._get_index(hourly_data.get("uv_index"), i) / 100 if self._get_index(hourly_data.get("uv_index"), i) is not None else None,
            )

            hourly.append(
                WeatherReading(
                    utc_time=utc_ts,
                    local_time=local_ts,
                    temperature=Temperature(
                        reading=self._get_index(hourly_data.get("temperature_2m"), i) or 0.0,
                        feels_like=self._get_index(hourly_data.get("apparent_temperature"), i),
                    ),
                    sky=hour_sky,
                    wind=Wind(
                        speed=self._get_index(hourly_data.get("wind_speed_10m"), i) or 0.0,
                        deg=self._get_index(hourly_data.get("wind_direction_10m"), i),
                        direction=self._deg_to_compass(self._get_index(hourly_data.get("wind_direction_10m"), i)),
                        gust=self._get_index(hourly_data.get("wind_gusts_10m"), i),
                    ),
                    summary=hour_title,
                    precip_probability=self._get_index(hourly_data.get("precipitation_probability"), i) / 100 if self._get_index(hourly_data.get("precipitation_probability"), i) is not None else None,
                    rain=self._get_index(hourly_data.get("rain"), i),
                    pressure=self._get_index(hourly_data.get("pressure_msl"), i),
                    humidity=self._get_index(hourly_data.get("relative_humidity_2m"), i) / 100 if self._get_index(hourly_data.get("relative_humidity_2m"), i) is not None else None,
                    dew_point=self._get_index(hourly_data.get("dew_point_2m"), i),
                    sunrise=None,
                    sunset=None,
                )
            )

        return hourly

    def _parse_daily_forecast(self, data: dict[str, Any], time_now: datetime) -> list[WeatherReading]:
        """Parse daily forecast data from API response.

        Args:
            data (dict[str, Any]): The API response data.
            time_now (datetime): Current local time.

        Returns:
            list[WeatherReading]: List of daily weather readings.
        """
        daily: list[WeatherReading] = []
        daily_data = data.get("daily", {})
        daily_times = daily_data.get("time", [])

        for i, date_str in enumerate(daily_times):
            local_ts = datetime.fromisoformat(date_str).replace(tzinfo=time_now.tzinfo)
            local_ts = local_ts.replace(hour=12, minute=0, second=0, microsecond=0, tzinfo=UTC)
            utc_ts = local_ts.astimezone(UTC)

            if local_ts.date() < time_now.date():
                continue

            reading = self._build_daily_reading(daily_data, i, utc_ts, local_ts)
            daily.append(reading)

        return daily

    def _build_daily_reading(
        self,
        daily_data: dict[str, Any],
        index: int,
        utc_ts: datetime,
        local_ts: datetime,
    ) -> WeatherReading:
        """Build a single daily WeatherReading from data.

        Args:
            daily_data (dict[str, Any]): The daily forecast data.
            index (int): The index in the daily data arrays.
            utc_ts (datetime): UTC timestamp for this reading.
            local_ts (datetime): Local timestamp for this reading.

        Returns:
            WeatherReading: The daily weather reading.
        """
        day_weather_code = self._get_index(daily_data.get("weather_code"), index) or 0
        day_title, day_desc_key = _WEATHER_CODE_MAP.get(day_weather_code, ("Unknown", "unknown"))

        day_sky = SkyCondition(
            title=day_title,
            description=day_title,
            icon=self._sky_to_icon(day_desc_key),
            icon_code=str(day_weather_code),
            icon_png_url=None,
            cloud_cover=None,
            visibility=None,
            uv_index=None,
        )

        sunrise_str = self._get_index(daily_data.get("sunrise", []), index)
        sunset_str = self._get_index(daily_data.get("sunset", []), index)
        sunrise = datetime.fromisoformat(sunrise_str).astimezone() if sunrise_str else None
        sunset = datetime.fromisoformat(sunset_str).astimezone() if sunset_str else None

        temp_max = self._get_index(daily_data.get("temperature_2m_max"), index)
        temp_min = self._get_index(daily_data.get("temperature_2m_min"), index)
        temp_avg = ((temp_max or 0) + (temp_min or 0)) / 2 if temp_max is not None and temp_min is not None else None

        apparent_max = self._get_index(daily_data.get("apparent_temperature_max"), index) or 0
        apparent_min = self._get_index(daily_data.get("apparent_temperature_min"), index) or 0
        feels_like_avg = (apparent_max + apparent_min) / 2 if apparent_max or apparent_min else None

        return WeatherReading(
            utc_time=utc_ts,
            local_time=local_ts,
            temperature=Temperature(
                reading=temp_avg or 0.0,
                high=temp_max,
                low=temp_min,
                feels_like=feels_like_avg,
            ),
            sky=day_sky,
            wind=Wind(
                speed=self._get_index(daily_data.get("wind_speed_10m_max"), index) or 0.0,
                deg=self._get_index(daily_data.get("wind_direction_10m_dominant"), index),
                direction=self._deg_to_compass(self._get_index(daily_data.get("wind_direction_10m_dominant"), index)),
                gust=self._get_index(daily_data.get("wind_gusts_10m_max"), index),
            ),
            summary=day_title,
            precip_probability=self._get_index(daily_data.get("precipitation_probability_max"), index) / 100 if self._get_index(daily_data.get("precipitation_probability_max"), index) is not None else None,
            rain=self._get_index(daily_data.get("rain_sum"), index),
            pressure=None,
            humidity=None,
            dew_point=None,
            sunrise=sunrise,
            sunset=sunset,
        )

    @staticmethod
    def _get_index(data: list | None, index: int) -> Any:
        """Safely get an item from a list by index.

        Args:
            data (list | None): The list to retrieve from.
            index (int): The index to retrieve.

        Returns:
            The item at the index if it exists, otherwise None.
        """
        if data is None or index >= len(data):
            return None
        return data[index]

    @staticmethod
    def _deg_to_compass(deg: float | None) -> str:
        """Convert wind direction in degrees to compass direction.

        Args:
            deg (float | None): Wind direction in degrees (0-360).

        Returns:
            str: Compass direction (e.g., "N", "NE", "E").
        """
        if deg is None:
            return ""
        return _COMPASS[round(deg / 22.5) % 16]

    @staticmethod
    def _sky_to_icon(sky: str) -> str:
        """Convert sky condition description to an emoji icon.

        Args:
            sky (str): Sky condition description.

        Returns:
            str: Emoji icon representing the sky condition.
        """
        sky_lower = sky.lower()
        for keyword, icon in _SKY_ICONS:
            if keyword in sky_lower:
                return icon
        return "🌡️"
