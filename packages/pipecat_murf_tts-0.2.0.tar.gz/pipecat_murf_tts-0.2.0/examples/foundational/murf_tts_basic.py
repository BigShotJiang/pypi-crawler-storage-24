import asyncio
import os
import sys

from dotenv import load_dotenv
from loguru import logger

from pipecat.audio.vad.silero import SileroVADAnalyzer
from pipecat.frames.frames import LLMMessagesAppendFrame, LLMRunFrame
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.runner import PipelineRunner
from pipecat.pipeline.task import PipelineParams, PipelineTask
from pipecat.processors.aggregators.llm_context import LLMContext
from pipecat.processors.aggregators.llm_response_universal import (
    LLMContextAggregatorPair,
    LLMUserAggregatorParams,
)
from pipecat.services.deepgram.stt import DeepgramSTTService
from pipecat.services.openai.llm import OpenAILLMService
from pipecat.transports.local.audio import (
    LocalAudioTransport,
    LocalAudioTransportParams,
)

from pipecat_murf_tts.tts import MurfTTSService

load_dotenv(override=True)

logger.remove(0)
logger.add(sys.stderr, level="DEBUG")


async def main():
    settings = {
        "murf_api_key": os.getenv("MURF_API_KEY"),
        "openai_api_key": os.getenv("OPENAI_API_KEY"),
        "deepgram_api_key": os.getenv("DEEPGRAM_API_KEY"),
    }

    # Validate that all required API keys are present
    missing_keys = [key for key, value in settings.items() if not value]
    if missing_keys:
        logger.error(f"Missing required API keys: {', '.join(missing_keys)}")
        logger.error("Please ensure all API keys are set in your .env file")
        sys.exit(1)

    logger.info("All API keys loaded successfully")

    transport = LocalAudioTransport(
        LocalAudioTransportParams(
            audio_in_enabled=True,
            audio_out_enabled=True,
        )
    )

    stt = DeepgramSTTService(api_key=settings["deepgram_api_key"])

    tts = MurfTTSService(
        api_key=settings["murf_api_key"],
        params=MurfTTSService.InputParams(
            voice_id="Matthew",
            style="Conversational",
            rate=0,
            pitch=0,
            variation=1,
            sample_rate=44100,
            channel_type="MONO",
            format="PCM",
        ),
    )

    llm = OpenAILLMService(api_key=settings["openai_api_key"])

    messages = [
        {
            "role": "system",
            "content": "You are a helpful LLM. Your goal is to demonstrate your capabilities in a succinct way. Your output will be converted to audio so don't include special characters in your answers. Respond to what the user said in a creative and helpful way.",
        },
    ]

    context = LLMContext(messages)
    context_aggregator = LLMContextAggregatorPair(
        context,
        user_params=LLMUserAggregatorParams(vad_analyzer=SileroVADAnalyzer()),
    )

    pipeline = Pipeline(
        [
            transport.input(),
            stt,
            context_aggregator.user(),
            llm,
            tts,
            transport.output(),
            context_aggregator.assistant(),
        ]
    )

    task = PipelineTask(
        pipeline,
        params=PipelineParams(
            enable_metrics=True,
            enable_usage_metrics=True,
        ),
    )

    await task.queue_frames(
        [
            LLMMessagesAppendFrame(
                messages=[
                    {
                        "role": "system",
                        "content": "Please introduce yourself to the user.",
                    }
                ]
            ),
            LLMRunFrame(),
        ]
    )

    runner = PipelineRunner()
    await runner.run(task)


if __name__ == "__main__":
    logger.info("Starting bot")
    asyncio.run(main())
