"""Tests for SDK resources with mocked HTTP responses."""
import pytest
import respx
import httpx

from foilengine import (
    FoilEngineClient,
    Persona,
    MachineInfo,
    SessionInit,
    ChatResponse,
    SessionStatus,
    ChatHistory,
    ResetResult,
    NotFoundError,
    AuthenticationError,
    RateLimitError,
    ForbiddenError,
)

BASE_URL = "http://localhost:8000"


@pytest.fixture
def client():
    c = FoilEngineClient(api_key="pk_live_test", base_url=BASE_URL, max_retries=0)
    yield c
    c.close()


# ============= Personas =============

@respx.mock
def test_list_personas(client):
    respx.get(f"{BASE_URL}/api/v1/sdk/personas").mock(
        return_value=httpx.Response(200, json=[
            {
                "id": "abc-123",
                "name": "Grumpy Barista",
                "description": "A coffee shop NPC",
                "created_at": "2026-03-10T12:00:00Z",
                "updated_at": "2026-03-10T12:00:00Z",
            }
        ])
    )
    personas = client.personas.list()
    assert len(personas) == 1
    assert isinstance(personas[0], Persona)
    assert personas[0].name == "Grumpy Barista"


@respx.mock
def test_list_personas_empty(client):
    respx.get(f"{BASE_URL}/api/v1/sdk/personas").mock(
        return_value=httpx.Response(200, json=[])
    )
    personas = client.personas.list()
    assert personas == []


# ============= Machines =============

@respx.mock
def test_list_machines(client):
    respx.get(f"{BASE_URL}/api/v1/sdk/chat/abc-123/machines").mock(
        return_value=httpx.Response(200, json=[
            {
                "machine_id": "m1",
                "machine_key": "opening",
                "name": "Opening Scene",
                "description": "First encounter",
                "has_session": True,
                "session_outcome": None,
                "is_linked": True,
            },
            {
                "machine_id": "m2",
                "machine_key": "side_quest",
                "name": "Side Quest",
                "description": None,
                "has_session": False,
                "session_outcome": None,
                "is_linked": False,
            },
        ])
    )
    machines = client.machines.list("abc-123", "player-001")
    assert len(machines) == 2
    assert isinstance(machines[0], MachineInfo)
    assert machines[0].is_linked is True
    assert machines[1].is_linked is False


# ============= Chat =============

@respx.mock
def test_init_session(client):
    respx.post(f"{BASE_URL}/api/v1/sdk/chat/abc-123/init-session").mock(
        return_value=httpx.Response(200, json={
            "session_id": "sess-1",
            "user_session_id": "player-001",
            "persona_name": "Grumpy Barista",
            "persona_description": "A coffee shop NPC",
            "player_name": "Alex",
            "player_gender": "non-binary",
            "message": "Welcome, Alex.",
            "machine_id": "m1",
        })
    )
    session = client.chat.init_session(
        persona_id="abc-123",
        user_session_id="player-001",
        player_name="Alex",
        player_gender="non-binary",
    )
    assert isinstance(session, SessionInit)
    assert session.message == "Welcome, Alex."
    assert session.persona_name == "Grumpy Barista"


@respx.mock
def test_send_message(client):
    respx.post(f"{BASE_URL}/api/v1/sdk/chat/abc-123/message").mock(
        return_value=httpx.Response(200, json={
            "message": "What do you want?",
            "current_state": "S1",
            "score": 5,
            "outcome": None,
            "decision": "pass",
            "follow_up": True,
            "session_id": "sess-1",
            "scoring_mode": "scoring",
            "redirect_count": 0,
            "machine_completed": False,
            "unlocked_machines": [],
        })
    )
    response = client.chat.send_message(
        persona_id="abc-123",
        message="Hello!",
        user_session_id="player-001",
    )
    assert isinstance(response, ChatResponse)
    assert response.message == "What do you want?"
    assert response.score == 5
    assert response.unlocked_machines == []


@respx.mock
def test_send_message_with_unlocked_machines(client):
    respx.post(f"{BASE_URL}/api/v1/sdk/chat/abc-123/message").mock(
        return_value=httpx.Response(200, json={
            "message": "Farewell.",
            "current_state": "S_END",
            "score": 20,
            "outcome": "ACCEPT",
            "decision": "pass",
            "follow_up": False,
            "session_id": "sess-1",
            "scoring_mode": "scoring",
            "machine_completed": True,
            "unlocked_machines": [
                {"machine_id": "m2", "machine_key": "chapter_2", "name": "Chapter 2", "is_auto_advance": False}
            ],
        })
    )
    response = client.chat.send_message(
        persona_id="abc-123",
        message="I accept your offer.",
        user_session_id="player-001",
    )
    assert response.machine_completed is True
    assert len(response.unlocked_machines) == 1
    assert response.unlocked_machines[0].machine_key == "chapter_2"


@respx.mock
def test_get_session(client):
    respx.get(f"{BASE_URL}/api/v1/sdk/chat/abc-123/session").mock(
        return_value=httpx.Response(200, json={
            "session_id": "sess-1",
            "persona_id": "abc-123",
            "machine_id": "m1",
            "current_state": "S1",
            "score": 10,
            "outcome": None,
            "player_name": "Alex",
            "player_gender": "non-binary",
            "started_at": "2026-03-10T12:00:00Z",
            "last_message_at": "2026-03-10T12:05:00Z",
        })
    )
    status = client.chat.get_session("abc-123", "player-001")
    assert isinstance(status, SessionStatus)
    assert status.score == 10


@respx.mock
def test_get_session_not_found(client):
    respx.get(f"{BASE_URL}/api/v1/sdk/chat/abc-123/session").mock(
        return_value=httpx.Response(404, json={"error": {"message": "No active session found"}})
    )
    with pytest.raises(NotFoundError):
        client.chat.get_session("abc-123", "nonexistent")


@respx.mock
def test_get_history(client):
    respx.get(f"{BASE_URL}/api/v1/sdk/chat/abc-123/history").mock(
        return_value=httpx.Response(200, json={
            "session_id": "sess-1",
            "persona_id": "abc-123",
            "messages": [
                {
                    "id": "msg-1",
                    "role": "assistant",
                    "content": "Hello!",
                    "state_key_at_time": "S0",
                    "score_at_time": 0,
                    "decision": None,
                    "follow_up_triggered": False,
                    "created_at": "2026-03-10T12:00:00Z",
                }
            ],
            "current_state": "S0",
            "score": 0,
            "outcome": None,
            "player_name": "Alex",
            "player_gender": "non-binary",
            "started_at": "2026-03-10T12:00:00Z",
            "last_message_at": "2026-03-10T12:00:00Z",
        })
    )
    history = client.chat.get_history("abc-123", "player-001")
    assert isinstance(history, ChatHistory)
    assert len(history.messages) == 1
    assert history.messages[0].role == "assistant"


@respx.mock
def test_reset_session(client):
    respx.post(f"{BASE_URL}/api/v1/sdk/chat/abc-123/reset").mock(
        return_value=httpx.Response(200, json={
            "session_id": "player-001",
            "message": "Conversation reset successfully",
        })
    )
    result = client.chat.reset("abc-123", "player-001")
    assert isinstance(result, ResetResult)
    assert "reset" in result.message.lower()


# ============= Error handling =============

@respx.mock
def test_auth_error(client):
    respx.get(f"{BASE_URL}/api/v1/sdk/personas").mock(
        return_value=httpx.Response(401, json={"error": {"message": "Invalid API key"}})
    )
    with pytest.raises(AuthenticationError) as exc_info:
        client.personas.list()
    assert exc_info.value.status_code == 401


@respx.mock
def test_forbidden_error(client):
    respx.post(f"{BASE_URL}/api/v1/sdk/chat/abc-123/init-session").mock(
        return_value=httpx.Response(403, json={"error": {"message": "API key does not have access"}})
    )
    with pytest.raises(ForbiddenError):
        client.chat.init_session("abc-123", "player-001", "Alex", "non-binary")


@respx.mock
def test_rate_limit_error(client):
    respx.get(f"{BASE_URL}/api/v1/sdk/personas").mock(
        return_value=httpx.Response(429, json={"error": {"message": "Rate limit exceeded"}}, headers={"Retry-After": "5"})
    )
    with pytest.raises(RateLimitError) as exc_info:
        client.personas.list()
    assert exc_info.value.retry_after == 5.0
