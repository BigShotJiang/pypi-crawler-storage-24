"""Tests for error classes."""
from foilengine.errors import (
    FoilEngineError,
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    BadRequestError,
    RateLimitError,
    ServerError,
    STATUS_CODE_TO_ERROR,
)


def test_error_hierarchy():
    """All errors should inherit from FoilEngineError."""
    for error_class in STATUS_CODE_TO_ERROR.values():
        assert issubclass(error_class, FoilEngineError)


def test_error_status_codes():
    assert AuthenticationError().status_code == 401
    assert ForbiddenError().status_code == 403
    assert NotFoundError().status_code == 404
    assert BadRequestError().status_code == 400
    assert RateLimitError().status_code == 429
    assert ServerError().status_code == 500


def test_rate_limit_error_retry_after():
    err = RateLimitError(retry_after=5.0)
    assert err.retry_after == 5.0


def test_error_message():
    err = NotFoundError("Persona not found")
    assert str(err) == "Persona not found"
    assert err.message == "Persona not found"


def test_status_code_mapping():
    assert STATUS_CODE_TO_ERROR[400] == BadRequestError
    assert STATUS_CODE_TO_ERROR[401] == AuthenticationError
    assert STATUS_CODE_TO_ERROR[403] == ForbiddenError
    assert STATUS_CODE_TO_ERROR[404] == NotFoundError
    assert STATUS_CODE_TO_ERROR[429] == RateLimitError
    assert STATUS_CODE_TO_ERROR[500] == ServerError
