"""Tests for FoilEngineClient initialization and resource access."""
import pytest
from foilengine import FoilEngineClient, AsyncFoilEngineClient


def test_client_has_resources():
    client = FoilEngineClient(api_key="pk_live_test", base_url="http://localhost:8000")
    assert hasattr(client, "personas")
    assert hasattr(client, "machines")
    assert hasattr(client, "chat")
    client.close()


def test_client_context_manager():
    with FoilEngineClient(api_key="pk_live_test", base_url="http://localhost:8000") as client:
        assert client.personas is not None


@pytest.mark.asyncio
async def test_async_client_context_manager():
    async with AsyncFoilEngineClient(api_key="pk_live_test", base_url="http://localhost:8000") as client:
        assert client.personas is not None
