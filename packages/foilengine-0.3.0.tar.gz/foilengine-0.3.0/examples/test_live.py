"""
Integration test script for the Foil Engine Python SDK.

Exercises the full SDK flow against a live API:
  list personas → init session → send message → get session → get history → list machines → reset

Usage:
  FOILENGINE_API_KEY=pk_live_... python examples/test_live.py
  FOILENGINE_API_KEY=pk_live_... FOILENGINE_BASE_URL=http://localhost:8000 python examples/test_live.py
"""

import os
import sys
from uuid import uuid4
from foilengine import FoilEngineClient

api_key = os.environ.get("FOILENGINE_API_KEY")
if not api_key:
    print("ERROR: Set FOILENGINE_API_KEY environment variable")
    sys.exit(1)

base_url = os.environ.get("FOILENGINE_BASE_URL", "https://api.foilengine.io")
session_id = f"test-{uuid4().hex[:8]}"

client = FoilEngineClient(api_key=api_key, base_url=base_url)

print(f"Base URL: {base_url}")
print(f"Session ID: {session_id}")
print()

# 1. List personas
print("=" * 50)
print("1. Listing personas...")
personas = client.personas.list()
print(f"   Found {len(personas)} persona(s)")
if not personas:
    print("   ERROR: No published personas found. Publish a persona first.")
    sys.exit(1)

persona = personas[0]
print(f"   Using: {persona.name} ({persona.id})")
print()

# 2. Init session
print("=" * 50)
print("2. Initializing session...")
session = client.chat.init_session(
    persona_id=persona.id,
    user_session_id=session_id,
    player_name="TestPlayer",
    player_gender="non-binary",
)
print(f"   Persona: {session.persona_name}")
print(f"   Greeting: {session.message[:100]}...")
print()

# 3. Send message
print("=" * 50)
print("3. Sending message: 'Hello! What can you tell me about yourself?'")
response = client.chat.send_message(
    persona_id=persona.id,
    message="Hello! What can you tell me about yourself?",
    user_session_id=session_id,
)
print(f"   Reply: {response.message[:100]}...")
print(f"   State: {response.current_state}")
print(f"   Score: {response.score}")
if response.outcome:
    print(f"   Outcome: {response.outcome}")
print()

# 4. Get session status
print("=" * 50)
print("4. Getting session status...")
status = client.chat.get_session(persona.id, session_id)
print(f"   Exists: {status.exists}")
print(f"   Score: {status.score}")
print(f"   State: {status.current_state}")
print()

# 5. Get history
print("=" * 50)
print("5. Getting chat history...")
history = client.chat.get_history(persona.id, session_id)
print(f"   Messages: {len(history.messages)}")
for msg in history.messages:
    role = msg.role.upper()
    text = msg.content[:80] if msg.content else "(empty)"
    print(f"   [{role}] {text}...")
print()

# 6. List machines
print("=" * 50)
print("6. Listing machines...")
machines = client.machines.list(persona.id, session_id)
print(f"   Found {len(machines)} machine(s)")
for m in machines:
    status_str = "active" if m.has_session else "available"
    linked = " (linked)" if m.is_linked else ""
    print(f"   - {m.name}: {status_str}{linked}")
print()

# 7. Reset session
print("=" * 50)
print("7. Resetting session...")
result = client.chat.reset(persona.id, session_id)
print(f"   Reset: {result.success}")
print()

print("=" * 50)
print("ALL TESTS PASSED")

client.close()
