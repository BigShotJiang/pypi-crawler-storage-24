"""
Response types for the Foil Engine SDK.

Uses dataclasses for zero external dependencies.
"""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Persona:
    """A published persona (NPC character)."""
    id: str
    name: str
    description: Optional[str]
    created_at: str
    updated_at: str


@dataclass
class MachineInfo:
    """A machine (scenario) available to a player."""
    machine_id: str
    machine_key: str
    name: str
    description: Optional[str]
    has_session: bool
    session_outcome: Optional[str]
    is_linked: bool


@dataclass
class SessionInit:
    """Response from initializing a chat session."""
    session_id: str
    user_session_id: str
    persona_name: str
    persona_description: Optional[str]
    player_name: str
    player_gender: str
    message: str
    machine_id: str


@dataclass
class UnlockedMachine:
    """A machine unlocked after completing a scenario."""
    machine_id: str
    machine_key: str
    name: str
    is_auto_advance: bool = False


@dataclass
class ChatResponse:
    """Response from sending a chat message."""
    message: str
    current_state: str
    score: int
    outcome: Optional[str]
    decision: Optional[str]
    follow_up: bool
    session_id: str
    scoring_mode: str = "scoring"
    redirect_count: Optional[int] = None
    machine_completed: bool = False
    unlocked_machines: list[UnlockedMachine] = field(default_factory=list)


@dataclass
class Message:
    """A single message in chat history."""
    id: str
    role: str
    content: str
    state_key_at_time: Optional[str]
    score_at_time: Optional[int]
    decision: Optional[str]
    follow_up_triggered: bool
    created_at: str


@dataclass
class ChatHistory:
    """Full chat history for a session."""
    session_id: str
    persona_id: str
    messages: list[Message]
    current_state: str
    score: int
    outcome: Optional[str]
    player_name: Optional[str]
    player_gender: Optional[str]
    started_at: str
    last_message_at: str


@dataclass
class SessionStatus:
    """Status of an existing session."""
    session_id: str
    persona_id: str
    machine_id: str
    current_state: str
    score: int
    outcome: Optional[str]
    player_name: Optional[str]
    player_gender: Optional[str]
    started_at: str
    last_message_at: str


@dataclass
class ResetResult:
    """Response from resetting a session."""
    session_id: str
    message: str
