"""Chat resource — manage sessions and send messages."""
from __future__ import annotations
from typing import Optional, Union

from foilengine._http import HttpClient, AsyncHttpClient
from foilengine.types import (
    SessionInit,
    ChatResponse,
    ChatHistory,
    SessionStatus,
    ResetResult,
    Message,
    UnlockedMachine,
)


def _require(value: str, name: str) -> None:
    """Raise ValueError if *value* is None, empty, or whitespace-only."""
    if not value or not value.strip():
        raise ValueError(f"{name} must not be empty")


def _parse_chat_response(data: dict) -> ChatResponse:
    unlocked = [UnlockedMachine(**u) for u in data.pop("unlocked_machines", [])]
    return ChatResponse(**data, unlocked_machines=unlocked)


def _parse_chat_history(data: dict) -> ChatHistory:
    messages = [Message(**m) for m in data.pop("messages", [])]
    return ChatHistory(**data, messages=messages)


class ChatResource:
    """Initialize sessions, send messages, and manage chat state."""

    def __init__(self, http: Union[HttpClient, AsyncHttpClient]):
        self._http = http

    # --- Sync methods ---

    def init_session(
        self,
        persona_id: str,
        user_session_id: str,
        player_name: str,
        player_gender: str,
        machine_id: Optional[str] = None,
    ) -> SessionInit:
        """Initialize a new chat session with a persona."""
        _require(persona_id, "persona_id")
        _require(user_session_id, "user_session_id")
        _require(player_name, "player_name")
        _require(player_gender, "player_gender")
        params = {"machine_id": machine_id} if machine_id else None
        data = self._http.post(
            f"/api/v1/sdk/chat/{persona_id}/init-session",
            json={
                "user_session_id": user_session_id,
                "player_name": player_name,
                "player_gender": player_gender,
            },
            params=params,
        )
        return SessionInit(**data)

    def send_message(
        self,
        persona_id: str,
        message: str,
        user_session_id: str,
        machine_id: Optional[str] = None,
    ) -> ChatResponse:
        """Send a player message and get the NPC response."""
        _require(persona_id, "persona_id")
        _require(message, "message")
        _require(user_session_id, "user_session_id")
        params = {"machine_id": machine_id} if machine_id else None
        data = self._http.post(
            f"/api/v1/sdk/chat/{persona_id}/message",
            json={
                "message": message,
                "user_session_id": user_session_id,
            },
            params=params,
        )
        return _parse_chat_response(data)

    def get_session(
        self,
        persona_id: str,
        user_session_id: str,
        machine_id: Optional[str] = None,
    ) -> SessionStatus:
        """Check if a player session exists and get its status."""
        _require(persona_id, "persona_id")
        _require(user_session_id, "user_session_id")
        params: dict = {"user_session_id": user_session_id}
        if machine_id:
            params["machine_id"] = machine_id
        data = self._http.get(
            f"/api/v1/sdk/chat/{persona_id}/session",
            params=params,
        )
        return SessionStatus(**data)

    def get_history(
        self,
        persona_id: str,
        user_session_id: str,
        machine_id: Optional[str] = None,
    ) -> ChatHistory:
        """Get full message history for a session."""
        _require(persona_id, "persona_id")
        _require(user_session_id, "user_session_id")
        params: dict = {"user_session_id": user_session_id}
        if machine_id:
            params["machine_id"] = machine_id
        data = self._http.get(
            f"/api/v1/sdk/chat/{persona_id}/history",
            params=params,
        )
        return _parse_chat_history(data)

    def reset(
        self,
        persona_id: str,
        user_session_id: str,
        machine_id: Optional[str] = None,
    ) -> ResetResult:
        """Reset/delete a chat session."""
        _require(persona_id, "persona_id")
        _require(user_session_id, "user_session_id")
        params: dict = {"user_session_id": user_session_id}
        if machine_id:
            params["machine_id"] = machine_id
        data = self._http.post(
            f"/api/v1/sdk/chat/{persona_id}/reset",
            params=params,
        )
        return ResetResult(**data)

    # --- Async methods ---

    async def init_session_async(
        self,
        persona_id: str,
        user_session_id: str,
        player_name: str,
        player_gender: str,
        machine_id: Optional[str] = None,
    ) -> SessionInit:
        """Initialize a new chat session with a persona (async)."""
        _require(persona_id, "persona_id")
        _require(user_session_id, "user_session_id")
        _require(player_name, "player_name")
        _require(player_gender, "player_gender")
        params = {"machine_id": machine_id} if machine_id else None
        data = await self._http.post(
            f"/api/v1/sdk/chat/{persona_id}/init-session",
            json={
                "user_session_id": user_session_id,
                "player_name": player_name,
                "player_gender": player_gender,
            },
            params=params,
        )
        return SessionInit(**data)

    async def send_message_async(
        self,
        persona_id: str,
        message: str,
        user_session_id: str,
        machine_id: Optional[str] = None,
    ) -> ChatResponse:
        """Send a player message and get the NPC response (async)."""
        _require(persona_id, "persona_id")
        _require(message, "message")
        _require(user_session_id, "user_session_id")
        params = {"machine_id": machine_id} if machine_id else None
        data = await self._http.post(
            f"/api/v1/sdk/chat/{persona_id}/message",
            json={
                "message": message,
                "user_session_id": user_session_id,
            },
            params=params,
        )
        return _parse_chat_response(data)

    async def get_session_async(
        self,
        persona_id: str,
        user_session_id: str,
        machine_id: Optional[str] = None,
    ) -> SessionStatus:
        """Check if a player session exists (async)."""
        _require(persona_id, "persona_id")
        _require(user_session_id, "user_session_id")
        params: dict = {"user_session_id": user_session_id}
        if machine_id:
            params["machine_id"] = machine_id
        data = await self._http.get(
            f"/api/v1/sdk/chat/{persona_id}/session",
            params=params,
        )
        return SessionStatus(**data)

    async def get_history_async(
        self,
        persona_id: str,
        user_session_id: str,
        machine_id: Optional[str] = None,
    ) -> ChatHistory:
        """Get full message history for a session (async)."""
        _require(persona_id, "persona_id")
        _require(user_session_id, "user_session_id")
        params: dict = {"user_session_id": user_session_id}
        if machine_id:
            params["machine_id"] = machine_id
        data = await self._http.get(
            f"/api/v1/sdk/chat/{persona_id}/history",
            params=params,
        )
        return _parse_chat_history(data)

    async def reset_async(
        self,
        persona_id: str,
        user_session_id: str,
        machine_id: Optional[str] = None,
    ) -> ResetResult:
        """Reset/delete a chat session (async)."""
        _require(persona_id, "persona_id")
        _require(user_session_id, "user_session_id")
        params: dict = {"user_session_id": user_session_id}
        if machine_id:
            params["machine_id"] = machine_id
        data = await self._http.post(
            f"/api/v1/sdk/chat/{persona_id}/reset",
            params=params,
        )
        return ResetResult(**data)
