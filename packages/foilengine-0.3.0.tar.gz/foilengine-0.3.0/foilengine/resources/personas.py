"""Personas resource — discover published personas."""
from __future__ import annotations
import time
from typing import Union, List

from foilengine._http import HttpClient, AsyncHttpClient
from foilengine.types import Persona


class PersonasResource:
    """List published personas owned by your API key."""

    def __init__(self, http: Union[HttpClient, AsyncHttpClient], cache_ttl: float = 60):
        self._http = http
        self._cache_ttl = cache_ttl
        self._cache: list[Persona] | None = None
        self._cache_time: float = 0.0

    def list(self) -> list[Persona]:
        """List all published personas."""
        if self._cache_ttl > 0 and self._cache is not None and time.time() - self._cache_time < self._cache_ttl:
            return self._cache
        data = self._http.get("/api/v1/sdk/personas")
        result = [Persona(**p) for p in data]
        self._cache = result
        self._cache_time = time.time()
        return result

    async def list_async(self) -> list[Persona]:
        """List all published personas (async)."""
        if self._cache_ttl > 0 and self._cache is not None and time.time() - self._cache_time < self._cache_ttl:
            return self._cache
        data = await self._http.get("/api/v1/sdk/personas")
        result = [Persona(**p) for p in data]
        self._cache = result
        self._cache_time = time.time()
        return result
