"""
Main client for the Foil Engine SDK.

Usage:
    from foilengine import FoilEngineClient

    client = FoilEngineClient(api_key="pk_live_...")
    personas = client.personas.list()
"""
from typing import Optional
from foilengine._http import HttpClient, AsyncHttpClient, DEFAULT_BASE_URL, DEFAULT_TIMEOUT, DEFAULT_MAX_RETRIES
from foilengine.resources import PersonasResource, MachinesResource, ChatResource


class FoilEngineClient:
    """Synchronous Foil Engine API client."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        llm_api_key: Optional[str] = None,
        llm_model: Optional[str] = None,
        llm_eval_model: Optional[str] = None,
        llm_response_model: Optional[str] = None,
        llm_summarization_model: Optional[str] = None,
        llm_eval_api_key: Optional[str] = None,
        llm_response_api_key: Optional[str] = None,
        llm_summarization_api_key: Optional[str] = None,
        debug: bool = False,
        cache_ttl: float = 60,
    ):
        self._http = HttpClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            llm_api_key=llm_api_key,
            llm_model=llm_model,
            llm_eval_model=llm_eval_model,
            llm_response_model=llm_response_model,
            llm_summarization_model=llm_summarization_model,
            llm_eval_api_key=llm_eval_api_key,
            llm_response_api_key=llm_response_api_key,
            llm_summarization_api_key=llm_summarization_api_key,
            debug=debug,
        )
        self.personas = PersonasResource(self._http, cache_ttl=cache_ttl)
        self.machines = MachinesResource(self._http)
        self.chat = ChatResource(self._http)

    def validate_llm_key(self, model: Optional[str] = None) -> dict:
        """Validate that the configured LLM API key works."""
        body = {}
        if model:
            body["model"] = model
        return self._http.post("/api/v1/sdk/validate-llm-key", json=body)

    def close(self):
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class AsyncFoilEngineClient:
    """Async Foil Engine API client."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        llm_api_key: Optional[str] = None,
        llm_model: Optional[str] = None,
        llm_eval_model: Optional[str] = None,
        llm_response_model: Optional[str] = None,
        llm_summarization_model: Optional[str] = None,
        llm_eval_api_key: Optional[str] = None,
        llm_response_api_key: Optional[str] = None,
        llm_summarization_api_key: Optional[str] = None,
        debug: bool = False,
        cache_ttl: float = 60,
    ):
        self._http = AsyncHttpClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            llm_api_key=llm_api_key,
            llm_model=llm_model,
            llm_eval_model=llm_eval_model,
            llm_response_model=llm_response_model,
            llm_summarization_model=llm_summarization_model,
            llm_eval_api_key=llm_eval_api_key,
            llm_response_api_key=llm_response_api_key,
            llm_summarization_api_key=llm_summarization_api_key,
            debug=debug,
        )
        self.personas = PersonasResource(self._http, cache_ttl=cache_ttl)
        self.machines = MachinesResource(self._http)
        self.chat = ChatResource(self._http)

    async def validate_llm_key(self, model: Optional[str] = None) -> dict:
        """Validate that the configured LLM API key works."""
        body = {}
        if model:
            body["model"] = model
        return await self._http.post("/api/v1/sdk/validate-llm-key", json=body)

    async def close(self):
        """Close the underlying HTTP client."""
        await self._http.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
