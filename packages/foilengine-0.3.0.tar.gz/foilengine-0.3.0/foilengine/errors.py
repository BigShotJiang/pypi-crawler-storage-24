"""
Typed exceptions for the Foil Engine SDK.

Maps HTTP status codes to specific error classes for clean error handling.
"""


class FoilEngineError(Exception):
    """Base exception for all Foil Engine SDK errors."""

    def __init__(self, message: str, status_code: int | None = None):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class AuthenticationError(FoilEngineError):
    """Raised when the API key is missing or invalid (401)."""

    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, status_code=401)


class ForbiddenError(FoilEngineError):
    """Raised when access is denied (403). API key doesn't own the persona or persona is unpublished."""

    def __init__(self, message: str = "Access denied"):
        super().__init__(message, status_code=403)


class NotFoundError(FoilEngineError):
    """Raised when a resource is not found (404)."""

    def __init__(self, message: str = "Resource not found"):
        super().__init__(message, status_code=404)


class BadRequestError(FoilEngineError):
    """Raised for invalid requests (400). Bad UUID format, missing fields, etc."""

    def __init__(self, message: str = "Bad request"):
        super().__init__(message, status_code=400)


class RateLimitError(FoilEngineError):
    """Raised when rate limited (429). Includes retry_after if available."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: float | None = None):
        self.retry_after = retry_after
        super().__init__(message, status_code=429)


class ServerError(FoilEngineError):
    """Raised for server-side errors (5xx)."""

    def __init__(self, message: str = "Internal server error"):
        super().__init__(message, status_code=500)


STATUS_CODE_TO_ERROR: dict[int, type[FoilEngineError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    403: ForbiddenError,
    404: NotFoundError,
    429: RateLimitError,
    500: ServerError,
}
