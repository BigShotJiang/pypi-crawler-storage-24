"""
Foil Engine SDK — Python client for the Foil Engine NPC API.

Usage:
    from foilengine import FoilEngineClient

    client = FoilEngineClient(api_key="pk_live_...")
    personas = client.personas.list()
"""
from foilengine.client import FoilEngineClient, AsyncFoilEngineClient
from foilengine.errors import (
    FoilEngineError,
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    BadRequestError,
    RateLimitError,
    ServerError,
)
from foilengine.types import (
    Persona,
    MachineInfo,
    SessionInit,
    ChatResponse,
    ChatHistory,
    SessionStatus,
    ResetResult,
    Message,
    UnlockedMachine,
)

__all__ = [
    "FoilEngineClient",
    "AsyncFoilEngineClient",
    "FoilEngineError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "BadRequestError",
    "RateLimitError",
    "ServerError",
    "Persona",
    "MachineInfo",
    "SessionInit",
    "ChatResponse",
    "ChatHistory",
    "SessionStatus",
    "ResetResult",
    "Message",
    "UnlockedMachine",
]

__version__ = "0.1.0"
