# -*- coding: utf-8 -*-
"""Configuration module for AtendentePro library."""

from .settings import (
    AtendenteProConfig,
    AtendentProConfig,
    get_config,
    configure,
    RECOMMENDED_PROMPT_PREFIX,
    SINGLE_REPLY_INSTRUCTION,
    DEFAULT_MODEL,
)

__all__ = [
    "AtendenteProConfig",
    "AtendentProConfig",
    "get_config",
    "configure",
    "RECOMMENDED_PROMPT_PREFIX",
    "SINGLE_REPLY_INSTRUCTION",
    "DEFAULT_MODEL",
]

