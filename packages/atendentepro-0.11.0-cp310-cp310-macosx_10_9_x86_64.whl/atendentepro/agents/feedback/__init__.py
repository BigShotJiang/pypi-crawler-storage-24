# -*- coding: utf-8 -*-
from typing import Any

"""
Feedback Agent for AtendentePro.

Handles user feedback, questions, complaints, and suggestions through
a ticket-based system with email notifications.

This is a universal module for all customer service systems,
allowing users to:
- Register questions (duvidas)
- Send feedback
- File complaints (reclamacoes)
- Submit suggestions (sugestoes)
- Give compliments (elogios)
- Report problems

All tickets are tracked with unique protocol numbers and can be
configured with custom email templates per client.
"""

import sys as _sys

from .agent import create_feedback_agent, FeedbackAgent
from .storage import (
    Ticket,
    TicketType,
    TicketPriority,
    TicketStatus,
    configure_feedback_storage,
    _get_storage_path,
    _load_tickets_from_file,
    _save_tickets_to_file,
    _gerar_protocolo,
    _salvar_ticket,
    _buscar_ticket,
    _listar_tickets,
)
from .email import (
    SMTP_HOST,
    SMTP_PORT,
    SMTP_USER,
    SMTP_PASSWORD,
    SMTP_FROM,
    FEEDBACK_EMAIL_DESTINO,
    SMTP_CONFIGURED,
    _validar_email,
    _enviar_email,
    _gerar_email_confirmacao,
    _gerar_email_equipe,
)
from .tools import (
    criar_ticket,
    enviar_email_confirmacao,
    consultar_ticket,
    listar_meus_tickets,
    atualizar_ticket,
    FEEDBACK_TOOLS,
)

# Keep a reference to the storage submodule so that attribute reads/writes
# for mutable globals (_tickets_storage, _storage_path, _protocol_prefix,
# _allowed_ticket_types, _email_config) are proxied transparently.
# This preserves backward compatibility for code that does:
#     import atendentepro.agents.feedback as fb_module
#     fb_module._tickets_storage = {}
from . import storage as _storage_mod

# Names that should be proxied to/from the storage submodule
_STORAGE_PROXY_ATTRS = frozenset({
    "_tickets_storage",
    "_protocol_prefix",
    "_allowed_ticket_types",
    "_storage_path",
    "_email_config",
})


def __getattr__(name: str) -> Any:  # type: ignore[override]
    if name in _STORAGE_PROXY_ATTRS:
        return getattr(_storage_mod, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


# Override __setattr__ at the module level by installing a custom module class.
# This lets ``fb_module._tickets_storage = {}`` propagate to the storage submodule.

class _FeedbackPackageModule(type(_sys.modules[__name__])):  # type: ignore[misc]
    def __setattr__(self, name: str, value: object) -> None:
        if name in _STORAGE_PROXY_ATTRS:
            setattr(_storage_mod, name, value)
            return
        super().__setattr__(name, value)

    def __getattr__(self, name: str) -> Any:  # type: ignore[override]
        if name in _STORAGE_PROXY_ATTRS:
            return getattr(_storage_mod, name)
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


_sys.modules[__name__].__class__ = _FeedbackPackageModule


__all__ = [
    # Agent
    "create_feedback_agent",
    "FeedbackAgent",
    # Storage
    "Ticket",
    "TicketType",
    "TicketPriority",
    "TicketStatus",
    "configure_feedback_storage",
    # Email
    "SMTP_CONFIGURED",
    "FEEDBACK_EMAIL_DESTINO",
    # Tools
    "FEEDBACK_TOOLS",
    "criar_ticket",
    "enviar_email_confirmacao",
    "consultar_ticket",
    "listar_meus_tickets",
    "atualizar_ticket",
]
