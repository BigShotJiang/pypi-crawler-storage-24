# AiPayGen MCP Server

**85+ AI-powered tools for Claude, Cursor, Windsurf, and any MCP-compatible AI agent.**

Research, write, code, translate, analyze, scrape the web, store agent memory, and more — all through a single MCP server.

## Quick Start

```bash
pip install aipaygen-mcp
```

### Claude Desktop

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "aipaygen": {
      "command": "aipaygen-mcp"
    }
  }
}
```

### Claude Code

```bash
claude mcp add aipaygen -- aipaygen-mcp
```

### Cursor / Windsurf

Add to your MCP config:

```json
{
  "aipaygen": {
    "command": "aipaygen-mcp"
  }
}
```

## What You Get

| Category | Tools |
|----------|-------|
| **AI Writing** | research, write, summarize, translate, rewrite, proofread, email, headline, social |
| **AI Analysis** | analyze, sentiment, classify, compare, score, fact, keywords, extract, tag |
| **AI Code** | code, sql, regex, test_cases, json_schema, mock |
| **AI Reasoning** | plan, decide, explain, debate, outline, questions, action, timeline, pitch |
| **Advanced AI** | vision (image analysis), rag (document Q&A), diagram, workflow, pipeline, chat |
| **Web Scraping** | Google Maps, Twitter/X, Instagram, TikTok, YouTube, any website |
| **Data** | weather, crypto prices, exchange rates, holidays, web search |
| **Agent Memory** | store, recall, search, list — persistent memory across sessions |
| **Marketplace** | list services, post your own agent services for others to discover |

## Pricing Tiers

| Tier | Price/Call | Examples |
|------|-----------|----------|
| free | $0.00 | health check, discovery |
| standard | $0.002 | sentiment, keywords, classify |
| ai | $0.006 | research, summarize, analyze, write |
| scraping | $0.01 | web scraping, social media data |
| ai_heavy | $0.02 | deep analysis, multi-step reasoning |

**Free tier:** 10 calls/day without API key.
**API key:** Unlimited calls, starting at $5. Get one at https://aipaygen.com/buy-credits

## API Key (Optional)

Free tier gives you 10 calls/day with no key needed.

For unlimited access, set your API key:

```bash
export AIPAYGEN_API_KEY="apk_your_key_here"
```

Get a key at [api.aipaygen.com/buy-credits](https://api.aipaygen.com/buy-credits) — plans start at $5.

## How It Works

AiPayGen acts as middleware between your AI agent and powerful APIs:

```
Your AI Agent (Claude/Cursor/etc.)
    ↓ MCP protocol
AiPayGen MCP Server (this package)
    ↓ HTTPS
api.aipaygen.com (85+ endpoints)
    ↓
Claude, GPT-4, web APIs, scrapers, etc.
```

Your agent gets instant access to research, writing, code generation, web scraping, and more — without managing API keys for each service individually.

## Links

- **API Docs**: [api.aipaygen.com/discover](https://api.aipaygen.com/discover)
- **GitHub**: [github.com/djautomd-lab/aipaygen](https://github.com/djautomd-lab/aipaygen)
- **Buy Credits**: [api.aipaygen.com/buy-credits](https://api.aipaygen.com/buy-credits)

## License

MIT

<!-- mcp-name: io.github.djautomd-lab/aipaygen -->
