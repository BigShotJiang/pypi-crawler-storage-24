import os
import geopandas as gpd
from typing import Optional

from .project_initialization import setup_project


class clip_flowlines:
    """
    A class to clip target flowlines by either a provided boundary polygon
    or the envelope of join flowlines.

    Attributes:
    -----------
    join_fl : str
        Path to join flowlines (can be GPKG, GDB, or Shapefile).
    target_fl : str
        Path to target flowlines to clip (can be GPKG, GDB, or Shapefile).
    output_clip : str
        GeoPackage path where the clipped result will be written.
    join_fl_layer : Optional[str]
        Layer name inside join_fl (if GPKG or GDB).
    target_fl_layer : Optional[str]
        Layer name inside target_fl (if GPKG or GDB).
    boundary : Optional[str]
        Path to an explicit boundary polygon (can be any supported format and any boundary extent).
    boundary_layer : Optional[str]
        Layer name inside boundary (if GPKG or GDB).
    output_clip_layer : Optional[str]
        Layer name to use in output clipped file (required for GPKG).
    """

    def __init__(
        self,
        join_fl: str,
        target_fl: str,
        join_fl_layer: Optional[str] = None,
        target_fl_layer: Optional[str] = None,
        boundary: Optional[str] = None,
        boundary_layer: Optional[str] = None,
        output_clip_layer: Optional[str] = None,
    ):
        self.join_fl = join_fl
        self.target_fl = target_fl
        self.join_fl_layer = join_fl_layer
        self.target_fl_layer = target_fl_layer
        self.boundary = boundary
        self.boundary_layer = boundary_layer
        self.output_clip_layer = (
            output_clip_layer if output_clip_layer else "ClippedFlowlines"
        )

        # get the output_clip path
        self.project_paths = setup_project()
        self.output_clip = self.project_paths.output_reach_gpkg

        self.clip()
        print(f"Clipping completed. Output written to: {self.output_clip}")

    def _read_data(self, path: str, layer: Optional[str]) -> gpd.GeoDataFrame:
        """Helper to read file, handling shapefiles (no layer) vs GPKG/GDB (with layer)"""
        ext = os.path.splitext(path)[-1].lower()

        if ext == ".shp":
            return gpd.read_file(path)
        elif ext in [".gpkg", ".gdb"]:
            if not layer:
                raise ValueError(f"Layer must be specified for file: {path}")
            return gpd.read_file(path, layer=layer)
        else:
            raise ValueError(f"Unsupported file format: {ext} for file {path}")

    def clip(self) -> gpd.GeoDataFrame:
        """
        Performs the flowline clipping operation.
        Returns the clipped GeoDataFrame.
        """
        # Read join flowlines
        join_gdf = self._read_data(self.join_fl, self.join_fl_layer)

        # Determine clipping boundary
        if self.boundary:
            # Use layer only if provided (for GPKG or GDB)
            if self.boundary_layer:
                boundary_gdf = self._read_data(self.boundary, self.boundary_layer)
            else:
                boundary_gdf = self._read_data(self.boundary, None)
        else:

            # Fallback: use bounding envelope of join flowlines
            envelope = join_gdf.geometry.union_all().envelope
            boundary_gdf = gpd.GeoDataFrame({"geometry": [envelope]}, crs=join_gdf.crs)

        # Read target flowlines
        target_gdf = self._read_data(self.target_fl, self.target_fl_layer)

        # Reproject if needed
        if target_gdf.crs != boundary_gdf.crs:
            target_gdf = target_gdf.to_crs(boundary_gdf.crs)

        # Clip
        clipped = gpd.clip(target_gdf, boundary_gdf)

        out_ext = os.path.splitext(self.output_clip)[-1].lower()
        if out_ext == ".gpkg":
            if not self.output_clip_layer:
                raise ValueError(
                    "You must specify output_clip_layer for GeoPackage output."
                )
            clipped.to_file(
                self.output_clip, layer=self.output_clip_layer, driver="GPKG", mode="w"
            )
        elif out_ext == ".shp":
            clipped.to_file(self.output_clip, driver="ESRI Shapefile")
        else:
            raise ValueError(f"Unsupported output format: {out_ext}")

        print(f"Clipped flowlines written to: {self.output_clip}")

        return clipped
