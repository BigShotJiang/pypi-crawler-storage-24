import os
import numpy as np
import geopandas as gpd
from typing import Optional, Tuple
from shapely.geometry import MultiLineString
from shapely.ops import linemerge

from .project_initialization import setup_project

"""
FYI- Here target_network word is refer to which flowlines where attribute is coming from
another flowline, and join_network is which flowline attribute is going to be transferred
FYI- Here target_network word is refer to which flowlines where attribute is coming from
another flowline, and join_network is which flowline attribute is going to be transferred
"""

import fiona


def _remove_layer_if_exists(gpkg_path: str, layer: str):  # efficiency improvement
    if not gpkg_path or not layer:
        return
    try:
        if os.path.exists(gpkg_path):
            layers = fiona.listlayers(gpkg_path)
            if layer in layers:
                fiona.remove(gpkg_path, layer=layer)
    except Exception:
        # If remove fails for any reason, we will still try writing with mode="w"/"a"
        pass


# Generate nodes along flowlines
class NodeExtractor:
    """
    Generate evenly spaced (or fixed-count) nodes along target flowlines and write to GPKG.
    Two mutually-exclusive modes:
    - spacing: place nodes every <spacing> meters along each feature
    - node_number: place exactly <node_number> nodes per feature (>=3)

    If the input CRS is geographic (lat/lon), features are automatically reprojected to
    an appropriate UTM zone for distance-based interpolation, and then reprojected back.
    Multipart lines are merged per feature.

    Parameters
    ----------
    target_network_unique_id_field : str
        Attribute/column name to carry through to the output points (extracted flowlines unique field).
    output_final_reach_joined_gpkg : str
        Path to the output GeoPackage to write generated nodes.
    output_layer : str
        Output layer name to create/overwrite in the output GPKG.
    spacing : Optional[float], default=None
        Distance between consecutive nodes (must not be used with node_number).
    node_number : Optional[int], default=None
        Number of nodes to generate per feature (>=3; must not be used with spacing).
    """

    def __init__(
        self,
        target_network_unique_id_field: str,
        target_network_gpkg: Optional[str] = None,
        target_network_layer: Optional[str] = None,
        output_layer: Optional[str] = None,
        identifier: Optional[str] = None,
        spacing: Optional[float] = None,
        node_number: Optional[int] = None,
    ):
        self.project_paths = setup_project.only_paths()

        # The attribute in this flowline is added from another flowline, It could be benchmark or extracted flowline
        if target_network_gpkg:
            self.extracted_reach_gpkg = target_network_gpkg
        else:
            self.extracted_reach_gpkg = self.project_paths.output_final_reach_gpkg

        self.output_final_reach_joined_gpkg = (
            self.project_paths.output_final_reach_joined_gpkg
        )
        self.extracted_reach_unique_id_field = target_network_unique_id_field
        self.spacing = spacing
        self.node_number = node_number
        self.output_layer = output_layer

        if target_network_layer:
            self.target_reach_layer = target_network_layer

        if identifier:
            self.target_reach_layer = f"join_fl_final_reaches_{identifier}"
            self.output_layer = f"join_fl_final_reaches_nodes_{identifier}"
        else:
            self.target_reach_layer = "join_fl_final_reaches"
            self.output_layer = "join_fl_final_reaches_nodes"

        # Internal state
        self.orig_crs = None
        self.need_reproject_back = False
        self.validate_mode_types()

        self.run()

    def run(self) -> gpd.GeoDataFrame:
        """
        Execute the whole pipeline:
         - Read target flowlines
         - Merge multipart geom into single LineString per feature
         - Reproject to UTM if needed
         - Generate nodes (by spacing or fixed count)
         - Reproject back (if needed) and save to GPKG
        Returns
        -------
        gpd.GeoDataFrame
            Generated points in the original CRS (same as input layer).
        """
        lines = self.load_and_prepare_lines()
        lines_proj = self.project_to_utm(lines)
        pts_proj = self.generate_points(lines_proj)
        pts = self.project_back(pts_proj)
        self.write_output(pts)
        mode = "spacing→nodes" if self.spacing is not None else "fixed nodes"
        print(
            f"\nGenerated and wrote {len(pts)} nodes ({mode}) "
            f"to {self.output_final_reach_joined_gpkg}/{self.output_layer}"
        )
        return pts

    # Validation helpers
    def validate_mode_types(self) -> None:
        if self.spacing is None and self.node_number is None:
            self.node_number = 5

        if self.spacing is not None and self.node_number is not None:
            raise ValueError(
                "Specify exactly one of `spacing` or `node_number`, not both. "
                f"spacing={self.spacing!r}, node_number={self.node_number!r}"
            )

        if self.spacing is not None:
            if not isinstance(self.spacing, (int, float)):
                raise TypeError(
                    f"`spacing` must be numeric (int or float), got {type(self.spacing).__name__}."
                )
            if self.spacing <= 0:
                raise ValueError("`spacing` must be > 0.")

        if self.node_number is not None:
            if not isinstance(self.node_number, int):
                raise TypeError(
                    f"`node_number` must be an integer, got {type(self.node_number).__name__}."
                )
            if self.node_number < 3:
                raise ValueError("`node_number` must be at least 3.")

    # IO and projection helpers
    def load_and_prepare_lines(self) -> gpd.GeoDataFrame:
        """Read line layer, drop empty geometries, and merge multipart lines."""
        lines = gpd.read_file(
            self.extracted_reach_gpkg, layer=self.target_reach_layer
        ).dropna(subset=["geometry"])
        self._orig_crs = lines.crs

        # Merge MultiLineString parts into a single LineString per feature
        lines["geometry"] = lines.geometry.apply(
            lambda g: linemerge(g) if isinstance(g, MultiLineString) else g
        )
        return lines

    def utm_epsg_for_bounds(self, bounds: Tuple[float, float, float, float]) -> int:
        """
        Compute a UTM EPSG code for the layer bounds (in lon/lat).
        Picks zone using centroid longitude; hemisphere by centroid latitude.
        """
        minx, miny, maxx, maxy = bounds
        midx, midy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
        zone = int((midx + 180) // 6) + 1
        return 32600 + zone if midy >= 0 else 32700 + zone

    # Project to UTM if original CRS is geographic to enable distance-based interpolation.
    def project_to_utm(self, lines: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        if self._orig_crs is not None and getattr(
            self._orig_crs, "is_geographic", False
        ):
            epsg_utm = self.utm_epsg_for_bounds(lines.total_bounds)
            lines_proj = lines.to_crs(epsg=epsg_utm)
            self._need_reproject_back = True
            return lines_proj
        else:
            self._need_reproject_back = False
            return lines

    # Reproject generated points back to the original CRS if we projected to UTM.
    def project_back(self, pts_proj: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        if self._need_reproject_back and self._orig_crs is not None:
            return pts_proj.to_crs(self._orig_crs)
        return pts_proj

    # Write generated points to the specified GeoPackage/layer.
    def write_output(self, pts: gpd.GeoDataFrame) -> None:
        # Ensure output folder exists
        # Ensure output folder exists
        out_dir = os.path.dirname(self.output_final_reach_joined_gpkg)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)

        # pts.to_file(
        #     filename=self.output_final_reach_joined_gpkg,
        #     layer=self.output_layer,
        #     driver="GPKG",
        # )

        _remove_layer_if_exists(
            self.output_final_reach_joined_gpkg, self.output_layer
        )  # efficiency improvement
        pts.to_file(
            filename=self.output_final_reach_joined_gpkg,
            layer=self.output_layer,
            driver="GPKG",
            mode="w",  # efficiency improvement
        )

    # Core generation
    def generate_points(self, lines_proj: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        records = []
        for row in lines_proj.itertuples():
            seg = row.geometry
            if seg is None:
                continue

            L = seg.length
            if not L or L == 0:
                continue

            # Determine number of nodes for this feature
            if self.spacing is not None:
                q = L / self.spacing

                # Ensure at least 3 nodes per feature even for short segments
                n = int(np.floor(q)) + 1 if q >= 3 else 3
            else:
                n = self.node_number

            # Interpolate points at linearly spaced fractions (including endpoints)
            fracs = np.linspace(0.0, 1.0, n)
            for f in fracs:
                pt = seg.interpolate(f * L)
                records.append(
                    {
                        f"{self.extracted_reach_unique_id_field}": getattr(
                            row, self.extracted_reach_unique_id_field, None
                        ),
                        "geometry": pt,
                    }
                )

        return gpd.GeoDataFrame(records, crs=lines_proj.crs)


# Get the information about the nearest attributes from the flowline to the nodes and then back to target flowline where those attributes are going to be added
class JoinNearestFlowLineAttributes:
    """
    Join nearest flowline attributes to the nodes, then back to target_network.
     - Read node points and join_network.
     - Reproject join_network into nodes CRS if they differ.
     - Compute 'reach_length_for_join' (metres) on join_network:
           - if geographic: temporarily project to UTM, measure, and bring back
           - else: measure directly
     - Nearest-geometry join: attach all flowline attributes to each node.
     - Drop the flowline geometry from the node table.
     - Join those node attributes back onto the target flowlines by `common_id`.
     - Write out:
         - nodes_with_attrs to output_gpkg/output_nodes_layer
         - enriched flowlines to output_gpkg/output_flowlines_layer
         - enriched flowlines (no geometry) as CSV alongside the GPKG
    """

    def __init__(
        self,
        target_network_unique_id_field: str,
        *,
        identifier: Optional[str] = None,
        join_network_gpkg: Optional[str] = None,
        target_network_gpkg: Optional[str] = None,
        join_network_layer: Optional[str] = None,
        target_network_layer: Optional[str] = None,
        output_nodes_layer: Optional[str] = None,
        output_flowlines_layer: Optional[str] = None,
        dedupe_by_common_id: bool = False,
    ) -> None:
        """
        Parameters
        ----------
        common_id : str
            Column shared between nodes and target flowlines used to merge attributes back.
        identifier : Optional[str]
            If provided, suffixes layer names like *_{identifier} to keep runs distinct.
        output_nodes_layer : Optional[str]
            Override output layer name for the nodes-with-attrs table.
        output_flowlines_layer : Optional[str]
            Override output layer name for the enriched flowlines table.
        dedupe_by_common_id : bool, default False
            If True, keep only the closest node per `common_id` before merging back.
        autorun : bool, default True
            Run the pipeline immediately on construction.
        """
        self.common_id = target_network_unique_id_field
        self.dedupe_by_common_id = dedupe_by_common_id
        self.project_paths = setup_project.only_paths()
        self.nodes_gpkg = self.project_paths.output_final_reach_joined_gpkg

        if join_network_gpkg:
            self.join_network_gpkg = join_network_gpkg
        else:
            self.join_network_gpkg = self.project_paths.output_reach_gpkg

        if target_network_gpkg:
            self.target_network_gpkg = target_network_gpkg
        else:
            self.target_network_gpkg = self.project_paths.output_final_reach_gpkg

        self.output_gpkg = self.project_paths.output_final_reach_joined_gpkg
        self.join_network_layer = (
            join_network_layer if join_network_layer else "ClippedFlowlines"
        )

        if identifier:
            self.nodes_layer = f"join_fl_final_reaches_nodes_{identifier}"
            if target_network_layer:
                self.target_network_layer = target_network_layer
            else:
                self.target_network_layer = f"join_fl_final_reaches_{identifier}"

            self.output_nodes_layer = (
                output_nodes_layer
                or f"join_fl_final_reaches_nodes_joinedAttr_{identifier}"
                or f"join_fl_final_reaches_nodes_joinedAttr_{identifier}"
            )
            self.output_flowlines_layer = (
                output_flowlines_layer
                or f"join_fl_final_reaches_joinedAttr_{identifier}"
            )
        else:
            self.nodes_layer = "join_fl_final_reaches_nodes"
            if target_network_layer:
                self.target_network_layer = target_network_layer
            else:
                self.target_network_layer = "join_fl_final_reaches"
            self.output_nodes_layer = (
                output_nodes_layer or "join_fl_final_reaches_nodes_joinedAttr"
            )
            self.output_flowlines_layer = (
                output_flowlines_layer or "join_fl_final_reaches_joinedAttr"
            )

        # Run the code
        self.run()

    def run(self) -> gpd.GeoDataFrame:
        # nodes, join_network, target_network = self.load_inputs()
        # join_network = self.align_crs(join_network, nodes)
        # join_network = self.add_reach_length_m(join_network)

        # joined_nodes = self.sjoin_nearest(nodes, join_network)
        # joined_nodes = self.strip_right_geom(joined_nodes)

        # node_attrs = self.prep_node_attrs(joined_nodes)
        # if self.dedupe_by_common_id and self.common_id in node_attrs.columns:
        #     node_attrs = self.dedupe_node_attrs(node_attrs, self.common_id)

        # flowlines_with_attrs = self.merge_back(
        #     target_network, node_attrs, self.common_id
        # )
        # self.write_outputs(joined_nodes, flowlines_with_attrs)
        # return flowlines_with_attrs

        nodes, join_network, target_network = self.load_inputs()

        # Keep your CRS alignment (still useful)
        join_network = self.align_crs(join_network, nodes)

        # ---- NEW: project to UTM if needed for distance ops ----
        nodes_work, join_work, meta = self._project_to_utm_if_geo(nodes, join_network)

        # ---- Compute reach lengths in the WORK CRS (meters) ----
        join_work["reach_length_for_join"] = join_work.geometry.length

        # ---- Do nearest join in WORK CRS ----
        joined_nodes = self.sjoin_nearest(nodes_work, join_work)

        # ---- Project joined nodes back for writing/consistency ----
        joined_nodes = self._project_back_if_needed(joined_nodes, meta)

        joined_nodes = self.strip_right_geom(joined_nodes)

        node_attrs = self.prep_node_attrs(joined_nodes)
        if self.dedupe_by_common_id and self.common_id in node_attrs.columns:
            node_attrs = self.dedupe_node_attrs(node_attrs, self.common_id)

        flowlines_with_attrs = self.merge_back(
            target_network, node_attrs, self.common_id
        )
        self.write_outputs(joined_nodes, flowlines_with_attrs)
        return flowlines_with_attrs

    def load_inputs(
        self,
    ) -> Tuple[gpd.GeoDataFrame, gpd.GeoDataFrame, gpd.GeoDataFrame]:
        self.nodes = gpd.read_file(self.nodes_gpkg, layer=self.nodes_layer)
        self.join_network = gpd.read_file(
            self.join_network_gpkg, layer=self.join_network_layer
        )
        self.target_network = gpd.read_file(
            self.target_network_gpkg, layer=self.target_network_layer
        )

        self.assert_crs_present(self.nodes, "nodes")
        self.assert_crs_present(self.join_network, "join flowlines")
        self.assert_crs_present(self.target_network, "target flowlines")
        return self.nodes, self.join_network, self.target_network

    def align_crs(
        self, gdf: gpd.GeoDataFrame, reference: gpd.GeoDataFrame
    ) -> gpd.GeoDataFrame:
        return gdf.to_crs(reference.crs) if gdf.crs != reference.crs else gdf

    # def add_reach_length_m(self, join_network: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    #     if join_network.empty:
    #         join_network["reach_length_for_join"] = []
    #         return join_network
    #     if self.is_geographic(join_network):
    #         utm_epsg = self.guess_utm_epsg(join_network)
    #         tmp = join_network.to_crs(epsg=utm_epsg)
    #         join_network["reach_length_for_join"] = tmp.geometry.length
    #     else:
    #         join_network["reach_length_for_join"] = join_network.geometry.length
    #     return join_network

    def sjoin_nearest(
        self, nodes: gpd.GeoDataFrame, join_network: gpd.GeoDataFrame
    ) -> gpd.GeoDataFrame:
        # print(f"[sjoin_nearest] nodes CRS: {nodes.crs}")
        # print(f"[sjoin_nearest] join_network CRS: {join_network.crs}")

        return gpd.sjoin_nearest(
            nodes, join_network, how="left", distance_col="dist_to_line"
        )

    def strip_right_geom(self, joined_nodes: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        return joined_nodes.drop(columns="geometry_right", errors="ignore")

    def prep_node_attrs(self, joined_nodes: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        return joined_nodes.drop(columns=["geometry"], errors="ignore")

    def dedupe_node_attrs(
        self, node_attrs: gpd.GeoDataFrame, key: str
    ) -> gpd.GeoDataFrame:
        if "dist_to_line" in node_attrs.columns:
            node_attrs = node_attrs.sort_values(["dist_to_line"])
        return node_attrs.drop_duplicates(subset=[key], keep="first")

    def merge_back(
        self, target_network: gpd.GeoDataFrame, node_attrs: gpd.GeoDataFrame, key: str
    ) -> gpd.GeoDataFrame:
        return target_network.merge(node_attrs, on=key, how="left")

    def write_outputs(
        self, joined_nodes: gpd.GeoDataFrame, flowlines_with_attrs: gpd.GeoDataFrame
    ) -> None:
        os.makedirs(os.path.dirname(self.output_gpkg), exist_ok=True)

        # joined_nodes.to_file(
        #     filename=self.output_gpkg,
        #     layer=self.output_nodes_layer,
        #     driver="GPKG",
        # )

        # flowlines_with_attrs.to_file(
        #     filename=self.output_gpkg,
        #     layer=self.output_flowlines_layer,
        #     driver="GPKG",
        # )

        _remove_layer_if_exists(
            self.output_gpkg, self.output_nodes_layer
        )  # efficiency improvement
        joined_nodes.to_file(
            filename=self.output_gpkg,
            layer=self.output_nodes_layer,
            driver="GPKG",
            mode="w",  # efficiency improvement
        )

        _remove_layer_if_exists(
            self.output_gpkg, self.output_flowlines_layer
        )  # efficiency improvement
        flowlines_with_attrs.to_file(
            filename=self.output_gpkg,
            layer=self.output_flowlines_layer,
            driver="GPKG",
            mode="w",  # efficiency improvement
        )

        csv_dir = os.path.join(
            os.path.dirname(self.output_gpkg), "FinalReaches_JoinedCommonID_csv"
        )
        os.makedirs(csv_dir, exist_ok=True)
        csv_path = os.path.join(csv_dir, f"{self.output_flowlines_layer}.csv")
        flowlines_with_attrs.drop(columns="geometry", errors="ignore").to_csv(
            csv_path, index=False
        )

        print(
            f"Wrote {len(joined_nodes)} nodes to {self.output_gpkg}/{self.output_nodes_layer}"
        )
        print(
            f"Wrote {len(flowlines_with_attrs)} flowlines to {self.output_gpkg}/{self.output_flowlines_layer}"
        )
        print(f"→ Wrote CSV of flowlines attributes to {csv_path}")

    @staticmethod
    def assert_crs_present(gdf: gpd.GeoDataFrame, name: str) -> None:
        if gdf.crs is None:
            raise ValueError(
                f"CRS is missing on {name}. Please set a valid CRS before running."
            )

    @staticmethod
    def is_geographic(gdf: gpd.GeoDataFrame) -> bool:
        crs = gdf.crs
        return bool(getattr(crs, "is_geographic", False))

    @staticmethod
    def guess_utm_epsg(gdf: gpd.GeoDataFrame) -> int:
        minx, miny, maxx, maxy = gdf.total_bounds
        midx, midy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
        zone = int((midx + 180) // 6) + 1
        return (32600 if midy >= 0 else 32700) + zone

    # I added on 02/24/2026
    def _project_to_utm_if_geo(
        self,
        nodes: gpd.GeoDataFrame,
        join_network: gpd.GeoDataFrame,
    ):
        """
        If nodes CRS is geographic (lon/lat), project BOTH nodes and join_network
        to a suitable UTM (meters) for distance-based ops (sjoin_nearest, lengths).
        Returns: nodes_work, join_work, meta dict for projecting back.
        """
        meta = {"projected": False, "orig_crs": nodes.crs}

        # Only need this for distance-based work
        if not self.is_geographic(nodes):
            return nodes, join_network, meta

        # Pick a UTM zone using the bounds (nodes are a good reference)
        utm_epsg = self.guess_utm_epsg(nodes)
        nodes_work = nodes.to_crs(epsg=utm_epsg)

        # Ensure join_network is in the same CRS as nodes_work
        join_work = (
            join_network.to_crs(epsg=utm_epsg)
            if join_network.crs != nodes_work.crs
            else join_network
        )

        meta["projected"] = True
        meta["utm_epsg"] = utm_epsg
        return nodes_work, join_work, meta

    def _project_back_if_needed(
        self, gdf: gpd.GeoDataFrame, meta: dict
    ) -> gpd.GeoDataFrame:
        """
        Project back to the original CRS of nodes (so outputs match the rest of the workflow).
        """
        if (
            meta.get("projected")
            and meta.get("orig_crs") is not None
            and gdf.crs != meta["orig_crs"]
        ):
            return gdf.to_crs(meta["orig_crs"])
        return gdf


# Transfer the single attribute based on counts of joined flowlines
class AggregateJoinedFlowlines:
    """
    Aggregate the joined flowlines to one record per target flowline, based on the
    count of joined flowlines; break ties using 'reach_length_for_join'.

    1) Read `joined_output_layer` from `joined_output_gpkg` (multiple joined records per target).
    2) Count how often each `join_fl_unique_id_field` occurs for each `target_fl_unique_id_field`.
    3) Keep only the flowline with the highest count; tie-break by 'reach_length_for_join'.
    4) Merge back full-feature records, drop duplicates.
    5) Drop 'reach_length_for_join'.
    6) Write aggregated layer to `joined_output_gpkg` under `output_aggregated_layer`.
    7) Export attributes (no geometry) as CSV.

    Notes
    -----
    - By default, the output GeoPackage is written with mode='w' (overwrite entire file),
      matching your original function. Set `overwrite_gpkg=False` to append a new layer instead.
    """

    def __init__(
        self,
        target_network_unique_id_field: str,
        join_network_unique_id_field: str,
        *,
        identifier: Optional[str] = None,
        output_flowlines_layer: Optional[
            str
        ] = None,  # Same as "JoinNearestFlowLineAttributes" module if used something unique
        output_aggregated_layer: Optional[str] = None,
        # overwrite_gpkg: bool = True,
    ) -> None:
        self.target_network_unique_id_field = target_network_unique_id_field
        self.join_network_unique_id_field = join_network_unique_id_field
        # self.overwrite_gpkg = overwrite_gpkg

        self.project_paths = setup_project.only_paths()
        self.joined_output_gpkg = self.project_paths.output_final_reach_joined_gpkg

        # layer naming
        if identifier:
            self.joined_output_layer = (
                output_flowlines_layer
                or f"join_fl_final_reaches_joinedAttr_{identifier}"
            )
            self.output_aggregated_layer = (
                output_aggregated_layer
                or f"join_fl_final_reaches_aggregatedAttr_{identifier}"
            )
        else:
            self.joined_output_layer = (
                output_flowlines_layer or "join_fl_final_reaches_joinedAttr"
            )
            self.output_aggregated_layer = (
                output_aggregated_layer or "join_fl_final_reaches_aggregatedAttr"
            )

        self.run()

    def run(self) -> gpd.GeoDataFrame:
        gdf = self.load_input()

        counts = self.count_occurrences(gdf)
        chosen = self.tie_break_by_length(gdf, counts)

        aggregated = gdf.merge(
            chosen,
            on=[self.target_network_unique_id_field, self.join_network_unique_id_field],
            how="inner",
        ).drop_duplicates(
            subset=[
                self.target_network_unique_id_field,
                self.join_network_unique_id_field,
            ]
        )

        aggregated = aggregated.drop(columns=["reach_length_for_join"], errors="ignore")

        self.write_outputs(aggregated)
        return aggregated

    # Helpers
    def load_input(self) -> gpd.GeoDataFrame:
        gdf = gpd.read_file(self.joined_output_gpkg, layer=self.joined_output_layer)
        if gdf.crs is None:
            raise ValueError(
                f"CRS is missing on input layer '{self.joined_output_layer}'."
            )
        return gdf

    def count_occurrences(self, gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        counts = (
            gdf.groupby(
                [self.target_network_unique_id_field, self.join_network_unique_id_field]
            )
            .size()
            .reset_index(name="cnt")
        )
        counts["max_cnt"] = counts.groupby(self.target_network_unique_id_field)[
            "cnt"
        ].transform("max")
        tied = counts[counts["cnt"] == counts["max_cnt"]].copy()
        return tied

    def tie_break_by_length(
        self, gdf: gpd.GeoDataFrame, tied: gpd.GeoDataFrame
    ) -> gpd.GeoDataFrame:
        # unique lengths per join flowline id
        lengths = gdf[
            [self.join_network_unique_id_field, "reach_length_for_join"]
        ].drop_duplicates(subset=self.join_network_unique_id_field)
        tied = tied.merge(lengths, on=self.join_network_unique_id_field, how="left")
        idx = tied.groupby(self.target_network_unique_id_field)[
            "reach_length_for_join"
        ].idxmax()
        chosen = tied.loc[
            idx,
            [self.target_network_unique_id_field, self.join_network_unique_id_field],
        ]
        return chosen

    def write_outputs(self, aggregated: gpd.GeoDataFrame) -> None:
        os.makedirs(os.path.dirname(self.joined_output_gpkg), exist_ok=True)

        # GeoPackage write mode: 'w' to overwrite whole file, else append.
        # mode = "w" if self.overwrite_gpkg else "a"
        # aggregated.to_file(
        #     filename=self.joined_output_gpkg,
        #     layer=self.output_aggregated_layer,
        #     driver="GPKG",
        #     mode=mode,
        # )
        _remove_layer_if_exists(
            self.joined_output_gpkg, self.output_aggregated_layer
        )  # efficiency improvement
        aggregated.to_file(
            filename=self.joined_output_gpkg,
            layer=self.output_aggregated_layer,
            driver="GPKG",
            mode="w",  # efficiency improvement
        )
        print(
            f"Aggregated {len(aggregated)} unique records "
            f"to layer '{self.output_aggregated_layer}' in {self.joined_output_gpkg}"
        )

        # CSV export for attributes only
        csv_dir = os.path.join(
            os.path.dirname(self.joined_output_gpkg), "FinalReaches_JoinedCommonID_csv"
        )
        os.makedirs(csv_dir, exist_ok=True)
        csv_path = os.path.join(csv_dir, f"{self.output_aggregated_layer}.csv")
        aggregated.drop(columns="geometry", errors="ignore").to_csv(
            csv_path, index=False
        )
        print(f"Attribute table saved as CSV to {csv_path}")
