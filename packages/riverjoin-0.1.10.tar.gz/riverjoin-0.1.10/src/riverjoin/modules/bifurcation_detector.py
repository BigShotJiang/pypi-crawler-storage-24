import geopandas as gpd
import pandas as pd
import re
from typing import Optional

_SPLIT_RE = re.compile(r"[,\s;|]+")


def _split_tokens(val) -> list[str]:
    if pd.isna(val):
        return []
    s = str(val).strip()
    return [t for t in _SPLIT_RE.split(s) if t]


class BifurcationDetector:
    """
    Checks if a flowline layer has any bifurcations based on a multi-valued nextDown field.
    """

    def __init__(
        self,
        gpkg_path: str,
        unique_id_nextDown: str,
        layer: Optional[str] = None,
    ):
        self.gpkg_path = gpkg_path
        self.layer = layer
        self.unique_id_nextDown = unique_id_nextDown

        self.gdf = (
            gpd.read_file(self.gpkg_path, layer=self.layer)
            if self.layer
            else gpd.read_file(self.gpkg_path)
        )

        # Normalize to string so splitting is reliable
        self.nextdown_series = self.gdf[self.unique_id_nextDown].astype("string")
        self.tokens_per_row = self.nextdown_series.apply(_split_tokens)

    def has_bifurcations(self) -> bool:
        return any(len(toks) > 1 for toks in self.tokens_per_row)

    def count_bifurcations(self) -> int:
        return sum(1 for toks in self.tokens_per_row if len(toks) > 1)

    # def bifurcation_row_indices(self) -> list[int]:
    #     return [int(i) for i, toks in zip(self.gdf.index, self.tokens_per_row) if len(toks) > 1]
