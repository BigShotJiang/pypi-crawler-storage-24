import os
from pathlib import Path
from typing import Optional, List, Dict


# Creating a empty directory structure to store intermidiate GeoPackage files
class setup_project:
    """Initializes the project directory structure for RiverJoin.
    Files managed:
      - TempPoints.gpkg
      - TempReaches.gpkg
      - TempReachesBuffers.gpkg
      - TempReachesPointsPerp.gpkg
      - FinalReaches.gpkg
      - FinalReaches_JoinedCommonID.gpkg
    """

    gpkg_names = [
        "TempPoints.gpkg",
        "TempReaches.gpkg",
        "TempReachesBuffers.gpkg",
        "TempReachesPointsPerp.gpkg",
        "FinalReaches.gpkg",
        "FinalReaches_JoinedCommonID.gpkg",
    ]

    def __init__(self):
        script_dir = Path.cwd()
        self.base_dir = script_dir / "RiverJoin" / "output"
        self.base_dir.mkdir(parents=True, exist_ok=True)

        self.paths = {}
        for name in self.gpkg_names:
            full_path = self.base_dir / name
            full_path.parent.mkdir(parents=True, exist_ok=True)
            self.paths[name] = str(full_path)

        self._assign_paths()

    @classmethod
    def only_paths(cls, base_dir: Optional[Path] = None):
        """
        Returns a lightweight object with only the file paths assigned.
        Does NOT create any folders.
        """
        obj = cls.__new__(cls)
        obj.base_dir = base_dir or Path.cwd() / "RiverJoin" / "output"
        obj.paths = {name: str(obj.base_dir / name) for name in cls.gpkg_names}
        obj._assign_paths()
        return obj

    def _assign_paths(self):
        """Assign individual file paths as attributes."""
        self.output_point_gpkg = self.paths["TempPoints.gpkg"]
        self.output_reach_gpkg = self.paths["TempReaches.gpkg"]
        self.output_reach_buffer_gpkg = self.paths["TempReachesBuffers.gpkg"]
        self.output_reach_point_perp_gpkg = self.paths["TempReachesPointsPerp.gpkg"]
        self.output_final_reach_gpkg = self.paths["FinalReaches.gpkg"]
        self.output_final_reach_joined_gpkg = self.paths[
            "FinalReaches_JoinedCommonID.gpkg"
        ]
