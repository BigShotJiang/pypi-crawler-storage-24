"""
Author: Dr. Yixian Chen (ychen223@ua.edu), Supath Dhital (sdhital@ua.edu)
Date Updated: 11 March 2026
"""

import geopandas as gpd
import pandas as pd
import numpy as np
import fiona
import re
from typing import Optional

from .project_initialization import setup_project


# Reconstruct the disconnected segments, which gives the final output of the flowline network
class ReconstructDisconnectedBifurcation:
    """
    - Reads the initially extracted network (extract_gdf) and the full join flowline network (join_fl).
    - Finds NextDownIDs (unique_id_nextDown) that do not appear as HydroIDs in the extracted set.
    - Traces upstream from each “disconnected end,” adding any missing reaches until hitting a node that is already in the extracted set or a dead-end.
    - Exports those “missing_reaches” to output_reach_gpkg/missing_reaches_{identifier}.
    - Merges them back into the extracted network, writing the final reconstructed network to output_final_reach_gpkg/output_final_reach_gpkg_{identifier}.

    Returns:
        Path to the final reconstructed feature class GeoPackage.
    """

    def __init__(
        self,
        unique_id: str,
        unique_id_nextDown: str,
        join_fl: str,
        target_nextdown_field: str,
        join_fl_reach_width_field: Optional[str] = None,
        width_preview_hops: int = 3,
        width_ratio_threshold: float = 0.5,
        join_fl_layer: Optional[str] = None,
        identifier: Optional[str] = None,
    ):
        self.unique_id = unique_id
        self.unique_id_nextDown = unique_id_nextDown
        self.join_fl = join_fl
        self.target_nextdown_field = target_nextdown_field
        self.join_fl_reach_width_field = join_fl_reach_width_field
        self.width_preview_hops = width_preview_hops
        self.width_ratio_threshold = width_ratio_threshold
        self.join_fl_layer = join_fl_layer
        self.identifier = identifier

        # Get project paths
        self.project_paths = setup_project.only_paths()
        self.output_reach_gpkg = self.project_paths.output_reach_gpkg
        self.output_final_reach_gpkg = self.project_paths.output_final_reach_gpkg
        self.output_final_reach_joined_gpkg = (
            self.project_paths.output_final_reach_joined_gpkg
        )

        if identifier:
            self.joined_extracted_layer = (
                f"join_fl_final_reaches_aggregatedAttr_{identifier}"
            )
            self.extracted_layer = f"join_fl_final_reaches_{identifier}"

        else:
            self.joined_extracted_layer = "join_fl_final_reaches_aggregatedAttr"
            self.extracted_layer = f"join_fl_final_reaches"

        self.result = None  # Final reconstructed GeoDataFrame
        self.missing_ids = []  # Missing reaches

        self.run()

    def run(self):
        self.read_inputs()
        self.dtype_alignment()
        self.find_disconnected_segments()
        self.trace_missing_segments()
        self.export_missing_reaches()
        self.merge_and_save_final()
        self.print_summary()

    def read_inputs(self):
        self.extract_gdf = gpd.read_file(
            # self.joined_output_gpkg, layer=self.joined_extracted_layer
            self.output_final_reach_joined_gpkg,
            layer=self.joined_extracted_layer,
        )

        self.extract_gdf_no_joinedAtrr = gpd.read_file(
            self.output_final_reach_gpkg, layer=self.extracted_layer
        )

        if self.join_fl_layer is None:
            self.orig_gdf = gpd.read_file(self.join_fl)
        else:
            self.orig_gdf = gpd.read_file(self.join_fl, layer=self.join_fl_layer)

    # helpers for normalization
    _SPLIT_RE = re.compile(r"[,\s;|]+")

    @staticmethod
    def _split_tokens(value) -> list[str]:
        """
        Accepts scalar or list-like. Returns list[str] of cleaned tokens.
        """
        if pd.isna(value):
            return []
        # lists/arrays come through unchanged (stringify each)
        if isinstance(value, (list, tuple, np.ndarray, pd.Series)):
            toks = []
            for v in value:
                if pd.isna(v):
                    continue
                toks.extend(ReconstructDisconnectedBifurcation._split_tokens(v))
            return toks
        # scalar -> split by comma/space/; / |
        s = str(value).strip()
        if not s:
            return []
        return [
            t for t in ReconstructDisconnectedBifurcation._SPLIT_RE.split(s) if t
        ]  # drop empties

    @staticmethod
    def _series_tokens(series: pd.Series) -> pd.Series:
        """
        Turn a string/mixed series with possible multi-values into list[str] per row.
        """
        return series.apply(ReconstructDisconnectedBifurcation._split_tokens)

    @staticmethod
    def _normalize_id_series_for_compare(s: pd.Series, target_dtype) -> pd.Series:
        """
        Reuse your compare-space policy, but ensure we end with a *string* surface
        for robust token comparisons (since multi-values are stringy by nature).
        """
        # use your existing policy to coerce, then stringify once
        if pd.api.types.is_integer_dtype(target_dtype):
            s2 = pd.to_numeric(s, errors="coerce").astype("Int64")
        elif pd.api.types.is_string_dtype(target_dtype) or target_dtype == object:
            s2 = s.astype("string")
        else:
            s2 = s.astype(target_dtype, copy=True)

        return s2.astype("string")  # final surface for token work

    def dtype_alignment(self):

        # establish compare space using your existing policy
        uid_dtype = self.extract_gdf[self.unique_id].dtype
        next_dtype = self.extract_gdf[self.unique_id_nextDown].dtype

        # normalize HydroIDs & NextDownIDs (row-wise strings) to compare space
        hydro_ids_series = self._normalize_id_series_for_compare(
            self.extract_gdf[self.unique_id], uid_dtype
        )
        nextdown_series = self._normalize_id_series_for_compare(
            self.extract_gdf[self.unique_id_nextDown], next_dtype
        )

        # tokenized lists per row (for bifurcations)
        self.nextdown_tokens_per_row = self._series_tokens(nextdown_series)

        # flat HydroID set for membership checks
        self.hydro_ids = hydro_ids_series
        self.hydro_ids_set = set(hydro_ids_series.dropna().unique())

        # original network compare space (to trace downstream)
        orig_ids_series = self._normalize_id_series_for_compare(
            self.orig_gdf[self.unique_id], uid_dtype
        )
        orig_next_ids_series = self._normalize_id_series_for_compare(
            self.orig_gdf[self.unique_id_nextDown], next_dtype
        )

        self.orig_ids = orig_ids_series
        self.orig_next_ids = orig_next_ids_series

    def find_disconnected_segments(self):
        """
        Inside instance methods (def ... (self):), prefer either:
        type(self)._series_tokens(...) (polymorphic and explicit), or
        self._series_tokens(...) (clean and polymorphic)
        """

        # Flatten all nextDown tokens from extracted set
        all_next_tokens = []
        for toks in self.nextdown_tokens_per_row:
            all_next_tokens.extend(toks)

        # disconnected ends = tokens not present in HydroIDs
        cand = pd.Series(all_next_tokens, dtype="string").dropna().unique()
        disconnected = [t for t in cand if t not in self.hydro_ids_set]

        self.disconnected_ends = []
        disconnected_set = set(disconnected)  # for quick lookup

        # Pre-tokenize the target_nextdown field
        if self.target_nextdown_field in self.extract_gdf.columns:
            tgt_next_series = self._normalize_id_series_for_compare(
                self.extract_gdf[self.target_nextdown_field],
                self.extract_gdf[self.target_nextdown_field].dtype,
            )
            tgt_next_tokens_per_row = self._series_tokens(tgt_next_series)
        else:
            # if field not present, treat as empty
            tgt_next_tokens_per_row = pd.Series(
                [[]] * len(self.extract_gdf), index=self.extract_gdf.index
            )

        for end in disconnected:
            # locate parent rows where this 'end' is among the row's nextDown tokens
            parent_rows = self.nextdown_tokens_per_row.apply(lambda toks: end in toks)
            if not parent_rows.any():
                # If no parent row found (edge case), keep it as disconnected
                self.disconnected_ends.append(end)
                continue

            # evaluate skip rule against *any* parent row that matches
            should_skip = False
            for idx in self.extract_gdf.index[parent_rows]:
                row_tokens = self.nextdown_tokens_per_row.iloc[idx]
                tgt_tokens = tgt_next_tokens_per_row.iloc[idx]

                # non-bifurcated on target side?
                not_bifurcated_target = len(tgt_tokens) <= 1

                # siblings in the same nextDown cell (exclude the current end)
                siblings = [t for t in row_tokens if t != end]

                # "already extracted" siblings = in HydroIDs and not in disconnected set
                extracted_siblings = [
                    t
                    for t in siblings
                    if (t in self.hydro_ids_set) and (t not in disconnected_set)
                ]

                if not_bifurcated_target and extracted_siblings:
                    should_skip = True
                    break

            if not should_skip:
                self.disconnected_ends.append(end)

    # Trace downstream from each disconnected end
    """
    What this does:
        - Groups sibling ends that share the same parent row (same nextDown cell).
        - For each group, does a preview trace (default: 3 hops) for each child and computes the average width (from self.orig_gdf[self.join_fl_reach_width_field]).
        - Prunes children whose average width is < ratio × largest (default ratio 0.5).
        - Traces the remaining children fully, recursively re-applying the same pruning at every junction (handles sub- and sub-sub-bifurcations).
        - Stops tracing a branch when it hits an already-extracted HydroID, a dead end, or a loop.
        - Writes the missing reaches as before.

        - If width field is missing and the run_bifurcation_pass is called, it just traces all tributaries (no pruning).
    """

    @staticmethod
    def _nanmean_safe(vals):
        arr = np.asarray(vals, dtype=float)
        if arr.size == 0:
            return np.nan
        if not np.isfinite(arr).any():
            return np.nan
        return float(np.nanmean(arr))

    @staticmethod
    def _first_or_nan(seq):
        return seq[0] if seq else pd.NA

    @staticmethod
    def _as_tuple_bbox(bbox_like):
        # (not used here; keep if you need to coerce bboxes)
        return tuple(map(float, bbox_like))

    # Build maps
    def _prepare_downstream_maps(self):
        # Full fanout: id -> list[str] of nextDown tokens
        orig_next_tokens = self._series_tokens(self.orig_next_ids)
        self.down_map_all = dict(
            zip(self.orig_ids.astype(str).tolist(), orig_next_tokens.tolist())
        )
        self.down_map_first = {
            i: self._first_or_nan(self.down_map_all.get(i, []))
            for i in self.down_map_all.keys()
        }

        # Width lookup
        # if self.join_fl_reach_width_field in self.orig_gdf.columns:
        if self.join_fl_reach_width_field and (
            self.join_fl_reach_width_field in self.orig_gdf.columns
        ):
            width_ser = self.orig_gdf.assign(
                _uid_str=self.orig_gdf[self.unique_id].astype("string")
            ).set_index("_uid_str")[self.join_fl_reach_width_field]
            width_ser = pd.to_numeric(width_ser, errors="coerce")  # non-numeric -> NaN
            self.width_map = {str(k): v for k, v in width_ser.to_dict().items()}
        else:
            self.width_map = {}  # no pruning if empty

    # Avg width over first-k downstream hops starting at start_id
    def _preview_avg_width(self, start_id: str, k: int) -> float:
        """Follow first child k hops; avg widths along the path (including start_id)."""
        widths = []
        current = start_id
        steps = 0
        visited = set()
        while pd.notna(current) and steps < k:
            if current in visited:
                break  # loop guard
            visited.add(current)
            w = self.width_map.get(current, np.nan)

            widths.append(np.nan if w in (None, "") else w)
            nxt = self.down_map_first.get(current, pd.NA)
            current = nxt
            steps += 1
        return self._nanmean_safe(widths)

    def _prune_children_by_width(self, children: list[str]) -> list[str]:
        """Keep children whose preview-avg-width >= ratio * max."""
        if not children:
            return []
        if not self.width_map:  # no width info -> keep all
            return children
        k = self.width_preview_hops or 3
        ratio = self.width_ratio_threshold or 0.5
        avgs = {c: self._preview_avg_width(c, k) for c in children}
        if all(np.isnan(v) for v in avgs.values()):
            return children
        max_avg = np.nanmax(list(avgs.values()))
        keep = [
            c for c, v in avgs.items() if (not np.isnan(v)) and (v >= ratio * max_avg)
        ]
        return keep or children

    def _parents_of_end(self, end: str) -> list[int]:
        """Row indices in extract_gdf where this end appears in the row's nextDown tokens."""
        if not hasattr(self, "nextdown_tokens_per_row"):
            self.nextdown_tokens_per_row = self._series_tokens(
                self.extract_gdf[self.unique_id_nextDown].astype(str)
            )
        return [
            idx
            for idx, toks in zip(self.extract_gdf.index, self.nextdown_tokens_per_row)
            if end in toks
        ]

    def _siblings_in_row(self, row_idx: int, exclude: str) -> list[str]:
        toks = self.nextdown_tokens_per_row.iloc[row_idx]
        return [t for t in toks if t != exclude]

    # NEW trace with recursive width-based pruning
    def trace_missing_segments(self):
        """
        Builds self.missing_ids_set with bifurcation-aware, width-pruned tracing.
        """
        self._prepare_downstream_maps()

        # figure out whether width pruning is actually active
        if not getattr(self, "join_fl_reach_width_field", None):
            width_note = "width pruning OFF (width field not provided)"
        elif not getattr(self, "width_map", {}):
            width_note = f"width pruning OFF (field '{self.join_fl_reach_width_field}' missing or unusable)"
        else:
            width_note = f"width pruning ON (field='{self.join_fl_reach_width_field}', "

        self.hydro_ids_set = set(self.hydro_ids.dropna().astype(str).tolist())
        disconnected_set = set(map(str, self.disconnected_ends))
        self.missing_ids_set = set()
        visited_global = set()

        for end in map(str, self.disconnected_ends):
            if end in visited_global:
                continue
            parent_rows = self._parents_of_end(end)
            candidate_children_groups = []
            if parent_rows:
                for pr in parent_rows:
                    siblings = self._siblings_in_row(pr, exclude=end)
                    group = [end] + siblings
                    group = [c for c in group if c in disconnected_set]

                    if group:
                        candidate_children_groups.append(group)
            else:
                candidate_children_groups = [[end]]

            # For each group, prune by width and trace the survivors
            for group in candidate_children_groups:

                # Width-based preview on *each* tributary in this group
                children_to_trace = self._prune_children_by_width(group)
                stack = list(children_to_trace)
                local_visited = set()  # avoid loops within this start
                while stack:
                    cur = stack.pop()
                    if pd.isna(cur) or cur in local_visited or cur in visited_global:
                        continue
                    local_visited.add(cur)
                    visited_global.add(cur)

                    # stop if this reach already extracted
                    if cur in self.hydro_ids_set:
                        continue

                    # record as missing
                    self.missing_ids_set.add(cur)

                    # fanout at this node
                    children = self.down_map_all.get(cur, [])
                    if not children:
                        continue

                    # prune children (recursively applies at each junction)
                    kept_children = self._prune_children_by_width(children)
                    # push all kept children for DFS
                    stack.extend(kept_children)

        # Also keep a legacy structure compatible with your export (list of sequences)
        if self.missing_ids_set:
            self.disconnected_segments = [list(self.missing_ids_set)]
        else:
            self.disconnected_segments = []

        # print message that is explicit about width usage
        print(f"Traced {len(self.missing_ids_set)} missing reaches ({width_note}).")

    # Export unchanged except using the set
    def export_missing_reaches(self):
        if not self.missing_ids_set:  # empty set -> False
            self.missing_reaches_gdf = self.orig_gdf.iloc[0:0].copy()
        else:
            # cast to the dtype of orig_ids for robust isin
            target_dtype = self.orig_ids.dtype
            missing_ids_series = pd.Series(list(self.missing_ids_set), dtype="string")
            # try to cast to compare dtype
            try:
                if pd.api.types.is_integer_dtype(target_dtype):
                    missing_ids_series = pd.to_numeric(
                        missing_ids_series, errors="coerce"
                    ).astype("Int64")
                elif (
                    pd.api.types.is_string_dtype(target_dtype) or target_dtype == object
                ):
                    missing_ids_series = missing_ids_series.astype("string")
                else:
                    missing_ids_series = missing_ids_series.astype(target_dtype)
                mask = self.orig_ids.isin(missing_ids_series)
            except Exception:
                # fallback: compare on string form
                oi = self.orig_ids.astype("string")
                mask = oi.isin(missing_ids_series.astype("string"))

            self.missing_reaches_gdf = self.orig_gdf.loc[mask].copy()

        missing_layer = (
            f"join_fl_traced_bifur_rches_{self.identifier}"
            if self.identifier
            else "join_fl_traced_bifur_rches"
        )
        self.missing_reaches_gdf.to_file(
            self.output_reach_gpkg, layer=missing_layer, driver="GPKG", mode="w"
        )

    # Merge extracted reaches with missing reaches and finalize
    def merge_and_save_final(self):

        # Align CRS BEFORE concatenation
        if self.missing_reaches_gdf.crs != self.extract_gdf_no_joinedAtrr.crs:
            self.missing_reaches_gdf = self.missing_reaches_gdf.to_crs(
                self.extract_gdf_no_joinedAtrr.crs
            )

        merged_gdf = gpd.GeoDataFrame(
            pd.concat(
                [self.extract_gdf_no_joinedAtrr, self.missing_reaches_gdf],
                ignore_index=True,
            ),
            crs=self.extract_gdf_no_joinedAtrr.crs,
        )

        merged_gdf = merged_gdf.drop_duplicates(subset=["geometry"])

        if self.identifier:
            self.final_layer = f"join_fl_final_reaches_{self.identifier}"
        else:
            self.final_layer = "join_fl_final_reaches"

        self.result = merged_gdf

        # Remove the existing layer
        try:
            fiona.remove(self.output_final_reach_gpkg, layer=self.final_layer)
            print(
                f"Removed existing layer '{self.final_layer}' from {self.output_final_reach_gpkg}."
            )
        except Exception as ex:
            # If something is off (e.g., layer missing), we still proceed to write
            print(f"Warning: couldn’t remove layer '{self.final_layer}': {ex}")

        merged_gdf.to_file(
            self.output_final_reach_gpkg,
            layer=self.final_layer,
            driver="GPKG",
            mode="w",
        )

    def print_summary(self):
        print(
            f"Saved reconstructed reaches to {self.output_final_reach_gpkg}/{self.final_layer}"
        )
