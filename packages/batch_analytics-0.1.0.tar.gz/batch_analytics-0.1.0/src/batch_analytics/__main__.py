"""Allow python -m batch_analytics to run the job runner."""

from .job_runner import main
import sys
sys.exit(main())
