"""
Batch analytics pipeline: Extract, Transform, Log stages + analytics modules.

Stages:
  - Extract: Load data from ClickHouse via Spark ClickHouse connector or JDBC
  - Transform: Deduplicate and stage data (parquet/delta/clickhouse)
  - Log: Persist run metadata and analytics results

Analytics modules:
  - Module 1: Linear regression (XY) with slope comparison across groups
  - Module 2: Multi-feature correlation
  - Module 3: PCA + KMeans clustering
"""

from .config import BatchAnalyticsConfig, SparkK8sConfig
from .extract import extract_all, extract_table, extract_unified
from .transform import (
    extract_anchor_id,
    load_staged,
    remove_duplicates,
    stage_to_clickhouse,
    transform,
    transform_and_stage,
)
from .log import log_analytics_artifacts, log_run
from .job_runner import run_pipeline, create_spark_session

__all__ = [
    "BatchAnalyticsConfig",
    "SparkK8sConfig",
    "extract_anchor_id",
    "extract_all",
    "extract_table",
    "extract_unified",
    "remove_duplicates",
    "stage_to_clickhouse",
    "transform",
    "transform_and_stage",
    "load_staged",
    "log_run",
    "log_analytics_artifacts",
    "run_pipeline",
    "create_spark_session",
]
