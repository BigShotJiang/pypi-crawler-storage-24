"""
Base output driver interface and write orchestration.
"""

import json
import logging
from abc import ABC, abstractmethod
from typing import Any

logger = logging.getLogger(__name__)


def _serialize_for_json(obj: Any) -> Any:
    """Convert numpy/Python types to JSON-serializable forms."""
    import numpy as np

    if isinstance(obj, dict):
        return {k: _serialize_for_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_serialize_for_json(x) for x in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.float32, np.float64)):
        return float(obj)
    if isinstance(obj, (np.integer, np.int32, np.int64)):
        return int(obj)
    if isinstance(obj, np.bool_):
        return bool(obj)
    return obj


class OutputDriver(ABC):
    """Interface for writing analytics results to a destination."""

    @abstractmethod
    def write(
        self,
        run_id: str,
        task_id: str,
        artifacts: dict[str, Any],
    ) -> list[str]:
        """
        Write analytics artifacts to the destination.

        Args:
            run_id: Unique run identifier
            task_id: Task identifier from spark_runner
            artifacts: Dict of module_name -> result (e.g. {"linear_regression": {...}})

        Returns:
            List of written locations (paths, keys, or identifiers)
        """
        pass


def write_analytics_output(
    run_id: str,
    task_id: str,
    artifacts: dict[str, Any],
    output_type: str,
    **driver_kwargs: Any,
) -> list[str]:
    """
    Write analytics results using the configured output driver.

    Args:
        run_id: Run identifier
        task_id: Task identifier (from TASK_ID env or run_id fallback)
        artifacts: Analytics module outputs
        output_type: local | s3 | clickhouse
        **driver_kwargs: Driver-specific config (path, database, table, etc.)

    Returns:
        List of written locations
    """
    if not artifacts:
        logger.debug("No analytics artifacts to write")
        return []

    output_type = (output_type or "local").lower().strip()
    if output_type == "local":
        driver = LocalOutputDriver(**driver_kwargs)
    elif output_type == "s3":
        driver = S3OutputDriver(**driver_kwargs)
    elif output_type == "clickhouse":
        driver = ClickHouseOutputDriver(**driver_kwargs)
    else:
        logger.warning("Unknown OUTPUT_TYPE=%r, falling back to local", output_type)
        driver = LocalOutputDriver(**driver_kwargs)

    try:
        locations = driver.write(run_id, task_id, artifacts)
        logger.info("Wrote analytics output to %s: %s", output_type, locations)
        return locations
    except Exception as e:
        logger.exception("Failed to write analytics output: %s", e)
        raise
