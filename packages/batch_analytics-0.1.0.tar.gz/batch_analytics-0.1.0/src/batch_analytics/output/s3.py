"""
S3 output driver: uploads analytics results as JSON to S3.
"""

import json
import logging
from typing import Any

from .base import OutputDriver, _serialize_for_json

logger = logging.getLogger(__name__)


class S3OutputDriver(OutputDriver):
    """Upload analytics artifacts to S3 as JSON objects."""

    def __init__(
        self,
        path: str,
        region: str | None = None,
        endpoint: str | None = None,
        **kwargs: Any,
    ) -> None:
        """
        Args:
            path: S3 path (e.g. s3://bucket/prefix/) - must end with /
            region: AWS region (default from env)
            endpoint: Custom endpoint for S3-compatible storage
        """
        self.path = path.rstrip("/") + "/"
        self.region = region
        self.endpoint = endpoint

    def _client(self):
        """Lazy boto3 client to avoid import at module load."""
        try:
            import boto3
            from botocore.config import Config
        except ImportError as e:
            raise ImportError(
                "S3 output requires boto3. Install with: pip install batch-analytics[s3]"
            ) from e

        config = Config(signature_version="s3v4")
        client_kwargs: dict[str, Any] = {}
        if self.region:
            client_kwargs["region_name"] = self.region
        if self.endpoint:
            client_kwargs["endpoint_url"] = self.endpoint

        return boto3.client("s3", config=config, **client_kwargs)

    def _parse_s3_path(self) -> tuple[str, str]:
        """Parse s3://bucket/prefix into bucket and prefix."""
        if not self.path.startswith("s3://"):
            raise ValueError(f"Invalid S3 path: {self.path}")
        parts = self.path[5:].split("/", 1)  # Remove s3://
        bucket = parts[0]
        prefix = parts[1].rstrip("/") + "/" if len(parts) > 1 else ""
        return bucket, prefix

    def write(
        self,
        run_id: str,
        task_id: str,
        artifacts: dict[str, Any],
    ) -> list[str]:
        bucket, prefix = self._parse_s3_path()
        client = self._client()

        # Use task_id for path: prefix/task_id/run_id_analytics_module.json
        key_prefix = f"{prefix}{task_id}/"

        locations: list[str] = []
        for name, data in artifacts.items():
            key = f"{key_prefix}{run_id}_analytics_{name}.json"
            body = json.dumps(_serialize_for_json(data), indent=2)
            client.put_object(Bucket=bucket, Key=key, Body=body, ContentType="application/json")
            locations.append(f"s3://{bucket}/{key}")

        logger.info("Uploaded %d analytics artifacts to s3://%s/%s", len(locations), bucket, key_prefix)
        return locations
