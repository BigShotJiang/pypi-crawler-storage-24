"""
ClickHouse output driver: inserts analytics results into a ClickHouse table.
"""

import json
import logging
from typing import Any

from .base import OutputDriver, _serialize_for_json

logger = logging.getLogger(__name__)


def _create_table_sql(database: str, table: str) -> str:
    """CREATE TABLE IF NOT EXISTS for analytics results."""
    return f"""
    CREATE TABLE IF NOT EXISTS {database}.{table} (
        task_id String,
        run_id String,
        module String,
        result String,
        created_at DateTime DEFAULT now()
    ) ENGINE = MergeTree()
    ORDER BY (task_id, run_id, module)
    """


class ClickHouseOutputDriver(OutputDriver):
    """Insert analytics artifacts into a ClickHouse table as JSON strings."""

    def __init__(
        self,
        database: str,
        table: str,
        host: str | None = None,
        port: int = 8123,
        user: str = "default",
        password: str = "",
        **kwargs: Any,
    ) -> None:
        self.database = database
        self.table = table
        self.host = host
        self.port = port
        self.user = user
        self.password = password

    def _client(self):
        """Lazy clickhouse-connect client."""
        try:
            import clickhouse_connect
        except ImportError as e:
            raise ImportError(
                "ClickHouse output requires clickhouse-connect. "
                "Install with: pip install batch-analytics[clickhouse]"
            ) from e

        return clickhouse_connect.get_client(
            host=self.host or "localhost",
            port=self.port,
            username=self.user,
            password=self.password if self.password else None,
        )

    def write(
        self,
        run_id: str,
        task_id: str,
        artifacts: dict[str, Any],
    ) -> list[str]:
        client = self._client()

        # Ensure table exists
        client.command(_create_table_sql(self.database, self.table).strip())

        rows: list[tuple[str, str, str, str]] = []
        for module, data in artifacts.items():
            result_json = json.dumps(_serialize_for_json(data))
            rows.append((task_id, run_id, module, result_json))

        client.insert(
            f"{self.database}.{self.table}",
            rows,
            column_names=["task_id", "run_id", "module", "result"],
        )

        location = f"{self.database}.{self.table}"
        logger.info("Inserted %d analytics rows into %s", len(rows), location)
        return [location]
