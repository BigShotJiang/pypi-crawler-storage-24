"""
Output drivers for analytics results: local, S3, ClickHouse.

Configuration via env vars (injected by analytics_runner):
- OUTPUT_TYPE: local | s3 | clickhouse
- OUTPUT_S3_PATH: s3://bucket/prefix/ (when type=s3)
- OUTPUT_CLICKHOUSE_DATABASE, OUTPUT_CLICKHOUSE_TABLE (when type=clickhouse)
- TASK_ID: task identifier (injected by spark_runner)
"""

from .base import OutputDriver, write_analytics_output
from .local import LocalOutputDriver
from .s3 import S3OutputDriver
from .clickhouse import ClickHouseOutputDriver

__all__ = [
    "OutputDriver",
    "write_analytics_output",
    "LocalOutputDriver",
    "S3OutputDriver",
    "ClickHouseOutputDriver",
]
