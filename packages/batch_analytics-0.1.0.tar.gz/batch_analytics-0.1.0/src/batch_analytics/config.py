"""
Configuration for batch analytics pipeline: Extract, Transform, Log stages.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ClickHouseConfig:
    """ClickHouse connection settings."""

    host: str = field(
        default_factory=lambda: os.environ.get(
            "CLICKHOUSE_HOST",
            "my-simple-cluster-clickhouse-headless.default.svc.cluster.local",
        )
    )
    port: int = int(os.environ.get("CLICKHOUSE_HTTP_PORT", "8123"))
    database: str = os.environ.get("CLICKHOUSE_DB", "example_db")
    user: str = os.environ.get("CLICKHOUSE_USER", "default")
    password: str = os.environ.get("CLICKHOUSE_PASSWORD", "")
    protocol: str = os.environ.get("CLICKHOUSE_PROTOCOL", "http")

    @property
    def jdbc_url(self) -> str:
        return f"jdbc:ch://{self.host}:{self.port}/{self.database}"

    @property
    def jdbc_properties(self) -> dict:
        props = {"user": self.user, "driver": "com.clickhouse.jdbc.ClickHouseDriver"}
        if self.password:
            props["password"] = self.password
        return props


@dataclass
class ExtractConfig:
    """Extract stage configuration."""

    # Source table(s) - comma-separated for multiple, or single table name
    source_tables: str = os.environ.get(
        "BATCH_SOURCE_TABLES",
        "batch_details_table,manufacturing_table,yield_table,temperature_table",
    )
    # Use ClickHouse native connector (format) vs JDBC fallback
    use_native_connector: bool = os.environ.get(
        "BATCH_USE_NATIVE_CONNECTOR", "false"
    ).lower() == "true"


@dataclass
class TransformConfig:
    """Transform stage configuration."""

    # Columns to use for deduplication (comma-separated); empty = use all columns
    dedup_columns: str = os.environ.get("BATCH_DEDUP_COLUMNS", "")
    # Staging output path (local or S3)
    staging_path: str = os.environ.get(
        "BATCH_STAGING_PATH",
        "/tmp/analytics_stage",
    )
    # Output format for load_staged when reading (parquet/delta/clickhouse).
    # Stage job always writes to ClickHouse; use clickhouse for analytics to read from staged table.
    staging_format: str = os.environ.get("BATCH_STAGING_FORMAT", "clickhouse")
    # Staging table name in ClickHouse (when format=clickhouse)
    staging_table: str = os.environ.get("BATCH_STAGING_TABLE", "analytics_staging")
    # Extract anchor_id from add_dimension column (e.g. {'anchor_id':'GP/GPH(D)/II(W)/250019'})
    add_dimension_column: str = os.environ.get("BATCH_ADD_DIMENSION_COLUMN", "add_dimension")
    anchor_id_column: str = os.environ.get("BATCH_ANCHOR_ID_COLUMN", "anchor_id")


@dataclass
class LogConfig:
    """Log stage configuration."""

    log_path: str = os.environ.get(
        "BATCH_LOG_PATH",
        "/tmp/analytics_logs",
    )
    # Retention: number of runs to keep
    retention_runs: int = int(os.environ.get("BATCH_LOG_RETENTION", "30"))


@dataclass
class OutputConfig:
    """
    Output destination for analytics results (injected by analytics_runner).

    Env vars: OUTPUT_TYPE, OUTPUT_S3_PATH, OUTPUT_CLICKHOUSE_*, TASK_ID
    """

    type: str = os.environ.get("OUTPUT_TYPE", "local")
    s3_path: str = os.environ.get("OUTPUT_S3_PATH", "")
    clickhouse_database: str = os.environ.get("OUTPUT_CLICKHOUSE_DATABASE", "example_db")
    clickhouse_table: str = os.environ.get("OUTPUT_CLICKHOUSE_TABLE", "analytics_results")
    # Task ID from spark_runner (for S3 key prefix, ClickHouse task_id column)
    task_id: str = os.environ.get("TASK_ID", "")


@dataclass
class AnalyticsConfig:
    """Analytics modules configuration."""

    # Module 1: Linear regression - X and Y column names
    lr_x_column: str = os.environ.get("BATCH_LR_X_COLUMN", "x")
    lr_y_column: str = os.environ.get("BATCH_LR_Y_COLUMN", "y")
    # Groups to compare slopes (e.g. "product,batch_no")
    lr_group_columns: str = os.environ.get("BATCH_LR_GROUP_COLUMNS", "")

    # Module 2: Correlation - feature columns (comma-separated)
    corr_features: str = os.environ.get(
        "BATCH_CORR_FEATURES",
        "",
    )
    corr_threshold: float = float(os.environ.get("BATCH_CORR_THRESHOLD", "0.8"))

    # Module 3: PCA + Clustering
    pca_features: str = os.environ.get("BATCH_PCA_FEATURES", "")
    pca_variance_threshold: float = float(
        os.environ.get("BATCH_PCA_VARIANCE_THRESHOLD", "0.95")
    )
    cluster_k: int = int(os.environ.get("BATCH_CLUSTER_K", "3"))

    # Module 4: T-test - compare means of two groups
    # Mode 1: value column + group column (2 levels)
    ttest_value_column: str = os.environ.get("BATCH_TTEST_VALUE_COLUMN", "")
    ttest_group_column: str = os.environ.get("BATCH_TTEST_GROUP_COLUMN", "")
    # Mode 2: two numeric columns
    ttest_col_a: str = os.environ.get("BATCH_TTEST_COL_A", "")
    ttest_col_b: str = os.environ.get("BATCH_TTEST_COL_B", "")


@dataclass
class SparkK8sConfig:
    """Spark on Kubernetes configuration."""

    # Set SPARK_MASTER=k8s://https://kubernetes.default.svc:443 to enable K8s
    master: str = os.environ.get("SPARK_MASTER", "local[*]")
    container_image: str = os.environ.get("SPARK_K8S_IMAGE", "sudhakso/spark:3.5.0")
    namespace: str = os.environ.get("SPARK_K8S_NAMESPACE", "default")
    service_account: str = os.environ.get("SPARK_K8S_SERVICE_ACCOUNT", "spark-sa")
    deploy_mode: str = os.environ.get("SPARK_DEPLOY_MODE", "client")
    # Driver/executor resources
    driver_memory: str = os.environ.get("SPARK_DRIVER_MEMORY", "512m")
    driver_memory_overhead: str = os.environ.get("SPARK_DRIVER_MEMORY_OVERHEAD", "256m")
    executor_instances: int = int(os.environ.get("SPARK_EXECUTOR_INSTANCES", "1"))
    executor_cores: int = int(os.environ.get("SPARK_EXECUTOR_CORES", "1"))
    executor_memory: str = os.environ.get("SPARK_EXECUTOR_MEMORY", "512m")
    executor_memory_overhead: str = os.environ.get("SPARK_EXECUTOR_MEMORY_OVERHEAD", "128m")
    # S3 (optional; set for s3a:// paths)
    s3_access_key: str = os.environ.get("AWS_ACCESS_KEY_ID", "")
    s3_secret_key: str = os.environ.get("AWS_SECRET_ACCESS_KEY", "")
    s3_endpoint: str = os.environ.get("AWS_ENDPOINT", "s3.amazonaws.com")
    s3_region: str = os.environ.get("AWS_REGION", "us-east-2")


@dataclass
class BatchAnalyticsConfig:
    """Aggregate configuration for the pipeline."""

    clickhouse: ClickHouseConfig = field(default_factory=ClickHouseConfig)
    spark_k8s: SparkK8sConfig = field(default_factory=SparkK8sConfig)
    extract: ExtractConfig = field(default_factory=ExtractConfig)
    transform: TransformConfig = field(default_factory=TransformConfig)
    log: LogConfig = field(default_factory=LogConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    analytics: AnalyticsConfig = field(default_factory=AnalyticsConfig)
