"""
Batch analytics job runner: orchestrates Extract, Transform, Log stages and analytics modules.
"""

import argparse
import logging
import os
import socket
import sys
import uuid
from pathlib import Path

from pyspark.sql import SparkSession

from .config import BatchAnalyticsConfig
from .extract import extract_unified
from .log import log_dataframe_summary, log_run
from .modules import DEFAULT_MODULES, MODULE_REGISTRY, VALID_MODULES
from .output import write_analytics_output
from .transform import load_staged, stage_to_clickhouse, transform

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


def create_spark_session(
    app_name: str = "BatchAnalytics",
    clickhouse_jars: str | None = None,
    config: BatchAnalyticsConfig | None = None,
) -> SparkSession:
    """
    Create SparkSession. Uses Kubernetes config when SPARK_MASTER starts with k8s://.
    """
    config = config or BatchAnalyticsConfig()
    cfg = config.spark_k8s

    builder = (
        SparkSession.builder.appName(app_name)
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
    )

    # JARs: ClickHouse JDBC + hadoop-aws (for S3 when on K8s)
    packages = []
    if clickhouse_jars:
        packages.append(clickhouse_jars)
    if cfg.master.startswith("k8s://"):
        packages.append("org.apache.hadoop:hadoop-aws:3.3.4")
    if packages:
        builder = builder.config("spark.jars.packages", ",".join(packages))

    if cfg.master.startswith("k8s://"):
        driver_host = socket.gethostbyname(socket.gethostname())
        builder = (
            builder.master(cfg.master)
            .config("spark.kubernetes.container.image", cfg.container_image)
            .config("spark.kubernetes.namespace", cfg.namespace)
            .config("spark.kubernetes.authenticate.serviceAccountName", cfg.service_account)
            .config("spark.driver.host", driver_host)
            .config("spark.driver.bindAddress", "0.0.0.0")
            .config(
                "spark.kubernetes.driver.pod.name",
                os.environ.get("HOSTNAME", socket.gethostname()),
            )
            .config("spark.submit.deployMode", cfg.deploy_mode)
            .config(
                "spark.driver.extraJavaOptions",
                "-Djava.net.preferIPv4Stack=true -XX:+UseG1GC -XX:+HeapDumpOnOutOfMemoryError",
            )
            .config("spark.driver.memory", cfg.driver_memory)
            .config("spark.driver.memoryOverhead", cfg.driver_memory_overhead)
            .config("spark.executor.instances", str(cfg.executor_instances))
            .config("spark.executor.cores", str(cfg.executor_cores))
            .config("spark.executor.memory", cfg.executor_memory)
            .config("spark.executor.memoryOverhead", cfg.executor_memory_overhead)
            .config("spark.kubernetes.executor.serviceAccountName", cfg.service_account)
            .config("spark.kubernetes.container.image.pullPolicy", "IfNotPresent")
        )
        if cfg.s3_access_key and cfg.s3_secret_key:
            builder = (
                builder.config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
                .config("spark.hadoop.fs.s3a.access.key", cfg.s3_access_key)
                .config("spark.hadoop.fs.s3a.secret.key", cfg.s3_secret_key)
                .config("spark.hadoop.fs.s3a.endpoint", cfg.s3_endpoint)
                .config("spark.hadoop.fs.s3a.endpoint.region", cfg.s3_region)
            )
        logger.info("Spark on Kubernetes: master=%s", cfg.master)

    return builder.getOrCreate()


def run_pipeline(
    config: BatchAnalyticsConfig | None = None,
    spark: SparkSession | None = None,
    run_extract: bool = True,
    run_transform: bool = True,
    run_stage: bool = True,
    run_analytics: bool = True,
    modules: list[str] | None = None,
) -> dict:
    """
    Run the full pipeline or selected stages.

    Args:
        config: Pipeline config (default: BatchAnalyticsConfig())
        spark: SparkSession (created if None)
        run_extract: Whether to extract from ClickHouse
        run_transform: Whether to transform (clean, dedupe, extract anchor_id)
        run_stage: Whether to stage transformed data to ClickHouse (separate job)
        run_analytics: Whether to run analytics (requires staged data in ClickHouse)
        modules: Which analytics to run: ["lr", "corr", "pca", "ttest"] or None for all

    Returns:
        Dict with run_id, stage results, analytics outputs
    """
    config = config or BatchAnalyticsConfig()
    run_id = str(uuid.uuid4())[:8]

    if spark is None:
        jars = "com.clickhouse:clickhouse-jdbc:0.4.6:all"
        spark = create_spark_session(
            app_name="BatchAnalytics",
            clickhouse_jars=jars,
            config=config,
        )

    result = {"run_id": run_id, "stages": {}, "analytics": {}}

    # ----- Extract -----
    if run_extract:
        logger.info("Stage: Extract")
        df_raw = extract_unified(spark, config)
        result["stages"]["extract"] = {
            "row_count": df_raw.count(),
            "columns": [f.name for f in df_raw.schema.fields],
        }
    else:
        logger.info("Stage: Extract (skipped, loading from stage)")
        df_raw = load_staged(spark, config)
        result["stages"]["extract"] = {"skipped": True, "loaded_from_stage": True}

    # ----- Transform -----
    if run_transform:
        logger.info("Stage: Transform")
        df_transformed = transform(df_raw, config)
        result["stages"]["transform"] = {"row_count": df_transformed.count()}
    else:
        df_transformed = df_raw  # df_raw already loaded from staged when not run_extract
        if run_extract and run_analytics:
            from .transform import extract_anchor_id, remove_duplicates

            df_transformed = extract_anchor_id(df_raw, config)
            dedup_cols = (
                [c.strip() for c in config.transform.dedup_columns.split(",") if c.strip()]
                if config.transform.dedup_columns
                else None
            )
            df_transformed = remove_duplicates(df_transformed, key_columns=dedup_cols)
        result["stages"]["transform"] = {"skipped": True}

    # ----- Stage (to ClickHouse) - separate job before analytics -----
    if run_stage:
        logger.info("Stage: Stage to ClickHouse")
        stage_to_clickhouse(spark, df_transformed, config)
        result["stages"]["stage"] = {
            "destination": f"{config.clickhouse.database}.{config.transform.staging_table}",
            "row_count": df_transformed.count(),
        }
    else:
        result["stages"]["stage"] = {"skipped": True}

    # For analytics: use in-memory df (we always have df_transformed from transform/load)
    df_for_analytics = df_transformed

    # ----- Log stage metrics -----
    log_run(
        run_id,
        "pipeline",
        result["stages"],
        output_dir=config.log.log_path,
        extra={"config_summary": {"staging_format": config.transform.staging_format}},
    )

    # ----- Analytics (runs after stage; must run extract+transform+stage first, or use --from-stage) -----
    if run_analytics:
        modules = modules or DEFAULT_MODULES
        for mod in modules:
            if mod not in MODULE_REGISTRY:
                logger.warning("Unknown module %r, skipping. Valid: %s", mod, VALID_MODULES)
                continue
            run_fn, result_key = MODULE_REGISTRY[mod]
            try:
                mod_result = run_fn(spark, df_for_analytics, config)
                result["analytics"][result_key] = mod_result
            except Exception as e:
                logger.exception("%s failed: %s", result_key, e)
                result["analytics"][result_key] = {"error": str(e)}

        task_id = config.output.task_id or run_id
        write_analytics_output(
            run_id=run_id,
            task_id=task_id,
            artifacts=result["analytics"],
            output_type=config.output.type,
            path=config.log.log_path
            if config.output.type == "local"
            else config.output.s3_path,
            database=config.output.clickhouse_database,
            table=config.output.clickhouse_table,
            host=config.clickhouse.host,
            port=config.clickhouse.port,
            user=config.clickhouse.user,
            password=config.clickhouse.password,
        )

    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Batch analytics: Extract, Transform, Log + analytics")
    parser.add_argument(
        "--extract",
        action="store_true",
        default=True,
        help="Run extract stage (default: true)",
    )
    parser.add_argument(
        "--no-extract",
        action="store_false",
        dest="extract",
    )
    parser.add_argument(
        "--transform",
        action="store_true",
        default=True,
        help="Run transform stage (default: true)",
    )
    parser.add_argument(
        "--no-transform",
        action="store_false",
        dest="transform",
    )
    parser.add_argument(
        "--stage",
        action="store_true",
        default=True,
        help="Run stage step: write transformed data to ClickHouse (default: true)",
    )
    parser.add_argument(
        "--no-stage",
        action="store_false",
        dest="stage",
    )
    parser.add_argument(
        "--analytics",
        action="store_true",
        default=True,
        help="Run analytics modules (default: true)",
    )
    parser.add_argument(
        "--no-analytics",
        action="store_false",
        dest="analytics",
    )
    parser.add_argument(
        "--modules",
        nargs="+",
        choices=VALID_MODULES,
        default=None,
        help="Analytics modules to run (default: all). Must match catalog module_arg.",
    )
    parser.add_argument(
        "--from-stage",
        action="store_true",
        help="Load from staged ClickHouse table, run analytics only (implies --no-extract --no-transform --no-stage)",
    )
    args = parser.parse_args()

    if args.from_stage:
        args.extract = False
        args.transform = False
        args.stage = False

    result = run_pipeline(
        run_extract=args.extract,
        run_transform=args.transform,
        run_stage=args.stage,
        run_analytics=args.analytics,
        modules=args.modules,
    )

    logger.info("Run completed: %s", result["run_id"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
