"""
Extract stage: Load data from ClickHouse using Spark ClickHouse connector or JDBC.
"""

import logging
from typing import Any

from pyspark.sql import DataFrame, SparkSession

from .config import BatchAnalyticsConfig

logger = logging.getLogger(__name__)


def _read_via_format(spark: SparkSession, cfg: BatchAnalyticsConfig, table: str) -> DataFrame | None:
    """
    Read from ClickHouse using the native format API (clickhouse-spark-runtime).
    Requires: com.clickhouse.spark:clickhouse-spark-runtime in spark.jars.packages
    """
    try:
        df = (
            spark.read.format("clickhouse")
            .option("host", cfg.clickhouse.host)
            .option("protocol", cfg.clickhouse.protocol)
            .option("http_port", str(cfg.clickhouse.port))
            .option("database", cfg.clickhouse.database)
            .option("table", table)
            .option("user", cfg.clickhouse.user)
            .load()
        )
        return df
    except Exception as e:
        logger.warning(
            "Native ClickHouse connector failed for table %s: %s. Falling back to JDBC.",
            table,
            e,
        )
        return None


def _read_via_jdbc(spark: SparkSession, cfg: BatchAnalyticsConfig, table: str) -> DataFrame:
    """Read from ClickHouse via JDBC."""
    return spark.read.jdbc(
        cfg.clickhouse.jdbc_url,
        table,
        properties=cfg.clickhouse.jdbc_properties,
    )


def extract_table(
    spark: SparkSession,
    table: str,
    config: BatchAnalyticsConfig,
) -> DataFrame:
    """
    Extract a single table from ClickHouse.
    Uses native connector if configured, otherwise JDBC.
    """
    if config.extract.use_native_connector:
        df = _read_via_format(spark, config, table)
        if df is None:
            df = _read_via_jdbc(spark, config, table)
    else:
        df = _read_via_jdbc(spark, config, table)

    logger.info("Extracted table %s: %d rows", table, df.count())
    return df


def extract_all(
    spark: SparkSession,
    config: BatchAnalyticsConfig,
) -> dict[str, DataFrame]:
    """
    Extract all configured source tables from ClickHouse.
    Returns a dict mapping table name to DataFrame.
    """
    tables = [t.strip() for t in config.extract.source_tables.split(",") if t.strip()]
    if not tables:
        raise ValueError("No source tables configured in BATCH_SOURCE_TABLES")

    result: dict[str, DataFrame] = {}
    for table in tables:
        df = extract_table(spark, table, config)
        result[table] = df

    return result


def extract_unified(
    spark: SparkSession,
    config: BatchAnalyticsConfig,
    join_keys: list[str] | None = None,
    primary_table: str | None = None,
) -> DataFrame:
    """
    Extract and unify source tables into one DataFrame.
    - Single table: returns it directly.
    - Multiple tables + join_keys: joins on those keys (left join, first table base).
    - Multiple tables, no join_keys: returns the primary (or first) table.
      Use primary_table to choose which table to use for analytics.
    """
    all_dfs = extract_all(spark, config)

    if len(all_dfs) == 1:
        return list(all_dfs.values())[0]

    if join_keys:
        dfs = list(all_dfs.values())
        base = dfs[0]
        for other in dfs[1:]:
            base = base.join(other, on=join_keys, how="left")
        return base

    # Multiple tables, no join: use primary or first
    if primary_table and primary_table in all_dfs:
        return all_dfs[primary_table]
    return list(all_dfs.values())[0]
