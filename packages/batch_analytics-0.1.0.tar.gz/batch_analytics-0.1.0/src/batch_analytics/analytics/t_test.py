"""
Module 4: T-test to compare means of two sets of data.
"""

import logging
from typing import Any

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, avg, stddev, count
from pyspark.sql.types import DoubleType

from ..config import BatchAnalyticsConfig

logger = logging.getLogger(__name__)


def run_t_test(
    spark: SparkSession,
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> dict[str, Any]:
    """
    Perform an independent samples t-test to compare the means of two groups.

    Supports two modes:
    1. Value + group: one numeric column, one categorical column with 2 levels
    2. Two columns: two numeric columns, compare their means

    Uses Welch's t-test (does not assume equal variances).

    Returns:
        - group_a, group_b: names/summary of each group
        - mean_a, mean_b, std_a, std_b, n_a, n_b
        - t_statistic, p_value, difference (mean_a - mean_b)
    """
    value_col = (config.analytics.ttest_value_column or "").strip()
    group_col = (config.analytics.ttest_group_column or "").strip()
    col_a = (config.analytics.ttest_col_a or "").strip()
    col_b = (config.analytics.ttest_col_b or "").strip()

    # Mode 1: value column + group column (both required)
    if value_col and group_col and value_col in df.columns and group_col in df.columns:
        return _run_t_test_by_group(df, value_col, group_col)

    # Mode 2: two numeric columns
    if col_a and col_b and col_a in df.columns and col_b in df.columns:
        return _run_t_test_two_columns(df, col_a, col_b)

    # Fallback: find first numeric + first string-like column with 2 distinct values
    numeric_cols = [
        f.name for f in df.schema.fields
        if "double" in str(f.dataType).lower()
        or "int" in str(f.dataType).lower()
        or "float" in str(f.dataType).lower()
    ]
    string_cols = [
        f.name for f in df.schema.fields
        if "string" in str(f.dataType).lower()
    ]
    for nc in numeric_cols:
        for sc in string_cols:
            distinct = df.select(sc).distinct().count()
            if distinct == 2:
                logger.info("Auto-selected t-test: value=%s, group=%s", nc, sc)
                return _run_t_test_by_group(df, nc, sc)

    raise ValueError(
        "T-test requires either (BATCH_TTEST_VALUE_COLUMN + BATCH_TTEST_GROUP_COLUMN) "
        "or (BATCH_TTEST_COL_A + BATCH_TTEST_COL_B). "
        f"Available columns: {df.columns}"
    )


def _run_t_test_by_group(
    df: DataFrame,
    value_col: str,
    group_col: str,
) -> dict[str, Any]:
    """T-test: compare mean of value_col across two levels of group_col."""
    df_num = df.select(
        col(value_col).cast(DoubleType()).alias("_val"),
        col(group_col).cast("string").alias("_grp"),
    ).filter(col("_val").isNotNull() & col("_grp").isNotNull())

    stats = (
        df_num.groupBy("_grp")
        .agg(
            avg("_val").alias("mean"),
            stddev("_val").alias("std"),
            count("_val").alias("n"),
        )
        .collect()
    )

    if len(stats) != 2:
        raise ValueError(
            f"T-test requires exactly 2 groups in {group_col}. Found: {[r['_grp'] for r in stats]}"
        )

    r0, r1 = stats[0], stats[1]
    return _compute_t_test_result(
        group_a=r0["_grp"],
        mean_a=float(r0["mean"]),
        std_a=float(r0["std"] or 0.0),
        n_a=int(r0["n"]),
        group_b=r1["_grp"],
        mean_b=float(r1["mean"]),
        std_b=float(r1["std"] or 0.0),
        n_b=int(r1["n"]),
    )


def _run_t_test_two_columns(df: DataFrame, col_a: str, col_b: str) -> dict[str, Any]:
    """T-test: compare means of two numeric columns."""
    df_num = df.select(
        col(col_a).cast(DoubleType()).alias("_a"),
        col(col_b).cast(DoubleType()).alias("_b"),
    ).filter(col("_a").isNotNull() & col("_b").isNotNull())

    row = df_num.agg(
        avg("_a").alias("mean_a"),
        stddev("_a").alias("std_a"),
        count("_a").alias("n_a"),
        avg("_b").alias("mean_b"),
        stddev("_b").alias("std_b"),
        count("_b").alias("n_b"),
    ).collect()[0]

    return _compute_t_test_result(
        group_a=col_a,
        mean_a=float(row["mean_a"]),
        std_a=float(row["std_a"] or 0.0),
        n_a=int(row["n_a"]),
        group_b=col_b,
        mean_b=float(row["mean_b"]),
        std_b=float(row["std_b"] or 0.0),
        n_b=int(row["n_b"]),
    )


def _compute_t_test_result(
    group_a: str,
    mean_a: float,
    std_a: float,
    n_a: int,
    group_b: str,
    mean_b: float,
    std_b: float,
    n_b: int,
) -> dict[str, Any]:
    """Compute Welch's t-test from summary statistics."""
    try:
        from scipy import stats
    except ImportError:
        raise ImportError("T-test requires scipy. Install with: pip install scipy")

    t_stat, p_value = stats.ttest_ind_from_stats(
        mean1=mean_a,
        std1=std_a,
        nobs1=n_a,
        mean2=mean_b,
        std2=std_b,
        nobs2=n_b,
        equal_var=False,  # Welch's t-test
    )

    return {
        "group_a": {
            "name": group_a,
            "mean": mean_a,
            "std": std_a,
            "n": n_a,
        },
        "group_b": {
            "name": group_b,
            "mean": mean_b,
            "std": std_b,
            "n": n_b,
        },
        "t_statistic": float(t_stat),
        "p_value": float(p_value),
        "mean_difference": mean_a - mean_b,
        "test": "Welch",
    }
