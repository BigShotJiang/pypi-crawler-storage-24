# Copyright 2025 ICube (University of Strasbourg - CNRS)
# author: Julien PONTABRY (ICube)
#
# This software is a computer program whose purpose is to provide a toolkit
# to model, process and analyze the longitudinal reorganization of brain
# connectivity data, as functional MRI for instance.
#
# This software is governed by the CeCILL-B license under French law and
# abiding by the rules of distribution of free software. You can use,
# modify and/or redistribute the software under the terms of the CeCILL-B
# license as circulated by CEA, CNRS and INRIA at the following URL
# "http://www.cecill.info".
#
# As a counterpart to the access to the source code and rights to copy,
# modify and redistribute granted by the license, users are provided only
# with a limited warranty and the software's author, the holder of the
# economic rights, and the successive licensors have only limited
# liability.
#
# In this respect, the user's attention is drawn to the risks associated
# with loading, using, modifying and/or developing or reproducing the
# software by the user in light of its specific status of free software,
# that may mean that it is complicated to manipulate, and that also
# therefore means that it is reserved for developers and experienced
# professionals having in-depth computer knowledge. Users are therefore
# encouraged to load and test the software's suitability as regards their
# requirements in conditions enabling the security of their systems and/or
# data to be ensured and, more generally, to use and operate it in the
# same conditions as regards security.
#
# The fact that you are presently reading this means that you have had
# knowledge of the CeCILL-B license and that you accept its terms.

import numpy as np


def integer_tick_step(max_val: int, max_range: int = 5) -> int:
    """Return a tick step so that ticks land only on integers.

    For small ranges (≤ `max_range`) every integer is shown.  For larger ranges the step
    is chosen so that roughly 8 ticks appear, avoiding float tick values.
    """
    if max_val <= max_range:
        return 1
    return max(1, round(max_val / 8))


def hex_to_rgba(hex_color: str, alpha: float) -> str:
    """Convert a hex colour string to an RGBA CSS string.

    Parameters
    ----------
    hex_color : str
        Colour in ``#RRGGBB`` format (e.g. ``'#636EFA'``).
    alpha : float
        Opacity in the range [0, 1].

    Returns
    -------
    str
        Colour in ``rgba(R, G, B, alpha)`` format suitable for Plotly.
    """
    r = int(hex_color[1:3], 16)
    g = int(hex_color[3:5], 16)
    b = int(hex_color[5:7], 16)
    return f'rgba({r},{g},{b},{alpha})'


def norm_min_max_size(s: list[float], new_min: float = 0, new_max: float = 1) -> list[float]:
    s_min = np.min(s)
    s_max = np.max(s)
    scale = s_max - s_min
    return ((new_max - new_min) * np.subtract(s, s_min) / scale + new_min).tolist()