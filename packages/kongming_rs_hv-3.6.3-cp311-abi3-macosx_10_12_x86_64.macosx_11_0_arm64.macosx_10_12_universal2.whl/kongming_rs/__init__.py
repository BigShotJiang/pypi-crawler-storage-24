from .kongming_rs import hv  # noqa: F401 — triggers Rust extension init
from .kongming_rs import HvError, REASON_NOT_FOUND  # noqa: F401
