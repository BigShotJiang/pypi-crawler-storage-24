"""Aegis CLI."""
