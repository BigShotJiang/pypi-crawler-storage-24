"""
Basic smoke tests for SpotterSec scanner.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from spottersec import scan_yaml_string, compute_risk_score


BAD_POD = open(os.path.join(os.path.dirname(__file__), "fixtures/bad_pod.yaml")).read()
GOOD_POD = open(os.path.join(os.path.dirname(__file__), "fixtures/good_pod.yaml")).read()

CLUSTER_ADMIN_BINDING = """
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: bad-binding
subjects:
- kind: ServiceAccount
  name: default
  namespace: default
roleRef:
  kind: ClusterRole
  name: cluster-admin
  apiGroup: rbac.authorization.k8s.io
"""

BAD_RBAC = """
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: wildcard-role
rules:
- apiGroups: ["*"]
  resources: ["*"]
  verbs: ["*"]
"""


def test_bad_pod_has_critical_findings():
    findings = scan_yaml_string(BAD_POD, "bad_pod.yaml")
    severities = [f.severity for f in findings]
    assert "CRITICAL" in severities, f"Expected CRITICAL findings, got: {severities}"


def test_bad_pod_finds_privileged():
    findings = scan_yaml_string(BAD_POD, "bad_pod.yaml")
    rule_ids = [f.rule_id for f in findings]
    assert "SC001" in rule_ids, "SC001 (privileged: true) should be detected"


def test_bad_pod_finds_hostpath():
    findings = scan_yaml_string(BAD_POD, "bad_pod.yaml")
    rule_ids = [f.rule_id for f in findings]
    assert "VOL001" in rule_ids, "VOL001 (hostPath /) should be detected"


def test_bad_pod_finds_host_namespaces():
    findings = scan_yaml_string(BAD_POD, "bad_pod.yaml")
    rule_ids = [f.rule_id for f in findings]
    assert "NS001" in rule_ids, "NS001 (hostPID) should be detected"
    assert "NS002" in rule_ids, "NS002 (hostNetwork) should be detected"


def test_good_pod_has_no_critical():
    findings = scan_yaml_string(GOOD_POD, "good_pod.yaml")
    critical = [f for f in findings if f.severity == "CRITICAL"]
    assert len(critical) == 0, f"Good pod should have no CRITICAL findings, got: {[f.rule_id for f in critical]}"


def test_cluster_admin_binding_detected():
    findings = scan_yaml_string(CLUSTER_ADMIN_BINDING, "binding.yaml")
    rule_ids = [f.rule_id for f in findings]
    assert "RBAC001" in rule_ids, "RBAC001 (cluster-admin binding) should be detected"


def test_wildcard_rbac_detected():
    findings = scan_yaml_string(BAD_RBAC, "role.yaml")
    rule_ids = [f.rule_id for f in findings]
    assert "RBAC006" in rule_ids or "RBAC003" in rule_ids, \
        f"Wildcard RBAC should be detected, got: {rule_ids}"


def test_risk_score_bad_pod():
    findings = scan_yaml_string(BAD_POD, "bad_pod.yaml")
    risk = compute_risk_score(findings)
    assert risk["score"] >= 70, f"Bad pod should have high risk score, got {risk['score']}"
    assert risk["grade"] in ("D", "F"), f"Bad pod should grade D or F, got {risk['grade']}"


def test_risk_score_good_pod():
    findings = scan_yaml_string(GOOD_POD, "good_pod.yaml")
    risk = compute_risk_score(findings)
    assert risk["score"] < 30, f"Good pod should have low risk score, got {risk['score']}"


def test_findings_have_required_fields():
    findings = scan_yaml_string(BAD_POD, "bad_pod.yaml")
    for f in findings:
        assert f.rule_id, "Finding must have rule_id"
        assert f.severity in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"), \
            f"Invalid severity: {f.severity}"
        assert f.title, "Finding must have title"
        assert f.resource_key, "Finding must have resource_key"
