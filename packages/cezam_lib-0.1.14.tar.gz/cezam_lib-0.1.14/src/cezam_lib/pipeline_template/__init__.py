"""Template de base pour les pipelines spécialisés CEZAM."""

__version__ = "0.1.14"

from .base_pipeline import BasePipeline
from .extractor import DataExtractor
from .messages import FusionMessage, PipelineMessage

__all__ = [
    "BasePipeline",
    "DataExtractor",
    "FusionMessage",
    "PipelineMessage",
]
