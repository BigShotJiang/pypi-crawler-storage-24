"""Bibliothèque partagée pour les microservices CEZAM.

Ce module fournit les clients et utilitaires communs pour l'infrastructure:
- MinIOClient: Client legacy pour les opérations JSON sur MinIO
- DatalakeClient: Client S3 pour le bucket datalake (lecture/écriture)
- SourceClient: Client S3 pour le bucket source (lecture seule)
- datalake_paths: Fonctions de construction de chemins normalisés
- RabbitMQPublisher: Publisher avec propagation OTel
- RabbitMQConsumer: Consumer avec gestion automatique ack/nack
- setup_otel: Configuration OpenTelemetry
"""

from .exceptions import (
    MinIOError,
    RabbitMQError,
    RetryableError,
    NonRetryableError,
)
from .minio_client import MinIOClient
from .datalake_client import DatalakeClient
from .format_adaptater import FormatAdapter
from .source_client import SourceClient
from . import datalake_paths
from .rabbitmq import RabbitMQPublisher, RabbitMQConsumer
from .otel import (
    setup_otel,
    inject_trace_context,
    extract_trace_context,
)

__version__ = "0.1.14"

__all__ = [
    "MinIOClient",
    "DatalakeClient",
    "FormatAdapter",
    "SourceClient",
    "datalake_paths",
    "MinIOError",
    "RabbitMQPublisher",
    "RabbitMQConsumer",
    "RabbitMQError",
    "RetryableError",
    "NonRetryableError",
    "setup_otel",
    "inject_trace_context",
    "extract_trace_context",
    "__version__",
]
