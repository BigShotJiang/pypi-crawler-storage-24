# Rotwood TEX Tool

KTEX texture packer + converter for [Rotwood](https://store.steampowered.com/app/2015270/Rotwood/).

## Installation

Requirements:

- Python 3.12+
- ImageMagick

### Windows

Install dependencies

- [Python](https://python.org) (Check "Add python.exe to PATH")
- [ImageMagick](https://imagemagick.org) ("Windows Binary Release" .exe installer)

Install rwtextool

- From PyPI (recommended):
	1. Open a terminal window
	2. Run `pip install rwtextool`
- From source repo:
	1. Download repo ZIP or `git clone` (if you have [Git](https://git-scm.com))
	2. Open terminal widnow in rwtextool directory
	3. Run `pip install .`

Now you can use `tex2img` and `img2tex` system-wide, see [Usage](#usage) for more details.

### Linux

Install dependencies

```shell
# Debian
sudo apt install git imagemagick python3
sudo apt install python3-venv  # for venv
sudo apt install python3-pip  # for global pip

# Arch Linux
sudo pacman -S git imagemagick python
sudo pacman -S python-pip  # for global pip

# Fedora
sudo dnf install git ImageMagick python3
sudo dnf install python3-pip  # for global pip
```

#### Install from PyPI

```shell
pip install rwtextool
```

#### Install from source

> [!NOTE]
> The commands used below might differ a bit depending on your platform/Linux distro, sometimes it will be `python`, sometimes it's `python3`.

```shell
git clone https://codeberg.org/gibbert/rwtextool
cd rwtextool

# virtual environment
	python3 -m venv .venv
	source .venv/bin/activate
	pip install .

# install system-wide (not recommended)
	sudo pip install --break-system-packages .
```

### Nix flake

This repo includes a Nix flake that provides a package under `packages."x86_64".default`.

There are 2 executables, `tex2img` and `img2tex`.

With `nix run` (uses `tex2img` by default)

```shell
nix run "git+https://codeberg.org/gibbert/rwtextool" -- --help
```

With `nix shell`

```shell
nix shell "git+https://codeberg.org/gibbert/rwtextool"
tex2img --help
img2tex --help
```

Example Nix flake input:

```nix
nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";

rwtextool = {
	url = "git+https://codeberg.org/gibbert/rwtextool";
	inputs.nixpkgs.follows = "nixpkgs";
};
```

For outputs I have `specialArgs = { inherit inputs; };`

In modules:

```nix
{ pkgs, inputs, ... }: {
	environment.systemPackages = [
		inputs.rwtextool.packages.${pkgs.stdenv.hostPlatform.system}.default
	];
}
```

## Usage

Extract image from tex files

```shell
tex2img --auto-atlas ui_ftf_power_icons1.tex
```

Pack folder of textures

```shell
img2tex directory/path
```

More detailed `--help` info

### Unpacking TEX+XML to PNGs

```txt
usage: tex2img [-h] [-A] [-a ATLAS_PATH] [-v] tex_path

Unpacks a Rotwood Klei TEX file (and XML atlas) to PNG images.

positional arguments:
  tex_path              TEX texture file

options:
  -h, --help            show this help message and exit
  -A, --auto-atlas      Automatically find and use the XML atlas matching the
                        texture file name
  -a, --atlas ATLAS_PATH
                        XML atlas file, the result unpacked images will be
                        placed in a new directory
  -v, --verbose         Output verbosity level (can stack) (warnings, info,
                        all info)
```

### Packing PNGs into TEX+XML

```txt
usage: img2tex [-h] [-v] source_path

  Packs a directory of PNG images into Rotwood Klei TEX textures and atlases.

  positional arguments:
    source_path    Directory of PNG files

  options:
    -h, --help     show this help message and exit
    -v, --verbose  Output verbosity level (can stack) (warnings, info, all info)
```

## License

This project uses the GPL 3 or later license (see [LICENSE](./LICENSE)).
