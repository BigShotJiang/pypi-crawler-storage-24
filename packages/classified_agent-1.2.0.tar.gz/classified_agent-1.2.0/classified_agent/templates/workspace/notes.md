# Agent Workspace Notes

This file is your agent's scratchpad. It can read and write
files in this directory via its filesystem tools.

Use this for:
- Task planning and sub-task breakdowns
- Intermediate observations and findings
- Progress tracking
- Notes to self for future iterations

---

*Created by `classified-agent init`*
