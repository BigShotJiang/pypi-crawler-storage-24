# Agent Workspace

This directory is your agent's working area. All file operations
(reads, writes, listings) are confined to this directory.

## Contents

| File | Purpose |
|------|---------|
| `notes.md` | Agent scratchpad — free-form notes and observations |
| `state.json` | Runtime state tracking (managed by the agent) |

## Rules

- The agent can read and write any file inside this directory
- File paths outside workspace are blocked by the sandboxed FS tools
- The agent may create subdirectories as needed
- Use `notes.md` for intermediate reasoning and progress tracking

## Managed by

This workspace was created by `classified-agent init`.
The agent runtime manages `state.json` automatically.
