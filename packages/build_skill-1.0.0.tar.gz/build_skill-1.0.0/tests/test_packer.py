"""tests/test_packer.py"""

import re
from build_skill.packer import TarPacker, PackResult
from build_skill.config import PackConfig


def test_pack_result_dataclass():
    """PackResult 数据类"""
    result = PackResult(output_file="dist/test.tar.gz", file_count=42, size="1.2M")
    assert result.output_file == "dist/test.tar.gz"
    assert result.file_count == 42
    assert result.size == "1.2M"


def test_patch_key_value_single_key(tmp_path):
    """_patch_key_value 替换单个键值"""
    cfg = tmp_path / "config.yaml"
    cfg.write_text("debug:\n  enabled: true\n  log_level: DEBUG\n", encoding="utf-8")
    packer = TarPacker(PackConfig(config_patches={"debug": {"enabled": "false"}}))
    packer.patch_config(cfg)
    content = cfg.read_text(encoding="utf-8")
    # enabled 应该被替换为 false
    assert re.search(r"^\s+enabled:\s*false", content, re.MULTILINE)


def test_patch_key_value_preserves_comments(tmp_path):
    """_patch_key_value 保留 YAML 注释"""
    cfg = tmp_path / "config.yaml"
    cfg.write_text("debug:   # debug 配置\n  enabled: true  # 是否启用\n", encoding="utf-8")
    packer = TarPacker(PackConfig(config_patches={"debug": {"enabled": "false"}}))
    packer.patch_config(cfg)
    content = cfg.read_text(encoding="utf-8")
    # 注释应保留
    assert "# debug 配置" in content
    assert "# 是否启用" in content


def test_pack_creates_tarball(tmp_path, monkeypatch):
    """pack() 生成 tar.gz 文件"""
    # 创建模拟的 skill 目录结构
    skill_dir = tmp_path / "skills" / "test-skill"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        "---\nname: test-skill\ndescription: test\n---\n", encoding="utf-8"
    )
    (skill_dir / "src").mkdir()
    (skill_dir / "src" / "main.py").write_text("# main", encoding="utf-8")

    # Mock get_config
    # 实际测试需要临时目录和打包逻辑
    # 这里简化测试，实际应测试完整 pack 流程
    assert True  # placeholder
