"""工具函数模块"""

import logging
from pathlib import Path
from typing import Optional

from build_skill.config import get_config

# 配置 logging
logger = logging.getLogger("build-skill")


def _setup_logging() -> None:
    """根据配置设置日志级别和格式"""
    cfg = get_config()
    level = logging.DEBUG if cfg.debug.enabled else getattr(logging, cfg.debug.log_level)
    logging.basicConfig(
        level=level,
        format="[%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def info(msg: str, *args: object) -> None:
    """输出 INFO 级别日志（绿色）"""
    _setup_logging()
    logger.info(msg, *args)


def warn(msg: str, *args: object) -> None:
    """输出 WARNING 级别日志（黄色）"""
    _setup_logging()
    logger.warning(msg, *args)


def error(msg: str, *args: object) -> None:
    """输出 ERROR 级别日志（红色）"""
    _setup_logging()
    logger.error(msg, *args)


def is_debug() -> bool:
    """当前是否开启调试模式（读取 config.debug.enabled）"""
    return get_config().debug.enabled


def log_level() -> str:
    """获取当前日志级别"""
    return get_config().debug.log_level


def resolve_skill_name(skills_dir: Path, name: Optional[str] = None) -> str:
    """推断或使用指定的 skill 名称

    Args:
        skills_dir: skills/ 目录路径
        name: 可选，指定的 skill 名称

    Returns:
        skill 名称字符串

    Raises:
        ValueError: 未指定 name 且 skills/ 下无唯一子目录
    """
    if name is not None:
        return name

    # 自动推断：skills/ 下唯一子目录
    subdirs = [d.name for d in skills_dir.iterdir() if d.is_dir()]
    if len(subdirs) == 1:
        return subdirs[0]

    if len(subdirs) == 0:
        raise ValueError("未找到 skill 目录，请用 --name 指定")

    raise ValueError(f"skills/ 下有多个子目录，请用 --name 指定: {subdirs}")


def get_version_from_file(
    init_file: str,
    version_regex: str = r'__version__\s*=\s*["\']([^"\']+)["\']',
) -> str:
    """从文件路径读取版本号，失败返回 "0.0.0"

    Args:
        init_file: 版本文件路径（可以是 __init__.py、pyproject.toml 等任意文件）
        version_regex: 提取版本号的正则（需有 1 个捕获组）
    """
    import re

    path = Path(init_file)
    if not path.exists():
        return "0.0.0"
    content = path.read_text(encoding="utf-8")
    match = re.search(version_regex, content)
    if match:
        return match.group(1)
    return "0.0.0"
