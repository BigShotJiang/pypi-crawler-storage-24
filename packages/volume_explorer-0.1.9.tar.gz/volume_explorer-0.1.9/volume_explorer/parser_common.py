"""
Shared helpers for Petrel volumetrics parsers.
"""

from __future__ import annotations

from datetime import datetime

from .constants import VOLUME_COLS
from .storage import try_float


def strip_row(line: str) -> list[str]:
    """Split a tab-separated line and trim trailing empty cells."""
    cells = line.split("\t")
    while cells and cells[-1].strip() == "":
        cells.pop()
    return cells


def parse_rows(text: str) -> list[list[str]]:
    """Split raw text into cleaned rows."""
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    return [strip_row(l) for l in lines]


def find_row(rows: list[list[str]], label: str, start: int = 0,
             exact: bool = False) -> int | None:
    """Find the first row whose first cell matches *label*."""
    for i, r in enumerate(rows[start:], start):
        if r:
            val = r[0].strip()
            if exact and val == label:
                return i
            if not exact and val.lower().startswith(label.lower()):
                return i
    return None


def row_val(rows: list[list[str]], idx: int | None, col: int = 1) -> str:
    """Extract a cell value from a specific row/column."""
    if idx is not None and idx < len(rows) and len(rows[idx]) > col:
        return rows[idx][col].strip()
    return ""


def find_case_header(rows: list[list[str]]) -> int | None:
    """Find the row index of the 'Case' header row."""
    for i, r in enumerate(rows):
        if len(r) > 2 and r[0].strip() == "Case" and "Bulk volume" in r[1]:
            return i
    return None


def normalise_cat_label(label: str) -> str:
    """Normalise a category row label to an internal key."""
    low = label.strip().lower()
    if "zone" in low:
        return "zones"
    if "facies" in low or "faci" in low:
        return "facies"
    if "contact" in low or "region" in low or "segment" in low:
        return "contact_regions"
    if "boundary" in low or "boundaries" in low:
        return "boundaries"
    return low.replace(" ", "_")


def cat_key_to_record_col(cat_key: str) -> str:
    """Map a category key to its column name in detailed records."""
    mapping = {
        "zones": "zone",
        "facies": "facies",
        "contact_regions": "region",
        "boundaries": "boundary",
    }
    return mapping.get(cat_key, cat_key)


def parse_metadata(rows: list[list[str]]) -> dict:
    """Parse the header metadata block common to both formats."""
    meta: dict = {}
    meta["software"] = rows[0][0].strip() if rows and rows[0] else ""

    idx = find_row(rows, "User name")
    meta["user"] = row_val(rows, idx)

    idx = find_row(rows, "Date")
    meta["date_raw"] = row_val(rows, idx)
    try:
        meta["date_parsed"] = datetime.strptime(
            meta["date_raw"], "%A, %B %d %Y %H:%M:%S"
        ).isoformat()
    except Exception:
        meta["date_parsed"] = meta["date_raw"]

    idx = find_row(rows, "Project")
    meta["project"] = row_val(rows, idx)

    idx = find_row(rows, "Model")
    meta["model"] = row_val(rows, idx)

    idx = find_row(rows, "Grid")
    meta["grid"] = row_val(rows, idx)

    idx = find_row(rows, "Input XY unit")
    meta["xy_unit"] = row_val(rows, idx)

    idx = find_row(rows, "Input Z unit")
    meta["z_unit"] = row_val(rows, idx)

    idx = find_row(rows, "HC intervals")
    meta["hc_intervals"] = row_val(rows, idx)

    idx = find_row(rows, "Gas oil contact")
    meta["gas_oil_contact"] = row_val(rows, idx)

    idx = find_row(rows, "Lower oil contact")
    if idx is None:
        idx = find_row(rows, "Oil water contact")
    meta["oil_water_contact"] = row_val(rows, idx)

    idx = find_row(rows, "Porosity")
    meta["porosity_property"] = row_val(rows, idx)

    idx = find_row(rows, "Net gross")
    meta["ntg_property"] = row_val(rows, idx)

    # Gas interval properties
    gas_props = {}
    idx_gas = find_row(rows, "Properties in gas interval")
    if idx_gas is not None:
        for j in range(idx_gas + 1, min(idx_gas + 10, len(rows))):
            if not rows[j] or not rows[j][0].strip():
                break
            key = rows[j][0].strip().rstrip(":")
            vals = [c.strip() for c in rows[j][1:] if c.strip()]
            if len(vals) >= 2 and vals[1].startswith("["):
                gas_props[key] = {"value": try_float(vals[0]), "unit": vals[1]}
            else:
                gas_props[key] = vals[0] if len(vals) == 1 else vals
    meta["gas_interval"] = gas_props

    # Oil interval properties
    oil_props = {}
    idx_oil = find_row(rows, "Properties in oil interval")
    if idx_oil is not None:
        for j in range(idx_oil + 1, min(idx_oil + 10, len(rows))):
            if not rows[j] or not rows[j][0].strip():
                break
            key = rows[j][0].strip().rstrip(":")
            vals = [c.strip() for c in rows[j][1:] if c.strip()]
            if len(vals) >= 2 and vals[1].startswith("["):
                oil_props[key] = {"value": try_float(vals[0]), "unit": vals[1]}
            else:
                oil_props[key] = vals[0] if len(vals) == 1 else vals
    meta["oil_interval"] = oil_props

    idx = find_row(rows, "Facies", 0, exact=True)
    meta["facies_property"] = row_val(rows, idx)

    idx = find_row(rows, "Contact regions", 0)
    meta["contact_regions_property"] = row_val(rows, idx)

    idx = find_row(rows, "Boundaries used")
    boundaries = []
    if idx is not None:
        for j in range(idx + 1, min(idx + 10, len(rows))):
            if not rows[j] or not rows[j][0].strip():
                break
            boundaries.append(rows[j][0].strip())
    meta["boundaries"] = boundaries

    return meta
