"""
PetrelVolumetrics — Read, store, query & explore Petrel volume reports.

Usage (Jupyter):
    from volume_explorer import PetrelVolumetrics

    # Read from clipboard (copy the Petrel volumetrics table first)
    pv = PetrelVolumetrics.from_clipboard()

    # Query volumes
    pv.stoiip(by='zone')
    pv.giip(by=['zone', 'facies'])
    pv.volumes(metric='stoiip', zone='Agat Sand 2 - Top Sola', by='facies')

    # Multi-case summary table
    pv.summary_table(metrics=['stoiip', 'giip'], zone=['Sand 2', 'Sand 3'])

    # Aliases — rename items for display, control ordering
    pv.aliases({
        'zones': [
            {'name': 'Agat Sand 2 - Top Sola', 'alias': 'Sand 2'},
        ],
    })

    # Streamlit dashboard
    # streamlit run -m volume_explorer.app.main
"""

from __future__ import annotations

from importlib.metadata import version as _pkg_version

from pathlib import Path

import pandas as pd

__version__ = _pkg_version("volume-explorer")

from .aliases import AliasMixin
from .name_maps import NameMapMixin
from .constants import (
    VOLUME_COLS,
    SHORT_NAMES,
    BASE_DIR_NAME,
    _TRIVIAL,
    resolve_metric,
    resolve_category,
    cat_to_df_col,
)
from .layouts import (
    Layout,
    save_layout as _save_layout,
    load_layouts as _load_layouts,
    get_layout as _get_layout,
    delete_layout as _delete_layout,
    list_layouts as _list_layouts,
)
from .parser import parse_raw
from .query import (
    build_detailed_df,
    volumes as _q_volumes,
    pivot as _q_pivot,
    table as _q_table,
    summary_table as _q_summary_table,
)
from .storage import (
    base_dir as _base_dir,
    discover_projects,
    load_data,
    save_data,
    save_from_clipboard,
    load_settings as _load_settings,
    save_settings as _save_settings,
    load_units as _load_units,
)
from .styling import StyledHTML, run_label, style_table
from .units import (
    format_metric,
    get_multiplier,
    apply_units_to_df,
    set_multipliers as _set_multipliers,
    get_multipliers as _get_multipliers,
    clear_multipliers as _clear_multipliers,
)

BASE_DIR = Path(BASE_DIR_NAME)


class _PVCache:
    """Simple load-once cache keyed by file path."""

    def __init__(self, cls: type):
        self._cls = cls
        self._store: dict[str, "PetrelVolumetrics"] = {}

    def get(self, path: Path) -> "PetrelVolumetrics":
        key = str(path)
        if key not in self._store:
            self._store[key] = self._cls.load(path)
        return self._store[key]

    def run_options(self, files: list[Path]) -> list[tuple[str, str]]:
        opts = []
        for f in files:
            try:
                pv = self.get(f)
                lbl = run_label(pv, fallback=f.stem)
            except Exception:
                lbl = f.stem
            opts.append((lbl, str(f)))
        return opts


class PetrelVolumetrics(AliasMixin, NameMapMixin):
    """
    Read, store, query and explore Petrel volumetrics exports.

    Supports both Petrel export formats (pivot and single-line)
    with automatic detection.
    """

    def __init__(self, data: dict, source_path: str | Path | None = None):
        self._data = data
        self._source_path = Path(source_path) if source_path else None
        self._detailed_df: pd.DataFrame | None = None
        if "aliases" not in self._data:
            self._data["aliases"] = {}

    # ================================================================
    # Properties
    # ================================================================

    @property
    def metadata(self) -> dict:
        return self._data["metadata"]

    def metadata_display(self) -> dict:
        """Return metadata with null/empty fields removed."""
        return {
            k: v for k, v in self.metadata.items()
            if v is not None and v != "" and v != "N/A"
            and v != {} and v != [] and v != "?"
        }

    @property
    def project(self) -> str:
        return self.metadata.get("project", "")

    @property
    def model(self) -> str:
        return self.metadata.get("model", "")

    @property
    def grid(self) -> str:
        return self.metadata.get("grid", "")

    @property
    def date(self) -> str:
        return self.metadata.get("date_parsed", self.metadata.get("date_raw", ""))

    @property
    def case_name(self) -> str:
        """Name of the first (or only) case."""
        cases = self._data.get("cases", [])
        if cases:
            return cases[0]
        # Legacy fallback
        legacy = self._data.get("_legacy_case", {})
        return legacy.get("name", self._data.get("case", {}).get("name", ""))

    @property
    def case_names(self) -> list[str]:
        """All case names in this dataset."""
        return list(self._data.get("cases", []))

    @property
    def title(self) -> str:
        return self._data.get("header", "")

    @title.setter
    def title(self, value: str):
        self._data["header"] = value
        self._save()

    @property
    def header(self) -> str:
        """Alias for title."""
        return self.title

    @header.setter
    def header(self, value: str):
        self.title = value

    @property
    def parameters(self) -> dict:
        params = self._data.get("parameters", {})
        if isinstance(params, dict) and self.case_names:
            # Return first case's parameters for backward compat
            first = self.case_names[0]
            if first in params:
                return params[first]
        # Legacy fallback
        legacy = self._data.get("_legacy_case", {})
        return legacy.get("parameters", params)

    @property
    def categories(self) -> dict[str, list[str]]:
        return self._data.get("categories", {})

    @property
    def category_keys(self) -> list[str]:
        return list(self.categories.keys())

    @property
    def totals(self) -> dict:
        """Total volumes for the first case (backward compat)."""
        legacy = self._data.get("_legacy_case", {})
        if legacy:
            return legacy.get("volumes", {})
        # Compute from detailed data
        df = self._get_detailed_df()
        if df.empty:
            return {}
        case_filter = self.case_names[0] if self.case_names else None
        if case_filter and "case" in df.columns:
            df = df[df["case"] == case_filter]
        return {col: df[col].sum() for col in VOLUME_COLS if col in df.columns}

    @property
    def metrics(self) -> list[str]:
        return list(SHORT_NAMES.keys())

    @property
    def format(self) -> str:
        """Which parser format was detected: 'pivot' or 'single_line'."""
        return self._data.get("format", "pivot")

    def __getattr__(self, name: str):
        if name.startswith("_"):
            raise AttributeError(name)
        cats = self._data.get("categories", {})
        if name in cats:
            return list(cats[name])
        raise AttributeError(
            f"'{type(self).__name__}' has no attribute '{name}'. "
            f"Available categories: {list(cats.keys())}"
        )

    # ================================================================
    # I/O
    # ================================================================

    @classmethod
    def from_clipboard(cls, base_dir: str | Path = BASE_DIR) -> "PetrelVolumetrics":
        """Read from clipboard, auto-detect format, parse, save JSON, return."""
        try:
            raw = pd.io.clipboards.clipboard_get()
        except (ImportError, AttributeError):
            try:
                raw = pd.io.clipboard.clipboard_get()
            except (ImportError, AttributeError):
                import subprocess
                raw = subprocess.check_output(
                    "powershell -command Get-Clipboard", shell=True
                ).decode("utf-8")

        data = parse_raw(raw)
        out_path = save_from_clipboard(data, Path(base_dir))

        print(f"✓ Saved → {out_path}  [format: {data.get('format', '?')}]")
        obj = cls(data, source_path=out_path)
        obj._print_summary()
        return obj

    @classmethod
    def load(cls, path: str | Path) -> "PetrelVolumetrics":
        """Load a saved JSON volumetrics file."""
        path = Path(path)
        data = load_data(path)
        return cls(data, source_path=path)

    @classmethod
    def load_all(cls, base_dir: str | Path = BASE_DIR) -> list["PetrelVolumetrics"]:
        """Load every JSON file under base_dir."""
        base = Path(base_dir)
        results = []
        for project, files in discover_projects(base).items():
            for p in files:
                try:
                    results.append(cls.load(p))
                except Exception as e:
                    print(f"⚠ Skipped {p}: {e}")
        return results

    def _save(self):
        """Persist data (incl. aliases) to JSON."""
        if self._source_path and self._source_path.exists():
            save_data(self._data, self._source_path)

    # ================================================================
    # DataFrames
    # ================================================================

    def _get_detailed_df(self) -> pd.DataFrame:
        if self._detailed_df is not None:
            return self._detailed_df
        self._detailed_df = build_detailed_df(self._data)
        return self._detailed_df

    def _base_dir(self) -> Path:
        return _base_dir(self._source_path)

    def _metric_display(self, short: str) -> tuple[str, float]:
        return format_metric(short, self._base_dir())

    # ================================================================
    # Query methods
    # ================================================================

    def volumes(
        self,
        metric: str | list[str] = "stoiip",
        by: str | list[str] | None = None,
        zone: str | list[str] | None = None,
        facies: str | list[str] | None = None,
        region: str | list[str] | None = None,
        case: str | list[str] | None = None,
        tag: str | None = None,
        exclude_zero: bool = True,
        use_aliases: bool = True,
    ) -> pd.DataFrame:
        """Flexible volume query. Use tag= to filter cases by scenario tag."""
        multi = isinstance(metric, list)
        metrics = metric if multi else [metric]
        case = self._resolve_tag_to_cases(tag, case)

        result = _q_volumes(
            self._data, metric=metric, by=by,
            zone=zone, facies=facies, region=region, case=case,
            exclude_zero=exclude_zero,
        )

        if use_aliases and not result.empty:
            result = self._apply_name_maps_to_df(result)
            result = self._apply_aliases_to_df(result)
            result = apply_units_to_df(result, metrics, self._base_dir())
        return result

    def stoiip(self, **kw) -> pd.DataFrame:
        return self.volumes(metric="stoiip", **kw)

    def giip(self, **kw) -> pd.DataFrame:
        return self.volumes(metric="giip", **kw)

    def hcpv(self, phase: str = "oil", **kw) -> pd.DataFrame:
        return self.volumes(metric=f"hcpv_{phase}", **kw)

    def bulk(self, **kw) -> pd.DataFrame:
        return self.volumes(metric="bulk", **kw)

    def net(self, **kw) -> pd.DataFrame:
        return self.volumes(metric="net", **kw)

    def pore(self, **kw) -> pd.DataFrame:
        return self.volumes(metric="pore", **kw)

    def pivot(self, metric: str = "stoiip", rows: str = "zone",
              columns: str = "facies", tag: str | None = None,
              use_aliases: bool = True, **kw) -> pd.DataFrame:
        """Create a pivot table. Use tag= to filter cases by scenario tag."""
        if tag is not None:
            kw["case"] = self._resolve_tag_to_cases(tag, kw.get("case"))
        pt = _q_pivot(self._data, metric=metric, rows=rows, columns=columns, **kw)
        if use_aliases and not pt.empty:
            pt = self._apply_name_maps_to_df(pt)
            pt = self._apply_aliases_to_df(pt)
        _, mult = self._metric_display(metric)
        if mult != 1.0:
            pt = pt * mult
        return pt

    def table(self, metric: str = "stoiip", by: list[str] | None = None,
              tag: str | None = None, use_aliases: bool = True, **kw) -> pd.DataFrame:
        """N-dimensional pivot table. Use tag= to filter cases by scenario tag."""
        if tag is not None:
            kw["case"] = self._resolve_tag_to_cases(tag, kw.get("case"))
        pt = _q_table(
            self._data, metric=metric, by=by,
            ordered_category_keys=self._ordered_category_keys(), **kw,
        )
        if use_aliases and not pt.empty:
            pt = self._apply_name_maps_to_df(pt)
            pt = self._apply_aliases_to_df(pt)
        _, mult = self._metric_display(metric)
        if mult != 1.0:
            pt = pt * mult
        return pt

    def summary_table(
        self,
        metrics: list[str] | None = None,
        runs: list["PetrelVolumetrics"] | None = None,
        labels: list[str] | None = None,
        zone: str | list[str] | None = None,
        facies: str | list[str] | None = None,
        region: str | list[str] | None = None,
        tag: str | None = None,
        exclude_zero: bool = True,
        use_aliases: bool = True,
    ) -> pd.DataFrame:
        """
        Multi-case, multi-metric summary table.

        For single-line multi-case data, operates on self._data.
        For comparing separate pivot files, pass runs=[pv1, pv2, ...].
        Use tag= to filter cases by scenario tag.
        """
        if metrics is None:
            metrics = ["bulk", "net", "pore", "hcpv_oil", "hcpv_gas", "stoiip", "giip"]

        case = self._resolve_tag_to_cases(tag, None)

        if runs is not None:
            result = _q_summary_table(
                runs=runs, metrics=metrics, labels=labels,
                zone=zone, facies=facies, region=region,
                exclude_zero=exclude_zero,
            )
        else:
            result = _q_summary_table(
                data=self._data, metrics=metrics, labels=labels,
                zone=zone, facies=facies, region=region,
                case=case,
                exclude_zero=exclude_zero,
            )

        if use_aliases and not result.empty:
            result = self._apply_name_maps_to_df(result)
            result = apply_units_to_df(result, metrics, self._base_dir())
        return result

    # ================================================================
    # Compare (backward compat)
    # ================================================================

    @staticmethod
    def compare(runs: list["PetrelVolumetrics"], metric: str = "stoiip",
                by: str = "zone", labels: list[str] | None = None) -> pd.DataFrame:
        """Compare a metric across runs side by side."""
        from datetime import datetime
        col = resolve_metric(metric)
        frames = []
        for i, pv in enumerate(runs):
            df = pv.volumes(metric=metric, by=by, exclude_zero=False, use_aliases=True)
            if labels and i < len(labels):
                label = labels[i]
            else:
                try:
                    dt = datetime.fromisoformat(pv.date)
                    date_str = dt.strftime("%d/%m/%y")
                except Exception:
                    date_str = pv.date[:10]
                label = f"{pv.model} ({date_str})"
            data_col = list(df.columns)[0]
            df = df.rename(columns={data_col: label})
            frames.append(df)
        if not frames:
            return pd.DataFrame()
        result = frames[0]
        for f in frames[1:]:
            result = result.join(f, how="outer")
        return result.fillna(0)

    # ================================================================
    # Multipliers
    # ================================================================

    @classmethod
    def set_multipliers(cls, *entries: dict, base_dir: str | Path = BASE_DIR):
        _set_multipliers(*entries, base=Path(base_dir))

    @classmethod
    def get_multipliers(cls, base_dir: str | Path = BASE_DIR) -> list[dict]:
        return _get_multipliers(Path(base_dir))

    @classmethod
    def clear_multipliers(cls, metric: str | None = None,
                          base_dir: str | Path = BASE_DIR):
        _clear_multipliers(metric, Path(base_dir))

    # ================================================================
    # Layouts
    # ================================================================

    @classmethod
    def save_layout(cls, name: str, base_dir: str | Path = BASE_DIR, **kw):
        """Save a named table layout configuration."""
        layout = Layout(name=name, **kw)
        _save_layout(layout, Path(base_dir))

    @classmethod
    def layouts(cls, base_dir: str | Path = BASE_DIR) -> list[str]:
        """List available layout names."""
        return _list_layouts(Path(base_dir))

    @classmethod
    def get_layout(cls, name: str, base_dir: str | Path = BASE_DIR) -> Layout | None:
        return _get_layout(name, Path(base_dir))

    @classmethod
    def delete_layout(cls, name: str, base_dir: str | Path = BASE_DIR):
        _delete_layout(name, Path(base_dir))

    def apply_layout(self, name: str, display: bool = True) -> pd.DataFrame:
        """Apply a saved layout to produce a table."""
        layout = _get_layout(name, self._base_dir())
        if layout is None:
            raise ValueError(f"Layout not found: {name}")

        filters = layout.filters or {}
        fmt_str = f"{{:,.{layout.decimals}f}}"

        if layout.format == "summary":
            df = self.summary_table(
                metrics=layout.metrics,
                zone=filters.get("zone"),
                facies=filters.get("facies"),
                region=filters.get("region"),
                exclude_zero=layout.hide_zeros,
            )
        elif layout.format == "pivot" and layout.pivot_columns:
            df = self.pivot(
                metric=layout.metrics[0] if layout.metrics else "stoiip",
                rows=layout.group_by[0] if layout.group_by else "zone",
                columns=layout.pivot_columns,
                zone=filters.get("zone"),
                facies=filters.get("facies"),
                region=filters.get("region"),
                margins=True,
                exclude_zero_rows=layout.hide_zeros,
                exclude_zero_cols=layout.hide_zeros,
            )
        else:
            metric_arg = layout.metrics if len(layout.metrics) > 1 else layout.metrics[0]
            df = self.volumes(
                metric=metric_arg,
                by=layout.group_by,
                zone=filters.get("zone"),
                facies=filters.get("facies"),
                region=filters.get("region"),
                exclude_zero=layout.hide_zeros,
            )

        if display:
            try:
                from IPython.display import display as _display
                title = layout.title or self.title or self.model
                styled = style_table(
                    df, fmt=fmt_str, dark=layout.dark,
                    title=title, subtotals=layout.show_subtotals,
                )
                _display(styled)
            except ImportError:
                print(df)

        return df

    # ================================================================
    # Clipboard
    # ================================================================

    def to_clipboard(self, metric: str = "stoiip", by: str = "zone", **kw):
        df = self.volumes(metric=metric, by=by, **kw)
        df.to_clipboard()
        print(f"✓ Copied ({len(df)} rows)")
        return df

    def pivot_to_clipboard(self, metric: str = "stoiip", rows: str = "zone",
                           columns: str = "facies", **kw):
        df = self.pivot(metric=metric, rows=rows, columns=columns, **kw)
        df.to_clipboard()
        print(f"✓ Copied ({df.shape[0]}×{df.shape[1]})")
        return df

    # ================================================================
    # Display
    # ================================================================

    def ls(self, category: str | None = None):
        """Print available items with aliases and ordering."""
        def _print_cat(label: str, items: list[str], alias_key: str | None = None):
            amap = self._alias_map(alias_key) if alias_key else {}
            order = self._alias_order(alias_key) if alias_key else None
            if order:
                ordered = [n for n in order if n in items]
                ordered += [n for n in items if n not in ordered]
            else:
                ordered = items
            print(f"\n  {label}:")
            for item in ordered:
                alias = amap.get(item)
                if alias and alias != item:
                    print(f"    {item}  →  {alias}")
                else:
                    print(f"    {item}")

        target = category.strip().lower() if category else None

        if target is None or target in ("metric", "metrics", "unit", "units"):
            base = self._base_dir()
            print(f"\n  Metrics:")
            for short, full in SHORT_NAMES.items():
                mult, result_unit = get_multiplier(short, base)
                from .units import default_metric_display
                dlabel, dabbrev = default_metric_display(full)
                unit = result_unit if result_unit else dabbrev
                disp = f"{dlabel} [{unit}]" if unit else full
                if mult != 1.0:
                    print(f"    {short:12s} {disp}  ×{mult}")
                else:
                    print(f"    {short:12s} {disp}")

        if target and target in ("metric", "metrics", "unit", "units"):
            return

        if target is None or target in ("category", "categories"):
            cat_aliases = {
                e["name"]: e.get("alias")
                for e in self._get_aliases().get("categories", [])
            }
            if cat_aliases or target in ("category", "categories"):
                print(f"\n  Categories:")
                for cat_key in self._ordered_category_keys():
                    display = self._cat_display_name(cat_key)
                    raw_label = cat_key.replace("_", " ").title()
                    if display != raw_label:
                        print(f"    {raw_label}  →  {display}")
                    else:
                        print(f"    {raw_label}")

        if target and target in ("category", "categories"):
            return

        for cat_key in self._ordered_category_keys():
            display_name = self._cat_display_name(cat_key)
            if target:
                norm = resolve_category(target) if target not in (
                    "metric", "metrics", "unit", "units", "category", "categories"
                ) else None
                if norm != cat_key:
                    continue
            _print_cat(display_name, self.categories[cat_key], alias_key=cat_key)

    def _print_summary(self):
        m = self.metadata_display()

        def _print_field(label: str, key: str):
            if key in m:
                print(f"  {label:18s}: {m[key]}")

        _print_field("Project", "project")
        _print_field("Model", "model")
        _print_field("Grid", "grid")
        _print_field("Date", "date_raw")

        fmt = self._data.get("format", "?")
        n_cases = len(self._data.get("cases", []))
        print(f"  {'Format':18s}: {fmt} ({n_cases} case{'s' if n_cases != 1 else ''})")
        if n_cases == 1:
            print(f"  {'Case':18s}: {self.case_name}")
        else:
            for cn in self.case_names[:5]:
                print(f"  {'Case':18s}: {cn}")
            if n_cases > 5:
                print(f"  {'':18s}  ... and {n_cases - 5} more")
        if self.title:
            print(f"  {'Title':18s}: {self.title}")

        _print_field("HC intervals", "hc_intervals")
        _print_field("Gas-oil contact", "gas_oil_contact")
        _print_field("Oil-water contact", "oil_water_contact")

        for k in self._ordered_category_keys():
            v = self.categories[k]
            display = self._cat_display_name(k)
            non_trivial = [x for x in v if x not in _TRIVIAL]
            if non_trivial:
                print(f"  {display:18s}: {', '.join(non_trivial)}")

        base = self._base_dir()
        for short in ("stoiip", "giip"):
            raw_col = resolve_metric(short)
            totals = self.totals
            raw_val = totals.get(raw_col)
            if raw_val is None or raw_val == 0:
                continue
            display_col, mult = format_metric(short, base)
            if mult != 1.0:
                val = f"{float(raw_val) * mult:,.1f}"
            else:
                val = f"{float(raw_val):,.1f}" if isinstance(raw_val, (int, float)) else str(raw_val)
            print(f"  {display_col:18s}: {val}")

        # Show name maps / aliases / multipliers counts
        nm = self._load_name_maps()
        nm_count = sum(len(v) for k, v in nm.items() if k != "tags" and isinstance(v, dict))
        tag_count = len(nm.get("tags", {}))
        if nm_count:
            print(f"  {'Name maps':18s}: {nm_count} mappings")
        if tag_count:
            print(f"  {'Tags':18s}: {tag_count} defined")

        a = self._get_aliases()
        if a:
            print(f"  {'Aliases':18s}: {sum(len(v) for v in a.values())} defined")
        mults = _load_units(base).get("multipliers", [])
        if mults:
            n = sum(len(e.get("name", [])) for e in mults)
            print(f"  {'Multipliers':18s}: {n} metrics configured")

    def info(self):
        self._print_summary()

    def show(self, metric: str | list[str] = "stoiip", by: str | list[str] = "zone",
             dark: bool = False, subtotals: bool = False, **kw):
        try:
            from IPython.display import display
        except ImportError:
            print(self.volumes(metric=metric, by=by, **kw))
            return
        metrics = metric if isinstance(metric, list) else [metric]
        labels = [self._metric_display(m)[0] for m in metrics]
        metric_arg = metrics if len(metrics) > 1 else metrics[0]
        title = self.title if self.title else f"{self.model} — {' | '.join(labels)}"
        subtitle = f"{self.grid} | {self.case_name}"
        df = self.volumes(metric=metric_arg, by=by, **kw)
        display(style_table(df, dark=dark, title=title, subtitle=subtitle,
                            subtotals=subtotals))
        return df

    def __repr__(self):
        return (
            f"PetrelVolumetrics(project='{self.project}', model='{self.model}', "
            f"grid='{self.grid}', cases={self.case_names})"
        )

