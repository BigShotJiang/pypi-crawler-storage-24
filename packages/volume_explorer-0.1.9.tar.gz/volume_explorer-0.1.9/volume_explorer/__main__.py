"""Allow running via: python -m volume_explorer [workdir]"""
from volume_explorer.app import cli

cli()
