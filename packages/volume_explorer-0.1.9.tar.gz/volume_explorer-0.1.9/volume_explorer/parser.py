"""
Auto-detect and parse Petrel volumetrics exports.

Delegates to format-specific parsers:
  - parser_pivot.py — one case per export, summary + detailed breakdown
  - parser_multi_split.py — all cases in one export, wide column layout

Both formats produce the same unified output structure.
"""

from __future__ import annotations

from .parser_common import parse_rows, find_case_header, parse_metadata
from .parser_pivot import parse_pivot
from .parser_single_line import parse_single_line, is_single_line


def parse_raw(text: str) -> dict:
    """
    Auto-detect format and parse raw Petrel volumetrics text.

    Parameters
    ----------
    text : str
        Tab-separated text from clipboard (either pivot or multi-split format).

    Returns
    -------
    dict
        Unified data structure with keys:
        metadata, format, cases, parameters, categories, detailed, aliases
    """
    rows = parse_rows(text)

    if not rows or not rows[0] or "petrel" not in rows[0][0].lower():
        raise ValueError(
            "Input does not look like a Petrel volumetrics export. "
            "First cell should contain 'Petrel <version>'."
        )

    case_row = find_case_header(rows)
    if case_row is None:
        raise ValueError("Could not find 'Case' header row with volume columns.")

    meta = parse_metadata(rows)

    if is_single_line(rows, case_row):
        return parse_single_line(rows, case_row, meta)
    else:
        return parse_pivot(rows, case_row, meta)
