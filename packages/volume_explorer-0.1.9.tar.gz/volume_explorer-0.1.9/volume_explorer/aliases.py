"""
Alias system for display names and ordering of categories and values.

Provides AliasMixin to be mixed into PetrelVolumetrics.
"""

from __future__ import annotations

import pandas as pd

from .constants import _CAT_TO_DF_COL, resolve_category


class AliasMixin:
    """
    Mixin providing alias get/set/clear and DataFrame transformation.

    Expects the host class to have:
      - self._data  (dict with 'aliases' and 'categories' keys)
      - self._save()
    """

    # ---- Public API ----

    def _get_aliases(self) -> dict:
        return self._data.get("aliases", {})

    def aliases(self, mapping: dict | None = None) -> dict:
        """
        Get or merge aliases.

        Call without arguments to inspect current aliases.
        Call with a dict to merge (existing categories not mentioned
        are left untouched).

        Parameters
        ----------
        mapping : dict, optional
            Keys   → 'categories', or any category name
            Values → list of {'name': <original>, 'alias': <display>}
        """
        if mapping is None:
            return dict(self._get_aliases())

        current = self._data.setdefault("aliases", {})

        for input_key, entries in mapping.items():
            low = input_key.strip().lower()
            if low in ("metrics", "metric"):
                print("⚠ Use set_multipliers() for metric units/labels.")
                continue
            elif low in ("categories", "category"):
                norm_key = "categories"
            else:
                try:
                    norm_key = resolve_category(input_key)
                except ValueError:
                    norm_key = low.replace(" ", "_")

            # Merge: update existing entries by name, append new ones
            existing = {e["name"]: e for e in current.get(norm_key, [])}
            for entry in entries:
                name = entry.get("name", "")
                existing[name] = dict(entry)

            # Rebuild list preserving new-input order first, then remaining
            new_names = [e.get("name", "") for e in entries]
            ordered = [existing[n] for n in new_names if n in existing]
            for name, entry in existing.items():
                if name not in new_names:
                    ordered.append(entry)

            current[norm_key] = ordered

        self._save()
        return dict(current)

    def clear_aliases(self, category: str | None = None):
        """Clear aliases. Without arguments clears everything."""
        if category is None:
            self._data["aliases"] = {}
        else:
            low = category.strip().lower()
            if low in ("metrics", "metric"):
                print("⚠ Use clear_multipliers() for metric units.")
                self._data.get("aliases", {}).pop("metrics", None)
                self._save()
                return
            elif low in ("categories", "category"):
                norm_key = "categories"
            else:
                norm_key = resolve_category(category)
            self._data.get("aliases", {}).pop(norm_key, None)
        self._save()
        print(f"✓ Aliases cleared{'' if category is None else f' for {category}'}")

    # ---- Internal helpers ----

    def _alias_map(self, cat_key: str) -> dict[str, str]:
        """Return {original_name: alias} for a category."""
        return {
            e["name"]: e.get("alias", e["name"])
            for e in self._get_aliases().get(cat_key, [])
        }

    def _alias_order(self, cat_key: str) -> list[str] | None:
        """Return ordered original names from aliases, or None."""
        entries = self._get_aliases().get(cat_key, [])
        return [e["name"] for e in entries] if entries else None

    def _cat_display_name(self, cat_key: str) -> str:
        """Return the display name for a category key."""
        for e in self._get_aliases().get("categories", []):
            if e.get("name", "").lower().replace(" ", "_") == cat_key.lower():
                return e.get("alias", cat_key)
            if e.get("name", "").lower() == cat_key.lower().replace("_", " "):
                return e.get("alias", cat_key)
        return cat_key.replace("_", " ").title()

    def _ordered_category_keys(self) -> list[str]:
        """Return category keys in display order."""
        cat_entries = self._get_aliases().get("categories", [])
        data_keys = list(self._data.get("categories", {}).keys())

        if not cat_entries:
            return data_keys

        ordered = []
        for e in cat_entries:
            name = e.get("name", "")
            for dk in data_keys:
                if (dk.lower() == name.lower().replace(" ", "_")
                        or dk.lower().replace("_", " ") == name.lower()):
                    if dk not in ordered:
                        ordered.append(dk)
                    break

        for dk in data_keys:
            if dk not in ordered:
                ordered.append(dk)

        return ordered

    def _apply_aliases_to_df(self, df: pd.DataFrame) -> pd.DataFrame:
        """Rename and reorder index/columns according to category aliases."""
        df = df.copy()
        col_to_cat = {v: k for k, v in _CAT_TO_DF_COL.items()}
        col_to_cat["name"] = None

        # --- Index ---
        if isinstance(df.index, pd.MultiIndex):
            for level in range(df.index.nlevels):
                lname = df.index.names[level]
                cat = col_to_cat.get(lname)
                if not cat:
                    continue
                amap = self._alias_map(cat)
                order = self._alias_order(cat)
                if amap:
                    new_level = df.index.levels[level].map(
                        lambda x, m=amap: m.get(x, x)
                    )
                    df.index = df.index.set_levels(new_level, level=level)
                if order:
                    aliased = [amap.get(n, n) for n in order]
                    df = _reorder_mi(df, level, aliased)
        else:
            idx_name = df.index.name or "name"
            cat = col_to_cat.get(idx_name)
            if cat is None and idx_name == "name":
                cats = self._data.get("categories", {})
                for ck in self._ordered_category_keys():
                    if set(cats.get(ck, [])) & set(df.index):
                        cat = ck
                        break
            if cat:
                amap = self._alias_map(cat)
                order = self._alias_order(cat)
                if amap:
                    df.index = df.index.map(lambda x, m=amap: m.get(x, x))
                if order:
                    aliased = [amap.get(n, n) for n in order]
                    current = list(df.index)
                    new_order = [x for x in aliased if x in current]
                    new_order += [x for x in current if x not in new_order]
                    df = df.reindex(new_order)

        # --- Columns (pivot tables) ---
        if hasattr(df.columns, "name") and df.columns.name:
            cat = col_to_cat.get(df.columns.name)
            if cat:
                amap = self._alias_map(cat)
                order = self._alias_order(cat)
                if amap:
                    df.columns = df.columns.map(lambda x, m=amap: m.get(x, x))
                if order:
                    aliased = [amap.get(n, n) for n in order]
                    current = list(df.columns)
                    new_order = [x for x in aliased if x in current]
                    new_order += [x for x in current if x not in new_order]
                    df = df[new_order]

        # --- Rename axis labels ---
        def _axis_alias(axis_name):
            if not axis_name:
                return axis_name
            cat = col_to_cat.get(axis_name)
            if cat:
                display = self._cat_display_name(cat)
                default = cat.replace("_", " ").title()
                if display != default:
                    return display.lower()
            return axis_name

        if isinstance(df.index, pd.MultiIndex):
            df.index.names = [_axis_alias(n) for n in df.index.names]
        else:
            df.index.name = _axis_alias(df.index.name)

        if hasattr(df.columns, "name") and df.columns.name:
            df.columns.name = _axis_alias(df.columns.name)

        return df


def _reorder_mi(df: pd.DataFrame, level: int, order: list) -> pd.DataFrame:
    """Reorder a MultiIndex DataFrame by one level."""
    try:
        vals = df.index.get_level_values(level).unique()
        full = [x for x in order if x in vals]
        full += [x for x in vals if x not in full]
        cat = pd.Categorical(
            df.index.get_level_values(level), categories=full, ordered=True
        )
        tmp = f"__sort_{level}"
        df = df.assign(**{tmp: cat}).sort_values(tmp).drop(columns=[tmp])
    except Exception:
        pass
    return df
