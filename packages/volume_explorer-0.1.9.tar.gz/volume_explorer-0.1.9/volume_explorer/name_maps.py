"""
Project-level name maps and tag system.

Name maps provide bulk renaming of cases, zones, facies, and segments
at the project level. Tags group cases into scenarios for filtering.

Both are stored in ``<project>/name_maps.json`` and shared across all
files in the project.

Provides NameMapMixin to be mixed into PetrelVolumetrics.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from .constants import _CAT_TO_DF_COL, resolve_category


class NameMapMixin:
    """
    Mixin providing project-level name maps and tags.

    Expects the host class to have:
      - self._source_path  (Path or None)
      - self._data  (dict with 'cases', 'categories')
    """

    # ----------------------------------------------------------------
    # Internal helpers
    # ----------------------------------------------------------------

    def _project_dir(self) -> Path:
        from .storage import project_dir_from_source
        return project_dir_from_source(self._source_path)

    def _load_name_maps(self) -> dict:
        from .storage import load_name_maps
        return load_name_maps(self._project_dir())

    def _save_name_maps(self, nm: dict):
        from .storage import save_name_maps
        save_name_maps(nm, self._project_dir())

    # ----------------------------------------------------------------
    # Name maps API
    # ----------------------------------------------------------------

    def name_maps(self, mapping: dict | None = None) -> dict:
        """
        Get or set project-level name maps.

        Without arguments: returns current name maps.
        With a dict: merges into existing maps and saves.

        Parameters
        ----------
        mapping : dict, optional
            Keys → category names ('cases', 'zones', 'facies', 'segments', etc.)
            Values → {original_name: display_name} dicts

        Example
        -------
        >>> pv.name_maps({
        ...     'cases': {'Volume_Jan25_inLic': 'Jan 2025 In-Licence'},
        ...     'zones': {'Agat Sand 2 - Top Sola': 'Sand 2'},
        ... })
        """
        nm = self._load_name_maps()
        if mapping is None:
            return {k: v for k, v in nm.items() if k != "tags"}

        for input_key, entries in mapping.items():
            low = input_key.strip().lower()
            if low == "tags":
                continue
            if low in ("cases", "case"):
                norm_key = "cases"
            else:
                norm_key = resolve_category(input_key)

            existing = nm.get(norm_key, {})
            existing.update(entries)
            nm[norm_key] = existing

        self._save_name_maps(nm)
        n = sum(len(v) for k, v in nm.items() if k != "tags" and isinstance(v, dict))
        print(f"✓ Name maps saved ({n} mappings)")
        return {k: v for k, v in nm.items() if k != "tags"}

    def clear_name_maps(self, category: str | None = None):
        """Clear project-level name maps. Without args clears all (preserves tags)."""
        nm = self._load_name_maps()
        if category is None:
            tags = nm.get("tags", {})
            nm = {"tags": tags} if tags else {}
        else:
            low = category.strip().lower()
            norm = "cases" if low in ("case", "cases") else resolve_category(category)
            nm.pop(norm, None)
        self._save_name_maps(nm)
        print(f"✓ Name maps cleared{'' if category is None else f' for {category}'}")

    # ----------------------------------------------------------------
    # Tags API
    # ----------------------------------------------------------------

    def tag(self, tag_name: str, cases: str | list[str]):
        """
        Assign one or more cases to a tag (scenario group).

        Example
        -------
        >>> pv.tag('Base', ['Volume_Jan25_inLic', 'Volume_Jan25_OoL'])
        >>> pv.tag('Sensitivity', 'Volume_Mar25_deeperOWC')
        """
        if isinstance(cases, str):
            cases = [cases]
        nm = self._load_name_maps()
        tags = nm.setdefault("tags", {})
        existing = list(tags.get(tag_name, []))
        for c in cases:
            if c not in existing:
                existing.append(c)
        tags[tag_name] = existing
        self._save_name_maps(nm)
        print(f"✓ Tag '{tag_name}': {len(existing)} cases")

    def untag(self, tag_name: str, cases: str | list[str] | None = None):
        """
        Remove cases from a tag, or delete the tag entirely.

        Example
        -------
        >>> pv.untag('Sensitivity', 'Volume_Mar25_deeperOWC')
        >>> pv.untag('Sensitivity')  # delete entire tag
        """
        nm = self._load_name_maps()
        tags = nm.get("tags", {})
        if tag_name not in tags:
            return
        if cases is None:
            del tags[tag_name]
            print(f"✓ Tag '{tag_name}' deleted")
        else:
            if isinstance(cases, str):
                cases = [cases]
            remove = set(cases)
            tags[tag_name] = [c for c in tags[tag_name] if c not in remove]
            if not tags[tag_name]:
                del tags[tag_name]
                print(f"✓ Tag '{tag_name}' deleted (empty)")
            else:
                print(f"✓ Tag '{tag_name}': {len(tags[tag_name])} cases")
        self._save_name_maps(nm)

    def tags(self) -> dict[str, list[str]]:
        """Return all tags: {tag_name: [case_names]}."""
        return dict(self._load_name_maps().get("tags", {}))

    def cases_for_tag(self, tag_name: str) -> list[str]:
        """Return case names belonging to a tag."""
        return list(self._load_name_maps().get("tags", {}).get(tag_name, []))

    def tags_for_case(self, case_name: str) -> list[str]:
        """Return all tags a case belongs to."""
        all_tags = self._load_name_maps().get("tags", {})
        return [t for t, cases in all_tags.items() if case_name in cases]

    # ----------------------------------------------------------------
    # Tag → case filter resolution
    # ----------------------------------------------------------------

    def _resolve_tag_to_cases(
        self,
        tag: str | None,
        case: str | list[str] | None,
    ) -> str | list[str] | None:
        """Resolve a tag to a case filter, merging with explicit case filter."""
        if tag is None:
            return case
        tag_cases = self.cases_for_tag(tag)
        if not tag_cases:
            return case
        if case is None:
            return tag_cases
        # Intersect explicit case filter with tag cases
        case_list = [case] if isinstance(case, str) else list(case)
        return [c for c in case_list if c in tag_cases] or case_list

    # ----------------------------------------------------------------
    # DataFrame transformation
    # ----------------------------------------------------------------

    def _apply_name_maps_to_df(self, df: pd.DataFrame) -> pd.DataFrame:
        """Rename index/column values using project-level name maps."""
        nm = self._load_name_maps()
        if not nm:
            return df

        df = df.copy()

        # Map DataFrame column/index names to name-map keys
        col_to_cat = {v: k for k, v in _CAT_TO_DF_COL.items()}
        col_to_cat["case"] = "cases"

        # --- Rename index values ---
        if isinstance(df.index, pd.MultiIndex):
            for level in range(df.index.nlevels):
                lname = df.index.names[level]
                cat = col_to_cat.get(lname)
                if cat and cat in nm and nm[cat]:
                    mapping = nm[cat]
                    new_level = df.index.levels[level].map(
                        lambda x, m=mapping: m.get(x, x)
                    )
                    df.index = df.index.set_levels(new_level, level=level)
        else:
            idx_name = df.index.name or ""
            cat = col_to_cat.get(idx_name)
            if cat and cat in nm and nm[cat]:
                df.index = df.index.map(lambda x, m=nm[cat]: m.get(x, x))

        # --- Rename column values (pivot tables) ---
        if hasattr(df.columns, "name") and df.columns.name:
            cat = col_to_cat.get(df.columns.name)
            if cat and cat in nm and nm[cat]:
                df.columns = df.columns.map(lambda x, m=nm[cat]: m.get(x, x))

        return df
