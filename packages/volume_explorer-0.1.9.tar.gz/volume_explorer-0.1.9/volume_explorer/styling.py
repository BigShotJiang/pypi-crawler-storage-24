"""
HTML styling and display helpers for volumetrics tables.
"""

from __future__ import annotations

import re
from html import escape as _esc
from itertools import groupby as _groupby

import pandas as pd


class StyledHTML:
    """Wrapper so Jupyter renders raw HTML via _repr_html_."""

    def __init__(self, html: str):
        self._html = html

    def _repr_html_(self):
        return self._html


def run_label(pv, fallback: str = "?") -> str:
    """Build a consistent display label for a run."""
    return f"{pv.model} | {pv.grid} | {pv.metadata.get('date_raw', fallback)}"


def theme(dark: bool = False) -> dict[str, str]:
    """Return colour palette for light or dark mode."""
    if dark:
        return {
            "bg":        "#0e1117",
            "bg_header": "#1a1c23",
            "fg":        "#e6eaf1",
            "fg_dim":    "#8b95a5",
            "fg_accent": "#c5cdd9",
            "border":    "#2d3140",
            "sep":       "#4a5063",
            "stripe":    "#141720",
        }
    return {
        "bg":        "#ffffff",
        "bg_header": "#f0f2f6",
        "fg":        "#1a1d27",
        "fg_dim":    "#6b7280",
        "fg_accent": "#31333f",
        "border":    "#d6dbe4",
        "sep":       "#31333f",
        "stripe":    "#f8f9fc",
    }


def insert_subtotals(df: pd.DataFrame) -> tuple[pd.DataFrame, set[int]]:
    """
    Insert subtotal rows at each group break in a MultiIndex DataFrame.
    Returns (new_df, set_of_sum_row_positions).
    """
    nlevels = df.index.nlevels
    ncols = len(df.columns)

    rows: list[tuple[tuple, list]] = []
    sum_positions: set[int] = set()

    orig = []
    for idx, vals in zip(df.index, df.values):
        orig.append((idx if isinstance(idx, tuple) else (idx,), list(vals)))

    def _emit_group(items: list, level: int):
        if level == nlevels - 1:
            for idx_tuple, vals in items:
                rows.append((idx_tuple, vals))
            return

        for _key, group_iter in _groupby(items, key=lambda x: x[0][level]):
            group = list(group_iter)
            _emit_group(group, level + 1)

            if len(group) > 1:
                sums = [0.0] * ncols
                for _, vals in group:
                    for j in range(ncols):
                        try:
                            sums[j] += float(vals[j])
                        except (ValueError, TypeError):
                            pass

                idx_parts = list(group[0][0])
                for k in range(level + 1, nlevels):
                    idx_parts[k] = "Sum" if k == level + 1 else ""
                sum_positions.add(len(rows))
                rows.append((tuple(idx_parts), sums))

    _emit_group(orig, 0)

    # Grand total row
    if len(orig) > 1:
        sums = [0.0] * ncols
        for _, vals in orig:
            for j in range(ncols):
                try:
                    sums[j] += float(vals[j])
                except (ValueError, TypeError):
                    pass
        idx_parts = ["Total"] + [""] * (nlevels - 1)
        sum_positions.add(len(rows))
        rows.append((tuple(idx_parts), sums))

    if rows:
        idx = pd.MultiIndex.from_tuples(
            [r[0] for r in rows], names=df.index.names
        )
        new_df = pd.DataFrame(
            [r[1] for r in rows], index=idx, columns=df.columns
        )
        return new_df, sum_positions
    return df, set()


def style_table(
    df: pd.DataFrame,
    fmt: str = "{:,.2f}",
    dark: bool = False,
    title: str = "",
    subtitle: str = "",
    subtotals: bool = False,
) -> StyledHTML:
    """
    Style a DataFrame for display with integrated header and theming.
    """
    t = theme(dark)

    sum_row_indices: set[int] = set()
    if subtotals:
        if isinstance(df.index, pd.MultiIndex) and df.index.nlevels >= 2:
            df, sum_row_indices = insert_subtotals(df)
        elif len(df) > 1:
            total_vals = []
            for col in df.columns:
                try:
                    total_vals.append(df[col].astype(float).sum())
                except (ValueError, TypeError):
                    total_vals.append("")
            total_row = pd.DataFrame(
                [total_vals], index=pd.Index(["Total"]), columns=df.columns,
            )
            total_row.index.name = df.index.name
            sum_row_indices = {len(df)}
            df = pd.concat([df, total_row])

    styles = [
        {"selector": "table", "props": [
            ("border-collapse", "collapse"),
            ("background-color", t["bg"]),
            ("color", t["fg"]),
            ("font-size", "14px"),
            ("width", "100%"),
            ("font-family", "'Segoe UI', system-ui, -apple-system, sans-serif"),
        ]},
        {"selector": "th", "props": [
            ("padding", "8px 14px"),
            ("background-color", t["bg_header"]),
            ("color", t["fg_dim"]),
            ("font-weight", "500"),
            ("font-size", "13px"),
            ("border-bottom", f"2px solid {t['border']}"),
            ("white-space", "nowrap"),
            ("text-align", "left"),
        ]},
        {"selector": "th.col_heading", "props": [
            ("text-align", "right"),
            ("min-width", "105px"),
        ]},
        {"selector": "td", "props": [
            ("padding", "6px 14px"),
            ("text-align", "right"),
            ("color", t["fg"]),
            ("min-width", "105px"),
            ("border-bottom", f"1px solid {t['border']}"),
        ]},
        {"selector": "th.row_heading", "props": [
            ("text-align", "left"),
            ("font-weight", "normal"),
            ("color", t["fg_dim"]),
            ("background-color", t["bg"]),
        ]},
        {"selector": "tbody tr:nth-child(even)", "props": [
            ("background-color", t["stripe"]),
        ]},
        {"selector": "tbody tr:nth-child(odd)", "props": [
            ("background-color", t["bg"]),
        ]},
    ]

    # Two-line metric column headers: label (accent) + dimmed unit
    _RE_COL_UNIT = re.compile(r"^(.+?)\s*\[(.+)\]$")
    col_rename = {}
    for col in df.columns:
        m = _RE_COL_UNIT.match(str(col))
        if m:
            label, unit = m.group(1).strip(), m.group(2).strip()
            col_rename[col] = (
                f'<span style="color:{t["fg_accent"]};'
                f'font-weight:600">{label}</span><br>'
                f'<span style="font-weight:400;color:{t["fg_dim"]};'
                f'font-size:12px">{unit}</span>'
            )
    if col_rename:
        df = df.rename(columns=col_rename)

    # Capture index level names for injection into header row
    idx_labels = []
    if isinstance(df.index, pd.MultiIndex):
        idx_labels = [str(n) if n else "" for n in df.index.names]
        df.index.names = [""] * df.index.nlevels
    elif df.index.name:
        idx_labels = [str(df.index.name)]
        df.index.name = ""

    styles.append({
        "selector": "thead tr:nth-child(2)",
        "props": [("display", "none")],
    })

    # Group separator borders for MultiIndex
    if isinstance(df.index, pd.MultiIndex) and df.index.nlevels >= 2:
        level0 = df.index.get_level_values(0)
        sep_count = 0
        for i in range(1, len(level0)):
            if level0[i] != level0[i - 1]:
                if i not in sum_row_indices:
                    sep_count += 1
                    if sep_count > 50:
                        break
                    styles.append({
                        "selector": f"tbody tr:nth-child({i + 1})",
                        "props": [("border-top", f"2px solid {t['sep']}")],
                    })

    # Sum-row styling
    for ri in sum_row_indices:
        n = ri + 1
        styles.append({
            "selector": f"tbody tr:nth-child({n})",
            "props": [
                ("background-color", f"{t['bg_header']} !important"),
                ("border-top", f"1px solid {t['border']}"),
            ],
        })
        styles.append({
            "selector": f"tbody tr:nth-child({n}) td",
            "props": [
                ("font-style", "italic"),
                ("color", t["fg_accent"]),
            ],
        })
        styles.append({
            "selector": f"tbody tr:nth-child({n}) th.row_heading",
            "props": [
                ("font-style", "italic"),
                ("color", t["fg_accent"]),
                ("background-color", t["bg_header"]),
            ],
        })

    table_html = df.style.format(fmt).set_table_styles(styles).to_html()

    # Post-process: inject index labels into blank header cells
    if idx_labels:
        def _replace_blank(match):
            _replace_blank.idx += 1
            i = _replace_blank.idx - 1
            if i < len(idx_labels) and idx_labels[i]:
                lbl = idx_labels[i]
                return f'<th class="{match.group(1)}">{lbl}</th>'
            return match.group(0)

        _replace_blank.idx = 0
        html_parts = table_html.split("</tr>", 1)
        if len(html_parts) == 2:
            first_row = re.sub(
                r'<th class="(blank[^"]*)"[^>]*>\s*&nbsp;\s*</th>',
                _replace_blank,
                html_parts[0],
            )
            table_html = first_row + "</tr>" + html_parts[1]

    # Build integrated header + table wrapper
    header_html = ""
    if title or subtitle:
        header_html = (
            f'<div style="background:{t["bg_header"]};'
            f'padding:10px 14px;border-bottom:1px solid {t["border"]}">'
        )
        if title:
            header_html += (
                f'<div style="color:{t["fg"]};font-weight:600;'
                f'font-size:16px;font-family:\'Segoe UI\',system-ui,sans-serif">'
                f'{title}</div>'
            )
        if subtitle:
            header_html += (
                f'<div style="color:{t["fg_dim"]};font-size:12px;'
                f'margin-top:2px;font-family:\'Segoe UI\',system-ui,sans-serif">'
                f'{subtitle}</div>'
            )
        header_html += '</div>'

    wrapper = (
        f'<div style="display:inline-block;border:1px solid {t["border"]};'
        f'border-radius:6px;overflow:hidden;background:{t["bg"]}">'
        f'{header_html}{table_html}</div>'
    )

    return StyledHTML(wrapper)


# ======================================================================
# Native SVG export (no foreignObject — MS Office compatible)
# ======================================================================

def table_to_svg(
    df: pd.DataFrame,
    fmt: str = "{:,.2f}",
    dark: bool = False,
    title: str = "",
    subtitle: str = "",
    subtotals: bool = False,
) -> str:
    """Render a DataFrame as a native SVG string.

    Uses only ``<rect>``, ``<text>``, and ``<line>`` elements so the
    result opens correctly in MS Office, Inkscape, browsers, etc.
    """
    t = theme(dark)

    sum_row_indices: set[int] = set()
    if subtotals:
        if isinstance(df.index, pd.MultiIndex) and df.index.nlevels >= 2:
            df, sum_row_indices = insert_subtotals(df)
        elif len(df) > 1:
            total_vals = []
            for col in df.columns:
                try:
                    total_vals.append(df[col].astype(float).sum())
                except (ValueError, TypeError):
                    total_vals.append("")
            total_row = pd.DataFrame(
                [total_vals], index=pd.Index(["Total"]), columns=df.columns,
            )
            total_row.index.name = df.index.name
            sum_row_indices = {len(df)}
            df = pd.concat([df, total_row])

    # ── Font metrics (approximate) ──
    FONT = "Segoe UI, system-ui, sans-serif"
    FONT_SZ = 14
    HDR_SZ = 13
    UNIT_SZ = 11
    TITLE_SZ = 16
    SUB_SZ = 12
    CHAR_W = 8.0       # avg char width at 14px
    HDR_CHAR_W = 7.5
    PAD_X = 14
    ROW_H = 28
    HDR_H = 42          # two-line header

    TITLE_H = 0
    if title or subtitle:
        TITLE_H = 12 + (20 if title else 0) + (16 if subtitle else 0)

    # ── Parse column headers ──
    _RE = re.compile(r"^(.+?)\s*\[(.+)\]$")
    col_info: list[tuple[str, str, str | None]] = []
    for col in df.columns:
        m = _RE.match(str(col))
        if m:
            col_info.append((str(col), m.group(1).strip(), m.group(2).strip()))
        else:
            col_info.append((str(col), str(col), None))

    # ── Index info ──
    if isinstance(df.index, pd.MultiIndex):
        idx_names = [str(n) if n else "" for n in df.index.names]
        nlevels = df.index.nlevels
    else:
        idx_names = [str(df.index.name) if df.index.name else ""]
        nlevels = 1

    # ── Column widths ──
    idx_widths: list[int] = []
    for level in range(nlevels):
        if isinstance(df.index, pd.MultiIndex):
            vals = df.index.get_level_values(level)
        else:
            vals = df.index
        max_len = max((len(str(v)) for v in vals), default=5)
        lbl_len = len(idx_names[level]) if level < len(idx_names) else 0
        max_len = max(max_len, lbl_len)
        idx_widths.append(int(max_len * CHAR_W + PAD_X * 2))

    data_widths: list[int] = []
    for ci, (_col_name, label, unit) in enumerate(col_info):
        hdr_len = max(len(label), len(unit) if unit else 0)
        data_max = 0
        for val in df.iloc[:, ci]:
            try:
                data_max = max(data_max, len(fmt.format(float(val))))
            except (ValueError, TypeError):
                data_max = max(data_max, len(str(val)))
        col_w = int(max(hdr_len * HDR_CHAR_W, data_max * CHAR_W) + PAD_X * 2)
        data_widths.append(max(col_w, 105))

    total_w = sum(idx_widths) + sum(data_widths)
    n_rows = len(df)
    total_h = TITLE_H + HDR_H + n_rows * ROW_H

    # ── Group separator detection ──
    level0 = None
    if isinstance(df.index, pd.MultiIndex) and df.index.nlevels >= 2:
        level0 = df.index.get_level_values(0)

    # ── Build SVG ──
    out: list[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'width="{total_w}" height="{total_h}" '
        f'font-family="{FONT}">',
        f'<rect width="{total_w}" height="{total_h}" fill="{t["bg"]}"/>',
    ]

    y = 0

    # ── Title area ──
    if TITLE_H:
        out.append(
            f'<rect x="0" y="0" width="{total_w}" '
            f'height="{TITLE_H}" fill="{t["bg_header"]}"/>'
        )
        ty = 10
        if title:
            ty += 16
            out.append(
                f'<text x="{PAD_X}" y="{ty}" font-size="{TITLE_SZ}" '
                f'font-weight="600" fill="{t["fg"]}">'
                f'{_esc(title)}</text>'
            )
        if subtitle:
            ty += 16
            out.append(
                f'<text x="{PAD_X}" y="{ty}" font-size="{SUB_SZ}" '
                f'fill="{t["fg_dim"]}">{_esc(subtitle)}</text>'
            )
        out.append(
            f'<line x1="0" y1="{TITLE_H}" x2="{total_w}" y2="{TITLE_H}" '
            f'stroke="{t["border"]}" stroke-width="1"/>'
        )
        y = TITLE_H

    # ── Column header row ──
    hdr_y = y
    out.append(
        f'<rect x="0" y="{hdr_y}" width="{total_w}" '
        f'height="{HDR_H}" fill="{t["bg_header"]}"/>'
    )

    x = 0
    for level in range(nlevels):
        lbl = idx_names[level] if level < len(idx_names) else ""
        ty = hdr_y + HDR_H / 2 + HDR_SZ * 0.35
        out.append(
            f'<text x="{x + PAD_X}" y="{ty}" font-size="{HDR_SZ}" '
            f'font-weight="500" fill="{t["fg_dim"]}">{_esc(lbl)}</text>'
        )
        x += idx_widths[level]

    for ci, (_cn, label, unit) in enumerate(col_info):
        cx = x + data_widths[ci] - PAD_X
        if unit:
            ly = hdr_y + HDR_H / 2 - 3
            uy = hdr_y + HDR_H / 2 + UNIT_SZ + 1
            out.append(
                f'<text x="{cx}" y="{ly}" text-anchor="end" '
                f'font-size="{HDR_SZ}" font-weight="600" '
                f'fill="{t["fg_accent"]}">{_esc(label)}</text>'
            )
            out.append(
                f'<text x="{cx}" y="{uy}" text-anchor="end" '
                f'font-size="{UNIT_SZ}" fill="{t["fg_dim"]}">'
                f'{_esc(unit)}</text>'
            )
        else:
            ty = hdr_y + HDR_H / 2 + HDR_SZ * 0.35
            out.append(
                f'<text x="{cx}" y="{ty}" text-anchor="end" '
                f'font-size="{HDR_SZ}" font-weight="600" '
                f'fill="{t["fg_accent"]}">{_esc(label)}</text>'
            )
        x += data_widths[ci]

    hdr_bot = hdr_y + HDR_H
    out.append(
        f'<line x1="0" y1="{hdr_bot}" x2="{total_w}" y2="{hdr_bot}" '
        f'stroke="{t["border"]}" stroke-width="2"/>'
    )

    # ── Data rows ──
    svg_sep_count = 0
    for ri in range(n_rows):
        ry = hdr_bot + ri * ROW_H
        is_sum = ri in sum_row_indices

        # Background
        if is_sum:
            bg = t["bg_header"]
        elif ri % 2 == 0:
            bg = t["stripe"]
        else:
            bg = t["bg"]
        out.append(
            f'<rect x="0" y="{ry}" width="{total_w}" '
            f'height="{ROW_H}" fill="{bg}"/>'
        )

        # Group separator
        if level0 is not None and ri > 0:
            if level0[ri] != level0[ri - 1] and not is_sum and svg_sep_count < 50:
                svg_sep_count += 1
                out.append(
                    f'<line x1="0" y1="{ry}" x2="{total_w}" y2="{ry}" '
                    f'stroke="{t["sep"]}" stroke-width="2"/>'
                )
        if is_sum:
            out.append(
                f'<line x1="0" y1="{ry}" x2="{total_w}" y2="{ry}" '
                f'stroke="{t["border"]}" stroke-width="1"/>'
            )

        # Index cells
        x = 0
        idx_vals = (
            df.index[ri]
            if isinstance(df.index, pd.MultiIndex)
            else (df.index[ri],)
        )
        for level in range(nlevels):
            v = str(idx_vals[level]) if level < len(idx_vals) else ""
            ty = ry + ROW_H / 2 + FONT_SZ * 0.35
            color = t["fg_accent"] if is_sum else t["fg_dim"]
            italic = ' font-style="italic"' if is_sum else ""
            out.append(
                f'<text x="{x + PAD_X}" y="{ty}" font-size="{FONT_SZ}" '
                f'fill="{color}"{italic}>{_esc(v)}</text>'
            )
            x += idx_widths[level]

        # Data cells
        for ci, _ in enumerate(col_info):
            val = df.iloc[ri, ci]
            try:
                txt = fmt.format(float(val))
            except (ValueError, TypeError):
                txt = str(val)
            tx = x + data_widths[ci] - PAD_X
            ty = ry + ROW_H / 2 + FONT_SZ * 0.35
            color = t["fg_accent"] if is_sum else t["fg"]
            italic = ' font-style="italic"' if is_sum else ""
            out.append(
                f'<text x="{tx}" y="{ty}" text-anchor="end" '
                f'font-size="{FONT_SZ}" fill="{color}"{italic}>'
                f'{_esc(txt)}</text>'
            )
            x += data_widths[ci]

        # Row bottom border
        out.append(
            f'<line x1="0" y1="{ry + ROW_H}" x2="{total_w}" '
            f'y2="{ry + ROW_H}" stroke="{t["border"]}" '
            f'stroke-width="0.5"/>'
        )

    out.append("</svg>")
    return "\n".join(out)
