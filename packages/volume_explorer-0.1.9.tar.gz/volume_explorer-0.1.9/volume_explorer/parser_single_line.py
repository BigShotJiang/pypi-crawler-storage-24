"""
Parser for the Petrel **single-line** volumetrics export format.

This format has all cases in one export, one row per case, with a wide
column layout. Above the 'Case' header row, 0–6 category header rows
define the grouping dimensions (Zones, Facies, Contact regions, etc.).
"""

from __future__ import annotations

from .constants import VOLUME_COLS, SHORT_METRIC_NAMES
from .parser_common import normalise_cat_label, cat_key_to_record_col
from .storage import try_float

# Values in category header rows that indicate subtotal/grand-total columns.
# These columns should be excluded from the fine-grained detailed records.
_SUBTOTAL_MARKERS = frozenset({"total", "sum", "all", ""})


# ---------------------------------------------------------------------------
# Format detection
# ---------------------------------------------------------------------------

def _detect_category_rows(rows: list[list[str]], case_row: int) -> list[int]:
    """
    Scan backwards from the Case header to find category header rows.

    A category row has:
    - A non-empty label in column 0
    - Category values spread across the data columns (typically col 11+)

    Returns row indices in top-to-bottom order (0 to 6 rows).
    """
    # Metadata keywords that indicate we've gone past the category rows
    _STOP_KEYWORDS = (
        "petrel", "user name", "date", "project", "model", "grid",
        "input", "hc interval", "general", "properties", "porosity",
        "net gross", "sat.", "bg ", "bo ", "rv ", "rs ", "boundaries",
        "filter", "gas oil", "oil water", "lower oil",
    )

    cat_rows = []
    i = case_row - 1
    while i >= 0 and len(cat_rows) < 6:
        r = rows[i]
        if not r or not r[0].strip():
            i -= 1
            continue

        label = r[0].strip().lower()

        if any(label.startswith(kw) for kw in _STOP_KEYWORDS):
            break

        # Category rows have values spread across many columns
        non_empty_after_label = sum(
            1 for c in r[1:min(len(r), 50)] if c.strip()
        )
        if non_empty_after_label > 3:
            cat_rows.append(i)
            i -= 1
        else:
            break

    cat_rows.reverse()  # top-to-bottom order
    return cat_rows


def is_single_line(rows: list[list[str]], case_row: int) -> bool:
    """Determine if this export uses the multi-split format."""
    cat_rows = _detect_category_rows(rows, case_row)
    if cat_rows:
        return True

    # Fallback: in multi-split, short metric names (without units)
    # are repeated many times after the initial total columns
    header = rows[case_row]
    short_count = sum(1 for c in header[1:] if c.strip() in SHORT_METRIC_NAMES)
    return short_count > len(VOLUME_COLS)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _compute_derived_totals(rec: dict):
    """
    Compute STOIIP and GIIP totals from sub-columns when the total
    isn't present in the expanded section.

    Petrel's expanded breakdown often only includes sub-columns
    (in oil, in gas) without the computed total.
    """
    _DERIVED = [
        (
            "STOIIP[*10^3 sm3]",
            "STOIIP (in oil)[*10^3 sm3]",
            "STOIIP (in gas)[*10^3 sm3]",
        ),
        (
            "GIIP[*10^6 sm3]",
            "GIIP (in gas)[*10^6 sm3]",
            "GIIP (in oil)[*10^6 sm3]",
        ),
    ]
    for total_col, sub_a, sub_b in _DERIVED:
        if rec.get(total_col, 0) == 0:
            a = rec.get(sub_a, 0) or 0
            b = rec.get(sub_b, 0) or 0
            if a or b:
                rec[total_col] = a + b


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def parse_single_line(rows: list[list[str]], case_row: int,
                      meta: dict) -> dict:
    """Parse a multi-split format export into the unified data structure."""
    header = [c.strip() for c in rows[case_row]]
    cat_row_indices = _detect_category_rows(rows, case_row)

    # --- Identify column groups ---
    # Col 0: "Case"
    # Cols 1..N: total volume columns (full names with units)
    # Cols N+1..M: expanded metric columns (short names per category combo)
    # Cols M+1..: $-parameter columns, then Folder

    total_col_indices = []
    param_col_indices = []
    folder_col_idx = None
    expanded_start = None

    for ci, ch in enumerate(header):
        if ci == 0:
            continue
        if ch in VOLUME_COLS:
            total_col_indices.append(ci)
        elif ch.startswith("$"):
            param_col_indices.append(ci)
        elif ch == "Folder":
            folder_col_idx = ci
        elif ch in SHORT_METRIC_NAMES:
            if expanded_start is None:
                expanded_start = ci

    # --- Build category info from header rows ---
    cat_infos = []  # list of (cat_key, record_col, row_index)
    for ri in cat_row_indices:
        label = rows[ri][0].strip()
        cat_key = normalise_cat_label(label)
        record_col = cat_key_to_record_col(cat_key)
        cat_infos.append((cat_key, record_col, ri))

    # --- Build expanded column descriptors ---
    # Each expanded column maps to ({record_col: value, ...}, full_metric_name)
    # Subtotal/grand-total columns are excluded.
    expanded_cols = []
    if expanded_start is not None:
        expanded_end = len(header)
        if param_col_indices:
            expanded_end = min(expanded_end, param_col_indices[0])
        if folder_col_idx is not None:
            expanded_end = min(expanded_end, folder_col_idx)

        for ci in range(expanded_start, expanded_end):
            short_name = header[ci].strip()
            if short_name not in SHORT_METRIC_NAMES:
                continue
            full_metric = SHORT_METRIC_NAMES[short_name]

            cat_vals = {}
            is_subtotal = False
            for _cat_key, record_col, ri in cat_infos:
                row_data = rows[ri]
                val = row_data[ci].strip() if ci < len(row_data) else ""
                cat_vals[record_col] = val
                if val.lower() in _SUBTOTAL_MARKERS:
                    is_subtotal = True

            # Skip subtotal/grand-total columns
            if is_subtotal:
                continue

            expanded_cols.append((ci, cat_vals, full_metric))

    # --- Discover unique category values (excluding subtotals) ---
    categories: dict[str, list[str]] = {}
    for cat_key, _record_col, ri in cat_infos:
        seen = set()
        ordered = []
        row_data = rows[ri]
        start = expanded_start or 0
        for ci in range(start, len(row_data)):
            val = row_data[ci].strip()
            if val and val not in seen and val.lower() not in _SUBTOTAL_MARKERS:
                seen.add(val)
                ordered.append(val)
        categories[cat_key] = ordered

    # --- Parse data rows (one per case) ---
    cases = []
    all_parameters: dict[str, dict] = {}
    all_detailed: list[dict] = []

    i = case_row + 1
    while i < len(rows):
        r = rows[i]
        if not r or not r[0].strip():
            i += 1
            continue

        case_name = r[0].strip()

        # Stop at known section markers
        if case_name.lower() in ("totals all result types", "detailed results"):
            break

        cases.append(case_name)

        # Extract parameters (strip leading $, drop null/empty values)
        params = {}
        for ci in param_col_indices:
            if ci < len(r):
                key = header[ci].lstrip("$").strip()
                val = try_float(r[ci])
                if val is not None and val != "" and val != 0:
                    params[key] = val
        all_parameters[case_name] = params

        # Extract expanded detailed records
        if expanded_cols:
            # Group by unique category combination
            combo_map: dict[tuple, dict] = {}
            for ci, cat_vals, full_metric in expanded_cols:
                val = try_float(r[ci]) if ci < len(r) else 0
                combo_key = tuple(sorted(cat_vals.items()))
                if combo_key not in combo_map:
                    rec = {"case": case_name}
                    rec.update(cat_vals)
                    combo_map[combo_key] = rec
                combo_map[combo_key][full_metric] = val

            for rec in combo_map.values():
                for vc in VOLUME_COLS:
                    if vc not in rec:
                        rec[vc] = 0
                _compute_derived_totals(rec)
                all_detailed.append(rec)
        else:
            # No expanded columns — just totals per case
            rec = {"case": case_name}
            for ci in total_col_indices:
                if ci < len(r):
                    rec[header[ci]] = try_float(r[ci])
            for vc in VOLUME_COLS:
                if vc not in rec:
                    rec[vc] = 0
            _compute_derived_totals(rec)
            all_detailed.append(rec)

        i += 1

    return {
        "metadata": meta,
        "format": "single_line",
        "cases": cases,
        "parameters": all_parameters,
        "categories": categories,
        "detailed": all_detailed,
        "aliases": {},
    }
