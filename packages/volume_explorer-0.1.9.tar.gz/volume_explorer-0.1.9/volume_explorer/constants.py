"""
Domain constants and resolution helpers for Petrel volumetrics.
"""

from __future__ import annotations

VOLUME_COLS = [
    "Bulk volume[*10^3 m3]",
    "Net volume[*10^3 m3]",
    "Pore volume[*10^3 rm3]",
    "HCPV oil[*10^3 rm3]",
    "HCPV gas[*10^3 rm3]",
    "STOIIP (in oil)[*10^3 sm3]",
    "STOIIP (in gas)[*10^3 sm3]",
    "STOIIP[*10^3 sm3]",
    "GIIP (in gas)[*10^6 sm3]",
    "GIIP (in oil)[*10^6 sm3]",
    "GIIP[*10^6 sm3]",
]

# Short name → full Petrel column name
SHORT_NAMES = {
    "bulk": "Bulk volume[*10^3 m3]",
    "net": "Net volume[*10^3 m3]",
    "pore": "Pore volume[*10^3 rm3]",
    "hcpv_oil": "HCPV oil[*10^3 rm3]",
    "hcpv_gas": "HCPV gas[*10^3 rm3]",
    "stoiip_oil": "STOIIP (in oil)[*10^3 sm3]",
    "stoiip_gas": "STOIIP (in gas)[*10^3 sm3]",
    "stoiip": "STOIIP[*10^3 sm3]",
    "giip_gas": "GIIP (in gas)[*10^6 sm3]",
    "giip_oil": "GIIP (in oil)[*10^6 sm3]",
    "giip": "GIIP[*10^6 sm3]",
}

# Short metric names (without units) used in multi-split column headers
# Maps to the full column name with units
SHORT_METRIC_NAMES = {
    "Bulk volume": "Bulk volume[*10^3 m3]",
    "Net volume": "Net volume[*10^3 m3]",
    "Pore volume": "Pore volume[*10^3 rm3]",
    "HCPV oil": "HCPV oil[*10^3 rm3]",
    "HCPV gas": "HCPV gas[*10^3 rm3]",
    "STOIIP (in oil)": "STOIIP (in oil)[*10^3 sm3]",
    "STOIIP (in gas)": "STOIIP (in gas)[*10^3 sm3]",
    "STOIIP": "STOIIP[*10^3 sm3]",
    "GIIP (in gas)": "GIIP (in gas)[*10^6 sm3]",
    "GIIP (in oil)": "GIIP (in oil)[*10^6 sm3]",
    "GIIP": "GIIP[*10^6 sm3]",
}

def _default_base_dir() -> str:
    """Return ~/Documents/VolumeExplorer on Mac/Windows/Linux."""
    from pathlib import Path
    return str(Path.home() / "Documents" / "VolumeExplorer")

BASE_DIR_NAME = _default_base_dir()
UNITS_FILE = "units.json"
SETTINGS_FILE = "explorer_settings.json"
LAYOUTS_FILE = "layouts.json"
NAME_MAPS_FILE = "name_maps.json"

# Mapping for flexible category key input
_CAT_ALIASES = {
    "zone": "zones",
    "zones": "zones",
    "facies": "facies",
    "region": "contact_regions",
    "regions": "contact_regions",
    "contact_region": "contact_regions",
    "contact_regions": "contact_regions",
    "contact regions": "contact_regions",
    "segment": "contact_regions",
    "segments": "contact_regions",
}

# Category key → DataFrame column name
_CAT_TO_DF_COL = {
    "zones": "zone",
    "facies": "facies",
    "contact_regions": "region",
}

# Trivial values to skip in filters/display
_TRIVIAL = {"N/A", "Code 0", "Undefined"}

# Known category row labels in Petrel exports (used for auto-detection)
_CATEGORY_ROW_LABELS = {
    "zones", "facies", "contact regions", "region", "regions",
    "segments", "boundary", "boundaries",
}


def resolve_metric(name: str) -> str:
    """Resolve a short/fuzzy metric name to the full column name."""
    low = name.strip().lower()
    if low in SHORT_NAMES:
        return SHORT_NAMES[low]
    for col in VOLUME_COLS:
        if low in col.lower():
            return col
    raise ValueError(
        f"Unknown metric '{name}'. Use one of: {list(SHORT_NAMES.keys())}"
    )


def resolve_category(name: str) -> str:
    """Resolve a user-friendly category name to the internal key."""
    key = name.strip().lower().replace(" ", "_")
    if key in _CAT_ALIASES:
        return _CAT_ALIASES[key]
    return key


def cat_to_df_col(cat_key: str) -> str:
    """Map a category key to its DataFrame column name."""
    return _CAT_TO_DF_COL.get(cat_key, cat_key)
