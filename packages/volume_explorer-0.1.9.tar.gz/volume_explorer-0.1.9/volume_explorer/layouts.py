"""
Layout system: stored table configurations.

A Layout is a saved query template that defines which metrics, groupings,
filters, and display options to use when producing a table.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path

from .constants import LAYOUTS_FILE


@dataclass
class Layout:
    name: str
    metrics: list[str] = field(default_factory=lambda: ["stoiip"])
    group_by: list[str] | None = None
    filters: dict | None = None
    format: str = "flat"            # "flat" | "pivot" | "summary"
    pivot_columns: str | None = None
    show_subtotals: bool = False
    hide_zeros: bool = True
    decimals: int = 2
    dark: bool = False
    title: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Layout":
        # Filter to only known fields
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in d.items() if k in known})


def _layouts_path(base: Path) -> Path:
    return base / LAYOUTS_FILE


def load_layouts(base: Path) -> list[Layout]:
    """Load all saved layouts."""
    p = _layouts_path(base)
    if not p.exists():
        return []
    with open(p, "r", encoding="utf-8") as f:
        data = json.load(f)
    return [Layout.from_dict(d) for d in data]


def get_layout(name: str, base: Path) -> Layout | None:
    """Get a layout by name."""
    for layout in load_layouts(base):
        if layout.name == name:
            return layout
    return None


def save_layout(layout: Layout, base: Path):
    """Save or update a layout."""
    layouts = load_layouts(base)
    # Replace if exists
    layouts = [l for l in layouts if l.name != layout.name]
    layouts.append(layout)

    base.mkdir(parents=True, exist_ok=True)
    with open(_layouts_path(base), "w", encoding="utf-8") as f:
        json.dump([l.to_dict() for l in layouts], f, indent=2, ensure_ascii=False)
    print(f"✓ Layout saved: {layout.name}")


def delete_layout(name: str, base: Path):
    """Delete a layout by name."""
    layouts = load_layouts(base)
    before = len(layouts)
    layouts = [l for l in layouts if l.name != name]
    if len(layouts) < before:
        with open(_layouts_path(base), "w", encoding="utf-8") as f:
            json.dump([l.to_dict() for l in layouts], f, indent=2, ensure_ascii=False)
        print(f"✓ Layout deleted: {name}")
    else:
        print(f"Layout not found: {name}")


def list_layouts(base: Path) -> list[str]:
    """List available layout names."""
    return [l.name for l in load_layouts(base)]
