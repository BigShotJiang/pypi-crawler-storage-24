"""
File I/O, project discovery, settings and units persistence.
"""

from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path

from .constants import BASE_DIR_NAME, UNITS_FILE, SETTINGS_FILE, NAME_MAPS_FILE


def base_dir(path: Path | None = None) -> Path:
    """Infer the VolumetricResults base directory from a source path."""
    if path:
        return path.parent.parent
    return Path(BASE_DIR_NAME)


def normalize_filename(s: str) -> str:
    return re.sub(r"[\s/\\:\-]+", "_", s).strip("_")


def try_float(v):
    try:
        return float(v)
    except (ValueError, TypeError):
        return v


def scan_json(base: Path) -> list[Path]:
    """Recursively find JSON files, skipping hidden directories."""
    _SKIP = {UNITS_FILE, SETTINGS_FILE, "layouts.json", NAME_MAPS_FILE}
    return sorted(
        p for p in base.rglob("*.json")
        if not any(part.startswith(".") for part in p.relative_to(base).parts)
        and p.name not in _SKIP
    )


def discover_projects(base: Path) -> dict[str, list[Path]]:
    result: dict[str, list[Path]] = {}
    for p in scan_json(base):
        project = p.parent.name
        result.setdefault(project, []).append(p)
    return result


def load_data(path: Path) -> dict:
    """Load a saved JSON volumetrics file."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_data(data: dict, path: Path):
    """Save volumetrics data to JSON."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def load_settings(base: Path) -> dict:
    """Load explorer settings from VolumetricResults/explorer_settings.json."""
    p = Path(base) / SETTINGS_FILE
    if p.exists():
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_settings(settings: dict, base: Path):
    """Save explorer settings."""
    d = Path(base)
    d.mkdir(parents=True, exist_ok=True)
    with open(d / SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2, ensure_ascii=False)


def load_units(base: Path) -> dict:
    """Load global units config from VolumetricResults/units.json."""
    p = Path(base) / UNITS_FILE
    if p.exists():
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_units(units: dict, base: Path):
    """Save global units config."""
    d = Path(base)
    d.mkdir(parents=True, exist_ok=True)
    with open(d / UNITS_FILE, "w", encoding="utf-8") as f:
        json.dump(units, f, indent=2, ensure_ascii=False)


def save_from_clipboard(data: dict, base_dir_path: Path) -> Path:
    """
    Save parsed data from clipboard.
    Returns the path where the file was saved.
    Preserves aliases and header from any existing file at the same path.
    """
    project_name = data["metadata"]["project"]
    if project_name.lower().endswith(".pet"):
        project_name = project_name[:-4]

    grid_name = (
        data["metadata"]["grid"]
        or data["metadata"]["model"]
        or "unknown"
    )
    norm_grid = normalize_filename(grid_name)

    try:
        dt = datetime.fromisoformat(data["metadata"]["date_parsed"])
    except Exception:
        dt = datetime.now()
    ts = dt.strftime("%d%m%y_%H%M")

    filename = f"{norm_grid}_{ts}.json"
    out_dir = Path(base_dir_path) / project_name.strip()
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / filename

    # Preserve aliases, header/title from previous version
    if out_path.exists():
        try:
            with open(out_path, "r", encoding="utf-8") as f:
                old = json.load(f)
            if old.get("aliases"):
                data["aliases"] = old["aliases"]
            if old.get("header"):
                data["header"] = old["header"]
        except Exception:
            pass

    save_data(data, out_path)
    return out_path


# ---------------------------------------------------------------------------
# Project-level name maps
# ---------------------------------------------------------------------------

def load_name_maps(project_dir: Path) -> dict[str, dict[str, str]]:
    """Load project-level name maps from <project>/name_maps.json."""
    p = project_dir / NAME_MAPS_FILE
    if p.exists():
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_name_maps(name_maps: dict[str, dict[str, str]], project_dir: Path):
    """Save project-level name maps to <project>/name_maps.json."""
    project_dir.mkdir(parents=True, exist_ok=True)
    with open(project_dir / NAME_MAPS_FILE, "w", encoding="utf-8") as f:
        json.dump(name_maps, f, indent=2, ensure_ascii=False)


def project_dir_from_source(source_path: Path | None, base: Path | None = None) -> Path:
    """
    Get the project directory from a source file path.

    VolumetricResults/<project>/<file>.json → VolumetricResults/<project>/
    """
    if source_path and source_path.parent.exists():
        return source_path.parent
    if base is None:
        base = Path(BASE_DIR_NAME)
    return base
