"""
Unit/multiplier system for Petrel volume metrics.
"""

from __future__ import annotations

import re
from pathlib import Path

import pandas as pd

from .constants import resolve_metric, SHORT_NAMES
from .storage import load_units, save_units

# Standard unit abbreviations by magnitude
_UNIT_ABBREV = {
    "3": "kcm",   # *10^3 → kilo cubic metres
    "6": "mcm",   # *10^6 → million cubic metres
    "9": "bcm",   # *10^9 → billion cubic metres
}

_RE_UNIT = re.compile(r"^(.*?)\[\*10\^(\d+)\s+\w+\]$")


def default_metric_display(raw_col: str) -> tuple[str, str]:
    """
    Parse a raw Petrel column name into (label, unit_abbrev).

    'STOIIP[*10^3 sm3]'  →  ('STOIIP', 'kcm')
    'GIIP (in gas)[*10^6 sm3]'  →  ('GIIP (in gas)', 'mcm')
    """
    m = _RE_UNIT.match(raw_col)
    if m:
        label = m.group(1).strip()
        exp = m.group(2)
        abbrev = _UNIT_ABBREV.get(exp, f"10^{exp} cm")
        return label, abbrev
    return raw_col, ""


def get_multiplier(short: str, base: Path) -> tuple[float, str | None]:
    """
    Look up multiplier and result_unit for a metric short name.
    Returns (multiplier, result_unit) or (1.0, None) if not configured.
    """
    cfg = load_units(base)
    for entry in cfg.get("multipliers", []):
        names = entry.get("name", [])
        if isinstance(names, str):
            names = [names]
        if short.lower() in [n.lower() for n in names]:
            return entry.get("multiplier", 1.0), entry.get("result_unit")
    return 1.0, None


def format_metric(short: str, base: Path) -> tuple[str, float]:
    """
    Return (display_column_name, multiplier) for a metric.
    Priority: multiplier config (result_unit) → smart default from raw column name.
    """
    raw_col = resolve_metric(short)
    label, default_abbrev = default_metric_display(raw_col)
    mult, result_unit = get_multiplier(short, base)

    unit = result_unit if result_unit else default_abbrev
    if unit:
        return f"{label} [{unit}]", mult
    return raw_col, mult


def apply_units_to_df(
    df: pd.DataFrame, metrics: list[str], base: Path
) -> pd.DataFrame:
    """Apply global units config: multiply values and rename columns."""
    df = df.copy()
    for short in metrics:
        raw_col = resolve_metric(short)
        display, mult = format_metric(short, base)
        if raw_col in df.columns:
            if mult != 1.0:
                df[raw_col] = df[raw_col] * mult
            if display != raw_col:
                df = df.rename(columns={raw_col: display})
    return df


def set_multipliers(*entries: dict, base: Path):
    """
    Set global metric multipliers. Stored in VolumetricResults/units.json.

    Each entry has: name (str or list), multiplier, result_unit.
    """
    cfg = load_units(base)
    existing: list[dict] = cfg.get("multipliers", [])

    for entry in entries:
        names = entry.get("name", [])
        if isinstance(names, str):
            names = [names]
        names = [n.strip().lower() for n in names]

        # Validate all metric names
        for n in names:
            resolve_metric(n)

        mult = entry.get("multiplier", 1.0)
        result_unit = entry.get("result_unit", "")

        # Remove these names from any existing entries
        cleaned = []
        for e in existing:
            e_names = e.get("name", [])
            if isinstance(e_names, str):
                e_names = [e_names]
            remaining = [n for n in e_names if n.lower() not in names]
            if remaining:
                e["name"] = remaining
                cleaned.append(e)
        existing = cleaned

        existing.append({
            "name": names,
            "multiplier": mult,
            "result_unit": result_unit,
        })

    cfg["multipliers"] = existing
    save_units(cfg, base)
    print(f"✓ Multipliers saved → {base / 'units.json'}")
    for entry in entries:
        names = entry.get("name", [])
        if isinstance(names, str):
            names = [names]
        mult = entry.get("multiplier", 1.0)
        runit = entry.get("result_unit", "")
        print(f"  {', '.join(names):30s} ×{mult}  → [{runit}]")


def get_multipliers(base: Path) -> list[dict]:
    """Return current global multiplier entries."""
    return load_units(base).get("multipliers", [])


def clear_multipliers(metric: str | None = None, base: Path | None = None):
    """Clear global multipliers. Without arguments clears all."""
    if base is None:
        base = Path("VolumetricResults")
    cfg = load_units(base)
    if metric is None:
        cfg.pop("multipliers", None)
        save_units(cfg, base)
        print("✓ All multipliers cleared")
    else:
        low = metric.strip().lower()
        existing = cfg.get("multipliers", [])
        cleaned = []
        for e in existing:
            e_names = e.get("name", [])
            if isinstance(e_names, str):
                e_names = [e_names]
            remaining = [n for n in e_names if n.lower() != low]
            if remaining:
                e["name"] = remaining
                cleaned.append(e)
        cfg["multipliers"] = cleaned
        save_units(cfg, base)
        print(f"✓ Multiplier cleared for {metric}")
