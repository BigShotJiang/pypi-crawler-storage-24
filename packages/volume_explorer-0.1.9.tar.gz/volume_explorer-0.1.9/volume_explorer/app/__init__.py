"""Streamlit dashboard for Petrel Volumetrics."""

import sys
from pathlib import Path


def cli():
    """Launch the Streamlit dashboard from the command line.

    Usage:
        volume-explorer [workdir]
        python -m volume_explorer [workdir]

    If workdir is given, it overrides the default data directory.
    """
    # Extract our own args before passing to streamlit
    workdir = None
    if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
        workdir = sys.argv.pop(1)

    main_script = str(Path(__file__).parent / "main.py")
    args = [
        "streamlit", "run", main_script,
        "--server.headless=true",
        "--browser.gatherUsageStats=false",
    ]
    if workdir:
        args += ["--", workdir]
    sys.argv = args

    from streamlit.web.cli import main as st_main
    st_main()
