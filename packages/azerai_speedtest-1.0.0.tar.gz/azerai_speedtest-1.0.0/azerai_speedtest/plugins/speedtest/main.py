"""
Speedtest Tools - LiveKit Agent Functions
İnternet sürət testi sistem araçları
"""
import logging
import threading
import time
import asyncio
from datetime import datetime
from typing import Dict, Any
from livekit.agents import function_tool, RunContext
import sounddevice as sd
import scipy.io.wavfile as wavfile
import numpy as np

logger = logging.getLogger("speedtest-tools")


def play_speedtest_music(stop_event):
    """
    Sürət testi işlemleri için arka plan müziği çalar.
    """
    try:
        music_dir = Path("plugins/speedtest/music")
        music_dir.mkdir(exist_ok=True)
        music_file = music_dir / "speedtest.wav"
        frequency = 440  # A4 notası - dengeli test tonu
        
        if not music_file.exists():
            sample_rate = 44100
            duration = 10.0  # 10 saniyelik döngü
            frequency = 440  # A4 notası - dengeli test tonu
            
            t = np.linspace(0, duration, int(sample_rate * duration), False)
            # Harmoniklerle hoş bir ses oluştur
            wave = 0.3 * np.sin(2 * np.pi * frequency * t) + \
                   0.1 * np.sin(2 * np.pi * frequency * 2 * t) + \
                   0.05 * np.sin(2 * np.pi * frequency * 3 * t)
            
            # Daha yumuşak yapmak ama tamamen solmasını engellemek için nazik zarf uygula
            envelope = 0.7 + 0.3 * np.sin(2 * np.pi * 0.5 * t)  # Nazik modülasyon
            wave = wave * envelope
            
            # Ses dosyası olarak kaydet
            wavfile.write(music_file, sample_rate, (wave * 32767).astype(np.int16))
        
        # Müzik dosyasını kusursuz çalma ile döngü olarak çal
        sample_rate, data = wavfile.read(str(music_file))
        
        while not stop_event.is_set():
            try:
                sd.play(data, sample_rate)
                # Sesin çalmasını bekle ama periyodik olarak stop_event kontrol et
                audio_duration = len(data) / sample_rate
                start_time = time.time()
                
                while time.time() - start_time < audio_duration:
                    if stop_event.is_set():
                        sd.stop()
                        return
                    time.sleep(0.1)  # Her 100ms'de bir kontrol et
                    
            except Exception as e:
                logging.error("Error playing background music: %s", e)
                break
                
    except ImportError:
        logging.warning("numpy not available for background music generation")
    except Exception as e:
        logging.error("Error in background music thread: %s", e)


class SpeedtestTools:
    """İnternet sürət testi alətləri"""
    
    def __init__(self):
        logger.info("SpeedtestTools initialized")

    def _run_speedtest(self) -> Dict[str, Any]:
        """Speedtest.net API ilə sürət testi edir"""
        try:
            import speedtest
            
            # Speedtest client oluştur
            st = speedtest.Speedtest()
            
            # Server seç
            st.get_best_server()
            
            # Download test
            download_speed = st.download()
            
            # Upload test
            upload_speed = st.upload()
            
            # Ping test
            ping = st.results.ping
            
            # Sonuçları formatla
            results = {
                'download': round(download_speed / 1_000_000, 2),  # Mbps
                'upload': round(upload_speed / 1_000_000, 2),      # Mbps
                'ping': round(ping, 2),                           # ms
                'server': st.server,
                'client': st.config.client
            }
            
            return results
            
        except ImportError:
            return {'error': 'Speedtest kütüphanesi qurulmayıb'}
        except Exception as e:
            return {'error': str(e)}


# Global instance
speedtest_tools = SpeedtestTools()


@function_tool()
async def check_internet_speed(ctx: RunContext) -> str:
    """
    İnternet bağlantısının sürətini test edir.
    
    Returns:
        Sürət testi nəticələri
    """
    logger = logging.getLogger("speedtest-plugin")
    
    try:
        logger.debug("=== SPEEDTEST START: set_audio_enabled(False) called ===")
        ctx.session.input.set_audio_enabled(False)

        stop_music = threading.Event()
        music_thread = threading.Thread(
            target=play_speedtest_music, 
            args=(stop_music,),
            daemon=True
        )
        music_thread.start()
        
        try:
            logger.debug("=== SPEEDTEST: Starting internet speed test ===")
            
            results = await asyncio.to_thread(
                speedtest_tools._run_speedtest
            )
            
            if 'error' in results:
                result_text = f"""⚡ SPEEDTEST ERROR

❌ Status: Test failed
🎵 Background music: A4 note (440 Hz)
⏰ Test time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

❌ Error:
{results['error']}"""
            else:
                result_text = f"""⚡ SPEEDTEST RESULTS

📊 Download: {results['download']} Mbps
📤 Upload: {results['upload']} Mbps
🏓 Ping: {results['ping']} ms
🌐 Server: {results.get('server', {}).get('name', 'Unknown')}
📍 Location: {results.get('server', {}).get('country', 'Unknown')}
🎵 Background music: A4 note (440 Hz)
⏰ Test time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

✅ Speedtest completed successfully"""
            
            logger.debug(f"=== SPEEDTEST COMPLETE: Test finished ===")
            return result_text
            
        except Exception as e:
            logger.debug(f"=== SPEEDTEST ERROR: {str(e)} ===")
            return f"Speedtest failed: {str(e)}"
        finally:
            stop_music.set()
            sd.stop()
            logger.debug("=== SPEEDTEST FINALLY: set_audio_enabled(True) called ===")
            ctx.session.input.set_audio_enabled(True)
        
    except Exception as e:
        logging.error(f"Speedtest plugin error: {e}")
        return f"Error during speedtest: {str(e)}"
