"""
AzerAI Speedtest Plugin
"""

from .main import check_internet_speed

__all__ = [
    "check_internet_speed"
]
