"""
AzerAI Speedtest Plugin - Plugin package
"""
