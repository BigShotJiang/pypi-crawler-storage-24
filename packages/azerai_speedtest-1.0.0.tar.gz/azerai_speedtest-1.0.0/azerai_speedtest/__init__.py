"""
AzerAI Speedtest Plugin - İnternet sürət testi plugini

Plugin əsaslı, çoxdilli AI asistenti üçün internet sürət testi modulu.
"""

__version__ = "1.0.0"
__author__ = "AzStudio Dev"
__email__ = "dev@azstudio.ai"

from .plugins.speedtest.main import check_internet_speed

__all__ = [
    "check_internet_speed"
]
