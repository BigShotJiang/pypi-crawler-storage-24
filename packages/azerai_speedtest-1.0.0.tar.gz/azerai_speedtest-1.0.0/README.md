# ⚡ AzerAI Speedtest Plugin

Azərbaycan dilində qabaqcıl səsli AI asistenti üçün internet sürət testi plugini.

## Xüsusiyyətlər

- ⚡ **Sürət testi** - Download, upload və ping ölçmə
- 🌐 **Speedtest.net API** - Etibarlı sürət test xidməti
- 📊 **Detallı nəticələr** - Tam metriklər
- 🎵 **Arxa plan musiqisi** - Test zamanı A4 notası
- 🎤 **Mikrofon kontrolü** - Test zamanı danışığı bloklayır
- 📍 **Server məlumatları** - Test serveri və location

## Quraşdırma

```bash
pip install azerai-speedtest
```

## İstifadə

Plugin avtomatik olaraq AzerAI tərəfindən aşkar edilir.

### Əmrlər

- `"İnternet sürətini test et"` - Sürət testi
- `"Bağlantı sürəti necədir?"` - Sürət sorğusu
- `"Speedtest çalıştır"` - Test icra et
- `"Download/upload yoxla"` - Spesifik test

## Fayl struktur

```
azerai_speedtest/
├── plugins/
│   └── speedtest/
│       ├── __init__.py
│       └── main.py
└── __init__.py
```

## Xüsusiyyətlər

### ⚡ **Sürət Testi**
- Download sürəti (Mbps)
- Upload sürəti (Mbps)
- Ping gecikməsi (ms)
- Server məlumatları
- Location məlumatları

### 📊 **Nəticə Formatı**
- Sürət metrikləri
- Test serveri
- Coğrafiya məlumatları
- Test vaxtı
- Arxa plan musiqi info

### 🌐 **API İnteqrasiyası**
- Speedtest.net API
- Avtomatik server seçimi
- Real-time nəticələr
- Error handling

## Asılılıqlar

- `livekit-agents>=1.0.0` - AI agent framework
- `speedtest>=2.1.3` - Sürət testi kütüphanəsi
- `sounddevice>=0.4.6` - Audio çalma
- `scipy>=1.11.0` - Audio işləmə
- `numpy>=1.24.0` - Riyazi əməliyyatlar

## Lisenziya

MIT License
