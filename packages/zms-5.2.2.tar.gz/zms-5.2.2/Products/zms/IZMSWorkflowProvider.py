################################################################################
# IZMSWorkflowProvider.py
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
################################################################################

# Imports.
from zope.interface import Interface

class IZMSWorkflowProvider(Interface):

  def getAutocommit(self):
    """
    @rtype: C{Boolean}
    """

  def getActivities(self):
    """
    @rtype: C{list}
    """

  def getActivityIds(self):
    """
    @rtype: C{list}
    """
  
  def getActivity(self, id):
    """
    @rtype: C{dict}
    """

  def getActivityDetails(self, id):
    """
    @rtype: C{dict}
    """

  def getTransitions(self):
    """
    @rtype: C{list}
    """

  def getTransitionIds(self):
    """
    @rtype: C{list}
    """