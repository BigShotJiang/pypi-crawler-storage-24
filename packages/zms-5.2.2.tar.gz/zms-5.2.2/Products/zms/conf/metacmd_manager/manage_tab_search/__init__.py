class manage_tab_search:
	"""
	python-representation of manage_tab_search
	"""

	# Acquired
	acquired = 0

	# Action
	action = "%smanage_executeMetacmd?id=manage_tab_search"

	# Description
	description = ""

	# Execution
	execution = False

	# Icon_clazz
	icon_clazz = "fas fa-cogs"

	# Id
	id = "manage_tab_search"

	# Meta_types
	meta_types = ["type(ZMSDocument)"]

	# Name
	name = "TAB_SEARCH"

	# Nodes
	nodes = "{$}"

	# Package
	package = "com.zms.custom.metacmd.tabs"

	# Revision
	revision = "5.0.2"

	# Roles
	roles = ["*"]

	# Stereotype
	stereotype = "tab"

	# Title
	title = "TAB_SEARCH"

	# Impl
	class Impl:
		manage_tab_search = {"id":"manage_tab_search"
			,"type":"Page Template"}
