//# ######################################
//# Handlebars Helper
//# ######################################
Handlebars.registerHelper("compareStrings", function (p, q, options) {
	return p == q ? options.fn(this) : options.inverse(this);
});
Handlebars.registerHelper('hide_tabs', function (length) {
	return length < 2 ? 'hidden' : 'not_hidden';
});
Handlebars.registerHelper('sanitize', function (str) {
	const element = document.createElement('div');
	element.innerText = String(str);
	return element.innerHTML;
});

//# ######################################
//# Init function show_results() as global
//# ######################################
var show_results;
var winloc = new URL(window.location);
//# ######################################
$(function() {
	const root_url=$('form#site-search-content').attr('data-root-url');
	//# Compile HB templ on docready into global var
	const hb_results_tmpl = Handlebars.compile( $('#hb_results_html').html() );
	const hb_spinner_tmpl = Handlebars.compile( $('#hb_spinner_html').html() );

	// Finally define show_results() on ready
	show_results = async (q, pageIndex) => {
		$('.search-results').html(hb_spinner_tmpl(q));
		// debugger;
		const qurl = `${root_url}/solr_query?q=${encodeURIComponent(q)}&pageIndex:int=${pageIndex}`;
		const response = await fetch(qurl);
		const res = await response.json();
		const res_processed = postprocess_results(q, res);
		var total = res_processed.total;
		var hb_results_html = hb_results_tmpl(res_processed);
		$('.search-results').html( hb_results_html );
		$('html, body').animate({scrollTop: $("#container_results").offset().top }, 1000);

		//# Add pagination ###################
		var fn = (pageIndex) => {
			return `javascript:show_results('${q}',${pageIndex})`
		};
		GetPagination(fn, total, 10, pageIndex);
		//# ##################################

		// Add object path on UUID/ZMSIndex
		$('ul.path').each(function() {
			show_breadcrumbs(this);
		})

	};

	const postprocess_results = (q, res) => {
		var total = res.response.numFound.value;
		var facets = []; // res.facets;
		var res_processed = { 'hits':[], 'total':total, 'query':q, 'facets':facets};

		res['response']['docs'].forEach(x => {
			var source = x;
			var hit = { 
				'path':source['uid'], 
				'href':source['index_html'], 
				'title':source['title'], 
				'snippet':source['standard_html']
			}; 
			// Snippet: field-name = 'standard_html'
			// Attachment: field-name = 'data'
			if ( typeof source['attachment'] !== 'undefined' && hit['snippet']=='' ) {
				hit['snippet'] = source['attachment']['content'];
			}
			if (hit['snippet'].length > 200) {
				hit['snippet'] = hit['snippet'].substring(0,200) + '...';
			}
			res_processed.hits.push(hit)
		})
		return res_processed;
	};

	const show_breadcrumbs = (el) => {
		const lang = $('#lang').attr('value');
		if ( el.dataset.id.startsWith('uid') ) {
			$.get(url=`${root_url}/solr_breadcrumbs_obj_path`, 
				data={ 'id' : el.dataset.id, 'lang' : lang },
				function(data, status) {
					$(el).html(data);
				}
			);
		}
	}

	//# Execute on submit event
	$('.search-form form').submit(function() {
		var q = $('input[name="q"]',this).val();
		winloc.searchParams.set('q', q);
		history.pushState({}, '', winloc);
		show_results(q, 0);
		return false;
	});

	//# Auto-execute search on URL parameter
	if ( winloc.searchParams.get('q') ) {
		$('#form-keyword').val(winloc.searchParams.get('q',''));
		$('.search-form form').trigger('submit');
	}

});