class com_zms_catalog_solr:
	"""
	python-representation of com.zms.catalog.solr
	"""

	# Access
	access = {"delete_custom":""
		,"delete_deny":[]
		,"insert_custom":""
		,"insert_deny":[]}

	# Enabled
	enabled = 0

	# Id
	id = "com.zms.catalog.solr"

	# Name
	name = "com.zms.catalog.solr"

	# Package
	package = ""

	# Revision
	revision = "1.1.1"

	# Type
	type = "ZMSPackage"
