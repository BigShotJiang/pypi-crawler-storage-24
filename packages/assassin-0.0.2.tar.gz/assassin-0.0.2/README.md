# assassin

A Python toolkit for targeted process termination, resource cleanup, and task management.

## Installation

```bash
pip install assassin
```

## Status

Currently in early development. First release coming soon.
