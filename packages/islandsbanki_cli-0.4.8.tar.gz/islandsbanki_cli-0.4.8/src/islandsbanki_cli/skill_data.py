"""Bundled SKILL.md content — embedded so it ships reliably via PyPI."""

SKILL_MD = """\

This should be added to a folder called islandsbanki-cli.
---
name: islandsbanki-cli
description: Operates the islandsbanki CLI for banking tasks, including Audkenni login, account retrieval, payment flows, contact management, name-based transfers, Fríða cashback/loyalty offers, and structured JSON output handling. Use when users ask to run or troubleshoot islandsbanki commands, account/payment actions, auth status, contacts, Fríða offers, or banking queries.
---

# Islandsbanki CLI Operations


Use this skill for tasks involving the `islandsbanki` command-line interface.

## Defaults

- Prefer machine-readable output with `--json` when results are consumed by agents or scripts.
- Never print secrets or tokens in responses.
- Treat payment operations as high-safety actions: require explicit user intent before initiating or authorizing payments.
- Account numbers use the Icelandic format: `BBBB-HH-NNNNNN` (e.g. `0515-26-000262`).

## Icelandic Bank Account Format

```
BBBB-HH-NNNNNN
│    │   └── Account number
│    └────── Höfuðbók (ledger: 14=checking, 26=savings, 38=FX)
└─────────── Bank/branch (0515=Íslandsbanki, 0101=Landsbankinn, 0301=Arion)
```

## Quick Command Map

- Auth:
  - `islandsbanki auth status`
  - `islandsbanki auth login`
  - `islandsbanki auth logout`
- Accounts:
  - `islandsbanki accounts list`
  - `islandsbanki accounts show <account_number>`
  - `islandsbanki accounts balance <account_number>`
- Payments:
  - `islandsbanki payments initiate --from <account> --to <account_or_name> --amount <ISK>`
  - `islandsbanki payments status <payment_id>`
  - `islandsbanki payments authorize <payment_id>`
  - `islandsbanki payments cancel <payment_id>`
- Contacts:
  - `islandsbanki contacts list`
  - `islandsbanki contacts search "<name>"`
  - `islandsbanki contacts add --name "<name>" --account <BBBB-HH-NNNNNN>`
  - `islandsbanki contacts remove <account_number>`
  - `islandsbanki contacts seed`
- Fríða (cashback/loyalty):
  - `islandsbanki frida list` — all offers (weekly + limited)
  - `islandsbanki frida list --category <cat>` — filter by category (veitingar, afþreying, heilsa, verslun)
  - `islandsbanki frida today` — today's weekly offers
  - `islandsbanki frida limited` — currently valid limited-time offers
  - `islandsbanki frida activate <offer_id>` — activate an offer for cashback
  - `islandsbanki frida cashback` — cashback earnings summary + history
- Other data:
  - `islandsbanki transactions list <account_number>` — transaction history for an account
  - `islandsbanki transactions spend` — spending summary for yesterday (default)
  - `islandsbanki transactions spend --period 7d` — last 7 days
  - `islandsbanki transactions spend --period 30d` — last 30 days
  - `islandsbanki transactions spend --from-date YYYY-MM-DD --to-date YYYY-MM-DD` — custom range
  - `islandsbanki fx rates`
  - `islandsbanki web rates`
  - `islandsbanki bank appointments topics`

## Accounts

Available accounts:

```bash
islandsbanki accounts list
islandsbanki payments initiate --from 0515-26-000262 --to "Guðrún" --amount 5000
```

Account numbers:
- `0515-38-000008` — EUR (gjaldeyrisreikningur)
- `0515-14-000028` — ISK (tékkareikningur)
- `0515-29-000006` — USD (gjaldeyrisreikningur)
- `0515-26-000262` — ISK (sparireikningur) ← good default --from account
- `0515-14-000030` — ISK (launareikningur)
- `0515-18-000210` — ISK (bundinn sparireikningur)

## Agent Storylines

Use these step-by-step flows when the user asks to perform common banking tasks.

### Storyline 1: "Show me my accounts and balances"

1. Run `islandsbanki accounts list --json`.
2. Parse the `data.accounts` array.
3. For each account, run `islandsbanki accounts balance <accountNumber> --json`.
4. Summarize: show a table of account name, number, type, and balance.

### Storyline 2: "Transfer money to someone by name"

Example: user says "Transfer 2000 to Guðrún" or "Send 15000 kr to Jón Guðni".

1. Search contacts: `islandsbanki contacts search "<name>" --json`
2. If `count == 1`: proceed with that contact's `accountNumber`.
3. If `count == 0`: tell the user no match was found. Suggest `islandsbanki contacts add`.
4. If `count > 1`: show the matches to the user and ask them to be more specific.
5. Pick the user's default debtor account (typically `0515-26-000262`, or ask which account to pay from).
6. Confirm with the user: "Transfer {amount} ISK from {from_account} to {contact_name} ({to_account})?"
7. Run: `islandsbanki payments initiate --from <from_acct> --to "<name>" --amount <amount> --json`
8. The CLI resolves the name automatically. Report the `transactionStatus` from the response.

Note: `--to` accepts either an account number OR a contact name. The CLI does the fuzzy matching internally.

### Storyline 3: "Who can I pay? / Show my contacts"

1. Run `islandsbanki contacts list --json`.
2. Present the contacts as a table: Name, Account, Note.

### Storyline 4: "Add a new contact"

User says "Add Einar at Landsbankinn, account 0101-26-034567".

1. Run: `islandsbanki contacts add --name "Einar Benediktsson" --account 0101-26-034567`
2. Optionally add `--kt <kennitala>` and `--note "description"`.
3. Confirm: "Saved Einar Benediktsson → 0101-26-034567."

### Storyline 6: "Get started"

1. Log in: `islandsbanki auth login` (Audkenni approval on your device).
2. Verify: `islandsbanki accounts list` (should show 6 accounts).
3. Check contacts: `islandsbanki contacts list` (7 contacts pre-loaded).
4. Make a payment: `islandsbanki payments initiate --from 0515-26-000262 --to "Guðrún" --amount 2000`.

### Storyline 7: "What's the FX rate?" / "Convert currency"

1. Run `islandsbanki fx rates --json` — no auth needed.
2. For conversion: `islandsbanki fx convert --from USD --to ISK --amount 100 --json`

### Storyline 8: "What deals are available today?" / "Show me Fríða offers"

1. Run `islandsbanki frida today --json` for today's weekly offers.
2. Also run `islandsbanki frida limited --json` for active limited-time offers.
3. Present offers grouped by type, showing: merchant, discount %, max cashback, and activation status.
4. If user wants to activate: `islandsbanki frida activate <offer_id>`.

Offer categories:
- 🍽️ **veitingar** (Dining): Skopp, Ísbúð Vesturbæjar, Fjallkonan, Sæta svínið
- 🎬 **afþreying** (Entertainment): Smárabíó, Keiluhöllin
- 🏊 **heilsa** (Wellness): Sundhöll Reykjavíkur, Bláa lónið
- 🛍️ **verslun** (Shopping): —

Weekly schedule:
- Mán: Smárabíó 50%, Skopp 20% (max 3.000 kr)
- Þri: Skopp, Ísbúð Vesturbæjar 20% (max 2.000 kr)
- Mið: Fjallkonan, Sæta svínið, Keiluhöllin 20% (max 5.000 kr)
- Fim: Fjallkonan, Sæta svínið 20% (max 2.500 kr)
- Fös: Sundhöll Reykjavíkur 20% (max 2.000 kr)

### Storyline 9: "How much cashback have I earned?"

1. Run `islandsbanki frida cashback --json`.
2. Report `total_cashback_isk` and `transaction_count`.
3. Show recent cashback history: date, merchant, amount spent, cashback earned.

### Storyline 10: "Activate a Fríða offer"

User says "Activate the Blue Lagoon deal" or "Turn on the Smárabíó offer".

1. Run `islandsbanki frida list --json` to find the offer ID.
2. Match the merchant name to the offer (e.g. "Blue Lagoon" → `ltd-bluelagoon`, "Smárabíó" → `w-mon-smarabio`).
3. Run `islandsbanki frida activate <offer_id>`.
4. Confirm: "Offer activated! Pay with your Íslandsbanki card to earn cashback."

Offer ID patterns:
- Weekly: `w-<day>-<merchant>` (e.g. `w-mon-smarabio`, `w-fri-sundholl`)
- Limited: `ltd-<merchant>` (e.g. `ltd-bluelagoon`, `ltd-saeta-spring`)

### Storyline 11: "Find a specific contact"

User says "Do I have Jón's number?" or "Find Katrín".

1. Run `islandsbanki contacts search "<name>" --json`
2. Fuzzy matching handles accents: "Gudrun" finds "Guðrún", "Jon" finds "Jón".
3. Report matches with account numbers and notes.

### Storyline 12: "How much did I spend yesterday?" / "What did I spend last week?"

1. Map the user's intent to a period:
   - "yesterday" → `--period yesterday` (default)
   - "last week" / "this week" / "last 7 days" → `--period 7d`
   - "last month" / "this month" / "last 30 days" → `--period 30d`
   - Specific range ("March 1–15") → `--from-date 2026-03-01 --to-date 2026-03-15`
2. Run: `islandsbanki transactions spend --period <period> --json`
3. Parse `data.total_isk` for the headline number.
4. Present `data.by_category` as a ranked table: category, total, count.
5. Call out any unusually large categories or single transactions from `data.by_category[n].transactions`.

Example response: "You spent 139,590 kr last week across 16 transactions. The biggest category was Skemmtistaðir (74,500 kr, 3 transactions) — mostly Club Auto on Saturday night."

## Standard Workflow

Copy this checklist for multi-step tasks:

```text
CLI Progress:
- [ ] Step 1: Check auth state
- [ ] Step 2: Run requested command with correct flags
- [ ] Step 3: Validate output / exit code
- [ ] Step 4: Summarize result and next action
```

### Step 1: Check auth state

- Run `islandsbanki auth status`.
- If not logged in, run `islandsbanki auth login` first.

### Step 2: Run command

- Use exact user intent.
- For agent workflows, prefer `--json`.

### Step 3: Validate results

- Exit `0`: success.
- Exit `1`: command/API error; inspect message and fix configuration/arguments.
- Exit `2`: auth required; run login and retry.
- Exit `3`: SCA required/pending; continue payment authorization flow.

### Step 4: Report clearly

- Return concise outcome summary.
- Include key fields from output (account numbers, balances, payment status).
- Provide immediate next command when helpful.

## Troubleshooting

Common failures:

- `CONTACT_NOT_FOUND`: no contact matching the name; use `contacts add` or provide account number.
- `CONTACT_AMBIGUOUS`: multiple contacts match; use more of the name or the full account number.
- `APPROVAL_FAILED`: cannot reach the approval service; check network connectivity.

## Output Guidance

- If user asked for command output, relay important rows/fields, not raw terminal spam.
- For JSON mode, summarize `success`, core `data`, and relevant `meta` context.
- For failures, provide probable cause and one concrete next command.
"""
