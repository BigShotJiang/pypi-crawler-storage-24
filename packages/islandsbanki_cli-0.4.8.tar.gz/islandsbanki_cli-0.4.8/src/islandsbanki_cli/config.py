"""
Configuration management.

Config file location: ~/.islandsbanki/config.toml

Example config.toml:
    [app]
    mock_app_url  = "http://github.is"   # frontend approval app URL
"""

from __future__ import annotations

import os
import tomllib
from pathlib import Path


CONFIG_DIR = Path.home() / ".islandsbanki"
CONFIG_FILE = CONFIG_DIR / "config.toml"

DEFAULT_MOCK_APP_URL = "http://github.is"


def _load_toml() -> dict:
    if not CONFIG_FILE.exists():
        return {}
    with open(CONFIG_FILE, "rb") as f:
        return tomllib.load(f)


def get_mock_app_url() -> str:
    """Resolve the mock app URL.  Priority: env var > config.toml > default."""
    env = os.environ.get("MOCK_APP_URL")
    if env:
        return env.rstrip("/")
    raw = _load_toml()
    url = raw.get("app", {}).get("mock_app_url", "")
    if url:
        return url.rstrip("/")
    return DEFAULT_MOCK_APP_URL


def ensure_config_dir() -> None:
    """Create ~/.islandsbanki/ if it doesn't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
