"""
Root CLI entry point for islandsbanki-cli.

Registers all sub-command groups and provides the --json / --sandbox
global flags that all sub-commands respect via the shared `state` module.

Usage examples:
    islandsbanki --help
    islandsbanki --version
    islandsbanki auth login --sandbox
    islandsbanki accounts list --json
    islandsbanki payments initiate --from IS85... --to IS52... --amount 5000
"""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from . import __version__
from . import state
from .commands import (
    auth,
    accounts,
    payments,
    transactions,
    cards,
    profile,
    fx,
    bank,
    web,
    contacts,
    frida,
)
from .version_check import check_for_update


from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file if it exists
app = typer.Typer(
    name="islandsbanki",
    help=(
        "[bold]Íslandsbanki Open Banking CLI[/bold]\n\n"
        "Designed for AI agents and personal assistants. "
        "Every command supports [cyan]--json[/cyan] for machine-readable output.\n\n"
        "[dim]Zero-trust: payments require Audkenni 2FA confirmation.[/dim]"
    ),
    add_completion=True,
    rich_markup_mode="rich",
    no_args_is_help=True,
)

console = Console()

# Register all sub-command groups
app.add_typer(
    auth.app, name="auth", help="Authenticate with Íslandsbanki — e.g. islandsbanki auth login"
)
app.add_typer(
    accounts.app,
    name="accounts",
    help="View accounts and balances — e.g. islandsbanki accounts list or islandsbanki accounts balance 0515-26-000262",
)
app.add_typer(
    payments.app,
    name="payments",
    help='Initiate and manage payments — e.g. islandsbanki payments initiate --to "Guðrún" --amount 5000',
)
app.add_typer(
    transactions.app,
    name="transactions",
    help="View transaction history — e.g. islandsbanki transactions spend --period 7d or islandsbanki transactions list 0515-26-000262",
)
app.add_typer(
    cards.app,
    name="cards",
    help="Manage debit and credit cards — e.g. islandsbanki cards list or islandsbanki cards freeze <card_id>",
)
app.add_typer(
    profile.app,
    name="profile",
    help="View your profile and contact info — e.g. islandsbanki profile show or islandsbanki profile advisor",
)
app.add_typer(
    fx.app,
    name="fx",
    help="Foreign exchange rates and conversion — e.g. islandsbanki fx rates or islandsbanki fx convert --from USD --to ISK --amount 100",
)
app.add_typer(
    bank.app,
    name="bank",
    help="Book advisor meetings — e.g. islandsbanki bank appointments topics or islandsbanki bank appointments slots --topic mortgage",
)
app.add_typer(
    web.app,
    name="web",
    help="Public info from islandsbanki.is — e.g. islandsbanki web rates or islandsbanki web branches",
)
app.add_typer(
    contacts.app,
    name="contacts",
    help='Manage payment contacts — e.g. islandsbanki contacts list or islandsbanki contacts search "Jón"',
)
app.add_typer(
    frida.app,
    name="frida",
    help="Fríða cashback & loyalty — e.g. islandsbanki frida today or islandsbanki frida activate w-mon-smarabio",
)


@app.command("get-skill")
def get_skill():
    """Print the SKILL.md for this CLI (used by AI agents like OpenClaw)."""
    from .skill_data import SKILL_MD

    typer.echo(SKILL_MD)
    raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        is_eager=True,
        help="Show version and exit.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output raw JSON — ideal for AI agents.",
        envvar="ISB_JSON",
    ),
):
    """Íslandsbanki Open Banking CLI."""
    if version:
        console.print(f"islandsbanki-cli [bold]{__version__}[/bold]")
        raise typer.Exit()

    # Propagate flags to shared state so all sub-commands can read them
    state.json_output = json_output

    # Non-blocking update check
    msg = check_for_update()
    if msg:
        console.print(msg)

    if ctx.invoked_subcommand is None:
        console.print(ctx.get_help())
