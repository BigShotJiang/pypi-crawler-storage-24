"""
Global mutable state for the CLI session.

Flags set by the root callback are read by all sub-commands.
"""
from __future__ import annotations

# Set True when --json flag is passed at root level or per command.
# All output functions check this before rendering rich UI.
json_output: bool = False
