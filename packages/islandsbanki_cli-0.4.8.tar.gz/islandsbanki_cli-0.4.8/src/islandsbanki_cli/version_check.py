"""Check PyPI for a newer version of the package (non-blocking)."""
from __future__ import annotations

import json
import urllib.request
import urllib.error
from functools import lru_cache

from . import __version__

_PYPI_PACKAGE = "islandsbanki-cli"
_PYPI_URL = f"https://pypi.org/pypi/{_PYPI_PACKAGE}/json"


@lru_cache(maxsize=1)
def get_latest_version() -> str | None:
    """Fetch latest version string from PyPI. Returns None on any failure."""
    try:
        req = urllib.request.Request(_PYPI_URL, method="GET")
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read())
            return data.get("info", {}).get("version")
    except Exception:
        return None


def _parse_version(v: str) -> tuple[int, ...]:
    """Turn '0.2.1' into (0, 2, 1) for comparison."""
    parts: list[int] = []
    for segment in v.split("."):
        digits = ""
        for ch in segment:
            if ch.isdigit():
                digits += ch
            else:
                break
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def check_for_update() -> str | None:
    """Return an update message if a newer version exists, else None."""
    latest = get_latest_version()
    if latest is None:
        return None
    try:
        if _parse_version(latest) > _parse_version(__version__):
            return (
                f"\n[yellow]⬆  Update available:[/yellow] "
                f"[bold]{__version__}[/bold] → [bold green]{latest}[/bold green]  "
                f"— run [cyan]pip install --upgrade {_PYPI_PACKAGE}[/cyan]\n"
            )
    except Exception:
        pass
    return None
