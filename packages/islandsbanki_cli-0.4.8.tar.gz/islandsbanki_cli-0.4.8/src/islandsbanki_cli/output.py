"""
Output helpers — every command uses these to respect --json mode.

Shape of every JSON envelope:
{
  "success": true|false,
  "data":    <command-specific payload>,
  "error":   null | {"code": "...", "message": "...", "detail": "..."},
  "meta":    {"command": "...", "sandbox": bool, "version": "..."}
}

Exit codes:
  0  Success
  1  General error
  2  Authentication required (not logged in / token expired)
  3  2FA / SCA required (action needs Audkenni approval)
"""

from __future__ import annotations

import json
from typing import Any, NoReturn, Optional

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from . import __version__
from . import state

console = Console()
err_console = Console(stderr=True)


def _meta() -> dict:
    return {"version": __version__}


def success(data: Any, *, command: str = "") -> None:
    """Print a successful result and exit 0."""
    if state.json_output:
        payload = {"success": True, "data": data, "error": None, "meta": _meta()}
        print(json.dumps(payload, ensure_ascii=False, indent=2, default=str))
    # Rich output is handled inline by the calling command when json_output=False.


def error(
    message: str,
    *,
    code: str = "ERROR",
    detail: Optional[str] = None,
    exit_code: int = 1,
) -> NoReturn:
    """Print an error and exit with the given exit code."""
    if state.json_output:
        payload = {
            "success": False,
            "data": None,
            "error": {"code": code, "message": message, "detail": detail},
            "meta": _meta(),
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        err_console.print(f"[bold red]Error:[/bold red] {message}")
        if detail:
            err_console.print(f"[dim]{detail}[/dim]")
    raise typer.Exit(exit_code)


def auth_required() -> NoReturn:
    """Exit with code 2 — caller must run `islandsbanki auth login`."""
    error(
        "Not authenticated. Run: islandsbanki auth login",
        code="AUTH_REQUIRED",
        exit_code=2,
    )


def sca_required(action: str) -> NoReturn:
    """Exit with code 3 — SCA/2FA challenge must be completed first."""
    error(
        f"This action requires Audkenni 2FA approval: {action}",
        code="SCA_REQUIRED",
        exit_code=3,
    )


def print_json(data: Any) -> None:
    """Always print raw JSON (used in --json mode for sub-steps)."""
    print(json.dumps(data, ensure_ascii=False, indent=2, default=str))


def print_table(rows: list[dict], title: str = "") -> Table:
    """Render a list of dicts as a Rich table."""
    if not rows:
        console.print("[dim]No results.[/dim]")
        return
    t = Table(title=title, box=box.ROUNDED, highlight=True)
    for col in rows[0].keys():
        t.add_column(str(col), overflow="fold")
    for row in rows:
        t.add_row(*[str(v) for v in row.values()])
    console.print(t)
    return t


def info(msg: str) -> None:
    if not state.json_output:
        console.print(f"[cyan]ℹ[/cyan]  {msg}")


def warn(msg: str) -> None:
    if not state.json_output:
        console.print(f"[yellow]⚠[/yellow]  {msg}")


def ok(msg: str) -> None:
    if not state.json_output:
        console.print(f"[green]✓[/green]  {msg}")


def spinner_msg(msg: str) -> None:
    """Used before long operations when not in JSON mode."""
    if not state.json_output:
        console.print(f"[dim]⏳ {msg}[/dim]")
