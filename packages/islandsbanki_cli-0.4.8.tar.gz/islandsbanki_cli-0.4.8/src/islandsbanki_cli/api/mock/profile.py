"""
Mock: User profile and personal information.

In production this would integrate with the IOBWS customer API.
Mocked for POC demo purposes.
"""
from __future__ import annotations

_MOCK_PROFILE = {
    "customerId": "ISB-USER-00142374",
    "name": "Jón Björnsson",
    "kennitala": "0101904519",
    "email": "jon.bjornsson@gmail.com",
    "phone": "+354 772 3344",
    "preferredLanguage": "is",
    "addresses": [
        {
            "type": "home",
            "street": "Njálsgata 42",
            "postalCode": "101",
            "city": "Reykjavík",
            "country": "IS",
            "primary": True,
        },
        {
            "type": "work",
            "street": "Borgartún 21",
            "postalCode": "105",
            "city": "Reykjavík",
            "country": "IS",
            "primary": False,
        },
    ],
    "bankRelationshipSince": "2009-05-14",
    "customerSegment": "retail",
    "advisor": {
        "name": "Sigríður Ólafsdóttir",
        "email": "sigridur@islandsbanki.is",
        "phone": "+354 440 4000 ext 3221",
        "branch": "Höfðatorg",
    },
}


def get_profile() -> dict:
    """Return the authenticated user's profile information."""
    return _MOCK_PROFILE.copy()


def get_addresses() -> list[dict]:
    """Return all registered addresses for the user."""
    return list(_MOCK_PROFILE["addresses"])  # type: ignore[arg-type]


def get_advisor() -> dict:
    """Return contact info for the user's assigned bank advisor."""
    return dict(_MOCK_PROFILE["advisor"])  # type: ignore[arg-type]
