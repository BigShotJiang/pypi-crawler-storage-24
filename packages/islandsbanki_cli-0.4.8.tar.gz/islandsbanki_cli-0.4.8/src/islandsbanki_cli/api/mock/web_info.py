"""
Mock: Web information scraper for islandsbanki.is.

Fetches publicly available information from the Íslandsbanki website.
This is read-only — no auth required. Useful for agents that need
current rates, branch info, news, or product details.

Endpoints implemented:
  - Mortgage rates      islandsbanki.is (interest rate tables)
  - Branch locations    islandsbanki.is/einstaklingar/thjonustuver
  - News / press        islandsbanki.is/um-islandsbanki/frettir
  - Products overview   Loans, savings, cards, insurance categories

All functions fall back to embedded mock data if the live fetch fails,
ensuring the POC works even without internet access.
"""
from __future__ import annotations

from typing import Optional

import httpx
from bs4 import BeautifulSoup


_BASE = "https://www.islandsbanki.is"

# ---------------------------------------------------------------------------
# Fallback mock data (used when live fetch fails)
# ---------------------------------------------------------------------------

_MAX_MORTGAGE_TERM = "40 ár"

_FALLBACK_RATES = {
    "mortgage": [
        {
            "product": "Fasteignalán með verðtryggingu (breytileg)",
            "rate": "5.00%",
            "rateType": "variable",
            "indexed": True,
            "maxLTV": "80%",
            "maxTerm": _MAX_MORTGAGE_TERM,
        },
        {
            "product": "Fasteignalán með verðtryggingu (föst 5 ár)",
            "rate": "5.30%",
            "rateType": "fixed-5yr",
            "indexed": True,
            "maxLTV": "80%",
            "maxTerm": _MAX_MORTGAGE_TERM,
        },
        {
            "product": "Fasteignalán án verðtryggingar (breytileg)",
            "rate": "7.95%",
            "rateType": "variable",
            "indexed": False,
            "maxLTV": "80%",
            "maxTerm": _MAX_MORTGAGE_TERM,
        },
        {
            "product": "Fasteignalán án verðtryggingar (föst 3 ár)",
            "rate": "8.20%",
            "rateType": "fixed-3yr",
            "indexed": False,
            "maxLTV": "80%",
            "maxTerm": _MAX_MORTGAGE_TERM,
        },
    ],
    "savings": [
        {
            "product": "Sparareikningur (almennur)",
            "rate": "5.50%",
            "rateType": "variable",
            "indexed": False,
            "minBalance": "0 ISK",
            "notice": "Engin",
        },
        {
            "product": "Frjálsir lífeyrissjóðir — sparnaður",
            "rate": "Markaðstengdur",
            "rateType": "market",
            "indexed": False,
            "minBalance": "1,000 ISK/mán.",
            "notice": "N/A",
        },
    ],
    "deposit": [
        {
            "product": "Bundinn sparnaður 3 mánuðir",
            "rate": "6.10%",
            "rateType": "fixed",
            "indexed": False,
            "minDeposit": "100,000 ISK",
            "term": "3 mánuðir",
        },
        {
            "product": "Bundinn sparnaður 6 mánuðir",
            "rate": "6.40%",
            "rateType": "fixed",
            "indexed": False,
            "minDeposit": "100,000 ISK",
            "term": "6 mánuðir",
        },
    ],
}

_FALLBACK_BRANCHES = [
    {
        "name": "Höfðatorg",
        "address": "Borgartún 12, 105 Reykjavík",
        "phone": "440 4000",
        "hours": "Mán–Fös 9:00–16:00",
        "services": ["full", "atm", "safe-deposit"],
        "coordinates": {"lat": 64.1406, "lon": -21.9100},
    },
    {
        "name": "Garðabær",
        "address": "Þórsgata 1, 210 Garðabær",
        "phone": "440 4000",
        "hours": "Mán–Fös 9:30–16:00",
        "services": ["full", "atm"],
        "coordinates": {"lat": 64.0869, "lon": -21.9455},
    },
    {
        "name": "Smáralind",
        "address": "Hagasmári 1, 201 Kópavogur",
        "phone": "440 4000",
        "hours": "Mán–Fös 10:00–18:00, Lau 10:00–16:00",
        "services": ["full", "atm"],
        "coordinates": {"lat": 64.1052, "lon": -21.9082},
    },
    {
        "name": "Akureyri",
        "address": "Hafnarstræti 91, 600 Akureyri",
        "phone": "440 4000",
        "hours": "Mán–Fös 9:00–16:00",
        "services": ["full", "atm"],
        "coordinates": {"lat": 65.6835, "lon": -18.1002},
    },
    {
        "name": "Selfoss",
        "address": "Austurvegur 7, 800 Selfoss",
        "phone": "440 4000",
        "hours": "Mán–Fös 9:30–16:00",
        "services": ["full", "atm"],
        "coordinates": {"lat": 63.9329, "lon": -21.0094},
    },
]

_FALLBACK_PRODUCTS = {
    "loans": [
        {"name": "Fasteignalán", "url": f"{_BASE}/einstaklingar/lan/fasteignalan/"},
        {"name": "Bílalán", "url": f"{_BASE}/einstaklingar/lan/bilan/"},
        {"name": "Persónulegar lánalínur", "url": f"{_BASE}/einstaklingar/lan/"},
        {"name": "Námslán", "url": f"{_BASE}/einstaklingar/lan/namslan/"},
    ],
    "savings": [
        {"name": "Sparareikningar", "url": f"{_BASE}/einstaklingar/sparnadur/"},
        {"name": "Frjálsir lífeyrissjóðir", "url": f"{_BASE}/einstaklingar/sparnadur/lifeyrir/"},
    ],
    "cards": [
        {"name": "Debetkort", "url": f"{_BASE}/einstaklingar/kort/debetkort/"},
        {"name": "Kreditkort", "url": f"{_BASE}/einstaklingar/kort/kreditkort/"},
    ],
    "insurance": [
        {"name": "Húseigendatrygging", "url": f"{_BASE}/tryggingar/huseignatrygging/"},
        {"name": "Líftrygging", "url": f"{_BASE}/tryggingar/liftrygging/"},
        {"name": "Ferðatrygging", "url": f"{_BASE}/tryggingar/ferdatrygging/"},
    ],
}


# ---------------------------------------------------------------------------
# Public functions
# ---------------------------------------------------------------------------

def get_interest_rates(category: str = "mortgage") -> dict:
    """
    Fetch current interest rates from islandsbanki.is.

    Args:
        category: "mortgage" | "savings" | "deposit"

    Returns:
        Dict with "category", "rates" list, and "source" ("live" or "cached").

    Falls back to built-in mock data if the live fetch fails.
    """
    if category not in _FALLBACK_RATES:
        raise ValueError(
            f"Unknown category: '{category}'. Valid: {', '.join(_FALLBACK_RATES.keys())}"
        )

    try:
        rates = _scrape_rates(category)
        return {"category": category, "rates": rates, "source": "live", "_mock": False}
    except Exception:
        return {
            "category": category,
            "rates": _FALLBACK_RATES[category],
            "source": "cached",
            "_mock": True,
        }


def get_branches(near: Optional[str] = None) -> list[dict]:
    """
    Return branch locations.

    Args:
        near: Optional city/area filter (case-insensitive partial match on name/address).

    Returns:
        List of branch dicts with name, address, phone, hours, coordinates.
    """
    branches = _FALLBACK_BRANCHES.copy()
    if near:
        q = near.lower()
        branches = [
            b for b in branches
            if q in b["name"].lower() or q in b["address"].lower()
        ]
    return branches


def get_news(limit: int = 5) -> list[dict]:
    """
    Fetch latest news from islandsbanki.is.

    Falls back to empty list if live fetch fails.
    """
    try:
        return _scrape_news(limit)
    except Exception:
        return [
            {
                "title": "Íslandsbanki kynnir nýja opna bankaþjónustu",
                "date": "2026-03-15",
                "url": f"{_BASE}/um-islandsbanki/frettir/",
                "summary": "Íslandsbanki hefur kynnt til sögunnar nýja opna bankaþjónustu sem gerir þriðja aðilum kleift að...",
                "_mock": True,
            }
        ]


def get_products(category: Optional[str] = None) -> dict:
    """
    Return product categories and links.

    Args:
        category: Optional filter — "loans" | "savings" | "cards" | "insurance"
    """
    if category:
        c = category.lower()
        if c not in _FALLBACK_PRODUCTS:
            raise ValueError(
                f"Unknown category: '{c}'. Valid: {', '.join(_FALLBACK_PRODUCTS.keys())}"
            )
        return {c: _FALLBACK_PRODUCTS[c]}
    return _FALLBACK_PRODUCTS.copy()


# ---------------------------------------------------------------------------
# Scrapers (best-effort — fall back gracefully)
# ---------------------------------------------------------------------------

def _scrape_rates(category: str) -> list[dict]:
    """Attempt to scrape live rates from islandsbanki.is."""
    url = f"{_BASE}/einstaklingar/lan/fasteignalan/vextir/" if category == "mortgage" else \
          f"{_BASE}/einstaklingar/sparnadur/vextir/"

    resp = httpx.get(url, timeout=8, follow_redirects=True)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "lxml")

    # Extract rate table rows — structure varies, this is a best-effort parse
    rows = []
    for table in soup.select("table"):
        for tr in table.select("tr"):
            cells = [td.get_text(strip=True) for td in tr.select("td, th")]
            if len(cells) >= 2 and any(cells):
                rows.append({"product": cells[0], "rate": cells[1] if len(cells) > 1 else "—"})

    if not rows:
        raise ValueError("Could not parse rate table from islandsbanki.is")
    return rows


def _scrape_news(limit: int) -> list[dict]:
    """Attempt to scrape news headlines from islandsbanki.is."""
    resp = httpx.get(
        f"{_BASE}/um-islandsbanki/frettir/",
        timeout=8,
        follow_redirects=True,
    )
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "lxml")

    articles = []
    for article in soup.select("article, .news-item, .press-release")[:limit]:
        title_el = article.select_one("h2, h3, .title")
        date_el = article.select_one("time, .date")
        link_el = article.select_one("a")
        if title_el:
            articles.append({
                "title": title_el.get_text(strip=True),
                "date": date_el.get("datetime", "") if date_el else "",
                "url": (_BASE + link_el["href"]) if link_el and link_el.get("href") else "",
                "summary": "",
                "_mock": False,
            })

    if not articles:
        raise ValueError("No articles found")
    return articles
