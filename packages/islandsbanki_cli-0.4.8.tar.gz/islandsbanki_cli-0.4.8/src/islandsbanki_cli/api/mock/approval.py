"""
Client for the frontend approval API.

The CLI sends approval requests to the frontend app for user
confirmation of sensitive actions (login, payments).

The user approves/rejects in the mobile-app UI.
"""

from __future__ import annotations

import time

import httpx

from ...config import get_mock_app_url

POLL_INTERVAL = 1.0  # seconds
POLL_TIMEOUT = 120.0  # seconds


def request_approval(
    approval_type: str,
    details: dict,
) -> dict:
    """
    Send an approval request to the frontend and poll until the user responds.

    Args:
        approval_type: "login", "payment", or "sca"
        details: dict of info shown to the user (amount, accounts, etc.)

    Returns:
        The full approval record with status "approved" or "rejected".

    Raises:
        RuntimeError: if the frontend is unreachable or times out.
    """
    base = get_mock_app_url()
    payload = {"type": approval_type, "details": details}

    try:
        resp = httpx.post(f"{base}/api/approve", json=payload, timeout=5.0)
        resp.raise_for_status()
    except httpx.ConnectError:
        raise RuntimeError(
            f"Cannot reach the app at {base}. "
            "Start it with: cd front-mock-ai-agent-protocol && npm run dev"
        )
    except httpx.HTTPError as e:
        raise RuntimeError(f"Approval API error: {e}")

    record = resp.json()
    request_id = record["id"]

    # Poll until the user responds
    deadline = time.monotonic() + POLL_TIMEOUT
    while time.monotonic() < deadline:
        time.sleep(POLL_INTERVAL)
        try:
            poll_resp = httpx.get(f"{base}/api/approve/{request_id}", timeout=5.0)
            poll_resp.raise_for_status()
            data = poll_resp.json()
            if data["status"] in ("approved", "rejected"):
                return data
        except httpx.HTTPError:
            continue  # transient error, keep polling

    raise RuntimeError(
        f"Approval timed out after {POLL_TIMEOUT}s. "
        "Open the mock app and approve/reject the request."
    )
