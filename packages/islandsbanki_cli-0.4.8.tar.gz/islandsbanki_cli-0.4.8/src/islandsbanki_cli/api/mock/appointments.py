"""
Mock: Bank interactions — appointment booking and advisor contact.

Supports scheduling consultations with bank advisors. Mocked for POC.
In production this would integrate with the bank's CRM / calendar system.

Supported topics:
  - mortgage       Mortgage application and advice
  - refinancing    Refinancing existing loans
  - savings        Savings plans and deposit accounts
  - investment     Investment portfolio advice
  - business       Business banking and SME services
  - insurance      Íslandsbanki insurance products
  - general        General banking assistance

The flow for an agent:
  1. islandsbanki bank appointments slots --topic mortgage
     → Returns available time slots with slot IDs
  2. islandsbanki bank appointments book --slot-id SLOT-005 --topic mortgage
     → Returns confirmed appointment + iCal export option
  3. islandsbanki bank appointments list
     → Shows upcoming appointments
  4. islandsbanki bank appointments cancel <appointment-id>
     → Cancels the appointment
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta
from typing import Optional


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

TOPICS = {
    "mortgage": "Húsnæðislán / Mortgage",
    "refinancing": "Endurfjármögnun / Refinancing",
    "savings": "Sparnaður / Savings",
    "investment": "Fjárfesting / Investment",
    "business": "Fyrirtækjaþjónusta / Business Banking",
    "insurance": "Tryggingar / Insurance",
    "general": "Almenn þjónusta / General",
}

BRANCHES = [
    {"id": "BRANCH-HT", "name": "Höfðatorg", "address": "Borgartún 12, 105 Reykjavík"},
    {"id": "BRANCH-GB", "name": "Garðabær", "address": "Þórsgata 1, 210 Garðabær"},
    {"id": "BRANCH-AK", "name": "Akureyri", "address": "Hafnarstræti 91, 600 Akureyri"},
    {"id": "BRANCH-SM", "name": "Smáralind", "address": "Hagasmári 1, 201 Kópavogur"},
]

ADVISORS = {
    "mortgage": {"name": "Sigríður Ólafsdóttir", "email": "sigridur@islandsbanki.is"},
    "refinancing": {"name": "Sigríður Ólafsdóttir", "email": "sigridur@islandsbanki.is"},
    "savings": {"name": "Gunnar Magnússon", "email": "gunnar.magnusson@islandsbanki.is"},
    "investment": {"name": "Anna Sigurðardóttir", "email": "anna.sigurdardottir@islandsbanki.is"},
    "business": {"name": "Einar Jónsson", "email": "einar.jonsson@islandsbanki.is"},
    "insurance": {"name": "María Björnsdóttir", "email": "maria.bjornsdottir@islandsbanki.is"},
    "general": {"name": "Þorsteinn Guðmundsson", "email": "thorsteinn@islandsbanki.is"},
}

# In-memory store for booked appointments
_BOOKED: dict[str, dict] = {}


# ---------------------------------------------------------------------------
# Slot generation
# ---------------------------------------------------------------------------

def _generate_slots(topic: str, branch_id: Optional[str] = None) -> list[dict]:
    """Generate available time slots for the next 5 business days."""
    slots = []
    base = datetime.now().replace(hour=9, minute=0, second=0, microsecond=0)
    slot_counter = 1
    days_added = 0

    while len(slots) < 8 and days_added < 10:
        base += timedelta(days=1)
        days_added += 1
        # Skip weekends
        if base.weekday() >= 5:
            continue

        for hour in [9, 10, 11, 14, 15, 16]:
            slot_time = base.replace(hour=hour)
            branch = (
                next((b for b in BRANCHES if b["id"] == branch_id), BRANCHES[0])
                if branch_id
                else BRANCHES[slot_counter % len(BRANCHES)]
            )
            advisor = ADVISORS.get(topic, ADVISORS["general"])

            slots.append({
                "slotId": f"SLOT-{topic[:3].upper()}-{slot_counter:03d}",
                "dateTime": slot_time.isoformat(),
                "durationMinutes": 45,
                "topic": topic,
                "topicLabel": TOPICS.get(topic, topic),
                "branch": branch,
                "advisor": advisor,
                "available": True,
            })
            slot_counter += 1
            if len(slots) >= 8:
                break

    return slots


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def list_slots(
    topic: str = "general",
    branch_id: Optional[str] = None,
) -> list[dict]:
    """
    Return available appointment slots for a given topic.

    Args:
        topic:     One of TOPICS keys (e.g. "mortgage", "savings").
        branch_id: Optional branch filter (e.g. "BRANCH-HT").

    Returns:
        List of slot dicts, each with slotId, dateTime, branch, advisor.
    """
    if topic not in TOPICS:
        raise ValueError(
            f"Unknown topic: '{topic}'. Valid topics: {', '.join(TOPICS.keys())}"
        )
    return _generate_slots(topic, branch_id)


def book_appointment(
    slot_id: str,
    topic: str,
    notes: Optional[str] = None,
) -> dict:
    """
    Book an appointment by slot ID.

    Args:
        slot_id:  Slot ID from list_slots() (e.g. "SLOT-MOR-001").
        topic:    Topic key (used to look up advisor & description).
        notes:    Optional preparation notes for the advisor.

    Returns:
        Confirmed appointment dict including appointmentId and iCalData.
    """
    # Resolve the slot
    slots = _generate_slots(topic)
    slot = next((s for s in slots if s["slotId"] == slot_id), None)

    if not slot:
        raise ValueError(
            f"Slot '{slot_id}' not found or no longer available. "
            "Run `islandsbanki bank appointments slots` to see current availability."
        )

    appointment_id = f"APPT-{uuid.uuid4().hex[:8].upper()}"
    dt = datetime.fromisoformat(slot["dateTime"])

    appointment = {
        "appointmentId": appointment_id,
        "slotId": slot_id,
        "status": "confirmed",
        "dateTime": slot["dateTime"],
        "durationMinutes": slot["durationMinutes"],
        "topic": topic,
        "topicLabel": TOPICS.get(topic, topic),
        "branch": slot["branch"],
        "advisor": slot["advisor"],
        "notes": notes or "",
        "iCalData": _build_ical(appointment_id, dt, slot),
        "_mock": True,
    }

    _BOOKED[appointment_id] = appointment
    return appointment


def list_appointments() -> list[dict]:
    """Return all upcoming booked appointments for the user."""
    now = datetime.now().isoformat()
    upcoming = [
        a for a in _BOOKED.values()
        if a["dateTime"] > now
    ]
    return sorted(upcoming, key=lambda x: x["dateTime"])


def cancel_appointment(appointment_id: str) -> dict:
    """
    Cancel a booked appointment.

    Returns:
        The cancelled appointment dict (status: "cancelled").
    Raises:
        ValueError if appointment not found.
    """
    if appointment_id not in _BOOKED:
        raise ValueError(
            f"Appointment '{appointment_id}' not found. "
            "Run `islandsbanki bank appointments list` to see your bookings."
        )
    _BOOKED[appointment_id]["status"] = "cancelled"
    return _BOOKED[appointment_id]


# ---------------------------------------------------------------------------
# iCal helper
# ---------------------------------------------------------------------------

def _build_ical(appointment_id: str, dt: datetime, slot: dict) -> str:
    """Build a minimal iCalendar (.ics) string for the appointment."""
    dt_end = dt + timedelta(minutes=slot["durationMinutes"])
    fmt = "%Y%m%dT%H%M%S"
    branch = slot["branch"]
    advisor = slot["advisor"]
    topic_label = slot["topicLabel"]

    return "\r\n".join([
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//islandsbanki-cli//0.1.0//EN",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        "BEGIN:VEVENT",
        f"UID:{appointment_id}@islandsbanki-cli",
        f"DTSTART:{dt.strftime(fmt)}",
        f"DTEND:{dt_end.strftime(fmt)}",
        f"SUMMARY:Íslandsbanki — {topic_label}",
        f"LOCATION:{branch['name']}, {branch['address']}",
        f"DESCRIPTION:Advisor: {advisor['name']} ({advisor['email']})\\nAppointment ID: {appointment_id}",
        "STATUS:CONFIRMED",
        "END:VEVENT",
        "END:VCALENDAR",
    ])


def get_ical(appointment_id: str) -> Optional[str]:
    """Return iCal data for a booked appointment, or None if not found."""
    appt = _BOOKED.get(appointment_id)
    if not appt:
        return None
    return appt.get("iCalData")


def list_topics() -> dict:
    """Return all supported appointment topics."""
    return TOPICS.copy()
