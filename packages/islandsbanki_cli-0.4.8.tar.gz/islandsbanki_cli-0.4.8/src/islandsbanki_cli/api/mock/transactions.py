"""
Mock: Transaction history across all accounts.

Realistic Icelandic transaction data spanning ~2 months back from today.
Last weekend (2026-03-14/15) includes a heavy night out at Club Auto & Röntgen.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import date
from typing import Optional


_MOCK_TRANSACTIONS = [
    # ── 2026-03-19 (yesterday) ─────────────────────────────────────────
    {
        "transactionId": "TXN-20260319-001",
        "bookingDate": "2026-03-19",
        "valueDate": "2026-03-19",
        "transactionAmount": {"amount": "-5890.00", "currency": "ISK"},
        "creditorName": "Krónan Laugavegi",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matvara",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Matarinnkaup",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260319-002",
        "bookingDate": "2026-03-19",
        "valueDate": "2026-03-19",
        "transactionAmount": {"amount": "-2100.00", "currency": "ISK"},
        "creditorName": "Kaffi Vinyl",
        "debtorName": None,
        "remittanceInformationUnstructured": "Kaffi og kaka",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Kaffihús",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260319-003",
        "bookingDate": "2026-03-19",
        "valueDate": "2026-03-19",
        "transactionAmount": {"amount": "-510.00", "currency": "ISK"},
        "creditorName": "Parka",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bílastæðagjald",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Bílastæði",
        "status": "booked",
    },
    # ── 2026-03-18 (Wednesday) ─────────────────────────────────────────
    {
        "transactionId": "TXN-20260318-001",
        "bookingDate": "2026-03-18",
        "valueDate": "2026-03-18",
        "transactionAmount": {"amount": "-4500.00", "currency": "ISK"},
        "creditorName": "Bónus Grafarvogur",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matvara",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Matarinnkaup",
        "status": "booked",
    },
    # ── 2026-03-17 (Tuesday) ───────────────────────────────────────────
    {
        "transactionId": "TXN-20260317-001",
        "bookingDate": "2026-03-17",
        "valueDate": "2026-03-17",
        "transactionAmount": {"amount": "-12800.00", "currency": "ISK"},
        "creditorName": "Elko Smáralind",
        "debtorName": None,
        "remittanceInformationUnstructured": "Tölvuhlutir",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Tölvur og tækni",
        "status": "booked",
    },
    # ── 2026-03-16 (Monday) ────────────────────────────────────────────
    {
        "transactionId": "TXN-20260316-001",
        "bookingDate": "2026-03-16",
        "valueDate": "2026-03-15",
        "transactionAmount": {"amount": "550000.00", "currency": "ISK"},
        "creditorName": None,
        "debtorName": "Launagreiðsla AS",
        "remittanceInformationUnstructured": "Laun mars 2026",
        "bankTransactionCode": "PMNT-ICDT-ESCT",
        "category": "Tekjur",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260316-002",
        "bookingDate": "2026-03-16",
        "valueDate": "2026-03-16",
        "transactionAmount": {"amount": "-3100.00", "currency": "ISK"},
        "creditorName": "N1 Selfossvegur",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bensín",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Eldsneyti",
        "status": "booked",
    },
    # ── 2026-03-15 (Sunday — continued from the night out) ─────────────
    {
        "transactionId": "TXN-20260315-001",
        "bookingDate": "2026-03-15",
        "valueDate": "2026-03-15",
        "transactionAmount": {"amount": "-89000.00", "currency": "ISK"},
        "creditorName": "Íslandsbanki hf. — Lán",
        "debtorName": None,
        "remittanceInformationUnstructured": "Afborgun húsnæðislán #4521",
        "bankTransactionCode": "LIQD-LOAN-RPMT",
        "category": "Lánafrádráttur",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260315-002",
        "bookingDate": "2026-03-15",
        "valueDate": "2026-03-15",
        "transactionAmount": {"amount": "-24800.00", "currency": "ISK"},
        "creditorName": "Röntgen",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bar og skemmtistaður",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Skemmtistaðir",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260315-003",
        "bookingDate": "2026-03-15",
        "valueDate": "2026-03-15",
        "transactionAmount": {"amount": "-8400.00", "currency": "ISK"},
        "creditorName": "Röntgen",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matur og drykki",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Veitingastaðir",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260315-004",
        "bookingDate": "2026-03-15",
        "valueDate": "2026-03-15",
        "transactionAmount": {"amount": "-5200.00", "currency": "ISK"},
        "creditorName": "Hreyfill taxi",
        "debtorName": None,
        "remittanceInformationUnstructured": "Leigubíll",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Ferðalag",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260315-005",
        "bookingDate": "2026-03-15",
        "valueDate": "2026-03-15",
        "transactionAmount": {"amount": "-3900.00", "currency": "ISK"},
        "creditorName": "Heilsuvera apótek",
        "debtorName": None,
        "remittanceInformationUnstructured": "Lyf",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Lyfjakaup",
        "status": "booked",
    },
    # ── 2026-03-14 (Saturday — big night out at Club Auto & Röntgen) ───
    {
        "transactionId": "TXN-20260314-001",
        "bookingDate": "2026-03-14",
        "valueDate": "2026-03-14",
        "transactionAmount": {"amount": "-3200.00", "currency": "ISK"},
        "creditorName": "Olís Þorragata",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bensín",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Eldsneyti",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260314-002",
        "bookingDate": "2026-03-14",
        "valueDate": "2026-03-14",
        "transactionAmount": {"amount": "-31500.00", "currency": "ISK"},
        "creditorName": "Club Auto",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bar og inngangur",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Skemmtistaðir",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260314-003",
        "bookingDate": "2026-03-14",
        "valueDate": "2026-03-14",
        "transactionAmount": {"amount": "-18200.00", "currency": "ISK"},
        "creditorName": "Club Auto",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bar",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Skemmtistaðir",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260314-004",
        "bookingDate": "2026-03-14",
        "valueDate": "2026-03-14",
        "transactionAmount": {"amount": "-9800.00", "currency": "ISK"},
        "creditorName": "Röntgen",
        "debtorName": None,
        "remittanceInformationUnstructured": "Kvöldmatur og drykki",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Veitingastaðir",
        "status": "booked",
    },
    # ── 2026-03-13 (Friday) ────────────────────────────────────────────
    {
        "transactionId": "TXN-20260313-001",
        "bookingDate": "2026-03-13",
        "valueDate": "2026-03-13",
        "transactionAmount": {"amount": "-1490.00", "currency": "ISK"},
        "creditorName": "Netflix International",
        "debtorName": None,
        "remittanceInformationUnstructured": "Netflix áskrift",
        "bankTransactionCode": "PMNT-MCRD-RECR",
        "category": "Þjónusta og áskriftir",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260313-002",
        "bookingDate": "2026-03-13",
        "valueDate": "2026-03-13",
        "transactionAmount": {"amount": "-4200.00", "currency": "ISK"},
        "creditorName": "Sambíóin Kringlunni",
        "debtorName": None,
        "remittanceInformationUnstructured": "Kvikmynd",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Bíó, leikhús, tónleikar",
        "status": "booked",
    },
    # ── 2026-03-12 (Thursday) ──────────────────────────────────────────
    {
        "transactionId": "TXN-20260312-001",
        "bookingDate": "2026-03-12",
        "valueDate": "2026-03-12",
        "transactionAmount": {"amount": "-7600.00", "currency": "ISK"},
        "creditorName": "Heilsuvera apótek",
        "debtorName": None,
        "remittanceInformationUnstructured": "Lyf",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Lyfjakaup",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260312-002",
        "bookingDate": "2026-03-12",
        "valueDate": "2026-03-12",
        "transactionAmount": {"amount": "-2800.00", "currency": "ISK"},
        "creditorName": "Kaffitár Bankastræti",
        "debtorName": None,
        "remittanceInformationUnstructured": "Kaffi",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Kaffihús",
        "status": "booked",
    },
    # ── 2026-03-11 (Wednesday) ─────────────────────────────────────────
    {
        "transactionId": "TXN-20260311-001",
        "bookingDate": "2026-03-11",
        "valueDate": "2026-03-11",
        "transactionAmount": {"amount": "-19876.00", "currency": "ISK"},
        "creditorName": "Bónus Háaleiti",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matvara",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Matarinnkaup",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260311-002",
        "bookingDate": "2026-03-11",
        "valueDate": "2026-03-11",
        "transactionAmount": {"amount": "-695.00", "currency": "ISK"},
        "creditorName": "Easy Park",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bílastæðagjald",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Bílastæði",
        "status": "booked",
    },
    # ── 2026-03-10 (Tuesday) ───────────────────────────────────────────
    {
        "transactionId": "TXN-20260310-001",
        "bookingDate": "2026-03-10",
        "valueDate": "2026-03-10",
        "transactionAmount": {"amount": "-9876.00", "currency": "ISK"},
        "creditorName": "Nettó Mjódd",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matvara",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Matarinnkaup",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260310-002",
        "bookingDate": "2026-03-10",
        "valueDate": "2026-03-10",
        "transactionAmount": {"amount": "-4560.00", "currency": "ISK"},
        "creditorName": "Lyf og heilsa",
        "debtorName": None,
        "remittanceInformationUnstructured": "Snyrtivörur",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Snyrtivörur",
        "status": "booked",
    },
    # ── 2026-03-09 (Monday) ────────────────────────────────────────────
    {
        "transactionId": "TXN-20260309-001",
        "bookingDate": "2026-03-09",
        "valueDate": "2026-03-09",
        "transactionAmount": {"amount": "-8950.00", "currency": "ISK"},
        "creditorName": "Olís Þorragata",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bensín",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Eldsneyti",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260309-002",
        "bookingDate": "2026-03-09",
        "valueDate": "2026-03-09",
        "transactionAmount": {"amount": "-2050.00", "currency": "ISK"},
        "creditorName": "Mokka Kaffi",
        "debtorName": None,
        "remittanceInformationUnstructured": "Kaffi",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Kaffihús",
        "status": "booked",
    },
    # ── 2026-03-07 (Saturday) ──────────────────────────────────────────
    {
        "transactionId": "TXN-20260307-001",
        "bookingDate": "2026-03-07",
        "valueDate": "2026-03-07",
        "transactionAmount": {"amount": "-13987.00", "currency": "ISK"},
        "creditorName": "Hagkaup Kringlan",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matvara",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Matarinnkaup",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260307-002",
        "bookingDate": "2026-03-07",
        "valueDate": "2026-03-07",
        "transactionAmount": {"amount": "9331.00", "currency": "ISK"},
        "creditorName": None,
        "debtorName": "Orkureikningar: Orka náttúrunnar",
        "remittanceInformationUnstructured": "Endurgreiðsla rafmagns",
        "bankTransactionCode": "PMNT-ICDT-ESCT",
        "category": "Rafmagn og hiti",
        "status": "booked",
    },
    # ── 2026-03-05 (Thursday) ──────────────────────────────────────────
    {
        "transactionId": "TXN-20260305-001",
        "bookingDate": "2026-03-05",
        "valueDate": "2026-03-05",
        "transactionAmount": {"amount": "-15420.00", "currency": "ISK"},
        "creditorName": "Orkuveita Reykjavíkur",
        "debtorName": None,
        "remittanceInformationUnstructured": "Rafmagn og hiti",
        "bankTransactionCode": "PMNT-MCRD-DBIT",
        "category": "Rafmagn og hiti",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260305-002",
        "bookingDate": "2026-03-05",
        "valueDate": "2026-03-05",
        "transactionAmount": {"amount": "-510.00", "currency": "ISK"},
        "creditorName": "Parka",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bílastæðagjald",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Bílastæði",
        "status": "booked",
    },
    # ── 2026-03-03 (Tuesday) ───────────────────────────────────────────
    {
        "transactionId": "TXN-20260303-001",
        "bookingDate": "2026-03-03",
        "valueDate": "2026-03-03",
        "transactionAmount": {"amount": "-9100.00", "currency": "ISK"},
        "creditorName": "N1 Vesturlandsvegur",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bensín",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Eldsneyti",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260303-002",
        "bookingDate": "2026-03-03",
        "valueDate": "2026-03-03",
        "transactionAmount": {"amount": "-18654.00", "currency": "ISK"},
        "creditorName": "Krónan Kringlan",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matvara",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Matarinnkaup",
        "status": "booked",
    },
    # ── 2026-03-01 (Sunday) ────────────────────────────────────────────
    {
        "transactionId": "TXN-20260301-001",
        "bookingDate": "2026-03-01",
        "valueDate": "2026-03-01",
        "transactionAmount": {"amount": "-19123.00", "currency": "ISK"},
        "creditorName": "Bónus Kópavogur",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matvara",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Matarinnkaup",
        "status": "booked",
    },
    # ── 2026-02-28 (Saturday) ──────────────────────────────────────────
    {
        "transactionId": "TXN-20260228-001",
        "bookingDate": "2026-02-28",
        "valueDate": "2026-02-28",
        "transactionAmount": {"amount": "-42500.00", "currency": "ISK"},
        "creditorName": "Brimborg",
        "debtorName": None,
        "remittanceInformationUnstructured": "Viðhald bifreiðar",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Viðhald og rekstur bifreiða",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260228-002",
        "bookingDate": "2026-02-28",
        "valueDate": "2026-02-28",
        "transactionAmount": {"amount": "-6200.00", "currency": "ISK"},
        "creditorName": "H&M Ísland",
        "debtorName": None,
        "remittanceInformationUnstructured": "Fatnaður",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Fatnaður",
        "status": "booked",
    },
    # ── 2026-02-27 (Friday) ────────────────────────────────────────────
    {
        "transactionId": "TXN-20260227-001",
        "bookingDate": "2026-02-27",
        "valueDate": "2026-02-27",
        "transactionAmount": {"amount": "-18900.00", "currency": "ISK"},
        "creditorName": "Verd Tryggingar",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bílatrygging",
        "bankTransactionCode": "PMNT-MCRD-DBIT",
        "category": "Bílatryggingar",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260227-002",
        "bookingDate": "2026-02-27",
        "valueDate": "2026-02-27",
        "transactionAmount": {"amount": "-20567.00", "currency": "ISK"},
        "creditorName": "Krónan Laugavegi",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matvara",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Matarinnkaup",
        "status": "booked",
    },
    # ── 2026-02-25 (Wednesday) ─────────────────────────────────────────
    {
        "transactionId": "TXN-20260225-001",
        "bookingDate": "2026-02-25",
        "valueDate": "2026-02-25",
        "transactionAmount": {"amount": "-8950.00", "currency": "ISK"},
        "creditorName": "Sambíóin Álfabakka",
        "debtorName": None,
        "remittanceInformationUnstructured": "Kvikmynd",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Bíó, leikhús, tónleikar",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260225-002",
        "bookingDate": "2026-02-25",
        "valueDate": "2026-02-25",
        "transactionAmount": {"amount": "-12345.00", "currency": "ISK"},
        "creditorName": "Hagabúðin",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matvara",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Matarinnkaup",
        "status": "booked",
    },
    # ── 2026-02-22 (Sunday) ────────────────────────────────────────────
    {
        "transactionId": "TXN-20260222-001",
        "bookingDate": "2026-02-22",
        "valueDate": "2026-02-22",
        "transactionAmount": {"amount": "-9100.00", "currency": "ISK"},
        "creditorName": "N1 Hafnarfjörður",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bensín",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Eldsneyti",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260222-002",
        "bookingDate": "2026-02-22",
        "valueDate": "2026-02-22",
        "transactionAmount": {"amount": "-2390.00", "currency": "ISK"},
        "creditorName": "Happdrætti SÍBS",
        "debtorName": None,
        "remittanceInformationUnstructured": "Lóterí",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Happdrætti",
        "status": "booked",
    },
    # ── 2026-02-20 (Friday) ────────────────────────────────────────────
    {
        "transactionId": "TXN-20260220-001",
        "bookingDate": "2026-02-20",
        "valueDate": "2026-02-20",
        "transactionAmount": {"amount": "-22000.00", "currency": "ISK"},
        "creditorName": "Bónus Grafarvogur",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matvara",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Matarinnkaup",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260220-002",
        "bookingDate": "2026-02-20",
        "valueDate": "2026-02-20",
        "transactionAmount": {"amount": "-14800.00", "currency": "ISK"},
        "creditorName": "Elko netverslun",
        "debtorName": None,
        "remittanceInformationUnstructured": "Heimilistæki",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Heimilistæki",
        "status": "booked",
    },
    # ── 2026-02-18 (Wednesday — salary) ───────────────────────────────
    {
        "transactionId": "TXN-20260218-001",
        "bookingDate": "2026-02-18",
        "valueDate": "2026-02-17",
        "transactionAmount": {"amount": "550000.00", "currency": "ISK"},
        "creditorName": None,
        "debtorName": "Launagreiðsla AS",
        "remittanceInformationUnstructured": "Laun febrúar 2026",
        "bankTransactionCode": "PMNT-ICDT-ESCT",
        "category": "Tekjur",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260218-002",
        "bookingDate": "2026-02-18",
        "valueDate": "2026-02-18",
        "transactionAmount": {"amount": "-89000.00", "currency": "ISK"},
        "creditorName": "Íslandsbanki hf. — Lán",
        "debtorName": None,
        "remittanceInformationUnstructured": "Afborgun húsnæðislán #4521",
        "bankTransactionCode": "LIQD-LOAN-RPMT",
        "category": "Lánafrádráttur",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260218-003",
        "bookingDate": "2026-02-18",
        "valueDate": "2026-02-18",
        "transactionAmount": {"amount": "-5400.00", "currency": "ISK"},
        "creditorName": "WorldGym Reykjavík",
        "debtorName": None,
        "remittanceInformationUnstructured": "Líkamsræktarmiðill",
        "bankTransactionCode": "PMNT-MCRD-RECR",
        "category": "Líkamsrækt",
        "status": "booked",
    },
    # ── 2026-02-14 (Saturday — Valentine's dinner) ────────────────────
    {
        "transactionId": "TXN-20260214-001",
        "bookingDate": "2026-02-14",
        "valueDate": "2026-02-14",
        "transactionAmount": {"amount": "-31200.00", "currency": "ISK"},
        "creditorName": "Rok veitingastaðir",
        "debtorName": None,
        "remittanceInformationUnstructured": "Kvöldmatur",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Veitingastaðir",
        "status": "booked",
    },
    # ── 2026-02-10 (Tuesday) ───────────────────────────────────────────
    {
        "transactionId": "TXN-20260210-001",
        "bookingDate": "2026-02-10",
        "valueDate": "2026-02-10",
        "transactionAmount": {"amount": "-3100.00", "currency": "ISK"},
        "creditorName": "N1 Álftanes",
        "debtorName": None,
        "remittanceInformationUnstructured": "Bensín",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Eldsneyti",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260210-002",
        "bookingDate": "2026-02-10",
        "valueDate": "2026-02-10",
        "transactionAmount": {"amount": "-18450.00", "currency": "ISK"},
        "creditorName": "Bónus Kópavogur",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matvara",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Matarinnkaup",
        "status": "booked",
    },
    # ── 2026-02-07 (Saturday) ──────────────────────────────────────────
    {
        "transactionId": "TXN-20260207-001",
        "bookingDate": "2026-02-07",
        "valueDate": "2026-02-07",
        "transactionAmount": {"amount": "-7800.00", "currency": "ISK"},
        "creditorName": "Sambíóin Kringlunni",
        "debtorName": None,
        "remittanceInformationUnstructured": "Kvikmynd og snakk",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Bíó, leikhús, tónleikar",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260207-002",
        "bookingDate": "2026-02-07",
        "valueDate": "2026-02-07",
        "transactionAmount": {"amount": "-4200.00", "currency": "ISK"},
        "creditorName": "Skopp",
        "debtorName": None,
        "remittanceInformationUnstructured": "Kvöldmatur",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Veitingastaðir",
        "status": "booked",
    },
    # ── 2026-02-03 (Tuesday) ───────────────────────────────────────────
    {
        "transactionId": "TXN-20260203-001",
        "bookingDate": "2026-02-03",
        "valueDate": "2026-02-03",
        "transactionAmount": {"amount": "-15600.00", "currency": "ISK"},
        "creditorName": "Orkuveita Reykjavíkur",
        "debtorName": None,
        "remittanceInformationUnstructured": "Rafmagn og hiti — febrúar",
        "bankTransactionCode": "PMNT-MCRD-DBIT",
        "category": "Rafmagn og hiti",
        "status": "booked",
    },
    {
        "transactionId": "TXN-20260203-002",
        "bookingDate": "2026-02-03",
        "valueDate": "2026-02-03",
        "transactionAmount": {"amount": "-12780.00", "currency": "ISK"},
        "creditorName": "Krónan Mjódd",
        "debtorName": None,
        "remittanceInformationUnstructured": "Matvara",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Matarinnkaup",
        "status": "booked",
    },
    # ── Pending ────────────────────────────────────────────────────────
    {
        "transactionId": "TXN-PENDING-001",
        "bookingDate": None,
        "valueDate": "2026-03-20",
        "transactionAmount": {"amount": "-6200.00", "currency": "ISK"},
        "creditorName": "H&M Ísland",
        "debtorName": None,
        "remittanceInformationUnstructured": "Fatnaður",
        "bankTransactionCode": "PMNT-MCRD-POSD",
        "category": "Fatnaður",
        "status": "pending",
    },
]

# Categories excluded from spending totals (income, structural payments)
_EXCLUDE_FROM_SPEND = {"Tekjur", "Lánafrádráttur"}


def list_transactions(
    account_id: str,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    limit: int = 50,
    booking_status: str = "both",
) -> dict:
    txns = _MOCK_TRANSACTIONS.copy()

    if booking_status == "booked":
        txns = [t for t in txns if t["status"] == "booked"]
    elif booking_status == "pending":
        txns = [t for t in txns if t["status"] == "pending"]

    if date_from:
        d_from = date.fromisoformat(date_from)
        txns = [
            t
            for t in txns
            if t.get("bookingDate") and date.fromisoformat(t["bookingDate"]) >= d_from
        ]
    if date_to:
        d_to = date.fromisoformat(date_to)
        txns = [
            t for t in txns if t.get("bookingDate") and date.fromisoformat(t["bookingDate"]) <= d_to
        ]

    txns = txns[:limit]

    return {
        "account": {
            "iban": f"IS{account_id[:22]}" if not account_id.startswith("IS") else account_id
        },
        "transactions": {
            "booked": [t for t in txns if t["status"] == "booked"],
            "pending": [t for t in txns if t["status"] == "pending"],
        },
    }


def get_transaction(transaction_id: str) -> Optional[dict]:
    for t in _MOCK_TRANSACTIONS:
        if t["transactionId"] == transaction_id:
            return t
    return None


def get_spend_summary(date_from: date, date_to: date) -> dict:
    """
    Aggregate spending across all accounts for a date range.

    Returns total_isk, count, by_category (sorted by spend desc), and flat
    transaction list. Excludes income and loan-repayment entries.
    """
    booked = [
        t
        for t in _MOCK_TRANSACTIONS
        if t["status"] == "booked"
        and t.get("bookingDate")
        and date_from <= date.fromisoformat(t["bookingDate"]) <= date_to
    ]
    spending = [
        t
        for t in booked
        if float(t["transactionAmount"]["amount"]) < 0
        and t.get("category") not in _EXCLUDE_FROM_SPEND
    ]

    by_cat: dict = defaultdict(lambda: {"total_isk": 0, "count": 0, "transactions": []})
    for t in spending:
        amt = abs(int(float(t["transactionAmount"]["amount"])))
        cat = t.get("category", "Annað")
        by_cat[cat]["total_isk"] += amt
        by_cat[cat]["count"] += 1
        by_cat[cat]["transactions"].append(
            {
                "date": t["bookingDate"],
                "merchant": t.get("creditorName") or t.get("debtorName") or "—",
                "amount_isk": amt,
                "note": t.get("remittanceInformationUnstructured", ""),
            }
        )

    categories_list = sorted(
        [{"category": cat, **data} for cat, data in by_cat.items()],
        key=lambda x: x["total_isk"],
        reverse=True,
    )

    return {
        "period_from": str(date_from),
        "period_to": str(date_to),
        "total_isk": sum(c["total_isk"] for c in categories_list),
        "count": len(spending),
        "by_category": categories_list,
        "transactions": sorted(spending, key=lambda t: t["bookingDate"], reverse=True),
    }
