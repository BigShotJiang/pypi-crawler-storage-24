"""
Mock: Account Information Service (AIS).

Returns realistic Icelandic account data using the Icelandic bank account
number format (BBBB-HH-NNNNNN). Used by all account commands.

Format: BankBranch-Höfuðbók-AccountNumber (e.g. 0515-26-000262)
  - BBBB = Bank/branch number (Íslandsbanki = 0515, Landsbankinn = 0101, etc.)
  - HH   = Höfuðbók (ledger type: 14=checking, 26=savings, 38=foreign currency)
  - NNNNNN = Account number

Six accounts for the demo user (mix of ISK, EUR, USD).
Transactions span ~3 months back from today plus a few pending days ahead.
"""

from __future__ import annotations

import random
from datetime import date, timedelta
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Mock accounts — Icelandic bank account numbers (BBBB-HH-NNNNNN)
# ---------------------------------------------------------------------------

_OWNER = "David Erik Mollberg"

_ACCOUNTS: list[dict[str, Any]] = [
    {
        "resourceId": "acct-eur-0001",
        "accountNumber": "0515-38-000008",
        "currency": "EUR",
        "name": _OWNER,
        "cashAccountType": "CACC",
        "status": "enabled",
        "product": "Gjaldeyrisreikningur",
        "bank": "Íslandsbanki",
    },
    {
        "resourceId": "acct-isk-0002",
        "accountNumber": "0515-14-000028",
        "currency": "ISK",
        "name": _OWNER,
        "cashAccountType": "CACC",
        "status": "enabled",
        "product": "Tékkareikningur",
        "bank": "Íslandsbanki",
    },
    {
        "resourceId": "acct-usd-0003",
        "accountNumber": "0515-29-000006",
        "currency": "USD",
        "name": _OWNER,
        "cashAccountType": "CACC",
        "status": "enabled",
        "product": "Gjaldeyrisreikningur",
        "bank": "Íslandsbanki",
    },
    {
        "resourceId": "acct-isk-0004",
        "accountNumber": "0515-26-000262",
        "currency": "ISK",
        "name": _OWNER,
        "cashAccountType": "SVGS",
        "status": "enabled",
        "product": "Sparireikningur",
        "bank": "Íslandsbanki",
    },
    {
        "resourceId": "acct-isk-0005",
        "accountNumber": "0515-14-000030",
        "currency": "ISK",
        "name": _OWNER,
        "cashAccountType": "CACC",
        "status": "enabled",
        "product": "Launareikningur",
        "bank": "Íslandsbanki",
    },
    {
        "resourceId": "acct-isk-0006",
        "accountNumber": "0515-18-000210",
        "currency": "ISK",
        "name": _OWNER,
        "cashAccountType": "SVGS",
        "status": "enabled",
        "product": "Bundinn sparireikningur",
        "bank": "Íslandsbanki",
    },
]

_ACCTNUM_TO_ACCOUNT = {a["accountNumber"]: a for a in _ACCOUNTS}
_ID_TO_ACCOUNT = {a["resourceId"]: a for a in _ACCOUNTS}

# ---------------------------------------------------------------------------
# Balances
# ---------------------------------------------------------------------------

_BALANCES: dict[str, list[dict]] = {
    "acct-eur-0001": [
        {
            "balanceType": "closingBooked",
            "balanceAmount": {"amount": "2340.55", "currency": "EUR"},
            "referenceDate": str(date.today()),
        },
        {
            "balanceType": "interimAvailable",
            "balanceAmount": {"amount": "2340.55", "currency": "EUR"},
            "referenceDate": str(date.today()),
        },
    ],
    "acct-isk-0002": [
        {
            "balanceType": "closingBooked",
            "balanceAmount": {"amount": "487230.00", "currency": "ISK"},
            "referenceDate": str(date.today()),
        },
        {
            "balanceType": "interimAvailable",
            "balanceAmount": {"amount": "481030.00", "currency": "ISK"},
            "referenceDate": str(date.today()),
        },
    ],
    "acct-usd-0003": [
        {
            "balanceType": "closingBooked",
            "balanceAmount": {"amount": "1105.30", "currency": "USD"},
            "referenceDate": str(date.today()),
        },
        {
            "balanceType": "interimAvailable",
            "balanceAmount": {"amount": "1105.30", "currency": "USD"},
            "referenceDate": str(date.today()),
        },
    ],
    "acct-isk-0004": [
        {
            "balanceType": "closingBooked",
            "balanceAmount": {"amount": "3215600.00", "currency": "ISK"},
            "referenceDate": str(date.today()),
        },
        {
            "balanceType": "interimAvailable",
            "balanceAmount": {"amount": "3215600.00", "currency": "ISK"},
            "referenceDate": str(date.today()),
        },
    ],
    "acct-isk-0005": [
        {
            "balanceType": "closingBooked",
            "balanceAmount": {"amount": "612450.00", "currency": "ISK"},
            "referenceDate": str(date.today()),
        },
        {
            "balanceType": "interimAvailable",
            "balanceAmount": {"amount": "606250.00", "currency": "ISK"},
            "referenceDate": str(date.today()),
        },
    ],
    "acct-isk-0006": [
        {
            "balanceType": "closingBooked",
            "balanceAmount": {"amount": "8500000.00", "currency": "ISK"},
            "referenceDate": str(date.today()),
        },
        {
            "balanceType": "interimAvailable",
            "balanceAmount": {"amount": "8500000.00", "currency": "ISK"},
            "referenceDate": str(date.today()),
        },
    ],
}

# ---------------------------------------------------------------------------
# Transaction generation (3 months history + a few pending)
# ---------------------------------------------------------------------------

_ISK_MERCHANTS = [
    ("Bónus Grafarvogur", "Matvara", "-4500.00", "PMNT-MCRD-POSD"),
    ("Krónan Kringlan", "Matvara", "-6320.00", "PMNT-MCRD-POSD"),
    ("Hagkaup Garðabær", "Matvara", "-8150.00", "PMNT-MCRD-POSD"),
    ("N1 Bíldshöfði", "Bensín", "-3200.00", "PMNT-MCRD-POSD"),
    ("Olís Þorragata", "Bensín", "-4800.00", "PMNT-MCRD-POSD"),
    ("Elko Smáralind", "Tölvuhlutir", "-12800.00", "PMNT-MCRD-POSD"),
    ("Netflix International", "Netflix áskrift", "-1490.00", "PMNT-MCRD-RECR"),
    ("Spotify AB", "Spotify áskrift", "-1290.00", "PMNT-MCRD-RECR"),
    ("Síminn hf.", "Farsímareikningur", "-4990.00", "PMNT-MCRD-RECR"),
    ("Orkuveita Reykjavíkur", "Rafmagn/hiti", "-18500.00", "PMNT-ICDT-ESCT"),
    ("Sjóvá-Almennar", "Bifreiðatrygging", "-11200.00", "PMNT-ICDT-ESCT"),
    ("Strætó bs.", "Klappkort", "-6500.00", "PMNT-MCRD-POSD"),
    ("Vínbúðin Kringlan", "Áfengi", "-3890.00", "PMNT-MCRD-POSD"),
    ("Heilsuvera apótek", "Lyf", "-7600.00", "PMNT-MCRD-POSD"),
    ("IKEA Kauptún", "Heimilistæki", "-24500.00", "PMNT-MCRD-POSD"),
    ("10-11 Laugavegi", "Smávara", "-1850.00", "PMNT-MCRD-POSD"),
    ("H&M Ísland", "Fatnaður", "-6200.00", "PMNT-MCRD-POSD"),
    ("Dominos Ísland", "Pizza", "-2990.00", "PMNT-MCRD-POSD"),
    ("Íslandsbanki hf. — Lán", "Afborgun húsnæðislán #4521", "-89000.00", "LIQD-LOAN-RPMT"),
]

_ISK_INCOMES = [
    ("Launagreiðsla AS", "Laun", "550000.00", "PMNT-ICDT-ESCT"),
    ("Ríkisskattstjóri", "Endurgreiðsla virðisaukaskatts", "42000.00", "PMNT-ICDT-ESCT"),
    ("Tryggingastofnun", "Barnabætur", "35000.00", "PMNT-ICDT-ESCT"),
]


def _generate_transactions(account: dict) -> list[dict]:
    """Generate ~90 days of realistic transactions for a given account."""
    ccy = account["currency"]
    today = date.today()
    start = today - timedelta(days=90)
    rng = random.Random(hash(account["accountNumber"]))  # deterministic per account

    booked: list[dict] = []
    pending: list[dict] = []

    if ccy != "ISK":
        # For EUR/USD accounts: fewer transactions
        base_amt = 150.0 if ccy == "EUR" else 120.0
        day = start
        txn_idx = 0
        while day <= today + timedelta(days=3):
            if rng.random() < 0.25:
                day += timedelta(days=1)
                continue
            txn_idx += 1
            is_credit = rng.random() < 0.3
            amt = round(rng.uniform(20, base_amt * 3), 2)
            txn = {
                "transactionId": f"TXN-{day.isoformat().replace('-', '')}-{txn_idx:03d}",
                "bookingDate": str(day) if day <= today else None,
                "valueDate": str(day),
                "transactionAmount": {
                    "amount": f"{amt:.2f}" if is_credit else f"-{amt:.2f}",
                    "currency": ccy,
                },
                "creditorName": None if is_credit else "International Transfer",
                "debtorName": "Wire Transfer In" if is_credit else None,
                "remittanceInformationUnstructured": "FX transfer",
                "bankTransactionCode": "PMNT-ICDT-XBCT",
                "status": "pending" if day > today else "booked",
            }
            if day > today:
                pending.append(txn)
            else:
                booked.append(txn)
            day += timedelta(days=rng.randint(2, 7))
        return booked + pending

    # ISK account: richer transaction mix
    day = start
    txn_idx = 0
    while day <= today + timedelta(days=5):
        # 1-3 transactions per day
        n_txns = rng.randint(0, 3)
        for _ in range(n_txns):
            txn_idx += 1

            # Salary on ~15th of each month
            if day.day == 15 and rng.random() < 0.8:
                src = rng.choice(_ISK_INCOMES)
                txn = _make_txn(txn_idx, day, today, src, ccy)
                if day > today:
                    pending.append(txn)
                else:
                    booked.append(txn)
                continue

            # Income ~10% of the time
            if rng.random() < 0.10:
                src = rng.choice(_ISK_INCOMES)
            else:
                src = rng.choice(_ISK_MERCHANTS)

            txn = _make_txn(txn_idx, day, today, src, ccy)
            if day > today:
                pending.append(txn)
            else:
                booked.append(txn)

        day += timedelta(days=1)

    return booked + pending


def _make_txn(idx: int, day: date, today: date, src: tuple, ccy: str) -> dict:
    name, desc, amt, code = src
    is_pending = day > today
    return {
        "transactionId": f"TXN-{day.isoformat().replace('-', '')}-{idx:03d}",
        "bookingDate": None if is_pending else str(day),
        "valueDate": str(day),
        "transactionAmount": {"amount": amt, "currency": ccy},
        "creditorName": name if float(amt) < 0 else None,
        "debtorName": name if float(amt) > 0 else None,
        "remittanceInformationUnstructured": desc,
        "bankTransactionCode": code,
        "status": "pending" if is_pending else "booked",
    }


# Cache generated transactions per account to stay deterministic in-session
_TX_CACHE: dict[str, list[dict]] = {}


def _get_txns(account_id: str) -> list[dict]:
    if account_id not in _TX_CACHE:
        acct = _resolve_account(account_id)
        if not acct:
            return []
        _TX_CACHE[account_id] = _generate_transactions(acct)
    return _TX_CACHE[account_id]


# ---------------------------------------------------------------------------
# Public API — matches api/accounts.py signatures (minus BankClient)
# ---------------------------------------------------------------------------


def _resolve_account(account_id: str) -> Optional[dict]:
    """Look up by resourceId or account number (BBBB-HH-NNNNNN)."""
    return _ID_TO_ACCOUNT.get(account_id) or _ACCTNUM_TO_ACCOUNT.get(account_id)


def list_accounts() -> list[dict]:
    """Return all mock accounts (same shape as real AIS list)."""
    return list(_ACCOUNTS)


def get_account(account_id: str) -> dict:
    """Return a single account by resourceId or account number."""
    acct = _resolve_account(account_id)
    if acct:
        return acct
    return {"error": "Account not found", "_mock": True}


def get_balances(account_id: str) -> list[dict]:
    """Return balance(s) for the given account."""
    acct = _resolve_account(account_id)
    if not acct:
        return []
    rid = acct["resourceId"]
    return _BALANCES.get(rid, [])


def get_transactions(account_id: str, **params: Any) -> dict:
    """
    Return transaction history for an account.

    Supports dateFrom, dateTo, bookingStatus params (same as real API).
    """
    txns = _get_txns(account_id)

    booking_status = params.get("bookingStatus", "both")
    date_from = params.get("dateFrom")
    date_to = params.get("dateTo")

    if booking_status == "booked":
        txns = [t for t in txns if t["status"] == "booked"]
    elif booking_status == "pending":
        txns = [t for t in txns if t["status"] == "pending"]

    if date_from:
        d = date.fromisoformat(date_from)
        txns = [
            t for t in txns if t.get("bookingDate") and date.fromisoformat(t["bookingDate"]) >= d
        ]
    if date_to:
        d = date.fromisoformat(date_to)
        txns = [
            t for t in txns if t.get("bookingDate") and date.fromisoformat(t["bookingDate"]) <= d
        ]

    return {
        "transactions": {
            "booked": [t for t in txns if t["status"] == "booked"],
            "pending": [t for t in txns if t["status"] == "pending"],
        },
        "_mock": True,
    }
