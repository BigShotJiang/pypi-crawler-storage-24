"""
Mock: Payment Initiation Service (PIS).

Returns realistic payment responses matching PSD2 PIS endpoint shapes.
Active for all payment commands — approval is handled via the app.

Simulates the full payment state machine:
  RCVD → ACTC → ACFC → ACCC  (success path)
  RCVD → RJCT                 (rejection)
  RCVD → CANC                 (cancellation)
"""

from __future__ import annotations

import uuid
from typing import Optional

# In-memory store of mock payments for the session
_PAYMENTS: dict[str, dict] = {}


def _new_payment_id() -> str:
    return f"PAY-MOCK-{uuid.uuid4().hex[:8].upper()}"


def initiate_credit_transfer(
    *,
    debtor_account: str,
    creditor_account: str,
    amount: str,
    currency: str = "ISK",
    reference: Optional[str] = None,
) -> dict:
    """Initiate a mock credit-transfer. Returns paymentId + status RCVD."""
    pid = _new_payment_id()
    payment = {
        "paymentId": pid,
        "transactionStatus": "RCVD",
        "instructedAmount": {"currency": currency, "amount": str(amount)},
        "debtorAccount": {"accountNumber": debtor_account},
        "creditorAccount": {"accountNumber": creditor_account},
        "remittanceInformationUnstructured": reference,
        "scaMethods": [{"authenticationMethodId": "audkenniApp", "name": "Audkenni App (mock)"}],
        "_links": {
            "scaStatus": {
                "href": f"/payments/v2/payments/credit-transfers/{pid}/authorisations/mock-auth-001/status"
            },
            "self": {"href": f"/payments/v2/payments/credit-transfers/{pid}"},
            "status": {"href": f"/payments/v2/payments/credit-transfers/{pid}/status"},
        },
        "_mock": True,
    }
    _PAYMENTS[pid] = payment
    return payment


def get_payment(payment_id: str, product: str = "credit-transfers") -> dict:
    """Get full payment details."""
    if payment_id in _PAYMENTS:
        return _PAYMENTS[payment_id]
    return {"paymentId": payment_id, "transactionStatus": "UNKNOWN", "_mock": True}


def get_payment_status(payment_id: str, product: str = "credit-transfers") -> dict:
    """Get payment status (auto-advances mock state machine)."""
    p = _PAYMENTS.get(payment_id)
    if not p:
        return {"transactionStatus": "UNKNOWN", "_mock": True}

    # Auto-advance: RCVD → ACTC → ACFC → ACCC
    _STATE_ADVANCE = {"RCVD": "ACTC", "ACTC": "ACFC", "ACFC": "ACCC"}
    current = p["transactionStatus"]
    if current in _STATE_ADVANCE:
        p["transactionStatus"] = _STATE_ADVANCE[current]

    return {"transactionStatus": p["transactionStatus"], "_mock": True}


def start_sca(
    payment_id: str,
    sca_method: str = "audkenniApp",
    product: str = "credit-transfers",
) -> dict:
    """Start mock SCA — immediately returns a scaStatus link."""
    return {
        "scaStatus": "started",
        "_links": {
            "scaStatus": {
                "href": f"/payments/v2/payments/{product}/{payment_id}/authorisations/mock-auth-001/status"
            }
        },
        "_mock": True,
    }


def poll_sca_until_final(
    sca_status_href: str,
    timeout_seconds: int = 90,
    poll_interval: float = 1.5,
) -> str:
    """Mock SCA always succeeds instantly."""
    return "finalised"


def poll_payment_until_final(
    payment_id: str,
    product: str = "credit-transfers",
    timeout_seconds: int = 60,
    poll_interval: float = 1.0,
) -> str:
    """Mock payment always settles to ACCC."""
    p = _PAYMENTS.get(payment_id)
    if p:
        p["transactionStatus"] = "ACCC"
    return "ACCC"


def cancel_payment(payment_id: str, product: str = "credit-transfers") -> dict:
    """Cancel a mock payment."""
    p = _PAYMENTS.get(payment_id)
    if p:
        p["transactionStatus"] = "CANC"
    return {"transactionStatus": "CANC", "_mock": True}
