"""
Mock: Cards / debit cards.

Realistic Icelandic card data for POC demo. In production this would
call the IOBWS card management API.
"""
from __future__ import annotations

from typing import Optional

_MOCK_HOLDER = "JÓN BJÖRNSSON"

_MOCK_CARDS = [
    {
        "cardId": "CARD-001",
        "maskedPan": "4569 12** **** 3382",
        "cardType": "DEBIT",
        "scheme": "Visa",
        "holderName": _MOCK_HOLDER,
        "expiryDate": "2028-09",
        "status": "active",
        "linkedAccountIban": "IS850515260002620103871409",
        "creditLimit": None,
        "spendingLimit": {"daily": "200000", "currency": "ISK"},
        "contactless": True,
    },
    {
        "cardId": "CARD-002",
        "maskedPan": "5241 82** **** 7741",
        "cardType": "CREDIT",
        "scheme": "Mastercard",
        "holderName": _MOCK_HOLDER,
        "expiryDate": "2027-04",
        "status": "active",
        "linkedAccountIban": None,
        "creditLimit": {"amount": "500000", "currency": "ISK"},
        "spendingLimit": {"daily": "300000", "currency": "ISK"},
        "contactless": True,
    },
    {
        "cardId": "CARD-003",
        "maskedPan": "4569 12** **** 0192",
        "cardType": "DEBIT",
        "scheme": "Visa",
        "holderName": _MOCK_HOLDER,
        "expiryDate": "2025-01",
        "status": "expired",
        "linkedAccountIban": "IS520515140000280103871409",
        "creditLimit": None,
        "spendingLimit": None,
        "contactless": False,
    },
]

_PENDING_FREEZE: set[str] = set()


def list_cards(include_expired: bool = False) -> list[dict]:
    """
    Return all cards for the authenticated user.

    Args:
        include_expired: If False (default), expired cards are excluded.
    """
    cards = _MOCK_CARDS.copy()
    if not include_expired:
        cards = [c for c in cards if c["status"] != "expired"]
    return cards


def get_card(card_id: str) -> Optional[dict]:
    """Return a single card by cardId, or None if not found."""
    for c in _MOCK_CARDS:
        if c["cardId"] == card_id:
            return dict(c)
    return None


def freeze_card(card_id: str) -> dict:
    """
    Temporarily freeze a card (blocks all transactions).

    Returns:
        Updated card dict with status "frozen".
    Raises:
        ValueError if card not found or already frozen/inactive.
    """
    card = get_card(card_id)
    if not card:
        raise ValueError(f"Card {card_id} not found.")
    if card["status"] in ("frozen", "expired", "cancelled"):
        raise ValueError(f"Card {card_id} cannot be frozen (status: {card['status']}).")

    # Mutate the mock store
    for c in _MOCK_CARDS:
        if c["cardId"] == card_id:
            c["status"] = "frozen"
    return get_card(card_id)  # type: ignore[return-value]


def unfreeze_card(card_id: str) -> dict:
    """
    Unfreeze a previously frozen card.

    Returns:
        Updated card dict with status "active".
    Raises:
        ValueError if card not found or not currently frozen.
    """
    card = get_card(card_id)
    if not card:
        raise ValueError(f"Card {card_id} not found.")
    if card["status"] != "frozen":
        raise ValueError(f"Card {card_id} is not frozen (status: {card['status']}).")
    for c in _MOCK_CARDS:
        if c["cardId"] == card_id:
            c["status"] = "active"
    return get_card(card_id)  # type: ignore[return-value]
