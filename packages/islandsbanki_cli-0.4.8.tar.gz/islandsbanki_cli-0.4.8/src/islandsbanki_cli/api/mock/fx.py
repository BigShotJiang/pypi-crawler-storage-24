"""
Mock: Foreign exchange rates and currency conversion.

In production this would call the Íslandsbanki FX rates API or IOBWS.
The rates below are representative mid-market rates for ISK as of early 2026.
Mocked for POC demo purposes.
"""
from __future__ import annotations

from typing import Optional

# Buying/selling rates from ISK perspective (bank rates, not mid-market)
_FX_RATES = {
    "USD": {"buy": 133.50, "sell": 136.20, "mid": 134.85},
    "EUR": {"buy": 143.80, "sell": 146.70, "mid": 145.25},
    "GBP": {"buy": 167.20, "sell": 170.90, "mid": 169.05},
    "DKK": {"buy": 19.30, "sell": 19.70, "mid": 19.50},
    "SEK": {"buy": 12.40, "sell": 12.70, "mid": 12.55},
    "NOK": {"buy": 12.10, "sell": 12.45, "mid": 12.28},
    "CHF": {"buy": 148.30, "sell": 151.50, "mid": 149.90},
    "JPY": {"buy": 0.885, "sell": 0.905, "mid": 0.895},
    "CAD": {"buy": 97.20, "sell": 99.40, "mid": 98.30},
    "AUD": {"buy": 84.10, "sell": 86.00, "mid": 85.05},
    "CNY": {"buy": 18.45, "sell": 18.85, "mid": 18.65},
    "PLN": {"buy": 33.20, "sell": 34.10, "mid": 33.65},
}


def get_rates(currency: Optional[str] = None) -> dict:
    """
    Return FX rates against ISK.

    Args:
        currency: If provided, return rates for that specific currency only
                  (e.g. "USD", "EUR"). Case-insensitive.

    Returns:
        Dict of currency code → {buy, sell, mid, baseCurrency: "ISK"}.
    """
    if currency:
        code = currency.upper()
        if code not in _FX_RATES:
            raise ValueError(
                f"Unknown currency: {code}. "
                f"Supported: {', '.join(sorted(_FX_RATES.keys()))}"
            )
        return {code: {**_FX_RATES[code], "baseCurrency": "ISK"}}

    return {
        code: {**rates, "baseCurrency": "ISK"}
        for code, rates in _FX_RATES.items()
    }


def convert(amount: float, from_currency: str, to_currency: str) -> dict:
    """
    Convert an amount between two currencies using mid-market rates.

    One of from_currency or to_currency must be "ISK".

    Args:
        amount:          Amount to convert.
        from_currency:   Source currency code (e.g. "ISK", "EUR").
        to_currency:     Target currency code.

    Returns:
        Dict with inputAmount, outputAmount, rate, fromCurrency, toCurrency.
    """
    from_c = from_currency.upper()
    to_c = to_currency.upper()

    if from_c == "ISK" and to_c in _FX_RATES:
        rate = 1.0 / _FX_RATES[to_c]["mid"]
        result = amount * rate
    elif to_c == "ISK" and from_c in _FX_RATES:
        rate = _FX_RATES[from_c]["mid"]
        result = amount * rate
    elif from_c in _FX_RATES and to_c in _FX_RATES:
        # Cross rate via ISK
        to_isk = _FX_RATES[from_c]["mid"]
        from_isk = 1.0 / _FX_RATES[to_c]["mid"]
        rate = to_isk * from_isk
        result = amount * rate
    else:
        supported = ", ".join(sorted(_FX_RATES.keys()))
        raise ValueError(
            f"Cannot convert {from_c} → {to_c}. "
            f"At least one must be ISK or supported ({supported})."
        )

    return {
        "inputAmount": round(amount, 2),
        "outputAmount": round(result, 2),
        "rate": round(rate, 6),
        "fromCurrency": from_c,
        "toCurrency": to_c,
        "_mock": True,
    }
