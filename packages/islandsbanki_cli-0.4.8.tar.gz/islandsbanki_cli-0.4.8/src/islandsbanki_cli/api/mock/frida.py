"""
Mock data for Fríða — Íslandsbanki's cashback/loyalty system.

Fríða offers discounts at partner businesses. You activate an offer
in the app, pay with your Íslandsbanki card, and get cashback.

Offers come in two types:
  - Weekly recurring (föst vikuleg tilboð) — same day each week
  - Limited-time (tímabundin tilboð) — available for a limited period
"""

from __future__ import annotations

from datetime import date

# ── Categories ───────────────────────────────────────────────────────────
CATEGORIES = {
    "veitingar": "🍽️  Veitingastaðir",
    "afþreying": "🎬  Afþreying",
    "heilsa": "🏊  Heilsa & líðan",
    "verslun": "🛍️  Verslun",
}

# ── Weekly recurring offers ──────────────────────────────────────────────
WEEKLY_OFFERS: list[dict] = [
    # ── Mánudagar ──
    {
        "id": "w-mon-smarabio",
        "merchant": "Smárabíó",
        "category": "afþreying",
        "day": "mánudagur",
        "day_en": "Monday",
        "discount_pct": 50,
        "max_cashback_isk": 3_000,
        "personal": False,
        "description": "Helmings afsláttur af kvikmyndum á mánudögum.",
    },
    {
        "id": "w-mon-skopp",
        "merchant": "Skopp",
        "category": "veitingar",
        "day": "mánudagur",
        "day_en": "Monday",
        "discount_pct": 20,
        "max_cashback_isk": 3_000,
        "personal": False,
        "description": "20% afsláttur hjá Skopp á mánudögum.",
    },
    # ── Þriðjudagar ──
    {
        "id": "w-tue-skopp",
        "merchant": "Skopp",
        "category": "veitingar",
        "day": "þriðjudagur",
        "day_en": "Tuesday",
        "discount_pct": 20,
        "max_cashback_isk": 2_000,
        "personal": False,
        "description": "20% afsláttur hjá Skopp á þriðjudögum.",
    },
    {
        "id": "w-tue-isbud",
        "merchant": "Ísbúð Vesturbæjar",
        "category": "veitingar",
        "day": "þriðjudagur",
        "day_en": "Tuesday",
        "discount_pct": 20,
        "max_cashback_isk": 2_000,
        "personal": False,
        "description": "20% afsláttur á ís á þriðjudögum.",
    },
    # ── Miðvikudagar ──
    {
        "id": "w-wed-fjallkonan",
        "merchant": "Fjallkonan",
        "category": "veitingar",
        "day": "miðvikudagur",
        "day_en": "Wednesday",
        "discount_pct": 20,
        "max_cashback_isk": 5_000,
        "personal": False,
        "description": "20% afsláttur hjá Fjallkonan á miðvikudögum.",
    },
    {
        "id": "w-wed-saeta",
        "merchant": "Sæta svínið",
        "category": "veitingar",
        "day": "miðvikudagur",
        "day_en": "Wednesday",
        "discount_pct": 20,
        "max_cashback_isk": 5_000,
        "personal": False,
        "description": "20% afsláttur hjá Sæta svíninu á miðvikudögum.",
    },
    {
        "id": "w-wed-keiluhollin",
        "merchant": "Keiluhöllin",
        "category": "afþreying",
        "day": "miðvikudagur",
        "day_en": "Wednesday",
        "discount_pct": 20,
        "max_cashback_isk": 5_000,
        "personal": False,
        "description": "20% afsláttur á keilu á miðvikudögum.",
    },
    # ── Fimmtudagar ──
    {
        "id": "w-thu-fjallkonan",
        "merchant": "Fjallkonan",
        "category": "veitingar",
        "day": "fimmtudagur",
        "day_en": "Thursday",
        "discount_pct": 20,
        "max_cashback_isk": 2_500,
        "personal": False,
        "description": "20% afsláttur hjá Fjallkonan á fimmtudögum.",
    },
    {
        "id": "w-thu-saeta",
        "merchant": "Sæta svínið",
        "category": "veitingar",
        "day": "fimmtudagur",
        "day_en": "Thursday",
        "discount_pct": 20,
        "max_cashback_isk": 2_500,
        "personal": False,
        "description": "20% afsláttur hjá Sæta svíninu á fimmtudögum.",
    },
    # ── Föstudagar ──
    {
        "id": "w-fri-sundholl",
        "merchant": "Sundhöll Reykjavíkur",
        "category": "heilsa",
        "day": "föstudagur",
        "day_en": "Friday",
        "discount_pct": 20,
        "max_cashback_isk": 2_000,
        "personal": False,
        "description": "20% afsláttur í Sundhöll Reykjavíkur á föstudögum.",
    },
]

# ── Limited-time offers ──────────────────────────────────────────────────
LIMITED_OFFERS: list[dict] = [
    {
        "id": "ltd-bluelagoon",
        "merchant": "Bláa lónið (Blue Lagoon)",
        "category": "heilsa",
        "discount_pct": 30,
        "max_cashback_isk": 30_000,
        "personal": False,
        "description": "30% afsláttur í Bláa lóninu — gildir fyrir alla.",
        "valid_from": date(2026, 3, 1),
        "valid_until": date(2026, 4, 30),
    },
    {
        "id": "ltd-saeta-spring",
        "merchant": "Sæta svínið",
        "category": "veitingar",
        "discount_pct": 20,
        "max_cashback_isk": 4_000,
        "personal": True,
        "description": "Sérstakt vortilboð — aðeins fyrir þig!",
        "valid_from": date(2026, 3, 10),
        "valid_until": date(2026, 4, 15),
    },
]

# ── Mock activated state ─────────────────────────────────────────────────
# Pretend the user has activated these offers
_ACTIVATED_IDS: set[str] = {"w-mon-smarabio", "w-fri-sundholl", "ltd-bluelagoon"}

# ── Mock cashback history ────────────────────────────────────────────────
CASHBACK_HISTORY: list[dict] = [
    {
        "date": "2026-03-14",
        "merchant": "Sundhöll Reykjavíkur",
        "spent_isk": 1_200,
        "cashback_isk": 240,
        "offer_id": "w-fri-sundholl",
    },
    {
        "date": "2026-03-10",
        "merchant": "Smárabíó",
        "spent_isk": 2_800,
        "cashback_isk": 1_400,
        "offer_id": "w-mon-smarabio",
    },
    {
        "date": "2026-03-05",
        "merchant": "Bláa lónið (Blue Lagoon)",
        "spent_isk": 14_900,
        "cashback_isk": 4_470,
        "offer_id": "ltd-bluelagoon",
    },
]


# ── Query helpers ────────────────────────────────────────────────────────

_DAY_MAP = {
    0: "mánudagur",
    1: "þriðjudagur",
    2: "miðvikudagur",
    3: "fimmtudagur",
    4: "föstudagur",
    5: "laugardagur",
    6: "sunnudagur",
}


def _today_day_is() -> str:
    return _DAY_MAP[date.today().weekday()]


def get_all_offers() -> list[dict]:
    """Return all offers (weekly + limited), each tagged with its type."""
    result = []
    for o in WEEKLY_OFFERS:
        result.append({**o, "type": "weekly"})
    for o in LIMITED_OFFERS:
        result.append(
            {
                **o,
                "type": "limited",
                "valid_from": str(o["valid_from"]),
                "valid_until": str(o["valid_until"]),
            }
        )
    return result


def get_todays_offers() -> list[dict]:
    """Return only the weekly offers active today."""
    today = _today_day_is()
    return [{**o, "type": "weekly"} for o in WEEKLY_OFFERS if o["day"] == today]


def get_limited_offers() -> list[dict]:
    """Return limited-time offers still valid."""
    today = date.today()
    return [
        {
            **o,
            "type": "limited",
            "valid_from": str(o["valid_from"]),
            "valid_until": str(o["valid_until"]),
        }
        for o in LIMITED_OFFERS
        if o["valid_from"] <= today <= o["valid_until"]
    ]


def get_offers_by_category(category: str) -> list[dict]:
    """Return all offers matching a category key."""
    return [{**o, "type": "weekly"} for o in WEEKLY_OFFERS if o["category"] == category] + [
        {
            **o,
            "type": "limited",
            "valid_from": str(o["valid_from"]),
            "valid_until": str(o["valid_until"]),
        }
        for o in LIMITED_OFFERS
        if o["category"] == category
    ]


def is_activated(offer_id: str) -> bool:
    return offer_id in _ACTIVATED_IDS


def activate_offer(offer_id: str) -> bool:
    """Activate an offer. Returns True if newly activated, False if already active."""
    if offer_id in _ACTIVATED_IDS:
        return False
    _ACTIVATED_IDS.add(offer_id)
    return True


def get_cashback_summary() -> dict:
    """Return total cashback earned and recent transactions."""
    total = sum(h["cashback_isk"] for h in CASHBACK_HISTORY)
    return {
        "total_cashback_isk": total,
        "transaction_count": len(CASHBACK_HISTORY),
        "history": CASHBACK_HISTORY,
    }
