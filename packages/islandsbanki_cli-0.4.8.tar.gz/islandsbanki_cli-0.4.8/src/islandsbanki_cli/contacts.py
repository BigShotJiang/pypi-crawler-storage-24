"""
Contacts registry — name-based payment resolution.

Stores contacts in ~/.islandsbanki/contacts.json with:
  - name:          Full name (e.g. "Jón Jónsson")
  - accountNumber: Icelandic bank account (BBBB-HH-NNNNNN)
  - kennitala:     Optional national ID (for claim payments)
  - note:          Optional free-text note

Supports fuzzy name matching so an AI agent (or user) can say
"transfer 2000 to Jón" and the CLI resolves it to the right account.

Iceland-only: all contacts use Icelandic bank account numbers.
Format: BankBranch-Höfuðbók-AccountNumber (e.g. 0515-26-000262)
"""

from __future__ import annotations

import json
import unicodedata
from typing import Optional

from .config import CONFIG_DIR

CONTACTS_FILE = CONFIG_DIR / "contacts.json"


def _save(contacts: list[dict]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONTACTS_FILE.write_text(
        json.dumps(contacts, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


# ---------------------------------------------------------------------------
# Default contacts — auto-seeded on first use
# ---------------------------------------------------------------------------

_DEFAULT_CONTACTS = [
    {
        "name": "Sindri Sigurður Jónsson",
        "accountNumber": "0101-26-051598",
        "kennitala": "1234567890",
        "note": "Landlord",
    },
    {
        "name": "Guðrún Sigurðardóttir",
        "accountNumber": "0515-26-003289",
        "kennitala": "2345678901",
        "note": "Friend",
    },
    {
        "name": "Ólafur Þórsson",
        "accountNumber": "0301-26-078432",
        "kennitala": "3456789012",
        "note": "Colleague",
    },
    {
        "name": "Anna Kristjánsdóttir",
        "accountNumber": "0515-26-018756",
        "kennitala": "4567890123",
        "note": "Sister",
    },
    {
        "name": "Sigurður Helgason",
        "accountNumber": "0101-26-043291",
        "kennitala": "5678901234",
        "note": "Business partner",
    },
    {
        "name": "Katrín Davíðsdóttir",
        "accountNumber": "0301-26-092145",
        "kennitala": "6789012345",
        "note": "Gym trainer",
    },
    {
        "name": "Jón Guðni Ómarsson",
        "accountNumber": "0515-26-007823",
        "kennitala": "7890123456",
        "note": "Uncle",
    },
    {
        "name": "Hjálmar Gíslason",
        "accountNumber": "0101-26-061247",
        "kennitala": "8901234567",
        "note": "Judge",
    },
]


def _load() -> list[dict]:
    if not CONTACTS_FILE.exists():
        _save(_DEFAULT_CONTACTS)
        return list(_DEFAULT_CONTACTS)
    text = CONTACTS_FILE.read_text(encoding="utf-8")
    data = json.loads(text)
    if isinstance(data, list):
        return data
    return []


def list_contacts() -> list[dict]:
    """Return all saved contacts."""
    return _load()


def add_contact(
    name: str,
    account_number: str,
    kennitala: str = "",
    note: str = "",
) -> dict:
    """Add or update a contact. If a contact with the same account exists, update it."""
    contacts = _load()
    # Update existing by account number
    for c in contacts:
        if c["accountNumber"] == account_number:
            c["name"] = name
            if kennitala:
                c["kennitala"] = kennitala
            if note:
                c["note"] = note
            _save(contacts)
            return c
    new = {"name": name, "accountNumber": account_number, "kennitala": kennitala, "note": note}
    contacts.append(new)
    _save(contacts)
    return new


def remove_contact(account_number: str) -> bool:
    """Remove a contact by account number. Returns True if found and removed."""
    contacts = _load()
    before = len(contacts)
    contacts = [c for c in contacts if c["accountNumber"] != account_number]
    if len(contacts) < before:
        _save(contacts)
        return True
    return False


# ---------------------------------------------------------------------------
# Fuzzy name matching
# ---------------------------------------------------------------------------


def _normalize(text: str) -> str:
    """Lowercase, strip accents, collapse whitespace."""
    # NFD decompose → strip combining marks → NFC recompose
    nfkd = unicodedata.normalize("NFKD", text.lower())
    stripped = "".join(c for c in nfkd if not unicodedata.combining(c))
    return " ".join(stripped.split())


def search_contacts(query: str) -> list[dict]:
    """
    Search contacts by partial / fuzzy name match.

    Matching strategy (ordered by priority):
      1. Exact full-name match (case/accent insensitive)
      2. Token overlap — scored by how many query tokens match contact tokens
      3. Substring match anywhere in the name

    Returns all matches sorted by relevance (exact > token > substring).
    """
    contacts = _load()
    if not contacts:
        return []

    q = _normalize(query)
    q_tokens = set(q.split())

    exact: list[dict] = []
    # (overlap_count, contact) — more matching tokens = higher priority
    token_scored: list[tuple[int, dict]] = []
    substring_matches: list[dict] = []

    for c in contacts:
        n = _normalize(c["name"])
        n_tokens = set(n.split())

        if n == q:
            exact.append(c)
        elif q_tokens & n_tokens:  # any shared exact token
            overlap = len(q_tokens & n_tokens)
            token_scored.append((overlap, c))
        elif q in n or any(qt in n for qt in q_tokens):
            substring_matches.append(c)

    # Sort token matches: most overlapping tokens first
    token_scored.sort(key=lambda x: x[0], reverse=True)
    token_matches = [c for _, c in token_scored]

    return exact + token_matches + substring_matches


def resolve_to_account(query: str) -> Optional[dict]:
    """
    Resolve a name query to a single contact.

    Returns the contact dict if:
      - Exactly one match overall, OR
      - Multiple matches but multi-token query clearly scores one
        contact higher than all others (e.g. "Jón Guðni" → matches
        "Jón Guðni Ómarsson" with 2 tokens but "Jónsson" only by substring)

    Returns None when genuinely ambiguous — callers should use
    search_contacts() for disambiguation.
    """
    contacts = _load()
    if not contacts:
        return None

    q = _normalize(query)
    q_tokens = set(q.split())

    scored: list[tuple[int, dict]] = []
    for c in contacts:
        n = _normalize(c["name"])
        n_tokens = set(n.split())

        if n == q:
            scored.append((1000, c))  # exact match = highest
        elif q_tokens & n_tokens:
            scored.append((len(q_tokens & n_tokens), c))
        elif q in n or any(qt in n for qt in q_tokens):
            scored.append((0, c))  # substring = lowest tier

    if not scored:
        return None
    if len(scored) == 1:
        return scored[0][1]

    scored.sort(key=lambda x: x[0], reverse=True)
    # If top result is strictly better than second, auto-select
    if scored[0][0] > scored[1][0]:
        return scored[0][1]

    return None


def seed_contacts() -> int:
    """Re-seed the contacts file with default contacts. Returns count added."""
    existing = _load()
    if existing:
        return 0
    _save(_DEFAULT_CONTACTS)
    return len(_DEFAULT_CONTACTS)
