"""
Lightweight session state for the mock auth flow.

Stores a simple JSON file at ~/.islandsbanki/.session.json
to track whether the user has logged in via the approval flow.

Schema:
{
    "authenticated": true,
    "logged_in_at":  1234567890   # Unix timestamp
}
"""
from __future__ import annotations

import json
import time
from pathlib import Path

_SESSION_FILE = Path.home() / ".islandsbanki" / ".session.json"


def save_session() -> None:
    """Mark the user as logged in."""
    _SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = {"authenticated": True, "logged_in_at": int(time.time())}
    _SESSION_FILE.write_text(json.dumps(payload))
    _SESSION_FILE.chmod(0o600)


def load_session() -> dict | None:
    """Load session state. Returns None if not logged in."""
    if not _SESSION_FILE.exists():
        return None
    try:
        return json.loads(_SESSION_FILE.read_text())
    except Exception:
        return None


def clear_session() -> None:
    """Clear the session (logout)."""
    if _SESSION_FILE.exists():
        _SESSION_FILE.unlink()


def is_logged_in() -> bool:
    """True if a session exists."""
    session = load_session()
    return session is not None and session.get("authenticated", False)
