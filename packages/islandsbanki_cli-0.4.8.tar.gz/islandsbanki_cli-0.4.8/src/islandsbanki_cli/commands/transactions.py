"""
Transactions commands: list, show.

Uses mocked data. In production this would call the IOBWS Transactions API
or the PSD2 Account Information /transactions endpoint.

Examples:
    islandsbanki transactions list IS850515260002620103871409
    islandsbanki transactions list IS850... --from-date 2026-03-01 --limit 20
    islandsbanki transactions show TXN-20260318-001
"""

from __future__ import annotations

from datetime import date, timedelta
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from .. import state
from ..api.mock.transactions import list_transactions, get_transaction, get_spend_summary
from ..output import error, info, success

app = typer.Typer(help="View transaction history [MOCK].", no_args_is_help=True)
console = Console()


@app.command("list")
def list_cmd(
    account_id: str = typer.Argument(..., help="Account IBAN or resourceId."),
    from_date: Optional[str] = typer.Option(None, "--from-date", help="Start date YYYY-MM-DD."),
    to_date: Optional[str] = typer.Option(None, "--to-date", help="End date YYYY-MM-DD."),
    limit: int = typer.Option(50, "--limit", "-n", help="Maximum transactions to return."),
    booking_status: str = typer.Option("both", "--status", help="booked | pending | both"),
):
    """
    List transactions for an account.

    Example:
        islandsbanki transactions list IS850515260002620103871409
        islandsbanki transactions list IS850... --from-date 2026-03-01 --limit 10
        islandsbanki transactions list IS850... --status pending
    """
    try:
        result = list_transactions(
            account_id,
            date_from=from_date,
            date_to=to_date,
            limit=limit,
            booking_status=booking_status,
        )
    except Exception as e:
        error(str(e), code="MOCK_ERROR")

    if state.json_output:
        success(result, command="transactions list")
        return

    booked = result["transactions"]["booked"]
    pending = result["transactions"]["pending"]

    def _table(txns: list, title: str):
        if not txns:
            return
        t = Table(title=title, box=box.ROUNDED, highlight=True)
        t.add_column("Date", style="dim")
        t.add_column("Amount", justify="right")
        t.add_column("Ccy")
        t.add_column("Counterparty")
        t.add_column("Description")
        t.add_column("ID", style="dim")
        for tx in txns:
            amt = tx["transactionAmount"]
            amount_str = amt["amount"]
            amount_float = float(amount_str)
            color = "red" if amount_float < 0 else "green"
            t.add_row(
                tx.get("bookingDate") or tx.get("valueDate") or "—",
                f"[{color}]{amount_float:,.2f}[/{color}]",
                amt["currency"],
                tx.get("creditorName") or tx.get("debtorName") or "—",
                tx.get("remittanceInformationUnstructured", "—"),
                tx.get("transactionId", "—"),
            )
        console.print(t)

    _table(booked, f"Booked Transactions — {account_id}")
    _table(pending, "Pending Transactions")

    if not booked and not pending:
        info("No transactions found.")


@app.command("show")
def show(
    transaction_id: str = typer.Argument(..., help="Transaction ID."),
):
    """
    Show details of a single transaction.

    Example:
        islandsbanki transactions show TXN-20260318-001
    """
    tx = get_transaction(transaction_id)
    if not tx:
        error(
            f"Transaction '{transaction_id}' not found.",
            code="NOT_FOUND",
            exit_code=1,
        )

    if state.json_output:
        success({"transaction": tx}, command="transactions show")
        return

    console.print_json(data=tx)


@app.command("spend")
def spend_cmd(
    period: str = typer.Option(
        "yesterday",
        "--period",
        "-p",
        help="Preset period: yesterday | 7d | 30d",
    ),
    from_date: Optional[str] = typer.Option(
        None, "--from-date", help="Start date YYYY-MM-DD (overrides --period)."
    ),
    to_date: Optional[str] = typer.Option(
        None, "--to-date", help="End date YYYY-MM-DD (overrides --period)."
    ),
):
    """
    Summarise spending across all accounts for a period.

    Example:
        islandsbanki transactions spend
        islandsbanki transactions spend --period 7d
        islandsbanki transactions spend --from-date 2026-03-01 --to-date 2026-03-15
    """
    today = date.today()
    yesterday = today - timedelta(days=1)

    if from_date:
        d_from = date.fromisoformat(from_date)
        d_to = date.fromisoformat(to_date) if to_date else yesterday
    elif period == "7d":
        d_from = today - timedelta(days=7)
        d_to = yesterday
    elif period == "30d":
        d_from = today - timedelta(days=30)
        d_to = yesterday
    else:  # yesterday (default)
        d_from = yesterday
        d_to = yesterday

    summary = get_spend_summary(d_from, d_to)

    if state.json_output:
        success(summary, command="transactions spend")
        return

    total = summary["total_isk"]
    period_label = str(d_from) if d_from == d_to else f"{d_from} → {d_to}"

    console.print()
    console.print(
        Panel(
            f"[bold red]{total:,.0f} kr[/bold red]",
            title=f"💸  Útgjöld — {period_label}",
            subtitle=f"{summary['count']} færslur",
            border_style="red" if total > 0 else "dim",
            expand=False,
        )
    )
    console.print()

    if not summary["by_category"]:
        info("Engar gjaldafærslur fundust á þessu tímabili.")
        return

    t = Table(title="Útgjöld eftir flokki", box=box.ROUNDED, highlight=True)
    t.add_column("Flokkur", style="cyan")
    t.add_column("Upphæð", justify="right", style="bold")
    t.add_column("Fjöldi", justify="right", style="dim")
    t.add_column("Stærsta færsla", style="dim")

    for cat in summary["by_category"]:
        largest = max(cat["transactions"], key=lambda x: x["amount_isk"])
        t.add_row(
            cat["category"],
            f"{cat['total_isk']:,.0f} kr",
            str(cat["count"]),
            f"{largest['merchant']} ({largest['amount_isk']:,.0f} kr)",
        )

    console.print(t)
    console.print()
