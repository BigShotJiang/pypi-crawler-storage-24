"""
Fríða commands: list, today, limited, activate, cashback.

Fríða is Íslandsbanki's cashback loyalty system. You get discounts
at partner businesses — activate the offer, pay with your card,
and get cashback automatically.

Examples:
    islandsbanki frida list
    islandsbanki frida today
    islandsbanki frida limited
    islandsbanki frida activate w-mon-smarabio
    islandsbanki frida cashback
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box

from .. import state
from ..api.mock.frida import (
    CATEGORIES,
    get_all_offers,
    get_todays_offers,
    get_limited_offers,
    get_offers_by_category,
    is_activated,
    activate_offer,
    get_cashback_summary,
)
from ..output import success, info

app = typer.Typer(
    help="Fríða — cashback & loyalty offers from Íslandsbanki.",
    no_args_is_help=True,
)
console = Console()


def _format_isk(amount: int) -> str:
    """Format ISK amount with thousands separator."""
    return f"{amount:,} kr".replace(",", ".")


def _status_badge(offer_id: str) -> str:
    return "[bold green]✓ VIRKT[/bold green]" if is_activated(offer_id) else "[dim]—[/dim]"


def _render_offers_table(offers: list[dict], *, title: str) -> Table:
    """Build a Rich table from a list of offers."""
    t = Table(title=title, box=box.ROUNDED, highlight=True, show_lines=True)
    t.add_column("Staða", justify="center", width=8)
    t.add_column("Staður", style="cyan bold", min_width=20)
    t.add_column("Flokkur", style="dim")
    t.add_column("Afsláttur", justify="right", style="green bold")
    t.add_column("Hámark", justify="right")
    t.add_column("Tegund", style="dim")
    t.add_column("Fyrir", justify="center")

    for o in offers:
        cat_label = CATEGORIES.get(o["category"], o["category"])
        offer_type = o.get("type", "weekly")
        if offer_type == "weekly":
            type_str = f"[blue]{o.get('day', '')}[/blue]"
        else:
            type_str = f"[yellow]→ {o.get('valid_until', '?')}[/yellow]"

        personal = "[magenta]Þitt[/magenta]" if o.get("personal") else "Allir"

        t.add_row(
            _status_badge(o["id"]),
            o["merchant"],
            cat_label,
            f"{o['discount_pct']}%",
            _format_isk(o["max_cashback_isk"]),
            type_str,
            personal,
        )

    return t


@app.command("list")
def list_cmd(
    category: str = typer.Option(
        None,
        "--category",
        "-c",
        help="Filter by category: veitingar, afþreying, heilsa, verslun.",
    ),
):
    """
    List all Fríða offers — weekly recurring and limited-time.

    Example:
        islandsbanki frida list
        islandsbanki frida list --category veitingar
        islandsbanki frida list --json
    """
    if category:
        offers = get_offers_by_category(category)
        title = f"Fríða — {CATEGORIES.get(category, category)}"
    else:
        offers = get_all_offers()
        title = "Fríða — Öll tilboð"

    if state.json_output:
        success({"offers": offers, "count": len(offers)}, command="frida list")
        return

    if not offers:
        info("Engin tilboð fundust.")
        return

    # Group by type for a nicer display
    weekly = [o for o in offers if o.get("type") == "weekly"]
    limited = [o for o in offers if o.get("type") == "limited"]

    if weekly:
        console.print()
        console.print(_render_offers_table(weekly, title=f"{title} — Föst vikuleg"))
    if limited:
        console.print()
        console.print(_render_offers_table(limited, title=f"{title} — Tímabundin"))

    console.print()
    console.print("[dim]Virkjaðu tilboð með:[/dim] [bold]islandsbanki frida activate <id>[/bold]")


@app.command("today")
def today_cmd():
    """
    Show today's active weekly offers.

    Example:
        islandsbanki frida today
        islandsbanki frida today --json
    """
    offers = get_todays_offers()

    if state.json_output:
        success({"offers": offers, "count": len(offers)}, command="frida today")
        return

    if not offers:
        console.print(
            Panel(
                "[dim]Engin föst tilboð í dag. Skoðaðu tímabundin tilboð:[/dim]\n"
                "[bold]islandsbanki frida limited[/bold]",
                title="Fríða — Í dag",
                border_style="blue",
            )
        )
        return

    console.print()
    console.print(_render_offers_table(offers, title="Fríða — Í dag"))


@app.command("limited")
def limited_cmd():
    """
    Show currently valid limited-time offers.

    Example:
        islandsbanki frida limited
        islandsbanki frida limited --json
    """
    offers = get_limited_offers()

    if state.json_output:
        success({"offers": offers, "count": len(offers)}, command="frida limited")
        return

    if not offers:
        info("Engin tímabundin tilboð í gangi.")
        return

    console.print()
    console.print(_render_offers_table(offers, title="Fríða — Tímabundin tilboð"))


@app.command("activate")
def activate_cmd(
    offer_id: str = typer.Argument(..., help="Offer ID to activate (e.g. w-mon-smarabio)."),
):
    """
    Activate (virkja) an offer so you receive cashback when you pay.

    Example:
        islandsbanki frida activate w-mon-smarabio
        islandsbanki frida activate ltd-bluelagoon --json
    """
    newly = activate_offer(offer_id)

    if state.json_output:
        success(
            {"offer_id": offer_id, "newly_activated": newly, "status": "active"},
            command="frida activate",
        )
        return

    if newly:
        console.print(f"[bold green]✓[/bold green] Tilboð [cyan]{offer_id}[/cyan] virkjað!")
    else:
        console.print(f"[yellow]Tilboð [cyan]{offer_id}[/cyan] er nú þegar virkt.[/yellow]")


@app.command("cashback")
def cashback_cmd():
    """
    Show your cashback earnings summary and recent history.

    Example:
        islandsbanki frida cashback
        islandsbanki frida cashback --json
    """
    summary = get_cashback_summary()

    if state.json_output:
        success(summary, command="frida cashback")
        return

    total = summary["total_cashback_isk"]

    console.print()
    console.print(
        Panel(
            f"[bold green]{_format_isk(total)}[/bold green]",
            title="💰 Heildar endurgreiðsla",
            subtitle=f"{summary['transaction_count']} færslur",
            border_style="green",
            expand=False,
        )
    )

    if summary["history"]:
        t = Table(title="Nýlegar endurgreiðslur", box=box.ROUNDED, highlight=True)
        t.add_column("Dagsetning", style="dim")
        t.add_column("Staður", style="cyan")
        t.add_column("Upphæð", justify="right")
        t.add_column("Endurgreitt", justify="right", style="green bold")

        for h in summary["history"]:
            t.add_row(
                h["date"],
                h["merchant"],
                _format_isk(h["spent_isk"]),
                _format_isk(h["cashback_isk"]),
            )

        console.print(t)
    console.print()
