"""
Cards commands: list, show, freeze, unfreeze.

Uses mocked data. In production this would integrate with the IOBWS
card management API.

Examples:
    islandsbanki cards list
    islandsbanki cards show CARD-001
    islandsbanki cards freeze CARD-001
    islandsbanki cards unfreeze CARD-001
"""
from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from .. import state
from ..api.mock.cards import list_cards, get_card, freeze_card, unfreeze_card
from ..output import error, ok, info, success

app = typer.Typer(help="Manage debit and credit cards [MOCK].", no_args_is_help=True)
console = Console()


@app.command("list")
def list_cmd(
    include_expired: bool = typer.Option(False, "--all", help="Include expired cards."),
):
    """
    List all cards associated with your account.

    Example:
        islandsbanki cards list
        islandsbanki cards list --all
        islandsbanki cards list --json
    """
    cards = list_cards(include_expired=include_expired)

    if state.json_output:
        success({"cards": cards}, command="cards list")
        return

    if not cards:
        info("No cards found.")
        return

    t = Table(title="Your Cards", box=box.ROUNDED)
    t.add_column("ID", style="dim")
    t.add_column("Masked PAN")
    t.add_column("Type")
    t.add_column("Scheme")
    t.add_column("Expires")
    t.add_column("Status")
    t.add_column("Contactless")

    for card in cards:
        status = card["status"]
        if status == "active":
            status_display = f"[green]{status}[/green]"
        elif status == "frozen":
            status_display = f"[yellow]{status}[/yellow]"
        else:
            status_display = f"[dim]{status}[/dim]"
        t.add_row(
            card["cardId"],
            card["maskedPan"],
            card["cardType"],
            card["scheme"],
            card["expiryDate"],
            status_display,
            "✓" if card["contactless"] else "—",
        )

    console.print(t)


@app.command("show")
def show(
    card_id: str = typer.Argument(..., help="Card ID (e.g. CARD-001)."),
):
    """
    Show full details of a card.

    Example:
        islandsbanki cards show CARD-001
    """
    card = get_card(card_id)
    if not card:
        error(f"Card '{card_id}' not found.", code="NOT_FOUND")

    if state.json_output:
        success({"card": card}, command="cards show")
        return

    console.print_json(data=card)


@app.command("freeze")
def freeze(
    card_id: str = typer.Argument(..., help="Card ID to freeze (e.g. CARD-001)."),
    confirm: bool = typer.Option(False, "--confirm", help="Skip confirmation prompt."),
):
    """
    Temporarily freeze a card — blocks all transactions until unfrozen.

    Example:
        islandsbanki cards freeze CARD-001 --confirm
    """
    if not confirm and not state.json_output:
        confirmed = typer.confirm(f"Freeze card {card_id}? All transactions will be blocked.")
        if not confirmed:
            info("Freeze cancelled.")
            raise typer.Exit()

    try:
        card = freeze_card(card_id)
    except ValueError as e:
        error(str(e), code="CARD_ERROR")

    if state.json_output:
        success({"card": card}, command="cards freeze")
        return

    ok(f"Card [bold]{card_id}[/bold] ([cyan]{card['maskedPan']}[/cyan]) is now [yellow]frozen[/yellow].")


@app.command("unfreeze")
def unfreeze(
    card_id: str = typer.Argument(..., help="Card ID to unfreeze (e.g. CARD-001)."),
):
    """
    Unfreeze a previously frozen card.

    Example:
        islandsbanki cards unfreeze CARD-001
    """
    try:
        card = unfreeze_card(card_id)
    except ValueError as e:
        error(str(e), code="CARD_ERROR")

    if state.json_output:
        success({"card": card}, command="cards unfreeze")
        return

    ok(f"Card [bold]{card_id}[/bold] ([cyan]{card['maskedPan']}[/cyan]) is now [green]active[/green].")
