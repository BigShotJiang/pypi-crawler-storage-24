"""
Web commands: rates, branches, news, products.

Fetches publicly available information from islandsbanki.is — no authentication required.
Scrapes live data where possible, falls back to embedded mock data.

Examples:
    islandsbanki web rates
    islandsbanki web rates --category savings
    islandsbanki web branches
    islandsbanki web branches --near Akureyri
    islandsbanki web news
    islandsbanki web news --limit 10
    islandsbanki web products
    islandsbanki web products --category loans
"""
from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from .. import state
from ..api.mock.web_info import get_interest_rates, get_branches, get_news, get_products
from ..output import error, info, success

app = typer.Typer(
    help="Public information from islandsbanki.is — no login required.",
    no_args_is_help=True,
)
console = Console()


@app.command("rates")
def rates(
    category: str = typer.Option("mortgage", "--category", "-c", help="Rate category: mortgage | savings | deposit"),
):
    """
    Show current interest rates from islandsbanki.is.

    Attempts to fetch live data; falls back to cached rates if the site is unreachable.

    Example:
        islandsbanki web rates
        islandsbanki web rates --category savings
        islandsbanki web rates --category deposit --json
    """
    try:
        result = get_interest_rates(category=category)
    except ValueError as e:
        error(str(e), code="INVALID_CATEGORY")

    if state.json_output:
        success(result, command="web rates")
        return

    source_label = "[green]live[/green]" if result.get("source") == "live" else "[yellow]cached[/yellow]"
    mock_note = " [dim](mock)[/dim]" if result.get("_mock") else ""

    t = Table(
        title=f"Interest Rates — {category.title()} ({source_label}{mock_note})",
        box=box.ROUNDED,
    )

    rate_list = result.get("rates", [])
    if not rate_list:
        info("No rate data available.")
        return

    # Determine columns from first entry
    cols = list(rate_list[0].keys())
    for col in cols:
        t.add_column(col.replace("_", " ").title())

    for rate_entry in rate_list:
        t.add_row(*[str(v) for v in rate_entry.values()])

    console.print(t)


@app.command("branches")
def branches(
    near: Optional[str] = typer.Option(None, "--near", help="Filter by city or area name."),
):
    """
    Show Íslandsbanki branch locations.

    Example:
        islandsbanki web branches
        islandsbanki web branches --near Akureyri
        islandsbanki web branches --json
    """
    results = get_branches(near=near)

    if state.json_output:
        success({"branches": results, "filter": near}, command="web branches")
        return

    if not results:
        info(f"No branches found{' near ' + near if near else ''}.")
        return

    t = Table(title="Branch Locations", box=box.ROUNDED)
    t.add_column("Name", style="bold")
    t.add_column("Address")
    t.add_column("Phone")
    t.add_column("Hours")
    t.add_column("Services")

    for branch in results:
        t.add_row(
            branch["name"],
            branch["address"],
            branch["phone"],
            branch["hours"],
            ", ".join(branch.get("services", [])),
        )

    console.print(t)


@app.command("news")
def news(
    limit: int = typer.Option(5, "--limit", "-n", help="Number of articles to return."),
):
    """
    Fetch latest news and press releases from islandsbanki.is.

    Example:
        islandsbanki web news
        islandsbanki web news --limit 10
        islandsbanki web news --json
    """
    articles = get_news(limit=limit)

    if state.json_output:
        success({"articles": articles}, command="web news")
        return

    if not articles:
        info("No news articles found.")
        return

    for article in articles:
        mock_badge = "[dim][mock][/dim] " if article.get("_mock") else ""
        console.print(
            f"\n  {mock_badge}[bold]{article.get('title', 'Untitled')}[/bold]  "
            f"[dim]{article.get('date', '')}[/dim]"
        )
        if article.get("summary"):
            console.print(f"  {article['summary']}")
        if article.get("url"):
            console.print(f"  [link={article['url']}][dim]{article['url']}[/dim][/link]")

    console.print()


@app.command("products")
def products(
    category: Optional[str] = typer.Option(None, "--category", "-c", help="Filter: loans | savings | cards | insurance"),
):
    """
    Browse Íslandsbanki product categories and links.

    Example:
        islandsbanki web products
        islandsbanki web products --category loans
        islandsbanki web products --json
    """
    try:
        result = get_products(category=category)
    except ValueError as e:
        error(str(e), code="INVALID_CATEGORY")

    if state.json_output:
        success({"products": result}, command="web products")
        return

    for cat, items in result.items():
        console.print(f"\n[bold]{cat.title()}[/bold]")
        for item in items:
            console.print(f"  • {item['name']}")
            console.print(f"    [dim][link={item['url']}]{item['url']}[/link][/dim]")

    console.print()
