"""
FX commands: rates, convert.

Uses mocked rates. In production this would call the Íslandsbanki
FX/market data API.

Examples:
    islandsbanki fx rates
    islandsbanki fx rates --currency USD
    islandsbanki fx convert 100 USD ISK
    islandsbanki fx convert 50000 ISK EUR
"""
from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from .. import state
from ..api.mock.fx import get_rates, convert
from ..output import error, success

app = typer.Typer(help="Foreign exchange rates and currency conversion [MOCK].", no_args_is_help=True)
console = Console()


@app.command("rates")
def rates(
    currency: Optional[str] = typer.Option(None, "--currency", "-c", help="Filter by currency code (e.g. USD, EUR)."),
):
    """
    Show current foreign exchange rates against ISK.

    Example:
        islandsbanki fx rates
        islandsbanki fx rates --currency EUR
        islandsbanki fx rates --json
    """
    try:
        data = get_rates(currency=currency)
    except ValueError as e:
        error(str(e), code="INVALID_CURRENCY")

    if state.json_output:
        success({"rates": data, "base": "ISK"}, command="fx rates")
        return

    t = Table(title="FX Rates (base: ISK)", box=box.ROUNDED)
    t.add_column("Currency", style="bold cyan")
    t.add_column("Buy", justify="right")
    t.add_column("Mid", justify="right", style="bold")
    t.add_column("Sell", justify="right")

    for code, rate_data in sorted(data.items()):
        t.add_row(
            code,
            f"{rate_data['buy']:.4f}",
            f"{rate_data['mid']:.4f}",
            f"{rate_data['sell']:.4f}",
        )

    console.print(t)
    console.print("[dim]Source: mock data. Use `web rates` for live rates from islandsbanki.is[/dim]")


@app.command("convert")
def convert_cmd(
    amount: float = typer.Argument(..., help="Amount to convert."),
    from_currency: str = typer.Argument(..., help="Source currency (e.g. ISK, USD)."),
    to_currency: str = typer.Argument(..., help="Target currency (e.g. EUR, ISK)."),
):
    """
    Convert an amount between currencies using mid-market rates.

    At least one currency must be ISK, or both must be in our table for cross rates.

    Example:
        islandsbanki fx convert 50000 ISK EUR
        islandsbanki fx convert 100 USD ISK
        islandsbanki fx convert 1000 EUR GBP
    """
    try:
        result = convert(amount, from_currency, to_currency)
    except ValueError as e:
        error(str(e), code="CONVERSION_ERROR")

    if state.json_output:
        success(result, command="fx convert")
        return

    console.print(
        f"\n  [bold]{result['inputAmount']:,.2f} {result['fromCurrency']}[/bold]"
        f"  →  "
        f"[bold green]{result['outputAmount']:,.2f} {result['toCurrency']}[/bold green]"
    )
    console.print(f"  [dim]Rate: 1 {result['fromCurrency']} = {result['rate']:.6f} {result['toCurrency']}[/dim]\n")
