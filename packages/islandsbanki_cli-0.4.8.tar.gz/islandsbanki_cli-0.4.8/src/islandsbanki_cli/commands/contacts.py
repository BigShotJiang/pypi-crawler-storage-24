"""
Contacts commands: list, add, remove, search, seed.

Manage your payment contacts directory. When you add someone,
they become available for name-based payments:
    islandsbanki payments initiate --from 0515-26-000262 --to "Jón" --amount 2000

Examples:
    islandsbanki contacts list
    islandsbanki contacts search "Jón"
    islandsbanki contacts add --name "Jón Jónsson" --account 0101-26-051598
    islandsbanki contacts remove 0101-26-051598
    islandsbanki contacts seed
"""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from .. import state
from ..contacts import (
    list_contacts,
    add_contact,
    remove_contact,
    search_contacts,
    seed_contacts,
)
from ..output import info, ok, success

app = typer.Typer(
    help="Manage payment contacts — name-based payment resolution.",
    no_args_is_help=True,
)
console = Console()


@app.command("list")
def list_cmd():
    """
    List all saved contacts.

    Example:
        islandsbanki contacts list
        islandsbanki contacts list --json
    """
    contacts = list_contacts()

    if state.json_output:
        success({"contacts": contacts, "count": len(contacts)}, command="contacts list")
        return

    if not contacts:
        info("No contacts saved. Use [bold]islandsbanki contacts add[/bold] to add a contact.")
        return

    t = Table(title="Contacts", box=box.ROUNDED, highlight=True)
    t.add_column("Name", style="cyan")
    t.add_column("Account", style="bold")
    t.add_column("Kennitala", style="dim")
    t.add_column("Note", style="dim")

    for c in contacts:
        t.add_row(
            c.get("name", "—"),
            c.get("accountNumber", "—"),
            c.get("kennitala", "—"),
            c.get("note", "—"),
        )

    console.print(t)


@app.command("search")
def search(
    query: str = typer.Argument(..., help="Name or partial name to search for."),
):
    """
    Search contacts by name (fuzzy matching).

    Supports partial names, accent-insensitive matching.
    "Jón" will find "Jón Jónsson", "Jón Bggi Sigurðsson", etc.

    Example:
        islandsbanki contacts search "Jón"
        islandsbanki contacts search "Guðrún" --json
    """
    matches = search_contacts(query)

    if state.json_output:
        success(
            {"query": query, "matches": matches, "count": len(matches)},
            command="contacts search",
        )
        return

    if not matches:
        info(f'No contacts matching "{query}".')
        return

    t = Table(title=f'Contacts matching "{query}"', box=box.ROUNDED, highlight=True)
    t.add_column("#", style="dim")
    t.add_column("Name", style="cyan")
    t.add_column("Account", style="bold")
    t.add_column("Note", style="dim")

    for i, c in enumerate(matches, 1):
        t.add_row(str(i), c["name"], c["accountNumber"], c.get("note", ""))

    console.print(t)


@app.command("add")
def add(
    name: str = typer.Option(..., "--name", help="Contact full name."),
    account: str = typer.Option(..., "--account", help="Icelandic bank account (BBBB-HH-NNNNNN)."),
    kennitala: Optional[str] = typer.Option(None, "--kt", help="Kennitala (national ID)."),
    note: Optional[str] = typer.Option(None, "--note", help="Free-text note."),
):
    """
    Add or update a contact.

    If a contact with the same account number already exists, it will be updated.

    Example:
        islandsbanki contacts add --name "Jón Jónsson" --account 0101-26-051598
        islandsbanki contacts add --name "Anna" --account 0515-26-018756 --kt 4567890123 --note "Sister"
    """
    contact = add_contact(name, account, kennitala=kennitala or "", note=note or "")

    if state.json_output:
        success({"contact": contact}, command="contacts add")
        return

    ok(f"Contact saved: [bold]{name}[/bold] → {account}")


@app.command("remove")
def remove(
    account: str = typer.Argument(..., help="Account number of the contact to remove."),
):
    """
    Remove a contact by account number.

    Example:
        islandsbanki contacts remove 0101-26-051598
    """
    removed = remove_contact(account)

    if state.json_output:
        success({"accountNumber": account, "removed": removed}, command="contacts remove")
        return

    if removed:
        ok(f"Contact with account {account} removed.")
    else:
        info(f"No contact found with account {account}.")


@app.command("seed")
def seed():
    """
    Seed the contacts file with demo/mock data.

    Adds 7 realistic Icelandic contacts if the contacts file is empty.
    Safe to run multiple times — does nothing if contacts already exist.

    Example:
        islandsbanki contacts seed
    """
    count = seed_contacts()

    if state.json_output:
        success({"seeded": count}, command="contacts seed")
        return

    if count:
        ok(
            f"Seeded {count} demo contacts. Run [bold]islandsbanki contacts list[/bold] to see them."
        )
    else:
        info("Contacts file already has entries — skipping seed.")
