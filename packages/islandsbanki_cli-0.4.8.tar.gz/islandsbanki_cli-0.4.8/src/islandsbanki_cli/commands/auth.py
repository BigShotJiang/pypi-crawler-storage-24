"""
Auth commands: login, logout, status.

Login sends an approval request to the Íslandsbanki app. The user
approves or rejects on their device. Session state is persisted locally.

Examples:
    islandsbanki auth login
    islandsbanki auth logout
    islandsbanki auth status
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from .. import state
from ..api.mock.approval import request_approval
from ..auth.session import save_session, clear_session, load_session, is_logged_in
from ..output import error, ok, info, warn, success


app = typer.Typer(help="Authenticate with Íslandsbanki.", no_args_is_help=True)
console = Console()


@app.command("login")
def login():
    """
    Authenticate with Íslandsbanki via Audkenni 2FA.

    Sends a login approval request to your Íslandsbanki app.
    Once you approve it on your device, the session is established.

    Example:
        islandsbanki auth login
    """
    if is_logged_in():
        info("Already logged in. Use [bold]auth logout[/bold] to sign out first.")
        if state.json_output:
            success({"authenticated": True, "already_logged_in": True}, command="auth login")
        return

    info("Sending login approval to your device…")

    try:
        result = request_approval(
            "login",
            {"user_name": "Rúrik"},
        )
    except RuntimeError as e:
        error(str(e), code="APPROVAL_FAILED")

    if result["status"] == "rejected":
        error("Login rejected by user.", code="AUTH_REJECTED")

    save_session()
    ok("Login approved — authenticated.")
    if state.json_output:
        success({"authenticated": True}, command="auth login")


@app.command("logout")
def logout():
    """
    Remove stored authentication session.

    Example:
        islandsbanki auth logout
    """
    clear_session()

    if state.json_output:
        success({"cleared": True}, command="auth logout")
    else:
        ok("Logged out.")


@app.command("status")
def status():
    """
    Show current authentication status.

    Example:
        islandsbanki auth status
        islandsbanki auth status --json
    """
    session = load_session()
    authenticated = session is not None and session.get("authenticated", False)
    logged_in_at = session.get("logged_in_at") if session else None

    result = {
        "authenticated": authenticated,
        "logged_in_at": logged_in_at,
    }

    if state.json_output:
        success(result, command="auth status")
        return

    _YES = "[green]✓[/green]"
    _NO = "[red]✗[/red]"

    t = Table(title="Authentication Status", box=box.ROUNDED)
    t.add_column("Field", style="bold")
    t.add_column("Value")
    t.add_row("Logged In", _YES if authenticated else _NO)
    if logged_in_at:
        import datetime

        dt = datetime.datetime.fromtimestamp(logged_in_at)
        t.add_row("Since", dt.strftime("%Y-%m-%d %H:%M"))
    console.print(t)

    if not authenticated:
        warn("Not logged in. Run: islandsbanki auth login")
