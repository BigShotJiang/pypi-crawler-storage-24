"""
Bank interaction commands: appointments sub-group.

Commands for scheduling and managing advisor meetings at Íslandsbanki.
Mocked for POC — in production would integrate with the bank's CRM.

Sub-commands:
    islandsbanki bank appointments slots   --topic mortgage
    islandsbanki bank appointments book    --slot-id SLOT-MOR-001 --topic mortgage
    islandsbanki bank appointments list
    islandsbanki bank appointments cancel  APPT-ABCD1234
    islandsbanki bank appointments ical    APPT-ABCD1234
    islandsbanki bank appointments topics

Examples:
    islandsbanki bank appointments slots --topic mortgage
    islandsbanki bank appointments book --slot-id SLOT-MOR-001 --topic mortgage
    islandsbanki bank appointments list
    islandsbanki bank appointments ical APPT-ABCD1234 --save meeting.ics
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from .. import state
from ..api.mock.appointments import (
    list_slots,
    book_appointment,
    list_appointments,
    cancel_appointment,
    get_ical,
    list_topics,
)
from ..output import error, ok, info, success

# Root group for "bank" — contains sub-groups
app = typer.Typer(
    help="Book advisor meetings and manage bank interactions [MOCK].", no_args_is_help=True
)
appointments_app = typer.Typer(
    help="Schedule and manage advisor appointments.", no_args_is_help=True
)
app.add_typer(appointments_app, name="appointments", help="Schedule advisor meetings.")

console = Console()


@appointments_app.command("topics")
def topics():
    """
    List available consultation topics.

    Example:
        islandsbanki bank appointments topics
    """
    data = list_topics()

    if state.json_output:
        success({"topics": data}, command="bank appointments topics")
        return

    t = Table(title="Available Topics", box=box.ROUNDED)
    t.add_column("Key", style="bold cyan")
    t.add_column("Description")
    for key, desc in data.items():
        t.add_row(key, desc)
    console.print(t)


@appointments_app.command("slots")
def slots(
    topic: str = typer.Option("general", "--topic", "-t", help="Consultation topic key."),
    branch_id: Optional[str] = typer.Option(
        None, "--branch", help="Branch ID filter (e.g. BRANCH-HT)."
    ),
):
    """
    Show available appointment slots for a topic. Always check if the user is avalible at the given time.

    Example:
        islandsbanki bank appointments slots --topic mortgage
        islandsbanki bank appointments slots --topic savings --branch BRANCH-HT
        islandsbanki bank appointments slots --json
    """
    try:
        available = list_slots(topic=topic, branch_id=branch_id)
    except ValueError as e:
        error(str(e), code="INVALID_TOPIC")

    if state.json_output:
        success({"slots": available, "topic": topic}, command="bank appointments slots")
        return

    if not available:
        info("No available slots found.")
        return

    t = Table(title=f"Available Slots — {topic}", box=box.ROUNDED)
    t.add_column("Slot ID", style="bold cyan")
    t.add_column("Date & Time")
    t.add_column("Duration")
    t.add_column("Branch")
    t.add_column("Advisor")

    for slot in available:
        t.add_row(
            slot["slotId"],
            slot["dateTime"].replace("T", " "),
            f"{slot['durationMinutes']} min",
            slot["branch"]["name"],
            slot["advisor"]["name"],
        )

    console.print(t)
    console.print(
        "[dim]Book with: islandsbanki bank appointments book --slot-id <SLOT-ID> --topic "
        + topic
        + "[/dim]"
    )


@appointments_app.command("book")
def book(
    slot_id: str = typer.Option(..., "--slot-id", help="Slot ID from `slots` command."),
    topic: str = typer.Option(..., "--topic", "-t", help="Consultation topic key."),
    notes: Optional[str] = typer.Option(None, "--notes", help="Notes for the advisor."),
    save_ical: Optional[str] = typer.Option(
        None, "--save-ical", help="Save .ics file to this path."
    ),
):
    """
    Book an appointment slot.

    The booking confirmation includes an iCal file you can import to your calendar.

    Example:
        islandsbanki bank appointments book --slot-id SLOT-MOR-001 --topic mortgage
        islandsbanki bank appointments book --slot-id SLOT-MOR-001 --topic mortgage --save-ical meeting.ics
        islandsbanki bank appointments book --slot-id SLOT-MOR-001 --topic mortgage --notes "Looking at 25M ISK mortgage"
    """
    try:
        appt = book_appointment(slot_id=slot_id, topic=topic, notes=notes)
    except ValueError as e:
        error(str(e), code="BOOKING_FAILED")

    # Optionally save iCal to disk
    if save_ical:
        ical_data = appt.get("iCalData", "")
        Path(save_ical).write_text(ical_data)
        ok(f"iCal saved to: {save_ical}")

    if state.json_output:
        success({"appointment": appt}, command="bank appointments book")
        return

    ok(f"Appointment confirmed! ID: [bold]{appt['appointmentId']}[/bold]")
    console.print(f"  Topic:   {appt['topicLabel']}")
    console.print(f"  When:    {appt['dateTime'].replace('T', ' ')}")
    console.print(f"  Where:   {appt['branch']['name']}, {appt['branch']['address']}")
    console.print(f"  Advisor: {appt['advisor']['name']}")
    if not save_ical:
        console.print(
            f"\n[dim]Export to calendar: islandsbanki bank appointments ical {appt['appointmentId']} --save meeting.ics[/dim]"
        )


@appointments_app.command("list")
def list_cmd():
    """
    List your upcoming booked appointments.

    Example:
        islandsbanki bank appointments list
        islandsbanki bank appointments list --json
    """
    appts = list_appointments()

    if state.json_output:
        success({"appointments": appts}, command="bank appointments list")
        return

    if not appts:
        info("No upcoming appointments.")
        return

    t = Table(title="Upcoming Appointments", box=box.ROUNDED)
    t.add_column("Appointment ID", style="bold cyan")
    t.add_column("Date & Time")
    t.add_column("Topic")
    t.add_column("Branch")
    t.add_column("Advisor")
    t.add_column("Status")

    for appt in appts:
        t.add_row(
            appt["appointmentId"],
            appt["dateTime"].replace("T", " "),
            appt["topicLabel"],
            appt["branch"]["name"],
            appt["advisor"]["name"],
            appt["status"],
        )

    console.print(t)


@appointments_app.command("cancel")
def cancel(
    appointment_id: str = typer.Argument(..., help="Appointment ID to cancel."),
    confirm: bool = typer.Option(False, "--confirm", help="Skip confirmation prompt."),
):
    """
    Cancel a booked appointment.

    Example:
        islandsbanki bank appointments cancel APPT-ABCD1234 --confirm
    """
    if not confirm and not state.json_output:
        confirmed = typer.confirm(f"Cancel appointment {appointment_id}?")
        if not confirmed:
            info("Cancellation aborted.")
            raise typer.Exit()

    try:
        appt = cancel_appointment(appointment_id)
    except ValueError as e:
        error(str(e), code="NOT_FOUND")

    if state.json_output:
        success({"appointment": appt}, command="bank appointments cancel")
        return

    ok(f"Appointment [bold]{appointment_id}[/bold] cancelled.")


@appointments_app.command("ical")
def ical(
    appointment_id: str = typer.Argument(..., help="Appointment ID."),
    save: Optional[str] = typer.Option(None, "--save", help="File path to save the .ics file."),
):
    """
    Print or save the iCal data for an appointment.

    The .ics file can be imported into Apple Calendar, Google Calendar, Outlook, etc.

    Example:
        islandsbanki bank appointments ical APPT-ABCD1234
        islandsbanki bank appointments ical APPT-ABCD1234 --save meeting.ics
    """
    ical_data = get_ical(appointment_id)
    if not ical_data:
        error(
            f"Appointment '{appointment_id}' not found.",
            code="NOT_FOUND",
        )

    if save:
        Path(save).write_text(ical_data)
        ok(f"iCal saved to: {save}")
        return

    if state.json_output:
        success(
            {"appointmentId": appointment_id, "iCalData": ical_data},
            command="bank appointments ical",
        )
        return

    console.print(ical_data)
