"""
Profile commands: show, addresses, advisor.

Uses mocked data.

Examples:
    islandsbanki profile show
    islandsbanki profile addresses
    islandsbanki profile advisor
"""
from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from .. import state
from ..api.mock.profile import get_profile, get_addresses, get_advisor
from ..output import success

app = typer.Typer(help="View your profile and contact information [MOCK].", no_args_is_help=True)
console = Console()


@app.command("show")
def show():
    """
    Display your profile information (name, kennitala, contact details).

    Example:
        islandsbanki profile show
        islandsbanki profile show --json
    """
    profile = get_profile()

    if state.json_output:
        success({"profile": profile}, command="profile show")
        return

    t = Table(title="Your Profile", box=box.MINIMAL_HEAVY_HEAD)
    t.add_column("Field", style="dim")
    t.add_column("Value", style="bold")

    fields = [
        ("Name", profile.get("name", "—")),
        ("Kennitala", profile.get("kennitala", "—")),
        ("Email", profile.get("email", "—")),
        ("Phone", profile.get("phone", "—")),
        ("Customer Since", profile.get("bankRelationshipSince", "—")),
        ("Segment", profile.get("customerSegment", "—")),
        ("Language", profile.get("preferredLanguage", "—")),
    ]

    for field, value in fields:
        t.add_row(field, value)

    console.print(t)


@app.command("addresses")
def addresses():
    """
    List registered addresses.

    Example:
        islandsbanki profile addresses
    """
    addrs = get_addresses()

    if state.json_output:
        success({"addresses": addrs}, command="profile addresses")
        return

    t = Table(title="Your Addresses", box=box.ROUNDED)
    t.add_column("Type")
    t.add_column("Street")
    t.add_column("Postal Code")
    t.add_column("City")
    t.add_column("Country")
    t.add_column("Primary")

    for addr in addrs:
        t.add_row(
            addr.get("type", "—"),
            addr.get("street", "—"),
            addr.get("postalCode", "—"),
            addr.get("city", "—"),
            addr.get("country", "—"),
            "✓" if addr.get("primary") else "—",
        )

    console.print(t)


@app.command("advisor")
def advisor():
    """
    Show your assigned bank advisor's contact information.

    Example:
        islandsbanki profile advisor
        islandsbanki profile advisor --json
    """
    adv = get_advisor()

    if state.json_output:
        success({"advisor": adv}, command="profile advisor")
        return

    console.print("\n[bold]Your Bank Advisor[/bold]")
    console.print(f"  Name:   [cyan]{adv.get('name', '—')}[/cyan]")
    console.print(f"  Email:  {adv.get('email', '—')}")
    console.print(f"  Phone:  {adv.get('phone', '—')}")
    console.print(f"  Branch: {adv.get('branch', '—')}\n")
