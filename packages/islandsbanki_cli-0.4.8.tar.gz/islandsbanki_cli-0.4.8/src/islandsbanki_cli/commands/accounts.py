"""
Accounts commands: list, show, balance.

Examples:
    islandsbanki accounts list
    islandsbanki accounts list --json
    islandsbanki accounts show 0515-26-000262
    islandsbanki accounts balance 0515-26-000262
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from .. import state
from ..api.mock import accounts as mock_accounts
from ..output import error, info, success


app = typer.Typer(help="View accounts and balances.", no_args_is_help=True)
console = Console()


@app.command("list")
def list_cmd():
    """
    List all accounts accessible to the authenticated user.

    Returns account IDs, account numbers, types, balances, and status.

    Example:
        islandsbanki accounts list
        islandsbanki accounts list --json
    """
    accounts = mock_accounts.list_accounts()

    if state.json_output:
        success({"accounts": accounts}, command="accounts list")
        return

    if not accounts:
        info("No accounts found.")
        return

    t = Table(title="Your Accounts", box=box.ROUNDED, highlight=True)
    t.add_column("Account", style="cyan")
    t.add_column("Type")
    t.add_column("Currency")
    t.add_column("Name")
    t.add_column("Status")
    t.add_column("ID", style="dim")

    for acc in accounts:
        t.add_row(
            acc.get("accountNumber", acc.get("iban", "—")),
            acc.get("cashAccountType", "—"),
            acc.get("currency", "—"),
            acc.get("name", "—"),
            acc.get("status", "—"),
            acc.get("resourceId", "—"),
        )

    console.print(t)


@app.command("show")
def show(
    account_id: str = typer.Argument(..., help="Account resourceId or account number."),
):
    """
    Show full details for a single account.

    Example:
        islandsbanki accounts show 0515-26-000262
    """
    account = mock_accounts.get_account(account_id)

    if state.json_output:
        success({"account": account}, command="accounts show")
        return

    console.print_json(data=account)


@app.command("balance")
def balance(
    account_id: str = typer.Argument(..., help="Account resourceId or account number."),
):
    """
    Show current balance(s) for an account.

    Returns both closing-booked and interim-available balances when available.

    Example:
        islandsbanki accounts balance 0515-26-000262
        islandsbanki accounts balance 0515-26-000262 --json
    """
    balances = mock_accounts.get_balances(account_id)

    if state.json_output:
        success({"accountId": account_id, "balances": balances}, command="accounts balance")
        return

    t = Table(title=f"Balances — {account_id}", box=box.ROUNDED)
    t.add_column("Type")
    t.add_column("Amount", justify="right", style="bold")
    t.add_column("Currency")
    t.add_column("Date")

    for b in balances:
        amt = b.get("balanceAmount", {})
        t.add_row(
            b.get("balanceType", "—"),
            f"{float(amt.get('amount', 0)):,.2f}",
            amt.get("currency", "ISK"),
            b.get("referenceDate", "—"),
        )

    console.print(t)
