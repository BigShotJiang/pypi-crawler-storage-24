"""
Payments commands: initiate, show, status, authorize, cancel.

Every payment requires Audkenni 2FA confirmation via the Íslandsbanki app.

Flow for `initiate`:
  1. CLI initiates payment
  2. Sends Audkenni push to your device
  3. Waits for your approval
  4. Polls until payment settles (ACCC)

Examples:
    islandsbanki payments initiate --from 0515-26-000262 --to 0101-26-051598 --amount 5000
    islandsbanki payments initiate --from 0515-26-000262 --to "Jón" --amount 2000
    islandsbanki payments status PAY-ABC123
    islandsbanki payments show PAY-ABC123
    islandsbanki payments cancel PAY-ABC123
"""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from .. import state
from ..api.mock import payments as mock_payments
from ..api.mock.approval import request_approval
from ..contacts import resolve_to_account, search_contacts
from ..output import error, info, ok, spinner_msg, success

CREDIT_TRANSFER = "credit-transfers"


def _is_account_number(value: str) -> bool:
    """Check if value looks like an Icelandic bank account (BBBB-HH-NNNNNN)."""
    parts = value.split("-")
    return len(parts) == 3 and all(p.isdigit() for p in parts)


def _resolve_recipient(to_value: str) -> str:
    """Resolve --to value: if it looks like an account number, return as-is; otherwise search contacts."""
    if _is_account_number(to_value):
        return to_value

    contact = resolve_to_account(to_value)
    if contact:
        acct = contact["accountNumber"]
        info(f"Resolved [bold]{to_value}[/bold] → [cyan]{contact['name']}[/cyan] ({acct})")
        return acct

    matches = search_contacts(to_value)
    if not matches:
        error(
            f'No contact found matching "{to_value}". '
            "Use an account number or run: islandsbanki contacts add",
            code="CONTACT_NOT_FOUND",
        )
    names_list = ", ".join(f"{m['name']} ({m['accountNumber']})" for m in matches)
    error(
        f'Multiple contacts match "{to_value}": {names_list}. '
        "Be more specific or use the full account number.",
        code="CONTACT_AMBIGUOUS",
    )


app = typer.Typer(
    help="Initiate and manage payments — requires Audkenni 2FA.",
    no_args_is_help=True,
)
console = Console()


@app.command("initiate")
def initiate(
    from_account: str = typer.Option(
        "0515-26-000262",
        "--from",
        help="Debtor account number (your account). Defaults to your primary ISK account.",
    ),
    to_account: str = typer.Option(..., "--to", help="Creditor account number or contact name."),
    amount: str = typer.Option(..., "--amount", help="Amount in ISK (e.g. 5000)."),
    currency: str = typer.Option("ISK", "--currency", help="Currency code (default: ISK)."),
    reference: Optional[str] = typer.Option(None, "--ref", help="Payment reference / description."),
    product: str = typer.Option(
        CREDIT_TRANSFER,
        "--product",
        help="Payment product: credit-transfers | card-deposits | claim-payments",
    ),
):
    """
    Initiate a bank transfer with Audkenni 2FA confirmation.

    The full flow runs automatically:
      1. Initiates the payment
      2. Sends Audkenni push to your device
      3. Waits for your approval
      4. Polls until payment settles (ACCC)

    Example:
        islandsbanki payments initiate --from 0515-26-000262 --to 0101-26-051598 --amount 5000
        islandsbanki payments initiate --from 0515-26-000262 --to "Jón" --amount 2000
        islandsbanki payments initiate --from 0515-26-000262 --to 0101-26-051598 --amount 10000 --ref "Rent March"
    """
    original_to = to_account
    to_account = _resolve_recipient(to_account)

    info(f"Initiating transfer of {amount} {currency} → {to_account}")

    init_resp = mock_payments.initiate_credit_transfer(
        debtor_account=from_account,
        creditor_account=to_account,
        amount=amount,
        currency=currency,
        reference=reference,
    )
    payment_id = init_resp["paymentId"]
    info(f"Payment ID: [bold]{payment_id}[/bold] — status: {init_resp['transactionStatus']}")

    display_name = original_to if original_to != to_account else to_account

    spinner_msg("Sending Audkenni approval to your device…")
    try:
        approval = request_approval(
            "payment",
            {
                "user_name": "Rúrik",
                "amount": f"{amount} {currency}",
                "from_account": from_account,
                "to_account": to_account,
                "to_name": display_name,
                "reference": reference or "—",
            },
        )
    except RuntimeError as e:
        error(str(e), code="APPROVAL_FAILED")

    if approval["status"] == "rejected":
        mock_payments.cancel_payment(payment_id, product)
        error("Payment rejected by user.", code="PAYMENT_REJECTED")

    ok("Audkenni approved.")
    final_tx = mock_payments.poll_payment_until_final(payment_id, product)

    result = {
        "paymentId": payment_id,
        "transactionStatus": final_tx,
        "debtorAccount": from_account,
        "creditorAccount": to_account,
        "amount": amount,
        "currency": currency,
    }

    if state.json_output:
        success(result, command="payments initiate")
        return

    status_color = "green" if final_tx == "ACCC" else "red"
    ok(f"Payment [{status_color}]{final_tx}[/{status_color}]")

    t = Table(box=box.MINIMAL)
    t.add_column("Field")
    t.add_column("Value")
    for k, v in result.items():
        t.add_row(k, str(v))
    console.print(t)


@app.command("show")
def show(
    payment_id: str = typer.Argument(..., help="Payment ID returned by initiate."),
    product: str = typer.Option(CREDIT_TRANSFER, "--product", help="Payment product type."),
):
    """
    Show full details of a payment.

    Example:
        islandsbanki payments show PAY-ABC123
    """
    payment = mock_payments.get_payment(payment_id, product)

    if state.json_output:
        success({"payment": payment}, command="payments show")
        return

    console.print_json(data=payment)


@app.command("status")
def status(
    payment_id: str = typer.Argument(..., help="Payment ID."),
    product: str = typer.Option(CREDIT_TRANSFER, "--product", help="Payment product type."),
):
    """
    Get the current transaction status of a payment.

    Status codes: RCVD → ACTC → ACFC → ACCC (success) | RJCT (rejected) | CANC

    Example:
        islandsbanki payments status PAY-ABC123
    """
    result = mock_payments.get_payment_status(payment_id, product)

    if state.json_output:
        success({"paymentId": payment_id, **result}, command="payments status")
        return

    tx_status = result.get("transactionStatus", "UNKNOWN")
    color = "green" if tx_status == "ACCC" else "red" if tx_status == "RJCT" else "yellow"
    console.print(f"Payment [bold]{payment_id}[/bold] — status: [{color}]{tx_status}[/{color}]")


@app.command("authorize")
def authorize(
    payment_id: str = typer.Argument(..., help="Payment ID to authorize."),
):
    """
    Trigger Audkenni 2FA authorization for an existing payment.

    Use this when you initiated a payment but need to authorize separately.

    Example:
        islandsbanki payments authorize PAY-ABC123
    """
    spinner_msg("Sending Audkenni approval to your device…")
    try:
        approval = request_approval(
            "sca",
            {
                "user_name": "Rúrik",
                "action": "authorize_payment",
                "payment_id": payment_id,
            },
        )
    except RuntimeError as e:
        error(str(e), code="APPROVAL_FAILED")

    authorized = approval["status"] == "approved"

    if state.json_output:
        success({"paymentId": payment_id, "authorized": authorized}, command="payments authorize")
    elif authorized:
        ok(f"Payment [bold]{payment_id}[/bold] authorized.")
    else:
        error("Authorization rejected by user.", code="AUTH_REJECTED")


@app.command("cancel")
def cancel(
    payment_id: str = typer.Argument(..., help="Payment ID to cancel."),
    product: str = typer.Option(CREDIT_TRANSFER, "--product", help="Payment product type."),
    confirm: bool = typer.Option(False, "--confirm", help="Skip confirmation prompt."),
):
    """
    Cancel a payment that has not yet been authorised.

    Example:
        islandsbanki payments cancel PAY-ABC123 --confirm
    """
    if not confirm and not state.json_output:
        confirmed = typer.confirm(f"Cancel payment {payment_id}?")
        if not confirmed:
            info("Cancellation aborted.")
            raise typer.Exit()

    mock_payments.cancel_payment(payment_id, product)

    if state.json_output:
        success({"paymentId": payment_id, "cancelled": True}, command="payments cancel")
        return

    ok(f"Payment [bold]{payment_id}[/bold] cancelled.")
