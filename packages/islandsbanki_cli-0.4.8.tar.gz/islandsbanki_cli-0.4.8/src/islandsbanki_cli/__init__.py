"""islandsbanki-cli — Open Banking CLI for Íslandsbanki."""

from importlib.metadata import version

__version__ = version("islandsbanki-cli")
__app_name__ = "islandsbanki"
