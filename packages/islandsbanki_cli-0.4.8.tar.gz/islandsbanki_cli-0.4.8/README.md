# Íslandsbanki CLI

[![PyPI](https://img.shields.io/pypi/v/islandsbanki-cli)](https://pypi.org/project/islandsbanki-cli/)
[![Python](https://img.shields.io/pypi/pyversions/islandsbanki-cli)](https://pypi.org/project/islandsbanki-cli/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A command-line interface for the [Íslandsbanki Open Banking API](https://developers.islandsbanki.is), built for AI agents and personal automation tools.

Provides accounts, payments, transactions, cards, profile, FX rates, branch appointments, Fríða loyalty offers, and public web data — all from a single, consistent CLI with Audkenni 2FA authentication.

---

## Usage with AI Agents

The CLI is designed as a tool for AI agent frameworks (Claude, GPT-4o, LangChain, OpenClaw, etc.).

### Retrieving the agent skill file

The package ships a built-in SKILL.md that any agent framework can consume:

```bash
# Print the skill definition to stdout
islandsbanki get-skill

# Save it to a file for your agent
islandsbanki get-skill > SKILL.md
```

This works from any PyPI install — no repo checkout required.

---

## Features

| Category | Commands |
|---|---|
| **Authentication** | `auth login`, `auth logout`, `auth status` |
| **Accounts** | `accounts list`, `accounts show`, `accounts balance` |
| **Payments** | `payments initiate`, `payments show`, `payments status`, `payments authorize`, `payments cancel` |
| **Contacts** | `contacts list`, `contacts search`, `contacts add`, `contacts remove` |
| **Transactions** | `transactions list`, `transactions show` |
| **Cards** | `cards list`, `cards show`, `cards freeze`, `cards unfreeze` |
| **Profile** | `profile show`, `profile addresses`, `profile advisor` |
| **FX Rates** | `fx rates`, `fx convert` |
| **Fríða Loyalty** | `frida list`, `frida today`, `frida limited`, `frida activate`, `frida cashback` |
| **Appointments** | `bank appointments slots/book/list/cancel/ical/topics` |
| **Public info** | `web rates`, `web branches`, `web news`, `web products` |
| **Agent skill** | `get-skill` |

---

## Accounts

The CLI works with Icelandic bank account format (`BBBB-HH-NNNNNN`):

```bash
islandsbanki accounts list
islandsbanki accounts balance 0515-26-000262
```

Your accounts:
- `0515-38-000008` — EUR foreign currency account (gjaldeyrisreikningur)
- `0515-14-000028` — ISK checking account (tékkareikningur)
- `0515-29-000006` — USD foreign currency account (gjaldeyrisreikningur)
- `0515-26-000262` — ISK savings account (sparireikningur)
- `0515-14-000030` — ISK salary account (launareikningur)
- `0515-18-000210` — ISK fixed savings (bundinn sparireikningur)

---

## Icelandic Bank Account Numbers

This CLI uses the native Icelandic bank account format instead of IBANs:

```
BBBB-HH-NNNNNN
│    │   └── Account number
│    └────── Höfuðbók (ledger type: 14=checking, 26=savings, 38=FX, etc.)
└─────────── Bank/branch number
```

Examples:
- `0515-26-000262` — Íslandsbanki (0515), savings (26)
- `0101-26-051598` — Landsbankinn (0101), savings (26)
- `0301-26-078432` — Arion banki (0301), savings (26)

Common bank numbers: Landsbankinn = 01xx, Arion = 03xx, Íslandsbanki = 05xx, Kvika = 07xx, Sparisjóðir = 11xx, Indó = 22xx.

---

## Contacts & Name-Based Payments

The CLI includes a contact registry for name-based transfers. Instead of typing an account number, just use a name:

```bash
# List all contacts (7 contacts are pre-loaded)
islandsbanki contacts list

# Search by name (fuzzy, accent-insensitive)
islandsbanki contacts search "Jón"
islandsbanki contacts search "Gudrun"   # finds Guðrún

# Add a new contact
islandsbanki contacts add --name "Einar Benediktsson" --account 0515-26-009912
islandsbanki contacts add --name "Helga" --account 0101-14-034567 --kt 1505862399 --note "Dentist"

# Pay by name — no account number needed
islandsbanki payments initiate --from 0515-26-000262 --to "Guðrún" --amount 2000
islandsbanki payments initiate --from 0515-26-000262 --to "Jón Guðni" --amount 15000 --ref "Birthday"
```

**Fuzzy matching rules:**
1. Exact full-name match (case/accent insensitive) — highest priority
2. Token overlap — "Jón Guðni" matches "Jón Guðni Ómarsson" with 2 tokens
3. Substring match — "Jón" matches "Jónsson" as a substring (lower priority)

When the query is ambiguous (e.g. two contacts share a first name with equal score), the CLI errors with all candidates so the agent or user can be more specific.

Contacts are stored in `~/.islandsbanki/contacts.json`.

---

## Installation

From PyPI:

```bash
pip install islandsbanki-cli
```

Or from source:

```bash
git clone https://github.com/your-org/islandsbanki-cli
cd islandsbanki-cli
uv sync
```

Requires Python 3.11+.

---

## Quick Start

```bash
# 1. Log in (opens Audkenni 2FA approval on your device)
islandsbanki auth login

# 2. List your accounts
islandsbanki accounts list

# 3. Check a balance
islandsbanki accounts balance 0515-26-000262

# 4. Get FX rates
islandsbanki fx rates --json

# 5. Transfer to a contact by name
islandsbanki payments initiate --from 0515-26-000262 --to "Guðrún" --amount 5000

# 6. Book an advisor meeting
islandsbanki bank appointments topics
islandsbanki bank appointments slots --topic mortgage
islandsbanki bank appointments book SLOT_ID --topic mortgage
```

---

## Authentication

The CLI uses **Audkenni** (Icelandic electronic ID) for authentication. When you run `islandsbanki auth login`, an approval request is sent to your device. Confirm it to establish a session.

Sessions are stored locally in `~/.islandsbanki/.session.json`.

---

## Security Model

- **Every payment requires 2FA**. The CLI triggers an Audkenni Strong Customer Authentication (SCA) approval for every payment — there is no flag to bypass it. This is a deliberate security design.
- **Sessions are stored locally** in the user's config directory (`~/.islandsbanki/`).
- **No credentials are stored in environment variables** — authentication is handled entirely through Audkenni device approval.

---

## JSON Output

All commands support `--json` for machine-readable output. The envelope is consistent:

```json
{
  "success": true,
  "data": { "...": "..." },
  "error": null,
  "meta": {
    "command": "accounts list",
    "timestamp": "2024-01-15T10:30:00Z"
  }
}
```

Exit codes: `0` success · `1` error · `2` login required · `3` SCA pending

---


### Example: scripting with JSON output

```python
import subprocess, json

def isb(cmd: str) -> dict:
    r = subprocess.run(
        f"islandsbanki {cmd} --json",
        shell=True, capture_output=True, text=True
    )
    if r.returncode == 2:
        raise RuntimeError("Auth required: islandsbanki auth login")
    return json.loads(r.stdout)

accounts = isb("accounts list")["data"]["accounts"]
rates    = isb("fx rates")["data"]["rates"]
balance  = isb(f"accounts balance {accounts[0]['resourceId']}")
```

See [docs/COMMANDS.md](docs/COMMANDS.md) for the complete command reference, including all flags, JSON schemas, and example outputs.

### Automatic update notifications

The CLI checks PyPI on every invocation. If a newer version is available you will see:

```
⬆  Update available: 0.1.0 → 0.2.0 — run pip install --upgrade islandsbanki-cli
```

---

## Commands Reference

Full command reference with all flags, JSON schemas, and examples: **[docs/COMMANDS.md](docs/COMMANDS.md)**

---

## Development

```bash
# Clone and install in editable mode
git clone https://github.com/your-org/islandsbanki-cli
cd islandsbanki-cli
uv sync

# Run the CLI
islandsbanki --help

# Lint
ruff check src/
```

### Publishing to PyPI

GitHub Actions runners are not available for this repo, so releases are done locally:

```bash
# Dry run (build + validate only)
./scripts/publish_pypi.sh --dry-run

# Publish
export PYPI_API_TOKEN=pypi-...
./scripts/publish_pypi.sh
```

The script skips the upload if the current version already exists on PyPI. Bump `version` in `pyproject.toml` before publishing a new release.

---

## Project Structure

```
islandsbanki-cli/
├── src/islandsbanki_cli/
│   ├── cli.py               # Root CLI app (typer)
│   ├── config.py            # Configuration (config.toml + env vars)
│   ├── state.py             # Global --json flag
│   ├── output.py            # Consistent JSON/rich output helpers
│   ├── contacts.py          # Contact registry (name → account)
│   ├── skill_data.py        # Embedded SKILL.md for get-skill command
│   ├── version_check.py     # PyPI update check
│   ├── auth/
│   │   └── session.py       # Session management (Audkenni)
│   ├── api/
│   │   └── mock/            # Banking data modules
│   │       ├── accounts.py
│   │       ├── payments.py
│   │       ├── transactions.py
│   │       ├── cards.py
│   │       ├── profile.py
│   │       ├── fx.py
│   │       ├── frida.py
│   │       ├── appointments.py
│   │       ├── approval.py
│   │       └── web_info.py
│   └── commands/            # CLI command modules
│       ├── auth.py
│       ├── accounts.py
│       ├── payments.py
│       ├── contacts.py
│       ├── transactions.py
│       ├── cards.py
│       ├── frida.py
│       ├── profile.py
│       ├── fx.py
│       ├── bank.py
│       └── web.py
├── scripts/
│   └── publish_pypi.sh      # Local PyPI publish script
└── pyproject.toml
```

---

## License

MIT — see [LICENSE](LICENSE).

---

## Disclaimer

This is a **proof of concept** built for the Íslandsbanki Open Banking competition.
It is not an official Íslandsbanki product. Use at your own risk.
