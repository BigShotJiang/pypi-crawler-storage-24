from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / "scripts" / "init_python_cli_template.py"
SRC_DIR = REPO_ROOT / "src"


def load_module():
    if str(SRC_DIR) not in sys.path:
        sys.path.insert(0, str(SRC_DIR))
    spec = importlib.util.spec_from_file_location("mcp_template_cli.cli", SRC_DIR / "mcp_template_cli" / "cli.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


class InitPythonCliTemplateTests(unittest.TestCase):
    def run_cli(self, *args: str, **kwargs: object) -> subprocess.CompletedProcess[str]:
        env = dict(kwargs.pop("env", {}))
        env["PYTHONPATH"] = str(SRC_DIR)
        return subprocess.run([sys.executable, "-m", "mcp_template_cli", *args], env=env, **kwargs)

    def test_slug_helpers_reject_invalid_values(self):
        module = load_module()

        self.assertEqual(module._server_slug("Demo Server"), "demo-server")
        self.assertEqual(module._tool_slug("Run Profile"), "run_profile")
        self.assertEqual(module._env_prefix("demo-server"), "DEMO_SERVER")
        self.assertEqual(module._env_prefix("FACTOR_TOOLS"), "FACTOR_TOOLS")

        with self.assertRaises(ValueError):
            module._server_slug("!!!")

        with self.assertRaises(ValueError):
            module._tool_slug("123-run")

        with self.assertRaises(ValueError):
            module._env_prefix("!!!")

        with self.assertRaises(ValueError):
            module._env_prefix("123_TOOLS")

    def test_copy_template_ignores_python_cache_files(self):
        module = load_module()

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            template_dir = tmp_path / "template"
            template_dir.mkdir()
            (template_dir / "server.py").write_text("print('ok')\n", encoding="utf-8")
            (template_dir / "__pycache__").mkdir()
            (template_dir / "__pycache__" / "server.pyc").write_bytes(b"compiled")
            (template_dir / "ignored.pyc").write_bytes(b"compiled")
            (template_dir / ".DS_Store").write_text("noise", encoding="utf-8")

            module.TEMPLATE_DIR = template_dir
            dest = tmp_path / "out"
            module._copy_template(dest)

            self.assertTrue((dest / "server.py").exists())
            self.assertFalse((dest / "__pycache__").exists())
            self.assertFalse((dest / "ignored.pyc").exists())
            self.assertFalse((dest / ".DS_Store").exists())

    def test_packaged_assets_exist(self):
        module = load_module()

        self.assertTrue((module.BUNDLED_DATA_DIR / "python-cli-template" / "server.py").exists())
        self.assertTrue((module.BUNDLED_DATA_DIR / "python-cli-template" / "doctor.py").exists())
        self.assertTrue((module.BUNDLED_DATA_DIR / "examples" / "claude_desktop_config.sample.json").exists())

    def test_bootstrap_script_rewrites_template_files(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            dest = Path(tmp_dir) / "generated-template"
            result = self.run_cli(
                "generate",
                str(dest),
                "--server-name",
                "Demo Server",
                "--tool-name",
                "run_profile",
                "--binary-name",
                "demo-cli",
                capture_output=True,
                text=True,
                check=True,
            )

            server_text = (dest / "server.py").read_text(encoding="utf-8")
            doctor_text = (dest / "doctor.py").read_text(encoding="utf-8")
            dockerfile_text = (dest / "Dockerfile").read_text(encoding="utf-8")
            gitignore_text = (dest / ".gitignore").read_text(encoding="utf-8")
            makefile_text = (dest / "Makefile").read_text(encoding="utf-8")
            requirements_text = (dest / "requirements.txt").read_text(encoding="utf-8")
            sample_input_text = (dest / "sample-input.txt").read_text(encoding="utf-8")
            sample_output_readme = (dest / "sample-output" / "README.txt").read_text(encoding="utf-8")
            env_example_text = (dest / ".env.example").read_text(encoding="utf-8")
            usage_text = (dest / "USAGE.md").read_text(encoding="utf-8")
            claude_desktop_text = (dest / "examples" / "claude_desktop_config.sample.json").read_text(
                encoding="utf-8"
            )
            claude_code_text = (dest / "examples" / "claude_code_mcp.sample.json").read_text(
                encoding="utf-8"
            )

            self.assertIn("Created template at", result.stdout)
            self.assertIn("server name: demo-server", result.stdout)
            self.assertIn("bin path: /ABS/PATH/TO/demo-cli", result.stdout)
            self.assertIn(f"python path: {sys.executable}", result.stdout)
            self.assertIn("read dirs: /ABS/PATH/TO/data,/ABS/PATH/TO/profiles,/ABS/PATH/TO/artifacts", result.stdout)
            self.assertIn("write dirs: /ABS/PATH/TO/artifacts", result.stdout)
            self.assertIn('FastMCP("demo-server")', server_text)
            self.assertIn("def version()", server_text)
            self.assertIn("def paths()", server_text)
            self.assertIn('TEMPLATE_VERSION = "2026.03.12"', server_text)
            self.assertIn("def run_profile(", server_text)
            self.assertIn("DEMO_SERVER_ALLOWED_READ_DIRS", server_text)
            self.assertIn("DEMO_SERVER_ALLOWED_WRITE_DIRS", server_text)
            self.assertIn("DEMO_SERVER_CMD_TIMEOUT_SEC", server_text)
            self.assertIn("DEMO_SERVER_BIN", server_text)
            self.assertIn("demo-cli", server_text)
            self.assertNotIn("project-template", server_text)
            self.assertNotIn("run_example", server_text)
            self.assertNotIn("PROJECT_BIN", doctor_text)
            self.assertIn("DEMO_SERVER_BIN", doctor_text)
            self.assertIn("demo-cli", dockerfile_text)
            self.assertIn('"demo-server"', claude_desktop_text)
            self.assertIn('"DEMO_SERVER_BIN"', claude_desktop_text)
            self.assertIn('"demo-server"', claude_code_text)
            self.assertIn('"DEMO_SERVER_ALLOWED_READ_DIRS"', claude_code_text)
            self.assertIn(str(dest / "server.py"), claude_desktop_text)
            self.assertIn(sys.executable, claude_desktop_text)
            self.assertIn("DEMO_SERVER_BIN=/ABS/PATH/TO/demo-cli", env_example_text)
            self.assertIn("DEMO_SERVER_ALLOWED_READ_DIRS=", env_example_text)
            self.assertIn("DEMO_SERVER_ALLOWED_WRITE_DIRS=", env_example_text)
            self.assertIn("DEMO_SERVER_CMD_TIMEOUT_SEC=180", env_example_text)
            self.assertIn("__pycache__/", gitignore_text)
            self.assertIn(".venv/", gitignore_text)
            self.assertIn(".env", gitignore_text)
            self.assertIn("install:", makefile_text)
            self.assertIn("doctor:", makefile_text)
            self.assertIn("run:", makefile_text)
            self.assertEqual(requirements_text, "mcp\n")
            self.assertIn("Replace this file with a real input", sample_input_text)
            self.assertIn("local wrapper output", sample_output_readme)
            self.assertIn("# demo-server MCP Wrapper", usage_text)
            self.assertIn("run_profile", usage_text)
            self.assertIn("DEMO_SERVER_BIN", usage_text)
            self.assertIn("version", usage_text)
            self.assertIn("healthcheck", usage_text)
            self.assertTrue((dest / "bin" / "demo-cli").exists())
            self.assertFalse((dest / "bin" / "project-cli").exists())

    def test_bootstrap_script_allows_env_prefix_override(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            dest = Path(tmp_dir) / "generated-template"
            self.run_cli(
                "generate",
                str(dest),
                "--server-name",
                "Demo Server",
                "--tool-name",
                "run_profile",
                "--binary-name",
                "demo-cli",
                "--env-prefix",
                "CUSTOM_TOOLS",
                capture_output=True,
                text=True,
                check=True,
            )

            server_text = (dest / "server.py").read_text(encoding="utf-8")
            env_example_text = (dest / ".env.example").read_text(encoding="utf-8")

            self.assertIn("CUSTOM_TOOLS_BIN", server_text)
            self.assertIn("CUSTOM_TOOLS_ALLOWED_READ_DIRS", server_text)
            self.assertIn("CUSTOM_TOOLS_BIN=/ABS/PATH/TO/demo-cli", env_example_text)

    def test_bootstrap_script_prefills_bin_path(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            dest = Path(tmp_dir) / "generated-template"
            self.run_cli(
                "generate",
                str(dest),
                "--server-name",
                "Demo Server",
                "--tool-name",
                "run_profile",
                "--binary-name",
                "demo-cli",
                "--bin-path",
                "/usr/local/bin/demo-cli",
                capture_output=True,
                text=True,
                check=True,
            )

            env_example_text = (dest / ".env.example").read_text(encoding="utf-8")
            claude_desktop_text = (dest / "examples" / "claude_desktop_config.sample.json").read_text(
                encoding="utf-8"
            )

            self.assertIn("DEMO_SERVER_BIN=/usr/local/bin/demo-cli", env_example_text)
            self.assertIn('"/usr/local/bin/demo-cli"', claude_desktop_text)

    def test_bootstrap_script_prefills_allowed_dirs(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            dest = Path(tmp_dir) / "generated-template"
            self.run_cli(
                "generate",
                str(dest),
                "--server-name",
                "Demo Server",
                "--tool-name",
                "run_profile",
                "--read-dirs",
                "/data,/profiles",
                "--write-dirs",
                "/artifacts",
                capture_output=True,
                text=True,
                check=True,
            )

            env_example_text = (dest / ".env.example").read_text(encoding="utf-8")
            claude_desktop_text = (dest / "examples" / "claude_desktop_config.sample.json").read_text(
                encoding="utf-8"
            )

            self.assertIn("DEMO_SERVER_ALLOWED_READ_DIRS=/data,/profiles", env_example_text)
            self.assertIn("DEMO_SERVER_ALLOWED_WRITE_DIRS=/artifacts", env_example_text)
            self.assertIn('"/data,/profiles"', claude_desktop_text)
            self.assertIn('"/artifacts"', claude_desktop_text)

    def test_bootstrap_script_prefills_python_path(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            dest = Path(tmp_dir) / "generated-template"
            self.run_cli(
                "generate",
                str(dest),
                "--server-name",
                "Demo Server",
                "--tool-name",
                "run_profile",
                "--python-path",
                "/opt/custom/python",
                capture_output=True,
                text=True,
                check=True,
            )

            claude_desktop_text = (dest / "examples" / "claude_desktop_config.sample.json").read_text(
                encoding="utf-8"
            )

            self.assertIn('"/opt/custom/python"', claude_desktop_text)

    def test_bootstrap_script_fails_when_destination_exists(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            dest = Path(tmp_dir) / "generated-template"
            dest.mkdir()

            result = self.run_cli(
                "generate",
                str(dest),
                "--server-name",
                "Demo Server",
                capture_output=True,
                text=True,
                check=False,
            )

            self.assertNotEqual(result.returncode, 0)
            self.assertIn("destination already exists", result.stderr)

    def test_bootstrap_script_dry_run_does_not_create_files(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            dest = Path(tmp_dir) / "generated-template"

            result = self.run_cli(
                "generate",
                str(dest),
                "--server-name",
                "Demo Server",
                "--tool-name",
                "run_profile",
                "--binary-name",
                "demo-cli",
                "--dry-run",
                capture_output=True,
                text=True,
                check=True,
            )

            self.assertFalse(dest.exists())
            self.assertIn("Dry run only. No files were written.", result.stdout)
            self.assertIn("bin path: /ABS/PATH/TO/demo-cli", result.stdout)
            self.assertIn(f"python path: {sys.executable}", result.stdout)
            self.assertIn("read dirs: /ABS/PATH/TO/data,/ABS/PATH/TO/profiles,/ABS/PATH/TO/artifacts", result.stdout)
            self.assertIn("write dirs: /ABS/PATH/TO/artifacts", result.stdout)
            self.assertIn(str(dest / "Makefile"), result.stdout)
            self.assertIn(str(dest / "requirements.txt"), result.stdout)
            self.assertIn(str(dest / "sample-input.txt"), result.stdout)
            self.assertIn(str(dest / "sample-output" / "README.txt"), result.stdout)
            self.assertIn(str(dest / ".gitignore"), result.stdout)
            self.assertIn(str(dest / "USAGE.md"), result.stdout)
            self.assertIn(str(dest / "bin" / "demo-cli"), result.stdout)

    def test_legacy_script_shim_still_works(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            dest = Path(tmp_dir) / "generated-template"

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT_PATH),
                    "generate",
                    str(dest),
                    "--server-name",
                    "Demo Server",
                ],
                capture_output=True,
                text=True,
                check=True,
            )

            self.assertIn("Created template at", result.stdout)
            self.assertTrue((dest / "server.py").exists())

    def test_list_templates_reports_python_template(self):
        result = self.run_cli(
            "list-templates",
            capture_output=True,
            text=True,
            check=True,
        )

        self.assertIn("python-cli", result.stdout)
        self.assertIn("Production-style Python MCP wrapper", result.stdout)

    def test_version_flag_reports_package_version(self):
        result = self.run_cli(
            "--version",
            capture_output=True,
            text=True,
            check=True,
        )

        self.assertIn("mcp-template 0.1.0", result.stdout)


if __name__ == "__main__":
    unittest.main()
