"""Public package for the mcp-template command."""

__version__ = "0.1.0"
