from __future__ import annotations

import argparse
import re
import shutil
import sys
from pathlib import Path

from mcp_template_cli import __version__

ROOT = Path(__file__).resolve().parents[2]
PACKAGE_ROOT = Path(__file__).resolve().parent
BUNDLED_DATA_DIR = PACKAGE_ROOT / "data"
IGNORED_NAMES = {"__pycache__", ".DS_Store"}


def _resolve_template_dir() -> Path:
    source_template_dir = ROOT / "python-cli-template"
    if source_template_dir.exists():
        return source_template_dir
    return BUNDLED_DATA_DIR / "python-cli-template"


def _resolve_examples_dir() -> Path:
    source_examples_dir = ROOT / "examples"
    if source_examples_dir.exists():
        return source_examples_dir
    return BUNDLED_DATA_DIR / "examples"


TEMPLATE_DIR = _resolve_template_dir()
EXAMPLES_DIR = _resolve_examples_dir()


def _server_slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.strip().lower()).strip("-")
    if not slug:
        raise ValueError("server name must include at least one letter or number")
    return slug


def _tool_slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", value.strip().lower()).strip("_")
    if not slug:
        raise ValueError("tool name must include at least one letter or number")
    if slug[0].isdigit():
        raise ValueError("tool name must start with a letter")
    return slug


def _env_prefix(value: str) -> str:
    prefix = re.sub(r"[^A-Z0-9]+", "_", value.upper()).strip("_")
    if not prefix:
        raise ValueError("env prefix must include at least one letter or number")
    if prefix[0].isdigit():
        raise ValueError("env prefix must start with a letter")
    return prefix


def _copy_template(dest: Path) -> None:
    def ignore(_dir: str, names: list[str]) -> set[str]:
        ignored = {name for name in names if name in IGNORED_NAMES}
        ignored.update(name for name in names if name.endswith((".pyc", ".pyo")))
        return ignored

    shutil.copytree(TEMPLATE_DIR, dest, ignore=ignore)


def _replace_in_file(path: Path, replacements: list[tuple[str, str]]) -> None:
    content = path.read_text(encoding="utf-8")
    for old, new in replacements:
        content = content.replace(old, new)
    path.write_text(content, encoding="utf-8")


def _write_sample_configs(
    dest: Path,
    replacements: list[tuple[str, str]],
    bin_path: str,
    python_path: str,
    read_dirs: str,
    write_dirs: str,
) -> None:
    sample_dir = dest / "examples"
    sample_dir.mkdir(parents=True, exist_ok=True)
    config_replacements = list(replacements)
    config_replacements.extend(
        [
            ("/ABS/PATH/TO/.venv/bin/python", python_path),
            ("/ABS/PATH/TO/server.py", str((dest / "server.py").resolve())),
            ("/ABS/PATH/TO/your_binary", bin_path),
            ("/ABS/PATH/TO/data,/ABS/PATH/TO/profiles,/ABS/PATH/TO/artifacts", read_dirs),
            ("/ABS/PATH/TO/artifacts", write_dirs),
        ]
    )
    for name in ("claude_desktop_config.sample.json", "claude_code_mcp.sample.json"):
        source = EXAMPLES_DIR / name
        target = sample_dir / name
        shutil.copy2(source, target)
        _replace_in_file(target, config_replacements)


def _write_env_example(dest: Path, env_prefix: str, bin_path: str, read_dirs: str, write_dirs: str) -> None:
    env_example = dest / ".env.example"
    env_example.write_text(
        "\n".join(
            [
                f"{env_prefix}_BIN={bin_path}",
                f"{env_prefix}_ALLOWED_READ_DIRS={read_dirs}",
                f"{env_prefix}_ALLOWED_WRITE_DIRS={write_dirs}",
                f"{env_prefix}_CMD_TIMEOUT_SEC=180",
                "",
            ]
        ),
        encoding="utf-8",
    )


def _write_gitignore(dest: Path) -> None:
    gitignore = dest / ".gitignore"
    gitignore.write_text(
        "\n".join(
            [
                "__pycache__/",
                "*.py[cod]",
                ".venv/",
                ".env",
                "",
            ]
        ),
        encoding="utf-8",
    )


def _write_requirements(dest: Path) -> None:
    requirements = dest / "requirements.txt"
    requirements.write_text("mcp\n", encoding="utf-8")


def _write_sample_files(dest: Path) -> None:
    sample_input = dest / "sample-input.txt"
    sample_input.write_text("Replace this file with a real input for your CLI.\n", encoding="utf-8")
    sample_output_dir = dest / "sample-output"
    sample_output_dir.mkdir(exist_ok=True)
    readme = sample_output_dir / "README.txt"
    readme.write_text("Use this directory for local wrapper output during setup.\n", encoding="utf-8")


def _write_makefile(dest: Path) -> None:
    makefile = dest / "Makefile"
    makefile.write_text(
        "\n".join(
            [
                "PYTHON ?= python3",
                "",
                ".PHONY: install doctor run",
                "",
                "install:",
                "\t$(PYTHON) -m pip install -r requirements.txt",
                "",
                "doctor:",
                "\t$(PYTHON) doctor.py --server server.py",
                "",
                "run:",
                "\t$(PYTHON) server.py",
                "",
            ]
        ),
        encoding="utf-8",
    )


def _write_usage_guide(dest: Path, server_name: str, tool_name: str, env_prefix: str) -> None:
    usage = dest / "USAGE.md"
    usage.write_text(
        "\n".join(
            [
                f"# {server_name} MCP Wrapper",
                "",
                "## First Run",
                "",
                "1. Replace the stub binary in `bin/` with your real executable.",
                f"2. Update the command mapping inside `{dest / 'server.py'}`.",
                "3. Fill in `.env.example` with your real paths and copy those values into your runtime environment.",
                "4. Adapt one of the sample client configs in `examples/`.",
                f"5. Run `python {dest / 'doctor.py'} --server {dest / 'server.py'}`.",
                f"6. Call `{tool_name}` only after `version` and `healthcheck` both succeed.",
                "",
                "## Runtime Variables",
                "",
                f"- `{env_prefix}_BIN`",
                f"- `{env_prefix}_ALLOWED_READ_DIRS`",
                f"- `{env_prefix}_ALLOWED_WRITE_DIRS`",
                f"- `{env_prefix}_CMD_TIMEOUT_SEC`",
                "",
                "## Generated Files",
                "",
                "- `server.py`: MCP wrapper entrypoint",
                "- `doctor.py`: preflight checks",
                "- `.gitignore`: starter ignores for local Python/runtime files",
                "- `Makefile`: common wrapper commands",
                "- `requirements.txt`: starter Python dependency file",
                "- `sample-input.txt`: placeholder input for first local tests",
                "- `sample-output/`: placeholder output directory",
                "- `.env.example`: runtime env template",
                "- `examples/`: sample client configs",
                "- `bin/`: CLI binary location",
                "",
            ]
        ),
        encoding="utf-8",
    )


def _print_dry_run(
    dest: Path,
    server_name: str,
    tool_name: str,
    binary_name: str,
    env_prefix: str,
    bin_path: str,
    python_path: str,
    read_dirs: str,
    write_dirs: str,
) -> None:
    print("Dry run only. No files were written.")
    print(f"destination: {dest}")
    print(f"server name: {server_name}")
    print(f"tool name: {tool_name}")
    print(f"binary name: {binary_name}")
    print(f"env prefix: {env_prefix}")
    print(f"bin path: {bin_path}")
    print(f"python path: {python_path}")
    print(f"read dirs: {read_dirs}")
    print(f"write dirs: {write_dirs}")
    print("Files that would be created:")
    for path in (
        dest / "server.py",
        dest / "doctor.py",
        dest / "Dockerfile",
        dest / ".gitignore",
        dest / "Makefile",
        dest / "requirements.txt",
        dest / "sample-input.txt",
        dest / "sample-output" / "README.txt",
        dest / ".env.example",
        dest / "USAGE.md",
        dest / "examples" / "claude_desktop_config.sample.json",
        dest / "examples" / "claude_code_mcp.sample.json",
        dest / "bin" / binary_name,
    ):
        print(f"- {path}")


def generate_template(args: argparse.Namespace) -> int:
    server_name = _server_slug(args.server_name)
    tool_name = _tool_slug(args.tool_name)
    binary_name = _server_slug(args.binary_name or server_name)
    env_prefix = _env_prefix(args.env_prefix or server_name)
    bin_path = str(Path(args.bin_path).expanduser().resolve()) if args.bin_path else f"/ABS/PATH/TO/{binary_name}"
    python_path = str(Path(args.python_path).expanduser().resolve()) if args.python_path else sys.executable
    read_dirs = args.read_dirs or "/ABS/PATH/TO/data,/ABS/PATH/TO/profiles,/ABS/PATH/TO/artifacts"
    write_dirs = args.write_dirs or "/ABS/PATH/TO/artifacts"
    dest = args.dest.expanduser().resolve()

    if dest.exists():
        raise SystemExit(f"destination already exists: {dest}")

    if args.dry_run:
        _print_dry_run(
            dest,
            server_name,
            tool_name,
            binary_name,
            env_prefix,
            bin_path,
            python_path,
            read_dirs,
            write_dirs,
        )
        return 0

    _copy_template(dest)

    replacements = [
        ("project-template", server_name),
        ("PROJECT_ALLOWED_READ_DIRS", f"{env_prefix}_ALLOWED_READ_DIRS"),
        ("PROJECT_ALLOWED_WRITE_DIRS", f"{env_prefix}_ALLOWED_WRITE_DIRS"),
        ("PROJECT_CMD_TIMEOUT_SEC", f"{env_prefix}_CMD_TIMEOUT_SEC"),
        ("PROJECT_BIN", f"{env_prefix}_BIN"),
        ("project-cli", binary_name),
        ("def run_example(", f"def {tool_name}("),
    ]

    _replace_in_file(dest / "server.py", replacements)
    _replace_in_file(dest / "doctor.py", replacements)
    _replace_in_file(dest / "Dockerfile", replacements)
    _write_gitignore(dest)
    _write_makefile(dest)
    _write_requirements(dest)
    _write_sample_files(dest)
    _write_sample_configs(dest, replacements, bin_path, python_path, read_dirs, write_dirs)
    _write_env_example(dest, env_prefix, bin_path, read_dirs, write_dirs)
    _write_usage_guide(dest, server_name, tool_name, env_prefix)

    source_stub = dest / "bin" / "project-cli"
    target_stub = dest / "bin" / binary_name
    source_stub.rename(target_stub)

    print(f"Created template at {dest}")
    print(f"server name: {server_name}")
    print(f"tool name: {tool_name}")
    print(f"binary name: {binary_name}")
    print(f"env prefix: {env_prefix}")
    print(f"bin path: {bin_path}")
    print(f"python path: {python_path}")
    print(f"read dirs: {read_dirs}")
    print(f"write dirs: {write_dirs}")
    print("Next: update the command mapping in server.py, replace the stub binary in bin/,")
    print("adapt the sample client config in examples/, fill in .env.example, and follow USAGE.md.")
    return 0


def list_templates(_args: argparse.Namespace) -> int:
    print("python-cli")
    print(f"template dir: {TEMPLATE_DIR}")
    print("description: Production-style Python MCP wrapper for existing CLIs.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mcp-template",
        description="Generate and inspect starter templates for wrapping existing CLIs as MCP servers.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    generate_parser = subparsers.add_parser(
        "generate",
        help="Generate a project-specific MCP wrapper from a template.",
    )
    generate_parser.add_argument("dest", type=Path, help="Destination directory for the generated template.")
    generate_parser.add_argument(
        "--server-name",
        required=True,
        help="MCP server name. Example: factor-tools",
    )
    generate_parser.add_argument(
        "--tool-name",
        default="run_example",
        help="Primary example tool function name. Example: run_profile",
    )
    generate_parser.add_argument(
        "--binary-name",
        help="CLI binary name or fallback executable. Defaults to the server name.",
    )
    generate_parser.add_argument(
        "--env-prefix",
        help="Override the generated env var prefix. Example: FACTOR_TOOLS",
    )
    generate_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate inputs and print what would be generated without writing files.",
    )
    generate_parser.add_argument(
        "--bin-path",
        help="Prefill the generated env/config files with the real executable path.",
    )
    generate_parser.add_argument(
        "--python-path",
        help="Prefill generated client configs with a specific Python interpreter path.",
    )
    generate_parser.add_argument(
        "--read-dirs",
        help="Prefill allowed read directories as a comma-separated list.",
    )
    generate_parser.add_argument(
        "--write-dirs",
        help="Prefill allowed write directories as a comma-separated list.",
    )
    generate_parser.set_defaults(func=generate_template)

    list_parser = subparsers.add_parser(
        "list-templates",
        help="Show the templates currently available in this repo.",
    )
    list_parser.set_defaults(func=list_templates)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
