"""Allow running via `python -m distromate_cli`."""

from . import main

if __name__ == "__main__":
    main()
