class ParserError(RuntimeError):
    pass
