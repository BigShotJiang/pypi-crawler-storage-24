# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class RemoteConsole:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'protocol': 'str',
        'type': 'str'
    }

    attribute_map = {
        'protocol': 'protocol',
        'type': 'type'
    }

    def __init__(self, protocol=None, type=None):
        r"""RemoteConsole

        The model defined in huaweicloud sdk

        :param protocol: 远程登录的协议。
        :type protocol: str
        :param type: 远程登录的类型。
        :type type: str
        """
        
        

        self._protocol = None
        self._type = None
        self.discriminator = None

        self.protocol = protocol
        self.type = type

    @property
    def protocol(self):
        r"""Gets the protocol of this RemoteConsole.

        远程登录的协议。

        :return: The protocol of this RemoteConsole.
        :rtype: str
        """
        return self._protocol

    @protocol.setter
    def protocol(self, protocol):
        r"""Sets the protocol of this RemoteConsole.

        远程登录的协议。

        :param protocol: The protocol of this RemoteConsole.
        :type protocol: str
        """
        self._protocol = protocol

    @property
    def type(self):
        r"""Gets the type of this RemoteConsole.

        远程登录的类型。

        :return: The type of this RemoteConsole.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this RemoteConsole.

        远程登录的类型。

        :param type: The type of this RemoteConsole.
        :type type: str
        """
        self._type = type

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, RemoteConsole):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
