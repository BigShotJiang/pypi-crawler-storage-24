# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ModifyVmNicRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'nic_id': 'str',
        'body': 'BareMetalModifyPortRequestBody'
    }

    attribute_map = {
        'nic_id': 'nic_id',
        'body': 'body'
    }

    def __init__(self, nic_id=None, body=None):
        r"""ModifyVmNicRequest

        The model defined in huaweicloud sdk

        :param nic_id: 
        :type nic_id: str
        :param body: Body of the ModifyVmNicRequest
        :type body: :class:`huaweicloudsdkbms.v1.BareMetalModifyPortRequestBody`
        """
        
        

        self._nic_id = None
        self._body = None
        self.discriminator = None

        self.nic_id = nic_id
        if body is not None:
            self.body = body

    @property
    def nic_id(self):
        r"""Gets the nic_id of this ModifyVmNicRequest.

        :return: The nic_id of this ModifyVmNicRequest.
        :rtype: str
        """
        return self._nic_id

    @nic_id.setter
    def nic_id(self, nic_id):
        r"""Sets the nic_id of this ModifyVmNicRequest.

        :param nic_id: The nic_id of this ModifyVmNicRequest.
        :type nic_id: str
        """
        self._nic_id = nic_id

    @property
    def body(self):
        r"""Gets the body of this ModifyVmNicRequest.

        :return: The body of this ModifyVmNicRequest.
        :rtype: :class:`huaweicloudsdkbms.v1.BareMetalModifyPortRequestBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this ModifyVmNicRequest.

        :param body: The body of this ModifyVmNicRequest.
        :type body: :class:`huaweicloudsdkbms.v1.BareMetalModifyPortRequestBody`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ModifyVmNicRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
