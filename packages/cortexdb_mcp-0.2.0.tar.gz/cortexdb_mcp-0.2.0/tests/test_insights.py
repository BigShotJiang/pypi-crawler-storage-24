"""Tests for the CortexDB proactive insights engine.

Each insight type is tested with mock episode data.  The REST API caching
behaviour is verified without requiring a live CortexDB instance.
"""

from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock, patch

import pytest

from cortexdb_mcp.insights import (
    Insight,
    InsightType,
    InsightsEngine,
    Severity,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now() -> datetime:
    return datetime.now(timezone.utc)


def _episode(
    episode_id: str,
    episode_type: str,
    entities: list[str],
    content: str = "",
    timestamp: datetime | None = None,
) -> dict:
    """Build a minimal episode dict for testing."""
    return {
        "episode_id": episode_id,
        "episode_type": episode_type,
        "entities": entities,
        "content": content,
        "timestamp": (timestamp or _now()).isoformat(),
    }


# ---------------------------------------------------------------------------
# InsightType and Insight dataclass
# ---------------------------------------------------------------------------


class TestInsightModel:
    """Basic model sanity checks."""

    def test_insight_types(self):
        assert InsightType.incident_spike.value == "incident_spike"
        assert InsightType.knowledge_gap.value == "knowledge_gap"
        assert InsightType.new_dependency.value == "new_dependency"

    def test_insight_to_dict(self):
        now = _now()
        insight = Insight(
            id="ins_abc",
            insight_type=InsightType.incident_spike,
            title="Spike",
            description="desc",
            severity=Severity.warning,
            entities=["svc-a"],
            evidence=["ep_1"],
            generated_at=now,
            confidence=0.9,
        )
        d = insight.to_dict()
        assert d["id"] == "ins_abc"
        assert d["insight_type"] == "incident_spike"
        assert d["severity"] == "warning"
        assert d["entities"] == ["svc-a"]
        assert d["confidence"] == 0.9


# ---------------------------------------------------------------------------
# Incident spike detection
# ---------------------------------------------------------------------------


class TestIncidentSpikeDetection:
    """Tests for InsightsEngine.incident_spike_detection."""

    @pytest.mark.asyncio
    async def test_spike_detected(self):
        """A service with incidents this week but none last week triggers a spike."""
        now = _now()
        episodes = [
            _episode("e1", "incident", ["payments-service"], timestamp=now - timedelta(hours=1)),
            _episode("e2", "incident", ["payments-service"], timestamp=now - timedelta(hours=5)),
            _episode("e3", "incident", ["payments-service"], timestamp=now - timedelta(hours=12)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.incident_spike_detection()

        assert len(insights) == 1
        assert insights[0].insight_type == InsightType.incident_spike
        assert "payments-service" in insights[0].title
        assert insights[0].severity == Severity.critical  # 3 incidents, 0 last week
        assert insights[0].confidence > 0

    @pytest.mark.asyncio
    async def test_no_spike_when_fewer_than_last_week(self):
        """No insight generated when this week has fewer incidents than last."""
        now = _now()
        episodes = [
            _episode("e1", "incident", ["svc-a"], timestamp=now - timedelta(hours=1)),
            # Last week had more.
            _episode("e2", "incident", ["svc-a"], timestamp=now - timedelta(days=9)),
            _episode("e3", "incident", ["svc-a"], timestamp=now - timedelta(days=10)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.incident_spike_detection()

        assert len(insights) == 0

    @pytest.mark.asyncio
    async def test_no_incidents_at_all(self):
        """No insights when there are no incident episodes."""
        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=[])):
            insights = await engine.incident_spike_detection()

        assert insights == []


# ---------------------------------------------------------------------------
# New dependency detection
# ---------------------------------------------------------------------------


class TestNewDependencyDetection:
    """Tests for InsightsEngine.new_dependency_detection."""

    @pytest.mark.asyncio
    async def test_new_pair_detected(self):
        """A co-occurrence pair seen only in the last 7 days is flagged."""
        now = _now()
        episodes = [
            _episode("e1", "api_call", ["checkout", "stripe-gateway-v2"], timestamp=now - timedelta(days=2)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.new_dependency_detection()

        assert len(insights) == 1
        assert insights[0].insight_type == InsightType.new_dependency
        assert "checkout" in insights[0].title
        assert "stripe-gateway-v2" in insights[0].title

    @pytest.mark.asyncio
    async def test_old_pair_not_flagged(self):
        """A pair that appeared before the recent window is not flagged."""
        now = _now()
        episodes = [
            # Old occurrence.
            _episode("e1", "api_call", ["svc-a", "svc-b"], timestamp=now - timedelta(days=30)),
            # Recent occurrence of the same pair.
            _episode("e2", "api_call", ["svc-a", "svc-b"], timestamp=now - timedelta(days=1)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.new_dependency_detection()

        assert len(insights) == 0


# ---------------------------------------------------------------------------
# Knowledge gap detection
# ---------------------------------------------------------------------------


class TestKnowledgeGapDetection:
    """Tests for InsightsEngine.knowledge_gap_detection."""

    @pytest.mark.asyncio
    async def test_gap_detected(self):
        """Service with incidents but no docs triggers a gap."""
        now = _now()
        episodes = [
            _episode("e1", "incident", ["billing-reconciliation"], timestamp=now - timedelta(days=1)),
            _episode("e2", "incident", ["billing-reconciliation"], timestamp=now - timedelta(days=3)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.knowledge_gap_detection()

        assert len(insights) == 1
        assert insights[0].insight_type == InsightType.knowledge_gap
        assert "billing-reconciliation" in insights[0].description

    @pytest.mark.asyncio
    async def test_no_gap_when_documented(self):
        """Service with both incidents and docs does not trigger a gap."""
        now = _now()
        episodes = [
            _episode("e1", "incident", ["svc-a"], timestamp=now - timedelta(days=1)),
            _episode("e2", "incident", ["svc-a"], timestamp=now - timedelta(days=3)),
            _episode("e3", "document", ["svc-a"], timestamp=now - timedelta(days=5)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.knowledge_gap_detection()

        assert len(insights) == 0


# ---------------------------------------------------------------------------
# Deployment risk assessment
# ---------------------------------------------------------------------------


class TestDeploymentRiskAssessment:
    """Tests for InsightsEngine.deployment_risk_assessment."""

    @pytest.mark.asyncio
    async def test_risk_detected(self):
        """Service with recent deploy and incident is flagged."""
        now = _now()
        episodes = [
            _episode("e1", "deploy", ["auth-service"], timestamp=now - timedelta(hours=6)),
            _episode("e2", "incident", ["auth-service"], timestamp=now - timedelta(hours=2)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.deployment_risk_assessment()

        assert len(insights) == 1
        assert insights[0].insight_type == InsightType.deployment_risk
        assert "auth-service" in insights[0].title

    @pytest.mark.asyncio
    async def test_no_risk_without_incident(self):
        """Deploy alone without incidents does not trigger."""
        now = _now()
        episodes = [
            _episode("e1", "deploy", ["auth-service"], timestamp=now - timedelta(hours=6)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.deployment_risk_assessment()

        assert len(insights) == 0


# ---------------------------------------------------------------------------
# Stale documentation detection
# ---------------------------------------------------------------------------


class TestStaleDocumentationDetection:
    """Tests for InsightsEngine.stale_documentation_detection."""

    @pytest.mark.asyncio
    async def test_stale_docs_detected(self):
        """Active service with docs older than 90 days is flagged."""
        now = _now()
        episodes = [
            # Active recently.
            _episode("e1", "incident", ["order-service"], timestamp=now - timedelta(days=2)),
            # Docs are old.
            _episode("e2", "document", ["order-service"], timestamp=now - timedelta(days=120)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.stale_documentation_detection()

        assert len(insights) == 1
        assert insights[0].insight_type == InsightType.stale_documentation
        assert "order-service" in insights[0].title

    @pytest.mark.asyncio
    async def test_fresh_docs_not_flagged(self):
        """Active service with recent docs is not flagged."""
        now = _now()
        episodes = [
            _episode("e1", "incident", ["svc-a"], timestamp=now - timedelta(days=2)),
            _episode("e2", "document", ["svc-a"], timestamp=now - timedelta(days=10)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.stale_documentation_detection()

        assert len(insights) == 0


# ---------------------------------------------------------------------------
# Recurring issue detection
# ---------------------------------------------------------------------------


class TestRecurringIssueDetection:
    """Tests for InsightsEngine.recurring_issue_detection."""

    @pytest.mark.asyncio
    async def test_recurring_pattern_detected(self):
        """Three incidents with overlapping content are flagged."""
        now = _now()
        episodes = [
            _episode("e1", "incident", ["db-service"], content="connection timeout to database primary", timestamp=now - timedelta(days=1)),
            _episode("e2", "incident", ["db-service"], content="connection timeout to database replica", timestamp=now - timedelta(days=5)),
            _episode("e3", "incident", ["db-service"], content="connection timeout to database failover", timestamp=now - timedelta(days=10)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.recurring_issue_detection()

        assert len(insights) == 1
        assert insights[0].insight_type == InsightType.recurring_issue
        assert "db-service" in insights[0].title

    @pytest.mark.asyncio
    async def test_no_recurring_with_few_incidents(self):
        """Two incidents are not enough to trigger recurring detection."""
        now = _now()
        episodes = [
            _episode("e1", "incident", ["svc-a"], content="error foo", timestamp=now - timedelta(days=1)),
            _episode("e2", "incident", ["svc-a"], content="error foo", timestamp=now - timedelta(days=5)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.recurring_issue_detection()

        assert len(insights) == 0


# ---------------------------------------------------------------------------
# generate_all
# ---------------------------------------------------------------------------


class TestGenerateAll:
    """Tests for InsightsEngine.generate_all."""

    @pytest.mark.asyncio
    async def test_combines_all_generators(self):
        """generate_all runs all generators and combines results."""
        now = _now()
        episodes = [
            _episode("e1", "incident", ["svc-a"], timestamp=now - timedelta(hours=1)),
            _episode("e2", "incident", ["svc-a"], timestamp=now - timedelta(hours=2)),
            _episode("e3", "incident", ["svc-a"], timestamp=now - timedelta(hours=3)),
        ]

        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=episodes)):
            insights = await engine.generate_all()

        # Should have at least an incident spike and a knowledge gap.
        types = {i.insight_type for i in insights}
        assert InsightType.incident_spike in types
        assert InsightType.knowledge_gap in types

    @pytest.mark.asyncio
    async def test_empty_episodes(self):
        """No insights from empty episode list."""
        engine = InsightsEngine()
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=[])):
            insights = await engine.generate_all()

        assert insights == []

    @pytest.mark.asyncio
    async def test_generator_failure_does_not_crash(self):
        """A failing generator should not prevent other generators from running."""
        engine = InsightsEngine()

        # Make incident_spike_detection raise, others return empty.
        with patch.object(engine, "_fetch_episodes", AsyncMock(return_value=[])):
            with patch.object(
                engine,
                "incident_spike_detection",
                AsyncMock(side_effect=RuntimeError("boom")),
            ):
                insights = await engine.generate_all()

        # Should still succeed (other generators return empty lists).
        assert isinstance(insights, list)


# ---------------------------------------------------------------------------
# REST API caching
# ---------------------------------------------------------------------------


class TestInsightsCache:
    """Tests for the InsightsCache used in the REST API."""

    def test_cache_hit(self):
        from cortexdb_mcp.api import InsightsCache

        cache = InsightsCache(ttl_seconds=60)
        data = [{"id": "ins_1"}]
        cache.set(data)
        assert cache.get() == data

    def test_cache_miss_after_ttl(self):
        from cortexdb_mcp.api import InsightsCache

        cache = InsightsCache(ttl_seconds=0)
        cache.set([{"id": "ins_1"}])
        # TTL of 0 means immediately expired.
        # We need a tiny delay so monotonic time advances.
        time.sleep(0.01)
        assert cache.get() is None

    def test_cache_invalidation(self):
        from cortexdb_mcp.api import InsightsCache

        cache = InsightsCache(ttl_seconds=300)
        cache.set([{"id": "ins_1"}])
        assert cache.get() is not None
        cache.invalidate()
        assert cache.get() is None

    def test_cache_initially_empty(self):
        from cortexdb_mcp.api import InsightsCache

        cache = InsightsCache()
        assert cache.get() is None


# ---------------------------------------------------------------------------
# REST API endpoints
# ---------------------------------------------------------------------------


class TestRESTEndpoints:
    """Tests for the FastAPI endpoints in cortexdb_mcp.api."""

    @pytest.mark.asyncio
    async def test_get_insights_endpoint(self):
        from fastapi.testclient import TestClient

        from cortexdb_mcp.api import _cache, app

        _cache.invalidate()

        mock_insights = [
            Insight(
                id="ins_test",
                insight_type=InsightType.incident_spike,
                title="Test spike",
                description="desc",
                severity=Severity.warning,
                entities=["svc-a"],
                evidence=["ep_1"],
                generated_at=_now(),
                confidence=0.8,
            )
        ]

        with patch.object(
            InsightsEngine,
            "generate_all",
            AsyncMock(return_value=mock_insights),
        ):
            client = TestClient(app)
            resp = client.get("/api/insights")

        assert resp.status_code == 200
        body = resp.json()
        assert "insights" in body
        assert len(body["insights"]) == 1
        assert body["insights"][0]["title"] == "Test spike"

    @pytest.mark.asyncio
    async def test_cached_response(self):
        from fastapi.testclient import TestClient

        from cortexdb_mcp.api import _cache, app

        # Pre-populate cache.
        _cache.set([{"id": "ins_cached", "title": "Cached"}])

        client = TestClient(app)
        resp = client.get("/api/insights")
        assert resp.status_code == 200
        body = resp.json()
        assert body["cached"] is True
        assert body["insights"][0]["id"] == "ins_cached"

        # Clean up.
        _cache.invalidate()

    def test_health_endpoint(self):
        from fastapi.testclient import TestClient

        from cortexdb_mcp.api import app

        client = TestClient(app)
        resp = client.get("/api/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"
