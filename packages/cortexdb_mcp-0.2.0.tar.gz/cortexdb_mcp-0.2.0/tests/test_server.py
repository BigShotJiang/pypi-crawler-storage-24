"""Tests for the CortexDB MCP server tools.

These tests mock the HTTP layer so they run without a live CortexDB instance.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest

from cortexdb_mcp.config import CortexMCPConfig
from cortexdb_mcp.server import (
    get_context,
    health_check,
    memory_forget,
    memory_search,
    memory_store,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_request(return_value: dict):
    """Return a patch that replaces ``_request`` with an async mock."""
    mock = AsyncMock(return_value=return_value)
    return patch("cortexdb_mcp.server._request", mock), mock


# ---------------------------------------------------------------------------
# Config tests
# ---------------------------------------------------------------------------


class TestConfig:
    """Tests for CortexMCPConfig."""

    def test_defaults(self):
        cfg = CortexMCPConfig()
        assert cfg.url == "http://localhost:3141"
        assert cfg.api_key is None
        assert cfg.timeout == 30.0

    def test_from_env(self, monkeypatch):
        monkeypatch.setenv("CORTEXDB_URL", "http://cortex:9999")
        monkeypatch.setenv("CORTEXDB_API_KEY", "secret-key")
        monkeypatch.setenv("CORTEXDB_TIMEOUT", "60")
        cfg = CortexMCPConfig.from_env()
        assert cfg.url == "http://cortex:9999"
        assert cfg.api_key == "secret-key"
        assert cfg.timeout == 60.0

    def test_from_env_defaults(self, monkeypatch):
        monkeypatch.delenv("CORTEXDB_URL", raising=False)
        monkeypatch.delenv("CORTEXDB_API_KEY", raising=False)
        monkeypatch.delenv("CORTEXDB_TIMEOUT", raising=False)
        cfg = CortexMCPConfig.from_env()
        assert cfg.url == "http://localhost:3141"
        assert cfg.api_key is None


# ---------------------------------------------------------------------------
# Tool tests
# ---------------------------------------------------------------------------


class TestMemoryStore:
    """Tests for the memory_store tool."""

    @pytest.mark.asyncio
    async def test_store_basic(self):
        patcher, mock = _mock_request({"event_id": "evt_123"})
        with patcher:
            result = await memory_store(content="hello world")
        assert "evt_123" in result
        mock.assert_called_once()
        call_args = mock.call_args
        assert call_args[0][0] == "POST"
        assert call_args[0][1] == "/v1/remember"

    @pytest.mark.asyncio
    async def test_store_with_source_uses_episodes(self):
        patcher, mock = _mock_request({"episode_id": "ep_456"})
        with patcher:
            result = await memory_store(
                content="deploy event",
                source="github",
                tags=["deploy"],
            )
        assert "ep_456" in result
        call_args = mock.call_args
        assert call_args[0][1] == "/v1/episodes"

    @pytest.mark.asyncio
    async def test_store_includes_optional_fields(self):
        patcher, mock = _mock_request({"event_id": "evt_789"})
        with patcher:
            await memory_store(
                content="test",
                tenant_id="t1",
                namespace="ns1",
                episode_type="observation",
            )
        body = mock.call_args[1]["json_body"]
        assert body["tenant_id"] == "t1"
        assert body["namespace"] == "ns1"
        assert body["episode_type"] == "observation"


class TestMemorySearch:
    """Tests for the memory_search tool."""

    @pytest.mark.asyncio
    async def test_search_with_context(self):
        patcher, mock = _mock_request({
            "context": "User deployed v2 yesterday.",
            "confidence": 0.92,
            "results": [],
        })
        with patcher:
            result = await memory_search(query="last deploy")
        assert "deployed v2" in result
        assert "0.92" in result

    @pytest.mark.asyncio
    async def test_search_no_results(self):
        patcher, _ = _mock_request({"context": "", "results": []})
        with patcher:
            result = await memory_search(query="nonexistent")
        assert result == "No results found."

    @pytest.mark.asyncio
    async def test_search_passes_max_results(self):
        patcher, mock = _mock_request({"context": "ok", "results": []})
        with patcher:
            await memory_search(query="q", max_results=5)
        body = mock.call_args[1]["json_body"]
        assert body["max_results"] == 5


class TestMemoryForget:
    """Tests for the memory_forget tool."""

    @pytest.mark.asyncio
    async def test_forget(self):
        patcher, mock = _mock_request({
            "entities_removed": 3,
            "edges_removed": 7,
        })
        with patcher:
            result = await memory_forget(reason="GDPR request", query="user@example.com")
        assert "3" in result
        assert "7" in result
        body = mock.call_args[1]["json_body"]
        assert body["reason"] == "GDPR request"
        assert body["query"] == "user@example.com"


class TestGetContext:
    """Tests for the get_context tool."""

    @pytest.mark.asyncio
    async def test_context_with_graph(self):
        patcher, mock = _mock_request({
            "context": "Service A depends on Service B.",
            "graph": {"nodes": ["A", "B"], "edges": [{"from": "A", "to": "B"}]},
        })
        with patcher:
            result = await get_context(topic="Service A", include_graph=True)
        assert "Service A depends on Service B" in result
        assert "Graph Relationships" in result
        body = mock.call_args[1]["json_body"]
        assert body["include_graph"] is True

    @pytest.mark.asyncio
    async def test_context_not_found(self):
        patcher, _ = _mock_request({"context": ""})
        with patcher:
            result = await get_context(topic="unknown")
        assert "No context found" in result


class TestHealthCheck:
    """Tests for the health_check tool."""

    @pytest.mark.asyncio
    async def test_health_ok(self):
        patcher, _ = _mock_request({"status": "healthy"})
        with patcher:
            result = await health_check()
        assert "healthy" in result

    @pytest.mark.asyncio
    async def test_health_error(self):
        mock = AsyncMock(side_effect=RuntimeError("connection refused"))
        with patch("cortexdb_mcp.server._request", mock):
            with pytest.raises(RuntimeError, match="connection refused"):
                await health_check()


# ---------------------------------------------------------------------------
# Prompt tests
# ---------------------------------------------------------------------------


class TestPrompts:
    """Tests for the prompt templates."""

    def test_investigate_incident(self):
        from cortexdb_mcp.server import investigate_incident
        result = investigate_incident(topic="outage-2024-03-15")
        assert "outage-2024-03-15" in result
        assert "root cause" in result.lower()

    def test_summarize_knowledge(self):
        from cortexdb_mcp.server import summarize_knowledge
        result = summarize_knowledge(topic="authentication service")
        assert "authentication service" in result
        assert "confidence" in result.lower()
