"""REST API for the CortexDB insights engine.

Exposes a lightweight FastAPI application that the GTM web dashboard calls to
display proactive insights.  Results are cached with a configurable TTL (default
5 minutes) so the engine is not re-run on every request.

Configuration is read from environment variables:

- ``CORTEXDB_URL``      -- CortexDB base URL (default ``http://localhost:3141``)
- ``CORTEXDB_API_KEY``  -- Optional bearer token
- ``CORTEXDB_TENANT_ID``-- Optional tenant scope
- ``INSIGHTS_CACHE_TTL``-- Cache lifetime in seconds (default ``300``)

Run directly::

    uvicorn cortexdb_mcp.api:app --host 0.0.0.0 --port 8080
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from cortexdb_mcp.insights import InsightsEngine

logger = logging.getLogger("cortexdb_mcp.api")

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

CORTEXDB_URL = os.environ.get("CORTEXDB_URL", "http://localhost:3141")
CORTEXDB_API_KEY = os.environ.get("CORTEXDB_API_KEY")
CORTEXDB_TENANT_ID = os.environ.get("CORTEXDB_TENANT_ID")
INSIGHTS_CACHE_TTL = int(os.environ.get("INSIGHTS_CACHE_TTL", "300"))

# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------


class InsightsCache:
    """Simple in-memory cache with TTL for generated insights."""

    def __init__(self, ttl_seconds: int = 300) -> None:
        self.ttl_seconds = ttl_seconds
        self._data: list[dict[str, Any]] | None = None
        self._timestamp: float = 0.0

    def get(self) -> list[dict[str, Any]] | None:
        """Return cached insights if still valid, otherwise None."""
        if self._data is not None and (time.monotonic() - self._timestamp) < self.ttl_seconds:
            return self._data
        return None

    def set(self, data: list[dict[str, Any]]) -> None:
        """Store insights in the cache."""
        self._data = data
        self._timestamp = time.monotonic()

    def invalidate(self) -> None:
        """Force-expire the cache."""
        self._data = None
        self._timestamp = 0.0


_cache = InsightsCache(ttl_seconds=INSIGHTS_CACHE_TTL)

# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

app = FastAPI(
    title="CortexDB Insights API",
    description="Proactive insights for the CortexDB GTM web dashboard.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


def _engine() -> InsightsEngine:
    """Build a fresh InsightsEngine from environment configuration."""
    return InsightsEngine(
        cortex_url=CORTEXDB_URL,
        api_key=CORTEXDB_API_KEY,
        tenant_id=CORTEXDB_TENANT_ID,
    )


@app.get("/api/insights")
async def get_insights() -> dict[str, Any]:
    """Return proactive insights as JSON.

    Results are cached for ``INSIGHTS_CACHE_TTL`` seconds (default 300).
    """
    cached = _cache.get()
    if cached is not None:
        return {"insights": cached, "cached": True}

    engine = _engine()
    insights = await engine.generate_all()
    serialized = [i.to_dict() for i in insights]
    _cache.set(serialized)
    return {"insights": serialized, "cached": False}


@app.post("/api/insights/refresh")
async def refresh_insights() -> dict[str, Any]:
    """Force-refresh the insights cache and return fresh results."""
    _cache.invalidate()
    engine = _engine()
    insights = await engine.generate_all()
    serialized = [i.to_dict() for i in insights]
    _cache.set(serialized)
    return {"insights": serialized, "cached": False}


@app.get("/api/health")
async def health() -> dict[str, str]:
    """Health check for the insights API."""
    return {"status": "ok"}
