"""CortexDB MCP Server -- expose CortexDB memory operations to AI agents via MCP."""

__version__ = "0.2.0"
