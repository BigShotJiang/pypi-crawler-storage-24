"""Configuration management for the CortexDB MCP server.

Reads settings from environment variables with sensible defaults.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class CortexMCPConfig:
    """Configuration for connecting to a CortexDB instance.

    Attributes:
        url: Base URL of the CortexDB HTTP API.
        api_key: Optional API key for authenticated access.
        timeout: HTTP request timeout in seconds.
    """

    url: str = "http://localhost:3141"
    api_key: str | None = None
    timeout: float = 30.0

    @classmethod
    def from_env(cls) -> CortexMCPConfig:
        """Build configuration from environment variables.

        Environment variables
        ---------------------
        CORTEXDB_URL      -- CortexDB base URL (default ``http://localhost:3141``)
        CORTEXDB_API_KEY  -- API key (default ``None``)
        CORTEXDB_TIMEOUT  -- Request timeout in seconds (default ``30.0``)
        """
        return cls(
            url=os.environ.get("CORTEXDB_URL", cls.url),
            api_key=os.environ.get("CORTEXDB_API_KEY", cls.api_key),
            timeout=float(os.environ.get("CORTEXDB_TIMEOUT", str(cls.timeout))),
        )
