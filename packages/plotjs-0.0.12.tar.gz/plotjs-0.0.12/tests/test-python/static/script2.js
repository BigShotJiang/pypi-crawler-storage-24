export const aVariable = "hello";
