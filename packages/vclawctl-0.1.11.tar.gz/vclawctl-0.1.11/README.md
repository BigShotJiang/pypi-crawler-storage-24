# vclawctl

`vclawctl` is an independent control-plane CLI for managing v-claw data.

All command outputs are JSON on stdout. On non-UTF-8 terminals (for example
Windows GBK), non-ASCII characters are auto-escaped to keep output stable.

## Quick Start

```bash
uv tool install vclawctl
vclawctl --help
```

## Control Channel Modes

`vclawctl` supports three execution modes:

```bash
vclawctl --mode api   ...   # API only
vclawctl --mode auto  ...   # API first, fallback to DB
vclawctl --mode db    ...   # DB only
```

Default mode is `api`.

## API Auth

When using API mode, provide:

- `VCLAWCTL_API_BASE_URL` (for example `http://127.0.0.1:7799/api/control/v1`)
- `VCLAWCTL_AUTH_TOKEN`

or pass flags directly:

```bash
vclawctl \
  --mode api \
  --api-base-url "http://127.0.0.1:7799/api/control/v1" \
  --auth-token "YOUR_TOKEN" \
  schedule status
```

## Examples

```bash
# List schedule tasks (default api mode)
vclawctl schedule list

# Inspect heartbeat end-to-end
vclawctl heartbeat show

# Inspect config without dumping huge branches
vclawctl config get
vclawctl config get --full
vclawctl config get --match feishu
vclawctl config get --key vectorvein.model_endpoint_backups

# Update heartbeat config
vclawctl heartbeat set --enabled true --interval-seconds 1800 --notify-policy im_owner

# Manage HEARTBEAT.md checklist items
vclawctl heartbeat add-item --text "检查今天的重要消息"
vclawctl heartbeat remove-item --index 1

# Inspect heartbeat-only task history
vclawctl heartbeat tasks --status error

# Create one-time schedule task
vclawctl schedule create --params-json '{"name":"once-hi","prompt":"Hi","schedule_type":"once","schedule_config":{"at":"2026-03-01T12:00:00Z"}}'

# Quick create one-time task after a delay
vclawctl schedule create --name "once-hi" --prompt "Hi" --after 10m
# --after supports: 30s / 5m / 2h / 1d / 90 (seconds)

# Generic method call
vclawctl call --method settings.get_value --params-json '{"key":"chat.default_agent_id"}'

# Live session/chat control (runtime API)
vclawctl session create --agent-id default
vclawctl session send --session-id <session_id> --message "继续执行"
vclawctl session approve --session-id <session_id> --decision approve
vclawctl session list
vclawctl chat ensure --force-new
vclawctl chat send --message "你好"
vclawctl chat status --ensure-session

# Runtime settings / LLM / VectorVein / Feishu (runtime API)
vclawctl config llm-settings
vclawctl config update-llm --settings-json '{"endpoints":[{"id":"openai-main","backend":"openai"}]}'
vclawctl config list-models --api-base https://api.openai.com/v1 --api-key <api_key>
vclawctl config approval-rules
vclawctl config update-approval-rule --rule-id shell_exec --enabled false
vclawctl config delete-approval-rule --rule-id shell_exec
vclawctl config vv-binding
vclawctl config vv-bind --base-url https://vectorvein.com --api-key <api_key>
vclawctl config vv-login-bind --base-url https://vectorvein.com --account user@example.com --password <password>
vclawctl config vv-summary
vclawctl config vv-unbind
vclawctl config test-embedding --backend openai --model text-embedding-3-large --test-input hello --test-timeout 45
vclawctl config test-rerank --backend cohere --model rerank-v3.5 --query "apple" --documents-json '["Apple is a fruit.","Apple released a laptop."]' --test-timeout 25
vclawctl config test-feishu --account-key default --config-json '{"app_id":"cli-app","app_secret":"cli-secret"}'

# List skill catalog
vclawctl skill list

# Get one skill detail
vclawctl skill get --skill-id <skill_id>

# Install/enable/disable/validate one skill
vclawctl skill install --skill-id <skill_id>
vclawctl skill disable --skill-id <skill_id>
vclawctl skill enable --skill-id <skill_id>
vclawctl skill validate --skill-id <skill_id>

# Uninstall skill (destructive)
vclawctl skill uninstall --skill-id <skill_id> --yes

# Import OpenClaw memory workspace into v-claw memory runtime
vclawctl memory import-openclaw --workspace-path /path/to/openclaw-workspace --include-sessions true

# Rebuild memory indexes for one agent
vclawctl memory rebuild-index --agent-id default

# List/search memory
vclawctl memory list --agent-id default --limit 20
vclawctl memory search --query "支付修复" --agent-id default --limit 12

# CRUD memory
vclawctl memory add --content "发布前必须跑回归测试" --memory-type policy --metadata-json '{"source":"manual"}'
vclawctl memory get --memory-id <memory_id>
vclawctl memory edit --memory-id <memory_id> --status archived
vclawctl memory delete --memory-id <memory_id>

# Preference / quiet hours
vclawctl preference quiet-hours get --agent-id default
vclawctl preference quiet-hours set --agent-id default --start 22:00 --end 09:30 --timezone Asia/Shanghai --allow-proactive false
vclawctl preference quiet-hours clear --agent-id default

# Stats and source file read
vclawctl memory stats --agent-id default
vclawctl memory get-file --path MEMORY.md --from-line 1 --lines 80

# Transcript search (runtime API)
vclawctl task transcript --session-id <session_id> --limit 100
vclawctl task transcript-search --query "timeout" --session-id <session_id>
vclawctl task transcript-stats --session-id <session_id>

# IM / workspace / agent context (runtime API)
vclawctl im status
vclawctl im accounts --channel feishu
vclawctl workspace state --workspace-path /path/to/workspace
vclawctl workspace preview --workspace-path /path/to/workspace --relative-path README.md
vclawctl agent-context status --agent-id default
vclawctl agent-context read --agent-id default --target USER.md

# Browser runtime inspection (runtime API)
vclawctl browser status --session-id <session_id>
vclawctl browser tabs --session-id <session_id>
vclawctl browser screenshot --session-id <session_id> --quality 60 --output browser.jpg

# One-shot: import package -> bind to agent -> set default agent -> reset chat session
vclawctl skill import-bind --file-path /path/to/new-skill.skill --agent-id default
```

## Heartbeat

`vclawctl heartbeat` is a first-class command group for heartbeat runtime state,
config, `HEARTBEAT.md`, checklist items, and heartbeat task history.

```bash
# Show combined heartbeat state: config + runtime status + HEARTBEAT.md + recent tasks
vclawctl heartbeat show

# Read only runtime status or normalized config
vclawctl heartbeat status
vclawctl heartbeat config

# Enable / disable / patch config
vclawctl heartbeat enable
vclawctl heartbeat disable
vclawctl heartbeat set --start 08:00 --end 23:00 --timezone Asia/Shanghai
vclawctl heartbeat set --main-agent-id ops-agent --notify-policy im_owner_or_chat

# Read / replace / reset HEARTBEAT.md
vclawctl heartbeat read
vclawctl heartbeat write --content $'# HEARTBEAT.md\n\n- 检查今日待办\n- 检查飞书消息\n'
vclawctl heartbeat clear

# Checklist-level operations without rewriting the whole file
vclawctl heartbeat items
vclawctl heartbeat add-item --text "检查今天的重要消息"
vclawctl heartbeat remove-item --index 2
vclawctl heartbeat remove-item --match "飞书" --all-matches true

# Heartbeat task inspection
vclawctl heartbeat tasks --limit 10
vclawctl heartbeat task --task-id <heartbeat_task_id>
```

Notes:

- `heartbeat` defaults to the configured `heartbeat.main_agent_id`; use `--agent-id`
  to override file/task operations.
- `show` is the best discovery entrypoint for agents because it returns current
  config, runtime snapshot, parsed checklist items, and recent heartbeat tasks.
- `clear` resets `HEARTBEAT.md` back to the default template instead of writing
  an empty file.
- `heartbeat` supports `api`, `auto`, and `db`. In `db` or local fallback mode,
  it can still manage `HEARTBEAT.md` and inspect heartbeat task snapshots.

## Python SDK

`vclawctl` also exposes a programmatic heartbeat controller:

```python
from pathlib import Path
from types import SimpleNamespace

from vclawctl.context import CLIContext
from vclawctl.sdk import HeartbeatSDK

data_dir = Path("/path/to/v-claw-data")
ctx = CLIContext(
    data_dir=data_dir,
    db_path=data_dir / "v_claw.db",
    pretty=False,
    mode="auto",
    api_base_url="http://127.0.0.1:7799/api/control/v1",
    auth_token="YOUR_TOKEN",
    timeout_seconds=10.0,
    logger=SimpleNamespace(info=lambda *args, **kwargs: None),
)

heartbeat = HeartbeatSDK(ctx)
heartbeat.inspect()
heartbeat.update_config({"enabled": True, "notify_policy": "im_owner"})
heartbeat.add_item(text="检查今日待办")
```

## Skill Workflow

`vclawctl skill` is designed for agent self-serve skill onboarding:

```bash
# 1) Import .zip/.skill into local skill catalog and global installation
vclawctl skill import --file-path /path/to/demo.skill

# 1.1) Third-party package compatibility mode (relaxed manifest checks)
vclawctl skill import --file-path /path/to/demo.skill --validation-mode compat

# 2) Bind imported skill to one agent profile (deduplicated append)
vclawctl skill bind --skill-id <skill_id> --agent-id default

# 3) Validate required skills before creating task/session
vclawctl skill validate --agent-id default --skill-id <skill_id>

# 4) Toggle installation state when debugging rollout
vclawctl skill disable --skill-id <skill_id>
vclawctl skill enable --skill-id <skill_id>
vclawctl skill update-installation --installation-id <installation_id> --enabled false --config-json '{"region":"cn"}'

# 5) Uninstall skill (delete local catalog/installations/files)
vclawctl skill uninstall --skill-id <skill_id> --yes
```

Or use one command:

```bash
vclawctl skill import-bind \
  --file-path /path/to/demo.skill \
  --agent-id default \
  --validation-mode compat
```

Notes:

- `skill import` / `skill import-bind` require runtime API (`--mode api`) with a running v-claw process.
- `heartbeat` supports `api` / `auto` / `db`; file and task inspection can fall back to local state,
  while live runtime status is only available when a v-claw instance is running.
- `preference quiet-hours` supports `api` / `auto` / `db`; in `db` mode it writes SQLite and mirrors the managed block into `USER.md`.
- `config get/set/patch` support local DB fallback, but advanced `config` runtime commands
  (`llm-settings`, `update-llm`, `list-models`, `approval-rules`, `update-approval-rule`,
  `delete-approval-rule`, `vv-*`, `test-embedding`, `test-rerank`, `test-feishu`)
  require runtime API (`--mode api/auto`) with a running v-claw instance.
- All `memory` command group operations require runtime API (`--mode api`).
- `session create/send/retry/approve/list`, `chat ensure/send/retry/status`, `task transcript*`,
  `im`, `workspace`, `agent-context`, and `browser` currently require runtime API (`--mode api/auto`).
- `skill uninstall` is destructive: it removes local catalog rows, installation rows, and imported skill files.
- Existing running sessions do not hot-load new skills; a fresh chat session is required.
- `--validation-mode` supports `strict` (default), `compat`, `minimal`.

## Inspect Task/Session Messages

```bash
# List messages by task
vclawctl task messages --task-id task-main

# Search message content inside one task/session
vclawctl task search-messages --task-id task-main --query "error"
vclawctl session search-messages --session-id sess-1 --query "timeout"

# Get last message quickly (useful to check current progress)
vclawctl task last-message --task-id task-main
vclawctl session last-message --session-id sess-1

# Read real transcript turns from transcript index / JSONL
vclawctl task transcript --session-id sess-1
vclawctl task transcript-search --session-id sess-1 --query "timeout"
```

Every `task/session` response now includes `data.meta.id_model` to reduce
identity confusion in human/agent workflows:

- `requested_by`: which id type was used (`task_id` or `session_id`)
- `relation`: persisted relation note between task/session
- `task_id_meaning` / `session_id_meaning`: semantic intent of each id
