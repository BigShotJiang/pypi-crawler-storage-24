from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import pytest

from vclawctl.commands import memory as memory_command
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError


def test_cmd_import_openclaw_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        captured["method"] = method
        captured["params"] = params
        captured["ctx"] = ctx
        captured["local_call"] = local_call
        return {"ok": True, "report": {"imported_count": 3}}

    monkeypatch.setattr(memory_command, "invoke", _fake_invoke)

    args = SimpleNamespace(
        workspace_path="/tmp/openclaw-workspace",
        agent_id="default",
        include_sessions="true",
        sessions_dir="/tmp/openclaw-workspace/sessions",
    )
    result = memory_command._cmd_import_openclaw(args, ctx=cast(CLIContext, object()))
    assert result == {"ok": True, "report": {"imported_count": 3}}
    assert captured["method"] == "memory.import_openclaw"
    params = cast(dict[str, Any], captured["params"])
    assert params["workspace_path"] == "/tmp/openclaw-workspace"
    assert params["agent_id"] == "default"
    assert params["include_sessions"] is True
    assert params["sessions_dir"] == "/tmp/openclaw-workspace/sessions"


def test_cmd_rebuild_index_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        captured["method"] = method
        captured["params"] = params
        captured["ctx"] = ctx
        captured["local_call"] = local_call
        return {"ok": True, "report": {"agent_id": "agent-x"}}

    monkeypatch.setattr(memory_command, "invoke", _fake_invoke)

    args = SimpleNamespace(agent_id="agent-x")
    result = memory_command._cmd_rebuild_index(args, ctx=cast(CLIContext, object()))
    assert result == {"ok": True, "report": {"agent_id": "agent-x"}}
    assert captured["method"] == "memory.rebuild"
    params = cast(dict[str, Any], captured["params"])
    assert params["agent_id"] == "agent-x"


def test_cmd_search_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True, "results": [{"memory_id": "m-1"}]}

    monkeypatch.setattr(memory_command, "invoke", _fake_invoke)

    args = SimpleNamespace(
        query="支付修复",
        agent_id="default",
        session_id="sess-1",
        limit=12,
        include_episodic="false",
    )
    result = memory_command._cmd_search(args, ctx=cast(CLIContext, object()))
    assert result["ok"] is True
    assert captured["method"] == "memory.search"
    params = cast(dict[str, Any], captured["params"])
    assert params["query"] == "支付修复"
    assert params["agent_id"] == "default"
    assert params["session_id"] == "sess-1"
    assert params["limit"] == 12
    assert params["include_episodic"] is False


def test_cmd_add_invokes_runtime_method_with_metadata(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True, "memory": {"memory_id": "m-2"}}

    monkeypatch.setattr(memory_command, "invoke", _fake_invoke)

    args = SimpleNamespace(
        content="记住：发布前跑回归测试",
        agent_id="default",
        session_id="sess-2",
        task_id="task-2",
        memory_type="policy",
        source_kind="manual",
        importance=0.9,
        metadata_json='{"category":"release"}',
    )
    result = memory_command._cmd_add(args, ctx=cast(CLIContext, object()))
    assert result["ok"] is True
    assert captured["method"] == "memory.add"
    params = cast(dict[str, Any], captured["params"])
    assert params["content"] == "记住：发布前跑回归测试"
    assert params["memory_type"] == "policy"
    assert params["source_kind"] == "manual"
    assert params["importance"] == 0.9
    assert params["metadata"] == {"category": "release"}


def test_cmd_list_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True, "entries": [], "total": 0}

    monkeypatch.setattr(memory_command, "invoke", _fake_invoke)

    args = SimpleNamespace(
        agent_id="default",
        status="active",
        memory_type="fact",
        source_kind="manual",
        query="中文",
        limit=30,
        offset=5,
    )
    result = memory_command._cmd_list(args, ctx=cast(CLIContext, object()))
    assert result["ok"] is True
    assert captured["method"] == "memory.list"
    params = cast(dict[str, Any], captured["params"])
    assert params == {
        "agent_id": "default",
        "status": "active",
        "memory_type": "fact",
        "source_kind": "manual",
        "query": "中文",
        "limit": 30,
        "offset": 5,
    }


def test_cmd_get_file_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True, "path": "MEMORY.md", "text": "..."}

    monkeypatch.setattr(memory_command, "invoke", _fake_invoke)

    args = SimpleNamespace(path="MEMORY.md", from_line=3, lines=20)
    result = memory_command._cmd_get_file(args, ctx=cast(CLIContext, object()))
    assert result["ok"] is True
    assert captured["method"] == "memory.get_file"
    params = cast(dict[str, Any], captured["params"])
    assert params == {"path": "MEMORY.md", "from": 3, "lines": 20}


def test_cmd_update_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True, "memory": {"memory_id": "m-3"}}

    monkeypatch.setattr(memory_command, "invoke", _fake_invoke)

    args = SimpleNamespace(
        memory_id="m-3",
        content="新的内容",
        memory_type="summary",
        status="active",
        importance="0.55",
        metadata_json='{"tag":"x"}',
    )
    result = memory_command._cmd_update(args, ctx=cast(CLIContext, object()))
    assert result["ok"] is True
    assert captured["method"] == "memory.update"
    params = cast(dict[str, Any], captured["params"])
    assert params["memory_id"] == "m-3"
    assert params["content"] == "新的内容"
    assert params["memory_type"] == "summary"
    assert params["status"] == "active"
    assert params["importance"] == 0.55
    assert params["metadata"] == {"tag": "x"}


def test_cmd_update_requires_patch_fields():
    args = SimpleNamespace(
        memory_id="m-9",
        content="",
        memory_type="",
        status="",
        importance="",
        metadata_json="",
    )
    with pytest.raises(CLIError) as exc:
        memory_command._cmd_update(args, ctx=cast(CLIContext, object()))
    assert exc.value.code == "missing_required"


def test_cmd_delete_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True}

    monkeypatch.setattr(memory_command, "invoke", _fake_invoke)

    args = SimpleNamespace(memory_id="m-del")
    result = memory_command._cmd_delete(args, ctx=cast(CLIContext, object()))
    assert result["ok"] is True
    assert captured["method"] == "memory.delete"
    assert cast(dict[str, Any], captured["params"]) == {"memory_id": "m-del"}


def test_cmd_stats_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True, "stats": {"total_count": 1}}

    monkeypatch.setattr(memory_command, "invoke", _fake_invoke)

    args = SimpleNamespace(agent_id="default")
    result = memory_command._cmd_stats(args, ctx=cast(CLIContext, object()))
    assert result["ok"] is True
    assert captured["method"] == "memory.stats"
    assert cast(dict[str, Any], captured["params"]) == {"agent_id": "default"}
