from __future__ import annotations

import sqlite3
import time
from types import SimpleNamespace

import pytest

from vclawctl.context import CLIContext
from vclawctl.errors import CLIError
from vclawctl.sdk.heartbeat import HeartbeatSDK


def _ctx(data_dir):
    return CLIContext(
        data_dir=data_dir,
        db_path=data_dir / "v_claw.db",
        pretty=False,
        mode="db",
        api_base_url="",
        auth_token="",
        timeout_seconds=10.0,
        logger=SimpleNamespace(info=lambda *args, **kwargs: None),
    )


def test_heartbeat_sdk_config_and_file_crud(data_dir):
    sdk = HeartbeatSDK(_ctx(data_dir))

    initial = sdk.get_config()["config"]
    assert initial["enabled"] is False
    assert initial["main_agent_id"] == "default"

    updated = sdk.update_config(
        {
            "enabled": True,
            "interval_seconds": 900,
            "active_hours": {"start": "09:00", "end": "21:30"},
            "timezone": "UTC",
            "main_agent_id": "ops-agent",
            "notify_policy": "im_owner_or_chat",
        }
    )["config"]
    assert updated == {
        "enabled": True,
        "interval_seconds": 900,
        "active_hours": {"start": "09:00", "end": "21:30"},
        "timezone": "UTC",
        "main_agent_id": "ops-agent",
        "notify_policy": "im_owner_or_chat",
    }

    file_payload = sdk.write_file(
        content="# HEARTBEAT.md\n\n## 心跳检查清单\n\n- 检查日程\n",
    )
    assert file_payload["agent_id"] == "ops-agent"
    assert file_payload["item_count"] == 1
    assert file_payload["items"][0]["text"] == "检查日程"

    added = sdk.add_item(text="检查待处理消息")
    assert added["item_count"] == 2

    removed = sdk.remove_item(index=1)
    assert [item["text"] for item in removed["items"]] == ["检查待处理消息"]
    assert removed["removed_items"][0]["text"] == "检查日程"

    cleared = sdk.clear_file()
    assert cleared["item_count"] == 0
    assert "心跳检查清单" in cleared["content"]


def test_heartbeat_sdk_lists_only_heartbeat_tasks(data_dir):
    now = time.time()
    conn = sqlite3.connect(data_dir / "v_claw.db")
    conn.execute(
        """
        INSERT INTO task_history(
            task_id, agent_id, session_id, title, prompt, session_kind,
            workspace_path, workspace_source, status, cycles_count, created_at,
            finished_at, is_favorite, progress_json, final_answer,
            token_usage_json, agent_name, model_name, parent_task_id,
            is_sub_task
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "hb-task-1",
            "default",
            "heartbeat-a1b2c3d4",
            "心跳巡检",
            "检查今天的重点事项",
            "task",
            "",
            "global_default",
            "completed",
            1,
            now,
            now,
            0,
            "[]",
            "HEARTBEAT_OK",
            "{}",
            "默认助手",
            "kimi-k2.5",
            "",
            0,
        ),
    )
    conn.execute(
        """
        INSERT INTO task_history(
            task_id, agent_id, session_id, title, prompt, session_kind,
            workspace_path, workspace_source, status, cycles_count, created_at,
            finished_at, is_favorite, progress_json, final_answer,
            token_usage_json, agent_name, model_name, parent_task_id,
            is_sub_task
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "user-task-1",
            "default",
            "session-user-1",
            "普通任务",
            "处理一个普通请求",
            "task",
            "",
            "global_default",
            "completed",
            1,
            now + 1,
            now + 1,
            0,
            "[]",
            "done",
            "{}",
            "默认助手",
            "kimi-k2.5",
            "",
            0,
        ),
    )
    conn.commit()
    conn.close()

    sdk = HeartbeatSDK(_ctx(data_dir))
    tasks = sdk.list_tasks()["tasks"]
    assert [item["task_id"] for item in tasks] == ["hb-task-1"]

    task_payload = sdk.get_task(task_id="hb-task-1")["task"]
    assert task_payload["session_id"].startswith("heartbeat-")

    with pytest.raises(CLIError):
        sdk.get_task(task_id="user-task-1")
