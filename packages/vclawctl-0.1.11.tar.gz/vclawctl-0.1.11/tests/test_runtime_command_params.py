from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import pytest

from vclawctl.commands import agent_context as agent_context_command
from vclawctl.commands import browser as browser_command
from vclawctl.commands import chat as chat_command
from vclawctl.commands import im as im_command
from vclawctl.commands import session as session_command
from vclawctl.commands import task as task_command
from vclawctl.commands import workspace as workspace_command
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError


def test_chat_runtime_commands_invoke_runtime_methods(monkeypatch):
    calls: list[tuple[str, dict[str, Any], object]] = []

    def _fake_invoke(*, method, params, ctx, local_call):
        calls.append((method, params, local_call))
        return {"ok": True}

    monkeypatch.setattr(chat_command, "invoke", _fake_invoke)

    chat_command._cmd_ensure(
        SimpleNamespace(force_new=True),
        ctx=cast(CLIContext, object()),
    )
    chat_command._cmd_status(
        SimpleNamespace(session_id="sess-chat", ensure_session=True),
        ctx=cast(CLIContext, object()),
    )
    chat_command._cmd_send(
        SimpleNamespace(message="hello", session_id="sess-chat", agent_id="default"),
        ctx=cast(CLIContext, object()),
    )
    chat_command._cmd_retry(
        SimpleNamespace(session_id="sess-chat"),
        ctx=cast(CLIContext, object()),
    )

    assert calls == [
        ("chat.ensure_session", {"force_new": True}, chat_command._runtime_only_local_fallback),
        (
            "chat.get_status",
            {"ensure_session": True, "session_id": "sess-chat"},
            chat_command._runtime_only_local_fallback,
        ),
        (
            "chat.send",
            {"message": "hello", "session_id": "sess-chat", "agent_id": "default"},
            chat_command._runtime_only_local_fallback,
        ),
        (
            "chat.retry",
            {"session_id": "sess-chat"},
            chat_command._runtime_only_local_fallback,
        ),
    ]


def test_session_runtime_commands_invoke_runtime_methods(monkeypatch):
    calls: list[tuple[str, dict[str, Any], object]] = []

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx
        calls.append((method, params, local_call))
        return {"ok": True}

    monkeypatch.setattr(session_command, "invoke", _fake_invoke)

    session_command._cmd_create(
        SimpleNamespace(
            agent_id="default",
            session_id="sess-new",
            workspace_path="/tmp/ws",
            workspace_mode="isolated",
            model_backend="openai",
            model_name="gpt-x",
            max_cycles=12,
            bash_shell="bash",
            windows_shell_priority="git-bash,powershell",
        ),
        ctx=cast(CLIContext, object()),
    )
    session_command._cmd_send(
        SimpleNamespace(
            session_id="sess-new",
            message="run",
            agent_id="default",
            attachment_paths="/tmp/a.txt,/tmp/b.txt",
        ),
        ctx=cast(CLIContext, object()),
    )
    session_command._cmd_retry(
        SimpleNamespace(session_id="sess-new"),
        ctx=cast(CLIContext, object()),
    )
    session_command._cmd_approve(
        SimpleNamespace(session_id="sess-new", decision="approve", request_id="req-1"),
        ctx=cast(CLIContext, object()),
    )
    session_command._cmd_list(SimpleNamespace(), ctx=cast(CLIContext, object()))

    assert calls == [
        (
            "agent.create_session",
            {
                "agent_id": "default",
                "session_id": "sess-new",
                "workspace_path": "/tmp/ws",
                "workspace_mode": "isolated",
                "model_backend": "openai",
                "model_name": "gpt-x",
                "max_cycles": 12,
                "bash_shell": "bash",
                "windows_shell_priority": ["git-bash", "powershell"],
            },
            session_command._runtime_only_local_fallback,
        ),
        (
            "agent.send",
            {
                "session_id": "sess-new",
                "message": "run",
                "agent_id": "default",
                "attachment_paths": ["/tmp/a.txt", "/tmp/b.txt"],
            },
            session_command._runtime_only_local_fallback,
        ),
        (
            "agent.retry",
            {"session_id": "sess-new"},
            session_command._runtime_only_local_fallback,
        ),
        (
            "agent.approve",
            {"session_id": "sess-new", "decision": "approve", "request_id": "req-1"},
            session_command._runtime_only_local_fallback,
        ),
        (
            "agent.list_sessions",
            {},
            session_command._runtime_only_local_fallback,
        ),
    ]


def test_task_transcript_commands_invoke_runtime_methods(monkeypatch):
    calls: list[tuple[str, dict[str, Any], object]] = []

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx
        calls.append((method, params, local_call))
        return {"ok": True}

    monkeypatch.setattr(task_command, "invoke", _fake_invoke)

    task_command._cmd_transcript(
        SimpleNamespace(session_id="sess-1", role="assistant", limit=80, offset=10),
        ctx=cast(CLIContext, object()),
    )
    task_command._cmd_transcript_stats(
        SimpleNamespace(session_id="sess-1"),
        ctx=cast(CLIContext, object()),
    )
    task_command._cmd_transcript_search(
        SimpleNamespace(
            query="error",
            session_id="sess-1",
            role="tool",
            cycle="3",
            limit=15,
            offset=2,
        ),
        ctx=cast(CLIContext, object()),
    )

    assert calls == [
        (
            "task_history.transcript_turns",
            {"session_id": "sess-1", "role": "assistant", "limit": 80, "offset": 10},
            task_command._runtime_only_local_fallback,
        ),
        (
            "task_history.transcript_stats",
            {"session_id": "sess-1"},
            task_command._runtime_only_local_fallback,
        ),
        (
            "task_history.transcript_search",
            {
                "query": "error",
                "limit": 15,
                "offset": 2,
                "session_id": "sess-1",
                "role": "tool",
                "cycle": 3,
            },
            task_command._runtime_only_local_fallback,
        ),
    ]


def test_task_transcript_search_rejects_invalid_cycle():
    with pytest.raises(CLIError) as exc_info:
        task_command._cmd_transcript_search(
            SimpleNamespace(
                query="error",
                session_id="",
                role="",
                cycle="bad",
                limit=20,
                offset=0,
            ),
            ctx=cast(CLIContext, object()),
        )
    assert exc_info.value.code == "invalid_arguments"


def test_im_workspace_agent_context_commands_invoke_runtime_methods(monkeypatch, tmp_path):
    im_calls: list[tuple[str, dict[str, Any], object]] = []
    workspace_calls: list[tuple[str, dict[str, Any], object]] = []
    agent_context_calls: list[tuple[str, dict[str, Any], object]] = []

    def _fake_im_invoke(*, method, params, ctx, local_call):
        del ctx
        im_calls.append((method, params, local_call))
        return {"ok": True}

    def _fake_workspace_invoke(*, method, params, ctx, local_call):
        del ctx
        workspace_calls.append((method, params, local_call))
        return {"ok": True}

    def _fake_agent_context_invoke(*, method, params, ctx, local_call):
        del ctx
        agent_context_calls.append((method, params, local_call))
        return {"ok": True}

    monkeypatch.setattr(im_command, "invoke", _fake_im_invoke)
    monkeypatch.setattr(workspace_command, "invoke", _fake_workspace_invoke)
    monkeypatch.setattr(agent_context_command, "invoke", _fake_agent_context_invoke)

    im_command._cmd_accounts(
        SimpleNamespace(channel="feishu", include_disabled="false"),
        ctx=cast(CLIContext, object()),
    )
    im_command._cmd_session_mapping(
        SimpleNamespace(
            account_id="12",
            session_id="sess-im",
            channel="feishu",
            session_key="k-1",
            chat_id="c-1",
        ),
        ctx=cast(CLIContext, object()),
    )

    workspace_command._cmd_preview(
        SimpleNamespace(relative_path="notes.txt", workspace_path="/tmp/ws", max_chars=512),
        ctx=cast(CLIContext, object()),
    )
    workspace_command._cmd_state(
        SimpleNamespace(workspace_path=""),
        ctx=cast(CLIContext, object()),
    )

    source_file = tmp_path / "USER.md"
    source_file.write_text("hello", encoding="utf-8")
    agent_context_command._cmd_read(
        SimpleNamespace(agent_id="default", target="USER.md"),
        ctx=cast(CLIContext, object()),
    )
    agent_context_command._cmd_write(
        SimpleNamespace(agent_id="default", target="MEMORY.md", content="", file=str(source_file)),
        ctx=cast(CLIContext, object()),
    )

    assert im_calls == [
        (
            "im.list_accounts",
            {"channel": "feishu", "include_disabled": False},
            im_command._runtime_only_local_fallback,
        ),
        (
            "im.get_main_session_mapping",
            {
                "account_id": 12,
                "session_id": "sess-im",
                "channel": "feishu",
                "session_key": "k-1",
                "chat_id": "c-1",
            },
            im_command._runtime_only_local_fallback,
        ),
    ]
    assert workspace_calls == [
        (
            "workspace.preview",
            {"workspace_path": "/tmp/ws", "relative_path": "notes.txt", "max_chars": 512},
            workspace_command._runtime_only_local_fallback,
        ),
        (
            "workspace.state",
            {},
            workspace_command._runtime_only_local_fallback,
        ),
    ]
    assert agent_context_calls == [
        (
            "agent_context.read",
            {"agent_id": "default", "target": "user"},
            agent_context_command._runtime_only_local_fallback,
        ),
        (
            "agent_context.write",
            {"agent_id": "default", "target": "memory_main", "content": "hello"},
            agent_context_command._runtime_only_local_fallback,
        ),
    ]


def test_agent_context_status_and_bundle_require_agent_id():
    for func in (agent_context_command._cmd_status, agent_context_command._cmd_bundle):
        with pytest.raises(CLIError) as exc_info:
            func(SimpleNamespace(agent_id=""), ctx=cast(CLIContext, object()))
        assert exc_info.value.code == "missing_required"


def test_browser_commands_invoke_runtime_methods_and_write_output(monkeypatch, tmp_path):
    browser_calls: list[tuple[str, dict[str, Any], object]] = []
    screenshot_bytes = b"fake-jpeg-binary"

    def _fake_browser_invoke(*, method, params, ctx, local_call):
        del ctx
        browser_calls.append((method, params, local_call))
        if method == "browser.get_screenshot":
            return {
                "tab_id": "tab-9",
                "scope_key": "sess-browser",
                "image_base64": "ZmFrZS1qcGVnLWJpbmFyeQ==",
            }
        return {"ok": True}

    monkeypatch.setattr(browser_command, "invoke", _fake_browser_invoke)

    browser_command._cmd_status(
        SimpleNamespace(session_id="sess-browser"),
        ctx=cast(CLIContext, object()),
    )
    browser_command._cmd_tabs(
        SimpleNamespace(session_id=""),
        ctx=cast(CLIContext, object()),
    )

    output_path = tmp_path / "captures" / "browser.jpg"
    result = browser_command._cmd_screenshot(
        SimpleNamespace(
            tab_id="tab-9",
            session_id="sess-browser",
            quality=72,
            output=str(output_path),
        ),
        ctx=cast(CLIContext, object()),
    )

    assert browser_calls == [
        (
            "browser.get_status",
            {"session_id": "sess-browser"},
            browser_command._runtime_only_local_fallback,
        ),
        (
            "browser.get_tabs",
            {},
            browser_command._runtime_only_local_fallback,
        ),
        (
            "browser.get_screenshot",
            {"session_id": "sess-browser", "tab_id": "tab-9", "quality": 72},
            browser_command._runtime_only_local_fallback,
        ),
    ]
    assert output_path.read_bytes() == screenshot_bytes
    assert result == {
        "tab_id": "tab-9",
        "scope_key": "sess-browser",
        "output_path": str(output_path.resolve()),
        "bytes_written": len(screenshot_bytes),
    }


def test_browser_screenshot_rejects_invalid_quality():
    with pytest.raises(CLIError) as exc_info:
        browser_command._cmd_screenshot(
            SimpleNamespace(tab_id="", session_id="", quality=101, output=""),
            ctx=cast(CLIContext, object()),
        )
    assert exc_info.value.code == "invalid_arguments"
