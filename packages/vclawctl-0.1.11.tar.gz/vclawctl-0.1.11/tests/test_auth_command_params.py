from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest

from vclawctl.adapters.sqlite.db import connect, read_config_json, upsert_config_json
from vclawctl.commands import auth as auth_command
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError


def _ctx(data_dir) -> CLIContext:
    return CLIContext(
        data_dir=data_dir,
        db_path=data_dir / "v_claw.db",
        pretty=False,
        mode="api",
        api_base_url="http://127.0.0.1:7799/api/control/v1",
        auth_token="token",
        timeout_seconds=10.0,
        logger=None,
    )


def test_auth_runtime_commands_invoke_runtime_methods(monkeypatch, data_dir):
    calls: list[tuple[str, dict[str, Any], object]] = []
    child_runs: list[tuple[list[str], dict[str, str]]] = []

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx
        calls.append((method, params, local_call))
        if method == "auth.resolve_env":
            return {
                "provider": "feishu",
                "principal": "requester",
                "env": {
                    "FEISHU_AUTH_MODE": "user",
                    "FEISHU_USER_ACCESS_TOKEN": "user_access_live",
                },
            }
        return {"provider": "feishu", "principal": params.get("principal", "tenant")}

    def _fake_run(command, env, check=False):  # noqa: ANN001
        del check
        child_runs.append((list(command), dict(env)))
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(auth_command, "invoke", _fake_invoke)
    monkeypatch.setattr(auth_command.subprocess, "run", _fake_run)

    ctx = _ctx(data_dir)
    auth_command._cmd_current(
        SimpleNamespace(provider="feishu", session_id="sess-auth"),
        ctx=ctx,
    )
    auth_command._cmd_use(
        SimpleNamespace(provider="feishu", principal="requester", session_id="sess-auth"),
        ctx=ctx,
    )
    auth_command._cmd_reset(
        SimpleNamespace(provider="feishu", session_id="sess-auth"),
        ctx=ctx,
    )
    result = auth_command._cmd_exec(
        SimpleNamespace(
            provider="feishu",
            principal="requester",
            session_id="sess-auth",
            command=["--", "feishu", "auth", "whoami"],
        ),
        ctx=ctx,
    )

    assert calls == [
        (
            "auth.current",
            {"session_id": "sess-auth", "provider": "feishu"},
            auth_command._runtime_only_local_fallback,
        ),
        (
            "auth.use",
            {
                "session_id": "sess-auth",
                "provider": "feishu",
                "principal": "requester",
            },
            auth_command._runtime_only_local_fallback,
        ),
        (
            "auth.reset",
            {"session_id": "sess-auth", "provider": "feishu"},
            auth_command._runtime_only_local_fallback,
        ),
        (
            "auth.resolve_env",
            {
                "session_id": "sess-auth",
                "provider": "feishu",
                "principal": "requester",
            },
            auth_command._runtime_only_local_fallback,
        ),
    ]
    assert result["session_id"] == "sess-auth"
    assert result["provider"] == "feishu"
    assert result["principal"] == "requester"
    assert result["exit_code"] == 0
    assert len(child_runs) == 1
    assert child_runs[0][0] == ["feishu", "auth", "whoami"]
    assert child_runs[0][1]["FEISHU_AUTH_MODE"] == "user"
    assert child_runs[0][1]["FEISHU_USER_ACCESS_TOKEN"] == "user_access_live"


def test_auth_resolve_session_id_prefers_env_then_db(monkeypatch, data_dir):
    ctx = _ctx(data_dir)

    monkeypatch.setenv("VCLAW_SESSION_ID", "env-session")
    assert auth_command._resolve_session_id(ctx, "") == "env-session"

    monkeypatch.delenv("VCLAW_SESSION_ID", raising=False)
    with connect(ctx.db_path, write=True) as conn:
        payload = read_config_json(conn)
        chat_cfg = dict(payload.get("chat") or {})
        chat_cfg["main_session_id"] = "db-session"
        payload["chat"] = chat_cfg
        upsert_config_json(conn, payload)

    assert auth_command._resolve_session_id(ctx, "") == "db-session"
    assert auth_command._resolve_session_id(ctx, "explicit-session") == "explicit-session"


def test_auth_resolve_session_id_requires_source(data_dir):
    ctx = _ctx(data_dir)
    with pytest.raises(CLIError) as exc_info:
        auth_command._resolve_session_id(ctx, "")
    assert exc_info.value.code == "missing_required"


def test_auth_exec_requires_command(data_dir):
    ctx = _ctx(data_dir)
    with pytest.raises(CLIError) as exc_info:
        auth_command._cmd_exec(
            SimpleNamespace(
                provider="feishu",
                principal="tenant",
                session_id="sess-auth",
                command=[],
            ),
            ctx=ctx,
        )
    assert exc_info.value.code == "missing_required"


def test_auth_exec_raises_on_child_failure(monkeypatch, data_dir):
    def _fake_invoke(*, method, params, ctx, local_call):
        del method, params, ctx, local_call
        return {
            "provider": "feishu",
            "principal": "tenant",
            "env": {"FEISHU_AUTH_MODE": "tenant"},
        }

    def _fake_run(command, env, check=False):  # noqa: ANN001
        del command, env, check
        return SimpleNamespace(returncode=9)

    monkeypatch.setattr(auth_command, "invoke", _fake_invoke)
    monkeypatch.setattr(auth_command.subprocess, "run", _fake_run)

    ctx = _ctx(data_dir)
    with pytest.raises(CLIError) as exc_info:
        auth_command._cmd_exec(
            SimpleNamespace(
                provider="feishu",
                principal="tenant",
                session_id="sess-auth",
                command=["--", "feishu", "auth", "whoami"],
            ),
            ctx=ctx,
        )
    assert exc_info.value.code == "child_process_failed"
