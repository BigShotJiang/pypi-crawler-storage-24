from __future__ import annotations

import json
from datetime import datetime, timezone

import pytest

from vclawctl.cli import main


def _run_cli(args: list[str], capsys):
    code = main(["--mode", "db", *args])
    out = capsys.readouterr().out.strip()
    payload = json.loads(out) if out else {}
    return code, payload


def test_config_set_get_and_patch(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "config",
            "set",
            "--key",
            "chat.default_agent_id",
            "--value-json",
            '"assistant-a"',
        ],
        capsys,
    )
    assert code == 0
    assert payload["ok"] is True

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "config",
            "get",
            "--key",
            "chat.default_agent_id",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["value"] == "assistant-a"

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "config",
            "patch",
            "--params-json",
            '{"agent": {"language": "en-US"}}',
        ],
        capsys,
    )
    assert code == 0
    assert payload["ok"] is True


def test_config_get_defaults_to_summary(data_dir, capsys):
    large_backups = {
        f"model_{idx}": [f"ep_{idx}", {"endpoint_id": f"ep_{idx}"}] for idx in range(24)
    }
    patch_payload = json.dumps(
        {
            "im": {
                "enabled": True,
                "feishu_transport": "long_connection",
            },
            "vectorvein": {
                "enabled": True,
                "model_endpoint_backups": large_backups,
            },
        },
        ensure_ascii=False,
    )
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "config",
            "patch",
            "--params-json",
            patch_payload,
        ],
        capsys,
    )
    assert code == 0
    assert payload["ok"] is True

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "config",
            "get",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["view"] == "summary"
    assert payload["data"]["config"]["chat"]["default_agent_id"] == "default"
    assert payload["data"]["config"]["im"]["feishu_transport"] == "long_connection"
    assert payload["data"]["config"]["vectorvein"]["model_endpoint_backups"].startswith(
        "<truncated object:"
    )
    assert payload["data"]["truncated_paths"] == [
        {
            "path": "vectorvein.model_endpoint_backups",
            "kind": "object",
            "items": 24,
        }
    ]


def test_config_get_full_and_match_views(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "config",
            "patch",
            "--params-json",
            '{"im":{"enabled":true,"feishu_transport":"long_connection"}}',
        ],
        capsys,
    )
    assert code == 0
    assert payload["ok"] is True

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "config",
            "get",
            "--full",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["view"] == "full"
    assert payload["data"]["config"]["im"]["feishu_transport"] == "long_connection"

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "config",
            "get",
            "--match",
            "feishu",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["view"] == "match"
    assert payload["data"]["query"] == "feishu"
    assert payload["data"]["match_count"] == 1
    assert payload["data"]["matches"] == [
        {
            "path": "im.feishu_transport",
            "reasons": ["path"],
            "value": "long_connection",
        }
    ]


def test_schedule_create_list_toggle_delete(data_dir, capsys):
    params = (
        '{'
        '"name":"nightly",'
        '"schedule_type":"interval",'
        '"schedule_config":{"every_seconds":300},'
        '"prompt":"run report"'
        '}'
    )
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "schedule",
            "create",
            "--params-json",
            params,
        ],
        capsys,
    )
    assert code == 0
    task_id = payload["data"]["task_id"]

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "schedule", "list", "--task-id", task_id],
        capsys,
    )
    assert code == 0
    assert payload["data"]["tasks"][0]["task_id"] == task_id

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "schedule", "toggle", "--task-id", task_id],
        capsys,
    )
    assert code == 0
    assert payload["data"]["ok"] is True

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "schedule", "delete", "--task-id", task_id, "--yes"],
        capsys,
    )
    assert code == 0
    assert payload["data"]["ok"] is True


def test_schedule_create_once_with_after_shortcut(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "schedule",
            "create",
            "--name",
            "once-hi",
            "--prompt",
            "Hi",
            "--after",
            "2m",
        ],
        capsys,
    )
    assert code == 0
    task_id = payload["data"]["task_id"]

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "schedule", "list", "--task-id", task_id],
        capsys,
    )
    assert code == 0
    task = payload["data"]["tasks"][0]
    assert task["schedule_type"] == "once"
    at_text = task["schedule_config"]["at"]
    run_at = datetime.fromisoformat(at_text.replace("Z", "+00:00"))
    delay_seconds = (run_at - datetime.now(timezone.utc)).total_seconds()
    assert 60 <= delay_seconds <= 180


def test_schedule_create_rejects_mixed_params_json_and_after(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "schedule",
            "create",
            "--params-json",
            '{"name":"once-hi","prompt":"Hi","schedule_type":"once","schedule_config":{"at":"2026-03-01T12:00:00Z"}}',
            "--after",
            "30s",
        ],
        capsys,
    )
    assert code == 2
    assert payload["code"] == "invalid_arguments"


def test_heartbeat_commands_in_db_mode(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "heartbeat",
            "set",
            "--main-agent-id",
            "ops-agent",
            "--enabled",
            "true",
            "--interval-seconds",
            "1200",
            "--notify-policy",
            "im_owner_or_chat",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["config"]["main_agent_id"] == "ops-agent"

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "heartbeat",
            "add-item",
            "--text",
            "检查今天的重要消息",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["added_item"] == "检查今天的重要消息"

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "heartbeat",
            "items",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["item_count"] == 1
    assert payload["data"]["items"][0]["text"] == "检查今天的重要消息"

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "heartbeat",
            "show",
            "--task-limit",
            "0",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["agent_id"] == "ops-agent"
    assert payload["data"]["runtime_available"] is False
    assert payload["data"]["tasks"] == []


def test_agent_create_update_delete(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "agent",
            "create",
            "--params-json",
            '{"name":"ops-agent","tools":["memory_search","schedule_task"]}',
        ],
        capsys,
    )
    assert code == 0
    agent_id = payload["data"]["agent"]["agent_id"]
    tools = payload["data"]["agent"]["tools"]
    assert "schedule_task" not in tools

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "agent",
            "update",
            "--agent-id",
            agent_id,
            "--updates-json",
            '{"language":"en-US","max_cycles":9}',
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["agent"]["language"] == "en-US"
    assert payload["data"]["agent"]["max_cycles"] == 9

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "agent",
            "delete",
            "--agent-id",
            agent_id,
            "--yes",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["ok"] is True


def test_skill_list_and_bind_agent(data_dir, capsys):
    db_path = data_dir / "v_claw.db"
    import sqlite3
    import time

    conn = sqlite3.connect(db_path)
    now = time.time()
    conn.execute(
        """
        INSERT INTO skills_catalog(
            skill_id, name, description, version, source_type,
            source_path, skill_dir, manifest_json, required_tools_json,
            compatibility, enabled, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "skill_alpha",
            "Skill Alpha",
            "Demo",
            "0.0.1",
            "imported",
            "/tmp/alpha.skill",
            "/tmp/skills/alpha",
            "{}",
            "[]",
            "",
            1,
            now,
            now,
        ),
    )
    conn.commit()
    conn.close()

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "skill",
            "list",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["skills"][0]["skill_id"] == "skill_alpha"

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "skill",
            "bind",
            "--skill-id",
            "skill_alpha",
            "--agent-id",
            "default",
            "--set-default-agent",
            "--reset-session",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["added"] is True
    assert "skill_alpha" in payload["data"]["agent"]["skills"]
    assert payload["data"]["installation"]["skill_id"] == "skill_alpha"
    assert payload["data"]["chat_state"]["default_agent_id"] == "default"
    assert payload["data"]["chat_state"]["session_id"] == ""

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            "skill.list_catalog",
            "--params-json",
            "{}",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["skills"][0]["skill_id"] == "skill_alpha"


def test_skill_import_requires_runtime_in_db_mode(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "skill",
            "import",
            "--file-path",
            "/tmp/demo.skill",
        ],
        capsys,
    )
    assert code == 2
    assert payload["code"] == "runtime_required"


def test_skill_lifecycle_install_toggle_validate_uninstall(data_dir, capsys):
    db_path = data_dir / "v_claw.db"
    import sqlite3
    import time

    imported_skill_dir = data_dir / "skills" / "imported" / "skill_alpha"
    imported_skill_dir.mkdir(parents=True, exist_ok=True)
    (imported_skill_dir / "SKILL.md").write_text("# skill alpha", encoding="utf-8")

    conn = sqlite3.connect(db_path)
    now = time.time()
    conn.execute(
        """
        INSERT INTO skills_catalog(
            skill_id, name, description, version, source_type,
            source_path, skill_dir, manifest_json, required_tools_json,
            compatibility, enabled, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "skill_alpha",
            "Skill Alpha",
            "Demo",
            "0.0.1",
            "imported",
            "/tmp/alpha.skill",
            imported_skill_dir.as_posix(),
            "{}",
            "[]",
            "",
            1,
            now,
            now,
        ),
    )
    conn.commit()
    conn.close()

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "skill",
            "get",
            "--skill-id",
            "skill_alpha",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["skill"]["skill_id"] == "skill_alpha"

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "skill",
            "install",
            "--skill-id",
            "skill_alpha",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["installation"]["skill_id"] == "skill_alpha"
    assert payload["data"]["installation"]["is_enabled"] is True

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "skill",
            "disable",
            "--skill-id",
            "skill_alpha",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["installation"]["is_enabled"] is False

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "skill",
            "validate",
            "--skill-id",
            "skill_alpha",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["ready"] is False
    assert payload["data"]["blocking_count"] == 1
    assert payload["data"]["items"][0]["status"] == "disabled"

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "skill",
            "enable",
            "--skill-id",
            "skill_alpha",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["installation"]["is_enabled"] is True

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            "skill.validate",
            "--params-json",
            '{"required_skills":["skill_alpha"]}',
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["ready"] is True

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "skill",
            "uninstall",
            "--skill-id",
            "skill_alpha",
        ],
        capsys,
    )
    assert code == 2
    assert payload["code"] == "confirmation_required"

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "skill",
            "uninstall",
            "--skill-id",
            "skill_alpha",
            "--yes",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["ok"] is True
    assert payload["data"]["deleted_files"] is True

    assert not imported_skill_dir.exists()
    conn = sqlite3.connect(db_path)
    catalog_row = conn.execute(
        "SELECT 1 FROM skills_catalog WHERE skill_id = ?",
        ("skill_alpha",),
    ).fetchone()
    installation_row = conn.execute(
        "SELECT 1 FROM skill_installations WHERE skill_id = ?",
        ("skill_alpha",),
    ).fetchone()
    conn.close()
    assert catalog_row is None
    assert installation_row is None


def test_skill_disable_agent_scope_creates_override_instead_of_mutating_global(data_dir, capsys):
    db_path = data_dir / "v_claw.db"
    import sqlite3
    import time

    conn = sqlite3.connect(db_path)
    now = time.time()
    conn.execute(
        """
        INSERT INTO skills_catalog(
            skill_id, name, description, version, source_type,
            source_path, skill_dir, manifest_json, required_tools_json,
            compatibility, enabled, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "skill_beta",
            "Skill Beta",
            "Demo",
            "0.0.1",
            "local",
            "",
            "",
            "{}",
            "[]",
            "",
            1,
            now,
            now,
        ),
    )
    conn.execute(
        """
        INSERT INTO skill_installations(
            installation_id, skill_id, scope_key,
            is_enabled, config_json, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "inst_global_beta",
            "skill_beta",
            "global",
            1,
            "{}",
            now,
            now,
        ),
    )
    conn.commit()
    conn.close()

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "skill",
            "disable",
            "--skill-id",
            "skill_beta",
            "--agent-id",
            "default",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["installation"]["scope_key"] == "agent:default"
    assert payload["data"]["installation"]["is_enabled"] is False

    conn = sqlite3.connect(db_path)
    global_row = conn.execute(
        "SELECT is_enabled FROM skill_installations WHERE skill_id = ? AND scope_key = ?",
        ("skill_beta", "global"),
    ).fetchone()
    agent_row = conn.execute(
        "SELECT is_enabled FROM skill_installations WHERE skill_id = ? AND scope_key = ?",
        ("skill_beta", "agent:default"),
    ).fetchone()
    conn.close()
    assert global_row is not None and int(global_row[0]) == 1
    assert agent_row is not None and int(agent_row[0]) == 0


def test_skill_update_installation_updates_enabled_and_config(data_dir, capsys):
    db_path = data_dir / "v_claw.db"
    import sqlite3
    import time

    conn = sqlite3.connect(db_path)
    now = time.time()
    conn.execute(
        """
        INSERT INTO skills_catalog(
            skill_id, name, description, version, source_type,
            source_path, skill_dir, manifest_json, required_tools_json,
            compatibility, enabled, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "skill_gamma",
            "Skill Gamma",
            "Demo",
            "0.0.1",
            "local",
            "",
            "",
            "{}",
            "[]",
            "",
            1,
            now,
            now,
        ),
    )
    conn.execute(
        """
        INSERT INTO skill_installations(
            installation_id, skill_id, scope_key,
            is_enabled, config_json, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "inst_gamma",
            "skill_gamma",
            "global",
            1,
            '{"region":"us","retry":1}',
            now,
            now,
        ),
    )
    conn.commit()
    conn.close()

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "skill",
            "update-installation",
            "--installation-id",
            "inst_gamma",
            "--enabled",
            "false",
            "--config-json",
            '{"region":"cn","retry":2}',
        ],
        capsys,
    )
    assert code == 0
    installation = payload["data"]["installation"]
    assert installation["installation_id"] == "inst_gamma"
    assert installation["is_enabled"] is False
    assert installation["config"] == {"region": "cn", "retry": 2}

    conn = sqlite3.connect(db_path)
    row = conn.execute(
        """
        SELECT is_enabled, config_json
        FROM skill_installations
        WHERE installation_id = ?
        """,
        ("inst_gamma",),
    ).fetchone()
    conn.close()
    assert row is not None
    assert int(row[0]) == 0
    assert json.loads(str(row[1])) == {"region": "cn", "retry": 2}


def test_task_and_session_queries(data_dir, capsys):
    db_path = data_dir / "v_claw.db"
    import sqlite3
    import time

    conn = sqlite3.connect(db_path)
    conn.execute(
        """
        INSERT INTO task_history(
            task_id, agent_id, session_id, title, prompt,
            session_kind, workspace_path, workspace_source,
            status, cycles_count, created_at, finished_at,
            is_favorite, progress_json, final_answer,
            token_usage_json, agent_name, model_name, parent_task_id, is_sub_task
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "task-main",
            "default",
            "sess-1",
            "T1",
            "hello",
            "task",
            "",
            "global_default",
            "completed",
            3,
            time.time(),
            time.time(),
            0,
            (
                '[{"type":"user_message","cycle":1,"content":"follow up"},'
                '{"type":"llm_response","cycle":1,"content":"working"}]'
            ),
            "done",
            '{"input_tokens": 12, "output_tokens": 4}',
            "",
            "",
            "",
            0,
        ),
    )
    conn.commit()
    conn.close()

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "task", "get", "--task-id", "task-main"],
        capsys,
    )
    assert code == 0
    assert payload["data"]["task"]["session_id"] == "sess-1"
    assert payload["data"]["meta"]["id_model"]["requested_by"] == "task_id"

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "session", "token", "--session-id", "sess-1"],
        capsys,
    )
    assert code == 0
    assert payload["data"]["token_usage"]["input_tokens"] == 12
    assert payload["data"]["meta"]["id_model"]["requested_by"] == "session_id"

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "task", "messages", "--task-id", "task-main"],
        capsys,
    )
    assert code == 0
    assert payload["data"]["total"] >= 3
    assert payload["data"]["messages"][-1]["content"] == "done"
    assert payload["data"]["meta"]["id_model"]["requested_by"] == "task_id"

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "task",
            "search-messages",
            "--task-id",
            "task-main",
            "--query",
            "work",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["total"] == 1
    assert payload["data"]["messages"][0]["content"] == "working"

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "session", "last-message", "--session-id", "sess-1"],
        capsys,
    )
    assert code == 0
    assert payload["data"]["message"]["role"] == "assistant"
    assert payload["data"]["message"]["content"] == "done"
    assert payload["data"]["meta"]["id_model"]["requested_by"] == "session_id"

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "session",
            "messages",
            "--session-id",
            "sess-1",
            "--role",
            "user",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["total"] == 2

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "session",
            "search-messages",
            "--session-id",
            "sess-1",
            "--query",
            "done",
            "--role",
            "assistant",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["total"] == 1


def test_call_namespace_dispatch(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            "settings.get_value",
            "--params-json",
            '{"key":"chat.default_agent_id"}',
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["value"] == "default"


def test_call_memory_namespace_requires_runtime_api(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            "memory.list",
            "--params-json",
            '{"agent_id":"default"}',
        ],
        capsys,
    )
    assert code == 2
    assert payload["ok"] is False
    assert payload["code"] == "runtime_api_required"


def test_memory_subcommand_exists_and_requires_runtime_api(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "memory",
            "list",
            "--agent-id",
            "default",
        ],
        capsys,
    )
    assert code == 2
    assert payload["ok"] is False
    assert payload["code"] == "runtime_api_required"


@pytest.mark.parametrize(
    ("argv", "expected_code"),
    [
        (
            ["session", "create", "--agent-id", "default"],
            "runtime_api_required",
        ),
        (
            ["chat", "ensure", "--force-new"],
            "runtime_api_required",
        ),
        (
            ["task", "transcript", "--session-id", "sess-1"],
            "runtime_api_required",
        ),
        (
            ["im", "status"],
            "runtime_api_required",
        ),
        (
            ["workspace", "state"],
            "runtime_api_required",
        ),
        (
            ["agent-context", "status", "--agent-id", "default"],
            "runtime_api_required",
        ),
        (
            ["browser", "status"],
            "runtime_api_required",
        ),
        (
            ["config", "llm-settings"],
            "runtime_api_required",
        ),
        (
            ["config", "approval-rules"],
            "runtime_api_required",
        ),
        (
            ["config", "vv-binding"],
            "runtime_api_required",
        ),
        (
            ["config", "test-feishu"],
            "runtime_api_required",
        ),
    ],
)
def test_new_runtime_only_subcommands_exist_and_require_runtime_api(
    data_dir,
    capsys,
    argv,
    expected_code,
):
    code, payload = _run_cli(
        ["--data-dir", str(data_dir), *argv],
        capsys,
    )
    assert code == 2
    assert payload["ok"] is False
    assert payload["code"] == expected_code


@pytest.mark.parametrize(
    "method",
    [
        "session.create_session",
        "settings.get_llm_settings",
        "settings.llm_settings",
        "task_history.transcript_turns",
        "im.get_status",
        "workspace.state",
        "agent_context.get_status",
        "browser.get_status",
        "browser.status",
    ],
)
def test_call_new_runtime_namespaces_require_runtime_api(data_dir, capsys, method):
    params_json = "{}"
    if method == "session.create_session":
        params_json = '{"agent_id":"default"}'
    elif method == "task_history.transcript_turns":
        params_json = '{"session_id":"sess-1"}'
    elif method == "agent_context.get_status":
        params_json = '{"agent_id":"default"}'

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            method,
            "--params-json",
            params_json,
        ],
        capsys,
    )
    assert code == 2
    assert payload["ok"] is False
    assert payload["code"] == "runtime_api_required"



def test_preference_quiet_hours_set_get_clear_db_mode(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--mode",
            "db",
            "--data-dir",
            str(data_dir),
            "preference",
            "quiet-hours",
            "get",
            "--agent-id",
            "default",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["quiet_hours"] is None

    code, payload = _run_cli(
        [
            "--mode",
            "db",
            "--data-dir",
            str(data_dir),
            "preference",
            "quiet-hours",
            "set",
            "--agent-id",
            "default",
            "--start",
            "22:00",
            "--end",
            "09:30",
            "--timezone",
            "Asia/Shanghai",
            "--allow-proactive",
            "false",
        ],
        capsys,
    )
    assert code == 0
    quiet_hours = payload["data"]["quiet_hours"]
    assert quiet_hours["quiet_hours_start"] == "22:00"
    assert quiet_hours["quiet_hours_end"] == "09:30"
    assert quiet_hours["allow_proactive_message"] is False

    user_md = (data_dir / "agent_contexts" / "default" / "USER.md").read_text(encoding="utf-8")
    assert "v-claw:quiet-hours:start" in user_md
    assert "22:00 - 09:30" in user_md

    code, payload = _run_cli(
        [
            "--mode",
            "db",
            "--data-dir",
            str(data_dir),
            "preference",
            "quiet-hours",
            "clear",
            "--agent-id",
            "default",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["cleared"] is True

    updated_user_md = (
        data_dir / "agent_contexts" / "default" / "USER.md"
    ).read_text(encoding="utf-8")
    assert "v-claw:quiet-hours:start" not in updated_user_md
