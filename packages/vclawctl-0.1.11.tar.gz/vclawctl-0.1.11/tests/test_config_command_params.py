from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import pytest

from vclawctl.commands import config as config_command
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError


def test_cmd_llm_settings_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        captured["method"] = method
        captured["params"] = params
        captured["ctx"] = ctx
        captured["local_call"] = local_call
        return {"ok": True}

    monkeypatch.setattr(config_command, "invoke", _fake_invoke)

    result = config_command._cmd_llm_settings(SimpleNamespace(), ctx=cast(CLIContext, object()))
    assert result == {"ok": True}
    assert captured["method"] == "settings.get_llm_settings"
    assert captured["params"] == {}
    assert captured["local_call"] is config_command._runtime_only_local_fallback


def test_cmd_update_llm_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True}

    monkeypatch.setattr(config_command, "invoke", _fake_invoke)

    args = SimpleNamespace(settings_json='{"endpoints":[{"id":"ep-1"}]}')
    result = config_command._cmd_update_llm(args, ctx=cast(CLIContext, object()))
    assert result == {"ok": True}
    assert captured["method"] == "settings.update_llm_settings"
    assert captured["params"] == {"llm_settings": {"endpoints": [{"id": "ep-1"}]}}


def test_cmd_update_approval_rule_requires_and_parses_enabled(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True}

    monkeypatch.setattr(config_command, "invoke", _fake_invoke)

    result = config_command._cmd_update_approval_rule(
        SimpleNamespace(rule_id="rule-1", enabled="true"),
        ctx=cast(CLIContext, object()),
    )
    assert result == {"ok": True}
    assert captured["method"] == "settings.update_approval_rule"
    assert captured["params"] == {"rule_id": "rule-1", "enabled": True}

    with pytest.raises(CLIError) as exc_info:
        config_command._cmd_update_approval_rule(
            SimpleNamespace(rule_id="rule-1", enabled=""),
            ctx=cast(CLIContext, object()),
        )
    assert exc_info.value.code == "missing_required"


def test_cmd_vv_bind_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True}

    monkeypatch.setattr(config_command, "invoke", _fake_invoke)

    args = SimpleNamespace(base_url="https://vectorvein.com", api_key="vv-key")
    result = config_command._cmd_vv_bind(args, ctx=cast(CLIContext, object()))
    assert result == {"ok": True}
    assert captured["method"] == "settings.bind_vectorvein"
    assert captured["params"] == {
        "base_url": "https://vectorvein.com",
        "api_key": "vv-key",
    }


def test_cmd_test_embedding_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True}

    monkeypatch.setattr(config_command, "invoke", _fake_invoke)

    args = SimpleNamespace(
        backend="openai",
        model="text-embedding-3-large",
        test_input="hello",
        test_timeout=45.0,
        dimensions="1024",
    )
    result = config_command._cmd_test_embedding(args, ctx=cast(CLIContext, object()))
    assert result == {"ok": True}
    assert captured["method"] == "settings.test_embedding_model"
    assert captured["params"] == {
        "backend": "openai",
        "model": "text-embedding-3-large",
        "timeout_seconds": 45.0,
        "input": "hello",
        "dimensions": 1024,
    }


def test_cmd_test_rerank_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True}

    monkeypatch.setattr(config_command, "invoke", _fake_invoke)

    args = SimpleNamespace(
        backend="cohere",
        model="rerank-v3.5",
        query="apple",
        documents_json='["Apple is a fruit","Banana is yellow"]',
        top_n="2",
        test_timeout=25.0,
    )
    result = config_command._cmd_test_rerank(args, ctx=cast(CLIContext, object()))
    assert result == {"ok": True}
    assert captured["method"] == "settings.test_rerank_model"
    assert captured["params"] == {
        "backend": "cohere",
        "model": "rerank-v3.5",
        "query": "apple",
        "timeout_seconds": 25.0,
        "documents": ["Apple is a fruit", "Banana is yellow"],
        "top_n": 2,
    }


def test_cmd_test_feishu_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        captured["method"] = method
        captured["params"] = params
        return {"ok": True}

    monkeypatch.setattr(config_command, "invoke", _fake_invoke)

    args = SimpleNamespace(
        account_key="default",
        config_json='{"app_id":"cli-app","app_secret":"cli-secret"}',
    )
    result = config_command._cmd_test_feishu(args, ctx=cast(CLIContext, object()))
    assert result == {"ok": True}
    assert captured["method"] == "settings.test_feishu_config"
    assert captured["params"] == {
        "account_key": "default",
        "config": {
            "app_id": "cli-app",
            "app_secret": "cli-secret",
        },
    }


def test_cmd_get_returns_summary_by_default(monkeypatch):
    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        assert method == "settings.get_config"
        assert params == {"key": "", "default": None}
        return {
            "config": {
                "chat": {"default_agent_id": "default"},
                "vectorvein": {
                    "enabled": True,
                    "model_endpoint_backups": {
                        f"model_{idx}": [f"ep_{idx}", {"endpoint_id": f"ep_{idx}"}]
                        for idx in range(24)
                    },
                },
            }
        }

    monkeypatch.setattr(config_command, "invoke", _fake_invoke)

    result = config_command._cmd_get(
        SimpleNamespace(default_json="null", key="", match="", full=False),
        ctx=cast(CLIContext, object()),
    )

    assert result["view"] == "summary"
    assert result["config"]["chat"]["default_agent_id"] == "default"
    assert result["config"]["vectorvein"]["model_endpoint_backups"].startswith("<truncated object:")
    assert result["truncated_paths"] == [
        {
            "path": "vectorvein.model_endpoint_backups",
            "kind": "object",
            "items": 24,
        }
    ]


def test_cmd_get_match_filters_config(monkeypatch):
    def _fake_invoke(*, method, params, ctx, local_call):
        del method, params, ctx, local_call
        return {
            "config": {
                "im": {
                    "enabled": True,
                    "feishu_transport": "long_connection",
                },
                "agent": {"language": "zh-CN"},
            }
        }

    monkeypatch.setattr(config_command, "invoke", _fake_invoke)

    result = config_command._cmd_get(
        SimpleNamespace(default_json="null", key="", match="feishu", full=False),
        ctx=cast(CLIContext, object()),
    )

    assert result["view"] == "match"
    assert result["query"] == "feishu"
    assert result["match_count"] == 1
    assert result["matches"] == [
        {
            "path": "im.feishu_transport",
            "reasons": ["path"],
            "value": "long_connection",
        }
    ]


def test_cmd_get_rejects_incompatible_flags():
    ctx = cast(CLIContext, object())

    with pytest.raises(CLIError) as key_full_exc:
        config_command._cmd_get(
            SimpleNamespace(default_json="null", key="chat.default_agent_id", match="", full=True),
            ctx=ctx,
        )
    assert key_full_exc.value.code == "invalid_arguments"

    with pytest.raises(CLIError) as key_match_exc:
        config_command._cmd_get(
            SimpleNamespace(
                default_json="null",
                key="chat.default_agent_id",
                match="chat",
                full=False,
            ),
            ctx=ctx,
        )
    assert key_match_exc.value.code == "invalid_arguments"

    with pytest.raises(CLIError) as match_full_exc:
        config_command._cmd_get(
            SimpleNamespace(default_json="null", key="", match="chat", full=True),
            ctx=ctx,
        )
    assert match_full_exc.value.code == "invalid_arguments"
