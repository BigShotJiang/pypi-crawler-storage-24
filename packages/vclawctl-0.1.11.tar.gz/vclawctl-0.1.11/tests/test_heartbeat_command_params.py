from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import pytest

from vclawctl.commands import heartbeat as heartbeat_command
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError


def test_cmd_set_builds_patch(monkeypatch):
    captured: dict[str, Any] = {}

    class _FakeSDK:
        def update_config(self, patch):
            captured["patch"] = patch
            return {"config": patch}

    monkeypatch.setattr(heartbeat_command, "_sdk", lambda ctx: _FakeSDK())

    args = SimpleNamespace(
        enabled="true",
        interval_seconds="1800",
        start="08:00",
        end="23:00",
        timezone="Asia/Shanghai",
        main_agent_id="ops-agent",
        notify_policy="im_owner",
    )
    result = heartbeat_command._cmd_set(args, ctx=cast(CLIContext, object()))
    assert result["config"]["main_agent_id"] == "ops-agent"
    assert captured["patch"] == {
        "enabled": "true",
        "interval_seconds": "1800",
        "timezone": "Asia/Shanghai",
        "main_agent_id": "ops-agent",
        "notify_policy": "im_owner",
        "active_hours": {"start": "08:00", "end": "23:00"},
    }


def test_cmd_write_requires_content_or_file():
    args = SimpleNamespace(agent_id="", content="", file="")
    with pytest.raises(CLIError) as exc_info:
        heartbeat_command._cmd_write(args, ctx=cast(CLIContext, object()))
    assert exc_info.value.code == "missing_required"


def test_cmd_remove_item_rejects_missing_selector():
    args = SimpleNamespace(agent_id="", index=0, match="", all_matches="false")
    with pytest.raises(CLIError) as exc_info:
        heartbeat_command._cmd_remove_item(args, ctx=cast(CLIContext, object()))
    assert exc_info.value.code == "missing_required"
