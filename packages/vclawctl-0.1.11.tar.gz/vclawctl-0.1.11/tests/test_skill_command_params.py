from __future__ import annotations

from types import SimpleNamespace

import pytest

from vclawctl.commands import skill as skill_command
from vclawctl.errors import CLIError


def test_cmd_import_passes_validation_mode(monkeypatch):
    captured: dict[str, object] = {}

    def _fake_invoke(method: str, params: dict[str, object], ctx: object) -> dict[str, object]:
        captured["method"] = method
        captured["params"] = params
        captured["ctx"] = ctx
        return {"ok": True}

    monkeypatch.setattr(skill_command, "_invoke_skill", _fake_invoke)

    args = SimpleNamespace(
        file_path="/tmp/demo.skill",
        no_install_globally=False,
        validation_mode="compat",
    )
    result = skill_command._cmd_import(args, ctx=object())
    assert result == {"ok": True}
    assert captured["method"] == "import_package"
    params = captured["params"]
    assert isinstance(params, dict)
    assert params["validation_mode"] == "compat"
    assert params["install_globally"] is True


def test_cmd_import_bind_passes_validation_mode(monkeypatch):
    captured: dict[str, object] = {}

    def _fake_invoke(method: str, params: dict[str, object], ctx: object) -> dict[str, object]:
        captured["method"] = method
        captured["params"] = params
        captured["ctx"] = ctx
        return {"ok": True}

    monkeypatch.setattr(skill_command, "_invoke_skill", _fake_invoke)

    args = SimpleNamespace(
        file_path="/tmp/demo.skill",
        agent_id="default",
        no_install_globally=True,
        validation_mode="minimal",
        bind_agent=True,
        set_default_agent=True,
        reset_session=True,
        no_ensure_installed=False,
    )
    result = skill_command._cmd_import_bind(args, ctx=object())
    assert result == {"ok": True}
    assert captured["method"] == "import_and_bind"
    params = captured["params"]
    assert isinstance(params, dict)
    assert params["validation_mode"] == "minimal"
    assert params["install_globally"] is False


def test_cmd_install_passes_scope_enabled_and_config(monkeypatch):
    captured: dict[str, object] = {}

    def _fake_invoke(method: str, params: dict[str, object], ctx: object) -> dict[str, object]:
        captured["method"] = method
        captured["params"] = params
        captured["ctx"] = ctx
        return {"ok": True}

    monkeypatch.setattr(skill_command, "_invoke_skill", _fake_invoke)

    args = SimpleNamespace(
        skill_id="skill_alpha",
        agent_id="agent-x",
        disabled=True,
        config_json='{"region":"cn","retry":2}',
    )
    result = skill_command._cmd_install(args, ctx=object())
    assert result == {"ok": True}
    assert captured["method"] == "install"
    params = captured["params"]
    assert isinstance(params, dict)
    assert params["skill_id"] == "skill_alpha"
    assert params["agent_id"] == "agent-x"
    assert params["is_enabled"] is False
    assert params["config"] == {"region": "cn", "retry": 2}


def test_cmd_update_installation_passes_enabled_and_config(monkeypatch):
    captured: dict[str, object] = {}

    def _fake_invoke(method: str, params: dict[str, object], ctx: object) -> dict[str, object]:
        captured["method"] = method
        captured["params"] = params
        captured["ctx"] = ctx
        return {"ok": True}

    monkeypatch.setattr(skill_command, "_invoke_skill", _fake_invoke)

    args = SimpleNamespace(
        installation_id="inst_alpha",
        enabled="false",
        config_json='{"region":"cn","retry":2}',
    )
    result = skill_command._cmd_update_installation(args, ctx=object())
    assert result == {"ok": True}
    assert captured["method"] == "update_installation"
    params = captured["params"]
    assert isinstance(params, dict)
    assert params["installation_id"] == "inst_alpha"
    assert params["is_enabled"] is False
    assert params["config"] == {"region": "cn", "retry": 2}


def test_cmd_update_installation_requires_enabled_or_config():
    args = SimpleNamespace(
        installation_id="inst_alpha",
        enabled=None,
        config_json=None,
    )
    with pytest.raises(CLIError) as exc_info:
        skill_command._cmd_update_installation(args, ctx=object())
    assert exc_info.value.code == "missing_required"


def test_cmd_uninstall_requires_yes():
    args = SimpleNamespace(skill_id="skill_alpha", yes=False)
    with pytest.raises(CLIError) as exc_info:
        skill_command._cmd_uninstall(args, ctx=object())
    assert "requires --yes" in str(exc_info.value)


def test_cmd_validate_passes_required_skills(monkeypatch):
    captured: dict[str, object] = {}

    def _fake_invoke(method: str, params: dict[str, object], ctx: object) -> dict[str, object]:
        captured["method"] = method
        captured["params"] = params
        captured["ctx"] = ctx
        return {"ready": True}

    monkeypatch.setattr(skill_command, "_invoke_skill", _fake_invoke)
    args = SimpleNamespace(skill_ids=["skill_a", "skill_b"], agent_id="default")
    result = skill_command._cmd_validate(args, ctx=object())
    assert result == {"ready": True}
    assert captured["method"] == "validate_required"
    params = captured["params"]
    assert isinstance(params, dict)
    assert params["required_skills"] == ["skill_a", "skill_b"]
    assert params["agent_id"] == "default"
