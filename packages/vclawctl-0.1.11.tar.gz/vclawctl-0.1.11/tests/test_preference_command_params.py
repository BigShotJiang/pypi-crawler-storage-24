from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import pytest

from vclawctl.commands import preference as preference_command
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError


def test_cmd_set_quiet_hours_invokes_runtime_method(monkeypatch):
    captured: dict[str, Any] = {}

    def _fake_invoke(*, method, params, ctx, local_call):
        captured["method"] = method
        captured["params"] = params
        captured["ctx"] = ctx
        captured["local_call"] = local_call
        return {"quiet_hours": {"quiet_hours_start": "22:00", "quiet_hours_end": "09:30"}}

    monkeypatch.setattr(preference_command, "invoke", _fake_invoke)

    args = SimpleNamespace(
        agent_id="default",
        start="22:00",
        end="9:30",
        timezone="Asia/Shanghai",
        allow_proactive="true",
    )
    result = preference_command._cmd_set_quiet_hours(args, ctx=cast(CLIContext, object()))
    assert result["quiet_hours"]["quiet_hours_start"] == "22:00"
    assert captured["method"] == "preference.set_quiet_hours"
    params = cast(dict[str, Any], captured["params"])
    assert params == {
        "agent_id": "default",
        "start": "22:00",
        "end": "09:30",
        "timezone": "Asia/Shanghai",
        "allow_proactive_message": True,
    }


def test_cmd_get_and_clear_quiet_hours_invoke_runtime_method(monkeypatch):
    calls: list[tuple[str, dict[str, Any]]] = []

    def _fake_invoke(*, method, params, ctx, local_call):
        del ctx, local_call
        calls.append((method, params))
        return {"ok": True}

    monkeypatch.setattr(preference_command, "invoke", _fake_invoke)

    preference_command._cmd_get_quiet_hours(
        SimpleNamespace(agent_id="agent-x"),
        ctx=cast(CLIContext, object()),
    )
    preference_command._cmd_clear_quiet_hours(
        SimpleNamespace(agent_id="agent-x"),
        ctx=cast(CLIContext, object()),
    )

    assert calls == [
        ("preference.get_quiet_hours", {"agent_id": "agent-x"}),
        ("preference.clear_quiet_hours", {"agent_id": "agent-x"}),
    ]


def test_cmd_set_quiet_hours_rejects_invalid_time():
    args = SimpleNamespace(
        agent_id="default",
        start="25:00",
        end="09:30",
        timezone="Asia/Shanghai",
        allow_proactive="false",
    )
    with pytest.raises(CLIError) as exc:
        preference_command._cmd_set_quiet_hours(args, ctx=cast(CLIContext, object()))
    assert exc.value.code == "invalid_time"
