from __future__ import annotations

import json
from types import SimpleNamespace

from vclawctl.cli import _build_parser, _resolve_auth_token, main


def _run_cli(args: list[str], capsys):
    code = main(args)
    out = capsys.readouterr().out.strip()
    payload = json.loads(out) if out else {}
    return code, payload


def test_resolve_auth_token_precedence(tmp_path, monkeypatch):
    token_file = tmp_path / "token.txt"
    token_file.write_text("file-token\n", encoding="utf-8")
    monkeypatch.setenv("VCLAWCTL_AUTH_TOKEN", "env-token")

    args = SimpleNamespace(auth_token="arg-token", auth_token_file=str(token_file))
    assert _resolve_auth_token(args) == "arg-token"

    args = SimpleNamespace(auth_token="", auth_token_file=str(token_file))
    assert _resolve_auth_token(args) == "file-token"

    args = SimpleNamespace(auth_token="", auth_token_file="")
    assert _resolve_auth_token(args) == "env-token"


def test_mode_db_uses_local_path(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--mode",
            "db",
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            "settings.get_value",
            "--params-json",
            '{"key":"chat.default_agent_id"}',
        ],
        capsys,
    )
    assert code == 0
    assert payload["ok"] is True
    assert payload["data"]["value"] == "default"


def test_mode_api_requires_token(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--mode",
            "api",
            "--api-base-url",
            "http://127.0.0.1:7799/api/control/v1",
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            "settings.get_value",
            "--params-json",
            '{"key":"chat.default_agent_id"}',
        ],
        capsys,
    )
    assert code == 2
    assert payload["ok"] is False
    assert payload["code"] == "auth_token_required"


def test_mode_api_unavailable_endpoint(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--mode",
            "api",
            "--api-base-url",
            "http://127.0.0.1:1/api/control/v1",
            "--auth-token",
            "dummy-token",
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            "settings.get_value",
            "--params-json",
            '{"key":"chat.default_agent_id"}',
        ],
        capsys,
    )
    assert code == 2
    assert payload["ok"] is False
    assert payload["code"] in {"runtime_unavailable", "runtime_http_error"}


def test_model_test_timeout_flags_do_not_override_global_timeout():
    parser = _build_parser()

    embedding_args = parser.parse_args(
        [
            "--timeout",
            "5",
            "config",
            "test-embedding",
            "--backend",
            "openai",
            "--model",
            "m",
        ]
    )
    assert embedding_args.timeout == 5.0
    assert embedding_args.test_timeout == 30.0

    rerank_args = parser.parse_args(
        [
            "config",
            "test-rerank",
            "--backend",
            "cohere",
            "--model",
            "m",
            "--query",
            "q",
            "--test-timeout",
            "45",
        ]
    )
    assert rerank_args.timeout == 10.0
    assert rerank_args.test_timeout == 45.0



def test_mode_db_preference_call_dispatches_locally(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--mode",
            "db",
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            "preference.get_quiet_hours",
            "--params-json",
            '{"agent_id":"default"}',
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["quiet_hours"] is None
