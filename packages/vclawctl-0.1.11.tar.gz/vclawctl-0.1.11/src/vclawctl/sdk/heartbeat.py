"""Heartbeat-focused SDK helpers for CLI and programmatic use."""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any

from vclawctl.adapters.sqlite.db import connect, loads_json, read_config_json, upsert_config_json
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError

_DEFAULT_HEARTBEAT_TEMPLATE = "# HEARTBEAT.md\n\n## 心跳检查清单\n\n"
_DEFAULT_ACTIVE_HOURS = {"start": "08:00", "end": "23:00"}
_DEFAULT_TIMEZONE = "Asia/Shanghai"
_DEFAULT_NOTIFY_POLICY = "im_owner"
_VALID_NOTIFY_POLICIES = {
    "none",
    "im_owner",
    "chat_inject",
    "im_owner_or_chat",
    "im_owner_and_chat",
}
_HHMM_PATTERN = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
_ITEM_PATTERN = re.compile(
    r"^\s*(?P<marker>(?:[-*+])|(?:\d+\.))\s+(?:(?P<checkbox>\[[ xX]\])\s+)?(?P<text>\S.*)$"
)
_TASK_STATUSES = {"running", "completed", "error", "paused", "pending_approval", "max_cycles"}


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in override.items():
        if isinstance(merged.get(key), dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _normalize_hhmm(value: Any, *, field_name: str, default: str) -> str:
    text = str(value or "").strip() or default
    match = _HHMM_PATTERN.fullmatch(text)
    if not match:
        raise CLIError(f"{field_name} must be HH:MM", code="invalid_time")
    return f"{int(match.group(1)):02d}:{match.group(2)}"


def _normalize_notify_policy(value: Any) -> str:
    policy = str(value or "").strip().lower() or _DEFAULT_NOTIFY_POLICY
    if policy not in _VALID_NOTIFY_POLICIES:
        raise CLIError(
            "notify_policy must be one of "
            "none|im_owner|chat_inject|im_owner_or_chat|im_owner_and_chat",
            code="invalid_notify_policy",
        )
    return policy


def _normalize_interval_seconds(value: Any, *, default: int) -> int:
    try:
        seconds = int(float(value if value is not None else default))
    except Exception as exc:  # noqa: BLE001
        raise CLIError("interval_seconds must be a number", code="invalid_interval") from exc
    return min(max(seconds, 300), 7200)


def _normalize_bool(value: Any, *, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return value != 0
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "on"}:
        return True
    if text in {"0", "false", "no", "off"}:
        return False
    raise CLIError("enabled must be true/false", code="invalid_enabled")


def _normalize_heartbeat_config(raw_config: dict[str, Any]) -> dict[str, Any]:
    heartbeat = raw_config.get("heartbeat", {})
    if not isinstance(heartbeat, dict):
        heartbeat = {}
    chat = raw_config.get("chat", {})
    if not isinstance(chat, dict):
        chat = {}
    active_hours = heartbeat.get("active_hours", {})
    if not isinstance(active_hours, dict):
        active_hours = {}
    main_agent_id = (
        str(heartbeat.get("main_agent_id") or "").strip()
        or str(chat.get("default_agent_id") or "").strip()
        or "default"
    )
    return {
        "enabled": _normalize_bool(heartbeat.get("enabled"), default=False),
        "interval_seconds": _normalize_interval_seconds(
            heartbeat.get("interval_seconds"),
            default=1800,
        ),
        "active_hours": {
            "start": _normalize_hhmm(
                active_hours.get("start"),
                field_name="active_hours.start",
                default=_DEFAULT_ACTIVE_HOURS["start"],
            ),
            "end": _normalize_hhmm(
                active_hours.get("end"),
                field_name="active_hours.end",
                default=_DEFAULT_ACTIVE_HOURS["end"],
            ),
        },
        "timezone": str(heartbeat.get("timezone") or "").strip() or _DEFAULT_TIMEZONE,
        "main_agent_id": main_agent_id,
        "notify_policy": _normalize_notify_policy(heartbeat.get("notify_policy")),
    }


def _normalize_file_content(content: Any) -> str:
    text = str(content or "").replace("\r\n", "\n").replace("\r", "\n")
    return text.rstrip() + "\n"


def _task_row_to_payload(row: Any, *, inferred_heartbeat: bool) -> dict[str, Any]:
    keys = set(row.keys()) if hasattr(row, "keys") else set()

    def _value(name: str, default: Any = "") -> Any:
        return row[name] if name in keys else default

    session_id = str(_value("session_id") or "")
    inferred_origin = (
        "heartbeat"
        if inferred_heartbeat and session_id.strip().lower().startswith("heartbeat-")
        else "user"
    )
    task_origin = str(_value("task_origin", inferred_origin) or "").strip()
    if not task_origin:
        task_origin = inferred_origin

    return {
        "task_id": str(_value("task_id") or ""),
        "agent_id": str(_value("agent_id") or ""),
        "session_id": session_id,
        "title": str(_value("title") or ""),
        "prompt": str(_value("prompt") or ""),
        "session_kind": str(_value("session_kind", "task") or "task"),
        "task_origin": task_origin,
        "workspace_path": str(_value("workspace_path") or ""),
        "workspace_source": str(_value("workspace_source", "global_default") or "global_default"),
        "status": str(_value("status", "running") or "running"),
        "cycles_count": int(_value("cycles_count", 0) or 0),
        "created_at": float(_value("created_at", 0.0) or 0.0),
        "finished_at": (
            float(_value("finished_at"))
            if _value("finished_at", None) is not None
            else None
        ),
        "is_favorite": bool(int(_value("is_favorite", 0) or 0)),
        "progress": loads_json(_value("progress_json", "[]"), []),
        "final_answer": str(_value("final_answer") or ""),
        "token_usage": loads_json(_value("token_usage_json", "{}"), {}),
        "agent_name": str(_value("agent_name") or ""),
        "model_name": str(_value("model_name") or ""),
        "parent_task_id": str(_value("parent_task_id") or ""),
        "is_sub_task": bool(int(_value("is_sub_task", 0) or 0)),
    }


class HeartbeatSDK:
    """High-level heartbeat controller for CLI and Python callers."""

    def __init__(self, ctx: CLIContext) -> None:
        self._ctx = ctx

    def get_config(self) -> dict[str, Any]:
        result = invoke(
            method="settings.get_config",
            params={},
            ctx=self._ctx,
            local_call=self._local_get_config,
        )
        config = result.get("config") if isinstance(result, dict) else {}
        if not isinstance(config, dict):
            config = {}
        return {"config": _normalize_heartbeat_config(config)}

    def update_config(self, patch: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(patch, dict) or not patch:
            raise CLIError("heartbeat config patch required", code="missing_required")

        current = self.get_config()["config"]
        merged = _deep_merge(current, patch)
        normalized = _normalize_heartbeat_config(
            {
                "heartbeat": merged,
                "chat": {"default_agent_id": current["main_agent_id"]},
            }
        )
        invoke(
            method="settings.update_config",
            params={"config": {"heartbeat": normalized}},
            ctx=self._ctx,
            local_call=lambda: self._local_update_config({"heartbeat": patch}),
        )
        return {"config": normalized}

    def status(self) -> dict[str, Any]:
        result = invoke(
            method="heartbeat.get_status",
            params={},
            ctx=self._ctx,
            local_call=self._local_status,
        )
        if "runtime_available" in result:
            return result
        return {"runtime_available": True, **result}

    def read_file(self, *, agent_id: str = "") -> dict[str, Any]:
        resolved_agent_id = self.resolve_agent_id(agent_id)
        result = invoke(
            method="agent_context.read",
            params={"agent_id": resolved_agent_id, "target": "heartbeat"},
            ctx=self._ctx,
            local_call=lambda: self._local_read_file(resolved_agent_id),
        )
        return self._enrich_file_payload(resolved_agent_id, result)

    def write_file(self, *, agent_id: str = "", content: str) -> dict[str, Any]:
        resolved_agent_id = self.resolve_agent_id(agent_id)
        normalized_content = _normalize_file_content(content)
        result = invoke(
            method="agent_context.write",
            params={
                "agent_id": resolved_agent_id,
                "target": "heartbeat",
                "content": normalized_content,
            },
            ctx=self._ctx,
            local_call=lambda: self._local_write_file(resolved_agent_id, normalized_content),
        )
        return self._enrich_file_payload(resolved_agent_id, result)

    def clear_file(self, *, agent_id: str = "") -> dict[str, Any]:
        return self.write_file(agent_id=agent_id, content=_DEFAULT_HEARTBEAT_TEMPLATE)

    def list_items(self, *, agent_id: str = "") -> dict[str, Any]:
        return self.read_file(agent_id=agent_id)

    def add_item(self, *, text: str, agent_id: str = "") -> dict[str, Any]:
        item_text = str(text or "").strip()
        if not item_text:
            raise CLIError("text required", code="missing_required")
        file_payload = self.read_file(agent_id=agent_id)
        content = str(file_payload.get("content") or "")
        if not content.strip():
            content = _DEFAULT_HEARTBEAT_TEMPLATE
        updated = content.rstrip() + "\n- " + item_text + "\n"
        result = self.write_file(agent_id=str(file_payload.get("agent_id") or ""), content=updated)
        result["added_item"] = item_text
        return result

    def remove_item(
        self,
        *,
        agent_id: str = "",
        index: int | None = None,
        match: str = "",
        remove_all: bool = False,
    ) -> dict[str, Any]:
        if index is None and not str(match or "").strip():
            raise CLIError("index or match required", code="missing_required")
        if index is not None and int(index) <= 0:
            raise CLIError("index must be > 0", code="invalid_index")

        file_payload = self.read_file(agent_id=agent_id)
        items = list(file_payload.get("items") or [])
        target_items: list[dict[str, Any]] = []
        if index is not None:
            target_items = [item for item in items if int(item.get("index") or 0) == int(index)]
        else:
            needle = str(match or "").strip().lower()
            target_items = [
                item for item in items
                if needle in str(item.get("text") or "").lower()
            ]
            if target_items and not remove_all:
                target_items = target_items[:1]
        if not target_items:
            raise CLIError("heartbeat item not found", code="not_found")

        removed_line_numbers = {int(item.get("line_number") or 0) for item in target_items}
        original_lines = str(file_payload.get("content") or "").splitlines()
        kept_lines = [
            line for line_number, line in enumerate(original_lines, start=1)
            if line_number not in removed_line_numbers
        ]
        updated_content = (
            "\n".join(kept_lines).rstrip() + "\n"
            if kept_lines
            else _DEFAULT_HEARTBEAT_TEMPLATE
        )
        result = self.write_file(
            agent_id=str(file_payload.get("agent_id") or ""),
            content=updated_content,
        )
        result["removed_items"] = target_items
        return result

    def list_tasks(
        self,
        *,
        agent_id: str = "",
        status: str = "",
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        resolved_agent_id = self.resolve_agent_id(agent_id)
        normalized_limit = max(int(limit or 20), 1)
        normalized_offset = max(int(offset or 0), 0)
        normalized_status = str(status or "").strip()
        if normalized_status and normalized_status not in _TASK_STATUSES:
            raise CLIError(
                "status must be one of running|completed|error|paused|pending_approval|max_cycles",
                code="invalid_status",
            )

        result = invoke(
            method="task_history.list",
            params={
                "agent_id": resolved_agent_id,
                "status": normalized_status or None,
                "limit": normalized_limit,
                "offset": normalized_offset,
                "task_origin": "heartbeat",
                "include_heartbeat_tasks": True,
            },
            ctx=self._ctx,
            local_call=lambda: self._local_list_tasks(
                agent_id=resolved_agent_id,
                status=normalized_status,
                limit=normalized_limit,
                offset=normalized_offset,
            ),
        )
        tasks = result.get("tasks") if isinstance(result, dict) else []
        return {
            "agent_id": resolved_agent_id,
            "tasks": tasks if isinstance(tasks, list) else [],
            "limit": normalized_limit,
            "offset": normalized_offset,
            "status": normalized_status,
        }

    def get_task(self, *, task_id: str) -> dict[str, Any]:
        normalized_task_id = str(task_id or "").strip()
        if not normalized_task_id:
            raise CLIError("task_id required", code="missing_required")
        result = invoke(
            method="task_history.get",
            params={"task_id": normalized_task_id},
            ctx=self._ctx,
            local_call=lambda: self._local_get_task(normalized_task_id),
        )
        task = result.get("task") if isinstance(result, dict) else None
        if not isinstance(task, dict):
            raise CLIError("heartbeat task not found", code="not_found")
        if not self._is_heartbeat_task(task):
            raise CLIError("heartbeat task not found", code="not_found")
        return {"task": task}

    def inspect(self, *, agent_id: str = "", task_limit: int = 5) -> dict[str, Any]:
        resolved_agent_id = self.resolve_agent_id(agent_id)
        config = self.get_config()["config"]
        status_payload = self.status()
        file_payload = self.read_file(agent_id=resolved_agent_id)
        normalized_task_limit = max(int(task_limit or 0), 0)
        tasks_payload = (
            self.list_tasks(agent_id=resolved_agent_id, limit=normalized_task_limit)
            if normalized_task_limit > 0
            else {"tasks": []}
        )
        return {
            "agent_id": resolved_agent_id,
            "runtime_available": bool(status_payload.get("runtime_available", False)),
            "config": config,
            "status": status_payload.get("status", {}),
            "file": file_payload,
            "tasks": tasks_payload.get("tasks", []),
        }

    def resolve_agent_id(self, agent_id: str = "") -> str:
        normalized = str(agent_id or "").strip()
        if normalized:
            return normalized
        return str(self.get_config()["config"]["main_agent_id"])

    def _local_get_config(self) -> dict[str, Any]:
        with connect(self._ctx.db_path) as conn:
            config = read_config_json(conn)
        return {"config": config}

    def _local_update_config(self, partial: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(partial, dict):
            raise CLIError("config must be object", code="invalid_payload")
        with connect(self._ctx.db_path, write=True) as conn:
            current = read_config_json(conn)
            next_config = _deep_merge(current, partial)
            heartbeat = _normalize_heartbeat_config(next_config)
            next_config["heartbeat"] = heartbeat
            upsert_config_json(conn, next_config)
        return {"ok": True}

    def _local_status(self) -> dict[str, Any]:
        config = self._local_get_config()["config"]
        heartbeat_config = _normalize_heartbeat_config(config)
        tasks = self._local_list_tasks(
            agent_id=str(heartbeat_config["main_agent_id"]),
            status="",
            limit=1,
            offset=0,
        )["tasks"]
        last_task = tasks[0] if tasks else {}
        return {
            "runtime_available": False,
            "status": {
                "running": None,
                "enabled": bool(heartbeat_config["enabled"]),
                "active_hours": self._in_active_hours(heartbeat_config),
                "main_agent_id": str(heartbeat_config["main_agent_id"]),
                "notify_policy": str(heartbeat_config["notify_policy"]),
                "last_session_id": str(last_task.get("session_id") or ""),
                "last_task_id": str(last_task.get("task_id") or ""),
                "last_tick_at": None,
                "last_run_at": last_task.get("created_at"),
                "last_status": str(last_task.get("status") or ""),
                "last_result_preview": str(
                    last_task.get("final_answer")
                    or last_task.get("prompt")
                    or ""
                )[:500],
            },
        }

    def _heartbeat_file_path(self, agent_id: str) -> Path:
        return self._ctx.data_dir / "agent_contexts" / agent_id / "HEARTBEAT.md"

    def _ensure_heartbeat_file(self, agent_id: str) -> Path:
        path = self._heartbeat_file_path(agent_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            path.write_text(_DEFAULT_HEARTBEAT_TEMPLATE, encoding="utf-8")
        return path

    def _local_read_file(self, agent_id: str) -> dict[str, Any]:
        file_path = self._ensure_heartbeat_file(agent_id)
        stat = file_path.stat()
        return {
            "target": "heartbeat",
            "path": str(file_path),
            "relative_path": file_path.relative_to(file_path.parent).as_posix(),
            "content": file_path.read_text(encoding="utf-8"),
            "updated_at": float(stat.st_mtime),
            "size_bytes": int(stat.st_size),
        }

    def _local_write_file(self, agent_id: str, content: str) -> dict[str, Any]:
        file_path = self._ensure_heartbeat_file(agent_id)
        file_path.write_text(_normalize_file_content(content), encoding="utf-8")
        stat = file_path.stat()
        return {
            "target": "heartbeat",
            "path": str(file_path),
            "relative_path": file_path.relative_to(file_path.parent).as_posix(),
            "content": file_path.read_text(encoding="utf-8"),
            "updated_at": float(stat.st_mtime),
            "size_bytes": int(stat.st_size),
        }

    def _enrich_file_payload(self, agent_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        content = str(payload.get("content") or "")
        items = self._extract_items(content)
        result = dict(payload)
        result["agent_id"] = agent_id
        result["items"] = items
        result["item_count"] = len(items)
        result["meaningful_content"] = any(
            not str(line).strip().startswith("#")
            for line in content.splitlines()
            if str(line).strip()
        )
        return result

    @staticmethod
    def _extract_items(content: str) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for line_number, raw_line in enumerate(str(content or "").splitlines(), start=1):
            match = _ITEM_PATTERN.match(raw_line)
            if not match:
                continue
            checkbox = str(match.group("checkbox") or "")
            items.append(
                {
                    "index": len(items) + 1,
                    "line_number": line_number,
                    "marker": str(match.group("marker") or "-"),
                    "checked": checkbox.lower() == "[x]" if checkbox else None,
                    "text": str(match.group("text") or "").strip(),
                    "raw": raw_line,
                }
            )
        return items

    @staticmethod
    def _in_active_hours(config: dict[str, Any]) -> bool | None:
        try:
            import zoneinfo

            tz = zoneinfo.ZoneInfo(str(config.get("timezone") or _DEFAULT_TIMEZONE))
            now = datetime.now(tz)
            active_hours = config.get("active_hours", {}) or {}
            start = _normalize_hhmm(
                active_hours.get("start"),
                field_name="active_hours.start",
                default=_DEFAULT_ACTIVE_HOURS["start"],
            )
            end = _normalize_hhmm(
                active_hours.get("end"),
                field_name="active_hours.end",
                default=_DEFAULT_ACTIVE_HOURS["end"],
            )
            start_hour, start_minute = map(int, start.split(":"))
            end_hour, end_minute = map(int, end.split(":"))
            now_minutes = now.hour * 60 + now.minute
            start_minutes = start_hour * 60 + start_minute
            end_minutes = end_hour * 60 + end_minute
            if start_minutes <= end_minutes:
                return start_minutes <= now_minutes <= end_minutes
            return now_minutes >= start_minutes or now_minutes <= end_minutes
        except Exception:
            return None

    @staticmethod
    def _is_heartbeat_task(task: dict[str, Any]) -> bool:
        task_origin = str(task.get("task_origin") or "").strip().lower()
        if task_origin:
            return task_origin == "heartbeat"
        session_id = str(task.get("session_id") or "").strip().lower()
        return session_id.startswith("heartbeat-")

    def _local_list_tasks(
        self,
        *,
        agent_id: str,
        status: str,
        limit: int,
        offset: int,
    ) -> dict[str, Any]:
        normalized_limit = max(int(limit or 20), 0)
        normalized_offset = max(int(offset or 0), 0)
        with connect(self._ctx.db_path) as conn:
            columns = {
                str(row["name"])
                for row in conn.execute("PRAGMA table_info(task_history)").fetchall()
            }
            where_parts: list[str] = []
            params: list[Any] = []
            if "task_origin" in columns:
                where_parts.append("task_origin = 'heartbeat'")
            else:
                where_parts.append("session_id LIKE 'heartbeat-%'")
            if agent_id:
                where_parts.append("agent_id = ?")
                params.append(agent_id)
            if status:
                where_parts.append("status = ?")
                params.append(status)
            where_clause = f"WHERE {' AND '.join(where_parts)}" if where_parts else ""
            query = f"""
                SELECT * FROM task_history
                {where_clause}
                ORDER BY created_at DESC
            """
            if normalized_limit > 0:
                query += " LIMIT ? OFFSET ?"
                params.extend([normalized_limit, normalized_offset])
            rows = conn.execute(query, tuple(params)).fetchall()
        tasks = [
            _task_row_to_payload(
                row,
                inferred_heartbeat="task_origin" not in columns,
            )
            for row in rows
        ]
        return {"tasks": tasks}

    def _local_get_task(self, task_id: str) -> dict[str, Any]:
        with connect(self._ctx.db_path) as conn:
            columns = {
                str(row["name"])
                for row in conn.execute("PRAGMA table_info(task_history)").fetchall()
            }
            row = conn.execute(
                "SELECT * FROM task_history WHERE task_id = ? LIMIT 1",
                (task_id,),
            ).fetchone()
        if not row:
            raise CLIError("heartbeat task not found", code="not_found")
        task = _task_row_to_payload(
            row,
            inferred_heartbeat="task_origin" not in columns,
        )
        if not self._is_heartbeat_task(task):
            raise CLIError("heartbeat task not found", code="not_found")
        return {"task": task}


__all__ = ["HeartbeatSDK"]
