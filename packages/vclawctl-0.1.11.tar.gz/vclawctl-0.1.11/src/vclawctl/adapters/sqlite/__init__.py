"""SQLite adapters."""
