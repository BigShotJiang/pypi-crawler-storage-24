"""Session-scoped auth principal command handlers."""

from __future__ import annotations

import argparse
import os
import subprocess
from typing import Any

from vclawctl.adapters.sqlite.db import connect, read_config_json
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError, ExitCode


def _runtime_only_local_fallback() -> dict[str, Any]:
    raise CLIError(
        (
            "auth command requires runtime API; use --mode api/auto "
            "with a running v-claw instance"
        ),
        code="runtime_api_required",
    )


def _resolve_session_id(ctx: CLIContext, explicit_session_id: Any) -> str:
    normalized_explicit = str(explicit_session_id or "").strip()
    if normalized_explicit:
        return normalized_explicit

    env_session_id = str(os.environ.get("VCLAW_SESSION_ID", "") or "").strip()
    if env_session_id:
        return env_session_id

    try:
        with connect(ctx.db_path) as conn:
            chat_cfg = read_config_json(conn).get("chat")
    except Exception:
        chat_cfg = {}
    if isinstance(chat_cfg, dict):
        main_session_id = str(chat_cfg.get("main_session_id") or "").strip()
        if main_session_id:
            return main_session_id

    raise CLIError(
        (
            "session_id required; pass --session-id, set VCLAW_SESSION_ID, "
            "or configure chat.main_session_id"
        ),
        code="missing_required",
    )


def _invoke_auth_runtime(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    return invoke(
        method=f"auth.{method}",
        params=params,
        ctx=ctx,
        local_call=_runtime_only_local_fallback,
    )


def current(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def use(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def reset(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def resolve_env(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "current": current,
        "use": use,
        "reset": reset,
        "resolve_env": resolve_env,
    }
    handler = handlers.get(method)
    if not handler:
        raise CLIError(f"Unknown auth method: {method}", code="unknown_method")
    return handler(ctx, params)


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "auth",
        help="Manage session-scoped auth principals",
        description=(
            "Switch the current runtime session between provider principals such as\n"
            "tenant and requester. Commands resolve session_id from --session-id,\n"
            "then VCLAW_SESSION_ID, then chat.main_session_id."
        ),
        epilog=(
            "Examples:\n"
            "  vclawctl auth current --provider feishu\n"
            "  vclawctl auth use --provider feishu --principal requester\n"
            "  vclawctl auth reset --provider feishu\n"
            "  vclawctl auth exec --provider feishu --principal requester -- feishu auth whoami"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    auth_sub = parser.add_subparsers(dest="auth_cmd", required=True)

    current_parser = auth_sub.add_parser("current", help="Show current principal selection")
    current_parser.add_argument("--provider", required=True, help="Auth provider, e.g. feishu")
    current_parser.add_argument("--session-id", default="", help="Target runtime session ID")
    current_parser.set_defaults(func=_cmd_current)

    use_parser = auth_sub.add_parser("use", help="Select principal for current session")
    use_parser.add_argument("--provider", required=True, help="Auth provider, e.g. feishu")
    use_parser.add_argument(
        "--principal",
        required=True,
        help="Principal name, e.g. tenant or requester",
    )
    use_parser.add_argument("--session-id", default="", help="Target runtime session ID")
    use_parser.set_defaults(func=_cmd_use)

    reset_parser = auth_sub.add_parser("reset", help="Reset provider principal to default")
    reset_parser.add_argument("--provider", required=True, help="Auth provider, e.g. feishu")
    reset_parser.add_argument("--session-id", default="", help="Target runtime session ID")
    reset_parser.set_defaults(func=_cmd_reset)

    exec_parser = auth_sub.add_parser(
        "exec",
        help="Run one command with resolved provider auth env",
    )
    exec_parser.add_argument("--provider", required=True, help="Auth provider, e.g. feishu")
    exec_parser.add_argument(
        "--principal",
        required=True,
        help="Principal name, e.g. tenant, requester, or default",
    )
    exec_parser.add_argument("--session-id", default="", help="Target runtime session ID")
    exec_parser.add_argument(
        "command",
        nargs=argparse.REMAINDER,
        help="Command to run after --",
    )
    exec_parser.set_defaults(func=_cmd_exec)


def _cmd_current(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "session_id": _resolve_session_id(ctx, args.session_id),
        "provider": str(args.provider or "").strip(),
    }
    return _invoke_auth_runtime("current", params, ctx)


def _cmd_use(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "session_id": _resolve_session_id(ctx, args.session_id),
        "provider": str(args.provider or "").strip(),
        "principal": str(args.principal or "").strip(),
    }
    return _invoke_auth_runtime("use", params, ctx)


def _cmd_reset(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "session_id": _resolve_session_id(ctx, args.session_id),
        "provider": str(args.provider or "").strip(),
    }
    return _invoke_auth_runtime("reset", params, ctx)


def _cmd_exec(args: Any, ctx: CLIContext) -> dict[str, Any]:
    command = [str(item) for item in list(args.command or [])]
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        raise CLIError("auth exec requires command after --", code="missing_required")

    session_id = _resolve_session_id(ctx, args.session_id)
    payload = _invoke_auth_runtime(
        "resolve_env",
        {
            "session_id": session_id,
            "provider": str(args.provider or "").strip(),
            "principal": str(args.principal or "").strip() or "default",
        },
        ctx,
    )
    env_overlay = payload.get("env")
    if not isinstance(env_overlay, dict):
        raise CLIError("auth.resolve_env returned invalid env payload", code="invalid_response")

    child_env = os.environ.copy()
    for key, value in env_overlay.items():
        env_name = str(key or "").strip()
        if not env_name:
            continue
        child_env[env_name] = "" if value is None else str(value)

    try:
        completed = subprocess.run(command, env=child_env, check=False)  # noqa: S603
    except OSError as exc:
        raise CLIError(
            f"failed to run child command: {exc}",
            code="child_process_spawn_failed",
        ) from exc

    result = {
        "session_id": session_id,
        "provider": str(payload.get("provider") or args.provider or "").strip(),
        "principal": str(payload.get("principal") or args.principal or "").strip(),
        "command": command,
        "exit_code": int(completed.returncode),
    }
    if completed.returncode != 0:
        raise CLIError(
            f"child command failed with exit code {completed.returncode}",
            code="child_process_failed",
            exit_code=ExitCode.ERROR,
        )
    return result
