"""Generic call command dispatcher."""

from __future__ import annotations

import argparse
from typing import Any

from vclawctl.commands import (
    agent,
    agent_context,
    auth,
    browser,
    chat,
    config,
    im,
    memory,
    preference,
    schedule,
    session,
    skill,
    task,
    workspace,
)
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import parse_json_object
from vclawctl.errors import CLIError


def _split_method(raw_method: str) -> tuple[str, str]:
    method = str(raw_method or "").strip()
    if not method:
        raise CLIError("method required", code="missing_required")

    namespace, dot, op = method.partition(".")
    if not dot or not namespace.strip() or not op.strip():
        raise CLIError("method must be namespace.method", code="invalid_method")
    return namespace.strip(), op.strip()


def dispatch_call(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    namespace, op = _split_method(method)

    if namespace == "schedule":
        return schedule.dispatch(op, params, ctx)
    if namespace in {"agent", "agent_profile"}:
        mapped = {
            "list": "list",
            "get": "get",
            "create": "create",
            "update": "update",
            "delete": "delete",
        }.get(op, op)
        return agent.dispatch(mapped, params, ctx)
    if namespace == "task_history":
        mapped = {
            "list": "list",
            "get": "get",
            "get_by_session": "get_by_session",
            "toggle_favorite": "toggle_favorite",
            "delete": "delete",
            "recent": "recent",
            "messages": "messages",
            "search_messages": "search_messages",
            "last_message": "last_message",
            "transcript_turns": "transcript_turns",
            "transcript_stats": "transcript_stats",
            "transcript_search": "transcript_search",
        }.get(op, op)
        return task.dispatch(mapped, params, ctx)
    if namespace == "settings":
        mapped = {
            "get_config": "get_config",
            "update_config": "update_config",
            "get_value": "get_value",
            "set_value": "set_value",
            "approval_rules": "list_approval_rules",
            "list_approval_rules": "list_approval_rules",
            "update_approval_rule": "update_approval_rule",
            "delete_approval_rule": "delete_approval_rule",
            "vv_binding": "get_vectorvein_binding",
            "get_vectorvein_binding": "get_vectorvein_binding",
            "vv_bind": "bind_vectorvein",
            "bind_vectorvein": "bind_vectorvein",
            "vv_login_bind": "login_and_bind_vectorvein",
            "login_and_bind_vectorvein": "login_and_bind_vectorvein",
            "vv_summary": "get_vectorvein_account_summary",
            "get_vectorvein_account_summary": "get_vectorvein_account_summary",
            "vv_unbind": "unbind_vectorvein",
            "unbind_vectorvein": "unbind_vectorvein",
            "llm_settings": "get_llm_settings",
            "get_llm_settings": "get_llm_settings",
            "update_llm": "update_llm_settings",
            "update_llm_settings": "update_llm_settings",
            "list_models": "list_endpoint_models",
            "list_endpoint_models": "list_endpoint_models",
            "test_embedding": "test_embedding_model",
            "test_embedding_model": "test_embedding_model",
            "test_rerank": "test_rerank_model",
            "test_rerank_model": "test_rerank_model",
            "test_feishu": "test_feishu_config",
            "test_feishu_config": "test_feishu_config",
        }.get(op, op)
        return config.dispatch(mapped, params, ctx)
    if namespace == "chat":
        return chat.dispatch(op, params, ctx)
    if namespace == "auth":
        return auth.dispatch(op, params, ctx)
    if namespace == "browser":
        return browser.dispatch(op, params, ctx)
    if namespace == "session":
        return session.dispatch(op, params, ctx)
    if namespace == "skill":
        mapped = {
            "list": "list_catalog",
            "list_catalog": "list_catalog",
            "installed": "list_installed",
            "list_installed": "list_installed",
            "get": "get_detail",
            "detail": "get_detail",
            "get_detail": "get_detail",
            "install": "install",
            "uninstall": "uninstall",
            "delete": "uninstall",
            "remove": "uninstall",
            "update_installation": "update_installation",
            "validate": "validate_required",
            "validate_required": "validate_required",
            "bind": "bind_agent",
            "bind_agent": "bind_agent",
            "import": "import_package",
            "import_package": "import_package",
            "import_and_bind": "import_and_bind",
        }.get(op, op)
        return skill.dispatch(mapped, params, ctx)
    if namespace == "memory":
        mapped = {
            "import": "import_openclaw",
            "import_openclaw": "import_openclaw",
            "rebuild": "rebuild",
            "rebuild_index": "rebuild",
            "get_file": "get_file",
            "list": "list",
            "search": "search",
            "get": "get",
            "add": "add",
            "update": "update",
            "edit": "update",
            "delete": "delete",
            "stats": "stats",
        }.get(op, op)
        return memory.dispatch(mapped, params, ctx)
    if namespace == "preference":
        mapped = {
            "get": "get_quiet_hours",
            "get_quiet_hours": "get_quiet_hours",
            "set": "set_quiet_hours",
            "set_quiet_hours": "set_quiet_hours",
            "clear": "clear_quiet_hours",
            "clear_quiet_hours": "clear_quiet_hours",
        }.get(op, op)
        return preference.dispatch(mapped, params, ctx)
    if namespace == "agent_context":
        return agent_context.dispatch(op, params, ctx)
    if namespace == "im":
        return im.dispatch(op, params, ctx)
    if namespace == "workspace":
        return workspace.dispatch(op, params, ctx)

    raise CLIError(f"Unsupported namespace: {namespace}", code="unsupported_namespace")


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "call",
        help="Call namespace.method with JSON params",
        description=(
            "Call any v-claw API method directly by namespace.method.\n"
            "Available namespaces: agent_profile, task_history, settings, chat, agent,\n"
            "auth,\n"
            "skill, memory, preference, schedule, agent_context, im, workspace, browser."
        ),
        epilog=(
            "Examples:\n"
            "  vclawctl call --method agent_profile.list\n"
            "  vclawctl call --method chat.get_status --params-json '{\"ensure_session\":true}'\n"
            "  vclawctl call --method settings.get_llm_settings"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument(
        "--method",
        required=True,
        help="API method as namespace.method, e.g. agent_profile.list, chat.get_status",
    )
    parser.add_argument(
        "--params-json", default="{}", help="JSON object of method parameters (default: {})"
    )
    parser.set_defaults(func=_cmd_call)


def _cmd_call(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = parse_json_object(args.params_json, field_name="params_json")
    method = str(args.method or "").strip()
    return invoke(
        method=method,
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch_call(method, params, ctx),
    )
