"""Session command handlers."""

from __future__ import annotations

import argparse
from typing import Any

from vclawctl.adapters.sqlite.db import connect, loads_json
from vclawctl.commands import chat as chat_cmd
from vclawctl.commands import task as task_cmd
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import normalize_positive_int
from vclawctl.errors import CLIError


def _row_to_status(row: Any) -> dict[str, Any]:
    token_usage = loads_json(row["token_usage_json"], {})
    progress = loads_json(row["progress_json"], [])
    return {
        "session_id": str(row["session_id"]),
        "task_id": str(row["task_id"]),
        "agent_id": str(row["agent_id"]),
        "session_kind": str(row["session_kind"] or "task"),
        "status": str(row["status"] or ""),
        "cycles_count": int(row["cycles_count"] or 0),
        "token_usage": token_usage,
        "workspace_path": str(row["workspace_path"] or ""),
        "workspace_source": str(row["workspace_source"] or ""),
        "final_answer": str(row["final_answer"] or ""),
        "progress": progress,
        "created_at": float(row["created_at"]),
        "finished_at": float(row["finished_at"]) if row["finished_at"] is not None else None,
    }


def _task_to_status(task: dict[str, Any], session_id: str) -> dict[str, Any]:
    token_usage = task.get("token_usage", {})
    progress = task.get("progress", [])
    raw_finished_at = task.get("finished_at")
    return {
        "session_id": str(task.get("session_id") or session_id),
        "task_id": str(task.get("task_id") or ""),
        "agent_id": str(task.get("agent_id") or ""),
        "session_kind": str(task.get("session_kind") or "task"),
        "status": str(task.get("status") or ""),
        "cycles_count": int(task.get("cycles_count") or 0),
        "token_usage": token_usage if isinstance(token_usage, dict) else {},
        "workspace_path": str(task.get("workspace_path") or ""),
        "workspace_source": str(task.get("workspace_source") or ""),
        "final_answer": str(task.get("final_answer") or ""),
        "progress": progress if isinstance(progress, list) else [],
        "created_at": float(task.get("created_at") or 0),
        "finished_at": (float(raw_finished_at) if raw_finished_at is not None else None),
    }


def status(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")

    with connect(ctx.db_path) as conn:
        row = conn.execute(
            "SELECT * FROM task_history WHERE session_id = ? LIMIT 1",
            (session_id,),
        ).fetchone()
    if not row:
        raise CLIError("Session not found", code="not_found")
    return {
        "status": _row_to_status(row),
        "meta": {"id_model": task_cmd.build_id_model_meta(requested_by="session_id")},
    }


def token(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    payload = status(ctx, {"session_id": params.get("session_id"), "live": False})
    status_payload = payload.get("status", {})
    token_usage = status_payload.get("token_usage", {})
    return {
        "session_id": status_payload.get("session_id", ""),
        "token_usage": token_usage,
        "meta": {"id_model": task_cmd.build_id_model_meta(requested_by="session_id")},
    }


def reset_current(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del params
    return chat_cmd.dispatch("reset_session", {}, ctx)


def cancel(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")

    raise CLIError(
        "offline cancel is not supported; pass --live to use runtime channel",
        code="runtime_required",
    )


def messages(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")
    return task_cmd.messages(
        ctx,
        {
            "session_id": session_id,
            "limit": params.get("limit"),
            "offset": params.get("offset"),
            "role": params.get("role"),
        },
    )


def search_messages(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")
    return task_cmd.search_messages(
        ctx,
        {
            "session_id": session_id,
            "query": params.get("query"),
            "limit": params.get("limit"),
            "offset": params.get("offset"),
            "role": params.get("role"),
        },
    )


def last_message(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")
    return task_cmd.last_message(
        ctx,
        {
            "session_id": session_id,
            "role": params.get("role"),
        },
    )


def _runtime_only_local_fallback() -> dict[str, Any]:
    raise CLIError(
        (
            "session runtime command requires runtime API; use --mode api/auto "
            "with a running v-claw instance"
        ),
        code="runtime_api_required",
    )


def _invoke_agent_runtime(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    return invoke(
        method=f"agent.{method}",
        params=params,
        ctx=ctx,
        local_call=_runtime_only_local_fallback,
    )


def create(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def list_runtime(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def send_runtime(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def retry_runtime(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def approve_runtime(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "create": create,
        "create_session": create,
        "list": list_runtime,
        "list_sessions": list_runtime,
        "send": send_runtime,
        "retry": retry_runtime,
        "approve": approve_runtime,
        "status": status,
        "token": token,
        "reset_current": reset_current,
        "cancel": cancel,
        "messages": messages,
        "search_messages": search_messages,
        "last_message": last_message,
    }
    handler = handlers.get(method)
    if not handler:
        raise CLIError(f"Unknown session method: {method}", code="unknown_method")
    return handler(ctx, params)


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "session",
        help="Inspect and control sessions",
        description=(
            "Manage individual runtime sessions. Each session is an independent execution\n"
            "context with its own agent, workspace, and message history.\n"
            "For quick chat workflows using the configured main session, see 'vclawctl chat'."
        ),
        epilog=(
            "Examples:\n"
            "  vclawctl session create --agent-id default\n"
            '  vclawctl session send --session-id <id> --message "hello"\n'
            "  vclawctl session list\n"
            "  vclawctl session approve --session-id <id> --decision approve"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    session_sub = parser.add_subparsers(dest="session_cmd", required=True)

    status_parser = session_sub.add_parser("status", help="Get session status")
    status_parser.add_argument("--session-id", required=True, help="Session ID to query")
    status_parser.add_argument("--live", action="store_true", help="Query runtime instead of DB")
    status_parser.set_defaults(func=_cmd_status)

    token_parser = session_sub.add_parser("token", help="Get token usage by session")
    token_parser.add_argument("--session-id", required=True, help="Session ID to query token usage")
    token_parser.set_defaults(func=_cmd_token)

    create_parser = session_sub.add_parser(
        "create",
        help="Create one runtime session (consider --timeout 300 for slow init)",
    )
    create_parser.add_argument(
        "--agent-id", default="default", help="Agent profile ID (default: default)"
    )
    create_parser.add_argument(
        "--session-id", default="", help="Custom session ID; auto-generated if omitted"
    )
    create_parser.add_argument(
        "--workspace-path", default="", help="Working directory for the session"
    )
    create_parser.add_argument("--workspace-mode", default="", help="Workspace access mode")
    create_parser.add_argument(
        "--model-backend", default="", help="LLM provider, e.g. moonshot, openai"
    )
    create_parser.add_argument(
        "--model-name", default="", help="Model name, e.g. kimi-k2.5, gpt-4o"
    )
    create_parser.add_argument(
        "--max-cycles", type=int, default=0, help="Max agent cycles per turn (0=use agent default)"
    )
    create_parser.add_argument("--bash-shell", default="", help="Shell executable path")
    create_parser.add_argument(
        "--windows-shell-priority",
        default="",
        help="Comma-separated Windows shell priority list",
    )
    create_parser.set_defaults(func=_cmd_create)

    list_parser = session_sub.add_parser("list", help="List runtime sessions")
    list_parser.set_defaults(func=_cmd_list)

    send_parser = session_sub.add_parser(
        "send",
        help="Send one message to runtime session (consider --timeout 300 for long tasks)",
    )
    send_parser.add_argument("--session-id", required=True, help="Target session ID")
    send_parser.add_argument("--message", required=True, help="Message text to send")
    send_parser.add_argument(
        "--agent-id", default="default", help="Agent profile ID (default: default)"
    )
    send_parser.add_argument(
        "--attachment-paths",
        default="",
        help="Comma-separated attachment paths",
    )
    send_parser.set_defaults(func=_cmd_send)

    retry_parser = session_sub.add_parser("retry", help="Retry one runtime session")
    retry_parser.add_argument("--session-id", required=True, help="Session ID to retry")
    retry_parser.set_defaults(func=_cmd_retry)

    approve_parser = session_sub.add_parser("approve", help="Approve or deny one runtime request")
    approve_parser.add_argument(
        "--session-id", required=True, help="Session ID with pending request"
    )
    approve_parser.add_argument(
        "--decision", required=True, choices=["approve", "deny"], help="Approve or deny the request"
    )
    approve_parser.add_argument(
        "--request-id", default="", help="Specific request ID; latest if omitted"
    )
    approve_parser.set_defaults(func=_cmd_approve)

    reset_parser = session_sub.add_parser(
        "reset-current",
        help="Reset current chat main session in config",
    )
    reset_parser.add_argument("--yes", action="store_true", help="Confirm reset")
    reset_parser.set_defaults(func=_cmd_reset_current)

    cancel_parser = session_sub.add_parser("cancel", help="Cancel a live session")
    cancel_parser.add_argument("--session-id", required=True, help="Session ID to cancel")
    cancel_parser.add_argument("--live", action="store_true", help="Cancel live runtime session")
    cancel_parser.set_defaults(func=_cmd_cancel)

    messages_parser = session_sub.add_parser("messages", help="List messages by session")
    messages_parser.add_argument("--session-id", required=True, help="Session ID to query")
    messages_parser.add_argument(
        "--role",
        default="",
        help="Filter role: user|assistant|system|tool",
    )
    messages_parser.add_argument("--limit", type=int, default=50, help="Max results (default: 50)")
    messages_parser.add_argument(
        "--offset", type=int, default=0, help="Skip first N results (default: 0)"
    )
    messages_parser.set_defaults(func=_cmd_messages)

    search_parser = session_sub.add_parser(
        "search-messages",
        help="Search messages by session",
    )
    search_parser.add_argument("--session-id", required=True, help="Session ID to search")
    search_parser.add_argument("--query", required=True, help="Search text")
    search_parser.add_argument(
        "--role",
        default="",
        help="Filter role: user|assistant|system|tool",
    )
    search_parser.add_argument("--limit", type=int, default=50, help="Max results (default: 50)")
    search_parser.add_argument(
        "--offset", type=int, default=0, help="Skip first N results (default: 0)"
    )
    search_parser.set_defaults(func=_cmd_search_messages)

    last_parser = session_sub.add_parser("last-message", help="Show last message by session")
    last_parser.add_argument("--session-id", required=True, help="Session ID to query")
    last_parser.add_argument("--role", default="", help="Filter role: user|assistant|system|tool")
    last_parser.set_defaults(func=_cmd_last_message)


def _normalize_offset(raw_offset: Any) -> int:
    try:
        parsed = int(raw_offset or 0)
    except Exception:  # noqa: BLE001
        parsed = 0
    return max(parsed, 0)


def _parse_csv_items(raw: Any) -> list[str]:
    text = str(raw or "").strip()
    if not text:
        return []
    items: list[str] = []
    seen: set[str] = set()
    for chunk in text.split(","):
        normalized = chunk.strip()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        items.append(normalized)
    return items


def _cmd_status(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"session_id": args.session_id}
    if not args.live:
        result = invoke(
            method="task_history.get_by_session",
            params=params,
            ctx=ctx,
            local_call=lambda: dispatch("status", params, ctx),
        )
        if "status" in result:
            if "meta" not in result:
                result["meta"] = {
                    "id_model": task_cmd.build_id_model_meta(requested_by="session_id")
                }
            return result
        task_payload = result.get("task")
        if isinstance(task_payload, dict):
            return {
                "status": _task_to_status(task_payload, args.session_id),
                "meta": {"id_model": task_cmd.build_id_model_meta(requested_by="session_id")},
            }
        return dispatch("status", params, ctx)

    return invoke(
        method="agent.get_status",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch("status", params, ctx),
    )


def _cmd_token(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"session_id": args.session_id}
    result = invoke(
        method="task_history.get_by_session",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch("token", params, ctx),
    )
    if "token_usage" in result and "session_id" in result:
        if "meta" not in result:
            result["meta"] = {"id_model": task_cmd.build_id_model_meta(requested_by="session_id")}
        return result
    task_payload = result.get("task")
    if isinstance(task_payload, dict):
        token_usage = task_payload.get("token_usage", {})
        return {
            "session_id": str(task_payload.get("session_id") or args.session_id),
            "token_usage": token_usage if isinstance(token_usage, dict) else {},
            "meta": {"id_model": task_cmd.build_id_model_meta(requested_by="session_id")},
        }
    return dispatch("token", params, ctx)


def _cmd_create(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params: dict[str, Any] = {
        "agent_id": str(args.agent_id or "default").strip() or "default",
    }
    optional_fields = {
        "session_id": str(args.session_id or "").strip(),
        "workspace_path": str(args.workspace_path or "").strip(),
        "workspace_mode": str(args.workspace_mode or "").strip(),
        "model_backend": str(args.model_backend or "").strip(),
        "model_name": str(args.model_name or "").strip(),
        "bash_shell": str(args.bash_shell or "").strip(),
    }
    for key, value in optional_fields.items():
        if value:
            params[key] = value
    if int(args.max_cycles or 0) > 0:
        params["max_cycles"] = int(args.max_cycles)
    windows_shell_priority = _parse_csv_items(args.windows_shell_priority)
    if windows_shell_priority:
        params["windows_shell_priority"] = windows_shell_priority
    return _invoke_agent_runtime("create_session", params, ctx)


def _cmd_list(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _invoke_agent_runtime("list_sessions", {}, ctx)


def _cmd_send(args: Any, ctx: CLIContext) -> dict[str, Any]:
    session_id = str(args.session_id or "").strip()
    message = str(args.message or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")
    if not message:
        raise CLIError("message required", code="missing_required")
    params: dict[str, Any] = {
        "session_id": session_id,
        "message": message,
        "agent_id": str(args.agent_id or "default").strip() or "default",
    }
    attachment_paths = _parse_csv_items(args.attachment_paths)
    if attachment_paths:
        params["attachment_paths"] = attachment_paths
    return _invoke_agent_runtime("send", params, ctx)


def _cmd_retry(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"session_id": str(args.session_id or "").strip()}
    if not params["session_id"]:
        raise CLIError("session_id required", code="missing_required")
    return _invoke_agent_runtime("retry", params, ctx)


def _cmd_approve(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params: dict[str, Any] = {
        "session_id": str(args.session_id or "").strip(),
        "decision": str(args.decision or "").strip(),
    }
    if not params["session_id"]:
        raise CLIError("session_id required", code="missing_required")
    if not params["decision"]:
        raise CLIError("decision required", code="missing_required")
    request_id = str(args.request_id or "").strip()
    if request_id:
        params["request_id"] = request_id
    return _invoke_agent_runtime("approve", params, ctx)


def _cmd_reset_current(args: Any, ctx: CLIContext) -> dict[str, Any]:
    if not args.yes:
        raise CLIError("reset-current requires --yes", code="confirmation_required")
    return invoke(
        method="settings.update_config",
        params={"config": {"chat": {"main_session_id": ""}}},
        ctx=ctx,
        local_call=lambda: dispatch("reset_current", {}, ctx),
    )


def _cmd_cancel(args: Any, ctx: CLIContext) -> dict[str, Any]:
    if not args.live:
        raise CLIError("cancel requires --live", code="runtime_required")
    params = {"session_id": args.session_id}
    return invoke(
        method="agent.cancel",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch("cancel", params, ctx),
    )


def _cmd_messages(args: Any, ctx: CLIContext) -> dict[str, Any]:
    task = task_cmd.resolve_task_record(ctx, {"session_id": args.session_id})
    return task_cmd.build_message_list_payload(
        task,
        role=args.role,
        limit=normalize_positive_int(args.limit, default=50),
        offset=_normalize_offset(args.offset),
        requested_by="session_id",
    )


def _cmd_search_messages(args: Any, ctx: CLIContext) -> dict[str, Any]:
    query = str(args.query or "").strip()
    if not query:
        raise CLIError("query required", code="missing_required")
    task = task_cmd.resolve_task_record(ctx, {"session_id": args.session_id})
    return task_cmd.build_message_list_payload(
        task,
        role=args.role,
        query=query,
        limit=normalize_positive_int(args.limit, default=50),
        offset=_normalize_offset(args.offset),
        requested_by="session_id",
    )


def _cmd_last_message(args: Any, ctx: CLIContext) -> dict[str, Any]:
    task = task_cmd.resolve_task_record(ctx, {"session_id": args.session_id})
    return task_cmd.build_last_message_payload(
        task,
        role=args.role,
        requested_by="session_id",
    )
