"""Chat/session-global command handlers."""

from __future__ import annotations

import argparse
from typing import Any

from vclawctl.adapters.sqlite.db import connect, read_config_json, upsert_config_json
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError


def _chat_cfg(config: dict[str, Any]) -> dict[str, Any]:
    raw = config.get("chat")
    return dict(raw) if isinstance(raw, dict) else {}


def _state_payload(conn: Any, cfg: dict[str, Any]) -> dict[str, Any]:
    chat_cfg = _chat_cfg(cfg)
    session_id = str(chat_cfg.get("main_session_id") or "").strip()
    default_agent_id = str(chat_cfg.get("default_agent_id") or "default").strip() or "default"

    status: dict[str, Any]
    if not session_id:
        status = {
            "status": "idle",
            "messages": [],
            "current_cycle": 0,
            "total_cycles": 0,
            "token_usage": {},
            "error": None,
            "progress": [],
            "final_answer": "",
        }
    else:
        row = conn.execute(
            "SELECT * FROM task_history WHERE session_id = ? LIMIT 1",
            (session_id,),
        ).fetchone()
        if not row:
            status = {
                "status": "idle",
                "messages": [],
                "current_cycle": 0,
                "total_cycles": 0,
                "token_usage": {},
                "error": None,
                "progress": [],
                "final_answer": "",
            }
        else:
            import json

            status = {
                "status": str(row["status"] or "idle"),
                "messages": [],
                "current_cycle": int(row["cycles_count"] or 0),
                "total_cycles": int(row["cycles_count"] or 0),
                "token_usage": json.loads(str(row["token_usage_json"] or "{}")),
                "error": None,
                "progress": json.loads(str(row["progress_json"] or "[]")),
                "final_answer": str(row["final_answer"] or ""),
                "task_id": str(row["task_id"]),
            }

    return {
        "ok": True,
        "mode": "chat",
        "default_agent_id": default_agent_id,
        "session_id": session_id,
        "status": status,
    }


def get_state(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del params
    with connect(ctx.db_path) as conn:
        cfg = read_config_json(conn)
        return _state_payload(conn, cfg)


def reset_session(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del params
    with connect(ctx.db_path, write=True) as conn:
        cfg = read_config_json(conn)
        chat_cfg = _chat_cfg(cfg)
        chat_cfg["main_session_id"] = ""
        chat_cfg["default_agent_id"] = (
            str(chat_cfg.get("default_agent_id") or "default") or "default"
        )
        cfg["chat"] = chat_cfg
        upsert_config_json(conn, cfg)
    return {"ok": True, "session_id": ""}


def set_default_agent(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    agent_id = str(params.get("agent_id") or "").strip()
    if not agent_id:
        raise CLIError("agent_id is required", code="missing_required")

    with connect(ctx.db_path, write=True) as conn:
        row = conn.execute(
            "SELECT agent_id FROM agent_profiles WHERE agent_id = ? LIMIT 1",
            (agent_id,),
        ).fetchone()
        if not row and agent_id != "default":
            raise CLIError(f"Agent not found: {agent_id}", code="not_found")

        cfg = read_config_json(conn)
        chat_cfg = _chat_cfg(cfg)
        chat_cfg["default_agent_id"] = agent_id
        cfg["chat"] = chat_cfg
        upsert_config_json(conn, cfg)
        return _state_payload(conn, cfg)


def set_main_session(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    with connect(ctx.db_path, write=True) as conn:
        cfg = read_config_json(conn)
        chat_cfg = _chat_cfg(cfg)
        chat_cfg["main_session_id"] = session_id
        cfg["chat"] = chat_cfg
        upsert_config_json(conn, cfg)
        return {"ok": True, "session_id": session_id}


def _runtime_only_local_fallback() -> dict[str, Any]:
    raise CLIError(
        (
            "chat runtime command requires runtime API; use --mode api/auto "
            "with a running v-claw instance"
        ),
        code="runtime_api_required",
    )


def ensure_session(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def get_status(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def send(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def retry(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "get_state": get_state,
        "get_status": get_status,
        "ensure_session": ensure_session,
        "reset_session": reset_session,
        "send": send,
        "retry": retry,
        "set_default_agent": set_default_agent,
        "set_main_session": set_main_session,
    }
    handler = handlers.get(method)
    if not handler:
        raise CLIError(f"Unknown chat method: {method}", code="unknown_method")
    return handler(ctx, params)


def _invoke_chat(
    method: str,
    params: dict[str, Any],
    ctx: CLIContext,
    *,
    runtime_only: bool = False,
) -> dict[str, Any]:
    return invoke(
        method=f"chat.{method}",
        params=params,
        ctx=ctx,
        local_call=(
            _runtime_only_local_fallback if runtime_only else lambda: dispatch(method, params, ctx)
        ),
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "chat",
        help="Manage chat-level state",
        description=(
            "Manage the persistent main chat session. Commands here use the configured\n"
            "default agent and main session ID, so you don't need to specify --session-id\n"
            "each time.\n"
            "For explicit multi-session control, see 'vclawctl session'."
        ),
        epilog=(
            "Examples:\n"
            "  vclawctl chat state                          # show default agent + main session\n"
            "  vclawctl chat ensure                    # ensure main session exists\n"
            '  vclawctl chat send --message "hello"         # send to main session\n'
            "  vclawctl chat set-default-agent --agent-id my-agent"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    chat_sub = parser.add_subparsers(dest="chat_cmd", required=True)

    state_parser = chat_sub.add_parser("state", help="Show chat state")
    state_parser.set_defaults(func=_cmd_state)

    reset_parser = chat_sub.add_parser("reset", help="Reset current main chat session")
    reset_parser.add_argument("--yes", action="store_true", help="Confirm reset")
    reset_parser.set_defaults(func=_cmd_reset)

    ensure_parser = chat_sub.add_parser(
        "ensure",
        help="Ensure chat session exists in runtime",
    )
    ensure_parser.add_argument(
        "--force-new", action="store_true", help="Force create a new session even if one exists"
    )
    ensure_parser.set_defaults(func=_cmd_ensure)

    status_parser = chat_sub.add_parser("status", help="Get live chat status from runtime")
    status_parser.add_argument(
        "--session-id", default="", help="Query specific session; uses main session if omitted"
    )
    status_parser.add_argument(
        "--ensure-session", action="store_true", help="Auto-create session if none exists"
    )
    status_parser.set_defaults(func=_cmd_status)

    send_parser = chat_sub.add_parser("send", help="Send one message to chat runtime")
    send_parser.add_argument("--message", required=True, help="Message text to send")
    send_parser.add_argument(
        "--session-id", default="", help="Target session; uses main session if omitted"
    )
    send_parser.add_argument(
        "--agent-id", default="", help="Agent ID; uses default agent if omitted"
    )
    send_parser.set_defaults(func=_cmd_send)

    retry_parser = chat_sub.add_parser("retry", help="Retry the current/target chat runtime cycle")
    retry_parser.add_argument(
        "--session-id", default="", help="Session to retry; uses main session if omitted"
    )
    retry_parser.set_defaults(func=_cmd_retry)

    default_agent_parser = chat_sub.add_parser("set-default-agent", help="Set default chat agent")
    default_agent_parser.add_argument(
        "--agent-id", required=True, help="Agent profile ID to set as default"
    )
    default_agent_parser.set_defaults(func=_cmd_set_default_agent)

    main_session_parser = chat_sub.add_parser("set-main-session", help="Set main session id")
    main_session_parser.add_argument(
        "--session-id", required=True, help="Session ID to set as main"
    )
    main_session_parser.set_defaults(func=_cmd_set_main_session)


def _cmd_state(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _invoke_chat("get_state", {}, ctx)


def _cmd_reset(args: Any, ctx: CLIContext) -> dict[str, Any]:
    if not args.yes:
        raise CLIError("reset requires --yes", code="confirmation_required")
    return _invoke_chat("reset_session", {}, ctx)


def _cmd_ensure(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"force_new": bool(args.force_new)}
    return _invoke_chat("ensure_session", params, ctx, runtime_only=True)


def _cmd_status(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params: dict[str, Any] = {
        "ensure_session": bool(args.ensure_session),
    }
    session_id = str(args.session_id or "").strip()
    if session_id:
        params["session_id"] = session_id
    return _invoke_chat("get_status", params, ctx, runtime_only=True)


def _cmd_send(args: Any, ctx: CLIContext) -> dict[str, Any]:
    message = str(args.message or "").strip()
    if not message:
        raise CLIError("message is required", code="missing_required")
    params: dict[str, Any] = {"message": message}
    session_id = str(args.session_id or "").strip()
    agent_id = str(args.agent_id or "").strip()
    if session_id:
        params["session_id"] = session_id
    if agent_id:
        params["agent_id"] = agent_id
    return _invoke_chat("send", params, ctx, runtime_only=True)


def _cmd_retry(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params: dict[str, Any] = {}
    session_id = str(args.session_id or "").strip()
    if session_id:
        params["session_id"] = session_id
    return _invoke_chat("retry", params, ctx, runtime_only=True)


def _cmd_set_default_agent(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"agent_id": args.agent_id}
    return _invoke_chat("set_default_agent", params, ctx)


def _cmd_set_main_session(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"session_id": args.session_id}
    return invoke(
        method="settings.update_config",
        params={"config": {"chat": {"main_session_id": args.session_id}}},
        ctx=ctx,
        local_call=lambda: dispatch("set_main_session", params, ctx),
    )
