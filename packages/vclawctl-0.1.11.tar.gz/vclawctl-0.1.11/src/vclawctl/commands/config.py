"""Config command handlers."""

from __future__ import annotations

import argparse
import json
from typing import Any

from vclawctl.adapters.sqlite.db import connect, read_config_json, upsert_config_json
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import parse_json_object, parse_json_value
from vclawctl.errors import CLIError

_SUMMARY_MAX_CONTAINER_ITEMS = 16
_SUMMARY_MAX_CONTAINER_CHARS = 480
_MATCH_RESULT_LIMIT = 20


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in override.items():
        if isinstance(merged.get(key), dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _get_by_path(data: dict[str, Any], key_path: str, default: Any = None) -> Any:
    cursor: Any = data
    for key in key_path.split("."):
        if not isinstance(cursor, dict):
            return default
        if key not in cursor:
            return default
        cursor = cursor[key]
    return cursor


def _set_by_path(data: dict[str, Any], key_path: str, value: Any) -> None:
    parts = [part for part in key_path.split(".") if part]
    if not parts:
        raise CLIError("key path is empty", code="invalid_key")

    cursor: dict[str, Any] = data
    for part in parts[:-1]:
        child = cursor.get(part)
        if not isinstance(child, dict):
            child = {}
            cursor[part] = child
        cursor = child
    cursor[parts[-1]] = value


def _parse_explicit_bool(raw: Any, *, field_name: str) -> bool:
    text = str(raw or "").strip().lower()
    if text in {"1", "true", "yes", "on"}:
        return True
    if text in {"0", "false", "no", "off"}:
        return False
    raise CLIError(
        f"{field_name} must be true/false",
        code="invalid_arguments",
    )


def _json_chars(value: Any) -> int:
    try:
        return len(json.dumps(value, ensure_ascii=False, sort_keys=True))
    except Exception:  # noqa: BLE001
        return len(str(value))


def _node_kind(value: Any) -> str:
    if isinstance(value, dict):
        return "object"
    if isinstance(value, list):
        return "array"
    return type(value).__name__


def _container_item_count(value: Any) -> int:
    if isinstance(value, (dict, list)):
        return len(value)
    return 0


def _should_truncate_container(value: Any, *, depth: int) -> bool:
    if not isinstance(value, (dict, list)):
        return False
    if depth < 2:
        return False
    return (
        _container_item_count(value) > _SUMMARY_MAX_CONTAINER_ITEMS
        or _json_chars(value) > _SUMMARY_MAX_CONTAINER_CHARS
    )


def _truncate_marker(*, path: str, value: Any) -> str:
    kind = _node_kind(value)
    count = _container_item_count(value)
    unit = "keys" if isinstance(value, dict) else "items"
    return f"<truncated {kind}: {count} {unit}; use --key {path} or --full>"


def _summarize_config_value(
    value: Any,
    *,
    path: str,
    depth: int,
    truncated_paths: list[dict[str, Any]],
) -> Any:
    if isinstance(value, dict):
        summarized: dict[str, Any] = {}
        for key, child in value.items():
            child_path = f"{path}.{key}" if path else str(key)
            if _should_truncate_container(child, depth=depth + 1):
                truncated_paths.append(
                    {
                        "path": child_path,
                        "kind": _node_kind(child),
                        "items": _container_item_count(child),
                    }
                )
                summarized[key] = _truncate_marker(path=child_path, value=child)
                continue
            summarized[key] = _summarize_config_value(
                child,
                path=child_path,
                depth=depth + 1,
                truncated_paths=truncated_paths,
            )
        return summarized
    if isinstance(value, list):
        summarized_items: list[Any] = []
        for index, child in enumerate(value):
            child_path = f"{path}[{index}]"
            if _should_truncate_container(child, depth=depth + 1):
                truncated_paths.append(
                    {
                        "path": child_path,
                        "kind": _node_kind(child),
                        "items": _container_item_count(child),
                    }
                )
                summarized_items.append(_truncate_marker(path=child_path, value=child))
                continue
            summarized_items.append(
                _summarize_config_value(
                    child,
                    path=child_path,
                    depth=depth + 1,
                    truncated_paths=truncated_paths,
                )
            )
        return summarized_items
    return value


def _summarize_config_payload(config: dict[str, Any]) -> dict[str, Any]:
    truncated_paths: list[dict[str, Any]] = []
    payload: dict[str, Any] = {
        "view": "summary",
        "config": _summarize_config_value(
            config,
            path="",
            depth=0,
            truncated_paths=truncated_paths,
        ),
        "hints": {
            "full": "vclawctl config get --full",
            "key": "vclawctl config get --key <dot.path>",
            "match": "vclawctl config get --match <text>",
        },
    }
    if truncated_paths:
        payload["truncated_paths"] = truncated_paths
    return payload


def _preview_matched_value(path: str, value: Any) -> Any:
    if isinstance(value, (dict, list)):
        return _summarize_config_payload({"value": value})["config"]["value"]
    return value


def _search_config_payload(config: dict[str, Any], *, query: str) -> dict[str, Any]:
    lowered = query.casefold()
    matches: dict[str, dict[str, Any]] = {}
    ordered_paths: list[str] = []

    def _record(path: str, value: Any, reason: str) -> None:
        entry = matches.get(path)
        if entry is None:
            entry = {
                "path": path,
                "reasons": [],
                "value": _preview_matched_value(path, value),
            }
            matches[path] = entry
            ordered_paths.append(path)
        reasons = entry["reasons"]
        if reason not in reasons:
            reasons.append(reason)

    def _walk(value: Any, path: str) -> None:
        if path and lowered in path.casefold():
            _record(path, value, "path")

        if isinstance(value, dict):
            for key, child in value.items():
                child_path = f"{path}.{key}" if path else str(key)
                _walk(child, child_path)
            return

        if isinstance(value, list):
            for index, child in enumerate(value):
                child_path = f"{path}[{index}]"
                _walk(child, child_path)
            return

        if path and lowered in str(value).casefold():
            _record(path, value, "value")

    _walk(config, "")
    total = len(ordered_paths)
    limited_paths = ordered_paths[:_MATCH_RESULT_LIMIT]
    payload: dict[str, Any] = {
        "view": "match",
        "query": query,
        "match_count": total,
        "matches": [matches[path] for path in limited_paths],
    }
    if total > _MATCH_RESULT_LIMIT:
        payload["truncated"] = True
        payload["remaining_count"] = total - _MATCH_RESULT_LIMIT
    return payload


def get_config(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    key = str(params.get("key") or "").strip()
    default = params.get("default")
    with connect(ctx.db_path) as conn:
        cfg = read_config_json(conn)
    if not key:
        return {"config": cfg}
    return {"value": _get_by_path(cfg, key, default)}


def update_config(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    partial = params.get("config", {})
    if not isinstance(partial, dict):
        raise CLIError("config must be object", code="invalid_payload")

    with connect(ctx.db_path, write=True) as conn:
        current = read_config_json(conn)
        next_cfg = _deep_merge(current, partial)
        upsert_config_json(conn, next_cfg)
    return {"ok": True}


def set_value(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    key = str(params.get("key") or "").strip()
    if not key:
        raise CLIError("key required", code="missing_required")
    value = params.get("value")

    with connect(ctx.db_path, write=True) as conn:
        current = read_config_json(conn)
        _set_by_path(current, key, value)
        upsert_config_json(conn, current)
    return {"ok": True}


def _runtime_only_local_fallback() -> dict[str, Any]:
    raise CLIError(
        (
            "config runtime command requires runtime API; use --mode api/auto "
            "with a running v-claw instance"
        ),
        code="runtime_api_required",
    )


def _runtime_stub(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "get_config": get_config,
        "update_config": update_config,
        "set_value": set_value,
        "get_value": get_config,
        "list_approval_rules": _runtime_stub,
        "update_approval_rule": _runtime_stub,
        "delete_approval_rule": _runtime_stub,
        "get_vectorvein_binding": _runtime_stub,
        "bind_vectorvein": _runtime_stub,
        "login_and_bind_vectorvein": _runtime_stub,
        "get_vectorvein_account_summary": _runtime_stub,
        "unbind_vectorvein": _runtime_stub,
        "get_llm_settings": _runtime_stub,
        "update_llm_settings": _runtime_stub,
        "list_endpoint_models": _runtime_stub,
        "test_embedding_model": _runtime_stub,
        "test_rerank_model": _runtime_stub,
        "test_feishu_config": _runtime_stub,
    }
    handler = handlers.get(method)
    if not handler:
        raise CLIError(f"Unknown config method: {method}", code="unknown_method")
    return handler(ctx, params)


def _invoke_config(
    method: str,
    params: dict[str, Any],
    ctx: CLIContext,
    *,
    runtime_only: bool = False,
) -> dict[str, Any]:
    method_name = f"settings.{method}"
    return invoke(
        method=method_name,
        params=params,
        ctx=ctx,
        local_call=(
            _runtime_only_local_fallback if runtime_only else lambda: dispatch(method, params, ctx)
        ),
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "config",
        help="Manage v-claw config",
        description=(
            "Manage v-claw configuration. Basic get/set/patch operate on local config JSON.\n"
            "LLM, approval, VectorVein, and test-* subcommands require a running v-claw\n"
            "instance (runtime API)."
        ),
        epilog=(
            "Examples:\n"
            "  vclawctl config get                          # summarized config\n"
            "  vclawctl config get --full                   # full config\n"
            "  vclawctl config get --match feishu           # search matching paths\n"
            "  vclawctl config get --key chat.default_agent_id\n"
            "  vclawctl config set --key chat.default_agent_id --value-json '\"my-agent\"'\n"
            "  vclawctl config llm-settings                 # runtime LLM config\n"
            "  vclawctl config vv-binding                   # VectorVein binding status"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    cfg_sub = parser.add_subparsers(dest="config_cmd", required=True)

    get_parser = cfg_sub.add_parser("get", help="Get config or key")
    get_parser.add_argument(
        "--key",
        default="",
        help="Dot-path config key, e.g. chat.default_agent_id; omit for summarized config",
    )
    get_parser.add_argument(
        "--default-json", default="null", help="Default JSON value if key not found (default: null)"
    )
    get_parser.add_argument(
        "--full",
        action="store_true",
        help="Return the full config instead of the default summarized view",
    )
    get_parser.add_argument(
        "--match",
        default="",
        help="Search config paths and scalar values, e.g. --match feishu",
    )
    get_parser.set_defaults(func=_cmd_get)

    set_parser = cfg_sub.add_parser("set", help="Set config key with JSON value")
    set_parser.add_argument("--key", required=True, help="Dot-path config key")
    set_parser.add_argument(
        "--value-json", required=True, help="JSON value to set, e.g. '\"my-agent\"' or '42'"
    )
    set_parser.set_defaults(func=_cmd_set)

    patch_parser = cfg_sub.add_parser("patch", help="Deep-merge config patch")
    patch_parser.add_argument(
        "--params-json", required=True, help="JSON object to deep-merge into config"
    )
    patch_parser.set_defaults(func=_cmd_patch)

    llm_settings_parser = cfg_sub.add_parser(
        "llm-settings",
        help="Get runtime LLM settings",
    )
    llm_settings_parser.set_defaults(func=_cmd_llm_settings)

    update_llm_parser = cfg_sub.add_parser(
        "update-llm",
        help="Update runtime LLM settings with a JSON payload",
    )
    update_llm_parser.add_argument(
        "--settings-json", required=True, help="LLM settings JSON object"
    )
    update_llm_parser.set_defaults(func=_cmd_update_llm)

    list_models_parser = cfg_sub.add_parser(
        "list-models",
        help="List models from one endpoint /models API",
    )
    list_models_parser.add_argument(
        "--api-base", required=True, help="API base URL, e.g. https://api.moonshot.cn/v1"
    )
    list_models_parser.add_argument("--api-key", required=True, help="API key for the endpoint")
    list_models_parser.set_defaults(func=_cmd_list_models)

    approval_rules_parser = cfg_sub.add_parser(
        "approval-rules",
        help="List approval rules from runtime",
    )
    approval_rules_parser.set_defaults(func=_cmd_approval_rules)

    update_approval_parser = cfg_sub.add_parser(
        "update-approval-rule",
        help="Update one approval rule",
    )
    update_approval_parser.add_argument("--rule-id", required=True, help="Approval rule ID")
    update_approval_parser.add_argument(
        "--enabled", required=True, help="Set enabled state: true or false"
    )
    update_approval_parser.set_defaults(func=_cmd_update_approval_rule)

    delete_approval_parser = cfg_sub.add_parser(
        "delete-approval-rule",
        help="Delete one approval rule",
    )
    delete_approval_parser.add_argument(
        "--rule-id", required=True, help="Approval rule ID to delete"
    )
    delete_approval_parser.set_defaults(func=_cmd_delete_approval_rule)

    vv_binding_parser = cfg_sub.add_parser(
        "vv-binding",
        help="Get current VectorVein binding status",
    )
    vv_binding_parser.set_defaults(func=_cmd_vv_binding)

    vv_bind_parser = cfg_sub.add_parser(
        "vv-bind",
        help="Bind VectorVein using base URL and API key",
    )
    vv_bind_parser.add_argument("--base-url", required=True, help="VectorVein API base URL")
    vv_bind_parser.add_argument("--api-key", required=True, help="VectorVein API key")
    vv_bind_parser.set_defaults(func=_cmd_vv_bind)

    vv_login_bind_parser = cfg_sub.add_parser(
        "vv-login-bind",
        help="Login and bind VectorVein using account/password",
    )
    vv_login_bind_parser.add_argument("--base-url", required=True, help="VectorVein API base URL")
    vv_login_bind_parser.add_argument(
        "--account", required=True, help="VectorVein account (email or phone)"
    )
    vv_login_bind_parser.add_argument("--password", required=True, help="Account password")
    vv_login_bind_parser.add_argument(
        "--country-code", default="86", help="Phone country code (default: 86)"
    )
    vv_login_bind_parser.set_defaults(func=_cmd_vv_login_bind)

    vv_unbind_parser = cfg_sub.add_parser(
        "vv-unbind",
        help="Unbind VectorVein integration",
    )
    vv_unbind_parser.set_defaults(func=_cmd_vv_unbind)

    vv_summary_parser = cfg_sub.add_parser(
        "vv-summary",
        help="Get VectorVein account summary",
    )
    vv_summary_parser.set_defaults(func=_cmd_vv_summary)

    test_embedding_parser = cfg_sub.add_parser(
        "test-embedding",
        help="Test embedding model through runtime settings",
    )
    test_embedding_parser.add_argument("--backend", required=True, help="Embedding provider name")
    test_embedding_parser.add_argument("--model", required=True, help="Embedding model name")
    test_embedding_parser.add_argument(
        "--test-input", default="", help="Test input text; uses default if omitted"
    )
    test_embedding_parser.add_argument(
        "--test-timeout", type=float, default=30.0, help="Request timeout seconds (default: 30)"
    )
    test_embedding_parser.add_argument(
        "--dimensions", default="", help="Embedding dimensions; uses model default if omitted"
    )
    test_embedding_parser.set_defaults(func=_cmd_test_embedding)

    test_rerank_parser = cfg_sub.add_parser(
        "test-rerank",
        help="Test rerank model through runtime settings",
    )
    test_rerank_parser.add_argument("--backend", required=True, help="Rerank provider name")
    test_rerank_parser.add_argument("--model", required=True, help="Rerank model name")
    test_rerank_parser.add_argument("--query", required=True, help="Query text for reranking")
    test_rerank_parser.add_argument(
        "--documents-json", default="", help="JSON array of documents to rerank"
    )
    test_rerank_parser.add_argument(
        "--top-n", default="", help="Return top N results; uses model default if omitted"
    )
    test_rerank_parser.add_argument(
        "--test-timeout", type=float, default=30.0, help="Request timeout seconds (default: 30)"
    )
    test_rerank_parser.set_defaults(func=_cmd_test_rerank)

    test_feishu_parser = cfg_sub.add_parser(
        "test-feishu",
        help="Test Feishu runtime configuration",
    )
    test_feishu_parser.add_argument(
        "--account-key", default="", help="Feishu account key; uses default if omitted"
    )
    test_feishu_parser.add_argument("--config-json", default="", help="Override Feishu config JSON")
    test_feishu_parser.set_defaults(func=_cmd_test_feishu)


def _cmd_get(args: Any, ctx: CLIContext) -> dict[str, Any]:
    default = parse_json_value(args.default_json, field_name="default_json")
    key = str(args.key or "").strip()
    match = str(getattr(args, "match", "") or "").strip()
    show_full = bool(getattr(args, "full", False))
    if key and match:
        raise CLIError("--key and --match cannot be combined", code="invalid_arguments")
    if key and show_full:
        raise CLIError("--key and --full cannot be combined", code="invalid_arguments")
    if match and show_full:
        raise CLIError("--match and --full cannot be combined", code="invalid_arguments")
    if key:
        params = {"key": key, "default": default}
        return _invoke_config("get_value", params, ctx)
    result = _invoke_config("get_config", {"key": key, "default": default}, ctx)
    config = result.get("config")
    if not isinstance(config, dict):
        raise CLIError("config payload missing", code="invalid_payload")
    if show_full:
        return {"view": "full", "config": config}
    if match:
        return _search_config_payload(config, query=match)
    return _summarize_config_payload(config)


def _cmd_set(args: Any, ctx: CLIContext) -> dict[str, Any]:
    value = parse_json_value(args.value_json, field_name="value_json")
    key = str(args.key or "").strip()
    partial: dict[str, Any] = {}
    _set_by_path(partial, key, value)
    params = {"config": partial}
    return _invoke_config("update_config", params, ctx)


def _cmd_patch(args: Any, ctx: CLIContext) -> dict[str, Any]:
    partial = parse_json_object(args.params_json, field_name="params_json")
    return _invoke_config("update_config", {"config": partial}, ctx)


def _cmd_llm_settings(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _invoke_config("get_llm_settings", {}, ctx, runtime_only=True)


def _cmd_update_llm(args: Any, ctx: CLIContext) -> dict[str, Any]:
    payload = parse_json_object(args.settings_json, field_name="settings_json")
    return _invoke_config(
        "update_llm_settings",
        {"llm_settings": payload},
        ctx,
        runtime_only=True,
    )


def _cmd_list_models(args: Any, ctx: CLIContext) -> dict[str, Any]:
    api_base = str(args.api_base or "").strip()
    api_key = str(args.api_key or "").strip()
    if not api_base:
        raise CLIError("api_base required", code="missing_required")
    if not api_key:
        raise CLIError("api_key required", code="missing_required")
    return _invoke_config(
        "list_endpoint_models",
        {
            "api_base": api_base,
            "api_key": api_key,
        },
        ctx,
        runtime_only=True,
    )


def _cmd_approval_rules(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _invoke_config("list_approval_rules", {}, ctx, runtime_only=True)


def _cmd_update_approval_rule(args: Any, ctx: CLIContext) -> dict[str, Any]:
    rule_id = str(args.rule_id or "").strip()
    if not rule_id:
        raise CLIError("rule_id required", code="missing_required")
    params: dict[str, Any] = {"rule_id": rule_id}
    enabled_raw = str(args.enabled or "").strip()
    if not enabled_raw:
        raise CLIError("enabled required", code="missing_required")
    params["enabled"] = _parse_explicit_bool(enabled_raw, field_name="enabled")
    return _invoke_config("update_approval_rule", params, ctx, runtime_only=True)


def _cmd_delete_approval_rule(args: Any, ctx: CLIContext) -> dict[str, Any]:
    rule_id = str(args.rule_id or "").strip()
    if not rule_id:
        raise CLIError("rule_id required", code="missing_required")
    return _invoke_config(
        "delete_approval_rule",
        {"rule_id": rule_id},
        ctx,
        runtime_only=True,
    )


def _cmd_vv_binding(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _invoke_config("get_vectorvein_binding", {}, ctx, runtime_only=True)


def _cmd_vv_bind(args: Any, ctx: CLIContext) -> dict[str, Any]:
    base_url = str(args.base_url or "").strip()
    api_key = str(args.api_key or "").strip()
    if not base_url:
        raise CLIError("base_url required", code="missing_required")
    if not api_key:
        raise CLIError("api_key required", code="missing_required")
    return _invoke_config(
        "bind_vectorvein",
        {
            "base_url": base_url,
            "api_key": api_key,
        },
        ctx,
        runtime_only=True,
    )


def _cmd_vv_login_bind(args: Any, ctx: CLIContext) -> dict[str, Any]:
    base_url = str(args.base_url or "").strip()
    account = str(args.account or "").strip()
    password = str(args.password or "").strip()
    country_code = str(args.country_code or "86").strip() or "86"
    if not base_url:
        raise CLIError("base_url required", code="missing_required")
    if not account:
        raise CLIError("account required", code="missing_required")
    if not password:
        raise CLIError("password required", code="missing_required")
    return _invoke_config(
        "login_and_bind_vectorvein",
        {
            "base_url": base_url,
            "account": account,
            "password": password,
            "country_code": country_code,
        },
        ctx,
        runtime_only=True,
    )


def _cmd_vv_unbind(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _invoke_config("unbind_vectorvein", {}, ctx, runtime_only=True)


def _cmd_vv_summary(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _invoke_config("get_vectorvein_account_summary", {}, ctx, runtime_only=True)


def _cmd_test_embedding(args: Any, ctx: CLIContext) -> dict[str, Any]:
    backend = str(args.backend or "").strip()
    model = str(args.model or "").strip()
    if not backend:
        raise CLIError("backend required", code="missing_required")
    if not model:
        raise CLIError("model required", code="missing_required")
    params: dict[str, Any] = {
        "backend": backend,
        "model": model,
        "timeout_seconds": float(args.test_timeout or 30.0),
    }
    test_input = str(args.test_input or "").strip()
    dimensions = str(args.dimensions or "").strip()
    if test_input:
        params["input"] = test_input
    if dimensions:
        try:
            params["dimensions"] = int(dimensions)
        except Exception as exc:  # noqa: BLE001
            raise CLIError("dimensions must be integer", code="invalid_arguments") from exc
    return _invoke_config("test_embedding_model", params, ctx, runtime_only=True)


def _cmd_test_rerank(args: Any, ctx: CLIContext) -> dict[str, Any]:
    backend = str(args.backend or "").strip()
    model = str(args.model or "").strip()
    query = str(args.query or "").strip()
    if not backend:
        raise CLIError("backend required", code="missing_required")
    if not model:
        raise CLIError("model required", code="missing_required")
    if not query:
        raise CLIError("query required", code="missing_required")
    params: dict[str, Any] = {
        "backend": backend,
        "model": model,
        "query": query,
        "timeout_seconds": float(args.test_timeout or 30.0),
    }
    documents_json = str(args.documents_json or "").strip()
    top_n = str(args.top_n or "").strip()
    if documents_json:
        documents = parse_json_value(documents_json, field_name="documents_json")
        if not isinstance(documents, list):
            raise CLIError("documents_json must be a JSON array", code="invalid_json_type")
        params["documents"] = documents
    if top_n:
        try:
            params["top_n"] = int(top_n)
        except Exception as exc:  # noqa: BLE001
            raise CLIError("top_n must be integer", code="invalid_arguments") from exc
    return _invoke_config("test_rerank_model", params, ctx, runtime_only=True)


def _cmd_test_feishu(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params: dict[str, Any] = {}
    account_key = str(args.account_key or "").strip()
    config_json = str(args.config_json or "").strip()
    if account_key:
        params["account_key"] = account_key
    if config_json:
        config_payload = parse_json_object(config_json, field_name="config_json")
        params["config"] = config_payload
    return _invoke_config("test_feishu_config", params, ctx, runtime_only=True)
