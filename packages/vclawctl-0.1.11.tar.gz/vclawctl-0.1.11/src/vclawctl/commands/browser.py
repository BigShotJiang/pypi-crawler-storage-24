"""Browser runtime command handlers."""

from __future__ import annotations

import argparse
import base64
import binascii
from pathlib import Path
from typing import Any

from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError

__all__ = ["register", "dispatch"]

_METHOD_ALIASES = {
    "status": "get_status",
    "get_status": "get_status",
    "tabs": "get_tabs",
    "get_tabs": "get_tabs",
    "screenshot": "get_screenshot",
    "get_screenshot": "get_screenshot",
}


def _runtime_only_local_fallback() -> dict[str, Any]:
    raise CLIError(
        (
            "browser command requires runtime API; use --mode api/auto "
            "with a running v-claw instance"
        ),
        code="runtime_api_required",
    )


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    raw_method = str(method or "").strip()
    if not raw_method:
        raise CLIError("browser method required", code="missing_required")
    method_name = _METHOD_ALIASES.get(raw_method, raw_method)
    return invoke(
        method=f"browser.{method_name}",
        params=params,
        ctx=ctx,
        local_call=_runtime_only_local_fallback,
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "browser",
        help="Inspect browser runtime state",
        epilog=(
            "Examples:\n"
            "  vclawctl browser status\n"
            "  vclawctl browser tabs\n"
            "  vclawctl browser screenshot --output screenshot.png"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    browser_sub = parser.add_subparsers(dest="browser_cmd", required=True)

    status_parser = browser_sub.add_parser("status", help="Get browser running status")
    status_parser.add_argument("--session-id", default="", help="Filter by session ID")
    status_parser.set_defaults(func=_cmd_status)

    tabs_parser = browser_sub.add_parser("tabs", help="List browser tabs")
    tabs_parser.add_argument("--session-id", default="", help="Filter by session ID")
    tabs_parser.set_defaults(func=_cmd_tabs)

    screenshot_parser = browser_sub.add_parser(
        "screenshot",
        help="Get browser screenshot as base64 or write decoded bytes to a file",
    )
    screenshot_parser.add_argument(
        "--tab-id", default="", help="Target tab ID; uses active tab if omitted"
    )
    screenshot_parser.add_argument("--session-id", default="", help="Filter by session ID")
    screenshot_parser.add_argument(
        "--quality", type=int, default=60, help="JPEG quality 0-100 (default: 60)"
    )
    screenshot_parser.add_argument(
        "--output", default="", help="Write decoded image to file path instead of base64 JSON"
    )
    screenshot_parser.set_defaults(func=_cmd_screenshot)


def _build_scope_params(*, session_id: Any) -> dict[str, Any]:
    params: dict[str, Any] = {}
    normalized_session_id = str(session_id or "").strip()
    if normalized_session_id:
        params["session_id"] = normalized_session_id
    return params


def _cmd_status(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return dispatch("get_status", _build_scope_params(session_id=args.session_id), ctx)


def _cmd_tabs(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return dispatch("get_tabs", _build_scope_params(session_id=args.session_id), ctx)


def _decode_screenshot_payload(result: dict[str, Any]) -> bytes:
    payload = result.get("image_base64")
    if not isinstance(payload, str) or not payload.strip():
        raise CLIError(
            "runtime response missing image_base64",
            code="invalid_payload",
        )
    try:
        return base64.b64decode(payload, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise CLIError(
            "runtime response has invalid image_base64",
            code="invalid_payload",
        ) from exc


def _cmd_screenshot(args: Any, ctx: CLIContext) -> dict[str, Any]:
    quality = int(args.quality)
    if quality < 0 or quality > 100:
        raise CLIError("quality must be between 0 and 100", code="invalid_arguments")

    params = _build_scope_params(session_id=args.session_id)
    tab_id = str(args.tab_id or "").strip()
    if tab_id:
        params["tab_id"] = tab_id
    params["quality"] = quality

    result = dispatch("get_screenshot", params, ctx)
    output = str(args.output or "").strip()
    if not output:
        return result

    raw = _decode_screenshot_payload(result)
    output_path = Path(output).expanduser()
    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(raw)
    except OSError as exc:
        raise CLIError(f"failed to write screenshot: {exc}", code="file_write_error") from exc

    payload = dict(result)
    payload.pop("image_base64", None)
    payload["output_path"] = str(output_path.resolve())
    payload["bytes_written"] = len(raw)
    return payload
