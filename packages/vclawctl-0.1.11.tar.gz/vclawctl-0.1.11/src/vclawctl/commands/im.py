"""IM runtime command handlers."""

from __future__ import annotations

import argparse
from typing import Any

from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import parse_bool, parse_json_object
from vclawctl.errors import CLIError

__all__ = ["register", "dispatch"]


def _runtime_only_local_fallback() -> dict[str, Any]:
    raise CLIError(
        "im command requires runtime API; use --mode api/auto with a running v-claw instance",
        code="runtime_api_required",
    )


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    method_name = str(method or "").strip()
    if not method_name:
        raise CLIError("im method required", code="missing_required")
    return invoke(
        method=f"im.{method_name}",
        params=params,
        ctx=ctx,
        local_call=_runtime_only_local_fallback,
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "im",
        help="Manage IM runtime accounts and bindings",
        epilog=(
            "Examples:\n"
            "  vclawctl im status\n"
            "  vclawctl im accounts\n"
            "  vclawctl im owner-binding --account-id 1\n"
            "  vclawctl im start-pairing --account-id 1"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    im_sub = parser.add_subparsers(dest="im_cmd", required=True)

    status_parser = im_sub.add_parser("status", help="Get IM runtime status")
    status_parser.set_defaults(func=_cmd_status)

    accounts_parser = im_sub.add_parser("accounts", help="List IM accounts")
    accounts_parser.add_argument("--channel", default="", help="Filter by channel type")
    accounts_parser.add_argument(
        "--include-disabled", default="true", help="Include disabled accounts (default: true)"
    )
    accounts_parser.set_defaults(func=_cmd_accounts)

    upsert_parser = im_sub.add_parser("upsert-account", help="Create or update one IM account")
    upsert_parser.add_argument(
        "--account-json", required=True, help="Account JSON object with channel, config, etc."
    )
    upsert_parser.set_defaults(func=_cmd_upsert_account)

    delete_parser = im_sub.add_parser("delete-account", help="Delete one IM account")
    delete_parser.add_argument("--account-id", required=True, type=int, help="Account ID (integer)")
    delete_parser.set_defaults(func=_cmd_delete_account)

    owner_parser = im_sub.add_parser("owner-binding", help="Get owner binding for one IM account")
    owner_parser.add_argument("--account-id", required=True, type=int, help="Account ID (integer)")
    owner_parser.set_defaults(func=_cmd_owner_binding)

    pairing_parser = im_sub.add_parser("start-pairing", help="Start owner pairing flow")
    pairing_parser.add_argument(
        "--account-id", required=True, type=int, help="Account ID (integer)"
    )
    pairing_parser.add_argument(
        "--expires-seconds",
        type=int,
        default=600,
        help="Pairing code expiry in seconds (default: 600)",
    )
    pairing_parser.set_defaults(func=_cmd_start_pairing)

    clear_owner_parser = im_sub.add_parser("clear-owner", help="Clear owner binding")
    clear_owner_parser.add_argument(
        "--account-id", required=True, type=int, help="Account ID (integer)"
    )
    clear_owner_parser.set_defaults(func=_cmd_clear_owner)

    mapping_parser = im_sub.add_parser("session-mapping", help="Resolve IM main session mapping")
    mapping_parser.add_argument("--account-id", default="", help="Filter by account ID")
    mapping_parser.add_argument("--session-id", default="", help="Filter by session ID")
    mapping_parser.add_argument("--channel", default="", help="Filter by channel type")
    mapping_parser.add_argument("--session-key", default="", help="Filter by session key")
    mapping_parser.add_argument("--chat-id", default="", help="Filter by chat ID")
    mapping_parser.set_defaults(func=_cmd_session_mapping)


def _cmd_status(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return dispatch("get_status", {}, ctx)


def _cmd_accounts(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "channel": str(args.channel or "").strip(),
        "include_disabled": parse_bool(args.include_disabled, default=True),
    }
    return dispatch("list_accounts", params, ctx)


def _cmd_upsert_account(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"account": parse_json_object(args.account_json, field_name="account_json")}
    return dispatch("upsert_account", params, ctx)


def _cmd_delete_account(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return dispatch("delete_account", {"account_id": int(args.account_id)}, ctx)


def _cmd_owner_binding(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return dispatch("get_owner_binding", {"account_id": int(args.account_id)}, ctx)


def _cmd_start_pairing(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return dispatch(
        "start_owner_pairing",
        {
            "account_id": int(args.account_id),
            "expires_seconds": int(args.expires_seconds),
        },
        ctx,
    )


def _cmd_clear_owner(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return dispatch("clear_owner_binding", {"account_id": int(args.account_id)}, ctx)


def _cmd_session_mapping(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params: dict[str, Any] = {}
    session_id = str(args.session_id or "").strip()
    channel = str(args.channel or "").strip()
    session_key = str(args.session_key or "").strip()
    chat_id = str(args.chat_id or "").strip()
    account_id = str(args.account_id or "").strip()
    if account_id:
        try:
            params["account_id"] = int(account_id)
        except Exception as exc:  # noqa: BLE001
            raise CLIError("account_id must be integer", code="invalid_arguments") from exc
    if session_id:
        params["session_id"] = session_id
    if channel:
        params["channel"] = channel
    if session_key:
        params["session_key"] = session_key
    if chat_id:
        params["chat_id"] = chat_id
    return dispatch("get_main_session_mapping", params, ctx)
