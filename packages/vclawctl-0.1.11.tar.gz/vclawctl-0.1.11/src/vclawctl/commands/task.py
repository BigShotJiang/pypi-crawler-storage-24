"""Task history command handlers."""

from __future__ import annotations

import argparse
from collections import deque
from typing import Any

from vclawctl.adapters.sqlite.db import connect, loads_json
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import normalize_positive_int, parse_bool
from vclawctl.errors import CLIError

_MESSAGE_ROLES = {"user", "assistant", "system", "tool"}
_ID_MODEL_RELATION = (
    "task_history persistence is 1:1 between task_id and session_id; "
    "runtime flows may differ (chat reuse, sub-tasks, injections, or pre-task sessions)."
)


def _row_to_task(row: Any) -> dict[str, Any]:
    return {
        "task_id": str(row["task_id"]),
        "agent_id": str(row["agent_id"]),
        "session_id": str(row["session_id"]),
        "title": str(row["title"]),
        "prompt": str(row["prompt"]),
        "session_kind": str(row["session_kind"] or "task"),
        "workspace_path": str(row["workspace_path"] or ""),
        "workspace_source": str(row["workspace_source"] or "global_default"),
        "status": str(row["status"] or "running"),
        "cycles_count": int(row["cycles_count"] or 0),
        "created_at": float(row["created_at"]),
        "finished_at": float(row["finished_at"]) if row["finished_at"] is not None else None,
        "is_favorite": bool(int(row["is_favorite"] or 0)),
        "progress": loads_json(row["progress_json"], []),
        "final_answer": str(row["final_answer"] or ""),
        "token_usage": loads_json(row["token_usage_json"], {}),
        "agent_name": str(row["agent_name"] or ""),
        "model_name": str(row["model_name"] or ""),
        "parent_task_id": str(row["parent_task_id"] or ""),
        "is_sub_task": bool(int(row["is_sub_task"] or 0)),
    }


def _normalize_message_role(raw_role: Any) -> str:
    role = str(raw_role or "").strip().lower()
    if not role:
        return ""
    if role not in _MESSAGE_ROLES:
        raise CLIError(
            "role must be one of user|assistant|system|tool",
            code="invalid_role",
        )
    return role


def build_id_model_meta(*, requested_by: str) -> dict[str, Any]:
    normalized = str(requested_by or "").strip().lower() or "unknown"
    return {
        "requested_by": normalized,
        "relation": _ID_MODEL_RELATION,
        "task_id_meaning": "execution record id in task_history",
        "session_id_meaning": "conversation/runtime channel id",
    }


def _normalize_offset(raw_offset: Any) -> int:
    try:
        offset = int(raw_offset or 0)
    except Exception:  # noqa: BLE001
        offset = 0
    return max(offset, 0)


def _resolve_target_ids(params: dict[str, Any]) -> tuple[str, str]:
    task_id = str(params.get("task_id") or "").strip()
    session_id = str(params.get("session_id") or "").strip()
    if not task_id and not session_id:
        raise CLIError("task_id or session_id required", code="missing_required")
    if task_id and session_id:
        raise CLIError(
            "Provide either task_id or session_id, not both",
            code="invalid_arguments",
        )
    return task_id, session_id


def _append_message(
    messages: list[dict[str, Any]],
    *,
    role: str,
    content: str,
    source: str,
    cycle: Any = None,
) -> None:
    text = str(content or "").strip()
    if not text:
        return
    if (
        messages
        and str(messages[-1].get("role") or "") == role
        and str(messages[-1].get("content") or "") == text
    ):
        return

    item: dict[str, Any] = {
        "index": len(messages) + 1,
        "role": role,
        "content": text,
        "source": source,
    }
    try:
        if cycle is not None:
            item["cycle"] = int(cycle)
    except Exception:  # noqa: BLE001
        pass
    messages.append(item)


def build_messages_from_task(task: dict[str, Any]) -> list[dict[str, Any]]:
    messages: list[dict[str, Any]] = []
    prompt = str(task.get("prompt") or "").strip()
    if prompt:
        _append_message(messages, role="user", content=prompt, source="prompt")

    progress = task.get("progress", [])
    if isinstance(progress, list):
        for item in progress:
            if not isinstance(item, dict):
                continue
            event_type = str(item.get("type") or "").strip()
            if event_type == "user_message":
                text = str(
                    item.get("content") or item.get("text") or item.get("message") or ""
                ).strip()
                _append_message(
                    messages,
                    role="user",
                    content=text,
                    source="progress.user_message",
                    cycle=item.get("cycle"),
                )
            elif event_type == "llm_response":
                text = str(item.get("content") or item.get("preview") or "").strip()
                _append_message(
                    messages,
                    role="assistant",
                    content=text,
                    source="progress.llm_response",
                    cycle=item.get("cycle"),
                )

    final_answer = str(task.get("final_answer") or "").strip()
    if final_answer:
        _append_message(
            messages,
            role="assistant",
            content=final_answer,
            source="final_answer",
        )
    return messages


def _filter_messages(
    messages: list[dict[str, Any]],
    *,
    role: str = "",
    query: str = "",
) -> list[dict[str, Any]]:
    filtered = messages
    normalized_role = _normalize_message_role(role)
    if normalized_role:
        filtered = [item for item in filtered if str(item.get("role") or "") == normalized_role]

    text = str(query or "").strip()
    if text:
        needle = text.lower()
        filtered = [item for item in filtered if needle in str(item.get("content") or "").lower()]
    return filtered


def build_message_list_payload(
    task: dict[str, Any],
    *,
    role: str = "",
    query: str = "",
    limit: int,
    offset: int,
    requested_by: str = "",
) -> dict[str, Any]:
    messages = _filter_messages(
        build_messages_from_task(task),
        role=role,
        query=query,
    )
    return {
        "task_id": str(task.get("task_id") or ""),
        "session_id": str(task.get("session_id") or ""),
        "total": len(messages),
        "messages": messages[offset : offset + limit],
        "meta": {"id_model": build_id_model_meta(requested_by=requested_by)},
    }


def build_last_message_payload(
    task: dict[str, Any],
    *,
    role: str = "",
    requested_by: str = "",
) -> dict[str, Any]:
    messages = _filter_messages(build_messages_from_task(task), role=role)
    return {
        "task_id": str(task.get("task_id") or ""),
        "session_id": str(task.get("session_id") or ""),
        "total": len(messages),
        "message": messages[-1] if messages else None,
        "meta": {"id_model": build_id_model_meta(requested_by=requested_by)},
    }


def _resolve_task_record_local(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id, session_id = _resolve_target_ids(params)
    payload = (
        get_task(ctx, {"task_id": task_id})
        if task_id
        else get_by_session(ctx, {"session_id": session_id})
    )
    task = payload.get("task")
    if not isinstance(task, dict):
        raise CLIError("Task not found", code="not_found")
    return task


def resolve_task_record(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id, session_id = _resolve_target_ids(params)
    if task_id:
        request_params = {"task_id": task_id}
        result = invoke(
            method="task_history.get",
            params=request_params,
            ctx=ctx,
            local_call=lambda: get_task(ctx, request_params),
        )
    else:
        request_params = {"session_id": session_id}
        result = invoke(
            method="task_history.get_by_session",
            params=request_params,
            ctx=ctx,
            local_call=lambda: get_by_session(ctx, request_params),
        )

    task = result.get("task") if isinstance(result, dict) else None
    if not isinstance(task, dict):
        raise CLIError("Task not found", code="not_found")
    return task


def _list_descendants(conn: Any, root_task_id: str) -> list[dict[str, str]]:
    results: list[dict[str, str]] = []
    pending: deque[str] = deque([root_task_id])
    visited: set[str] = set()

    while pending:
        current = pending.popleft()
        if current in visited:
            continue
        visited.add(current)

        row = conn.execute(
            "SELECT task_id, session_id FROM task_history WHERE task_id = ? LIMIT 1",
            (current,),
        ).fetchone()
        if row:
            results.append(
                {
                    "task_id": str(row["task_id"]),
                    "session_id": str(row["session_id"] or ""),
                }
            )

        child_rows = conn.execute(
            "SELECT task_id FROM task_history WHERE parent_task_id = ?",
            (current,),
        ).fetchall()
        for child in child_rows:
            child_id = str(child["task_id"] or "").strip()
            if child_id and child_id not in visited:
                pending.append(child_id)

    return results


def list_tasks(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    limit = normalize_positive_int(params.get("limit"), default=50)
    offset = max(int(params.get("offset", 0) or 0), 0)
    include_sub_tasks = parse_bool(params.get("include_sub_tasks"), default=False)
    include_chat_tasks = parse_bool(params.get("include_chat_tasks"), default=False)
    agent_id = str(params.get("agent_id") or "").strip()
    status = str(params.get("status") or "").strip()

    where: list[str] = []
    values: list[Any] = []
    if not include_sub_tasks:
        where.append("is_sub_task = 0")
    if not include_chat_tasks:
        where.append("session_kind != 'chat'")
    if agent_id:
        where.append("agent_id = ?")
        values.append(agent_id)
    if status:
        where.append("status = ?")
        values.append(status)

    where_clause = f"WHERE {' AND '.join(where)}" if where else ""

    with connect(ctx.db_path) as conn:
        rows = conn.execute(
            f"""
            SELECT * FROM task_history
            {where_clause}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
            """,
            tuple(values + [limit, offset]),
        ).fetchall()
    return {"tasks": [_row_to_task(row) for row in rows]}


def get_task(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id = str(params.get("task_id") or "").strip()
    if not task_id:
        raise CLIError("task_id required", code="missing_required")

    with connect(ctx.db_path) as conn:
        row = conn.execute(
            "SELECT * FROM task_history WHERE task_id = ? LIMIT 1",
            (task_id,),
        ).fetchone()
    if not row:
        raise CLIError("Task not found", code="not_found")
    return {
        "task": _row_to_task(row),
        "meta": {"id_model": build_id_model_meta(requested_by="task_id")},
    }


def get_by_session(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")
    with connect(ctx.db_path) as conn:
        row = conn.execute(
            "SELECT * FROM task_history WHERE session_id = ? LIMIT 1",
            (session_id,),
        ).fetchone()
    if not row:
        raise CLIError("Task not found", code="not_found")
    return {
        "task": _row_to_task(row),
        "meta": {"id_model": build_id_model_meta(requested_by="session_id")},
    }


def toggle_favorite(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id = str(params.get("task_id") or "").strip()
    if not task_id:
        raise CLIError("task_id required", code="missing_required")

    with connect(ctx.db_path, write=True) as conn:
        row = conn.execute(
            "SELECT is_favorite FROM task_history WHERE task_id = ? LIMIT 1",
            (task_id,),
        ).fetchone()
        if not row:
            return {"ok": False}
        next_value = 0 if int(row["is_favorite"] or 0) else 1
        cur = conn.execute(
            "UPDATE task_history SET is_favorite = ? WHERE task_id = ?",
            (next_value, task_id),
        )
    return {"ok": bool(cur.rowcount), "is_favorite": bool(next_value)}


def delete_task(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id = str(params.get("task_id") or "").strip()
    if not task_id:
        raise CLIError("task_id required", code="missing_required")

    with connect(ctx.db_path, write=True) as conn:
        descendants = _list_descendants(conn, task_id)
        task_ids = [item["task_id"] for item in descendants if item.get("task_id")]
        if not task_ids:
            return {"ok": False, "deleted": 0, "task_ids": []}

        placeholders = ", ".join("?" for _ in task_ids)
        cur = conn.execute(
            f"DELETE FROM task_history WHERE task_id IN ({placeholders})",
            tuple(task_ids),
        )

    deleted_count = int(cur.rowcount if cur.rowcount >= 0 else len(task_ids))
    return {
        "ok": deleted_count > 0,
        "deleted": deleted_count,
        "task_ids": task_ids,
    }


def recent_tasks(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    payload = dict(params)
    payload["offset"] = 0
    return list_tasks(ctx, payload)


def messages(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task = _resolve_task_record_local(ctx, params)
    limit = normalize_positive_int(params.get("limit"), default=50)
    offset = _normalize_offset(params.get("offset"))
    role = str(params.get("role") or "")
    requested_by = "task_id" if str(params.get("task_id") or "").strip() else "session_id"
    return build_message_list_payload(
        task,
        role=role,
        limit=limit,
        offset=offset,
        requested_by=requested_by,
    )


def search_messages(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    query = str(params.get("query") or "").strip()
    if not query:
        raise CLIError("query required", code="missing_required")
    task = _resolve_task_record_local(ctx, params)
    limit = normalize_positive_int(params.get("limit"), default=50)
    offset = _normalize_offset(params.get("offset"))
    role = str(params.get("role") or "")
    requested_by = "task_id" if str(params.get("task_id") or "").strip() else "session_id"
    return build_message_list_payload(
        task,
        role=role,
        query=query,
        limit=limit,
        offset=offset,
        requested_by=requested_by,
    )


def last_message(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task = _resolve_task_record_local(ctx, params)
    role = str(params.get("role") or "")
    requested_by = "task_id" if str(params.get("task_id") or "").strip() else "session_id"
    return build_last_message_payload(
        task,
        role=role,
        requested_by=requested_by,
    )


def _runtime_only_local_fallback() -> dict[str, Any]:
    raise CLIError(
        (
            "task transcript command requires runtime API; use --mode api/auto "
            "with a running v-claw instance"
        ),
        code="runtime_api_required",
    )


def _transcript_stub(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    return _runtime_only_local_fallback()


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "list": list_tasks,
        "get": get_task,
        "get_by_session": get_by_session,
        "toggle_favorite": toggle_favorite,
        "delete": delete_task,
        "recent": recent_tasks,
        "messages": messages,
        "search_messages": search_messages,
        "last_message": last_message,
        "transcript_turns": _transcript_stub,
        "transcript_stats": _transcript_stub,
        "transcript_search": _transcript_stub,
    }
    handler = handlers.get(method)
    if not handler:
        raise CLIError(f"Unknown task method: {method}", code="unknown_method")
    return handler(ctx, params)


def _invoke_task(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    return invoke(
        method=f"task_history.{method}",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch(method, params, ctx),
    )


def _invoke_task_runtime_only(
    method: str,
    params: dict[str, Any],
    ctx: CLIContext,
) -> dict[str, Any]:
    return invoke(
        method=f"task_history.{method}",
        params=params,
        ctx=ctx,
        local_call=_runtime_only_local_fallback,
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "task",
        help="Manage task history",
        epilog=(
            "Examples:\n"
            "  vclawctl task list --limit 10\n"
            "  vclawctl task get --task-id <id>\n"
            "  vclawctl task messages --session-id <id> --role assistant\n"
            "  vclawctl task transcript --session-id <id>"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    task_sub = parser.add_subparsers(dest="task_cmd", required=True)

    list_parser = task_sub.add_parser("list", help="List tasks")
    list_parser.add_argument("--agent-id", default="", help="Filter by agent ID")
    list_parser.add_argument("--status", default="", help="Filter by status")
    list_parser.add_argument("--limit", type=int, default=50, help="Max results (default: 50)")
    list_parser.add_argument(
        "--offset", type=int, default=0, help="Skip first N results (default: 0)"
    )
    list_parser.add_argument(
        "--include-sub-tasks", action="store_true", help="Include sub-tasks in results"
    )
    list_parser.add_argument(
        "--include-chat-tasks", action="store_true", help="Include chat-initiated tasks"
    )
    list_parser.set_defaults(func=_cmd_list)

    get_parser = task_sub.add_parser("get", help="Get task by task_id")
    get_parser.add_argument("--task-id", required=True, help="Task ID to retrieve")
    get_parser.set_defaults(func=_cmd_get)

    by_session_parser = task_sub.add_parser("by-session", help="Get task by session_id")
    by_session_parser.add_argument("--session-id", required=True, help="Session ID to look up task")
    by_session_parser.set_defaults(func=_cmd_by_session)

    fav_parser = task_sub.add_parser("toggle-favorite", help="Toggle favorite")
    fav_parser.add_argument("--task-id", required=True, help="Task ID to toggle")
    fav_parser.set_defaults(func=_cmd_toggle_favorite)

    delete_parser = task_sub.add_parser("delete", help="Delete task recursively")
    delete_parser.add_argument("--task-id", required=True, help="Task ID to delete")
    delete_parser.add_argument("--yes", action="store_true", help="Confirm recursive deletion")
    delete_parser.set_defaults(func=_cmd_delete)

    recent_parser = task_sub.add_parser("recent", help="List recent tasks")
    recent_parser.add_argument("--limit", type=int, default=5, help="Max results (default: 5)")
    recent_parser.add_argument("--include-sub-tasks", action="store_true", help="Include sub-tasks")
    recent_parser.add_argument(
        "--include-chat-tasks", action="store_true", help="Include chat-initiated tasks"
    )
    recent_parser.set_defaults(func=_cmd_recent)

    messages_parser = task_sub.add_parser("messages", help="List messages in a task/session")
    messages_target = messages_parser.add_mutually_exclusive_group(required=True)
    messages_target.add_argument(
        "--task-id", default="", help="Task ID (mutually exclusive with --session-id)"
    )
    messages_target.add_argument(
        "--session-id", default="", help="Session ID (mutually exclusive with --task-id)"
    )
    messages_parser.add_argument(
        "--role",
        default="",
        help="Filter role: user|assistant|system|tool",
    )
    messages_parser.add_argument("--limit", type=int, default=50, help="Max results (default: 50)")
    messages_parser.add_argument(
        "--offset", type=int, default=0, help="Skip first N results (default: 0)"
    )
    messages_parser.set_defaults(func=_cmd_messages)

    search_parser = task_sub.add_parser(
        "search-messages",
        help="Search messages in a task/session",
    )
    search_target = search_parser.add_mutually_exclusive_group(required=True)
    search_target.add_argument(
        "--task-id", default="", help="Task ID (mutually exclusive with --session-id)"
    )
    search_target.add_argument(
        "--session-id", default="", help="Session ID (mutually exclusive with --task-id)"
    )
    search_parser.add_argument("--query", required=True, help="Search text")
    search_parser.add_argument("--role", default="", help="Filter role: user|assistant|system|tool")
    search_parser.add_argument("--limit", type=int, default=50, help="Max results (default: 50)")
    search_parser.add_argument(
        "--offset", type=int, default=0, help="Skip first N results (default: 0)"
    )
    search_parser.set_defaults(func=_cmd_search_messages)

    last_parser = task_sub.add_parser("last-message", help="Show last message in a task/session")
    last_target = last_parser.add_mutually_exclusive_group(required=True)
    last_target.add_argument(
        "--task-id", default="", help="Task ID (mutually exclusive with --session-id)"
    )
    last_target.add_argument(
        "--session-id", default="", help="Session ID (mutually exclusive with --task-id)"
    )
    last_parser.add_argument("--role", default="", help="Filter role: user|assistant|system|tool")
    last_parser.set_defaults(func=_cmd_last_message)

    transcript_parser = task_sub.add_parser(
        "transcript",
        help="List transcript turns by session_id",
    )
    transcript_parser.add_argument(
        "--session-id", required=True, help="Session ID to query transcript"
    )
    transcript_parser.add_argument(
        "--role", default="", help="Filter by role: user, assistant, tool"
    )
    transcript_parser.add_argument(
        "--limit", type=int, default=200, help="Max turns (default: 200)"
    )
    transcript_parser.add_argument(
        "--offset", type=int, default=0, help="Skip first N turns (default: 0)"
    )
    transcript_parser.set_defaults(func=_cmd_transcript)

    transcript_stats_parser = task_sub.add_parser(
        "transcript-stats",
        help="Get transcript stats by session_id",
    )
    transcript_stats_parser.add_argument(
        "--session-id", required=True, help="Session ID to query stats"
    )
    transcript_stats_parser.set_defaults(func=_cmd_transcript_stats)

    transcript_search_parser = task_sub.add_parser(
        "transcript-search",
        help="Search transcript turns",
    )
    transcript_search_parser.add_argument(
        "--query", required=True, help="Search text in transcript"
    )
    transcript_search_parser.add_argument("--session-id", default="", help="Filter by session ID")
    transcript_search_parser.add_argument("--role", default="", help="Filter by role")
    transcript_search_parser.add_argument(
        "--cycle", default="", help="Filter by agent cycle number"
    )
    transcript_search_parser.add_argument(
        "--limit", type=int, default=20, help="Max results (default: 20)"
    )
    transcript_search_parser.add_argument(
        "--offset", type=int, default=0, help="Skip first N results (default: 0)"
    )
    transcript_search_parser.set_defaults(func=_cmd_transcript_search)


def _cmd_list(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "agent_id": args.agent_id,
        "status": args.status,
        "limit": args.limit,
        "offset": args.offset,
        "include_sub_tasks": args.include_sub_tasks,
        "include_chat_tasks": args.include_chat_tasks,
    }
    return _invoke_task("list", params, ctx)


def _cmd_get(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"task_id": args.task_id}
    return _invoke_task("get", params, ctx)


def _cmd_by_session(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"session_id": args.session_id}
    return _invoke_task("get_by_session", params, ctx)


def _cmd_toggle_favorite(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"task_id": args.task_id}
    return _invoke_task("toggle_favorite", params, ctx)


def _cmd_delete(args: Any, ctx: CLIContext) -> dict[str, Any]:
    if not args.yes:
        raise CLIError("delete requires --yes", code="confirmation_required")
    params = {"task_id": args.task_id}
    return _invoke_task("delete", params, ctx)


def _cmd_recent(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "limit": args.limit,
        "include_sub_tasks": args.include_sub_tasks,
        "include_chat_tasks": args.include_chat_tasks,
    }
    return _invoke_task("recent", params, ctx)


def _cmd_messages(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "task_id": args.task_id,
        "session_id": args.session_id,
    }
    task = resolve_task_record(ctx, params)
    requested_by = "task_id" if str(args.task_id or "").strip() else "session_id"
    return build_message_list_payload(
        task,
        role=args.role,
        limit=normalize_positive_int(args.limit, default=50),
        offset=_normalize_offset(args.offset),
        requested_by=requested_by,
    )


def _cmd_search_messages(args: Any, ctx: CLIContext) -> dict[str, Any]:
    query = str(args.query or "").strip()
    if not query:
        raise CLIError("query required", code="missing_required")
    params = {
        "task_id": args.task_id,
        "session_id": args.session_id,
    }
    task = resolve_task_record(ctx, params)
    requested_by = "task_id" if str(args.task_id or "").strip() else "session_id"
    return build_message_list_payload(
        task,
        role=args.role,
        query=query,
        limit=normalize_positive_int(args.limit, default=50),
        offset=_normalize_offset(args.offset),
        requested_by=requested_by,
    )


def _cmd_last_message(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "task_id": args.task_id,
        "session_id": args.session_id,
    }
    task = resolve_task_record(ctx, params)
    requested_by = "task_id" if str(args.task_id or "").strip() else "session_id"
    return build_last_message_payload(
        task,
        role=args.role,
        requested_by=requested_by,
    )


def _cmd_transcript(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "session_id": str(args.session_id or "").strip(),
        "limit": normalize_positive_int(args.limit, default=200),
        "offset": _normalize_offset(args.offset),
    }
    role = str(args.role or "").strip()
    if role:
        params["role"] = role
    return _invoke_task_runtime_only("transcript_turns", params, ctx)


def _cmd_transcript_stats(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"session_id": str(args.session_id or "").strip()}
    return _invoke_task_runtime_only("transcript_stats", params, ctx)


def _cmd_transcript_search(args: Any, ctx: CLIContext) -> dict[str, Any]:
    query = str(args.query or "").strip()
    if not query:
        raise CLIError("query required", code="missing_required")
    params = {
        "query": query,
        "limit": normalize_positive_int(args.limit, default=20),
        "offset": _normalize_offset(args.offset),
    }
    session_id = str(args.session_id or "").strip()
    role = str(args.role or "").strip()
    cycle = str(args.cycle or "").strip()
    if session_id:
        params["session_id"] = session_id
    if role:
        params["role"] = role
    if cycle:
        try:
            params["cycle"] = int(cycle)
        except Exception as exc:  # noqa: BLE001
            raise CLIError("cycle must be integer", code="invalid_arguments") from exc
    return _invoke_task_runtime_only("transcript_search", params, ctx)
