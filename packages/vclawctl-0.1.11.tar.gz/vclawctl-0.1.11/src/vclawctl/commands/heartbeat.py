"""Heartbeat command handlers."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

from vclawctl.context import CLIContext
from vclawctl.errors import CLIError
from vclawctl.sdk.heartbeat import HeartbeatSDK


def _sdk(ctx: CLIContext) -> HeartbeatSDK:
    return HeartbeatSDK(ctx)


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "heartbeat",
        help="Manage heartbeat config, HEARTBEAT.md, and heartbeat tasks",
        description=(
            "Manage heartbeat as a first-class control surface.\n"
            "By default, file-oriented commands use the configured heartbeat main agent.\n"
            "Use --agent-id to override the target agent explicitly."
        ),
        epilog=(
            "Examples:\n"
            "  vclawctl heartbeat show\n"
            "  vclawctl heartbeat set --enabled true --interval-seconds 1800 "
            "--notify-policy im_owner\n"
            "  vclawctl heartbeat read\n"
            "  vclawctl heartbeat add-item --text \"检查今天的重要消息\"\n"
            "  vclawctl heartbeat tasks --status error"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    heartbeat_sub = parser.add_subparsers(dest="heartbeat_cmd", required=True)

    show_parser = heartbeat_sub.add_parser("show", help="Show combined heartbeat state")
    show_parser.add_argument("--agent-id", default="", help="Override target agent ID")
    show_parser.add_argument(
        "--task-limit",
        type=int,
        default=5,
        help="How many recent heartbeat tasks to include (default: 5)",
    )
    show_parser.set_defaults(func=_cmd_show)

    status_parser = heartbeat_sub.add_parser("status", help="Show heartbeat runtime status")
    status_parser.set_defaults(func=_cmd_status)

    config_parser = heartbeat_sub.add_parser("config", help="Show normalized heartbeat config")
    config_parser.set_defaults(func=_cmd_config)

    set_parser = heartbeat_sub.add_parser("set", help="Update heartbeat config fields")
    set_parser.add_argument("--enabled", default="", help="true/false")
    set_parser.add_argument(
        "--interval-seconds",
        default="",
        help="Run interval in seconds (clamped to 300-7200)",
    )
    set_parser.add_argument("--start", default="", help="Active window start, e.g. 08:00")
    set_parser.add_argument("--end", default="", help="Active window end, e.g. 23:00")
    set_parser.add_argument("--timezone", default="", help="IANA timezone, e.g. Asia/Shanghai")
    set_parser.add_argument("--main-agent-id", default="", help="Agent ID used for heartbeat")
    set_parser.add_argument(
        "--notify-policy",
        default="",
        help="none|im_owner|chat_inject|im_owner_or_chat|im_owner_and_chat",
    )
    set_parser.set_defaults(func=_cmd_set)

    enable_parser = heartbeat_sub.add_parser("enable", help="Enable heartbeat")
    enable_parser.set_defaults(func=_cmd_enable)

    disable_parser = heartbeat_sub.add_parser("disable", help="Disable heartbeat")
    disable_parser.set_defaults(func=_cmd_disable)

    read_parser = heartbeat_sub.add_parser("read", help="Read HEARTBEAT.md")
    read_parser.add_argument("--agent-id", default="", help="Override target agent ID")
    read_parser.set_defaults(func=_cmd_read)

    write_parser = heartbeat_sub.add_parser("write", help="Replace HEARTBEAT.md content")
    write_parser.add_argument("--agent-id", default="", help="Override target agent ID")
    write_parser.add_argument("--content", default="", help="Inline content to write")
    write_parser.add_argument("--file", default="", help="Load content from local file path")
    write_parser.set_defaults(func=_cmd_write)

    clear_parser = heartbeat_sub.add_parser("clear", help="Reset HEARTBEAT.md to default template")
    clear_parser.add_argument("--agent-id", default="", help="Override target agent ID")
    clear_parser.set_defaults(func=_cmd_clear)

    items_parser = heartbeat_sub.add_parser("items", help="List parsed checklist items")
    items_parser.add_argument("--agent-id", default="", help="Override target agent ID")
    items_parser.set_defaults(func=_cmd_items)

    add_item_parser = heartbeat_sub.add_parser("add-item", help="Append one checklist item")
    add_item_parser.add_argument("--agent-id", default="", help="Override target agent ID")
    add_item_parser.add_argument("--text", required=True, help="Checklist item text")
    add_item_parser.set_defaults(func=_cmd_add_item)

    remove_item_parser = heartbeat_sub.add_parser("remove-item", help="Remove checklist items")
    remove_item_parser.add_argument("--agent-id", default="", help="Override target agent ID")
    remove_item_parser.add_argument(
        "--index",
        type=int,
        default=0,
        help="1-based item index returned by `heartbeat items`",
    )
    remove_item_parser.add_argument(
        "--match",
        default="",
        help="Case-insensitive text match against checklist item content",
    )
    remove_item_parser.add_argument(
        "--all-matches",
        default="false",
        help="When using --match, remove every matched item (default: false)",
    )
    remove_item_parser.set_defaults(func=_cmd_remove_item)

    tasks_parser = heartbeat_sub.add_parser("tasks", help="List heartbeat tasks only")
    tasks_parser.add_argument("--agent-id", default="", help="Override target agent ID")
    tasks_parser.add_argument(
        "--status",
        default="",
        help="Filter by task status: running|completed|error|paused|pending_approval|max_cycles",
    )
    tasks_parser.add_argument("--limit", type=int, default=20, help="Result limit (default: 20)")
    tasks_parser.add_argument("--offset", type=int, default=0, help="Result offset (default: 0)")
    tasks_parser.set_defaults(func=_cmd_tasks)

    task_parser = heartbeat_sub.add_parser("task", help="Get one heartbeat task by task_id")
    task_parser.add_argument("--task-id", required=True, help="Heartbeat task ID")
    task_parser.set_defaults(func=_cmd_task)


def _cmd_show(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return _sdk(ctx).inspect(
        agent_id=str(args.agent_id or "").strip(),
        task_limit=max(int(args.task_limit or 5), 0),
    )


def _cmd_status(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _sdk(ctx).status()


def _cmd_config(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _sdk(ctx).get_config()


def _cmd_set(args: Any, ctx: CLIContext) -> dict[str, Any]:
    patch: dict[str, Any] = {}
    if str(args.enabled or "").strip():
        patch["enabled"] = str(args.enabled).strip()
    if str(args.interval_seconds or "").strip():
        patch["interval_seconds"] = str(args.interval_seconds).strip()
    if str(args.timezone or "").strip():
        patch["timezone"] = str(args.timezone).strip()
    if str(args.main_agent_id or "").strip():
        patch["main_agent_id"] = str(args.main_agent_id).strip()
    if str(args.notify_policy or "").strip():
        patch["notify_policy"] = str(args.notify_policy).strip()
    active_hours: dict[str, Any] = {}
    if str(args.start or "").strip():
        active_hours["start"] = str(args.start).strip()
    if str(args.end or "").strip():
        active_hours["end"] = str(args.end).strip()
    if active_hours:
        patch["active_hours"] = active_hours
    if not patch:
        raise CLIError("at least one config field is required", code="missing_required")
    return _sdk(ctx).update_config(patch)


def _cmd_enable(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _sdk(ctx).update_config({"enabled": True})


def _cmd_disable(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _sdk(ctx).update_config({"enabled": False})


def _cmd_read(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return _sdk(ctx).read_file(agent_id=str(args.agent_id or "").strip())


def _load_file_content(file_path: str) -> str:
    try:
        return Path(file_path).read_text(encoding="utf-8")
    except OSError as exc:
        raise CLIError(f"failed to read file: {exc}", code="file_read_error") from exc


def _cmd_write(args: Any, ctx: CLIContext) -> dict[str, Any]:
    inline_content = str(args.content or "")
    file_path = str(args.file or "").strip()
    if file_path and inline_content:
        raise CLIError("use either --content or --file", code="invalid_arguments")
    if file_path:
        inline_content = _load_file_content(file_path)
    if not file_path and not inline_content:
        raise CLIError("--content or --file required", code="missing_required")
    return _sdk(ctx).write_file(
        agent_id=str(args.agent_id or "").strip(),
        content=inline_content,
    )


def _cmd_clear(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return _sdk(ctx).clear_file(agent_id=str(args.agent_id or "").strip())


def _cmd_items(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return _sdk(ctx).list_items(agent_id=str(args.agent_id or "").strip())


def _cmd_add_item(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return _sdk(ctx).add_item(
        agent_id=str(args.agent_id or "").strip(),
        text=str(args.text or "").strip(),
    )


def _cmd_remove_item(args: Any, ctx: CLIContext) -> dict[str, Any]:
    raw_index = int(args.index or 0)
    match = str(args.match or "").strip()
    if raw_index and match:
        raise CLIError("use either --index or --match", code="invalid_arguments")
    if not raw_index and not match:
        raise CLIError("--index or --match required", code="missing_required")
    remove_all = str(args.all_matches or "").strip().lower() in {"1", "true", "yes", "on"}
    return _sdk(ctx).remove_item(
        agent_id=str(args.agent_id or "").strip(),
        index=raw_index or None,
        match=match,
        remove_all=remove_all,
    )


def _cmd_tasks(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return _sdk(ctx).list_tasks(
        agent_id=str(args.agent_id or "").strip(),
        status=str(args.status or "").strip(),
        limit=max(int(args.limit or 20), 1),
        offset=max(int(args.offset or 0), 0),
    )


def _cmd_task(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return _sdk(ctx).get_task(task_id=str(args.task_id or "").strip())


__all__ = ["register"]
