"""Memory command handlers."""

from __future__ import annotations

import argparse
from typing import Any

from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import normalize_positive_int, parse_bool, parse_json_object
from vclawctl.errors import CLIError


def _runtime_only_local_fallback() -> dict[str, Any]:
    raise CLIError(
        "memory command requires runtime API; use --mode api/auto with a running v-claw instance",
        code="runtime_api_required",
    )


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    method_name = str(method or "").strip()
    if not method_name:
        raise CLIError("memory method required", code="missing_required")
    return invoke(
        method=f"memory.{method_name}",
        params=params,
        ctx=ctx,
        local_call=_runtime_only_local_fallback,
    )


def _normalize_agent_id(raw_agent_id: Any, *, default: str = "default") -> str:
    return str(raw_agent_id or default).strip() or default


def _parse_optional_int(raw: Any, *, default: int, minimum: int) -> int:
    try:
        value = int(raw)
    except Exception:  # noqa: BLE001
        value = default
    return max(minimum, value)


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "memory",
        help="Manage memory runtime",
        epilog=(
            "Examples:\n"
            "  vclawctl memory list --agent-id default\n"
            '  vclawctl memory search --query "project setup"\n'
            '  vclawctl memory add --content "User prefers dark mode"\n'
            "  vclawctl memory stats"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    memory_sub = parser.add_subparsers(dest="memory_cmd", required=True)

    list_parser = memory_sub.add_parser("list", help="List memories with filters")
    list_parser.add_argument("--agent-id", default="default", help="Agent ID (default: default)")
    list_parser.add_argument("--status", default="", help="Filter by status: active, archived")
    list_parser.add_argument(
        "--memory-type", default="", help="Filter by type: fact, preference, episode, etc."
    )
    list_parser.add_argument(
        "--source-kind", default="", help="Filter by source: manual, auto, imported"
    )
    list_parser.add_argument("--query", default="", help="Filter by text match")
    list_parser.add_argument("--limit", type=int, default=20, help="Max results (default: 20)")
    list_parser.add_argument(
        "--offset", type=int, default=0, help="Skip first N results (default: 0)"
    )
    list_parser.set_defaults(func=_cmd_list)

    search_parser = memory_sub.add_parser("search", help="Search memory entries")
    search_parser.add_argument("--query", required=True, help="Search text")
    search_parser.add_argument("--agent-id", default="default", help="Agent ID (default: default)")
    search_parser.add_argument("--session-id", default="", help="Filter by session ID")
    search_parser.add_argument("--limit", type=int, default=10, help="Max results (default: 10)")
    search_parser.add_argument(
        "--include-episodic", default="true", help="Include episodic memories (default: true)"
    )
    search_parser.set_defaults(func=_cmd_search)

    get_parser = memory_sub.add_parser("get", help="Get one memory by memory_id")
    get_parser.add_argument("--memory-id", required=True, help="Memory entry ID")
    get_parser.set_defaults(func=_cmd_get)

    add_parser = memory_sub.add_parser("add", help="Add one memory")
    add_parser.add_argument("--content", required=True, help="Memory content text")
    add_parser.add_argument("--agent-id", default="default", help="Agent ID (default: default)")
    add_parser.add_argument("--session-id", default="", help="Associated session ID")
    add_parser.add_argument("--task-id", default="", help="Associated task ID")
    add_parser.add_argument("--memory-type", default="fact", help="Memory type (default: fact)")
    add_parser.add_argument("--source-kind", default="manual", help="Source kind (default: manual)")
    add_parser.add_argument(
        "--importance", type=float, default=0.8, help="Importance score 0.0-1.0 (default: 0.8)"
    )
    add_parser.add_argument("--metadata-json", default="{}", help="Extra metadata JSON object")
    add_parser.set_defaults(func=_cmd_add)

    update_parser = memory_sub.add_parser(
        "update",
        aliases=["edit"],
        help="Update one memory by memory_id",
    )
    update_parser.add_argument("--memory-id", required=True, help="Memory entry ID to update")
    update_parser.add_argument("--content", default="", help="New content text")
    update_parser.add_argument("--memory-type", default="", help="New memory type")
    update_parser.add_argument("--status", default="", help="New status: active, archived")
    update_parser.add_argument("--importance", default="", help="New importance score 0.0-1.0")
    update_parser.add_argument("--metadata-json", default="", help="Metadata JSON to merge")
    update_parser.set_defaults(func=_cmd_update)

    delete_parser = memory_sub.add_parser("delete", help="Delete one memory by memory_id")
    delete_parser.add_argument("--memory-id", required=True, help="Memory entry ID to delete")
    delete_parser.set_defaults(func=_cmd_delete)

    stats_parser = memory_sub.add_parser("stats", help="Get memory stats")
    stats_parser.add_argument("--agent-id", default="default", help="Agent ID (default: default)")
    stats_parser.set_defaults(func=_cmd_stats)

    get_file_parser = memory_sub.add_parser("get-file", help="Read memory source file")
    get_file_parser.add_argument("--path", required=True, help="Memory source file path")
    get_file_parser.add_argument(
        "--from-line", type=int, default=1, help="Start line number (default: 1)"
    )
    get_file_parser.add_argument(
        "--lines", type=int, default=200, help="Number of lines to read (default: 200)"
    )
    get_file_parser.set_defaults(func=_cmd_get_file)

    import_parser = memory_sub.add_parser(
        "import-openclaw",
        help="Import OpenClaw memory markdown and optional sessions JSONL",
    )
    import_parser.add_argument(
        "--workspace-path", required=True, help="OpenClaw workspace directory"
    )
    import_parser.add_argument(
        "--agent-id", default="default", help="Target agent ID (default: default)"
    )
    import_parser.add_argument(
        "--include-sessions", default="false", help="Import session data (default: false)"
    )
    import_parser.add_argument("--sessions-dir", default="", help="Sessions JSONL directory")
    import_parser.set_defaults(func=_cmd_import_openclaw)

    rebuild_parser = memory_sub.add_parser("rebuild-index", help="Rebuild memory FTS/vector index")
    rebuild_parser.add_argument("--agent-id", default="default", help="Agent ID (default: default)")
    rebuild_parser.set_defaults(func=_cmd_rebuild_index)


def _cmd_list(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params: dict[str, Any] = {
        "agent_id": _normalize_agent_id(args.agent_id),
        "limit": normalize_positive_int(args.limit, default=20),
        "offset": _parse_optional_int(args.offset, default=0, minimum=0),
    }
    status = str(args.status or "").strip()
    memory_type = str(args.memory_type or "").strip()
    source_kind = str(args.source_kind or "").strip()
    query = str(args.query or "").strip()
    if status:
        params["status"] = status
    if memory_type:
        params["memory_type"] = memory_type
    if source_kind:
        params["source_kind"] = source_kind
    if query:
        params["query"] = query
    return dispatch("list", params, ctx)


def _cmd_search(args: Any, ctx: CLIContext) -> dict[str, Any]:
    query = str(args.query or "").strip()
    if not query:
        raise CLIError("query required", code="missing_required")
    params = {
        "query": query,
        "agent_id": _normalize_agent_id(args.agent_id),
        "session_id": str(args.session_id or "").strip(),
        "limit": normalize_positive_int(args.limit, default=10),
        "include_episodic": parse_bool(args.include_episodic, default=True),
    }
    return dispatch("search", params, ctx)


def _cmd_get(args: Any, ctx: CLIContext) -> dict[str, Any]:
    memory_id = str(args.memory_id or "").strip()
    if not memory_id:
        raise CLIError("memory_id required", code="missing_required")
    return dispatch("get", {"memory_id": memory_id}, ctx)


def _cmd_add(args: Any, ctx: CLIContext) -> dict[str, Any]:
    content = str(args.content or "").strip()
    if not content:
        raise CLIError("content required", code="missing_required")
    params = {
        "content": content,
        "agent_id": _normalize_agent_id(args.agent_id),
        "session_id": str(args.session_id or "").strip(),
        "task_id": str(args.task_id or "").strip(),
        "memory_type": str(args.memory_type or "fact").strip() or "fact",
        "source_kind": str(args.source_kind or "manual").strip() or "manual",
        "importance": float(args.importance),
        "metadata": parse_json_object(args.metadata_json, field_name="metadata_json"),
    }
    return dispatch("add", params, ctx)


def _cmd_update(args: Any, ctx: CLIContext) -> dict[str, Any]:
    memory_id = str(args.memory_id or "").strip()
    if not memory_id:
        raise CLIError("memory_id required", code="missing_required")
    params: dict[str, Any] = {"memory_id": memory_id}
    content = str(args.content or "").strip()
    memory_type = str(args.memory_type or "").strip()
    status = str(args.status or "").strip()
    importance_text = str(args.importance or "").strip()
    metadata_text = str(args.metadata_json or "").strip()

    if content:
        params["content"] = content
    if memory_type:
        params["memory_type"] = memory_type
    if status:
        params["status"] = status
    if importance_text:
        try:
            params["importance"] = float(importance_text)
        except Exception as exc:  # noqa: BLE001
            raise CLIError("importance must be number", code="invalid_arguments") from exc
    if metadata_text:
        params["metadata"] = parse_json_object(metadata_text, field_name="metadata_json")

    if len(params) == 1:
        raise CLIError(
            "at least one update field required",
            code="missing_required",
        )
    return dispatch("update", params, ctx)


def _cmd_delete(args: Any, ctx: CLIContext) -> dict[str, Any]:
    memory_id = str(args.memory_id or "").strip()
    if not memory_id:
        raise CLIError("memory_id required", code="missing_required")
    return dispatch("delete", {"memory_id": memory_id}, ctx)


def _cmd_stats(args: Any, ctx: CLIContext) -> dict[str, Any]:
    agent_id = _normalize_agent_id(args.agent_id)
    return dispatch("stats", {"agent_id": agent_id}, ctx)


def _cmd_get_file(args: Any, ctx: CLIContext) -> dict[str, Any]:
    path = str(args.path or "").strip()
    if not path:
        raise CLIError("path required", code="missing_required")
    params = {
        "path": path,
        "from": _parse_optional_int(args.from_line, default=1, minimum=1),
        "lines": _parse_optional_int(args.lines, default=200, minimum=1),
    }
    return dispatch("get_file", params, ctx)


def _cmd_import_openclaw(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "workspace_path": str(args.workspace_path or "").strip(),
        "agent_id": _normalize_agent_id(args.agent_id),
        "include_sessions": parse_bool(args.include_sessions, default=False),
        "sessions_dir": str(args.sessions_dir or "").strip(),
    }
    if not params["workspace_path"]:
        raise CLIError("workspace_path required", code="missing_required")
    return dispatch("import_openclaw", params, ctx)


def _cmd_rebuild_index(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"agent_id": _normalize_agent_id(args.agent_id)}
    return dispatch("rebuild", params, ctx)


__all__ = ["register", "dispatch"]
