"""Skill catalog/import/binding command handlers."""

from __future__ import annotations

import argparse
import json
import shutil
import time
import uuid
from pathlib import Path
from typing import Any

from vclawctl.adapters.sqlite.db import connect, loads_json, read_config_json, upsert_config_json
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import parse_bool, parse_json_object
from vclawctl.errors import CLIError

GLOBAL_SCOPE_KEY = "global"
VALIDATION_MODE_CHOICES = ("strict", "compat", "minimal")


def _scope_key(agent_id: str | None = None) -> str:
    normalized = str(agent_id or "").strip()
    if not normalized:
        return GLOBAL_SCOPE_KEY
    return f"agent:{normalized}"


def _normalize_skill_id_list(raw: Any) -> list[str]:
    if not isinstance(raw, list):
        return []
    normalized: list[str] = []
    seen: set[str] = set()
    for item in raw:
        skill_id = str(item or "").strip()
        if not skill_id or skill_id in seen:
            continue
        seen.add(skill_id)
        normalized.append(skill_id)
    return normalized


def _imported_skill_root(ctx: CLIContext) -> Path:
    return (ctx.db_path.parent / "skills" / "imported").resolve()


def _remove_imported_skill_dir(ctx: CLIContext, skill_dir: str) -> bool:
    normalized = str(skill_dir or "").strip()
    if not normalized:
        return False
    imported_root = _imported_skill_root(ctx)
    try:
        candidate = Path(normalized).expanduser().resolve()
    except Exception:
        return False
    try:
        candidate.relative_to(imported_root)
    except ValueError:
        return False
    if not candidate.exists() or not candidate.is_dir():
        return False
    shutil.rmtree(candidate, ignore_errors=True)
    return True


def _row_to_catalog(row: Any) -> dict[str, Any]:
    return {
        "skill_id": str(row["skill_id"]),
        "name": str(row["name"] or ""),
        "description": str(row["description"] or ""),
        "version": str(row["version"] or "0.0.0"),
        "source_type": str(row["source_type"] or "local"),
        "source_path": str(row["source_path"] or ""),
        "skill_dir": str(row["skill_dir"] or ""),
        "manifest": loads_json(row["manifest_json"], {}),
        "required_tools": loads_json(row["required_tools_json"], []),
        "compatibility": str(row["compatibility"] or ""),
        "enabled": bool(int(row["enabled"] or 0)),
        "created_at": float(row["created_at"] or time.time()),
        "updated_at": float(row["updated_at"] or time.time()),
    }


def _row_to_installation(row: Any) -> dict[str, Any]:
    installation = {
        "installation_id": str(row["installation_id"]),
        "skill_id": str(row["skill_id"]),
        "scope_key": str(row["scope_key"] or GLOBAL_SCOPE_KEY),
        "is_enabled": bool(int(row["is_enabled"] or 0)),
        "config": loads_json(row["config_json"], {}),
        "created_at": float(row["created_at"] or time.time()),
        "updated_at": float(row["updated_at"] or time.time()),
    }
    if "skill_name" in row.keys():
        installation["skill_name"] = str(row["skill_name"] or "")
    if "skill_description" in row.keys():
        installation["skill_description"] = str(row["skill_description"] or "")
    if "skill_enabled" in row.keys():
        installation["skill_enabled"] = bool(int(row["skill_enabled"] or 0))
    return installation


def _row_to_agent(row: Any) -> dict[str, Any]:
    return {
        "agent_id": str(row["agent_id"]),
        "name": str(row["name"] or ""),
        "description": str(row["description"] or ""),
        "system_prompt": str(row["system_prompt"] or ""),
        "model_backend": str(row["model_backend"] or "moonshot"),
        "model_name": str(row["model_name"] or "kimi-k2.5"),
        "max_cycles": int(row["max_cycles"] or 20),
        "language": str(row["language"] or "zh-CN"),
        "allow_interruption": bool(int(row["allow_interruption"] or 0)),
        "use_workspace": bool(int(row["use_workspace"] or 0)),
        "load_user_memory": bool(int(row["load_user_memory"] or 0)),
        "default_workspace_path": str(row["default_workspace_path"] or ""),
        "tools": loads_json(row["tools_json"], []),
        "skills": _normalize_skill_id_list(loads_json(row["skills_json"], [])),
        "callable_sub_agents": loads_json(row["callable_sub_agents_json"], []),
        "created_at": float(row["created_at"] or time.time()),
        "updated_at": float(row["updated_at"] or time.time()),
    }


def _select_installation_rows(conn: Any, *, scope_key: str) -> list[Any]:
    return conn.execute(
        """
        SELECT i.*,
               c.name AS skill_name,
               c.description AS skill_description,
               c.enabled AS skill_enabled
        FROM skill_installations i
        JOIN skills_catalog c ON c.skill_id = i.skill_id
        WHERE i.scope_key = ?
        """,
        (scope_key,),
    ).fetchall()


def _upsert_installation(
    conn: Any,
    *,
    skill_id: str,
    scope_key: str,
    is_enabled: bool,
    config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    existing = conn.execute(
        """
        SELECT installation_id, created_at
        FROM skill_installations
        WHERE skill_id = ? AND scope_key = ?
        LIMIT 1
        """,
        (skill_id, scope_key),
    ).fetchone()
    installation_id = str(existing["installation_id"]) if existing else uuid.uuid4().hex[:12]
    created_at = float(existing["created_at"]) if existing else time.time()
    now = time.time()
    conn.execute(
        """
        INSERT INTO skill_installations(
            installation_id, skill_id, scope_key,
            is_enabled, config_json, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(skill_id, scope_key) DO UPDATE SET
            is_enabled = excluded.is_enabled,
            config_json = excluded.config_json,
            updated_at = excluded.updated_at
        """,
        (
            installation_id,
            skill_id,
            scope_key,
            int(is_enabled),
            json.dumps(dict(config or {}), ensure_ascii=False),
            created_at,
            now,
        ),
    )
    row = conn.execute(
        """
        SELECT i.*,
               c.name AS skill_name,
               c.description AS skill_description,
               c.enabled AS skill_enabled
        FROM skill_installations i
        JOIN skills_catalog c ON c.skill_id = i.skill_id
        WHERE i.installation_id = ?
        LIMIT 1
        """,
        (installation_id,),
    ).fetchone()
    if not row:
        raise CLIError("installation not found after upsert", code="install_failed")
    return _row_to_installation(row)


def _list_installations(conn: Any, *, agent_id: str | None = None) -> list[dict[str, Any]]:
    scope = _scope_key(agent_id)
    global_rows = _select_installation_rows(conn, scope_key=GLOBAL_SCOPE_KEY)
    global_map = {str(row["skill_id"]): row for row in global_rows}
    if scope == GLOBAL_SCOPE_KEY:
        result: list[dict[str, Any]] = []
        for row in global_rows:
            installation = _row_to_installation(row)
            installation["global_is_enabled"] = installation["is_enabled"]
            installation["global_installation_id"] = installation["installation_id"]
            installation["has_agent_override"] = False
            result.append(installation)
        result.sort(key=lambda item: str(item.get("skill_name", "")))
        return result

    agent_rows = _select_installation_rows(conn, scope_key=scope)
    agent_map = {str(row["skill_id"]): row for row in agent_rows}
    merged_skill_ids = set(global_map) | set(agent_map)
    result = []
    for skill_id in merged_skill_ids:
        base = agent_map.get(skill_id) or global_map.get(skill_id)
        if base is None:
            continue
        installation = _row_to_installation(base)
        global_row = global_map.get(skill_id)
        installation["global_is_enabled"] = (
            bool(int(global_row["is_enabled"] or 0)) if global_row is not None else None
        )
        installation["global_installation_id"] = (
            str(global_row["installation_id"]) if global_row is not None else None
        )
        installation["has_agent_override"] = skill_id in agent_map
        result.append(installation)
    result.sort(key=lambda item: str(item.get("skill_name", "")))
    return result


def list_catalog(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    include_disabled = bool(params.get("include_disabled", True))
    with connect(ctx.db_path) as conn:
        if include_disabled:
            rows = conn.execute(
                "SELECT * FROM skills_catalog ORDER BY updated_at DESC, name ASC"
            ).fetchall()
        else:
            rows = conn.execute(
                """
                SELECT * FROM skills_catalog
                WHERE enabled = 1
                ORDER BY updated_at DESC, name ASC
                """
            ).fetchall()
    return {"skills": [_row_to_catalog(row) for row in rows]}


def get_detail(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    skill_id = str(params.get("skill_id") or "").strip()
    if not skill_id:
        raise CLIError("skill_id required", code="missing_required")
    with connect(ctx.db_path) as conn:
        row = conn.execute(
            "SELECT * FROM skills_catalog WHERE skill_id = ? LIMIT 1",
            (skill_id,),
        ).fetchone()
    if not row:
        raise CLIError("Skill not found", code="not_found")
    return {"skill": _row_to_catalog(row)}


def install(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    skill_id = str(params.get("skill_id") or "").strip()
    if not skill_id:
        raise CLIError("skill_id required", code="missing_required")
    agent_id = str(params.get("agent_id", "") or "").strip() or None
    is_enabled = bool(params.get("is_enabled", True))
    config = params.get("config", {})
    if not isinstance(config, dict):
        raise CLIError("config must be an object", code="invalid_arguments")

    scope = _scope_key(agent_id)
    with connect(ctx.db_path, write=True) as conn:
        skill_row = conn.execute(
            "SELECT skill_id FROM skills_catalog WHERE skill_id = ? LIMIT 1",
            (skill_id,),
        ).fetchone()
        if not skill_row:
            raise CLIError("Skill not found", code="not_found")
        installation = _upsert_installation(
            conn,
            skill_id=skill_id,
            scope_key=scope,
            is_enabled=is_enabled,
            config=config,
        )
    return {"installation": installation}


def uninstall(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    skill_id = str(params.get("skill_id") or "").strip()
    if not skill_id:
        raise CLIError("skill_id required", code="missing_required")

    source_type = ""
    skill_dir = ""
    with connect(ctx.db_path, write=True) as conn:
        row = conn.execute(
            "SELECT source_type, skill_dir FROM skills_catalog WHERE skill_id = ? LIMIT 1",
            (skill_id,),
        ).fetchone()
        if row is None:
            cur = conn.execute(
                "DELETE FROM skill_installations WHERE skill_id = ?",
                (skill_id,),
            )
            if not cur.rowcount:
                raise CLIError("Skill not found", code="not_found")
            return {"ok": True, "deleted_files": False}

        source_type = str(row["source_type"] or "").strip().lower()
        skill_dir = str(row["skill_dir"] or "").strip()
        conn.execute("DELETE FROM skill_installations WHERE skill_id = ?", (skill_id,))
        cur = conn.execute("DELETE FROM skills_catalog WHERE skill_id = ?", (skill_id,))
        if not cur.rowcount:
            raise CLIError("Skill not found", code="not_found")

    deleted_files = False
    if source_type == "imported":
        deleted_files = _remove_imported_skill_dir(ctx, skill_dir)
    return {"ok": True, "deleted_files": deleted_files}


def update_installation(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    installation_id = str(params.get("installation_id") or "").strip()
    if not installation_id:
        raise CLIError("installation_id required", code="missing_required")

    has_is_enabled = "is_enabled" in params
    has_config = "config" in params
    if not has_is_enabled and not has_config:
        raise CLIError("Nothing to update", code="invalid_arguments")

    is_enabled = params.get("is_enabled", None) if has_is_enabled else None
    if has_is_enabled and not isinstance(is_enabled, bool):
        raise CLIError("is_enabled must be boolean", code="invalid_arguments")

    config = params.get("config", None) if has_config else None
    if has_config and not isinstance(config, dict):
        raise CLIError("config must be an object", code="invalid_arguments")

    with connect(ctx.db_path, write=True) as conn:
        row = conn.execute(
            """
            SELECT i.*,
                   c.name AS skill_name,
                   c.description AS skill_description,
                   c.enabled AS skill_enabled
            FROM skill_installations i
            JOIN skills_catalog c ON c.skill_id = i.skill_id
            WHERE i.installation_id = ?
            LIMIT 1
            """,
            (installation_id,),
        ).fetchone()
        if not row:
            raise CLIError("installation not found", code="not_found")

        next_enabled = bool(int(row["is_enabled"] or 0)) if is_enabled is None else bool(is_enabled)
        next_config = loads_json(row["config_json"], {}) if config is None else dict(config)
        conn.execute(
            """
            UPDATE skill_installations
            SET is_enabled = ?, config_json = ?, updated_at = ?
            WHERE installation_id = ?
            """,
            (
                int(next_enabled),
                json.dumps(next_config, ensure_ascii=False),
                time.time(),
                installation_id,
            ),
        )
        updated_row = conn.execute(
            """
            SELECT i.*,
                   c.name AS skill_name,
                   c.description AS skill_description,
                   c.enabled AS skill_enabled
            FROM skill_installations i
            JOIN skills_catalog c ON c.skill_id = i.skill_id
            WHERE i.installation_id = ?
            LIMIT 1
            """,
            (installation_id,),
        ).fetchone()
    if not updated_row:
        raise CLIError("installation not found", code="not_found")
    return {"installation": _row_to_installation(updated_row)}


def validate_required(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    required_skills = params.get("required_skills", [])
    if not isinstance(required_skills, list):
        raise CLIError("required_skills must be a list", code="invalid_arguments")

    agent_id = str(params.get("agent_id", "") or "").strip() or None
    normalized_required: list[str] = []
    seen_required: set[str] = set()
    for item in required_skills:
        skill_id = str(item or "").strip()
        if not skill_id or skill_id in seen_required:
            continue
        seen_required.add(skill_id)
        normalized_required.append(skill_id)
    if not normalized_required:
        return {"ready": True, "items": [], "blocking_count": 0}

    with connect(ctx.db_path) as conn:
        installations = _list_installations(conn, agent_id=agent_id)
        installed_by_skill_id = {str(row.get("skill_id", "")): row for row in installations}
        items: list[dict[str, Any]] = []
        blocking_count = 0
        for skill_id in normalized_required:
            catalog_row = conn.execute(
                "SELECT * FROM skills_catalog WHERE skill_id = ? LIMIT 1",
                (skill_id,),
            ).fetchone()
            if not catalog_row:
                blocking_count += 1
                items.append(
                    {
                        "skill_id": skill_id,
                        "status": "missing",
                        "reason": "Skill not found in local catalog",
                        "auto_fixable": False,
                    }
                )
                continue

            catalog = _row_to_catalog(catalog_row)
            installation = installed_by_skill_id.get(skill_id)
            if installation is None:
                blocking_count += 1
                items.append(
                    {
                        "skill_id": skill_id,
                        "skill_name": catalog.get("name", ""),
                        "status": "missing_installation",
                        "reason": "Skill is not installed",
                        "auto_fixable": True,
                    }
                )
                continue

            if not bool(catalog.get("enabled", True)):
                blocking_count += 1
                items.append(
                    {
                        "skill_id": skill_id,
                        "skill_name": catalog.get("name", ""),
                        "status": "disabled",
                        "reason": "Skill is disabled in catalog",
                        "auto_fixable": False,
                    }
                )
                continue

            if not bool(installation.get("is_enabled", False)):
                blocking_count += 1
                items.append(
                    {
                        "skill_id": skill_id,
                        "skill_name": installation.get("skill_name", catalog.get("name", "")),
                        "status": "disabled",
                        "reason": "Skill installation is disabled",
                        "auto_fixable": True,
                    }
                )
                continue

            items.append(
                {
                    "skill_id": skill_id,
                    "skill_name": installation.get("skill_name", catalog.get("name", "")),
                    "status": "ready",
                    "reason": "",
                    "auto_fixable": False,
                }
            )

    return {
        "ready": blocking_count == 0,
        "items": items,
        "blocking_count": blocking_count,
    }


def list_installed(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    agent_id = str(params.get("agent_id", "") or "").strip() or None
    with connect(ctx.db_path) as conn:
        result = _list_installations(conn, agent_id=agent_id)
    return {"installations": result}


def bind_agent(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    skill_id = str(params.get("skill_id") or "").strip()
    if not skill_id:
        raise CLIError("skill_id required", code="missing_required")
    agent_id = str(params.get("agent_id", "default") or "default").strip() or "default"
    ensure_installed = bool(params.get("ensure_installed", True))
    set_default_agent = bool(params.get("set_default_agent", False))
    reset_session = bool(params.get("reset_session", False))

    with connect(ctx.db_path, write=True) as conn:
        skill_row = conn.execute(
            "SELECT * FROM skills_catalog WHERE skill_id = ? LIMIT 1",
            (skill_id,),
        ).fetchone()
        if not skill_row:
            raise CLIError("Skill not found", code="not_found")
        skill = _row_to_catalog(skill_row)

        installation: dict[str, Any] | None = None
        if ensure_installed:
            installation = _upsert_installation(
                conn,
                skill_id=skill_id,
                scope_key=GLOBAL_SCOPE_KEY,
                is_enabled=True,
                config={},
            )

        agent_row = conn.execute(
            "SELECT * FROM agent_profiles WHERE agent_id = ? LIMIT 1",
            (agent_id,),
        ).fetchone()
        if not agent_row:
            raise CLIError(f"Agent not found: {agent_id}", code="not_found")

        skills = _normalize_skill_id_list(loads_json(agent_row["skills_json"], []))
        added = skill_id not in skills
        if added:
            skills.append(skill_id)
            conn.execute(
                """
                UPDATE agent_profiles
                SET skills_json = ?, updated_at = ?
                WHERE agent_id = ?
                """,
                (json.dumps(skills, ensure_ascii=False), time.time(), agent_id),
            )
            agent_row = conn.execute(
                "SELECT * FROM agent_profiles WHERE agent_id = ? LIMIT 1",
                (agent_id,),
            ).fetchone()
            if not agent_row:
                raise CLIError("Agent update failed", code="update_failed")

        chat_state: dict[str, Any] | None = None
        if set_default_agent or reset_session:
            cfg = read_config_json(conn)
            chat_cfg = cfg.get("chat", {})
            if not isinstance(chat_cfg, dict):
                chat_cfg = {}
            if set_default_agent:
                chat_cfg["default_agent_id"] = agent_id
            if reset_session:
                # DB mode can only clear main session pointer.
                chat_cfg["main_session_id"] = ""
            cfg["chat"] = chat_cfg
            upsert_config_json(conn, cfg)
            chat_state = {
                "ok": True,
                "mode": "chat",
                "default_agent_id": str(chat_cfg.get("default_agent_id") or "default"),
                "session_id": str(chat_cfg.get("main_session_id") or ""),
            }

    return {
        "skill": skill,
        "installation": installation,
        "agent": _row_to_agent(agent_row),
        "added": added,
        "chat_state": chat_state,
    }


def import_package(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    raise CLIError(
        "skill import requires runtime API; use --mode api with running v-claw",
        code="runtime_required",
    )


def import_and_bind(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del ctx, params
    raise CLIError(
        "skill import-and-bind requires runtime API; use --mode api with running v-claw",
        code="runtime_required",
    )


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "list_catalog": list_catalog,
        "list_installed": list_installed,
        "get_detail": get_detail,
        "install": install,
        "uninstall": uninstall,
        "update_installation": update_installation,
        "validate_required": validate_required,
        "bind_agent": bind_agent,
        "import_package": import_package,
        "import_and_bind": import_and_bind,
    }
    handler = handlers.get(method)
    if not handler:
        raise CLIError(f"Unknown skill method: {method}", code="unknown_method")
    return handler(ctx, params)


def _invoke_skill(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    return invoke(
        method=f"skill.{method}",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch(method, params, ctx),
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "skill",
        help="Manage skill catalog, installation state, and agent bindings",
        description=(
            "Manage skill lifecycle in local v-claw data.\n"
            "Recommended flow: import -> install/bind -> validate -> enable/disable -> uninstall."
        ),
        epilog=(
            "Examples:\n"
            "  vclawctl skill list\n"
            "  vclawctl skill install --skill-id <id>\n"
            "  vclawctl skill validate --skill-id <id>\n"
            "  vclawctl skill uninstall --skill-id <id> --yes"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    skill_sub = parser.add_subparsers(dest="skill_cmd", required=True)

    list_parser = skill_sub.add_parser("list", help="List local skill catalog")
    list_parser.add_argument(
        "--enabled-only",
        action="store_true",
        help="Only list enabled skills",
    )
    list_parser.set_defaults(func=_cmd_list)

    installed_parser = skill_sub.add_parser("installed", help="List installed skills")
    installed_parser.add_argument(
        "--agent-id",
        default="",
        help="Resolve installations for one agent (merges global + override)",
    )
    installed_parser.set_defaults(func=_cmd_installed)

    get_parser = skill_sub.add_parser("get", help="Get one skill detail from catalog")
    get_parser.add_argument("--skill-id", required=True, help="Skill ID to look up")
    get_parser.set_defaults(func=_cmd_get)

    install_parser = skill_sub.add_parser("install", help="Install skill into global/agent scope")
    install_parser.add_argument("--skill-id", required=True, help="Skill ID to install")
    install_parser.add_argument(
        "--agent-id",
        default="",
        help="Install for one agent scope; omit for global",
    )
    install_parser.add_argument(
        "--disabled",
        action="store_true",
        help="Create installation as disabled",
    )
    install_parser.add_argument(
        "--config-json",
        default="{}",
        help="Installation config JSON object",
    )
    install_parser.set_defaults(func=_cmd_install)

    uninstall_parser = skill_sub.add_parser(
        "uninstall",
        help="Uninstall skill by deleting local catalog/installations/files",
    )
    uninstall_parser.add_argument("--skill-id", required=True, help="Skill ID to uninstall")
    uninstall_parser.add_argument(
        "--yes",
        action="store_true",
        help="Confirm destructive removal",
    )
    uninstall_parser.set_defaults(func=_cmd_uninstall)

    enable_parser = skill_sub.add_parser(
        "enable",
        help="Enable one installed skill in global/agent scope",
    )
    enable_parser.add_argument("--skill-id", required=True, help="Skill ID to enable")
    enable_parser.add_argument(
        "--agent-id",
        default="",
        help="Target one agent scope; omit for global",
    )
    enable_parser.set_defaults(func=_cmd_enable)

    disable_parser = skill_sub.add_parser(
        "disable",
        help="Disable one installed skill in global/agent scope",
    )
    disable_parser.add_argument("--skill-id", required=True, help="Skill ID to disable")
    disable_parser.add_argument(
        "--agent-id",
        default="",
        help="Target one agent scope; omit for global",
    )
    disable_parser.set_defaults(func=_cmd_disable)

    validate_parser = skill_sub.add_parser(
        "validate",
        help="Validate required skills readiness for one agent scope",
    )
    validate_parser.add_argument(
        "--skill-id",
        dest="skill_ids",
        action="append",
        required=True,
        help="Required skill id (repeatable)",
    )
    validate_parser.add_argument(
        "--agent-id",
        default="",
        help="Validate against one agent scope; omit for global",
    )
    validate_parser.set_defaults(func=_cmd_validate)

    import_parser = skill_sub.add_parser(
        "import",
        help="Import .zip/.skill package (runtime API required)",
    )
    import_parser.add_argument("--file-path", required=True, help="Path to .zip or .skill package")
    import_parser.add_argument(
        "--validation-mode",
        choices=VALIDATION_MODE_CHOICES,
        default="strict",
        help="Skill validation strictness (default: strict)",
    )
    import_parser.add_argument(
        "--no-install-globally",
        action="store_true",
        help="Import into catalog only, do not install globally",
    )
    import_parser.set_defaults(func=_cmd_import)

    bind_parser = skill_sub.add_parser("bind", help="Bind one skill to one agent profile")
    bind_parser.add_argument("--skill-id", required=True, help="Skill ID to bind")
    bind_parser.add_argument(
        "--agent-id", default="default", help="Target agent ID (default: default)"
    )
    bind_parser.add_argument(
        "--no-ensure-installed",
        action="store_true",
        help="Do not auto-install skill globally before binding",
    )
    bind_parser.add_argument(
        "--set-default-agent",
        action="store_true",
        help="Also set chat.default_agent_id to this agent",
    )
    bind_parser.add_argument(
        "--reset-session",
        action="store_true",
        help="Also reset chat main session",
    )
    bind_parser.set_defaults(func=_cmd_bind)

    update_inst_parser = skill_sub.add_parser(
        "update-installation",
        help="Update an existing skill installation (enable/disable, config)",
    )
    update_inst_parser.add_argument(
        "--installation-id", required=True, help="Installation ID to update"
    )
    update_inst_parser.add_argument(
        "--enabled",
        default=None,
        help="Set enabled state (true/false); omit to leave unchanged",
    )
    update_inst_parser.add_argument(
        "--config-json",
        default=None,
        help="New config JSON object; omit to leave unchanged",
    )
    update_inst_parser.set_defaults(func=_cmd_update_installation)

    import_bind_parser = skill_sub.add_parser(
        "import-bind",
        help="Import package then bind skill to agent (runtime API required)",
    )
    import_bind_parser.add_argument(
        "--file-path", required=True, help="Path to .zip or .skill package"
    )
    import_bind_parser.add_argument(
        "--validation-mode",
        choices=VALIDATION_MODE_CHOICES,
        default="strict",
        help="Skill validation strictness (default: strict)",
    )
    import_bind_parser.add_argument(
        "--agent-id", default="default", help="Target agent ID (default: default)"
    )
    import_bind_parser.add_argument(
        "--no-install-globally",
        action="store_true",
        help="Import into catalog only, do not install globally",
    )
    import_bind_parser.add_argument(
        "--bind-agent",
        dest="bind_agent",
        action="store_true",
        default=True,
    )
    import_bind_parser.add_argument(
        "--no-bind-agent",
        dest="bind_agent",
        action="store_false",
        help="Import only; do not bind to agent",
    )
    import_bind_parser.add_argument(
        "--set-default-agent",
        dest="set_default_agent",
        action="store_true",
        default=True,
        help="Set chat.default_agent_id to target agent (default: true)",
    )
    import_bind_parser.add_argument(
        "--no-set-default-agent",
        dest="set_default_agent",
        action="store_false",
        help="Do not change chat.default_agent_id",
    )
    import_bind_parser.add_argument(
        "--reset-session",
        dest="reset_session",
        action="store_true",
        default=True,
        help="Force-create a new chat main session to load new skill (default: true)",
    )
    import_bind_parser.add_argument(
        "--no-reset-session",
        dest="reset_session",
        action="store_false",
        help="Do not reset chat session",
    )
    import_bind_parser.add_argument(
        "--no-ensure-installed",
        action="store_true",
        help="Do not auto-install skill globally before binding",
    )
    import_bind_parser.set_defaults(func=_cmd_import_bind)


def _cmd_list(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"include_disabled": not bool(args.enabled_only)}
    return _invoke_skill("list_catalog", params, ctx)


def _cmd_installed(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"agent_id": str(args.agent_id or "").strip()}
    return _invoke_skill("list_installed", params, ctx)


def _cmd_get(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"skill_id": str(args.skill_id or "").strip()}
    return _invoke_skill("get_detail", params, ctx)


def _cmd_install(args: Any, ctx: CLIContext) -> dict[str, Any]:
    config = parse_json_object(args.config_json, field_name="config_json")
    params = {
        "skill_id": str(args.skill_id or "").strip(),
        "agent_id": str(args.agent_id or "").strip(),
        "is_enabled": not bool(args.disabled),
        "config": config,
    }
    return _invoke_skill("install", params, ctx)


def _cmd_uninstall(args: Any, ctx: CLIContext) -> dict[str, Any]:
    if not bool(args.yes):
        raise CLIError("uninstall requires --yes", code="confirmation_required")
    params = {"skill_id": str(args.skill_id or "").strip()}
    return _invoke_skill("uninstall", params, ctx)


def _cmd_update_installation(args: Any, ctx: CLIContext) -> dict[str, Any]:
    installation_id = str(args.installation_id or "").strip()
    if not installation_id:
        raise CLIError("installation_id required", code="missing_required")

    params: dict[str, Any] = {"installation_id": installation_id}
    if args.enabled is not None:
        params["is_enabled"] = parse_bool(args.enabled, default=True)
    if args.config_json is not None:
        params["config"] = parse_json_object(args.config_json, field_name="config_json")
    if "is_enabled" not in params and "config" not in params:
        raise CLIError(
            "at least --enabled or --config-json required",
            code="missing_required",
        )
    return _invoke_skill("update_installation", params, ctx)


def _set_installation_enabled(
    *,
    skill_id: str,
    agent_id: str,
    is_enabled: bool,
    ctx: CLIContext,
) -> dict[str, Any]:
    installed = _invoke_skill("list_installed", {"agent_id": agent_id}, ctx)
    installations = installed.get("installations", [])
    if not isinstance(installations, list):
        installations = []

    target: dict[str, Any] | None = None
    for item in installations:
        if not isinstance(item, dict):
            continue
        if str(item.get("skill_id", "")).strip() == skill_id:
            target = item
            break
    if target is None:
        raise CLIError("Skill is not installed", code="not_installed")

    agent_scope = str(agent_id or "").strip()
    if agent_scope and not bool(target.get("has_agent_override", False)):
        # Keep global state unchanged; create agent override when targeting one agent.
        return _invoke_skill(
            "install",
            {
                "skill_id": skill_id,
                "agent_id": agent_scope,
                "is_enabled": bool(is_enabled),
                "config": {},
            },
            ctx,
        )

    installation_id = str(target.get("installation_id", "")).strip()
    if not installation_id:
        raise CLIError("installation_id missing", code="invalid_state")

    return _invoke_skill(
        "update_installation",
        {"installation_id": installation_id, "is_enabled": bool(is_enabled)},
        ctx,
    )


def _cmd_enable(args: Any, ctx: CLIContext) -> dict[str, Any]:
    skill_id = str(args.skill_id or "").strip()
    agent_id = str(args.agent_id or "").strip()
    return _set_installation_enabled(
        skill_id=skill_id,
        agent_id=agent_id,
        is_enabled=True,
        ctx=ctx,
    )


def _cmd_disable(args: Any, ctx: CLIContext) -> dict[str, Any]:
    skill_id = str(args.skill_id or "").strip()
    agent_id = str(args.agent_id or "").strip()
    return _set_installation_enabled(
        skill_id=skill_id,
        agent_id=agent_id,
        is_enabled=False,
        ctx=ctx,
    )


def _cmd_validate(args: Any, ctx: CLIContext) -> dict[str, Any]:
    raw_skill_ids = args.skill_ids if isinstance(args.skill_ids, list) else []
    skill_ids = [str(item or "").strip() for item in raw_skill_ids if str(item or "").strip()]
    if not skill_ids:
        raise CLIError("at least one --skill-id is required", code="missing_required")

    params = {
        "required_skills": skill_ids,
        "agent_id": str(args.agent_id or "").strip(),
    }
    return _invoke_skill("validate_required", params, ctx)


def _cmd_import(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "file_path": str(args.file_path or "").strip(),
        "install_globally": not bool(args.no_install_globally),
        "validation_mode": str(args.validation_mode or "strict").strip().lower() or "strict",
    }
    return _invoke_skill("import_package", params, ctx)


def _cmd_bind(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "skill_id": str(args.skill_id or "").strip(),
        "agent_id": str(args.agent_id or "default").strip() or "default",
        "ensure_installed": not bool(args.no_ensure_installed),
        "set_default_agent": bool(args.set_default_agent),
        "reset_session": bool(args.reset_session),
    }
    return _invoke_skill("bind_agent", params, ctx)


def _cmd_import_bind(args: Any, ctx: CLIContext) -> dict[str, Any]:
    bind_agent = bool(args.bind_agent)
    set_default_agent = bool(args.set_default_agent) if bind_agent else False
    reset_session = bool(args.reset_session) if bind_agent else False
    params = {
        "file_path": str(args.file_path or "").strip(),
        "agent_id": str(args.agent_id or "default").strip() or "default",
        "install_globally": not bool(args.no_install_globally),
        "validation_mode": str(args.validation_mode or "strict").strip().lower() or "strict",
        "bind_agent": bind_agent,
        "ensure_installed": not bool(args.no_ensure_installed),
        "set_default_agent": set_default_agent,
        "reset_session": reset_session,
    }
    return _invoke_skill("import_and_bind", params, ctx)
