"""Agent context runtime command handlers."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError

_FILENAME_TO_TARGET = {
    "USER.MD": "user",
    "AGENTS.MD": "agents",
    "SOUL.MD": "soul",
    "MEMORY.MD": "memory_main",
}

__all__ = ["register", "dispatch"]


def _runtime_only_local_fallback() -> dict[str, Any]:
    raise CLIError(
        (
            "agent-context command requires runtime API; use --mode api/auto "
            "with a running v-claw instance"
        ),
        code="runtime_api_required",
    )


def _normalize_target(raw: Any) -> str:
    target = str(raw or "").strip()
    if not target:
        return ""
    return _FILENAME_TO_TARGET.get(target.upper(), target.lower())


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    method_name = str(method or "").strip()
    if not method_name:
        raise CLIError("agent_context method required", code="missing_required")
    return invoke(
        method=f"agent_context.{method_name}",
        params=params,
        ctx=ctx,
        local_call=_runtime_only_local_fallback,
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "agent-context",
        help="Inspect and edit agent context files",
        description=(
            "Inspect and edit agent context files (USER.md, AGENTS.md, SOUL.md, MEMORY.md).\n"
            "These files form the agent's system prompt. --target accepts both key (user)\n"
            "and filename (USER.md)."
        ),
        epilog=(
            "Examples:\n"
            "  vclawctl agent-context status --agent-id default\n"
            "  vclawctl agent-context read --agent-id default --target user\n"
            "  vclawctl agent-context read --agent-id default --target SOUL.md\n"
            "  vclawctl agent-context write --agent-id default --target user --file ./USER.md"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    context_sub = parser.add_subparsers(dest="agent_context_cmd", required=True)

    status_parser = context_sub.add_parser("status", help="Get agent context file status")
    status_parser.add_argument("--agent-id", required=True, help="Agent profile ID")
    status_parser.set_defaults(func=_cmd_status)

    bundle_parser = context_sub.add_parser("bundle", help="Get stable agent context bundle")
    bundle_parser.add_argument("--agent-id", required=True, help="Agent profile ID")
    bundle_parser.set_defaults(func=_cmd_bundle)

    read_parser = context_sub.add_parser("read", help="Read one agent context file")
    read_parser.add_argument("--agent-id", required=True, help="Agent profile ID")
    read_parser.add_argument(
        "--target",
        required=True,
        help=(
            "Context target: user, agents, soul, memory_main"
            " (or USER.md, AGENTS.md, SOUL.md, MEMORY.md)"
        ),
    )
    read_parser.set_defaults(func=_cmd_read)

    write_parser = context_sub.add_parser("write", help="Write one agent context file")
    write_parser.add_argument("--agent-id", required=True, help="Agent profile ID")
    write_parser.add_argument(
        "--target",
        required=True,
        help=(
            "Context target: user, agents, soul, memory_main"
            " (or USER.md, AGENTS.md, SOUL.md, MEMORY.md)"
        ),
    )
    write_parser.add_argument("--content", default="", help="Content text to write")
    write_parser.add_argument(
        "--file", default="", help="Read content from local file path instead of --content"
    )
    write_parser.set_defaults(func=_cmd_write)


def _cmd_status(args: Any, ctx: CLIContext) -> dict[str, Any]:
    agent_id = str(args.agent_id or "").strip()
    if not agent_id:
        raise CLIError("agent_id required", code="missing_required")
    params = {"agent_id": agent_id}
    return dispatch("get_status", params, ctx)


def _cmd_bundle(args: Any, ctx: CLIContext) -> dict[str, Any]:
    agent_id = str(args.agent_id or "").strip()
    if not agent_id:
        raise CLIError("agent_id required", code="missing_required")
    params = {"agent_id": agent_id}
    return dispatch("get_bundle", params, ctx)


def _cmd_read(args: Any, ctx: CLIContext) -> dict[str, Any]:
    agent_id = str(args.agent_id or "").strip()
    target = _normalize_target(args.target)
    if not agent_id:
        raise CLIError("agent_id required", code="missing_required")
    if not target:
        raise CLIError("target required", code="missing_required")
    return dispatch("read", {"agent_id": agent_id, "target": target}, ctx)


def _cmd_write(args: Any, ctx: CLIContext) -> dict[str, Any]:
    agent_id = str(args.agent_id or "").strip()
    target = _normalize_target(args.target)
    if not agent_id:
        raise CLIError("agent_id required", code="missing_required")
    if not target:
        raise CLIError("target required", code="missing_required")

    file_path = str(args.file or "").strip()
    content = str(args.content or "")
    if file_path:
        try:
            content = Path(file_path).read_text(encoding="utf-8")
        except OSError as exc:
            raise CLIError(
                f"failed to read file: {exc}",
                code="file_read_error",
            ) from exc
    elif not content:
        raise CLIError("--content or --file required", code="missing_required")

    return dispatch(
        "write",
        {
            "agent_id": agent_id,
            "target": target,
            "content": content,
        },
        ctx,
    )
