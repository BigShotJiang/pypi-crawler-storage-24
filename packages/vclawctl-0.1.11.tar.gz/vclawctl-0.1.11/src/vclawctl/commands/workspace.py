"""Workspace runtime command handlers."""

from __future__ import annotations

import argparse
from typing import Any

from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError

__all__ = ["register", "dispatch"]


def _runtime_only_local_fallback() -> dict[str, Any]:
    raise CLIError(
        (
            "workspace command requires runtime API; use --mode api/auto "
            "with a running v-claw instance"
        ),
        code="runtime_api_required",
    )


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    method_name = str(method or "").strip()
    if not method_name:
        raise CLIError("workspace method required", code="missing_required")
    return invoke(
        method=f"workspace.{method_name}",
        params=params,
        ctx=ctx,
        local_call=_runtime_only_local_fallback,
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "workspace",
        help="Inspect workspace runtime state",
        epilog=(
            "Examples:\n"
            "  vclawctl workspace state\n"
            "  vclawctl workspace list\n"
            "  vclawctl workspace preview --relative-path README.md"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    workspace_sub = parser.add_subparsers(dest="workspace_cmd", required=True)

    state_parser = workspace_sub.add_parser("state", help="Get workspace state")
    state_parser.add_argument(
        "--workspace-path", default="", help="Workspace root path; uses session default if omitted"
    )
    state_parser.set_defaults(func=_cmd_state)

    list_parser = workspace_sub.add_parser("list", help="List workspace entries")
    list_parser.add_argument(
        "--workspace-path", default="", help="Workspace root path; uses session default if omitted"
    )
    list_parser.add_argument(
        "--relative-path", default="", help="Subdirectory to list; root if omitted"
    )
    list_parser.add_argument(
        "--include-hidden", action="store_true", help="Include hidden files/directories"
    )
    list_parser.set_defaults(func=_cmd_list)

    preview_parser = workspace_sub.add_parser("preview", help="Preview one workspace file")
    preview_parser.add_argument(
        "--relative-path", required=True, help="File path relative to workspace root"
    )
    preview_parser.add_argument(
        "--workspace-path", default="", help="Workspace root path; uses session default if omitted"
    )
    preview_parser.add_argument(
        "--max-chars", type=int, default=0, help="Max characters to return (0=unlimited)"
    )
    preview_parser.set_defaults(func=_cmd_preview)

    open_parser = workspace_sub.add_parser(
        "open",
        help="Open workspace path in file manager (may not work in headless environments)",
    )
    open_parser.add_argument(
        "--workspace-path", default="", help="Workspace root path; uses session default if omitted"
    )
    open_parser.add_argument(
        "--relative-path", default="", help="Path to open; workspace root if omitted"
    )
    open_parser.set_defaults(func=_cmd_open)


def _cmd_state(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params: dict[str, Any] = {}
    workspace_path = str(args.workspace_path or "").strip()
    if workspace_path:
        params["workspace_path"] = workspace_path
    return dispatch("state", params, ctx)


def _cmd_list(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params: dict[str, Any] = {"include_hidden": bool(args.include_hidden)}
    workspace_path = str(args.workspace_path or "").strip()
    relative_path = str(args.relative_path or "").strip()
    if workspace_path:
        params["workspace_path"] = workspace_path
    if relative_path:
        params["relative_path"] = relative_path
    return dispatch("list", params, ctx)


def _cmd_preview(args: Any, ctx: CLIContext) -> dict[str, Any]:
    relative_path = str(args.relative_path or "").strip()
    if not relative_path:
        raise CLIError("relative_path required", code="missing_required")
    params: dict[str, Any] = {"relative_path": relative_path}
    workspace_path = str(args.workspace_path or "").strip()
    if workspace_path:
        params["workspace_path"] = workspace_path
    if int(args.max_chars or 0) > 0:
        params["max_chars"] = int(args.max_chars)
    return dispatch("preview", params, ctx)


def _cmd_open(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params: dict[str, Any] = {}
    workspace_path = str(args.workspace_path or "").strip()
    relative_path = str(args.relative_path or "").strip()
    if workspace_path:
        params["workspace_path"] = workspace_path
    if relative_path:
        params["relative_path"] = relative_path
    return dispatch("open_path", params, ctx)
