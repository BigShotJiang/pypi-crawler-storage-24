"""Structured preference command handlers."""

from __future__ import annotations

import argparse
import json
import re
import time
from pathlib import Path
from typing import Any

from vclawctl.adapters.sqlite.db import connect, loads_json
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import parse_bool
from vclawctl.errors import CLIError

_QUIET_HOURS_PATTERN = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
_QUIET_HOURS_START_MARKER = "<!-- v-claw:quiet-hours:start -->"
_QUIET_HOURS_END_MARKER = "<!-- v-claw:quiet-hours:end -->"
_DEFAULT_USER_MD = "# USER.md\n\n## 用户画像\n\n"
_DEFAULT_SCOPE = "default"
_DEFAULT_TIMEZONE = "Asia/Shanghai"


def _normalize_agent_id(raw_agent_id: Any, *, default: str = "default") -> str:
    return str(raw_agent_id or default).strip() or default


def _normalize_hhmm(value: Any, *, field_name: str) -> str:
    normalized = str(value or "").strip()
    match = _QUIET_HOURS_PATTERN.fullmatch(normalized)
    if not match:
        raise CLIError(f"{field_name} must be HH:MM", code="invalid_time")
    return f"{int(match.group(1)):02d}:{match.group(2)}"


def _ensure_preferences_table(conn: Any) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS agent_user_preferences (
            agent_id TEXT NOT NULL,
            user_scope_key TEXT NOT NULL DEFAULT 'default',
            timezone TEXT NOT NULL DEFAULT 'Asia/Shanghai',
            quiet_hours_start TEXT NOT NULL DEFAULT '',
            quiet_hours_end TEXT NOT NULL DEFAULT '',
            allow_proactive_message INTEGER NOT NULL DEFAULT 1,
            interruption_policy TEXT NOT NULL DEFAULT 'normal',
            metadata_json TEXT NOT NULL DEFAULT '{}',
            updated_at REAL NOT NULL,
            PRIMARY KEY(agent_id, user_scope_key)
        )
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_agent_user_preferences_updated
        ON agent_user_preferences(updated_at DESC)
        """
    )


def _user_md_path(ctx: CLIContext, *, agent_id: str) -> Path:
    return ctx.data_dir / "agent_contexts" / agent_id / "USER.md"


def _ensure_user_md(ctx: CLIContext, *, agent_id: str) -> Path:
    user_md = _user_md_path(ctx, agent_id=agent_id)
    user_md.parent.mkdir(parents=True, exist_ok=True)
    if not user_md.exists():
        user_md.write_text(_DEFAULT_USER_MD, encoding="utf-8")
    return user_md


def _build_quiet_hours_block(payload: dict[str, Any]) -> str:
    block_lines = [
        _QUIET_HOURS_START_MARKER,
        "## 机器同步偏好",
        "",
        (
            f"- 安静时段：{payload['quiet_hours_start']} - {payload['quiet_hours_end']} "
            f"（{payload['timezone']}）"
        ),
        _QUIET_HOURS_END_MARKER,
    ]
    return "\n".join(block_lines)


def _sync_quiet_hours_block_to_user_md(ctx: CLIContext, payload: dict[str, Any]) -> None:
    user_md = _ensure_user_md(ctx, agent_id=str(payload["agent_id"]))
    content = user_md.read_text(encoding="utf-8")
    block = _build_quiet_hours_block(payload)
    pattern = re.compile(
        re.escape(_QUIET_HOURS_START_MARKER) + r".*?" + re.escape(_QUIET_HOURS_END_MARKER),
        re.DOTALL,
    )
    if pattern.search(content):
        updated = pattern.sub(block, content, count=1).rstrip() + "\n"
    else:
        base = content.rstrip()
        updated = f"{base}\n\n{block}\n" if base else f"{block}\n"
    user_md.write_text(updated, encoding="utf-8")


def _remove_quiet_hours_block_from_user_md(ctx: CLIContext, *, agent_id: str) -> None:
    user_md = _ensure_user_md(ctx, agent_id=agent_id)
    content = user_md.read_text(encoding="utf-8")
    pattern = re.compile(
        re.escape(_QUIET_HOURS_START_MARKER) + r".*?" + re.escape(_QUIET_HOURS_END_MARKER),
        re.DOTALL,
    )
    updated = pattern.sub("", content, count=1)
    updated = re.sub(r"\n{3,}", "\n\n", updated).strip() + "\n"
    user_md.write_text(updated, encoding="utf-8")


def get_quiet_hours(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    agent_id = _normalize_agent_id(params.get("agent_id"))
    with connect(ctx.db_path, write=True) as conn:
        _ensure_preferences_table(conn)
        row = conn.execute(
            """
            SELECT *
            FROM agent_user_preferences
            WHERE agent_id = ? AND user_scope_key = ?
            LIMIT 1
            """,
            (agent_id, _DEFAULT_SCOPE),
        ).fetchone()
    if row is None:
        return {"quiet_hours": None}
    return {
        "quiet_hours": {
            "agent_id": str(row["agent_id"] or agent_id),
            "user_scope_key": str(row["user_scope_key"] or _DEFAULT_SCOPE),
            "timezone": str(row["timezone"] or _DEFAULT_TIMEZONE),
            "quiet_hours_start": str(row["quiet_hours_start"] or ""),
            "quiet_hours_end": str(row["quiet_hours_end"] or ""),
            "allow_proactive_message": bool(int(row["allow_proactive_message"] or 0)),
            "interruption_policy": str(row["interruption_policy"] or "normal"),
            "metadata": loads_json(row["metadata_json"], {}),
            "updated_at": float(row["updated_at"] or 0.0),
        }
    }


def set_quiet_hours(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    agent_id = _normalize_agent_id(params.get("agent_id"))
    start = _normalize_hhmm(params.get("start"), field_name="start")
    end = _normalize_hhmm(params.get("end"), field_name="end")
    timezone = str(params.get("timezone") or _DEFAULT_TIMEZONE).strip() or _DEFAULT_TIMEZONE
    allow_proactive = parse_bool(params.get("allow_proactive_message"), default=False)
    now = time.time()
    metadata_json = json.dumps({"managed_by": "quiet_hours_cli"}, ensure_ascii=False)
    with connect(ctx.db_path, write=True) as conn:
        _ensure_preferences_table(conn)
        conn.execute(
            """
            INSERT INTO agent_user_preferences(
                agent_id, user_scope_key, timezone,
                quiet_hours_start, quiet_hours_end,
                allow_proactive_message, interruption_policy,
                metadata_json, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(agent_id, user_scope_key) DO UPDATE SET
                timezone = excluded.timezone,
                quiet_hours_start = excluded.quiet_hours_start,
                quiet_hours_end = excluded.quiet_hours_end,
                allow_proactive_message = excluded.allow_proactive_message,
                interruption_policy = excluded.interruption_policy,
                metadata_json = excluded.metadata_json,
                updated_at = excluded.updated_at
            """,
            (
                agent_id,
                _DEFAULT_SCOPE,
                timezone,
                start,
                end,
                int(bool(allow_proactive)),
                "quiet_hours",
                metadata_json,
                now,
            ),
        )
    payload = get_quiet_hours(ctx, {"agent_id": agent_id})
    quiet_hours = payload.get("quiet_hours")
    if not isinstance(quiet_hours, dict):
        raise CLIError("failed to load saved quiet hours", code="preference_save_failed")
    _sync_quiet_hours_block_to_user_md(ctx, quiet_hours)
    return {"quiet_hours": quiet_hours}


def clear_quiet_hours(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    agent_id = _normalize_agent_id(params.get("agent_id"))
    with connect(ctx.db_path, write=True) as conn:
        _ensure_preferences_table(conn)
        cur = conn.execute(
            "DELETE FROM agent_user_preferences WHERE agent_id = ? AND user_scope_key = ?",
            (agent_id, _DEFAULT_SCOPE),
        )
    _remove_quiet_hours_block_from_user_md(ctx, agent_id=agent_id)
    return {"cleared": bool(cur.rowcount)}


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "get_quiet_hours": get_quiet_hours,
        "set_quiet_hours": set_quiet_hours,
        "clear_quiet_hours": clear_quiet_hours,
    }
    handler = handlers.get(str(method or "").strip())
    if not handler:
        raise CLIError(f"Unknown preference method: {method}", code="unknown_method")
    return handler(ctx, params)


def _invoke_preference(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    return invoke(
        method=f"preference.{method}",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch(method, params, ctx),
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "preference",
        help="Manage structured agent preferences",
        epilog=(
            "Examples:\n"
            "  vclawctl preference quiet-hours get\n"
            "  vclawctl preference quiet-hours set --start 23:00 --end 07:00\n"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    preference_sub = parser.add_subparsers(dest="preference_cmd", required=True)

    quiet_hours_parser = preference_sub.add_parser("quiet-hours", help="Manage quiet hours")
    quiet_hours_sub = quiet_hours_parser.add_subparsers(
        dest="preference_quiet_hours_cmd",
        required=True,
    )

    get_parser = quiet_hours_sub.add_parser("get", help="Get quiet hours")
    get_parser.add_argument("--agent-id", default="default", help="Agent ID (default: default)")
    get_parser.set_defaults(func=_cmd_get_quiet_hours)

    set_parser = quiet_hours_sub.add_parser("set", help="Set quiet hours")
    set_parser.add_argument("--agent-id", default="default", help="Agent ID (default: default)")
    set_parser.add_argument("--start", required=True, help="Start time, e.g. 23:00")
    set_parser.add_argument("--end", required=True, help="End time, e.g. 07:00")
    set_parser.add_argument(
        "--timezone", default=_DEFAULT_TIMEZONE, help="Timezone (default: Asia/Shanghai)"
    )
    set_parser.add_argument(
        "--allow-proactive",
        default="false",
        help="Allow proactive messages during quiet hours (default: false)",
    )
    set_parser.set_defaults(func=_cmd_set_quiet_hours)

    clear_parser = quiet_hours_sub.add_parser("clear", help="Clear quiet hours")
    clear_parser.add_argument("--agent-id", default="default", help="Agent ID (default: default)")
    clear_parser.set_defaults(func=_cmd_clear_quiet_hours)


def _cmd_get_quiet_hours(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return _invoke_preference(
        "get_quiet_hours",
        {"agent_id": _normalize_agent_id(args.agent_id)},
        ctx,
    )


def _cmd_set_quiet_hours(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return _invoke_preference(
        "set_quiet_hours",
        {
            "agent_id": _normalize_agent_id(args.agent_id),
            "start": _normalize_hhmm(args.start, field_name="start"),
            "end": _normalize_hhmm(args.end, field_name="end"),
            "timezone": str(args.timezone or _DEFAULT_TIMEZONE).strip() or _DEFAULT_TIMEZONE,
            "allow_proactive_message": parse_bool(args.allow_proactive, default=False),
        },
        ctx,
    )


def _cmd_clear_quiet_hours(args: Any, ctx: CLIContext) -> dict[str, Any]:
    return _invoke_preference(
        "clear_quiet_hours",
        {"agent_id": _normalize_agent_id(args.agent_id)},
        ctx,
    )


__all__ = ["register", "dispatch"]
