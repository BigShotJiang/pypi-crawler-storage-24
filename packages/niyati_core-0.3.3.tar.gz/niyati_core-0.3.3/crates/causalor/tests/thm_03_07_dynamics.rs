mod common;
use causalor::*;
use common::create_test_graph;

// Helper to calculate V_G(t)
fn target_reachable_volume(
    engine: &reachability::core::ReachabilityEngine,
    state: &StateId,
    budget: f64,
    target: &StateId,
) -> usize {
    let reachable = engine.compute_reachable_set(state, budget);
    if reachable.is_reachable(target) {
        1
    } else {
        0
    }
}

// ============================================================================
// THEOREM 3 & 4: Reachable Volume & Irreversibility
// ============================================================================

#[test]
fn theorem_4_irreversibility_volume_decay() {
    let space = create_test_graph();
    let engine = reachability::core::ReachabilityEngine::new(space);
    let target = "C".into();

    // At Start (A), budget = 10.0
    // Paths to C: A -> B -> C (cost 8). So C is reachable.
    let v_g_t0 = target_reachable_volume(&engine, &"A".into(), 10.0, &target);
    assert_eq!(v_g_t0, 1);

    // Transition: A -> B (cost 5.0)
    // At B, budget = 10.0 - 5.0 = 5.0
    // Paths to C: B -> C (cost 3). So C is reachable.
    let v_g_t1 = target_reachable_volume(&engine, &"B".into(), 5.0, &target);
    assert_eq!(v_g_t1, 1);

    // Irreversibility: Options strictly shrink or stay flat
    assert!(v_g_t1 <= v_g_t0);
}

// ============================================================================
// THEOREM 5: Point of No Return (Disconnection Transition)
// ============================================================================

#[test]
fn theorem_5_point_of_no_return_and_theorem_6_persistence() {
    let space = create_test_graph();
    let engine = reachability::core::ReachabilityEngine::new(space);
    let target = "C".into();

    // State 1: A (Budget = 10)
    // C is reachable (Cost = 8)
    assert_eq!(
        target_reachable_volume(&engine, &"A".into(), 10.0, &target),
        1
    );

    // Decision: Take path A -> D (Cost = 10)
    // State 2: D (Budget = 0)
    // C is structurally unreachable
    assert_eq!(
        target_reachable_volume(&engine, &"D".into(), 0.0, &target),
        0
    );

    // The transition from A -> D is the Point of No Return (Theorem 5).
    // Volume collapsed from 1 -> 0 instantly.

    // Theorem 6 (Persistence of Irreversibility)
    // Once volume drops to 0, no valid downstream action can recover it.
    // Even if budget was somehow infinite from D (Testing structural disconnect):
    assert_eq!(
        target_reachable_volume(&engine, &"D".into(), 1000.0, &target),
        0
    );
}
