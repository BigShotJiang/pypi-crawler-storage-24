use causalor::geometry::{Polytope, Vector};

// ============================================================================
// THEOREM 14: Fragility & Unified Collapse Risk
// ============================================================================

#[test]
fn theorem_14_1_directional_thickness_tau_v() {
    let mut p = Polytope::new();
    // A 3D box: [0, 10] in all dimensions
    p.add_constraint(Vector(vec![1.0, 0.0, 0.0]), 10.0);
    p.add_constraint(Vector(vec![-1.0, 0.0, 0.0]), 0.0);
    p.add_constraint(Vector(vec![0.0, 1.0, 0.0]), 10.0);
    p.add_constraint(Vector(vec![0.0, -1.0, 0.0]), 0.0);
    p.add_constraint(Vector(vec![0.0, 0.0, 1.0]), 10.0);
    p.add_constraint(Vector(vec![0.0, 0.0, -1.0]), 0.0);

    // Deep interior
    let center = Vector(vec![5.0, 5.0, 5.0]);
    let transition_x = Vector(vec![1.0, 0.0, 0.0]);

    // Orthogonal margins (y and z constraints boundary margins = 5)
    let tau_v_center = p.estimate_directional_thickness(&center, &transition_x);
    assert_eq!(tau_v_center, 5.0, "Center is 5 units thick orthogonally");

    // Close to a side wall
    let wall = Vector(vec![5.0, 9.0, 5.0]);
    let tau_v_wall = p.estimate_directional_thickness(&wall, &transition_x);
    assert_eq!(
        tau_v_wall, 1.0,
        "Moving along X near the Y wall yields 1.0 thickness"
    );
}

#[test]
fn theorem_14_3_unified_collapse_risk() {
    let mut p = Polytope::new();
    // A narrow 2D corridor:
    // Forward path is perfectly open: x <= 1000
    // Sideways paths are strictly bound: y <= 1, -y <= -1 (y exactly equals 1)
    p.add_constraint(Vector(vec![1.0, 0.0]), 1000.0);
    p.add_constraint(Vector(vec![0.0, 1.0]), 1.0);
    p.add_constraint(Vector(vec![0.0, -1.0]), -1.0);

    // State is functionally trapped in a degenerate corridor
    let trapped_state = Vector(vec![50.0, 1.0]);

    // We attempt a safe, incremental forward transition
    let transition = Vector(vec![1.0, 0.0]);

    // Theorem 13 (Proximity $\delta$) -> Completely Safe! (distance to 1000 is massive)
    let proximity_risk = p.predict_kappa_spike(&trapped_state, &transition);
    assert!(
        proximity_risk < 0.1,
        "Proximity risk should appear overwhelmingly safe"
    );

    // Theorem 14 (Unified Risk -> proximity * amplification factor 1/tau_v)
    let total_risk = p.unified_collapse_risk(&trapped_state, &transition);

    // The corridor limits orthogonal deviations to precisely zero (Y is locked at 1.0)
    // The system collapses instantly upon noise.
    assert!(
        total_risk >= 1.0,
        "Corridor lacks thickness; system must trigger infinite collapse risk"
    );
}
