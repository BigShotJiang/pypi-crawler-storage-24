use causalor::dynamics::evolution::DynamicStateSpace;

// ============================================================================
// THEOREM 24: Temporal Consistency
// ============================================================================

/// Theorem 24.1 (Temporal Monotonicity Invariant):
/// Ω(t_{k+1}) ≤ Ω(t_k) for static systems. Any increase is a diagnostic signal.
#[test]
fn theorem_24_1_monotonicity_invariant_holds() {
    // A valid, monotonically decreasing Ω time series
    let omega_series = [100.0, 95.0, 80.0, 60.0, 40.0, 20.0, 5.0];

    // Verify monotonicity
    for i in 1..omega_series.len() {
        assert!(
            omega_series[i] <= omega_series[i - 1],
            "Monotonicity violated at step {}: {} > {}",
            i,
            omega_series[i],
            omega_series[i - 1]
        );
    }
}

/// Theorem 24.1 — Monotonicity violation detection:
/// When Ω increases, the system must flag it.
#[test]
fn theorem_24_1_monotonicity_breach_detected() {
    // Time series with a breach at step 3 (Ω increased)
    let omega_series = [100.0, 80.0, 60.0, 70.0, 50.0]; // 60 → 70 is a breach

    let mut breaches = Vec::new();
    for i in 1..omega_series.len() {
        if omega_series[i] > omega_series[i - 1] {
            breaches.push(i);
        }
    }

    assert_eq!(breaches.len(), 1, "Should detect exactly one breach");
    assert_eq!(breaches[0], 3, "Breach should be at step 3");
}

/// Theorem 24.2 (Collapse Rate Additivity Invariant):
/// Σ κ(t_k → t_{k+1}) = log Ω(t_0) - log Ω(t_n)
#[test]
fn theorem_24_2_kappa_additivity() {
    let omega_series: Vec<f64> = vec![100.0, 80.0, 50.0, 20.0, 5.0];

    // Compute κ at each step: κ = log(Ω_k) - log(Ω_{k+1})
    let kappa_series: Vec<f64> = omega_series
        .windows(2)
        .map(|w| {
            let (a, b) = (w[0], w[1]);
            a.ln() - b.ln()
        })
        .collect();

    let kappa_sum: f64 = kappa_series.iter().sum();
    let endpoint_diff: f64 = omega_series[0].ln() - omega_series[omega_series.len() - 1].ln();

    // T24.2: Additivity — sum of κ equals endpoint log-difference
    let residual = (kappa_sum - endpoint_diff).abs();
    assert!(
        residual < 1e-10,
        "κ additivity violated: sum = {:.6}, endpoint diff = {:.6}, residual = {:.2e}",
        kappa_sum,
        endpoint_diff,
        residual
    );
}

/// Theorem 24.2 — Additivity breach when a measurement is missing.
#[test]
fn theorem_24_2_missing_measurement_detected() {
    let omega_series: Vec<f64> = vec![100.0, 80.0, 50.0, 20.0, 5.0];

    // Correct κ values
    let kappa_correct: Vec<f64> = omega_series
        .windows(2)
        .map(|w| {
            let (a, b) = (w[0], w[1]);
            a.ln() - b.ln()
        })
        .collect();

    // Drop one measurement (simulate data loss)
    let kappa_incomplete: Vec<f64> = kappa_correct[..3].to_vec(); // missing last κ

    let incomplete_sum: f64 = kappa_incomplete.iter().sum();
    let endpoint_diff = omega_series[0].ln() - omega_series[omega_series.len() - 1].ln();

    let residual = (incomplete_sum - endpoint_diff).abs();
    assert!(
        residual > 0.1,
        "Missing measurement should cause additivity breach (residual = {:.4})",
        residual
    );
}

/// Theorem 24.3 (State Function Verification):
/// Total information loss depends only on endpoints, not path taken.
#[test]
fn theorem_24_3_state_function_path_independence() {
    // Two different paths from Ω = 100 to Ω = 10

    // Path A: gradual decay
    let path_a: Vec<f64> = vec![100.0, 80.0, 60.0, 40.0, 20.0, 10.0];
    let info_loss_a: f64 = path_a
        .windows(2)
        .map(|w| {
            let (a, b) = (w[0], w[1]);
            a.ln() - b.ln()
        })
        .sum();

    // Path B: sharp initial drop then plateau
    let path_b: Vec<f64> = vec![100.0, 30.0, 15.0, 12.0, 11.0, 10.0];
    let info_loss_b: f64 = path_b
        .windows(2)
        .map(|w| {
            let (a, b) = (w[0], w[1]);
            a.ln() - b.ln()
        })
        .sum();

    // T24.3: Both paths must give the same total information loss
    let expected = 100.0_f64.ln() - 10.0_f64.ln();
    assert!(
        (info_loss_a - expected).abs() < 1e-10,
        "Path A total ({:.6}) must match endpoint diff ({:.6})",
        info_loss_a,
        expected
    );
    assert!(
        (info_loss_b - expected).abs() < 1e-10,
        "Path B total ({:.6}) must match endpoint diff ({:.6})",
        info_loss_b,
        expected
    );
    assert!(
        (info_loss_a - info_loss_b).abs() < 1e-10,
        "Both paths must yield identical information loss"
    );
}

/// Theorem 23 + 24 Integration:
/// Discovery events interact correctly with temporal consistency.
#[test]
fn theorem_23_24_discovery_invalidates_monotonicity() {
    let mut dss = DynamicStateSpace::new(10, 15);

    // Mark target as collapsed at time 3
    dss.mark_collapsed("supplier_x".into(), 3);
    assert!(
        dss.persistence_valid(&"supplier_x".into()),
        "Persistence should be valid before discovery"
    );

    // Discovery at time 5: new supplier comes online
    dss.register_discovery(
        5,
        vec!["new_supplier".into()],
        vec![("new_supplier".into(), "warehouse".into(), 2.0)],
    );

    // T23.2 + T24.1: Discovery invalidates persistence AND monotonicity
    assert!(
        !dss.persistence_valid(&"supplier_x".into()),
        "Persistence must be invalidated after discovery"
    );

    // Regret should be positive
    let regret = dss.discovery_regret(0);
    assert!(regret > 0, "Discovery regret must be positive");
}
