use causalor::geometry::{Polytope, Vector};

// ============================================================================
// THEOREM 20: Survival Optimality Principle
// ============================================================================

/// Theorem 20 — Phase-Dependent Policy:
/// The optimal survival action depends on the system's phase.
/// In open regions: maximize forward optionality.
/// In corridors: minimize lateral exposure (stay centered).
#[test]
fn theorem_20_phase_dependent_policy() {
    // Open region: 3D box [0, 100]^3
    let mut open_region = Polytope::new();
    for d in 0..3 {
        let mut n_pos = vec![0.0; 3];
        n_pos[d] = 1.0;
        let mut n_neg = vec![0.0; 3];
        n_neg[d] = -1.0;
        open_region.add_constraint(Vector(n_pos), 100.0);
        open_region.add_constraint(Vector(n_neg), 0.0);
    }

    // Corridor: [0, 100] × [0, 2] × [0, 2]
    let mut corridor = Polytope::new();
    corridor.add_constraint(Vector(vec![1.0, 0.0, 0.0]), 100.0);
    corridor.add_constraint(Vector(vec![-1.0, 0.0, 0.0]), 0.0);
    corridor.add_constraint(Vector(vec![0.0, 1.0, 0.0]), 2.0);
    corridor.add_constraint(Vector(vec![0.0, -1.0, 0.0]), 0.0);
    corridor.add_constraint(Vector(vec![0.0, 0.0, 1.0]), 2.0);
    corridor.add_constraint(Vector(vec![0.0, 0.0, -1.0]), 0.0);

    let open_center = Vector(vec![50.0, 50.0, 50.0]);
    let corridor_center = Vector(vec![50.0, 1.0, 1.0]);

    let forward = Vector(vec![1.0, 0.0, 0.0]);

    // In open region: collapse risk is low everywhere
    let risk_open = open_region.unified_collapse_risk(&open_center, &forward);

    // In corridor: collapse risk is amplified (thin orthogonal margins)
    let risk_corridor = corridor.unified_collapse_risk(&corridor_center, &forward);

    // T20: Corridor demands fundamentally different policy (higher risk)
    assert!(
        risk_corridor > risk_open,
        "Corridor ({:.4}) must have higher collapse risk than open region ({:.6})",
        risk_corridor,
        risk_open
    );
}

/// Theorem 20 — Thickness-Preserving Control Law:
/// A survival-optimal trajectory stays in the center of the feasible set,
/// maximizing the minimum distance to any boundary.
#[test]
fn theorem_20_thickness_preservation() {
    let mut corridor = Polytope::new();
    // Corridor: [0, 100] × [0, 4]
    corridor.add_constraint(Vector(vec![1.0, 0.0]), 100.0);
    corridor.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    corridor.add_constraint(Vector(vec![0.0, 1.0]), 4.0);
    corridor.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    let forward = Vector(vec![1.0, 0.0]);

    // Center of corridor (y = 2): maximum thickness
    let center = Vector(vec![50.0, 2.0]);
    let tau_center = corridor.estimate_directional_thickness(&center, &forward);

    // Edge of corridor (y = 0.5): thin margins
    let edge = Vector(vec![50.0, 0.5]);
    let tau_edge = corridor.estimate_directional_thickness(&edge, &forward);

    // T20: Thickness-preserving control keeps us centered
    assert!(
        tau_center > tau_edge,
        "Center ({}) must have greater thickness than edge ({})",
        tau_center,
        tau_edge
    );
}

// ============================================================================
// THEOREM 20.5: Minimum Collapse Perturbation (Adversarial Dual)
// ============================================================================

/// Theorem 20.5.1 — Minimum Collapse Perturbation:
/// ε*(x) = min_{||Δ|| ≤ r} δ(x + Δ) where δ drops to zero.
/// The minimum perturbation to force collapse is at least τ*.
#[test]
fn theorem_20_5_minimum_collapse_perturbation() {
    let mut p = Polytope::new();
    // 2D box [0, 10] × [0, 6]
    p.add_constraint(Vector(vec![1.0, 0.0]), 10.0);
    p.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    p.add_constraint(Vector(vec![0.0, 1.0]), 6.0);
    p.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    // Interior point
    let x = Vector(vec![5.0, 3.0]);
    let delta = p.boundary_distance(&x); // minimum distance to any boundary

    // T20.5: ε*(x) = δ(x) — the minimum perturbation to escape feasibility
    // equals the boundary distance
    assert_eq!(delta, 3.0, "Boundary distance should be 3 (nearest y-wall)");

    // T20.5.2: ε* ≥ τ* always
    // Effective thickness of the polytope bounds ε* from below
    let v = Vector(vec![1.0, 0.0]);
    let tau_star = p.estimate_directional_thickness(&x, &v);
    assert!(delta >= 0.0, "Collapse perturbation must be non-negative");
    assert!(
        tau_star > 0.0,
        "Thickness must be positive for interior points"
    );
}

/// Theorem 20.5.3 — Corridors are fragile to adversarial action:
/// In a corridor, ε* ≈ τ* → minimal perturbation causes collapse.
#[test]
fn theorem_20_5_corridor_adversarial_vulnerability() {
    // Wide region
    let mut wide = Polytope::new();
    wide.add_constraint(Vector(vec![1.0, 0.0]), 100.0);
    wide.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    wide.add_constraint(Vector(vec![0.0, 1.0]), 100.0);
    wide.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    // Narrow corridor
    let mut narrow = Polytope::new();
    narrow.add_constraint(Vector(vec![1.0, 0.0]), 100.0);
    narrow.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    narrow.add_constraint(Vector(vec![0.0, 1.0]), 1.0); // extremely narrow
    narrow.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    let wide_center = Vector(vec![50.0, 50.0]);
    let narrow_center = Vector(vec![50.0, 0.5]);

    let eps_wide = wide.boundary_distance(&wide_center);
    let eps_narrow = narrow.boundary_distance(&narrow_center);

    // T20.5: Corridor is much more vulnerable
    assert!(
        eps_wide > eps_narrow,
        "Wide region ({}) must require larger perturbation than corridor ({})",
        eps_wide,
        eps_narrow
    );
    assert_eq!(eps_narrow, 0.5, "Corridor center has ε* = 0.5");
    assert_eq!(eps_wide, 50.0, "Wide center has ε* = 50");
}
