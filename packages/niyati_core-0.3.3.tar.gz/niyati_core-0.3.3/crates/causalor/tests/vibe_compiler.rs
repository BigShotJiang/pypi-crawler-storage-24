use causalor::*;

/// Phase 26 Integration Test Suite
/// Covers every major gap identified in the gap analysis.

// ============================================================================
// Existing test (updated to check new fields)
// ============================================================================

#[test]
fn test_vibe_compiler_hardened_startup() {
    let schema_json = r#"{
      "version": "1.0.0",
      "metadata": { "name": "Hardened Startup" },
      "time": { "type": "discrete", "horizon": 12 },
      "resources": { "money": { "initial": 500000, "min": 0 } },
      "variables": {
        "mrr": { 
            "type": "float", 
            "initial": 10000, 
            "min": 0, 
            "max": 1000000, 
            "discretization": 10000 
        },
        "runway": { 
            "type": "float", 
            "initial": 500000, 
            "min": 0, 
            "max": 1000000, 
            "discretization": 50000 
        }
      },
      "actions": [
        {
          "name": "hire",
          "cost": { "money": 150000 },
          "effects": {
            "mrr": { "op": "multiply", "value": 1.2 }
          },
          "preconditions": ["runway > 100000"]
        }
      ],
      "transitions": [
        {
          "name": "burn",
          "type": "recurring",
          "priority": 0,
          "effects": {
            "runway": { "op": "decrement", "value": 50000 }
          }
        }
      ],
      "constraints": [
        {
          "type": "non_negative",
          "variable": "runway",
          "mode": "hard"
        }
      ],
      "goal": {
        "type": "threshold",
        "conditions": [
          {
            "variable": "mrr",
            "operator": "gte",
            "value": 1000000
          }
        ]
      }
    }"#;

    let schema: VibeSchema = serde_json::from_str(schema_json).unwrap();
    let budget = 300000.0;

    let result = simulate(schema, Some(budget), CapabilityMode::Full);

    println!("Verdict: {}", result.verdict);
    println!("Timeline steps: {}", result.timeline.len());
    // New fields
    println!("Goal reached at: {:?}", result.goal_reached_at);
    println!(
        "Timeline[0].goal_distance: {}",
        result.timeline[0].goal_distance
    );

    assert_eq!(result.verdict, "possible");
    assert!(result.timeline[0].future_width > 0);
    // New: SimulationResult has goal_reached_at field
    // (possible values: None or Some(t))
    // goal_distance should be between 0.0 and 1.0
    assert!(result.timeline[0].goal_distance >= 0.0);
    assert!(result.timeline[0].goal_distance <= 1.0);
}

// ============================================================================
// Phase 24: Schema validation — invalid bounds rejected
// ============================================================================

#[test]
fn test_schema_validation_rejects_invalid_bounds() {
    let schema_json = r#"{
      "version": "1.0.0",
      "metadata": { "name": "Bad Schema" },
      "time": { "type": "discrete", "horizon": 5 },
      "resources": {},
      "variables": {
        "x": { "type": "float", "initial": 5.0, "min": 100.0, "max": 10.0, "discretization": 1.0 }
      },
      "actions": [],
      "transitions": [],
      "constraints": [],
      "goal": {
        "type": "threshold",
        "conditions": [{ "variable": "x", "operator": "gte", "value": 9.0 }]
      }
    }"#;

    let schema: VibeSchema = serde_json::from_str(schema_json).unwrap();
    let result = simulate(schema, None, CapabilityMode::Full);

    // Should return "invalid_schema" verdict with error in recommendation
    assert_eq!(result.verdict, "invalid_schema");
    assert!(
        result.recommendation.contains("min") || result.recommendation.contains("Schema error")
    );
    assert!(result.timeline.is_empty());
    println!("Validation rejection: {}", result.recommendation);
}

// ============================================================================
// Phase 24: Schema validation — zero discretization rejected
// ============================================================================

#[test]
fn test_schema_validation_rejects_zero_discretization() {
    let schema_json = r#"{
      "version": "1.0.0",
      "metadata": { "name": "Zero Disc" },
      "time": { "type": "discrete", "horizon": 5 },
      "resources": {},
      "variables": {
        "x": { "type": "float", "initial": 5.0, "min": 0.0, "max": 10.0, "discretization": 0.0 }
      },
      "actions": [],
      "transitions": [],
      "constraints": [],
      "goal": {
        "type": "threshold",
        "conditions": [{ "variable": "x", "operator": "gte", "value": 9.0 }]
      }
    }"#;

    let schema: VibeSchema = serde_json::from_str(schema_json).unwrap();
    let result = simulate(schema, None, CapabilityMode::Full);
    assert_eq!(result.verdict, "invalid_schema");
    println!("Zero disc rejection: {}", result.recommendation);
}

// ============================================================================
// Phase 21: Goal detection — goal already met at t=0 (goal_distance = 1.0)
// ============================================================================

#[test]
fn test_goal_already_met_at_start() {
    let schema_json = r#"{
      "version": "1.0.0",
      "metadata": { "name": "Already Won" },
      "time": { "type": "discrete", "horizon": 5 },
      "resources": {},
      "variables": {
        "score": { "type": "float", "initial": 100.0, "min": 0.0, "max": 200.0, "discretization": 10.0 }
      },
      "actions": [],
      "transitions": [],
      "constraints": [],
      "goal": {
        "type": "threshold",
        "conditions": [{ "variable": "score", "operator": "gte", "value": 50.0 }]
      }
    }"#;

    let schema: VibeSchema = serde_json::from_str(schema_json).unwrap();
    let result = simulate(schema, None, CapabilityMode::Full);

    println!("Goal distance at t=0: {}", result.timeline[0].goal_distance);
    println!("Goal reached at: {:?}", result.goal_reached_at);

    // Initial value (100) >= goal (50), so goal_distance should be 1.0
    assert_eq!(result.timeline[0].goal_distance, 1.0);
    // Goal should be detected at t=0
    assert_eq!(result.goal_reached_at, Some(0));
}

// ============================================================================
// Phase 21: Goal not met — goal_distance < 1.0
// ============================================================================

#[test]
fn test_goal_not_met_at_start() {
    let schema_json = r#"{
      "version": "1.0.0",
      "metadata": { "name": "Not Yet" },
      "time": { "type": "discrete", "horizon": 5 },
      "resources": {},
      "variables": {
        "score": { "type": "float", "initial": 5.0, "min": 0.0, "max": 200.0, "discretization": 1.0 }
      },
      "actions": [],
      "transitions": [],
      "constraints": [],
      "goal": {
        "type": "threshold",
        "conditions": [
          { "variable": "score", "operator": "gte", "value": 100.0 }
        ]
      }
    }"#;

    let schema: VibeSchema = serde_json::from_str(schema_json).unwrap();
    let result = simulate(schema, None, CapabilityMode::Full);

    println!("Goal distance: {}", result.timeline[0].goal_distance);
    // Initial score (5) < goal (100): no conditions met → 0.0
    assert_eq!(result.timeline[0].goal_distance, 0.0);
    assert_eq!(result.goal_reached_at, None);
}

// ============================================================================
// Phase 22: n-D polytope — per-variable bounds correctly enforce thickness
// ============================================================================

#[test]
fn test_nd_polytope_thickness_nonzero() {
    let schema_json = r#"{
      "version": "1.0.0",
      "metadata": { "name": "2D Polytope Test" },
      "time": { "type": "discrete", "horizon": 3 },
      "resources": {},
      "variables": {
        "x": { "type": "float", "initial": 5.0, "min": 0.0, "max": 100.0, "discretization": 5.0 },
        "y": { "type": "float", "initial": 5.0, "min": 0.0, "max": 100.0, "discretization": 5.0 }
      },
      "actions": [
        {
          "name": "move",
          "cost": { "energy": 1.0 },
          "effects": {
            "x": { "op": "add", "value": 5.0 },
            "y": { "op": "add", "value": 5.0 }
          },
          "preconditions": []
        }
      ],
      "transitions": [],
      "constraints": [],
      "goal": {
        "type": "threshold",
        "conditions": [{ "variable": "x", "operator": "gte", "value": 50.0 }]
      }
    }"#;

    let schema: VibeSchema = serde_json::from_str(schema_json).unwrap();
    let result = simulate(schema, None, CapabilityMode::Full);

    // With real n-D polytope (2 variables, both [0,100]), thickness at t=0 should be >= 0
    assert!(result.timeline[0].thickness >= 0.0);
    println!(
        "2D polytope thickness at t=0: {:.3}",
        result.timeline[0].thickness
    );
    println!("Verdict: {}", result.verdict);
}

// ============================================================================
// Phase 23: Point-of-no-return fires when budget exhausted
// ============================================================================

#[test]
fn test_point_of_no_return_with_tight_budget() {
    let schema_json = r#"{
      "version": "1.0.0",
      "metadata": { "name": "Tight Budget" },
      "time": { "type": "discrete", "horizon": 4 },
      "resources": { "money": { "initial": 50.0, "min": 0.0 } },
      "variables": {
        "x": { "type": "float", "initial": 0.0, "min": 0.0, "max": 10.0, "discretization": 1.0 }
      },
      "actions": [
        {
          "name": "step",
          "cost": { "money": 100.0 },
          "effects": { "x": { "op": "add", "value": 1.0 } },
          "preconditions": []
        }
      ],
      "transitions": [],
      "constraints": [],
      "goal": {
        "type": "threshold",
        "conditions": [{ "variable": "x", "operator": "gte", "value": 5.0 }]
      }
    }"#;

    let schema: VibeSchema = serde_json::from_str(schema_json).unwrap();
    // Budget = 50: only possible to take 0 steps (each costs 100)
    let result = simulate(schema, Some(50.0), CapabilityMode::Full);

    // future_width at t=4 (last step) should be 0 since no actions are affordable
    // with budget 50 * (1 - 4/4) = 0
    println!(
        "Timeline last step: {:?}",
        result.timeline.last().map(|s| s.future_width)
    );
    println!("Point of no return: {:?}", result.point_of_no_return);
    // At budget 50, no state transitions are possible since min cost = 100
    // So Ω should be 1 (only the start state is "reachable")
    assert!(result.timeline[0].future_width >= 1);
}

// ============================================================================
// Phase 25: AND-joined preconditions work correctly
// ============================================================================

#[test]
fn test_and_precondition_blocks_action() {
    let schema_json = r#"{
      "version": "1.0.0",
      "metadata": { "name": "AND Precondition" },
      "time": { "type": "discrete", "horizon": 3 },
      "resources": {},
      "variables": {
        "unlocked": { "type": "float", "initial": 0.0, "min": 0.0, "max": 1.0, "discretization": 1.0 },
        "energy": { "type": "float", "initial": 10.0, "min": 0.0, "max": 100.0, "discretization": 1.0 }
      },
      "actions": [
        {
          "name": "restricted_move",
          "cost": { "x": 1.0 },
          "effects": { "energy": { "op": "decrement", "value": 1.0 } },
          "preconditions": ["unlocked >= 1 && energy >= 5"]
        }
      ],
      "transitions": [],
      "constraints": [],
      "goal": {
        "type": "threshold",
        "conditions": [{ "variable": "energy", "operator": "lte", "value": 8.0 }]
      }
    }"#;

    let schema: VibeSchema = serde_json::from_str(schema_json).unwrap();
    let result = simulate(schema, None, CapabilityMode::Full);

    println!("AND precondition test verdict: {}", result.verdict);
    // unlocked = 0.0, so precondition "unlocked >= 1" fails → action never taken
    // Only the start state is reachable. Since energy starts at 10 and goal is <= 8,
    // goal is not met at start.
    assert_eq!(result.timeline[0].goal_distance, 0.0);
}
