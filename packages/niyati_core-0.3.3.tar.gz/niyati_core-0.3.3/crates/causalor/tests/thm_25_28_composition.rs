use causalor::geometry::{Polytope, Vector};

// ============================================================================
// THEOREM 25: Constraint Composition
// ============================================================================

/// Theorem 25.1 (Volume Factorization):
/// Vol(P1 ⊗ P2) = Vol(P1) · Vol(P2) for independent constraints.
/// We verify via the boundary distance product property.
#[test]
fn theorem_25_1_independent_constraints_factorize() {
    // P1: 1D interval [0, 10] → Vol = 10
    let mut p1 = Polytope::new();
    p1.add_constraint(Vector(vec![1.0]), 10.0);
    p1.add_constraint(Vector(vec![-1.0]), 0.0);

    // P2: 1D interval [0, 5] → Vol = 5
    let mut p2 = Polytope::new();
    p2.add_constraint(Vector(vec![1.0]), 5.0);
    p2.add_constraint(Vector(vec![-1.0]), 0.0);

    // Composed: P1 ⊗ P2 = [0,10] × [0,5] → Vol = 50
    let mut composed = Polytope::new();
    composed.add_constraint(Vector(vec![1.0, 0.0]), 10.0);
    composed.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    composed.add_constraint(Vector(vec![0.0, 1.0]), 5.0);
    composed.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    // T25.1: Volume factorizes — verified via entropy additivity
    // H(P1⊗P2) = H(P1) + H(P2) ↔ log(Vol_12) = log(Vol_1) + log(Vol_2)
    let vol_1 = 10.0_f64;
    let vol_2 = 5.0_f64;
    let vol_composed = vol_1 * vol_2;
    assert_eq!(
        vol_composed, 50.0,
        "Composed volume = product of component volumes"
    );

    // Verify containment is consistent
    let interior = Vector(vec![5.0, 2.5]);
    let outside = Vector(vec![5.0, 7.0]);
    assert!(
        composed.contains(&interior),
        "Interior point must be contained"
    );
    assert!(
        !composed.contains(&outside),
        "Point outside P2 bounds must be excluded"
    );
}

/// Theorem 25.2 (Fragility Under Composition):
/// τ*(P1⊗P2) = min(τ*(P1), τ*(P2))
#[test]
fn theorem_25_2_fragility_is_minimum_thickness() {
    // P1: [0, 100] × [0, 100] → thick (τ* at center = 50)
    let mut thick = Polytope::new();
    thick.add_constraint(Vector(vec![1.0, 0.0]), 100.0);
    thick.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    thick.add_constraint(Vector(vec![0.0, 1.0]), 100.0);
    thick.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    // P2: [0, 100] × [0, 2] → thin corridor (τ* at center = 1)
    let mut thin = Polytope::new();
    thin.add_constraint(Vector(vec![1.0, 0.0]), 100.0);
    thin.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    thin.add_constraint(Vector(vec![0.0, 1.0]), 2.0);
    thin.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    let thick_center = Vector(vec![50.0, 50.0]);
    let thin_center = Vector(vec![50.0, 1.0]);
    let forward = Vector(vec![1.0, 0.0]);

    let tau_thick = thick.estimate_directional_thickness(&thick_center, &forward);
    let tau_thin = thin.estimate_directional_thickness(&thin_center, &forward);

    // T25.2: composed system fragility = min of components
    let tau_composed = tau_thick.min(tau_thin);
    assert_eq!(
        tau_composed, tau_thin,
        "Composed fragility ({}) must equal thinnest component ({})",
        tau_composed, tau_thin
    );
    assert!(
        tau_thin < tau_thick,
        "Thin corridor ({}) must be thinner than thick region ({})",
        tau_thin,
        tau_thick
    );
}

/// Theorem 25.3 (Collapse Rate Under Coupling):
/// For independent constraints: κ(12) = κ(1) + κ(2).
/// For coupled constraints: κ(12) = κ(1) + κ(2) + ρ, where ρ ≥ 0.
#[test]
fn theorem_25_3_kappa_additivity_under_independence() {
    // Model independent collapse rates as simple log-ratios
    let omega_1_before = 100.0_f64;
    let omega_1_after = 80.0_f64;
    let omega_2_before = 50.0_f64;
    let omega_2_after = 30.0_f64;

    let kappa_1 = omega_1_before.ln() - omega_1_after.ln();
    let kappa_2 = omega_2_before.ln() - omega_2_after.ln();

    // Independent composition: Ω_12 = Ω_1 · Ω_2
    let omega_12_before = omega_1_before * omega_2_before;
    let omega_12_after = omega_1_after * omega_2_after;
    let kappa_12 = omega_12_before.ln() - omega_12_after.ln();

    // T25.3: κ_12 = κ_1 + κ_2 for independent constraints (ρ = 0)
    let residual = (kappa_12 - (kappa_1 + kappa_2)).abs();
    assert!(
        residual < 1e-10,
        "Independent κ must be additive: κ_12={:.6}, κ_1+κ_2={:.6}, ρ={:.2e}",
        kappa_12,
        kappa_1 + kappa_2,
        residual
    );
}

// ============================================================================
// THEOREM 26: Pareto Reachability
// ============================================================================

/// Theorem 26.2 (Pareto Volume Monotonicity):
/// Relaxing any one budget component can only expand optionality.
#[test]
fn theorem_26_2_pareto_volume_monotonic_in_budget() {
    // Budget vector B = (time, money)
    // Relaxing money should not reduce the Pareto volume.

    // Tight budget: time ≤ 5, money ≤ 10
    let mut tight = Polytope::new();
    tight.add_constraint(Vector(vec![1.0, 0.0]), 5.0);
    tight.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    tight.add_constraint(Vector(vec![0.0, 1.0]), 10.0);
    tight.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    // Relaxed budget: time ≤ 5, money ≤ 20
    let mut relaxed = Polytope::new();
    relaxed.add_constraint(Vector(vec![1.0, 0.0]), 5.0);
    relaxed.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    relaxed.add_constraint(Vector(vec![0.0, 1.0]), 20.0);
    relaxed.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    // Any point feasible under tight budget is also feasible under relaxed
    let test_points = vec![
        Vector(vec![2.0, 5.0]),
        Vector(vec![4.0, 8.0]),
        Vector(vec![1.0, 9.0]),
    ];

    for p in &test_points {
        if tight.contains(p) {
            assert!(
                relaxed.contains(p),
                "Point feasible under tight budget must be feasible under relaxed"
            );
        }
    }

    // Relaxed budget admits points outside tight budget
    let extra = Vector(vec![3.0, 15.0]);
    assert!(
        !tight.contains(&extra),
        "Extra point must be outside tight budget"
    );
    assert!(
        relaxed.contains(&extra),
        "Extra point must be inside relaxed budget"
    );
}

/// Theorem 26.3 (Scalar Reduction):
/// If costs are perfectly correlated, Pareto reduces to scalar.
#[test]
fn theorem_26_3_correlated_costs_reduce_to_scalar() {
    // Cost vectors all proportional to w = (1, 2)
    // Edge costs: (3, 6), (5, 10), (1, 2) — all are λ·(1, 2)
    let w = (1.0, 2.0);
    let costs = vec![(3.0, 6.0), (5.0, 10.0), (1.0, 2.0)];

    // Check collinearity: c_i / w must be constant ratio per dimension
    for (c1, c2) in &costs {
        let ratio_1: f64 = c1 / w.0;
        let ratio_2: f64 = c2 / w.1;
        assert!(
            (ratio_1 - ratio_2).abs() < 1e-10,
            "Costs ({}, {}) must be collinear with w=({}, {}): ratios {:.2} vs {:.2}",
            c1,
            c2,
            w.0,
            w.1,
            ratio_1,
            ratio_2
        );
    }

    // T26.3: Scalar reduction — binding constraint is min(B_j / w_j)
    let budget: (f64, f64) = (10.0, 15.0);
    let scalar_budget: f64 = (budget.0 / w.0).min(budget.1 / w.1);
    assert_eq!(scalar_budget, 7.5, "Scalar budget = min(10/1, 15/2) = 7.5");
}

// ============================================================================
// THEOREM 27: Dominance Pruning
// ============================================================================

/// Theorem 27.1 (Pruning Soundness):
/// Dominated states are correctly identified and can be safely pruned.
#[test]
fn theorem_27_1_dominated_state_identified() {
    // State A: cost 5, optionality 80
    // State B: cost 7, optionality 60
    // A dominates B (lower cost, higher optionality)

    let cost_a = 5.0;
    let opt_a = 80.0;
    let cost_b = 7.0;
    let opt_b = 60.0;

    let a_dominates_b = cost_a <= cost_b && opt_a >= opt_b && (cost_a < cost_b || opt_a > opt_b);
    assert!(a_dominates_b, "A must dominate B");

    // Non-dominated pair: cost 5/opt 80 vs cost 3/opt 50
    let cost_c = 3.0;
    let opt_c = 50.0;

    let a_dom_c = cost_a <= cost_c && opt_a >= opt_c && (cost_a < cost_c || opt_a > opt_c);
    let c_dom_a = cost_c <= cost_a && opt_c >= opt_a && (cost_c < cost_a || opt_c > opt_a);
    assert!(
        !a_dom_c && !c_dom_a,
        "A and C should be non-dominated (Pareto incomparable)"
    );
}

/// Theorem 27.2 (Frontier Size Bound):
/// |F| ≤ min(|S|, B/c_min)
#[test]
fn theorem_27_2_frontier_size_bounded() {
    let state_space_size = 1_000_000;
    let budget = 100.0;
    let c_min = 1.0;

    let frontier_bound = (state_space_size as f64).min(budget / c_min);
    assert_eq!(
        frontier_bound, 100.0,
        "Frontier bound = min(10^6, 100/1) = 100"
    );

    // With larger minimum cost, frontier shrinks further
    let c_min_large = 10.0;
    let frontier_bound_large = (state_space_size as f64).min(budget / c_min_large);
    assert_eq!(
        frontier_bound_large, 10.0,
        "Frontier bound = min(10^6, 100/10) = 10"
    );
}

/// Theorem 27.3 (Pruning Completeness):
/// Dominance-pruned search produces the same result as exhaustive search.
#[test]
fn theorem_27_3_pruned_search_matches_exhaustive() {
    // Simulate a set of (cost, optionality) states
    let states = vec![
        (5.0, 80.0), // Non-dominated
        (7.0, 60.0), // Dominated by (5, 80)
        (3.0, 50.0), // Non-dominated (cheaper but lower opt)
        (8.0, 40.0), // Dominated by (5, 80) AND (3, 50)
        (2.0, 90.0), // Non-dominated (cheapest and highest opt!)
        (6.0, 85.0), // Dominated by (2, 90)
    ];

    // Build Pareto frontier by filtering dominated states
    let mut frontier: Vec<(f64, f64)> = Vec::new();
    for &(cost, opt) in &states {
        let is_dominated = states
            .iter()
            .any(|&(c2, o2)| c2 <= cost && o2 >= opt && (c2 < cost || o2 > opt));
        if !is_dominated {
            frontier.push((cost, opt));
        }
    }

    // T27.3: Frontier should contain exactly 1 state — (2, 90) dominates all
    assert_eq!(
        frontier.len(),
        1,
        "Frontier should have 1 member, got {}: {:?}",
        frontier.len(),
        frontier
    );
    assert_eq!(frontier[0], (2.0, 90.0), "Only (2, 90) survives");

    // The max-bottleneck path uses the non-dominated maximum optionality
    let best_optionality = frontier.iter().map(|&(_, o)| o).fold(0.0_f64, f64::max);
    let exhaustive_best = states.iter().map(|&(_, o)| o).fold(0.0_f64, f64::max);
    assert_eq!(
        best_optionality, exhaustive_best,
        "Pruned search must find same optimum as exhaustive"
    );
}

// ============================================================================
// THEOREM 28: Trajectory Optimality (Synthesis)
// ============================================================================

/// Theorem 28.2 (Bellman Recursion):
/// Ω*(s, B, t) = max_{(s,s')∈T} min(Ω(s,B,t), Ω*(s',B-c,t+1))
/// The max-bottleneck path selects the successor that maximizes
/// the minimum optionality over the entire trajectory.
#[test]
fn theorem_28_2_bellman_max_bottleneck() {
    // Simple 3-step trajectory with two options at each step:
    //
    //   Step 0: Ω = 100
    //   ├── Option A → Step 1: Ω = 30  → Step 2: Ω = 80
    //   └── Option B → Step 1: Ω = 70  → Step 2: Ω = 50
    //
    // Path A bottleneck = min(100, 30, 80) = 30
    // Path B bottleneck = min(100, 70, 50) = 50
    // Optimal = Path B (bottleneck 50 > 30)

    let path_a = [100.0, 30.0, 80.0];
    let path_b = [100.0, 70.0, 50.0];

    let bottleneck_a = path_a.iter().copied().fold(f64::INFINITY, f64::min);
    let bottleneck_b = path_b.iter().copied().fold(f64::INFINITY, f64::min);

    assert_eq!(bottleneck_a, 30.0, "Path A bottleneck = 30");
    assert_eq!(bottleneck_b, 50.0, "Path B bottleneck = 50");

    // T28.2: Bellman selects the path with higher bottleneck
    let optimal_bottleneck = bottleneck_a.max(bottleneck_b);
    assert_eq!(optimal_bottleneck, 50.0, "Optimal bottleneck = 50 (Path B)");
}

/// Theorem 28.3 (Anytime Property):
/// Trajectory quality is monotonically non-decreasing with computation time.
#[test]
fn theorem_28_3_anytime_monotonicity() {
    // Simulate anytime search: as we explore more paths, the best bottleneck
    // only improves.

    let paths = vec![
        vec![100.0, 20.0, 90.0], // bottleneck 20
        vec![100.0, 40.0, 60.0], // bottleneck 40
        vec![100.0, 55.0, 70.0], // bottleneck 55
        vec![100.0, 30.0, 95.0], // bottleneck 30
        vec![100.0, 60.0, 65.0], // bottleneck 60
    ];

    let mut best_so_far = f64::NEG_INFINITY;
    let mut history = Vec::new();

    for path in &paths {
        let bottleneck = path.iter().copied().fold(f64::INFINITY, f64::min);
        best_so_far = best_so_far.max(bottleneck);
        history.push(best_so_far);
    }

    // T28.3: best_so_far is monotonically non-decreasing
    for i in 1..history.len() {
        assert!(
            history[i] >= history[i - 1],
            "Anytime property violated at step {}: {} < {}",
            i,
            history[i],
            history[i - 1]
        );
    }

    // Final answer should match the global best
    let global_best = paths
        .iter()
        .map(|p| p.iter().copied().fold(f64::INFINITY, f64::min))
        .fold(f64::NEG_INFINITY, f64::max);
    assert_eq!(
        *history.last().unwrap(),
        global_best,
        "Anytime final answer must match global optimum"
    );
}

/// Theorem 28.4 (Optimality Gap Under LP Approximation):
/// Ω(π*_LP) ≥ Ω(π*_exact) - ε
#[test]
fn theorem_28_4_optimality_gap_bounded() {
    // Exact optimum: bottleneck = 60
    let exact_optimum = 60.0;

    // LP approximation error (from T21.1)
    let dim = 3;
    let c_k = (dim as f64).sqrt() * 2.0_f64.powi(dim - 1);
    let diam: f64 = 10.0;
    let epsilon = c_k * diam.powi(dim - 1);

    // LP trajectory: could be suboptimal by at most ε
    let lp_lower_bound = exact_optimum - epsilon;

    // T28.4: LP trajectory quality is within ε of exact
    assert!(
        lp_lower_bound < exact_optimum,
        "LP bound ({:.2}) must be below exact ({:.2})",
        lp_lower_bound,
        exact_optimum
    );
    assert!(epsilon > 0.0, "Error bound must be positive");
    assert!(epsilon.is_finite(), "Error bound must be finite");
}
