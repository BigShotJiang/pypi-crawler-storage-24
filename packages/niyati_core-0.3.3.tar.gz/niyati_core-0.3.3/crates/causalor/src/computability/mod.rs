//! Theorem 20c: Computability of Reachable Sets
//!
//! Classifies computation problems into three regimes:
//! - ExactBFS: |S| tractable, exact guarantees (T20c.1)
//! - ApproximateLP: |S| intractable, T8.4 error bounds (T20c.2)
//! - Unsound: Assumption 8.0 violated, no guarantees (T20c.3)

/// Computation mode classification.
#[derive(Debug, Clone, PartialEq)]
pub enum ComputationMode {
    /// T20c.1: |S| tractable, exact guarantees via Dijkstra
    ExactBFS,
    /// T20c.2: |S| intractable (#P-hard), LP relaxation with T8.4 bounds
    ApproximateLP,
    /// T20c.3: Assumption 8.0 violated — results formally unsound
    Unsound,
}

/// A detected violation of Causalor's foundational assumptions
#[derive(Debug, Clone)]
pub struct AssumptionViolation {
    pub assumption: String,
    pub details: String,
    pub severity: ViolationSeverity,
}

#[derive(Debug, Clone, PartialEq)]
pub enum ViolationSeverity {
    /// Results may be slightly degraded
    Warning,
    /// Results are formally unsound — no guarantees apply
    Critical,
}

/// Complete computability analysis for a given problem instance
#[derive(Debug, Clone)]
pub struct ComputabilityAnalysis {
    pub mode: ComputationMode,
    pub state_space_size: Option<usize>,
    pub error_bound: Option<f64>,
    pub assumption_violations: Vec<AssumptionViolation>,
}

/// Threshold for switching from BFS to LP mode (number of states)
const BFS_LP_THRESHOLD: usize = 1_000_000;

impl ComputabilityAnalysis {
    /// Theorem 20c: classify the computation mode for a given problem.
    ///
    /// Checks Assumption 8.0 (additive, non-negative costs) and state space size
    /// to determine which engine mode provides formal guarantees.
    pub fn analyze(
        state_space_size: Option<usize>,
        has_negative_costs: bool,
        is_non_additive: bool,
    ) -> Self {
        let mut violations = Vec::new();

        // Check Assumption 8.0.2: Positive Monotonicity
        if has_negative_costs {
            violations.push(AssumptionViolation {
                assumption: "Assumption 8.0.2 (Positive Monotonicity)".into(),
                details: "Negative costs detected — budget can increase along paths, \
                          breaking monotone contraction (T4)"
                    .into(),
                severity: ViolationSeverity::Critical,
            });
        }

        // Check Assumption 8.0.1: Additive Cost Algebra
        if is_non_additive {
            violations.push(AssumptionViolation {
                assumption: "Assumption 8.0.1 (Additive Cost Algebra)".into(),
                details: "Non-additive cost structure — polytope embedding (T8) invalid, \
                          all geometric tier theorems inapplicable"
                    .into(),
                severity: ViolationSeverity::Critical,
            });
        }

        // T20c.3: Any critical violation → Unsound mode
        if violations
            .iter()
            .any(|v| v.severity == ViolationSeverity::Critical)
        {
            return Self {
                mode: ComputationMode::Unsound,
                state_space_size,
                error_bound: None,
                assumption_violations: violations,
            };
        }

        // T20c.1 vs T20c.2: classify by state space tractability
        match state_space_size {
            Some(n) if n < BFS_LP_THRESHOLD => Self {
                mode: ComputationMode::ExactBFS,
                state_space_size: Some(n),
                error_bound: Some(0.0), // Exact — no approximation error
                assumption_violations: violations,
            },
            _ => Self {
                mode: ComputationMode::ApproximateLP,
                state_space_size,
                error_bound: Some(1.0), // Placeholder: actual bound from T8.4
                assumption_violations: violations,
            },
        }
    }

    /// Returns true if the analysis detects any formal guarantee violations
    pub fn is_sound(&self) -> bool {
        self.mode != ComputationMode::Unsound
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn small_graph_selects_bfs() {
        let analysis = ComputabilityAnalysis::analyze(Some(100), false, false);
        assert_eq!(analysis.mode, ComputationMode::ExactBFS);
        assert_eq!(analysis.error_bound, Some(0.0));
        assert!(analysis.is_sound());
    }

    #[test]
    fn large_graph_selects_lp() {
        let analysis = ComputabilityAnalysis::analyze(Some(10_000_000), false, false);
        assert_eq!(analysis.mode, ComputationMode::ApproximateLP);
        assert!(analysis.error_bound.unwrap() > 0.0);
        assert!(analysis.is_sound());
    }

    #[test]
    fn negative_costs_unsound() {
        let analysis = ComputabilityAnalysis::analyze(Some(100), true, false);
        assert_eq!(analysis.mode, ComputationMode::Unsound);
        assert!(!analysis.is_sound());
        assert_eq!(analysis.assumption_violations.len(), 1);
    }

    #[test]
    fn non_additive_unsound() {
        let analysis = ComputabilityAnalysis::analyze(Some(100), false, true);
        assert_eq!(analysis.mode, ComputationMode::Unsound);
        assert!(!analysis.is_sound());
    }

    #[test]
    fn unknown_size_selects_lp() {
        let analysis = ComputabilityAnalysis::analyze(None, false, false);
        assert_eq!(analysis.mode, ComputationMode::ApproximateLP);
    }
}
