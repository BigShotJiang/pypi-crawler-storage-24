//! Theorem 24: Temporal Consistency Checking
//!
//! Runtime invariant verification for the Causalor engine.
//! Detects when measurements violate the mathematical guarantees
//! of the theorem canon — monotonicity breaches, κ additivity
//! failures, and state function path dependence.

use crate::types::Time;

/// A single observation in the temporal history
#[derive(Debug, Clone)]
pub struct Observation {
    pub time: Time,
    pub omega: f64,
}

/// T24.1: Monotonicity violation — Ω increased between steps
#[derive(Debug, Clone)]
pub struct MonotonicityViolation {
    pub time_from: Time,
    pub time_to: Time,
    pub omega_from: f64,
    pub omega_to: f64,
    pub magnitude: f64,
}

/// Complete consistency report
#[derive(Debug, Clone)]
pub struct ConsistencyReport {
    /// T24.1: All monotonicity violations detected
    pub monotonicity_violations: Vec<MonotonicityViolation>,
    /// T24.2: κ additivity residual (should be ≈ 0)
    pub additivity_residual: f64,
    /// T24.3: Path independence verified
    pub state_function_valid: bool,
    /// Overall system health
    pub is_consistent: bool,
}

/// Theorem 24: Temporal Consistency Checker
///
/// Maintains a running history of (time, Ω) observations and
/// verifies the three temporal invariants in real time.
#[derive(Debug, Clone)]
pub struct TemporalConsistencyChecker {
    history: Vec<Observation>,
}

impl TemporalConsistencyChecker {
    pub fn new() -> Self {
        Self {
            history: Vec::new(),
        }
    }

    /// Record a new observation.
    pub fn record(&mut self, time: Time, omega: f64) {
        self.history.push(Observation { time, omega });
    }

    /// Number of observations recorded.
    pub fn len(&self) -> usize {
        self.history.len()
    }

    /// Whether the checker has no observations.
    pub fn is_empty(&self) -> bool {
        self.history.is_empty()
    }

    /// T24.1: Check temporal monotonicity invariant.
    ///
    /// In a static system (no discovery events), Ω must never increase.
    /// Any increase is a diagnostic signal — either a measurement error,
    /// a discovery event, or a bug.
    pub fn check_monotonicity(&self) -> Vec<MonotonicityViolation> {
        let mut violations = Vec::new();
        for window in self.history.windows(2) {
            let (prev, curr) = (&window[0], &window[1]);
            if curr.omega > prev.omega + 1e-10 {
                violations.push(MonotonicityViolation {
                    time_from: prev.time,
                    time_to: curr.time,
                    omega_from: prev.omega,
                    omega_to: curr.omega,
                    magnitude: curr.omega - prev.omega,
                });
            }
        }
        violations
    }

    /// T24.2: Check κ additivity invariant.
    ///
    /// Σ κ(t_k → t_{k+1}) must equal log Ω(t_0) - log Ω(t_n).
    /// Returns the residual (should be ≈ 0 for a consistent system).
    pub fn check_kappa_additivity(&self) -> f64 {
        if self.history.len() < 2 {
            return 0.0;
        }

        // Sum of step-wise κ
        let kappa_sum: f64 = self
            .history
            .windows(2)
            .map(|w| {
                let (prev, curr) = (w[0].omega, w[1].omega);
                if prev > 0.0 && curr > 0.0 {
                    prev.ln() - curr.ln()
                } else if prev > 0.0 {
                    f64::INFINITY
                } else {
                    0.0
                }
            })
            .filter(|k| k.is_finite())
            .sum();

        // Endpoint difference
        let first = self.history.first().unwrap().omega;
        let last = self.history.last().unwrap().omega;

        if first > 0.0 && last > 0.0 {
            let endpoint_diff = first.ln() - last.ln();
            (kappa_sum - endpoint_diff).abs()
        } else {
            0.0 // Can't check when endpoints are zero
        }
    }

    /// T24.3: Verify state function property.
    ///
    /// Total information loss depends only on endpoints, not path.
    /// We verify this by checking that κ additivity holds (T24.2)
    /// — if it does, the collapse rate is a state function.
    pub fn verify_state_function(&self) -> bool {
        let residual = self.check_kappa_additivity();
        residual < 1e-6
    }

    /// Run all three checks and produce a complete report.
    pub fn full_report(&self) -> ConsistencyReport {
        let violations = self.check_monotonicity();
        let residual = self.check_kappa_additivity();
        let state_fn = self.verify_state_function();

        ConsistencyReport {
            is_consistent: violations.is_empty() && state_fn,
            monotonicity_violations: violations,
            additivity_residual: residual,
            state_function_valid: state_fn,
        }
    }
}

impl Default for TemporalConsistencyChecker {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn monotonic_series_passes() {
        let mut checker = TemporalConsistencyChecker::new();
        for (t, omega) in [(0, 100.0), (1, 90.0), (2, 70.0), (3, 50.0)] {
            checker.record(t, omega);
        }
        assert!(checker.check_monotonicity().is_empty());
    }

    #[test]
    fn breach_detected() {
        let mut checker = TemporalConsistencyChecker::new();
        checker.record(0, 100.0);
        checker.record(1, 80.0);
        checker.record(2, 90.0); // breach!
        checker.record(3, 50.0);

        let violations = checker.check_monotonicity();
        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].time_from, 1);
        assert_eq!(violations[0].time_to, 2);
    }

    #[test]
    fn kappa_additivity_holds() {
        let mut checker = TemporalConsistencyChecker::new();
        for (t, omega) in [(0, 100.0), (1, 80.0), (2, 50.0), (3, 20.0)] {
            checker.record(t, omega);
        }
        let residual = checker.check_kappa_additivity();
        assert!(
            residual < 1e-10,
            "Additivity residual should be ~0, got {}",
            residual
        );
    }

    #[test]
    fn state_function_verified() {
        let mut checker = TemporalConsistencyChecker::new();
        for (t, omega) in [(0, 100.0), (1, 50.0), (2, 25.0), (3, 10.0)] {
            checker.record(t, omega);
        }
        assert!(checker.verify_state_function());
    }

    #[test]
    fn full_report_consistent() {
        let mut checker = TemporalConsistencyChecker::new();
        for (t, omega) in [(0, 100.0), (1, 80.0), (2, 60.0), (3, 40.0)] {
            checker.record(t, omega);
        }
        let report = checker.full_report();
        assert!(report.is_consistent);
        assert!(report.monotonicity_violations.is_empty());
        assert!(report.state_function_valid);
    }

    #[test]
    fn full_report_inconsistent() {
        let mut checker = TemporalConsistencyChecker::new();
        checker.record(0, 100.0);
        checker.record(1, 50.0);
        checker.record(2, 80.0); // breach
        checker.record(3, 30.0);

        let report = checker.full_report();
        assert!(!report.is_consistent);
        assert_eq!(report.monotonicity_violations.len(), 1);
    }
}
