pub mod types;

use async_trait::async_trait;
use chrono::Utc;
use serde::{Deserialize, Serialize};
use std::collections::{HashSet, VecDeque};
use std::fs;
use std::time::Duration;

use crate::observer::types::*;

#[derive(Debug, thiserror::Error)]
pub enum ObserverError {
    #[error("Fetch error: {0}")]
    FetchError(String),
    #[error("Serialization error: {0}")]
    SerdeError(#[from] serde_json::Error),
    #[error("IO error: {0}")]
    IoError(#[from] std::io::Error),
}

#[async_trait]
pub trait ObservableSystem: Send + Sync {
    async fn fetch_state(&self) -> Result<SystemState, ObserverError>;
    fn compute_omega(&self, state: &SystemState) -> f64;
    fn build_state_id(&self, state: &SystemState) -> String;
    fn describe_state_snapshot(&self, snapshot: &StateSnapshot) -> String;
}

#[derive(Debug, Serialize, Deserialize)]
struct PersistedState {
    last_omega: f64,
    last_state_id: String,
    alerted_impossibilities: HashSet<String>,
    last_update: chrono::DateTime<Utc>,
}

pub struct CausalObserver {
    pub system: Box<dyn ObservableSystem>,
    pub poll_interval: Duration,
    pub previous_omega: Option<f64>,
    pub previous_state: Option<SystemState>,
    pub previous_state_id: Option<String>,
    pub state_history: VecDeque<StateSnapshot>,
    pub alerted_impossibilities: HashSet<String>,
    pub persist_file: String,
}

impl CausalObserver {
    pub fn new(
        system: Box<dyn ObservableSystem>,
        poll_interval: Duration,
        persist_file: &str,
    ) -> Self {
        let mut observer = Self {
            system,
            poll_interval,
            previous_omega: None,
            previous_state: None,
            previous_state_id: None,
            state_history: VecDeque::new(),
            alerted_impossibilities: HashSet::new(),
            persist_file: persist_file.to_string(),
        };
        observer
            .load_state()
            .unwrap_or_else(|e| println!("No persistence state found, starting fresh: {}", e));
        observer
    }

    fn load_state(&mut self) -> Result<(), ObserverError> {
        if let Ok(data) = fs::read_to_string(&self.persist_file) {
            let state: PersistedState = serde_json::from_str(&data)?;
            self.previous_omega = Some(state.last_omega);
            self.previous_state_id = Some(state.last_state_id);
            self.alerted_impossibilities = state.alerted_impossibilities;
            println!(
                "📂 Loaded persisted state from {}",
                state.last_update.format("%Y-%m-%d %H:%M:%S")
            );
        }
        Ok(())
    }

    fn save_state(&self) -> Result<(), ObserverError> {
        let state = PersistedState {
            last_omega: self.previous_omega.unwrap_or(0.0),
            last_state_id: self.previous_state_id.clone().unwrap_or_default(),
            alerted_impossibilities: self.alerted_impossibilities.clone(),
            last_update: Utc::now(),
        };
        let json = serde_json::to_string_pretty(&state)?;
        fs::write(&self.persist_file, json)?;
        Ok(())
    }

    fn classify(&self, omega: f64) -> AlertLevel {
        if omega == 0.0 {
            AlertLevel::Terminal
        } else if omega == 1.0 {
            AlertLevel::Critical
        } else if omega <= 10.0 {
            AlertLevel::Warning
        } else {
            AlertLevel::Safe
        }
    }

    fn map_phase(&self, omega: f64) -> Phase {
        match self.classify(omega) {
            AlertLevel::Safe => Phase::Safe,
            AlertLevel::Warning => Phase::Warning,
            AlertLevel::Critical => Phase::Critical,
            AlertLevel::Terminal => Phase::Collapsed,
        }
    }

    fn generate_proof(
        &self,
        prev_omega: f64,
        curr_omega: f64,
        state: &SystemState,
    ) -> ImpossibilityProof {
        let collapse_timeline: Vec<_> = self
            .state_history
            .iter()
            .map(|snapshot| CollapseStep {
                timestamp: snapshot.timestamp,
                omega: snapshot.omega,
                state_description: self.system.describe_state_snapshot(snapshot),
                phase: self.map_phase(snapshot.omega),
            })
            .collect();

        ImpossibilityProof {
            omega_before: prev_omega,
            omega_after: curr_omega,
            collapse_rate: if prev_omega > 0.0 {
                prev_omega.ln() - curr_omega.max(0.01).ln()
            } else {
                f64::INFINITY
            },
            collapse_timeline,
            violated_theorem: "Theorem 5: Point of No Return".to_string(),
            proof_type: ProofType::Structural,
            state_transition: StateTransition {
                from: self.previous_state_id.clone().unwrap_or_default(),
                to: state.id.clone(),
                trigger_event: "State Transition Detected".to_string(),
                eliminated_paths: None,
            },
            confidence: state.confidence,
            corroborating_sources: state.corroborating_sources.clone(),
            verification_url: None,
            reproducible: true,
        }
    }

    async fn broadcast(&self, proof: &ImpossibilityProof) -> Result<(), ObserverError> {
        let hr = proof.format_human_readable();
        println!("{}", hr);
        Ok(())
    }

    pub async fn run(&mut self) -> Result<(), ObserverError> {
        let mut interval = tokio::time::interval(self.poll_interval);

        loop {
            interval.tick().await;

            let state = match self.system.fetch_state().await {
                Ok(s) => s,
                Err(e) => {
                    println!("Failed to fetch state: {}", e);
                    continue;
                }
            };

            let state_id = self.system.build_state_id(&state);

            if let Some(prev_id) = &self.previous_state_id {
                if state_id == *prev_id {
                    continue; // State hasn't changed
                }
            }

            let omega = self.system.compute_omega(&state);

            let snapshot = StateSnapshot {
                id: state_id.clone(),
                timestamp: state.timestamp,
                omega,
                confidence: state.confidence,
                description: "Automated snapshot".to_string(),
            };

            self.state_history.push_back(snapshot);
            if self.state_history.len() > 100 {
                self.state_history.pop_front();
            }

            if let (Some(prev_omega), Some(_)) = (&self.previous_omega, &self.previous_state) {
                if omega == 0.0 && *prev_omega > 0.0 && state.confidence >= 0.95 {
                    let impossibility_key = format!("{}_impossible", state_id);
                    if !self.alerted_impossibilities.contains(&impossibility_key) {
                        let proof = self.generate_proof(*prev_omega, omega, &state);
                        self.broadcast(&proof).await?;
                        self.alerted_impossibilities.insert(impossibility_key);
                        self.save_state()?;
                    }
                } else if omega != *prev_omega {
                    let level = self.classify(omega);
                    if level == AlertLevel::Critical || level == AlertLevel::Warning {
                        println!("⚠️ State Shift Detected: Ω = {:.0}", omega);
                    }
                }
            }

            self.previous_omega = Some(omega);
            self.previous_state = Some(state.clone());
            self.previous_state_id = Some(state_id);
            self.save_state()?;
        }
    }
}
