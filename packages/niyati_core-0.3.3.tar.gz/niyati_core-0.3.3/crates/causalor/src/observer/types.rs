use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemState {
    pub id: String,
    pub timestamp: DateTime<Utc>,
    pub data: HashMap<String, serde_json::Value>,
    pub confidence: f64,
    pub source: String,
    pub corroborating_sources: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StateSnapshot {
    pub id: String,
    pub timestamp: DateTime<Utc>,
    pub omega: f64,
    pub confidence: f64,
    pub description: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum Phase {
    Safe,      // Ω > 10
    Warning,   // 1 < Ω ≤ 10
    Critical,  // Ω = 1
    Collapsed, // Ω = 0
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum AlertLevel {
    Safe,
    Warning,
    Critical,
    Terminal,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ProofType {
    Structural,
    Numerical,
    Combinatorial,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CollapseStep {
    pub timestamp: DateTime<Utc>,
    pub omega: f64,
    pub state_description: String,
    pub phase: Phase,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StateTransition {
    pub from: String,
    pub to: String,
    pub trigger_event: String,
    pub eliminated_paths: Option<Vec<String>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImpossibilityProof {
    pub omega_before: f64,
    pub omega_after: f64,
    pub collapse_rate: f64,
    pub collapse_timeline: Vec<CollapseStep>,
    pub violated_theorem: String,
    pub proof_type: ProofType,
    pub state_transition: StateTransition,
    pub confidence: f64,
    pub corroborating_sources: Vec<String>,
    pub verification_url: Option<String>,
    pub reproducible: bool,
}

impl ImpossibilityProof {
    pub fn format_human_readable(&self) -> String {
        let mut output = String::new();
        output.push_str("🚨 STRUCTURAL IMPOSSIBILITY PROOF\n\n");
        output.push_str("Timeline of Collapse:\n");
        for step in &self.collapse_timeline {
            let phase_emoji = match step.phase {
                Phase::Safe => "✅",
                Phase::Warning => "⚠️",
                Phase::Critical => "🚨",
                Phase::Collapsed => "❌",
            };
            output.push_str(&format!(
                "[{}] {} Ω = {:.0} - {}\n",
                step.timestamp.format("%H:%M:%S"),
                phase_emoji,
                step.omega,
                step.state_description
            ));
        }

        let pct = if self.omega_before > 0.0 {
            100.0 * (self.omega_before - self.omega_after) / self.omega_before
        } else {
            100.0
        };

        output.push_str(&format!(
            "\nTransition:\n\
             • Before: Ω = {:.0} paths\n\
             • After: Ω = {:.0} paths\n\
             • Collapse: {:.1}% of futures eliminated\n\n",
            self.omega_before, self.omega_after, pct
        ));

        output.push_str(&format!("Theorem: {}\n", self.violated_theorem));
        output.push_str(&format!("Confidence: {:.1}%\n", self.confidence * 100.0));

        if !self.corroborating_sources.is_empty() {
            output.push_str(&format!(
                "Sources: {}\n",
                self.corroborating_sources.join(", ")
            ));
        }
        output.push_str("\nThis is mathematics, not prediction.\n");
        output
    }

    pub fn to_json(&self) -> String {
        serde_json::to_string_pretty(self).unwrap()
    }
}
