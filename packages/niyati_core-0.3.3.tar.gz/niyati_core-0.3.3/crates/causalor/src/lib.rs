//! Causalor: Mathematical infrastructure for computing reachable futures
//!
//! This library implements theorems from reachability theory to analyze
//! what states remain reachable under resource constraints.
//!
//! ## Theorem Stack (T1 → T28)
//! simulate() integrates: T1, T3, T6, T9, T13, T14, T24
//! Expert endpoints: T8, T15, T16, T25, T26, T27, T28

// Tier 1: Core foundations
pub mod dynamics;
pub mod enforcement;
pub mod information;
#[cfg(feature = "observer")]
pub mod observer;
pub mod reachability;
pub mod types;

// Tier 2: Geometric extensions
pub mod computability;
pub mod geometry;

// Tier 3: Advanced modules
pub mod approximation;
pub mod dominance;
pub mod multiagent;
pub mod pareto;
pub mod temporal;

use std::collections::HashMap;

// CDP Layer: The Compiler & Vibe Schema
pub mod vibe;

use crate::approximation::polytope::MonteCarloVolumeEstimator;
use crate::approximation::PolytopeVolumeEstimator;
pub use vibe::{
    CapabilityMode, ErrorBounds, ExecutionMode, GlobalSensitivityReport, ScenarioCompiler,
    SimulateRequest, SimulationResult, SystemAlert, TimelineStep, TrustLevel, VibeSchema,
};

// Re-export main types for external crates
pub use dominance::{OptimalTrajectory, OptimalTrajectoryEngine};
pub use geometry::{ConstraintPlane, Polytope, Vector};
pub use multiagent::MultiAgentEngine;
pub use pareto::{CompositionAnalysis, ParetoEngine, VectorBudget};
pub use reachability::core::{ReachabilityEngine, ReachableSet};
pub use temporal::TemporalConsistencyChecker;
pub use types::{Cost, State, StateId, StateSpace, Transition};

/// The Universal Entry Point for the Causalor Developer Platform.
///
/// ## Theorem Integration Chain
/// - **T1**: Dijkstra reachability — computes R_B(s₀) at each budget slice
/// - **T3/T6**: Collapse rate κ = log(Ω_t) − log(Ω_{t+1}) per step
/// - **T9**: Optionality Ω = |R_B(s₀)| — the raw count of reachable states
/// - **T13**: Directional distance δ_v(x) — how far from constraint boundary
/// - **T14**: Thickness τ(x) — corridor width orthogonal to motion (flexibility)
/// - **T24**: Temporal consistency — monotonicity + κ additivity verification
///
/// Phase 21: goal detection (goal_reached_at, goal_distance per step)
/// Phase 22: n-D polytope — each schema variable gets its own constraint axis
/// Phase 24: schema validation — bounds, discretization, initial value checks
pub fn simulate(
    schema: VibeSchema,
    budget: Option<f64>,
    capability: CapabilityMode,
) -> SimulationResult {
    use dynamics::collapse::{compute_collapse_rate, Optionality};
    use geometry::{Polytope, Vector};
    use information::critical_decisions::entropy;
    use temporal::TemporalConsistencyChecker;

    // ── Phase 24: Schema Validation (Capability Aware) ───────────────────────
    if let Err(e) = ScenarioCompiler::validate_schema(&schema, &capability) {
        // Return an impossible result with error embedded in recommendation
        return SimulationResult {
            timeline: vec![],
            point_of_no_return: Some(0),
            goal_reached_at: None,
            recommended_path: None,
            is_approximate: false,
            verdict: "invalid_schema".to_string(),
            recommendation: format!("Schema error: {}", e),
            calculation_mode: ExecutionMode::Discrete,
            trust_level: TrustLevel::High,
            error_bounds: ErrorBounds {
                epsilon: 0.0,
                confidence: 1.0,
            },
            alerts: vec![],
            sensitivity_report: None,
        };
    }

    // ── Phase 38: Complexity Oracle & Mode Selection ───────────────────────
    let potential = ScenarioCompiler::estimate_complexity(&schema);
    let base_mode = if potential < 5000.0 {
        ExecutionMode::Discrete
    } else if potential < 100000.0 {
        ExecutionMode::Hybrid
    } else {
        ExecutionMode::Continuous
    };

    // Enforcement: Lite mode refuses Discrete/Hybrid for complexity > 5000 (T21 mandatory)
    let calculation_mode = if capability == CapabilityMode::Lite && potential > 5000.0 {
        ExecutionMode::Continuous
    } else {
        base_mode
    };

    let (mut trust_level, mut error_bounds) = match calculation_mode {
        ExecutionMode::Discrete => (
            TrustLevel::High,
            ErrorBounds {
                epsilon: 0.0,
                confidence: 1.0,
            },
        ),
        ExecutionMode::Hybrid => (
            TrustLevel::Medium,
            ErrorBounds {
                epsilon: 0.05,
                confidence: 0.99,
            },
        ),
        ExecutionMode::Continuous => (
            TrustLevel::Low,
            ErrorBounds {
                epsilon: 0.15,
                confidence: 0.95,
            },
        ),
    };

    let is_approximate = calculation_mode == ExecutionMode::Continuous || potential > 1e6;

    let mut alerts = Vec::new();

    // ── Phase 39: Computability Audit (T20c) ──────────────────────────────────
    let mut has_negative_costs = false;
    for action in &schema.actions {
        for cost in action.cost.values() {
            if *cost < 0.0 {
                has_negative_costs = true;
                break;
            }
        }
        if has_negative_costs {
            break;
        }
    }

    let analysis = computability::ComputabilityAnalysis::analyze(
        Some(potential as usize),
        has_negative_costs,
        false, // Non-additive costs not yet modeled in schema
    );

    if !analysis.is_sound() {
        for violation in &analysis.assumption_violations {
            alerts.push(SystemAlert {
                r#type: "unsound_system".to_string(),
                message: violation.assumption.clone(),
                detail: Some(violation.details.clone()),
            });
        }
    }

    if calculation_mode != ExecutionMode::Discrete {
        alerts.push(SystemAlert {
            r#type: "high_complexity".to_string(),
            message: "Performance Scaling Activated: Transitioning to geometric volume estimation (T21).".to_string(),
            detail: Some(format!(
                "Complexity score ({:.1}) exceeds discrete threshold (5000). Switched to {:?} mode to preserve strategic intelligence performance.",
                potential, calculation_mode
            )),
        });
    }

    let compiler = ScenarioCompiler::new();
    let space = compiler.compile(&schema);

    let initial_attr = compiler.get_initial_attributes(&schema);
    let initial_state_id = compiler.hash_state(&initial_attr);

    // Resolve budget: explicit → resources["capital"] → ∞
    let resolved_budget = budget.unwrap_or_else(|| {
        schema
            .resources
            .values()
            .next() // Use first resource as primary budget anchor for now
            .map(|r| r.initial)
            .unwrap_or(f64::INFINITY)
    });

    let horizon = schema.time.horizon;

    // ── Phase 22: n-D Polytope — per-variable constraint planes ──────────────
    // Each variable gets a pair of axis-aligned planes: min and max bounds.
    // Schema constraints add additional planes on the corresponding variable axis.
    let var_names: Vec<&str> = {
        let mut names: Vec<&str> = schema.variables.keys().map(|s| s.as_str()).collect();
        names.sort(); // deterministic ordering
        names
    };
    let n_vars = var_names.len().max(1);

    let mut polytope = Polytope::new();

    // Build per-variable bound planes (axis-aligned)
    for (i, name) in var_names.iter().enumerate() {
        if let Some(var) = schema.variables.get(*name) {
            let mut lo_normal = vec![0.0; n_vars];
            let mut hi_normal = vec![0.0; n_vars];
            lo_normal[i] = -1.0; // -x_i ≤ -min ↔ x_i ≥ min
            hi_normal[i] = 1.0; //  x_i ≤ max

            let lo = var.min.unwrap_or(0.0);
            let hi = var.max.unwrap_or(1e6);
            polytope.add_constraint(Vector(lo_normal), -lo);
            polytope.add_constraint(Vector(hi_normal), hi);
        }
    }

    // Add schema constraints as additional planes on the variable's axis
    for constraint in &schema.constraints {
        if let Some(idx) = var_names
            .iter()
            .position(|&n| n == constraint.variable.as_str())
        {
            if let (Some(val), Some(op)) = (constraint.value, &constraint.operator) {
                use vibe::schema::Operator;
                let (sign, bound) = match op {
                    Operator::Lte | Operator::Lt => (1.0_f64, val),
                    Operator::Gte | Operator::Gt => (-1.0_f64, -val),
                    Operator::Eq => (1.0_f64, val),
                };
                let mut normal = vec![0.0; n_vars];
                normal[idx] = sign;
                polytope.add_constraint(Vector(normal), bound);
            }
        }
    }

    // Motion direction = uniform across all variable dimensions (normalized)
    let motion_dir = Vector(vec![1.0 / (n_vars as f64).sqrt(); n_vars]);
    // Center point at midpoint of variable ranges
    let center_vals: Vec<f64> = var_names
        .iter()
        .map(|name| {
            schema
                .variables
                .get(*name)
                .map(|v| {
                    let lo = v.min.unwrap_or(0.0);
                    let hi = v.max.unwrap_or(1.0);
                    (lo + hi) / 2.0
                })
                .unwrap_or(0.5)
        })
        .collect();
    let center_pt = Vector(center_vals);

    // ── T1: Compute reachable set at full budget ──────────────────────────────
    let engine = reachability::core::ReachabilityEngine::new(space.clone());
    let full_reachable = engine.compute_reachable_set(&initial_state_id, resolved_budget);
    let full_omega = full_reachable.optionality();

    // ── T24: Temporal consistency checker ─────────────────────────────────────
    let mut temporal = TemporalConsistencyChecker::new();

    // ── Phase 21: Goal detection setup ────────────────────────────────────────
    let mut goal_reached_at: Option<usize> = None;
    let initial_goal_progress = compiler.goal_progress(&initial_attr, &schema);

    // ── T14/T13: Pre-compute base thickness & risk for the polytope ───────────
    let base_thickness = polytope.estimate_directional_thickness(&center_pt, &motion_dir);
    let base_kappa_spike = polytope.predict_kappa_spike(&center_pt, &motion_dir);

    // ── T28: Compute Optimal Trajectory (Max-Bottleneck Path) ─────────────────
    // π* = argmax_π min_{t ∈ π} Ω(s(t))
    // This finds the path that stays in the "widest" part of the future.
    let reachable_states = &full_reachable.states;
    let mut target_states = std::collections::HashSet::new();
    for state_id in reachable_states {
        if let Some(state) = space.states.get(state_id) {
            if compiler.is_goal_reached(state, &schema) {
                target_states.insert(state_id.clone());
            }
        }
    }

    let optimal_trajectory = if !target_states.is_empty() && capability == CapabilityMode::Full {
        let traj = OptimalTrajectoryEngine::max_bottleneck_path(
            &space,
            &initial_state_id,
            &target_states,
            resolved_budget,
            |sid| {
                engine
                    .compute_reachable_set(sid, resolved_budget)
                    .optionality() as f64
            },
        );
        if traj.reaches_target {
            Some(traj)
        } else {
            None
        }
    } else {
        None
    };

    let recommended_path_ids: Vec<String> = optimal_trajectory
        .as_ref()
        .map(|t| t.path.to_vec())
        .unwrap_or_default();

    // ── Phase 42: Continuous Estimator Setup (T21) ───────────────────────────
    let mut variable_bounds = HashMap::new();
    let mut discretization_factors = HashMap::new();
    for (name, var) in &schema.variables {
        let min = var.min.unwrap_or(0.0);
        let max = var
            .max
            .unwrap_or(vibe::schema::VariableType::Float.default_max()); // Use schema logic
        variable_bounds.insert(name.clone(), (min, max));
        discretization_factors.insert(name.clone(), var.discretization);
    }

    let continuous_estimator = if calculation_mode == ExecutionMode::Continuous {
        Some(MonteCarloVolumeEstimator::new(
            polytope.constraints.clone(),
            variable_bounds,
            discretization_factors,
        ))
    } else {
        None
    };

    // ── Timeline: compute per-step Ω, κ, τ, goal_distance ───────────────────
    let mut timeline = Vec::new();
    let mut point_of_no_return: Option<usize> = None;
    let mut prev_omega = full_omega as f64;
    let mut culprit_freqs: HashMap<String, usize> = HashMap::new();
    let mut total_thickness: f64 = 0.0;
    let mut peak_fragility: f64 = 0.0;

    for t in 0..=horizon {
        // T1: budget drains linearly over the horizon
        let budget_fraction = if horizon > 0 {
            t as f64 / horizon as f64
        } else {
            0.0
        };
        let step_budget = if resolved_budget.is_infinite() {
            f64::INFINITY
        } else {
            resolved_budget * (1.0 - budget_fraction)
        };

        // T9: Ω at this time step
        let (step_omega, step_bounds, step_trust) = if step_budget <= 0.0 {
            (
                0,
                ErrorBounds {
                    epsilon: 0.0,
                    confidence: 1.0,
                },
                TrustLevel::High,
            )
        } else if let Some(ref estimator) = continuous_estimator {
            // Continuous T21 Path
            let (omega, bounds, trust) = estimator.estimate_volume(10000);
            (omega as usize, bounds, trust)
        } else {
            // Discrete Path
            let omega = engine
                .compute_reachable_set(&initial_state_id, step_budget)
                .optionality();
            (
                omega,
                ErrorBounds {
                    epsilon: 0.0,
                    confidence: 1.0,
                },
                TrustLevel::High,
            )
        };

        // Update global trust/bounds (pessimistic aggregation)
        if (step_trust.clone() as i32) < (trust_level.clone() as i32) {
            trust_level = step_trust;
        }
        error_bounds.epsilon = error_bounds.epsilon.max(step_bounds.epsilon);
        error_bounds.confidence = error_bounds.confidence.min(step_bounds.confidence);

        // T24: record for monotonicity + additivity validation
        temporal.record(t, step_omega as f64);

        // T3/T6: Collapse rate κ = ln(Ω_prev) − ln(Ω_curr)
        let curr_opt = Optionality(step_omega as f64);
        let prev_opt = Optionality(prev_omega);
        let kappa = compute_collapse_rate(prev_opt, curr_opt);

        // T14: Geometric flexibility = directional thickness τ(x), scaled by Ω fraction
        let omega_fraction = if full_omega > 0 {
            step_omega as f64 / full_omega as f64
        } else {
            0.0
        };
        let thickness = if base_thickness.is_finite() {
            (base_thickness * omega_fraction).max(0.0)
        } else {
            omega_fraction
        };

        total_thickness += thickness;

        // T13.3: Risk spike = κ_geom × κ_discrete
        let risk_spike = if kappa.0.is_finite() && kappa.0 > 0.0 {
            (base_kappa_spike * kappa.0.min(10.0)).min(100.0)
        } else {
            0.0
        };

        // Point-of-no-return: first t where Ω drops to 0
        if step_omega == 0 && point_of_no_return.is_none() {
            point_of_no_return = Some(t);
        }

        // T4/T28: Goal distance & progress tracking
        let (goal_dist, reached) = if let Some(ref traj) = optimal_trajectory {
            if let Some(state_id) = traj.path.get(t) {
                if let Some(state) = engine.state_space.states.get(state_id) {
                    let progress = compiler.goal_progress(&state.attributes, &schema);
                    (progress, progress >= 1.0)
                } else {
                    (initial_goal_progress, initial_goal_progress >= 1.0)
                }
            } else {
                (initial_goal_progress, initial_goal_progress >= 1.0)
            }
        } else {
            (initial_goal_progress, initial_goal_progress >= 1.0)
        };

        if reached && goal_reached_at.is_none() {
            goal_reached_at = Some(t);
        }

        // T28: Check if this step is on the recommended path
        // (Simplified: we use index-based matching for discrete time)
        let is_on_recommended_path = optimal_trajectory
            .as_ref()
            .map(|traj| t < traj.path.len())
            .unwrap_or(false);

        let status = match step_omega {
            0 => "collapsed",
            1..=5 => "critical",
            6..=20 => "narrowing",
            _ => "safe",
        }
        .to_string();

        // T17: Structural entropy
        let step_entropy = entropy(Optionality(step_omega as f64));

        // T18: Sensitivity / Root Cause Analysis
        // We look for the variable whose axis-aligned boundary is closest to the center point.
        let mut dominant_root_cause: Option<String> = None;
        if step_omega < full_omega {
            let mut min_dist = f64::INFINITY;
            for (i, name) in var_names.iter().enumerate() {
                // Approximate distance to variable i's specific constraints
                for plane in &polytope.constraints {
                    if plane.normal.0[i].abs() > 0.9 {
                        // Primarily axis-aligned to variable i
                        let dist =
                            (plane.bound - plane.normal.dot(&center_pt)) / plane.normal.magnitude();
                        if dist < min_dist {
                            min_dist = dist;
                            dominant_root_cause = Some(name.to_string());
                        }
                    }
                }
            }
        }

        if let Some(ref cause) = dominant_root_cause {
            *culprit_freqs.entry(cause.clone()).or_insert(0) += 1;
        }
        peak_fragility = peak_fragility.max(risk_spike);

        timeline.push(TimelineStep {
            t,
            future_width: step_omega,
            thickness,
            risk_spike,
            goal_distance: goal_dist,
            is_on_recommended_path,
            entropy: step_entropy.0,
            dominant_root_cause,
            status,
        });

        prev_omega = step_omega as f64;
    }

    let mean_thickness = if horizon > 0 {
        total_thickness / (horizon + 1) as f64
    } else {
        total_thickness
    };

    let sensitivity_report = Some(GlobalSensitivityReport {
        primary_culprits: culprit_freqs,
        mean_thickness,
        peak_fragility,
    });

    // ── T24: Run full consistency report ──────────────────────────────────────
    let consistency = temporal.full_report();
    let temporal_warning = if !consistency.is_consistent {
        alerts.push(SystemAlert {
            r#type: "temporal_inconsistency".to_string(),
            message: "Monotonicity violation detected in simulation timeline.".to_string(),
            detail: Some(format!(
                "Found {} structural inconsistencies (T24).",
                consistency.monotonicity_violations.len()
            )),
        });
        format!(
            " [T24 ALERT: {} monotonicity violation(s) detected]",
            consistency.monotonicity_violations.len()
        )
    } else {
        String::new()
    };

    // ── Verdict & Recommendation ───────────────────────────────────────────────
    let verdict = if full_omega > 0 {
        "possible"
    } else {
        "impossible"
    };

    let recommendation = match full_omega {
        0 => "Goal is structurally unreachable. Expand action space or relax constraints.",
        1..=5 => "Critically constrained — narrow corridor detected (T14). Urgent: reduce scope or add resources.",
        6..=20 => "Low optionality. Recommend diversifying available actions (T9 < threshold).",
        _ => "Trajectory is stable. Maintain current action plan.",
    };

    SimulationResult {
        timeline,
        point_of_no_return,
        goal_reached_at,
        recommended_path: if recommended_path_ids.is_empty() {
            None
        } else {
            Some(recommended_path_ids)
        },
        is_approximate,
        verdict: format!("{}{}", verdict, temporal_warning),
        recommendation: recommendation.to_string(),
        calculation_mode,
        trust_level,
        error_bounds,
        alerts,
        sensitivity_report,
    }
}
