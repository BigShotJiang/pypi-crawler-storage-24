use crate::types::*;
use crate::reachability::core::{ReachabilityEngine, ReachableSet};
use std::collections::HashSet;

/// Theorem 4: Irreversibility Detection
pub struct IrreversibilityAnalyzer {
    engine: ReachabilityEngine,
}

impl IrreversibilityAnalyzer {
    pub fn new(state_space: StateSpace) -> Self {
        IrreversibilityAnalyzer {
            engine: ReachabilityEngine::new(state_space),
        }
    }
    
    /// Theorem 4: Check if target set is unreachable
    /// 
    /// G is unreachable iff R_B(s₀) ∩ G = ∅
    pub fn is_unreachable(
        &self,
        start: &StateId,
        budget: Budget,
        target_set: &HashSet<StateId>,
    ) -> bool {
        let reachable = self.engine.compute_reachable_set(start, budget);
        reachable.states.is_disjoint(target_set)
    }
    
    /// Find all unreachable targets from a list
    pub fn find_unreachable(
        &self,
        start: &StateId,
        budget: Budget,
        targets: &[StateId],
    ) -> Vec<UnreachableTarget> {
        let reachable = self.engine.compute_reachable_set(start, budget);
        
        targets
            .iter()
            .filter(|t| !reachable.is_reachable(t))
            .map(|t| UnreachableTarget {
                target: t.clone(),
                reason: UnreachableReason::StructuralDisconnection,
            })
            .collect()
    }
}

#[derive(Debug, Clone)]
pub struct UnreachableTarget {
    pub target: StateId,
    pub reason: UnreachableReason,
}

#[derive(Debug, Clone)]
pub enum UnreachableReason {
    StructuralDisconnection,
    InsufficientBudget,
}

/// Theorem 5: Point of No Return
pub struct DisconnectionAnalyzer {
    engine: ReachabilityEngine,
}

impl DisconnectionAnalyzer {
    pub fn new(state_space: StateSpace) -> Self {
        DisconnectionAnalyzer {
            engine: ReachabilityEngine::new(state_space),
        }
    }
    
    /// Theorem 5: Find disconnection time
    /// 
    /// t* = sup{t | G ∩ R_B(s(t)) ≠ ∅}
    pub fn find_disconnection_time(
        &self,
        trajectory: &[StateId],
        budget: Budget,
        target: &StateId,
    ) -> DisconnectionResult {
        let mut last_reachable_time = None;
        
        for (t, state) in trajectory.iter().enumerate() {
            let reachable = self.engine.compute_reachable_set(state, budget);
            
            if reachable.is_reachable(target) {
                last_reachable_time = Some(t);
            } else if last_reachable_time.is_some() {
                // Found disconnection point
                return DisconnectionResult::Disconnected(DisconnectionEvent {
                    target: target.clone(),
                    last_reachable_time: last_reachable_time.unwrap(),
                    first_unreachable_time: t,
                    last_reachable_state: trajectory[last_reachable_time.unwrap()].clone(),
                    first_unreachable_state: state.clone(),
                });
            }
        }
        
        match last_reachable_time {
            None => DisconnectionResult::NeverReachable,
            Some(t) => DisconnectionResult::StillReachable(t),
        }
    }
    
    /// Find all disconnection events for multiple targets
    pub fn find_all_disconnections(
        &self,
        trajectory: &[StateId],
        budget: Budget,
        targets: &[StateId],
    ) -> Vec<DisconnectionEvent> {
        targets
            .iter()
            .filter_map(|target| {
                match self.find_disconnection_time(trajectory, budget, target) {
                    DisconnectionResult::Disconnected(event) => Some(event),
                    _ => None,
                }
            })
            .collect()
    }
}

#[derive(Debug, Clone)]
pub enum DisconnectionResult {
    NeverReachable,
    StillReachable(usize),
    Disconnected(DisconnectionEvent),
}

#[derive(Debug, Clone)]
pub struct DisconnectionEvent {
    pub target: StateId,
    pub last_reachable_time: usize,
    pub first_unreachable_time: usize,
    pub last_reachable_state: StateId,
    pub first_unreachable_state: StateId,
}

impl DisconnectionEvent {
    /// Human-readable description
    pub fn describe(&self) -> String {
        format!(
            "{} became unreachable at step {} (was reachable until step {})",
            self.target,
            self.first_unreachable_time,
            self.last_reachable_time
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_theorem_4_structural_disconnection() {
        // Graph: A -> B -> C    (D is disconnected)
        let mut space = StateSpace::new();
        
        for id in &["A", "B", "C", "D"] {
            space.add_state(State {
                id: id.to_string(),
                attributes: HashMap::new(),
            });
        }
        
        space.add_transition(Transition {
            from: "A".into(),
            to: "B".into(),
            cost: 5.0,
            metadata: None,
        });
        
        space.add_transition(Transition {
            from: "B".into(),
            to: "C".into(),
            cost: 5.0,
            metadata: None,
        });
        
        let analyzer = IrreversibilityAnalyzer::new(space);
        
        let target_d: HashSet<_> = vec!["D".into()].into_iter().collect();
        
        // D is structurally unreachable
        assert!(analyzer.is_unreachable(&"A".into(), 1000.0, &target_d));
    }
    
    #[test]
    fn test_theorem_4_budget_unreachability() {
        let mut space = StateSpace::new();
        
        for id in &["A", "B", "C"] {
            space.add_state(State {
                id: id.to_string(),
                attributes: HashMap::new(),
            });
        }
        
        space.add_transition(Transition {
            from: "A".into(),
            to: "B".into(),
            cost: 5.0,
            metadata: None,
        });
        
        space.add_transition(Transition {
            from: "B".into(),
            to: "C".into(),
            cost: 10.0,
            metadata: None,
        });
        
        let analyzer = IrreversibilityAnalyzer::new(space);
        
        let target_c: HashSet<_> = vec!["C".into()].into_iter().collect();
        
        // C is unreachable with budget 10 (need 15)
        assert!(analyzer.is_unreachable(&"A".into(), 10.0, &target_c));
        
        // But reachable with budget 15
        assert!(!analyzer.is_unreachable(&"A".into(), 15.0, &target_c));
    }
    
    #[test]
    fn test_theorem_5_disconnection_detection() {
        // Create trajectory where option is lost
        let mut space = StateSpace::new();
        
        // Will implement with trajectory simulation
    }
}