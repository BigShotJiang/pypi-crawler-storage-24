use crate::dynamics::collapse::Optionality;
use crate::types::*;
use std::cmp::Ordering;
use std::collections::{BinaryHeap, HashMap, HashSet};
use std::sync::RwLock;

/// Theorem 1: Reachable Set Computation
///
/// Computes R_B(s₀) = {s ∈ S | ∃ path π: s₀ → s, Σc(π) ≤ B}
pub struct ReachabilityEngine {
    pub state_space: StateSpace,
    memo: RwLock<HashMap<(StateId, u64), Optionality>>,
}

#[derive(Debug, Clone)]
struct Node {
    cost: Cost,
    state: StateId,
}

impl Eq for Node {}
impl PartialEq for Node {
    fn eq(&self, other: &Self) -> bool {
        self.cost == other.cost && self.state == other.state
    }
}

impl Ord for Node {
    fn cmp(&self, other: &Self) -> Ordering {
        // Reverse for min-heap
        other
            .cost
            .partial_cmp(&self.cost)
            .unwrap_or(Ordering::Equal)
            .then_with(|| self.state.cmp(&other.state))
    }
}

impl PartialOrd for Node {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl ReachabilityEngine {
    pub fn new(state_space: StateSpace) -> Self {
        ReachabilityEngine {
            state_space,
            memo: RwLock::new(HashMap::new()),
        }
    }

    /// Theorem 9: Compute the absolute structural measure of reachable states.
    /// This is strictly memoized to prevent exponential complexity during decision lookaheads.
    pub fn compute_structural_optionality(&self, start: &StateId, budget: Budget) -> Optionality {
        // Rust HashMaps do not support f64 keys natively, mapping via raw bits
        let key = (start.clone(), budget.to_bits());

        if let Ok(guard) = self.memo.read() {
            if let Some(opt) = guard.get(&key) {
                return *opt;
            }
        }

        let reachable = self.compute_reachable_set(start, budget);
        let opt_val = Optionality(reachable.optionality() as f64);

        if let Ok(mut guard) = self.memo.write() {
            guard.insert(key, opt_val);
        }
        opt_val
    }

    /// Core reachability computation (Dijkstra's algorithm)
    ///
    /// # Correctness
    /// See proof in docs/theorems/proofs/theorem_01_reachable_set.md
    ///
    /// # Complexity
    /// - Time: O(|E| + |V| log |V|) with binary heap
    /// - Space: O(|V|)
    pub fn compute_reachable_set(&self, start: &StateId, budget: Budget) -> ReachableSet {
        let graph = self.state_space.build_graph();

        // Distance from start to each state
        let mut distances: HashMap<StateId, Cost> = HashMap::new();
        distances.insert(start.clone(), 0.0);

        // Priority queue for Dijkstra
        let mut pq = BinaryHeap::new();
        pq.push(Node {
            cost: 0.0,
            state: start.clone(),
        });

        // Track paths
        let mut paths: HashMap<StateId, Vec<StateId>> = HashMap::new();
        paths.insert(start.clone(), vec![start.clone()]);

        // Dijkstra's algorithm
        while let Some(Node { cost, state }) = pq.pop() {
            // Skip if we've found a better path
            if let Some(&best_cost) = distances.get(&state) {
                if cost > best_cost {
                    continue;
                }
            }

            // Explore neighbors
            if let Some(neighbors) = graph.get(&state) {
                for (next_state, edge_cost) in neighbors {
                    let new_cost = cost + edge_cost;

                    // Only consider if within budget
                    if new_cost <= budget {
                        let is_better = distances
                            .get(next_state)
                            .is_none_or(|&current| new_cost < current);

                        if is_better {
                            distances.insert(next_state.clone(), new_cost);

                            // Track path
                            let mut new_path = paths.get(&state).unwrap().clone();
                            new_path.push(next_state.clone());
                            paths.insert(next_state.clone(), new_path);

                            pq.push(Node {
                                cost: new_cost,
                                state: next_state.clone(),
                            });
                        }
                    }
                }
            }
        }

        ReachableSet {
            states: distances.keys().cloned().collect(),
            distances,
            paths,
            budget,
            start: start.clone(),
        }
    }
}

/// Result of reachability computation
#[derive(Debug, Clone)]
pub struct ReachableSet {
    pub states: HashSet<StateId>,
    pub distances: HashMap<StateId, Cost>,
    pub paths: HashMap<StateId, Vec<StateId>>,
    pub budget: Budget,
    pub start: StateId,
}

impl ReachableSet {
    /// Check if target is reachable (used by Theorem 4)
    pub fn is_reachable(&self, target: &StateId) -> bool {
        self.states.contains(target)
    }

    /// Get minimum cost to reach target
    pub fn cost_to(&self, target: &StateId) -> Option<Cost> {
        self.distances.get(target).copied()
    }

    /// Get path to target (if reachable)
    pub fn path_to(&self, target: &StateId) -> Option<&Vec<StateId>> {
        self.paths.get(target)
    }

    /// Theorem 9: Optionality measure
    pub fn optionality(&self) -> usize {
        self.states.len()
    }

    /// Get all reachable states as sorted vector
    pub fn reachable_states(&self) -> Vec<StateId> {
        let mut states: Vec<_> = self.states.iter().cloned().collect();
        states.sort();
        states
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn create_simple_graph() -> StateSpace {
        let mut space = StateSpace::new();

        space.add_state(State {
            id: "A".into(),
            attributes: HashMap::new(),
        });
        space.add_state(State {
            id: "B".into(),
            attributes: HashMap::new(),
        });
        space.add_state(State {
            id: "C".into(),
            attributes: HashMap::new(),
        });
        space.add_state(State {
            id: "D".into(),
            attributes: HashMap::new(),
        });

        space.add_transition(Transition {
            from: "A".into(),
            to: "B".into(),
            cost: 5.0,
            metadata: None,
        });

        space.add_transition(Transition {
            from: "B".into(),
            to: "C".into(),
            cost: 3.0,
            metadata: None,
        });

        space.add_transition(Transition {
            from: "A".into(),
            to: "D".into(),
            cost: 10.0,
            metadata: None,
        });

        space
    }

    #[test]
    fn test_theorem_1_basic_reachability() {
        // Example from proof document
        let space = create_simple_graph();
        let engine = ReachabilityEngine::new(space);

        // Budget 7: should reach A, B but not C (8) or D (10)
        let reachable = engine.compute_reachable_set(&"A".into(), 7.0);

        assert!(reachable.is_reachable(&"A".into()));
        assert!(reachable.is_reachable(&"B".into()));
        assert!(!reachable.is_reachable(&"C".into()));
        assert!(!reachable.is_reachable(&"D".into()));

        assert_eq!(reachable.optionality(), 2);
    }

    #[test]
    fn test_theorem_1_with_sufficient_budget() {
        let space = create_simple_graph();
        let engine = ReachabilityEngine::new(space);

        // Budget 10: should reach all states
        let reachable = engine.compute_reachable_set(&"A".into(), 10.0);

        assert!(reachable.is_reachable(&"A".into()));
        assert!(reachable.is_reachable(&"B".into()));
        assert!(reachable.is_reachable(&"C".into()));
        assert!(reachable.is_reachable(&"D".into()));

        assert_eq!(reachable.optionality(), 4);
    }

    #[test]
    fn test_corollary_1_1_reflexivity() {
        // Corollary 1.1: s₀ ∈ R_B(s₀) for any B ≥ 0
        let space = create_simple_graph();
        let engine = ReachabilityEngine::new(space);

        let reachable = engine.compute_reachable_set(&"A".into(), 0.0);
        assert!(reachable.is_reachable(&"A".into()));
        assert_eq!(reachable.optionality(), 1);
    }

    #[test]
    fn test_path_reconstruction() {
        let space = create_simple_graph();
        let engine = ReachabilityEngine::new(space);

        let reachable = engine.compute_reachable_set(&"A".into(), 10.0);

        // Path to C should be A -> B -> C
        let path_to_c = reachable.path_to(&"C".into()).unwrap();
        assert_eq!(path_to_c, &vec!["A", "B", "C"]);

        // Cost should be 8
        assert_eq!(reachable.cost_to(&"C".into()), Some(8.0));
    }
}
