pub mod polytope;
use crate::vibe::schema::{ErrorBounds, TrustLevel};

/// T21: Point-in-Polytope Volume Estimation.
///
/// Estimates the count of reachable states (Ω) by calculating the volume
/// of an n-dimensional polytope defined by budget and system constraints.
pub trait PolytopeVolumeEstimator {
    /// Estimates volume (Ω) and returns error metrics (T22).
    fn estimate_volume(&self, num_samples: usize) -> (f64, ErrorBounds, TrustLevel);
}

/// T22: Epistemic Trust Oracle.
///
/// Calculates TrustLevel and ErrorBounds based on sampling variance
/// and relative error magnitude.
pub struct TrustOracle;

impl TrustOracle {
    pub fn evaluate(
        hat_omega: f64,
        inside_count: usize,
        total_samples: usize,
        box_volume: f64,
    ) -> (ErrorBounds, TrustLevel) {
        if total_samples == 0 {
            return (
                ErrorBounds {
                    epsilon: 0.0,
                    confidence: 0.0,
                },
                TrustLevel::Low,
            );
        }

        let p_hat = inside_count as f64 / total_samples as f64;

        // Bernoulli standard error: sqrt(p(1-p)/n)
        let se = (p_hat * (1.0 - p_hat) / total_samples as f64).sqrt();

        // 95% confidence interval (z=1.96)
        let epsilon = 1.96 * se * box_volume;
        let relative_error = if hat_omega > 0.0 {
            epsilon / hat_omega
        } else {
            1.0
        };

        let trust_level = if relative_error < 0.05 {
            TrustLevel::High
        } else if relative_error < 0.25 {
            TrustLevel::Medium
        } else {
            TrustLevel::Low
        };

        (
            ErrorBounds {
                epsilon,
                confidence: 0.95,
            },
            trust_level,
        )
    }
}
