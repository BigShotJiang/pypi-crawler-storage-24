use crate::information::critical_decisions::DecisionMetrics;
use crate::types::StateId;

pub struct PolicyEnforcer {
    pub epsilon: f64,
}

#[derive(Debug, Clone)]
pub enum EnforcementResult {
    Allowed(StateId),
    CriticalViolation {
        state: StateId,
        kappa: f64,
        impact_ratio: f64,
    },
}

impl PolicyEnforcer {
    pub fn new(epsilon: f64) -> Self {
        Self { epsilon }
    }

    pub fn enforce(
        &self,
        _current: &StateId,
        transitions: Vec<DecisionMetrics>,
    ) -> Vec<EnforcementResult> {
        transitions
            .into_iter()
            .map(|m| {
                if m.kappa.0 == f64::INFINITY || m.impact_ratio >= self.epsilon {
                    EnforcementResult::CriticalViolation {
                        state: m.next_state,
                        kappa: m.kappa.0,
                        impact_ratio: m.impact_ratio,
                    }
                } else {
                    EnforcementResult::Allowed(m.next_state)
                }
            })
            .collect()
    }
}
