use std::f64;

/// A strict semantic type representing the Optionality ($\Omega$) of a state.
/// CRITICAL INVARIANT: $\Omega$ strictly equals the *count of valid goal paths* ($|V_G|$).
/// It is NEVER a probabilistic weight. It represents pure, unweighted structural capacity.
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd)]
pub struct Optionality(pub f64);

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd)]
pub struct Entropy(pub f64);

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd)]
pub struct CollapseRate(pub f64);

#[derive(Debug, Clone, PartialEq)]
pub enum CollapseEvent {
    Plateau,
    WeakDecay(f64),
    StrongDecay(f64),
    Terminal,
}

pub fn safe_log2(x: f64) -> f64 {
    if x <= 0.0 {
        f64::NEG_INFINITY
    } else {
        x.log2()
    }
}

pub fn compute_collapse_rate(omega_curr: Optionality, omega_next: Optionality) -> CollapseRate {
    match (omega_curr.0, omega_next.0) {
        (0.0, _) => CollapseRate(0.0),           // Already collapsed
        (_, 0.0) => CollapseRate(f64::INFINITY), // Terminal disconnection
        (curr, next) => CollapseRate(safe_log2(curr) - safe_log2(next)), // Standard continuous decay log return
    }
}

pub fn delta_entropy(h_curr: Entropy, h_next: Entropy) -> f64 {
    h_next.0 - h_curr.0 // In closed systems, this is guaranteed <= 0
}

pub fn classify_collapse(rate: CollapseRate) -> CollapseEvent {
    if rate.0 == f64::INFINITY {
        return CollapseEvent::Terminal;
    }
    if rate.0 == 0.0 {
        return CollapseEvent::Plateau;
    }
    if rate.0 < 1.0 {
        return CollapseEvent::WeakDecay(rate.0);
    }
    CollapseEvent::StrongDecay(rate.0)
}
