//! Theorem 23: Dynamic State Space Evolution
//!
//! Tracks discovery events (graph expansion), conditional persistence guarantees,
//! and discovery regret for systems with evolving state spaces.

use std::collections::HashMap;

/// A unique identifier for a target set
pub type TargetId = String;
/// A unique identifier for a state
pub type StateId = String;

/// Record of a discovery event — graph expansion at a specific time
#[derive(Debug, Clone)]
pub struct DiscoveryEvent {
    pub time: usize,
    pub new_states: Vec<StateId>,
    pub new_edges: Vec<(StateId, StateId, f64)>,
}

/// Collapse record for a specific target — tracks whether persistence is valid
#[derive(Debug, Clone)]
pub struct CollapseRecord {
    pub collapsed_at: usize,
    pub discovered_since: bool,
}

/// Theorem 23: Dynamic state space with discovery event tracking
#[derive(Debug, Clone)]
pub struct DynamicStateSpace {
    pub discovery_log: Vec<DiscoveryEvent>,
    pub collapsed_targets: HashMap<TargetId, CollapseRecord>,
    pub total_states: usize,
    pub total_edges: usize,
}

impl DynamicStateSpace {
    pub fn new(initial_states: usize, initial_edges: usize) -> Self {
        Self {
            discovery_log: Vec::new(),
            collapsed_targets: HashMap::new(),
            total_states: initial_states,
            total_edges: initial_edges,
        }
    }

    /// Theorem 23.1: Register a discovery event.
    ///
    /// This is the ONLY mechanism by which Ω can increase.
    /// Invalidates all persistence guarantees for collapsed targets.
    pub fn register_discovery(
        &mut self,
        time: usize,
        new_states: Vec<StateId>,
        new_edges: Vec<(StateId, StateId, f64)>,
    ) {
        self.total_states += new_states.len();
        self.total_edges += new_edges.len();

        // T23.2: Mark all collapsed targets as needing re-evaluation
        for record in self.collapsed_targets.values_mut() {
            if record.collapsed_at <= time {
                record.discovered_since = true;
            }
        }

        self.discovery_log.push(DiscoveryEvent {
            time,
            new_states,
            new_edges,
        });
    }

    /// Record that a target has become unreachable (V_G = 0)
    pub fn mark_collapsed(&mut self, target: TargetId, time: usize) {
        self.collapsed_targets.insert(
            target,
            CollapseRecord {
                collapsed_at: time,
                discovered_since: false,
            },
        );
    }

    /// Theorem 23.2: Check if persistence guarantee still holds for a target.
    ///
    /// Returns true if no discovery events have occurred since the target collapsed.
    /// If false, the target must be re-evaluated — the graph has changed.
    pub fn persistence_valid(&self, target: &TargetId) -> bool {
        match self.collapsed_targets.get(target) {
            Some(record) => !record.discovered_since,
            None => true, // Target never collapsed — persistence trivially holds
        }
    }

    /// Theorem 23.3: Compute discovery regret since a given time.
    ///
    /// Returns the total number of new structural elements (states + edges)
    /// discovered since the given time. This is an upper bound on the
    /// optionality that would have been preserved if discovered earlier.
    pub fn discovery_regret(&self, since: usize) -> usize {
        self.discovery_log
            .iter()
            .filter(|e| e.time >= since)
            .map(|e| e.new_states.len() + e.new_edges.len())
            .sum()
    }

    /// Returns the number of discovery events in the log
    pub fn discovery_count(&self) -> usize {
        self.discovery_log.len()
    }

    /// Returns true if any discovery events have occurred
    pub fn has_discoveries(&self) -> bool {
        !self.discovery_log.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn persistence_valid_without_discovery() {
        let mut dss = DynamicStateSpace::new(10, 15);
        dss.mark_collapsed("goal_A".into(), 5);

        // No discovery events — persistence should hold
        assert!(dss.persistence_valid(&"goal_A".into()));
    }

    #[test]
    fn persistence_invalidated_by_discovery() {
        let mut dss = DynamicStateSpace::new(10, 15);
        dss.mark_collapsed("goal_A".into(), 5);

        // Discovery event at time 7 — persistence invalidated
        dss.register_discovery(7, vec!["new_state".into()], vec![]);
        assert!(!dss.persistence_valid(&"goal_A".into()));
    }

    #[test]
    fn regret_accumulates() {
        let mut dss = DynamicStateSpace::new(10, 15);
        dss.register_discovery(3, vec!["s1".into(), "s2".into()], vec![]);
        dss.register_discovery(5, vec!["s3".into()], vec![("s3".into(), "s1".into(), 1.0)]);

        // Regret since time 0: 2 states + 1 state + 1 edge = 4
        assert_eq!(dss.discovery_regret(0), 4);

        // Regret since time 4: 1 state + 1 edge = 2
        assert_eq!(dss.discovery_regret(4), 2);
    }

    #[test]
    fn uncollapsed_target_persistence_trivially_valid() {
        let dss = DynamicStateSpace::new(10, 15);
        assert!(dss.persistence_valid(&"never_collapsed".into()));
    }
}
