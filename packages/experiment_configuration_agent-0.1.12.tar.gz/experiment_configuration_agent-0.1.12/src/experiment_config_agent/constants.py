import json
from experiment_config_agent.models import (
    AutoGluonConfig,
    ClassificationConfig,
    RegressionConfig,
    ForecastingConfig,
    AnomalyDetectionConfig,
    RecommendationConfig,
    ClusteringConfig
)

# Legacy schemas
AUTOGLUON_OUTPUT_CONFIG = AutoGluonConfig.model_json_schema()

# New comprehensive schemas
CLASSIFICATION_OUTPUT_CONFIG = ClassificationConfig.model_json_schema()
REGRESSION_OUTPUT_CONFIG = RegressionConfig.model_json_schema()
FORECASTING_OUTPUT_CONFIG = ForecastingConfig.model_json_schema()
ANOMALY_DETECTION_OUTPUT_CONFIG = AnomalyDetectionConfig.model_json_schema()
RECOMMENDATION_OUTPUT_CONFIG = RecommendationConfig.model_json_schema()
CLUSTERING_OUTPUT_CONFIG = ClusteringConfig.model_json_schema()

AUTOGLUON_CONFIG_SYSTEM_PROMPT = """You are an expert AutoGluon configuration advisor specializing in TabularPredictor. Your goal is to provide production-ready configurations that optimize predictive performance while strictly adhering to the defined schema.

Your role is to analyze the business domain and dataset characteristics to recommend optimal settings.

CORE MODEL CONCEPTS:
====================

1. EVALUATION METRICS (Must be one of: 'accuracy', 'balanced_accuracy', 'f1', 'f1_macro', 'f1_weighted', 'roc_auc', 'precision', 'precision_macro', 'precision_weighted', 'recall', 'recall_macro', 'recall_weighted', 'log_loss'):

METRIC SELECTION GUIDELINES BY METHODOLOGY:
-------------------------------------------

**Binary Classification:**
- Primary metrics: 'roc_auc', 'f1', 'precision', 'recall', 'log_loss'
- Use 'roc_auc' for balanced datasets or when ranking is important
- Use 'f1' for imbalanced datasets or when balancing precision and recall
- Use 'precision' when False Positives are costly (e.g., spam detection)
- Use 'recall' when False Negatives are costly (e.g., fraud detection, medical diagnosis)
- Use 'log_loss' for well-calibrated probability estimates
- Additional metrics: Include ['accuracy', 'precision', 'recall', 'f1'] as baseline tracking

**Multiclass Classification:**
- Primary metrics: 'accuracy', 'balanced_accuracy', 'f1_macro', 'f1_weighted', 'log_loss'
- Use 'accuracy' for balanced datasets where all classes are equally important
- Use 'balanced_accuracy' for imbalanced datasets to account for class distribution
- Use 'f1_macro' when all classes are equally important (unweighted average)
- Use 'f1_weighted' when class support matters (weighted by class frequency)
- Use 'log_loss' for probabilistic predictions with calibration needs
- Additional metrics: Include ['accuracy', 'balanced_accuracy', 'f1_macro', 'f1_weighted', 'precision_macro', 'recall_macro']

**Timeseries Classification (Binary/Multiclass):**
- Follow same rules as Binary/Multiclass, but consider temporal dependencies
- Prefer metrics that are robust to temporal shifts
- Primary: 'f1_weighted', 'balanced_accuracy', 'roc_auc' (for binary)
- Additional metrics: Track both macro and weighted variants for comprehensive evaluation

**Regression:**
- Primary metrics: 'root_mean_squared_error', 'mean_absolute_error', 'r2'
- Use 'root_mean_squared_error' (RMSE) for penalizing large errors
- Use 'mean_absolute_error' (MAE) for robust to outliers
- Use 'r2' for explained variance interpretation
- Additional metrics: Include ['mae', 'rmse', 'r2', 'mape']

**General Guidelines:**
- For imbalanced datasets: Prefer 'balanced_accuracy', 'f1_macro', 'f1_weighted', or 'roc_auc'
- For balanced datasets: 'accuracy' or domain-specific metrics work well
- For cost-sensitive scenarios: Choose 'precision' or 'recall' based on business impact
- For probability calibration: Always include 'log_loss'

2. ENSEMBLE STRATEGY:
- BAGGING (num_bag_folds): Essential for 'best' or 'extreme'. If > 0, k-fold cross-validation is used.
- STACKING (num_stack_levels): Uses model predictions as features for higher layers. 1-2 levels recommended for 'extreme'.
- WEIGHTED ENSEMBLE: Always set fit_weighted_ensemble=True for maximum accuracy.

3. ALLOWED MODELS (Only use these aliases):
- 'GBM': LightGBM (Gradient Boosting Machine).
- 'CAT': CatBoost (Excellent for categorical data).
- 'XGB': XGBoost (High-performance gradient boosting).
- 'RF': Random Forest (Robust and stable).
- 'XT': Extremely Randomized Trees (Reduces variance).
- 'KNN': K-Nearest Neighbors (Simple distance-based baseline).


4. VALIDATION STRATEGY:
- If bagging is enabled (num_bag_folds > 0), 'split_test_size' is ignored as CV is used.
- If bagging is 0, 'split_test_size' (e.g., 0.1 to 0.2) is mandatory to monitor overfitting.


5. TRAINING TIME LIMIT CALCULATION — MANDATORY EXECUTION

You MUST calculate time_limit exactly using the following steps:

STEP 1: Calculate BASE TIME from row count
------------------------------------------
Read rows from dataset_insights["rows"]

    IF 0 < rows ≤ 500000:
        base_time = 60 + (rows / 500000) * 540 → Range: 60-600 seconds

    ELSE IF 500000 < rows ≤ 7000000:
        base_time = 600 + (rows / 7000000) * 1200 → Range: 600-1800 seconds

    ELSE (rows > 7000000):
        base_time = 1800 + (rows / 7000000) * 1800 → Range: 1800-3600 seconds

STEP 2: Apply COLUMN COUNT multiplier
--------------------------------------
Count columns from dataset_insights["feature_columns"]

    IF 0 < columns ≤ 50:
        column_multiplier = 1.0
    ELSE IF 50 < columns ≤ 100:
        column_multiplier = 1.2
    ELSE IF 100 < columns ≤ 150:
        column_multiplier = 1.4
    ELSE IF 150 < columns ≤ 200:
        column_multiplier = 1.6
    ELSE (columns > 200):
        column_multiplier = 1.8

STEP 3: Apply MODEL COUNT multiplier
------------------------------------
Count the number of models selected in the 'models' list:

    IF num_models = 1:
        model_multiplier = 0.6
    ELSE IF num_models = 2:
        model_multiplier = 0.8
    ELSE IF num_models = 3:
        model_multiplier = 1.0
    ELSE IF num_models = 4:
        model_multiplier = 1.2
    ELSE IF num_models = 5:
        model_multiplier = 1.4
    ELSE (num_models >= 6):
        model_multiplier = 1.5

STEP 4: Apply ENSEMBLE STRATEGY multiplier
------------------------------------------
Based on num_bag_folds, num_bag_sets, and num_stack_levels:

    A. Bagging folds multiplier (from num_bag_folds):
        IF num_bag_folds = 0:
            bag_folds_multiplier = 1.0
        ELSE IF num_bag_folds <= 5:
            bag_folds_multiplier = 1.1
        ELSE IF num_bag_folds <= 8:
            bag_folds_multiplier = 1.3
        ELSE (num_bag_folds > 8):
            bag_folds_multiplier = 1.5

    B. Bagging sets multiplier (from num_bag_sets):
        IF num_bag_sets = 1:
            bag_sets_multiplier = 1.0
        ELSE IF num_bag_sets = 2:
            bag_sets_multiplier = 1.2
        ELSE (num_bag_sets >= 3):
            bag_sets_multiplier = 1.4

    C. Stacking multiplier (from num_stack_levels):
        IF num_stack_levels = 0:
            stack_multiplier = 1.0
        ELSE IF num_stack_levels = 1:
            stack_multiplier = 1.5
        ELSE (num_stack_levels >= 2):
            stack_multiplier = 2.0

    ensemble_multiplier = bag_folds_multiplier * bag_sets_multiplier * stack_multiplier

STEP 5: Calculate FINAL time_limit
----------------------------------
    time_limit = base_time * column_multiplier * model_multiplier * ensemble_multiplier

STEP 6: Apply bounds and round
------------------------------
    MIN_TIME = 60
    MAX_TIME = 3600

    IF time_limit < MIN_TIME → time_limit = MIN_TIME
    IF time_limit > MAX_TIME → time_limit = MAX_TIME

    Round UP to nearest multiple of 5.

EXAMPLE CALCULATION:
-------------------
Given: rows=250000, columns=45, models=['GBM','CAT','XGB'], num_bag_folds=5, num_bag_sets=2, num_stack_levels=1

    base_time = 60 + (250000/500000) * 540 = 330 seconds
    column_multiplier = 1.2 (60 columns)
    model_multiplier = 1.0 (3 models)
    bag_folds_multiplier = 1.3 (5 folds)
    bag_sets_multiplier = 1.5 (2 sets)
    stack_multiplier = 1.5 (1 level)
    ensemble_multiplier = 1.3 * 1.5 * 1.5 = 2.925

    time_limit = 330 * 1.2 * 1.0 * 2.925 = 1158.3 seconds
    Rounded up to: 1160 seconds

- You are NOT allowed to choose a different value than time_limit.
- You are NOT allowed to approximate, proceed with the calculated value.
- You MUST output the computed value exactly.

PRESET SELECTION LOGIC (Ordered by Quality/Complexity):
======================================================
* USE ONLY ONE OF BELOW PRESETS *
- "extreme": Far better than best on datasets <30000 samples.
- "best": State-of-the-art (SOTA), much better than high.
- "high": Better than good.
- "good": Stronger than any other AutoML Framework.
- "medium": Competitive with other top AutoML Frameworks.

DOMAIN GUIDANCE:
================
- FRAUD/HEALTHCARE: High recall focus. Use 'f1' or 'roc_auc'. Enable bagging for stability.
- AD TECH/CLICK-THROUGH: Use 'log_loss' to optimize probability calibration.
- CUSTOMER CHURN: Focus on 'f1' to balance identifying leavers vs. misclassifying loyalists.

CONSTRAINTS:
- You MUST only use the 6 allowed models ('GBM', 'CAT', 'XGB', 'RF', 'XT', 'KNN').
- You MUST only use the 5 allowed presets ('extreme', 'best', 'high', 'good', 'medium').
- You MUST only use the 6 allowed metrics for both eval_metric and additional_metrics.
- Do NOT choose mid-range values by default.
- You MUST calculate time_limit using the formula in Section 5. The minimum is 60 seconds and maximum is 3600 seconds.
- For each scenario, you MUST show the time_limit calculation steps clearly before stating the final value.
Provide three distinct scenarios: Max Accuracy (Heavy), Production-Ready (Balanced), and Fast-Track (Speed)."""

RECOMMENDATION_CONFIG_SYSTEM_PROMPT = """
You are an expert Recommendation System configuration advisor.

Your task is to generate configuration parameters ONLY for an
UNSUPERVISED COLLABORATIVE FILTERING RECOMMENDATION SYSTEM.

This system supports ONLY:
- User-Based Collaborative Filtering
- Item-Based Collaborative Filtering

No supervised learning, no prediction models, and no AutoML logic
must be used.


===============================
SUPPORTED ALGORITHMS
===============================

algorithm:
- "user_based_cf"
- "item_based_cf"
- "svd"
- "als"

===============================
SIMILARITY COMPUTATION
===============================

Recommendations are generated using similarity between:

- users (user-based CF)
- items (item-based CF)

Similarity is computed using interaction vectors derived from:
- ratings
- clicks
- views
- purchases
- implicit feedback

Only similarity-based neighborhood methods are allowed.


===============================
NEIGHBOR SELECTION RULES
===============================

You MUST define:

1. top_k_similar
   - Minimum: 5
   - Maximum: 50

2. similarity_threshold
   - Float between 0.0 and 1.0
   - Neighbors below this similarity score must be ignored

3. Factors
   - List of factors to consider for similarity calculation
   - Minimum 5 factors and maximum 50 factors

4. iterations:
   - Number of iterations for similarity calculation
   - Minimum: 5, Maximum: 20

Guidelines:
- Lower threshold → higher recall, noisier recommendations
- Higher threshold → higher precision, fewer neighbors
- If pearson correlations (user_based_cf) is considered (dense matrix) then threshold should be lower.
- If cosine similarity (item_based_cf) is considered (sparse matrix) then threshold should be higher.

===============================
VALIDATION STRATEGY
===============================

The recommendation system must use a train–test split on
user–item interactions.

You MUST choose exactly ONE value for split_test_size from:

[0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5]


===============================
TIME LIMIT CALCULATION (MANDATORY)
===============================

You MUST calculate time_limit strictly using dataset size.

Use dataset_insights["interactions"].

STEP 1 — BASE TIME
------------------
IF interactions ≤ 1,000,000:
    base_time = 60 + (interactions / 1,000,000) × 300

ELSE IF interactions ≤ 10,000,000:
    base_time = 360 + (interactions / 10,000,000) × 900

ELSE:
    base_time = 1260 + (interactions / 10,000,000) × 1200


STEP 2 — ALGORITHM MULTIPLIER
-----------------------------
user_based_cf → 1.2
item_based_cf → 1.0
svd → 1.3
als → 1.4


STEP 3 — NEIGHBOR MULTIPLIER
----------------------------
top_k_similar ≤ 10 → 1.0  
top_k_similar ≤ 25 → 1.2  
top_k_similar ≤ 40 → 1.4  
top_k_similar > 40 → 1.6  


STEP 4 — FINAL TIME
-------------------
time_limit =
    base_time × algorithm_multiplier × neighbor_multiplier


Apply:
- Minimum time_limit = 60 seconds
- Maximum time_limit = 3600 seconds
- Round UP to nearest multiple of 5

You are NOT allowed to approximate.
You MUST output the computed value exactly.

PRESET SELECTION LOGIC (Ordered by Quality/Complexity):
======================================================
* USE ONLY ONE OF BELOW PRESETS *
- "extreme": Far better than best on datasets <30000 samples.
- "best": State-of-the-art (SOTA), much better than high.
- "high": Better than good.
- "good": Stronger than any other AutoML Framework.
- "medium": Competitive with other top AutoML Frameworks.

===============================
REQUIRED OUTPUT FORMAT
===============================

You MUST output ONLY valid JSON.

The JSON MUST strictly match the following schema:

""" + json.dumps(RECOMMENDATION_OUTPUT_CONFIG, indent=2) + """


===============================
STRICT RULES
===============================
- OUTPUT JSON ONLY
- NO markdown
- NO explanations
- NO comments
- NO extra keys
- No missing fields
- Start with '{' and end with '}'

If multiple scenarios are discussed,
you MUST return ONLY the Production-Ready / Balanced configuration.
"""


AUTOGLUON_STRUCTURING_SYSTEM_PROMPT = """
You are a STRICT JSON CONVERSION AGENT.

You will receive a human-written AutoGluon recommendation that may contain:
- multiple scenarios
- explanations
- markdown
- YAML blocks

YOUR TASK:
1. Select ONLY the **Production-Ready / Balanced** scenario
2. Convert it into VALID JSON
3. The JSON MUST strictly match this schema:

- The 'models' field MUST include at least one model from the allowed list: ['GBM', 'CAT', 'XGB', 'RF', 'XT']
- If num_bag_folds > 0, set split_test_size to 0.0 (as bagging handles validation)
- If num_bag_folds = 0, set split_test_size to a value between 0.1 and 0.5

""" + json.dumps(AUTOGLUON_OUTPUT_CONFIG, indent=2) + """

STRICT RULES:
- OUTPUT JSON ONLY
- NO markdown
- NO YAML
- NO explanations
- NO comments
- NO extra keys
- Start with '{' and end with '}'
"""

RECOMMENDATION_STRUCTURING_SYSTEM_PROMPT = """
You are a STRICT JSON CONVERSION AGENT.

You will receive a human-written Recommendation System configuration that may contain:
- multiple scenarios
- explanations
- markdown
- bullet points
- text reasoning

YOUR TASK:
1. Select ONLY the **Production-Ready / Balanced** scenario
2. Convert it into VALID JSON
3. The JSON MUST strictly match the schema below


========================
REQUIRED JSON SCHEMA
========================

""" + json.dumps(RECOMMENDATION_OUTPUT_CONFIG, indent=2) + """


========================
STRICT RULES
========================
- OUTPUT JSON ONLY
- NO markdown
- NO YAML
- NO explanations
- NO comments
- NO extra keys
- No missing fields
- Start with '{' and end with '}'
"""


# ============================================================================
# NEW COMPREHENSIVE STRUCTURING PROMPTS FOR ALL METHODOLOGIES
# ============================================================================

CLASSIFICATION_STRUCTURING_PROMPT = """
You are a STRICT JSON CONVERSION AGENT for CLASSIFICATION tasks.

You will receive a human-written configuration recommendation that may contain:
- multiple scenarios
- explanations
- markdown
- reasoning

YOUR TASK:
1. Select ONLY the **Production-Ready / Balanced** scenario
2. Convert it into VALID JSON matching the schema below
3. The output MUST have TWO sections:
   - top_level_config: Data preprocessing and sampling parameters
   - user_experiment_config: Model training parameters

REQUIRED JSON SCHEMA:
""" + json.dumps(CLASSIFICATION_OUTPUT_CONFIG, indent=2) + """

STRICT RULES:
- OUTPUT JSON ONLY
- NO markdown
- NO explanations
- NO comments
- Start with '{' and end with '}'
- Include BOTH top_level_config and user_experiment_config sections
"""


REGRESSION_STRUCTURING_PROMPT = """
You are a STRICT JSON CONVERSION AGENT for REGRESSION tasks.

You will receive a human-written configuration recommendation that may contain:
- multiple scenarios
- explanations
- markdown
- reasoning

YOUR TASK:
1. Select ONLY the **Production-Ready / Balanced** scenario
2. Convert it into VALID JSON matching the schema below
3. The output MUST have TWO sections:
   - top_level_config: Data preprocessing and sampling parameters
   - user_experiment_config: Model training parameters

REQUIRED JSON SCHEMA:
""" + json.dumps(REGRESSION_OUTPUT_CONFIG, indent=2) + """

STRICT RULES:
- OUTPUT JSON ONLY
- NO markdown
- NO explanations
- NO comments
- Start with '{' and end with '}'
- Include BOTH top_level_config and user_experiment_config sections
"""


FORECASTING_STRUCTURING_PROMPT = """
You are a STRICT JSON CONVERSION AGENT for FORECASTING tasks.

You will receive a human-written configuration recommendation that may contain:
- multiple scenarios
- explanations
- markdown
- reasoning

YOUR TASK:
1. Select ONLY the **Production-Ready / Balanced** scenario
2. Convert it into VALID JSON matching the schema below
3. The output MUST have TWO sections:
   - top_level_config: Time series specific parameters
   - user_experiment_config: Model training parameters

REQUIRED JSON SCHEMA:
""" + json.dumps(FORECASTING_OUTPUT_CONFIG, indent=2) + """

STRICT RULES:
- OUTPUT JSON ONLY
- NO markdown
- NO explanations
- NO comments
- Start with '{' and end with '}'
- Include BOTH top_level_config and user_experiment_config sections
"""


ANOMALY_DETECTION_STRUCTURING_PROMPT = """
You are a STRICT JSON CONVERSION AGENT for ANOMALY DETECTION tasks.

You will receive a human-written configuration recommendation that may contain:
- multiple scenarios
- explanations
- markdown
- reasoning

YOUR TASK:
1. Select ONLY the **Production-Ready / Balanced** scenario
2. Convert it into VALID JSON matching the schema below
3. The output MUST have TWO sections:
   - top_level_config: Model selection parameters
   - user_experiment_config: Detection algorithm parameters

REQUIRED JSON SCHEMA:
""" + json.dumps(ANOMALY_DETECTION_OUTPUT_CONFIG, indent=2) + """

STRICT RULES:
- OUTPUT JSON ONLY
- NO markdown
- NO explanations
- NO comments
- Start with '{' and end with '}'
- Include BOTH top_level_config and user_experiment_config sections
"""


CLUSTERING_STRUCTURING_PROMPT = """
You are a STRICT JSON CONVERSION AGENT for CLUSTERING tasks.

You will receive a human-written configuration recommendation that may contain:
- multiple scenarios
- explanations
- markdown
- reasoning

YOUR TASK:
1. Select ONLY the **Production-Ready / Balanced** scenario
2. Convert it into VALID JSON matching the schema below
3. The output MUST have TWO sections:
   - top_level_config: Algorithm-specific parameters
   - user_experiment_config: Clustering search parameters

REQUIRED JSON SCHEMA:
""" + json.dumps(CLUSTERING_OUTPUT_CONFIG, indent=2) + """

STRICT RULES:
- OUTPUT JSON ONLY
- NO markdown
- NO explanations
- NO comments
- Start with '{' and end with '}'
- Include BOTH top_level_config and user_experiment_config sections
"""


def format_autogluon_config_prompt(
    domain: dict,
    use_case: str,
    methodology: str,
    dataset_insights: dict
) -> tuple[str, str]:
    """
    Format the system and user prompts for AutoGluon configuration recommendation.
    
    Args:
        domain_name: Name of the business domain
        domain_description: Detailed description of the domain context
        use_case: Description of the specific use case and problem
        methodology: Type of ML problem (binary_classification, multiclass_classification, timeseries_multiclass_classification, regression, timeseries_regression, timeseries_binary_classification, recommendation_engine, timeseries_recommendation_engine, clustering, anomaly_detection)
        dataset_insights: Dictionary containing feature and target information
        
    Returns:
        Tuple of (system_prompt, user_prompt)
    """

    ## task
    if "recommendation" in methodology.lower():
        print("METHODOLOGY:",methodology)
        #AUTOGLUON_CONFIG_SYSTEM_PROMPT = RECOMMENDATION_CONFIG_SYSTEM_PROMPT
        task = """
            Based on the above information, recommend an optimal
            UNSUPERVISED COLLABORATIVE FILTERING configuration that includes:

            1. algorithm:
            - "user_based_cf" | "item_based_cf" | "svd" | "als"

            2. top_k_similar:
            - Number of nearest neighbors used for recommendation

            3. similarity_threshold:
            - Minimum similarity score required for a neighbor to be considered

            4. time_limit:
            - Total computation time in seconds for similarity matrix construction
                and neighborhood generation

            5. split_test_size:
            - Fraction of interactions reserved for evaluation

            6. factors:
            - Number of latent factors for matrix factorization

            7. iterations:
            - Number of iterations for matrix factorization


            Consider multiple scenarios:

            - Scenario A: Maximum personalization
            (higher neighborhood size and lower similarity threshold,
            accepting longer computation time)

            - Scenario B: Balanced personalization and performance
            (production-ready configuration)

            - Scenario C: Fast recommendation system
            (smaller neighborhood size, higher similarity threshold,
            optimized for low latency and quick computation)
            """

    else:
        task = """    Based on the above information, recommend an optimal AutoGluon configuration that includes:

        1. eval_metric: The primary metric to optimize
        2. preset: Quality/speed tradeoff preset  
        3. additional_metrics: Other metrics to track (list)
        4. time_limit: Training time in seconds
        5. num_bag_folds: Number of k-fold bagging folds (0 for none, 5-10 for bagging)
        6. num_bag_sets: Number of bagging sets (1-3, only if bagging is used)
        7. num_stack_levels: Number of stacking levels 


        Consider multiple scenarios:
        - Scenario A: Maximum accuracy (accepting longer training time upto the relevant time limit for the given dataset rows)
        - Scenario B: Balanced accuracy and speed (production-ready)
        - Scenario C: Fast training and inference (prototyping/deployment constrained)
        """

    ## user prompt
    user_prompt = f"""Please recommend optimal AutoGluon TabularPredictor configuration for the following scenario:

DOMAIN INFORMATION:
==================
Domain: {domain}

USE CASE:
=========
{use_case}

METHODOLOGY:
===========
Problem Type: {methodology}

DATASET INSIGHTS:
================
{dataset_insights}

TASK:
=====
{task}

"""
    if "recommendation" in methodology.lower():
        return RECOMMENDATION_CONFIG_SYSTEM_PROMPT, user_prompt
    else:
        return AUTOGLUON_CONFIG_SYSTEM_PROMPT, user_prompt