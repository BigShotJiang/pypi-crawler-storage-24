@test @navegacion
Feature: Navegación Simple con Framework
  Como usuario del framework
  Quiero navegar a una página web
  Para verificar que el framework funciona correctamente

  @smoke
  Scenario: Abrir página de ejemplo
    Given voy a la url "https://example.com"
    Then the page title should be "Example Domain"
    And I should see text "Example Domain"

  @smoke  
  Scenario: Verificar httpbin
    Given voy a la url "https://httpbin.org"
    Then the page title should be "httpbin.org"
    And I should see text "httpbin"