@ocr @test
Feature: Funcionalidad OCR del Framework
  Como usuario del framework
  Quiero usar OCR para extraer y validar texto de imágenes
  Para automatizar pruebas que requieren reconocimiento de texto

  @smoke @ocr_basic
  Scenario: Prueba básica de OCR con screenshot
    Given voy a la url "https://example.com"
    When tomo una captura de pantalla con nombre "ocr_test_basic"
    And extraigo texto del screenshot "ocr_test_basic" usando OCR
    Then debería encontrar el texto "Example Domain" en los resultados OCR