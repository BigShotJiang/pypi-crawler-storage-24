@test @basico
Feature: Test de Navegación Básica
  Automatización de pruebas para Test de Navegación Básica

  @smoke @navegacion
  Scenario: Abrir página web
    Verificar que se puede abrir una página web correctamente
    Given que abro el navegador
    When navego a 'https://example.com'
    Then debería ver el título de la página
