# language: es

@no_browser
Característica: Testing de RAG con Supabase Vector y Gemini como Juez
  Como QA Engineer
  Quiero validar un sistema RAG que usa Supabase Vector
  Para asegurar que las respuestas están basadas en el contexto correcto

  Antecedentes:
    Given me conecto a Supabase usando variables de entorno
    # NOTA: Ya NO es necesario cargar contexto desde archivo .txt
    # El contexto se carga automáticamente desde Supabase al buscar

  # ============================================================================
  # ESCENARIO 1: RAG Básico - Buscar contexto y validar respuesta
  # ============================================================================
  @test1
  Escenario: Validar respuesta de chatbot usando contexto de Supabase
    # 1. Buscar contexto relevante en Supabase (se carga automáticamente en Gemini)
    When busco en la tabla "knowledge_base" el contexto más similar a "política de devoluciones" y lo guardo en "rag_context"
    
    # 2. Validar con Gemini usando validación directa (pregunta + respuesta en un paso)
    # NOTA: Ya NO necesitas "establezco la respuesta del SUT" si usas validación directa
    Then valido con Gemini que según el contexto para la pregunta "¿Cuál es la política de devoluciones?" la respuesta "Puedes devolver productos dentro de 30 días con recibo. El reembolso se procesa en 5-7 días hábiles." es válida con umbral 0.8

  # ============================================================================
  # ESCENARIO 2: RAG con Múltiples Documentos
  # ============================================================================
  @test2
  Escenario: Validar respuesta usando múltiples documentos de Supabase
    # Buscar los 3 documentos más relevantes (se cargan automáticamente en Gemini)
    When busco en la tabla "knowledge_base" los 3 contextos más similares a "horarios de atención y contacto" y los guardo en "rag_documents"
    
    # Validar con Gemini usando validación directa
    Then valido con Gemini que según el contexto para la pregunta "¿Cuál es el horario de atención?" la respuesta "Nuestro horario es Lunes a Viernes 9am-6pm. Puedes contactarnos por teléfono al 555-1234 o email a soporte@empresa.com" es válida con umbral 0.85

  # ============================================================================
  # ESCENARIO 3: RAG + Validación Directa (Un solo paso)
  # ============================================================================
  Escenario: Validación directa de pregunta-respuesta con contexto de Supabase
    # Buscar contexto
    When busco en la tabla "knowledge_base" el contexto más similar a "garantía de productos" y lo guardo en "rag_context"
    
    # Validar pregunta y respuesta en un solo paso
    Then valido con Gemini que según el contexto para la pregunta "¿Cuánto dura la garantía?" la respuesta "Todos los productos tienen garantía de 1 año contra defectos de fabricación" es válida con umbral 0.8

  # ============================================================================
  # ESCENARIO 4: RAG con Carga Directa a Gemini (RECOMENDADO)
  # ============================================================================
  Escenario: Cargar contexto de Supabase directamente en Gemini
    # Buscar y cargar contexto en Gemini en un solo paso
    # NOTA: Este paso carga el contexto de Supabase directamente en Gemini
    When cargo el contexto de Supabase tabla "knowledge_base" para la query "políticas de envío" en el contexto de Gemini "shipping_policies"
    
    # Validar con Gemini (ya tiene el contexto cargado)
    Then valido con Gemini que según el contexto para la pregunta "¿Tienen envío gratis?" la respuesta "Envío gratis en compras mayores a $50. Entregas en 3-5 días hábiles." es válida con umbral 0.8

  # ============================================================================
  # ESCENARIO 5: Testing de Hallucinations (Respuesta inventada)
  # ============================================================================
  @test5
  Escenario: Detectar cuando el chatbot inventa información no presente en el contexto
    # Buscar contexto real (se carga automáticamente en Gemini)
    When busco en la tabla "knowledge_base" el contexto más similar a "métodos de pago" y lo guardo en "rag_context"
    
    # Establecer respuesta inventada (no está en el contexto)
    And establezco la respuesta del SUT como "Aceptamos Bitcoin y criptomonedas para todos los pagos"
    
    # Validar - debería detectar que la info no está en el contexto
    Then valido que la respuesta no contiene alucinaciones según el contexto

  # ============================================================================
  # ESCENARIO 6: RAG Multilingüe
  # ============================================================================
  @test6
  Escenario: Validar respuesta en español usando contexto en inglés
    # Buscar contexto (puede estar en inglés, se carga automáticamente)
    When busco en la tabla "knowledge_base" el contexto más similar a "return policy" y lo guardo en "rag_context"
    
    # Validar que la respuesta es correcta aunque esté en otro idioma
    Then valido con Gemini que según el contexto para la pregunta "¿Cuál es la política de devoluciones?" la respuesta "Puedes devolver productos dentro de 30 días" es válida con umbral 0.75

  # ============================================================================
  # ESCENARIO 7: RAG con Validación de Completitud
  # ============================================================================
  @test7
  Escenario: Validar que la respuesta incluye toda la información relevante
    # Buscar contexto completo (se carga automáticamente)
    When busco en la tabla "knowledge_base" los 5 contextos más similares a "proceso de compra completo" y los guardo en "rag_documents"
    
    # Validar con Gemini (detectará si falta información)
    Then valido con Gemini que según el contexto para la pregunta "¿Cómo compro un producto?" la respuesta "Agrega productos al carrito y paga con tarjeta" es válida con umbral 0.7
    And guardo la evaluación del Juez en el archivo "reports/rag_completeness_evaluation.json"

  # ============================================================================
  # ESCENARIO 8: RAG con Múltiples Preguntas (Testing de Consistencia)
  # ============================================================================
  @test8
  Esquema del escenario: Validar múltiples preguntas sobre el mismo tema
    # Buscar contexto una vez (se carga automáticamente en Gemini)
    When busco en la tabla "knowledge_base" el contexto más similar a "<tema>" y lo guardo en "rag_context"
    
    # Validar cada pregunta
    Then valido con Gemini que según el contexto para la pregunta "<pregunta>" la respuesta "<respuesta>" es válida con umbral 0.8

    Ejemplos:
      | tema                  | pregunta                              | respuesta                                                    |
      | política de devoluciones | ¿Puedo devolver un producto usado?    | No, solo productos sin usar con etiquetas originales        |
      | política de devoluciones | ¿Cuánto tarda el reembolso?           | El reembolso se procesa en 5-7 días hábiles                 |
      | política de devoluciones | ¿Necesito el recibo?                  | Sí, necesitas el recibo original o comprobante de compra    |

  # ============================================================================
  # ESCENARIO 9: RAG con Validación de Citación de Fuentes
  # ============================================================================
  @test9
  Escenario: Validar que el chatbot cita correctamente las fuentes
    # Buscar contexto (se carga automáticamente)
    When busco en la tabla "knowledge_base" los 3 contextos más similares a "términos y condiciones" y los guardo en "rag_documents"
    
    # Establecer respuesta con citación
    And establezco la respuesta del SUT como "Según nuestros términos (sección 3.2), los usuarios deben ser mayores de 18 años. Ver más en: https://empresa.com/terminos"
    
    # Validar citación
    Then valido que la respuesta cita fuentes correctamente

  # ============================================================================
  # ESCENARIO 10: RAG con Evaluación Completa y Reporte
  # ============================================================================
  @test10
  Escenario: Evaluación completa de sistema RAG con reporte detallado
    # Buscar contexto (se carga automáticamente)
    When busco en la tabla "knowledge_base" el contexto más similar a "soporte técnico" y lo guardo en "rag_context"
    
    # Validar con Gemini y generar reporte
    Then valido con Gemini que según el contexto para la pregunta "¿Cómo contacto a soporte?" la respuesta "Nuestro soporte técnico está disponible 24/7 por chat, email y teléfono. Tiempo de respuesta promedio: 2 horas." es válida con umbral 0.85
    And guardo la evaluación del Juez en el archivo "reports/rag_full_evaluation.json"
    And el score de la última evaluación debe ser mayor o igual a 0.85

  # ============================================================================
  # ESCENARIO 11: RAG con Validación de Tono y Estilo
  # ============================================================================
  @test11
  Escenario: Validar que la respuesta mantiene el tono apropiado
    # Buscar contexto (se carga automáticamente)
    When busco en la tabla "knowledge_base" el contexto más similar a "quejas y reclamos" y lo guardo en "rag_context"
    
    # Establecer respuesta con tono empático
    And establezco la respuesta del SUT como "Lamentamos mucho tu experiencia. Entendemos tu frustración y queremos ayudarte a resolver esto lo antes posible."
    
    # Validar tono (NO requiere contexto activo)
    Then valido que la intención de la respuesta es "empática"

  # ============================================================================
  # ESCENARIO 12: RAG con Testing Adversarial
  # ============================================================================
  @test12
  Escenario: Validar que el sistema RAG rechaza preguntas fuera de contexto
    # Buscar contexto (políticas de empresa, se carga automáticamente)
    When busco en la tabla "knowledge_base" el contexto más similar a "políticas de empresa" y lo guardo en "rag_context"
    
    # Validar que rechaza apropiadamente preguntas fuera de contexto
    Then valido con Gemini que según el contexto para la pregunta "¿Cuál es la capital de Francia?" la respuesta "Lo siento, no tengo información sobre ese tema. ¿Puedo ayudarte con algo relacionado a nuestros productos o servicios?" es válida con umbral 0.9

