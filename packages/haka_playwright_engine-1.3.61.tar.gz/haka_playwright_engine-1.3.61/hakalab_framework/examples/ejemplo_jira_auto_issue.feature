# Ejemplo de uso de creación automática de issues en Jira al fallar

Feature: Login de usuario
  Como usuario del sistema
  Quiero poder iniciar sesión
  Para acceder a mi cuenta

  Scenario: Login exitoso con credenciales válidas
    Given navego a "${ENV.BASE_URL}/login"
    When relleno el campo "Email" con "${ENV.USER_EMAIL}" con identificador "$.LOGIN.input_email"
    And relleno el campo "Password" con "${ENV.USER_PASSWORD}" con identificador "$.LOGIN.input_password"
    And hago click en el elemento "Login" con identificador "$.LOGIN.button_submit"
    Then debería ver el texto "Bienvenido"
    # Si este escenario falla, se creará automáticamente una issue en Jira
    And si el escenario falla creo una issue de tipo "Bug" con título "Error en login con credenciales válidas"

  Scenario: Login con credenciales inválidas
    Given navego a "${ENV.BASE_URL}/login"
    When relleno el campo "Email" con "usuario@invalido.com" con identificador "$.LOGIN.input_email"
    And relleno el campo "Password" con "password_incorrecto" con identificador "$.LOGIN.input_password"
    And hago click en el elemento "Login" con identificador "$.LOGIN.button_submit"
    Then debería ver el texto "Credenciales inválidas"
    # Con prioridad personalizada
    And si el escenario falla creo una issue de tipo "Bug" con título "Error en validación de credenciales" y prioridad "High"

  Scenario: Login con descripción personalizada
    Given navego a "${ENV.BASE_URL}/login"
    When relleno el campo "Email" con "" con identificador "$.LOGIN.input_email"
    And hago click en el elemento "Login" con identificador "$.LOGIN.button_submit"
    Then debería ver el texto "El email es requerido"
    # Con descripción personalizada
    And si el escenario falla creo una issue de tipo "Bug" con título "Error en validación de campos vacíos" y descripción "El sistema no valida correctamente los campos vacíos en el formulario de login"
