# language: es
Feature: Testing con Supabase Vector Database
  Como QA Engineer
  Quiero realizar búsquedas semánticas en Supabase
  Para validar sistemas RAG y chatbots con IA

  Background:
    Given me conecto a Supabase usando variables de entorno

  @supabase @vector_search
  Scenario: Búsqueda vectorial simple
    When busco en la tabla "knowledge_base" el contexto más similar a "política de devoluciones" y lo guardo en "context"
    Then verifico que la variable "context" no está vacía
    And muestro el valor de la variable "context"

  @supabase @rag_testing
  Scenario: Testing de RAG con validación Gemini
    # Buscar contexto relevante en Supabase
    When busco en la tabla "knowledge_base" el contexto más similar a "horario de atención" y lo guardo en "kb_context"
    
    # Simular llamada a API con contexto
    When realizo una petición POST a "${CHATBOT_API}/ask" con el body:
      """
      {
        "question": "¿Cuál es el horario de atención?",
        "context": "${kb_context}"
      }
      """
    
    # Validar respuesta
    Then el código de estado de la respuesta debería ser 200
    And extraigo el valor "answer" del JSON de respuesta y lo guardo en "chatbot_answer"
    
    # Validar con Gemini usando el contexto de Supabase
    When establezco la respuesta del SUT como "${chatbot_answer}"
    And cargo la variable "kb_context" como contexto de Gemini "customer_service"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8

  @supabase @direct_gemini @no_browser
  Scenario: Carga directa de contexto de Supabase a Gemini
    # Cargar contexto directamente desde Supabase a Gemini
    Given cargo el contexto de Supabase tabla "knowledge_base" para la query "políticas de envío" en el contexto de Gemini "shipping_policies"
    
    # Obtener respuesta del sistema
    When realizo una petición POST a "${CHATBOT_API}/ask" con el body:
      """
      {
        "question": "¿Cuánto tarda el envío internacional?"
      }
      """
    And extraigo el valor "answer" del JSON de respuesta y lo guardo en "system_answer"
    
    # Validar con Gemini
    When establezco la respuesta del SUT como "${system_answer}"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.85
    And valido que la respuesta no contiene alucinaciones según el contexto
    And valido que la respuesta está en idioma "español"

  @supabase @multiple_docs
  Scenario: Búsqueda de múltiples documentos
    When busco en la tabla "knowledge_base" los 5 contextos más similares a "política de garantías" y los guardo en "warranty_docs"
    Then verifico que la variable "warranty_docs" es una lista
    And verifico que la variable "warranty_docs" tiene al menos 1 elementos

  @supabase @table_query
  Scenario: Consulta directa a tabla con filtro
    When consulto la tabla "products" filtrando por "category" igual a "electronics" y guardo en "electronics"
    Then verifico que la variable "electronics" es una lista
    And muestro el número de elementos en la variable "electronics"

  @supabase @consistency_check @no_browser
  Scenario: Validar consistencia entre múltiples fuentes
    # Buscar múltiples documentos sobre el mismo tema
    When busco en la tabla "knowledge_base" los 3 contextos más similares a "política de cancelación" y los guardo en "cancellation_docs"
    
    # Obtener respuesta del sistema
    When realizo una petición POST a "${CHATBOT_API}/ask" con el body:
      """
      {
        "question": "¿Puedo cancelar mi pedido?",
        "use_multiple_sources": true
      }
      """
    And extraigo el valor "answer" del JSON de respuesta y lo guardo en "answer"
    
    # Validar consistencia
    When establezco la respuesta del SUT como "${answer}"
    Then valido que la respuesta no contiene alucinaciones según el contexto
    And valido que la intención de la respuesta es "informativa"

  @supabase @semantic_search
  Scenario Outline: Búsquedas semánticas variadas
    When busco en la tabla "knowledge_base" el contexto más similar a "<query>" y lo guardo en "result"
    Then verifico que la variable "result" no está vacía
    And muestro el valor de la variable "result"

    Examples:
      | query                          |
      | política de privacidad         |
      | términos y condiciones         |
      | métodos de pago aceptados      |
      | proceso de devolución          |
      | garantía de productos          |

  @supabase @integration_test @no_browser
  Scenario: Test completo de integración RAG
    # 1. Buscar contexto en Supabase
    Given cargo el contexto de Supabase tabla "knowledge_base" para la query "soporte técnico" en el contexto de Gemini "tech_support"
    
    # 2. Generar respuesta de referencia con Gemini
    When Gemini genera la respuesta para el prompt "¿Cómo contacto con soporte técnico?"
    And guardo la respuesta generada en la variable "golden_answer"
    
    # 3. Obtener respuesta del sistema
    When realizo una petición POST a "${CHATBOT_API}/ask" con el body:
      """
      {
        "question": "¿Cómo contacto con soporte técnico?"
      }
      """
    And extraigo el valor "answer" del JSON de respuesta y lo guardo en "system_answer"
    
    # 4. Comparar respuestas
    When establezco la respuesta del SUT como "${system_answer}"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    
    # 5. Validaciones adicionales
    And valido que la respuesta no contiene alucinaciones según el contexto
    And valido que la respuesta está en idioma "español"
    And valido que la intención de la respuesta es "informativa"
    
    # 6. Validar similitud semántica con respuesta de referencia
    Then el texto "${system_answer}" debe ser semánticamente similar a "${golden_answer}"
