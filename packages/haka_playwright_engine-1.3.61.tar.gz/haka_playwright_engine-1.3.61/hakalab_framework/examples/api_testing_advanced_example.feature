# Ejemplo Avanzado de Testing de APIs REST
# Incluye validación de esquemas, comparación con archivos, y validaciones complejas

Feature: Testing Avanzado de API REST

  Background:
    Given establezco la URL base de API a "https://api.example.com/v1"
    And establezco el header "Content-Type" con valor "application/json"

  # ============================================================================
  # EJEMPLO 1: Validación con JSON Schema
  # ============================================================================
  
  Scenario: Crear usuario y validar con esquema JSON Schema
    # Crear usuario desde archivo
    When cargo JSON del archivo "payloads/create_user.json" y envío POST a "/users" guardando respuesta en variable "response"
    Then la respuesta debería tener código 201
    
    # Validar con esquema JSON Schema (Draft 7)
    And verifico que el JSON de respuesta API coincide con el esquema del archivo "schemas/user_schema.json"
    
    # Validar tipos específicos
    And verifico que el JSON de respuesta API tiene el campo "id" con tipo "integer"
    And verifico que el JSON de respuesta API tiene el campo "email" con tipo "string"
    And verifico que el JSON de respuesta API tiene el campo "active" con tipo "boolean"
    And verifico que el JSON de respuesta API tiene el campo "roles" con tipo "array"
    
    # Validar patrones
    And verifico que el campo "email" del JSON de respuesta API coincide con el patrón "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
    
    # Validar rangos
    And verifico que el campo "age" del JSON de respuesta API está en el rango 18 a 100
    
    # Guardar respuesta para referencia
    And guardo el JSON de respuesta API en el archivo "responses/user_created.json"
    
    # Extraer ID para siguientes tests
    And extraigo el campo "id" de la respuesta y lo guardo en la variable "user_id"

  # ============================================================================
  # EJEMPLO 2: Comparación con Archivo Ignorando Campos Dinámicos
  # ============================================================================
  
  Scenario: Obtener usuario y comparar con archivo esperado
    # Obtener usuario
    When envío petición GET a "/users/123"
    Then la respuesta debería tener código 200
    
    # Comparar con archivo esperado ignorando timestamps
    And verifico que el JSON de respuesta API coincide con el archivo "expected/user_123.json" ignorando campos "created_at,updated_at,last_login"
    
    # Validar que los campos ignorados existen y tienen formato ISO 8601
    And verifico que el campo "created_at" del JSON de respuesta API coincide con el patrón "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}"
    And verifico que el campo "updated_at" del JSON de respuesta API coincide con el patrón "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}"

  # ============================================================================
  # EJEMPLO 3: Validación de Arrays Complejos
  # ============================================================================
  
  Scenario: Validar lista de productos con estructura compleja
    When envío petición GET a "/products?category=electronics&limit=10"
    Then la respuesta debería tener código 200
    
    # Validar estructura del array
    And el array "products" en la respuesta debería tener 10 elementos
    
    # Validar que todos los elementos tienen campos requeridos
    And verifico que todos los elementos del array "products" del JSON de respuesta API tienen el campo "id"
    And verifico que todos los elementos del array "products" del JSON de respuesta API tienen el campo "name"
    And verifico que todos los elementos del array "products" del JSON de respuesta API tienen el campo "price"
    And verifico que todos los elementos del array "products" del JSON de respuesta API tienen el campo "stock"
    
    # Validar que existe un producto específico
    And verifico que el array "products" del JSON de respuesta API contiene un elemento con "name" igual a "Laptop Gaming"
    
    # Validar tipos en el primer elemento
    And verifico que el JSON de respuesta API tiene el campo "products.0.id" con tipo "integer"
    And verifico que el JSON de respuesta API tiene el campo "products.0.name" con tipo "string"
    And verifico que el JSON de respuesta API tiene el campo "products.0.price" con tipo "number"
    And verifico que el JSON de respuesta API tiene el campo "products.0.tags" con tipo "array"
    
    # Validar rangos
    And verifico que el campo "products.0.price" del JSON de respuesta API está en el rango 0 a 999999
    And verifico que el campo "products.0.stock" del JSON de respuesta API está en el rango 0 a 10000

  # ============================================================================
  # EJEMPLO 4: Validación Sin Valores Nulos
  # ============================================================================
  
  Scenario: Validar que la respuesta no contiene valores nulos
    When envío petición GET a "/users/123/profile"
    Then la respuesta debería tener código 200
    
    # Validar que no hay nulls en toda la respuesta
    And verifico que el JSON de respuesta API no tiene valores nulos
    
    # Validar estructura completa con esquema
    And verifico que el JSON de respuesta API coincide con el esquema del archivo "schemas/user_profile_schema.json"

  # ============================================================================
  # EJEMPLO 5: Validación de Paginación
  # ============================================================================
  
  Scenario: Validar estructura de paginación
    When envío petición GET a "/users?page=1&limit=20"
    Then la respuesta debería tener código 200
    
    # Validar estructura de paginación
    And verifico que el JSON de respuesta API tiene el campo "data" con tipo "array"
    And verifico que el JSON de respuesta API tiene el campo "pagination.total" con tipo "integer"
    And verifico que el JSON de respuesta API tiene el campo "pagination.page" con tipo "integer"
    And verifico que el JSON de respuesta API tiene el campo "pagination.limit" con tipo "integer"
    And verifico que el JSON de respuesta API tiene el campo "pagination.pages" con tipo "integer"
    
    # Validar valores de paginación
    And el campo "pagination.page" debería ser 1
    And el campo "pagination.limit" debería ser 20
    And el array "data" en la respuesta debería tener 20 elementos
    
    # Validar que todos los usuarios tienen estructura correcta
    And verifico que todos los elementos del array "data" del JSON de respuesta API tienen el campo "id"
    And verifico que todos los elementos del array "data" del JSON de respuesta API tienen el campo "email"

  # ============================================================================
  # EJEMPLO 6: Comparación Ignorando Orden de Arrays
  # ============================================================================
  
  Scenario: Validar resultados de búsqueda ignorando orden
    When envío petición GET a "/search?q=laptop&sort=relevance"
    Then la respuesta debería tener código 200
    
    # Comparar con archivo esperado ignorando orden de resultados
    And verifico que el JSON de respuesta API coincide con el archivo "expected/search_laptop.json" ignorando orden
    
    # Validar que todos los resultados tienen los campos necesarios
    And verifico que todos los elementos del array "results" del JSON de respuesta API tienen el campo "id"
    And verifico que todos los elementos del array "results" del JSON de respuesta API tienen el campo "title"
    And verifico que todos los elementos del array "results" del JSON de respuesta API tienen el campo "relevance"
    
    # Validar rangos de relevancia
    And verifico que el campo "results.0.relevance" del JSON de respuesta API está en el rango 0 a 1

  # ============================================================================
  # EJEMPLO 7: Flujo Completo de E-commerce con Validación de Esquemas
  # ============================================================================
  
  Scenario: Flujo completo de orden con validación robusta
    # Autenticación
    When cargo JSON del archivo "payloads/login.json" y envío POST a "/auth/login" guardando respuesta en variable "auth_response"
    Then la respuesta debería tener código 200
    And extraigo el campo "access_token" de la respuesta y lo guardo en la variable "token"
    And establezco el header "Authorization" con valor "Bearer ${token}"
    
    # Crear orden
    When cargo JSON del archivo "payloads/create_order.json" y envío POST a "/orders" guardando respuesta en variable "order_response"
    Then la respuesta debería tener código 201
    And verifico que el JSON de respuesta API coincide con el esquema del archivo "schemas/order_schema.json"
    And extraigo el campo "id" de la respuesta y lo guardo en la variable "order_id"
    
    # Validar items de la orden
    And verifico que todos los elementos del array "items" del JSON de respuesta API tienen el campo "product_id"
    And verifico que todos los elementos del array "items" del JSON de respuesta API tienen el campo "quantity"
    And verifico que todos los elementos del array "items" del JSON de respuesta API tienen el campo "price"
    
    # Validar totales
    And verifico que el JSON de respuesta API tiene el campo "subtotal" con tipo "number"
    And verifico que el JSON de respuesta API tiene el campo "tax" con tipo "number"
    And verifico que el JSON de respuesta API tiene el campo "total" con tipo "number"
    
    # Obtener orden
    When envío petición GET a "/orders/${order_id}"
    Then la respuesta debería tener código 200
    And verifico que el JSON de respuesta API coincide con el esquema del archivo "schemas/order_schema.json"
    
    # Actualizar orden
    When cargo JSON del archivo "payloads/update_order.json" y envío PUT a "/orders/${order_id}" guardando respuesta en variable "update_response"
    Then la respuesta debería tener código 200
    And el campo "status" debería ser "processing"
    
    # Cancelar orden
    When envío petición DELETE a "/orders/${order_id}"
    Then la respuesta debería tener código 204

  # ============================================================================
  # EJEMPLO 8: Validación de Errores con Esquemas
  # ============================================================================
  
  Scenario: Validar estructura de errores
    # Intentar crear usuario con datos inválidos
    When cargo JSON del archivo "payloads/invalid_user.json" y envío POST a "/users" guardando respuesta en variable "error_response"
    Then la respuesta debería tener código 400
    
    # Validar estructura de error con esquema
    And verifico que el JSON de respuesta API coincide con el esquema del archivo "schemas/error_schema.json"
    
    # Validar campos de error
    And verifico que el JSON de respuesta API tiene el campo "error.code" con tipo "string"
    And verifico que el JSON de respuesta API tiene el campo "error.message" con tipo "string"
    And verifico que el JSON de respuesta API tiene el campo "error.details" con tipo "array"
    
    # Validar que hay detalles de error
    And el array "error.details" en la respuesta debería tener al menos 1 elemento
    And verifico que todos los elementos del array "error.details" del JSON de respuesta API tienen el campo "field"
    And verifico que todos los elementos del array "error.details" del JSON de respuesta API tienen el campo "message"
