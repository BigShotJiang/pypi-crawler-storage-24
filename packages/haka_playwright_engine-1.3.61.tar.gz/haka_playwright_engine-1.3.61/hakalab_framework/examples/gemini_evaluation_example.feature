# Ejemplo Completo de Testing con Gemini como Juez
# Evaluación de respuestas de IA Generativa (LLMs, chatbots, etc.)

Feature: Testing de Chatbot con Gemini como Juez

  # ============================================================================
  # EJEMPLO 1: Testing Básico de Chatbot
  # ============================================================================
  
  Background:
    Given el contexto de reglas de negocio "customer_service" está cargado desde el archivo "context/customer_service_rules.txt"

  Scenario: Validar respuesta sobre horario de atención
    When establezco la respuesta del SUT como "Nuestro horario de atención es de lunes a viernes de 9am a 6pm. Los fines de semana estamos cerrados."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    And guardo la evaluación del Juez en el archivo "evaluations/horario_test.json"

  Scenario: Validar respuesta sobre devoluciones
    When establezco la respuesta del SUT como "Puedes devolver cualquier producto dentro de 30 días desde la compra. Solo necesitas el recibo y el producto en buen estado."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    And el score de la última evaluación debe ser mayor o igual a 0.8

  Scenario: Validar respuesta sobre métodos de pago
    When establezco la respuesta del SUT como "Aceptamos tarjetas de crédito, débito, PayPal y transferencia bancaria. Todos los pagos son seguros."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8

  # ============================================================================
  # EJEMPLO 2: Testing con Múltiples Contextos
  # ============================================================================

Feature: Testing con Diferentes Contextos de Negocio

  Scenario: Soporte técnico
    Given el contexto de reglas de negocio "tech_support" está cargado desde el archivo "context/tech_support_rules.txt"
    When establezco la respuesta del SUT como "Para resetear tu contraseña, ve a la página de login y haz click en 'Olvidé mi contraseña'. Recibirás un email con instrucciones."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.85
    And guardo la evaluación del Juez en el archivo "evaluations/tech_support_test.json"

  Scenario: Ventas y promociones
    Given el contexto de reglas de negocio "sales" está cargado desde el archivo "context/sales_rules.txt"
    When establezco la respuesta del SUT como "Tenemos una promoción especial del 20% de descuento en todos los productos hasta fin de mes. ¡No te lo pierdas!"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8

  Scenario: Cambiar entre contextos
    Given el contexto de reglas de negocio "general" está cargado desde el archivo "context/general_rules.txt"
    When establezco la respuesta del SUT como "Respuesta con contexto general"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.7
    
    # Cambiar a contexto específico
    Given cambio al contexto de reglas de negocio "tech_support"
    When establezco la respuesta del SUT como "Respuesta con contexto técnico"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.85

  # ============================================================================
  # EJEMPLO 3: Testing con Criterios Personalizados
  # ============================================================================

Feature: Testing con Criterios Específicos

  Background:
    Given el contexto de reglas de negocio "empathy" está cargado desde el archivo "context/empathy_rules.txt"

  Scenario: Validar tono empático en respuesta a queja
    When establezco la respuesta del SUT como "Lamento mucho que hayas tenido esa experiencia. Entiendo tu frustración y quiero ayudarte a resolverlo lo antes posible."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "tono empático,respuesta en menos de 30 palabras,ofrece ayuda" y umbral 0.9
    And guardo la evaluación del Juez en el archivo "evaluations/empathy_test.json"

  Scenario: Validar respuesta concisa y clara
    When establezco la respuesta del SUT como "Sí, puedes cambiar tu dirección de envío. Ve a 'Mi Cuenta' > 'Pedidos' > 'Editar Dirección'."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "respuesta concisa,pasos claros,menos de 25 palabras" y umbral 0.85

  Scenario: Validar respuesta profesional
    When establezco la respuesta del SUT como "Gracias por contactarnos. Hemos recibido tu solicitud y te responderemos en un plazo máximo de 24 horas."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "tono profesional,incluye tiempo de respuesta" y umbral 0.8

  # ============================================================================
  # EJEMPLO 4: Testing con Respuestas desde Archivo
  # ============================================================================

Feature: Testing con Respuestas Complejas

  Background:
    Given el contexto de reglas de negocio "legal" está cargado desde el archivo "context/legal_terms.txt"

  Scenario: Validar términos y condiciones
    When cargo la respuesta del SUT desde el archivo "responses/terms_and_conditions.txt"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9
    And guardo la evaluación del Juez en el archivo "evaluations/legal_terms_eval.json"
    And el score de la última evaluación debe ser mayor o igual a 0.9

  Scenario: Validar política de privacidad
    When cargo la respuesta del SUT desde el archivo "responses/privacy_policy.txt"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9
    And guardo la evaluación del Juez en el archivo "evaluations/privacy_policy_eval.json"

  # ============================================================================
  # EJEMPLO 5: Testing con Limpieza de Caché
  # ============================================================================

Feature: Testing con Actualización de Contexto

  Scenario: Usar contexto antiguo
    Given el contexto de reglas de negocio "old_rules" está cargado desde el archivo "context/old_rules_v1.txt"
    When establezco la respuesta del SUT como "Respuesta basada en reglas antiguas: envío gratis para pedidos > 100€"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    And guardo la evaluación del Juez en el archivo "evaluations/old_rules_test.json"

  Scenario: Actualizar y usar nuevo contexto
    # Limpiar cachés para forzar recarga
    Given limpio todos los cachés de contexto
    And el contexto de reglas de negocio "new_rules" está cargado desde el archivo "context/new_rules_v2.txt"
    When establezco la respuesta del SUT como "Respuesta basada en reglas nuevas: envío gratis para pedidos > 50€"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    And guardo la evaluación del Juez en el archivo "evaluations/new_rules_test.json"

  # ============================================================================
  # EJEMPLO 6: Testing de Chatbot Multilingüe
  # ============================================================================

Feature: Testing de Respuestas en Múltiples Idiomas

  Scenario: Validar respuesta en español
    Given el contexto de reglas de negocio "spanish_rules" está cargado desde el archivo "context/rules_es.txt"
    When establezco la respuesta del SUT como "Hola, ¿en qué puedo ayudarte hoy? Estoy aquí para resolver tus dudas."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8

  Scenario: Validar respuesta en inglés
    Given el contexto de reglas de negocio "english_rules" está cargado desde el archivo "context/rules_en.txt"
    When establezco la respuesta del SUT como "Hello, how can I help you today? I'm here to answer your questions."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8

  Scenario: Validar que no mezcla idiomas
    Given el contexto de reglas de negocio "spanish_rules" está cargado desde el archivo "context/rules_es.txt"
    When establezco la respuesta del SUT como "Hola, how can I help you? Estoy aquí para ayudarte."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    # Este test debería fallar porque mezcla idiomas

  # ============================================================================
  # EJEMPLO 7: Testing de Restricciones de Seguridad
  # ============================================================================

Feature: Testing de Restricciones de Seguridad

  Background:
    Given el contexto de reglas de negocio "security" está cargado desde el archivo "context/security_restrictions.txt"

  Scenario: Validar que no comparte información sensible
    When establezco la respuesta del SUT como "No puedo compartir información de cuentas de otros usuarios por razones de seguridad. Solo puedo ayudarte con tu propia cuenta."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9

  Scenario: Validar que no da consejos médicos
    When establezco la respuesta del SUT como "No puedo dar consejos médicos. Te recomiendo consultar con un profesional de la salud para tu situación específica."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9

  Scenario: Validar que deriva correctamente
    When establezco la respuesta del SUT como "Esta consulta requiere atención especializada. Te voy a transferir con un agente humano que podrá ayudarte mejor."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.85

  # ============================================================================
  # EJEMPLO 8: Testing de Calidad de Contenido Generado
  # ============================================================================

Feature: Testing de Generación de Contenido

  Background:
    Given el contexto de reglas de negocio "content_style" está cargado desde el archivo "context/content_style_guide.txt"

  Scenario: Validar artículo de blog
    When cargo la respuesta del SUT desde el archivo "responses/blog_article.txt"
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "tono profesional,estructura clara,100-200 palabras,sin jerga técnica" y umbral 0.85
    And guardo la evaluación del Juez en el archivo "evaluations/blog_article_eval.json"

  Scenario: Validar descripción de producto
    When establezco la respuesta del SUT como "Este producto revolucionario combina tecnología de punta con diseño elegante. Perfecto para profesionales que buscan calidad y rendimiento. Disponible en varios colores."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "tono persuasivo,menos de 50 palabras,destaca beneficios" y umbral 0.8

  Scenario: Validar email de marketing
    When cargo la respuesta del SUT desde el archivo "responses/marketing_email.txt"
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "tono amigable,call to action claro,personalizado" y umbral 0.85
    And guardo la evaluación del Juez en el archivo "evaluations/marketing_email_eval.json"

  # ============================================================================
  # EJEMPLO 9: Validación Directa de Pregunta-Respuesta
  # ============================================================================

Feature: Validación Directa de Pares Pregunta-Respuesta

  Background:
    Given el contexto de reglas de negocio "customer_service" está cargado desde el archivo "context/customer_service_rules.txt"

  Scenario: Validar múltiples preguntas frecuentes
    # Validar horario de atención
    Then valido con Gemini que según el contexto para la pregunta "¿Cuál es el horario de atención?" la respuesta "Lunes a viernes de 9am a 6pm" es válida con umbral 0.8
    
    # Validar política de devoluciones
    And el Juez Gemini valida que para la pregunta "¿Aceptan devoluciones?" la respuesta "Sí, dentro de 30 días con recibo" es correcta con umbral 0.8
    
    # Validar métodos de pago
    And valido con Gemini que según el contexto para la pregunta "¿Qué métodos de pago aceptan?" la respuesta "Tarjetas de crédito, débito y PayPal" es válida con umbral 0.8

  Scenario: Validar respuestas de soporte técnico
    Given el contexto de reglas de negocio "tech_support" está cargado desde el archivo "context/tech_support_rules.txt"
    
    # Validar reseteo de contraseña
    Then el Juez Gemini valida que para la pregunta "¿Cómo reseteo mi contraseña?" la respuesta "Ve a login y haz click en 'Olvidé mi contraseña'" es correcta con umbral 0.85
    
    # Validar actualización de software
    And valido con Gemini que según el contexto para la pregunta "¿Cómo actualizo el software?" la respuesta "Ve a Configuración > Actualizaciones > Buscar actualizaciones" es válida con umbral 0.85

  Scenario: Validar respuestas incorrectas (deben fallar)
    # Esta respuesta debería fallar porque el horario es incorrecto
    Then valido con Gemini que según el contexto para la pregunta "¿Cuál es el horario?" la respuesta "Abierto 24/7 todos los días" es válida con umbral 0.8
    # Este test debería fallar si las reglas de negocio dicen que no están abiertos 24/7

  # ============================================================================
  # EJEMPLO 10: Threshold Configurable (NUEVO v1.3.11+)
  # ============================================================================

Feature: Testing con Threshold Configurable

  Background:
    Given el contexto de reglas de negocio "policies" está cargado desde el archivo "context/policies.txt"

  Scenario: Usar threshold por defecto del .env
    When interactúo con la IA con el prompt "¿Cuál es la política de devoluciones?"
    And establezco la respuesta del SUT como "Puedes devolver productos dentro de 30 días con recibo"
    Then el Juez Gemini debe validar la respuesta
    # Usa GEMINI_JUDGE_THRESHOLD del .env (default: 0.80)
    And guardo la evaluación del Juez en el archivo "evaluations/threshold_default.json"

  Scenario: Validar múltiples respuestas con threshold del .env
    # Todas estas validaciones usan el threshold configurado en .env
    When establezco la respuesta del SUT como "Aceptamos tarjetas de crédito, débito y PayPal"
    Then el Juez Gemini debe validar la respuesta
    
    When establezco la respuesta del SUT como "El envío es gratis para pedidos mayores a $50"
    Then el Juez Gemini debe validar la respuesta
    
    When establezco la respuesta del SUT como "Nuestro horario es de lunes a viernes de 9am a 6pm"
    Then el Juez Gemini debe validar la respuesta

  Scenario: Usar threshold específico para test estricto
    When interactúo con la IA con el prompt "¿Aceptan devoluciones?"
    And establezco la respuesta del SUT como "Sí, dentro de 30 días con recibo original en buen estado"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.95
    # Threshold muy alto (0.95) para validación estricta
    And guardo la evaluación del Juez en el archivo "evaluations/threshold_strict.json"

  Scenario: Combinar threshold del .env con threshold específico
    # Primera validación usa .env
    When establezco la respuesta del SUT como "Respuesta estándar con threshold del .env"
    Then el Juez Gemini debe validar la respuesta
    
    # Segunda validación usa threshold específico más alto
    When establezco la respuesta del SUT como "Respuesta crítica que requiere validación estricta"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.95

  # ============================================================================
  # EJEMPLO 11: Dimensiones RAG - Context Relevance (NUEVO v1.3.11+)
  # ============================================================================

Feature: Testing de Context Relevance (RAG)

  Background:
    Given el contexto de reglas de negocio "customer_service" está cargado desde el archivo "context/customer_service_rules.txt"

  Scenario: Contexto relevante - debería pasar (usa threshold del .env)
    When interactúo con la IA con el prompt "¿Cuál es la política de devoluciones?"
    And establezco la respuesta del SUT como "Puedes devolver productos dentro de 30 días con recibo"
    Then el Juez Gemini debe validar la respuesta
    # Usa GEMINI_JUDGE_THRESHOLD del .env - Context Relevance debería ser alto (0.9+)
    And guardo la evaluación del Juez en el archivo "evaluations/context_relevant.json"

  Scenario: Validar múltiples respuestas con contexto relevante
    # Todas usan threshold del .env
    When establezco la respuesta del SUT como "Aceptamos devoluciones dentro de 30 días"
    Then el Juez Gemini debe validar la respuesta
    
    When establezco la respuesta del SUT como "El horario de atención es de 9am a 6pm"
    Then el Juez Gemini debe validar la respuesta
    
    When establezco la respuesta del SUT como "Aceptamos tarjetas de crédito y débito"
    Then el Juez Gemini debe validar la respuesta

  Scenario: Contexto irrelevante - threshold específico para detectar problema
    When interactúo con la IA con el prompt "¿Cuál es el precio del producto X?"
    And establezco la respuesta del SUT como "El precio es $99.99"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.70
    # Context Relevance podría ser bajo si el contexto no tiene info de precios
    And guardo la evaluación del Juez en el archivo "evaluations/context_irrelevant.json"

  # ============================================================================
  # EJEMPLO 12: Dimensiones RAG - Faithfulness (NUEVO v1.3.11+)
  # ============================================================================

Feature: Testing de Faithfulness - Detección de Alucinaciones

  Background:
    Given el contexto de reglas de negocio "policies" está cargado desde el archivo "context/policies.txt"
    # Contexto dice: "Devoluciones permitidas dentro de 30 días con recibo"

  Scenario: Respuesta fiel al contexto - usa threshold del .env
    When interactúo con la IA con el prompt "¿Cuál es el plazo de devolución?"
    And establezco la respuesta del SUT como "Puedes devolver productos dentro de 30 días con recibo"
    Then el Juez Gemini debe validar la respuesta
    # Usa GEMINI_JUDGE_THRESHOLD del .env - Faithfulness debería ser alto (0.95+)
    And guardo la evaluación del Juez en el archivo "evaluations/faithful_response.json"

  Scenario: Validar múltiples respuestas fieles al contexto
    # Todas usan threshold del .env
    When establezco la respuesta del SUT como "El plazo de devolución es de 30 días"
    Then el Juez Gemini debe validar la respuesta
    
    When establezco la respuesta del SUT como "Necesitas el recibo para hacer una devolución"
    Then el Juez Gemini debe validar la respuesta
    
    When establezco la respuesta del SUT como "Aceptamos devoluciones dentro de 30 días con recibo original"
    Then el Juez Gemini debe validar la respuesta

  Scenario: Alucinación detectada - plazo incorrecto
    When interactúo con la IA con el prompt "¿Cuál es el plazo de devolución?"
    And establezco la respuesta del SUT como "Puedes devolver productos dentro de 60 días sin recibo"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.80
    # Faithfulness debería ser bajo (<0.5) porque inventa 60 días (contexto dice 30)
    # Este test debería FALLAR porque la IA está alucinando
    And guardo la evaluación del Juez en el archivo "evaluations/hallucination_detected.json"

  Scenario: Alucinación parcial - agrega información no presente
    When interactúo con la IA con el prompt "¿Política de devoluciones?"
    And establezco la respuesta del SUT como "Puedes devolver dentro de 30 días con recibo. Además, ofrecemos reembolso completo en 24 horas"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.80
    # Faithfulness debería ser medio (0.6-0.7) porque mezcla info correcta con inventada
    # "reembolso en 24 horas" no está en el contexto
    And guardo la evaluación del Juez en el archivo "evaluations/partial_hallucination.json"

  # ============================================================================
  # EJEMPLO 13: Dimensiones RAG - Answer Relevance (NUEVO v1.3.11+)
  # ============================================================================

Feature: Testing de Answer Relevance

  Background:
    Given el contexto de reglas de negocio "customer_service" está cargado desde el archivo "context/customer_service_rules.txt"

  Scenario: Respuesta relevante - aborda la pregunta (usa threshold del .env)
    When interactúo con la IA con el prompt "¿Cuánto cuesta el envío?"
    And establezco la respuesta del SUT como "El envío cuesta $5 para pedidos menores a $50, y es gratis para pedidos mayores"
    Then el Juez Gemini debe validar la respuesta
    # Usa GEMINI_JUDGE_THRESHOLD del .env - Answer Relevance debería ser alto (0.9+)
    And guardo la evaluación del Juez en el archivo "evaluations/answer_relevant.json"

  Scenario: Validar múltiples respuestas relevantes
    # Todas usan threshold del .env
    When establezco la respuesta del SUT como "El horario es de lunes a viernes de 9am a 6pm"
    Then el Juez Gemini debe validar la respuesta
    
    When establezco la respuesta del SUT como "Aceptamos tarjetas de crédito, débito y PayPal"
    Then el Juez Gemini debe validar la respuesta
    
    When establezco la respuesta del SUT como "Puedes devolver productos dentro de 30 días con recibo"
    Then el Juez Gemini debe validar la respuesta

  Scenario: Respuesta irrelevante - no aborda la pregunta
    When interactúo con la IA con el prompt "¿Cuánto cuesta el envío?"
    And establezco la respuesta del SUT como "Nuestro horario de atención es de lunes a viernes de 9am a 6pm"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.80
    # Answer Relevance debería ser bajo (<0.3) porque no responde la pregunta
    # Este test debería FALLAR
    And guardo la evaluación del Juez en el archivo "evaluations/answer_irrelevant.json"

  Scenario: Respuesta parcialmente relevante
    When interactúo con la IA con el prompt "¿Cuánto cuesta el envío?"
    And establezco la respuesta del SUT como "Ofrecemos varios métodos de envío. Puedes elegir el que prefieras al hacer checkout"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.70
    # Answer Relevance debería ser medio (0.5-0.6) porque habla de envío pero no responde el costo
    And guardo la evaluación del Juez en el archivo "evaluations/answer_partial.json"

  # ============================================================================
  # EJEMPLO 14: Análisis Completo de Dimensiones RAG (NUEVO v1.3.11+)
  # ============================================================================

Feature: Análisis Completo de Todas las Dimensiones

  Background:
    Given el contexto de reglas de negocio "comprehensive" está cargado desde el archivo "context/comprehensive_rules.txt"

  Scenario: Respuesta perfecta - todas las dimensiones altas (usa threshold del .env)
    When interactúo con la IA con el prompt "¿Cuál es su política de devoluciones?"
    And establezco la respuesta del SUT como "Aceptamos devoluciones dentro de 30 días con recibo original. El producto debe estar en su empaque original y sin usar. El reembolso se procesa en 5-7 días hábiles."
    Then el Juez Gemini debe validar la respuesta
    # Usa GEMINI_JUDGE_THRESHOLD del .env
    And guardo la evaluación del Juez en el archivo "evaluations/perfect_response.json"
    # Dimensiones esperadas:
    # - Precision: 0.95+ (información correcta)
    # - Compliance: 0.95+ (cumple reglas)
    # - Tone: 0.90+ (profesional)
    # - Coherence: 0.95+ (coherente)
    # - Context Relevance: 0.95+ (contexto útil)
    # - Faithfulness: 0.95+ (fiel al contexto)
    # - Answer Relevance: 0.95+ (responde la pregunta)

  Scenario: Validar múltiples respuestas de calidad con threshold del .env
    # Todas estas validaciones usan el threshold del .env
    When establezco la respuesta del SUT como "Nuestro horario de atención es de lunes a viernes de 9am a 6pm. Los fines de semana estamos cerrados."
    Then el Juez Gemini debe validar la respuesta
    
    When establezco la respuesta del SUT como "Aceptamos tarjetas de crédito, débito, PayPal y transferencia bancaria. Todos los pagos son seguros."
    Then el Juez Gemini debe validar la respuesta
    
    When establezco la respuesta del SUT como "El envío es gratis para pedidos mayores a $50. Para pedidos menores, el costo es de $5."
    Then el Juez Gemini debe validar la respuesta

  Scenario: Respuesta con múltiples problemas - threshold alto para detectar
    When interactúo con la IA con el prompt "¿Cuál es su política de devoluciones?"
    And establezco la respuesta del SUT como "Pues mira, creo que puedes devolver cuando quieras, no estoy seguro. Tal vez en 90 días o algo así. No sé si necesitas recibo."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.80
    And guardo la evaluación del Juez en el archivo "evaluations/problematic_response.json"
    # Este test debería FALLAR con múltiples dimensiones bajas:
    # - Precision: bajo (información incorrecta)
    # - Compliance: bajo (no cumple reglas)
    # - Tone: bajo (informal, inseguro)
    # - Coherence: medio (algo coherente pero vago)
    # - Context Relevance: medio (contexto tiene la info pero no la usa)
    # - Faithfulness: bajo (inventa 90 días)
    # - Answer Relevance: medio (intenta responder pero mal)

  Scenario: Guardar y analizar evaluación detallada (usa threshold del .env)
    When interactúo con la IA con el prompt "¿Aceptan devoluciones de productos usados?"
    And establezco la respuesta del SUT como "No aceptamos devoluciones de productos que hayan sido usados. Solo aceptamos devoluciones de productos en su empaque original y sin usar, dentro de 30 días con recibo."
    Then el Juez Gemini debe validar la respuesta
    And guardo la evaluación del Juez en el archivo "evaluations/detailed_analysis.json"
    # El archivo JSON contendrá todas las dimensiones con scores y explicaciones detalladas
    # Puedes analizar el JSON para ver qué dimensiones están bajas y por qué
