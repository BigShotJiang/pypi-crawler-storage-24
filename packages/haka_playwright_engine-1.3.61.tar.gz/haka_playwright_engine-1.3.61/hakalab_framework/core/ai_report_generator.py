"""
Generador de Reportes de Validaciones IA
Genera reportes especializados para validaciones de IA (Gemini como Juez, Validación Semántica, RAG)
"""
import os
import json
import base64
from datetime import datetime
from typing import Dict, List, Any
import logging


class AIReportGenerator:
    """Genera reportes HTML especializados para validaciones de IA"""
    
    def __init__(self, config_path: str = None):
        self.logger = logging.getLogger(__name__)
        self.config = self._load_report_config(config_path)
        self.ai_validations = []
    
    def _load_report_config(self, config_path: str = None) -> Dict[str, Any]:
        """Carga la configuración del reporte desde JSON (mismo que html_reporter.py)"""
        default_config = {
            "report_info": {
                "title": "Reporte de Pruebas Haka Lab",
                "engineer": "Ingeniero QA",
                "execution_date": "auto",
                "product": "Nombre del Producto",
                "company": "Nombre de la Empresa",
                "version": "1.0.0",
                "environment": "Testing"
            },
            "logos": {
                "primary_logo": {
                    "enabled": True,
                    "path": self._get_haka_lab_logo(),
                    "alt": "Haka Lab Logo",
                    "width": "200px"
                },
                "secondary_logo": {
                    "enabled": False,
                    "path": "",
                    "alt": "Company Logo",
                    "width": "200px"
                }
            },
            "styling": {
                "primary_color": "#2c3e50",
                "secondary_color": "#3498db",
                "accent_color": "#e74c3c",
                "success_color": "#27ae60",
                "warning_color": "#f39c12"
            }
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                    self._deep_merge(default_config, user_config)
            except Exception as e:
                self.logger.warning(f"Error cargando configuración {config_path}: {e}")
        
        # Buscar archivo de configuración en ubicaciones comunes
        common_paths = [
            'report_config.json',
            'config/report_config.json',
            '.hakalab/report_config.json',
            os.path.expanduser('~/.hakalab/report_config.json')
        ]
        
        for path in common_paths:
            if os.path.exists(path):
                try:
                    with open(path, 'r', encoding='utf-8') as f:
                        user_config = json.load(f)
                        self._deep_merge(default_config, user_config)
                        self.logger.info(f"Configuración cargada desde: {path}")
                        break
                except Exception as e:
                    self.logger.warning(f"Error cargando configuración {path}: {e}")
        
        return default_config
    
    def _deep_merge(self, base: dict, update: dict):
        """Merge recursivo de diccionarios"""
        for key, value in update.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._deep_merge(base[key], value)
            else:
                base[key] = value
    
    def _get_haka_lab_logo(self) -> str:
        """Retorna el logo de Haka Lab en base64 (mismo que html_reporter.py)"""
        haka_lab_svg = """
        <svg width="200" height="80" viewBox="0 0 400 160" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="hakaGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style="stop-color:#00bcd4;stop-opacity:1" />
                    <stop offset="100%" style="stop-color:#2196f3;stop-opacity:1" />
                </linearGradient>
            </defs>
            
            <!-- Haka Lab Logo -->
            <g fill="url(#hakaGradient)">
                <!-- H -->
                <rect x="20" y="30" width="12" height="60"/>
                <rect x="20" y="55" width="35" height="10"/>
                <rect x="43" y="30" width="12" height="60"/>
                
                <!-- a -->
                <circle cx="80" cy="70" r="15"/>
                <rect x="88" y="55" width="8" height="35"/>
                <rect x="72" y="75" width="16" height="8"/>
                
                <!-- k -->
                <rect x="120" y="30" width="12" height="60"/>
                <polygon points="132,55 145,42 155,42 142,55 155,68 145,68"/>
                <polygon points="132,65 145,78 155,78 142,65"/>
                
                <!-- a -->
                <circle cx="180" cy="70" r="15"/>
                <rect x="188" y="55" width="8" height="35"/>
                <rect x="172" y="75" width="16" height="8"/>
            </g>
            
            <!-- Lab -->
            <g fill="#34495e">
                <!-- L -->
                <rect x="240" y="30" width="12" height="60"/>
                <rect x="240" y="78" width="30" height="12"/>
                
                <!-- a -->
                <circle cx="290" cy="70" r="12"/>
                <rect x="296" y="58" width="6" height="32"/>
                <rect x="284" y="75" width="12" height="6"/>
                
                <!-- b -->
                <rect x="320" y="30" width="10" height="60"/>
                <ellipse cx="340" cy="55" rx="12" ry="10"/>
                <ellipse cx="340" cy="75" rx="12" ry="10"/>
            </g>
            
            <!-- Subtitle -->
            <text x="20" y="110" font-family="Arial, sans-serif" font-size="14" fill="#7f8c8d">
                CONTINUOUS VALUE DELIVERY
            </text>
        </svg>
        """
        
        # Convertir SVG a base64
        svg_bytes = haka_lab_svg.encode('utf-8')
        svg_base64 = base64.b64encode(svg_bytes).decode('utf-8')
        return f"data:image/svg+xml;base64,{svg_base64}"
    
    def _image_to_base64(self, image_path: str) -> str:
        """Convierte una imagen a base64 para embeber en HTML"""
        try:
            if not os.path.exists(image_path):
                return None
            
            with open(image_path, 'rb') as img_file:
                img_data = img_file.read()
                img_base64 = base64.b64encode(img_data).decode('utf-8')
                
                # Detectar tipo de imagen
                ext = os.path.splitext(image_path)[1].lower()
                mime_types = {
                    '.png': 'image/png',
                    '.jpg': 'image/jpeg',
                    '.jpeg': 'image/jpeg',
                    '.gif': 'image/gif',
                    '.svg': 'image/svg+xml'
                }
                mime_type = mime_types.get(ext, 'image/png')
                
                return f"data:{mime_type};base64,{img_base64}"
        except Exception as e:
            self.logger.warning(f"Error convirtiendo imagen a base64: {e}")
            return None
    
    def add_validation(self, validation_data: Dict[str, Any]):
        """Agrega una validación de IA al reporte"""
        self.ai_validations.append(validation_data)
    
    def generate_report(self, output_path: str = None) -> str:
        """Genera el reporte HTML de validaciones IA"""
        if not self.ai_validations:
            self.logger.info("No hay validaciones de IA para reportar")
            return None
        
        # Generar nombre de archivo si no se proporciona o si es un directorio
        if not output_path:
            timestamp = datetime.now().strftime("%d%m%Y_%H%M")
            output_dir = os.environ.get('AI_REPORT_PATH', 'reports/ai-reports')
            os.makedirs(output_dir, exist_ok=True)
            output_path = os.path.join(output_dir, f'ai_report_{timestamp}.html')
        elif os.path.isdir(output_path) or not output_path.endswith('.html'):
            # Si es un directorio o no tiene extensión .html, generar nombre de archivo
            timestamp = datetime.now().strftime("%d%m%Y_%H%M")
            os.makedirs(output_path, exist_ok=True)
            output_path = os.path.join(output_path, f'ai_report_{timestamp}.html')
        else:
            # Es un archivo completo, asegurar que el directorio existe
            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)
        
        # Generar análisis con Gemini si está habilitado
        gemini_analysis = None
        if os.environ.get('AI_REPORT_ANALYSIS', 'true').lower() == 'true':
            gemini_analysis = self._generate_gemini_analysis()
        
        # Generar HTML
        html_content = self._generate_html(gemini_analysis)
        
        # Guardar archivo
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        self.logger.info(f"📊 Reporte de Validaciones IA generado: {output_path}")
        return output_path
    
    def _generate_gemini_analysis(self) -> Dict[str, str]:
        """Genera análisis automático usando Gemini"""
        try:
            from google import genai
            
            # Preparar datos para análisis
            summary_data = {
                "total": len(self.ai_validations),
                "passed": len([v for v in self.ai_validations if v.get('passed', False)]),
                "failed": len([v for v in self.ai_validations if not v.get('passed', False)]),
                "avg_score": sum([v.get('score', 0) for v in self.ai_validations]) / len(self.ai_validations) if self.ai_validations else 0,
                "validations": self.ai_validations
            }
            
            # Prompt para Gemini
            prompt = f"""Analiza los siguientes resultados de validaciones de IA y genera un reporte ejecutivo.

Datos:
{json.dumps(summary_data, indent=2, ensure_ascii=False)}

Genera un análisis en formato JSON con esta estructura:
{{
  "resumen_ejecutivo": "Resumen general de los resultados (2-3 párrafos)",
  "patrones_identificados": ["Patrón 1", "Patrón 2", ...],
  "problemas_recurrentes": ["Problema 1", "Problema 2", ...],
  "recomendaciones": ["Recomendación 1", "Recomendación 2", ...],
  "conclusion": "Conclusión final"
}}

Sé conciso y enfócate en insights accionables."""
            
            # Llamar a Gemini
            api_key = os.environ.get('GEMINI_API_KEY')
            if not api_key:
                self.logger.warning("GEMINI_API_KEY no configurada, saltando análisis")
                return None
            
            client = genai.Client(api_key=api_key)
            model_name = os.environ.get('GEMINI_JUDGE_MODEL', 'gemini-2.0-flash-exp')
            
            response = client.models.generate_content(
                model=model_name,
                contents=prompt
            )
            
            # Parsear respuesta
            response_text = response.text.strip()
            if response_text.startswith('```json'):
                response_text = response_text.replace('```json', '').replace('```', '').strip()
            
            analysis = json.loads(response_text)
            return analysis
            
        except Exception as e:
            self.logger.warning(f"Error generando análisis con Gemini: {e}")
            return None
    
    def _generate_html(self, gemini_analysis: Dict[str, str] = None) -> str:
        """Genera el contenido HTML del reporte"""
        # Calcular métricas
        total = len(self.ai_validations)
        passed = len([v for v in self.ai_validations if v.get('passed', False)])
        failed = total - passed
        pass_rate = (passed / total * 100) if total > 0 else 0
        avg_score = sum([v.get('score', 0) for v in self.ai_validations]) / total if total > 0 else 0
        
        # Agrupar por tipo
        by_type = {}
        for v in self.ai_validations:
            vtype = v.get('type', 'Desconocido')
            if vtype not in by_type:
                by_type[vtype] = {'total': 0, 'passed': 0, 'failed': 0}
            by_type[vtype]['total'] += 1
            if v.get('passed', False):
                by_type[vtype]['passed'] += 1
            else:
                by_type[vtype]['failed'] += 1
        
        # Obtener configuración
        report_info = self.config.get('report_info', {})
        logos = self.config.get('logos', {})
        styling = self.config.get('styling', {})
        
        # Extraer colores para usar en el template
        primary_color = styling.get('primary_color', '#2c3e50')
        secondary_color = styling.get('secondary_color', '#3498db')
        accent_color = styling.get('accent_color', '#e74c3c')
        success_color = styling.get('success_color', '#27ae60')
        warning_color = styling.get('warning_color', '#f39c12')
        
        # Fecha de ejecución
        execution_date = report_info.get('execution_date', 'auto')
        if execution_date == 'auto':
            execution_date = datetime.now().strftime("%d/%m/%Y %H:%M")
        
        html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Validaciones IA - {report_info.get('product', 'Producto')}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, {secondary_color} 0%, {primary_color} 100%);
            padding: 20px;
            color: #333;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }}
        
        /* HEADER - Mismo formato que el reporte HTML existente */
        .header {{
            background: linear-gradient(135deg, {primary_color} 0%, {secondary_color} 100%);
            color: white;
            padding: 40px;
        }}
        
        .header-top {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }}
        
        .logos {{
            display: flex;
            gap: 30px;
            align-items: center;
        }}
        
        .logo img {{
            max-height: 60px;
            width: auto;
        }}
        
        .header-title {{
            text-align: center;
        }}
        
        .header-title h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }}
        
        .header-title .subtitle {{
            font-size: 1.2em;
            opacity: 0.9;
        }}
        
        .header-info {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }}
        
        .info-item {{
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 8px;
            backdrop-filter: blur(10px);
        }}
        
        .info-item .label {{
            font-size: 0.9em;
            opacity: 0.8;
            margin-bottom: 5px;
        }}
        
        .info-item .value {{
            font-size: 1.1em;
            font-weight: bold;
        }}
        
        /* CONTENT */
        .content {{
            padding: 40px;
        }}
        
        .section {{
            margin-bottom: 40px;
        }}
        
        .section-title {{
            font-size: 1.8em;
            color: {primary_color};
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid {secondary_color};
        }}
        
        /* METRICS */
        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        
        .metric-card {{
            background: linear-gradient(135deg, {secondary_color} 0%, {primary_color} 100%);
            color: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }}
        
        .metric-card.success {{
            background: linear-gradient(135deg, {success_color} 0%, #1e8449 100%);
        }}
        
        .metric-card.danger {{
            background: linear-gradient(135deg, {accent_color} 0%, #a93226 100%);
        }}
        
        .metric-card.warning {{
            background: linear-gradient(135deg, {warning_color} 0%, #d68910 100%);
        }}
        
        .metric-value {{
            font-size: 3em;
            font-weight: bold;
            margin-bottom: 10px;
        }}
        
        .metric-label {{
            font-size: 1.1em;
            opacity: 0.9;
        }}
        
        /* GEMINI ANALYSIS */
        .gemini-analysis {{
            background: linear-gradient(135deg, {secondary_color} 0%, {primary_color} 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        
        .gemini-analysis h3 {{
            font-size: 1.5em;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        
        .gemini-analysis p {{
            line-height: 1.6;
            margin-bottom: 15px;
        }}
        
        .gemini-analysis ul {{
            list-style: none;
            padding-left: 0;
        }}
        
        .gemini-analysis li {{
            padding: 8px 0;
            padding-left: 25px;
            position: relative;
        }}
        
        .gemini-analysis li:before {{
            content: "→";
            position: absolute;
            left: 0;
            font-weight: bold;
        }}
        
        /* VALIDATION CARDS - ACCORDION */
        .validation-card {{
            background: #f8f9fa;
            border-left: 5px solid {secondary_color};
            margin-bottom: 15px;
            border-radius: 8px;
            overflow: hidden;
        }}
        
        .validation-card.failed {{
            border-left-color: {accent_color};
        }}
        
        .validation-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 25px;
            cursor: pointer;
            background: white;
            transition: background 0.3s;
        }}
        
        .validation-header:hover {{
            background: #f8f9fa;
        }}
        
        .validation-title {{
            font-size: 1.3em;
            font-weight: bold;
            color: {primary_color};
            flex: 1;
        }}
        
        .validation-score {{
            font-size: 2em;
            font-weight: bold;
            margin-right: 15px;
        }}
        
        .validation-score.passed {{
            color: {success_color};
        }}
        
        .validation-score.failed {{
            color: {accent_color};
        }}
        
        .accordion-icon {{
            font-size: 1.5em;
            transition: transform 0.3s;
            color: {secondary_color};
        }}
        
        .accordion-icon.active {{
            transform: rotate(180deg);
        }}
        
        .validation-details {{
            padding: 0 25px;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out, padding 0.3s ease-out;
        }}
        
        .validation-details.active {{
            max-height: 5000px;
            padding: 25px;
            transition: max-height 0.5s ease-in, padding 0.3s ease-in;
        }}
        
        .detail-row {{
            margin-bottom: 10px;
        }}
        
        .detail-label {{
            font-weight: bold;
            color: {primary_color};
            margin-bottom: 5px;
        }}
        
        .detail-value {{
            background: white;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #dee2e6;
        }}
        
        /* DIMENSIONS */
        .dimensions-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }}
        
        .dimension-item {{
            background: white;
            padding: 15px;
            border-radius: 5px;
            border: 1px solid #dee2e6;
        }}
        
        .dimension-name {{
            font-size: 0.9em;
            color: #666;
            margin-bottom: 5px;
        }}
        
        .dimension-value {{
            font-size: 1.5em;
            font-weight: bold;
            color: {secondary_color};
        }}
        
        /* LISTS */
        .item-list {{
            list-style: none;
            padding: 0;
        }}
        
        .item-list li {{
            padding: 8px 0;
            padding-left: 25px;
            position: relative;
        }}
        
        .item-list.strengths li:before {{
            content: "✓";
            position: absolute;
            left: 0;
            color: {success_color};
            font-weight: bold;
        }}
        
        .item-list.errors li:before {{
            content: "✗";
            position: absolute;
            left: 0;
            color: {accent_color};
            font-weight: bold;
        }}
        
        .item-list.suggestions li:before {{
            content: "💡";
            position: absolute;
            left: 0;
        }}
        
        /* FOOTER */
        .footer {{
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            color: #666;
            border-top: 1px solid #dee2e6;
        }}
    </style>
    <script>
        // Función para toggle del acordeón
        function toggleAccordion(element) {{
            const details = element.nextElementSibling;
            const icon = element.querySelector('.accordion-icon');
            
            details.classList.toggle('active');
            icon.classList.toggle('active');
        }}
    </script>
</head>
<body>
    <div class="container">
        <!-- HEADER -->
        <div class="header">
            <div class="header-top">
                <div class="logos">"""
        
        # Logos
        if logos.get('primary_logo', {}).get('enabled', True):
            logo_path = logos['primary_logo'].get('path', '')
            if logo_path:
                # Si ya es data URI, usarlo directamente
                if logo_path.startswith('data:'):
                    logo_base64 = logo_path
                else:
                    logo_base64 = self._image_to_base64(logo_path)
                
                if logo_base64:
                    html += f"""
                    <div class="logo">
                        <img src="{logo_base64}" alt="{logos['primary_logo'].get('alt', 'Logo')}" style="width: {logos['primary_logo'].get('width', '200px')}">
                    </div>"""
        
        if logos.get('secondary_logo', {}).get('enabled', False):
            logo_path = logos['secondary_logo'].get('path', '')
            if logo_path:
                # Si ya es data URI, usarlo directamente
                if logo_path.startswith('data:'):
                    logo_base64 = logo_path
                else:
                    logo_base64 = self._image_to_base64(logo_path)
                
                if logo_base64:
                    html += f"""
                    <div class="logo">
                        <img src="{logo_base64}" alt="{logos['secondary_logo'].get('alt', 'Logo')}" style="width: {logos['secondary_logo'].get('width', '200px')}">
                    </div>"""
        
        html += f"""
                </div>
            </div>
            
            <div class="header-title">
                <h1>Reporte de Pruebas a Gen AI</h1>
                <div class="subtitle">{report_info.get('title', 'Reporte de Pruebas')}</div>
            </div>
            
            <div class="header-info">
                <div class="info-item">
                    <div class="label">Producto</div>
                    <div class="value">{report_info.get('product', 'N/A')}</div>
                </div>
                <div class="info-item">
                    <div class="label">Versión</div>
                    <div class="value">{report_info.get('version', 'N/A')}</div>
                </div>
                <div class="info-item">
                    <div class="label">Ambiente</div>
                    <div class="value">{report_info.get('environment', 'N/A')}</div>
                </div>
                <div class="info-item">
                    <div class="label">Ingeniero QA</div>
                    <div class="value">{report_info.get('engineer', 'N/A')}</div>
                </div>
                <div class="info-item">
                    <div class="label">Empresa</div>
                    <div class="value">{report_info.get('company', 'N/A')}</div>
                </div>
                <div class="info-item">
                    <div class="label">Fecha de Ejecución</div>
                    <div class="value">{execution_date}</div>
                </div>
            </div>
        </div>
        
        <!-- CONTENT -->
        <div class="content">
            <!-- METRICS -->
            <div class="section">
                <h2 class="section-title">📊 Métricas Generales</h2>
                <div class="metrics-grid">
                    <div class="metric-card">
                        <div class="metric-value">{total}</div>
                        <div class="metric-label">Total Validaciones</div>
                    </div>
                    <div class="metric-card success">
                        <div class="metric-value">{passed}</div>
                        <div class="metric-label">Aprobadas ({pass_rate:.1f}%)</div>
                    </div>
                    <div class="metric-card danger">
                        <div class="metric-value">{failed}</div>
                        <div class="metric-label">Reprobadas ({100-pass_rate:.1f}%)</div>
                    </div>
                    <div class="metric-card warning">
                        <div class="metric-value">{avg_score:.2f}</div>
                        <div class="metric-label">Score Promedio</div>
                    </div>
                </div>
            </div>"""
        
        # Gemini Analysis
        if gemini_analysis:
            html += f"""
            <div class="section">
                <div class="gemini-analysis">
                    <h3>🧠 Análisis Generado por Gemini</h3>
                    <p><strong>Resumen Ejecutivo:</strong></p>
                    <p>{gemini_analysis.get('resumen_ejecutivo', 'No disponible')}</p>
                    
                    <p><strong>Patrones Identificados:</strong></p>
                    <ul>
                        {''.join([f'<li>{p}</li>' for p in gemini_analysis.get('patrones_identificados', [])])}
                    </ul>
                    
                    <p><strong>Problemas Recurrentes:</strong></p>
                    <ul>
                        {''.join([f'<li>{p}</li>' for p in gemini_analysis.get('problemas_recurrentes', [])])}
                    </ul>
                    
                    <p><strong>Recomendaciones:</strong></p>
                    <ul>
                        {''.join([f'<li>{r}</li>' for r in gemini_analysis.get('recomendaciones', [])])}
                    </ul>
                    
                    <p><strong>Conclusión:</strong></p>
                    <p>{gemini_analysis.get('conclusion', 'No disponible')}</p>
                </div>
            </div>"""
        
        # Validations by Type
        html += f"""
            <div class="section">
                <h2 class="section-title">🎯 Validaciones por Tipo</h2>
                <div class="metrics-grid">"""
        
        for vtype, stats in by_type.items():
            html += f"""
                    <div class="metric-card">
                        <div class="metric-label">{vtype}</div>
                        <div class="metric-value" style="font-size: 1.5em;">{stats['passed']}/{stats['total']}</div>
                        <div class="metric-label">Aprobadas</div>
                    </div>"""
        
        html += """
                </div>
            </div>
            
            <!-- VALIDATIONS DETAIL -->
            <div class="section">
                <h2 class="section-title">📋 Detalle de Validaciones</h2>"""
        
        # Validation cards
        for validation in self.ai_validations:
            passed = validation.get('passed', False)
            score = validation.get('score', 0)
            threshold = validation.get('threshold', 0.8)
            
            html += f"""
                <div class="validation-card {'failed' if not passed else ''}">
                    <div class="validation-header" onclick="toggleAccordion(this)">
                        <div class="validation-title">{validation.get('scenario', 'Escenario')}</div>
                        <div class="validation-score {'passed' if passed else 'failed'}">
                            {score:.2f} / 1.00
                            {'✓' if passed else '✗'}
                        </div>
                        <div class="accordion-icon">▼</div>
                    </div>
                    
                    <div class="validation-details">
                        <div class="detail-row">
                            <div class="detail-label">Tipo:</div>
                            <div class="detail-value">{validation.get('type', 'N/A')}</div>
                        </div>
                        
                        <div class="detail-row">
                            <div class="detail-label">Umbral:</div>
                            <div class="detail-value">{threshold:.2f}</div>
                        </div>"""
            
            # Prompt y Respuesta
            if 'prompt' in validation:
                html += f"""
                        <div class="detail-row">
                            <div class="detail-label">Prompt:</div>
                            <div class="detail-value">{validation['prompt']}</div>
                        </div>"""
            
            if 'response' in validation:
                html += f"""
                        <div class="detail-row">
                            <div class="detail-label">Respuesta:</div>
                            <div class="detail-value">{validation['response'][:500]}{'...' if len(validation['response']) > 500 else ''}</div>
                        </div>"""
            
            # Dimensions
            if 'dimensions' in validation and validation['dimensions']:
                html += """
                        <div class="detail-row">
                            <div class="detail-label">Dimensiones:</div>
                            <div class="dimensions-grid">"""
                
                for dim_name, dim_value in validation['dimensions'].items():
                    html += f"""
                                <div class="dimension-item">
                                    <div class="dimension-name">{dim_name.replace('_', ' ').title()}</div>
                                    <div class="dimension-value">{dim_value:.2f}</div>
                                </div>"""
                
                html += """
                            </div>
                        </div>"""
            
            # Reasoning
            if 'reasoning' in validation:
                html += f"""
                        <div class="detail-row">
                            <div class="detail-label">Razonamiento:</div>
                            <div class="detail-value">{validation['reasoning']}</div>
                        </div>"""
            
            # Critical Errors
            if 'critical_errors' in validation and validation['critical_errors']:
                html += f"""
                        <div class="detail-row">
                            <div class="detail-label">Errores Críticos:</div>
                            <ul class="item-list errors">
                                {''.join([f'<li>{e}</li>' for e in validation['critical_errors']])}
                            </ul>
                        </div>"""
            
            # Strengths
            if 'strengths' in validation and validation['strengths']:
                html += f"""
                        <div class="detail-row">
                            <div class="detail-label">Fortalezas:</div>
                            <ul class="item-list strengths">
                                {''.join([f'<li>{s}</li>' for s in validation['strengths']])}
                            </ul>
                        </div>"""
            
            # Suggestions
            if 'suggestions' in validation and validation['suggestions']:
                html += f"""
                        <div class="detail-row">
                            <div class="detail-label">Sugerencias:</div>
                            <ul class="item-list suggestions">
                                {''.join([f'<li>{s}</li>' for s in validation['suggestions']])}
                            </ul>
                        </div>"""
            
            html += """
                    </div>
                </div>"""
        
        html += """
            </div>
        </div>
        
        <!-- FOOTER -->
        <div class="footer">
            <p>Generado por Haka Playwright Engine - Reporte de Validaciones IA</p>
            <p>Framework de Testing Automatizado con IA</p>
        </div>
    </div>
</body>
</html>"""
        
        return html
