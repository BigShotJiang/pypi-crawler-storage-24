"""
Sistema de Soft Assertions para Behave
Permite continuar ejecutando validaciones incluso después de un fallo
"""
from typing import List, Dict, Any, Optional
from datetime import datetime


class SoftAssertionError:
    """Representa un error de assertion capturado"""
    
    def __init__(self, step_name: str, error: AssertionError, step_index: int):
        self.step_name = step_name
        self.error = error
        self.error_message = str(error)
        self.step_index = step_index
        self.timestamp = datetime.now()
    
    def __str__(self):
        return f"[Step {self.step_index}] {self.step_name}: {self.error_message}"


class SoftAssertionManager:
    """
    Gestor de soft assertions para escenarios de Behave
    
    Permite que las validaciones continúen ejecutándose incluso después de un fallo,
    acumulando todos los errores para reportarlos al final del escenario.
    """
    
    def __init__(self):
        self.errors: List[SoftAssertionError] = []
        self.enabled = False
        self.current_step_index = 0
    
    def enable(self):
        """Activa el modo soft assertions para el escenario actual"""
        self.enabled = True
        self.errors = []
        self.current_step_index = 0
    
    def disable(self):
        """Desactiva el modo soft assertions"""
        self.enabled = False
        self.errors = []
        self.current_step_index = 0
    
    def is_enabled(self) -> bool:
        """Verifica si el modo soft assertions está activo"""
        return self.enabled
    
    def capture_error(self, step_name: str, error: AssertionError):
        """
        Captura un error de assertion sin detener la ejecución
        
        Args:
            step_name: Nombre del step que falló
            error: El AssertionError capturado
        """
        if self.enabled:
            soft_error = SoftAssertionError(step_name, error, self.current_step_index)
            self.errors.append(soft_error)
            print(f"\n⚠️  SOFT ASSERTION FAILED: {soft_error}")
            print(f"    Continuando con las siguientes validaciones...\n")
    
    def increment_step(self):
        """Incrementa el contador de steps"""
        self.current_step_index += 1
    
    def has_errors(self) -> bool:
        """Verifica si hay errores capturados"""
        return len(self.errors) > 0
    
    def get_errors(self) -> List[SoftAssertionError]:
        """Obtiene la lista de errores capturados"""
        return self.errors
    
    def get_error_count(self) -> int:
        """Obtiene el número de errores capturados"""
        return len(self.errors)
    
    def get_summary(self) -> Dict[str, Any]:
        """
        Obtiene un resumen de los errores capturados
        
        Returns:
            Dict con información del resumen
        """
        return {
            'total_errors': len(self.errors),
            'errors': [
                {
                    'step_index': err.step_index,
                    'step_name': err.step_name,
                    'error_message': err.error_message,
                    'timestamp': err.timestamp.isoformat()
                }
                for err in self.errors
            ]
        }
    
    def assert_all(self):
        """
        Lanza un AssertionError con todos los errores acumulados
        
        Este método debe llamarse al final del escenario para marcar
        el escenario como fallido si hubo errores.
        """
        if self.has_errors():
            error_messages = []
            error_messages.append(f"\n{'='*70}")
            error_messages.append(f"ESCENARIO FALLIDO: {len(self.errors)} validación(es) fallaron")
            error_messages.append(f"{'='*70}\n")
            
            for i, error in enumerate(self.errors, 1):
                error_messages.append(f"{i}. {error}")
                error_messages.append("")
            
            error_messages.append(f"{'='*70}")
            
            raise AssertionError('\n'.join(error_messages))
    
    def clear(self):
        """Limpia todos los errores capturados"""
        self.errors = []
        self.current_step_index = 0


def enable_soft_assertions(context):
    """
    Activa soft assertions para el escenario actual
    
    Debe llamarse en el step que inicia las validaciones (típicamente un Then)
    
    Args:
        context: Contexto de Behave
    """
    if not hasattr(context, 'soft_assertions'):
        context.soft_assertions = SoftAssertionManager()
    
    context.soft_assertions.enable()


def disable_soft_assertions(context):
    """
    Desactiva soft assertions y verifica errores acumulados
    
    Debe llamarse al final del escenario (en after_scenario)
    
    Args:
        context: Contexto de Behave
    """
    if hasattr(context, 'soft_assertions') and context.soft_assertions.is_enabled():
        context.soft_assertions.disable()


def capture_soft_assertion(context, step, error: AssertionError):
    """
    Captura un error de assertion en modo soft
    
    Args:
        context: Contexto de Behave
        step: Step actual
        error: AssertionError capturado
    """
    if hasattr(context, 'soft_assertions') and context.soft_assertions.is_enabled():
        context.soft_assertions.capture_error(step.name, error)
        return True
    return False


def assert_all_soft_assertions(context):
    """
    Verifica todos los errores acumulados y lanza AssertionError si hay alguno
    
    Debe llamarse al final del escenario (en after_scenario)
    
    Args:
        context: Contexto de Behave
    """
    if hasattr(context, 'soft_assertions'):
        context.soft_assertions.assert_all()
