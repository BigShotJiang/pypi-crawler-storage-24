"""
Hooks de Behave para integrar Soft Assertions
"""
from hakalab_framework.core.soft_assertions import SoftAssertionManager


def before_scenario_soft_assertions(context, scenario):
    """
    Hook antes de cada escenario para inicializar soft assertions
    
    Si el escenario tiene el tag @soft_assertions, activa el modo automáticamente
    """
    # Inicializar manager si no existe
    if not hasattr(context, 'soft_assertions'):
        context.soft_assertions = SoftAssertionManager()
    
    # Verificar si el escenario tiene el tag @soft_assertions
    if 'soft_assertions' in scenario.tags:
        context.soft_assertions.enable()
        print(f"\n✓ Soft Assertions activadas para: {scenario.name}")
        print(f"  Los steps continuarán ejecutándose incluso si fallan\n")
        
        # Inicializar lista para guardar steps fallidos reales
        if not hasattr(scenario, '_soft_assertion_failed_steps'):
            scenario._soft_assertion_failed_steps = []


def after_step_soft_assertions(context, step):
    """
    Hook después de cada step para permitir continuar después de un fallo
    
    Estrategia:
    1. Si el step falló con AssertionError, guardamos el estado real (failed)
    2. Marcamos el step como "passed" para que Behave continúe
    3. Al final, modificamos el reporte HTML para mostrar el estado real
    """
    if not hasattr(context, 'soft_assertions'):
        return
    
    # Incrementar contador de steps
    if context.soft_assertions.is_enabled():
        context.soft_assertions.increment_step()
    
    # Si el step falló y soft assertions está activo
    if step.status.name == 'failed' and context.soft_assertions.is_enabled():
        # Verificar si el error es un AssertionError
        if step.exception and isinstance(step.exception, AssertionError):
            # Capturar el error para el resumen final
            error_msg = str(step.exception)
            context.soft_assertions.capture_error(step.name, step.exception)
            
            # CRÍTICO: Guardar el estado real del step (failed)
            # Esto se usará para modificar el reporte HTML al final
            step._soft_assertion_real_status = 'failed'
            step._soft_assertion_error_message = error_msg
            
            # Guardar referencia al step en el escenario
            scenario = context.scenario
            if hasattr(scenario, '_soft_assertion_failed_steps'):
                scenario._soft_assertion_failed_steps.append({
                    'step': step,
                    'error': error_msg,
                    'step_number': context.soft_assertions.current_step_index
                })
            
            # CRÍTICO: Marcar el step como "passed" para que Behave continúe
            from behave.model_core import Status
            step.status = Status.passed
            step.exception = None
            step.error_message = None


def after_scenario_soft_assertions(context, scenario):
    """
    Hook después de cada escenario para mostrar resumen de errores
    
    Estrategia:
    1. Mostrar resumen de errores en consola
    2. Guardar información en atributos personalizados del escenario
    3. El reporte HTML usará estos atributos para mostrar el estado real
    """
    if not hasattr(context, 'soft_assertions'):
        return
    
    # Si soft assertions está activo y hay errores
    if context.soft_assertions.is_enabled():
        if context.soft_assertions.has_errors():
            # Imprimir resumen
            summary = context.soft_assertions.get_summary()
            print(f"\n{'='*70}")
            print(f"📊 RESUMEN DE SOFT ASSERTIONS")
            print(f"{'='*70}")
            print(f"Total de validaciones fallidas: {summary['total_errors']}")
            print(f"{'='*70}")
            
            # Imprimir cada error (usando objetos SoftAssertionError)
            for error_obj in context.soft_assertions.errors:
                print(f"  ❌ [Step {error_obj.step_index}] {error_obj.step_name}")
                print(f"     {error_obj.error_message}")
            
            print(f"{'='*70}")
            print(f"⚠️  IMPORTANTE: Revisa el reporte HTML para ver el estado real")
            print(f"    de los escenarios con @soft_assertions")
            print(f"{'='*70}\n")
            
            # CRÍTICO: Guardar información en atributos personalizados del escenario
            # El reporte HTML usará estos atributos para mostrar el estado real
            scenario._soft_assertion_has_failures = True
            
            # Crear un mensaje de error para el escenario
            error_messages = []
            for error_obj in context.soft_assertions.errors:
                error_messages.append(f"[Step {error_obj.step_index}] {error_obj.step_name}: {error_obj.error_message}")
            
            scenario._soft_assertion_error_summary = "\n".join(error_messages)
            
            # Incrementar contador global de escenarios fallidos con soft assertions
            if not hasattr(context, '_soft_assertion_failed_scenarios_count'):
                context._soft_assertion_failed_scenarios_count = 0
            context._soft_assertion_failed_scenarios_count += 1
        
        # Desactivar soft assertions
        context.soft_assertions.disable()
    
    # Limpiar errores para el siguiente escenario
    if hasattr(context, 'soft_assertions'):
        context.soft_assertions.clear()
