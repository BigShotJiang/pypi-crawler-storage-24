"""
Clase base para plugins de Behave.
"""
from abc import ABC, abstractmethod
from typing import Optional


class BasePlugin(ABC):
    """Clase base abstracta para plugins del framework."""
    
    def __init__(self):
        """Inicializa el plugin y verifica si está habilitado."""
        self.enabled = self._is_enabled()
    
    @abstractmethod
    def _is_enabled(self) -> bool:
        """
        Determina si el plugin está habilitado.
        Debe ser implementado por cada plugin.
        
        Returns:
            bool: True si el plugin está habilitado, False en caso contrario
        """
        pass
    
    def before_all(self, context) -> None:
        """Hook ejecutado antes de todas las features."""
        pass
    
    def after_all(self, context) -> None:
        """Hook ejecutado después de todas las features."""
        pass
    
    def before_feature(self, context, feature) -> None:
        """Hook ejecutado antes de cada feature."""
        pass
    
    def after_feature(self, context, feature) -> None:
        """Hook ejecutado después de cada feature."""
        pass
    
    def before_scenario(self, context, scenario) -> None:
        """Hook ejecutado antes de cada escenario."""
        pass
    
    def after_scenario(self, context, scenario) -> None:
        """Hook ejecutado después de cada escenario."""
        pass
    
    def before_step(self, context, step) -> None:
        """Hook ejecutado antes de cada step."""
        pass
    
    def after_step(self, context, step) -> None:
        """Hook ejecutado después de cada step."""
        pass
