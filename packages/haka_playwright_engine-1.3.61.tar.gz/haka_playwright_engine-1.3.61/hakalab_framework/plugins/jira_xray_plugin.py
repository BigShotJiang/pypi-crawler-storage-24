"""
Plugin para integración con Jira y Xray.
"""
import os
from .base_plugin import BasePlugin
from hakalab_framework.integrations.behave_hooks import (
    before_all_jira_xray,
    before_feature_jira_xray,
    after_scenario_jira_xray,
    after_feature_jira_xray
)


class JiraXrayPlugin(BasePlugin):
    """Plugin para integración con Jira y Xray."""
    
    def _is_enabled(self) -> bool:
        """Plugin habilitado si JIRA_ENABLED=true."""
        return os.getenv('JIRA_ENABLED', 'false').lower() == 'true'
    
    def before_all(self, context) -> None:
        """Configura la integración con Jira/Xray."""
        if self.enabled:
            before_all_jira_xray(context)
    
    def before_feature(self, context, feature) -> None:
        """Hook antes de cada feature."""
        if self.enabled:
            before_feature_jira_xray(context, feature)
    
    def after_scenario(self, context, scenario) -> None:
        """Recopila resultados del escenario para Jira/Xray."""
        if self.enabled:
            after_scenario_jira_xray(context, scenario)
    
    def after_feature(self, context, feature) -> None:
        """Finaliza la feature en Jira/Xray."""
        if self.enabled:
            after_feature_jira_xray(context, feature)
    
    def after_all(self, context) -> None:
        """Procesa la integración con Jira/Xray."""
        if self.enabled and hasattr(context, 'jira_xray_hooks'):
            try:
                context.jira_xray_hooks.after_all(context)
                print("\n✅ Integración Jira/Xray completada")
            except Exception as e:
                context.logger.error(f"❌ Error en integración Jira/Xray: {e}")
