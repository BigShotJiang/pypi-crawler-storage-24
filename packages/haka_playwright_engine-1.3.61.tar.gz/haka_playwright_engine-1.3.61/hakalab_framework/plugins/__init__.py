"""
Sistema de plugins para Haka Framework
"""
from .base_plugin import BasePlugin
from .html_report_plugin import HtmlReportPlugin
from .ai_report_plugin import AIReportPlugin
from .soft_assertions_plugin import SoftAssertionsPlugin
from .screenshot_plugin import ScreenshotPlugin
from .jira_xray_plugin import JiraXrayPlugin
from .plugin_manager import PluginManager

__all__ = [
    'BasePlugin',
    'HtmlReportPlugin',
    'AIReportPlugin',
    'SoftAssertionsPlugin',
    'ScreenshotPlugin',
    'JiraXrayPlugin',
    'PluginManager'
]
