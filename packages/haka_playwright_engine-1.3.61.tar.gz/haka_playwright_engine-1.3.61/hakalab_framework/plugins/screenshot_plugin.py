"""
Plugin para captura de screenshots.
"""
import os
from .base_plugin import BasePlugin
from hakalab_framework.core.screenshot_manager import (
    take_screenshot,
    take_screenshot_on_failure,
    cleanup_directories,
    get_screenshots_summary
)


class ScreenshotPlugin(BasePlugin):
    """Plugin para captura automática de screenshots."""
    
    def _is_enabled(self) -> bool:
        """Plugin habilitado si HTML_REPORT_CAPTURE_ALL_STEPS=true."""
        return os.getenv('HTML_REPORT_CAPTURE_ALL_STEPS', 'true').lower() == 'true'
    
    def before_all(self, context) -> None:
        """Limpia directorios de screenshots si está configurado."""
        if self.enabled:
            cleanup_directories()
    
    def after_step(self, context, step) -> None:
        """Captura screenshot después de cada step."""
        if self.enabled and hasattr(context, 'page') and context.page:
            try:
                # Generar nombre del screenshot basado en el paso
                step_name = step.name.replace(' ', '_').replace('"', '').replace("'", '')
                screenshot_name = f"step_{step.line}_{step_name[:50]}"
                
                # Capturar screenshot
                take_screenshot(context, screenshot_name)
            except Exception as e:
                context.logger.debug(f"Error capturando screenshot: {e}")
    
    def after_scenario(self, context, scenario) -> None:
        """Captura screenshot en caso de fallo."""
        if self.enabled:
            try:
                take_screenshot_on_failure(context, scenario)
            except Exception as e:
                context.logger.debug(f"Error capturando screenshot de fallo: {e}")
    
    def after_all(self, context) -> None:
        """Muestra resumen de screenshots capturados."""
        if self.enabled:
            try:
                summary = get_screenshots_summary()
                if summary["total"] > 0:
                    print(f"\n📸 Screenshots: {summary['total']} total, {summary['failed']} fallos")
            except Exception as e:
                context.logger.debug(f"Error obteniendo resumen de screenshots: {e}")
