"""
Plugin para Soft Assertions.
"""
import os
from .base_plugin import BasePlugin
from hakalab_framework.core.soft_assertion_hooks import (
    before_scenario_soft_assertions,
    after_step_soft_assertions,
    after_scenario_soft_assertions
)


class SoftAssertionsPlugin(BasePlugin):
    """Plugin para soft assertions (validaciones continuas)."""
    
    def _is_enabled(self) -> bool:
        """Plugin siempre habilitado, se activa por tag @soft_assertions."""
        return True
    
    def before_scenario(self, context, scenario) -> None:
        """Inicializa soft assertions si el escenario tiene el tag."""
        if self.enabled:
            before_scenario_soft_assertions(context, scenario)
    
    def after_step(self, context, step) -> None:
        """Captura errores de soft assertions."""
        if self.enabled:
            after_step_soft_assertions(context, step)
    
    def after_scenario(self, context, scenario) -> None:
        """Verifica errores acumulados de soft assertions."""
        if self.enabled:
            after_scenario_soft_assertions(context, scenario)
