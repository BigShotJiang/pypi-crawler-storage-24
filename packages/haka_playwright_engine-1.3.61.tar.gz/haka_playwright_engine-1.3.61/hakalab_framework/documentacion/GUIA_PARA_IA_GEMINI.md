# GUÍA PARA IA: Haka Playwright Engine Framework

> **Audiencia:** Esta guía está diseñada para ser leída por IAs (como Gemini) que asisten a desarrolladores en la creación de pruebas automatizadas con este framework.

---

## 🎯 OBJETIVO DEL FRAMEWORK

**Haka Playwright Engine** es un framework de testing BDD (Behavior-Driven Development) que combina:
- **Playwright** (automatización de navegadores)
- **Behave** (framework BDD en Python con sintaxis Gherkin)
- **674+ pasos preconstruidos** listos para usar

### Filosofía Principal: REUTILIZAR, NO REINVENTAR

⚠️ **REGLA DE ORO:** Antes de crear un nuevo paso, SIEMPRE busca en los 674 pasos existentes.

**Razones:**
1. Ahorra tiempo de desarrollo
2. Mantiene consistencia en el código
3. Los pasos existentes están probados y documentados
4. Evita duplicación de funcionalidad

---

## 📚 INVENTARIO DE PASOS DISPONIBLES

El framework tiene **674 pasos** organizados en **34 categorías**:

### Categorías Principales:
- **Navegación:** Ir a URLs, recargar, navegar atrás/adelante
- **Interacción:** Clicks, llenar campos, drag & drop
- **Validación:** Verificar elementos, textos, atributos
- **API Testing:** Peticiones HTTP, validación de respuestas JSON
- **Variables:** Crear, guardar, usar variables en escenarios
- **Archivos:** Subir/descargar archivos, leer CSVs
- **Base de Datos:** Consultas SQL, validaciones
- **Validación Semántica:** Comparación de textos con IA
- **Gemini AI:** Evaluación de respuestas con IA
- **Supabase Vector:** Búsqueda vectorial y RAG
- **Soft Assertions:** Validaciones continuas

### Dónde Consultar los Pasos:
```
hakalab_framework/documentacion/INVENTARIO_COMPLETO_PASOS.txt
hakalab_framework/documentacion/INVENTARIO_STEPS_POR_CATEGORIA.txt
```

---

## 🔍 PROCESO PARA CREAR PRUEBAS

### PASO 1: Entender el Requerimiento del Usuario

Cuando un usuario pide crear una prueba, identifica:
- ¿Qué se está probando? (Login, formulario, API, etc.)
- ¿Qué acciones se necesitan? (Navegar, llenar campos, hacer click)
- ¿Qué validaciones se requieren? (Verificar texto, elemento visible, respuesta API)

### PASO 2: Buscar Pasos Existentes

**Antes de escribir CUALQUIER paso, busca en el inventario:**

```gherkin
# ❌ NO HAGAS ESTO (crear paso nuevo sin buscar)
Given creo un nuevo paso para navegar a la URL

# ✅ HAZ ESTO (usar paso existente)
Given navego a "https://example.com"
```

**Cómo buscar:**
1. Lee `INVENTARIO_COMPLETO_PASOS.txt`
2. Busca por palabras clave: "navego", "click", "verifico", "API", etc.
3. Si encuentras algo similar, úsalo

### PASO 3: Crear Paso SOLO si No Existe

Si después de buscar exhaustivamente NO encuentras un paso que haga lo que necesitas:

1. **Verifica que realmente no existe** (busca variantes en español e inglés)
2. **Considera si puedes combinar pasos existentes** en lugar de crear uno nuevo
3. **Si definitivamente necesitas crear uno nuevo**, sigue las reglas de la siguiente sección

---

## 🛠️ CÓMO CREAR PASOS PERSONALIZADOS

### Ubicación de Archivos

```
features/
├── steps/
│   └── custom_steps.py          # Tus pasos personalizados
├── environment.py                # Configuración de hooks
└── mi_prueba.feature            # Tus escenarios
```

### Anatomía de un Paso

```python
from behave import given, when, then, step

@step('navego a la página de login')
def step_navigate_to_login(context):
    """Navega a la página de login de la aplicación"""
    context.page.goto("https://example.com/login")
```

**Componentes:**
- `@step`: Decorador (puede ser @given, @when, @then, o @step para cualquiera)
- `'texto del paso'`: Texto exacto que se usa en el .feature
- `context`: Objeto que contiene el estado compartido (page, variables, etc.)

### Pasos con Parámetros

```python
@step('navego a "{url}"')
def step_navigate_to_url(context, url):
    """Navega a una URL específica"""
    context.page.goto(url)
```

Uso en .feature:
```gherkin
Given navego a "https://example.com"
```

### ⚠️ REGLA CRÍTICA: Evitar Ambigüedad

**Behave NO puede distinguir pasos cuando uno es prefijo del otro:**

```python
# ❌ INCORRECTO (Causa AmbiguousStep)
@step('verifico que el elemento "{name}" está visible')
@step('verifico que el elemento "{name}" está visible en la página')
```

**Solución: Usar palabras clave diferentes**

```python
# ✅ CORRECTO
@step('verifico que el elemento "{name}" está visible')
@step('verifico que el elemento "{name}" aparece en la página')
```

### Acceso al Navegador

```python
@step('hago click en el botón de login')
def step_click_login(context):
    # context.page es la instancia de Playwright Page
    context.page.click("#login-button")
```

---

## 📦 VARIABLES EN EL FRAMEWORK

### 1. Variables de Entorno (.env)

```bash
# .env
BASE_URL=https://example.com
USERNAME=test_user
PASSWORD=test_pass
```

Uso en pasos:
```python
import os
url = os.getenv('BASE_URL')
```

Uso en .feature:
```gherkin
Given navego a la URL de entorno "BASE_URL"
```

### 2. Variables de Contexto (entre pasos)

```gherkin
# Guardar valor en variable
When extraigo el texto del elemento "user-name" y lo guardo en "username"

# Usar variable guardada
Then verifico que la variable "username" contiene "John"
```

En código Python:
```python
# Guardar
context.variables['username'] = "John"

# Leer
username = context.variables.get('username')
```

### 3. Variables en Escenarios (Scenario Outline)

```gherkin
Scenario Outline: Login con múltiples usuarios
  Given navego a "https://example.com/login"
  When ingreso "<username>" en el campo "user"
  And ingreso "<password>" en el campo "pass"
  Then verifico que el login es "<resultado>"

  Examples:
    | username | password | resultado |
    | admin    | admin123 | exitoso   |
    | user     | wrong    | fallido   |
```

---

## 🎯 LOCALIZADORES DE ELEMENTOS

### JSON POM (Page Object Model)

El framework soporta **3 formatos** de localizadores en JSON POM:

#### 1. Formato Simple (String)

**Ubicación:** `json_poms/login_page.json`

```json
{
  "username_field": "#username",
  "password_field": "#password",
  "login_button": "button[type='submit']",
  "error_message": ".error-msg"
}
```

**Uso en .feature:**
```gherkin
Given cargo los localizadores desde "login_page.json"
When ingreso "admin" en el elemento "username_field"
And hago click en el elemento "login_button"
```

#### 2. Formato con Fallbacks (Diccionario)

Para mayor robustez, puedes definir selectores alternativos:

```json
{
  "submit_button": {
    "selector": "button[type='submit']",
    "fallbacks": [
      "#submit-btn",
      "//button[text()='Submit']",
      ".btn-primary"
    ]
  }
}
```

**Comportamiento:**
- Intenta el `selector` principal primero
- Si no lo encuentra, prueba cada `fallback` en orden
- Usa el primero que encuentre en la página

**Uso en .feature:**
```gherkin
Given cargo los localizadores desde "form_page.json"
When hago click en el elemento "submit_button"
# Automáticamente intenta los fallbacks si el selector principal falla
```

#### 3. Formato por Role (Diccionario) ⭐ NUEVO

Usa `get_by_role()` de Playwright para localizadores más accesibles y robustos:

```json
{
  "name_textbox": {
    "role": "textbox",
    "type": "name",
    "value": "Ingresa tu nombre"
  },
  "email_input": {
    "role": "textbox",
    "type": "name",
    "value": "Email"
  },
  "login_button": {
    "role": "button",
    "type": "exact",
    "value": "Login"
  },
  "search_box": {
    "role": "searchbox",
    "type": "name",
    "value": "Buscar productos"
  }
}
```

**Parámetros:**
- `role`: Rol ARIA del elemento (textbox, button, link, checkbox, etc.)
- `type`: Tipo de búsqueda
  - `"name"`: Busca por nombre accesible (aria-label, label, placeholder, etc.)
  - `"exact"`: Busca por nombre exacto (coincidencia exacta)
- `value`: Valor a buscar (nombre del elemento)

**Roles soportados por Playwright:**
- `textbox` - Campos de texto
- `button` - Botones
- `link` - Enlaces
- `checkbox` - Checkboxes
- `radio` - Radio buttons
- `combobox` - Dropdowns/Select
- `searchbox` - Campos de búsqueda
- `listbox` - Listas
- `tab` - Pestañas
- `heading` - Encabezados (h1, h2, etc.)
- Y muchos más...

**Ventajas de usar Roles:**
- ✅ Más resistente a cambios en el HTML
- ✅ Mejor accesibilidad (usa atributos ARIA)
- ✅ Más legible y semántico
- ✅ Funciona con labels, aria-label, placeholder, etc.

**Uso en .feature:**
```gherkin
Given cargo los localizadores desde "form_page.json"
When ingreso "Juan Pérez" en el elemento "name_textbox"
And ingreso "juan@email.com" en el elemento "email_input"
And hago click en el elemento "login_button"
```

**Equivalencia con Playwright:**
```python
# JSON POM con role
{"role": "textbox", "type": "name", "value": "Ingresa tu nombre"}

# Se convierte en:
page.get_by_role("textbox", name="Ingresa tu nombre")
```

### Comparación de los 3 Formatos

```json
{
  "// FORMATO 1: Simple (string)": "",
  "username_simple": "#username",
  
  "// FORMATO 2: Con Fallbacks (diccionario)": "",
  "username_fallback": {
    "selector": "#username",
    "fallbacks": ["input[name='username']", "//input[@type='text']"]
  },
  
  "// FORMATO 3: Por Role (diccionario)": "",
  "username_role": {
    "role": "textbox",
    "type": "name",
    "value": "Username"
  }
}
```

**¿Cuándo usar cada formato?**

| Formato | Cuándo Usar |
|---------|-------------|
| **Simple** | Elementos con selectores estables (IDs únicos) |
| **Fallbacks** | Elementos que pueden cambiar de selector |
| **Role** | Formularios, botones, elementos interactivos (RECOMENDADO) |

### Localizadores Directos

Si no quieres usar JSON POM, puedes usar localizadores directos:

```gherkin
# CSS Selector
When hago click en el elemento con css "#login-button"

# XPath
When hago click en el elemento con xpath "//button[@id='login']"

# Texto
When hago click en el elemento con texto "Login"
```

---

## 📝 ESTRUCTURA DE ARCHIVOS .FEATURE

### Sintaxis Gherkin Básica

```gherkin
# language: es
Característica: Login de usuarios
  Como usuario del sistema
  Quiero poder iniciar sesión
  Para acceder a mi cuenta

  Antecedentes:
    Given navego a "https://example.com/login"
    And cargo los localizadores desde "login_page.json"

  @smoke @login
  Escenario: Login exitoso con credenciales válidas
    When ingreso "admin" en el elemento "username_field"
    And ingreso "admin123" en el elemento "password_field"
    And hago click en el elemento "login_button"
    Then verifico que el elemento "welcome_message" está visible
    And verifico que el texto del elemento "welcome_message" contiene "Bienvenido"
```

### Componentes:

- **Característica:** Descripción de alto nivel
- **Antecedentes:** Pasos que se ejecutan antes de cada escenario
- **Escenario:** Caso de prueba específico
- **@tags:** Etiquetas para filtrar ejecución
- **Given/When/Then/And:** Palabras clave de Gherkin

---

## 🔄 AGRUPAR PASOS COMUNES

### Opción 1: Usar Antecedentes (Background)

```gherkin
Característica: Gestión de productos

  Antecedentes:
    Given navego a "https://example.com"
    And inicio sesión como "admin"
    And navego a la sección "productos"

  Escenario: Crear producto
    When hago click en "nuevo producto"
    # ...

  Escenario: Editar producto
    When selecciono el producto "Laptop"
    # ...
```

### Opción 2: Crear Paso Compuesto

```python
@step('inicio sesión como "{role}"')
def step_login_as_role(context, role):
    """Paso compuesto que agrupa login completo"""
    credentials = {
        'admin': ('admin', 'admin123'),
        'user': ('user', 'user123')
    }
    username, password = credentials[role]
    
    context.page.goto("https://example.com/login")
    context.page.fill("#username", username)
    context.page.fill("#password", password)
    context.page.click("#login-button")
```

### Opción 3: Usar Scenario Outline

```gherkin
Scenario Outline: Validar campos del formulario
  When ingreso "<valor>" en el campo "<campo>"
  Then verifico que el campo "<campo>" contiene "<valor>"

  Examples:
    | campo    | valor           |
    | nombre   | Juan Pérez      |
    | email    | juan@email.com  |
    | telefono | 123456789       |
```

---

## 🧪 CASOS DE USO COMUNES

### 1. Login Simple

```gherkin
Scenario: Login exitoso
  Given navego a "https://example.com/login"
  When ingreso "admin" en el campo con id "username"
  And ingreso "admin123" en el campo con id "password"
  And hago click en el botón con css "button[type='submit']"
  Then verifico que el elemento con css ".welcome" está visible
```

### 2. API Testing

```gherkin
Scenario: Obtener usuario por ID
  When hago una petición GET a "https://api.example.com/users/1"
  Then el código de respuesta debe ser 200
  And el campo "name" de la respuesta debe ser "John Doe"
  And el campo "email" de la respuesta debe ser "john@example.com"
```

### 3. Formulario con Validaciones

```gherkin
@soft_assertions
Scenario: Validar campos requeridos
  Given navego a "https://example.com/register"
  When hago click en el botón "submit"
  Then verifico que el elemento "email_error" está visible
  And verifico que el elemento "password_error" está visible
  And verifico que el elemento "name_error" está visible
```

### 4. Uso de Variables

```gherkin
Scenario: Crear y usar variable
  Given navego a "https://example.com/profile"
  When extraigo el texto del elemento "user-id" y lo guardo en "userId"
  And navego a "https://example.com/orders"
  Then verifico que la URL contiene la variable "userId"
```

---

## 🏷️ TAGS ESPECIALES

### @soft_assertions
Permite que las validaciones continúen incluso si fallan:

```gherkin
@soft_assertions
Scenario: Validar múltiples campos
  Then verifico que el campo "name" contiene "John"
  And verifico que el campo "email" contiene "john@example.com"
  And verifico que el campo "phone" contiene "123456789"
  # Si alguno falla, los demás se ejecutan igual
```

### @no_browser
Para pruebas que no necesitan navegador (APIs, validaciones semánticas):

```gherkin
@no_browser
Scenario: Validar respuesta de API
  When hago una petición GET a "https://api.example.com/users"
  Then el código de respuesta debe ser 200
```

### Tags de Organización

```gherkin
@smoke @login @critical
Scenario: Login crítico

@regression @api
Scenario: Test de regresión de API
```

Ejecutar solo smoke tests:
```bash
behave --tags=smoke
```

---

## 🔧 CONFIGURACIÓN DEL PROYECTO

### Estructura Recomendada

```
mi_proyecto/
├── features/
│   ├── steps/
│   │   └── custom_steps.py
│   ├── environment.py
│   ├── login.feature
│   └── api.feature
├── json_poms/
│   ├── login_page.json
│   └── products_page.json
├── .env
├── behave.ini
└── requirements.txt
```

### .env (Variables de Entorno)

```bash
# URLs
BASE_URL=https://example.com
API_URL=https://api.example.com

# Credenciales
ADMIN_USER=admin
ADMIN_PASS=admin123

# Configuración
HEADLESS=false
BROWSER=chromium
TIMEOUT=30000
```

### behave.ini (Configuración de Behave)

```ini
[behave]
default_format = pretty
show_timings = true
show_skipped = false
color = true
```

---

## 🎨 MEJORES PRÁCTICAS

### 1. Nombres Descriptivos

```gherkin
# ❌ Malo
Scenario: Test 1
  When hago algo
  Then verifico algo

# ✅ Bueno
Scenario: Login exitoso con credenciales de administrador
  When ingreso credenciales de administrador
  Then verifico que accedo al dashboard
```

### 2. Un Escenario = Una Funcionalidad

```gherkin
# ❌ Malo (hace demasiado)
Scenario: Login y crear producto y editarlo
  Given inicio sesión
  When creo un producto
  And edito el producto
  And elimino el producto

# ✅ Bueno (enfocado)
Scenario: Crear producto después de login
  Given inicio sesión como administrador
  When creo un producto "Laptop"
  Then verifico que el producto fue creado
```

### 3. Usar Antecedentes para Setup Común

```gherkin
Característica: Gestión de productos

  Antecedentes:
    Given inicio sesión como administrador
    And navego a la sección de productos

  Scenario: Crear producto
    # Ya estoy logueado y en productos
    When hago click en "nuevo"
```

### 4. Variables para Datos Dinámicos

```gherkin
# ✅ Bueno (reutilizable)
Scenario: Crear usuario y validar
  When creo un usuario con email "user@example.com"
  And guardo el ID del usuario en "userId"
  Then verifico que el usuario con ID "{userId}" existe
```

### 5. Soft Assertions para Validaciones Múltiples

```gherkin
@soft_assertions
Scenario: Validar formulario completo
  # Todas las validaciones se ejecutan
  Then verifico campo "nombre"
  And verifico campo "email"
  And verifico campo "telefono"
```

### 6. Usar Localizadores por Role (RECOMENDADO)

```json
// ✅ MEJOR: Usar roles (más robusto y accesible)
{
  "username_field": {
    "role": "textbox",
    "type": "name",
    "value": "Username"
  },
  "login_button": {
    "role": "button",
    "type": "exact",
    "value": "Login"
  }
}

// ❌ MENOS ROBUSTO: Selectores CSS/XPath
{
  "username_field": "#username",
  "login_button": "button[type='submit']"
}
```

**Ventajas de usar roles:**
- Más resistente a cambios en el HTML
- Mejor accesibilidad
- Más legible y mantenible
- Funciona con labels, aria-label, placeholder

---

## ⚠️ ERRORES COMUNES A EVITAR

### 1. Crear Pasos Duplicados

```gherkin
# ❌ NO HAGAS ESTO
@step('voy a la URL "{url}"')  # Ya existe "navego a"

# ✅ USA EL EXISTENTE
Given navego a "https://example.com"
```

### 2. Pasos Ambiguos

```python
# ❌ INCORRECTO (ambiguo)
@step('verifico que el elemento "{name}"')
@step('verifico que el elemento "{name}" está visible')

# ✅ CORRECTO
@step('verifico que existe el elemento "{name}"')
@step('verifico que el elemento "{name}" está visible')
```

### 3. Hardcodear Datos

```gherkin
# ❌ Malo
When ingreso "admin" en el campo "username"

# ✅ Mejor (usar variable de entorno)
When ingreso el valor de entorno "ADMIN_USER" en el campo "username"
```

### 4. No Usar JSON POM

```gherkin
# ❌ Malo (localizadores en el .feature)
When hago click en el elemento con css "#login-btn"

# ✅ Mejor (usar JSON POM)
Given cargo los localizadores desde "login_page.json"
When hago click en el elemento "login_button"
```

---

## 📖 RECURSOS Y DOCUMENTACIÓN

### Archivos de Referencia

```
hakalab_framework/documentacion/
├── INVENTARIO_COMPLETO_PASOS.txt          # Lista de todos los pasos
├── INVENTARIO_STEPS_POR_CATEGORIA.txt     # Pasos por categoría
├── GUIA_COMPLETA_USO.txt                  # Guía completa del framework
├── GUIA_API_TESTING_NotebookLM.txt        # Testing de APIs
├── GUIA_VALIDACION_SEMANTICA_IA.txt       # Validación con IA
├── GUIA_SOFT_ASSERTIONS.txt               # Soft Assertions
└── GUIA_SUPABASE_VECTOR.txt               # RAG y búsqueda vectorial
```

### Ejemplos Completos

```
hakalab_framework/examples/
├── api_testing_advanced_example.feature
├── gemini_evaluation_example.feature
├── semantic_validation_example.feature
├── soft_assertions_example.feature
└── rag_supabase_gemini_example.feature
```

---

## 🤖 GUÍA RÁPIDA PARA IA

### Cuando un Usuario Pide Crear una Prueba:

1. **Pregunta:** ¿Qué se está probando?
2. **Busca:** En `INVENTARIO_COMPLETO_PASOS.txt` los pasos necesarios
3. **Reutiliza:** Usa pasos existentes siempre que sea posible
4. **Estructura:** Crea el .feature con Given/When/Then
5. **Variables:** Usa variables de entorno para datos sensibles
6. **Localizadores:** Sugiere usar JSON POM para elementos
7. **Tags:** Agrega tags apropiados (@smoke, @regression, etc.)
8. **Valida:** Verifica que no hay pasos ambiguos

### Checklist Antes de Responder:

- [ ] ¿Busqué en el inventario de pasos?
- [ ] ¿Estoy reutilizando pasos existentes?
- [ ] ¿Los nombres de escenarios son descriptivos?
- [ ] ¿Usé variables para datos dinámicos?
- [ ] ¿Sugerí JSON POM para localizadores?
- [ ] ¿Usé localizadores por role cuando sea posible? (RECOMENDADO)
- [ ] ¿Agregué fallbacks para selectores que pueden cambiar?
- [ ] ¿Agregué tags apropiados?
- [ ] ¿Evité crear pasos ambiguos?

### Ejemplo de Respuesta Ideal:

```markdown
He creado la prueba usando los pasos existentes del framework:

**Archivo:** features/login.feature

```gherkin
# language: es
@smoke @login
Característica: Login de usuarios

  Antecedentes:
    Given navego a la URL de entorno "BASE_URL"
    And cargo los localizadores desde "login_page.json"

  Escenario: Login exitoso con credenciales válidas
    When ingreso el valor de entorno "ADMIN_USER" en el elemento "username_field"
    And ingreso el valor de entorno "ADMIN_PASS" en el elemento "password_field"
    And hago click en el elemento "login_button"
    Then verifico que el elemento "welcome_message" está visible
    And verifico que el texto del elemento "welcome_message" contiene "Bienvenido"
```

**Archivo:** json_poms/login_page.json

```json
{
  "username_field": {
    "role": "textbox",
    "type": "name",
    "value": "Username"
  },
  "password_field": {
    "role": "textbox",
    "type": "name",
    "value": "Password"
  },
  "login_button": {
    "role": "button",
    "type": "exact",
    "value": "Login"
  },
  "welcome_message": {
    "selector": ".welcome-msg",
    "fallbacks": ["#welcome", "//div[contains(@class, 'welcome')]"]
  }
}
```

**Notas:**
- Todos los pasos usados ya existen en el framework
- Las credenciales se leen desde variables de entorno (.env)
- Los localizadores usan formato por role (más robusto)
- El mensaje de bienvenida tiene fallbacks por si cambia el selector
- Tag @smoke para pruebas críticas
```

---

## 🎓 CONCLUSIÓN

Este framework está diseñado para **maximizar la reutilización** y **minimizar el código personalizado**.

**Recuerda:**
1. ✅ Busca SIEMPRE en los 674 pasos existentes
2. ✅ Usa variables de entorno para configuración
3. ✅ Usa JSON POM para localizadores
4. ✅ Agrupa pasos comunes en Antecedentes
5. ✅ Usa tags para organizar pruebas
6. ✅ Crea pasos personalizados SOLO cuando sea necesario
7. ✅ Evita pasos ambiguos

**El objetivo es escribir pruebas legibles, mantenibles y reutilizables usando el poder de los 674 pasos preconstruidos.**
