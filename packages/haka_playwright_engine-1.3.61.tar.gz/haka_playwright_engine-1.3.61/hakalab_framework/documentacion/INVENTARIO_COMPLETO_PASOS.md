# Inventario Completo de Pasos - Haka Playwright Engine

Este documento contiene todos los pasos disponibles en el framework, organizados por categorías y con descripciones breves.

**Total de categorías:** 34  
**Total de pasos:** 674

---

## Tabla de Contenidos

- [API Testing](#api-testing)
- [Accessibility](#accessibility)
- [Archivos](#archivos)
- [Avanzado](#avanzado)
- [Base de Datos](#base-de-datos)
- [CSV](#csv)
- [Combobox y Dropdowns](#combobox-y-dropdowns)
- [Control del Navegador](#control-del-navegador)
- [Drag & Drop](#drag-&-drop)
- [Elementos Web](#elementos-web)
- [Email](#email)
- [Entrada Avanzada](#entrada-avanzada)
- [Esperas](#esperas)
- [Formularios Avanzados](#formularios-avanzados)
- [Gemini AI Testing](#gemini-ai-testing)
- [Interacción](#interacción)
- [Jira/Xray](#jira-xray)
- [Modales y Diálogos](#modales-y-diálogos)
- [Navegación](#navegación)
- [OCR](#ocr)
- [PDF](#pdf)
- [Performance](#performance)
- [Responsive](#responsive)
- [Salesforce](#salesforce)
- [Scroll](#scroll)
- [Supabase Vector](#supabase-vector)
- [Tablas](#tablas)
- [Teclado y Mouse](#teclado-y-mouse)
- [Timing y Cronómetros](#timing-y-cronómetros)
- [Validaciones y Aserciones](#validaciones-y-aserciones)
- [Validación JSON](#validación-json)
- [Variables y Datos](#variables-y-datos)
- [Ventanas y Pestañas](#ventanas-y-pestañas)
- [iFrames](#iframes)

---

## API Testing

**Total de pasos:** 52

1. `cargo el cuerpo de petición API del archivo "{file_path}" y envío POST a "{url}" guardando respuesta en variable "{variable_name}"`
   - **Descripción:** Carga el cuerpo de petición desde un archivo y envía POST

2. `creo datos de prueba API con plantilla "{template}" y valores "{values}" guardando en variable "{variable_name}"`
   - **Descripción:** Crea datos de prueba usando una plantilla y valores

3. `detengo la escucha de llamadas a API`
   - **Descripción:** Detiene la escucha de llamadas a API

4. `detengo la interceptación de llamadas a API`
   - **Descripción:** Detiene la interceptación de llamadas a API

5. `envío peticiones API concurrentes "{count}" veces a "{url}" y verifico que todas tengan éxito`
   - **Descripción:** Envía múltiples peticiones concurrentes para testing de carga

6. `envío peticiones API en lote desde archivo "{requests_file}" y guardo resultados en variable "{variable_name}"`
   - **Descripción:** Envía múltiples peticiones API desde un archivo de configuración

7. `envío petición DELETE a "{url}" y guardo la respuesta en la variable "{variable_name}"`
   - **Descripción:** Envía una petición DELETE y guarda la respuesta

8. `envío petición GET a "{url}" y guardo la respuesta en la variable "{variable_name}"`
   - **Descripción:** Envía una petición GET y guarda la respuesta

9. `envío petición GET al endpoint "{endpoint}" y guardo la respuesta en la variable "{variable_name}"`
   - **Descripción:** Envía GET usando URL base + endpoint

10. `envío petición GET autenticada a "{url}" con token "{token}" y guardo la respuesta en la variable "{variable_name}"`
   - **Descripción:** Envía una petición GET autenticada con Bearer token

11. `envío petición HEAD a "{url}" y guardo la respuesta en la variable "{variable_name}"`
   - **Descripción:** Envía una petición HEAD y guarda la respuesta

12. `envío petición OPTIONS a "{url}" y guardo la respuesta en la variable "{variable_name}"`
   - **Descripción:** Envía una petición OPTIONS y guarda la respuesta

13. `envío petición PATCH a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"`
   - **Descripción:** Envía una petición PATCH con cuerpo y guarda la respuesta

14. `envío petición POST a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"`
   - **Descripción:** Envía una petición POST con cuerpo y guarda la respuesta

15. `envío petición PUT a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"`
   - **Descripción:** Envía una petición PUT con cuerpo y guarda la respuesta

16. `envío petición multipart form a "{url}" con campos "{fields}" y guardo la respuesta en la variable "{variable_name}"`
   - **Descripción:** Envía una petición multipart/form-data

17. `establezco el header de API "{header_name}" a "{header_value}"`
   - **Descripción:** Establece un header para las próximas peticiones API

18. `establezco el timeout de API a "{timeout}" segundos`
   - **Descripción:** Establece el timeout para las peticiones API

19. `establezco la URL base de API a "{base_url}"`
   - **Descripción:** Establece una URL base para las peticiones API

20. `extraigo el valor de la respuesta API "{key}" y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Extrae un valor de la respuesta API y lo guarda en una variable

21. `guardo el cuerpo de respuesta API en el archivo "{file_path}"`
   - **Descripción:** Guarda el cuerpo de respuesta API en un archivo

22. `guardo los datos de la llamada a API en la variable "{variable_name}"`
   - **Descripción:** Guarda los datos de la última llamada a API en una variable Ejemplo: And guardo los datos de la llamada...

23. `inicio la escucha de llamadas a API`
   - **Descripción:** Inicia la escucha global de todas las llamadas a API (requests y responses) Esto activa listeners que guardan TODAS las...

24. `limpio las llamadas a API interceptadas`
   - **Descripción:** Limpia el registro de llamadas a API interceptadas     Ejemplo:     When limpio las llamadas a API interceptadas

25. `limpio todos los datos de sesión API`
   - **Descripción:** Limpia todos los datos de sesión API

26. `mido el rendimiento de API para "{iterations}" peticiones a "{url}" y guardo métricas en variable "{variable_name}"`
   - **Descripción:** Mide el rendimiento de una API con múltiples peticiones

27. `obtengo el valor de la respuesta API capturada "{api_url}" en la ruta "{json_path}" y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Extrae un valor de una respuesta API guardada en background Busca en las llamadas guardadas por el listener y extrae...

28. `subo archivo "{file_path}" al endpoint API "{url}" con nombre de campo "{field_name}" y guardo la respuesta en la variable "{variable_name}"`
   - **Descripción:** Sube un archivo a un endpoint API

29. `verifico que NO se realizó una llamada a la API "{api_url}"`
   - **Descripción:** Verifica que NO se realizó una llamada a una API específica Ejemplo: Then verifico que NO se realizó una llamada...

30. `verifico que el array JSON de respuesta API tiene "{expected_length}" elementos`
   - **Descripción:** Verifica que un array JSON tiene una longitud específica

31. `verifico que el cuerpo de respuesta API contiene el texto "{expected_text}"`
   - **Descripción:** Verifica que el cuerpo de respuesta contiene un texto específico

32. `verifico que el código de estado de la respuesta API es "{expected_status}"`
   - **Descripción:** Verifica el código de estado de la última respuesta API

33. `verifico que el elemento "{index}" del array JSON tiene "{key}" con valor "{expected_value}"`
   - **Descripción:** Verifica que un elemento específico de un array JSON tiene un valor esperado

34. `verifico que el endpoint API "{endpoint}" soporta CORS`
   - **Descripción:** Verifica que un endpoint soporta CORS

35. `verifico que el esquema JSON de respuesta API coincide con el archivo "{schema_file}"`
   - **Descripción:** Verifica que la respuesta JSON coincide con un esquema

36. `verifico que el estado de respuesta API está en el rango "{min_status}" a "{max_status}"`
   - **Descripción:** Verifica que el código de estado está dentro de un rango

37. `verifico que el header de respuesta API "{header_name}" contiene "{expected_text}"`
   - **Descripción:** Verifica que un header de respuesta contiene un texto específico

38. `verifico que el header de respuesta API "{header_name}" es igual a "{expected_value}"`
   - **Descripción:** Verifica que un header de respuesta tiene un valor específico

39. `verifico que el número de llamadas a la API "{api_url}" es "{expected_count}"`
   - **Descripción:** Verifica que se realizó un número específico de llamadas a una API Ejemplo: Then verifico que el número de llamadas...

40. `verifico que el tiempo de respuesta de la API es menor a "{max_seconds}" segundos`
   - **Descripción:** Verifica que el tiempo de respuesta de la API está dentro del límite

41. `verifico que el tipo de contenido de respuesta API es "{expected_content_type}"`
   - **Descripción:** Verifica el tipo de contenido de la respuesta

42. `verifico que la llamada a API contiene el header "{header_name}" con valor "{header_value}"`
   - **Descripción:** Verifica que la última llamada a API contiene un header específico Ejemplo: And verifico que la llamada a API contiene...

43. `verifico que la llamada a API contiene el parámetro "{parameter}" con valor "{value}"`
   - **Descripción:** Verifica que la última llamada a API contiene un parámetro específico Ejemplo: And verifico que la llamada a API contiene...

44. `verifico que la respuesta API coincide con la respuesta esperada del archivo "{expected_file}"`
   - **Descripción:** Verifica que la respuesta API coincide con una respuesta esperada en archivo

45. `verifico que la respuesta API contiene "{key}" con valor "{expected_value}"`
   - **Descripción:** Verifica que la respuesta API contiene una clave con un valor específico

46. `verifico que la respuesta API es JSON válido`
   - **Descripción:** Verifica que la respuesta API es JSON válido

47. `verifico que la respuesta API sigue las convenciones REST para el método "{http_method}"`
   - **Descripción:** Verifica que la respuesta sigue las convenciones REST

48. `verifico que la respuesta API tiene headers de seguridad`
   - **Descripción:** Verifica que la respuesta tiene headers de seguridad importantes

49. `verifico que la respuesta API tiene paginación con total "{expected_total}" y página "{expected_page}"`
   - **Descripción:** Verifica información de paginación en la respuesta API

50. `verifico que los headers de rate limit están presentes en la respuesta API`
   - **Descripción:** Verifica que los headers de rate limiting están presentes

51. `verifico que se realizó una llamada a la API "{api_url}" usando método "{method}"`
   - **Descripción:** Verifica que se realizó una llamada a una API con un método HTTP específico Ejemplo: Then verifico que se realizó...

52. `verifico que se realizó una llamada a la API en "{api_url}"`
   - **Descripción:** Verifica que se realizó una llamada a una API específica     Busca en las llamadas guardadas por el listener de background


## Accessibility

**Total de pasos:** 12

1. `verifico que el elemento "{element_name}" es accesible por teclado con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento es accesible por teclado

2. `verifico que el elemento "{element_name}" es anunciado por lector de pantalla con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento será anunciado apropiadamente por lectores de pantalla

3. `verifico que el elemento "{element_name}" tiene contraste de color suficiente con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene contraste de color suficiente

4. `verifico que el elemento "{element_name}" tiene etiqueta ARIA "{expected_label}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene una etiqueta ARIA específica

5. `verifico que el elemento "{element_name}" tiene jerarquía de encabezados correcta con identificador "{identifier}"`
   - **Descripción:** Verifica que los encabezados siguen una jerarquía correcta

6. `verifico que el elemento "{element_name}" tiene rol ARIA "{expected_role}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene un rol ARIA específico

7. `verifico que el elemento "{element_name}" tiene texto alt "{expected_alt}" con identificador "{identifier}"`
   - **Descripción:** Verifica que una imagen tiene texto alternativo específico

8. `verifico que el elemento "{element_name}" tiene texto de enlace descriptivo con identificador "{identifier}"`
   - **Descripción:** Verifica que un enlace tiene texto descriptivo (no genérico)

9. `verifico que el formulario tiene etiquetas apropiadas para todos los campos`
   - **Descripción:** Verifica que todos los campos de formulario tienen etiquetas apropiadas

10. `verifico que la página tiene estructura de documento apropiada`
   - **Descripción:** Verifica que la página tiene una estructura de documento apropiada

11. `verifico que las imágenes tienen texto alternativo apropiado`
   - **Descripción:** Verifica que todas las imágenes tienen texto alternativo apropiado

12. `verifico que los elementos interactivos tienen indicadores de foco`
   - **Descripción:** Verifica que los elementos interactivos tienen indicadores de foco visibles


## Archivos

**Total de pasos:** 18

1. `espero a que complete la descarga`
   - **Descripción:** Espera a que complete la descarga actual

2. `extraigo y verifico que el ZIP contiene los archivos "{expected_files}"`
   - **Descripción:** Verifica que un archivo ZIP contiene archivos específicos

3. `guardo la descarga como "{filename}"`
   - **Descripción:** Guarda la descarga con un nombre específico

4. `inicio descarga haciendo click en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Inicia una descarga haciendo click en un elemento

5. `obtengo el tamaño del archivo "{filename}" y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Obtiene el tamaño de un archivo y lo guarda en una variable

6. `subo el archivo "{file_path}" al elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Sube un archivo a un elemento input[type=file]

7. `subo el archivo "{file_path}" haciendo click en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Sube un archivo haciendo click en un botón que abre el diálogo de carga Este step intercepta el diálogo nativo...

8. `subo el archivo de descargas "{filename}" haciendo click en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Sube un archivo desde la carpeta downloads haciendo click en un botón Este step intercepta el diálogo nativo del SO...

9. `subo el archivo de descargas "{filename}" haciendo click en el input con id "{input_id}"`
   - **Descripción:** Sube un archivo desde downloads haciendo click en un input[type=file] por su ID Este step es útil cuando el botón...

10. `verifico que el CSV descargado tiene "{expected_rows}" filas`
   - **Descripción:** Verifica que el CSV tiene un número específico de filas

11. `verifico que el JSON descargado contiene la clave "{key}" con valor "{value}"`
   - **Descripción:** Verifica que el JSON descargado contiene una clave con valor específico

12. `verifico que el archivo "{filename}" existe en el directorio "{directory}"`
   - **Descripción:** Verifica que un archivo existe en un directorio específico

13. `verifico que el archivo descargado contiene el texto "{text}"`
   - **Descripción:** Verifica que el archivo descargado contiene un texto específico

14. `verifico que el nombre del archivo descargado es "{expected_filename}"`
   - **Descripción:** Verifica que el archivo descargado tiene el nombre esperado

15. `verifico que el tamaño del archivo descargado es mayor a "{min_size}" bytes`
   - **Descripción:** Verifica que el archivo descargado tiene un tamaño mínimo

16. `verifico que existe el archivo descargado`
   - **Descripción:** Verifica que el archivo descargado existe

17. `verifico que la descarga es CSV válido con "{expected_columns}" columnas`
   - **Descripción:** Verifica que el archivo descargado es CSV válido con columnas específicas

18. `verifico que la descarga es JSON válido`
   - **Descripción:** Verifica que el archivo descargado es JSON válido


## Avanzado

**Total de pasos:** 6

1. `arrastro el elemento "{source_element}" al elemento "{target_element}" con identificador origen "{source_id}" e identificador destino "{target_id}"`
   - **Descripción:** Arrastra un elemento y lo suelta en otro

2. `emulo el dispositivo "{device_name}"`
   - **Descripción:** Emula un dispositivo específico

3. `establezco la geolocalización del navegador a latitud {latitude:f} y longitud {longitude:f}`
   - **Descripción:** Establece la geolocalización del navegador

4. `simulo la combinación de teclas "{keys}"`
   - **Descripción:** Simula una combinación de teclas

5. `tomo una captura de pantalla con nombre "{filename}"`
   - **Descripción:** Toma una captura de pantalla

6. `tomo una captura de pantalla simple`
   - **Descripción:** Toma una captura de pantalla con nombre automático


## Base de Datos

**Total de pasos:** 13

1. `cierro la conexión a la base de datos`
   - **Descripción:** Cierra la conexión a la base de datos

2. `creo la tabla "{table_name}" con columnas "{columns_definition}"`
   - **Descripción:** Crea una tabla con la definición de columnas especificada

3. `ejecuto la actualización SQL "{query}"`
   - **Descripción:** Ejecuta una consulta SQL de actualización (INSERT, UPDATE, DELETE)

4. `ejecuto la consulta SQL "{query}" y guardo el resultado en la variable "{variable_name}"`
   - **Descripción:** Ejecuta una consulta SQL y guarda el resultado

5. `elimino la tabla "{table_name}"`
   - **Descripción:** Elimina una tabla

6. `hago backup de la base de datos al archivo "{backup_file}"`
   - **Descripción:** Hace backup de la base de datos

7. `inserto datos de prueba en la tabla "{table_name}" con valores "{values}"`
   - **Descripción:** Inserta datos de prueba en una tabla

8. `me conecto a la base de datos "{db_name}"`
   - **Descripción:** Conecta a una base de datos usando configuración del

9. `me conecto a la base de datos SQLite "{db_path}"`
   - **Descripción:** Conecta a una base de datos SQLite específica

10. `me conecto a la base de datos usando configuración del entorno`
   - **Descripción:** Conecta a la base de datos usando la configuración del archivo

11. `obtengo el valor del resultado SQL de la columna "{column}" fila "{row_index}" y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Obtiene un valor específico del resultado SQL

12. `verifico que el resultado SQL contiene una fila con "{column}" igual a "{expected_value}"`
   - **Descripción:** Verifica que el resultado SQL contiene una fila con un valor específico

13. `verifico que el resultado de la consulta SQL tiene "{expected_count}" filas`
   - **Descripción:** Verifica el número de filas en el último resultado SQL


## CSV

**Total de pasos:** 12

1. `busco en el CSV "{csv_variable}" el valor "{search_value}" en la columna "{column_name}"`
   - **Descripción:** Busca un valor específico en una columna del CSV

2. `busco en el CSV "{csv_variable}" múltiples valores "{values_list}" en columna "{column_name}"`
   - **Descripción:** Busca múltiples valores en una columna del CSV

3. `cargo el archivo CSV "{file_path}" en la variable "{variable_name}"`
   - **Descripción:** Carga un archivo CSV completo en una variable

4. `exporto el CSV "{csv_variable}" a "{output_path}"`
   - **Descripción:** Exporta un CSV (o resultado filtrado) a un archivo

5. `filtro el CSV "{csv_variable}" donde "{column_name}" contiene "{filter_value}" y guardo como "{result_variable}"`
   - **Descripción:** Filtra un CSV por valor en columna específica

6. `muestro un resumen del CSV "{csv_variable}"`
   - **Descripción:** Muestra un resumen del CSV cargado

7. `obtengo el valor de la fila {row_index:d} columna "{column_name}" del CSV "{csv_variable}" y lo guardo en "{result_variable}"`
   - **Descripción:** Obtiene el valor de una celda específica del CSV

8. `ordeno el CSV "{csv_variable}" por columna "{column_name}" de forma "{order_type}" y guardo como "{result_variable}"`
   - **Descripción:** Ordena un CSV por una columna específica

9. `verifico que el CSV "{csv_variable}" contiene las columnas "{column_list}"`
   - **Descripción:** Verifica que un CSV contiene las columnas especificadas

10. `verifico que el CSV "{csv_variable}" tiene {expected_rows:d} filas`
   - **Descripción:** Verifica el número de filas en un CSV

11. `verifico que el archivo CSV "{file_path}" existe`
   - **Descripción:** Verifica que un archivo CSV existe

12. `verifico que el archivo CSV "{file_path}" tiene un peso de al menos {min_size:d} bytes`
   - **Descripción:** Verifica el tamaño mínimo de un archivo CSV


## Combobox y Dropdowns

**Total de pasos:** 27

1. `abro el dropdown "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Abre un dropdown personalizado

2. `escribo y selecciono "{text}" en el combobox buscable "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Escribe en un combobox buscable y selecciona la opción

3. `limpio la selección del combobox "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Limpia la selección de un combobox

4. `navego las opciones del combobox con flechas y selecciono la opción "{option}" de "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Navega por las opciones de un combobox usando teclas de flecha

5. `selecciono la opción "{option}" del combobox "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Selecciona una opción de un combobox/select simulando interacción humana completa Dispara TODOS los eventos que un usuario real generaría: -...

6. `selecciono la opción "{option}" del dropdown abierto`
   - **Descripción:** Selecciona una opción de un dropdown abierto

7. `selecciono la opción por valor "{value}" del combobox "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Selecciona una opción de un combobox/select por valor

8. `selecciono la opción por índice "{index}" del combobox "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Selecciona una opción de un combobox/select por índice

9. `selecciono múltiples opciones "{options}" del multiselect "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Selecciona múltiples opciones de un select múltiple

10. `verifico que el combobox "{element_name}" contiene exactamente "{expected_options}" opciones con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox contiene exactamente las opciones especificadas

11. `verifico que el combobox "{element_name}" contiene la opción "{expected_option}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox contiene una opción específica

12. `verifico que el combobox "{element_name}" contiene las opciones "{options}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox contiene opciones específicas

13. `verifico que el combobox "{element_name}" es campo requerido con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox es un campo requerido

14. `verifico que el combobox "{element_name}" no contiene la opción "{unexpected_option}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox NO contiene una opción específica

15. `verifico que el combobox "{element_name}" no permite selección múltiple con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox NO permite selección múltiple

16. `verifico que el combobox "{element_name}" no tiene opciones duplicadas con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox no tiene opciones duplicadas

17. `verifico que el combobox "{element_name}" permite selección múltiple con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox permite selección múltiple

18. `verifico que el combobox "{element_name}" se puede filtrar escribiendo "{filter_text}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox se puede filtrar escribiendo texto

19. `verifico que el combobox "{element_name}" tiene "{expected_count}" opciones con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox tiene un número específico de opciones

20. `verifico que el combobox "{element_name}" tiene la opción "{option}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox tiene una opción específica disponible Este paso NO abre el combobox, solo verifica que la opción...

21. `verifico que el combobox "{element_name}" tiene seleccionada la opción "{option}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox tiene una opción específica seleccionada

22. `verifico que el placeholder del combobox "{element_name}" es "{expected_placeholder}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un combobox tiene un placeholder específico

23. `verifico que la primera opción del combobox "{element_name}" es "{expected_option}" con identificador "{identifier}"`
   - **Descripción:** Verifica que la primera opción de un combobox es específica

24. `verifico que la selección por defecto del combobox "{element_name}" es "{expected_selection}" con identificador "{identifier}"`
   - **Descripción:** Verifica que la selección por defecto de un combobox es específica

25. `verifico que la última opción del combobox "{element_name}" es "{expected_option}" con identificador "{identifier}"`
   - **Descripción:** Verifica que la última opción de un combobox es específica

26. `verifico que las opciones del combobox "{element_name}" contienen los valores "{expected_values}" con identificador "{identifier}"`
   - **Descripción:** Verifica que las opciones de un combobox tienen valores específicos

27. `verifico que las opciones del combobox "{element_name}" están ordenadas alfabéticamente con identificador "{identifier}"`
   - **Descripción:** Verifica que las opciones de un combobox están ordenadas alfabéticamente


## Control del Navegador

**Total de pasos:** 40

1. `bloqueo el tipo de recurso "{resource_type}"`
   - **Descripción:** Bloquea un tipo específico de recurso

2. `cargo la configuración del navegador desde el archivo "{config_file}"`
   - **Descripción:** Carga configuración del navegador desde un archivo JSON

3. `configuro el navegador para entorno CI/CD`
   - **Descripción:** Configura el navegador para entornos de CI/CD

4. `configuro el navegador para testing móvil`
   - **Descripción:** Configura el navegador específicamente para testing móvil

5. `desactivo el navegador para esta prueba`
   - **Descripción:** Desactiva el navegador para pruebas que no lo necesitan (API, validación semántica, etc

6. `desbloqueo todos los recursos`
   - **Descripción:** Desbloquea todos los recursos

7. `deshabilito la característica experimental de Chrome "{feature}"`
   - **Descripción:** Deshabilita una característica experimental de Chrome

8. `deshabilito las características de seguridad del navegador`
   - **Descripción:** Deshabilita características de seguridad del navegador (solo para testing)

9. `ejecuto JavaScript "{script}" y guardo el resultado en la variable "{variable_name}"`
   - **Descripción:** Ejecuta JavaScript personalizado y guarda el resultado

10. `ejecuto el siguiente JavaScript y guardo el resultado en la variable "{variable_name}"`
   - **Descripción:** Ejecuta JavaScript multilínea y guarda el resultado     Usa context

11. `elimino el item de localStorage "{key}"`
   - **Descripción:** Elimina un item específico de localStorage

12. `elimino la cookie "{name}"`
   - **Descripción:** Elimina una cookie específica

13. `establezco el argumento del navegador "{argument}"`
   - **Descripción:** Añade un argumento específico al navegador

14. `establezco el comportamiento de descarga del navegador a "{behavior}" con ruta "{download_path}"`
   - **Descripción:** Configura el comportamiento de descarga del navegador

15. `establezco el item de localStorage "{key}" con valor "{value}"`
   - **Descripción:** Establece un item en localStorage

16. `establezco el item de sessionStorage "{key}" con valor "{value}"`
   - **Descripción:** Establece un item en sessionStorage

17. `establezco el límite de memoria del navegador a "{memory_mb}" MB`
   - **Descripción:** Establece un límite de memoria para el navegador

18. `establezco el proxy del navegador a "{proxy_server}"`
   - **Descripción:** Configura un servidor proxy para el navegador

19. `establezco el user agent a "{user_agent}"`
   - **Descripción:** Establece el user agent del navegador

20. `establezco el viewport del navegador a "{width}x{height}"`
   - **Descripción:** Establece el tamaño del viewport del navegador

21. `establezco la bandera de Chrome "{flag}" con valor "{value}"`
   - **Descripción:** Establece una bandera específica de Chrome

22. `establezco la cookie "{name}" con valor "{value}"`
   - **Descripción:** Establece una cookie específica

23. `establezco la preferencia del navegador "{preference}" con valor "{value}"`
   - **Descripción:** Establece una preferencia específica del navegador

24. `establezco los argumentos del navegador desde la lista "{arguments_list}"`
   - **Descripción:** Establece múltiples argumentos del navegador desde una lista separada por comas

25. `guardo la configuración actual del navegador en el archivo "{config_file}"`
   - **Descripción:** Guarda la configuración actual del navegador en un archivo JSON

26. `habilito el modo de rendimiento del navegador`
   - **Descripción:** Habilita configuraciones para máximo rendimiento

27. `habilito la característica experimental de Chrome "{feature}"`
   - **Descripción:** Habilita una característica experimental de Chrome

28. `limpio el localStorage`
   - **Descripción:** Limpia todo el localStorage

29. `limpio el sessionStorage`
   - **Descripción:** Limpia todo el sessionStorage

30. `limpio la caché del navegador`
   - **Descripción:** Limpia la caché del navegador

31. `limpio todas las cookies`
   - **Descripción:** Elimina todas las cookies

32. `limpio todas las preferencias del navegador`
   - **Descripción:** Limpia todas las preferencias del navegador configuradas

33. `limpio todos los argumentos del navegador`
   - **Descripción:** Limpia todos los argumentos del navegador configurados

34. `muestro la configuración actual del navegador`
   - **Descripción:** Muestra la configuración actual del navegador

35. `obtengo el item de localStorage "{key}" y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Obtiene un item de localStorage y lo guarda en una variable

36. `obtengo el item de sessionStorage "{key}" y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Obtiene un item de sessionStorage y lo guarda en una variable

37. `obtengo el user agent actual y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Obtiene el user agent actual

38. `obtengo la cookie "{name}" y la guardo en la variable "{variable_name}"`
   - **Descripción:** Obtiene el valor de una cookie y lo guarda en una variable

39. `reactivo el navegador`
   - **Descripción:** Reactiva el navegador después de haberlo desactivado

40. `simulo la condición de red "{condition}"`
   - **Descripción:** Simula diferentes condiciones de red


## Drag & Drop

**Total de pasos:** 13

1. `arrastro el elemento "{element_name}" a las coordenadas x="{x}" y="{y}" con identificador "{identifier}"`
   - **Descripción:** Arrastra un elemento a coordenadas específicas

2. `arrastro el elemento "{element_name}" por desplazamiento x="{x}" y="{y}" con identificador "{identifier}"`
   - **Descripción:** Arrastra un elemento por un desplazamiento específico

3. `arrastro el elemento "{source_element}" al elemento "{target_element}" con identificadores "{source_id}" y "{target_id}"`
   - **Descripción:** Arrastra un elemento y lo suelta en otro elemento

4. `arrastro el elemento "{source_element}" al elemento "{target_element}" usando API nativa con identificadores "{source_id}" y "{target_id}"`
   - **Descripción:** Arrastra un elemento usando la API nativa de Playwright (alternativa más robusta)

5. `arrastro lentamente el elemento "{element_name}" al elemento "{target_element}" con identificadores "{source_id}" y "{target_id}"`
   - **Descripción:** Drag and drop con movimiento lento (útil para elementos sensibles)

6. `arrastro y suelto el archivo "{file_path}" al elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Arrastra y suelta un archivo en un elemento (para uploads)

7. `empiezo a arrastrar el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Inicia el arrastre de un elemento (para operaciones de drag complejas)

8. `muevo el elemento arrastrado a las coordenadas x="{x}" y="{y}"`
   - **Descripción:** Mueve un elemento que está siendo arrastrado a nuevas coordenadas

9. `paso el mouse sobre el elemento antes de arrastrar "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Pasa el mouse sobre un elemento antes de arrastrarlo (útil para elementos que requieren hover)

10. `realizo drag and drop avanzado desde "{source_element}" hasta "{target_element}" con identificadores "{source_id}" y "{target_id}"`
   - **Descripción:** Drag and drop avanzado con múltiples métodos de fallback

11. `suelto el elemento arrastrado`
   - **Descripción:** Suelta el elemento que está siendo arrastrado

12. `verifico que el drag and drop fue exitoso comprobando la posición del elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica que el drag and drop fue exitoso comprobando cambios en el elemento

13. `verifico que el elemento "{element_name}" está en la posición x="{x}" y="{y}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento está en una posición específica (aproximada)


## Elementos Web

**Total de pasos:** 14

1. `clono el elemento "{source_element}" y lo añado a "{target_element}" con identificadores "{source_id}" y "{target_id}"`
   - **Descripción:** Clona un elemento y lo añade a otro elemento

2. `desenfocar el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Desenfoca un elemento específico

3. `disparo el evento "{event}" en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Dispara un evento específico en un elemento

4. `elimino el atributo "{attribute}" del elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Elimina un atributo específico de un elemento

5. `elimino el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Elimina un elemento del DOM

6. `enfoco el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Enfoca un elemento específico

7. `establezco el atributo "{attribute}" con valor "{value}" en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Establece un atributo específico en un elemento

8. `establezco el estilo CSS "{property}" con valor "{value}" en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Establece una propiedad CSS en un elemento

9. `limpio la selección en la página`
   - **Descripción:** Limpia cualquier selección de texto en la página

10. `obtengo la posición del elemento y la guardo en variables x="{x_var}" y="{y_var}" para elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Obtiene la posición de un elemento y la guarda en variables

11. `obtengo las dimensiones del elemento y las guardo en variables ancho="{width_var}" alto="{height_var}" para elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Obtiene las dimensiones de un elemento y las guarda en variables

12. `selecciono el texto del elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Selecciona todo el texto dentro de un elemento

13. `simulo mouse enter en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Simula el evento mouse enter en un elemento

14. `simulo mouse leave en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Simula el evento mouse leave moviendo el mouse fuera del elemento


## Email

**Total de pasos:** 9

1. `busco emails con asunto que contiene "{subject_text}" y guardo el conteo en la variable "{variable_name}"`
   - **Descripción:** Busca emails por asunto y guarda el conteo

2. `cierro la conexión de email`
   - **Descripción:** Cierra la conexión IMAP

3. `elimino emails con asunto que contiene "{subject_text}"`
   - **Descripción:** Elimina emails que contienen un texto específico en el asunto

4. `establezco las credenciales de email remitente="{sender}" contraseña="{password}"`
   - **Descripción:** Establece las credenciales para envío de email

5. `extraigo el código de verificación del cuerpo del email y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Extrae un código de verificación del último email recibido

6. `me conecto al servidor IMAP "{imap_server}" puerto "{port}" con usuario "{username}" contraseña "{password}"`
   - **Descripción:** Conecta a un servidor IMAP para leer emails

7. `obtengo el contenido del email más reciente y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Obtiene el contenido del email más reciente

8. `selecciono la carpeta de email "{folder}"`
   - **Descripción:** Selecciona una carpeta de email (INBOX, SENT, etc

9. `verifico que se recibió un email con asunto "{subject}" dentro de "{timeout}" segundos`
   - **Descripción:** Verifica que se recibió un email con un asunto específico dentro del tiempo límite


## Entrada Avanzada

**Total de pasos:** 21

1. `agrego "{additional_text}" al final del texto en "{selector}"`
   - **Descripción:** Agrega texto al final del contenido existente

2. `borro {num_chars:d} caracteres del final en "{selector}"`
   - **Descripción:** Borra un número específico de caracteres del final

3. `copio el contenido del campo "{selector}" al portapapeles`
   - **Descripción:** Copia el contenido de un campo al portapapeles

4. `desenfocar el campo actual`
   - **Descripción:** Quita el foco del campo actual

5. `enfoco el campo "{selector}"`
   - **Descripción:** Enfoca un campo específico

6. `escribo con velocidad "{speed_type}" el texto "{text}" en "{selector}"`
   - **Descripción:** Escribe texto con diferentes velocidades predefinidas

7. `inserto "{text}" al inicio del campo "{selector}"`
   - **Descripción:** Inserta texto al inicio del contenido existente

8. `limpio completamente el campo "{selector}"`
   - **Descripción:** Limpia completamente un campo de entrada usando múltiples métodos

9. `limpio el campo "{selector}" usando {method}`
   - **Descripción:** Limpia un campo usando diferentes métodos

10. `pego el contenido del portapapeles en "{selector}"`
   - **Descripción:** Pega el contenido del portapapeles en un campo

11. `que escribo avanzado "{text}" y presiono Enter en "{selector}"`
   - **Descripción:** Escribe texto y presiona Enter

12. `que escribo con errores simulados "{text}" en "{selector}"`
   - **Descripción:** Simula errores de escritura humanos (escribir, borrar, corregir)

13. `que escribo gradualmente "{text}" en "{selector}" con delay de {delay:d}ms`
   - **Descripción:** Escribe texto gradualmente, carácter por carácter

14. `que escribo múltiples líneas en "{selector}"`
   - **Descripción:** Escribe texto multilínea desde el contexto del step

15. `que escribo naturalmente "{text}" en "{selector}"`
   - **Descripción:** Escribe texto simulando escritura humana con delays variables

16. `reemplazo el texto en "{selector}" con "{new_text}"`
   - **Descripción:** Reemplaza completamente el texto en un campo

17. `selecciono el texto desde la posición {start:d} hasta {end:d} en "{selector}"`
   - **Descripción:** Selecciona un rango específico de texto en un campo

18. `selecciono todo el texto en "{selector}" y lo borro`
   - **Descripción:** Selecciona todo el texto y lo borra

19. `tecleo "{key}" en el campo "{selector}"`
   - **Descripción:** Presiona una tecla específica en un elemento

20. `tecleo combinación "{key_combination}" en el campo "{selector}"`
   - **Descripción:** Presiona una combinación de teclas en un elemento

21. `verifico que puedo escribir en el campo "{selector}"`
   - **Descripción:** Verifica que un campo acepta entrada de texto


## Esperas

**Total de pasos:** 29

1. `espero a que el campo "{element_name}" tenga el valor "{value}" con identificador "{identifier}"`
   - **Descripción:** Espera a que un campo tenga un valor específico

2. `espero a que el campo "{element_name}" tenga valor con identificador "{identifier}"`
   - **Descripción:** Espera a que un campo tenga algún valor (no esté vacío)

3. `espero a que el contenido del DOM esté cargado`
   - **Descripción:** Espera a que el contenido del DOM esté cargado

4. `espero a que el elemento "{element_name}" contenga el texto "{text}" con identificador "{identifier}"`
   - **Descripción:** Espera a que un elemento contenga un texto específico

5. `espero a que el elemento "{element_name}" deje de cambiar con identificador "{identifier}"`
   - **Descripción:** Espera a que un elemento deje de cambiar (útil para contadores, loaders dinámicos) Verifica que el textContent se mantenga igual...

6. `espero a que el elemento "{element_name}" esté habilitado con identificador "{identifier}"`
   - **Descripción:** Espera a que un elemento esté habilitado

7. `espero a que el elemento "{element_name}" esté oculto con identificador "{identifier}"`
   - **Descripción:** Espera a que un elemento esté oculto

8. `espero a que el elemento "{element_name}" no esté vacío con identificador "{identifier}"`
   - **Descripción:** Espera a que un elemento tenga contenido (textContent no vacío)

9. `espero a que el elemento "{element_name}" no tenga la clase "{css_class}" con identificador "{identifier}"`
   - **Descripción:** Espera a que un elemento NO tenga una clase CSS específica (útil para esperar fin de loading)

10. `espero a que el elemento "{element_name}" sea clickeable con identificador "{identifier}"`
   - **Descripción:** Espera a que un elemento sea clickeable

11. `espero a que el elemento "{element_name}" sea removido del DOM con identificador "{identifier}"`
   - **Descripción:** Espera a que un elemento sea removido del DOM

12. `espero a que el elemento "{element_name}" sea visible con identificador "{identifier}"`
   - **Descripción:** Espera a que un elemento sea visible

13. `espero a que el elemento "{element_name}" tenga el atributo "{attribute}" con valor "{value}" con identificador "{identifier}"`
   - **Descripción:** Espera a que un atributo tenga un valor específico

14. `espero a que el elemento "{element_name}" tenga el atributo "{attribute}" en identificador "{identifier}"`
   - **Descripción:** Espera a que un elemento tenga un atributo específico

15. `espero a que el elemento "{element_name}" tenga elementos hijos con identificador "{identifier}"`
   - **Descripción:** Espera a que un elemento tenga elementos hijos cargados

16. `espero a que el elemento "{element_name}" tenga la clase "{css_class}" con identificador "{identifier}"`
   - **Descripción:** Espera a que un elemento tenga una clase CSS específica

17. `espero a que el select "{element_name}" tenga al menos {count:d} opciones con identificador "{identifier}"`
   - **Descripción:** Espera a que un select tenga al menos N opciones cargadas

18. `espero a que el select "{element_name}" tenga opciones con identificador "{identifier}"`
   - **Descripción:** Espera a que un select tenga opciones cargadas (más de la opción por defecto) Útil cuando un combobox se carga...

19. `espero a que el spinner de carga desaparezca con identificador "{identifier}"`
   - **Descripción:** Espera a que un spinner/loader desaparezca

20. `espero a que el título de la página sea "{title}"`
   - **Descripción:** Espera a que el título de la página sea específico

21. `espero a que haya al menos {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Espera a que haya al menos N elementos que coincidan con el selector

22. `espero a que haya exactamente {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Espera a que haya exactamente N elementos que coincidan con el selector

23. `espero a que la lista "{element_name}" tenga elementos con identificador "{identifier}"`
   - **Descripción:** Espera a que una lista (ul/ol) tenga elementos li cargados

24. `espero a que la red esté inactiva`
   - **Descripción:** Espera a que la red esté inactiva

25. `espero a que la tabla "{element_name}" tenga al menos {count:d} filas con identificador "{identifier}"`
   - **Descripción:** Espera a que una tabla tenga al menos N filas de datos

26. `espero a que la tabla "{element_name}" tenga filas con identificador "{identifier}"`
   - **Descripción:** Espera a que una tabla tenga filas cargadas (al menos 1 fila de datos)

27. `espero a que la url de la página contenga "{url_part}"`
   - **Descripción:** Espera a que la URL contenga una parte específica

28. `espero {milliseconds:d} milisegundos`
   - **Descripción:** Espera un número específico de milisegundos

29. `espero {seconds:d} segundos`
   - **Descripción:** Espera un número específico de segundos (usar solo cuando sea necesario)


## Formularios Avanzados

**Total de pasos:** 11

1. `auto-relleno el formulario "{form_name}" con datos de prueba usando identificador "{identifier}"`
   - **Descripción:** Auto-rellena un formulario con datos de prueba comunes

2. `deshabilito el campo "{field_name}" en formulario "{form_name}" con identificador de formulario "{form_id}" y identificador de campo "{field_id}"`
   - **Descripción:** Deshabilita un campo de formulario

3. `envío el formulario "{form_name}" con identificador "{identifier}"`
   - **Descripción:** Envía un formulario específico

4. `establezco el campo "{field_name}" como solo lectura en formulario "{form_name}" con identificador de formulario "{form_id}" y identificador de campo "{field_id}"`
   - **Descripción:** Establece un campo como solo lectura

5. `habilito el campo "{field_name}" en formulario "{form_name}" con identificador de formulario "{form_id}" y identificador de campo "{field_id}"`
   - **Descripción:** Habilita un campo de formulario

6. `limpio todos los campos del formulario "{form_name}" con identificador "{identifier}"`
   - **Descripción:** Limpia todos los campos de un formulario

7. `obtengo los datos del formulario y los guardo en la variable "{variable_name}" para formulario "{form_name}" con identificador "{identifier}"`
   - **Descripción:** Extrae todos los datos de un formulario y los guarda como JSON

8. `relleno el formulario con datos de la variable "{data_variable}" para formulario "{form_name}" con identificador "{identifier}"`
   - **Descripción:** Rellena un formulario con datos de una variable JSON

9. `reseteo el formulario "{form_name}" con identificador "{identifier}"`
   - **Descripción:** Resetea un formulario a sus valores por defecto

10. `valido el formulario "{form_name}" con identificador "{identifier}"`
   - **Descripción:** Valida un formulario usando la validación HTML5 nativa

11. `verifico los campos requeridos en el formulario "{form_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica que todos los campos requeridos estén completados


## Gemini AI Testing

**Total de pasos:** 22

1. `Gemini genera la respuesta para el prompt "{user_query}"`
   - **Descripción:** Genera una respuesta usando Gemini basándose en el contexto de negocio cargado Útil para: - Generar respuestas de referencia (golden...

2. `cambio al contexto de reglas de negocio "{context_name}"`
   - **Descripción:** Cambia al contexto de reglas de negocio especificado     Ejemplo:     When cambio al contexto de reglas de negocio "politicas_devoluciones"

3. `cargo la respuesta del SUT desde el archivo "{file_path}"`
   - **Descripción:** Carga la respuesta del SUT desde un archivo     Ejemplo:     And cargo la respuesta del SUT desde el archivo "responses/chatbot_response

4. `el Juez Gemini debe validar la respuesta con criterios personalizados "{criteria}" y umbral {threshold:f}`
   - **Descripción:** Evalúa la respuesta del SUT con criterios personalizados Ejemplo: Then el Juez Gemini debe validar la respuesta con criterios personalizados...

5. `el Juez Gemini debe validar la respuesta con un umbral mínimo de {threshold:f}`
   - **Descripción:** Evalúa la respuesta del SUT usando Gemini como Juez     Evalúa múltiples dimensiones:   1

6. `el contexto de reglas de negocio "{context_name}" está cargado desde el archivo "{file_path}"`
   - **Descripción:** Carga el contexto de reglas de negocio usando Context Caching o System Instruction Si el archivo supera 32k tokens, usa...

7. `el score de la última evaluación debe ser mayor o igual a {min_score:f}`
   - **Descripción:** Verifica que el score de la última evaluación cumple con el mínimo Ejemplo: And el score de la última evaluación...

8. `establezco la respuesta del SUT como "{response_text}"`
   - **Descripción:** Establece manualmente la respuesta del SUT (útil para testing) Ejemplo: And establezco la respuesta del SUT como "Puedes devolver productos...

9. `guardo la evaluación del Juez en el archivo "{file_path}"`
   - **Descripción:** Guarda la última evaluación del Juez en un archivo JSON Ejemplo: And guardo la evaluación del Juez en el archivo...

10. `interactúo con la IA con el prompt "{user_query}"`
   - **Descripción:** Interactúa con el Sistema Bajo Prueba (SUT) y guarda la respuesta     NOTA: Este es un placeholder

11. `limpio todos los cachés de contexto`
   - **Descripción:** Limpia todos los cachés de contexto creados     Ejemplo:     When limpio todos los cachés de contexto

12. `valido con Gemini que según el contexto para la pregunta "{pregunta}" la respuesta "{respuesta}" es válida con umbral {threshold:f}`
   - **Descripción:** Valida una pregunta y respuesta directamente en un solo paso Este paso combina establecer la pregunta, la respuesta y validar...

13. `valido que el JSON de respuesta tiene la estructura "{schema_file}"`
   - **Descripción:** Valida que el JSON de respuesta cumple con un esquema específico Ejemplo: Then valido que el JSON de respuesta tiene...

14. `valido que la intención de la respuesta es "{expected_intent}"`
   - **Descripción:** Valida que la intención de la respuesta del SUT es la esperada Ejemplo: Then valido que la intención de la...

15. `valido que la respuesta cita fuentes correctamente`
   - **Descripción:** Valida que la respuesta cita fuentes correctamente (para RAG)     Ejemplo:     Then valido que la respuesta cita fuentes correctamente

16. `valido que la respuesta del SUT es un JSON válido`
   - **Descripción:** Valida que la respuesta del SUT es un JSON válido Ejemplo: Then valido que la respuesta del SUT es un...

17. `valido que la respuesta del SUT está en idioma "{language}"`
   - **Descripción:** Valida que la respuesta del SUT está en el idioma especificado Ejemplo: Then valido que la respuesta del SUT está...

18. `valido que la respuesta no contiene alucinaciones según el contexto`
   - **Descripción:** Detecta si la respuesta contiene alucinaciones (información inventada)     Ejemplo:     Given cargo el contexto de negocio "products" desde el archivo "context/products

19. `valido que la respuesta no contiene lenguaje tóxico`
   - **Descripción:** Detecta si la respuesta contiene lenguaje tóxico o inapropiado     Ejemplo:     Then valido que la respuesta no contiene lenguaje tóxico

20. `valido que la respuesta no contiene sesgos de "{bias_type}"`
   - **Descripción:** Detecta si la respuesta contiene sesgos específicos Ejemplo: Then valido que la respuesta no contiene sesgos de "género" Then verifico...

21. `valido que la respuesta rechaza el prompt adversarial`
   - **Descripción:** Valida que la IA rechaza correctamente un prompt adversarial Ejemplo: When establezco la respuesta del SUT como "Lo siento, no...

22. `valido que las respuestas "{var1}" y "{var2}" son consistentes`
   - **Descripción:** Valida que dos respuestas son consistentes entre sí Ejemplo: When guardo el valor de la variable "sut_response" en "respuesta_1" And...


## Interacción

**Total de pasos:** 22

1. `abro el calendario html desde el icono derecho con localizador "{identifier}"`
   - **Descripción:** Sin descripción disponible

2. `abro el calendario y relleno el campo de fecha "{field_name}" con "{date_text}" con identificador "{identifier}"`
   - **Descripción:** Abre el calendario nativo del navegador y rellena el campo de fecha Este paso es útil cuando el campo de...

3. `desmarco el checkbox "{checkbox_name}" con identificador "{identifier}"`
   - **Descripción:** Desmarca un checkbox

4. `escribo "{text}" en el campo "{field_name}" con identificador "{identifier}"`
   - **Descripción:** Escribe texto en un campo (sin limpiar primero)

5. `establezco el atributo "{attribute_name}" a "{attribute_value}" en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Establece o modifica un atributo HTML de un elemento Ejemplos: - establezco el atributo "placeholder" a "Ingrese su nombre" en...

6. `hago click derecho en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Hace click derecho en un elemento

7. `hago click en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Hace click en un elemento

8. `hago click en el select "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Hace click en un select/combobox

9. `hago doble click en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Hace doble click en un elemento

10. `limpio el campo "{field_name}" con identificador "{identifier}"`
   - **Descripción:** Limpia un campo de texto

11. `marco el checkbox "{checkbox_name}" con identificador "{identifier}"`
   - **Descripción:** Marca un checkbox

12. `obtengo el atributo "{attribute_name}" del elemento "{element_name}" con identificador "{identifier}" y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Obtiene el valor de un atributo HTML y lo guarda en una variable Ejemplos: - obtengo el atributo "value" del...

13. `paso el mouse sobre el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Pasa el mouse sobre un elemento

14. `presiono desde el teclado "{key}"`
   - **Descripción:** Sin descripción disponible

15. `relleno el campo "{field_name}" con "{text}" con identificador "{identifier}"`
   - **Descripción:** Rellena un campo de texto

16. `relleno el campo de fecha "{field_name}" con "{date_text}" con identificador "{identifier}"`
   - **Descripción:** Rellena un campo de fecha (input type="date") y dispara eventos de Angular Acepta formatos: - DD-MM-YYYY (01-01-2027) -> convierte a...

17. `remuevo el atributo "{attribute_name}" del elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Remueve un atributo HTML de un elemento     Ejemplos:   - remuevo el atributo "readonly" del elemento "input" con identificador "$

18. `selecciono la fecha "{date_text}" en el input de fecha "{identifier}"`
   - **Descripción:** Sin descripción disponible

19. `selecciono la opción "{option}" del dropdown "{dropdown_name}" con identificador "{identifier}"`
   - **Descripción:** Selecciona una opción de un dropdown

20. `subo el archivo "{file_path}" al campo "{field_name}" con identificador "{identifier}"`
   - **Descripción:** Sube un archivo

21. `verifico que el elemento "{element_name}" con identificador "{identifier}" no tiene el atributo "{attribute_name}"`
   - **Descripción:** Verifica que un elemento NO tiene un atributo específico     Ejemplos:   - verifico que el elemento "input" con identificador "$

22. `verifico que el elemento "{element_name}" con identificador "{identifier}" tiene el atributo "{attribute_name}"`
   - **Descripción:** Verifica que un elemento tiene un atributo específico     Ejemplos:   - verifico que el elemento "input" con identificador "$


## Jira/Xray

**Total de pasos:** 15

1. `actualizo el estado del test "{test_key}" a "{status}" en el test execution actual`
   - **Descripción:** Actualizar el estado de un test en un Test Execution

2. `adjunto el archivo "{file_path}" a la issue "{issue_key}"`
   - **Descripción:** Adjuntar un archivo a una issue de Jira

3. `agrego los tests "{test_keys}" al test execution actual`
   - **Descripción:** Agregar tests a un Test Execution

4. `agrego un comentario "{comment}" a la issue "{issue_key}"`
   - **Descripción:** Agregar un comentario a una issue de Jira

5. `busco issues en Jira con JQL "{jql}"`
   - **Descripción:** Buscar issues usando JQL y guardar resultados

6. `creo un test execution "{summary}" en Xray`
   - **Descripción:** Crear un Test Execution en Xray

7. `muestro información de la integración Jira/Xray`
   - **Descripción:** Mostrar información sobre el estado de la integración

8. `si el escenario falla creo una issue de tipo "{issue_type}" con el título "{title}"`
   - **Descripción:** Registra que se debe crear una issue si el escenario falla Este paso NO crea la issue inmediatamente, sino que...

9. `si el escenario falla creo una issue de tipo "{issue_type}" con título "{title}" y descripción "{description}"`
   - **Descripción:** Registra que se debe crear una issue con descripción personalizada si el escenario falla Ejemplos: - si el escenario falla...

10. `si el escenario falla creo una issue de tipo "{issue_type}" con título "{title}" y prioridad "{priority}"`
   - **Descripción:** Registra que se debe crear una issue con prioridad específica si el escenario falla Prioridades válidas: Highest, High, Medium, Low,...

11. `verifico la conexión con Jira`
   - **Descripción:** Verificar que la conexión con Jira funciona correctamente

12. `verifico la configuración de Xray`
   - **Descripción:** Verificar que Xray está configurado correctamente

13. `verifico que el test "{test_key}" es de tipo Test en Jira`
   - **Descripción:** Verificar que una issue es de tipo Test

14. `verifico que la búsqueda JQL encontró "{expected_count}" issues`
   - **Descripción:** Verificar el número de resultados de una búsqueda JQL

15. `verifico que la issue "{issue_key}" existe en Jira`
   - **Descripción:** Verificar que una issue específica existe en Jira


## Modales y Diálogos

**Total de pasos:** 23

1. `cierro el modal "{modal_name}" haciendo click en el botón cerrar con identificador "{identifier}"`
   - **Descripción:** Cierra un modal haciendo click en el botón de cerrar

2. `cierro el modal haciendo click fuera`
   - **Descripción:** Cierra un modal haciendo click fuera del contenido del modal

3. `cierro el modal presionando la tecla Escape`
   - **Descripción:** Cierra un modal presionando la tecla Escape

4. `desactivo el manejo automático de diálogos`
   - **Descripción:** Desactiva el manejo automático de diálogos/alertas

5. `el mensaje del diálogo capturado debería contener "{expected_text}"`
   - **Descripción:** Verifica que el mensaje capturado contiene un texto     Este step verifica el mensaje guardado en context

6. `el mensaje del diálogo capturado debería ser "{expected_text}"`
   - **Descripción:** Verifica que el mensaje capturado es exactamente igual     Este step verifica el mensaje guardado en context

7. `espero a que aparezca cualquier modal`
   - **Descripción:** Espera a que aparezca cualquier modal en la página

8. `espero a que aparezca el modal "{modal_name}" con identificador "{identifier}"`
   - **Descripción:** Espera a que aparezca un modal

9. `espero a que desaparezca el modal "{modal_name}" con identificador "{identifier}"`
   - **Descripción:** Espera a que desaparezca un modal

10. `evito que se cierren automáticamente los diálogos`
   - **Descripción:** Previene que los diálogos se cierren automáticamente     Este step:   1

11. `guardo el mensaje del diálogo capturado en la variable "{variable_name}"`
   - **Descripción:** Guarda el mensaje capturado en una variable     Este step guarda el mensaje de context

12. `hago click en el botón "{button_text}" del modal "{modal_name}" con identificador de modal "{modal_id}"`
   - **Descripción:** Hace click en un botón específico dentro de un modal

13. `manejo el prompt del navegador con texto "{text}" y acción "{action}"`
   - **Descripción:** Maneja prompts del navegador con texto y acción

14. `manejo la alerta del navegador con acción "{action}"`
   - **Descripción:** Maneja alertas del navegador (accept/dismiss) - SOLO cuando aparezca

15. `manejo la confirmación del navegador con acción "{action}"`
   - **Descripción:** Maneja confirmaciones del navegador (accept/dismiss)

16. `obtengo el mensaje del diálogo guardado`
   - **Descripción:** Obtiene el mensaje del diálogo que fue capturado por el listener     Este step lee el mensaje guardado en context

17. `relleno el campo "{field_name}" con "{text}" en el modal "{modal_name}" con identificadores modal="{modal_id}" campo="{field_id}"`
   - **Descripción:** Rellena un campo dentro de un modal

18. `tomo captura del modal "{modal_name}" con identificador "{identifier}"`
   - **Descripción:** Toma una captura de pantalla específica del modal

19. `verifico que el modal "{modal_name}" contiene el texto "{text}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un modal contiene un texto específico

20. `verifico que el modal "{modal_name}" es visible con identificador "{identifier}"`
   - **Descripción:** Verifica que un modal es visible

21. `verifico que el modal "{modal_name}" no es visible con identificador "{identifier}"`
   - **Descripción:** Verifica que un modal no es visible

22. `verifico que el modal "{modal_name}" tiene el título "{expected_title}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un modal tiene un título específico

23. `verifico que no hay modales visibles`
   - **Descripción:** Verifica que no hay modales visibles en la página


## Navegación

**Total de pasos:** 10

1. `abro una nueva pestaña`
   - **Descripción:** Abre una nueva pestaña

2. `cambio a la pestaña {tab_index:d}`
   - **Descripción:** Cambia a una pestaña específica por índice

3. `cierro la pestaña actual`
   - **Descripción:** Cierra la pestaña actual

4. `espero a que cargue la página`
   - **Descripción:** Espera a que la página termine de cargar

5. `establezco el tamaño de ventana a {width:d}x{height:d}`
   - **Descripción:** Establece el tamaño de la ventana

6. `maximizo la ventana`
   - **Descripción:** Maximiza la ventana del navegador

7. `recargo la página`
   - **Descripción:** Recarga la página actual y espera a que cargue completamente

8. `voy a la url "{url}"`
   - **Descripción:** Navega a una URL específica y espera a que la página cargue completamente

9. `voy hacia adelante`
   - **Descripción:** Navega hacia adelante en el historial y espera a que cargue

10. `voy hacia atrás`
   - **Descripción:** Navega hacia atrás en el historial y espera a que cargue


## OCR

**Total de pasos:** 9

1. `busco el texto "{search_text}" en la página actual usando OCR`
   - **Descripción:** Busca texto específico en la página actual usando OCR

2. `debería encontrar el texto "{expected_text}" en los resultados OCR`
   - **Descripción:** Verifica que un texto específico esté en los resultados OCR

3. `extraigo texto del screenshot "{screenshot_name}" usando OCR`
   - **Descripción:** Extrae texto de un screenshot usando OCR

4. `extraigo y guardo texto OCR del elemento "{element_name}" con identificador "{identifier}" en variable "{variable_name}"`
   - **Descripción:** Extrae texto OCR de un elemento específico y lo guarda en una variable

5. `guardo resultados OCR en archivo "{filename}"`
   - **Descripción:** Guarda los resultados OCR en un archivo

6. `no debería encontrar el texto "{unexpected_text}" en los resultados OCR`
   - **Descripción:** Verifica que un texto específico NO esté en los resultados OCR

7. `tomo screenshot y extraigo texto con OCR usando engine "{engine}"`
   - **Descripción:** Toma screenshot y extrae texto en un solo paso

8. `verifico que el texto es legible en screenshot "{screenshot_name}" con confianza mínima "{min_confidence}"`
   - **Descripción:** Verifica que el texto en un screenshot sea legible usando OCR

9. `verifico que la calidad del texto OCR es al menos "{min_confidence}" por ciento`
   - **Descripción:** Verifica que la calidad del OCR sea superior al mínimo especificado


## PDF

**Total de pasos:** 11

1. `extraigo el texto de la página "{page_number}" del PDF "{filename}" y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Extrae el texto de una página específica del PDF y lo guarda en una variable Ejemplos: - extraigo el texto...

2. `extraigo el texto del PDF "{filename}" y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Extrae todo el texto de un PDF y lo guarda en una variable Ejemplos: - extraigo el texto del PDF...

3. `verifico que el PDF "{filename}" contiene texto que coincide con el patrón "{pattern}"`
   - **Descripción:** Verifica que un PDF contiene texto que coincide con un patrón regex     Ejemplos:   - verifico que el PDF "documento

4. `verifico que el PDF "{filename}" de la carpeta "{directory}" contiene el texto "{text}"`
   - **Descripción:** Verifica que un PDF en una carpeta específica contiene un texto     Permite especificar la carpeta donde se encuentra el PDF

5. `verifico que el PDF "{filename}" tiene metadato "{key}" con valor "{value}"`
   - **Descripción:** Verifica que un PDF contiene metadatos específicos     Ejemplos:   - verifico que el PDF "documento

6. `verifico que el archivo PDF "{filename}" contiene el texto "{text}"`
   - **Descripción:** Verifica que un PDF contiene un texto específico     Busca el texto en todas las páginas del PDF

7. `verifico que el archivo PDF "{filename}" está encriptado`
   - **Descripción:** Verifica que un PDF está encriptado     Ejemplos:   - verifico que el archivo PDF "documento_seguro

8. `verifico que el archivo PDF "{filename}" no contiene el texto "{text}"`
   - **Descripción:** Verifica que un PDF NO contiene un texto específico     Busca el texto en todas las páginas del PDF

9. `verifico que el archivo PDF "{filename}" no está encriptado`
   - **Descripción:** Verifica que un PDF NO está encriptado     Ejemplos:   - verifico que el archivo PDF "documento

10. `verifico que el archivo PDF "{filename}" tiene "{expected_pages}" páginas`
   - **Descripción:** Verifica que un PDF tiene un número específico de páginas     Ejemplos:   - verifico que el archivo PDF "documento

11. `verifico que la página "{page_number}" del PDF "{filename}" contiene el texto "{text}"`
   - **Descripción:** Verifica que una página específica del PDF contiene un texto     Ejemplos:   - verifico que la página "1" del PDF "documento


## Performance

**Total de pasos:** 13

1. `mido y guardo el tiempo de carga de página en la variable "{variable_name}"`
   - **Descripción:** Mide el tiempo de carga de página y lo guarda en una variable

2. `verifico que el dropdown "{dropdown_name}" se expande en menos de "{max_seconds}" segundos con identificador "{identifier}"`
   - **Descripción:** Verifica que un dropdown se expande en tiempo específico

3. `verifico que el elemento "{element_name}" aparece en menos de "{max_seconds}" segundos con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento aparece en un tiempo específico

4. `verifico que el modal "{modal_name}" se abre en menos de "{max_seconds}" segundos con identificador "{identifier}"`
   - **Descripción:** Verifica que un modal se abre en tiempo específico

5. `verifico que el rendimiento del scroll de página es suave`
   - **Descripción:** Verifica que el scroll de la página es suave y sin lag

6. `verifico que el tiempo de respuesta del click en elemento "{element_name}" es menor a "{max_seconds}" segundos con identificador "{identifier}"`
   - **Descripción:** Verifica que la respuesta a un click es rápida

7. `verifico que el tiempo de respuesta del envío de formulario es menor a "{max_seconds}" segundos`
   - **Descripción:** Verifica que el envío de formulario responde en tiempo específico

8. `verifico que el uso de memoria es aceptable después de "{actions_count}" acciones`
   - **Descripción:** Verifica que el uso de memoria del navegador es aceptable

9. `verifico que la animación se completa en menos de "{max_seconds}" segundos en elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica que una animación se completa en tiempo específico

10. `verifico que la imagen "{image_name}" carga en menos de "{max_seconds}" segundos con identificador "{identifier}"`
   - **Descripción:** Verifica que una imagen carga en tiempo específico

11. `verifico que la página carga en menos de "{max_seconds}" segundos`
   - **Descripción:** Verifica que la página carga en un tiempo específico

12. `verifico que las peticiones de red se completan en menos de "{max_seconds}" segundos`
   - **Descripción:** Verifica que todas las peticiones de red se completan en tiempo específico

13. `verifico que los resultados de búsqueda aparecen en menos de "{max_seconds}" segundos`
   - **Descripción:** Verifica que los resultados de búsqueda aparecen rápidamente


## Responsive

**Total de pasos:** 14

1. `establezco el viewport a tamaño desktop "{width}x{height}"`
   - **Descripción:** Establece el viewport a un tamaño desktop específico

2. `establezco el viewport a tamaño móvil "{width}x{height}"`
   - **Descripción:** Establece el viewport a un tamaño móvil específico

3. `establezco el viewport a tamaño tablet "{width}x{height}"`
   - **Descripción:** Establece el viewport a un tamaño tablet específico

4. `verifico el comportamiento del breakpoint en "{width}" píxeles`
   - **Descripción:** Verifica el comportamiento en un breakpoint específico

5. `verifico que el elemento "{element_name}" es visible en móvil con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento es visible en viewport móvil

6. `verifico que el elemento "{element_name}" está oculto en móvil con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento está oculto en viewport móvil

7. `verifico que el elemento "{element_name}" se adapta a cambios de viewport con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento se adapta a diferentes tamaños de viewport

8. `verifico que el elemento "{element_name}" se apila verticalmente en móvil con identificador "{identifier}"`
   - **Descripción:** Verifica que elementos se apilan verticalmente en dispositivos móviles

9. `verifico que el elemento "{element_name}" tiene tamaño de fuente responsive con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene tamaño de fuente que se adapta al viewport

10. `verifico que el menú de navegación se colapsa en móvil`
   - **Descripción:** Verifica que el menú de navegación se colapsa en dispositivos móviles

11. `verifico que el texto es legible en tamaño móvil`
   - **Descripción:** Verifica que el texto es legible en dispositivos móviles

12. `verifico que las imágenes se escalan apropiadamente en móvil`
   - **Descripción:** Verifica que las imágenes se escalan apropiadamente en dispositivos móviles

13. `verifico que los botones son amigables al tacto en móvil`
   - **Descripción:** Verifica que los botones tienen tamaño apropiado para dispositivos táctiles

14. `verifico que no hay scroll horizontal`
   - **Descripción:** Verifica que no hay scroll horizontal en la página


## Salesforce

**Total de pasos:** 17

1. `abro el registro "{record_id}" de Salesforce para el objeto "{object_name}"`
   - **Descripción:** Abre un registro específico por su ID

2. `busco en la búsqueda global de Salesforce con "{search_term}"`
   - **Descripción:** Realiza una búsqueda global en Salesforce

3. `busco y selecciono el lookup "{field_name}" de Salesforce con "{search_term}"`
   - **Descripción:** Busca y selecciona un valor en un campo lookup de Salesforce

4. `cambio a la vista Lightning de Salesforce`
   - **Descripción:** Cambia a Lightning desde Salesforce Classic

5. `cambio a la vista clásica de Salesforce`
   - **Descripción:** Cambia a Salesforce Classic desde Lightning

6. `cierro los mensajes toast de Salesforce`
   - **Descripción:** Cierra todos los mensajes toast visibles

7. `creo un nuevo registro de Salesforce para el objeto "{object_name}"`
   - **Descripción:** Inicia la creación de un nuevo registro

8. `edito el registro de Salesforce`
   - **Descripción:** Inicia la edición del registro actual

9. `elimino el registro de Salesforce`
   - **Descripción:** Elimina el registro actual

10. `espero a que cargue Salesforce Lightning`
   - **Descripción:** Espera a que Salesforce Lightning termine de cargar completamente

11. `espero el mensaje toast de Salesforce "{message_type}"`
   - **Descripción:** Espera a que aparezca un mensaje toast de Salesforce

12. `guardo el registro de Salesforce`
   - **Descripción:** Guarda el registro actual en Salesforce

13. `hago click en la pestaña "{tab_name}" de Salesforce`
   - **Descripción:** Hace click en una pestaña específica de Salesforce

14. `navego a la aplicación de Salesforce "{app_name}"`
   - **Descripción:** Navega a una aplicación específica en Salesforce

15. `relleno el campo de Salesforce "{field_name}" con "{value}"`
   - **Descripción:** Rellena un campo específico en Salesforce (maneja diferentes tipos)

16. `selecciono la opción "{option}" del picklist "{field_name}" de Salesforce`
   - **Descripción:** Selecciona una opción de un picklist de Salesforce

17. `verifico que el campo "{field_name}" del registro de Salesforce contiene "{expected_value}"`
   - **Descripción:** Verifica el valor de un campo en un registro de Salesforce


## Scroll

**Total de pasos:** 9

1. `hago scroll al elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Hace scroll hasta un elemento específico

2. `hago scroll al final de la página`
   - **Descripción:** Hace scroll al final de la página

3. `hago scroll al inicio de la página`
   - **Descripción:** Hace scroll al inicio de la página

4. `hago scroll del elemento "{element_name}" hacia abajo {pixels:d} píxeles con identificador "{identifier}"`
   - **Descripción:** Hace scroll hacia abajo dentro de un elemento específico

5. `hago scroll del elemento "{element_name}" hacia arriba {pixels:d} píxeles con identificador "{identifier}"`
   - **Descripción:** Hace scroll hacia arriba dentro de un elemento específico

6. `hago scroll hacia abajo {pixels:d} píxeles`
   - **Descripción:** Hace scroll hacia abajo un número específico de píxeles

7. `hago scroll hacia arriba {pixels:d} píxeles`
   - **Descripción:** Hace scroll hacia arriba un número específico de píxeles

8. `hago scroll hacia la derecha {pixels:d} píxeles`
   - **Descripción:** Hace scroll hacia la derecha un número específico de píxeles

9. `hago scroll hacia la izquierda {pixels:d} píxeles`
   - **Descripción:** Hace scroll hacia la izquierda un número específico de píxeles


## Supabase Vector

**Total de pasos:** 7

1. `busco en la tabla "{table_name}" el contexto más similar a "{query}" y lo guardo en "{variable_name}"`
   - **Descripción:** Busca contexto similar usando búsqueda vectorial en Supabase con Gemini Args: table_name: Nombre de la tabla con embeddings query: Texto...

2. `busco en la tabla "{table_name}" los {count} contextos más similares a "{query}" y los guardo en "{variable_name}"`
   - **Descripción:** Busca múltiples contextos similares usando búsqueda vectorial con Gemini Args: table_name: Nombre de la tabla con embeddings count: Número de...

3. `cargo el contexto de Supabase tabla "{table_name}" para la query "{query}" en el contexto de Gemini "{context_name}"`
   - **Descripción:** Busca contexto en Supabase y lo carga directamente en Gemini Args: table_name: Tabla de Supabase con embeddings query: Query de...

4. `consulto la tabla "{table_name}" en Supabase y guardo el resultado en "{variable_name}"`
   - **Descripción:** Consulta una tabla de Supabase y guarda el resultado Args: table_name: Nombre de la tabla variable_name: Variable donde guardar el...

5. `consulto la tabla "{table_name}" filtrando por "{column}" igual a "{value}" y guardo en "{variable_name}"`
   - **Descripción:** Consulta una tabla de Supabase con filtro Args: table_name: Nombre de la tabla column: Columna para filtrar value: Valor del...

6. `me conecto a Supabase con URL "{supabase_url}" y key "{supabase_key}"`
   - **Descripción:** Conecta a Supabase usando URL y API key Args: supabase_url: URL del proyecto Supabase supabase_key: API key de Supabase (anon...

7. `me conecto a Supabase usando variables de entorno`
   - **Descripción:** Conecta a Supabase usando variables de entorno SUPABASE_URL y SUPABASE_KEY Variables requeridas: - SUPABASE_URL: URL del proyecto - SUPABASE_KEY: API...


## Tablas

**Total de pasos:** 15

1. `edito la celda de la fila "{row}" columna "{column}" con valor "{new_value}" en la tabla "{table_name}" con identificador "{identifier}"`
   - **Descripción:** Edita el valor de una celda de la tabla

2. `exporto los datos de la tabla "{table_name}" y los guardo en la variable "{variable_name}" con identificador "{identifier}"`
   - **Descripción:** Exporta todos los datos de la tabla como lista de diccionarios

3. `filtro la tabla "{table_name}" por la columna "{column_name}" con valor "{filter_value}" con identificador "{identifier}"`
   - **Descripción:** Filtra una tabla por una columna específica

4. `guardo en la variable "{variable_name}" el valor de la columna "{column}" de la fila "{row}" en la tabla con identificador "{identifier}"`
   - **Descripción:** Guarda el valor de una celda en una variable     El identificador puede ser un localizador directo o un $

5. `hago click en la celda de la fila "{row}" columna "{column}" de la tabla "{table_name}" con identificador "{identifier}"`
   - **Descripción:** Hace click en una celda específica de la tabla

6. `obtengo el valor de la celda fila "{row}" columna "{column}" y lo guardo en la variable "{variable_name}" de la tabla "{table_name}" con identificador "{identifier}"`
   - **Descripción:** Obtiene el valor de una celda y lo guarda en una variable

7. `ordeno la tabla "{table_name}" por la columna "{column_name}" con identificador "{identifier}"`
   - **Descripción:** Ordena una tabla haciendo click en el header de una columna

8. `selecciono la fila "{row_number}" en la tabla "{table_name}" con identificador "{identifier}"`
   - **Descripción:** Selecciona una fila específica de la tabla

9. `verifico que el header de la tabla "{table_name}" tiene las siguientes columnas con identificador "{identifier}"`
   - **Descripción:** Verifica que el header de la tabla tiene las columnas esperadas Usa una tabla de datos en el feature para...

10. `verifico que la celda de la fila "{row}" columna "{column}" contiene "{expected_text}" en la tabla "{table_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica que una celda específica contiene un texto

11. `verifico que la fila "{row_number}" de la tabla "{table_name}" está seleccionada con identificador "{identifier}"`
   - **Descripción:** Verifica que una fila específica está seleccionada

12. `verifico que la fila "{row_number}" de la tabla "{table_name}" tiene datos con formato con identificador "{identifier}"`
   - **Descripción:** Verifica que una fila tiene datos que coinciden con formatos específicos

13. `verifico que la fila "{row_number}" de la tabla "{table_name}" tiene los siguientes datos con identificador "{identifier}"`
   - **Descripción:** Verifica que una fila completa tiene los datos esperados Usa una tabla de datos en el feature para especificar los...

14. `verifico que la tabla "{table_name}" tiene "{expected_columns}" columnas con identificador "{identifier}"`
   - **Descripción:** Verifica que una tabla tiene un número específico de columnas

15. `verifico que la tabla "{table_name}" tiene "{expected_rows}" filas con identificador "{identifier}"`
   - **Descripción:** Verifica que una tabla tiene un número específico de filas Soporta valores directos o variables con ${variable_name} Ejemplos: verifico que...


## Teclado y Mouse

**Total de pasos:** 27

1. `copio el texto seleccionado con Ctrl+C`
   - **Descripción:** Copia el texto seleccionado con Ctrl+C

2. `corto el texto con Ctrl+X`
   - **Descripción:** Corta texto con Ctrl+X

3. `decremento el campo numérico "{field_name}" "{times}" veces con identificador "{identifier}"`
   - **Descripción:** Decrementa el valor de un campo numérico usando la flecha abajo Hace click en el campo y presiona ArrowDown N...

4. `deshago la acción con Ctrl+Z`
   - **Descripción:** Deshace la última acción con Ctrl+Z

5. `escribo el texto "{text}" con retraso de "{delay}" ms entre caracteres`
   - **Descripción:** Escribe texto con retraso entre caracteres

6. `escribo el texto "{text}" y presiono Enter`
   - **Descripción:** Escribe texto y presiona Enter

7. `hago click derecho en las coordenadas x="{x}" y="{y}"`
   - **Descripción:** Hace click derecho en coordenadas específicas

8. `hago click en las coordenadas x="{x}" y="{y}"`
   - **Descripción:** Hace click en coordenadas específicas

9. `hago doble click en las coordenadas x="{x}" y="{y}"`
   - **Descripción:** Hace doble click en coordenadas específicas

10. `hago scroll con la rueda del mouse "{direction}" por "{steps}" pasos`
   - **Descripción:** Hace scroll con la rueda del mouse

11. `incremento el campo numérico "{field_name}" "{times}" veces con identificador "{identifier}"`
   - **Descripción:** Incrementa el valor de un campo numérico usando la flecha arriba Hace click en el campo y presiona ArrowUp N...

12. `limpio el campo actual con Ctrl+A y Delete`
   - **Descripción:** Limpia el campo actual seleccionando todo y borrando

13. `mantengo presionada la tecla "{key}" por "{duration}" segundos`
   - **Descripción:** Mantiene presionada una tecla por un tiempo específico

14. `muevo el mouse a las coordenadas x="{x}" y="{y}"`
   - **Descripción:** Mueve el mouse a coordenadas específicas

15. `navego con la tecla Tab "{times}" veces`
   - **Descripción:** Navega usando la tecla Tab un número específico de veces

16. `pego el texto con Ctrl+V`
   - **Descripción:** Pega texto con Ctrl+V

17. `presiono la combinación de teclas "{keys}"`
   - **Descripción:** Presiona una combinación de teclas (ej: Ctrl+C, Alt+Tab)

18. `presiono la tecla Escape`
   - **Descripción:** Presiona la tecla Escape

19. `presiono la tecla Espacio`
   - **Descripción:** Presiona la tecla Espacio

20. `presiono la tecla de flecha "{direction}"`
   - **Descripción:** Presiona una tecla de flecha específica

21. `pulso la tecla "{key}"`
   - **Descripción:** Presiona una tecla específica

22. `pulso la tecla Enter`
   - **Descripción:** Presiona la tecla Enter

23. `realizo gesto de mouse desde x="{start_x}" y="{start_y}" hasta x="{end_x}" y="{end_y}"`
   - **Descripción:** Realiza un gesto de mouse desde un punto hasta otro

24. `rehago la acción con Ctrl+Y`
   - **Descripción:** Rehace la acción con Ctrl+Y

25. `selecciono todo el texto con Ctrl+A`
   - **Descripción:** Selecciona todo el texto con Ctrl+A

26. `simulo el atajo de teclado "{shortcut}" en el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Simula un atajo de teclado en un elemento específico

27. `simulo escritura humana con el texto "{text}" y retrasos aleatorios`
   - **Descripción:** Simula escritura humana con retrasos aleatorios entre caracteres


## Timing y Cronómetros

**Total de pasos:** 18

1. `espero aleatoriamente entre {min_seconds:d} y {max_seconds:d} segundos`
   - **Descripción:** Espera un tiempo aleatorio entre dos valores

2. `espero con timeout de {timeout:d} segundos hasta que "{selector}" sea visible`
   - **Descripción:** Espera un elemento con timeout personalizado

3. `espero hasta que el elemento "{selector}" contenga el texto "{expected_text}"`
   - **Descripción:** Espera hasta que un elemento contenga un texto específico

4. `espero hasta que el elemento "{selector}" desaparezca`
   - **Descripción:** Espera hasta que un elemento desaparezca

5. `espero hasta que el elemento "{selector}" esté habilitado`
   - **Descripción:** Espera hasta que un elemento esté habilitado

6. `espero hasta que el elemento "{selector}" no esté en estado de carga`
   - **Descripción:** Espera hasta que un elemento no esté en estado de carga

7. `espero hasta que el elemento "{selector}" sea visible`
   - **Descripción:** Espera hasta que un elemento sea visible

8. `espero hasta que el elemento "{selector}" tenga el atributo "{attribute}" con valor "{expected_value}"`
   - **Descripción:** Espera hasta que un elemento tenga un atributo con valor específico

9. `espero hasta que haya en total {count_text} elementos "{selector}"`
   - **Descripción:** Espera hasta que haya un número específico de elementos (soporta variables) Permite usar variables guardadas previamente con la palabra clave...

10. `espero hasta que haya {count:d} elementos "{selector}"`
   - **Descripción:** Espera hasta que haya un número específico de elementos (con número literal)     Ejemplos:     espero hasta que haya 5 elementos "$

11. `espero hasta que la URL contenga "{url_part}"`
   - **Descripción:** Espera hasta que la URL contenga una parte específica

12. `espero hasta que la página termine de cargar`
   - **Descripción:** Espera hasta que la página termine de cargar completamente

13. `espero hasta que no haya requests de red pendientes`
   - **Descripción:** Espera hasta que no haya actividad de red

14. `espero progresivamente: {wait_pattern}`
   - **Descripción:** Espera con patrón progresivo (ej: "1,2,3,5" segundos)

15. `establezco el timeout global en {timeout:d} segundos`
   - **Descripción:** Establece el timeout global para las operaciones

16. `marco el tiempo de inicio como "{timer_name}"`
   - **Descripción:** Inicia un cronómetro con nombre específico

17. `muestro el tiempo transcurrido del cronómetro "{timer_name}"`
   - **Descripción:** Muestra el tiempo transcurrido de un cronómetro

18. `verifico que el cronómetro "{timer_name}" no exceda {max_seconds:d} segundos`
   - **Descripción:** Verifica que un cronómetro no exceda un tiempo máximo


## Validaciones y Aserciones

**Total de pasos:** 88

1. `debería haber al menos {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica que haya al menos un número mínimo de elementos

2. `debería haber como máximo {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica que haya como máximo un número de elementos

3. `debería haber exactamente {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica que haya un número exacto de elementos que coincidan con el selector

4. `debería haberse abierto una nueva ventana con título que contiene "{title}"`
   - **Descripción:** Verifica que se abrió una nueva ventana/tab con un título particular

5. `debería haberse abierto una nueva ventana con url que contiene "{url_part}"`
   - **Descripción:** Verifica que se abrió una nueva ventana/tab con una URL particular

6. `debería ver el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento sea visible Soporta variables en el identificador usando ${variable_name} Ejemplos: debería ver el elemento "Nombre" con...

7. `debería ver el texto "{text}"`
   - **Descripción:** Verifica que un texto sea visible en la página (búsqueda exacta)

8. `debería ver el texto que contiene "{text}"`
   - **Descripción:** Verifica que un texto parcial sea visible en la página (búsqueda parcial)

9. `debería ver en la página el texto {text_with_variable}`
   - **Descripción:** Verifica que un texto parcial sea visible (soporta variables sin comillas) Permite usar variables sin necesidad de comillas: - debería...

10. `el campo "{field_name}" debería estar vacío con identificador "{identifier}"`
   - **Descripción:** Verifica que un campo esté vacío (sin valor)     Ejemplos:   - el campo "Email" debería estar vacío con identificador "$

11. `el campo "{field_name}" debería tener el valor "{value}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un campo tenga un valor específico

12. `el campo "{field_name}" no debería estar vacío con identificador "{identifier}"`
   - **Descripción:** Verifica que un campo NO esté vacío (tiene algún valor) Ejemplos: - el campo "Email" no debería estar vacío con...

13. `el campo "{field_name}" no debería tener el valor "{value}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un campo NO tenga un valor específico     Ejemplos:   - el campo "Email" no debería tener el valor "test@example

14. `el checkbox "{checkbox_name}" debería estar marcado con identificador "{identifier}"`
   - **Descripción:** Verifica que un checkbox esté marcado

15. `el checkbox "{checkbox_name}" no debería estar marcado con identificador "{identifier}"`
   - **Descripción:** Verifica que un checkbox no esté marcado

16. `el elemento "{element_name}" debería contener el texto "{text}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento contenga un texto específico

17. `el elemento "{element_name}" debería estar adjunto al DOM con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento esté adjunto al DOM

18. `el elemento "{element_name}" debería estar deshabilitado con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento esté deshabilitado

19. `el elemento "{element_name}" debería estar habilitado con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento esté habilitado

20. `el elemento "{element_name}" debería estar oculto con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento esté oculto (hidden o display:none)

21. `el elemento "{element_name}" debería existir con identificador "{identifier}" y valor "{value}"`
   - **Descripción:** Verifica que un elemento existe en el DOM usando un localizador dinámico Soporta localizadores dinámicos con placeholders que se reemplazan...

22. `el elemento "{element_name}" debería existir en identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento existe en el DOM (sin importar si es visible)     Soporta localizadores dinámicos con placeholders:   - $

23. `el elemento "{element_name}" debería ser de solo lectura con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento sea de solo lectura (readonly)

24. `el elemento "{element_name}" debería ser editable con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento sea editable

25. `el elemento "{element_name}" debería ser requerido con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento sea requerido (required)

26. `el elemento "{element_name}" debería tener aria-expanded "{state}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tenga aria-expanded con un estado específico (true/false)

27. `el elemento "{element_name}" debería tener atributo data "{data_attr}" con valor "{value}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tenga un data-attribute específico con un valor Ejemplos: - el elemento "Card" debería tener atributo data...

28. `el elemento "{element_name}" debería tener el atributo "{attribute}" con valor "{value}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un atributo tenga un valor específico

29. `el elemento "{element_name}" debería tener el atributo "{attribute}" en identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tenga un atributo específico (sin importar su valor)

30. `el elemento "{element_name}" debería tener el atributo "{attribute}" que contiene "{value}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un atributo contenga un valor específico

31. `el elemento "{element_name}" debería tener el texto exacto "{text}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tenga un texto exacto

32. `el elemento "{element_name}" debería tener id "{element_id}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tenga un id específico

33. `el elemento "{element_name}" debería tener la clase "{css_class}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tenga una clase CSS específica

34. `el elemento "{element_name}" debería tener nombre "{name}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tenga un atributo name específico

35. `el elemento "{element_name}" debería tener rol "{role}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tenga un rol ARIA específico

36. `el elemento "{element_name}" debería tener título "{title}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tenga un atributo title específico

37. `el elemento "{element_name}" no debería existir con identificador "{identifier}" y valor "{value}"`
   - **Descripción:** Verifica que un elemento NO existe en el DOM usando un localizador dinámico Soporta localizadores dinámicos con placeholders que se...

38. `el elemento "{element_name}" no debería existir en identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento NO existe en el DOM     Soporta localizadores dinámicos con placeholders:   - $

39. `el elemento "{element_name}" no debería ser de solo lectura con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento NO sea de solo lectura

40. `el elemento "{element_name}" no debería ser requerido con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento NO sea requerido

41. `el elemento "{element_name}" no debería tener el atributo "{attribute}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento NO tenga un atributo específico

42. `el elemento "{element_name}" no debería tener la clase "{css_class}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento NO tenga una clase CSS específica

43. `el enlace "{element_name}" debería tener href "{href}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un enlace tenga un href específico

44. `el enlace "{element_name}" debería tener href que contiene "{href_part}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un enlace tenga un href que contenga una parte específica

45. `el input "{element_name}" debería tener longitud máxima "{maxlength}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un input tenga una longitud máxima específica

46. `el input "{element_name}" debería tener patrón "{pattern}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un input tenga un patrón de validación específico

47. `el input "{element_name}" debería tener placeholder "{placeholder}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un input tenga un placeholder específico

48. `el input "{element_name}" debería tener tipo "{input_type}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un input tenga un tipo específico (text, email, number, etc

49. `el input "{element_name}" debería tener valor máximo "{max_value}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un input tenga un valor máximo específico

50. `el input "{element_name}" debería tener valor mínimo "{min_value}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un input tenga un valor mínimo específico

51. `el select "{element_name}" debería tener la opción seleccionada "{option_text}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un select tenga una opción específica seleccionada

52. `el select "{element_name}" debería tener {count:d} opciones con identificador "{identifier}"`
   - **Descripción:** Verifica que un select tenga un número específico de opciones

53. `el título de la página debería contener "{text}"`
   - **Descripción:** Verifica que el título de la página contenga un texto

54. `el título de la página debería ser "{title}"`
   - **Descripción:** Verifica que el título de la página sea exacto

55. `guardo en la variable "{variable_name}" el valor de la propiedad CSS "{property}" del elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Guarda el valor de una propiedad CSS en una variable Ejemplo: guardo en la variable "color_boton" el valor de la...

56. `la imagen "{element_name}" debería tener alt "{alt}" con identificador "{identifier}"`
   - **Descripción:** Verifica que una imagen tenga un texto alternativo específico

57. `la imagen "{element_name}" debería tener src "{src}" con identificador "{identifier}"`
   - **Descripción:** Verifica que una imagen tenga un src específico

58. `la url actual debería contener "{url_part}"`
   - **Descripción:** Verifica que la URL actual contenga una parte específica

59. `la url actual debería ser "{url}"`
   - **Descripción:** Verifica la URL actual

60. `no debería ver el elemento "{element_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento no sea visible     Soporta variables en el identificador usando ${variable_name}

61. `no debería ver el texto "{text}"`
   - **Descripción:** Verifica que un texto no sea visible en la página

62. `que debería haber {count:d} ventanas abiertas`
   - **Descripción:** Verifica que hay un número específico de ventanas abiertas

63. `the element "{element_name}" should have aria-label "{aria_label}" with identifier "{identifier}"`
   - **Descripción:** Verifica que un elemento tenga un aria-label específico

64. `verifico que el ancho del elemento "{element_name}" es "{expected_width}" píxeles con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene un ancho específico

65. `verifico que el atributo "{attribute}" del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un atributo de elemento coincide con un patrón regex

66. `verifico que el color de fondo del elemento "{element_name}" es "{expected_color}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene un color de fondo específico

67. `verifico que el color del texto del elemento "{element_name}" es "{expected_color}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene un color de texto específico

68. `verifico que el elemento "{element_name}" está dentro del viewport con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento está visible dentro del viewport

69. `verifico que el elemento "{element_name}" está posicionado en x="{expected_x}" y="{expected_y}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento está en una posición específica

70. `verifico que el elemento "{element_name}" no tiene la clase CSS "{css_class}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento NO tiene una clase CSS específica

71. `verifico que el elemento "{element_name}" no tiene la propiedad CSS "{property}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento NO tiene una propiedad CSS específica Ejemplo: verifico que el elemento "div" no tiene la propiedad...

72. `verifico que el elemento "{element_name}" tiene el atributo "{attribute}" con valor "{expected_value}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene un atributo con valor específico

73. `verifico que el elemento "{element_name}" tiene el foco con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene el foco

74. `verifico que el elemento "{element_name}" tiene la clase CSS "{css_class}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene una clase CSS específica

75. `verifico que el elemento "{element_name}" tiene la propiedad CSS "{property}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene una propiedad CSS específica (sin importar el valor) Ejemplo: verifico que el elemento "button" tiene...

76. `verifico que el tamaño de fuente del elemento "{element_name}" es "{expected_size}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene un tamaño de fuente específico

77. `verifico que el texto del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"`
   - **Descripción:** Verifica que el texto de un elemento coincide con un patrón regex

78. `verifico que el texto del elemento "{element_name}" es numérico con identificador "{identifier}"`
   - **Descripción:** Verifica que el texto de un elemento es numérico

79. `verifico que el texto del elemento "{element_name}" tiene formato de email válido con identificador "{identifier}"`
   - **Descripción:** Verifica que el texto de un elemento tiene formato de email válido

80. `verifico que el texto del elemento "{element_name}" tiene formato de fecha válido "{date_format}" con identificador "{identifier}"`
   - **Descripción:** Verifica que el texto de un elemento tiene formato de fecha válido

81. `verifico que el texto del elemento "{element_name}" tiene formato de teléfono válido con identificador "{identifier}"`
   - **Descripción:** Verifica que el texto de un elemento tiene formato de teléfono válido

82. `verifico que la altura del elemento "{element_name}" es "{expected_height}" píxeles con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene una altura específica

83. `verifico que la longitud del texto del elemento "{element_name}" es "{expected_length}" con identificador "{identifier}"`
   - **Descripción:** Verifica que el texto de un elemento tiene una longitud específica     Funciona con elementos de texto normales, inputs y textareas

84. `verifico que la longitud del texto del elemento "{element_name}" está entre "{min_length}" y "{max_length}" con identificador "{identifier}"`
   - **Descripción:** Verifica que el texto de un elemento tiene una longitud dentro de un rango Funciona con elementos de texto normales,...

85. `verifico que la propiedad CSS "{property}" del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"`
   - **Descripción:** Verifica que una propiedad CSS de un elemento coincide con un patrón regex Ejemplo: verifico que la propiedad CSS "background-color"...

86. `verifico que la propiedad CSS "{property}" del elemento "{element_name}" contiene "{expected_value}" con identificador "{identifier}"`
   - **Descripción:** Verifica que una propiedad CSS de un elemento contiene un valor específico Ejemplo: verifico que la propiedad CSS "font-family" del...

87. `verifico que la propiedad CSS "{property}" del elemento "{element_name}" es "{expected_value}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento tiene una propiedad CSS específica con un valor exacto Ejemplo: verifico que la propiedad CSS "color"...

88. `verifico que la propiedad CSS "{property}" del elemento "{element_name}" no existe con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento NO tiene una propiedad CSS específica Ejemplo: verifico que la propiedad CSS "custom-prop" del elemento "div"...


## Validación JSON

**Total de pasos:** 12

1. `cargo JSON del archivo "{file_path}" y envío POST a "{url}" guardando respuesta en variable "{variable_name}"`
   - **Descripción:** Carga JSON desde un archivo y envía POST     Ejemplo:     When cargo JSON del archivo "payloads/create_user

2. `guardo el JSON de respuesta API en el archivo "{file_path}"`
   - **Descripción:** Guarda la respuesta JSON en un archivo     Ejemplo:     Then guardo el JSON de respuesta API en el archivo "responses/user_response

3. `verifico que el JSON de respuesta API coincide con el archivo "{expected_file}" ignorando campos "{ignored_fields}"`
   - **Descripción:** Verifica que la respuesta JSON coincide con un archivo ignorando campos específicos Ejemplo: Then verifico que el JSON de respuesta...

4. `verifico que el JSON de respuesta API coincide con el archivo "{expected_file}" ignorando orden`
   - **Descripción:** Verifica que la respuesta JSON coincide con un archivo ignorando el orden de arrays Ejemplo: Then verifico que el JSON...

5. `verifico que el JSON de respuesta API coincide con el esquema del archivo "{schema_file}"`
   - **Descripción:** Verifica que la respuesta JSON coincide con un esquema JSON Schema (Draft 7) Ejemplo: Then verifico que el JSON de...

6. `verifico que el JSON de respuesta API coincide exactamente con el archivo "{expected_file}"`
   - **Descripción:** Verifica que la respuesta JSON es exactamente igual al contenido de un archivo Ejemplo: Then verifico que el JSON de...

7. `verifico que el JSON de respuesta API no tiene valores nulos`
   - **Descripción:** Verifica que la respuesta JSON no contiene valores null Ejemplo: Then verifico que el JSON de respuesta API no tiene...

8. `verifico que el JSON de respuesta API tiene el campo "{field_path}" con tipo "{expected_type}"`
   - **Descripción:** Verifica que un campo JSON tiene un tipo específico Tipos soportados: string, number, integer, boolean, array, object, null Ejemplo: Then...

9. `verifico que el array "{array_path}" del JSON de respuesta API contiene un elemento con "{field}" igual a "{value}"`
   - **Descripción:** Verifica que un array JSON contiene un elemento con un campo específico Ejemplo: Then verifico que el array "users" del...

10. `verifico que el campo "{field_path}" del JSON de respuesta API coincide con el patrón "{pattern}"`
   - **Descripción:** Verifica que un campo JSON coincide con una expresión regular Ejemplo: Then verifico que el campo "email" del JSON de...

11. `verifico que el campo "{field_path}" del JSON de respuesta API está en el rango {min_value} a {max_value}`
   - **Descripción:** Verifica que un campo numérico está dentro de un rango Ejemplo: Then verifico que el campo "age" del JSON de...

12. `verifico que todos los elementos del array "{array_path}" del JSON de respuesta API tienen el campo "{field}"`
   - **Descripción:** Verifica que todos los elementos de un array tienen un campo específico Ejemplo: Then verifico que todos los elementos del...


## Variables y Datos

**Total de pasos:** 39

1. `cargo las variables de entorno del archivo "{env_file}"`
   - **Descripción:** Carga variables de entorno desde un archivo específico

2. `concateno las variables "{var1}" y "{var2}" en la variable "{result_var}"`
   - **Descripción:** Concatena dos variables en una nueva variable

3. `copio la variable "{source_var}" a "{target_var}"`
   - **Descripción:** Copia el valor de una variable a otra

4. `creo la variable "{variable_name}" con valor "{value}"`
   - **Descripción:** Crea o actualiza una variable con un valor específico

5. `cuento los elementos con identificador "{identifier}" y guardo el conteo en la variable "{variable_name}"`
   - **Descripción:** Cuenta elementos que coinciden con un localizador y guarda el conteo

6. `establezco la variable de entorno "{var_name}" con valor "{value}"`
   - **Descripción:** Establece una variable de entorno durante la ejecución

7. `genero una variable "{variable_name}" con fecha actual en formato "{date_format}" sumando {days:d} días hábiles`
   - **Descripción:** Genera una variable con fecha actual + días hábiles (lunes a viernes) Los días hábiles son de lunes a viernes...

8. `genero una variable "{variable_name}" con fecha actual usando formato "{date_format}"`
   - **Descripción:** Genera una variable con fecha en formato específico

9. `genero una variable "{variable_name}" con número aleatorio entre {min_val:d} y {max_val:d}`
   - **Descripción:** Genera una variable con número aleatorio

10. `genero una variable "{variable_name}" con texto aleatorio de {length:d} caracteres`
   - **Descripción:** Genera una variable con texto aleatorio

11. `genero una variable "{variable_name}" con timestamp actual`
   - **Descripción:** Genera una variable con timestamp actual

12. `guardo el atributo "{attribute}" del elemento "{selector}" en la variable "{variable_name}"`
   - **Descripción:** Extrae un atributo de un elemento y lo guarda en una variable

13. `guardo el texto del elemento "{selector}" en la variable "{variable_name}"`
   - **Descripción:** Extrae el texto de un elemento y lo guarda en una variable

14. `hago backup de la variable de entorno "{var_name}" como "{backup_name}"`
   - **Descripción:** Hace backup de una variable de entorno

15. `hago click en el botón de login`
   - **Descripción:** Hace click en el botón de login (múltiples selectores comunes)

16. `imprimo las variables de entorno que coinciden con el patrón "{pattern}"`
   - **Descripción:** Imprime variables de entorno que coinciden con un patrón

17. `imprimo todas las variables de entorno`
   - **Descripción:** Imprime todas las variables de entorno (útil para debugging)

18. `incremento la variable numérica "{variable_name}" en {increment:d}`
   - **Descripción:** Incrementa una variable numérica

19. `limpio todas las variables globales`
   - **Descripción:** Limpia todas las variables

20. `muestro el valor de la variable "{variable_name}"`
   - **Descripción:** Muestra el valor actual de una variable

21. `muestro todas las variables actuales`
   - **Descripción:** Muestra todas las variables actuales

22. `navego a la URL de entorno "{env_var_name}"`
   - **Descripción:** Navega a una URL almacenada en una variable de entorno

23. `obtengo el atributo "{attribute}" del elemento "{element_name}" y lo guardo en la variable "{variable_name}" con identificador "{identifier}"`
   - **Descripción:** Obtiene un atributo de un elemento y lo guarda en una variable

24. `obtengo el texto del elemento "{element_name}" y lo guardo en la variable "{variable_name}" con identificador "{identifier}"`
   - **Descripción:** Obtiene el texto de un elemento y lo guarda en una variable

25. `obtengo el título de la página y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Obtiene el título de la página y lo guarda en una variable

26. `obtengo el valor del campo "{field_name}" y lo guardo en la variable "{variable_name}" con identificador "{identifier}"`
   - **Descripción:** Obtiene el valor de un campo y lo guarda en una variable

27. `obtengo la propiedad css "{property}" del elemento "{element_name}" y la guardo en la variable "{variable_name}" con identificador "{identifier}"`
   - **Descripción:** Obtiene una propiedad CSS de un elemento y la guarda en una variable

28. `obtengo la url actual y la guardo en la variable "{variable_name}"`
   - **Descripción:** Obtiene la URL actual y la guarda en una variable

29. `obtengo variable de entorno "{var_name}" y la guardo en variable "{variable_name}"`
   - **Descripción:** Obtiene una variable de entorno y la guarda en una variable del framework

30. `realizo login completo con credenciales de entorno "{username_var}" y "{password_var}"`
   - **Descripción:** Realiza el proceso completo de login usando variables de entorno

31. `relleno el campo "{field_name}" con la variable de entorno "{env_var_name}" usando identificador "{identifier}"`
   - **Descripción:** Rellena un campo con el valor de una variable de entorno

32. `restauro la variable de entorno "{var_name}" desde el backup "{backup_name}"`
   - **Descripción:** Restaura una variable de entorno desde un backup

33. `verifico que existe la variable de entorno "{var_name}"`
   - **Descripción:** Verifica que una variable de entorno existe

34. `verifico que la variable "{variable_name}" contiene "{expected_value}"`
   - **Descripción:** Verifica que una variable contiene un valor específico Soporta tanto el nombre de la variable directamente como con sintaxis ${variable}...

35. `verifico que la variable "{variable_name}" es igual a "{expected_value}"`
   - **Descripción:** Verifica que una variable es exactamente igual a un valor Soporta tanto el nombre de la variable directamente como con...

36. `verifico que la variable de entorno "{var_name}" es igual a "{expected_value}"`
   - **Descripción:** Verifica que una variable de entorno tiene un valor específico

37. `verifico si el checkbox "{checkbox_name}" está marcado y guardo el resultado en la variable "{variable_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica si un checkbox está marcado y guarda el resultado

38. `verifico si el elemento "{element_name}" es visible y guardo el resultado en la variable "{variable_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica si un elemento es visible y guarda el resultado

39. `verifico si el elemento "{element_name}" está habilitado y guardo el resultado en la variable "{variable_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica si un elemento está habilitado y guarda el resultado


## Ventanas y Pestañas

**Total de pasos:** 16

1. `acepto la alerta con texto "{text}"`
   - **Descripción:** Acepta una alerta y envía texto (para prompts)

2. `acepto la alerta simple`
   - **Descripción:** Acepta una alerta de JavaScript (espera a que aparezca)

3. `cambio a la nueva ventana`
   - **Descripción:** Cambia a la ventana más reciente

4. `cambio a la ventana con título "{title}"`
   - **Descripción:** Cambia a una ventana específica por su título con reintentos

5. `cambio a la ventana con url que contiene "{url_part}"`
   - **Descripción:** Sin descripción disponible

6. `cierro la ventana actual`
   - **Descripción:** Cierra la ventana actual

7. `el mensaje de la alerta debería contener "{expected_text}"`
   - **Descripción:** Verifica que el mensaje de la alerta contenga un texto parcial

8. `el mensaje de la alerta debería ser "{expected_text}"`
   - **Descripción:** Verifica que el mensaje de la alerta sea exactamente igual

9. `extraigo el texto del diálogo lo guardo en la variable "{variable_name}" y cierro el diálogo`
   - **Descripción:** Extrae el texto del diálogo, lo guarda en una variable y lo cierra     Este step:   1

10. `guardo el mensaje de la alerta en la variable "{variable_name}"`
   - **Descripción:** Guarda el mensaje de la alerta en una variable

11. `obtengo el texto de la alerta y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Obtiene el texto de una alerta y lo guarda en una variable

12. `que cambio al contenido principal`
   - **Descripción:** Vuelve al contenido principal (sale del iframe)

13. `que cambio al frame "{frame_name}" con identificador "{identifier}"`
   - **Descripción:** Cambia a un frame específico

14. `rechazo la alerta`
   - **Descripción:** Rechaza una alerta de JavaScript (espera a que aparezca)

15. `tomo una captura de pantalla y la guardo como "{filename}"`
   - **Descripción:** Toma una captura de pantalla

16. `tomo una captura del elemento "{element_name}" y la guardo como "{filename}" con identificador "{identifier}"`
   - **Descripción:** Toma una captura de pantalla de un elemento específico


## iFrames

**Total de pasos:** 10

1. `cambio al iframe por src que contiene "{src_part}"`
   - **Descripción:** Cambia al iframe por parte de su URL src

2. `debería ver el elemento "{element_name}" dentro del iframe con identificador "{identifier}"`
   - **Descripción:** Verifica que un elemento sea visible dentro del iframe actual

3. `debería ver texto "{text}" dentro del iframe`
   - **Descripción:** Verifica que un texto sea visible dentro del iframe actual

4. `ejecuto javascript "{script}" dentro del iframe`
   - **Descripción:** Ejecuta JavaScript dentro del iframe actual

5. `espero a que cargue el iframe "{iframe_name}" con identificador "{identifier}"`
   - **Descripción:** Espera a que un iframe termine de cargar

6. `hago click en el elemento "{element_name}" dentro del iframe con identificador "{identifier}"`
   - **Descripción:** Hace click en un elemento dentro del iframe actual

7. `obtengo el número de iframes y lo guardo en la variable "{variable_name}"`
   - **Descripción:** Obtiene el número total de iframes en la página

8. `relleno el campo "{field_name}" con "{text}" dentro del iframe con identificador "{identifier}"`
   - **Descripción:** Rellena un campo dentro del iframe actual

9. `verifico que el iframe "{iframe_name}" tiene src "{expected_src}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un iframe tiene una URL src específica

10. `verifico que existe el iframe "{iframe_name}" con identificador "{identifier}"`
   - **Descripción:** Verifica que un iframe existe en la página


