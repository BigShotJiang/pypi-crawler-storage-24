"""Provider protocol: minimal interface for API providers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:
    from pathlib import Path

    from pollux.providers.models import (
        ProviderFileAsset,
        ProviderRequest,
        ProviderResponse,
    )


@dataclass(frozen=True)
class ProviderCapabilities:
    """Feature flags exposed by providers."""

    persistent_cache: bool
    uploads: bool
    structured_outputs: bool = False
    reasoning: bool = False
    deferred_delivery: bool = False
    conversation: bool = False
    implicit_caching: bool = False


@runtime_checkable
class Provider(Protocol):
    """Minimal provider protocol: generate, upload, create_cache."""

    async def generate(
        self,
        request: ProviderRequest,
    ) -> ProviderResponse:
        """Generate content from the model."""
        ...

    async def upload_file(self, path: Path, mime_type: str) -> ProviderFileAsset:
        """Upload a file and return its asset representation."""
        ...

    async def create_cache(
        self,
        *,
        model: str,
        parts: list[Any],
        system_instruction: str | None = None,
        tools: list[dict[str, Any]] | list[Any] | None = None,
        ttl_seconds: int = 3600,
    ) -> str:
        """Create a cache and return its name."""
        ...

    @property
    def capabilities(self) -> ProviderCapabilities:
        """Feature capabilities for strict option validation."""
        ...
