# -*- coding: utf-8 -*-
# Python

"""Copyright (c) Alexander Fedotov.
This source code is licensed under the license found in the
LICENSE file in the root directory of this source tree.
"""
from typing import List, Dict
from os import environ
import requests


def respond(messages, instructions, **kwargs):
    """
    """
    api_key = environ.get("XAI_API_KEY")
    api_base = environ.get("XAI_API_BASE", "https://api.x.ai/v1")
    api_type = environ.get("XAI_API_TYPE", "open_ai")
    default_model = environ.get("XAI_DEFAULT_MODEL", "grok-4.20-reasoning")

    json_data = {
        "model": kwargs.get("model", default_model),
        "instructions": instructions,
        "input": messages,
        "max_output_tokens": kwargs.get("max_tokens", 64000),
        "reasoning": {
            "summary": "detailed"
        }
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + api_key
    }

    try:
        response = requests.post(
            f"{api_base}/responses",
            headers=headers,
            json=json_data,
        )
        if response.status_code == requests.codes.ok:
            output = response.json()
            text = ''
            thoughts = ''
            for part in output['output']:
                if part['type'] == 'message':
                    for chunk in part['content']:
                        text += chunk['text']
                elif part['type'] == 'reasoning_content':
                    for chunk in part['summary']:
                        thoughts += chunk['text']
        else:
            print(f"Request status code: {response.status_code}")
            return '',''

        return thoughts, text

    except Exception as e:
        print("Unable to generate ChatCompletion response")
        print(f"Exception: {e}")
        return None


if __name__ == '__main__':

    msgs = [
        {
            "role": "user",
            "content": "Are Language Models seeking the Truth?"
        }
    ]

    # continuations = grk_complete(text_before=the_text_before, model='grok-beta', **kwa)
    instruction = "You are an eloquent Assistant."

    thoughts, text = respond(messages=msgs, instructions=instruction)

    print('ok')