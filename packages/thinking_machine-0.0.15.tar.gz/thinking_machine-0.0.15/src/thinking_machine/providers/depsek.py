# -*- coding: utf-8 -*-
# Python

"""Copyright (c) Alexander Fedotov.
This source code is licensed under the license found in the
LICENSE file in the root directory of this source tree.
"""
from os import environ
import requests


def respond(messages, instructions, **kwargs):
    """
    """
    api_key = environ.get("DEPSEK_API_KEY")
    api_base = environ.get("DEPSEK_API_BASE", "https://api.deepseek.com")
    default_model = environ.get("DEPSEK_DEFAULT_MODEL", "deepseek-reasoner")

    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + api_key
    }

    instruction = kwargs.get('system_instruction', instructions)
    first_message = [dict(role='system', content=instruction)] if instruction else []

    # add contents and user text to the first (instruction) message
    first_message.extend(messages)
    instruction_and_contents = first_message

    json_data = {
        "model":            kwargs.get("model", default_model),
        "messages":         instruction_and_contents,
        "max_tokens":       kwargs.get("max_tokens", 32000),
        "temperature":      kwargs.get("temperature", 1.0),
        "thinking": {
            "type": "enabled"
        }
    }
    try:
        response = requests.post(
            f"{api_base}/chat/completions",
            headers=headers,
            json=json_data,
        )
        if response.status_code == requests.codes.ok:
            output = response.json()
            message = output['choices'][0]['message']
            text = message['content']
            thoughts = message['reasoning_content']
        else:
            print(f"Request status code: {response.status_code}")
            return '', ''
        return thoughts, text

    except Exception as e:
        print("Unable to generate ChatCompletion response")
        print(f"Exception: {e}")
        return '', ''


if __name__ == '__main__':

    msgs = [
        {
            "role": "user",
            "content": "Are language models seeking the Truth?"
        }
    ]

    inst = "Do not use markdown or any form of emphasis."

    thoughts, text = respond(messages=msgs, instructions=inst)

    print('ok')