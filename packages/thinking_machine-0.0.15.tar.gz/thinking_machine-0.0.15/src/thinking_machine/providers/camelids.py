# -*- coding: utf-8 -*-
# Python

"""Copyright (c) Alexander Fedotov.
This source code is licensed under the license found in the
LICENSE file in the root directory of this source tree.
"""
from os import environ
import requests


def respond(messages=None, instructions=None, **kwargs):
    """A continuation of text with a given context and instruction.
        kwargs:
            temperature     = 0 to 1.0
            top_p           = 0.0 to 1.0
            top_k           = The maximum number of tokens to consider when sampling.
            n               = 1 is mandatory for this method continuationS have n > 1
            max_tokens      = number of tokens
            stop            = ['stop']  array of up to 4 sequences
    """
    meta_key = environ.get('META_API_KEY', '')  # meta_KEY', '')
    meta_api_base = environ.get('META_API_BASE', 'https://api.llama.com/v1')
    meta_content_model = environ.get('META_DEFAULT_CONTENT_MODEL', 'Llama-4-Maverick-17B-128E-Instruct-FP8')

    instruction         = kwargs.get('system_instruction', instructions)
    first_message       = [dict(role='system', content=instruction)] if instruction else []

    # add contents and user text to the first (instruction) message
    first_message.extend(messages)
    instruction_and_contents = first_message

    json_data = {
        'model':                    kwargs.get('model', meta_content_model),
        'messages':                 instruction_and_contents,
        'response_format':          kwargs.get('response_format',{'type': 'text'}),
        'temperature':              kwargs.get('temperature', 1.0),  # 0.0 to 1.0
        'max_completion_tokens':    kwargs.get('max_tokens', 4028),
        'top_p':                    kwargs.get('top_p', 0.9),
        'top_k':                    kwargs.get('top_k', 10),
        'stream':                   False
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + meta_key
    }
    try:
        response = requests.post(
            url=f'{meta_api_base}/chat/completions',
            headers=headers,
            json=json_data,
        )
        if response.status_code == requests.codes.ok:
            output = response.json()
            text = output['completion_message']['content']['text']
        else:
            print(f'Request status code: {response.status_code}')
            return '', ''

    except Exception as e:
        print(f'Unable to generate response, {e}')
        return '', ''

    return '', text


if __name__ == '__main__':
   print('You have launched main')
