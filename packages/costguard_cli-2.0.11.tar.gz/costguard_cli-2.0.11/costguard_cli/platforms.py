"""CI platform detection and PR/MR comment posting.

Supports GitLab, GitHub, and Azure DevOps. Each platform handler reads
its required configuration from environment variables set by the CI runner.

Comments are idempotent: a hidden HTML marker lets the handler find and
update an existing CostGuard comment instead of creating duplicates.
"""

import os
import re
import sys
from typing import Callable, Optional

import requests

MARKER = "<!-- costguard-result -->"


def detect_ci_platform() -> Optional[str]:
    """Detect the current CI platform from environment variables."""
    if os.environ.get("GITLAB_CI"):
        return "gitlab"
    if os.environ.get("GITHUB_ACTIONS"):
        return "github"
    if os.environ.get("BUILD_REPOSITORY_URI"):
        return "azure_devops"
    return None


def _find_existing_note_id(url: str, headers: dict, marker: str) -> Optional[int]:
    """Scan paginated MR/PR notes for one containing *marker*."""
    page = 1
    while True:
        try:
            resp = requests.get(
                url, headers=headers,
                params={"per_page": 100, "page": page},
                timeout=30,
            )
            if not resp.ok:
                break
            notes = resp.json()
            if not notes:
                break
            for note in notes:
                if marker in note.get("body", ""):
                    return note["id"]
            page += 1
        except Exception:
            break
    return None


def post_gitlab_comment(formatted_output: str) -> None:
    """Post or update a comment on a GitLab merge request."""
    project_id = os.environ.get("CI_PROJECT_ID")
    mr_iid = os.environ.get("CI_MERGE_REQUEST_IID")
    token = os.environ.get("GITLAB_TOKEN")
    gitlab_url = os.environ.get("CI_SERVER_URL", "https://gitlab.com")

    if not all([project_id, mr_iid, token]):
        print(
            "[CostGuard] WARNING: Missing GITLAB_TOKEN for MR comment posting. "
            "Set a project/group access token with 'api' scope as GITLAB_TOKEN in CI/CD variables.",
            file=sys.stderr,
        )
        return

    url = f"{gitlab_url}/api/v4/projects/{project_id}/merge_requests/{mr_iid}/notes"
    headers = {"PRIVATE-TOKEN": token}
    body = f"{MARKER}\n{formatted_output}"

    existing_id = _find_existing_note_id(url, headers, MARKER)

    if existing_id:
        resp = requests.put(
            f"{url}/{existing_id}", headers=headers,
            json={"body": body}, timeout=30,
        )
        action = "Updated"
    else:
        resp = requests.post(url, headers=headers, json={"body": body}, timeout=30)
        action = "Posted"

    if resp.ok:
        print(f"[CostGuard] {action} MR comment.", file=sys.stderr)
    else:
        print(
            f"[CostGuard] Failed to post GitLab comment: {resp.status_code} {resp.text[:300]}",
            file=sys.stderr,
        )


def post_github_comment(formatted_output: str) -> None:
    """Post or update a comment on a GitHub pull request."""
    token = os.environ.get("GITHUB_TOKEN")
    repository = os.environ.get("GITHUB_REPOSITORY")
    github_ref = os.environ.get("GITHUB_REF", "")

    pr_match = re.search(r"refs/pull/(\d+)/", github_ref)
    pr_number = pr_match.group(1) if pr_match else None

    if not all([token, repository, pr_number]):
        print(
            "[CostGuard] WARNING: Missing GitHub env vars for comment posting "
            "(GITHUB_TOKEN, GITHUB_REPOSITORY, GITHUB_REF with PR number).",
            file=sys.stderr,
        )
        return

    url = f"https://api.github.com/repos/{repository}/issues/{pr_number}/comments"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
    }
    body = f"{MARKER}\n{formatted_output}"

    existing_id = _find_existing_comment_github(url, headers)

    if existing_id:
        patch_url = f"https://api.github.com/repos/{repository}/issues/comments/{existing_id}"
        resp = requests.patch(
            patch_url, headers=headers, json={"body": body}, timeout=30,
        )
        action = "Updated"
    else:
        resp = requests.post(url, headers=headers, json={"body": body}, timeout=30)
        action = "Posted"

    if resp.ok:
        print(f"[CostGuard] {action} GitHub PR comment.", file=sys.stderr)
    else:
        print(
            f"[CostGuard] Failed to post GitHub comment: {resp.status_code} {resp.text[:300]}",
            file=sys.stderr,
        )


def _find_existing_comment_github(url: str, headers: dict) -> Optional[int]:
    """Find an existing CostGuard comment on a GitHub PR."""
    page = 1
    while True:
        try:
            resp = requests.get(
                url, headers=headers,
                params={"per_page": 100, "page": page},
                timeout=30,
            )
            if not resp.ok:
                break
            comments = resp.json()
            if not comments:
                break
            for comment in comments:
                if MARKER in comment.get("body", ""):
                    return comment["id"]
            page += 1
        except Exception:
            break
    return None


def _resolve_pr_id_azure(
    collection_uri: str, project: str, repo_id: str, headers: dict,
) -> Optional[str]:
    """Resolve PR ID from source branch via Azure DevOps REST API.

    Queries active pull requests whose source branch matches
    BUILD_SOURCEBRANCH and returns the first match's PR ID.

    Returns None (graceful skip) when:
    - BUILD_SOURCEBRANCH is refs/heads/master (post-merge push, no PR to comment on)
    - No active PR exists for the source branch
    - API call fails (network error, auth error)
    """
    source_branch = os.environ.get("BUILD_SOURCEBRANCH", "")
    if not source_branch:
        return None

    url = (
        f"{collection_uri}/{project}/_apis/git/repositories/{repo_id}"
        f"/pullrequests"
    )
    params = {
        "searchCriteria.sourceRefName": source_branch,
        "searchCriteria.status": "active",
        "$top": "1",
        "api-version": "7.0",
    }

    try:
        resp = requests.get(url, headers=headers, params=params, timeout=30)
        if resp.ok:
            prs = resp.json().get("value", [])
            if prs:
                pr_id = str(prs[0]["pullRequestId"])
                print(
                    f"[CostGuard] Resolved PR #{pr_id} from source branch.",
                    file=sys.stderr,
                )
                return pr_id
    except Exception as exc:
        print(
            f"[CostGuard] WARNING: Failed to resolve PR ID via API: {exc}",
            file=sys.stderr,
        )

    return None


def post_azure_devops_comment(formatted_output: str) -> None:
    """Post or update a comment on an Azure DevOps pull request.

    Auto-exposed vars (no explicit env mapping needed):
        SYSTEM_TEAMFOUNDATIONCOLLECTIONURI, SYSTEM_TEAMPROJECT,
        BUILD_REPOSITORY_ID, BUILD_SOURCEBRANCH

    Must be mapped explicitly (secret):
        SYSTEM_ACCESSTOKEN
    """
    token = os.environ.get("SYSTEM_ACCESSTOKEN")
    collection_uri = os.environ.get("SYSTEM_TEAMFOUNDATIONCOLLECTIONURI", "").rstrip("/")
    project = os.environ.get("SYSTEM_TEAMPROJECT")
    repo_id = os.environ.get("BUILD_REPOSITORY_ID")

    if not all([token, collection_uri, project, repo_id]):
        print(
            "[CostGuard] WARNING: Missing Azure DevOps env vars for comment posting. "
            "Required: SYSTEM_ACCESSTOKEN (must be mapped explicitly). "
            "Auto-exposed: SYSTEM_TEAMFOUNDATIONCOLLECTIONURI, SYSTEM_TEAMPROJECT, "
            "BUILD_REPOSITORY_ID.",
            file=sys.stderr,
        )
        return

    # Build auth header early — needed for both PR resolution and comment posting
    import base64
    b64_token = base64.b64encode(f":{token}".encode()).decode()
    headers = {
        "Authorization": f"Basic {b64_token}",
        "Content-Type": "application/json",
    }

    # 1. Try the branch-policy variable first
    pr_id = os.environ.get("SYSTEM_PULLREQUEST_PULLREQUESTID")
    if pr_id and pr_id.startswith("$("):
        pr_id = None  # unresolved macro — no branch policy

    # 2. Fallback: resolve PR ID from source branch via REST API
    if not pr_id:
        pr_id = _resolve_pr_id_azure(collection_uri, project, repo_id, headers)

    if not pr_id:
        print(
            "[CostGuard] No active PR found for this build. "
            "Skipping comment posting (this is normal for CI push builds).",
            file=sys.stderr,
        )
        return

    threads_url = (
        f"{collection_uri}/{project}/_apis/git/repositories/{repo_id}"
        f"/pullRequests/{pr_id}/threads?api-version=7.0"
    )
    body = f"{MARKER}\n{formatted_output}"

    existing = _find_existing_thread_azure(threads_url, headers)

    if existing:
        thread_id, comment_id = existing
        patch_url = (
            f"{collection_uri}/{project}/_apis/git/repositories/{repo_id}"
            f"/pullRequests/{pr_id}/threads/{thread_id}"
            f"/comments/{comment_id}?api-version=7.0"
        )
        resp = requests.patch(
            patch_url, headers=headers,
            json={"content": body}, timeout=30,
        )
        action = "Updated"
    else:
        payload = {
            "comments": [
                {
                    "parentCommentId": 0,
                    "content": body,
                    "commentType": 1,
                }
            ],
        }
        resp = requests.post(threads_url, headers=headers, json=payload, timeout=30)
        action = "Posted"

    if resp.ok:
        print(f"[CostGuard] {action} Azure DevOps PR comment.", file=sys.stderr)
    else:
        print(
            f"[CostGuard] Failed to post Azure DevOps comment: "
            f"{resp.status_code} {resp.text[:300]}\n"
            f"[CostGuard] DEBUG URL: {threads_url}",
            file=sys.stderr,
        )


def _find_existing_thread_azure(
    threads_url: str, headers: dict,
) -> Optional[tuple[int, int]]:
    """Find a CostGuard thread/comment on an Azure DevOps PR.

    Returns (thread_id, comment_id) or None.
    """
    try:
        resp = requests.get(threads_url, headers=headers, timeout=30)
        if not resp.ok:
            return None
        for thread in resp.json().get("value", []):
            for comment in thread.get("comments", []):
                if MARKER in comment.get("content", ""):
                    return thread["id"], comment["id"]
    except Exception:
        pass
    return None


_HANDLERS: dict[str, Callable[[str], None]] = {
    "gitlab": post_gitlab_comment,
    "github": post_github_comment,
    "azure_devops": post_azure_devops_comment,
}


def post_ci_comment(formatted_output: str) -> None:
    """Detect CI platform and post the formatted output as a comment."""
    platform = detect_ci_platform()
    if platform is None:
        print(
            "[CostGuard] No supported CI platform detected. Skipping comment posting.",
            file=sys.stderr,
        )
        return

    handler = _HANDLERS[platform]
    try:
        handler(formatted_output)
    except Exception as exc:
        print(f"[CostGuard] Error posting comment to {platform}: {exc}", file=sys.stderr)
