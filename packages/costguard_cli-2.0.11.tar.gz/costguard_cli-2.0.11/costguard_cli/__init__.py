"""CostGuard CLI — shift-left cost governance for CI/CD pipelines."""

__version__ = "2.0.11"
