#!/usr/bin/env python3
"""
Setup script for markdup package.
This file is provided for backward compatibility with pip.
The main configuration is in pyproject.toml.
"""

from setuptools import Extension, setup

extensions = []

try:
    from Cython.Build import cythonize

    extensions = cythonize(
        [
            Extension(
                "markdup._cython_accs",
                ["markdup/_cython_accs.pyx"],
            )
        ],
        language_level=3,
    )
except Exception:
    # Optional accelerator: build continues without Cython.
    extensions = []

if __name__ == "__main__":
    setup(ext_modules=extensions)
