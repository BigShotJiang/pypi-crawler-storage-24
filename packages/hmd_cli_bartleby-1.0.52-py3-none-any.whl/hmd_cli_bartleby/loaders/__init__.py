# Loaders for AI components
