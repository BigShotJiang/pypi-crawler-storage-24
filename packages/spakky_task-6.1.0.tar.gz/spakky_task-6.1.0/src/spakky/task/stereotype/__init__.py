"""Task handler stereotype module."""
