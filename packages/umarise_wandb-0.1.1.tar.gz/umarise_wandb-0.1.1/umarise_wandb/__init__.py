"""
umarise-wandb: Anchor W&B artifacts to Bitcoin.

Usage:
    # Option 1: Auto-anchor (recommended)
    import umarise_wandb
    umarise_wandb.enable()
    # All subsequent wandb.log_artifact() calls are anchored automatically

    # Option 2: Explicit
    from umarise_wandb import anchor_artifact
    umarise_wandb.anchor_artifact(artifact, run=run)
"""

from umarise_wandb.anchor import anchor_artifact, anchor_logged_artifact, anchor_file
from umarise_wandb.callback import enable, disable

__version__ = "0.1.0"
__all__ = ["anchor_artifact", "anchor_logged_artifact", "anchor_file", "enable", "disable"]
