# umarise-wandb

Anchor W&B artifacts to Bitcoin. Zero-touch provenance for ML experiments.

```
pip install umarise-wandb
```

## Quick start

```python
import umarise_wandb

# Enable once. Every artifact is anchored automatically.
umarise_wandb.enable()
```

That's it. Every `wandb.log_artifact()` call now anchors the artifact to Bitcoin in the background.

## Explicit anchoring

```python
import wandb
import umarise_wandb

with wandb.init() as run:
    artifact = wandb.Artifact("my-model", type="model")
    artifact.add_file("model.pt")
    run.log_artifact(artifact)

    # Anchor explicitly
    results = umarise_wandb.anchor_artifact(artifact)
    # results[0]["origin_id"] -> UUID
```

## Anchor a previously logged artifact

```python
results = umarise_wandb.anchor_logged_artifact("my-model:v3")
```

## What happens

1. File is hashed locally (SHA-256). Bytes never leave your machine.
2. Hash is submitted to Umarise Core API.
3. Umarise anchors to Bitcoin via OpenTimestamps.
4. `origin_id` is logged to your W&B run summary.
5. Within ~2 hours, proof is confirmed on the Bitcoin blockchain.

## W&B metadata written

| Key | Location | Value |
|-----|----------|-------|
| `umarise/origin_id` | Run log | UUID |
| `umarise/anchored` | Run log | `true` |
| `umarise_anchored` | Run summary | `true` |
| `umarise_last_origin_id` | Run summary | UUID |

## Environment

Set `UMARISE_API_KEY` or pass `api_key=` to any function.

```bash
export UMARISE_API_KEY=um_your_key
```

## Design principle

`umarise-wandb` never breaks your training pipeline. If anchoring fails (network, API), it silently continues. Your experiment always completes.

## Verify independently

The proof is yours. Verify without Umarise:
- [verify-anchoring.org](https://verify-anchoring.org)
- `ots verify proof.ots`

## Links

- [Umarise](https://umarise.com)
- [API Reference](https://umarise.com/api-reference)
- [Case Study: 89 anchors/day, zero human intervention](https://umarise.com/case/ai-code-generation)
- [Integration Guide](https://umarise.com/integrate)

## License

[Unlicense](https://unlicense.org/) - Public Domain
