#!/usr/bin/env python3
"""
Setup script for AILOOS package.
"""

from setuptools import setup, find_packages

setup(
    name="ailoos",
    version="4.3.6",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.9",
    install_requires=[
        "aiohttp>=3.8.0",
        "psutil>=5.9.0",
        "numpy>=1.21.0",
        "pyyaml>=6.0",
        "requests>=2.28.0",
        "tqdm>=4.64.0",
        "structlog>=21.1.0",
    ],
)
