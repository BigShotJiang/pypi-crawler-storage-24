"""
Wallet Manager - Gestor completo de wallets DRACMA (Real EmpoorioChain Integration)
Maneja creación, gestión y operaciones de wallets con persistencia y seguridad.
"""

import asyncio
import json
import os
import time
import hashlib
import secrets
from urllib.parse import urlparse
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from pathlib import Path

from ..core.logging import get_logger
# from .core import Blockchain, Wallet, Transaction, get_blockchain # Removed Mock
# from .dracma_token import dracmaManager, get_token_manager # Removed Mock

try:
    from substrateinterface import SubstrateInterface, Keypair, KeypairType
    from substrateinterface.exceptions import SubstrateRequestException
    HAS_SUBSTRATE_INTERFACE = True
except Exception:
    SubstrateInterface = None  # type: ignore
    Keypair = None  # type: ignore
    KeypairType = None  # type: ignore
    SubstrateRequestException = Exception  # type: ignore
    HAS_SUBSTRATE_INTERFACE = False

logger = get_logger(__name__)


def _derive_substrate_ws_url() -> str:
    """Resolve the best available Substrate WebSocket endpoint for the wallet backend."""
    explicit = (
        os.getenv("AILOOS_SUBSTRATE_WS_URL")
        or os.getenv("EMPOORIOCHAIN_WS_URL")
    )
    if explicit:
        return explicit

    http_like = (
        os.getenv("EMPORIO_RPC_URL")
        or os.getenv("BLOCKCHAIN_RPC_URL")
        or os.getenv("AILOOS_BLOCKCHAIN_RPC_URL")
    )
    if http_like:
        parsed = urlparse(http_like)
        if parsed.scheme in {"http", "https"} and parsed.netloc:
            ws_scheme = "wss" if parsed.scheme == "https" else "ws"
            return f"{ws_scheme}://{parsed.netloc}"
        if parsed.scheme in {"ws", "wss"} and parsed.netloc:
            return http_like

    try:
        from ..core.config import get_config

        config = get_config()
        rpc_url = getattr(config.blockchain, "rpc_url", "")
        if rpc_url:
            parsed = urlparse(rpc_url)
            if parsed.scheme in {"http", "https"} and parsed.netloc:
                ws_scheme = "wss" if parsed.scheme == "https" else "ws"
                return f"{ws_scheme}://{parsed.netloc}"
            if parsed.scheme in {"ws", "wss"} and parsed.netloc:
                return rpc_url
    except Exception:
        pass

    return "wss://rpc.empooriochain.org"


def _candidate_substrate_ws_urls(primary: str) -> List[str]:
    """Build an ordered set of node endpoints, keeping a production fallback."""
    candidates: List[str] = []
    for value in (
        primary,
        os.getenv("AILOOS_SUBSTRATE_WS_URL"),
        os.getenv("EMPOORIOCHAIN_WS_URL"),
        os.getenv("EMPOORIOCHAIN_WS_FALLBACK"),
        os.getenv("AILOOS_SUBSTRATE_WS_FALLBACK"),
        "wss://rpc.empooriochain.org",
        "ws://217.160.88.153:9944",
    ):
        if not value:
            continue
        normalized = value.strip()
        if normalized and normalized not in candidates:
            candidates.append(normalized)
    return candidates


@dataclass
class WalletInfo:
    """Información completa de una wallet."""
    wallet_id: str
    address: str
    balance: float
    staked_amount: float = 0.0
    rewards_earned: float = 0.0
    transaction_count: int = 0
    created_at: datetime = None
    last_activity: datetime = None
    security_level: str = "standard"  # standard, high, maximum
    mnemonic: str = None # Added for real signing

    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.last_activity is None:
            self.last_activity = datetime.now()


@dataclass
class TransactionRecord:
    """Registro completo de transacción."""
    tx_hash: str
    wallet_id: str
    tx_type: str  # transfer, stake, unstake, reward, purchase
    amount: float
    recipient: Optional[str] = None
    sender: Optional[str] = None
    timestamp: datetime = None
    status: str = "pending"  # pending, confirmed, failed
    block_number: Optional[int] = None
    gas_used: Optional[int] = None
    data: Dict[str, Any] = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()
        if self.data is None:
            self.data = {}


class WalletManager:
    """
    Gestor completo de wallets Dracma conectado a EmpoorioChain Real.
    """

    def __init__(self, storage_path: str = "./wallets", node_url: str = "wss://rpc.empooriochain.org"):
        env_storage = os.getenv("AILOOS_WALLET_STORAGE_PATH")
        self.storage_path = Path(env_storage or storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.node_url = _derive_substrate_ws_url() or node_url
        self.substrate = None

        # Estado en memoria
        self.wallets: Dict[str, WalletInfo] = {}
        self.transactions: Dict[str, List[TransactionRecord]] = {}

        # Configuración de seguridad
        self.encryption_key = self._generate_encryption_key()
        self.backup_enabled = True

        # Initial connection
        self._connect_node()

        # Cargar datos existentes
        self._load_wallets()

        logger.info(f"💰 Wallet Manager initialized with {len(self.wallets)} wallets")

    def _connect_node(self):
        if not HAS_SUBSTRATE_INTERFACE:
            logger.warning("⚠️ substrate-interface not available; wallet runs in offline mode")
            self.substrate = None
            return
        last_error = None
        for candidate in _candidate_substrate_ws_urls(self.node_url):
            try:
                substrate = SubstrateInterface(
                    url=candidate,
                    ss58_format=42,
                    type_registry_preset='substrate-node-template'
                )
                self.substrate = substrate
                self.node_url = candidate
                logger.info(f"✅ Connected to EmpoorioChain node at {candidate}")
                return
            except Exception as e:
                last_error = e
                logger.warning(f"Failed to connect to node endpoint {candidate}: {e}")

        logger.error(f"❌ Failed to connect to node: {last_error}")
        self.substrate = None

    def _ensure_connected(self) -> bool:
        if self.substrate:
            return True
        self._connect_node()
        return self.substrate is not None

    def is_connected(self) -> bool:
        return self.substrate is not None

    def get_chain_info(self) -> Dict[str, Any]:
        """Return real chain info from the connected Substrate node when available."""
        if not self._ensure_connected():
            return {
                "is_valid": False,
                "status": "offline",
                "endpoint": self.node_url,
                "total_blocks": 0,
            }

        try:
            chain_name = self.substrate.rpc_request("system_chain", []).get("result")
            chain_type = self.substrate.rpc_request("system_chainType", []).get("result")
            node_name = self.substrate.rpc_request("system_name", []).get("result")
            node_version = self.substrate.rpc_request("system_version", []).get("result")
            finalized_hash = self.substrate.rpc_request("chain_getFinalizedHead", []).get("result")
            header = {}
            if finalized_hash:
                header = self.substrate.rpc_request("chain_getHeader", [finalized_hash]).get("result") or {}

            block_number_hex = header.get("number", "0x0")
            block_number = int(block_number_hex, 16) if isinstance(block_number_hex, str) else 0
            return {
                "is_valid": True,
                "status": "synced",
                "endpoint": self.node_url,
                "chain": chain_name,
                "chain_type": chain_type,
                "node_name": node_name,
                "node_version": node_version,
                "finalized_head": finalized_hash,
                "total_blocks": block_number,
            }
        except Exception as e:
            logger.warning(f"Failed to query chain info: {e}")
            return {
                "is_valid": False,
                "status": "degraded",
                "endpoint": self.node_url,
                "error": str(e),
                "total_blocks": 0,
            }

    def _generate_encryption_key(self) -> str:
        return secrets.token_hex(32)

    def _load_wallets(self):
        try:
            for wallet_file in self.storage_path.glob("*.json"):
                try:
                    with open(wallet_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)

                    # Handle legacy/migrated structure
                    info_data = data['info']
                    if 'balance' not in info_data: info_data['balance'] = 0.0 # Migration

                    wallet_info = WalletInfo(**info_data)
                    self.wallets[wallet_info.wallet_id] = wallet_info
                    
                    if 'transactions' in data:
                        self.transactions[wallet_info.wallet_id] = [
                            TransactionRecord(**tx) for tx in data['transactions']
                        ]

                except Exception as e:
                    logger.warning(f"Failed to load wallet {wallet_file}: {e}")

        except Exception as e:
            logger.error(f"Error loading wallets: {e}")

    def _save_wallet(self, wallet_id: str):
        try:
            wallet_info = self.wallets[wallet_id]
            wallet_file = self.storage_path / f"{wallet_id}.json"

            data = {
                'info': asdict(wallet_info),
                'transactions': [asdict(tx) for tx in self.transactions.get(wallet_id, [])],
                'version': '2.0-real'
            }

            with open(wallet_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, default=str)

        except Exception as e:
            logger.error(f"Error saving wallet {wallet_id}: {e}")

    async def create_wallet(self, user_id: str, label: str = "default",
                          security_level: str = "standard") -> Dict[str, Any]:
        try:
            if not HAS_SUBSTRATE_INTERFACE:
                return {'success': False, 'error': 'substrate-interface dependency not installed'}
            wallet_id = f"{user_id}_{label}_{int(datetime.now().timestamp())}"

            # Generate Real Substrate Keypair
            mnemonic = Keypair.generate_mnemonic()
            keypair = Keypair.create_from_mnemonic(mnemonic, ss58_format=42)

            wallet_info = WalletInfo(
                wallet_id=wallet_id,
                address=keypair.ss58_address,
                balance=0.0,
                security_level=security_level,
                mnemonic=mnemonic
            )

            self.wallets[wallet_id] = wallet_info
            self.transactions[wallet_id] = []
            self._save_wallet(wallet_id)

            logger.info(f"✅ Created REAL EmpoorioChain wallet {wallet_id}")

            return {
                'success': True,
                'wallet_id': wallet_id,
                'address': keypair.ss58_address,
                'mnemonic': mnemonic # Return only once!
            }

        except Exception as e:
            logger.error(f"❌ Error creating wallet: {e}")
            return {'success': False, 'error': str(e)}

    def get_user_wallets(self, user_id: str) -> List[WalletInfo]:
        user_wallets = []
        for wallet in self.wallets.values():
            if wallet.wallet_id.startswith(f"{user_id}_"):
                user_wallets.append(wallet)
        return user_wallets

    async def get_wallet_balance(self, wallet_id: str) -> Dict[str, Any]:
        try:
            if wallet_id not in self.wallets:
                return {'error': 'Wallet not found'}

            wallet_info = self.wallets[wallet_id]

            # Query Real On-Chain Balance
            if self.substrate:
                try:
                    result = self.substrate.query('System', 'Account', [wallet_info.address])
                    free = result.value['data']['free']
                    # Assuming 18 decimals, adjust if 12
                    # EmpoorioChain standard is usually 12 or 18. Defaulting to 1e12 (like DOT) or 1e18 (like ETH)
                    # Let's assume 1e18 for compatibility with current codebase expectations if they were ETH-like
                    # Or check metadata. For safety, return float representation.
                    # If this is a massive number (u128), python float loses precision but is fine for display.
                    
                    real_balance = float(free) / 10**12 # Assuming 12 decimals (Substrate default) or 18?
                    # Let's check previous terminal/Dracma code. Code assumed float directly.
                    # We'll normalize to "Dracma" units.
                    
                    if real_balance != wallet_info.balance:
                        wallet_info.balance = real_balance
                        self._save_wallet(wallet_id)
                except Exception as e:
                    logger.warning(f"Failed to query chain balance: {e}")

            return {
                'wallet_id': wallet_id,
                'address': wallet_info.address,
                'total_balance': wallet_info.balance,
                'available_balance': wallet_info.balance - wallet_info.staked_amount,
                'staked_amount': wallet_info.staked_amount,
                'rewards_earned': wallet_info.rewards_earned,
                'last_updated': datetime.now().isoformat()
            }

        except Exception as e:
            logger.error(f"Error getting balance for {wallet_id}: {e}")
            return {'error': str(e)}

    async def transfer(self, from_wallet_id: str, to_address: str, amount: float,
                      description: str = "") -> Dict[str, Any]:
        """Transfer tokens using Real EmpoorioChain Extrinsics"""
        try:
            if from_wallet_id not in self.wallets:
                return {'success': False, 'error': 'Wallet not found'}
            
            if not self.substrate:
                self._connect_node()
                if not self.substrate:
                    return {'success': False, 'error': 'Node connection failed'}

            from_wallet = self.wallets[from_wallet_id]
            
            # Recreate keypair
            if not from_wallet.mnemonic:
                 return {'success': False, 'error': 'No mnemonic found for signing'}
            
            keypair = Keypair.create_from_mnemonic(from_wallet.mnemonic, ss58_format=42)
            
            # Convert amount to lowest unit (Planks)
            # Assuming 12 decimals
            amount_planks = int(amount * 10**12)
            
            logger.info(f"Sending {amount} ({amount_planks} planks) to {to_address}")

            # Compose Extrinsic
            call = self.substrate.compose_call(
                call_module='Balances',
                call_function='transfer_allow_death',
                call_params={
                    'dest': to_address,
                    'value': amount_planks
                }
            )
            
            extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
            
            # Submit and Wait
            receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
            
            if receipt.is_success:
                tx_hash = receipt.extrinsic_hash
                logger.info(f"✅ Transfer successful: {tx_hash}")
                
                 # Log transaction locally
                tx_record = TransactionRecord(
                    tx_hash=tx_hash,
                    wallet_id=from_wallet_id,
                    tx_type='transfer',
                    amount=amount,
                    recipient=to_address,
                    sender=from_wallet.address,
                    status='confirmed',
                    timestamp=datetime.now()
                )
                if from_wallet_id not in self.transactions:
                    self.transactions[from_wallet_id] = []
                self.transactions[from_wallet_id].append(tx_record)
                
                 # Update balance cache
                from_wallet.balance -= amount # Optimistic update
                self._save_wallet(from_wallet_id)
                
                return {
                    'success': True,
                    'tx_hash': tx_hash,
                    'amount': amount,
                    'block': receipt.block_number
                }
            else:
                 return {'success': False, 'error': f"Extrinsic failed: {receipt.error_message}"}

        except Exception as e:
            logger.error(f"Error transferring tokens: {e}")
            return {'success': False, 'error': str(e)}

    async def governance_list_proposals(self, limit: int = 100) -> Dict[str, Any]:
        """Read governance proposals from CommunityGovernance storage."""
        try:
            if not self._ensure_connected():
                return {"success": False, "error": "Node connection failed"}

            items: List[Dict[str, Any]] = []
            count = 0
            for key_obj, value_obj in self.substrate.query_map('CommunityGovernance', 'Proposals'):
                proposal_id = getattr(key_obj, "value", key_obj)
                value = getattr(value_obj, "value", value_obj) or {}
                item = {
                    "proposal_id": int(proposal_id),
                    "status": value.get("status"),
                    "proposer": value.get("proposer"),
                    "submitted_at": value.get("submitted_at"),
                    "voting_ends_at": value.get("voting_ends_at"),
                    "proposal_type": value.get("proposal_type"),
                    "description": value.get("description"),
                    "deposit": value.get("deposit"),
                    "execution_data": value.get("execution_data"),
                }
                items.append(item)
                count += 1
                if count >= limit:
                    break

            items.sort(key=lambda x: x.get("proposal_id", 0), reverse=True)
            return {"success": True, "proposals": items}
        except Exception as e:
            logger.error(f"Error listing governance proposals: {e}")
            return {"success": False, "error": str(e)}

    async def governance_submit_proposal(
        self,
        wallet_id: str,
        proposal_type: str,
        description: str,
        execution_data: bytes = b""
    ) -> Dict[str, Any]:
        """Submit governance proposal on-chain via CommunityGovernance.submit_proposal."""
        try:
            if wallet_id not in self.wallets:
                return {"success": False, "error": "Wallet not found"}
            if not self._ensure_connected():
                return {"success": False, "error": "Node connection failed"}
            if not HAS_SUBSTRATE_INTERFACE:
                return {"success": False, "error": "substrate-interface dependency not installed"}

            wallet = self.wallets[wallet_id]
            if not wallet.mnemonic:
                return {"success": False, "error": "No mnemonic found for signing"}
            keypair = Keypair.create_from_mnemonic(wallet.mnemonic, ss58_format=42)

            # Precheck deposit requirement so users get a deterministic error before paying tx fee.
            try:
                proposal_deposit = int(self.substrate.get_constant('CommunityGovernance', 'ProposalDeposit').value)
                account_info = self.substrate.query('System', 'Account', [keypair.ss58_address]).value
                free_balance = int(account_info.get('data', {}).get('free', 0))
                if free_balance < proposal_deposit:
                    return {
                        "success": False,
                        "error": "Insufficient balance for governance proposal deposit",
                        "required_deposit": proposal_deposit,
                        "free_balance": free_balance,
                    }
            except Exception:
                # Continue if constant/account precheck is not available in this runtime metadata.
                pass

            call = self.substrate.compose_call(
                call_module='CommunityGovernance',
                call_function='submit_proposal',
                call_params={
                    "proposal_type": {proposal_type: None},
                    "description": description.encode("utf-8"),
                    "execution_data": execution_data,
                }
            )
            nonce = int(self.substrate.rpc_request('system_accountNextIndex', [keypair.ss58_address]).get('result', 0))
            extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair, nonce=nonce)
            receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
            if not receipt.is_success:
                return {"success": False, "error": f"Extrinsic failed: {receipt.error_message}"}
            return {
                "success": True,
                "tx_hash": receipt.extrinsic_hash,
                "block": receipt.block_number,
            }
        except Exception as e:
            logger.error(f"Error submitting governance proposal: {e}")
            return {"success": False, "error": str(e)}

    async def governance_vote(
        self,
        wallet_id: str,
        proposal_id: int,
        vote: str,
    ) -> Dict[str, Any]:
        """Vote on governance proposal via CommunityGovernance.vote_on_proposal."""
        try:
            if wallet_id not in self.wallets:
                return {"success": False, "error": "Wallet not found"}
            if not self._ensure_connected():
                return {"success": False, "error": "Node connection failed"}
            if not HAS_SUBSTRATE_INTERFACE:
                return {"success": False, "error": "substrate-interface dependency not installed"}
            if vote not in {"Aye", "Nay"}:
                return {"success": False, "error": "vote must be Aye or Nay"}

            wallet = self.wallets[wallet_id]
            if not wallet.mnemonic:
                return {"success": False, "error": "No mnemonic found for signing"}
            keypair = Keypair.create_from_mnemonic(wallet.mnemonic, ss58_format=42)

            call = self.substrate.compose_call(
                call_module='CommunityGovernance',
                call_function='vote_on_proposal',
                call_params={
                    "proposal_id": int(proposal_id),
                    "vote": {vote: None},
                }
            )
            nonce = int(self.substrate.rpc_request('system_accountNextIndex', [keypair.ss58_address]).get('result', 0))
            extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair, nonce=nonce)
            receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
            if not receipt.is_success:
                return {"success": False, "error": f"Extrinsic failed: {receipt.error_message}"}
            return {
                "success": True,
                "tx_hash": receipt.extrinsic_hash,
                "block": receipt.block_number,
            }
        except Exception as e:
            logger.error(f"Error casting governance vote: {e}")
            return {"success": False, "error": str(e)}

    # Staking stubs - keep local for logic but ideally call Staking pallet
    async def stake(self, wallet_id: str, amount: float) -> Dict[str, Any]:
         # Mock local staking logic maintained for compatibility
         # Can be improved to call pallet-staking later
        if os.getenv("AILOOS_TERMINAL_STRICT_REAL", "false").lower() == "true":
             return {'success': False, 'error': 'REAL STAKING REQUIRED: Please connect to a Substrate node with pallet-staking enabled.'}
        try:
            if wallet_id not in self.wallets: return {'success': False, 'error': 'Wallet not found'}
            wallet = self.wallets[wallet_id]
            wallet.staked_amount += amount
            self._save_wallet(wallet_id)
            return {'success': True, 'staked_amount': wallet.staked_amount}
        except Exception as e: return {'error': str(e)}

    async def unstake(self, wallet_id: str, amount: float) -> Dict[str, Any]:
        try:
            if wallet_id not in self.wallets: return {'success': False, 'error': 'Wallet not found'}
            wallet = self.wallets[wallet_id]
            if wallet.staked_amount >= amount:
                wallet.staked_amount -= amount
                self._save_wallet(wallet_id)
                return {'success': True, 'staked_amount': wallet.staked_amount}
            return {'success': False, 'error': 'Insufficient staked'}
        except Exception as e: return {'error': str(e)}

    def get_transaction_history(self, wallet_id: str, limit: int = 20) -> List[Dict[str, Any]]:
        if wallet_id not in self.transactions: return []
        txs = self.transactions[wallet_id]
        txs.sort(key=lambda x: x.timestamp, reverse=True)
        return [asdict(tx) for tx in txs[:limit]]

    async def backup_wallet(self, wallet_id: str, backup_path: str) -> bool:
        # Simple file copy backup
        return True # Stub

    async def restore_wallet(self, backup_file: str) -> Dict[str, Any]:
        return {'success': False, 'error': 'Not implemented'}

    def get_wallet_stats(self, wallet_id: str) -> Dict[str, Any]:
        # Reuse balance logic
        return {'wallet_id': wallet_id, 'status': 'active'}

    # Singleton pattern
_wallet_manager: Optional[WalletManager] = None

def get_wallet_manager() -> WalletManager:
    global _wallet_manager
    if _wallet_manager is None:
        _wallet_manager = WalletManager()
    return _wallet_manager

def main():
    # CLI Stub
    pass

if __name__ == "__main__":
    main()
