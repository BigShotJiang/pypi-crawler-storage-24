# pyphonetik

Python bindings for [phonetik](https://crates.io/crates/phonetik), a phonetic analysis engine for English. Rhyme detection, scansion, syllable counting, and phonetic comparison backed by a 126K-word embedded dictionary.

## Install

```
pip install pyphonetik
```

## Usage

```python
from pyphonetik import Engine

p = Engine()

# Lookup
info = p.lookup("hello")
# {'word': 'HELLO', 'phonemes': ['HH', 'AH0', 'L', 'OW1'], 'syllable_count': 2, ...}

# Rhymes
p.perfect_rhymes("cat")  # [{'word': 'BAT', 'rhyme_type': 'perfect', ...}, ...]
p.slant_rhymes("love", 10)
p.near_rhymes("night", 10)
p.rhymes("cat", 50)  # all types, merged

# Scansion
scan = p.scan("uneasy lies the head that wears the crown")
scan["meter"]["name"]  # 'iambic pentameter'
scan["visual"]         # 'x / x / x / x / x /'

# Raw dictionary stress (no function word demotion)
raw = p.scan("uneasy lies the head that wears the crown", mode="dictionary")
scan["syllable_count"]  # 10

# Compare
p.compare("cat", "bat")
# {'similarity': 0.6667, 'rhyme_type': 'perfect', 'confidence': 1.0, ...}

# Utilities
p.syllable_count("beautiful")  # 3
p.contains("hello")  # True
p.word_count()  # 126052
```

## Requirements

- Python >= 3.9
- No runtime dependencies. The dictionary is compiled into the binary.

## License

MIT
