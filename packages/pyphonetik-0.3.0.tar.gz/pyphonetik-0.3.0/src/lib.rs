use pyo3::prelude::*;
use pyo3::types::PyDict;
use pyo3::IntoPyObjectExt;

use phonetik::{Phonetik, StressMode};

/// Phonetic analysis engine backed by a 126K-word embedded dictionary.
///
/// Thread-safe and cheaply cloneable. All methods are available
/// immediately after construction — no files to load.
#[pyclass]
struct Engine {
    inner: Phonetik,
}

#[pymethods]
impl Engine {
    #[new]
    fn new() -> Self {
        Self {
            inner: Phonetik::new(),
        }
    }

    /// Look up a word's phonetic information.
    /// Returns a dict with word, phonemes, syllable_count, syllables,
    /// stresses, display, and variant_count. Returns None if unknown.
    fn lookup(&self, word: &str) -> Option<PyObject> {
        Python::with_gil(|py| {
            let info = self.inner.lookup(word)?;
            let d = PyDict::new(py);
            d.set_item("word", &info.word).ok()?;
            d.set_item("phonemes", &info.phonemes).ok()?;
            d.set_item("syllable_count", info.syllable_count).ok()?;
            d.set_item("syllables", &info.syllables).ok()?;
            d.set_item("stress_pattern", &info.stress_pattern).ok()?;
            d.set_item("stress_display", &info.stress_display).ok()?;
            d.set_item("variant_count", info.variant_count).ok()?;
            Some(d.into())
        })
    }

    /// Count syllables in a word. Estimates for unknown words.
    fn syllable_count(&self, word: &str) -> usize {
        self.inner.syllable_count(word)
    }

    /// Check if a word is in the dictionary.
    fn contains(&self, word: &str) -> bool {
        self.inner.contains(word)
    }

    /// Number of words in the dictionary.
    fn word_count(&self) -> usize {
        self.inner.word_count()
    }

    /// Find all rhymes for a word, merged across types.
    /// Returns a list of dicts with word, rhyme_type, phonemes,
    /// syllables, and confidence.
    fn rhymes(&self, word: &str, limit: usize) -> PyObject {
        Python::with_gil(|py| {
            let matches = self.inner.rhymes(word, limit);
            rhyme_matches_to_py(py, &matches)
        })
    }

    /// Find perfect rhymes only.
    fn perfect_rhymes(&self, word: &str) -> PyObject {
        Python::with_gil(|py| {
            let matches = self.inner.perfect_rhymes(word);
            rhyme_matches_to_py(py, &matches)
        })
    }

    /// Find slant rhymes only.
    fn slant_rhymes(&self, word: &str, limit: usize) -> PyObject {
        Python::with_gil(|py| {
            let matches = self.inner.slant_rhymes(word, limit);
            rhyme_matches_to_py(py, &matches)
        })
    }

    /// Find near rhymes only.
    fn near_rhymes(&self, word: &str, limit: usize) -> PyObject {
        Python::with_gil(|py| {
            let matches = self.inner.near_rhymes(word, limit);
            rhyme_matches_to_py(py, &matches)
        })
    }

    /// Perform scansion on a line of text.
    /// Uses natural speech stress by default (function words demoted).
    /// Pass mode="dictionary" for raw CMUdict stress.
    #[pyo3(signature = (line, mode="spoken"))]
    fn scan(&self, line: &str, mode: &str) -> PyObject {
        let stress_mode = match mode {
            "dictionary" => StressMode::Dictionary,
            _ => StressMode::Spoken,
        };
        Python::with_gil(|py| {
            let s = self.inner.scan_with_mode(line, stress_mode);
            let d = PyDict::new(py);
            d.set_item("syllable_count", s.syllable_count).ok();
            d.set_item("stressed_display", &s.stressed_display).ok();
            d.set_item("visual", &s.visual).ok();
            d.set_item("stress_pattern", &s.stress_pattern).ok();
            d.set_item("binary_pattern", &s.binary_pattern).ok();

            let m = PyDict::new(py);
            m.set_item("name", &s.meter.name).ok();
            m.set_item("foot_type", &s.meter.foot_type).ok();
            m.set_item("foot_count", s.meter.foot_count).ok();
            m.set_item("regularity", s.meter.regularity).ok();
            d.set_item("meter", m).ok();

            d.into()
        })
    }

    /// Compare two words phonetically.
    /// Returns a dict with word1, word2, similarity, rhyme_type,
    /// and confidence. Returns None if either word is unknown.
    fn compare(&self, word1: &str, word2: &str) -> Option<PyObject> {
        Python::with_gil(|py| {
            let cmp = self.inner.compare(word1, word2)?;
            let d = PyDict::new(py);
            d.set_item("word1", &cmp.word1).ok()?;
            d.set_item("word2", &cmp.word2).ok()?;
            d.set_item("similarity", cmp.similarity).ok()?;
            d.set_item("rhyme_type", format!("{:?}", cmp.rhyme_type).to_lowercase())
                .ok()?;
            d.set_item("confidence", cmp.confidence).ok()?;
            Some(d.into())
        })
    }
}

fn rhyme_matches_to_py(py: Python<'_>, matches: &[phonetik::RhymeMatch]) -> PyObject {
    let list: Vec<PyObject> = matches
        .iter()
        .map(|m| {
            let d = PyDict::new(py);
            d.set_item("word", &m.word).ok();
            d.set_item("rhyme_type", format!("{:?}", m.rhyme_type).to_lowercase())
                .ok();
            d.set_item("phonemes", &m.phonemes).ok();
            d.set_item("syllables", m.syllables).ok();
            d.set_item("confidence", m.confidence).ok();
            d.into()
        })
        .collect();
    list.into_py_any(py).unwrap()
}

#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<Engine>()?;
    Ok(())
}
