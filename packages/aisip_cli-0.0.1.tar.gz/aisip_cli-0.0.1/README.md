# aisip-cli

AISIP CLI — AI Structured Instruction Protocol command-line interface

- Protocol: https://aisip.dev
- License: MIT
