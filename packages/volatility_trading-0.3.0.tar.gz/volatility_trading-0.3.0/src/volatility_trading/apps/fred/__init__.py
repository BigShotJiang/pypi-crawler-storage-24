"""FRED app entrypoints."""
