"""YFinance app entrypoints."""
