from setuptools import find_packages, setup


setup(
    name="br-scratch-keepalive",
    version="0.1.1",
    description="CLI for keeping large BR200 scratch datasets warm with resumable refresh jobs.",
    author="Amit Subhash",
    python_requires=">=3.9",
    package_dir={"": "src"},
    packages=find_packages("src"),
    entry_points={
        "console_scripts": [
            "scratch-keepalive=scratch_keepalive.cli:main",
        ]
    },
)
