import tempfile
import unittest
from pathlib import Path
from unittest import mock

from scratch_keepalive.config import Config, Profile
from scratch_keepalive.logging_utils import RunLogger
from scratch_keepalive.models import DatasetRecord
from scratch_keepalive.refresh import (
    build_refresh_plan,
    checkpoint_path,
    parse_keep_until,
    refresh_dataset,
    registry_path,
)
from scratch_keepalive.registry import Registry


class RefreshPlanTests(unittest.TestCase):
    def test_build_refresh_plan_splits_top_level_and_second_level(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "dataset"
            (root / "mri" / "batch00").mkdir(parents=True)
            (root / "mri" / "batch01").mkdir(parents=True)
            (root / "metadata").mkdir()
            (root / "metadata" / "a.json").write_text("{}", encoding="utf-8")
            (root / "README.md").write_text("x", encoding="utf-8")

            record = DatasetRecord(
                name="x",
                path=str(root),
                profile="br200",
                keep_until="2099-01-01",
                refresh_days=14,
            )
            plan = build_refresh_plan(record)
            self.assertIn("mri/batch00", plan.units)
            self.assertIn("mri/batch01", plan.units)
            self.assertIn("metadata", plan.units)
            self.assertTrue(any(unit.startswith("ROOT_FILES:") for unit in plan.units))

    def test_parse_keep_until(self) -> None:
        parsed = parse_keep_until("2099-01-01")
        self.assertEqual(parsed.isoformat(), "2099-01-01")

    def test_refresh_updates_success_and_creates_sentinel(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_root = Path(tmp)
            scratch_root = tmp_root / "scratch"
            dataset_root = scratch_root / "dataset"
            state_root = tmp_root / "state"
            log_root = tmp_root / "logs"
            (dataset_root / "mri" / "batch00").mkdir(parents=True)
            (dataset_root / "mri" / "batch00" / "a.txt").write_text("x", encoding="utf-8")
            (dataset_root / "README.md").write_text("x", encoding="utf-8")

            profile = Profile(
                name="br200",
                scheduler_type="scrontab",
                allowed_roots=[str(scratch_root)],
                log_dir=str(log_root),
                state_dir=str(state_root),
                account="r00602",
                partition="general",
                cpus=1,
                mem="2G",
                time_limit="2:00:00",
                refresh_days=14,
                min_refresh_days=14,
            )
            config = Config(config_path=tmp_root / "config.json", default_profile="br200", profiles={"br200": profile})
            registry = Registry(registry_path(config, profile))
            record = DatasetRecord(
                name="dataset",
                path=str(dataset_root),
                profile="br200",
                keep_until="2099-01-01",
                refresh_days=14,
            )
            registry.add(record)
            logger = RunLogger(log_root, "testrun")
            updated = refresh_dataset(config, profile, record, logger)

            self.assertEqual(updated.last_result, "complete")
            self.assertIsNotNone(updated.last_success_at)
            self.assertTrue((dataset_root / ".scratch_keepalive").exists())
            self.assertFalse(checkpoint_path(config, profile, "dataset").exists())

    def test_refresh_resumes_from_checkpoint(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_root = Path(tmp)
            scratch_root = tmp_root / "scratch"
            dataset_root = scratch_root / "dataset"
            state_root = tmp_root / "state"
            log_root = tmp_root / "logs"
            (dataset_root / "mri" / "batch00").mkdir(parents=True)
            (dataset_root / "mri" / "batch01").mkdir(parents=True)
            (dataset_root / "mri" / "batch00" / "a.txt").write_text("x", encoding="utf-8")
            (dataset_root / "mri" / "batch01" / "b.txt").write_text("y", encoding="utf-8")

            profile = Profile(
                name="br200",
                scheduler_type="scrontab",
                allowed_roots=[str(scratch_root)],
                log_dir=str(log_root),
                state_dir=str(state_root),
                account="r00602",
                partition="general",
                cpus=1,
                mem="2G",
                time_limit="2:00:00",
                refresh_days=14,
                min_refresh_days=14,
            )
            config = Config(config_path=tmp_root / "config.json", default_profile="br200", profiles={"br200": profile})
            record = DatasetRecord(
                name="dataset",
                path=str(dataset_root),
                profile="br200",
                keep_until="2099-01-01",
                refresh_days=14,
            )
            logger1 = RunLogger(log_root, "first")
            logger2 = RunLogger(log_root, "second")

            original_execute = "scratch_keepalive.refresh.execute_unit"
            call_count = {"n": 0}

            def flaky_execute(root: Path, unit: str) -> int:
                call_count["n"] += 1
                if call_count["n"] == 2:
                    raise RuntimeError("boom")
                return 1

            with mock.patch(original_execute, side_effect=flaky_execute):
                partial = refresh_dataset(config, profile, record, logger1)

            self.assertEqual(partial.last_result, "partial")
            self.assertTrue(checkpoint_path(config, profile, "dataset").exists())

            resumed = refresh_dataset(config, profile, partial, logger2)
            self.assertEqual(resumed.last_result, "complete")
            self.assertFalse(checkpoint_path(config, profile, "dataset").exists())
