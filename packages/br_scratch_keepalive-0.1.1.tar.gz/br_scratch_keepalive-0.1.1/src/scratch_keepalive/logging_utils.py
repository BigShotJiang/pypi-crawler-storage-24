from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class RunLogger:
    def __init__(self, log_dir: Path, run_id: str):
        self.log_dir = log_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.log_dir / f"refresh-{run_id}.log"

    def write(self, message: str) -> None:
        line = f"[{utc_now()}] {message}\n"
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(line)

    def write_json(self, payload: Dict[str, Any]) -> None:
        line = json.dumps({"timestamp": utc_now(), **payload}, sort_keys=True)
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")

