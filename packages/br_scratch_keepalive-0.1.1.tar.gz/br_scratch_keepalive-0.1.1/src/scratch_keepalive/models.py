from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import List, Optional


@dataclass
class DatasetRecord:
    name: str
    path: str
    profile: str
    keep_until: str
    refresh_days: int
    enabled: bool = True
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    last_attempt_at: Optional[str] = None
    last_success_at: Optional[str] = None
    last_result: Optional[str] = None
    last_error: Optional[str] = None
    last_run_id: Optional[str] = None
    last_completed_checkpoint: Optional[str] = None
    sentinel_enabled: bool = True

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class RefreshPlan:
    version: int
    dataset_name: str
    dataset_path: str
    units: List[str]

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class CheckpointState:
    dataset_name: str
    run_id: str
    refresh_started_at: str
    plan_version: int
    root_path: str
    units: List[str]
    completed_units: List[str] = field(default_factory=list)
    failed_units: List[str] = field(default_factory=list)
    last_processed_unit: Optional[str] = None
    last_heartbeat_at: Optional[str] = None
    last_error: Optional[str] = None
    status: str = "running"

    def to_dict(self) -> dict:
        return asdict(self)

