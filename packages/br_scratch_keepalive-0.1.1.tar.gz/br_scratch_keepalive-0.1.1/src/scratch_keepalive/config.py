from __future__ import annotations

import json
import os
import socket
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional


def _json_default_path() -> Path:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg) / "scratch-keepalive" / "config.json"
    return Path.home() / ".config" / "scratch-keepalive" / "config.json"


def _json_state_root() -> Path:
    xdg = os.environ.get("XDG_STATE_HOME")
    if xdg:
        return Path(xdg) / "scratch-keepalive"
    return Path.home() / ".local" / "state" / "scratch-keepalive"


def _default_home_root() -> Path:
    return Path.home() / ".scratch-keepalive"


@dataclass
class Profile:
    name: str
    scheduler_type: str
    allowed_roots: list[str]
    log_dir: str
    state_dir: str
    account: str
    partition: str
    cpus: int
    mem: str
    time_limit: str
    refresh_days: int
    min_refresh_days: int

    def normalized_allowed_roots(self) -> list[Path]:
        return [Path(root).expanduser().resolve() for root in self.allowed_roots]


@dataclass
class Config:
    config_path: Path
    default_profile: str
    profiles: Dict[str, Profile] = field(default_factory=dict)

    @property
    def state_root(self) -> Path:
        state_dir = self.profiles[self.default_profile].state_dir
        return Path(state_dir).expanduser()


def username() -> str:
    return os.environ.get("USER") or Path.home().name


def on_br200() -> bool:
    host = socket.getfqdn().lower()
    if "bigred" in host or "uits.iu.edu" in host:
        return True
    user = username()
    return Path(f"/N/scratch/{user}").exists() and Path("/N/slate").exists()


def _default_br200_profile() -> Profile:
    user = username()
    slate = Path(f"/N/slate/{user}")
    log_dir = slate / "jobs" if slate.exists() else _default_home_root() / "logs"
    state_dir = _json_state_root()
    return Profile(
        name="br200",
        scheduler_type="scrontab",
        allowed_roots=[f"/N/scratch/{user}"],
        log_dir=str(log_dir),
        state_dir=str(state_dir),
        account=os.environ.get("SCRATCH_KEEPALIVE_ACCOUNT", "r00602"),
        partition="general",
        cpus=1,
        mem="2G",
        time_limit="2:00:00",
        refresh_days=14,
        min_refresh_days=14,
    )


def default_config(config_path: Optional[Path] = None) -> Config:
    path = config_path or _json_default_path()
    profile = _default_br200_profile()
    return Config(config_path=path, default_profile=profile.name, profiles={profile.name: profile})


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def save_config(config: Config) -> None:
    ensure_parent(config.config_path)
    payload = {
        "default_profile": config.default_profile,
        "profiles": {
            name: {
                "name": profile.name,
                "scheduler_type": profile.scheduler_type,
                "allowed_roots": profile.allowed_roots,
                "log_dir": profile.log_dir,
                "state_dir": profile.state_dir,
                "account": profile.account,
                "partition": profile.partition,
                "cpus": profile.cpus,
                "mem": profile.mem,
                "time_limit": profile.time_limit,
                "refresh_days": profile.refresh_days,
                "min_refresh_days": profile.min_refresh_days,
            }
            for name, profile in config.profiles.items()
        },
    }
    config.config_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def load_config(config_path: Optional[Path] = None) -> Config:
    path = config_path or _json_default_path()
    if not path.exists():
        config = default_config(path)
        return config
    data = json.loads(path.read_text(encoding="utf-8"))
    profiles = {
        name: Profile(**payload)
        for name, payload in data["profiles"].items()
    }
    return Config(config_path=path, default_profile=data["default_profile"], profiles=profiles)
