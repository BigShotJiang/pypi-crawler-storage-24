from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import date
from pathlib import Path
from typing import Iterable, List

from .config import Config, default_config, load_config, on_br200, save_config
from .doctor import run_doctor
from .logging_utils import RunLogger
from .models import DatasetRecord
from .refresh import checkpoint_dir, checkpoint_path, is_expired, parse_keep_until, refresh_records, registry_path, validate_managed_path
from .registry import Registry
from .scheduler import (
    install_scrontab,
    install_slurm_schedule,
    read_scheduler_state,
    schedule_next_slurm_job,
    scrontab_available,
    scrontab_usable,
    uninstall_scrontab,
    uninstall_slurm_schedule,
)


def fail(message: str) -> int:
    print(f"error: {message}", file=sys.stderr)
    return 1


def require_br200() -> None:
    if not on_br200():
        raise RuntimeError("the br200 profile must be run from inside a BR200 shell session")


def _load(profile_name: str | None = None) -> tuple[Config, object, Registry]:
    config = load_config()
    profile = config.profiles[profile_name or config.default_profile]
    reg = Registry(registry_path(config, profile))
    return config, profile, reg


def _format_records(records: Iterable[DatasetRecord], as_json: bool = False) -> str:
    payload = [record.to_dict() for record in records]
    if as_json:
        return json.dumps(payload, indent=2)
    lines = []
    for record in payload:
        lines.append(
            f"{record['name']}: enabled={record['enabled']} keep_until={record['keep_until']} "
            f"last_result={record['last_result']} path={record['path']}"
        )
    return "\n".join(lines)


def cmd_init(args: argparse.Namespace) -> int:
    require_br200()
    config = default_config()
    profile = config.profiles[config.default_profile]
    Path(profile.state_dir).expanduser().mkdir(parents=True, exist_ok=True)
    Path(profile.log_dir).expanduser().mkdir(parents=True, exist_ok=True)
    Registry(registry_path(config, profile)).save({})
    save_config(config)
    print(f"initialized profile={profile.name} config={config.config_path}")
    return 0


def cmd_add(args: argparse.Namespace) -> int:
    require_br200()
    config, profile, reg = _load(args.profile)
    path = Path(args.path).expanduser().resolve()
    validate_managed_path(profile, path)
    if not path.exists():
        return fail(f"path does not exist: {path}")
    keep_until = parse_keep_until(args.keep_until)
    if keep_until < date.today():
        return fail("keep-until date is already expired")
    record = DatasetRecord(
        name=args.name,
        path=str(path),
        profile=profile.name,
        keep_until=args.keep_until,
        refresh_days=args.refresh_days or profile.refresh_days,
    )
    if record.refresh_days < profile.min_refresh_days:
        return fail(
            f"refresh-days={record.refresh_days} is below the BR200 minimum of "
            f"{profile.min_refresh_days} days"
        )
    reg.add(record)
    print(f"added {args.name} -> {path}")
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    _, _, reg = _load(args.profile)
    print(_format_records(reg.list(), as_json=args.json))
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    config, profile, reg = _load(args.profile)
    records = reg.list() if not args.name else ([reg.get(args.name)] if reg.get(args.name) else [])
    payload = []
    for record in records:
        cp = checkpoint_path(config, profile, record.name)
        item = record.to_dict()
        item["checkpoint_path"] = str(cp) if cp.exists() else None
        item["checkpoint_exists"] = cp.exists()
        payload.append(item)
    if args.json:
        print(json.dumps(payload, indent=2))
        return 0
    for item in payload:
        print(
            f"{item['name']}: result={item['last_result']} success={item['last_success_at']} "
            f"checkpoint={item['checkpoint_path']}"
        )
    return 0


def _select_records(reg: Registry, name: str | None) -> List[DatasetRecord]:
    if name:
        record = reg.get(name)
        if not record:
            raise KeyError(name)
        return [record]
    return reg.list()


def _effective_refresh_days(profile, records: List[DatasetRecord]) -> int:
    active = [record.refresh_days for record in records if record.enabled and not is_expired(record)]
    if not active:
        return profile.refresh_days
    return max(profile.min_refresh_days, min(active))


def cmd_refresh(args: argparse.Namespace) -> int:
    require_br200()
    config, profile, reg = _load(args.profile)
    records = _select_records(reg, args.name)
    run_id = os.urandom(4).hex()
    logger = RunLogger(Path(profile.log_dir).expanduser(), run_id)
    refresh_records(config, profile, reg, records, logger)
    print(f"refresh run complete: {logger.path}")
    return 0


def cmd_extend(args: argparse.Namespace) -> int:
    _, _, reg = _load(args.profile)
    record = reg.get(args.name)
    if not record:
        return fail(f"unknown dataset: {args.name}")
    parse_keep_until(args.keep_until)
    record.keep_until = args.keep_until
    reg.update(record)
    print(f"extended {args.name} to {args.keep_until}")
    return 0


def _toggle_dataset(name: str, enabled: bool, profile_name: str | None) -> int:
    _, _, reg = _load(profile_name)
    record = reg.get(name)
    if not record:
        return fail(f"unknown dataset: {name}")
    record.enabled = enabled
    reg.update(record)
    print(f"{'enabled' if enabled else 'disabled'} {name}")
    return 0


def cmd_remove(args: argparse.Namespace) -> int:
    config, profile, reg = _load(args.profile)
    try:
        reg.remove(args.name)
    except KeyError:
        return fail(f"unknown dataset: {args.name}")
    cp = checkpoint_path(config, profile, args.name)
    if cp.exists():
        cp.unlink()
    print(f"removed {args.name}")
    return 0


def cmd_install_cron(args: argparse.Namespace) -> int:
    require_br200()
    config, profile, _ = _load(args.profile)
    command = f"{sys.executable} -m scratch_keepalive.cli refresh --all --profile {profile.name}"
    config_home = str(config.config_path.parent.parent)
    state_home = str(Path(profile.state_dir).expanduser().parent)
    refresh_days = _effective_refresh_days(profile, Registry(registry_path(config, profile)).list())
    if scrontab_usable():
        install_scrontab(command, profile)
        print("installed managed scrontab entry")
        return 0
    job_id = install_slurm_schedule(profile, command, config_home, state_home, refresh_days)
    print(f"installed slurm-resubmitting schedule job_id={job_id} refresh_days={refresh_days}")
    return 0


def cmd_uninstall_cron(args: argparse.Namespace) -> int:
    require_br200()
    _, profile, _ = _load(args.profile)
    if scrontab_usable():
        uninstall_scrontab()
        print("removed managed scrontab entry")
        return 0
    uninstall_slurm_schedule(profile)
    print("removed slurm-resubmitting schedule")
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    config, profile, _ = _load(args.profile)
    results = run_doctor(config, profile)
    if args.json:
        print(json.dumps([{"check": name, "status": status} for name, status in results], indent=2))
    else:
        for name, status in results:
            print(f"{name}: {status}")
    if any(status in {"missing", "not-br200"} for _, status in results):
        return 1
    return 0


def cmd_repair(args: argparse.Namespace) -> int:
    config, profile, reg = _load(args.profile)
    cp_root = checkpoint_dir(config, profile)
    cp_root.mkdir(parents=True, exist_ok=True)
    targets = []
    if args.name:
        targets = [checkpoint_path(config, profile, args.name)]
    else:
        targets = sorted(cp_root.glob("*.checkpoint.json"))

    removed = 0
    for cp in targets:
        if cp.exists():
            cp.unlink()
            removed += 1

    if args.name:
        record = reg.get(args.name)
        if record:
            record.last_completed_checkpoint = None
            reg.update(record)
    else:
        for record in reg.list():
            if record.last_completed_checkpoint:
                record.last_completed_checkpoint = None
                reg.update(record)

    print(f"removed {removed} checkpoint file(s)")
    return 0


def cmd_schedule_next(args: argparse.Namespace) -> int:
    require_br200()
    _, profile, reg = _load(args.profile)
    active_records = [record for record in reg.list() if record.enabled and not is_expired(record)]
    if not active_records:
        print("no active datasets remain; not scheduling another run")
        return 0
    if not read_scheduler_state(profile):
        return fail("no existing scheduler state found")
    refresh_days = _effective_refresh_days(profile, active_records)
    job_id = schedule_next_slurm_job(profile, refresh_days)
    print(f"scheduled next slurm refresh job_id={job_id} refresh_days={refresh_days}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="scratch-keepalive")
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init")
    init.add_argument("--profile", default="br200")
    init.set_defaults(func=cmd_init)

    add = sub.add_parser("add")
    add.add_argument("--name", required=True)
    add.add_argument("--path", required=True)
    add.add_argument("--keep-until", required=True)
    add.add_argument("--refresh-days", type=int)
    add.add_argument("--profile", default="br200")
    add.set_defaults(func=cmd_add)

    lsp = sub.add_parser("list")
    lsp.add_argument("--json", action="store_true")
    lsp.add_argument("--profile", default="br200")
    lsp.set_defaults(func=cmd_list)

    status = sub.add_parser("status")
    status.add_argument("--name")
    status.add_argument("--json", action="store_true")
    status.add_argument("--profile", default="br200")
    status.set_defaults(func=cmd_status)

    refresh = sub.add_parser("refresh")
    group = refresh.add_mutually_exclusive_group(required=True)
    group.add_argument("--all", action="store_true")
    group.add_argument("--name")
    refresh.add_argument("--profile", default="br200")
    refresh.set_defaults(func=cmd_refresh)

    extend = sub.add_parser("extend")
    extend.add_argument("--name", required=True)
    extend.add_argument("--keep-until", required=True)
    extend.add_argument("--profile", default="br200")
    extend.set_defaults(func=cmd_extend)

    enable = sub.add_parser("enable")
    enable.add_argument("--name", required=True)
    enable.add_argument("--profile", default="br200")
    enable.set_defaults(func=lambda args: _toggle_dataset(args.name, True, args.profile))

    disable = sub.add_parser("disable")
    disable.add_argument("--name", required=True)
    disable.add_argument("--profile", default="br200")
    disable.set_defaults(func=lambda args: _toggle_dataset(args.name, False, args.profile))

    remove = sub.add_parser("remove")
    remove.add_argument("--name", required=True)
    remove.add_argument("--profile", default="br200")
    remove.set_defaults(func=cmd_remove)

    install = sub.add_parser("install-cron")
    install.add_argument("--profile", default="br200")
    install.set_defaults(func=cmd_install_cron)

    uninstall = sub.add_parser("uninstall-cron")
    uninstall.add_argument("--profile", default="br200")
    uninstall.set_defaults(func=cmd_uninstall_cron)

    doctor = sub.add_parser("doctor")
    doctor.add_argument("--json", action="store_true")
    doctor.add_argument("--profile", default="br200")
    doctor.set_defaults(func=cmd_doctor)

    repair = sub.add_parser("repair")
    repair.add_argument("--name")
    repair.add_argument("--profile", default="br200")
    repair.set_defaults(func=cmd_repair)

    schedule_next = sub.add_parser("schedule-next")
    schedule_next.add_argument("--profile", default="br200")
    schedule_next.set_defaults(func=cmd_schedule_next)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
