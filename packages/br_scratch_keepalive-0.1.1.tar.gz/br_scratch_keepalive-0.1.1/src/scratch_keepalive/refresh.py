from __future__ import annotations

import json
import os
import uuid
from dataclasses import asdict
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Iterable, List, Optional

from .config import Config, Profile
from .logging_utils import RunLogger, utc_now
from .models import CheckpointState, DatasetRecord, RefreshPlan
from .registry import Registry


PLAN_VERSION = 1
ROOT_FILES_CHUNK = 1000


def parse_keep_until(value: str) -> date:
    return date.fromisoformat(value)


def is_expired(record: DatasetRecord) -> bool:
    return parse_keep_until(record.keep_until) < date.today()


def validate_managed_path(profile: Profile, path: Path) -> None:
    resolved = path.expanduser().resolve()
    allowed = profile.normalized_allowed_roots()
    if not any(root == resolved or root in resolved.parents for root in allowed):
        raise ValueError(f"path '{resolved}' is outside allowed roots: {', '.join(str(root) for root in allowed)}")


def _list_dir_names(path: Path) -> List[Path]:
    return sorted([entry for entry in path.iterdir() if entry.is_dir()], key=lambda item: item.name)


def _list_file_names(path: Path) -> List[Path]:
    return sorted([entry for entry in path.iterdir() if entry.is_file()], key=lambda item: item.name)


def build_refresh_plan(dataset: DatasetRecord) -> RefreshPlan:
    root = Path(dataset.path).resolve()
    units: List[str] = []

    root_files = _list_file_names(root)
    if root_files:
        for start in range(0, len(root_files), ROOT_FILES_CHUNK):
            end = min(start + ROOT_FILES_CHUNK, len(root_files))
            units.append(f"ROOT_FILES:{start}:{end}")

    for entry in _list_dir_names(root):
        child_dirs = _list_dir_names(entry)
        child_files = _list_file_names(entry)
        if child_dirs:
            for child in child_dirs:
                units.append(str(child.relative_to(root)))
            if child_files:
                units.append(f"{entry.relative_to(root)}/__files__")
        else:
            units.append(str(entry.relative_to(root)))

    if not units:
        units.append(".")

    return RefreshPlan(
        version=PLAN_VERSION,
        dataset_name=dataset.name,
        dataset_path=str(root),
        units=units,
    )


def checkpoint_dir(config: Config, profile: Profile) -> Path:
    return Path(profile.state_dir).expanduser() / "checkpoints"


def registry_path(config: Config, profile: Profile) -> Path:
    return Path(profile.state_dir).expanduser() / "registry.json"


def checkpoint_path(config: Config, profile: Profile, dataset_name: str) -> Path:
    return checkpoint_dir(config, profile) / f"{dataset_name}.checkpoint.json"


def load_checkpoint(path: Path) -> Optional[CheckpointState]:
    if not path.exists():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    return CheckpointState(**data)


def save_checkpoint(path: Path, state: CheckpointState) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(asdict(state), indent=2) + "\n", encoding="utf-8")


def remove_checkpoint(path: Path) -> None:
    if path.exists():
        path.unlink()


def _walk_path(path: Path) -> int:
    count = 0
    stack = [path]
    while stack:
        current = stack.pop()
        count += 1
        try:
            with os.scandir(current) as iterator:
                for entry in iterator:
                    count += 1
                    if entry.is_dir(follow_symlinks=False):
                        stack.append(Path(entry.path))
        except NotADirectoryError:
            continue
    return count


def _walk_root_file_chunk(root: Path, start: int, end: int) -> int:
    files = _list_file_names(root)[start:end]
    count = 0
    for entry in files:
        entry.stat()
        count += 1
    return count


def execute_unit(root: Path, unit: str) -> int:
    if unit == ".":
        return _walk_path(root)
    if unit.startswith("ROOT_FILES:"):
        _, start, end = unit.split(":")
        return _walk_root_file_chunk(root, int(start), int(end))
    if unit.endswith("/__files__"):
        folder = root / unit[:-len("/__files__")]
        count = 0
        for entry in _list_file_names(folder):
            entry.stat()
            count += 1
        return count
    return _walk_path(root / unit)


def _sentinel_path(root: Path) -> Path:
    return root / ".scratch_keepalive"


def _touch_sentinel(root: Path) -> None:
    sentinel = _sentinel_path(root)
    if sentinel.exists():
        sentinel.touch()
    else:
        sentinel.write_text("managed by scratch-keepalive\n", encoding="utf-8")


def refresh_dataset(config: Config, profile: Profile, record: DatasetRecord, logger: RunLogger) -> DatasetRecord:
    root = Path(record.path).resolve()
    validate_managed_path(profile, root)
    if not root.exists():
        raise FileNotFoundError(f"{root} does not exist")
    if is_expired(record):
        record.last_result = "expired"
        record.last_error = None
        return record

    plan = build_refresh_plan(record)
    cp_path = checkpoint_path(config, profile, record.name)
    existing = load_checkpoint(cp_path)
    run_id = existing.run_id if existing and existing.plan_version == plan.version and existing.root_path == str(root) and existing.units == plan.units else uuid.uuid4().hex[:12]
    state = existing if existing and existing.plan_version == plan.version and existing.root_path == str(root) and existing.units == plan.units else CheckpointState(
        dataset_name=record.name,
        run_id=run_id,
        refresh_started_at=utc_now(),
        plan_version=plan.version,
        root_path=str(root),
        units=plan.units,
    )
    logger.write(f"dataset={record.name} run_id={state.run_id} resume={'yes' if existing else 'no'} units={len(plan.units)}")

    record.last_attempt_at = utc_now()
    record.last_run_id = state.run_id
    completed = set(state.completed_units)

    for unit in plan.units:
        if unit in completed:
            continue
        try:
            visited = execute_unit(root, unit)
            state.completed_units.append(unit)
            state.last_processed_unit = unit
            state.last_heartbeat_at = utc_now()
            state.status = "running"
            state.last_error = None
            save_checkpoint(cp_path, state)
            logger.write(f"dataset={record.name} unit={unit} visited={visited} status=ok")
        except Exception as exc:
            state.failed_units.append(unit)
            state.last_processed_unit = unit
            state.last_heartbeat_at = utc_now()
            state.status = "failed"
            state.last_error = str(exc)
            save_checkpoint(cp_path, state)
            logger.write(f"dataset={record.name} unit={unit} status=error error={exc}")
            record.last_result = "partial"
            record.last_error = str(exc)
            record.last_completed_checkpoint = str(cp_path)
            return record

    if record.sentinel_enabled:
        _touch_sentinel(root)
    state.status = "complete"
    state.last_heartbeat_at = utc_now()
    save_checkpoint(cp_path, state)
    remove_checkpoint(cp_path)
    logger.write(f"dataset={record.name} status=complete units={len(plan.units)}")
    record.last_success_at = utc_now()
    record.last_result = "complete"
    record.last_error = None
    record.last_completed_checkpoint = None
    return record


def refresh_records(
    config: Config,
    profile: Profile,
    registry: Registry,
    records: Iterable[DatasetRecord],
    logger: RunLogger,
) -> List[DatasetRecord]:
    updated: List[DatasetRecord] = []
    for record in records:
        if not record.enabled:
            logger.write(f"dataset={record.name} status=skipped reason=disabled")
            updated.append(record)
            continue
        try:
            refreshed = refresh_dataset(config, profile, record, logger)
        except Exception as exc:
            record.last_attempt_at = utc_now()
            record.last_result = "failed"
            record.last_error = str(exc)
            logger.write(f"dataset={record.name} status=failed error={exc}")
            refreshed = record
        registry.update(refreshed)
        updated.append(refreshed)
    return updated

