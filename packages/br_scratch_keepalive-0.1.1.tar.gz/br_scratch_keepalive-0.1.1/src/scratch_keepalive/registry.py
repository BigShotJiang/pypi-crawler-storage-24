from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from .models import DatasetRecord


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class Registry:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load(self) -> Dict[str, DatasetRecord]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return {item["name"]: DatasetRecord(**item) for item in data.get("datasets", [])}

    def save(self, records: Dict[str, DatasetRecord]) -> None:
        payload = {"datasets": [asdict(records[name]) for name in sorted(records)]}
        self.path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    def add(self, record: DatasetRecord) -> None:
        records = self.load()
        if record.name in records:
            raise ValueError(f"dataset '{record.name}' already exists")
        if any(Path(existing.path).resolve() == Path(record.path).resolve() for existing in records.values()):
            raise ValueError(f"path '{record.path}' is already managed")
        record.created_at = now_iso()
        record.updated_at = record.created_at
        records[record.name] = record
        self.save(records)

    def update(self, record: DatasetRecord) -> None:
        records = self.load()
        if record.name not in records:
            raise KeyError(record.name)
        record.updated_at = now_iso()
        records[record.name] = record
        self.save(records)

    def remove(self, name: str) -> DatasetRecord:
        records = self.load()
        if name not in records:
            raise KeyError(name)
        record = records.pop(name)
        self.save(records)
        return record

    def get(self, name: str) -> Optional[DatasetRecord]:
        return self.load().get(name)

    def list(self) -> List[DatasetRecord]:
        return list(self.load().values())

