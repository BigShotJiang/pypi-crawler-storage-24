from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

from .config import Profile


MARKER_START = "# scratch-keepalive:start"
MARKER_END = "# scratch-keepalive:end"


def scrontab_available() -> bool:
    return shutil.which("scrontab") is not None


def scrontab_usable() -> bool:
    if not scrontab_available():
        return False
    result = subprocess.run(["scrontab", "-l"], capture_output=True, text=True)
    stderr = (result.stderr or "").lower()
    return "disabled on this cluster" not in stderr


def _read_scrontab() -> str:
    result = subprocess.run(["scrontab", "-l"], capture_output=True, text=True)
    if result.returncode != 0:
        return ""
    return result.stdout


def _write_scrontab(text: str) -> None:
    proc = subprocess.run(["scrontab", "-"], input=text, text=True, capture_output=True)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "failed to write scrontab")


def _managed_block(command: str, profile: Profile) -> str:
    cron = (
        f"0 0 */14 * * -A {profile.account} -p {profile.partition} "
        f"--cpus-per-task={profile.cpus} --mem={profile.mem} -t {profile.time_limit} {command}"
    )
    return f"{MARKER_START}\n{cron}\n{MARKER_END}\n"


def install_scrontab(command: str, profile: Profile) -> None:
    current = _read_scrontab()
    lines = current.splitlines()
    kept = []
    inside = False
    for line in lines:
        if line.strip() == MARKER_START:
            inside = True
            continue
        if line.strip() == MARKER_END:
            inside = False
            continue
        if not inside:
            kept.append(line)
    if kept and kept[-1] != "":
        kept.append("")
    kept.append(_managed_block(command, profile).rstrip("\n"))
    _write_scrontab("\n".join(kept).rstrip() + "\n")


def uninstall_scrontab() -> None:
    current = _read_scrontab()
    lines = current.splitlines()
    kept = []
    inside = False
    for line in lines:
        if line.strip() == MARKER_START:
            inside = True
            continue
        if line.strip() == MARKER_END:
            inside = False
            continue
        if not inside:
            kept.append(line)
    text = "\n".join(kept).rstrip()
    if text:
        text += "\n"
    _write_scrontab(text)


def has_managed_entry() -> bool:
    current = _read_scrontab()
    return MARKER_START in current and MARKER_END in current


def render_managed_command(command: str, profile: Profile) -> str:
    return _managed_block(command, profile)


def scheduler_state_path(profile: Profile) -> Path:
    return Path(profile.state_dir).expanduser() / "scheduler.json"


def generated_script_path(profile: Profile) -> Path:
    return Path(profile.state_dir).expanduser() / "run_scheduled_refresh.sh"


def read_scheduler_state(profile: Profile) -> dict | None:
    path = scheduler_state_path(profile)
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _write_scheduler_state(profile: Profile, payload: dict) -> None:
    path = scheduler_state_path(profile)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def clear_scheduler_state(profile: Profile) -> None:
    state = scheduler_state_path(profile)
    script = generated_script_path(profile)
    if state.exists():
        state.unlink()
    if script.exists():
        script.unlink()


def _run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True)


def _submit_slurm_job(profile: Profile, script_path: Path, refresh_days: int) -> str:
    proc = _run(
        [
            "sbatch",
            "--parsable",
            f"--begin=now+{refresh_days}days",
            "-A",
            profile.account,
            "-p",
            profile.partition,
            "--nodes=1",
            "--ntasks=1",
            f"--cpus-per-task={profile.cpus}",
            "--mem",
            profile.mem,
            "-t",
            profile.time_limit,
            "-J",
            "scratch_keepalive",
            str(script_path),
        ]
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "failed to submit slurm schedule job")
    return proc.stdout.strip()


def write_slurm_wrapper(profile: Profile, command: str, config_home: str, state_home: str) -> Path:
    script = generated_script_path(profile)
    script.parent.mkdir(parents=True, exist_ok=True)
    refresh_prefix = command.rsplit(" refresh --all", 1)[0]
    body = "\n".join(
        [
            "#!/bin/bash",
            "set -euo pipefail",
            f"export XDG_CONFIG_HOME={json.dumps(config_home)}",
            f"export XDG_STATE_HOME={json.dumps(state_home)}",
            command,
            f"{refresh_prefix} schedule-next --profile {profile.name}",
            "",
        ]
    )
    script.write_text(body, encoding="utf-8")
    script.chmod(0o700)
    return script


def install_slurm_schedule(profile: Profile, command: str, config_home: str, state_home: str, refresh_days: int) -> str:
    script = write_slurm_wrapper(profile, command, config_home, state_home)
    job_id = _submit_slurm_job(profile, script, refresh_days)
    _write_scheduler_state(
        profile,
        {
            "mode": "slurm_resubmit",
            "job_id": job_id,
            "script_path": str(script),
            "refresh_days": refresh_days,
        },
    )
    return job_id


def schedule_next_slurm_job(profile: Profile, refresh_days: int) -> str:
    state = read_scheduler_state(profile)
    if not state or state.get("mode") != "slurm_resubmit":
        raise RuntimeError("no slurm scheduler state found")
    job_id = _submit_slurm_job(profile, Path(state["script_path"]), refresh_days)
    state["job_id"] = job_id
    _write_scheduler_state(profile, state)
    return job_id


def uninstall_slurm_schedule(profile: Profile) -> None:
    state = read_scheduler_state(profile)
    if state and state.get("job_id"):
        proc = _run(["scancel", str(state["job_id"])])
        stderr = (proc.stderr or "").lower()
        if proc.returncode != 0 and "invalid job id" not in stderr:
            raise RuntimeError(proc.stderr.strip() or "failed to cancel scheduler job")
    clear_scheduler_state(profile)
