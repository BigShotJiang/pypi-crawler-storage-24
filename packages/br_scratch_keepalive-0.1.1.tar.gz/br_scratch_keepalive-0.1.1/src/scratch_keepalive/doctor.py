from __future__ import annotations

from pathlib import Path
from typing import List, Tuple

from .config import Config, Profile, on_br200
from .refresh import checkpoint_dir, registry_path
from .scheduler import has_managed_entry, read_scheduler_state, scrontab_available, scrontab_usable


def run_doctor(config: Config, profile: Profile) -> List[Tuple[str, str]]:
    results: List[Tuple[str, str]] = []
    results.append(("environment", "ok" if on_br200() else "not-br200"))
    results.append(("scrontab", "ok" if scrontab_available() else "missing"))
    results.append(("scrontab_usable", "yes" if scrontab_usable() else "no"))
    results.append(("scrontab_entry", "present" if scrontab_usable() and has_managed_entry() else "absent"))
    results.append(("slurm_scheduler_state", "present" if read_scheduler_state(profile) else "absent"))
    reg = registry_path(config, profile)
    results.append(("registry", "present" if reg.exists() else "missing"))
    cp_dir = checkpoint_dir(config, profile)
    results.append(("checkpoint_dir", "present" if cp_dir.exists() else "missing"))
    for root in profile.normalized_allowed_roots():
        results.append((f"allowed_root:{root}", "present" if root.exists() else "missing"))
    log_dir = Path(profile.log_dir).expanduser()
    results.append(("log_dir", "present" if log_dir.exists() else "missing"))
    return results
