from ara_cli.file_loaders.document_reader import DocumentReader

class DocxReader(DocumentReader):
    """Reader for DOCX files"""

    def read(self, extract_images: bool = False) -> str:
        import docx

        doc = docx.Document(self.file_path)
        text_content = '\n'.join(para.text for para in doc.paragraphs)

        if not extract_images:
            return text_content

        from PIL import Image
        import io

        # Create data directory for images
        images_dir = self.create_image_data_dir("docx")

        # Extract and process images
        image_descriptions = []
        image_counter = 1

        for rel in doc.part.rels.values():
            if "image" in rel.reltype:
                image_data = rel.target_part.blob

                # Determine image format
                image = Image.open(io.BytesIO(image_data))
                image_format = image.format.lower()

                # Save and describe image
                relative_path, description = self.save_and_describe_image(
                    image_data, image_format, images_dir, image_counter
                )

                # Add formatted description to list
                image_description = f"\nImage: {relative_path}\n[{description}]\n"
                image_descriptions.append(image_description)

                image_counter += 1

        # Combine text content with image descriptions
        if image_descriptions:
            text_content += "\n\n### Extracted Images\n" + \
                "\n".join(image_descriptions)

        return text_content
