from ara_cli.file_loaders.document_reader import DocumentReader

class PdfReader(DocumentReader):
    """Reader for PDF files"""

    def read(self, extract_images: bool = False) -> str:
        import pymupdf4llm

        if not extract_images:
            return pymupdf4llm.to_markdown(self.file_path, write_images=False)

        import fitz  # PyMuPDF

        # Create images directory
        images_dir = self.create_image_data_dir("pdf")

        # Extract text without images first
        text_content = pymupdf4llm.to_markdown(
            self.file_path, write_images=False)

        # Extract and process images
        doc = fitz.open(self.file_path)
        image_descriptions = []
        image_counter = 1

        for page_num, page in enumerate(doc):
            image_list = page.get_images()

            for img_index, img in enumerate(image_list):
                # Extract image
                xref = img[0]
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                image_ext = base_image["ext"]

                # Save and describe image
                relative_path, description = self.save_and_describe_image(
                    image_bytes, image_ext, images_dir, image_counter
                )

                # Add formatted description to list
                image_description = f"\nImage: {relative_path}\n[{description}]\n"
                image_descriptions.append(image_description)

                image_counter += 1

        doc.close()

        # Combine text content with image descriptions
        if image_descriptions:
            text_content += "\n\n### Extracted Images\n" + \
                "\n".join(image_descriptions)

        return text_content
