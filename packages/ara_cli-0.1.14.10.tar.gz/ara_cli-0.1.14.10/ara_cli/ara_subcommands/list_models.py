import typer
from typing import Optional, List, Dict, Any, Tuple


def validate_flags(all: bool, available: bool, check_active: bool) -> None:
    """
    Ensures that only one of the exclusive flags is set.
    """
    from rich.console import Console

    console = Console()
    flags_set = sum([all, available, check_active])
    if flags_set > 1:
        console.print(
            "[red]Error: The flags --all, --available, and --check-active are mutually exclusive. Please use only one.[/red]"
        )
        raise typer.Exit(1)


def _determine_fetch_mode(all: bool, available: bool, check_active: bool) -> str:
    """Determine the mode string for fetching/caching models."""
    if all:
        return "all"
    elif check_active:
        return "check-active"
    return "available"


def _get_cached_models_with_warning(
    cache: Any, mode_str: str, warning_prefix: str
) -> Tuple[List[str], str]:
    """Try to get cached models, fall back to fallback models if unavailable."""
    cached_models = cache.load_models(mode_str)
    if cached_models:
        cache_info = cache.get_cache_info()
        timestamp = cache_info.get(
            "timestamp", "unknown") if cache_info else "unknown"
        return cached_models, f"{warning_prefix} (updated: {timestamp})[/yellow]"

    fallback = cache.get_fallback_models()
    return fallback, f"{warning_prefix} - using fallback models[/yellow]"


def _fetch_models_from_litellm(
    mode_str: str, available: bool
) -> List[str]:
    """Fetch models from LiteLLM based on mode."""
    from rich.console import Console
    from litellm import model_cost
    from litellm.utils import get_valid_models

    console = Console()

    if mode_str == "all":
        console.print(
            "[bold]Fetching all statically supported models...[/bold]")
        return sorted(list(model_cost.keys()))
    elif mode_str == "check-active":
        console.print(
            "[bold]Probing providers for active models (this may take a moment)...[/bold]"
        )
        return get_valid_models(check_provider_endpoint=True)
    else:
        if available:
            console.print(
                "[bold]Listing available models based on environment variables...[/bold]"
            )
        return get_valid_models(check_provider_endpoint=False)


def _build_models_with_metadata(models: List[str]) -> List[Dict[str, Any]]:
    """Build models list with metadata for caching."""
    models_with_metadata = []
    for m in models:
        p, ctx, in_cost_str, out_cost_str = _get_model_display_data(m)
        models_with_metadata.append(
            {
                "name": m,
                "provider": p,
                "context": ctx,
                "input_cost_per_1m": in_cost_str,
                "output_cost_per_1m": out_cost_str,
            }
        )
    return models_with_metadata


def fetch_models(
    all: bool,
    available: bool,
    check_active: bool,
    use_cache: bool = True,
    offline: bool = False,
) -> Tuple[List[str], Optional[str]]:
    """
    Retrieves the list of models based on the selected mode.

    Returns:
        Tuple of (models_list, warning_message)
        warning_message is non-None if models came from cache or fallback
    """
    from ara_cli.cache.model_cache import ModelCache

    cache = ModelCache()
    mode_str = _determine_fetch_mode(all, available, check_active)

    if offline:
        return _get_cached_models_with_warning(
            cache, mode_str, "[yellow]⚠️  Offline mode: Using cached data"
        )

    try:
        models = _fetch_models_from_litellm(mode_str, available)

        if use_cache:
            models_with_metadata = _build_models_with_metadata(models)
            cache.save_models(models_with_metadata, mode_str)

        return models, None

    except Exception:
        if use_cache:
            cached_models = cache.load_models(mode_str)
            if cached_models:
                cache_info = cache.get_cache_info()
                timestamp = (
                    cache_info.get(
                        "timestamp", "unknown") if cache_info else "unknown"
                )
                return (
                    cached_models,
                    f"[yellow]⚠️  LiteLLM server unavailable. Using cached data (updated: {timestamp})[/yellow]",
                )

        fallback = cache.get_fallback_models()
        return (
            fallback,
            "[yellow]⚠️  LiteLLM server unavailable. Using fallback models.[/yellow]\n"
            "[dim]To see cached models, ensure internet connection and try: ara list-models --refresh[/dim]",
        )


def get_unique_providers(models: List[str]) -> List[str]:
    """
    Extracts a sorted list of unique providers from the given models.
    """
    from litellm import model_cost
    from litellm.utils import get_model_info

    providers = set()
    for m in models:
        info = {}
        if m in model_cost:
            info = model_cost[m]
        else:
            try:
                info = get_model_info(m)
            except Exception:
                pass

        p = info.get("litellm_provider")
        if p:
            providers.add(p)
        elif "/" in m:
            providers.add(m.split("/")[0])

    return sorted(list(providers))


def filter_models_by_provider(models: List[str], provider: str) -> List[str]:
    """
    Filters the model list to include only those matching the specified provider.
    """
    from litellm import model_cost

    provider = provider.lower()
    filtered_models = []
    for m in models:
        p = None
        if m in model_cost:
            p = model_cost[m].get("litellm_provider")

        if not p:
            if m.startswith(provider):
                filtered_models.append(m)
                continue

        if p == provider:
            filtered_models.append(m)
    return filtered_models


def _get_model_display_data(model_name: str) -> Tuple[str, str, str, str]:
    """
    Helper to extract and format model data for the table.
    Returns (provider, context, in_cost, out_cost).
    """
    from litellm import model_cost
    from litellm.utils import get_model_info

    info = {}
    if model_name in model_cost:
        info = model_cost[model_name]
    else:
        try:
            info = get_model_info(model_name)
        except Exception:
            pass

    p = info.get("litellm_provider", "Unknown")
    ctx = info.get("max_tokens") or info.get("max_input_tokens") or "-"

    in_cost = info.get("input_cost_per_token", 0) or 0
    out_cost = info.get("output_cost_per_token", 0) or 0

    in_cost_str = f"{in_cost * 1_000_000:.2f}" if in_cost else "-"
    out_cost_str = f"{out_cost * 1_000_000:.2f}" if out_cost else "-"

    return str(p), str(ctx), in_cost_str, out_cost_str


def create_model_table(models: List[str]) -> Any:
    """
    Creates a rich Table containing detailed model information.
    """
    from rich.table import Table

    table = Table(title=f"Supported Models ({len(models)} found)")
    table.add_column("Model Name", style="cyan", no_wrap=True)
    table.add_column("Provider", style="magenta")
    table.add_column("Context", justify="right")
    table.add_column("In Cost ($/1M)", justify="right")
    table.add_column("Out Cost ($/1M)", justify="right")

    for m in models:
        p, ctx, in_cost_str, out_cost_str = _get_model_display_data(m)
        table.add_row(m, p, ctx, in_cost_str, out_cost_str)
    return table


def _extract_model_names(models: List[str] | List[Dict[str, Any]]) -> List[str]:
    """
    Extract model names from list of strings or dicts (with metadata).
    """
    if not models:
        return []

    if isinstance(models[0], dict):
        return [m.get("name", "") for m in models]
    return models


def _handle_clear_cache(cache: Any, console: Any) -> None:
    """Handle the --clear-cache command."""
    if cache.clear_cache():
        console.print("[green]✓ Cache cleared successfully.[/green]")
    else:
        console.print("[red]✗ Failed to clear cache.[/red]")
    raise typer.Exit(0)


def _handle_cache_info(cache: Any, console: Any) -> None:
    """Handle the --cache-info command."""
    info = cache.get_cache_info()
    if info:
        console.print("[bold]Cache Information:[/bold]")
        console.print(
            f"Location: {info['cache_file']}\n"
            f"Last Updated: {info['timestamp']}\n"
            f"Version: {info['version']}\n"
            f"Valid: {'Yes ✓' if info['valid'] else 'No ✗ (expired)'}"
        )
    else:
        console.print("[yellow]No cache file found.[/yellow]")
    raise typer.Exit(0)


def _handle_list_providers(
    model_names: List[str], json_output: bool, console: Any
) -> None:
    """Handle the --providers command."""
    import json as json_lib

    sorted_providers = get_unique_providers(model_names)

    if not sorted_providers:
        if json_output:
            console.print(json_lib.dumps({"providers": []}))
        else:
            console.print("[yellow]No providers could be determined.[/yellow]")
        return

    if json_output:
        console.print(json_lib.dumps({"providers": sorted_providers}))
    else:
        console.print(
            f"[bold]Available Providers ({len(sorted_providers)}):[/bold]")
        console.print("\n".join(sorted_providers))


def _output_models_json(
    models: List[Any], model_names: List[str], console: Any
) -> None:
    """Output models in JSON format."""
    import json as json_lib

    if models and isinstance(models[0], dict):
        models_data = [m for m in models if m.get("name") in model_names]
    else:
        models_data = _build_models_with_metadata(model_names)

    console.print(json_lib.dumps({"models": models_data}))


def _output_models_table(model_names: List[str], console: Any) -> None:
    """Output models in table format."""
    content = create_model_table(model_names)
    console.print(content)


def list_models(
    all: bool = typer.Option(
        False,
        "--all",
        "-a",
        help="List all statically supported models from the registry.",
    ),
    available: bool = typer.Option(
        False,
        "--available",
        "-v",
        help="List models available based on current environment variables (default).",
    ),
    check_active: bool = typer.Option(
        False,
        "--check-active",
        help="Actively probe provider APIs to verify model availability (slower).",
    ),
    provider: Optional[str] = typer.Option(
        None,
        "--provider",
        "-p",
        help="Filter models by provider (e.g., 'openai', 'anthropic').",
    ),
    json: bool = typer.Option(
        False,
        "-j",
        "--json",
        help="Output models as JSON.",
    ),
    list_providers: bool = typer.Option(
        False, "--providers", help="List available providers instead of models."
    ),
    clear_cache: bool = typer.Option(
        False,
        "--clear-cache",
        help="Delete cached models and exit.",
    ),
    cache_info: bool = typer.Option(
        False,
        "--cache-info",
        help="Show cache information and exit.",
    ),
    refresh: bool = typer.Option(
        False,
        "--refresh",
        help="Bypass cache and fetch fresh models from LiteLLM.",
    ),
    offline: bool = typer.Option(
        False,
        "--offline",
        help="Use only cached models (don't try to connect to LiteLLM).",
    ),
):
    """
    List supported LLM models or providers.
    """
    from rich.console import Console
    from ara_cli.cache.model_cache import ModelCache

    console = Console()
    cache = ModelCache()

    if clear_cache:
        _handle_clear_cache(cache, console)

    if cache_info:
        _handle_cache_info(cache, console)

    validate_flags(all, available, check_active)

    models, warning = fetch_models(
        all, available, check_active, use_cache=not refresh, offline=offline
    )

    if warning:
        console.print(warning)

    model_names = _extract_model_names(models)

    if list_providers:
        _handle_list_providers(model_names, json, console)
        return

    if provider:
        model_names = filter_models_by_provider(model_names, provider)

    if not model_names:
        _output_empty_result(json, console)
        return

    if json:
        _output_models_json(models, model_names, console)
    else:
        _output_models_table(model_names, console)


def _output_empty_result(json_output: bool, console: Any) -> None:
    """Output empty result message."""
    import json as json_lib

    if json_output:
        console.print(json_lib.dumps({"models": []}))
    else:
        console.print(
            "[yellow]No models found matching the criteria.[/yellow]")


def register(app: typer.Typer):
    app.command(name="list-models", help="List supported LLM models via LiteLLM.")(
        list_models
    )
