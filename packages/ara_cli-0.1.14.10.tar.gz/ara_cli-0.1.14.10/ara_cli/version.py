# version.py
__version__ = "0.1.14.10"   # fith parameter like .0 for local install test purposes only. official numbers should be 4 digit numbers
