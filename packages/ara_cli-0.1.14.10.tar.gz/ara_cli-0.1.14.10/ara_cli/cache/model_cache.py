"""Model cache management for ara list-models command."""

import json
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any


class ModelCache:
    """Manages caching of LLM models list."""

    CACHE_FILENAME = "models_cache.json"
    DEFAULT_TTL_HOURS = 24
    CACHE_VERSION = "1.0"

    # Fallback models when no cache and no connection
    FALLBACK_MODELS = [
        "gpt-4",
        "gpt-4-turbo",
        "gpt-3.5-turbo",
        "claude-3-opus",
        "claude-3-sonnet",
        "claude-3-haiku",
        "gemini-pro",
        "mistral-large",
        "mistral-medium",
        "mixtral-8x7b",
    ]

    def __init__(
        self, cache_dir: Optional[str] = None, ttl_hours: int = DEFAULT_TTL_HOURS
    ):
        """
        Initialize ModelCache.

        Args:
            cache_dir: Custom cache directory. If None, uses platform-specific default.
            ttl_hours: Time to live for cache in hours (default: 24)
        """
        self.ttl_hours = ttl_hours
        self.cache_dir = Path(cache_dir) if cache_dir else self._get_default_cache_dir()
        self.cache_file = self.cache_dir / self.CACHE_FILENAME

    @staticmethod
    def _get_default_cache_dir() -> Path:
        """Get platform-specific cache directory."""
        if os.name == "nt":  # Windows
            cache_base = os.getenv("LOCALAPPDATA", os.path.expanduser("~"))
            cache_path = Path(cache_base) / "ara" / "models"
        else:  # Linux/macOS
            cache_base = os.getenv("XDG_CACHE_HOME", os.path.expanduser("~/.cache"))
            cache_path = Path(cache_base) / "ara" / "models"

        return cache_path

    def _ensure_cache_dir(self) -> None:
        """Create cache directory if it doesn't exist."""
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _is_cache_valid(self) -> bool:
        """Check if cache file exists and is still valid (within TTL)."""
        if not self.cache_file.exists():
            return False

        try:
            with open(self.cache_file, "r") as f:
                data = json.load(f)

            timestamp_str = data.get("timestamp")
            if not timestamp_str:
                return False

            cached_time = datetime.fromisoformat(timestamp_str)
            expiry_time = cached_time + timedelta(hours=self.ttl_hours)

            return datetime.now() < expiry_time
        except (json.JSONDecodeError, KeyError, ValueError):
            return False

    def get_cache_info(self) -> Optional[Dict[str, Any]]:
        """
        Get cache metadata without loading models.

        Returns:
            Dict with cache info or None if cache doesn't exist.
        """
        if not self.cache_file.exists():
            return None

        try:
            with open(self.cache_file, "r") as f:
                data = json.load(f)

            timestamp = data.get("timestamp", "unknown")
            version = data.get("version", "unknown")
            is_valid = self._is_cache_valid()

            return {
                "timestamp": timestamp,
                "version": version,
                "valid": is_valid,
                "cache_file": str(self.cache_file),
            }
        except (json.JSONDecodeError, IOError):
            return None

    def save_models(
        self,
        models: List[str] | List[Dict[str, Any]],
        mode: str = "available",
        providers_map: Optional[Dict[str, List[str]]] = None,
    ) -> bool:
        """
        Save models to cache with optional metadata.

        Args:
            models: List of model names (strings) or list of model dicts with metadata.
                    Dict format: {"name": str, "provider": str, "context": str,
                                  "input_cost_per_1m": str, "output_cost_per_1m": str}
            mode: Mode used to fetch models ('all', 'available', 'check-active')
            providers_map: Optional dict mapping providers to their models

        Returns:
            True if successful, False otherwise
        """
        try:
            self._ensure_cache_dir()

            # Load existing cache to preserve other modes
            existing_data = {}
            if self.cache_file.exists():
                try:
                    with open(self.cache_file, "r") as f:
                        existing_data = json.load(f)
                except (json.JSONDecodeError, IOError):
                    existing_data = {}

            # Handle both string list and metadata dict list
            if models and isinstance(models[0], dict):
                # Sort by name if metadata available
                sorted_models = sorted(models, key=lambda x: x.get("name", ""))
            else:
                # Convert string list to lightweight format
                sorted_models = sorted(models)

            # Merge with existing modes
            modes = existing_data.get("modes", {})
            modes[mode] = {
                "models": sorted_models,
                "last_updated": datetime.now().isoformat(),
            }

            cache_data = {
                "timestamp": datetime.now().isoformat(),
                "version": self.CACHE_VERSION,
                "ttl_hours": self.ttl_hours,
                "modes": modes,
            }

            if providers_map:
                cache_data["providers"] = providers_map
            elif "providers" in existing_data:
                cache_data["providers"] = existing_data["providers"]

            with open(self.cache_file, "w") as f:
                json.dump(cache_data, f, indent=2)

            return True
        except IOError as e:
            # Silent fail - cache is optional
            return False

    def load_models(
        self, mode: str = "available"
    ) -> Optional[List[str] | List[Dict[str, Any]]]:
        """
        Load models from cache. Returns either list of strings or list of dicts with metadata.

        Args:
            mode: Mode to load ('all', 'available', 'check-active')

        Returns:
            List of models (strings or dicts with metadata) if cache valid, None otherwise
        """
        if not self._is_cache_valid():
            return None

        try:
            with open(self.cache_file, "r") as f:
                data = json.load(f)

            modes = data.get("modes", {})
            mode_data = modes.get(mode)

            if mode_data:
                return mode_data.get("models", [])

            return None
        except (json.JSONDecodeError, IOError, KeyError):
            return None

    def get_cache_timestamp(self) -> Optional[str]:
        """Get the timestamp of cached data."""
        if not self.cache_file.exists():
            return None

        try:
            with open(self.cache_file, "r") as f:
                data = json.load(f)
            return data.get("timestamp")
        except (json.JSONDecodeError, IOError):
            return None

    def clear_cache(self) -> bool:
        """Delete cache file."""
        try:
            if self.cache_file.exists():
                self.cache_file.unlink()
            return True
        except OSError:
            return False

    def get_fallback_models(self) -> List[str]:
        """Get fallback model list for offline use."""
        return self.FALLBACK_MODELS
