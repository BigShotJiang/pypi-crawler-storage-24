// ═══════════════════════════════════════════════════════
//  CVC Dashboard — Typed REST API Client
// ═══════════════════════════════════════════════════════
import type {
  ServicesResponse, AnalyticsResponse, StatsResponse,
  CommitEntry, TimelineEntry,
  CommitRequest, BranchRequest, MergeRequest, RestoreRequest,
  OperationResult, RecallResult, DiffResult,
  MemoryContextResponse, MemoryBlobsResponse, MemoryStatsResponse,
  ModelCatalog, CurrentModel,
  MCPTool, MCPStatus,
  ChatRequest,
  HiveMindAgent, RegisterAgentRequest,
  GatewayConfig, VCSStatus, AuditEntry,
} from './types';

const BASE = '';  // same-origin

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(init?.headers as Record<string, string> ?? {}) },
    ...init,
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`API ${res.status}: ${body}`);
  }
  return res.json() as Promise<T>;
}

function get<T>(path: string): Promise<T> {
  return request<T>(path);
}

function post<T>(path: string, body?: unknown): Promise<T> {
  return request<T>(path, { method: 'POST', body: body != null ? JSON.stringify(body) : undefined });
}

function del<T>(path: string): Promise<T> {
  return request<T>(path, { method: 'DELETE' });
}

// ── Gateway / Services ─────────────────────────
export function getServices(): Promise<ServicesResponse> {
  return get('/api/gateway/services');
}

export function serviceAction(service: string, action: string): Promise<OperationResult> {
  return post(`/api/gateway/services/${encodeURIComponent(service)}/${encodeURIComponent(action)}`);
}

export function getAnalytics(): Promise<AnalyticsResponse> {
  return get('/api/gateway/analytics');
}

export function getCommits(limit: number = 50): Promise<CommitEntry[]> {
  return get(`/api/gateway/commits?limit=${limit}`);
}

export function getConfig(): Promise<GatewayConfig> {
  return get('/api/gateway/config');
}

// ── Operations ─────────────────────────────────
export function opsCommit(req: CommitRequest): Promise<OperationResult> {
  return post('/api/ops/commit', req);
}

export function opsBranch(req: BranchRequest): Promise<OperationResult> {
  return post('/api/ops/branch', req);
}

export function opsMerge(req: MergeRequest): Promise<OperationResult> {
  return post('/api/ops/merge', req);
}

export function opsRestore(req: RestoreRequest): Promise<OperationResult> {
  return post('/api/ops/restore', req);
}

export function opsRecall(query: string, limit: number = 10): Promise<RecallResult> {
  return get(`/api/ops/recall?query=${encodeURIComponent(query)}&limit=${limit}`);
}

export function opsDiff(hash1: string, hash2: string): Promise<DiffResult> {
  return get(`/api/ops/diff?hash1=${encodeURIComponent(hash1)}&hash2=${encodeURIComponent(hash2)}`);
}

export function opsTimeline(limit: number = 50): Promise<TimelineEntry[]> {
  return get(`/api/ops/timeline?limit=${limit}`);
}

export function opsBranches(): Promise<string[]> {
  return get('/api/ops/branches');
}

export function opsStatus(): Promise<StatsResponse> {
  return get('/api/ops/status');
}

// ── Memory ─────────────────────────────────────
export function getMemoryContext(): Promise<MemoryContextResponse> {
  return get('/api/memory/context');
}

export function getMemoryBlobs(): Promise<MemoryBlobsResponse> {
  return get('/api/memory/blobs');
}

export function getMemoryStats(): Promise<MemoryStatsResponse> {
  return get('/api/memory/stats');
}

// ── Models ─────────────────────────────────────
export function getModelCatalog(): Promise<ModelCatalog> {
  return get('/api/models/catalog');
}

export function getCurrentModel(): Promise<CurrentModel> {
  return get('/api/models/current');
}

export function switchModel(provider: string, model: string): Promise<OperationResult> {
  return post('/api/models/switch', { provider, model });
}

// ── Chat — yields structured event objects ─────
export interface ChatEvent {
  type: 'text' | 'tool_start' | 'tool_result' | 'status';
  content?: string;
  name?: string;
  args?: Record<string, unknown>;
  output?: string;
  message?: string;
}

export async function* chatStream(req: ChatRequest): AsyncGenerator<ChatEvent, void, unknown> {
  const res = await fetch(`${BASE}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...req, stream: true }),
  });
  if (!res.ok) throw new Error(`Chat ${res.status}`);
  const reader = res.body?.getReader();
  if (!reader) return;
  const decoder = new TextDecoder();
  let buffer = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop()!;
    for (const line of lines) {
      if (line.startsWith('data: ')) {
        const data = line.slice(6);
        if (data === '[DONE]') return;
        try {
          const parsed = JSON.parse(data);
          // New structured events from agentic loop
          if (parsed.type) {
            yield parsed as ChatEvent;
          }
          // Legacy fallback: OpenAI-style delta
          else if (parsed.choices?.[0]?.delta?.content) {
            yield { type: 'text', content: parsed.choices[0].delta.content };
          }
        } catch { /* skip malformed SSE */ }
      }
    }
  }
}

export function getChatModels(): Promise<{ models: string[] }> {
  return get('/api/chat/models');
}

// ── MCP ────────────────────────────────────────
export function getMCPTools(): Promise<MCPTool[]> {
  return get('/api/mcp/tools');
}

export function getMCPStatus(): Promise<MCPStatus> {
  return get('/api/mcp/status');
}

// ── VCS ────────────────────────────────────────
export function getVCSStatus(): Promise<VCSStatus> {
  return get('/api/vcs/status');
}

// ── Audit ──────────────────────────────────────
export function getAudit(): Promise<AuditEntry[]> {
  return get('/api/audit');
}

// ── Sessions ───────────────────────────────────
export function getSessions(): Promise<unknown[]> {
  return get('/api/sessions');
}

// ── Connections ────────────────────────────────
export function getConnections(): Promise<unknown> {
  return get('/api/connections');
}

// ── Hive Mind ──────────────────────────────────
export function getHiveMindAgents(): Promise<HiveMindAgent[]> {
  return get('/api/hivemind/agents');
}

export function registerHiveMindAgent(req: RegisterAgentRequest): Promise<OperationResult> {
  return post('/api/hivemind/register', req);
}

export function removeHiveMindAgent(agentId: string): Promise<OperationResult> {
  return del(`/api/hivemind/agents/${encodeURIComponent(agentId)}`);
}

// ── Stats ──────────────────────────────────────
export function getStats(): Promise<StatsResponse> {
  return get('/api/stats');
}
