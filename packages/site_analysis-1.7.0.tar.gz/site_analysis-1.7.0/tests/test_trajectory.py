import unittest
from collections import Counter
import numpy as np
from pymatgen.core import Structure, Lattice

from site_analysis.trajectory import Trajectory
from site_analysis.polyhedral_site import PolyhedralSite
from site_analysis.spherical_site import SphericalSite
from site_analysis.voronoi_site import VoronoiSite
from site_analysis.dynamic_voronoi_site import DynamicVoronoiSite
from site_analysis.site_collection import SiteCollection
from site_analysis.polyhedral_site_collection import PolyhedralSiteCollection
from site_analysis.voronoi_site_collection import VoronoiSiteCollection
from site_analysis.spherical_site_collection import SphericalSiteCollection
from site_analysis.dynamic_voronoi_site_collection import DynamicVoronoiSiteCollection
from site_analysis.atom import Atom
from site_analysis.site import Site
from unittest.mock import Mock, patch, PropertyMock

import tempfile
import os
import json


class TrajectoryInitializationTestCase(unittest.TestCase):
    """Tests for Trajectory initialization with different site types."""

    def setUp(self):
        Site._newid = 0

    def test_initialisation_with_polyhedral_sites(self):
        sites = [PolyhedralSite(vertex_indices=[0, 1, 2, 3])]
        trajectory = Trajectory(atoms=[Atom(index=0)], sites=sites)
        self.assertIsInstance(trajectory.site_collection, PolyhedralSiteCollection)

    def test_initialisation_with_voronoi_sites(self):
        sites = [VoronoiSite(frac_coords=np.array([0.5, 0.5, 0.5]))]
        trajectory = Trajectory(atoms=[Atom(index=0)], sites=sites)
        self.assertIsInstance(trajectory.site_collection, VoronoiSiteCollection)

    def test_initialisation_with_spherical_sites(self):
        sites = [SphericalSite(frac_coords=np.array([0.5, 0.5, 0.5]), rcut=1.0)]
        trajectory = Trajectory(atoms=[Atom(index=0)], sites=sites)
        self.assertIsInstance(trajectory.site_collection, SphericalSiteCollection)

    def test_initialisation_with_dynamic_voronoi_sites(self):
        sites = [DynamicVoronoiSite(reference_indices=[0, 1])]
        trajectory = Trajectory(atoms=[Atom(index=0)], sites=sites)
        self.assertIsInstance(trajectory.site_collection, DynamicVoronoiSiteCollection)

    def test___len___returns_zero_for_empty_trajectory(self):
        sites = [SphericalSite(frac_coords=np.array([0.5, 0.5, 0.5]), rcut=1.0)]
        trajectory = Trajectory(atoms=[Atom(index=0)], sites=sites)
        self.assertEqual(len(trajectory), 0)

    def test___len___returns_number_of_timesteps(self):
        trajectory = Trajectory.__new__(Trajectory)
        trajectory.timesteps = ['foo', 'bar']
        self.assertEqual(len(trajectory), 2)

    def test_init_raises_type_error_if_passed_mixed_site_types(self):
        sites = [PolyhedralSite(vertex_indices=[0, 1, 2, 3]),
                 VoronoiSite(frac_coords=np.array([0.5, 0.5, 0.5]))]
        with self.assertRaises(TypeError):
            Trajectory(atoms=[Atom(index=0)], sites=sites)

    def test_init_raises_type_error_if_passed_invalid_site_type(self):
        with self.assertRaises(TypeError):
            Trajectory(atoms=[Atom(index=0)], sites=["foo"])


class TrajectoryFunctionalityTestCase(unittest.TestCase):
    """Tests for Trajectory functionality using real pymatgen objects."""
    
    def setUp(self):
        """Set up test fixtures with simple objects."""
        # Reset Site._newid counter
        Site._newid = 0
        
        # Create simple lattice
        self.lattice = Lattice.cubic(5.0)
        
        # Create a structure with two atoms
        species = ["Na", "Na"]
        coords = [[0.1, 0.1, 0.1], [0.5, 0.5, 0.5]]
        self.structure = Structure(self.lattice, species, coords)
        
        # Create two slightly different structures for trajectory testing
        coords2 = [[0.11, 0.1, 0.1], [0.51, 0.5, 0.5]]
        self.structure2 = Structure(self.lattice, species, coords2)
        
        # Create atoms
        self.atom1 = Atom(index=0)
        self.atom2 = Atom(index=1)
        self.atoms = [self.atom1, self.atom2]
        
        # Create sites (spherical sites are simple to create)
        self.site1 = SphericalSite(frac_coords=np.array([0.1, 0.1, 0.1]), rcut=0.3, label="site1")
        self.site2 = SphericalSite(frac_coords=np.array([0.5, 0.5, 0.5]), rcut=0.3, label="site2")
        self.sites = [self.site1, self.site2]
        
        # Create trajectory object
        self.trajectory = Trajectory(sites=self.sites, atoms=self.atoms)
    
    def test_initialization(self):
        """Test that Trajectory initializes correctly."""
        # Check that the sites and atoms were stored
        self.assertEqual(self.trajectory.sites, self.sites)
        self.assertEqual(self.trajectory.atoms, self.atoms)
        
        # Check initial state
        self.assertEqual(len(self.trajectory.timesteps), 0)
        
        # Check lookup dictionaries
        self.assertEqual(self.trajectory.atom_lookup[0], 0)  # atom with index 0 is at position 0
        self.assertEqual(self.trajectory.atom_lookup[1], 1)  # atom with index 1 is at position 1
        self.assertEqual(self.trajectory.site_lookup[self.site1.index], 0)
        self.assertEqual(self.trajectory.site_lookup[self.site2.index], 1)
    
    def test_atom_by_index(self):
        """Test retrieving an atom by index."""
        self.assertIs(self.trajectory.atom_by_index(0), self.atom1)
        self.assertIs(self.trajectory.atom_by_index(1), self.atom2)
    
    def test_site_by_index(self):
        """Test retrieving a site by index."""
        self.assertIs(self.trajectory.site_by_index(self.site1.index), self.site1)
        self.assertIs(self.trajectory.site_by_index(self.site2.index), self.site2)
    
    def test_analyse_structure_delegates_to_site_collection(self):
        """Test that analyse_structure delegates to site_collection.analyse_structure."""
        # Create minimal real sites (required for Trajectory initialization)
        from site_analysis.spherical_site import SphericalSite
        import numpy as np
        
        real_sites = [SphericalSite(frac_coords=np.array([0.5, 0.5, 0.5]), rcut=1.0)]
        
        # Create mock atoms with required attributes
        mock_atom1 = Mock(spec=Atom)
        mock_atom1.index = 0
        mock_atom2 = Mock(spec=Atom) 
        mock_atom2.index = 1
        mock_atoms = [mock_atom1, mock_atom2]
        
        mock_structure = Mock(spec=Structure)
        
        # Create trajectory (this will create a real site_collection)
        trajectory = Trajectory(sites=real_sites, atoms=mock_atoms)
        
        # Mock the site_collection that was created
        trajectory.site_collection = Mock()
        
        # Call the method
        trajectory.analyse_structure(mock_structure)
        
        # Verify it delegates correctly
        trajectory.site_collection.analyse_structure.assert_called_once_with(mock_atoms, mock_structure)
    
    def test_append_timestep(self):
        """Test that append_timestep correctly adds a timestep."""
        # Pre-assign atoms to sites for simplicity
        self.atom1.in_site = self.site1.index
        self.atom2.in_site = self.site2.index
        self.site1.contains_atoms = [0]
        self.site2.contains_atoms = [1]
        
        # Append a timestep
        self.trajectory.append_timestep(self.structure, t=42)
        
        # Check timestep was recorded
        self.assertEqual(len(self.trajectory.timesteps), 1)
        self.assertEqual(self.trajectory.timesteps[0], 42)
        
        # Check atom trajectories were updated
        self.assertEqual(len(self.atom1.trajectory), 1)
        self.assertEqual(self.atom1.trajectory[0], self.site1.index)
        
        self.assertEqual(len(self.atom2.trajectory), 1)
        self.assertEqual(self.atom2.trajectory[0], self.site2.index)
        
        # Check site trajectories were updated
        self.assertEqual(len(self.site1.trajectory), 1)
        self.assertEqual(self.site1.trajectory[0], [0])  # Contains atom 0
        
        self.assertEqual(len(self.site2.trajectory), 1)
        self.assertEqual(self.site2.trajectory[0], [1])  # Contains atom 1
    
    def test_append_timestep_with_t_zero(self):
        """Test that append_timestep records timestep t=0."""
        self.trajectory.append_timestep(self.structure, t=0)
        self.assertEqual(self.trajectory.timesteps, [0])

    def test_reset(self):
        """Test that reset correctly clears the trajectory."""
        # Setup with a timestep
        self.test_append_timestep()  # Reuse the previous test
        
        # Reset the trajectory
        self.trajectory.reset()
        
        # Check timesteps are cleared
        self.assertEqual(len(self.trajectory.timesteps), 0)
        
        # Check atoms are reset
        self.assertIsNone(self.atom1.in_site)
        self.assertIsNone(self.atom2.in_site)
        self.assertEqual(len(self.atom1.trajectory), 0)
        self.assertEqual(len(self.atom2.trajectory), 0)
        
        # Check sites are reset
        self.assertEqual(len(self.site1.contains_atoms), 0)
        self.assertEqual(len(self.site2.contains_atoms), 0)
        self.assertEqual(len(self.site1.trajectory), 0)
        self.assertEqual(len(self.site2.trajectory), 0)
    
    def test_trajectory_from_structures(self):
        """Test generating a trajectory from a list of structures."""
        # Create list of structures
        structures = [self.structure, self.structure2]
        
        # Generate trajectory
        self.trajectory.trajectory_from_structures(structures)
        
        # Check two timesteps were recorded
        self.assertEqual(len(self.trajectory.timesteps), 2)
        self.assertEqual(self.trajectory.timesteps, [1, 2])  # Should be 1-indexed
        
        # Check atom trajectories length
        self.assertEqual(len(self.atom1.trajectory), 2)
        self.assertEqual(len(self.atom2.trajectory), 2)
        
        # Check site trajectories length
        self.assertEqual(len(self.site1.trajectory), 2)
        self.assertEqual(len(self.site2.trajectory), 2)
    
    def test_atom_sites_property(self):
        """Test the atom_sites property."""
        # Assign atoms to sites
        self.atom1.in_site = self.site1.index
        self.atom2.in_site = self.site2.index
        
        # Check the property
        atom_sites = self.trajectory.atom_sites
        self.assertEqual(len(atom_sites), 2)
        self.assertEqual(atom_sites[0], self.site1.index)
        self.assertEqual(atom_sites[1], self.site2.index)
    
    def test_site_occupations_property(self):
        """Test the site_occupations property."""
        # Assign atoms to sites
        self.site1.contains_atoms = [0]
        self.site2.contains_atoms = [1]
        
        # Check the property
        occupations = self.trajectory.site_occupations
        self.assertEqual(len(occupations), 2)
        self.assertEqual(occupations[0], [0])  # site1 contains atom0
        self.assertEqual(occupations[1], [1])  # site2 contains atom1
    
    def test_trajectory_properties(self):
        """Test atoms_trajectory and sites_trajectory properties."""
        # Setup with two timesteps
        self.atom1.trajectory = [self.site1.index, self.site1.index]
        self.atom2.trajectory = [self.site2.index, self.site2.index]
        
        self.site1.trajectory = [[0], [0]]
        self.site2.trajectory = [[1], [1]]
        
        # Check atoms_trajectory
        at = self.trajectory.atoms_trajectory
        self.assertEqual(len(at), 2)  # 2 timesteps
        self.assertEqual(at[0], [self.site1.index, self.site2.index])  # First timestep
        self.assertEqual(at[1], [self.site1.index, self.site2.index])  # Second timestep
        
        # Check sites_trajectory
        st = self.trajectory.sites_trajectory
        self.assertEqual(len(st), 2)  # 2 timesteps
        self.assertEqual(st[0], [[0], [1]])  # First timestep
        self.assertEqual(st[1], [[0], [1]])  # Second timestep
        
        # Check shortcuts
        self.assertEqual(self.trajectory.at, at)
        self.assertEqual(self.trajectory.st, st)
    
    def test_site_coordination_numbers(self):
        """Test the site_coordination_numbers method."""
        # Use patch to mock the coordination_number property
        with patch.object(SphericalSite, 'coordination_number', 
                         new_callable=PropertyMock) as mock_coord_number:
            # Configure the mock to return different values for different sites
            mock_coord_number.side_effect = [4, 6]
            
            # Get coordination numbers
            coordination = self.trajectory.site_coordination_numbers()
            
            # Check the counter
            self.assertEqual(coordination[4], 1)  # 1 site with coordination 4
            self.assertEqual(coordination[6], 1)  # 1 site with coordination 6
    
    def test_site_labels(self):
        """Test the site_labels method."""
        # Sites already have labels from setUp
        labels = self.trajectory.site_labels()
        
        self.assertEqual(len(labels), 2)
        self.assertEqual(labels[0], "site1")
        self.assertEqual(labels[1], "site2")
        
    def test_assign_site_occupations(self):
        """Test that assign_site_occupations extracts lattice_matrix and delegates."""
        self.trajectory.site_collection = Mock()

        self.trajectory.assign_site_occupations(self.structure)

        self.trajectory.site_collection.assign_site_occupations.assert_called_once()
        args = self.trajectory.site_collection.assign_site_occupations.call_args[0]
        self.assertIs(args[0], self.atoms)
        np.testing.assert_array_equal(args[1], self.structure.lattice.matrix)
    
    def test_trajectory_from_structures_with_progress(self):
        """Test trajectory_from_structures wraps iterator with tqdm."""
        structures = [self.structure, self.structure2]

        with patch.object(self.trajectory, 'append_timestep') as mock_append, \
             patch('site_analysis.trajectory.tqdm') as mock_tqdm:
            mock_tqdm.return_value = enumerate(structures, 1)

            self.trajectory.trajectory_from_structures(structures, progress=True)

            mock_tqdm.assert_called_once()
            _, kwargs = mock_tqdm.call_args
            self.assertEqual(kwargs['total'], 2)
            self.assertEqual(mock_append.call_count, 2)

    def test_init_with_empty_sites(self):
        """Test that Trajectory raises ValueError with empty sites list."""
        with self.assertRaises(ValueError) as context:
            Trajectory(sites=[], atoms=[Atom(index=0)])

        self.assertIn("empty sites list", str(context.exception))

    def test_init_with_empty_atoms(self):
        """Test that Trajectory raises ValueError with empty atoms list."""
        sites = [SphericalSite(frac_coords=np.array([0.5, 0.5, 0.5]), rcut=1.0)]

        with self.assertRaises(ValueError) as context:
            Trajectory(sites=sites, atoms=[])

        self.assertIn("empty atoms list", str(context.exception))
        
    def test_site_summaries_default(self):
        """Test that site_summaries delegates to site_collection."""
        # Create real sites
        sites = [
            SphericalSite(frac_coords=np.array([0.0, 0.0, 0.0]), rcut=1.0),
            SphericalSite(frac_coords=np.array([0.5, 0.5, 0.5]), rcut=1.0)
        ]
        mock_atoms = [Mock(spec=Atom, index=0)]
        
        # Create trajectory
        trajectory = Trajectory(sites=sites, atoms=mock_atoms)
        
        # Replace site_collection with mock
        trajectory.site_collection = Mock(spec=SiteCollection)
        trajectory.site_collection.summaries.return_value = [
            {'index': 0, 'site_type': 'SphericalSite'},
            {'index': 1, 'site_type': 'SphericalSite'}
        ]
        
        result = trajectory.site_summaries()
        
        # Should delegate to site_collection
        trajectory.site_collection.summaries.assert_called_once_with(metrics=None)
        
        # Should return the same result
        self.assertEqual(result, [
            {'index': 0, 'site_type': 'SphericalSite'},
            {'index': 1, 'site_type': 'SphericalSite'}
        ])
    
    def test_site_summaries_with_metrics(self):
        """Test that site_summaries passes metrics to site_collection."""
        # Create real site
        sites = [SphericalSite(frac_coords=np.array([0.0, 0.0, 0.0]), rcut=1.0)]
        mock_atoms = [Mock(spec=Atom, index=0)]
        
        # Create trajectory
        trajectory = Trajectory(sites=sites, atoms=mock_atoms)
        
        # Replace site_collection with mock
        trajectory.site_collection = Mock(spec=SiteCollection)
        trajectory.site_collection.summaries.return_value = [
            {'index': 0},
            {'index': 1}
        ]
        
        result = trajectory.site_summaries(metrics=['index'])
        
        # Should pass metrics through
        trajectory.site_collection.summaries.assert_called_once_with(metrics=['index'])
        
        # Should return the same result
        self.assertEqual(result, [{'index': 0}, {'index': 1}])
        
    def test_write_site_summaries_default(self):
        """Test that write_site_summaries writes summaries to JSON file."""
        # Create trajectory
        sites = [SphericalSite(frac_coords=np.array([0.0, 0.0, 0.0]), rcut=1.0)]
        mock_atoms = [Mock(spec=Atom, index=0)]
        trajectory = Trajectory(sites=sites, atoms=mock_atoms)
        
        # Mock site_summaries to return known data
        expected_data = [{'index': 0, 'site_type': 'SphericalSite'}]
        trajectory.site_summaries = Mock(return_value=expected_data)
        
        # Mock file operations
        mock_file = Mock()
        mock_file.__enter__ = Mock(return_value=mock_file)
        mock_file.__exit__ = Mock(return_value=None)
        
        with patch('builtins.open', return_value=mock_file) as mock_open:
            with patch('json.dump') as mock_json_dump:
                trajectory.write_site_summaries('output.json')
                
                # Should call site_summaries with default metrics
                trajectory.site_summaries.assert_called_once_with(metrics=None)
                
                # Should open file for writing
                mock_open.assert_called_once_with('output.json', 'w')
                
                # Should dump data to file with nice formatting
                mock_json_dump.assert_called_once_with(expected_data, mock_file, indent=2)
    
    def test_write_site_summaries_with_metrics(self):
        """Test that write_site_summaries passes metrics parameter."""
        # Create trajectory
        sites = [SphericalSite(frac_coords=np.array([0.0, 0.0, 0.0]), rcut=1.0)]
        mock_atoms = [Mock(spec=Atom, index=0)]
        trajectory = Trajectory(sites=sites, atoms=mock_atoms)
        
        # Mock site_summaries
        expected_data = [{'index': 0}]
        trajectory.site_summaries = Mock(return_value=expected_data)
        
        # Mock file operations
        mock_file = Mock()
        mock_file.__enter__ = Mock(return_value=mock_file)
        mock_file.__exit__ = Mock(return_value=None)
        
        with patch('builtins.open', return_value=mock_file) as mock_open:
            with patch('json.dump') as mock_json_dump:
                trajectory.write_site_summaries('output.json', metrics=['index'])
                
                # Should pass metrics to site_summaries
                trajectory.site_summaries.assert_called_once_with(metrics=['index'])
                
                # Should write to file
                mock_json_dump.assert_called_once_with(expected_data, mock_file, indent=2)
    
    def test_reset_clears_dynamic_voronoi_batch_caches(self):
        """trajectory.reset() should clear DynamicVoronoiSiteCollection group caches."""
        Site._newid = 0
        lattice = Lattice.cubic(10.0)
        # 4 reference atoms + 1 mobile atom
        coords = [[0.1, 0.1, 0.1], [0.2, 0.2, 0.2],
                  [0.7, 0.7, 0.7], [0.8, 0.8, 0.8],
                  [0.15, 0.15, 0.15]]
        structure = Structure(lattice, ["Na"] * 5, coords)

        site1 = DynamicVoronoiSite(reference_indices=[0, 1])
        site2 = DynamicVoronoiSite(reference_indices=[2, 3])
        atom = Atom(index=4)
        trajectory = Trajectory(sites=[site1, site2], atoms=[atom])

        trajectory.append_timestep(structure, t=1)
        self.assertTrue(trajectory.site_collection._centre_groups[0].initialised)

        trajectory.reset()
        self.assertFalse(trajectory.site_collection._centre_groups[0].initialised)
        self.assertIsNone(site1._centre_coords)
        self.assertIsNone(site2._centre_coords)

    def test_write_site_summaries_integration(self):
        """Integration test that actually writes a file."""
        
        # Create trajectory with real data
        Site.reset_index()  # Reset to get predictable indices
        sites = [
            SphericalSite(frac_coords=np.array([0.0, 0.0, 0.0]), rcut=1.0),
            SphericalSite(frac_coords=np.array([0.5, 0.5, 0.5]), rcut=1.0)
        ]
        mock_atoms = [Mock(spec=Atom, index=0)]
        trajectory = Trajectory(sites=sites, atoms=mock_atoms)
        
        # Write to temporary file
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.json') as f:
            temp_filename = f.name
        
        try:
            trajectory.write_site_summaries(temp_filename, metrics=['index', 'site_type'])
            
            # Read back and verify
            with open(temp_filename, 'r') as f:
                data = json.load(f)
            
            self.assertEqual(len(data), 2)
            self.assertEqual(data[0]['index'], 0)
            self.assertEqual(data[0]['site_type'], 'SphericalSite')
            self.assertEqual(data[1]['index'], 1)
            self.assertEqual(data[1]['site_type'], 'SphericalSite')
        finally:
            # Clean up
            os.unlink(temp_filename)


class TransitionCountsBySiteTestCase(unittest.TestCase):
    """Tests for Trajectory.transition_counts_by_site()."""

    def setUp(self):
        Site._newid = 0
        self.site0 = SphericalSite(frac_coords=np.array([0.0, 0.0, 0.0]), rcut=0.3, label="A")
        self.site1 = SphericalSite(frac_coords=np.array([0.5, 0.5, 0.5]), rcut=0.3, label="B")
        self.site2 = SphericalSite(frac_coords=np.array([0.5, 0.0, 0.5]), rcut=0.3)
        self.sites = [self.site0, self.site1, self.site2]
        self.atoms = [Atom(index=0)]
        self.trajectory = Trajectory(sites=self.sites, atoms=self.atoms)

    def test_all_sites_have_transitions(self):
        """Test correct counts with transitions on every site."""
        self.site0.transitions = Counter({1: 3, 2: 1})
        self.site1.transitions = Counter({0: 2})
        self.site2.transitions = Counter({0: 1, 1: 4})
        result = self.trajectory.transition_counts_by_site()
        self.assertEqual(result.to_dict(), {
            0: {0: 0, 1: 3, 2: 1},
            1: {0: 2, 1: 0, 2: 0},
            2: {0: 1, 1: 4, 2: 0},
        })

    def test_site_with_no_outgoing_transitions(self):
        """Test that a site with no transitions appears as a row of zeros."""
        self.site0.transitions = Counter({1: 5})
        # site1 and site2 have no transitions
        result = self.trajectory.transition_counts_by_site()
        np.testing.assert_array_equal(result.matrix[1], [0, 0, 0])
        np.testing.assert_array_equal(result.matrix[2], [0, 0, 0])

    def test_asymmetric_transitions(self):
        """Test that A->B and B->A are independent entries."""
        self.site0.transitions = Counter({1: 3})
        # site1 has no transition back to site0
        result = self.trajectory.transition_counts_by_site()
        self.assertEqual(result.get(0, 1), 3)
        self.assertEqual(result.get(1, 0), 0)

    def test_no_transitions_at_all(self):
        """Test all zeros when no transitions recorded."""
        result = self.trajectory.transition_counts_by_site()
        np.testing.assert_array_equal(result.matrix, np.zeros((3, 3)))

    def test_self_transitions_are_preserved_if_present(self):
        """Test that pre-populated self-transition keys are preserved.

        Note: SiteCollection.update_occupation() skips self-transitions,
        so these should not appear in normal trajectory data. This test
        verifies that transition_counts_by_site() faithfully reports whatever is
        present in site.transitions without filtering.
        """
        self.site0.transitions = Counter({0: 2, 1: 3})
        result = self.trajectory.transition_counts_by_site()
        self.assertEqual(result.get(0, 0), 2)
        self.assertEqual(result.get(0, 1), 3)

    def test_unknown_destination_index_raises(self):
        """Test that a transition to a non-existent site index raises ValueError."""
        self.site0.transitions = Counter({1: 3, 99: 5})
        with self.assertRaises(ValueError):
            self.trajectory.transition_counts_by_site()

    def test_single_site(self):
        """Test single-site trajectory produces 1x1 zero matrix."""
        Site._newid = 0
        site = SphericalSite(frac_coords=np.array([0.0, 0.0, 0.0]), rcut=0.3)
        trajectory = Trajectory(sites=[site], atoms=[Atom(index=0)])
        result = trajectory.transition_counts_by_site()
        self.assertEqual(result.to_dict(), {0: {0: 0}})


class TransitionCountsByLabelTestCase(unittest.TestCase):
    """Tests for Trajectory.transition_counts_by_label()."""

    def setUp(self):
        Site._newid = 0
        # Two sites labelled "A", one labelled "B", one unlabelled
        self.site0 = SphericalSite(frac_coords=np.array([0.0, 0.0, 0.0]), rcut=0.3, label="A")
        self.site1 = SphericalSite(frac_coords=np.array([0.25, 0.25, 0.25]), rcut=0.3, label="A")
        self.site2 = SphericalSite(frac_coords=np.array([0.5, 0.5, 0.5]), rcut=0.3, label="B")
        self.site3 = SphericalSite(frac_coords=np.array([0.75, 0.75, 0.75]), rcut=0.3)
        self.sites = [self.site0, self.site1, self.site2, self.site3]
        self.atoms = [Atom(index=0)]
        self.trajectory = Trajectory(sites=self.sites, atoms=self.atoms)

    def test_basic_label_aggregation(self):
        """Test that transitions from sites sharing a label are summed."""
        # site0 (A) -> site2 (B): 3 hops
        self.site0.transitions = Counter({2: 3})
        # site1 (A) -> site2 (B): 2 hops
        self.site1.transitions = Counter({2: 2})
        # site2 (B) -> site0 (A): 1 hop
        self.site2.transitions = Counter({0: 1})
        result = self.trajectory.transition_counts_by_label()
        self.assertEqual(result.to_dict(), {
            "A": {"A": 0, "B": 5},
            "B": {"A": 1, "B": 0},
        })

    def test_unlabelled_sites_are_skipped_with_warning(self):
        """Test that transitions to unlabelled sites are excluded with a warning."""
        # unlabelled site3 has transitions
        self.site3.transitions = Counter({0: 10})
        # site0 (A) transitions to unlabelled site3
        self.site0.transitions = Counter({3: 7})
        with self.assertWarns(UserWarning):
            result = self.trajectory.transition_counts_by_label()
        # site3 should not appear; site0's transition to site3 is excluded
        self.assertNotIn(None, result.keys)
        self.assertEqual(result.to_dict(), {
            "A": {"A": 0, "B": 0},
            "B": {"A": 0, "B": 0},
        })

    def test_all_sites_unlabelled(self):
        """Test that all-unlabelled sites produce an empty table."""
        Site._newid = 0
        site = SphericalSite(frac_coords=np.array([0.0, 0.0, 0.0]), rcut=0.3)
        trajectory = Trajectory(sites=[site], atoms=[Atom(index=0)])
        result = trajectory.transition_counts_by_label()
        self.assertEqual(result.keys, ())
        self.assertEqual(result.matrix.shape, (0, 0))

    def test_square_output(self):
        """Test that labels appearing only as destinations still appear as keys."""
        # Only site0 (A) has transitions, to site2 (B)
        self.site0.transitions = Counter({2: 1})
        result = self.trajectory.transition_counts_by_label()
        # "B" should appear as a key even though it has no outgoing transitions
        self.assertIn("B", result.keys)
        np.testing.assert_array_equal(result.matrix[1], [0, 0])

    def test_intra_label_transitions(self):
        """Test transitions between sites that share the same label."""
        # site0 (A) -> site1 (A): this is an A->A transition
        self.site0.transitions = Counter({1: 4})
        result = self.trajectory.transition_counts_by_label()
        self.assertEqual(result.get("A", "A"), 4)

    def test_unlabelled_site_with_invalid_destination_raises(self):
        """Test that an unlabelled site transitioning to an invalid index raises."""
        self.site3.transitions = Counter({99: 5})
        with self.assertRaises(ValueError):
            self.trajectory.transition_counts_by_label()


class TransitionProbabilitiesTestCase(unittest.TestCase):
    """Tests for Trajectory.transition_probabilities_by_site() and transition_probabilities_by_label()."""

    def setUp(self):
        Site._newid = 0
        self.site0 = SphericalSite(frac_coords=np.array([0.0, 0.0, 0.0]), rcut=0.3, label="A")
        self.site1 = SphericalSite(frac_coords=np.array([0.5, 0.5, 0.5]), rcut=0.3, label="B")
        self.site2 = SphericalSite(frac_coords=np.array([0.5, 0.0, 0.5]), rcut=0.3, label="C")
        self.sites = [self.site0, self.site1, self.site2]
        self.atoms = [Atom(index=0)]
        self.trajectory = Trajectory(sites=self.sites, atoms=self.atoms)

    def test_basic_normalisation(self):
        """Test row-normalised probabilities sum to 1.0."""
        self.site0.transitions = Counter({1: 3, 2: 1})  # total 4
        self.site1.transitions = Counter({0: 2, 2: 2})  # total 4
        result = self.trajectory.transition_probabilities_by_site()
        self.assertAlmostEqual(result.get(0, 1), 0.75)
        self.assertAlmostEqual(result.get(0, 2), 0.25)
        self.assertAlmostEqual(result.get(0, 0), 0.0)
        self.assertAlmostEqual(result.get(1, 0), 0.5)
        self.assertAlmostEqual(result.get(1, 2), 0.5)

    def test_row_with_zero_transitions(self):
        """Test that a row with no transitions remains all zeros."""
        self.site0.transitions = Counter({1: 1})
        # site1 and site2 have no transitions
        result = self.trajectory.transition_probabilities_by_site()
        np.testing.assert_array_equal(result.matrix[1], [0.0, 0.0, 0.0])
        np.testing.assert_array_equal(result.matrix[2], [0.0, 0.0, 0.0])

    def test_single_outgoing_transition(self):
        """Test that a single outgoing transition becomes 1.0."""
        self.site0.transitions = Counter({1: 5})
        result = self.trajectory.transition_probabilities_by_site()
        self.assertAlmostEqual(result.get(0, 1), 1.0)
        self.assertAlmostEqual(result.get(0, 0), 0.0)
        self.assertAlmostEqual(result.get(0, 2), 0.0)

    def test_by_label(self):
        """Test label-level probabilities are correctly normalised."""
        self.site0.transitions = Counter({1: 6, 2: 4})  # A: total 10
        self.site1.transitions = Counter({0: 3})         # B: total 3
        result = self.trajectory.transition_probabilities_by_label()
        self.assertAlmostEqual(result.get("A", "B"), 0.6)
        self.assertAlmostEqual(result.get("A", "C"), 0.4)
        self.assertAlmostEqual(result.get("B", "A"), 1.0)

    def test_zero_transition_label_by_label(self):
        """Test that a label with no outgoing transitions gives all-zero probabilities."""
        self.site0.transitions = Counter({1: 4})  # A -> B
        # site1 (B) and site2 (C) have no transitions
        result = self.trajectory.transition_probabilities_by_label()
        np.testing.assert_array_equal(result.matrix[1], [0.0, 0.0, 0.0])
        np.testing.assert_array_equal(result.matrix[2], [0.0, 0.0, 0.0])


class TransitionCustomKeysTestCase(unittest.TestCase):
    """Tests for custom key ordering on transition methods."""

    def setUp(self):
        Site._newid = 0
        self.site0 = SphericalSite(frac_coords=np.array([0.0, 0.0, 0.0]), rcut=0.3, label="A")
        self.site1 = SphericalSite(frac_coords=np.array([0.5, 0.5, 0.5]), rcut=0.3, label="B")
        self.site2 = SphericalSite(frac_coords=np.array([0.5, 0.0, 0.5]), rcut=0.3, label="C")
        self.sites = [self.site0, self.site1, self.site2]
        self.atoms = [Atom(index=0)]
        self.trajectory = Trajectory(sites=self.sites, atoms=self.atoms)

    def test_custom_key_order_by_site(self):
        """Test that custom keys reorder rows and columns for counts."""
        self.site0.transitions = Counter({1: 3, 2: 1})
        self.site1.transitions = Counter({0: 2})
        result = self.trajectory.transition_counts_by_site(keys=[2, 0, 1])
        self.assertEqual(result.keys, (2, 0, 1))
        np.testing.assert_array_equal(result.matrix, np.array([
            [0, 0, 0],
            [1, 0, 3],
            [0, 2, 0],
        ]))

    def test_custom_key_order_by_label(self):
        """Test that custom keys reorder rows and columns for probabilities."""
        self.site0.transitions = Counter({1: 3, 2: 1})
        self.site1.transitions = Counter({0: 2})
        result = self.trajectory.transition_probabilities_by_label(keys=["C", "B", "A"])
        self.assertEqual(result.keys, ("C", "B", "A"))
        np.testing.assert_array_almost_equal(result.matrix, np.array([
            [0.0, 0.0, 0.0],
            [0.0, 0.0, 1.0],
            [0.25, 0.75, 0.0],
        ]))

    def test_custom_key_order_probabilities_by_site(self):
        """Test that custom keys reorder probabilities by site."""
        self.site0.transitions = Counter({1: 3, 2: 1})
        self.site1.transitions = Counter({0: 2})
        result = self.trajectory.transition_probabilities_by_site(keys=[2, 0, 1])
        self.assertEqual(result.keys, (2, 0, 1))
        np.testing.assert_array_almost_equal(result.matrix, np.array([
            [0.0, 0.0, 0.0],
            [0.25, 0.0, 0.75],
            [0.0, 1.0, 0.0],
        ]))

    def test_unknown_key_raises_value_error(self):
        """Test that an unknown key raises ValueError."""
        with self.assertRaises(ValueError):
            self.trajectory.transition_counts_by_label(keys=["A", "Z"])

    def test_subset_keys_raises_value_error(self):
        """Test that passing a subset of keys raises ValueError."""
        with self.assertRaises(ValueError):
            self.trajectory.transition_counts_by_label(keys=["A", "B"])

    def test_default_keys_are_sorted(self):
        """Test that keys are sorted by default."""
        self.site0.transitions = Counter({1: 3})
        result = self.trajectory.transition_counts_by_site()
        self.assertEqual(result.keys, (0, 1, 2))

    def test_default_label_keys_are_sorted(self):
        """Test that label keys are sorted by default."""
        self.site0.transitions = Counter({1: 3})
        result = self.trajectory.transition_counts_by_label()
        self.assertEqual(result.keys, ("A", "B", "C"))


if __name__ == '__main__':
    unittest.main()
