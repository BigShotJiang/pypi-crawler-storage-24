"""ORBIT CLI — Data strategy copilot for robot policy training."""

from __future__ import annotations

import json
import sys

import click


def _json_default(obj):
    """Handle numpy types for JSON serialization."""
    import numpy as np

    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


class _OrbitGroup(click.Group):
    """Custom group that catches unexpected errors and shows clean messages."""

    def invoke(self, ctx):
        try:
            return super().invoke(ctx)
        except click.exceptions.Exit:
            raise
        except click.exceptions.Abort:
            raise
        except click.ClickException:
            raise
        except SystemExit:
            raise
        except KeyboardInterrupt:
            raise SystemExit(130)
        except Exception as e:
            from orbit.utils.display import console

            console.print(f"\n[bold red]Error:[/bold red] {e}")
            console.print("[dim]Run with ORBIT_DEBUG=1 for full traceback.[/dim]")
            import os

            if os.environ.get("ORBIT_DEBUG"):
                raise
            raise SystemExit(1) from None


@click.group(cls=_OrbitGroup)
def main():
    """Data strategy copilot for robot policy training."""


@main.command()
@click.argument("dataset_repo")
@click.option("--episodes", type=int, default=None, help="Limit analysis to N episodes.")
@click.option("--no-cache", is_flag=True, help="Skip cache.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--skip-embeddings", is_flag=True, help="Skip SigLIP embedding analysis.")
@click.option("--skip-coverage", is_flag=True, help="Skip coverage analysis.")
@click.option(
    "--device",
    type=click.Choice(["cpu", "cuda", "mps"]),
    default=None,
    help="Device for embedding computation.",
)
@click.option("--max-frames", type=int, default=4, help="Frames per episode for embeddings.")
@click.option("--skip-signal-diagnostics", is_flag=True, help="Skip signal diagnostics.")
@click.option("--skip-ai-assessment", is_flag=True, help="Skip VLM-powered AI assessment.")
@click.option(
    "--policy",
    default="auto",
    help="Policy type for fit analysis (act, diffusion_policy, smolvla, auto).",
)
@click.option("--full", is_flag=True, help="Analyze all episodes (no sampling).")
def analyze(
    dataset_repo: str,
    episodes: int | None,
    no_cache: bool,
    as_json: bool,
    skip_embeddings: bool,
    skip_coverage: bool,
    device: str | None,
    max_frames: int,
    skip_signal_diagnostics: bool,
    skip_ai_assessment: bool,
    policy: str,
    full: bool,
):
    """Analyze robot training data."""
    import numpy as np

    from orbit.analyzer.coverage import compute_coverage
    from orbit.analyzer.dataset_loader import load_dataset_info, load_episode_data
    from orbit.analyzer.policy_fit import PolicyFitAnalyzer
    from orbit.analyzer.quality import compute_quality_score, ready_to_train_assessment
    from orbit.analyzer.recommendations import generate_recommendations
    from orbit.analyzer.success_predictor import CalibratedSuccessPredictor
    from orbit.analyzer.task_context import TaskContextAnalyzer
    from orbit.utils.display import console

    # Validate dataset_repo
    if not dataset_repo or not dataset_repo.strip():
        if as_json:
            click.echo(json.dumps({"error": "Dataset repo ID must not be empty"}))
        else:
            console.print("\n[bold red]Error:[/bold red] Dataset repo ID must not be empty")
        sys.exit(1)

    if "/" not in dataset_repo or dataset_repo.endswith("/") or dataset_repo.startswith("/"):
        if as_json:
            click.echo(
                json.dumps(
                    {
                        "error": f"Invalid repo ID '{dataset_repo}'. "
                        "Expected format: owner/dataset_name (e.g. lerobot/pusht)"
                    }
                )
            )
        else:
            console.print(
                f"\n[bold red]Error:[/bold red] Invalid repo ID '{dataset_repo}'. "
                "Expected format: owner/dataset_name (e.g. lerobot/pusht)"
            )
        sys.exit(1)

    try:
        info = load_dataset_info(dataset_repo)
    except (ValueError, ConnectionError) as e:
        if as_json:
            click.echo(json.dumps({"error": str(e)}))
        else:
            console.print(f"\n[bold red]Error:[/bold red] {e}")
        sys.exit(1)

    # Load episode data for coverage analysis
    coverage = None
    episode_data = None
    if not skip_coverage:
        try:
            ep_indices = list(range(min(episodes, info.num_episodes))) if episodes else None
            max_ep = None if full else (episodes or 100)
            episode_data = load_episode_data(
                dataset_repo, episode_indices=ep_indices, max_episodes=max_ep,
            )
            if not as_json and episode_data is not None and not episode_data.empty:
                n_loaded = episode_data["episode_index"].nunique()
                if n_loaded < info.num_episodes:
                    console.print(
                        f"[dim]Analyzing {n_loaded}/{info.num_episodes} episodes "
                        f"(sampling for speed, use --full for all)[/dim]"
                    )
        except (ValueError, ConnectionError):
            episode_data = None

        if episode_data is not None and not episode_data.empty:
            coverage = compute_coverage(info, episode_data)

    is_estimated = coverage is None
    if is_estimated:
        coverage = _synthetic_coverage(info)

    # Signal diagnostics (optional)
    signal_diag = None
    if not skip_signal_diagnostics and episode_data is not None and not episode_data.empty:
        try:
            from orbit.analyzer.coverage import _extract_array
            from orbit.analyzer.signal_diagnostics import compute_signal_diagnostics

            action_arr = (
                _extract_array(episode_data["action"]) if "action" in episode_data.columns else None
            )
            if action_arr is not None and action_arr.size > 0:
                # Group by episode
                ep_groups = episode_data.groupby("episode_index")
                action_episodes = []
                for _, ep_df in ep_groups:
                    ep_actions = _extract_array(ep_df["action"])
                    if ep_actions is not None and ep_actions.size > 0:
                        action_episodes.append(ep_actions)

                if action_episodes:
                    signal_diag = compute_signal_diagnostics(action_episodes)
        except Exception as e:
            if not as_json:
                console.print(f"\n[dim]Signal diagnostics skipped — {e}[/dim]")

    # Embedding analysis (optional)
    embedding_analysis = None
    visual_diversity: float | None = None

    if not skip_embeddings:
        try:
            from orbit.analyzer.embeddings import (
                analyze_embeddings,
                compute_frame_embeddings,
            )

            max_ep = episodes if episodes else 100

            if as_json:
                import io
                from contextlib import redirect_stderr, redirect_stdout

                buf = io.StringIO()
                with redirect_stdout(buf), redirect_stderr(buf):
                    emb_result = compute_frame_embeddings(
                        dataset_repo,
                        info,
                        max_frames_per_episode=max_frames,
                        max_episodes=max_ep,
                        device=device,
                        no_cache=no_cache,
                    )
            else:
                emb_result = compute_frame_embeddings(
                    dataset_repo,
                    info,
                    max_frames_per_episode=max_frames,
                    max_episodes=max_ep,
                    device=device,
                    no_cache=no_cache,
                )
            embedding_analysis = analyze_embeddings(emb_result)
            visual_diversity = embedding_analysis.diversity_score
        except ImportError:
            if not as_json:
                console.print(
                    "\n[dim]Visual analysis skipped — install torch and "
                    "transformers for embedding analysis[/dim]"
                )
        except Exception as e:
            if not as_json:
                console.print(f"\n[dim]Visual analysis skipped — {e}[/dim]")

    # Build action episodes list for new analyzers
    action_episodes = []
    state_episodes = []
    if episode_data is not None and not episode_data.empty:
        try:
            from orbit.analyzer.coverage import _extract_array

            ep_groups = episode_data.groupby("episode_index")
            for _, ep_df in ep_groups:
                if "action" in ep_df.columns:
                    ep_actions = _extract_array(ep_df["action"])
                    if ep_actions is not None and ep_actions.size > 0:
                        action_episodes.append(ep_actions)
                if "state" in ep_df.columns:
                    ep_states = _extract_array(ep_df["state"])
                    if ep_states is not None and ep_states.size > 0:
                        state_episodes.append(ep_states)
        except Exception:
            pass

    # Compute quality and recommendations
    quality = compute_quality_score(
        info,
        coverage,
        visual_diversity=visual_diversity,
        action_episodes=action_episodes if action_episodes else None,
        state_episodes=state_episodes if state_episodes else None,
        signal_diagnostics_summary=(
            max(0.0, 1.0 - len(signal_diag.blockers) * 0.15
                - min(len(signal_diag.warnings), 6) * 0.05)
            if signal_diag
            else None
        ),
    )
    assessment = ready_to_train_assessment(quality)
    recs = generate_recommendations(info, coverage, quality)

    # --- NEW: Full prediction pipeline ---

    # Task Context Analysis
    task_context = None
    if action_episodes:
        try:
            analyzer = TaskContextAnalyzer()
            task_context = analyzer.analyze(
                action_episodes,
                metadata={
                    "robot_type": info.robot_type,
                    "task_description": dataset_repo,
                },
            )
        except Exception as e:
            if not as_json:
                console.print(f"\n[dim]Task context analysis skipped — {e}[/dim]")

    # Policy Fit Analysis
    policy_fit_result = None
    if action_episodes and task_context:
        try:
            pf_analyzer = PolicyFitAnalyzer()
            policy_fit_result = pf_analyzer.analyze(
                action_episodes,
                policy_type=policy,
                episode_count=info.num_episodes,
                metadata={"is_bimanual": task_context.is_bimanual},
                task_complexity=task_context.task_complexity_score,
                consistency_score=coverage.episode_consistency,
                multimodality_score=task_context.trajectory_multimodality,
            )
        except Exception as e:
            if not as_json:
                console.print(f"\n[dim]Policy fit analysis skipped — {e}[/dim]")

    # Calibrated Success Prediction
    success_prediction = None
    if task_context and policy_fit_result:
        try:
            predictor = CalibratedSuccessPredictor()
            sig_diag_dict = {}
            if signal_diag:
                sig_diag_dict = {
                    "blockers": signal_diag.blockers,
                    "warnings": signal_diag.warnings,
                    "dead_dimensions": signal_diag.dead_dimensions,
                }

            # Infer task type from dataset name
            from orbit.analyzer.task_inference import infer_task_profile

            task_profile = infer_task_profile(dataset_name=dataset_repo)

            success_prediction = predictor.predict(
                data_quality=quality.overall_score,
                task_context=task_context,
                policy_fit=policy_fit_result,
                signal_diagnostics=sig_diag_dict,
                embedding_diversity=visual_diversity,
                task_type=task_profile.task_type,
                episode_count=info.num_episodes,
            )
        except Exception as e:
            if not as_json:
                console.print(f"\n[dim]Success prediction skipped — {e}[/dim]")

    # Community Comparison
    community_comp = None
    try:
        from orbit.analyzer.community_comparison import compute_community_comparison
        from orbit.analyzer.task_inference import infer_task_profile as _infer_tp

        _tp = _infer_tp(dataset_name=dataset_repo)
        community_comp = compute_community_comparison(
            dataset_name=dataset_repo,
            task_type=_tp.task_type,
            robot_type=info.robot_type,
            num_episodes=info.num_episodes,
            coverage_score=quality.overall_score,
            policy_type=policy_fit_result.policy_type if policy_fit_result else None,
        )
    except Exception as e:
        if not as_json:
            console.print(f"\n[dim]Community comparison skipped — {e}[/dim]")

    # AI Assessment (VLM predictor — legacy, still available)
    vlm_prediction = None
    if not skip_ai_assessment:
        try:
            from orbit.analyzer.vlm_predictor import predict_success_rate

            vlm_quality_metrics = {}
            if not skip_signal_diagnostics and signal_diag is not None:
                vlm_quality_metrics["action_smoothness"] = (
                    float(np.mean([jd.smoothness for jd in signal_diag.joint_diagnostics]))
                    if signal_diag.joint_diagnostics
                    else 0.5
                )

            vlm_dataset_info = {
                "num_episodes": info.num_episodes,
                "task_description": dataset_repo,
                "robot_type": info.robot_type or "unknown",
                "policy": policy_fit_result.policy_type if policy_fit_result else "unknown",
            }

            vlm_prediction = predict_success_rate(
                coverage_report=coverage,
                signal_diagnostics=signal_diag,
                quality_metrics=vlm_quality_metrics,
                dataset_info=vlm_dataset_info,
            )
        except Exception as e:
            if not as_json:
                console.print(f"\n[dim]AI assessment skipped — {e}[/dim]")

    if as_json:
        report = _full_report_to_dict(
            info,
            coverage,
            quality,
            assessment,
            recs,
            embedding_analysis=embedding_analysis,
            signal_diagnostics=signal_diag,
        )
        report["coverage_estimated"] = is_estimated
        if success_prediction is not None:
            report["success_prediction"] = {
                "predicted_success_rate": success_prediction.predicted_success_rate,
                "confidence_interval": list(success_prediction.confidence_interval),
                "grade": success_prediction.grade,
                "contributing_factors": success_prediction.contributing_factors,
                "limiting_factor": success_prediction.limiting_factor,
                "limiting_factor_detail": success_prediction.limiting_factor_detail,
                "recommendations": success_prediction.recommendations,
                "base_rate": success_prediction.base_rate,
                "n_ground_truth_matches": success_prediction.n_ground_truth_matches,
            }
        if task_context is not None:
            report["task_context"] = {
                "task_complexity_score": task_context.task_complexity_score,
                "dimension_complexity": task_context.dimension_complexity,
                "temporal_complexity": task_context.temporal_complexity,
                "coordination_complexity": task_context.coordination_complexity,
                "object_interaction_complexity": task_context.object_interaction_complexity,
                "trajectory_multimodality": task_context.trajectory_multimodality,
                "is_bimanual": task_context.is_bimanual,
                "action_dim": task_context.action_dim,
                "estimated_task_type": task_context.estimated_task_type,
            }
        if policy_fit_result is not None:
            report["policy_fit"] = {
                "policy_type": policy_fit_result.policy_type,
                "fit_score": policy_fit_result.fit_score,
                "episode_sufficiency": policy_fit_result.episode_sufficiency,
                "action_space_compatibility": policy_fit_result.action_space_compatibility,
                "consistency_compatibility": policy_fit_result.consistency_compatibility,
                "specific_warnings": policy_fit_result.specific_warnings,
                "recommended_policies": policy_fit_result.recommended_policies,
            }
        if community_comp is not None:
            from orbit.analyzer.community_comparison import comparison_to_dict

            report["community_comparison"] = comparison_to_dict(community_comp)
        if vlm_prediction is not None:
            report["ai_assessment"] = {
                "predicted_success_rate": vlm_prediction.predicted_success_rate,
                "confidence": vlm_prediction.confidence,
                "grade": vlm_prediction.grade,
                "reasoning": vlm_prediction.reasoning,
                "similar_datasets": vlm_prediction.similar_datasets,
                "key_strengths": vlm_prediction.key_strengths,
                "key_weaknesses": vlm_prediction.key_weaknesses,
                "improvement_estimate": vlm_prediction.improvement_estimate,
                "model_used": vlm_prediction.model_used,
                "tokens_used": vlm_prediction.tokens_used,
                "cost_estimate": vlm_prediction.cost_estimate,
            }
        click.echo(json.dumps(report, indent=2, default=_json_default))
        return

    _print_report(
        info,
        coverage,
        quality,
        assessment,
        recs,
        embedding_analysis=embedding_analysis,
        is_estimated=is_estimated,
        signal_diagnostics=signal_diag,
        vlm_prediction=vlm_prediction,
        success_prediction=success_prediction,
        task_context=task_context,
        policy_fit=policy_fit_result,
        community_comparison=community_comp,
    )


def _synthetic_coverage(info):
    """Generate synthetic coverage scores based on dataset metadata."""
    from orbit.analyzer.coverage import FullCoverageReport

    ep_factor = min(1.0, info.num_episodes / 50)
    return FullCoverageReport(
        position_diversity=min(1.0, 0.3 + ep_factor * 0.5),
        action_diversity=min(1.0, 0.2 + ep_factor * 0.5),
        episode_consistency=min(1.0, 0.5 + ep_factor * 0.4),
        temporal_coverage=min(1.0, 0.2 + ep_factor * 0.4),
    )


def _coverage_status(score: float) -> tuple[str, str]:
    """Return (status, label) for a coverage score."""
    if score >= 0.65:
        return "ok", "good"
    elif score >= 0.45:
        return "warn", "moderate"
    else:
        return "bad", "needs improvement"


def _score_color(score: float) -> str:
    if score >= 0.65:
        return "green"
    elif score >= 0.45:
        return "yellow"
    else:
        return "red"


def _verdict_color(verdict: str) -> str:
    if verdict == "YES":
        return "green"
    elif verdict == "NOT YET":
        return "yellow"
    else:
        return "red"


def _priority_style(priority: str) -> str:
    if priority == "HIGH":
        return "bold red"
    elif priority == "MEDIUM":
        return "bold yellow"
    else:
        return "dim"


def _info_to_dict(info) -> dict:
    """Convert DatasetInfo to a JSON-serializable dict."""
    from orbit.utils.display import format_duration

    return {
        "repo_id": info.repo_id,
        "num_episodes": info.num_episodes,
        "num_frames": info.num_frames,
        "fps": info.fps,
        "robot_type": info.robot_type,
        "camera_names": info.camera_names,
        "video_keys": info.video_keys,
        "shapes": info.shapes,
        "duration_seconds": info.duration_seconds,
        "duration_human": format_duration(info.duration_seconds),
    }


def _full_report_to_dict(
    info,
    coverage,
    quality,
    assessment,
    recs,
    embedding_analysis=None,
    signal_diagnostics=None,
) -> dict:
    """Convert the full analysis report to a JSON-serializable dict."""
    data = _info_to_dict(info)
    data["coverage"] = {
        "position_diversity": coverage.position_diversity,
        "action_diversity": coverage.action_diversity,
        "episode_consistency": coverage.episode_consistency,
        "temporal_coverage": coverage.temporal_coverage,
    }
    data["quality_score"] = quality.overall_score
    data["component_scores"] = quality.component_scores
    data["ready_to_train"] = quality.ready_to_train
    data["ready_to_train_verdict"] = assessment.verdict
    data["ready_to_train_reason"] = assessment.reason
    data["confidence"] = quality.confidence
    low, high = quality.estimated_success_rate
    data["estimated_success_rate"] = {
        "low": round(low, 2),
        "high": round(high, 2),
        "display": f"{low:.0%}-{high:.0%}",
    }
    data["recommendations"] = [
        {
            "priority": r.priority,
            "category": r.category,
            "description": r.description,
            "expected_impact": r.expected_impact,
            "effort": r.effort,
        }
        for r in recs
    ]
    data["blocking_issues"] = assessment.blocking_issues
    data["nice_to_haves"] = assessment.nice_to_haves

    if embedding_analysis is not None:
        data["embedding_analysis"] = {
            "n_clusters": embedding_analysis.n_clusters,
            "cluster_sizes": embedding_analysis.cluster_sizes,
            "visual_diversity": embedding_analysis.diversity_score,
            "outlier_episodes": embedding_analysis.outlier_indices,
            "insights": embedding_analysis.insights,
        }
        data["visual_diversity"] = embedding_analysis.diversity_score

    if signal_diagnostics is not None:
        data["signal_diagnostics"] = _signal_diag_to_dict(signal_diagnostics)

    return data


def _signal_diag_to_dict(sd) -> dict:
    """Convert a SignalDiagnosticsReport to a JSON-serializable dict."""
    return {
        "joint_diagnostics": [
            {
                "joint_index": jd.joint_index,
                "joint_name": jd.joint_name,
                "range_used": list(jd.range_used),
                "range_limit": list(jd.range_limit) if jd.range_limit else None,
                "range_utilization": round(jd.range_utilization, 4),
                "zero_velocity_ratio": round(jd.zero_velocity_ratio, 4),
                "smoothness": round(jd.smoothness, 4),
                "directional_bias": round(jd.directional_bias, 4),
                "is_dead": jd.is_dead,
                "is_clipping": jd.is_clipping,
                "issues": jd.issues,
            }
            for jd in sd.joint_diagnostics
        ],
        "gripper_analysis": {
            "gripper_dim": sd.gripper_analysis.gripper_dim,
            "open_ratio": round(sd.gripper_analysis.open_ratio, 4),
            "close_ratio": round(sd.gripper_analysis.close_ratio, 4),
            "transitions_per_episode": round(sd.gripper_analysis.transitions_per_episode, 2),
            "has_sufficient_grasps": sd.gripper_analysis.has_sufficient_grasps,
            "issues": sd.gripper_analysis.issues,
        },
        "episode_diagnostics": [
            {
                "episode_index": ed.episode_index,
                "quality_score": round(ed.quality_score, 4),
                "length": ed.length,
                "is_truncated": ed.is_truncated,
                "jerk_spike_count": ed.jerk_spike_count,
                "recommendation": ed.recommendation,
                "issues": ed.issues,
            }
            for ed in sd.episode_diagnostics
        ],
        "global_zero_velocity_ratio": round(sd.global_zero_velocity_ratio, 4),
        "dead_dimensions": sd.dead_dimensions,
        "episodes_to_remove": sd.episodes_to_remove,
        "episodes_to_review": sd.episodes_to_review,
        "blockers": sd.blockers,
        "warnings": sd.warnings,
        "passing": sd.passing,
        "prescription": sd.prescription,
    }


def _print_report(
    info,
    coverage,
    quality,
    assessment,
    recs,
    embedding_analysis=None,
    is_estimated=False,
    signal_diagnostics=None,
    vlm_prediction=None,
    success_prediction=None,
    task_context=None,
    policy_fit=None,
    community_comparison=None,
) -> None:
    """Print a formatted dataset report using Rich."""
    from orbit.utils.display import (
        console,
        format_duration,
        print_header,
        print_metric,
        print_section,
    )

    print_header(f"ORBIT Analysis: {info.repo_id}")

    if is_estimated:
        console.print(
            "\n[bold yellow]WARNING:[/bold yellow] Coverage analysis failed — "
            "showing estimated scores based on episode count only. "
            "Run with --embeddings for accurate results.\n"
        )

    # --- HEADLINE: Predicted Success Rate ---
    if success_prediction is not None:
        pred_pct = int(success_prediction.predicted_success_rate * 100)
        ci_high = int(success_prediction.confidence_interval[1] * 100)
        pred_color = _score_color(success_prediction.predicted_success_rate)
        policy_name = policy_fit.policy_type if policy_fit else "unknown"
        robot_name = info.robot_type or "robot"

        console.print()
        console.print(
            f"  [bold]PREDICTED SUCCESS RATE:[/bold] "
            f"[bold {pred_color}]{pred_pct}%[/bold {pred_color}] "
            f"[dim](±{ci_high - pred_pct}%)[/dim]"
        )
        console.print(f"  [dim]with {policy_name} policy on {robot_name}[/dim]")

        # Contributing factors
        console.print()
        console.print("  [bold]What's driving this prediction:[/bold]")
        for factor, contrib in success_prediction.contributing_factors.items():
            sign = "+" if contrib >= 0 else ""
            if factor == "Data Quality":
                detail = f"{quality.overall_score:.2f}"
                label = "Good" if quality.overall_score >= 0.65 else "Needs work"
            elif factor == "Task Difficulty":
                detail = f"{task_context.task_complexity_score:.2f}" if task_context else "?"
                label = task_context.estimated_task_type.title() if task_context else "?"
            elif factor == "Policy Fit":
                detail = f"{policy_fit.fit_score:.2f}" if policy_fit else "?"
                label = "Strong" if policy_fit and policy_fit.fit_score >= 0.65 else "Weak"
            elif factor == "Episode Count":
                detail = f"{policy_fit.episode_sufficiency:.2f}" if policy_fit else "?"
                label = (
                    "Sufficient" if policy_fit and policy_fit.episode_sufficiency >= 0.7 else "Low"
                )
            else:
                detail = ""
                label = ""
            console.print(
                f"  ├── {factor}: {detail} ({label}){'':>5}contributes {sign}{contrib:.1f}%"
            )
        console.print(
            f"  └── Base Rate (similar tasks): {success_prediction.base_rate:.0%} "
            f"[dim]({success_prediction.n_ground_truth_matches} matches)[/dim]"
        )

        # Limiting factor
        console.print()
        console.print(f"  [bold]LIMITING FACTOR:[/bold] {success_prediction.limiting_factor}")
        console.print(f"  [dim]{success_prediction.limiting_factor_detail}[/dim]")

        # Improvement recommendations
        if success_prediction.recommendations:
            console.print()
            console.print("  [bold]TO IMPROVE:[/bold]")
            for i, rec in enumerate(success_prediction.recommendations[:3], 1):
                console.print(f"  {i}. {rec}")

        console.print()

    # --- Overview ---
    print_section("Overview")

    camera_list = ", ".join(info.camera_names) if info.camera_names else "none"
    num_cameras = len(info.camera_names)

    dur = format_duration(info.duration_seconds)
    print_metric(
        "Episodes",
        f"{info.num_episodes:,} | Frames: {info.num_frames:,} | Duration: {dur}",
    )
    print_metric("Robot", info.robot_type)
    print_metric("Cameras", f"{num_cameras} ({camera_list})")
    print_metric(
        "FPS",
        str(int(info.fps) if info.fps == int(info.fps) else info.fps),
    )

    # --- Coverage Analysis ---
    estimated_suffix = " (estimated)" if is_estimated else ""
    print_section(f"Coverage Analysis{estimated_suffix}")

    coverage_items = [
        ("Position diversity", coverage.position_diversity),
        ("Action diversity", coverage.action_diversity),
        ("Episode consistency", coverage.episode_consistency),
        ("Temporal coverage", coverage.temporal_coverage),
    ]
    for name, score in coverage_items:
        status, label = _coverage_status(score)
        print_metric(
            f"{name}",
            f"{score:.2f} ({label}){estimated_suffix}",
            status=status,
        )

    # --- Embedding Analysis ---
    if embedding_analysis is not None:
        print_section("Visual Embedding Analysis (SigLIP)")

        n_frames = sum(embedding_analysis.cluster_sizes)
        noise_count = (
            int(sum(1 for label in embedding_analysis.cluster_labels if label == -1))
            if len(embedding_analysis.cluster_labels) > 0
            else 0
        )
        total_frames = n_frames + noise_count

        console.print(f"  Frames analyzed: {total_frames}")

        console.print(f"  Clusters detected: {embedding_analysis.n_clusters}")
        for i, size in enumerate(embedding_analysis.cluster_sizes):
            console.print(f"    Cluster {i + 1}: {size} frames")

        div = embedding_analysis.diversity_score
        div_status, div_label = _coverage_status(div)
        print_metric("Visual diversity", f"{div:.2f} ({div_label})", status=div_status)

        if embedding_analysis.outlier_indices:
            ep_str = ", ".join(str(e) for e in embedding_analysis.outlier_indices[:10])
            console.print(
                f"  Outlier episodes: {len(embedding_analysis.outlier_indices)} "
                f"(episodes {ep_str} — review recommended)"
            )

        if embedding_analysis.insights:
            console.print()
            console.print("  [bold]Insights:[/bold]")
            for insight in embedding_analysis.insights:
                console.print(f"    [dim]-> {insight}[/dim]")

    # --- Signal Diagnostics ---
    if signal_diagnostics is not None:
        _print_signal_diagnostics(signal_diagnostics)

    # --- AI Assessment ---
    if vlm_prediction is not None:
        print_section("AI Assessment")
        pred_pct = vlm_prediction.predicted_success_rate * 100
        grade_color = _score_color(vlm_prediction.predicted_success_rate)
        console.print(
            f"  [bold]Predicted Success Rate:[/bold] "
            f"[{grade_color}]{pred_pct:.0f}% (Grade: {vlm_prediction.grade})[/{grade_color}]"
        )
        conf_pct = vlm_prediction.confidence * 100
        console.print(f"  [bold]Confidence:[/bold] {conf_pct:.0f}%")
        console.print(f"  [bold]Reasoning:[/bold] {vlm_prediction.reasoning}")

        if vlm_prediction.similar_datasets:
            console.print("\n  [bold]Similar Datasets:[/bold]")
            for sd in vlm_prediction.similar_datasets[:3]:
                name = sd.get("id", sd.get("dataset", "unknown"))
                rate = sd.get("success_rate", "?")
                why = sd.get("why_similar", "")
                console.print(f"    [dim]- {name} ({rate}) {why}[/dim]")

        if vlm_prediction.key_strengths:
            console.print("\n  [bold green]Strengths:[/bold green]")
            for s in vlm_prediction.key_strengths:
                console.print(f"    [green]\u2713[/green] {s}")

        if vlm_prediction.key_weaknesses:
            console.print("\n  [bold red]Weaknesses:[/bold red]")
            for w in vlm_prediction.key_weaknesses:
                console.print(f"    [red]\u2717[/red] {w}")

        if vlm_prediction.improvement_estimate:
            console.print(f"\n  [bold]Improvement:[/bold] {vlm_prediction.improvement_estimate}")

        model_info = vlm_prediction.model_used
        if vlm_prediction.cost_estimate > 0:
            model_info += f" (${vlm_prediction.cost_estimate:.4f})"
        console.print(f"  [dim]Model: {model_info}[/dim]")

        if vlm_prediction.model_used == "heuristic":
            console.print(
                "\n  [dim]AI assessment unavailable \u2014 set GOOGLE_API_KEY or "
                "ANTHROPIC_API_KEY for VLM-powered predictions. Using heuristic estimate.[/dim]"
            )

    # --- Quality Score ---
    console.print()
    color = _score_color(quality.overall_score)
    _, label = _coverage_status(quality.overall_score)

    if vlm_prediction is not None and vlm_prediction.model_used != "heuristic":
        # Show both AI and heuristic scores
        ai_pct = vlm_prediction.predicted_success_rate * 100
        console.print(
            f"[bold]AI Predicted:[/bold] [{_score_color(vlm_prediction.predicted_success_rate)}]"
            f"{ai_pct:.0f}%[/{_score_color(vlm_prediction.predicted_success_rate)}]  "
            f"[bold]Heuristic Score:[/bold] [{color}]{quality.overall_score:.2f}[/{color}]"
        )
    else:
        console.print(
            f"[bold]Quality Score:[/bold] "
            f"[{color}]{quality.overall_score:.2f} / 1.00[/{color}] "
            f"({label})"
        )

    # --- Ready to Train ---
    v_color = _verdict_color(assessment.verdict)
    console.print(f"[bold]Ready to Train?[/bold] [{v_color}]{assessment.verdict}[/{v_color}]")

    # --- Estimated Success Rate ---
    low, high = quality.estimated_success_rate
    console.print(
        f"[bold]Estimated Success Rate:[/bold] "
        f"{low:.0%}-{high:.0%} ({quality.confidence} confidence)"
    )

    # --- Recommendations ---
    if recs:
        print_section("Recommendations (ranked by expected impact)")
        console.print()
        for rec in recs:
            style = _priority_style(rec.priority)
            console.print(f"  [{style}][{rec.priority}][/{style}] {rec.description}")
            console.print(
                f"  [dim]→ Expected quality improvement: +{rec.expected_impact:.2f}[/dim]"
            )
            console.print()

    # --- Community Comparison ---
    if community_comparison is not None:
        comp = community_comparison
        print_section("Community Comparison")
        console.print()

        if comp.similar_successful:
            console.print("  [bold]Similar datasets that achieved >70% success:[/bold]")
            for p in comp.similar_successful:
                console.print(
                    f"    \u2022 {p.dataset}: {p.num_episodes} eps, "
                    f"{p.success_rate:.0%} success ({p.policy})"
                )
            console.print()

        # Your dataset vs peers
        console.print("  [bold]Your dataset vs peers:[/bold]")
        console.print(
            f"    Episodes:  {comp.your_episodes} (you) vs "
            f"{comp.peer_avg_episodes:.0f} avg ({comp.your_episode_percentile})"
        )
        if comp.your_coverage is not None:
            console.print(
                f"    Quality:   {comp.your_coverage:.2f} (you)"
            )
        console.print()

        if comp.similar_all and not comp.similar_successful:
            console.print("  [dim]No similar datasets with >70% success found.[/dim]")
            best = max(comp.similar_all, key=lambda p: p.success_rate)
            console.print(
                f"  [dim]Best match: {best.dataset} at {best.success_rate:.0%} "
                f"({best.policy})[/dim]"
            )
            console.print()

        console.print(f"  [bold cyan]\u27a4[/bold cyan] {comp.actionable_tip}")
        console.print()

    console.print("[dim]Run orbit plan to generate a full collection playbook.[/dim]\n")


def _print_signal_diagnostics(sd) -> None:
    """Print the signal diagnostics section of the report."""
    from orbit.utils.display import console, print_metric, print_section

    print_section("Signal Diagnostics")

    # Per-joint health
    for jd in sd.joint_diagnostics:
        if jd.is_dead:
            status, icon = "bad", "[red]\u2717 CRITICAL[/red]"
        elif jd.issues:
            status, icon = "warn", "[yellow]\u26a0 WARNING[/yellow]"
        else:
            status, icon = "ok", "[green]\u2713 HEALTHY[/green]"

        name = jd.joint_name or f"joint_{jd.joint_index}"
        detail = f"vel={1 - jd.zero_velocity_ratio:.0%} smooth={jd.smoothness:.2f}"
        print_metric(name, f"{icon}  {detail}", status=status)

    # Episode quality
    num_eps = len(sd.episode_diagnostics)
    good = sum(1 for e in sd.episode_diagnostics if e.recommendation == "keep")
    remove_eps = sd.episodes_to_remove
    review_eps = sd.episodes_to_review
    if remove_eps or review_eps:
        flagged = []
        if remove_eps:
            flagged.append(f"{len(remove_eps)} to remove")
        if review_eps:
            flagged.append(f"{len(review_eps)} to review")
        ep_str = ", ".join(str(e) for e in (remove_eps + review_eps)[:8])
        suffix = "..." if len(remove_eps) + len(review_eps) > 8 else ""
        console.print(
            f"\n  Episodes: {good}/{num_eps} good, {', '.join(flagged)} (episodes {ep_str}{suffix})"
        )
    else:
        console.print(f"\n  Episodes: {good}/{num_eps} good")

    # Gripper
    ga = sd.gripper_analysis
    if ga.gripper_dim is not None:
        grip_status = "[green]\u2713[/green]" if ga.has_sufficient_grasps else "[red]\u2717[/red]"
        console.print(
            f"  {grip_status} Gripper (dim {ga.gripper_dim}): "
            f"{ga.transitions_per_episode:.1f} transitions/ep, "
            f"open {ga.open_ratio:.0%} / close {ga.close_ratio:.0%}"
        )
    else:
        console.print("  [dim]No gripper dimension detected[/dim]")

    # Blockers / Warnings / Passing
    if sd.blockers:
        console.print("\n  [bold red]Blockers:[/bold red]")
        for b in sd.blockers:
            console.print(f"    [red]\u2717[/red] {b}")

    if sd.warnings:
        console.print("\n  [bold yellow]Warnings:[/bold yellow]")
        for w in sd.warnings:
            console.print(f"    [yellow]\u26a0[/yellow] {w}")

    if sd.passing:
        console.print("\n  [bold green]Passing:[/bold green]")
        for p in sd.passing:
            console.print(f"    [green]\u2713[/green] {p}")

    # Prescription
    if sd.prescription:
        console.print("\n  [bold]Prescription:[/bold]")
        for i, rx in enumerate(sd.prescription, 1):
            console.print(f"    {i}. {rx}")


@main.command()
@click.argument("task_description")
@click.option("--robot", default="so100", help="Robot type (so100, so101, koch, aloha).")
@click.option("--policy", default="act", help="Policy type (act, diffusion_policy, smolvla).")
@click.option("--save", "save_path", default=None, help="Save plan to JSON file.")
@click.option("--format", "fmt", default=None, type=click.Choice(["json"]), help="Output format.")
def plan(task_description: str, robot: str, policy: str, save_path: str | None, fmt: str | None):
    """Plan data collection strategy."""
    from orbit.planner.playbook import generate_playbook
    from orbit.utils.display import console

    playbook = generate_playbook(task_description, robot, policy)

    if save_path:
        playbook.save(save_path)
        console.print(f"\n[green]Plan saved to {save_path}[/green]")

    if fmt == "json":
        click.echo(json.dumps(playbook.to_dict(), indent=2))
        return

    _print_playbook(playbook)


def _print_playbook(playbook) -> None:
    """Print a formatted playbook using Rich."""
    from orbit.utils.display import console, print_header, print_section

    print_header("ORBIT Data Collection Playbook")

    console.print(f"\n[bold]Task:[/bold] {playbook.task_description}")
    console.print(f"[bold]Task type:[/bold] {playbook.task_type}")
    console.print(f"[bold]Robot:[/bold] {playbook.robot_type}")
    console.print(f"[bold]Policy:[/bold] {playbook.policy_type}")
    console.print(f"[bold]Total target episodes:[/bold] {playbook.total_target_episodes}")

    # Robot-specific tips
    if playbook.robot_config:
        print_section("Robot Setup")
        rc = playbook.robot_config
        dims = rc.workspace_dims
        console.print(f"  Workspace: {dims[0]}m x {dims[1]}m x {dims[2]}m")
        console.print(f"  Camera: {rc.recommended_camera_position}")
        res = rc.recommended_resolution
        console.print(f"  FPS: {rc.recommended_fps}  |  Resolution: {res[0]}x{res[1]}")
        console.print(f"  Arms: {rc.arm_count}")
        console.print(f"  [dim]{rc.notes}[/dim]")

    # Phases
    for i, phase in enumerate(playbook.phases, 1):
        print_section(f"Phase {i}: {phase.name} ({phase.target_episodes} episodes)")
        for req_name, req_desc in phase.requirements.items():
            label = req_name.replace("_", " ").title()
            console.print(f"  [green]\u2713[/green] {label}: [bold]{req_desc}[/bold]")

    # Estimates
    print_section("Estimates")
    console.print(f"  80% success rate: {playbook.estimates.eighty_percent_success}")
    console.print(f"  95% success rate: {playbook.estimates.ninety_five_percent_success}")

    # Policy notes
    if playbook.policy_notes:
        print_section("Policy Notes")
        for note in playbook.policy_notes:
            console.print(f"  [dim]\u2022 {note}[/dim]")

    console.print()


@main.command()
@click.argument("query", required=False, default=None)
@click.option("--task", default=None, help="Filter by task type (pick_and_place, insertion, pushing, etc.).")
@click.option("--policy", "policy_filter", default=None, help="Filter by policy (act, diffusion_policy, bc, etc.).")
@click.option("--min-success", type=float, default=None, help="Only show entries with success rate >= this value.")
@click.option("--max-success", type=float, default=None, help="Only show entries with success rate <= this value.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--top", type=int, default=None, help="Show only top N entries by success rate.")
def benchmark(
    query: str | None,
    task: str | None,
    policy_filter: str | None,
    min_success: float | None,
    max_success: float | None,
    as_json: bool,
    top: int | None,
):
    """Browse the benchmark database of 82 validated results.

    Search by keyword, filter by task type or policy, or browse all entries.

    Examples:

      orbit benchmark                     # show all 82 entries
      orbit benchmark aloha               # search for 'aloha' entries
      orbit benchmark --task insertion     # filter by task type
      orbit benchmark --policy act --top 5 # top 5 ACT results
      orbit benchmark --min-success 0.8    # only high-performing entries
    """
    from orbit.utils.display import console

    # Load ground truth
    from pathlib import Path

    gt_path = Path(__file__).parent / "analyzer" / "data" / "ground_truth_condensed.json"
    try:
        with open(gt_path) as f:
            entries = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        console.print(f"[bold red]Error:[/bold red] Could not load benchmark data: {e}")
        sys.exit(1)

    # Apply filters
    filtered = entries

    if query:
        q = query.lower()
        filtered = [
            e for e in filtered
            if q in e.get("id", "").lower()
            or q in e.get("dataset", "").lower()
            or q in e.get("task_type", "").lower()
            or q in e.get("policy", "").lower()
            or q in e.get("features_summary", "").lower()
        ]

    if task:
        t = task.lower()
        filtered = [e for e in filtered if t in e.get("task_type", "").lower()]

    if policy_filter:
        p = policy_filter.lower()
        filtered = [e for e in filtered if p in e.get("policy", "").lower()]

    if min_success is not None:
        filtered = [e for e in filtered if e.get("success_rate", 0) >= min_success]

    if max_success is not None:
        filtered = [e for e in filtered if e.get("success_rate", 1) <= max_success]

    # Sort by success rate descending
    filtered.sort(key=lambda e: e.get("success_rate", 0), reverse=True)

    if top:
        filtered = filtered[:top]

    if not filtered:
        if as_json:
            click.echo(json.dumps([]))
        else:
            console.print("[yellow]No matching benchmark entries found.[/yellow]")
            if query:
                console.print(f"[dim]Search query: '{query}'[/dim]")
        return

    if as_json:
        click.echo(json.dumps(filtered, indent=2))
        return

    _print_benchmark_table(filtered, len(entries), query=query, task=task, policy=policy_filter)


def _print_benchmark_table(
    entries: list[dict],
    total: int,
    query: str | None = None,
    task: str | None = None,
    policy: str | None = None,
) -> None:
    """Print benchmark entries as a formatted table."""
    from pathlib import Path

    from orbit.utils.display import console, print_header

    # Header
    filter_desc = []
    if query:
        filter_desc.append(f"query='{query}'")
    if task:
        filter_desc.append(f"task={task}")
    if policy:
        filter_desc.append(f"policy={policy}")
    filter_str = f" ({', '.join(filter_desc)})" if filter_desc else ""

    print_header(f"ORBIT Benchmark Database — {len(entries)}/{total} entries{filter_str}")

    # Group by task type for readability
    task_groups: dict[str, list[dict]] = {}
    for e in entries:
        tt = e.get("task_type", "unknown")
        task_groups.setdefault(tt, []).append(e)

    for task_type, group in task_groups.items():
        console.print(f"\n  [bold]{task_type.replace('_', ' ').title()}[/bold] ({len(group)} entries)")
        console.print(f"  {'─' * 90}")

        for e in group:
            rate = e.get("success_rate", 0)
            if rate >= 0.80:
                color = "green"
            elif rate >= 0.50:
                color = "yellow"
            else:
                color = "red"

            eps = e.get("num_episodes", "?")
            eps_str = f"{eps:>6,}" if isinstance(eps, int) else f"{eps:>6}"

            console.print(
                f"  [{color}]{rate:5.0%}[/{color}]  "
                f"{e.get('id', '?'):<42} "
                f"policy={e.get('policy', '?'):<20} "
                f"eps={eps_str}"
            )

    # Summary stats
    rates = [e.get("success_rate", 0) for e in entries]
    console.print(f"\n  [dim]Success rate range: {min(rates):.0%} – {max(rates):.0%} | "
                  f"Median: {sorted(rates)[len(rates)//2]:.0%} | "
                  f"Mean: {sum(rates)/len(rates):.0%}[/dim]")

    # Available task types
    all_tasks = sorted(set(e.get("task_type", "") for e in entries))
    all_policies = sorted(set(e.get("policy", "") for e in entries))
    console.print(f"  [dim]Task types: {', '.join(all_tasks)}[/dim]")
    console.print(f"  [dim]Policies: {', '.join(all_policies)}[/dim]")
    console.print()


@main.command()
@click.argument("plan_file")
@click.option("--dataset", required=True, help="HuggingFace dataset repo ID.")
def track(plan_file: str, dataset: str):
    """Track training progress against a collection plan."""
    from orbit.analyzer.coverage import compute_coverage
    from orbit.analyzer.dataset_loader import load_dataset_info, load_episode_data
    from orbit.tracker.progress import compute_progress, load_plan_from_file
    from orbit.utils.display import console

    # Load the plan
    try:
        playbook = load_plan_from_file(plan_file)
    except FileNotFoundError:
        console.print(
            f"\n[bold red]Error:[/bold red] Plan file not found: {plan_file}\n"
            f"Run [bold]orbit plan[/bold] first to create one."
        )
        sys.exit(1)
    except (json.JSONDecodeError, KeyError, ValueError) as e:
        console.print(f"\n[bold red]Error:[/bold red] Invalid plan file: {e}")
        sys.exit(1)

    # Load dataset info
    try:
        info = load_dataset_info(dataset)
    except (ValueError, ConnectionError) as e:
        console.print(f"\n[bold red]Error:[/bold red] {e}")
        sys.exit(1)

    # Load episode data for coverage analysis
    try:
        episode_data = load_episode_data(dataset)
    except (ValueError, ConnectionError):
        episode_data = None

    # Compute coverage
    is_estimated = False
    if episode_data is not None and not episode_data.empty:
        coverage = compute_coverage(info, episode_data)
    else:
        coverage = _synthetic_coverage(info)
        is_estimated = True

    # Compute progress
    report = compute_progress(playbook, info, coverage)

    _print_tracking_report(report, playbook, dataset, is_estimated=is_estimated)


def _print_tracking_report(
    report,
    playbook,
    dataset: str,
    is_estimated: bool = False,
) -> None:
    """Print a formatted tracking report using Rich."""
    from orbit.utils.display import console, print_header, print_section

    print_header("ORBIT Progress Tracker")

    if is_estimated:
        console.print(
            "\n[bold yellow]WARNING:[/bold yellow] Coverage analysis failed — "
            "showing estimated scores based on episode count only. "
            "Run with --embeddings for accurate results.\n"
        )

    console.print(f"\n[bold]Plan:[/bold] {playbook.task_description}")
    console.print(f"[bold]Dataset:[/bold] {dataset}")

    # Progress bar
    filled = int(report.progress_percent / 100 * 16)
    bar = "\u2588" * filled + "\u2591" * (16 - filled)
    console.print(
        f"\n[bold]Episode Progress:[/bold] {bar} "
        f"{report.current_episodes}/{report.total_target_episodes} "
        f"({report.progress_percent:.0f}%)"
    )

    phase_display = "Core demonstrations" if report.phase == "core" else "Diversity expansion"
    console.print(f"[bold]Phase:[/bold] {phase_display}")

    # Coverage checklist
    print_section("Coverage Checklist")
    for item in report.coverage_checklist:
        if item.status == "complete":
            icon = "[green]\u2713[/green]"
        elif item.status == "in_progress":
            icon = "[yellow]\u25cb[/yellow]"
        else:
            icon = "[red]\u2717[/red]"

        if item.name == "Near-failure recoveries":
            console.print(
                f"  {icon} {item.name:<30} "
                f"({int(item.current)} found \u2014 target: {int(item.target)})"
            )
        else:
            console.print(
                f"  {icon} {item.name:<30} ({item.current:.2f} \u2014 target: {item.target:.2f})"
            )

    # Ready to train
    if report.ready_to_train:
        console.print("\n[bold]Ready to Train?[/bold] [bold green]YES[/bold green]")
    else:
        console.print("\n[bold]Ready to Train?[/bold] [bold yellow]NOT YET[/bold yellow]")

    # Next session priorities
    if report.next_session_priorities:
        print_section("Next Session Priorities")
        for i, priority in enumerate(report.next_session_priorities, 1):
            console.print(f"  {i}. {priority}")

    console.print()
