"""Calibrated success predictor — multi-factor model for predicting policy success rate.

Combines data quality, task context, and policy fit with ground truth calibration
to produce an honest prediction with confidence intervals.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from orbit.analyzer.policy_fit import PolicyFit
from orbit.analyzer.task_context import TaskContext

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class SuccessPrediction:
    """Predicted policy success rate with supporting analysis."""

    predicted_success_rate: float  # 0-1, THE headline number
    confidence_interval: tuple[float, float]  # (low, high)
    contributing_factors: dict[str, float]  # factor -> contribution (can be negative)
    limiting_factor: str  # what's holding success back the most
    limiting_factor_detail: str  # explanation of the limiting factor
    recommendation: str  # what would improve success rate the most
    recommendations: list[str]  # ordered list of improvements
    grade: str  # A/B/C/D/F
    base_rate: float  # base rate from ground truth matches
    n_ground_truth_matches: int  # how many GT entries informed this
    ground_truth_range: tuple[float, float]  # (min, max) of matched GT success rates


# ---------------------------------------------------------------------------
# Ground truth loading (shared with vlm_predictor)
# ---------------------------------------------------------------------------

GROUND_TRUTH_PATH = Path(__file__).parent / "data" / "ground_truth_condensed.json"
_ground_truth_cache: list[dict] | None = None


def _load_ground_truth() -> list[dict]:
    """Load ground truth data, caching after first call."""
    global _ground_truth_cache
    if _ground_truth_cache is not None:
        return _ground_truth_cache
    try:
        with open(GROUND_TRUTH_PATH) as f:
            _ground_truth_cache = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.warning("Failed to load ground truth data: %s", e)
        _ground_truth_cache = []
    return _ground_truth_cache


def _find_matching_entries(
    ground_truth: list[dict],
    task_type: str | None = None,
    policy_type: str | None = None,
    is_bimanual: bool = False,
    action_dim: int | None = None,
    episode_count: int | None = None,
) -> list[dict]:
    """Find ground truth entries that match the current dataset characteristics.

    Returns entries sorted by relevance score (most relevant first).
    Policy matching is weighted heavily — same task with different policy
    can have wildly different success rates.
    """
    if not ground_truth:
        return []

    scored: list[tuple[float, dict]] = []
    task_type_lower = (task_type or "").lower()
    policy_lower = (policy_type or "").lower()

    # Normalize policy families for matching
    def _policy_family(p: str) -> str:
        p = p.lower()
        if "diffusion" in p:
            return "diffusion"
        elif p in ("act",):
            return "act"
        elif "bc_rnn" in p or "bcrnn" in p:
            return "bc_rnn"
        elif p in ("bc", "behavioral_cloning"):
            return "bc"
        elif "rt1" in p:
            return "rt1"
        elif "octo" in p:
            return "octo"
        return p

    query_family = _policy_family(policy_lower)

    for entry in ground_truth:
        score = 0.0
        entry_task = entry.get("task_type", "").lower()
        entry_policy = entry.get("policy", "").lower()
        entry_summary = entry.get("features_summary", "").lower()
        entry_episodes = entry.get("num_episodes", 0)
        entry_family = _policy_family(entry_policy)

        # Task type matching (important)
        if task_type_lower and task_type_lower in entry_task:
            score += 4.0
        elif task_type_lower and any(
            w in entry_task for w in task_type_lower.split("_") if len(w) > 2
        ):
            score += 1.5

        # Policy matching (MOST important — same task, different policy = huge difference)
        if query_family and query_family == entry_family:
            score += 6.0  # Strong boost for same policy family
        elif policy_lower and policy_lower in entry_policy:
            score += 4.0
        elif query_family:
            # Partial match within similar policy categories
            similar_groups = [
                {"bc", "bc_rnn"},  # BC family
                {"diffusion", "dp3"},  # Diffusion family
                {"act"},  # ACT is its own thing
            ]
            for group in similar_groups:
                if query_family in group and entry_family in group:
                    score += 2.0
                    break

        # Bimanual matching
        if is_bimanual and "bimanual" in entry_summary:
            score += 2.0
        elif not is_bimanual and "bimanual" not in entry_summary:
            score += 0.5

        # Demo quality matching
        if "multi human" in entry_summary or "multi_human" in entry_summary:
            score += 0.5  # slight boost for multi-human entries (common scenario)

        # Episode count similarity (log scale)
        if episode_count and entry_episodes:
            ratio = min(episode_count, entry_episodes) / max(episode_count, entry_episodes)
            score += ratio * 1.0

        if score > 0:
            scored.append((score, entry))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [entry for _, entry in scored[:15]]


# ---------------------------------------------------------------------------
# Grade mapping
# ---------------------------------------------------------------------------


def _grade_from_score(score: float) -> str:
    """Map a predicted success rate to a letter grade."""
    if score >= 0.80:
        return "A"
    elif score >= 0.65:
        return "B"
    elif score >= 0.50:
        return "C"
    elif score >= 0.35:
        return "D"
    else:
        return "F"


# ---------------------------------------------------------------------------
# Main predictor
# ---------------------------------------------------------------------------


class CalibratedSuccessPredictor:
    """Predicts policy success rate using all available signals."""

    def __init__(self):
        self._ground_truth = _load_ground_truth()

    def predict(
        self,
        data_quality: float,
        task_context: TaskContext,
        policy_fit: PolicyFit,
        signal_diagnostics: dict | None = None,
        embedding_diversity: float | None = None,
        task_type: str | None = None,
        episode_count: int | None = None,
    ) -> SuccessPrediction:
        """Predict policy success rate from all available signals.

        Args:
            data_quality: Overall data quality score (0-1).
            task_context: Task complexity analysis.
            policy_fit: Policy-data fit analysis.
            signal_diagnostics: Optional dict with 'blockers', 'warnings', 'dead_dimensions'.
            embedding_diversity: Optional visual diversity score (0-1).
            task_type: Optional task type string for GT matching.
            episode_count: Optional override for episode count.

        Returns:
            SuccessPrediction with predicted rate and supporting analysis.
        """
        signal_diagnostics = signal_diagnostics or {}

        # Step 1: Find ground truth base rate
        matches = _find_matching_entries(
            self._ground_truth,
            task_type=task_type,
            policy_type=policy_fit.policy_type,
            is_bimanual=task_context.is_bimanual,
            action_dim=task_context.action_dim,
            episode_count=episode_count,
        )

        if matches:
            gt_rates = [e["success_rate"] for e in matches]
            # Weighted average: closer matches (first in list) get more weight
            weights = np.array([1.0 / (i + 1) for i in range(len(gt_rates))])
            weights = weights / weights.sum()
            base_rate = float(np.average(gt_rates, weights=weights))
            gt_min, gt_max = float(min(gt_rates)), float(max(gt_rates))
        else:
            base_rate = 0.60  # Neutral prior
            gt_min, gt_max = 0.3, 0.9

        n_matches = len(matches)

        # Step 2: Compute adjustments from each factor

        # Data quality adjustment: quality relative to average (0.65 assumed average)
        quality_delta = (data_quality - 0.65) * 0.35
        quality_contribution = quality_delta

        # Task complexity adjustment: harder tasks lower the prediction
        # Map complexity to a penalty: 0.0 complexity -> +3%, 1.0 complexity -> -25%
        complexity_delta = 0.03 - task_context.task_complexity_score * 0.28
        task_contribution = complexity_delta

        # Policy fit adjustment: good fit boosts, BAD fit penalizes HEAVILY
        # This is critical: BC on a hard multimodal task should be crushed
        if policy_fit.fit_score >= 0.6:
            policy_delta = (policy_fit.fit_score - 0.60) * 0.20
        else:
            # Strong penalty for poor fit — exponential dropoff
            policy_delta = (policy_fit.fit_score - 0.60) * 0.50
        policy_contribution = policy_delta

        # Episode sufficiency adjustment
        ep_suff_delta = (policy_fit.episode_sufficiency - 0.70) * 0.15
        episode_contribution = ep_suff_delta

        # Signal diagnostics penalty
        # Blockers (dead joints, high removal ratio) are severe; warnings
        # (directional bias, clipping) are mild.  Previous calibration
        # over-penalised warnings — 13 directional-bias warnings alone
        # produced a -42% swing.  Cap total warning contribution and overall
        # penalty so that signal health cannot dominate the prediction.
        signal_penalty = 0.0
        blockers = signal_diagnostics.get("blockers", [])
        warnings = signal_diagnostics.get("warnings", [])
        dead_dims = signal_diagnostics.get("dead_dimensions", [])

        if blockers:
            signal_penalty += len(blockers) * 0.10
        if warnings:
            # Diminishing returns: first few warnings matter, rest are noise
            warning_penalty = min(len(warnings), 5) * 0.025
            signal_penalty += warning_penalty
        if dead_dims:
            signal_penalty += len(dead_dims) * 0.12

        signal_penalty = min(0.20, signal_penalty)  # Cap total penalty at 20%
        signal_contribution = -signal_penalty

        # Embedding diversity bonus/penalty
        diversity_contribution = 0.0
        if embedding_diversity is not None:
            diversity_contribution = (embedding_diversity - 0.50) * 0.10

        # Step 3: Combine into prediction
        predicted = base_rate + (
            quality_contribution
            + task_contribution
            + policy_contribution
            + episode_contribution
            + signal_contribution
            + diversity_contribution
        )

        # Clamp to ground truth range when we have good matches
        # This prevents wild over/under predictions
        if n_matches >= 3:
            # Allow some room beyond the GT range, but not too much
            range_margin = 0.10
            predicted = float(
                np.clip(
                    predicted,
                    max(0.0, gt_min - range_margin),
                    min(1.0, gt_max + range_margin),
                )
            )

        predicted = float(np.clip(predicted, 0.0, 1.0))

        # Step 4: Confidence interval
        # Wider when we have fewer GT matches, higher task complexity, or signal issues
        base_width = 0.10
        if n_matches < 3:
            base_width += 0.08
        elif n_matches < 8:
            base_width += 0.04

        if task_context.task_complexity_score > 0.7:
            base_width += 0.05

        if signal_penalty > 0.1:
            base_width += 0.05

        ci_low = max(0.0, predicted - base_width)
        ci_high = min(1.0, predicted + base_width)

        # Step 5: Identify limiting factor
        contributions = {
            "Data Quality": quality_contribution,
            "Task Difficulty": task_contribution,
            "Policy Fit": policy_contribution,
            "Episode Count": episode_contribution,
            "Signal Health": signal_contribution,
        }
        if embedding_diversity is not None:
            contributions["Visual Diversity"] = diversity_contribution

        # Limiting factor = most negative contribution
        limiting_factor = min(contributions, key=contributions.get)
        limiting_detail = _explain_limiting_factor(
            limiting_factor,
            task_context,
            policy_fit,
            data_quality,
            signal_diagnostics,
            embedding_diversity,
        )

        # Step 6: Generate recommendations
        recs = _generate_recommendations(
            contributions,
            task_context,
            policy_fit,
            data_quality,
            signal_diagnostics,
            episode_count,
        )

        # Contributing factors as percentages
        factor_display = {}
        for name, val in contributions.items():
            factor_display[name] = round(val * 100, 1)  # as percentage points

        return SuccessPrediction(
            predicted_success_rate=round(predicted, 3),
            confidence_interval=(round(ci_low, 3), round(ci_high, 3)),
            contributing_factors=factor_display,
            limiting_factor=limiting_factor,
            limiting_factor_detail=limiting_detail,
            recommendation=recs[0] if recs else "Data looks good for training",
            recommendations=recs,
            grade=_grade_from_score(predicted),
            base_rate=round(base_rate, 3),
            n_ground_truth_matches=n_matches,
            ground_truth_range=(round(gt_min, 3), round(gt_max, 3)),
        )


def _explain_limiting_factor(
    factor: str,
    task_context: TaskContext,
    policy_fit: PolicyFit,
    data_quality: float,
    signal_diagnostics: dict,
    embedding_diversity: float | None,
) -> str:
    """Generate a human-readable explanation of the limiting factor."""
    if factor == "Task Difficulty":
        return (
            f"Task complexity score is {task_context.task_complexity_score:.2f} "
            f"({task_context.estimated_task_type}). "
            f"Action dim: {task_context.action_dim}, "
            f"{'bimanual' if task_context.is_bimanual else 'single-arm'}. "
            f"This limits achievable success rate regardless of data quality."
        )
    elif factor == "Policy Fit":
        warnings = (
            "; ".join(policy_fit.specific_warnings[:2])
            if policy_fit.specific_warnings
            else "suboptimal fit"
        )
        return (
            f"Policy fit score is {policy_fit.fit_score:.2f} for {policy_fit.policy_type}. "
            f"Issues: {warnings}"
        )
    elif factor == "Data Quality":
        return (
            f"Data quality score is {data_quality:.2f}. "
            f"Improving smoothness, consistency, or coverage would help."
        )
    elif factor == "Episode Count":
        return (
            f"Episode sufficiency is {policy_fit.episode_sufficiency:.2f}. "
            "More demonstrations would improve learning, especially for "
            + (
                "this complex task."
                if task_context.task_complexity_score > 0.5
                else "reliable training."
            )
        )
    elif factor == "Signal Health":
        blockers = signal_diagnostics.get("blockers", [])
        dead = signal_diagnostics.get("dead_dimensions", [])
        issues = []
        if dead:
            issues.append(f"{len(dead)} dead joint(s)")
        if blockers:
            issues.append(f"{len(blockers)} blocker(s)")
        return (
            f"Signal health issues detected: "
            f"{', '.join(issues) if issues else 'warnings present'}. "
            f"Fix hardware/collection issues before training."
        )
    elif factor == "Visual Diversity":
        return (
            f"Visual diversity is {embedding_diversity:.2f}. "
            f"Collect demonstrations in more varied visual conditions."
        )
    return f"{factor} is the current bottleneck."


def _generate_recommendations(
    contributions: dict[str, float],
    task_context: TaskContext,
    policy_fit: PolicyFit,
    data_quality: float,
    signal_diagnostics: dict,
    episode_count: int | None,
) -> list[str]:
    """Generate specific, actionable recommendations ordered by impact."""
    recs: list[tuple[float, str]] = []

    # Signal health is always most urgent if there are blockers
    blockers = signal_diagnostics.get("blockers", [])
    dead_dims = signal_diagnostics.get("dead_dimensions", [])
    if blockers or dead_dims:
        recs.append(
            (
                1.0,
                "Fix signal health issues first: "
                + "; ".join(
                    blockers[:2]
                    + [f"{len(dead_dims)} dead joints" for _ in dead_dims[:1] if dead_dims]
                ),
            )
        )

    # Episode count
    if policy_fit.episode_sufficiency < 0.7 and episode_count:
        from orbit.analyzer.policy_fit import POLICY_PROFILES

        profile = POLICY_PROFILES.get(policy_fit.policy_type)
        if profile:
            needed = profile["sweet_spot_low"] + (
                task_context.task_complexity_score
                * (profile["sweet_spot_high"] - profile["sweet_spot_low"])
            )
            more_needed = max(0, int(needed) - episode_count)
            if more_needed > 0:
                recs.append(
                    (
                        0.8,
                        f"Add ~{more_needed} more demonstrations to "
                        f"reach sweet spot for {policy_fit.policy_type}",
                    )
                )

    # Data quality
    if data_quality < 0.6:
        recs.append(
            (
                0.7,
                "Improve data quality — focus on smoother, more consistent demonstrations",
            )
        )
    elif data_quality < 0.75:
        recs.append((0.4, "Data quality is decent but could be improved with more careful teleop"))

    # Policy recommendations
    if policy_fit.recommended_policies and len(policy_fit.recommended_policies) > 1:
        if policy_fit.recommended_policies[0]["policy"] == policy_fit.policy_type:
            alt = policy_fit.recommended_policies[1]
        else:
            alt = policy_fit.recommended_policies[0]
        if alt["fit_score"] > policy_fit.fit_score + 0.05:
            recs.append(
                (
                    0.6,
                    (
                        f"Consider {alt['full_name']} ({alt['policy']}) — "
                        f"predicted fit score {alt['fit_score']:.2f} "
                        f"vs current {policy_fit.fit_score:.2f}"
                    ),
                )
            )

    # Multimodality warning
    if task_context.trajectory_multimodality > 0.6 and policy_fit.policy_type in ("bc", "act"):
        recs.append(
            (
                0.7,
                (
                    f"Data shows multiple strategies "
                    f"(multimodality={task_context.trajectory_multimodality:.2f}). "
                    f"Diffusion Policy handles this much better than {policy_fit.policy_type}."
                ),
            )
        )

    # Recovery demos
    if task_context.task_complexity_score > 0.5:
        recs.append(
            (
                0.3,
                "Include 5-10 recovery demonstrations showing how to recover from near-failures",
            )
        )

    # Sort by priority (highest first) and return just the recommendation text
    recs.sort(key=lambda x: x[0], reverse=True)
    return [r[1] for r in recs[:5]]
