"""Community comparison — compare a dataset against the benchmark database.

Finds similar entries by task_type and robot_type, then produces a structured
comparison showing how the user's dataset stacks up against successful peers.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

GROUND_TRUTH_PATH = Path(__file__).parent / "data" / "ground_truth_condensed.json"


@dataclass
class PeerEntry:
    """A single benchmark peer for display."""

    id: str
    dataset: str
    num_episodes: int
    success_rate: float
    policy: str
    task_type: str


@dataclass
class CommunityComparison:
    """Result of comparing a dataset against the benchmark database."""

    similar_successful: list[PeerEntry]  # peers with >70% success
    similar_all: list[PeerEntry]  # all matched peers (for stats)
    your_episodes: int
    peer_avg_episodes: float
    your_episode_percentile: str  # "bottom 25%", "middle 50%", etc.
    your_coverage: float | None  # overall coverage-like metric
    peer_avg_coverage: float | None
    actionable_tip: str  # one-liner recommendation


def compute_community_comparison(
    dataset_name: str,
    task_type: str | None,
    robot_type: str | None,
    num_episodes: int,
    coverage_score: float | None = None,
    policy_type: str | None = None,
) -> CommunityComparison | None:
    """Find similar benchmark entries and build a comparison.

    Returns None if the benchmark database can't be loaded or no similar
    entries are found.
    """
    try:
        with open(GROUND_TRUTH_PATH) as f:
            ground_truth: list[dict] = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.warning("Failed to load benchmark database: %s", e)
        return None

    if not ground_truth:
        return None

    # Score each entry for similarity
    scored: list[tuple[float, dict]] = []
    task_lower = (task_type or "").lower()
    robot_lower = (robot_type or "").lower()
    dataset_lower = dataset_name.lower()

    for entry in ground_truth:
        score = 0.0
        entry_task = entry.get("task_type", "").lower()
        entry_summary = entry.get("features_summary", "").lower()

        # Task type match (strongest signal)
        if task_lower and task_lower == entry_task:
            score += 5.0
        elif task_lower and task_lower in entry_task:
            score += 3.0

        # Robot type / bimanual matching via summary
        if robot_lower:
            if robot_lower in entry_summary:
                score += 3.0
            elif "aloha" in robot_lower and "bimanual" in entry_summary:
                score += 2.0
            elif "aloha" in dataset_lower and "aloha" in entry.get("id", "").lower():
                score += 3.0

        # Dataset name keyword overlap
        name_parts = [
            p for p in dataset_lower.replace("/", " ").replace("_", " ").split()
            if len(p) > 2 and p not in ("sim", "the", "and", "lerobot")
        ]
        for part in name_parts:
            if part in entry.get("id", "").lower() or part in entry_summary:
                score += 1.0

        if score > 0:
            scored.append((score, entry))

    if not scored:
        return None

    # Sort by score, take top 5
    scored.sort(key=lambda x: -x[0])
    top_entries = [e for _, e in scored[:5]]

    if len(top_entries) < 1:
        return None

    # Build peer entries
    all_peers = [
        PeerEntry(
            id=e["id"],
            dataset=e["dataset"],
            num_episodes=e.get("num_episodes", 0),
            success_rate=e.get("success_rate", 0.0),
            policy=e.get("policy", "unknown"),
            task_type=e.get("task_type", "unknown"),
        )
        for e in top_entries
    ]

    successful_peers = [p for p in all_peers if p.success_rate >= 0.70]

    # Compute stats from all peers
    peer_episodes = [p.num_episodes for p in all_peers if p.num_episodes > 0]
    peer_avg_ep = sum(peer_episodes) / len(peer_episodes) if peer_episodes else 0

    # Episode percentile
    if peer_episodes:
        below = sum(1 for ep in peer_episodes if num_episodes < ep)
        ratio = below / len(peer_episodes)
        if ratio >= 0.75:
            percentile = "bottom 25%"
        elif ratio >= 0.50:
            percentile = "below average"
        elif ratio >= 0.25:
            percentile = "above average"
        else:
            percentile = "top 25%"
    else:
        percentile = "unknown"

    # Actionable tip
    tip = _generate_tip(num_episodes, peer_avg_ep, successful_peers, coverage_score)

    return CommunityComparison(
        similar_successful=successful_peers,
        similar_all=all_peers,
        your_episodes=num_episodes,
        peer_avg_episodes=peer_avg_ep,
        your_episode_percentile=percentile,
        your_coverage=coverage_score,
        peer_avg_coverage=None,  # benchmark doesn't store coverage
        actionable_tip=tip,
    )


def _generate_tip(
    num_episodes: int,
    peer_avg_ep: float,
    successful_peers: list[PeerEntry],
    coverage_score: float | None,
) -> str:
    """Generate one actionable recommendation from the comparison."""
    if not successful_peers:
        return "No similar datasets with >70% success found — you're pioneering this task type."

    min_success_eps = min(p.num_episodes for p in successful_peers)
    avg_success_eps = sum(p.num_episodes for p in successful_peers) / len(successful_peers)

    if num_episodes < min_success_eps:
        gap = int(min_success_eps - num_episodes)
        return f"Collect ~{gap} more episodes to match the smallest successful peer ({min_success_eps} eps)."

    if num_episodes < avg_success_eps * 0.8:
        gap = int(avg_success_eps - num_episodes)
        return f"Collect ~{gap} more episodes to match successful peers (avg {int(avg_success_eps)} eps)."

    if coverage_score is not None and coverage_score < 0.70:
        return "Episode count matches peers — focus on diversity (varied start positions, speeds, approaches)."

    return "Your dataset size matches successful peers — focus on data quality and policy tuning."


def comparison_to_dict(comp: CommunityComparison) -> dict:
    """Convert to a JSON-serializable dict."""
    return {
        "similar_successful": [
            {
                "id": p.id,
                "dataset": p.dataset,
                "num_episodes": p.num_episodes,
                "success_rate": p.success_rate,
                "policy": p.policy,
            }
            for p in comp.similar_successful
        ],
        "similar_all": [
            {
                "id": p.id,
                "dataset": p.dataset,
                "num_episodes": p.num_episodes,
                "success_rate": p.success_rate,
                "policy": p.policy,
                "task_type": p.task_type,
            }
            for p in comp.similar_all
        ],
        "your_episodes": comp.your_episodes,
        "peer_avg_episodes": round(comp.peer_avg_episodes, 1),
        "your_episode_percentile": comp.your_episode_percentile,
        "actionable_tip": comp.actionable_tip,
    }
