"""Load LeRobot datasets from HuggingFace Hub."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd
from huggingface_hub import hf_hub_download
from huggingface_hub.hf_api import HfApi
from huggingface_hub.utils import (
    EntryNotFoundError,
    HfHubHTTPError,
    RepositoryNotFoundError,
)

logger = logging.getLogger(__name__)


@dataclass
class DatasetInfo:
    """Metadata about a LeRobot dataset."""

    repo_id: str
    num_episodes: int
    num_frames: int
    fps: float
    robot_type: str
    camera_names: list[str]
    video_keys: list[str]
    shapes: dict[str, list[int]] = field(default_factory=dict)
    duration_seconds: float = 0.0


def load_dataset_info(repo_id: str) -> DatasetInfo:
    """Fetch dataset metadata from HuggingFace Hub without downloading full data.

    Args:
        repo_id: HuggingFace repo ID, e.g. "lerobot/aloha_mobile_cabinet".

    Returns:
        DatasetInfo with parsed metadata.

    Raises:
        ValueError: If the repo doesn't exist or isn't a LeRobot dataset.
        ConnectionError: On network failures.
    """
    # Download meta/info.json (also validates repo exists)
    try:
        info_path = hf_hub_download(
            repo_id=repo_id,
            filename="meta/info.json",
            repo_type="dataset",
        )
    except RepositoryNotFoundError:
        raise ValueError(f"Dataset '{repo_id}' not found on HuggingFace Hub")
    except EntryNotFoundError:
        raise ValueError(f"'{repo_id}' does not appear to be a LeRobot dataset")
    except (HfHubHTTPError, Exception) as e:
        if isinstance(e, ValueError):
            raise
        raise ConnectionError(f"Network error downloading metadata from '{repo_id}': {e}") from e

    with open(info_path) as f:
        info = json.load(f)

    # Download episodes metadata (try v3 parquet first, then v1 jsonl)
    episodes_path = None
    episodes_parquet_path = None
    try:
        episodes_parquet_path = hf_hub_download(
            repo_id=repo_id,
            filename="meta/episodes/chunk-000/file-000.parquet",
            repo_type="dataset",
        )
    except (EntryNotFoundError, Exception):
        pass

    if episodes_parquet_path is None:
        try:
            episodes_path = hf_hub_download(
                repo_id=repo_id,
                filename="meta/episodes.jsonl",
                repo_type="dataset",
            )
        except EntryNotFoundError:
            episodes_path = None
        except (HfHubHTTPError, Exception) as e:
            if isinstance(e, (ValueError, EntryNotFoundError)):
                raise
            raise ConnectionError(
                f"Network error downloading episodes from '{repo_id}': {e}"
            ) from e

    num_episodes = info.get("total_episodes", 0)
    num_frames = info.get("total_frames", 0)
    fps = float(info.get("fps", 0))
    robot_type = info.get("robot_type", "unknown")

    # Parse camera names and video keys from info.json
    video_keys: list[str] = []
    camera_names: list[str] = []
    shapes: dict[str, list[int]] = {}

    features = info.get("features", {})
    for key, feat in features.items():
        if feat.get("dtype") == "video":
            video_keys.append(key)
            # e.g. "observation.images.top" -> "top"
            parts = key.split(".")
            camera_names.append(parts[-1])
        shape = feat.get("shape")
        if shape is not None:
            shapes[key] = shape

    # Override episode count from episodes metadata if available
    if episodes_parquet_path is not None:
        try:
            ep_df = pd.read_parquet(episodes_parquet_path)
            if len(ep_df) > 0:
                num_episodes = len(ep_df)
        except Exception:
            pass
    elif episodes_path is not None:
        ep_path = Path(episodes_path)
        if ep_path.exists():
            with open(ep_path) as f:
                lines = [line.strip() for line in f if line.strip()]
            if lines:
                num_episodes = len(lines)

    duration_seconds = num_frames / fps if fps > 0 else 0.0

    return DatasetInfo(
        repo_id=repo_id,
        num_episodes=num_episodes,
        num_frames=num_frames,
        fps=fps,
        robot_type=robot_type,
        camera_names=camera_names,
        video_keys=video_keys,
        shapes=shapes,
        duration_seconds=duration_seconds,
    )


def _sample_episode_indices(total: int, max_samples: int = 100) -> list[int]:
    """Select evenly-spaced episode indices when total exceeds max_samples."""
    if total <= max_samples:
        return list(range(total))
    step = total / max_samples
    return [int(i * step) for i in range(max_samples)]


def _discover_data_files(repo_id: str) -> list[str]:
    """Discover parquet data files in a LeRobot dataset repo.

    Handles both v1 (data/episode_NNNNNN.parquet) and v2/v3
    (data/chunk-NNN/file-NNN.parquet) formats.
    """
    api = HfApi()
    try:
        all_files = api.list_repo_files(repo_id, repo_type="dataset")
    except Exception:
        return []

    parquet_files = sorted(
        f for f in all_files if f.startswith("data/") and f.endswith(".parquet")
    )
    return parquet_files


def load_episode_data(
    repo_id: str,
    episode_indices: list[int] | None = None,
    max_episodes: int | None = None,
) -> pd.DataFrame:
    """Download and load episode parquet files from a LeRobot dataset.

    Supports both v1 (per-episode parquet) and v2/v3 (chunked parquet) formats.

    Args:
        repo_id: HuggingFace repo ID.
        episode_indices: Specific episodes to load. If None and the dataset
            has >100 episodes, 100 episodes are sampled evenly.
        max_episodes: Override max episodes to sample. Defaults to 100.

    Returns:
        DataFrame with columns: episode_index, frame_index, action, state,
        timestamp.

    Raises:
        ValueError: If the repo doesn't exist or isn't a LeRobot dataset.
        ConnectionError: On network failures.
    """
    info = load_dataset_info(repo_id)

    if max_episodes is None:
        max_episodes = 100

    # Discover what data files exist
    data_files = _discover_data_files(repo_id)

    if not data_files:
        logger.warning("No data files found in %s", repo_id)
        return pd.DataFrame(
            columns=["episode_index", "frame_index", "action", "state", "timestamp"]
        )

    # Determine format: v2/v3 chunk format or v1 per-episode format
    is_chunk_format = any("chunk-" in f for f in data_files)

    if is_chunk_format:
        result = _load_chunk_format(repo_id, data_files, info, episode_indices, max_episodes)
    else:
        result = _load_per_episode_format(repo_id, data_files, info, episode_indices, max_episodes)

    if result.empty:
        return pd.DataFrame(
            columns=["episode_index", "frame_index", "action", "state", "timestamp"]
        )

    # Normalise column names
    # Map observation.state -> state if needed
    if "state" not in result.columns and "observation.state" in result.columns:
        result = result.rename(columns={"observation.state": "state"})

    expected = ["episode_index", "frame_index", "action", "state", "timestamp"]
    for col in expected:
        if col not in result.columns:
            result[col] = None

    return result[expected + [c for c in result.columns if c not in expected]]


def _load_chunk_format(
    repo_id: str,
    data_files: list[str],
    info: DatasetInfo,
    episode_indices: list[int] | None,
    max_episodes: int,
) -> pd.DataFrame:
    """Load data from v2/v3 chunk-based parquet format.

    Downloads chunk files and filters to requested episodes.
    """
    frames: list[pd.DataFrame] = []

    for filename in data_files:
        try:
            parquet_path = hf_hub_download(
                repo_id=repo_id,
                filename=filename,
                repo_type="dataset",
            )
        except EntryNotFoundError:
            continue
        except (HfHubHTTPError, Exception) as e:
            if isinstance(e, (ValueError, EntryNotFoundError)):
                raise
            raise ConnectionError(
                f"Network error downloading {filename} from '{repo_id}': {e}"
            ) from e

        df = pd.read_parquet(parquet_path)
        frames.append(df)

    if not frames:
        return pd.DataFrame()

    result = pd.concat(frames, ignore_index=True)

    if "episode_index" not in result.columns:
        return result

    # Filter to requested episodes
    if episode_indices is not None:
        result = result[result["episode_index"].isin(episode_indices)]
    elif info.num_episodes > max_episodes:
        # Sample episodes evenly
        sampled = _sample_episode_indices(info.num_episodes, max_episodes)
        logger.info(
            "Sampling %d/%d episodes for speed",
            len(sampled),
            info.num_episodes,
        )
        result = result[result["episode_index"].isin(sampled)]

    return result


def _load_per_episode_format(
    repo_id: str,
    data_files: list[str],
    info: DatasetInfo,
    episode_indices: list[int] | None,
    max_episodes: int,
) -> pd.DataFrame:
    """Load data from v1 per-episode parquet format."""
    if episode_indices is None:
        episode_indices = _sample_episode_indices(info.num_episodes, max_episodes)

    frames: list[pd.DataFrame] = []
    for ep_idx in episode_indices:
        filename = f"data/episode_{ep_idx:06d}.parquet"
        if filename not in data_files:
            continue
        try:
            parquet_path = hf_hub_download(
                repo_id=repo_id,
                filename=filename,
                repo_type="dataset",
            )
        except EntryNotFoundError:
            continue
        except (HfHubHTTPError, Exception) as e:
            if isinstance(e, (ValueError, EntryNotFoundError)):
                raise
            raise ConnectionError(
                f"Network error downloading episode {ep_idx} from '{repo_id}': {e}"
            ) from e

        df = pd.read_parquet(parquet_path)
        if "episode_index" not in df.columns:
            df["episode_index"] = ep_idx
        frames.append(df)

    if not frames:
        return pd.DataFrame()

    return pd.concat(frames, ignore_index=True)
