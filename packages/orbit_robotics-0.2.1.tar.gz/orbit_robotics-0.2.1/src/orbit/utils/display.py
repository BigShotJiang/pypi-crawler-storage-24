"""Rich-based display helpers for ORBIT reports."""

from __future__ import annotations

from rich.console import Console

console = Console()


def print_header(title: str) -> None:
    """Print a report header with ═ underline."""
    console.print(f"\n[bold cyan]{title}[/bold cyan]")
    console.print("[cyan]" + "═" * len(title) + "[/cyan]")


def print_section(name: str) -> None:
    """Print a section name."""
    console.print(f"\n[bold yellow]{name}[/bold yellow]")


def print_metric(name: str, value: str, status: str = "ok") -> None:
    """Print a metric with status indicator.

    Args:
        name: Metric name.
        value: Display value.
        status: "ok" (green ✓), "warn" (yellow ⚠), or "bad" (red ✗).
    """
    if status == "ok":
        icon = "[green]✓[/green]"
    elif status == "warn":
        icon = "[yellow]⚠[/yellow]"
    else:
        icon = "[red]✗[/red]"
    console.print(f"  {icon} {name}: [bold]{value}[/bold]")


def format_duration(seconds: float) -> str:
    """Format seconds into a human-readable duration string."""
    if seconds < 60:
        return f"{seconds:.1f} sec"
    if seconds < 3600:
        return f"{seconds / 60:.1f} min"
    return f"{seconds / 3600:.1f} hours"
