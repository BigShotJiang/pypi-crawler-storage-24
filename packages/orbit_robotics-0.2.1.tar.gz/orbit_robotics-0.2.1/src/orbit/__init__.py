"""orbit-robotics: Data strategy copilot for robot policy training."""

__version__ = "0.1.0"
