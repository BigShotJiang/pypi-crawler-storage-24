"""Tests for the CalibratedSuccessPredictor."""

import numpy as np
import pytest

from orbit.analyzer.task_context import TaskContext
from orbit.analyzer.policy_fit import PolicyFit
from orbit.analyzer.success_predictor import CalibratedSuccessPredictor, SuccessPrediction


def _make_task_context(complexity=0.5, action_dim=7, is_bimanual=False):
    return TaskContext(
        task_complexity_score=complexity,
        dimension_complexity=0.4,
        temporal_complexity=0.4,
        coordination_complexity=0.4,
        object_interaction_complexity=0.3,
        trajectory_multimodality=0.3,
        is_bimanual=is_bimanual,
        action_dim=action_dim,
        mean_episode_length=150,
        estimated_task_type="moderate",
    )


def _make_policy_fit(fit_score=0.7, ep_suff=0.8, policy="diffusion_policy"):
    return PolicyFit(
        fit_score=fit_score,
        episode_sufficiency=ep_suff,
        action_space_compatibility=0.9,
        consistency_compatibility=0.7,
        policy_type=policy,
    )


class TestCalibratedSuccessPredictor:
    """Test the calibrated success predictor."""

    def setup_method(self):
        self.predictor = CalibratedSuccessPredictor()

    def test_basic_prediction(self):
        tc = _make_task_context()
        pf = _make_policy_fit()
        pred = self.predictor.predict(0.7, tc, pf)
        assert isinstance(pred, SuccessPrediction)
        assert 0.0 <= pred.predicted_success_rate <= 1.0

    def test_confidence_interval(self):
        tc = _make_task_context()
        pf = _make_policy_fit()
        pred = self.predictor.predict(0.7, tc, pf)
        low, high = pred.confidence_interval
        assert low <= pred.predicted_success_rate <= high
        assert low >= 0.0
        assert high <= 1.0

    def test_high_quality_beats_low_quality(self):
        tc = _make_task_context()
        pf = _make_policy_fit()
        pred_high = self.predictor.predict(0.90, tc, pf)
        pred_low = self.predictor.predict(0.30, tc, pf)
        assert pred_high.predicted_success_rate > pred_low.predicted_success_rate

    def test_simple_task_beats_complex(self):
        pf = _make_policy_fit()
        pred_simple = self.predictor.predict(0.7, _make_task_context(complexity=0.1), pf)
        pred_complex = self.predictor.predict(0.7, _make_task_context(complexity=0.9), pf)
        assert pred_simple.predicted_success_rate > pred_complex.predicted_success_rate

    def test_good_fit_beats_bad_fit(self):
        tc = _make_task_context()
        pred_good = self.predictor.predict(0.7, tc, _make_policy_fit(fit_score=0.9))
        pred_bad = self.predictor.predict(0.7, tc, _make_policy_fit(fit_score=0.2))
        assert pred_good.predicted_success_rate > pred_bad.predicted_success_rate

    def test_signal_blockers_reduce_prediction(self):
        tc = _make_task_context()
        pf = _make_policy_fit()
        pred_clean = self.predictor.predict(0.7, tc, pf)
        pred_blocked = self.predictor.predict(
            0.7, tc, pf,
            signal_diagnostics={
                "blockers": ["Dead joint", "Truncated episodes"],
                "warnings": ["High zero velocity"],
                "dead_dimensions": [2, 3],
            },
        )
        assert pred_clean.predicted_success_rate > pred_blocked.predicted_success_rate

    def test_grade_assignment(self):
        tc = _make_task_context(complexity=0.1)
        pf = _make_policy_fit(fit_score=0.9, ep_suff=0.9)
        pred = self.predictor.predict(0.9, tc, pf)
        assert pred.grade in ("A", "B", "C", "D", "F")

    def test_limiting_factor_identified(self):
        tc = _make_task_context()
        pf = _make_policy_fit()
        pred = self.predictor.predict(0.7, tc, pf)
        assert pred.limiting_factor != ""
        assert pred.limiting_factor_detail != ""

    def test_recommendations_present(self):
        tc = _make_task_context(complexity=0.7)
        pf = _make_policy_fit(ep_suff=0.4)
        pred = self.predictor.predict(0.5, tc, pf)
        assert len(pred.recommendations) > 0

    def test_ground_truth_matches(self):
        tc = _make_task_context()
        pf = _make_policy_fit(policy="diffusion_policy")
        pred = self.predictor.predict(
            0.7, tc, pf,
            task_type="pick_and_place",
            episode_count=200,
        )
        assert pred.n_ground_truth_matches > 0
        assert pred.base_rate > 0

    def test_contributing_factors_sum(self):
        tc = _make_task_context()
        pf = _make_policy_fit()
        pred = self.predictor.predict(0.7, tc, pf)
        assert "Data Quality" in pred.contributing_factors
        assert "Task Difficulty" in pred.contributing_factors
        assert "Policy Fit" in pred.contributing_factors

    def test_bimanual_task(self):
        tc = _make_task_context(complexity=0.6, action_dim=14, is_bimanual=True)
        pf = _make_policy_fit(policy="act")
        pred = self.predictor.predict(0.7, tc, pf, task_type="transport")
        assert 0.0 <= pred.predicted_success_rate <= 1.0

    def test_very_low_quality_gets_low_prediction(self):
        tc = _make_task_context(complexity=0.8)
        pf = _make_policy_fit(fit_score=0.3, ep_suff=0.3)
        pred = self.predictor.predict(
            0.2, tc, pf,
            signal_diagnostics={"blockers": ["Dead joint"], "warnings": [], "dead_dimensions": [0]},
        )
        assert pred.predicted_success_rate < 0.5
