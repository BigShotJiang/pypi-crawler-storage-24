"""Tests for orbit.tracker.progress."""

from __future__ import annotations

import os
import tempfile
from unittest.mock import patch

from click.testing import CliRunner

from orbit.analyzer.coverage import FullCoverageReport
from orbit.analyzer.dataset_loader import DatasetInfo
from orbit.cli import main
from orbit.planner.playbook import Playbook, generate_playbook
from orbit.tracker.progress import (
    compute_progress,
    load_plan_from_file,
)


def _make_info(num_episodes: int = 35) -> DatasetInfo:
    """Create a DatasetInfo for testing."""
    return DatasetInfo(
        repo_id="test/dataset",
        num_episodes=num_episodes,
        num_frames=num_episodes * 300,
        fps=30.0,
        robot_type="so100",
        camera_names=["cam_top"],
        video_keys=["observation.images.cam_top"],
        shapes={"action": [6]},
        duration_seconds=num_episodes * 10.0,
    )


def _make_coverage(
    position: float = 0.72,
    action: float = 0.31,
    consistency: float = 0.85,
    temporal: float = 0.55,
    outlier_episodes: list[int] | None = None,
) -> FullCoverageReport:
    """Create a FullCoverageReport for testing."""
    if outlier_episodes is None:
        outlier_episodes = [3] if consistency < 0.9 else []
    return FullCoverageReport(
        position_diversity=position,
        action_diversity=action,
        episode_consistency=consistency,
        temporal_coverage=temporal,
        outlier_episodes=outlier_episodes,
    )


def _make_plan() -> Playbook:
    """Create a Playbook for testing."""
    return generate_playbook("pick up mugs from table", "so100", "act")


class TestProgressComputation:
    """Test compute_progress with mock data."""

    def test_basic_progress(self):
        plan = _make_plan()
        info = _make_info(35)
        coverage = _make_coverage()
        report = compute_progress(plan, info, coverage)

        assert report.current_episodes == 35
        assert report.total_target_episodes == plan.total_target_episodes
        assert 0 < report.progress_percent < 100
        assert report.phase == "core"

    def test_progress_percent_calculation(self):
        plan = _make_plan()
        info = _make_info(plan.total_target_episodes)
        coverage = _make_coverage(0.8, 0.6, 0.9, 0.6)
        report = compute_progress(plan, info, coverage)

        assert report.progress_percent == 100.0

    def test_phase_core(self):
        plan = _make_plan()
        core_target = plan.phases[0].target_episodes
        info = _make_info(core_target - 10)
        coverage = _make_coverage()
        report = compute_progress(plan, info, coverage)

        assert report.phase == "core"

    def test_phase_diversity(self):
        plan = _make_plan()
        core_target = plan.phases[0].target_episodes
        info = _make_info(core_target + 5)
        coverage = _make_coverage()
        report = compute_progress(plan, info, coverage)

        assert report.phase == "diversity"


class TestChecklistGeneration:
    """Test checklist item generation."""

    def test_checklist_has_items(self):
        plan = _make_plan()
        info = _make_info(35)
        coverage = _make_coverage()
        report = compute_progress(plan, info, coverage)

        assert len(report.coverage_checklist) > 0

    def test_position_complete_when_above_target(self):
        plan = _make_plan()
        info = _make_info(35)
        coverage = _make_coverage(position=0.72)
        report = compute_progress(plan, info, coverage)

        pos_items = [
            item for item in report.coverage_checklist
            if "Position" in item.name
        ]
        if pos_items:
            assert pos_items[0].status == "complete"

    def test_action_not_complete_when_below_target(self):
        plan = _make_plan()
        info = _make_info(35)
        coverage = _make_coverage(action=0.31)
        report = compute_progress(plan, info, coverage)

        action_items = [
            item for item in report.coverage_checklist
            if "Action" in item.name
        ]
        if action_items:
            assert action_items[0].status != "complete"

    def test_checklist_item_has_current_and_target(self):
        plan = _make_plan()
        info = _make_info(35)
        coverage = _make_coverage()
        report = compute_progress(plan, info, coverage)

        for item in report.coverage_checklist:
            assert isinstance(item.current, (int, float))
            assert isinstance(item.target, (int, float))
            assert item.status in ("complete", "in_progress", "not_started")


class TestNextSessionPriorities:
    """Test next session priority ranking."""

    def test_has_priorities_when_incomplete(self):
        plan = _make_plan()
        info = _make_info(35)
        coverage = _make_coverage(action=0.31)
        report = compute_progress(plan, info, coverage)

        assert len(report.next_session_priorities) > 0

    def test_priorities_capped_at_three(self):
        plan = _make_plan()
        info = _make_info(10)
        coverage = _make_coverage(0.2, 0.1, 0.5, 0.2)
        report = compute_progress(plan, info, coverage)

        assert len(report.next_session_priorities) <= 3

    def test_no_priorities_when_all_complete(self):
        plan = _make_plan()
        info = _make_info(plan.total_target_episodes + 50)
        coverage = _make_coverage(0.9, 0.8, 0.6, 0.7)
        report = compute_progress(plan, info, coverage)

        # If everything is above threshold and episodes exceed target,
        # there should be no priorities (or very few)
        # Some may remain if specific items are still below target
        # The key check is that ready_to_train is True
        if report.ready_to_train:
            assert len(report.next_session_priorities) == 0


class TestExceedsPlanTargets:
    """Test edge case: dataset exceeds plan targets."""

    def test_exceeds_all_targets(self):
        plan = _make_plan()
        info = _make_info(plan.total_target_episodes + 100)
        # Use high consistency (>0.95 skips failure check) but explicitly
        # provide enough outlier episodes to satisfy recovery target
        coverage = _make_coverage(
            0.9, 0.8, 0.75, 0.7,
            outlier_episodes=[1, 2, 3, 4, 5, 6],
        )
        report = compute_progress(plan, info, coverage)

        assert report.progress_percent == 100.0
        assert report.ready_to_train is True

    def test_exceeds_episodes_but_low_coverage(self):
        plan = _make_plan()
        info = _make_info(plan.total_target_episodes + 100)
        coverage = _make_coverage(0.1, 0.1, 0.3, 0.1)
        report = compute_progress(plan, info, coverage)

        assert report.progress_percent == 100.0
        assert report.ready_to_train is False


class TestPlanSaveLoad:
    """Test saving and loading plans."""

    def test_roundtrip(self):
        plan = _make_plan()
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            plan.save(path)
            loaded = load_plan_from_file(path)
            assert loaded.task_type == plan.task_type
            assert loaded.robot_type == plan.robot_type
            assert loaded.total_target_episodes == plan.total_target_episodes
            assert len(loaded.phases) == len(plan.phases)
        finally:
            os.unlink(path)

    def test_load_nonexistent_file(self):
        import pytest
        with pytest.raises(FileNotFoundError):
            load_plan_from_file("/nonexistent/plan.json")


class TestTrackCLI:
    """Test the orbit track CLI command."""

    def test_track_file_not_found(self):
        runner = CliRunner()
        result = runner.invoke(main, [
            "track", "/tmp/nonexistent_plan.json",
            "--dataset", "lerobot/pusht",
        ])
        assert result.exit_code != 0
        assert "Plan file not found" in result.output
        assert "orbit plan" in result.output

    @patch("orbit.analyzer.dataset_loader.load_dataset_info")
    @patch("orbit.analyzer.dataset_loader.load_episode_data")
    def test_track_shows_progress(self, mock_ep, mock_info):
        mock_info.return_value = _make_info(35)
        mock_ep.return_value = None

        plan = _make_plan()
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            plan.save(path)
            runner = CliRunner()
            result = runner.invoke(main, [
                "track", path, "--dataset", "test/dataset",
            ])
            assert result.exit_code == 0
            assert "ORBIT Progress Tracker" in result.output
            assert "35" in result.output
            assert "Ready to Train" in result.output
        finally:
            os.unlink(path)

    def test_track_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["track", "--help"])
        assert result.exit_code == 0
        assert "Track training progress" in result.output
