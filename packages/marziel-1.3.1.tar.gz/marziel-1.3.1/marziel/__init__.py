"""
Marziel AI — Private Intelligence, Locally Powered.

pip install marziel
marziel serve
"""

__version__ = "1.3.1"
__author__ = "Marziel AI Team"
