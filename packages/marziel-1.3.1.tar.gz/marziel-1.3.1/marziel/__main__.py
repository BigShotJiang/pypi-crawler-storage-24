"""Allow running as: python -m marziel"""
from marziel.cli import main

if __name__ == "__main__":
    main()
