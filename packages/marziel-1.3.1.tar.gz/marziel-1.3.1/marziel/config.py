"""
Marziel AI — Configuration

Centralized configuration for the Marziel application.
All environment variables and constants are loaded here.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env from project root
_ENV_FILE = Path(__file__).parent.parent / ".env"
load_dotenv(_ENV_FILE)

# ── Server ──
LLM_PORT = int(os.environ.get("LLM_PORT", "8000"))
VLLM_URL = os.environ.get("VLLM_URL", "http://localhost:8000")
VLLM_MODEL = os.environ.get("VLLM_MODEL", "")
IDLE_TIMEOUT = int(os.environ.get("MARZIEL_IDLE_TIMEOUT", "600"))

# ── Stripe Billing ──
STRIPE_SECRET_KEY = os.environ.get("STRIPE_SECRET_KEY", "")
STRIPE_PUBLISHABLE_KEY = os.environ.get("STRIPE_PUBLISHABLE_KEY", "")
STRIPE_WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")

STRIPE_PRICES = {
    "starter": os.environ.get("STRIPE_PRICE_STARTER", ""),
    "pro": os.environ.get("STRIPE_PRICE_PRO", ""),
    "enterprise": os.environ.get("STRIPE_PRICE_ENTERPRISE", ""),
}

# Reverse map: price_id -> tier
PRICE_TO_TIER = {v: k for k, v in STRIPE_PRICES.items() if v}

# ── Licensing ──
LICENSE_FILE = Path.home() / ".marziel" / "license.json"

# ── Feature gating ──
AGENT_TIERS = {"pro", "enterprise"}
