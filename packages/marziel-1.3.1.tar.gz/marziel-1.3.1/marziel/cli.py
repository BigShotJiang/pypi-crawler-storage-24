#!/usr/bin/env python3
"""
Marziel CLI — Complete AI system.

`marziel serve` does everything:
  1. Downloads model from Hugging Face (first run only, ~4.2GB)
  2. Starts MLX inference engine
  3. Starts web server with UI

Zero manual steps.
"""

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import time
import urllib.request

# ── Config ──
HF_REPO = os.environ.get("MARZIEL_HF_REPO", "efops/marziel-8b-custom")
MARZIEL_HOME = os.path.expanduser("~/.marziel")
MODEL_DIR = os.path.join(MARZIEL_HOME, "models", "marziel-8b-custom")
LLM_PORT = int(os.environ.get("LLM_PORT", "8000"))
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "llama3.1:8b")


def _print(msg):
    print(f"  {msg}")


# ══════════════════════════════════════════════════════════
# MODEL MANAGEMENT
# ══════════════════════════════════════════════════════════

def _model_exists():
    """Check if model is already downloaded."""
    return (
        os.path.isdir(MODEL_DIR)
        and os.path.exists(os.path.join(MODEL_DIR, "config.json"))
        and os.path.exists(os.path.join(MODEL_DIR, "model.safetensors"))
    )


def _download_model():
    """Download the Marziel model from Hugging Face."""
    _print(f"📥 Downloading Marziel AI model...")
    _print(f"   Source: huggingface.co/{HF_REPO}")
    _print(f"   Destination: {MODEL_DIR}")
    _print(f"   Size: ~4.2 GB (one-time download)")
    _print(f"   Your model stays 100% local after download.")
    _print("")

    os.makedirs(MODEL_DIR, exist_ok=True)

    try:
        from huggingface_hub import snapshot_download

        snapshot_download(
            repo_id=HF_REPO,
            local_dir=MODEL_DIR,
            local_dir_use_symlinks=False,
        )
        _print("   ✅ Model downloaded successfully!")
        return True

    except Exception as e:
        error_msg = str(e)
        if "401" in error_msg or "403" in error_msg or "gated" in error_msg.lower():
            _print("   🔒 This model requires authentication.")
            _print("")
            _print("   Run these commands first:")
            _print("     pip install huggingface_hub")
            _print("     huggingface-cli login")
            _print("")
            _print("   Then run 'marziel serve' again.")
        else:
            _print(f"   ❌ Download failed: {e}")
        return False


# ══════════════════════════════════════════════════════════
# ENGINE MANAGEMENT
# ══════════════════════════════════════════════════════════

def _port_active(port):
    """Check if an LLM server is running on a port."""
    try:
        req = urllib.request.Request(f"http://localhost:{port}/v1/models")
        resp = urllib.request.urlopen(req, timeout=3)
        return resp.status == 200
    except Exception:
        return False


def _ollama_running():
    try:
        req = urllib.request.Request("http://localhost:11434/api/tags")
        resp = urllib.request.urlopen(req, timeout=3)
        return resp.status == 200
    except Exception:
        return False


def _find_mlx_python():
    """Find a Python with mlx_lm installed."""
    # Check common venv locations
    candidates = [
        os.path.expanduser("~/.venv-mlx/bin/python3"),
        os.path.join(MARZIEL_HOME, "venv/bin/python3"),
        shutil.which("python3"),
    ]
    for py in candidates:
        if py and os.path.exists(py):
            try:
                result = subprocess.run(
                    [py, "-c", "import mlx_lm; print('ok')"],
                    capture_output=True, text=True, timeout=5
                )
                if result.returncode == 0:
                    return py
            except Exception:
                continue
    return None


def _start_mlx_engine():
    """Start MLX inference server with the downloaded model."""
    python = _find_mlx_python()

    if not python:
        _print("   ⚠️  mlx_lm not found. Installing...")
        # Create a venv and install mlx_lm
        venv_dir = os.path.join(MARZIEL_HOME, "venv")
        if not os.path.exists(venv_dir):
            subprocess.run([sys.executable, "-m", "venv", venv_dir], check=True)
        pip = os.path.join(venv_dir, "bin", "pip")
        subprocess.run([pip, "install", "mlx-lm"], check=True)
        python = os.path.join(venv_dir, "bin", "python3")

    _print(f"🚀 Starting Marziel AI engine...")
    _print(f"   Model: marziel-8b-custom")
    _print(f"   Port: {LLM_PORT}")

    # Kill any existing process on the port
    try:
        subprocess.run(
            f"lsof -ti:{LLM_PORT} | xargs kill -9 2>/dev/null || true",
            shell=True, capture_output=True
        )
        time.sleep(1)
    except Exception:
        pass

    # Start MLX server
    subprocess.Popen(
        [python, "-m", "mlx_lm.server",
         "--model", MODEL_DIR,
         "--port", str(LLM_PORT),
         "--host", "0.0.0.0"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )

    # Wait for it to be ready
    for i in range(30):
        if _port_active(LLM_PORT):
            _print("   ✅ Engine running")
            return True
        time.sleep(1)
        if i % 5 == 4:
            _print(f"   ⏳ Loading model... ({i+1}s)")

    _print("   ⚠️  Engine started — model still loading, will be ready shortly")
    return True


def _start_ollama():
    """Fallback: start Ollama engine."""
    if not shutil.which("ollama"):
        system = platform.system().lower()
        _print("📥 Installing Ollama (fallback engine)...")
        try:
            if system in ("darwin", "linux"):
                subprocess.run(
                    ["sh", "-c", "curl -fsSL https://ollama.com/install.sh | sh"],
                    check=True
                )
            else:
                _print("   Install Ollama: https://ollama.com/download")
                return False
        except Exception:
            return False

    if not _ollama_running():
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        for _ in range(15):
            if _ollama_running():
                break
            time.sleep(1)

    # Pull model if needed
    try:
        req = urllib.request.Request("http://localhost:11434/api/tags")
        resp = urllib.request.urlopen(req, timeout=5)
        data = json.loads(resp.read().decode())
        models = [m.get("name", "") for m in data.get("models", [])]
        if not any(OLLAMA_MODEL.split(":")[0] in m for m in models):
            _print(f"📥 Pulling {OLLAMA_MODEL}...")
            subprocess.run(["ollama", "pull", OLLAMA_MODEL], check=True)
    except Exception:
        pass

    _print("   ✅ Ollama engine running")
    return True


def ensure_ready():
    """Ensure model is downloaded and engine is running."""

    # Step 1: engine already running?
    if _port_active(LLM_PORT):
        _print(f"✅ AI engine already running (port {LLM_PORT})")
        return "mlx"

    # Step 2: model downloaded?
    if not _model_exists():
        if not _download_model():
            # Fallback to Ollama
            _print("")
            _print("⚡ Falling back to Ollama...")
            if _start_ollama():
                return "ollama"
            return None

    # Step 3: start MLX engine
    if platform.machine() in ("arm64", "aarch64"):
        _start_mlx_engine()
        return "mlx"
    else:
        # Non-Apple Silicon — use Ollama
        _print("   ℹ️  MLX requires Apple Silicon — using Ollama")
        if _start_ollama():
            return "ollama"
        return None


# ══════════════════════════════════════════════════════════
# CLI COMMANDS
# ══════════════════════════════════════════════════════════

def cmd_serve(args):
    """Start the complete Marziel AI system."""
    port = args.port or int(os.environ.get("MARZIEL_PORT", "8001"))
    host = args.host or os.environ.get("MARZIEL_HOST", "0.0.0.0")

    print()
    print("  ╔══════════════════════════════════════════════════╗")
    print("  ║  🧠 Marziel AI — Private Intelligence Engine    ║")
    print("  ╚══════════════════════════════════════════════════╝")
    print()

    # Auto-setup everything
    engine = ensure_ready()
    _print("")

    engine_labels = {
        "mlx": "Marziel 8B Custom (Apple Silicon MLX)",
        "ollama": f"Ollama ({OLLAMA_MODEL})",
    }

    _print("━━━ System Ready ━━━")
    _print("")
    _print(f"🌐 Dashboard: http://localhost:{port}")
    _print(f"🔌 API:       http://localhost:{port}/llm/chat")
    _print(f"🛡️  Sentinel:  Active")
    _print(f"🧬 Neurons:   8 synapse types")
    if engine:
        _print(f"🧠 LLM:       {engine_labels.get(engine, engine)}")
    _print("")

    from marziel.server import create_app
    app = create_app()

    if args.debug:
        app.run(host=host, port=port, debug=True)
    else:
        try:
            from gunicorn.app.base import BaseApplication

            class MarzielApp(BaseApplication):
                def __init__(self, app, options=None):
                    self.options = options or {}
                    self.application = app
                    super().__init__()

                def load_config(self):
                    for key, value in self.options.items():
                        if key in self.cfg.settings and value is not None:
                            self.cfg.set(key.lower(), value)

                def load(self):
                    return self.application

            options = {
                "bind": f"{host}:{port}",
                "workers": 2,
                "timeout": 120,
                "accesslog": "-",
            }
            MarzielApp(app, options).run()
        except ImportError:
            app.run(host=host, port=port, debug=False)


def cmd_status(args):
    """Check all system components."""
    port = args.port or 8001
    from marziel import __version__
    _print(f"Marziel AI v{__version__}")
    _print("")

    # License status removed

    try:
        req = urllib.request.Request(f"http://localhost:{port}/health")
        urllib.request.urlopen(req, timeout=3)
        _print(f"✅ Server (port {port})")
    except Exception:
        _print(f"❌ Server (port {port})")

    if _port_active(LLM_PORT):
        _print(f"✅ AI Engine (port {LLM_PORT})")
    else:
        _print(f"⏸️  AI Engine (idle — auto-restarts on next request)")

    if _model_exists():
        _print(f"✅ Model: marziel-8b-custom ({MODEL_DIR})")
    else:
        _print(f"❌ Model not downloaded — run 'marziel serve'")

    if _ollama_running():
        _print("✅ Ollama (port 11434)")
    elif shutil.which("ollama"):
        _print("⏸️  Ollama installed (not running)")

    # Resource info
    _print("")
    _print("━━━ Resources ━━━")
    try:
        if platform.system() == "Darwin":
            result = subprocess.run(
                ["sysctl", "-n", "hw.memsize"],
                capture_output=True, text=True, timeout=3
            )
            total_gb = round(int(result.stdout.strip()) / 1024**3, 1)
            _print(f"💾 System RAM: {total_gb} GB")
        # Engine RAM
        if _port_active(LLM_PORT):
            result = subprocess.run(
                f"lsof -ti:{LLM_PORT} | head -1",
                shell=True, capture_output=True, text=True, timeout=3
            )
            pid = result.stdout.strip()
            if pid:
                result = subprocess.run(
                    ["ps", "-o", "rss=", "-p", pid],
                    capture_output=True, text=True, timeout=3
                )
                rss_mb = round(int(result.stdout.strip()) / 1024)
                _print(f"🧠 Engine RAM: {rss_mb} MB")
        idle_timeout = int(os.environ.get("MARZIEL_IDLE_TIMEOUT", "600"))
        _print(f"♻️  Idle shutdown: {idle_timeout // 60} min (saves RAM when not in use)")
    except Exception:
        pass



def cmd_version(args):
    """Show version information."""
    from marziel import __version__
    _print(f"Marziel AI v{__version__}")
    _print(f"Python {sys.version.split()[0]}")
    _print(f"Platform: {sys.platform} ({platform.machine()})")
    _print(f"Model repo: {HF_REPO}")
    _print(f"Model dir: {MODEL_DIR}")
    _print(f"Model ready: {'Yes' if _model_exists() else 'No'}")


def main():
    parser = argparse.ArgumentParser(
        prog="marziel",
        description="🧠 Marziel AI — Private Intelligence, Locally Powered",
    )
    sub = parser.add_subparsers(dest="command")

    p_serve = sub.add_parser("serve", help="Start Marziel (auto-downloads model)")
    p_serve.add_argument("--port", type=int, default=None, help="Server port (default: 8001)")
    p_serve.add_argument("--host", default=None, help="Host (default: 0.0.0.0)")
    p_serve.add_argument("--debug", action="store_true", help="Debug mode")

    p_status = sub.add_parser("status", help="Check system status")
    p_status.add_argument("--port", type=int, default=None)

    sub.add_parser("version", help="Show version info")

    args = parser.parse_args()

    if args.command == "serve":
        cmd_serve(args)
    elif args.command == "status":
        cmd_status(args)
    elif args.command == "version":
        cmd_version(args)
    else:
        parser.print_help()
        print("\n  Quick start:")
        print("    pip install marziel")
        print("    marziel serve")
        print()


if __name__ == "__main__":
    main()

