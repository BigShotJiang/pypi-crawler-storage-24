---
language:
  - en
license: mit
tags:
  - llama
  - mlx
  - 4-bit
  - local-ai
  - private
  - maritime
library_name: mlx
pipeline_tag: text-generation
base_model: meta-llama/Llama-3.1-8B-Instruct
---

# 🧠 Marziel AI — v1.3.0

**Private Local Intelligence — runs entirely on your hardware.**

Marziel AI is a locally-powered AI assistant with web search, browser automation, GitHub analysis, URL reading, code generation, and intelligent conversations — all without sending a single byte to the cloud.

## Quick Install

```bash
pip install marziel
marziel serve
```

That's it. The first run downloads the model (~4.2 GB) from Hugging Face and starts everything automatically.

## What It Does

| Feature | Description |
|---------|-------------|
| 🧠 **AI Chat** | Conversational AI with personality, code generation, data analysis |
| 🔍 **Web Search** | Live internet results via DuckDuckGo — always up-to-date answers |
| 🌐 **Browser Control** | Headless Chromium automation — navigate, click, type, screenshot |
| 🔗 **URL Analysis** | Share any link — reads, extracts, and analyzes content |
| 🐙 **GitHub Analysis** | Paste any repo URL — get architecture, languages, README analysis |
| ⚡ **Autonomous Agent** | Multi-step reasoning with bash, file, web, and browser tools |
| 🚢 **Maritime Intel** | Vessel tracking, route analysis, operational intelligence |
| 🔒 **100% Private** | Everything runs locally. Zero cloud dependency |

## Changelog

### v1.3.0 — Browser Control
- **Browser automation**: Headless Chromium via Playwright — navigate, click, type, read pages, take screenshots
- **Agent tool**: `ACTION: browser` with subcommands (navigate, click, type, read, screenshot, close)
- `pip install "marziel[browser]"` to enable

### v1.2.0 — Production Ready
- **Stripe webhook HMAC-SHA256 verification** — prevents fake payment events
- **Rate limiting**: 20 requests/min per IP on sensitive endpoints
- **React Error Boundary** — no more blank screens on crash
- **install.sh rewritten** for pip install flow with platform extras

### v1.1.0 — Auto Web Search
- **Auto web search augmentation** — Marziel detects when questions need current info and searches DuckDuckGo
- **Modular billing** — Clean Stripe integration with EUR pricing
- **Premium dashboard** — Glassmorphism UI with real-time engine status
- **ReAct Agent** — Autonomous tool-use with bash, file I/O, and web search

## Requirements

- **RAM**: 8GB minimum (16GB recommended)
- **Disk**: ~5GB for the model
- **Python**: 3.10+
- **Supported hardware**:
  - Apple Silicon (M1/M2/M3/M4) — uses MLX inference
  - NVIDIA GPU (8GB+ VRAM) — uses vLLM with CUDA
  - CPU fallback — uses Ollama or llama.cpp

## Usage

```bash
# Install and start (basic)
pip install marziel
marziel serve

# With browser automation
pip install "marziel[browser]"
python -m playwright install chromium
marziel serve

# Check status
marziel status

# Show version
marziel version
```

Then open **http://localhost:8001** — your private AI dashboard.

## Architecture

```
┌─────────────────────────────────────────┐
│  Browser (localhost:8001)               │
│  ┌───────────────────────────────────┐  │
│  │  Marziel Dashboard (React)       │  │
│  │  Dashboard · Chat · Settings     │  │
│  └──────────────┬────────────────────┘  │
│                 │ API calls             │
│  ┌──────────────▼────────────────────┐  │
│  │  Marziel Backend (Flask+Gunicorn)│  │
│  │  Agent · Search · Browser · Bill │  │
│  └──────────────┬────────────────────┘  │
│                 │ LLM inference         │
│  ┌──────────────▼────────────────────┐  │
│  │  LLM Server (MLX/vLLM:8000)     │  │
│  │  Marziel 8B Custom (4-bit)      │  │
│  └───────────────────────────────────┘  │
│                YOUR MACHINE             │
└─────────────────────────────────────────┘
```

## Pricing

| Plan | Price | Features |
|------|-------|----------|
| **Free** | €0/mo | AI Chat, Web Search, URL Analysis |
| **Starter** | €9/mo | Everything in Free |
| **Pro** | €29/mo | + GitHub, Maritime, Agent Mode, Browser |
| **Enterprise** | €199/mo | + Priority support, Mitosis, Custom fine-tuning |

## Links

- 🌐 Website: [marziel.com](https://marziel.com)
- 🤗 Model: [huggingface.co/efops/marziel-8b-custom](https://huggingface.co/efops/marziel-8b-custom)
- 📦 PyPI: [pypi.org/project/marziel](https://pypi.org/project/marziel)

## License

MIT License

---

Built with ❤️ by Efe (Efkan Isazade)
