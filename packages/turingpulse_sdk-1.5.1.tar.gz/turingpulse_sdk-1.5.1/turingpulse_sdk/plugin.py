"""Core TuringPulse plugin implementation."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import threading
from typing import Any, Callable, Dict, Optional
from uuid import uuid4

from .client import TuringPulseHttpClient
from .config import TuringPulseConfig
from .context import ExecutionContext, bind_context, current_context
from .event_builder import EventBuilder
from .exceptions import GovernanceBlockedError, PluginNotInitializedError, TriggerNotFoundError
from .fingerprint import FingerprintBuilder
from .governance import GovernanceDirective, GovernanceManager
from .instrumentation import InstrumentationOptions
from .kpi import KPIResult, evaluate_kpis
from .llm_detector import detect_node_type
from .registry import TriggerRegistry
from .tracing import TracingManager
from .trigger_state import flush_pending

logger = logging.getLogger("turingpulse.sdk.core")
_PLUGIN: "TuringPulsePlugin | None" = None
_INIT_LOCK = threading.Lock()


class TuringPulsePlugin:
    def __init__(self, config: TuringPulseConfig):
        self.config = config
        self.client = TuringPulseHttpClient(config)
        self.tracing = TracingManager(config)
        self.governance = GovernanceManager(self.client, config)
        self.registry = TriggerRegistry()
        self.event_builder = EventBuilder(config)

    def shutdown(self) -> None:
        self.client.close()

    async def ashutdown(self) -> None:
        await self.client.aclose()

    # ------------------------------------------------------------------
    # Trigger management
    # ------------------------------------------------------------------

    def register_trigger(self, key: str, func: Callable, description: Optional[str] = None) -> str:
        namespaced = self._namespaced_key(key)
        self.registry.register(namespaced, func, description=description)
        return namespaced

    def unregister_trigger(self, key: str) -> None:
        self.registry.unregister(self._namespaced_key(key))

    def trigger_agent(self, key: str, *args, **kwargs):
        namespaced = self._namespaced_key(key)
        entry = self.registry.get(namespaced)
        if not entry:
            safe_key = str(namespaced)[:100] if namespaced else "<empty>"
            raise TriggerNotFoundError(f"No trigger registered for key '{safe_key}'")
        return entry.func(*args, **kwargs)

    def list_triggers(self):
        return self.registry.list()

    # ------------------------------------------------------------------
    # Execution — shared span scaffolding + sync/async/gen variants
    # ------------------------------------------------------------------

    def _span_scaffold(self, func: Callable, args: tuple, kwargs: dict, options: InstrumentationOptions):
        """Return (context, span_cm) with all shared setup done.

        Used by all four execute variants to avoid repeating context
        build, node recording, and tracing span construction.
        """
        context = self._build_context(func, args, kwargs, options)
        self._record_node(context, func, args, kwargs)
        span_cm = self.tracing.span(
            options.span_name(func.__name__),
            attributes=context.labels,
            enabled=options.tracing_enabled(self.config.trace_enabled),
            context=context,
        )
        return context, span_cm

    # ------------------------------------------------------------------
    # Pre-execution governance (HITL blocking)
    # ------------------------------------------------------------------

    def _resolve_governance(self, options: InstrumentationOptions) -> GovernanceDirective | None:
        """Merge per-call governance with global defaults.

        Per-call directive fields take precedence over global defaults.
        If neither per-call nor global HITL is enabled, returns None to skip
        the pre-execution check.
        """
        directive = options.governance
        defaults = self.config.governance_defaults

        if directive is None and not defaults.hitl:
            return None

        if directive is None:
            return GovernanceDirective(
                hitl=defaults.hitl,
                reviewers=list(defaults.reviewers),
                escalation_channels=list(defaults.escalation_channels),
                metadata=dict(defaults.metadata),
                severity=defaults.severity,
                auto_escalate_after_seconds=defaults.auto_escalate_after_seconds,
            )

        if not directive.hitl and defaults.hitl:
            directive = directive.model_copy(update={"hitl": True})

        return directive

    def _pre_execution_policy_check(
        self, context: ExecutionContext, options: InstrumentationOptions
    ) -> None:
        """Run a synchronous pre-execution policy check. Raises GovernanceBlockedError on 'block'."""
        directive = self._resolve_governance(options)
        if directive is None or not directive.hitl:
            return

        policy_kwargs: Dict[str, Any] = {
            "workflow_name": context.workflow_name,
            "span_id": context.span_id,
            "node_type": context.node_type,
            "operation": context.operation,
        }
        if context.tool_name is not None:
            policy_kwargs["tool_name"] = context.tool_name
        if context.tool_args is not None:
            policy_kwargs["tool_args"] = context.tool_args
            try:
                import json
                policy_kwargs["input_text"] = json.dumps(context.tool_args, default=str)[:10_000]
            except Exception:
                pass
        if context.mcp_server is not None:
            policy_kwargs["mcp_server"] = context.mcp_server

        try:
            result = self.client.policy_check(**policy_kwargs)
        except Exception:
            return

        if result.blocked:
            raise GovernanceBlockedError(
                reason=result.reason,
                policy_ids=result.policy_ids,
            )

    async def _pre_execution_policy_check_async(
        self, context: ExecutionContext, options: InstrumentationOptions
    ) -> None:
        """Run an async pre-execution policy check. Raises GovernanceBlockedError on 'block'."""
        directive = self._resolve_governance(options)
        if directive is None or not directive.hitl:
            return

        policy_kwargs: Dict[str, Any] = {
            "workflow_name": context.workflow_name,
            "span_id": context.span_id,
            "node_type": context.node_type,
            "operation": context.operation,
        }
        if context.tool_name is not None:
            policy_kwargs["tool_name"] = context.tool_name
        if context.tool_args is not None:
            policy_kwargs["tool_args"] = context.tool_args
            try:
                import json
                policy_kwargs["input_text"] = json.dumps(context.tool_args, default=str)[:10_000]
            except Exception:
                pass
        if context.mcp_server is not None:
            policy_kwargs["mcp_server"] = context.mcp_server

        try:
            result = await self.client.policy_check_async(**policy_kwargs)
        except Exception:
            return

        if result.blocked:
            raise GovernanceBlockedError(
                reason=result.reason,
                policy_ids=result.policy_ids,
            )

    # ------------------------------------------------------------------
    # Execution — sync/async/gen variants with pre-execution policy check
    # ------------------------------------------------------------------

    def execute_sync(self, func: Callable, args: tuple, kwargs: dict, options: InstrumentationOptions):
        context, span_cm = self._span_scaffold(func, args, kwargs, options)
        with bind_context(context), span_cm:
            result: Any = None
            error: BaseException | None = None
            try:
                self._pre_execution_policy_check(context, options)
                result = func(*args, **kwargs)
                context.finish(result=result)
                return result
            except Exception as exc:
                error = exc
                context.finish(error=exc)
                raise
            finally:
                self._pop_node(context)
                self._finalize(context, options, result, error, is_async=False)

    async def execute_async(self, func: Callable, args: tuple, kwargs: dict, options: InstrumentationOptions):
        context, span_cm = self._span_scaffold(func, args, kwargs, options)
        with bind_context(context), span_cm:
            result: Any = None
            error: BaseException | None = None
            try:
                await self._pre_execution_policy_check_async(context, options)
                result = await func(*args, **kwargs)
                context.finish(result=result)
                return result
            except Exception as exc:
                error = exc
                context.finish(error=exc)
                raise
            finally:
                self._pop_node(context)
                await self._finalize_async(context, options, result, error)

    def execute_sync_gen(self, func: Callable, args: tuple, kwargs: dict, options: InstrumentationOptions):
        """Wrap a sync generator: span covers the full iteration lifetime."""
        context, span_cm = self._span_scaffold(func, args, kwargs, options)
        with bind_context(context), span_cm:
            error: BaseException | None = None
            chunks: list = []
            try:
                self._pre_execution_policy_check(context, options)
                for item in func(*args, **kwargs):
                    chunks.append(item)
                    yield item
                context.finish(result=chunks)
            except Exception as exc:
                error = exc
                context.finish(error=exc)
                raise
            finally:
                self._pop_node(context)
                self._finalize(context, options, chunks, error, is_async=False)

    async def execute_async_gen(self, func: Callable, args: tuple, kwargs: dict, options: InstrumentationOptions):
        """Wrap an async generator: span covers the full iteration lifetime."""
        context, span_cm = self._span_scaffold(func, args, kwargs, options)
        with bind_context(context), span_cm:
            error: BaseException | None = None
            chunks: list = []
            try:
                await self._pre_execution_policy_check_async(context, options)
                async for item in func(*args, **kwargs):
                    chunks.append(item)
                    yield item
                context.finish(result=chunks)
            except Exception as exc:
                error = exc
                context.finish(error=exc)
                raise
            finally:
                self._pop_node(context)
                await self._finalize_async(context, options, chunks, error)

    # ------------------------------------------------------------------
    # Finalize — shared logic, branching only on the emit call
    # ------------------------------------------------------------------

    def _finalize_common(
        self,
        context: ExecutionContext,
        options: InstrumentationOptions,
        result: Any,
        error: BaseException | None,
    ):
        """Shared pre-emit logic: transcript, KPI, event build."""
        self._auto_populate_io(context, result, error)
        self.event_builder.apply_transcript(options, context, result, error)
        kpi_results = evaluate_kpis(options.kpis, context)
        event = self.event_builder.build(context, options, kpi_results)
        payload = self.client.serialize_events([event])
        return payload, kpi_results, options.governance

    _USER_INPUT_KEYS = ("user_query", "guest_message", "input", "query", "message", "question", "prompt", "text")

    @staticmethod
    def _auto_populate_io(
        context: ExecutionContext,
        result: Any,
        error: BaseException | None,
    ) -> None:
        """Auto-populate input_data/output_data for raw @instrument spans.

        Framework integrations (LangGraph, LangChain, etc.) explicitly call
        ``ctx.set_io()`` with rich data.  When they haven't, fall back to a
        best-effort extraction:

        * For dict arguments, extract the first user-facing key (user_query,
          input, message, …) rather than dumping the entire state dict.
        * For dict returns, extract the last-set key that looks like an output
          (final_response, action_result, output, …).
        """
        from .config import MAX_FIELD_SIZE

        if context.input_data is None:
            try:
                text: str | None = None
                if context.args:
                    first = context.args[0]
                    if isinstance(first, dict):
                        text = TuringPulsePlugin._extract_user_field(first)
                        if text is None:
                            text = json.dumps(first, default=str, ensure_ascii=False)
                    elif isinstance(first, str):
                        text = first
                    else:
                        text = repr(first)
                elif context.kwargs:
                    text = json.dumps(
                        {k: v for k, v in context.kwargs.items()},
                        default=str,
                        ensure_ascii=False,
                    )
                if text:
                    context.input_data = text[:MAX_FIELD_SIZE]
            except Exception:
                pass

        if context.output_data is None and result is not None and error is None:
            try:
                if isinstance(result, dict):
                    text = TuringPulsePlugin._extract_output_field(result)
                    if text is None:
                        text = json.dumps(result, default=str, ensure_ascii=False)
                elif isinstance(result, str):
                    text = result
                else:
                    text = repr(result)
                context.output_data = text[:MAX_FIELD_SIZE]
            except Exception:
                pass

    @staticmethod
    def _extract_user_field(d: dict) -> str | None:
        for key in TuringPulsePlugin._USER_INPUT_KEYS:
            val = d.get(key)
            if val and isinstance(val, str):
                return val
        return None

    _OUTPUT_KEYS = ("final_response", "action_result", "output", "result", "response", "answer", "completion")

    @staticmethod
    def _extract_output_field(d: dict) -> str | None:
        for key in TuringPulsePlugin._OUTPUT_KEYS:
            val = d.get(key)
            if val and isinstance(val, str):
                return val
        return None

    def _finalize(
        self,
        context: ExecutionContext,
        options: InstrumentationOptions,
        result: Any,
        error: BaseException | None,
        is_async: bool = False,
    ) -> None:
        payload, kpi_results, directive = self._finalize_common(context, options, result, error)
        try:
            self.client.emit_serialized_payload(payload)
        except Exception as exc:
            logger.warning("Failed to emit TuringPulse event: %s", type(exc).__name__)
        if not isinstance(error, GovernanceBlockedError):
            self._handle_governance(directive, context, kpi_results)
        if context.depth == 0 and context.fingerprint_builder:
            self._send_fingerprint(context, error)

    async def _finalize_async(
        self,
        context: ExecutionContext,
        options: InstrumentationOptions,
        result: Any,
        error: BaseException | None,
    ) -> None:
        payload, kpi_results, directive = self._finalize_common(context, options, result, error)
        try:
            await self.client.emit_serialized_payload_async(payload)
        except Exception as exc:
            logger.warning("Failed to emit TuringPulse event (async): %s", type(exc).__name__)
        if not isinstance(error, GovernanceBlockedError):
            await self._handle_governance_async(directive, context, kpi_results)
        if context.depth == 0 and context.fingerprint_builder:
            await self._send_fingerprint_async(context, error)

    # ------------------------------------------------------------------
    # Context building
    # ------------------------------------------------------------------

    def _build_context(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        options: InstrumentationOptions,
    ) -> ExecutionContext:
        trigger_key = self._namespaced_key(options.trigger_key) if options.trigger_key else None
        labels = self.config.merged_labels(options.labels)
        metadata = dict(options.metadata)
        metadata["agent.function"] = func.__name__
        metadata["agent.operation"] = options.operation or func.__name__
        parent = current_context()
        run_id = parent.run_id if parent else uuid4().hex
        parent_span_id = parent.span_id if parent else None
        depth = (parent.depth + 1) if parent else 0

        fingerprint_builder = None
        if self.config.fingerprint.enabled:
            fingerprint_builder = parent.fingerprint_builder if parent else FingerprintBuilder(self.config.fingerprint)

        workflow_name = options.workflow_name or self.config.workflow_name
        node_id = options.effective_agent_id or workflow_name

        pending_attachments: list = []
        if depth == 0:
            pending_attachments = self._drain_pending_attachments()

        return ExecutionContext(
            run_id=run_id,
            agent_id=node_id,
            operation=options.operation or func.__name__,
            trigger_key=trigger_key,
            hidden_entrypoint=options.hidden_entrypoint,
            labels=labels,
            metadata=metadata,
            args=args,
            kwargs=kwargs,
            parent_span_id=parent_span_id,
            depth=depth,
            fingerprint_builder=fingerprint_builder,
            workflow_id=node_id,
            workflow_name=workflow_name,
            agentic_pattern=options.agentic_pattern,
            attachments=pending_attachments,
        )

    @staticmethod
    def _drain_pending_attachments() -> list:
        """Collect attachments uploaded before any span was active."""
        try:
            from .attachments import drain_global_pending
            return drain_global_pending()
        except Exception:
            return []

    # ------------------------------------------------------------------
    # Governance
    # ------------------------------------------------------------------

    def _handle_governance(
        self,
        directive: GovernanceDirective | None,
        context: ExecutionContext,
        kpi_results: list[KPIResult],
    ) -> None:
        if not directive:
            return
        try:
            self.governance.enforce(directive, context, kpi_results)
        except Exception as exc:
            logger.warning("Failed to enforce governance directive: %s", type(exc).__name__)

    async def _handle_governance_async(
        self,
        directive: GovernanceDirective | None,
        context: ExecutionContext,
        kpi_results: list[KPIResult],
    ) -> None:
        if not directive:
            return
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._handle_governance, directive, context, kpi_results)

    # ------------------------------------------------------------------
    # Fingerprinting
    # ------------------------------------------------------------------

    def _record_node(self, context: ExecutionContext, func: Callable, args: tuple, kwargs: dict) -> None:
        func_name = func.__name__
        func_qualname = getattr(func, "__qualname__", func_name)
        explicit_type = context.metadata.get("node_type")
        node_type, llm_info = detect_node_type(func_name, func_qualname, args, kwargs)
        if explicit_type:
            node_type = explicit_type

        if not context.node_type:
            context.node_type = node_type
        if llm_info:
            if not context.model:
                context.model = llm_info.model
            if not context.provider:
                context.provider = llm_info.provider

        if not context.fingerprint_builder:
            return
        if llm_info:
            context.record_node(name=func_name, node_type=node_type, config=llm_info.config, prompt=llm_info.prompt)
        else:
            context.record_node(name=func_name, node_type=node_type)
        context.fingerprint_builder.push_parent(func_name)

    def _pop_node(self, context: ExecutionContext) -> None:
        if context.fingerprint_builder:
            context.fingerprint_builder.pop_parent()

    def _build_fingerprint_payload(self, context: ExecutionContext) -> Dict[str, Any]:
        assert context.fingerprint_builder is not None
        fingerprint_data = context.fingerprint_builder.get_fingerprint()
        return {
            "run_id": context.run_id,
            "workflow_id": context.workflow_id or context.agent_id,
            "fingerprint": fingerprint_data.model_dump(),
        }

    def _send_fingerprint(self, context: ExecutionContext, error: Optional[BaseException]) -> None:
        if not self.config.fingerprint.enabled or not context.fingerprint_builder:
            return
        if error and not self.config.fingerprint.send_on_failure:
            return
        payload = self._build_fingerprint_payload(context)
        if self.config.fingerprint.send_async:
            threading.Thread(target=self._emit_fingerprint, args=(payload,), daemon=True).start()
        else:
            self._emit_fingerprint(payload)

    async def _send_fingerprint_async(self, context: ExecutionContext, error: Optional[BaseException]) -> None:
        if not self.config.fingerprint.enabled or not context.fingerprint_builder:
            return
        if error and not self.config.fingerprint.send_on_failure:
            return
        payload = self._build_fingerprint_payload(context)
        loop = asyncio.get_running_loop()
        if self.config.fingerprint.send_async:
            asyncio.ensure_future(loop.run_in_executor(None, self._emit_fingerprint, payload))
        else:
            await loop.run_in_executor(None, self._emit_fingerprint, payload)

    def _emit_fingerprint(self, payload: Dict[str, Any]) -> None:
        try:
            result = self.client.post_fingerprint(payload)
            if result:
                logger.debug("Fingerprint sent for run %s", payload.get("run_id"))
        except Exception as exc:
            logger.warning("Failed to send fingerprint: %s", type(exc).__name__)

    # ------------------------------------------------------------------
    # Custom change registration
    # ------------------------------------------------------------------

    def register_custom_change(
        self,
        change_type: str,
        details: Optional[Dict[str, Any]] = None,
        workflow_id: Optional[str] = None,
        detected_at: Optional[str] = None,
    ) -> bool:
        """Register a custom change event for root cause analysis."""
        context = current_context()
        wf_id = workflow_id or (context.workflow_id or context.agent_id if context else None)
        if not wf_id:
            logger.warning("register_custom_change: No workflow_id provided and no active context")
            return False
        payload: Dict[str, Any] = {
            "workflow_id": wf_id,
            "change_type": change_type,
            "change_details": details or {},
            "source": "sdk",
            "metadata": {},
        }
        if detected_at:
            payload["detected_at"] = detected_at
        try:
            result = self.client.post_custom_change(payload)
            if result and result.get("success"):
                logger.debug("Registered custom change: type=%s, workflow=%s", change_type, wf_id)
                return True
            logger.warning("Failed to register custom change: unexpected response")
            return False
        except Exception as exc:
            logger.warning("Failed to register custom change: %s", type(exc).__name__)
            return False

    async def register_custom_change_async(
        self,
        change_type: str,
        details: Optional[Dict[str, Any]] = None,
        workflow_id: Optional[str] = None,
        detected_at: Optional[str] = None,
    ) -> bool:
        """Async version of register_custom_change."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None, lambda: self.register_custom_change(change_type, details, workflow_id, detected_at)
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _namespaced_key(self, key: str) -> str:
        return key if ":" in key else f"{self.config.trigger_namespace}:{key}"


def init(config: TuringPulseConfig | None = None, **overrides) -> TuringPulsePlugin:
    """Initialise the TuringPulse SDK.

    No network calls are made during init — the SDK simply stores the
    configuration locally.  The backend resolves tenant_id and project_id
    from the API key when the first telemetry payload is sent.

    Usage::

        import turingpulse_sdk

        turingpulse_sdk.init(
            api_key="sk_...",
            workflow_name="customer-support",
        )
    """
    global _PLUGIN
    if config is None:
        config = TuringPulseConfig(**overrides)
    elif overrides:
        merged = config.model_dump()
        merged.update(overrides)
        config = TuringPulseConfig(**merged)

    _PLUGIN = TuringPulsePlugin(config)
    flush_pending(_PLUGIN)
    return _PLUGIN


def get_plugin() -> TuringPulsePlugin:
    global _PLUGIN
    if _PLUGIN is None:
        with _INIT_LOCK:
            if _PLUGIN is None:
                api_key = os.getenv("TP_API_KEY", "")
                if api_key:
                    logger.info("Auto-initializing TuringPulse SDK from environment variables")
                    init()
                else:
                    raise PluginNotInitializedError(
                        "TuringPulse plugin is not initialized. "
                        "Call turingpulse_sdk.init(...) once or set TP_API_KEY env var."
                    )
    assert _PLUGIN is not None
    return _PLUGIN
