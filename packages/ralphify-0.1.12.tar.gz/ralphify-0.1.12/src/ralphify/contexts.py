"""Discover and run dynamic data contexts injected before each iteration.

Contexts live in ``.ralphify/contexts/<name>/`` and provide fresh data to the
prompt each loop — for example recent git history or current test status.
A context can run a command/script, provide static text, or both.
"""

from dataclasses import dataclass
from pathlib import Path

from ralphify._discovery import PrimitiveEntry, discover_enabled, discover_local_primitives, discover_primitives, find_run_script
from ralphify._frontmatter import CONTEXT_MARKER
from ralphify._output import truncate_output
from ralphify._runner import run_command
from ralphify.resolver import resolve_placeholders


_DEFAULT_TIMEOUT = 30

@dataclass
class Context:
    """A dynamic data context discovered from ``.ralphify/contexts/<name>/CONTEXT.md``.

    A context may have a *command* or *script* (whose stdout is captured),
    *static_content* (the body text from CONTEXT.md), or both.  When both
    are present the static content appears first, followed by the command output.
    """

    name: str
    path: Path
    command: str | None = None
    script: Path | None = None
    timeout: int = _DEFAULT_TIMEOUT
    enabled: bool = True
    static_content: str = ""


@dataclass
class ContextResult:
    """Outcome of running a single :class:`Context`.

    *output* contains the command's stdout (empty string for static-only
    contexts).  *success* is ``True`` when the command exits with code 0
    or when no command was configured.
    """

    context: Context
    output: str
    success: bool
    timed_out: bool = False

    def render(self) -> str:
        """Combine static content and truncated command output into prompt text.

        This is the single source of truth for how a context result appears
        in the assembled prompt.  Used by :func:`resolve_contexts` to build
        the placeholder lookup dict.
        """
        parts: list[str] = []
        if self.context.static_content:
            parts.append(self.context.static_content)
        output = truncate_output(self.output)
        if output.strip():
            parts.append(output.strip())
        return "\n".join(parts)


def _context_from_entry(prim: PrimitiveEntry) -> Context:
    """Convert a :class:`PrimitiveEntry` to a :class:`Context`."""
    return Context(
        name=prim.path.name,
        path=prim.path,
        command=prim.frontmatter.get("command"),
        script=find_run_script(prim.path),
        timeout=prim.frontmatter.get("timeout", _DEFAULT_TIMEOUT),
        enabled=prim.frontmatter.get("enabled", True),
        static_content=prim.body,
    )


def discover_contexts(root: Path = Path(".")) -> list[Context]:
    """Scan ``.ralphify/contexts/`` for subdirectories containing a ``CONTEXT.md``.

    Returns all discovered contexts (both enabled and disabled) sorted
    alphabetically by name.  The caller is responsible for filtering by
    ``enabled`` before execution.
    """
    return [_context_from_entry(prim) for prim in discover_primitives(root, "contexts", CONTEXT_MARKER)]


def discover_contexts_local(ralph_dir: Path) -> list[Context]:
    """Scan ``ralph_dir/contexts/`` for ralph-scoped contexts.

    Same construction logic as :func:`discover_contexts` but reads from
    a ralph directory instead of the global ``.ralphify/contexts/``.
    """
    return [_context_from_entry(prim) for prim in discover_local_primitives(ralph_dir, "contexts", CONTEXT_MARKER)]


def discover_enabled_contexts(
    root: Path,
    ralph_dir: Path | None = None,
    global_names: list[str] | None = None,
) -> list[Context]:
    """Discover contexts, merge local overrides, and return only enabled ones.

    When *global_names* is ``None``, no global contexts are included.
    Pass a list of names to select specific globals from the library.
    """
    return discover_enabled(
        root, ralph_dir, discover_contexts, discover_contexts_local,
        global_names=global_names, kind="contexts",
    )


def _build_env(
    ralph_name: str | None,
    user_args: dict[str, str] | None,
) -> dict[str, str] | None:
    """Build the environment dict for context/check subprocesses."""
    env: dict[str, str] = {}
    if ralph_name:
        env["RALPH_NAME"] = ralph_name
    if user_args:
        for key, value in user_args.items():
            env_key = "RALPH_ARG_" + key.upper().replace("-", "_")
            env[env_key] = value
    return env or None


def run_context(
    context: Context,
    project_root: Path,
    ralph_name: str | None = None,
    user_args: dict[str, str] | None = None,
) -> ContextResult:
    """Run a single context and return the result.

    Static-only contexts (no script or command) return immediately with
    ``success=True`` and empty output.  The static content is combined
    with command output later during prompt resolution.

    When *ralph_name* is set, a ``RALPH_NAME`` environment variable is
    passed to the subprocess so scripts can read per-ralph state.

    When *user_args* is set, ``RALPH_ARG_<KEY>`` environment variables
    are passed for each user argument.
    """
    if not context.script and not context.command:
        # Static-only context, no command to run
        return ContextResult(context=context, output="", success=True)

    env = _build_env(ralph_name, user_args)
    r = run_command(
        script=context.script,
        command=context.command,
        cwd=project_root,
        timeout=context.timeout,
        env=env,
    )
    return ContextResult(
        context=context,
        output=r.output,
        success=r.success,
        timed_out=r.timed_out,
    )


def run_all_contexts(
    contexts: list[Context],
    project_root: Path,
    ralph_name: str | None = None,
    user_args: dict[str, str] | None = None,
) -> list[ContextResult]:
    """Run every context sequentially and return all results.

    Each context's command (or script) executes with *project_root* as the
    working directory.  Static-only contexts return immediately.  Results
    are passed to :func:`resolve_contexts` for prompt injection.

    When *ralph_name* is set, it is forwarded to each context subprocess
    as the ``RALPH_NAME`` environment variable.

    When *user_args* is set, ``RALPH_ARG_<KEY>`` environment variables
    are forwarded to each context subprocess.
    """
    return [run_context(ctx, project_root, ralph_name, user_args) for ctx in contexts]


def resolve_contexts(prompt: str, results: list[ContextResult]) -> str:
    """Replace context placeholders in a prompt string.

    Each context result is rendered via :meth:`ContextResult.render`,
    then injected into the prompt via :func:`resolve_placeholders`.

    Callers are responsible for passing only the results they want
    resolved (the engine pre-filters via ``_rediscover_primitives``).

    Only named placeholders are supported:
    - {{ contexts.<name> }} → specific context content
    - Contexts not referenced by name are excluded
    """
    available: dict[str, str] = {}
    for r in results:
        rendered = r.render()
        if rendered:
            available[r.context.name] = rendered

    return resolve_placeholders(prompt, available, "contexts")
