"""CLI commands for ralphify — init, run, and scaffold new primitives.

This is the main module.  The ``run`` command delegates to the engine module
for the core autonomous loop.  Terminal rendering of events is handled by
:class:`~ralphify._console_emitter.ConsoleEmitter`.
"""

import os
import shutil
import sys
import tomllib
import uuid
from pathlib import Path
from typing import NoReturn

import typer
from rich.console import Console

from ralphify import __version__
from ralphify._console_emitter import ConsoleEmitter
from ralphify._frontmatter import CONFIG_FILENAME, parse_frontmatter
from ralphify._run_types import RunConfig, RunState
from ralphify.engine import run_loop
from ralphify.ralphs import resolve_ralph_source
from ralphify.detector import detect_project
from ralphify._templates import (
    ROOT_RALPH_TEMPLATE,
    RALPH_TOML_TEMPLATE,
)

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

_console = Console(highlight=False)
rprint = _console.print

app = typer.Typer()


def _exit_error(msg: str) -> NoReturn:
    """Print an error in red and exit with code 1."""
    rprint(f"[red]{msg}[/red]")
    raise typer.Exit(1)


BANNER_LINES = [
    "██████╗░░█████╗░██╗░░░░░██████╗░██╗░░██╗██╗███████╗██╗░░░██╗",
    "██╔══██╗██╔══██╗██║░░░░░██╔══██╗██║░░██║██║██╔════╝╚██╗░██╔╝",
    "██████╔╝███████║██║░░░░░██████╔╝███████║██║█████╗░░░╚████╔╝░",
    "██╔══██╗██╔══██║██║░░░░░██╔═══╝░██╔══██║██║██╔══╝░░░░╚██╔╝░░",
    "██║░░██║██║░░██║███████╗██║░░░░░██║░░██║██║██║░░░░░░░░██║░░░",
    "╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝╚═╝░░░░░╚═╝░░╚═╝╚═╝╚═╝░░░░░░░░╚═╝░░░",
]

TAGLINE = "Stop stressing over not having an agent running. Ralph is always running"


BANNER_COLORS = [
    "#8B6CF0",  # light violet
    "#A78BF5",  # soft violet
    "#D4A0E0",  # pink-violet transition
    "#E8956B",  # warm transition
    "#E87B4A",  # orange accent
    "#E06030",  # deep orange
]


def _print_banner() -> None:
    width = shutil.get_terminal_size().columns
    art_width = max(len(line) for line in BANNER_LINES)
    pad = max(0, (width - art_width) // 2)
    prefix = " " * pad

    rprint()
    for line, color in zip(BANNER_LINES, BANNER_COLORS):
        rprint(f"[bold {color}]{prefix}{line}[/bold {color}]")
    rprint()
    rprint(f"[italic #A78BF5]{TAGLINE:^{width}}[/italic #A78BF5]")
    rprint()
    help_text = "Run 'ralph --help' for usage information"
    rprint(f"[dim]{help_text:^{width}}[/dim]")
    star_text = "⭐ Star us on GitHub: https://github.com/computerlovetech/ralphify"
    rprint(f"[dim]{star_text:^{width}}[/dim]")
    rprint()


def _version_callback(value: bool) -> None:
    if value:
        rprint(f"ralphify {__version__}")
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main_callback(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", "-V", help="Show version and exit.", callback=_version_callback, is_eager=True),
) -> None:
    """Stop stressing over not having an agent running. Ralph is always running."""
    if ctx.invoked_subcommand is None:
        _print_banner()
        rprint(ctx.get_help())
        raise typer.Exit()


def _load_config() -> dict:
    """Load and return the ralph.toml config, exiting if not found."""
    config_path = Path(CONFIG_FILENAME)
    if not config_path.exists():
        _exit_error(f"{CONFIG_FILENAME} not found. Run 'ralph init' first.")
    with open(config_path, "rb") as f:
        return tomllib.load(f)


@app.command()
def init(
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing config."),
) -> None:
    """Initialize ralph config and prompt template."""
    config_path = Path(CONFIG_FILENAME)
    prompt_path = Path("RALPH.md")

    project_type = detect_project()

    if config_path.exists() and not force:
        rprint(f"[yellow]{CONFIG_FILENAME} already exists. Use --force to overwrite.[/yellow]")
        raise typer.Exit(1)

    config_path.write_text(RALPH_TOML_TEMPLATE)
    rprint(f"[green]Created {CONFIG_FILENAME}[/green]")

    if prompt_path.exists():
        rprint("[dim]RALPH.md already exists, skipping.[/dim]")
    else:
        prompt_path.write_text(ROOT_RALPH_TEMPLATE)
        rprint("[green]Created RALPH.md[/green]")

    rprint(f"\nDetected project type: [bold]{project_type}[/bold]")
    rprint("Edit RALPH.md to customize your agent's behavior.")


@app.command()
def new(
    name: str | None = typer.Argument(None, help="Name for the new ralph. If omitted, the agent will help you choose."),
) -> None:
    """Create a new ralph with AI-guided setup."""
    from ralphify._skills import build_agent_command, detect_agent, install_skill

    try:
        agent = detect_agent()
    except RuntimeError as e:
        _exit_error(str(e))

    try:
        install_skill("new-ralph", agent.name)
    except RuntimeError as e:
        _exit_error(str(e))

    cmd = build_agent_command(agent.name, "new-ralph", name)
    os.execvp(cmd[0], cmd)


def _parse_user_args(
    raw_args: list[str],
    declared_names: list[str] | None,
) -> dict[str, str]:
    """Parse extra CLI args into a dict of user arguments.

    Supports ``--name value`` (named) and positional args mapped to
    *declared_names* from frontmatter ``args: [...]``.

    Raises :class:`typer.BadParameter` on invalid input.
    """
    result: dict[str, str] = {}
    positional_index = 0
    i = 0
    while i < len(raw_args):
        token = raw_args[i]
        if token.startswith("--"):
            name = token[2:]
            if i + 1 >= len(raw_args):
                raise typer.BadParameter(f"Flag '--{name}' requires a value.")
            result[name] = raw_args[i + 1]
            i += 2
        else:
            # Positional arg
            if not declared_names:
                raise typer.BadParameter(
                    f"Positional argument '{token}' requires args declared in RALPH.md frontmatter. "
                    f"Use --name value syntax or add 'args: [...]' to your RALPH.md."
                )
            if positional_index >= len(declared_names):
                raise typer.BadParameter(
                    f"Too many positional arguments. Expected at most {len(declared_names)} "
                    f"({', '.join(declared_names)})."
                )
            result[declared_names[positional_index]] = token
            positional_index += 1
            i += 1
    return result


def _build_run_config(
    toml_config: dict,
    ralph_arg: str | None,
    max_iterations: int | None,
    stop_on_error: bool,
    delay: float,
    log_dir: str | None,
    timeout: float | None,
    extra_args: list[str] | None = None,
) -> RunConfig:
    """Validate toml config, resolve the ralph source, and build a RunConfig.

    Exits with an error message for invalid config, missing files, or
    missing agent command.  Extracted from ``run()`` so the command body
    reads as a clean three-step flow: load config → build config → run.
    """
    agent = toml_config.get("agent")
    if not isinstance(agent, dict):
        _exit_error(f"Missing [agent] section in {CONFIG_FILENAME}.")
    command = agent.get("command")
    if not command:
        _exit_error(f"Missing 'command' in [agent] section of {CONFIG_FILENAME}.")
    args = agent.get("args", [])

    try:
        source = resolve_ralph_source(
            ralph_arg=ralph_arg,
            toml_ralph=agent.get("ralph", "RALPH.md"),
        )
    except ValueError as e:
        _exit_error(str(e))

    try:
        ralph_text = Path(source.file_path).read_text()
    except FileNotFoundError:
        _exit_error(f"Prompt file '{source.file_path}' not found.")

    if not shutil.which(command):
        _exit_error(f"Agent command '{command}' not found on PATH.")

    # Extract declared global primitive dependencies from ralph frontmatter
    ralph_fm, _ = parse_frontmatter(ralph_text)

    # Parse user args against declared arg names from frontmatter
    declared_names = ralph_fm.get("args")
    ralph_args: dict[str, str] = {}
    if extra_args:
        ralph_args = _parse_user_args(extra_args, declared_names)

    return RunConfig(
        command=command,
        args=args,
        ralph_file=source.file_path,
        ralph_name=source.ralph_name,
        max_iterations=max_iterations,
        delay=delay,
        timeout=timeout,
        stop_on_error=stop_on_error,
        log_dir=log_dir,
        global_checks=ralph_fm.get("checks"),
        global_contexts=ralph_fm.get("contexts"),
        ralph_args=ralph_args,
    )


@app.command(context_settings={"allow_extra_args": True, "allow_interspersed_args": True, "ignore_unknown_options": True})
def run(
    ctx: typer.Context,
    ralph: str | None = typer.Argument(None, help="Named ralph from .ralphify/ralphs/."),
    n: int | None = typer.Option(None, "-n", help="Max number of iterations. Infinite if not set."),
    stop_on_error: bool = typer.Option(False, "--stop-on-error", "-s", help="Stop if the agent exits with non-zero."),
    delay: float = typer.Option(0, "--delay", "-d", help="Seconds to wait between iterations."),
    log_dir: str | None = typer.Option(None, "--log-dir", "-l", help="Save iteration output to log files in this directory."),
    timeout: float | None = typer.Option(None, "--timeout", "-t", help="Max seconds per iteration. Kill agent if exceeded."),
) -> None:
    """Run the autonomous coding loop.

    Each iteration: read RALPH.md, resolve context placeholders, append
    any check failures from the previous iteration, pipe the assembled
    prompt to the agent, then run checks.
    Repeat until *n* iterations or Ctrl+C.

    Extra flags (--name value) and positional args are passed as user
    arguments to the ralph template.  Use {{ args.name }} placeholders
    in RALPH.md to reference them.
    """
    # When ignore_unknown_options is True, Click may capture a --flag as
    # the ralph positional argument.  Detect this and move it back to extra args.
    extra = list(ctx.args)
    if ralph and ralph.startswith("--"):
        extra = [ralph] + extra
        ralph = None

    toml_config = _load_config()
    config = _build_run_config(
        toml_config, ralph, n, stop_on_error, delay, log_dir, timeout,
        extra_args=extra or None,
    )

    if log_dir:
        rprint(f"[dim]Logging output to {log_dir}/[/dim]")

    state = RunState(run_id=uuid.uuid4().hex[:12])
    emitter = ConsoleEmitter(_console)

    run_loop(config, state, emitter)


