---
description: Install ralphify, set up your first autonomous coding loop with checks and contexts, and run a self-healing AI agent in 10 minutes.
---

# Getting Started

This tutorial walks through setting up ralphify on a project, adding checks and contexts, and running a productive autonomous loop. By the end, you'll have a self-healing coding loop that validates its own work.

## Prerequisites

- **Python 3.11+**
- **An AI coding agent CLI** — this tutorial uses Claude Code, but ralphify works with [any agent that accepts piped input](agents.md)
- **A project with a test suite** (we'll use this for the feedback loop)

## Step 1: Install ralphify

```bash
uv tool install ralphify
```

Verify it's working:

```bash
ralph --version
```

## Step 2: Initialize your project

Navigate to your project and run:

```bash
ralph init
```

This creates two files:

**`ralph.toml`** — configuration for the loop:

```toml
[agent]
command = "claude"
args = ["-p", "--dangerously-skip-permissions"]
ralph = "RALPH.md"
```

!!! info "What does `--dangerously-skip-permissions` do?"
    Claude Code normally asks for your approval before running shell commands, editing files, or making git commits. The `--dangerously-skip-permissions` flag disables these interactive prompts so the agent can work autonomously without waiting for input. The `-p` flag enables non-interactive ("print") mode, which reads the prompt from stdin instead of opening a chat session.

    This is safe to use when ralphify is the only thing running the agent, because **checks** act as your guardrails — they validate the agent's work after each iteration and feed failures back for the agent to fix.

**`RALPH.md`** — the prompt that gets piped to the agent each iteration. The default is a generic starting point — you'll customize it next.

## Step 3: Write your ralph

Replace the contents of `RALPH.md` with a prompt tailored to your project. Here's an example for a Python project with a TODO list:

```markdown
# Prompt

You are an autonomous coding agent running in a loop. Each iteration
starts with a fresh context. Your progress lives in the code and git.

Read TODO.md for the current task list. Pick the top uncompleted task,
implement it fully, then mark it done.

## Rules

- One task per iteration
- No placeholder code — full, working implementations only
- Run `uv run pytest -x` before committing
- Commit with a descriptive message like `feat: add X` or `fix: resolve Y`
- Mark the completed task in TODO.md
```

## Step 4: Do a test run

Before setting up checks and contexts, verify the basic loop works:

```bash
ralph run -n 1 --log-dir ralph_logs
```

This runs a single iteration and saves the output to `ralph_logs/`. Review the log to see what the agent did:

```bash
ls ralph_logs/
cat ralph_logs/001_*.log
```

!!! tip "Add `ralph_logs/` to `.gitignore`"
    Log files are useful for debugging but shouldn't be committed. Add them to your `.gitignore`:

    ```bash
    echo "ralph_logs/" >> .gitignore
    ```

If the agent produced useful work, you're ready to add guardrails.

## Step 5: Add a test check

Checks run **after** each iteration to validate the agent's work. If a check fails, its output is fed into the next iteration so the agent can fix the problem.

Create a check that runs your test suite:

```bash
mkdir -p .ralphify/checks/tests
```

Create `.ralphify/checks/tests/CHECK.md`:

```markdown
---
command: uv run pytest -x
timeout: 120
enabled: true
---
Fix all failing tests. Do not skip or delete tests.
Do not add `# type: ignore` or `# noqa` comments.
```

The text below the frontmatter is the **failure instruction** — it gets included in the prompt when the check fails, telling the agent how to handle the failure.

## Step 6: Add a lint check

Add a second check for linting:

```bash
mkdir -p .ralphify/checks/lint
```

Create `.ralphify/checks/lint/CHECK.md`:

```markdown
---
command: uv run ruff check .
timeout: 60
enabled: true
---
Fix all lint errors. Do not suppress warnings with noqa comments.
```

## Step 7: Add a context

Contexts inject dynamic data into the prompt before each iteration. A useful default is recent git history — it helps the agent understand what's already been done.

```bash
mkdir -p .ralphify/contexts/git-log
```

Create `.ralphify/contexts/git-log/CONTEXT.md`:

```markdown
---
command: git log --oneline -10
timeout: 10
enabled: true
---
## Recent commits
```

The command runs each iteration and its output is appended to the prompt. The body text ("## Recent commits") appears above the command output as a label.

!!! tip "Use `ralph new` for AI-guided setup"
    Instead of creating primitive files manually, you can run `ralph new` to launch an AI-guided session that creates a complete ralph — prompt, checks, and contexts — via conversation with your agent.

### Declare your primitives and place the context

Checks and contexts must be **declared** in your ralph file's frontmatter before they'll run. Now that you've created all three primitives, update `RALPH.md` to declare them and place the context:

```markdown
---
checks: [tests, lint]
contexts: [git-log]
---

# Prompt

{{ contexts.git-log }}

You are an autonomous coding agent running in a loop. Each iteration
starts with a fresh context. Your progress lives in the code and git.

Read TODO.md for the current task list. Pick the top uncompleted task,
implement it fully, then mark it done.

## Rules

- One task per iteration
- No placeholder code — full, working implementations only
- Run `uv run pytest -x` before committing
- Commit with a descriptive message like `feat: add X` or `fix: resolve Y`
- Mark the completed task in TODO.md
```

The `checks` and `contexts` fields in the frontmatter tell ralphify which global primitives to use. The `{{ contexts.git-log }}` placeholder controls where the context output appears in the prompt — contexts not referenced by a placeholder are excluded.

## Step 8: Run the loop

Start with a few iterations to verify things work as expected:

```bash
ralph run -n 3 --log-dir ralph_logs
```

Watch the output. After each iteration, you'll see check results:

```
── Iteration 1 ──
✓ Iteration 1 completed (45.2s) → ralph_logs/001_20250115-142301.log
  Checks: 2 passed
    ✓ lint
    ✓ tests
```

If a check fails, the next iteration automatically gets the failure details:

```
── Iteration 2 ──
✗ Iteration 2 failed with exit code 1 (23.1s)
  Checks: 1 passed, 1 failed
    ✓ lint
    ✗ tests (exit 1)

── Iteration 3 ──
```

The agent in iteration 3 receives the test failure output and the failure instruction ("Fix all failing tests..."), so it can fix the problem.

Once you're confident the loop works, drop the `-n 3` to let it run indefinitely. Press `Ctrl+C` to stop.

## Next steps

- [Writing Prompts](writing-prompts.md) — patterns for writing effective autonomous loop prompts
- [Cookbook](cookbook.md) — copy-pasteable setups for documentation and test coverage loops
- [How it Works](how-it-works.md) — what happens inside each iteration
- [Primitives](primitives.md) — full reference for checks, contexts, and named ralphs
- [CLI Reference](cli.md) — all commands and options
