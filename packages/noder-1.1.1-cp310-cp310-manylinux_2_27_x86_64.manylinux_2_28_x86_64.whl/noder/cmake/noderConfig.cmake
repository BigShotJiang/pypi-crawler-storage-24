
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was noderConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

if("ON" STREQUAL "ON" AND WIN32)
    set(_noder_hdf5_dll "${PACKAGE_PREFIX_DIR}/noder/hdf5.dll")
    set(_noder_hdf5_implib "${PACKAGE_PREFIX_DIR}/noder/hdf5.lib")
    if(EXISTS "${_noder_hdf5_dll}" AND EXISTS "${_noder_hdf5_implib}")
        if(NOT TARGET hdf5::hdf5-shared)
            add_library(hdf5::hdf5-shared SHARED IMPORTED)
            set_target_properties(hdf5::hdf5-shared PROPERTIES
                IMPORTED_IMPLIB "${_noder_hdf5_implib}"
                IMPORTED_LOCATION "${_noder_hdf5_dll}"
            )
        endif()
    else()
        find_dependency(HDF5 REQUIRED COMPONENTS C)
    endif()
endif()

include("${CMAKE_CURRENT_LIST_DIR}/noderTargets.cmake")

set_and_check(noder_PACKAGE_DIR "${PACKAGE_PREFIX_DIR}/noder")
set_and_check(noder_INCLUDE_DIR "${PACKAGE_PREFIX_DIR}/noder/include")
set(noder_CMAKE_DIR "${CMAKE_CURRENT_LIST_DIR}")

if(TARGET noder::core_shared AND NOT TARGET noder::core_library)
    add_library(noder::core_library INTERFACE IMPORTED)
    target_link_libraries(noder::core_library INTERFACE noder::core_shared)
endif()
