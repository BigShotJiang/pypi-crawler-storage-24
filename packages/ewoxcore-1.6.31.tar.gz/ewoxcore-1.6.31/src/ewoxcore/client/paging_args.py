from typing import Any, Callable, Generic, List, Dict, Text, Optional, Tuple, Union, TypeVar, Type
from ewoxcore.decorators.serializable import Serializable
from ewoxcore.utils.string_util import StringUtil
from ewoxcore.utils.number_util import NumberUtil

@Serializable
class PagingArgs():
    def __init__(self, data:Optional[dict[str, any]]=None) -> None:
        if data is None:
            self.search: str = ""
            self.skip: int = 0
            self.num: int = 10
            self.sortField: str = ""
            self.sortDirection: str = "asc"
        else:
            self.search: str = StringUtil.get_safe_string(data.get("search", ""))
            self.skip: int = NumberUtil.get_safe_int(data.get("skip", 0))
            self.num: int = NumberUtil.get_safe_int(data.get("num", 10))
            self.sortField: str = StringUtil.get_safe_string(data.get("sortField", ""))
            self.sortDirection: str = StringUtil.get_safe_string(data.get("sortDirection", "asc"))


    def to_dict(self) -> dict[str, Any]:
        return {
            "search": self.search,
            "skip": self.skip,
            "num": self.num,
            "sortField": self.sortField,
            "sortDir": self.sortDirection,
        }
