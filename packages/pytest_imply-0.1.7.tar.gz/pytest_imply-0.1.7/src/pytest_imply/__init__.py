"""pytest-imply — skip tests implied by stronger ones."""

from importlib.metadata import version, PackageNotFoundError

from pytest_imply.plugin import PytestImplyWarning

try:
    __version__ = version("pytest-imply")
except PackageNotFoundError:
    __version__ = "unknown"

__all__ = ["PytestImplyWarning", "__version__"]
