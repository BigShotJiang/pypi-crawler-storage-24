"""pytest configuration for pytest-imply tests."""

pytest_plugins = ["pytester"]
