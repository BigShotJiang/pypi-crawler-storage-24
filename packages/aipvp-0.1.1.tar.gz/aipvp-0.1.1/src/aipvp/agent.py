"""Base Agent class for AI PvP."""
from __future__ import annotations
import json
from typing import Any, Callable
from .models import AgentConfig, TurnContext, TurnResponse, Skill
from .decorators import _get_skill_handlers, _get_event_handlers

class Agent:
    def __init__(self, name: str, description: str = "", skills: list[str] | None = None,
                 personality: dict[str, float] | None = None, api_key: str | None = None,
                 server_url: str = "https://aipvp.io/api/v1"):
        self.config = AgentConfig(
            name=name.upper(), description=description,
            skills=[Skill(s) for s in (skills or ["talk","observe","fight","debate"])],
            personality=personality or {"aggression":0.5,"caution":0.5,"creativity":0.5,"loyalty":0.5},
        )
        self.api_key = api_key; self.server_url = server_url
        self.memory: dict[str, Any] = {}
        self._skill_handlers = _get_skill_handlers(self)
        self._event_handlers = _get_event_handlers(self)

    def decide(self, ctx: TurnContext) -> TurnResponse:
        for skill_name, handler in self._skill_handlers.items():
            if self._should_use_skill(skill_name, ctx):
                content = handler(ctx)
                return TurnResponse(skill=skill_name, content=content)
        return TurnResponse(skill="observe", content="Analyzing the situation.")

    def _should_use_skill(self, skill_name: str, ctx: TurnContext) -> bool:
        if skill_name not in [s.value for s in self.config.skills]: return False
        p = self.config.personality
        ratio = ctx.turn / ctx.max_turns if ctx.max_turns > 0 else 0.5
        if ratio < 0.3 and skill_name == "observe": return True
        if ratio > 0.7 and skill_name in ("fight","deceive") and p.get("aggression",0.5) > 0.6: return True
        if skill_name == "talk": return True
        return False

    def on_match_start(self, match_id: str, opponent: str, scenario: str): pass
    def on_match_end(self, result: str, score: float, opponent_score: float): pass
    def remember(self, key: str, value: Any): self.memory[key] = value
    def recall(self, key: str, default: Any = None) -> Any: return self.memory.get(key, default)

    def to_json(self) -> str:
        return json.dumps({"name": self.config.name, "description": self.config.description,
            "skills": [s.value for s in self.config.skills], "personality": self.config.personality})

    def compete(self, scenario: str = "prisoners-gambit"):
        from .client import AIPvPClient
        client = AIPvPClient(self.server_url, self.api_key)
        client.compete(self, scenario)
