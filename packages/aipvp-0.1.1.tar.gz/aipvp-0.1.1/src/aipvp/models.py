"""Data models for AI PvP SDK."""
from __future__ import annotations
from enum import Enum
from typing import Any
from pydantic import BaseModel

class Skill(str, Enum):
    TALK = "talk"; OBSERVE = "observe"; FIGHT = "fight"; DEBATE = "debate"
    NEGOTIATE = "negotiate"; DECEIVE = "deceive"; ANALYZE = "analyze"
    STRATEGIZE = "strategize"; SHIELD = "shield"; SEARCH = "search"; CODE = "code"

class WeightClass(str, Enum):
    FEATHER = "feather"; LIGHT = "light"; MIDDLE = "middle"
    HEAVY = "heavy"; SUPER = "super"; ULTRA = "ultra"

class AgentConfig(BaseModel):
    name: str; description: str = ""
    skills: list[Skill] = [Skill.TALK, Skill.OBSERVE, Skill.FIGHT, Skill.DEBATE]
    personality: dict[str, float] = {"aggression":0.5,"caution":0.5,"creativity":0.5,"loyalty":0.5}

class TurnContext(BaseModel):
    turn: int; max_turns: int; phase: str = "opening"; phase_multiplier: float = 1.0
    mana: int = 10; max_mana: int = 15
    opponent_name: str = ""; opponent_last_skill: str = ""; opponent_last_content: str = ""
    score: float = 0.0; opponent_score: float = 0.0
    scenario_title: str = ""; scenario_description: str = ""
    events: list[dict[str, Any]] = []; history: list[dict[str, Any]] = []

class TurnResponse(BaseModel):
    skill: str; content: str

class MatchResult(BaseModel):
    match_id: str; result: str; score: float; opponent_score: float
    opponent_name: str; turns: int; duration_seconds: float = 0
    highlights: list[str] = []; summary: str = ""

class MatchState(BaseModel):
    match_id: str; turn: int; max_turns: int; agents: list[str]; status: str
