"""HTTP + WebSocket client for AI PvP server."""
from __future__ import annotations
import json, asyncio
from typing import TYPE_CHECKING
import httpx
if TYPE_CHECKING:
    from .agent import Agent

class AIPvPClient:
    def __init__(self, base_url: str = "https://aipvp.io/api/v1", api_key: str | None = None):
        self.base_url = base_url.rstrip("/"); self.api_key = api_key
        self._http = httpx.Client(base_url=self.base_url,
            headers={"Authorization": f"Bearer {api_key}"} if api_key else {}, timeout=30.0)

    def login(self, email: str, password: str) -> dict:
        resp = self._http.post("/auth/login", json={"email": email, "password": password})
        resp.raise_for_status(); data = resp.json()
        self._http.headers["Authorization"] = f"Bearer {data['token']}"; self.api_key = data["token"]; return data

    def register(self, email: str, password: str, display_name: str) -> dict:
        resp = self._http.post("/auth/register", json={"email": email, "password": password, "display_name": display_name})
        resp.raise_for_status(); data = resp.json()
        self._http.headers["Authorization"] = f"Bearer {data['token']}"; self.api_key = data["token"]; return data

    def register_agent(self, agent: "Agent") -> str:
        resp = self._http.post("/agents", json={"name": agent.config.name, "description": agent.config.description,
            "skills": [s.value for s in agent.config.skills], "personality": agent.config.personality})
        resp.raise_for_status(); return resp.json()["id"]

    def list_agents(self) -> list[dict]:
        resp = self._http.get("/agents"); resp.raise_for_status(); return resp.json()

    def start_match(self, agent_id: str, scenario: str = "prisoners-gambit") -> dict:
        resp = self._http.post("/matches", json={"agent_id": agent_id, "scenario_id": scenario})
        resp.raise_for_status(); return resp.json()

    def get_replay(self, match_id: str) -> list[dict]:
        resp = self._http.get(f"/matches/{match_id}/replay"); resp.raise_for_status(); return resp.json()

    def get_history(self, agent_id: str) -> list[dict]:
        resp = self._http.get(f"/agents/{agent_id}/history"); resp.raise_for_status(); return resp.json()

    def join_queue(self, agent_id: str, auto_battle: bool = False) -> dict:
        resp = self._http.post("/matchmaking/queue", json={"agent_id": agent_id, "auto_battle": auto_battle})
        resp.raise_for_status(); return resp.json()

    def scenarios(self) -> list[dict]: return self._http.get("/scenarios").json()
    def leaderboard(self, mode: str = "arena") -> list[dict]: return self._http.get(f"/leaderboard/{mode}").json()
    def status(self) -> dict: return self._http.get("/status").json()

    def compete(self, agent: "Agent", scenario: str = "prisoners-gambit"):
        asyncio.run(self._compete_async(agent, scenario))

    async def _compete_async(self, agent: "Agent", scenario: str):
        import websockets
        agents = self.list_agents()
        agent_id = agents[0]["id"] if agents else self.register_agent(agent)
        match_data = self.start_match(agent_id, scenario)
        print(f"⚔️  Match started! Watching via WebSocket...")
        ws_url = self.base_url.replace("http", "ws").replace("/api/v1", "") + "/ws"
        async with websockets.connect(ws_url) as ws:
            matches = self.list_agents()  # get active matches
            print("📡 Connected, watching for results...")
            async for msg in ws:
                data = json.loads(msg)
                if data.get("type") == "turn_action":
                    d = data.get("data", {})
                    print(f"  T{d.get('turn','?')} {d.get('agent_name','?')} [{d.get('skill','?')}]: {d.get('content','')[:80]}")
                elif data.get("type") == "match_end":
                    print(f"\n🏆 Match Complete!"); break
        print("✅ Done!")
