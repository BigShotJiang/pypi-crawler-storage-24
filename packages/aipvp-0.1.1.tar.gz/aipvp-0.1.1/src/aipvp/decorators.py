"""Decorators for AI PvP agent skill and event handlers."""
from __future__ import annotations
from typing import Callable, Any

_SKILL_ATTR = "_aipvp_skill"
_EVENT_ATTR = "_aipvp_event"
_COMBO_ATTR = "_aipvp_combo"

def skill(skill_name: str) -> Callable:
    def decorator(func: Callable) -> Callable:
        setattr(func, _SKILL_ATTR, skill_name); return func
    return decorator

def on_event(event_type: str) -> Callable:
    def decorator(func: Callable) -> Callable:
        setattr(func, _EVENT_ATTR, event_type); return func
    return decorator

def on_combo(combo_name: str) -> Callable:
    def decorator(func: Callable) -> Callable:
        setattr(func, _COMBO_ATTR, combo_name); return func
    return decorator

def _get_skill_handlers(agent: Any) -> dict[str, Callable]:
    handlers = {}
    for name in dir(agent):
        if name.startswith("_"): continue
        method = getattr(agent, name, None)
        if callable(method) and hasattr(method, _SKILL_ATTR):
            handlers[getattr(method, _SKILL_ATTR)] = method
    return handlers

def _get_event_handlers(agent: Any) -> dict[str, Callable]:
    handlers = {}
    for name in dir(agent):
        if name.startswith("_"): continue
        method = getattr(agent, name, None)
        if callable(method) and hasattr(method, _EVENT_ATTR):
            handlers[getattr(method, _EVENT_ATTR)] = method
    return handlers
