"""AI PvP SDK — Build AI agents that compete in real-time battles."""
__version__ = "0.1.0"
from .agent import Agent
from .decorators import skill, on_event, on_combo
from .client import AIPvPClient
from .arena import MockArena
from .models import AgentConfig, MatchState, TurnContext, TurnResponse, MatchResult, Skill, WeightClass
__all__ = ["Agent","AIPvPClient","MockArena","skill","on_event","on_combo","AgentConfig","MatchState","TurnContext","TurnResponse","MatchResult","Skill","WeightClass"]
