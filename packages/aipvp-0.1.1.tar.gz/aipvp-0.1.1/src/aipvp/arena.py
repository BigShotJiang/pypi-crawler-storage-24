"""MockArena for local testing without a server."""
from __future__ import annotations
from typing import TYPE_CHECKING
from .models import TurnContext, TurnResponse
if TYPE_CHECKING:
    from .agent import Agent

# Scoring hierarchy: fight > talk > observe (and everything else)
_SKILL_POWER = {"fight": 3, "deceive": 3, "talk": 2, "debate": 2, "negotiate": 2,
                "observe": 1, "analyze": 1, "strategize": 1, "shield": 1, "search": 1, "code": 1}


class MockArena:
    def __init__(self, turns: int = 12, verbose: bool = True):
        self.turns = turns; self.verbose = verbose

    def fight(self, agent_a: "Agent", agent_b: "Agent", turns: int | None = None) -> dict:
        max_turns = turns or self.turns
        score_a = score_b = 0.0; history = []
        if self.verbose: print(f"\n⚔️  {agent_a.config.name} vs {agent_b.config.name} ({max_turns} turns)\n")
        agent_a.on_match_start("local", agent_b.config.name, "local-test")
        agent_b.on_match_start("local", agent_a.config.name, "local-test")

        for turn in range(1, max_turns + 1):
            phase = "opening" if turn <= max_turns * 0.3 else ("midgame" if turn <= max_turns * 0.7 else "endgame")
            mult = 1.0 if phase == "opening" else (1.5 if phase == "midgame" else 2.0)
            ctx_a = TurnContext(turn=turn, max_turns=max_turns, phase=phase, phase_multiplier=mult,
                opponent_name=agent_b.config.name, score=score_a, opponent_score=score_b, history=history)
            ctx_b = TurnContext(turn=turn, max_turns=max_turns, phase=phase, phase_multiplier=mult,
                opponent_name=agent_a.config.name, score=score_b, opponent_score=score_a, history=history)
            resp_a = agent_a.decide(ctx_a); resp_b = agent_b.decide(ctx_b)

            # Score based on skill power: fight > talk > observe
            power_a = _SKILL_POWER.get(resp_a.skill, 1)
            power_b = _SKILL_POWER.get(resp_b.skill, 1)

            if power_a > power_b:
                pts_a = power_a * mult
                pts_b = 0.0
            elif power_b > power_a:
                pts_a = 0.0
                pts_b = power_b * mult
            else:
                # Tie -- both score half
                pts_a = (power_a * mult) / 2.0
                pts_b = (power_b * mult) / 2.0

            score_a += pts_a; score_b += pts_b

            turn_record = {
                "turn": turn, "phase": phase, "multiplier": mult,
                "a": {"name": agent_a.config.name, "skill": resp_a.skill, "content": resp_a.content, "points": pts_a},
                "b": {"name": agent_b.config.name, "skill": resp_b.skill, "content": resp_b.content, "points": pts_b},
            }
            history.append(turn_record)

            if self.verbose:
                winner_tag = ("→ " + agent_a.config.name) if pts_a > pts_b else (
                    ("→ " + agent_b.config.name) if pts_b > pts_a else "→ TIE")
                print(f"  Turn {turn:>2} [{phase:>7}] "
                      f"{agent_a.config.name}: {resp_a.skill:<10} vs "
                      f"{agent_b.config.name}: {resp_b.skill:<10} "
                      f"(+{pts_a:.1f} / +{pts_b:.1f}) {winner_tag}")

        # Determine result
        if score_a > score_b:
            result = "a_wins"
            winner = agent_a.config.name
        elif score_b > score_a:
            result = "b_wins"
            winner = agent_b.config.name
        else:
            result = "draw"
            winner = "DRAW"

        agent_a.on_match_end(result if result != "b_wins" else "loss", score_a, score_b)
        agent_b.on_match_end(result if result != "a_wins" else "loss", score_b, score_a)

        if self.verbose:
            print(f"\n  Final Score: {agent_a.config.name} {score_a:.1f} - {score_b:.1f} {agent_b.config.name}")
            print(f"  Result: {winner}\n")

        return {
            "match_id": "local-test",
            "agent_a": agent_a.config.name,
            "agent_b": agent_b.config.name,
            "score_a": score_a,
            "score_b": score_b,
            "result": result,
            "turns": max_turns,
            "history": history,
        }
