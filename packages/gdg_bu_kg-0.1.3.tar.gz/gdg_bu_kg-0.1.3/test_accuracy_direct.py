import asyncio
import sys
import os

os.environ["TOGETHER_API_KEY"] = "b3393f58344d74d8023d86d6280b670180c5a5b3db2701c2f3b09e7c88f2d3e1"
os.environ["DATABASE_URL"] = "postgresql://postgres:PQgNCbtsxmWbEjYwPqrCQFsEtnpjpnki@centerbeam.proxy.rlwy.net:36280/railway"
os.environ["NEO4J_URI"] = "neo4j+s://f6c60fc9.databases.neo4j.io"
os.environ["NEO4J_USERNAME"] = "f6c60fc9"
os.environ["NEO4J_PASSWORD"] = "bfo7MEKe0eUaYimbe0Ci3jyx1J6sW9PItHWSQR9_NDk"

sys.path.append(os.path.join(os.path.dirname(__file__), 'kg_backend'))
os.chdir("kg_backend")

import httpx
from config import settings
from api.index import BABCOCK_SCHEMA_PROMPT, CYPHER_MODEL
from database import db

QUERIES = [
    "What are the admission requirements for Nursing?",
    "Tell me an insight about Computer Science.",
    "List all lecturers in the School of Computing.",
    "Where is the nearest cafeteria?"
]

async def test():
    print("=== Cypher Generation Accuracy Test ===\n")
    print(f"Model: {CYPHER_MODEL}")
    print(f"Prompt tokens (approx): ~{len(BABCOCK_SCHEMA_PROMPT.split())}\n")

    for i, q in enumerate(QUERIES, 1):
        print(f"--- Test {i}: {q} ---")
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    "https://api.together.xyz/v1/chat/completions",
                    headers={"Authorization": f"Bearer {settings.together_api_key}"},
                    json={
                        "model": CYPHER_MODEL,
                        "messages": [
                            {"role": "system", "content": BABCOCK_SCHEMA_PROMPT},
                            {"role": "user", "content": f"Query: {q}"},
                        ],
                        "temperature": 0.0,
                        "max_tokens": 150,
                    },
                    timeout=20.0,
                )
                resp.raise_for_status()
                cypher = resp.json()["choices"][0]["message"]["content"].strip()
                cypher = cypher.replace("```cypher", "").replace("```", "").strip()
                cypher = cypher.split(';')[0].strip()

                print(f"   Generated Cypher: {cypher}")

                # Execute against Neo4j
                try:
                    results = db.run_query_with_retry(cypher)
                    print(f"   DB Result: {len(results)} row(s) returned")
                    if results:
                        for r in results[:2]:
                            print(f"     -> {r}")
                    print(f"   VERDICT: {'PASS' if results else 'FAIL (0 rows)'}")
                except Exception as db_err:
                    print(f"   DB Error: {db_err}")
                    print(f"   VERDICT: FAIL (invalid Cypher)")
        except Exception as e:
            print(f"   LLM Error: {e}")
            print(f"   VERDICT: FAIL (generation error)")
        print()

if __name__ == "__main__":
    asyncio.run(test())
