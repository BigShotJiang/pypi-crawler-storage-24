import requests
import json

BASE_URL = "http://localhost:8001/v1"
API_KEY = "bu_kg_3v_2RRXRjhQMACpjg-NKqfRm8qI6GEkGAxKtwhNVkBY"

TEST_QUERIES = [
    "What are the admission requirements for Nursing?",
    "Tell me an insight about Computer Science.",
    "List all lecturers in the School of Computing.",
    "Where is the nearest cafeteria?"
]

def run_accuracy_test():
    try:
        auth_resp = requests.post(f"{BASE_URL}/auth/token", json={"api_key": API_KEY}, timeout=30)
        auth_resp.raise_for_status()
        token = auth_resp.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
    except Exception as e:
        print(f"Failed to authenticate: {e}")
        return

    print("=== Testing Cypher Generation Accuracy with Compressed Schema ===\n")

    for i, q in enumerate(TEST_QUERIES, 1):
        print(f"Test {i}: {q}")
        try:
            resp = requests.post(f"{BASE_URL}/query", headers=headers, json={"query": q}, timeout=60)
            resp.raise_for_status()
            data = resp.json()
            
            # Print the text response and check how many nodes were returned contextually
            text_response = data["data"]["text_response"]
            nodes = data["data"]["graph"]["nodes"]
            print(f"-> Found {len(nodes)} context node(s)")
            print(f"-> AI Response Summary: {text_response[:150]}...\n")
            
        except requests.exceptions.HTTPError as e:
            print(f"HTTP Error: {e.response.text}")
        except Exception as e:
            print(f"Test Failed: {e}")

if __name__ == '__main__':
    run_accuracy_test()
