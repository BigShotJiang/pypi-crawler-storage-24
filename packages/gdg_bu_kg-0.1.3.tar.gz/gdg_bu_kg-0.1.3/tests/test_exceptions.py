"""Tests for exception hierarchy."""

import pytest

from gdg_bu_kg.exceptions import (
    AuthenticationError,
    BackendServiceError,
    ConnectionError,
    ForbiddenError,
    InvalidQueryError,
    KnowledgeGraphError,
    NotFoundError,
    RateLimitExceededError,
    ValidationError,
)


ALL_EXCEPTIONS = [
    AuthenticationError,
    ForbiddenError,
    InvalidQueryError,
    NotFoundError,
    ValidationError,
    RateLimitExceededError,
    BackendServiceError,
    ConnectionError,
]


class TestExceptionHierarchy:
    @pytest.mark.parametrize("exc_cls", ALL_EXCEPTIONS)
    def test_inherits_from_base(self, exc_cls):
        assert issubclass(exc_cls, KnowledgeGraphError)

    @pytest.mark.parametrize("exc_cls", ALL_EXCEPTIONS)
    def test_is_catchable_as_base(self, exc_cls):
        with pytest.raises(KnowledgeGraphError):
            raise exc_cls()

    @pytest.mark.parametrize("exc_cls", ALL_EXCEPTIONS)
    def test_has_default_message(self, exc_cls):
        exc = exc_cls()
        assert len(exc.message) > 0

    def test_custom_message(self):
        exc = AuthenticationError("custom msg")
        assert exc.message == "custom msg"
        assert str(exc) == "custom msg"

    def test_base_exception(self):
        exc = KnowledgeGraphError("base error")
        assert str(exc) == "base error"
