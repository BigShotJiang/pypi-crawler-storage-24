"""Tests for sync and async clients using respx for HTTP mocking."""

import pytest
import respx
import httpx

from gdg_bu_kg import (
    KnowledgeGraphClient,
    AsyncKnowledgeGraphClient,
    AuthenticationError,
    ForbiddenError,
    InvalidQueryError,
    NotFoundError,
    RateLimitExceededError,
    BackendServiceError,
    ConnectionError,
    ValidationError,
    QueryResponse,
    GraphResponse,
)


# =============================================================================
# Sample API responses
# =============================================================================

MOCK_QUERY_RESPONSE = {
    "status": "success",
    "data": {
        "text_response": "Babcock University was founded in 1959.",
        "graph": {
            "nodes": [
                {"id": "bu_1", "label": "Babcock University", "properties": {"type": "Institution"}},
            ],
            "edges": [],
        },
    },
}

MOCK_GRAPH_RESPONSE = {
    "status": "success",
    "data": {
        "graph": {
            "nodes": [
                {"id": "dept_1", "label": "Computer Science", "properties": {"type": "Department"}},
                {"id": "dept_2", "label": "Software Engineering", "properties": {"type": "Department"}},
            ],
            "edges": [
                {"from": "dept_1", "to": "dept_2", "label": "RELATED_TO", "properties": {}},
            ],
        },
        "context": "Found 2 departments in the School of Computing.",
    },
}

BASE_URL = "https://api.babcock-kg.com/v1"


# =============================================================================
# Sync Client Tests
# =============================================================================

class TestSyncClientInit:
    def test_empty_api_key_raises(self):
        with pytest.raises(AuthenticationError):
            KnowledgeGraphClient(api_key="")

    def test_whitespace_api_key_raises(self):
        with pytest.raises(AuthenticationError):
            KnowledgeGraphClient(api_key="   ")


class TestSyncQuery:
    @respx.mock
    def test_successful_query_returns_model(self):
        respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(200, json=MOCK_QUERY_RESPONSE)
        )
        client = KnowledgeGraphClient(api_key="test_key", max_retries=1)
        result = client.query("When was Babcock founded?")

        assert isinstance(result, QueryResponse)
        assert result.status == "success"
        assert "1959" in result.data.text_response
        assert len(result.data.graph.nodes) == 1
        client.close()

    @respx.mock
    def test_query_with_llm_params(self):
        route = respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(200, json=MOCK_QUERY_RESPONSE)
        )
        client = KnowledgeGraphClient(api_key="test_key", max_retries=1)
        client.query(
            "Tell me about Babcock",
            system_prompt="You are a university guide.",
            temperature=0.5,
            max_tokens=512,
            top_p=0.9,
        )
        # Verify that the LLM params were sent in the request body
        request_body = route.calls.last.request.content
        import json
        body = json.loads(request_body)
        assert body["system_prompt"] == "You are a university guide."
        assert body["temperature"] == 0.5
        assert body["max_tokens"] == 512
        assert body["top_p"] == 0.9
        client.close()

    @respx.mock
    def test_query_dict_format(self):
        respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(200, json=MOCK_QUERY_RESPONSE)
        )
        client = KnowledgeGraphClient(api_key="test_key", max_retries=1)
        result = client.query("Test query", response_format="dict")

        assert isinstance(result, dict)
        assert result["status"] == "success"
        client.close()

    def test_empty_query_raises(self):
        client = KnowledgeGraphClient(api_key="test_key")
        with pytest.raises(InvalidQueryError):
            client.query("")
        client.close()

    def test_whitespace_query_raises(self):
        client = KnowledgeGraphClient(api_key="test_key")
        with pytest.raises(InvalidQueryError):
            client.query("   ")
        client.close()


class TestSyncGraphQuery:
    @respx.mock
    def test_successful_graph_query(self):
        respx.post(f"{BASE_URL}/graph").mock(
            return_value=httpx.Response(200, json=MOCK_GRAPH_RESPONSE)
        )
        client = KnowledgeGraphClient(api_key="test_key", max_retries=1)
        result = client.graph_query("Show departments")

        assert isinstance(result, GraphResponse)
        assert result.status == "success"
        assert len(result.data.graph.nodes) == 2
        assert result.data.context is not None
        client.close()

    @respx.mock
    def test_graph_query_dict_format(self):
        respx.post(f"{BASE_URL}/graph").mock(
            return_value=httpx.Response(200, json=MOCK_GRAPH_RESPONSE)
        )
        client = KnowledgeGraphClient(api_key="test_key", max_retries=1)
        result = client.graph_query("Show departments", response_format="dict")

        assert isinstance(result, dict)
        assert result["data"]["context"] is not None
        client.close()


class TestSyncErrorMapping:
    @respx.mock
    def test_401_raises_authentication_error(self):
        respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(401, json={"detail": "Invalid key"})
        )
        client = KnowledgeGraphClient(api_key="bad_key", max_retries=1)
        with pytest.raises(AuthenticationError):
            client.query("test")
        client.close()

    @respx.mock
    def test_403_raises_forbidden_error(self):
        respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(403, json={"detail": "Forbidden"})
        )
        client = KnowledgeGraphClient(api_key="test_key", max_retries=1)
        with pytest.raises(ForbiddenError):
            client.query("test")
        client.close()

    @respx.mock
    def test_404_raises_not_found_error(self):
        respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(404, json={"detail": "Not found"})
        )
        client = KnowledgeGraphClient(api_key="test_key", max_retries=1)
        with pytest.raises(NotFoundError):
            client.query("test")
        client.close()

    @respx.mock
    def test_422_raises_validation_error(self):
        respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(422, json={"detail": "Unprocessable"})
        )
        client = KnowledgeGraphClient(api_key="test_key", max_retries=1)
        with pytest.raises(ValidationError):
            client.query("test")
        client.close()

    @respx.mock
    def test_429_raises_rate_limit_error(self):
        respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(429, json={"detail": "Too many requests"})
        )
        client = KnowledgeGraphClient(api_key="test_key", max_retries=1)
        with pytest.raises(RateLimitExceededError):
            client.query("test")
        client.close()

    @respx.mock
    def test_500_raises_backend_error(self):
        respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(500, json={"detail": "Internal error"})
        )
        client = KnowledgeGraphClient(api_key="test_key", max_retries=1)
        with pytest.raises(BackendServiceError):
            client.query("test")
        client.close()


class TestSyncContextManager:
    @respx.mock
    def test_context_manager(self):
        respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(200, json=MOCK_QUERY_RESPONSE)
        )
        with KnowledgeGraphClient(api_key="test_key", max_retries=1) as client:
            result = client.query("test")
            assert result.status == "success"


# =============================================================================
# Async Client Tests
# =============================================================================

class TestAsyncClientInit:
    def test_empty_api_key_raises(self):
        with pytest.raises(AuthenticationError):
            AsyncKnowledgeGraphClient(api_key="")


class TestAsyncQuery:
    @respx.mock
    @pytest.mark.asyncio
    async def test_successful_query(self):
        respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(200, json=MOCK_QUERY_RESPONSE)
        )
        async with AsyncKnowledgeGraphClient(api_key="test_key", max_retries=1) as client:
            result = await client.query("When was Babcock founded?")
            assert isinstance(result, QueryResponse)
            assert result.status == "success"

    @respx.mock
    @pytest.mark.asyncio
    async def test_graph_query(self):
        respx.post(f"{BASE_URL}/graph").mock(
            return_value=httpx.Response(200, json=MOCK_GRAPH_RESPONSE)
        )
        async with AsyncKnowledgeGraphClient(api_key="test_key", max_retries=1) as client:
            result = await client.graph_query("Show departments")
            assert isinstance(result, GraphResponse)
            assert len(result.data.graph.nodes) == 2

    @respx.mock
    @pytest.mark.asyncio
    async def test_query_with_llm_params(self):
        route = respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(200, json=MOCK_QUERY_RESPONSE)
        )
        async with AsyncKnowledgeGraphClient(api_key="test_key", max_retries=1) as client:
            await client.query(
                "test",
                system_prompt="Be concise.",
                temperature=0.3,
            )
            import json
            body = json.loads(route.calls.last.request.content)
            assert body["system_prompt"] == "Be concise."
            assert body["temperature"] == 0.3

    @pytest.mark.asyncio
    async def test_empty_query_raises(self):
        client = AsyncKnowledgeGraphClient(api_key="test_key")
        with pytest.raises(InvalidQueryError):
            await client.query("")
        await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_401_raises_auth_error(self):
        respx.post(f"{BASE_URL}/query").mock(
            return_value=httpx.Response(401, json={"detail": "Bad key"})
        )
        async with AsyncKnowledgeGraphClient(api_key="bad", max_retries=1) as client:
            with pytest.raises(AuthenticationError):
                await client.query("test")
