"""Tests for Pydantic response models."""

from gdg_bu_kg.models import (
    EdgeModel,
    GraphModel,
    GraphResponse,
    GraphResponseData,
    NodeModel,
    QueryResponse,
    QueryResponseData,
)


SAMPLE_AI_RESPONSE = {
    "status": "success",
    "data": {
        "text_response": "The Computer Science department is part of the School of Computing.",
        "graph": {
            "nodes": [
                {"id": "cs_1", "label": "Computer Science", "properties": {"type": "Department"}},
                {"id": "soc_1", "label": "School of Computing", "properties": {"type": "School"}},
            ],
            "edges": [
                {"from": "cs_1", "to": "soc_1", "label": "BELONGS_TO", "properties": {}},
            ],
        },
    },
}

SAMPLE_GRAPH_RESPONSE = {
    "status": "success",
    "data": {
        "graph": {
            "nodes": [
                {"id": "dept_1", "label": "Software Engineering", "properties": {"type": "Department"}},
            ],
            "edges": [],
        },
        "context": "Found 1 department matching the query.",
    },
}


class TestNodeModel:
    def test_basic_parse(self):
        node = NodeModel(id="n1", label="Test", properties={"key": "val"})
        assert node.id == "n1"
        assert node.label == "Test"
        assert node.properties == {"key": "val"}

    def test_default_properties(self):
        node = NodeModel(id="n1", label="Test")
        assert node.properties == {}

    def test_repr(self):
        node = NodeModel(id="n1", label="Test")
        assert "n1" in repr(node)
        assert "Test" in repr(node)

    def test_repr_html(self):
        node = NodeModel(id="n1", label="Test", properties={"type": "Service"})
        html = node._repr_html_()
        assert "n1" in html
        assert "Test" in html


class TestEdgeModel:
    def test_parse_with_alias(self):
        edge = EdgeModel(**{"from": "a", "to": "b", "label": "REL", "properties": {}})
        assert edge.from_node == "a"
        assert edge.to == "b"
        assert edge.label == "REL"

    def test_repr(self):
        edge = EdgeModel(**{"from": "a", "to": "b", "label": "REL", "properties": {}})
        assert "REL" in repr(edge)

    def test_repr_html(self):
        edge = EdgeModel(**{"from": "a", "to": "b", "label": "CONNECTS", "properties": {}})
        html = edge._repr_html_()
        assert "CONNECTS" in html


class TestGraphModel:
    def test_empty_graph(self):
        graph = GraphModel(nodes=[], edges=[])
        assert len(graph.nodes) == 0
        assert len(graph.edges) == 0
        assert "0" in repr(graph)

    def test_graph_with_data(self):
        graph = GraphModel(
            nodes=[NodeModel(id="n1", label="A")],
            edges=[EdgeModel(**{"from": "n1", "to": "n2", "label": "R", "properties": {}})],
        )
        assert len(graph.nodes) == 1
        assert len(graph.edges) == 1

    def test_repr_html(self):
        graph = GraphModel(
            nodes=[NodeModel(id="n1", label="A")],
            edges=[],
        )
        html = graph._repr_html_()
        assert "<table>" in html


class TestQueryResponse:
    def test_full_parse(self):
        resp = QueryResponse.model_validate(SAMPLE_AI_RESPONSE)
        assert resp.status == "success"
        assert "Computer Science" in resp.data.text_response
        assert len(resp.data.graph.nodes) == 2
        assert len(resp.data.graph.edges) == 1
        assert resp.data.graph.edges[0].from_node == "cs_1"
        assert resp.data.graph.edges[0].label == "BELONGS_TO"

    def test_repr_html(self):
        resp = QueryResponse.model_validate(SAMPLE_AI_RESPONSE)
        html = resp._repr_html_()
        assert "success" in html.lower() or "SUCCESS" in html


class TestGraphResponse:
    def test_full_parse(self):
        resp = GraphResponse.model_validate(SAMPLE_GRAPH_RESPONSE)
        assert resp.status == "success"
        assert resp.data.context == "Found 1 department matching the query."
        assert len(resp.data.graph.nodes) == 1
        assert resp.data.graph.nodes[0].label == "Software Engineering"

    def test_no_context(self):
        data = {
            "status": "success",
            "data": {"graph": {"nodes": [], "edges": []}},
        }
        resp = GraphResponse.model_validate(data)
        assert resp.data.context is None

    def test_repr_html(self):
        resp = GraphResponse.model_validate(SAMPLE_GRAPH_RESPONSE)
        html = resp._repr_html_()
        assert "Context" in html
