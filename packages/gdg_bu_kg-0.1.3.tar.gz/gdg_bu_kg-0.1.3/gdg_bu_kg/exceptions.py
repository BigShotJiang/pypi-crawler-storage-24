"""Custom exceptions for the Babcock Knowledge Graph SDK."""


class KnowledgeGraphError(Exception):
    """Base exception for all Knowledge Graph SDK errors."""

    def __init__(self, message: str = "An error occurred with the Knowledge Graph service."):
        self.message = message
        super().__init__(self.message)


class AuthenticationError(KnowledgeGraphError):
    """Raised when authentication fails (HTTP 401).

    Typically means the API key is invalid, expired, or missing.
    Regenerate your key from the SaaS Dashboard.
    """

    def __init__(self, message: str = "Authentication failed. Please check your API key."):
        super().__init__(message)


class ForbiddenError(KnowledgeGraphError):
    """Raised when the API key is valid but lacks permissions (HTTP 403)."""

    def __init__(self, message: str = "Access denied. Your API key lacks the required permissions."):
        super().__init__(message)


class InvalidQueryError(KnowledgeGraphError):
    """Raised when the query is malformed or empty (HTTP 400)."""

    def __init__(self, message: str = "Invalid query. Please provide a non-empty query string."):
        super().__init__(message)


class NotFoundError(KnowledgeGraphError):
    """Raised when the requested resource or endpoint is not found (HTTP 404)."""

    def __init__(self, message: str = "The requested resource was not found."):
        super().__init__(message)


class ValidationError(KnowledgeGraphError):
    """Raised when the backend cannot process the query (HTTP 422)."""

    def __init__(self, message: str = "The server could not process your query."):
        super().__init__(message)


class RateLimitExceededError(KnowledgeGraphError):
    """Raised when the rate limit is exceeded (HTTP 429).

    Wait before retrying, or upgrade your plan for higher limits.
    """

    def __init__(self, message: str = "Rate limit exceeded. Please wait before retrying."):
        super().__init__(message)


class BackendServiceError(KnowledgeGraphError):
    """Raised when the backend encounters an internal error (HTTP 5xx)."""

    def __init__(self, message: str = "The Knowledge Graph service encountered an internal error."):
        super().__init__(message)


class ConnectionError(KnowledgeGraphError):
    """Raised when a network-level connection failure occurs."""

    def __init__(self, message: str = "Failed to connect to the Knowledge Graph service. Check your network."):
        super().__init__(message)
