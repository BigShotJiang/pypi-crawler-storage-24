"""Babcock Knowledge Graph SDK.

A Python SDK for querying the Babcock University Knowledge Graph.
Supports both AI-powered queries (LLM + KG) and raw graph data retrieval.
"""

__version__ = "0.1.0"

from .client import AsyncKnowledgeGraphClient, KnowledgeGraphClient
from .enums import SupportedChatModel
from .exceptions import (
    AuthenticationError,
    BackendServiceError,
    ConnectionError,
    ForbiddenError,
    InvalidQueryError,
    KnowledgeGraphError,
    NotFoundError,
    RateLimitExceededError,
    ValidationError,
)
from .models import (
    EdgeModel,
    GraphModel,
    GraphResponse,
    GraphResponseData,
    NodeModel,
    QueryResponse,
    QueryResponseData,
)

__all__ = [
    # Clients
    "KnowledgeGraphClient",
    "AsyncKnowledgeGraphClient",
    # Enums
    "SupportedChatModel",
    # Models
    "NodeModel",
    "EdgeModel",
    "GraphModel",
    "QueryResponse",
    "QueryResponseData",
    "GraphResponse",
    "GraphResponseData",
    # Exceptions
    "KnowledgeGraphError",
    "AuthenticationError",
    "ForbiddenError",
    "InvalidQueryError",
    "NotFoundError",
    "ValidationError",
    "RateLimitExceededError",
    "BackendServiceError",
    "ConnectionError",
]
