"""Sync and async clients for the Babcock Knowledge Graph SDK."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from .exceptions import (
    AuthenticationError,
    BackendServiceError,
    ConnectionError,
    ForbiddenError,
    InvalidQueryError,
    KnowledgeGraphError,
    NotFoundError,
    RateLimitExceededError,
    ValidationError,
)
from .enums import SupportedChatModel
from .models import GraphResponse, QueryResponse

logger = logging.getLogger("kg_client")


# =============================================================================
# HTTP Status → Exception mapping
# =============================================================================

_STATUS_EXCEPTION_MAP: Dict[int, type] = {
    400: InvalidQueryError,
    401: AuthenticationError,
    403: ForbiddenError,
    404: NotFoundError,
    422: ValidationError,
    429: RateLimitExceededError,
}


def _raise_for_status(response: httpx.Response) -> None:
    """Map an HTTP error response to a SDK-specific exception."""
    code = response.status_code
    if code >= 500:
        detail = _extract_detail(response)
        raise BackendServiceError(
            f"Backend error (HTTP {code}): {detail}"
        )
    exc_cls = _STATUS_EXCEPTION_MAP.get(code)
    if exc_cls is not None:
        detail = _extract_detail(response)
        raise exc_cls(f"{exc_cls.__doc__.strip().split(chr(10))[0]} Detail: {detail}")
    if code >= 400:
        raise KnowledgeGraphError(f"Unexpected error (HTTP {code}): {response.text[:200]}")


def _extract_detail(response: httpx.Response) -> str:
    """Try to pull a human-readable message from the response body."""
    try:
        body = response.json()
        return body.get("detail", body.get("message", response.text[:200]))
    except Exception:
        return response.text[:200]


# =============================================================================
# Retry predicate — retry on transient errors only
# =============================================================================

_RETRYABLE = (RateLimitExceededError, BackendServiceError, ConnectionError)


# =============================================================================
# Synchronous Client
# =============================================================================

class KnowledgeGraphClient:
    """Synchronous client for the Babcock Knowledge Graph API.

    Args:
        api_key: Your platform API key from the SaaS dashboard.
        timeout: Request timeout in seconds (default 30).
        max_retries: Max retry attempts for transient errors (default 3).
    """

    _DEFAULT_BASE_URL: str = "https://bu-kg.vercel.app/v1"

    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: int = 30,
        max_retries: int = 3,
    ) -> None:
        if not api_key or not api_key.strip():
            raise AuthenticationError("API key must not be empty.")

        self._api_key = api_key
        
        import os
        env_url = os.getenv("BU_KG_BASE_URL")
        actual_url = (base_url or env_url or self._DEFAULT_BASE_URL).strip()
        self._base_url = actual_url.rstrip("/")
        
        self._timeout = timeout
        self._max_retries = max_retries
        self._session_token: Optional[str] = None
        
        # Internal client without auth header initially
        self._client = httpx.Client(
            base_url=self.__base_url,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "gdg-bu-kg/0.1.2",
            },
            timeout=timeout,
        )
        
        # Initial token exchange
        self._refresh_token()
        logger.info("KnowledgeGraphClient initialized (base_url=HIDDEN, timeout=%ds)", timeout)

    def _refresh_token(self) -> None:
        """Exchange the permanent API key for a fresh session JWT."""
        logger.debug("Refreshing session token...")
        try:
            resp = self._client.post("/auth/token", json={"api_key": self._api_key})
            if resp.status_code != 200:
                _raise_for_status(resp)
            
            data = resp.json()
            self._session_token = data["access_token"]
            # Update client headers for future requests
            self._client.headers["Authorization"] = f"Bearer {self._session_token}"
        except Exception as e:
            raise AuthenticationError(f"Failed to authenticate: {str(e)}")

    # ----- Public API --------------------------------------------------------

    @classmethod
    def get_available_models(cls) -> List[str]:
        """Return a list of supported model strings for the LLM+Graph API."""
        return [m.value for m in SupportedChatModel]

    def query(
        self,
        query: str,
        *,
        model: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        response_format: str = "model",
    ) -> QueryResponse | dict:
        """Send a natural language query to the LLM + Knowledge Graph."""
        self._validate_query(query)

        payload: Dict[str, Any] = {"query": query}
        if model is not None: payload["model"] = model
        if system_prompt is not None: payload["system_prompt"] = system_prompt
        if temperature is not None: payload["temperature"] = temperature
        if max_tokens is not None: payload["max_tokens"] = max_tokens
        if top_p is not None: payload["top_p"] = top_p

        raw = self._post("/query", payload)

        if response_format == "dict":
            return raw
        return QueryResponse.model_validate(raw)

    def graph_query(
        self,
        query: str,
        *,
        response_format: str = "model",
    ) -> GraphResponse | dict:
        """Query the knowledge graph for raw contextual data."""
        self._validate_query(query)
        payload: Dict[str, Any] = {"query": query}
        raw = self._post("/graph", payload)

        if response_format == "dict":
            return raw
        return GraphResponse.model_validate(raw)

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    # ----- Context manager ---------------------------------------------------

    def __enter__(self) -> "KnowledgeGraphClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ----- Internals ---------------------------------------------------------

    def _validate_query(self, query: str) -> None:
        if not query or not query.strip():
            raise InvalidQueryError("Query must not be empty.")

    def _post(self, endpoint: str, payload: Dict[str, Any]) -> dict:
        """POST with automatic retry and token refresh."""

        @retry(
            retry=retry_if_exception_type(_RETRYABLE),
            stop=stop_after_attempt(self._max_retries),
            wait=wait_exponential(multiplier=1, min=1, max=10),
            reraise=True,
        )
        def _do_post() -> dict:
            try:
                resp = self._client.post(endpoint, json=payload)
                
                # Handle token expiration (401)
                if resp.status_code == 401 and "session" in resp.text.lower():
                    logger.warning("Session expired. Attempting refresh...")
                    self._refresh_token()
                    resp = self._client.post(endpoint, json=payload) # Retry once
                
                if resp.status_code >= 400:
                    _raise_for_status(resp)

                return resp.json()
            except httpx.HTTPError as exc:
                raise ConnectionError(f"HTTP Request failed: {exc}") from exc

        return _do_post()


# =============================================================================
# Asynchronous Client
# =============================================================================

class AsyncKnowledgeGraphClient:
    """Asynchronous client for the Babcock Knowledge Graph API."""

    _DEFAULT_BASE_URL: str = "https://bu-kg.vercel.app/v1"

    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: int = 30,
        max_retries: int = 3,
    ) -> None:
        if not api_key or not api_key.strip():
            raise AuthenticationError("API key must not be empty.")

        self._api_key = api_key
        
        import os
        env_url = os.getenv("BU_KG_BASE_URL")
        actual_url = (base_url or env_url or self._DEFAULT_BASE_URL).strip()
        self._base_url = actual_url.rstrip("/")
        
        self._timeout = timeout
        self._max_retries = max_retries
        self._session_token: Optional[str] = None
        
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "gdg-bu-kg/0.1.2",
            },
            timeout=timeout,
        )
        # Initial token exchange must be handled explicitly or on first request
        # We'll allow __init__ to stay non-async but trigger the token on first use
        logger.info("AsyncKnowledgeGraphClient initialized (base_url=HIDDEN)")

    async def _refresh_token(self) -> None:
        """Async exchange the permanent API key for a fresh session JWT."""
        try:
            resp = await self._client.post("/auth/token", json={"api_key": self._api_key})
            if resp.status_code != 200:
                _raise_for_status(resp)
            
            data = resp.json()
            self._session_token = data["access_token"]
            self._client.headers["Authorization"] = f"Bearer {self._session_token}"
        except Exception as e:
            raise AuthenticationError(f"Failed to authenticate: {str(e)}")

    # ----- Public API --------------------------------------------------------

    @classmethod
    def get_available_models(cls) -> List[str]:
        """Return a list of supported model strings for the LLM+Graph API."""
        return [m.value for m in SupportedChatModel]

    async def query(
        self,
        query: str,
        *,
        model: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        response_format: str = "model",
    ) -> QueryResponse | dict:
        """Async NL query."""
        self._validate_query(query)
        if not self._session_token: await self._refresh_token()

        payload: Dict[str, Any] = {"query": query}
        if model is not None: payload["model"] = model
        if system_prompt is not None: payload["system_prompt"] = system_prompt
        if temperature is not None: payload["temperature"] = temperature
        if max_tokens is not None: payload["max_tokens"] = max_tokens
        if top_p is not None: payload["top_p"] = top_p

        raw = await self._post("/query", payload)

        if response_format == "dict":
            return raw
        return QueryResponse.model_validate(raw)

    async def graph_query(
        self,
        query: str,
        *,
        response_format: str = "model",
    ) -> GraphResponse | dict:
        """Async graph query."""
        self._validate_query(query)
        if not self._session_token: await self._refresh_token()
        
        payload: Dict[str, Any] = {"query": query}
        raw = await self._post("/graph", payload)

        if response_format == "dict":
            return raw
        return GraphResponse.model_validate(raw)

    async def close(self) -> None:
        """Close the underlying async HTTP connection pool."""
        await self._client.aclose()

    # ----- Context manager ---------------------------------------------------

    async def __aenter__(self) -> "AsyncKnowledgeGraphClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    # ----- Internals ---------------------------------------------------------

    def _validate_query(self, query: str) -> None:
        if not query or not query.strip():
            raise InvalidQueryError("Query must not be empty.")

    async def _post(self, endpoint: str, payload: Dict[str, Any]) -> dict:
        """Async POST with manual retry and token refresh."""
        last_exc: Exception | None = None

        for attempt in range(1, self._max_retries + 1):
            try:
                resp = await self._client.post(endpoint, json=payload)
                
                # Handle token expiration (401)
                if resp.status_code == 401 and "session" in resp.text.lower():
                    await self._refresh_token()
                    resp = await self._client.post(endpoint, json=payload) # Retry once
                
                if resp.status_code >= 400:
                    _raise_for_status(resp)

                return resp.json()
            except httpx.HTTPError as exc:
                last_exc = ConnectionError(f"HTTP Request failed: {exc}")
                if attempt < self._max_retries:
                    import asyncio
                    await asyncio.sleep(min(2 ** attempt, 10))
                    continue
                raise last_exc from exc

        raise last_exc  # type: ignore[misc]
