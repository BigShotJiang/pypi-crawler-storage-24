"""Pydantic models for the Babcock Knowledge Graph SDK responses."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# =============================================================================
# Shared Graph Models
# =============================================================================

class NodeModel(BaseModel):
    """A single node in the knowledge graph."""

    id: str
    label: str
    properties: Dict[str, Any] = Field(default_factory=dict)

    def _repr_html_(self) -> str:
        props = ", ".join(f"{k}={v}" for k, v in self.properties.items())
        return (
            f'<span style="color:#4fc3f7"><b>[{self.id}]</b></span> '
            f'<b>{self.label}</b>'
            f'{f" <i>({props})</i>" if props else ""}'
        )

    def __repr__(self) -> str:
        return f"Node(id={self.id!r}, label={self.label!r}, properties={self.properties!r})"


class EdgeModel(BaseModel):
    """A directed edge (relationship) between two nodes."""

    from_node: str = Field(alias="from")
    to: str
    label: str
    properties: Dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}

    def _repr_html_(self) -> str:
        props = ", ".join(f"{k}={v}" for k, v in self.properties.items())
        return (
            f'<span style="color:#81c784">{self.from_node}</span> '
            f'—<b>{self.label}</b>→ '
            f'<span style="color:#81c784">{self.to}</span>'
            f'{f" <i>({props})</i>" if props else ""}'
        )

    def __repr__(self) -> str:
        return (
            f"Edge(from={self.from_node!r}, to={self.to!r}, "
            f"label={self.label!r}, properties={self.properties!r})"
        )


class GraphModel(BaseModel):
    """A graph structure containing nodes and edges."""

    nodes: List[NodeModel] = Field(default_factory=list)
    edges: List[EdgeModel] = Field(default_factory=list)

    def _repr_html_(self) -> str:
        node_rows = "".join(
            f"<tr><td>{n.id}</td><td>{n.label}</td><td>{n.properties}</td></tr>"
            for n in self.nodes
        )
        edge_rows = "".join(
            f"<tr><td>{e.from_node}</td><td>{e.label}</td><td>{e.to}</td><td>{e.properties}</td></tr>"
            for e in self.edges
        )
        return (
            "<h4>Nodes</h4>"
            "<table><tr><th>ID</th><th>Label</th><th>Properties</th></tr>"
            f"{node_rows}</table>"
            "<h4>Edges</h4>"
            "<table><tr><th>From</th><th>Relationship</th><th>To</th><th>Properties</th></tr>"
            f"{edge_rows}</table>"
        )

    def __repr__(self) -> str:
        return f"Graph(nodes={len(self.nodes)}, edges={len(self.edges)})"


# =============================================================================
# AI Query Response (client.query)
# =============================================================================

class QueryResponseData(BaseModel):
    """Data payload for an AI Query response."""

    text_response: str
    graph: GraphModel

    def _repr_html_(self) -> str:
        return (
            f'<div style="padding:10px;border-left:3px solid #4fc3f7;margin-bottom:10px">'
            f"<p>{self.text_response}</p></div>"
            f"{self.graph._repr_html_()}"
        )

    def __repr__(self) -> str:
        preview = self.text_response[:80] + ("..." if len(self.text_response) > 80 else "")
        return f"QueryResponseData(text={preview!r}, graph={self.graph!r})"


class QueryResponse(BaseModel):
    """Full response from the AI Query endpoint (client.query)."""

    status: str
    data: QueryResponseData

    def _repr_html_(self) -> str:
        badge_color = "#81c784" if self.status == "success" else "#e57373"
        return (
            f'<div style="font-family:sans-serif">'
            f'<span style="background:{badge_color};color:#fff;padding:2px 8px;'
            f'border-radius:4px;font-size:12px">{self.status.upper()}</span>'
            f"{self.data._repr_html_()}</div>"
        )

    def __repr__(self) -> str:
        return f"QueryResponse(status={self.status!r}, data={self.data!r})"


# =============================================================================
# Graph Query Response (client.graph_query)
# =============================================================================

class GraphResponseData(BaseModel):
    """Data payload for a Graph Query response."""

    graph: GraphModel
    context: Optional[str] = None

    def _repr_html_(self) -> str:
        ctx = (
            f'<div style="padding:10px;border-left:3px solid #ffb74d;margin-bottom:10px">'
            f"<p><b>Context:</b> {self.context}</p></div>"
            if self.context
            else ""
        )
        return f"{ctx}{self.graph._repr_html_()}"

    def __repr__(self) -> str:
        return f"GraphResponseData(graph={self.graph!r}, context={self.context!r})"


class GraphResponse(BaseModel):
    """Full response from the Graph Query endpoint (client.graph_query)."""

    status: str
    data: GraphResponseData

    def _repr_html_(self) -> str:
        badge_color = "#81c784" if self.status == "success" else "#e57373"
        return (
            f'<div style="font-family:sans-serif">'
            f'<span style="background:{badge_color};color:#fff;padding:2px 8px;'
            f'border-radius:4px;font-size:12px">{self.status.upper()}</span>'
            f"{self.data._repr_html_()}</div>"
        )

    def __repr__(self) -> str:
        return f"GraphResponse(status={self.status!r}, data={self.data!r})"
