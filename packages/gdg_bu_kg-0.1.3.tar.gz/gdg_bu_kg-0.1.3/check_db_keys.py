import hashlib
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
from config import settings

Base = declarative_base()

class ApiKey(Base):
    __tablename__ = "api_keys"
    id = Column(Integer, primary_key=True)
    owner = Column(String)
    key_hash = Column(String)

engine = create_engine(settings.database_url, connect_args={"sslmode": "require"})
Session = sessionmaker(bind=engine)
session = Session()

def get_hash(api_key: str) -> str:
    return hashlib.sha256(api_key.encode("utf-8")).hexdigest()

def main():
    print("--- Database Key Check ---")
    keys = session.query(ApiKey).all()
    print(f"Total keys found: {len(keys)}")
    
    target_key = "bu_kg_3v_2RRXRjhQMACpjg-NKqfRm8qI6GEkGAxKtwhNVkBY"
    target_hash = get_hash(target_key)
    
    found = False
    for k in keys:
        print(f"Owner: {k.owner} | Hash: {k.key_hash[:10]}...")
        if k.key_hash == target_hash:
            print(">>> MATCH FOUND! The key is in the DB.")
            found = True
            
    if not found:
        print(">>> NO MATCH. The key is NOT in the DB.")
        
    session.close()

if __name__ == "__main__":
    main()
