import time
import requests
import json

# API Config
BASE_URL = "http://localhost:8001/v1"
API_KEY = "bu_kg_3v_2RRXRjhQMACpjg-NKqfRm8qI6GEkGAxKtwhNVkBY"

def benchmark():
    # 1. Get Token
    auth_resp = requests.post(f"{BASE_URL}/auth/token", json={"api_key": API_KEY}, timeout=30)
    token = auth_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    print(f"{'Test Type':<25} | {'Latency (s)':<12} | {'Status'}")
    print("-" * 50)

    # Test A: LLM + Graph
    try:
        start = time.time()
        resp = requests.post(f"{BASE_URL}/query", headers=headers, json={"query": "What is the admission requirement for Computer Science?"}, timeout=45)
        end = time.time()
        print(f"{'LLM + Graph Query':<25} | {end-start:<12.3f} | {resp.status_code}")
        print(resp.json())
    except Exception as e:
        print(f"Test A Failed: {e}")

    # Test B: Raw Graph Query
    try:
        start = time.time()
        resp = requests.post(f"{BASE_URL}/graph", headers=headers, json={"query": "MATCH (p:Program) WHERE toLower(p.Name) CONTAINS 'computer science' RETURN p.Admission_Requirement"}, timeout=45)
        end = time.time()
        print(f"{'Raw Graph Query':<25} | {end-start:<12.3f} | {resp.status_code}")
        print(resp.json())
    except Exception as e:
        print(f"Test B Failed: {e}")

if __name__ == '__main__':
    benchmark()
