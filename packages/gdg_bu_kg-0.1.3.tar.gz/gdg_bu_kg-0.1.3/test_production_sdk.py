from gdg_bu_kg import KnowledgeGraphClient
import os

# API key provided by the user
API_KEY = "bu_kg_3v_2RRXRjhQMACpjg-NKqfRm8qI6GEkGAxKtwhNVkBY"

def main():
    print(f"--- Testing Babcock Knowledge Graph SDK (v0.1.2) ---")
    
    # Initialize client - it will automatically exchange the API_KEY for a JWT session token
    try:
        client = KnowledgeGraphClient(api_key=API_KEY)
        print(f"✓ Client initialized (Session-based Auth)")
        
        # Test 1: Simple NL Query
        print("\n[Test 1] Querying: Who are the lecturers in Computer Science?")
        response = client.query("Who are the lecturers in Computer Science?")
        if response.status == "success":
            print(f"✓ AI Answer: {response.data.text_response[:100]}...")
        
        # Test 2: Raw Graph Query
        print("\n[Test 2] Raw Cypher: MATCH (s:School) RETURN s.Name AS Name LIMIT 3")
        graph_resp = client.graph_query("MATCH (s:School) RETURN s.Name AS Name LIMIT 3")
        if graph_resp.status == "success":
            schools = [n.properties.get('Name') for n in graph_resp.data.graph.nodes]
            print(f"✓ Found Schools: {schools}")

        # Test 3: Complex Reasoning
        print("\n[Test 3] Querying: Which school does the Computer Science department belong to?")
        response = client.query("Which school does the Computer Science department belong to?")
        if response.status == "success":
            print(f"✓ AI Answer: {response.data.text_response}")

        print("\n--- All Production Tests Passed! ---")
            
    except Exception as e:
        print(f"✗ An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
