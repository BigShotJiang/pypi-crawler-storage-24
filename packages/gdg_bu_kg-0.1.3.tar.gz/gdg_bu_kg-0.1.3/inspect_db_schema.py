import os
from neo4j import GraphDatabase
from dotenv import load_dotenv

load_dotenv("kg_backend/.env")

uri = os.getenv("NEO4J_URI")
username = os.getenv("NEO4J_USERNAME")
password = os.getenv("NEO4J_PASSWORD")

def inspect_schema():
    with open("neo4j_schema.txt", "w") as f:
        driver = GraphDatabase.driver(uri, auth=(username, password))
        with driver.session() as session:
            labels = session.run("CALL db.labels()").value()
            f.write(f"Labels: {labels}\n")
            
            for label in labels:
                props = session.run(f"MATCH (n:{label}) UNWIND keys(n) AS key RETURN DISTINCT key").value()
                f.write(f"Label '{label}' Properties: {props}\n")
            
            # Get relationships
            rels = session.run("CALL db.relationshipTypes()").value()
            f.write(f"\nRelationship Types: {rels}\n")
        driver.close()

if __name__ == "__main__":
    inspect_schema()
