# Supported AI Models for Babcock Knowledge Graph

When using `client.query()` to perform a semantic LLM search grounded on the Graph Database, you can optionally pass an LLM model string. This document lists all models officially supported by the Babcock central backend.

If you are building a frontend, you can present these as a dropdown menu so the user can dynamically choose which LLM engine handles their query (e.g. for cost, speed, or reasoning capabilities).

To fetch these programmatically using the SDK, utilize the helper method:
```python
from kg_client import KnowledgeGraphClient
models = KnowledgeGraphClient.get_available_models()
```

### Models List

| Model Label | Value provided to `model` Parameter | Category |
| -- | -- | -- |
| GLM-5-FP4 | `GLM-5-FP4` | chat |
| Qwen3.5 397B A17b | `Qwen3.5 397B A17b` | chat |
| MiniMax M2.5 FP4 | `MiniMax M2.5 FP4` | chat |
| Kimi K2.5 | `Kimi K2.5` | chat |
| GLM 4.7 Fp8 | `GLM 4.7 Fp8` | chat |
| Qwen3.5 9B FP8 | `Qwen3.5 9B FP8` | chat |
| Qwen3 Coder Next Fp8 | `Qwen3 Coder Next Fp8` | chat |
| Qwen3 Next 80B A3b Instruct | `Qwen3 Next 80B A3b Instruct` | chat |
| Qwen3 Coder 480B A35B Instruct Fp8 | `Qwen3 Coder 480B A35B Instruct Fp8` | chat |
| Qwen3-VL-8B-Instruct | `Qwen3-VL-8B-Instruct` | chat |
| Qwen2.5 7B Instruct Turbo | `Qwen2.5 7B Instruct Turbo` | chat |
| Glm 4.5 Air Fp8 | `Glm 4.5 Air Fp8` | chat |
| Llama 4 Maverick Instruct (17Bx128E) | `Llama 4 Maverick Instruct (17Bx128E)` | chat |
| Meta Llama 3.3 70B Instruct Turbo | `Meta Llama 3.3 70B Instruct Turbo` | chat |
| Meta Llama 3.1 8B Instruct Turbo | `Meta Llama 3.1 8B Instruct Turbo` | chat |
| Mistral Small (24B) Instruct 25.01 | `Mistral Small (24B) Instruct 25.01` | chat |
| Mixtral-8x7B Instruct v0.1 | `Mixtral-8x7B Instruct v0.1` | chat |
| Gemma 3N E4B Instruct | `Gemma 3N E4B Instruct` | chat |
| Meta Llama 3 8B Instruct Lite | `Meta Llama 3 8B Instruct Lite` | chat |
| Arize AI Qwen 2 1.5B Instruct | `Arize AI Qwen 2 1.5B Instruct` | chat |
| Apriel 1.5 15B Thinker | `Apriel 1.5 15B Thinker` | chat |
| Trinity Mini | `Trinity Mini` | chat |
| EssentialAI Rnj-1 Instruct | `EssentialAI Rnj-1 Instruct` | chat |
| Cogito v2.1 671B | `Cogito v2.1 671B` | chat |
| Apriel 1.6 15B Thinker | `Apriel 1.6 15B Thinker` | chat |
| DeepSeek R1-0528 | `DeepSeek R1-0528` | chat |
| OpenAI GPT-OSS 20B | `OpenAI GPT-OSS 20B` | chat |
| Deepseek V3.1 | `Deepseek V3.1` | chat |
| Qwen3 235B A22B Instruct 2507 FP8 Throughput | `Qwen3 235B A22B Instruct 2507 FP8 Throughput` | chat |
| Qwen3 235B A22B Thinking 2507 FP8 | `Qwen3 235B A22B Thinking 2507 FP8` | chat |
| OpenAI GPT-OSS 120B | `OpenAI GPT-OSS 120B` | chat |
| Lfm2 24B A2b Preview | `Lfm2 24B A2b Preview` | chat |
| LFM2-24B-A2B | `LFM2-24B-A2B` | chat |
| nim/nvidia/llama-3.3-nemotron-super-49b-v1 | `nim/nvidia/llama-3.3-nemotron-super-49b-v1` | chat |
| Deepseek Coder 33B Instruct | `Deepseek Coder 33B Instruct` | chat |
| Llama 4 Scout (17Bx16E) | `Llama 4 Scout (17Bx16E)` | chat |
| Meta Llama 3.1 405B Instruct | `Meta Llama 3.1 405B Instruct` | chat |

*(Note: Image, Audio, Moderation, and Video generation models were heavily filtered from this list as they do not apply to Knowledge Graph search)*
