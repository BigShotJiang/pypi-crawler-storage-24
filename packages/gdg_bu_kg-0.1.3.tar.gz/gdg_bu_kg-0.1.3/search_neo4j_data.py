import os
from neo4j import GraphDatabase
from dotenv import load_dotenv

load_dotenv("kg_backend/.env")

uri = os.getenv("NEO4J_URI")
username = os.getenv("NEO4J_USERNAME")
password = os.getenv("NEO4J_PASSWORD")

def search_keywords(keyword):
    driver = GraphDatabase.driver(uri, auth=(username, password))
    with driver.session() as session:
        query = f"""
        MATCH (n) 
        WHERE any(prop in keys(n) WHERE toLower(toString(n[prop])) CONTAINS toLower('{keyword}'))
        RETURN labels(n) AS labels, properties(n) AS props
        LIMIT 10
        """
        results = session.run(query)
        print(f"\n--- Results for '{keyword}' ---")
        for record in results:
            print(f"Labels: {record['labels']}")
            print(f"Props: {record['props']}")
    driver.close()

if __name__ == "__main__":
    search_keywords("Nursing")
    search_keywords("Computer Science")
