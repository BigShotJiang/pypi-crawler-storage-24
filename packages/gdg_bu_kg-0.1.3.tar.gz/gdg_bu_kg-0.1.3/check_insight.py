import os
from neo4j import GraphDatabase
from dotenv import load_dotenv

load_dotenv("kg_backend/.env")

uri = os.getenv("NEO4J_URI")
username = os.getenv("NEO4J_USERNAME")
password = os.getenv("NEO4J_PASSWORD")

def debug_insight():
    driver = GraphDatabase.driver(uri, auth=(username, password))
    with driver.session() as session:
        # Search for any node with 'Computer Science' and see all its properties
        res = session.run("MATCH (i:Insight) WHERE any(prop in keys(i) WHERE i[prop] CONTAINS 'Computer Science') RETURN properties(i) LIMIT 1")
        record = res.single()
        if record:
            print(record.data())
        else:
            print("NOT FOUND")
    driver.close()

if __name__ == "__main__":
    debug_insight()
