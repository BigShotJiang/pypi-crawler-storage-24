import os
import time
import httpx
import json
from neo4j import GraphDatabase
from dotenv import load_dotenv

# Load environment
load_dotenv("kg_backend/.env")

TOGETHER_API_KEY = os.getenv("TOGETHER_API_KEY")
NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USERNAME = os.getenv("NEO4J_USERNAME")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")

# The "Iron-Clad" Prompt we just updated in index.py
BABCOCK_SCHEMA_PROMPT = """
You are the Iron-Clad Cypher Expert for the Babcock University Knowledge Graph.
Your goal is to generate precise Cypher queries. IMPORTANT: This is a HYBRID schema.

## 1. Node Labels & Properties
- (s:School) {School_Name: 'Name', School_ID: 'ID'}
- (p:Program) {Program_Name: 'Name', `Admission Requirements`: 'Text', School_ID: 'ID'}
- (st:Staff) {Staff_Name: 'Name', Role: 'Title', Department: 'Dept', School_ID: 'ID'}
- (i:Insight) {title: 'Title', core_summary: 'Text'}
- (c:Course) {Course_Title: 'Title', Course_Code: 'Code'}
- (caf:Cafeteria) {Name: 'Name'}

## 2. Hybrid Connections
A. GRAPH RELATIONSHIPS (Use these with ->):
   - (c:Course)-[:PART_OF]->(p:Program)
   - (p:Program)-[:PART_OF]->(s:School)
   - (caf:Cafeteria)-[:LOCATED_AT]->(:Infrastructure)

B. RELATIONAL & ORPHAN SEARCH (How to find nodes with no direct links):
   - Staff to School: (st:Staff), (s:School) WHERE st.School_ID = s.School_ID
   - Staff to Program: (st:Staff), (p:Program) WHERE toLower(st.Department) CONTAINS toLower(p.Program_Name)
   - Insights: Insights are ORPHANED. To find an insight about 'X', search BOTH i.title and i.core_summary directly.

## 3. Retrieval Rules
- ALWAYS use toLower() and CONTAINS for robust text matching.
- Use backticks for properties with spaces: p.`Admission Requirements`.

## 4. Examples
Q: What are the admission requirements for Nursing?
Cypher: MATCH (p:Program) WHERE toLower(p.Program_Name) CONTAINS 'nursing' RETURN p.Program_Name AS Program, p.`Admission Requirements` AS Requirements

Q: Tell me an insight about Computer Science.
Cypher: MATCH (i:Insight) WHERE toLower(i.title) CONTAINS 'computer science' OR toLower(i.core_summary) CONTAINS 'computer science' RETURN i.title AS Insight, i.core_summary AS Summary

Q: List all lecturers in the School of Computing.
Cypher: MATCH (st:Staff), (s:School) WHERE st.School_ID = s.School_ID AND toLower(s.School_Name) CONTAINS 'computing' RETURN DISTINCT st.Staff_Name AS Lecturer, st.Role AS Role

Q: List all courses for Computer Science.
Cypher: MATCH (c:Course)-[:PART_OF]->(p:Program) WHERE toLower(p.Program_Name) CONTAINS 'computer science' RETURN c.Course_Title AS Course

## Rules
- Return ONLY raw Cypher. No markdown. No explanations.
- Use LIMIT 10 unless asked for more.
"""

MODELS = [
    ("Llama-3.1-8B", "meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo"),
    ("Llama-3.3-70B", "meta-llama/Llama-3.3-70B-Instruct-Turbo")
]

TEST_QUERIES = [
    "What are the admission requirements for Nursing?",
    "Tell me an insight about Computer Science.",
    "List all lecturers in the School of Computing.",
    "Where is the nearest cafeteria?"
]

def run_compare():
    driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD))
    
    print(f"{'Model':<15} | {'Query':<40} | {'G-Lat':<7} | {'Total-Lat':<10} | {'Status'}")
    print("-" * 100)

    for model_name, model_id in MODELS:
        for query in TEST_QUERIES:
            start_total = time.time()
            
            # 1. Cypher Generation
            start_gen = time.time()
            try:
                resp = httpx.post(
                    "https://api.together.xyz/v1/chat/completions",
                    headers={"Authorization": f"Bearer {TOGETHER_API_KEY}"},
                    json={
                        "model": model_id,
                        "messages": [
                            {"role": "system", "content": BABCOCK_SCHEMA_PROMPT},
                            {"role": "user", "content": f"Query: {query}"}
                        ],
                        "temperature": 0.0,
                        "max_tokens": 150
                    },
                    timeout=30.0
                )
                resp.raise_for_status()
                cypher = resp.json()["choices"][0]["message"]["content"].strip().replace("```cypher", "").replace("```", "").split(";")[0].strip()
                gen_time = time.time() - start_gen
            except Exception as e:
                print(f"{model_name:<15} | {query[:40]:<40} | FAIL Gen: {str(e)[:20]}")
                continue

            # 2. Graph Execution
            start_graph = time.time()
            nodes_found = 0
            try:
                with driver.session() as session:
                    res = session.run(cypher)
                    nodes_found = len(list(res))
                graph_time = (time.time() - start_graph) + gen_time
            except Exception as e:
                graph_time = gen_time
                print(f"{model_name:<15} | {query[:40]:<40} | FAIL Graph: {str(e)[:20]}")
                continue

            # 3. Final Answer (LLM Synthesis)
            start_llm = time.time()
            try:
                resp = httpx.post(
                    "https://api.together.xyz/v1/chat/completions",
                    headers={"Authorization": f"Bearer {TOGETHER_API_KEY}"},
                    json={
                        "model": model_id,
                        "messages": [
                            {"role": "system", "content": "You are a helpful Babcock University assistant. Answer based on context."},
                            {"role": "user", "content": f"Question: {query}\nContext: {cypher} results had {nodes_found} records.\nAnswer:"}
                        ],
                        "temperature": 0.4,
                        "max_tokens": 300
                    },
                    timeout=30.0
                )
                total_time = time.time() - start_total
            except Exception as e:
                total_time = time.time() - start_total

            status = "PASS" if nodes_found > 0 else "ZERO_NODES"
            print(f"{model_name:<15} | {query[:40]:<40} | {graph_time:.2f}s | {total_time:.2f}s | {status} ({nodes_found} nodes)")

    driver.close()

if __name__ == "__main__":
    run_compare()
