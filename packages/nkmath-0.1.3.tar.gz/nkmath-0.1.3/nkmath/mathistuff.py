def add(a,b):
    return a+b

def sub(a,b):
    return a-b

def mul(a,b):
    return a*b

def div(a,b):
    return a/b

def float_div(a,b):
    return a//b

def help():
    print("""nkmath.add(n1,n2) = adds the numbers n1,n2,
    nkmath.sub(n1,n2) = subtracts n1,n2
    nkmath.mul(n1,n2) = multiplies n1,n2
    nkmath.div(n1,2) = divides n1,n2
    nkmath.float_div(n1,n2) = float divides n1,n2
    Thanks For Using NkMath! made By Niranthak in Grade 8!""")
