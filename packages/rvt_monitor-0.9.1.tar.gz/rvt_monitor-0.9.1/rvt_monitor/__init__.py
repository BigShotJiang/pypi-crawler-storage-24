"""RVTool - BLE Device Control Application."""

__version__ = "0.9.0"
