"""BLE Connection Manager."""

import asyncio
import logging
import platform
import struct
from datetime import datetime
from enum import Enum
from typing import Callable, Optional

from bleak import BleakClient
from bleak.exc import BleakError

logger = logging.getLogger(__name__)

from .protocol import (
    CharUUID,
    ServiceUUID,
    MotionCommand,
    MotionState,
    build_motion_command,
    build_led_mode,
    build_led_brightness,
    build_led_color_index,
    build_led_color_rgb,
    build_dimension_write,
    build_wifi_config,
    build_generic_command,
    DimensionCommand,
    GenericCommandId,
    LEDTarget,
)
from .scanner import detect_device_type
from .profiles import detect_profile, get_profile
from .parsers import (
    CeilyStatus,
    WallyStatus,
    DeviceStatus,
    parse_ceily_status,
    parse_wally_status,
)


class ConnectionState(Enum):
    """BLE connection state."""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"


_SECURITY_ERROR_KEYWORDS = [
    "insufficient encryption",
    "insufficient authentication",
    "not paired",
    "pairing",
    "security",
    "bond",
    "encrypt",
]


def _is_security_error(error: Exception) -> bool:
    """Check if a BleakError is related to BLE security/pairing."""
    msg = str(error).lower()
    return any(kw in msg for kw in _SECURITY_ERROR_KEYWORDS)


class _StaleBondError(Exception):
    """Connection failed, possibly due to stale bond keys."""


class _SecurityDisconnectError(Exception):
    """Connection established but dropped during security setup.

    Indicates a REPEAT_PAIRING scenario: ESP32 deleted stale bond,
    disconnected, and opened pairing mode for clean reconnect.
    """


class BLEManager:
    """BLE connection and communication manager."""

    def __init__(self):
        self.client: Optional[BleakClient] = None
        self.device_address: Optional[str] = None
        self.device_name: Optional[str] = None
        self.device_type: Optional[str] = None
        self.connection_state = ConnectionState.DISCONNECTED
        self.status: Optional[DeviceStatus] = None
        self.device_info: Optional[dict] = None  # BLE SIG Device Information
        self.profile_id: str = "v1-p2"  # Profile version (v1-p1 or v1-p2)
        self.rssi: int = -100
        self.last_packet_time: Optional[datetime] = None
        self.last_connect_error: Optional[str] = None

        # Status subscription state (for v1-p2 notify mode)
        self._status_subscribed: bool = False

        # Callbacks
        self.on_state_change: Optional[Callable[[ConnectionState], None]] = None
        self.on_status_update: Optional[Callable[[DeviceStatus], None]] = None
        self.on_log_event: Optional[Callable[[str], None]] = None
        self.on_wifi_event: Optional[Callable[[bool], None]] = None
        self.on_disconnect: Optional[Callable[[], None]] = None
        self.on_led_status_update: Optional[Callable[[dict], None]] = None
        self.on_dimensions_update: Optional[Callable[[dict], None]] = None

        # Dimension get response (for v1-p3 notify-based read)
        self._dimension_event: Optional[asyncio.Event] = None
        self._dimension_result: Optional[dict] = None

        # Stats
        self.command_success_count = 0
        self.command_error_count = 0

    @property
    def connected(self) -> bool:
        return (
            self.connection_state == ConnectionState.CONNECTED
            and self.client is not None
            and self.client.is_connected
        )

    def _set_state(self, state: ConnectionState):
        """Update connection state and notify callback."""
        self.connection_state = state
        if self.on_state_change:
            self.on_state_change(state)

    def _on_disconnect(self, client: BleakClient):
        """Handle unexpected disconnection."""
        # Only handle disconnect if we were actually connected
        # Ignore spurious disconnect callbacks during connection attempts
        if self.connection_state != ConnectionState.CONNECTED:
            return
        logger.info("Disconnected from %s", self.device_address)
        self._set_state(ConnectionState.DISCONNECTED)
        self._status_subscribed = False
        self.client = None
        if self.on_disconnect:
            self.on_disconnect()

    def _handle_notification(self, sender, data: bytearray):
        """Handle BLE notification (log events).

        BleLogMessage structure (15 bytes):
        - uint32_t timestamp (4 bytes)
        - uint16_t protocol_version (2 bytes)
        - uint8_t event_type (1 byte)
        - uint8_t data[8] (8 bytes)

        Event types:
        - 3 = WiFi connection status changed
        """
        self.last_packet_time = datetime.now()
        try:
            if len(data) >= 15:
                # Parse binary log message
                timestamp = struct.unpack_from("<I", data, 0)[0]
                protocol_ver = struct.unpack_from("<H", data, 4)[0]
                event_type = data[6]
                event_data = data[7:15]

                message = self._format_log_event(event_type, event_data, timestamp)
                if message and self.on_log_event:
                    self.on_log_event(message)
                # WiFi event: notify status change
                if event_type == 3 and self.on_wifi_event:
                    self.on_wifi_event(event_data[0] == 1)
            else:
                # Try as plain text (fallback)
                message = data.decode("utf-8", errors="replace").strip()
                if message and self.on_log_event:
                    self.on_log_event(message)
        except Exception:
            pass

    def _handle_status_notification(self, sender, data: bytearray):
        """Handle BLE status notification (v1-p2 notify mode)."""
        self.last_packet_time = datetime.now()
        try:
            raw = bytes(data)
            if self.device_type == "ceily":
                self.status, effective = parse_ceily_status(raw, self.profile_id)
                if effective != self.profile_id:
                    print(f"[BLE] Ceily: Data format mismatch, switching to {effective} UI")
                    self.profile_id = effective
            elif self.device_type == "wally":
                self.status, effective = parse_wally_status(raw, self.profile_id)
                if effective != self.profile_id:
                    print(f"[BLE] Wally: Data format mismatch ({len(data)} bytes), switching to {effective} UI")
                    self.profile_id = effective

            if self.on_status_update and self.status:
                self.on_status_update(self.status)
        except Exception as e:
            print(f"[BLE] Status parse error: {e} (len={len(data)})")

    def _handle_led_status_notification(self, sender, data: bytearray):
        """Handle BLE LED status notification."""
        self.last_packet_time = datetime.now()
        try:
            from .protocol import parse_led_status
            result = parse_led_status(bytes(data))
            if result and self.on_led_status_update:
                self.on_led_status_update(result)
        except Exception as e:
            print(f"[BLE] LED status notify parse error: {e}")

    def _handle_dimension_notification(self, sender, data: bytearray):
        """Handle BLE dimension notification (v1-p3 TLV push)."""
        self.last_packet_time = datetime.now()
        try:
            from .protocol import (
                parse_dimensions_tlv,
                CEILY_DIMENSIONS_V3, WALLY_DIMENSIONS_V3,
            )
            values = parse_dimensions_tlv(bytes(data))
            if self.device_type == "ceily":
                dim_meta = CEILY_DIMENSIONS_V3
            elif self.device_type == "wally":
                dim_meta = WALLY_DIMENSIONS_V3
            else:
                return

            result = {
                "device_type": self.device_type,
                "dimensions": [
                    {
                        "id": dim["id"],
                        "name": dim["name"],
                        "unit": dim["unit"],
                        "type": dim["type"],
                        "value": values.get(dim["id"], 0),
                        "readonly": dim.get("readonly", False),
                    }
                    for dim in dim_meta
                ],
            }
            # Signal pending read_all_dimensions() if waiting
            if self._dimension_event:
                self._dimension_result = result
                self._dimension_event.set()

            if self.on_dimensions_update:
                self.on_dimensions_update(result)
        except Exception as e:
            print(f"[BLE] Dimension notify parse error: {e}")

    def _format_log_event(self, event_type: int, data: bytes, timestamp: int) -> str:
        """Format binary log event to human-readable string."""
        # Event type 0: None - ignore
        if event_type == 0:
            return None

        # Event type 1: Command received
        if event_type == 1:
            sender = data[0]
            command = data[1]
            cmd_names = {0: "Stop", 1: "Up", 2: "Down"}
            sender_names = {0: "None", 1: "Button", 2: "BLE", 3: "System"}
            cmd_str = cmd_names.get(command, f"Unknown({command})")
            sender_str = sender_names.get(sender, f"Unknown({sender})")
            return f"Command: {cmd_str} from {sender_str}"

        # Event type 2: Motion state changed
        if event_type == 2:
            state_from = data[0]
            state_to = data[1]
            position = data[2]
            error_code = data[3]
            state_names = {
                0: "Down", 1: "Up", 2: "Moving Down", 3: "Moving Up",
                4: "Stop", 5: "Emergency", 8: "Manual", 255: "Init"
            }
            error_names = {
                0: "None",
                1: "Not initialized",
                2: "Device error",
                3: "Torque outlier detected",
                4: "Object detected",
                5: "E-stop activated",
                6: "Max torque exceeded",
                0x20: "Wally start env error",
                0x21: "Wally slip occurred",
                0x22: "Wally ToF angle error",
            }
            from_str = state_names.get(state_from, f"Unknown({state_from})")
            to_str = state_names.get(state_to, f"Unknown({state_to})")
            err_str = error_names.get(error_code, f"Unknown({error_code})")
            if error_code == 0:
                return f"State: {from_str} -> {to_str}, pos={position}"
            return f"State: {from_str} -> {to_str}, pos={position}, err={err_str}"

        # Event type 3: WiFi connection status
        if event_type == 3:
            status = data[0]
            rssi = struct.unpack("<b", data[1:2])[0]  # signed int8
            if status == 1:  # Connected
                channel = data[2]
                return f"WiFi Connected: ch={channel}, RSSI={rssi}dBm"
            elif status == 2:  # Disconnected
                reason = data[3]
                reason_text = {
                    1: "Unspecified", 2: "Auth expire", 3: "Auth leave",
                    4: "Assoc expire", 5: "Assoc toomany", 6: "Not authed",
                    7: "Not assoced", 8: "Assoc leave", 9: "Assoc not authed",
                    15: "4-way handshake timeout", 16: "Group key update timeout",
                    23: "802.1X auth failed", 200: "Beacon timeout",
                    201: "No AP found", 202: "Auth fail", 203: "Assoc fail",
                    204: "Handshake timeout",
                }.get(reason, f"Unknown({reason})")
                return f"WiFi Disconnected: reason={reason_text}, RSSI={rssi}dBm"
            else:
                return f"WiFi Status: {status}"

        # Event type 4: BLE connection status
        if event_type == 4:
            status = data[0]
            active_count = data[1]
            bonded = "bonded" if data[2] else "unbonded"
            if status == 1:  # Connected
                rssi = struct.unpack("<b", data[3:4])[0]
                encrypted = "encrypted" if data[4] else "plain"
                return (f"BLE Connected ({bonded}, {encrypted}, "
                        f"RSSI={rssi}dBm) [{active_count} conn]")
            elif status == 2:  # Disconnected
                reason = data[3]
                return (f"BLE Disconnected ({bonded}, "
                        f"reason=0x{reason:02X}) [{active_count} conn]")
            else:
                return f"BLE Status: {status}"

        # Event type 5: Config change
        if event_type == 5:
            result = data[0]
            dim_id = data[1]
            value = struct.unpack_from("<h", data, 2)[0]
            current = struct.unpack_from("<h", data, 4)[0]
            result_names = {0: "changed", 1: "rejected(range)", 2: "rejected(not found)"}
            result_str = result_names.get(result, f"unknown({result})")
            if result == 0:
                return f"Config: dim=0x{dim_id:02X} -> {value} ({result_str})"
            return f"Config: dim=0x{dim_id:02X} val={value} cur={current} ({result_str})"

        # Event type 6: MQTT connection status
        if event_type == 6:
            status = data[0]
            if status == 1:
                return "MQTT Connected"
            elif status == 2:
                return "MQTT Disconnected"
            elif status == 3:
                error_type = data[1] if len(data) > 1 else 0
                return f"MQTT Error (type={error_type})"
            else:
                return f"MQTT Status: {status}"

        # Unknown event type - show hex
        hex_data = data[:8].hex()
        return f"Event[{event_type}]: {hex_data}"

    async def connect(self, address: str, name: str = "",
                      pairable: bool = False) -> bool:
        """Connect to a BLE device.

        Args:
            address: BLE device address
            name: Device name
            pairable: Device pairing flag from scan manufacturer data.
                      If False, skip BLE pairing even for v1-p3+ devices.

        Returns True on success.
        On failure, sets self.last_connect_error with reason string.
        """
        self.last_connect_error = None

        if self.connected:
            await self.disconnect()

        self._set_state(ConnectionState.CONNECTING)
        self.device_address = address
        self.device_name = name
        self.device_type = detect_device_type(name) if name else None

        # Initialize status based on device type
        if self.device_type == "ceily":
            self.status = CeilyStatus()
        elif self.device_type == "wally":
            self.status = WallyStatus()
        else:
            self.status = None

        # On Linux, register BlueZ agent once for Just Works pairing
        if platform.system() == "Linux":
            from .bluez_agent import ensure_bluez_agent
            await ensure_bluez_agent()

        try:
            result = await self._connect_and_pair(address, pairable)
            return result
        except _SecurityDisconnectError:
            # Connection established but dropped during security setup.
            # REPEAT_PAIRING pattern: ESP32 deleted stale bond and opened
            # pairing mode. Clear local cache and retry with fresh pairing.
            logger.info(
                "Security disconnect detected — "
                "retrying with fresh pairing in 2s"
            )
            if platform.system() == "Linux":
                from .bluez_agent import remove_devices_by_name, remove_device
                if name:
                    await remove_devices_by_name(name)
                else:
                    await remove_device(address)
            await asyncio.sleep(2.0)
            try:
                result = await self._connect_and_pair(address, pairable=True)
                return result
            except Exception as retry_err:
                logger.warning(
                    "Reconnect after security disconnect failed: %s",
                    retry_err,
                )
                self.last_connect_error = (
                    "Reconnect after security disconnect failed. "
                    "Use 'Reset Bond' to clear cached keys."
                )
                self._set_state(ConnectionState.DISCONNECTED)
                self.client = None
                return False
        except _StaleBondError as e:
            cause = str(e.__cause__) if e.__cause__ else "unknown"
            self.last_connect_error = (
                f"Stale bond ({cause}). "
                "Use 'Reset Bond' button to clear cached keys."
            )
            logger.warning("Stale bond error: %s", cause)
            self._set_state(ConnectionState.DISCONNECTED)
            self.client = None
            return False
        except BleakError as e:
            logger.warning("BleakError during connect: %s", e)
            self._set_state(ConnectionState.DISCONNECTED)
            if self.client:
                try:
                    await self.client.disconnect()
                except Exception:
                    pass
            self.client = None
            if _is_security_error(e):
                raise BleakError(
                    "기기가 페어링 모드가 아닙니다. "
                    "버튼을 3초간 눌러주세요."
                ) from e
            raise
        except Exception as e:
            logger.warning("Unexpected error during connect: %s", e)
            self.last_connect_error = str(e)
            self._set_state(ConnectionState.DISCONNECTED)
            if self.client:
                try:
                    await self.client.disconnect()
                except Exception:
                    pass
            self.client = None
            return False

    async def _connect_and_pair(self, address: str,
                               pairable: bool = False) -> bool:
        """Internal: connect, detect profile, pair if pairable, set up notifications.

        Raises _StaleBondError if connection fails due to stale bond keys.
        """
        logger.info("Connecting to %s (pairable=%s)", address, pairable)
        self.client = BleakClient(
            address,
            disconnected_callback=self._on_disconnect,
        )

        try:
            await asyncio.wait_for(
                self.client.connect(),
                timeout=20.0,
            )
        except (BleakError, asyncio.TimeoutError, Exception) as e:
            logger.warning("Connect failed: %s", e)
            if self.client:
                try:
                    await self.client.disconnect()
                except Exception:
                    pass
            self.client = None
            raise _StaleBondError() from e

        if self.client is None or not self.client.is_connected:
            raise _StaleBondError()

        logger.info("Connected to %s (mtu=%d)", address, self.client.mtu_size)

        # --- Setup phase: any disconnect here indicates security-level
        # failure (e.g., REPEAT_PAIRING). Wrap to detect this pattern. ---
        try:
            return await self._setup_after_connect(pairable)
        except Exception as e:
            if self.client is None or not self.client.is_connected:
                # Connected then dropped = security disconnect
                if self.client:
                    try:
                        await self.client.disconnect()
                    except Exception:
                        pass
                self.client = None
                raise _SecurityDisconnectError() from e
            raise

    async def _setup_after_connect(self, pairable: bool) -> bool:
        """Post-connect setup: profile detection, pairing, subscriptions.

        Separated from _connect_and_pair so that security disconnects
        (e.g., REPEAT_PAIRING) can be detected at the boundary.
        """
        # Wait for connection to stabilize (BlueZ needs time after connect)
        await asyncio.sleep(0.5)

        # Detect profile from available services
        services = self.client.services
        service_uuids = [str(s.uuid) for s in services]
        self.profile_id = detect_profile(service_uuids)
        logger.info("Detected profile: %s", self.profile_id)

        # Read Device Information Service (v1-p2+)
        if get_profile(self.profile_id)["has_device_info"]:
            self.device_info = await self.read_device_info()
            pv = self.device_info.get("protocol_version") if self.device_info else None
            if pv and pv >= 3:
                self.profile_id = "v1-p3"
                logger.info("Upgraded profile to v1-p3 (protocol_version=%s)", pv)
        else:
            self.device_info = None

        # Pair only if device advertised pairable flag
        if pairable:
            logger.info("Initiating BLE pairing...")
            try:
                await self.client.pair()
                logger.info("Pairing completed successfully")
            except Exception as e:
                logger.warning("Pairing failed: %s", e)
                if self.client is None or not self.client.is_connected:
                    raise _StaleBondError() from e
        else:
            logger.info("Skipping pairing (pairable=%s)", pairable)

        if self.client is None or not self.client.is_connected:
            raise _StaleBondError()

        # Start notification for log events
        try:
            if self.client:
                await self.client.start_notify(
                    CharUUID.LOG_EVENT,
                    self._handle_notification,
                )
                logger.info("Subscribed to log event notifications")
        except Exception as e:
            logger.warning("Log event notify subscribe failed: %s", e)

        # Subscribe to LED status notifications
        try:
            if self.client:
                await self.client.start_notify(
                    CharUUID.LED_STATUS,
                    self._handle_led_status_notification,
                )
                logger.info("Subscribed to LED status notifications")
        except Exception as e:
            logger.warning("LED status notify subscribe failed: %s", e)

        # Subscribe to dimension notifications (v1-p3 only)
        if self.profile_id == "v1-p3":
            try:
                if self.client:
                    await self.client.start_notify(
                        CharUUID.DIMENSION,
                        self._handle_dimension_notification,
                    )
                    logger.info("Subscribed to dimension notifications")
            except Exception as e:
                logger.warning("Dimension notify subscribe failed: %s", e)

        # Set user name on device
        try:
            if self.client:
                await self.client.write_gatt_char(
                    CharUUID.USER_NAME,
                    b"rvt-monitor",
                )
                logger.info("User name set to 'rvt-monitor'")
        except Exception as e:
            logger.debug("User name write skipped: %s", e)

        # Verify still connected after setup
        if self.client is None or not self.client.is_connected:
            raise BleakError("Connection lost during setup")

        self._set_state(ConnectionState.CONNECTED)
        self.last_packet_time = datetime.now()
        logger.info("Connection setup complete (profile=%s)", self.profile_id)

        return True

    async def disconnect(self):
        """Disconnect from current device."""
        if self.client:
            try:
                await self.client.disconnect()
            except Exception:
                pass
            self.client = None
        self.device_info = None
        self._status_subscribed = False
        self._set_state(ConnectionState.DISCONNECTED)

    async def read_status(self) -> Optional[DeviceStatus]:
        """Read device status."""
        if not self.connected:
            return None

        try:
            data = await self.client.read_gatt_char(CharUUID.SYSTEM_STATUS)
            self.last_packet_time = datetime.now()

            if self.device_type == "ceily":
                self.status, effective = parse_ceily_status(data, self.profile_id)
                if effective != self.profile_id:
                    print(f"[BLE] Ceily: Data format mismatch, switching to {effective} UI")
                    self.profile_id = effective
            elif self.device_type == "wally":
                self.status, effective = parse_wally_status(data, self.profile_id)
                if effective != self.profile_id:
                    print(f"[BLE] Wally: Data format mismatch ({len(data)} bytes), switching to {effective} UI")
                    self.profile_id = effective

            if self.on_status_update and self.status:
                self.on_status_update(self.status)

            return self.status

        except BleakError as e:
            self.command_error_count += 1
            if _is_security_error(e):
                if self.on_log_event:
                    self.on_log_event(
                        "암호화된 연결이 필요합니다. "
                        "기기를 재페어링하세요."
                    )
            return None
        except Exception:
            self.command_error_count += 1
            return None

    async def subscribe_status(self) -> bool:
        """Subscribe to status notifications (v1-p2 notify mode).

        Returns True if successfully subscribed.
        """
        if not self.connected:
            return False

        if self._status_subscribed:
            return True

        try:
            await self.client.start_notify(
                CharUUID.SYSTEM_STATUS,
                self._handle_status_notification,
            )
            self._status_subscribed = True
            return True
        except Exception:
            return False

    async def unsubscribe_status(self) -> bool:
        """Unsubscribe from status notifications.

        Returns True if successfully unsubscribed.
        """
        if not self.connected:
            return False

        if not self._status_subscribed:
            return True

        try:
            await self.client.stop_notify(CharUUID.SYSTEM_STATUS)
            self._status_subscribed = False
            return True
        except Exception:
            return False

    @property
    def status_subscribed(self) -> bool:
        """Return whether status notifications are subscribed."""
        return self._status_subscribed

    async def send_command(self, command: MotionCommand) -> bool:
        """Send motion command (UP/DOWN/STOP)."""
        if not self.connected:
            return False

        try:
            if self.profile_id == "v1-p3":
                data = build_generic_command(
                    GenericCommandId.MOTION_CONTROL, bytes([command])
                )
                await self.client.write_gatt_char(
                    CharUUID.GENERIC_CONTROL, data
                )
            else:
                data = build_motion_command(command)
                await self.client.write_gatt_char(
                    CharUUID.MOTION_CONTROL, data
                )
            self.command_success_count += 1
            self.last_packet_time = datetime.now()
            return True
        except BleakError as e:
            self.command_error_count += 1
            if _is_security_error(e) and self.on_log_event:
                self.on_log_event(
                    "암호화된 연결이 필요합니다. "
                    "기기를 재페어링하세요."
                )
            return False
        except Exception:
            self.command_error_count += 1
            return False

    async def send_up(self) -> bool:
        """Send UP/OPEN command."""
        return await self.send_command(MotionCommand.UP)

    async def send_down(self) -> bool:
        """Send DOWN/CLOSE command."""
        return await self.send_command(MotionCommand.DOWN)

    async def send_stop(self) -> bool:
        """Send STOP command."""
        return await self.send_command(MotionCommand.STOP)

    async def _send_led_command(self, data: bytes) -> bool:
        """Send LED command via generic control (v1-p3) or legacy characteristic."""
        if not self.connected:
            return False

        try:
            if self.profile_id == "v1-p3":
                payload = build_generic_command(
                    GenericCommandId.LED_CONTROL, data
                )
                await self.client.write_gatt_char(
                    CharUUID.GENERIC_CONTROL, payload
                )
            else:
                await self.client.write_gatt_char(CharUUID.LED_CONTROL, data)
            self.command_success_count += 1
            return True
        except Exception as e:
            print(f"[BLE] LED command error: {e}")
            self.command_error_count += 1
            return False

    async def set_led_brightness(self, target: LEDTarget, brightness: int) -> bool:
        """Set LED brightness (0-255)."""
        return await self._send_led_command(build_led_brightness(target, brightness))

    async def set_led_color_index(self, index: int) -> bool:
        """Set LED color by index."""
        return await self._send_led_command(build_led_color_index(index))

    async def set_led_color(self, r: int, g: int, b: int) -> bool:
        """Set LED RGB color (writes to custom color slot index 2)."""
        return await self._send_led_command(build_led_color_rgb(2, r, g, b))

    async def set_led_mode(self, target: LEDTarget, on: bool) -> bool:
        """Set LED on/off mode."""
        return await self._send_led_command(build_led_mode(target, on))

    async def read_led_status(self) -> Optional[dict]:
        """Read LED status (22 bytes)."""
        if not self.connected:
            return None

        try:
            data = await self.client.read_gatt_char(CharUUID.LED_STATUS)
            self.last_packet_time = datetime.now()
            from .protocol import parse_led_status
            return parse_led_status(data)
        except Exception:
            self.command_error_count += 1
            return None

    async def read_dimension(self, dimension_id: int) -> Optional[int]:
        """Read dimension value."""
        if not self.connected:
            return None

        try:
            data = build_dimension_write(dimension_id, 0)
            await self.client.write_gatt_char(CharUUID.DIMENSION, data)
            result = await self.client.read_gatt_char(CharUUID.DIMENSION)
            if len(result) >= 8:
                _, value = struct.unpack("<II", result[:8])
                return value
            return None
        except Exception:
            self.command_error_count += 1
            return None

    async def write_dimension(self, dimension_id: int, value: int) -> bool:
        """Write dimension value."""
        if not self.connected:
            return False

        try:
            payload = build_dimension_write(dimension_id, value)
            if self.profile_id == "v1-p3":
                data = build_generic_command(
                    GenericCommandId.DIMENSION_SET, payload
                )
                await self.client.write_gatt_char(
                    CharUUID.GENERIC_CONTROL, data
                )
            else:
                await self.client.write_gatt_char(CharUUID.DIMENSION, payload)
            self.command_success_count += 1
            return True
        except Exception:
            self.command_error_count += 1
            return False

    async def save_dimensions(self) -> bool:
        """Save all dimensions to flash."""
        if not self.connected:
            return False

        if self.profile_id == "v1-p3":
            # v1-p3: auto-saved on each DimensionSet, no explicit save needed
            return True

        try:
            data = build_dimension_write(DimensionCommand.SAVE, 0)
            await self.client.write_gatt_char(CharUUID.DIMENSION, data)
            self.command_success_count += 1
            return True
        except Exception:
            self.command_error_count += 1
            return False

    async def set_wifi_config(self, ssid: str, password: str) -> bool:
        """Set WiFi configuration."""
        if not self.connected:
            return False

        try:
            data = build_wifi_config(ssid, password)
            await self.client.write_gatt_char(CharUUID.WIFI_CONFIG, data)
            self.command_success_count += 1
            return True
        except Exception:
            self.command_error_count += 1
            return False

    async def read_wifi_status(self) -> Optional[dict]:
        """Read WiFi configuration status (33 bytes: 32 SSID + 1 status)."""
        if not self.connected:
            return None

        try:
            data = await self.client.read_gatt_char(CharUUID.WIFI_CONFIG)
            from .protocol import parse_wifi_status
            return parse_wifi_status(data)
        except Exception:
            self.command_error_count += 1
            return None

    async def read_device_info(self) -> Optional[dict]:
        """Read Device Information Service (BLE SIG 0x180A).

        Returns dict with:
        - manufacturer_name: e.g., "Rovothome"
        - model_number: e.g., "ceily" or "wally"
        - serial_number: e.g., "1234567890123456"
        - hardware_revision: e.g., "v1"
        - firmware_revision: e.g., "2.7.10-efac753f-p3"
        - protocol_version: parsed from firmware_revision suffix (e.g., 3)
        """
        # Use client.is_connected directly (not self.connected)
        # because this may be called during _connect_and_pair before
        # connection_state is set to CONNECTED.
        if not self.client or not self.client.is_connected:
            return None

        result = {
            "manufacturer_name": None,
            "model_number": None,
            "serial_number": None,
            "hardware_revision": None,
            "firmware_revision": None,
            "protocol_version": None,
        }

        try:
            # Read Manufacturer Name (e.g., "Rovothome")
            data = await self.client.read_gatt_char(CharUUID.MANUFACTURER_NAME)
            result["manufacturer_name"] = data.decode("utf-8").rstrip("\x00")
        except Exception as e:
            print(f"[BLE] Failed to read manufacturer_name: {e}")

        try:
            # Read Model Number (e.g., "ceily" or "wally")
            data = await self.client.read_gatt_char(CharUUID.MODEL_NUMBER)
            result["model_number"] = data.decode("utf-8").rstrip("\x00")
        except Exception as e:
            print(f"[BLE] Failed to read model_number: {e}")

        try:
            # Read Serial Number (e.g., "1234567890123456")
            data = await self.client.read_gatt_char(CharUUID.SERIAL_NUMBER)
            result["serial_number"] = data.decode("utf-8").rstrip("\x00")
        except Exception as e:
            print(f"[BLE] Failed to read serial_number: {e}")

        try:
            # Read Hardware Revision (e.g., "v1")
            data = await self.client.read_gatt_char(CharUUID.HARDWARE_REVISION)
            result["hardware_revision"] = data.decode("utf-8").rstrip("\x00")
        except Exception as e:
            print(f"[BLE] Failed to read hardware_revision: {e}")

        try:
            # Read Firmware Revision (e.g., "2.7.10-efac753f-p3")
            data = await self.client.read_gatt_char(CharUUID.FIRMWARE_REVISION)
            result["firmware_revision"] = data.decode("utf-8").rstrip("\x00")
            # Parse protocol version from fw revision suffix (e.g., "...-p3" -> 3)
            fw = result["firmware_revision"]
            if fw and "-p" in fw:
                try:
                    result["protocol_version"] = int(fw.rsplit("-p", 1)[1])
                except (ValueError, IndexError):
                    pass
        except Exception as e:
            print(f"[BLE] Failed to read firmware_revision: {e}")

        self.last_packet_time = datetime.now()
        print(f"[BLE] Device info result: {result}")
        return result

    async def read_all_dimensions(self) -> Optional[dict]:
        """Read all dimensions from device.

        v1-p3: Send DimensionGet command, wait for notify response.
        v1-p2: Read DIMENSION characteristic (fixed binary struct).
        """
        if not self.connected:
            return None

        is_v3 = self.profile_id == "v1-p3"

        if is_v3:
            # Send GenericCmdDimensionGet and wait for notify
            try:
                self._dimension_event = asyncio.Event()
                self._dimension_result = None
                data = build_generic_command(GenericCommandId.DIMENSION_GET)
                await self.client.write_gatt_char(
                    CharUUID.GENERIC_CONTROL, data
                )
                await asyncio.wait_for(
                    self._dimension_event.wait(), timeout=3.0
                )
                return self._dimension_result
            except Exception:
                self.command_error_count += 1
                return None
            finally:
                self._dimension_event = None

        # v1-p2: fixed binary struct (ceily=12B, wally=24B)
        from .protocol import (
            CEILY_DIMENSIONS, WALLY_DIMENSIONS,
            parse_ceily_dimensions_v2,
            parse_wally_dimensions_v2,
        )

        if self.device_type == "ceily":
            dim_meta = CEILY_DIMENSIONS
        elif self.device_type == "wally":
            dim_meta = WALLY_DIMENSIONS
        else:
            return None

        try:
            data = await self.client.read_gatt_char(CharUUID.DIMENSION)
            self.last_packet_time = datetime.now()

            if self.device_type == "ceily":
                values = parse_ceily_dimensions_v2(data)
            else:
                values = parse_wally_dimensions_v2(data)

            return {
                "device_type": self.device_type,
                "dimensions": [
                    {
                        "id": dim["id"],
                        "name": dim["name"],
                        "unit": dim["unit"],
                        "type": dim["type"],
                        "value": values.get(dim["id"], 0),
                        "readonly": dim.get("readonly", False),
                    }
                    for dim in dim_meta
                ],
            }
        except Exception:
            self.command_error_count += 1
            return None

    def get_stats(self) -> dict:
        """Get command statistics."""
        total = self.command_success_count + self.command_error_count
        success_rate = (
            (self.command_success_count / total * 100) if total > 0 else 0
        )
        return {
            "success_count": self.command_success_count,
            "error_count": self.command_error_count,
            "success_rate": round(success_rate, 1),
        }

    def get_connection_info(self) -> dict:
        """Get current connection info."""
        info = {
            "connected": self.connected,
            "state": self.connection_state.value,
            "device_name": self.device_name,
            "device_address": self.device_address,
            "device_type": self.device_type,
            "profile_id": self.profile_id,
            "rssi": self.rssi,
            "last_packet": (
                self.last_packet_time.isoformat()
                if self.last_packet_time else None
            ),
        }
        if self.device_info:
            info["device_info"] = self.device_info
        return info
