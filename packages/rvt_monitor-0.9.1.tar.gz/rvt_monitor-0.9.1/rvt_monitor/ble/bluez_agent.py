"""BlueZ NoInputNoOutput pairing agent for Just Works BLE pairing.

Registers a D-Bus agent so that BlueZ can auto-accept Just Works
pairing requests without requiring a manual `bluetoothctl agent` session.
"""

import asyncio
import logging

from dbus_fast import BusType
from dbus_fast.aio import MessageBus
from dbus_fast.service import ServiceInterface, method

logger = logging.getLogger(__name__)

AGENT_PATH = "/rvt_monitor/agent"
CAPABILITY = "NoInputNoOutput"

# Keep references to prevent GC
_bus = None
_agent = None


class _NoInputNoOutputAgent(ServiceInterface):
    """BlueZ Agent1 implementation for Just Works pairing."""

    def __init__(self):
        super().__init__("org.bluez.Agent1")

    @method()
    def Release(self) -> None:
        logger.info("BlueZ agent released")

    @method()
    def RequestConfirmation(self, device: "o", passkey: "u") -> None:
        logger.info(f"Auto-confirming pairing for {device}")

    @method()
    def RequestAuthorization(self, device: "o") -> None:
        logger.info(f"Auto-authorizing {device}")

    @method()
    def AuthorizeService(self, device: "o", uuid: "s") -> None:
        logger.info(f"Auto-authorizing service {uuid} for {device}")

    @method()
    def Cancel(self) -> None:
        logger.info("Pairing cancelled")


async def ensure_bluez_agent() -> bool:
    """Register a NoInputNoOutput agent with BlueZ (idempotent).

    Returns True if agent is registered, False on failure.
    """
    global _bus, _agent

    if _bus is not None:
        return True

    try:
        bus = await MessageBus(bus_type=BusType.SYSTEM).connect()
        agent = _NoInputNoOutputAgent()
        bus.export(AGENT_PATH, agent)

        introspection = await bus.introspect("org.bluez", "/org/bluez")
        proxy = bus.get_proxy_object(
            "org.bluez", "/org/bluez", introspection
        )
        agent_manager = proxy.get_interface(
            "org.bluez.AgentManager1"
        )

        await agent_manager.call_register_agent(AGENT_PATH, CAPABILITY)
        await agent_manager.call_request_default_agent(AGENT_PATH)

        _bus = bus
        _agent = agent
        logger.info("BlueZ NoInputNoOutput agent registered")
        return True

    except Exception as e:
        logger.warning(f"Failed to register BlueZ agent: {e}")
        return False


async def remove_device(address: str) -> bool:
    """Remove a device from BlueZ cache (clears stale bond keys).

    Equivalent to `bluetoothctl remove <address>`.
    """
    try:
        bus = await MessageBus(bus_type=BusType.SYSTEM).connect()

        addr_path = address.upper().replace(":", "_")

        for adapter in ["hci0", "hci1"]:
            device_path = f"/org/bluez/{adapter}/dev_{addr_path}"
            adapter_path = f"/org/bluez/{adapter}"
            try:
                adapter_intro = await bus.introspect(
                    "org.bluez", adapter_path
                )
                adapter_proxy = bus.get_proxy_object(
                    "org.bluez", adapter_path, adapter_intro
                )
                adapter_iface = adapter_proxy.get_interface(
                    "org.bluez.Adapter1"
                )
                await adapter_iface.call_remove_device(device_path)
                logger.info(f"Removed device {address} from BlueZ")
                bus.disconnect()
                return True
            except Exception as e:
                logger.debug(f"remove_device {adapter}: {e}")
                continue

        logger.warning(f"Device {address} not found in BlueZ")
        bus.disconnect()
        return False

    except Exception as e:
        logger.warning(f"Failed to remove device {address}: {e}")
        return False


async def remove_devices_by_name(name: str) -> int:
    """Remove ALL BlueZ cached entries matching a device name.

    RPA devices may have multiple cached entries with different addresses.
    Returns the number of devices removed.
    """
    removed = 0
    try:
        bus = await MessageBus(bus_type=BusType.SYSTEM).connect()

        for adapter in ["hci0", "hci1"]:
            adapter_path = f"/org/bluez/{adapter}"
            try:
                adapter_intro = await bus.introspect(
                    "org.bluez", adapter_path
                )
            except Exception:
                continue

            adapter_proxy = bus.get_proxy_object(
                "org.bluez", adapter_path, adapter_intro
            )
            adapter_iface = adapter_proxy.get_interface(
                "org.bluez.Adapter1"
            )

            # Enumerate all device objects under this adapter
            for child in adapter_intro.nodes:
                device_path = f"{adapter_path}/{child.name}"
                try:
                    dev_intro = await bus.introspect(
                        "org.bluez", device_path
                    )
                    dev_proxy = bus.get_proxy_object(
                        "org.bluez", device_path, dev_intro
                    )
                    dev_iface = dev_proxy.get_interface(
                        "org.bluez.Device1"
                    )
                    dev_name = await dev_iface.get_name()
                    if dev_name == name:
                        await adapter_iface.call_remove_device(device_path)
                        logger.info(
                            f"Removed cached device: {child.name} ({name})"
                        )
                        removed += 1
                except Exception:
                    continue

        bus.disconnect()

    except Exception as e:
        logger.warning(f"Failed to enumerate BlueZ devices: {e}")

    logger.info(f"Removed {removed} cached entries for '{name}'")
    return removed
