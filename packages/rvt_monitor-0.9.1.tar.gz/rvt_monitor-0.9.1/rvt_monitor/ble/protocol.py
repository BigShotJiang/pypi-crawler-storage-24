"""BLE GATT Protocol Definitions for Ceily/Wally devices."""

from enum import IntEnum

# Device prefixes for scanning
DEVICE_PREFIX_CEILY = "ceily-"
DEVICE_PREFIX_WALLY = "wally-"


# =============================================================================
# Service UUIDs
# =============================================================================

class ServiceUUID:
    """BLE Service UUIDs."""
    # BLE SIG Standard Services
    DEVICE_INFO = "0000180a-0000-1000-8000-00805f9b34fb"  # 16-bit: 0x180A
    # Custom Services
    CONTROL = "0000ff20-0000-1000-8000-00805f9b34fb"  # 16-bit: 0xFF20
    SYSTEM_STATUS = "501a8cf5-98a7-4370-bb97-632c84910000"
    DIMENSION = "cc9762a6-bbb7-4b21-b2e2-153059030000"
    LED = "07ecc81b-b952-47e6-a1f1-0999577f0000"
    LOG = "cc9762a6-bbb7-4b21-b2e2-153059032200"
    GENERIC_CONTROL = "1444862b-b565-4e67-bea3-ca66bfb0f22c"


# =============================================================================
# Characteristic UUIDs
# =============================================================================

class CharUUID:
    """BLE Characteristic UUIDs."""
    # Device Information Service (Read) - BLE SIG Standard
    MANUFACTURER_NAME = "00002a29-0000-1000-8000-00805f9b34fb"  # 16-bit: 0x2A29
    MODEL_NUMBER = "00002a24-0000-1000-8000-00805f9b34fb"  # 16-bit: 0x2A24
    SERIAL_NUMBER = "00002a25-0000-1000-8000-00805f9b34fb"  # 16-bit: 0x2A25
    HARDWARE_REVISION = "00002a27-0000-1000-8000-00805f9b34fb"  # 16-bit: 0x2A27
    FIRMWARE_REVISION = "00002a26-0000-1000-8000-00805f9b34fb"  # 16-bit: 0x2A26

    # Motion Control (Write)
    MOTION_CONTROL = "0000ff21-0000-1000-8000-00805f9b34fb"  # 16-bit: 0xFF21

    # System Status (Read/Notify)
    SYSTEM_STATUS = "501a8cf5-98a7-4370-bb97-632c84910001"

    # Dimension (Read/Write)
    DIMENSION = "cc9762a6-bbb7-4b21-b2e2-153059030001"

    # LED Control (Write)
    LED_CONTROL = "07ecc81b-b952-47e6-a1f1-0999577f0001"
    # LED Status (Read)
    LED_STATUS = "07ecc81b-b952-47e6-a1f1-0999577f0002"

    # Log Event (Notify)
    LOG_EVENT = "cc9762a6-bbb7-4b21-b2e2-153059032201"

    # Generic Control (Write)
    GENERIC_CONTROL = "c09827c2-96ac-428d-a8b7-16a40c531f19"

    # User Registry (Read/Write)
    USER_NAME = "cc9762a6-bbb7-4b21-b2e2-153059030401"

    # WiFi Provisioning (Read/Write)
    WIFI_CONFIG = "0caaae86-33a2-4f8e-93d2-4de5c6a900af"


# =============================================================================
# Motion Commands
# =============================================================================

class GenericCommandId(IntEnum):
    """Generic control command IDs (uint32, little-endian)."""
    MOTION_CONTROL = 0x00000001
    LED_CONTROL = 0x00000002
    DIMENSION_SET = 0x00000003
    DIMENSION_GET = 0x00000004


class MotionCommand(IntEnum):
    """Motion control commands (for MOTION_CONTROL characteristic)."""
    STOP = 0x00
    UP = 0x01      # Ceily: Up, Wally: Open
    DOWN = 0x02    # Ceily: Down, Wally: Close

    # Aliases for Wally
    OPEN = 0x01
    CLOSE = 0x02


# =============================================================================
# Motion State
# =============================================================================

class MotionState(IntEnum):
    """Device motion state (from SYSTEM_STATUS characteristic byte 0)."""
    DOWN = 0       # Ceily: Down position, Wally: Closed
    UP = 1         # Ceily: Up position, Wally: Opened
    MOVING_DOWN = 2
    MOVING_UP = 3
    STOP = 4
    EMERGENCY = 5
    MANUAL = 8     # External manual drive detected
    INIT = 255


# =============================================================================
# LED Commands
# =============================================================================

class LEDCommand(IntEnum):
    """LED control commands."""
    NONE = 0
    CHANGE_MODE = 1
    CHANGE_BRIGHTNESS = 2
    CHANGE_RGB_INDEX = 3
    CHANGE_COLOR = 4


class LEDTarget(IntEnum):
    """LED target index."""
    WALL = 0
    DIRECT = 1
    CEILING = 2
    HEAD = 3
    ALL = 0xFF


# =============================================================================
# Dimension Commands and IDs
# =============================================================================

class DimensionCommand(IntEnum):
    """Dimension save command."""
    SAVE = 0xFD


# --- v1-p2 legacy dimension IDs (deployed firmware) ---

class CeilyDimensionID(IntEnum):
    """Ceily dimension IDs (v1-p2)."""
    WIDTH_MM = 0x01
    LENGTH_MM = 0x02
    STROKE_MM = 0x03
    GEAR_RATIO = 0x04
    PULLEY_RADIUS_MM = 0x05
    TOF_ENABLED = 0x06
    TORQUE_THRESHOLD_MNM = 0x07
    MISSION_SPEED = 0x08
    COLOR_LED_TYPE = 0x09
    REMOTE_CTRL = 0x0A


class WallyDimensionID(IntEnum):
    """Wally dimension IDs (v1-p2)."""
    OPEN_LIMIT_DISTANCE_MM = 0x01
    LEFT_WHEEL_FROM_TOF_MM = 0x04
    RIGHT_WHEEL_FROM_TOF_MM = 0x05
    LEFT_TOF_OFFSET_FROM_CENTER_MM = 0x06
    RIGHT_TOF_OFFSET_FROM_CENTER_MM = 0x07
    TOF_Y_OFFSET_FROM_CENTER_MM = 0x08
    IS_OPEN_PLUS_DIRECTION = 0x09
    WHEEL_RADIUS_MM = 0x0A
    GEAR_RATIO = 0x0B
    KEEP_DISTANCE_MM = 0x0C
    MISSION_SPEED = 0x0D
    TORQUE_THRESHOLD_MNM = 0x0E
    COLOR_LED_TYPE = 0x0F
    REMOTE_CTRL = 0x10
    CONTROL_BUTTON_VERSION = 0xEE


# --- v1-p3 unified dimension IDs (matches firmware DimensionEnum) ---

class DimensionID(IntEnum):
    """Unified dimension IDs (v1-p3).

    Common (0x00~0x0F): Shared across all devices
    Wally-common (0x20~0x2F): Shared across Wally v1/v2
    V1-specific (0x30~0x3F): V1 hardware only
    """
    # Common
    WIDTH_MM = 0x01
    LENGTH_MM = 0x02
    STROKE_MM = 0x03
    GEAR_RATIO = 0x04
    DRIVE_RADIUS_MM = 0x05
    TORQUE_THRESHOLD_MNM = 0x07
    MISSION_SPEED = 0x08
    COLOR_LED_TYPE = 0x09
    REMOTE_CTRL = 0x0A
    CONTROL_BUTTON_VERSION = 0x0B
    LED_CAL = 0x0C
    # Wally-common
    IS_OPEN_PLUS_DIRECTION = 0x20
    KEEP_DISTANCE_MM = 0x21
    MOTOR_DISTANCE_MM = 0x22
    # V1-specific
    V1_CEILY_TOF_ENABLED = 0x30
    V1_WALLY_LEFT_WHEEL_FROM_TOF_MM = 0x35
    V1_WALLY_RIGHT_WHEEL_FROM_TOF_MM = 0x36
    V1_WALLY_LEFT_TOF_OFFSET_FROM_CENTER_MM = 0x37
    V1_WALLY_RIGHT_TOF_OFFSET_FROM_CENTER_MM = 0x38
    V1_WALLY_TOF_Y_OFFSET_FROM_CENTER_MM = 0x39


# ToF enabled bit flags
TOF_ENABLED_FRONT = 1 << 0
TOF_ENABLED_LEFT = 1 << 1
TOF_ENABLED_RIGHT = 1 << 2
TOF_ENABLED_ALL = TOF_ENABLED_FRONT | TOF_ENABLED_LEFT | TOF_ENABLED_RIGHT


# --- v1-p2 dimension metadata ---

CEILY_DIMENSIONS = [
    {"id": CeilyDimensionID.WIDTH_MM, "name": "Width", "unit": "mm", "type": "uint16"},
    {"id": CeilyDimensionID.LENGTH_MM, "name": "Length", "unit": "mm", "type": "uint16"},
    {"id": CeilyDimensionID.STROKE_MM, "name": "Stroke", "unit": "mm", "type": "uint16"},
    {"id": CeilyDimensionID.GEAR_RATIO, "name": "Gear Ratio", "unit": "", "type": "uint8"},
    {"id": CeilyDimensionID.PULLEY_RADIUS_MM, "name": "Pulley Radius", "unit": "mm", "type": "uint8"},
    {"id": CeilyDimensionID.TOF_ENABLED, "name": "ToF Enabled", "unit": "", "type": "uint8"},
    {"id": CeilyDimensionID.TORQUE_THRESHOLD_MNM, "name": "Torque Threshold", "unit": "mNm", "type": "uint16"},
    {"id": CeilyDimensionID.MISSION_SPEED, "name": "Mission Speed", "unit": "", "type": "uint8"},
    {"id": CeilyDimensionID.COLOR_LED_TYPE, "name": "LED Type", "unit": "", "type": "uint8"},
    {"id": CeilyDimensionID.REMOTE_CTRL, "name": "Remote Control", "unit": "", "type": "uint8"},
]

WALLY_DIMENSIONS = [
    {"id": WallyDimensionID.OPEN_LIMIT_DISTANCE_MM, "name": "Open Limit", "unit": "mm", "type": "uint16"},
    {"id": WallyDimensionID.LEFT_WHEEL_FROM_TOF_MM, "name": "Left Wheel from ToF", "unit": "mm", "type": "int16"},
    {"id": WallyDimensionID.RIGHT_WHEEL_FROM_TOF_MM, "name": "Right Wheel from ToF", "unit": "mm", "type": "int16"},
    {"id": WallyDimensionID.LEFT_TOF_OFFSET_FROM_CENTER_MM, "name": "Left ToF Offset", "unit": "mm", "type": "int16"},
    {"id": WallyDimensionID.RIGHT_TOF_OFFSET_FROM_CENTER_MM, "name": "Right ToF Offset", "unit": "mm", "type": "int16"},
    {"id": WallyDimensionID.TOF_Y_OFFSET_FROM_CENTER_MM, "name": "ToF Y Offset", "unit": "mm", "type": "int16"},
    {"id": WallyDimensionID.IS_OPEN_PLUS_DIRECTION, "name": "Open Plus Direction", "unit": "", "type": "bool"},
    {"id": WallyDimensionID.WHEEL_RADIUS_MM, "name": "Wheel Radius", "unit": "mm", "type": "uint8"},
    {"id": WallyDimensionID.GEAR_RATIO, "name": "Gear Ratio", "unit": "", "type": "uint8"},
    {"id": WallyDimensionID.KEEP_DISTANCE_MM, "name": "Keep Distance", "unit": "mm", "type": "uint8"},
    {"id": WallyDimensionID.MISSION_SPEED, "name": "Mission Speed", "unit": "", "type": "uint8", "readonly": True},
    {"id": WallyDimensionID.TORQUE_THRESHOLD_MNM, "name": "Torque Threshold", "unit": "mNm", "type": "uint16"},
    {"id": WallyDimensionID.COLOR_LED_TYPE, "name": "LED Type", "unit": "", "type": "uint8"},
    {"id": WallyDimensionID.REMOTE_CTRL, "name": "Remote Control", "unit": "", "type": "uint8"},
    {"id": WallyDimensionID.CONTROL_BUTTON_VERSION, "name": "Button Version", "unit": "", "type": "uint8", "readonly": True},
]

# --- v1-p3 dimension metadata ---

CEILY_DIMENSIONS_V3 = [
    {"id": DimensionID.WIDTH_MM, "name": "Width", "unit": "mm", "type": "uint16"},
    {"id": DimensionID.LENGTH_MM, "name": "Length", "unit": "mm", "type": "uint16"},
    {"id": DimensionID.STROKE_MM, "name": "Stroke", "unit": "mm", "type": "uint16"},
    {"id": DimensionID.GEAR_RATIO, "name": "Gear Ratio", "unit": "", "type": "uint8"},
    {"id": DimensionID.DRIVE_RADIUS_MM, "name": "Pulley Radius", "unit": "mm", "type": "uint8"},
    {"id": DimensionID.V1_CEILY_TOF_ENABLED, "name": "ToF Enabled", "unit": "", "type": "uint8"},
    {"id": DimensionID.TORQUE_THRESHOLD_MNM, "name": "Torque Threshold", "unit": "mNm", "type": "uint16"},
    {"id": DimensionID.MISSION_SPEED, "name": "Mission Speed", "unit": "", "type": "uint8"},
    {"id": DimensionID.COLOR_LED_TYPE, "name": "LED Type", "unit": "", "type": "uint8"},
    {"id": DimensionID.REMOTE_CTRL, "name": "Remote Control", "unit": "", "type": "uint8"},
    {"id": DimensionID.CONTROL_BUTTON_VERSION, "name": "Button Version", "unit": "", "type": "uint8"},
    {"id": DimensionID.LED_CAL, "name": "LED Cal", "unit": "", "type": "uint32"},
]

WALLY_DIMENSIONS_V3 = [
    {"id": DimensionID.WIDTH_MM, "name": "Width", "unit": "mm", "type": "uint16"},
    {"id": DimensionID.LENGTH_MM, "name": "Length", "unit": "mm", "type": "uint16"},
    {"id": DimensionID.STROKE_MM, "name": "Stroke", "unit": "mm", "type": "uint16"},
    {"id": DimensionID.V1_WALLY_LEFT_WHEEL_FROM_TOF_MM, "name": "Left Wheel from ToF", "unit": "mm", "type": "int16"},
    {"id": DimensionID.V1_WALLY_RIGHT_WHEEL_FROM_TOF_MM, "name": "Right Wheel from ToF", "unit": "mm", "type": "int16"},
    {"id": DimensionID.V1_WALLY_LEFT_TOF_OFFSET_FROM_CENTER_MM, "name": "Left ToF Offset", "unit": "mm", "type": "int16"},
    {"id": DimensionID.V1_WALLY_RIGHT_TOF_OFFSET_FROM_CENTER_MM, "name": "Right ToF Offset", "unit": "mm", "type": "int16"},
    {"id": DimensionID.V1_WALLY_TOF_Y_OFFSET_FROM_CENTER_MM, "name": "ToF Y Offset", "unit": "mm", "type": "int16"},
    {"id": DimensionID.IS_OPEN_PLUS_DIRECTION, "name": "Open Plus Direction", "unit": "", "type": "bool"},
    {"id": DimensionID.DRIVE_RADIUS_MM, "name": "Wheel Radius", "unit": "mm", "type": "uint8"},
    {"id": DimensionID.GEAR_RATIO, "name": "Gear Ratio", "unit": "", "type": "uint8"},
    {"id": DimensionID.KEEP_DISTANCE_MM, "name": "Keep Distance", "unit": "mm", "type": "uint8"},
    {"id": DimensionID.MOTOR_DISTANCE_MM, "name": "Motor Distance", "unit": "mm", "type": "uint16", "readonly": True},
    {"id": DimensionID.MISSION_SPEED, "name": "Mission Speed", "unit": "", "type": "uint8"},
    {"id": DimensionID.TORQUE_THRESHOLD_MNM, "name": "Torque Threshold", "unit": "mNm", "type": "uint16"},
    {"id": DimensionID.CONTROL_BUTTON_VERSION, "name": "Button Version", "unit": "", "type": "uint8"},
    {"id": DimensionID.COLOR_LED_TYPE, "name": "LED Type", "unit": "", "type": "uint8"},
    {"id": DimensionID.REMOTE_CTRL, "name": "Remote Control", "unit": "", "type": "uint8"},
    {"id": DimensionID.LED_CAL, "name": "LED Cal", "unit": "", "type": "uint32"},
]


# =============================================================================
# Data Builders
# =============================================================================

def build_generic_command(cmd_id: GenericCommandId, payload: bytes = b"") -> bytes:
    """Build generic control command: [cmd_id: 4B LE][payload: 0-16B]."""
    import struct
    return struct.pack("<I", cmd_id) + payload


def build_motion_command(command: MotionCommand) -> bytes:
    """Build motion control command data."""
    return bytes([command])


def build_led_mode(target: LEDTarget, on: bool) -> bytes:
    """Build LED on/off mode command."""
    mode = 1 if on else 0
    return bytes([LEDCommand.CHANGE_MODE, target, mode])


def build_led_brightness(target: LEDTarget, brightness: int) -> bytes:
    """Build LED brightness command (0-100)."""
    brightness = max(0, min(100, brightness))
    return bytes([LEDCommand.CHANGE_BRIGHTNESS, target, brightness])


def build_led_color_index(index: int) -> bytes:
    """Build LED color index command (1 arg byte: index)."""
    return bytes([LEDCommand.CHANGE_RGB_INDEX, index])


def build_led_color_rgb(index: int, r: int, g: int, b: int) -> bytes:
    """Build LED RGB color command (index: color table slot, 2=custom)."""
    r = max(0, min(255, r))
    g = max(0, min(255, g))
    b = max(0, min(255, b))
    return bytes([LEDCommand.CHANGE_COLOR, index, r, g, b])


def build_dimension_write(dimension_id: int, value: int) -> bytes:
    """Build dimension write command (8 bytes: 4 id + 4 value)."""
    import struct
    return struct.pack("<II", dimension_id, value)


def build_wifi_config(ssid: str, password: str) -> bytes:
    """Build WiFi provisioning data (96 bytes: 32 SSID + 64 password)."""
    ssid_bytes = ssid.encode("utf-8")[:32].ljust(32, b"\x00")
    password_bytes = password.encode("utf-8")[:64].ljust(64, b"\x00")
    return ssid_bytes + password_bytes


def parse_ceily_dimensions_v2(data: bytes) -> dict:
    """Parse v1-p2 ceily dimension read (12 bytes, fixed struct).

    Layout:
      offset 0:  width_mm (uint16)
      offset 2:  length_mm (uint16)
      offset 4:  stroke_mm (uint16)
      offset 6:  gear_ratio (uint8)
      offset 7:  pulley_radius_mm (uint8)
      offset 8:  tof_enabled (uint8)
      offset 9:  torque_threshold_mnm (uint16)
      offset 11: mission_speed (uint8)
    """
    import struct
    if len(data) < 12:
        return {}
    result = {}
    result[CeilyDimensionID.WIDTH_MM] = struct.unpack_from("<H", data, 0)[0]
    result[CeilyDimensionID.LENGTH_MM] = struct.unpack_from("<H", data, 2)[0]
    result[CeilyDimensionID.STROKE_MM] = struct.unpack_from("<H", data, 4)[0]
    result[CeilyDimensionID.GEAR_RATIO] = data[6]
    result[CeilyDimensionID.PULLEY_RADIUS_MM] = data[7]
    result[CeilyDimensionID.TOF_ENABLED] = data[8]
    result[CeilyDimensionID.TORQUE_THRESHOLD_MNM] = struct.unpack_from("<H", data, 9)[0]
    result[CeilyDimensionID.MISSION_SPEED] = data[11]
    return result


def parse_wally_dimensions_v2(data: bytes) -> dict:
    """Parse v1-p2 wally dimension read (24 bytes, fixed struct).

    Layout:
      offset 0:  open_limit_distance_mm (uint16)
      offset 2-5: unused (uninitialized in firmware)
      offset 6:  left_wheel_from_tof (int16)
      offset 8:  right_wheel_from_tof (int16)
      offset 10: left_tof_offset_from_center_mm (int16)
      offset 12: right_tof_offset_from_center_mm (int16)
      offset 14: tof_y_offset_from_center_mm (int16)
      offset 16: is_open_plus_direction (uint8)
      offset 17: wheel_radius_mm (uint8)
      offset 18: gear_ratio (uint8)
      offset 19: keep_distance_mm (uint8)
      offset 20: mission_speed (uint8)
      offset 21: control_button_version (uint8)
      offset 22: torque_threshold_mnm (uint16)
    """
    import struct
    if len(data) < 24:
        return {}
    result = {}
    result[WallyDimensionID.OPEN_LIMIT_DISTANCE_MM] = struct.unpack_from("<H", data, 0)[0]
    result[WallyDimensionID.LEFT_WHEEL_FROM_TOF_MM] = struct.unpack_from("<h", data, 6)[0]
    result[WallyDimensionID.RIGHT_WHEEL_FROM_TOF_MM] = struct.unpack_from("<h", data, 8)[0]
    result[WallyDimensionID.LEFT_TOF_OFFSET_FROM_CENTER_MM] = struct.unpack_from("<h", data, 10)[0]
    result[WallyDimensionID.RIGHT_TOF_OFFSET_FROM_CENTER_MM] = struct.unpack_from("<h", data, 12)[0]
    result[WallyDimensionID.TOF_Y_OFFSET_FROM_CENTER_MM] = struct.unpack_from("<h", data, 14)[0]
    result[WallyDimensionID.IS_OPEN_PLUS_DIRECTION] = data[16]
    result[WallyDimensionID.WHEEL_RADIUS_MM] = data[17]
    result[WallyDimensionID.GEAR_RATIO] = data[18]
    result[WallyDimensionID.KEEP_DISTANCE_MM] = data[19]
    result[WallyDimensionID.MISSION_SPEED] = data[20]
    result[WallyDimensionID.CONTROL_BUTTON_VERSION] = data[21]
    result[WallyDimensionID.TORQUE_THRESHOLD_MNM] = struct.unpack_from("<H", data, 22)[0]
    return result


def parse_dimensions_tlv(data: bytes) -> dict:
    """Parse TLV-encoded dimension data.

    Format: [tag(1)][len(1)][value(len)] repeated.
    - tag: dimension enum value (uint8)
    - len: 1 or 2
    - value: little-endian unsigned
    """
    import struct
    result = {}
    offset = 0
    while offset + 2 <= len(data):
        tag = data[offset]
        length = data[offset + 1]
        offset += 2
        if offset + length > len(data):
            break
        if length == 1:
            result[tag] = data[offset]
        elif length == 2:
            result[tag] = struct.unpack_from("<H", data, offset)[0]
        offset += length
    return result


def parse_led_status(data: bytes) -> dict:
    """Parse LED status data (22 bytes).

    Layout (led_status_profile_v1_t):
    - leds[4] x 3 bytes (current_brightness, default_brightness, mode)
    - current_index (1 byte)
    - color_table[3] x 3 bytes (r, g, b)
    """
    if len(data) < 22:
        return {}

    led_names = ["wall", "direct", "ceiling", "head"]
    leds = {}
    for i in range(4):
        offset = i * 3
        leds[led_names[i]] = {
            "current_brightness": data[offset],
            "default_brightness": data[offset + 1],
            "mode": data[offset + 2],
        }

    current_index = data[12]

    color_table = []
    for i in range(3):
        offset = 13 + i * 3
        color_table.append({
            "r": data[offset],
            "g": data[offset + 1],
            "b": data[offset + 2],
        })

    return {
        "leds": leds,
        "current_index": current_index,
        "color_table": color_table,
    }


def parse_wifi_status(data: bytes) -> dict:
    """Parse WiFi status data (33 bytes: 32 SSID + 1 status)."""
    if len(data) < 33:
        return {"ssid": "", "connected": False}
    ssid = data[:32].rstrip(b"\x00").decode("utf-8", errors="replace")
    connected = data[32] == 1
    return {"ssid": ssid, "connected": connected}
