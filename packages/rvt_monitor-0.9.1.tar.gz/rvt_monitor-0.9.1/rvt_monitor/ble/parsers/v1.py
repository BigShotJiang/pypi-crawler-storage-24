"""v1-p1 status parser — flat format with float kinematics."""

import struct
from datetime import datetime

from ..protocol import MotionState
from .types import (
    CeilyStatus,
    TofStatus,
    WallyStatus,
    WallyTofStatus,
)


def parse_ceily(data: bytes) -> CeilyStatus:
    """Parse Ceily v1-p1 format (33 bytes).

    Layout: motion(1) + tof(6) + limit(1) + servo_conn(1) + alarm(2)
            + servo_pos(4) + position_mm(4f) + velocity_mm(4f)
            + torque(4f) + current(2) + voltage(2) + temp(2)
    """
    status = CeilyStatus()

    if len(data) < 33:
        return status

    status.motion_state = MotionState(data[0])
    status.tof_front = TofStatus.from_bytes_v1(data[1], bool(data[2]))
    status.tof_left = TofStatus.from_bytes_v1(data[3], bool(data[4]))
    status.tof_right = TofStatus.from_bytes_v1(data[5], bool(data[6]))
    # Limit switch: bit 0 = top ON, bit 4 = bottom ON
    status.limit_switch_state = data[7]
    status.top_limit = bool(data[7] & 0x01)
    status.bottom_limit = bool(data[7] & 0x10)
    # Servo
    # bit 0: is_connected, bit 1: is_enabled
    motor_status_byte = data[8]
    status.servo_connected = bool(motor_status_byte & 0x01)
    status.servo_enabled = bool(motor_status_byte & 0x02)
    status.servo_current_alarm = struct.unpack("<H", data[9:11])[0]
    status.servo_position = struct.unpack("<i", data[11:15])[0]
    # Kinematics (float values)
    status.position_mm = struct.unpack("<f", data[15:19])[0]
    status.velocity_mm = struct.unpack("<f", data[19:23])[0]
    status.torque = struct.unpack("<f", data[23:27])[0]
    # Motor status (int16 values)
    status.motor_current = struct.unpack("<h", data[27:29])[0]
    status.voltage = struct.unpack("<h", data[29:31])[0]
    status.temperature = struct.unpack("<h", data[31:33])[0]

    status.last_update = datetime.now()
    return status


def parse_wally(data: bytes) -> WallyStatus:
    """Parse Wally v1-p1 format (60-106 bytes).

    Layout: motion(1) + tof_left(5) + tof_right(5) + limit(1)
            + motor_left(24) + motor_right(24)
            + kinematics(30, optional)
    """
    status = WallyStatus()

    if len(data) < 60:
        return status

    status.motion_state = MotionState(data[0])
    # ToF sensors: status byte + distance (float)
    tof_left_status = data[1]
    tof_left_dist = struct.unpack("<f", data[2:6])[0]
    status.tof_left = WallyTofStatus.from_bytes_v1(tof_left_status, tof_left_dist)

    tof_right_status = data[6]
    tof_right_dist = struct.unpack("<f", data[7:11])[0]
    status.tof_right = WallyTofStatus.from_bytes_v1(tof_right_status, tof_right_dist)

    # Limit switch: bit 0 = open ON, bit 4 = close ON
    status.limit_switch_state = data[11]
    status.open_limit = bool(data[11] & 0x01)
    status.close_limit = bool(data[11] & 0x10)

    # Left motor (bytes 12-35)
    status.motor_left.current_alarm = struct.unpack("<H", data[12:14])[0]
    status.motor_left.position = struct.unpack("<i", data[14:18])[0]
    status.motor_left.position_mm = struct.unpack("<f", data[18:22])[0]
    status.motor_left.velocity = struct.unpack("<f", data[22:26])[0]
    status.motor_left.torque = struct.unpack("<f", data[26:30])[0]
    status.motor_left.current = struct.unpack("<h", data[30:32])[0]
    status.motor_left.voltage = struct.unpack("<h", data[32:34])[0]
    status.motor_left.temperature = struct.unpack("<h", data[34:36])[0]

    # Right motor (bytes 36-59)
    status.motor_right.current_alarm = struct.unpack("<H", data[36:38])[0]
    status.motor_right.position = struct.unpack("<i", data[38:42])[0]
    status.motor_right.position_mm = struct.unpack("<f", data[42:46])[0]
    status.motor_right.velocity = struct.unpack("<f", data[46:50])[0]
    status.motor_right.torque = struct.unpack("<f", data[50:54])[0]
    status.motor_right.current = struct.unpack("<h", data[54:56])[0]
    status.motor_right.voltage = struct.unpack("<h", data[56:58])[0]
    status.motor_right.temperature = struct.unpack("<h", data[58:60])[0]

    # Wally kinematics (bytes 60+)
    if len(data) >= 90:
        status.wally_x = struct.unpack("<f", data[60:64])[0]
        status.wally_y = struct.unpack("<f", data[64:68])[0]
        status.distance_to_wall = struct.unpack("<h", data[68:70])[0]
        status.angle = struct.unpack("<d", data[70:78])[0]
        status.target_x = struct.unpack("<f", data[78:82])[0]
        status.target_y = struct.unpack("<f", data[82:86])[0]
        status.target_velocity = struct.unpack("<f", data[86:90])[0]

    status.last_update = datetime.now()
    return status
