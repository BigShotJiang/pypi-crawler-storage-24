"""v1-p2 status parser — compact format with int16 values."""

import struct
from datetime import datetime

from ..protocol import MotionState
from .types import (
    CeilyStatus,
    TofStatus,
    WallyStatus,
    WallyTofStatus,
)


def parse_ceily(data: bytes) -> CeilyStatus:
    """Parse Ceily v1-p2 format (37-43 bytes).

    Layout: common(17) + sensors(7) + motor(13) + legs(6, optional)
    """
    status = CeilyStatus()

    if len(data) < 37:
        return status

    # Common (17 bytes)
    status.motion_state = MotionState(data[0])
    status.mcu_temp = struct.unpack("<b", data[1:2])[0]  # int8
    status.speed_control_state = data[2]
    status.position_percentage = data[3]
    status.position_mm = struct.unpack("<h", data[4:6])[0]  # signed int16
    status.remain_distance = struct.unpack("<h", data[6:8])[0]  # signed int16
    status.torque = struct.unpack("<h", data[8:10])[0]  # signed int16
    status.current_velocity = struct.unpack("<h", data[10:12])[0]  # signed int16
    status.command_velocity = struct.unpack("<h", data[12:14])[0]  # signed int16
    status.is_position_verified = bool(data[14])
    status.is_current_model_learning = bool(data[15])
    status.motion_phase = data[16]
    # Sensors (7 bytes, offset 17)
    status.tof_front = TofStatus.from_bytes_v2(data[17], data[18])
    status.tof_left = TofStatus.from_bytes_v2(data[19], data[20])
    status.tof_right = TofStatus.from_bytes_v2(data[21], data[22])
    # Limit switch: bit 0 = top ON, bit 4 = bottom ON
    status.limit_switch_state = data[23]
    status.top_limit = bool(data[23] & 0x01)
    status.bottom_limit = bool(data[23] & 0x10)
    # Motor (13 bytes, offset 24)
    # bit 0: is_connected, bit 1: is_enabled
    motor_status_byte = data[24]
    status.servo_connected = bool(motor_status_byte & 0x01)
    status.servo_enabled = bool(motor_status_byte & 0x02)
    status.servo_current_alarm = struct.unpack("<H", data[25:27])[0]
    status.raw_velocity = struct.unpack("<h", data[27:29])[0]
    status.raw_torque = struct.unpack("<h", data[29:31])[0]
    status.motor_current = struct.unpack("<h", data[31:33])[0]
    status.voltage = struct.unpack("<h", data[33:35])[0]
    status.temperature = struct.unpack("<h", data[35:37])[0]
    # Legs (6 bytes, offset 37)
    if len(data) >= 43:
        # Left leg (3 bytes) - angles are int8 (-20 to 110)
        status.left_leg_current_angle = struct.unpack("<b", data[37:38])[0]
        status.left_leg_target_angle = struct.unpack("<b", data[38:39])[0]
        left_data = data[39]
        status.left_leg_fold_limit = bool(left_data & 0x01)
        status.left_leg_spread_limit = bool(left_data & 0x02)
        status.leg_desire_state = (left_data >> 2) & 0x03
        status.left_leg_state = (left_data >> 4) & 0x0F
        # Right leg (3 bytes)
        status.right_leg_current_angle = struct.unpack("<b", data[40:41])[0]
        status.right_leg_target_angle = struct.unpack("<b", data[41:42])[0]
        right_data = data[42]
        status.right_leg_fold_limit = bool(right_data & 0x01)
        status.right_leg_spread_limit = bool(right_data & 0x02)
        status.right_leg_state = (right_data >> 4) & 0x0F

    status.last_update = datetime.now()
    return status


def parse_wally(data: bytes) -> WallyStatus:
    """Parse Wally v1-p2 format (49-80 bytes, compact motor 13B each).

    Layout: common(17) + sensors(6) + motor_left(13) + motor_right(13)
            + kinematics(31, optional)
    """
    status = WallyStatus()

    if len(data) < 49:
        return status

    # Common (17 bytes, offset 0)
    status.motion_state = MotionState(data[0])
    status.mcu_temp = struct.unpack("<b", data[1:2])[0]  # int8
    status.speed_control_state = data[2]
    status.position_percentage = data[3]
    status.position_mm = struct.unpack("<h", data[4:6])[0]  # signed int16
    status.remain_distance = struct.unpack("<h", data[6:8])[0]  # signed int16
    status.torque = struct.unpack("<h", data[8:10])[0]  # signed int16
    status.current_velocity = struct.unpack("<h", data[10:12])[0]  # signed int16
    status.command_velocity = struct.unpack("<h", data[12:14])[0]  # signed int16
    status.is_position_verified = bool(data[14])
    status.is_current_model_learning = bool(data[15])
    status.motion_phase = data[16]

    # Sensors (6 bytes, offset 17)
    status.tof_left = WallyTofStatus.from_bytes_v2(data[17], data[18])
    status.tof_right = WallyTofStatus.from_bytes_v2(data[19], data[20])
    # Limit switch: bit 0 = open ON, bit 4 = close ON
    status.limit_switch_state = data[21]
    status.open_limit = bool(data[21] & 0x01)
    status.close_limit = bool(data[21] & 0x10)
    status.photo_sensor_state = data[22]

    # Left motor (13 bytes, offset 23)
    # bit 0: is_connected, bit 1: is_enabled
    ml_status_byte = data[23]
    status.motor_left.is_connected = bool(ml_status_byte & 0x01)
    status.motor_left.is_enabled = bool(ml_status_byte & 0x02)
    status.motor_left.current_alarm = struct.unpack("<H", data[24:26])[0]
    status.motor_left.raw_velocity = struct.unpack("<h", data[26:28])[0]
    status.motor_left.raw_torque = struct.unpack("<h", data[28:30])[0]
    status.motor_left.current = struct.unpack("<h", data[30:32])[0]
    status.motor_left.voltage = struct.unpack("<h", data[32:34])[0]
    status.motor_left.temperature = struct.unpack("<h", data[34:36])[0]

    # Right motor (13 bytes, offset 36)
    # bit 0: is_connected, bit 1: is_enabled
    mr_status_byte = data[36]
    status.motor_right.is_connected = bool(mr_status_byte & 0x01)
    status.motor_right.is_enabled = bool(mr_status_byte & 0x02)
    status.motor_right.current_alarm = struct.unpack("<H", data[37:39])[0]
    status.motor_right.raw_velocity = struct.unpack("<h", data[39:41])[0]
    status.motor_right.raw_torque = struct.unpack("<h", data[41:43])[0]
    status.motor_right.current = struct.unpack("<h", data[43:45])[0]
    status.motor_right.voltage = struct.unpack("<h", data[45:47])[0]
    status.motor_right.temperature = struct.unpack("<h", data[47:49])[0]

    # Wally kinematics (31 bytes, offset 49)
    if len(data) >= 67:
        status.wally_x = struct.unpack("<f", data[49:53])[0]
        status.wally_y = struct.unpack("<f", data[53:57])[0]
        status.distance_to_wall = struct.unpack("<h", data[57:59])[0]
        status.angle = struct.unpack("<d", data[59:67])[0]
        # Reserved 13 bytes (offset 67-79)

    status.last_update = datetime.now()
    return status
