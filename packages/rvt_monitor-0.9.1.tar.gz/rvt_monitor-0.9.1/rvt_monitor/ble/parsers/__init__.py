"""BLE status packet parsers — route by profile version."""

from .types import (
    TofStatus,
    CeilyStatus,
    WallyMotorStatus,
    WallyTofStatus,
    WallyStatus,
    DeviceStatus,
)


def parse_ceily_status(data: bytes, profile_id: str) -> tuple:
    """Parse Ceily status by profile.

    Returns:
        (CeilyStatus, effective_profile_id)
    """
    if profile_id == "v1-p3":
        from . import v3
        return v3.parse_ceily(data), profile_id

    if profile_id == "v1-p2" and len(data) >= 37:
        from . import v2
        return v2.parse_ceily(data), profile_id

    effective = "v1-p1" if profile_id == "v1-p2" else profile_id
    from . import v1
    return v1.parse_ceily(data), effective


def parse_wally_status(data: bytes, profile_id: str) -> tuple:
    """Parse Wally status by profile.

    Returns:
        (WallyStatus, effective_profile_id)
    """
    if profile_id == "v1-p3":
        from . import v3
        return v3.parse_wally(data), profile_id

    if profile_id == "v1-p2" and len(data) >= 49:
        from . import v2
        return v2.parse_wally(data), profile_id

    effective = "v1-p1" if profile_id == "v1-p2" else profile_id
    from . import v1
    return v1.parse_wally(data), effective
