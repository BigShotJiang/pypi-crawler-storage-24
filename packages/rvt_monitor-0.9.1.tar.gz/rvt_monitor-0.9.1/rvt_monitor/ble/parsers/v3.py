"""v1-p3 TLV status parser — Type-Length-Value sections."""

import struct
from datetime import datetime

from ..protocol import MotionState
from .types import (
    CeilyStatus,
    TofStatus,
    WallyStatus,
    WallyTofStatus,
)

# Section type identifiers (must match firmware device_status.h)
SECTION_CEILY_MOTION = 0x01
SECTION_WALLY_MOTION = 0x02
SECTION_TORQUE = 0x03
SECTION_COMM = 0x04
SECTION_MOTOR = 0x05
SECTION_V1_HEALTH = 0x06
SECTION_OBSTACLE_INFO = 0x07
SECTION_LEGS = 0x09
SECTION_CEILY_V1_ONLY = 0x10
SECTION_WALLY_V1_ONLY = 0x11


def parse_tlv(data: bytes) -> tuple:
    """Parse TLV status packet.

    Header: [version (uint8)] [section_count (uint8)]
    Each section: [type(1)] [length(1)] [value(N)]

    Returns:
        (tlv_version, {section_type: section_bytes})
    """
    if len(data) < 2:
        return 0, {}

    tlv_version = data[0]
    section_count = data[1]

    sections = {}
    pos = 2
    for _ in range(section_count):
        if pos + 2 > len(data):
            break
        section_type = data[pos]
        section_length = data[pos + 1]
        value_start = pos + 2
        value_end = value_start + section_length

        if value_end > len(data):
            break

        sections[section_type] = data[value_start:value_end]
        pos = value_end

    return tlv_version, sections



def _parse_comm_section(status, section_data: bytes):
    """Parse COMM section (2 bytes): flags(1) + rssi(1)."""
    s = section_data
    if len(s) >= 2:
        flags = s[0]
        status.wifi_connected = bool(flags & 0x01)
        status.mqtt_connected = bool(flags & 0x02)
        status.ble_connections = (flags >> 4) & 0x0F
        status.wifi_rssi = struct.unpack_from("<b", s, 1)[0]


def _parse_health_section(status, section_data: bytes):
    """Parse V1_HEALTH section (11 bytes) into status object."""
    s = section_data
    if len(s) >= 1:
        status.mcu_temp = struct.unpack_from("<b", s, 0)[0]
    if len(s) >= 7:
        status.free_heap = struct.unpack_from("<I", s, 1)[0]
        status.min_free_heap_kb = struct.unpack_from("<H", s, 5)[0]
    if len(s) >= 11:
        status.uptime_s = struct.unpack_from("<I", s, 7)[0]


def _parse_ceily_motion(status, section_data: bytes):
    """Parse CEILY_MOTION section (14 bytes)."""
    s = section_data
    if len(s) < 14:
        return
    status.motion_state = MotionState(s[0])
    status.speed_control_state = s[1]
    status.position_percentage = s[2]
    status.position_mm = struct.unpack_from("<h", s, 3)[0]
    status.remain_distance = struct.unpack_from("<h", s, 5)[0]
    status.current_velocity = struct.unpack_from("<h", s, 7)[0]
    status.command_velocity = struct.unpack_from("<h", s, 9)[0]
    status.is_position_verified = bool(s[11])
    status.motion_phase = s[12]
    status.limit_switch_state = s[13]
    status.top_limit = bool(s[13] & 0x01)
    status.bottom_limit = bool(s[13] & 0x10)


def _parse_wally_motion(status, section_data: bytes):
    """Parse WALLY_MOTION section (35 bytes)."""
    s = section_data
    if len(s) < 11:
        return
    status.motion_state = MotionState(s[0])
    status.speed_control_state = s[1]
    status.position_percentage = s[2]
    status.remain_distance = struct.unpack_from("<h", s, 3)[0]
    status.current_velocity = struct.unpack_from("<h", s, 5)[0]
    status.command_velocity = struct.unpack_from("<h", s, 7)[0]
    status.is_position_verified = bool(s[9])
    status.motion_phase = s[10]
    if len(s) >= 25:
        status.wally_x = struct.unpack_from("<f", s, 11)[0]
        status.position_mm = int(status.wally_x)
        status.wally_y = struct.unpack_from("<f", s, 15)[0]
        status.distance_to_wall = struct.unpack_from("<h", s, 19)[0]
        status.angle = struct.unpack_from("<f", s, 21)[0]
    if len(s) >= 26:
        status.angle_source = s[25]
    if len(s) >= 34:
        status.angle_from_motors = struct.unpack_from("<f", s, 26)[0]
        status.angle_from_tof = struct.unpack_from("<f", s, 30)[0]
    if len(s) >= 35:
        status.limit_switch_state = s[34]
        status.open_limit = bool(s[34] & 0x01)
        status.close_limit = bool(s[34] & 0x10)


def _parse_torque_section(status, section_data: bytes):
    """Parse TORQUE section (9 bytes)."""
    s = section_data
    if len(s) >= 4:
        status.torque_measured = struct.unpack_from("<h", s, 0)[0]
        status.torque = status.torque_measured  # legacy alias
        status.torque_predicted = struct.unpack_from("<h", s, 2)[0]
    if len(s) >= 6:
        status.torque_estimated_max = struct.unpack_from("<h", s, 4)[0]
    if len(s) >= 7:
        status.is_current_model_learning = bool(s[6])
    if len(s) >= 9:
        status.torque_threshold = struct.unpack_from("<h", s, 7)[0]


def parse_ceily(data: bytes) -> CeilyStatus:
    """Parse Ceily TLV status packet (protocol version 3)."""
    status = CeilyStatus()
    _, sections = parse_tlv(data)

    # V1_HEALTH (11 bytes)
    if SECTION_V1_HEALTH in sections:
        _parse_health_section(status, sections[SECTION_V1_HEALTH])

    # CEILY_V1_ONLY (3 bytes) — ToF status only
    if SECTION_CEILY_V1_ONLY in sections:
        s = sections[SECTION_CEILY_V1_ONLY]
        if len(s) >= 3:
            status.tof_front = TofStatus.from_bytes_v2(s[0], 0)
            status.tof_left = TofStatus.from_bytes_v2(s[1], 0)
            status.tof_right = TofStatus.from_bytes_v2(s[2], 0)

    # MOTOR (13 bytes)
    if SECTION_MOTOR in sections:
        s = sections[SECTION_MOTOR]
        if len(s) >= 13:
            motor_status_byte = s[0]
            status.servo_connected = bool(motor_status_byte & 0x01)
            status.servo_enabled = bool(motor_status_byte & 0x02)
            status.servo_current_alarm = struct.unpack_from("<H", s, 1)[0]
            status.raw_velocity = struct.unpack_from("<h", s, 3)[0]
            status.raw_torque = struct.unpack_from("<h", s, 5)[0]
            status.motor_current = struct.unpack_from("<h", s, 7)[0]
            status.voltage = struct.unpack_from("<h", s, 9)[0]
            status.temperature = struct.unpack_from("<h", s, 11)[0]

    # LEGS (6 bytes)
    if SECTION_LEGS in sections:
        s = sections[SECTION_LEGS]
        if len(s) >= 6:
            status.left_leg_current_angle = struct.unpack_from("<b", s, 0)[0]
            status.left_leg_target_angle = struct.unpack_from("<b", s, 1)[0]
            left_data = s[2]
            status.left_leg_fold_limit = bool(left_data & 0x01)
            status.left_leg_spread_limit = bool(left_data & 0x02)
            status.leg_desire_state = (left_data >> 2) & 0x03
            status.left_leg_state = (left_data >> 4) & 0x0F
            status.right_leg_current_angle = struct.unpack_from("<b", s, 3)[0]
            status.right_leg_target_angle = struct.unpack_from("<b", s, 4)[0]
            right_data = s[5]
            status.right_leg_fold_limit = bool(right_data & 0x01)
            status.right_leg_spread_limit = bool(right_data & 0x02)
            status.right_leg_state = (right_data >> 4) & 0x0F

    # OBSTACLE_INFO (6 bytes) — per-zone bitmaps for 3 ToF sensors
    if SECTION_OBSTACLE_INFO in sections:
        s = sections[SECTION_OBSTACLE_INFO]
        if len(s) >= 6:
            status.obstacle_front_bitmap = struct.unpack_from("<H", s, 0)[0]
            status.obstacle_left_bitmap = struct.unpack_from("<H", s, 2)[0]
            status.obstacle_right_bitmap = struct.unpack_from("<H", s, 4)[0]

    # CEILY_MOTION (13 bytes)
    if SECTION_CEILY_MOTION in sections:
        _parse_ceily_motion(status, sections[SECTION_CEILY_MOTION])

    # TORQUE (9 bytes)
    if SECTION_TORQUE in sections:
        _parse_torque_section(status, sections[SECTION_TORQUE])

    # COMM (4 bytes)
    if SECTION_COMM in sections:
        _parse_comm_section(status, sections[SECTION_COMM])

    status.last_update = datetime.now()
    return status


def parse_wally(data: bytes) -> WallyStatus:
    """Parse Wally TLV status packet (protocol version 3)."""
    status = WallyStatus()
    _, sections = parse_tlv(data)

    # V1_HEALTH (11 bytes)
    if SECTION_V1_HEALTH in sections:
        _parse_health_section(status, sections[SECTION_V1_HEALTH])

    # WALLY_V1_ONLY (6 bytes) — ToF left/right + photo sensor + angle sync
    if SECTION_WALLY_V1_ONLY in sections:
        s = sections[SECTION_WALLY_V1_ONLY]
        if len(s) >= 4:
            status.tof_left = WallyTofStatus.from_bytes_v2(s[0], s[1])
            status.tof_right = WallyTofStatus.from_bytes_v2(s[2], s[3])
        if len(s) >= 5:
            status.photo_sensor_state = s[4]
        if len(s) >= 6:
            status.angle_sync_state = s[5]

    # MOTOR (26 bytes)
    if SECTION_MOTOR in sections:
        s = sections[SECTION_MOTOR]
        if len(s) >= 26:
            # Left motor (13 bytes)
            ml_status = s[0]
            status.motor_left.is_connected = bool(ml_status & 0x01)
            status.motor_left.is_enabled = bool(ml_status & 0x02)
            status.motor_left.current_alarm = struct.unpack_from("<H", s, 1)[0]
            status.motor_left.raw_velocity = struct.unpack_from("<h", s, 3)[0]
            status.motor_left.raw_torque = struct.unpack_from("<h", s, 5)[0]
            status.motor_left.current = struct.unpack_from("<h", s, 7)[0]
            status.motor_left.voltage = struct.unpack_from("<h", s, 9)[0]
            status.motor_left.temperature = struct.unpack_from("<h", s, 11)[0]
            # Right motor (13 bytes, offset 13)
            mr_status = s[13]
            status.motor_right.is_connected = bool(mr_status & 0x01)
            status.motor_right.is_enabled = bool(mr_status & 0x02)
            status.motor_right.current_alarm = struct.unpack_from("<H", s, 14)[0]
            status.motor_right.raw_velocity = struct.unpack_from("<h", s, 16)[0]
            status.motor_right.raw_torque = struct.unpack_from("<h", s, 18)[0]
            status.motor_right.current = struct.unpack_from("<h", s, 20)[0]
            status.motor_right.voltage = struct.unpack_from("<h", s, 22)[0]
            status.motor_right.temperature = struct.unpack_from("<h", s, 24)[0]

    # OBSTACLE_INFO (1 byte) — limit switch state
    if SECTION_OBSTACLE_INFO in sections:
        s = sections[SECTION_OBSTACLE_INFO]
        if len(s) >= 1:
            status.obstacle_limit_switch = s[0]

    # WALLY_MOTION (31 bytes)
    if SECTION_WALLY_MOTION in sections:
        _parse_wally_motion(status, sections[SECTION_WALLY_MOTION])

    # TORQUE (9 bytes)
    if SECTION_TORQUE in sections:
        _parse_torque_section(status, sections[SECTION_TORQUE])

    # COMM (4 bytes)
    if SECTION_COMM in sections:
        _parse_comm_section(status, sections[SECTION_COMM])

    status.last_update = datetime.now()
    return status
