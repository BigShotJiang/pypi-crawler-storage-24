/**
 * Dimension settings module — render table, pending changes, read/save
 */

import { sendWs } from './ws.js';

let pendingDimensions = {};
let dimensionTbody;

export function initDimensionListeners() {
  dimensionTbody = document.getElementById('dimension-tbody');

  document.getElementById('btn-read-dimensions').addEventListener('click', () => {
    pendingDimensions = {};
    sendWs('read_dimensions');
  });

  document.getElementById('btn-save-dimensions').addEventListener('click', () => {
    const ids = Object.keys(pendingDimensions);
    ids.forEach(id => {
      sendWs('write_dimension', { id: parseInt(id, 10), value: pendingDimensions[id] });
    });
    pendingDimensions = {};
    sendWs('save_dimensions');
  });
}

export function renderDimensionTable(data) {
  if (!data || !data.dimensions) {
    dimensionTbody.innerHTML = '<tr><td colspan="3">No dimension data</td></tr>';
    return;
  }

  dimensionTbody.innerHTML = '';
  data.dimensions.forEach(dim => {
    const tr = document.createElement('tr');

    // Name
    const tdName = document.createElement('td');
    tdName.textContent = dim.name;
    tr.appendChild(tdName);

    // Value
    const tdValue = document.createElement('td');

    if (dim.name === 'ToF Enabled') {
      const container = document.createElement('div');
      container.className = 'tof-checkboxes';

      const sensors = [
        { bit: 0, label: 'Front' },
        { bit: 1, label: 'Left' },
        { bit: 2, label: 'Right' },
      ];

      sensors.forEach(sensor => {
        const label = document.createElement('label');
        label.className = 'tof-checkbox-label';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = (dim.value & (1 << sensor.bit)) !== 0;
        checkbox.dataset.bit = sensor.bit;
        checkbox.dataset.dimId = dim.id;
        checkbox.addEventListener('change', () => {
          let newValue = 0;
          container.querySelectorAll('input[type="checkbox"]').forEach(cb => {
            if (cb.checked) {
              newValue |= (1 << parseInt(cb.dataset.bit, 10));
            }
          });
          pendingDimensions[dim.id] = newValue;
        });
        label.appendChild(checkbox);
        label.appendChild(document.createTextNode(` ${sensor.label}`));
        container.appendChild(label);
      });

      tdValue.appendChild(container);
    } else {
      const input = document.createElement('input');
      input.type = 'number';
      input.value = dim.value;
      input.dataset.dimId = dim.id;
      input.dataset.originalValue = dim.value;
      input.addEventListener('blur', () => {
        const newValue = parseInt(input.value, 10);
        const originalValue = parseInt(input.dataset.originalValue, 10);
        if (!isNaN(newValue) && newValue !== originalValue) {
          pendingDimensions[dim.id] = newValue;
          input.dataset.originalValue = newValue;
        }
      });
      tdValue.appendChild(input);
    }
    tr.appendChild(tdValue);

    // Unit
    const tdUnit = document.createElement('td');
    tdUnit.textContent = dim.unit || '-';
    tr.appendChild(tdUnit);

    dimensionTbody.appendChild(tr);
  });
}
