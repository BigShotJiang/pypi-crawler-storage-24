/**
 * Camera-based LED calibration module
 * 6-step measurement: R→G→B→C→M→Y with auto ROI detection
 * Mixed colors (CMY) provide cross-channel verification for robust correction.
 */

import { sendWs } from './ws.js';
import { appendLog } from './log.js';

const STEP_ORDER = ['red', 'green', 'blue', 'cyan', 'magenta', 'yellow', 'done'];

const STEP_CONFIG = {
  red:     { label: 'Red',     color: [255, 0, 0] },
  green:   { label: 'Green',   color: [0, 255, 0] },
  blue:    { label: 'Blue',    color: [0, 0, 255] },
  cyan:    { label: 'Cyan',    color: [0, 255, 255] },
  magenta: { label: 'Magenta', color: [255, 0, 255] },
  yellow:  { label: 'Yellow',  color: [255, 255, 0] },
};

// Which primary channels to validate per step
const STEP_PRIMARY = {
  red: ['r'], green: ['g'], blue: ['b'],
  cyan: ['g', 'b'], magenta: ['r', 'b'], yellow: ['r', 'g'],
};

let state = 'idle';
let stream = null;
let measurements = {};

// DOM references
let video, canvas, ctx, overlay, overlayCtx;
let btnStart, btnCapture, btnNext, btnCancel, btnApply;
let previewArea, statusEl, resultsEl;
let measEls = {};
let resultR, resultG, resultB;
let stepEls;

export function initCalibration() {
  video = document.getElementById('cal-video');
  canvas = document.getElementById('cal-canvas');
  overlay = document.getElementById('cal-overlay');
  btnStart = document.getElementById('btn-cal-start');
  btnCapture = document.getElementById('btn-cal-capture');
  btnNext = document.getElementById('btn-cal-next');
  btnCancel = document.getElementById('btn-cal-cancel');
  btnApply = document.getElementById('btn-cal-apply');
  previewArea = document.getElementById('cal-preview-area');
  statusEl = document.getElementById('cal-status');
  resultsEl = document.getElementById('cal-results');
  resultR = document.getElementById('cal-result-r');
  resultG = document.getElementById('cal-result-g');
  resultB = document.getElementById('cal-result-b');
  stepEls = document.querySelectorAll('.cal-step');

  for (const key of Object.keys(STEP_CONFIG)) {
    measEls[key] = document.getElementById(`cal-meas-${key}`);
  }

  btnStart.addEventListener('click', startCalibration);
  btnCapture.addEventListener('click', handleCapture);
  btnNext.addEventListener('click', handleNext);
  btnCancel.addEventListener('click', stopCalibration);
  btnApply.addEventListener('click', applyResults);
}

async function startCalibration() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 640 }, height: { ideal: 480 } }
    });
  } catch (err) {
    appendLog('ERROR', `Camera access denied: ${err.message}`);
    alert('Camera access denied. Please allow camera access and try again.');
    return;
  }

  video.srcObject = stream;
  await video.play();

  canvas.width = video.videoWidth || 640;
  canvas.height = video.videoHeight || 480;
  ctx = canvas.getContext('2d');

  overlay.width = video.videoWidth || 640;
  overlay.height = video.videoHeight || 480;
  overlayCtx = overlay.getContext('2d');

  measurements = {};
  for (const key of Object.keys(STEP_CONFIG)) {
    if (measEls[key]) measEls[key].textContent = '--';
  }
  resultsEl.style.display = 'none';

  btnStart.style.display = 'none';
  previewArea.style.display = 'flex';

  setCalStep('red');
  appendLog('INFO', 'Camera calibration started (6-step R/G/B/C/M/Y)');
}

function stopCalibration() {
  if (stream) {
    stream.getTracks().forEach(t => t.stop());
    stream = null;
  }
  video.srcObject = null;
  state = 'idle';

  previewArea.style.display = 'none';
  btnStart.style.display = '';
  if (overlayCtx) overlayCtx.clearRect(0, 0, overlay.width, overlay.height);

  appendLog('INFO', 'Camera calibration stopped');
}

function setCalStep(step) {
  state = step;
  const stepIdx = STEP_ORDER.indexOf(step);

  stepEls.forEach(el => {
    const s = el.dataset.step;
    const sIdx = STEP_ORDER.indexOf(s);
    el.classList.remove('active', 'done');
    if (s === step) {
      el.classList.add('active');
    } else if (sIdx < stepIdx) {
      el.classList.add('done');
    }
  });

  if (overlayCtx) overlayCtx.clearRect(0, 0, overlay.width, overlay.height);

  if (step === 'done') {
    btnCapture.style.display = 'none';
    btnNext.style.display = 'none';
    statusEl.textContent = 'Calibration complete!';

    const correction = computeCorrection();
    resultR.textContent = `R: ${correction.r}%`;
    resultG.textContent = `G: ${correction.g}%`;
    resultB.textContent = `B: ${correction.b}%`;
    resultsEl.style.display = '';
    return;
  }

  const cfg = STEP_CONFIG[step];
  const nextStep = STEP_ORDER[stepIdx + 1];
  const nextLabel = nextStep === 'done' ? 'Finish' : `Next (${STEP_CONFIG[nextStep].label})`;

  btnCapture.textContent = `Capture ${cfg.label}`;
  btnCapture.style.display = '';
  btnCapture.disabled = false;
  btnNext.textContent = nextLabel;
  btnNext.style.display = '';
  btnNext.disabled = true;

  const [r, g, b] = cfg.color;
  statusEl.textContent = `LED → (${r},${g},${b}). Click Capture.`;

  sendWs('led_color', { r, g, b });
  appendLog('INFO', `Cal step: ${cfg.label} — LED set to (${r},${g},${b})`);
}

function captureFrame() {
  if (!video || video.readyState < 2) {
    statusEl.textContent = 'Video not ready. Please wait and try again.';
    return null;
  }

  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const roi = detectROI(imageData, canvas.width, canvas.height);
  const avg = computeAverageRGB(imageData, roi);
  drawROIOverlay(roi);
  return avg;
}

function detectROI(imageData, w, h) {
  const data = imageData.data;
  let maxBright = 0;

  for (let i = 0; i < data.length; i += 4) {
    const bright = (data[i] + data[i + 1] + data[i + 2]) / 3;
    if (bright > maxBright) maxBright = bright;
  }

  const threshold = maxBright * 0.5;
  let sumX = 0, sumY = 0, sumW = 0;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const bright = (data[idx] + data[idx + 1] + data[idx + 2]) / 3;
      if (bright >= threshold) {
        sumX += x * bright;
        sumY += y * bright;
        sumW += bright;
      }
    }
  }

  if (sumW === 0) {
    statusEl.textContent = 'No bright area detected — using center fallback';
    return { x: Math.floor(w / 2) - 20, y: Math.floor(h / 2) - 20, w: 40, h: 40 };
  }

  const cx = Math.round(sumX / sumW);
  const cy = Math.round(sumY / sumW);

  const roiSize = 40;
  const half = roiSize / 2;
  const rx = Math.max(0, Math.min(w - roiSize, cx - half));
  const ry = Math.max(0, Math.min(h - roiSize, cy - half));

  return { x: rx, y: ry, w: roiSize, h: roiSize };
}

function computeAverageRGB(imageData, roi) {
  const data = imageData.data;
  const w = imageData.width;
  let sumR = 0, sumG = 0, sumB = 0, count = 0;

  for (let y = roi.y; y < roi.y + roi.h; y++) {
    for (let x = roi.x; x < roi.x + roi.w; x++) {
      const idx = (y * w + x) * 4;
      sumR += data[idx];
      sumG += data[idx + 1];
      sumB += data[idx + 2];
      count++;
    }
  }

  return {
    r: Math.round(sumR / count),
    g: Math.round(sumG / count),
    b: Math.round(sumB / count)
  };
}

function drawROIOverlay(roi) {
  overlayCtx.clearRect(0, 0, overlay.width, overlay.height);

  const sx = overlay.width / canvas.width;
  const sy = overlay.height / canvas.height;
  const dx = roi.x * sx;
  const dy = roi.y * sy;
  const dw = roi.w * sx;
  const dh = roi.h * sy;

  overlayCtx.strokeStyle = '#00ff00';
  overlayCtx.lineWidth = 2;
  overlayCtx.strokeRect(dx, dy, dw, dh);

  const cx = dx + dw / 2;
  const cy = dy + dh / 2;
  overlayCtx.beginPath();
  overlayCtx.moveTo(cx - 8, cy);
  overlayCtx.lineTo(cx + 8, cy);
  overlayCtx.moveTo(cx, cy - 8);
  overlayCtx.lineTo(cx, cy + 8);
  overlayCtx.stroke();
}

function handleCapture() {
  const avg = captureFrame();
  if (!avg) return;

  // Validate that expected primary channels are visible
  const primaries = STEP_PRIMARY[state];
  const minVal = Math.min(...primaries.map(ch => avg[ch]));
  if (minVal < 10) {
    const chNames = primaries.map(c => c.toUpperCase()).join('/');
    statusEl.textContent = `Warning: LED may not be visible (${chNames} too low: ${minVal})`;
    btnNext.disabled = true;
    return;
  }

  measurements[state] = avg;

  if (measEls[state]) {
    measEls[state].textContent = `${avg.r},${avg.g},${avg.b}`;
  }

  statusEl.textContent = `Captured ${STEP_CONFIG[state].label}: R=${avg.r} G=${avg.g} B=${avg.b}`;
  btnNext.disabled = false;
  appendLog('INFO', `Cal capture ${state}: R=${avg.r} G=${avg.g} B=${avg.b}`);
}

function handleNext() {
  const idx = STEP_ORDER.indexOf(state);
  if (idx < 0) return;
  setCalStep(STEP_ORDER[idx + 1]);
}

/**
 * Compute correction using averaged channel responses across 6 measurements.
 *
 * Each channel is measured in its primary test AND in its secondary (CMY) tests:
 *   R response: red.r, magenta.r, yellow.r  (3 samples)
 *   G response: green.g, cyan.g, yellow.g   (3 samples)
 *   B response: blue.b, cyan.b, magenta.b   (3 samples)
 *
 * Averaging reduces noise and accounts for cross-channel effects.
 */
function computeCorrection() {
  const m = measurements;

  const avgR = (m.red.r + m.magenta.r + m.yellow.r) / 3;
  const avgG = (m.green.g + m.cyan.g + m.yellow.g) / 3;
  const avgB = (m.blue.b + m.cyan.b + m.magenta.b) / 3;

  const corrR = 255 / avgR;
  const corrG = 255 / avgG;
  const corrB = 255 / avgB;

  const maxCorr = Math.max(corrR, corrG, corrB);
  return {
    r: Math.round(corrR / maxCorr * 100),
    g: Math.round(corrG / maxCorr * 100),
    b: Math.round(corrB / maxCorr * 100)
  };
}

function applyResults() {
  const correction = computeCorrection();

  const calR = document.getElementById('led-cal-r');
  const calG = document.getElementById('led-cal-g');
  const calB = document.getElementById('led-cal-b');

  calR.value = correction.r;
  calG.value = correction.g;
  calB.value = correction.b;

  calR.dispatchEvent(new Event('input'));
  calG.dispatchEvent(new Event('input'));
  calB.dispatchEvent(new Event('input'));

  appendLog('INFO', `Cal applied: R=${correction.r}% G=${correction.g}% B=${correction.b}%`);
  stopCalibration();
}
