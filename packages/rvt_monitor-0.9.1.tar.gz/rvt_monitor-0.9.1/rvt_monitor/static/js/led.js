/**
 * LED control module — toggle, brightness, color index, color presets
 */

import { sendWs } from './ws.js';
import { appendLog } from './log.js';
import { initCalibration } from './calibration.js';

let ledStates = {0: false, 1: false, 2: false, 3: false};

function toggleLed(target) {
  ledStates[target] = !ledStates[target];
  sendWs('led_mode', { target, on: ledStates[target] });
  updateLedToggleBtn(target, ledStates[target]);
}

function updateLedToggleBtn(target, on) {
  const btn = document.querySelector(`.led-toggle-btn[data-target="${target}"]`);
  if (btn) {
    btn.textContent = on ? 'ON' : 'OFF';
    btn.className = `btn led-toggle-btn ${on ? 'led-on' : ''}`;
  }
}

function sendLedBrightnessAll(value) {
  value = parseInt(value, 10);
  document.getElementById('led-brightness-all-value').textContent = value;
  sendWs('led_brightness', { target: 255, value });
}

function sendLedColorIndex(index) {
  document.querySelectorAll('.color-index-btn').forEach(btn => {
    btn.classList.toggle('active', parseInt(btn.dataset.index, 10) === index);
  });
  sendWs('led_color_index', { index });
}

function sendLedPresetColor(r, g, b) {
  sendWs('led_color', { r, g, b });
  appendLog('INFO', `LED Color: R:${r} G:${g} B:${b}`);
}

function updateCalHexPreview() {
  const r = Math.max(0, Math.min(100, parseInt(document.getElementById('led-cal-r').value, 10) || 0));
  const g = Math.max(0, Math.min(100, parseInt(document.getElementById('led-cal-g').value, 10) || 0));
  const b = Math.max(0, Math.min(100, parseInt(document.getElementById('led-cal-b').value, 10) || 0));
  const packed = (r << 16) | (g << 8) | b;
  document.getElementById('led-cal-hex').textContent = '0x' + packed.toString(16).padStart(8, '0').toUpperCase();
}

function writeCalibration() {
  const r = Math.max(0, Math.min(100, parseInt(document.getElementById('led-cal-r').value, 10) || 0));
  const g = Math.max(0, Math.min(100, parseInt(document.getElementById('led-cal-g').value, 10) || 0));
  const b = Math.max(0, Math.min(100, parseInt(document.getElementById('led-cal-b').value, 10) || 0));
  const packed = (r << 16) | (g << 8) | b;
  sendWs('write_dimension', { id: 0x0C, value: packed });
  sendWs('save_dimensions');
  appendLog('INFO', `LED Cal Write: R=${r}% G=${g}% B=${b}% (0x${packed.toString(16).padStart(8, '0').toUpperCase()})`);
}

export function initLedListeners() {
  document.getElementById('btn-read-led-status').addEventListener('click', () => {
    sendWs('read_led_status');
  });

  document.querySelectorAll('.led-toggle-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      toggleLed(parseInt(btn.dataset.target, 10));
    });
  });

  document.getElementById('led-brightness-all').addEventListener('input', (e) => {
    sendLedBrightnessAll(e.target.value);
  });

  document.querySelectorAll('.color-index-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      sendLedColorIndex(parseInt(btn.dataset.index, 10));
    });
  });

  document.querySelectorAll('.color-swatch').forEach(swatch => {
    const r = parseInt(swatch.dataset.r, 10);
    const g = parseInt(swatch.dataset.g, 10);
    const b = parseInt(swatch.dataset.b, 10);
    swatch.addEventListener('click', () => {
      sendLedPresetColor(r, g, b);
    });
  });

  ['led-cal-r', 'led-cal-g', 'led-cal-b'].forEach(id => {
    document.getElementById(id).addEventListener('input', updateCalHexPreview);
  });
  document.getElementById('btn-led-cal-write').addEventListener('click', writeCalibration);

  initCalibration();
}

export function renderLedStatus(data) {
  if (!data || !data.leds) return;

  const ledNames = ['wall', 'direct', 'ceiling', 'head'];
  let firstBrightness = 0;
  ledNames.forEach((name, idx) => {
    const led = data.leds[name];
    if (!led) return;

    const isOn = led.mode !== 0;
    ledStates[idx] = isOn;
    updateLedToggleBtn(idx, isOn);

    if (idx === 0) firstBrightness = led.default_brightness;
  });

  const slider = document.getElementById('led-brightness-all');
  if (slider) slider.value = firstBrightness;
  document.getElementById('led-brightness-all-value').textContent = firstBrightness;

  if (data.current_index !== undefined) {
    document.querySelectorAll('.color-index-btn').forEach(btn => {
      btn.classList.toggle('active', parseInt(btn.dataset.index, 10) === data.current_index);
    });
  }

}
