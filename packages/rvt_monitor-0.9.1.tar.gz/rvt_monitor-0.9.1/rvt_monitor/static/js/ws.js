/**
 * WebSocket module — connection management and message sending
 */

import { appendLog } from './log.js';

let ws = null;
let _clientId = null;
let messageHandler = null;

export function getClientId() {
  return _clientId;
}

export function setClientId(id) {
  _clientId = id;
}

export function initWebSocket(onMessage) {
  messageHandler = onMessage;
  connect();
}

function connect() {
  ws = new WebSocket(`ws://${location.host}/ws`);

  ws.onopen = () => {
    appendLog('INFO', 'WebSocket connected');
  };

  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    if (messageHandler) messageHandler(msg);
  };

  ws.onclose = () => {
    appendLog('WARNING', 'WebSocket disconnected, reconnecting...');
    _clientId = null;
    setTimeout(connect, 3000);
  };

  ws.onerror = () => {
    appendLog('ERROR', 'WebSocket error');
  };
}

export function sendWs(type, data = {}) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type, data }));
  }
}
