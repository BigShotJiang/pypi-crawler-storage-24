/**
 * Wally status update module — p1/p2 branch included
 */

import {
  getMotionStateText, formatVoltage, formatTemp,
  getSpeedControlStateName, getMotionPhaseName,
  formatTofState, formatWallyLimitSwitch,
  formatUptime, formatHeap,
} from './status-common.js';

let el = {};

export function initWallyElements() {
  el = {
    motionState: document.getElementById('wally-motion-state'),
    mcuTemp: document.getElementById('wally-mcu-temp'),
    // p3-only
    freeHeap: document.getElementById('wally-free-heap'),
    minHeap: document.getElementById('wally-min-heap'),
    uptime: document.getElementById('wally-uptime'),
    // p2-only
    speedControlState: document.getElementById('wally-speed-control-state'),
    motionPhase: document.getElementById('wally-motion-phase'),
    positionMm: document.getElementById('wally-position-mm'),
    positionPct: document.getElementById('wally-position-pct'),
    remainDistance: document.getElementById('wally-remain-distance'),
    currentVelocity: document.getElementById('wally-current-velocity'),
    commandVelocity: document.getElementById('wally-command-velocity'),
    torque: document.getElementById('wally-torque'),
    positionVerified: document.getElementById('wally-position-verified'),
    modelLearning: document.getElementById('wally-model-learning'),
    limitSwitch: document.getElementById('wally-limit-switch'),
    photoSensor: document.getElementById('wally-photo-sensor'),
    // p1-only
    limitSwitchP1: document.getElementById('wally-limit-switch-p1'),
    mlAlarmP1: document.getElementById('wally-ml-alarm-p1'),
    mrAlarmP1: document.getElementById('wally-mr-alarm-p1'),
    // Kinematics
    x: document.getElementById('wally-x'),
    y: document.getElementById('wally-y'),
    distance: document.getElementById('wally-distance'),
    angle: document.getElementById('wally-angle'),
    // Left motor
    mlConnected: document.getElementById('wally-ml-connected'),
    mlEnabled: document.getElementById('wally-ml-enabled'),
    mlAlarm: document.getElementById('wally-ml-alarm'),
    mlVelocity: document.getElementById('wally-ml-velocity'),
    mlTorque: document.getElementById('wally-ml-torque'),
    mlCurrent: document.getElementById('wally-ml-current'),
    mlVoltage: document.getElementById('wally-ml-voltage'),
    mlTemperature: document.getElementById('wally-ml-temperature'),
    // Right motor
    mrConnected: document.getElementById('wally-mr-connected'),
    mrEnabled: document.getElementById('wally-mr-enabled'),
    mrAlarm: document.getElementById('wally-mr-alarm'),
    mrVelocity: document.getElementById('wally-mr-velocity'),
    mrTorque: document.getElementById('wally-mr-torque'),
    mrCurrent: document.getElementById('wally-mr-current'),
    mrVoltage: document.getElementById('wally-mr-voltage'),
    mrTemperature: document.getElementById('wally-mr-temperature'),
    // ToF
    tofLeftStatus: document.getElementById('wally-tof-left-status'),
    tofLeftDist: document.getElementById('wally-tof-left-dist'),
    tofRightStatus: document.getElementById('wally-tof-right-status'),
    tofRightDist: document.getElementById('wally-tof-right-dist'),
  };
}

export function updateWallyStatus(status, profileId) {
  const isP2 = profileId === 'v1-p2' || profileId === 'v1-p3';
  const isP3 = profileId === 'v1-p3';

  el.motionState.textContent = getMotionStateText(status.motion_state, 'wally');
  el.mcuTemp.textContent = status.mcu_temp ?? '-';

  if (isP3) {
    el.freeHeap.textContent = formatHeap(status.free_heap);
    el.minHeap.textContent = `${status.min_free_heap_kb ?? '-'} KB`;
    el.uptime.textContent = formatUptime(status.uptime_s);
  }

  if (isP2) {
    el.speedControlState.textContent = getSpeedControlStateName(status.speed_control_state);
    el.motionPhase.textContent = getMotionPhaseName(status.motion_phase, 'wally');
    el.positionMm.textContent = status.position_mm ?? '-';
    el.positionPct.textContent = status.position_percentage ?? '-';
    el.remainDistance.textContent = status.remain_distance ?? '-';
    el.currentVelocity.textContent = status.current_velocity ?? '-';
    el.commandVelocity.textContent = status.command_velocity ?? '-';
    el.torque.textContent = status.torque ?? '-';
    el.positionVerified.textContent = status.is_position_verified ? 'Yes' : 'No';
    el.positionVerified.className = status.is_position_verified ? 'status-ok' : 'status-warn';
    el.modelLearning.textContent = status.is_current_model_learning ? 'Yes' : 'No';
    el.limitSwitch.textContent = formatWallyLimitSwitch(status.limit_switch_state);
    el.photoSensor.textContent = status.photo_sensor_state ?? '-';
  } else {
    el.limitSwitchP1.textContent = formatWallyLimitSwitch(status.limit_switch_state);
  }

  // Kinematics
  el.x.textContent = status.wally_x?.toFixed(1) ?? '-';
  el.y.textContent = status.wally_y?.toFixed(1) ?? '-';
  el.distance.textContent = status.distance_to_wall ?? '-';
  el.angle.textContent = status.angle?.toFixed(2) ?? '-';

  // Left motor
  const ml = status.motor_left || {};
  if (isP2) {
    el.mlConnected.textContent = ml.is_connected ? 'OK' : 'N/A';
    el.mlConnected.className = ml.is_connected ? 'status-ok' : 'status-warn';
    el.mlEnabled.textContent = ml.is_enabled ? 'ON' : 'OFF';
    el.mlEnabled.className = ml.is_enabled ? 'status-ok' : 'status-warn';
    el.mlAlarm.textContent = ml.current_alarm ? `Code ${ml.current_alarm}` : 'None';
    el.mlVelocity.textContent = ml.raw_velocity ?? '-';
    el.mlTorque.textContent = ml.raw_torque ?? '-';
  } else {
    el.mlAlarmP1.textContent = ml.current_alarm ? `Code ${ml.current_alarm}` : 'None';
    el.mlVelocity.textContent = ml.velocity?.toFixed(1) ?? '-';
    el.mlTorque.textContent = ml.torque?.toFixed(2) ?? '-';
  }
  el.mlCurrent.textContent = ml.current ?? '-';
  el.mlVoltage.textContent = formatVoltage(ml.voltage);
  el.mlTemperature.textContent = formatTemp(ml.temperature);

  // Right motor
  const mr = status.motor_right || {};
  if (isP2) {
    el.mrConnected.textContent = mr.is_connected ? 'OK' : 'N/A';
    el.mrConnected.className = mr.is_connected ? 'status-ok' : 'status-warn';
    el.mrEnabled.textContent = mr.is_enabled ? 'ON' : 'OFF';
    el.mrEnabled.className = mr.is_enabled ? 'status-ok' : 'status-warn';
    el.mrAlarm.textContent = mr.current_alarm ? `Code ${mr.current_alarm}` : 'None';
    el.mrVelocity.textContent = mr.raw_velocity ?? '-';
    el.mrTorque.textContent = mr.raw_torque ?? '-';
  } else {
    el.mrAlarmP1.textContent = mr.current_alarm ? `Code ${mr.current_alarm}` : 'None';
    el.mrVelocity.textContent = mr.velocity?.toFixed(1) ?? '-';
    el.mrTorque.textContent = mr.torque?.toFixed(2) ?? '-';
  }
  el.mrCurrent.textContent = mr.current ?? '-';
  el.mrVoltage.textContent = formatVoltage(mr.voltage);
  el.mrTemperature.textContent = formatTemp(mr.temperature);

  // ToF sensors
  const tofLeft = status.tof_left || {};
  const tofRight = status.tof_right || {};

  el.tofLeftStatus.textContent = formatTofState(tofLeft);
  el.tofLeftDist.textContent = tofLeft.distance_mm?.toFixed(1) ?? '-';
  el.tofRightStatus.textContent = formatTofState(tofRight);
  el.tofRightDist.textContent = tofRight.distance_mm?.toFixed(1) ?? '-';
}
