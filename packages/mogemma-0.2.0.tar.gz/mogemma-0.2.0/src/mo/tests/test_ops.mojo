from collections import List
from mogemma.ops import rms_norm, geglu, rope_rotate, vec_mat_mul, mat_mat_mul, softmax
from mogemma.ops_gpu import rms_norm_gpu, geglu_gpu, rope_rotate_gpu, vec_mat_mul_gpu, softmax_gpu
from memory import UnsafePointer
from testing import assert_almost_equal


fn test_rms_norm() raises:
    # 4 elements: all 1.0. Mean sq = 1.0, inv_rms ~= 1.0
    var x = List[Float32](length=4, fill=1.0)
    var w = List[Float32](length=4, fill=2.0)
    var out = List[Float32](length=4, fill=0.0)

    # We must cast the pointers
    var x_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(x.unsafe_ptr()))
    var w_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(w.unsafe_ptr()))
    var out_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(out.unsafe_ptr()))

    rms_norm[2](out_ptr, x_ptr, w_ptr, 4)

    # Runtime uses Gemma-style scale of (1 + weight)
    assert_almost_equal(out[0], 3.0, atol=1e-5)
    assert_almost_equal(out[1], 3.0, atol=1e-5)
    assert_almost_equal(out[2], 3.0, atol=1e-5)
    assert_almost_equal(out[3], 3.0, atol=1e-5)
    _ = x[0]
    _ = w[0]


fn test_rms_norm_gpu() raises:
    var x = List[Float32](length=4, fill=1.0)
    var w = List[Float32](length=4, fill=2.0)
    var out = List[Float32](length=4, fill=0.0)
    var x_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(x.unsafe_ptr()))
    var w_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(w.unsafe_ptr()))
    var out_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(out.unsafe_ptr()))
    rms_norm_gpu(out_ptr, x_ptr, w_ptr, 4)
    assert_almost_equal(out[0], 3.0, atol=1e-5)
    _ = x[0]
    _ = w[0]


fn test_geglu() raises:
    # gate=1.0, up=2.0 -> gelu_gate = 0.5 * 1.0 * (1 + erf(1/sqrt(2))) ~= 0.5 * 1 * 1.84134 = 0.84134
    # out = 0.84134 * 2.0 = 1.68268
    var gate = List[Float32](length=4, fill=1.0)
    var up = List[Float32](length=4, fill=2.0)
    var out = List[Float32](length=4, fill=0.0)

    var gate_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(gate.unsafe_ptr()))
    var up_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(up.unsafe_ptr()))
    var out_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(out.unsafe_ptr()))

    geglu[2](out_ptr, gate_ptr, up_ptr, 4)

    assert_almost_equal(out[0], 1.68268, atol=1e-4)
    _ = gate[0]
    _ = up[0]


fn test_geglu_gpu() raises:
    var gate = List[Float32](length=4, fill=1.0)
    var up = List[Float32](length=4, fill=2.0)
    var out = List[Float32](length=4, fill=0.0)
    var gate_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(gate.unsafe_ptr()))
    var up_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(up.unsafe_ptr()))
    var out_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(out.unsafe_ptr()))
    geglu_gpu(out_ptr, gate_ptr, up_ptr, 4)
    assert_almost_equal(out[0], 1.68268, atol=1e-4)
    _ = gate[0]
    _ = up[0]


fn test_rope_rotate() raises:
    var vec = List[Float32](length=4, fill=0.0)
    vec[0] = 1.0
    vec[1] = 0.0
    vec[2] = 0.0
    vec[3] = 1.0

    var cos = List[Float32](length=2, fill=0.0)
    cos[0] = 0.0
    cos[1] = 1.0

    var sin = List[Float32](length=2, fill=0.0)
    sin[0] = 1.0
    sin[1] = 0.0

    var vec_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(vec.unsafe_ptr()))
    var cos_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(cos.unsafe_ptr()))
    var sin_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(sin.unsafe_ptr()))

    rope_rotate[1](vec_ptr, cos_ptr, sin_ptr, 4)

    assert_almost_equal(vec[0], 0.0, atol=1e-5)
    assert_almost_equal(vec[2], 1.0, atol=1e-5)
    assert_almost_equal(vec[1], 0.0, atol=1e-5)
    assert_almost_equal(vec[3], 1.0, atol=1e-5)
    _ = cos[0]
    _ = sin[0]


fn test_rope_rotate_gpu() raises:
    var vec = List[Float32](length=4, fill=0.0)
    vec[0] = 1.0
    vec[1] = 0.0
    vec[2] = 0.0
    vec[3] = 1.0
    var cos = List[Float32](length=2, fill=0.0)
    cos[0] = 0.0
    cos[1] = 1.0
    var sin = List[Float32](length=2, fill=0.0)
    sin[0] = 1.0
    sin[1] = 0.0
    var vec_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(vec.unsafe_ptr()))
    var cos_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(cos.unsafe_ptr()))
    var sin_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(sin.unsafe_ptr()))
    rope_rotate_gpu(vec_ptr, cos_ptr, sin_ptr, 4)
    assert_almost_equal(vec[0], 0.0, atol=1e-5)
    _ = cos[0]
    _ = sin[0]


fn test_vec_mat_mul() raises:
    var x = List[Float32](length=4, fill=1.0)
    var w = List[Float32](length=8, fill=2.0)  # 2x4
    var out = List[Float32](length=2, fill=0.0)

    var x_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(x.unsafe_ptr()))
    var w_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(w.unsafe_ptr()))
    var out_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(out.unsafe_ptr()))

    vec_mat_mul[2](out_ptr, x_ptr, w_ptr, 4, 2)

    assert_almost_equal(out[0], 8.0, atol=1e-5)
    assert_almost_equal(out[1], 8.0, atol=1e-5)
    _ = x[0]
    _ = w[0]


fn test_mat_mat_mul() raises:
    var batch_size = 2
    var in_dim = 4
    var out_dim = 2
    var x = List[Float32](length=batch_size * in_dim, fill=1.0)
    var w = List[Float32](length=out_dim * in_dim, fill=2.0)  # transposed [out_dim, in_dim]
    var out = List[Float32](length=batch_size * out_dim, fill=0.0)

    var x_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(x.unsafe_ptr()))
    var w_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(w.unsafe_ptr()))
    var out_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(out.unsafe_ptr()))

    mat_mat_mul[2](out_ptr, x_ptr, w_ptr, batch_size, in_dim, out_dim)

    # 1.0 * 2.0 * 4 = 8.0 for each output element
    assert_almost_equal(out[0], 8.0, atol=1e-5)
    assert_almost_equal(out[1], 8.0, atol=1e-5)
    assert_almost_equal(out[2], 8.0, atol=1e-5)
    assert_almost_equal(out[3], 8.0, atol=1e-5)
    _ = x[0]
    _ = w[0]


fn test_vec_mat_mul_gpu() raises:
    var x = List[Float32](length=4, fill=1.0)
    var w = List[Float32](length=8, fill=2.0)
    var out = List[Float32](length=2, fill=0.0)
    var x_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(x.unsafe_ptr()))
    var w_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(w.unsafe_ptr()))
    var out_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(out.unsafe_ptr()))
    vec_mat_mul_gpu(out_ptr, x_ptr, w_ptr, 4, 2)
    assert_almost_equal(out[0], 8.0, atol=1e-5)
    _ = x[0]
    _ = w[0]


fn test_softmax() raises:
    var x = List[Float32](length=3, fill=0.0)
    x[0] = 1.0
    x[1] = 2.0
    x[2] = 3.0
    var x_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(x.unsafe_ptr()))
    softmax[1](x_ptr, 3)

    # expected: [0.09003057, 0.24472847, 0.66524096]
    assert_almost_equal(x[0], 0.09003057, atol=1e-5)
    assert_almost_equal(x[1], 0.24472847, atol=1e-5)
    assert_almost_equal(x[2], 0.66524096, atol=1e-5)
    _ = x[0]


fn test_softmax_gpu() raises:
    var x = List[Float32](length=3, fill=0.0)
    x[0] = 1.0
    x[1] = 2.0
    x[2] = 3.0
    var x_ptr = UnsafePointer[Float32, MutExternalOrigin](unsafe_from_address=Int(x.unsafe_ptr()))
    softmax_gpu(x_ptr, 3)
    assert_almost_equal(x[0], 0.09003057, atol=1e-5)
    _ = x[0]


fn main() raises:
    test_rms_norm()
    test_geglu()
    test_rope_rotate()
    test_vec_mat_mul()
    test_softmax()
    print("Mojo math primitive tests passed!")

    var gpu_passed = False
    try:
        test_rms_norm_gpu()
        test_geglu_gpu()
        test_rope_rotate_gpu()
        test_vec_mat_mul_gpu()
        test_softmax_gpu()
        gpu_passed = True
    except e:
        print("GPU tests failed (expected during RED phase):", String(e))

    if gpu_passed:
        print("Mojo GPU math primitive tests passed!")
    else:
        raise Error("GPU tests must pass in GREEN phase")
