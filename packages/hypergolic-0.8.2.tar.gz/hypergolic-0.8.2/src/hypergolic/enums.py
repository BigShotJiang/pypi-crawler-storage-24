from enum import Enum


class ModelTier(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"


class KnowledgeScope(str, Enum):
    UNIVERSAL = "universal"
    USER = "user"
    PROJECT = "project"
    SESSION = "session"


class KnowledgeRelationType(str, Enum):
    RELATES_TO = "relates_to"
    DEPENDS_ON = "depends_on"
    CONTRADICTS = "contradicts"
    SUPERSEDES = "supersedes"
    REFINES = "refines"
    EXAMPLE_OF = "example_of"
