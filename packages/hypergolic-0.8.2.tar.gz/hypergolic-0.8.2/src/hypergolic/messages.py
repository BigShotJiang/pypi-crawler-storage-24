import asyncio
import logging
from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Callable, Awaitable, cast

from anthropic import AsyncAnthropic, ParsedMessageStreamEvent, APIConnectionError, APIStatusError
from anthropic.types import (
    Message,
    MessageParam,
    ParsedMessage,
    StopReason,
    TextBlockParam,
    ToolResultBlockParam,
    ToolUseBlock,
)
from pydantic import BaseModel
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage
from hypergolic.prompts.builder import build_session_prompt
from hypergolic.providers import tier_to_model_id
from hypergolic.schemas import Session
from hypergolic.tools.tool_list import build_tools, get_tool_schemas, set_tools_cache_breakpoint
from hypergolic.tools.handlers import ApprovalCallback, UserQuestionCallback, handle_tool_use
from hypergolic.truncation import (
    get_last_assistant_usage,
    perform_truncation,
    persist_truncation_summary,
    resolve_truncation_config,
    should_truncate,
)

logger = logging.getLogger(__name__)

MAX_STREAM_RETRIES = 2
RETRY_BASE_DELAY = 1.0

RETRYABLE_EXCEPTIONS = (APIConnectionError,)


class UserInterrupt(Exception):
    def __init__(self, partial_text: str | None = None):
        super().__init__()
        self.partial_text = partial_text


def _is_retryable_status(exc: APIStatusError) -> bool:
    return exc.status_code in (429, 500, 502, 503, 529)


@dataclass
class BroadcastEvent:
    type: str
    role: str
    content: Any
    session_id: str | None = None
    model: str | None = None
    stop_reason: str | None = None
    message_id: str | None = None
    usage: dict | None = None


BroadcastFn = Callable[[BroadcastEvent], Awaitable[None]]


def _extract_partial_text(stream: Any) -> str | None:
    try:
        snapshot = stream.current_message_snapshot
    except Exception:
        return None
    if not snapshot or not snapshot.content:
        return None
    text_parts = [
        block.text for block in snapshot.content
        if getattr(block, "type", None) == "text" and getattr(block, "text", None)
    ]
    return "\n\n".join(text_parts) if text_parts else None


INTERRUPTED_SUFFIX = "\n\n---\n*[Response interrupted by user]*"


async def _persist_partial_assistant_message(session_id: str, text: str) -> None:
    with get_db() as db:
        db_message = DBMessage(
            session_id=session_id,
            content=[{"type": "text", "text": text + INTERRUPTED_SUFFIX}],
            model=None,
            role="assistant",
            stop_reason="interrupted",
            stop_sequence=None,
            usage=None,
        )
        db.add(db_message)


def _build_interrupt_tool_results(response: Message) -> MessageParam | None:
    tool_blocks = [b for b in response.content if isinstance(b, ToolUseBlock)]
    if not tool_blocks:
        return None
    result_blocks: list[ToolResultBlockParam] = [
        ToolResultBlockParam(
            tool_use_id=b.id,
            type="tool_result",
            content=[TextBlockParam(type="text", text="Interrupted by user")],
            is_error=True,
        )
        for b in tool_blocks
    ]
    return MessageParam(role="user", content=result_blocks)


async def _persist_interrupt_tool_results(session_id: str, response: Message) -> None:
    interrupt_result = _build_interrupt_tool_results(response)
    if interrupt_result:
        await persist_user_message(session_id=session_id, message=interrupt_result)


async def create_message(
    client: AsyncAnthropic,
    session: Session,
    message: MessageParam,
    broadcast: BroadcastFn,
    history: list[MessageParam] | None = None,
    cancel_event: asyncio.Event | None = None,
    approval_callback: ApprovalCallback | None = None,
    user_question_callback: UserQuestionCallback | None = None,
) -> Message:
    response: Message | None = None
    stop_reason: StopReason | None = None
    _messages: list[MessageParam] = list(history or []) + [message]

    prompt = list(build_session_prompt(session))
    tools = build_tools(session=session)
    tool_schemas = set_tools_cache_breakpoint(get_tool_schemas(tools))

    truncation_config = resolve_truncation_config(session)

    await persist_user_message(session_id=session.id, message=message)

    def _check_cancelled() -> None:
        if cancel_event and cancel_event.is_set():
            raise UserInterrupt()

    # Check if we need truncation before even starting (from a previous turn)
    pre_usage = get_last_assistant_usage(session.id)
    if should_truncate(pre_usage, truncation_config.token_threshold):
        logger.info("Session %s exceeds token threshold, truncating before turn", session.id)
        await broadcast(BroadcastEvent(
            type="truncation_start",
            role="assistant",
            content=[],
            session_id=session.id,
        ))
        summary = await perform_truncation(client, session, _messages[:-1], truncation_config)
        if summary:
            summary_text = summary["content"][0]["text"]  # type: ignore[index]
            persist_truncation_summary(session.id, summary_text)
            _messages = [summary, message]
            prompt = list(build_session_prompt(session))
            await broadcast(BroadcastEvent(
                type="truncation_complete",
                role="assistant",
                content=[],
                session_id=session.id,
            ))
        else:
            await broadcast(BroadcastEvent(
                type="truncation_failed",
                role="assistant",
                content=[],
                session_id=session.id,
            ))

    while stop_reason != "end_turn":
        _check_cancelled()
        cached_messages = set_message_cache_breakpoint(_messages)

        last_stream_error: Exception | None = None
        for attempt in range(MAX_STREAM_RETRIES + 1):
            try:
                async with client.messages.stream(
                    max_tokens=8192,
                    model=tier_to_model_id(session.model_tier),
                    messages=cached_messages,
                    system=prompt,
                    tools=tool_schemas,
                ) as stream:
                    async for event in stream:
                        _check_cancelled()
                        await handle_streaming_event(event, broadcast, session.id)
                    response = await stream.get_final_message()
                last_stream_error = None
                break
            except UserInterrupt:
                partial_text = _extract_partial_text(stream)
                if partial_text:
                    await _persist_partial_assistant_message(
                        session_id=session.id, text=partial_text
                    )
                raise UserInterrupt(partial_text=partial_text)
            except RETRYABLE_EXCEPTIONS as exc:
                last_stream_error = exc
                if attempt < MAX_STREAM_RETRIES:
                    delay = RETRY_BASE_DELAY * (2 ** attempt)
                    logger.warning("Stream attempt %d failed (%s), retrying in %.1fs", attempt + 1, exc, delay)
                    await asyncio.sleep(delay)
                    continue
            except APIStatusError as exc:
                if _is_retryable_status(exc) and attempt < MAX_STREAM_RETRIES:
                    last_stream_error = exc
                    delay = RETRY_BASE_DELAY * (2 ** attempt)
                    logger.warning("Stream attempt %d failed (HTTP %d), retrying in %.1fs", attempt + 1, exc.status_code, delay)
                    await asyncio.sleep(delay)
                    continue
                raise

        if last_stream_error is not None:
            raise last_stream_error

        assert response is not None
        agent_message = parse_agent_message(response)
        _messages.append(agent_message)

        stop_reason = response.stop_reason
        await persist_agent_message(session_id=session.id, message=response)

        # Check if this response pushed us over the truncation threshold.
        # If so, let the current tool calls resolve but don't go back for more.
        current_usage = response.usage.model_dump(mode="json") if response.usage else None
        needs_truncation = should_truncate(current_usage, truncation_config.token_threshold)

        try:
            await broadcast(
                BroadcastEvent(
                    type="assistant_message",
                    role="assistant",
                    content=response.content,
                    session_id=session.id,
                    model=response.model,
                    stop_reason=response.stop_reason,
                    message_id=response.id,
                    usage=response.usage.model_dump(mode="json") if response.usage else None,
                )
            )

            match stop_reason:
                case "end_turn":
                    pass
                case "tool_use":
                    _check_cancelled()
                    tool_result = await handle_tool_use(
                        response, tools,
                        session=session,
                        approval_callback=approval_callback,
                        user_question_callback=user_question_callback,
                    )
                    _check_cancelled()
                    _messages.append(tool_result)
                    await persist_user_message(
                        session_id=session.id, message=tool_result
                    )
                    await broadcast(
                        BroadcastEvent(
                            type="tool_result",
                            role="user",
                            content=tool_result.get("content", []),
                            session_id=session.id,
                        )
                    )
                    if needs_truncation:
                        logger.info(
                            "Session %s hit truncation threshold mid-turn, stopping tool loop",
                            session.id,
                        )
                        stop_reason = "end_turn"
                case _:
                    raise Exception(f"Unhandled stop reason: {stop_reason}")
        except (UserInterrupt, asyncio.CancelledError):
            if stop_reason == "tool_use":
                await _persist_interrupt_tool_results(session.id, response)
            raise UserInterrupt()

    if not response:
        raise Exception("Turn ended without response")
    return response


async def handle_streaming_event(
    event: ParsedMessageStreamEvent,
    broadcast: BroadcastFn,
    session_id: str,
) -> None:
    from anthropic.types import (
        RawContentBlockStartEvent,
        RawContentBlockDeltaEvent,
    )
    from anthropic.lib.streaming._types import ParsedContentBlockStopEvent

    if isinstance(event, RawContentBlockStartEvent):
        block = event.content_block
        block_data: dict[str, Any] = {"type": block.type, "index": event.index}
        if block.type == "text":
            block_data["text"] = ""
        elif block.type == "tool_use":
            block_data["id"] = getattr(block, "id", "")
            block_data["name"] = getattr(block, "name", "")
            block_data["input"] = {}
        await broadcast(BroadcastEvent(
            type="content_block_start",
            role="assistant",
            content=[block_data],
            session_id=session_id,
        ))
    elif isinstance(event, RawContentBlockDeltaEvent):
        delta = event.delta
        delta_data: dict[str, Any] = {"type": delta.type, "index": event.index}
        if delta.type == "text_delta":
            delta_data["text"] = delta.text  # type: ignore[union-attr]
        elif delta.type == "input_json_delta":
            delta_data["partial_json"] = delta.partial_json  # type: ignore[union-attr]
        await broadcast(BroadcastEvent(
            type="content_block_delta",
            role="assistant",
            content=[delta_data],
            session_id=session_id,
        ))
    elif isinstance(event, ParsedContentBlockStopEvent):
        await broadcast(BroadcastEvent(
            type="content_block_stop",
            role="assistant",
            content=[{"index": event.index}],
            session_id=session_id,
        ))


def _strip_cache_control(messages: list[MessageParam]) -> None:
    for message in messages:
        if not isinstance(message, dict):
            continue
        content = message.get("content")
        if not content or not isinstance(content, list):
            continue
        for block in content:
            if isinstance(block, dict) and "cache_control" in block:
                raw = cast(dict[str, Any], block)
                del raw["cache_control"]


def set_message_cache_breakpoint(
    messages: list[MessageParam],
) -> list[MessageParam]:
    result = deepcopy(messages)
    _strip_cache_control(result)

    if len(result) >= 2:
        target_msg = result[-2]
    else:
        target_msg = result[-1]

    content = target_msg.get("content") if isinstance(target_msg, dict) else None
    if content is None or not isinstance(content, list) or len(content) == 0:
        return result

    last_block = content[-1]
    if isinstance(last_block, dict):
        raw = cast(dict[str, Any], last_block)
        raw["cache_control"] = {"type": "ephemeral"}

    return result


EXCLUDED_FIELDS = {"parsed_output", "caller"}


async def persist_agent_message(session_id: str, message: ParsedMessage):
    content = []
    for block in message.content:
        if isinstance(block, BaseModel):
            content.append(block.model_dump(mode="json", exclude=EXCLUDED_FIELDS))
        else:
            content.append(block)

    usage = message.usage.model_dump(mode="json") if message.usage else None

    with get_db() as db:
        db_message = DBMessage(
            id=message.id,
            session_id=session_id,
            content=content,
            model=message.model,
            role=message.role,
            stop_reason=message.stop_reason,
            stop_sequence=message.stop_sequence,
            usage=usage,
        )
        db.add(db_message)


async def persist_user_message(session_id: str, message: MessageParam):
    content = message.get("content", [])

    if isinstance(content, str):
        content = [{"type": "text", "text": content}]
    else:
        normalized_content = []
        for block in content:
            if isinstance(block, BaseModel):
                normalized_content.append(block.model_dump(mode="json"))
            else:
                normalized_content.append(block)
        content = normalized_content

    with get_db() as db:
        db_message = DBMessage(
            session_id=session_id,
            content=content,
            model=None,
            role=message.get("role", "user"),
            stop_reason=None,
            stop_sequence=None,
            usage=None,
        )
        db.add(db_message)




def parse_agent_message(message: Message) -> MessageParam:
    content = []
    for c in message.content:
        if isinstance(c, BaseModel):
            content.append(c.model_dump(mode="json", exclude=EXCLUDED_FIELDS))
        else:
            content.append(c)
    return {
        "content": content,
        "role": "assistant",
    }
