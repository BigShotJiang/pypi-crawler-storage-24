import logging
from copy import deepcopy

from anthropic.types import ToolUnionParam
from hypergolic.config.settings import settings, load_project_config, load_user_project_config
from hypergolic.mcp.tool_bridge import get_mcp_tools_for_session
from hypergolic.schemas import Session
from hypergolic.tools.ask_user import AskUserTool
from hypergolic.tools.browser import BrowserTool
from hypergolic.tools.command import CommandTool
from hypergolic.tools.custom import build_custom_tool
from hypergolic.tools.delete_files import DeleteFilesTool
from hypergolic.tools.edit_file import EditFilesTool
from hypergolic.tools.list_files import ListFilesTool
from hypergolic.tools.make_directory import MakeDirectoryTool
from hypergolic.tools.manage_mcp import ManageMCPTool, get_enabled_servers
from hypergolic.tools.read_files import ReadFilesTool
from hypergolic.tools.search_files import SearchFilesTool
from hypergolic.tools.write_file import WriteFilesTool
from hypergolic.tools.history import HistoryTool
from hypergolic.tools.knowledge import KnowledgeTool
from hypergolic.tools.git import GitTool
from hypergolic.tools.schemas import Tool
from hypergolic.tools.skills import build_skills_tool

logger = logging.getLogger(__name__)

STANDARD_TOOLS: list[Tool] = [
    ListFilesTool,
    ReadFilesTool,
    SearchFilesTool,
    CommandTool,
    WriteFilesTool,
    EditFilesTool,
    MakeDirectoryTool,
    DeleteFilesTool,
    KnowledgeTool,
    HistoryTool,
    AskUserTool,
    ManageMCPTool,
    BrowserTool,
    GitTool,
]


def build_tools(session: Session) -> list[Tool]:
    tools: list[Tool] = list(STANDARD_TOOLS)
    standard_ids = {t.id for t in STANDARD_TOOLS}
    seen_custom_ids: set[str] = set()

    for config in settings.user_config.tools:
        if config.id in standard_ids:
            logger.warning("Custom tool '%s' conflicts with a built-in tool, skipping", config.id)
            continue
        tools.append(build_custom_tool(config))
        seen_custom_ids.add(config.id)

    user_project_config = load_user_project_config(session.working_directory())
    for config in (user_project_config.tools if user_project_config else []):
        if config.id in standard_ids:
            logger.warning("Custom tool '%s' conflicts with a built-in tool, skipping", config.id)
            continue
        if config.id in seen_custom_ids:
            tools = [t for t in tools if t.id != config.id]
            logger.info("User-project tool '%s' overrides user-level tool", config.id)
        tools.append(build_custom_tool(config))
        seen_custom_ids.add(config.id)

    project_config = load_project_config(session.working_directory())
    for config in project_config.tools:
        if config.id in standard_ids:
            logger.warning("Custom tool '%s' conflicts with a built-in tool, skipping", config.id)
            continue
        if config.id in seen_custom_ids:
            tools = [t for t in tools if t.id != config.id]
            logger.info("Project tool '%s' overrides user-level tool", config.id)
        tools.append(build_custom_tool(config))

    skills_tool = build_skills_tool(session.working_directory())
    if skills_tool:
        tools.append(skills_tool)

    enabled_servers = get_enabled_servers(session.id)
    if enabled_servers:
        mcp_tools = get_mcp_tools_for_session(enabled_servers)
        tools.extend(mcp_tools)

    return tools


def get_tool_source(tool_id: str) -> str:
    standard_ids = {t.id for t in STANDARD_TOOLS}
    if tool_id in standard_ids or tool_id == "skills":
        return "standard"
    if tool_id.startswith("mcp_"):
        return "mcp"
    return "user"


def get_tool_schemas(tools: list[Tool]) -> list[ToolUnionParam]:
    return [t.to_param() for t in tools]


def set_tools_cache_breakpoint(
    tool_schemas: list[ToolUnionParam],
) -> list[ToolUnionParam]:
    schemas = deepcopy(tool_schemas)
    schemas[-1]["cache_control"] = {"type": "ephemeral"}
    return schemas
