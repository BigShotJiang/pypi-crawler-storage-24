from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Generic, TypeVar, Type, TYPE_CHECKING

from anthropic.types import ToolUnionParam
from anthropic.types.tool_result_block_param import Content
from pydantic import BaseModel

if TYPE_CHECKING:
    from hypergolic.schemas import Session

T = TypeVar("T", bound=BaseModel)

ToolContent = list[Content]


@dataclass
class ToolOutput:
    content: list[Content] = field(default_factory=list)
    is_error: bool = False


class Tool(BaseModel, Generic[T]):
    id: str
    name: str
    description: str
    strict: bool
    input: Type[T]
    call_tool: Callable[[T, Session], ToolOutput]

    model_config = {"arbitrary_types_allowed": True}

    def to_param(self) -> ToolUnionParam:
        schema = self.input.model_json_schema()
        schema["additionalProperties"] = False

        return {
            "name": self.id,
            "description": self.description,
            "input_schema": schema,
        }
