from typing import Literal

from pydantic import BaseModel, Field

from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput


_enabled_servers_by_session: dict[str, set[str]] = {}


def get_enabled_servers(session_id: str) -> set[str]:
    return _enabled_servers_by_session.get(session_id, set()).copy()


def set_enabled_servers(session_id: str, servers: set[str]) -> None:
    _enabled_servers_by_session[session_id] = servers


class ManageMCPInput(BaseModel):
    command: Literal["list", "enable", "disable"] = Field(
        description="MCP operation to perform."
    )
    server_name: str | None = Field(
        default=None,
        description="Server name (for 'enable'/'disable').",
    )


def _call_manage_mcp(input: ManageMCPInput, session: Session) -> ToolOutput:
    from hypergolic.mcp.client import get_mcp_manager

    manager = get_mcp_manager()
    session_id = session.id

    if input.command == "list":
        available = manager.get_available_servers()
        enabled = get_enabled_servers(session_id)
        if not available:
            return ToolOutput(
                content=[{"type": "text", "text": "No MCP servers configured."}]
            )
        lines = []
        for name, (config, source) in available.items():
            connected = manager.is_connected(name)
            in_session = name in enabled
            status = "enabled" if in_session else ("connected" if connected else "available")
            server = manager.get_connected_server(name)
            tool_count = len(server.tools) if server else 0
            lines.append(
                f"- {name} (source: {source}, status: {status}, "
                f"tools: {tool_count})"
            )
        return ToolOutput(
            content=[{"type": "text", "text": "\n".join(lines)}]
        )

    if not input.server_name:
        return ToolOutput(
            content=[{"type": "text", "text": "server_name is required for enable/disable."}],
            is_error=True,
        )

    if input.command == "enable":
        enabled = get_enabled_servers(session_id)
        enabled.add(input.server_name)
        set_enabled_servers(session_id, enabled)
        return ToolOutput(
            content=[{
                "type": "text",
                "text": f"Marked MCP server '{input.server_name}' as enabled for this session. "
                        f"Connect via the MCP panel or it will be connected on next tool build.",
            }]
        )

    if input.command == "disable":
        enabled = get_enabled_servers(session_id)
        enabled.discard(input.server_name)
        set_enabled_servers(session_id, enabled)
        return ToolOutput(
            content=[{
                "type": "text",
                "text": f"Disabled MCP server '{input.server_name}' for this session.",
            }]
        )

    return ToolOutput(
        content=[{"type": "text", "text": f"Unknown command: {input.command}"}],
        is_error=True,
    )


ManageMCPTool = Tool(
    id="manage_mcp",
    name="Manage MCP Servers",
    description="Manage MCP servers for this session. Commands: list, enable, disable.",
    strict=True,
    input=ManageMCPInput,
    call_tool=_call_manage_mcp,
)
