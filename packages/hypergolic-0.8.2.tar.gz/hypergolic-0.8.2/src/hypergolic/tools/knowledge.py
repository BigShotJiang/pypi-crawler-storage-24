import json
from typing import Literal

from pydantic import BaseModel, Field
from sqlalchemy import func, select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBKnowledge, DBKnowledgeRelationship, DBKnowledgeTag, DBProject, DBTag
from hypergolic.db.queries import get_tags_for_knowledge
from hypergolic.enums import KnowledgeRelationType, KnowledgeScope
from hypergolic.git import git_repo_root
from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput


VALID_RELATION_TYPES = [e.value for e in KnowledgeRelationType]


class KnowledgeCreateItem(BaseModel):
    content: str = Field(description="Knowledge content.")
    tags: list[str] | None = Field(default=None, description="Tag names. Auto-creates new tags.")
    scope: Literal["universal", "user", "project", "session"] | None = Field(
        default=None, description="Scope."
    )
    source: str | None = Field(
        default=None, description="Source: 'user_correction', 'user_stated', 'llm_inferred', etc."
    )


class KnowledgeInput(BaseModel):
    command: Literal["create", "search", "list_tags", "delete", "link", "unlink", "create_tag", "delete_tag"] = Field(
        description="The knowledge operation to perform.",
    )
    content: str | None = Field(
        default=None,
        description="Knowledge content (for single 'create').",
    )
    tags: list[str] | None = Field(
        default=None,
        description="Tag names (for single 'create'). Auto-creates new tags.",
    )
    scope: Literal["universal", "user", "project", "session"] | None = Field(
        default=None,
        description="Scope (for 'create').",
    )
    source: str | None = Field(
        default=None,
        description="Source: 'user_correction', 'user_stated', 'llm_inferred', etc.",
    )
    items: list[KnowledgeCreateItem] | None = Field(
        default=None,
        description="Batch items (for 'create'). If provided, creates multiple items at once.",
    )
    query: str | None = Field(
        default=None,
        description="Substring to search (for 'search').",
    )
    filter_tags: list[str] | None = Field(
        default=None,
        description="Filter by tag names (for 'search').",
    )
    filter_scope: str | None = Field(
        default=None,
        description="Filter by scope (for 'search').",
    )
    knowledge_id: str | None = Field(
        default=None,
        description="ID to delete (for single 'delete').",
    )
    knowledge_ids: list[str] | None = Field(
        default=None,
        description="IDs to delete (for batch 'delete').",
    )
    tag_name: str | None = Field(
        default=None,
        description="Tag name (for 'create_tag').",
    )
    tag_id: str | None = Field(
        default=None,
        description="Tag ID (for 'delete_tag').",
    )
    source_id: str | None = Field(
        default=None,
        description="Source knowledge ID (for 'link').",
    )
    target_id: str | None = Field(
        default=None,
        description="Target knowledge ID (for 'link').",
    )
    relation_type: Literal[
        "relates_to", "depends_on", "contradicts", "supersedes", "refines", "example_of"
    ] | None = Field(
        default=None,
        description="Relationship type (for 'link').",
    )
    relationship_id: str | None = Field(
        default=None,
        description="Relationship ID (for 'unlink').",
    )


def _resolve_project_id(db) -> str | None:  # noqa
    repo_root = str(git_repo_root())
    project = db.execute(
        select(DBProject).where(DBProject.path == repo_root)
    ).scalar_one_or_none()
    return project.id if project else None


def _resolve_or_create_tags(db, tag_names: list[str]) -> list[str]:  # noqa
    tag_ids: list[str] = []
    for name in tag_names:
        tag = db.execute(
            select(DBTag).where(DBTag.name == name)
        ).scalar_one_or_none()
        if not tag:
            tag = DBTag(name=name)
            db.add(tag)
            db.flush()
        tag_ids.append(tag.id)
    return tag_ids


def _serialize_knowledge(db, item: DBKnowledge) -> dict:  # noqa
    tags = get_tags_for_knowledge(db, item.id)
    return {
        "id": item.id,
        "content": item.content,
        "scope": item.scope,
        "source": item.source,
        "project_id": item.project_id,
        "session_id": item.session_id,
        "tags": tags,
        "created_at": item.created_at.isoformat(),
        "updated_at": item.updated_at.isoformat(),
    }


def _create_single_item(
    db, content: str, tags: list[str] | None, scope_str: str | None, source: str | None, session_id: str | None
) -> dict | str:
    scope = KnowledgeScope(scope_str) if scope_str else KnowledgeScope.UNIVERSAL

    project_id = None
    if scope == KnowledgeScope.PROJECT:
        project_id = _resolve_project_id(db)
        if not project_id:
            return "Error: Not in a recognized git project."

    resolved_session_id = None
    if scope == KnowledgeScope.SESSION:
        resolved_session_id = session_id
        if not resolved_session_id:
            return "Error: No active session for session-scoped knowledge."

    item = DBKnowledge(
        content=content,
        scope=scope.value,
        source=source,
        project_id=project_id,
        session_id=resolved_session_id,
    )
    db.add(item)
    db.flush()

    if tags:
        tag_ids = _resolve_or_create_tags(db, tags)
        for tag_id in tag_ids:
            db.add(DBKnowledgeTag(knowledge_id=item.id, tag_id=tag_id))
        db.flush()

    return _serialize_knowledge(db, item)


def _handle_create(input: KnowledgeInput, session_id: str | None) -> ToolOutput:
    if input.items:
        with get_db() as db:
            results = []
            for create_item in input.items:
                result = _create_single_item(
                    db, create_item.content, create_item.tags, create_item.scope, create_item.source, session_id
                )
                if isinstance(result, str):
                    return ToolOutput(
                        content=[{"type": "text", "text": result}],
                        is_error=True,
                    )
                results.append(result)
        return ToolOutput(
            content=[{"type": "text", "text": json.dumps(results, indent=2)}],
        )

    if not input.content:
        return ToolOutput(
            content=[{"type": "text", "text": "Error: 'content' or 'items' is required for create."}],
            is_error=True,
        )

    with get_db() as db:
        result = _create_single_item(db, input.content, input.tags, input.scope, input.source, session_id)
        if isinstance(result, str):
            return ToolOutput(
                content=[{"type": "text", "text": result}],
                is_error=True,
            )

    return ToolOutput(
        content=[{"type": "text", "text": json.dumps(result, indent=2)}],
    )


def _handle_search(input: KnowledgeInput) -> ToolOutput:
    with get_db() as db:
        query = select(DBKnowledge)

        if input.query:
            query = query.where(DBKnowledge.content.contains(input.query))

        if input.filter_scope:
            query = query.where(DBKnowledge.scope == input.filter_scope)

        if input.filter_tags:
            for tag_name in input.filter_tags:
                tag_subq = (
                    select(DBKnowledgeTag.knowledge_id)
                    .join(DBTag, DBKnowledgeTag.tag_id == DBTag.id)
                    .where(DBTag.name == tag_name)
                )
                query = query.where(DBKnowledge.id.in_(tag_subq))

        query = query.order_by(DBKnowledge.created_at.desc()).limit(50)
        items = db.execute(query).scalars().all()
        results = [_serialize_knowledge(db, item) for item in items]

    return ToolOutput(
        content=[{"type": "text", "text": json.dumps(results, indent=2)}],
    )


def _handle_list_tags() -> ToolOutput:
    with get_db() as db:
        rows = db.execute(
            select(DBTag.name, func.count(DBKnowledgeTag.id).label("count"))
            .outerjoin(DBKnowledgeTag, DBKnowledgeTag.tag_id == DBTag.id)
            .group_by(DBTag.id)
            .order_by(DBTag.name)
        ).all()
        results = [{"name": row.name, "count": row.count} for row in rows]

    return ToolOutput(
        content=[{"type": "text", "text": json.dumps(results, indent=2)}],
    )


def _delete_single_item(db, kid: str) -> str | None:
    from sqlalchemy import delete as sa_delete

    item = db.execute(
        select(DBKnowledge).where(DBKnowledge.id == kid)
    ).scalar_one_or_none()

    if not item:
        return f"Error: Knowledge item '{kid}' not found."

    db.execute(sa_delete(DBKnowledgeTag).where(DBKnowledgeTag.knowledge_id == item.id))
    db.execute(sa_delete(DBKnowledgeRelationship).where(
        (DBKnowledgeRelationship.source_id == item.id)
        | (DBKnowledgeRelationship.target_id == item.id)
    ))
    db.delete(item)
    return None


def _handle_delete(input: KnowledgeInput) -> ToolOutput:
    ids_to_delete: list[str] = []
    if input.knowledge_ids:
        ids_to_delete = input.knowledge_ids
    elif input.knowledge_id:
        ids_to_delete = [input.knowledge_id]
    else:
        return ToolOutput(
            content=[{"type": "text", "text": "Error: 'knowledge_id' or 'knowledge_ids' is required for delete."}],
            is_error=True,
        )

    with get_db() as db:
        for kid in ids_to_delete:
            error = _delete_single_item(db, kid)
            if error:
                return ToolOutput(
                    content=[{"type": "text", "text": error}],
                    is_error=True,
                )

    deleted = ", ".join(f"'{k}'" for k in ids_to_delete)
    noun = "item" if len(ids_to_delete) == 1 else "items"
    return ToolOutput(
        content=[{"type": "text", "text": f"Deleted knowledge {noun} {deleted}."}],
    )


def _handle_create_tag(input: KnowledgeInput) -> ToolOutput:
    if not input.tag_name:
        return ToolOutput(
            content=[{"type": "text", "text": "Error: 'tag_name' is required for create_tag."}],
            is_error=True,
        )

    with get_db() as db:
        existing = db.execute(
            select(DBTag).where(DBTag.name == input.tag_name)
        ).scalar_one_or_none()
        if existing:
            return ToolOutput(
                content=[{"type": "text", "text": f"Error: Tag '{input.tag_name}' already exists."}],
                is_error=True,
            )

        tag = DBTag(name=input.tag_name)
        db.add(tag)
        db.flush()
        result = {"id": tag.id, "name": tag.name, "created_at": tag.created_at.isoformat()}

    return ToolOutput(
        content=[{"type": "text", "text": json.dumps(result, indent=2)}],
    )


def _handle_delete_tag(input: KnowledgeInput) -> ToolOutput:
    if not input.tag_id:
        return ToolOutput(
            content=[{"type": "text", "text": "Error: 'tag_id' is required for delete_tag."}],
            is_error=True,
        )

    with get_db() as db:
        tag = db.execute(
            select(DBTag).where(DBTag.id == input.tag_id)
        ).scalar_one_or_none()
        if not tag:
            return ToolOutput(
                content=[{"type": "text", "text": f"Error: Tag '{input.tag_id}' not found."}],
                is_error=True,
            )

        from sqlalchemy import delete as sa_delete
        db.execute(sa_delete(DBKnowledgeTag).where(DBKnowledgeTag.tag_id == tag.id))
        db.delete(tag)

    return ToolOutput(
        content=[{"type": "text", "text": f"Deleted tag '{input.tag_id}'."}],
    )


def _handle_link(input: KnowledgeInput) -> ToolOutput:
    if not input.source_id or not input.target_id or not input.relation_type:
        return ToolOutput(
            content=[{"type": "text", "text": "Error: 'source_id', 'target_id', and 'relation_type' are required for link."}],
            is_error=True,
        )
    if input.source_id == input.target_id:
        return ToolOutput(
            content=[{"type": "text", "text": "Error: Cannot link a knowledge item to itself."}],
            is_error=True,
        )

    with get_db() as db:
        for kid in [input.source_id, input.target_id]:
            item = db.execute(
                select(DBKnowledge).where(DBKnowledge.id == kid)
            ).scalar_one_or_none()
            if not item:
                return ToolOutput(
                    content=[{"type": "text", "text": f"Error: Knowledge item '{kid}' not found."}],
                    is_error=True,
                )

        existing = db.execute(
            select(DBKnowledgeRelationship).where(
                DBKnowledgeRelationship.source_id == input.source_id,
                DBKnowledgeRelationship.target_id == input.target_id,
                DBKnowledgeRelationship.relation_type == input.relation_type,
            )
        ).scalar_one_or_none()
        if existing:
            return ToolOutput(
                content=[{"type": "text", "text": "Error: Relationship already exists."}],
                is_error=True,
            )

        rel = DBKnowledgeRelationship(
            source_id=input.source_id,
            target_id=input.target_id,
            relation_type=input.relation_type,
        )
        db.add(rel)
        db.flush()

        result = {
            "id": rel.id,
            "source_id": rel.source_id,
            "target_id": rel.target_id,
            "relation_type": rel.relation_type,
            "created_at": rel.created_at.isoformat(),
        }

    return ToolOutput(
        content=[{"type": "text", "text": json.dumps(result, indent=2)}],
    )


def _handle_unlink(input: KnowledgeInput) -> ToolOutput:
    if not input.relationship_id:
        return ToolOutput(
            content=[{"type": "text", "text": "Error: 'relationship_id' is required for unlink."}],
            is_error=True,
        )

    with get_db() as db:
        rel = db.execute(
            select(DBKnowledgeRelationship).where(DBKnowledgeRelationship.id == input.relationship_id)
        ).scalar_one_or_none()

        if not rel:
            return ToolOutput(
                content=[{"type": "text", "text": f"Error: Relationship '{input.relationship_id}' not found."}],
                is_error=True,
            )

        db.delete(rel)

    return ToolOutput(
        content=[{"type": "text", "text": f"Deleted relationship '{input.relationship_id}'."}],
    )


def run_knowledge(input: KnowledgeInput, session: Session) -> ToolOutput:
    match input.command:
        case "create":
            return _handle_create(input, session.id)
        case "search":
            return _handle_search(input)
        case "list_tags":
            return _handle_list_tags()
        case "delete":
            return _handle_delete(input)
        case "link":
            return _handle_link(input)
        case "unlink":
            return _handle_unlink(input)
        case "create_tag":
            return _handle_create_tag(input)
        case "delete_tag":
            return _handle_delete_tag(input)


KnowledgeTool = Tool(
    id="knowledge",
    name="Knowledge",
    description="Persistent knowledge graph. Commands: create, search, list_tags, delete, link, unlink, create_tag, delete_tag.",
    strict=False,
    input=KnowledgeInput,
    call_tool=run_knowledge,
)
