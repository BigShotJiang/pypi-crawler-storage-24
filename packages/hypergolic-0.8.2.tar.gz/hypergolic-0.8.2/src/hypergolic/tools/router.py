from fastapi import APIRouter
from sqlalchemy import select, delete as sa_delete

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBToolAutoApproval
from hypergolic.tools.approval import AlwaysApproveMode, save_auto_approval

from pydantic import BaseModel
from typing import Any

router = APIRouter(prefix="/api/tools", tags=["tools"])


class AutoApprovalRuleResponse(BaseModel):
    id: str
    tool_name: str
    tool_input_hash: str | None
    tool_input_snapshot: dict[str, Any] | None
    created_at: str


class CreateAutoApprovalRequest(BaseModel):
    tool_name: str
    mode: AlwaysApproveMode
    tool_input: dict[str, Any] = {}


@router.get("/auto-approvals", response_model=list[AutoApprovalRuleResponse])
def list_auto_approvals(tool_name: str | None = None):
    with get_db() as db:
        query = select(DBToolAutoApproval).order_by(DBToolAutoApproval.created_at.desc())
        if tool_name:
            query = query.where(DBToolAutoApproval.tool_name == tool_name)
        rows = db.execute(query).scalars().all()
        return [
            AutoApprovalRuleResponse(
                id=r.id,
                tool_name=r.tool_name,
                tool_input_hash=r.tool_input_hash,
                tool_input_snapshot=r.tool_input_snapshot,
                created_at=r.created_at.isoformat(),
            )
            for r in rows
        ]


@router.post("/auto-approvals", response_model=AutoApprovalRuleResponse)
def create_auto_approval(req: CreateAutoApprovalRequest):
    rule = save_auto_approval(req.tool_name, req.mode, req.tool_input)
    return AutoApprovalRuleResponse(
        id=rule.id,
        tool_name=rule.tool_name,
        tool_input_hash=rule.tool_input_hash,
        tool_input_snapshot=rule.tool_input_snapshot,
        created_at=rule.created_at.isoformat(),
    )


@router.delete("/auto-approvals/{rule_id}")
def delete_auto_approval(rule_id: str):
    with get_db() as db:
        db.execute(
            sa_delete(DBToolAutoApproval).where(DBToolAutoApproval.id == rule_id)
        )
    return {"status": "deleted"}
