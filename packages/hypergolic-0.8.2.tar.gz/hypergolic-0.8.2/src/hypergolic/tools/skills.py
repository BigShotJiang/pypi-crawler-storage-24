from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput


def _handle_skills(inp: BaseModel, session: Session) -> ToolOutput:
    from hypergolic.skills.resolver import get_skill_prompt_content
    from hypergolic.db.engine import get_db
    from hypergolic.db.models import DBSessionSkill
    from sqlalchemy import select

    skill_id = inp.skill_id  # type: ignore[attr-defined]
    project_path = session.working_directory()

    with get_db() as db:
        already_active = db.execute(
            select(DBSessionSkill)
            .where(DBSessionSkill.session_id == session.id)
            .where(DBSessionSkill.skill_id == skill_id)
        ).scalar_one_or_none()
        if already_active:
            return ToolOutput(
                content=[{"type": "text", "text": f"Skill '{skill_id}' is already active."}],
            )

    result = get_skill_prompt_content(skill_id, project_path)
    if result is None:
        return ToolOutput(
            content=[{"type": "text", "text": f"Skill '{skill_id}' not found."}],
            is_error=True,
        )

    skill_name, prompt_content = result

    with get_db() as db:
        db.add(DBSessionSkill(
            session_id=session.id,
            skill_id=skill_id,
        ))

    return ToolOutput(
        content=[{"type": "text", "text": f"Skill Added: {skill_name}\n\n{prompt_content}"}],
    )


def _build_skills_description(skills: list[dict[str, Any]]) -> str:
    desc = (
        "Activate a skill to gain specialized expertise for the current session.\n\n"
        "Available skills:\n"
    )
    for skill in skills:
        desc += f"- `{skill['id']}`: {skill['description']}\n"
    return desc.rstrip()


def build_skills_tool(project_path: Path | None = None) -> Tool | None:
    from hypergolic.skills.resolver import resolve_skills

    skills = resolve_skills(project_path)
    if not skills:
        return None

    skill_ids = [s["id"] for s in skills]
    SkillIdEnum = Enum("SkillIdEnum", {sid: sid for sid in skill_ids}, type=str)

    class SkillsInput(BaseModel):
        skill_id: SkillIdEnum

    return Tool(
        id="skills",
        name="Skills",
        description=_build_skills_description(skills),
        strict=False,
        input=SkillsInput,
        call_tool=_handle_skills,
    )
