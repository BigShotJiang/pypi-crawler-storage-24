from pathlib import Path

from pydantic import BaseModel, Field

from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput


class DeleteFilesInput(BaseModel):
    paths: list[str] = Field(
        description="File paths to delete.",
    )


def delete_files(input: DeleteFilesInput, session: Session) -> ToolOutput:
    results = []
    has_error = False

    for file_path in input.paths:
        p = Path(file_path).expanduser()
        if not p.is_absolute():
            p = session.working_directory() / p
        path = p
        try:
            if not path.exists():
                results.append({"type": "text", "text": f"File not found: {file_path}"})
                has_error = True
            elif path.is_dir():
                results.append({"type": "text", "text": f"Is a directory (use rmdir instead): {file_path}"})
                has_error = True
            else:
                path.unlink()
                results.append({"type": "text", "text": f"Deleted {file_path}"})
        except PermissionError:
            results.append({"type": "text", "text": f"Permission denied: {file_path}"})
            has_error = True
        except Exception as e:
            results.append({"type": "text", "text": f"Error deleting {file_path}: {e}"})
            has_error = True

    if not results:
        return ToolOutput(content=[{"type": "text", "text": "No file paths provided."}])

    return ToolOutput(content=results, is_error=has_error)


DeleteFilesTool = Tool(
    id="delete_files",
    name="Delete Files",
    description="Delete files by path.",
    strict=True,
    input=DeleteFilesInput,
    call_tool=delete_files,
)
