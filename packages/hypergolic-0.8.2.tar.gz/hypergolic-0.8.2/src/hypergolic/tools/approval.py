import hashlib
import json
from enum import Enum
from typing import Any

from sqlalchemy import select

from hypergolic.config.settings import settings
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBToolAutoApproval


class ApprovalRequirement(str, Enum):
    ALWAYS_ALLOW = "always_allow"
    REQUIRES_APPROVAL = "requires_approval"


class AlwaysApproveMode(str, Enum):
    WITH_PARAMS = "with_params"
    ANY_PARAMS = "any_params"


BUILTIN_TOOLS_REQUIRING_APPROVAL = {"command", "browser"}

BUILTIN_TOOLS_CONDITIONAL_APPROVAL: dict[str, set[str]] = {
    "git": {"status", "diff", "log", "show", "branch_list", "stash_list"},
}


def _custom_tools_requiring_approval() -> set[str]:
    ids: set[str] = set()
    for config in settings.user_config.tools:
        if config.requires_approval:
            ids.add(config.id)
    for project_config in settings.user_config.projects:
        for config in project_config.tools:
            if config.requires_approval:
                ids.add(config.id)
    for config in settings.project_config.tools:
        if config.requires_approval:
            ids.add(config.id)
    return ids


def get_approval_requirement(
    tool_id: str, tool_input: dict[str, Any] | None = None,
) -> ApprovalRequirement:
    if tool_id in BUILTIN_TOOLS_CONDITIONAL_APPROVAL:
        allowed_commands = BUILTIN_TOOLS_CONDITIONAL_APPROVAL[tool_id]
        command = (tool_input or {}).get("command", "")
        if command in allowed_commands:
            return ApprovalRequirement.ALWAYS_ALLOW
        return ApprovalRequirement.REQUIRES_APPROVAL
    if tool_id in BUILTIN_TOOLS_REQUIRING_APPROVAL:
        return ApprovalRequirement.REQUIRES_APPROVAL
    if tool_id in _custom_tools_requiring_approval():
        return ApprovalRequirement.REQUIRES_APPROVAL
    if tool_id.startswith("mcp_"):
        return ApprovalRequirement.REQUIRES_APPROVAL
    return ApprovalRequirement.ALWAYS_ALLOW


def _hash_tool_input(tool_input: dict[str, Any]) -> str:
    canonical = json.dumps(tool_input, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode()).hexdigest()


def check_auto_approval(tool_name: str, tool_input: dict[str, Any]) -> bool:
    input_hash = _hash_tool_input(tool_input)
    with get_db() as db:
        row = db.execute(
            select(DBToolAutoApproval).where(
                DBToolAutoApproval.tool_name == tool_name,
                (DBToolAutoApproval.tool_input_hash == None) | (DBToolAutoApproval.tool_input_hash == input_hash),  # noqa: E711
            )
        ).scalars().first()
        return row is not None


def save_auto_approval(
    tool_name: str, mode: AlwaysApproveMode, tool_input: dict[str, Any]
) -> DBToolAutoApproval:
    input_hash = _hash_tool_input(tool_input) if mode == AlwaysApproveMode.WITH_PARAMS else None
    snapshot = tool_input if mode == AlwaysApproveMode.WITH_PARAMS else None

    with get_db() as db:
        existing = db.execute(
            select(DBToolAutoApproval).where(
                DBToolAutoApproval.tool_name == tool_name,
                DBToolAutoApproval.tool_input_hash == input_hash,
            )
        ).scalars().first()
        if existing:
            return existing

        rule = DBToolAutoApproval(
            tool_name=tool_name,
            tool_input_hash=input_hash,
            tool_input_snapshot=snapshot,
        )
        db.add(rule)
        db.flush()
        return rule
