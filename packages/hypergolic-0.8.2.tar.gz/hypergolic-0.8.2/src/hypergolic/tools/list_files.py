import subprocess
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field

from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput


class ListFilesInput(BaseModel):
    directory: str = Field(
        description="Directory to list.",
    )
    pattern: Optional[str] = Field(
        default=None,
        description="Glob pattern to filter files.",
    )
    max_depth: Optional[int] = Field(
        default=None,
        description="Max depth to traverse.",
    )
    include_hidden: bool = Field(
        default=False,
        description="Include hidden files/directories.",
    )


def _resolve_path(path: str, session: Session) -> str:
    p = Path(path).expanduser()
    if not p.is_absolute():
        p = session.working_directory() / p
    return str(p)


def list_files(input: ListFilesInput, session: Session) -> ToolOutput:
    cmd = ["rg", "--files"]

    if input.max_depth is not None:
        cmd.extend(["--max-depth", str(input.max_depth)])

    if input.include_hidden:
        cmd.append("--hidden")

    if input.pattern:
        cmd.extend(["-g", input.pattern])

    cmd.append(_resolve_path(input.directory, session))

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
        )

        if result.returncode != 0 and result.stderr:
            if "No files were searched" in result.stderr:
                return ToolOutput(
                    content=[{"type": "text", "text": "No files found matching the criteria."}],
                )
            return ToolOutput(
                content=[{"type": "text", "text": f"Error listing files: {result.stderr}"}],
                is_error=True,
            )

        files = result.stdout.strip().split("\n") if result.stdout.strip() else []

        if not files:
            return ToolOutput(
                content=[{"type": "text", "text": "No files found in the specified directory."}],
            )

        file_list = "\n".join(files)
        return ToolOutput(content=[{"type": "text", "text": file_list}])

    except Exception as e:
        return ToolOutput(
            content=[{"type": "text", "text": f"Error listing files: {str(e)}"}],
            is_error=True,
        )


ListFilesTool = Tool(
    id="list_files",
    name="List Files",
    description="List files in a directory.",
    strict=True,
    input=ListFilesInput,
    call_tool=list_files,
)
