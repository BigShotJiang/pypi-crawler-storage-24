import asyncio
import logging
from typing import Any

from anthropic.types import MessageParam
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession
from hypergolic.messages import BroadcastEvent, UserInterrupt, create_message
from hypergolic.providers import create_client
from hypergolic.schemas import Session
from hypergolic.sessions import create_session
from hypergolic.tools.handlers import ApprovalRequest, ApprovalResponse, UserQuestionRequest, UserQuestionResponse
from hypergolic.websocket.helpers import (
    build_content_blocks,
    format_error_detail,
    load_session_messages,
    persist_error_message,
    serialize_event,
)
from hypergolic.websocket.schemas import (
    ApprovalResponseMessage,
    ConnectMessage,
    TruncateRequestMessage,
    UserQuestionResponseMessage,
    parse_client_message,
)

logger = logging.getLogger(__name__)

router = APIRouter()

_client = None


def get_client():
    global _client
    if _client is None:
        _client = create_client()
    return _client


@router.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    current_task: asyncio.Task[Any] | None = None
    cancel_event: asyncio.Event = asyncio.Event()
    pending_approvals: dict[str, asyncio.Future[ApprovalResponse]] = {}
    pending_questions: dict[str, asyncio.Future[UserQuestionResponse]] = {}

    async def _run_turn(request: ConnectMessage) -> None:
        nonlocal cancel_event
        cancel_event = asyncio.Event()
        client = get_client()
        session_id: str | None = None

        try:
            if request.session_id:
                with get_db() as db:
                    from hypergolic.db.models import DBProject
                    row = db.execute(
                        select(DBSession, DBProject.path)
                        .join(DBProject, DBSession.project_id == DBProject.id)
                        .where(DBSession.id == request.session_id)
                    ).one()
                    db_session, project_path = row
                    session = Session(
                        id=db_session.id,
                        model_tier=db_session.model_tier,
                        project_id=db_session.project_id,
                        project_path=project_path,
                        role=db_session.role,
                    )
                history = load_session_messages(session.id)
            else:
                if not request.project_id:
                    raise ValueError("project_id is required to create a new session")
                session = create_session(project_id=request.project_id, model_tier=request.model_tier)
                history = []

            session_id = session.id

            async def broadcast(event: BroadcastEvent) -> None:
                await ws.send_json(serialize_event(event))

            async def approval_callback(req: ApprovalRequest) -> ApprovalResponse:
                await ws.send_json({
                    "type": "tool_approval_request",
                    "tool_use_id": req.tool_use_id,
                    "tool_name": req.tool_name,
                    "tool_input": req.tool_input,
                    "session_id": session_id,
                })

                loop = asyncio.get_event_loop()
                future: asyncio.Future[ApprovalResponse] = loop.create_future()
                pending_approvals[req.tool_use_id] = future

                try:
                    return await future
                finally:
                    pending_approvals.pop(req.tool_use_id, None)

            async def user_question_callback(req: UserQuestionRequest) -> UserQuestionResponse:
                await ws.send_json({
                    "type": "user_question_request",
                    "tool_use_id": req.tool_use_id,
                    "question": req.question,
                    "options": req.options,
                    "session_id": session_id,
                })

                loop = asyncio.get_event_loop()
                future: asyncio.Future[UserQuestionResponse] = loop.create_future()
                pending_questions[req.tool_use_id] = future

                try:
                    return await future
                finally:
                    pending_questions.pop(req.tool_use_id, None)

            content_blocks = build_content_blocks(request)
            user_message: MessageParam = {
                "role": "user",
                "content": content_blocks,
            }

            await create_message(
                client=client,
                session=session,
                message=user_message,
                broadcast=broadcast,
                history=history,
                cancel_event=cancel_event,
                approval_callback=approval_callback,
                user_question_callback=user_question_callback,
            )

            await ws.send_json({"type": "done", "session_id": session.id})
        except UserInterrupt as ui:
            try:
                payload: dict[str, Any] = {"type": "interrupted", "session_id": session_id}
                if ui.partial_text:
                    payload["partial_text"] = ui.partial_text
                await ws.send_json(payload)
            except Exception:
                logger.warning("Failed to send interrupt payload to WebSocket", exc_info=True)
        except Exception as exc:
            logger.error("Error during WebSocket turn", exc_info=True)
            detail = format_error_detail(exc)
            if session_id:
                persist_error_message(session_id, detail)
            try:
                await ws.send_json({"type": "error", "detail": detail, "session_id": session_id})
            except Exception:
                logger.warning("Failed to send error payload to WebSocket", exc_info=True)

    try:
        while True:
            raw = await ws.receive_json()
            msg = parse_client_message(raw)

            if isinstance(msg, ApprovalResponseMessage):
                future = pending_approvals.get(msg.tool_use_id)
                if future and not future.done():
                    future.set_result(ApprovalResponse(
                        approved=msg.approved,
                        denial_reason=msg.denial_reason,
                        always_approve=msg.always_approve,
                    ))
                continue

            if isinstance(msg, UserQuestionResponseMessage):
                q_future = pending_questions.get(msg.tool_use_id)
                if q_future and not q_future.done():
                    q_future.set_result(UserQuestionResponse(
                        response=msg.response,
                    ))
                continue

            if isinstance(msg, TruncateRequestMessage):
                # Cancel any in-progress turn first
                if current_task and not current_task.done():
                    cancel_event.set()
                    for fut in pending_approvals.values():
                        if not fut.done():
                            fut.cancel()
                    pending_approvals.clear()
                    for fut in pending_questions.values():
                        if not fut.done():
                            fut.cancel()
                    pending_questions.clear()
                    try:
                        await asyncio.wait_for(current_task, timeout=2.0)
                    except (asyncio.TimeoutError, Exception):
                        current_task.cancel()
                        try:
                            await current_task
                        except (asyncio.CancelledError, Exception):
                            pass

                async def _run_truncation(truncate_msg: TruncateRequestMessage) -> None:
                    try:
                        from hypergolic.truncation import perform_truncation, resolve_truncation_config
                        session_id = truncate_msg.session_id
                        with get_db() as db:
                            from hypergolic.db.models import DBProject
                            row = db.execute(
                                select(DBSession, DBProject.path)
                                .join(DBProject, DBSession.project_id == DBProject.id)
                                .where(DBSession.id == session_id)
                            ).one()
                            db_session, project_path = row
                            session = Session(
                                id=db_session.id,
                                model_tier=db_session.model_tier,
                                project_id=db_session.project_id,
                                project_path=project_path,
                                role=db_session.role,
                            )

                        config = resolve_truncation_config(session)
                        messages = load_session_messages(session.id)

                        if not messages:
                            await ws.send_json({"type": "truncation_failed", "session_id": session_id})
                            return

                        await ws.send_json({"type": "truncation_start", "session_id": session_id})

                        client = get_client()
                        summary = await perform_truncation(client, session, messages, config)
                        if summary:
                            await ws.send_json({"type": "truncation_complete", "session_id": session_id})
                            summary_text = summary["content"][0]["text"]  # type: ignore[index]
                            continuation = ConnectMessage(
                                type="chat",
                                message=summary_text,
                                model_tier=session.model_tier,
                                session_id=session.id,
                            )
                            await _run_turn(continuation)
                        else:
                            await ws.send_json({"type": "truncation_failed", "session_id": session_id})
                    except Exception as exc:
                        logger.error("Error during manual truncation", exc_info=True)
                        try:
                            await ws.send_json({
                                "type": "truncation_failed",
                                "session_id": truncate_msg.session_id,
                                "detail": str(exc),
                            })
                        except Exception:
                            pass

                current_task = asyncio.create_task(_run_truncation(msg))
                continue

            request = msg

            if current_task and not current_task.done():
                cancel_event.set()
                for fut in pending_approvals.values():
                    if not fut.done():
                        fut.cancel()
                pending_approvals.clear()
                for fut in pending_questions.values():
                    if not fut.done():
                        fut.cancel()
                pending_questions.clear()
                try:
                    await asyncio.wait_for(current_task, timeout=0.5)
                except (asyncio.TimeoutError, Exception):
                    current_task.cancel()
                    try:
                        await current_task
                    except (asyncio.CancelledError, Exception):
                        logger.debug("Previous task cancelled during new turn", exc_info=True)

            current_task = asyncio.create_task(_run_turn(request))
    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected")
    except Exception:
        logger.error("Unexpected WebSocket error", exc_info=True)
    finally:
        for fut in pending_approvals.values():
            if not fut.done():
                fut.cancel()
        pending_approvals.clear()
        for fut in pending_questions.values():
            if not fut.done():
                fut.cancel()
        pending_questions.clear()
        if current_task and not current_task.done():
            cancel_event.set()
            current_task.cancel()
            try:
                await current_task
            except (asyncio.CancelledError, Exception):
                logger.debug("Task cancelled during WebSocket cleanup", exc_info=True)
        try:
            await ws.close()
        except Exception:
            logger.debug("Failed to close WebSocket cleanly", exc_info=True)
