import logging
from typing import Any, cast, Literal

from anthropic.types import MessageParam, TextBlockParam, ImageBlockParam
from pydantic import BaseModel
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage
from hypergolic.messages import BroadcastEvent
from hypergolic.websocket.schemas import ConnectMessage

logger = logging.getLogger(__name__)

EXCLUDED_CONTENT_FIELDS = {"parsed_output", "caller"}


def serialize_event(event: BroadcastEvent) -> dict[str, Any]:
    content = []
    for block in event.content:
        if isinstance(block, BaseModel):
            content.append(block.model_dump(mode="json"))
        elif isinstance(block, dict):
            content.append(block)
        else:
            content.append(str(block))

    payload: dict[str, Any] = {
        "type": event.type,
        "role": event.role,
        "content": content,
    }
    if event.session_id:
        payload["session_id"] = event.session_id
    if event.model:
        payload["model"] = event.model
    if event.stop_reason:
        payload["stop_reason"] = event.stop_reason
    if event.message_id:
        payload["message_id"] = event.message_id
    if event.usage:
        payload["usage"] = event.usage
    return payload


def strip_excluded_fields(content: list[Any]) -> list[Any]:
    cleaned = []
    for block in content:
        if isinstance(block, dict):
            cleaned.append({k: v for k, v in block.items() if k not in EXCLUDED_CONTENT_FIELDS})
        else:
            cleaned.append(block)
    return cleaned


def load_session_messages(session_id: str) -> list[MessageParam]:
    with get_db() as db:
        rows = db.execute(
            select(DBMessage)
            .where(DBMessage.session_id == session_id)
            .where(DBMessage.truncated == False)  # noqa: E712
            .order_by(DBMessage.created_at)
        ).scalars().all()
        return [
            MessageParam(
                role=cast(Literal["user", "assistant"], row.role),
                content=strip_excluded_fields(row.content),
            )
            for row in rows
        ]


def build_content_blocks(
    request: ConnectMessage,
) -> list[TextBlockParam | ImageBlockParam]:
    blocks: list[TextBlockParam | ImageBlockParam] = []
    if request.content_blocks:
        for raw_block in request.content_blocks:
            if raw_block.get("type") == "image" and "source" in raw_block:
                blocks.append(ImageBlockParam(type="image", source=raw_block["source"]))
            elif raw_block.get("type") == "text" and "text" in raw_block:
                blocks.append(TextBlockParam(type="text", text=raw_block["text"]))
    blocks.append(TextBlockParam(type="text", text=request.message))
    return blocks


def persist_error_message(session_id: str, detail: str) -> None:
    with get_db() as db:
        db.add(DBMessage(
            session_id=session_id,
            content=[{"type": "text", "text": detail}],
            model=None,
            role="assistant",
            stop_reason="error",
            stop_sequence=None,
            usage=None,
        ))


def format_error_detail(exc: Exception) -> str:
    from anthropic import APIConnectionError, APIStatusError
    if isinstance(exc, APIConnectionError):
        return f"Lost connection to AI provider: {exc}"
    if isinstance(exc, APIStatusError):
        return f"AI provider error (HTTP {exc.status_code}): {exc.message}"
    return str(exc)
