import asyncio
import logging
from pathlib import Path

from anthropic import AsyncAnthropic, APIConnectionError, APIStatusError
from anthropic.types import MessageParam, TextBlockParam
from sqlalchemy import select, update

from hypergolic.config.schemas import TruncationConfig
from hypergolic.config.settings import load_project_config, load_user_project_config, settings
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage
from hypergolic.enums import ModelTier
from hypergolic.providers import tier_to_model_id
from hypergolic.schemas import Session

logger = logging.getLogger(__name__)

RETRY_BASE_DELAY = 1.0


def resolve_truncation_config(session: Session) -> TruncationConfig:
    project_config = load_project_config(session.working_directory())
    user_project_config = load_user_project_config(session.working_directory())
    user_config = settings.user_config

    base = user_config.truncation
    merged = base.model_copy()

    if user_project_config and user_project_config.truncation != TruncationConfig():
        up = user_project_config.truncation
        merged = up.model_copy()

    if project_config.truncation != TruncationConfig():
        p = project_config.truncation
        merged = p.model_copy()

    return merged


def should_truncate(last_usage: dict | None, threshold: int) -> bool:
    if not last_usage:
        return False
    input_tokens = last_usage.get("input_tokens", 0)
    cache_read = last_usage.get("cache_read_input_tokens", 0)
    cache_creation = last_usage.get("cache_creation_input_tokens", 0)
    total_context = input_tokens + cache_read + cache_creation
    return total_context >= threshold


def _build_truncation_prompt_blocks(session: Session, config: TruncationConfig) -> list[TextBlockParam]:
    blocks: list[TextBlockParam] = []

    from hypergolic.prompts.builder import build_prompt_blocks
    session_prompt_blocks = build_prompt_blocks(session)
    for block in session_prompt_blocks:
        blocks.append(block.to_text_block())

    base_truncation_path = Path(__file__).parent / "prompts" / "truncation_prompt.md"
    if base_truncation_path.exists():
        blocks.append({"type": "text", "text": base_truncation_path.read_text()})

    user_truncation_path = Path.home() / ".agents" / "TRUNCATION_PROMPT.md"
    if user_truncation_path.exists():
        blocks.append({
            "type": "text",
            "text": f"# User Truncation Guidance\n\n{user_truncation_path.read_text()}",
        })

    project_path = session.working_directory()
    project_truncation_path = project_path / ".agents" / "TRUNCATION_PROMPT.md"
    if project_truncation_path.exists():
        blocks.append({
            "type": "text",
            "text": f"# Project Truncation Guidance\n\n{project_truncation_path.read_text()}",
        })

    if config.prompt_path:
        custom_path = Path(config.prompt_path).expanduser()
        if custom_path.exists():
            blocks.append({
                "type": "text",
                "text": f"# Custom Truncation Guidance\n\n{custom_path.read_text()}",
            })

    return blocks


def _tier_from_string(tier_str: str) -> ModelTier:
    return ModelTier(tier_str)


async def perform_truncation(
    client: AsyncAnthropic,
    session: Session,
    messages: list[MessageParam],
    config: TruncationConfig,
) -> MessageParam | None:
    if not messages:
        return None

    prompt_blocks = _build_truncation_prompt_blocks(session, config)
    model_tier = _tier_from_string(config.model_tier)
    model_id = tier_to_model_id(model_tier)

    max_attempts = 1 + config.max_retries
    last_error: Exception | None = None

    for attempt in range(max_attempts):
        try:
            truncation_messages = list(messages)
            if truncation_messages and truncation_messages[-1]["role"] == "assistant":
                truncation_messages.append({
                    "role": "user",
                    "content": [{"type": "text", "text": "Please summarize this conversation now."}],
                })

            response = await client.messages.create(
                max_tokens=8192,
                model=model_id,
                messages=truncation_messages,
                system=prompt_blocks,
            )

            summary_text = ""
            for block in response.content:
                if getattr(block, "type", None) == "text":
                    summary_text += getattr(block, "text", "")

            if not summary_text.strip():
                logger.error("Truncation agent returned empty summary")
                return None

            _persist_truncation(
                session_id=session.id,
                summary_text=summary_text,
                truncation_usage=response.usage.model_dump(mode="json") if response.usage else None,
                truncation_model=response.model,
            )

            summary_message: MessageParam = {
                "role": "user",
                "content": [{"type": "text", "text": summary_text}],
            }
            return summary_message

        except (APIConnectionError, APIStatusError) as exc:
            last_error = exc
            if attempt < max_attempts - 1:
                delay = RETRY_BASE_DELAY * (2 ** attempt)
                logger.warning(
                    "Truncation attempt %d failed (%s), retrying in %.1fs",
                    attempt + 1, exc, delay,
                )
                await asyncio.sleep(delay)
            else:
                logger.error("Truncation failed after %d attempts: %s", max_attempts, exc)
        except Exception as exc:
            logger.error("Unexpected error during truncation: %s", exc, exc_info=True)
            last_error = exc
            break

    if last_error:
        logger.error("Truncation abandoned, continuing with full context")
    return None


def _persist_truncation(
    session_id: str,
    summary_text: str,
    truncation_usage: dict | None,
    truncation_model: str | None,
) -> None:
    with get_db() as db:
        db.execute(
            update(DBMessage)
            .where(DBMessage.session_id == session_id)
            .where(DBMessage.truncated == False)  # noqa: E712
            .values(truncated=True)
        )

        truncation_agent_msg = DBMessage(
            session_id=session_id,
            content=[{"type": "text", "text": summary_text}],
            model=truncation_model,
            role="assistant",
            stop_reason="truncation",
            stop_sequence=None,
            usage=truncation_usage,
            truncated=True,
        )
        db.add(truncation_agent_msg)


def persist_truncation_summary(session_id: str, summary_text: str) -> None:
    with get_db() as db:
        summary_msg = DBMessage(
            session_id=session_id,
            content=[{"type": "text", "text": summary_text}],
            model=None,
            role="user",
            stop_reason=None,
            stop_sequence=None,
            usage=None,
            truncated=False,
        )
        db.add(summary_msg)


def get_last_assistant_usage(session_id: str) -> dict | None:
    with get_db() as db:
        msg = db.execute(
            select(DBMessage)
            .where(DBMessage.session_id == session_id)
            .where(DBMessage.role == "assistant")
            .where(DBMessage.usage.isnot(None))
            .order_by(DBMessage.created_at.desc())
            .limit(1)
        ).scalar_one_or_none()
        if msg and msg.usage:
            return msg.usage
        return None
