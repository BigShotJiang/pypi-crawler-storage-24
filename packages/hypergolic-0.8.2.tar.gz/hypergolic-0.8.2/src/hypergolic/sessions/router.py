from fastapi import APIRouter
from sqlalchemy import select, delete as sa_delete

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession, DBMessage, DBProject, DBSessionSkill
from hypergolic.schemas import Session
from hypergolic.sessions.operations import create_session
from hypergolic.sessions.schemas import (
    CreateSessionRequest,
    MessageResponse,
    PromptPartInfo,
    RoleInfo,
    SessionResponse,
    SkillInfo,
    TruncationResponse,
    ToolInfo,
)

router = APIRouter(prefix="/api/sessions", tags=["sessions"])


def _session_response(row: DBSession, project_name: str) -> SessionResponse:
    return SessionResponse(
        id=row.id,
        model_tier=row.model_tier,
        project_id=row.project_id,
        project_name=project_name,
        role=row.role,
        created_at=row.created_at.isoformat(),
        updated_at=row.updated_at.isoformat(),
    )


@router.get("", response_model=list[SessionResponse])
def list_sessions(project_id: str | None = None):
    with get_db() as db:
        stmt = (
            select(DBSession, DBProject.name)
            .join(DBProject, DBSession.project_id == DBProject.id)
            .order_by(DBSession.created_at.desc())
        )
        if project_id:
            stmt = stmt.where(DBSession.project_id == project_id)
        rows = db.execute(stmt).all()
        return [
            _session_response(session, project_name)
            for session, project_name in rows
        ]


@router.post("", response_model=SessionResponse)
def create_session_endpoint(req: CreateSessionRequest):
    session = create_session(project_id=req.project_id, model_tier=req.model_tier, role=req.role)
    with get_db() as db:
        row = db.execute(
            select(DBSession, DBProject.name)
            .join(DBProject, DBSession.project_id == DBProject.id)
            .where(DBSession.id == session.id)
        ).one()
        return _session_response(row[0], row[1])


@router.get("/roles", response_model=list[RoleInfo])
def list_roles(project_id: str | None = None):
    from pathlib import Path
    from hypergolic.skills.resolver import resolve_roles

    project_path: Path | None = None
    if project_id:
        with get_db() as db:
            project = db.execute(
                select(DBProject).where(DBProject.id == project_id)
            ).scalar_one_or_none()
            if project:
                project_path = Path(project.path)

    roles = resolve_roles(project_path)
    return [RoleInfo(id=r["id"], name=r["name"], source=r["source"]) for r in roles]


@router.delete("/{session_id}")
def delete_session_endpoint(session_id: str):
    with get_db() as db:
        db.execute(
            sa_delete(DBSessionSkill).where(DBSessionSkill.session_id == session_id)
        )
        db.execute(
            sa_delete(DBMessage).where(DBMessage.session_id == session_id)
        )
        db.execute(
            sa_delete(DBSession).where(DBSession.id == session_id)
        )
    return {"status": "deleted"}


@router.get("/{session_id}/messages", response_model=list[MessageResponse])
def get_session_messages(session_id: str):
    with get_db() as db:
        rows = db.execute(
            select(DBMessage)
            .where(DBMessage.session_id == session_id)
            .order_by(DBMessage.created_at)
        ).scalars().all()
        return [
            MessageResponse(
                id=r.id,
                session_id=r.session_id,
                role=r.role,
                content=r.content,
                model=r.model,
                stop_reason=r.stop_reason,
                usage=r.usage,
                truncated=r.truncated,
                created_at=r.created_at.isoformat(),
            )
            for r in rows
        ]


@router.post("/{session_id}/truncate", response_model=TruncationResponse)
async def truncate_session(session_id: str):
    session = _load_session(session_id)

    from hypergolic.providers import create_client
    from hypergolic.truncation import perform_truncation, persist_truncation_summary, resolve_truncation_config
    from hypergolic.websocket.helpers import load_session_messages

    config = resolve_truncation_config(session)
    messages = load_session_messages(session.id)

    if not messages:
        return TruncationResponse(success=False, message="No messages to truncate")

    client = create_client()
    try:
        summary = await perform_truncation(client, session, messages, config)
        if summary:
            summary_text = summary["content"][0]["text"]  # type: ignore[index]
            persist_truncation_summary(session.id, summary_text)
            return TruncationResponse(success=True, message="Conversation truncated successfully")
        return TruncationResponse(success=False, message="Truncation failed after retries")
    finally:
        await client.close()


def _load_session(session_id: str) -> Session:
    with get_db() as db:
        row = db.execute(
            select(DBSession, DBProject.path)
            .join(DBProject, DBSession.project_id == DBProject.id)
            .where(DBSession.id == session_id)
        ).one()
        db_session, project_path = row
        return Session(
            id=db_session.id,
            model_tier=db_session.model_tier,
            project_id=db_session.project_id,
            project_path=project_path,
            role=db_session.role,
        )


@router.get("/{session_id}/tools", response_model=list[ToolInfo])
def get_session_tools(session_id: str):
    session = _load_session(session_id)

    from hypergolic.tools.tool_list import build_tools, get_tool_source
    from hypergolic.tools.approval import get_approval_requirement, ApprovalRequirement
    tools = build_tools(session=session)
    from hypergolic.mcp.tool_bridge import parse_mcp_tool_id
    result = []
    for t in tools:
        mcp_parsed = parse_mcp_tool_id(t.id)
        result.append(ToolInfo(
            id=t.id,
            name=t.name,
            description=t.description,
            source=get_tool_source(t.id),
            requires_approval=get_approval_requirement(t.id) == ApprovalRequirement.REQUIRES_APPROVAL,
            mcp_server=mcp_parsed[0] if mcp_parsed else None,
        ))
    return result


@router.get("/{session_id}/prompt", response_model=list[PromptPartInfo])
def get_session_prompt(session_id: str):
    session = _load_session(session_id)

    from hypergolic.prompts.builder import build_prompt_blocks
    blocks = build_prompt_blocks(session)

    return [
        PromptPartInfo(
            source=block.source,
            content=block.text,
            token_estimate=len(block.text) // 4,
        )
        for block in blocks
    ]


@router.get("/{session_id}/skills", response_model=list[SkillInfo])
def get_session_skills(session_id: str):
    from hypergolic.db.models import DBSessionSkill
    from hypergolic.skills.resolver import resolve_skills

    session = _load_session(session_id)
    project_path = session.working_directory()

    with get_db() as db:
        active_skill_ids = set(
            db.execute(
                select(DBSessionSkill.skill_id)
                .where(DBSessionSkill.session_id == session_id)
            ).scalars().all()
        )

    all_skills = resolve_skills(project_path)
    return [
        SkillInfo(
            id=s["id"],
            name=s["name"],
            description=s["description"],
            source=s["source"],
            active=s["id"] in active_skill_ids,
        )
        for s in all_skills
    ]

