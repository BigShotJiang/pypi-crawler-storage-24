from typing import Any

from pydantic import BaseModel, Field

from hypergolic.enums import ModelTier


class CreateSessionRequest(BaseModel):
    model_tier: ModelTier = Field(default=ModelTier.HIGH)
    project_id: str
    role: str = "default"


class SessionResponse(BaseModel):
    id: str
    model_tier: ModelTier
    project_id: str
    project_name: str
    role: str
    created_at: str
    updated_at: str


class MessageResponse(BaseModel):
    id: str
    session_id: str
    role: str
    content: list[Any]
    model: str | None = None
    stop_reason: str | None = None
    usage: dict[str, Any] | None = None
    truncated: bool = False
    created_at: str


class TruncationResponse(BaseModel):
    success: bool
    message: str


class ToolInfo(BaseModel):
    id: str
    name: str
    description: str
    source: str
    requires_approval: bool
    mcp_server: str | None = None


class PromptPartInfo(BaseModel):
    source: str
    content: str
    token_estimate: int



class RoleInfo(BaseModel):
    id: str
    name: str
    source: str


class SkillInfo(BaseModel):
    id: str
    name: str
    description: str
    source: str
    active: bool
