import subprocess
from pathlib import Path

from hypergolic.files.schemas import FileNode
from hypergolic.git import git_repo_root


def _git_status_map(repo_root: Path) -> dict[str, str]:
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain", "-uall"],
            capture_output=True,
            text=True,
            check=True,
            cwd=repo_root,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return {}

    status_map: dict[str, str] = {}
    for line in result.stdout.splitlines():
        if len(line) < 4:
            continue
        xy = line[:2]
        filepath = line[3:].strip()
        if " -> " in filepath:
            filepath = filepath.split(" -> ", 1)[1]
        status_map[filepath] = xy.strip()
    return status_map


def _git_ignored_set(repo_root: Path) -> set[str]:
    try:
        result = subprocess.run(
            ["git", "ls-files", "--others", "--ignored", "--exclude-standard", "--directory"],
            capture_output=True,
            text=True,
            check=True,
            cwd=repo_root,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return set()

    ignored: set[str] = set()
    for line in result.stdout.splitlines():
        entry = line.strip().rstrip("/")
        if entry:
            ignored.add(entry)
    return ignored


def _build_tree(
    directory: Path,
    repo_root: Path,
    status_map: dict[str, str],
    ignored_set: set[str],
) -> list[FileNode]:
    nodes: list[FileNode] = []
    try:
        entries = sorted(directory.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
    except PermissionError:
        return nodes

    for entry in entries:
        if entry.name.startswith("."):
            continue

        rel = str(entry.relative_to(repo_root))

        is_ignored = rel in ignored_set or any(
            rel.startswith(ign + "/") or rel == ign for ign in ignored_set
        )

        if entry.is_dir():
            if entry.name == "node_modules" or entry.name == "__pycache__":
                continue
            children = _build_tree(entry, repo_root, status_map, ignored_set)
            git_status = "ignored" if is_ignored else _dir_aggregate_status(rel, status_map)
            nodes.append(FileNode(
                name=entry.name,
                path=rel,
                is_dir=True,
                git_status=git_status,
                children=children,
            ))
        else:
            if is_ignored:
                git_status = "ignored"
            else:
                git_status = status_map.get(rel)
            nodes.append(FileNode(
                name=entry.name,
                path=rel,
                is_dir=False,
                git_status=git_status,
            ))

    return nodes


def _dir_aggregate_status(dir_rel: str, status_map: dict[str, str]) -> str | None:
    prefix = dir_rel + "/"
    statuses = {v for k, v in status_map.items() if k.startswith(prefix)}
    if not statuses:
        return None
    if "M" in statuses or "MM" in statuses or "AM" in statuses:
        return "M"
    if "A" in statuses:
        return "A"
    if "??" in statuses:
        return "??"
    return next(iter(statuses))


def build_file_tree(repo_root: Path | None = None) -> list[FileNode]:
    root = repo_root or git_repo_root()
    status_map = _git_status_map(root)
    ignored_set = _git_ignored_set(root)
    return _build_tree(root, root, status_map, ignored_set)


def get_repo_root(repo_root: Path | None = None) -> str:
    return str(repo_root or git_repo_root())
