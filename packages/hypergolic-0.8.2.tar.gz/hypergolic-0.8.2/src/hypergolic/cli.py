import os
import subprocess
import sys
import threading
from pathlib import Path


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _ui_dist_dir() -> Path:
    return _package_root() / "ui_dist"


def _find_ui_source_dir() -> Path | None:
    cwd = Path.cwd()
    candidates = [
        cwd / "ui",
        _package_root().parent.parent / "ui",
    ]
    for candidate in candidates:
        if (candidate / "package.json").exists():
            return candidate
    return None


def _build_ui() -> None:
    ui_dir = _find_ui_source_dir()
    if ui_dir is None:
        print(
            "Error: Cannot find ui/ directory with package.json. "
            "Run from the hypergolic repo root, or ensure the UI is pre-built.",
            file=sys.stderr,
        )
        sys.exit(1)

    print(f"Building UI from {ui_dir}...")
    result = subprocess.run(["pnpm", "install", "--frozen-lockfile"], cwd=str(ui_dir))
    if result.returncode != 0:
        print("Error: pnpm install failed.", file=sys.stderr)
        sys.exit(1)

    result = subprocess.run(["pnpm", "run", "build"], cwd=str(ui_dir))
    if result.returncode != 0:
        print("Error: UI build failed.", file=sys.stderr)
        sys.exit(1)
    print("UI build complete.")


def _run_migrations() -> None:
    from alembic import command
    from alembic.config import Config

    root = _package_root()
    alembic_ini = root / "alembic.ini"
    alembic_cfg = Config(str(alembic_ini))
    alembic_cfg.set_main_option("script_location", str(root / "alembic"))
    command.upgrade(alembic_cfg, "head")


DEFAULT_TAGS = [
    "code-style",
    "tooling",
    "architecture",
    "domain",
    "team",
    "workflow",
    "debugging",
    "preference",
    "correction",
]


def _seed_tags() -> None:
    from sqlalchemy import select
    from hypergolic.db.engine import get_db
    from hypergolic.db.models import DBTag

    with get_db() as db:
        existing = {row.name for row in db.execute(select(DBTag)).scalars().all()}
        for tag_name in DEFAULT_TAGS:
            if tag_name not in existing:
                db.add(DBTag(name=tag_name))


def _register_config_projects() -> None:
    from sqlalchemy import select
    from hypergolic.config.settings import _load_user_config
    from hypergolic.db.engine import get_db
    from hypergolic.db.models import DBProject

    user_config = _load_user_config()
    if not user_config.projects:
        return

    with get_db() as db:
        for project in user_config.projects:
            resolved = str(Path(project.git_root).resolve())
            existing = db.execute(
                select(DBProject).where(DBProject.path == resolved)
            ).scalar_one_or_none()
            if existing:
                if existing.name != project.name:
                    existing.name = project.name
                continue
            db.add(DBProject(name=project.name, path=resolved))


def main() -> None:
    import uvicorn
    from hypergolic.logging import setup_error_logging

    setup_error_logging()

    dev_mode = os.environ.get("HYPERGOLIC_DEV_MODE", "").lower() in ("1", "true", "yes")

    if dev_mode:
        _build_ui()
    elif not _ui_dist_dir().exists():
        print(
            "Error: UI has not been built. Set HYPERGOLIC_DEV_MODE=true "
            "to build automatically, or pre-build with "
            "`cd ui && pnpm run build`.",
            file=sys.stderr,
        )
        sys.exit(1)

    _run_migrations()
    _seed_tags()
    _register_config_projects()

    host = "127.0.0.1"
    port = 8000
    url = f"http://{host}:{port}"

    server_thread = threading.Thread(
        target=uvicorn.run,
        kwargs={
            "app": "hypergolic.api:app",
            "host": host,
            "port": port,
            "log_level": "info",
        },
        daemon=True,
    )
    server_thread.start()

    import webview

    largest_screen = max(webview.screens, key=lambda s: s.width * s.height)
    window = webview.create_window(
        "Hypergolic",
        url,
        screen=largest_screen,
        background_color="#0a0a0f",
        maximized=True,
    )

    def _maximize_on_largest_screen() -> None:
        if window is None:
            return
        window.move(0, 0)
        window.resize(largest_screen.width, largest_screen.height)

    webview.start(func=_maximize_on_largest_screen)


if __name__ == "__main__":
    main()
