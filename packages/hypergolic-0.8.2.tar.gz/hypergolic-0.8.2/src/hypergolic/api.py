from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from hypergolic.attachments.router import router as attachments_router
from hypergolic.files.router import router as files_router
from hypergolic.git.router import router as git_router
from hypergolic.knowledge.router import router as knowledge_router
from hypergolic.mcp.client import get_mcp_manager
from hypergolic.mcp.router import router as mcp_router
from hypergolic.projects.router import router as projects_router
from hypergolic.providers import create_client
from hypergolic.sessions.router import router as sessions_router
from hypergolic.tools.router import router as tools_router
from hypergolic.terminal.router import router as terminal_router
from hypergolic.websocket.router import router as websocket_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.client = create_client()
    yield
    await get_mcp_manager().shutdown()


app = FastAPI(
    title="Hypergolic API",
    description="API for conversing with the Hypergolic agent.",
    version="0.3.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,  # type: ignore[arg-type]
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(projects_router)
app.include_router(sessions_router)
app.include_router(attachments_router)
app.include_router(files_router)
app.include_router(git_router)
app.include_router(knowledge_router)
app.include_router(mcp_router)
app.include_router(tools_router)
app.include_router(terminal_router)
app.include_router(websocket_router)

_UI_DIST = Path(__file__).resolve().parent / "ui_dist"

if _UI_DIST.is_dir():
    app.mount("/assets", StaticFiles(directory=_UI_DIST / "assets"), name="ui-assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str = ""):
        file_path = _UI_DIST / full_path
        if full_path and file_path.is_file():
            return FileResponse(file_path)
        return FileResponse(_UI_DIST / "index.html")
