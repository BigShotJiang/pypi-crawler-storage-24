import asyncio
import logging
import os
import ssl
from contextlib import AsyncExitStack
from dataclasses import dataclass
from typing import Any

import certifi
import httpx
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.types import Tool as MCPTool
from pydantic import AnyUrl

from hypergolic.config.schemas import MCPServerConfig
from hypergolic.config.settings import settings

logger = logging.getLogger(__name__)


def _make_ssl_context() -> ssl.SSLContext:
    ctx = ssl.create_default_context(cafile=certifi.where())
    # Python 3.13+ enforces Authority Key Identifier on certs by default.
    # Corporate SSL-intercept CAs (e.g. Rocket/Quicken Loans) may lack this
    # extension, so we relax the strict X.509 checks.
    ctx.verify_flags &= ~ssl.VerifyFlags.VERIFY_X509_STRICT
    return ctx


def _make_http_client(
    headers: dict[str, str] | None = None,
    timeout: httpx.Timeout | None = None,
    auth: httpx.Auth | None = None,
) -> httpx.AsyncClient:
    from mcp.shared._httpx_utils import MCP_DEFAULT_SSE_READ_TIMEOUT, MCP_DEFAULT_TIMEOUT

    kwargs: dict[str, Any] = {
        "follow_redirects": True,
        "verify": _make_ssl_context(),
    }
    kwargs["timeout"] = timeout or httpx.Timeout(
        MCP_DEFAULT_TIMEOUT, read=MCP_DEFAULT_SSE_READ_TIMEOUT
    )
    if headers is not None:
        kwargs["headers"] = headers
    if auth is not None:
        kwargs["auth"] = auth
    return httpx.AsyncClient(**kwargs)


@dataclass
class ConnectedServer:
    name: str
    source: str
    session: ClientSession
    tools: list[MCPTool]
    _exit_stack: AsyncExitStack


class MCPManager:
    def __init__(self) -> None:
        self._servers: dict[str, ConnectedServer] = {}
        self._lock = asyncio.Lock()

    def get_available_servers(self, project_path: str | None = None) -> dict[str, tuple[MCPServerConfig, str]]:
        from pathlib import Path
        from hypergolic.config.settings import load_project_config, load_user_project_config

        servers: dict[str, tuple[MCPServerConfig, str]] = {}
        for name, config in settings.user_config.mcp_servers.items():
            servers[name] = (config, "user")
        if project_path:
            user_project_config = load_user_project_config(Path(project_path))
            if user_project_config:
                for name, config in user_project_config.mcp_servers.items():
                    servers[name] = (config, "user-project")
        project_config = load_project_config(Path(project_path)) if project_path else settings.project_config
        for name, config in project_config.mcp_servers.items():
            servers[name] = (config, "project")
        return servers

    def is_connected(self, server_name: str) -> bool:
        return server_name in self._servers

    def get_connected_server(self, server_name: str) -> ConnectedServer | None:
        return self._servers.get(server_name)

    def get_all_connected(self) -> dict[str, ConnectedServer]:
        return dict(self._servers)

    def get_auth_status(self, server_name: str) -> str:
        available = self.get_available_servers()
        if server_name not in available:
            return "unknown"
        config, _ = available[server_name]
        if config.auth.type == "none":
            return "not_required"
        if config.auth.type == "token":
            env_var = config.auth.token_env_var
            if env_var and os.environ.get(env_var):
                return "ready"
            return "missing_token"
        if config.auth.type == "oauth":
            from hypergolic.mcp.oauth import FileTokenStorage
            storage = FileTokenStorage(server_name)
            if storage._tokens_path.exists():
                return "ready"
            return "needs_oauth"
        return "unknown"

    async def connect(self, server_name: str) -> ConnectedServer:
        async with self._lock:
            if server_name in self._servers:
                return self._servers[server_name]

            available = self.get_available_servers()
            if server_name not in available:
                raise ValueError(f"MCP server '{server_name}' not found in configuration")

            config, source = available[server_name]
            exit_stack = AsyncExitStack()

            try:
                if config.transport == "stdio":
                    session = await self._connect_stdio(config, exit_stack)
                elif config.transport == "streamable_http":
                    session = await self._connect_streamable_http(
                        server_name, config, exit_stack
                    )
                elif config.transport == "sse":
                    session = await self._connect_sse(
                        server_name, config, exit_stack
                    )
                else:
                    raise ValueError(f"Unknown transport: {config.transport}")

                await session.initialize()
                tools_result = await session.list_tools()
                tools = tools_result.tools

                server = ConnectedServer(
                    name=server_name,
                    source=source,
                    session=session,
                    tools=tools,
                    _exit_stack=exit_stack,
                )
                self._servers[server_name] = server
                logger.info(
                    "Connected to MCP server '%s' (%s) with %d tools",
                    server_name, config.transport, len(tools),
                )
                return server

            except Exception:
                await exit_stack.aclose()
                logger.error("Failed to connect to MCP server '%s'", server_name, exc_info=True)
                raise

    async def _connect_stdio(
        self, config: MCPServerConfig, exit_stack: AsyncExitStack
    ) -> ClientSession:
        if not config.command:
            raise ValueError("stdio transport requires 'command'")
        params = StdioServerParameters(
            command=config.command,
            args=config.args,
            env=config.env or None,
        )
        stdio_transport = await exit_stack.enter_async_context(
            stdio_client(params)
        )
        read_stream, write_stream = stdio_transport
        return await exit_stack.enter_async_context(
            ClientSession(read_stream, write_stream)
        )

    async def _connect_streamable_http(
        self,
        server_name: str,
        config: MCPServerConfig,
        exit_stack: AsyncExitStack,
    ) -> ClientSession:
        from mcp.client.streamable_http import streamable_http_client

        if not config.url:
            raise ValueError("streamable_http transport requires 'url'")

        headers, auth = self._build_http_auth(server_name, config)
        client = _make_http_client(headers=headers, auth=auth)

        transport = await exit_stack.enter_async_context(
            streamable_http_client(url=config.url, http_client=client)
        )
        read_stream, write_stream, _ = transport
        return await exit_stack.enter_async_context(
            ClientSession(read_stream, write_stream)
        )

    async def _connect_sse(
        self,
        server_name: str,
        config: MCPServerConfig,
        exit_stack: AsyncExitStack,
    ) -> ClientSession:
        from mcp.client.sse import sse_client

        if not config.url:
            raise ValueError("sse transport requires 'url'")

        headers, auth = self._build_http_auth(server_name, config)

        transport = await exit_stack.enter_async_context(
            sse_client(
                url=config.url,
                headers=headers,
                auth=auth,
                httpx_client_factory=_make_http_client,
            )
        )
        read_stream, write_stream = transport
        return await exit_stack.enter_async_context(
            ClientSession(read_stream, write_stream)
        )

    def _build_http_auth(
        self, server_name: str, config: MCPServerConfig
    ) -> tuple[dict[str, str] | None, Any]:
        auth_config = config.auth
        headers: dict[str, str] | None = None
        auth: httpx.Auth | None = None

        if auth_config.type == "token":
            token = self._resolve_token(auth_config)
            if token:
                prefix = auth_config.token_prefix
                value = f"{prefix} {token}" if prefix else token
                headers = {auth_config.token_header: value}

        elif auth_config.type == "oauth":
            from mcp.client.auth import OAuthClientProvider
            from mcp.shared.auth import OAuthClientMetadata
            from hypergolic.mcp.oauth import (
                FileTokenStorage,
                OAUTH_REDIRECT_URI,
                open_browser_for_oauth,
                wait_for_oauth_callback,
            )

            storage = FileTokenStorage(server_name)
            redirect_uri = AnyUrl(OAUTH_REDIRECT_URI)
            client_metadata = OAuthClientMetadata(
                redirect_uris=[redirect_uri],
                client_name="Hypergolic",
                grant_types=["authorization_code", "refresh_token"],
                response_types=["code"],
            )
            auth = OAuthClientProvider(
                server_url=config.url or "",
                client_metadata=client_metadata,
                storage=storage,
                redirect_handler=open_browser_for_oauth,
                callback_handler=wait_for_oauth_callback,
            )

        return headers, auth

    @staticmethod
    def _resolve_token(auth_config: Any) -> str | None:
        if auth_config.token_env_var:
            return os.environ.get(auth_config.token_env_var)
        return None

    async def disconnect(self, server_name: str) -> None:
        async with self._lock:
            server = self._servers.pop(server_name, None)
            if server:
                try:
                    await server._exit_stack.aclose()
                except Exception:
                    logger.warning(
                        "Error closing MCP server '%s'", server_name, exc_info=True
                    )
                logger.info("Disconnected from MCP server '%s'", server_name)

    async def call_tool(
        self, server_name: str, tool_name: str, arguments: dict[str, Any]
    ) -> dict[str, Any]:
        server = self._servers.get(server_name)
        if not server:
            raise ValueError(f"MCP server '{server_name}' is not connected")

        result = await server.session.call_tool(tool_name, arguments)
        content_parts: list[dict[str, Any]] = []
        for item in result.content:
            if hasattr(item, "text"):
                content_parts.append({"type": "text", "text": item.text})
            elif hasattr(item, "data") and hasattr(item, "mimeType"):
                content_parts.append({"type": "text", "text": f"[Binary content: {item.mimeType}]"})
            else:
                content_parts.append({"type": "text", "text": str(item)})

        return {"content": content_parts, "is_error": result.isError}

    async def shutdown(self) -> None:
        names = list(self._servers.keys())
        for name in names:
            await self.disconnect(name)


_manager: MCPManager | None = None


def get_mcp_manager() -> MCPManager:
    global _manager
    if _manager is None:
        _manager = MCPManager()
    return _manager
