"""Tests for embeddings.py module."""

from unittest.mock import Mock, patch

import httpx
import pytest

from tessera.embeddings import EmbeddingClient, EmbeddingUnavailableError


class TestEmbeddingClientInit:
    """Test EmbeddingClient initialization."""

    def test_client_initialization(self):
        """Test basic client initialization."""
        client = EmbeddingClient(
            endpoint="http://localhost:8000/v1/embeddings",
            model="default"
        )
        assert client.endpoint == "http://localhost:8000/v1/embeddings"
        assert client.model == "default"
        client.close()

    def test_client_custom_timeout(self):
        """Test client with custom timeout."""
        client = EmbeddingClient(
            endpoint="http://localhost:8000/v1/embeddings",
            model="default",
            timeout=60.0
        )
        # Just verify client was created successfully
        assert client.endpoint == "http://localhost:8000/v1/embeddings"
        client.close()

    def test_client_default_endpoint(self):
        """Test client with default endpoint."""
        client = EmbeddingClient()
        assert client.endpoint == "http://localhost:8000/v1/embeddings"
        assert client.model == "default"
        client.close()


class TestEmbeddingClientCache:
    """Test embedding caching."""

    def test_cache_initialization(self):
        """Test that cache is initialized empty."""
        client = EmbeddingClient()
        assert len(client._cache) == 0
        client.close()

    @patch("httpx.Client.post")
    def test_cache_stores_embeddings(self, mock_post):
        """Test that embeddings are cached."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "data": [
                {"embedding": [0.1, 0.2, 0.3]},
            ]
        }
        mock_post.return_value = mock_response

        client = EmbeddingClient()
        result = client.embed(["hello"])

        assert len(client._cache) == 1
        assert "hello" in client._cache
        client.close()

    @patch("httpx.Client.post")
    def test_cache_reuses_embeddings(self, mock_post):
        """Test that cached embeddings are reused."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "data": [
                {"embedding": [0.1, 0.2, 0.3]},
            ]
        }
        mock_post.return_value = mock_response

        client = EmbeddingClient()

        # First call
        result1 = client.embed(["hello"])
        assert mock_post.call_count == 1

        # Second call with same text
        result2 = client.embed(["hello"])
        # Should still be 1 call (cached)
        assert mock_post.call_count == 1

        # Results should be identical
        assert result1 == result2
        client.close()


class TestEmbeddingSingleText:
    """Test single text embedding."""

    @patch("httpx.Client.post")
    def test_embed_single_text(self, mock_post):
        """Test embed_single convenience method."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "data": [
                {"embedding": [0.1, 0.2, 0.3]},
            ]
        }
        mock_post.return_value = mock_response

        client = EmbeddingClient()
        result = client.embed_single("hello")

        assert result == [0.1, 0.2, 0.3]
        client.close()


class TestEmbeddingBatching:
    """Test embedding batching."""

    @patch("httpx.Client.post")
    def test_embed_batch_under_limit(self, mock_post):
        """Test batch under 100 item limit."""
        texts = ["text1", "text2", "text3"]
        mock_response = Mock()
        mock_response.json.return_value = {
            "data": [
                {"embedding": [0.1, 0.2]},
                {"embedding": [0.3, 0.4]},
                {"embedding": [0.5, 0.6]},
            ]
        }
        mock_post.return_value = mock_response

        client = EmbeddingClient()
        result = client.embed(texts)

        # Should make 1 API call
        assert mock_post.call_count == 1
        assert len(result) == 3
        client.close()

    @patch("httpx.Client.post")
    def test_embed_batch_over_limit(self, mock_post):
        """Test batch over 100 item limit (should split)."""
        texts = [f"text{i}" for i in range(150)]

        # Mock will be called twice (100 + 50)
        mock_response1 = Mock()
        mock_response1.json.return_value = {
            "data": [{"embedding": [0.1, 0.2]} for _ in range(100)]
        }

        mock_response2 = Mock()
        mock_response2.json.return_value = {
            "data": [{"embedding": [0.3, 0.4]} for _ in range(50)]
        }

        mock_post.side_effect = [mock_response1, mock_response2]

        client = EmbeddingClient()
        result = client.embed(texts)

        # Should make 2 API calls
        assert mock_post.call_count == 2
        assert len(result) == 150
        client.close()


class TestEmbeddingErrorHandling:
    """Test error handling."""

    @patch("httpx.Client.post")
    def test_embed_request_error(self, mock_post):
        """Test handling of request errors."""
        mock_post.side_effect = httpx.RequestError("Connection failed")

        client = EmbeddingClient()

        with pytest.raises(EmbeddingUnavailableError):
            client.embed(["hello"])

        client.close()

    @patch("httpx.Client.post")
    def test_embed_http_error(self, mock_post):
        """Test handling of HTTP errors."""
        mock_response = Mock()
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "500 Server Error",
            request=Mock(),
            response=Mock()
        )
        mock_post.return_value = mock_response

        client = EmbeddingClient()

        with pytest.raises(EmbeddingUnavailableError):
            client.embed(["hello"])

        client.close()

    @patch("httpx.Client.post")
    def test_embed_invalid_response_missing_embedding(self, mock_post):
        """Test handling of invalid response format (missing embedding field)."""
        mock_response = Mock()
        # Response has data but missing 'embedding' field
        mock_response.json.return_value = {
            "data": [
                {"content": "hello"}  # Missing 'embedding' field
            ]
        }
        mock_post.return_value = mock_response

        client = EmbeddingClient()

        with pytest.raises(EmbeddingUnavailableError):
            client.embed(["hello"])

        client.close()


class TestEmbeddingContextManager:
    """Test context manager interface."""

    def test_context_manager_enter_exit(self):
        """Test client works as context manager."""
        with EmbeddingClient() as client:
            assert client is not None
            assert client.endpoint == "http://localhost:8000/v1/embeddings"


class TestEmbeddingDuplicateTexts:
    """Test handling of duplicate text inputs."""

    @patch.object(httpx.Client, 'post')
    def test_duplicate_texts_all_get_embeddings(self, mock_post):
        """Two identical texts should both receive embeddings (both sent to API, both filled)."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()
        # Both duplicates are sent to API (neither is cached yet in same batch)
        mock_response.json.return_value = {
            "data": [
                {"embedding": [0.1, 0.2, 0.3]},
                {"embedding": [0.1, 0.2, 0.3]},
            ]
        }
        mock_post.return_value = mock_response

        client = EmbeddingClient()
        results = client.embed(["hello world", "hello world"])

        assert len(results) == 2
        assert results[0] == [0.1, 0.2, 0.3]
        assert results[1] == [0.1, 0.2, 0.3]
        client.close()

    @patch.object(httpx.Client, 'post')
    def test_duplicate_texts_across_batches_use_cache(self, mock_post):
        """Second call with same text should use cache, not API."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()
        mock_response.json.return_value = {
            "data": [{"embedding": [0.1, 0.2, 0.3]}]
        }
        mock_post.return_value = mock_response

        client = EmbeddingClient()
        # First call populates cache
        r1 = client.embed(["hello world"])
        assert r1[0] == [0.1, 0.2, 0.3]
        assert mock_post.call_count == 1

        # Second call should use cache — no API call
        r2 = client.embed(["hello world"])
        assert r2[0] == [0.1, 0.2, 0.3]
        assert mock_post.call_count == 1  # Still 1, cache hit
        client.close()

    @patch.object(httpx.Client, 'post')
    def test_count_mismatch_raises(self, mock_post):
        """Response with wrong count should raise."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()
        mock_response.json.return_value = {
            "data": [
                {"embedding": [0.1, 0.2]},
                # Missing second item
            ]
        }
        mock_post.return_value = mock_response

        client = EmbeddingClient()
        with pytest.raises(EmbeddingUnavailableError, match="count mismatch"):
            client.embed(["text1", "text2"])
        client.close()


class TestEmbeddingEmpty:
    """Test handling of empty inputs."""

    def test_embed_empty_list(self):
        """Test embedding empty list."""
        client = EmbeddingClient()
        result = client.embed([])
        assert result == []
        client.close()


# --- FastembedClient tests ---

class TestFastembedClient:
    """Test FastembedClient with mocked fastembed."""

    def _make_client(self, mock_te):
        """Create a FastembedClient with mocked TextEmbedding."""
        import numpy as np
        mock_model = Mock()
        mock_model.embed.side_effect = lambda texts: iter([np.array([0.1, 0.2, 0.3]) for _ in texts])
        mock_te.return_value = mock_model

        from tessera.embeddings import FastembedClient
        client = FastembedClient(model_name="test-model")
        return client, mock_model

    @patch("tessera.embeddings.FastembedClient.__init__", return_value=None)
    def test_embed_basic(self, _mock_init):
        """Test basic embedding via fastembed."""
        import numpy as np
        from tessera.embeddings import FastembedClient
        client = FastembedClient.__new__(FastembedClient)
        client._cache = {}
        client._cache_max = 10000
        client.model_name = "test"
        mock_model = Mock()
        mock_model.embed.side_effect = lambda texts: iter([np.array([0.1, 0.2, 0.3]) for _ in texts])
        client._model = mock_model

        result = client.embed(["hello", "world"])
        assert len(result) == 2
        assert result[0] == [0.1, 0.2, 0.3]
        mock_model.embed.assert_called_once()

    @patch("tessera.embeddings.FastembedClient.__init__", return_value=None)
    def test_cache_hit(self, _mock_init):
        """Test that cached texts are not re-embedded."""
        import numpy as np
        from tessera.embeddings import FastembedClient
        client = FastembedClient.__new__(FastembedClient)
        client._cache = {"hello": [0.1, 0.2, 0.3]}
        client._cache_max = 10000
        client.model_name = "test"
        mock_model = Mock()
        mock_model.embed.side_effect = lambda texts: iter([np.array([0.4, 0.5, 0.6]) for _ in texts])
        client._model = mock_model

        result = client.embed(["hello", "world"])
        assert result[0] == [0.1, 0.2, 0.3]  # from cache
        assert result[1] == [0.4, 0.5, 0.6]  # from model
        # Model should only be called for uncached "world"
        mock_model.embed.assert_called_once_with(["world"])

    @patch("tessera.embeddings.FastembedClient.__init__", return_value=None)
    def test_embed_empty(self, _mock_init):
        """Test embedding empty list."""
        from tessera.embeddings import FastembedClient
        client = FastembedClient.__new__(FastembedClient)
        client._cache = {}
        result = client.embed([])
        assert result == []

    @patch("tessera.embeddings.FastembedClient.__init__", return_value=None)
    def test_embed_query_adds_prefix(self, _mock_init):
        """Test that embed_query adds retrieval prefix."""
        import numpy as np
        from tessera.embeddings import FastembedClient
        client = FastembedClient.__new__(FastembedClient)
        client._cache = {}
        client._cache_max = 10000
        client.model_name = "test"
        mock_model = Mock()
        mock_model.embed.side_effect = lambda texts: iter([np.array([0.1, 0.2, 0.3]) for _ in texts])
        client._model = mock_model

        client.embed_query("test query")
        called_texts = mock_model.embed.call_args[0][0]
        assert called_texts[0].startswith("Represent this search query")

    @patch("tessera.embeddings.FastembedClient.__init__", return_value=None)
    def test_context_manager(self, _mock_init):
        """Test context manager support."""
        from tessera.embeddings import FastembedClient
        client = FastembedClient.__new__(FastembedClient)
        client._cache = {}
        with client as c:
            assert c is client


class TestFastembedReranker:
    """Test FastembedReranker with mocked TextCrossEncoder."""

    @patch("tessera.embeddings.FastembedReranker.__init__", return_value=None)
    def test_rerank_basic(self, _mock_init):
        """Test basic reranking."""
        from tessera.embeddings import FastembedReranker
        reranker = FastembedReranker.__new__(FastembedReranker)
        reranker.model_name = "test"
        mock_model = Mock()
        mock_model.rerank.return_value = [0.9, 0.1, 0.5]
        reranker._model = mock_model

        result = reranker.rerank("query", ["doc1", "doc2", "doc3"], top_k=2)
        assert len(result) == 2
        assert result[0] == (0, 0.9)  # doc1 is highest
        assert result[1] == (2, 0.5)  # doc3 is second

    @patch("tessera.embeddings.FastembedReranker.__init__", return_value=None)
    def test_rerank_empty(self, _mock_init):
        """Test reranking empty docs."""
        from tessera.embeddings import FastembedReranker
        reranker = FastembedReranker.__new__(FastembedReranker)
        result = reranker.rerank("query", [])
        assert result == []


class TestCreateEmbeddingClient:
    """Test the create_embedding_client factory."""

    def test_http_with_endpoint(self):
        from tessera.embeddings import create_embedding_client, EmbeddingClient
        client = create_embedding_client("http", embedding_endpoint="http://localhost:8000/v1")
        assert isinstance(client, EmbeddingClient)
        client.close()

    def test_http_without_endpoint(self):
        from tessera.embeddings import create_embedding_client
        client = create_embedding_client("http")
        assert client is None

    def test_fastembed_not_installed(self):
        from tessera.embeddings import create_embedding_client
        with patch.dict("sys.modules", {"fastembed": None}):
            with pytest.raises(ImportError, match="tessera-idx"):
                create_embedding_client("fastembed")

    def test_auto_with_endpoint(self):
        from tessera.embeddings import create_embedding_client, EmbeddingClient
        client = create_embedding_client("auto", embedding_endpoint="http://localhost:8000/v1")
        assert isinstance(client, EmbeddingClient)
        client.close()

    def test_auto_no_fastembed_no_endpoint(self):
        from tessera.embeddings import create_embedding_client
        with patch.dict("sys.modules", {"fastembed": None}):
            client = create_embedding_client("auto")
            assert client is None


class TestHTTPReranker:
    """Test HTTPReranker with mocked httpx."""

    @patch.object(httpx.Client, 'post')
    def test_rerank_basic(self, mock_post):
        """Test basic HTTP reranking."""
        from tessera.embeddings import HTTPReranker
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()
        mock_response.json.return_value = {
            "results": [
                {"index": 2, "relevance_score": 0.95},
                {"index": 0, "relevance_score": 0.80},
            ]
        }
        mock_post.return_value = mock_response

        reranker = HTTPReranker(endpoint="http://localhost:8800/v1/rerank", model="test")
        result = reranker.rerank("query", ["doc1", "doc2", "doc3"], top_k=2)

        assert len(result) == 2
        assert result[0] == (2, 0.95)
        assert result[1] == (0, 0.80)
        reranker.close()

    @patch.object(httpx.Client, 'post')
    def test_rerank_sends_correct_payload(self, mock_post):
        """Test that correct payload is sent to the endpoint."""
        from tessera.embeddings import HTTPReranker
        mock_response = Mock()
        mock_response.raise_for_status = Mock()
        mock_response.json.return_value = {"results": []}
        mock_post.return_value = mock_response

        reranker = HTTPReranker(endpoint="http://localhost:8800/v1/rerank", model="jina-reranker")
        reranker.rerank("test query", ["doc1", "doc2"], top_k=5)

        call_json = mock_post.call_args[1]["json"]
        assert call_json["query"] == "test query"
        assert call_json["documents"] == ["doc1", "doc2"]
        assert call_json["top_n"] == 5
        assert call_json["model"] == "jina-reranker"
        reranker.close()

    def test_rerank_empty_documents(self):
        """Test reranking empty document list."""
        from tessera.embeddings import HTTPReranker
        reranker = HTTPReranker()
        result = reranker.rerank("query", [])
        assert result == []
        reranker.close()

    @patch.object(httpx.Client, 'post')
    def test_rerank_endpoint_error_returns_fallback(self, mock_post):
        """Test graceful fallback on endpoint error."""
        from tessera.embeddings import HTTPReranker
        mock_post.side_effect = httpx.RequestError("Connection failed")

        reranker = HTTPReranker()
        result = reranker.rerank("query", ["doc1", "doc2"], top_k=2)

        # Should return fallback indices instead of raising
        assert len(result) == 2
        assert result[0][0] == 0
        assert result[1][0] == 1
        reranker.close()

    def test_context_manager(self):
        """Test context manager support."""
        from tessera.embeddings import HTTPReranker
        with HTTPReranker() as r:
            assert r is not None


class TestCreateReranker:
    """Test the create_reranker factory."""

    def test_disabled(self):
        from tessera.embeddings import create_reranker
        assert create_reranker(enabled=False) is None

    def test_http_with_endpoint(self):
        from tessera.embeddings import create_reranker, HTTPReranker
        reranker = create_reranker(provider="http", reranking_endpoint="http://localhost:8800/v1/rerank")
        assert isinstance(reranker, HTTPReranker)
        reranker.close()

    def test_http_without_endpoint(self):
        from tessera.embeddings import create_reranker
        assert create_reranker(provider="http") is None

    def test_auto_with_endpoint(self):
        from tessera.embeddings import create_reranker, HTTPReranker
        reranker = create_reranker(provider="auto", reranking_endpoint="http://localhost:8800/v1/rerank")
        assert isinstance(reranker, HTTPReranker)
        reranker.close()

    def test_no_fastembed(self):
        from tessera.embeddings import create_reranker
        with patch.dict("sys.modules", {"fastembed": None, "fastembed.rerank": None, "fastembed.rerank.cross_encoder": None}):
            assert create_reranker(provider="auto") is None
