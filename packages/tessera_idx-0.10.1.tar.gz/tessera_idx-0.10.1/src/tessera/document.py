"""Document extraction and chunking module.

Supports extraction and chunking of various document formats:
- PDF: Extract text using pymupdf4llm
- Markdown/RST: Split on headers with hierarchy tracking
- YAML: Split by top-level keys with safe loading
- JSON: Split by top-level keys with safe loading
- HTML/XML: Strip tags, then chunk as plaintext
- Plaintext (.txt, .csv, .log, .ini, .cfg, .toml, .env.example, etc.):
  Line-based chunking with configurable size

All exceptions are wrapped in DocumentExtractionError for uniform error handling.
"""

import asyncio
import json
import re
from dataclasses import dataclass
from html.parser import HTMLParser

import yaml


class DocumentExtractionError(Exception):
    """Raised when document extraction fails."""
    pass


@dataclass
class DocumentChunk:
    """A chunk of a document with metadata."""
    content: str
    source_type: str  # e.g. 'markdown', 'pdf', 'yaml', 'json'
    source_file: str = ""
    section_heading: str = ""
    key_path: str = ""
    page_number: int | None = None
    parent_section: str = ""
    start_line: int = 0
    end_line: int = 0


async def extract_pdf(pdf_path: str) -> str:
    """
    Extract text from PDF using pymupdf4llm.

    CRITICAL: Uses asyncio.to_thread() to avoid blocking the event loop.
    The extraction is run in a thread pool, not via asyncio.run().

    Args:
        pdf_path: Path to PDF file

    Returns:
        Markdown text extracted from PDF

    Raises:
        DocumentExtractionError: If extraction fails
    """
    try:
        import pymupdf4llm
    except ImportError:
        raise DocumentExtractionError(
            "pymupdf4llm not installed. Install with: pip install pymupdf4llm"
        ) from None

    try:
        # Use asyncio.to_thread to run blocking I/O without blocking event loop
        markdown_text = await asyncio.to_thread(
            pymupdf4llm.to_markdown, pdf_path
        )
        return markdown_text
    except Exception as e:
        raise DocumentExtractionError(
            f"Failed to extract PDF from {pdf_path}: {e}"
        ) from e


def chunk_markdown(
    markdown_text: str,
    max_chunk_size: int = 1024,
    overlap: int = 128,
    split_headers: list[str] | None = None,
) -> list[DocumentChunk]:
    """
    Chunk markdown text on header boundaries with hierarchy tracking.

    Splits on lines starting with header patterns (default: "#", "##", "###").
    Maintains section hierarchy (h1 -> h2 -> h3) and tracks parent_section.
    Chunks exceeding max_chunk_size are split with overlap.

    Args:
        markdown_text: Markdown text to chunk
        max_chunk_size: Maximum chunk size in characters (default 1024)
        overlap: Character overlap for large chunks (default 128)
        split_headers: Header patterns to split on (default ["#", "##", "###"])

    Returns:
        List of DocumentChunk objects
    """
    if split_headers is None:
        split_headers = ["#", "##", "###"]

    lines = markdown_text.split("\n")
    chunks = []
    current_chunk_lines = []
    current_heading = ""
    parent_heading = ""
    start_line_idx = 0
    header_stack = {}  # Track header hierarchy: {level: header_text}

    for line_idx, line in enumerate(lines):
        # Check if line is a header
        is_header = False
        header_level = None
        header_text = ""

        for header_pattern in split_headers:
            if line.startswith(header_pattern + " "):
                is_header = True
                header_level = len(header_pattern)
                header_text = line[len(header_pattern) :].strip()
                break

        if is_header:
            # Flush current chunk if it has content
            if current_chunk_lines:
                chunk_content = "\n".join(current_chunk_lines)
                if len(chunk_content) > max_chunk_size:
                    # Split large chunks with overlap
                    chunks.extend(
                        _split_large_chunk(
                            chunk_content,
                            current_heading,
                            parent_heading,
                            start_line_idx,
                            line_idx - 1,
                            max_chunk_size,
                            overlap,
                        )
                    )
                else:
                    chunks.append(
                        DocumentChunk(
                            content=chunk_content,
                            source_type="markdown",
                            section_heading=current_heading,
                            parent_section=parent_heading,
                            start_line=start_line_idx,
                            end_line=line_idx - 1,
                        )
                    )
                current_chunk_lines = []

            # Update header tracking
            if header_level == 1:
                header_stack = {1: header_text}
                current_heading = header_text
                parent_heading = ""
            elif header_level == 2:
                header_stack = {
                    k: v for k, v in header_stack.items() if k < 2
                }
                header_stack[2] = header_text
                current_heading = header_text
                parent_heading = header_stack.get(1, "")
            elif header_level == 3:
                header_stack = {
                    k: v for k, v in header_stack.items() if k < 3
                }
                header_stack[3] = header_text
                current_heading = header_text
                parent_heading = header_stack.get(2, header_stack.get(1, ""))

            start_line_idx = line_idx
            current_chunk_lines = [line]
        else:
            current_chunk_lines.append(line)

    # Flush remaining chunk
    if current_chunk_lines:
        chunk_content = "\n".join(current_chunk_lines)
        if len(chunk_content) > max_chunk_size:
            chunks.extend(
                _split_large_chunk(
                    chunk_content,
                    current_heading,
                    parent_heading,
                    start_line_idx,
                    len(lines) - 1,
                    max_chunk_size,
                    overlap,
                )
            )
        else:
            chunks.append(
                DocumentChunk(
                    content=chunk_content,
                    source_type="markdown",
                    section_heading=current_heading,
                    parent_section=parent_heading,
                    start_line=start_line_idx,
                    end_line=len(lines) - 1,
                )
            )

    return chunks


def _split_large_chunk(
    content: str,
    section_heading: str,
    parent_section: str,
    start_line: int,
    end_line: int,
    max_chunk_size: int,
    overlap: int,
) -> list[DocumentChunk]:
    """
    Split a large chunk into overlapping pieces.

    Args:
        content: Content to split
        section_heading: Section heading for this chunk
        parent_section: Parent section name
        start_line: Starting line number
        end_line: Ending line number
        max_chunk_size: Maximum size for each piece
        overlap: Character overlap between pieces

    Returns:
        List of DocumentChunk objects
    """
    chunks = []
    offset = 0
    line_offset = start_line

    while offset < len(content):
        # Take up to max_chunk_size characters
        end_offset = min(offset + max_chunk_size, len(content))
        chunk_text = content[offset:end_offset]

        # Count newlines to estimate line number
        lines_in_chunk = chunk_text.count("\n")
        chunk_end_line = line_offset + lines_in_chunk

        chunks.append(
            DocumentChunk(
                content=chunk_text,
                source_type="markdown",
                section_heading=section_heading,
                parent_section=parent_section,
                start_line=line_offset,
                end_line=chunk_end_line,
            )
        )

        # Move offset by (max_chunk_size - overlap) for next chunk
        offset = end_offset - overlap
        line_offset = chunk_end_line

        # Stop if we've reached the end
        if end_offset >= len(content):
            break

    return chunks


def chunk_yaml(
    yaml_path: str, max_chunk_size: int = 2048
) -> list[DocumentChunk]:
    """
    Chunk YAML file by top-level keys.

    Uses safe_load for security. Chunks by top-level keys with recursive
    splitting if content exceeds max_chunk_size.

    Args:
        yaml_path: Path to YAML file
        max_chunk_size: Maximum chunk size in characters (default 2048)

    Returns:
        List of DocumentChunk objects

    Raises:
        DocumentExtractionError: If YAML parsing fails
    """
    try:
        with open(yaml_path) as f:
            content = f.read()
        try:
            data = yaml.safe_load(content)
        except yaml.constructor.ConstructorError:
            # Fall back to raw text chunking for YAML with custom tags (e.g., mkdocs.yml)
            lines = content.split("\n")
            return [DocumentChunk(
                content=content,
                source_type="yaml",
                start_line=0,
                end_line=len(lines) - 1,
            )]
        except yaml.YAMLError as e:
            raise DocumentExtractionError(
                f"Failed to parse YAML file {yaml_path}: {e}"
            ) from e
    except FileNotFoundError as e:
        raise DocumentExtractionError(
            f"YAML file not found: {yaml_path}"
        ) from e
    except Exception as e:
        raise DocumentExtractionError(
            f"Failed to read YAML file {yaml_path}: {e}"
        ) from e

    if data is None:
        return []

    if not isinstance(data, dict):
        # If root is not a dict, wrap the entire content
        content = yaml.dump(data, default_flow_style=False)
        return [
            DocumentChunk(
                content=content,
                source_type="yaml",
                source_file=yaml_path,
                key_path="",
                parent_section="",
                start_line=0,
                end_line=len(content.split("\n")) - 1,
            )
        ]

    chunks = []
    for key, value in data.items():
        # Dump this key-value pair to YAML
        content = yaml.dump({key: value}, default_flow_style=False)

        # Check if chunk exceeds max_chunk_size
        if len(content) > max_chunk_size:
            # Recursively chunk nested structures
            sub_chunks = _chunk_yaml_nested(
                {key: value}, max_chunk_size, key, ""
            )
            chunks.extend(sub_chunks)
        else:
            chunks.append(
                DocumentChunk(
                    content=content,
                    source_type="yaml",
                    source_file=yaml_path,
                    key_path=key,
                    parent_section="",
                    start_line=0,
                    end_line=len(content.split("\n")) - 1,
                )
            )

    return chunks


def _chunk_yaml_nested(
    data: dict, max_chunk_size: int, key_path: str, parent_section: str
) -> list[DocumentChunk]:
    """
    Recursively chunk nested YAML structures.

    Args:
        data: Dict to chunk (single key-value pair)
        max_chunk_size: Maximum chunk size
        key_path: Current key path (dot-separated)
        parent_section: Parent section name

    Returns:
        List of DocumentChunk objects
    """
    chunks = []
    for key, value in data.items():
        current_key_path = f"{key_path}.{key}" if key_path else key

        if isinstance(value, dict):
            # Recursively process nested dict
            for nested_key, nested_value in value.items():
                nested_content = yaml.dump(
                    {nested_key: nested_value}, default_flow_style=False
                )
                if len(nested_content) > max_chunk_size:
                    # Further recursion
                    chunks.extend(
                        _chunk_yaml_nested(
                            {nested_key: nested_value},
                            max_chunk_size,
                            current_key_path,
                            key_path,
                        )
                    )
                else:
                    chunks.append(
                        DocumentChunk(
                            content=nested_content,
                            source_type="yaml",
                            key_path=f"{current_key_path}.{nested_key}",
                            parent_section=key_path,
                            start_line=0,
                            end_line=len(nested_content.split("\n")) - 1,
                        )
                    )
        else:
            # Leaf value
            content = yaml.dump({key: value}, default_flow_style=False)
            chunks.append(
                DocumentChunk(
                    content=content,
                    source_type="yaml",
                    key_path=current_key_path,
                    parent_section=parent_section,
                    start_line=0,
                    end_line=len(content.split("\n")) - 1,
                )
            )

    return chunks


def _strip_jsonc(text: str) -> str:
    """Strip JSONC extensions (comments, trailing commas) for json.loads compatibility."""
    # Remove block comments (/* ... */)
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
    # Remove single-line comments (// ...)
    text = re.sub(r'//.*$', '', text, flags=re.MULTILINE)
    # Remove trailing commas before } or ]
    text = re.sub(r',\s*([}\]])', r'\1', text)
    return text


def chunk_json(
    json_path: str, max_chunk_size: int = 2048
) -> list[DocumentChunk]:
    """
    Chunk JSON file by top-level keys.

    Uses json.loads() for safe parsing. Chunks by top-level keys with
    recursive splitting if content exceeds max_chunk_size.

    Args:
        json_path: Path to JSON file
        max_chunk_size: Maximum chunk size in characters (default 2048)

    Returns:
        List of DocumentChunk objects

    Raises:
        DocumentExtractionError: If JSON parsing fails
    """
    try:
        with open(json_path) as f:
            content = f.read()
        try:
            data = json.loads(content)
        except json.JSONDecodeError:
            # Retry with JSONC tolerance (strip comments and trailing commas)
            data = json.loads(_strip_jsonc(content))
    except FileNotFoundError as e:
        raise DocumentExtractionError(
            f"JSON file not found: {json_path}"
        ) from e
    except json.JSONDecodeError as e:
        raise DocumentExtractionError(
            f"Failed to parse JSON file {json_path}: {e}"
        ) from e
    except Exception as e:
        raise DocumentExtractionError(
            f"Failed to read JSON file {json_path}: {e}"
        ) from e

    if data is None:
        return []

    if not isinstance(data, dict):
        # If root is not a dict, wrap the entire content
        content = json.dumps(data, indent=2)
        return [
            DocumentChunk(
                content=content,
                source_type="json",
                source_file=json_path,
                key_path="",
                parent_section="",
                start_line=0,
                end_line=len(content.split("\n")) - 1,
            )
        ]

    chunks = []
    for key, value in data.items():
        # Dump this key-value pair to JSON
        content = json.dumps({key: value}, indent=2)

        # Check if chunk exceeds max_chunk_size
        if len(content) > max_chunk_size:
            # Recursively chunk nested structures
            sub_chunks = _chunk_json_nested(
                {key: value}, max_chunk_size, key, ""
            )
            chunks.extend(sub_chunks)
        else:
            chunks.append(
                DocumentChunk(
                    content=content,
                    source_type="json",
                    source_file=json_path,
                    key_path=key,
                    parent_section="",
                    start_line=0,
                    end_line=len(content.split("\n")) - 1,
                )
            )

    return chunks


def _chunk_json_nested(
    data: dict, max_chunk_size: int, key_path: str, parent_section: str
) -> list[DocumentChunk]:
    """
    Recursively chunk nested JSON structures.

    Args:
        data: Dict to chunk (single key-value pair)
        max_chunk_size: Maximum chunk size
        key_path: Current key path (dot-separated)
        parent_section: Parent section name

    Returns:
        List of DocumentChunk objects
    """
    chunks = []
    for key, value in data.items():
        current_key_path = f"{key_path}.{key}" if key_path else key

        if isinstance(value, dict):
            # Recursively process nested dict
            for nested_key, nested_value in value.items():
                nested_content = json.dumps(
                    {nested_key: nested_value}, indent=2
                )
                if len(nested_content) > max_chunk_size:
                    # Further recursion
                    chunks.extend(
                        _chunk_json_nested(
                            {nested_key: nested_value},
                            max_chunk_size,
                            current_key_path,
                            key_path,
                        )
                    )
                else:
                    chunks.append(
                        DocumentChunk(
                            content=nested_content,
                            source_type="json",
                            key_path=f"{current_key_path}.{nested_key}",
                            parent_section=key_path,
                            start_line=0,
                            end_line=len(nested_content.split("\n")) - 1,
                        )
                    )
        else:
            # Leaf value
            content = json.dumps({key: value}, indent=2)
            chunks.append(
                DocumentChunk(
                    content=content,
                    source_type="json",
                    key_path=current_key_path,
                    parent_section=parent_section,
                    start_line=0,
                    end_line=len(content.split("\n")) - 1,
                )
            )

    return chunks


class _HTMLTextExtractor(HTMLParser):
    """Extract visible text from HTML, stripping all tags."""

    def __init__(self):
        super().__init__()
        self._parts: list[str] = []
        self._skip = False

    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style', 'svg', 'noscript'):
            self._skip = True

    def handle_endtag(self, tag):
        if tag in ('script', 'style', 'svg', 'noscript'):
            self._skip = False
        if tag in ('p', 'div', 'br', 'li', 'tr', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'):
            self._parts.append('\n')

    def handle_data(self, data):
        if not self._skip:
            self._parts.append(data)

    def get_text(self) -> str:
        return ''.join(self._parts)


def strip_html(html_content: str) -> str:
    """Strip HTML tags and return visible text."""
    extractor = _HTMLTextExtractor()
    extractor.feed(html_content)
    text = extractor.get_text()
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def chunk_plaintext(
    text: str,
    source_type: str = "text",
    max_chunk_size: int = 1024,
    overlap_lines: int = 3,
) -> list[DocumentChunk]:
    """Chunk plaintext content by line groups.

    Splits text into chunks of approximately max_chunk_size characters,
    breaking on line boundaries. Adjacent chunks share overlap_lines
    for context continuity.
    """
    if not text or not text.strip():
        return []

    lines = text.split('\n')
    chunks = []
    start_idx = 0

    while start_idx < len(lines):
        chunk_lines = []
        char_count = 0
        end_idx = start_idx

        while end_idx < len(lines):
            line = lines[end_idx]
            new_count = char_count + len(line) + 1
            if new_count > max_chunk_size and chunk_lines:
                break
            chunk_lines.append(line)
            char_count = new_count
            end_idx += 1

        if chunk_lines:
            chunks.append(DocumentChunk(
                content='\n'.join(chunk_lines),
                source_type=source_type,
                start_line=start_idx,
                end_line=end_idx - 1,
            ))

        if end_idx >= len(lines):
            break
        start_idx = max(end_idx - overlap_lines, start_idx + 1)

    return chunks


def chunk_html(html_path: str, max_chunk_size: int = 1024) -> list[DocumentChunk]:
    """Chunk HTML file by stripping tags and chunking the visible text."""
    try:
        with open(html_path, encoding='utf-8', errors='replace') as f:
            content = f.read()
    except FileNotFoundError as e:
        raise DocumentExtractionError(f"HTML file not found: {html_path}") from e
    except Exception as e:
        raise DocumentExtractionError(f"Failed to read HTML file {html_path}: {e}") from e

    text = strip_html(content)
    return chunk_plaintext(text, source_type='html', max_chunk_size=max_chunk_size)


def chunk_xml(xml_path: str, max_chunk_size: int = 1024) -> list[DocumentChunk]:
    """Chunk XML file by stripping tags and chunking visible text content."""
    try:
        with open(xml_path, encoding='utf-8', errors='replace') as f:
            content = f.read()
    except FileNotFoundError as e:
        raise DocumentExtractionError(f"XML file not found: {xml_path}") from e
    except Exception as e:
        raise DocumentExtractionError(f"Failed to read XML file {xml_path}: {e}") from e

    text = strip_html(content)
    return chunk_plaintext(text, source_type='xml', max_chunk_size=max_chunk_size)


def chunk_text_file(
    file_path: str, source_type: str = "text", max_chunk_size: int = 1024
) -> list[DocumentChunk]:
    """Chunk a plaintext file (txt, rst, csv, log, ini, cfg, toml, etc.)."""
    try:
        with open(file_path, encoding='utf-8', errors='replace') as f:
            content = f.read()
    except FileNotFoundError as e:
        raise DocumentExtractionError(f"Text file not found: {file_path}") from e
    except Exception as e:
        raise DocumentExtractionError(f"Failed to read text file {file_path}: {e}") from e

    return chunk_plaintext(content, source_type=source_type, max_chunk_size=max_chunk_size)
