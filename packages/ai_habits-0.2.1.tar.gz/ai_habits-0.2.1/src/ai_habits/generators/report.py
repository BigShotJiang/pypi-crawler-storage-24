"""Rich-formatted terminal output for ai-habits commands."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from ai_habits.patterns.clustering import Pattern
from ai_habits.patterns.anti_patterns import AntiPatternMatch
from ai_habits.auditors.feature_auditor import FeatureGap, SkillMatch

console = Console()

# Category metadata: category → (emoji, label, action hint)
_CATEGORY_DISPLAY: dict[str, tuple[str, str, str]] = {
    "repeatable-workflow":    ("🔁", "Repeated workflow",    "generate skill"),
    "boilerplate-request":    ("📋", "Boilerplate/scaffold", "generate skill"),
    "context-re-explanation": ("🔄", "Context re-explained", "generate patch"),
    "one-off-task":           ("✨", "One-off task",         ""),
    None:                     ("📌", "Uncategorized",        "generate skill"),
}


def print_scan_report(
    patterns: list[Pattern],
    anti_pattern_matches: list[AntiPatternMatch],
    scanned_sessions: int,
    scanned_messages: int,
    since: str,
) -> None:
    """Print the full `ai-habits scan` report."""
    console.print()
    console.print(Panel.fit(
        f"[bold cyan]ai-habits scan[/bold cyan]  [dim]{since}[/dim]",
        border_style="cyan",
    ))
    console.print(
        f"[dim]Scanned [bold]{scanned_sessions}[/bold] conversations, "
        f"[bold]{scanned_messages}[/bold] user messages[/dim]\n"
    )

    if not patterns and not anti_pattern_matches:
        console.print("[yellow]No patterns found.[/yellow]")
        console.print(
            "[dim]Try lowering --min-occurrences or widening --last window.[/dim]"
        )
        return

    if patterns:
        console.print("[bold]🔁 REPEATED PATTERNS[/bold]")
        for i, pat in enumerate(patterns, 1):
            _print_pattern(pat, i)

    if anti_pattern_matches:
        console.print("\n[bold]⚠️  ANTI-PATTERNS[/bold]")
        for match in anti_pattern_matches:
            _print_anti_pattern(match)

    actionable = [p for p in patterns if p.category not in ("one-off-task", None)]
    if actionable:
        console.print(
            f"\n[dim]Act on a pattern — e.g. "
            f"[bold]ai-habits generate skill --id {actionable[0].id}[/bold] "
            f"or [bold]ai-habits generate patch --id {actionable[0].id}[/bold][/dim]\n"
        )


def _print_pattern(pat: Pattern, index: int) -> None:
    emoji, label_str, action = _CATEGORY_DISPLAY.get(
        pat.category, _CATEGORY_DISPLAY[None]
    )
    category_tag = f"[bold]{emoji} {pat.category or 'unclassified'}[/bold]"

    header = Text()
    header.append(f"  {index}. ", style="bold white")
    header.append(f"{pat.label or pat.id}", style="bold yellow")
    header.append(f"  [", style="dim")
    header.append(f"{pat.id}", style="bold dim")
    header.append(f"]", style="dim")
    header.append(f" — {pat.size} occurrence{'s' if pat.size != 1 else ''}", style="dim")
    console.print(header)

    console.print(f"     │ Type: {category_tag}")

    # Dates summary
    dates = pat.dates
    if dates:
        date_strs = [d.strftime("%b %-d") for d in dates[:6]]
        more = f" +{len(dates)-6} more" if len(dates) > 6 else ""
        console.print(f"     │ Dates: [dim]{', '.join(date_strs)}{more}[/dim]")

    # Token waste estimate
    input_tok, output_tok = pat.wasted_tokens
    total_tok = input_tok + output_tok
    if total_tok > 0:
        parts = []
        if input_tok:
            parts.append(f"~{input_tok:,} input")
        if output_tok:
            parts.append(f"~{output_tok:,} output")
        console.print(
            f"     │ Est. token waste: [red]{' + '.join(parts)} tokens[/red]"
        )

    # Sample message
    if pat.sample_texts:
        sample = pat.sample_texts[0][:80].replace("\n", " ")
        console.print(f"     │ Sample: [italic dim]\"{sample}\"[/italic dim]")

    # Action hint or CLAUDE.md snippet
    if action:
        console.print(
            f"     └─ [green]💡 {_action_hint(pat, action)}[/green]"
        )
    elif pat.category == "one-off-task":
        snippet = _claude_md_snippet(pat)
        console.print(f"     │ [green]💡 Add to CLAUDE.md:[/green]")
        for line in snippet.split("\n"):
            console.print(f"     │   [dim]{line}[/dim]")
    console.print()


def _action_hint(pat: Pattern, action: str) -> str:
    if action == "generate skill":
        return f"Skill candidate → [bold]ai-habits generate skill --id {pat.id}[/bold]"
    elif action == "generate patch":
        return f"Add to CLAUDE.md → [bold]ai-habits generate patch --id {pat.id}[/bold]"
    return ""


def _claude_md_snippet(pat: Pattern) -> str:
    """Generate a ready-to-paste CLAUDE.md snippet for a one-off-task pattern."""
    text = (pat.representative_text or (pat.sample_texts[0] if pat.sample_texts else "")).strip()
    label = (pat.label or text)[:60].strip()
    t = text.lower()

    # Stuck / error / debugging patterns
    if any(kw in t for kw in ["stuck", "error", "fail", "not work", "broken", "crash", "wrong", "issue", "bug"]):
        return (
            f"## Troubleshooting\n"
            f"\n"
            f"### {label}\n"
            f"- **Cause**: [what triggers this]\n"
            f"- **Diagnose**: [how to tell what's wrong]\n"
            f"- **Fix**: [what resolves it]"
        )

    # Question patterns
    if any(t.startswith(kw) for kw in ["how", "what", "why", "can ", "should", "is there", "where"]):
        return (
            f"## Common Questions\n"
            f"\n"
            f"**Q: {label}**\n"
            f"A: [document the answer here so Claude always has this context]"
        )

    # Generic recurring note
    return (
        f"## Notes\n"
        f"\n"
        f"### {label}\n"
        f"[document what Claude needs to know about this recurring topic]"
    )


def _print_anti_pattern(match: AntiPatternMatch) -> None:
    console.print(f"  [bold yellow]{match.name}[/bold yellow] [dim]({match.count} occurrences)[/dim]")
    console.print(f"  {match.description}")
    console.print(f"  [green]💡 {match.suggestion}[/green]")
    console.print(
        f"  [dim]→ [bold]ai-habits generate patch[/bold]  "
        f"(or add context manually to CLAUDE.md)[/dim]"
    )
    console.print()


def print_discover_report(gaps: list[FeatureGap], project_path: Path) -> None:
    """Print the `ai-habits discover` report."""
    console.print()
    console.print(Panel.fit(
        "[bold yellow]ai-habits discover[/bold yellow]",
        border_style="yellow",
    ))
    console.print(f"[dim]Project: {project_path}[/dim]\n")

    present = [g for g in gaps if g.present]
    missing = [g for g in gaps if not g.present]

    if present:
        for gap in present:
            console.print(f"[green]✓[/green] [bold]{gap.feature}[/bold]")

    if missing:
        console.print()
        for gap in missing:
            sev_color = {"high": "red", "medium": "yellow", "low": "dim"}.get(gap.severity, "white")
            console.print(f"[{sev_color}]✗[/{sev_color}] [bold]{gap.feature}[/bold]")
            console.print(f"  {gap.why_it_matters}")

            if gap.mcp_matches:
                _print_mcp_matches(gap.mcp_matches)
            elif gap.skill_matches:
                _print_skill_matches(gap.skill_matches)
            else:
                console.print(f"  [green]→ {gap.how_to_enable}[/green]")
            console.print()
    else:
        console.print("\n[green]All tracked Claude Code features are present![/green]\n")


def _print_skill_matches(matches: list[SkillMatch]) -> None:
    """Print a table of matched community skill templates."""
    table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim", padding=(0, 1))
    table.add_column("Skill", style="bold yellow", no_wrap=True)
    table.add_column("What it does", style="dim")
    table.add_column("Install", style="green")

    for m in matches:
        table.add_row(
            m.name,
            m.description[:55] + ("…" if len(m.description) > 55 else ""),
            f"ai-habits generate skill --template {m.id}",
        )

    console.print(table)


def _print_mcp_matches(matches: list) -> None:
    """Print a table of matched MCP servers with install commands."""
    table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim", padding=(0, 1))
    table.add_column("Server", style="bold yellow", no_wrap=True)
    table.add_column("Replaces", style="dim")
    table.add_column("Install", style="green")
    table.add_column("Hits", style="red", justify="right")

    for m in matches:
        env_note = f" [dim](needs {', '.join(m.requires_env[:2])})[/dim]" if m.requires_env else ""
        table.add_row(
            m.name,
            m.replaces[:55] + ("…" if len(m.replaces) > 55 else ""),
            m.install + env_note,
            str(m.hit_count),
        )

    console.print(table)
    console.print(
        "  [green]→ Add to ~/.claude/settings.json under 'mcpServers'[/green]\n"
        "  [dim]Full catalog: https://github.com/modelcontextprotocol/servers[/dim]"
    )


def print_audit_report(findings: list, project_path: Path) -> None:
    """Print the `ai-habits audit` report."""
    console.print()
    console.print(Panel.fit(
        "[bold magenta]ai-habits audit[/bold magenta]",
        border_style="magenta",
    ))
    console.print(f"[dim]Project: {project_path}[/dim]\n")

    if not findings:
        console.print("[green]✓ CLAUDE.md looks good — no stale or missing entries detected.[/green]")
        console.print("[dim](Full audit requires conversation history — run ai-habits scan first)[/dim]\n")
        return

    for finding in findings:
        icon = "⚠️" if finding.kind == "stale" else "❌"
        console.print(f"{icon}  [bold]{finding.kind.upper()}[/bold]: {finding.section}")
        console.print(f"   {finding.description}")
        if finding.suggestion:
            console.print(f"   [green]→ {finding.suggestion}[/green]")
        console.print()


# ---------------------------------------------------------------------------
# Scan result persistence
# ---------------------------------------------------------------------------

AI_HABITS_DIR = Path.home() / ".ai-habits"


def save_scan_results(patterns: list[Pattern]) -> Path:
    """Persist scan results to ~/.ai-habits/last_scan.json.

    Returns the path of the saved file.
    """
    AI_HABITS_DIR.mkdir(parents=True, exist_ok=True)
    output_path = AI_HABITS_DIR / "last_scan.json"

    data = {
        "saved_at": datetime.utcnow().isoformat() + "Z",
        "patterns": [_pattern_to_dict(p) for p in patterns],
    }
    output_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return output_path


def load_scan_results() -> list[dict]:
    """Load the last scan results from ~/.ai-habits/last_scan.json.

    Returns a list of pattern dicts, or empty list if none exist.
    """
    path = AI_HABITS_DIR / "last_scan.json"
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text())["patterns"]
    except Exception:
        return []


def _pattern_to_dict(pat: Pattern) -> dict:
    input_tok, output_tok = pat.wasted_tokens
    return {
        "id": pat.id,
        "label": pat.label,
        "category": pat.category,
        "size": pat.size,
        "sample_texts": pat.sample_texts,
        "dates": [d.isoformat() for d in pat.dates[:10]],
        "wasted_input_tokens": input_tok,
        "wasted_output_tokens": output_tok,
    }
