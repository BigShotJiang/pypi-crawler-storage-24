"""Conversation history scanners/adapters."""
