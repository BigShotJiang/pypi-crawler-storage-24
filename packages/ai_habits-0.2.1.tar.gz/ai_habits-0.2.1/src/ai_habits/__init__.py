"""ai-habits: AI workflow efficiency tool for developers."""

__version__ = "0.2.1"
