from numbers import Number
import os
import sys
import json
import shutil
import subprocess
import time
import fnmatch
import re
import requests

from pathlib import Path
from typing import List, Dict, Any
from urllib.parse import quote
from .enums import Format, SourceType, InputStemType, FrameRate, Language, VenueType
from .constants import (
    ENV_CODA_CLI_EXE,
    ENV_NO_CODA_EXE,
    ENV_CODA_API_GROUP_ID,
    DEFAULT_PROGRAM_ID,
    DEFAULT_BIT_DEPTH,
    DEFAULT_SAMPLE_RATE,
    URL_PREFIX_S3,
    URL_PREFIX_IO,
    URL_PREFIX_FILE,
)
from .utils import make_request, validate_group_id
from .preset import Preset


class Essence:
    """Single source essence for a Coda job.

    This class constructs the essence/s payload, which can
    consist of one or more media files (e.g., an interleaved WAV or a
    group of multi-mono WAVs).

    Attributes:
        payload (dict): The dictionary that holds the essence definition.

    """

    def __init__(
        self,
        format: Format,
        stem_type: InputStemType = InputStemType.PRINTMASTER,
        program: str = DEFAULT_PROGRAM_ID,
        description: str = "",
        timing_info: dict[str, str] | None = None
    ) -> None:
        """Initialize the CodaEssence object.

        Args:
            format (Format): The input audio format of the essence (e.g., "5.1", "7.1.2", "atmos").
            stem_type (InputStemType, optional): The type of input source stem (e.g., "audio/pm", "audio/dx").
                Defaults to InputStemType.PRINTMASTER.
            program (str, optional): The program identifier for the essence definition.
                Defaults to "program-1".
            description (str, optional): A human-readable description of the essence.
                Defaults to "".
            timing_info (dict, optional): Framerate, FFOA and LFOA info.

        Raises:
            ValueError: If format is an empty string.

        """
        if not format or not isinstance(format, str):
            raise ValueError("format must not be an empty string and must be a string type.")

        self.payload: Dict[str, Any] = {
            "type": "",
            "definition": {
                "format": format,
                "program": program,
                "description": description,
                "type": stem_type,
            }
        }

        if timing_info is not None:
            if timing_info.get("frame_rate"):
                self.payload["definition"]["frame_rate"] = timing_info.get("frame_rate")
            if timing_info.get("ffoa_timecode"):
                self.payload["definition"]["ffoa_timecode"] = timing_info.get("ffoa_timecode")
            if timing_info.get("lfoa_timecode"):
                self.payload["definition"]["lfoa_timecode"] = timing_info.get("lfoa_timecode")
            if timing_info.get("file_start_timecode"):
                self.payload["definition"]["file_start_timecode"] = timing_info.get("file_start_timecode")

    def __repr__(self):
        """Return the full internal state of the Essence as formatted JSON.

        Example::

            >>> repr(essence)
            'Essence:\\n{\\n  "type": "local",\\n  ...\\n}'
        """
        return f"Essence:\n{json.dumps(self.payload, indent=2, default=str)}"

    def add_interleaved_resource(
        self,
        file: str | dict,
        channel_selection: dict[str, int],
        channel_count: int,
        frames: int,
        bit_depth: int = DEFAULT_BIT_DEPTH,
        sample_rate: int = DEFAULT_SAMPLE_RATE,
        io_location_id: str | None = None
    ) -> None:
        """Configure the essence as a single interleaved resource.

        This sets the essence type to 'interleaved' and populates the definition
        with the properties of a single, multichannel media file.

        Args:
            file (str | dict): The filepath of the interleaved media file, or a dict containing a 'url' key.
                If a dict is passed in it will require a 'url' key to sepcify the location path.
                The dict can contain the optional keys 'auth' and 'opts' for resource authorization.
            channel_selection (dict[str, int]): A map of channel labels to their stream IDs.
            channel_count (int): The total number of channels in the file.
            frames (int): The duration of the file in frames.
            bit_depth (int, optional): The bit depth. Defaults to 24.
            sample_rate (int, optional): The sample rate. Defaults to 48000.
            io_location_id (str, optional): The IO Location ID associated with the source files. Required for agent transfers.

        Raises:
            TypeError: If channel_selection is not a dictionary.
            ValueError: If IO Location ID has not been provided for non-S3 sources.

        """
        if not isinstance(channel_selection, dict):
            raise TypeError("channel_selection must be a dictionary.")

        self.payload["type"] = SourceType.INTERLEAVED

        if isinstance(file, str):
            url = file
            auth = None
            opts = None
        else:
            url = file["url"]
            auth = file.get("auth")
            opts = file.get("opts")

        if URL_PREFIX_S3 not in url:
            if io_location_id is None:
                raise ValueError("IO Location ID is required for non-S3 file sources.")
            url = f"{URL_PREFIX_IO}{io_location_id}{url}"

        resource_dict: Dict[str, Any] = {"url": url}
        if auth is not None:
            resource_dict["auth"] = auth
        if opts is not None:
            resource_dict["opts"] = opts

        self.payload["definition"].update({
            "resource": resource_dict,
            "bit_depth": bit_depth,
            "sample_rate": sample_rate,
            "channel_count": channel_count,
            "frames": frames,
            "channel_selection": channel_selection.copy(),
        })

    def add_multi_mono_resources(
        self, files: List, frames: int, bit_depth: int = DEFAULT_BIT_DEPTH, sample_rate: int = DEFAULT_SAMPLE_RATE, io_location_id: str | None = None
    ) -> None:
        """Configure the essence as a group of multi-mono resources.

        This sets the essence type to 'multi_mono' and populates the definition
        with a list of single-channel media files that form a multichannel group.

        Args:
            files (list): A list of file URLs (or dicts with 'url' keys).
            frames (int): The duration of the files in frames.
            bit_depth (int, optional): The bit depth. Defaults to 24.
            sample_rate (int, optional): The sample rate. Defaults to 48000.
            io_location_id (str, optional): The IO Location ID associated with the source files. Required for agent transfers.

        Raises:
            TypeError: If files is not a list.
            ValueError: If the number of provided files does not match the
                channel count implied by the essence's format.
            ValueError: If IO Location ID has not been provided for non-S3 sources.

        """
        if not isinstance(files, list):
            raise TypeError("files must be provided as a list.")

        stem_format = self.payload["definition"]["format"]
        if stem_format != Format.ATMOS:
            try:
                expected_channels = sum(int(p) for p in stem_format.split('.'))
                actual_channels = len(files)
                if actual_channels != expected_channels:
                    raise ValueError(
                        f"Channel count mismatch for format '{stem_format}': "
                        f"Expected {expected_channels} files for multi-mono resources, but received {actual_channels}."
                    )
            except (ValueError, TypeError) as e:
                if isinstance(e, ValueError) and "Channel count mismatch" in str(e):
                    raise e
                print(
                    f"Warning: Could not validate channel count for format '{stem_format}'.",
                    file=sys.stderr,
                )

        self.payload["type"] = SourceType.MULTI_MONO.value
        self.payload["definition"]["resources"] = []
        for file_entry in files:
            if isinstance(file_entry, str):
                url = file_entry
                auth = None
                opts = None
                label = ""
            else:
                url = file_entry["url"]
                auth = file_entry.get("auth")
                opts = file_entry.get("opts")
                label = file_entry.get("channel_label", "")

            if not label:
                ch_labels = [
                    "Lsr", "Rsr", "Lts", "Rts", "Lss", "Rss",
                    "Lfe", "Ls", "Rs", "L", "C", "R",
                ]
                for ch in ch_labels:
                    if "." + ch.upper() + "." in url.upper():
                        label = "LFE" if ch == "Lfe" else ch.capitalize()
                        break

            if URL_PREFIX_S3 not in url:
                if io_location_id is None:
                    raise ValueError("IO Location ID is required for non-S3 file sources.")
                url = f"{URL_PREFIX_IO}{io_location_id}{url}"

            res: Dict[str, Any] = {
                "resource": {"url": url},
                "bit_depth": bit_depth,
                "sample_rate": sample_rate,
                "channel_count": 1,
                "frames": frames,
                "channel_label": label,
                "bext_time_reference": 0,
            }
            if auth is not None:
                res["resource"]["auth"] = auth
            if opts is not None:
                res["resource"]["opts"] = opts
            self.payload["definition"]["resources"].append(res)

    def override_stem_type(self, stem_type: InputStemType) -> None:
        """Override the stem type of the essence input source.

        Args:
            stem_type: The type of input source stem (e.g., "audio/pm", "audio/dx").

        """
        self.payload["definition"]["type"] = stem_type

    def override_program(self, program: str) -> None:
        """Override the program identifier of the essence.

        Args:
            program (str): The program identifier for the essence definition.

        """
        self.payload["definition"]["program"] = program

    def override_format(self, format: Format) -> None:
        """Override the audio format of the essence input source.

        Args:
            format (Format): The input audio format of the essence (e.g., "5.1", "7.1.2", "atmos").

        """
        self.payload["definition"]["format"] = format

    def override_language(self, language: Language) -> None:
        """Override the language of the essence.

        Args:
            language: The language for the essence (e.g., Language.ENGLISH).

        """
        self.payload["definition"]["language"] = language

    def override_venue(self, venue: VenueType) -> None:
        """Override the venue of the essence.

        Args:
            venue: The venue for the essence (e.g., VenueType.NEARFIELD).

        """
        self.payload["definition"]["venue"] = venue

    def override_timing_info(
        self,
        frame_rate: FrameRate | None = None,
        ffoa_timecode: str | None = None,
        lfoa_timecode: str | None = None,
        file_start_timecode: str | None = None,
        head_leader_length: int | None = None,
        tail_leader_length: int | None = None
    ) -> None:
        """Override timing information for the essence.

        Timing parameters come in two mutually exclusive groups. When using either group,
        ALL parameters in that group must be provided:
        - Timecode-based: frame_rate, ffoa_timecode, lfoa_timecode, file_start_timecode (all four required together)
        - Offset-based: frame_rate, head_leader_length, tail_leader_length (all three required together)

        Args:
            frame_rate (FrameRate, optional): The source frame rate. Required with all timing groups.
            ffoa_timecode (str, optional): First frame of action timecode.
            lfoa_timecode (str, optional): Last frame of action timecode.
            file_start_timecode (str, optional): File start timecode.
            head_leader_length (int, optional): Head leader length in frames.
            tail_leader_length (int, optional): Tail leader length in frames.

        Raises:
            ValueError: If both timecode-based and offset-based parameters are provided.
            ValueError: If only some parameters from a group are provided.

        """
        # Define parameter groups (excluding frame_rate from the "other params" check)
        timecode_other_params = {
            "ffoa_timecode": ffoa_timecode,
            "lfoa_timecode": lfoa_timecode,
            "file_start_timecode": file_start_timecode
        }

        offset_other_params = {
            "head_leader_length": head_leader_length,
            "tail_leader_length": tail_leader_length
        }

        timecode_other_set = [k for k, v in timecode_other_params.items() if v is not None]
        offset_other_set = [k for k, v in offset_other_params.items() if v is not None]

        # Check if parameters from both groups are provided
        if timecode_other_set and offset_other_set:
            raise ValueError(
                "Timecode-based parameters (frame_rate, ffoa_timecode, lfoa_timecode, file_start_timecode) "
                "and offset-based parameters (frame_rate, head_leader_length, tail_leader_length) are mutually exclusive. "
                "Please provide only one type of timing parameter."
            )

        # Validate timecode group - if any timecode param is provided, all must be provided (including frame_rate)
        if timecode_other_set:
            full_timecode_params = {
                "frame_rate": frame_rate,
                "ffoa_timecode": ffoa_timecode,
                "lfoa_timecode": lfoa_timecode,
                "file_start_timecode": file_start_timecode
            }
            complete_timecode_set = [k for k, v in full_timecode_params.items() if v is not None]
            if len(complete_timecode_set) != len(full_timecode_params):
                missing = [k for k, v in full_timecode_params.items() if v is None]
                raise ValueError(
                    f"When using timecode-based parameters, all must be provided. "
                    f"Missing: {', '.join(missing)}"
                )

        # Validate offset group - if any offset param is provided, all must be provided (including frame_rate)
        if offset_other_set:
            full_offset_params = {
                "frame_rate": frame_rate,
                "head_leader_length": head_leader_length,
                "tail_leader_length": tail_leader_length
            }
            complete_offset_set = [k for k, v in full_offset_params.items() if v is not None]
            if len(complete_offset_set) != len(full_offset_params):
                missing = [k for k, v in full_offset_params.items() if v is None]
                raise ValueError(
                    f"When using offset-based parameters, all must be provided. "
                    f"Missing: {', '.join(missing)}"
                )

        # Check if frame_rate is provided alone (without any other timing params)
        if frame_rate is not None and not timecode_other_set and not offset_other_set:
            raise ValueError(
                "frame_rate cannot be used alone. It must be provided as part of either: "
                "timecode-based parameters (frame_rate, ffoa_timecode, lfoa_timecode, file_start_timecode) or "
                "offset-based parameters (frame_rate, head_leader_length, tail_leader_length)."
            )

        if frame_rate is not None:
            self.payload["definition"]["frame_rate"] = frame_rate

        # For timecode based settings
        if ffoa_timecode is not None:
            self.payload["definition"]["ffoa_timecode"] = ffoa_timecode
            self.payload["definition"]["lfoa_timecode"] = lfoa_timecode
            self.payload["definition"]["file_start_timecode"] = file_start_timecode

        # For offset based settings
        if head_leader_length is not None:
            # Remove any set timecode settings just in case
            self.payload["definition"].pop("ffoa_timecode", None)
            self.payload["definition"].pop("lfoa_timecode", None)
            self.payload["definition"].pop("file_start_timecode", None)

            # Set the offest values
            self.payload["definition"]["head_leader_length"] = head_leader_length
            self.payload["definition"]["tail_leader_length"] = tail_leader_length

    def override_bext_time_reference(self, bext_time_reference: int) -> None:
        """Set BEXT time reference on all resources.

        Args:
            bext_time_reference (int): The BEXT time reference value.

        """
        for resource in self.payload["definition"]["resources"]:
            resource["bext_time_reference"] = bext_time_reference

    @staticmethod
    def essences_from_files(
        files: list,
        io_location_id: str | None = None,
        file_info: dict | None = None,
        program: str = "",
        forced_frame_rate: str | None = None,
        no_file_scan: bool = False
    ) -> list["Essence"]:
        """Create a list of CodaEssence objects from files.

        Note: this method only supports multi-mono file sets.

        This method inspects local files using the 'coda inspect' command-line tool
        to automatically determine their properties. For S3 files or when the CLI
        is unavailable, it relies on the `file_info` dictionary for manual creation.

        Args:
            files (List): A list of file paths.
            io_location_id (str, optional): The IO Location ID associated with the source files. Required for agent transfers.
            file_info (dict, optional): Manual override info for files. Required for S3.
                Should contain keys like 'format', 'type', 'frames', 'auth'. Defaults to None.
                Examples: file_info = {
                            "frames": 720000,
                            "format": Format.SEVEN_ONE,
                            "type": InputStemType.PRINTMASTER,
                            "auth": {
                                "iam_role": os.getenv(ENV_S3_ROLE, "XXXX"),
                                "iam_external_id": os.getenv(ENV_S3_EXTERNAL_ID, "XXXX"),
                            },
                            "opts": {"region": "us-west-2"},
                        }

                        Note: `auth` may also use S3 access key secret and ID
                        "auth": {
                            "access_key_id": os.getenv(ENV_S3_ACCESS_KEY_ID, "XXXX"),
                            "secret_access_key": os.getenv(ENV_S3_SECRET_ACCESS_KEY, "XXXX"),
                        }
            program (str, optional): The program identifier to assign to the essences.
                Defaults to "".
            forced_frame_rate (str, optional): Specify the frame rate to calculate the FFOA and LFOA
            no_file_scan (bool, optional): Do not use Coda CLI to scan files for metadata

        Raises:
            ValueError: If `files` is not populated with a list of file paths.
            ValueError: If the 'coda' CLI tool is required but not found, or if
                the inspection process fails.
            ValueError: If the 'coda inspect' CLI tool does not return sources info.
            ValueError: If S3 files are provided without a `file_info` dictionary.
            ValueError: If IO Location ID has not been provided for non-S3 sources.
            ValueError: If CODA_API_GROUP_ID has not been set for using `coda inspect`.

        Returns:
            List[CodaEssence]: A list of CodaEssence objects.

        """
        if not files:
            raise ValueError("Files must contain a list of file paths.")

        local_files = [f for f in files if URL_PREFIX_S3 not in str(f)]
        s3_files = [f for f in files if URL_PREFIX_S3 in str(f)]
        essences = []

        if local_files:
            if io_location_id is None:
                raise ValueError("IO Location ID must be filled to use supplied files.")

            absfiles = [str(Path(f).resolve()) for f in local_files]
            codaexe = shutil.which("coda") or os.getenv(ENV_CODA_CLI_EXE)
            if not codaexe or os.getenv(ENV_NO_CODA_EXE) is not None or no_file_scan is True:
                if not file_info:
                    raise ValueError("Coda CLI not found and file_info was not provided for manual creation.")

                print("Creating essence manually from file_info.", file=sys.stderr)

                essence = Essence(file_info["format"], stem_type=file_info["type"], program=program)
                res = [{"url": url} for url in absfiles]
                essence.add_multi_mono_resources(res, frames=file_info["frames"], io_location_id=io_location_id)
                essences.append(essence)
            else:
                try:
                    group_id = os.getenv(ENV_CODA_API_GROUP_ID)
                    if not group_id:
                        raise ValueError("CODA_API_GROUP_ID must be set. Use workflow.with_group() for convenience.")

                    print(f"coda inspect scanning {len(absfiles)} files", file=sys.stderr)
                    print(f"using coda cli: {codaexe}", file=sys.stderr)

                    args = [codaexe, "inspect", "--group-id", group_id, "--io-location-id", io_location_id]
                    if forced_frame_rate:
                        args = [
                            *args,
                            "--frame-rate",
                            forced_frame_rate,
                        ]
                    args = [*args, *absfiles]

                    ret = subprocess.run(
                        args,
                        shell=False,
                        check=True,
                        capture_output=True,
                        text=True,
                    )

                    j = json.loads(ret.stdout)
                    if not j.get("sources"):
                        raise ValueError("`coda inspect` was unable to retrieve the sources information.")

                    essences.extend(_build_essences_from_profile(j, program=program))

                except subprocess.CalledProcessError as e:
                    error_message = (
                        f"The 'coda inspect' command failed with exit code {e.returncode}.\n"
                        f"--- STDOUT ---\n{e.stdout}\n"
                        f"--- STDERR ---\n{e.stderr}\n"
                    )
                    raise ValueError(error_message) from e
                except Exception as e:
                    raise ValueError(f"An unexpected error occurred during 'coda inspect': {e}") from e

        if s3_files:
            print(f"Adding {len(s3_files)} S3 files", file=sys.stderr)
            if not file_info:
                raise ValueError("file_info must be provided for S3 files.")

            essence = Essence(
                file_info["format"], stem_type=file_info["type"], program=program
            )

            res = [
                {
                    "url": r,
                    "auth": file_info.get("auth"),
                    "opts": file_info.get("opts"),
                }
                for r in s3_files
            ]
            essence.add_multi_mono_resources(res, frames=file_info["frames"])
            essences.append(essence)

        return essences

    @staticmethod
    def list_files(
        io_location_name: str | None = None,
        io_location_id: str | None = None,
        path: str = "/",
        pattern: str | None = None,
        regex: str | None = None
    ) -> list[str]:
        """List files at a path within an IO Location.

        Args:
            io_location_name (str | None, optional): The human-readable name of the
                IO Location. Mutually exclusive with io_location_id.
            io_location_id (str | None, optional): The IO Location ID. Mutually
                exclusive with io_location_name.
            path (str, optional): The directory path within the IO Location to list.
                Defaults to "/".
            pattern (str | None, optional): A shell-style glob pattern (e.g., "*.wav")
                to filter the returned filenames. Mutually exclusive with regex.
                Defaults to None (return all files).
            regex (str | None, optional): A regular expression pattern (e.g.,
                r".*_PM_.*\\.wav$") to filter the returned filenames using
                re.search(). Mutually exclusive with pattern.
                Defaults to None (return all files).

        Returns:
            list[str]: A list of filename strings at the given path. If pattern or
                regex is provided, only filenames matching the filter are returned.

        Raises:
            ValueError: If both pattern and regex are provided.
            ValueError: If both io_location_name and io_location_id are provided.
            ValueError: If neither io_location_name nor io_location_id is provided.
            ValueError: If CODA_API_GROUP_ID is not set.
            CodaAPIError: If the API request fails.

        """
        if pattern and regex:
            raise ValueError("Provide either pattern or regex, not both.")
        resolved_id = _resolve_io_location_id(io_location_name, io_location_id)
        group_id = validate_group_id()
        encoded_path = quote(path, safe="")
        ret = make_request(
            requests.get,
            f"/interface/v2/groups/{group_id}/io-locations/{resolved_id}/files/{encoded_path}"
        )
        filenames = ret.json()["files"]
        if pattern:
            filenames = fnmatch.filter(filenames, pattern)
        elif regex:
            compiled = re.compile(regex)
            filenames = [f for f in filenames if compiled.search(f)]
        return filenames

    @staticmethod
    def list_folders(
        io_location_name: str | None = None,
        io_location_id: str | None = None,
        path: str = "/"
    ) -> list[str]:
        """List folders at a path within an IO Location.

        Args:
            io_location_name (str | None, optional): The human-readable name of the
                IO Location. Mutually exclusive with io_location_id.
            io_location_id (str | None, optional): The IO Location ID. Mutually
                exclusive with io_location_name.
            path (str, optional): The directory path within the IO Location to list.
                Defaults to "/".

        Returns:
            list[str]: A list of folder name strings at the given path.

        Raises:
            ValueError: If both io_location_name and io_location_id are provided.
            ValueError: If neither io_location_name nor io_location_id is provided.
            ValueError: If CODA_API_GROUP_ID is not set.
            CodaAPIError: If the API request fails.

        """
        resolved_id = _resolve_io_location_id(io_location_name, io_location_id)
        group_id = validate_group_id()
        encoded_path = quote(path, safe="")
        ret = make_request(
            requests.get,
            f"/interface/v2/groups/{group_id}/io-locations/{resolved_id}/folders/{encoded_path}"
        )
        return ret.json()["folders"]

    @staticmethod
    def discover_files(
        io_location_name: str | None = None,
        io_location_id: str | None = None,
        files: list | None = None,
        poll_rate: int = 4
    ) -> dict:
        """Submit files for metadata discovery and return parsed profile data.

        Constructs full file URLs from the IO Location's base URL, submits them
        to the Coda discovery API, polls until the discovery job completes, then
        fetches and returns the parsed input profile data.

        Args:
            io_location_name (str | None, optional): The human-readable name of the
                IO Location. Mutually exclusive with io_location_id.
            io_location_id (str | None, optional): The IO Location ID. Mutually
                exclusive with io_location_name.
            files (list | None, optional): A list of relative file paths or filenames to
                submit for discovery. Defaults to None (treated as empty list).
            poll_rate (int, optional): Seconds between discovery status polls.
                Defaults to 4.

        Returns:
            dict: The parsed input profile data from the Coda API, containing
                source metadata such as format, stem type, and timing information.

        Raises:
            ValueError: If both io_location_name and io_location_id are provided.
            ValueError: If neither io_location_name nor io_location_id is provided.
            ValueError: If CODA_API_GROUP_ID is not set.
            TimeoutError: If the discovery job does not complete within the timeout.
            CodaAPIError: If any API request fails.

        """
        if files is None:
            files = []
        resolved_id = _resolve_io_location_id(io_location_name, io_location_id)
        group_id = validate_group_id()
        ret = make_request(
            requests.get,
            f"/interface/v2/groups/{group_id}/io-locations/{resolved_id}"
        )
        io_location_url = ret.json()["url"]
        base_path = _get_discovery_base_path(io_location_url)
        full_urls = []
        for f in files:
            sep = "" if base_path.endswith("/") else "/"
            full_urls.append(base_path + sep + f.lstrip("/"))

        ret = make_request(
            requests.post,
            f"/interface/v2/groups/{group_id}/io-locations/{resolved_id}/discovery",
            payload={"urls": full_urls}
        )
        discovery_id = ret.json()["discovery_id"]
        input_profile_id = _poll_discovery(group_id, resolved_id, discovery_id, interval=poll_rate)
        ret = make_request(
            requests.get,
            f"/interface/v2/input-profiles/{input_profile_id}/parse"
        )
        return ret.json()["parsed_input_profile"]

    @staticmethod
    def essences_from_io_location(
        io_location_name: str | None = None,
        io_location_id: str | None = None,
        path: str = "/",
        pattern: str | None = None,
        regex: str | None = None,
        discovery_poll_rate: int = 4
    ) -> list["Essence"]:
        """List files, discover metadata, and build Essence objects from an IO Location.

        This is a high-level convenience method that combines list_files(),
        discover_files(), and _build_essences_from_profile() into a single call.

        Args:
            io_location_name (str | None, optional): The human-readable name of the
                IO Location. Mutually exclusive with io_location_id.
            io_location_id (str | None, optional): The IO Location ID. Mutually
                exclusive with io_location_name.
            path (str, optional): The directory path within the IO Location to list
                files from. Defaults to "/".
            pattern (str | None, optional): A shell-style glob pattern (e.g., "*.wav")
                to filter files before submitting for discovery. Mutually exclusive
                with regex. Defaults to None.
            regex (str | None, optional): A regular expression pattern (e.g.,
                r".*_PM_.*\\.wav$") to filter files before submitting for discovery.
                Mutually exclusive with pattern. Defaults to None.
            discovery_poll_rate (int, optional): Seconds between discovery status
                polls. Defaults to 4.

        Returns:
            list[Essence]: A list of Essence objects built from the discovered
                file metadata.

        Raises:
            ValueError: If both pattern and regex are provided.
            ValueError: If both io_location_name and io_location_id are provided.
            ValueError: If neither io_location_name nor io_location_id is provided.
            ValueError: If CODA_API_GROUP_ID is not set.
            TimeoutError: If the discovery job does not complete within the timeout.
            CodaAPIError: If any API request fails.

        """
        resolved_id = _resolve_io_location_id(io_location_name, io_location_id)
        filenames = Essence.list_files(io_location_id=resolved_id, path=path, pattern=pattern, regex=regex)
        files_with_path = [path.rstrip("/") + "/" + f for f in filenames]
        profile_data = Essence.discover_files(io_location_id=resolved_id, files=files_with_path, poll_rate=discovery_poll_rate)
        return _build_essences_from_profile(profile_data)

    def dict(self) -> dict:
        """Return the final payload dictionary for the essence.

        Performs a validation check to ensure the number of resource files or
        channel selections matches the channel count specified by the audio format.

        Raises:
            ValueError: If the number of files/channels doesn't match the format's channel count.

        Returns:
            dict: The essence payload dictionary.

        """
        definition = self.payload["definition"]
        if definition.get("format") in [Format.ATMOS, Format.IMAX5, Format.IMAX6, Format.IMAX12]:
            return self.payload

        try:
            expected_channels = sum(int(e) for e in definition["format"].split("."))
            actual_channels = 0

            if "resources" in definition:
                actual_channels = len(definition["resources"])
            elif "channel_selection" in definition:
                actual_channels = len(definition["channel_selection"])

            if actual_channels > 0 and actual_channels != expected_channels:
                raise ValueError(
                    f"Channel count mismatch for format '{definition['format']}': "
                    f"Expected {expected_channels} channels, but found {actual_channels}."
                )

        except (ValueError, TypeError) as e:
            if isinstance(e, ValueError) and "Channel count mismatch" in str(e):
                raise e
            print(
                f"Warning: Could not validate channel count for format '{definition['format']}'.",
                file=sys.stderr,
            )

        return self.payload


def _resolve_io_location_id(io_location_name: str | None, io_location_id: str | None) -> str:
    """Resolve an IO Location ID from either a name or a direct ID.

    Args:
        io_location_name (str | None): The human-readable name of the IO Location.
        io_location_id (str | None): The direct IO Location ID.

    Returns:
        str: The resolved IO Location ID.

    Raises:
        ValueError: If both io_location_name and io_location_id are provided.
        ValueError: If neither io_location_name nor io_location_id is provided.

    """
    if io_location_name is not None and io_location_id is not None:
        raise ValueError("Provide either io_location_name or io_location_id, not both.")
    if io_location_name is not None:
        return Preset.get_io_location_id_by_name(io_location_name)
    if io_location_id is not None:
        return io_location_id
    raise ValueError("One of io_location_name or io_location_id is required.")


def _get_discovery_base_path(io_location_url: str) -> str:
    """Convert an IO Location URL to a base path for discovery URL construction.

    Args:
        io_location_url (str): The URL of the IO Location (e.g., "file:///data/wanda"
            or "s3://bucket/coda/wanda").

    Returns:
        str: The base path suitable for constructing full file discovery URLs.
            For file:// URLs, returns the path after stripping the prefix.
            For all other schemes (including s3://), returns the URL as-is.

    """
    if io_location_url.startswith(URL_PREFIX_FILE):
        return io_location_url[len(URL_PREFIX_FILE):]
    return io_location_url


def _poll_discovery(group_id: str, io_location_id: str, discovery_id: str, timeout: int = 300, interval: int = 4) -> str:
    """Poll the discovery endpoint until it completes, then return the input profile ID.

    Args:
        group_id (str): The Coda group ID.
        io_location_id (str): The IO Location ID used for the discovery request.
        discovery_id (str): The discovery job ID returned from the initial POST.
        timeout (int, optional): Maximum number of seconds to wait. Defaults to 300.
        interval (int, optional): Seconds to sleep between polls. Defaults to 4.

    Returns:
        str: The input_profile_id once discovery completes.

    Raises:
        TimeoutError: If the discovery does not complete within the timeout period.

    """
    elapsed = 0
    while elapsed < timeout:
        ret = make_request(
            requests.get,
            f"/interface/v2/groups/{group_id}/io-locations/{io_location_id}/discovery/{discovery_id}"
        )
        j = ret.json()
        if j.get("complete") is True:
            if "error" in j:
                raise RuntimeError(f"Discovery failed: {j['error']}")
            return j["input_profile_id"]
        time.sleep(interval)
        elapsed += interval
    raise TimeoutError(f"Discovery timed out after {timeout} seconds.")


def _build_essences_from_profile(profile_data: dict, program: str = "") -> list["Essence"]:
    """Build a list of Essence objects from parsed profile data.

    This function converts the output of the `coda inspect` command (or equivalent
    API response) into a list of Essence objects ready for use in a job payload.

    Args:
        profile_data (dict): Parsed profile data in the same schema as `coda inspect`
            output. Expected keys include 'source_frame_rate', 'ffoa_timecode',
            'lfoa_timecode', 'file_start_timecode', and 'sources'.
        program (str, optional): Default program identifier to assign to each
            essence if none is found in the profile data. Defaults to "".

    Returns:
        list: A list of Essence objects constructed from the profile data.

    """
    timing_info: dict[str, str] = {
        k: v for k, v in {
            "frame_rate": profile_data.get("source_frame_rate"),
            "ffoa_timecode": profile_data.get("ffoa_timecode"),
            "lfoa_timecode": profile_data.get("lfoa_timecode"),
            "file_start_timecode": profile_data.get("file_start_timecode"),
        }.items() if v is not None
    }
    essences = []
    for source in profile_data.get("sources", []):
        source_type = source.get("type")
        source_def = source.get("definition")

        format_value = source_def.get("format", "")
        if not format_value and source_type in [SourceType.ADM, SourceType.IAB_MXF]:
            format_value = Format.ATMOS

        essence = Essence(
            format=format_value,
            stem_type=source_def.get("type"),
            program=source_def.get("program", program),
            description=source_def.get("description"),
            timing_info=timing_info,
        )
        essence.payload["type"] = source_type
        for key, value in source_def.items():
            essence.payload["definition"][key] = value
        essences.append(essence)
    return essences



