"""
Comprehensive unit tests for cobweb-py 0.1.3.

Tests cover:
  - Package imports and __version__
  - client.py: _pick_col, _df_to_ohlc_rows, _to_rows, _normalize_ohlcv_keys,
                BacktestConfig, CobwebSim signal validation
  - scoring.py: FEATURES/PLOTS dicts, _to_df, zscore, score, score_by_id,
                auto_score, list_features, list_plots, _resolve_plot_id,
                _resolve_category, show_features, show_plots
  - utils.py: fix_timestamps, load_csv, align, to_signals, get_signal, save_table
  - plots.py: _to_df, _as_float_matrix, _label, payload_to_figure, payloads_to_figures
  - easy.py: _ensure_feature_deps, Pipeline.__init__

Run with:
    python -m pytest tests/test_cobweb.py -v
"""
from __future__ import annotations

import math
import warnings
from io import StringIO
from pathlib import Path
from typing import Any, Dict, List
from unittest.mock import patch, MagicMock

import pandas as pd
import pytest


# ---------------------------------------------------------------------------
# 1. Package imports and __version__
# ---------------------------------------------------------------------------
class TestPackageInit:
    def test_version_string(self):
        import cobweb_py
        assert hasattr(cobweb_py, "__version__")
        assert cobweb_py.__version__ == "0.1.3"

    def test_public_exports(self):
        import cobweb_py
        expected = [
            "CobwebSim", "CobwebError", "BacktestConfig",
            "FEATURES", "PLOTS",
            "score", "score_by_id", "auto_score", "auto_score_by_id",
            "list_features", "list_plots",
            "show_features", "show_plots", "show_categories",
            "FEATURE_CATS", "PLOT_CATS",
            "save_table", "fix_timestamps", "load_csv", "align",
            "to_signals", "get_plot", "save_all_plots",
            "get_signal", "print_signal",
            "payload_to_figure", "payloads_to_figures",
            "quickstart", "Pipeline",
        ]
        for name in expected:
            assert hasattr(cobweb_py, name), f"Missing export: {name}"


# ---------------------------------------------------------------------------
# 2. client.py
# ---------------------------------------------------------------------------
class TestPickCol:
    def test_basic_lookup(self):
        from cobweb_py.client import _pick_col
        lower_map = {"open": "Open", "close": "Close"}
        assert _pick_col(lower_map, "open") == "Open"
        assert _pick_col(lower_map, "close") == "Close"

    def test_fallback_names(self):
        from cobweb_py.client import _pick_col
        lower_map = {"vol": "Vol"}
        assert _pick_col(lower_map, "volume", "vol") == "Vol"

    def test_missing_returns_none(self):
        from cobweb_py.client import _pick_col
        lower_map = {"open": "open"}
        assert _pick_col(lower_map, "missing_col") is None


class TestDfToOhlcRows:
    def _make_df(self, n=25):
        return pd.DataFrame({
            "Open": [100.0 + i for i in range(n)],
            "High": [105.0 + i for i in range(n)],
            "Low": [95.0 + i for i in range(n)],
            "Close": [102.0 + i for i in range(n)],
            "Volume": [1000 + i for i in range(n)],
            "timestamp": [f"2024-01-{i+1:02d}" for i in range(n)],
        })

    def test_basic_conversion(self):
        from cobweb_py.client import _df_to_ohlc_rows
        df = self._make_df()
        rows = _df_to_ohlc_rows(df)
        assert len(rows) == 25
        assert "open" in rows[0]
        assert "high" in rows[0]
        assert "low" in rows[0]
        assert "close" in rows[0]
        assert "volume" in rows[0]
        assert "timestamp" in rows[0]

    def test_missing_columns_raises(self):
        from cobweb_py.client import _df_to_ohlc_rows, CobwebError
        df = pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6]})
        with pytest.raises(CobwebError, match="Missing required columns"):
            _df_to_ohlc_rows(df)

    def test_too_few_rows_raises(self):
        from cobweb_py.client import _df_to_ohlc_rows, CobwebError
        df = self._make_df(n=5)
        with pytest.raises(CobwebError, match="at least 20"):
            _df_to_ohlc_rows(df)

    def test_nan_volume_excluded(self):
        from cobweb_py.client import _df_to_ohlc_rows
        df = self._make_df()
        df.loc[0, "Volume"] = float("nan")
        rows = _df_to_ohlc_rows(df)
        assert "volume" not in rows[0]  # NaN volume excluded
        assert "volume" in rows[1]      # valid volume kept


class TestToRows:
    def _make_rows(self, n=25):
        return [
            {"open": 100+i, "high": 105+i, "low": 95+i, "close": 102+i, "volume": 1000+i}
            for i in range(n)
        ]

    def test_list_of_dicts(self):
        from cobweb_py.client import _to_rows
        rows = self._make_rows()
        result = _to_rows(rows)
        assert len(result) == 25

    def test_dict_with_rows_key(self):
        from cobweb_py.client import _to_rows
        data = {"rows": self._make_rows()}
        result = _to_rows(data)
        assert len(result) == 25

    def test_dataframe_input(self):
        from cobweb_py.client import _to_rows
        df = pd.DataFrame({
            "Open": [100.0 + i for i in range(25)],
            "High": [105.0 + i for i in range(25)],
            "Low": [95.0 + i for i in range(25)],
            "Close": [102.0 + i for i in range(25)],
        })
        result = _to_rows(df)
        assert len(result) == 25

    def test_unsupported_type_raises(self):
        from cobweb_py.client import _to_rows, CobwebError
        with pytest.raises(CobwebError, match="Unsupported"):
            _to_rows(42)


class TestNormalizeOhlcvKeys:
    def test_already_lowercase(self):
        from cobweb_py.client import _normalize_ohlcv_keys
        rows = [{"open": 1, "close": 2}]
        assert _normalize_ohlcv_keys(rows) == rows

    def test_uppercase_normalized(self):
        from cobweb_py.client import _normalize_ohlcv_keys
        rows = [{"Open": 1, "Close": 2, "custom_col": 99}]
        result = _normalize_ohlcv_keys(rows)
        assert "open" in result[0]
        assert "close" in result[0]
        assert "custom_col" in result[0]


class TestBacktestConfig:
    def test_default_values(self):
        from cobweb_py.client import BacktestConfig
        cfg = BacktestConfig()
        assert cfg.initial_cash == 10_000.0
        assert cfg.fee_bps == 1.0

    def test_to_dict(self):
        from cobweb_py.client import BacktestConfig
        cfg = BacktestConfig(initial_cash=50_000)
        d = cfg.to_dict()
        assert d["initial_cash"] == 50_000
        assert isinstance(d, dict)


# ---------------------------------------------------------------------------
# 3. scoring.py
# ---------------------------------------------------------------------------
class TestFeaturesDicts:
    def test_features_has_71_entries(self):
        from cobweb_py.scoring import FEATURES
        assert len(FEATURES) == 71

    def test_plots_has_27_entries(self):
        from cobweb_py.scoring import PLOTS
        assert len(PLOTS) == 27

    def test_feature_ids_1_to_71(self):
        from cobweb_py.scoring import FEATURES
        assert set(FEATURES.keys()) == set(range(1, 72))

    def test_plot_ids_1_to_27(self):
        from cobweb_py.scoring import PLOTS
        assert set(PLOTS.keys()) == set(range(1, 28))


class TestScoringToDf:
    def test_list_of_dicts(self):
        from cobweb_py.scoring import _to_df
        df = _to_df([{"a": 1, "b": 2}, {"a": 3, "b": 4}])
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2

    def test_dict_with_rows(self):
        from cobweb_py.scoring import _to_df
        df = _to_df({"rows": [{"a": 1}, {"a": 2}]})
        assert len(df) == 2

    def test_dataframe_passthrough(self):
        from cobweb_py.scoring import _to_df
        orig = pd.DataFrame({"x": [1, 2, 3]})
        df = _to_df(orig)
        assert len(df) == 3
        # Should be a copy, not the same object
        assert df is not orig

    def test_invalid_input_raises(self):
        from cobweb_py.scoring import _to_df
        with pytest.raises(ValueError):
            _to_df(42)


class TestZscore:
    def test_normal_values(self):
        from cobweb_py.scoring import zscore
        s = pd.Series([1, 2, 3, 4, 5])
        z = zscore(s)
        assert abs(z.mean()) < 1e-10  # mean should be ~0

    def test_constant_series(self):
        from cobweb_py.scoring import zscore
        s = pd.Series([5, 5, 5, 5])
        z = zscore(s)
        # constant series -> std=0 -> all zeros
        assert all(v == 0.0 for v in z)


class TestScore:
    def _make_rows(self, n=50):
        return [
            {
                "ret_1d": 0.01 * (i % 10 - 5),
                "rsi_14": 30 + i,
                "sma_20": 100 + i * 0.5,
                "close": 100 + i * 0.5 + 1,
            }
            for i in range(n)
        ]

    def test_basic_score(self):
        from cobweb_py.scoring import score
        rows = self._make_rows()
        weights = {"ret_1d": 0.5, "rsi_14": 0.5}
        result = score(rows, weights)
        assert len(result) == 50
        assert all(isinstance(v, float) for v in result)

    def test_missing_column_warns(self):
        from cobweb_py.scoring import score
        rows = self._make_rows()
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = score(rows, {"nonexistent_col": 1.0})
            assert len(w) >= 1
            assert "not found" in str(w[0].message)
        assert len(result) == 50

    def test_empty_weights(self):
        from cobweb_py.scoring import score
        rows = self._make_rows()
        result = score(rows, {})
        assert all(v == 0.0 for v in result)

    def test_rsi_to_unit(self):
        from cobweb_py.scoring import score
        rows = [{"rsi_14": 70.0} for _ in range(25)]
        result = score(rows, {"rsi_14": 1.0}, normalize=False, rsi_to_unit=True)
        # RSI 70 -> 0.70
        assert all(abs(v - 0.70) < 1e-6 for v in result)


class TestScoreById:
    def test_basic_score_by_id(self):
        from cobweb_py.scoring import score_by_id
        rows = [
            {"ret_1d": 0.01, "rsi_14": 50, "close": 100, "sma_20": 99}
            for _ in range(30)
        ]
        result = score_by_id(rows, {36: 0.3, 1: 0.4})
        assert len(result) == 30

    def test_invalid_id_warns(self):
        from cobweb_py.scoring import score_by_id
        rows = [{"ret_1d": 0.01} for _ in range(25)]
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            score_by_id(rows, {999: 1.0})
            assert any("not recognised" in str(warning.message) for warning in w)

    def test_ma_id_uses_signal(self):
        from cobweb_py.scoring import score_by_id
        rows = [
            {"ret_1d": 0.01, "close": 105, "sma_20": 100}
            for _ in range(25)
        ]
        # feature 11 = sma_20, should be converted to sma_signal
        result = score_by_id(rows, {11: 1.0}, normalize=False, rsi_to_unit=False)
        assert len(result) == 25
        # sma_signal = (close - sma_20) / sma_20 = (105-100)/100 = 0.05
        assert abs(result[0] - 0.05) < 1e-6


class TestAutoScore:
    def test_auto_score_runs(self):
        from cobweb_py.scoring import auto_score
        rows = [
            {"ret_1d": 0.01, "rsi_14": 50, "close": 100, "sma_20": 99}
            for _ in range(30)
        ]
        result = auto_score(rows)
        assert len(result) == 30


class TestListFeaturesPlots:
    def test_list_features_all(self):
        from cobweb_py.scoring import list_features
        features = list_features()
        assert len(features) == 71

    def test_list_features_by_category(self):
        from cobweb_py.scoring import list_features
        rsi_features = list_features("rsi")
        assert len(rsi_features) == 2  # rsi_14 and rsi_pct_252

    def test_list_plots_all(self):
        from cobweb_py.scoring import list_plots
        plots = list_plots()
        assert len(plots) == 27

    def test_list_plots_by_category(self):
        from cobweb_py.scoring import list_plots
        trade_plots = list_plots("trades")
        assert len(trade_plots) == 4  # plots 16-19


class TestResolvePlotId:
    def test_exact_match(self):
        from cobweb_py.scoring import _resolve_plot_id
        assert _resolve_plot_id("equity_curve_linear") == 1

    def test_fuzzy_prefix(self):
        from cobweb_py.scoring import _resolve_plot_id
        assert _resolve_plot_id("rolling_sharpe") == 5

    def test_ambiguous_raises(self):
        from cobweb_py.scoring import _resolve_plot_id
        with pytest.raises(ValueError, match="Ambiguous"):
            _resolve_plot_id("equity")  # matches equity_curve_linear and equity_curve_log

    def test_no_match_raises(self):
        from cobweb_py.scoring import _resolve_plot_id
        with pytest.raises(ValueError, match="No plot matched"):
            _resolve_plot_id("nonexistent_plot_xyz")


class TestResolveCategory:
    def test_exact(self):
        from cobweb_py.scoring import _resolve_category, FEATURE_CATS
        result = _resolve_category("rsi", FEATURE_CATS)
        assert result == ["rsi"]

    def test_prefix(self):
        from cobweb_py.scoring import _resolve_category, FEATURE_CATS
        result = _resolve_category("vol", FEATURE_CATS)
        assert "volatility" in result
        assert "volume" in result


# ---------------------------------------------------------------------------
# 4. utils.py
# ---------------------------------------------------------------------------
class TestFixTimestamps:
    def test_basic(self):
        from cobweb_py.utils import fix_timestamps
        rows = [
            {"timestamp": "14/09/2020 00:00", "close": 100},
            {"timestamp": "15/09/2020 00:00", "close": 101},
        ]
        result = fix_timestamps(rows, dayfirst=True)
        assert "rows" in result
        assert len(result["rows"]) == 2
        assert "2020-09-14" in result["rows"][0]["timestamp"]

    def test_missing_column_raises(self):
        from cobweb_py.utils import fix_timestamps
        from cobweb_py.client import CobwebError
        rows = [{"close": 100}]
        with pytest.raises(CobwebError, match="missing"):
            fix_timestamps(rows, timestamp_col="timestamp")


class TestToSignals:
    def test_basic_long_signal(self):
        from cobweb_py.utils import to_signals
        scores = [0.0, 0.1, 0.25, 0.3, 0.1, 0.03, 0.0]
        signals = to_signals(scores, entry_th=0.20, exit_th=0.05)
        # 0.0 -> flat, 0.1 -> flat, 0.25 -> long, 0.3 -> long, 0.1 -> long, 0.03 -> flat, 0.0 -> flat
        assert signals == [0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0]

    def test_nan_handling(self):
        from cobweb_py.utils import to_signals
        scores = [0.25, float("nan"), 0.1, 0.03]
        signals = to_signals(scores, entry_th=0.20, exit_th=0.05)
        # 0.25 -> long, nan -> stays in long, 0.1 -> still long, 0.03 -> exit
        assert signals == [1.0, 1.0, 1.0, 0.0]

    def test_inf_handling(self):
        from cobweb_py.utils import to_signals
        scores = [0.25, float("inf"), float("-inf"), 0.03]
        signals = to_signals(scores, entry_th=0.20, exit_th=0.05)
        assert signals[0] == 1.0
        assert signals[1] == 1.0  # inf -> no change
        assert signals[2] == 1.0  # -inf -> no change
        assert signals[3] == 0.0  # exit

    def test_short_signals(self):
        from cobweb_py.utils import to_signals
        scores = [0.0, -0.25, -0.3, -0.08, 0.0]
        signals = to_signals(scores, entry_th=0.20, exit_th=0.05, use_shorts=True)
        # 0.0 -> flat, -0.25 -> short (-1), -0.3 -> short (-1), -0.08 -> still short, 0.0 -> flat
        assert signals == [0.0, -1.0, -1.0, -1.0, 0.0]


class TestGetSignal:
    def test_basic(self):
        from cobweb_py.utils import get_signal
        bt = {"current_signal": "buy", "current_exposure": 0.87, "signal_strength": 0.72}
        s = get_signal(bt)
        assert s["signal"] == "buy"
        assert abs(s["exposure"] - 0.87) < 1e-6
        assert abs(s["strength"] - 0.72) < 1e-6

    def test_defaults(self):
        from cobweb_py.utils import get_signal
        s = get_signal({})
        assert s["signal"] == "hold"
        assert s["exposure"] == 0.0
        assert s["strength"] == 0.0


class TestSaveTable:
    def test_basic_save(self, tmp_path):
        from cobweb_py.utils import save_table
        rows = [{"a": 1, "b": 2}, {"a": 3, "b": 4}]
        out = save_table(rows, tmp_path / "test_table.html", title="Test")
        assert Path(out).exists()
        content = Path(out).read_text()
        assert "Test" in content
        assert "<table" in content


class TestAlign:
    def test_basic_align(self):
        from cobweb_py.utils import align
        a = {"rows": [
            {"timestamp": "2024-01-01 00:00:00", "close": 100},
            {"timestamp": "2024-01-02 00:00:00", "close": 101},
            {"timestamp": "2024-01-03 00:00:00", "close": 102},
        ]}
        b = {"rows": [
            {"timestamp": "2024-01-02 00:00:00", "close": 200},
            {"timestamp": "2024-01-03 00:00:00", "close": 201},
            {"timestamp": "2024-01-04 00:00:00", "close": 202},
        ]}
        a_out, b_out = align(a, b)
        assert len(a_out["rows"]) == 2
        assert len(b_out["rows"]) == 2

    def test_no_overlap_raises(self):
        from cobweb_py.utils import align
        from cobweb_py.client import CobwebError
        a = {"rows": [{"timestamp": "2024-01-01 00:00:00", "close": 100}]}
        b = {"rows": [{"timestamp": "2025-06-01 00:00:00", "close": 200}]}
        with pytest.raises(CobwebError, match="no overlapping"):
            align(a, b)


# ---------------------------------------------------------------------------
# 5. plots.py
# ---------------------------------------------------------------------------
class TestPlotsToDf:
    def test_dataframe_passthrough(self):
        from cobweb_py.plots import _to_df
        orig = pd.DataFrame({"x": [1, 2]})
        df = _to_df(orig)
        assert df is not orig
        assert len(df) == 2

    def test_dict_with_rows(self):
        from cobweb_py.plots import _to_df
        df = _to_df({"rows": [{"a": 1}]})
        assert len(df) == 1

    def test_dict_with_equity_curve(self):
        from cobweb_py.plots import _to_df
        df = _to_df({"equity_curve": [{"equity": 10000}]})
        assert len(df) == 1
        assert "equity" in df.columns


class TestAsFloatMatrix:
    def test_normal_values(self):
        from cobweb_py.plots import _as_float_matrix
        z = [[1.0, 2.0], [3.0, 4.0]]
        result = _as_float_matrix(z)
        assert result == [[1.0, 2.0], [3.0, 4.0]]

    def test_non_numeric_becomes_nan(self):
        from cobweb_py.plots import _as_float_matrix
        z = [[1.0, "bad"], [None, 4.0]]
        result = _as_float_matrix(z)
        assert result[0][0] == 1.0
        assert math.isnan(result[0][1])
        assert math.isnan(result[1][0])
        assert result[1][1] == 4.0

    def test_inf_becomes_nan(self):
        from cobweb_py.plots import _as_float_matrix
        z = [[float("inf"), float("-inf")]]
        result = _as_float_matrix(z)
        assert math.isnan(result[0][0])
        assert math.isnan(result[0][1])


class TestLabel:
    def test_known_labels(self):
        from cobweb_py.plots import _label
        assert _label("close") == "Close"
        assert _label("volume") == "Volume"
        assert _label("equity") == "Equity"

    def test_snake_case_humanized(self):
        from cobweb_py.plots import _label
        assert _label("my_custom_col") == "My Custom Col"


# ---------------------------------------------------------------------------
# 6. easy.py
# ---------------------------------------------------------------------------
class TestEnsureFeatureDeps:
    def test_both_none(self):
        from cobweb_py.easy import _ensure_feature_deps
        result = _ensure_feature_deps(None, None)
        assert result is None

    def test_plot_21_adds_70(self):
        from cobweb_py.easy import _ensure_feature_deps
        result = _ensure_feature_deps(None, [21])
        assert 70 in result

    def test_plot_20_adds_71(self):
        from cobweb_py.easy import _ensure_feature_deps
        result = _ensure_feature_deps(None, [20])
        assert 71 in result

    def test_existing_features_preserved(self):
        from cobweb_py.easy import _ensure_feature_deps
        result = _ensure_feature_deps([1, 2, 3], [21])
        assert 1 in result
        assert 2 in result
        assert 3 in result
        assert 70 in result

    def test_no_deps_needed_returns_none(self):
        from cobweb_py.easy import _ensure_feature_deps
        result = _ensure_feature_deps(None, [5])  # plot 5 doesn't need deps
        assert result is None


class TestPipelineInit:
    def test_init(self):
        from cobweb_py.easy import Pipeline
        pipe = Pipeline("http://localhost:8000", [{"open": 1, "close": 2}])
        assert pipe.is_enriched is False
        assert pipe.enriched_rows is None
        assert pipe.feature_columns is None

    def test_reset(self):
        from cobweb_py.easy import Pipeline
        pipe = Pipeline("http://localhost:8000", [{"open": 1, "close": 2}])
        pipe._enriched_rows = [{"a": 1}]  # fake cached data
        assert pipe.is_enriched is True
        pipe.reset()
        assert pipe.is_enriched is False


# ---------------------------------------------------------------------------
# 7. Integration: features.py was deleted
# ---------------------------------------------------------------------------
class TestFeaturesModuleRemoved:
    def test_no_features_module(self):
        """Ensure the dead features.py module was actually deleted."""
        import importlib
        with pytest.raises(ModuleNotFoundError):
            importlib.import_module("cobweb_py.features")


# ---------------------------------------------------------------------------
# 8. XSS safety (html.escape usage)
# ---------------------------------------------------------------------------
class TestXssSafety:
    def test_save_table_escapes_title(self, tmp_path):
        from cobweb_py.utils import save_table
        malicious_title = '<script>alert("xss")</script>'
        out = save_table(
            [{"a": 1}],
            tmp_path / "xss_test.html",
            title=malicious_title,
        )
        content = Path(out).read_text()
        assert "<script>" not in content
        assert "&lt;script&gt;" in content


# ---------------------------------------------------------------------------
# 9. Edge cases
# ---------------------------------------------------------------------------
class TestEdgeCases:
    def test_empty_rows_list(self):
        from cobweb_py.client import _normalize_ohlcv_keys
        assert _normalize_ohlcv_keys([]) == []

    def test_to_signals_empty(self):
        from cobweb_py.utils import to_signals
        assert to_signals([], 0.2, 0.05) == []

    def test_score_with_sma_signal(self):
        """Test score() creates sma_signal from close & sma_20."""
        from cobweb_py.scoring import score
        rows = [
            {"close": 105, "sma_20": 100, "ret_1d": 0.01}
            for _ in range(25)
        ]
        result = score(rows, {"sma_signal": 0.5, "ret_1d": 0.5})
        assert len(result) == 25
        # sma_signal should be (105-100)/100 = 0.05

    def test_backtest_config_none_fields(self):
        from cobweb_py.client import BacktestConfig
        cfg = BacktestConfig(max_participation=None)
        d = cfg.to_dict()
        assert "max_participation" not in d


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
