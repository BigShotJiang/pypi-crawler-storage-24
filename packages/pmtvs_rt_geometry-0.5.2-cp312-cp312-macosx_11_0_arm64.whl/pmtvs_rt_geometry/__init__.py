"""
pmtvs-rt-geometry — RT geometry primitives.

Implements:
  find_stable_baseline_1d  — adaptive sliding-window baseline discovery
  rt_geometry_single       — RT geometry for one cohort matrix
  rt_geometry_batch        — RT geometry for multiple cohorts (Rayon parallel)

numpy in, numpy out.
Rust backend (_core) required.
"""

__version__ = "0.5.1"

import numpy as np

try:
    from pmtvs_rt_geometry._core import (
        find_stable_baseline_1d as _rs_find_stable_baseline_1d,
        rt_geometry_single as _rs_rt_geometry_single,
        rt_geometry_batch as _rs_rt_geometry_batch,
    )
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-rt-geometry && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

BACKEND = "rust"


def find_stable_baseline_1d(values, window_fraction=0.2, min_window=10, stride_fraction=0.05):
    """Return (start_idx, end_idx) of most stable region in 1D signal."""
    return _rs_find_stable_baseline_1d(
        np.ascontiguousarray(values, dtype=np.float64),
        float(window_fraction),
        int(min_window),
        float(stride_fraction),
    )


def rt_geometry_single(matrix, min_baseline_cycles=3):
    """RT geometry for one cohort. Returns (cd, cdn, pc1, pc2, mahal)."""
    return _rs_rt_geometry_single(
        np.ascontiguousarray(matrix, dtype=np.float64),
        int(min_baseline_cycles),
    )


def rt_geometry_batch(matrices_flat, cycles_per_cohort, n_signals, min_baseline_cycles=3):
    """Batch RT geometry — Rayon parallel. Returns (cd, cdn, pc1, pc2, mahal).
    matrices_flat: shape (n_cohorts, max_nc * n_signals)
    cycles_per_cohort: 1D int array of actual cycle counts
    n_signals: number of signal columns per cohort
    """
    return _rs_rt_geometry_batch(
        np.ascontiguousarray(matrices_flat, dtype=np.float64),
        np.ascontiguousarray(cycles_per_cohort, dtype=np.int64),
        int(n_signals),
        int(min_baseline_cycles),
    )


__all__ = [
    "__version__",
    "BACKEND",
    "find_stable_baseline_1d",
    "rt_geometry_single",
    "rt_geometry_batch",
]
