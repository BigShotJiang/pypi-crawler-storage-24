# rftools/__init__.py
"""
rftools — Python client for rftools.io (203 RF & electronics calculators).

Quick start (free API key, 5 calls/month):
    import rftools
    result = rftools.calculate("vswr-return-loss", {"vswr": 2.5})
    print(result["returnLoss"])  # 9.54

Authenticated (API tier, 10,000 calls/month):
    client = rftools.Client(api_key="rfc_live_xxx")
    result = client.calculate("free-space-path-loss", {"frequency": 2400, "distance": 100})
"""
import os

__version__ = "0.1.1"
__all__ = [
    "Client",
    "AsyncClient",
    "calculate",
    "list_calculators",
    "get_calculator",
    "CalculatorResult",
    "CalculatorInfo",
    "InputField",
    "OutputField",
    "RFToolsError",
    "AuthError",
    "RateLimitError",
    "ValidationError",
    "NotFoundError",
    "APIError",
]

from rftools.client import Client, AsyncClient
from rftools.types import CalculatorResult, CalculatorInfo, InputField, OutputField
from rftools.exceptions import (
    RFToolsError, AuthError, RateLimitError, ValidationError, NotFoundError, APIError,
)

_default_client: Client | None = None


def _get_default_client() -> Client:
    global _default_client
    env_key = os.environ.get("RFTOOLS_API_KEY")
    if _default_client is None or (env_key and _default_client._api_key != env_key):
        _default_client = Client(api_key=env_key)
    return _default_client


def calculate(slug: str, inputs: dict) -> CalculatorResult:
    """
    Run a calculator using the free tier (no API key required).

    Requires an API key. Free tier: 5 calls/month. For higher limits, use ``rftools.Client(api_key=...)``.
    """
    return _get_default_client().calculate(slug, inputs)


def list_calculators(category: str | None = None) -> list[CalculatorInfo]:
    """Return metadata for all 203 calculators, optionally filtered by category."""
    return _get_default_client().list_calculators(category=category)


def get_calculator(slug: str) -> CalculatorInfo:
    """Return metadata for a single calculator by slug."""
    return _get_default_client().get_calculator(slug)
