# rftools/calculators/__init__.py
"""Auto-generated typed stubs for all 203 rftools.io calculators."""
