# rftools/exceptions.py
"""Exception hierarchy for the rftools client."""


class RFToolsError(Exception):
    """Base exception for all rftools errors."""
    pass


class AuthError(RFToolsError):
    """Raised when the API key is missing, invalid, or revoked (HTTP 401)."""
    pass


class RateLimitError(RFToolsError):
    """Raised when the monthly quota is exceeded (HTTP 429 or 401 with quota message)."""
    def __init__(self, message: str, retry_after: int | None = None):
        super().__init__(message)
        self.retry_after = retry_after  # seconds until reset, if provided


class ValidationError(RFToolsError):
    """Raised when inputs fail server-side validation (HTTP 422)."""
    def __init__(self, message: str, detail: list | None = None):
        super().__init__(message)
        self.detail = detail or []


class NotFoundError(RFToolsError):
    """Raised when the calculator slug does not exist (HTTP 404)."""
    pass


class APIError(RFToolsError):
    """Raised for unexpected HTTP errors from the API."""
    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code
