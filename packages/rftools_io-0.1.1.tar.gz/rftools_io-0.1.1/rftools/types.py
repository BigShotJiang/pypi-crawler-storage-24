# rftools/types.py
"""Typed dataclasses for calculator metadata and results."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class InputField:
    key: str                         # e.g. "vswr"
    label: str                       # e.g. "VSWR"
    unit: str                        # e.g. "" or "MHz" or "dBm"
    default: float                   # default value
    min: float | None = None
    max: float | None = None
    description: str = ""


@dataclass(frozen=True)
class OutputField:
    key: str                         # e.g. "returnLoss"
    label: str                       # e.g. "Return Loss"
    unit: str                        # e.g. "dB"
    description: str = ""


@dataclass(frozen=True)
class CalculatorInfo:
    slug: str                        # e.g. "vswr-return-loss"
    title: str                       # e.g. "VSWR & Return Loss"
    category: str                    # e.g. "rf"
    description: str
    inputs: tuple[InputField, ...]
    outputs: tuple[OutputField, ...]
    keywords: tuple[str, ...]

    def __repr__(self) -> str:
        return (
            f"CalculatorInfo(slug={self.slug!r}, category={self.category!r}, "
            f"inputs={[f.key for f in self.inputs]}, "
            f"outputs={[f.key for f in self.outputs]})"
        )


@dataclass(frozen=True)
class CalculatorResult:
    slug: str
    values: dict[str, float]
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def __getitem__(self, key: str) -> float:
        """Allow result["returnLoss"] shorthand."""
        return self.values[key]

    def __repr__(self) -> str:
        return f"CalculatorResult(slug={self.slug!r}, values={self.values})"


@dataclass
class BatchResultItem:
    slug: str
    values: dict[str, float] | None
    warnings: list[str] = field(default_factory=list)
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.error is None
