"""
Test that generated stubs exist and have correct signatures.
These tests do NOT call the network — they only inspect metadata.
"""
import inspect
from rftools._catalog import CALCULATORS
from rftools.calculators import rf, pcb, power, antenna


def test_catalog_has_203_entries():
    assert len(CALCULATORS) == 203


def test_catalog_vswr():
    info = CALCULATORS["vswr-return-loss"]
    assert info.slug == "vswr-return-loss"
    assert info.category == "rf"
    assert any(f.key == "vswr" for f in info.inputs)
    assert any(f.key == "returnLoss" for f in info.outputs)


def test_rf_stub_exists():
    assert callable(rf.vswr_return_loss)


def test_rf_stub_signature():
    sig = inspect.signature(rf.vswr_return_loss)
    assert "vswr" in sig.parameters
    # Default matches the registry value (currently 1.5)
    assert isinstance(sig.parameters["vswr"].default, float)


def test_catalog_all_categories():
    categories = {c.category for c in CALCULATORS.values()}
    expected = {"rf", "pcb", "power", "signal", "antenna", "general",
                "motor", "protocol", "emc", "thermal", "sensor", "unit-conversion", "audio"}
    assert categories == expected


def test_catalog_entries_have_inputs_outputs():
    for slug, info in CALCULATORS.items():
        assert len(info.inputs) > 0, f"{slug} has no inputs"
        assert len(info.outputs) > 0, f"{slug} has no outputs"


def test_antenna_stub_exists():
    assert callable(antenna.dipole_antenna)


def test_pcb_stub_exists():
    # Check a known PCB calculator
    fns = [n for n, v in inspect.getmembers(pcb, inspect.isfunction) if not n.startswith("_")]
    assert len(fns) >= 10
