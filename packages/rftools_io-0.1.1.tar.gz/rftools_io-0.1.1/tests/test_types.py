from rftools.types import InputField, OutputField, CalculatorInfo, CalculatorResult, BatchResultItem


def test_calculator_result_getitem():
    r = CalculatorResult(slug="vswr-return-loss", values={"returnLoss": 9.54}, warnings=[])
    assert r["returnLoss"] == 9.54


def test_calculator_result_ok():
    r = CalculatorResult(slug="test", values={"x": 1.0})
    assert r.errors == []


def test_batch_result_item_ok():
    item = BatchResultItem(slug="vswr-return-loss", values={"returnLoss": 9.54})
    assert item.ok is True


def test_batch_result_item_error():
    item = BatchResultItem(slug="bad-slug", values=None, error="Calculator 'bad-slug' not found")
    assert item.ok is False


def test_input_field_frozen():
    f = InputField(key="vswr", label="VSWR", unit="", default=2.0, min=1.0)
    assert f.key == "vswr"
    assert f.min == 1.0


def test_calculator_info_repr():
    info = CalculatorInfo(
        slug="vswr-return-loss",
        title="VSWR & Return Loss",
        category="rf",
        description="Convert between VSWR and return loss",
        inputs=(InputField(key="vswr", label="VSWR", unit="", default=2.0),),
        outputs=(OutputField(key="returnLoss", label="Return Loss", unit="dB"),),
        keywords=("vswr", "return loss"),
    )
    assert "vswr-return-loss" in repr(info)
    assert "rf" in repr(info)
