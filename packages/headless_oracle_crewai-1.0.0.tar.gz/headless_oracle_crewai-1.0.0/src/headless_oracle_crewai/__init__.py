"""
headless-oracle-crewai — CrewAI tools for Headless Oracle market state verification.

Note: SMA in this package denotes "Signed Market Attestation" — not Simple Moving Average.

Auto-provisions a sandbox API key on first use (lazy, not on import).
"""
from .tools import MarketStatusTool, MarketScheduleTool

__all__ = ["MarketStatusTool", "MarketScheduleTool"]
__version__ = "1.0.0"
