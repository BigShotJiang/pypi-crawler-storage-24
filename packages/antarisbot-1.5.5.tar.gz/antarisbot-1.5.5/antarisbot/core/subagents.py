"""
antarisbot/core/subagents.py

Subagent system for AntarisBot.

Allows the bot (or user) to spawn named subagents — isolated async workers
that each receive a scoped context packet, run their own LLM call chain,
and report results back to Discord and/or the parent memory store.

Key design decisions:
- Isolation via asyncio tasks (same process, separate context/state)
  matches OpenClaw's isolated session model — lightweight, no IPC overhead
- Each subagent shares the parent's LLM dispatcher + API key (same provider)
- Max concurrent agents is configurable (default 4, tunable per machine)
- Auto-naming: if no name given, assigns a, b, c, d ... or a1, b1 on overflow
- Results are posted to Discord if a channel is available, and saved to memory
"""
from __future__ import annotations

import asyncio
import logging
import string
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Callable, Optional

if TYPE_CHECKING:
    from antarisbot.core.bot import AntarisBot

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Auto-name generator  (a, b, c … z, a1, b1 …)
# ---------------------------------------------------------------------------
_ALPHA = list(string.ascii_lowercase)


def _auto_name(existing: set[str]) -> str:
    for ch in _ALPHA:
        if ch not in existing:
            return ch
    suffix = 1
    while True:
        for ch in _ALPHA:
            candidate = f"{ch}{suffix}"
            if candidate not in existing:
                return candidate
        suffix += 1


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

class SubagentStatus(str, Enum):
    RUNNING = "running"
    DONE    = "done"
    FAILED  = "failed"
    KILLED  = "killed"


@dataclass
class SubagentResult:
    text: str
    elapsed: float   # seconds
    tokens_used: int = 0


@dataclass
class Subagent:
    name: str
    task: str
    context: str                    # pre-built context string passed at spawn
    status: SubagentStatus = SubagentStatus.RUNNING
    result: Optional[SubagentResult] = None
    started_at: float = field(default_factory=time.monotonic)
    task_handle: Optional[asyncio.Task] = None
    origin_channel: object = None   # Discord channel captured at spawn time (fix: avoids race condition)

    @property
    def elapsed(self) -> float:
        return time.monotonic() - self.started_at

    def summary(self) -> str:
        icon = {
            SubagentStatus.RUNNING: "⏳",
            SubagentStatus.DONE:    "✅",
            SubagentStatus.FAILED:  "❌",
            SubagentStatus.KILLED:  "🛑",
        }[self.status]
        elapsed = f"{self.elapsed:.1f}s"
        if self.result:
            preview = self.result.text[:80].replace("\n", " ")
            return f"{icon} **{self.name}** ({elapsed}) — {preview}…"
        return f"{icon} **{self.name}** ({elapsed}) — {self.task[:60]}"


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

class SubagentRegistry:
    """
    In-process registry of all spawned subagents for a bot session.

    Thread-safe via asyncio — all access should happen on the event loop.
    """

    def __init__(self, bot: "AntarisBot", max_agents: int = 4):
        self.bot = bot
        self.max_agents = max_agents
        self._agents: dict[str, Subagent] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def active_count(self) -> int:
        return sum(
            1 for a in self._agents.values()
            if a.status == SubagentStatus.RUNNING
        )

    def get(self, name: str) -> Optional[Subagent]:
        return self._agents.get(name)

    def list_all(self) -> list[Subagent]:
        return list(self._agents.values())

    async def spawn(
        self,
        task: str,
        name: Optional[str] = None,
        context: Optional[str] = None,
        on_done: Optional[Callable] = None,
        origin_channel: object = None,
    ) -> tuple[bool, str]:
        """
        Spawn a new subagent.

        Returns (success, message).
        origin_channel: Discord channel object captured at call time — stored on
        the agent so concurrent spawns from different channels don't race.
        """
        if self.active_count >= self.max_agents:
            return False, (
                f"⚠️ Max concurrent subagents reached ({self.max_agents}). "
                f"Kill one with `!agents kill <name>` or wait for one to finish."
            )

        # Auto-name from RUNNING agents only (completed agents free their names)
        running_names = {
            n for n, a in self._agents.items()
            if a.status == SubagentStatus.RUNNING
        }
        resolved_name = name or _auto_name(running_names)

        if resolved_name in self._agents and self._agents[resolved_name].status == SubagentStatus.RUNNING:
            return False, f"⚠️ Subagent **{resolved_name}** is already running."

        # Build context: use provided, or auto-scope from memory
        ctx = context or await self._build_auto_context(task)

        # Capture origin channel at spawn time to avoid race conditions
        channel = origin_channel or getattr(self.bot, "_active_discord_channel", None)

        agent = Subagent(name=resolved_name, task=task, context=ctx, origin_channel=channel)
        self._agents[resolved_name] = agent

        # Launch async task
        agent.task_handle = asyncio.create_task(
            self._run(agent, on_done),
            name=f"subagent-{resolved_name}",
        )

        logger.info("Spawned subagent '%s' — task: %s", resolved_name, task[:80])
        return True, f"🚀 Spawned subagent **{resolved_name}** — `{task[:80]}`"

    async def spawn_many(
        self,
        tasks: list[str],
        names: Optional[list[str]] = None,
        on_done: Optional[Callable] = None,
        origin_channel: object = None,
    ) -> list[tuple[bool, str]]:
        """Spawn multiple subagents at once. Pre-validates count against available slots."""
        available = self.max_agents - self.active_count
        if available <= 0:
            return [(False, f"⚠️ Max concurrent subagents reached ({self.max_agents}).")]

        # Cap tasks to available slots upfront — clean UX, no partial noisy failures
        tasks = tasks[:available]
        if names:
            names = names[:available]

        results = []
        for i, task in enumerate(tasks):
            name = names[i] if names and i < len(names) else None
            ok, msg = await self.spawn(task, name=name, on_done=on_done, origin_channel=origin_channel)
            results.append((ok, msg))
        return results

    async def kill(self, name: str) -> tuple[bool, str]:
        agent = self._agents.get(name)
        if not agent:
            return False, f"No subagent named **{name}**."
        if agent.status != SubagentStatus.RUNNING:
            return False, f"Subagent **{name}** is already {agent.status.value}."
        if agent.task_handle:
            agent.task_handle.cancel()
        agent.status = SubagentStatus.KILLED
        logger.info("Killed subagent '%s'", name)
        return True, f"🛑 Killed subagent **{name}**."

    def result_text(self, name: str) -> Optional[str]:
        agent = self._agents.get(name)
        if not agent or not agent.result:
            return None
        return agent.result.text

    def status_board(self) -> str:
        if not self._agents:
            return "No subagents spawned this session."
        lines = [f"**Subagents** ({self.active_count}/{self.max_agents} running)"]
        for agent in self._agents.values():
            lines.append(agent.summary())
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _build_auto_context(self, task: str) -> str:
        """Build a scoped context packet from memory relevant to the task."""
        try:
            if hasattr(self.bot, "memory") and self.bot.memory:
                memories = await asyncio.get_running_loop().run_in_executor(
                    None,
                    lambda: self.bot.memory.recall(
                        query=task,
                        user_id="__subagent__",
                        session_id=None,
                    ),
                )
                if memories:
                    block = "\n".join(f"- {m}" for m in memories[:8])
                    return f"[Relevant context]\n{block}"
        except Exception as e:
            logger.debug("Auto-context build failed: %s", e)
        return ""

    # Discord mention pattern — strip @everyone, @here, and <@id> from LLM output
    _MENTION_RE = None

    @classmethod
    def _strip_mentions(cls, text: str) -> str:
        import re
        if cls._MENTION_RE is None:
            cls._MENTION_RE = re.compile(r"@(everyone|here)|<@[!&]?\d+>")
        return cls._MENTION_RE.sub("[mention removed]", text)

    # Default LLM call timeout in seconds — prevents runaway subagents
    LLM_TIMEOUT = 300

    async def _run(
        self,
        agent: Subagent,
        on_done,
    ) -> None:
        """Core execution loop for a single subagent."""
        t0 = time.monotonic()
        try:
            # Build system prompt
            system = (
                f"You are a focused subagent named '{agent.name}'. "
                f"Complete the assigned task thoroughly and concisely. "
                f"Report results directly — no filler, no preamble."
            )

            # Build messages: context + task
            if agent.context:
                content = f"Context provided:\n{agent.context}\n\nTask: {agent.task}"
            else:
                content = agent.task

            from antarisbot.llm.base import Message, Role
            messages = [Message(role=Role.USER, content=content)]

            # Timeout guard — prevents runaway subagents from holding slots forever
            response = await asyncio.wait_for(
                self.bot.dispatcher.complete(messages=messages, system=system),
                timeout=self.LLM_TIMEOUT,
            )

            elapsed = time.monotonic() - t0
            agent.result = SubagentResult(
                text=response.text,
                elapsed=elapsed,
                tokens_used=response.usage.get("total_tokens", 0) if response.usage else 0,
            )
            agent.status = SubagentStatus.DONE
            logger.info("Subagent '%s' done in %.1fs", agent.name, elapsed)

            await self._save_to_memory(agent)
            await self._report_to_discord(agent)

        except asyncio.TimeoutError:
            agent.status = SubagentStatus.FAILED
            agent.result = SubagentResult(
                text=f"Timed out after {self.LLM_TIMEOUT}s.",
                elapsed=time.monotonic() - t0,
            )
            logger.warning("Subagent '%s' timed out", agent.name)
            await self._report_to_discord(agent)
        except asyncio.CancelledError:
            agent.status = SubagentStatus.KILLED
            logger.info("Subagent '%s' cancelled", agent.name)
        except Exception as e:
            agent.status = SubagentStatus.FAILED
            agent.result = SubagentResult(
                text=f"Error: {e}",
                elapsed=time.monotonic() - t0,
            )
            logger.exception("Subagent '%s' failed: %s", agent.name, e)
            await self._report_to_discord(agent)
        finally:
            if on_done:
                try:
                    if asyncio.iscoroutinefunction(on_done):
                        await on_done(agent)
                    else:
                        on_done(agent)
                except Exception:
                    pass

    async def _save_to_memory(self, agent: Subagent) -> None:
        """Save subagent result to the memory store."""
        try:
            if not (hasattr(self.bot, "memory") and self.bot.memory and agent.result):
                return
            content = (
                f"Subagent '{agent.name}' completed task: {agent.task}\n"
                f"Result: {agent.result.text}"
            )
            await asyncio.get_running_loop().run_in_executor(
                None,
                lambda: self.bot.memory.ingest(
                    text=content,
                    user_id="__subagent__",
                    session_id=f"subagent-{agent.name}",
                ),
            )
        except Exception as e:
            logger.debug("Subagent memory save failed: %s", e)

    async def _report_to_discord(self, agent: Subagent) -> None:
        """Post subagent result to the agent's origin channel (captured at spawn time)."""
        try:
            # Use origin_channel captured at spawn — avoids race with _active_discord_channel
            channel = agent.origin_channel
            if not channel:
                return

            if agent.status == SubagentStatus.DONE and agent.result:
                header = f"✅ **Subagent {agent.name}** finished in {agent.result.elapsed:.1f}s"
                # Strip Discord mentions from LLM output before posting
                body = self._strip_mentions(agent.result.text)
                full = f"{header}\n{body}"
                if len(full) <= 1900:
                    await channel.send(full)
                else:
                    await channel.send(header)
                    for i in range(0, len(body), 1900):
                        await channel.send(body[i:i+1900])

            elif agent.status in (SubagentStatus.FAILED, SubagentStatus.KILLED) and agent.result:
                icon = "❌" if agent.status == SubagentStatus.FAILED else "🛑"
                await channel.send(
                    f"{icon} **Subagent {agent.name}**: {agent.result.text[:200]}"
                )
        except Exception as e:
            logger.debug("Subagent Discord report failed: %s", e)
