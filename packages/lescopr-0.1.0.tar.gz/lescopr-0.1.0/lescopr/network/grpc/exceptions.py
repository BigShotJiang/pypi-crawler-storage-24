"""
Exceptions spécialisées pour le module gRPC - VERSION REFACTORISÉE
"""

class GrpcError(Exception):
    """Exception de base pour les erreurs gRPC"""
    
    def __init__(self, message: str, error_code: str = None, details: dict = None):
        super().__init__(message)
        self.error_code = error_code
        self.details = details or {}
    
    def __str__(self):
        if self.error_code:
            return f"[{self.error_code}] {self.args[0]}"
        return self.args[0]


class GrpcConnectionError(GrpcError):
    """Erreur de connexion gRPC"""
    
    def __init__(self, message: str, host: str = None, port: int = None):
        super().__init__(message, "GRPC_CONNECTION_ERROR")
        self.host = host
        self.port = port
        if host and port:
            self.details = {'host': host, 'port': port}


class GrpcStreamError(GrpcError):
    """Erreur de stream gRPC"""
    
    def __init__(self, message: str, stream_type: str = None):
        super().__init__(message, "GRPC_STREAM_ERROR")
        self.stream_type = stream_type


class GrpcAuthenticationError(GrpcError):
    """Erreur d'authentification gRPC"""
    
    def __init__(self, message: str, sdk_id: str = None):
        super().__init__(message, "GRPC_AUTH_ERROR")
        self.sdk_id = sdk_id


class GrpcTimeoutError(GrpcError):
    """Erreur de timeout gRPC"""
    
    def __init__(self, message: str, timeout_duration: float = None):
        super().__init__(message, "GRPC_TIMEOUT_ERROR")
        self.timeout_duration = timeout_duration