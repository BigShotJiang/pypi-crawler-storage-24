from enum import Enum

class ConnectionState(Enum):
    """États de connexion possibles."""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    FAILED = "failed"