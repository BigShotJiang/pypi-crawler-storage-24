import time
import psutil

def get_cpu_usage():
    """Utilisation CPU en pourcentage."""
    try:
        return psutil.cpu_percent(interval=0.1)
    except ImportError:
        return -1.0

def get_ram_usage():
    """RAM utilisée en Mo."""
    try:
        import psutil
        mem = psutil.virtual_memory()
        return mem.used / (1024 * 1024)
    except ImportError:
        return -1.0

def get_ram_percent():
    """Pourcentage de RAM utilisée."""
    try:
        import psutil
        mem = psutil.virtual_memory()
        return mem.percent
    except ImportError:
        return -1.0

def get_swap_usage():
    """Utilisation du swap en Mo."""
    try:
        import psutil
        swap = psutil.swap_memory()
        return swap.used / (1024 * 1024)
    except ImportError:
        return -1.0

def get_disk_usage():
    """Espace disque utilisé en Go sur la partition principale."""
    try:
        import psutil
        disk = psutil.disk_usage('/')
        return disk.used / (1024 * 1024 * 1024)
    except ImportError:
        return -1.0

def get_disk_percent():
    """Pourcentage d'espace disque utilisé sur la partition principale."""
    try:
        import psutil
        disk = psutil.disk_usage('/')
        return disk.percent
    except ImportError:
        return -1.0

def get_network_bytes_sent():
    """Octets envoyés depuis le démarrage."""
    try:
        import psutil
        net = psutil.net_io_counters()
        return net.bytes_sent
    except ImportError:
        return -1

def get_network_bytes_recv():
    """Octets reçus depuis le démarrage."""
    try:
        import psutil
        net = psutil.net_io_counters()
        return net.bytes_recv
    except ImportError:
        return -1

def get_uptime():
    """Uptime du système en secondes."""
    try:
        import psutil
        return int(time.time() - psutil.boot_time())
    except ImportError:
        return -1

def get_process_count():
    """Nombre de processus actifs."""
    try:
        import psutil
        return len(psutil.pids())
    except ImportError:
        return -1