"""
Lecteur de fichiers sécurisé avec gestion d'erreurs robuste
"""
import os
import json
from typing import Optional, Dict, Any
from pathlib import Path

from ..utils.constants import MAX_FILE_SIZE


class FileReader:
    """Lecteur de fichiers sécurisé et robuste"""
    
    def __init__(self, max_size: int = MAX_FILE_SIZE):
        self.max_size = max_size
    
    def read_text(self, file_path: str) -> Optional[str]:
        """
        Lit le contenu textuel d'un fichier de manière sécurisée
        
        Args:
            file_path: Chemin du fichier
            
        Returns:
            Contenu du fichier ou None en cas d'erreur
        """
        try:
            path = Path(file_path)
            
            if not path.exists():
                return None
            
            if not path.is_file():
                return None
            
            # Vérifier la taille
            file_size = path.stat().st_size
            if file_size > self.max_size:
                return f"__FILE_TOO_LARGE__:{file_size}"
            
            # Lire le contenu avec gestion d'encodage
            encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
            
            for encoding in encodings:
                try:
                    with open(path, 'r', encoding=encoding, errors='ignore') as f:
                        return f.read()
                except UnicodeDecodeError:
                    continue
            
            return f"__ENCODING_ERROR__:{file_path}"
                
        except PermissionError:
            return f"__PERMISSION_DENIED__:{file_path}"
        except FileNotFoundError:
            return None
        except Exception as e:
            return f"__READ_ERROR__:{str(e)}"
    
    def read_json(self, file_path: str) -> Optional[Dict[str, Any]]:
        """
        Lit et parse un fichier JSON
        
        Args:
            file_path: Chemin du fichier JSON
            
        Returns:
            Dictionnaire parsé ou None en cas d'erreur
        """
        content = self.read_text(file_path)
        if not content or content.startswith('__'):
            return None
        
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            return None
    
    def file_exists(self, file_path: str) -> bool:
        """Vérifie l'existence d'un fichier"""
        return Path(file_path).exists()
    
    def get_file_size(self, file_path: str) -> Optional[int]:
        """Retourne la taille d'un fichier en octets"""
        try:
            return Path(file_path).stat().st_size
        except (FileNotFoundError, PermissionError):
            return None
    
    def is_text_file(self, file_path: str) -> bool:
        """Détermine si un fichier est probablement un fichier texte"""
        try:
            with open(file_path, 'rb') as f:
                chunk = f.read(1024)
                return b'\0' not in chunk
        except:
            return False