"""
Patterns de détection des frameworks et technologies
"""

# Patterns pour la détection des frameworks
FRAMEWORK_PATTERNS = {
    # Python Frameworks
    'django': {
        'parent_stack_type': 'python',
        'files': ['manage.py'],
        'content_patterns': {
            'requirements.txt': [r'^\s*[Dd]jango[>=~!<]', r'^\s*django[>=~!<]'],
            'pyproject.toml': [r'django', r'Django', r'framework\s*=\s*["\']django["\']'],
            'Pipfile': [r'django', r'Django'],
            'setup.py': [r'django', r'Django'],
            'manage.py': [r'django', r'Django', r'DJANGO_SETTINGS_MODULE']
        },
        'optional_files': ['urls.py', 'wsgi.py', 'asgi.py', 'settings.py'],
        'confidence_weights': {
            'files': 50,
            'content_patterns': 40,
            'optional_files': 10
        }
    },
    
    'flask': {
        'parent_stack_type': 'python',
        'files': [],
        'content_patterns': {
            'requirements.txt': [r'^\s*[Ff]lask[>=~!<]', r'^\s*flask[>=~!<]'],
            'pyproject.toml': [r'flask', r'Flask'],
            'Pipfile': [r'flask', r'Flask'],
            '*app.py': [r'from\s+flask\s+import\s+Flask', r'Flask\(__name__\)'],
            '*main.py': [r'from\s+flask\s+import\s+Flask'],
            '*wsgi.py': [r'from\s+flask\s+import\s+Flask'],
        },
        'confidence_weights': {
            'content_patterns': 90,
            'optional_files': 10
        }
    },
    
    'fastapi': {
        'parent_stack_type': 'python',
        'files': [],
        'content_patterns': {
            'requirements.txt': [r'^\s*[Ff]ast[Aa][Pp][Ii][>=~!<]', r'^\s*fastapi[>=~!<]'],
            'pyproject.toml': [r'fastapi', r'FastAPI'],
            'Pipfile': [r'fastapi', r'FastAPI'],
            '*app.py': [r'from\s+fastapi\s+import\s+FastAPI', r'FastAPI\('],
            '*main.py': [r'from\s+fastapi\s+import\s+FastAPI'],
        },
        'confidence_weights': {
            'content_patterns': 90,
            'optional_files': 10
        }
    },
    
    # JavaScript Frameworks
    'react': {
        'parent_stack_type': 'javascript',
        'files': ['package.json'],
        'content_patterns': {
            'package.json': [r'"react":\s*"[^"]*"', r'"@types/react":\s*"[^"]*"']
        },
        'optional_files': ['src/App.js', 'src/App.tsx', 'public/index.html'],
        'confidence_weights': {
            'files': 30,
            'content_patterns': 60,
            'optional_files': 10
        }
    },
    
    'vue': {
        'parent_stack_type': 'javascript',
        'files': ['package.json'],
        'content_patterns': {
            'package.json': [r'"vue":\s*"[^"]*"', r'"@vue/'],
            'vue.config.js': [r'vue', r'Vue']
        },
        'optional_files': ['vue.config.js', 'src/App.vue'],
        'confidence_weights': {
            'files': 30,
            'content_patterns': 60,
            'optional_files': 10
        }
    },
    
    'angular': {
        'parent_stack_type': 'javascript',
        'files': ['package.json', 'angular.json'],
        'content_patterns': {
            'package.json': [r'"@angular/core":\s*"[^"]*"', r'"@angular/'],
            'angular.json': [r'"architect":', r'"build":']
        },
        'confidence_weights': {
            'files': 50,
            'content_patterns': 50
        }
    },
    
    'nextjs': {
        'parent_stack_type': 'javascript',
        'files': ['package.json'],
        'content_patterns': {
            'package.json': [r'"next":\s*"[^"]*"'],
            'next.config.js': [r'next', r'Next']
        },
        'optional_files': ['next.config.js', 'pages/_app.js', 'pages/index.js'],
        'confidence_weights': {
            'content_patterns': 70,
            'optional_files': 30
        }
    },
    
    # PHP Frameworks
    'laravel': {
        'parent_stack_type': 'php',
        'files': ['composer.json'],
        'content_patterns': {
            'composer.json': [r'"laravel/framework":\s*"[^"]*"', r'"laravel/laravel"']
        },
        'optional_files': ['artisan', 'config/app.php', 'routes/web.php'],
        'confidence_weights': {
            'files': 30,
            'content_patterns': 50,
            'optional_files': 20
        }
    },
    
    'symfony': {
        'parent_stack_type': 'php',
        'files': ['composer.json'],
        'content_patterns': {
            'composer.json': [r'"symfony/symfony":\s*"[^"]*"', r'"symfony/framework-bundle"']
        },
        'confidence_weights': {
            'files': 30,
            'content_patterns': 70
        }
    }
}

# Patterns pour la détection des technologies de base
TECHNOLOGY_PATTERNS = {
    'python': {
        'files': ['requirements.txt', 'setup.py', 'pyproject.toml', 'Pipfile'],
        'extensions': ['.py', '.pyx', '.pyi']
    },
    'javascript': {
        'files': ['package.json', 'yarn.lock', 'package-lock.json'],
        'extensions': ['.js', '.mjs', '.cjs', '.jsx']
    },
    'typescript': {
        'files': ['tsconfig.json', 'package.json'],
        'extensions': ['.ts', '.tsx'],
        'content_patterns': {
            'package.json': [r'"typescript":\s*"[^"]*"', r'"@types/']
        }
    },
    'php': {
        'files': ['composer.json', 'composer.lock'],
        'extensions': ['.php']
    },
    'java': {
        'files': ['pom.xml', 'build.gradle', 'gradle.properties'],
        'extensions': ['.java', '.class']
    },
    'go': {
        'files': ['go.mod', 'go.sum'],
        'extensions': ['.go']
    },
    'rust': {
        'files': ['Cargo.toml', 'Cargo.lock'],
        'extensions': ['.rs']
    },
    'ruby': {
        'files': ['Gemfile', 'Gemfile.lock'],
        'extensions': ['.rb']
    }
}