"""
Analyseur de technologies pour les projets
"""
import os
from typing import Dict, Any
from collections import Counter
from pathlib import Path

from ..utils.constants import EXTENSION_TO_TECH
from ..core.scanner import ProjectScanner
from ...monitoring.logger import logger


class TechnologyAnalyzer:
    """Analyseur pour détecter les technologies utilisées dans un projet"""
    
    def __init__(self, project_root: str):
        self.project_root = Path(project_root)
        self.scanner = ProjectScanner(str(project_root))
    
    def analyze(self) -> Dict[str, Any]:
        """
        Analyse les technologies utilisées dans le projet
        
        Returns:
            Dictionnaire avec les résultats d'analyse des technologies
        """
        try:
            logger('info', "Détection des technologies...")
            
            # Compter les fichiers par extension
            extension_counts = self.scanner.scan_files_by_extension()
            
            if not extension_counts:
                return self._get_default_result()
            
            # Mapper les extensions aux technologies
            tech_counts = Counter()
            total_files = 0
            
            for ext, count in extension_counts.items():
                if ext in EXTENSION_TO_TECH:
                    tech = EXTENSION_TO_TECH[ext]
                    tech_counts[tech] += count
                    total_files += count
                else:
                    tech_counts['Other'] += count
                    total_files += count
            
            if total_files == 0:
                return self._get_default_result()
            
            # Calculer les statistiques
            return self._calculate_statistics(tech_counts, total_files)
            
        except Exception as e:
            logger('error', f"Erreur lors de la détection des technologies: {e}")
            return self._get_default_result()
    
    def _calculate_statistics(self, tech_counts: Counter, total_files: int) -> Dict[str, Any]:
        """Calcule les statistiques des technologies"""
        
        # Détails par technologie
        tech_details = {}
        percentages = {}
        
        for tech, count in tech_counts.items():
            percentage = (count / total_files) * 100
            tech_details[tech] = {
                'count': count,
                'percentage': round(percentage, 2)
            }
            percentages[tech] = round(percentage, 2)
        
        # Trier par pourcentage décroissant
        sorted_percentages = dict(sorted(percentages.items(), key=lambda x: x[1], reverse=True))
        
        # Résumé par catégorie principale
        summary = self._create_summary(tech_counts, total_files)
        
        return {
            'details': tech_details,
            'percentages': sorted_percentages,
            'summary': summary,
            'total_files': total_files,
            'total_technologies': len(tech_counts)
        }
    
    def _create_summary(self, tech_counts: Counter, total_files: int) -> Dict[str, float]:
        """Crée un résumé par catégories principales"""
        categories = {
            'Backend': ['Python', 'Java', 'PHP', 'Go', 'Rust', 'Ruby', 'C#', 'C++', 'C'],
            'Frontend': ['JavaScript', 'TypeScript', 'HTML', 'CSS', 'SCSS', 'SASS'],
            'Mobile': ['Swift', 'Kotlin', 'Dart', 'Objective-C'],
            'Data': ['SQL', 'JSON', 'YAML', 'XML'],
            'Config': ['TOML', 'INI', 'Config'],
            'Documentation': ['Markdown', 'reStructuredText']
        }
        
        summary = {}
        
        for category, techs in categories.items():
            category_count = sum(tech_counts.get(tech, 0) for tech in techs)
            if category_count > 0:
                percentage = (category_count / total_files) * 100
                summary[category] = round(percentage, 2)
        
        # Ajouter "Other" pour les technologies non catégorisées
        categorized_count = sum(summary.values()) / 100 * total_files
        other_count = total_files - categorized_count
        if other_count > 0:
            summary['Other'] = round((other_count / total_files) * 100, 2)
        
        return summary
    
    def _get_default_result(self) -> Dict[str, Any]:
        """Retourne un résultat par défaut en cas d'erreur"""
        return {
            'details': {},
            'percentages': {'Unknown': 100.0},
            'summary': {'Unknown': 100.0},
            'total_files': 0,
            'total_technologies': 0
        }