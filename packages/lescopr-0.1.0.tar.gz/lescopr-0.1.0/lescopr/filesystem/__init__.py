"""
Module filesystem pour la gestion complète du système de fichiers dans Lescopr SDK

Ce module fournit tous les outils nécessaires pour:
- Analyser la structure des projets
- Détecter les technologies et frameworks
- Gérer la configuration du SDK
- Lire et traiter les fichiers de manière sécurisée
"""

# Imports principaux pour l'API publique
from .analyzers.project import ProjectAnalyzer
from .config.manager import ConfigManager
from .config.validator import ConfigValidator
from .core.scanner import ProjectScanner
from .core.reader import FileReader

# Imports des analyzers spécialisés
from .analyzers.technology import TechnologyAnalyzer
from .analyzers.framework import FrameworkAnalyzer

__version__ = "2.0.0"
__author__ = "SonnaLab"

# API publique du module
__all__ = [
    # Classes principales
    'ProjectAnalyzer',
    'ConfigManager',
    'ConfigValidator',
    
    # Classes de core
    'ProjectScanner',
    'FileReader',
    
    # Analyzers spécialisés
    'TechnologyAnalyzer',
    'FrameworkAnalyzer',
]

# Fonctions de commodité
def analyze_project(project_root: str = None) -> dict:
    """
    Fonction de commodité pour analyser un projet complet
    
    Args:
        project_root: Chemin racine du projet (par défaut: répertoire courant)
        
    Returns:
        Dictionnaire avec l'analyse complète du projet
    """
    analyzer = ProjectAnalyzer(project_root)
    return analyzer.analyze()

def load_config(config_dir: str = None) -> dict:
    """
    Fonction de commodité pour charger la configuration
    
    Args:
        config_dir: Répertoire de configuration (par défaut: répertoire courant)
        
    Returns:
        Dictionnaire de configuration
    """
    manager = ConfigManager(config_dir)
    return manager.load()

def save_config(config: dict, config_dir: str = None) -> bool:
    """
    Fonction de commodité pour sauvegarder la configuration
    
    Args:
        config: Configuration à sauvegarder
        config_dir: Répertoire de configuration (par défaut: répertoire courant)
        
    Returns:
        True si succès, False sinon
    """
    manager = ConfigManager(config_dir)
    return manager.save(config)