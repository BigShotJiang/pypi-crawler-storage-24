"""
Constantes pour l'analyse du système de fichiers
"""

# Taille maximale des fichiers à analyser (1MB)
MAX_FILE_SIZE = 1 * 1024 * 1024

# Répertoires à ignorer lors du scan
IGNORED_DIRS = {
    '.git', '.vscode', '.idea', '.vs', '.vscode-server',
    'node_modules', '__pycache__', '.pytest_cache', '.mypy_cache',
    'venv', 'env', '.venv', '.env', 'virtualenv',
    'build', 'dist', 'target', 'bin', 'obj', 'out',
    '.DS_Store', '.svn', '.hg', '.bzr',
    'coverage', '.coverage', '.nyc_output', 'htmlcov',
    'logs', 'tmp', 'temp', '.tmp', '.temp',
    '.next', '.nuxt', '.cache', '.parcel-cache'
}

# Préfixes de fichiers à ignorer
IGNORED_FILE_PREFIXES = {'.', '~', '#', '$'}

# Fichiers à analyser pour la détection des technologies/frameworks
FILES_TO_ANALYZE = {
    # Configuration Python
    'requirements.txt', 'pyproject.toml', 'setup.py', 'setup.cfg',
    'Pipfile', 'Pipfile.lock', 'poetry.lock', 'tox.ini',
    'conda.yml', 'environment.yml',
    
    # Fichiers Python spécifiques
    'manage.py', 'app.py', 'main.py', 'wsgi.py', 'asgi.py',
    'settings.py', 'urls.py', 'views.py', 'models.py',
    'tasks.py', 'celery.py', 'conftest.py',
    
    # Configuration JavaScript/Node.js
    'package.json', 'package-lock.json', 'yarn.lock', 'pnpm-lock.yaml',
    'webpack.config.js', 'vite.config.js', 'rollup.config.js',
    'tsconfig.json', 'babel.config.js', '.babelrc',
    
    # Configuration spécifiques aux frameworks JS
    'angular.json', 'vue.config.js', 'nuxt.config.js',
    'gatsby-config.js', 'next.config.js', 'svelte.config.js',
    'ember-cli-build.js', 'quasar.config.js',
    
    # Autres technologies
    'composer.json', 'pom.xml', 'build.gradle', 'Cargo.toml',
    'go.mod', 'go.sum', 'Gemfile', 'Gemfile.lock',
    'Makefile', 'CMakeLists.txt', 'meson.build',
    'Dockerfile', 'docker-compose.yml', 'docker-compose.yaml',
    
    # Configuration et environnement
    '.env', '.env.local', '.env.example', '.env.production',
    'config.json', 'config.yml', 'config.yaml',
    '.gitignore', '.dockerignore', 'README.md'
}

# Extensions et technologies associées
EXTENSION_TO_TECH = {
    # Web Frontend
    '.html': 'HTML', '.htm': 'HTML', '.css': 'CSS',
    '.scss': 'SCSS', '.sass': 'SASS', '.less': 'LESS', '.styl': 'Stylus',
    '.js': 'JavaScript', '.mjs': 'JavaScript', '.cjs': 'JavaScript',
    '.jsx': 'React', '.ts': 'TypeScript', '.tsx': 'React TypeScript',
    '.vue': 'Vue.js', '.svelte': 'Svelte',
    
    # Backend
    '.py': 'Python', '.pyx': 'Cython', '.pyi': 'Python',
    '.java': 'Java', '.kt': 'Kotlin', '.scala': 'Scala',
    '.php': 'PHP', '.rb': 'Ruby', '.go': 'Go', '.rs': 'Rust',
    '.c': 'C', '.cpp': 'C++', '.cc': 'C++', '.cxx': 'C++',
    '.cs': 'C#', '.fs': 'F#', '.vb': 'VB.NET',
    '.swift': 'Swift', '.m': 'Objective-C', '.mm': 'Objective-C++',
    
    # Data & Config
    '.json': 'JSON', '.yaml': 'YAML', '.yml': 'YAML',
    '.xml': 'XML', '.toml': 'TOML', '.ini': 'INI', '.cfg': 'Config',
    '.sql': 'SQL', '.md': 'Markdown', '.rst': 'reStructuredText',
    '.sh': 'Shell', '.bash': 'Bash', '.zsh': 'Zsh', '.fish': 'Fish',
    
    # Autres
    '.dart': 'Dart', '.elm': 'Elm', '.clj': 'Clojure', '.cljs': 'ClojureScript',
    '.ex': 'Elixir', '.exs': 'Elixir', '.erl': 'Erlang', '.hrl': 'Erlang',
    '.lua': 'Lua', '.pl': 'Perl', '.r': 'R', '.R': 'R'
}