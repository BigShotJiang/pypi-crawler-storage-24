import os
import click
from .core.lescopr import Lescopr

def get_project_files():
    """Retourne les chemins des fichiers Lescopr dans la racine du projet."""
    project_root = os.getcwd()
    return {
        'config': os.path.join(project_root, ".lescopr.json"),
        'log': os.path.join(project_root, ".lescopr.log"),
        'pid': os.path.join(project_root, ".lescopr.pid")
    }

@click.group()
def main():
    """CLI Lescopr pour la gestion du SDK"""
    pass

#--------------------------INIT COMMAND------------------------------------------------
@main.command()
@click.option('--sdk-key', required=True, help='Votre clé SDK Lescopr')
@click.option('--api-key', default="lsk_api_key_12345", help='Votre clé API Lescopr')
@click.option('--environment', default='development', type=click.Choice(['development', 'production']), help='Environnement')
@click.option('--start-daemon', is_flag=True, default=True, help='Démarrer automatiquement le daemon après initialisation')
def init(api_key, environment, sdk_key, start_daemon):
    """Initialise le SDK Lescopr dans le projet actuel."""
    try:
        files = get_project_files()
        
        if os.path.exists(files['config']):
            click.echo("⚠️ SDK Lescopr déjà initialisé dans ce projet")
            if not click.confirm("Voulez-vous réinitialiser la configuration ?"):
                return
        
        click.echo("\n⏳ Initialisation du SDK Lescopr...")
        
        result = Lescopr.initialize_project(
            api_key=api_key,
            sdk_key=sdk_key, 
            environment=environment
        )
        
        if not result['success']:
            click.echo(f"❌ {result['error']}")
            raise click.Abort()
        
        config = result['config']
        click.echo(f"\n✅ SDK initialisé avec succès dans le projet")
        click.echo(f"▪ ID SDK: {config['sdk_id']}")
        click.echo(f"▪ Projet: {config['project_name']}")
        click.echo(f"▪ Stack détectée: {', '.join(config.get('project_stack', []))}")
        click.echo(f"▪ Environnement: {environment.upper()}")
        click.echo(f"▪ Configuration: {files['config']}")
        
        if start_daemon:
            click.echo("\n⏳ Démarrage automatique du daemon...")
            daemon_result = Lescopr.start_daemon()
            if daemon_result['success']:
                click.echo(f"✅ Daemon démarré (PID: {daemon_result['pid']})")
            else:
                click.echo(f"❌ Erreur daemon: {daemon_result['error']}")
        else:
            click.echo("\n💡 Utilisez 'lescopr start' pour démarrer le monitoring")
            
    except Exception as e:
        click.echo(f"\n❌ Échec de l'initialisation : {str(e)}", err=True)
        raise click.Abort()

#--------------------------START COMMAND------------------------------------------------
@main.command()
@click.option('--daemon', is_flag=True, default=True, help='Démarrer en mode daemon (arrière-plan)')
def start(daemon):
    """Démarre le daemon gRPC Lescopr."""
    files = get_project_files()
    
    if not os.path.exists(files['config']):
        click.echo("❌ Projet non initialisé. Utilisez 'lescopr init' d'abord.")
        return
    
    if daemon:
        # ✅ DÉLÉGUER au core
        result = Lescopr.start_daemon()
        if result['success']:
            click.echo(f"✅ Daemon démarré (PID: {result['pid']})")
            click.echo(f"📝 Logs: {result['log_file']}")
        else:
            click.echo(f"❌ {result['error']}")
    else:
        # ✅ DÉLÉGUER au core
        result = Lescopr.start_interactive()
        if result['success']:
            click.echo("✅ Mode interactif démarré. Ctrl+C pour arrêter.")
            try:
                result['wait_function']()
            except KeyboardInterrupt:
                click.echo("\n⏳ Arrêt en cours...")
                Lescopr.stop_interactive()
                click.echo("🛑 Arrêté")
        else:
            click.echo(f"❌ {result['error']}")

#--------------------------STOP COMMAND------------------------------------------------
@main.command()
def stop():
    """Arrête le daemon gRPC."""
    result = Lescopr.stop_daemon()
    if result['success']:
        click.echo("✅ Daemon arrêté avec succès.")
    else:
        click.echo(f"⚠️ {result['error']}")

#--------------------------STATUS COMMAND------------------------------------------------
@main.command()
def status():
    """Affiche l'état du daemon gRPC."""
    result = Lescopr.get_status()
    
    click.echo(f"📁 Projet: {result['project_path']}")
    click.echo(f"🔧 Config: {result['config_file']}")
    
    if not result['config_exists']:
        click.echo("❌ Projet non initialisé")
        return
    
    config = result['config']
    click.echo(f"🆔 SDK ID: {config.get('sdk_id', 'N/A')}")
    click.echo(f"📦 Projet: {config.get('project_name', 'N/A')}")
    
    if result['daemon_running']:
        click.echo(f"🟢 Daemon: Actif (PID: {result['daemon_pid']})")
    else:
        click.echo("🔴 Daemon: Arrêté")

#--------------------------RESET COMMAND------------------------------------------------
@main.command()
@click.option('--force', is_flag=True, help='Force la réinitialisation sans confirmation')
@click.option('--keep-config', is_flag=True, help='Garde la configuration mais arrête le daemon')
def reset(force, keep_config):
    """Réinitialise complètement le SDK Lescopr."""
    try:
        files = get_project_files()
        
        # Vérifications préliminaires
        has_config = os.path.exists(files['config'])
        has_daemon = os.path.exists(files['pid'])
        
        if not has_config and not has_daemon:
            click.echo("ℹ️ Aucune installation Lescopr détectée dans ce projet.")
            return
        
        # Confirmation (sauf si --force)
        if not force:
            click.echo("⚠️ Cette opération va :")
            if has_daemon:
                click.echo("  • Arrêter le daemon en cours")
            if not keep_config:
                click.echo("  • Supprimer la configuration (.lescopr.json)")
                click.echo("  • Supprimer les logs (.lescopr.log)")
            else:
                click.echo("  • Garder la configuration mais nettoyer les processus")
            
            if not click.confirm("\nContinuer ?"):
                click.echo("❌ Opération annulée.")
                return
        
        click.echo("\n⏳ Réinitialisation en cours...")
        
        # Déléguer au core
        result = Lescopr.reset_project(keep_config=keep_config)
        
        if result['success']:
            click.echo("✅ Réinitialisation terminée avec succès")
            
            if result.get('daemon_stopped'):
                click.echo("  • Daemon arrêté")
            if result.get('config_removed'):
                click.echo("  • Configuration supprimée")
            if result.get('logs_cleaned'):
                click.echo("  • Logs nettoyés")
            if result.get('processes_cleaned'):
                click.echo("  • Processus nettoyés")
                
            if keep_config:
                click.echo("\n💡 Configuration conservée. Utilisez 'lescopr start' pour redémarrer.")
            else:
                click.echo("\n💡 Utilisez 'lescopr init' pour réinitialiser le projet.")
        else:
            click.echo(f"❌ Erreur lors de la réinitialisation: {result['error']}")
            
    except Exception as e:
        click.echo(f"\n❌ Erreur inattendue: {str(e)}", err=True)
        raise click.Abort()

#--------------------------DIAGNOSTIC COMMAND SIMPLIFIÉ------------------------------------------------
@main.command()
@click.option('--verbose', '-v', is_flag=True, help='Mode verbeux avec informations détaillées')
@click.option('--check-server', is_flag=True, help='Vérifier la connectivité serveur uniquement')
def diagnose(verbose, check_server):
    """Diagnostique complet du SDK et de la connexion"""
    click.echo("🔍 Diagnostic Lescopr...")
    
    # 1. Vérifier la configuration
    click.echo("\n📋 Configuration:")
    try:
        config = Lescopr._load_project_config()
        if config:
            click.echo(f"  ✅ Config trouvée - Projet: {config.get('project_name', 'Inconnu')}")
            click.echo(f"  ✅ SDK ID: {config.get('sdk_id', 'Manquant')}")
            click.echo(f"  ✅ SDK Key: {'***' + config.get('sdk_key', '')[-4:] if config.get('sdk_key') else 'Manquant'}")
            click.echo(f"  ✅ API Key: {'***' + config.get('api_key', '')[-4:] if config.get('api_key') else 'Manquant'}")
            click.echo(f"  ✅ Environnement: {config.get('environment', 'Manquant')}")
        else:
            click.echo("  ❌ Aucune configuration trouvée")
            click.echo("  💡 Exécutez 'lescopr init' pour initialiser")
            return
    except Exception as e:
        click.echo(f"  ❌ Erreur lecture config: {e}")
        return
    
    # 2. Vérifier l'état du daemon
    click.echo("\n🤖 État du daemon:")
    status = Lescopr.get_status()
    
    daemon_active = status['daemon_running']
    
    if daemon_active:
        click.echo(f"  ✅ Daemon actif (PID: {status['daemon_pid']})")
        
        # Vérifier les logs du daemon
        log_file = status.get('log_file', './.lescopr.log')
        if os.path.exists(log_file):
            click.echo(f"  📄 Logs: {log_file}")
            
            # Analyser le contenu des logs si verbose
            if verbose:
                try:
                    with open(log_file, 'r') as f:
                        content = f.read().strip()
                        
                    if not content:
                        click.echo("  ⚠️ Fichier de logs vide")
                    else:
                        lines = content.split('\n')
                        click.echo(f"  📊 {len(lines)} ligne(s) de logs")
                        
                        click.echo("  📝 Dernières 5 lignes:")
                        for line in lines[-5:]:
                            if line.strip():
                                click.echo(f"     {line.strip()}")
                except Exception as e:
                    click.echo(f"     ❌ Erreur lecture logs: {e}")
        else:
            click.echo(f"  ❌ Fichier de logs introuvable: {log_file}")
    else:
        click.echo("  ❌ Daemon non actif")
    
    # 3. Vérifier le serveur gRPC uniquement si demandé
    if check_server:
        click.echo("\n🌐 Serveur gRPC:")
        try:
            import socket
            import time
            
            host = config.get('grpc_host', '127.0.0.1')
            port = config.get('grpc_port', 50051)
            
            click.echo(f"  🔄 Test connexion sur {host}:{port}...")
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            start_time = time.time()
            result = sock.connect_ex((host, port))
            end_time = time.time()
            sock.close()
            
            if result == 0:
                click.echo(f"  ✅ Serveur accessible ({(end_time - start_time) * 1000:.1f}ms)")
            else:
                click.echo(f"  ❌ Serveur inaccessible (code: {result})")
                click.echo("  � Vérifiez que le serveur gRPC Lescopr est démarré")
                
        except Exception as e:
            click.echo(f"  ❌ Erreur test serveur: {e}")
    
    # 4. Recommandations
    click.echo("\n💡 Recommandations:")
    
    if not daemon_active:
        click.echo("  🔧 Démarrer le daemon:")
        click.echo("     lescopr start")
    else:
        click.echo("  ✅ Système opérationnel")
        click.echo("  � Pour redémarrer le daemon:")
        click.echo("     lescopr stop && lescopr start")
    
    if verbose:
        click.echo("\n� Commandes utiles:")
        click.echo("  • lescopr status    - État du système")
        click.echo("  • lescopr stop      - Arrêter le daemon")
        click.echo("  • lescopr start     - Démarrer le daemon")
        click.echo("  • lescopr reset     - Nettoyer complètement")
    
    click.echo("\n✅ Diagnostic terminé")

#--------------------------TEST COMMAND SUPPRIMÉ------------------------------------------------
# ❌ SUPPRIMÉ: La commande 'test' avec tests d'envoi a été complètement supprimée
# La communication est maintenant testée automatiquement par l'application elle-même

if __name__ == '__main__':
    main()