"""
Module daemon pour Lescopr SDK
"""

from .main import main

__all__ = ['main']