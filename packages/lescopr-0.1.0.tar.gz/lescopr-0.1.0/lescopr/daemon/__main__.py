"""Point d'entrée pour python -m lescopr.daemon"""

import os
import sys

os.environ['LESCOPR_DAEMON_MODE'] = 'true'

from .main import main

if __name__ == "__main__":
    main()