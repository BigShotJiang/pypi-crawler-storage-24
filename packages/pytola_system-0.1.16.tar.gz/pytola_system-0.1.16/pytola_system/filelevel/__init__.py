"""File level suffix rename utility."""
