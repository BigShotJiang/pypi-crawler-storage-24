"""Tests for sshcopyid module."""
