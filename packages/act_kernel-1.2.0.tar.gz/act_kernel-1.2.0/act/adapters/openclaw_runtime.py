"""
OpenClaw Runtime Hook – 让所有 OpenClaw 技能调用都经过 ACT
"""

import requests
import json
from typing import Any, Dict

class OpenClawACTRuntime:
    """OpenClaw 执行器替换层，所有技能执行都通过 ACT Gateway"""

    def __init__(self, gateway_url: str = "http://localhost:9000"):
        self.gateway_url = gateway_url

    def execute(self, skill_name: str, params: Dict[str, Any]) -> Any:
        """执行技能，返回结果，失败时抛出异常"""
        intent = skill_name  # 假设技能名与 ACT 工具名一致
        try:
            resp = requests.post(
                f"{self.gateway_url}/act/dispatch",
                json={"intent": intent, "params": params},
                timeout=5
            )
            result = resp.json()
        except Exception as e:
            raise RuntimeError(f"ACT Gateway 调用失败: {e}")

        if result["execution"]["status"] == "ok":
            return result["payload"]
        else:
            error_info = result.get("error", {"message": "Unknown error"})
            raise RuntimeError(f"ACT 执行失败: {error_info}")

def patch_openclaw(openclaw_app, gateway_url="http://localhost:9000"):
    """
    将 OpenClaw 的 tool executor 替换为 ACTRuntime
    假设 openclaw_app 有 `tool_executor` 属性或方法
    """
    act_runtime = OpenClawACTRuntime(gateway_url)
    original_execute = openclaw_app.tool_executor.execute

    def wrapped_execute(tool_name, action, params):
        # 组合成技能名，假设 OpenClaw 技能名 = tool_name.action
        skill_name = f"{tool_name}.{action}" if action else tool_name
        try:
            return act_runtime.execute(skill_name, params)
        except Exception as e:
            # 可选择记录日志或回退
            raise e

    openclaw_app.tool_executor.execute = wrapped_execute