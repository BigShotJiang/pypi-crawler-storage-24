"""
自动生成 CrewAI 工具列表
"""

from act.adapters.crewai_adapter import ACTTool

def build_crewai_tools(kernel):
    """从内核注册表中生成所有 CrewAI 工具"""
    tools = []
    for (tool_name, action), metadata in kernel.registry._metadata.items():
        tools.append(ACTTool(kernel, tool_name, action, metadata))
    return tools
