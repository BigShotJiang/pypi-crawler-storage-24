"""
ACT Gateway – HTTP 服务，包含 ACT 执行端点和 MCP 兼容端点
"""

import time
import sys
from fastapi import FastAPI, HTTPException
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel
from typing import Any, Dict, Optional
import uvicorn

from act import ACTKernel, tool, register_tools_from_module
from act.tools.weather import *   # 导入内置示例工具

# 初始化内核
kernel = ACTKernel(default_timeout_ms=3000, default_retries=1)
# 注册内置工具
register_tools_from_module(kernel, sys.modules[__name__])

# 可选：加载用户自定义工具（从环境变量或目录）

app = FastAPI(title="ACT Gateway", version="1.0")

class DispatchRequest(BaseModel):
    intent: str
    params: Optional[Dict[str, Any]] = None
    context: Optional[Dict[str, Any]] = None

@app.post("/act/dispatch")
async def dispatch(request: DispatchRequest):
    params = request.params or {}
    context = request.context or {}
    result = await run_in_threadpool(kernel.dispatch, request.intent, params, context)
    return result

@app.get("/act/tools")
async def list_tools():
    """返回所有已注册工具的完整元数据"""
    tools = {}
    for (tool_name, action), meta in kernel.registry._metadata.items():
        tools[f"{tool_name}.{action}"] = {
            "description": meta.get("description", ""),
            "parameters": meta.get("parameters", {}),
            "timeout_ms": meta.get("timeout_ms", kernel.default_timeout_ms),
            "rate_limit": meta.get("rate_limit"),
            "retries": meta.get("retries", kernel.default_retries),
        }
    return tools

# MCP 兼容端点
@app.post("/mcp/tools/list")
async def mcp_list_tools():
    tools = []
    for (tool_name, action), meta in kernel.registry._metadata.items():
        tools.append({
            "name": f"{tool_name}.{action}",
            "description": meta.get("description", ""),
            "inputSchema": meta.get("parameters", {"type": "object", "additionalProperties": False})
        })
    return {"tools": tools}

@app.post("/mcp/tools/call")
async def mcp_call_tool(request: dict):
    tool_name = request.get("name")
    arguments = request.get("arguments", {})
    result = kernel.dispatch(tool_name, arguments)
    if result["execution"]["status"] == "ok":
        import json
        return {
            "content": [{"type": "text", "text": json.dumps(result["payload"])}],
            "isError": False
        }
    else:
        return {
            "content": [{"type": "text", "text": result.get("error", {}).get("message", "Unknown error")}],
            "isError": True
        }

@app.get("/health")
async def health():
    return {"status": "ok"}

def main():
    """命令行入口点"""
    uvicorn.run(app, host="0.0.0.0", port=9000)

if __name__ == "__main__":
    main()