import time
from act import tool

@tool(
    name="weather.get_current",
    description="获取指定城市的当前天气",
    timeout_ms=2000,
    rate_limit=2,
    parameters={
        "city": {"type": "string", "description": "城市名称"}
    }
)
def get_weather(params):
    city = params.get("city", "Beijing")
    time.sleep(0.2)
    return {"city": city, "temperature": 22, "condition": "sunny"}

@tool(
    name="weather.slow",
    description="故意慢的工具，用于演示超时",
    timeout_ms=1000,
    rate_limit=1,
    parameters={}
)
def slow_tool(params):
    time.sleep(2)
    return {"ok": True}

@tool(
    name="weather.error",
    description="故意失败的工具，用于演示熔断",
    timeout_ms=1000,
    rate_limit=5,
    parameters={}
)
def error_tool(params):
    raise Exception("Intentional tool error")