"""
示例工具：天气相关
"""

import time
from act import tool

@tool(
    name="weather.get_current",
    description="获取指定城市的当前天气",
    timeout_ms=2000,
    rate_limit=2,
    parameters={
        "city": {"type": "string", "description": "城市名称"}
    }
)
def get_weather(params):
    city = params.get("city", "Beijing")
    time.sleep(0.2)
    return {
        "city": city,
        "temperature": 22,
        "condition": "sunny"
    }

@tool(
    name="weather.get_forecast",
    description="获取未来几天的天气预报",
    timeout_ms=3000,
    rate_limit=1,
    parameters={
        "city": {"type": "string"},
        "days": {"type": "integer", "description": "天数"}
    }
)
def get_forecast(params):
    city = params.get("city", "Beijing")
    days = params.get("days", 3)
    time.sleep(0.5)
    return {
        "city": city,
        "forecast": [{"day": i, "temp": 20 + i} for i in range(days)]
    }

@tool(
    name="weather.slow_test",
    description="一个故意慢的工具，用于演示超时",
    timeout_ms=1000,
    rate_limit=5,
    parameters={}
)
def slow_test(params):
    time.sleep(2)
    return {"ok": True}
