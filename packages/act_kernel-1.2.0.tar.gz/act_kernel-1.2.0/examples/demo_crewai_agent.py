"""
CrewAI 集成示例：展示如何使用 ACT Kernel 作为执行层
"""

import sys
import os
# 确保可以导入 examples.tools
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import time
from crewai import Agent, Task, Crew, Process
from act import ACTKernel
from act.tooling import register_tools_from_module
from act.adapters.crewai_auto import build_crewai_tools

# 导入示例工具模块
import examples.tools.weather as weather_module

# 1. 初始化内核
kernel = ACTKernel(default_timeout_ms=3000, default_retries=1)

# 2. 自动注册工具（同时添加路由）
register_tools_from_module(kernel, weather_module)

# 3. 生成 CrewAI 工具列表
crewai_tools = build_crewai_tools(kernel)

# 4. 创建 CrewAI Agent
weather_agent = Agent(
    role="天气助手",
    goal="根据用户需求获取天气信息",
    backstory="你是一个专业的天气查询助手，可以使用天气工具。",
    tools=crewai_tools,
    verbose=True,
    allow_code_execution=False,
)

# 5. 定义任务
task = Task(
    description="查询上海今天的天气",
    expected_output="返回天气状况和温度",
    agent=weather_agent,
)

# 6. 创建 Crew 并运行
crew = Crew(
    agents=[weather_agent],
    tasks=[task],
    process=Process.sequential,
)

print("=== 运行 CrewAI Agent 调用 ACT 工具 ===\n")
result = crew.kickoff()
print("\n最终结果:", result)

# 7. 附加演示：限流效果
print("\n=== 限流演示（连续 5 次调用同一工具） ===\n")
slow_tool = next(t for t in crewai_tools if t.name == "weather.get_current")
for i in range(5):
    try:
        res = slow_tool._run(city="Beijing")
        print(f"调用 {i+1}: 成功 -> {res}")
    except Exception as e:
        print(f"调用 {i+1}: 失败 -> {e}")
    time.sleep(0.1)

# 8. 超时演示
print("\n=== 超时演示（使用慢工具） ===\n")
slow_tool2 = next(t for t in crewai_tools if t.name == "weather.slow_test")
try:
    result = slow_tool2._run()
    print("慢工具调用成功（不应发生）:", result)
except Exception as e:
    print("慢工具调用失败（预期超时）:", e)
