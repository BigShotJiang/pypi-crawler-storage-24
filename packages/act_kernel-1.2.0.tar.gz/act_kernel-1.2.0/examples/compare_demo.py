import time
import random
from act import ACTKernel, tool

# ---------- 不稳定工具 ----------
def unstable_tool(params):
    time.sleep(random.uniform(0.5, 2.5))
    if random.random() < 0.3:
        raise Exception("外部服务故障")
    return {"data": "success"}

# ---------- 原生调用 ----------
def native_call():
    print("❌ 原生调用（无超时、重试、熔断）")
    for i in range(10):
        try:
            result = unstable_tool({})
            print(f"  第{i+1}次: 成功")
        except Exception as e:
            print(f"  第{i+1}次: 失败 -> {e}")
        time.sleep(0.5)

# ---------- ACT 包装 ----------
@tool(name="test.unstable", timeout_ms=1000, retries=2, rate_limit=2)
def act_wrapped_tool(params):
    return unstable_tool(params)

def act_call():
    print("✅ ACT 调用（超时1s + 重试2次 + 限流2/s）")
    kernel = ACTKernel()
    kernel.register_tool("test", "unstable", act_wrapped_tool,
                         metadata={"timeout_ms": 1000, "retries": 2, "rate_limit": 2})
    for i in range(10):
        result = kernel.dispatch("test.unstable", {})
        status = result["execution"]["status"]
        if status == "ok":
            print(f"  第{i+1}次: 成功")
        else:
            print(f"  第{i+1}次: 失败 -> {result['error']['code']}")
        time.sleep(0.5)

if __name__ == "__main__":
    native_call()
    print("-" * 40)
    act_call()