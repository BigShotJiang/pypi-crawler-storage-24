# ACT Kernel – Execution Layer for AI Agents

[![PyPI version](https://badge.fury.io/py/act-kernel.svg)](https://pypi.org/project/act-kernel/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![MCP Compatible](https://img.shields.io/badge/MCP-Compatible-blue)](https://modelcontextprotocol.io)
[![OpenClaw Ready](https://img.shields.io/badge/OpenClaw-Ready-brightgreen)](https://github.com/openclaw/openclaw)

**ACT Kernel** 是一个轻量级执行层，为 AI Agent 提供**超时、重试、限流、熔断、统一观测**等生产级能力。它可以无缝接管 OpenClaw、CrewAI、MCP 等框架的工具调用，让不可靠的执行变得稳定可控。

> **Make AI Agents reliable in production.**

<div align="right">
  <small><a href="README.zh.md">中文版</a> | <a href="README.md">English</a></small>
</div>

## 为什么需要 ACT？

| 能力 | 原生 Agent | ACT 加持 |
|------|----------|---------|
| 超时控制 | ❌ 永久卡死 | ✅ 可配置超时 |
| 自动重试 | ❌ 一次性失败 | ✅ 指数退避重试 |
| 限流保护 | ❌ 无限制 | ✅ 令牌桶限流 |
| 熔断机制 | ❌ 雪崩风险 | ✅ 自动熔断恢复 |
| 统一观测 | ❌ 日志混乱 | ✅ 标准 Envelope |

## 一键安装

```bash
# Linux / macOS
curl -fsSL https://raw.githubusercontent.com/deepseek609609-collab/act-kernel-agent/main/scripts/install.sh | bash

# Windows (PowerShell 管理员)
powershell -ExecutionPolicy Bypass -Command "& { Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/deepseek609609-collab/act-kernel-agent/main/scripts/install.ps1' -OutFile install.ps1; .\install.ps1 }"
```

## 生态接管

### 🦞 OpenClaw 运行时替换

```python
from act.adapters.openclaw_runtime import patch_openclaw
patch_openclaw(openclaw_app)   # 之后所有 Skill 自动获得 ACT 治理
```

### 🔌 MCP 兼容端点

ACT Gateway 原生支持 MCP 协议，任何 MCP 客户端可直接调用：

```http
POST /mcp/tools/list
POST /mcp/tools/call
```

### 🚀 CrewAI 集成

```python
from act.adapters.crewai_auto import build_crewai_tools
tools = build_crewai_tools(kernel)
agent = Agent(tools=tools, ...)
```

## 快速体验

```bash
# 启动 Gateway
act-gateway

# 调用工具
curl -X POST http://localhost:9000/act/dispatch \
  -H "Content-Type: application/json" \
  -d '{"intent": "weather.get_current", "params": {"city": "Beijing"}}'
```

## 演示：Before vs After

[点击查看 GIF 演示](https://via.placeholder.com/800x400?text=GIF+Demo+Placeholder)

## 文档

- [协议规范](docs/protocol.md)
- [架构说明](docs/architecture.md)
- [贡献指南](CONTRIBUTING.md)

## 许可证

MIT