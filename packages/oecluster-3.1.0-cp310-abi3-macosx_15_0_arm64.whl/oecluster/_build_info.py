# Auto-generated build information - do not edit
OPENEYE_BUILD_VERSION = "2025.2.1"
OPENEYE_LIBRARY_TYPE = "SHARED"
OPENEYE_EXPECTED_LIBS = ["liboechem-4.3.0.1.dylib", "liboesystem-4.3.0.1.dylib", "liboeplatform-4.3.0.1.dylib", "liboemath-2.9.1.1.dylib", "libzstd.1.dylib", "liboegraphsim-2.7.0.1.dylib", "liboeshape.a", "liboehermite.a", "liboeopt.a", "liboemolpotential.a", "liboebio.a", "liboegrid-4.3.0.1.dylib", "liboezap.a", "liboespicoli.a", "liboesitehopper.a", "liboespruce.a"]
