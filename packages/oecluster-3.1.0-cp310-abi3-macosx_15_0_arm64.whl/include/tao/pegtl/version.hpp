// Copyright (c) 2017-2022 Dr. Colin Hirsch and Daniel Frey
// Please see LICENSE for license or visit https://github.com/taocpp/PEGTL/

#ifndef TAO_PEGTL_VERSION_HPP
#define TAO_PEGTL_VERSION_HPP

#define TAO_PEGTL_VERSION "3.2.7"

#define TAO_PEGTL_VERSION_MAJOR 3
#define TAO_PEGTL_VERSION_MINOR 2
#define TAO_PEGTL_VERSION_PATCH 7

#endif
