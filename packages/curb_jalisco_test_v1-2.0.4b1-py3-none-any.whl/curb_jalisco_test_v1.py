def saludo(): print('Curb v2 funcionando desde Jalisco')
