# VeldrabDB

Una librería simple para manejar bases de datos SQLite en Python.

## Instalación

```bash
pip install veldrab
```

## Uso

```python
from veldrab import VeldrabDB

# Crear instancia de la base de datos
db = VeldrabDB("mi_base.db")

# Crear tabla
db.create_table("usuarios", {"id": "INTEGER PRIMARY KEY", "nombre": "TEXT", "edad": "INTEGER"})

# Insertar datos
db.insert("usuarios", {"nombre": "Juan", "edad": 25})

# Seleccionar datos
resultados = db.select("usuarios")
print(resultados)

# Actualizar datos
db.update("usuarios", {"edad": 26}, "nombre = 'Juan'")

# Eliminar datos
db.delete("usuarios", "nombre = 'Juan'")

# Cerrar conexión
db.close()
```

## Funciones disponibles

- `VeldrabDB(db_name)`: Inicializa la conexión a la base de datos.
- `create_table(table_name, columns)`: Crea una tabla.
- `insert(table_name, data)`: Inserta datos.
- `select(table_name, columns, where)`: Selecciona datos.
- `update(table_name, data, where)`: Actualiza datos.
- `delete(table_name, where)`: Elimina datos.
- `close()`: Cierra la conexión.