# Este es el archivo __init__.py para el paquete veldrab (VeldrabDB)
# Librería simple para manejar bases de datos SQLite

import sqlite3
from typing import List, Tuple, Any

class VeldrabDB:
    def __init__(self, db_name: str = "veldrab.db"):
        self.db_name = db_name
        self.connection = None
        self.connect()

    def connect(self):
        """Conecta a la base de datos."""
        self.connection = sqlite3.connect(self.db_name)
        print(f"Conectado a la base de datos: {self.db_name}")

    def create_table(self, table_name: str, columns: dict):
        """Crea una tabla con las columnas especificadas.
        columns: {'columna1': 'tipo', 'columna2': 'tipo'}
        """
        columns_str = ", ".join([f"{col} {tipo}" for col, tipo in columns.items()])
        query = f"CREATE TABLE IF NOT EXISTS {table_name} ({columns_str})"
        self.execute_query(query)
        print(f"Tabla '{table_name}' creada o ya existe.")

    def insert(self, table_name: str, data: dict):
        """Inserta datos en la tabla."""
        columns = ", ".join(data.keys())
        placeholders = ", ".join(["?" for _ in data])
        values = tuple(data.values())
        query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
        self.execute_query(query, values)
        print("Datos insertados.")

    def select(self, table_name: str, columns: List[str] = None, where: str = None) -> List[Tuple]:
        """Selecciona datos de la tabla."""
        if columns is None:
            columns = "*"
        else:
            columns = ", ".join(columns)
        query = f"SELECT {columns} FROM {table_name}"
        if where:
            query += f" WHERE {where}"
        return self.execute_query(query, fetch=True)

    def update(self, table_name: str, data: dict, where: str):
        """Actualiza datos en la tabla."""
        set_str = ", ".join([f"{col} = ?" for col in data.keys()])
        values = tuple(data.values())
        query = f"UPDATE {table_name} SET {set_str} WHERE {where}"
        self.execute_query(query, values)
        print("Datos actualizados.")

    def delete(self, table_name: str, where: str):
        """Elimina datos de la tabla."""
        query = f"DELETE FROM {table_name} WHERE {where}"
        self.execute_query(query)
        print("Datos eliminados.")

    def execute_query(self, query: str, params: Tuple = (), fetch: bool = False) -> List[Tuple]:
        """Ejecuta una consulta SQL."""
        try:
            cursor = self.connection.cursor()
            cursor.execute(query, params)
            if fetch:
                result = cursor.fetchall()
                return result
            self.connection.commit()
        except sqlite3.Error as e:
            print(f"Error en la consulta: {e}")
            return []

    def close(self):
        """Cierra la conexión."""
        if self.connection:
            self.connection.close()
            print("Conexión cerrada.")

# Función de ejemplo
def hola():
    print("¡Hola desde VeldrabDB!")

# Ejemplo de uso:
# db = VeldrabDB()
# db.create_table("usuarios", {"id": "INTEGER PRIMARY KEY", "nombre": "TEXT", "edad": "INTEGER"})
# db.insert("usuarios", {"nombre": "Juan", "edad": 25})
# print(db.select("usuarios"))
# db.close()