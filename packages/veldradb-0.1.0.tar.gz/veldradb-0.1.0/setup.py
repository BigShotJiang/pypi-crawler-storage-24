from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="VelDraDB",
    version="0.1.0",
    packages=find_packages(),
    description="Embedded ECS-based database engine for enterprise game engines.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Tu Nombre",
    author_email="tuemail@example.com",
    url="https://github.com/sudo-bautista-johansson/VeldraDB",
    license="MIT",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.6",
)