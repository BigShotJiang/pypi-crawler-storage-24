"""Data mutation operations for PyStreamCI."""

from __future__ import annotations

import json
import logging
import mimetypes
from pathlib import Path
from typing import Any, IO

import requests

from .auth import Auth
from .exceptions import StreamCIValidationError, StreamCIRequestError
from .response import parse_mutation_response
from .retry import RetryHandler
from ._types import Document, BlobsDict

logger = logging.getLogger(__name__)

_MAX_BATCH_SIZE = 10_000


def _normalize_blobs(
    blobs: BlobsDict,
) -> tuple[dict[str, tuple[str, IO[bytes], str]], list[IO[bytes]]]:
    """Normalise *blobs* to ``{key: (filename, fileobj, mime)}`` 3-tuples.

    Accepts any of:
    - ``IO[bytes]``  — file object (bare)
    - ``str`` / ``Path``  — file path (opened here; caller must close)
    - ``(name, IO[bytes])``  — 2-tuple
    - ``(name, IO[bytes], mime)``  — 3-tuple (existing format, unchanged)

    Also strips quote characters from bracket-notation keys so that
    Python-native ``abc["def"]`` becomes ``abc[def]`` as the server expects.

    Returns ``(normalised_dict, opened_files)`` where *opened_files* is a list
    of file handles opened for path inputs — the caller must close them.
    """
    if not blobs:
        return {}, []

    normalised: dict[str, tuple[str, IO[bytes], str]] = {}
    opened: list[IO[bytes]] = []

    for raw_key, value in blobs.items():
        key = raw_key.replace('"', '').replace("'", '')

        if isinstance(value, (str, Path)):
            path = Path(value)
            if not path.exists():
                raise StreamCIValidationError(f"Blob file not found: {path}")
            fh = path.open("rb")
            opened.append(fh)
            mime, _ = mimetypes.guess_type(str(path))
            normalised[key] = (path.name, fh, mime or "application/octet-stream")

        elif isinstance(value, tuple):
            if len(value) == 3:
                normalised[key] = value  # type: ignore[assignment]
            elif len(value) == 2:
                name, fobj = value  # type: ignore[misc]
                mime, _ = mimetypes.guess_type(name)
                normalised[key] = (name, fobj, mime or "application/octet-stream")
            else:
                raise StreamCIValidationError(
                    f"Blob tuple for key '{key}' must have 2 or 3 elements, got {len(value)}"
                )

        elif hasattr(value, "read"):  # IO[bytes] duck-type check
            name = getattr(value, "name", None)
            if name:
                name = Path(name).name
                mime, _ = mimetypes.guess_type(name)
            else:
                name = "blob"
                mime = None
            normalised[key] = (name, value, mime or "application/octet-stream")  # type: ignore[arg-type]

        else:
            raise StreamCIValidationError(
                f"Unsupported blob value type for key '{key}': {type(value).__name__}. "
                "Expected IO[bytes], str/Path, or a 2- or 3-tuple."
            )

    return normalised, opened


class DataOperations:
    """Provides insert, insert_many, insert_file, update, and delete operations."""

    def __init__(
        self,
        session: requests.Session,
        base_url: str,
        auth: Auth,
        retry: RetryHandler,
        timeout: float,
    ) -> None:
        self._session = session
        self._url = base_url.rstrip("/") + "/data"
        self._auth = auth
        self._retry = retry
        self._timeout = timeout

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _post_json(self, payload: dict) -> dict:
        def _do():
            logger.debug("POST %s method=%s", self._url, payload.get("request", {}).get("method"))
            resp = self._session.post(self._url, json=payload, timeout=self._timeout)
            resp.raise_for_status()
            return resp

        resp = self._retry.execute(_do, description=f"data/{payload['request']['method']}")
        result = parse_mutation_response(resp.text)
        logger.info(
            "%s completed: %s",
            payload["request"]["method"],
            result.get("msg", "ok"),
        )
        return result

    def _post_multipart(self, data_fields: dict, files: dict[str, Any]) -> dict:
        """POST multipart/form-data with JSON-serialised text fields."""
        encoded = {
            k: json.dumps(v) if isinstance(v, (dict, list)) else v
            for k, v in data_fields.items()
        }

        def _do():
            logger.debug("POST multipart %s", self._url)
            resp = self._session.post(
                self._url, data=encoded, files=files, timeout=self._timeout
            )
            resp.raise_for_status()
            return resp

        resp = self._retry.execute(_do, description="data/multipart")
        return parse_mutation_response(resp.text)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def insert(
        self,
        data: Document,
        blobs: BlobsDict = None,
    ) -> dict:
        """Insert a single document.

        Pass *blobs* to include blob fields (multipart); omit for JSON-only insert.
        """
        if blobs:
            normalised, opened = _normalize_blobs(blobs)
            try:
                data_fields = {
                    "auth": self._auth.to_dict(),
                    "request": {"method": "insert", "data": data},
                }
                return self._post_multipart(data_fields, normalised)
            finally:
                for fh in opened:
                    fh.close()

        return self._post_json(
            {"auth": self._auth.to_dict(), "request": {"method": "insert", "data": data}}
        )

    def insert_many(
        self,
        data: list[Document],
        datatype: str = "json",
        batch_size: int = 1000,
    ) -> list[dict]:
        """Send *data* in batches of *batch_size* (max 10 000 per batch).

        Returns a list of server responses, one per batch.
        """
        if datatype not in ("json", "csv"):
            raise StreamCIValidationError(f"Unsupported datatype '{datatype}'. Use 'json' or 'csv'.")
        if batch_size < 1 or batch_size > _MAX_BATCH_SIZE:
            raise StreamCIValidationError(
                f"batch_size must be between 1 and {_MAX_BATCH_SIZE}, got {batch_size}"
            )

        results = []
        total = len(data)
        for start in range(0, total, batch_size):
            batch = data[start : start + batch_size]
            logger.info(
                "insert_many batch %d-%d / %d",
                start + 1,
                min(start + batch_size, total),
                total,
            )
            result = self._post_json(
                {
                    "auth": self._auth.to_dict(),
                    "request": {
                        "method": "bulkload",
                        "data": batch,
                        "datatype": datatype,
                    },
                }
            )
            results.append(result)
        return results

    def insert_file(self, file_path: str | Path, datatype: str = "json") -> dict:
        """Upload an NDJSON or CSV file via multipart/form-data."""
        file_path = Path(file_path)
        if not file_path.exists():
            raise StreamCIValidationError(f"File not found: {file_path}")

        data_fields = {
            "auth": self._auth.to_dict(),
            "request": {"method": "upload", "datatype": datatype},
        }
        with file_path.open("rb") as fh:
            files = {"file": (file_path.name, fh, "application/octet-stream")}
            return self._post_multipart(data_fields, files)

    def update(
        self,
        filter: Document,
        data: Document,
        blobs: BlobsDict = None,
    ) -> dict:
        """Update document(s) matching *filter*.

        Pass *blobs* to include blob fields (multipart); omit for JSON-only update.
        """
        if blobs:
            normalised, opened = _normalize_blobs(blobs)
            try:
                data_fields = {
                    "auth": self._auth.to_dict(),
                    "request": {"method": "update", "filter": filter, "data": data},
                }
                return self._post_multipart(data_fields, normalised)
            finally:
                for fh in opened:
                    fh.close()

        return self._post_json(
            {
                "auth": self._auth.to_dict(),
                "request": {"method": "update", "filter": filter, "data": data},
            }
        )

    def delete(self, filter: Document) -> dict:
        """Delete document(s) matching *filter*."""
        return self._post_json(
            {
                "auth": self._auth.to_dict(),
                "request": {"method": "remove", "filter": filter},
            }
        )
