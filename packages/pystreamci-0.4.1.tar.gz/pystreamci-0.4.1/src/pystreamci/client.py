"""StreamCIClient — main connector for PyStreamCI."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Iterator

import requests

from .auth import Auth
from .data import DataOperations
from .query import QueryOperations
from .logger import setup_logger
from .retry import RetryHandler
from ._types import Document, BlobsDict

logger = logging.getLogger(__name__)


class StreamCIClient:
    """Connector-style client for the StreamCI API.

    Usage::

        client = StreamCIClient(host="https://api.streamci.org",
                                target="my_sensors",
                                secret_key="...")
        client.connect()
        try:
            client.insert({"val": 1})
        finally:
            client.close()

    Prefer using as a context manager via :func:`pystreamci.connect`.
    """

    def __init__(
        self,
        host: str,
        target: str,
        *,
        authtype: str = "secret",
        secret_key: str | None = None,
        username: str | None = None,
        password: str | None = None,
        max_retries: int = 3,
        timeout: float = 30.0,
        log_level: int | str = logging.WARNING,
        log_file: str | Path | None = None,
    ) -> None:
        self._host = host.rstrip("/")
        self._auth = Auth(
            target=target,
            authtype=authtype,
            secret_key=secret_key,
            username=username,
            password=password,
        )
        self._max_retries = max_retries
        self._timeout = timeout

        # Set up package-level logger
        setup_logger("pystreamci", level=log_level, log_file=log_file)

        self._session: requests.Session | None = None
        self._retry: RetryHandler | None = None
        self._data_ops: DataOperations | None = None
        self._query_ops: QueryOperations | None = None

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    def connect(self) -> "StreamCIClient":
        """Open the underlying HTTP session.  Returns *self* for chaining."""
        if self._session is not None:
            return self  # Already connected
        self._session = requests.Session()
        self._retry = RetryHandler(max_retries=self._max_retries)
        self._data_ops = DataOperations(
            self._session, self._host, self._auth, self._retry, self._timeout
        )
        self._query_ops = QueryOperations(
            self._session, self._host, self._auth, self._retry, self._timeout
        )
        logger.debug("StreamCIClient connected to %s (target=%s)", self._host, self._auth.target)
        return self

    def close(self) -> None:
        """Close the HTTP session."""
        if self._session is not None:
            self._session.close()
            self._session = None
            logger.debug("StreamCIClient disconnected")

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "StreamCIClient":
        return self.connect()

    def __exit__(self, *_: Any) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Sub-operation accessors
    # ------------------------------------------------------------------

    @property
    def data(self) -> DataOperations:
        """Access :class:`DataOperations` directly."""
        if self._data_ops is None:
            raise RuntimeError("Client is not connected. Call connect() first.")
        return self._data_ops

    @property
    def queries(self) -> QueryOperations:
        """Access :class:`QueryOperations` directly."""
        if self._query_ops is None:
            raise RuntimeError("Client is not connected. Call connect() first.")
        return self._query_ops

    # ------------------------------------------------------------------
    # Shortcut methods (delegates to sub-operations)
    # ------------------------------------------------------------------

    def insert(
        self,
        data: Document,
        blobs: BlobsDict = None,
    ) -> dict:
        return self.data.insert(data, blobs=blobs)

    def insert_many(
        self,
        data: list[Document],
        datatype: str = "json",
        batch_size: int = 1000,
    ) -> list[dict]:
        return self.data.insert_many(data, datatype=datatype, batch_size=batch_size)

    def insert_file(self, file_path: str | Path, datatype: str = "json") -> dict:
        return self.data.insert_file(file_path, datatype=datatype)

    def update(
        self,
        filter: Document,
        data: Document,
        blobs: BlobsDict = None,
    ) -> dict:
        return self.data.update(filter, data, blobs=blobs)

    def delete(self, filter: Document) -> dict:
        return self.data.delete(filter)

    def query(
        self,
        query: Document | None = None,
        *,
        project: list[str] | None = None,
        sort: dict[str, int] | None = None,
        limit: int | None = None,
    ) -> list[Document]:
        return self.queries.query(
            query, project=project, sort=sort, limit=limit
        )

    def query_iter(
        self,
        query: Document | None = None,
        *,
        project: list[str] | None = None,
        sort: dict[str, int] | None = None,
        limit: int | None = None,
    ) -> Iterator[Document]:
        return self.queries.query_iter(
            query, project=project, sort=sort, limit=limit
        )

    def query_blob(self, document_id: str, field: str) -> bytes:
        return self.queries.query_blob(document_id, field)

    def query_blobs_by_field(self, document_ids: list[str], field: str) -> dict[str, bytes]:
        return self.queries.query_blobs_by_field(document_ids, field)

    def query_blobs_by_doc(
        self, document_id: str, *, ignore_errors: bool = False
    ) -> dict[str, bytes]:
        return self.queries.query_blobs_by_doc(document_id, ignore_errors=ignore_errors)

    def __repr__(self) -> str:
        status = "connected" if self._session else "disconnected"
        return (
            f"StreamCIClient(host={self._host!r}, "
            f"target={self._auth.target!r}, {status})"
        )
