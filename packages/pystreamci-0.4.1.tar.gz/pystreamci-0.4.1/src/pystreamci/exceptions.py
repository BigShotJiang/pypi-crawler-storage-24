"""Exception hierarchy for PyStreamCI."""


class StreamCIError(Exception):
    """Base exception for all PyStreamCI errors."""


class StreamCIConnectionError(StreamCIError):
    """Connection failed (retries exhausted)."""


class StreamCIRequestError(StreamCIError):
    """Server returned error response (status=0)."""

    def __init__(self, message: str, response: dict | None = None) -> None:
        super().__init__(message)
        self.response = response


class StreamCIAuthError(StreamCIRequestError):
    """Authentication or authorization error."""


class StreamCIParseError(StreamCIError):
    """Response parsing failed."""


class StreamCITimeoutError(StreamCIError):
    """Request timed out."""


class StreamCIValidationError(StreamCIError):
    """Client-side validation error."""
