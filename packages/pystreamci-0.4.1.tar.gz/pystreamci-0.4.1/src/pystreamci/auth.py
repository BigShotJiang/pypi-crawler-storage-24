"""Authentication dataclass for PyStreamCI."""

from __future__ import annotations

from dataclasses import dataclass

from .exceptions import StreamCIValidationError
from ._types import AuthDict


@dataclass(frozen=True)
class Auth:
    """Holds authentication credentials for a StreamCI target.

    Supports two auth types:
    - ``"secret"``: requires ``secret_key``
    - ``"password"``: requires ``username`` and ``password``
    """

    target: str
    authtype: str
    secret_key: str | None = None
    username: str | None = None
    password: str | None = None

    def __post_init__(self) -> None:
        if not self.target:
            raise StreamCIValidationError("target must not be empty")
        if self.authtype == "secret":
            if not self.secret_key:
                raise StreamCIValidationError("secret_key required for authtype='secret'")
        elif self.authtype == "password":
            if not self.username or not self.password:
                raise StreamCIValidationError(
                    "username and password required for authtype='password'"
                )
        else:
            raise StreamCIValidationError(
                f"Unsupported authtype '{self.authtype}'. Use 'secret' or 'password'."
            )

    def to_dict(self) -> AuthDict:
        """Return the auth block expected by the StreamCI API."""
        d: AuthDict = {"target": self.target, "authtype": self.authtype}
        if self.secret_key is not None:
            d["secret_key"] = self.secret_key
        if self.username is not None:
            d["username"] = self.username
        if self.password is not None:
            d["password"] = self.password
        return d
