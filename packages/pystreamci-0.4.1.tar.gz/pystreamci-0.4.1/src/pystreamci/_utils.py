"""Utility helpers for PyStreamCI."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def make_date(dt: datetime | str) -> dict[str, str]:
    """Convert a datetime or ISO-8601 string to a StreamCI ``$date`` object.

    Examples::

        make_date("2025-08-04T10:00:00Z")
        # → {"$date": "2025-08-04T10:00:00Z"}

        make_date(datetime(2025, 8, 4, 10, 0, 0, tzinfo=timezone.utc))
        # → {"$date": "2025-08-04T10:00:00Z"}
    """
    if isinstance(dt, datetime):
        if dt.tzinfo is None:
            # Assume UTC for naive datetimes
            dt = dt.replace(tzinfo=timezone.utc)
        iso = dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"
        # Drop milliseconds if zero for cleaner output
        if dt.microsecond == 0:
            iso = dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        return {"$date": iso}
    # Already a string — pass through as-is
    return {"$date": str(dt)}


def _is_blob_field(value: Any) -> bool:
    """Return True if *value* looks like a StreamCI blob metadata object."""
    meta = value
    if isinstance(value, list) and len(value) >= 2 and value[0] == "blob":
        meta = value[1]
    return (
        isinstance(meta, dict)
        and isinstance(meta.get("S3key"), str)
        and isinstance(meta.get("S3bucket"), str)
        and bool(meta["S3key"])
        and bool(meta["S3bucket"])
    )


def _find_blob_paths(obj: Any, prefix: str = "") -> list[str]:
    """Recursively find all blob field dot-notation paths in a document."""
    paths = []
    if isinstance(obj, dict):
        for key, value in obj.items():
            path = f"{prefix}.{key}" if prefix else key
            if key == "_id":
                continue
            if _is_blob_field(value):
                paths.append(path)
            elif isinstance(value, dict):
                paths.extend(_find_blob_paths(value, path))
            elif isinstance(value, list):
                paths.extend(_find_blob_paths(value, path))
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            path = f"{prefix}.{i}"
            if _is_blob_field(item):
                paths.append(path)
            elif isinstance(item, (dict, list)):
                paths.extend(_find_blob_paths(item, path))
    return paths
