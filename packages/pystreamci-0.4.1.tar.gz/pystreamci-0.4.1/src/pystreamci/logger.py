"""Logging setup for PyStreamCI."""

import logging
from pathlib import Path


def setup_logger(
    name: str,
    level: int | str = logging.WARNING,
    log_file: str | Path | None = None,
) -> logging.Logger:
    """Return a logger with console (and optional file) handler.

    If the logger already has handlers attached (e.g. called multiple times),
    existing handlers are cleared first to avoid duplicate output.
    """
    logger = logging.getLogger(name)
    logger.handlers.clear()
    logger.setLevel(level)
    logger.propagate = False

    formatter = logging.Formatter(
        "%(asctime)s [%(name)s] %(levelname)s %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )

    console = logging.StreamHandler()
    console.setFormatter(formatter)
    logger.addHandler(console)

    if log_file is not None:
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    return logger
