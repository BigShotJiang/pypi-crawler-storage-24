"""PyStreamCI — Python client library for StreamCI.

Quickstart::

    import pystreamci

    # Secret-key auth (context manager)
    with pystreamci.connect("https://api.streamci.org",
                            target="my_sensors",
                            secret_key="...") as client:
        client.insert({"val": 42})
        docs = client.query({"val": {"$gte": 10}})

    # Password auth
    client = pystreamci.connect("https://api.streamci.org",
                                target="my_sensors",
                                username="user1", password="pass123")
    client.connect()
    ...
    client.close()
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .auth import Auth
from .client import StreamCIClient
from .exceptions import (
    StreamCIError,
    StreamCIAuthError,
    StreamCIConnectionError,
    StreamCIParseError,
    StreamCIRequestError,
    StreamCITimeoutError,
    StreamCIValidationError,
)
from ._utils import make_date

__all__ = [
    "connect",
    "StreamCIClient",
    "Auth",
    # Exceptions
    "StreamCIError",
    "StreamCIAuthError",
    "StreamCIConnectionError",
    "StreamCIParseError",
    "StreamCIRequestError",
    "StreamCITimeoutError",
    "StreamCIValidationError",
    # Utilities
    "make_date",
]

__version__ = "0.4.1"


def connect(
    host: str,
    target: str,
    *,
    secret_key: str | None = None,
    username: str | None = None,
    password: str | None = None,
    max_retries: int = 3,
    timeout: float = 30.0,
    log_level: int | str = "WARNING",
    log_file: str | Path | None = None,
) -> StreamCIClient:
    """Create and return a :class:`StreamCIClient`.

    Auth type is inferred automatically:
    - Provide ``secret_key`` → ``authtype="secret"``
    - Provide ``username`` + ``password`` → ``authtype="password"``

    The returned client **is not yet connected**.  Use it as a context manager
    (recommended) or call :meth:`StreamCIClient.connect` manually::

        # Context manager — connects and closes automatically
        with pystreamci.connect(...) as client:
            client.insert(...)

        # Manual lifecycle
        client = pystreamci.connect(...)
        client.connect()
        try:
            client.insert(...)
        finally:
            client.close()
    """
    if secret_key is not None:
        authtype = "secret"
    elif username is not None and password is not None:
        authtype = "password"
    else:
        raise StreamCIValidationError(
            "Provide either secret_key or both username and password."
        )

    return StreamCIClient(
        host=host,
        target=target,
        authtype=authtype,
        secret_key=secret_key,
        username=username,
        password=password,
        max_retries=max_retries,
        timeout=timeout,
        log_level=log_level,
        log_file=log_file,
    )
