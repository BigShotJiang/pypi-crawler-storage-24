"""Exponential-backoff retry handler for PyStreamCI."""

from __future__ import annotations

import logging
import time
from typing import Callable, TypeVar

import requests

from .exceptions import StreamCIConnectionError, StreamCITimeoutError

T = TypeVar("T")

logger = logging.getLogger(__name__)


class RetryHandler:
    """Retries a callable on transient network errors with exponential backoff.

    Retries on:
    - ``requests.ConnectionError``
    - ``requests.Timeout``
    """

    def __init__(
        self,
        max_retries: int = 3,
        backoff_base: float = 1.0,
        backoff_max: float = 30.0,
    ) -> None:
        self.max_retries = max_retries
        self.backoff_base = backoff_base
        self.backoff_max = backoff_max

    def execute(self, fn: Callable[[], T], description: str = "request") -> T:
        """Call *fn* and retry on transient errors.

        :param fn: Zero-argument callable that performs the HTTP request.
        :param description: Human-readable label used in log messages.
        :raises StreamCIConnectionError: When all retries are exhausted.
        :raises StreamCITimeoutError: When a timeout occurs and retries are exhausted.
        """
        last_exc: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                return fn()
            except requests.Timeout as exc:
                last_exc = exc
                if attempt >= self.max_retries:
                    raise StreamCITimeoutError(
                        f"{description} timed out after {self.max_retries} retries"
                    ) from exc
                wait = min(self.backoff_base * (2**attempt), self.backoff_max)
                logger.warning(
                    "Timeout on %s (attempt %d/%d), retrying in %.1fs",
                    description,
                    attempt + 1,
                    self.max_retries,
                    wait,
                )
                time.sleep(wait)
            except requests.ConnectionError as exc:
                last_exc = exc
                if attempt >= self.max_retries:
                    raise StreamCIConnectionError(
                        f"{description} failed after {self.max_retries} retries: {exc}"
                    ) from exc
                wait = min(self.backoff_base * (2**attempt), self.backoff_max)
                logger.warning(
                    "ConnectionError on %s (attempt %d/%d), retrying in %.1fs",
                    description,
                    attempt + 1,
                    self.max_retries,
                    wait,
                )
                time.sleep(wait)

        # Should not reach here
        raise StreamCIConnectionError(f"{description} failed") from last_exc
