"""Type aliases and TypedDicts for PyStreamCI."""

from pathlib import Path
from typing import Any, IO, Union

# JSON-compatible value
JSONValue = Any

# A document (dict) returned from a query
Document = dict[str, Any]

# Auth block sent to the API
AuthDict = dict[str, str]

# Raw request block
RequestDict = dict[str, Any]

# Blob value formats accepted by insert() / update()
BlobValue = Union[
    "IO[bytes]",
    str,
    Path,
    "tuple[str, IO[bytes]]",
    "tuple[str, IO[bytes], str]",
]
BlobsDict = Union[dict[str, BlobValue], None]
