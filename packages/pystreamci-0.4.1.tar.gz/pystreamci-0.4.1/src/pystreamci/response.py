"""Response parsing utilities for PyStreamCI."""

from __future__ import annotations

import json
import logging
from typing import Iterator

import requests

from .exceptions import StreamCIAuthError, StreamCIParseError, StreamCIRequestError
from ._types import Document

logger = logging.getLogger(__name__)

_AUTH_ERROR_PATTERNS = (
    "invalid authentication",
    "permission denied",
    "wrong secret key",
)


def _is_auth_error(msg: str) -> bool:
    """Check if the error message indicates an authentication/authorization failure."""
    msg_lower = msg.lower()
    return any(pattern in msg_lower for pattern in _AUTH_ERROR_PATTERNS)


def _raise_request_error(msg: str, response: dict | None) -> None:
    """Raise StreamCIAuthError or StreamCIRequestError based on message content."""
    if _is_auth_error(msg):
        raise StreamCIAuthError(msg, response=response)
    raise StreamCIRequestError(msg, response=response)


def _decode_line(line: str) -> Document:
    """Parse a single NDJSON line, handling double-encoded strings."""
    data = json.loads(line)
    if isinstance(data, str):
        # Double-encoded: the value itself is a JSON string
        data = json.loads(data)
    return data


def parse_ndjson(text: str) -> list[Document]:
    """Parse an NDJSON response body into a list of documents.

    Handles:
    - Empty / whitespace-only responses (returns ``[]``).
    - Single JSON object (wraps in a list).
    - Double-encoded strings.
    """
    if not text or not text.strip():
        return []

    lines = [l for l in text.strip().splitlines() if l.strip()]
    if not lines:
        return []

    try:
        results: list[Document] = []
        for line in lines:
            results.append(_decode_line(line))
        return results
    except json.JSONDecodeError as exc:
        raise StreamCIParseError(f"NDJSON parse error: {exc}. Text: {text[:200]}") from exc


def parse_ndjson_stream(response: requests.Response) -> Iterator[Document]:
    """Yield documents from a streaming NDJSON response line by line.

    Uses ``iter_lines`` to avoid loading the full body into memory.
    """
    try:
        for raw_line in response.iter_lines(decode_unicode=True):
            if not raw_line or not raw_line.strip():
                continue
            try:
                yield _decode_line(raw_line)
            except json.JSONDecodeError as exc:
                raise StreamCIParseError(
                    f"NDJSON stream parse error: {exc}. Line: {raw_line[:200]}"
                ) from exc
    except requests.RequestException as exc:
        from .exceptions import StreamCIConnectionError
        raise StreamCIConnectionError(f"Stream read error: {exc}") from exc


def parse_mutation_response(text: str) -> dict:
    """Parse a mutation (insert/update/delete/bulkload) response.

    Expected format: ``{"status": 1, "msg": "..."}``

    :raises StreamCIRequestError: When ``status`` is 0 (server-side error).
    :raises StreamCIParseError: When the response is not valid JSON.
    """
    if not text or not text.strip():
        raise StreamCIParseError("Empty response from server")

    try:
        data = json.loads(text)
        if isinstance(data, str):
            data = json.loads(data)
    except json.JSONDecodeError as exc:
        raise StreamCIParseError(f"JSON parse error: {exc}. Text: {text[:200]}") from exc

    if not isinstance(data, dict):
        raise StreamCIParseError(f"Expected dict response, got {type(data).__name__}")

    if data.get("status") == 0:
        _raise_request_error(data.get("msg", "Server returned status=0"), data)

    return data


def parse_query_response(text: str) -> list[Document]:
    """Parse a query response.

    The server always returns NDJSON (Transfer-Encoding: chunked).
    Error responses use the single-object ``{"status":0, "msg":"..."}`` format.
    The legacy envelope format ``{"status":1, "data":[...]}`` is also handled
    for future compatibility.
    """
    if not text or not text.strip():
        return []

    # Check for single-object error or envelope response (no newline in body)
    stripped = text.strip()
    if not stripped.startswith("[") and "\n" not in stripped:
        try:
            data = json.loads(stripped)
            if isinstance(data, str):
                data = json.loads(data)
            if isinstance(data, dict):
                if data.get("status") == 0:
                    _raise_request_error(data.get("msg", "Server returned status=0"), data)
                if "data" in data:
                    raw = data["data"]
                    if raw is None:
                        return []
                    return raw if isinstance(raw, list) else [raw]
        except (json.JSONDecodeError, KeyError):
            pass

    return parse_ndjson(text)
