"""Query operations for PyStreamCI."""

from __future__ import annotations

import logging
from typing import Any, Iterator

import requests

from .auth import Auth
from .exceptions import StreamCIRequestError, StreamCIValidationError
from .response import parse_query_response, parse_ndjson_stream, parse_mutation_response, _raise_request_error
from .retry import RetryHandler
from ._types import Document
from ._utils import _is_blob_field, _find_blob_paths

logger = logging.getLogger(__name__)


class QueryOperations:
    """Provides query, query_blob, and query_blobs operations."""

    def __init__(
        self,
        session: requests.Session,
        base_url: str,
        auth: Auth,
        retry: RetryHandler,
        timeout: float,
    ) -> None:
        self._session = session
        self._url = base_url.rstrip("/") + "/query"
        self._auth = auth
        self._retry = retry
        self._timeout = timeout

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_request(
        self,
        query: Document | None,
        project: list[str] | None,
        sort: dict[str, int] | None,
        limit: int | None,
    ) -> dict:
        req: dict[str, Any] = {"method": "query"}
        if query is not None:
            req["query"] = query
        if project is not None:
            req["project"] = project
        if sort is not None:
            req["sort"] = sort
        if limit is not None:
            req["limit"] = limit
        return req

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def query(
        self,
        query: Document | None = None,
        *,
        project: list[str] | None = None,
        sort: dict[str, int] | None = None,
        limit: int | None = None,
    ) -> list[Document]:
        """Execute a query and return results as a list."""
        payload = {
            "auth": self._auth.to_dict(),
            "request": self._build_request(query, project, sort, limit),
        }

        logger.debug("query target=%s", self._auth.target)

        def _do():
            resp = self._session.post(self._url, json=payload, timeout=self._timeout)
            resp.raise_for_status()
            return resp

        resp = self._retry.execute(_do, description="query")
        docs = parse_query_response(resp.text)
        logger.info("query returned %d documents", len(docs))
        return docs

    def query_iter(
        self,
        query: Document | None = None,
        *,
        project: list[str] | None = None,
        sort: dict[str, int] | None = None,
        limit: int | None = None,
    ) -> Iterator[Document]:
        """Stream query results as an iterator (large datasets).

        Always uses ``stream=True`` (NDJSON).  The HTTP connection stays open
        until the iterator is exhausted or garbage-collected.
        """
        payload = {
            "auth": self._auth.to_dict(),
            "request": self._build_request(query, project, sort, limit),
        }

        logger.debug("query_iter target=%s", self._auth.target)

        def _do():
            resp = self._session.post(
                self._url, json=payload, timeout=self._timeout, stream=True
            )
            resp.raise_for_status()
            return resp

        resp = self._retry.execute(_do, description="query_iter")
        return parse_ndjson_stream(resp)

    def query_blob(self, document_id: str, field: str) -> bytes:
        """Download a single blob field from a document.

        Both *document_id* and *field* are required by the backend.

        :returns: Raw bytes of the blob.
        """
        if not document_id:
            raise StreamCIValidationError("document_id is required for query_blob")
        if not field:
            raise StreamCIValidationError("field is required for query_blob")

        payload = {
            "auth": self._auth.to_dict(),
            "request": {
                "method": "queryBlob",
                "document_id": document_id,
                "field": field,
            },
        }

        logger.debug(
            "query_blob document_id=%s field=%s", document_id, field
        )

        def _do():
            resp = self._session.post(self._url, json=payload, timeout=self._timeout)
            return resp

        resp = self._retry.execute(_do, description="query_blob")

        # HTTP error: try to parse JSON body for a structured error message first
        if not resp.ok:
            try:
                import json
                data = json.loads(resp.text)
                if isinstance(data, dict) and data.get("status") == 0:
                    _raise_request_error(data.get("msg", "query_blob failed"), data)
            except (ValueError, KeyError):
                pass
            resp.raise_for_status()

        # Success: check for JSON status=0 anyway (server may return 200 with error body)
        content_type = resp.headers.get("Content-Type", "")
        if "application/json" in content_type or "text/plain" in content_type:
            try:
                import json
                data = json.loads(resp.text)
                if isinstance(data, dict) and data.get("status") == 0:
                    _raise_request_error(data.get("msg", "query_blob failed"), data)
            except (ValueError, KeyError):
                pass

        return resp.content

    def query_blobs_by_field(self, document_ids: list[str], field: str) -> dict[str, bytes]:
        """Download a blob field from multiple documents.

        Calls :meth:`query_blob` sequentially for each *document_id*.
        Raises on the first failure.

        :returns: Mapping of ``document_id`` → raw bytes.
        """
        results = {}
        for doc_id in document_ids:
            results[doc_id] = self.query_blob(doc_id, field)
        return results

    def query_blobs_by_doc(
        self, document_id: str, *, ignore_errors: bool = False
    ) -> dict[str, bytes]:
        """Download all blob fields from a single document.

        Fetches the document, auto-detects blob fields using :func:`_is_blob_field`,
        then downloads each one via :meth:`query_blob`.

        :param document_id: ID of the document to retrieve blobs from.
        :param ignore_errors: If *True*, skip fields that fail to download instead of
            raising.  If *False* (default), re-raise the first error encountered.
        :returns: Mapping of ``field_name`` → raw bytes.  Empty dict when the document
            has no blob fields.
        :raises StreamCIValidationError: If *document_id* is empty.
        :raises StreamCIRequestError: If the document is not found.
        """
        if not document_id:
            raise StreamCIValidationError("document_id is required for query_blobs_by_doc")

        docs = self.query({"_id": document_id}, limit=1)
        if not docs:
            raise StreamCIRequestError("Document not found", response=None)

        doc = docs[0]
        blob_fields = _find_blob_paths(doc)

        if not blob_fields:
            return {}

        results: dict[str, bytes] = {}
        for field in blob_fields:
            try:
                results[field] = self.query_blob(document_id, field)
            except Exception:
                if ignore_errors:
                    logger.warning(
                        "query_blobs_by_doc: failed to download field %r from %s, skipping",
                        field,
                        document_id,
                    )
                else:
                    raise
        return results
