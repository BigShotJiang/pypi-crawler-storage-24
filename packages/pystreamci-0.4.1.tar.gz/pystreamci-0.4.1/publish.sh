#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "==> Activating venv..."
source .venv/bin/activate

echo "==> Installing build tools..."
pip install -q build twine

echo "==> Cleaning dist/..."
rm -rf dist/

echo "==> Building sdist + wheel..."
python -m build

echo "==> Uploading to PyPI..."
twine upload dist/*

echo "==> Done! Published pystreamci $(python -c 'import pystreamci; print(pystreamci.__version__)')"
