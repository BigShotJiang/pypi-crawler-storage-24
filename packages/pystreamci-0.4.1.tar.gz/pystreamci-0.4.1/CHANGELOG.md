# Changelog

## [0.4.1] - 2026-03-17

### Changed
- `StreamCIAuthError` is now a subclass of `StreamCIRequestError` (previously a direct subclass of `StreamCIError`); auth errors are now catchable with `except StreamCIRequestError`

### Fixed
- `query_blob` HTTP 400 responses now raise `StreamCIRequestError` instead of leaking raw `requests.HTTPError`
- `"wrong secret key"` server messages are now correctly classified as `StreamCIAuthError` (previously raised `StreamCIRequestError`)

## [0.4.0] - 2026-03-15

### Changed
- `blobs=` parameter in `insert()` and `update()` now accepts flexible formats — bare file objects, file paths (`str` or `Path`), 2-tuples `(name, file)`, and the existing 3-tuples `(name, file, mime)`. Filename and MIME type are auto-inferred when not provided.

## [0.3.1] - 2026-03-13

### Fixed
- `query` with `_id` filter now works correctly (server-side `_id` handling fix)
- API endpoint compatibility updates

## [0.3.0] - 2026-03-13

### Added
- `query_blobs_by_doc(document_id, *, ignore_errors)`: download all blob fields from a single document; auto-detects blob fields via S3 metadata and returns `dict[str, bytes]`; supports nested blob fields (dot-notation keys, e.g. `result.figure`, `figures.0`)
- Blob key normalization: SDK strips quotes from bracket-notation keys before sending, allowing Python-style `blobs={'field["subkey"]': ...}` syntax

### Changed
- `query_blobs(document_ids, field)` → `query_blobs_by_field(document_ids, field)`: renamed for naming consistency with `query_blobs_by_doc`

## [0.2.0] - 2026-03-09

### Changed
- `insert(data, files=...)` → `insert(data, blobs=...)`: parameter renamed to avoid confusion with `requests` library's `files` argument
- `update(filter, data, files=...)` → `update(filter, data, blobs=...)`: same rename
- `bulkload(...)` → `insert_many(...)`: method renamed for naming consistency with `insert` family
- `upload(...)` → `insert_file(...)`: method renamed for naming consistency with `insert` family
- `query()` and `query_iter()`: removed unused `batch` parameter (server ignores it)

### Added
- `query_blobs(document_ids, field)`: convenience method to download a blob field from multiple documents sequentially; raises on first failure
- `make_date()` unit tests: ISO string passthrough, tz-aware/naive datetime, microseconds, zero-ms clean output
- Bulkload datetime integration tests (plain string + `$date` mix) for `default` and `timeseries` collections; `$date`-only for `nosql`

## [0.1.0] - 2026-03-02

Initial release.

### Added
- `StreamCIClient` connector with context manager support
- `pystreamci.connect()` factory function
- `DataOperations`: `insert`, `bulkload`, `upload`, `update`, `delete`
- `QueryOperations`: `query`, `query_iter`, `query_blob`
- `RetryHandler` with exponential backoff for transient network errors
- NDJSON streaming response parser
- `Auth` dataclass supporting `secret` and `password` auth types
- `make_date()` utility for `$date` Extended JSON conversion
- Full exception hierarchy: `StreamCIError`, `StreamCIConnectionError`, `StreamCIAuthError`,
  `StreamCIRequestError`, `StreamCIParseError`, `StreamCITimeoutError`, `StreamCIValidationError`
- Console + optional file logging via `setup_logger()`
