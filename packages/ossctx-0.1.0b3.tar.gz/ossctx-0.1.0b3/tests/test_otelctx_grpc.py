import socket
import time

import grpc

from otelctx.api.routes import ingest_payload
from otelctx.db.repository import OtelRepository
from otelctx.otlp_grpc import start_otlp_grpc_server
from opentelemetry.proto.collector.trace.v1 import trace_service_pb2_grpc
from opentelemetry.proto.collector.trace.v1.trace_service_pb2 import ExportTraceServiceRequest
from opentelemetry.proto.trace.v1.trace_pb2 import ResourceSpans, ScopeSpans, Span, Status
from opentelemetry.proto.resource.v1.resource_pb2 import Resource
from opentelemetry.proto.common.v1.common_pb2 import AnyValue, KeyValue


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def test_otelctx_grpc_export_ingests_trace(tmp_path) -> None:
    repo = OtelRepository(tmp_path / "otel-grpc.db")
    repo.create_schema()
    port = _free_port()

    server = start_otlp_grpc_server(port, lambda payload: ingest_payload(repo, payload))
    try:
        channel = grpc.insecure_channel(f"127.0.0.1:{port}")
        grpc.channel_ready_future(channel).result(timeout=5)
        stub = trace_service_pb2_grpc.TraceServiceStub(channel)

        request = ExportTraceServiceRequest(
            resource_spans=[
                ResourceSpans(
                    resource=Resource(
                        attributes=[
                            KeyValue(key="service.name", value=AnyValue(string_value="grpc-checkout"))
                        ]
                    ),
                    scope_spans=[
                        ScopeSpans(
                            spans=[
                                Span(
                                    trace_id=b"1234567890abcdef",
                                    span_id=b"12345678",
                                    name="POST /checkout",
                                    kind=Span.SpanKind.SPAN_KIND_SERVER,
                                    start_time_unix_nano=1710784800000000000,
                                    end_time_unix_nano=1710784800100000000,
                                    status=Status(code=Status.StatusCode.STATUS_CODE_OK),
                                )
                            ]
                        )
                    ],
                )
            ]
        )

        stub.Export(request, timeout=5)

        deadline = time.time() + 5
        while time.time() < deadline:
            stats = repo.get_stats()
            if stats.traces == 1 and stats.spans == 1:
                break
            time.sleep(0.05)
        else:
            raise AssertionError("Timed out waiting for gRPC OTLP ingest")

        traces = repo.list_traces()
        assert len(traces) == 1
        assert traces[0]["root_service_name"] == "grpc-checkout"
    finally:
        server.stop(grace=1)
