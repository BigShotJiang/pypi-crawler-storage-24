from pathlib import Path

from sqlalchemy import text

from common.db import create_engine_with_wal


def test_sqlite_wal_is_enabled(tmp_path: Path) -> None:
    db_path = tmp_path / "test.db"
    engine = create_engine_with_wal(f"sqlite:///{db_path}")
    with engine.connect() as conn:
        mode = conn.execute(text("PRAGMA journal_mode;")).scalar_one()
    assert str(mode).lower() == "wal"
