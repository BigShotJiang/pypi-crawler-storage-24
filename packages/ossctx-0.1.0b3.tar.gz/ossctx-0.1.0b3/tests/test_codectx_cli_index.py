from pathlib import Path

from typer.testing import CliRunner

from codectx.cli import app

runner = CliRunner()


def test_codectx_index_cli(tmp_path: Path) -> None:
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    (project_dir / "app.py").write_text("import os\n\ndef hello():\n    return 1\n", encoding="utf-8")
    db_path = tmp_path / "index.db"

    result = runner.invoke(app, ["index", str(project_dir), "--db", str(db_path)])
    assert result.exit_code == 0
    assert "Indexed files: 1" in result.stdout
    assert "Files: 1" in result.stdout
