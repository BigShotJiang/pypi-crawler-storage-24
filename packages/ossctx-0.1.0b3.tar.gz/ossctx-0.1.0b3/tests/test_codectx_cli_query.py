from pathlib import Path

from typer.testing import CliRunner

from codectx.cli import app

runner = CliRunner()


def test_codectx_query_entity_deps_and_calls(tmp_path: Path) -> None:
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    source_file = project_dir / "app.py"
    helper_file = project_dir / "helpers.py"
    helper_file.write_text("def helper():\n    return 1\n", encoding="utf-8")
    source_file.write_text(
        "from helpers import helper\n\ndef hello():\n    return helper()\n",
        encoding="utf-8",
    )
    db_path = tmp_path / "index.db"

    index_result = runner.invoke(app, ["index", str(project_dir), "--db", str(db_path)])
    assert index_result.exit_code == 0

    entity_result = runner.invoke(app, ["query", "entity", "hello", "--db", str(db_path)])
    assert entity_result.exit_code == 0
    assert "Found 1 entities" in entity_result.stdout
    assert "[function] hello" in entity_result.stdout

    deps_result = runner.invoke(app, ["query", "deps", str(source_file), "--db", str(db_path)])
    assert deps_result.exit_code == 0
    assert "File:" in deps_result.stdout

    calls_result = runner.invoke(app, ["query", "calls", "hello", "--db", str(db_path)])
    assert calls_result.exit_code == 0
    assert "Outgoing calls:" in calls_result.stdout
    assert "helper" in calls_result.stdout
