from __future__ import annotations

import time

from otelctx.tsdb import TsdbRingBuffer


def test_tsdb_records_and_queries_series() -> None:
    tsdb = TsdbRingBuffer(per_series_capacity=10)
    now = time.time()

    tsdb.record("http.latency", 12.0, {"service": "api"}, now - 2)
    tsdb.record("http.latency", 24.0, {"service": "api"}, now - 1)
    tsdb.record("http.latency", 48.0, {"service": "worker"}, now - 1)

    series = tsdb.query_series("http.latency", window_seconds=10, labels={"service": "api"})

    assert len(series) == 2
    assert [point["value"] for point in series] == [12.0, 24.0]


def test_tsdb_aggregate_window_produces_bucket_stats() -> None:
    tsdb = TsdbRingBuffer(per_series_capacity=10)
    now = time.time()

    tsdb.record("queue.depth", 1.0, {"service": "api"}, now - 5)
    tsdb.record("queue.depth", 3.0, {"service": "api"}, now - 4)
    tsdb.record("queue.depth", 5.0, {"service": "api"}, now - 1)

    buckets = tsdb.aggregate_window("queue.depth", window_seconds=6, step_seconds=2, labels={"service": "api"})
    non_empty = [bucket for bucket in buckets if bucket["count"] > 0]

    assert len(non_empty) >= 2
    assert any(bucket["min"] == 1.0 and bucket["max"] == 3.0 for bucket in non_empty)
    assert any(bucket["count"] == 1 and bucket["mean"] == 5.0 for bucket in non_empty)


def test_tsdb_ingests_normalized_metric_payload() -> None:
    tsdb = TsdbRingBuffer(per_series_capacity=10)
    now_ns = int(time.time() * 1_000_000_000)

    stored = tsdb.ingest_from_metric_payload(
        {
            "metrics": [
                {
                    "name": "http.requests",
                    "service_name": "checkout",
                    "metric_type": "counter",
                    "data_points": [
                        {"value": 10, "time_unix_nano": now_ns - 2_000_000_000, "attributes": {"route": "/checkout"}},
                        {"value": 12, "time_unix_nano": now_ns - 1_000_000_000, "attributes": {"route": "/checkout"}},
                    ],
                }
            ]
        }
    )

    stats = tsdb.get_stats("http.requests", window_seconds=10_000_000)

    assert stored == 2
    assert stats["count"] == 2
    assert stats["max"] == 12.0
