from fastapi.testclient import TestClient

from common.server import create_app
from docsctx.api.routes import build_router
from docsctx.db.repository import DocumentRecord, DocsRepository


def test_docsctx_api_exposes_documents_and_search(tmp_path) -> None:
    repo = DocsRepository(tmp_path / "docs.db")
    repo.create_schema()
    repo.upsert_document(
        DocumentRecord(
            source_uri="docs://intro",
            title="Intro",
            doc_type="markdown",
            checksum="abc",
            content="alpha beta\nhello docs search world",
            chunks=["alpha beta", "hello docs search world"],
        )
    )

    app = create_app("docsctx", "0.1.0")
    app.include_router(build_router(repo))
    client = TestClient(app)

    documents_response = client.get("/api/documents")
    assert documents_response.status_code == 200
    payload = documents_response.json()
    assert len(payload) == 1
    assert payload[0]["title"] == "Intro"

    search_response = client.post("/api/search", json={"query": "docs search", "top_k": 5})
    assert search_response.status_code == 200
    search_payload = search_response.json()
    assert search_payload["results"]
    assert search_payload["results"][0]["title"] == "Intro"
