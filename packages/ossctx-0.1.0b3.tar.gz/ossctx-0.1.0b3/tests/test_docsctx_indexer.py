from pathlib import Path

from docsctx.db.repository import DocsRepository
from docsctx.indexer import DocsIndexer


def test_docs_indexer_indexes_markdown_and_html(tmp_path: Path) -> None:
    source_dir = tmp_path / "docs"
    source_dir.mkdir()
    (source_dir / "guide.md").write_text("# Guide\n\nThis tool indexes guides.", encoding="utf-8")
    (source_dir / "page.html").write_text(
        "<html><head><title>Reference</title></head><body><h1>Reference</h1><p>Searchable text.</p></body></html>",
        encoding="utf-8",
    )

    repo = DocsRepository(tmp_path / "docs.db")
    indexer = DocsIndexer(repo, chunk_size=40, chunk_overlap=10)
    summary = indexer.index_path(source_dir)
    stats = repo.get_stats()

    assert summary.indexed_documents == 2
    assert stats.documents == 2
    assert stats.chunks >= 2
