import json

from typer.testing import CliRunner

from otelctx.cli import app

runner = CliRunner()


def test_otelctx_ingest_and_stats_cli(tmp_path) -> None:
    db_path = tmp_path / "otel.db"
    payload_path = tmp_path / "traces.json"
    payload_path.write_text(
        json.dumps(
            {
                "traces": [
                    {
                        "trace_id": "trace-1",
                        "root_service_name": "api",
                        "root_span_name": "GET /orders",
                        "status_code": "OK",
                        "spans": [
                            {
                                "span_id": "span-1",
                                "name": "GET /orders",
                                "service_name": "api",
                                "start_time": "2026-03-18T10:00:00Z",
                                "end_time": "2026-03-18T10:00:00.050000Z",
                            }
                        ],
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    ingest_result = runner.invoke(app, ["ingest", str(payload_path), "--db", str(db_path)])
    assert ingest_result.exit_code == 0
    assert "Ingested traces: 1" in ingest_result.stdout

    stats_result = runner.invoke(app, ["stats", "--db", str(db_path)])
    assert stats_result.exit_code == 0
    assert "Traces: 1" in stats_result.stdout
    assert "Spans: 1" in stats_result.stdout


def test_otelctx_cli_ingests_logs_and_metrics(tmp_path) -> None:
    db_path = tmp_path / "otel.db"
    payload_path = tmp_path / "signals.json"
    payload_path.write_text(
        json.dumps(
            {
                "logs": [
                    {
                        "timestamp": "2026-03-18T10:00:01Z",
                        "service_name": "api",
                        "severity_text": "WARN",
                        "body": "slow checkout"
                    }
                ],
                "metrics": [
                    {
                        "service_name": "api",
                        "name": "queue.depth",
                        "type": "gauge",
                        "time": "2026-03-18T10:00:02Z",
                        "value": 7
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    ingest_result = runner.invoke(app, ["ingest", str(payload_path), "--db", str(db_path)])
    assert ingest_result.exit_code == 0
    assert "Ingested logs: 1" in ingest_result.stdout
    assert "Ingested metrics: 1" in ingest_result.stdout

    stats_result = runner.invoke(app, ["stats", "--db", str(db_path)])
    assert stats_result.exit_code == 0
    assert "Logs: 1" in stats_result.stdout
    assert "Metrics: 1" in stats_result.stdout
