from __future__ import annotations

from docsctx.extractor import ExtractionResult
from docsctx.indexer import estimate_tokens
from docsctx.provider import _parse_extraction_json


def test_estimate_tokens_matches_go_heuristic() -> None:
    assert estimate_tokens("abcd") == 1
    assert estimate_tokens("abcdefgh") == 2
    assert estimate_tokens("a") == 1


def test_extraction_result_defaults_claims_to_empty_list() -> None:
    result = ExtractionResult(entities=[], relationships=[])

    assert result.claims == []


def test_provider_parses_claims_into_entity_name_field() -> None:
    parsed = _parse_extraction_json(
        '{"entities":[{"name":"Orders","type":"Concept","description":"desc","score":7}],'
        '"relationships":[{"source":"Orders","target":"Payments","predicate":"depends_on","description":"desc","weight":0.8}],'
        '"claims":[{"entity":"Orders","claim":"Orders depend on payments","status":"CONFIRMED"}]}'
    )

    assert parsed.entities[0].score == 7
    assert parsed.claims[0].entity_name == "Orders"
    assert parsed.claims[0].claim == "Orders depend on payments"
