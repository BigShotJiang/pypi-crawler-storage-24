from otelctx.db.repository import LogRecord, MetricRecord, OtelRepository, SpanRecord, TraceRecord


def test_otel_repository_ingests_trace_and_services(tmp_path) -> None:
    repo = OtelRepository(tmp_path / "otel.db")
    repo.create_schema()
    repo.ingest_traces(
        [
            TraceRecord(
                trace_id="trace-1",
                root_service_name="api",
                root_span_name="GET /orders",
                status_code="OK",
                spans=[
                    SpanRecord(
                        span_id="span-1",
                        name="GET /orders",
                        service_name="api",
                        status_code="OK",
                        start_time="2026-03-18T10:00:00Z",
                        end_time="2026-03-18T10:00:00.100000Z",
                    ),
                    SpanRecord(
                        span_id="span-2",
                        parent_span_id="span-1",
                        name="SELECT orders",
                        service_name="db",
                        status_code="ERROR",
                        start_time="2026-03-18T10:00:00.010000Z",
                        end_time="2026-03-18T10:00:00.050000Z",
                    ),
                ],
            )
        ]
    )

    stats = repo.get_stats()
    services = repo.list_services()
    trace = repo.get_trace("trace-1")

    assert stats.traces == 1
    assert stats.spans == 2
    assert stats.services == 2
    assert stats.error_spans == 1
    assert trace is not None
    assert len(trace["spans"]) == 2
    assert services[0].service_name in {"api", "db"}


def test_otel_repository_ingests_logs_and_metrics(tmp_path) -> None:
    repo = OtelRepository(tmp_path / "otel.db")
    repo.create_schema()

    log_summary = repo.ingest_logs(
        [
            LogRecord(
                timestamp="2026-03-18T10:00:01Z",
                service_name="api",
                severity_text="ERROR",
                body="checkout failed",
                trace_id="trace-1",
                span_id="span-2",
                attributes={"http.status_code": 500},
            )
        ]
    )
    metric_summary = repo.ingest_metrics(
        [
            MetricRecord(
                service_name="api",
                name="http.server.duration",
                metric_type="gauge",
                unit="ms",
                time="2026-03-18T10:00:02Z",
                value=12.5,
                attributes={"route": "/checkout"},
            )
        ]
    )

    stats = repo.get_stats()
    logs = repo.list_logs()
    metrics = repo.list_metrics()

    assert log_summary == {"logs": 1}
    assert metric_summary == {"metrics": 1}
    assert stats.logs == 1
    assert stats.metrics == 1
    assert logs[0]["body"] == "checkout failed"
    assert metrics[0]["name"] == "http.server.duration"
