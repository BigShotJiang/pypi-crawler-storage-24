from __future__ import annotations

from datetime import UTC, datetime

from otelctx.archive import ArchiveScheduler, ArchiveTier, DailyArchive


def test_daily_archive_round_trips_records(tmp_path) -> None:
    archive = DailyArchive(tmp_path, datetime(2026, 3, 18, tzinfo=UTC).date(), signal="logs")
    records = [{"service": "api", "message": "hello"}, {"service": "db", "message": "world"}]

    archive.append(records)
    restored = archive.read_all()
    manifest = archive.manifest()

    assert restored == records
    assert manifest is not None
    assert manifest["record_count"] == 2


def test_archive_tier_search_and_stats(tmp_path) -> None:
    tier = ArchiveTier(tmp_path, hot_days=0)
    tier.archive([{"trace_id": "abc", "service": "checkout"}], signal="traces")

    results = tier.search_cold("checkout", signal="traces", days_back=1, limit=10)
    stats = tier.storage_stats()

    assert len(results) == 1
    assert results[0]["service"] == "checkout"
    assert stats["archive_count"] >= 1
    assert stats["record_count"] >= 1


def test_archive_scheduler_rotates_records_by_day(tmp_path) -> None:
    tier = ArchiveTier(tmp_path, hot_days=1)
    deleted: list[str] = []

    old_record = {"start_time": "2026-03-15T10:00:00+00:00", "trace_id": "old-trace"}

    scheduler = ArchiveScheduler(
        tier,
        fetch_fn=lambda signal, cutoff: [old_record] if signal == "traces" else [],
        delete_fn=lambda signal, cutoff: deleted.append(signal),
        hot_days=1,
    )

    scheduler._rotate_once()

    manifests = tier.list_archives(signal="traces")
    assert manifests
    assert deleted == ["traces"]
