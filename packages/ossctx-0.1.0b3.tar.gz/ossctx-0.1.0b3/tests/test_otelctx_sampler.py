"""Tests for AdaptiveSampler (otelctx/sampler.py)."""

from __future__ import annotations

import pytest

from otelctx.sampler import AdaptiveSampler


class TestAdaptiveSamplerInit:
    def test_default_rate_is_one(self):
        s = AdaptiveSampler()
        assert s._rate == 1.0

    def test_custom_rate(self):
        s = AdaptiveSampler(rate=0.5)
        assert s._rate == 0.5

    def test_invalid_rate_raises(self):
        with pytest.raises(ValueError):
            AdaptiveSampler(rate=1.5)

    def test_invalid_rate_negative(self):
        with pytest.raises(ValueError):
            AdaptiveSampler(rate=-0.1)


class TestAdaptiveSamplerDecisions:
    def test_rate_one_always_ingests(self):
        s = AdaptiveSampler(rate=1.0, always_errors=False)
        for _ in range(20):
            assert s.should_ingest("svc") is True

    def test_rate_zero_only_allows_initial_bucket_token(self):
        s = AdaptiveSampler(rate=0.0, always_errors=False)
        results = [s.should_ingest("svc") for _ in range(50)]
        assert results[0] is True
        assert all(r is False for r in results[1:])

    def test_always_errors_passes_error_spans(self):
        s = AdaptiveSampler(rate=0.0, always_errors=True)
        assert s.should_ingest("svc", status_code="ERROR") is True

    def test_always_errors_false_uses_normal_bucket_rules(self):
        s = AdaptiveSampler(rate=0.0, always_errors=False)
        results = [s.should_ingest("svc", status_code="ERROR") for _ in range(20)]
        assert results[0] is True
        assert all(r is False for r in results[1:])

    def test_latency_threshold_passes_slow_spans(self):
        s = AdaptiveSampler(rate=0.0, always_errors=False, latency_threshold_ms=500.0)
        assert s.should_ingest("svc", duration_ms=1000.0) is True

    def test_latency_threshold_fast_spans_still_consume_bucket(self):
        s = AdaptiveSampler(rate=0.0, always_errors=False, latency_threshold_ms=500.0)
        results = [s.should_ingest("svc", duration_ms=100.0) for _ in range(20)]
        assert results[0] is True
        assert all(r is False for r in results[1:])

    def test_multiple_services_tracked_separately(self):
        s = AdaptiveSampler(rate=0.5)
        s.should_ingest("svc-a")
        s.should_ingest("svc-b")
        st = s.stats()
        assert st["active_services"] == 2


class TestAdaptiveSamplerStats:
    def test_stats_recorded(self):
        s = AdaptiveSampler(rate=1.0)
        for _ in range(5):
            s.should_ingest("svc")
        st = s.stats()
        assert st["total_seen"] == 5

    def test_rate_zero_drops_all_after_initial_token(self):
        s = AdaptiveSampler(rate=0.0, always_errors=False)
        for _ in range(10):
            s.should_ingest("svc")
        st = s.stats()
        assert st["total_dropped"] == 9
        assert st["total_accepted"] == 1

    def test_reset_clears_counters(self):
        s = AdaptiveSampler(rate=1.0)
        for _ in range(5):
            s.should_ingest("svc")
        # set_rate rebuilds buckets and effectively resets per-service buckets
        s.set_rate(0.5)
        assert s._rate == 0.5
        st = s.stats()
        # counters persist across set_rate; only buckets are rebuilt
        assert st["total_seen"] == 5

