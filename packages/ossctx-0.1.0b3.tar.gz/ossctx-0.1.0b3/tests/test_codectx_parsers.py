from codectx.parser.registry import parse_file


def test_python_parser_extracts_class_function_imports_and_calls() -> None:
    content = """
import os
from pathlib import Path

class Demo:
    def helper(self) -> int:
        return 1

    def method(self, value: int) -> int:
        self.helper()
        return value

async def task(name: str) -> None:
    helper()
    return None

def helper() -> int:
    return 1
""".strip()
    result = parse_file("demo.py", content)

    names = {entity.qualified_name or entity.name: entity for entity in result.entities}
    assert result.language == "python"
    assert "Demo" in names
    assert names["Demo"].type == "class"
    assert "Demo.method" in names
    assert names["Demo.method"].type == "method"
    assert names["Demo.method"].parent == "Demo"
    assert "task" in names
    assert len(result.dependencies) == 2
    call_targets = {relation.target_qualified_name for relation in result.relations if relation.relation_type == "calls"}
    assert "Demo.helper" in call_targets
    assert "helper" in call_targets


def test_python_parser_preserves_import_qualified_call_targets() -> None:
    content = """
from helpers import helper as imported_helper
import services

def run() -> None:
    imported_helper()
    services.process()
""".strip()
    result = parse_file("demo.py", content)

    call_targets = {relation.target_qualified_name for relation in result.relations if relation.relation_type == "calls"}
    assert "helpers.helper" in call_targets
    assert "services.process" in call_targets


def test_go_parser_extracts_func_type_import_and_calls() -> None:
    content = """
package main

import "fmt"

type Service struct {}

func Run() {
    fmt.Println("ok")
    helper()
}

func helper() {}
""".strip()
    result = parse_file("main.go", content)

    names = {entity.qualified_name or entity.name: entity for entity in result.entities}
    assert result.language == "go"
    assert "Service" in names
    assert names["Service"].type == "struct"
    assert "Run" in names
    assert names["Run"].type == "function"
    assert result.dependencies[0].path == "fmt"
    call_targets = {relation.target_qualified_name for relation in result.relations if relation.relation_type == "calls"}
    assert "Println" in call_targets
    assert "helper" in call_targets


def test_javascript_parser_extracts_entities_and_calls() -> None:
    content = """
import x from './dep.js'

function helper() { return 1; }
const run = () => helper();
""".strip()
    result = parse_file("demo.js", content)

    assert result.language == "javascript"
    names = {entity.qualified_name or entity.name for entity in result.entities}
    assert "helper" in names
    assert "run" in names
    calls = [relation for relation in result.relations if relation.relation_type == "calls"]
    assert any(relation.target_qualified_name == "helper" for relation in calls)


def test_java_parser_extracts_entities_and_calls() -> None:
    content = """
import java.util.List;

class Service {
    public void run() {
        helper();
    }

    private void helper() {}
}
""".strip()
    result = parse_file("Service.java", content)

    assert result.language == "java"
    names = {entity.qualified_name or entity.name for entity in result.entities}
    assert "Service" in names
    assert "Service.run" in names
    assert "Service.helper" in names
    calls = [relation for relation in result.relations if relation.relation_type == "calls"]
    assert any(relation.target_qualified_name == "helper" for relation in calls)
