from pathlib import Path

from typer.testing import CliRunner

from docsctx.cli import app

runner = CliRunner()


def test_docsctx_index_and_stats_cli(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    (docs_dir / "intro.md").write_text("# Intro\n\nHello docs search world.", encoding="utf-8")
    db_path = tmp_path / "docs.db"

    index_result = runner.invoke(app, ["index", str(docs_dir), "--db", str(db_path), "--chunk-size", "30"])
    assert index_result.exit_code == 0
    assert "Indexed documents: 1" in index_result.stdout

    stats_result = runner.invoke(app, ["stats", "--db", str(db_path)])
    assert stats_result.exit_code == 0
    assert "documents: 1" in stats_result.stdout
    assert "chunks:" in stats_result.stdout
