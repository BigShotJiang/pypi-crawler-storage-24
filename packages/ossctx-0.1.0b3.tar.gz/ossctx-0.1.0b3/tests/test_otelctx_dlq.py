from __future__ import annotations

from otelctx.cache import DeadLetterQueue, DlqReplayWorker, _DlqBase
from otelctx.db.repository import OtelRepository


def _make_dlq(tmp_path):
    repo = OtelRepository(tmp_path / "otel.db")
    repo.create_schema()
    _DlqBase.metadata.create_all(repo.engine)
    return DeadLetterQueue(repo.session_factory)


def test_dead_letter_queue_push_list_and_ack(tmp_path) -> None:
    dlq = _make_dlq(tmp_path)

    entry_id = dlq.push('{"event":"bad"}', "boom", signal="logs")
    entries = dlq.list_entries(signal="logs")

    assert entry_id > 0
    assert len(entries) == 1
    assert entries[0]["signal"] == "logs"
    assert dlq.ack(entry_id) is True
    assert dlq.count() == 0


def test_dlq_replay_worker_replays_and_acks_successful_entry(tmp_path) -> None:
    dlq = _make_dlq(tmp_path)
    seen: list[str] = []

    dlq.push('{"event":"recoverable"}', "temporary", signal="traces")
    worker = DlqReplayWorker(dlq, lambda payload: seen.append(payload) or True, interval_seconds=3600)

    worker._replay_once()

    assert seen == ['{"event":"recoverable"}']
    assert dlq.count() == 0


def test_dlq_replay_worker_increments_attempts_on_failure(tmp_path) -> None:
    dlq = _make_dlq(tmp_path)
    entry_id = dlq.push('{"event":"still-bad"}', "temporary", signal="metrics")
    worker = DlqReplayWorker(dlq, lambda payload: False, interval_seconds=3600)

    worker._replay_once()

    entry = next(item for item in dlq.list_entries() if item["id"] == entry_id)
    assert entry["attempt_count"] == 2
