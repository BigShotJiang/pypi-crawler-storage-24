from typer.testing import CliRunner

from common.cli import app

runner = CliRunner()


def test_root_help_shows_groups() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "code" in result.stdout
    assert "docs" in result.stdout
    assert "otel" in result.stdout
