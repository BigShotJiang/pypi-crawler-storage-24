from fastapi.testclient import TestClient

from common.server import create_app
from otelctx.api.routes import build_router
from otelctx.db.repository import OtelRepository
from otelctx.cli import build_app


def test_otelctx_api_ingest_and_query(tmp_path) -> None:
    repo = OtelRepository(tmp_path / "otel.db")
    repo.create_schema()

    app = create_app("otelctx", "0.1.0")
    app.include_router(build_router(repo))
    client = TestClient(app)

    ingest_response = client.post(
        "/api/ingest",
        json={
            "spans": [
                {
                    "trace_id": "trace-1",
                    "span_id": "span-1",
                    "name": "GET /orders",
                    "service_name": "api",
                    "status_code": "OK",
                    "start_time": "2026-03-18T10:00:00Z",
                    "end_time": "2026-03-18T10:00:00.050000Z",
                },
                {
                    "trace_id": "trace-1",
                    "span_id": "span-2",
                    "parent_span_id": "span-1",
                    "name": "query orders",
                    "service_name": "db",
                    "status_code": "ERROR",
                    "start_time": "2026-03-18T10:00:00.010000Z",
                    "end_time": "2026-03-18T10:00:00.030000Z",
                },
            ]
        },
    )
    assert ingest_response.status_code == 200
    assert ingest_response.json()["traces"] == 1

    otlp_response = client.post(
        "/api/otlp/v1/traces",
        json={
            "resourceSpans": [
                {
                    "resource": {
                        "attributes": [
                            {"key": "service.name", "value": {"stringValue": "checkout"}}
                        ]
                    },
                    "scopeSpans": [
                        {
                            "spans": [
                                {
                                    "traceId": "otlp-trace-1",
                                    "spanId": "otlp-span-1",
                                    "name": "POST /checkout",
                                    "kind": 2,
                                    "status": {"code": 1},
                                    "startTimeUnixNano": "1710784800000000000",
                                    "endTimeUnixNano": "1710784800100000000"
                                }
                            ]
                        }
                    ],
                }
            ]
        },
    )
    assert otlp_response.status_code == 200
    assert otlp_response.json()["traces"] == 1

    stats_response = client.get("/api/stats")
    assert stats_response.status_code == 200
    assert stats_response.json()["spans"] == 3

    traces_response = client.get("/api/traces")
    assert traces_response.status_code == 200
    assert len(traces_response.json()) == 2

    trace_response = client.get("/api/traces/trace-1")
    assert trace_response.status_code == 200
    assert len(trace_response.json()["spans"]) == 2

    services_response = client.get("/api/services")
    assert services_response.status_code == 200
    assert len(services_response.json()) >= 2


def test_otelctx_api_ingests_otlp_logs_and_metrics(tmp_path) -> None:
    repo = OtelRepository(tmp_path / "otel.db")
    repo.create_schema()

    app = create_app("otelctx", "0.1.0")
    app.include_router(build_router(repo))
    client = TestClient(app)

    logs_response = client.post(
        "/api/otlp/v1/logs",
        json={
            "resourceLogs": [
                {
                    "resource": {
                        "attributes": [
                            {"key": "service.name", "value": {"stringValue": "checkout"}}
                        ]
                    },
                    "scopeLogs": [
                        {
                            "logRecords": [
                                {
                                    "timeUnixNano": "1710784800000000000",
                                    "severityText": "ERROR",
                                    "body": {"stringValue": "payment failed"},
                                    "attributes": [
                                        {"key": "http.status_code", "value": {"intValue": "500"}}
                                    ]
                                }
                            ]
                        }
                    ],
                }
            ]
        },
    )
    assert logs_response.status_code == 200
    assert logs_response.json()["logs"] == 1

    metrics_response = client.post(
        "/api/otlp/v1/metrics",
        json={
            "resourceMetrics": [
                {
                    "resource": {
                        "attributes": [
                            {"key": "service.name", "value": {"stringValue": "checkout"}}
                        ]
                    },
                    "scopeMetrics": [
                        {
                            "metrics": [
                                {
                                    "name": "http.server.duration",
                                    "unit": "ms",
                                    "gauge": {
                                        "dataPoints": [
                                            {
                                                "timeUnixNano": "1710784800100000000",
                                                "asDouble": 42.5,
                                                "attributes": [
                                                    {"key": "route", "value": {"stringValue": "/checkout"}}
                                                ]
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    ],
                }
            ]
        },
    )
    assert metrics_response.status_code == 200
    assert metrics_response.json()["metrics"] == 1

    logs_list_response = client.get("/api/logs")
    assert logs_list_response.status_code == 200
    assert logs_list_response.json()[0]["body"] == "payment failed"

    metrics_list_response = client.get("/api/metrics")
    assert metrics_list_response.status_code == 200
    assert metrics_list_response.json()[0]["name"] == "http.server.duration"

    stats_response = client.get("/api/stats")
    assert stats_response.status_code == 200
    assert stats_response.json()["logs"] == 1
    assert stats_response.json()["metrics"] == 1


def test_otelctx_v1_traces_compatibility_route(tmp_path) -> None:
    app = build_app()
    client = TestClient(app)

    response = client.post(
        "/v1/traces",
        json={
            "resourceSpans": [
                {
                    "resource": {
                        "attributes": [
                            {"key": "service.name", "value": {"stringValue": "gateway"}}
                        ]
                    },
                    "scopeSpans": [
                        {
                            "spans": [
                                {
                                    "traceId": "compat-trace-1",
                                    "spanId": "compat-span-1",
                                    "name": "GET /health",
                                    "kind": 1,
                                    "status": {"code": 1},
                                    "startTimeUnixNano": "1710784800000000000",
                                    "endTimeUnixNano": "1710784800010000000"
                                }
                            ]
                        }
                    ],
                }
            ]
        },
    )
    assert response.status_code == 200
    assert response.json()["traces"] == 1
    assert response.json()["spans"] == 1


def test_otelctx_v1_logs_and_metrics_compatibility_routes() -> None:
    app = build_app()
    client = TestClient(app)

    logs_response = client.post(
        "/v1/logs",
        json={
            "resourceLogs": [
                {
                    "resource": {
                        "attributes": [
                            {"key": "service.name", "value": {"stringValue": "gateway"}}
                        ]
                    },
                    "scopeLogs": [
                        {
                            "logRecords": [
                                {
                                    "timeUnixNano": "1710784800000000000",
                                    "severityNumber": 17,
                                    "body": {"stringValue": "gateway timeout"}
                                }
                            ]
                        }
                    ],
                }
            ]
        },
    )
    assert logs_response.status_code == 200
    assert logs_response.json()["logs"] == 1

    metrics_response = client.post(
        "/v1/metrics",
        json={
            "resourceMetrics": [
                {
                    "resource": {
                        "attributes": [
                            {"key": "service.name", "value": {"stringValue": "gateway"}}
                        ]
                    },
                    "scopeMetrics": [
                        {
                            "metrics": [
                                {
                                    "name": "queue.depth",
                                    "gauge": {
                                        "dataPoints": [
                                            {
                                                "timeUnixNano": "1710784800200000000",
                                                "asInt": "3"
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    ],
                }
            ]
        },
    )
    assert metrics_response.status_code == 200
    assert metrics_response.json()["metrics"] == 1
