from fastapi.testclient import TestClient

from common.server import create_app


def test_health_endpoint() -> None:
    app = create_app("test-app", "0.1.0")
    client = TestClient(app)

    response = client.get("/api/health")
    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "ok"
    assert payload["version"] == "0.1.0"
