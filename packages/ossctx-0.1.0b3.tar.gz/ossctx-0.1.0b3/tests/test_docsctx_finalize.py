from docsctx.db.repository import DocsRepository
from docsctx.finalize import run_finalize
from docsctx.indexer import DocsIndexer


def test_docsctx_finalize_builds_entities_and_communities(tmp_path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    (docs_dir / "orders.md").write_text("# Orders\n\nOrders service tracks orders and payments.", encoding="utf-8")
    (docs_dir / "payments.md").write_text("# Payments\n\nPayments service reconciles orders and invoices.", encoding="utf-8")

    repo = DocsRepository(tmp_path / "docs.db")
    indexer = DocsIndexer(repo, chunk_size=80, chunk_overlap=10)
    indexer.index_path(docs_dir)

    summary = run_finalize(repo)
    stats = repo.get_stats()
    communities = repo.list_communities()
    document = repo.get_document(1)

    assert summary["documents"] == 2
    assert summary["provider_deterministic"] == 2
    assert stats.entities > 0
    assert stats.relationships > 0
    assert stats.communities >= 1
    assert communities
    assert document is not None
    assert document["structure"] is not None
    assert document["entities"]
    assert document["provider_status"] == "deterministic"
