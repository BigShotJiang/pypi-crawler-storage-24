from __future__ import annotations

from datetime import UTC, datetime

from fastapi.testclient import TestClient

from common.server import create_app
from otelctx.api.routes import build_router
from otelctx.archive import ArchiveTier
from otelctx.cache import DeadLetterQueue, _DlqBase
from otelctx.db.repository import OtelRepository, SpanRecord, TraceRecord
from otelctx.graph import ServiceGraph
from otelctx.sampler import AdaptiveSampler
from otelctx.tsdb import TsdbRingBuffer


def test_otelctx_advanced_routes_are_wired(tmp_path) -> None:
    repo = OtelRepository(tmp_path / "otel.db")
    repo.create_schema()
    _DlqBase.metadata.create_all(repo.engine)

    repo.ingest_traces(
        [
            TraceRecord(
                trace_id="trace-advanced",
                root_service_name="api",
                root_span_name="GET /orders",
                status_code="ERROR",
                spans=[
                    SpanRecord(
                        span_id="span-root",
                        name="GET /orders",
                        service_name="api",
                        status_code="OK",
                        start_time="2026-03-18T10:00:00Z",
                        end_time="2026-03-18T10:00:00.050000Z",
                    ),
                    SpanRecord(
                        span_id="span-db",
                        parent_span_id="span-root",
                        name="SELECT orders",
                        service_name="db",
                        status_code="ERROR",
                        start_time="2026-03-18T10:00:00.010000Z",
                        end_time="2026-03-18T10:00:00.030000Z",
                    ),
                ],
            )
        ]
    )

    tsdb = TsdbRingBuffer(per_series_capacity=16)
    tsdb.record("queue.depth", 4.0, {"service": "api"})
    tsdb.record("queue.depth", 8.0, {"service": "api"})

    archive = ArchiveTier(tmp_path / "archive", hot_days=0)
    archive.archive([{"trace_id": "archived-trace", "service": "api"}], signal="traces")

    dlq = DeadLetterQueue(repo.session_factory)
    entry_id = dlq.push('{"bad": true}', "failed ingest", signal="logs")
    sampler = AdaptiveSampler(rate=0.25)
    sampler.should_ingest("api")

    graph = ServiceGraph()
    graph.rebuild(repo)

    app = create_app("otelctx", "0.1.0")
    app.include_router(build_router(repo, graph=graph, tsdb=tsdb, archive=archive, dlq=dlq, sampler=sampler))
    client = TestClient(app)

    timeseries = client.get("/api/metrics/timeseries", params={"metric": "queue.depth", "window": 60, "step": 30, "service": "api"})
    assert timeseries.status_code == 200
    assert any(bucket["count"] > 0 for bucket in timeseries.json())

    archive_stats = client.get("/api/archive/stats")
    assert archive_stats.status_code == 200
    assert archive_stats.json()["record_count"] >= 1

    archive_search = client.get("/api/archive/search", params={"q": "archived-trace", "signal": "traces", "days_back": 1})
    assert archive_search.status_code == 200
    assert archive_search.json()[0]["trace_id"] == "archived-trace"

    dlq_list = client.get("/api/dlq")
    assert dlq_list.status_code == 200
    assert dlq_list.json()[0]["id"] == entry_id

    dlq_ack = client.post(f"/api/dlq/{entry_id}/ack")
    assert dlq_ack.status_code == 200
    assert dlq_ack.json() == {"acked": entry_id}

    sampler_stats = client.get("/api/sampler/stats")
    assert sampler_stats.status_code == 200
    assert sampler_stats.json()["rate"] == 0.25

    graph_response = client.get("/api/graph")
    assert graph_response.status_code == 200
    assert graph_response.json()["service_count"] >= 2

    health_response = client.get("/api/services/api/health")
    assert health_response.status_code == 200
    assert health_response.json()["name"] == "api"
