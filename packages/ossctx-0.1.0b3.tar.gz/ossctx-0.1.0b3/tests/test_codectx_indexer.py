from pathlib import Path

from codectx.db.repository import CodeRepository
from codectx.indexer import CodeIndexer


def test_indexer_indexes_python_and_go_files(tmp_path: Path) -> None:
    source_dir = tmp_path / "src"
    source_dir.mkdir()
    (source_dir / "main.py").write_text(
        "import os\n\nclass Demo:\n    def run(self):\n        return 1\n",
        encoding="utf-8",
    )
    (source_dir / "main.go").write_text(
        'package main\n\nimport "fmt"\n\nfunc Run() {}\n',
        encoding="utf-8",
    )

    repo = CodeRepository(tmp_path / "code.db")
    indexer = CodeIndexer(repo)
    summary = indexer.index_directory(source_dir)
    stats = repo.get_stats()

    assert summary.indexed_files == 2
    assert stats.files == 2
    assert stats.entities >= 3
    assert stats.dependencies >= 2


def test_indexer_directory_tree_reflects_nested_paths(tmp_path: Path) -> None:
    source_dir = tmp_path / "src"
    nested_dir = source_dir / "pkg"
    nested_dir.mkdir(parents=True)
    (nested_dir / "main.py").write_text("def hello():\n    return 1\n", encoding="utf-8")

    repo = CodeRepository(tmp_path / "code.db")
    indexer = CodeIndexer(repo)
    summary = indexer.index_directory(source_dir)
    tree = repo.get_directory_tree(root_prefix=str(source_dir))

    def contains_file(node: dict, target: str) -> bool:
        for key, value in node.items():
            if key == target:
                return True
            if isinstance(value, dict) and contains_file(value, target):
                return True
        return False

    assert summary.indexed_files == 1
    assert contains_file(tree, "main.py")

