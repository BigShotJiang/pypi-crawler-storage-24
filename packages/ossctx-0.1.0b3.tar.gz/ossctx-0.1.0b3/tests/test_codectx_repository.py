from pathlib import Path

from sqlalchemy import select

from codectx.db.models import Entity, EntityRelation, File
from codectx.db.repository import CodeRepository
from codectx.indexer import CodeIndexer


def test_codectx_stats_include_inserted_files(tmp_path: Path) -> None:
    repo = CodeRepository(tmp_path / "code.db")
    repo.create_schema()
    repo.upsert_file("src/main.py", "python", lines_of_code=42, tokens=120)

    stats = repo.get_stats()
    assert stats.files == 1
    assert stats.lines_of_code == 42
    assert stats.tokens == 120


def test_codectx_prefers_import_resolved_targets(tmp_path: Path) -> None:
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    (project_dir / "helpers.py").write_text("def helper():\n    return 1\n", encoding="utf-8")
    (project_dir / "other.py").write_text("def helper():\n    return 2\n", encoding="utf-8")
    (project_dir / "app.py").write_text(
        "from helpers import helper\n\ndef hello():\n    return helper()\n",
        encoding="utf-8",
    )

    repo = CodeRepository(tmp_path / "code.db")
    indexer = CodeIndexer(repo)
    indexer.index_directory(project_dir)

    with repo.session_factory() as session:
        app_file_id = session.scalar(select(File.id).where(File.path == str((project_dir / "app.py").resolve())))
        helpers_file_id = session.scalar(select(File.id).where(File.path == str((project_dir / "helpers.py").resolve())))
        assert app_file_id is not None
        assert helpers_file_id is not None

        source_entity = session.scalar(select(Entity).where(Entity.file_id == app_file_id, Entity.name == "hello"))
        assert source_entity is not None

        relation = session.scalar(select(EntityRelation).where(EntityRelation.source_entity_id == source_entity.id))
        assert relation is not None

        target_entity = session.scalar(select(Entity).where(Entity.id == relation.target_entity_id))
        assert target_entity is not None
        assert target_entity.file_id == helpers_file_id


def test_codectx_repository_exposes_global_helper_queries(tmp_path: Path) -> None:
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    (project_dir / "helpers.py").write_text("def helper():\n    return 1\n", encoding="utf-8")
    (project_dir / "app.py").write_text(
        "from helpers import helper\n\ndef hello():\n    return helper()\n",
        encoding="utf-8",
    )

    repo = CodeRepository(tmp_path / "code.db")
    CodeIndexer(repo).index_directory(project_dir)

    file_rows = repo.list_files(limit=10)
    assert file_rows

    file_payload = repo.get_file_by_id(file_rows[0]["id"])
    entities = repo.get_all_entities(limit=20)
    dependencies = repo.get_all_dependencies(limit=20)
    relations = repo.get_all_relations(limit=20)

    assert file_payload is not None
    assert file_payload["path"].endswith(".py")
    assert any(entity["name"] == "hello" for entity in entities)
    assert any("helpers" in dependency["target_path"] for dependency in dependencies)
    assert any(relation["relation_type"] == "calls" for relation in relations)

