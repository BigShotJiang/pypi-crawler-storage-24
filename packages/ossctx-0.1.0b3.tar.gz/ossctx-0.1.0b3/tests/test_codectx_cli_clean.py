from pathlib import Path

from typer.testing import CliRunner

from codectx.cli import app

runner = CliRunner()


def test_codectx_clean_removes_database(tmp_path: Path) -> None:
    db_path = tmp_path / "index.db"
    db_path.write_text("placeholder", encoding="utf-8")

    result = runner.invoke(app, ["clean", "--db", str(db_path)])
    assert result.exit_code == 0
    assert not db_path.exists()
    assert "Deleted database" in result.stdout
