from pathlib import Path

from docsctx.db.repository import DocumentRecord, DocsRepository


def test_docs_repository_search_returns_matching_chunk(tmp_path: Path) -> None:
    repo = DocsRepository(tmp_path / "docs.db")
    repo.create_schema()
    repo.upsert_document(
        DocumentRecord(
            source_uri="docs://guide",
            title="Guide",
            doc_type="markdown",
            checksum="abc",
            content="alpha beta gamma\nsearch term appears here",
            chunks=["alpha beta gamma", "search term appears here"],
        )
    )

    results = repo.search("search term", top_k=3)

    assert len(results) == 1
    assert results[0].title == "Guide"
    assert "search term" in results[0].snippet.lower()
