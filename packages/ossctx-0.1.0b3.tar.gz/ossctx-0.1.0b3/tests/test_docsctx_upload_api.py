from fastapi.testclient import TestClient

from common.server import create_app
from docsctx.api.routes import build_router
from docsctx.config import DocsSettings
from docsctx.db.repository import DocsRepository


def test_docsctx_upload_and_finalize_api(tmp_path) -> None:
    repo = DocsRepository(tmp_path / "docs.db")
    repo.create_schema()
    settings = DocsSettings(db_path=tmp_path / "docs.db")

    app = create_app("docsctx", "0.1.0")
    app.include_router(build_router(repo, settings))
    client = TestClient(app)

    upload_response = client.post(
        "/api/upload",
        json={
            "documents": [
                {"filename": "intro.md", "doc_type": "markdown", "content": "# Intro\n\nSearch and graph extraction overview."},
                {"filename": "guide.txt", "doc_type": "text", "content": "Guide covers search and overview details."},
            ]
        },
    )
    assert upload_response.status_code == 200
    assert upload_response.json()["indexed_documents"] == 2

    finalize_response = client.post("/api/finalize")
    assert finalize_response.status_code == 200
    assert finalize_response.json()["documents"] == 2
    assert finalize_response.json()["provider_deterministic"] == 2

    communities_response = client.get("/api/communities")
    assert communities_response.status_code == 200
    assert communities_response.json()

    documents_response = client.get("/api/documents")
    assert documents_response.status_code == 200
    assert documents_response.json()[0]["provider_status"] == "deterministic"
