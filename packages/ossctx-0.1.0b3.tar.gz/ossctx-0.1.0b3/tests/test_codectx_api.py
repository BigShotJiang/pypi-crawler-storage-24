from fastapi.testclient import TestClient

from codectx.api.routes import build_router
from codectx.db.repository import CodeRepository
from common.server import create_app


def test_codectx_stats_api(tmp_path) -> None:
    repo = CodeRepository(tmp_path / "code.db")
    repo.create_schema()
    repo.upsert_file("src/example.py", "python", lines_of_code=10, tokens=25)

    app = create_app("codectx", "0.1.0")
    app.include_router(build_router(repo))
    client = TestClient(app)

    response = client.get("/api/stats")
    assert response.status_code == 200
    assert response.json()["files"] == 1
