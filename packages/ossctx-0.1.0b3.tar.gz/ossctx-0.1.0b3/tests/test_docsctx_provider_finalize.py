import httpx

from docsctx.config import DocsSettings
from docsctx.db.repository import DocsRepository
from docsctx.finalize import run_finalize
from docsctx.indexer import DocsIndexer
from docsctx.provider import BaseProvider, ProviderAnalysis


def test_docsctx_finalize_with_mock_provider(tmp_path) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    (docs_dir / "orders.md").write_text("# Orders\n\nOrders service tracks orders and payments.", encoding="utf-8")
    (docs_dir / "payments.md").write_text("# Payments\n\nPayments service reconciles orders and invoices.", encoding="utf-8")

    repo = DocsRepository(tmp_path / "docs.db")
    indexer = DocsIndexer(repo, chunk_size=80, chunk_overlap=10)
    indexer.index_path(docs_dir)

    settings = DocsSettings(db_path=tmp_path / "docs.db", llm_provider="mock")
    summary = run_finalize(repo, settings)

    stats = repo.get_stats()
    document = repo.get_document(1)

    assert summary["documents"] == 2
    assert summary["provider_successes"] == 2
    assert stats.entities > 0
    assert stats.relationships > 0
    assert document is not None
    assert document["structure"] is not None
    assert document["structure"].get("summary")
    assert document["structure"]["provider"]["status"] == "succeeded"
    assert document["provider_status"] == "succeeded"


class _FlakyProvider(BaseProvider):
    def __init__(self) -> None:
        self.calls = 0

    def analyze(self, title: str, content: str) -> ProviderAnalysis:
        self.calls += 1
        if self.calls < 3:
            raise httpx.ReadTimeout("temporary provider timeout")
        return ProviderAnalysis(
            summary=f"summary for {title}",
            headings=[title],
            entities=[("orders", 2)],
            relationships=[("orders", "payments", 1)],
        )


class _AlwaysFailingProvider(BaseProvider):
    def analyze(self, title: str, content: str) -> ProviderAnalysis:
        raise ValueError("provider rejected payload")


def test_docsctx_finalize_retries_provider_before_success(tmp_path, monkeypatch) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    (docs_dir / "orders.md").write_text("# Orders\n\nOrders service tracks orders and payments.", encoding="utf-8")

    repo = DocsRepository(tmp_path / "docs.db")
    indexer = DocsIndexer(repo, chunk_size=80, chunk_overlap=10)
    indexer.index_path(docs_dir)

    provider = _FlakyProvider()
    monkeypatch.setattr("docsctx.finalize.create_provider", lambda settings: provider)
    settings = DocsSettings(db_path=tmp_path / "docs.db", llm_provider="openai", llm_max_retries=2, llm_retry_backoff_seconds=0.0)
    summary = run_finalize(repo, settings)

    document = repo.get_document(1)
    assert summary["provider_successes"] == 1
    assert summary["provider_fallbacks"] == 0
    assert document is not None
    assert document["structure"]["provider"]["attempts"] == 3
    assert document["structure"]["provider"]["status"] == "succeeded"


def test_docsctx_finalize_falls_back_and_persists_provider_error(tmp_path, monkeypatch) -> None:
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    (docs_dir / "orders.md").write_text("# Orders\n\nOrders service tracks orders and payments.", encoding="utf-8")

    repo = DocsRepository(tmp_path / "docs.db")
    indexer = DocsIndexer(repo, chunk_size=80, chunk_overlap=10)
    indexer.index_path(docs_dir)

    monkeypatch.setattr("docsctx.finalize.create_provider", lambda settings: _AlwaysFailingProvider())
    settings = DocsSettings(db_path=tmp_path / "docs.db", llm_provider="openai", llm_max_retries=1, llm_retry_backoff_seconds=0.0)
    summary = run_finalize(repo, settings)

    document = repo.get_document(1)
    assert summary["provider_successes"] == 0
    assert summary["provider_fallbacks"] == 1
    assert document is not None
    assert document["structure"]["provider"]["status"] == "fallback"
    assert document["structure"]["provider"]["fallback_used"] is True
    assert "ValueError" in document["structure"]["provider"]["last_error"]
    assert document["provider_status"] == "fallback"
