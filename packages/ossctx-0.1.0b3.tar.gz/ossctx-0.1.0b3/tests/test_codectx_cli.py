from pathlib import Path
import json

from typer.testing import CliRunner

from codectx.cli import app, build_mcp_server_entry
from codectx.db.repository import CodeRepository

runner = CliRunner()


def test_codectx_stats_cli(tmp_path: Path) -> None:
    db_path = tmp_path / "code.db"
    repo = CodeRepository(db_path)
    repo.create_schema()
    repo.upsert_file("src/example.py", "python", lines_of_code=10, tokens=25)

    result = runner.invoke(app, ["stats", "--db", str(db_path)])
    assert result.exit_code == 0
    assert "Files: 1" in result.stdout
    assert "Lines of code: 10" in result.stdout


def test_codectx_setup_writes_stdio_mcp_config(tmp_path: Path) -> None:
    config_path = tmp_path / ".vscode" / "mcp.json"

    result = runner.invoke(
        app,
        [
            "setup",
            "--output",
            str(config_path),
            "--binary",
            "ossCtx",
            "--db",
            "custom.db",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    server = payload["servers"]["ossctx-codectx"]
    assert server["type"] == "stdio"
    assert server["command"] == "ossCtx"
    assert server["args"] == ["code", "mcp", "--transport", "stdio", "--db", "custom.db"]


def test_codectx_setup_merges_existing_servers(tmp_path: Path) -> None:
    config_path = tmp_path / ".vscode" / "mcp.json"
    config_path.parent.mkdir(parents=True)
    config_path.write_text(
        json.dumps({"servers": {"existing": {"type": "http", "url": "https://example.test/mcp"}}, "inputs": []}),
        encoding="utf-8",
    )

    result = runner.invoke(app, ["setup", "--output", str(config_path)])

    assert result.exit_code == 0
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    assert "existing" in payload["servers"]
    assert "ossctx-codectx" in payload["servers"]


def test_build_mcp_server_entry_supports_streamable_http() -> None:
    entry = build_mcp_server_entry(binary="ossCtx", transport="streamable-http", addr="127.0.0.1:8081", db_path=None)

    assert entry == {"type": "http", "url": "http://127.0.0.1:8081/mcp"}
