from __future__ import annotations

import asyncio

from otelctx.realtime import RealtimeHub


class _FakeWebSocket:
    def __init__(self) -> None:
        self.messages: list[str] = []

    async def send_text(self, text: str) -> None:
        self.messages.append(text)


def test_realtime_hub_publish_updates_stats() -> None:
    hub = RealtimeHub(buffer_size=2, flush_interval_ms=10)

    hub.publish_sync({"type": "trace", "trace_id": "abc"})

    stats = hub.stats()
    assert stats["buffer_size"] == 1
    assert stats["buffer_capacity"] == 2


def test_realtime_hub_flush_loop_broadcasts_batches() -> None:
    async def run_test() -> None:
        hub = RealtimeHub(buffer_size=4, flush_interval_ms=10)
        socket = _FakeWebSocket()
        hub._clients.add(socket)
        hub._ensure_queue()

        task = asyncio.create_task(hub.flush_loop())
        try:
            hub.publish_sync({"type": "trace", "trace_id": "abc"})
            hub.publish_sync({"type": "log", "message": "warn"})
            await asyncio.sleep(0.05)
        finally:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        assert len(socket.messages) == 1
        assert '"events":' in socket.messages[0]
        assert '"trace_id": "abc"' in socket.messages[0]

    asyncio.run(run_test())
