"""Shared database helpers."""

from collections.abc import Iterator
from contextlib import contextmanager

from sqlalchemy import create_engine, text
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker


class Base(DeclarativeBase):
    """Declarative ORM base class."""


def create_engine_with_wal(db_url: str, echo: bool = False):
    """Create SQLAlchemy engine and enable SQLite WAL pragmas when applicable."""
    engine = create_engine(db_url, echo=echo, future=True)
    if db_url.startswith("sqlite"):
        with engine.begin() as conn:
            conn.execute(text("PRAGMA journal_mode=WAL;"))
            conn.execute(text("PRAGMA foreign_keys=ON;"))
            conn.execute(text("PRAGMA busy_timeout=5000;"))
    return engine


def create_session_factory(engine) -> sessionmaker[Session]:
    """Create a SQLAlchemy session factory."""
    return sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False, future=True)


@contextmanager
def session_scope(session_factory: sessionmaker[Session]) -> Iterator[Session]:
    """Context helper for transaction scoping."""
    session = session_factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
