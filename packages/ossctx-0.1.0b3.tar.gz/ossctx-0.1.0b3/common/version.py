"""Version helpers for ossctx."""

from importlib.metadata import PackageNotFoundError, version


try:
    __version__ = version("ossctx")
except PackageNotFoundError:
    __version__ = "0.1.0"
