"""Shared middleware and exception handlers."""

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from common.types import ErrorResponse


def add_exception_handlers(app: FastAPI) -> None:
    """Register uniform error responses."""

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(_: Request, exc: Exception) -> JSONResponse:
        payload = ErrorResponse(error="internal_error", detail=str(exc)).model_dump()
        return JSONResponse(status_code=500, content=payload)
