"""FastAPI app factory for all subsystems."""

from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from common.middleware import add_exception_handlers
from common.types import HealthResponse


def create_app(title: str, version: str) -> FastAPI:
    """Create a base app with shared middleware and health/version endpoint."""
    app = FastAPI(title=title, version=version, docs_url="/api/swagger", redoc_url="/api/redoc")

    @app.get("/api/health", response_model=HealthResponse)
    async def health() -> HealthResponse:
        return HealthResponse(status="ok", version=version)

    return app


def mount_spa(app: FastAPI, dist_dir: Path, mount_path: str = "/") -> None:
    """Mount static assets and add SPA fallback when built assets are present."""
    index_path = dist_dir / "index.html"
    if not index_path.exists():
        return

    app.mount(mount_path, StaticFiles(directory=str(dist_dir), html=True), name="spa")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa_fallback(full_path: str) -> FileResponse:
        _ = full_path
        return FileResponse(index_path)
