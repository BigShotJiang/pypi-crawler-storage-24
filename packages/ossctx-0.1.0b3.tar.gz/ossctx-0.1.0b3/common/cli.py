"""Root CLI app for ossctx."""

import typer

from codectx.cli import app as code_app
from docsctx.cli import app as docs_app
from otelctx.cli import app as otel_app
from ui.cli import app as ui_app
from common.version import __version__

app = typer.Typer(
    name="ossCtx",
    help="Unified CLI for code, docs, and otel context workflows.",
    no_args_is_help=True,
)
app.add_typer(code_app, name="code")
app.add_typer(docs_app, name="docs")
app.add_typer(otel_app, name="otel")
app.add_typer(ui_app, name="ui")


@app.callback()
def root_callback(version: bool = typer.Option(False, "--version", help="Show version and exit.")) -> None:
    """Root callback for global options."""
    if version:
        typer.echo(__version__)
        raise typer.Exit()


def main() -> None:
    """Console entrypoint."""
    app()
