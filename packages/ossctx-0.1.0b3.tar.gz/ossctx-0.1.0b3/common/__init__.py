"""Shared platform layer for ossctx."""

from .version import __version__

__all__ = ["__version__"]
