"""CLI entrypoint for the unified UI."""

from __future__ import annotations

from pathlib import Path

import typer
import uvicorn

from ui.app import build_app
from otelctx.db.repository import OtelRepository
from otelctx.api.routes import ingest_payload


app = typer.Typer(help="Unified UI commands.", no_args_is_help=True)


@app.command("serve")
def serve(
    host: str = typer.Option("127.0.0.1", "--host", help="Bind host."),
    port: int = typer.Option(8070, "--port", help="Bind port."),
    grpc_port: int = typer.Option(4317, "--grpc-port", help="OTLP gRPC port."),
    code_db: str = typer.Option(".codecontext.db", "--code-db", help="Path to the code context database."),
    docs_db: str = typer.Option(".docscontext.db", "--docs-db", help="Path to the docs context database."),
    otel_db: str = typer.Option(".otelcontext.db", "--otel-db", help="Path to the otel context database."),
) -> None:
    """Run the unified ossctx UI and API server."""
    grpc_server = None
    if grpc_port > 0:
        try:
            from otelctx.otlp_grpc import start_otlp_grpc_server
            otel_repo = OtelRepository(Path(otel_db))
            otel_repo.create_schema()
            grpc_server = start_otlp_grpc_server(
                grpc_port,
                lambda payload: ingest_payload(otel_repo, payload),
            )
            typer.echo(f"OTLP gRPC receiver listening on 0.0.0.0:{grpc_port}")
        except RuntimeError as exc:
            typer.echo(f"OTLP gRPC disabled: {exc}")

    try:
        app_instance = build_app(code_db=Path(code_db), docs_db=Path(docs_db), otel_db=Path(otel_db))
        uvicorn.run(app_instance, host=host, port=port)
    finally:
        if grpc_server is not None:
            grpc_server.stop(grace=1)


def compat_main() -> None:
    """Compatibility entrypoint for a direct UI command."""
    app()
