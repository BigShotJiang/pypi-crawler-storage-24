"""FastAPI application factory for the unified ossctx UI."""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from common.server import create_app
from common.version import __version__
from ui.views import build_router, configure_databases

from codectx.cli import build_app as build_code_app
from codectx.config import CodeSettings
from docsctx.cli import build_app as build_docs_app
from docsctx.config import DocsSettings
from otelctx.cli import build_app as build_otel_app
from otelctx.config import OtelSettings
from otelctx.db.repository import OtelRepository
from otelctx.api.routes import ingest_payload


def _templates_dir() -> Path:
    return Path(__file__).resolve().parent / "templates"


def _static_dir() -> Path:
    return Path(__file__).resolve().parent / "static"


def build_app(code_db: str | Path = ".codecontext.db", docs_db: str | Path = ".docscontext.db", otel_db: str | Path = ".otelcontext.db") -> FastAPI:
    """Create the unified UI application."""
    configure_databases(code_db=Path(code_db), docs_db=Path(docs_db), otel_db=Path(otel_db))
    
    app = create_app("ossctx-ui", __version__)
    app.state.templates = Jinja2Templates(directory=str(_templates_dir()))
    app.mount("/static", StaticFiles(directory=str(_static_dir())), name="static")
    
    app.include_router(build_router())

    # Mount sub-APIs
    app.mount("/api/code", build_code_app(CodeSettings(db_path=Path(code_db))))
    app.mount("/api/docs", build_docs_app(DocsSettings(db_path=Path(docs_db))))
    
    otel_settings = OtelSettings(db_path=Path(otel_db))
    otel_app = build_otel_app(otel_settings)
    app.mount("/api/otel", otel_app)

    # Expose standard OTLP HTTP receiver endpoints at the root for compatibility
    otel_repo = OtelRepository(Path(otel_db))
    
    @app.post("/v1/traces")
    async def ingest_otlp_traces(payload: dict[str, object]) -> dict[str, int]:
        return ingest_payload(otel_repo, payload)

    @app.post("/v1/logs")
    async def ingest_otlp_logs(payload: dict[str, object]) -> dict[str, int]:
        return ingest_payload(otel_repo, payload)

    @app.post("/v1/metrics")
    async def ingest_otlp_metrics(payload: dict[str, object]) -> dict[str, int]:
        return ingest_payload(otel_repo, payload)

    return app
