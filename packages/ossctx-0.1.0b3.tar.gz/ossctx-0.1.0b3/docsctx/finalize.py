"""Finalize structured and community analysis for docsctx."""

from __future__ import annotations

from docsctx.analysis import analyze_document, build_communities
from docsctx.config import DocsSettings
from docsctx.db.repository import DocsRepository
from docsctx.provider import analyze_with_retries, create_provider


def run_finalize(repository: DocsRepository, settings: DocsSettings | None = None) -> dict[str, int]:
    """Build document structures, entities, relationships, and communities."""
    resolved_settings = settings or DocsSettings()
    provider = None
    provider_setup_error = ""
    requested_provider = resolved_settings.llm_provider.lower().strip() or "none"
    if requested_provider not in {"", "none"}:
        try:
            provider = create_provider(resolved_settings)
        except Exception as exc:
            provider_setup_error = f"{type(exc).__name__}: {exc}"

    documents = repository.list_documents_for_analysis()
    analyzed = []
    provider_successes = 0
    provider_fallbacks = 0
    provider_deterministic = 0
    for document in documents:
        analyzed_doc = analyze_document(
            document_id=document["id"],
            title=document["title"],
            source_uri=document["source_uri"],
            doc_type=document["doc_type"],
            content=document["content"],
        )

        if provider is None:
            if provider_setup_error:
                provider_fallbacks += 1
                provider_meta = {
                    "requested_provider": requested_provider,
                    "used_provider": "deterministic",
                    "status": "fallback",
                    "attempts": 0,
                    "fallback_used": True,
                    "last_error": provider_setup_error,
                }
            else:
                provider_deterministic += 1
                provider_meta = {
                    "requested_provider": requested_provider,
                    "used_provider": "deterministic",
                    "status": "deterministic",
                    "attempts": 0,
                    "fallback_used": False,
                    "last_error": "",
                }
        else:
            provider_attempt = analyze_with_retries(
                provider,
                document["title"],
                document["content"],
                max_retries=resolved_settings.llm_max_retries,
                backoff_seconds=resolved_settings.llm_retry_backoff_seconds,
            )
            if provider_attempt.succeeded and provider_attempt.analysis is not None:
                provider_result = provider_attempt.analysis
                analyzed_doc.structure["summary"] = provider_result.summary or analyzed_doc.structure.get("summary", "")
                analyzed_doc.structure["headings"] = provider_result.headings or analyzed_doc.structure.get("headings", [])
                analyzed_doc.entities = provider_result.entities or analyzed_doc.entities
                analyzed_doc.relationships = provider_result.relationships or analyzed_doc.relationships
                provider_successes += 1
                provider_meta = {
                    "requested_provider": requested_provider,
                    "used_provider": requested_provider,
                    "status": "succeeded",
                    "attempts": provider_attempt.attempts,
                    "fallback_used": False,
                    "last_error": "",
                }
            elif resolved_settings.llm_fallback_on_error:
                provider_fallbacks += 1
                provider_meta = {
                    "requested_provider": requested_provider,
                    "used_provider": "deterministic",
                    "status": "fallback",
                    "attempts": provider_attempt.attempts,
                    "fallback_used": True,
                    "last_error": provider_attempt.error,
                }
            else:
                raise RuntimeError(provider_attempt.error or "Provider analysis failed")
        analyzed_doc.structure["provider"] = provider_meta
        analyzed.append(analyzed_doc)

    for document in analyzed:
        repository.store_document_analysis(
            document.document_id,
            structure=document.structure,
            entities=document.entities,
            relationships=document.relationships,
        )

    communities = build_communities(analyzed)
    repository.replace_communities(communities)
    return {
        "documents": len(analyzed),
        "communities": len(communities),
        "provider_successes": provider_successes,
        "provider_fallbacks": provider_fallbacks,
        "provider_deterministic": provider_deterministic,
    }
