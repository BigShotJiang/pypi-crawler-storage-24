"""Docs context subsystem."""
