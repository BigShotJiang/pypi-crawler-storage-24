"""Provider-backed extraction helpers for docsctx."""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass

import httpx

from docsctx.config import DocsSettings
from docsctx.extractor import ExtractedClaim, ExtractedEntity, ExtractedRelationship, ExtractionResult


@dataclass(slots=True)
class ProviderAnalysis:
    summary: str
    headings: list[str]
    entities: list[tuple[str, int]]
    relationships: list[tuple[str, str, int]]



@dataclass(slots=True)
class ProviderAttemptResult:
    analysis: ProviderAnalysis | None
    attempts: int
    error: str = ""

    @property
    def succeeded(self) -> bool:
        return self.analysis is not None


class BaseProvider:
    def analyze(self, title: str, content: str) -> ProviderAnalysis:
        raise NotImplementedError

    def extract_graph(self, title: str, content: str) -> ExtractionResult:
        """Extract entities, relationships, and claims via LLM."""
        raise NotImplementedError

    def synthesize_global_answer(self, query: str, community_summaries: str) -> str:
        """Synthesize an answer from community summaries. Override in subclasses."""
        return ""


class MockProvider(BaseProvider):
    WORD_RE = re.compile(r"[A-Za-z][A-Za-z0-9_-]{2,}")

    def analyze(self, title: str, content: str) -> ProviderAnalysis:
        words: dict[str, int] = {}
        for match in self.WORD_RE.finditer(content.lower()):
            word = match.group(0)
            words[word] = words.get(word, 0) + 1
        top = sorted(words.items(), key=lambda item: (-item[1], item[0]))[:8]
        entities = [(word, count) for word, count in top]
        relationships: list[tuple[str, str, int]] = []
        for index, (left, left_count) in enumerate(entities[:4]):
            for right, right_count in entities[index + 1 : 4]:
                relationships.append((left, right, min(left_count, right_count)))
        headings = [line.lstrip("#").strip() for line in content.splitlines() if line.strip().startswith("#")][:10]
        summary = " ".join(content.splitlines()[:3]).strip()[:400]
        return ProviderAnalysis(summary=summary, headings=headings, entities=entities, relationships=relationships)

    def extract_graph(self, title: str, content: str) -> ExtractionResult:
        """Mock extraction returning empty results."""
        return ExtractionResult(entities=[], relationships=[], claims=[])

    def synthesize_global_answer(self, query: str, community_summaries: str) -> str:
        return f"Based on indexed documents: {community_summaries[:200]}"


class OpenAICompatibleProvider(BaseProvider):
    def __init__(self, base_url: str, model: str, api_key: str, timeout: float = 20.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout

    def analyze(self, title: str, content: str) -> ProviderAnalysis:
        prompt = self._prompt(title, content)
        response = httpx.post(
            f"{self.base_url}/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={
                "model": self.model,
                "temperature": 0,
                "messages": [
                    {"role": "system", "content": "Extract structured document metadata as strict JSON."},
                    {"role": "user", "content": prompt},
                ],
                "response_format": {"type": "json_object"},
            },
            timeout=self.timeout,
        )
        response.raise_for_status()
        payload = response.json()
        text = payload["choices"][0]["message"]["content"]
        return _parse_analysis_json(text)

    def extract_graph(self, title: str, content: str) -> ExtractionResult:
        """Extract entities, relationships, and claims via LLM."""
        prompt = self._extraction_prompt(title, content)
        response = httpx.post(
            f"{self.base_url}/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={
                "model": self.model,
                "temperature": 0,
                "messages": [
                    {"role": "system", "content": "You are a knowledge graph extraction expert. Extract entities, relationships, and claims as strict JSON."},
                    {"role": "user", "content": prompt},
                ],
                "response_format": {"type": "json_object"},
            },
            timeout=self.timeout,
        )
        response.raise_for_status()
        payload = response.json()
        text = payload["choices"][0]["message"]["content"]
        return _parse_extraction_json(text)

    @staticmethod
    def _prompt(title: str, content: str) -> str:
        clipped = content[:12000]
        return (
            "Return only JSON with fields: summary (string), headings (array of strings), "
            "entities (array of {name,score}), relationships (array of {source,target,weight}). "
            f"Title: {title}\nContent:\n{clipped}"
        )

    @staticmethod
    def _extraction_prompt(title: str, content: str) -> str:
        clipped = content[:12000]
        return (
            "Extract a knowledge graph from the document. Return JSON with:\n"
            '- "entities": array of {name, type (Person/Org/Concept/Location/Event/Technology), description, score}\n'
            '- "relationships": array of {source, target, predicate (describes/relates_to/part_of/caused_by), description, weight}\n'
            '- "claims": array of {entity, claim, status (CONFIRMED/REFUTED/SPECULATIVE)}\n'
            f"Title: {title}\nContent:\n{clipped}"
        )

    def synthesize_global_answer(self, query: str, community_summaries: str) -> str:
        clipped = community_summaries[:6000]
        response = httpx.post(
            f"{self.base_url}/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={
                "model": self.model,
                "temperature": 0,
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a helpful assistant that synthesizes document knowledge to answer questions concisely.",
                    },
                    {
                        "role": "user",
                        "content": (
                            f"Community summaries from indexed documents:\n{clipped}\n\n"
                            f"Answer this question using only the provided summaries: {query}"
                        ),
                    },
                ],
            },
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]



class OllamaProvider(BaseProvider):
    def __init__(self, base_url: str, model: str, timeout: float = 20.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout

    def analyze(self, title: str, content: str) -> ProviderAnalysis:
        prompt = OpenAICompatibleProvider._prompt(title, content)
        response = httpx.post(
            f"{self.base_url}/api/chat",
            json={
                "model": self.model,
                "stream": False,
                "messages": [
                    {"role": "system", "content": "Extract structured document metadata as strict JSON."},
                    {"role": "user", "content": prompt},
                ],
                "format": "json",
            },
            timeout=self.timeout,
        )
        response.raise_for_status()
        payload = response.json()
        text = payload.get("message", {}).get("content", "{}")
        return _parse_analysis_json(str(text))

    def extract_graph(self, title: str, content: str) -> ExtractionResult:
        """Extract entities, relationships, and claims via Ollama."""
        prompt = OpenAICompatibleProvider._extraction_prompt(title, content)
        response = httpx.post(
            f"{self.base_url}/api/chat",
            json={
                "model": self.model,
                "stream": False,
                "messages": [
                    {"role": "system", "content": "You are a knowledge graph extraction expert. Extract entities, relationships, and claims as strict JSON."},
                    {"role": "user", "content": prompt},
                ],
                "format": "json",
            },
            timeout=self.timeout,
        )
        response.raise_for_status()
        payload = response.json()
        text = payload.get("message", {}).get("content", "{}")
        return _parse_extraction_json(str(text))

    def synthesize_global_answer(self, query: str, community_summaries: str) -> str:
        clipped = community_summaries[:6000]
        response = httpx.post(
            f"{self.base_url}/api/chat",
            json={
                "model": self.model,
                "stream": False,
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a helpful assistant that synthesizes document knowledge to answer questions concisely.",
                    },
                    {
                        "role": "user",
                        "content": (
                            f"Community summaries from indexed documents:\n{clipped}\n\n"
                            f"Answer this question using only the provided summaries: {query}"
                        ),
                    },
                ],
            },
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json().get("message", {}).get("content", "")


def create_provider(settings: DocsSettings) -> BaseProvider | None:
    provider = settings.llm_provider.lower().strip()
    if provider in {"", "none"}:
        return None
    if provider == "mock":
        return MockProvider()
    if provider == "ollama":
        return OllamaProvider(settings.llm_base_url, settings.llm_model, timeout=settings.llm_timeout_seconds)
    if provider in {"openai", "azure"}:
        if not settings.llm_api_key:
            raise ValueError("DOCSCTX_LLM_API_KEY is required for openai/azure providers")
        base_url = settings.llm_base_url
        if provider == "azure":
            base_url = f"{settings.llm_base_url.rstrip('/')}/openai/deployments/{settings.llm_model}"
        return OpenAICompatibleProvider(base_url, settings.llm_model, settings.llm_api_key, timeout=settings.llm_timeout_seconds)
    raise ValueError(f"Unsupported docs LLM provider: {settings.llm_provider}")


def analyze_with_retries(
    provider: BaseProvider,
    title: str,
    content: str,
    max_retries: int = 0,
    backoff_seconds: float = 0.0,
) -> ProviderAttemptResult:
    attempts = 0
    last_error = ""
    total_attempts = max(1, max_retries + 1)
    for attempt in range(total_attempts):
        attempts = attempt + 1
        try:
            return ProviderAttemptResult(analysis=provider.analyze(title, content), attempts=attempts)
        except Exception as exc:
            last_error = f"{type(exc).__name__}: {exc}"
            if attempt + 1 >= total_attempts:
                break
            if backoff_seconds > 0:
                time.sleep(backoff_seconds * attempts)
    return ProviderAttemptResult(analysis=None, attempts=attempts, error=last_error)


def _parse_analysis_json(raw_text: str) -> ProviderAnalysis:
    text = raw_text.strip()
    if not text:
        return ProviderAnalysis(summary="", headings=[], entities=[], relationships=[])
    if not text.startswith("{"):
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            text = text[start : end + 1]
    payload = json.loads(text)
    summary = str(payload.get("summary") or "")
    headings = [str(item) for item in payload.get("headings", []) if isinstance(item, str)]
    entities = []
    for item in payload.get("entities", []):
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        score = int(item.get("score") or 0)
        if name:
            entities.append((name, score))
    relationships = []
    for item in payload.get("relationships", []):
        if not isinstance(item, dict):
            continue
        source = str(item.get("source") or "").strip()
        target = str(item.get("target") or "").strip()
        weight = int(item.get("weight") or 0)
        if source and target:
            relationships.append((source, target, weight))
    return ProviderAnalysis(summary=summary, headings=headings, entities=entities, relationships=relationships)


def _parse_extraction_json(raw_text: str) -> ExtractionResult:
    """Parse knowledge graph JSON from LLM."""
    text = raw_text.strip()
    if not text:
        return ExtractionResult(entities=[], relationships=[], claims=[])
    if not text.startswith("{"):
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            text = text[start : end + 1]
    try:
        payload = json.loads(text)
    except (json.JSONDecodeError, ValueError):
        return ExtractionResult(entities=[], relationships=[], claims=[])

    # Parse entities
    entities: list[ExtractedEntity] = []
    for item in payload.get("entities", []):
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        entity_type = str(item.get("type") or "Concept").strip()
        description = str(item.get("description") or "").strip()
        score = int(item.get("score") or 0)
        if name:
            entities.append(ExtractedEntity(name=name, entity_type=entity_type, description=description, score=score))

    # Parse relationships
    relationships: list[ExtractedRelationship] = []
    for item in payload.get("relationships", []):
        if not isinstance(item, dict):
            continue
        source = str(item.get("source") or "").strip()
        target = str(item.get("target") or "").strip()
        predicate = str(item.get("predicate") or "").strip()
        description = str(item.get("description") or "").strip()
        weight = float(item.get("weight") or 1.0)
        if source and target:
            relationships.append(ExtractedRelationship(source=source, target=target, predicate=predicate, description=description, weight=weight))

    # Parse claims
    claims: list[ExtractedClaim] = []
    for item in payload.get("claims", []):
        if not isinstance(item, dict):
            continue
        entity = str(item.get("entity") or "").strip()
        claim = str(item.get("claim") or "").strip()
        status = str(item.get("status") or "SPECULATIVE").strip()
        if entity and claim:
            claims.append(ExtractedClaim(entity_name=entity, claim=claim, status=status))

    return ExtractionResult(entities=entities, relationships=relationships, claims=claims)
