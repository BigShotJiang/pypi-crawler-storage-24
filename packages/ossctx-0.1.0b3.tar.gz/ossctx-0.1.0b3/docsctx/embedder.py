"""Embedding provider for docsctx GraphRAG pipeline."""

from __future__ import annotations

import math
import struct

import httpx

from docsctx.config import DocsSettings


def encode_vector(vec: list[float]) -> bytes:
    """Pack a float vector into a compact bytes blob."""
    return struct.pack(f"<{len(vec)}f", *vec)


def decode_vector(data: bytes) -> list[float]:
    """Unpack a bytes blob into a float list."""
    count = len(data) // 4
    return list(struct.unpack(f"<{count}f", data))


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors."""
    if len(a) != len(b) or not a:
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


class BaseEmbedder:
    """Abstract embedding provider."""

    def embed_one(self, text: str) -> list[float]:
        raise NotImplementedError

    def embed_query(self, text: str) -> list[float]:
        """Embed a single query string. Alias for embed_one()."""
        return self.embed_one(text)

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [self.embed_one(t) for t in texts]


class OpenAIEmbedder(BaseEmbedder):
    """Embedding via OpenAI-compatible ``/embeddings`` endpoint."""

    def __init__(self, base_url: str, model: str, api_key: str, timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout

    def embed_one(self, text: str) -> list[float]:
        return self.embed_batch([text])[0]

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        response = httpx.post(
            f"{self.base_url}/embeddings",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={"model": self.model, "input": texts},
            timeout=self.timeout,
        )
        response.raise_for_status()
        data = response.json()["data"]
        data.sort(key=lambda item: item["index"])
        return [item["embedding"] for item in data]


class OllamaEmbedder(BaseEmbedder):
    """Embedding via Ollama ``/api/embed`` endpoint."""

    def __init__(self, base_url: str, model: str, timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout

    def embed_one(self, text: str) -> list[float]:
        response = httpx.post(
            f"{self.base_url}/api/embed",
            json={"model": self.model, "input": text},
            timeout=self.timeout,
        )
        response.raise_for_status()
        payload = response.json()
        embeddings = payload.get("embeddings", [])
        return embeddings[0] if embeddings else []

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        response = httpx.post(
            f"{self.base_url}/api/embed",
            json={"model": self.model, "input": texts},
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json().get("embeddings", [])


class HuggingFaceEmbedder(BaseEmbedder):
    """Embedding via HuggingFace Inference API."""

    def __init__(self, api_key: str, model: str = "sentence-transformers/all-MiniLM-L6-v2", timeout: float = 30.0) -> None:
        self.api_key = api_key
        self.model = model
        self.timeout = timeout
        self._base_url = f"https://api-inference.huggingface.co/pipeline/feature-extraction/{model}"

    def embed_one(self, text: str) -> list[float]:
        return self.embed_batch([text])[0]

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        response = httpx.post(
            self._base_url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={"inputs": texts, "options": {"wait_for_model": True}},
            timeout=self.timeout,
        )
        response.raise_for_status()
        result = response.json()
        if isinstance(result, list) and result and isinstance(result[0], list):
            return result
        if isinstance(result, list) and result and isinstance(result[0], (int, float)):
            return [result]
        return []


def create_embedder(settings: DocsSettings) -> BaseEmbedder | None:
    """Create an embedder from settings; returns None if not configured."""
    provider = settings.llm_provider.lower().strip()
    model = settings.embed_model or settings.llm_model
    if provider in {"", "none", "mock"}:
        return None
    if provider == "ollama":
        base_url = settings.embed_base_url or settings.llm_base_url
        return OllamaEmbedder(base_url, model, timeout=settings.llm_timeout_seconds)
    if provider in {"openai", "azure"}:
        if not (settings.embed_api_key or settings.llm_api_key):
            return None
        base_url = settings.embed_base_url or settings.llm_base_url
        api_key = settings.embed_api_key or settings.llm_api_key
        if provider == "azure":
            base_url = f"{base_url.rstrip('/')}/openai/deployments/{model}"
        return OpenAIEmbedder(base_url, model, api_key, timeout=settings.llm_timeout_seconds)
    if provider == "huggingface":
        api_key = settings.embed_api_key or settings.llm_api_key
        if not api_key:
            return None
        return HuggingFaceEmbedder(api_key, model, timeout=settings.llm_timeout_seconds)
    return None


def embed_texts(
    embedder: BaseEmbedder,
    texts: list[str],
    batch_size: int = 20,
) -> list[list[float]]:
    """Embed a list of texts in batches."""
    results: list[list[float]] = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        results.extend(embedder.embed_batch(batch))
    return results
