"""Configuration for the docs context subsystem."""

from pathlib import Path

from pydantic import Field

from common.config import BaseAppSettings


class DocsSettings(BaseAppSettings):
    """Settings for docsctx."""

    db_path: Path = Field(default=Path(".docscontext.db"), alias="DOCSCTX_DB_PATH")
    host: str = Field(default="127.0.0.1", alias="DOCSCTX_HOST")
    port: int = Field(default=8090, alias="DOCSCTX_PORT")
    chunk_size: int = Field(default=1200, alias="DOCSCTX_CHUNK_SIZE")
    chunk_overlap: int = Field(default=150, alias="DOCSCTX_CHUNK_OVERLAP")
    max_pages: int = Field(default=100, alias="DOCSCTX_MAX_PAGES")
    max_depth: int = Field(default=2, alias="DOCSCTX_MAX_DEPTH")
    llm_provider: str = Field(default="none", alias="DOCSCTX_LLM_PROVIDER")
    llm_model: str = Field(default="gpt-4o-mini", alias="DOCSCTX_LLM_MODEL")
    llm_base_url: str = Field(default="https://api.openai.com/v1", alias="DOCSCTX_LLM_BASE_URL")
    llm_api_key: str = Field(default="", alias="DOCSCTX_LLM_API_KEY")
    llm_timeout_seconds: float = Field(default=20.0, alias="DOCSCTX_LLM_TIMEOUT_SECONDS")
    llm_max_retries: int = Field(default=2, alias="DOCSCTX_LLM_MAX_RETRIES")
    llm_retry_backoff_seconds: float = Field(default=0.25, alias="DOCSCTX_LLM_RETRY_BACKOFF_SECONDS")
    llm_fallback_on_error: bool = Field(default=True, alias="DOCSCTX_LLM_FALLBACK_ON_ERROR")
    embed_model: str = Field(default="", alias="DOCSCTX_EMBED_MODEL")
    embed_base_url: str = Field(default="", alias="DOCSCTX_EMBED_BASE_URL")
    embed_api_key: str = Field(default="", alias="DOCSCTX_EMBED_API_KEY")
    embed_batch_size: int = Field(default=20, alias="DOCSCTX_EMBED_BATCH_SIZE")
    community_min_size: int = Field(default=1, alias="DOCSCTX_COMMUNITY_MIN_SIZE")
    community_max_levels: int = Field(default=3, alias="DOCSCTX_COMMUNITY_MAX_LEVELS")
    extract_claims: bool = Field(default=True, alias="DOCSCTX_EXTRACT_CLAIMS")
