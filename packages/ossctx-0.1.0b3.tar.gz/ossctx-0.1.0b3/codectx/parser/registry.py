"""Language detection and parser dispatch."""

from pathlib import Path

from codectx.parser.types import ParseResult

SUPPORTED_EXTENSIONS: dict[str, str] = {
    # Core (tree-sitter accelerated)
    ".go":   "go",
    ".py":   "python",
    ".pyw":  "python",
    ".js":   "javascript",
    ".jsx":  "javascript",
    ".mjs":  "javascript",
    ".cjs":  "javascript",
    ".ts":   "typescript",
    ".tsx":  "typescript",
    ".mts":  "typescript",
    ".cts":  "typescript",
    ".java": "java",
    # Tier 1
    ".rs":    "rust",
    ".cs":    "csharp",
    ".rb":    "ruby",
    ".sql":   "sql",
    ".kt":    "kotlin",
    ".kts":   "kotlin",
    ".scala": "scala",
    ".sc":    "scala",
    ".sbt":   "scala",
    # Tier 2
    ".sh":    "bash",
    ".bash":  "bash",
    ".zsh":   "bash",
    ".fish":  "bash",
    ".lua":   "lua",
    ".pl":    "perl",
    ".pm":    "perl",
    ".r":     "r",
    ".R":     "r",
    # Tier 3 — markup & config
    ".html":  "html",
    ".htm":   "html",
    ".css":   "css",
    ".scss":  "css",
    ".sass":  "css",
    ".md":    "markdown",
    ".markdown": "markdown",
    ".json":  "json",
    ".xml":   "xml",
    ".xsd":   "xml",
    ".xsl":   "xml",
    ".xslt":  "xml",
    ".svg":   "xml",
    ".yml":   "yaml",
    ".yaml":  "yaml",
    ".toml":  "toml",
    ".hcl":   "hcl",
    ".tf":    "hcl",
    ".tfvars": "hcl",
    ".properties": "properties",
}

# Dockerfile has no extension — matched by filename below.
_FILENAME_MAP: dict[str, str] = {
    "Dockerfile": "dockerfile",
    "dockerfile": "dockerfile",
}


def detect_language(file_path: str) -> str:
    p = Path(file_path)
    by_name = _FILENAME_MAP.get(p.name)
    if by_name:
        return by_name
    return SUPPORTED_EXTENSIONS.get(p.suffix.lower(), "unknown")


def parse_file(file_path: str, content: str) -> ParseResult:  # noqa: C901
    language = detect_language(file_path)
    if language == "python":
        from codectx.parser.python_parser import parse_python
        return parse_python(file_path, content)
    if language == "go":
        from codectx.parser.go_parser import parse_go
        return parse_go(file_path, content)
    if language in {"javascript", "typescript"}:
        from codectx.parser.javascript_parser import parse_javascript
        return parse_javascript(file_path, content)
    if language == "java":
        from codectx.parser.java_parser import parse_java
        return parse_java(file_path, content)
    if language == "rust":
        from codectx.parser.rust_parser import parse_rust
        return parse_rust(file_path, content)
    if language == "csharp":
        from codectx.parser.csharp_parser import parse_csharp
        return parse_csharp(file_path, content)
    if language == "ruby":
        from codectx.parser.ruby_parser import parse_ruby
        return parse_ruby(file_path, content)
    if language == "sql":
        from codectx.parser.sql_parser import parse_sql
        return parse_sql(file_path, content)
    if language == "kotlin":
        from codectx.parser.kotlin_parser import parse_kotlin
        return parse_kotlin(file_path, content)
    if language == "scala":
        from codectx.parser.scala_parser import parse_scala
        return parse_scala(file_path, content)
    if language == "bash":
        from codectx.parser.bash_parser import parse_bash
        return parse_bash(file_path, content)
    if language == "lua":
        from codectx.parser.lua_parser import parse_lua
        return parse_lua(file_path, content)
    if language == "perl":
        from codectx.parser.perl_parser import parse_perl
        return parse_perl(file_path, content)
    if language == "r":
        from codectx.parser.r_parser import parse_r
        return parse_r(file_path, content)
    if language == "html":
        from codectx.parser.html_parser import parse_html
        return parse_html(file_path, content)
    if language == "css":
        from codectx.parser.css_parser import parse_css
        return parse_css(file_path, content)
    if language == "markdown":
        from codectx.parser.markdown_parser import parse_markdown
        return parse_markdown(file_path, content)
    if language == "json":
        from codectx.parser.json_parser import parse_json
        return parse_json(file_path, content)
    if language == "xml":
        from codectx.parser.xml_parser import parse_xml
        return parse_xml(file_path, content)
    if language == "yaml":
        from codectx.parser.yaml_parser import parse_yaml
        return parse_yaml(file_path, content)
    if language == "toml":
        from codectx.parser.toml_parser import parse_toml
        return parse_toml(file_path, content)
    if language == "hcl":
        from codectx.parser.hcl_parser import parse_hcl
        return parse_hcl(file_path, content)
    if language == "properties":
        from codectx.parser.properties_parser import parse_properties
        return parse_properties(file_path, content)
    if language == "dockerfile":
        from codectx.parser.dockerfile_parser import parse_dockerfile
        return parse_dockerfile(file_path, content)
    return ParseResult(file_path=file_path, language=language)
