"""Dockerfile parser — instructions and build stages as entities."""

from __future__ import annotations

import re

from codectx.parser.types import DependencyRecord, EntityRecord, ParseResult

# FROM image AS stage
_FROM_RE   = re.compile(r"^FROM\s+(\S+)(?:\s+AS\s+(\S+))?", re.MULTILINE | re.IGNORECASE)
# COPY --from=stage ...
_COPY_FROM_RE = re.compile(r"^COPY\s+--from=(\S+)", re.MULTILINE | re.IGNORECASE)
# ARG NAME
_ARG_RE    = re.compile(r"^ARG\s+(\w+)(?:=.*)?$", re.MULTILINE | re.IGNORECASE)
# ENV NAME VALUE or ENV NAME=VALUE
_ENV_RE    = re.compile(r"^ENV\s+(\w+)[\s=]", re.MULTILINE | re.IGNORECASE)
# EXPOSE port
_EXPOSE_RE = re.compile(r"^EXPOSE\s+(\d+)", re.MULTILINE | re.IGNORECASE)
# LABEL key=value
_LABEL_RE  = re.compile(r"^LABEL\s+([\w.-]+)=", re.MULTILINE | re.IGNORECASE)


def _ln(content: str, pos: int) -> int:
    return content[:pos].count("\n") + 1


def parse_dockerfile(file_path: str, content: str) -> ParseResult:
    result = ParseResult(file_path=file_path, language="dockerfile")

    stage_count = 0
    for m in _FROM_RE.finditer(content):
        image = m.group(1)
        stage = m.group(2)
        stage_count += 1
        name = stage or f"stage{stage_count}"
        result.entities.append(EntityRecord(
            name=name, qualified_name=name, type="stage",
            kind=image,
            start_line=_ln(content, m.start()), end_line=_ln(content, m.start()),
            language="dockerfile",
        ))
        result.dependencies.append(DependencyRecord(
            path=image, type="from", line_number=_ln(content, m.start()),
            is_local=not image.startswith("scratch") and "/" not in image.split(":")[0],
        ))

    for m in _ARG_RE.finditer(content):
        result.entities.append(EntityRecord(
            name=m.group(1), qualified_name=m.group(1), type="arg",
            start_line=_ln(content, m.start()), end_line=_ln(content, m.start()),
            language="dockerfile",
        ))

    for m in _ENV_RE.finditer(content):
        result.entities.append(EntityRecord(
            name=m.group(1), qualified_name=m.group(1), type="env",
            start_line=_ln(content, m.start()), end_line=_ln(content, m.start()),
            language="dockerfile",
        ))

    for m in _EXPOSE_RE.finditer(content):
        result.entities.append(EntityRecord(
            name=m.group(1), qualified_name=m.group(1), type="port",
            start_line=_ln(content, m.start()), end_line=_ln(content, m.start()),
            language="dockerfile",
        ))

    return result
