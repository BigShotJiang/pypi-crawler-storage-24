"""Parser package for codectx."""

from .registry import parse_file
from .types import DependencyRecord, EntityRecord, ParseResult

__all__ = ["DependencyRecord", "EntityRecord", "ParseResult", "parse_file"]
