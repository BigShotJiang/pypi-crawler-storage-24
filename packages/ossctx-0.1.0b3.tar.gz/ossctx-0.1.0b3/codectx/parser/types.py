"""Shared parser data structures."""

from dataclasses import dataclass, field


@dataclass(slots=True)
class EntityRecord:
    name: str
    type: str
    qualified_name: str = ""
    kind: str = ""
    signature: str = ""
    start_line: int = 0
    end_line: int = 0
    column_start: int = 0
    column_end: int = 0
    docs: str = ""
    parent: str = ""
    visibility: str = ""
    scope: str = ""
    language: str = ""
    attributes: dict[str, object] = field(default_factory=dict)


@dataclass(slots=True)
class DependencyRecord:
    path: str
    type: str
    line_number: int = 0
    resolved: str = ""
    is_local: bool = False


@dataclass(slots=True)
class RelationRecord:
    source_qualified_name: str
    target_qualified_name: str
    relation_type: str
    line_number: int = 0
    context: str = ""


@dataclass(slots=True)
class ParseResult:
    file_path: str
    language: str
    entities: list[EntityRecord] = field(default_factory=list)
    dependencies: list[DependencyRecord] = field(default_factory=list)
    relations: list[RelationRecord] = field(default_factory=list)
