"""JSON parser — top-level keys as entities."""

from __future__ import annotations

import json as _json

from codectx.parser.types import EntityRecord, ParseResult


def parse_json(file_path: str, content: str) -> ParseResult:
    result = ParseResult(file_path=file_path, language="json")
    try:
        data = _json.loads(content)
    except _json.JSONDecodeError:
        return result

    if not isinstance(data, dict):
        return result

    for i, key in enumerate(data.keys()):
        result.entities.append(EntityRecord(
            name=str(key), qualified_name=str(key), type="key",
            start_line=1, end_line=1, language="json",
        ))

    return result
