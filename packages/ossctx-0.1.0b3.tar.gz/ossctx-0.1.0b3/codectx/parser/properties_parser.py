"""Java .properties file parser — key=value pairs."""

from __future__ import annotations

import re

from codectx.parser.types import EntityRecord, ParseResult

_PROP_RE = re.compile(r"^([^#!=\s][^=:]*?)\s*[=:]\s*(.*)", re.MULTILINE)


def _ln(content: str, pos: int) -> int:
    return content[:pos].count("\n") + 1


def parse_properties(file_path: str, content: str) -> ParseResult:
    result = ParseResult(file_path=file_path, language="properties")

    for m in _PROP_RE.finditer(content):
        key = m.group(1).strip()
        if not key:
            continue
        result.entities.append(EntityRecord(
            name=key, qualified_name=key, type="property",
            start_line=_ln(content, m.start()), end_line=_ln(content, m.start()),
            language="properties",
        ))

    return result
