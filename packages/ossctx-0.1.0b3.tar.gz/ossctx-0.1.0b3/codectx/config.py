"""Configuration for the code context subsystem."""

from pathlib import Path

from pydantic import Field

from common.config import BaseAppSettings


class CodeSettings(BaseAppSettings):
    """Settings for codectx."""

    db_path: Path = Field(default=Path(".codecontext.db"), alias="CODECTX_DB_PATH")
    host: str = Field(default="127.0.0.1", alias="CODECTX_HOST")
    port: int = Field(default=8080, alias="CODECTX_PORT")
    max_file_size_mb: int = Field(default=10, alias="CODECTX_MAX_FILE_SIZE_MB")
