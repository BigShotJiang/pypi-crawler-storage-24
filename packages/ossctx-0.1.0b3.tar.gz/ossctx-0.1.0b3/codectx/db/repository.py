"""Repository methods for code graph data."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path

from sqlalchemy import case, func, or_, select
from sqlalchemy.orm import aliased

from codectx.db.models import Dependency, Entity, EntityRelation, File
from codectx.parser.types import DependencyRecord, EntityRecord, RelationRecord
from common.db import Base, create_engine_with_wal, create_session_factory, session_scope


@dataclass(slots=True)
class CodeStats:
    files: int = 0
    entities: int = 0
    dependencies: int = 0
    relations: int = 0
    lines_of_code: int = 0
    tokens: int = 0

    def to_dict(self) -> dict[str, int]:
        return asdict(self)


class CodeRepository:
    """Persistence wrapper for codectx."""

    def __init__(self, db_path: str | Path, echo: bool = False) -> None:
        self.db_path = Path(db_path)
        self.engine = create_engine_with_wal(f"sqlite:///{self.db_path}", echo=echo)
        self.session_factory = create_session_factory(self.engine)

    def create_schema(self) -> None:
        Base.metadata.create_all(self.engine, tables=[File.__table__, Entity.__table__, Dependency.__table__, EntityRelation.__table__])

    def upsert_file(self, path: str, language: str, file_hash: str = "", lines_of_code: int = 0, tokens: int = 0) -> int:
        with session_scope(self.session_factory) as session:
            existing = session.scalar(select(File).where(File.path == path))
            if existing is None:
                file_row = File(path=path, language=language, hash=file_hash or None, lines_of_code=lines_of_code, tokens=tokens)
                session.add(file_row)
                session.flush()
                return file_row.id

            existing.language = language
            existing.hash = file_hash or None
            existing.lines_of_code = lines_of_code
            existing.tokens = tokens
            session.flush()
            return existing.id

    def file_needs_update(self, path: str, new_hash: str) -> bool:
        """Check if a file needs updating by comparing its current hash with the stored hash."""
        with session_scope(self.session_factory) as session:
            existing = session.scalar(select(File).where(File.path == path))
            if existing is None:
                return True  # New file
            if existing.hash != new_hash:
                return True  # File changed
            return False  # File unchanged

    def get_file_by_path(self, path: str) -> File | None:
        with session_scope(self.session_factory) as session:
            return session.scalar(select(File).where(File.path == path))

    def get_entities_by_name(self, name: str) -> list[Entity]:
        with session_scope(self.session_factory) as session:
            return list(
                session.scalars(
                    select(Entity)
                    .where(or_(Entity.name == name, Entity.qualified_name == name))
                    .order_by(Entity.file_id, Entity.start_line)
                )
            )

    def get_dependency_graph(self, path: str) -> dict[str, object] | None:
        with session_scope(self.session_factory) as session:
            file_row = session.scalar(select(File).where(File.path == path))
            if file_row is None:
                return None
            dependencies = list(
                session.scalars(
                    select(Dependency).where(Dependency.source_file_id == file_row.id).order_by(Dependency.line_number, Dependency.target_path)
                )
            )
            return {
                "file": file_row.path,
                "dependencies": [dependency.target_path for dependency in dependencies],
            }

    def get_call_graph(self, name: str) -> dict[str, object] | None:
        with session_scope(self.session_factory) as session:
            entity = session.scalar(
                select(Entity)
                .where(or_(Entity.name == name, Entity.qualified_name == name))
                .order_by(Entity.start_line)
            )
            if entity is None:
                return None

            source_entity = aliased(Entity)
            target_entity = aliased(Entity)
            outgoing_rows = session.execute(
                select(EntityRelation, target_entity)
                .join(target_entity, EntityRelation.target_entity_id == target_entity.id)
                .where(EntityRelation.source_entity_id == entity.id, EntityRelation.relation_type == "calls")
                .order_by(EntityRelation.line_number, target_entity.qualified_name, target_entity.name)
            )
            incoming_rows = session.execute(
                select(EntityRelation, source_entity)
                .join(source_entity, EntityRelation.source_entity_id == source_entity.id)
                .where(EntityRelation.target_entity_id == entity.id, EntityRelation.relation_type == "calls")
                .order_by(EntityRelation.line_number, source_entity.qualified_name, source_entity.name)
            )
            return {
                "entity": entity.qualified_name or entity.name,
                "outgoing": [
                    {
                        "target": target.qualified_name or target.name,
                        "line_number": relation.line_number,
                        "context": relation.context or "",
                    }
                    for relation, target in outgoing_rows
                ],
                "incoming": [
                    {
                        "source": source.qualified_name or source.name,
                        "line_number": relation.line_number,
                        "context": relation.context or "",
                    }
                    for relation, source in incoming_rows
                ],
            }

    def delete_entities_by_file(self, file_id: int) -> None:
        with session_scope(self.session_factory) as session:
            for entity in session.scalars(select(Entity).where(Entity.file_id == file_id)):
                session.delete(entity)

    def delete_dependencies_by_file(self, file_id: int) -> None:
        with session_scope(self.session_factory) as session:
            for dependency in session.scalars(select(Dependency).where(Dependency.source_file_id == file_id)):
                session.delete(dependency)

    def delete_relations_by_file(self, file_id: int) -> None:
        with session_scope(self.session_factory) as session:
            entity_ids = list(session.scalars(select(Entity.id).where(Entity.file_id == file_id)))
            if not entity_ids:
                return
            for relation in session.scalars(
                select(EntityRelation).where(
                    or_(EntityRelation.source_entity_id.in_(entity_ids), EntityRelation.target_entity_id.in_(entity_ids))
                )
            ):
                session.delete(relation)

    def insert_entity(self, file_id: int, entity: EntityRecord) -> int:
        with session_scope(self.session_factory) as session:
            row = Entity(
                file_id=file_id,
                name=entity.name,
                qualified_name=entity.qualified_name or None,
                type=entity.type,
                kind=entity.kind or None,
                signature=entity.signature or None,
                start_line=entity.start_line,
                end_line=entity.end_line,
                column_start=entity.column_start,
                column_end=entity.column_end,
                documentation=entity.docs or None,
                parent=entity.parent or None,
                visibility=entity.visibility or None,
                scope=entity.scope or None,
                language=entity.language or None,
                attributes=None,
            )
            session.add(row)
            session.flush()
            return row.id

    def insert_dependency(self, file_id: int, dependency: DependencyRecord) -> int:
        with session_scope(self.session_factory) as session:
            row = Dependency(
                source_file_id=file_id,
                target_path=dependency.path,
                import_type=dependency.type or None,
                line_number=dependency.line_number,
                resolved=dependency.resolved or None,
                is_local=dependency.is_local,
            )
            session.add(row)
            session.flush()
            return row.id

    def insert_relation(self, file_id: int, relation: RelationRecord) -> int | None:
        with session_scope(self.session_factory) as session:
            source = session.scalar(
                select(Entity)
                .where(
                    Entity.file_id == file_id,
                    or_(Entity.qualified_name == relation.source_qualified_name, Entity.name == relation.source_qualified_name),
                )
                .order_by(Entity.start_line)
            )
            if source is None:
                return None

            target = self._resolve_target_entity(session, file_id, relation.target_qualified_name)
            if target is None:
                return None

            row = EntityRelation(
                source_entity_id=source.id,
                target_entity_id=target.id,
                relation_type=relation.relation_type,
                line_number=relation.line_number,
                context=relation.context or None,
            )
            session.add(row)
            session.flush()
            return row.id

    def _resolve_target_entity(self, session, file_id: int, target_name: str) -> Entity | None:
        module_hint, _, symbol_name = target_name.rpartition(".")
        fallback_symbol = symbol_name or target_name

        imported_file_ids: list[int] = []
        if module_hint:
            imported_file_ids = self._resolve_imported_file_ids(session, file_id, module_hint)
            if imported_file_ids:
                target = session.scalar(
                    select(Entity)
                    .where(
                        Entity.file_id.in_(imported_file_ids),
                        or_(
                            Entity.qualified_name == target_name,
                            Entity.name == fallback_symbol,
                            Entity.qualified_name == fallback_symbol,
                        ),
                    )
                    .order_by(Entity.start_line.asc())
                )
                if target is not None:
                    return target

        prefer_same_file = case((Entity.file_id == file_id, 0), else_=1)
        prefer_exact_qualified = case((Entity.qualified_name == target_name, 0), else_=1)
        return session.scalar(
            select(Entity)
            .where(or_(Entity.qualified_name == target_name, Entity.name == fallback_symbol, Entity.name == target_name))
            .order_by(prefer_exact_qualified.asc(), prefer_same_file.asc(), Entity.start_line.asc())
        )

    def _resolve_imported_file_ids(self, session, file_id: int, module_hint: str) -> list[int]:
        dependency_rows = list(session.scalars(select(Dependency).where(Dependency.source_file_id == file_id)))
        matched_paths = []
        normalized_hint = module_hint.strip(".")
        hint_tail = normalized_hint.rsplit(".", 1)[-1]
        for dependency in dependency_rows:
            dependency_module = (dependency.target_path or "").strip(".")
            dependency_tail = dependency_module.rsplit(".", 1)[-1] if dependency_module else ""
            if normalized_hint in {dependency_module, dependency_tail} or dependency_module.endswith(f".{normalized_hint}"):
                if dependency.resolved:
                    matched_paths.append(dependency.resolved)

        if not matched_paths:
            return []

        return list(
            session.scalars(select(File.id).where(File.path.in_(matched_paths)))
        )

    def list_files(self, limit: int = 100, offset: int = 0) -> list[dict[str, object]]:
        with session_scope(self.session_factory) as session:
            rows = list(
                session.scalars(
                    select(File).order_by(File.path).limit(limit).offset(offset)
                )
            )
            return [
                {
                    "id": row.id,
                    "path": row.path,
                    "language": row.language,
                    "lines_of_code": row.lines_of_code,
                    "tokens": row.tokens,
                }
                for row in rows
            ]

    def search_entities(self, query: str, limit: int = 20) -> list[dict[str, object]]:
        with session_scope(self.session_factory) as session:
            pattern = f"%{query}%"
            rows = list(
                session.scalars(
                    select(Entity)
                    .where(
                        or_(
                            Entity.name.ilike(pattern),
                            Entity.qualified_name.ilike(pattern),
                        )
                    )
                    .order_by(Entity.name, Entity.start_line)
                    .limit(limit)
                )
            )
            return [
                {
                    "id": row.id,
                    "name": row.name,
                    "qualified_name": row.qualified_name,
                    "type": row.type,
                    "kind": row.kind,
                    "file_id": row.file_id,
                    "start_line": row.start_line,
                    "end_line": row.end_line,
                    "documentation": row.documentation,
                    "language": row.language,
                }
                for row in rows
            ]

    def get_entity_by_id(self, entity_id: int) -> dict[str, object] | None:
        with session_scope(self.session_factory) as session:
            row = session.get(Entity, entity_id)
            if row is None:
                return None
            return {
                "id": row.id,
                "name": row.name,
                "qualified_name": row.qualified_name,
                "type": row.type,
                "kind": row.kind,
                "signature": row.signature,
                "file_id": row.file_id,
                "start_line": row.start_line,
                "end_line": row.end_line,
                "documentation": row.documentation,
                "visibility": row.visibility,
                "scope": row.scope,
                "language": row.language,
                "parent": row.parent,
            }

    def get_entity_code(self, entity_id: int, source_root: str = ".") -> dict[str, object] | None:
        """Return the source lines for an entity, reading from disk."""
        with session_scope(self.session_factory) as session:
            entity = session.get(Entity, entity_id)
            if entity is None:
                return None
            file_row = session.get(File, entity.file_id)
            if file_row is None:
                return None

            file_path = Path(source_root) / file_row.path if not Path(file_row.path).is_absolute() else Path(file_row.path)
            code = ""
            if file_path.exists():
                try:
                    lines = file_path.read_text(encoding="utf-8", errors="replace").splitlines()
                    start = max(0, (entity.start_line or 1) - 1)
                    end = min(len(lines), entity.end_line or len(lines))
                    code = "\n".join(lines[start:end])
                except OSError:
                    code = ""

            return {
                "entity_id": entity_id,
                "name": entity.name,
                "qualified_name": entity.qualified_name,
                "file": file_row.path,
                "start_line": entity.start_line,
                "end_line": entity.end_line,
                "code": code,
            }

    def get_file_imports(self, file_path: str) -> list[dict[str, object]]:
        with session_scope(self.session_factory) as session:
            file_row = session.scalar(select(File).where(File.path == file_path))
            if file_row is None:
                return []
            rows = list(
                session.scalars(
                    select(Dependency)
                    .where(Dependency.source_file_id == file_row.id)
                    .order_by(Dependency.line_number, Dependency.target_path)
                )
            )
            return [
                {
                    "target_path": row.target_path,
                    "import_type": row.import_type,
                    "line_number": row.line_number,
                    "resolved": row.resolved,
                    "is_local": row.is_local,
                }
                for row in rows
            ]

    def get_file_entities(self, file_path: str) -> list[dict[str, object]]:
        with session_scope(self.session_factory) as session:
            file_row = session.scalar(select(File).where(File.path == file_path))
            if file_row is None:
                return []
            rows = list(
                session.scalars(
                    select(Entity)
                    .where(Entity.file_id == file_row.id)
                    .order_by(Entity.start_line)
                )
            )
            return [
                {
                    "id": row.id,
                    "name": row.name,
                    "qualified_name": row.qualified_name,
                    "type": row.type,
                    "kind": row.kind,
                    "start_line": row.start_line,
                    "end_line": row.end_line,
                    "documentation": row.documentation,
                    "visibility": row.visibility,
                }
                for row in rows
            ]

    def get_stats(self) -> CodeStats:
        with session_scope(self.session_factory) as session:
            file_count = session.scalar(select(func.count()).select_from(File)) or 0
            entity_count = session.scalar(select(func.count()).select_from(Entity)) or 0
            dependency_count = session.scalar(select(func.count()).select_from(Dependency)) or 0
            relation_count = session.scalar(select(func.count()).select_from(EntityRelation)) or 0
            lines_of_code = session.scalar(select(func.coalesce(func.sum(File.lines_of_code), 0))) or 0
            tokens = session.scalar(select(func.coalesce(func.sum(File.tokens), 0))) or 0
            return CodeStats(
                files=int(file_count),
                entities=int(entity_count),
                dependencies=int(dependency_count),
                relations=int(relation_count),
                lines_of_code=int(lines_of_code),
                tokens=int(tokens),
            )

    # ------------------------------------------------------------------
    # Batch query methods
    # ------------------------------------------------------------------

    def get_file_entity_counts(self, file_ids: list[int]) -> dict[int, int]:
        """Return {file_id: entity_count} for the given file IDs."""
        if not file_ids:
            return {}
        with session_scope(self.session_factory) as session:
            rows = session.execute(
                select(Entity.file_id, func.count(Entity.id))
                .where(Entity.file_id.in_(file_ids))
                .group_by(Entity.file_id)
            )
            return {file_id: int(count) for file_id, count in rows}

    def get_importers_of_file(self, file_path: str) -> list[dict[str, object]]:
        """Return files that import the given file path."""
        with session_scope(self.session_factory) as session:
            rows = session.execute(
                select(File, Dependency)
                .join(Dependency, Dependency.source_file_id == File.id)
                .where(or_(Dependency.target_path == file_path, Dependency.resolved == file_path))
                .order_by(File.path)
            )
            return [
                {
                    "file_id": file_row.id,
                    "path": file_row.path,
                    "language": file_row.language,
                    "import_type": dep_row.import_type,
                    "line_number": dep_row.line_number,
                }
                for file_row, dep_row in rows
            ]

    def get_entities_by_file_ids(self, file_ids: list[int]) -> list[dict[str, object]]:
        """Return all entities for a set of file IDs."""
        if not file_ids:
            return []
        with session_scope(self.session_factory) as session:
            rows = list(session.scalars(
                select(Entity)
                .where(Entity.file_id.in_(file_ids))
                .order_by(Entity.file_id, Entity.start_line)
            ))
            return [
                {
                    "id": row.id,
                    "file_id": row.file_id,
                    "name": row.name,
                    "qualified_name": row.qualified_name,
                    "type": row.type,
                    "kind": row.kind,
                    "start_line": row.start_line,
                    "end_line": row.end_line,
                }
                for row in rows
            ]

    def get_dependencies_by_file_ids(self, file_ids: list[int]) -> list[dict[str, object]]:
        """Return all dependencies for a set of file IDs."""
        if not file_ids:
            return []
        with session_scope(self.session_factory) as session:
            rows = list(session.scalars(
                select(Dependency)
                .where(Dependency.source_file_id.in_(file_ids))
                .order_by(Dependency.source_file_id, Dependency.line_number)
            ))
            return [
                {
                    "file_id": row.source_file_id,
                    "target_path": row.target_path,
                    "import_type": row.import_type,
                    "line_number": row.line_number,
                    "resolved": row.resolved,
                    "is_local": row.is_local,
                }
                for row in rows
            ]

    def get_relations_by_entity_ids(self, entity_ids: list[int]) -> list[dict[str, object]]:
        """Return all relations where source or target is in entity_ids."""
        if not entity_ids:
            return []
        with session_scope(self.session_factory) as session:
            rows = list(session.scalars(
                select(EntityRelation)
                .where(
                    or_(
                        EntityRelation.source_entity_id.in_(entity_ids),
                        EntityRelation.target_entity_id.in_(entity_ids),
                    )
                )
                .order_by(EntityRelation.source_entity_id, EntityRelation.line_number)
            ))
            return [
                {
                    "id": row.id,
                    "source_entity_id": row.source_entity_id,
                    "target_entity_id": row.target_entity_id,
                    "relation_type": row.relation_type,
                    "line_number": row.line_number,
                    "context": row.context,
                }
                for row in rows
            ]

    def get_entities_by_ids(self, entity_ids: list[int]) -> list[dict[str, object]]:
        """Return entities for a list of entity IDs."""
        if not entity_ids:
            return []
        with session_scope(self.session_factory) as session:
            rows = list(session.scalars(
                select(Entity).where(Entity.id.in_(entity_ids)).order_by(Entity.id)
            ))
            return [
                {
                    "id": row.id,
                    "name": row.name,
                    "qualified_name": row.qualified_name,
                    "type": row.type,
                    "kind": row.kind,
                    "file_id": row.file_id,
                    "start_line": row.start_line,
                    "end_line": row.end_line,
                    "documentation": row.documentation,
                    "visibility": row.visibility,
                    "language": row.language,
                }
                for row in rows
            ]

    def get_directory_tree(self, root_prefix: str = "") -> dict[str, object]:
        """Return a nested directory tree of all indexed files."""
        with session_scope(self.session_factory) as session:
            rows = list(session.scalars(select(File).order_by(File.path)))
        tree: dict[str, object] = {}
        for file_row in rows:
            path = file_row.path
            if root_prefix and not path.startswith(root_prefix):
                continue
            parts = path.replace("\\", "/").split("/")
            node = tree
            for part in parts[:-1]:
                node = node.setdefault(part, {})  # type: ignore[assignment]
            filename = parts[-1]
            node[filename] = {
                "id": file_row.id,
                "language": file_row.language,
                "lines_of_code": file_row.lines_of_code,
            }
        return tree

    def get_file_by_id(self, file_id: int) -> dict | None:
        """Return a single file record by its primary key."""
        with session_scope(self.session_factory) as session:
            row = session.get(File, file_id)
            if row is None:
                return None
            return {
                "id": row.id,
                "path": row.path,
                "language": row.language,
                "hash": row.hash,
                "lines_of_code": row.lines_of_code,
                "tokens": row.tokens,
            }

    def get_all_entities(self, limit: int = 1000) -> list[dict]:
        """Return up to *limit* entity records across all files."""
        with session_scope(self.session_factory) as session:
            rows = list(session.scalars(select(Entity).order_by(Entity.id).limit(limit)))
            return [
                {
                    "id": row.id,
                    "name": row.name,
                    "qualified_name": row.qualified_name,
                    "type": row.type,
                    "kind": row.kind,
                    "file_id": row.file_id,
                    "start_line": row.start_line,
                    "end_line": row.end_line,
                    "documentation": row.documentation,
                    "visibility": row.visibility,
                    "language": row.language,
                }
                for row in rows
            ]

    def get_all_dependencies(self, limit: int = 1000) -> list[dict]:
        """Return up to *limit* dependency records across all files."""
        with session_scope(self.session_factory) as session:
            rows = list(session.scalars(select(Dependency).order_by(Dependency.id).limit(limit)))
            return [
                {
                    "id": row.id,
                    "source_file_id": row.source_file_id,
                    "target_path": row.target_path,
                    "import_type": row.import_type,
                    "line_number": row.line_number,
                    "resolved": row.resolved,
                    "is_local": row.is_local,
                }
                for row in rows
            ]

    def get_all_relations(self, limit: int = 1000) -> list[dict]:
        """Return up to *limit* entity-relation records across all files."""
        with session_scope(self.session_factory) as session:
            rows = list(session.scalars(select(EntityRelation).order_by(EntityRelation.id).limit(limit)))
            return [
                {
                    "id": row.id,
                    "source_entity_id": row.source_entity_id,
                    "target_entity_id": row.target_entity_id,
                    "relation_type": row.relation_type,
                    "line_number": row.line_number,
                }
                for row in rows
            ]
