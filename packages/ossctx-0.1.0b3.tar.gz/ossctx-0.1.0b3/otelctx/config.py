"""Configuration for the otel context subsystem."""

from pathlib import Path

from pydantic import Field

from common.config import BaseAppSettings


class OtelSettings(BaseAppSettings):
    """Settings for otelctx."""

    # Core
    db_path: Path = Field(default=Path(".otelcontext.db"), alias="OTELCTX_DB_PATH")
    host: str = Field(default="127.0.0.1", alias="OTELCTX_HOST")
    port: int = Field(default=8088, alias="OTELCTX_PORT")
    grpc_port: int = Field(default=4317, alias="OTELCTX_GRPC_PORT")

    # Archive / retention
    hot_days: int = Field(default=7, alias="OTELCTX_HOT_DAYS")
    cold_days: int = Field(default=90, alias="OTELCTX_COLD_DAYS")
    archive_dir: Path = Field(default=Path(".otel_archive"), alias="OTELCTX_ARCHIVE_DIR")

    # In-memory TSDB
    tsdb_capacity: int = Field(default=10_000, alias="OTELCTX_TSDB_CAPACITY")
    tsdb_window_seconds: float = Field(default=60.0, alias="OTELCTX_TSDB_WINDOW_SECONDS")
    tsdb_cardinality_limit: int = Field(default=1_000, alias="OTELCTX_TSDB_CARDINALITY_LIMIT")

    # Adaptive sampling
    sampling_rate: float = Field(default=1.0, alias="OTELCTX_SAMPLING_RATE")
    sampling_always_errors: bool = Field(default=True, alias="OTELCTX_SAMPLING_ALWAYS_ERRORS")
    sampling_latency_threshold_ms: float = Field(default=1000.0, alias="OTELCTX_SAMPLING_LATENCY_THRESHOLD_MS")

    # Dead-letter queue
    dlq_max_retries: int = Field(default=5, alias="OTELCTX_DLQ_MAX_RETRIES")
    dlq_replay_interval_seconds: float = Field(default=60.0, alias="OTELCTX_DLQ_REPLAY_INTERVAL_SECONDS")

    # WebSocket / real-time
    ws_buffer_size: int = Field(default=100, alias="OTELCTX_WS_BUFFER_SIZE")
    ws_flush_interval_ms: int = Field(default=500, alias="OTELCTX_WS_FLUSH_INTERVAL_MS")

    # Prometheus
    prometheus_enabled: bool = Field(default=False, alias="OTELCTX_PROMETHEUS_ENABLED")

    # AI / embedding (optional)
    ai_enabled: bool = Field(default=False, alias="OTELCTX_AI_ENABLED")
    ai_azure_endpoint: str = Field(default="", alias="OTELCTX_AI_AZURE_ENDPOINT")
    ai_azure_key: str = Field(default="", alias="OTELCTX_AI_AZURE_KEY")

    # Signal filters
    min_severity: str = Field(default="", alias="OTELCTX_MIN_SEVERITY")
    allowed_services: str = Field(default="", alias="OTELCTX_ALLOWED_SERVICES")
    excluded_services: str = Field(default="", alias="OTELCTX_EXCLUDED_SERVICES")
