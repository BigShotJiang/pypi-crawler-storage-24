"""HireKit — AI-powered company analysis and interview preparation CLI."""

__version__ = "0.1.0"
