from setuptools import setup, find_packages

setup(
    name="flowproxy",
    version="0.3.2",
    packages=find_packages(),  # this will now include flowproxy.cli
    install_requires=[
        "PyYAML>=6.0",
        "pydantic>=2.0",
        "typer[all]",
        "uvicorn",
        "fastapi",
        "httpx"
    ],
    entry_points={
        "console_scripts": [
            "flowproxy=flowproxy.cli.main:app",  # updated path
        ],
    },
    python_requires=">=3.10",
    author="Daksh Tiwari",
    description="FlowProxy: Config-driven proxy and orchestrator starter package",
    url="https://github.com/daksh2916/flowproxy",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)