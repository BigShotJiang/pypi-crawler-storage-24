#!/usr/bin/env python3
"""
AdvisorFinder CLI

Search SEC-registered financial advisors from the terminal.

Usage:
    advisorfinder search "Joseph Montgomery" --state VA
    advisorfinder lookup 3034796
    advisorfinder verify 3034796
    advisorfinder firm 133640
    advisorfinder stats
    advisorfinder disclosures --type customer_complaint --state CA
"""

import json
import socket
import sys
import urllib.error
import urllib.parse
import urllib.request
from enum import Enum
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="advisorfinder",
    help="Search SEC-registered financial advisors. Data from SEC IAPD.",
    no_args_is_help=True,
)


class DisclosureType(str, Enum):
    customer_complaint = "customer_complaint"
    regulatory = "regulatory"
    criminal = "criminal"
    termination = "termination"
    bankruptcy = "bankruptcy"
    civil = "civil"
    bond = "bond"
    judgment = "judgment"
    investigation = "investigation"
console = Console()
err_console = Console(stderr=True)


@app.callback()
def _main():
    """AdvisorFinder CLI — search SEC-registered financial advisors."""

API_BASE = "https://sec-advisor-project.vercel.app/api/index"
TIMEOUT = 30

# ---------------------------------------------------------------------------
# Risk scoring (bundled — no external dependency)
# ---------------------------------------------------------------------------

_RISK_WEIGHTS = {
    "has_criminal": 50,
    "has_regulatory_action": 30,
    "has_customer_complaint": 25,
    "has_termination": 20,
    "has_civil_judicial": 15,
    "has_judgment": 15,
    "has_investigation": 10,
    "has_bankruptcy": 10,
    "has_bond": 5,
}

_RISK_COLORS = {
    "Clean": "green",
    "Low": "yellow",
    "Medium": "dark_orange",
    "High": "red",
    "Very High": "red bold",
}


def _calc_score(disclosures: dict) -> int:
    return sum(w for f, w in _RISK_WEIGHTS.items() if disclosures.get(f))


def _get_level(score: int) -> str:
    if score == 0:
        return "Clean"
    if score <= 10:
        return "Low"
    if score <= 30:
        return "Medium"
    if score <= 60:
        return "High"
    return "Very High"


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def api_get(endpoint: str) -> dict:
    """GET request to the AdvisorFinder API. Returns dict (may contain 'error' key)."""
    url = f"{API_BASE}{endpoint}"
    try:
        with urllib.request.urlopen(url, timeout=TIMEOUT) as response:
            return json.loads(response.read().decode())
    except urllib.error.HTTPError as e:
        if e.code == 429:
            return {"error": "rate_limited", "message": "API rate limit reached. Please wait a moment and try again."}
        return {"error": f"http_{e.code}", "message": f"API error {e.code}. Try again shortly."}
    except (urllib.error.URLError, socket.timeout, OSError) as e:
        return {"error": "network", "message": f"Network error: {e}. Check your connection."}
    except (json.JSONDecodeError, ValueError):
        return {"error": "parse", "message": "Unexpected API response. Check your connection."}


def _handle_error(result: dict, json_output: bool) -> None:
    """Print error and exit 1."""
    msg = result.get("message", result.get("error", "Unknown error"))
    if json_output:
        typer.echo(json.dumps({"error": msg}))
    else:
        err_console.print(f"[red]Error:[/red] {msg}")
    raise typer.Exit(1)


@app.command()
def stats(
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON"),
):
    """Show database statistics — total advisors, firms, disclosure rates."""
    data = api_get("/stats")
    if "error" in data:
        _handle_error(data, json_output)

    if json_output:
        typer.echo(json.dumps(data, indent=2))
        return

    table = Table(title="AdvisorFinder Database Stats", box=box.ROUNDED)
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")

    table.add_row("Total Advisors", f"{data.get('total_advisors', 0):,}")
    table.add_row("Active Advisors", f"{data.get('active_advisors', 0):,}")
    table.add_row("Total Firms", f"{data.get('total_firms', 0):,}")
    table.add_row("", "")
    table.add_row("With Customer Complaints", f"{data.get('with_complaints', 0):,}")
    table.add_row("With Criminal History", f"{data.get('with_criminal', 0):,}")
    table.add_row("With Regulatory Actions", f"{data.get('with_regulatory', 0):,}")

    console.print(table)

    top = data.get("top_states", [])
    if top:
        state_table = Table(title="Top States by Advisor Count", box=box.SIMPLE)
        state_table.add_column("State")
        state_table.add_column("Advisors", justify="right")
        for s in top:
            state_table.add_row(s.get("state", ""), f"{s.get('count', 0):,}")
        console.print(state_table)


@app.command()
def search(
    name: Optional[str] = typer.Argument(None, help="Full name or last name (e.g. 'Joseph Montgomery')"),
    state: Optional[str] = typer.Option(None, "--state", help="Two-letter state code (e.g. VA)"),
    firm: Optional[str] = typer.Option(None, "--firm", help="Firm name (partial match)"),
    limit: int = typer.Option(20, "--limit", min=1, max=200, help="Max results"),
    active_only: bool = typer.Option(False, "--active-only", help="Only active registrations"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON"),
):
    """Search for advisors by name, state, or firm."""
    if not name and not state and not firm:
        err_console.print("[red]Error:[/red] Provide at least one of: NAME, --state, --firm")
        raise typer.Exit(1)

    params = []
    if name:
        parts = name.strip().split()
        if len(parts) >= 2:
            params.append(f"first_name={urllib.parse.quote(parts[0])}")
            params.append(f"last_name={urllib.parse.quote(' '.join(parts[1:]))}")
        else:
            params.append(f"q={urllib.parse.quote(name)}")
    if state:
        params.append(f"state={urllib.parse.quote(state.upper())}")
    if firm:
        params.append(f"firm={urllib.parse.quote(firm)}")
    if active_only:
        params.append("active_only=true")
    params.append(f"limit={limit}")

    data = api_get(f"/search?{'&'.join(params)}")
    if "error" in data:
        _handle_error(data, json_output)

    advisors = data.get("advisors", [])

    if json_output:
        typer.echo(json.dumps(data, indent=2))
        return

    if not advisors:
        console.print("[yellow]No results found in SEC IAPD database.[/yellow]")
        name_q = urllib.parse.quote(name or "")
        console.print(f"\nTry searching directly:")
        console.print(f"  BrokerCheck: https://brokercheck.finra.org/search?query={name_q}")
        console.print(f"  SEC IAPD:    https://adviserinfo.sec.gov/search/genericsearch/gridCurrent498?query={name_q}")
        return

    table = Table(box=box.ROUNDED, show_header=True)
    table.add_column("CRD", style="dim", width=10)
    table.add_column("Name", min_width=20)
    table.add_column("Status", width=10)
    table.add_column("Firm", min_width=25)
    table.add_column("Location", min_width=15)
    table.add_column("Disclosures", width=12)

    for a in advisors:
        name_str = f"{a.get('first_name', '')} {a.get('last_name', '')}".strip()
        active = a.get("active_registration")
        status = "[green]Active[/green]" if active else "[dim]Inactive[/dim]"
        has_disc = any([a.get("has_customer_complaint"), a.get("has_regulatory_action"), a.get("has_criminal")])
        disc_str = "[red]Yes[/red]" if has_disc else "[green]None[/green]"
        location = f"{a.get('city', '')}, {a.get('state', '')}".strip(", ")
        table.add_row(
            str(a.get("crd_number", "")),
            name_str,
            status,
            a.get("firm_name") or "—",
            location or "—",
            disc_str,
        )

    console.print(table)
    console.print(f"[dim]{len(advisors)} result(s) — use [bold]advisorfinder lookup <CRD>[/bold] for full profile[/dim]")


@app.command()
def lookup(
    crd: int = typer.Argument(..., help="Advisor CRD number"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON"),
):
    """Full profile for an advisor by CRD number."""
    data = api_get(f"/advisor/{crd}")

    if "error" in data or "advisor" not in data:
        if json_output:
            typer.echo(json.dumps({
                "found": False, "crd_number": crd,
                "brokercheck": f"https://brokercheck.finra.org/individual/summary/{crd}",
                "sec_iapd": f"https://adviserinfo.sec.gov/individual/summary/{crd}",
            }, indent=2))
        else:
            console.print(f"[red]Advisor CRD {crd} not found in our database.[/red]")
            console.print(f"\nCheck official sources:")
            console.print(f"  BrokerCheck: https://brokercheck.finra.org/individual/summary/{crd}")
            console.print(f"  SEC IAPD:    https://adviserinfo.sec.gov/individual/summary/{crd}")
        raise typer.Exit(1)

    advisor = data["advisor"]
    score = _calc_score(advisor)
    level = _get_level(score)
    risk_color = _RISK_COLORS.get(level, "white")

    # Compute years of experience from earliest exam or employment date
    earliest_year = None
    for exam in data.get("exams", []):
        if exam.get("exam_date"):
            try:
                y = int(exam["exam_date"][:4])
                if earliest_year is None or y < earliest_year:
                    earliest_year = y
            except (ValueError, IndexError):
                pass
    for emp in data.get("employment_history", []):
        if emp.get("from_date"):
            try:
                parts = emp["from_date"].split("/")
                y = int(parts[-1]) if len(parts) >= 2 else int(parts[0])
                if earliest_year is None or y < earliest_year:
                    earliest_year = y
            except (ValueError, IndexError):
                pass

    from datetime import date
    years_exp = (date.today().year - earliest_year) if earliest_year else None

    registered_states = sorted(set(
        r["registration_authority"] for r in data.get("registrations", [])
        if r.get("status") in ("APPROVED", "ACTIVE", "CURRENT")
    ))

    if json_output:
        typer.echo(json.dumps({
            "found": True,
            "crd_number": crd,
            "name": f"{advisor.get('first_name', '')} {advisor.get('last_name', '')}".strip(),
            "active": advisor.get("active_registration"),
            "firm": advisor.get("firm_name"),
            "firm_crd": advisor.get("firm_crd"),
            "location": f"{advisor.get('city', '')}, {advisor.get('state', '')}".strip(", "),
            "years_experience": years_exp,
            "earliest_record_year": earliest_year,
            "designations": [d.get("designation") for d in data.get("designations", [])],
            "exams": data.get("exams", []),
            "employment_history": data.get("employment_history", []),
            "registered_states": registered_states,
            "other_business": data.get("other_business", []),
            "disclosures": {k: advisor.get(k) for k in _RISK_WEIGHTS},
            "risk_score": score,
            "risk_level": level,
            "links": {
                "sec": f"https://adviserinfo.sec.gov/individual/summary/{crd}",
                "brokercheck": f"https://brokercheck.finra.org/individual/summary/{crd}",
            },
        }, indent=2))
        return

    # Pretty output
    active = advisor.get("active_registration")
    status_str = "[green]● ACTIVE[/green]" if active else "[red]● INACTIVE[/red]"
    firm_str = f"{advisor.get('firm_name', '—')}  [dim](CRD {advisor.get('firm_crd', '?')})[/dim]"
    location = f"{advisor.get('city', '')}, {advisor.get('state', '')}".strip(", ") or "—"
    full_name = f"{advisor.get('first_name', '')} {advisor.get('last_name', '')}".strip()

    header = (
        f"[bold]{full_name}[/bold]  [dim]CRD #{crd}[/dim]\n"
        f"Status:  {status_str}\n"
        f"Firm:    {firm_str}\n"
        f"Office:  {location}\n"
        f"Risk:    [{risk_color}]● {level}[/{risk_color}]  [dim](score: {score})[/dim]"
    )
    if years_exp:
        header += f"\nExp:     {years_exp} years  [dim](since {earliest_year})[/dim]"

    console.print(Panel(header, expand=False))

    designations = [d.get("designation") for d in data.get("designations", []) if d.get("designation")]
    if designations:
        console.print(f"\n[bold]Designations[/bold]  {' · '.join(designations)}")

    exams = data.get("exams", [])
    if exams:
        console.print("\n[bold]Exams[/bold]")
        for e in exams:
            console.print(f"  {e.get('exam_name', '?'):<20} [dim]{e.get('exam_date', '')}[/dim]")

    emp_history = data.get("employment_history", [])
    if emp_history:
        console.print("\n[bold]Employment History[/bold]")
        t = Table(box=box.SIMPLE, show_header=False, padding=(0, 1))
        t.add_column("Firm", min_width=30)
        t.add_column("From", style="dim", width=10)
        t.add_column("To", style="dim", width=10)
        for e in emp_history:
            to_str = e.get("to_date") or "Present"
            t.add_row(e.get("org_name", "?"), e.get("from_date", ""), to_str)
        console.print(t)

    if registered_states:
        console.print(f"\n[bold]Registered States ({len(registered_states)})[/bold]")
        console.print("  " + "  ".join(registered_states))

    other = data.get("other_business", [])
    if other:
        console.print("\n[bold]Outside Business Activities[/bold]")
        for o in other:
            console.print(f"  • {o}")

    console.print(f"\n[dim]🔗 SEC:        https://adviserinfo.sec.gov/individual/summary/{crd}[/dim]")
    console.print(f"[dim]🔗 BrokerCheck: https://brokercheck.finra.org/individual/summary/{crd}[/dim]")


@app.command()
def verify(
    crd: int = typer.Argument(..., help="Advisor CRD number"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON"),
):
    """Quick check — active status, disclosures, risk score."""
    data = api_get(f"/advisor/{crd}")

    if "error" in data or "advisor" not in data:
        if json_output:
            typer.echo(json.dumps({"verified": False, "crd_number": crd}, indent=2))
        else:
            console.print(f"[red]Advisor CRD {crd} not found.[/red]")
            console.print(f"  BrokerCheck: https://brokercheck.finra.org/individual/summary/{crd}")
            console.print(f"  SEC IAPD:    https://adviserinfo.sec.gov/individual/summary/{crd}")
        raise typer.Exit(1)

    advisor = data["advisor"]
    score = _calc_score(advisor)
    level = _get_level(score)
    risk_color = _RISK_COLORS.get(level, "white")
    active = bool(advisor.get("active_registration"))

    disclosure_types = [
        label for flag, label in [
            ("has_criminal", "Criminal"),
            ("has_regulatory_action", "Regulatory Action"),
            ("has_customer_complaint", "Customer Complaint"),
            ("has_termination", "Termination"),
            ("has_bankruptcy", "Bankruptcy"),
        ] if advisor.get(flag)
    ]

    if json_output:
        typer.echo(json.dumps({
            "verified": True,
            "crd_number": crd,
            "name": f"{advisor.get('first_name', '')} {advisor.get('last_name', '')}".strip(),
            "active": active,
            "status": "ACTIVE" if active else "INACTIVE",
            "current_firm": advisor.get("firm_name"),
            "state": advisor.get("state"),
            "has_disclosures": len(disclosure_types) > 0,
            "disclosure_types": disclosure_types,
            "risk_score": score,
            "risk_level": level,
            "sec_link": f"https://adviserinfo.sec.gov/individual/summary/{crd}",
            "brokercheck_link": f"https://brokercheck.finra.org/individual/summary/{crd}",
        }, indent=2))
        return

    full_name = f"{advisor.get('first_name', '')} {advisor.get('last_name', '')}".strip()
    status_str = "[green]● ACTIVE[/green]" if active else "[red]● INACTIVE[/red]"
    disc_str = (
        f"[red]{', '.join(disclosure_types)}[/red]"
        if disclosure_types
        else "[green]None[/green]"
    )

    content = (
        f"[bold]{full_name}[/bold]  [dim]CRD #{crd}[/dim]\n"
        f"Status:      {status_str}\n"
        f"Firm:        {advisor.get('firm_name', '—')}\n"
        f"State:       {advisor.get('state', '—')}\n"
        f"Risk:        [{risk_color}]{level}[/{risk_color}]  [dim](score: {score})[/dim]\n"
        f"Disclosures: {disc_str}"
    )
    console.print(Panel(content, title="Advisor Verification", expand=False))


@app.command()
def firm(
    firm_crd: int = typer.Argument(..., help="Firm CRD number"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON"),
):
    """Firm overview — advisor count, location, disclosure stats."""
    data = api_get(f"/firm/{firm_crd}")

    if "error" in data or "firm" not in data:
        if json_output:
            typer.echo(json.dumps({"found": False, "firm_crd": firm_crd}, indent=2))
        else:
            console.print(f"[red]Firm CRD {firm_crd} not found.[/red]")
            console.print(f"  SEC: https://adviserinfo.sec.gov/Firm/{firm_crd}")
        raise typer.Exit(1)

    f = data["firm"]
    stats = data.get("disclosure_stats", {})
    total = f.get("advisor_count", 0)
    with_complaints = stats.get("with_complaints", 0)
    disc_rate = f"{with_complaints / total * 100:.1f}%" if total > 0 else "0%"

    if json_output:
        typer.echo(json.dumps({
            "found": True,
            "firm_crd": firm_crd,
            "firm_name": f.get("firm_name"),
            "location": f"{f.get('city', '')}, {f.get('state', '')}".strip(", "),
            "total_advisors": total,
            "disclosure_rate": disc_rate,
            "disclosure_stats": stats,
            "sec_link": f"https://adviserinfo.sec.gov/Firm/{firm_crd}",
        }, indent=2))
        return

    location = f"{f.get('city', '')}, {f.get('state', '')}".strip(", ") or "—"
    header = (
        f"[bold]{f.get('firm_name', '?')}[/bold]  [dim]CRD #{firm_crd}[/dim]\n"
        f"Location:       {location}\n"
        f"Total Advisors: [bold]{total:,}[/bold]\n"
        f"Complaint Rate: {disc_rate}"
    )
    console.print(Panel(header, expand=False))

    disc_table = Table(box=box.SIMPLE, show_header=True)
    disc_table.add_column("Disclosure Type")
    disc_table.add_column("Count", justify="right")
    disc_table.add_row("Customer Complaints", str(stats.get("with_complaints", 0)))
    disc_table.add_row("Regulatory Actions", str(stats.get("with_regulatory", 0)))
    disc_table.add_row("Criminal History", str(stats.get("with_criminal", 0)))
    console.print(disc_table)
    console.print(f"\n[dim]🔗 SEC: https://adviserinfo.sec.gov/Firm/{firm_crd}[/dim]")


@app.command()
def disclosures(
    type: DisclosureType = typer.Option(..., "--type", help="Disclosure type to filter by"),
    state: Optional[str] = typer.Option(None, "--state", help="Two-letter state code"),
    limit: int = typer.Option(50, "--limit", min=1, max=200),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON"),
):
    """List advisors filtered by disclosure type."""
    params = [f"type={type.value}", f"limit={limit}"]
    if state:
        params.append(f"state={state.upper()}")

    data = api_get(f"/disclosures?{'&'.join(params)}")
    if "error" in data:
        _handle_error(data, json_output)

    if json_output:
        typer.echo(json.dumps(data, indent=2))
        return

    advisors = data.get("advisors", [])
    console.print(f"[bold]{type.value.replace('_', ' ').title()} Disclosures[/bold] — {len(advisors)} result(s)")

    if not advisors:
        console.print("[yellow]No advisors found with this disclosure type.[/yellow]")
        return

    table = Table(box=box.ROUNDED)
    table.add_column("CRD", style="dim", width=10)
    table.add_column("Name", min_width=20)
    table.add_column("Status", width=10)
    table.add_column("Firm", min_width=25)
    table.add_column("State", width=6)

    for a in advisors:
        name_str = f"{a.get('first_name', '')} {a.get('last_name', '')}".strip()
        active = a.get("active_registration")
        status = "[green]Active[/green]" if active else "[dim]Inactive[/dim]"
        table.add_row(
            str(a.get("crd_number", "")),
            name_str,
            status,
            a.get("firm_name") or "—",
            a.get("state") or "—",
        )
    console.print(table)
