# advisorfinder-cli

Terminal CLI for searching SEC-registered financial advisors. Data sourced from the SEC Investment Adviser Public Disclosure (IAPD) database.

## Install

```bash
pip install advisorfinder-cli
```

## Usage

```bash
# Search by name
advisorfinder search "Joseph Montgomery" --state VA

# Full profile
advisorfinder lookup 3034796

# Quick safety check
advisorfinder verify 3034796

# Firm overview
advisorfinder firm 133640

# Database stats
advisorfinder stats

# Advisors with complaints in California
advisorfinder disclosures --type customer_complaint --state CA

# JSON output (for scripting)
advisorfinder lookup 3034796 --json | jq '.risk_level'
```

## macOS SSL Note

If you see a certificate error on macOS, run:

```bash
export SSL_CERT_FILE=/private/etc/ssl/cert.pem
advisorfinder stats
```

Or add it to your shell profile (`~/.zshrc` or `~/.bash_profile`) to make it permanent.

## Data

Data is sourced from the SEC IAPD database, updated weekly. Always verify important information at:
- [SEC IAPD](https://adviserinfo.sec.gov)
- [FINRA BrokerCheck](https://brokercheck.finra.org)
