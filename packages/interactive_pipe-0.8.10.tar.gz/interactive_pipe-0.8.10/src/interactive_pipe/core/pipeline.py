import logging
import warnings
from typing import Any, Dict, List, Optional

from interactive_pipe.core.context import _set_user_context
from interactive_pipe.core.engine import PipelineEngine
from interactive_pipe.core.filter import FilterCore

# Deprecated aliases for 'context' parameter
_CONTEXT_ALIASES = ("global_params", "global_parameters", "global_state", "global_context", "state")


class PipelineCore:
    """A pipeline is defined as the combination of:
    - a list of filters
    - an engine to execute the filters (with cache or not)
    - optionally, some inputs to process
    """

    def __init__(
        self,
        filters: List[FilterCore],
        name="pipeline",
        cache=False,
        inputs: Optional[list] = None,
        parameters: Optional[dict] = None,
        context: Optional[dict] = None,
        outputs: Optional[list] = None,
        safe_input_buffer_deepcopy: bool = True,
        **kwargs,
    ):
        if not all(isinstance(f, FilterCore) for f in filters):
            raise ValueError(f"All elements in 'filters' must be instances of 'Filter'. {[type(f) for f in filters]}")
        self.filters = filters
        self.engine = PipelineEngine(cache, safe_input_buffer_deepcopy=safe_input_buffer_deepcopy)

        # Handle deprecated aliases for context parameter
        for alias in _CONTEXT_ALIASES:
            if alias in kwargs:
                warnings.warn(
                    f"'{alias}' parameter is deprecated, use 'context' instead.",
                    DeprecationWarning,
                    stacklevel=2,
                )
                if context is None:
                    context = kwargs.pop(alias)
                else:
                    kwargs.pop(alias)  # Ignore if context already provided

        # Warn about any remaining unknown kwargs
        if kwargs:
            unknown = ", ".join(kwargs.keys())
            raise TypeError(f"PipelineCore.__init__() got unexpected keyword argument(s): {unknown}")

        if context is None:
            context = {}
        self.global_params = context
        for filter in self.filters:
            # link each filter to global params
            filter.global_params = self.global_params

        # Initialize user context (separate from global_params for clean API)
        self._user_context = dict(context) if isinstance(context, dict) else {}

        self.reset_cache()
        if inputs is None:
            logging.warning("Setting a pipeline without input -  use inputs=[] to get rid of this warning")
            self.inputs_routing = []
        else:
            self.inputs_routing = inputs

        self.__initialized_inputs = False
        if outputs is None:
            outputs = self.filters[-1].outputs
            logging.warning(f"Using last filter outputs {self.filters[-1]} {outputs}")

        self.outputs = outputs  # output indexes (routing)
        # You need to set the values to their default_value for each filter
        if parameters is None:
            parameters = {}
        self.parameters = parameters
        self.results = None
        self.name = name

    def reset_cache(self):
        for filter in self.filters:
            filter.reset_cache()

    def run(self) -> dict:
        """Useful for standalone python access without gui or disk write"""
        # Set user context before running pipeline
        _set_user_context(self._user_context)
        try:
            return self.engine.run(self.filters, imglst=self.inputs)
        finally:
            # Clear user context after execution
            _set_user_context(None)

    def _reset_global_params(self):
        for filter in self.filters:
            filter.global_params = self.global_params

    @property
    def parameters(self):
        parameters = {}
        for filt in self.filters:
            parameters[filt.name] = filt.values
        return parameters

    @parameters.setter
    def parameters(self, new_parameters: Dict[str, Any]):
        """Force tuning parameters

        ```
        new_parameters = {
            'filter1' : {'param1_1': 5, 'param1_2': 10},
            'filter2' : {'param2_1':8}
        }
        ```
        filter1.values = new_parameters["filter1"]
        filter2.values = new_parameters["filter2"]

        scan all new_parameters, check if the key describe the name of an avaiable filter,
        then update that given filter parameters.

        assume filter2 needed a second parameter `param2_2` which was defined when instantiating the filter...
        `param2_2` will stay untouched
        """
        available_filters_names = [filt.name for filt in self.filters]
        for filter_name in new_parameters.keys():
            if filter_name not in available_filters_names:
                raise ValueError(f"filter {filter_name} does not exist {available_filters_names}")
            self.filters[available_filters_names.index(filter_name)].values = new_parameters[filter_name]

    @property
    def inputs(self):
        if not self.__initialized_inputs:
            raise RuntimeError("Cannot access uninitialized inputs!")
        return self.__inputs

    @inputs.setter
    def inputs(self, inputs: list):
        if inputs is not None:
            if isinstance(inputs, dict):
                provided_keys = list(inputs.keys())
                for idx, input_name in enumerate(self.inputs_routing):
                    if input_name not in provided_keys:
                        raise ValueError(f"{input_name} is not among {provided_keys}")
                self.__inputs = inputs
            elif isinstance(inputs, (list, tuple)):
                # inputs is a list or a tuple
                if len(inputs) != len(self.inputs_routing):
                    raise ValueError(
                        f"Wrong amount of inputs: provided {len(inputs)} vs expected {len(self.inputs_routing)}"
                    )
                self.__inputs = {}
                for idx, input_name in enumerate(self.inputs_routing):
                    self.__inputs[input_name] = inputs[idx]
            else:
                # single element
                if len(self.inputs_routing) != 1:
                    raise ValueError(f"Single input provided but expected {len(self.inputs_routing)} inputs")
                self.__inputs = {self.inputs_routing[0]: inputs}
            if not isinstance(self.__inputs, dict):
                raise RuntimeError("Internal error: inputs should be a dict")
            if len(self.__inputs.keys()) == 0:
                # similar to having no input, but explicitly saying that we have initialized it.
                self.__inputs = None
        else:
            if not (
                self.inputs_routing is None
                or (isinstance(self.inputs_routing, (tuple, list)) and len(self.inputs_routing) == 0)
            ):
                raise ValueError("Cannot set inputs to None when inputs_routing is defined")
            self.__inputs = None
        self.__initialized_inputs = True
        self.reset_cache()
