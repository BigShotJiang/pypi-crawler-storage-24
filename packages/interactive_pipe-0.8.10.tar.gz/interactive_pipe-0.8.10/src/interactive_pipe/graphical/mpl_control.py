import logging

from matplotlib.widgets import CheckButtons, RadioButtons, Slider, TextBox

from interactive_pipe.headless.control import Control


class BaseControl:
    def __init__(self, name, ctrl: Control, update_func, ax_control=None):
        super().__init__()
        self.name = name
        self.ctrl = ctrl
        self.update_func = update_func
        self.control_widget = None
        self.check_control_type()
        self.ax_control = ax_control

    def create(self):
        raise NotImplementedError("This method should be overridden by subclass")

    def check_control_type(self):
        raise NotImplementedError("This method should be overridden by subclass to check the right slider control type")


class SliderMatplotlibControl(BaseControl):
    def create(self):
        if self.ctrl.value_range is None:
            raise ValueError("value_range must be provided for SliderMatplotlibControl")
        if self.ax_control is None:
            raise ValueError("ax_control must be provided for SliderMatplotlibControl")
        valmin = self.ctrl.value_range[0]
        valmax = self.ctrl.value_range[1]
        valinit = self.ctrl.value
        if not isinstance(valmin, (int, float)):
            raise TypeError(f"Expected int or float for valmin, got {type(valmin)}")
        if not isinstance(valmax, (int, float)):
            raise TypeError(f"Expected int or float for valmax, got {type(valmax)}")
        if not isinstance(valinit, (int, float)):
            raise TypeError(f"Expected int or float for valinit, got {type(valinit)}")
        slider = Slider(
            self.ax_control,
            self.name,
            float(valmin),
            float(valmax),
            valinit=float(valinit),
            valstep=1 if self.ctrl._type is int else None,
        )
        slider.on_changed(lambda val: self.update_func(self.name, val))
        return slider


class IntSliderMatplotlibControl(SliderMatplotlibControl):
    def check_control_type(self):
        if self.ctrl._type is not int:
            raise TypeError(f"Expected int control type, got {self.ctrl._type}")


class FloatSliderMatplotlibControl(SliderMatplotlibControl):
    def check_control_type(self):
        if self.ctrl._type is not float:
            raise TypeError(f"Expected float control type, got {self.ctrl._type}")


class BoolCheckButtonMatplotlibControl(BaseControl):
    def check_control_type(self):
        if self.ctrl._type is not bool:
            raise TypeError(f"Expected bool control type, got {self.ctrl._type}")

    def create(self):
        if self.ax_control is None:
            raise ValueError("ax_control must be provided for BoolCheckButtonMatplotlibControl")
        value = self.ctrl.value
        if not isinstance(value, bool):
            raise TypeError(f"Expected bool for BoolCheckButtonMatplotlibControl, got {type(value)}")
        current_state = [value]

        def on_click(label):
            current_state[0] = not current_state[0]
            self.update_func(self.name, current_state[0])

        checks = CheckButtons(self.ax_control, [self.name], [value])
        checks.on_clicked(on_click)
        return checks


class StringRadioButtonMatplotlibControl(BaseControl):
    def check_control_type(self):
        if self.ctrl._type is not str:
            raise TypeError(f"Expected str control type, got {self.ctrl._type}")
        if self.ctrl.value_range is None:
            raise ValueError("value_range must be provided for StringRadioButtonMatplotlibControl")

    def create(self):
        if self.ax_control is None:
            raise ValueError("ax_control must be provided for StringRadioButtonMatplotlibControl")
        options = self.ctrl.value_range
        if options is None:
            raise ValueError("value_range must be provided for StringRadioButtonMatplotlibControl")
        # Convert options to strings if needed
        options_str = [str(opt) for opt in options]
        active_index = None
        value_str = str(self.ctrl.value)
        if value_str in options_str:
            active_index = options_str.index(value_str)
        radio = RadioButtons(
            self.ax_control,
            options_str,
            active=active_index if active_index is not None else 0,
        )
        radio.on_clicked(lambda val: self.update_func(self.name, val))

        return radio


class PromptMatplotlibControl(BaseControl):
    def check_control_type(self):
        if self.ctrl._type is not str:
            raise TypeError(f"Expected str control type, got {self.ctrl._type}")
        if self.ctrl.value_range is not None:
            raise ValueError("value_range must be None for PromptMatplotlibControl")

    def create(self):
        if self.ax_control is None:
            raise ValueError("ax_control must be provided for PromptMatplotlibControl")
        value = self.ctrl.value
        if not isinstance(value, str):
            raise TypeError(f"Expected str for PromptMatplotlibControl, got {type(value)}")
        # Create a prompt for text input
        self.text_box = TextBox(self.ax_control, "Input", initial=value)

        # Function to handle the update when text is entered
        def submit(text):
            self.update_func(self.name, text)

        # Connect the submission of the text box to the submit function
        self.text_box.on_submit(submit)

        return self.text_box


class ControlFactory:
    @staticmethod
    def create_control(control: Control, update_func, ax_control=None):
        control_type = control._type
        name = control.name
        # Return None for single-value controls (don't show anything)
        if control_type is str and control.value_range is not None and len(control.value_range) == 1:
            return None

        control_class_map = {
            bool: BoolCheckButtonMatplotlibControl,
            int: IntSliderMatplotlibControl,
            float: FloatSliderMatplotlibControl,
            str: (PromptMatplotlibControl if control.value_range is None else StringRadioButtonMatplotlibControl),
        }

        if control_type not in control_class_map:
            logging.warning(f"Unsupported control type: {control_type} for control named {name}")
            return None

        control_class = control_class_map[control_type]
        return control_class(name, control, update_func, ax_control)
