import logging
import time
from functools import partial
from pathlib import Path
from typing import Callable, List, Optional

from interactive_pipe.data_objects.image import Image
from interactive_pipe.data_objects.parameters import Parameters
from interactive_pipe.headless.control import TimeControl
from interactive_pipe.headless.keyboard import KeyboardControl
from interactive_pipe.headless.pipeline import HeadlessPipeline


class InteractivePipeGUI:
    """Adds a generic graphical user interface to HeadlessPipeline.

    Needs to be specified/customized for each backend.
    It adds an app with a GUI on top of a HeadlessPipeline.
    Widgets will update the pipeline parameters.
    - It deals with key bindings
     (keyboard press triggers a function.
     function docstring is shown to the user when he presses "F1" help)
    - It deals with printing the help
    - Initializing the app `init_app` usually requires creating the window object
    A few special methods may be redefined for some specific backend needs.
    `reset_parameters`, `close`,
    `save_parameters`, `load_parameters`, `print_parameters`
    `display_graph`, `help`
    Docstring of these methods will be used in the "F1" help descriptions
    - Redefining `print_message` will allow a window popup for instance.

    Do not re-implement the init function!
    """

    def __init__(
        self,
        pipeline: Optional[HeadlessPipeline] = None,
        controls: Optional[List] = None,
        name: str = "",
        custom_end: Callable = lambda: None,
        audio: bool = False,
        size=None,
        **kwargs,
    ) -> None:
        if controls is None:
            controls = []
        if pipeline is None:
            raise ValueError("pipeline must be provided")
        self.pipeline = pipeline
        self.custom_end = custom_end
        self.audio = audio
        self.name = name
        self.size = size
        merged_controls = []
        merged_controls += controls
        if hasattr(pipeline, "controls"):
            merged_controls += pipeline.controls
        self.controls = merged_controls
        if self.pipeline.outputs:
            if not isinstance(self.pipeline.outputs[0], list):
                self.pipeline.outputs = [self.pipeline.outputs]
        self.pipeline.global_params["__output_styles"] = {}
        self.pipeline.global_params["__app"] = self
        self.pipeline.global_params["__pipeline"] = self.pipeline
        if "__events" not in self.pipeline.global_params.keys():
            self.pipeline.global_params["__events"] = {}
        self.key_bindings = {}
        self.context_key_bindings = {}
        self.init_app(**kwargs)
        self.reset_context_events()

    def init_app(self):
        """Init the app
        Initializing the app requires
        - creating the window object
        - binding default keyboard keys
        """
        raise NotImplementedError

    def run(self) -> list:
        """Once properly initialized
        - Show the window
        - Put it in full screen if needed
        - execute the app (launch the main event loop)
        Return results
        """
        raise NotImplementedError

    def __call__(self, *args, parameters=None, context=None, **kwargs) -> list:
        if parameters is None:
            parameters = {}
        # Handle context parameter - update user context if provided
        # Check both named parameter and kwargs
        context_dict = context
        if context_dict is None and "context" in kwargs:
            context_dict = kwargs.pop("context")
        if context_dict is not None:
            if isinstance(context_dict, dict):
                self.pipeline._user_context.update(context_dict)
            else:
                raise TypeError(f"context must be a dict, got {type(context_dict)}")
        self.pipeline.parameters = parameters
        self.pipeline.parameters = self.pipeline.parameters_from_keyword_args(**kwargs)
        self.pipeline.inputs = list(args)
        results = self.run()
        return results

    def bind_key(self, key, func: Callable):
        if key in self.key_bindings.keys():
            logging.warning(f"Key {key} already bound to {self.key_bindings[key]}")
        self.key_bindings[key] = func

    def bind_key_to_context(self, key: str, context_param_name: str, doc: str):
        self.context_key_bindings[key] = {"param_name": context_param_name, "doc": doc}
        # Not triggered!
        self.pipeline.global_params["__events"][context_param_name] = False

    def reset_context_events(self):
        for evkey in self.pipeline.global_params["__events"].keys():
            self.pipeline.global_params["__events"][evkey] = False

    def on_press(self, key_pressed, refresh_func=None):
        for key, func in self.key_bindings.items():
            if key_pressed == key:
                func()  # a GUI level function like reset parameters or export images
        is_any_event_triggered = False
        for key, event_dict in self.context_key_bindings.items():
            event_triggered = key_pressed == key
            self.pipeline.global_params["__events"][event_dict["param_name"]] = event_triggered
            if event_triggered:
                logging.info(f"TRIGGERED A KEY EVENT {key_pressed} - {event_dict['doc']}")
                is_any_event_triggered = True
        if is_any_event_triggered:
            self.pipeline.reset_cache()
            if refresh_func is not None:
                refresh_func()
        self.reset_context_events()

    def bind_keyboard_slider(self, ctrl: KeyboardControl, key_update_parameter_func: Callable):
        if not isinstance(ctrl, KeyboardControl):
            raise TypeError(f"ctrl must be a KeyboardControl instance, got {type(ctrl)}")
        toggle_only = True
        doc = ""
        slider_name = ctrl.name
        toggle_only = ctrl.keyup is None or ctrl.keydown is None

        for keyboard_key, down_flag in [(ctrl.keyup, False), (ctrl.keydown, True)]:
            if keyboard_key is None:
                continue
            if toggle_only:
                if ctrl._type is bool:
                    doc = f"toggle {ctrl.name}"
                else:
                    if ctrl.keyup is None:
                        doc = f"decrease {ctrl.name}"
                    elif ctrl.keydown is None:
                        doc = f"increase {ctrl.name}"
            else:
                if down_flag:
                    formatted_keydown = self._format_key_for_help(ctrl.keydown) if ctrl.keydown else ""
                    formatted_keyup = self._format_key_for_help(ctrl.keyup) if ctrl.keyup else ""
                    doc = f"[{formatted_keydown}]/[{formatted_keyup}]: {ctrl.name}"
                else:
                    doc = None
            update_func = partial(key_update_parameter_func, slider_name, down_flag)
            self.bind_key(keyboard_key, update_func)
            update_func.__doc__ = doc

    def play_pause_time(self, suspend_resume_timer: Optional[Callable] = None):
        """Play or pause the timer"""
        if self.start_time is None:
            self.start_time = time.time()
        else:
            self.start_time = time.time() - self.start_time
        self.time_playing = not self.time_playing
        if suspend_resume_timer is not None:
            suspend_resume_timer(not self.time_playing)

    def plug_timer_control(
        self,
        ctrl: TimeControl,
        update_parameter_func: Callable,
        suspend_resume_timer: Optional[Callable] = None,
    ):
        """Plug timer control to the processing block (pass the time to the block)
        Bind the pause_resume_key (default "p") play/pause key to the timer
        """
        if not isinstance(ctrl, TimeControl):
            raise TypeError(f"ctrl must be a TimeControl instance, got {type(ctrl)}")
        doc = ""
        slider_name = ctrl.name
        doc = None
        self.start_time = time.time()
        self.time_playing = True

        def update_func():
            if self.start_time is None:
                self.start_time = time.time()
            delta_time = time.time() - self.start_time
            return update_parameter_func(slider_name, delta_time)

        pause_resume_func = partial(self.play_pause_time, suspend_resume_timer)
        pause_resume_func.__doc__ = f"pause/resume time control '{slider_name}'"
        self.bind_key(ctrl.pause_resume_key, pause_resume_func)
        update_func.__doc__ = doc
        return update_func

    # ---------------------------------------------------------------------

    def reset_parameters(self):
        """reset parameters"""
        logging.debug("Reset parameters")

    def close(self):
        """quit"""
        logging.debug("Closing gui")

    def save_parameters(self):
        """export parameters dictionary to a yaml/json file"""
        self.pipeline.export_tuning()

    def load_parameters(self):
        """import parameters dictionary from a yaml/json file on disk"""
        pth = Parameters.check_path(Path(Parameters.prompt_file()))
        self.pipeline.import_tuning(pth)

    def print_parameters(self):
        """print parameters dictionary in the console"""
        print(self.pipeline.__repr__())

    def save_images(self):
        """save images to disk"""
        pth = Image.check_path(Path(Image.prompt_file()), load=False)
        self.pipeline.save(pth, data_wrapper_fn=lambda im: Image(im), save_entire_buffer=True)

    def graph_representation(self, path=None, ortho=True, view=False):
        """Generate graph representation of the pipeline"""
        return self.pipeline.graph_representation(path=path, ortho=ortho, view=view)

    def display_graph(self):
        """display execution graph"""
        try:
            result = self.pipeline.graph_representation(view=True, ortho=False)
            if result is None:
                self.print_message(
                    [
                        "Graph visualization failed.",
                        "Graphviz executables are required to display the graph.",
                        "Please install Graphviz system package:",
                        "  - Ubuntu/Debian: sudo apt-get install graphviz",
                        "  - macOS: brew install graphviz",
                        "  - Windows: Download from https://graphviz.org/download/",
                    ]
                )
        except Exception as exc:
            self.print_message(
                [
                    f"Failed to display graph: {exc}",
                    "Graphviz executables are required to display the graph.",
                    "Please install Graphviz system package:",
                    "  - Ubuntu/Debian: sudo apt-get install graphviz",
                    "  - macOS: brew install graphviz",
                    "  - Windows: Download from https://graphviz.org/download/",
                ]
            )

    def _format_key_for_help(self, key: str) -> str:
        """Format a key string for display in help text.

        Converts special keys like spacebar to readable names.
        """
        if key == " " or key == KeyboardControl.KEY_SPACEBAR:
            return "SPACEBAR"
        return key

    def _format_docstring_for_help(self, docstring: str) -> str:
        """Format a docstring to replace spacebar references with readable text."""
        # Replace [" "] with [SPACEBAR] in docstrings
        return docstring.replace('[" "]', "[SPACEBAR]")

    def help(self) -> List[str]:
        """print this help in the console"""
        help = []
        for key, func in self.key_bindings.items():
            if func.__doc__ is not None:
                if func.__doc__.startswith("["):
                    formatted_doc = self._format_docstring_for_help(func.__doc__)
                    help.append(f"{formatted_doc}")
                else:
                    formatted_key = self._format_key_for_help(key)
                    formatted_doc = self._format_docstring_for_help(func.__doc__)
                    help.append(f"[{formatted_key}]    : {formatted_doc}")
        for key_context, event_dict in self.context_key_bindings.items():
            formatted_key_context = self._format_key_for_help(key_context)
            formatted_doc = self._format_docstring_for_help(event_dict["doc"])
            help.append(
                f"[{formatted_key_context}]    : {formatted_doc} (context['__event'][{event_dict['param_name']}])"
            )
        self.print_message(help)
        return help

    def print_message(self, message_list: List[str]):
        print("\n".join(message_list))

    # ---------------------------------------------------------------------
