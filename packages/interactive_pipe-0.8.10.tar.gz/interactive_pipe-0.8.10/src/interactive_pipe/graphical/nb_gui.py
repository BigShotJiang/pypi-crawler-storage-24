from typing import List, Optional, Tuple, Union

import matplotlib.pyplot as plt
from IPython.display import display
from ipywidgets import interact

from interactive_pipe.graphical.gui import InteractivePipeGUI
from interactive_pipe.graphical.mpl_window import MatplotlibWindow
from interactive_pipe.graphical.nb_control import ControlFactory
from interactive_pipe.headless.control import Control


class InteractivePipeJupyter(InteractivePipeGUI):
    def init_app(self, **kwargs):
        self.window = MainWindow(
            controls=self.controls,
            name=self.name,
            pipeline=self.pipeline,
            size=self.size,
            **kwargs,
        )

    def run(self) -> None:
        if not self.pipeline._PipelineCore__initialized_inputs:  # type: ignore[reportAttributeAccessIssue]
            raise RuntimeError("Did you forget to initialize the pipeline inputs?")
        interact(self.window._interact_fn, **self.window.sliders_dict)
        return None  # do not return arrays in a jupyter notebook


# You will need %matplotlib inline


class MainWindow(MatplotlibWindow):
    def __init__(
        self,
        controls=None,
        name="",
        pipeline=None,
        size: Optional[Union[int, Tuple[int, int]]] = None,
        style: Optional[str] = None,
        rc_params=None,
        **unused_kwargs,
    ):
        if controls is None:
            controls = []
        if size is not None and isinstance(size, int):
            size = (size, size)
        if size is not None and not isinstance(size, (tuple, list)):
            raise TypeError("size should be a tuple, list, or None")

        super().__init__(
            controls=controls,
            name=name,
            pipeline=pipeline,
            style=style,
            rc_params=rc_params,
            size=size,
        )
        self.init_sliders(self.controls)

    def create_figure(self):
        if self.fig is None:
            self.fig, self.ax = plt.subplots(figsize=self.size)
            plt.axis("off")

    def init_sliders(self, controls: List[Control], dry_run=False):
        self.ctrl = {}
        self.result_label = {}
        control_factory = ControlFactory()
        self.sliders_dict = {}

        for ctrl in controls:
            slider_name = ctrl.name
            slider_instance = control_factory.create_control(ctrl)
            # Skip controls that return None (e.g., single-value controls)
            if slider_instance is None:
                self.ctrl[slider_name] = ctrl
                continue
            slider_widget = slider_instance.create()
            # needed to keep the object alive
            self.sliders_dict[slider_name] = slider_widget
            self.ctrl[slider_name] = ctrl

    def _interact_fn(self, **kwargs):
        for idx, param in kwargs.items():
            self.ctrl[idx].update(param)
        self.refresh()
        display(self.fig)

    def refresh(self):
        if self.pipeline is not None:
            out = self.pipeline.run()
            self.create_figure()
            self.refresh_display(out)
