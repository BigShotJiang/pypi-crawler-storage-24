import logging
import signal
from typing import Union

from interactive_pipe.core.backend import Backend
from interactive_pipe.helper import _private


def get_interactive_pipeline_class(gui: Union[str, Backend, None] = "auto"):
    selected_gui = None
    if gui is None or gui == "auto":
        if _private.auto_gui is not None:
            selected_gui = _private.auto_gui  # skip selection, used cached one
            logging.debug(f"auto gui already selected {selected_gui}")
        else:
            try:
                __IPYTHON__  # type: ignore  # noqa: F821
                selected_gui = "nb"
            except Exception:
                try:
                    from interactive_pipe.graphical.qt_gui import (
                        InteractivePipeQT as ChosenGui,
                    )

                    selected_gui = "qt"
                except Exception as qt_import_execption:
                    try:
                        import matplotlib.pyplot as plt  # noqa: F401

                        selected_gui = "mpl"
                    except Exception as mpl_import_exception:
                        raise NameError(
                            "Error in auto backend choice:\n"
                            + f"Could not import Qt: {qt_import_execption}\n"
                            + f"Could not import Matplotlib {mpl_import_exception}"
                        )
            _private.auto_gui = selected_gui
    else:
        selected_gui = gui
    if selected_gui == "qt":
        # make sure that the signal handlers are reset to default
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        signal.signal(signal.SIGTERM, signal.SIG_DFL)
        from interactive_pipe.graphical.qt_gui import (  # noqa: F811
            InteractivePipeQT as ChosenGui,
        )
    elif selected_gui == "mpl":
        from interactive_pipe.graphical.mpl_gui import (
            InteractivePipeMatplotlib as ChosenGui,
        )
    elif selected_gui == "nb":
        from interactive_pipe.graphical.nb_gui import (
            InteractivePipeJupyter as ChosenGui,
        )
    elif selected_gui == "gradio":
        from interactive_pipe.graphical.gradio_gui import (
            InteractivePipeGradio as ChosenGui,
        )
    else:
        raise NotImplementedError(f"Gui {gui} not available")
    return ChosenGui
