import{a as e}from"../chunks/BM5NbulM.js";export{e as component};
