import{l as o,a as r}from"../chunks/krX1kQOh.js";export{o as load_css,r as start};
