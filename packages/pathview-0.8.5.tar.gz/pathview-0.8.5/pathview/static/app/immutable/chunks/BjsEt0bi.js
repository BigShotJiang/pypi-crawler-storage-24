const s=globalThis.__sveltekit_zm1sog?.base??"",a=globalThis.__sveltekit_zm1sog?.assets??s??"";export{a,s as b};
