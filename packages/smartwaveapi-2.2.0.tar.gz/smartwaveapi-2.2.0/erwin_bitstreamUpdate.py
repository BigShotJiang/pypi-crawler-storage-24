from SmartWaveAPI import SmartWave
import time

def main():
    with SmartWave().connect() as sw:
        sw.updateFPGABitstream("C:/Users/Erwin/Documents/wfg_luke/wfg_git/vivado/my_bitstream_for_SPIx1_config.bin")

        sw.infoCallback = lambda hw, uc, fpga, flashId: print("Hardware version: %s\nMicrocontroller version: %s\nFPGA version: %s\nFlash ID: 0x%x" % (hw, uc, fpga, flashId))
        sw.requestInfo()


if __name__ == "__main__":
    main()
