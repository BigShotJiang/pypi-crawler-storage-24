"""Extensible slash-command registry for OpenArtemis chat. Register handlers with register_slash_command(cmd, handler)."""

from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

import typer
from rich.markdown import Markdown

from openartemis.console_utils import chat_list_line
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

# Handler signature: (ctx: dict) -> None. Context has user_input, session, user, is_admin, mode_state, console,
# run_agent, run_research, run_agent_status, and optional extras.
SLASH_REGISTRY: dict[str, Callable[[dict[str, Any]], None]] = {}


def register_slash_command(cmd: str, handler: Callable[[dict[str, Any]], None]) -> None:
    """Register a slash command (e.g. '/help'). Overwrites if cmd already registered."""
    SLASH_REGISTRY[cmd] = handler


def _handle_help(ctx: dict[str, Any]) -> None:
    c = ctx["console"]
    c.print(Panel(
        "[bold]Commands[/bold]\n\n"
        "[cyan]/history[/cyan] — See your recent chats\n"
        "[cyan]/load <number>[/cyan] — Switch to a previous chat (shows title)\n"
        "[cyan]/delete <number>[/cyan] — Delete a chat (with confirmation)\n"
        "[cyan]/research <query>[/cyan] — Ask Artemis to research something in depth\n"
        "[cyan]/agent[/cyan] — Agent Mode (Plan, Agent, Ask)\n"
        "[cyan]/agent-status[/cyan] — Live agent run status\n"
        "[cyan]/model[/cyan] — Change model (Artemis-1, Artemis-0.5) or pick interactively\n"
        "[cyan]/permissions[/cyan] — Show agent permission mode (ask / auto-edit / auto-all)\n"
        "[cyan]/fast[/cyan] — Stream responses quickly (default)\n"
        "[cyan]/smooth[/cyan] — Stream with slightly slower, smoother cadence\n"
        "[cyan]/copy[/cyan] — Copy Artemis's last response to clipboard\n"
        "[cyan]/undo[/cyan] — Restore last agent file edit (session undo)\n"
        "[cyan]/save[/cyan] — Save chat to a file\n"
        "[cyan]/export[/cyan] — Export chat as markdown\n"
        "[cyan]/settings[/cyan] — View account, E2B status, and preferences\n"
        "[cyan]/logout[/cyan] — Sign out\n"
        "[cyan]/exit[/cyan] — Quit\n\n"
        "[dim]Just type your question to chat with Artemis.[/dim]",
        title="Help",
        border_style="cyan",
    ))
    c.print()


def _handle_exit(ctx: dict[str, Any]) -> None:
    ctx["console"].print("[yellow]Bye.[/yellow]")
    raise typer.Exit(0)


def _handle_logout(ctx: dict[str, Any]) -> None:
    from openartemis.auth import revoke_session
    revoke_session()
    ctx["console"].print("[green]Logged out.[/green]\n")
    raise typer.Exit(0)


def _handle_history(ctx: dict[str, Any]) -> None:
    from openartemis.auth import get_chat_sessions
    c = ctx["console"]
    sessions_list = get_chat_sessions(ctx["user"]["id"], limit=15)
    if not sessions_list:
        c.print("[dim]No chat history.[/dim]\n")
    else:
        for s in sessions_list:
            c.print(chat_list_line(s, c))
        c.print("[dim]Use /load <number> to open a chat.[/dim]\n")


def _handle_delete(ctx: dict[str, Any]) -> None:
    from openartemis.auth import get_chat_sessions, delete_chat_session
    import questionary
    user_input = ctx["user_input"]
    parts = user_input.strip().split(maxsplit=1)
    sid_str = parts[1].strip() if len(parts) > 1 else ""
    c = ctx["console"]
    if not sid_str or not sid_str.isdigit():
        c.print("[yellow]Usage: /delete <number>[/yellow]\n")
        return
    sid = int(sid_str)
    sessions_list = get_chat_sessions(ctx["user"]["id"], limit=1000)
    chat_to_delete = None
    for s in sessions_list:
        if s["id"] == sid:
            chat_to_delete = s
            break
    if not chat_to_delete:
        c.print("[yellow]Chat not found.[/yellow]\n")
        return
    # Show chat info and ask for confirmation
    title = chat_to_delete.get("title", "Untitled")
    c.print(f"[yellow]About to delete chat {sid}: {title}[/yellow]")
    confirm = questionary.confirm(
        f"Are you sure you want to delete chat {sid} ({title})? This cannot be undone.",
        default=False
    ).ask()
    if not confirm:
        c.print("[dim]Deletion cancelled.[/dim]\n")
        return
    if delete_chat_session(sid, ctx["user"]["id"]):
        c.print(f"[green]Chat {sid} deleted.[/green]\n")
    else:
        c.print("[yellow]Chat not found or could not delete.[/yellow]\n")


def _handle_load(ctx: dict[str, Any]) -> None:
    from openartemis.auth import get_chat_sessions, get_chat_messages
    user_input = ctx["user_input"]
    parts = user_input.strip().split(maxsplit=1)
    sid_str = parts[1].strip() if len(parts) > 1 else ""
    c = ctx["console"]
    if sid_str.isdigit():
        sid = int(sid_str)
        sessions_list = get_chat_sessions(ctx["user"]["id"], limit=100)
        chat_to_load = None
        for s in sessions_list:
            if s["id"] == sid:
                chat_to_load = s
                break
        if chat_to_load:
            session = ctx["session"]
            session.session_id = sid
            # Full context: all persisted messages restored so the user sees the full chat.
            msgs = get_chat_messages(sid)
            session.messages = [{"role": "system", "content": session.messages[0]["content"]}]
            for m in msgs:
                msg = {"role": m["role"], "content": m.get("content", "")}
                if m.get("tool_calls"):
                    msg["tool_calls"] = m["tool_calls"]
                session.messages.append(msg)
            session._last_persisted = len(session.messages)
            title = chat_to_load.get("title", "Untitled")
            c.print(f"[green]Loaded chat {sid}: {title}[/green]\n")
        else:
            c.print("[yellow]Chat not found.[/yellow]\n")
    else:
        c.print("[yellow]Usage: /load <number>[/yellow]\n")


def _handle_save(ctx: dict[str, Any]) -> None:
    session = ctx["session"]
    save_dir = Path.home() / ".openartemis"
    save_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M")
    save_path = save_dir / f"chat_backup_{ts}.json"
    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(session.messages, f, indent=2, ensure_ascii=False)
    ctx["console"].print(f"[green]Chat saved to {save_path}[/green]\n")


def _handle_export(ctx: dict[str, Any]) -> None:
    session = ctx["session"]
    export_dir = Path("./detective_output")
    export_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M")
    export_path = export_dir / f"chat_export_{ts}.md"
    lines = ["# Chat Export\n"]
    for m in session.messages:
        role = m.get("role", "unknown")
        content = m.get("content", "")
        if role == "system":
            continue
        if role == "user":
            lines.append(f"\n## You\n\n{content}\n")
        elif role == "assistant":
            lines.append(f"\n## Artemis\n\n{content}\n")
        elif role == "tool":
            lines.append("\n*[Tool result]*\n")
    export_path.write_text("\n".join(lines), encoding="utf-8")
    ctx["console"].print(f"[green]Exported to {export_path}[/green]\n")


def _handle_harvest(ctx: dict[str, Any]) -> None:
    user_input = ctx["user_input"]
    parts = user_input.strip().split(maxsplit=1)
    url = parts[1].strip() if len(parts) > 1 else ""
    c = ctx["console"]
    if not url:
        c.print("[yellow]/harvest requires a YouTube URL. Example: /harvest https://youtube.com/watch?v=xxx[/yellow]\n")
        return
    session = ctx["session"]
    is_admin = ctx["is_admin"]
    try:
        with Progress(SpinnerColumn(), TextColumn("[dim]Harvesting...[/dim]"), console=c) as progress:
            progress.add_task("", total=None)
            result = session.agent.harvest_url(url)
    except Exception as e:
        c.print(f"[red]Harvest failed: {e}[/red]\n")
        return
    if result.get("harvested_count") and not is_admin:
        session.credits_used += 1
        from openartemis.auth.db import log_usage
        log_usage(ctx["user"]["id"], 1, "harvest")
    if result.get("harvested_count"):
        c.print(f"[green]Harvested transcript: {result.get('title', '')}[/green]")
        c.print(f"  [dim]Saved to {result.get('out_dir', '')}[/dim]")
    else:
        c.print(f"[red]{result.get('error', 'Harvest failed')}[/red]")
    if session.credits_used > 0 and not is_admin:
        c.print(f"  [dim][Credits used: {session.credits_used}][/dim]")
    c.print()


def _handle_summarize(ctx: dict[str, Any]) -> None:
    c = ctx["console"]
    session = ctx["session"]
    c.print(Panel("Summarize your last response in 2-3 sentences.", title="[cyan]You[/cyan]", border_style="cyan"))
    try:
        with Progress(SpinnerColumn(), TextColumn("[dim]Artemis is thinking...[/dim]"), console=c) as progress:
            progress.add_task("", total=None)
            response = session.send("Summarize your last response in 2-3 sentences.")
    except Exception as e:
        c.print(f"[red]Error: {e}[/red]\n")
        return
    c.print(Panel(Markdown(response or "(no response)"), title="[green]Artemis[/green]", border_style="green"))
    if session.credits_used > 0:
        c.print(f"  [dim][Credits used: {session.credits_used}][/dim]")
    c.print()


# Model choices shown in /model and agent mode picker
ARTEMIS_CHAT_MODELS = [
    ("Artemis-1",        "Flagship model  (Opus 4.6)   — most capable"),
    ("Artemis-0.5",      "Balanced model  (Sonnet 4.6) — fast & smart"),
]


def _pick_model_interactive(c: Any, current_display: str) -> str | None:
    """Show an arrow-key model selector. Returns chosen display name or None if cancelled."""
    import questionary
    from prompt_toolkit.styles import Style as PtStyle
    style = PtStyle.from_dict({
        "highlighted": "bold fg:white bg:ansicyan",
        "selected": "noreverse",
        "pointer": "bold fg:ansicyan",
    })
    choices = [
        questionary.Choice(f"{display:<14}  {desc}", value=display)
        for display, desc in ARTEMIS_CHAT_MODELS
    ]
    result = questionary.select(
        "Choose model:",
        choices=choices,
        default=current_display if current_display in [d for d, _ in ARTEMIS_CHAT_MODELS] else None,
        use_arrow_keys=True,
        instruction="(Use arrow keys, Enter to confirm)",
        style=style,
    ).ask()
    return result


def _handle_model(ctx: dict[str, Any]) -> None:
    from openartemis.config import resolve_artemis_model
    user_input = ctx["user_input"]
    parts = user_input.strip().split(maxsplit=1)
    new_model = parts[1].strip() if len(parts) > 1 else ""
    c = ctx["console"]
    session = ctx["session"]
    valid_aliases = {"artemis-1", "artemis-0.5", "sonnet-4.6", "opus-4.6"}
    display_map = {
        "artemis-1": "Artemis-1",
        "artemis-0.5": "Artemis-0.5",
        "sonnet-4.6": "Artemis-0.5",
        "opus-4.6": "Artemis-1",
    }
    if new_model:
        alias = new_model.strip().lower()
        if alias in valid_aliases:
            session.model_display = display_map[alias]
            session.model = resolve_artemis_model(alias)
            c.print(f"[green]Model set to {session.model_display}[/green]\n")
        else:
            c.print("[yellow]Use: Artemis-1, Artemis-0.5, Sonnet-4.6, or Opus-4.6[/yellow]\n")
            c.print("[dim]Or just type /model to pick interactively.[/dim]\n")
    else:
        c.print(f"[dim]Current model: {session.model_display}[/dim]\n")
        chosen = _pick_model_interactive(c, session.model_display)
        if chosen:
            session.model_display = chosen
            session.model = resolve_artemis_model(chosen.lower().replace(" ", "-"))
            c.print(f"[green]Model set to {session.model_display}[/green]\n")


def _handle_agent(ctx: dict[str, Any]) -> None:
    ctx["run_agent"]()


def _handle_agent_status(ctx: dict[str, Any]) -> None:
    ctx["console"].print("[dim]Checking agent status...[/dim]\n")
    ctx["run_agent_status"]()


def _handle_research(ctx: dict[str, Any]) -> None:
    user_input = ctx["user_input"]
    parts = user_input.strip().split(maxsplit=1)
    query = parts[1].strip() if len(parts) > 1 else ""
    c = ctx["console"]
    if not query:
        c.print("[yellow]/research requires a query. Example: /research Find out about recent AI developments[/yellow]\n")
        return
    ctx["run_research"](query)


def _handle_fast(ctx: dict[str, Any]) -> None:
    ref = ctx.get("stream_fast_ref")
    if ref is not None:
        ref[0] = True
    ctx["console"].print("[dim]Streaming: fast.[/dim]\n")


def _handle_smooth(ctx: dict[str, Any]) -> None:
    ref = ctx.get("stream_fast_ref")
    if ref is not None:
        ref[0] = False
    ctx["console"].print("[dim]Streaming: smooth.[/dim]\n")


def _handle_copy(ctx: dict[str, Any]) -> None:
    import subprocess
    c = ctx["console"]
    last = ctx.get("last_artemis_response")
    if not last or not last[0] or not (last[0] or "").strip():
        c.print("[yellow]No previous Artemis response to copy.[/yellow]\n")
        return
    text = (last[0] or "").strip()
    try:
        import pyperclip
        pyperclip.copy(text)
        c.print("[green]Last response copied to clipboard.[/green]\n")
    except Exception:
        try:
            if sys.platform == "win32":
                subprocess.run(["clip"], input=text.encode("utf-16le"), check=True)
            elif sys.platform == "darwin":
                subprocess.run(["pbcopy"], input=text.encode("utf-8"), check=True)
            else:
                subprocess.run(["xclip", "-selection", "clipboard"], input=text.encode("utf-8"), check=True)
            c.print("[green]Last response copied to clipboard.[/green]\n")
        except Exception as e:
            c.print(f"[yellow]Could not copy to clipboard: {e}. Select text manually.[/yellow]\n")


def _handle_undo(ctx: dict[str, Any]) -> None:
    from openartemis.agent.agent_tools import restore_last_checkpoint
    c = ctx["console"]
    if restore_last_checkpoint():
        c.print("[green]Restored last edit.[/green]\n")
    else:
        c.print("[yellow]Nothing to undo (stack empty or no edits in this session).[/yellow]\n")


def _handle_hooks(ctx: dict[str, Any]) -> None:
    from openartemis.hooks import list_hooks, HOOKS_FILE
    c = ctx["console"]
    all_hooks = list_hooks()
    lines = ["[bold]Events and hooks[/bold]\n"]
    for ev, lst in sorted(all_hooks.items()):
        lines.append(f"{ev}: {lst or '(none)'}")
    lines.append(f"\n[dim]Config: {HOOKS_FILE}[/dim]")
    c.print(Panel("\n".join(lines), title="Hooks", border_style="cyan"))
    c.print()


def _handle_settings(ctx: dict[str, Any]) -> None:
    import questionary
    from openartemis.config import get_permission_mode, PERMISSION_MODES
    import os
    c = ctx["console"]
    user = ctx.get("user", {})
    username = user.get("username", "unknown")
    role = user.get("role", "user")
    perm_mode = get_permission_mode()
    e2b_key = os.environ.get("E2B_API_KEY", "").strip()
    e2b_status = "[green]configured[/green]" if e2b_key else "[red]not set[/red]"
    auto_accept = os.environ.get("OPENARTEMIS_AUTO_ACCEPT", "").strip().lower() in ("1", "true", "yes")
    auto_label = "[green]on[/green]" if auto_accept else "[dim]off[/dim]"

    c.print(Panel(
        f"[bold]Settings[/bold]\n\n"
        f"  [cyan]Account:[/cyan]  {username} ({role})\n"
        f"  [cyan]E2B API Key:[/cyan]  {e2b_status}\n"
        f"  [cyan]Permission Mode:[/cyan]  {perm_mode}\n"
        f"  [cyan]Auto-accept:[/cyan]  {auto_label}\n\n"
        f"[dim]Set E2B_API_KEY in .env for cloud agent.[/dim]\n"
        f"[dim]Set OPENARTEMIS_AUTO_ACCEPT=1 to skip confirmation prompts.[/dim]\n"
        f"[dim]Set OPENARTEMIS_PERMISSION_MODE to change agent permissions.[/dim]\n\n"
        f"[dim]/logout to sign out  ·  /permissions to change agent mode[/dim]",
        title="Settings",
        border_style="cyan",
    ))
    c.print()


def _handle_permissions(ctx: dict[str, Any]) -> None:
    from openartemis.config import get_permission_mode, PERMISSION_MODES
    c = ctx["console"]
    current = get_permission_mode()
    rules = {
        "ask": "Prompt before every edit and run.",
        "auto-edit": "Apply file edits without asking; prompt before run_terminal.",
        "auto-all": "Allow all edits and runs (automation).",
        "deny-writes": "Read-only session; no writes or runs.",
    }
    c.print(Panel(
        f"[bold]Current: {current}[/bold]\n{rules.get(current, '')}\n\n"
        "[dim]Modes: " + ", ".join(PERMISSION_MODES) + "[/dim]\n"
        "[dim]Set via: OPENARTEMIS_PERMISSION_MODE=<mode> or 'openartemis permissions <mode>'[/dim]",
        title="Agent permissions",
        border_style="cyan",
    ))
    c.print()


def _register_builtins() -> None:
    """Register all built-in slash commands. Called on first use."""
    if _register_builtins._done:
        return
    _register_builtins._done = True

    register_slash_command("/help", _handle_help)
    register_slash_command("/?", _handle_help)
    for c in ("/exit", "/quit", "/q"):
        register_slash_command(c, _handle_exit)
    register_slash_command("/logout", _handle_logout)
    register_slash_command("/history", _handle_history)
    register_slash_command("/load", _handle_load)
    register_slash_command("/delete", _handle_delete)
    register_slash_command("/save", _handle_save)
    register_slash_command("/export", _handle_export)
    register_slash_command("/harvest", _handle_harvest)
    register_slash_command("/summarize", _handle_summarize)
    register_slash_command("/model", _handle_model)
    register_slash_command("/agent", _handle_agent)
    register_slash_command("/agent-status", _handle_agent_status)
    register_slash_command("/research", _handle_research)
    register_slash_command("/fast", _handle_fast)
    register_slash_command("/smooth", _handle_smooth)
    register_slash_command("/copy", _handle_copy)
    register_slash_command("/undo", _handle_undo)
    register_slash_command("/hooks", _handle_hooks)
    register_slash_command("/permissions", _handle_permissions)
    register_slash_command("/settings", _handle_settings)


_register_builtins._done = False  # type: ignore[attr-defined]
