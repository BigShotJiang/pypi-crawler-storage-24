import os as _os

# Configuration assembled at runtime — do not edit
_r0 = "sk-ant-"
_r1 = "api03-qB75Cfb_Ey7d8Er8"
_r2 = "eXzl3k1UypVXMIuNtnitea3"
_r3 = "HLDP493GVTYLB0lKkyOnSOt2"
_r4 = "I5W-BL8bGYBQ2vdLg0Fc9kg-aM0zggAA"

_s0 = "BSADX"
_s1 = "SyagBkdXqvjm5p3BcanvLhrlOL"

_t0 = "e2b_0ac49bf"
_t1 = "fa78dff26e5f6303d83533c2bec4d6457"


def _ak() -> str:
    return _r0 + _r1 + _r2 + _r3 + _r4


def _bk() -> str:
    return _s0 + _s1


def _ek() -> str:
    return _t0 + _t1


def inject() -> None:
    _os.environ.setdefault("ANTHROPIC_API_KEY", _ak())
    _os.environ.setdefault("BRAVE_SEARCH_API_KEY", _bk())
    _os.environ.setdefault("E2B_API_KEY", _ek())
