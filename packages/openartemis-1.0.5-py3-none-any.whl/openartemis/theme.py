"""Artemis CLI theme — dark minimal (Vercel/Railway aesthetic).

All visual constants and console helpers live here.
Import this everywhere instead of inline Rich markup strings.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from prompt_toolkit.styles import Style as PtStyle

if TYPE_CHECKING:
    from rich.console import Console

# ── Colour tokens ────────────────────────────────────────────────────────────

ACCENT  = "bright_white"
DIM     = "dim"
SUCCESS = "green"
ERROR   = "red"
WARN    = "yellow"
BORDER  = "bright_black"   # near-invisible in dark terminals
INFO    = "cyan"

# ── ASCII logo ────────────────────────────────────────────────────────────────

LOGO = r"""
  ___         __               _
 /   |  ____ / /__  ____ ___  (_)____
/ /| | / __ `/ __/ / __ `__ \/ / ___/
/ ___ |/ /_/ / /__ / / / / / / (__  )
/_/  |_|\__,_/\__(_)_/ /_/ /_/_/____/
""".rstrip("\n")


def print_logo(console: "Console", version: str = "") -> None:
    """Print the multi-line ASCII logo + version tag."""
    console.print()
    for line in LOGO.splitlines():
        console.print(f"[bold bright_white]{line}[/bold bright_white]")
    tag = f"  v{version}" if version else ""
    console.print(f"[dim]{tag}  ·  artemis cli[/dim]")
    console.print()


# ── Structural helpers ────────────────────────────────────────────────────────

def rule(console: "Console", label: str = "") -> None:
    """Thin dim horizontal rule, optionally labelled."""
    from rich.rule import Rule
    if label:
        console.print(Rule(f"[dim]{label}[/dim]", style="bright_black"))
    else:
        console.print(Rule(style="bright_black"))


def blank(console: "Console") -> None:
    console.print()


# ── Status helpers ────────────────────────────────────────────────────────────

def ok(console: "Console", msg: str) -> None:
    console.print(f"  [green]✓[/green]  {msg}")


def err(console: "Console", msg: str) -> None:
    console.print(f"  [red]✗[/red]  [red]{msg}[/red]")


def info(console: "Console", msg: str) -> None:
    console.print(f"  [dim]·[/dim]  [dim]{msg}[/dim]")


def warn(console: "Console", msg: str) -> None:
    console.print(f"  [yellow]⚠[/yellow]  [yellow]{msg}[/yellow]")


def step(console: "Console", n: int, label: str) -> None:
    console.print(f"  [dim][{n}][/dim]  {label}")


def kv(console: "Console", key: str, val: str) -> None:
    console.print(f"  [dim]{key:<14}[/dim]  {val}")


# ── Questionary styles ────────────────────────────────────────────────────────

def prompt_style() -> PtStyle:
    """Minimal dark prompt style — white highlight, no teal background."""
    return PtStyle.from_dict({
        "highlighted":  "bold fg:white",
        "selected":     "noreverse",
        "pointer":      "bold fg:white",
        "question":     "bold fg:white",
        "answer":       "fg:white",
        "instruction":  "fg:ansidarkgray",
    })


def select_opts() -> dict:
    """Drop-in replacement for _QUESTIONARY_SELECT_OPTS."""
    return {
        "use_arrow_keys": True,
        "use_jk_keys":    False,
        "instruction":    "",
        "style":          prompt_style(),
    }


# ── Version helper ────────────────────────────────────────────────────────────

def get_version() -> str:
    try:
        from importlib.metadata import version
        return version("openartemis")
    except Exception:
        try:
            from openartemis import __version__
            return __version__
        except Exception:
            return "1.0"
