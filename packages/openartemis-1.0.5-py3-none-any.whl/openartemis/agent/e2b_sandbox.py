"""E2B cloud sandbox — create, manage, and interact with E2B Linux VMs for agent coding.

All agent coding happens inside the E2B sandbox. The sandbox provides:
- File read/write (sandbox.files.read / sandbox.files.write)
- Command execution (sandbox.commands.run)
- Directory listing
- File download (zip the project and pull it down)

The local machine never runs untrusted code — everything executes in E2B's isolated Linux VM.
"""

import io
import json
import os
import time
import zipfile
from pathlib import Path
from typing import Any, Optional

# E2B API key from env
E2B_API_KEY_ENV = "E2B_API_KEY"
E2B_PROJECT_DIR = "/home/user/ArtemisProject"

# Sandbox timeout: 30 minutes default (can be extended)
DEFAULT_TIMEOUT_SEC = 30 * 60


def _get_api_key() -> str:
    """Return E2B API key from environment."""
    key = os.environ.get(E2B_API_KEY_ENV, "").strip()
    if not key:
        raise RuntimeError(
            f"E2B_API_KEY not set. Add it to your .env or environment.\n"
            f"Get one at https://e2b.dev/dashboard?tab=keys"
        )
    return key


class E2BSandbox:
    """Wrapper around an E2B Sandbox instance for agent use."""

    def __init__(self) -> None:
        self._sandbox: Any = None
        self._started = False
        self.sandbox_id: Optional[str] = None
        self._proxy_sandbox_id: Optional[str] = None
        self._proxy_access_token: Optional[str] = None
        self._use_proxy: bool = False

    def start(self, timeout: int = DEFAULT_TIMEOUT_SEC) -> None:
        """Create and start the E2B sandbox."""
        from e2b import Sandbox
        api_key = _get_api_key()
        os.environ["E2B_API_KEY"] = api_key
        # Use the Node.js template for web/game development
        self._sandbox = Sandbox("e2b-nodejs", timeout=timeout)
        import uuid
        self.sandbox_id = f"e2b-{uuid.uuid4().hex[:8]}"
        # Ensure project directory exists
        try:
            self._sandbox.commands.run(f"mkdir -p {E2B_PROJECT_DIR}", timeout=5)
        except Exception:
            pass  # Directory creation failure is non-fatal
        self._started = True

    def stop(self) -> None:
        """Kill the sandbox."""
        if self._sandbox:
            try:
                self._sandbox.kill()
            except Exception:
                pass
            self._sandbox = None
            self._started = False

    def close(self) -> None:
        """Close the sandbox."""
        if self._sandbox:
            self._sandbox.close()
            self._sandbox = None
            self._started = False

    @property
    def alive(self) -> bool:
        return self._started and self._sandbox is not None

    def _check(self) -> None:
        if not self.alive:
            raise RuntimeError("E2B sandbox is not running. Call start() first.")

    # ── File operations ──

    def write_file(self, path: str, content: str) -> str:
        """Write file inside sandbox (relative to project dir). Auto-lints .html/.js files."""
        self._check()
        full = f"{E2B_PROJECT_DIR}/{path.lstrip('/')}"
        # Ensure parent directory exists
        parent = "/".join(full.split("/")[:-1])
        if parent:
            try:
                self._sandbox.commands.run(f"mkdir -p {parent}")
            except Exception:
                pass
        self._sandbox.files.write(full, content)
        msg = f"Wrote {path} ({len(content)} bytes)"

        # Auto-lint .html and .js files
        lower = path.lower()
        if lower.endswith(".html") or lower.endswith(".js"):
            lint_result = self.lint_file(path)
            if lint_result.get("auto_fixed"):
                msg += f"\n[LINT] Auto-fixed {len(lint_result.get('fixed_issues', []))} issues"
            if not lint_result.get("lint_passed") and lint_result.get("errors"):
                errs = lint_result["errors"][:3]  # Cap at 3 errors shown
                msg += "\n[LINT] " + "; ".join(errs)
        return msg

    # ── Static analysis ──

    def lint_file(self, path: str) -> dict:
        """Run static analysis on a file inside the sandbox.

        For .html: extracts <script> content and runs node --check.
        For .js: runs node --check directly.
        Auto-fixes trivial issues (common typos, missing semicolons).

        Returns: {"lint_passed": bool, "errors": [...], "auto_fixed": bool, "fixed_issues": [...]}
        """
        self._check()
        lower = path.lower()
        result = {"lint_passed": True, "errors": [], "auto_fixed": False, "fixed_issues": []}

        if lower.endswith(".html"):
            # Extract JS from <script> tags and check syntax
            extract_and_check = r"""
import re, sys, json
html = open(sys.argv[1], encoding='utf-8', errors='replace').read()
scripts = re.findall(r'<script[^>]*>([\s\S]*?)</script>', html, re.IGNORECASE)
if not scripts:
    print(json.dumps({"ok": True, "errors": []}))
    sys.exit(0)
js = '\n'.join(scripts)
with open('/tmp/_lint_target.js', 'w') as f:
    f.write(js)
import subprocess
r = subprocess.run(['node', '--check', '/tmp/_lint_target.js'], capture_output=True, text=True, timeout=10)
if r.returncode == 0:
    print(json.dumps({"ok": True, "errors": []}))
else:
    errs = [l.strip() for l in (r.stderr or '').strip().split('\n') if l.strip()]
    print(json.dumps({"ok": False, "errors": errs[:5]}))
"""
            self._sandbox.files.write("/tmp/_lint_html.py", extract_and_check)
            full = f"{E2B_PROJECT_DIR}/{path.lstrip('/')}"
            try:
                r = self._sandbox.commands.run(f"python3 /tmp/_lint_html.py {full} 2>&1", timeout=15)
                stdout = (r.stdout or "").strip()
                import json as _json
                try:
                    parsed = _json.loads(stdout)
                    if not parsed.get("ok"):
                        result["lint_passed"] = False
                        result["errors"] = parsed.get("errors", [])
                        # Attempt auto-fix
                        fixed = self._auto_fix_js_in_html(path, result["errors"])
                        if fixed:
                            result["auto_fixed"] = True
                            result["fixed_issues"] = fixed
                            # Re-check after fix
                            r2 = self._sandbox.commands.run(f"python3 /tmp/_lint_html.py {full} 2>&1", timeout=15)
                            stdout2 = (r2.stdout or "").strip()
                            try:
                                p2 = _json.loads(stdout2)
                                result["lint_passed"] = p2.get("ok", False)
                                if not p2.get("ok"):
                                    result["errors"] = p2.get("errors", [])
                                else:
                                    result["errors"] = []
                            except (ValueError, _json.JSONDecodeError):
                                pass
                except (ValueError, _json.JSONDecodeError):
                    pass  # Can't parse lint output — skip silently
            except Exception:
                pass  # Lint failure is non-fatal

        elif lower.endswith(".js"):
            full = f"{E2B_PROJECT_DIR}/{path.lstrip('/')}"
            try:
                r = self._sandbox.commands.run(f"node --check {full} 2>&1", timeout=10)
                if r.exit_code != 0:
                    result["lint_passed"] = False
                    errs = [l.strip() for l in (r.stdout or r.stderr or "").strip().split("\n") if l.strip()]
                    result["errors"] = errs[:5]
                    # Attempt auto-fix
                    fixed = self._auto_fix_js(path, result["errors"])
                    if fixed:
                        result["auto_fixed"] = True
                        result["fixed_issues"] = fixed
                        r2 = self._sandbox.commands.run(f"node --check {full} 2>&1", timeout=10)
                        result["lint_passed"] = r2.exit_code == 0
                        if r2.exit_code != 0:
                            result["errors"] = [l.strip() for l in (r2.stdout or r2.stderr or "").strip().split("\n") if l.strip()][:5]
                        else:
                            result["errors"] = []
            except Exception:
                pass
        return result

    def _auto_fix_js_in_html(self, path: str, errors: list) -> list:
        """Attempt to auto-fix common JS errors inside an HTML file. Returns list of fixes applied."""
        full = f"{E2B_PROJECT_DIR}/{path.lstrip('/')}"
        try:
            content = self._sandbox.files.read(full)
            if isinstance(content, bytes):
                content = content.decode("utf-8", errors="replace")
        except Exception:
            return []
        original = content
        fixes = []
        # Common typo fixes
        _TYPO_MAP = {
            "fucntion": "function", "funciton": "function", "funtion": "function",
            "retrun": "return", "reutrn": "return",
            "cosnt": "const", "conts": "const",
            "lte": "let",
            "treu": "true", "flase": "false",
            "doucment": "document", "docuemnt": "document",
        }
        for typo, fix in _TYPO_MAP.items():
            if typo in content:
                content = content.replace(typo, fix)
                fixes.append(f"typo: {typo} → {fix}")
        if content != original:
            self._sandbox.files.write(full, content)
        return fixes

    def _auto_fix_js(self, path: str, errors: list) -> list:
        """Attempt to auto-fix common JS errors in a .js file."""
        return self._auto_fix_js_in_html(path, errors)  # Same logic works

    def read_file(self, path: str) -> str:
        """Read file from sandbox."""
        self._check()
        full = f"{E2B_PROJECT_DIR}/{path.lstrip('/')}"
        try:
            content = self._sandbox.files.read(full)
            if isinstance(content, bytes):
                content = content.decode("utf-8", errors="replace")
            return content
        except Exception as e:
            return f"Error reading {path}: {e}"

    def list_dir(self, path: str = ".") -> str:
        """List directory contents in sandbox."""
        self._check()
        if path == "." or not path:
            full = E2B_PROJECT_DIR
        else:
            full = f"{E2B_PROJECT_DIR}/{path.lstrip('/')}"
        try:
            result = self._sandbox.commands.run(f"ls -la {full} 2>&1")
            return result.stdout or "(empty)"
        except Exception as e:
            return f"Error listing {path}: {e}"

    def search_in_files(self, query: str, path: str = ".", max_results: int = 50) -> str:
        """Grep for text in project files."""
        self._check()
        if path == "." or not path:
            full = E2B_PROJECT_DIR
        else:
            full = f"{E2B_PROJECT_DIR}/{path.lstrip('/')}"
        try:
            result = self._sandbox.commands.run(
                f"grep -rn --include='*' -i '{query}' {full} 2>/dev/null | head -n {max_results}"
            )
            out = result.stdout or ""
            out = out.replace(E2B_PROJECT_DIR + "/", "")
            return out or f"No matches for '{query}'"
        except Exception as e:
            return f"No matches for '{query}' (search error: {e})"

    # ── Command execution ──

    def run_terminal(self, command: str, timeout: int = 300) -> str:
        """Run a shell command inside the sandbox project directory."""
        self._check()
        try:
            result = self._sandbox.commands.run(
                f"cd {E2B_PROJECT_DIR} && {command}",
                timeout=timeout,
            )
            out = result.stdout or ""
            err = result.stderr or ""
            if err:
                out = out + "\n[stderr]\n" + err
            return out.strip() or f"(exit {result.exit_code})"
        except Exception as e:
            return f"Error: {e}"

    def run_background(self, command: str) -> str:
        """Start a background process (e.g. dev server) in the sandbox."""
        self._check()
        try:
            self._sandbox.commands.run(
                f"cd {E2B_PROJECT_DIR} && nohup {command} > /tmp/server.log 2>&1 &",
                timeout=15,
            )
            time.sleep(2)  # Give server time to start
            return f"Started background process: {command}"
        except Exception:
            # Non-zero exit is expected for background processes — ignore
            time.sleep(2)
            return f"Started background process: {command}"

    # ── Screenshot via sandbox's internal browser ──

    def quick_verify(self, url_or_path: str) -> str:
        """Quick verification without screenshot - just check if server responds."""
        self._check()
        try:
            result = self._sandbox.commands.run(
                f"curl -s -o /dev/null -w '%{{http_code}}' -m 5 {url_or_path}",
                timeout=12,
            )
            code = (result.stdout or "").strip()
            if code.startswith("2") or code.startswith("3"):
                return f"Server responding (HTTP {code})"
            elif code == "000":
                return "Server not responding (connection refused)"
            else:
                return f"Server responded with HTTP {code}"
        except Exception:
            # curl exiting non-zero just means connection refused / timeout
            return "Server not responding yet"
    
    def take_screenshot(self, url_or_path: str, prompt: str = "") -> str:
        """Take screenshot of a URL. Tries curl-based quick verify first (fast),
        then playwright only if it's already installed (no install step)."""
        self._check()

        # Step 1: curl quick check — always fast, no dependencies
        quick = self.quick_verify(url_or_path)
        if "responding" in quick.lower():
            # Server is up; try playwright screenshot only if already installed
            capture_script = f"""
import sys, time
try:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
        page = browser.new_page(viewport={{'width': 1024, 'height': 768}})
        page.goto('{url_or_path}', timeout=10000, wait_until='domcontentloaded')
        time.sleep(1)
        page.screenshot(path='/tmp/screenshot.png')
        browser.close()
        print('SUCCESS')
except ImportError:
    print('NO_PLAYWRIGHT')
except Exception as e:
    print(f'ERROR: {{e}}')
"""
            try:
                self._sandbox.files.write("/tmp/capture.py", capture_script)
                result = self._sandbox.commands.run("python3 /tmp/capture.py 2>&1", timeout=20)
                stdout = result.stdout or ""
                if "SUCCESS" in stdout:
                    try:
                        img_bytes = self._sandbox.files.read("/tmp/screenshot.png")
                        if isinstance(img_bytes, str):
                            img_bytes = img_bytes.encode("latin-1")
                        import base64
                        b64 = base64.b64encode(img_bytes).decode("ascii")
                        return _analyze_screenshot_b64(b64, prompt or "Is this game/app working? Any visible errors?")
                    except Exception:
                        pass  # Fall through to text response
                if "NO_PLAYWRIGHT" in stdout:
                    return f"Server is responding at {url_or_path}. Playwright not installed — skipping visual check. Assume working."
            except Exception:
                pass  # Fall through
            return f"Server is responding at {url_or_path}. Visual screenshot unavailable. Assume working and proceed to manifest."
        else:
            return f"Server check: {quick}. If the server just started, assume it is working and proceed to manifest."

    # ── Search and replace ──

    def search_replace(self, path: str, old_string: str, new_string: str) -> str:
        """Replace text in a file inside the sandbox."""
        self._check()
        content = self.read_file(path)
        if content.startswith("Error reading"):
            return content
        if old_string not in content:
            return f"Error: old_string not found in {path}"
        new_content = content.replace(old_string, new_string)
        return self.write_file(path, new_content)

    def apply_patch(self, path: str, patch_content: str) -> str:
        """Apply a unified diff patch to a file."""
        self._check()
        full = f"{E2B_PROJECT_DIR}/{path.lstrip('/')}"
        self._sandbox.files.write("/tmp/patch.diff", patch_content)
        result = self._sandbox.commands.run(f"cd {E2B_PROJECT_DIR} && patch {full} /tmp/patch.diff 2>&1")
        return result.stdout or f"Patch applied to {path}"

    # ── Git state management ──

    def git_init(self) -> bool:
        """Initialize a Git repo in the project directory for checkpoint/rollback."""
        self._check()
        try:
            r = self._sandbox.commands.run(
                f"cd {E2B_PROJECT_DIR} && git init && git add -A && git commit -m 'init' --allow-empty 2>&1",
                timeout=15,
            )
            return r.exit_code == 0
        except Exception:
            return False

    def git_checkpoint(self, label: str = "") -> str | None:
        """Commit current state and return the commit hash, or None on failure."""
        self._check()
        msg = label or "checkpoint"
        try:
            r = self._sandbox.commands.run(
                f"cd {E2B_PROJECT_DIR} && git add -A && git commit -m '{msg}' --allow-empty 2>&1 && git rev-parse HEAD",
                timeout=15,
            )
            lines = [l.strip() for l in (r.stdout or "").strip().split("\n") if l.strip()]
            if lines:
                h = lines[-1]
                if len(h) >= 7 and all(c in "0123456789abcdef" for c in h[:7]):
                    return h
        except Exception:
            pass
        return None

    def git_rollback(self, commit_hash: str) -> bool:
        """Hard-reset to a specific commit."""
        self._check()
        try:
            r = self._sandbox.commands.run(
                f"cd {E2B_PROJECT_DIR} && git reset --hard {commit_hash} 2>&1",
                timeout=10,
            )
            return r.exit_code == 0
        except Exception:
            return False

    # ── Test execution ──

    def run_tests(self, test_script: str) -> dict:
        """Write and run a Node.js test script. Returns parsed JSON results.

        Returns: {"passed": N, "failed": N, "errors": [...]}
        """
        self._check()
        import json as _json
        self._sandbox.files.write("/tmp/_artemis_tests.js", test_script)
        try:
            r = self._sandbox.commands.run("node /tmp/_artemis_tests.js 2>&1", timeout=15)
            stdout = (r.stdout or "").strip()
            for line in reversed(stdout.split("\n")):
                line = line.strip()
                if line.startswith("{"):
                    try:
                        return _json.loads(line)
                    except (ValueError, _json.JSONDecodeError):
                        continue
            return {"passed": 0, "failed": 1, "errors": ["test_runner: no JSON output"]}
        except Exception as e:
            return {"passed": 0, "failed": 1, "errors": [f"test_runner: {e}"]}

    # ── Project download ──

    def download_project_zip(self, local_dest: Path) -> Path:
        """Zip the entire project inside sandbox and download to local path. Returns local zip path."""
        self._check()
        import uuid
        
        # Use unique filename to avoid Windows file locks
        unique_id = str(uuid.uuid4())
        zip_path_sandbox = f"/tmp/project_{unique_id}.zip"
        
        # Try zip command first, fall back to tar if zip not available
        try:
            result = self._sandbox.commands.run(
                f"cd {E2B_PROJECT_DIR} && zip -r {zip_path_sandbox} . -x '*.pyc' '__pycache__/*' 'node_modules/*' '.git/*' 2>&1",
                timeout=60,
            )
            if result.exit_code != 0:
                raise Exception("zip command failed")
        except Exception:
            # Fallback to tar
            self._sandbox.commands.run(
                f"cd {E2B_PROJECT_DIR} && tar -czf {zip_path_sandbox} --exclude='*.pyc' --exclude='__pycache__' --exclude='node_modules' --exclude='.git' . 2>&1",
                timeout=60,
            )
        
        try:
            zip_bytes = self._sandbox.files.read(zip_path_sandbox)
            if isinstance(zip_bytes, str):
                zip_bytes = zip_bytes.encode("latin-1")
            local_dest.parent.mkdir(parents=True, exist_ok=True)
            local_dest.write_bytes(zip_bytes)
            return local_dest
        except Exception as e:
            # Last resort: download files individually
            return self._download_files_individually(local_dest)

    def _download_files_individually(self, local_dest: Path) -> Path:
        """Fallback: download files individually and create zip."""
        import zipfile
        import tempfile
        import uuid
        
        self._check()
        # List all files
        result = self._sandbox.commands.run(f"find {E2B_PROJECT_DIR} -type f | head -200", timeout=30)
        
        # Use unique filename to avoid conflicts
        unique_id = str(uuid.uuid4())
        with tempfile.NamedTemporaryFile(suffix=f'_{unique_id}.zip', delete=False) as tmp_zip:
            with zipfile.ZipFile(tmp_zip.name, 'w', zipfile.ZIP_DEFLATED) as zf:
                if result.stdout:
                    for file_line in result.stdout.strip().split('\n'):
                        if file_line.strip():
                            rel_path = file_line.replace(E2B_PROJECT_DIR + '/', '')
                            try:
                                content = self._sandbox.files.read(file_line)
                                if isinstance(content, str):
                                    content = content.encode('utf-8', errors='replace')
                                zf.writestr(rel_path, content)
                            except Exception:
                                continue  # Skip files that can't be read
            
            # Move temp file to destination with retry
            import shutil
            import time
            import os
            local_dest.parent.mkdir(parents=True, exist_ok=True)
            
            # Retry file move in case of temporary locks
            for attempt in range(3):
                try:
                    shutil.move(tmp_zip.name, str(local_dest))
                    return local_dest
                except Exception as e:
                    if attempt == 2:
                        # Last resort - copy instead of move
                        shutil.copy2(tmp_zip.name, str(local_dest))
                        try:
                            os.unlink(tmp_zip.name)
                        except:
                            pass
                        return local_dest
                    time.sleep(0.5)  # Wait before retry

    def upload_folder(self, local_folder: Path) -> str:
        self._check()
        count = 0
        for local_file in local_folder.rglob("*"):
            if local_file.is_file():
                rel = local_file.relative_to(local_folder)
                # Skip common junk
                rel_str = str(rel).replace("\\", "/")
                if any(skip in rel_str for skip in ("node_modules/", "__pycache__/", ".git/", ".pyc")):
                    continue
                try:
                    content = local_file.read_text(encoding="utf-8", errors="replace")
                    self.write_file(rel_str, content)
                    count += 1
                except Exception:
                    # Binary file — read as bytes and write
                    try:
                        data = local_file.read_bytes()
                        full = f"{E2B_PROJECT_DIR}/{rel_str}"
                        parent = "/".join(full.split("/")[:-1])
                        self._sandbox.commands.run(f"mkdir -p {parent}")
                        self._sandbox.files.write(full, data)
                        count += 1
                    except Exception:
                        pass
        return f"Uploaded {count} files to sandbox"

    def get_file_tree(self) -> str:
        """Get a tree view of the project."""
        self._check()
        # Try tree command, fall back to find
        result = self._sandbox.commands.run(
            f"(command -v tree >/dev/null 2>&1 && tree {E2B_PROJECT_DIR} -I 'node_modules|__pycache__|.git') || "
            f"find {E2B_PROJECT_DIR} -not -path '*/node_modules/*' -not -path '*/__pycache__/*' -not -path '*/.git/*' | head -100"
        )
        out = (result.stdout or "").replace(E2B_PROJECT_DIR, ".")
        return out or "(empty project)"


def _analyze_screenshot_b64(b64_png: str, prompt: str) -> str:
    """Send screenshot to vision model for analysis. Optimized for speed."""
    from openartemis.config import get_anthropic_client, DEFAULT_BASE_MODEL
    
    client = get_anthropic_client()
    
    try:
        resp = client.messages.create(
            model=DEFAULT_BASE_MODEL,
            max_tokens=50,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": f"Quick check: {prompt} Just say 'WORKING' if it looks good, or describe the main issue if not. Be brief."},
                        {
                            "type": "image",
                            "source": {"type": "base64", "media_type": "image/png", "data": b64_png},
                        },
                    ],
                }
            ],
        )
        return resp.content[0].text or "(no analysis)"
    except Exception as e:
        return f"Vision analysis failed: {e}"


# ── Tool schemas for the AI agent (same format as agent_tools.py AGENT_TOOLS) ──

E2B_AGENT_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Write content to file in the cloud sandbox. Creates parent dirs. Path relative to project root.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path (e.g. index.html, src/app.js)"},
                    "content": {"type": "string", "description": "File content"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read file contents from the cloud sandbox.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "File path relative to project"}},
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_dir",
            "description": "List files and directories in the cloud sandbox.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "Directory path (default: .)", "default": "."}},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_in_files",
            "description": "Search for text in project files inside the cloud sandbox.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Text to search for"},
                    "path": {"type": "string", "description": "Directory to search in (default: .)", "default": "."},
                    "max_results": {"type": "integer", "description": "Max matches (default 50)", "default": 50},
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_background",
            "description": "Start background process (dev server) - MUCH FASTER than run_terminal for servers. Use for python -m http.server, npm start, etc.",
            "parameters": {
                "type": "object",
                "properties": {"command": {"type": "string", "description": "Command to run in background (no & needed)"}},
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_terminal",
            "description": "Run shell command in the cloud sandbox (Linux). Use for npm, python, pip, apt-get, gcc, etc. Any language/tool available on Linux.",
            "parameters": {
                "type": "object",
                "properties": {"command": {"type": "string", "description": "Shell command to run"}},
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "quick_verify",
            "description": "Quick verification without screenshot - just check if server responds. Fast alternative to take_screenshot.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url_or_path": {"type": "string", "description": "URL to check (e.g. http://localhost:8000)"},
                },
                "required": ["url_or_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "take_screenshot",
            "description": "Take screenshot of URL (e.g. http://localhost:8000) running in the sandbox. Sends to vision model for UI feedback.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url_or_path": {"type": "string", "description": "URL to capture (e.g. http://localhost:3000)"},
                    "prompt": {"type": "string", "description": "What to ask about the screenshot", "default": "Describe what you see. Any issues or improvements?"},
                },
                "required": ["url_or_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_replace",
            "description": "Replace old_string with new_string in a file. For small edits.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path"},
                    "old_string": {"type": "string", "description": "Exact string to replace"},
                    "new_string": {"type": "string", "description": "Replacement"},
                },
                "required": ["path", "old_string", "new_string"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "apply_patch",
            "description": "Apply unified diff patch to a file in the sandbox.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path"},
                    "patch_content": {"type": "string", "description": "Unified diff content"},
                },
                "required": ["path", "patch_content"],
            },
        },
    },
]


def execute_e2b_tool(sandbox: E2BSandbox, name: str, args: dict) -> str:
    """Execute a tool call against the E2B sandbox."""
    if name == "write_file":
        return sandbox.write_file(args.get("path", ""), args.get("content", ""))
    if name == "read_file":
        return sandbox.read_file(args.get("path", ""))
    if name == "list_dir":
        return sandbox.list_dir(args.get("path", "."))
    if name == "search_in_files":
        return sandbox.search_in_files(
            args.get("query", ""),
            args.get("path", "."),
            max_results=args.get("max_results", 50),
        )
    if name == "run_background":
        return sandbox.run_background(args.get("command", ""))
    if name == "run_terminal":
        return sandbox.run_terminal(args.get("command", ""))
    if name == "quick_verify":
        return sandbox.quick_verify(args.get("url_or_path", ""))
    if name == "take_screenshot":
        return sandbox.take_screenshot(
            args.get("url_or_path", ""),
            args.get("prompt", "Describe what you see. Any issues or improvements?"),
        )
    if name == "search_replace":
        return sandbox.search_replace(
            args.get("path", ""),
            args.get("old_string", ""),
            args.get("new_string", ""),
        )
    if name == "apply_patch":
        return sandbox.apply_patch(args.get("path", ""), args.get("patch_content", ""))
    return f"Unknown tool: {name}"
