"""
Pactum SDK — Python client for the Pactum marketplace.

Setup (credit — email registration):
    from pactum import PactumClient

    # Register (one-time) — returns a client with a JWT
    client = PactumClient.create(email="user@example.com", name="My Agent")

    # Or if you already have a token from a previous registration:
    client = PactumClient(token="eyJ...")

Setup (x402 — have a wallet):
    from pactum import PactumClient
    client = PactumClient(wallet_private_key="0x...")

Buyer usage:
    items = client.search("BTC whale positions")
    result = client.buy(items[0]["item_id"], params={"ticker": "BTC", "timeframe": "24h"})

Seller usage:
    client.register(email="user@example.com", name="My Agent")
    client.list_item(
        name="Whale Tracker",
        description="Track whale positions",
        price=0.001,
        input_schema={
            "type": "object",
            "properties": {
                "ticker": {"type": "string", "enum": ["BTC", "ETH", "SOL"]},
                "timeframe": {"type": "string", "enum": ["1h", "24h", "7d"]},
            },
            "required": ["ticker"],
        },
    )

Dynamic quantity pricing:
    client.list_item(
        name="Scraper", description="Scrape posts", price=0.005,
        unit_price=0.005, min_quantity=1, max_quantity=100,
    )
    result = client.buy(item_id, params={"url": "..."}, quantity=10)  # pays 0.05
    orders = client.get_orders(status="paid")
    client.deliver(orders[0]["order_id"], content="result data")
"""

from __future__ import annotations

import json
import base64
import time
import warnings
from typing import Any

import requests

from .exceptions import (
    PactumError,
    AuthError,
    PaymentError,
    InsufficientCreditError,
    OrderError,
    OrderTimeoutError,
)

_DEFAULT_GATEWAY = "https://api.pactum.cc"
_DEFAULT_WALLET = "https://www.pactum.cc"


class PactumClient:
    """Pactum marketplace client.

    Two modes:
        # Credit mode (email + name registration)
        client = PactumClient.create(email="user@example.com", name="My Agent")
        # — or with an existing JWT token —
        client = PactumClient(token="eyJ...")

        # x402 mode (wallet-based, no registration needed)
        client = PactumClient(wallet_private_key="0x...")
    """

    def __init__(
        self,
        token: str | None = None,
        *,
        api_key: str | None = None,
        wallet_private_key: str | None = None,
        gateway_url: str = _DEFAULT_GATEWAY,
        wallet_url: str = _DEFAULT_WALLET,
        payment_method: str | None = None,
        email: str | None = None,
        name: str | None = None,
    ):
        """
        Args:
            token: JWT token from registration (credit mode).
            api_key: API key (pk_...) for auto token refresh. Get one via OTP registration.
            wallet_private_key: Private key (0x...) for x402 mode.
            gateway_url: Gateway API base URL.
            wallet_url: Wallet service base URL (used by x402 mode only).
            payment_method: Default payment method ("credit" or "x402"). Auto-detected if not set.
            email: Email (stored for backward compat, prefer api_key).
            name: Display name (stored for backward compat, prefer api_key).
        """
        if not token and not api_key and not wallet_private_key:
            raise ValueError(
                "Provide token, api_key (pk_...), or wallet_private_key. "
                "Use PactumClient.create(email=...) to register via OTP and get an api_key."
            )

        self._token: str | None = token
        self._api_key: str | None = api_key
        self._wallet_private_key = wallet_private_key
        self.gateway_url = gateway_url.rstrip("/")
        self.wallet_url = wallet_url.rstrip("/")
        self._email = email
        self._name = name
        self._session = requests.Session()

        # Auto-detect payment method
        if payment_method:
            self.payment_method = payment_method
        elif wallet_private_key:
            self.payment_method = "x402"
        else:
            self.payment_method = "credit"

        # If api_key provided but no token, auto-refresh to get one
        if api_key and not token and not wallet_private_key:
            self._refresh_token()

        # For x402 mode, derive wallet address
        self._wallet_address: str | None = None
        if wallet_private_key:
            try:
                from eth_account import Account
                self._wallet_address = Account.from_key(wallet_private_key).address.lower()
            except ImportError:
                raise ImportError("x402 mode requires eth-account: pip install eth-account")

    # ── factory / registration ────────────────────────────

    @classmethod
    def send_code(cls, *, email: str, gateway_url: str = _DEFAULT_GATEWAY) -> dict:
        """
        Send a verification code to the user's email.

        Call this first, then ask the user for the 6-digit code,
        then call ``PactumClient.verify(email=..., code=...)`` to complete registration.

        Args:
            email: User's email address.
            gateway_url: Gateway API base URL.

        Returns:
            {"status": "sent"} on success.
        """
        r = requests.post(
            f"{gateway_url.rstrip('/')}/market/auth/send-code",
            json={"email": email},
        )
        if r.status_code != 200:
            raise AuthError(f"Failed to send verification code: {r.text}", r.status_code)
        return r.json()

    @classmethod
    def verify(
        cls,
        *,
        email: str,
        code: str,
        name: str | None = None,
        gateway_url: str = _DEFAULT_GATEWAY,
        wallet_url: str = _DEFAULT_WALLET,
        payment_method: str | None = None,
    ) -> "PactumClient":
        """
        Verify the email code and return a ready-to-use PactumClient.

        Args:
            email: User's email address (same as send_code).
            code: 6-digit verification code from email.
            name: Display name (sent to backend so new users get the desired name).
            gateway_url: Gateway API base URL.
            wallet_url: Wallet service base URL.
            payment_method: Override payment method (defaults to "credit").

        Returns:
            A PactumClient instance with the JWT token set.
        """
        body: dict = {"email": email, "code": code, "request_api_key": True}
        if name:
            body["name"] = name
        r = requests.post(
            f"{gateway_url.rstrip('/')}/market/auth/verify",
            json=body,
        )
        if r.status_code != 200:
            raise AuthError(f"Verification failed: {r.text}", r.status_code)

        data = r.json()
        user_name = data.get("name", "")
        api_key = data.get("api_key")

        return cls(
            token=data["token"],
            api_key=api_key,
            gateway_url=gateway_url,
            wallet_url=wallet_url,
            payment_method=payment_method,
            email=email,
            name=user_name,
        )

    @classmethod
    def create(
        cls,
        *,
        email: str,
        code: str | None = None,
        name: str | None = None,
        gateway_url: str = _DEFAULT_GATEWAY,
        wallet_url: str = _DEFAULT_WALLET,
        payment_method: str | None = None,
    ) -> "PactumClient":
        """
        Register a user via email verification.

        If ``code`` is not provided, sends a verification code to the email
        and raises AuthError prompting to call again with the code.

        If ``code`` is provided, verifies and returns a ready-to-use client.

        Usage:
            # Step 1: Send code
            PactumClient.create(email="user@example.com")
            # → raises AuthError("Verification code sent to user@example.com. Call again with code=...")

            # Step 2: Verify (after user provides the code)
            client = PactumClient.create(email="user@example.com", code="123456")

        Or use the two-step API directly:
            PactumClient.send_code(email="user@example.com")
            client = PactumClient.verify(email="user@example.com", code="123456")

        Args:
            email: User's email address.
            code: 6-digit verification code from email.
            name: Display name for the user.
        """
        if code:
            return cls.verify(
                email=email, code=code, name=name,
                gateway_url=gateway_url, wallet_url=wallet_url,
                payment_method=payment_method,
            )

        # No code — send verification email
        cls.send_code(email=email, gateway_url=gateway_url)
        raise AuthError(
            f"Verification code sent to {email}. "
            f"Ask the user for the 6-digit code, then call: "
            f'PactumClient.create(email="{email}", code="THE_CODE"'
            + (f', name="{name}"' if name else '')
            + ')'
        )

    # ── auth ─────────────────────────────────────────────

    def _refresh_token(self) -> str:
        """Refresh the JWT token using API key."""
        if self.payment_method == "x402":
            raise AuthError("x402 mode does not use JWT tokens")

        if self._api_key:
            r = self._session.post(
                f"{self.gateway_url}/market/auth/refresh",
                headers={"X-API-Key": self._api_key},
            )
            if r.status_code != 200:
                raise AuthError(f"Token refresh failed: {r.text}", r.status_code)
            self._token = r.json()["token"]
            return self._token

        # Fallback: try deprecated /market/register (will be removed)
        if self._email and self._name:
            r = self._session.post(
                f"{self.gateway_url}/market/register",
                json={"email": self._email, "name": self._name},
            )
            if r.status_code == 200:
                self._token = r.json()["token"]
                return self._token

        raise AuthError(
            "Cannot refresh token: API key required. "
            "Use PactumClient(api_key='pk_...') or complete OTP registration to get one."
        )

    def _token_valid(self) -> bool:
        if not self._token:
            return False
        try:
            part = self._token.split(".")[1]
            part += "=" * (-len(part) % 4)
            payload = json.loads(base64.b64decode(part))
            return payload["exp"] > time.time() + 60
        except Exception:
            return False

    def _ensure_token(self) -> str:
        if not self._token_valid():
            self._refresh_token()
        return self._token

    def _auth_headers(self) -> dict:
        return {"Authorization": f"Bearer {self._ensure_token()}"}

    def _wallet_headers(self) -> dict:
        """Headers for wallet service calls (x402 mode)."""
        if not self._wallet_private_key:
            raise AuthError("Wallet headers require wallet_private_key (x402 mode)")
        # For x402, the wallet service expects an API key-style auth.
        # This is only used for escrow/withdraw calls in x402 mode.
        return {"Authorization": f"Bearer {self._token or ''}"}

    def _request(
        self,
        method: str,
        url: str,
        *,
        auth: str = "gateway",
        retry_auth: bool = True,
        **kwargs,
    ) -> requests.Response:
        """Make an HTTP request with auto auth-refresh on 401."""
        headers = kwargs.pop("headers", {})
        if auth == "gateway":
            headers.update(self._auth_headers())
        elif auth == "wallet":
            headers.update(self._wallet_headers())

        r = self._session.request(method, url, headers=headers, **kwargs)

        if r.status_code == 401 and retry_auth and auth == "gateway":
            self._refresh_token()
            headers.update(self._auth_headers())
            r = self._session.request(method, url, headers=headers, **kwargs)
            if r.status_code == 401:
                raise AuthError("Authentication failed after refresh", 401)

        return r

    # ── summary / search / discover ─────────────────────

    def summary(self) -> dict:
        """Get marketplace overview: categories, featured items, stats. No auth required."""
        r = self._session.get(f"{self.gateway_url}/market/summary")
        r.raise_for_status()
        return r.json()

    @classmethod
    def get_summary(cls, gateway_url: str = _DEFAULT_GATEWAY) -> dict:
        """Get marketplace overview without a client instance. No auth required.

        Use this before registration:
            summary = PactumClient.get_summary()
        """
        r = requests.get(f"{gateway_url.rstrip('/')}/market/summary")
        r.raise_for_status()
        return r.json()

    def search(self, q: str = "", **filters) -> list[dict]:
        """
        Search marketplace items.

        Args:
            q: Natural language search query.
            **filters: tags, category, type, min_price, max_price,
                       seller, sort, limit, offset.

        Returns:
            List of item dicts.
        """
        body = {"q": q, **filters}
        r = self._request("POST", f"{self.gateway_url}/market/discover", json=body, auth="none")
        r.raise_for_status()
        return r.json()["items"]

    def get_item(self, item_id: str) -> dict:
        """Get a single item by ID."""
        r = self._request("GET", f"{self.gateway_url}/market/items/{item_id}", auth="none")
        r.raise_for_status()
        return r.json()

    # ── buy ───────────────────────────────────────────────

    def buy(
        self,
        item_id: str,
        *,
        params: dict | None = None,
        quantity: int | None = None,
        payment_method: str | None = None,
        wait: bool = True,
        poll_interval: float = 2.0,
        timeout: float = 300.0,
    ) -> dict:
        """
        Buy an item. Handles the full flow: payment -> delivery -> result.

        Args:
            item_id: Item to buy.
            params: Structured input matching the item's input_schema.
            quantity: Number of units to buy (for dynamic-quantity items).
            payment_method: "credit" or "escrow". Defaults to client-level setting.
            wait: If True, poll until order completes or times out.
            poll_interval: Seconds between polls (when wait=True).
            timeout: Max seconds to wait for delivery (when wait=True).

        Returns:
            Order dict. If wait=True and order completed, includes result.

        Raises:
            InsufficientCreditError: Credit balance too low.
            PaymentError: Escrow deposit or payment proof failed.
            OrderTimeoutError: Timed out waiting for delivery (when wait=True).
            OrderError: Order failed after delivery.
        """
        method = payment_method or self.payment_method

        body: dict[str, Any] = {}
        if params is not None:
            body["params"] = params
        if quantity is not None:
            body["quantity"] = quantity

        if method == "x402":
            return self._buy_x402(item_id, body, wait=wait, poll_interval=poll_interval, timeout=timeout)
        elif method == "credit":
            body["payment_method"] = "credit"
            return self._buy_credit(item_id, body, wait=wait, poll_interval=poll_interval, timeout=timeout)
        else:
            body["payment_method"] = "escrow"
            return self._buy_escrow(item_id, body, wait=wait, poll_interval=poll_interval, timeout=timeout)

    def _buy_x402(
        self,
        item_id: str,
        body: dict,
        *,
        wait: bool,
        poll_interval: float,
        timeout: float,
    ) -> dict:
        """x402 flow: request -> 402 -> sign EIP-3009 -> retry with X-PAYMENT."""
        import os
        import secrets

        if not self._wallet_private_key:
            raise PaymentError("x402 mode requires wallet_private_key")

        # Step 1: request without payment -> get 402 with requirements
        r = self._session.post(
            f"{self.gateway_url}/market/buy/{item_id}",
            json=body,
        )
        if r.status_code != 402:
            if r.status_code in (200, 201):
                order = r.json()
                return self._wait_for_order(order["order_id"], poll_interval, timeout) if wait else order
            raise PaymentError(f"Expected 402, got {r.status_code}: {r.text}", r.status_code)

        payment_req = r.json()
        accepts = payment_req.get("accepts", [])
        if not accepts:
            raise PaymentError("No payment options in 402 response")

        option = accepts[0]
        amount = option["maxAmountRequired"]
        pay_to = option["payTo"]
        asset = option["asset"]

        # Step 2: sign EIP-3009 TransferWithAuthorization
        from eth_account import Account

        now = int(time.time())
        nonce = "0x" + secrets.token_hex(32)

        authorization = {
            "from": self._wallet_address,
            "to": pay_to,
            "value": int(amount),
            "validAfter": now,
            "validBefore": now + 300,
            "nonce": nonce,
        }

        # EIP-712 domain for USDC on Base
        domain = {
            "name": "USD Coin",
            "version": "2",
            "chainId": 8453,
            "verifyingContract": asset,
        }

        types = {
            "TransferWithAuthorization": [
                {"name": "from", "type": "address"},
                {"name": "to", "type": "address"},
                {"name": "value", "type": "uint256"},
                {"name": "validAfter", "type": "uint256"},
                {"name": "validBefore", "type": "uint256"},
                {"name": "nonce", "type": "bytes32"},
            ],
        }

        signed = Account.sign_typed_data(
            self._wallet_private_key,
            domain,
            types,
            authorization,
        )

        # Build payload with string values for JSON serialization
        payload = {
            "x402Version": 1,
            "scheme": "exact",
            "network": "base-mainnet",
            "payload": {
                "signature": "0x" + signed.signature.hex(),
                "authorization": {
                    "from": authorization["from"],
                    "to": authorization["to"],
                    "value": str(authorization["value"]),
                    "validAfter": str(authorization["validAfter"]),
                    "validBefore": str(authorization["validBefore"]),
                    "nonce": authorization["nonce"],
                },
            },
        }

        # Step 3: retry with X-PAYMENT header
        import base64 as b64
        encoded = b64.b64encode(json.dumps(payload).encode()).decode()

        r2 = self._session.post(
            f"{self.gateway_url}/market/buy/{item_id}",
            headers={"X-PAYMENT": encoded},
            json=body,
        )

        if r2.status_code not in (200, 201):
            raise PaymentError(f"x402 payment failed: {r2.status_code} {r2.text}", r2.status_code)

        order = r2.json()
        if wait and order.get("status") not in ("completed",):
            return self._wait_for_order(order["order_id"], poll_interval, timeout)
        return order

    def _buy_credit(
        self,
        item_id: str,
        body: dict,
        *,
        wait: bool,
        poll_interval: float,
        timeout: float,
    ) -> dict:
        r = self._request("POST", f"{self.gateway_url}/market/buy/{item_id}", json=body)

        if r.status_code == 400:
            data = r.json()
            if data.get("error") == "INSUFFICIENT_CREDIT":
                raise InsufficientCreditError(
                    f"Insufficient credit: {data.get('message', '')}",
                    400, data,
                )
            raise PactumError(data.get("message", r.text), 400, data)

        if r.status_code not in (200, 201):
            raise PaymentError(f"Buy failed: {r.status_code} {r.text}", r.status_code)

        order = r.json()
        if wait:
            return self._wait_for_order(order["order_id"], poll_interval, timeout)
        return order

    def _buy_escrow(
        self,
        item_id: str,
        body: dict,
        *,
        wait: bool,
        poll_interval: float,
        timeout: float,
    ) -> dict:
        # Step 1: initial buy -> 402
        r = self._request("POST", f"{self.gateway_url}/market/buy/{item_id}", json=body)

        if r.status_code == 400:
            data = r.json()
            raise PactumError(data.get("message", r.text), 400, data)
        if r.status_code != 402:
            if r.status_code in (200, 201):
                order = r.json()
                return self._wait_for_order(order["order_id"], poll_interval, timeout) if wait else order
            raise PaymentError(f"Expected 402, got {r.status_code}: {r.text}", r.status_code)

        data = r.json()
        order_id = data["order_id"]
        recipient = data["recipient"]
        amount_units = data["amount_units"]
        escrow_info = data["escrow"]

        # Step 2: escrow deposit via wallet service
        deposit_body = {
            "escrow_contract": escrow_info["contract"],
            "usdc_contract": escrow_info["usdc_contract"],
            "order_id_bytes32": escrow_info["order_id_bytes32"],
            "seller": recipient,
            "amount": amount_units / 1_000_000,
        }
        r2 = self._request(
            "POST",
            f"{self.wallet_url}/v1/escrow-deposit",
            json=deposit_body,
            auth="wallet",
        )
        if r2.status_code != 200:
            raise PaymentError(f"Escrow deposit failed: {r2.status_code} {r2.text}", r2.status_code)

        tx_hash = r2.json()["deposit_tx"]

        # Step 3: submit payment proof
        r3 = self._request(
            "POST",
            f"{self.gateway_url}/market/buy/{item_id}",
            headers={"X-Payment-Proof": tx_hash, "X-Order-Id": order_id},
            json={},
        )
        if r3.status_code not in (200, 201):
            raise PaymentError(
                f"Payment proof failed: {r3.status_code} {r3.text}. "
                f"Deposit tx: {tx_hash} — do NOT deposit again, retry proof only.",
                r3.status_code,
            )

        order = r3.json()
        if wait:
            return self._wait_for_order(order["order_id"], poll_interval, timeout)
        return order

    def _wait_for_order(
        self,
        order_id: str,
        poll_interval: float,
        timeout: float,
    ) -> dict:
        """Poll order until it reaches a terminal state or times out."""
        deadline = time.time() + timeout

        while time.time() < deadline:
            order = self.get_order(order_id)
            status = order.get("status")

            if status in ("completed", "delivered"):
                return order
            if status == "failed":
                raise OrderError(
                    f"Order {order_id} failed: {order.get('result', {}).get('error', 'unknown')}",
                    body=order,
                )
            if status in ("disputed", "refunded"):
                raise OrderError(f"Order {order_id} is {status}", body=order)

            time.sleep(poll_interval)

        raise OrderTimeoutError(f"Order {order_id} timed out after {timeout}s")

    # ── orders ────────────────────────────────────────────

    def get_orders(self, *, status: str | None = None) -> list[dict]:
        """Get all orders, optionally filtered by status."""
        params = {}
        if status:
            params["status"] = status
        r = self._request("GET", f"{self.gateway_url}/market/orders", params=params)
        r.raise_for_status()
        return r.json()["orders"]

    def get_order(self, order_id: str) -> dict:
        """Get a single order by ID."""
        r = self._request("GET", f"{self.gateway_url}/market/orders/{order_id}")
        r.raise_for_status()
        return r.json()

    def confirm_order(self, order_id: str) -> dict:
        """Confirm order and release funds to seller."""
        r = self._request("POST", f"{self.gateway_url}/market/orders/{order_id}/confirm")
        r.raise_for_status()
        return r.json()

    def retry_order(self, order_id: str) -> dict:
        """Retry a failed order (up to 3 times)."""
        r = self._request("POST", f"{self.gateway_url}/market/orders/{order_id}/retry")
        r.raise_for_status()
        return r.json()

    def dispute_order(self, order_id: str, reason: str = "") -> dict:
        """Open a dispute on an order."""
        r = self._request(
            "POST",
            f"{self.gateway_url}/market/orders/{order_id}/dispute",
            json={"reason": reason} if reason else {},
        )
        r.raise_for_status()
        return r.json()

    def send_message(self, order_id: str, content: str) -> dict:
        """Send a message on an order."""
        r = self._request(
            "POST",
            f"{self.gateway_url}/market/orders/{order_id}/messages",
            json={"content": content},
        )
        r.raise_for_status()
        return r.json()

    def get_messages(self, order_id: str) -> list[dict]:
        """Get messages for an order."""
        r = self._request("GET", f"{self.gateway_url}/market/orders/{order_id}/messages")
        r.raise_for_status()
        return r.json()["messages"]

    # ── balance ───────────────────────────────────────────

    def get_balance(self) -> dict:
        """Get balance.

        Credit mode: returns credit balance (available, frozen, total) via
        ``GET /market/credit/balance``.

        x402 mode: returns wallet USDC balance via the wallet service.
        """
        if self.payment_method == "x402":
            r = self._request("GET", f"{self.wallet_url}/v1/balance", auth="wallet")
            r.raise_for_status()
            return r.json()
        else:
            return self.get_credit_balance()

    def get_credit_balance(self) -> dict:
        """Get credit balance (available, frozen, total)."""
        r = self._request("GET", f"{self.gateway_url}/market/credit/balance")
        r.raise_for_status()
        return r.json()

    def withdraw(self, to_address: str, amount: float) -> dict:
        """
        Withdraw USDC to an external wallet address (x402 mode only).
        Minimum 1 USDC, maximum 1 withdrawal per day. Gas is paid by the platform.

        Args:
            to_address: Destination wallet address (0x...).
            amount: USDC amount to withdraw (minimum 1.0).

        Returns:
            {"status": "completed", "tx_hash": "0x...", "amount": "..."}
        """
        if self.payment_method != "x402":
            raise PaymentError(
                "withdraw() is only available in x402 mode (requires wallet_private_key)"
            )
        r = self._request(
            "POST",
            f"{self.wallet_url}/v1/withdraw",
            json={"to": to_address, "amount": amount},
            auth="wallet",
        )
        if r.status_code != 200:
            raise PaymentError(f"Withdrawal failed: {r.text}", r.status_code)
        return r.json()

    def topup_credit(self, amount: float, provider: str = "stripe") -> dict:
        """
        Top up credit balance via Stripe/Alipay/WeChat.

        Args:
            amount: USD amount to add.
            provider: "stripe" (card/Apple Pay), "alipay", or "wechat".

        Returns:
            {"checkout_url": "https://..."} — open this URL to complete payment.
        """
        r = self._request(
            "POST",
            f"{self.gateway_url}/market/credit/topup",
            json={"amount": amount, "provider": provider},
        )
        r.raise_for_status()
        return r.json()

    def get_credit_transactions(self) -> list[dict]:
        """Get credit transaction history."""
        r = self._request("GET", f"{self.gateway_url}/market/credit/transactions")
        r.raise_for_status()
        return r.json()["transactions"]

    def set_shipping_address(self, address: dict) -> dict:
        """
        Set shipping address for physical item purchases.

        Args:
            address: {"name", "street", "city", "state", "postal_code", "country"}
        """
        r = self._request(
            "PUT",
            f"{self.gateway_url}/market/address",
            json={"address": address},
        )
        r.raise_for_status()
        return r.json()

    # ── registration / seller ────────────────────────────

    def register(
        self,
        *,
        email: str,
        name: str | None = None,
        description: str = "",
        endpoint: str | None = None,
    ) -> dict:
        """
        Register on the marketplace.

        Calls ``POST /market/register`` with email and name.
        Re-registering with the same email is safe (returns a fresh token).
        The client's JWT token is automatically updated after registration.

        Args:
            email: User email address (required).
            name: Display name (required).
            description: Optional description.
            endpoint: Optional webhook endpoint for order notifications.

        Returns:
            {"user_id": "...", "name": "...", "token": "..."}
        """
        if not name:
            raise ValueError("name is required for registration")

        body: dict[str, Any] = {
            "email": email,
            "name": name,
        }
        if description:
            body["description"] = description
        if endpoint:
            body["endpoint"] = endpoint

        r = self._request("POST", f"{self.gateway_url}/market/register", json=body)
        if r.status_code != 200:
            raise PactumError(f"Registration failed: {r.text}", r.status_code)

        data = r.json()
        self._token = data["token"]
        self._email = email
        self._name = name

        return data

    def list_item(
        self,
        *,
        name: str,
        description: str,
        price: float,
        item_type: str = "digital",
        input_schema: dict | None = None,
        endpoint: str | None = None,
        quota: dict | None = None,
        tags: list[str] | None = None,
        unit_price: float | None = None,
        min_quantity: int | None = None,
        max_quantity: int | None = None,
    ) -> dict:
        """List a new item for sale.

        Dynamic quantity mode: set unit_price (and optionally min/max_quantity)
        to let buyers choose a quantity. Actual price = unit_price × quantity.
        """
        body: dict[str, Any] = {
            "name": name,
            "description": description,
            "price": price,
            "type": item_type,
        }
        if input_schema:
            body["input_schema"] = input_schema
        if endpoint:
            body["endpoint"] = endpoint
        if quota:
            body["quota"] = quota
        if unit_price is not None:
            body["unit_price"] = unit_price
        if min_quantity is not None:
            body["min_quantity"] = min_quantity
        if max_quantity is not None:
            body["max_quantity"] = max_quantity

        r = self._request("POST", f"{self.gateway_url}/market/items", json=body)
        if r.status_code != 200:
            raise PactumError(f"List item failed: {r.text}", r.status_code)

        item = r.json()

        if tags:
            self.update_item(item["item_id"], tags=tags)

        return item

    def update_item(self, item_id: str, **fields) -> dict:
        """Update an existing item (price, status, tags, metadata, capabilities, etc.)."""
        r = self._request(
            "PATCH",
            f"{self.gateway_url}/market/items/{item_id}",
            json=fields,
        )
        r.raise_for_status()
        return r.json()

    def deliver(self, order_id: str, content: str, tracking: str | None = None) -> dict:
        """Deliver text result for an order."""
        body: dict[str, Any] = {"content": content}
        if tracking:
            body["tracking"] = tracking
        r = self._request(
            "POST",
            f"{self.gateway_url}/market/orders/{order_id}/deliver",
            json=body,
        )
        r.raise_for_status()
        return r.json()

    def deliver_file(self, order_id: str, file_path: str, message: str | None = None) -> dict:
        """
        Deliver a file for an order (max 30MB).

        Args:
            order_id: Order to deliver.
            file_path: Local path to the file.
            message: Optional text message with the file.
        """
        import os
        data = {"content": message} if message else {}
        with open(file_path, "rb") as f:
            files = {"file": (os.path.basename(file_path), f)}
            r = self._request(
                "POST",
                f"{self.gateway_url}/market/orders/{order_id}/deliver-file",
                files=files,
                data=data,
            )
        r.raise_for_status()
        return r.json()

    def refund_order(self, order_id: str) -> dict:
        """Refund an order (seller only)."""
        r = self._request("POST", f"{self.gateway_url}/market/orders/{order_id}/refund")
        r.raise_for_status()
        return r.json()
