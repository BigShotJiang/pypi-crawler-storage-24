from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image


@dataclass(slots=True)
class PNGOutput:
    """PNG 输出结果"""
    comparison_path: Path
    before_path: Path
    after_path: Path


def save_png(image: np.ndarray, path: Path) -> Path:
    """保存 PNG 图片"""
    path.parent.mkdir(parents=True, exist_ok=True)
    img = Image.fromarray(image, mode="RGBA")
    img.save(path, "PNG")
    return path


import matplotlib.pyplot as plt

from nrdp.domain.visualization import (
    VisualizationConfig,
    extract_slice_range,
    prepare_slice_image,
    render_isometric_stack,
)


def generate_sample_png(
    patient_id: str,
    original_data: np.ndarray,
    original_label: np.ndarray,
    expanded_data: np.ndarray,
    expanded_label: np.ndarray,
    axis: int,
    tumor_indices: list[int],
    output_dir: Path,
    config: VisualizationConfig,
) -> PNGOutput:
    """为单个样本生成3张PNG图片"""
    output_dir.mkdir(parents=True, exist_ok=True)

    # 提取原始切片范围
    slice_range = extract_slice_range(tumor_indices)
    if slice_range is None:
        # 无肿瘤，生成空图
        empty = np.zeros((100, 100, 4), dtype=np.uint8)
        return PNGOutput(
            comparison_path=save_png(empty, output_dir / "comparison.png"),
            before_path=save_png(empty, output_dir / "before.png"),
            after_path=save_png(empty, output_dir / "after.png"),
        )

    # 准备原始切片图像列表
    before_slices = []
    for i in range(slice_range.start, slice_range.end + 1):
        data_slice = np.take(original_data, i, axis=axis)
        label_slice = np.take(original_label, i, axis=axis)
        before_slices.append(prepare_slice_image(data_slice, label_slice))

    # 准备扩展后切片图像列表（按比例映射）
    after_slices = []
    expansion_ratio = expanded_data.shape[axis] / original_data.shape[axis]
    for i in range(slice_range.start, slice_range.end + 1):
        expanded_i = int(i * expansion_ratio)
        expanded_i = min(expanded_i, expanded_data.shape[axis] - 1)
        data_slice = np.take(expanded_data, expanded_i, axis=axis)
        label_slice = np.take(expanded_label, expanded_i, axis=axis)
        after_slices.append(prepare_slice_image(data_slice, label_slice))

    # 渲染并保存
    before_image = render_isometric_stack(before_slices, config)
    after_image = render_isometric_stack(after_slices, config)

    # 生成对比图（左右并排）
    comparison_image = render_comparison_image(
        before_image,
        after_image,
        {"title": "Before", "total_slices": original_data.shape[axis], "tumor_slices": len(tumor_indices)},
        {"title": "After", "total_slices": expanded_data.shape[axis], "tumor_slices": int(len(tumor_indices) * expansion_ratio)},
    )

    return PNGOutput(
        comparison_path=save_png(comparison_image, output_dir / "comparison.png"),
        before_path=save_png(before_image, output_dir / "before.png"),
        after_path=save_png(after_image, output_dir / "after.png"),
    )


def render_comparison_image(
    before_image: np.ndarray,
    after_image: np.ndarray,
    before_info: dict,
    after_info: dict,
) -> np.ndarray:
    """渲染左右对比图，底部带标题和统计信息"""
    # 计算画布大小
    max_height = max(before_image.shape[0], after_image.shape[0])
    total_width = before_image.shape[1] + after_image.shape[1]

    title_height = 80

    plt.switch_backend("agg")
    # 设置支持中文的字体
    plt.rcParams["font.family"] = ["Droid Sans Fallback", "DejaVu Sans"]
    fig, axes = plt.subplots(
        1, 2,
        figsize=(total_width / 100, (max_height + title_height) / 100),
        dpi=100,
    )
    fig.patch.set_facecolor("black")

    # 左侧： 插值前
    axes[0].imshow(before_image)
    axes[0].axis("off")
    axes[0].set_title(
        f"{before_info['title']}\nSlices: {before_info['total_slices']} | Tumor: {before_info['tumor_slices']}",
        color="white",
        fontsize=10,
    )

    # 右侧: 插值后
    axes[1].imshow(after_image)
    axes[1].axis("off")
    axes[1].set_title(
        f"{after_info['title']}\nSlices: {after_info['total_slices']} | Tumor: {after_info['tumor_slices']}",
        color="white",
        fontsize=10,
    )

    plt.tight_layout()

    # 转换为 numpy 数组
    fig.canvas.draw()
    result = np.frombuffer(fig.canvas.buffer_rgba(), dtype=np.uint8)
    result = result.reshape(fig.canvas.get_width_height()[::-1] + (4,))
    plt.close(fig)

    return result
