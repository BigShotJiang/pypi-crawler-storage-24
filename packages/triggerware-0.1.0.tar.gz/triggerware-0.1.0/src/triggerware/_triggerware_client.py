from typing import TYPE_CHECKING

from jayson_rpc import JsonRpcConnection, JsonRpcStreamConnection, JsonRpcWebSocketConnection
from ._queries import View

if TYPE_CHECKING:
    import triggerware as tw

class TriggerwareClient:
    """A TriggerwareClient provides a connection to a triggerware server. A client contains methods for
    issuing a few specific requests that are supported by any Triggerware server. Classes that extend
    TriggerwareClient for specific applications will implement their own application-specific methods
    to make requests that are idiosyncratic to a Triggerware server for that application.

    A TriggerwareClient can also manage Subscriptions. By subscribing to certain kinds of changes,
    the client arranges to be notified when these changes occur in the data accessible to the server.
    """

    def __init__(self, json_rpc: JsonRpcConnection):
        self.json_rpc = json_rpc

        self._batch_sub_counter = 0
        self._sub_counter = 0
        self._poll_counter = 0
        self._handles: list[int] = []

        self.sql_mode: str = "fol"
        self.default_fol_schema: str | None = None
        self.default_sql_schema: str | None = None
        self.default_fetch_size: int | None = None
        self.default_timeout: float | None = None

    @classmethod
    async def connect_tcp(cls, host: str, port: int) -> "TriggerwareClient":
        """Connect to a Triggerware server over TCP.

        Args:
            host: The server host.
            port: The server port.
        """
        json_rpc = await JsonRpcStreamConnection.connect(host, port)
        return cls(json_rpc)

    @classmethod
    async def connect_ws(cls, instance: str, api_key: str) -> "TriggerwareClient":
        """Connect to a Triggerware server over WebSocket.

        Args:
            uri: The WebSocket URI to connect to.
        """
        uri = "ws://tw-instance-load-balancer-194323221.us-east-2.elb.amazonaws.com"
        json_rpc = await JsonRpcWebSocketConnection.connect(
            uri,
            headers={
                "TW-Instance": instance,
                "Authorization": f"Bearer {api_key}",
            }
        )
        return cls(json_rpc)

    async def execute_query(
        self,
        query: "tw.Query | str",
        restriction: "tw.ResourceRestricted | None" = None,
    ) -> "tw.ResultSet":
        """Executes a query on the connected server.

        Args:
            query: The query to execute.
            restriction: Optional restrictions to apply to the query.

        Returns:
            tw.ResultSet: The result set from the server.

        Raises:
            InvalidQueryException: If the query is invalid.
            InternalErrorException: If an internal error occurs.
            ServerErrorException: If a server error occurs.
        """
        view = View(self, query, restriction)
        return await view.execute()

    async def validate_query(self, query: "tw.Query | str"):
        """Validate a query string on the server. This method will raise an InvalidQueryException if
        the query contains errors.

        Args:
            query: The query to validate.

        Raises:
            InvalidQueryException: If the query is invalid.
            InternalErrorException: If an internal error occurs.
            ServerErrorException: If a server error occurs.
        """
        return await View(self, query).validate()

    async def close(self):
        """
        Closes the connection to the server.
        """
        await self.json_rpc.close()

    @property
    def is_closed(self) -> bool:
        return self.json_rpc.is_closed

    def register_handle(self, handle: int):
        """Register a handle with this client. Not meant for external use.

        Args:
            handle (int): The handle to register.
        """
        self._handles.append(handle)

__all__ = ["TriggerwareClient"]
