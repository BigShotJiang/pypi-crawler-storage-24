"""
protfunc — Python SDK for the POOL / GRASP-Func protein functional site prediction server.

Quick start::

    from protfunc import Client

    client = Client(base_url="https://your-server.northeastern.edu")

    # Run POOL
    results = client.run_pool("./structures/")

    # Run full GRASP-Func pipeline
    results = client.run_graspfunc("./input/", known_proteins=["1a2b"])
"""

from .client import Client, ProtFuncError, ProgressEvent, Status

__version__ = "0.1.1"
__all__ = ["Client", "ProtFuncError", "ProgressEvent", "Status"]