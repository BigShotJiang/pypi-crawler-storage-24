"""Basic chat example with PharmaAgent.

Demonstrates single-query usage with structured response handling.

Usage:
    export OPENAI_API_KEY=sk-...
    python examples/basic_chat.py
"""

from pharma_ai_agent import PharmaAgent

# Initialize the agent
agent = PharmaAgent(
    provider="openai",  # or "anthropic"
    api_key="",         # Uses env var if empty
    locale="en",
    strict_mode=True,
)

# Print knowledge base stats
stats = agent.knowledge_stats
print(f"Knowledge base: {stats['drug_interactions']} interactions, "
      f"{stats['supplement_profiles']} supplements\n")

# Ask a question
query = "Can I take ibuprofen with warfarin?"
print(f"Q: {query}")
print("-" * 50)

response = agent.ask(query)

print(f"Answer: {response.answer}\n")

if response.interactions:
    print("Interactions found:")
    for interaction in response.interactions:
        print(f"  [{interaction['severity'].upper()}] "
              f"{interaction['drug_a']} + {interaction['drug_b']}")
        print(f"  {interaction['patient_description']}")
    print()

if response.sources:
    print("Sources:")
    for source in response.sources:
        print(f"  - {source}")
    print()

print(f"Safety score: {response.safety_score}")
print(f"Tools used: {response.tool_calls_made}")
