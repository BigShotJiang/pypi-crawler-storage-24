"""Custom knowledge base extension example.

Demonstrates how to add custom drug interaction data to the knowledge base.

Usage:
    python examples/custom_knowledge.py
"""

from pharma_ai_agent import PharmaAgent
from pharma_ai_agent.knowledge.drug_db import DrugInteraction, DRUG_INTERACTIONS
from pharma_ai_agent.knowledge.retriever import KnowledgeRetriever

# Add a custom interaction to the knowledge base
custom_interaction = DrugInteraction(
    drug_a="CustomDrugA",
    drug_b="CustomDrugB",
    severity="moderate",
    mechanism="CustomDrugA inhibits CYP enzymes that metabolize CustomDrugB.",
    clinical_description="Elevated CustomDrugB levels may cause side effects.",
    patient_description="These two medications may interact. Your doctor should "
    "monitor you if you take both.",
    management="Monitor blood levels and adjust dose as needed.",
    sources=["Internal Clinical Database"],
    aliases_a=["BrandNameA"],
    aliases_b=["BrandNameB"],
)

# Add to the global list
DRUG_INTERACTIONS.append(custom_interaction)

# Create a new retriever that includes the custom data
retriever = KnowledgeRetriever()

# Verify the custom interaction is searchable
interactions = retriever.find_interactions("CustomDrugA", "CustomDrugB")
print(f"Found custom interaction: {len(interactions) > 0}")
if interactions:
    print(f"  Severity: {interactions[0].severity}")
    print(f"  Mechanism: {interactions[0].mechanism}")

# Use with agent
agent = PharmaAgent(provider="openai", api_key="")

# The agent will now include the custom interaction in its knowledge base
results = agent.check_medications(["CustomDrugA", "CustomDrugB"])
for pair, result in results.items():
    print(f"\n{pair[0]} + {pair[1]}:")
    print(f"  Found: {result['found']}")
    print(f"  Severity: {result['severity']}")

# Clean up: remove the custom interaction
DRUG_INTERACTIONS.pop()
print("\nCustom interaction removed.")
