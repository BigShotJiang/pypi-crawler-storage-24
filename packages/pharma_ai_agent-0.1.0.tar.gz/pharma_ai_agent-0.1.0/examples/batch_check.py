"""Batch medication interaction check example.

Checks all pairwise interactions among a list of medications.

Usage:
    python examples/batch_check.py
"""

from pharma_ai_agent import PharmaAgent

agent = PharmaAgent(provider="openai", api_key="")

# List of medications a patient might be taking
medications = [
    "warfarin",
    "ibuprofen",
    "vitamin D",
    "fish oil",
    "omeprazole",
]

print(f"Checking interactions among {len(medications)} medications:")
print(f"  {', '.join(medications)}\n")
print("=" * 60)

results = agent.check_medications(medications)

# Sort by severity
severity_order = {"major": 0, "moderate": 1, "minor": 2, "none": 3}
sorted_results = sorted(
    results.items(),
    key=lambda x: severity_order.get(x[1].get("severity", "none"), 99),
)

found_count = 0
for (drug_a, drug_b), result in sorted_results:
    if result["found"]:
        found_count += 1
        severity = result["severity"].upper()
        icon = {"MAJOR": "!!!", "MODERATE": "!!", "MINOR": "!"}
        print(f"\n[{icon.get(severity, '?')} {severity}] {drug_a} + {drug_b}")
        print(f"  {result.get('patient_description', result.get('description', 'N/A'))}")
        if result.get("management"):
            print(f"  Management: {result['management']}")
        if result.get("sources"):
            print(f"  Sources: {', '.join(result['sources'][:2])}")

print(f"\n{'=' * 60}")
print(f"Found {found_count} interaction(s) out of {len(results)} pairs checked.")
print("\nDISCLAIMER: This is for educational purposes only. "
      "Consult your healthcare provider.")
