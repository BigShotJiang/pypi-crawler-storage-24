"""Auto-disclaimer injection for agent responses."""

from __future__ import annotations

from typing import Literal

DISCLAIMER_EN = (
    "DISCLAIMER: This information is for educational purposes only and does not "
    "constitute medical advice. Always consult a qualified healthcare provider "
    "(doctor, pharmacist, or other medical professional) before making any "
    "decisions about your medications or supplements. Do not start, stop, or "
    "change the dosage of any medication without professional guidance."
)

DISCLAIMER_KO = (
    "면책 조항: 이 정보는 교육 목적으로만 제공되며 의학적 조언을 구성하지 않습니다. "
    "약물이나 영양제에 대한 결정을 내리기 전에 반드시 자격을 갖춘 의료 전문가 "
    "(의사, 약사 또는 기타 의료 전문가)와 상담하십시오. 전문가의 지도 없이 "
    "약물의 복용을 시작, 중단 또는 용량을 변경하지 마십시오."
)

DISCLAIMER_SHORT_EN = (
    "This is not medical advice. Consult your doctor or pharmacist."
)

DISCLAIMER_SHORT_KO = (
    "이 정보는 의학적 조언이 아닙니다. 의사 또는 약사와 상담하세요."
)


class DisclaimerInjector:
    """Automatically appends medical disclaimers to agent responses.

    Args:
        locale: Language locale ("en" or "ko").
        short: Use short disclaimer format.
    """

    def __init__(
        self,
        locale: Literal["en", "ko"] = "en",
        short: bool = False,
    ) -> None:
        self.locale = locale
        self.short = short

    @property
    def disclaimer(self) -> str:
        """Get the disclaimer text for the configured locale."""
        if self.locale == "ko":
            return DISCLAIMER_SHORT_KO if self.short else DISCLAIMER_KO
        return DISCLAIMER_SHORT_EN if self.short else DISCLAIMER_EN

    def inject(self, response: str) -> str:
        """Append disclaimer to a response if not already present.

        Args:
            response: The agent's response text.

        Returns:
            Response with disclaimer appended.
        """
        # Check if a disclaimer is already present
        disclaimer_markers = [
            "disclaimer",
            "not medical advice",
            "consult your doctor",
            "consult a qualified",
            "healthcare provider",
            "의학적 조언",
            "면책 조항",
            "의료 전문가",
        ]

        response_lower = response.lower()
        if any(marker in response_lower for marker in disclaimer_markers):
            return response

        separator = "\n\n---\n\n" if "\n" in response else "\n\n"
        return f"{response}{separator}{self.disclaimer}"
