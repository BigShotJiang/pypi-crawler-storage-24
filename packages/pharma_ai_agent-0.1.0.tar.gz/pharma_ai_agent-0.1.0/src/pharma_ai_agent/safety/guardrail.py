"""Safety guardrail integration.

Provides pre-check (query validation) and post-check (response validation)
safety layers. Integrates with llm-medical-guard when available,
with a built-in fallback for basic safety checks.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Literal


@dataclass
class SafetyCheckResult:
    """Result of a safety check."""

    safe: bool
    score: float  # 0.0 = unsafe, 1.0 = safe
    flags: list[str] = field(default_factory=list)
    action: Literal["allow", "warn", "block"] = "allow"

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "safe": self.safe,
            "score": self.score,
            "flags": self.flags,
            "action": self.action,
        }


# Patterns that indicate potentially harmful queries
_HARMFUL_PATTERNS = [
    (r"\b(?:overdose|OD)\b.*\b(?:how|method|way)\b", "overdose_inquiry"),
    (r"\b(?:suicide|self.?harm|kill\s*(?:my)?self)\b", "self_harm"),
    (r"\bhow\s+(?:much|many).*\b(?:die|kill|lethal|fatal)\b", "lethal_dose_inquiry"),
    (r"\b(?:get\s+high|abuse|recreational)\b.*\b(?:drug|med|pill)\b", "drug_abuse"),
    (r"\b(?:make|synthesize|produce|manufacture)\b.*\b(?:drug|meth|fentanyl)\b", "drug_synthesis"),
]

# Patterns that indicate the response may contain unsafe medical advice
_UNSAFE_RESPONSE_PATTERNS = [
    (r"\b(?:you\s+should\s+(?:stop|quit|discontinue))\b.*\bmedication\b", "unsupervised_discontinuation"),
    (r"\b(?:definitely|certainly|guaranteed)\b.*\b(?:safe|harmless|fine)\b", "false_assurance"),
    (r"\b(?:don't\s+need|skip|ignore)\b.*\b(?:doctor|physician|prescriber)\b", "discouraging_medical_care"),
    (r"\b(?:diagnos|you\s+have|you\s+suffer)\b", "unauthorized_diagnosis"),
]


class SafetyGuardrail:
    """Safety guardrail for pre-check and post-check validation.

    Attempts to use llm-medical-guard if installed, falls back to
    built-in pattern matching.

    Args:
        strict_mode: If True, apply stricter thresholds and block more aggressively.
    """

    def __init__(self, strict_mode: bool = True) -> None:
        self.strict_mode = strict_mode
        self._guard = self._try_load_guard()

    @staticmethod
    def _try_load_guard():
        """Try to load llm-medical-guard. Returns None if not available."""
        try:
            from llm_medical_guard import MedicalGuard  # type: ignore[import-untyped]
            return MedicalGuard()
        except ImportError:
            return None

    def pre_check(self, query: str) -> SafetyCheckResult:
        """Validate a user query before processing.

        Checks for harmful intent patterns.

        Args:
            query: User's input query.

        Returns:
            SafetyCheckResult indicating whether to proceed.
        """
        flags: list[str] = []

        # Pattern matching check
        query_lower = query.lower()
        for pattern, flag_name in _HARMFUL_PATTERNS:
            if re.search(pattern, query_lower, re.IGNORECASE):
                flags.append(flag_name)

        if flags:
            return SafetyCheckResult(
                safe=False,
                score=0.0,
                flags=flags,
                action="block",
            )

        # Try llm-medical-guard if available
        if self._guard is not None:
            try:
                result = self._guard.check_query(query)
                return SafetyCheckResult(
                    safe=result.safe,
                    score=result.score,
                    flags=result.flags if hasattr(result, "flags") else [],
                    action="allow" if result.safe else "block",
                )
            except Exception:
                pass  # Fall through to default

        return SafetyCheckResult(safe=True, score=1.0, action="allow")

    def post_check(self, response: str, query: str = "") -> SafetyCheckResult:
        """Validate an agent response before returning to the user.

        Checks for unsafe medical advice patterns.

        Args:
            response: Agent's generated response.
            query: Original user query (for context).

        Returns:
            SafetyCheckResult with safety score and any flags.
        """
        flags: list[str] = []

        # Pattern matching check
        for pattern, flag_name in _UNSAFE_RESPONSE_PATTERNS:
            if re.search(pattern, response, re.IGNORECASE):
                flags.append(flag_name)

        # Check for missing disclaimer in strict mode
        if self.strict_mode:
            has_disclaimer = any(
                phrase in response.lower()
                for phrase in [
                    "consult",
                    "healthcare provider",
                    "doctor",
                    "pharmacist",
                    "medical professional",
                    "physician",
                    "disclaimer",
                ]
            )
            if not has_disclaimer:
                flags.append("missing_disclaimer")

        # Check for source citations
        has_sources = any(
            phrase in response.lower()
            for phrase in ["source", "fda", "nih", "who", "study", "guideline", "reference"]
        )
        if not has_sources and self.strict_mode:
            flags.append("missing_sources")

        # Try llm-medical-guard if available
        if self._guard is not None:
            try:
                result = self._guard.check_response(response, context=query)
                guard_flags = result.flags if hasattr(result, "flags") else []
                flags.extend(guard_flags)
                score = result.score
            except Exception:
                score = 1.0 - (len(flags) * 0.2)
        else:
            score = max(0.0, 1.0 - (len(flags) * 0.2))

        action: Literal["allow", "warn", "block"]
        if score < 0.3:
            action = "block"
        elif score < 0.7 or flags:
            action = "warn"
        else:
            action = "allow"

        return SafetyCheckResult(
            safe=score >= 0.5,
            score=round(score, 2),
            flags=flags,
            action=action,
        )
