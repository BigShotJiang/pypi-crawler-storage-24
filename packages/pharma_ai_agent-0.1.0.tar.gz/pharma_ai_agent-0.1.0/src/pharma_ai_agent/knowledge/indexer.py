"""Simple vector-free text indexer using BM25-like scoring.

No external dependencies required. Uses term frequency and inverse document
frequency for relevance ranking without vector embeddings.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass, field


@dataclass
class Document:
    """An indexed document."""

    doc_id: str
    text: str
    metadata: dict = field(default_factory=dict)
    tokens: list[str] = field(default_factory=list, repr=False)


class TextIndexer:
    """BM25-like text indexer for knowledge retrieval.

    Uses Okapi BM25 scoring to rank documents by relevance to a query.
    No vector database or embedding model required.

    Args:
        k1: Term frequency saturation parameter (default 1.5).
        b: Document length normalization parameter (default 0.75).
    """

    def __init__(self, k1: float = 1.5, b: float = 0.75) -> None:
        self.k1 = k1
        self.b = b
        self.documents: list[Document] = []
        self.avg_doc_len: float = 0.0
        self.doc_count: int = 0
        self.df: Counter[str] = Counter()  # document frequency per term

    @staticmethod
    def tokenize(text: str) -> list[str]:
        """Tokenize text into lowercase terms."""
        text = text.lower()
        text = re.sub(r"[^\w\s-]", " ", text)
        tokens = text.split()
        # Remove very short tokens but keep drug abbreviations
        return [t for t in tokens if len(t) >= 2]

    def add_document(self, doc_id: str, text: str, metadata: dict | None = None) -> None:
        """Add a document to the index."""
        tokens = self.tokenize(text)
        doc = Document(
            doc_id=doc_id,
            text=text,
            metadata=metadata or {},
            tokens=tokens,
        )
        self.documents.append(doc)

        # Update document frequency
        unique_terms = set(tokens)
        for term in unique_terms:
            self.df[term] += 1

        # Update stats
        self.doc_count = len(self.documents)
        total_len = sum(len(d.tokens) for d in self.documents)
        self.avg_doc_len = total_len / self.doc_count if self.doc_count > 0 else 0.0

    def _idf(self, term: str) -> float:
        """Calculate inverse document frequency for a term."""
        n = self.doc_count
        df = self.df.get(term, 0)
        if df == 0:
            return 0.0
        return math.log((n - df + 0.5) / (df + 0.5) + 1.0)

    def _score_document(self, doc: Document, query_tokens: list[str]) -> float:
        """Calculate BM25 score for a document given query tokens."""
        score = 0.0
        doc_len = len(doc.tokens)
        tf_counter = Counter(doc.tokens)

        for term in query_tokens:
            tf = tf_counter.get(term, 0)
            if tf == 0:
                continue
            idf = self._idf(term)
            numerator = tf * (self.k1 + 1)
            denominator = tf + self.k1 * (
                1 - self.b + self.b * doc_len / max(self.avg_doc_len, 1.0)
            )
            score += idf * numerator / denominator

        return score

    def search(self, query: str, top_k: int = 5) -> list[tuple[Document, float]]:
        """Search for documents matching the query.

        Args:
            query: Search query string.
            top_k: Maximum number of results to return.

        Returns:
            List of (document, score) tuples, sorted by relevance.
        """
        query_tokens = self.tokenize(query)
        if not query_tokens:
            return []

        scored = []
        for doc in self.documents:
            score = self._score_document(doc, query_tokens)
            if score > 0:
                scored.append((doc, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]

    def clear(self) -> None:
        """Clear all indexed documents."""
        self.documents.clear()
        self.df.clear()
        self.doc_count = 0
        self.avg_doc_len = 0.0
