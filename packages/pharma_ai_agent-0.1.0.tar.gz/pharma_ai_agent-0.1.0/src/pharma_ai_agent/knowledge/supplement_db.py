"""Embedded supplement safety data.

Contains verified supplement safety limits, recommended daily allowances,
and upper tolerable intake levels from NIH ODS, WHO, and IOM sources.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SupplementLimit:
    """A supplement with its safety limits and key information."""

    name: str
    category: str  # vitamin, mineral, herbal, amino_acid, other
    rda_adult: str  # Recommended Daily Allowance for adults
    upper_limit: str  # Upper Tolerable Intake Level (UL)
    common_doses: str  # Typical supplement doses
    toxicity_symptoms: str
    deficiency_symptoms: str
    food_sources: str
    special_populations: str  # Warnings for specific groups
    drug_interactions_summary: str
    sources: list[str] = field(default_factory=list)
    aliases: list[str] = field(default_factory=list)

    @property
    def all_names(self) -> list[str]:
        """All names for this supplement."""
        return [self.name.lower()] + [a.lower() for a in self.aliases]

    def matches(self, query: str) -> bool:
        """Check if this supplement matches a query string."""
        q = query.lower().strip()
        return any(q in name or name in q for name in self.all_names)

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "name": self.name,
            "category": self.category,
            "rda_adult": self.rda_adult,
            "upper_limit": self.upper_limit,
            "common_doses": self.common_doses,
            "toxicity_symptoms": self.toxicity_symptoms,
            "drug_interactions_summary": self.drug_interactions_summary,
            "sources": self.sources,
        }


# ---------------------------------------------------------------------------
# Embedded supplement safety database
# Sources: NIH Office of Dietary Supplements, WHO, IOM DRI Reports
# ---------------------------------------------------------------------------

SUPPLEMENT_LIMITS: list[SupplementLimit] = [
    SupplementLimit(
        name="Vitamin A",
        category="vitamin",
        rda_adult="700-900 mcg RAE (2,333-3,000 IU)",
        upper_limit="3,000 mcg RAE (10,000 IU) preformed vitamin A",
        common_doses="1,500-3,000 mcg RAE",
        toxicity_symptoms="Nausea, headache, dizziness, blurred vision, liver damage. "
        "Chronic excess: bone loss, birth defects.",
        deficiency_symptoms="Night blindness, dry eyes, increased infection susceptibility.",
        food_sources="Liver, sweet potato, carrots, spinach, fortified dairy.",
        special_populations="CONTRAINDICATED in pregnancy at high doses (>3,000 mcg) - "
        "teratogenic. Beta-carotene form is safer.",
        drug_interactions_summary="Retinoids (isotretinoin): additive toxicity. "
        "Warfarin: may increase bleeding risk.",
        sources=["NIH ODS - Vitamin A Fact Sheet", "IOM DRI 2001"],
        aliases=["retinol", "retinyl palmitate", "beta-carotene", "retinoid"],
    ),
    SupplementLimit(
        name="Vitamin B12",
        category="vitamin",
        rda_adult="2.4 mcg",
        upper_limit="No established UL (low toxicity risk)",
        common_doses="500-5,000 mcg",
        toxicity_symptoms="No known toxicity at typical supplement doses. Excess excreted in urine.",
        deficiency_symptoms="Megaloblastic anemia, fatigue, nerve damage, cognitive decline, "
        "tingling in extremities.",
        food_sources="Meat, fish, dairy, eggs, fortified cereals.",
        special_populations="Vegans, elderly (>50), those with pernicious anemia or GI disorders "
        "often need supplementation.",
        drug_interactions_summary="Metformin: reduces B12 absorption. PPIs: reduce absorption. "
        "No significant toxicity concerns.",
        sources=["NIH ODS - Vitamin B12 Fact Sheet", "IOM DRI 1998"],
        aliases=["cobalamin", "methylcobalamin", "cyanocobalamin", "B12"],
    ),
    SupplementLimit(
        name="Vitamin C",
        category="vitamin",
        rda_adult="75-90 mg (smokers: +35 mg)",
        upper_limit="2,000 mg/day",
        common_doses="250-1,000 mg",
        toxicity_symptoms="Diarrhea, nausea, abdominal cramps, kidney stones (oxalate). "
        "Doses >2g may increase kidney stone risk.",
        deficiency_symptoms="Scurvy: fatigue, gum disease, poor wound healing, bruising.",
        food_sources="Citrus, strawberries, bell peppers, broccoli, tomatoes.",
        special_populations="Smokers need extra. Those with kidney disease should limit intake. "
        "Iron overload conditions - vitamin C enhances iron absorption.",
        drug_interactions_summary="May increase iron absorption (beneficial in deficiency, "
        "harmful in overload). May reduce effectiveness of some chemotherapy drugs.",
        sources=["NIH ODS - Vitamin C Fact Sheet", "IOM DRI 2000"],
        aliases=["ascorbic acid", "ascorbate", "L-ascorbic acid"],
    ),
    SupplementLimit(
        name="Vitamin D",
        category="vitamin",
        rda_adult="600-800 IU (15-20 mcg)",
        upper_limit="4,000 IU (100 mcg)/day",
        common_doses="1,000-5,000 IU",
        toxicity_symptoms="Hypercalcemia: nausea, vomiting, weakness, frequent urination, "
        "kidney problems. Rarely occurs below 10,000 IU/day.",
        deficiency_symptoms="Rickets (children), osteomalacia (adults), bone pain, muscle "
        "weakness, increased fracture risk.",
        food_sources="Fatty fish, fortified milk/OJ, egg yolks, mushrooms (UV-exposed).",
        special_populations="Dark skin, elderly, obese, limited sun exposure, exclusively "
        "breastfed infants all at higher deficiency risk.",
        drug_interactions_summary="Thiazide diuretics: risk of hypercalcemia. Steroids: reduce "
        "calcium absorption. Statins: generally safe combination.",
        sources=["NIH ODS - Vitamin D Fact Sheet", "IOM DRI 2011", "Endocrine Society Guidelines"],
        aliases=["cholecalciferol", "D3", "ergocalciferol", "D2", "calciferol"],
    ),
    SupplementLimit(
        name="Vitamin E",
        category="vitamin",
        rda_adult="15 mg (22.4 IU) alpha-tocopherol",
        upper_limit="1,000 mg (1,500 IU) alpha-tocopherol/day",
        common_doses="100-400 IU",
        toxicity_symptoms="High doses (>400 IU): increased bleeding risk, possible increased "
        "all-cause mortality. Nausea, diarrhea.",
        deficiency_symptoms="Rare. Nerve damage, muscle weakness, vision problems.",
        food_sources="Nuts, seeds, vegetable oils, green leafy vegetables.",
        special_populations="Those on anticoagulants should be cautious. Stop 2 weeks before "
        "surgery. Doses >400 IU may increase mortality.",
        drug_interactions_summary="Warfarin/anticoagulants: increased bleeding risk. "
        "Chemotherapy/radiation: may reduce efficacy (antioxidant effect).",
        sources=["NIH ODS - Vitamin E Fact Sheet", "Miller ER, et al., Ann Intern Med 2005"],
        aliases=["alpha-tocopherol", "tocopherol", "d-alpha-tocopherol"],
    ),
    SupplementLimit(
        name="Vitamin K",
        category="vitamin",
        rda_adult="90-120 mcg",
        upper_limit="No established UL",
        common_doses="90-120 mcg (some supplements 1,000+ mcg)",
        toxicity_symptoms="No known toxicity from food or supplements in phylloquinone form.",
        deficiency_symptoms="Easy bruising, excessive bleeding, heavy menstrual periods.",
        food_sources="Green leafy vegetables, natto, broccoli, Brussels sprouts.",
        special_populations="Warfarin users must maintain CONSISTENT intake - do not start or "
        "stop vitamin K supplements without consulting prescriber.",
        drug_interactions_summary="Warfarin: CRITICAL interaction. Vitamin K directly antagonizes "
        "warfarin. Changes in intake affect INR significantly.",
        sources=["NIH ODS - Vitamin K Fact Sheet", "IOM DRI 2001"],
        aliases=["phylloquinone", "K1", "menaquinone", "K2", "MK-7"],
    ),
    SupplementLimit(
        name="Calcium",
        category="mineral",
        rda_adult="1,000-1,200 mg",
        upper_limit="2,500 mg/day (age 19-50), 2,000 mg/day (>50)",
        common_doses="500-600 mg per dose (split dosing for absorption)",
        toxicity_symptoms="Hypercalcemia: constipation, kidney stones, nausea. "
        "Chronic excess may increase cardiovascular risk.",
        deficiency_symptoms="Osteoporosis, osteopenia, muscle cramps, numbness/tingling.",
        food_sources="Dairy, fortified plant milks, sardines, tofu, leafy greens.",
        special_populations="Postmenopausal women need 1,200mg. Split doses for better absorption. "
        "Take with vitamin D for optimal absorption.",
        drug_interactions_summary="Levothyroxine: separate by 4+ hours. Fluoroquinolones/tetracyclines: "
        "separate by 2+ hours. Bisphosphonates: separate by 30+ minutes.",
        sources=["NIH ODS - Calcium Fact Sheet", "IOM DRI 2011"],
        aliases=["calcium carbonate", "calcium citrate", "Ca"],
    ),
    SupplementLimit(
        name="Iron",
        category="mineral",
        rda_adult="8 mg (men), 18 mg (premenopausal women), 8 mg (postmenopausal)",
        upper_limit="45 mg/day elemental iron",
        common_doses="18-65 mg elemental iron (therapeutic: up to 200mg)",
        toxicity_symptoms="Nausea, vomiting, constipation, abdominal pain. Acute overdose: "
        "organ failure (especially dangerous in children).",
        deficiency_symptoms="Fatigue, weakness, pale skin, shortness of breath, cold extremities, "
        "brittle nails.",
        food_sources="Red meat, poultry, beans, lentils, fortified cereals, spinach.",
        special_populations="Do NOT supplement without documented deficiency. Hemochromatosis "
        "patients must avoid. Take with vitamin C for better absorption.",
        drug_interactions_summary="Levothyroxine: separate by 4+ hours. PPIs reduce absorption. "
        "Calcium reduces absorption. Fluoroquinolones: separate by 2+ hours.",
        sources=["NIH ODS - Iron Fact Sheet", "IOM DRI 2001"],
        aliases=["ferrous sulfate", "ferrous gluconate", "ferrous fumarate", "Fe"],
    ),
    SupplementLimit(
        name="Magnesium",
        category="mineral",
        rda_adult="310-420 mg",
        upper_limit="350 mg/day from supplements (not food)",
        common_doses="200-400 mg",
        toxicity_symptoms="Diarrhea (most common), nausea, abdominal cramping. Severe: "
        "hypotension, cardiac arrest (very rare from oral supplements).",
        deficiency_symptoms="Muscle cramps, fatigue, weakness, loss of appetite, nausea, "
        "tingling. Severe: seizures, arrhythmias.",
        food_sources="Nuts, seeds, whole grains, legumes, dark chocolate, leafy greens.",
        special_populations="Diabetes, alcoholism, GI diseases increase deficiency risk. "
        "Kidney disease patients should consult doctor before supplementing.",
        drug_interactions_summary="Tetracyclines/fluoroquinolones: reduces antibiotic absorption. "
        "Bisphosphonates: reduces absorption. Diuretics may cause depletion.",
        sources=["NIH ODS - Magnesium Fact Sheet", "IOM DRI 1997"],
        aliases=["magnesium oxide", "magnesium citrate", "magnesium glycinate", "Mg"],
    ),
    SupplementLimit(
        name="Zinc",
        category="mineral",
        rda_adult="8-11 mg",
        upper_limit="40 mg/day",
        common_doses="15-30 mg",
        toxicity_symptoms="Nausea, vomiting, diarrhea, metallic taste. Chronic excess: "
        "copper deficiency, immune suppression, low HDL.",
        deficiency_symptoms="Impaired immunity, slow wound healing, taste changes, hair loss, "
        "diarrhea.",
        food_sources="Oysters, red meat, poultry, beans, nuts, dairy.",
        special_populations="Vegetarians may need 50% more (phytate binding). Long-term "
        "supplementation >40mg requires copper co-supplementation.",
        drug_interactions_summary="Fluoroquinolones/tetracyclines: reduces absorption. "
        "Penicillamine: reduces both drug and zinc absorption.",
        sources=["NIH ODS - Zinc Fact Sheet", "IOM DRI 2001"],
        aliases=["zinc gluconate", "zinc picolinate", "zinc citrate", "Zn"],
    ),
    SupplementLimit(
        name="Selenium",
        category="mineral",
        rda_adult="55 mcg",
        upper_limit="400 mcg/day",
        common_doses="50-200 mcg",
        toxicity_symptoms="Selenosis: garlic breath, nail brittleness, nausea, diarrhea, "
        "skin rash, fatigue, nerve damage.",
        deficiency_symptoms="Rare in developed countries. Keshan disease (cardiomyopathy), "
        "weakened immunity.",
        food_sources="Brazil nuts (very high), seafood, organ meats, grains.",
        special_populations="1-2 Brazil nuts/day provide adequate selenium. Do not combine "
        "multiple selenium sources without counting total intake.",
        drug_interactions_summary="Cisplatin: may reduce kidney toxicity. Minimal drug interactions "
        "at recommended doses.",
        sources=["NIH ODS - Selenium Fact Sheet", "IOM DRI 2000"],
        aliases=["selenomethionine", "sodium selenite", "Se"],
    ),
    SupplementLimit(
        name="Potassium",
        category="mineral",
        rda_adult="2,600-3,400 mg (adequate intake)",
        upper_limit="No established UL from food. Supplement forms limited to 99mg per unit in US.",
        common_doses="99 mg (OTC), 600-750 mg (Rx)",
        toxicity_symptoms="Hyperkalemia: muscle weakness, paralysis, cardiac arrhythmias, "
        "cardiac arrest. Medical emergency.",
        deficiency_symptoms="Hypokalemia: weakness, fatigue, muscle cramps, constipation, "
        "cardiac arrhythmias.",
        food_sources="Bananas, potatoes, spinach, beans, yogurt, salmon.",
        special_populations="ACE inhibitors/ARBs/potassium-sparing diuretics: HIGH risk of "
        "hyperkalemia. Kidney disease: must limit potassium.",
        drug_interactions_summary="ACE inhibitors/ARBs: hyperkalemia risk. Potassium-sparing "
        "diuretics: hyperkalemia risk. Loop/thiazide diuretics: may need supplementation.",
        sources=["NIH ODS - Potassium Fact Sheet", "IOM DRI 2019"],
        aliases=["potassium chloride", "potassium citrate", "K", "KCl"],
    ),
    SupplementLimit(
        name="Omega-3 Fatty Acids",
        category="other",
        rda_adult="250-500 mg EPA+DHA (no formal RDA)",
        upper_limit="3,000-5,000 mg EPA+DHA (FDA: up to 3g supplemental is GRAS)",
        common_doses="500-2,000 mg EPA+DHA",
        toxicity_symptoms="Fishy burps, diarrhea, nausea. High doses (>3g): increased bleeding "
        "time, possible LDL increase.",
        deficiency_symptoms="Dry skin, poor memory, mood issues, joint pain (non-specific).",
        food_sources="Fatty fish (salmon, mackerel, sardines), flaxseed, chia seeds, walnuts.",
        special_populations="Those on anticoagulants should limit to <2g/day. Fish allergy: "
        "use algae-based omega-3. Pregnant: important for fetal development.",
        drug_interactions_summary="Warfarin/anticoagulants: may increase bleeding at high doses. "
        "Blood pressure medications: additive hypotensive effect.",
        sources=["NIH ODS - Omega-3 Fact Sheet", "AHA Omega-3 Scientific Advisory"],
        aliases=["fish oil", "EPA", "DHA", "omega 3", "krill oil", "algal oil"],
    ),
    SupplementLimit(
        name="Coenzyme Q10",
        category="other",
        rda_adult="No RDA established",
        upper_limit="No formal UL. Studies used up to 1,200 mg/day.",
        common_doses="100-300 mg",
        toxicity_symptoms="Generally well tolerated. Mild: insomnia, nausea, diarrhea, "
        "heartburn at high doses.",
        deficiency_symptoms="Not a classical deficiency. Statin users may have reduced CoQ10 "
        "levels (clinical significance debated).",
        food_sources="Organ meats, sardines, peanuts, spinach, broccoli.",
        special_populations="Commonly used by statin users. May improve heart failure symptoms. "
        "Fat-soluble - take with meals.",
        drug_interactions_summary="Warfarin: structurally similar to vitamin K, may reduce "
        "warfarin efficacy. Statins: may replenish depleted CoQ10.",
        sources=["NIH ODS - CoQ10 Supplement", "Natural Medicines Comprehensive Database"],
        aliases=["CoQ10", "ubiquinone", "ubiquinol"],
    ),
    SupplementLimit(
        name="Melatonin",
        category="other",
        rda_adult="No RDA (not a nutrient)",
        upper_limit="No formal UL. Typical doses 0.5-10 mg.",
        common_doses="0.5-5 mg (start low)",
        toxicity_symptoms="Drowsiness, headache, dizziness, nausea. High doses: vivid dreams, "
        "next-day grogginess.",
        deficiency_symptoms="N/A (endogenous hormone). Low production: insomnia, poor sleep quality.",
        food_sources="Tart cherries, walnuts, tomatoes, rice (very small amounts).",
        special_populations="Not recommended for children without medical guidance. Autoimmune "
        "conditions: may stimulate immune system. Pregnancy: insufficient safety data.",
        drug_interactions_summary="Anticoagulants: mild bleeding risk. Diabetes medications: may "
        "affect blood sugar. CNS depressants: additive sedation.",
        sources=["NIH NCCIH - Melatonin", "Natural Medicines Database"],
        aliases=["N-acetyl-5-methoxytryptamine"],
    ),
    SupplementLimit(
        name="Probiotics",
        category="other",
        rda_adult="No RDA. Doses measured in CFU (colony forming units).",
        upper_limit="No formal UL. Most studies use 1-100 billion CFU.",
        common_doses="1-50 billion CFU",
        toxicity_symptoms="Mild gas, bloating initially. Rarely: infections in severely "
        "immunocompromised patients.",
        deficiency_symptoms="N/A. Gut microbiome imbalance (dysbiosis) is a separate concept.",
        food_sources="Yogurt, kefir, kimchi, sauerkraut, kombucha, miso.",
        special_populations="Immunocompromised patients should consult doctor. ICU patients: "
        "risk of bacteremia. Generally very safe for healthy individuals.",
        drug_interactions_summary="Antibiotics: take 2+ hours apart. Immunosuppressants: "
        "theoretical concern. No major drug interactions for healthy people.",
        sources=["NIH NCCIH - Probiotics", "WGO Global Guidelines - Probiotics"],
        aliases=["Lactobacillus", "Bifidobacterium", "Saccharomyces boulardii"],
    ),
    SupplementLimit(
        name="Turmeric / Curcumin",
        category="herbal",
        rda_adult="No RDA. WHO ADI: 0-3 mg/kg body weight.",
        upper_limit="No formal UL. Studies used up to 8,000 mg/day curcumin.",
        common_doses="500-2,000 mg curcumin extract",
        toxicity_symptoms="Nausea, diarrhea, headache. High doses: increased liver enzymes "
        "(rare reports with concentrated supplements).",
        deficiency_symptoms="N/A (not an essential nutrient).",
        food_sources="Turmeric spice, curry powder.",
        special_populations="Gallstone patients: may stimulate bile. Surgery: stop 2 weeks "
        "before (bleeding risk). Pregnancy: dietary amounts only.",
        drug_interactions_summary="Anticoagulants: increased bleeding risk. May inhibit CYP enzymes. "
        "Iron supplements: may reduce absorption.",
        sources=["NIH NCCIH - Turmeric", "WHO Monograph", "Natural Medicines Database"],
        aliases=["curcumin", "curcuma longa", "turmeric extract"],
    ),
    SupplementLimit(
        name="St. John's Wort",
        category="herbal",
        rda_adult="No RDA.",
        upper_limit="No formal UL. Typical dose 300mg 3x/day (900mg total).",
        common_doses="300-900 mg standardized extract",
        toxicity_symptoms="Photosensitivity, anxiety, dry mouth, GI upset, fatigue.",
        deficiency_symptoms="N/A.",
        food_sources="Not a food. Herbal supplement only.",
        special_populations="MAJOR drug interaction potential. Avoid in pregnancy/lactation. "
        "Avoid 2 weeks before surgery.",
        drug_interactions_summary="POTENT CYP3A4 AND P-GP INDUCER. Reduces levels of: SSRIs "
        "(serotonin syndrome risk), oral contraceptives, warfarin, HIV medications, "
        "cyclosporine, digoxin, and many more.",
        sources=["NIH NCCIH - St. John's Wort", "FDA Drug Interaction Table"],
        aliases=["Hypericum perforatum", "SJW", "hypericum"],
    ),
    SupplementLimit(
        name="Ginkgo Biloba",
        category="herbal",
        rda_adult="No RDA.",
        upper_limit="No formal UL. Typical dose 120-240 mg standardized extract.",
        common_doses="120-240 mg EGb 761 extract",
        toxicity_symptoms="Headache, dizziness, GI upset, allergic skin reactions. "
        "Seizures at very high doses.",
        deficiency_symptoms="N/A.",
        food_sources="Not a food. Herbal supplement from ginkgo tree leaves.",
        special_populations="Stop 2 weeks before surgery (bleeding risk). Epilepsy: may "
        "lower seizure threshold. Diabetes: may affect blood sugar.",
        drug_interactions_summary="Anticoagulants/antiplatelets: increased bleeding risk. "
        "Anticonvulsants: may reduce efficacy. CYP substrate interactions.",
        sources=["NIH NCCIH - Ginkgo", "Natural Medicines Database"],
        aliases=["ginkgo", "EGb 761", "ginkgo extract"],
    ),
    SupplementLimit(
        name="Garlic Supplements",
        category="herbal",
        rda_adult="No RDA.",
        upper_limit="No formal UL.",
        common_doses="600-1,200 mg aged garlic extract",
        toxicity_symptoms="Breath/body odor, heartburn, nausea, diarrhea. Topical: skin burns.",
        deficiency_symptoms="N/A.",
        food_sources="Fresh garlic, aged garlic.",
        special_populations="Stop 1-2 weeks before surgery (bleeding risk). HIV patients on "
        "saquinavir: contraindicated.",
        drug_interactions_summary="Anticoagulants: mild bleeding risk. Saquinavir (HIV): reduces "
        "drug levels. CYP2E1 inducer. May enhance hypoglycemic effects.",
        sources=["NIH NCCIH - Garlic", "Natural Medicines Database"],
        aliases=["allicin", "aged garlic extract", "AGE"],
    ),
    SupplementLimit(
        name="Biotin",
        category="vitamin",
        rda_adult="30 mcg (adequate intake)",
        upper_limit="No established UL",
        common_doses="2,500-10,000 mcg (for hair/nails)",
        toxicity_symptoms="No known toxicity. IMPORTANT: high-dose biotin can interfere with "
        "laboratory blood tests (troponin, thyroid, hormones) causing false results.",
        deficiency_symptoms="Hair loss, brittle nails, skin rash, neurological symptoms. "
        "Rare except in genetic disorders or raw egg consumption.",
        food_sources="Eggs, liver, salmon, avocado, sweet potato, nuts.",
        special_populations="CRITICAL: Inform healthcare providers of biotin supplementation "
        "before any blood tests. Can cause false low troponin (miss heart attack).",
        drug_interactions_summary="No significant drug interactions. Lab test interference is "
        "the main safety concern at high doses.",
        sources=["NIH ODS - Biotin Fact Sheet", "FDA Safety Communication - Biotin Lab Tests"],
        aliases=["vitamin B7", "vitamin H", "B7"],
    ),
    SupplementLimit(
        name="Folate",
        category="vitamin",
        rda_adult="400 mcg DFE (600 mcg DFE in pregnancy)",
        upper_limit="1,000 mcg/day folic acid from supplements/fortification",
        common_doses="400-800 mcg folic acid",
        toxicity_symptoms="High doses may mask B12 deficiency (allowing neurological damage "
        "to progress). Possible colorectal cancer promotion at very high doses.",
        deficiency_symptoms="Megaloblastic anemia, neural tube defects in fetus, fatigue, "
        "mouth sores.",
        food_sources="Leafy greens, legumes, fortified grains, liver, asparagus.",
        special_populations="ALL women of childbearing age should take 400mcg daily. "
        "Do not exceed 1,000mcg without B12 status check.",
        drug_interactions_summary="Methotrexate: antagonizes effect (by design). Phenytoin: "
        "mutual interaction. Sulfasalazine: reduces folate absorption.",
        sources=["NIH ODS - Folate Fact Sheet", "IOM DRI 1998", "WHO Pregnancy Guidelines"],
        aliases=["folic acid", "vitamin B9", "B9", "methylfolate", "5-MTHF", "folacin"],
    ),
    SupplementLimit(
        name="Vitamin B6",
        category="vitamin",
        rda_adult="1.3-1.7 mg",
        upper_limit="100 mg/day",
        common_doses="10-100 mg",
        toxicity_symptoms="Doses >200mg/day: peripheral neuropathy (nerve damage), "
        "numbness, difficulty walking. Usually reversible on discontinuation.",
        deficiency_symptoms="Anemia, dermatitis, confusion, depression, weakened immunity.",
        food_sources="Poultry, fish, potatoes, chickpeas, bananas, fortified cereals.",
        special_populations="Commonly used for pregnancy nausea (25mg 3x/day). Kidney "
        "patients on dialysis may need supplementation.",
        drug_interactions_summary="Levodopa: reduces efficacy (give with carbidopa). "
        "Phenytoin/phenobarbital: may reduce levels. Isoniazid: causes B6 depletion.",
        sources=["NIH ODS - Vitamin B6 Fact Sheet", "IOM DRI 1998"],
        aliases=["pyridoxine", "pyridoxal", "P5P", "pyridoxamine"],
    ),
    SupplementLimit(
        name="Chromium",
        category="mineral",
        rda_adult="20-35 mcg (adequate intake)",
        upper_limit="No established UL",
        common_doses="200-1,000 mcg",
        toxicity_symptoms="Rarely: kidney damage, liver damage at very high doses. "
        "GI upset, headache.",
        deficiency_symptoms="Rare. Impaired glucose tolerance, peripheral neuropathy.",
        food_sources="Broccoli, grape juice, whole grains, meat.",
        special_populations="Marketed for blood sugar control and weight loss, but evidence "
        "is limited. Kidney/liver disease: avoid high doses.",
        drug_interactions_summary="Insulin/sulfonylureas: may enhance hypoglycemic effect. "
        "Levothyroxine: may reduce absorption. NSAIDs: may increase chromium absorption.",
        sources=["NIH ODS - Chromium Fact Sheet", "IOM DRI 2001"],
        aliases=["chromium picolinate", "chromium polynicotinate", "Cr"],
    ),
    SupplementLimit(
        name="Glucosamine",
        category="other",
        rda_adult="No RDA.",
        upper_limit="No formal UL. Studies used 1,500 mg/day.",
        common_doses="500 mg 3x/day or 1,500 mg once daily",
        toxicity_symptoms="Mild GI upset, nausea, heartburn, diarrhea, constipation.",
        deficiency_symptoms="N/A (not an essential nutrient).",
        food_sources="Shellfish shells (supplement source). No significant food sources.",
        special_populations="Shellfish allergy: use synthetic/vegetarian form. Warfarin users: "
        "monitor INR. Diabetes: may affect blood sugar.",
        drug_interactions_summary="Warfarin: may increase INR and bleeding risk. Diabetes "
        "medications: monitor blood sugar. Generally safe.",
        sources=["NIH NCCIH - Glucosamine", "Natural Medicines Database"],
        aliases=["glucosamine sulfate", "glucosamine HCl", "glucosamine chondroitin"],
    ),
    SupplementLimit(
        name="Ashwagandha",
        category="herbal",
        rda_adult="No RDA.",
        upper_limit="No formal UL. Studies used 300-600 mg root extract.",
        common_doses="300-600 mg root extract (standardized to withanolides)",
        toxicity_symptoms="GI upset, drowsiness, headache. Rare: liver injury (case reports "
        "with concentrated extracts).",
        deficiency_symptoms="N/A.",
        food_sources="Not a common food. Nightshade family plant.",
        special_populations="Autoimmune diseases: may stimulate immune system. Thyroid: "
        "may increase thyroid hormone levels. Pregnancy: contraindicated.",
        drug_interactions_summary="Thyroid medications: may potentiate effect. Sedatives: "
        "additive drowsiness. Immunosuppressants: may counteract effect.",
        sources=["NIH NCCIH", "Natural Medicines Database"],
        aliases=["Withania somnifera", "Indian ginseng", "winter cherry"],
    ),
    SupplementLimit(
        name="Elderberry",
        category="herbal",
        rda_adult="No RDA.",
        upper_limit="No formal UL.",
        common_doses="300-600 mg extract",
        toxicity_symptoms="Nausea, vomiting, diarrhea. Raw/unripe berries contain cyanogenic "
        "glycosides (toxic).",
        deficiency_symptoms="N/A.",
        food_sources="Cooked elderberries (raw are toxic).",
        special_populations="Autoimmune diseases: may stimulate immune system (cytokine storm "
        "concern is theoretical). Pregnancy: insufficient data.",
        drug_interactions_summary="Immunosuppressants: may counteract. Diabetes medications: "
        "may enhance hypoglycemic effect. Diuretics: additive effect.",
        sources=["NIH NCCIH", "Natural Medicines Database"],
        aliases=["Sambucus nigra", "sambucus", "black elderberry"],
    ),
    SupplementLimit(
        name="Collagen",
        category="other",
        rda_adult="No RDA.",
        upper_limit="No formal UL.",
        common_doses="2,500-15,000 mg (2.5-15g)",
        toxicity_symptoms="Generally well tolerated. Mild: bloating, heartburn, feeling "
        "of fullness. Bad taste (some products).",
        deficiency_symptoms="N/A (body produces collagen; production decreases with age).",
        food_sources="Bone broth, chicken skin, pork skin, fish skin.",
        special_populations="Fish/shellfish allergy: check source. Contains hydroxyproline "
        "which is converted to oxalate - caution in kidney stone formers.",
        drug_interactions_summary="No significant drug interactions known. Generally very safe.",
        sources=["Natural Medicines Database"],
        aliases=["collagen peptides", "hydrolyzed collagen", "collagen protein"],
    ),
    SupplementLimit(
        name="Creatine",
        category="other",
        rda_adult="No RDA.",
        upper_limit="No formal UL. Long-term studies up to 5g/day show safety.",
        common_doses="3-5 g/day (maintenance), 20g/day loading (5-7 days)",
        toxicity_symptoms="Water retention, GI upset, muscle cramping. May increase "
        "serum creatinine (confounds kidney function tests).",
        deficiency_symptoms="N/A (endogenously produced). Rare genetic deficiency syndromes exist.",
        food_sources="Red meat, fish (1-2g per pound).",
        special_populations="IMPORTANT: Creatine raises serum creatinine, which may falsely "
        "suggest kidney impairment on blood tests. Inform your doctor.",
        drug_interactions_summary="Nephrotoxic drugs: theoretical concern. NSAIDs + creatine: "
        "may increase kidney stress. Generally very safe.",
        sources=["ISSN Position Stand on Creatine", "NIH NCCIH"],
        aliases=["creatine monohydrate", "creatine HCl"],
    ),
]
