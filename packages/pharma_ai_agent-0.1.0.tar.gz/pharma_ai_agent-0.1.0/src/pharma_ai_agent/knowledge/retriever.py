"""Knowledge retriever that combines drug and supplement databases.

Provides a unified interface for querying the embedded knowledge base
using the BM25-like text indexer.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from pharma_ai_agent.knowledge.drug_db import DRUG_INTERACTIONS, DrugInteraction
from pharma_ai_agent.knowledge.supplement_db import SUPPLEMENT_LIMITS, SupplementLimit
from pharma_ai_agent.knowledge.indexer import TextIndexer


@dataclass
class RetrievalResult:
    """Result from a knowledge retrieval query."""

    query: str
    interactions: list[DrugInteraction] = field(default_factory=list)
    supplements: list[SupplementLimit] = field(default_factory=list)
    context_text: str = ""
    relevance_score: float = 0.0

    @property
    def has_results(self) -> bool:
        """Check if any results were found."""
        return bool(self.interactions or self.supplements)


class KnowledgeRetriever:
    """Retrieves relevant knowledge from the embedded databases.

    Combines exact name matching with BM25 text search for robust retrieval.
    """

    def __init__(self) -> None:
        self._indexer = TextIndexer()
        self._interactions = DRUG_INTERACTIONS
        self._supplements = SUPPLEMENT_LIMITS
        self._build_index()

    def _build_index(self) -> None:
        """Build the text search index from embedded data."""
        for i, interaction in enumerate(self._interactions):
            text_parts = [
                interaction.drug_a,
                interaction.drug_b,
                " ".join(interaction.aliases_a),
                " ".join(interaction.aliases_b),
                interaction.mechanism,
                interaction.clinical_description,
                interaction.patient_description,
                interaction.management,
            ]
            self._indexer.add_document(
                doc_id=f"interaction_{i}",
                text=" ".join(text_parts),
                metadata={"type": "interaction", "index": i},
            )

        for i, supplement in enumerate(self._supplements):
            text_parts = [
                supplement.name,
                " ".join(supplement.aliases),
                supplement.category,
                supplement.toxicity_symptoms,
                supplement.drug_interactions_summary,
                supplement.special_populations,
            ]
            self._indexer.add_document(
                doc_id=f"supplement_{i}",
                text=" ".join(text_parts),
                metadata={"type": "supplement", "index": i},
            )

    def find_interactions(self, drug_a: str, drug_b: str) -> list[DrugInteraction]:
        """Find interactions between two specific drugs/supplements.

        Uses exact name matching (case-insensitive) including aliases.
        """
        results = []
        for interaction in self._interactions:
            if interaction.matches(drug_a, drug_b):
                results.append(interaction)
        return results

    def find_supplement(self, name: str) -> SupplementLimit | None:
        """Find a supplement by name (exact match including aliases)."""
        for supplement in self._supplements:
            if supplement.matches(name):
                return supplement
        return None

    def search(self, query: str, top_k: int = 10) -> RetrievalResult:
        """Search the knowledge base using text matching.

        Combines exact matching and BM25 search for comprehensive results.

        Args:
            query: Natural language query.
            top_k: Maximum results per category.

        Returns:
            RetrievalResult with matched interactions and supplements.
        """
        result = RetrievalResult(query=query)

        # BM25 text search
        search_results = self._indexer.search(query, top_k=top_k * 2)

        seen_interactions: set[int] = set()
        seen_supplements: set[int] = set()

        for doc, score in search_results:
            doc_type = doc.metadata.get("type")
            idx = doc.metadata.get("index", -1)

            if doc_type == "interaction" and idx not in seen_interactions:
                seen_interactions.add(idx)
                result.interactions.append(self._interactions[idx])
                result.relevance_score = max(result.relevance_score, score)

            elif doc_type == "supplement" and idx not in seen_supplements:
                seen_supplements.add(idx)
                result.supplements.append(self._supplements[idx])
                result.relevance_score = max(result.relevance_score, score)

        # Limit results
        result.interactions = result.interactions[:top_k]
        result.supplements = result.supplements[:top_k]

        # Build context text for LLM
        result.context_text = self._build_context(result)

        return result

    def _build_context(self, result: RetrievalResult) -> str:
        """Build a context string from retrieval results for LLM consumption."""
        parts: list[str] = []

        if result.interactions:
            parts.append("=== DRUG INTERACTION DATA ===")
            for interaction in result.interactions:
                parts.append(
                    f"\n[{interaction.severity.upper()}] {interaction.drug_a} + {interaction.drug_b}\n"
                    f"Mechanism: {interaction.mechanism}\n"
                    f"Clinical: {interaction.clinical_description}\n"
                    f"Management: {interaction.management}\n"
                    f"Sources: {', '.join(interaction.sources)}"
                )

        if result.supplements:
            parts.append("\n=== SUPPLEMENT SAFETY DATA ===")
            for supplement in result.supplements:
                parts.append(
                    f"\n{supplement.name} ({supplement.category})\n"
                    f"RDA: {supplement.rda_adult}\n"
                    f"Upper Limit: {supplement.upper_limit}\n"
                    f"Toxicity: {supplement.toxicity_symptoms}\n"
                    f"Drug Interactions: {supplement.drug_interactions_summary}\n"
                    f"Sources: {', '.join(supplement.sources)}"
                )

        return "\n".join(parts) if parts else "No relevant data found in knowledge base."

    @property
    def interaction_count(self) -> int:
        """Number of interactions in the knowledge base."""
        return len(self._interactions)

    @property
    def supplement_count(self) -> int:
        """Number of supplements in the knowledge base."""
        return len(self._supplements)
