"""Embedded drug interaction knowledge base.

Contains verified drug-drug interactions sourced from FDA, NIH, and WHO
public databases. Each interaction includes severity, mechanism, and
patient-friendly explanations.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


@dataclass
class DrugInteraction:
    """A verified drug-drug interaction record."""

    drug_a: str
    drug_b: str
    severity: Literal["major", "moderate", "minor"]
    mechanism: str
    clinical_description: str
    patient_description: str
    management: str
    sources: list[str] = field(default_factory=list)
    aliases_a: list[str] = field(default_factory=list)
    aliases_b: list[str] = field(default_factory=list)

    @property
    def all_names_a(self) -> list[str]:
        """All names (generic + brand) for drug A."""
        return [self.drug_a.lower()] + [a.lower() for a in self.aliases_a]

    @property
    def all_names_b(self) -> list[str]:
        """All names (generic + brand) for drug B."""
        return [self.drug_b.lower()] + [a.lower() for a in self.aliases_b]

    def matches(self, name1: str, name2: str) -> bool:
        """Check if this interaction matches two drug names (order-independent)."""
        n1, n2 = name1.lower().strip(), name2.lower().strip()
        forward = n1 in self.all_names_a and n2 in self.all_names_b
        reverse = n1 in self.all_names_b and n2 in self.all_names_a
        return forward or reverse

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "drug_a": self.drug_a,
            "drug_b": self.drug_b,
            "severity": self.severity,
            "mechanism": self.mechanism,
            "clinical_description": self.clinical_description,
            "patient_description": self.patient_description,
            "management": self.management,
            "sources": self.sources,
        }


# ---------------------------------------------------------------------------
# Embedded interaction database (200+ entries)
# Sources: FDA Drug Interaction Table, NIH DailyMed, WHO Essential Medicines
# ---------------------------------------------------------------------------

DRUG_INTERACTIONS: list[DrugInteraction] = [
    # --- Anticoagulant interactions (high-risk) ---
    DrugInteraction(
        drug_a="warfarin",
        drug_b="ibuprofen",
        severity="major",
        mechanism="NSAIDs inhibit platelet aggregation and may cause GI bleeding; "
        "combined with warfarin's anticoagulant effect, bleeding risk increases significantly.",
        clinical_description="Concurrent use of warfarin and ibuprofen increases the risk of "
        "gastrointestinal and other bleeding events. INR may become unstable.",
        patient_description="Taking ibuprofen while on warfarin can significantly increase your "
        "risk of bleeding, including internal bleeding. This is a dangerous combination.",
        management="Avoid concurrent use if possible. If NSAID is needed, use the lowest dose "
        "for the shortest duration. Monitor INR frequently. Consider acetaminophen as alternative.",
        sources=[
            "FDA Drug Safety Communication (2015)",
            "NIH DailyMed - Warfarin Sodium Label",
        ],
        aliases_a=["Coumadin", "Jantoven"],
        aliases_b=["Advil", "Motrin", "Nurofen"],
    ),
    DrugInteraction(
        drug_a="warfarin",
        drug_b="aspirin",
        severity="major",
        mechanism="Aspirin irreversibly inhibits COX-1, reducing thromboxane A2 production "
        "and platelet aggregation. Combined with warfarin, bleeding risk is markedly elevated.",
        clinical_description="Concomitant use significantly increases risk of major bleeding "
        "events including intracranial hemorrhage.",
        patient_description="Taking aspirin with warfarin greatly increases your bleeding risk. "
        "Only combine these under close medical supervision.",
        management="Avoid unless specifically directed by physician for cardiac indications. "
        "Use lowest effective aspirin dose (75-100mg). Monitor INR closely.",
        sources=[
            "FDA Drug Interaction Table",
            "AHA/ACC Guideline on Antithrombotic Therapy (2019)",
        ],
        aliases_a=["Coumadin", "Jantoven"],
        aliases_b=["Bayer Aspirin", "Ecotrin", "Bufferin"],
    ),
    DrugInteraction(
        drug_a="warfarin",
        drug_b="acetaminophen",
        severity="moderate",
        mechanism="Acetaminophen may inhibit vitamin K-dependent clotting factor synthesis "
        "at doses >2g/day, potentiating warfarin's anticoagulant effect.",
        clinical_description="High-dose acetaminophen (>2g/day for several days) may increase "
        "INR in patients on warfarin.",
        patient_description="Occasional use of Tylenol is generally safer than NSAIDs with "
        "warfarin, but regular high doses can still affect your blood thinning.",
        management="Preferred over NSAIDs for pain relief. Limit to <2g/day. Monitor INR "
        "if using regularly for more than a few days.",
        sources=["NIH DailyMed - Warfarin Sodium Label", "Hylek et al., JAMA 1998"],
        aliases_a=["Coumadin", "Jantoven"],
        aliases_b=["Tylenol", "Paracetamol", "APAP"],
    ),
    DrugInteraction(
        drug_a="warfarin",
        drug_b="fluconazole",
        severity="major",
        mechanism="Fluconazole is a potent CYP2C9 inhibitor. Warfarin's S-enantiomer "
        "(the more active form) is metabolized by CYP2C9.",
        clinical_description="Fluconazole can increase warfarin plasma concentrations 2-3 fold, "
        "leading to dangerously elevated INR and bleeding risk.",
        patient_description="This antifungal medication can make warfarin much stronger in your "
        "body, greatly increasing bleeding risk.",
        management="Reduce warfarin dose by 25-50% when starting fluconazole. Monitor INR "
        "within 3-5 days and adjust. Consider alternative antifungal.",
        sources=["FDA Drug Interaction Table", "NIH DailyMed - Fluconazole Label"],
        aliases_a=["Coumadin", "Jantoven"],
        aliases_b=["Diflucan"],
    ),
    DrugInteraction(
        drug_a="warfarin",
        drug_b="vitamin K",
        severity="moderate",
        mechanism="Vitamin K is the direct pharmacological antagonist of warfarin. "
        "Supplemental vitamin K can reverse anticoagulant effects.",
        clinical_description="Vitamin K supplementation can reduce INR and decrease "
        "warfarin efficacy, increasing thrombotic risk.",
        patient_description="Vitamin K works against warfarin. Taking vitamin K supplements "
        "can make your blood thinner less effective.",
        management="Maintain consistent dietary vitamin K intake. Avoid vitamin K supplements "
        "unless directed by physician. Monitor INR if diet changes significantly.",
        sources=["FDA Drug Interaction Table", "AHA Warfarin Management Guidelines"],
        aliases_a=["Coumadin", "Jantoven"],
        aliases_b=["phytonadione", "phylloquinone", "menaquinone"],
    ),
    # --- Statin interactions ---
    DrugInteraction(
        drug_a="simvastatin",
        drug_b="amiodarone",
        severity="major",
        mechanism="Amiodarone inhibits CYP3A4, significantly increasing simvastatin "
        "plasma levels and risk of rhabdomyolysis.",
        clinical_description="Risk of myopathy/rhabdomyolysis is markedly increased. "
        "Simvastatin dose should not exceed 20mg/day with amiodarone.",
        patient_description="This heart rhythm medication can cause dangerously high levels "
        "of simvastatin in your blood, potentially causing severe muscle damage.",
        management="Do not exceed simvastatin 20mg/day. Consider switching to pravastatin "
        "or rosuvastatin which are not CYP3A4 substrates.",
        sources=[
            "FDA Drug Safety Communication - Simvastatin Dose Limitations",
            "NIH DailyMed - Simvastatin Label",
        ],
        aliases_a=["Zocor"],
        aliases_b=["Cordarone", "Pacerone"],
    ),
    DrugInteraction(
        drug_a="simvastatin",
        drug_b="grapefruit juice",
        severity="moderate",
        mechanism="Grapefruit juice inhibits intestinal CYP3A4, increasing oral "
        "bioavailability of simvastatin.",
        clinical_description="Large quantities of grapefruit juice can increase simvastatin "
        "exposure and risk of myopathy.",
        patient_description="Grapefruit juice can increase the amount of simvastatin your "
        "body absorbs, raising the risk of muscle side effects.",
        management="Avoid large quantities of grapefruit juice (>1 quart/day). "
        "Small amounts are generally acceptable.",
        sources=["FDA Drug Interaction Table", "NIH DailyMed - Simvastatin Label"],
        aliases_a=["Zocor"],
        aliases_b=["grapefruit"],
    ),
    DrugInteraction(
        drug_a="atorvastatin",
        drug_b="clarithromycin",
        severity="major",
        mechanism="Clarithromycin is a potent CYP3A4 inhibitor, increasing atorvastatin "
        "plasma concentrations and myopathy risk.",
        clinical_description="Concomitant use can increase atorvastatin AUC by up to 4-fold, "
        "significantly increasing rhabdomyolysis risk.",
        patient_description="This antibiotic can cause dangerously high levels of your "
        "cholesterol medication, risking severe muscle damage.",
        management="Use azithromycin as alternative antibiotic. If clarithromycin is essential, "
        "temporarily hold atorvastatin. Consider pravastatin.",
        sources=["FDA Drug Interaction Table", "NIH DailyMed - Atorvastatin Label"],
        aliases_a=["Lipitor"],
        aliases_b=["Biaxin"],
    ),
    # --- ACE inhibitor / ARB interactions ---
    DrugInteraction(
        drug_a="lisinopril",
        drug_b="potassium",
        severity="major",
        mechanism="ACE inhibitors reduce aldosterone secretion, decreasing renal potassium "
        "excretion. Additional potassium can cause life-threatening hyperkalemia.",
        clinical_description="Risk of hyperkalemia (serum K+ >5.5 mEq/L) with potential "
        "cardiac arrhythmias and cardiac arrest.",
        patient_description="Your blood pressure medication already raises potassium levels. "
        "Adding potassium supplements can make levels dangerously high.",
        management="Avoid potassium supplements unless directed by physician with regular "
        "monitoring. Check serum potassium within 1 week of starting.",
        sources=["FDA Drug Interaction Table", "NIH DailyMed - Lisinopril Label"],
        aliases_a=["Prinivil", "Zestril"],
        aliases_b=["potassium chloride", "K-Dur", "Klor-Con", "potassium supplement"],
    ),
    DrugInteraction(
        drug_a="lisinopril",
        drug_b="spironolactone",
        severity="major",
        mechanism="Both ACE inhibitors and spironolactone increase serum potassium. "
        "Combined use significantly elevates hyperkalemia risk.",
        clinical_description="Concomitant use increases risk of severe hyperkalemia, "
        "especially in patients with renal impairment.",
        patient_description="Both of these medications raise potassium levels in your blood. "
        "Together they can cause dangerously high potassium.",
        management="If combination is necessary, start spironolactone at low dose (12.5-25mg). "
        "Monitor potassium at 3 days, 1 week, then monthly.",
        sources=["RALES Trial Safety Data", "NIH DailyMed - Spironolactone Label"],
        aliases_a=["Prinivil", "Zestril"],
        aliases_b=["Aldactone"],
    ),
    # --- SSRI interactions ---
    DrugInteraction(
        drug_a="sertraline",
        drug_b="tramadol",
        severity="major",
        mechanism="Both increase serotonergic activity. Tramadol inhibits serotonin reuptake "
        "and sertraline is an SSRI. Combined use risks serotonin syndrome.",
        clinical_description="Risk of serotonin syndrome: agitation, hyperthermia, tachycardia, "
        "myoclonus, hyperreflexia. Can be life-threatening.",
        patient_description="Taking these together can cause a dangerous condition called "
        "serotonin syndrome, where too much serotonin builds up in your brain.",
        management="Avoid combination if possible. If necessary, use lowest effective doses "
        "and monitor for serotonin syndrome symptoms. Educate patient on warning signs.",
        sources=["FDA Drug Safety Communication - Serotonin Syndrome", "NIH DailyMed"],
        aliases_a=["Zoloft"],
        aliases_b=["Ultram", "ConZip"],
    ),
    DrugInteraction(
        drug_a="fluoxetine",
        drug_b="MAO inhibitors",
        severity="major",
        mechanism="Fluoxetine's serotonin reuptake inhibition combined with MAO inhibition "
        "causes massive serotonin accumulation. Potentially fatal.",
        clinical_description="Contraindicated combination. Risk of fatal serotonin syndrome. "
        "14-day washout required between agents.",
        patient_description="These medications must NEVER be taken together. The combination "
        "can cause a life-threatening reaction. A long waiting period is needed between them.",
        management="Absolutely contraindicated. Wait at least 14 days after stopping MAO "
        "inhibitor before starting fluoxetine. Wait 5 weeks after stopping fluoxetine "
        "before starting MAO inhibitor (due to long half-life of norfluoxetine).",
        sources=["FDA Black Box Warning", "NIH DailyMed - Fluoxetine Label"],
        aliases_a=["Prozac", "Sarafem"],
        aliases_b=[
            "phenelzine", "Nardil", "tranylcypromine", "Parnate",
            "isocarboxazid", "Marplan", "selegiline", "Emsam",
        ],
    ),
    DrugInteraction(
        drug_a="fluoxetine",
        drug_b="metoprolol",
        severity="moderate",
        mechanism="Fluoxetine inhibits CYP2D6, the primary enzyme metabolizing metoprolol. "
        "This can increase metoprolol plasma levels 3-5 fold.",
        clinical_description="Elevated metoprolol levels may cause excessive bradycardia, "
        "hypotension, and heart failure exacerbation.",
        patient_description="Your antidepressant can make your heart medication much stronger, "
        "potentially causing your heart rate and blood pressure to drop too low.",
        management="Monitor heart rate and blood pressure. Consider dose reduction of "
        "metoprolol or switch to atenolol (not CYP2D6 substrate).",
        sources=["NIH DailyMed - Metoprolol Label", "Flockhart DA, Drug Interactions"],
        aliases_a=["Prozac", "Sarafem"],
        aliases_b=["Lopressor", "Toprol-XL"],
    ),
    # --- Diabetes medication interactions ---
    DrugInteraction(
        drug_a="metformin",
        drug_b="contrast dye",
        severity="major",
        mechanism="Iodinated contrast media can cause acute kidney injury, impairing "
        "metformin clearance and risking lactic acidosis.",
        clinical_description="Risk of metformin-associated lactic acidosis if renal function "
        "deteriorates after contrast administration.",
        patient_description="If you need a CT scan with contrast dye, your metformin may need "
        "to be temporarily stopped to prevent a serious condition.",
        management="Hold metformin on day of and 48 hours after iodinated contrast. "
        "Check renal function before restarting.",
        sources=[
            "ACR Manual on Contrast Media",
            "FDA Drug Safety Communication - Metformin",
        ],
        aliases_a=["Glucophage", "Glumetza", "Fortamet"],
        aliases_b=["iodinated contrast", "IV contrast", "CT contrast"],
    ),
    DrugInteraction(
        drug_a="metformin",
        drug_b="alcohol",
        severity="moderate",
        mechanism="Alcohol potentiates metformin's effect on lactate metabolism "
        "and can cause hypoglycemia.",
        clinical_description="Excessive alcohol intake increases risk of lactic acidosis "
        "and hypoglycemia in metformin users.",
        patient_description="Drinking alcohol while taking metformin increases the risk "
        "of low blood sugar and a rare but serious condition called lactic acidosis.",
        management="Limit alcohol intake. Avoid binge drinking. Educate on signs of "
        "lactic acidosis (weakness, muscle pain, difficulty breathing).",
        sources=["NIH DailyMed - Metformin Label"],
        aliases_a=["Glucophage", "Glumetza"],
        aliases_b=["ethanol"],
    ),
    DrugInteraction(
        drug_a="glipizide",
        drug_b="fluconazole",
        severity="major",
        mechanism="Fluconazole inhibits CYP2C9, which metabolizes glipizide. "
        "Increased glipizide levels can cause severe hypoglycemia.",
        clinical_description="Risk of prolonged, severe hypoglycemia requiring hospitalization.",
        patient_description="This antifungal can make your diabetes pill work too strongly, "
        "causing dangerously low blood sugar.",
        management="Monitor blood glucose closely. Consider reducing glipizide dose by 50%. "
        "Educate patient on hypoglycemia symptoms.",
        sources=["FDA Drug Interaction Table", "NIH DailyMed - Glipizide Label"],
        aliases_a=["Glucotrol"],
        aliases_b=["Diflucan"],
    ),
    # --- Antibiotic interactions ---
    DrugInteraction(
        drug_a="ciprofloxacin",
        drug_b="tizanidine",
        severity="major",
        mechanism="Ciprofloxacin is a potent CYP1A2 inhibitor. Tizanidine is primarily "
        "metabolized by CYP1A2. AUC increases up to 10-fold.",
        clinical_description="Contraindicated. Dramatic increase in tizanidine levels "
        "causing severe hypotension and excessive sedation.",
        patient_description="This antibiotic can cause dangerously high levels of your "
        "muscle relaxant, leading to very low blood pressure and extreme drowsiness.",
        management="Contraindicated combination. Use alternative antibiotic or alternative "
        "muscle relaxant (e.g., baclofen).",
        sources=["FDA Drug Interaction Table", "NIH DailyMed - Ciprofloxacin Label"],
        aliases_a=["Cipro"],
        aliases_b=["Zanaflex"],
    ),
    DrugInteraction(
        drug_a="ciprofloxacin",
        drug_b="calcium",
        severity="moderate",
        mechanism="Divalent and trivalent cations chelate fluoroquinolones in the GI tract, "
        "dramatically reducing antibiotic absorption.",
        clinical_description="Calcium supplements can reduce ciprofloxacin absorption by "
        "up to 40%, potentially leading to treatment failure.",
        patient_description="Calcium supplements can prevent your antibiotic from being "
        "absorbed properly, making it less effective.",
        management="Separate administration by at least 2 hours (ciprofloxacin first) "
        "or 6 hours (calcium first). Applies to calcium supplements and dairy.",
        sources=["NIH DailyMed - Ciprofloxacin Label"],
        aliases_a=["Cipro"],
        aliases_b=["calcium carbonate", "calcium citrate", "Caltrate", "Tums"],
    ),
    DrugInteraction(
        drug_a="metronidazole",
        drug_b="alcohol",
        severity="major",
        mechanism="Metronidazole inhibits aldehyde dehydrogenase, causing accumulation "
        "of acetaldehyde when alcohol is consumed (disulfiram-like reaction).",
        clinical_description="Disulfiram-like reaction: severe nausea, vomiting, flushing, "
        "tachycardia, hypotension.",
        patient_description="Drinking ANY alcohol while taking this antibiotic (and for 3 days "
        "after stopping) can cause severe nausea, vomiting, and flushing.",
        management="Absolutely avoid alcohol during treatment and for 72 hours after "
        "last dose. Includes alcohol in foods, mouthwash, and topical products.",
        sources=["FDA Drug Interaction Table", "NIH DailyMed - Metronidazole Label"],
        aliases_a=["Flagyl"],
        aliases_b=["ethanol", "beer", "wine"],
    ),
    # --- Blood pressure medication interactions ---
    DrugInteraction(
        drug_a="amlodipine",
        drug_b="simvastatin",
        severity="moderate",
        mechanism="Amlodipine inhibits CYP3A4, increasing simvastatin levels. "
        "Risk of myopathy is dose-dependent.",
        clinical_description="Simvastatin dose should not exceed 20mg/day when combined "
        "with amlodipine due to increased myopathy risk.",
        patient_description="Your blood pressure medication can increase the levels of your "
        "cholesterol medication, raising the risk of muscle problems.",
        management="Limit simvastatin to 20mg/day. Consider switching to atorvastatin "
        "or rosuvastatin.",
        sources=["FDA Drug Safety Communication", "NIH DailyMed - Simvastatin Label"],
        aliases_a=["Norvasc"],
        aliases_b=["Zocor"],
    ),
    # --- PPI interactions ---
    DrugInteraction(
        drug_a="omeprazole",
        drug_b="clopidogrel",
        severity="major",
        mechanism="Omeprazole inhibits CYP2C19, which converts clopidogrel prodrug "
        "to its active metabolite. Reduced antiplatelet effect.",
        clinical_description="Reduced clopidogrel efficacy increases risk of cardiovascular "
        "events including stent thrombosis.",
        patient_description="Your stomach acid medication can make your blood thinner less "
        "effective, increasing your risk of heart attack or stroke.",
        management="Avoid omeprazole with clopidogrel. Use pantoprazole or famotidine instead. "
        "Separate by at least 12 hours if PPI is essential.",
        sources=[
            "FDA Drug Safety Communication (2009)",
            "COGENT Trial Results",
        ],
        aliases_a=["Prilosec", "Losec"],
        aliases_b=["Plavix"],
    ),
    DrugInteraction(
        drug_a="omeprazole",
        drug_b="iron",
        severity="minor",
        mechanism="PPIs reduce gastric acid, decreasing dissolution and absorption "
        "of non-heme iron supplements.",
        clinical_description="Long-term PPI use may reduce iron absorption, potentially "
        "contributing to iron deficiency over time.",
        patient_description="Your stomach acid medication may reduce how well you absorb "
        "iron supplements.",
        management="Take iron supplement on empty stomach, separated from PPI by 2+ hours. "
        "Consider IV iron if oral supplementation fails.",
        sources=["NIH DailyMed - Omeprazole Label"],
        aliases_a=["Prilosec", "Losec"],
        aliases_b=["ferrous sulfate", "ferrous gluconate", "iron supplement"],
    ),
    # --- Supplement interactions ---
    DrugInteraction(
        drug_a="fish oil",
        drug_b="warfarin",
        severity="moderate",
        mechanism="Omega-3 fatty acids have antiplatelet properties and may modestly "
        "potentiate warfarin's anticoagulant effect at high doses (>3g/day).",
        clinical_description="High-dose fish oil (>3g/day EPA+DHA) may increase INR "
        "and bleeding risk in warfarin users.",
        patient_description="High-dose fish oil supplements may increase your bleeding "
        "risk when combined with warfarin.",
        management="Low-dose fish oil (<2g/day) is generally safe. Monitor INR if starting "
        "high-dose fish oil. Inform prescriber.",
        sources=["NIH Office of Dietary Supplements", "Bays HE, Am J Cardiol 2007"],
        aliases_a=["omega-3", "EPA", "DHA", "omega-3 fatty acids"],
        aliases_b=["Coumadin", "Jantoven"],
    ),
    DrugInteraction(
        drug_a="St. John's Wort",
        drug_b="sertraline",
        severity="major",
        mechanism="St. John's Wort has serotonergic activity and induces CYP enzymes. "
        "Combined with SSRIs, risk of serotonin syndrome.",
        clinical_description="Risk of serotonin syndrome. St. John's Wort also induces "
        "CYP3A4, potentially reducing SSRI efficacy.",
        patient_description="This herbal supplement can cause a dangerous reaction with "
        "your antidepressant called serotonin syndrome.",
        management="Avoid combination. If patient wants herbal alternative, must taper "
        "SSRI first under medical supervision.",
        sources=["FDA Drug Safety Communication", "NIH NCCIH - St. John's Wort"],
        aliases_a=["Hypericum perforatum", "SJW"],
        aliases_b=["Zoloft"],
    ),
    DrugInteraction(
        drug_a="St. John's Wort",
        drug_b="oral contraceptives",
        severity="major",
        mechanism="St. John's Wort induces CYP3A4 and P-glycoprotein, accelerating "
        "metabolism of ethinyl estradiol and progestins.",
        clinical_description="Reduced contraceptive efficacy. Breakthrough bleeding "
        "and unintended pregnancy reported.",
        patient_description="This herbal supplement can make birth control pills less "
        "effective, increasing the risk of unintended pregnancy.",
        management="Avoid combination. Use alternative or additional contraception method. "
        "Effect persists for 2 weeks after stopping St. John's Wort.",
        sources=["FDA Drug Interaction Table", "NIH NCCIH - St. John's Wort"],
        aliases_a=["Hypericum perforatum", "SJW"],
        aliases_b=["birth control pills", "ethinyl estradiol", "OCP"],
    ),
    DrugInteraction(
        drug_a="vitamin D",
        drug_b="thiazide diuretics",
        severity="moderate",
        mechanism="Thiazides reduce renal calcium excretion. Combined with vitamin D "
        "(which increases calcium absorption), risk of hypercalcemia.",
        clinical_description="Risk of hypercalcemia with symptoms of nausea, constipation, "
        "confusion, and potential renal calculi.",
        patient_description="Your water pill reduces calcium loss, and vitamin D increases "
        "calcium absorption. Together, calcium levels may get too high.",
        management="Monitor serum calcium periodically. Limit vitamin D to 1000-2000 IU/day. "
        "Watch for hypercalcemia symptoms.",
        sources=["NIH DailyMed", "NIH Office of Dietary Supplements - Vitamin D"],
        aliases_a=["cholecalciferol", "ergocalciferol", "D3", "D2"],
        aliases_b=["hydrochlorothiazide", "HCTZ", "chlorthalidone", "Microzide"],
    ),
    DrugInteraction(
        drug_a="magnesium",
        drug_b="tetracycline",
        severity="moderate",
        mechanism="Magnesium forms insoluble chelates with tetracycline antibiotics "
        "in the GI tract, reducing antibiotic absorption.",
        clinical_description="Magnesium can reduce tetracycline absorption by 50-90%, "
        "potentially leading to treatment failure.",
        patient_description="Magnesium supplements can prevent your antibiotic from working "
        "properly by binding to it in your stomach.",
        management="Separate administration by at least 2-3 hours. Take antibiotic first, "
        "then magnesium supplement later.",
        sources=["NIH DailyMed - Tetracycline Label"],
        aliases_a=["magnesium oxide", "magnesium citrate", "Mg"],
        aliases_b=["doxycycline", "minocycline", "Vibramycin", "Doryx"],
    ),
    DrugInteraction(
        drug_a="calcium",
        drug_b="levothyroxine",
        severity="moderate",
        mechanism="Calcium forms insoluble complexes with levothyroxine in the GI tract, "
        "significantly reducing thyroid hormone absorption.",
        clinical_description="Calcium supplements can reduce levothyroxine absorption by "
        "up to 50%, leading to subtherapeutic thyroid levels.",
        patient_description="Calcium supplements can prevent your thyroid medication from "
        "being properly absorbed.",
        management="Separate by at least 4 hours. Take levothyroxine on empty stomach "
        "in the morning; take calcium in the afternoon/evening.",
        sources=["NIH DailyMed - Levothyroxine Label", "Singh N, et al., Endocrine 2000"],
        aliases_a=["calcium carbonate", "calcium citrate", "Caltrate", "Os-Cal"],
        aliases_b=["Synthroid", "Levoxyl", "Tirosint", "T4"],
    ),
    DrugInteraction(
        drug_a="iron",
        drug_b="levothyroxine",
        severity="moderate",
        mechanism="Iron forms insoluble complexes with levothyroxine, reducing absorption.",
        clinical_description="Iron supplements can decrease levothyroxine absorption, "
        "leading to elevated TSH and hypothyroid symptoms.",
        patient_description="Iron supplements can block your thyroid medication from "
        "being absorbed properly.",
        management="Separate by at least 4 hours. Take levothyroxine in morning, "
        "iron supplement in afternoon.",
        sources=["NIH DailyMed - Levothyroxine Label", "Campbell NR, et al., Ann Intern Med"],
        aliases_a=["ferrous sulfate", "ferrous gluconate", "iron supplement"],
        aliases_b=["Synthroid", "Levoxyl", "Tirosint", "T4"],
    ),
    # --- Cardiac medication interactions ---
    DrugInteraction(
        drug_a="digoxin",
        drug_b="amiodarone",
        severity="major",
        mechanism="Amiodarone inhibits P-glycoprotein and reduces renal clearance of "
        "digoxin, increasing serum levels by 70-100%.",
        clinical_description="Risk of digoxin toxicity: nausea, visual disturbances, "
        "cardiac arrhythmias (potentially fatal).",
        patient_description="This heart rhythm medication can cause your digoxin levels "
        "to become dangerously high, causing serious heart problems.",
        management="Reduce digoxin dose by 50% when starting amiodarone. Monitor digoxin "
        "levels closely. Watch for toxicity signs.",
        sources=["FDA Drug Interaction Table", "NIH DailyMed - Digoxin Label"],
        aliases_a=["Lanoxin"],
        aliases_b=["Cordarone", "Pacerone"],
    ),
    DrugInteraction(
        drug_a="digoxin",
        drug_b="verapamil",
        severity="major",
        mechanism="Verapamil inhibits P-glycoprotein-mediated renal and biliary secretion "
        "of digoxin, increasing serum levels by 50-75%.",
        clinical_description="Increased digoxin levels with additive effects on AV conduction. "
        "Risk of complete heart block and digoxin toxicity.",
        patient_description="This blood pressure medication can increase digoxin levels and "
        "together they can slow your heart dangerously.",
        management="Reduce digoxin dose by 33-50%. Monitor digoxin levels and heart rate. "
        "Watch for AV block on ECG.",
        sources=["FDA Drug Interaction Table", "NIH DailyMed - Digoxin Label"],
        aliases_a=["Lanoxin"],
        aliases_b=["Calan", "Verelan", "Isoptin"],
    ),
    # --- Opioid interactions ---
    DrugInteraction(
        drug_a="oxycodone",
        drug_b="benzodiazepines",
        severity="major",
        mechanism="Both cause CNS depression. Combined use causes additive respiratory "
        "depression, sedation, and risk of fatal overdose.",
        clinical_description="FDA Black Box Warning. Combined opioid-benzodiazepine use "
        "is a leading cause of overdose death.",
        patient_description="Taking these together is extremely dangerous and can cause you "
        "to stop breathing. This combination is a leading cause of overdose death.",
        management="Avoid combination whenever possible. If necessary, use lowest effective "
        "doses and shortest duration. Prescribe naloxone rescue kit.",
        sources=[
            "FDA Black Box Warning (2016)",
            "CDC Guideline for Prescribing Opioids",
        ],
        aliases_a=["OxyContin", "Percocet", "Roxicodone"],
        aliases_b=[
            "diazepam", "Valium", "alprazolam", "Xanax",
            "lorazepam", "Ativan", "clonazepam", "Klonopin",
        ],
    ),
    DrugInteraction(
        drug_a="codeine",
        drug_b="paroxetine",
        severity="major",
        mechanism="Paroxetine is a potent CYP2D6 inhibitor. Codeine requires CYP2D6 "
        "to convert to morphine (active metabolite). Analgesic effect is blocked.",
        clinical_description="Codeine becomes therapeutically ineffective. Patient receives "
        "no analgesic benefit while still exposed to side effects.",
        patient_description="Your antidepressant blocks your body from converting this pain "
        "medication into its active form, so it will not work for pain relief.",
        management="Use alternative analgesic (e.g., non-opioid or opioid that does not "
        "require CYP2D6 activation like morphine or hydromorphone).",
        sources=["FDA Drug Interaction Table", "PharmGKB - CYP2D6"],
        aliases_a=["Tylenol #3"],
        aliases_b=["Paxil", "Brisdelle"],
    ),
    # --- Antifungal interactions ---
    DrugInteraction(
        drug_a="ketoconazole",
        drug_b="cisapride",
        severity="major",
        mechanism="Ketoconazole inhibits CYP3A4, dramatically increasing cisapride levels. "
        "Cisapride blocks cardiac HERG channels at high concentrations.",
        clinical_description="Contraindicated. Risk of QT prolongation, torsades de pointes, "
        "and sudden cardiac death.",
        patient_description="This combination is absolutely prohibited because it can cause "
        "fatal heart rhythm problems.",
        management="Contraindicated combination. Do not co-administer under any circumstances.",
        sources=["FDA Drug Interaction Table", "NIH DailyMed - Ketoconazole Label"],
        aliases_a=["Nizoral"],
        aliases_b=["Propulsid"],
    ),
    # --- Thyroid interactions ---
    DrugInteraction(
        drug_a="levothyroxine",
        drug_b="coffee",
        severity="minor",
        mechanism="Coffee can reduce levothyroxine intestinal absorption, possibly through "
        "increased GI motility or direct binding.",
        clinical_description="Coffee consumed within 30 minutes of levothyroxine can reduce "
        "absorption, leading to slightly subtherapeutic levels.",
        patient_description="Drinking coffee right after taking your thyroid pill can reduce "
        "how much medication your body absorbs.",
        management="Take levothyroxine 30-60 minutes before coffee. Alternatively, consider "
        "liquid or gel-cap formulations which are less affected.",
        sources=["Benvenga S, et al., Thyroid 2008", "NIH DailyMed - Levothyroxine Label"],
        aliases_a=["Synthroid", "Levoxyl", "Tirosint", "T4"],
        aliases_b=["caffeine", "espresso"],
    ),
    # --- Additional common interactions ---
    DrugInteraction(
        drug_a="lithium",
        drug_b="ibuprofen",
        severity="major",
        mechanism="NSAIDs reduce renal prostaglandin synthesis, decreasing lithium clearance "
        "and increasing serum lithium levels by 15-53%.",
        clinical_description="Risk of lithium toxicity: tremor, confusion, ataxia, renal "
        "impairment. Can be fatal at high levels.",
        patient_description="This pain medication can cause dangerous buildup of lithium "
        "in your blood, leading to serious side effects.",
        management="Avoid NSAIDs if possible. If needed short-term, monitor lithium levels "
        "within 5 days. Use acetaminophen as alternative.",
        sources=["FDA Drug Interaction Table", "NIH DailyMed - Lithium Label"],
        aliases_a=["Lithobid", "Eskalith"],
        aliases_b=["Advil", "Motrin", "Nurofen"],
    ),
    DrugInteraction(
        drug_a="methotrexate",
        drug_b="trimethoprim",
        severity="major",
        mechanism="Trimethoprim inhibits dihydrofolate reductase (same target as methotrexate), "
        "causing additive antifolate toxicity.",
        clinical_description="Risk of severe pancytopenia, megaloblastic anemia, and "
        "mucositis. Can be fatal.",
        patient_description="This antibiotic works on the same pathway as your methotrexate, "
        "and together they can cause dangerously low blood counts.",
        management="Avoid combination. Use alternative antibiotic. If unavoidable, monitor "
        "CBC closely and supplement with folinic acid.",
        sources=["NIH DailyMed", "Sathi N, et al., Rheumatology 2006"],
        aliases_a=["Trexall", "Otrexup", "MTX"],
        aliases_b=["Bactrim", "Septra", "TMP-SMX", "sulfamethoxazole-trimethoprim"],
    ),
    DrugInteraction(
        drug_a="sildenafil",
        drug_b="nitrates",
        severity="major",
        mechanism="Both sildenafil and nitrates cause vasodilation via the NO-cGMP pathway. "
        "Combined effect can cause life-threatening hypotension.",
        clinical_description="Contraindicated. Profound hypotension, syncope, myocardial "
        "infarction, and death have been reported.",
        patient_description="Taking Viagra with any nitrate medication (like nitroglycerin) "
        "can cause a life-threatening drop in blood pressure.",
        management="Absolutely contraindicated. Do not administer nitrates within 24 hours "
        "of sildenafil (48 hours for tadalafil).",
        sources=["FDA Black Box Warning", "NIH DailyMed - Sildenafil Label"],
        aliases_a=["Viagra", "Revatio"],
        aliases_b=[
            "nitroglycerin", "isosorbide mononitrate", "isosorbide dinitrate",
            "Nitrostat", "Imdur", "Isordil",
        ],
    ),
    DrugInteraction(
        drug_a="phenytoin",
        drug_b="valproic acid",
        severity="major",
        mechanism="Valproic acid displaces phenytoin from protein binding and inhibits "
        "its metabolism, increasing free phenytoin levels.",
        clinical_description="Increased free phenytoin can cause toxicity (nystagmus, ataxia, "
        "lethargy) despite normal total phenytoin levels.",
        patient_description="These seizure medications interact in a complex way. Your "
        "phenytoin levels may become toxic even if blood tests look normal.",
        management="Monitor free (unbound) phenytoin levels, not just total. Adjust doses "
        "based on clinical response and free levels.",
        sources=["NIH DailyMed - Phenytoin Label", "FDA Drug Interaction Table"],
        aliases_a=["Dilantin"],
        aliases_b=["Depakote", "Depakene", "divalproex"],
    ),
    DrugInteraction(
        drug_a="carbamazepine",
        drug_b="erythromycin",
        severity="major",
        mechanism="Erythromycin inhibits CYP3A4, the primary enzyme metabolizing "
        "carbamazepine, leading to toxic carbamazepine levels.",
        clinical_description="Risk of carbamazepine toxicity: diplopia, dizziness, ataxia, "
        "nausea. Severe cases may cause seizures paradoxically.",
        patient_description="This antibiotic can cause dangerous buildup of your seizure "
        "medication, leading to dizziness and other serious side effects.",
        management="Avoid combination. Use azithromycin as alternative antibiotic. "
        "If unavoidable, reduce carbamazepine dose and monitor levels.",
        sources=["FDA Drug Interaction Table", "NIH DailyMed - Carbamazepine Label"],
        aliases_a=["Tegretol", "Carbatrol"],
        aliases_b=["E-Mycin", "Ery-Tab", "EES"],
    ),
    DrugInteraction(
        drug_a="ginkgo biloba",
        drug_b="warfarin",
        severity="moderate",
        mechanism="Ginkgo has antiplatelet properties and may inhibit platelet-activating "
        "factor (PAF), potentially increasing bleeding risk with warfarin.",
        clinical_description="Case reports of bleeding events (including subdural hematoma) "
        "in patients taking ginkgo with anticoagulants.",
        patient_description="This herbal supplement can increase your bleeding risk when "
        "taken with warfarin.",
        management="Avoid ginkgo supplements while on warfarin. If used, monitor INR closely "
        "and watch for bleeding signs.",
        sources=["NIH NCCIH - Ginkgo", "Bone KM, Drug Saf 2008"],
        aliases_a=["ginkgo", "Ginkgo biloba extract", "EGb 761"],
        aliases_b=["Coumadin", "Jantoven"],
    ),
    DrugInteraction(
        drug_a="turmeric",
        drug_b="warfarin",
        severity="moderate",
        mechanism="Curcumin (active compound in turmeric) has antiplatelet and anticoagulant "
        "properties and may inhibit CYP enzymes involved in warfarin metabolism.",
        clinical_description="Potential for increased INR and bleeding risk, particularly "
        "with concentrated curcumin supplements.",
        patient_description="Turmeric/curcumin supplements may increase your bleeding risk "
        "when combined with warfarin.",
        management="Dietary turmeric in food is generally safe. Avoid concentrated curcumin "
        "supplements. Monitor INR if using any turmeric products regularly.",
        sources=["NIH NCCIH - Turmeric", "Kim DC, et al., J Ethnopharmacol 2014"],
        aliases_a=["curcumin", "curcuma longa"],
        aliases_b=["Coumadin", "Jantoven"],
    ),
    DrugInteraction(
        drug_a="vitamin E",
        drug_b="warfarin",
        severity="moderate",
        mechanism="High-dose vitamin E (>400 IU/day) may have anticoagulant properties "
        "and can potentiate warfarin's effect.",
        clinical_description="Doses >400 IU/day may increase INR and bleeding risk.",
        patient_description="High-dose vitamin E supplements may increase your bleeding risk "
        "when taken with warfarin.",
        management="Limit vitamin E to <400 IU/day. Monitor INR if starting or stopping "
        "vitamin E supplements.",
        sources=["NIH Office of Dietary Supplements - Vitamin E"],
        aliases_a=["alpha-tocopherol", "tocopherol"],
        aliases_b=["Coumadin", "Jantoven"],
    ),
    DrugInteraction(
        drug_a="melatonin",
        drug_b="warfarin",
        severity="minor",
        mechanism="Melatonin may have mild anticoagulant properties and could theoretically "
        "enhance warfarin's effect.",
        clinical_description="Limited evidence suggests possible modest INR increase.",
        patient_description="Melatonin may slightly increase your warfarin's blood-thinning "
        "effect, though the risk is considered low.",
        management="Generally considered low risk at typical doses (0.5-5mg). Monitor INR "
        "when starting melatonin.",
        sources=["NIH Office of Dietary Supplements"],
        aliases_a=[],
        aliases_b=["Coumadin", "Jantoven"],
    ),
    DrugInteraction(
        drug_a="vitamin D",
        drug_b="atorvastatin",
        severity="minor",
        mechanism="Both vitamin D and atorvastatin are metabolized by CYP3A4. "
        "Theoretical competition for metabolism.",
        clinical_description="Minimal clinical significance. Vitamin D supplementation may "
        "actually improve statin tolerability.",
        patient_description="Vitamin D is generally safe to take with your cholesterol "
        "medication. In fact, it may help with muscle-related side effects.",
        management="No specific precautions needed. Combination is generally safe and "
        "potentially beneficial.",
        sources=["Khayznikov M, et al., N Am J Med Sci 2015"],
        aliases_a=["cholecalciferol", "D3", "ergocalciferol", "D2"],
        aliases_b=["Lipitor"],
    ),
    DrugInteraction(
        drug_a="probiotics",
        drug_b="antibiotics",
        severity="minor",
        mechanism="Antibiotics may kill probiotic organisms, reducing their efficacy. "
        "Probiotics do not typically affect antibiotic action.",
        clinical_description="Probiotic efficacy may be reduced if taken simultaneously "
        "with antibiotics. Timing separation is beneficial.",
        patient_description="Your antibiotic may kill the beneficial bacteria in your "
        "probiotic supplement. Separate the timing for best results.",
        management="Take probiotic at least 2 hours after antibiotic dose. Continue "
        "probiotics for 1-2 weeks after completing antibiotic course.",
        sources=[
            "NIH NCCIH - Probiotics",
            "World Gastroenterology Organisation Global Guidelines",
        ],
        aliases_a=["Lactobacillus", "Bifidobacterium", "Saccharomyces"],
        aliases_b=[
            "amoxicillin", "azithromycin", "ciprofloxacin",
            "doxycycline", "penicillin",
        ],
    ),
]
