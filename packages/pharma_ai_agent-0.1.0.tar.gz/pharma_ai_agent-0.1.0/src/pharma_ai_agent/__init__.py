"""Pharma AI Agent - Evidence-based drug information powered by RAG."""

from pharma_ai_agent.agent import PharmaAgent
from pharma_ai_agent.config import AgentConfig

__version__ = "0.1.0"
__all__ = ["PharmaAgent", "AgentConfig"]
