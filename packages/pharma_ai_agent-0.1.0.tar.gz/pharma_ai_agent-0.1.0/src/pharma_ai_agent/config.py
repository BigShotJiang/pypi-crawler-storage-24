"""Agent configuration."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Literal


@dataclass
class AgentConfig:
    """Configuration for PharmaAgent."""

    provider: Literal["openai", "anthropic"] = "openai"
    api_key: str = ""
    model: str = ""
    locale: Literal["en", "ko"] = "en"
    strict_mode: bool = True
    max_retries: int = 2
    temperature: float = 0.1
    max_tokens: int = 2048

    # Safety thresholds
    min_safety_score: float = 0.7
    require_sources: bool = True

    # Tool configuration
    enabled_tools: list[str] = field(
        default_factory=lambda: [
            "interaction_checker",
            "dosage_checker",
            "drug_lookup",
            "source_finder",
        ]
    )

    @classmethod
    def from_env(cls) -> AgentConfig:
        """Create configuration from environment variables."""
        return cls(
            provider=os.getenv("PHARMA_PROVIDER", "openai"),  # type: ignore[arg-type]
            api_key=os.getenv("OPENAI_API_KEY", "")
            if os.getenv("PHARMA_PROVIDER", "openai") == "openai"
            else os.getenv("ANTHROPIC_API_KEY", ""),
            model=os.getenv("PHARMA_MODEL", ""),
            locale=os.getenv("PHARMA_LOCALE", "en"),  # type: ignore[arg-type]
            strict_mode=os.getenv("PHARMA_STRICT_MODE", "true").lower() == "true",
        )

    @property
    def resolved_model(self) -> str:
        """Return the model name, falling back to provider defaults."""
        if self.model:
            return self.model
        defaults = {
            "openai": "gpt-4o",
            "anthropic": "claude-sonnet-4-20250514",
        }
        return defaults.get(self.provider, "gpt-4o")
