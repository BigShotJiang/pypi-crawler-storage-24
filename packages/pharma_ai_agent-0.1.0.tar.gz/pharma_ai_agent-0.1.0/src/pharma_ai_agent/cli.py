"""Interactive CLI chat interface for PharmaAgent."""

from __future__ import annotations

import sys

import click

from pharma_ai_agent.agent import PharmaAgent
from pharma_ai_agent.config import AgentConfig


@click.command()
@click.option(
    "--provider",
    type=click.Choice(["openai", "anthropic"]),
    default=None,
    help="LLM provider (default: from env or openai)",
)
@click.option("--api-key", default=None, help="API key (default: from env)")
@click.option("--model", default=None, help="Model name override")
@click.option(
    "--locale",
    type=click.Choice(["en", "ko"]),
    default=None,
    help="Response language",
)
@click.option("--strict/--no-strict", default=None, help="Strict safety mode")
@click.option("--offline", is_flag=True, help="Run without LLM (knowledge base only)")
def main(
    provider: str | None,
    api_key: str | None,
    model: str | None,
    locale: str | None,
    strict: bool | None,
    offline: bool,
) -> None:
    """Pharma AI Agent - Evidence-based drug information assistant.

    Ask questions about drug interactions, supplement safety, and dosage limits.
    All responses are grounded in verified data from FDA, NIH, and WHO sources.
    """
    # Build config from env, then override with CLI args
    config = AgentConfig.from_env()
    if provider:
        config.provider = provider  # type: ignore[assignment]
    if api_key:
        config.api_key = api_key
    if model:
        config.model = model
    if locale:
        config.locale = locale  # type: ignore[assignment]
    if strict is not None:
        config.strict_mode = strict

    if offline:
        config.api_key = ""  # Force offline mode

    agent = PharmaAgent(config=config)

    stats = agent.knowledge_stats
    click.echo("=" * 60)
    click.echo("  Pharma AI Agent - Drug Information Assistant")
    click.echo("=" * 60)
    click.echo(
        f"  Knowledge base: {stats['drug_interactions']} interactions, "
        f"{stats['supplement_profiles']} supplements"
    )
    click.echo(f"  Provider: {config.provider} ({config.resolved_model})")
    click.echo(f"  Locale: {config.locale} | Strict mode: {config.strict_mode}")
    if offline:
        click.echo("  Mode: OFFLINE (knowledge base only, no LLM)")
    click.echo("=" * 60)
    click.echo('  Type your question, or "quit" to exit.')
    click.echo()

    while True:
        try:
            query = click.prompt("You", prompt_suffix="> ").strip()
        except (EOFError, KeyboardInterrupt):
            click.echo("\nGoodbye!")
            sys.exit(0)

        if not query:
            continue
        if query.lower() in ("quit", "exit", "q"):
            click.echo("Goodbye!")
            break

        # Handle special commands
        if query.lower() == "stats":
            click.echo(f"Knowledge base: {stats}")
            continue

        if query.lower().startswith("check "):
            # Batch check: "check warfarin ibuprofen vitamin D"
            meds = query[6:].strip().split()
            if len(meds) < 2:
                click.echo("Please provide at least 2 medications to check.")
                continue
            results = agent.check_medications(meds)
            for pair, result in results.items():
                severity = result.get("severity", "none")
                icon = {"major": "!!!", "moderate": "!!", "minor": "!", "none": "-"}
                click.echo(
                    f"  [{icon.get(severity, '?')}] {pair[0]} + {pair[1]}: "
                    f"{severity} - {result.get('description', 'No interaction found')}"
                )
            continue

        # Regular query
        click.echo()
        response = agent.ask(query)

        if response.blocked:
            click.echo(f"[BLOCKED] {response.answer}")
        else:
            click.echo(response.answer)

            if response.sources:
                click.echo("\nSources:")
                for source in response.sources[:5]:
                    click.echo(f"  - {source}")

            click.echo(f"\n[Safety score: {response.safety_score}]")

        click.echo()


if __name__ == "__main__":
    main()
