"""Response templates for structured agent output."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ResponseTemplate:
    """Template for structuring agent responses."""

    answer: str = ""
    interactions: list[dict] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    safety_score: float = 1.0
    disclaimer: str = ""
    locale: str = "en"

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "answer": self.answer,
            "interactions": self.interactions,
            "sources": self.sources,
            "safety_score": self.safety_score,
            "disclaimer": self.disclaimer,
        }

    @staticmethod
    def format_interaction_summary(interactions: list[dict]) -> str:
        """Format interaction data into a readable summary."""
        if not interactions:
            return "No known interactions found in the database."

        lines = []
        for inter in interactions:
            severity = inter.get("severity", "unknown").upper()
            drug_a = inter.get("drug_a", "Unknown")
            drug_b = inter.get("drug_b", "Unknown")
            desc = inter.get("patient_description", inter.get("description", ""))
            lines.append(f"[{severity}] {drug_a} + {drug_b}: {desc}")

        return "\n".join(lines)

    @staticmethod
    def format_sources(sources: list[str]) -> str:
        """Format source citations into a readable list."""
        if not sources:
            return "No sources available."
        return "\n".join(f"- {source}" for source in sources)
