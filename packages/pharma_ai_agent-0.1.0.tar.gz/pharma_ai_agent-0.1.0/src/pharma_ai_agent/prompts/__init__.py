"""System prompts and response templates."""

from pharma_ai_agent.prompts.system import SYSTEM_PROMPT, get_system_prompt
from pharma_ai_agent.prompts.templates import ResponseTemplate

__all__ = ["SYSTEM_PROMPT", "get_system_prompt", "ResponseTemplate"]
