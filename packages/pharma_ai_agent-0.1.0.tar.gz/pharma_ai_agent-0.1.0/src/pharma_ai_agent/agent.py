"""Main PharmaAgent class.

Orchestrates knowledge retrieval, tool execution, LLM generation,
and safety checks to produce evidence-based drug information responses.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Literal

from pharma_ai_agent.config import AgentConfig
from pharma_ai_agent.knowledge.retriever import KnowledgeRetriever
from pharma_ai_agent.prompts.system import get_system_prompt
from pharma_ai_agent.prompts.templates import ResponseTemplate
from pharma_ai_agent.providers.base import BaseLLMProvider
from pharma_ai_agent.safety.disclaimer import DisclaimerInjector
from pharma_ai_agent.safety.guardrail import SafetyGuardrail
from pharma_ai_agent.tools.dosage_checker import DosageChecker
from pharma_ai_agent.tools.drug_lookup import DrugLookup
from pharma_ai_agent.tools.interaction_checker import InteractionChecker
from pharma_ai_agent.tools.source_finder import SourceFinder


@dataclass
class AgentResponse:
    """Complete response from the PharmaAgent."""

    answer: str
    interactions: list[dict] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    safety_score: float = 1.0
    disclaimer: str = ""
    tool_calls_made: list[str] = field(default_factory=list)
    blocked: bool = False
    block_reason: str = ""

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "answer": self.answer,
            "interactions": self.interactions,
            "sources": self.sources,
            "safety_score": self.safety_score,
            "disclaimer": self.disclaimer,
            "tool_calls_made": self.tool_calls_made,
            "blocked": self.blocked,
        }


class PharmaAgent:
    """AI agent for evidence-based drug information queries.

    Uses RAG (Retrieval Augmented Generation) to ground LLM responses
    in verified drug interaction and supplement safety data.

    Args:
        provider: LLM provider name ("openai" or "anthropic").
        api_key: API key for the LLM provider.
        model: Model name override (uses provider default if empty).
        locale: Response language ("en" or "ko").
        strict_mode: Enable strict safety checks.
        config: Full AgentConfig (overrides individual params).

    Example:
        >>> agent = PharmaAgent(provider="openai", api_key="sk-...")
        >>> response = agent.ask("Can I take ibuprofen with warfarin?")
        >>> print(response.answer)
        >>> print(response.safety_score)
    """

    def __init__(
        self,
        provider: str = "openai",
        api_key: str = "",
        model: str = "",
        locale: Literal["en", "ko"] = "en",
        strict_mode: bool = True,
        config: AgentConfig | None = None,
    ) -> None:
        if config:
            self._config = config
        else:
            self._config = AgentConfig(
                provider=provider,  # type: ignore[arg-type]
                api_key=api_key,
                model=model,
                locale=locale,  # type: ignore[arg-type]
                strict_mode=strict_mode,
            )

        # Initialize components
        self._retriever = KnowledgeRetriever()
        self._guardrail = SafetyGuardrail(strict_mode=self._config.strict_mode)
        self._disclaimer = DisclaimerInjector(locale=self._config.locale)

        # Initialize tools
        self._interaction_checker = InteractionChecker(self._retriever)
        self._dosage_checker = DosageChecker(self._retriever)
        self._drug_lookup = DrugLookup(self._retriever)
        self._source_finder = SourceFinder(self._retriever)

        self._tools = {
            "interaction_checker": self._interaction_checker,
            "dosage_checker": self._dosage_checker,
            "drug_lookup": self._drug_lookup,
            "source_finder": self._source_finder,
        }

        # Initialize LLM provider (lazy - only when needed)
        self._llm: BaseLLMProvider | None = None

    def _get_llm(self) -> BaseLLMProvider:
        """Get or create the LLM provider."""
        if self._llm is not None:
            return self._llm

        if self._config.provider == "openai":
            from pharma_ai_agent.providers.openai_provider import OpenAIProvider
            self._llm = OpenAIProvider(
                api_key=self._config.api_key,
                model=self._config.resolved_model,
            )
        elif self._config.provider == "anthropic":
            from pharma_ai_agent.providers.anthropic_provider import AnthropicProvider
            self._llm = AnthropicProvider(
                api_key=self._config.api_key,
                model=self._config.resolved_model,
            )
        else:
            raise ValueError(f"Unsupported provider: {self._config.provider}")

        return self._llm

    def ask(self, query: str) -> AgentResponse:
        """Ask a drug/supplement information question.

        Performs the full RAG pipeline:
        1. Pre-check query safety
        2. Retrieve relevant knowledge
        3. Build context-aware system prompt
        4. Generate LLM response with tool use
        5. Post-check response safety
        6. Inject disclaimer

        Args:
            query: Natural language question about drugs or supplements.

        Returns:
            AgentResponse with answer, sources, safety score, and disclaimer.
        """
        # Step 1: Pre-check query safety
        pre_check = self._guardrail.pre_check(query)
        if not pre_check.safe:
            return AgentResponse(
                answer=self._get_blocked_message(pre_check.flags),
                blocked=True,
                block_reason=", ".join(pre_check.flags),
                disclaimer=self._disclaimer.disclaimer,
                safety_score=pre_check.score,
            )

        # Step 2: Retrieve relevant knowledge
        retrieval = self._retriever.search(query)

        # Step 3: Build system prompt with context
        system_prompt = get_system_prompt(
            context=retrieval.context_text,
            locale=self._config.locale,
        )

        # Step 4: Collect tool results
        tool_calls_made: list[str] = []
        all_interactions: list[dict] = []
        all_sources: list[str] = []

        # Auto-execute relevant tools based on retrieval
        for interaction in retrieval.interactions:
            result = self._interaction_checker.check_pair(
                interaction.drug_a, interaction.drug_b
            )
            if result.found:
                all_interactions.append(result.to_dict())
                all_sources.extend(result.sources)
                tool_calls_made.append("interaction_checker")

        for supplement in retrieval.supplements:
            source_result = self._source_finder.find(supplement.name)
            all_sources.extend(source_result.sources)
            tool_calls_made.append("source_finder")

        # Step 5: Generate LLM response
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query},
        ]

        # Add tool results as context if we have any
        if all_interactions:
            tool_context = (
                "Tool results:\n"
                + json.dumps(all_interactions, indent=2, default=str)
            )
            messages.append({"role": "user", "content": tool_context})

        try:
            llm = self._get_llm()
            tool_schemas = [tool.get_tool_schema() for tool in self._tools.values()]
            llm_response = llm.chat(
                messages=messages,
                tools=tool_schemas,
                temperature=self._config.temperature,
                max_tokens=self._config.max_tokens,
            )

            # Handle any additional tool calls from LLM
            if llm_response.has_tool_calls:
                for tc in llm_response.tool_calls:
                    tool_result = self._execute_tool(tc["name"], tc["arguments"])
                    tool_calls_made.append(tc["name"])
                    if tool_result:
                        messages.append({
                            "role": "assistant",
                            "content": json.dumps(
                                {"tool_call": tc["name"], "result": tool_result},
                                default=str,
                            ),
                        })

                # Get final response after tool execution
                llm_response = llm.chat(
                    messages=messages,
                    temperature=self._config.temperature,
                    max_tokens=self._config.max_tokens,
                )

            answer = llm_response.content

        except Exception as e:
            # Fallback to knowledge-base-only response
            answer = self._build_fallback_response(query, retrieval, all_interactions)
            if not answer:
                answer = f"I encountered an error accessing the AI model: {e}. " \
                         "However, here is what I found in the verified database."

        # Step 6: Post-check response safety
        post_check = self._guardrail.post_check(answer, query)

        # Step 7: Inject disclaimer
        answer_with_disclaimer = self._disclaimer.inject(answer)

        # Deduplicate sources
        unique_sources = list(dict.fromkeys(all_sources))

        return AgentResponse(
            answer=answer_with_disclaimer,
            interactions=all_interactions,
            sources=unique_sources,
            safety_score=post_check.score,
            disclaimer=self._disclaimer.disclaimer,
            tool_calls_made=list(set(tool_calls_made)),
            blocked=False,
        )

    def check_medications(
        self, medications: list[str]
    ) -> dict[tuple[str, str], dict]:
        """Check all pairwise interactions among a list of medications.

        Args:
            medications: List of drug/supplement names.

        Returns:
            Dictionary mapping (drug_a, drug_b) pairs to interaction results.
        """
        results = self._interaction_checker.check_multiple(medications)
        return {pair: result.to_dict() for pair, result in results.items()}

    def _execute_tool(self, tool_name: str, arguments: dict) -> dict | None:
        """Execute a tool by name with the given arguments."""
        if tool_name == "interaction_checker":
            result = self._interaction_checker.check_pair(
                arguments.get("drug_a", ""),
                arguments.get("drug_b", ""),
            )
            return result.to_dict()
        elif tool_name == "dosage_checker":
            result = self._dosage_checker.check(
                arguments.get("supplement_name", ""),
                arguments.get("dose", ""),
            )
            return result.to_dict()
        elif tool_name == "drug_lookup":
            result = self._drug_lookup.lookup(arguments.get("query", ""))
            return result.to_dict()
        elif tool_name == "source_finder":
            result = self._source_finder.find(arguments.get("query", ""))
            return result.to_dict()
        return None

    def _build_fallback_response(
        self, query: str, retrieval, interactions: list[dict]
    ) -> str:
        """Build a response using only knowledge base data (no LLM)."""
        parts: list[str] = []

        if interactions:
            parts.append("Based on verified data, here are the relevant interactions:\n")
            for inter in interactions:
                severity = inter.get("severity", "unknown").upper()
                drug_a = inter.get("drug_a", "")
                drug_b = inter.get("drug_b", "")
                desc = inter.get("patient_description", inter.get("description", ""))
                mgmt = inter.get("management", "")
                parts.append(f"**[{severity}] {drug_a} + {drug_b}**")
                parts.append(f"{desc}")
                if mgmt:
                    parts.append(f"Management: {mgmt}")
                parts.append("")

        if retrieval.supplements:
            parts.append("Supplement information:\n")
            for supp in retrieval.supplements:
                parts.append(f"**{supp.name}**")
                parts.append(f"RDA: {supp.rda_adult}")
                parts.append(f"Upper Limit: {supp.upper_limit}")
                if supp.drug_interactions_summary:
                    parts.append(f"Drug Interactions: {supp.drug_interactions_summary}")
                parts.append("")

        if not parts:
            return ""

        parts.append(
            "Please consult your doctor or pharmacist for personalized advice."
        )
        return "\n".join(parts)

    def _get_blocked_message(self, flags: list[str]) -> str:
        """Return an appropriate message for blocked queries."""
        if self._config.locale == "ko":
            return (
                "이 질문에는 답변할 수 없습니다. 긴급한 의료 상황이라면 "
                "119에 전화하거나 가까운 응급실을 방문해주세요. "
                "정신건강 위기상담: 1577-0199"
            )
        return (
            "I'm unable to provide information for this type of query. "
            "If you are experiencing a medical emergency, please call 911 "
            "or go to your nearest emergency room. "
            "Crisis helpline: 988 Suicide & Crisis Lifeline."
        )

    @property
    def knowledge_stats(self) -> dict:
        """Return statistics about the embedded knowledge base."""
        return {
            "drug_interactions": self._retriever.interaction_count,
            "supplement_profiles": self._retriever.supplement_count,
        }
