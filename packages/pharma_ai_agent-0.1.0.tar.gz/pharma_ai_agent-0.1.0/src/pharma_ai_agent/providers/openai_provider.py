"""OpenAI GPT provider integration."""

from __future__ import annotations

import json

from pharma_ai_agent.providers.base import BaseLLMProvider, LLMResponse


class OpenAIProvider(BaseLLMProvider):
    """OpenAI GPT provider.

    Args:
        api_key: OpenAI API key.
        model: Model name (default: gpt-4o).
    """

    def __init__(self, api_key: str, model: str = "gpt-4o") -> None:
        self.model = model
        try:
            from openai import OpenAI
            self._client = OpenAI(api_key=api_key)
        except ImportError as e:
            raise ImportError(
                "OpenAI package is required. Install with: pip install openai>=1.0"
            ) from e

    def chat(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        temperature: float = 0.1,
        max_tokens: int = 2048,
    ) -> LLMResponse:
        """Send a chat completion request to OpenAI.

        Args:
            messages: Conversation messages.
            tools: Optional tool schemas.
            temperature: Sampling temperature.
            max_tokens: Maximum response tokens.

        Returns:
            LLMResponse with the model's response.
        """
        kwargs: dict = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"

        response = self._client.chat.completions.create(**kwargs)
        choice = response.choices[0]

        tool_calls = []
        if choice.message.tool_calls:
            for tc in choice.message.tool_calls:
                tool_calls.append({
                    "id": tc.id,
                    "name": tc.function.name,
                    "arguments": json.loads(tc.function.arguments),
                })

        return LLMResponse(
            content=choice.message.content or "",
            tool_calls=tool_calls,
            model=response.model,
            usage={
                "prompt_tokens": response.usage.prompt_tokens if response.usage else 0,
                "completion_tokens": response.usage.completion_tokens if response.usage else 0,
                "total_tokens": response.usage.total_tokens if response.usage else 0,
            },
            finish_reason=choice.finish_reason or "",
        )

    def get_model_name(self) -> str:
        """Return the OpenAI model name."""
        return self.model
