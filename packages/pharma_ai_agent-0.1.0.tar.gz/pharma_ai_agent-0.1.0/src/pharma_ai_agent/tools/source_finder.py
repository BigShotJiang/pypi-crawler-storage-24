"""Source citation finder tool.

Finds authoritative source citations (FDA, NIH, WHO) relevant to a query.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from pharma_ai_agent.knowledge.retriever import KnowledgeRetriever


@dataclass
class SourceResult:
    """Result containing authoritative source citations."""

    query: str
    sources: list[str] = field(default_factory=list)
    source_urls: list[dict[str, str]] = field(default_factory=list)

    @property
    def has_sources(self) -> bool:
        """Check if any sources were found."""
        return bool(self.sources)

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "query": self.query,
            "sources": self.sources,
            "source_urls": self.source_urls,
        }


# Well-known authoritative source URLs
_AUTHORITY_URLS: dict[str, str] = {
    "FDA": "https://www.fda.gov/drugs",
    "FDA Drug Interaction Table": "https://www.fda.gov/drugs/drug-interactions-labeling/drug-development-and-drug-interactions-table-substrates-inhibitors-and-inducers",
    "NIH DailyMed": "https://dailymed.nlm.nih.gov/dailymed/",
    "NIH ODS": "https://ods.od.nih.gov/factsheets/",
    "NIH NCCIH": "https://www.nccih.nih.gov/health",
    "WHO": "https://www.who.int/medicines",
    "CDC": "https://www.cdc.gov/medication-safety/",
    "PharmGKB": "https://www.pharmgkb.org/",
    "Natural Medicines": "https://naturalmedicines.therapeuticresearch.com/",
}


class SourceFinder:
    """Tool for finding authoritative source citations.

    Searches the knowledge base and returns relevant FDA, NIH, WHO,
    and other authoritative citations.
    """

    name = "source_finder"
    description = (
        "Find authoritative source citations (FDA, NIH, WHO) relevant "
        "to a drug or supplement query."
    )

    def __init__(self, retriever: KnowledgeRetriever | None = None) -> None:
        self.retriever = retriever or KnowledgeRetriever()

    def find(self, query: str) -> SourceResult:
        """Find authoritative sources for a query.

        Args:
            query: Drug, supplement, or interaction query.

        Returns:
            SourceResult with citations and reference URLs.
        """
        retrieval = self.retriever.search(query, top_k=10)

        all_sources: list[str] = []
        for interaction in retrieval.interactions:
            all_sources.extend(interaction.sources)
        for supplement in retrieval.supplements:
            all_sources.extend(supplement.sources)

        # Deduplicate while preserving order
        unique_sources = list(dict.fromkeys(all_sources))

        # Match sources to authority URLs
        source_urls: list[dict[str, str]] = []
        for source in unique_sources:
            url = self._match_authority_url(source)
            source_urls.append({"citation": source, "url": url})

        return SourceResult(
            query=query,
            sources=unique_sources,
            source_urls=source_urls,
        )

    @staticmethod
    def _match_authority_url(source: str) -> str:
        """Match a source citation to an authoritative URL."""
        source_lower = source.lower()
        for key, url in _AUTHORITY_URLS.items():
            if key.lower() in source_lower:
                return url
        # Default to general search
        return f"https://pubmed.ncbi.nlm.nih.gov/?term={source.replace(' ', '+')}"

    def get_tool_schema(self) -> dict:
        """Return the tool schema for LLM function calling."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Drug, supplement, or interaction to find sources for",
                        },
                    },
                    "required": ["query"],
                },
            },
        }
