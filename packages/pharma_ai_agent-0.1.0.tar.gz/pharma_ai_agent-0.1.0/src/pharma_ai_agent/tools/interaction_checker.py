"""Drug interaction check tool.

Checks pairs of drugs/supplements against the embedded knowledge base
and returns structured interaction data.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from typing import Literal

from pharma_ai_agent.knowledge.retriever import KnowledgeRetriever


@dataclass
class InteractionResult:
    """Result of checking a drug pair for interactions."""

    drug_a: str
    drug_b: str
    found: bool
    severity: Literal["major", "moderate", "minor", "none"] = "none"
    mechanism: str = ""
    description: str = ""
    patient_description: str = ""
    management: str = ""
    sources: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "drug_a": self.drug_a,
            "drug_b": self.drug_b,
            "found": self.found,
            "severity": self.severity,
            "mechanism": self.mechanism,
            "description": self.description,
            "patient_description": self.patient_description,
            "management": self.management,
            "sources": self.sources,
        }


class InteractionChecker:
    """Tool for checking drug-drug and drug-supplement interactions.

    Uses the embedded knowledge base for exact matching, providing
    high-confidence interaction data.
    """

    name = "interaction_checker"
    description = (
        "Check for known interactions between two drugs or supplements. "
        "Returns severity, mechanism, and management recommendations."
    )

    def __init__(self, retriever: KnowledgeRetriever | None = None) -> None:
        self.retriever = retriever or KnowledgeRetriever()

    def check_pair(self, drug_a: str, drug_b: str) -> InteractionResult:
        """Check for interactions between two drugs.

        Args:
            drug_a: First drug/supplement name.
            drug_b: Second drug/supplement name.

        Returns:
            InteractionResult with any found interaction data.
        """
        interactions = self.retriever.find_interactions(drug_a, drug_b)

        if not interactions:
            return InteractionResult(
                drug_a=drug_a,
                drug_b=drug_b,
                found=False,
            )

        # Return the most severe interaction found
        interaction = max(
            interactions,
            key=lambda i: {"major": 3, "moderate": 2, "minor": 1}.get(i.severity, 0),
        )

        return InteractionResult(
            drug_a=drug_a,
            drug_b=drug_b,
            found=True,
            severity=interaction.severity,
            mechanism=interaction.mechanism,
            description=interaction.clinical_description,
            patient_description=interaction.patient_description,
            management=interaction.management,
            sources=interaction.sources,
        )

    def check_multiple(
        self, medications: list[str]
    ) -> dict[tuple[str, str], InteractionResult]:
        """Check all pairwise interactions among a list of medications.

        Args:
            medications: List of drug/supplement names.

        Returns:
            Dictionary mapping drug pairs to interaction results.
        """
        results: dict[tuple[str, str], InteractionResult] = {}

        for drug_a, drug_b in itertools.combinations(medications, 2):
            pair = (drug_a, drug_b)
            results[pair] = self.check_pair(drug_a, drug_b)

        return results

    def get_tool_schema(self) -> dict:
        """Return the tool schema for LLM function calling."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "drug_a": {
                            "type": "string",
                            "description": "First drug or supplement name",
                        },
                        "drug_b": {
                            "type": "string",
                            "description": "Second drug or supplement name",
                        },
                    },
                    "required": ["drug_a", "drug_b"],
                },
            },
        }
