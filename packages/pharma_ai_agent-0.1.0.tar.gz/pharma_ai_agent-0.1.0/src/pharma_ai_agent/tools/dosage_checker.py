"""Dosage safety check tool.

Validates mentioned dosages against known supplement upper limits
and recommended daily allowances.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Literal

from pharma_ai_agent.knowledge.retriever import KnowledgeRetriever


@dataclass
class DosageResult:
    """Result of a dosage safety check."""

    supplement_name: str
    mentioned_dose: str
    found: bool
    status: Literal["safe", "caution", "exceeds_ul", "unknown"] = "unknown"
    rda: str = ""
    upper_limit: str = ""
    common_doses: str = ""
    warnings: list[str] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "supplement_name": self.supplement_name,
            "mentioned_dose": self.mentioned_dose,
            "found": self.found,
            "status": self.status,
            "rda": self.rda,
            "upper_limit": self.upper_limit,
            "warnings": self.warnings,
            "sources": self.sources,
        }


def _extract_numeric_mg(dose_str: str) -> float | None:
    """Try to extract a numeric mg value from a dose string."""
    dose_str = dose_str.lower().strip()

    # Handle IU to approximate mg conversions for common supplements
    iu_match = re.search(r"([\d,]+(?:\.\d+)?)\s*iu", dose_str)
    if iu_match:
        return float(iu_match.group(1).replace(",", ""))

    # Handle mcg
    mcg_match = re.search(r"([\d,]+(?:\.\d+)?)\s*(?:mcg|ug)", dose_str)
    if mcg_match:
        return float(mcg_match.group(1).replace(",", "")) / 1000  # convert to mg

    # Handle mg
    mg_match = re.search(r"([\d,]+(?:\.\d+)?)\s*(?:mg|milligram)", dose_str)
    if mg_match:
        return float(mg_match.group(1).replace(",", ""))

    # Handle g
    g_match = re.search(r"([\d,]+(?:\.\d+)?)\s*(?:g|gram)(?![\w])", dose_str)
    if g_match:
        return float(g_match.group(1).replace(",", "")) * 1000

    return None


class DosageChecker:
    """Tool for checking supplement dosage safety.

    Validates dosages against known RDAs and upper tolerable intake levels.
    """

    name = "dosage_checker"
    description = (
        "Check if a supplement dosage is within safe limits. "
        "Returns RDA, upper limit, and safety status."
    )

    def __init__(self, retriever: KnowledgeRetriever | None = None) -> None:
        self.retriever = retriever or KnowledgeRetriever()

    def check(self, supplement_name: str, dose: str = "") -> DosageResult:
        """Check dosage safety for a supplement.

        Args:
            supplement_name: Name of the supplement.
            dose: Mentioned dosage (e.g., "5000 IU", "500 mg").

        Returns:
            DosageResult with safety assessment.
        """
        supplement = self.retriever.find_supplement(supplement_name)

        if supplement is None:
            return DosageResult(
                supplement_name=supplement_name,
                mentioned_dose=dose,
                found=False,
                status="unknown",
                warnings=["Supplement not found in knowledge base. Cannot verify dosage safety."],
            )

        warnings: list[str] = []
        status: Literal["safe", "caution", "exceeds_ul", "unknown"] = "safe"

        if supplement.special_populations:
            warnings.append(f"Special populations: {supplement.special_populations}")

        if supplement.toxicity_symptoms:
            warnings.append(f"Toxicity signs: {supplement.toxicity_symptoms}")

        # If a specific dose was mentioned, try basic comparison
        if dose:
            numeric_dose = _extract_numeric_mg(dose)
            numeric_ul = _extract_numeric_mg(supplement.upper_limit)

            if numeric_dose is not None and numeric_ul is not None and numeric_ul > 0:
                if numeric_dose > numeric_ul:
                    status = "exceeds_ul"
                    warnings.insert(
                        0,
                        f"Mentioned dose ({dose}) exceeds the upper tolerable "
                        f"intake level ({supplement.upper_limit}).",
                    )
                elif numeric_dose > numeric_ul * 0.8:
                    status = "caution"
                    warnings.insert(
                        0,
                        f"Mentioned dose ({dose}) is approaching the upper "
                        f"tolerable intake level ({supplement.upper_limit}).",
                    )

        return DosageResult(
            supplement_name=supplement.name,
            mentioned_dose=dose,
            found=True,
            status=status,
            rda=supplement.rda_adult,
            upper_limit=supplement.upper_limit,
            common_doses=supplement.common_doses,
            warnings=warnings,
            sources=supplement.sources,
        )

    def get_tool_schema(self) -> dict:
        """Return the tool schema for LLM function calling."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "supplement_name": {
                            "type": "string",
                            "description": "Name of the supplement to check",
                        },
                        "dose": {
                            "type": "string",
                            "description": "Dosage to validate (e.g., '5000 IU', '500 mg')",
                        },
                    },
                    "required": ["supplement_name"],
                },
            },
        }
