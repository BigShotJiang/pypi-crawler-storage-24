"""Drug/supplement information lookup tool.

Provides comprehensive information about a drug or supplement from
the embedded knowledge base.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from pharma_ai_agent.knowledge.retriever import KnowledgeRetriever


@dataclass
class LookupResult:
    """Result of a drug/supplement lookup."""

    query: str
    found: bool
    item_type: str = ""  # "drug_interaction", "supplement", "both"
    name: str = ""
    summary: str = ""
    interactions: list[dict] = field(default_factory=list)
    supplement_info: dict = field(default_factory=dict)
    sources: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "query": self.query,
            "found": self.found,
            "item_type": self.item_type,
            "name": self.name,
            "summary": self.summary,
            "interactions": self.interactions,
            "supplement_info": self.supplement_info,
            "sources": self.sources,
        }


class DrugLookup:
    """Tool for looking up comprehensive drug/supplement information.

    Searches the knowledge base and returns all known information
    about a drug or supplement.
    """

    name = "drug_lookup"
    description = (
        "Look up comprehensive information about a drug or supplement. "
        "Returns known interactions, safety data, and source citations."
    )

    def __init__(self, retriever: KnowledgeRetriever | None = None) -> None:
        self.retriever = retriever or KnowledgeRetriever()

    def lookup(self, query: str) -> LookupResult:
        """Look up information about a drug or supplement.

        Args:
            query: Drug or supplement name to look up.

        Returns:
            LookupResult with all available information.
        """
        retrieval = self.retriever.search(query, top_k=10)

        if not retrieval.has_results:
            return LookupResult(
                query=query,
                found=False,
                summary=f"No information found for '{query}' in the knowledge base.",
            )

        interactions_data = []
        all_sources: list[str] = []

        for interaction in retrieval.interactions:
            interactions_data.append(interaction.to_dict())
            all_sources.extend(interaction.sources)

        supplement_info = {}
        if retrieval.supplements:
            # Use the best matching supplement
            best_supplement = retrieval.supplements[0]
            supplement_info = best_supplement.to_dict()
            all_sources.extend(best_supplement.sources)

        # Determine type
        has_interactions = bool(interactions_data)
        has_supplement = bool(supplement_info)
        if has_interactions and has_supplement:
            item_type = "both"
        elif has_interactions:
            item_type = "drug_interaction"
        else:
            item_type = "supplement"

        # Build summary
        summary_parts = []
        if has_interactions:
            severity_counts = {"major": 0, "moderate": 0, "minor": 0}
            for inter in retrieval.interactions:
                severity_counts[inter.severity] = severity_counts.get(inter.severity, 0) + 1
            summary_parts.append(
                f"Found {len(interactions_data)} interaction(s): "
                f"{severity_counts['major']} major, "
                f"{severity_counts['moderate']} moderate, "
                f"{severity_counts['minor']} minor."
            )
        if has_supplement:
            summary_parts.append(
                f"Supplement data available: RDA {supplement_info.get('rda_adult', 'N/A')}, "
                f"Upper Limit {supplement_info.get('upper_limit', 'N/A')}."
            )

        # Deduplicate sources
        unique_sources = list(dict.fromkeys(all_sources))

        return LookupResult(
            query=query,
            found=True,
            item_type=item_type,
            name=query,
            summary=" ".join(summary_parts),
            interactions=interactions_data,
            supplement_info=supplement_info,
            sources=unique_sources,
        )

    def get_tool_schema(self) -> dict:
        """Return the tool schema for LLM function calling."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Drug or supplement name to look up",
                        },
                    },
                    "required": ["query"],
                },
            },
        }
