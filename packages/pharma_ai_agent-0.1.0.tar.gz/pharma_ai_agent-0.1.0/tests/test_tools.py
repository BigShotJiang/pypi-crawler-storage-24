"""Tests for agent tools."""

from __future__ import annotations

import pytest

from pharma_ai_agent.knowledge.retriever import KnowledgeRetriever
from pharma_ai_agent.tools.interaction_checker import InteractionChecker, InteractionResult
from pharma_ai_agent.tools.dosage_checker import DosageChecker, DosageResult
from pharma_ai_agent.tools.drug_lookup import DrugLookup, LookupResult
from pharma_ai_agent.tools.source_finder import SourceFinder, SourceResult


@pytest.fixture
def retriever():
    return KnowledgeRetriever()


class TestInteractionChecker:
    """Tests for InteractionChecker tool."""

    def test_check_known_interaction(self, retriever):
        checker = InteractionChecker(retriever)
        result = checker.check_pair("warfarin", "ibuprofen")
        assert result.found is True
        assert result.severity == "major"
        assert len(result.sources) > 0

    def test_check_by_brand_name(self, retriever):
        checker = InteractionChecker(retriever)
        result = checker.check_pair("Coumadin", "Advil")
        assert result.found is True
        assert result.severity == "major"

    def test_check_no_interaction(self, retriever):
        checker = InteractionChecker(retriever)
        result = checker.check_pair("aspirin", "metformin")
        assert result.found is False
        assert result.severity == "none"

    def test_check_order_independent(self, retriever):
        checker = InteractionChecker(retriever)
        result1 = checker.check_pair("warfarin", "ibuprofen")
        result2 = checker.check_pair("ibuprofen", "warfarin")
        assert result1.found == result2.found
        assert result1.severity == result2.severity

    def test_check_multiple(self, retriever):
        checker = InteractionChecker(retriever)
        results = checker.check_multiple(["warfarin", "ibuprofen", "vitamin D"])
        assert len(results) == 3  # C(3,2) = 3 pairs

    def test_check_multiple_finds_known(self, retriever):
        checker = InteractionChecker(retriever)
        results = checker.check_multiple(["warfarin", "aspirin", "ibuprofen"])
        # Both warfarin+aspirin and warfarin+ibuprofen should be found
        found_count = sum(1 for r in results.values() if r.found)
        assert found_count >= 2

    def test_result_to_dict(self, retriever):
        checker = InteractionChecker(retriever)
        result = checker.check_pair("warfarin", "ibuprofen")
        d = result.to_dict()
        assert "drug_a" in d
        assert "severity" in d
        assert "sources" in d

    def test_tool_schema(self, retriever):
        checker = InteractionChecker(retriever)
        schema = checker.get_tool_schema()
        assert schema["type"] == "function"
        assert schema["function"]["name"] == "interaction_checker"
        assert "drug_a" in schema["function"]["parameters"]["properties"]


class TestDosageChecker:
    """Tests for DosageChecker tool."""

    def test_check_known_supplement(self, retriever):
        checker = DosageChecker(retriever)
        result = checker.check("Vitamin D")
        assert result.found is True
        assert result.rda != ""
        assert result.upper_limit != ""

    def test_check_by_alias(self, retriever):
        checker = DosageChecker(retriever)
        result = checker.check("D3")
        assert result.found is True
        assert result.supplement_name == "Vitamin D"

    def test_check_unknown_supplement(self, retriever):
        checker = DosageChecker(retriever)
        result = checker.check("Xylitol Phosphatide Complex 9000")
        assert result.found is False
        assert result.status == "unknown"

    def test_check_exceeds_upper_limit(self, retriever):
        checker = DosageChecker(retriever)
        result = checker.check("Vitamin D", "50000 IU")
        assert result.found is True
        assert result.status == "exceeds_ul"

    def test_check_safe_dose(self, retriever):
        checker = DosageChecker(retriever)
        result = checker.check("Vitamin D", "1000 IU")
        assert result.found is True
        assert result.status == "safe"

    def test_check_has_warnings(self, retriever):
        checker = DosageChecker(retriever)
        result = checker.check("Iron", "100 mg")
        assert result.found is True
        assert len(result.warnings) > 0

    def test_result_to_dict(self, retriever):
        checker = DosageChecker(retriever)
        result = checker.check("Calcium", "500 mg")
        d = result.to_dict()
        assert "supplement_name" in d
        assert "status" in d

    def test_tool_schema(self, retriever):
        checker = DosageChecker(retriever)
        schema = checker.get_tool_schema()
        assert schema["function"]["name"] == "dosage_checker"


class TestDrugLookup:
    """Tests for DrugLookup tool."""

    def test_lookup_known_drug(self, retriever):
        lookup = DrugLookup(retriever)
        result = lookup.lookup("warfarin")
        assert result.found is True
        assert len(result.interactions) > 0

    def test_lookup_known_supplement(self, retriever):
        lookup = DrugLookup(retriever)
        result = lookup.lookup("Vitamin D")
        assert result.found is True
        assert result.supplement_info != {}

    def test_lookup_unknown(self, retriever):
        lookup = DrugLookup(retriever)
        result = lookup.lookup("completely_unknown_drug_xyz")
        assert result.found is False

    def test_lookup_returns_sources(self, retriever):
        lookup = DrugLookup(retriever)
        result = lookup.lookup("warfarin")
        assert len(result.sources) > 0

    def test_lookup_summary(self, retriever):
        lookup = DrugLookup(retriever)
        result = lookup.lookup("warfarin")
        assert result.summary != ""

    def test_result_to_dict(self, retriever):
        lookup = DrugLookup(retriever)
        result = lookup.lookup("warfarin")
        d = result.to_dict()
        assert "query" in d
        assert "found" in d
        assert "interactions" in d

    def test_tool_schema(self, retriever):
        lookup = DrugLookup(retriever)
        schema = lookup.get_tool_schema()
        assert schema["function"]["name"] == "drug_lookup"


class TestSourceFinder:
    """Tests for SourceFinder tool."""

    def test_find_sources_for_known_drug(self, retriever):
        finder = SourceFinder(retriever)
        result = finder.find("warfarin")
        assert result.has_sources is True
        assert len(result.sources) > 0

    def test_find_sources_include_urls(self, retriever):
        finder = SourceFinder(retriever)
        result = finder.find("warfarin ibuprofen interaction")
        assert len(result.source_urls) > 0
        for source_url in result.source_urls:
            assert "citation" in source_url
            assert "url" in source_url

    def test_find_sources_fda(self, retriever):
        finder = SourceFinder(retriever)
        result = finder.find("warfarin")
        # At least one FDA source should exist for warfarin
        fda_sources = [s for s in result.sources if "FDA" in s]
        assert len(fda_sources) > 0

    def test_find_no_sources(self, retriever):
        finder = SourceFinder(retriever)
        result = finder.find("completely_unknown_xyz_12345")
        assert result.has_sources is False

    def test_result_to_dict(self, retriever):
        finder = SourceFinder(retriever)
        result = finder.find("vitamin D")
        d = result.to_dict()
        assert "query" in d
        assert "sources" in d

    def test_tool_schema(self, retriever):
        finder = SourceFinder(retriever)
        schema = finder.get_tool_schema()
        assert schema["function"]["name"] == "source_finder"
