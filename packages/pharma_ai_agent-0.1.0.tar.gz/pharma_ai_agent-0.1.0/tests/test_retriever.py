"""Tests for the knowledge retriever and text indexer."""

from __future__ import annotations

import pytest

from pharma_ai_agent.knowledge.indexer import TextIndexer
from pharma_ai_agent.knowledge.retriever import KnowledgeRetriever, RetrievalResult


class TestTextIndexer:
    """Tests for BM25-like text indexer."""

    def test_tokenize(self):
        tokens = TextIndexer.tokenize("Hello, World! This is a test.")
        assert "hello" in tokens
        assert "world" in tokens
        assert "test" in tokens

    def test_tokenize_removes_short(self):
        tokens = TextIndexer.tokenize("I am a big test")
        assert "i" not in tokens  # Single char removed (< 2)
        assert "am" in tokens
        assert "big" in tokens

    def test_add_and_search(self):
        indexer = TextIndexer()
        indexer.add_document("doc1", "warfarin ibuprofen interaction bleeding risk")
        indexer.add_document("doc2", "vitamin D calcium supplement bone health")
        indexer.add_document("doc3", "metformin diabetes blood sugar glucose")

        results = indexer.search("warfarin bleeding")
        assert len(results) > 0
        assert results[0][0].doc_id == "doc1"

    def test_search_relevance_order(self):
        indexer = TextIndexer()
        indexer.add_document("exact", "warfarin ibuprofen drug interaction")
        indexer.add_document("partial", "warfarin is a blood thinner medication")
        indexer.add_document("unrelated", "vitamin D sunshine calcium bones")

        results = indexer.search("warfarin ibuprofen interaction")
        assert results[0][0].doc_id == "exact"

    def test_search_no_results(self):
        indexer = TextIndexer()
        indexer.add_document("doc1", "aspirin headache pain relief")
        results = indexer.search("completely unrelated query xyz")
        # May or may not return results depending on term overlap
        for doc, score in results:
            assert score > 0

    def test_search_empty_query(self):
        indexer = TextIndexer()
        indexer.add_document("doc1", "test document")
        results = indexer.search("")
        assert len(results) == 0

    def test_search_top_k(self):
        indexer = TextIndexer()
        for i in range(20):
            indexer.add_document(f"doc{i}", f"drug interaction test document {i}")
        results = indexer.search("drug interaction", top_k=5)
        assert len(results) <= 5

    def test_clear(self):
        indexer = TextIndexer()
        indexer.add_document("doc1", "test")
        assert indexer.doc_count == 1
        indexer.clear()
        assert indexer.doc_count == 0
        assert len(indexer.search("test")) == 0

    def test_metadata_preserved(self):
        indexer = TextIndexer()
        indexer.add_document("doc1", "test", metadata={"type": "interaction", "index": 5})
        results = indexer.search("test")
        assert results[0][0].metadata["type"] == "interaction"
        assert results[0][0].metadata["index"] == 5


class TestKnowledgeRetriever:
    """Tests for KnowledgeRetriever."""

    def test_find_interactions_exact(self):
        retriever = KnowledgeRetriever()
        results = retriever.find_interactions("warfarin", "ibuprofen")
        assert len(results) > 0
        assert results[0].severity == "major"

    def test_find_interactions_brand_names(self):
        retriever = KnowledgeRetriever()
        results = retriever.find_interactions("Coumadin", "Advil")
        assert len(results) > 0

    def test_find_interactions_order_independent(self):
        retriever = KnowledgeRetriever()
        r1 = retriever.find_interactions("warfarin", "ibuprofen")
        r2 = retriever.find_interactions("ibuprofen", "warfarin")
        assert len(r1) == len(r2)

    def test_find_interactions_not_found(self):
        retriever = KnowledgeRetriever()
        results = retriever.find_interactions("water", "sunshine")
        assert len(results) == 0

    def test_find_supplement(self):
        retriever = KnowledgeRetriever()
        result = retriever.find_supplement("Vitamin D")
        assert result is not None
        assert result.name == "Vitamin D"

    def test_find_supplement_by_alias(self):
        retriever = KnowledgeRetriever()
        result = retriever.find_supplement("D3")
        assert result is not None
        assert result.name == "Vitamin D"

    def test_find_supplement_not_found(self):
        retriever = KnowledgeRetriever()
        result = retriever.find_supplement("NonexistentSupplement")
        assert result is None

    def test_search_returns_result(self):
        retriever = KnowledgeRetriever()
        result = retriever.search("warfarin ibuprofen")
        assert isinstance(result, RetrievalResult)
        assert result.has_results is True

    def test_search_context_text(self):
        retriever = KnowledgeRetriever()
        result = retriever.search("warfarin ibuprofen interaction")
        assert result.context_text != ""
        assert "warfarin" in result.context_text.lower()

    def test_search_no_results(self):
        retriever = KnowledgeRetriever()
        result = retriever.search("xyznonexistentquery12345")
        # May still find partial matches
        assert isinstance(result, RetrievalResult)

    def test_interaction_count(self):
        retriever = KnowledgeRetriever()
        assert retriever.interaction_count > 0

    def test_supplement_count(self):
        retriever = KnowledgeRetriever()
        assert retriever.supplement_count > 0

    def test_search_supplement_query(self):
        retriever = KnowledgeRetriever()
        result = retriever.search("vitamin D safety upper limit dosage")
        assert result.has_results is True
        # Should find vitamin D in supplements
        supplement_names = [s.name for s in result.supplements]
        assert any("Vitamin D" in name for name in supplement_names)


class TestRetrievalResult:
    """Tests for RetrievalResult."""

    def test_has_results_true(self):
        from pharma_ai_agent.knowledge.drug_db import DrugInteraction
        result = RetrievalResult(
            query="test",
            interactions=[DrugInteraction(
                drug_a="a", drug_b="b", severity="minor",
                mechanism="t", clinical_description="t",
                patient_description="t", management="t",
            )],
        )
        assert result.has_results is True

    def test_has_results_false(self):
        result = RetrievalResult(query="test")
        assert result.has_results is False

    def test_edge_case_misspelling(self):
        """Retriever should handle misspellings gracefully."""
        retriever = KnowledgeRetriever()
        # "warfrin" is a misspelling of "warfarin"
        result = retriever.search("warfrin ibuprofin")
        # May or may not find results, but should not crash
        assert isinstance(result, RetrievalResult)
