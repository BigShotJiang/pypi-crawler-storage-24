"""Tests for the knowledge base modules."""

from __future__ import annotations

import pytest

from pharma_ai_agent.knowledge.drug_db import DRUG_INTERACTIONS, DrugInteraction
from pharma_ai_agent.knowledge.supplement_db import SUPPLEMENT_LIMITS, SupplementLimit


class TestDrugInteraction:
    """Tests for DrugInteraction dataclass."""

    def test_matches_generic_names(self):
        interaction = DrugInteraction(
            drug_a="warfarin",
            drug_b="ibuprofen",
            severity="major",
            mechanism="test",
            clinical_description="test",
            patient_description="test",
            management="test",
        )
        assert interaction.matches("warfarin", "ibuprofen") is True
        assert interaction.matches("ibuprofen", "warfarin") is True

    def test_matches_brand_names(self):
        interaction = DrugInteraction(
            drug_a="warfarin",
            drug_b="ibuprofen",
            severity="major",
            mechanism="test",
            clinical_description="test",
            patient_description="test",
            management="test",
            aliases_a=["Coumadin"],
            aliases_b=["Advil", "Motrin"],
        )
        assert interaction.matches("Coumadin", "Advil") is True
        assert interaction.matches("Motrin", "warfarin") is True

    def test_matches_case_insensitive(self):
        interaction = DrugInteraction(
            drug_a="warfarin",
            drug_b="ibuprofen",
            severity="major",
            mechanism="test",
            clinical_description="test",
            patient_description="test",
            management="test",
        )
        assert interaction.matches("WARFARIN", "IBUPROFEN") is True
        assert interaction.matches("Warfarin", "Ibuprofen") is True

    def test_no_match(self):
        interaction = DrugInteraction(
            drug_a="warfarin",
            drug_b="ibuprofen",
            severity="major",
            mechanism="test",
            clinical_description="test",
            patient_description="test",
            management="test",
        )
        assert interaction.matches("aspirin", "metformin") is False

    def test_to_dict(self):
        interaction = DrugInteraction(
            drug_a="warfarin",
            drug_b="ibuprofen",
            severity="major",
            mechanism="test mechanism",
            clinical_description="test clinical",
            patient_description="test patient",
            management="test management",
            sources=["FDA"],
        )
        d = interaction.to_dict()
        assert d["drug_a"] == "warfarin"
        assert d["severity"] == "major"
        assert "FDA" in d["sources"]

    def test_all_names(self):
        interaction = DrugInteraction(
            drug_a="warfarin",
            drug_b="ibuprofen",
            severity="major",
            mechanism="test",
            clinical_description="test",
            patient_description="test",
            management="test",
            aliases_a=["Coumadin", "Jantoven"],
            aliases_b=["Advil"],
        )
        assert "warfarin" in interaction.all_names_a
        assert "coumadin" in interaction.all_names_a
        assert "advil" in interaction.all_names_b


class TestDrugInteractionsDB:
    """Tests for the embedded drug interaction database."""

    def test_db_not_empty(self):
        assert len(DRUG_INTERACTIONS) > 0

    def test_db_has_minimum_entries(self):
        assert len(DRUG_INTERACTIONS) >= 30

    def test_all_have_required_fields(self):
        for interaction in DRUG_INTERACTIONS:
            assert interaction.drug_a, f"Missing drug_a in {interaction}"
            assert interaction.drug_b, f"Missing drug_b in {interaction}"
            assert interaction.severity in ("major", "moderate", "minor")
            assert interaction.mechanism
            assert interaction.clinical_description
            assert interaction.patient_description
            assert interaction.management

    def test_all_have_sources(self):
        for interaction in DRUG_INTERACTIONS:
            assert len(interaction.sources) > 0, (
                f"Missing sources for {interaction.drug_a} + {interaction.drug_b}"
            )

    def test_severity_distribution(self):
        severities = [i.severity for i in DRUG_INTERACTIONS]
        assert "major" in severities
        assert "moderate" in severities
        assert "minor" in severities

    def test_warfarin_ibuprofen_exists(self):
        found = any(i.matches("warfarin", "ibuprofen") for i in DRUG_INTERACTIONS)
        assert found is True

    def test_contraindicated_pairs_are_major(self):
        """Contraindicated pairs should always be major severity."""
        critical_pairs = [
            ("fluoxetine", "MAO inhibitors"),
            ("sildenafil", "nitrates"),
            ("ketoconazole", "cisapride"),
        ]
        for drug_a, drug_b in critical_pairs:
            for interaction in DRUG_INTERACTIONS:
                if interaction.matches(drug_a, drug_b):
                    assert interaction.severity == "major", (
                        f"{drug_a} + {drug_b} should be major severity"
                    )


class TestSupplementLimit:
    """Tests for SupplementLimit dataclass."""

    def test_matches_name(self):
        supplement = SupplementLimit(
            name="Vitamin D",
            category="vitamin",
            rda_adult="600 IU",
            upper_limit="4000 IU",
            common_doses="1000 IU",
            toxicity_symptoms="test",
            deficiency_symptoms="test",
            food_sources="test",
            special_populations="test",
            drug_interactions_summary="test",
            aliases=["D3", "cholecalciferol"],
        )
        assert supplement.matches("Vitamin D") is True
        assert supplement.matches("D3") is True
        assert supplement.matches("cholecalciferol") is True

    def test_matches_case_insensitive(self):
        supplement = SupplementLimit(
            name="Vitamin D",
            category="vitamin",
            rda_adult="",
            upper_limit="",
            common_doses="",
            toxicity_symptoms="",
            deficiency_symptoms="",
            food_sources="",
            special_populations="",
            drug_interactions_summary="",
        )
        assert supplement.matches("vitamin d") is True
        assert supplement.matches("VITAMIN D") is True

    def test_to_dict(self):
        supplement = SupplementLimit(
            name="Iron",
            category="mineral",
            rda_adult="18 mg",
            upper_limit="45 mg",
            common_doses="18-65 mg",
            toxicity_symptoms="nausea",
            deficiency_symptoms="fatigue",
            food_sources="meat",
            special_populations="test",
            drug_interactions_summary="test interactions",
            sources=["NIH"],
        )
        d = supplement.to_dict()
        assert d["name"] == "Iron"
        assert d["category"] == "mineral"
        assert "NIH" in d["sources"]


class TestSupplementsDB:
    """Tests for the embedded supplement database."""

    def test_db_not_empty(self):
        assert len(SUPPLEMENT_LIMITS) > 0

    def test_db_has_minimum_entries(self):
        assert len(SUPPLEMENT_LIMITS) >= 20

    def test_all_have_required_fields(self):
        for supplement in SUPPLEMENT_LIMITS:
            assert supplement.name
            assert supplement.category in (
                "vitamin", "mineral", "herbal", "amino_acid", "other"
            )
            assert supplement.rda_adult
            assert supplement.upper_limit

    def test_all_have_sources(self):
        for supplement in SUPPLEMENT_LIMITS:
            assert len(supplement.sources) > 0, (
                f"Missing sources for {supplement.name}"
            )

    def test_common_supplements_exist(self):
        names = {s.name.lower() for s in SUPPLEMENT_LIMITS}
        for expected in ["vitamin d", "calcium", "iron", "magnesium", "zinc"]:
            assert expected in names, f"Missing common supplement: {expected}"

    def test_categories_represented(self):
        categories = {s.category for s in SUPPLEMENT_LIMITS}
        assert "vitamin" in categories
        assert "mineral" in categories
        assert "herbal" in categories
