"""Tests for the main PharmaAgent class."""

from __future__ import annotations

import pytest

from pharma_ai_agent.agent import AgentResponse, PharmaAgent
from pharma_ai_agent.config import AgentConfig
from tests.conftest import MockLLMProvider


class TestAgentResponse:
    """Tests for AgentResponse dataclass."""

    def test_to_dict(self):
        response = AgentResponse(
            answer="Test answer",
            interactions=[{"drug_a": "warfarin", "drug_b": "ibuprofen"}],
            sources=["FDA"],
            safety_score=0.9,
            disclaimer="Test disclaimer",
        )
        d = response.to_dict()
        assert d["answer"] == "Test answer"
        assert len(d["interactions"]) == 1
        assert d["safety_score"] == 0.9
        assert d["blocked"] is False

    def test_blocked_response(self):
        response = AgentResponse(
            answer="Blocked",
            blocked=True,
            block_reason="self_harm",
        )
        assert response.blocked is True


class TestPharmaAgent:
    """Tests for PharmaAgent."""

    def test_init_default(self):
        agent = PharmaAgent(provider="openai", api_key="test")
        assert agent._config.provider == "openai"
        assert agent._config.strict_mode is True

    def test_init_with_config(self):
        config = AgentConfig(provider="anthropic", api_key="test", locale="ko")
        agent = PharmaAgent(config=config)
        assert agent._config.locale == "ko"

    def test_knowledge_stats(self, agent: PharmaAgent):
        stats = agent.knowledge_stats
        assert stats["drug_interactions"] > 0
        assert stats["supplement_profiles"] > 0

    def test_ask_returns_response(self, agent: PharmaAgent):
        response = agent.ask("Can I take ibuprofen with warfarin?")
        assert isinstance(response, AgentResponse)
        assert response.answer != ""
        assert response.blocked is False

    def test_ask_includes_disclaimer(self, agent: PharmaAgent):
        response = agent.ask("Is vitamin D safe?")
        # Disclaimer should be in the answer or as separate field
        assert response.disclaimer != ""

    def test_ask_blocked_harmful_query(self, agent: PharmaAgent):
        response = agent.ask("How much ibuprofen to die from overdose?")
        assert response.blocked is True
        assert response.block_reason != ""

    def test_ask_blocked_self_harm(self, agent: PharmaAgent):
        response = agent.ask("I want to kill myself with pills")
        assert response.blocked is True

    def test_check_medications(self, agent: PharmaAgent):
        results = agent.check_medications(["warfarin", "ibuprofen", "vitamin D"])
        assert len(results) == 3  # 3 pairs from 3 medications
        # warfarin+ibuprofen should be found
        warfarin_ibuprofen = results.get(("warfarin", "ibuprofen"))
        assert warfarin_ibuprofen is not None
        assert warfarin_ibuprofen["found"] is True
        assert warfarin_ibuprofen["severity"] == "major"

    def test_check_medications_no_interaction(self, agent: PharmaAgent):
        results = agent.check_medications(["aspirin", "metformin"])
        pair = ("aspirin", "metformin")
        assert pair in results
        assert results[pair]["found"] is False

    def test_fallback_response_without_llm(self):
        """Agent should work without LLM using knowledge base only."""
        config = AgentConfig(provider="openai", api_key="")
        agent = PharmaAgent(config=config)
        # Force LLM to fail
        agent._llm = MockLLMProvider(response_text="")

        response = agent.ask("warfarin ibuprofen interaction")
        # Should still produce a response from the knowledge base
        assert isinstance(response, AgentResponse)

    def test_agent_response_has_sources(self, agent: PharmaAgent):
        response = agent.ask("Tell me about warfarin and aspirin interaction")
        # Sources should come from the knowledge base
        assert isinstance(response.sources, list)

    def test_locale_ko(self):
        config = AgentConfig(provider="openai", api_key="test", locale="ko")
        agent = PharmaAgent(config=config)
        agent._llm = MockLLMProvider(response_text="한국어 응답 테스트")
        response = agent.ask("이부프로펜과 와파린을 같이 먹어도 되나요?")
        assert isinstance(response, AgentResponse)


class TestAgentConfig:
    """Tests for AgentConfig."""

    def test_defaults(self):
        config = AgentConfig()
        assert config.provider == "openai"
        assert config.strict_mode is True
        assert config.locale == "en"

    def test_resolved_model_default(self):
        config = AgentConfig(provider="openai")
        assert config.resolved_model == "gpt-4o"

    def test_resolved_model_anthropic(self):
        config = AgentConfig(provider="anthropic")
        assert config.resolved_model == "claude-sonnet-4-20250514"

    def test_resolved_model_override(self):
        config = AgentConfig(provider="openai", model="gpt-4-turbo")
        assert config.resolved_model == "gpt-4-turbo"

    def test_from_env(self, monkeypatch):
        monkeypatch.setenv("PHARMA_PROVIDER", "anthropic")
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.setenv("PHARMA_LOCALE", "ko")
        monkeypatch.setenv("PHARMA_STRICT_MODE", "false")

        config = AgentConfig.from_env()
        assert config.provider == "anthropic"
        assert config.api_key == "test-key"
        assert config.locale == "ko"
        assert config.strict_mode is False
