"""Shared test fixtures for pharma-ai-agent tests."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from pharma_ai_agent.agent import PharmaAgent
from pharma_ai_agent.config import AgentConfig
from pharma_ai_agent.knowledge.retriever import KnowledgeRetriever
from pharma_ai_agent.providers.base import BaseLLMProvider, LLMResponse


class MockLLMProvider(BaseLLMProvider):
    """Mock LLM provider for testing without API keys."""

    def __init__(self, response_text: str = "", tool_calls: list[dict] | None = None):
        self._response_text = response_text
        self._tool_calls = tool_calls or []

    def chat(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        temperature: float = 0.1,
        max_tokens: int = 2048,
    ) -> LLMResponse:
        return LLMResponse(
            content=self._response_text,
            tool_calls=self._tool_calls,
            model="mock-model",
            usage={"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150},
            finish_reason="stop",
        )

    def get_model_name(self) -> str:
        return "mock-model"


@pytest.fixture
def retriever() -> KnowledgeRetriever:
    """Provide a KnowledgeRetriever instance."""
    return KnowledgeRetriever()


@pytest.fixture
def mock_provider() -> MockLLMProvider:
    """Provide a mock LLM provider."""
    return MockLLMProvider(
        response_text=(
            "Based on FDA data, warfarin and ibuprofen have a MAJOR interaction. "
            "NSAIDs increase bleeding risk when combined with warfarin. "
            "Source: FDA Drug Safety Communication. "
            "Please consult your healthcare provider before making any changes."
        )
    )


@pytest.fixture
def agent_config() -> AgentConfig:
    """Provide a test agent configuration."""
    return AgentConfig(
        provider="openai",
        api_key="test-key",
        strict_mode=True,
        locale="en",
    )


@pytest.fixture
def agent(agent_config: AgentConfig, mock_provider: MockLLMProvider) -> PharmaAgent:
    """Provide a PharmaAgent with mock LLM provider."""
    pharma_agent = PharmaAgent(config=agent_config)
    pharma_agent._llm = mock_provider
    return pharma_agent
