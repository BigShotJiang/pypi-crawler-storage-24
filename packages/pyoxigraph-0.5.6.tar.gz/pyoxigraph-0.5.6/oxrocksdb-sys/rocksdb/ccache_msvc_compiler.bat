ccache.exe cl.exe %*
