"""
ndslive.mapviewer - Python CLI and API for running the NDS MapViewer Docker container.

Usage:
    from ndslive.mapviewer import MapViewer

    # Start with config file
    mv = MapViewer(config="config.yaml", edition="community")
    mv.start()

    # Or with context manager
    with MapViewer(config="config.yaml") as mv:
        mv.start()
        print(f"MapViewer at {mv.url}")
"""

try:
    from ._version import __version__, __commit__
except ImportError:
    __version__ = "0.0.0+dev"
    __commit__ = "unknown"

from .viewer import MapViewer
from .exceptions import (
    MapViewerError,
    DockerNotInstalled,
    DockerNotRunning,
    RegistryNotLoggedIn,
    ImagePullFailed,
    ConfigError,
    ContainerError,
    ContainerNotFound,
    ContainerAlreadyRunning,
)

__all__ = [
    "__version__",
    "MapViewer",
    "MapViewerError",
    "DockerNotInstalled",
    "DockerNotRunning",
    "RegistryNotLoggedIn",
    "ImagePullFailed",
    "ConfigError",
    "ContainerError",
    "ContainerNotFound",
    "ContainerAlreadyRunning",
]
