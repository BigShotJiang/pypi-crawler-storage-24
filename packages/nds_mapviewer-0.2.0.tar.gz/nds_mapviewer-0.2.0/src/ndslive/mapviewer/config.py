"""Configuration parsing and path transformation for MapViewer."""

from __future__ import annotations

import os
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import yaml

from .exceptions import ConfigError

# User config directories
NDS_DIR = Path.home() / ".nds"
CONFIGS_DIR = NDS_DIR / "configs"
DEFAULT_CONFIG = NDS_DIR / "config.yaml"
LEGACY_CONFIG = NDS_DIR / "mapviewer.yaml"

# Patterns for detecting local paths in URIs
FILESTORE_PATTERN = re.compile(r"^filestore:(.+)$")
FOLDER_URI_PATTERN = re.compile(r"^folder:(.+)$")
LOCALHOST_PATTERN = re.compile(r"^(localhost|127\.0\.0\.1)(:\d+)?$")

# Default config for demo mode
DEFAULT_DEMO_CONFIG = {
    "http-settings": [
        {
            "scope": "https://api.nds.live/*",
            "api-key": "WB1Vsg9YNz2xiQJcELXxO6477Ex8Tfre",
        }
    ],
    "sources": [
        {
            "type": "SmartLayerTileService",
            "uri": "https://api.nds.live/island6/openapi.json",
            "mapId": "Island 6",
        }
    ],
}


@dataclass
class VolumeMount:
    """Represents a Docker volume mount."""

    host_path: Path
    container_path: str

    def to_docker_volume(self) -> dict:
        """Convert to Docker SDK volume format."""
        return {str(self.host_path): {"bind": self.container_path, "mode": "ro"}}


@dataclass
class TransformedConfig:
    """Result of config transformation."""

    config: dict[str, Any]
    volumes: list[VolumeMount] = field(default_factory=list)
    config_dir: Path | None = None

    def get_docker_volumes(self) -> dict[str, dict]:
        """Get all volumes as Docker SDK format."""
        result = {}
        for vol in self.volumes:
            result.update(vol.to_docker_volume())
        return result


def load_config(config_path: str | Path) -> dict[str, Any]:
    """Load and parse a MapViewer YAML config file."""
    path = Path(config_path).expanduser().resolve()

    if not path.exists():
        raise ConfigError(f"Config file not found: {path}", str(path))

    try:
        with open(path) as f:
            config = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ConfigError(f"Invalid YAML: {e}", str(path)) from e

    if not isinstance(config, dict):
        raise ConfigError("Config must be a YAML dictionary", str(path))

    return config


def get_demo_config() -> dict[str, Any]:
    """Get the default demo configuration."""
    import copy
    return copy.deepcopy(DEFAULT_DEMO_CONFIG)


def _extract_local_path(uri_or_path: str) -> Path | None:
    """Extract local filesystem path from a URI or path string."""
    # Check filestore: prefix
    match = FILESTORE_PATTERN.match(uri_or_path)
    if match:
        path_str = match.group(1)
        path = Path(path_str).expanduser()
        if path.is_absolute():
            return path.resolve()
        return None

    # Check folder: prefix
    match = FOLDER_URI_PATTERN.match(uri_or_path)
    if match:
        path_str = match.group(1)
        path = Path(path_str).expanduser()
        if path.is_absolute():
            return path.resolve()
        return None

    # Check plain path (for folder: fields)
    path = Path(uri_or_path).expanduser()
    if path.is_absolute() and (path.exists() or path.parent.exists()):
        return path.resolve()

    return None


def _is_localhost(host: str) -> bool:
    """Check if a host string refers to localhost."""
    return bool(LOCALHOST_PATTERN.match(host))


def _transform_localhost(host: str) -> str:
    """Transform localhost to host.docker.internal."""
    match = LOCALHOST_PATTERN.match(host)
    if match:
        port_part = match.group(2) or ""
        return f"host.docker.internal{port_part}"
    return host


def _find_common_parent(paths: list[Path]) -> dict[Path, Path]:
    """
    Find optimal parent directories for volume mounts.
    Returns a mapping of original paths to their mount parent directories.
    """
    if not paths:
        return {}

    # Group paths by their parent directories
    parent_to_paths: dict[Path, list[Path]] = {}
    for path in paths:
        # Use the parent directory for files, the path itself for directories
        if path.is_file():
            parent = path.parent
        else:
            parent = path
        parent_to_paths.setdefault(parent, []).append(path)

    # Deduplicate parents - if one parent is a child of another, use the ancestor
    parents = list(parent_to_paths.keys())
    result: dict[Path, Path] = {}

    for path in paths:
        mount_parent = path.parent if path.is_file() else path

        # Check if any existing parent is an ancestor
        for parent in parents:
            if mount_parent == parent or parent in mount_parent.parents:
                mount_parent = parent
                break
            if mount_parent in parent.parents:
                # Current mount_parent is ancestor of an existing one
                # Update all paths that used the child parent
                for p, mp in list(result.items()):
                    if mp == parent:
                        result[p] = mount_parent
                break

        result[path] = mount_parent

    return result


def transform_config(config: dict[str, Any]) -> TransformedConfig:
    """
    Transform a MapViewer config for Docker execution.

    - Extracts local filesystem paths and creates volume mounts
    - Rewrites paths to use container mount points
    - Transforms localhost references to host.docker.internal
    """
    import copy

    transformed = copy.deepcopy(config)
    local_paths: list[Path] = []
    path_locations: list[tuple[str, int, str, str]] = []  # (section, index, field, original)

    sources = transformed.get("sources", [])

    # First pass: collect all local paths
    for idx, source in enumerate(sources):
        source_type = source.get("type", "")

        # Check uri field (SmartLayerTileService, etc.)
        uri = source.get("uri", "")
        if uri:
            local_path = _extract_local_path(uri)
            if local_path:
                local_paths.append(local_path)
                path_locations.append(("sources", idx, "uri", uri))

        # Check folder field (ClassicFolder, GeoJsonFolder)
        folder = source.get("folder", "")
        if folder:
            local_path = _extract_local_path(folder)
            if local_path:
                local_paths.append(local_path)
                path_locations.append(("sources", idx, "folder", folder))

        # Check host field (DataSourceHost) for localhost
        host = source.get("host", "")
        if host and _is_localhost(host):
            transformed["sources"][idx]["host"] = _transform_localhost(host)

    # Find optimal mount points
    path_to_mount_parent = _find_common_parent(local_paths)

    # Deduplicate mount parents
    unique_parents = list(set(path_to_mount_parent.values()))
    parent_to_container_path = {
        parent: f"/data/{idx}" for idx, parent in enumerate(unique_parents)
    }

    # Create volume mounts
    volumes = [
        VolumeMount(host_path=parent, container_path=container_path)
        for parent, container_path in parent_to_container_path.items()
    ]

    # Second pass: rewrite paths
    for section, idx, field_name, original in path_locations:
        local_path = _extract_local_path(original)
        if not local_path:
            continue

        mount_parent = path_to_mount_parent[local_path]
        container_base = parent_to_container_path[mount_parent]

        # Calculate relative path from mount parent to the actual path
        try:
            relative = local_path.relative_to(mount_parent)
            container_full_path = f"{container_base}/{relative}" if str(relative) != "." else container_base
        except ValueError:
            # Path is not relative to mount parent (shouldn't happen)
            container_full_path = f"{container_base}/{local_path.name}"

        # Rebuild the URI/path with container path
        if field_name == "uri":
            if original.startswith("filestore:"):
                new_value = f"filestore:{container_full_path}"
            elif original.startswith("folder:"):
                new_value = f"folder:{container_full_path}"
            else:
                new_value = container_full_path
        else:
            new_value = container_full_path

        transformed[section][idx][field_name] = new_value

    return TransformedConfig(config=transformed, volumes=volumes)


def write_config_to_temp(config: dict[str, Any]) -> Path:
    """Write config to a temporary directory, returning the directory path.

    Uses ~/.nds/tmp/ instead of system temp to ensure Docker can mount it
    (macOS Docker Desktop has restrictions on /var/folders access).
    """
    # Use user's home directory for temp files (Docker-friendly)
    base_temp = NDS_DIR / "tmp"
    base_temp.mkdir(parents=True, exist_ok=True)

    temp_dir = Path(tempfile.mkdtemp(prefix="mapviewer-", dir=base_temp))
    config_file = temp_dir / "mapviewer.yaml"

    fd = os.open(str(config_file), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    return temp_dir


def validate_paths(config: dict[str, Any]) -> list[str]:
    """
    Validate that all local paths in the config exist.
    Returns a list of error messages for missing paths.
    """
    errors = []
    sources = config.get("sources", [])

    for idx, source in enumerate(sources):
        source_type = source.get("type", "")
        map_id = source.get("mapId", f"source[{idx}]")

        # Check uri field
        uri = source.get("uri", "")
        if uri:
            local_path = _extract_local_path(uri)
            if local_path and not local_path.exists():
                errors.append(f"{map_id}: Path does not exist: {local_path}")

        # Check folder field
        folder = source.get("folder", "")
        if folder:
            local_path = _extract_local_path(folder)
            if local_path and not local_path.exists():
                errors.append(f"{map_id}: Folder does not exist: {local_path}")

    return errors


# --- Directory type detection ---

def detect_directory_type(path: Path) -> str:
    """Detect source type from directory contents.

    Returns: "geojson", "classic", or "folder" (SmartLayer default).
    """
    if any(path.glob("*.geojson")):
        return "geojson"
    if (path / "ROOT.NDS").exists():
        return "classic"
    return "folder"


# --- Config generation functions ---

def create_geojson_config(folder_path: str | Path) -> dict[str, Any]:
    """Create a config dict for a GeoJSON folder."""
    folder_path = Path(folder_path)
    return {
        "sources": [{
            "type": "GeoJsonFolder",
            "folder": str(folder_path),
        }]
    }


def create_classic_config(
    folder_path: str | Path, map_id: str | None = None,
) -> dict[str, Any]:
    """Create a config dict for an NDS Classic folder."""
    folder_path = Path(folder_path)
    return {
        "sources": [{
            "type": "ClassicFolder",
            "folder": str(folder_path),
            "mapId": map_id or folder_path.name,
        }]
    }


def create_folder_config(
    folder_path: str | Path, map_id: str | None = None,
) -> dict[str, Any]:
    """Create a config dict for a SmartLayer folder."""
    folder_path = Path(folder_path)
    return {
        "sources": [
            {
                "type": "SmartLayerTileService",
                "uri": f"folder:{folder_path}",
                "mapId": map_id or folder_path.name,
            }
        ]
    }


def create_filestore_config(
    filestore_path: str | Path, map_id: str | None = None,
) -> dict[str, Any]:
    """Create a config dict for a FileStore."""
    filestore_path = Path(filestore_path)
    return {
        "sources": [
            {
                "type": "SmartLayerTileService",
                "uri": f"filestore:{filestore_path}",
                "mapId": map_id or filestore_path.stem,
            }
        ]
    }


def create_service_config(
    url: str,
    auth_method: str = "none",
    api_key: str | None = None,
    query_params: list[dict[str, str]] | None = None,
    basic_user: str | None = None,
    basic_password: str | None = None,
    bearer_token: str | None = None,
    oauth2_client_id: str | None = None,
    oauth2_client_secret: str | None = None,
    oauth2_token_url: str | None = None,
    oauth2_audience: str | None = None,
    oauth2_scope: str | None = None,
    proxy_host: str | None = None,
    proxy_port: int | None = None,
    proxy_user: str | None = None,
    proxy_password: str | None = None,
) -> dict[str, Any]:
    """Create a config dict for connecting to a remote service.

    Args:
        url: Service URL (e.g., https://api.example.com/openapi.json)
        auth_method: One of "none", "apiKey", "queryParam", "basic", "bearer", "oauth2"
        api_key: API key value (for auth_method="apiKey")
        query_params: List of {"key": k, "value": v} dicts (for auth_method="queryParam")
        basic_user: Username (for auth_method="basic")
        basic_password: Password (for auth_method="basic")
        bearer_token: Token value (for auth_method="bearer")
        oauth2_client_id: Client ID (for auth_method="oauth2")
        oauth2_client_secret: Client secret (for auth_method="oauth2")
        oauth2_token_url: Token URL (for auth_method="oauth2")
        oauth2_audience: Audience (for auth_method="oauth2")
        oauth2_scope: Space-separated scopes (for auth_method="oauth2")
        proxy_host: Proxy hostname
        proxy_port: Proxy port
        proxy_user: Proxy username
        proxy_password: Proxy password

    Returns:
        Config dict ready to be written to YAML.
    """
    parsed = urlparse(url)
    scope = f"{parsed.scheme}://{parsed.netloc}/*"

    config: dict[str, Any] = {
        "sources": [
            {
                "type": "SmartLayerTileService",
                "uri": url,
                "mapId": parsed.netloc.replace(".", "-"),
            }
        ]
    }

    http_settings: dict[str, Any] = {"scope": scope}
    has_http_settings = False

    # Authentication based on selected method
    if auth_method == "apiKey" and api_key:
        http_settings["api-key"] = api_key
        has_http_settings = True

    elif auth_method == "queryParam" and query_params:
        query_dict: dict[str, str] = {}
        for param in query_params:
            key = param.get("key", "")
            value = param.get("value", "")
            if key:
                query_dict[key] = value
        if query_dict:
            http_settings["query"] = query_dict
            has_http_settings = True

    elif auth_method == "basic" and basic_user:
        http_settings["basic-auth"] = {"user": basic_user}
        if basic_password:
            http_settings["basic-auth"]["password"] = basic_password
        has_http_settings = True

    elif auth_method == "bearer" and bearer_token:
        http_settings["headers"] = {"Authorization": f"Bearer {bearer_token}"}
        has_http_settings = True

    elif auth_method == "oauth2" and oauth2_client_id and oauth2_token_url:
        oauth2_config: dict[str, Any] = {
            "clientId": oauth2_client_id,
            "tokenUrl": oauth2_token_url,
        }
        if oauth2_client_secret:
            oauth2_config["clientSecret"] = oauth2_client_secret
        if oauth2_audience:
            oauth2_config["audience"] = oauth2_audience
        if oauth2_scope:
            oauth2_config["scope"] = oauth2_scope.split()
        http_settings["oauth2"] = oauth2_config
        has_http_settings = True

    # Proxy settings (independent of auth method)
    if proxy_host:
        proxy: dict[str, Any] = {"host": proxy_host}
        if proxy_port:
            proxy["port"] = proxy_port
        if proxy_user:
            proxy["user"] = proxy_user
        if proxy_password:
            proxy["password"] = proxy_password
        http_settings["proxy"] = proxy
        has_http_settings = True

    if has_http_settings:
        config["http-settings"] = [http_settings]

    return config


# --- Config resolution functions ---

@dataclass
class ResolvedConfig:
    """Result of config resolution."""
    config_path: Path
    source_type: str  # "local_filestore", "local_folder", "saved_config", "demo"
    display_name: str  # Human-readable description


def resolve_config_source(arg: str) -> ResolvedConfig | None:
    """Resolve a CLI argument to a config source.

    Resolution order:
    1. If arg is an absolute path or starts with ./ → treat as local path
    2. If arg exists as local file/folder → use it
    3. If ~/.nds/configs/<arg>.yaml exists → use saved config
    4. Return None if not found

    Args:
        arg: CLI argument (path or config name)

    Returns:
        ResolvedConfig if found, None otherwise.
    """
    # Check for absolute path or explicit relative path
    if arg.startswith("/") or arg.startswith("./") or arg.startswith("../"):
        path = Path(arg).expanduser().resolve()
        if path.exists():
            if path.suffix == ".ndslive":
                return ResolvedConfig(
                    config_path=path,
                    source_type="local_filestore",
                    display_name=str(path),
                )
            elif path.is_dir():
                dir_type = detect_directory_type(path)
                type_map = {
                    "geojson": "local_geojson",
                    "classic": "local_classic",
                    "folder": "local_folder",
                }
                return ResolvedConfig(
                    config_path=path,
                    source_type=type_map[dir_type],
                    display_name=str(path),
                )
            elif path.suffix in (".yaml", ".yml"):
                return ResolvedConfig(
                    config_path=path,
                    source_type="local_config",
                    display_name=str(path),
                )
        return None

    # Check if it exists as a local path (implicit relative)
    local_path = Path(arg).expanduser()
    if local_path.exists():
        resolved = local_path.resolve()
        if resolved.suffix == ".ndslive":
            return ResolvedConfig(
                config_path=resolved,
                source_type="local_filestore",
                display_name=str(resolved),
            )
        elif resolved.is_dir():
            dir_type = detect_directory_type(resolved)
            type_map = {
                "geojson": "local_geojson",
                "classic": "local_classic",
                "folder": "local_folder",
            }
            return ResolvedConfig(
                config_path=resolved,
                source_type=type_map[dir_type],
                display_name=str(resolved),
            )
        elif resolved.suffix in (".yaml", ".yml"):
            return ResolvedConfig(
                config_path=resolved,
                source_type="local_config",
                display_name=str(resolved),
            )

    # Check saved configs directory
    saved_config = CONFIGS_DIR / f"{arg}.yaml"
    if saved_config.exists():
        return ResolvedConfig(
            config_path=saved_config,
            source_type="saved_config",
            display_name=f"~/.nds/configs/{arg}.yaml",
        )

    return None


def save_config(config: dict[str, Any], name: str) -> Path:
    """Save a config to the workspace directory.

    Args:
        config: Config dict to save
        name: Config name (without extension)

    Returns:
        Path to the saved config file.

    Raises:
        ConfigError: If name contains path traversal characters.
    """
    if "/" in name or "\\" in name or ".." in name:
        raise ConfigError(f"Invalid config name: {name}")

    CONFIGS_DIR.mkdir(parents=True, exist_ok=True)
    config_path = CONFIGS_DIR / f"{name}.yaml"

    fd = os.open(str(config_path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    return config_path


def delete_config(name: str) -> bool:
    """Delete a saved config by name.

    Args:
        name: Config name (without extension)

    Returns:
        True if deleted, False if file didn't exist.

    Raises:
        ConfigError: If name contains path traversal characters.
    """
    if "/" in name or "\\" in name or ".." in name:
        raise ConfigError(f"Invalid config name: {name}")

    config_path = CONFIGS_DIR / f"{name}.yaml"
    if not config_path.exists():
        return False

    config_path.unlink()
    return True


def list_saved_configs() -> list[str]:
    """List all saved config names."""
    if not CONFIGS_DIR.exists():
        return []

    return sorted(
        p.stem for p in CONFIGS_DIR.glob("*.yaml")
    )
