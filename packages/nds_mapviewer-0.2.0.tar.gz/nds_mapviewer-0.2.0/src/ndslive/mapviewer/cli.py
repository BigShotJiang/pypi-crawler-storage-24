#!/usr/bin/env python3
"""CLI entry point for mapviewer."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from rich.console import Console

from . import __version__, __commit__
from .docker_client import parse_image_version as _parse_image_version
from .exceptions import MapViewerError

console = Console()


def _build_run_subtitle(edition: str, image_version_raw: str | None) -> str:
    """Build a banner subtitle for the run screen.

    Example: ``"community edition | v2025.6.2 (abc123f)"``
    """
    version, commit = _parse_image_version(image_version_raw)
    if version != "unknown":
        return f"{edition} edition | v{version} ({commit})"
    return f"{edition} edition"


def _stop_existing_container() -> None:
    """Stop the current MapViewer container if it is running."""
    from .viewer import MapViewer
    from .exceptions import ContainerNotFound

    try:
        mv = MapViewer.connect()
        mv.stop()
    except ContainerNotFound:
        pass


def _get_edition_default() -> str:
    """Read edition from ndslive-setup config, fallback to community."""
    setup_config = Path.home() / ".nds" / "setup.json"
    if setup_config.exists():
        import json
        try:
            with open(setup_config) as f:
                return json.load(f).get("edition", "community")
        except (json.JSONDecodeError, OSError):
            pass
    return "community"


# ---------------------------------------------------------------------------
# Command handler
# ---------------------------------------------------------------------------

def cmd_main(args: argparse.Namespace) -> int:
    """Unified handler: sources → resolve & launch, no sources → HomeScreen."""
    from .config import (
        load_config,
        resolve_config_source,
        create_filestore_config,
        create_folder_config,
        create_geojson_config,
        create_classic_config,
        get_demo_config,
    )
    from .tui import MapViewerApp

    edition = args.edition
    version = args.image_version
    no_browser = args.no_browser
    port = args.port
    source_args = args.sources

    # --demo → demo config
    if args.demo:
        config = get_demo_config()
        app = MapViewerApp(
            edition=edition,
            version=version,
            no_browser=no_browser,
            port=port,
            run_config=config,
            run_label="Demo (NDS Islands)",
            is_demo=True,
        )
        app.run()
        return 0

    # No sources → check ~/.nds/config.yaml, then legacy, then HomeScreen
    if not source_args:
        from .config import DEFAULT_CONFIG, LEGACY_CONFIG, load_config
        if DEFAULT_CONFIG.exists():
            try:
                config = load_config(DEFAULT_CONFIG)
                app = MapViewerApp(
                    edition=edition,
                    version=version,
                    no_browser=no_browser,
                    port=port,
                    run_config=config,
                    run_label="~/.nds/config.yaml",
                )
                app.run()
                return 0
            except Exception:
                pass  # fall through

        if LEGACY_CONFIG.exists():
            console.print(
                "[yellow]Warning:[/yellow] ~/.nds/mapviewer.yaml is deprecated,"
                " rename to ~/.nds/config.yaml"
            )
            try:
                config = load_config(LEGACY_CONFIG)
                app = MapViewerApp(
                    edition=edition,
                    version=version,
                    no_browser=no_browser,
                    port=port,
                    run_config=config,
                    run_label="~/.nds/mapviewer.yaml",
                )
                app.run()
                return 0
            except Exception:
                pass  # fall through to HomeScreen

        app = MapViewerApp(
            edition=edition,
            version=version,
            no_browser=no_browser,
            port=port,
        )
        app.run()
        return 0

    # Resolve each source and collect configs
    all_sources: list[dict] = []
    all_http_settings: list[dict] = []
    descriptions: list[str] = []

    for source_arg in source_args:
        # Parse optional path:mapId syntax
        custom_map_id = None
        if ":" in source_arg:
            path_part, _, map_id_part = source_arg.rpartition(":")
            candidate = Path(path_part).expanduser()
            if candidate.exists():
                source_arg = path_part
                custom_map_id = map_id_part

        resolved = resolve_config_source(source_arg)

        if resolved is None:
            console.print(f"[red]Error:[/red] Source not found: {source_arg}")
            return 1

        if resolved.source_type == "local_filestore":
            config = create_filestore_config(resolved.config_path, map_id=custom_map_id)
            descriptions.append(f"filestore: {resolved.config_path.name}")

        elif resolved.source_type == "local_geojson":
            config = create_geojson_config(resolved.config_path)
            descriptions.append(f"geojson: {resolved.config_path.name}")

        elif resolved.source_type == "local_classic":
            config = create_classic_config(resolved.config_path, map_id=custom_map_id)
            descriptions.append(f"classic: {resolved.config_path.name}")

        elif resolved.source_type == "local_folder":
            config = create_folder_config(resolved.config_path, map_id=custom_map_id)
            descriptions.append(f"folder: {resolved.config_path.name}")

        elif resolved.source_type in ("local_config", "saved_config"):
            config = load_config(resolved.config_path)
            descriptions.append(
                f"saved: {resolved.config_path.stem}"
                if resolved.source_type == "saved_config"
                else f"config: {resolved.config_path.name}"
            )

        else:
            console.print(f"[red]Error:[/red] Unknown source type: {resolved.source_type}")
            return 1

        all_sources.extend(config.get("sources", []))
        all_http_settings.extend(config.get("http-settings", []))

    # Merge into a single config
    merged: dict = {"sources": all_sources}
    if all_http_settings:
        merged["http-settings"] = all_http_settings

    source_desc = ", ".join(descriptions)

    app = MapViewerApp(
        edition=edition,
        version=version,
        no_browser=no_browser,
        port=port,
        run_config=merged,
        run_label=source_desc,
    )
    app.run()
    return 0


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser (reused by TUI help screen)."""
    parser = argparse.ArgumentParser(
        prog="mapviewer",
        description="NDS MapViewer - view NDS.Live map data",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  # Interactive HomeScreen
  mapviewer

  # Quick start with local data
  mapviewer /path/to/data.ndslive
  mapviewer /path/to/smartlayer/folder
  mapviewer /path/to/geojson/folder
  mapviewer --demo

  # Multiple sources at once
  mapviewer /path/a.ndslive /path/to/geojson/

  # Custom mapId
  mapviewer /path/a.ndslive:MyMap

  # Use a saved connection
  mapviewer mywork

  # First-time setup
  pip install ndslive-setup && ndslive-setup
""",
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__} ({__commit__[:7]})",
    )
    parser.add_argument(
        "sources",
        nargs="*",
        help="One or more data source paths or saved config names",
    )
    parser.add_argument(
        "--demo",
        action="store_true",
        help="Use demo data (NDS Islands)",
    )
    parser.add_argument(
        "-e", "--edition",
        choices=["community", "member"],
        default=_get_edition_default(),
        help="MapViewer edition (default: from ndslive-setup config or community)",
    )
    parser.add_argument(
        "-i", "--image-version",
        dest="image_version",
        default="latest",
        help="Image version tag (default: latest)",
    )
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not auto-open the browser after startup",
    )
    parser.add_argument(
        "-p", "--port", type=int, default=0,
        help="Host port to expose MapViewer on (default: auto-select from 8089)",
    )

    return parser


def main() -> int:
    """Main entry point."""
    parser = _build_parser()
    args = parser.parse_args()
    return cmd_main(args)


if __name__ == "__main__":
    sys.exit(main())
