"""Docker SDK wrapper with validation and error handling."""

from __future__ import annotations

import json
import platform
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Iterator

if TYPE_CHECKING:
    from docker.models.containers import Container

from .exceptions import (
    ContainerAlreadyRunning,
    ContainerNotFound,
    DockerNotInstalled,
    DockerNotRunning,
    ImagePullFailed,
    RegistryNotLoggedIn,
    RegistryQueryFailed,
)

CONTAINER_NAME = "ndslive-mapviewer"
CONTAINER_LABEL = "app=ndslive-mapviewer"

REGISTRIES = {
    "community": "artifactory.nds-association.org/ndslive-dockerreg",
    "member": "artifactory.nds-association.org/tooling-dockerreg",
}

IMAGE_NAME = "nds-mapviewer"

KNOWN_TAGS = ["latest", "dev", "dev-rc"]


@dataclass
class DockerInfo:
    """Information about the Docker installation."""

    version: str
    running: bool
    platform: str


def get_docker_client():
    """Get a Docker client, raising appropriate exceptions if unavailable."""
    try:
        import docker
    except ImportError as e:
        raise DockerNotInstalled(
            "Docker SDK for Python is not installed.\n"
            "Install it with: pip install docker"
        ) from e

    try:
        client = docker.from_env()
        client.ping()
        return client
    except docker.errors.DockerException as e:
        error_str = str(e).lower()
        if "connection refused" in error_str or "not running" in error_str:
            raise DockerNotRunning() from e
        if "not found" in error_str or "no such file" in error_str:
            raise DockerNotInstalled() from e
        raise DockerNotRunning(f"Docker error: {e}") from e


def get_docker_info() -> DockerInfo | None:
    """Get Docker installation info, or None if not available."""
    try:
        client = get_docker_client()
        version = client.version()
        return DockerInfo(
            version=version.get("Version", "unknown"),
            running=True,
            platform=version.get("Os", platform.system().lower()),
        )
    except (DockerNotInstalled, DockerNotRunning):
        return None


def detect_architecture() -> str:
    """Detect the system architecture for Docker images."""
    machine = platform.machine().lower()
    if machine in ("x86_64", "amd64"):
        return "amd64"
    if machine in ("arm64", "aarch64"):
        return "arm64"
    # Default to amd64 for unknown architectures
    return "amd64"


def find_free_port(preferred: int = 8089) -> int:
    """Find a free port, trying preferred port first."""
    import socket

    # Try preferred port first
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", preferred))
            return preferred
        except OSError:
            pass

    # Find any free port
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def get_image_tag(edition: str, version: str, arch: str | None = None) -> str:
    """Get the full Docker image tag for the given edition and version."""
    if arch is None:
        arch = detect_architecture()
    registry = REGISTRIES.get(edition)
    if not registry:
        raise ValueError(f"Unknown edition: {edition}. Must be 'community' or 'member'.")
    return f"{registry}/{IMAGE_NAME}:{version}-{arch}"


def is_logged_in(edition: str) -> bool:
    """Check if the user is logged into the registry for the given edition."""
    registry = REGISTRIES.get(edition)
    if not registry:
        return False

    # Docker stores auth in ~/.docker/config.json
    config_path = Path.home() / ".docker" / "config.json"
    if not config_path.exists():
        return False

    try:
        with open(config_path) as f:
            config = json.load(f)

        auths = config.get("auths", {})
        # Check for the registry host (without the repository path)
        registry_host = registry.split("/")[0]

        # Check various possible key formats
        for key in auths:
            if registry_host in key or registry in key:
                # Check if there's actual auth data
                auth_data = auths[key]
                if auth_data.get("auth") or auth_data.get("identitytoken"):
                    return True

        # Also check credHelpers and credsStore
        cred_helpers = config.get("credHelpers", {})
        creds_store = config.get("credsStore")

        if creds_store or any(registry_host in k for k in cred_helpers):
            # If using credential helpers, assume logged in if configured
            # (we can't easily check the actual credentials)
            return True

        return False
    except (json.JSONDecodeError, OSError):
        return False


def ensure_logged_in(edition: str) -> None:
    """Ensure the user is logged into the registry for the given edition."""
    if not is_logged_in(edition):
        registry = REGISTRIES.get(edition, "unknown")
        raise RegistryNotLoggedIn(registry, edition)


def pull_image(
    edition: str,
    version: str = "latest",
    arch: str | None = None,
    progress_callback: Callable[[dict], None] | None = None,
) -> str:
    """Pull the MapViewer image, returning the full image tag."""
    client = get_docker_client()
    ensure_logged_in(edition)

    image_tag = get_image_tag(edition, version, arch)

    try:
        # Pull with progress reporting
        for line in client.api.pull(image_tag, stream=True, decode=True):
            if progress_callback and "status" in line:
                progress_callback(line)
        return image_tag
    except Exception as e:
        error_str = str(e).lower()
        if "unauthorized" in error_str or "authentication required" in error_str:
            registry = REGISTRIES.get(edition, "unknown")
            raise RegistryNotLoggedIn(registry, edition) from e
        if "not found" in error_str:
            raise ImagePullFailed(image_tag, "Image not found in registry") from e
        raise ImagePullFailed(image_tag, str(e)) from e


def image_exists(edition: str, version: str = "latest", arch: str | None = None) -> bool:
    """Check if the MapViewer image exists locally."""
    try:
        client = get_docker_client()
        image_tag = get_image_tag(edition, version, arch)
        client.images.get(image_tag)
        return True
    except Exception:
        return False


def list_local_image_versions(edition: str | None = None) -> list[dict]:
    """List locally available nds-mapviewer images.

    Returns:
        List of dicts with keys: edition, version, tag, size_mb.
    """
    import re

    try:
        client = get_docker_client()
    except (DockerNotInstalled, DockerNotRunning):
        return []

    editions = [edition] if edition else list(REGISTRIES)
    results: list[dict] = []

    for ed in editions:
        registry = REGISTRIES.get(ed)
        if not registry:
            continue
        repo = f"{registry}/{IMAGE_NAME}"
        try:
            images = client.images.list(name=repo)
        except Exception:
            continue
        for img in images:
            size_mb = round(img.attrs.get("Size", 0) / (1024 * 1024), 1)
            for tag_str in img.tags:
                # tag_str looks like "registry/image:version-arch"
                if ":" not in tag_str:
                    continue
                tag_part = tag_str.split(":")[-1]
                # Strip architecture suffix
                version_str = re.sub(r"-(amd64|arm64)$", "", tag_part)
                results.append({
                    "edition": ed,
                    "version": version_str,
                    "tag": tag_part,
                    "size_mb": size_mb,
                })

    return results


@dataclass
class UpdateStatus:
    """Result of an update check for a single edition."""

    edition: str
    version: str
    arch: str
    local_digest: str | None
    remote_digest: str | None
    update_available: bool
    error: str | None = None


def list_installed_editions() -> list[str]:
    """Return editions that have at least one local image."""
    try:
        client = get_docker_client()
    except (DockerNotInstalled, DockerNotRunning):
        return []
    editions = []
    for edition in REGISTRIES:
        tag = get_image_tag(edition, "latest")
        try:
            client.images.get(tag)
            editions.append(edition)
        except Exception:
            pass
    return editions


def get_local_digest(
    edition: str, version: str = "latest", arch: str | None = None,
) -> str | None:
    """Get the registry digest of a locally installed image."""
    try:
        client = get_docker_client()
        image_tag = get_image_tag(edition, version, arch)
        image = client.images.get(image_tag)
        registry = REGISTRIES[edition]
        for rd in image.attrs.get("RepoDigests", []):
            if registry in rd:
                return rd.split("@")[-1]
        return None
    except Exception:
        return None


def get_remote_digest(
    edition: str, version: str = "latest", arch: str | None = None,
) -> str | None:
    """Query Docker daemon for the remote manifest digest.

    Uses the Docker Engine distribution API which handles auth
    and proxy configuration via the daemon.
    """
    client = get_docker_client()
    ensure_logged_in(edition)
    image_tag = get_image_tag(edition, version, arch)
    try:
        dist_info = client.api.inspect_distribution(image_tag)
        return dist_info.get("Descriptor", {}).get("digest")
    except Exception as e:
        error_str = str(e).lower()
        if "unauthorized" in error_str or "authentication required" in error_str:
            registry = REGISTRIES.get(edition, "unknown")
            raise RegistryNotLoggedIn(registry, edition) from e
        registry = REGISTRIES.get(edition, "unknown")
        raise RegistryQueryFailed(registry, str(e)) from e


def check_for_update(
    edition: str, version: str = "latest", arch: str | None = None,
) -> UpdateStatus:
    """Check if an update is available for the given edition.

    Compares local and remote image digests. Errors are captured
    in the returned status rather than raised.
    """
    if arch is None:
        arch = detect_architecture()
    local_digest = get_local_digest(edition, version, arch)

    try:
        remote_digest = get_remote_digest(edition, version, arch)
    except (RegistryNotLoggedIn, RegistryQueryFailed) as e:
        return UpdateStatus(
            edition=edition, version=version, arch=arch,
            local_digest=local_digest, remote_digest=None,
            update_available=False, error=str(e),
        )

    update_available = (
        local_digest is not None
        and remote_digest is not None
        and local_digest != remote_digest
    )
    return UpdateStatus(
        edition=edition, version=version, arch=arch,
        local_digest=local_digest, remote_digest=remote_digest,
        update_available=update_available,
    )


def parse_image_version(raw: str | None) -> tuple[str, str]:
    """Parse the ``--version`` output from the Docker image.

    Args:
        raw: Output like ``"NDS MapViewer version 2025.6.2, Commit ID: abc123f"``

    Returns:
        ``(version, commit)`` tuple.  Falls back to ``("unknown", "unknown")``.
    """
    import re

    if not raw:
        return "unknown", "unknown"
    m = re.search(r"version\s+([\w.]+)", raw, re.IGNORECASE)
    version = m.group(1) if m else "unknown"
    m = re.search(r"Commit\s+ID:\s*(\S+)", raw, re.IGNORECASE)
    commit = m.group(1)[:7] if m else "unknown"
    return version, commit


def get_image_version(name: str = CONTAINER_NAME) -> str | None:
    """Get the MapViewer version string from a running container.

    Executes ``/entrypoint.bash --version`` inside the container and
    returns the raw output, e.g.
    ``"NDS MapViewer version 2025.6.2, Commit ID: abc123f"``.

    Returns None if the container is not running or the command fails.
    """
    container = get_container(name)
    if container is None or container.status != "running":
        return None
    try:
        result = container.exec_run("/entrypoint.bash --version")
        if result.exit_code == 0:
            return result.output.decode("utf-8").strip()
    except Exception:
        pass
    return None


def get_container(name: str = CONTAINER_NAME) -> Container | None:
    """Get the MapViewer container if it exists."""
    try:
        client = get_docker_client()
        return client.containers.get(name)
    except Exception:
        return None


def get_container_status(name: str = CONTAINER_NAME) -> str:
    """Get the status of the MapViewer container."""
    container = get_container(name)
    if container is None:
        return "not_found"
    return container.status


def list_containers() -> list[Container]:
    """List all MapViewer containers (running or stopped).

    Returns containers with the 'app=ndslive-mapviewer' label,
    plus any container named with the default name for backward compatibility.
    """
    try:
        client = get_docker_client()

        # Find containers with our label
        labeled = client.containers.list(
            all=True,
            filters={"label": CONTAINER_LABEL}
        )

        # Also check for default-named container without label (backward compat)
        seen_names = {c.name for c in labeled}
        if CONTAINER_NAME not in seen_names:
            try:
                default = client.containers.get(CONTAINER_NAME)
                labeled.append(default)
            except Exception:
                pass

        return labeled
    except (DockerNotInstalled, DockerNotRunning):
        return []


def run_container(
    image_tag: str,
    port: int = 8089,
    config_dir: str | Path | None = None,
    volumes: dict[str, dict] | None = None,
    environment: dict[str, str] | None = None,
    name: str = CONTAINER_NAME,
    detach: bool = True,
    remove_existing: bool = False,
) -> Container:
    """Run the MapViewer container.

    Args:
        image_tag: Docker image tag to run.
        port: Host port to bind.
        config_dir: Config directory to mount.
        volumes: Additional volume mounts.
        environment: Environment variables.
        name: Container name.
        detach: Run in detached mode.
        remove_existing: Remove existing container if running.
    """
    client = get_docker_client()

    # Check for existing container
    existing = get_container(name)
    if existing:
        if existing.status == "running":
            if not remove_existing:
                raise ContainerAlreadyRunning(name, port)
            existing.stop()
        existing.remove()

    # Build volume mounts
    all_volumes = volumes.copy() if volumes else {}

    if config_dir:
        config_path = Path(config_dir).resolve()
        all_volumes[str(config_path)] = {"bind": "/config", "mode": "rw"}

    # Build environment
    env = environment.copy() if environment else {}

    # Build port mapping
    ports = {"8089/tcp": port}

    # Extra hosts for host.docker.internal on Linux
    extra_hosts = {}
    if platform.system() == "Linux":
        extra_hosts["host.docker.internal"] = "host-gateway"

    container = client.containers.run(
        image_tag,
        detach=detach,
        name=name,
        ports=ports,
        volumes=all_volumes,
        environment=env,
        extra_hosts=extra_hosts if extra_hosts else None,
        labels={"app": "ndslive-mapviewer"},
        remove=False,
    )

    return container


def stop_container(name: str = CONTAINER_NAME, remove: bool = True) -> bool:
    """Stop the MapViewer container."""
    container = get_container(name)
    if container is None:
        raise ContainerNotFound(name)

    if container.status == "running":
        container.stop()

    if remove:
        container.remove()

    return True


def get_container_logs(
    name: str = CONTAINER_NAME,
    follow: bool = False,
    tail: int | str = "all",
) -> Iterator[str] | str:
    """Get logs from the MapViewer container."""
    container = get_container(name)
    if container is None:
        raise ContainerNotFound(name)

    if follow:
        return (line.decode("utf-8") for line in container.logs(stream=True, follow=True))
    else:
        return container.logs(tail=tail).decode("utf-8")


def wait_for_container_ready(
    name: str = CONTAINER_NAME,
    timeout: int = 60,
    port: int = 8089,
    log_callback: Callable[[str], None] | None = None,
) -> bool:
    """Wait for the MapViewer container to be ready.

    Uses the /status endpoint to verify MapViewer is fully initialized,
    not just that the port is open.

    Args:
        name: Container name
        timeout: Max wait time in seconds
        port: Host port MapViewer is running on
        log_callback: Optional callback(line: str) called with latest log line
    """
    import time
    import urllib.request
    import urllib.error

    client = get_docker_client()
    start_time = time.time()
    last_log_line = ""

    while time.time() - start_time < timeout:
        try:
            container = client.containers.get(name)
        except Exception:
            time.sleep(0.5)
            continue

        if container.status != "running":
            # Container exited - get logs for error message
            time.sleep(0.5)
            continue

        # Get latest log line for progress feedback
        if log_callback:
            try:
                logs = container.logs(tail=1).decode("utf-8").strip()
                if logs and logs != last_log_line:
                    last_log_line = logs
                    # Get just the last line if multiple
                    log_callback(logs.split("\n")[-1])
            except Exception:
                pass

        # Try HTTP health check on /status endpoint
        try:
            url = f"http://127.0.0.1:{port}/status"
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=2) as response:
                if response.status == 200:
                    return True
        except (urllib.error.URLError, OSError, TimeoutError):
            pass

        time.sleep(0.5)

    return False


@dataclass
class ContainerStats:
    """Snapshot of container resource usage."""

    cpu_percent: float
    memory_mb: float
    memory_limit_mb: float
    net_rx_mb: float
    net_tx_mb: float


def get_container_stats(name: str = CONTAINER_NAME) -> Iterator[ContainerStats]:
    """Stream container resource stats (~1 sample/sec).

    Yields ContainerStats with CPU %, memory, and network I/O.
    Stops when the container exits or an error occurs.
    """
    container = get_container(name)
    if container is None:
        return

    prev_cpu = 0.0
    prev_system = 0.0

    try:
        for raw in container.stats(stream=True, decode=True):
            # CPU
            cpu_delta = (
                raw.get("cpu_stats", {}).get("cpu_usage", {}).get("total_usage", 0)
                - prev_cpu
            )
            system_delta = (
                raw.get("cpu_stats", {}).get("system_cpu_usage", 0) - prev_system
            )
            num_cpus = raw.get("cpu_stats", {}).get("online_cpus", 1) or 1
            prev_cpu = raw.get("cpu_stats", {}).get("cpu_usage", {}).get(
                "total_usage", 0
            )
            prev_system = raw.get("cpu_stats", {}).get("system_cpu_usage", 0)

            if system_delta > 0 and cpu_delta >= 0:
                cpu_percent = (cpu_delta / system_delta) * num_cpus * 100.0
            else:
                cpu_percent = 0.0

            # Memory
            mem_stats = raw.get("memory_stats", {})
            memory_mb = mem_stats.get("usage", 0) / (1024 * 1024)
            memory_limit_mb = mem_stats.get("limit", 0) / (1024 * 1024)

            # Network (sum all interfaces)
            net_rx = 0
            net_tx = 0
            for iface in raw.get("networks", {}).values():
                net_rx += iface.get("rx_bytes", 0)
                net_tx += iface.get("tx_bytes", 0)

            yield ContainerStats(
                cpu_percent=round(cpu_percent, 1),
                memory_mb=round(memory_mb, 1),
                memory_limit_mb=round(memory_limit_mb, 1),
                net_rx_mb=round(net_rx / (1024 * 1024), 2),
                net_tx_mb=round(net_tx / (1024 * 1024), 2),
            )
    except Exception:
        return
