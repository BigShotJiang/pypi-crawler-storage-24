"""Custom exceptions for ndslive.mapviewer."""


class MapViewerError(Exception):
    """Base exception for all MapViewer errors."""

    pass


class DockerNotInstalled(MapViewerError):
    """Docker is not installed on the system."""

    def __init__(self, message: str | None = None):
        self.message = message or (
            "Docker is not installed.\n\n"
            "Please install Docker for your platform:\n"
            "  macOS:   https://docs.docker.com/desktop/install/mac-install/\n"
            "  Windows: https://docs.docker.com/desktop/install/windows-install/\n"
            "  Linux:   https://docs.docker.com/engine/install/\n\n"
            "After installation, run 'mapviewer setup' for guided setup."
        )
        super().__init__(self.message)


class DockerNotRunning(MapViewerError):
    """Docker daemon is not running."""

    def __init__(self, message: str | None = None):
        self.message = message or (
            "Docker daemon is not running.\n\n"
            "Please start Docker:\n"
            "  macOS/Windows:  Open Docker Desktop application\n"
            "  Linux:          sudo systemctl start docker\n\n"
            "Run 'mapviewer setup' for guided setup."
        )
        super().__init__(self.message)


class RegistryNotLoggedIn(MapViewerError):
    """User is not logged into the required Docker registry."""

    def __init__(self, registry: str, edition: str):
        self.registry = registry
        self.edition = edition
        self.message = (
            f"Not logged into Docker registry for {edition} edition.\n\n"
            f"Please login with your NDS credentials:\n"
            f"  docker login {registry}\n\n"
            "To generate an identity token (recommended):\n"
            "  1. Log in to https://artifactory.nds-association.org\n"
            "  2. Click your username (top right) -> Edit Profile\n"
            "  3. Under Identity Tokens, click Generate\n"
            "  4. Use the token as your password for docker login\n\n"
            "Run 'mapviewer setup' for guided setup."
        )
        super().__init__(self.message)


class ImagePullFailed(MapViewerError):
    """Failed to pull the Docker image."""

    def __init__(self, image: str, reason: str | None = None):
        self.image = image
        self.reason = reason
        msg = f"Failed to pull image: {image}"
        if reason:
            msg += f"\n\nReason: {reason}"
        self.message = msg
        super().__init__(self.message)


class ConfigError(MapViewerError):
    """Error in the MapViewer configuration."""

    def __init__(self, message: str, file_path: str | None = None):
        self.file_path = file_path
        if file_path:
            self.message = f"Configuration error in {file_path}:\n{message}"
        else:
            self.message = f"Configuration error: {message}"
        super().__init__(self.message)


class ContainerError(MapViewerError):
    """Error related to container operations."""

    def __init__(self, message: str, container_id: str | None = None):
        self.container_id = container_id
        self.message = message
        super().__init__(self.message)


class ContainerNotFound(ContainerError):
    """MapViewer container not found."""

    def __init__(self, name: str = "ndslive-mapviewer"):
        self.name = name
        self.message = (
            f"Container '{name}' not found.\n\n"
            "Start the MapViewer first:\n"
            "  mapviewer run /path/to/data"
        )
        super().__init__(self.message)


class ContainerAlreadyRunning(ContainerError):
    """MapViewer container is already running."""

    def __init__(self, name: str = "ndslive-mapviewer", port: int | None = None):
        self.name = name
        self.port = port
        msg = f"Container '{name}' is already running."
        if port:
            msg += f"\n\nAccess the MapViewer at: http://localhost:{port}"
        msg += "\n\nThe running instance will be replaced on next 'mapviewer run'."
        self.message = msg
        super().__init__(self.message)


class RegistryQueryFailed(MapViewerError):
    """Failed to query the remote Docker registry."""

    def __init__(self, registry: str, reason: str | None = None):
        self.registry = registry
        self.reason = reason
        msg = f"Failed to query registry: {registry}"
        if reason:
            msg += f"\n\nReason: {reason}"
        msg += (
            "\n\nPossible causes:"
            f"\n  - Not logged in: run 'docker login {registry}'"
            "\n  - Behind a proxy: configure Docker's proxy settings"
            "\n    https://docs.docker.com/engine/cli/proxy/"
        )
        self.message = msg
        super().__init__(self.message)
