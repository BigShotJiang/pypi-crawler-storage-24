"""Shared UI components for the MapViewer CLI."""

from __future__ import annotations

from rich.panel import Panel
from rich.text import Text

DOCS_URL = "https://developer.nds.live/tools/mapviewer"

_BANNER_ART = r"""
 _  _ ___  ___   __  __           __   ___
| \| |   \/ __| |  \/  |__ _ _ __\ \ / (_)_____ __ _____ _ _
| .` | |) \__ \ | |\/| / _` | '_ \\ V /| / -_) V  V / -_) '_|
|_|\_|___/|___/ |_|  |_\__,_| .__/ \_/ |_\___|\_/\_/\___|_|
                             |_|
""".strip("\n")


def build_banner(subtitle: str = "Setup Wizard", dry: bool = False) -> Panel:
    """Build the MapViewer banner panel.

    Args:
        subtitle: Text shown below the ASCII art (e.g. "Setup Wizard"
                  or "community edition | v2025.6.2 (abc123f)").
        dry: If True, append a [DRY RUN] badge to the subtitle.
    """
    title = Text(_BANNER_ART, style="grey74")
    title.append("\n")
    label = Text(subtitle, style="bold")
    if dry:
        label.append("  ")
        label.append("[DRY RUN]", style="yellow")
    title.append_text(label)
    title.append("\n")
    title.append("Full Docs: ")
    title.append(DOCS_URL, style=f"link {DOCS_URL}")
    return Panel.fit(title, border_style="blue")
