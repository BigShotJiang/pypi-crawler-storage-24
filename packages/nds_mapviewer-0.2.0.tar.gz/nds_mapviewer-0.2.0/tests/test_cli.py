"""Tests for CLI integration."""

import subprocess
import sys

import pytest


def run_cli(*args, check=False):
    """Run the CLI and capture output."""
    result = subprocess.run(
        [sys.executable, "-m", "ndslive.mapviewer.cli", *args],
        capture_output=True,
        text=True,
    )
    if check and result.returncode != 0:
        raise subprocess.CalledProcessError(
            result.returncode, args, result.stdout, result.stderr
        )
    return result


class TestCliHelp:
    """Tests for CLI help commands."""

    def test_help_shows_all_options(self):
        """--help shows all options on the root parser."""
        result = run_cli("--help")
        assert result.returncode == 0
        assert "--demo" in result.stdout
        assert "--edition" in result.stdout
        assert "--image-version" in result.stdout
        assert "--no-browser" in result.stdout
        assert "--port" in result.stdout

    def test_help_shows_multi_path(self):
        """--help mentions multiple sources."""
        result = run_cli("--help")
        assert "one or more" in result.stdout.lower()


class TestCliVersion:
    """Tests for CLI version command."""

    def test_version_flag(self):
        """--version shows version info."""
        result = run_cli("--version")
        output = result.stdout + result.stderr
        assert "0.1.0" in output or "version" in output.lower()


class TestCliSourceValidation:
    """Tests for CLI source validation."""

    def test_nonexistent_source(self):
        """Nonexistent source path shows error."""
        result = run_cli("/tmp/this-does-not-exist-xyz123.ndslive")
        assert result.returncode != 0
        output = result.stdout + result.stderr
        assert "not found" in output.lower() or "error" in output.lower()


class TestCliLegacyMigration:
    """Tests for legacy mapviewer.yaml migration hint."""

    def test_legacy_config_deprecation_warning(self, tmp_path, monkeypatch, capsys):
        """Deprecation warning is printed when only mapviewer.yaml exists."""
        nds_dir = tmp_path / ".nds"
        nds_dir.mkdir()
        legacy = nds_dir / "mapviewer.yaml"
        legacy.write_text("sources: []\n")
        new_config = nds_dir / "config.yaml"

        monkeypatch.setattr(
            "ndslive.mapviewer.config.NDS_DIR", nds_dir,
        )
        monkeypatch.setattr(
            "ndslive.mapviewer.config.DEFAULT_CONFIG", new_config,
        )
        monkeypatch.setattr(
            "ndslive.mapviewer.config.LEGACY_CONFIG", legacy,
        )

        # Patch MapViewerApp.run to avoid actually launching the TUI
        app_kwargs = {}
        def fake_run(self):
            app_kwargs.update({
                "run_config": self._run_config,
                "run_label": self._run_label,
            })
        monkeypatch.setattr(
            "ndslive.mapviewer.tui.MapViewerApp.run", fake_run,
        )

        from ndslive.mapviewer.cli import cmd_main
        import argparse

        args = argparse.Namespace(
            edition="community",
            image_version="latest",
            no_browser=True,
            port=0,
            sources=[],
            demo=False,
        )
        rc = cmd_main(args)

        assert rc == 0
        # Legacy file is used as-is (not renamed)
        assert legacy.exists()
        assert not new_config.exists()
        # Config was loaded and passed to the app
        assert app_kwargs["run_config"] == {"sources": []}
        assert "mapviewer.yaml" in app_kwargs["run_label"]
        # Deprecation warning was printed
        captured = capsys.readouterr()
        assert "deprecated" in captured.out


class TestCliPreprocessing:
    """Tests for removed commands."""

    def test_no_removed_commands(self):
        """Removed commands are not accessible."""
        for cmd in [
            "start", "stop", "restart", "status", "logs",
            "open", "list", "inspect", "doctor",
            "run", "connect",
        ]:
            result = run_cli(cmd)
            output = result.stdout + result.stderr
            # Should either fail or be treated as a source-not-found attempt
            assert result.returncode != 0 or "not found" in output.lower()
