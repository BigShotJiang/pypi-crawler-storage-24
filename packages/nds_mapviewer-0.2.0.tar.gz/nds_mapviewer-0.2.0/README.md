# NDS MapViewer

Visualize NDS.Live, NDS.Classic, and GeoJSON map data on a 3D Cesium globe
with live style editing, feature inspection, and layer management — all from
a single `mapviewer` command. No Docker knowledge required.

> **Beta** — This Python package is in early development. The CLI interface may
> change between releases. Feedback and bug reports are welcome via the
> [NDS developer portal](https://developer.nds.live/tools/mapviewer).

Full documentation: **https://developer.nds.live/tools/mapviewer**

## Features

- **3D globe visualization** powered by [Cesium](https://cesium.com/) via [erdblick](https://github.com/ndsev/erdblick)
- **Multiple data formats** — NDS.Live, GeoJSON, NDS.Classic (member edition)
- **Live style editing** — modify map styles in real time with YAML-based rules
- **Feature inspection** — click any map feature to explore its attributes and relations
- **Local and remote data** — view SmartLayer folders, FileStore files, or remote services
- **Guided setup** — interactive wizard for creating data source configs
- **Config management** — save, switch, and delete configs from the RunScreen (`c`)

## Getting Started

The recommended way to set up your NDS.Live environment (credentials, Docker registry, pip index) is via [`ndslive-setup`](https://pypi.org/project/ndslive-setup/):

```bash
pip install ndslive-setup
ndslive-setup
```

This interactive wizard configures everything you need in one step, including installing `nds-mapviewer`.

## Installation

If you prefer to install manually (or `ndslive-setup` already configured your environment):

```bash
pip install nds-mapviewer
```

Requires Python 3.10+ and [Docker](https://docs.docker.com/get-docker/).

## Usage

```bash
mapviewer                         # HomeScreen (or auto-loads ~/.nds/config.yaml)

mapviewer /path/to/data.ndslive   # View a local FileStore
mapviewer /path/to/folder         # View a local SmartLayer folder
mapviewer /path/to/geojson/       # View a GeoJSON folder
mapviewer --demo                  # Try it with NDS Islands sample data

mapviewer mywork                  # Load a saved config by name
mapviewer /path/a.ndslive /path/b # Multiple sources at once
```

All commands accept `-e community|member` and `-i VERSION`.

If `~/.nds/config.yaml` exists, `mapviewer` (with no arguments) loads it
automatically and goes straight to the RunScreen.

## Editions

| Edition | Formats | Access |
|---------|---------|--------|
| **community** | NDS.Live, GeoJSON, open formats | Free — [nds.live](https://nds.live) |
| **member** | + NDS.Classic | [NDS membership](https://nds-association.org/#contact) |

## Open-Source Building Blocks

- **[mapget](https://github.com/ndsev/mapget)** — tile-based map data server with caching
- **[erdblick](https://github.com/ndsev/erdblick)** — Cesium web frontend with live style editing and inspection tools

## License

The MapViewer is a proprietary product of the NDS Association. License terms
and conditions are governed by the account type used to access the Docker
image — registering for a community or member account includes accepting the
applicable licensing terms for the MapViewer and its components.
