"""Setup script for nds-mapviewer - maintained for compatibility."""

from setuptools import setup, find_namespace_packages

# Most configuration is in pyproject.toml
# This file exists for compatibility with older tools

setup(
    packages=find_namespace_packages(where="src", include=["ndslive*"]),
    package_dir={"": "src"},
)
