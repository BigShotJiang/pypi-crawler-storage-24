"""Processor based on Nameparser"""

__version__ = "0.6.7"
