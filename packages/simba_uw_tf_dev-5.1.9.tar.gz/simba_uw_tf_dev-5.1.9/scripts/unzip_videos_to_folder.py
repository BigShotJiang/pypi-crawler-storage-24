"""
Unzip all zip files under a root folder and place all video files into a single
output folder (raw_cropped_videos by default).
Usage: python unzip_videos_to_folder.py [root_dir]
Default root_dir: F:\\troubleshooting\\mitra
"""
import os
import sys
import zipfile
from pathlib import Path

VIDEO_EXT = {".mp4", ".avi", ".mov", ".mkv", ".wmv", ".flv", ".webm", ".m4v", ".mpg", ".mpeg"}
DEFAULT_ROOT = r"F:\troubleshooting\mitra"
OUT_FOLDER = "raw_cropped_videos"


def main():
    root = Path(sys.argv[1] if len(sys.argv) > 1 else DEFAULT_ROOT)
    out_dir = root / OUT_FOLDER
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Root: {root}")
    print(f"Output folder: {out_dir}")

    zips = list(root.rglob("*.zip"))
    print(f"Found {len(zips)} zip file(s)\n")

    count = 0
    for zpath in zips:
        try:
            with zipfile.ZipFile(zpath, "r") as z:
                for name in z.namelist():
                    if z.getinfo(name).is_dir():
                        continue
                    base = os.path.basename(name)
                    ext = os.path.splitext(base)[1].lower()
                    if ext not in VIDEO_EXT:
                        continue
                    dest = out_dir / base
                    if dest.exists():
                        stem, suf = dest.stem, dest.suffix
                        dest = out_dir / f"{stem}_{zpath.stem}{suf}"
                    with z.open(name) as src:
                        dest.write_bytes(src.read())
                    count += 1
                    print(f"  [{count}] {dest.name}  <- {zpath.name}")
        except Exception as e:
            print(f"  ERROR {zpath.name}: {e}")

    print(f"\nDone. {count} video(s) in {out_dir}")


if __name__ == "__main__":
    main()
