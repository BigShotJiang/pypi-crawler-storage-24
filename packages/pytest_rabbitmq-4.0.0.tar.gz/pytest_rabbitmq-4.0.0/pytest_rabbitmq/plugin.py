# Copyright (C) 2013 by Clearcode <http://clearcode.cc>
# and associates (see AUTHORS).

# This file is part of pytest-rabbitmq.

# pytest-rabbitmq is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# pytest-rabbitmq is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with pytest-rabbitmq.  If not, see <http://www.gnu.org/licenses/>.
"""Plugin definition for pytest-rabbitmq."""

from tempfile import gettempdir

from pytest import Parser

from pytest_rabbitmq import factories

# pylint:disable=invalid-name
_help_ctl = "RabbitMQ ctl path"
_help_server = "RabbitMQ server path"
_help_plugindir = "Directory where 'plugin' file is located"
_help_host = "Host at which RabbitMQ will accept connections"
_help_port = "Port at which RabbitMQ will accept connections"
_help_port_search_count = "Number of times, pytest-rabbitmq will search for free port"
_help_distribution_port = "Port at which RabbitMQ nodes will communicate with each other"
_help_node = "Node name for rabbitmq instance"


def pytest_addoption(parser: Parser) -> None:
    """Confioguration option."""
    parser.addini(name="rabbitmq_host", help=_help_host, default="127.0.0.1")
    parser.addoption(
        "--rabbitmq-host",
        action="store",
        dest="rabbitmq_host",
        help=_help_host,
    )

    parser.addini(
        name="rabbitmq_port",
        help=_help_port,
        default=None,
    )
    parser.addoption("--rabbitmq-port", action="store", dest="rabbitmq_port", help=_help_port)

    parser.addini(
        name="rabbitmq_port_search_count", type="int", help=_help_port_search_count, default=5
    )
    parser.addoption(
        "--rabbitmq-port-search-count",
        action="store",
        type=int,
        dest="rabbitmq_port_search_count",
        help=_help_port_search_count,
    )

    parser.addini(
        name="rabbitmq_distribution_port",
        help=_help_distribution_port,
        default=None,
    )
    parser.addoption(
        "--rabbitmq-distribution-port",
        action="store",
        dest="rabbitmq_distribution_port",
        help=_help_distribution_port,
    )

    parser.addini(
        name="rabbitmq_ctl",
        help=_help_ctl,
        default="/usr/lib/rabbitmq/bin/rabbitmqctl",
    )
    parser.addoption("--rabbitmq-ctl", action="store", dest="rabbitmq_ctl", help=_help_ctl)

    parser.addini(
        name="rabbitmq_server",
        help=_help_server,
        default="/usr/lib/rabbitmq/bin/rabbitmq-server",
    )
    parser.addoption("--rabbitmq-server", action="store", dest="rabbitmq_server", help=_help_server)

    parser.addini(
        name="rabbitmq_plugindir",
        help=_help_plugindir,
        default=gettempdir(),
    )
    parser.addoption(
        "--rabbitmq-plugindir",
        action="store",
        metavar="path",
        dest="rabbitmq_plugindir",
        help=_help_plugindir,
    )

    parser.addini(
        name="rabbitmq_node",
        help=_help_node,
        default=None,
    )
    parser.addoption(
        "--rabbitmq-node",
        action="store",
        dest="rabbitmq_node",
        help=_help_node,
    )


rabbitmq_proc = factories.rabbitmq_proc()
rabbitmq = factories.rabbitmq("rabbitmq_proc")
