"""
cvc.sdk.agent — Per-agent interface for the hive mind.

Each ``Agent`` instance is bound to a specific agent identity and provides
methods for committing, recalling, and querying scoped context.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from cvc.core.database import ContextDatabase
from cvc.core.models import (
    CognitiveCommit,
    CommitMetadata,
    CommitType,
    ContentBlob,
    ContextMessage,
    CVCCommitRequest,
)
from cvc.sdk.events import AGENT_TARGETED, COMMIT_CREATED, EventBus
from cvc.sdk.registry import AgentRegistry
from cvc.sdk.router import Router

logger = logging.getLogger("cvc.sdk.agent")


class Agent:
    """
    A hive mind agent bound to a specific identity.

    Provides scoped access to the Merkle DAG — commits go through the
    router for branch targeting, and recalls are limited to branches the
    agent can read.

    Usage::

        agent = hive.register_agent("SPC-AEG-02", role="specialist", squad="aegis")
        agent.commit("Completed radiation analysis", content={"findings": "..."})
        recent = agent.context(limit=5)
        results = agent.recall("radiation levels")
    """

    def __init__(
        self,
        agent_id: str,
        db: ContextDatabase,
        registry: AgentRegistry,
        router: Router,
        event_bus: EventBus,
        *,
        engine: Any = None,
    ) -> None:
        self.agent_id = agent_id
        self._db = db
        self._registry = registry
        self._router = router
        self._event_bus = event_bus
        self._engine = engine  # CVCEngine, if available

    @property
    def profile(self) -> dict[str, Any] | None:
        """Current agent profile from the registry."""
        return self._registry.get(self.agent_id)

    @property
    def squad(self) -> str | None:
        p = self.profile
        return p.get("squad") if p else None

    @property
    def rank(self) -> str | None:
        p = self.profile
        return p.get("rank") if p else None

    # -- Commit ------------------------------------------------------------

    def commit(
        self,
        message: str,
        *,
        content: dict[str, Any] | None = None,
        commit_type: CommitType = CommitType.CHECKPOINT,
        tags: list[str] | None = None,
        target_agent_id: str | None = None,
        action_type: str | None = None,
        branch: str | None = None,
        messages: list[dict[str, str]] | None = None,
    ) -> str:
        """
        Commit a cognitive turn to the hive mind.

        Returns the commit hash.
        """
        target_branch = branch or self._router.target_branch(self.agent_id)

        # Enforce write permission
        if not self._router.validate_write(self.agent_id, target_branch):
            raise PermissionError(
                f"Agent {self.agent_id} cannot write to branch {target_branch}"
            )

        # Ensure branch exists
        bp = self._db.index.get_branch(target_branch)
        if bp is None:
            # Auto-create squad branch if needed
            squad = self.squad
            if squad:
                self._router.ensure_squad_branch(squad)
                bp = self._db.index.get_branch(target_branch)
            if bp is None:
                raise ValueError(f"Branch {target_branch} does not exist")

        # Build content blob
        context_messages = []
        if messages:
            context_messages = [
                ContextMessage(role=m.get("role", "assistant"), content=m.get("content", ""))
                for m in messages
            ]
        blob = ContentBlob(
            messages=context_messages,
            tool_outputs=content or {},
        )

        # Build metadata with hive mind fields
        profile = self.profile or {}
        meta = CommitMetadata(
            agent_id=self.agent_id,
            tags=tags or [],
            squad=profile.get("squad"),
            target_agent_id=target_agent_id,
            rank=profile.get("rank"),
            action_type=action_type,
        )

        commit = CognitiveCommit(
            parent_hashes=[bp.head_hash],
            commit_type=commit_type,
            message=message,
            content_blob=blob,
            metadata=meta,
        )

        commit_hash = self._db.store_commit(commit)
        self._db.index.advance_head(target_branch, commit_hash)

        logger.info(
            "Agent %s committed %s on %s: %s",
            self.agent_id, commit_hash[:12], target_branch, message[:60],
        )

        # Fire events
        event_data = {
            "commit_hash": commit_hash,
            "agent_id": self.agent_id,
            "branch": target_branch,
            "message": message,
            "squad": profile.get("squad"),
            "target_agent_id": target_agent_id,
            "action_type": action_type,
        }
        self._event_bus.emit(COMMIT_CREATED, event_data)
        if target_agent_id:
            self._event_bus.emit(AGENT_TARGETED, event_data)

        return commit_hash

    # -- Recall (semantic search) ------------------------------------------

    def recall(self, query: str, *, limit: int = 5) -> list[CognitiveCommit]:
        """
        Semantic search within the agent's accessible scope.

        Searches the ChromaDB vector store, filtered to branches
        this agent can read.
        """
        readable = self._router.readable_branches(self.agent_id)
        # Use vector search with branch filtering
        if self._db.vectors.available:
            results = self._db.vectors.query(query, n_results=limit * 2)
            if results:
                # Filter to accessible branches by checking commit metadata
                accessible = []
                for doc_id in results:
                    commit = self._db.index.get_commit(doc_id)
                    if commit is not None:
                        accessible.append(commit)
                    if len(accessible) >= limit:
                        break
                return accessible

        # Fallback to text search scoped to agent's commits
        return self._db.index.search_commits(query, limit=limit)

    # -- Context -----------------------------------------------------------

    def context(self, *, limit: int = 10) -> list[CognitiveCommit]:
        """Get recent commits visible to this agent."""
        return self._router.context_for(self.agent_id, limit=limit)

    def inbox(self, *, limit: int = 20) -> list[CognitiveCommit]:
        """Get commits addressed specifically to this agent."""
        return self._db.index.list_commits_by_target(self.agent_id, limit=limit)

    def squad_context(self, *, limit: int = 20) -> list[CognitiveCommit]:
        """Get recent commits from the agent's squad."""
        squad = self.squad
        if not squad:
            return []
        return self._db.index.list_commits_by_squad(squad, limit=limit)

    def history(self, *, limit: int = 50) -> list[CognitiveCommit]:
        """Get this agent's own commit history."""
        return self._db.index.list_commits_by_agent(self.agent_id, limit=limit)
