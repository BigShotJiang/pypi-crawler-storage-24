"""
cvc.sdk.router — Hierarchical routing engine for hive mind.

Determines which branches an agent can read/write, validates
permissions, and provides scoped context views matching the
AstroSwarm tree-isolation model.
"""

from __future__ import annotations

import logging
from typing import Any

from cvc.core.database import IndexDB
from cvc.core.models import CognitiveCommit
from cvc.sdk.registry import AgentRegistry

logger = logging.getLogger("cvc.sdk.router")

# Default branch naming conventions
GLOBAL_BRANCH = "main"
SQUAD_PREFIX = "squad/"
AGENT_PREFIX = "agent/"


class Router:
    """
    Role-based routing engine that enforces branch-level access control
    and provides scoped context views per agent.

    Routing rules:
    - Specialists: read/write their squad branch only
    - Captains: read/write squad branch + read global
    - Mission controllers: read/write global
    - Custom rules via agent profile's readable/writable branches
    """

    def __init__(self, index: IndexDB, registry: AgentRegistry) -> None:
        self._index = index
        self._registry = registry

    def target_branch(self, agent_id: str) -> str:
        """Determine the default write branch for an agent based on its squad."""
        profile = self._registry.get(agent_id)
        if profile is None:
            return GLOBAL_BRANCH
        squad = profile.get("squad")
        if squad:
            return f"{SQUAD_PREFIX}{squad}"
        return GLOBAL_BRANCH

    def validate_write(self, agent_id: str, branch: str) -> bool:
        """Check if agent is allowed to write to the target branch."""
        return self._registry.can_write(agent_id, branch)

    def validate_read(self, agent_id: str, branch: str) -> bool:
        """Check if agent is allowed to read from the target branch."""
        return self._registry.can_read(agent_id, branch)

    def readable_branches(self, agent_id: str) -> list[str]:
        """Return list of branches this agent can read from.

        Empty list from the profile means unrestricted — return all branches.
        """
        profile = self._registry.get(agent_id)
        if profile is None:
            return [GLOBAL_BRANCH]
        readable = profile.get("readable_branches", [])
        if not readable:
            return [b.name for b in self._index.list_branches()]
        return readable

    def writable_branches(self, agent_id: str) -> list[str]:
        """Return list of branches this agent can write to."""
        profile = self._registry.get(agent_id)
        if profile is None:
            return [GLOBAL_BRANCH]
        writable = profile.get("writable_branches", [])
        if not writable:
            return [b.name for b in self._index.list_branches()]
        return writable

    def context_for(
        self, agent_id: str, limit: int = 20
    ) -> list[CognitiveCommit]:
        """Return recent commits visible to this agent (from accessible branches only)."""
        branches = self.readable_branches(agent_id)
        commits: list[CognitiveCommit] = []
        seen: set[str] = set()

        for branch_name in branches:
            branch_commits = self._index.list_commits(branch=branch_name, limit=limit)
            for c in branch_commits:
                if c.commit_hash not in seen:
                    seen.add(c.commit_hash)
                    commits.append(c)

        # Sort by timestamp descending, limit
        commits.sort(key=lambda c: c.metadata.timestamp, reverse=True)
        return commits[:limit]

    def ensure_squad_branch(self, squad: str) -> None:
        """Create the squad branch if it doesn't exist yet."""
        branch_name = f"{SQUAD_PREFIX}{squad}"
        existing = self._index.get_branch(branch_name)
        if existing is not None:
            return
        # Create from HEAD of global branch
        main = self._index.get_branch(GLOBAL_BRANCH)
        if main is None:
            return
        from cvc.core.models import BranchPointer
        self._index.upsert_branch(BranchPointer(
            name=branch_name,
            head_hash=main.head_hash,
            parent_branch=GLOBAL_BRANCH,
            description=f"Squad branch for {squad}",
        ))
        logger.info("Created squad branch %s", branch_name)
