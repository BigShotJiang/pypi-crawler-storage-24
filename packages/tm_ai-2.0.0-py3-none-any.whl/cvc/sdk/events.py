"""
cvc.sdk.events — In-process event bus for hive mind notifications.

Provides pub/sub for commit lifecycle events so agents can react to
each other's contributions in real time.
"""

from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from typing import Any, Callable

logger = logging.getLogger("cvc.sdk.events")

# Standard event names
COMMIT_CREATED = "commit.created"
AGENT_TARGETED = "agent.targeted"
BRANCH_UPDATED = "branch.updated"
SQUAD_MERGED = "squad.merged"
AGENT_REGISTERED = "agent.registered"

EventCallback = Callable[[dict[str, Any]], Any]


class EventBus:
    """
    Lightweight in-process event bus with sync and async subscribers.

    Usage::

        bus = EventBus()
        bus.on("commit.created", lambda e: print(e))
        bus.emit("commit.created", {"hash": "abc123", "agent": "SPC-01"})
    """

    def __init__(self) -> None:
        self._sync_handlers: dict[str, list[EventCallback]] = defaultdict(list)
        self._async_handlers: dict[str, list[Callable]] = defaultdict(list)

    # -- Subscribe ---------------------------------------------------------

    def on(self, event: str, callback: EventCallback) -> None:
        """Register a synchronous event handler."""
        self._sync_handlers[event].append(callback)

    def on_async(self, event: str, callback: Callable) -> None:
        """Register an async event handler."""
        self._async_handlers[event].append(callback)

    def off(self, event: str, callback: EventCallback | None = None) -> None:
        """Remove a specific handler, or all handlers for the event."""
        if callback is None:
            self._sync_handlers.pop(event, None)
            self._async_handlers.pop(event, None)
        else:
            if event in self._sync_handlers:
                try:
                    self._sync_handlers[event].remove(callback)
                except ValueError:
                    pass
            if event in self._async_handlers:
                try:
                    self._async_handlers[event].remove(callback)
                except ValueError:
                    pass

    # -- Emit --------------------------------------------------------------

    def emit(self, event: str, data: dict[str, Any] | None = None) -> None:
        """Fire an event, calling all registered sync handlers."""
        payload = data or {}
        payload.setdefault("event", event)
        for handler in self._sync_handlers.get(event, []):
            try:
                handler(payload)
            except Exception:
                logger.exception("Error in sync handler for %s", event)
        # Also fire wildcard handlers
        for handler in self._sync_handlers.get("*", []):
            try:
                handler(payload)
            except Exception:
                logger.exception("Error in wildcard handler for %s", event)

    async def emit_async(self, event: str, data: dict[str, Any] | None = None) -> None:
        """Fire an event, calling all registered async handlers."""
        payload = data or {}
        payload.setdefault("event", event)
        # Fire sync handlers first
        self.emit(event, payload)
        # Then async handlers
        tasks = []
        for handler in self._async_handlers.get(event, []):
            tasks.append(handler(payload))
        for handler in self._async_handlers.get("*", []):
            tasks.append(handler(payload))
        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for r in results:
                if isinstance(r, Exception):
                    logger.exception("Error in async handler for %s: %s", event, r)
