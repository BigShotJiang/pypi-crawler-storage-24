"""
cvc.sdk — Multi-Agent Cognitive Memory SDK.

Public API for using CVC as a hive mind platform.

Usage::

    from cvc.sdk import HiveMind

    hive = HiveMind(".cvc")
    agent = hive.register_agent("SPC-01", role="specialist", squad="aegis")
    agent.commit("Analysis complete", content={"findings": "..."})
    recent = agent.context(limit=5)
"""

from cvc.sdk.agent import Agent
from cvc.sdk.events import (
    AGENT_REGISTERED,
    AGENT_TARGETED,
    BRANCH_UPDATED,
    COMMIT_CREATED,
    SQUAD_MERGED,
    EventBus,
)
from cvc.sdk.hivemind import HiveMind
from cvc.sdk.registry import AgentRegistry
from cvc.sdk.router import Router

__all__ = [
    # Core classes
    "HiveMind",
    "Agent",
    "AgentRegistry",
    "Router",
    "EventBus",
    # Event constants
    "COMMIT_CREATED",
    "AGENT_TARGETED",
    "BRANCH_UPDATED",
    "SQUAD_MERGED",
    "AGENT_REGISTERED",
]
