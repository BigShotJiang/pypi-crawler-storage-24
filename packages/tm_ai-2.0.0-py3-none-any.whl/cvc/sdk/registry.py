"""
cvc.sdk.registry — Agent Registry for the Hive Mind.

Manages multi-agent identities: registration, lookup, filtering,
and branch-permission enforcement.  Wraps `IndexDB` agent methods.
"""

from __future__ import annotations

import logging
from typing import Any

from cvc.core.database import IndexDB

logger = logging.getLogger("cvc.sdk.registry")


class AgentRegistry:
    """
    Central registry of hive mind agents.

    Backed by the ``agents`` table in the CVC SQLite index.
    """

    def __init__(self, index: IndexDB) -> None:
        self._index = index

    # -- Registration ------------------------------------------------------

    def register(
        self,
        agent_id: str,
        *,
        name: str | None = None,
        role: str | None = None,
        rank: str | None = None,
        squad: str | None = None,
        capabilities: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        readable_branches: list[str] | None = None,
        writable_branches: list[str] | None = None,
    ) -> dict[str, Any]:
        """Register a new agent (or update if it already exists)."""
        self._index.insert_agent(
            agent_id=agent_id,
            name=name,
            role=role,
            rank=rank,
            squad=squad,
            capabilities=capabilities,
            metadata=metadata,
            readable_branches=readable_branches,
            writable_branches=writable_branches,
        )
        logger.info("Registered agent %s (squad=%s, rank=%s)", agent_id, squad, rank)
        return self.get(agent_id)  # type: ignore[return-value]

    # -- Lookup ------------------------------------------------------------

    def get(self, agent_id: str) -> dict[str, Any] | None:
        """Retrieve an agent profile by ID."""
        return self._index.get_agent(agent_id)

    def list(
        self,
        *,
        squad: str | None = None,
        rank: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List agents, optionally filtered."""
        return self._index.list_agents(squad=squad, rank=rank, status=status)

    # -- Updates -----------------------------------------------------------

    def update(self, agent_id: str, **fields: Any) -> bool:
        """Update fields on an existing agent."""
        return self._index.update_agent(agent_id, **fields)

    def deactivate(self, agent_id: str) -> bool:
        """Mark an agent as inactive (soft delete)."""
        return self._index.update_agent(agent_id, status="inactive")

    def remove(self, agent_id: str) -> bool:
        """Hard-delete an agent from the registry."""
        return self._index.delete_agent(agent_id)

    # -- Permission checks -------------------------------------------------

    def can_read(self, agent_id: str, branch: str) -> bool:
        """Check if agent has read access to the given branch."""
        profile = self.get(agent_id)
        if profile is None:
            return False
        readable = profile.get("readable_branches", [])
        # Empty list = unrestricted read
        if not readable:
            return True
        return branch in readable or "**" in readable

    def can_write(self, agent_id: str, branch: str) -> bool:
        """Check if agent has write access to the given branch."""
        profile = self.get(agent_id)
        if profile is None:
            return False
        writable = profile.get("writable_branches", [])
        # Empty list = unrestricted write
        if not writable:
            return True
        return branch in writable or "**" in writable
