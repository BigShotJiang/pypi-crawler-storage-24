"""
cvc.sdk.hivemind — The main ``HiveMind`` class.

Top-level entry point for using CVC as a multi-agent cognitive memory
platform.  Wraps ``CVCEngine`` + ``ContextDatabase`` with a clean,
developer-friendly API.

Usage::

    from cvc.sdk import HiveMind

    hive = HiveMind(".cvc")
    zeus = hive.register_agent("MC-01", role="mission_controller", rank="zeus")
    zeus.commit("Mission initialized", action_type="DIRECTIVE")

    captain = hive.register_agent("CPT-AEG-01", role="captain", rank="captain", squad="aegis")
    captain.commit("Squad Aegis: tasking specialists", target_agent_id="SPC-AEG-01")
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from cvc.core.database import ContextDatabase
from cvc.core.models import (
    CognitiveCommit,
    CVCBranchRequest,
    CVCConfig,
    CVCMergeRequest,
)
from cvc.operations.engine import CVCEngine
from cvc.sdk.agent import Agent
from cvc.sdk.events import AGENT_REGISTERED, EventBus
from cvc.sdk.registry import AgentRegistry
from cvc.sdk.router import Router

logger = logging.getLogger("cvc.sdk.hivemind")


class HiveMind:
    """
    Multi-agent cognitive memory — the hive mind.

    Opens (or initializes) a CVC store and provides methods for
    agent registration, commit, recall, branching, and merging.
    Thread-safe for concurrent agent operations.
    """

    def __init__(self, path: str | Path = ".cvc", *, vector_enabled: bool | None = None) -> None:
        cvc_root = Path(path)
        self._config = CVCConfig(
            cvc_root=cvc_root,
            db_path=cvc_root / "cvc.db",
            objects_dir=cvc_root / "objects",
            branches_dir=cvc_root / "branches",
            chroma_persist_dir=cvc_root / "chroma",
            pageindex_dir=cvc_root / "pageindex",
        )
        if vector_enabled is not None:
            self._config.vector_enabled = vector_enabled
        self._config.ensure_dirs()
        self._db = ContextDatabase(self._config)
        self._engine = CVCEngine(self._config, self._db)
        self._event_bus = EventBus()
        self._registry = AgentRegistry(self._db.index)
        self._router = Router(self._db.index, self._registry)
        self._agents: dict[str, Agent] = {}

    # -- Properties --------------------------------------------------------

    @property
    def db(self) -> ContextDatabase:
        return self._db

    @property
    def engine(self) -> CVCEngine:
        return self._engine

    @property
    def events(self) -> EventBus:
        return self._event_bus

    @property
    def registry(self) -> AgentRegistry:
        return self._registry

    @property
    def router(self) -> Router:
        return self._router

    # -- Agent management --------------------------------------------------

    def register_agent(
        self,
        agent_id: str,
        *,
        name: str | None = None,
        role: str | None = None,
        rank: str | None = None,
        squad: str | None = None,
        capabilities: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        readable_branches: list[str] | None = None,
        writable_branches: list[str] | None = None,
    ) -> Agent:
        """
        Register an agent and return an ``Agent`` handle.

        If the agent already exists, its profile is updated.
        If a squad is specified, the squad branch is auto-created.
        """
        self._registry.register(
            agent_id,
            name=name,
            role=role,
            rank=rank,
            squad=squad,
            capabilities=capabilities,
            metadata=metadata,
            readable_branches=readable_branches,
            writable_branches=writable_branches,
        )

        # Auto-create squad branch
        if squad:
            self._router.ensure_squad_branch(squad)

        agent = Agent(
            agent_id=agent_id,
            db=self._db,
            registry=self._registry,
            router=self._router,
            event_bus=self._event_bus,
            engine=self._engine,
        )
        self._agents[agent_id] = agent

        self._event_bus.emit(AGENT_REGISTERED, {
            "agent_id": agent_id,
            "role": role,
            "rank": rank,
            "squad": squad,
        })

        return agent

    def get_agent(self, agent_id: str) -> Agent | None:
        """Get a previously registered Agent handle."""
        if agent_id in self._agents:
            return self._agents[agent_id]
        # Check registry
        profile = self._registry.get(agent_id)
        if profile is None:
            return None
        agent = Agent(
            agent_id=agent_id,
            db=self._db,
            registry=self._registry,
            router=self._router,
            event_bus=self._event_bus,
            engine=self._engine,
        )
        self._agents[agent_id] = agent
        return agent

    def list_agents(
        self,
        *,
        squad: str | None = None,
        rank: str | None = None,
    ) -> list[dict[str, Any]]:
        """List all registered agents."""
        return self._registry.list(squad=squad, rank=rank)

    # -- Branching & merging -----------------------------------------------

    def branch(self, name: str, *, description: str = "", source_commit: str | None = None) -> str:
        """Create a new branch. Returns the source commit hash."""
        resp = self._engine.branch(CVCBranchRequest(
            name=name,
            source_commit=source_commit,
            description=description,
        ))
        if not resp.success:
            raise RuntimeError(resp.message)
        return resp.commit_hash or ""

    def merge(self, source: str, target: str = "main") -> str:
        """Merge source branch into target. Returns the merge commit hash."""
        resp = self._engine.merge(CVCMergeRequest(
            source_branch=source,
            target_branch=target,
        ))
        if not resp.success:
            raise RuntimeError(resp.message)
        return resp.commit_hash or ""

    def merge_squads(self, target: str = "main") -> list[str]:
        """Merge all squad branches into the target branch."""
        merged: list[str] = []
        for bp in self._db.index.list_branches():
            if bp.name.startswith("squad/") and bp.name != target:
                try:
                    h = self.merge(bp.name, target)
                    merged.append(h)
                except RuntimeError as e:
                    logger.warning("Failed to merge %s: %s", bp.name, e)
        return merged

    # -- Query -------------------------------------------------------------

    def log(
        self,
        *,
        branch: str | None = None,
        agent_id: str | None = None,
        squad: str | None = None,
        limit: int = 50,
    ) -> list[CognitiveCommit]:
        """Query the commit log with optional filters."""
        if agent_id:
            return self._db.index.list_commits_by_agent(agent_id, limit=limit)
        if squad:
            return self._db.index.list_commits_by_squad(squad, limit=limit)
        return self._db.index.list_commits(branch=branch, limit=limit)

    def recall(self, query: str, *, limit: int = 5) -> list[CognitiveCommit]:
        """Global semantic search across the entire hive mind."""
        if self._db.vectors.available:
            results = self._db.vectors.query(query, n_results=limit)
            if results:
                commits = []
                for doc_id in results:
                    c = self._db.index.get_commit(doc_id)
                    if c is not None:
                        commits.append(c)
                return commits
        return self._db.index.search_commits(query, limit=limit)

    # -- Status ------------------------------------------------------------

    def status(self) -> dict[str, Any]:
        """Return a summary of the hive mind state."""
        branches = self._db.index.list_branches()
        agents = self._registry.list()
        return {
            "branch_count": len(branches),
            "branches": [b.name for b in branches],
            "agent_count": len(agents),
            "agents": [a["agent_id"] for a in agents],
            "active_branch": self._engine.active_branch,
            "head_hash": self._engine.head_hash,
        }

    def close(self) -> None:
        """Close all database connections."""
        self._db.index.close()
