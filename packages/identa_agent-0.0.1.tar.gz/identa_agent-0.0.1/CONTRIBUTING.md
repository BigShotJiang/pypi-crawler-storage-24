# Contributing to Anima

First off — thank you. Anima is built in public and shaped by the community. Every issue filed, every PR submitted, and every opinion shared on the RFC makes the project better.

This document explains how to get involved, regardless of your experience level.

---

## Ways to contribute

### 1. Weigh in on the spec (no code required)

The most valuable thing you can do right now is read the [RFC issue #1](https://github.com/shepax/anima-ai/issues/1) and share your opinion on the open questions. The APF format is not locked yet. Your real-world experience building agents is exactly what we need to get the design right.

### 2. File issues

If you've hit a problem that Anima should solve — even if you don't know how to solve it — open an issue. Describe the pain. The more specific, the better.

Good issue titles:
- "APF spec doesn't handle multi-language agents cleanly"
- "No way to represent implicit reasoning style in current schema"
- "anima diff should show behavioral change severity, not just field diffs"

Bad issue titles:
- "Bug"
- "Suggestion"
- "Question"

### 3. Submit a provider adapter

If you build an adapter for a provider we don't support yet (Gemini, Mistral, Ollama, Cohere, etc.), we want it. See the [adapter guide](#building-a-provider-adapter) below.

### 4. Improve the examples

The `/examples` folder is deliberately sparse right now. Real-world agent examples — customer service, sales, internal tooling, coding assistants — are incredibly valuable for new users.

### 5. Fix bugs and ship features

Check the [issues list](https://github.com/shepax/anima-ai/issues) for anything tagged `good first issue` or `help wanted`.

---

## Development setup

### Prerequisites

- Python 3.10+
- `uv` (recommended) or `pip`
- An OpenAI or Anthropic API key for integration tests

### Clone and install

```bash
git clone https://github.com/shepax/anima-ai.git
cd anima-ai
```

Using `uv` (recommended):
```bash
uv venv
source .venv/bin/activate
uv pip install -e ".[dev]"
```

Using `pip`:
```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

### Run tests

```bash
pytest tests/
```

Integration tests (requires API keys):
```bash
OPENAI_API_KEY=sk-... ANTHROPIC_API_KEY=sk-ant-... pytest tests/integration/
```

### Run the CLI locally

```bash
anima --help
anima init --name "TestAgent" --role "Test agent"
anima validate testagent.apf.json
```

---

## Project structure

```
anima/
├── anima/
│   ├── cli.py                  # CLI entry point (Typer)
│   ├── core/
│   │   ├── schema.py           # APF schema validation (Pydantic v2)
│   │   ├── memory.py           # Memory persistence layer
│   │   └── adapters/
│   │       ├── base.py         # Abstract BaseAdapter — start here
│   │       ├── openai.py       # OpenAI adapter
│   │       └── anthropic.py    # Anthropic adapter
├── examples/
│   ├── customer_service/
│   └── sales_assistant/
├── tests/
│   ├── unit/
│   └── integration/
├── SPEC.md                     # APF format specification
└── CONTRIBUTING.md             # This file
```

---

## Building a provider adapter

Adapters are the most impactful contribution you can make. Each adapter teaches Anima how to translate a provider-agnostic APF identity into a specific model's native format.

### The BaseAdapter interface

All adapters inherit from `anima.core.adapters.base.BaseAdapter`:

```python
from abc import ABC, abstractmethod
from anima.core.schema import APFDocument

class BaseAdapter(ABC):

    @abstractmethod
    def export(self, **kwargs) -> APFDocument:
        """
        Pull an existing agent's configuration from the provider
        and return it as an APF document.
        """
        ...

    @abstractmethod
    def import_persona(self, apf: APFDocument, **kwargs) -> dict:
        """
        Translate an APF document into this provider's native
        configuration format and return it ready to use.
        """
        ...

    @abstractmethod
    def compile_system_prompt(self, apf: APFDocument) -> str:
        """
        Compile the APF identity + operating principles into
        a system prompt optimized for this provider's behavior.
        """
        ...

    def get_provider_slug(self) -> str:
        """Return the provider identifier used in APF files."""
        raise NotImplementedError
```

### Key design rule: provider-specific prompt compilation

The most important method is `compile_system_prompt`. This is where your adapter earns its keep.

Do not simply copy the `persona_prompt` field and call it done. The adapter should translate the structured `identity`, `operating_principles`, and `provider_calibration` fields into a prompt that reliably produces the intended behavior on *your specific provider*.

For example, Claude responds better to explicit persona framing ("You genuinely care about...") while GPT responds better to instructional framing ("Always respond with..."). Your adapter should know the difference.

### Adapter checklist before submitting a PR

- [ ] Inherits from `BaseAdapter`
- [ ] Implements `export`, `import_persona`, and `compile_system_prompt`
- [ ] `get_provider_slug` returns a lowercase string matching the APF `provider_adapters` key
- [ ] Handles `behavioral_targets` and `provider_calibration` fields if present
- [ ] Handles `operating_principles` and injects them as behavioral rules
- [ ] Unit tests in `tests/unit/adapters/test_{provider}.py`
- [ ] Integration test with a real API call (gated behind env var check)
- [ ] Entry in the provider table in `README.md`
- [ ] Documented in `SPEC.md` under `provider_adapters`

---

## Code style

- **Formatter:** `ruff format`
- **Linter:** `ruff check`
- **Type hints:** required on all public functions
- **Docstrings:** Google style
- **Tests:** pytest, aim for 80%+ coverage on new code

Run before every commit:
```bash
ruff format .
ruff check .
pytest tests/unit/
```

---

## Commit message format

```
type: short description

Longer explanation if needed. Wrap at 72 chars.

Refs #issue-number
```

Types: `feat`, `fix`, `docs`, `test`, `refactor`, `chore`

Examples:
```
feat: add Anthropic adapter with behavioral calibration support
fix: handle missing operating_principles block in schema validator
docs: add provider adapter guide to CONTRIBUTING.md
```

---

## Pull request process

1. Fork the repo and create a branch: `git checkout -b feat/your-feature`
2. Make your changes with tests
3. Run `ruff` and `pytest` — both must pass
4. Open a PR against `main` with a clear description of what and why
5. Reference any related issues in the PR body
6. A maintainer will review within 48 hours

For large changes (new adapters, spec changes, architectural decisions) — open an issue or RFC comment first before writing code. Saves everyone time.

---

## Reporting security issues

Do not open a public issue for security vulnerabilities. Email directly: security@anima-ai.dev (placeholder — update with real address).

---

## Code of conduct

Be direct. Be kind. Assume good intent. Disagree on ideas, not people.

We are building something the community needs — that only works if the community feels welcome contributing to it.

---

*Thank you for being here early. The spec belongs to all of us.*
