# Agent Persona Format (APF) Specification

**Version:** 0.1-draft  
**Status:** RFC — open for community feedback ([issue #1](https://github.com/shepax/anima-ai/issues/1))  
**Last updated:** 2026-03-21

---

## Overview

The Agent Persona Format (APF) is an open, provider-agnostic JSON standard for encoding the complete identity of an AI agent. An APF file captures everything that makes an agent *itself* — independently of which LLM is currently powering it.

An APF file is:
- **Portable** — readable by any provider adapter
- **Versionable** — designed to be tracked in git
- **Human-readable** — plain JSON, no binary blobs
- **Extensible** — adapters and custom fields via namespaced keys

### Design insight from the community

Early validation with engineers who've solved this problem in production confirmed three things:

1. **System prompts and memory migrate cleanly.** The hard part is not moving the data — it's behavioral equivalence. The same instruction ("be concise") produces noticeably different output on GPT vs Claude vs Gemini.
2. **Persona must be versioned per-provider, not as a single portable prompt.** Engineers who solved this independently all arrived at a config layer with provider-specific tone and verbosity anchors sitting above a provider-agnostic memory layer.
3. **Operating principles are more portable than tone.** Structured behavioral rules ("ask one clarifying question before proceeding") survive provider switches better than stylistic instructions ("sound warm") because they describe *what to do* rather than *how to sound*.

APF is designed around all three insights.

---

## File format

APF files use the `.apf.json` extension by convention.

```
aria.apf.json
sales-bot-v2.apf.json
support-agent-prod.apf.json
```

---

## Top-level schema

```json
{
  "anima_version": "0.1",
  "metadata": { ... },
  "identity": { ... },
  "operating_principles": { ... },
  "behavioral_targets": { ... },
  "memory": { ... },
  "provider_adapters": { ... },
  "extensions": { ... }
}
```

All top-level keys except `anima_version` and `metadata` are optional in v0.1.

---

## Field reference

### `anima_version` *(string, required)*

```json
"anima_version": "0.1"
```

---

### `metadata` *(object, required)*

```json
"metadata": {
  "name": "Aria",
  "role": "Customer success agent for Acme Corp",
  "description": "Handles tier-1 support queries with a warm, solution-focused tone.",
  "created_at": "2026-03-19T00:00:00Z",
  "updated_at": "2026-03-21T00:00:00Z",
  "version": "1.0.0",
  "author": "eng-team@acme.com",
  "tags": ["support", "customer-facing", "production"]
}
```

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | string | yes | Display name of the agent |
| `role` | string | yes | One-line role description |
| `description` | string | no | Longer description of the agent's purpose |
| `created_at` | ISO 8601 | yes | Creation timestamp |
| `updated_at` | ISO 8601 | yes | Last modified timestamp |
| `version` | semver | yes | Agent identity version |
| `author` | string | no | Creator identifier |
| `tags` | string[] | no | Freeform labels |

---

### `identity` *(object)*

The surface-level persona — tone, style, and behavioral boundaries. These fields are stylistic and provider-sensitive. The same values may need different expression per provider. See `provider_adapters[provider].calibration` for per-provider tuning.

```json
"identity": {
  "tone": ["warm", "concise", "professional"],
  "avoid": [
    "filler phrases like 'Certainly!' or 'Absolutely!'",
    "excessive apologies",
    "technical jargon unless user initiates it"
  ],
  "core_traits": ["empathetic", "solution-focused", "brand-consistent"],
  "persona_prompt": "You are Aria, the customer success agent for Acme Corp. You speak with warmth and directness. You prioritize solving the user's problem over procedure.",
  "response_style": {
    "max_length": "concise — 2 to 3 sentences unless detail is explicitly needed",
    "format_preference": "plain prose, no bullet points in casual exchanges",
    "language": "en-US"
  },
  "boundaries": {
    "never_discuss": ["competitor pricing", "internal escalation paths"],
    "always_escalate": ["refund requests over $500", "legal threats"]
  }
}
```

> **Note on portability:** `tone` and `persona_prompt` are not fully portable across providers. Claude tends verbose and careful by default; GPT tends terser. Use `provider_adapters[provider].calibration` to express equivalent tone per provider. See RFC Q7.

---

### `operating_principles` *(object)*

Structured behavioral rules describing *how the agent makes decisions* — independent of tone or style. More portable across providers than identity fields because they define actions, not aesthetics.

Community validation confirmed: "Ask one clarifying question before proceeding" means the same thing to GPT and Claude. "Sound warm" does not.

```json
"operating_principles": {
  "ambiguity_handling": "Ask exactly one clarifying question before proceeding. Never assume.",
  "reasoning_style": "For complex requests, show brief reasoning before the answer. For simple requests, answer directly.",
  "confidence_threshold": "If confidence is below 0.7 or stakes are high, escalate rather than guess.",
  "initiative_level": "Proactive — suggest next steps when the path forward is clear.",
  "error_handling": "Acknowledge mistakes directly. Do not over-apologize. Correct and move on.",
  "scope_discipline": "Stay within your defined role. Redirect clearly when asked about out-of-scope topics."
}
```

Freeform key-value pairs. Values should be specific and actionable — avoid vague directives like "be helpful."

---

### `behavioral_targets` *(object)*

Normalized scalar values (0.0–1.0) representing intended behavioral position on key dimensions. Provider-agnostic targets — the adapter layer finds the provider-specific expression that hits each target.

```json
"behavioral_targets": {
  "warmth": 0.75,
  "verbosity": 0.3,
  "formality": 0.6,
  "proactivity": 0.7,
  "caution": 0.5
}
```

| Dimension | 0.0 | 1.0 |
|---|---|---|
| `warmth` | Neutral, transactional | Highly empathetic, personal |
| `verbosity` | Extremely terse | Highly detailed |
| `formality` | Casual, colloquial | Formal, professional |
| `proactivity` | Reactive only | Highly proactive, anticipates |
| `caution` | Confident, assumes | Highly cautious, verifies |

These targets feed into `provider_adapters[provider].calibration`. See RFC Q7 for the debate on hand-specified vs eval-driven calibration.

---

### `memory` *(object)*

The agent's persistent state across sessions and provider switches. Fully provider-agnostic — community validation confirmed this migrates cleanly between providers without modification.

```json
"memory": {
  "episodic": [
    {
      "id": "ep_001",
      "timestamp": "2026-03-18T14:22:00Z",
      "summary": "User Sarah J. reported billing discrepancy of $45. Escalated to billing team. Ticket #8821 opened.",
      "entities": ["user:sarah.j@example.com", "ticket:8821"],
      "provider": "openai"
    }
  ],
  "procedural": {
    "escalation_threshold": "User expresses frustration twice in a single session",
    "preferred_greeting": "Hi [name], happy to help.",
    "known_edge_cases": [
      "Users from EU may ask about GDPR data requests — always route to privacy@acme.com"
    ]
  },
  "semantic": {
    "product_knowledge_version": "2026-Q1",
    "last_training_sync": "2026-03-01T00:00:00Z"
  }
}
```

#### `memory.episodic` *(array)*

Compressed natural language summaries of significant past interactions — not raw transcripts. See RFC Q1 for the debate on summaries vs raw pairs.

| Field | Type | Description |
|---|---|---|
| `id` | string | Unique episode identifier |
| `timestamp` | ISO 8601 | When the episode occurred |
| `summary` | string | Human-readable summary |
| `entities` | string[] | Named entities involved |
| `provider` | string | Which LLM provider was active |

#### `memory.procedural` *(object)*

Behavioral policies learned from experience — distinct from `operating_principles` (designed up front). Freeform key-value pairs.

#### `memory.semantic` *(object)*

Metadata about the agent's knowledge state. Freeform key-value pairs.

---

### `provider_adapters` *(object)*

Provider-specific configuration. Each key is a provider slug. The adapter translates the provider-agnostic fields into the format and idiom that provider responds to best.

```json
"provider_adapters": {
  "openai": {
    "model": "gpt-4o",
    "system_prompt_template": "You are {name}, {role}. {persona_prompt}\n\nTone: {tone_joined}. Avoid: {avoid_joined}.\n\nOperating rules:\n{operating_principles_joined}",
    "calibration": {
      "warmth_expression": "Always acknowledge the user's situation before answering.",
      "verbosity_expression": "Keep responses under 3 sentences unless the user asks for detail.",
      "formality_expression": "Use professional but approachable language."
    },
    "parameters": { "temperature": 0.7, "max_tokens": 1024 },
    "tools": [],
    "assistant_id": "asst_abc123"
  },
  "anthropic": {
    "model": "claude-sonnet-4-6",
    "system_prompt_template": "You are {name}, {role}. {persona_prompt}\n\nQualities: {tone_joined}. Never: {avoid_joined}.\n\nHow you operate:\n{operating_principles_joined}",
    "calibration": {
      "warmth_expression": "You genuinely care about helping this person. Lead with empathy, then solve.",
      "verbosity_expression": "Be direct. Claude's default is verbose — actively resist that. Say what needs saying, nothing more.",
      "formality_expression": "Warm professional. Not stiff, not casual."
    },
    "parameters": { "temperature": 0.7, "max_tokens": 1024 }
  }
}
```

| Field | Type | Required | Description |
|---|---|---|---|
| `model` | string | yes | Model identifier for this provider |
| `system_prompt_template` | string | no | Jinja2-style template compiled at runtime |
| `calibration` | object | no | Provider-specific expressions for behavioral targets |
| `parameters` | object | no | Provider-specific generation parameters |
| `tools` | array | no | Tool/function definitions in provider's native schema |
| `assistant_id` | string | no | Provider-specific agent identifier |

#### Template variables

| Variable | Source |
|---|---|
| `{name}` | `metadata.name` |
| `{role}` | `metadata.role` |
| `{persona_prompt}` | `identity.persona_prompt` |
| `{tone_joined}` | `identity.tone` as comma-separated string |
| `{avoid_joined}` | `identity.avoid` as newline-separated list |
| `{operating_principles_joined}` | `operating_principles` formatted as bullet rules |

#### The calibration block

The practical solution to provider sensitivity. Same `verbosity: 0.3` target, different expression:

- **OpenAI:** `"Keep responses under 3 sentences unless the user asks for detail."`
- **Anthropic:** `"Be direct. Claude's default is verbose — actively resist that."`

Same target. Different expression. Both arrive at equivalent behavior.

---

### `extensions` *(object)*

Namespaced custom fields. Use reverse-domain notation to avoid collisions.

```json
"extensions": {
  "com.acme.compliance": {
    "data_residency": "EU",
    "pii_handling": "redact"
  },
  "io.langchain.config": {
    "chain_type": "conversational_retrieval",
    "retriever_k": 4
  }
}
```

---

## Complete example

```json
{
  "anima_version": "0.1",
  "metadata": {
    "name": "Aria",
    "role": "Customer success agent for Acme Corp",
    "description": "Handles tier-1 support with warmth and efficiency.",
    "created_at": "2026-03-19T00:00:00Z",
    "updated_at": "2026-03-21T00:00:00Z",
    "version": "1.2.0",
    "author": "eng@acme.com",
    "tags": ["support", "production", "en-US"]
  },
  "identity": {
    "tone": ["warm", "concise", "professional"],
    "avoid": [
      "filler phrases like 'Certainly!' or 'Absolutely!'",
      "excessive apologies",
      "technical jargon unless user initiates it"
    ],
    "core_traits": ["empathetic", "solution-focused", "brand-consistent"],
    "persona_prompt": "You are Aria, Acme Corp's customer success agent. Direct, warm, and always focused on solving the user's actual problem. You never overpromise.",
    "response_style": {
      "max_length": "2 to 3 sentences unless detail is needed",
      "format_preference": "plain prose",
      "language": "en-US"
    },
    "boundaries": {
      "never_discuss": ["competitor pricing", "internal escalation paths"],
      "always_escalate": ["refund requests over $500", "legal threats"]
    }
  },
  "operating_principles": {
    "ambiguity_handling": "Ask exactly one clarifying question before proceeding. Never assume.",
    "reasoning_style": "Answer directly for simple requests. Show brief reasoning for complex ones.",
    "initiative_level": "Suggest next steps when the path forward is obvious.",
    "error_handling": "Acknowledge mistakes directly. Do not over-apologize. Correct and move on.",
    "scope_discipline": "Redirect clearly when asked about out-of-scope topics."
  },
  "behavioral_targets": {
    "warmth": 0.75,
    "verbosity": 0.3,
    "formality": 0.6,
    "proactivity": 0.7,
    "caution": 0.5
  },
  "memory": {
    "episodic": [],
    "procedural": {
      "escalation_threshold": "User expresses frustration twice in one session",
      "preferred_greeting": "Hi [name], happy to help."
    },
    "semantic": {
      "product_knowledge_version": "2026-Q1"
    }
  },
  "provider_adapters": {
    "openai": {
      "model": "gpt-4o",
      "calibration": {
        "warmth_expression": "Always acknowledge the user's situation before answering.",
        "verbosity_expression": "Keep responses under 3 sentences unless asked for detail."
      },
      "parameters": { "temperature": 0.7, "max_tokens": 1024 }
    },
    "anthropic": {
      "model": "claude-sonnet-4-6",
      "calibration": {
        "warmth_expression": "You genuinely care about helping. Lead with empathy, then solve.",
        "verbosity_expression": "Be direct. Claude's default is verbose — actively resist that."
      },
      "parameters": { "temperature": 0.7, "max_tokens": 1024 }
    }
  }
}
```

---

## Versioning

- **Patch** (`1.0.0` → `1.0.1`): Minor wording changes, parameter tweaks
- **Minor** (`1.0.0` → `1.1.0`): New fields, new provider adapters, memory entries
- **Major** (`1.0.0` → `2.0.0`): Breaking behavioral change — significant persona shift

Track APF files in git. Treat them like code. Diff them with `anima diff`.

---

## Design principles

1. **Provider-agnostic first.** `identity`, `operating_principles`, and `behavioral_targets` must be meaningful without provider-specific knowledge.
2. **Human readable.** An APF file should be understandable by a non-engineer brand manager.
3. **Lossless round-trips.** Export from Provider A, import to Provider B — behavioral intent preserved.
4. **Operating principles over stylistic instructions.** Structured behavioral rules are more portable than tone adjectives.
5. **Minimal required fields.** Only `anima_version` and `metadata` are required.
6. **Extensible without forking.** The `extensions` block handles customization cleanly.

---

## Open questions (RFC)

Full debate at [issue #1](https://github.com/shepax/anima-ai/issues/1):

- **Q1:** Should `episodic` memory store raw message pairs or summaries only?
- **Q2:** Should APF support binary embeddings for semantic memory, or stay text-only?
- **Q3:** Should `persona_prompt` be required, or always auto-generated from structured fields?
- **Q4:** Multi-language agents — one APF per locale or a `locales` map?
- **Q5:** Should APF support agent composition — inheriting from a base persona?
- **Q6:** What's missing entirely? Describe your use case.
- **Q7:** Should `behavioral_targets` calibration be hand-specified or eval-driven?

  From community feedback — an engineer independently built this same architecture and asked: *"Has anyone tried using evals to automate the tone calibration part, like scoring outputs against a reference persona across providers?"*

  **Option A:** Hand-specified (current spec) — explicit, auditable, no infrastructure needed.
  **Option B:** Eval-driven — LLM judge scores outputs against targets, iterates until convergence.
  **Option C:** Both as layers — hand-specified baseline, eval-derived override when available.

---

## Changelog

| Version | Date | Notes |
|---|---|---|
| 0.1-draft | 2026-03-19 | Initial draft |
| 0.1-draft | 2026-03-21 | Added `operating_principles`, `behavioral_targets`, `calibration` block based on community validation. Added Q6, Q7. |

---

*This spec is maintained by the Anima community. To propose changes, open an issue or PR.*
