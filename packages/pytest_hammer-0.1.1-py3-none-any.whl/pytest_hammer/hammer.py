class Hammer:
    def __init__(self):
        self.mysql = {}
        self.mongo = {}
        self.es = {}

    def __getitem__(self, key):
        return self.__dict__.get(key)

    def __setitem__(self, key, value):
        self.__dict__[key] = value


hammer = Hammer()
