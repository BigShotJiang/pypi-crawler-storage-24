"""
@CreateTime: 2026/3/18
@ModifyTime:
@Author: rick
@Desc:
"""
import json
import requests
from pytest_hammer import log


def post(url, body, headers=None, raw=False):
    log.info(f'POST:{url} params:{json.dumps(body)}, headers:{headers}')
    res = requests.post(url, json=body, headers=headers)
    if raw:
        try:
            log.info(f'POST:{url} res:{res.json()}')
        except Exception as e:
            log.warning('返回解析错误...')
    else:
        res = res.json()
        log.info(f'POST:{url} res:{res}')
    return res


def post_form(url, params, headers=None, raw=False):
    log.info(f'POST:{url} params:{json.dumps(params)}, headers:{headers}')
    res = requests.post(url, data=params, headers=headers)
    if raw:
        try:
            log.info(f'POST:{url} res:{res.json()}')
        except Exception as e:
            log.warning('返回解析错误...')
    else:
        res = res.json()
        log.info(f'POST:{url} res:{res}')
    return res


def get(url, params=None, headers=None, raw=False):
    log.info(f'GET:{url} params:{json.dumps(params)}, headers:{headers}')
    res = requests.get(url, params=params, headers=headers)
    if raw:
        try:
            log.info(f'GET:{url} res:{res.json()}')
        except Exception as e:
            log.warning('返回解析错误...')
    else:
        res = res.json()
        log.info(f'GET:{url} res:{res}')
    return res


def response_ok(data: list = None):
    res = {'success': True, 'errorMsg': ''}
    if data:
        if isinstance(data, (list, dict)):
            res['data'] = data
    else:
        res['data'] = []
    return res


def response_error(msg='', data: list = None):
    res = {'success': False, 'errorMsg': msg}
    if data and isinstance(data, list):
        res['data'] = data
    else:
        res['data'] = []
    return res


def response_paging_ok(data: list = None, total: int = 0):
    res = {'success': True, 'errorMsg': '', 'total': total}
    if data and isinstance(data, list):
        res['data'] = data
    else:
        res['data'] = []
    return res


def response(data):
    res = {
        'success': True,
        'errorMsg': '',
        'data': data
    }
    return res

