import pytest
import yaml
import pytest
from pytest_hammer import log, hammer
from pytest_hammer.db.mysql import Mysql
from pytest_hammer.db.mongo import Mongo
from pytest_hammer.db.es import Es
from pytest_hammer.db.redis import Redis
from pytest_hammer import dingtalk
from pytest_hammer.request import rest
from pytest_hammer import utils


def pytest_addoption(parser):
    group = parser.getgroup('hammer')
    group.addoption(
        '--cfg',
        action='store',
        dest='cfg',
        default='',
        help='get config file path'
    )


yaml_cfg = {}
hammer.dingtalk = dingtalk
hammer.rest = rest
hammer.utils = utils


@pytest.fixture(scope="session", autouse=True)
def config_read(request):
    log.info(f"yaml path: {request.config.option.cfg}")
    global yaml_cfg
    if request.config.option.cfg:
        with open(request.config.option.cfg) as f:
            yaml_cfg = yaml.safe_load(f)
            log.info(f"yaml cfg: {yaml_cfg}")


@pytest.fixture(scope="session", autouse=True)
def set_hammer():
    for key, value in yaml_cfg.items():

        # 设置mysql
        if 'mysql' in key:
            mysql = Mysql(
                host=yaml_cfg[key]['host'],
                user=yaml_cfg[key]['user'],
                password=yaml_cfg[key]['password'],
                db=yaml_cfg[key]['db'],
                port=yaml_cfg[key]['port']
            )

            hammer.mysql[key] = mysql

        # 设置mongo
        if 'mongo' in key:
            mongo = Mongo(
                host=yaml_cfg[key]['host'],
                user=yaml_cfg[key]['user'],
                password=yaml_cfg[key]['password'],
                db=yaml_cfg[key]['db'],
                port=yaml_cfg[key]['port']
            )

            hammer.mongo[key] = mongo

        # 设置es
        if 'es' in key:
            es = Es(
                host=yaml_cfg[key]['host'],
                port=yaml_cfg[key]['port']
            )

            hammer.es[key] = es

        # 设置redis
        if 'redis' in key:
            redis = Redis(
                host=yaml_cfg[key]['host'],
                port=yaml_cfg[key]['port']
            )

            hammer.redis[key] = redis
