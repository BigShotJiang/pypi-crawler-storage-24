from pytest_hammer.logger import log
from pytest_hammer.hammer import hammer
from pytest_hammer.request.rest import post, post_form, get
