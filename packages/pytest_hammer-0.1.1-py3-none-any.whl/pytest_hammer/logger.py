import logging
import colorlog


# 1、设置日志器的名字，默认是root
log = logging.getLogger('hammer')
# 设置全局的日志级别
log.setLevel('INFO')

# 输出到文件 和 输出到控制台的格式可以定义不同
log_colors_config = {
            'DEBUG': 'cyan',
            'INFO': 'green',
            'WARNING': 'yellow',
            'ERROR': 'red',
            'CRITICAL': 'red',
        }
formatter = colorlog.ColoredFormatter(
            '%(log_color)s%(asctime)s  %(filename)s[line:%(lineno)d] %(levelname)s: %(message)s',
            log_colors=log_colors_config)
log_fmt = '%(asctime)s - %(funcName)s - %(levelname)s - %(message)s'

# # 2、设置输出日志到文件
# # encoding='utf-8' 输出到文件中的中文日志就不会乱码了
# file_handler = logging.FileHandler(filename='./log.txt', encoding='utf-8', mode='a')  # stdout to file
# # 此时输出到文件单独设置了日志级别为ERROR，此时输出到文件中的日志级别为ERROR
# file_handler.setLevel('ERROR')
# file_handler.setFormatter(formatter)
# # 将file_handler加入到logger内
# logger.addHandler(file_handler)  # 添加handler

# 3、设置输出日志到控制台
control_handler = logging.StreamHandler()  # stdout to console
control_handler.setLevel('INFO')  # 设置INFO级别
control_handler.setFormatter(formatter)
# 将control_handler加入到logger内
log.addHandler(control_handler)  # 把控制台日志对象添加到logger中
