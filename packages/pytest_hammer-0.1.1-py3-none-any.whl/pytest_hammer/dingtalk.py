from pytest_hammer import post, get


def send_msg(token, msg, type="text", **kwargs):
    url = "https://oapi.dingtalk.com/robot/send?access_token=" + token
    data = {}
    headers = {'Content-Type': "application/json;charset=UTF-8", 'accept': "application/json;charset=UTF-8"}
    atMobiles = []
    if 'atMobiles' in kwargs:
        for atMobile in kwargs['atMobiles']:
            atMobiles.append(atMobile)

    if "text" == type:
        data = {'msgtype': 'text',
                'text': {'content': msg},
                'at': {'atMobiles': atMobiles, 'isAtAll': False}}
    elif "link" == type:
        data = {'msgtype': 'link',
                'link': {'title': kwargs['title'], 'text': msg, 'messageUrl': kwargs['msgUrl']},
                'at': {'atMobiles': atMobiles, 'isAtAll': False}}
    elif "markdown" == type:
        data = {"msgtype": "markdown",
                "markdown": {"title": kwargs['title'], 'text': msg},
                "at": {"atMobiles": atMobiles, "isAtAll": False}}
    return post(url, data, headers)


