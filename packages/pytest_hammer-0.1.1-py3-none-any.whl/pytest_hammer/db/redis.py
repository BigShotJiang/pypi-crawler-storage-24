from rediscluster import RedisCluster


class Redis:
    def __init__(self, host, port):
        startup_nodes = [
            {"host": host, "port": port}
        ]
        self.rc = RedisCluster(startup_nodes=startup_nodes, decode_responses=True)

    def keys(self, key):
        return self.rc.keys(key)

    def get(self, key):
        return self.rc.get(key)

    def delete(self, key):
        return self.rc.delete(key)

    def set(self, key, value):
        return self.rc.set(name=key, value=value)
