import pymysql
from pytest_hammer import log
from dbutils.pooled_db import PooledDB


class Mysql:

    def __init__(self, host, user, password, db, port=3306):
        self.__pool = PooledDB(
            pymysql,
            maxconnections=10,
            host=host,
            user=user,
            password=password,
            port=port,
            db=db,
            charset='utf8',
            cursorclass=pymysql.cursors.DictCursor
        )

    def __del__(self):
        if self.__pool:
            self.__pool.close()

    def execute_sql(self, sql, values=None):
        connection = self.__pool.connection()
        cursor = connection.cursor()
        try:
            connection.ping(reconnect=True)  # 连接断开自动重连
            cursor.execute(sql, values)
            connection.commit()
        except Exception as e:
            log.error(e)
            connection.rollback()

    def execute_sql_batch(self, sql, values=None):
        connection = self.__pool.connection()
        cursor = connection.cursor()
        try:
            connection.ping(reconnect=True)  # 连接断开自动重连
            cursor.executemany(sql, values)
            connection.commit()
        except Exception as e:
            log.error(e)
            connection.rollback()

    def select(self, sql):
        connection = self.__pool.connection()
        cursor = connection.cursor()
        connection.ping(reconnect=True)
        cursor.execute(sql)
        res = cursor.fetchall()
        return res

    def update(self, sql, values=None):
        self.execute_sql(sql, values)

    def insert(self, sql, values=None):
        self.execute_sql(sql, values)

    def insert_batch(self, sql, values):
        self.execute_sql_batch(sql, values)

    def delete(self, sql, values=None):
        self.execute_sql(sql, values)

