from elasticsearch import Elasticsearch
from pytest_hammer import log


class Es:
    def __init__(self, host, port):
        self.es = Elasticsearch([{"host": host, "port": port}])

    def es_search(self, index, body):
        try:
            search_result = self.es.search(index=index, body=body)
            if search_result is None:
                log.info("查询ES结果为None")
            return search_result
        except Exception as e:
            log.error("连接es失败，%s" % str(e))

    def es_delete(self, index, es_id, doc_type):
        try:
            return self.es.delete(index=index, id=es_id, doc_type=doc_type)
        except Exception as e:
            log.info("es_id {} not found,{}".format(es_id, e.args[1]))

    def es_insert(self, index, doc_type, es_id, body):
        try:
            return self.es.index(index=index, doc_type=doc_type, id=es_id, body=body)
        except Exception as e:
            log.info("es_id {} not found,{}".format(es_id, e.args[1]))

