from pytest_hammer import log
from pymongo import MongoClient


class Mongo:

    def __init__(self, host, user, password, db, port=27017):
        self.connection = MongoClient(f'mongodb://{user}:{password}@{host}:{port}/{db}')
        self.db = self.connection[db]

    def insert(self, collection, data):
        if isinstance(data, dict):
            self.db[collection].insert_one(data)
        elif isinstance(data, list):
            self.db[collection].insert_many(data)
        else:
            log.warning(f'插入数据类型错误，当前类型为：{type(data)}')