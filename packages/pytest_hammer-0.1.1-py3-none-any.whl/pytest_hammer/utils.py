from functools import wraps


def register_usage(func):
    """
    使用记录装饰器
    :param func: 函数
    :return:
    """
    @wraps(func)
    def usage(*args, **kwargs):
        # data_count = None
        # if request.method.upper() == 'POST':
        #     params = request.json
        #     data = params.get('positions') or params.get('traceInfo')
        #     data_count = len(data) if data else None
        #     params = json.dumps(params)
        #     log.info(f'{request.method.upper()}: {request.path}: {params}')
        # else:
        #     params = json.dumps(request.args)
        #     if request.args.keys():
        #         log.info(f'{request.method.upper()}: {request.path}: {params}')
        #     else:
        #         log.info(f'{request.method.upper()}: {request.path}')
        # start = time.time()

        # 调用函数
        res = func(*args, **kwargs)
        # success = res.get('success') if res and isinstance(res, dict) else None
        #
        # end = time.time()
        # consume_time = round(end - start, 2)
        # user = request.headers.get('userName', '')
        # user = urllib.parse.unquote(user)
        # add_usage_record(func.__name__, consume_time, params, success, user, data_count)
        # log.info(f'consume time: {consume_time}s')
        return res

    return usage
