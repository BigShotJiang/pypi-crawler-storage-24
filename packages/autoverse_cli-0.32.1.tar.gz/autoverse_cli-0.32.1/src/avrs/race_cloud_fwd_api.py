import argparse
import json
import re
import time
import subprocess
import threading
import http
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# https://gist.github.com/dfrankow/f91aefd683ece8e696c26e183d696c29

REAPER_CHECK_INTERVAL_SEC = 15
REAPER_STALE_THRESHOLD_SEC = 60

class ApiForwardHandler(BaseHTTPRequestHandler):
    def __init__(self, target_port):
        self.target_port = target_port
        self.heartbeat_timestamps = {}
        self.heartbeat_lock = threading.Lock()

    # allows to be passed to the HTTPServer ctor
    def __call__(self, *args, **kwargs):
        """Handle a request."""
        super().__init__(*args, **kwargs)

    def do_POST(self):
        length = int(self.headers.get('content-length'))
        rfile_str = self.rfile.read(length).decode('utf8')

        if self.path == '/heartbeat':
            self.handle_heartbeat(rfile_str)
            return

        sim_response = self.get_fwd_response(rfile_str)
        try:
            print("{} : {}".format(self.client_address, rfile_str))
        except:
            pass
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(sim_response.encode('utf-8'))
        self.end_headers()

    def handle_heartbeat(self, body):
        try:
            data = json.loads(body)
            slot = int(data['slot'])
            team_name = data.get('team_name', 'unknown')
            with self.heartbeat_lock:
                self.heartbeat_timestamps[slot] = (time.time(), team_name)
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"ok": true}')
        except Exception as e:
            self.send_response(HTTPStatus.BAD_REQUEST)
            self.end_headers()
            self.wfile.write(json.dumps({"ok": False, "error": str(e)}).encode('utf-8'))

    def get_fwd_response(self, body):
        connection = http.client.HTTPConnection('localhost', self.target_port, timeout=3)
        headers = {
            'Content-type': 'application/json',
        }
        #body = json.dumps(body).encode('utf-8') # already a string here
        connection.request('POST', '/post', body, headers)
        response = connection.getresponse()
        response_string = ''
        if response.status != 200:
            pass
        else:
            response_string = response.read().decode('utf-8')
        return response_string


class HeartbeatReaper(threading.Thread):
    def __init__(self, handler):
        super().__init__(daemon=True)
        self.handler = handler

    def run(self):
        while True:
            time.sleep(REAPER_CHECK_INTERVAL_SEC)
            self.check_stale_slots()

    def check_stale_slots(self):
        now = time.time()
        stale_slots = []
        with self.handler.heartbeat_lock:
            for slot, (last_time, team_name) in self.handler.heartbeat_timestamps.items():
                if now - last_time > REAPER_STALE_THRESHOLD_SEC:
                    stale_slots.append((slot, team_name))
            for slot, _ in stale_slots:
                del self.handler.heartbeat_timestamps[slot]

        for slot, team_name in stale_slots:
            self.disconnect_team(slot, team_name)

    def disconnect_team(self, slot, team_name):
        try:
            print('reaper: disconnecting stale team {} from slot {}'.format(team_name, slot))
            subprocess.run(
                ['avrs', 'race-cloud', 'disconnect', team_name, '--local', '--slot', str(slot)],
                timeout=30)
        except Exception as e:
            print('reaper: failed to disconnect team {} from slot {}: {}'.format(team_name, slot, e))
