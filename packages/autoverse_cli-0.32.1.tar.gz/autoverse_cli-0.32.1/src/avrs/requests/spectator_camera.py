from avrs.requests.request import AvrsApiRequest


class AvrsSpectatorCameraRequests():
    def __init__(self, parser, cfg):
        psr = parser.add_parser('spectator', help='control the spectator camera for broadcast-style viewing')
        sps = psr.add_subparsers(required=True, help='sub-command spectator')
        EnableSpectatorCamera(sps, cfg)
        DisableSpectatorCamera(sps, cfg)
        SetSpectatorFocusRequest(sps, cfg)


class EnableSpectatorCamera(AvrsApiRequest):
    def __init__(self, parser, cfg):
        AvrsApiRequest.__init__(self, parser, cfg, 'ToggleSpectator', '')
        psr = parser.add_parser('enable', help='enable the spectator camera')
        psr.set_defaults(func=self.send_request)

    def get_request_body(self, args):
        return {
            'bEnabled': True
        }


class DisableSpectatorCamera(AvrsApiRequest):
    def __init__(self, parser, cfg):
        AvrsApiRequest.__init__(self, parser, cfg, 'ToggleSpectator', '')
        psr = parser.add_parser('disable', help='disable the spectator camera')
        psr.set_defaults(func=self.send_request)

    def get_request_body(self, args):
        return {
            'bEnabled': False
        }


class SetSpectatorFocusRequest(AvrsApiRequest):
    def __init__(self, parser, cfg):
        AvrsApiRequest.__init__(self, parser, cfg, 'SetSpectatorFocus', '')
        psr = parser.add_parser('focus', help='set which vehicle the spectator camera follows')
        psr.add_argument(
            'vehicle',
            nargs='?',
            default='leader',
            help='vehicle UID to focus on (from list-sim-objects), or "leader" to follow the race leader (default: leader)')
        psr.set_defaults(func=self.send_request)

    def get_request_body(self, args):
        return {
            'VehicleName': args.vehicle
        }
