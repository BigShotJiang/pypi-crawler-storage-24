from avrs.requests.request import AvrsApiRequest
from argparse import RawTextHelpFormatter

DESPAWN_OBJECT_HELP = '''
despawn an object by name
'''

class AvrsDespawnObjectRequest(AvrsApiRequest):
    def __init__(self, parser, cfg):
        AvrsApiRequest.__init__(self, parser, cfg, 'DespawnObject', 0)
        psr = parser.add_parser('despawn-object', help=DESPAWN_OBJECT_HELP, formatter_class=RawTextHelpFormatter)

        psr.add_argument(
            'name',
            help='the name of the object to despawn')

        psr.set_defaults(func=self.send_request)
    
    def get_request_body(self, args):
        self.target_object_id = args.name
        return {
            'tags': [],
            'bMatchAnyTag': True
        }