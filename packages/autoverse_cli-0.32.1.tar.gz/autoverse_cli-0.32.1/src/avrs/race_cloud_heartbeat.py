import time
import json
import http.client
import logging

HEARTBEAT_INTERVAL_SEC = 15
HEARTBEAT_MAX_FAILURES = 10

def heartbeat_loop(sim_ip, sim_port, team_name, slot):
    """Blocking loop that sends periodic heartbeats to the sim forwarder.
    Exits after HEARTBEAT_MAX_FAILURES consecutive failures."""
    logger = logging.getLogger('avrs')
    consecutive_failures = 0

    logger.info('heartbeat loop starting: sim={}:{}, team={}, slot={}'.format(
        sim_ip, sim_port, team_name, slot))

    while True:
        try:
            connection = http.client.HTTPConnection(sim_ip, sim_port, timeout=5)
            headers = {'Content-type': 'application/json'}
            body = json.dumps({
                'team_name': team_name,
                'slot': slot
            }).encode('utf-8')
            connection.request('POST', '/heartbeat', body, headers)
            response = connection.getresponse()
            response.read()

            if response.status == 200:
                consecutive_failures = 0
                logger.info('heartbeat ok')
            else:
                consecutive_failures += 1
                logger.warning('heartbeat got status {}, failure {}/{}'.format(
                    response.status, consecutive_failures, HEARTBEAT_MAX_FAILURES))

        except Exception as e:
            consecutive_failures += 1
            logger.warning('heartbeat error: {}, failure {}/{}'.format(
                e, consecutive_failures, HEARTBEAT_MAX_FAILURES))

        finally:
            try:
                connection.close()
            except Exception:
                pass

        if consecutive_failures >= HEARTBEAT_MAX_FAILURES:
            logger.error('heartbeat exceeded max failures ({}). exiting.'.format(
                HEARTBEAT_MAX_FAILURES))
            break

        time.sleep(HEARTBEAT_INTERVAL_SEC)
