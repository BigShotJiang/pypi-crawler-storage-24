# Copyright 2015 Objectif Libre
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

"""
test_cloudkittydashboard
----------------------------------

Tests for `cloudkittydashboard` module.
"""

from cloudkittydashboard.dashboards.project.rating import \
    panel as rating_panel
from cloudkittydashboard.dashboards.project.reporting import \
    panel as reporting_panel
from cloudkittydashboard.tests import base
import horizon


class TestCloudkittydashboard(base.TestCase):

    def test_registered(self):
        project_dashboard = horizon.get_dashboard('project')

        panel_1 = project_dashboard.get_panel('rating')
        self.assertEqual(rating_panel.Project_rating, panel_1.__class__)

        panel_2 = project_dashboard.get_panel('reporting')
        self.assertEqual(reporting_panel.Project_reporting, panel_2.__class__)
