"""Tests for tsam_xarray.aggregate()."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
import xarray as xr

import tsam_xarray


def _make_da(
    n_days: int = 30,
    variables: list[str] | None = None,
    regions: list[str] | None = None,
    scenarios: list[str] | None = None,
) -> xr.DataArray:
    """Create a synthetic DataArray for testing."""
    if variables is None:
        variables = ["solar", "wind"]
    if regions is None:
        regions = ["north", "south"]

    time = pd.date_range("2020-01-01", periods=n_days * 24, freq="h")
    rng = np.random.default_rng(42)

    dims = ["time", "variable", "region"]
    shape: list[int] = [len(time), len(variables), len(regions)]
    coords: dict[str, list[str] | pd.DatetimeIndex] = {
        "time": time,
        "variable": variables,
        "region": regions,
    }

    if scenarios is not None:
        dims.append("scenario")
        shape.append(len(scenarios))
        coords["scenario"] = scenarios

    return xr.DataArray(rng.random(shape), dims=dims, coords=coords)


class TestBasicRoundtrip:
    def test_dims_and_shapes(self):
        da = _make_da()
        result = tsam_xarray.aggregate(
            da,
            n_clusters=4,
            time_dim="time",
            cluster_dim=["variable", "region"],
        )
        expected = {"cluster", "timestep", "variable", "region"}
        assert set(result.typical_periods.dims) == expected
        assert result.typical_periods.sizes["cluster"] == 4
        assert result.typical_periods.sizes["timestep"] == 24

    def test_cluster_weights_sum(self):
        da = _make_da()
        result = tsam_xarray.aggregate(
            da,
            n_clusters=4,
            time_dim="time",
            cluster_dim=["variable", "region"],
        )
        assert int(result.cluster_weights.sum()) == 30

    def test_cluster_assignments_shape(self):
        da = _make_da()
        result = tsam_xarray.aggregate(
            da,
            n_clusters=4,
            time_dim="time",
            cluster_dim=["variable", "region"],
        )
        assert result.cluster_assignments.dims == ("period",)
        assert result.cluster_assignments.sizes["period"] == 30

    def test_accuracy_dims(self):
        da = _make_da()
        result = tsam_xarray.aggregate(
            da,
            n_clusters=4,
            time_dim="time",
            cluster_dim=["variable", "region"],
        )
        for field in ("rmse", "mae", "rmse_duration"):
            metric = getattr(result.accuracy, field)
            assert set(metric.dims) == {"variable", "region"}

    def test_reconstructed_shape(self):
        da = _make_da()
        result = tsam_xarray.aggregate(
            da,
            n_clusters=4,
            time_dim="time",
            cluster_dim=["variable", "region"],
        )
        expected = {"time", "variable", "region"}
        assert set(result.reconstructed.dims) == expected
        assert result.reconstructed.sizes["time"] == da.sizes["time"]

    def test_raw_is_tsam_result(self):
        da = _make_da()
        result = tsam_xarray.aggregate(
            da,
            n_clusters=4,
            time_dim="time",
            cluster_dim=["variable", "region"],
        )
        from tsam.result import AggregationResult as TsamResult

        assert isinstance(result.raw, TsamResult)


class TestSingleClusterDim:
    def test_single_dim(self):
        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        result = tsam_xarray.aggregate(
            da_flat,
            n_clusters=4,
            time_dim="time",
            cluster_dim="variable",
        )
        assert set(result.typical_periods.dims) == {
            "cluster",
            "timestep",
            "variable",
        }
        assert set(result.accuracy.rmse.dims) == {"variable"}

    def test_string_cluster_dim(self):
        """cluster_dim accepts a single string."""
        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        result = tsam_xarray.aggregate(
            da_flat,
            n_clusters=4,
            time_dim="time",
            cluster_dim="variable",
        )
        assert "variable" in result.typical_periods.dims


class TestAutoSliceDims:
    def test_extra_dims_auto_sliced(self):
        """Dims not in time or cluster_dim are automatically sliced."""
        da = _make_da(scenarios=["low", "high"])
        result = tsam_xarray.aggregate(
            da,
            n_clusters=4,
            time_dim="time",
            cluster_dim=["variable", "region"],
        )
        assert "scenario" in result.typical_periods.dims
        assert result.typical_periods.sizes["scenario"] == 2
        assert "scenario" in result.accuracy.rmse.dims

    def test_auto_slice_raw_is_dict(self):
        da = _make_da(scenarios=["low", "high"])
        result = tsam_xarray.aggregate(
            da,
            n_clusters=4,
            time_dim="time",
            cluster_dim=["variable", "region"],
        )
        assert isinstance(result.raw, dict)
        assert len(result.raw) == 2

    def test_multiple_auto_slice_dims(self):
        time = pd.date_range("2020-01-01", periods=30 * 24, freq="h")
        rng = np.random.default_rng(42)
        da = xr.DataArray(
            rng.random((len(time), 2, 2, 2)),
            dims=["time", "variable", "scenario", "year"],
            coords={
                "time": time,
                "variable": ["solar", "wind"],
                "scenario": ["low", "high"],
                "year": [2020, 2021],
            },
        )
        result = tsam_xarray.aggregate(
            da,
            n_clusters=4,
            time_dim="time",
            cluster_dim="variable",
        )
        assert "scenario" in result.typical_periods.dims
        assert "year" in result.typical_periods.dims
        assert result.typical_periods.sizes["scenario"] == 2
        assert result.typical_periods.sizes["year"] == 2


class TestExplicitTimeDim:
    def test_non_standard_time_dim(self):
        time = pd.date_range("2020-01-01", periods=30 * 24, freq="h")
        rng = np.random.default_rng(42)
        da = xr.DataArray(
            rng.random((len(time), 2)),
            dims=["t", "variable"],
            coords={"t": time, "variable": ["solar", "wind"]},
        )
        result = tsam_xarray.aggregate(
            da, n_clusters=4, time_dim="t", cluster_dim="variable"
        )
        assert result.typical_periods.sizes["cluster"] == 4


class TestWeights:
    def test_weights_simple_dict(self):
        """Simple dict weights for single cluster_dim."""
        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        result = tsam_xarray.aggregate(
            da_flat,
            time_dim="time",
            cluster_dim="variable",
            n_clusters=4,
            weights={"solar": 2.0, "wind": 1.0},
        )
        tsam_weights = result.raw._aggregation.weightDict
        assert tsam_weights["solar"] == 2.0
        assert tsam_weights["wind"] == 1.0

    def test_weights_dict_of_dicts(self):
        """Dict-of-dicts weights for multiple cluster_dim."""
        da = _make_da()
        result = tsam_xarray.aggregate(
            da,
            time_dim="time",
            cluster_dim=["variable", "region"],
            n_clusters=4,
            weights={"variable": {"solar": 2.0}, "region": {"north": 1.5}},
        )
        tsam_weights = result.raw._aggregation.weightDict
        # solar*north = 2.0*1.5 = 3.0
        assert tsam_weights[("solar", "north")] == 3.0
        # solar*south = 2.0*1.0 = 2.0
        assert tsam_weights[("solar", "south")] == 2.0
        # wind*north = 1.0*1.5 = 1.5
        assert tsam_weights[("wind", "north")] == 1.5
        # wind*south = 1.0*1.0 = 1.0
        assert tsam_weights[("wind", "south")] == 1.0

    def test_weights_affect_clustering(self):
        """Weighted and unweighted produce different results."""
        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        result_no_w = tsam_xarray.aggregate(
            da_flat,
            time_dim="time",
            cluster_dim="variable",
            n_clusters=4,
        )
        result_w = tsam_xarray.aggregate(
            da_flat,
            time_dim="time",
            cluster_dim="variable",
            n_clusters=4,
            weights={"solar": 10.0, "wind": 0.1},
        )
        rmse_no_w = result_no_w.accuracy.rmse
        rmse_w = result_w.accuracy.rmse
        assert float(rmse_w.sel(variable="solar")) < float(
            rmse_no_w.sel(variable="solar")
        )

    def test_weights_rejects_simple_dict_multi_dim(self):
        """Simple dict with multiple cluster_dim raises."""
        da = _make_da()
        with pytest.raises(ValueError, match="single cluster_dim"):
            tsam_xarray.aggregate(
                da,
                time_dim="time",
                cluster_dim=["variable", "region"],
                n_clusters=4,
                weights={"solar": 2.0},
            )

    def test_weights_rejects_unknown_dim(self):
        """Dict-of-dicts with unknown dim key raises."""
        da = _make_da()
        with pytest.raises(ValueError, match="unknown dims"):
            tsam_xarray.aggregate(
                da,
                time_dim="time",
                cluster_dim=["variable", "region"],
                n_clusters=4,
                weights={"scenario": {"low": 2.0}},
            )

    def test_weights_rejects_unknown_coord(self):
        """Weights with unknown coord values raise."""
        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        with pytest.raises(ValueError, match="unknown coords"):
            tsam_xarray.aggregate(
                da_flat,
                time_dim="time",
                cluster_dim="variable",
                n_clusters=4,
                weights={"solar": 2.0, "nuclear": 3.0},
            )

    def test_weights_rejects_mixed_dict(self):
        """Mixed dict values (some dicts, some floats) raise."""
        da = _make_da()
        with pytest.raises(ValueError, match="Mixed weights"):
            tsam_xarray.aggregate(
                da,
                time_dim="time",
                cluster_dim=["variable", "region"],
                n_clusters=4,
                weights={"variable": {"solar": 2.0}, "region": 1.5},  # type: ignore[dict-item]
            )


class TestWeightTranslation:
    """Verify weight values are correctly translated."""

    def test_single_dim_values(self):
        from tsam_xarray._core import _translate_weights

        w = {"variable": {"solar": 2.0, "wind": 0.5}}
        df = pd.DataFrame(
            {"solar": [1.0], "wind": [2.0]},
            index=pd.date_range("2020-01-01", periods=1, freq="h"),
        )
        flat = _translate_weights(w, df, ["variable"])
        assert flat["solar"] == 2.0
        assert flat["wind"] == 0.5

    def test_multi_dim_broadcast(self):
        """Single-dim weights broadcast across other dims."""
        from tsam_xarray._core import _translate_weights

        w = {"variable": {"solar": 2.0, "wind": 1.0}}
        cols = pd.MultiIndex.from_tuples(
            [
                ("solar", "north"),
                ("solar", "south"),
                ("wind", "north"),
                ("wind", "south"),
            ],
            names=["variable", "region"],
        )
        df = pd.DataFrame(
            [[1, 2, 3, 4]],
            columns=cols,
            index=pd.date_range("2020-01-01", periods=1, freq="h"),
        )
        flat = _translate_weights(w, df, ["variable", "region"])
        assert flat[("solar", "north")] == 2.0
        assert flat[("solar", "south")] == 2.0
        assert flat[("wind", "north")] == 1.0
        assert flat[("wind", "south")] == 1.0

    def test_multi_dim_full(self):
        """Full multi-dim weights are multiplied."""
        from tsam_xarray._core import _translate_weights

        w = {
            "variable": {"solar": 3.0, "wind": 1.0},
            "region": {"north": 1.5, "south": 2.0},
        }
        cols = pd.MultiIndex.from_tuples(
            [
                ("solar", "north"),
                ("solar", "south"),
                ("wind", "north"),
                ("wind", "south"),
            ],
            names=["variable", "region"],
        )
        df = pd.DataFrame(
            [[1, 2, 3, 4]],
            columns=cols,
            index=pd.date_range("2020-01-01", periods=1, freq="h"),
        )
        flat = _translate_weights(w, df, ["variable", "region"])
        assert flat[("solar", "north")] == 4.5  # 3.0 * 1.5
        assert flat[("solar", "south")] == 6.0  # 3.0 * 2.0
        assert flat[("wind", "north")] == 1.5  # 1.0 * 1.5
        assert flat[("wind", "south")] == 2.0  # 1.0 * 2.0

    def test_missing_coords_default_to_one(self):
        """Coords not in weights get weight 1.0."""
        from tsam_xarray._core import _translate_weights

        w = {"variable": {"solar": 3.0}}
        df = pd.DataFrame(
            {"solar": [1.0], "wind": [2.0]},
            index=pd.date_range("2020-01-01", periods=1, freq="h"),
        )
        flat = _translate_weights(w, df, ["variable"])
        assert flat["solar"] == 3.0
        assert flat["wind"] == 1.0


class TestValidation:
    def test_invalid_time_dim(self):
        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        with pytest.raises(ValueError, match=r"time_dim.*not in"):
            tsam_xarray.aggregate(
                da_flat,
                n_clusters=4,
                time_dim="nonexistent",
                cluster_dim="variable",
            )

    def test_invalid_cluster_dim(self):
        da = _make_da()
        with pytest.raises(ValueError, match="cluster_dim"):
            tsam_xarray.aggregate(
                da,
                n_clusters=4,
                time_dim="time",
                cluster_dim=["nonexistent"],
            )

    def test_cluster_dim_overlaps_time(self):
        da = _make_da()
        with pytest.raises(ValueError, match="overlap"):
            tsam_xarray.aggregate(
                da,
                n_clusters=4,
                time_dim="time",
                cluster_dim=["time", "variable"],
            )

    def test_cluster_config_weights_rejected(self):
        """ClusterConfig.weights is deprecated and not supported."""
        from tsam import ClusterConfig

        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        with pytest.raises(ValueError, match=r"ClusterConfig\.weights"):
            tsam_xarray.aggregate(
                da_flat,
                n_clusters=4,
                time_dim="time",
                cluster_dim="variable",
                cluster=ClusterConfig(weights={"solar": 2.0}),
            )


class TestMultiIndexPassthrough:
    """Verify tsam preserves MultiIndex columns."""

    def test_multiindex_columns_preserved(self):
        da = _make_da().stack(column=["variable", "region"])
        df = da.to_pandas()
        assert isinstance(df.columns, pd.MultiIndex)

        import tsam

        result = tsam.aggregate(df, n_clusters=4)
        assert isinstance(result.cluster_representatives.columns, pd.MultiIndex)
        assert isinstance(result.reconstructed.columns, pd.MultiIndex)

    def test_multiindex_accuracy_index_preserved(self):
        da = _make_da().stack(column=["variable", "region"])
        df = da.to_pandas()

        import tsam

        result = tsam.aggregate(df, n_clusters=4)
        assert isinstance(result.accuracy.rmse.index, pd.MultiIndex)
        assert isinstance(result.accuracy.mae.index, pd.MultiIndex)


class TestSegmentation:
    def test_segment_durations_shape(self):
        """segment_durations has (cluster, timestep) dims."""
        from tsam import SegmentConfig

        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        result = tsam_xarray.aggregate(
            da_flat,
            time_dim="time",
            cluster_dim="variable",
            n_clusters=4,
            segments=SegmentConfig(n_segments=6),
        )
        assert result.segment_durations is not None
        assert set(result.segment_durations.dims) == {
            "cluster",
            "timestep",
        }
        assert result.segment_durations.sizes["cluster"] == 4
        assert result.segment_durations.sizes["timestep"] == 6

    def test_segment_durations_sum_to_period(self):
        """Each cluster's durations sum to timesteps per period."""
        from tsam import SegmentConfig

        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        result = tsam_xarray.aggregate(
            da_flat,
            time_dim="time",
            cluster_dim="variable",
            n_clusters=4,
            segments=SegmentConfig(n_segments=6),
        )
        assert result.segment_durations is not None
        # Each cluster's durations should sum to 24 (hours per day)
        for c in range(4):
            total = int(result.segment_durations.sel(cluster=c).sum())
            assert total == 24

    def test_no_segmentation_returns_none(self):
        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        result = tsam_xarray.aggregate(
            da_flat,
            time_dim="time",
            cluster_dim="variable",
            n_clusters=4,
        )
        assert result.segment_durations is None

    def test_typical_periods_with_segments(self):
        """typical_periods timestep dim equals n_segments."""
        from tsam import SegmentConfig

        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        result = tsam_xarray.aggregate(
            da_flat,
            time_dim="time",
            cluster_dim="variable",
            n_clusters=4,
            segments=SegmentConfig(n_segments=6),
        )
        assert result.typical_periods.sizes["timestep"] == 6


class TestDisaggregate:
    def test_roundtrip_no_segments(self):
        """disaggregate(typical_periods) matches reconstructed."""
        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        result = tsam_xarray.aggregate(
            da_flat,
            time_dim="time",
            cluster_dim="variable",
            n_clusters=4,
        )
        dis = result.disaggregate(result.typical_periods)
        xr.testing.assert_allclose(dis, result.reconstructed)

    def test_roundtrip_with_segments_ffill(self):
        """disaggregate + ffill matches reconstructed (segmented)."""
        from tsam import SegmentConfig

        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        result = tsam_xarray.aggregate(
            da_flat,
            time_dim="time",
            cluster_dim="variable",
            n_clusters=4,
            segments=SegmentConfig(n_segments=6),
        )
        dis = result.disaggregate(result.typical_periods)
        filled = dis.ffill(dim="time")
        xr.testing.assert_allclose(filled, result.reconstructed)

    def test_disaggregate_dims(self):
        """disaggregate replaces cluster+timestep with time."""
        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        result = tsam_xarray.aggregate(
            da_flat,
            time_dim="time",
            cluster_dim="variable",
            n_clusters=4,
        )
        dis = result.disaggregate(result.typical_periods)
        assert "time" in dis.dims
        assert "cluster" not in dis.dims
        assert "timestep" not in dis.dims
        assert "variable" in dis.dims

    def test_roundtrip_multi_dim(self):
        """disaggregate works with auto-sliced dims."""
        da = _make_da(scenarios=["low", "high"])
        result = tsam_xarray.aggregate(
            da,
            time_dim="time",
            cluster_dim=["variable", "region"],
            n_clusters=4,
        )
        dis = result.disaggregate(result.typical_periods)
        assert dis.dims == result.reconstructed.dims
        np.testing.assert_allclose(dis.values, result.reconstructed.values)

    def test_roundtrip_multi_dim_with_segments(self):
        """disaggregate + ffill with sliced segmented data."""
        from tsam import SegmentConfig

        da = _make_da(scenarios=["low", "high"])
        result = tsam_xarray.aggregate(
            da,
            time_dim="time",
            cluster_dim=["variable", "region"],
            n_clusters=4,
            segments=SegmentConfig(n_segments=6),
        )
        dis = result.disaggregate(result.typical_periods)
        filled = dis.ffill(dim="time")
        assert filled.dims == result.reconstructed.dims
        np.testing.assert_allclose(filled.values, result.reconstructed.values)

    def test_disaggregate_segmented_has_nan(self):
        """Segmented disaggregate has NaN at non-boundary timesteps."""
        from tsam import SegmentConfig

        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        result = tsam_xarray.aggregate(
            da_flat,
            time_dim="time",
            cluster_dim="variable",
            n_clusters=4,
            segments=SegmentConfig(n_segments=6),
        )
        dis = result.disaggregate(result.typical_periods)
        assert bool(dis.isnull().any())


class TestDataValidation:
    def test_reserved_dim_name_cluster(self):
        time = pd.date_range("2020-01-01", periods=30 * 24, freq="h")
        da = xr.DataArray(
            np.random.default_rng(42).random((len(time), 2)),
            dims=["time", "cluster"],
            coords={"time": time, "cluster": ["a", "b"]},
        )
        with pytest.raises(ValueError, match="reserved"):
            tsam_xarray.aggregate(
                da, time_dim="time", cluster_dim="cluster", n_clusters=4
            )

    def test_reserved_dim_name_timestep(self):
        time = pd.date_range("2020-01-01", periods=30 * 24, freq="h")
        da = xr.DataArray(
            np.random.default_rng(42).random((len(time), 2)),
            dims=["time", "timestep"],
            coords={"time": time, "timestep": [0, 1]},
        )
        with pytest.raises(ValueError, match="reserved"):
            tsam_xarray.aggregate(
                da, time_dim="time", cluster_dim="timestep", n_clusters=4
            )

    def test_reserved_dim_name_period(self):
        time = pd.date_range("2020-01-01", periods=30 * 24, freq="h")
        da = xr.DataArray(
            np.random.default_rng(42).random((len(time), 2, 2)),
            dims=["time", "variable", "period"],
            coords={
                "time": time,
                "variable": ["a", "b"],
                "period": [0, 1],
            },
        )
        with pytest.raises(ValueError, match="reserved"):
            tsam_xarray.aggregate(
                da,
                time_dim="time",
                cluster_dim="variable",
                n_clusters=4,
            )

    def test_dask_array_warns(self):
        pytest.importorskip("dask")
        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        da_dask = da_flat.chunk({"time": 100})
        with pytest.warns(UserWarning, match="dask"):
            result = tsam_xarray.aggregate(
                da_dask,
                time_dim="time",
                cluster_dim="variable",
                n_clusters=4,
            )
        assert not hasattr(result.typical_periods.data, "dask")

    def test_nan_rejected(self):
        da = _make_da()
        da_flat = da.isel(region=0).drop_vars("region")
        da_nan = da_flat.copy()
        da_nan.values[0, 0] = np.nan
        with pytest.raises(ValueError, match="NaN"):
            tsam_xarray.aggregate(
                da_nan, time_dim="time", cluster_dim="variable", n_clusters=4
            )

    def test_non_numeric_dtype(self):
        time = pd.date_range("2020-01-01", periods=30 * 24, freq="h")
        da = xr.DataArray(
            [["a", "b"]] * len(time),
            dims=["time", "variable"],
            coords={"time": time, "variable": ["x", "y"]},
        )
        with pytest.raises(TypeError, match="numeric"):
            tsam_xarray.aggregate(
                da, time_dim="time", cluster_dim="variable", n_clusters=4
            )

    def test_non_datetime_time_coord(self):
        da = xr.DataArray(
            np.random.default_rng(42).random((100, 2)),
            dims=["time", "variable"],
            coords={"time": np.arange(100), "variable": ["a", "b"]},
        )
        with pytest.raises(TypeError, match="datetime"):
            tsam_xarray.aggregate(
                da, time_dim="time", cluster_dim="variable", n_clusters=4
            )

    def test_irregular_time_spacing(self):
        times = pd.to_datetime(["2020-01-01", "2020-01-02", "2020-01-04"])
        da = xr.DataArray(
            np.random.default_rng(42).random((3, 2)),
            dims=["time", "variable"],
            coords={"time": times, "variable": ["a", "b"]},
        )
        with pytest.raises(ValueError, match="regular spacing"):
            tsam_xarray.aggregate(
                da, time_dim="time", cluster_dim="variable", n_clusters=2
            )
