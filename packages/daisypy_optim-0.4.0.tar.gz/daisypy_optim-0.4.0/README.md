# daisypy-optim
Framework for optimization of Daisy parameters.

## Features
* Optimization using a greedy sequential optimizer, CMA-ES, or Bayesian optimizers
* Optimization across multiple scenarios
* Single or multi-objective optimization
* Optimization of parameters in both `.dai` and `.py` files

See [doc/examples](doc/examples) for examples of how to run optimizations.

See https://github.com/orting/interactive-decision-maps for visualization of multi-objective optimization results.

## Overview
The framework can be used in two ways

1. As a self-contained environment
2. As a regular python module

### Self contained optimization environment
The idea of self-contained environment is to create a repository that contains everything that is needed for the optimization (except the Daisy binary). This allow easy sharing, version control and archiving. This type of optimization is defined by

* a single dai file template
* zero or more python file templates
* a python script that runs the simulation

A tool is included that generates the python script based on user input. Once generated, it can be adapted to specific needs. To start using `daisypy-optim` this way look at

* [Windows](doc/getting-started-win.md)
* [Linux](doc/getting-started-linux.md)


### Regular python modules
To use `daisypy-optim` as a regular python module. Simply install from `pypi` with

    pip install daisypy-optim

To enable CMA-ES

    pip install daisypy-optim[cma]

To enable Ax (this pulls a lot of dependencies)

    pip install daisypy-optim[ax]

All of the above

    pip install daisypy-optim[cma,ax]

And look at the [doc/examples](doc/examples) and [tests](tests) to see how to setup an optimization


## Chossing an optimization method
There are several optimization methods available

 * `sequential` : A greedy approach that fixes one parameter at a time. Works well when optimizing few paramaters.
 * `cma` : CMA-ES. Works well for larger number of parameters and when the outcome depends strongly on parameter combinations. Does not work for single parameters.
 * `ax` : Ax. Bayesian optimization. Supports multi-objective optimization.


## Continuous/categorical parameters
Both continuous and categorical parameters are supported. Currently, the sequential method treats everything as categorial parameters (by sampling a fixed number of values from the continuous parameters). CMA-ES requires continuous parameters. Ax should wotk with both.
