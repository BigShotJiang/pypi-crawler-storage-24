from sphinx_gha.ext import setup as setup  # noqa: F401
