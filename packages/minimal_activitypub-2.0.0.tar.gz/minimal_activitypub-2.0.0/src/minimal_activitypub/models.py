"""Data models for minimal_activitypub.

This module is reserved for Phase 3 (richer response objects).
"""
