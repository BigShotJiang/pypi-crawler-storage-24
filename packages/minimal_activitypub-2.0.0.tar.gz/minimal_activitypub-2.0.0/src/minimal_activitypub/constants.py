"""Constants for minimal_activitypub."""

from typing import Any
from typing import Final

from pytz import timezone

PAGINATION_UNDEFINED: dict[str, dict[str, str | None]] = {
    "next": {"max_id": None, "min_id": None},
    "prev": {"max_id": None, "min_id": None},
}

REDIRECT_URI: Final[str] = "urn:ietf:wg:oauth:2.0:oob"

# HTTP status codes of interest (more detail at https://en.wikipedia.org/wiki/List_of_HTTP_status_codes)
STATUS_BAD_REQUEST: Final[int] = 400
STATUS_UNAUTHORIZED: Final[int] = 401
STATUS_FORBIDDEN: Final[int] = 403
STATUS_NOT_FOUND: Final[int] = 404
STATUS_CONFLICT: Final[int] = 409
STATUS_GONE: Final[int] = 410
STATUS_UNPROCESSABLE_ENTITY: Final[int] = 422
STATUS_TOO_MANY_REQUESTS: Final[int] = 429
STATUS_INTERNAL_SERVER_ERROR: Final[int] = 500

INSTANCE_TYPE_MASTODON: Final[str] = "Mastodon"
INSTANCE_TYPE_PLEROMA: Final[str] = "Pleroma"
INSTANCE_TYPE_TAKAHE: Final[str] = "takahe"

MAX_ATTACHMENTS_MASTODON: Final[int] = 4
MAX_ATTACHMENTS_PLEROMA: Final[int] = 10  # 10 is a placeholder, reasonable stand in
MAX_ATTACHMENTS_TAKAHE: Final[int] = 10  # 10 is a placeholder, reasonable stand in

UTC: Final[Any] = timezone("UTC")
