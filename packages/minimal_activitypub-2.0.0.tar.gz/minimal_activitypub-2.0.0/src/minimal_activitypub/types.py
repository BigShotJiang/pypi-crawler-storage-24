"""Type definitions for minimal_activitypub."""

from typing import Any
from typing import Dict
from typing import TypeVar

ActivityPubClass = TypeVar("ActivityPubClass", bound="ActivityPub")  # noqa: F821  # ty: ignore[unresolved-reference]
Status = Dict[str, Any]
