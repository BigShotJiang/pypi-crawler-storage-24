"""Package 'minimal_activitypub' level definitions."""

import sys
from enum import Enum
from importlib.metadata import version
from typing import Final

from minimal_activitypub.constants import INSTANCE_TYPE_MASTODON
from minimal_activitypub.constants import INSTANCE_TYPE_PLEROMA
from minimal_activitypub.constants import INSTANCE_TYPE_TAKAHE
from minimal_activitypub.exceptions import ActivityPubError
from minimal_activitypub.exceptions import ApiError
from minimal_activitypub.exceptions import ClientError
from minimal_activitypub.exceptions import ConflictError
from minimal_activitypub.exceptions import ForbiddenError
from minimal_activitypub.exceptions import GoneError
from minimal_activitypub.exceptions import NetworkError
from minimal_activitypub.exceptions import NotFoundError
from minimal_activitypub.exceptions import RatelimitError
from minimal_activitypub.exceptions import ServerError
from minimal_activitypub.exceptions import UnauthorizedError
from minimal_activitypub.exceptions import UnprocessedError
from minimal_activitypub.types import ActivityPubClass
from minimal_activitypub.types import Status

__display_name__: Final[str] = "Minimal-ActivityPub"
__version__: Final[str] = version(str(__package__))

USER_AGENT: Final[str] = f"{__display_name__}_v{__version__}_Python_{sys.version.split()[0]}"


class Visibility(str, Enum):
    """Enumerating possible Visibility values for statuses."""

    PUBLIC = "public"
    UNLISTED = "unlisted"
    PRIVATE = "private"
    DIRECT = "direct"


class SearchType(str, Enum):
    """Enumerating possible type values for status searches."""

    ACCOUNTS = "accounts"
    HASHTAGS = "hashtags"
    STATUSES = "statuses"


__all__ = [  # noqa: RUF022
    "ActivityPubClass",
    "ActivityPubError",
    "ApiError",
    "ClientError",
    "ConflictError",
    "__display_name__",
    "ForbiddenError",
    "GoneError",
    "INSTANCE_TYPE_MASTODON",
    "INSTANCE_TYPE_PLEROMA",
    "INSTANCE_TYPE_TAKAHE",
    "NetworkError",
    "NotFoundError",
    "RatelimitError",
    "SearchType",
    "ServerError",
    "Status",
    "UnauthorizedError",
    "UnprocessedError",
    "USER_AGENT",
    "__version__",
    "Visibility",
]
