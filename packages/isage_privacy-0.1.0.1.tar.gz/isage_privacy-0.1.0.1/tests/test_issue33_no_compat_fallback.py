from __future__ import annotations

from pathlib import Path

import pytest


def _privacy_root() -> Path:
    return Path(__file__).resolve().parents[1] / "src" / "sage_libs" / "sage_privacy"


def test_core_modules_have_no_importerror_fallback() -> None:
    targets = [
        _privacy_root() / "dp" / "gaussian.py",
        _privacy_root() / "dp" / "laplace.py",
        _privacy_root() / "unlearning" / "gradient_ascent.py",
        _privacy_root() / "unlearning" / "fisher_forgetting.py",
        _privacy_root() / "_register.py",
    ]

    for file_path in targets:
        source = file_path.read_text(encoding="utf-8")
        assert "_HAS_SAGE" not in source

    assert "BaseUnlearner = object" not in (
        (_privacy_root() / "unlearning" / "gradient_ascent.py").read_text(encoding="utf-8")
    )
    assert "BaseUnlearner = object" not in (
        (_privacy_root() / "unlearning" / "fisher_forgetting.py").read_text(encoding="utf-8")
    )
    assert "BasePrivacyMechanism = object" not in (
        (_privacy_root() / "dp" / "gaussian.py").read_text(encoding="utf-8")
    )
    assert "BasePrivacyMechanism = object" not in (
        (_privacy_root() / "dp" / "laplace.py").read_text(encoding="utf-8")
    )
    assert "except ImportError" not in (
        (_privacy_root() / "_register.py").read_text(encoding="utf-8")
    )


def test_unlearning_verification_requires_original_model() -> None:
    from sage_libs.sage_privacy.unlearning import (
        FisherForgettingUnlearner,
        GradientAscentUnlearner,
    )

    for unlearner in [GradientAscentUnlearner(), FisherForgettingUnlearner()]:
        with pytest.raises(ValueError, match="original_model is required"):
            unlearner.verify_unlearning(model=[1, 2, 3], forget_data=[1, 2, 3], original_model=None)
