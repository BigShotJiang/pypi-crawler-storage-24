"""Tests for package structure and imports."""


class TestPackageImports:
    """Test that all package imports work correctly."""

    def test_import_package(self):
        """Test main package import."""
        import sage_libs.sage_privacy as sage_privacy

        assert hasattr(sage_privacy, "__version__")
        assert hasattr(sage_privacy, "__author__")
        assert hasattr(sage_privacy, "register_to_sage")

    def test_import_version(self):
        """Test version format."""
        from sage_libs.sage_privacy import __version__

        parts = __version__.split(".")
        assert len(parts) == 4
        assert all(p.isdigit() for p in parts)

    def test_import_unlearning(self):
        """Test unlearning imports from subpackage."""
        from sage_libs.sage_privacy.unlearning import (
            FisherForgettingUnlearner,
            GradientAscentUnlearner,
        )

        assert GradientAscentUnlearner is not None
        assert FisherForgettingUnlearner is not None

    def test_import_dp(self):
        """Test DP mechanism imports from subpackage."""
        from sage_libs.sage_privacy.dp import GaussianMechanism, LaplaceMechanism

        assert GaussianMechanism is not None
        assert LaplaceMechanism is not None

    def test_import_from_submodules(self):
        """Test imports from submodules."""
        from sage_libs.sage_privacy.dp import GaussianMechanism, LaplaceMechanism
        from sage_libs.sage_privacy.unlearning import GradientAscentUnlearner
        from sage_libs.sage_privacy.unlearning.gradient_ascent import GradientAscentConfig

        assert GradientAscentUnlearner is not None
        assert GradientAscentConfig is not None
        assert GaussianMechanism is not None
        assert LaplaceMechanism is not None

    def test_all_exports(self):
        """Test strict root exports."""
        import sage_libs.sage_privacy as sage_privacy

        expected = ["__version__", "__author__", "__email__", "register_to_sage"]
        for item in expected:
            assert item in sage_privacy.__all__

        assert "GradientAscentUnlearner" not in sage_privacy.__all__
        assert "FisherForgettingUnlearner" not in sage_privacy.__all__
        assert "GaussianMechanism" not in sage_privacy.__all__
        assert "LaplaceMechanism" not in sage_privacy.__all__


class TestRegistration:
    """Test explicit SAGE registration API."""

    def test_registration_callable(self):
        """Test explicit registration function export."""
        from sage_libs.sage_privacy import register_to_sage

        assert callable(register_to_sage)
