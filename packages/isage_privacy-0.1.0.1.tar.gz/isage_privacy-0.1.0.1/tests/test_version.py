"""Test version information."""


def test_version():
    from sage_libs.sage_privacy import __version__
    from sage_libs.sage_privacy._version import __version__ as source_version

    assert __version__ == source_version
    parts = __version__.split(".")
    assert len(parts) == 4
    assert all(part.isdigit() for part in parts)
