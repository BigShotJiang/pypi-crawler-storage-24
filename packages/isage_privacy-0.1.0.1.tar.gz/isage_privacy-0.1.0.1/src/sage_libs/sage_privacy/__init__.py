"""Compatibility shim — use ``sage_privacy`` directly.

Deprecated: this path is kept for backward compatibility only.
"""

from sage_privacy import __author__, __email__, __version__, register_to_sage  # noqa: F401
