"""SAGE Privacy package root.

The root package only exposes stable metadata and explicit registration entrypoints.
Research implementations stay in subpackages:

- ``sage_libs.sage_privacy.dp``
- ``sage_libs.sage_privacy.unlearning``
"""

from ._version import __author__, __email__, __version__
from ._register import register_to_sage

__all__ = [
    "__version__",
    "__author__",
    "__email__",
    "register_to_sage",
]
