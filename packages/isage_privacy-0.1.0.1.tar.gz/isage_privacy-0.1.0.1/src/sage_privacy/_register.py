"""Registration entrypoint for SAGE privacy interface."""

from .dp import GaussianMechanism, LaplaceMechanism
from .unlearning import FisherForgettingUnlearner, GradientAscentUnlearner


def register_to_sage() -> None:
    """Register privacy implementations into ``sage.libs.privacy.interface``."""
    from sage.libs.privacy.interface import register_mechanism, register_unlearner

    register_unlearner("gradient_ascent", GradientAscentUnlearner)
    register_unlearner("fisher_forgetting", FisherForgettingUnlearner)
    register_mechanism("gaussian", GaussianMechanism)
    register_mechanism("laplace", LaplaceMechanism)


__all__ = ["register_to_sage"]
