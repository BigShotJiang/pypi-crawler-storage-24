# sage-privacy

Privacy protection algorithms for SAGE, including differential privacy and machine unlearning.

**PyPI Package**: `isage-privacy`

## Boundary

- Root package (`sage_libs.sage_privacy`) exposes only stable metadata and explicit registration API.
- Research implementations are accessed from subpackages:
	- `sage_libs.sage_privacy.dp`
	- `sage_libs.sage_privacy.unlearning`
- No root-level re-export of concrete research implementations.

## Installation

```bash
pip install isage-privacy
```

## Usage

```python
from sage_libs.sage_privacy import register_to_sage
from sage_libs.sage_privacy.dp import GaussianMechanism
from sage_libs.sage_privacy.unlearning import GradientAscentUnlearner

register_to_sage()

mechanism = GaussianMechanism(epsilon=1.0)
unlearner = GradientAscentUnlearner()
```

## License

MIT
