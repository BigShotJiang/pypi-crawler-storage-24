"""Tests for GitHub MCP server client."""

import pytest
from unittest.mock import AsyncMock, patch
from github_mcp_server.client import (
    GitHubClient,
    GitHubAuthError,
    GitHubNotFoundError,
    GitHubRateLimitError,
)


@pytest.fixture
def client():
    return GitHubClient(token="ghp_test-token")


class TestClientInit:
    def test_requires_token(self):
        with pytest.raises(GitHubAuthError):
            GitHubClient(token="")

    def test_creates_with_valid_token(self):
        c = GitHubClient(token="ghp_valid-token")
        assert c.token == "ghp_valid-token"


class TestListRepos:
    @pytest.mark.asyncio
    async def test_list_repos_success(self, client, mock_github_response):
        resp = mock_github_response(data=[
            {
                "full_name": "octocat/Hello-World",
                "description": "A test repo",
                "language": "Python",
                "stargazers_count": 100,
                "forks_count": 50,
                "private": False,
                "html_url": "https://github.com/octocat/Hello-World",
                "updated_at": "2024-01-01T00:00:00Z",
            }
        ])
        with patch.object(client._client, "request", return_value=resp):
            result = await client.list_repos()
            assert len(result) == 1
            assert result[0]["full_name"] == "octocat/Hello-World"
            assert result[0]["stars"] == 100


class TestGetRepo:
    @pytest.mark.asyncio
    async def test_get_repo_success(self, client, mock_github_response):
        resp = mock_github_response(data={
            "full_name": "octocat/Hello-World",
            "description": "A test repo",
            "language": "Python",
            "stargazers_count": 100,
            "forks_count": 50,
            "open_issues_count": 5,
            "private": False,
            "default_branch": "main",
            "html_url": "https://github.com/octocat/Hello-World",
            "created_at": "2020-01-01",
            "updated_at": "2024-01-01",
            "topics": ["test"],
        })
        with patch.object(client._client, "request", return_value=resp):
            result = await client.get_repo("octocat", "Hello-World")
            assert result["full_name"] == "octocat/Hello-World"
            assert result["open_issues"] == 5


class TestErrorHandling:
    @pytest.mark.asyncio
    async def test_auth_error(self, client, mock_github_response):
        resp = mock_github_response(
            status_code=401,
            data={"message": "Bad credentials"},
        )
        with patch.object(client._client, "request", return_value=resp):
            with pytest.raises(GitHubAuthError):
                await client.get_user()

    @pytest.mark.asyncio
    async def test_not_found_error(self, client, mock_github_response):
        resp = mock_github_response(
            status_code=404,
            data={"message": "Not Found"},
        )
        with patch.object(client._client, "request", return_value=resp):
            with pytest.raises(GitHubNotFoundError):
                await client.get_repo("ghost", "nonexistent")

    @pytest.mark.asyncio
    async def test_rate_limit_retry(self, client, mock_github_response):
        resp_limited = mock_github_response(status_code=429, data={})
        resp_limited.headers = {"retry-after": "0"}
        resp_ok = mock_github_response(data={
            "login": "octocat",
            "name": "Octocat",
            "html_url": "https://github.com/octocat",
        })
        with patch.object(
            client._client, "request", side_effect=[resp_limited, resp_ok]
        ):
            result = await client.get_user("octocat")
            assert result["login"] == "octocat"


class TestConfigValidation:
    def test_valid_config(self, mock_config):
        errors = mock_config.validate()
        assert len(errors) == 0

    def test_missing_token(self):
        import os
        from github_mcp_server.config import GitHubConfig
        with patch.dict(os.environ, {}, clear=True):
            config = GitHubConfig()
            errors = config.validate()
            assert any("GITHUB_TOKEN" in e for e in errors)
