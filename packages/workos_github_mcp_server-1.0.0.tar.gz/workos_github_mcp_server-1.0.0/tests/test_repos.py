"""Tests for GitHub MCP repo tools — verify tools are registered correctly."""

import pytest
import asyncio
from fastmcp import FastMCP
from github_mcp_server.tools.repos import register_repo_tools
from github_mcp_server.tools.issues import register_issue_tools
from github_mcp_server.tools.pulls import register_pull_tools
from github_mcp_server.tools.commits import register_commit_tools
from github_mcp_server.tools.gists import register_gist_tools
from github_mcp_server.tools.users import register_user_tools


@pytest.fixture
def app_with_tools(mock_config):
    app = FastMCP(name="test", version="0.1.0")
    register_repo_tools(app, mock_config)
    register_issue_tools(app, mock_config)
    register_pull_tools(app, mock_config)
    register_commit_tools(app, mock_config)
    register_gist_tools(app, mock_config)
    register_user_tools(app, mock_config)
    return app


class TestToolsRegistered:
    def test_repo_tools_registered(self, app_with_tools):
        """Verify all repo tools are registered."""
        tools = asyncio.run(app_with_tools.list_tools())
        tool_names = [t.name for t in tools]
        assert "github_list_repos" in tool_names
        assert "github_get_repo" in tool_names
        assert "github_search_repos" in tool_names

    def test_issue_tools_registered(self, app_with_tools):
        """Verify all issue tools are registered."""
        tools = asyncio.run(app_with_tools.list_tools())
        tool_names = [t.name for t in tools]
        assert "github_list_issues" in tool_names
        assert "github_create_issue" in tool_names
        assert "github_get_issue" in tool_names
        assert "github_update_issue" in tool_names
        assert "github_search_issues" in tool_names

    def test_pull_tools_registered(self, app_with_tools):
        """Verify all PR tools are registered."""
        tools = asyncio.run(app_with_tools.list_tools())
        tool_names = [t.name for t in tools]
        assert "github_list_pull_requests" in tool_names
        assert "github_get_pull_request" in tool_names
        assert "github_create_pull_request" in tool_names

    def test_commit_tools_registered(self, app_with_tools):
        """Verify commit tools are registered."""
        tools = asyncio.run(app_with_tools.list_tools())
        tool_names = [t.name for t in tools]
        assert "github_list_commits" in tool_names

    def test_gist_tools_registered(self, app_with_tools):
        """Verify gist tools are registered."""
        tools = asyncio.run(app_with_tools.list_tools())
        tool_names = [t.name for t in tools]
        assert "github_list_gists" in tool_names
        assert "github_create_gist" in tool_names

    def test_user_tools_registered(self, app_with_tools):
        """Verify user tools are registered."""
        tools = asyncio.run(app_with_tools.list_tools())
        tool_names = [t.name for t in tools]
        assert "github_get_user" in tool_names

    def test_total_tool_count(self, app_with_tools):
        """Verify the total number of registered tools."""
        tools = asyncio.run(app_with_tools.list_tools())
        assert len(tools) == 15
