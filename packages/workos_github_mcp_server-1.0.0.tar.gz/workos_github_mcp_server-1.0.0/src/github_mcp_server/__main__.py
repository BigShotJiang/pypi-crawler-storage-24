"""Allow running as: python -m github_mcp_server"""
from github_mcp_server import main

main()
