"""
GitHub MCP Server — FastMCP instance with all tools registered.

This is the core server module. Tools are organized by domain
in the tools/ subpackage and registered here.
"""

import logging
import sys

from fastmcp import FastMCP

from github_mcp_server.config import GitHubConfig
from github_mcp_server.tools.repos import register_repo_tools
from github_mcp_server.tools.issues import register_issue_tools
from github_mcp_server.tools.pulls import register_pull_tools
from github_mcp_server.tools.commits import register_commit_tools
from github_mcp_server.tools.gists import register_gist_tools
from github_mcp_server.tools.users import register_user_tools

# Ensure logging goes to stderr (required for stdio MCP transport)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    stream=sys.stderr,
)

logger = logging.getLogger("github_mcp_server")


def create_server() -> FastMCP:
    """Create and configure the GitHub MCP server.

    Validates environment configuration on startup and registers
    all GitHub tools with the FastMCP instance.
    """
    # Validate config on startup
    config = GitHubConfig()
    config.validate_or_exit()

    app = FastMCP(
        name="github-mcp-server",
        instructions=(
            "MCP server for GitHub operations. "
            "Manage repositories, issues, pull requests, commits, "
            "gists, search code, and look up user profiles."
        ),
        version="1.0.0",
    )

    # Register all tool groups
    register_repo_tools(app, config)
    register_issue_tools(app, config)
    register_pull_tools(app, config)
    register_commit_tools(app, config)
    register_gist_tools(app, config)
    register_user_tools(app, config)

    logger.info("GitHub MCP server configured with all tool groups")
    return app
