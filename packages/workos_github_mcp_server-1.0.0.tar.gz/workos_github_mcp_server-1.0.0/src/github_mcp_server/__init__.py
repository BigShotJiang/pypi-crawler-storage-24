"""
GitHub MCP Server — Model Context Protocol server for GitHub operations.

An independent, generalized MCP server that can connect to any AI agent
supporting the Model Context Protocol. Not tied to any specific project.

Quick start:
    pip install workos-github-mcp-server
    GITHUB_TOKEN=ghp_... github-mcp-server

Or run as a module:
    python -m github_mcp_server
"""

__version__ = "1.0.0"

from github_mcp_server.server import create_server


def main():
    """Entry point for the github-mcp-server CLI command."""
    server = create_server()
    server.run()


__all__ = ["main", "create_server", "__version__"]
