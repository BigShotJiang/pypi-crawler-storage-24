"""GitHub pull request tools — list, get, create PRs."""

from github_mcp_server.client import GitHubClient, GitHubAPIError
from github_mcp_server.config import GitHubConfig


def register_pull_tools(app, config: GitHubConfig):
    """Register pull request tools with the FastMCP app."""

    @app.tool()
    async def github_list_pull_requests(
        owner: str,
        repo: str,
        state: str = "open",
        per_page: int = 30,
    ) -> dict:
        """List pull requests in a GitHub repository.

        Args:
            owner: Repository owner (e.g., 'octocat')
            repo: Repository name (e.g., 'Hello-World')
            state: Filter by state — 'open', 'closed', 'all' (default: 'open')
            per_page: Number of results (1-100, default: 30)
        """
        per_page = min(max(per_page, 1), 100)
        try:
            async with GitHubClient(token=config.token) as client:
                prs = await client.list_prs(
                    owner=owner, repo=repo, state=state, per_page=per_page,
                )
                return {"success": True, "count": len(prs), "pull_requests": prs}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def github_get_pull_request(
        owner: str, repo: str, pr_number: int
    ) -> dict:
        """Get details of a specific pull request.

        Args:
            owner: Repository owner (e.g., 'octocat')
            repo: Repository name (e.g., 'Hello-World')
            pr_number: Pull request number (e.g., 42)
        """
        try:
            async with GitHubClient(token=config.token) as client:
                result = await client.get_pr(
                    owner=owner, repo=repo, pr_number=pr_number,
                )
                return {"success": True, "pull_request": result}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def github_create_pull_request(
        owner: str,
        repo: str,
        title: str,
        head: str,
        base: str,
        body: str = "",
        draft: bool = False,
    ) -> dict:
        """Create a new pull request in a GitHub repository.

        Args:
            owner: Repository owner (e.g., 'octocat')
            repo: Repository name (e.g., 'Hello-World')
            title: PR title
            head: Branch containing changes (e.g., 'feature-branch')
            base: Branch to merge into (e.g., 'main')
            body: PR description (supports GitHub Markdown)
            draft: Create as draft PR (default: false)
        """
        try:
            async with GitHubClient(token=config.token) as client:
                result = await client.create_pr(
                    owner=owner, repo=repo, title=title,
                    head=head, base=base, body=body, draft=draft,
                )
                return {"success": True, **result}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}
