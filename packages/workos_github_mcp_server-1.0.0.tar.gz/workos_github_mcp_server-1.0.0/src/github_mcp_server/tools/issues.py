"""GitHub issue tools — list, create, get, update, search issues."""

from typing import Optional

from github_mcp_server.client import GitHubClient, GitHubAPIError
from github_mcp_server.config import GitHubConfig


def register_issue_tools(app, config: GitHubConfig):
    """Register issue tools with the FastMCP app."""

    @app.tool()
    async def github_list_issues(
        owner: str,
        repo: str,
        state: str = "open",
        per_page: int = 30,
    ) -> dict:
        """List issues in a GitHub repository.

        Args:
            owner: Repository owner (e.g., 'octocat')
            repo: Repository name (e.g., 'Hello-World')
            state: Filter by state — 'open', 'closed', 'all' (default: 'open')
            per_page: Number of results (1-100, default: 30)
        """
        per_page = min(max(per_page, 1), 100)
        try:
            async with GitHubClient(token=config.token) as client:
                issues = await client.list_issues(
                    owner=owner, repo=repo, state=state, per_page=per_page,
                )
                return {"success": True, "count": len(issues), "issues": issues}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def github_create_issue(
        owner: str,
        repo: str,
        title: str,
        body: str = "",
        labels: Optional[list[str]] = None,
        assignees: Optional[list[str]] = None,
    ) -> dict:
        """Create a new issue in a GitHub repository.

        Args:
            owner: Repository owner (e.g., 'octocat')
            repo: Repository name (e.g., 'Hello-World')
            title: Issue title
            body: Issue body (supports GitHub Markdown)
            labels: List of label names to apply (e.g., ['bug', 'urgent'])
            assignees: List of GitHub usernames to assign
        """
        try:
            async with GitHubClient(token=config.token) as client:
                result = await client.create_issue(
                    owner=owner, repo=repo, title=title,
                    body=body, labels=labels, assignees=assignees,
                )
                return {"success": True, **result}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def github_get_issue(
        owner: str, repo: str, issue_number: int
    ) -> dict:
        """Get details of a specific issue.

        Args:
            owner: Repository owner (e.g., 'octocat')
            repo: Repository name (e.g., 'Hello-World')
            issue_number: Issue number (e.g., 42)
        """
        try:
            async with GitHubClient(token=config.token) as client:
                result = await client.get_issue(
                    owner=owner, repo=repo, issue_number=issue_number,
                )
                return {"success": True, "issue": result}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def github_update_issue(
        owner: str,
        repo: str,
        issue_number: int,
        title: Optional[str] = None,
        body: Optional[str] = None,
        state: Optional[str] = None,
        labels: Optional[list[str]] = None,
        assignees: Optional[list[str]] = None,
    ) -> dict:
        """Update an existing issue in a GitHub repository.

        Args:
            owner: Repository owner (e.g., 'octocat')
            repo: Repository name (e.g., 'Hello-World')
            issue_number: Issue number to update
            title: New title (omit to keep current)
            body: New body (omit to keep current)
            state: New state — 'open' or 'closed' (omit to keep current)
            labels: Replace labels (omit to keep current)
            assignees: Replace assignees (omit to keep current)
        """
        try:
            async with GitHubClient(token=config.token) as client:
                result = await client.update_issue(
                    owner=owner, repo=repo, issue_number=issue_number,
                    title=title, body=body, state=state,
                    labels=labels, assignees=assignees,
                )
                return {"success": True, **result}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def github_search_issues(
        query: str, sort: str = "created", per_page: int = 10
    ) -> dict:
        """Search issues and pull requests across GitHub.

        Args:
            query: Search query (e.g., 'bug repo:octocat/Hello-World state:open')
            sort: Sort by — 'created', 'updated', 'comments' (default: 'created')
            per_page: Number of results (1-100, default: 10)
        """
        per_page = min(max(per_page, 1), 100)
        try:
            async with GitHubClient(token=config.token) as client:
                issues = await client.search_issues(
                    query=query, sort=sort, per_page=per_page,
                )
                return {"success": True, "count": len(issues), "results": issues}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}
