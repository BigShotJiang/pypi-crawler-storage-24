"""GitHub commit tools — list commits."""

from typing import Optional

from github_mcp_server.client import GitHubClient, GitHubAPIError
from github_mcp_server.config import GitHubConfig


def register_commit_tools(app, config: GitHubConfig):
    """Register commit tools with the FastMCP app."""

    @app.tool()
    async def github_list_commits(
        owner: str,
        repo: str,
        sha: Optional[str] = None,
        per_page: int = 30,
    ) -> dict:
        """List recent commits in a GitHub repository.

        Args:
            owner: Repository owner (e.g., 'octocat')
            repo: Repository name (e.g., 'Hello-World')
            sha: Branch name or commit SHA to list from (default: repo's default branch)
            per_page: Number of results (1-100, default: 30)
        """
        per_page = min(max(per_page, 1), 100)
        try:
            async with GitHubClient(token=config.token) as client:
                commits = await client.list_commits(
                    owner=owner, repo=repo, sha=sha, per_page=per_page,
                )
                return {"success": True, "count": len(commits), "commits": commits}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}
