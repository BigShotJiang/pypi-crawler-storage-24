"""GitHub MCP Server tools — organized by domain."""
