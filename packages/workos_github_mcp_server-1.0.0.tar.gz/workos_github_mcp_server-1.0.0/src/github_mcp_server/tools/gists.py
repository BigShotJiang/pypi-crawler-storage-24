"""GitHub gist tools — list and create gists."""

from github_mcp_server.client import GitHubClient, GitHubAPIError
from github_mcp_server.config import GitHubConfig


def register_gist_tools(app, config: GitHubConfig):
    """Register gist tools with the FastMCP app."""

    @app.tool()
    async def github_list_gists(per_page: int = 10) -> dict:
        """List gists for the authenticated GitHub user.

        Args:
            per_page: Number of results (1-100, default: 10)
        """
        per_page = min(max(per_page, 1), 100)
        try:
            async with GitHubClient(token=config.token) as client:
                gists = await client.list_gists(per_page=per_page)
                return {"success": True, "count": len(gists), "gists": gists}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def github_create_gist(
        files: dict[str, str],
        description: str = "",
        public: bool = False,
    ) -> dict:
        """Create a new GitHub gist.

        Args:
            files: Map of filename to content (e.g., {'hello.py': 'print("hi")'})
            description: Gist description
            public: Whether the gist is public (default: false/secret)
        """
        try:
            async with GitHubClient(token=config.token) as client:
                result = await client.create_gist(
                    files=files, description=description, public=public,
                )
                return {"success": True, **result}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}
