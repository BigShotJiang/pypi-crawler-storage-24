"""GitHub user tools — look up user profiles."""

from typing import Optional

from github_mcp_server.client import GitHubClient, GitHubAPIError
from github_mcp_server.config import GitHubConfig


def register_user_tools(app, config: GitHubConfig):
    """Register user tools with the FastMCP app."""

    @app.tool()
    async def github_get_user(username: Optional[str] = None) -> dict:
        """Get a GitHub user's profile information.

        Args:
            username: GitHub username (e.g., 'octocat'). If omitted, returns your own profile.

        Returns profile with name, bio, company, location, public repos, and follower counts.
        """
        try:
            async with GitHubClient(token=config.token) as client:
                profile = await client.get_user(username=username)
                return {"success": True, "profile": profile}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}
