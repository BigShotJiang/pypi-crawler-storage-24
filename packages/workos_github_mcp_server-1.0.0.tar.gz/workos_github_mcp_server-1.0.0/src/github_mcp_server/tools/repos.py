"""GitHub repository tools — list, get details, search repos."""

from typing import Optional

from github_mcp_server.client import GitHubClient, GitHubAPIError
from github_mcp_server.config import GitHubConfig


def register_repo_tools(app, config: GitHubConfig):
    """Register repository tools with the FastMCP app."""

    @app.tool()
    async def github_list_repos(
        owner: Optional[str] = None,
        repo_type: str = "owner",
        sort: str = "updated",
        per_page: int = 30,
    ) -> dict:
        """List GitHub repositories for the authenticated user or a specific owner.

        Args:
            owner: GitHub username or org. If omitted, lists your own repos.
            repo_type: Filter type — 'all', 'owner', 'member' (default: 'owner')
            sort: Sort by — 'created', 'updated', 'pushed', 'full_name' (default: 'updated')
            per_page: Number of results (1-100, default: 30)
        """
        per_page = min(max(per_page, 1), 100)
        try:
            async with GitHubClient(token=config.token) as client:
                repos = await client.list_repos(
                    owner=owner, repo_type=repo_type, sort=sort, per_page=per_page,
                )
                return {"success": True, "count": len(repos), "repos": repos}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def github_get_repo(owner: str, repo: str) -> dict:
        """Get detailed information about a GitHub repository.

        Args:
            owner: Repository owner (user or org, e.g., 'octocat')
            repo: Repository name (e.g., 'Hello-World')
        """
        try:
            async with GitHubClient(token=config.token) as client:
                result = await client.get_repo(owner=owner, repo=repo)
                return {"success": True, "repo": result}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def github_search_repos(
        query: str, sort: str = "stars", per_page: int = 10
    ) -> dict:
        """Search for repositories on GitHub.

        Args:
            query: Search query (e.g., 'machine learning language:python stars:>1000')
            sort: Sort by — 'stars', 'forks', 'updated', 'help-wanted-issues' (default: 'stars')
            per_page: Number of results (1-100, default: 10)
        """
        per_page = min(max(per_page, 1), 100)
        try:
            async with GitHubClient(token=config.token) as client:
                repos = await client.search_repos(
                    query=query, sort=sort, per_page=per_page,
                )
                return {"success": True, "count": len(repos), "repos": repos}
        except GitHubAPIError as e:
            return {"success": False, "error": e.message}
