"""
Environment variable validation for GitHub MCP Server.

Required environment variables:
    GITHUB_TOKEN: GitHub Personal Access Token (ghp_... or github_pat_...)

Optional:
    GITHUB_LOG_LEVEL: Logging level (default: INFO)
"""

import os
import sys
import logging

logger = logging.getLogger("github_mcp_server.config")


class GitHubConfig:
    """Validated GitHub configuration from environment variables."""

    def __init__(self):
        self.token: str = ""
        self.log_level: str = "INFO"
        self._load()

    def _load(self):
        self.token = os.environ.get("GITHUB_TOKEN", "")
        self.log_level = os.environ.get("GITHUB_LOG_LEVEL", "INFO")

    def validate(self) -> list[str]:
        """Validate configuration. Returns list of error messages (empty = valid)."""
        errors = []

        if not self.token:
            errors.append(
                "GITHUB_TOKEN is required. "
                "Create one at https://github.com/settings/tokens"
            )

        return errors

    def validate_or_exit(self):
        """Validate configuration, exit with clear error if invalid."""
        errors = self.validate()
        if errors:
            print("GitHub MCP Server configuration errors:", file=sys.stderr)
            for err in errors:
                print(f"  ✗ {err}", file=sys.stderr)
            print(
                "\nSet the required environment variables and try again.",
                file=sys.stderr,
            )
            sys.exit(1)
        logger.info("GitHub configuration validated successfully")
