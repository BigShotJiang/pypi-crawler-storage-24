"""Search service functions — the public API of icv-search."""

from icv_search.auto_index import skip_index_update
from icv_search.cache import ICVSearchCache
from icv_search.middleware import get_current_tenant_id
from icv_search.services.documents import (
    index_documents,
    index_model_instances,
    reindex_all,
    reindex_zero_downtime,
    remove_documents,
)
from icv_search.services.indexing import (
    create_index,
    delete_index,
    get_index_settings,
    get_index_stats,
    get_model_search_settings,
    get_stop_words,
    get_synonyms,
    get_typo_tolerance,
    reset_stop_words,
    reset_synonyms,
    update_index_settings,
    update_stop_words,
    update_synonyms,
    update_typo_tolerance,
)
from icv_search.services.analytics import (
    clear_query_aggregates,
    clear_query_logs,
    get_popular_queries,
    get_query_trend,
    get_search_stats,
    get_zero_result_queries,
)
from icv_search.services.search import get_task, multi_search, search
from icv_search.types import IndexStats, SearchResult, TaskResult

__all__ = [
    # Index management
    "create_index",
    "delete_index",
    "update_index_settings",
    "get_index_settings",
    "get_index_stats",
    "get_model_search_settings",
    # Synonym management
    "get_synonyms",
    "update_synonyms",
    "reset_synonyms",
    # Stop-word management
    "get_stop_words",
    "update_stop_words",
    "reset_stop_words",
    # Typo tolerance
    "get_typo_tolerance",
    "update_typo_tolerance",
    # Document operations
    "index_documents",
    "remove_documents",
    "index_model_instances",
    "reindex_all",
    "reindex_zero_downtime",
    # Search
    "search",
    "multi_search",
    "get_task",
    # Utilities
    "skip_index_update",
    # Tenant context
    "get_current_tenant_id",
    # Cache
    "ICVSearchCache",
    # Normalised response types
    "IndexStats",
    "SearchResult",
    "TaskResult",
    # Analytics
    "get_popular_queries",
    "get_zero_result_queries",
    "get_search_stats",
    "clear_query_logs",
    "get_query_trend",
    "clear_query_aggregates",
]
