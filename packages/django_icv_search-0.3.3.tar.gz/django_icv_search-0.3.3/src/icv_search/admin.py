"""Admin registrations for icv-search models."""

from django.contrib import admin
from django.utils.translation import gettext_lazy as _

from icv_search.models import IndexSyncLog, SearchIndex, SearchQueryAggregate, SearchQueryLog


@admin.register(SearchIndex)
class SearchIndexAdmin(admin.ModelAdmin):
    list_display = [
        "name",
        "tenant_id",
        "engine_uid",
        "document_count",
        "is_synced",
        "is_active",
        "last_synced_at",
    ]
    list_filter = ["is_synced", "is_active"]
    search_fields = ["name", "tenant_id", "engine_uid"]
    readonly_fields = [
        "engine_uid",
        "document_count",
        "is_synced",
        "last_synced_at",
        "created_at",
        "updated_at",
    ]
    fieldsets = [
        (None, {"fields": ["name", "tenant_id", "engine_uid", "primary_key_field", "is_active"]}),
        ("Settings", {"fields": ["settings"], "classes": ["collapse"]}),
        ("Sync Status", {"fields": ["is_synced", "last_synced_at", "document_count"]}),
        ("Timestamps", {"fields": ["created_at", "updated_at"]}),
    ]


@admin.register(IndexSyncLog)
class IndexSyncLogAdmin(admin.ModelAdmin):
    list_display = ["index", "action", "status", "task_uid", "created_at", "completed_at"]
    list_filter = ["action", "status"]
    search_fields = ["index__name", "task_uid", "detail"]
    readonly_fields = [
        "index",
        "action",
        "status",
        "detail",
        "task_uid",
        "created_at",
        "completed_at",
    ]
    list_select_related = ["index"]


@admin.register(SearchQueryLog)
class SearchQueryLogAdmin(admin.ModelAdmin):
    list_display = [
        "query",
        "index_name",
        "hit_count",
        "is_zero_result",
        "processing_time_ms",
        "created_at",
    ]
    list_filter = ["is_zero_result", "index_name"]
    search_fields = ["query"]
    readonly_fields = [
        "index_name",
        "query",
        "filters",
        "sort",
        "hit_count",
        "processing_time_ms",
        "user",
        "tenant_id",
        "is_zero_result",
        "metadata",
        "created_at",
        "updated_at",
    ]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(SearchQueryAggregate)
class SearchQueryAggregateAdmin(admin.ModelAdmin):
    list_display = [
        "query",
        "index_name",
        "date",
        "tenant_id",
        "total_count",
        "zero_result_count",
        "get_avg_processing_time_ms",
    ]
    list_filter = ["index_name", "date"]
    search_fields = ["query"]
    date_hierarchy = "date"
    readonly_fields = [
        "index_name",
        "query",
        "date",
        "tenant_id",
        "total_count",
        "zero_result_count",
        "total_processing_time_ms",
        "created_at",
        "updated_at",
    ]

    @admin.display(description=_("avg processing time (ms)"))
    def get_avg_processing_time_ms(self, obj: SearchQueryAggregate) -> float:
        return obj.avg_processing_time_ms

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
