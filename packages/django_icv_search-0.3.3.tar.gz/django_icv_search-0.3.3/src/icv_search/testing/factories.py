"""Factory-boy factories for icv-search models."""

import datetime

import factory

from icv_search.models import IndexSyncLog, SearchIndex, SearchQueryAggregate, SearchQueryLog


class SearchIndexFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = SearchIndex

    name = factory.Sequence(lambda n: f"test-index-{n}")
    tenant_id = ""
    primary_key_field = "id"
    settings = factory.LazyFunction(dict)
    is_active = True


class IndexSyncLogFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = IndexSyncLog

    index = factory.SubFactory(SearchIndexFactory)
    action = "created"
    status = "success"


class SearchQueryLogFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = SearchQueryLog

    index_name = factory.Sequence(lambda n: f"test-index-{n}")
    query = factory.Sequence(lambda n: f"test query {n}")
    filters = factory.LazyFunction(dict)
    sort = factory.LazyFunction(list)
    hit_count = 5
    processing_time_ms = 10
    user = None
    tenant_id = ""
    is_zero_result = False
    metadata = factory.LazyFunction(dict)


class SearchQueryAggregateFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = SearchQueryAggregate

    index_name = factory.Sequence(lambda n: f"test-index-{n}")
    query = factory.Sequence(lambda n: f"test query {n}")
    date = factory.LazyFunction(datetime.date.today)
    tenant_id = ""
    total_count = 10
    zero_result_count = 2
    total_processing_time_ms = 150
