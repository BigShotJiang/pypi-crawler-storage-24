"""Frame source elements for reading gravitational wave data."""

from sgn_gwframe.sources.frame import GWFrameSource
from sgn_gwframe.sources.framewatch import GWFrameWatchSource

__all__ = ["GWFrameSource", "GWFrameWatchSource"]
