"""Utility functions for gravitational wave frame I/O."""

# Copyright (C) 2009-2013  Kipp Cannon, Chad Hanna, Drew Keppel
# Copyright (C) 2024 Becca Ewing, Yun-Jing Huang

from __future__ import annotations

import os


def from_T050017(url):  # noqa: N802
    """
    Parse a URL in the style of T050017-00.
    """
    filename, _ = os.path.splitext(os.path.basename(url))
    obs, desc, start, dur = filename.split("-")
    return obs, desc, int(start), int(dur)
