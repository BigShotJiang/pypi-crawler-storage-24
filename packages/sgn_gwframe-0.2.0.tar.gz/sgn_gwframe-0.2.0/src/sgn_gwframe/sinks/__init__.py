"""Frame sink elements for writing gravitational wave data."""

from sgn_gwframe.sinks.frame import GWFrameSink

__all__ = ["GWFrameSink"]
