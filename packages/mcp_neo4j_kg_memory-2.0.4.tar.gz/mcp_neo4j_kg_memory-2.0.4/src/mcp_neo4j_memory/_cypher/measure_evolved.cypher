MATCH (old:Envisioning {name: $target})
MATCH (g:Genesis)-[:OPENING]->(old)
CREATE (new:Envisioning {name: $new_name, description: $new_description, t_created: datetime()})
CREATE (new)-[m:MEASUREMENT]->(old)
SET m.t_created = datetime(),
    m.measurement_type = 'evolved'
CREATE (g)-[o:OPENING]->(new)
SET o.t_created = datetime()
RETURN new.name AS new_envisioning, old.name AS old_envisioning,
       g.name AS genesis, m.measurement_type AS measurement_type,
       m.t_created AS measured_at
