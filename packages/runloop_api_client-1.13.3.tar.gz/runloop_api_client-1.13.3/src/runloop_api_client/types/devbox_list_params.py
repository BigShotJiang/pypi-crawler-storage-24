# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, TypedDict

__all__ = ["DevboxListParams"]


class DevboxListParams(TypedDict, total=False):
    include_total_count: bool
    """If true (default), includes total_count in the response.

    Set to false to skip the count query for better performance on large datasets.
    """

    limit: int
    """The limit of items to return. Default is 20. Max is 5000."""

    starting_after: str
    """Load the next page of data starting after the item with the given ID."""

    status: Literal[
        "provisioning", "initializing", "running", "suspending", "suspended", "resuming", "failure", "shutdown"
    ]
    """Filter by status"""
