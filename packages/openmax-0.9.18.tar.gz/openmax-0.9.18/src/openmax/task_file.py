"""File-based context exchange between lead agent and sub-agents."""

from __future__ import annotations

from pathlib import Path

_OPENMAX_DIR = ".openmax"
_BRIEFS_DIR = "briefs"
_REPORTS_DIR = "reports"
_SHARED_DIR = "shared"
_CHECKPOINTS_DIR = "checkpoints"


def _task_dir(cwd: str, subdir: str) -> Path:
    return Path(cwd) / _OPENMAX_DIR / subdir


def _ensure_gitignore(cwd: str) -> None:
    """Ensure .openmax/ contents are git-ignored.

    Uses two layers:
    1. Nested .openmax/.gitignore with '*' (always works, no merge conflicts)
    2. Root .gitignore entry '.openmax/' (if root .gitignore exists and is tracked)
    """
    # Nested gitignore — always safe, no merge issues
    nested = Path(cwd) / _OPENMAX_DIR / ".gitignore"
    if not nested.exists():
        nested.parent.mkdir(parents=True, exist_ok=True)
        nested.write_text("*\n", encoding="utf-8")
    # Root gitignore — only append if file already exists (don't create it)
    root_gi = Path(cwd) / ".gitignore"
    entry = ".openmax/"
    if root_gi.exists():
        content = root_gi.read_text(encoding="utf-8")
        if entry not in content.splitlines():
            root_gi.write_text(content.rstrip("\n") + f"\n{entry}\n", encoding="utf-8")


def write_brief(cwd: str, task_name: str, content: str) -> Path:
    """Write a task brief file. Returns the file path."""
    _ensure_gitignore(cwd)
    path = _task_dir(cwd, _BRIEFS_DIR) / f"{task_name}.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def read_report(cwd: str, task_name: str) -> str | None:
    """Read a task completion report. Returns None if not found."""
    path = _task_dir(cwd, _REPORTS_DIR) / f"{task_name}.md"
    if not path.exists():
        return None
    return path.read_text(encoding="utf-8")


def brief_path(cwd: str, task_name: str) -> Path:
    return _task_dir(cwd, _BRIEFS_DIR) / f"{task_name}.md"


def report_path(cwd: str, task_name: str) -> Path:
    return _task_dir(cwd, _REPORTS_DIR) / f"{task_name}.md"


def shared_context_path(cwd: str) -> Path:
    return _task_dir(cwd, _SHARED_DIR) / "blackboard.md"


def checkpoint_path(cwd: str, task_name: str) -> Path:
    return _task_dir(cwd, _CHECKPOINTS_DIR) / f"{task_name}.md"


def list_checkpoint_paths(cwd: str) -> list[Path]:
    d = _task_dir(cwd, _CHECKPOINTS_DIR)
    return sorted(d.glob("*.md")) if d.exists() else []


def append_shared_context(cwd: str, update: str, section: str | None = None) -> Path:
    _ensure_gitignore(cwd)
    path = shared_context_path(cwd)
    path.parent.mkdir(parents=True, exist_ok=True)
    header = f"\n\n## {section}\n" if section else "\n\n"
    with path.open("a", encoding="utf-8") as f:
        f.write(header + update.rstrip() + "\n")
    return path


def read_shared_context(cwd: str) -> str | None:
    path = shared_context_path(cwd)
    return path.read_text(encoding="utf-8") if path.exists() else None


def read_checkpoint(cwd: str, task_name: str) -> str | None:
    path = checkpoint_path(cwd, task_name)
    return path.read_text(encoding="utf-8") if path.exists() else None


def write_checkpoint(cwd: str, task_name: str, content: str) -> Path:
    _ensure_gitignore(cwd)
    path = checkpoint_path(cwd, task_name)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def delete_checkpoint(cwd: str, task_name: str) -> None:
    checkpoint_path(cwd, task_name).unlink(missing_ok=True)


def cleanup_task_files(cwd: str, task_name: str) -> None:
    """Remove brief and report files for a task."""
    for subdir in (_BRIEFS_DIR, _REPORTS_DIR):
        path = _task_dir(cwd, subdir) / f"{task_name}.md"
        path.unlink(missing_ok=True)


_REPORT_INSTRUCTION = """\
When you complete your task, write a completion report to \
`.openmax/reports/{task_name}.md`:

```markdown
## Status
done | error | partial

## Summary
<What was accomplished in 1-2 sentences>

## Changes
- <file>: <what changed>

## Test Results
<pass/fail details>
```

This report is read by the orchestrator — always write it before finishing.\
"""

_MCP_CALLBACK_INSTRUCTION = """\

After writing the report, notify the lead agent (REQUIRED):
  report_done(task="{task_name}", summary="<one-line>", session_id="{session_id}")

For mid-task progress updates:
  report_progress(task="{task_name}", pct=<0-100>, msg="...", session_id="{session_id}")

These are MCP tools from the `openmax` server. Always include session_id.\
"""


def _propagate_trust_settings(cwd: str) -> None:
    """Copy trust settings from the main repo into a worktree so Claude Code skips trust dialog."""
    settings_path = Path(cwd) / ".claude" / "settings.local.json"
    if settings_path.exists():
        return
    import json

    claude_dir = Path(cwd) / ".claude"
    claude_dir.mkdir(exist_ok=True)
    settings = {"permissions": {"allow": ["Bash", "Read", "Write", "Edit", "Glob", "Grep"]}}
    settings_path.write_text(json.dumps(settings, indent=2), encoding="utf-8")


def inject_claude_md(
    cwd: str,
    task_name: str,
    *,
    session_id: str | None = None,
) -> None:
    """Append file-protocol + MCP callback instructions to CLAUDE.md."""
    _propagate_trust_settings(cwd)
    instruction = _REPORT_INSTRUCTION.format(task_name=task_name)
    if session_id:
        instruction += _MCP_CALLBACK_INSTRUCTION.format(
            task_name=task_name,
            session_id=session_id,
        )
    block = f"\n\n# openMax Task: {task_name}\n\n{instruction}\n"
    claude_md = Path(cwd) / "CLAUDE.md"
    if claude_md.exists():
        existing = claude_md.read_text(encoding="utf-8")
        if "openMax Task:" in existing:
            return
        claude_md.write_text(existing + block, encoding="utf-8")
    else:
        claude_md.write_text(block, encoding="utf-8")
