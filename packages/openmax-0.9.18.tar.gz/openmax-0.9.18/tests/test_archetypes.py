from __future__ import annotations

import textwrap

import pytest

from openmax.archetypes import (
    BUILT_IN_ARCHETYPES,
    format_archetype_context,
    format_subtask_hints,
    get_all_archetypes,
    load_custom_archetypes,
)
from openmax.archetypes._base import (
    Archetype,
    SubtaskTemplate,
    classify_task,
    match_archetype,
)

# --- classify_task ---


class TestClassifyTask:
    def test_web_keywords_score_highest(self):
        scores = classify_task("build a React frontend page")
        assert scores["web"] > scores["cli"]
        assert scores["web"] > 0

    def test_cli_keywords(self):
        scores = classify_task("add a new CLI subcommand with argparse")
        assert scores["cli"] > scores["web"]

    def test_api_keywords(self):
        scores = classify_task("add a REST endpoint with FastAPI")
        assert scores["api"] > scores["cli"]

    def test_library_keywords(self):
        scores = classify_task("publish a Python SDK package to PyPI")
        assert scores["library"] > scores["web"]

    def test_refactor_keywords(self):
        scores = classify_task("refactor the auth module and migrate to new schema")
        assert scores["refactor"] > scores["web"]

    def test_empty_task_returns_zeros(self):
        scores = classify_task("")
        assert all(v == 0.0 for v in scores.values())

    def test_all_categories_present(self):
        scores = classify_task("anything")
        assert set(scores.keys()) == {"web", "cli", "api", "library", "refactor"}


# --- match_archetype ---


def _make_archetype(name: str) -> Archetype:
    return Archetype(
        name=name,
        display_name=name.title(),
        description=f"Test {name}",
    )


class TestMatchArchetype:
    def test_matches_by_task_keywords(self):
        archetypes = [_make_archetype("web"), _make_archetype("cli")]
        result = match_archetype("build a React frontend", archetypes)
        assert result is not None
        assert result.name == "web"

    def test_returns_none_when_no_archetypes(self):
        assert match_archetype("anything", []) is None

    def test_returns_none_when_confidence_too_low(self):
        arch = _make_archetype("web")
        result = match_archetype("unrelated task", [arch])
        assert result is None

    def test_task_keywords_determine_match(self):
        web = _make_archetype("web")
        cli = _make_archetype("cli")
        result = match_archetype("build a web page", [web, cli])
        assert result is not None
        assert result.name == "web"


# --- Built-in archetypes ---


# --- load_custom_archetypes ---


class TestLoadCustomArchetypes:
    def test_missing_dir_returns_empty(self, tmp_path):
        assert load_custom_archetypes(str(tmp_path)) == []

    def test_loads_valid_yaml(self, tmp_path):
        arch_dir = tmp_path / ".openmax" / "archetypes"
        arch_dir.mkdir(parents=True)
        yaml_content = textwrap.dedent("""\
            name: custom
            display_name: Custom Archetype
            description: A test archetype
            subtask_templates:
              - name: step1
                description: First step
            planning_hints:
              - Do the thing
            anti_patterns:
              - Don't do the bad thing
        """)
        (arch_dir / "custom.yaml").write_text(yaml_content)
        try:
            import yaml  # noqa: F401
        except ImportError:
            pytest.skip("PyYAML not installed")
        result = load_custom_archetypes(str(tmp_path))
        assert len(result) == 1
        assert result[0].name == "custom"

    def test_invalid_yaml_skipped(self, tmp_path):
        arch_dir = tmp_path / ".openmax" / "archetypes"
        arch_dir.mkdir(parents=True)
        (arch_dir / "broken.yaml").write_text(":::invalid:::")
        try:
            import yaml  # noqa: F401
        except ImportError:
            pytest.skip("PyYAML not installed")
        result = load_custom_archetypes(str(tmp_path))
        assert result == []


class TestGetAllArchetypes:
    def test_includes_builtins(self, tmp_path):
        get_all_archetypes.cache_clear()
        result = get_all_archetypes(str(tmp_path))
        assert len(result) >= 5


# --- format functions ---


class TestFormatArchetypeContext:
    def test_contains_archetype_name(self):
        arch = BUILT_IN_ARCHETYPES[0]
        output = format_archetype_context(arch, "build something")
        assert arch.display_name in output
        assert "build something" in output

    def test_contains_planning_hints(self):
        arch = BUILT_IN_ARCHETYPES[0]
        output = format_archetype_context(arch, "task")
        assert "Planning hints" in output


class TestFormatSubtaskHints:
    def test_lists_all_templates(self):
        arch = BUILT_IN_ARCHETYPES[0]
        output = format_subtask_hints(arch)
        for t in arch.subtask_templates:
            assert t.name in output

    def test_shows_dependencies(self):
        arch = Archetype(
            name="test",
            display_name="Test",
            description="test",
            subtask_templates=[
                SubtaskTemplate(
                    name="step2",
                    description="Second",
                    dependencies=["step1"],
                )
            ],
        )
        output = format_subtask_hints(arch)
        assert "after: step1" in output
