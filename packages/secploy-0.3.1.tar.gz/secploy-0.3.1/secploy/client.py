import threading
import logging
from typing import Any, Callable, Dict, Optional, List, Union
import queue

from secploy.lib.config import config_to_namespace

from .lib import setup_logger, load_config, DEFAULT_CONFIG, secploy_logger
from .schemas import SecployConfig, LogLevel
from .log_capture import SecployLogCapturer
from .events import EventHandler
from .processor import EventProcessor
from .config_manager import ConfigManager


class _EnvAccessor:
    """Ergonomic config accessor: client.env.MY_KEY or client.env.my_key."""

    def __init__(self, config_manager: ConfigManager):
        self._config_manager = config_manager

    def _lookup(self, key: str, default: Any = None) -> Any:
        # Support exact key plus common case variants.
        for candidate in (key, key.upper(), key.lower()):
            value = self._config_manager.get(candidate, None)
            if value is not None:
                return value
        return default

    def __getattr__(self, name: str) -> Any:
        value = self._lookup(name, None)
        if value is None:
            raise AttributeError(
                f"Config '{name}' was not found. "
                "Use client.env.get('KEY', default) for optional values."
            )
        return value

    def __getitem__(self, key: str) -> Any:
        value = self._lookup(key, None)
        if value is None:
            raise KeyError(key)
        return value

    def get(self, key: str, default: Any = None) -> Any:
        return self._lookup(key, default)

    def all(self) -> Dict[str, str]:
        return self._config_manager.all()

class SecployClient:
    def __init__(
        self,
        api_key: Optional[str] = None,
        environment_key: Optional[str] = None,
        organization_id: Optional[str] = None,
        config_file: Optional[str] = None,
        config: Optional[SecployConfig] = DEFAULT_CONFIG,
        log_levels: Optional[List[Union[str, int]]] = None
    ):
        """
        Initialize the Secploy client.

        Args:
            api_key: Optional API key to override configuration
            environment_key: Optional Environment key to override configuration
            organization_id: Optional Organization ID to override configuration
            config_file: Optional path to configuration file
            config: Configuration object, defaults to DEFAULT_CONFIG
        
        Raises:
            ValueError: If required configuration is missing
            TypeError: If configuration values have invalid types
        """
        # Load config from file if provided else it will load from default locations or find .secploy
        config_dict = load_config(config_file)
        config = config_to_namespace(config_dict)

        if config is None:
            secploy_logger.error("No valid configuration found")
            return
            
        # Override api_key if provided directly
        if api_key:
            config.api_key = api_key
        if environment_key:
            config.environment_key = environment_key
        if organization_id:
            config.organization_id = organization_id

        # Special handling for log_level if it's a string
        log_level = getattr(config, 'log_level', None)
        if isinstance(log_level, str):
            try:
                setattr(config, 'log_level', LogLevel(log_level.upper()))
            except ValueError:
                raise ValueError(
                    f"Invalid log level: {log_level}. Must be one of: "
                    f"{', '.join(level.value for level in LogLevel)}"
                )

        # Validate required fields
        if not getattr(config, 'api_key', None):
            raise ValueError("API key is required")
        if not getattr(config, 'environment_key', None):
            raise ValueError("Environment key is required")
        if not getattr(config, 'organization_id', None):
            raise ValueError("Organization ID is required")
        if not getattr(config, 'ingest_url', None):
            raise ValueError("Ingest URL is required")

        # Set instance attributes from config
        self.api_key = getattr(config, 'api_key')
        self.environment_key = getattr(config, 'environment_key', None)
        self.organization_id = getattr(config, 'organization_id', None)
        self.environment = getattr(config, 'environment', 'development')
        self.sampling_rate = getattr(config, 'sampling_rate', 1.0)
        self.ingest_url = getattr(config, 'ingest_url').rstrip("/")
        self.api_url = getattr(config, 'api_url', 'https://api.secploy.com').rstrip("/")
        self.heartbeat_interval = getattr(config, 'heartbeat_interval', 60)
        self.max_retry = getattr(config, 'max_retry', 5)
        self.debug = getattr(config, 'debug', False)
        self.log_level = getattr(config, 'log_level', 'INFO')
        self.realtime = getattr(config, 'realtime', True)  # set False to disable WS

        # Batch processing configuration
        self.batch_size = getattr(config, 'batch_size', 100)  # Max events per batch
        self.flush_interval = getattr(config, 'flush_interval', 60)  # Max seconds between flushes

        # Initialize internal state
        self._event_queue = queue.Queue()
        self._event_handler = EventHandler(self._event_queue)
        
        # Initialize event processor
        self._event_processor = EventProcessor(
            queue=self._event_queue,
            ingest_url=self.ingest_url,
            headers_callback=self._headers,
            batch_size=self.batch_size,
            flush_interval=self.flush_interval,
            max_retry=self.max_retry
        )
        
        # Setup logging
        if self.debug:
            setup_logger(log_level=self.log_level)
        
        # Initialize log capturer
        self._log_capturer = SecployLogCapturer(self, levels=log_levels)

        # Config manager (env vars, secrets, feature flags)
        self.configs = ConfigManager(
            api_url=self.api_url,
            headers_callback=self._headers,
        )

        # Ergonomic config access, e.g. client.env.google_api_key
        self.env = _EnvAccessor(self.configs)

        self.start()
    
    def capture_logs(self, loggers: Union[str, List[str], None] = None):
        """
        Start capturing logs from specified loggers.
        
        Args:
            loggers: Logger name(s) to capture. Can be:
                    - None to capture the root logger
                    - A string for a single logger
                    - A list of logger names
        """
        self._log_capturer.start_capture(loggers)
        secploy_logger.info(f"Started capturing logs from {loggers or 'root'}")
        
    def stop_capturing_logs(self, loggers: Union[str, List[str], None] = None):
        """
        Stop capturing logs from specified loggers.
        
        Args:
            loggers: Logger name(s) to stop capturing
        """
        self._log_capturer.stop_capture(loggers)
        secploy_logger.info(f"Stopped capturing logs from {loggers or 'root'}")
    
    def _headers(self):
        return {
            "X-API-Key": f"{self.api_key}",
            "X-Environment-Key": f"{self.environment_key}",
            "X-Organization-ID": f"{self.organization_id}",
            "Content-Type": "application/json",
        }

    def send_event(self, event_type: str, payload: Dict[str, Any]) -> bool:
        """
        Queue an event for sending. Events are batched and sent periodically.
        
        Args:
            event_type: Type of the event
            payload: Event payload data
        
        Returns:
            bool: True if event was queued successfully
        """
        return self._event_handler.send_event(event_type, payload)

    def track_http_request(
        self,
        method: str,
        endpoint: str,
        status_code: int,
        message: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Track an HTTP request event with automatic type inference based on status code.
        For example, 404 becomes "warning" and 500 becomes "critical".
        """
        payload: Dict[str, Any] = {
            "endpoint": endpoint,
            "method": method,
            "status_code": status_code,
            "message": message or f"{method} {endpoint} completed with {status_code}",
            "context": context or {},
        }
        return self.send_event("http_request", payload)

    def track_error(
        self,
        error: Exception,
        endpoint: Optional[str] = None,
        method: Optional[str] = None,
        status_code: int = 500,
        context: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Track an application error event with default critical/error semantics.
        """
        merged_context = dict(context or {})
        merged_context.setdefault("error_type", type(error).__name__)

        payload: Dict[str, Any] = {
            "message": str(error),
            "status_code": status_code,
            "context": merged_context,
        }
        if endpoint:
            payload["endpoint"] = endpoint
        if method:
            payload["method"] = method

        return self.send_event("error", payload)

    def track_metric(
        self,
        name: str,
        value: Union[int, float],
        unit: Optional[str] = None,
        tags: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        message: Optional[str] = None,
    ) -> bool:
        """
        Track a metric event with a normalized payload shape.
        """
        merged_context = dict(context or {})
        if tags is not None:
            merged_context["tags"] = tags
        if unit:
            merged_context["unit"] = unit

        payload: Dict[str, Any] = {
            "name": name,
            "value": value,
            "message": message or f"Metric {name}={value}",
            "context": merged_context,
        }
        return self.send_event("metric", payload)

    def start(self):
        """Start the client's event processing and real-time config delivery."""
        secploy_logger.info("Starting Secploy client...")
        self._event_processor.start()
        if self.realtime:
            ws_url = (
                self.api_url
                .replace("https://", "wss://")
                .replace("http://", "ws://")
            ) + "/ws/sdk/configs/"
            self.configs.start_realtime(ws_url, self._headers)

    def stop(self):
        """Stop the client and wait for processing to finish."""
        secploy_logger.info("Stopping Secploy client...")

        # Stop real-time config delivery (WebSocket + polling fallback)
        self.configs.stop_realtime()

        # Stop config auto-refresh if running
        if self.configs.is_refreshing:
            self.configs.stop_refresh()

        # Stop all log capturing
        if hasattr(self, '_log_capturer'):
            self._log_capturer.stop_all()
        
        # Stop event processing
        self._event_processor.stop()
