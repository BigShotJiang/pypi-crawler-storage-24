#!/usr/bin/env python3
from pbi_agent.__main__ import main


if __name__ == "__main__":
    raise SystemExit(main())
