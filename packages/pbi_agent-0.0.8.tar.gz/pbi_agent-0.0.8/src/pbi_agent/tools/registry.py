from __future__ import annotations

from typing import Any

from pbi_agent.tools.types import ToolHandler, ToolSpec

_REGISTRY: dict[str, tuple[ToolSpec, ToolHandler]] = {}

# --- built-in function tools -----------------------------------------------
from pbi_agent.tools.skill_knowledge import SPEC as _sk_spec, handle as _sk_handle  # noqa: E402
from pbi_agent.tools.init_report import SPEC as _ir_spec, handle as _ir_handle  # noqa: E402
from pbi_agent.tools.shell import SPEC as _sh_spec, handle as _sh_handle  # noqa: E402
from pbi_agent.tools.apply_patch import SPEC as _ap_spec, handle as _ap_handle  # noqa: E402

_REGISTRY[_sk_spec.name] = (_sk_spec, _sk_handle)
_REGISTRY[_ir_spec.name] = (_ir_spec, _ir_handle)
_REGISTRY[_sh_spec.name] = (_sh_spec, _sh_handle)
_REGISTRY[_ap_spec.name] = (_ap_spec, _ap_handle)


def get_tool_specs() -> list[ToolSpec]:
    return [item[0] for item in _REGISTRY.values()]


def get_tool_handler(name: str) -> ToolHandler | None:
    entry = _REGISTRY.get(name)
    if entry is None:
        return None
    return entry[1]


def get_tool_spec(name: str) -> ToolSpec | None:
    entry = _REGISTRY.get(name)
    if entry is None:
        return None
    return entry[0]


def get_openai_tool_definitions() -> list[dict[str, Any]]:
    """Return tool definitions in OpenAI Responses API format.

    All tools are now registered function tools — no provider-specific
    native types.
    """
    tools: list[dict[str, Any]] = []
    for spec in get_tool_specs():
        tools.append(
            {
                "type": "function",
                "name": spec.name,
                "description": spec.description,
                "parameters": spec.parameters_schema,
            }
        )
    return tools


def get_anthropic_tool_definitions() -> list[dict[str, Any]]:
    """Return tool definitions in Anthropic Messages API format.

    All tools are now registered function tools — no provider-specific
    native types.
    """
    tools: list[dict[str, Any]] = []
    for spec in get_tool_specs():
        tools.append(
            {
                "name": spec.name,
                "description": spec.description,
                "input_schema": spec.parameters_schema,
            }
        )
    return tools


def get_openai_chat_tool_definitions() -> list[dict[str, Any]]:
    """Return tool definitions in OpenAI Chat Completions format."""
    tools: list[dict[str, Any]] = []
    for spec in get_tool_specs():
        tools.append(
            {
                "type": "function",
                "function": {
                    "name": spec.name,
                    "description": spec.description,
                    "parameters": spec.parameters_schema,
                },
            }
        )
    return tools
