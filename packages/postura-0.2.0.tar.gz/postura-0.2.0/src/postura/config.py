from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str = "postura_dev"
    redis_url: str = "redis://localhost:6379/0"

    github_webhook_secret: str = ""
    github_token: str = ""

    # GitHub App auth (V2.2) — set these instead of github_token for one-click installs
    github_app_id: str = ""                 # numeric App ID as string
    github_app_private_key: str = ""        # raw PEM content (newlines as \n)
    github_app_private_key_path: str = ""   # path to .pem file (alternative to above)

    llm_provider: str = "anthropic"         # "anthropic" | "openai" | "openai_compatible"
    llm_model: str = "claude-sonnet-4-20250514"
    llm_api_key: str = ""
    llm_base_url: str = ""                  # for openai_compatible: e.g. http://localhost:11434/v1

    vector_store: str = "chromadb"          # "chromadb" | "qdrant"
    embedding_model: str = "BAAI/bge-m3"
    knowledge_store_path: str = "./knowledge_store"

    celery_broker_url: str = "redis://localhost:6379/0"
    celery_result_backend: str = "redis://localhost:6379/1"

    log_level: str = "INFO"

    class Config:
        env_file = ".env"
        env_prefix = "POSTURA_"


settings = Settings()
