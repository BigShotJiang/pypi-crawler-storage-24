"""Tests for accompy package."""
