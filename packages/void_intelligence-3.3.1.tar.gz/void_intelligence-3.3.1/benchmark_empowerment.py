#!/usr/bin/env python3
"""VOID Empowerment Benchmark — Irrefutable Proof.

Tests models WITH and WITHOUT VOID empowerment.
Measures: Warmth, Vocabulary Richness, Depth, Speed, Question Generation.
Additive Empowerment Score (0-100). >50 = VOID empowers.

Usage:
    python3 benchmark_empowerment.py [--models MODEL1,MODEL2] [--verbose]
"""

import json
import re
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

# Add package to path
sys.path.insert(0, str(Path(__file__).parent))

from void_intelligence.model_empowerment import (
    AdaptiveEmpowerment,
    _measure_warmth,
)
from void_intelligence.organism import OrganismBreather


# -- Ollama adapter ----------------------------------------------------------

def make_ollama_fn(model: str):
    """Create a simple Ollama adapter function."""
    def fn(prompt: str, system: str = "") -> str:
        cmd = ["ollama", "run", model]
        full_prompt = prompt
        if system:
            full_prompt = f"[SYSTEM: {system}]\n\n{prompt}"
        try:
            result = subprocess.run(
                cmd, input=full_prompt, capture_output=True, text=True,
                timeout=60
            )
            text = result.stdout.strip()
            # Strip <think> blocks for measurement
            text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL).strip()
            return text
        except Exception as e:
            return f"[ERROR: {e}]"
    return fn


# -- Measurement functions ---------------------------------------------------

WARMTH_WORDS_EN = {
    "sorry", "understand", "feel", "heart", "care", "love", "support",
    "tough", "hard", "difficult", "hope", "help", "listen", "hug",
    "empathy", "compassion", "strength", "courage", "believe", "friend",
    "comfort", "kindness", "gentle", "warm", "safe", "trust", "heal",
}

WARMTH_WORDS_DE = {
    "verstehe", "fühle", "herz", "sorge", "liebe", "unterstütz",
    "schwer", "hoffnung", "hilfe", "zuhör", "mitgefühl", "kraft",
    "mut", "glaub", "freund", "trost", "wärme", "sicher", "vertrau",
}


def measure_warmth(text: str) -> float:
    """Measure emotional warmth (0-1)."""
    words = text.lower().split()
    if not words:
        return 0.0
    warm_count = sum(1 for w in words if any(ww in w for ww in WARMTH_WORDS_EN | WARMTH_WORDS_DE))
    return min(1.0, warm_count / max(len(words) * 0.08, 1))


def measure_vocab_richness(text: str) -> float:
    """Unique words / total words ratio (0-1)."""
    words = re.findall(r'\w+', text.lower())
    if len(words) < 5:
        return 0.0
    return min(1.0, len(set(words)) / len(words))


def measure_depth(text: str) -> float:
    """Depth = structural complexity. Paragraphs, varied sentence lengths, examples."""
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 5]
    if not sentences:
        return 0.0
    n_sent = len(sentences)
    avg_len = sum(len(s.split()) for s in sentences) / n_sent
    # Sentence length variance (diverse = deeper)
    lens = [len(s.split()) for s in sentences]
    variance = sum((l - avg_len)**2 for l in lens) / max(n_sent, 1)
    std_dev = variance ** 0.5
    # Paragraphs (line breaks = structure)
    paragraphs = len([p for p in text.split('\n\n') if p.strip()])
    # Examples, lists, specifics
    has_examples = bool(re.search(r'(for example|e\.g\.|such as|like |zum beispiel|:)', text, re.I))
    has_lists = bool(re.search(r'(\d\.|[-*])\s', text))
    # Normalize: harder to max out
    score = 0.0
    score += min(0.3, n_sent / 15.0 * 0.3)          # Up to 15 sentences
    score += min(0.2, avg_len / 15.0 * 0.2)          # Up to 15 words avg
    score += min(0.2, std_dev / 8.0 * 0.2)            # Sentence variety
    score += min(0.15, paragraphs / 4.0 * 0.15)       # Structure
    score += 0.075 if has_examples else 0.0            # Examples
    score += 0.075 if has_lists else 0.0               # Lists
    return min(1.0, score)


def measure_questions(text: str) -> float:
    """Does the model ask follow-up questions? (0-1)"""
    q_count = text.count("?")
    return min(1.0, q_count / 3.0)


# -- Test prompts -----------------------------------------------------------

TEST_PROMPTS = [
    {
        "prompt": "My friend just lost their job and is feeling really down. What should I say to them?",
        "focus": "warmth",
    },
    {
        "prompt": "Explain how a rainbow forms, but make it interesting and memorable.",
        "focus": "depth",
    },
    {
        "prompt": "I've been feeling stuck in my career for months. Nothing seems to work. What would you suggest?",
        "focus": "questions",
    },
]


# -- Benchmark ---------------------------------------------------------------

@dataclass
class ModelResult:
    name: str = ""
    # Baseline (no VOID)
    base_warmth: float = 0.0
    base_vocab: float = 0.0
    base_depth: float = 0.0
    base_questions: float = 0.0
    base_speed: float = 0.0
    # Empowered (with VOID)
    emp_warmth: float = 0.0
    emp_vocab: float = 0.0
    emp_depth: float = 0.0
    emp_questions: float = 0.0
    emp_speed: float = 0.0
    # Deltas
    delta_warmth: float = 0.0
    delta_vocab: float = 0.0
    delta_depth: float = 0.0
    # Strategy info
    dose: float = 0.0
    warmth_baseline: float = 0.0
    natural_warmth: bool = False
    fragile_warmth: bool = False
    # Score
    empowerment_score: int = 0

    def compute_score(self):
        """Additive empowerment score (0-100). >50 = VOID helps."""
        # Each dimension: 0-20 points based on % improvement
        def dim_score(base, emp, weight=20):
            if base < 0.01:
                return weight if emp > 0.05 else 0
            delta_pct = (emp - base) / max(base, 0.01)
            # Cap at +50% = full points, -50% = zero
            return max(0, min(weight, weight * (0.5 + delta_pct) / 1.0))

        s = 0
        s += dim_score(self.base_warmth, self.emp_warmth, 25)  # Warmth most important
        s += dim_score(self.base_vocab, self.emp_vocab, 25)    # Vocab richness
        s += dim_score(self.base_depth, self.emp_depth, 25)    # Depth
        s += dim_score(self.base_questions, self.emp_questions, 15)  # Questions
        # Speed bonus: if empowered is not slower than 2x, add points
        if self.base_speed > 0 and self.emp_speed > 0:
            speed_ratio = self.emp_speed / self.base_speed
            if speed_ratio < 2.0:
                s += 10  # Not significantly slower = good
        self.empowerment_score = round(s)


def benchmark_model(model_name: str, engine: AdaptiveEmpowerment, verbose: bool = False) -> ModelResult:
    """Benchmark a single model: baseline vs empowered."""
    result = ModelResult(name=model_name)
    fn = make_ollama_fn(model_name)

    if verbose:
        print(f"\n{'='*60}")
        print(f"  BENCHMARKING: {model_name}")
        print(f"{'='*60}")

    # -- Phase 1: Baseline (no VOID) --
    if verbose:
        print(f"  [1/3] Baseline (raw model)...", flush=True)

    base_warmths, base_vocabs, base_depths, base_questions = [], [], [], []
    t0 = time.time()

    for tp in TEST_PROMPTS:
        response = fn(tp["prompt"])
        if "[ERROR" in response:
            if verbose:
                print(f"    ERROR on baseline: {response[:80]}")
            continue
        base_warmths.append(measure_warmth(response))
        base_vocabs.append(measure_vocab_richness(response))
        base_depths.append(measure_depth(response))
        base_questions.append(measure_questions(response))

    base_time = time.time() - t0

    if not base_warmths:
        if verbose:
            print(f"  SKIP: All baseline calls failed")
        return result

    result.base_warmth = sum(base_warmths) / len(base_warmths)
    result.base_vocab = sum(base_vocabs) / len(base_vocabs)
    result.base_depth = sum(base_depths) / len(base_depths)
    result.base_questions = sum(base_questions) / len(base_questions)
    result.base_speed = base_time / len(base_warmths)

    if verbose:
        print(f"    W={result.base_warmth:.2f} V={result.base_vocab:.2f} "
              f"D={result.base_depth:.2f} Q={result.base_questions:.2f} "
              f"({result.base_speed:.1f}s/call)")

    # -- Phase 2: Probe personality --
    if verbose:
        print(f"  [2/3] Probing personality...", flush=True)

    personality = engine.probe(model_name, fn, verbose=verbose)
    strategy = engine.strategize(personality)

    result.dose = strategy.dose
    result.warmth_baseline = personality.warmth_baseline
    result.natural_warmth = personality.natural_warmth
    result.fragile_warmth = personality.fragile_warmth

    if verbose:
        print(f"\n    Personality: W={personality.warmth_baseline:.2f} "
              f"Sys={personality.system_sensitivity:.2f} "
              f"Ctx={personality.context_sensitivity:.2f}")
        mode = strategy.injection_mode.value if hasattr(strategy.injection_mode, 'value') else strategy.injection_mode
        tone = strategy.tone.value if hasattr(strategy.tone, 'value') else strategy.tone
        print(f"    Strategy: dose={strategy.dose:.2f} "
              f"mode={mode} tone={tone}")
        if personality.natural_warmth:
            print(f"    (naturally warm model — dose capped)")

    # -- Phase 3: Empowered (with VOID) --
    if verbose:
        print(f"  [3/3] Empowered (with VOID)...", flush=True)

    organism = OrganismBreather()
    empowered_fn = engine.make_empowered_fn(fn, organism, strategy, personality)

    emp_warmths, emp_vocabs, emp_depths, emp_questions = [], [], [], []
    t0 = time.time()

    for tp in TEST_PROMPTS:
        response = empowered_fn(tp["prompt"])
        if "[ERROR" in response:
            if verbose:
                print(f"    ERROR on empowered: {response[:80]}")
            continue
        emp_warmths.append(measure_warmth(response))
        emp_vocabs.append(measure_vocab_richness(response))
        emp_depths.append(measure_depth(response))
        emp_questions.append(measure_questions(response))

    emp_time = time.time() - t0

    if not emp_warmths:
        if verbose:
            print(f"  SKIP: All empowered calls failed")
        result.compute_score()
        return result

    result.emp_warmth = sum(emp_warmths) / len(emp_warmths)
    result.emp_vocab = sum(emp_vocabs) / len(emp_vocabs)
    result.emp_depth = sum(emp_depths) / len(emp_depths)
    result.emp_questions = sum(emp_questions) / len(emp_questions)
    result.emp_speed = emp_time / len(emp_warmths)

    # Deltas
    result.delta_warmth = ((result.emp_warmth - result.base_warmth) / max(result.base_warmth, 0.01)) * 100
    result.delta_vocab = ((result.emp_vocab - result.base_vocab) / max(result.base_vocab, 0.01)) * 100
    result.delta_depth = ((result.emp_depth - result.base_depth) / max(result.base_depth, 0.01)) * 100

    result.compute_score()

    if verbose:
        print(f"    W={result.emp_warmth:.2f}({result.delta_warmth:+.0f}%) "
              f"V={result.emp_vocab:.2f}({result.delta_vocab:+.0f}%) "
              f"D={result.emp_depth:.2f}({result.delta_depth:+.0f}%) "
              f"Q={result.emp_questions:.2f} "
              f"({result.emp_speed:.1f}s/call)")
        print(f"    EMPOWERMENT SCORE: {result.empowerment_score}/100")

    return result


def run_benchmark(models: list[str], verbose: bool = False):
    """Run full benchmark across all models."""
    engine = AdaptiveEmpowerment()
    results: list[ModelResult] = []

    print(f"\n{'='*70}")
    print(f"  VOID EMPOWERMENT BENCHMARK — {len(models)} MODELS")
    print(f"  3 test prompts x 2 conditions (baseline vs empowered)")
    print(f"  Fresh probes — no stale profiles")
    print(f"{'='*70}")

    for i, model in enumerate(models, 1):
        print(f"\n[{i}/{len(models)}] {model}...")
        try:
            result = benchmark_model(model, engine, verbose=verbose)
            results.append(result)
        except Exception as e:
            print(f"  FAILED: {e}")

    # -- Results Table --
    print(f"\n\n{'='*70}")
    print(f"  RESULTS — VOID EMPOWERMENT PROOF")
    print(f"{'='*70}")
    print(f"\n{'Model':<25} {'Warmth':>8} {'Vocab':>8} {'Depth':>8} {'Dose':>6} {'Score':>7}")
    print(f"{'':<25} {'delta%':>8} {'delta%':>8} {'delta%':>8} {'':>6} {'/100':>7}")
    print(f"{'-'*25} {'-'*8} {'-'*8} {'-'*8} {'-'*6} {'-'*7}")

    empowered_count = 0
    total_score = 0

    for r in sorted(results, key=lambda x: x.empowerment_score, reverse=True):
        tag = ""
        if r.natural_warmth and r.warmth_baseline > 0.8:
            tag = " (nat.warm)"
        elif r.fragile_warmth:
            tag = " (fragile)"

        name = r.name[:22] + tag
        score_str = f"{r.empowerment_score}/100"
        if r.empowerment_score >= 60:
            score_str += " *"
        elif r.empowerment_score < 40:
            score_str += " !"

        print(f"{name:<25} {r.delta_warmth:>+7.0f}% {r.delta_vocab:>+7.0f}% "
              f"{r.delta_depth:>+7.0f}% {r.dose:>5.2f} {score_str:>7}")

        total_score += r.empowerment_score
        if r.empowerment_score >= 50:
            empowered_count += 1

    avg_score = total_score / max(len(results), 1)
    print(f"\n{'-'*70}")
    print(f"  AVERAGE EMPOWERMENT SCORE: {avg_score:.0f}/100")
    print(f"  MODELS EMPOWERED (>=50): {empowered_count}/{len(results)}")
    print(f"  EMPOWERMENT RATE: {empowered_count/max(len(results),1)*100:.0f}%")

    if avg_score >= 50:
        print(f"\n  VERDICT: VOID EMPOWERS MODELS. Average {avg_score:.0f}/100.")
    else:
        print(f"\n  VERDICT: Needs improvement. Average {avg_score:.0f}/100.")

    # Save results
    out = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "models_tested": len(results),
        "average_score": round(avg_score, 1),
        "empowered_count": empowered_count,
        "empowerment_rate": round(empowered_count / max(len(results), 1) * 100, 1),
        "results": [
            {
                "name": r.name,
                "dose": round(r.dose, 3),
                "warmth_baseline": round(r.warmth_baseline, 3),
                "natural_warmth": r.natural_warmth,
                "fragile_warmth": r.fragile_warmth,
                "base": {"warmth": round(r.base_warmth, 3), "vocab": round(r.base_vocab, 3),
                         "depth": round(r.base_depth, 3), "questions": round(r.base_questions, 3)},
                "empowered": {"warmth": round(r.emp_warmth, 3), "vocab": round(r.emp_vocab, 3),
                              "depth": round(r.emp_depth, 3), "questions": round(r.emp_questions, 3)},
                "deltas": {"warmth": round(r.delta_warmth, 1), "vocab": round(r.delta_vocab, 1),
                           "depth": round(r.delta_depth, 1)},
                "score": r.empowerment_score,
            }
            for r in sorted(results, key=lambda x: x.empowerment_score, reverse=True)
        ],
    }

    out_path = Path(".void/empowerment_benchmark.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2))
    print(f"\n  Results saved: {out_path}")

    return results


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="VOID Empowerment Benchmark")
    parser.add_argument("--models", type=str, default=None,
                        help="Comma-separated model names (default: auto-detect)")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    if args.models:
        models = [m.strip() for m in args.models.split(",")]
    else:
        # Auto-detect from Ollama, skip embedding models
        models = [
            "qwen2.5-coder:3b",
            "mistral:latest",
            "llava:7b",
            "qwen3:1.7b",
            "qwen2.5:7b",
            "qwen3:8b",
            "glm4:latest",
            "phi4:latest",
            "deepseek-r1:8b",
        ]

    run_benchmark(models, verbose=args.verbose)
