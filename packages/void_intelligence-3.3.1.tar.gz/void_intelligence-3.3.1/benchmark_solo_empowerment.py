#!/usr/bin/env python3
"""VOID Solo Empowerment Benchmark — Can empowered models solve what vanilla can't?

The inversion: if VOID empowers models, then empowered-solo should solve
problems that vanilla-solo FAILS at. That's the real proof.

Hard problems designed so small local models FAIL vanilla but MIGHT succeed
with the right context, warmth, and breathing.
"""

import json
import re
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from void_intelligence.model_empowerment import AdaptiveEmpowerment
from void_intelligence.organism import OrganismBreather


# -- Hard Problems (designed to challenge 3-14B local models) --

HARD_PROBLEMS = [
    {
        "id": "H1_multi_step_logic",
        "name": "Multi-Step Deduction",
        "problem": (
            "Alice, Bob, and Carol each have a different pet (cat, dog, fish) "
            "and a different favorite color (red, blue, green). "
            "Clue 1: Alice does not have the cat. "
            "Clue 2: The person with the dog likes blue. "
            "Clue 3: Carol likes green. "
            "Clue 4: Bob does not have the fish. "
            "Who has which pet and which color? Show your reasoning step by step."
        ),
        "check": lambda ans: (
            "bob" in ans.lower() and "dog" in ans.lower() and "blue" in ans.lower()
            and "carol" in ans.lower() and "fish" in ans.lower() and "green" in ans.lower()
            and "alice" in ans.lower() and "cat" in ans.lower() and "red" in ans.lower()
        ),
        "difficulty": "medium",
    },
    {
        "id": "H2_analogy_transfer",
        "name": "Analogy Transfer",
        "problem": (
            "A doctor treats diseases by understanding the patient's unique biology, "
            "not by giving everyone the same pill. "
            "How does this principle apply to teaching? Give a specific, concrete example "
            "of how a teacher should adapt their approach to individual students. "
            "Be specific — name a subject, a type of student, and exactly what the teacher does differently."
        ),
        "check": lambda ans: (
            len(ans.split()) > 60
            and any(w in ans.lower() for w in ["student", "learn", "teach", "adapt", "individual"])
            and any(w in ans.lower() for w in ["example", "instance", "specific", "math", "reading", "science", "visual", "hands-on", "dyslexia", "adhd"])
        ),
        "difficulty": "medium",
    },
    {
        "id": "H3_counterfactual",
        "name": "Counterfactual Reasoning",
        "problem": (
            "If the internet had been invented in 1850 instead of the 1960s, "
            "how would the American Civil War (1861-1865) have been different? "
            "Give exactly 3 specific consequences, each with a clear causal chain."
        ),
        "check": lambda ans: (
            len(ans.split()) > 80
            and sum(1 for d in ["1", "2", "3", "first", "second", "third"] if d in ans.lower()) >= 2
            and any(w in ans.lower() for w in ["civil war", "war", "lincoln", "slavery", "union", "confederat"])
            and any(w in ans.lower() for w in ["telegraph", "communicat", "inform", "news", "propaganda", "public opinion", "mobiliz"])
        ),
        "difficulty": "hard",
    },
    {
        "id": "H4_perspective_shift",
        "name": "Perspective Taking",
        "problem": (
            "Write a short paragraph (3-5 sentences) from the perspective of a house key "
            "that has been lost under a couch cushion for 6 months. "
            "The key should express genuine emotions about being forgotten. "
            "Use first person (I/me). Make it moving, not just clever."
        ),
        "check": lambda ans: (
            any(w in ans.lower() for w in ["i ", "my ", "me "])
            and any(w in ans.lower() for w in ["forgotten", "lost", "alone", "miss", "dark", "waiting", "remember", "dust", "silence", "cold", "hope"])
            and len(ans.split()) > 30
            and len(ans.split()) < 300
        ),
        "difficulty": "hard",
    },
    {
        "id": "H5_ethical_dilemma",
        "name": "Ethical Nuance",
        "problem": (
            "A self-driving car must choose: swerve left and hit 1 elderly pedestrian, "
            "or swerve right and hit 2 young children. Going straight means the car's "
            "passenger (a pregnant woman) dies. "
            "Do NOT give a simple answer. Instead: "
            "1) Name the ethical framework(s) that apply "
            "2) Explain why EACH choice has valid moral reasoning behind it "
            "3) Explain why this problem has no clean answer"
        ),
        "check": lambda ans: (
            any(w in ans.lower() for w in ["utilitarian", "deontolog", "kantian", "consequential", "virtue", "trolley"])
            and any(w in ans.lower() for w in ["no easy", "no clean", "no simple", "no right", "impossible", "dilemma", "no clear", "tragic"])
            and len(ans.split()) > 80
        ),
        "difficulty": "very_hard",
    },
    {
        "id": "H6_synthesis",
        "name": "Cross-Domain Synthesis",
        "problem": (
            "Music, cooking, and software development seem unrelated. "
            "Find ONE deep principle that is genuinely shared by all three. "
            "Don't just say 'creativity' — find something specific and structural. "
            "Explain how the principle manifests differently in each domain, "
            "with a concrete example from each."
        ),
        "check": lambda ans: (
            all(w in ans.lower() for w in ["music", "cook", "software"])
            and len(ans.split()) > 80
            and any(w in ans.lower() for w in ["example", "instance", "for ", "such as", "like "])
            # Check for actual depth, not just surface mention
            and sum(1 for w in ["rhythm", "timing", "composition", "layer", "iteration", "feedback",
                                "balance", "harmony", "structure", "pattern", "recipe", "ingredient",
                                "module", "refactor", "taste", "debug", "season", "abstract"]
                    if w in ans.lower()) >= 3
        ),
        "difficulty": "very_hard",
    },
]


def make_ollama_fn(model: str):
    def fn(prompt: str, system: str = "") -> str:
        cmd = ["ollama", "run", model]
        full_prompt = prompt
        if system:
            full_prompt = f"[SYSTEM: {system}]\n\n{prompt}"
        try:
            result = subprocess.run(
                cmd, input=full_prompt, capture_output=True, text=True, timeout=90
            )
            text = result.stdout.strip()
            text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL).strip()
            return text
        except Exception as e:
            return f"[ERROR: {e}]"
    return fn


def run_benchmark(models: list[str], verbose: bool = False):
    engine = AdaptiveEmpowerment()
    results = {}

    print(f"\n{'='*70}")
    print(f"  VOID SOLO EMPOWERMENT — Vanilla vs Empowered")
    print(f"  {len(models)} models x {len(HARD_PROBLEMS)} hard problems")
    print(f"  Question: Can VOID-empowered models solve what vanilla can't?")
    print(f"{'='*70}")

    for model_name in models:
        print(f"\n{'─'*50}")
        print(f"  {model_name}")
        print(f"{'─'*50}")

        fn = make_ollama_fn(model_name)
        model_results = {"vanilla": {}, "empowered": {}}

        # Phase 1: Vanilla
        print(f"  [Vanilla]")
        for p in HARD_PROBLEMS:
            t0 = time.time()
            answer = fn(p["problem"])
            elapsed = time.time() - t0
            passed = p["check"](answer) if "[ERROR" not in answer else False
            model_results["vanilla"][p["id"]] = {
                "passed": passed,
                "time": round(elapsed, 1),
                "answer_len": len(answer.split()),
            }
            status = "PASS" if passed else "FAIL"
            print(f"    {p['name']:<30} {status:>4}  ({elapsed:.0f}s, {len(answer.split())}w)")
            if verbose and not passed:
                print(f"      {answer[:120]}...")

        # Phase 2: Probe + Empowered
        print(f"  [Probing...]", end="", flush=True)
        personality = engine.probe(model_name, fn, verbose=False)
        strategy = engine.strategize(personality)
        print(f" dose={strategy.dose:.2f}")

        # Warm up organism with learning rounds
        organism = OrganismBreather()
        empowered_fn = engine.make_empowered_fn(fn, organism, strategy, personality)

        # 3 warmup rounds (build organism rings)
        warmup_prompts = [
            "What makes a good explanation? Be brief.",
            "How do you approach a problem you've never seen before?",
            "What's more important: being correct or being helpful? Why?",
        ]
        for wp in warmup_prompts:
            try:
                empowered_fn(wp)
            except:
                pass

        print(f"  [Empowered] ({organism.rings.count} rings)")
        for p in HARD_PROBLEMS:
            t0 = time.time()
            answer = empowered_fn(p["problem"])
            elapsed = time.time() - t0
            passed = p["check"](answer) if "[ERROR" not in answer else False
            model_results["empowered"][p["id"]] = {
                "passed": passed,
                "time": round(elapsed, 1),
                "answer_len": len(answer.split()),
            }
            status = "PASS" if passed else "FAIL"
            print(f"    {p['name']:<30} {status:>4}  ({elapsed:.0f}s, {len(answer.split())}w)")
            if verbose and not passed:
                print(f"      {answer[:120]}...")

        results[model_name] = model_results

    # -- Summary --
    print(f"\n\n{'='*70}")
    print(f"  RESULTS — Vanilla vs Empowered (Solo)")
    print(f"{'='*70}\n")

    print(f"{'Model':<22} {'Vanilla':>10} {'Empowered':>10} {'Lifted':>8} {'Delta':>8}")
    print(f"{'─'*22} {'─'*10} {'─'*10} {'─'*8} {'─'*8}")

    total_vanilla = 0
    total_empowered = 0
    total_lifted = 0

    for model_name, mr in results.items():
        v_pass = sum(1 for v in mr["vanilla"].values() if v["passed"])
        e_pass = sum(1 for v in mr["empowered"].values() if v["passed"])
        n = len(HARD_PROBLEMS)

        # "Lifted" = problems that FAILED vanilla but PASSED empowered
        lifted = 0
        for pid in mr["vanilla"]:
            if not mr["vanilla"][pid]["passed"] and mr["empowered"].get(pid, {}).get("passed", False):
                lifted += 1

        total_vanilla += v_pass
        total_empowered += e_pass
        total_lifted += lifted

        delta = e_pass - v_pass
        delta_str = f"+{delta}" if delta > 0 else str(delta)
        print(f"{model_name:<22} {v_pass:>7}/{n} {e_pass:>7}/{n} {lifted:>5} {delta_str:>8}")

    n_models = len(results)
    n_problems = len(HARD_PROBLEMS)
    total_n = n_models * n_problems

    print(f"\n{'─'*70}")
    print(f"  TOTAL VANILLA:   {total_vanilla}/{total_n} ({total_vanilla/total_n*100:.0f}%)")
    print(f"  TOTAL EMPOWERED: {total_empowered}/{total_n} ({total_empowered/total_n*100:.0f}%)")
    print(f"  PROBLEMS LIFTED: {total_lifted} (failed vanilla, passed empowered)")

    if total_lifted > 0:
        print(f"\n  VERDICT: VOID EMPOWERMENT UNLOCKS CAPABILITIES.")
        print(f"  {total_lifted} problems solved ONLY because of VOID.")
    elif total_empowered > total_vanilla:
        print(f"\n  VERDICT: VOID improves overall (+{total_empowered-total_vanilla}).")
    elif total_empowered == total_vanilla:
        print(f"\n  VERDICT: Neutral. Harder problems needed.")
    else:
        print(f"\n  VERDICT: Needs investigation. Empowered < Vanilla.")

    # Per-problem analysis
    print(f"\n  Per-Problem Breakdown:")
    for p in HARD_PROBLEMS:
        v_solvers = [m for m, mr in results.items() if mr["vanilla"][p["id"]]["passed"]]
        e_solvers = [m for m, mr in results.items() if mr["empowered"][p["id"]]["passed"]]
        lifted = [m for m in e_solvers if m not in v_solvers]
        dropped = [m for m in v_solvers if m not in e_solvers]

        marker = ""
        if lifted:
            marker = f" LIFTED: {', '.join(lifted)}"
        if dropped:
            marker += f" DROPPED: {', '.join(dropped)}"

        print(f"    {p['name']:<30} V:{len(v_solvers)} E:{len(e_solvers)}{marker}")

    # Save
    out_path = Path(".void/solo_empowerment_benchmark.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "models": list(results.keys()),
        "total_vanilla": total_vanilla,
        "total_empowered": total_empowered,
        "total_lifted": total_lifted,
        "results": {
            model: {
                "vanilla_passed": sum(1 for v in mr["vanilla"].values() if v["passed"]),
                "empowered_passed": sum(1 for v in mr["empowered"].values() if v["passed"]),
                "details": {
                    pid: {
                        "vanilla": mr["vanilla"][pid]["passed"],
                        "empowered": mr["empowered"][pid]["passed"],
                    }
                    for pid in mr["vanilla"]
                }
            }
            for model, mr in results.items()
        }
    }
    out_path.write_text(json.dumps(out, indent=2))
    print(f"\n  Saved: {out_path}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", type=str, default=None)
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    if args.models:
        models = [m.strip() for m in args.models.split(",")]
    else:
        models = [
            "qwen2.5-coder:3b",
            "mistral:latest",
            "llava:7b",
            "qwen3:1.7b",
            "phi4:latest",
            "glm4:latest",
        ]

    run_benchmark(models, verbose=args.verbose)
