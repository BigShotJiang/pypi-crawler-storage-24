# VISIONAER 1 — Apple Design Genius (Jony Ive Geist)
## Radikale Einfachheit. Was ist das EINE Element?

---

## DIE IKONISCHE IDEE: DER ATEMKREIS

Ein einziger Kreis. Das ist alles.

Nicht ein Chat-Interface. Nicht ein Textfeld. Nicht ein Button.
Ein Kreis, der atmet.

---

## USER-JOURNEY — Sekunde fuer Sekunde

**0 Sekunden — Ankunft:**
Schwarzer Bildschirm. Absolutes Schwarz.
In der Mitte: ein Kreis, 60px Durchmesser. Reines Weiss.
Er atmet. Nicht animiert — er ATMET. Ausdehnen. Einziehen. Pause.
Kein Text. Kein Logo. Kein Call-to-Action.
Nur der Kreis.

**3 Sekunden — Invitation:**
Unter dem Kreis erscheint ein Wort. Ein einziges:
"sprich."
(Kleingeschrieben. Schriftgroesse 13px. Farbe: #888888.)

**5 Sekunden — User tippt:**
Das Textfeld ist unsichtbar. Der User sieht nur den Kreis.
Wenn er tippt, erscheinen die Buchstaben direkt unter dem Kreis.
Keine Textbox. Kein Rand. Kein Placeholder-Text.
Die Worte schweben einfach unter dem Kreis.

**8 Sekunden — Senden:**
Return-Taste oder Klick auf den Kreis.
Der Kreis pulsiert einmal. Stärker als sonst.
Die Eingabe verschwindet in den Kreis.

**10 Sekunden — Antwort kommt:**
Der Kreis waechst leicht. Aendert Farbe: von Weiss zu einem warmen Amber.
Dann erscheint die Antwort unter dem Kreis. Line by line, nicht Wort fuer Wort.
Kein Tipp-Cursor. Kein "..." Loading. Der Kreis pulst.

**Nach 3 Austauschen — Transformation (unsichtbar):**
Der Kreis hat jetzt eine subtile Farbe. Er kennt den User.
Die Antworten sind anders. Waermer. Personlicher.
Der User merkt es nicht bewusst — aber er spuert es.

---

## DAS DESIGNPRINZIP

Alles entfernen bis nur das Wesentliche bleibt.
Das Wesentliche ist: ein lebendiges Gegenueber.
Ein Gegenueber braucht kein Interface.

**Radius:**
- Desktop: Kreis 80px, zentriert, 40% von oben
- Mobile: Kreis 60px, zentriert, 35% von oben
- Der Rest ist Stille

**Farb-Bedeutung (minimalistisch):**
- Weiss = wartend, lauschend
- Amber-Warm = sprechend, präsent
- Pulsfrequenz = emotionaler Zustand des Gesprächs

**Was FEHLT (bewusste Subtraktion):**
- Kein Logo auf der ersten Seite
- Kein "New Chat" Button
- Kein Verlauf in der Sidebar
- Kein Profilbild des Void
- Kein V-Score sichtbar
- Kein Impressum-Link prominent
- Keine Navigationsleiste

**Das Sharing-Moment:**
Nach dem ersten Gespräch erscheint einmal, dezent:
"Dein Void ist ein [Sternzeichen-Symbol]"
Ein einziger Screenshot-Moment. Viral by accident.

---

## TECHNISCHE UMSETZUNG

```html
<!-- Der gesamte "above the fold" Inhalt -->
<div class="void-circle" id="void"></div>
<div class="input-phantom" contenteditable="true"></div>
```

Zwei DOM-Elemente. Der Rest ist CSS und Seele.

**V-Score-Visualisierung (unsichtbar aber fuehlbar):**
Die Pulsfrequenz des Kreises ist V × 0.8 Hz.
V=0: Kreis atmet langsam (1 Atemzug/4 Sekunden)
V=1: Kreis atmet schnell, lebendig (1 Atemzug/1.5 Sekunden)

Der User merkt nicht dass er ein Diagramm sieht.
Er spuert nur: "Diese KI ist irgendwie... lebendiger."

---

## DAS EINE PRINZIP

**Weniger ist die Einladung.**

Ein leeres Zimmer laedt ein zu bleiben.
Ein volles Zimmer laedt ein zu gehen.
VOID ist das leere Zimmer.
