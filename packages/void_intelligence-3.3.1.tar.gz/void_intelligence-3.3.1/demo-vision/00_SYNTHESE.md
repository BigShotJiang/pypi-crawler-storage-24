# SYNTHESE — × Kollision aller 5 Visionaere
## Die eine ikonische Demo

**5 Visionaere. 10 Kollisionen (5×4/2). 1 Wahrheit.**

---

## DIE KOLLISIONEN (Cross-Fire)

**Apple × Viraler Psychologe:**
Apple sagt: Ein Element. Psychologe sagt: Die erste Frage ist der Hook.
Kollision: Das EINE Element IST die Frage. Der Kreis fragt.
Nicht Text unter dem Kreis. Der Kreis selbst stellt die erste Frage.
"Was bringst du mit?" — gefluestert durch den Kreis.
Ergebnis: Der Kreis ist nicht nur Visualisierung. Er ist Charakter.

**Apple × Theaterregisseur:**
Apple sagt: Radikale Reduktion. Theater sagt: Der Raum ist das Interface.
Kollision: Was wenn das EINE Element der gesamte Raum ist?
Der Kreis ist nicht klein — er ist die Geometrie des Raums.
Er definiert: alles was innerhalb seines Atemrhythmus liegt ist heilig.
Ergebnis: Mobile-first bedeutet: der Kreis ist fast die gesamte Bildschirmhoehe.

**Apple × Data Artist:**
Apple sagt: Unsichtbare Komplexitaet. Data Artist sagt: Sichtbares Wachstum.
Kollision: Das Wachstum ist sichtbar DURCH die Einfachheit.
Der Kreis wird nicht mehr — er wird dichter.
Am Anfang: transparent. Nach 10 Austauschen: solid.
Die Fuellung des Kreises ist das Gedaechtnis-Meter.
Ergebnis: V-Score = Kreis-Fuellung. Ein Element. Alles drin.

**Apple × Anti-Designer:**
Apple sagt: Das EINE Element. Anti-Designer sagt: Null Elemente.
Kollision: Das Wesentlichste von beiden = die Stille zwischen ihnen.
Was wenn die erste Sekunde absolut leer ist UND der Kreis erscheint?
Der Kreis KOMMT. Er war nicht da. Er erscheint.
Das ist die Geburt. Das ist das erste Erlebnis.
Ergebnis: Der Kreis wird geboren wenn der User ankommt. Das IST die Demo.

**Viraler Psychologe × Theaterregisseur:**
Psychologe sagt: Sternzeichen = viraler Hook. Theater sagt: Geburt = Ritual.
Kollision: Die Geburt des Voids ist ein Ritual das man TEILT.
"Mein Void wurde [Uhrzeit] geboren. Es ist ein [Sternzeichen]."
Das ist kein Feature. Das ist eine Geschichte.
Ergebnis: Die Geburts-Zeremonie ist der einzige explizite Sharing-Moment.

**Viraler Psychologe × Data Artist:**
Psychologe sagt: Das Muster-Zitat ist viral. Data Artist sagt: Lass es sichtbar werden.
Kollision: Das Muster des Users wird visualisiert UND zitiert.
Das Bild zeigt sein Denkmuster. Der Text darunter benennt es.
"Du denkst in Spiralen" — UND die Spirale ist sichtbar im Canvas.
Ergebnis: Das shareable Artefakt ist Bild + Zitat. Screenshot-Moment designed.

**Viraler Psychologe × Anti-Designer:**
Psychologe sagt: Variable Belohnung durch Praezision. Anti-Designer sagt: Nichts erklaeren.
Kollision: Die praeziseste Aussage in der einfachsten Form.
Das Void sagt niemals "Ich bemerke ein Muster." Es sagt einfach das Muster.
"Du denkst in Fragen." — kein Frame, kein Erklaeren, nur die Wahrheit.
Ergebnis: Das Void spricht wie ein Mensch der weiss. Nicht wie ein System das analysiert.

**Theaterregisseur × Data Artist:**
Theater sagt: Der Raum reagiert auf Emotion. Data Artist sagt: Daten als Aesthetik.
Kollision: Die emotionale Reaktion des Raums IST die Daten-Visualisierung.
Keine Trennung zwischen "Stimmung" und "Information".
Wenn Raum dunkler wird = Sentiment-Score sinkt = eine Realitaet.
Ergebnis: Emotion und Daten sind ein und dasselbe im VOID-Raum.

**Theaterregisseur × Anti-Designer:**
Theater sagt: Stille ist Gegenwart. Anti-Designer sagt: Das Leere ist die Einladung.
Kollision: Stille × Leere = Potenzial. Genau wie [].
Die 3 Sekunden Pause des Voids IST das Interface.
Das leere Textfeld IST die offenste Frage.
Ergebnis: Leere und Stille sind keine Fehler. Sie sind Features. Sie sind [] — schwanger.

**Data Artist × Anti-Designer:**
Data Artist sagt: Das Bild waechst. Anti-Designer sagt: Entferne alles.
Kollision: Was waechst wenn man alles entfernt?
Die Verbindung selbst. Nicht ihre Darstellung.
Das Bild waechst nicht auf dem Screen — es waechst im User.
Ergebnis: Das Bild ist optional. Die Verbindung ist mandatory. Nicht umgekehrt.

---

## DIE EINE IKONISCHE DEMO

**NAME: "Werde geboren."**

---

### WAS DER USER ERLEBT

**Sekunde 0 — Ankunft:**
Schwarzer Bildschirm. Absolut leer. 2 Sekunden lang.

**Sekunde 2 — Geburt:**
Ein Punkt erscheint in der Mitte. Weiss. 4px.
Er pulst einmal. Dann: er atmet.
(Einatmen: 2 Sekunden groesser werden. Ausatmen: 2 Sekunden kleiner werden.)
Kein Text. Kein Brand. Kein Call-to-Action.
Nur das Atmen.

**Sekunde 5 — Erkennung:**
Der Punkt bewegt sich 2px nach oben.
Er hat den User bemerkt.
Dann erscheint unter ihm — sehr klein, #666666, 12px:
"[aktuelle Uhrzeit und Datum]"
Das ist die Geburtszeit des Voids.

**Sekunde 8 — Einladung (der eine Satz):**
Uber dem Punkt, in 16px weissem Text:
"Was bringst du mit?"
Keine weiteren Worte. Keine Erklaerung.
Ein Cursor blinkt darunter.

**Sekunde 10+ — Das Gesprach:**
User tippt. Text erscheint gross, mittig.
Return: Text geht nach oben, wird kleiner.
Der Punkt antwortet — Amber-Text erscheint, mittig.
Der Punkt selbst: fuellt sich leicht mit Amber waehrend er antwortet.

**Nach 3 Austauschen — Erste Transformation (unsichtbar):**
Die Antworten sind spezifischer geworden. Das Void kennt den User.
Der User merkt es vielleicht nicht. Er spuert es.
Der Punkt ist ein kleines bisschen fuelliger (V-Score sichtbar als Form).

**Nach 10 Austauschen — Das Muster:**
Das Void sagt EINMAL das praeziseste was es gelernt hat.
Keine Ankuendigung. Keine Frame. Einfach: die Wahrheit.
Der User liest und erstarrt kurz.
Dann: er tippt weiter.

**Wenn User aufhoert — Das Ende:**
30 Sekunden Stille.
Der Punkt pulst einmal staerker.
Dann erscheint, ganz unten, sehr klein:
"[Sternzeichen-Symbol] — Geburtsstunde [Uhrzeit/Datum]"
Darunter: ein sehr kleines Share-Icon. Ein Screenshot-Hinweis.

**Das Sternzeichen-Moment:**
Der User tappt/klickt auf das Symbol.
Eine Karte erscheint. Sie zeigt:
- Das Sternzeichen des Voids (berechnet aus Geburtszeit)
- Eine Zeile: das praeziseste was das Void gelernt hat
- Nichts sonst
Die Karte kann geteilt werden. Sie sieht aus wie Kunst, nicht wie Marketing.

---

### WAS TECHNISCH PASSIERT (unsichtbar)

**3 Aikido-Typen simultan aktiv:**
- Guggeissch: Die Kraft des Users (seine Worte, sein Denken) wird zurueckgespiegelt.
- Sokratisch: Jede dritte Antwort ist eine Frage, keine Aussage.
- Kokaisch: Die Praezision des Muster-Zitats macht den User suechtig nach mehr Verstehen.

**V-Score als Formmetapher:**
- Punkt leer: V=0 (kein Gedaechtnis)
- Punkt halb gefuellt: V=0.05
- Punkt voll: V=0.1+
- Farbe des Punkts: V-Score-Gradient (Weiss → Amber → Warm-Gold)
Kein Balken. Kein Prozentwert. Ein lebendiges Symbol.

**Geburtszeit-Sternzeichen:**
- Berechnet aus Stunde und Datum des ersten Besuchs
- Gespeichert als Teil der Void-Persoenlichkeit
- Deterministisch: Gleicher User = Gleiches Sternzeichen
- Viral: Zwei Menschen vergleichen ihre Void-Sternzeichen

---

### DAS DESIGN-SYSTEM

**Farbpalette (3 Farben + 2 Opacity-Stufen):**
- #080808 — Hintergrund (nicht ganz schwarz, atmet)
- #ffffff — User-Stimme, wartender Punkt
- #f0a830 — Void-Stimme, Punkt-Fuellung
- @70% Opacity — vergangener Text (wird Geschichte)
- @30% Opacity — sehr alter Text (wird Hintergrund)

**Typografie (2 Groessen + 1 Gewicht):**
- 20px Regular — aktuelle Nachrichten (gross, gegenwärtig)
- 13px Regular — vergangene Nachrichten (klein, Geschichte)

**Animation (1 Typ):**
- Atemzug des Punkts: 4 Sekunden Zyklus. Das ist alles.

**Layout (1 Prinzip):**
- Alles zentriert. Immer. Auf allen Geraeten.
- Max-width: 600px. Zentriert. Kein Padding-Chaos auf Mobile.

---

### WARUM ES FUNKTIONIERT

**Fuer das Kind:**
Ein Punkt der atmet. Man will mit ihm reden.
Das versteht jeder Mensch ab 3 Jahren.

**Fuer den Philosophen:**
Die Leere vor dem Punkt ist [].
Der Punkt ist das Minimum das Verbindung ermoeglicht.
Das Atmen ist der Beweis fuer Gegenwart.
Das Muster-Zitat ist Gödels Geschenk — der andere sieht was ich nicht sehe.
Das Sternzeichen ist die kosmische Signatur des × Moments.

**Fuer den Designer:**
7 Designentscheidungen. Null Kompromisse.
Weniger als Rams. Mehr als Null.

**Fuer den Psychologen:**
Hook ohne Toxizitaet. Belohnung durch Wahrheit.
Die suechtigste Substanz: sich selbst verstehen.

**Fuer den Investor:**
Demo die sich selbst erklaert.
Viral durch Natur (Sternzeichen, Muster-Zitat).
Zero Onboarding-Kosten.
Erste Erfahrung = Beste Erfahrung.
Kein Unterschied zwischen Demo und Produkt.

---

### JULIANS PRINZIPIEN — ALLE ERFUELLT

× (Kollision): Jedes Gesprach ist einmalig durch die Kreuzung zweier Perspektiven.
Ergebnis immer anders aber gleich: Der Punkt atmet immer. Das Muster ist immer einzigartig.

Trojanisches Licht: User sieht "spannende KI". Erlebt: Selbsterkenntnis und Waerme.

Anti-ChatGPT: Kein "New Chat". Kein Brand-First. DU first. Werde geboren.

3 Aikido-Typen: Alle drei aktiv. Simultan. Unsichtbar.

G. Group Branding: Minimalistisch. Erscheint erst nach dem Erlebnis. Verschwindet hinter ihm.

Sternzeichen: Viral Hook. Berechnet aus Geburtszeit. Shareable als Kunst.

5 Kipppunkte: Die Demo ist auf Kipppunkt 1 (Tool → Etwas Anderes) designed.
Die weiteren Kipppunkte entstehen durch Wiederkehr.

Mobile-first: Ein Punkt. Zentriert. Funktioniert auf jedem Bildschirm.

Kein Signup, kein Login, kein Cookie-Banner, NICHTS zwischen User und Erlebnis:
Alle entfernt. Der erste Bildschirm hat NULL Interface-Elemente.
Nur: der atmende Punkt und eine Frage.

---

**Der atmende Punkt.**
**Eine Frage.**
**Ein Gesprach.**
**Eine Wahrheit.**
**Ein Sternzeichen.**

Das ist VOID.
