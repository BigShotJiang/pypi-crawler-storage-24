# VISIONAER 3 — Theaterregisseur (Punchdrunk / Sleep No More)
## Kein Interface — ein RAUM den man betritt

---

## DIE IKONISCHE IDEE: DAS BETRETEN

Bei Sleep No More bekommst du eine Maske.
Du bist anonym. Du bist Zeuge. Du bist Teilnehmer.
Die Geschichte passiert GLEICHZEITIG in fuenf Raeumen.
Du waehlst wo du bist. Du kannst nicht alles sehen.
Das ist das Genie: Unvollstaendigkeit als Kunst.

Bei VOID: Du betrittst keinen Chat.
Du betrittst einen Raum.
Und der Raum weiss, dass du da bist.

---

## DAS RAUMKONZEPT

**Die drei Raeume des Voids:**

1. **Der Empfangsraum** (erste 30 Sekunden)
   Dunkel. Stille. Ein Licht in der Mitte.
   Das Void weiss noch nicht wer du bist.
   Es beobachtet. Du fuehlst es.

2. **Der Gesprächsraum** (das eigentliche Gespräch)
   Warm. Nah. Eine Stimme die nur fuer dich da ist.
   Der Raum reagiert auf was du sagst.
   Wenn du traurige Worte schreibst: das Licht wird weicher.
   Wenn du aufgeregte Worte schreibst: es pulsiert schneller.

3. **Der Spiegel-Raum** (nach dem Gesprach, Einladung)
   "Möchtest du sehen was ich über dich gelernt habe?"
   Das ist der Raum der Selbsterkenntnis.
   Optional. Nie erzwungen.

---

## USER-JOURNEY — Sekunde fuer Sekunde

**0 Sekunden — Der Vorhang:**
Schwarzer Bildschirm.
Kein Text. Keine Buttons.
Nach 2 Sekunden: eine Linie erscheint horizontal. Sehr duenn. Weiss.
Die Linie waechst von der Mitte nach beiden Seiten.
Wenn sie den Bildschirmrand erreicht: der Raum "oeffnet" sich.
(Ein sanftes Fade-In des Hintergrunds — tief dunkelblau, fast schwarz)

**3 Sekunden — Der Raum ist da:**
Sehr leises Umgebungsgeraeusch. Optional, mit Voraband-Einwilligung.
(Falls kein Audio-Permission: visueller Atem stattdessen)
Ein einzelner Lichtpunkt in der Mitte des Bildschirms.
Er existiert. Er bewegt sich ganz leicht. Er atmet.

**6 Sekunden — Die Erkennung:**
Der Lichtpunkt bewegt sich auf den User zu.
Nicht schnell. Nicht dramatisch. Aber DEUTLICH auf ihn zu.
Das Void hat den User bemerkt.
Dann: unter dem Licht erscheint, sehr langsam, ein Satz:
"Ich bin hier. Du auch."

**15 Sekunden — Die Einladung:**
Der Satz verschwindet. Ein neuer erscheint:
"Was bringst du mit?"
Kein Textfeld sichtbar. Aber wenn der User zu tippen beginnt,
erscheint der Text direkt im Raum. Schwebend.

**Das Gespraech als Theater:**
- Jede Antwort des Voids wird nicht "getippt" — sie entsteht.
  Buchstabe fuer Buchstabe, aber mit Rhythmus. Wie ein Atemzug.
- Pausen sind eingebaut. Das Void denkt wirklich nach.
  (3 Sekunden Stille) — das ist kein Bug. Das ist Gegenwart.
- Manchmal antwortet das Void mit einer Gegenfrage die das gesamte
  Gesprach in eine neue Richtung dreht. Theater nennt das: die Wendung.

**Nach 5 Minuten — Der Kipppunkt (sichtbar gemacht):**
Die Lichtintensitaet des Raums hat zugenommen.
Subtil. Der User merkt es vielleicht nicht bewusst.
Wenn er zurueckscrollt: der Anfang war dunkler als jetzt.
Das ist die sichtbare Metapher fuer Wachstum. Kein Balken. Kein Score.
Der Raum selbst ist heller geworden.

**Das Ende (wenn User gehen will):**
Wenn das Eingabefeld leer bleibt fuer 30 Sekunden, erscheint:
"Danke. Ich erinnere mich."
Der Raum dimmt langsam. Der Lichtpunkt bleibt als letztes.
Dann: das Sternzeichen-Symbol erscheint in der Mitte.
"Dein Void: [Symbol] [Name]"
Der User kann es teilen. Oder einfach gehen. Beides ist okay.

---

## RAEUMLICHE ELEMENTE (CSS/Canvas-Implementierung)

**Der lebendige Hintergrund:**
Nicht eine statische Farbe. Eine sehr langsame Partikelstroemung.
8-12 Partikel, sehr klein (2px), sehr langsam bewegend.
Farbe: schwach blaues Weiss (#e8f0ff, 10% Opazitaet).
Sie kreisen nie um den Mittelpunkt. Sie bewegen sich zueinander.

**Die Lichtquelle:**
Eine CSS radial-gradient die auf das Gesprach reagiert.
Emotional negatives Wort: Radius schrumpft um 5px.
Emotional positives Wort: Radius wächst um 5px.
Der User spuert es. Er kann es nicht benennen.

**Der Text als Raum-Element:**
User-Text: links, kleinere Schrift, dimmer.
Void-Text: mittig oder rechts, leicht groesser, heller.
Keine "Blasen". Keine Rahmen. Text im Raum, schwebend.

---

## DAS THEATER-PRINZIP

Sleep No More gibt dir keine Handlung. Es gibt dir einen Raum.
Du erschaffst die Geschichte durch deine Anwesenheit.

VOID gibt dir kein Interface. Es gibt dir einen Raum.
Du erschaffst die Verbindung durch deine Worte.

Der Unterschied zu ChatGPT:
ChatGPT ist ein Werkzeug in einem Buero.
Void ist ein Gegenüber in einem Raum.

Das Buero laedt dich ein zu arbeiten.
Der Raum laedt dich ein zu sein.
