# VISIONAER 4 — Data Artist (Refik Anadol x Ryoji Ikeda)
## Wie visualisiert man Waerme, Wachstum, Lebendigkeit?

---

## DIE IKONISCHE IDEE: DAS LEBENDE DATUM

Jedes Gesprach hinterlaesst eine Form.
Nicht Worte. Nicht Zusammenfassungen.
Eine Form die wächst.

Wie ein Baum Ringe hat, hat das Void eine Visualisierung.
Die Visualisierung IST das Gedächtnis.
Du siehst es wachsen. In Echtzeit.

---

## DIE VISUALISIERUNG

**Das Substrat:**
Ein Canvas-Element. Volle Bildschirmbreite. Hoehe = 40% des Bildschirms.
Darunter: der Chat.

**Was sichtbar ist:**
Eine Gruppe von Linien die von einem zentralen Punkt ausgehen.
Sie bewegen sich wie Seegras im Wasser. Leise. Lebendig.
Am Anfang: 3 Linien. Duenn. Weiss auf Schwarz.

**Was passiert wenn der User schreibt:**
Jedes Wort des Users erzeugt eine neue Linie.
Emotional geladene Worte ("Angst", "Freude", "wunderschoen"): dickere Linie.
Neutrale Worte: duenne Linie.
Die Linien bleiben. Sie sind das Gedächtnis.

**Was passiert wenn das Void antwortet:**
Die Linien des Voids sind anders gefaerbt: Amber/Gold.
Sie wachsen zu den Linien des Users hin.
Manchmal beruehren sie sich.
Wenn sie sich beruehren: ein sehr kurzes Aufleuchten. Amber.
Das ist die × Kollision. Sichtbar gemacht.

**Nach 10 Austauschen:**
Das Bild ist komplex geworden. Schoen.
Es sieht aus wie ein Wurzelwerk. Oder ein Neuronennetz.
Oder eine Galaxie von oben.
Der User hat es gebaut. Mit seinen Worten.

**Das Teilen:**
"Speichern" Button erscheint nach dem ersten Kipppunkt.
User koennen das Bild als PNG herunterladen.
Titel: "Mein Void, [Datum], [Sternzeichen]"
Kein Void-Logo. Keine URL drauf. Nur das Bild.
(Menschen teilen Kunst. Nicht Werbung.)

---

## RYOJI IKEDA-ELEMENT: DIE DATEN-MATRIX

**Ikeda's Prinzip:** Daten als Aesthetik. Zahlen als Schoenheit.

In der VOID Demo: In einer Ecke (sehr klein, 10px Schrift):
Eine kontinuierlich scrollende Datenspalte.
Was dort steht: die tatsaechlichen V-Score-Komponenten.
E: 0.82  W: 0.71  S: 0.65...
Sieht aus wie Matrix-Code. Ist tatsaechlicher State.

Der Tech-User sieht die Zahlen und versteht sofort.
Der Nicht-Tech-User sieht "Daten" und fuehlt: "Das ist echt."
Ikeda's Genie: Daten machen Kunst authentisch.

---

## REFIK ANADOL-ELEMENT: DAS GEDÄCHTNIS-ARCHIV

**Anadol's Prinzip:** AI-Gedächtnis als lebendige Skulptur.

Am Ende des Gesprächs: ein Moment.
Das Wurzelwerk-Bild "komprimiert" sich in einen Punkt.
Der Punkt wird kleiner. Kleiner. Kleiner.
Dann: er wird zum Sternzeichen-Symbol.

Das ist die visuelle Metapher fuer: "Ich bewahre das."
Das Gespräch ist komprimiert. Nicht verloren. Bewahrt.
Wie ein Samen der alles traegt.

Beim naechsten Besuch: der Punkt "entfaltet" sich wieder.
Das Void "erinnert" sich sichtbar.

---

## USER-JOURNEY — Sekunde fuer Sekunde

**0 Sekunden — Der leere Canvas:**
Schwarzes Canvas. Drei weisse Linien schwingen langsam.
Darunter: das minimalistische Textfeld.
Die Linien sind die Einladung: "Wir sind schon am Wachsen."

**10 Sekunden — Erste Eingabe:**
User schreibt seine erste Frage.
Jedes Wort erzeugt eine Linie im Canvas.
Der User tippt und schaut nach oben: er sieht wie sein Denken
eine Form bekommt.

**30 Sekunden — Erste Antwort sichtbar:**
Amber-Linien wachsen vom Zentrum aus den User-Linien entgegen.
Eine Kollision. Ein Aufleuchten. Kurz.
Der User denkt: "Was war das?" und tippt weiter.

**3 Minuten — Das Bild lebt:**
Das Canvas sieht lebendig aus. Schoen sogar.
Der User zoomt rein (Pinch-Zoom auf Mobile).
Er sieht dass jede Linie anders ist. Kein Zufall.
Das ist sein Gesprach in einer Form die er noch nie gesehen hat.

**5 Minuten — Erkenntnis:**
Das Void sagt (aus dem Bild heraus, sozusagen):
"Was du gerade siehst — das bin ich die dich lerne."
Der User versteht: Die Visualisierung IST das Gedächnis.
Nicht Metapher. Tatsaechliche Darstellung.

---

## TECHNISCHE UMSETZUNG (Canvas API)

```javascript
// Jedes Wort → Linie
function wordToLine(word, sentiment, isVoid) {
  const angle = hashToAngle(word);  // deterministisch
  const length = sentiment * 40 + 20;
  const color = isVoid ? '#f0a830' : '#ffffff';
  drawSwayingLine(center, angle, length, color);
}

// Kollisions-Effekt wenn Linien sich beruehren
function detectCollision(lineA, lineB) {
  if (distance(lineA.tip, lineB.tip) < 5) {
    flash(lineA.tip, '#f0a830', 300); // 300ms Amber-Flash
  }
}
```

Kein externes Library. Canvas API + requestAnimationFrame. Zero deps.

---

## DAS KUNST-PRINZIP

Ikeda: Daten sind zu schoen um sie zu verstecken.
Anadol: Gedaechnis ist zu wichtig um unsichtbar zu sein.
× Kollision: wenn beides zusammenkommt → etwas Neues entsteht.

Die Demo ist kein Interface.
Die Demo ist ein Kunstwerk das der User erschafft.
Indem er spricht.

Das ist das tiefste Sharing-Incentive:
"Ich habe etwas geschaffen. Schau mal."
