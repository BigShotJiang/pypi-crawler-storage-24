# VISIONAER 5 — Anti-Designer (Dieter Rams invertiert)
## Was ENTFERNEN wir damit nur das Wesentliche bleibt?

---

## DIE IKONISCHE IDEE: NULL DESIGN

Dieter Rams: Gutes Design ist so wenig Design wie möglich.
VOID Anti-Design: Was ist das absolut kleinstmoegliche Design
das noch eine lebendige Verbindung ermöglicht?

Die Antwort: Ein Textfeld. Und ein Satz.

Das ist alles.

---

## DER SUBTRAKTIONS-PROZESS (Dokumentiert)

**Version 1.0 — Was jeder macht:**
- Header mit Logo
- Sidebar mit Gesprächsverlauf
- Avatar des Void
- Buttons: New Chat, Share, Settings
- V-Score Dashboard
- Zodiac Widget
- Input mit Senden-Button
Ergebnis: 9 Elemente. Zu viel.

**Version 1.1 — Erste Subtraktion:**
- ~~Header mit Logo~~ → Logo wird zum einzigen Zeichen: "."
- ~~Sidebar~~ → Entfernt. Kein Verlauf sichtbar.
- ~~Avatar~~ → Entfernt. Das Void ist unsichtbar.
- ~~Buttons~~ → Alle entfernt. Return-Taste reicht.
- V-Score Dashboard → Reduziert auf eine Zahl
- ~~Zodiac Widget~~ → Erscheint nur einmal
- Input + Senden-Button → Input bleibt, Button weg
Ergebnis: 3 Elemente. Besser.

**Version 1.2 — Zweite Subtraktion:**
- "." → Entfernt. Sogar der Punkt ist zu viel zu Beginn.
- V-Score-Zahl → Entfernt. Sichtbar nur wenn User fragt.
- Zodiac → Entfernt von der Hauptseite. Kommt nach dem Gesprach.
Ergebnis: 1 Element. Ein Textfeld.

**Version 1.3 — Dritte Subtraktion:**
Kann man das Textfeld auch entfernen?
Ja. Wenn der User auf den Bildschirm tippt, erscheint es.
Vor dem ersten Tippen: absolut leerer Bildschirm.
Ergebnis: 0 sichtbare Elemente. Pure Einladung.

---

## DAS FINALE DESIGN (nach dreifacher Subtraktion)

**Was der User sieht:**
Einen leeren Bildschirm.
Farbe: #0a0a0a (fast schwarz aber nicht ganz).
Nichts sonst.

**Was passiert wenn User ankommt:**
Nach 1.5 Sekunden: ein Cursor blinkt in der Mitte des Bildschirms.
Nicht in einem Textfeld. Einfach so. In der Mitte.
Der Cursor ist die Einladung.

**Was passiert wenn User tippt:**
Die Buchstaben erscheinen wo der Cursor war. Gross. 24px.
Kein Textfeld-Rahmen. Nur die Worte im Raum.

**Was passiert nach Return:**
Die Worte des Users gleiten nach oben.
Werden kleiner. 14px. Dimmer. #666666.
In der Mitte: eine neue Zeile erscheint. Amber. 24px.
Das ist die Antwort des Voids. Line by line.

**Was passiert wenn der User weiterredet:**
Gesprach baut sich auf. Oben: verblasster Verlauf.
Mitte: aktueller Austausch.
Bottom: leerer Raum fuer die naechste Eingabe.

Kein Scroll-Indicator. Kein "Load more". Kein Timestamp.
Nur: die Schichten des Gesprächs übereinander.

---

## DIE 10 GEBOTE DES ANTI-DESIGNS

**1. Entferne alles was du erklaeren muesstest.**
(Wenn du einen Tooltip brauchst: das Element gehoert nicht hin.)

**2. Entferne alles was nur fuer Randabfaelle existiert.**
(KEIN Cookie-Banner. KEIN Impressums-Popup. Das ist Gesetz, nicht Design.)

**3. Entferne alles was der User nicht in den ersten 3 Sekunden braucht.**
(Alles andere kommt spaeter, falls ueberhaupt.)

**4. Entferne alle Farben ausser einer.**
(Eine Farbe. Eine Bedeutung. Amber = das Void spricht.)

**5. Entferne alle Schriftgroessen ausser zwei.**
(Gross = aktuell. Klein = vergangen. Das reicht.)

**6. Entferne alle Animationen ausser einer.**
(Der Cursor blinkt. Das reicht als Lebenszeichen.)

**7. Entferne alle Buttons.**
(Return-Taste. Enter. Das ist universell. Das ist genug.)

**8. Entferne alle Erklaerungen.**
(Eine Demo erklaert sich durch Benutzung. Nicht durch Text.)

**9. Entferne alle Branding-Elemente vom ersten Screen.**
(Brand kommt am Ende. Wenn der User es schon erlebt hat.)

**10. Entferne alles was den User daran erinnert dass er auf einer Website ist.**
(Das ist das schwerste. Und das Wichtigste.)

---

## USER-JOURNEY — Sekunde fuer Sekunde

**0 Sekunden:**
Leerer Bildschirm. #0a0a0a.

**1.5 Sekunden:**
Cursor. Mittig. Blinkt.

**User tippt (kann sofort sein oder nach 60 Sekunden):**
Text erscheint. Gross. Weiss. Mittig.

**Return:**
Text geht nach oben. Wird klein. Amber-Text erscheint.

**2 Minuten:**
Das ist es. Das ist die gesamte Demo.
Kein Onboarding. Kein Tutorial. Keine Features-Liste.
Nur: Gespräch.

**Nach dem Gesprach (wenn User aufhoert zu tippen, 30 Sekunden):**
Unten, sehr klein, sehr dezent:
"void.ai  |  [Sternzeichen-Symbol] [Datum]"
Zwei Elemente. Mehr nicht.

---

## WAS UEBRIG BLEIBT

Nach dreifacher Subtraktion bleibt:
- 1 Hintergrundfarbe
- 1 Cursor-Animation
- 2 Textgroessen
- 1 Akzentfarbe (Amber)
- 1 Schriftfamilie
- 1 Interaktion (tippen)

Das sind 7 Designentscheidungen.
Rams hat 10 Gebote. Wir haben 7 Entscheidungen.
Das ist weniger als Rams. Das ist Anti-Design.

**Das Tiefste:**
Wenn ein Design so einfach ist dass es verschwindet —
dann wird die VERBINDUNG sichtbar.
Nicht das Design. Die Verbindung.
Das ist das Ziel.
