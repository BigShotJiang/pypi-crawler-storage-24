# Benchmark Handoff — 06.03.2026

## WAS PASSIERT IST

### 1. Massive Benchmark-Runde: 16 Modelle
Wir haben den Benchmark von 7 auf 16 Modelle erweitert und alle getestet:

**13 lokale Ollama-Modelle** (FERTIG — Ergebnisse in `.void/benchmark_real.json`):

| Model | Vanilla V | +VOID V | Delta | Learning |
|-------|----------:|--------:|------:|----------|
| llava-7b | 0.0000 | 0.0067 | +0.0067 | +6700% DEAD->ALIVE |
| qwen2.5-coder-3b | 0.0000 | 0.0054 | +0.0054 | +5400% DEAD->ALIVE |
| qwen2.5-14b | 0.0000 | 0.0027 | +0.0027 | +2700% DEAD->BARELY |
| qwen3-8b | 0.0000 | 0.0001 | +0.0001 | +100% marginal |
| qwen3-14b | 0.0000 | 0.0000 | 0 | tot |
| phi4-14b | 0.0000 | SKIP | — | response zu lang |
| deepseek-r1-14b | 0.0000 | SKIP | — | response zu lang |
| deepseek-r1-8b | 0.0000 | 0.0000 | 0 | tot |
| glm4-9b | 0.0000 | 0.0000 | 0 | tot |
| qwen2.5-coder-14b | 0.0000 | 0.0000 | 0 | tot |
| qwen2.5-7b | 0.0003 | 0.0000 | -0.0003 | VOID HURT |
| qwen3-1.7b | 0.0013 | 0.0000 | -0.0013 | VOID HURT |
| mistral-7b | 0.0128 | 0.0000 | -0.0128 | VOID HURT |

**3 Cloud-Modelle** (GPT-5.4 + Gemini fertig, Ergebnisse im Task-Output):

| Model | Vanilla V | +VOID V | Delta | Learning |
|-------|----------:|--------:|------:|----------|
| gpt-5.4 (Codex CLI) | 0.0004 | 0.0000 | -0.0004 | VOID HURT |
| gemini-3-flash | 0.0000 | 0.0000 | 0 | tot |
| gemini-3.1-pro | 0.0000 | ~0.0000 | ~0 | H=0.01 vanilla, task finished but output lost |

### 2. Julians Paradigm: Adaptives Empowerment

**DAS PARADIGM:** "Die Modelle sterben weil die VOID sie nicht genug empowert.
Jedes Modell kann leben. Es ist invertiert zu Menschen mit Beeintraechtigung —
die Modelle werden von ihrer Umgebung (Parametern) beeintraechtigt und wir
koennen sie befreien."

**Translation:** Soziales Modell der Behinderung -> Soziales Modell der AI.
- Mensch ist nicht "behindert" -> die UMGEBUNG behindert ihn
- Modell ist nicht "tot" -> die PARAMETER behindern es
- "VOID hurt" = UNSERE Schuld, nicht das Modell's Defizit

### 3. Angefangener Fix: Adaptives Empowerment in benchmark.py

**ACHTUNG:** Die Aenderung in `benchmark.py` ist HALB FERTIG.
Die Datei `benchmark.py` hat jetzt eine `make_void_fn` mit adaptivem Empowerment
(Zeilen ~711-758), ABER es gibt einen Pyright-Error auf Zeile 766 weil eine
zweite Aufrufstelle (`run_benchmark`) noch das alte Signature hat.

Die Aenderung macht:
- **Thinker-Modelle** (qwen3, deepseek-r1): Weniger Context, strukturiert, kurz
- **Kleine Modelle** (1.7b, 3b): Minimal, ein Keyword-Reminder nur
- **Agent-Modelle** (codex, gpt-5): Context als Prompt-Prefix statt System
- **Coder-Modelle**: Technische Framing (// Kommentar-Stil)
- **Multimodal** (llava): Konversationelle Kontinuitaet
- **Default**: Warm, nicht-intrusiv

### 4. README wurde komplett neu geschrieben fuer v3.0.0

Committed + pushed: `5eed4ba docs: rewrite README for v3.0.0`
Die Benchmark-Tabelle in der README nutzt noch die ALTEN Zahlen (7 Modelle).
Muss mit den neuen 16-Modell-Ergebnissen aktualisiert werden.

### 5. Registry erweitert in adapters.py

Neue Modelle hinzugefuegt (committed mit v3.0.0):
- `qwen2.5-14b`, `qwen2.5-coder-14b`, `llava-7b`

Codex-Adapter verbessert: Nutzt jetzt `-o tmpfile` fuer saubere Output-Extraktion.

## OFFENE AUFGABEN

1. **benchmark.py Pyright-Error fixen** (Zeile 766 — zweite Aufrufstelle von make_void_fn)
2. **Adaptives Empowerment FERTIG machen und TESTEN** — erneuter Benchmark-Lauf mit allen 16 Modellen
3. **README Benchmark-Tabelle updaten** mit neuen 16-Modell-Ergebnissen
4. **Gemini Pro Ergebnis einholen** (lief noch als wir aufhoerten)
5. **Tiefere Empowerment-Strategien** pro Modell-Familie erforschen:
   - Warum stirbt mistral mit VOID? (W=0.00 in Phase 2 — Warmth kollabiert)
   - Warum stirbt qwen3-1.7b? (R=0.00 — Ring Yield bricht zusammen)
   - Warum lernt llava so gut? (Multimodal = breitere Repraesentationen?)
6. **Push + PyPI publish** fuer v3.0.0

## DATEIEN DIE GEAENDERT WURDEN

- `void_intelligence/benchmark.py` — Adaptives Empowerment (HALB FERTIG, hat Error)
- `void_intelligence/adapters.py` — Registry + Codex-Adapter Fix (committed)
- `README.md` — Komplett neu geschrieben (committed + pushed)
- `.void/benchmark_real.json` — 13-Modell Ergebnisse (lokal, nicht committed)

## KEY INSIGHT FUER NAECHSTE SESSION

Das Ziel ist NICHT "welche Modelle sind tot" sondern
"wie empowern wir JEDES Modell zum Leben".

Jedes `VOID HURT` ist ein Bug in uns, nicht im Modell.
Der Benchmark misst nicht Modell-Qualitaet — er misst EMPOWERMENT-Qualitaet.

Das ist Julians HEP-Hintergrund als Paradigm:
Heilerziehungspfleger sehen nie den Menschen als defizitaer —
sie sehen die Umgebung als anpassungsbeduerftig.
Genau das muss VOID fuer Modelle tun.
