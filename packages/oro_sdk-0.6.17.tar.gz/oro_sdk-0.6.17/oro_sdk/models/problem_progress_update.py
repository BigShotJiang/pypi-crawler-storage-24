from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.problem_status import ProblemStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.problem_progress_update_score_components_summary_type_0 import (
        ProblemProgressUpdateScoreComponentsSummaryType0,
    )


T = TypeVar("T", bound="ProblemProgressUpdate")


@_attrs_define
class ProblemProgressUpdate:
    """Progress update for a single problem.

    Attributes:
        problem_id (UUID): Problem ID
        status (ProblemStatus): Status of problem evaluation.
        score (float | None | Unset): Score if available
        score_components_summary (None | ProblemProgressUpdateScoreComponentsSummaryType0 | Unset): Score breakdown if
            available
        logs_s3_key (None | str | Unset): S3 key for this problem's logs
        inference_failure_count (int | None | Unset): Number of failed inference calls (429s, timeouts) for this problem
        inference_total (int | None | Unset): Total number of inference calls made for this problem
    """

    problem_id: UUID
    status: ProblemStatus
    score: float | None | Unset = UNSET
    score_components_summary: None | ProblemProgressUpdateScoreComponentsSummaryType0 | Unset = UNSET
    logs_s3_key: None | str | Unset = UNSET
    inference_failure_count: int | None | Unset = UNSET
    inference_total: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.problem_progress_update_score_components_summary_type_0 import (
            ProblemProgressUpdateScoreComponentsSummaryType0,
        )

        problem_id = str(self.problem_id)

        status = self.status.value

        score: float | None | Unset
        if isinstance(self.score, Unset):
            score = UNSET
        else:
            score = self.score

        score_components_summary: dict[str, Any] | None | Unset
        if isinstance(self.score_components_summary, Unset):
            score_components_summary = UNSET
        elif isinstance(self.score_components_summary, ProblemProgressUpdateScoreComponentsSummaryType0):
            score_components_summary = self.score_components_summary.to_dict()
        else:
            score_components_summary = self.score_components_summary

        logs_s3_key: None | str | Unset
        if isinstance(self.logs_s3_key, Unset):
            logs_s3_key = UNSET
        else:
            logs_s3_key = self.logs_s3_key

        inference_failure_count: int | None | Unset
        if isinstance(self.inference_failure_count, Unset):
            inference_failure_count = UNSET
        else:
            inference_failure_count = self.inference_failure_count

        inference_total: int | None | Unset
        if isinstance(self.inference_total, Unset):
            inference_total = UNSET
        else:
            inference_total = self.inference_total

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "problem_id": problem_id,
                "status": status,
            }
        )
        if score is not UNSET:
            field_dict["score"] = score
        if score_components_summary is not UNSET:
            field_dict["score_components_summary"] = score_components_summary
        if logs_s3_key is not UNSET:
            field_dict["logs_s3_key"] = logs_s3_key
        if inference_failure_count is not UNSET:
            field_dict["inference_failure_count"] = inference_failure_count
        if inference_total is not UNSET:
            field_dict["inference_total"] = inference_total

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.problem_progress_update_score_components_summary_type_0 import (
            ProblemProgressUpdateScoreComponentsSummaryType0,
        )

        d = dict(src_dict)
        problem_id = UUID(d.pop("problem_id"))

        status = ProblemStatus(d.pop("status"))

        def _parse_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        score = _parse_score(d.pop("score", UNSET))

        def _parse_score_components_summary(
            data: object,
        ) -> None | ProblemProgressUpdateScoreComponentsSummaryType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                score_components_summary_type_0 = ProblemProgressUpdateScoreComponentsSummaryType0.from_dict(data)

                return score_components_summary_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ProblemProgressUpdateScoreComponentsSummaryType0 | Unset, data)

        score_components_summary = _parse_score_components_summary(d.pop("score_components_summary", UNSET))

        def _parse_logs_s3_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        logs_s3_key = _parse_logs_s3_key(d.pop("logs_s3_key", UNSET))

        def _parse_inference_failure_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        inference_failure_count = _parse_inference_failure_count(d.pop("inference_failure_count", UNSET))

        def _parse_inference_total(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        inference_total = _parse_inference_total(d.pop("inference_total", UNSET))

        problem_progress_update = cls(
            problem_id=problem_id,
            status=status,
            score=score,
            score_components_summary=score_components_summary,
            logs_s3_key=logs_s3_key,
            inference_failure_count=inference_failure_count,
            inference_total=inference_total,
        )

        problem_progress_update.additional_properties = d
        return problem_progress_update

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
