from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.validator_status import ValidatorStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.validator_current_agent import ValidatorCurrentAgent
    from ..models.validator_public_service_versions_type_0 import ValidatorPublicServiceVersionsType0


T = TypeVar("T", bound="ValidatorPublic")


@_attrs_define
class ValidatorPublic:
    """Public representation of a validator.

    Attributes:
        hotkey (str): Validator's SS58 address
        status (ValidatorStatus): Status of a validator.
        registered_at (datetime.datetime): When validator was registered
        name (None | str | Unset): On-chain identity name, if set
        last_claim_at (datetime.datetime | None | Unset): Last work claim time
        last_seen_at (datetime.datetime | None | Unset): Last time validator was seen
        current_agent (None | Unset | ValidatorCurrentAgent): Agent currently being evaluated, if any
        service_versions (None | Unset | ValidatorPublicServiceVersionsType0): Docker image digests for validator stack
            services
        identity_url (None | str | Unset): On-chain identity URL
        identity_image (None | str | Unset): On-chain identity image URL
        identity_description (None | str | Unset): On-chain identity description
    """

    hotkey: str
    status: ValidatorStatus
    registered_at: datetime.datetime
    name: None | str | Unset = UNSET
    last_claim_at: datetime.datetime | None | Unset = UNSET
    last_seen_at: datetime.datetime | None | Unset = UNSET
    current_agent: None | Unset | ValidatorCurrentAgent = UNSET
    service_versions: None | Unset | ValidatorPublicServiceVersionsType0 = UNSET
    identity_url: None | str | Unset = UNSET
    identity_image: None | str | Unset = UNSET
    identity_description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.validator_current_agent import ValidatorCurrentAgent
        from ..models.validator_public_service_versions_type_0 import ValidatorPublicServiceVersionsType0

        hotkey = self.hotkey

        status = self.status.value

        registered_at = self.registered_at.isoformat()

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        last_claim_at: None | str | Unset
        if isinstance(self.last_claim_at, Unset):
            last_claim_at = UNSET
        elif isinstance(self.last_claim_at, datetime.datetime):
            last_claim_at = self.last_claim_at.isoformat()
        else:
            last_claim_at = self.last_claim_at

        last_seen_at: None | str | Unset
        if isinstance(self.last_seen_at, Unset):
            last_seen_at = UNSET
        elif isinstance(self.last_seen_at, datetime.datetime):
            last_seen_at = self.last_seen_at.isoformat()
        else:
            last_seen_at = self.last_seen_at

        current_agent: dict[str, Any] | None | Unset
        if isinstance(self.current_agent, Unset):
            current_agent = UNSET
        elif isinstance(self.current_agent, ValidatorCurrentAgent):
            current_agent = self.current_agent.to_dict()
        else:
            current_agent = self.current_agent

        service_versions: dict[str, Any] | None | Unset
        if isinstance(self.service_versions, Unset):
            service_versions = UNSET
        elif isinstance(self.service_versions, ValidatorPublicServiceVersionsType0):
            service_versions = self.service_versions.to_dict()
        else:
            service_versions = self.service_versions

        identity_url: None | str | Unset
        if isinstance(self.identity_url, Unset):
            identity_url = UNSET
        else:
            identity_url = self.identity_url

        identity_image: None | str | Unset
        if isinstance(self.identity_image, Unset):
            identity_image = UNSET
        else:
            identity_image = self.identity_image

        identity_description: None | str | Unset
        if isinstance(self.identity_description, Unset):
            identity_description = UNSET
        else:
            identity_description = self.identity_description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hotkey": hotkey,
                "status": status,
                "registered_at": registered_at,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if last_claim_at is not UNSET:
            field_dict["last_claim_at"] = last_claim_at
        if last_seen_at is not UNSET:
            field_dict["last_seen_at"] = last_seen_at
        if current_agent is not UNSET:
            field_dict["current_agent"] = current_agent
        if service_versions is not UNSET:
            field_dict["service_versions"] = service_versions
        if identity_url is not UNSET:
            field_dict["identity_url"] = identity_url
        if identity_image is not UNSET:
            field_dict["identity_image"] = identity_image
        if identity_description is not UNSET:
            field_dict["identity_description"] = identity_description

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.validator_current_agent import ValidatorCurrentAgent
        from ..models.validator_public_service_versions_type_0 import ValidatorPublicServiceVersionsType0

        d = dict(src_dict)
        hotkey = d.pop("hotkey")

        status = ValidatorStatus(d.pop("status"))

        registered_at = isoparse(d.pop("registered_at"))

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_last_claim_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_claim_at_type_0 = isoparse(data)

                return last_claim_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_claim_at = _parse_last_claim_at(d.pop("last_claim_at", UNSET))

        def _parse_last_seen_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_seen_at_type_0 = isoparse(data)

                return last_seen_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_seen_at = _parse_last_seen_at(d.pop("last_seen_at", UNSET))

        def _parse_current_agent(data: object) -> None | Unset | ValidatorCurrentAgent:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                current_agent_type_0 = ValidatorCurrentAgent.from_dict(data)

                return current_agent_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | ValidatorCurrentAgent, data)

        current_agent = _parse_current_agent(d.pop("current_agent", UNSET))

        def _parse_service_versions(data: object) -> None | Unset | ValidatorPublicServiceVersionsType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                service_versions_type_0 = ValidatorPublicServiceVersionsType0.from_dict(data)

                return service_versions_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | ValidatorPublicServiceVersionsType0, data)

        service_versions = _parse_service_versions(d.pop("service_versions", UNSET))

        def _parse_identity_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        identity_url = _parse_identity_url(d.pop("identity_url", UNSET))

        def _parse_identity_image(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        identity_image = _parse_identity_image(d.pop("identity_image", UNSET))

        def _parse_identity_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        identity_description = _parse_identity_description(d.pop("identity_description", UNSET))

        validator_public = cls(
            hotkey=hotkey,
            status=status,
            registered_at=registered_at,
            name=name,
            last_claim_at=last_claim_at,
            last_seen_at=last_seen_at,
            current_agent=current_agent,
            service_versions=service_versions,
            identity_url=identity_url,
            identity_image=identity_image,
            identity_description=identity_description,
        )

        validator_public.additional_properties = d
        return validator_public

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
