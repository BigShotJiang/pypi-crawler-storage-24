"""
协议抽象基类
定义统一的文件传输协议接口，便于扩展新协议
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Callable, Tuple
from pathlib import Path
import hashlib
from dataclasses import dataclass
from enum import Enum


class TransferStatus(Enum):
    """传输状态枚举"""
    PENDING = "pending"
    UPLOADING = "uploading"
    DOWNLOADING = "downloading"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class FileInfo:
    """文件信息数据类"""
    path: str
    size: int
    is_directory: bool
    modified_time: float
    permissions: Optional[str] = None
    checksum: Optional[str] = None


@dataclass
class TransferProgress:
    """传输进度数据类"""
    file_path: str
    total_size: int
    transferred_size: int
    speed: float  # bytes/second
    status: TransferStatus
    error_message: Optional[str] = None
    start_time: Optional[float] = None
    estimated_time_remaining: Optional[float] = None
    is_skipped: bool = False  # 是否为跳过（双端一致）而非实际传输
    
    @property
    def progress_percentage(self) -> float:
        """计算传输进度百分比"""
        if self.total_size == 0:
            return 100.0
        return (self.transferred_size / self.total_size) * 100.0


class ProtocolClient(ABC):
    """协议客户端抽象基类"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        初始化协议客户端
        
        Args:
            config: 协议配置字典
        """
        self.config = config
        self.is_connected = False
        self._progress_callback: Optional[Callable[[TransferProgress], None]] = None
    
    @abstractmethod
    async def connect(self) -> bool:
        """
        连接到远程服务器
        
        Returns:
            是否连接成功
        """
        pass
    
    @abstractmethod
    async def disconnect(self) -> None:
        """断开连接"""
        pass
    
    @abstractmethod
    async def list_directory(self, remote_path: str) -> List[FileInfo]:
        """
        列出远程目录内容
        
        Args:
            remote_path: 远程目录路径
            
        Returns:
            文件信息列表
        """
        pass
    
    @abstractmethod
    async def upload_file(self, local_path: str, remote_path: str, 
                         progress_callback: Optional[Callable[[TransferProgress], None]] = None) -> bool:
        """
        上传单个文件
        
        Args:
            local_path: 本地文件路径
            remote_path: 远程文件路径
            progress_callback: 进度回调函数
            
        Returns:
            是否上传成功
        """
        pass
    
    @abstractmethod
    async def download_file(self, remote_path: str, local_path: str,
                           progress_callback: Optional[Callable[[TransferProgress], None]] = None) -> bool:
        """
        下载单个文件
        
        Args:
            remote_path: 远程文件路径
            local_path: 本地文件路径
            progress_callback: 进度回调函数
            
        Returns:
            是否下载成功
        """
        pass
    
    @abstractmethod
    async def create_directory(self, remote_path: str) -> bool:
        """
        创建远程目录
        
        Args:
            remote_path: 远程目录路径
            
        Returns:
            是否创建成功
        """
        pass
    
    @abstractmethod
    async def remove_file(self, remote_path: str) -> bool:
        """
        删除远程文件
        
        Args:
            remote_path: 远程文件路径
            
        Returns:
            是否删除成功
        """
        pass
    
    @abstractmethod
    async def remove_directory(self, remote_path: str) -> bool:
        """
        删除远程目录
        
        Args:
            remote_path: 远程目录路径
            
        Returns:
            是否删除成功
        """
        pass
    
    @abstractmethod
    async def file_exists(self, remote_path: str) -> bool:
        """
        检查远程文件是否存在
        
        Args:
            remote_path: 远程文件路径
            
        Returns:
            文件是否存在
        """
        pass
    
    @abstractmethod
    async def get_file_info(self, remote_path: str) -> Optional[FileInfo]:
        """
        获取远程文件信息
        
        Args:
            remote_path: 远程文件路径
            
        Returns:
            文件信息，如果文件不存在返回None
        """
        pass
    
    def set_progress_callback(self, callback: Callable[[TransferProgress], None]) -> None:
        """
        设置进度回调函数
        
        Args:
            callback: 进度回调函数
        """
        self._progress_callback = callback
    
    def calculate_file_checksum(self, file_path: str, algorithm: str = 'md5', max_size_for_full_hash: int = 1024*1024) -> Optional[str]:
        """
        计算文件校验和（针对大文件优化）
        
        Args:
            file_path: 文件路径
            algorithm: 哈希算法 (md5, sha1, sha256)
            max_size_for_full_hash: 全文件哈希的最大文件大小（字节）
            
        Returns:
            文件校验和，计算失败返回None
        """
        try:
            file_path_obj = Path(file_path)
            if not file_path_obj.exists():
                return None
            
            file_size = file_path_obj.stat().st_size
            hash_obj = hashlib.new(algorithm)
            
            # 小文件：全文件哈希
            if file_size <= max_size_for_full_hash:
                with open(file_path, 'rb') as f:
                    while chunk := f.read(8192):
                        hash_obj.update(chunk)
            else:
                # 大文件：采样哈希法（固定位置采样，确保一致性）
                with open(file_path, 'rb') as f:
                    # 添加文件大小到哈希（确保不同大小文件有不同哈希）
                    hash_obj.update(str(file_size).encode())
                    
                    # 计算采样点（固定算法确保一致性）
                    sample_size = 8192  # 每个采样点8KB
                    max_samples = 16    # 最多16个采样点
                    
                    if file_size <= sample_size * max_samples:
                        # 文件较小，采样所有位置
                        num_samples = file_size // sample_size
                    else:
                        # 大文件，固定采样点数
                        num_samples = max_samples
                    
                    if num_samples > 0:
                        for i in range(num_samples):
                            # 计算采样位置（均匀分布）
                            position = (file_size * i) // num_samples
                            f.seek(position)
                            
                            # 读取采样数据
                            sample_data = f.read(min(sample_size, file_size - position))
                            hash_obj.update(sample_data)
                            
                            # 添加位置信息到哈希（增加唯一性）
                            hash_obj.update(str(position).encode())
                    
            return hash_obj.hexdigest()
            
        except Exception:
            return None
    
    
    async def verify_file_integrity(self, local_path: str, remote_path: str) -> bool:
        """
        验证文件完整性
        
        Args:
            local_path: 本地文件路径
            remote_path: 远程文件路径
            
        Returns:
            文件是否完整
        """
        try:
            # 获取本地文件信息
            local_file = Path(local_path)
            if not local_file.exists():
                return False
            
            # 获取远程文件信息
            remote_info = await self.get_file_info(remote_path)
            if not remote_info:
                return False
            
            # 比较文件大小
            if local_file.stat().st_size != remote_info.size:
                return False
            
            # 如果配置启用校验和验证
            if self.config.get('verify_checksum', True):
                local_checksum = self.calculate_file_checksum(local_path)
                if local_checksum and remote_info.checksum:
                    return local_checksum == remote_info.checksum
            
            return True
            
        except Exception:
            return False
    
    async def files_are_identical(self, local_path: str, remote_path: str) -> bool:
        """
        检查本地和远程文件是否相同（避免重复传输）
        
        Args:
            local_path: 本地文件路径
            remote_path: 远程文件路径
            
        Returns:
            文件是否相同
        """
        try:
            # 检查本地文件是否存在
            local_file = Path(local_path)
            if not local_file.exists():
                return False
            
            # 检查远程文件是否存在
            if not await self.file_exists(remote_path):
                return False
            
            # 获取远程文件信息
            remote_info = await self.get_file_info(remote_path)
            if not remote_info:
                return False
            
            local_stat = local_file.stat()
            
            # 首先比较文件大小（快速排除）
            if local_stat.st_size != remote_info.size:
                return False
            
            # 计算本地文件校验和
            local_checksum = self.calculate_file_checksum(local_path)
            if not local_checksum:
                return False
            
            # 如果远程有校验和，直接比较
            if remote_info.checksum:
                return local_checksum == remote_info.checksum
            
            # 如果远程没有校验和，计算远程校验和进行比较
            remote_checksum = await self._calculate_remote_checksum(remote_path)
            if not remote_checksum:
                return False
                
            return local_checksum == remote_checksum
            
        except Exception:
            return False
    
    def normalize_path(self, path: str) -> str:
        """
        标准化路径格式
        
        Args:
            path: 原始路径
            
        Returns:
            标准化后的路径
        """
        # 转换为正斜杠（Unix风格）
        normalized = path.replace('\\', '/')
        
        # 移除重复的斜杠
        while '//' in normalized:
            normalized = normalized.replace('//', '/')
        
        # 确保目录路径以斜杠结尾
        if normalized.endswith('/') and len(normalized) > 1:
            normalized = normalized.rstrip('/')
            
        return normalized
    
    def get_connection_info(self) -> Dict[str, Any]:
        """
        获取连接信息
        
        Returns:
            连接信息字典
        """
        return {
            'protocol': self.__class__.__name__.lower().replace('client', ''),
            'host': self.config.get('host', ''),
            'port': self.config.get('port', 0),
            'username': self.config.get('username', ''),
            'is_connected': self.is_connected
        }
    
    async def test_connection(self) -> Tuple[bool, Optional[str]]:
        """
        测试连接
        
        Returns:
            (是否连接成功, 错误消息)
        """
        try:
            success = await self.connect()
            if success:
                await self.disconnect()
                return True, None
            else:
                return False, "连接失败"
                
        except Exception as e:
            return False, str(e)
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        if self.is_connected:
            # 注意：这里应该是同步版本，但我们的接口是异步的
            # 在实际实现中，子类可能需要提供同步版本的disconnect方法
            pass
    
    async def __aenter__(self):
        """异步上下文管理器入口"""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器出口"""
        await self.disconnect()
