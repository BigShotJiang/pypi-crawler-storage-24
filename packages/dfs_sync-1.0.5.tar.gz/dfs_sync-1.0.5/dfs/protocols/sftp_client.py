"""
SFTP协议客户端实现
基于paramiko库实现SFTP文件传输功能
"""

import asyncio
import time
import hashlib
from typing import List, Dict, Any, Optional, Callable
from pathlib import Path
import paramiko
from paramiko import SSHClient, SFTPClient as ParamikoSFTPClient
import stat
import os

from .base import ProtocolClient, FileInfo, TransferProgress, TransferStatus


class SFTPClient(ProtocolClient):
    """SFTP协议客户端实现"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        初始化SFTP客户端
        
        Args:
            config: SFTP配置字典，包含host、port、username、password等
        """
        super().__init__(config)
        self.ssh_client: Optional[SSHClient] = None
        self.sftp_client: Optional[ParamikoSFTPClient] = None
        
        # 初始化日志器
        from ..core.logger import get_logger
        self.logger = get_logger('dfs.protocols.sftp')
        
        # 从配置中提取连接参数
        self.host = config.get('host', '')
        self.port = config.get('port', 22)
        self.username = config.get('username', '')
        self.password = config.get('password', '')
        self.private_key_path = config.get('private_key', '')
        self.timeout = config.get('timeout', 30)
        
        # 传输配置
        self.chunk_size = config.get('chunk_size', 8192)
        self.max_retries = config.get('max_retries', 3)
        self.retry_delay = config.get('retry_delay', 1.0)
    
    async def connect(self) -> bool:
        """
        连接到SFTP服务器
        
        Returns:
            是否连接成功
        """
        try:
            # 创建SSH客户端
            self.ssh_client = SSHClient()
            self.ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            # 准备认证参数
            connect_kwargs = {
                'hostname': self.host,
                'port': self.port,
                'username': self.username,
                'timeout': self.timeout
            }
            
            # 选择认证方式
            if self.private_key_path and os.path.exists(self.private_key_path):
                # 使用私钥认证
                try:
                    private_key = paramiko.RSAKey.from_private_key_file(self.private_key_path)
                    connect_kwargs['pkey'] = private_key
                except Exception:
                    try:
                        private_key = paramiko.Ed25519Key.from_private_key_file(self.private_key_path)
                        connect_kwargs['pkey'] = private_key
                    except Exception:
                        # 如果私钥加载失败，尝试密码认证
                        if self.password:
                            connect_kwargs['password'] = self.password
            elif self.password:
                # 使用密码认证
                connect_kwargs['password'] = self.password
            else:
                raise ValueError("必须提供密码或私钥进行认证")
            
            # 在线程池中执行连接（因为paramiko是同步的）
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, lambda: self.ssh_client.connect(**connect_kwargs))
            
            # 创建SFTP客户端
            self.sftp_client = self.ssh_client.open_sftp()
            self.is_connected = True
            
            return True
            
        except Exception as e:
            self.is_connected = False
            if self.ssh_client:
                self.ssh_client.close()
                self.ssh_client = None
            raise ConnectionError(f"SFTP连接失败: {e}")
    
    async def disconnect(self) -> None:
        """断开SFTP连接"""
        try:
            if self.sftp_client:
                self.sftp_client.close()
                self.sftp_client = None
            
            if self.ssh_client:
                self.ssh_client.close()
                self.ssh_client = None
                
            self.is_connected = False
            
        except Exception:
            pass  # 忽略断开连接时的错误
    
    async def list_directory(self, remote_path: str) -> List[FileInfo]:
        """
        列出远程目录内容
        
        Args:
            remote_path: 远程目录路径
            
        Returns:
            文件信息列表
        """
        if not self.is_connected or not self.sftp_client:
            raise ConnectionError("SFTP未连接")
        
        try:
            remote_path = self.normalize_path(remote_path)
            self.logger.debug(f"开始列出目录: {remote_path}")
            
            start_time = time.time()
            # 在线程池中执行（paramiko是同步的）
            loop = asyncio.get_event_loop()
            file_attrs = await loop.run_in_executor(
                None, self.sftp_client.listdir_attr, remote_path
            )
            
            list_time = time.time() - start_time
            self.logger.debug(f"列出目录 {remote_path} 耗时: {list_time:.2f}s, 发现 {len(file_attrs)} 个项目")
            
            file_infos = []
            for attr in file_attrs:
                file_info = FileInfo(
                    path=self.normalize_path(f"{remote_path}/{attr.filename}"),
                    size=attr.st_size or 0,
                    is_directory=stat.S_ISDIR(attr.st_mode) if attr.st_mode else False,
                    modified_time=attr.st_mtime or 0,
                    permissions=oct(attr.st_mode)[-3:] if attr.st_mode else None
                )
                file_infos.append(file_info)
            
            total_time = time.time() - start_time
            self.logger.debug(f"完成目录列表 {remote_path}: {total_time:.2f}s")
            return file_infos
            
        except Exception as e:
            self.logger.error(f"列出目录失败 {remote_path}: {e}")
            raise IOError(f"列出目录失败 {remote_path}: {e}")
    
    async def upload_file(self, local_path: str, remote_path: str,
                         progress_callback: Optional[Callable[[TransferProgress], None]] = None) -> bool:
        """
        上传单个文件
        
        Args:
            local_path: 本地文件路径
            remote_path: 远程文件路径
            progress_callback: 进度回调函数
            
        Returns:
            是否上传成功
        """
        if not self.is_connected or not self.sftp_client:
            raise ConnectionError("SFTP未连接")
        
        local_file = Path(local_path)
        if not local_file.exists():
            raise FileNotFoundError(f"本地文件不存在: {local_path}")
        
        if local_file.is_dir():
            raise ValueError(f"不能上传目录作为文件: {local_path}")
        
        remote_path = self.normalize_path(remote_path)
        file_size = local_file.stat().st_size
        
        # 创建进度对象
        progress = TransferProgress(
            file_path=local_path,
            total_size=file_size,
            transferred_size=0,
            speed=0.0,
            status=TransferStatus.UPLOADING,
            start_time=time.time()
        )
        
        try:
            # 确保远程目录存在
            remote_dir = '/'.join(remote_path.split('/')[:-1])
            if remote_dir:
                await self._ensure_remote_directory(remote_dir)
            
            # 使用回调函数上传文件
            def upload_callback(transferred: int, total: int):
                if progress_callback:
                    current_time = time.time()
                    elapsed_time = current_time - progress.start_time
                    
                    progress.transferred_size = transferred
                    if elapsed_time > 0:
                        progress.speed = transferred / elapsed_time
                        if progress.speed > 0:
                            remaining_bytes = total - transferred
                            progress.estimated_time_remaining = remaining_bytes / progress.speed
                    
                    progress_callback(progress)
            
            # 在线程池中执行上传（添加超时控制）
            loop = asyncio.get_event_loop()
            await asyncio.wait_for(
                loop.run_in_executor(
                    None,
                    lambda: self.sftp_client.put(
                        local_path, remote_path, callback=upload_callback
                    )
                ),
                timeout=300  # 5分钟超时
            )
            
            # 更新最终状态
            progress.status = TransferStatus.COMPLETED
            progress.transferred_size = file_size
            if progress_callback:
                progress_callback(progress)
            
            return True
            
        except Exception as e:
            progress.status = TransferStatus.FAILED
            progress.error_message = str(e)
            if progress_callback:
                progress_callback(progress)
            raise IOError(f"上传文件失败 {local_path} -> {remote_path}: {e}")
    
    async def download_file(self, remote_path: str, local_path: str,
                           progress_callback: Optional[Callable[[TransferProgress], None]] = None) -> bool:
        """
        下载单个文件
        
        Args:
            remote_path: 远程文件路径
            local_path: 本地文件路径
            progress_callback: 进度回调函数
            
        Returns:
            是否下载成功
        """
        if not self.is_connected or not self.sftp_client:
            raise ConnectionError("SFTP未连接")
        
        remote_path = self.normalize_path(remote_path)
        
        # 获取远程文件信息
        try:
            loop = asyncio.get_event_loop()
            remote_stat = await loop.run_in_executor(
                None, self.sftp_client.stat, remote_path
            )
            file_size = remote_stat.st_size
        except Exception as e:
            raise FileNotFoundError(f"远程文件不存在: {remote_path}")
        
        # 确保本地目录存在
        local_file = Path(local_path)
        local_file.parent.mkdir(parents=True, exist_ok=True)
        
        # 创建进度对象
        progress = TransferProgress(
            file_path=remote_path,
            total_size=file_size,
            transferred_size=0,
            speed=0.0,
            status=TransferStatus.DOWNLOADING,
            start_time=time.time()
        )
        
        try:
            # 使用回调函数下载文件
            def download_callback(transferred: int, total: int):
                if progress_callback:
                    current_time = time.time()
                    elapsed_time = current_time - progress.start_time
                    
                    progress.transferred_size = transferred
                    if elapsed_time > 0:
                        progress.speed = transferred / elapsed_time
                        if progress.speed > 0:
                            remaining_bytes = total - transferred
                            progress.estimated_time_remaining = remaining_bytes / progress.speed
                    
                    progress_callback(progress)
            
            # 在线程池中执行下载
            await loop.run_in_executor(
                None,
                lambda: self.sftp_client.get(
                    remote_path, local_path, callback=download_callback
                )
            )
            
            # 更新最终状态
            progress.status = TransferStatus.COMPLETED
            progress.transferred_size = file_size
            if progress_callback:
                progress_callback(progress)
            
            return True
            
        except Exception as e:
            progress.status = TransferStatus.FAILED
            progress.error_message = str(e)
            if progress_callback:
                progress_callback(progress)
            
            # 删除不完整的本地文件
            if local_file.exists():
                local_file.unlink()
                
            raise IOError(f"下载文件失败 {remote_path} -> {local_path}: {e}")
    
    async def create_directory(self, remote_path: str) -> bool:
        """
        创建远程目录
        
        Args:
            remote_path: 远程目录路径
            
        Returns:
            是否创建成功
        """
        if not self.is_connected or not self.sftp_client:
            raise ConnectionError("SFTP未连接")
        
        try:
            remote_path = self.normalize_path(remote_path)
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self.sftp_client.mkdir, remote_path)
            return True
            
        except Exception as e:
            raise IOError(f"创建目录失败 {remote_path}: {e}")
    
    async def remove_file(self, remote_path: str) -> bool:
        """
        删除远程文件
        
        Args:
            remote_path: 远程文件路径
            
        Returns:
            是否删除成功
        """
        if not self.is_connected or not self.sftp_client:
            raise ConnectionError("SFTP未连接")
        
        try:
            remote_path = self.normalize_path(remote_path)
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self.sftp_client.remove, remote_path)
            return True
            
        except Exception as e:
            raise IOError(f"删除文件失败 {remote_path}: {e}")
    
    async def remove_directory(self, remote_path: str) -> bool:
        """
        删除远程目录
        
        Args:
            remote_path: 远程目录路径
            
        Returns:
            是否删除成功
        """
        if not self.is_connected or not self.sftp_client:
            raise ConnectionError("SFTP未连接")
        
        try:
            remote_path = self.normalize_path(remote_path)
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self.sftp_client.rmdir, remote_path)
            return True
            
        except Exception as e:
            raise IOError(f"删除目录失败 {remote_path}: {e}")
    
    async def file_exists(self, remote_path: str) -> bool:
        """
        检查远程文件是否存在
        
        Args:
            remote_path: 远程文件路径
            
        Returns:
            文件是否存在
        """
        if not self.is_connected or not self.sftp_client:
            raise ConnectionError("SFTP未连接")
        
        try:
            remote_path = self.normalize_path(remote_path)
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self.sftp_client.stat, remote_path)
            return True
            
        except FileNotFoundError:
            return False
        except Exception:
            return False
    
    async def get_file_info(self, remote_path: str) -> Optional[FileInfo]:
        """
        获取远程文件信息
        
        Args:
            remote_path: 远程文件路径
            
        Returns:
            文件信息，如果文件不存在返回None
        """
        if not self.is_connected or not self.sftp_client:
            raise ConnectionError("SFTP未连接")
        
        try:
            remote_path = self.normalize_path(remote_path)
            loop = asyncio.get_event_loop()
            file_stat = await loop.run_in_executor(None, self.sftp_client.stat, remote_path)
            
            # 对于小文件，计算校验和
            checksum = None
            if not stat.S_ISDIR(file_stat.st_mode) and file_stat.st_size <= 10*1024*1024:  # 10MB以下计算校验和
                try:
                    checksum = await self._calculate_remote_checksum(remote_path)
                except Exception:
                    pass  # 校验和计算失败不影响文件信息获取
            
            return FileInfo(
                path=remote_path,
                size=file_stat.st_size,
                is_directory=stat.S_ISDIR(file_stat.st_mode),
                modified_time=file_stat.st_mtime,
                permissions=oct(file_stat.st_mode)[-3:] if file_stat.st_mode else None,
                checksum=checksum
            )
            
        except Exception:
            return None
    
    async def get_file_info_basic(self, remote_path: str) -> Optional[FileInfo]:
        """
        获取远程文件基础信息（不计算校验和，用于任务添加阶段）
        
        Args:
            remote_path: 远程文件路径
            
        Returns:
            文件基础信息，如果文件不存在返回None
        """
        if not self.is_connected or not self.sftp_client:
            raise ConnectionError("SFTP未连接")
        
        try:
            remote_path = self.normalize_path(remote_path)
            loop = asyncio.get_event_loop()
            file_stat = await loop.run_in_executor(None, self.sftp_client.stat, remote_path)
            
            # 任务添加阶段不计算校验和，延后到实际传输时计算
            return FileInfo(
                path=remote_path,
                size=file_stat.st_size,
                is_directory=stat.S_ISDIR(file_stat.st_mode),
                modified_time=file_stat.st_mtime,
                permissions=oct(file_stat.st_mode)[-3:] if file_stat.st_mode else None,
                checksum=None  # 延后计算
            )
            
        except Exception:
            return None
    
    async def get_files_info_batch_basic(self, remote_paths: List[str], max_concurrent: int = 8) -> Dict[str, Optional[FileInfo]]:
        """
        批量获取远程文件基础信息（不计算校验和，用于任务添加阶段）
        
        Args:
            remote_paths: 远程文件路径列表
            max_concurrent: 最大并发数（当前使用串行处理确保稳定性）
            
        Returns:
            文件路径到文件信息的映射
        """
        if not remote_paths:
            return {}
        
        self.logger.debug(f"开始批量获取 {len(remote_paths)} 个文件的基础信息")
        start_time = time.time()
        results = {}
        
        # 使用串行处理确保稳定性，但仍然比原来的get_file_info快很多
        # 因为不计算校验和，每个文件只需要1次网络请求而不是100+次
        for i, path in enumerate(remote_paths):
            try:
                file_start = time.time()
                info = await self.get_file_info_basic(path)
                file_time = time.time() - file_start
                results[path] = info
                self.logger.debug(f"文件 {i+1}/{len(remote_paths)} ({os.path.basename(path)}): {file_time:.3f}s")
            except Exception as e:
                self.logger.debug(f"获取文件基础信息失败 {path}: {e}")
                results[path] = None
        
        total_time = time.time() - start_time
        success_count = sum(1 for v in results.values() if v is not None)
        self.logger.debug(f"批量获取完成: {total_time:.2f}s, 成功 {success_count}/{len(remote_paths)} 个文件")
        
        return results
    
    async def _calculate_remote_checksum(self, remote_path: str) -> Optional[str]:
        """
        计算远程文件的校验和（与本地算法保持一致）
        
        Args:
            remote_path: 远程文件路径
            
        Returns:
            文件校验和
        """
        if not self.is_connected or not self.sftp_client:
            return None
        
        try:
            loop = asyncio.get_event_loop()
            
            # 获取文件大小
            file_stat = await loop.run_in_executor(None, self.sftp_client.stat, remote_path)
            file_size = file_stat.st_size
            
            hash_obj = hashlib.md5()
            max_size_for_full_hash = 1024*1024  # 1MB
            
            # 小文件：全文件哈希
            if file_size <= max_size_for_full_hash:
                remote_file = None
                try:
                    remote_file = await loop.run_in_executor(None, self.sftp_client.open, remote_path, 'rb')
                    while True:
                        chunk = await loop.run_in_executor(None, remote_file.read, 8192)
                        if not chunk:
                            break
                        hash_obj.update(chunk)
                finally:
                    if remote_file is not None:
                        try:
                            await loop.run_in_executor(None, remote_file.close)
                        except Exception as e:
                            # 记录关闭文件句柄失败，但不抛出异常
                            pass
            else:
                # 大文件：采样哈希法（与本地算法完全一致）
                remote_file = None
                try:
                    remote_file = await loop.run_in_executor(None, self.sftp_client.open, remote_path, 'rb')
                    # 添加文件大小到哈希（确保不同大小文件有不同哈希）
                    hash_obj.update(str(file_size).encode())
                    
                    # 计算采样点（与本地算法相同）
                    sample_size = 8192  # 每个采样点8KB
                    max_samples = 16    # 最多16个采样点
                    
                    if file_size <= sample_size * max_samples:
                        # 文件较小，采样所有位置
                        num_samples = file_size // sample_size
                    else:
                        # 大文件，固定采样点数
                        num_samples = max_samples
                    
                    if num_samples > 0:
                        for i in range(num_samples):
                            # 计算采样位置（均匀分布）
                            position = (file_size * i) // num_samples
                            await loop.run_in_executor(None, remote_file.seek, position)
                            
                            # 读取采样数据
                            remaining_size = file_size - position
                            read_size = min(sample_size, remaining_size)
                            sample_data = await loop.run_in_executor(None, remote_file.read, read_size)
                            hash_obj.update(sample_data)
                            
                            # 添加位置信息到哈希（增加唯一性）
                            hash_obj.update(str(position).encode())
                            
                finally:
                    if remote_file is not None:
                        try:
                            await loop.run_in_executor(None, remote_file.close)
                        except Exception as e:
                            # 记录关闭文件句柄失败，但不抛出异常
                            pass
            
            return hash_obj.hexdigest()
            
        except Exception:
            return None
    
    async def _ensure_remote_directory(self, remote_path: str) -> None:
        """
        确保远程目录存在，如果不存在则递归创建
        
        Args:
            remote_path: 远程目录路径
        """
        if not remote_path or remote_path in ['/', '/root', '/home', '/usr', '/var', '/tmp']:
            # 跳过系统目录和根目录
            return
        
        try:
            # 递归创建父目录
            parent_path = '/'.join(remote_path.split('/')[:-1])
            if parent_path and parent_path != remote_path and parent_path != '/':
                await self._ensure_remote_directory(parent_path)
            
            # 尝试创建当前目录
            try:
                await asyncio.wait_for(self.create_directory(remote_path), timeout=10)
                pass  # 目录创建成功
            except Exception as create_error:
                error_msg = str(create_error).lower()
                if ("exists" in error_msg or "file exists" in error_msg or 
                    "failure" in error_msg):
                    # 目录已存在或其他可忽略的错误
                    pass  # 目录已存在或创建失败（可忽略）
                    return
                else:
                    # 其他不可忽略的错误
                    raise create_error
            
        except asyncio.TimeoutError:
            raise Exception(f"目录操作超时: {remote_path}")
        except Exception as e:
            error_msg = str(e).lower()
            if not ("exists" in error_msg or "file exists" in error_msg or "failure" in error_msg):
                raise
