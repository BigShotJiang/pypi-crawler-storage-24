#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
文件信息缓存模块
提供远程文件信息的缓存和批量获取功能，优化文件校验性能
"""

import time
import asyncio
import hashlib
from typing import Dict, List, Optional, Set, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path
import json
import threading

from ..protocols.base import FileInfo


@dataclass
class CachedFileInfo:
    """缓存的文件信息"""
    file_info: FileInfo
    cache_time: float  # 缓存时间戳
    access_count: int = 0  # 访问次数
    last_access: float = 0  # 最后访问时间
    
    def is_expired(self, max_age: float) -> bool:
        """检查缓存是否过期"""
        return time.time() - self.cache_time > max_age
    
    def mark_accessed(self) -> None:
        """标记被访问"""
        self.access_count += 1
        self.last_access = time.time()


class FileInfoCache:
    """文件信息缓存管理器"""
    
    def __init__(self, 
                 max_cache_size: int = 10000,
                 default_ttl: float = 300.0,  # 5分钟默认TTL
                 cleanup_interval: float = 60.0):  # 1分钟清理间隔
        """
        初始化文件信息缓存
        
        Args:
            max_cache_size: 最大缓存条目数
            default_ttl: 默认缓存存活时间（秒）
            cleanup_interval: 缓存清理间隔（秒）
        """
        self.max_cache_size = max_cache_size
        self.default_ttl = default_ttl
        self.cleanup_interval = cleanup_interval
        
        self._cache: Dict[str, CachedFileInfo] = {}
        self._lock = threading.RLock()
        self._last_cleanup = time.time()
        
        # 统计信息
        self.stats = {
            'hits': 0,
            'misses': 0,
            'expired': 0,
            'evicted': 0
        }
    
    def get(self, file_path: str, max_age: Optional[float] = None) -> Optional[FileInfo]:
        """
        获取缓存的文件信息
        
        Args:
            file_path: 文件路径
            max_age: 最大年龄，None使用默认TTL
            
        Returns:
            文件信息，如果不存在或过期返回None
        """
        if max_age is None:
            max_age = self.default_ttl
            
        with self._lock:
            cached = self._cache.get(file_path)
            if cached is None:
                self.stats['misses'] += 1
                return None
            
            if cached.is_expired(max_age):
                del self._cache[file_path]
                self.stats['expired'] += 1
                return None
            
            cached.mark_accessed()
            self.stats['hits'] += 1
            return cached.file_info
    
    def put(self, file_path: str, file_info: FileInfo) -> None:
        """
        缓存文件信息
        
        Args:
            file_path: 文件路径
            file_info: 文件信息
        """
        with self._lock:
            # 检查是否需要清理
            if len(self._cache) >= self.max_cache_size:
                self._evict_lru()
            
            # 添加到缓存
            self._cache[file_path] = CachedFileInfo(
                file_info=file_info,
                cache_time=time.time(),
                last_access=time.time()
            )
            
            # 定期清理过期缓存
            if time.time() - self._last_cleanup > self.cleanup_interval:
                self._cleanup_expired()
    
    def put_batch(self, file_infos: Dict[str, FileInfo]) -> None:
        """
        批量缓存文件信息
        
        Args:
            file_infos: 文件路径到文件信息的映射
        """
        with self._lock:
            current_time = time.time()
            for file_path, file_info in file_infos.items():
                if len(self._cache) >= self.max_cache_size:
                    self._evict_lru()
                
                self._cache[file_path] = CachedFileInfo(
                    file_info=file_info,
                    cache_time=current_time,
                    last_access=current_time
                )
    
    def invalidate(self, file_path: str) -> None:
        """
        使指定文件的缓存失效
        
        Args:
            file_path: 文件路径
        """
        with self._lock:
            self._cache.pop(file_path, None)
    
    def clear(self) -> None:
        """清空所有缓存"""
        with self._lock:
            self._cache.clear()
            self.stats = {'hits': 0, 'misses': 0, 'expired': 0, 'evicted': 0}
    
    def _evict_lru(self) -> None:
        """驱逐最近最少使用的缓存项"""
        if not self._cache:
            return
        
        # 找到最久未访问的项
        lru_key = min(self._cache.keys(), 
                     key=lambda k: self._cache[k].last_access)
        del self._cache[lru_key]
        self.stats['evicted'] += 1
    
    def _cleanup_expired(self) -> None:
        """清理过期的缓存项"""
        current_time = time.time()
        expired_keys = []
        
        for key, cached in self._cache.items():
            if cached.is_expired(self.default_ttl):
                expired_keys.append(key)
        
        for key in expired_keys:
            del self._cache[key]
            self.stats['expired'] += 1
        
        self._last_cleanup = current_time
    
    def get_stats(self) -> Dict:
        """获取缓存统计信息"""
        with self._lock:
            total_requests = self.stats['hits'] + self.stats['misses']
            hit_rate = self.stats['hits'] / total_requests if total_requests > 0 else 0
            
            return {
                **self.stats,
                'cache_size': len(self._cache),
                'hit_rate': hit_rate,
                'total_requests': total_requests
            }
    
    def save_to_file(self, cache_file: str) -> bool:
        """
        将缓存保存到文件
        
        Args:
            cache_file: 缓存文件路径
            
        Returns:
            是否保存成功
        """
        try:
            with self._lock:
                cache_data = {}
                for key, cached in self._cache.items():
                    cache_data[key] = {
                        'file_info': asdict(cached.file_info),
                        'cache_time': cached.cache_time,
                        'access_count': cached.access_count,
                        'last_access': cached.last_access
                    }
                
                with open(cache_file, 'w', encoding='utf-8') as f:
                    json.dump({
                        'cache_data': cache_data,
                        'stats': self.stats
                    }, f, indent=2)
                
                return True
        except Exception:
            return False
    
    def load_from_file(self, cache_file: str) -> bool:
        """
        从文件加载缓存
        
        Args:
            cache_file: 缓存文件路径
            
        Returns:
            是否加载成功
        """
        try:
            if not Path(cache_file).exists():
                return False
            
            with open(cache_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            with self._lock:
                self._cache.clear()
                cache_data = data.get('cache_data', {})
                
                for key, cached_data in cache_data.items():
                    file_info_dict = cached_data['file_info']
                    file_info = FileInfo(
                        path=file_info_dict['path'],
                        size=file_info_dict['size'],
                        is_directory=file_info_dict['is_directory'],
                        modified_time=file_info_dict['modified_time'],
                        permissions=file_info_dict.get('permissions'),
                        checksum=file_info_dict.get('checksum')
                    )
                    
                    self._cache[key] = CachedFileInfo(
                        file_info=file_info,
                        cache_time=cached_data['cache_time'],
                        access_count=cached_data['access_count'],
                        last_access=cached_data['last_access']
                    )
                
                self.stats = data.get('stats', self.stats)
                return True
                
        except Exception:
            return False


class BatchFileInfoFetcher:
    """批量文件信息获取器"""
    
    def __init__(self, sftp_client, cache: Optional[FileInfoCache] = None):
        """
        初始化批量文件信息获取器
        
        Args:
            sftp_client: SFTP客户端
            cache: 文件信息缓存
        """
        self.sftp_client = sftp_client
        self.cache = cache
    
    async def get_files_info_batch(self, 
                                  file_paths: List[str], 
                                  max_concurrent: int = 10,
                                  use_cache: bool = True) -> Dict[str, Optional[FileInfo]]:
        """
        批量获取文件信息
        
        Args:
            file_paths: 文件路径列表
            max_concurrent: 最大并发数
            use_cache: 是否使用缓存
            
        Returns:
            文件路径到文件信息的映射
        """
        results = {}
        pending_paths = []
        
        # 先尝试从缓存获取
        if use_cache and self.cache:
            for path in file_paths:
                cached_info = self.cache.get(path)
                if cached_info:
                    results[path] = cached_info
                else:
                    pending_paths.append(path)
        else:
            pending_paths = file_paths.copy()
        
        if not pending_paths:
            return results
        
        # 批量获取未缓存的文件信息
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def fetch_single(path: str) -> Tuple[str, Optional[FileInfo]]:
            async with semaphore:
                try:
                    info = await self.sftp_client.get_file_info(path)
                    return path, info
                except Exception:
                    return path, None
        
        # 并发获取文件信息
        tasks = [fetch_single(path) for path in pending_paths]
        fetch_results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # 处理结果并更新缓存
        cache_updates = {}
        for result in fetch_results:
            if isinstance(result, Exception):
                continue
            
            path, info = result
            results[path] = info
            
            if info and use_cache and self.cache:
                cache_updates[path] = info
        
        # 批量更新缓存
        if cache_updates and self.cache:
            self.cache.put_batch(cache_updates)
        
        return results
    
    async def prefetch_directory_info(self, 
                                    directory_path: str,
                                    recursive: bool = True,
                                    max_depth: int = 10) -> int:
        """
        预取目录信息到缓存
        
        Args:
            directory_path: 目录路径
            recursive: 是否递归
            max_depth: 最大递归深度
            
        Returns:
            预取的文件数量
        """
        if not self.cache:
            return 0
        
        try:
            file_paths = []
            
            # 获取目录中的所有文件路径
            await self._collect_file_paths(directory_path, file_paths, recursive, max_depth, 0)
            
            # 批量获取文件信息
            await self.get_files_info_batch(file_paths, use_cache=True)
            
            return len(file_paths)
            
        except Exception:
            return 0
    
    async def _collect_file_paths(self, 
                                directory_path: str, 
                                file_paths: List[str],
                                recursive: bool,
                                max_depth: int,
                                current_depth: int) -> None:
        """递归收集文件路径"""
        if current_depth >= max_depth:
            return
        
        try:
            files = await self.sftp_client.list_directory(directory_path)
            
            for file_info in files:
                file_paths.append(file_info.path)
                
                if recursive and file_info.is_directory:
                    await self._collect_file_paths(
                        file_info.path, file_paths, recursive, 
                        max_depth, current_depth + 1
                    )
        except Exception:
            pass
