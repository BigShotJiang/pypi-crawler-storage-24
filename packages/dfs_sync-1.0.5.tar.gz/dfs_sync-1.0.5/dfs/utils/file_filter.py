"""
文件过滤模块
支持.gitignore语法的文件过滤规则和预设过滤规则
"""

import os
import re
from pathlib import Path
from typing import List, Set, Optional, Pattern
import fnmatch


class FileFilter:
    """文件过滤器，支持.gitignore语法"""
    
    # 预设的系统文件过滤规则
    DEFAULT_SYSTEM_PATTERNS = [
        # macOS系统文件
        '.DS_Store',
        '.AppleDouble',
        '.LSOverride',
        '._*',
        
        # Windows系统文件
        'Thumbs.db',
        'ehthumbs.db',
        'Desktop.ini',
        '$RECYCLE.BIN/',
        
        # Linux系统文件
        '*~',
        '.fuse_hidden*',
        '.Trash-*',
        
        # 临时文件
        '*.tmp',
        '*.temp',
        '*.bak',
        '*.swp',
        '*.swo',
        
        # 版本控制
        '.git/',
        '.svn/',
        '.hg/',
        '.bzr/',
        
        # IDE文件
        '.vscode/',
        '.idea/',
        '*.iml',
        '.project',
        '.classpath',
        
        # 编译产物
        '*.pyc',
        '*.pyo',
        '__pycache__/',
        '*.class',
        '*.o',
        '*.so',
        '*.dylib',
        '*.dll',
        
        # 日志文件
        # '*.log',
        # 'logs/',
        
        # 缓存目录
        'node_modules/',
        '.npm/',
        '.yarn/',
        'bower_components/',
        
        # 构建目录
        'build/',
        'dist/',
        'target/',
        'out/',
    ]
    
    def __init__(self, patterns: Optional[List[str]] = None, 
                 use_gitignore: bool = True,
                 use_system_filters: bool = True,
                 case_sensitive: bool = True):
        """
        初始化文件过滤器
        
        Args:
            patterns: 自定义过滤模式列表
            use_gitignore: 是否使用.gitignore文件
            use_system_filters: 是否使用预设系统文件过滤
            case_sensitive: 是否区分大小写
        """
        self.patterns: List[str] = patterns or []
        self.use_gitignore = use_gitignore
        self.use_system_filters = use_system_filters
        self.case_sensitive = case_sensitive
        
        # 编译后的正则表达式缓存
        self._compiled_patterns: List[Pattern] = []
        self._gitignore_patterns: List[Pattern] = []
        
        self._compile_patterns()
    
    def _compile_patterns(self) -> None:
        """编译过滤模式为正则表达式"""
        all_patterns = []
        
        # 添加自定义模式
        all_patterns.extend(self.patterns)
        
        # 添加系统预设模式
        if self.use_system_filters:
            all_patterns.extend(self.DEFAULT_SYSTEM_PATTERNS)
        
        # 编译模式
        self._compiled_patterns = []
        for pattern in all_patterns:
            compiled = self._compile_gitignore_pattern(pattern)
            if compiled:
                self._compiled_patterns.append(compiled)
    
    def _compile_gitignore_pattern(self, pattern: str) -> Optional[Pattern]:
        """
        将.gitignore模式编译为正则表达式
        
        Args:
            pattern: gitignore模式字符串
            
        Returns:
            编译后的正则表达式模式
        """
        if not pattern or pattern.startswith('#'):
            return None
        
        # 移除前后空白
        pattern = pattern.strip()
        if not pattern:
            return None
        
        # 处理否定模式（以!开头）
        negate = False
        if pattern.startswith('!'):
            negate = True
            pattern = pattern[1:]
        
        # 转义特殊字符，但保留通配符
        escaped = re.escape(pattern)
        
        # 恢复通配符
        escaped = escaped.replace('\\*\\*', '.*')  # ** 匹配任意路径
        escaped = escaped.replace('\\*', '[^/]*')  # * 匹配除路径分隔符外的任意字符
        escaped = escaped.replace('\\?', '[^/]')   # ? 匹配除路径分隔符外的单个字符
        
        # 处理目录模式（以/结尾）
        if pattern.endswith('/'):
            escaped += '.*'
        
        # 处理绝对路径模式（以/开头）
        if pattern.startswith('/'):
            escaped = '^' + escaped[1:]  # 移除开头的/，添加^
        else:
            # 相对路径模式，可以匹配任意位置
            escaped = '(?:^|/)' + escaped
        
        # 添加结尾锚点（如果需要）
        if not escaped.endswith('.*'):
            escaped += '(?:/.*)?$'
        else:
            escaped += '$'
        
        try:
            flags = 0 if self.case_sensitive else re.IGNORECASE
            compiled = re.compile(escaped, flags)
            
            # 创建包装类来存储否定标志
            class CompiledPattern:
                def __init__(self, pattern, negate=False):
                    self.pattern = pattern
                    self.negate = negate
                
                def search(self, string):
                    return self.pattern.search(string)
                
                def match(self, string):
                    return self.pattern.match(string)
            
            return CompiledPattern(compiled, negate)
            
        except re.error:
            return None
    
    def load_gitignore(self, gitignore_path: str) -> bool:
        """
        加载.gitignore文件
        
        Args:
            gitignore_path: .gitignore文件路径
            
        Returns:
            是否加载成功
        """
        try:
            gitignore_file = Path(gitignore_path)
            if not gitignore_file.exists():
                return False
            
            with open(gitignore_file, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            
            # 编译.gitignore模式
            self._gitignore_patterns = []
            for line in lines:
                line = line.strip()
                if line and not line.startswith('#'):
                    compiled = self._compile_gitignore_pattern(line)
                    if compiled:
                        self._gitignore_patterns.append(compiled)
            
            return True
            
        except Exception:
            return False
    
    def should_ignore(self, file_path: str, base_path: str = "") -> bool:
        """
        检查文件是否应该被忽略
        
        Args:
            file_path: 文件路径
            base_path: 基础路径
            
        Returns:
            是否应该忽略
        """
        # 标准化路径
        if base_path:
            try:
                rel_path = os.path.relpath(file_path, base_path)
            except ValueError:
                rel_path = file_path
        else:
            rel_path = file_path
        
        # 统一使用正斜杠
        rel_path = rel_path.replace('\\', '/')
        
        # 检查是否匹配任何忽略模式
        ignore = False
        
        # 检查自定义模式和系统模式
        for pattern in self._compiled_patterns:
            if pattern.search(rel_path):
                if pattern.negate:
                    ignore = False  # 否定模式，不忽略
                else:
                    ignore = True
        
        # 检查.gitignore模式
        if self.use_gitignore:
            for pattern in self._gitignore_patterns:
                if pattern.search(rel_path):
                    if pattern.negate:
                        ignore = False
                    else:
                        ignore = True
        
        return ignore
    
    def filter_files(self, file_paths: List[str], base_path: str = "") -> List[str]:
        """
        过滤文件列表，返回不应该被忽略的文件
        
        Args:
            file_paths: 文件路径列表
            base_path: 基础路径
            
        Returns:
            过滤后的文件路径列表
        """
        filtered = []
        for file_path in file_paths:
            if not self.should_ignore(file_path, base_path):
                filtered.append(file_path)
        return filtered
    
    def add_pattern(self, pattern: str) -> None:
        """
        添加新的过滤模式
        
        Args:
            pattern: 过滤模式字符串
        """
        if pattern and pattern not in self.patterns:
            self.patterns.append(pattern)
            self._compile_patterns()  # 重新编译模式
    
    def remove_pattern(self, pattern: str) -> bool:
        """
        移除过滤模式
        
        Args:
            pattern: 要移除的模式字符串
            
        Returns:
            是否成功移除
        """
        try:
            self.patterns.remove(pattern)
            self._compile_patterns()  # 重新编译模式
            return True
        except ValueError:
            return False
    
    def clear_patterns(self) -> None:
        """清除所有自定义模式"""
        self.patterns.clear()
        self._compile_patterns()
    
    def get_patterns(self) -> List[str]:
        """获取当前所有模式"""
        all_patterns = self.patterns.copy()
        if self.use_system_filters:
            all_patterns.extend(self.DEFAULT_SYSTEM_PATTERNS)
        return all_patterns
    
    def test_pattern(self, pattern: str, test_paths: List[str]) -> List[str]:
        """
        测试模式匹配结果
        
        Args:
            pattern: 要测试的模式
            test_paths: 测试路径列表
            
        Returns:
            匹配的路径列表
        """
        compiled = self._compile_gitignore_pattern(pattern)
        if not compiled:
            return []
        
        matches = []
        for path in test_paths:
            normalized_path = path.replace('\\', '/')
            if compiled.search(normalized_path):
                matches.append(path)
        
        return matches
    
    def find_gitignore_files(self, base_path: str) -> List[str]:
        """
        在指定路径及其子目录中查找所有.gitignore文件
        
        Args:
            base_path: 基础搜索路径
            
        Returns:
            找到的.gitignore文件路径列表
        """
        gitignore_files = []
        
        try:
            base_dir = Path(base_path)
            if not base_dir.exists():
                return gitignore_files
            
            # 递归查找.gitignore文件
            for root, dirs, files in os.walk(base_dir):
                if '.gitignore' in files:
                    gitignore_path = os.path.join(root, '.gitignore')
                    gitignore_files.append(gitignore_path)
                
                # 跳过.git目录
                if '.git' in dirs:
                    dirs.remove('.git')
            
            return gitignore_files
            
        except Exception:
            return gitignore_files
    
    def auto_load_gitignores(self, base_path: str) -> int:
        """
        自动加载指定路径下的所有.gitignore文件
        
        Args:
            base_path: 基础路径
            
        Returns:
            成功加载的.gitignore文件数量
        """
        if not self.use_gitignore:
            return 0
        
        gitignore_files = self.find_gitignore_files(base_path)
        loaded_count = 0
        
        for gitignore_file in gitignore_files:
            if self.load_gitignore(gitignore_file):
                loaded_count += 1
        
        return loaded_count
