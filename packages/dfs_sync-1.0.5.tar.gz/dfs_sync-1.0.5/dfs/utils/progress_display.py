#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
简化的进度显示模块
- 每个文件独立一个进度条
- 完成后永久保留
- 跳过的文件不显示进度条
"""

import os
import time
import threading
from typing import Dict, Optional
from ..protocols.base import TransferProgress, TransferStatus


_ICONS = {
    'upload':   '↑',
    'download': '↓',
    'skip':     '»',
    'ok':       '✓',
    'fail':     '✗',
    'other':    '-',
}


class SimpleProgressDisplay:
    """简化的进度显示器"""
    
    def __init__(self):
        """初始化进度显示器"""
        self._lock = threading.Lock()
        self._file_lines: Dict[str, str] = {}  # 文件路径 -> 显示行内容
        self._start_time = time.time()
        self._total_files = 0
        self._completed_files = 0
        self._failed_files = 0
        self._skipped_files = 0  # 新增：跳过的文件数量
        self._transferred_bytes = 0
        self._completed_files_displayed = set()  # 已显示完成的文件集合
        self._failed_files_displayed = set()     # 已显示失败的文件集合
        self._file_task_numbers: Dict[str, int] = {}  # 文件路径 -> 任务序号
        self._task_counter = 0  # 已分配的任务序号（受 _lock 保护）
        
        # 进度刷新频率控制
        self._refresh_interval = 0.2  # 200ms刷新间隔，降低刷新频率
        self._last_update_times: Dict[str, float] = {}  # 文件路径 -> 上次更新时间
        self._force_update_threshold = 5.0  # 5%进度变化强制更新
        self._last_progress_values: Dict[str, float] = {}  # 文件路径 -> 上次进度值
        
        # 输出协调机制
        self._current_progress_line = ""  # 当前显示的进度行
        self._has_active_progress = False  # 是否有活跃的进度条
        
    def set_total_files(self, total: int) -> None:
        """设置总文件数"""
        self._total_files = total
    
    def set_refresh_interval(self, interval: float) -> None:
        """
        设置进度条刷新间隔
        
        Args:
            interval: 刷新间隔（秒），建议值：0.1-1.0
        """
        if 0.05 <= interval <= 5.0:  # 限制在合理范围内
            self._refresh_interval = interval
        else:
            # 使用默认值并发出警告
            self._refresh_interval = 0.2
            print(f"警告: 刷新间隔 {interval} 超出合理范围 [0.05, 5.0]，使用默认值 0.2 秒")
    
    def set_force_update_threshold(self, threshold: float) -> None:
        """
        设置强制更新的进度变化阈值
        
        Args:
            threshold: 进度变化阈值（百分比），建议值：1.0-10.0
        """
        if 0.1 <= threshold <= 50.0:  # 限制在合理范围内
            self._force_update_threshold = threshold
        else:
            # 使用默认值并发出警告
            self._force_update_threshold = 5.0
            print(f"警告: 进度阈值 {threshold} 超出合理范围 [0.1, 50.0]，使用默认值 5.0%")
        
    def update_progress(self, progress: TransferProgress) -> None:
        """
        更新进度显示
        
        Args:
            progress: 传输进度对象
        """
        with self._lock:
            file_path = progress.file_path
            current_time = time.time()
            
            if progress.status in [TransferStatus.UPLOADING, TransferStatus.DOWNLOADING]:
                # 检查是否需要更新（基于时间间隔和进度变化）
                should_update = self._should_update_progress(file_path, progress, current_time)
                
                if should_update:
                    # 实际传输中，显示动态进度条
                    progress_line = self._format_progress_line(progress)
                    print(f"\r\033[K{progress_line}", end="", flush=True)
                    
                    # 标记有活跃的进度条
                    self._has_active_progress = True
                    self._current_progress_line = progress_line
                    
                    # 更新记录
                    self._last_update_times[file_path] = current_time
                    self._last_progress_values[file_path] = progress.progress_percentage
                
            elif progress.status == TransferStatus.COMPLETED:
                # 完成后，在新行显示最终状态并保留（每个文件只显示一次）
                if file_path not in self._completed_files_displayed:
                    
                    # 判断是否为跳过的文件（双端内容一致，无需实际传输）
                    is_skipped = progress.is_skipped
                    
                    # 标记为已显示，防止重复显示
                    self._completed_files_displayed.add(file_path)
                    
                    # 更新统计
                    if is_skipped:
                        self._skipped_files += 1
                        # 跳过的文件不显示进度条，只记录统计
                    else:
                        self._completed_files += 1
                        self._transferred_bytes += progress.total_size
                        # 显示进度条（0字节文件也显示，但不显示传输中状态的空文件）
                        if progress.transferred_size > 0 or progress.total_size == 0:
                            progress_line = self._format_progress_line(progress)
                            print(f"\r\033[K{progress_line}")  # 清除行尾残留内容并换行保留
                    
                    # 清除活跃进度条状态
                    self._has_active_progress = False
                    self._current_progress_line = ""
                    
                    # 清理该文件的刷新记录
                    self._cleanup_file_records(file_path)
                    
            elif progress.status == TransferStatus.FAILED:
                # 失败后，在新行显示失败状态并保留（每个文件只显示一次）
                if file_path not in self._failed_files_displayed:
                    progress_line = self._format_progress_line(progress)
                    print(f"\r\033[K{progress_line}")  # 清除行尾残留内容并换行保留
                    
                    # 标记为已显示，防止重复显示
                    self._failed_files_displayed.add(file_path)
                    
                    # 更新统计
                    self._failed_files += 1
                    
                    # 清除活跃进度条状态
                    self._has_active_progress = False
                    self._current_progress_line = ""
                    
                    # 清理该文件的刷新记录
                    self._cleanup_file_records(file_path)
    
    def _should_update_progress(self, file_path: str, progress: TransferProgress, current_time: float) -> bool:
        """
        判断是否应该更新进度显示
        
        Args:
            file_path: 文件路径
            progress: 传输进度对象
            current_time: 当前时间
            
        Returns:
            是否应该更新
        """
        # 第一次更新，必须显示
        if file_path not in self._last_update_times:
            return True
        
        # 检查时间间隔
        time_since_last_update = current_time - self._last_update_times[file_path]
        if time_since_last_update >= self._refresh_interval:
            return True
        
        # 检查进度变化是否足够大
        if file_path in self._last_progress_values:
            progress_change = abs(progress.progress_percentage - self._last_progress_values[file_path])
            if progress_change >= self._force_update_threshold:
                return True
        
        # 完成状态必须更新
        if progress.progress_percentage >= 100.0:
            return True
        
        return False
    
    def _cleanup_file_records(self, file_path: str) -> None:
        """
        清理单个文件的刷新记录，释放内存
        
        Args:
            file_path: 文件路径
        """
        # 清理刷新频率控制相关记录
        self._last_update_times.pop(file_path, None)
        self._last_progress_values.pop(file_path, None)
        self._file_lines.pop(file_path, None)
                
    def _format_progress_line(self, progress: TransferProgress) -> str:
        """
        格式化进度行
        
        Args:
            progress: 传输进度对象
            
        Returns:
            格式化的进度行字符串
        """
        # 状态图标
        if progress.status == TransferStatus.UPLOADING:
            icon = _ICONS['upload']
        elif progress.status == TransferStatus.DOWNLOADING:
            icon = _ICONS['download']
        elif progress.status == TransferStatus.COMPLETED and progress.is_skipped:
            icon = _ICONS['skip']
        elif progress.status == TransferStatus.COMPLETED:
            icon = _ICONS['ok']
        elif progress.status == TransferStatus.FAILED:
            icon = _ICONS['fail']
        else:
            icon = _ICONS['other']

        # 分配任务序号（首次出现时）；调用方已持有 _lock
        file_path = progress.file_path
        if file_path not in self._file_task_numbers:
            self._task_counter += 1
            self._file_task_numbers[file_path] = self._task_counter
        task_num = self._file_task_numbers[file_path]
        task_label = f"[{task_num}/{self._total_files}]" if self._total_files > 0 else f"[{task_num}]"

        # 跳过文件：专属格式，不显示进度条
        if progress.is_skipped:
            file_name = os.path.basename(file_path)
            line = f"{icon} {task_label}跳过传输: {file_name} (文件已存在)"
            return line

        # 文件名（截断长路径）
        file_name = progress.file_path
        if len(file_name) > 40:
            file_name = "..." + file_name[-37:]
            
        # 进度条
        if progress.total_size > 0:
            percentage = progress.progress_percentage
            bar_width = 20
            filled = int(bar_width * percentage / 100)
            bar = "█" * filled + "░" * (bar_width - filled)
            progress_bar = f"[{bar}]"
        else:
            progress_bar = "[" + "█" * 20 + "]"
            percentage = 100.0
            
        # # 大小信息
        # if progress.total_size > 0:
        #     size_info = f"{self._format_bytes(progress.transferred_size)}/{self._format_bytes(progress.total_size)}"
        # else:
        #     size_info = self._format_bytes(progress.transferred_size)
            
        # # 速度信息
        # speed_info = ""
        # if progress.speed > 0:
        #     speed_info = f" | {self._format_speed(progress.speed)}"
            
        # # 组装完整行
        # line = f"{icon} {file_name} | {progress_bar} | {percentage:5.1f}% | {size_info}{speed_info}"
        line = f"{icon} {task_label}{file_name} {progress_bar} {percentage:3.0f}%"
        
        # 确保行长度不超过终端宽度，避免自动换行
        max_width = 100  # 合理的终端宽度
        if len(line) > max_width:
            line = line[:max_width-3] + "..."
            
        return line
        
    def _format_bytes(self, size: int) -> str:
        """格式化字节大小"""
        if size < 1024:
            return f"{size} B"
        elif size < 1024 * 1024:
            return f"{size / 1024:.1f} KB"
        elif size < 1024 * 1024 * 1024:
            return f"{size / (1024 * 1024):.1f} MB"
        else:
            return f"{size / (1024 * 1024 * 1024):.1f} GB"
            
    def _format_speed(self, speed: float) -> str:
        """格式化传输速度"""
        if speed < 1024:
            return f"{speed:.1f} B/s"
        elif speed < 1024 * 1024:
            return f"{speed / 1024:.1f} KB/s"
        elif speed < 1024 * 1024 * 1024:
            return f"{speed / (1024 * 1024):.1f} MB/s"
        else:
            return f"{speed / (1024 * 1024 * 1024):.1f} GB/s"
            
    def show_summary(self) -> None:
        """显示传输摘要"""
        elapsed_time = time.time() - self._start_time
        
        # 完成数 = 实际传输 + 跳过，保证与总数口径一致
        effective_done = self._completed_files + self._skipped_files
        
        print("=" * 60)
        print(f"耗时: {self._format_time(elapsed_time)}")
        if self._skipped_files > 0:
            print(f"完成: {effective_done}/{self._total_files} (传输 {self._completed_files}, 跳过 {self._skipped_files})")
        else:
            print(f"完成: {self._completed_files}/{self._total_files}")
        print(f"失败: {self._failed_files}")
            
        if self._transferred_bytes > 0:
            print(f"传输大小: {self._format_bytes(self._transferred_bytes)}")
            
        if elapsed_time > 0:
            avg_speed = self._transferred_bytes / elapsed_time
            print(f"速率: {self._format_speed(avg_speed)}")
            
        # print("=" * 60)
        
    def _format_time(self, seconds: float) -> str:
        """格式化时间"""
        if seconds < 60:
            return f"{seconds:.0f}s"
        elif seconds < 3600:
            minutes = int(seconds // 60)
            secs = int(seconds % 60)
            return f"{minutes}m {secs}s"
        else:
            hours = int(seconds // 3600)
            minutes = int((seconds % 3600) // 60)
            return f"{hours}h {minutes}m"
            
    def show_skip_message(self, file_path: str) -> None:
        """
        显示跳过文件的消息（与进度条协调）
        
        Args:
            file_path: 文件完整路径
        """
        with self._lock:
            progress = TransferProgress(
                file_path=file_path,
                total_size=0,
                transferred_size=0,
                speed=0.0,
                status=TransferStatus.COMPLETED,
                start_time=time.time(),
                is_skipped=True
            )
            skip_msg = self._format_progress_line(progress)

            if self._has_active_progress:
                print(f"\r\033[K{skip_msg}", flush=True)
            else:
                print(skip_msg)
    
    def show_file_status(self, file_path: str, status: TransferStatus, file_size: int = 0, error_msg: str = "") -> None:
        """
        显示文件状态（用于失败文件的显示）
        
        Args:
            file_path: 文件路径
            status: 传输状态
            file_size: 文件大小
            error_msg: 错误信息（如果有）
        """
        with self._lock:
            if status == TransferStatus.FAILED:
                # 创建失败状态的进度信息
                progress = TransferProgress(
                    file_path=file_path,
                    total_size=file_size,
                    transferred_size=0,
                    speed=0.0,
                    status=status,
                    start_time=time.time()
                )
                
                # 格式化并显示失败状态
                progress_line = self._format_progress_line(progress)
                if error_msg:
                    progress_line += f" - {error_msg}"
                    
                if self._has_active_progress:
                    print(f"\r\033[K{progress_line}")
                else:
                    print(progress_line)
    
    def finish_display(self) -> None:
        """完成显示，清理刷新记录释放内存"""
        with self._lock:
            # 清理所有刷新频率控制记录，释放内存
            self._last_update_times.clear()
            self._last_progress_values.clear()
            self._file_lines.clear()
            self._file_task_numbers.clear()
            self._task_counter = 0


# 为了兼容性，保持原来的类名
ProgressDisplay = SimpleProgressDisplay