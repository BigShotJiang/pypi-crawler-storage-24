"""
路径处理工具模块
提供跨平台的路径处理、通配符匹配和智能路径识别功能
"""

import os
import re
import glob
from pathlib import Path, PurePath
from typing import List, Tuple, Set, Optional
import fnmatch
import platform


class PathHandler:
    """路径处理工具类"""
    
    def __init__(self, case_sensitive: bool = None):
        """
        初始化路径处理器
        
        Args:
            case_sensitive: 是否区分大小写，None表示根据系统自动判断
        """
        if case_sensitive is None:
            # 根据操作系统自动判断
            self.case_sensitive = platform.system() != 'Windows'
        else:
            self.case_sensitive = case_sensitive
    
    def normalize_path(self, path: str) -> str:
        """
        标准化路径格式，处理跨平台兼容性
        
        Args:
            path: 原始路径
            
        Returns:
            标准化后的路径
        """
        if not path:
            return ""
        
        # 转换路径分隔符为当前系统格式
        normalized = os.path.normpath(path)
        
        # 处理相对路径
        if normalized.startswith('./'):
            normalized = normalized[2:]
        elif normalized == '.':
            normalized = ""
        
        # 确保绝对路径格式正确
        if os.path.isabs(normalized):
            normalized = os.path.abspath(normalized)
        
        return normalized
    
    def is_directory_path(self, path: str) -> bool:
        """
        智能识别路径是否为目录
        
        Args:
            path: 路径字符串
            
        Returns:
            是否为目录路径
        """
        # 如果路径以分隔符结尾，认为是目录
        if path.endswith(('/', '\\\\')):
            return True
        
        # 如果路径存在且是目录
        if os.path.exists(path) and os.path.isdir(path):
            return True
        
        # 如果路径存在且是文件，明确不是目录
        if os.path.exists(path) and os.path.isfile(path):
            return False
        
        path_obj = Path(path)
        filename = path_obj.name
        
        # 如果有明显的文件扩展名，认为是文件
        if path_obj.suffix and len(path_obj.suffix) <= 5:  # 常见扩展名长度限制
            # 常见文件扩展名
            common_extensions = {
                '.txt', '.json', '.xml', '.csv', '.log', '.md', '.yml', '.yaml',
                '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg', '.ico',
                '.mp3', '.mp4', '.avi', '.mkv', '.mov', '.wav', '.flac',
                '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
                '.zip', '.tar', '.gz', '.rar', '.7z',
                '.py', '.js', '.html', '.css', '.java', '.cpp', '.c', '.h',
                '.sh', '.bat', '.exe', '.dll', '.so'
            }
            if path_obj.suffix.lower() in common_extensions:
                return False
        
        # 如果文件名包含点但不是隐藏文件，且有扩展名，可能是文件
        if '.' in filename and not filename.startswith('.') and path_obj.suffix:
            return False
        
        # 其他情况认为是目录（包括无扩展名的路径）
        return True
    
    def expand_wildcards(self, pattern: str, base_path: str = ".") -> List[str]:
        """
        展开通配符模式，支持glob语法
        
        Args:
            pattern: 通配符模式，如 *.txt, **/*.py
            base_path: 基础路径
            
        Returns:
            匹配的文件路径列表
        """
        try:
            # 处理绝对路径
            if os.path.isabs(pattern):
                search_pattern = pattern
            else:
                search_pattern = os.path.join(base_path, pattern)
            
            # 使用glob进行模式匹配
            matches = glob.glob(search_pattern, recursive=True)
            
            # 标准化路径
            normalized_matches = [self.normalize_path(match) for match in matches]
            
            # 根据大小写敏感性处理
            if not self.case_sensitive:
                # 去重（忽略大小写）
                seen = set()
                result = []
                for match in normalized_matches:
                    match_lower = match.lower()
                    if match_lower not in seen:
                        seen.add(match_lower)
                        result.append(match)
                return result
            
            return normalized_matches
            
        except Exception:
            return []
    
    def match_pattern(self, filename: str, pattern: str) -> bool:
        """
        检查文件名是否匹配指定模式
        
        Args:
            filename: 文件名
            pattern: 模式字符串，支持通配符
            
        Returns:
            是否匹配
        """
        try:
            # 处理大小写敏感性
            if not self.case_sensitive:
                filename = filename.lower()
                pattern = pattern.lower()
            
            # 使用fnmatch进行模式匹配
            return fnmatch.fnmatch(filename, pattern)
            
        except Exception:
            return False
    
    def get_relative_path(self, path: str, base_path: str) -> str:
        """
        获取相对于基础路径的相对路径
        
        Args:
            path: 目标路径
            base_path: 基础路径
            
        Returns:
            相对路径
        """
        try:
            path_obj = Path(path)
            base_obj = Path(base_path)
            
            # 如果都是绝对路径，计算相对路径
            if path_obj.is_absolute() and base_obj.is_absolute():
                return str(path_obj.relative_to(base_obj))
            
            # 否则直接返回标准化路径
            return self.normalize_path(path)
            
        except ValueError:
            # 如果无法计算相对路径，返回绝对路径
            return os.path.abspath(path)
    
    def split_path(self, path: str) -> Tuple[str, str]:
        """
        分割路径为目录和文件名
        
        Args:
            path: 文件路径
            
        Returns:
            (目录路径, 文件名)
        """
        normalized = self.normalize_path(path)
        return os.path.split(normalized)
    
    def join_paths(self, *paths: str) -> str:
        """
        连接多个路径组件
        
        Args:
            *paths: 路径组件
            
        Returns:
            连接后的路径
        """
        if not paths:
            return ""
        
        # 过滤空路径
        valid_paths = [p for p in paths if p]
        if not valid_paths:
            return ""
        
        joined = os.path.join(*valid_paths)
        return self.normalize_path(joined)
    
    def ensure_directory(self, path: str) -> bool:
        """
        确保目录存在，如果不存在则创建
        
        Args:
            path: 目录路径
            
        Returns:
            是否成功创建或已存在
        """
        try:
            Path(path).mkdir(parents=True, exist_ok=True)
            return True
        except Exception:
            return False
    
    def get_file_extension(self, path: str) -> str:
        """
        获取文件扩展名
        
        Args:
            path: 文件路径
            
        Returns:
            文件扩展名（包含点号）
        """
        return Path(path).suffix
    
    def change_extension(self, path: str, new_ext: str) -> str:
        """
        更改文件扩展名
        
        Args:
            path: 原文件路径
            new_ext: 新扩展名（可以包含或不包含点号）
            
        Returns:
            新的文件路径
        """
        path_obj = Path(path)
        
        # 确保扩展名以点号开头
        if new_ext and not new_ext.startswith('.'):
            new_ext = '.' + new_ext
        
        new_path = path_obj.with_suffix(new_ext)
        return str(new_path)
    
    def is_hidden_file(self, path: str) -> bool:
        """
        检查是否为隐藏文件或目录
        
        Args:
            path: 文件路径
            
        Returns:
            是否为隐藏文件
        """
        filename = os.path.basename(path)
        
        # Unix/Linux风格的隐藏文件（以点开头）
        if filename.startswith('.') and filename not in ['.', '..']:
            return True
        
        # Windows风格的隐藏文件（通过文件属性）
        if platform.system() == 'Windows':
            try:
                import ctypes
                attrs = ctypes.windll.kernel32.GetFileAttributesW(path)
                return attrs != -1 and attrs & 2  # FILE_ATTRIBUTE_HIDDEN
            except Exception:
                pass
        
        return False
    
    def get_common_path(self, paths: List[str]) -> str:
        """
        获取多个路径的公共父路径
        
        Args:
            paths: 路径列表
            
        Returns:
            公共父路径
        """
        if not paths:
            return ""
        
        if len(paths) == 1:
            return os.path.dirname(paths[0])
        
        try:
            # 标准化所有路径
            normalized_paths = [self.normalize_path(p) for p in paths]
            
            # 使用os.path.commonpath计算公共路径
            common = os.path.commonpath(normalized_paths)
            return self.normalize_path(common)
            
        except ValueError:
            # 如果路径没有公共部分，返回空字符串
            return ""
    
    def validate_path(self, path: str) -> Tuple[bool, str]:
        """
        验证路径是否有效
        
        Args:
            path: 要验证的路径
            
        Returns:
            (是否有效, 错误信息)
        """
        if not path:
            return False, "路径不能为空"
        
        try:
            # 检查路径长度
            if len(path) > 260 and platform.system() == 'Windows':
                return False, "Windows路径长度不能超过260个字符"
            
            # 检查非法字符
            illegal_chars = set('<>:"|?*')
            if platform.system() == 'Windows':
                if any(char in path for char in illegal_chars):
                    return False, f"路径包含非法字符: {illegal_chars}"
            
            # 尝试创建Path对象
            Path(path)
            
            return True, ""
            
        except Exception as e:
            return False, f"路径格式无效: {e}"
    
    def resolve_target_path(self, source_path: str, target_path: str) -> str:
        """
        智能解析目标路径
        
        根据业界标准逻辑：
        - 如果目标是目录，将源文件名添加到目标目录
        - 如果目标是文件，直接使用目标路径
        
        Args:
            source_path: 源路径
            target_path: 目标路径
            
        Returns:
            解析后的目标路径
        """
        if not source_path or not target_path:
            return target_path
        
        # 标准化路径
        source_path = self.normalize_path(source_path)
        target_path = self.normalize_path(target_path)
        
        # 展开用户目录
        target_path = os.path.expanduser(target_path)
        
        # 如果目标路径是目录（或被识别为目录）
        if self.is_directory_path(target_path):
            # 获取源文件名
            source_filename = os.path.basename(source_path)
            
            # 将源文件名添加到目标目录
            resolved_path = self.join_paths(target_path, source_filename)
            return resolved_path
        
        # 否则直接使用目标路径（作为完整的文件路径）
        return target_path
    
    def expand_user_path(self, path: str) -> str:
        """
        展开用户路径（~）
        
        Args:
            path: 可能包含~的路径
            
        Returns:
            展开后的绝对路径
        """
        return os.path.expanduser(path)
    
    @staticmethod
    def sanitize_windows_filename(name: str) -> str:
        """
        将文件名组件中 Windows 不支持的字符替换为百分号编码形式。
        Windows 文件名非法字符（不含路径分隔符）: : * ? " < > |
        """
        replacements = {
            ':': '%3A',
            '*': '%2A',
            '?': '%3F',
            '"': '%22',
            '<': '%3C',
            '>': '%3E',
            '|': '%7C',
        }
        for char, encoded in replacements.items():
            name = name.replace(char, encoded)
        return name

    def remote_to_local_path(self, remote_file_path: str, remote_base: str, local_base: str) -> str:
        """
        将远程文件路径转换为本地路径，在 Windows 上自动净化非法字符。

        Args:
            remote_file_path: 远程文件完整路径（使用正斜杠）
            remote_base: 远程基础目录路径
            local_base: 本地基础目录路径

        Returns:
            适合当前操作系统的本地文件路径
        """
        remote_file_norm = remote_file_path.replace('\\', '/')
        remote_base_norm = remote_base.replace('\\', '/')
        if not remote_base_norm.endswith('/'):
            remote_base_norm += '/'

        if remote_file_norm.startswith(remote_base_norm):
            rel_str = remote_file_norm[len(remote_base_norm):]
        else:
            rel_str = os.path.relpath(remote_file_path, remote_base).replace('\\', '/')

        components = [c for c in rel_str.split('/') if c]
        if not components:
            return local_base

        if platform.system() == 'Windows':
            components = [self.sanitize_windows_filename(c) for c in components]

        local_rel = os.path.join(*components)
        return os.path.join(local_base, local_rel)

    def get_path_type(self, path: str) -> str:
        """
        获取路径类型
        
        Args:
            path: 路径字符串
            
        Returns:
            'file', 'directory', 'not_exists'
        """
        expanded_path = self.expand_user_path(path)
        
        if os.path.exists(expanded_path):
            if os.path.isfile(expanded_path):
                return 'file'
            elif os.path.isdir(expanded_path):
                return 'directory'
        
        # 路径不存在，根据模式推测
        if self.is_directory_path(path):
            return 'directory'
        else:
            return 'file'
