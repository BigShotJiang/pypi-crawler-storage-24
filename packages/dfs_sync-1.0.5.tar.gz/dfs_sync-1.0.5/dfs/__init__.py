"""
DFS - 分布式文件同步工具
一个高性能、易使用、跨平台的并发文件上传/下载工具

支持协议: SFTP
"""

__version__ = "1.0.5"
__author__ = "xigua"
__description__ = "分布式文件同步工具 - 高性能并发文件传输"

from .core.config import Config
from .core.logger import Logger
from .protocols.sftp_client import SFTPClient
from .core.transfer_manager import TransferManager

__all__ = [
    "Config",
    "Logger", 
    "SFTPClient",
    "TransferManager"
]
