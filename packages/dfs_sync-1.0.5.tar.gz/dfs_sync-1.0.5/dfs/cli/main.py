"""
命令行接口主模块
提供用户友好的命令行界面，支持上传、下载、配置等功能
"""

import argparse
import asyncio
import sys
import os
import re
import getpass
from typing import Optional, List, Tuple
from pathlib import Path
import multiprocessing

from ..core.config import Config
from ..core.logger import Logger, get_logger
from ..protocols.sftp_client import SFTPClient
from ..core.transfer_manager import TransferManager
from ..utils.path_handler import PathHandler
from .. import __version__, __description__


class DFSCli:
    """DFS命令行接口类"""
    
    def __init__(self):
        """初始化CLI"""
        self.config: Optional[Config] = None
        self.logger: Optional[Logger] = None
        self.client: Optional[SFTPClient] = None
        self.transfer_manager: Optional[TransferManager] = None
        self.path_handler = PathHandler()
    
    def parse_server_string(self, server_str: str) -> Tuple[Optional[str], Optional[str], Optional[int]]:
        """
        解析服务器连接字符串，支持以下格式：
        - host
        - user@host
        - host:port
        - user@host:port
        
        Args:
            server_str: 服务器连接字符串
            
        Returns:
            (username, host, port) 元组，未指定的部分返回None
        """
        username = None
        host = None
        port = None
        
        # 匹配 user@host:port 格式
        pattern = r'^(?:([^@]+)@)?([^:]+)(?::(\d+))?$'
        match = re.match(pattern, server_str)
        
        if match:
            username = match.group(1)  # 可能为None
            host = match.group(2)
            port_str = match.group(3)  # 可能为None
            if port_str:
                port = int(port_str)
        else:
            # 如果不匹配，假设整个字符串是host
            host = server_str
        
        return username, host, port
        
    def create_parser(self) -> argparse.ArgumentParser:
        """
        创建命令行参数解析器
        
        Returns:
            参数解析器
        """
        parser = argparse.ArgumentParser(
            prog='dfs',
            description=__description__,
            formatter_class=argparse.RawDescriptionHelpFormatter,
            allow_abbrev=False,  # 禁用选项前缀匹配，防止 -f 被识别为 -ff
            epilog="""
示例用法:
  # 推荐格式 - 使用 user@host[:port] 格式（类似SSH）
  dfs root@10.0.0.1 -u ./file.txt /remote/          # 用户名@主机
  dfs admin@10.0.0.2:2222 -u ./file.txt /tmp/       # 用户名@主机:端口
  dfs root@10.0.0.1 --test-connection               # 测试连接

  # 传统格式 - 仅指定IP（用户名密码从配置文件读取）
  dfs 10.0.0.1 -u ./file.txt /remote/               # 使用指定服务器IP
  dfs 10.0.0.2 -U root -u ./file.txt /tmp/          # 指定IP和用户名

  # 基本操作
  dfs -u ./local_file.txt /remote/path/file.txt     # 上传文件
  dfs -u ./local_dir /remote/path/                  # 上传目录
  dfs -d /remote/path/file.txt ./local_file.txt     # 下载文件
  dfs -d /remote/path/dir ./local_dir               # 下载目录

  # 快捷方式（在 ~/.dfs.yaml 的 shortcuts 节中配置）
  dfs -ff                                           # 执行内置快捷方式 "ff"
  dfs root@10.0.0.1 -s logs                         # 指定服务器并执行快捷方式

  # 高级用法
  dfs root@10.0.0.1 -u ./src /backup/ -j 4          # 使用并发连接
  DFS_PASSWORD=mypass dfs root@10.0.0.1 -u ./       # 环境变量密码
  dfs --config-set server.host example.com          # 设置配置
  dfs --config-show                                 # 显示当前配置

快捷方式配置（~/.dfs.yaml）:
  shortcuts:
    ff:                          # dfs -ff 或 dfs -s ff
      action: download
      remote: /root/logfile
      local: ~/downloads/logfile
    backup:                      # dfs -s backup
      action: upload
      local: ./src
      remote: /backup/src

安全提示:
  - 推荐使用SSH密钥认证，避免使用密码
  - 避免在命令行中直接输入密码（会记录在历史中）
  - 优先级: user@host > 环境变量 > -U/-p参数 > 配置文件
  - 当密码缺失时，会自动提示交互式输入
            """
        )
        
        # 位置参数：服务器连接字符串（可选）
        parser.add_argument(
            'server_str',
            nargs='?',
            metavar='[user@]host[:port]',
            help='服务器连接字符串，支持格式: host, user@host, host:port, user@host:port （优先级最高）'
        )
        
        # 版本信息
        parser.add_argument(
            '-v', '--version',
            action='version',
            version=f'DFS {__version__}'
        )
        
        # 主要操作
        main_group = parser.add_mutually_exclusive_group()
        
        main_group.add_argument(
            '-u', '--upload',
            nargs=2,
            metavar=('LOCAL_PATH', 'REMOTE_PATH'),
            help='上传文件或目录到远程服务器'
        )
        
        main_group.add_argument(
            '-d', '--download',
            nargs=2,
            metavar=('REMOTE_PATH', 'LOCAL_PATH'),
            help='从远程服务器下载文件或目录'
        )
        
        main_group.add_argument(
            '-ff', '--fast-fetch',
            action='store_true',
            help='执行配置文件中名为 "ff" 的快捷方式（路径在 ~/.dfs.yaml shortcuts.ff 中配置）'
        )

        main_group.add_argument(
            '-s', '--shortcut',
            metavar='NAME',
            help='执行配置文件中指定名称的快捷方式，如: dfs -s backup'
        )
        
        # 配置管理
        config_group = parser.add_argument_group('配置管理')
        
        config_group.add_argument(
            '--config-file',
            metavar='PATH',
            help='指定配置文件路径'
        )
        
        config_group.add_argument(
            '--config-show',
            action='store_true',
            help='显示当前配置'
        )
        
        config_group.add_argument(
            '--config-set',
            nargs=2,
            metavar=('KEY', 'VALUE'),
            help='设置配置项，如: server.host example.com'
        )
        
        config_group.add_argument(
            '--config-get',
            metavar='KEY',
            help='获取配置项值'
        )
        
        config_group.add_argument(
            '--config-reset',
            action='store_true',
            help='重置配置为默认值'
        )
        
        # 连接选项
        conn_group = parser.add_argument_group('连接选项')
        
        conn_group.add_argument(
            '-H', '--host',
            help='服务器主机地址'
        )
        
        conn_group.add_argument(
            '-P', '--port',
            type=int,
            help='服务器端口号'
        )
        
        conn_group.add_argument(
            '-U', '--username',
            help='用户名'
        )
        
        conn_group.add_argument(
            '-p', '--password',
            help='密码（不推荐：会暴露在历史记录中。推荐使用环境变量DFS_PASSWORD或交互式输入）'
        )
        
        conn_group.add_argument(
            '--password-stdin',
            action='store_true',
            help='从标准输入读取密码（更安全）'
        )
        
        conn_group.add_argument(
            '-k', '--private-key',
            help='私钥文件路径'
        )
        
        conn_group.add_argument(
            '--test-connection',
            action='store_true',
            help='测试服务器连接'
        )
        
        # 传输选项
        transfer_group = parser.add_argument_group('传输选项')
        
        transfer_group.add_argument(
            '-j', '--concurrent',
            type=int,
            metavar='N',
            help='并发连接数 (1-16)'
        )
        
        transfer_group.add_argument(
            '--chunk-size',
            type=int,
            metavar='BYTES',
            help='传输块大小（字节）'
        )
        
        transfer_group.add_argument(
            '--no-verify',
            action='store_true',
            help='跳过文件完整性验证'
        )
        
        transfer_group.add_argument(
            '--retry',
            type=int,
            metavar='N',
            help='失败重试次数'
        )
        
        # 过滤选项
        filter_group = parser.add_argument_group('过滤选项')
        
        filter_group.add_argument(
            '--ignore',
            action='append',
            metavar='PATTERN',
            help='忽略匹配模式的文件，可多次使用'
        )
        
        filter_group.add_argument(
            '--no-gitignore',
            action='store_true',
            help='不使用.gitignore文件'
        )
        
        filter_group.add_argument(
            '--include-hidden',
            action='store_true',
            help='包含隐藏文件'
        )
        
        filter_group.add_argument(
            '--no-system-filter',
            action='store_true',
            help='不使用系统文件过滤器'
        )
        
        # 日志选项
        log_group = parser.add_argument_group('日志选项')
        
        log_group.add_argument(
            '--log-level',
            choices=['debug', 'info', 'warning', 'error', 'critical'],
            help='日志级别'
        )
        
        log_group.add_argument(
            '--log-file',
            metavar='PATH',
            help='日志文件路径'
        )
        
        log_group.add_argument(
            '-q', '--quiet',
            action='store_true',
            help='静默模式，只显示错误'
        )
        
        log_group.add_argument(
            '--verbose',
            action='store_true',
            help='详细模式，显示调试信息'
        )
        
        return parser
    
    def init_config(self, args: argparse.Namespace) -> None:
        """
        初始化配置
        
        Args:
            args: 命令行参数
        """
        # 加载配置文件
        self.config = Config(args.config_file)
        
        # 应用命令行参数覆盖配置（按优先级从低到高）
        
        # 1. 命令行选项参数（优先级：低）
        if args.host:
            self.config.set('server.host', args.host)
        if args.port:
            self.config.set('server.port', args.port)
        if args.username:
            self.config.set('server.username', args.username)
        if args.private_key:
            self.config.set('server.private_key', args.private_key)
        
        # 2. 命令行密码参数（优先级：中）
        if args.password:
            self.config.set('server.password', args.password)
            print("⚠️  警告: 命令行密码会保留在shell历史记录中，不安全！")
            print("   推荐使用: SSH密钥、环境变量DFS_PASSWORD或交互式输入")
        
        # 3. 从标准输入读取密码（优先级：中高）
        if hasattr(args, 'password_stdin') and args.password_stdin:
            try:
                password = sys.stdin.readline().strip()
                if password:
                    self.config.set('server.password', password)
            except Exception as e:
                print(f"⚠️  警告: 从标准输入读取密码失败: {e}")
        
        # 4. 环境变量（优先级：高）
        env_password = os.environ.get('DFS_PASSWORD')
        if env_password:
            self.config.set('server.password', env_password)
        
        # 5. 位置参数 server_str（优先级：最高）
        # 支持格式: host, user@host, host:port, user@host:port
        if hasattr(args, 'server_str') and args.server_str:
            username, host, port = self.parse_server_string(args.server_str)
            
            if host:
                self.config.set('server.host', host)
            if username:
                self.config.set('server.username', username)
            if port:
                self.config.set('server.port', port)
        
        if args.concurrent:
            try:
                cpu_cores = multiprocessing.cpu_count()
            except (ImportError, NotImplementedError):
                cpu_cores = 4  # 默认值
                
            if 1 <= args.concurrent <= 16:
                if args.concurrent > cpu_cores:
                    print(f"警告: 并发连接数 ({args.concurrent}) 超过系统CPU核心数 ({cpu_cores})")
                    print("这可能会导致性能下降，建议使用不超过CPU核心数的值")
                self.config.set('transfer.concurrent_connections', args.concurrent)
            else:
                print("警告: 并发连接数应在1-16之间")
        
        if args.chunk_size:
            self.config.set('transfer.chunk_size', args.chunk_size)
        
        if args.no_verify:
            self.config.set('transfer.verify_checksum', False)
        
        if args.retry is not None:
            self.config.set('transfer.max_retries', args.retry)
        
        # 过滤器选项
        if args.ignore:
            existing_patterns = self.config.get('filters.custom_patterns', [])
            existing_patterns.extend(args.ignore)
            self.config.set('filters.custom_patterns', existing_patterns)
        
        if args.no_gitignore:
            self.config.set('filters.use_gitignore', False)
        
        if args.include_hidden:
            self.config.set('filters.exclude_hidden', False)
        
        if args.no_system_filter:
            # 移除系统过滤器模式
            self.config.set('filters.custom_patterns', [])
        
        # 日志选项
        if args.log_level:
            self.config.set('logging.level', args.log_level)
        elif args.quiet:
            self.config.set('logging.level', 'error')
        elif args.verbose:
            self.config.set('logging.level', 'debug')
        
        if args.log_file:
            self.config.set('logging.file_path', args.log_file)
    
    def init_logger(self) -> None:
        """初始化日志器"""
        log_config = self.config.get('logging', {})
        self.logger = get_logger('dfs.cli.main', log_config)
    
    def prompt_password_if_needed(self) -> None:
        """
        如果没有密码且没有私钥，则提示用户输入密码
        交互式输入密码（不会显示在屏幕上，也不会记录在历史中）
        """
        has_password = bool(self.config.get('server.password'))
        has_private_key = bool(self.config.get('server.private_key'))
        
        # 如果既没有密码也没有私钥，则提示输入密码
        if not has_password and not has_private_key:
            try:
                server_host = self.config.get('server.host', 'server')
                username = self.config.get('server.username', 'user')
                
                # 使用 getpass 安全地输入密码
                password = getpass.getpass(f"请输入 {username}@{server_host} 的密码: ")
                
                if password:
                    self.config.set('server.password', password)
                    # print("✅ 密码已设置")
                else:
                    print("⚠️  警告: 未输入密码，如果服务器需要认证，连接将失败")
            except (KeyboardInterrupt, EOFError):
                print("\n⏹️  取消密码输入")
            except Exception as e:
                print(f"⚠️  警告: 密码输入失败: {e}")
    
    async def init_client(self) -> bool:
        """
        初始化SFTP客户端
        
        Returns:
            是否初始化成功
        """
        try:
            server_config = self.config.get('server', {})
            transfer_config = self.config.get('transfer', {})
            
            # 合并配置
            client_config = {**server_config, **transfer_config}
            
            self.client = SFTPClient(client_config)
            
            # 创建传输管理器
            manager_config = {
                **server_config,
                **transfer_config,
                **self.config.get('filters', {}),
                **self.config.get('paths', {})
            }
            
            self.transfer_manager = TransferManager(
                self.client, manager_config, self.logger
            )
            
            return True
            
        except Exception as e:
            self.logger.error(f"初始化客户端失败: {e}")
            return False
    
    async def handle_upload(self, local_path: str, remote_path: str) -> int:
        """
        处理上传命令
        
        Args:
            local_path: 本地路径
            remote_path: 远程路径
            
        Returns:
            退出码
        """
        try:
            # 展开用户路径
            local_path = self.path_handler.expand_user_path(local_path)
            
            # 检查本地路径
            local_file = Path(local_path)
            if not local_file.exists():
                self.logger.error(f"本地路径不存在: {local_path}")
                return 1
            
            # 获取服务器信息用于显示
            server_host = self.config.get('server.host', 'unknown')
            server_port = self.config.get('server.port', 22)
            server_info = f"{server_host}:{server_port}" if server_port != 22 else server_host
            
            # 智能解析远程目标路径
            if local_file.is_file():
                # 如果本地是文件，智能解析远程路径
                resolved_remote_path = self.path_handler.resolve_target_path(local_path, remote_path)
                self.logger.info(f"[{server_info}] 开始上传: {local_path} -> {resolved_remote_path}")
            else:
                # 如果本地是目录，直接使用远程路径
                resolved_remote_path = remote_path
                self.logger.info(f"[{server_info}] 开始上传: {local_path} -> {resolved_remote_path}")
            
            # 连接到服务器
            if not await self.client.connect():
                self.logger.error(f"[{server_info}] 连接服务器失败")
                return 1
            
            # 执行上传
            if local_file.is_file():
                success = await self.transfer_manager.upload_file(local_path, resolved_remote_path)
            else:
                success = await self.transfer_manager.upload_directory(local_path, resolved_remote_path)
            
            # 开始传输
            if success:
                success = await self.transfer_manager.start_transfer()
            
            if success:
                # self.logger.info("上传完成")
                return 0
            else:
                self.logger.error(f"[{server_info}] 上传失败")
                return 1
                
        except Exception as e:
            server_host = self.config.get('server.host', 'unknown')
            server_port = self.config.get('server.port', 22)
            server_info = f"{server_host}:{server_port}" if server_port != 22 else server_host
            self.logger.error(f"[{server_info}] 上传过程中发生错误: {e}")
            return 1
        finally:
            # 清理传输管理器资源
            if self.transfer_manager:
                self.transfer_manager.cleanup_resources()
            # 断开客户端连接
            if self.client:
                await self.client.disconnect()
    
    async def handle_download(self, remote_path: str, local_path: str) -> int:
        """
        处理下载命令
        
        Args:
            remote_path: 远程路径
            local_path: 本地路径
            
        Returns:
            退出码
        """
        try:
            # 展开用户路径
            local_path = self.path_handler.expand_user_path(local_path)
            
            # 获取服务器信息用于显示
            server_host = self.config.get('server.host', 'unknown')
            server_port = self.config.get('server.port', 22)
            server_info = f"{server_host}:{server_port}" if server_port != 22 else server_host
            
            # 连接到服务器
            if not await self.client.connect():
                self.logger.error(f"[{server_info}] 连接服务器失败")
                return 1
            
            # 检查远程路径
            if not await self.client.file_exists(remote_path):
                self.logger.error(f"[{server_info}] 远程路径不存在: {remote_path}")
                return 1
            
            # 获取远程文件信息
            remote_info = await self.client.get_file_info(remote_path)
            if not remote_info:
                self.logger.error(f"[{server_info}] 无法获取远程路径信息: {remote_path}")
                return 1
            
            # 智能解析本地目标路径
            if not remote_info.is_directory:
                # 如果远程是文件，智能解析本地路径
                resolved_local_path = self.path_handler.resolve_target_path(remote_path, local_path)
                self.logger.info(f"[{server_info}] 开始下载: {remote_path} -> {resolved_local_path}")
            else:
                # 如果远程是目录，直接使用本地路径
                resolved_local_path = local_path
                self.logger.info(f"[{server_info}] 开始下载: {remote_path} -> {resolved_local_path}")
            
            # 执行下载
            if remote_info.is_directory:
                success = await self.transfer_manager.download_directory(remote_path, resolved_local_path)
            else:
                success = await self.transfer_manager.download_file(remote_path, resolved_local_path)
            
            # 开始传输
            if success:
                success = await self.transfer_manager.start_transfer()
            
            if success:
                self.logger.debug(f"[{server_info}] 下载完成")
                return 0
            else:
                self.logger.error(f"[{server_info}] 下载失败")
                return 1
                
        except Exception as e:
            server_host = self.config.get('server.host', 'unknown')
            server_port = self.config.get('server.port', 22)
            server_info = f"{server_host}:{server_port}" if server_port != 22 else server_host
            self.logger.error(f"[{server_info}] 下载过程中发生错误: {e}")
            return 1
        finally:
            # 清理传输管理器资源
            if self.transfer_manager:
                self.transfer_manager.cleanup_resources()
            # 断开客户端连接
            if self.client:
                await self.client.disconnect()
    
    async def handle_shortcut(self, name: str) -> int:
        """
        执行配置文件中定义的快捷方式

        Args:
            name: shortcuts 节中的快捷方式名称

        Returns:
            退出码
        """
        shortcuts = self.config.get('shortcuts', {})
        if not shortcuts or name not in shortcuts:
            defined = ', '.join(shortcuts.keys()) if shortcuts else '（无）'
            print(f"❌ 快捷方式 '{name}' 不存在")
            print(f"   当前已定义的快捷方式: {defined}")
            print(f"   在 ~/.dfs.yaml 的 shortcuts 节中添加新快捷方式")
            return 1

        sc = shortcuts[name]
        action = sc.get('action', '').lower()
        remote = sc.get('remote', '')
        local = sc.get('local', '')

        if not action or not remote or not local:
            print(f"❌ 快捷方式 '{name}' 配置不完整，需要 action / remote / local 三个字段")
            return 1

        if action == 'download':
            return await self.handle_download(remote, local)
        elif action == 'upload':
            return await self.handle_upload(local, remote)
        else:
            print(f"❌ 快捷方式 '{name}' 的 action 值 '{action}' 无效，必须为 upload 或 download")
            return 1

    async def handle_test_connection(self) -> int:
        """
        处理测试连接命令
        
        Returns:
            退出码
        """
        try:
            # 获取服务器信息用于显示
            server_host = self.config.get('server.host', 'unknown')
            server_port = self.config.get('server.port', 22)
            server_info = f"{server_host}:{server_port}" if server_port != 22 else server_host
            
            self.logger.info(f"[{server_info}] 测试服务器连接...")
            
            success, error_msg = await self.client.test_connection()
            
            if success:
                conn_info = self.client.get_connection_info()
                print(f"✅ 连接成功")
                print(f"   协议: {conn_info['protocol'].upper()}")
                print(f"   主机: {conn_info['host']}:{conn_info['port']}")
                print(f"   用户: {conn_info['username']}")
                return 0
            else:
                print(f"❌ [{server_info}] 连接失败: {error_msg}")
                return 1
                
        except Exception as e:
            self.logger.error(f"测试连接时发生错误: {e}")
            return 1
    
    def handle_config_show(self) -> int:
        """
        显示当前配置
        
        Returns:
            退出码
        """
        try:
            print("📋 当前配置:")
            print("=" * 50)
            print(str(self.config))
            return 0
        except Exception as e:
            self.logger.error(f"显示配置失败: {e}")
            return 1
    
    def handle_config_set(self, key: str, value: str) -> int:
        """
        设置配置项
        
        Args:
            key: 配置键
            value: 配置值
            
        Returns:
            退出码
        """
        try:
            # 类型转换
            if value.lower() in ['true', 'false']:
                value = value.lower() == 'true'
            elif value.isdigit():
                value = int(value)
            elif value.replace('.', '').isdigit():
                value = float(value)
            
            self.config.set(key, value)
            
            if self.config.save():
                print(f"✅ 配置已设置: {key} = {value}")
                return 0
            else:
                print(f"❌ 配置保存失败")
                return 1
                
        except Exception as e:
            self.logger.error(f"设置配置失败: {e}")
            return 1
    
    def handle_config_get(self, key: str) -> int:
        """
        获取配置项
        
        Args:
            key: 配置键
            
        Returns:
            退出码
        """
        try:
            value = self.config.get(key)
            if value is not None:
                print(f"{key} = {value}")
                return 0
            else:
                print(f"配置项不存在: {key}")
                return 1
                
        except Exception as e:
            self.logger.error(f"获取配置失败: {e}")
            return 1
    
    def handle_config_reset(self) -> int:
        """
        重置配置
        
        Returns:
            退出码
        """
        try:
            self.config.reset()
            if self.config.save():
                print("✅ 配置已重置为默认值")
                return 0
            else:
                print("❌ 配置保存失败")
                return 1
                
        except Exception as e:
            self.logger.error(f"重置配置失败: {e}")
            return 1
    
    async def run(self, args: List[str] = None) -> int:
        """
        运行CLI应用
        
        Args:
            args: 命令行参数列表
            
        Returns:
            退出码
        """
        try:
            # 解析命令行参数
            parser = self.create_parser()
            parsed_args = parser.parse_args(args)
            
            # 初始化配置和日志
            self.init_config(parsed_args)
            self.init_logger()
            
            # 处理配置命令
            if parsed_args.config_show:
                return self.handle_config_show()
            
            if parsed_args.config_set:
                return self.handle_config_set(*parsed_args.config_set)
            
            if parsed_args.config_get:
                return self.handle_config_get(parsed_args.config_get)
            
            if parsed_args.config_reset:
                return self.handle_config_reset()
            
            # 如果需要连接服务器，则提示输入密码（如果缺失）
            needs_connection = (
                parsed_args.test_connection or
                parsed_args.fast_fetch or
                parsed_args.shortcut or
                parsed_args.upload or
                parsed_args.download
            )
            
            if needs_connection:
                # 提示输入密码（如果需要）
                self.prompt_password_if_needed()
            
            # 验证服务器配置
            if not self.config.validate_server_config():
                print("❌ 服务器配置不完整，请设置主机、用户名和认证信息")
                print("使用 'dfs --config-show' 查看当前配置")
                print("使用 'dfs --config-set' 设置配置项")
                print("\n提示:")
                print("  - 使用 'dfs user@host' 格式直接指定服务器和用户名")
                print("  - 设置环境变量: export DFS_PASSWORD=your_password")
                print("  - 推荐使用SSH密钥: dfs --config-set server.private_key ~/.ssh/id_rsa")
                return 1
            
            # 初始化客户端
            if not await self.init_client():
                return 1
            
            # 处理主要命令
            if parsed_args.test_connection:
                return await self.handle_test_connection()
            
            if parsed_args.fast_fetch:
                return await self.handle_shortcut('ff')

            if parsed_args.shortcut:
                return await self.handle_shortcut(parsed_args.shortcut)

            if parsed_args.upload:
                return await self.handle_upload(*parsed_args.upload)
            
            if parsed_args.download:
                return await self.handle_download(*parsed_args.download)
            
            # 如果没有指定任何操作，显示帮助
            parser.print_help()
            return 0
            
        except KeyboardInterrupt:
            print("\n⏹️  操作被用户取消")
            if self.transfer_manager:
                self.transfer_manager.stop_transfer()
            return 130
        except Exception as e:
            if self.logger:
                self.logger.error(f"程序执行失败: {e}")
            else:
                print(f"❌ 程序执行失败: {e}")
            return 1


def main(args: List[str] = None) -> None:
    """
    CLI入口函数
    
    Args:
        args: 命令行参数列表
    """
    cli = DFSCli()
    sys.exit(asyncio.run(cli.run(args)))


if __name__ == '__main__':
    sys.exit(main())
