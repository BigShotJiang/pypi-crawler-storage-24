"""
配置管理模块
提供YAML配置文件的读取、写入和管理功能
"""

import copy
import os
import yaml
from typing import Dict, Any, Optional
from pathlib import Path
import multiprocessing


class Config:
    """配置管理类，负责处理YAML配置文件"""
    
    CONFIG_VERSION = 2

    DEFAULT_CONFIG = {
        'config_version': 2,
        'server': {
            'host': '',
            'port': 22,
            'username': '',
            'password': '',
            'private_key': '',
            'timeout': 30
        },
        'transfer': {
            'concurrent_connections': 4,
            'chunk_size': 8192,  # 8KB
            'max_retries': 3,
            'retry_delay': 1.0,
            'verify_checksum': True,
            'skip_file_check': True  # 跳过文件检查，直接覆盖上传或下载
        },
        'logging': {
            'level': 'info',
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            'file_path': '',  # 空表示只输出到控制台
            'max_size': 10485760,  # 10MB
            'backup_count': 3
        },
        'filters': {
            'use_gitignore': True,
            'custom_patterns': [
                '.DS_Store',
                'Thumbs.db',
                '*.tmp',
                '*.temp',
                '*.egg-info/',
                '__pycache__/',
                '*.pyc',
                '*.pyo',
                '*.pyd',
                'build/',
                'dist/',
                '.git/',
                '.vscode/',
                '.idea/'
            ],
            'exclude_hidden': True
        },
        'paths': {
            'use_relative': True,
            'normalize_separators': True,
            'case_sensitive': True
        },
        'shortcuts': {
            'ff': {
                'action': 'download',
                'remote': '/root/logfile',
                'local': '~/downloads/logfile'
            }
        }
    }
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化配置管理器
        
        Args:
            config_path: 配置文件路径，如果为None则使用默认路径
        """
        if config_path is None:
            self.config_path = Path(os.path.expanduser("~")) / ".dfs.yaml"
        else:
            self.config_path = Path(config_path)
        
        self.config: Dict[str, Any] = {}
        self._cpu_cores = self._get_cpu_cores()
        self._load_config()
    
    def _get_cpu_cores(self) -> int:
        """
        获取系统CPU核心数
        
        Returns:
            CPU核心数，如果获取失败则返回4作为默认值
        """
        try:
            return multiprocessing.cpu_count()
        except (ImportError, NotImplementedError):
            # 如果无法获取CPU核心数，返回默认值4
            return 4
    
    def _load_config(self) -> None:
        """加载配置文件"""
        try:
            if self.config_path.exists():
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    loaded_config = yaml.safe_load(f) or {}
                    
                # 合并默认配置和用户配置
                self.config = self._merge_config(copy.deepcopy(self.DEFAULT_CONFIG), loaded_config)
            else:
                # 使用默认配置并创建配置文件
                self.config = copy.deepcopy(self.DEFAULT_CONFIG)
                self._create_default_config()
                
        except Exception as e:
            print(f"警告: 加载配置文件失败 ({e})，使用默认配置")
            self.config = copy.deepcopy(self.DEFAULT_CONFIG)

        # 优化并发连接数配置
        self._optimize_concurrent_connections()

    def _optimize_concurrent_connections(self) -> None:
        """
        优化并发连接数配置，确保不超过系统核心数
        """
        current_concurrent = self.config.get('transfer', {}).get('concurrent_connections', 4)
        
        # 计算推荐的并发连接数
        # 规则：不超过CPU核心数，但至少为1，最多为16
        recommended_concurrent = min(max(1, self._cpu_cores), 16)
        
        if current_concurrent > self._cpu_cores:
            # 如果当前配置超过CPU核心数，自动调整并给出警告
            print(f"警告: 并发连接数 ({current_concurrent}) 超过系统CPU核心数 ({self._cpu_cores})")
            print(f"自动调整为推荐值: {recommended_concurrent}")
            
            # 更新配置
            if 'transfer' not in self.config:
                self.config['transfer'] = {}
            self.config['transfer']['concurrent_connections'] = recommended_concurrent
        elif current_concurrent <= 0:
            # 如果配置值无效，使用推荐值
            print(f"警告: 并发连接数配置无效 ({current_concurrent})")
            print(f"自动调整为推荐值: {recommended_concurrent}")
            
            if 'transfer' not in self.config:
                self.config['transfer'] = {}
            self.config['transfer']['concurrent_connections'] = recommended_concurrent
    
    def _merge_config(self, default: Dict[str, Any], user: Dict[str, Any]) -> Dict[str, Any]:
        """
        递归合并配置字典
        
        Args:
            default: 默认配置
            user: 用户配置
            
        Returns:
            合并后的配置
        """
        result = default.copy()
        
        for key, value in user.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_config(result[key], value)
            else:
                result[key] = value
                
        return result
    
    # 带注释的初始配置模板，仅用于首次生成配置文件
    _DEFAULT_CONFIG_TEMPLATE = """\
# DFS 配置文件 (~/.dfs.yaml)

config_version: 2

# ── 服务器连接 ────────────────────────────────────────────────────────────────
server:
  host: ''          # SFTP 服务器地址，如 10.0.0.1 或 example.com
  port: 22          # SSH/SFTP 端口，默认 22
  username: ''      # 登录用户名
  password: ''      # 登录密码（建议改用环境变量 DFS_PASSWORD 代替明文）
  private_key: ''   # SSH 私钥路径，如 ~/.ssh/id_rsa（优先级高于 password）
  timeout: 30       # 连接超时时间（秒）

# ── 传输控制 ─────────────────────────────────────────────────────────────────
transfer:
  concurrent_connections: 4  # 并发连接数（建议 ≤ CPU 核心数，最大 16）
  chunk_size: 8192            # 分块大小（字节），默认 8 KB
  max_retries: 3              # 失败后自动重试次数
  retry_delay: 1.0            # 重试间隔（秒）
  verify_checksum: true       # 传输完成后校验文件完整性（MD5 采样）
  skip_file_check: true       # true=直接覆盖（更快）；false=比对内容后跳过相同文件

# ── 日志 ─────────────────────────────────────────────────────────────────────
logging:
  level: info                 # 日志级别：debug / info / warning / error
  format: '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
  file_path: ''               # 日志文件路径，留空则只输出到控制台
  max_size: 10485760          # 日志文件最大大小（字节），默认 10 MB
  backup_count: 3             # 日志文件滚动备份数量

# ── 文件过滤 ─────────────────────────────────────────────────────────────────
filters:
  use_gitignore: true         # 自动读取目录中的 .gitignore 规则
  exclude_hidden: true        # 排除以 . 开头的隐藏文件/目录
  custom_patterns:            # 自定义排除规则，支持 .gitignore 通配符语法
    - .DS_Store
    - Thumbs.db
    - '*.tmp'
    - '*.temp'
    - '*.egg-info/'
    - __pycache__/
    - '*.pyc'
    - '*.pyo'
    - '*.pyd'
    - build/
    - dist/
    - .git/
    - .vscode/
    - .idea/

# ── 路径处理 ─────────────────────────────────────────────────────────────────
paths:
  use_relative: true          # 使用相对路径
  normalize_separators: true  # 统一路径分隔符（跨平台兼容）
  case_sensitive: true        # 路径大小写敏感（Linux/macOS 建议 true）

# ── 快捷方式 ─────────────────────────────────────────────────────────────────
# 使用 `dfs -s <名称>` 执行，或用内置别名 `dfs -ff` 执行名为 ff 的快捷方式
# 每个快捷方式包含：
#   action : upload（上传）或 download（下载）
#   remote : 远程路径
#   local  : 本地路径
shortcuts:
  ff:
    action: download
    remote: /root/logfile
    local: ~/downloads/logfile
  # 示例 - 上传快捷方式：
  # backup:
  #   action: upload
  #   local: ./src
  #   remote: /backup/src
"""

    def _create_default_config(self) -> None:
        """首次创建带注释的默认配置文件"""
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_path, 'w', encoding='utf-8') as f:
                f.write(self._DEFAULT_CONFIG_TEMPLATE)
            print(f"已创建默认配置文件: {self.config_path}")
        except Exception as e:
            print(f"警告: 创建配置文件失败 ({e})")
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置值，支持点号分隔的嵌套键
        
        Args:
            key: 配置键，如 'server.host' 或 'transfer.concurrent_connections'
            default: 默认值
            
        Returns:
            配置值
        """
        keys = key.split('.')
        value = self.config
        
        try:
            for k in keys:
                value = value[k]
            return value
        except (KeyError, TypeError):
            return default
    
    def set(self, key: str, value: Any) -> None:
        """
        设置配置值，支持点号分隔的嵌套键
        
        Args:
            key: 配置键
            value: 配置值
        """
        keys = key.split('.')
        config = self.config
        
        # 导航到最后一层
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        # 设置值
        config[keys[-1]] = value
    
    def save(self) -> bool:
        """
        保存配置到文件
        
        Returns:
            是否保存成功
        """
        try:
            # 确保配置目录存在
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 保存配置
            with open(self.config_path, 'w', encoding='utf-8') as f:
                yaml.dump(self.config, f, default_flow_style=False,
                         allow_unicode=True, indent=2)
                         
            return True
            
        except Exception as e:
            print(f"保存配置文件失败: {e}")
            return False
    
    def reset(self) -> None:
        """重置为默认配置"""
        self.config = copy.deepcopy(self.DEFAULT_CONFIG)
    
    def get_all(self) -> Dict[str, Any]:
        """获取所有配置"""
        return self.config.copy()
    
    def validate_server_config(self) -> bool:
        """
        验证服务器配置是否完整
        
        Returns:
            配置是否有效
        """
        required_fields = ['host', 'username']
        
        for field in required_fields:
            if not self.get(f'server.{field}'):
                return False
                
        # 检查认证方式
        has_password = bool(self.get('server.password'))
        has_private_key = bool(self.get('server.private_key'))
        
        return has_password or has_private_key
    
    def __str__(self) -> str:
        """返回配置的字符串表示"""
        return yaml.dump(self.config, default_flow_style=False, 
                        allow_unicode=True, indent=2)
