"""
日志系统模块
提供统一的日志记录功能，支持多级别日志和本地时间显示
"""

import logging
import logging.handlers
from typing import Optional
from datetime import datetime
import os
from pathlib import Path


class LocalTimeFormatter(logging.Formatter):
    """自定义格式化器，使用本地时间而不是UTC时间"""
    
    def formatTime(self, record, datefmt=None):
        """
        格式化时间为本地时间
        
        Args:
            record: 日志记录
            datefmt: 日期格式
            
        Returns:
            格式化的时间字符串
        """
        dt = datetime.fromtimestamp(record.created)
        if datefmt:
            return dt.strftime(datefmt)
        else:
            return dt.strftime('%Y-%m-%d %H:%M:%S')


class Logger:
    """日志管理类"""
    
    _instances = {}  # 单例模式，避免重复创建logger
    
    def __new__(cls, name: str = 'dfs', config: Optional[dict] = None):
        """
        单例模式创建logger实例
        
        Args:
            name: logger名称
            config: 日志配置
            
        Returns:
            Logger实例
        """
        if name not in cls._instances:
            instance = super().__new__(cls)
            cls._instances[name] = instance
            instance._initialized = False
        return cls._instances[name]
    
    def __init__(self, name: str = 'dfs', config: Optional[dict] = None):
        """
        初始化日志器
        
        Args:
            name: logger名称
            config: 日志配置字典
        """
        if self._initialized:
            return
            
        self.name = name
        self.logger = logging.getLogger(name)
        self.config = config or {}
        
        # 设置默认配置
        self.level = self.config.get('level', 'info').upper()
        self.format_str = self.config.get('format', 
                                         '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.file_path = self.config.get('file_path', '')
        self.max_size = self.config.get('max_size', 10485760)  # 10MB
        self.backup_count = self.config.get('backup_count', 3)
        
        self._setup_logger()
        self._initialized = True
    
    def _setup_logger(self) -> None:
        """设置日志器"""
        # 清除现有的处理器
        self.logger.handlers.clear()
        
        # 设置日志级别
        level_map = {
            'DEBUG': logging.DEBUG,
            'INFO': logging.INFO,
            'WARNING': logging.WARNING,
            'ERROR': logging.ERROR,
            'CRITICAL': logging.CRITICAL
        }
        self.logger.setLevel(level_map.get(self.level, logging.INFO))
        
        # 创建格式化器
        formatter = LocalTimeFormatter(self.format_str)
        
        # 控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)
        
        # 文件处理器（如果配置了文件路径）
        if self.file_path:
            try:
                # 确保日志目录存在
                expanded_path = os.path.expanduser(self.file_path)
                log_path = Path(expanded_path)
                log_path.parent.mkdir(parents=True, exist_ok=True)
                
                # 使用RotatingFileHandler支持日志轮转
                file_handler = logging.handlers.RotatingFileHandler(
                    expanded_path,
                    maxBytes=self.max_size,
                    backupCount=self.backup_count,
                    encoding='utf-8'
                )
                file_handler.setFormatter(formatter)
                self.logger.addHandler(file_handler)
                
            except Exception as e:
                self.logger.warning(f"无法创建文件日志处理器: {e}")
        
        # 防止日志传播到根logger
        self.logger.propagate = False
    
    def debug(self, message: str, *args, **kwargs) -> None:
        """记录DEBUG级别日志"""
        self.logger.debug(message, *args, **kwargs)
    
    def info(self, message: str, *args, **kwargs) -> None:
        """记录INFO级别日志"""
        self.logger.info(message, *args, **kwargs)
    
    def warning(self, message: str, *args, **kwargs) -> None:
        """记录WARNING级别日志"""
        self.logger.warning(message, *args, **kwargs)
    
    def error(self, message: str, *args, **kwargs) -> None:
        """记录ERROR级别日志"""
        self.logger.error(message, *args, **kwargs)
    
    def critical(self, message: str, *args, **kwargs) -> None:
        """记录CRITICAL级别日志"""
        self.logger.critical(message, *args, **kwargs)
    
    def exception(self, message: str, *args, **kwargs) -> None:
        """记录异常日志，包含堆栈信息"""
        self.logger.exception(message, *args, **kwargs)
    
    def set_level(self, level: str) -> None:
        """
        动态设置日志级别
        
        Args:
            level: 日志级别字符串
        """
        level_map = {
            'DEBUG': logging.DEBUG,
            'INFO': logging.INFO,
            'WARNING': logging.WARNING,
            'ERROR': logging.ERROR,
            'CRITICAL': logging.CRITICAL
        }
        
        if level.upper() in level_map:
            self.logger.setLevel(level_map[level.upper()])
            self.level = level.upper()
    
    def add_file_handler(self, file_path: str, max_size: int = 10485760, 
                        backup_count: int = 3) -> bool:
        """
        添加文件处理器
        
        Args:
            file_path: 日志文件路径
            max_size: 最大文件大小
            backup_count: 备份文件数量
            
        Returns:
            是否添加成功
        """
        try:
            # 确保日志目录存在
            expanded_path = os.path.expanduser(file_path)
            log_path = Path(expanded_path)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 创建文件处理器
            formatter = LocalTimeFormatter(self.format_str)
            file_handler = logging.handlers.RotatingFileHandler(
                expanded_path,
                maxBytes=max_size,
                backupCount=backup_count,
                encoding='utf-8'
            )
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)
            
            return True
            
        except Exception as e:
            self.logger.error(f"添加文件处理器失败: {e}")
            return False
    
    def get_logger(self) -> logging.Logger:
        """
        获取底层的logging.Logger对象
        
        Returns:
            logging.Logger实例
        """
        return self.logger
    
    @classmethod
    def get_instance(cls, name: str = 'dfs') -> 'Logger':
        """
        获取已存在的logger实例
        
        Args:
            name: logger名称
            
        Returns:
            Logger实例
        """
        return cls._instances.get(name, cls(name))
    
    @classmethod
    def cleanup(cls) -> None:
        """清理所有logger实例"""
        for logger in cls._instances.values():
            for handler in logger.logger.handlers:
                handler.close()
            logger.logger.handlers.clear()
        cls._instances.clear()


def get_logger(name: str = 'dfs', config: Optional[dict] = None) -> Logger:
    """
    便捷函数：获取logger实例
    
    Args:
        name: logger名称
        config: 日志配置
        
    Returns:
        Logger实例
    """
    return Logger(name, config)
