"""
传输管理器模块
实现并发文件传输管理，避免竞态条件，提供统一的传输接口
"""

import asyncio
import time
from typing import List, Dict, Optional, Callable, Tuple, Set, Any
from pathlib import Path
from dataclasses import dataclass
from enum import Enum
import hashlib
import os
import threading

from ..protocols.base import ProtocolClient, TransferProgress, TransferStatus, FileInfo
from ..utils.path_handler import PathHandler
from ..utils.file_filter import FileFilter
from ..utils.progress_display import ProgressDisplay
from .logger import Logger


class TransferType(Enum):
    """传输类型枚举"""
    UPLOAD = "upload"
    DOWNLOAD = "download"


@dataclass
class TransferTask:
    """传输任务数据类"""
    task_id: str
    transfer_type: TransferType
    local_path: str
    remote_path: str
    is_directory: bool
    size: int = 0
    priority: int = 0  # 优先级，数字越大优先级越高
    retry_count: int = 0
    max_retries: int = 3
    
    def __hash__(self):
        return hash(self.task_id)
    
    def __eq__(self, other):
        if not isinstance(other, TransferTask):
            return False
        return self.task_id == other.task_id


class TransferManager:
    """传输管理器，负责并发传输任务的调度和执行"""
    
    def __init__(self, client: ProtocolClient, config: Dict[str, Any], logger: Logger):
        """
        初始化传输管理器
        
        Args:
            client: 协议客户端（主连接，用于初始化和测试）
            config: 配置字典
            logger: 日志器
        """
        self.client = client
        self.config = config
        self.logger = logger
        
        # 并发控制
        self.max_concurrent = config.get('concurrent_connections', 4)
        self.semaphore = asyncio.Semaphore(self.max_concurrent)
        
        # 服务器配置（用于创建独立连接）
        self.server_config = {
            'host': config.get('host', ''),
            'port': config.get('port', 22),
            'username': config.get('username', ''),
            'password': config.get('password', ''),
            'private_key': config.get('private_key', ''),
            'timeout': config.get('timeout', 30),
            'chunk_size': config.get('chunk_size', 8192),
            'max_retries': config.get('max_retries', 3),
            'retry_delay': config.get('retry_delay', 1.0),
            'verify_checksum': config.get('verify_checksum', True),
            'skip_file_check': config.get('skip_file_check', True)
        }
        
        # 任务管理
        self.pending_tasks: asyncio.Queue = asyncio.Queue()
        self.active_tasks: Dict[str, TransferTask] = {}
        self.completed_tasks: Set[str] = set()
        self.failed_tasks: Dict[str, str] = {}  # task_id -> error_message
        
        # 内存管理配置
        self._max_completed_records = 10000  # 最大完成任务记录数
        self._max_failed_records = 1000     # 最大失败任务记录数
        
        # 进度管理
        self.progress_display = ProgressDisplay()
        self.progress_callback: Optional[Callable[[TransferProgress], None]] = None
        self.task_progresses: Dict[str, TransferProgress] = {}
        
        # 工具类
        self.path_handler = PathHandler(
            case_sensitive=config.get('case_sensitive', True)
        )
        self.file_filter = FileFilter(
            patterns=config.get('custom_patterns', []),
            use_gitignore=config.get('use_gitignore', True),
            use_system_filters=config.get('use_system_filters', True),
            case_sensitive=config.get('case_sensitive', True)
        )
        
        # 统计信息
        self.stats = {
            'total_files': 0,
            'completed_files': 0,
            'failed_files': 0,
            'skipped_files': 0,  # 新增：跳过的文件数量
            'total_bytes': 0,
            'transferred_bytes': 0,
            'start_time': 0,
            'end_time': 0
        }
        
        # 控制标志
        self._is_running = False
        self._should_stop = False
        
        # 任务去重
        self._processed_paths: Set[str] = set()
        
        # 统计信息锁（保护统计数据的线程安全）
        self._stats_lock = threading.Lock()
    
    async def upload_file(self, local_path: str, remote_path: str) -> bool:
        """
        上传单个文件
        
        Args:
            local_path: 本地文件路径
            remote_path: 远程文件路径
            
        Returns:
            是否上传成功
        """
        return await self._add_file_task(TransferType.UPLOAD, local_path, remote_path)
    
    async def download_file(self, remote_path: str, local_path: str) -> bool:
        """
        下载单个文件
        
        Args:
            remote_path: 远程文件路径
            local_path: 本地文件路径
            
        Returns:
            是否下载成功
        """
        return await self._add_file_task(TransferType.DOWNLOAD, remote_path, local_path)
    
    async def upload_directory(self, local_path: str, remote_path: str) -> bool:
        """
        上传目录
        
        Args:
            local_path: 本地目录路径
            remote_path: 远程目录路径
            
        Returns:
            是否上传成功
        """
        return await self._add_directory_task(TransferType.UPLOAD, local_path, remote_path)
    
    async def download_directory(self, remote_path: str, local_path: str) -> bool:
        """
        下载目录
        
        Args:
            remote_path: 远程目录路径
            local_path: 本地目录路径
            
        Returns:
            是否下载成功
        """
        return await self._add_directory_task(TransferType.DOWNLOAD, remote_path, local_path)
    
    async def _add_file_task(self, transfer_type: TransferType, source_path: str, dest_path: str) -> bool:
        """
        添加文件传输任务
        
        Args:
            transfer_type: 传输类型
            source_path: 源路径
            dest_path: 目标路径
            
        Returns:
            是否添加成功
        """
        try:
            # 生成任务ID
            task_id = self._generate_task_id(transfer_type, source_path, dest_path)
            
            # 避免重复任务
            if task_id in self._processed_paths:
                self.logger.debug(f"跳过重复任务: {source_path}")
                return True
            
            # 获取文件大小
            file_size = 0
            skip_file_check = self.config.get('skip_file_check', True)
            
            if transfer_type == TransferType.UPLOAD:
                local_file = Path(source_path)
                if local_file.exists() and local_file.is_file():
                    file_size = local_file.stat().st_size
                else:
                    if skip_file_check:
                        # 跳过文件检查模式下，即使本地文件不存在也创建任务（可能在传输时创建）
                        self.logger.warning(f"跳过文件检查模式：本地文件不存在 {source_path}")
                        file_size = 0
                    else:
                        self.logger.error(f"本地文件不存在: {source_path}")
                        return False
            else:  # DOWNLOAD
                if skip_file_check:
                    # 跳过文件检查模式下，不获取远程文件信息，直接创建任务
                    self.logger.debug(f"跳过文件检查模式：不验证远程文件 {source_path}")
                    file_size = 0  # 文件大小未知，传输时再确定
                else:
                    # 正常模式下，获取远程文件基础信息（任务添加阶段不计算校验和）
                    file_info = await self.client.get_file_info_basic(source_path)
                    if file_info and not file_info.is_directory:
                        file_size = file_info.size
                    else:
                        self.logger.error(f"远程文件不存在或是目录: {source_path}")
                        return False
            
            # 创建传输任务
            task = TransferTask(
                task_id=task_id,
                transfer_type=transfer_type,
                local_path=source_path if transfer_type == TransferType.UPLOAD else dest_path,
                remote_path=dest_path if transfer_type == TransferType.UPLOAD else source_path,
                is_directory=False,
                size=file_size,
                max_retries=self.config.get('max_retries', 3)
            )
            
            # 添加到队列
            await self.pending_tasks.put(task)
            self._processed_paths.add(task_id)
            
            # 线程安全地更新统计信息
            with self._stats_lock:
                self.stats['total_files'] += 1
                self.stats['total_bytes'] += file_size
            
            self.logger.debug(f"添加文件传输任务: {source_path} -> {dest_path} (大小: {file_size} 字节)")
            return True
            
        except Exception as e:
            self.logger.error(f"添加文件传输任务失败: {e}")
            return False
    
    async def _add_directory_task(self, transfer_type: TransferType, source_path: str, dest_path: str) -> bool:
        """
        添加目录传输任务（递归处理）
        
        Args:
            transfer_type: 传输类型
            source_path: 源路径
            dest_path: 目标路径
            
        Returns:
            是否添加成功
        """
        try:
            self.logger.info("正在确定传输文件, 请稍候...")
            if transfer_type == TransferType.UPLOAD:
                return await self._scan_local_directory(source_path, dest_path)
            else:
                return await self._scan_remote_directory(source_path, dest_path)
                
        except Exception as e:
            self.logger.error(f"添加目录传输任务失败: {e}")
            return False
    
    async def _scan_local_directory(self, local_path: str, remote_path: str) -> bool:
        """
        扫描本地目录并添加上传任务
        
        Args:
            local_path: 本地目录路径
            remote_path: 远程目录路径
            
        Returns:
            是否扫描成功
        """
        local_dir = Path(local_path)
        if not local_dir.exists() or not local_dir.is_dir():
            self.logger.error(f"本地目录不存在: {local_path}")
            return False
        
        # 自动加载.gitignore文件
        self.file_filter.auto_load_gitignores(local_path)
        
        # 递归扫描目录
        for root, dirs, files in os.walk(local_dir):
            # 过滤目录
            dirs[:] = [d for d in dirs if not self.file_filter.should_ignore(
                os.path.join(root, d), local_path
            )]
            
            # 处理文件
            for filename in files:
                local_file_path = os.path.join(root, filename)
                
                # 应用文件过滤器
                if self.file_filter.should_ignore(local_file_path, local_path):
                    self.logger.debug(f"跳过被过滤的文件: {local_file_path}")
                    continue
                
                # 计算远程文件路径
                rel_path = os.path.relpath(local_file_path, local_path)
                remote_file_path = self.path_handler.join_paths(remote_path, rel_path)
                remote_file_path = remote_file_path.replace('\\', '/')  # 统一使用正斜杠
                
                # 添加文件传输任务
                await self._add_file_task(TransferType.UPLOAD, local_file_path, remote_file_path)
        
        return True
    
    async def _scan_remote_directory(self, remote_path: str, local_path: str) -> bool:
        """
        扫描远程目录并添加下载任务（优化版本：批量获取文件信息）
        
        Args:
            remote_path: 远程目录路径
            local_path: 本地目录路径
            
        Returns:
            是否扫描成功
        """
        try:
            skip_file_check = self.config.get('skip_file_check', True)
            
            if skip_file_check:
                # 跳过文件检查模式：使用原有快速方式
                return await self._scan_remote_directory_fast(remote_path, local_path)
            else:
                # 正常模式：使用批量优化方式
                return await self._scan_remote_directory_optimized(remote_path, local_path)
            
        except Exception as e:
            self.logger.error(f"扫描远程目录失败: {e}")
            return False
    
    async def _scan_remote_directory_fast(self, remote_path: str, local_path: str) -> bool:
        """
        快速扫描远程目录（skip_file_check=true模式）
        """
        # 递归获取远程目录中的所有文件
        remote_files = await self._list_remote_files_recursive(remote_path)
        
        for file_info in remote_files:
            if file_info.is_directory:
                continue
            
            # 计算本地文件路径（Windows 下自动净化非法字符）
            local_file_path = self.path_handler.remote_to_local_path(
                file_info.path, remote_path, local_path
            )
            
            # 应用文件过滤器
            if self.file_filter.should_ignore(file_info.path, remote_path):
                self.logger.debug(f"跳过被过滤的文件: {file_info.path}")
                continue
            
            # 添加文件传输任务（跳过文件检查）
            await self._add_file_task(TransferType.DOWNLOAD, file_info.path, local_file_path)
        
        return True
    
    async def _scan_remote_directory_optimized(self, remote_path: str, local_path: str) -> bool:
        """
        优化的远程目录扫描（skip_file_check=false模式，使用批量获取）
        """
        self.logger.debug(f"开始优化扫描远程目录: {remote_path}")
        start_time = time.time()
        
        # 1. 首先收集所有文件路径（轻量级操作）
        self.logger.debug("步骤1: 收集所有文件路径")
        collect_start = time.time()
        all_file_paths = await self._collect_remote_file_paths_only(remote_path)
        collect_time = time.time() - collect_start
        self.logger.debug(f"收集文件路径完成: {collect_time:.2f}s, 发现 {len(all_file_paths)} 个文件")
        
        if not all_file_paths:
            self.logger.info("远程目录为空或无可传输文件")
            return True
        
        # 2. 应用文件过滤器（在批量获取前过滤，减少网络请求）
        self.logger.debug("步骤2: 应用文件过滤器")
        filter_start = time.time()
        filtered_paths = []
        for file_path in all_file_paths:
            if not self.file_filter.should_ignore(file_path, remote_path):
                filtered_paths.append(file_path)
            else:
                self.logger.debug(f"跳过被过滤的文件: {file_path}")
        
        filter_time = time.time() - filter_start
        self.logger.debug(f"文件过滤完成: {filter_time:.2f}s, 剩余 {len(filtered_paths)} 个文件")
        
        if not filtered_paths:
            self.logger.info("所有文件都被过滤器排除")
            return True

        self.logger.info(f"发现 {len(filtered_paths)} 个待传输文件，正在批量获取基础信息...")
        
        # 3. 批量获取文件基础信息（不计算校验和）
        self.logger.debug("步骤3: 批量获取文件基础信息")
        batch_start = time.time()
        batch_size = 10  # 每批处理10个文件，提高响应性
        for i in range(0, len(filtered_paths), batch_size):
            batch_paths = filtered_paths[i:i + batch_size]
            batch_num = i//batch_size + 1
            total_batches = (len(filtered_paths) + batch_size - 1)//batch_size
            self.logger.debug(f"处理文件批次 {batch_num}/{total_batches} ({len(batch_paths)} 个文件)")
            
            batch_info_start = time.time()
            # 批量获取基础文件信息
            files_info = await self.client.get_files_info_batch_basic(batch_paths, max_concurrent=6)
            batch_info_time = time.time() - batch_info_start
            self.logger.debug(f"批次 {batch_num} 信息获取耗时: {batch_info_time:.2f}s")
            
            # 4. 为每个文件创建任务
            for file_path, file_info in files_info.items():
                if not file_info or file_info.is_directory:
                    continue
                
                # 计算本地文件路径（Windows 下自动净化非法字符）
                local_file_path = self.path_handler.remote_to_local_path(
                    file_path, remote_path, local_path
                )
                
                # 直接创建任务（使用已获取的基础信息）
                await self._add_file_task_with_basic_info(
                    TransferType.DOWNLOAD, file_path, local_file_path, file_info
                )
        
        batch_time = time.time() - batch_start
        total_time = time.time() - start_time
        self.logger.debug(f"批量处理完成: {batch_time:.2f}s")
        self.logger.debug(f"优化扫描总耗时: {total_time:.2f}s")
        
        return True
    
    async def _list_remote_files_recursive(self, remote_path: str) -> List[FileInfo]:
        """
        递归列出远程目录中的所有文件
        
        Args:
            remote_path: 远程目录路径
            
        Returns:
            文件信息列表
        """
        all_files = []
        
        try:
            # 获取当前目录内容
            files = await self.client.list_directory(remote_path)
            
            for file_info in files:
                if file_info.is_directory:
                    # 递归处理子目录
                    subdir_files = await self._list_remote_files_recursive(file_info.path)
                    all_files.extend(subdir_files)
                else:
                    # 添加文件
                    all_files.append(file_info)
            
            return all_files
            
        except Exception as e:
            self.logger.error(f"列出远程目录失败 {remote_path}: {e}")
            return []
    
    async def _collect_remote_file_paths_only(self, remote_path: str) -> List[str]:
        """
        收集远程目录中的所有文件路径（仅路径，不获取详细信息）
        
        Args:
            remote_path: 远程目录路径
            
        Returns:
            文件路径列表
        """
        all_file_paths = []
        
        try:
            await self._collect_paths_recursive_only(remote_path, all_file_paths)
            return all_file_paths
        except Exception as e:
            self.logger.error(f"收集远程文件路径失败 {remote_path}: {e}")
            return []
    
    async def _collect_paths_recursive_only(self, current_path: str, file_paths: List[str]) -> None:
        """
        递归收集文件路径（仅路径，优化版本）
        
        Args:
            current_path: 当前目录路径
            file_paths: 文件路径列表（会被修改）
        """
        try:
            self.logger.debug(f"开始扫描目录: {current_path}")
            
            # 获取当前目录内容（只需要基础信息），添加超时控制
            try:
                items = await asyncio.wait_for(
                    self.client.list_directory(current_path), 
                    timeout=30.0  # 30秒超时
                )
            except asyncio.TimeoutError:
                self.logger.error(f"扫描目录超时: {current_path}")
                return
                
            self.logger.debug(f"目录 {current_path} 包含 {len(items)} 个项目")
            
            # 分离文件和目录，并发处理子目录
            directories = []
            file_count = 0
            for item in items:
                if item.is_directory:
                    directories.append(item.path)
                    self.logger.debug(f"发现子目录: {item.path}")
                else:
                    file_paths.append(item.path)
                    file_count += 1
            
            self.logger.debug(f"目录 {current_path}: {file_count} 个文件, {len(directories)} 个子目录")
            
            # 并发处理子目录（限制并发数避免过多连接）
            if directories:
                self.logger.debug(f"开始并发处理 {len(directories)} 个子目录")
                # 减少并发数，避免 SFTP 连接问题
                semaphore = asyncio.Semaphore(1)  # 改为串行处理，避免连接冲突
                
                async def process_directory(dir_path: str):
                    async with semaphore:
                        self.logger.debug(f"处理子目录: {dir_path}")
                        try:
                            await asyncio.wait_for(
                                self._collect_paths_recursive_only(dir_path, file_paths),
                                timeout=60.0  # 每个子目录60秒超时
                            )
                            self.logger.debug(f"完成子目录: {dir_path}")
                        except asyncio.TimeoutError:
                            self.logger.error(f"处理子目录超时: {dir_path}")
                        except Exception as e:
                            self.logger.error(f"处理子目录失败 {dir_path}: {e}")
                
                # 并发处理所有子目录
                tasks = [process_directory(dir_path) for dir_path in directories]
                await asyncio.gather(*tasks, return_exceptions=True)
                self.logger.debug(f"完成所有子目录处理: {current_path}")
                
        except Exception as e:
            self.logger.error(f"收集路径失败 {current_path}: {e}")
            self.logger.debug(f"收集路径异常详情", exc_info=True)
    
    async def _add_file_task_with_basic_info(self, transfer_type: TransferType, source_path: str, 
                                           dest_path: str, file_info: FileInfo) -> bool:
        """
        使用已有基础文件信息添加传输任务（优化版本）
        
        Args:
            transfer_type: 传输类型
            source_path: 源路径
            dest_path: 目标路径
            file_info: 已获取的基础文件信息
            
        Returns:
            是否添加成功
        """
        try:
            # 生成任务ID
            task_id = self._generate_task_id(transfer_type, source_path, dest_path)
            
            # 避免重复任务
            if task_id in self._processed_paths:
                self.logger.debug(f"跳过重复任务: {source_path}")
                return True
            
            # 使用已有的基础文件信息
            file_size = file_info.size if file_info else 0
            
            # 创建传输任务
            task = TransferTask(
                task_id=task_id,
                transfer_type=transfer_type,
                local_path=source_path if transfer_type == TransferType.UPLOAD else dest_path,
                remote_path=dest_path if transfer_type == TransferType.UPLOAD else source_path,
                is_directory=False,
                size=file_size,
                max_retries=self.config.get('max_retries', 3)
            )
            
            # 添加到队列
            await self.pending_tasks.put(task)
            self._processed_paths.add(task_id)
            
            # 线程安全地更新统计信息
            with self._stats_lock:
                self.stats['total_files'] += 1
                self.stats['total_bytes'] += file_size
            
            self.logger.debug(f"添加文件传输任务: {source_path} -> {dest_path} (大小: {file_size} 字节)")
            return True
            
        except Exception as e:
            self.logger.error(f"添加文件传输任务失败: {e}")
            return False
    
    def _generate_task_id(self, transfer_type: TransferType, source_path: str, dest_path: str) -> str:
        """
        生成任务ID
        
        Args:
            transfer_type: 传输类型
            source_path: 源路径
            dest_path: 目标路径
            
        Returns:
            任务ID
        """
        content = f"{transfer_type.value}:{source_path}:{dest_path}"
        return hashlib.md5(content.encode()).hexdigest()
    
    async def start_transfer(self) -> bool:
        """
        开始传输任务
        
        Returns:
            是否成功完成所有任务
        """
        if self._is_running:
            self.logger.warning("传输任务已在运行中")
            return False
        
        # 检查是否有任务
        if self.stats['total_files'] == 0:
            self.logger.info("没有需要传输的文件")
            return True
        
        self._is_running = True
        self._should_stop = False
        self.stats['start_time'] = time.time()
        
        self.logger.info(f"开始传输任务，并发数: {self.max_concurrent}，总文件数: {self.stats['total_files']}")
        self.progress_display.set_total_files(self.stats['total_files'])
        
        try:
            # 确保SFTP客户端已连接
            if not self.client.is_connected:
                self.logger.info("连接SFTP服务器...")
                if not await self.client.connect():
                    self.logger.error("SFTP连接失败")
                    return False
                    
            # 测试连接
            self.logger.debug("测试SFTP连接...")
            
            # 创建工作协程
            workers = [
                asyncio.create_task(self._worker(f"Worker-{i}"))
                for i in range(self.max_concurrent)
            ]
            
            # 等待队列为空或所有worker完成
            done_workers = 0
            while done_workers < len(workers) and not self.pending_tasks.empty():
                # 等待一段时间，检查进度
                await asyncio.sleep(0.1)
                done_workers = sum(1 for w in workers if w.done())
            
            # 停止所有worker
            self._should_stop = True
            
            # 等待所有worker完成
            await asyncio.gather(*workers, return_exceptions=True)
            
            self.stats['end_time'] = time.time()
            success = len(self.failed_tasks) == 0
            
            self.logger.info(f"传输任务完成，成功: {self.stats['completed_files']}, "
                           f"失败: {len(self.failed_tasks)}, 跳过: {self.stats['skipped_files']}")
            
            # 清理进度显示（只清理动态进度行，保留完成的进度条）
            self.progress_display.finish_display()
            
            # 显示摘要
            if self.stats['total_files'] > 0:
                self.progress_display.show_summary()
            
            return success
            
        except Exception as e:
            self.logger.error(f"传输任务执行失败: {e}")
            return False
        finally:
            self._is_running = False
    
    async def _worker(self, worker_name: str) -> None:
        """
        工作协程，处理传输任务（使用持久连接）
        
        Args:
            worker_name: 工作者名称
        """
        self.logger.debug(f"{worker_name} 启动")
        
        # 为这个worker创建持久的SFTP连接
        from ..protocols.sftp_client import SFTPClient
        worker_client = SFTPClient(self.server_config.copy())
        
        try:
            self.logger.debug(f"{worker_name} 创建持久SFTP连接")
            
            # 初始连接
            if not await worker_client.connect():
                self.logger.error(f"{worker_name} 初始SFTP连接失败")
                return
            
            self.logger.debug(f"{worker_name} 持久SFTP连接已建立")
            
            while not self._should_stop:
                task = None
                try:
                    # 获取任务（超时机制避免无限等待）
                    task = await asyncio.wait_for(self.pending_tasks.get(), timeout=1.0)
                    
                    self.logger.debug(f"{worker_name} 获取到任务: {task.local_path}")
                    
                    # 获取并发信号量
                    async with self.semaphore:
                        should_retry = await self._execute_task_with_persistent_connection(task, worker_name, worker_client)
                        
                        # 如果需要重试，重新放入队列（不调用task_done）
                        if should_retry:
                            await asyncio.sleep(self.config.get('retry_delay', 1.0))
                            await self.pending_tasks.put(task)
                            task = None  # 重试任务不调用task_done()
                    
                except asyncio.TimeoutError:
                    # 超时，检查是否还有任务或应该停止
                    if self.pending_tasks.empty() or self._should_stop:
                        self.logger.debug(f"{worker_name} 超时退出，队列为空: {self.pending_tasks.empty()}")
                        break
                    continue
                except Exception as e:
                    self.logger.error(f"{worker_name} 执行任务失败: {e}")
                finally:
                    # 只有成功获取任务后才调用task_done()
                    if task is not None:
                        self.pending_tasks.task_done()
                        task = None
        
        finally:
            # 关闭worker的持久连接
            if worker_client and worker_client.is_connected:
                await worker_client.disconnect()
                self.logger.debug(f"{worker_name} 持久SFTP连接已关闭")
        
        self.logger.debug(f"{worker_name} 停止")
    
    async def _execute_task_with_persistent_connection(self, task: TransferTask, worker_name: str, client: 'ProtocolClient') -> bool:
        """
        使用持久连接执行单个传输任务
        
        Args:
            task: 传输任务
            worker_name: 工作者名称
            client: 持久的SFTP客户端连接
            
        Returns:
            bool: 是否需要重试该任务
        """
        self.active_tasks[task.task_id] = task
        
        try:
            # 检查连接状态，如果断开则重连
            if not client.is_connected:
                self.logger.debug(f"{worker_name} 检测到连接断开，正在重连...")
                if not await client.connect():
                    raise ConnectionError("SFTP重连失败")
                self.logger.debug(f"{worker_name} SFTP重连成功")
            
            self.logger.debug(f"{worker_name} 开始执行任务: {task.local_path}")
            
            # 创建进度回调
            def progress_callback(progress: TransferProgress):
                self.task_progresses[task.task_id] = progress
                if self.progress_callback:
                    self.progress_callback(progress)
                self.progress_display.update_progress(progress)
            
            # 执行传输
            is_skipped = await self._check_and_handle_skip(task, client, progress_callback)
            success = is_skipped

            if not is_skipped:
                if task.transfer_type == TransferType.UPLOAD:
                    remote_dir = '/'.join(task.remote_path.split('/')[:-1])
                    if remote_dir and not await client.file_exists(remote_dir):
                        await client._ensure_remote_directory(remote_dir)
                    success = await client.upload_file(
                        task.local_path, task.remote_path, progress_callback
                    )
                else:  # DOWNLOAD
                    local_dir = os.path.dirname(task.local_path)
                    if local_dir:
                        self.path_handler.ensure_directory(local_dir)
                    success = await client.download_file(
                        task.remote_path, task.local_path, progress_callback
                    )
            
            if success:
                self.completed_tasks.add(task.task_id)
                # 线程安全地更新统计信息（只有实际传输的文件才计入completed_files和transferred_bytes）
                if not is_skipped:
                    with self._stats_lock:
                        self.stats['completed_files'] += 1
                        self.stats['transferred_bytes'] += task.size
                
                # 验证文件完整性（如果启用）
                if self.config.get('verify_checksum', True):
                    if task.transfer_type == TransferType.UPLOAD:
                        integrity_ok = await client.verify_file_integrity(
                            task.local_path, task.remote_path
                        )
                    else:
                        integrity_ok = await client.verify_file_integrity(
                            task.local_path, task.remote_path
                        )
                    
                    if not integrity_ok:
                        self.logger.warning(f"文件完整性验证失败: {task.local_path}")
                
                self.logger.debug(f"{worker_name} 任务完成: {task.local_path}")
                return False  # 任务成功，不需要重试
            else:
                raise Exception("传输失败")
                
        except Exception as e:
            error_msg = str(e)
            self.logger.error(f"{worker_name} 任务失败: {task.local_path} - {error_msg}")
            
            # 重试机制
            if task.retry_count < task.max_retries:
                task.retry_count += 1
                self.logger.info(f"{worker_name} 重试任务 ({task.retry_count}/{task.max_retries}): {task.local_path}")
                return True  # 需要重试
            else:
                # 超过最大重试次数，标记为失败
                self.failed_tasks[task.task_id] = error_msg
                # 线程安全地更新统计信息
                with self._stats_lock:
                    self.stats['failed_files'] += 1
                self.progress_display.show_file_status(
                    task.local_path, TransferStatus.FAILED, task.size, error_msg
                )
                return False  # 不再重试
        
        finally:
            # 清理活动任务（注意：不关闭连接，因为是持久连接）
            if task.task_id in self.active_tasks:
                del self.active_tasks[task.task_id]
    
    async def _check_and_handle_skip(
        self,
        task: TransferTask,
        client: 'ProtocolClient',
        progress_callback: Callable[[TransferProgress], None],
    ) -> bool:
        """
        检查文件是否可跳过传输（双端内容完全相同），若跳过则同步处理进度和统计。

        Returns:
            True 表示文件已跳过（调用方应视为成功），False 表示需要继续传输。
        """
        if self.config.get('skip_file_check', True):
            return False

        should_skip = await client.files_are_identical(task.local_path, task.remote_path)
        if not should_skip:
            return False

        self.progress_display.show_skip_message(task.local_path)
        skip_progress = TransferProgress(
            file_path=task.local_path,
            total_size=task.size,
            transferred_size=task.size,
            speed=0.0,
            status=TransferStatus.COMPLETED,
            start_time=time.time(),
            is_skipped=True
        )
        progress_callback(skip_progress)
        with self._stats_lock:
            self.stats['skipped_files'] += 1
        return True

    def stop_transfer(self) -> None:
        """停止传输任务"""
        self._should_stop = True
        self.logger.info("正在停止传输任务...")
    
    def get_transfer_stats(self) -> Dict[str, Any]:
        """获取传输统计信息"""
        stats = self.stats.copy()
        stats['active_tasks'] = len(self.active_tasks)
        stats['pending_tasks'] = self.pending_tasks.qsize()
        stats['failed_tasks'] = len(self.failed_tasks)
        
        if stats['start_time'] > 0:
            if stats['end_time'] > 0:
                stats['duration'] = stats['end_time'] - stats['start_time']
            else:
                stats['duration'] = time.time() - stats['start_time']
            
            if stats['duration'] > 0:
                stats['average_speed'] = stats['transferred_bytes'] / stats['duration']
        
        return stats
    
    def set_progress_callback(self, callback: Callable[[TransferProgress], None]) -> None:
        """
        设置进度回调函数
        
        Args:
            callback: 进度回调函数
        """
        self.progress_callback = callback
    
    def _cleanup_task_records(self) -> None:
        """
        清理任务记录，防止内存无限增长
        """
        # 清理完成任务记录（保留最近的记录）
        if len(self.completed_tasks) > self._max_completed_records:
            # 转换为列表，移除最旧的记录
            completed_list = list(self.completed_tasks)
            keep_count = self._max_completed_records // 2  # 保留一半
            self.completed_tasks = set(completed_list[-keep_count:])
            self.logger.debug(f"清理完成任务记录，保留 {keep_count} 条")
        
        # 清理失败任务记录
        if len(self.failed_tasks) > self._max_failed_records:
            # 转换为列表，移除最旧的记录
            failed_items = list(self.failed_tasks.items())
            keep_count = self._max_failed_records // 2
            self.failed_tasks = dict(failed_items[-keep_count:])
            self.logger.debug(f"清理失败任务记录，保留 {keep_count} 条")
    
    def cleanup_resources(self) -> None:
        """
        清理所有资源，释放内存
        """
        try:
            # 清理任务相关数据结构
            self.active_tasks.clear()
            self.completed_tasks.clear()
            self.failed_tasks.clear()
            self.task_progresses.clear()
            self._processed_paths.clear()
            
            # 清理队列（如果还有待处理任务，先处理完）
            while not self.pending_tasks.empty():
                try:
                    self.pending_tasks.get_nowait()
                    self.pending_tasks.task_done()
                except:
                    break
            
            self.logger.debug("资源清理完成")
            
        except Exception as e:
            self.logger.error(f"资源清理失败: {e}")
    
    def __del__(self):
        """析构函数，确保资源被释放"""
        try:
            self.cleanup_resources()
        except:
            pass  # 忽略析构时的异常
