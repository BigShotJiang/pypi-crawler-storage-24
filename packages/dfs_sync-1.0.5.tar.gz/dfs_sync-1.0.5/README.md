# DFS - 分布式文件同步工具

一个高性能、易使用、跨平台的并发文件传输工具，支持SFTP协议。

## 安装

### 方法一：使用pip安装（推荐）

**从PyPI安装（正式发布后）：**
```bash
pip install dfs
```

### 方法二：从源码安装

```bash
pip install -e .
```

**开发模式安装（包含开发依赖）：**
```bash
pip install -e ".[dev]"
```

### 方法三：直接运行（不安装）

```bash
python -m dfs.cli.main --help
```

### 验证安装

安装完成后，可以通过以下命令验证：

```bash
dfs --version
dfs --help
```