"""By-frame 214 L0 header keywords that are not instrument specific."""

from astropy.io import fits

from dkist_processing_common.models.fits_access import MetadataKey
from dkist_processing_common.parsers.l1_fits_access import L1FitsAccess


class AbstractProperty:
    """
    A class for defining properties expected to exist in subclasses, but that don't exist on the current class.

    Use like this

    .. code::

      class BaseClass:
        required_property = AbstractProperty()

    Then accessing `BaseClass().required_property` will result in a `NotImplementedError`.
    """

    # Inspired by https://stackoverflow.com/questions/56997102/python-notimplementederror-for-instance-attributes
    def __get__(self, *args, **kwargs):
        raise NotImplementedError(
            "This property needs to be defined manually in an instrument subclass"
        )


class L0FitsAccess(L1FitsAccess):
    """
    Class defining a fits access object for L0 input data.

    Parameters
    ----------
    hdu
        The input fits hdu
    name
        An optional name to be associated with the hdu
    auto_squeeze
        A boolean indicating whether to 'squeeze' out dimensions of size 1
    """

    modulator_state: int = AbstractProperty()

    def __init__(
        self,
        hdu: fits.ImageHDU | fits.PrimaryHDU | fits.CompImageHDU,
        name: str | None = None,
        auto_squeeze: bool = True,
    ):
        super().__init__(hdu=hdu, name=name, auto_squeeze=auto_squeeze)
        self.ip_task_type: str = self.header[MetadataKey.ip_task_type]
        self.ip_start_time: str = self.header[MetadataKey.ip_start_time]
        self.ip_end_time: str = self.header[MetadataKey.ip_end_time]
