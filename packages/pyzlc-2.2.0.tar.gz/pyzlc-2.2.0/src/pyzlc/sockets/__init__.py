"socket module initialization"
