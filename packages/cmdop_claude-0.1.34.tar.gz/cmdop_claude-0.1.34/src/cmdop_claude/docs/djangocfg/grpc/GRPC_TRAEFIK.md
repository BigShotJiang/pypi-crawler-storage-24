# gRPC Configuration with Traefik

## Overview

This document describes the critical Traefik configuration for gRPC services, particularly for bidirectional streaming (like terminal sessions).

## Quick Fix: 60-Second Disconnects ⚡

If your gRPC streams disconnect **exactly every 60 seconds**, you need to configure Traefik timeouts:

**1. Edit your `traefik.yaml` entrypoint configuration:**

```yaml
entryPoints:
  websecure:
    address: ":443"
    # ADD THIS:
    transport:
      respondingTimeouts:
        readTimeout: 0      # Unlimited (for gRPC streaming)
        writeTimeout: 0     # Unlimited (for gRPC streaming)
        idleTimeout: 90s    # 90s idle before disconnect
```

**2. Restart Traefik:**
```bash
docker restart traefik
```

**3. Verify (wait 2+ minutes):**
```bash
# Check logs - should NOT see "Stream cancelled" every 60s anymore
docker logs <grpc-container> --timestamps --since 5m | grep -E "REGISTRATION|Stream cancelled"
```

**Result:** Streams will stay connected for hours instead of disconnecting every 60 seconds.

## Key Configuration

### Required Labels

```yaml
labels:
  - "traefik.enable=true"
  - "traefik.docker.network=dokploy-network"
  - "traefik.http.routers.djangocfg-grpc.rule=Host(`grpc.djangocfg.com`)"
  - "traefik.http.routers.djangocfg-grpc.entrypoints=websecure"
  - "traefik.http.routers.djangocfg-grpc.tls=true"
  - "traefik.http.services.djangocfg-grpc.loadbalancer.server.port=50051"
  - "traefik.http.services.djangocfg-grpc.loadbalancer.server.scheme=h2c"
  # gRPC streaming - instant flush (critical for bidirectional streaming)
  - "traefik.http.services.djangocfg-grpc.loadbalancer.responseForwarding.flushInterval=1ms"
  - "traefik.http.services.djangocfg-grpc.loadbalancer.passHostHeader=true"
```

### Critical Settings Explained

#### 1. `scheme=h2c` (HTTP/2 Cleartext)
gRPC requires HTTP/2. The `h2c` scheme tells Traefik to use HTTP/2 without TLS for backend communication (TLS is terminated at Traefik).

#### 2. `flushInterval=1ms` (Most Important!)
**This is critical for bidirectional streaming.**

Without this setting, Traefik buffers responses which causes:
- Delayed terminal output
- RST_STREAM errors
- Choppy/laggy streaming experience

Setting `flushInterval=1ms` ensures responses are forwarded immediately without buffering.

#### 3. `passHostHeader=true`
Forwards the original Host header to the backend. Important for services that validate the hostname.

## Common Issues

### Issue: Internal gRPC Calls Fail in Production (TLS Required)

**Symptom:** Web terminal input doesn't work. Django logs show:
```
GRPCChannelError: Insecure gRPC connections are not allowed in production.
Set GRPC__USE_TLS=true and configure TLS certificates.
```

**Context:** Your architecture has internal Docker-to-Docker gRPC calls:
```
Browser → Centrifugo (WebSocket) → Django API → gRPC Server
                                   ↑
                            Internal call!
                     (cmdop-api → cmdop-grpc:50051)
```

**Root Cause:** Django's `get_grpc_channel()` requires TLS in production (`DEBUG=False`). But for internal Docker network communication, TLS is unnecessary overhead - traffic never leaves the Docker network.

**Solution:** Enable internal insecure connections for Docker services:

```yaml
# docker-compose.yaml
services:
  api:
    environment:
      # Internal gRPC connection (Docker service name)
      GRPC__INTERNAL_URL: "cmdop-grpc:50051"
      # Allow insecure for internal Docker network
      GRPC__ALLOW_INTERNAL_INSECURE: "true"
```

**How it works:**
- `GRPC__ALLOW_INTERNAL_INSECURE=true` allows insecure connections **only** to internal addresses
- Internal addresses are detected by: `localhost`, `127.0.0.1`, `cmdop-*` prefix, or `:50051` port
- External connections (public URLs) still require TLS

**Security Note:** This is safe because:
1. Traffic stays within Docker network (isolated)
2. External gRPC (via Traefik) uses TLS termination
3. Only internal service-to-service calls are insecure

**After fix:**
```bash
# Rebuild containers:
docker compose up -d --force-recreate api

# Test web terminal input - should work now
```

---

### Issue: gRPC 404 - Traefik Skips Unhealthy Containers (Traefik 3.x)

**Symptom:** gRPC clients receive 404 errors. Traefik access logs show:
```json
{"DownstreamStatus":404,"OriginStatus":0,"OriginDuration":0}
```
- `OriginStatus: 0` - Request NEVER reached backend
- `OriginDuration: 0` - No backend connection attempted

**Root Cause:** Traefik 3.x skips containers with unhealthy Docker health checks!

**Diagnosis:**
```bash
# Check container health status:
docker ps --filter "name=grpc" --format "table {{.Names}}\t{{.Status}}"

# If you see "unhealthy":
cmdop-grpc       Up 5 minutes (unhealthy)  ← Traefik ignores this!
stockapis-grpc   Up 2 days (healthy)       ← Traefik routes to this

# Verify router exists in Traefik:
curl -sk https://traefik.your-domain.com/api/rawdata | grep cmdop-grpc
# If missing - health check is the issue!
```

**Why it fails:** The default `grpc_health_probe` health check requires the gRPC server to implement the standard health check protocol. If your server requires authentication for ALL requests (including health checks), the probe fails.

```yaml
# This health check FAILS when server requires auth:
healthcheck:
  test: ["CMD", "grpc_health_probe", "-addr=localhost:50051"]
```

**Solution:** Use a simple TCP port check instead:

```yaml
healthcheck:
  # TCP check - doesn't require auth, just verifies port is open
  test: ["CMD-SHELL", "python -c \"import socket; s=socket.socket(); s.connect(('localhost', 50051)); s.close()\""]
  interval: 30s
  timeout: 10s
  retries: 3
  start_period: 60s
```

**After fix:**
```bash
# Recreate the container:
docker compose up -d --force-recreate grpc

# Wait for health check (60s start_period + 30s interval):
sleep 90

# Verify healthy status:
docker ps --filter "name=grpc" --format "{{.Names}}\t{{.Status}}"
# Should show: cmdop-grpc   Up 2 minutes (healthy)

# Verify Traefik router exists:
curl -sk https://traefik.your-domain.com/api/rawdata | grep cmdop-grpc
# Should show: cmdop-grpc@docker
```

**Alternative Solutions:**
1. **Implement gRPC health check without auth** - Exclude `/grpc.health.v1.Health/Check` from authentication
2. **Disable health check entirely** - Remove the `healthcheck:` section (not recommended)
3. **Use process check** - `test: ["CMD-SHELL", "pgrep -f rungrpc"]`

**Key Insight:** Traefik 3.x behavior change - it now respects Docker health status and excludes unhealthy containers from routing. This is different from Traefik 2.x which routed to all containers regardless of health.

---

### Issue: RST_STREAM / Connection Reset
**Symptom:** gRPC streams disconnect randomly, client receives RST_STREAM errors.

**Solution:** Ensure `flushInterval=1ms` is set. This prevents Traefik from buffering gRPC frames.

### Issue: Stream disconnects exactly every 60 seconds
**Symptom:**
- Terminal sessions disconnect precisely 60s after connection
- Logs show `Stream cancelled for session...` exactly 60s after registration
- Clients immediately reconnect in a loop

**Root Cause:** Traefik's **default responseHeaderTimeout is 60 seconds**!

For long-running gRPC streams, Traefik needs to wait indefinitely for responses (bidirectional streaming doesn't send headers immediately).

**Diagnosis:**
```bash
# Check timing pattern:
docker logs djangocfg-grpc --timestamps | grep -E "REGISTRATION|Stream cancelled"

# If you see exactly 60s intervals:
# 19:20:48 REGISTRATION
# 19:21:48 Stream cancelled  ← 60s later!
# → responseHeaderTimeout issue
```

**Solution:** Configure timeouts in Traefik **entrypoint** (not labels!)

Edit `/path/to/traefik.yaml`:
```yaml
entryPoints:
  websecure:
    address: ":443"
    transport:
      respondingTimeouts:
        readTimeout: 0      # Unlimited (for gRPC streaming)
        writeTimeout: 0     # Unlimited (for gRPC streaming)
        idleTimeout: 90s    # 90s idle before disconnect
```

Then restart Traefik:
```bash
docker restart <traefik-container>
```

**Why entrypoint, not service labels?**
- Timeout configuration must be at entrypoint level for all routers
- Service labels don't support `responseHeaderTimeout` field
- This is documented in [Traefik issue #10652](https://github.com/traefik/traefik/issues/10652)

**Explanation:**
- `readTimeout: 0` → Unlimited wait for reading response (required for streaming)
- `writeTimeout: 0` → Unlimited wait for writing request
- `idleTimeout: 90s` → Keep connection alive 90s without data (heartbeat interval is 30s)

**After fix:**
```bash
# Terminal sessions stay connected for hours
docker logs djangocfg-grpc --timestamps | grep "Stream cancelled"
# Should be empty or only on manual disconnect
```

### Issue: HTTP 404 from gRPC endpoint
**Symptom:** Browser or client receives 404 when connecting to gRPC.

**Possible causes:**
1. **Compress middleware** - Do NOT use compress middleware with gRPC. It breaks the protocol.
2. **Missing h2c scheme** - gRPC requires HTTP/2, ensure `scheme=h2c` is set.
3. **Wrong port** - Verify the backend port matches the gRPC server port.

### Issue: Browser shows 404 at grpc.djangocfg.com
**This is normal!** gRPC is not HTTP/1.1 compatible. Browsers cannot directly access gRPC endpoints. The 404 is expected when accessing via browser.

To test gRPC, use:
```bash
# Health check
grpc_health_probe -addr=localhost:50051

# Or via Docker
docker exec djangocfg-grpc grpc_health_probe -addr=localhost:50051
```

### Issue: Random RST_STREAM with "Stream cancelled for session..."
**Symptom:** Clients receive `RST_STREAM with code 2 (Internal server error)` and constantly reconnect. Django logs show `Stream cancelled for session...` with no ERROR logs.

**Root Cause:** gRPC server running with **auto-reload enabled** in production!

When Django's auto-reload detects file changes:
1. Server initiates graceful shutdown
2. All active gRPC streams are cancelled
3. Clients receive RST_STREAM error
4. Server restarts, clients reconnect
5. Cycle repeats on every file change

**Diagnosis:**
```bash
docker logs djangocfg-grpc --tail 50 | grep -E "changed, reloading|Hotreload active"

# If you see:
# "/app/apps/terminal/grpc/services/handlers/output.py changed, reloading."
# "⚠️ Hotreload active - connections may be dropped on code changes"
# → Auto-reload is ENABLED
```

**Solution:**
```yaml
# docker-compose.yaml
services:
  grpc:
    command: poetry run python manage.py rungrpc --noreload  # ← Add this flag!
```

**Why this matters:**
- **Development:** Hot-reload is convenient for rapid iteration
- **Production:** Hot-reload causes service interruptions for ALL connected clients
- **Impact:** Every file change (even from IDE auto-save, git operations, or log rotations) triggers restart

**After fix:**
```bash
# Redeploy:
docker compose up -d grpc

# Verify no more reloads:
docker logs djangocfg-grpc --tail 20 | grep -E "reload|changed"
# Should be empty or show: "Auto-reloader disabled"
```

**Result:**
- ✅ Stable streaming connections
- ✅ No more random disconnects
- ✅ Clients stay connected for hours/days

## What NOT to Do

### Do NOT add compress middleware
```yaml
# WRONG - This breaks gRPC!
- "traefik.http.middlewares.grpc-compress.compress=false"
- "traefik.http.routers.djangocfg-grpc.middlewares=grpc-compress"
```

The compress middleware (even when disabled) interferes with gRPC routing and causes 404 errors.

### Do NOT use HTTP/1.1
```yaml
# WRONG - gRPC requires HTTP/2
- "traefik.http.services.djangocfg-grpc.loadbalancer.server.scheme=http"
```

Always use `h2c` for gRPC backends.

### Do NOT enable auto-reload in production
```yaml
# WRONG - Causes RST_STREAM on every file change!
command: poetry run python manage.py rungrpc

# CORRECT - Stable production server
command: poetry run python manage.py rungrpc --noreload
```

Auto-reload is great for development but **catastrophic** in production:
- Every file change kills all active streams
- Clients get RST_STREAM and must reconnect
- IDE auto-save, git pulls, log rotations all trigger restarts
- Terminal sessions interrupted mid-command

## Testing

### 1. Container Health
```bash
docker compose ps grpc
# Should show: Up (healthy)
```

### 2. gRPC Health Probe
```bash
docker exec djangocfg-grpc grpc_health_probe -addr=localhost:50051
# Should show: status: SERVING
```

### 3. Check Traefik Labels
```bash
docker inspect djangocfg-grpc --format '{{json .Config.Labels}}' | grep traefik
```

### 4. Logs
```bash
docker logs djangocfg-grpc --tail 50
# Should show HTTP 200 responses to Centrifugo
```

## Architecture

### External gRPC (Electron → Server)
```
Electron/Go Client
      │
      ▼ (HTTPS/gRPC over TLS)
   Traefik (TLS termination)
      │
      ▼ (H2C - HTTP/2 cleartext)
  cmdop-grpc:50051
```

### Web Terminal Flow (Browser ↔ Terminal)
```
┌─────────────────────────────────────────────────────────────────┐
│                        Docker Network                            │
│                                                                  │
│  ┌──────────┐    Internal gRPC     ┌──────────────┐             │
│  │ cmdop-api│◄───────────────────►│ cmdop-grpc   │             │
│  │ (Django) │    (insecure OK)     │ (gRPC Server)│             │
│  └────┬─────┘                      └──────┬───────┘             │
│       │                                   │                      │
│       │ Centrifugo RPC                    │ Bidirectional Stream │
│       ▼                                   │                      │
│  ┌──────────────┐                         │                      │
│  │  Centrifugo  │                         │                      │
│  │  (WebSocket) │                         ▼                      │
│  └──────┬───────┘                   ┌──────────┐                │
│         │                           │ Electron │                │
└─────────┼───────────────────────────┴──────────┴────────────────┘
          │
          ▼ (WSS via Traefik)
      Browser
```

### The terminal data flow:
1. **Output (Terminal → Browser):**
   - Electron sends output to gRPC server
   - gRPC server publishes to Centrifugo
   - Browser receives via WebSocket

2. **Input (Browser → Terminal):**
   - Browser sends input via Centrifugo RPC
   - **Django API receives RPC, calls gRPC server internally** ← Requires `GRPC__ALLOW_INTERNAL_INSECURE=true`
   - gRPC server forwards to Electron via bidirectional stream

### Key Environment Variables
```yaml
# For external gRPC (Electron clients)
GRPC__USE_TLS: "false"           # TLS handled by Traefik

# For internal gRPC (Django API → gRPC Server)
GRPC__INTERNAL_URL: "cmdop-grpc:50051"
GRPC__ALLOW_INTERNAL_INSECURE: "true"
```

## Real-World Troubleshooting Example

### Problem: RST_STREAM every 60 seconds on cmdop-grpc

**Symptoms observed:**
```bash
# Go client logs showing constant reconnects:
15:55:34 WRN Connection lost error="gRPC error: rpc error: code = Internal desc = stream terminated by RST_STREAM with error code: INTERNAL_ERROR" reconnect_count=0
⚠️  Connection lost: gRPC error: receive error: rpc error: code = Internal desc = stream terminated by RST_STREAM with error code: INTERNAL_ERROR
🔄 Reconnecting in 982.848755ms... (attempt 1)
```

**Step 1: Check timing pattern**
```bash
ssh administrator@server "docker logs cmdop-grpc --timestamps | grep -E 'REGISTRATION|Stream cancelled' | tail -20"

# Output showed exact 60-second pattern:
2025-12-13T07:56:37 📝 TERMINAL REGISTRATION
2025-12-13T07:57:37 Stream cancelled for session f73b5dcd...  ← 60s later!
2025-12-13T07:57:39 📝 TERMINAL REGISTRATION
2025-12-13T07:58:39 Stream cancelled for session f73b5dcd...  ← 60s later!
2025-12-13T07:58:41 📝 TERMINAL REGISTRATION
```

**Step 2: Verify Traefik labels are correct**
```bash
docker inspect cmdop-grpc --format '{{json .Config.Labels}}' | python3 -m json.tool | grep -E 'flush|scheme'

# Output:
"traefik.http.services.cmdop-grpc.loadbalancer.responseForwarding.flushInterval": "1ms" ✅
"traefik.http.services.cmdop-grpc.loadbalancer.server.scheme": "h2c" ✅
```

**Step 3: Check Traefik config for timeouts**
```bash
docker inspect traefik --format '{{json .Mounts}}' | python3 -m json.tool | grep traefik.yaml
# Found: /home/administrator/root/deployment/services/traefik/traefik.yaml

cat /home/administrator/root/deployment/services/traefik/traefik.yaml | grep -A 5 websecure

# Output showed NO timeout configuration:
websecure:
  address: ":443"
# ❌ Missing transport.respondingTimeouts!
```

**Step 4: Apply the fix**
```bash
# Edit traefik.yaml to add timeout config:
cat > /tmp/traefik_patch.yaml << 'EOF'
entryPoints:
  websecure:
    address: ":443"
    transport:
      respondingTimeouts:
        readTimeout: 0
        writeTimeout: 0
        idleTimeout: 90s
# ... rest of config
EOF

# Copy and restart:
cp /tmp/traefik_patch.yaml /home/administrator/root/deployment/services/traefik/traefik.yaml
docker restart traefik
```

**Step 5: Verify the fix**
```bash
# Wait 2+ minutes, then check logs:
docker logs cmdop-grpc --since 5m --timestamps | grep -E "REGISTRATION|Stream cancelled"

# Before fix: Disconnects every 60s
# After fix: No disconnects! ✅

# The connection at 08:01:52 survived past 08:03:30 (98+ seconds)
# No "Stream cancelled" messages after Traefik restart
```

**Root Cause:** Traefik's default `readTimeout` is 60 seconds. Without explicit configuration, all HTTP/2 streams (including gRPC) are terminated after 60 seconds of waiting for response headers.

**Solution:** Setting `readTimeout: 0` (unlimited) in the `websecure` entrypoint allows gRPC streams to run indefinitely, as required for bidirectional streaming.

**Key Learning:** Service-level labels (`traefik.http.services.*`) cannot override entrypoint-level timeouts. The timeout configuration **must** be in `traefik.yaml` at the entrypoint level.
