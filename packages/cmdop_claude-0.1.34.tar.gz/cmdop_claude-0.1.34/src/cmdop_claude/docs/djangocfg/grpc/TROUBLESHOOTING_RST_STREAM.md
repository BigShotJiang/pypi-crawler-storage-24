# Troubleshooting: RST_STREAM with code 2 (Internal server error)

## 🔍 Что это значит?

`RST_STREAM with code 2` - gRPC сервер прервал stream из-за **внутренней ошибки**.

HTTP/2 коды:
- `0` = NO_ERROR
- `1` = PROTOCOL_ERROR
- `2` = **INTERNAL_ERROR** ← ваш случай
- `3` = FLOW_CONTROL_ERROR
- etc.

---

## 📊 Диагностика

### 1. Проверь логи Django gRPC сервера:

```bash
# Production (Docker):
docker logs -f djangocfg-grpc --tail 200 | grep -E "Stream error|Error processing|Failed to handle"

# Local:
tail -f logs/grpc.log | grep -E "ERROR|Exception"
```

**Ищи паттерны:**

#### А) Stream error (main loop):
```
ERROR: Stream error for session abc123: DatabaseError: connection lost
```
**Причина:** Основной yield loop упал (server.py:162-171)

#### Б) Error processing messages:
```
ERROR: Error processing messages for session abc123: ValueError: invalid session
```
**Причина:** Exception в обработке входящих сообщений (server.py:138-148)

#### В) Failed to handle terminal output:
```
ERROR: Failed to handle terminal output for session abc123: ConnectionError: Centrifugo unavailable
```
**Причина:** Не удалось отправить output в browser через Centrifugo (output.py:55-65)

---

### 2. Типичные причины:

#### 🔴 **A. Database Connection Timeout**
**Симптомы:**
- Ошибка после ~30-60 секунд неактивности
- В логах: `DatabaseError`, `connection already closed`, `FATAL: terminating connection`

**Решение:**
```python
# settings.py
DATABASES = {
    'default': {
        'CONN_MAX_AGE': 300,  # Keep connection 5 min
        'CONN_HEALTH_CHECKS': True,  # Check before using
        'OPTIONS': {
            'connect_timeout': 10,
            'keepalives': 1,
            'keepalives_idle': 30,
            'keepalives_interval': 10,
            'keepalives_count': 5,
        }
    }
}
```

#### 🔴 **B. Centrifugo Publisher Failed**
**Симптомы:**
- В логах: `Failed to handle terminal output`, `ConnectionRefusedError`, `HTTPError 503`
- Terminal работает но браузер не получает output

**Проверка:**
```bash
# Проверь что Centrifugo работает:
curl http://localhost:8000/connection/websocket
# Должен ответить: 405 Method Not Allowed (это ОК, WebSocket нужен)

# Проверь внутренний API:
curl -X POST http://localhost:8001/api/publish \
  -H "Authorization: apikey YOUR_API_KEY" \
  -d '{"channel":"test","data":{}}'
```

**Решение:**
- Перезапусти Centrifugo: `docker restart centrifugo`
- Проверь API key в настройках Django

#### 🔴 **C. PTY Process Crash**
**Симптомы:**
- Terminal внезапно обрывается во время работы
- Ошибка не в Django, а на Electron стороне

**Проверка (Electron):**
```typescript
// В grpc-terminal ловим PTY exit:
pty.onExit(({ exitCode, signal }) => {
  console.error(`PTY died: exitCode=${exitCode} signal=${signal}`);
});
```

**Возможные причины:**
- Out of Memory (OOM killed)
- Segmentation fault в node-pty
- macOS sandbox restrictions

#### 🔴 **D. gRPC Keepalive Timeout**
**Симптомы:**
- Обрыв после длительного простоя (>2 минуты молчания)
- Нет ошибок в Django логах

**Текущие настройки:**
- Django ping: каждые 60 секунд (server.py:150)
- Electron heartbeat: каждые 30 секунд (client.ts)

**Улучшение:**
```python
# При создании gRPC server добавь опции:
server = grpc.aio.server(
    options=[
        ('grpc.keepalive_time_ms', 30000),  # Ping every 30s
        ('grpc.keepalive_timeout_ms', 10000),  # Wait 10s for pong
        ('grpc.keepalive_permit_without_calls', 1),  # Allow pings on idle
        ('grpc.http2.max_pings_without_data', 0),  # Unlimited
        ('grpc.http2.min_time_between_pings_ms', 10000),
        ('grpc.http2.min_ping_interval_without_data_ms', 30000),
    ]
)
```

#### 🔴 **E. Memory Leak / High Load**
**Симптомы:**
- Случайные обрывы под нагрузкой
- `docker stats` показывает высокий memory usage

**Проверка:**
```bash
# Мониторинг памяти:
docker stats djangocfg-grpc --no-stream

# Проверь количество активных сессий:
docker exec djangocfg-grpc python manage.py shell -c "
from apps.terminal.models import TerminalSession
print(TerminalSession.objects.filter(status='connected').count())
"
```

**Решение:**
- Добавь `MAX_SESSIONS_PER_ELECTRON` limit
- Cleanup старых disconnected sessions

---

## 🛠️ Улучшения (уже применены):

### ✅ 1. Улучшенное логирование
Теперь все ошибки включают:
- `error_type` (имя класса исключения)
- `session_id` (для трассировки)
- `error_message` (детали)

**Пример нового лога:**
```
ERROR: Stream error for session abc12345: DatabaseError: FATAL: terminating connection due to administrator command
  session_id: abc12345-6789-...
  error_type: DatabaseError
  error_message: FATAL: terminating connection...
```

### ✅ 2. Reconnect logic в Electron
Клиент уже имеет:
- Автоматический retry с exponential backoff
- Max retries configurable (default: unlimited)
- Connection state tracking: `disconnected | connecting | connected | reconnecting`

**Настройки (config.ts):**
```typescript
reconnectInterval: 5,  // Retry every 5 seconds
```

---

## 🔬 Добавь мониторинг:

### 1. Prometheus metrics (рекомендуется):
```python
# apps/terminal/metrics.py
from prometheus_client import Counter, Histogram

grpc_stream_errors = Counter(
    'grpc_stream_errors_total',
    'Total gRPC stream errors',
    ['error_type', 'session_id']
)

grpc_stream_duration = Histogram(
    'grpc_stream_duration_seconds',
    'gRPC stream lifetime'
)
```

### 2. Sentry error tracking:
```python
# settings.py
import sentry_sdk
from sentry_sdk.integrations.django import DjangoIntegration

sentry_sdk.init(
    dsn="YOUR_DSN",
    integrations=[DjangoIntegration()],
    traces_sample_rate=0.1,
)
```

Тогда все `logger.error(..., exc_info=True)` автоматически попадут в Sentry с полным stack trace.

---

## 📈 Следующие шаги:

1. **Мониторь логи** после деплоя улучшений
2. **Собери паттерн** - ошибки случайные или в определенные моменты?
3. **Добавь метрики** - сколько reconnect'ов в час?
4. **Протестируй нагрузку** - `ab -n 1000 -c 50` на Django API

---

## 🚨 Экстренная диагностика:

```bash
# 1. Проверь что gRPC server вообще работает:
grpcurl -plaintext localhost:50051 list

# 2. Проверь активные соединения:
docker exec djangocfg-grpc netstat -an | grep 50051

# 3. Проверь DB connections:
docker exec djangocfg-db psql -U postgres -c "SELECT count(*) FROM pg_stat_activity WHERE datname='djangocfg';"

# 4. Проверь Centrifugo health:
curl http://localhost:8001/health
```

---

**Лучший способ найти причину:**
1. Включи DEBUG logging для gRPC
2. Воспроизведи ошибку
3. Найди точное время обрыва в логах
4. Ищи ERROR за 1-2 секунды до обрыва

Удачи! 🚀
