# gRPC Internal URL Fix - Diagnostic Report

**Дата:** 2025-12-11
**Коммит:** 75505d992

---

## ✅ Что было исправлено

### Проблема
Terminal input от браузера не работал в продакшене из-за hardcoded `localhost:50051` в `centrifugo_handlers.py`.

### Решение
Заменили hardcoded URL на конфигурируемый `env.grpc_internal_url`:

```python
# До (НЕ работало в Docker)
async with grpc.aio.insecure_channel("localhost:50051") as channel:

# После (работает и локально и в Docker)
async with grpc.aio.insecure_channel(GRPC_INTERNAL_ADDRESS) as channel:
```

---

## 🔍 Диагностика: Почему все еще не работает

### Проверка 1: Установлена ли переменная окружения?

**На сервере проверить:**

```bash
# 1. Проверить что переменная есть в .env
cd /path/to/django
grep GRPC_INTERNAL_URL api/environment/.env*

# Ожидаемое:
# .env.prod: GRPC_INTERNAL_URL=djangocfg-grpc:50051
# или
# .env: GRPC_INTERNAL_URL=localhost:50051 (для локалки)
```

**Если переменная НЕ установлена:**

```bash
# Добавить в .env.prod
echo "GRPC_INTERNAL_URL=djangocfg-grpc:50051" >> api/environment/.env.prod

# ИЛИ добавить в docker-compose.yaml
# services:
#   djangocfg-api:
#     environment:
#       - GRPC_INTERNAL_URL=djangocfg-grpc:50051
```

### Проверка 2: Перезапущен ли Django API контейнер?

```bash
# Код изменился - ОБЯЗАТЕЛЬНО перезапустить контейнер
docker-compose restart djangocfg-api

# ИЛИ пересобрать если изменился requirements
docker-compose up -d --build djangocfg-api
```

### Проверка 3: Доступен ли gRPC сервер из Django API контейнера?

```bash
# Войти в Django API контейнер
docker exec -it djangocfg-api bash

# Проверить DNS резолвится ли имя сервиса
ping djangocfg-grpc
# Ожидаемое: PING djangocfg-grpc (172.x.x.x)

# Проверить порт 50051 открыт
nc -zv djangocfg-grpc 50051
# Ожидаемое: Connection to djangocfg-grpc 50051 port [tcp/*] succeeded!

# Проверить gRPC health check
grpcurl -plaintext djangocfg-grpc:50051 list
# Ожидаемое: список сервисов включая terminal.TerminalStreamingService
```

### Проверка 4: Логи Django API

```bash
# Проверить что Django загружает правильную переменную
docker logs djangocfg-api 2>&1 | grep -i grpc_internal

# Проверить ошибки при terminal.input RPC
docker logs djangocfg-api 2>&1 | grep -i "terminal.input"

# Проверить gRPC ошибки
docker logs djangocfg-api 2>&1 | grep -i "grpc error"
```

### Проверка 5: Centrifugo RPC доступен?

```bash
# Логи Centrifugo
docker logs djangocfg-centrifugo 2>&1 | grep -i rpc

# Проверить что RPC методы зарегистрированы
docker logs djangocfg-api 2>&1 | grep "websocket_rpc"
# Ожидаемое:
# Registered RPC: terminal.input
# Registered RPC: terminal.resize
# Registered RPC: terminal.signal
# Registered RPC: terminal.close
```

---

## 🎯 Две возможные проблемы

### Проблема A: gRPC internal connectivity (Backend)

**Симптомы:**
- В браузере DevTools → Console: "RPC error: UNAVAILABLE" или "connection refused"
- Django логи: `terminal.input gRPC error: UNAVAILABLE: failed to connect`

**Причина:** Django API не может подключиться к gRPC серверу

**Решение:**

1. **Проверить что контейнеры в одной сети:**
   ```bash
   docker network inspect djangocfg-network
   # Должны быть оба: djangocfg-api и djangocfg-grpc
   ```

2. **Проверить переменную окружения:**
   ```bash
   docker exec djangocfg-api env | grep GRPC_INTERNAL_URL
   # Ожидаемое: GRPC_INTERNAL_URL=djangocfg-grpc:50051
   ```

3. **Проверить что gRPC сервер запущен:**
   ```bash
   docker ps | grep grpc
   # Ожидаемое: djangocfg-grpc   Up

   docker logs djangocfg-grpc | tail -20
   # Ожидаемое: "gRPC server listening on 0.0.0.0:50051"
   ```

### Проблема B: Centrifugo WebSocket (Frontend)

**Симптомы:**
- В браузере DevTools → Network → WS: connection failed или 404
- Terminal output не появляется в браузере
- Но Electron терминал работает

**Причина:** Браузер не может подключиться к Centrifugo WebSocket

**Решение:** См. `CENTRIFUGO_PRODUCTION_ISSUE.md`

---

## 📋 Полный Checklist

### Backend (gRPC internal)

- [ ] Переменная `GRPC_INTERNAL_URL=djangocfg-grpc:50051` в `.env.prod`
- [ ] Django API контейнер перезапущен после изменений
- [ ] Контейнеры `djangocfg-api` и `djangocfg-grpc` в одной сети
- [ ] DNS `djangocfg-grpc` резолвится из `djangocfg-api`
- [ ] Порт `50051` доступен из `djangocfg-api`
- [ ] gRPC сервер запущен и слушает `0.0.0.0:50051`
- [ ] Нет ошибок "UNAVAILABLE" в Django логах

### Frontend (Centrifugo WebSocket)

- [ ] Centrifugo запущен
- [ ] Traefik маршрутизация настроена для `ws.djangocfg.com`
- [ ] SSL сертификат для `ws.djangocfg.com` валиден
- [ ] DNS `ws.djangocfg.com` резолвится
- [ ] Browser WebSocket подключается (101 Switching Protocols)
- [ ] Terminal output появляется в браузере

---

## 🚀 Быстрый тест

### 1. Проверить что изменения применены

```bash
# На сервере
cd /path/to/django

# Проверить что код обновлен
git log -1 --oneline
# Ожидаемое: 75505d992 fix(terminal): use configurable gRPC internal URL

# Проверить содержимое файла
grep "GRPC_INTERNAL_ADDRESS" apps/terminal/centrifugo_handlers.py
# Ожидаемое: GRPC_INTERNAL_ADDRESS = env.grpc_internal_url
```

### 2. Добавить переменную и перезапустить

```bash
# Добавить в .env.prod (если еще нет)
echo "GRPC_INTERNAL_URL=djangocfg-grpc:50051" >> api/environment/.env.prod

# Перезапустить API
docker-compose restart djangocfg-api

# Проверить что переменная загружена
docker exec djangocfg-api env | grep GRPC_INTERNAL_URL
```

### 3. Проверить connectivity из Django

```bash
# Войти в контейнер
docker exec -it djangocfg-api bash

# Установить grpcurl (если еще нет)
wget https://github.com/fullstorydev/grpcurl/releases/download/v1.8.9/grpcurl_1.8.9_linux_x86_64.tar.gz
tar -xvf grpcurl_1.8.9_linux_x86_64.tar.gz
mv grpcurl /usr/local/bin/

# Проверить gRPC сервер
grpcurl -plaintext djangocfg-grpc:50051 list

# Ожидаемое:
# grpc.health.v1.Health
# grpc.reflection.v1alpha.ServerReflection
# terminal.TerminalStreamingService
```

### 4. Тест через браузер

```javascript
// В браузере DevTools → Console
const centrifuge = new Centrifuge('wss://ws.djangocfg.com/connection/websocket', {
  token: 'YOUR_TOKEN_HERE'
});

centrifuge.on('connect', () => console.log('✅ Connected'));
centrifuge.on('error', (err) => console.error('❌ Error:', err));

centrifuge.connect();

// Затем вызвать RPC
centrifuge.rpc('terminal.input', {
  session_id: 'YOUR_SESSION_ID',
  data: btoa('ls\n')  // base64 encode "ls\n"
}).then(
  (result) => console.log('✅ RPC success:', result),
  (error) => console.error('❌ RPC error:', error)
);
```

---

## 📊 Архитектура (обновленная)

```
BROWSER (https://terminal.djangocfg.com)
    │
    │ WebSocket: wss://ws.djangocfg.com/connection/websocket
    ▼
CENTRIFUGO (djangocfg-centrifugo:8000)
    │
    │ RPC: terminal.input, terminal.resize, etc.
    ▼
DJANGO API (djangocfg-api)
    │ centrifugo_handlers.py
    │
    │ gRPC Client: env.grpc_internal_url
    │              ↓
    │              GRPC_INTERNAL_URL=djangocfg-grpc:50051  ✅ НОВОЕ
    ▼
DJANGO gRPC SERVER (djangocfg-grpc:50051)
    │ TerminalStreamingService
    │
    │ gRPC bidirectional stream
    ▼
ELECTRON (на машине пользователя)
    │ TerminalClient → grpc.djangocfg.com:443
    │
    └─ PTY Manager (node-pty)
       └─ /bin/zsh процесс
```

---

## 🔄 Flow: Browser Input → Electron

```
1. Браузер: нажатие клавиши 'a'
   └─ centrifuge.rpc('terminal.input', {data: btoa('a')})

2. Centrifugo: forwards RPC to Django API
   └─ POST /cfg/centrifugo/rpc

3. Django API: centrifugo_handlers.py → terminal_input()
   └─ grpc.aio.insecure_channel(GRPC_INTERNAL_ADDRESS)  ✅ djangocfg-grpc:50051
      └─ stub.SendInput(session_id, data)

4. Django gRPC Server: receives SendInput
   └─ Finds active Electron connection by session_id
      └─ Sends TerminalInput message via bidirectional stream

5. Electron: receives TerminalInput
   └─ pty.write('a')

6. PTY: writes to shell stdin
   └─ Shell echoes 'a' to stdout
      └─ PTY captures output
         └─ Electron sends TerminalOutput back to Django
            └─ Django publishes to Centrifugo
               └─ Browser receives output via WebSocket
                  └─ xterm.js displays 'a'
```

---

## 🎓 Lessons Learned

### Почему не работало раньше?

**Локально (работало):**
- Django API: `localhost:50051` → попадал на локальный gRPC сервер ✅
- В Docker Compose локально: `localhost` резолвится в host machine

**В продакшене (НЕ работало):**
- Django API контейнер: `localhost:50051` → искал gRPC сервер ВНУТРИ своего контейнера ❌
- gRPC сервер находится в **другом контейнере**: `djangocfg-grpc`
- Нужно использовать **Docker service name**: `djangocfg-grpc:50051`

### Docker Networking

```yaml
# docker-compose.yaml
services:
  djangocfg-api:
    networks:
      - djangocfg-network
    environment:
      - GRPC_INTERNAL_URL=djangocfg-grpc:50051  # Service name!

  djangocfg-grpc:
    networks:
      - djangocfg-network
    # Docker DNS автоматически резолвит service name в IP контейнера
```

**Важно:**
- ✅ `djangocfg-grpc:50051` - правильно (service name)
- ❌ `localhost:50051` - неправильно (смотрит внутрь своего контейнера)
- ❌ `127.0.0.1:50051` - неправильно (то же самое)
- ✅ `djangocfg-grpc.djangocfg-network:50051` - тоже правильно (FQDN)

---

## ✅ Когда проблема решена

**Признаки успеха:**

1. ✅ В браузере ввод текста появляется в терминале
2. ✅ Django логи: нет ошибок "UNAVAILABLE"
3. ✅ gRPC логи: `SendInput` запросы обрабатываются
4. ✅ Electron логи: получает TerminalInput сообщения
5. ✅ PTY output возвращается в браузер через Centrifugo

**Тест:**
```bash
# 1. Открыть терминал в Electron
# 2. Открыть тот же session в браузере
# 3. Ввести 'echo hello' в браузере
# 4. Проверить что вывод "hello" появился в ОБОИХ местах
```

---

**Автор отчета:** Claude (Terminal gRPC Fix Analysis)
**Коммит:** 75505d992
**Дата:** 2025-12-11
