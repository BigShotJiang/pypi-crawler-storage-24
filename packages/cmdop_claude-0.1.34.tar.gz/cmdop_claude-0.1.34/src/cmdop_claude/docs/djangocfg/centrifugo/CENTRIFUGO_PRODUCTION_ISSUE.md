# Centrifugo Production Issue Report

**Дата:** 2025-12-11
**Проблема:** Electron terminal подключается к Centrifugo в локалке, но не в проде

---

## 🔴 Диагноз проблемы

### Ключевое различие: Доступ к Centrifugo

| Среда | Доступ | URL | Работает? |
|-------|--------|-----|-----------|
| **Локальная** | Прямой (порт 8120 открыт) | `ws://localhost:8120` | ✅ ДА |
| **Продакшен** | Только через Traefik | `wss://ws.djangocfg.com` | ❌ НЕТ |

---

## 📊 Архитектура потока данных

```
ELECTRON (Local Machine)
    │
    │ gRPC bidirectional stream
    ▼
DJANGO (Docker: djangocfg-django)
    │
    │ HTTP API: http://centrifugo:8000/api  ✅ РАБОТАЕТ
    ▼
CENTRIFUGO (Docker: djangocfg-centrifugo)
    │
    │ WebSocket для браузера
    ▼
BROWSER (https://terminal.djangocfg.com)
    │
    │ wss://ws.djangocfg.com/connection/websocket  ❌ НЕ РАБОТАЕТ В ПРОДЕ
    └─────────────────────────────────────────────────────────────
```

---

## 🔍 Что работает

### ✅ Django → Centrifugo (внутри Docker)

**Конфигурация:**
```bash
# .env.prod
CENTRIFUGO__CENTRIFUGO_API_URL=http://centrifugo:8000/api
```

**Результат:** Django успешно публикует события в Centrifugo через HTTP API

### ✅ Electron → Django → Terminal Session

**Результат:**
- Terminal session создается: `831b2b87-2b87-4ea3-8fa9-c0b3032e3dea`
- Electron получает output через gRPC
- Терминал работает в Electron приложении

---

## 🔴 Что НЕ работает

### ❌ Browser → Centrifugo WebSocket (в проде)

**Конфигурация:**
```bash
# .env.production (frontend)
NEXT_PUBLIC_CENTRIFUGO_URL=wss://ws.djangocfg.com/connection/websocket
```

**Проблема:** Браузер не получает WebSocket события от Centrifugo

---

## 🏗️ Docker Compose конфигурации

### Локальная (работает)

```yaml
# docker-compose-local.yaml
centrifugo:
  image: centrifugo/centrifugo:v6
  container_name: djangocfg_centrifugo
  ports:
    - "8120:8000"  # ✅ Порт открыт наружу!
  networks:
    - djangocfg-network
  labels:
    - "traefik.http.routers.djangocfg-centrifugo.rule=Host(`ws.localhost`)"
```

**Почему работает:**
- Порт `8120` открыт напрямую
- Electron/Browser подключается к `localhost:8120`
- Не требуется SSL

### Продакшен (НЕ работает)

```yaml
# docker-compose.yaml
centrifugo:
  image: centrifugo/centrifugo:v6
  container_name: djangocfg-centrifugo
  # ❌ НЕТ прямых портов!
  networks:
    - dokploy-network
  labels:
    - "traefik.http.routers.djangocfg-ws.rule=Host(`ws.djangocfg.com`)"
    - "traefik.http.routers.djangocfg-ws.entrypoints=websecure"
    - "traefik.http.routers.djangocfg-ws.tls=true"
    - "traefik.http.services.djangocfg-ws.loadbalancer.server.port=8000"
```

**Потенциальные проблемы:**
1. SSL сертификат для `ws.djangocfg.com` не настроен
2. Traefik неправильно маршрутизирует WebSocket
3. DNS не резолвит `ws.djangocfg.com`
4. Firewall блокирует WebSocket соединения

---

## 🔧 Решения

### Решение 1: Проверить SSL сертификат

```bash
# На сервере
curl -I https://ws.djangocfg.com/health

# Проверить сертификат
openssl s_client -connect ws.djangocfg.com:443 -servername ws.djangocfg.com
```

**Ожидаемое:** Валидный SSL сертификат для `ws.djangocfg.com`

### Решение 2: Проверить Traefik конфигурацию

```bash
# Логи Traefik
docker logs djangocfg-traefik | grep -i centrifugo

# Проверить маршруты
docker exec djangocfg-traefik traefik version
```

**Проверить:**
- Есть ли роутер `djangocfg-ws` в Traefik
- Активен ли роутер
- Правильно ли настроен entrypoint `websecure`

### Решение 3: Проверить DNS

```bash
# На локальной машине
nslookup ws.djangocfg.com
dig ws.djangocfg.com

# На сервере
curl -I https://ws.djangocfg.com
```

**Ожидаемое:** DNS резолвится в IP сервера

### Решение 4: Проверить Centrifugo health

```bash
# На сервере (внутри Docker network)
docker exec djangocfg-django curl http://centrifugo:8000/health

# Логи Centrifugo
docker logs djangocfg-centrifugo
```

**Ожидаемое:** Centrifugo запущен и отвечает

### Решение 5: Временно открыть порт для диагностики

**Добавить в docker-compose.yaml:**
```yaml
centrifugo:
  ports:
    - "8120:8000"  # Временно для диагностики
```

**Затем:**
```bash
docker-compose up -d centrifugo
```

**Проверить прямое подключение:**
```bash
# С локальной машины
wscat -c ws://SERVER_IP:8120/connection/websocket
```

---

## 📋 Чек-лист диагностики

### Проверки на сервере

- [ ] Centrifugo запущен: `docker ps | grep centrifugo`
- [ ] Centrifugo логи: `docker logs djangocfg-centrifugo`
- [ ] Traefik видит сервис: `docker logs djangocfg-traefik | grep ws.djangocfg.com`
- [ ] DNS резолвится: `nslookup ws.djangocfg.com`
- [ ] SSL сертификат: `curl -I https://ws.djangocfg.com`
- [ ] Django подключается: `docker logs djangocfg-django | grep -i centrifugo`

### Проверки с клиента

- [ ] WebSocket подключение: DevTools → Network → WS
- [ ] Ошибки в консоли браузера
- [ ] Centrifugo URL правильный в настройках
- [ ] CORS настройки

---

## 🎯 Наиболее вероятная причина

### SSL сертификат для ws.djangocfg.com не настроен

**Симптомы:**
- `ERR_CERT_COMMON_NAME_INVALID` в браузере
- WebSocket connection failed
- SSL handshake error в Traefik логах

**Решение:**

1. **Cloudflare:** Добавить DNS запись для `ws.djangocfg.com`
   ```
   Type: A
   Name: ws
   Content: SERVER_IP
   Proxy: Yes (Orange cloud)
   ```

2. **Let's Encrypt:** Traefik автоматически получит сертификат
   ```yaml
   labels:
     - "traefik.http.routers.djangocfg-ws.tls.certresolver=letsencrypt"
   ```

3. **Проверить:** `https://ws.djangocfg.com/health`

---

## 📁 Ключевые файлы конфигурации

### Docker
- `/projects/docker/docker-compose.yaml` - Продакшен
- `/projects/docker/docker-compose-local.yaml` - Локальная
- `/projects/docker/.env.prod` - Env vars продакшен
- `/projects/docker/.env.local` - Env vars локальная

### Frontend
- `/projects/solution/frontend/apps/terminal/.env.production` - Electron prod
- `/projects/solution/frontend/apps/terminal/.env.development` - Electron dev

### Django
- `/projects/solution/django/api/environment/.env.prod` - Django prod
- `/projects/solution/django/api/config.py` - Django config

### Centrifugo
- `/projects/docker/services/centrifugo/config.json` - Centrifugo config

---

## 🔄 Terminal Events Flow

### 1. Electron → Django (через gRPC)

```
Electron PTY Manager
    │ TerminalOutput proto
    ▼
Django handle_terminal_output()
    │
    └─ get_terminal_publisher().publish_output(session_id, data)
```

### 2. Django → Centrifugo (через HTTP API)

```python
# consumers.py
await client.publish(
    channel=f"terminal#session#{session_id}",
    data={
        "type": "output",
        "data": base64_encoded,
        "is_stderr": False,
        "sequence": 123,
        "timestamp": "2025-12-11T12:00:00Z"
    }
)
```

**URL:** `http://centrifugo:8000/api` (внутри Docker) ✅ РАБОТАЕТ

### 3. Centrifugo → Browser (через WebSocket)

```javascript
// Browser WebSocket client
const centrifuge = new Centrifuge('wss://ws.djangocfg.com/connection/websocket')
centrifuge.subscribe(`terminal#session#${sessionId}`, (ctx) => {
  const { type, data } = ctx.data
  if (type === 'output') {
    xterm.write(atob(data))  // base64 decode
  }
})
```

**URL:** `wss://ws.djangocfg.com/connection/websocket` ❌ НЕ РАБОТАЕТ В ПРОДЕ

---

## 🚀 Быстрое решение (для тестирования)

### Вариант A: Открыть порт напрямую

```bash
# На сервере
cd /path/to/docker
nano docker-compose.yaml

# Добавить в centrifugo:
ports:
  - "8120:8000"

# Перезапустить
docker-compose up -d centrifugo

# В браузере изменить URL на:
ws://SERVER_IP:8120/connection/websocket
```

### Вариант B: Использовать Cloudflare Tunnel

```bash
# Установить cloudflared
cloudflared tunnel create djangocfg-ws

# Создать туннель для WebSocket
cloudflared tunnel route dns djangocfg-ws ws.djangocfg.com

# Запустить
cloudflared tunnel run djangocfg-ws
```

---

## 📈 Мониторинг

### Метрики для отслеживания

1. **Centrifugo подключения:**
   - Активные WebSocket соединения
   - Ошибки подключения
   - Latency

2. **Django публикации:**
   - Успешные publish к Centrifugo
   - Ошибки CentrifugoConnectionError
   - Retry attempts

3. **Terminal сессии:**
   - Активные сессии
   - Output throughput (байт/сек)
   - Error rate

### Логи для проверки

```bash
# Django
docker logs djangocfg-django | grep -E "(centrifugo|terminal)" | tail -100

# Centrifugo
docker logs djangocfg-centrifugo | tail -100

# Traefik
docker logs djangocfg-traefik | grep ws.djangocfg.com | tail -100
```

---

## ✅ Когда проблема решена

**Признаки успеха:**

1. ✅ Browser DevTools → Network → WS → Status: 101 Switching Protocols
2. ✅ Terminal output отображается в реальном времени в браузере
3. ✅ Нет ошибок в Django логах о Centrifugo
4. ✅ Centrifugo логи показывают активные подписки на каналы

**Тестирование:**

```bash
# 1. Создать terminal сессию в Electron
# 2. Открыть браузер: https://terminal.djangocfg.com/private/terminal/{SESSION_ID}
# 3. Ввести команду в Electron: echo "Hello from Electron"
# 4. Проверить что "Hello from Electron" появился в браузере

# Ожидаемое: Вывод синхронизирован в реальном времени
```

---

## 📞 Дополнительная информация

### Документация Centrifugo
- WebSocket: https://centrifugal.dev/docs/transports/websocket
- HTTP API: https://centrifugal.dev/docs/server/server_api

### Traefik и WebSocket
- https://doc.traefik.io/traefik/routing/routers/#websocket

### Отладка WebSocket
```bash
# Инструмент wscat
npm install -g wscat
wscat -c wss://ws.djangocfg.com/connection/websocket
```

---

**Автор отчета:** Claude (Electron Terminal Analysis)
**Агенты:** Explore (Docker Config), Explore (gRPC Centrifugo)
**Дата создания:** 2025-12-11
