# Server-Side vs Client-Side Subscriptions in Centrifugo

## Problem

When generating JWT tokens for Centrifugo, using the `channels` claim causes **server-side auto-subscription**. If the frontend then also tries to subscribe via `subscription.subscribe()`, Centrifugo returns error code 105: "already subscribed".

## Symptoms

Browser console shows:
```
[SharedTerminal] Centrifugo connected
[SharedTerminal] Unsubscribed from channel
```

Centrifugo logs show:
```json
{
  "level": "info",
  "channel": "terminal:session:xxx",
  "message": "client already subscribed on channel"
}
{
  "code": 105,
  "error": "already subscribed"
}
```

## Root Cause

Two subscription mechanisms conflicting:

### 1. Server-Side Subscription (via JWT token)

```python
payload = {
    "sub": user_id,
    "exp": exp,
    "channels": ["terminal:session:xxx"],  # <-- Auto-subscribes on connect
}
```

When client connects with this token, Centrifugo automatically subscribes them to the channels listed in the `channels` claim.

### 2. Client-Side Subscription (via centrifuge-js)

```typescript
const subscription = centrifuge.newSubscription(channel);
subscription.subscribe();  // <-- Tries to subscribe again
```

This creates a **second** subscription attempt, which fails because the client is already subscribed via the token.

## Solution

Choose ONE subscription method:

### Option A: Client-Side Only (Recommended)

Remove `channels` from the token:

```python
payload = {
    "sub": user_id,
    "exp": exp,
    # NO "channels" claim
}
```

Frontend subscribes normally:

```typescript
const subscription = centrifuge.newSubscription(channel);
subscription.on('subscribed', () => console.log('Subscribed'));
subscription.on('publication', handleMessage);
subscription.subscribe();
centrifuge.connect();
```

Authorization via namespace config:
```json
{
  "name": "terminal",
  "allow_subscribe_for_client": true
}
```

### Option B: Server-Side Only

Keep `channels` in token, but don't create client-side subscription:

```typescript
// No newSubscription() call
centrifuge.on('publication', (ctx) => {
  // Handle all publications from server-side subscriptions
  console.log('Channel:', ctx.channel);
  console.log('Data:', ctx.data);
});
centrifuge.connect();
```

## When to Use Which

| Use Case | Recommendation |
|----------|----------------|
| User can subscribe to multiple channels dynamically | Client-Side |
| Fixed channels known at auth time | Server-Side |
| Need subscription lifecycle events (subscribed/unsubscribed) | Client-Side |
| Simple read-only viewers | Either works |
| Need subscribe proxy validation | Client-Side |

## Centrifugo v6 Config Notes

In Centrifugo v6, the subscribe proxy configuration format changed significantly:

### Old Format (v5 and earlier) - INVALID in v6:
```json
{
  "proxy": {
    "subscribe": {
      "endpoint": "http://backend/subscribe"
    }
  },
  "channel": {
    "namespaces": [
      {
        "name": "terminal",
        "proxy_subscribe": true
      }
    ]
  }
}
```

### New Format (v6):
```json
{
  "channel": {
    "proxy": {
      "subscribe": {
        "endpoint": "http://backend/subscribe"
      }
    },
    "namespaces": [
      {
        "name": "terminal",
        "subscribe_proxy_enabled": true
      }
    ]
  }
}
```

### Key Changes:
| v5 | v6 |
|----|-----|
| `proxy.subscribe.endpoint` | `channel.proxy.subscribe.endpoint` |
| `proxy_subscribe: true` | `subscribe_proxy_enabled: true` |

### Warnings indicating outdated config:
```
"unknown key in configuration file" for proxy_subscribe
"unknown key in configuration file" for proxy
"unknown var in environment" for CENTRIFUGO_SUBSCRIBE_PROXY_ENDPOINT
```

Source: https://centrifugal.dev/docs/server/proxy

## Related Files

- Token generation: `apps/terminal/views/api/shared_viewsets.py`
- Frontend subscription: `SharedTerminal.tsx`
- Centrifugo config: `docker/services/centrifugo/config.json`
