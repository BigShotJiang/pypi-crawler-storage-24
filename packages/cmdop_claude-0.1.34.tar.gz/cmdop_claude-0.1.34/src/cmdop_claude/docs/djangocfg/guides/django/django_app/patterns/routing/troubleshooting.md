# 🚨 Common Issues & Solutions

## 1. **Admin Interface URLs Not Working (404 Errors)**

### Problem: Admin interface returns 404 or import errors

### A. **Method Decorator on Mixin Classes**

**❌ PROBLEM**: Decorators on mixin classes cause import issues
```python
# This causes circular imports and 404s
@method_decorator(staff_member_required, name='dispatch')
class AdminTemplateViewMixin(TemplateView):  # Mixin with decorator!
    pass

class PaymentListView(AdminTemplateViewMixin, LoginRequiredMixin, TemplateView):
    pass
```

**✅ SOLUTION**: Move decorators to concrete view classes
```python
# Clean mixin without decorators
class AdminTemplateViewMixin(TemplateView):
    def get_context_data(self, **kwargs):
        # Mixin logic only
        pass

# Decorator on concrete class
@method_decorator(staff_member_required, name='dispatch')
class PaymentListView(AdminTemplateViewMixin, LoginRequiredMixin, TemplateView):
    template_name = 'payments/payment_list.html'
```

### B. **Incorrect Import Paths in Admin Interface**

**❌ PROBLEM**: Wrong relative imports
```python
from ...models import UniversalPayment  # Too many dots
from ..base import AdminBaseViewSet     # Wrong path
```

**✅ SOLUTION**: Fix relative import paths
```python
from ....models import UniversalPayment  # Correct path
from ..base import AdminBaseViewSet      # Correct path

# Or use absolute imports
from django_cfg.apps.payments.models import UniversalPayment
```

### C. **URLs Not Registered in Main Configuration**

**❌ PROBLEM**: Admin URLs not included in main routing
```python
# Missing from django_cfg/apps/urls.py
urlpatterns = [
    path('payments/', include('django_cfg.apps.payments.urls')),
    # Missing: path('cfg/admin/django_cfg_payments/', include(...))
]
```

**✅ SOLUTION**: Add admin URLs to main configuration
```python
urlpatterns = [
    path('payments/', include('django_cfg.apps.payments.urls')),
    path('cfg/admin/django_cfg_payments/', include('django_cfg.apps.payments.urls_admin')),
]
```

## 2. **Import Errors During URL Loading**

### Problem: Circular imports or missing modules

**❌ COMMON ISSUES**:
```python
# Circular import
from .views import SomeView  # views.py imports from urls.py

# Missing import
from .views import NonExistentView

# Wrong import path
from ..wrong.path import View
```

**✅ SOLUTIONS**:
```python
# Use string-based view references
path('payments/', 'django_cfg.apps.payments.views.PaymentListView', name='payment-list')

# Or import at function level
def get_urlpatterns():
    from .views import PaymentListView
    return [
        path('payments/', PaymentListView.as_view(), name='payment-list'),
    ]

urlpatterns = get_urlpatterns()
```

## 3. **Middleware Blocking Admin Access**

### Problem: API middleware requires authentication for admin interface

### A. **Old Approach: Blacklist (Exempt Paths)**
```python
# ❌ PROBLEM: Hard to maintain, security risks
class APIAccessMiddleware:
    def __init__(self):
        # Need to remember to exempt EVERY public path
        self.exempt_paths = [
            '/api/health/', '/admin/', '/api/cfg/admin/',
            '/api/payments/', '/api/currencies/', '/api/webhooks/',
            # ... endless list of exemptions
        ]
    
    def process_request(self, request):
        if request.path.startswith('/api/') and not self._is_exempt(request.path):
            return self.require_api_key(request)
```

### B. **New Approach: Whitelist (Protected Paths) ✅**
```python
# ✅ SOLUTION: Whitelist approach - more secure and maintainable
class APIAccessMiddleware:
    def __init__(self):
        # Only specify paths that NEED protection
        self.protected_paths = [
            '/api/admin/',    # Admin API endpoints
            '/api/private/',  # Private API endpoints
            '/api/secure/',   # Secure API endpoints
        ]
        
        self.protected_patterns = [
            re.compile(r'^/api/admin/.*$'),
            re.compile(r'^/api/private/.*$'),
            re.compile(r'^/api/secure/.*$'),
        ]
    
    def process_request(self, request):
        if self._is_protected_path(request.path):
            return self.require_api_key(request)
        # All other paths are public by default
        return None
    
    def _is_protected_path(self, path: str) -> bool:
        """Check if path requires API key (whitelist approach)."""
        # Check exact protected paths
        for protected_path in self.protected_paths:
            if path.startswith(protected_path):
                return True
        
        # Check protected patterns
        for pattern in self.protected_patterns:
            if pattern.match(path):
                return True
        
        return False  # Not protected - public access
```

**Benefits of Whitelist Approach**:
- 🔒 **More Secure**: Public by default, protection by exception
- 🧹 **Easier Maintenance**: Only list what needs protection
- 🐛 **Fewer Bugs**: No need to remember every public endpoint
- 📖 **Better Documentation**: Clear intent of what's protected

## 4. **Model Field Issues in API ViewSets**

### Problem: Django filters fail with non-existent field names

**❌ PROBLEM**: Wrong field names in filterset_fields
```python
class AdminPaymentViewSet(AdminBaseViewSet):
    filterset_fields = ['status', 'provider', 'currency_code', 'user']  # currency_code doesn't exist!
    
# Error: TypeError: 'Meta.fields' must not contain non-model field names: currency_code
```

**✅ SOLUTION**: Use correct field relationships
```python
class AdminPaymentViewSet(AdminBaseViewSet):
    filterset_fields = ['status', 'provider', 'currency__code', 'user']  # Use ForeignKey relationship
    
# Model structure:
# UniversalPayment.currency -> ForeignKey to Currency model
# Currency.code -> CharField with currency code
```

## 5. **Missing Manager Methods**

### Problem: AttributeError for missing manager methods

**❌ PROBLEM**: QuerySet has method but Manager doesn't expose it
```python
# In PaymentQuerySet
def by_user(self, user):
    return self.filter(user=user)

# In PaymentManager - MISSING METHOD!
class PaymentManager(models.Manager):
    def get_queryset(self):
        return PaymentQuerySet(self.model, using=self._db)
    # Missing: by_user method!

# Usage fails:
Payment.objects.by_user(user)  # AttributeError: 'PaymentManager' object has no attribute 'by_user'
```

**✅ SOLUTION**: Add missing methods to Manager
```python
class PaymentManager(models.Manager):
    def get_queryset(self):
        return PaymentQuerySet(self.model, using=self._db)
    
    def by_user(self, user):
        """Get payments by user."""
        return self.get_queryset().by_user(user)
```

## 6. **JavaScript API Integration Issues**

### Problem: PaymentAPI not available in browser

**❌ SYMPTOMS**:
```javascript
// Console errors:
// TypeError: Cannot read properties of undefined (reading 'payments')
// PaymentAPI is not available
```

**✅ DEBUGGING STEPS**:
```javascript
// 1. Check if API client loads
console.log('PaymentAPI available:', typeof window.PaymentAPI);
console.log('PaymentAPIClient class:', typeof PaymentAPIClient);

// 2. Check script loading order
// base.html should load api-client.js BEFORE payment-list.js

// 3. Check for JavaScript errors
// Look for syntax errors preventing script execution

// 4. Verify API endpoints
fetch('/cfg/admin/django_cfg_payments/admin/api/payments/')
    .then(r => r.json())
    .then(data => console.log('API works:', data))
    .catch(e => console.error('API error:', e));
```

## 7. **URL Pattern Debugging**

### Useful Commands:
```bash
# Show all URL patterns with Django-CFG command
python manage.py show_urls

# Filter to specific app
python manage.py show_urls --filter payments

# Show in table format with methods
python manage.py show_urls --format table --show-methods

# Test URL resolution
python manage.py shell
>>> from django.urls import reverse
>>> reverse('cfg_payments:payment-list')

# Check URL pattern matching
>>> from django.urls import resolve
>>> resolve('/api/payments/payments/')
```

### Debug URL Issues:
```python
# In Django shell
from django.conf import settings
print("URL_CONF:", settings.ROOT_URLCONF)

# Check if URLs are loaded
from django.urls import get_resolver
resolver = get_resolver()
print("URL patterns:", resolver.url_patterns)
```

## 8. **Server Restart Requirements**

### When to Restart Django Server:
- ✅ **URL pattern changes** (urls.py modifications)
- ✅ **New view imports** (adding new views to urls.py)
- ✅ **Middleware changes** (MIDDLEWARE setting changes)
- ✅ **Settings modifications** (settings.py changes)

### When Restart NOT Needed:
- ❌ **Template changes** (auto-reloaded in DEBUG=True)
- ❌ **Static file changes** (served directly in development)
- ❌ **View logic changes** (auto-reloaded)
- ❌ **Model changes** (after migrations)

## 9. **Cache-Related Issues**

### Problem: Browser caches old JavaScript/CSS

**✅ SOLUTIONS**:
```python
# 1. Add cache busting to templates
<script src="{% static 'payments/js/payment-list.js' %}?v={{ timestamp }}"></script>

# 2. Use Django's cache busting
{% load static %}
<script src="{% static 'payments/js/payment-list.js' %}"></script>

# 3. Force browser refresh
# Chrome/Firefox: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)
# Or: DevTools → Network → "Disable cache"
```

## 10. **Common Error Patterns & Solutions**

### A. **404 on Admin Interface**
```
Problem: /cfg/admin/django_cfg_payments/admin/ returns 404
Solution: Check urls_admin.py is included in main URLs
```

### B. **500 on API Endpoints**
```
Problem: /cfg/admin/django_cfg_payments/admin/api/payments/ returns 500
Solution: Check model field names in filterset_fields
```

### C. **JavaScript Errors**
```
Problem: PaymentAPI is not defined
Solution: Check script loading order and syntax errors
```

### D. **Import Errors**
```
Problem: ImportError: cannot import name 'SomeView'
Solution: Check import paths and circular dependencies
```

### E. **Permission Denied**
```
Problem: 403 Forbidden on admin interface
Solution: Check user permissions and middleware configuration
```

## 11. **Debugging Workflow**

### Step-by-Step Debugging Process:
1. **Identify Error Type**
   - 404: URL routing issue
   - 500: Server-side code issue
   - 403: Permission/middleware issue
   - JavaScript: Client-side issue

2. **Check Logs**
   - Django server logs (terminal)
   - Browser console logs
   - Network tab in DevTools

3. **Verify Configuration**
   - URLs are registered
   - Imports are correct
   - Middleware is configured properly

4. **Test Incrementally**
   - Start with simple endpoint
   - Add complexity gradually
   - Use MCP for automated testing

5. **Document Solution**
   - Record the fix
   - Update documentation
   - Add to troubleshooting guide
