# 🎯 Test Organization Patterns

## 1. **Test Factory Pattern (Real Implementation)**
```python
# Real pattern from django-cfg tests
class DocumentFactory:
    """Factory for creating test documents."""
    
    @staticmethod
    def create_with_chunks(user, chunk_count=3, title="Test Document"):
        """Create document with specified number of chunks."""
        document = ExternalData.objects.create(
            user=user,
            title=title,
            content="Test content " * 100,
            processing_status=ProcessingStatus.COMPLETED
        )
        
        for i in range(chunk_count):
            ExternalDataChunk.objects.create(
                external_data=document,
                user=user,
                content=f"Chunk {i} content",
                chunk_index=i,
                embedding_vector=[0.1 * i] * 1536  # Mock embedding
            )
        
        return document
    
    @staticmethod
    def create_processing_document(user, title="Processing Document"):
        """Create document in processing state."""
        return ExternalData.objects.create(
            user=user,
            title=title,
            content="Content being processed",
            processing_status=ProcessingStatus.PROCESSING
        )

class UserFactory:
    """Factory for creating test users."""
    
    @staticmethod
    def create_user(email="test@example.com", username="testuser"):
        """Create standard test user."""
        return User.objects.create_user(
            email=email,
            username=username,
            password="testpass123"
        )
    
    @staticmethod
    def create_superuser(email="admin@example.com", username="admin"):
        """Create test superuser."""
        return User.objects.create_superuser(
            email=email,
            username=username,
            password="adminpass123"
        )
```

## 2. **Test Mixin Pattern (Real Implementation)**
```python
# Real pattern from knowbase tests
class ExternalDataTestMixin:
    """Mixin for external data testing."""
    
    def setUp_external_data(self):
        """Set up external data test fixtures."""
        self.user = UserFactory.create_user()
        self.document = DocumentFactory.create_with_chunks(self.user, chunk_count=5)
    
    def assert_document_processed(self, document):
        """Assert document was processed correctly."""
        self.assertEqual(document.processing_status, ProcessingStatus.COMPLETED)
        self.assertIsNotNone(document.processed_at)
        self.assertGreater(document.chunks.count(), 0)
    
    def assert_chunks_have_embeddings(self, document):
        """Assert all chunks have embeddings."""
        chunks = document.chunks.all()
        for chunk in chunks:
            self.assertIsNotNone(chunk.embedding_vector)
            self.assertGreater(len(chunk.embedding_vector), 0)

class ConfigTestMixin:
    """Mixin for configuration testing."""
    
    def setUp_config(self):
        """Set up configuration test fixtures."""
        self.test_config = {
            'chunk_size': 1000,
            'overlap_size': 100,
            'embedding_model': 'text-embedding-ada-002'
        }
    
    def assert_config_valid(self, config):
        """Assert configuration is valid."""
        self.assertIn('chunk_size', config)
        self.assertIn('overlap_size', config)
        self.assertIn('embedding_model', config)
        self.assertGreater(config['chunk_size'], 0)
        self.assertGreaterEqual(config['overlap_size'], 0)
```

## Test Categories by Purpose
| Category | Purpose | Coverage Focus |
|----------|---------|----------------|
| **Models** | Business logic, data validation | Managers, model methods |
| **Services** | Service layer, integrations | Cache, business logic |
| **Views** | API endpoints, serializers | DRF APIs, HTTP responses |
| **Middleware** | Request/response processing | Access control, tracking |

## 🚨 CRITICAL: One Test Class Per File Rule

**MANDATORY**: Each test class MUST be in a separate file. Never accumulate multiple test classes in one file.

### ❌ WRONG - Multiple classes in one file:
```python
# ❌ BAD: test_models.py (multiple classes)
class PaymentModelTest(TestCase):
    pass

class CurrencyModelTest(TestCase):
    pass

class UserBalanceModelTest(TestCase):
    pass
```

### ✅ CORRECT - One class per file:
```python
# ✅ GOOD: test_payment_model.py (single class)
class PaymentModelTest(TestCase):
    pass

# ✅ GOOD: test_currency_model.py (single class)  
class CurrencyModelTest(TestCase):
    pass

# ✅ GOOD: test_balance_model.py (single class)
class UserBalanceModelTest(TestCase):
    pass
```

### 📏 File Size Limits
- **Max 400 lines per test file**
- **Max 150 lines per test class**
- **If exceeded**: Create subdirectories and split by functionality

## Recommended Modular Test Structure
```
tests/
├── __init__.py
├── README.md                    # Documentation
├── management/                  # Management command tests
│   ├── __init__.py
│   └── commands/               # One file per command
│       ├── __init__.py
│       ├── test_currency_stats.py
│       ├── test_process_payments.py
│       └── test_cleanup_data.py
├── middleware/                  # Middleware tests
│   ├── __init__.py
│   ├── test_api_access.py      # One middleware per file
│   ├── test_rate_limiting.py
│   └── test_usage_tracking.py
├── models/                      # Model and manager tests
│   ├── __init__.py
│   ├── managers/               # One manager per file
│   │   ├── __init__.py
│   │   ├── test_payment_manager.py
│   │   ├── test_balance_manager.py
│   │   └── test_currency_manager.py
│   └── model_tests/            # One model per file
│       ├── __init__.py
│       ├── test_payment_model.py
│       ├── test_currency_model.py
│       └── test_balance_model.py
├── providers/                   # Provider tests
│   ├── __init__.py
│   ├── clients/                # One provider per file
│   │   ├── __init__.py
│   │   └── test_nowpayments.py
│   ├── test_base_provider.py
│   └── test_registry.py
├── services/                    # Service layer tests
│   ├── __init__.py
│   ├── test_cache_service.py    # One service per file
│   └── test_payment_service.py
├── views/                       # API and view tests
│   ├── __init__.py
│   └── api/                    # One viewset per file
│       ├── __init__.py
│       ├── test_payment_api.py
│       └── test_balance_api.py
└── webhooks/                    # Webhook handler tests
    ├── __init__.py
    ├── handlers/               # One handler per file
    │   ├── __init__.py
    │   ├── test_base_handler.py
    │   └── test_nowpayments_handler.py
    ├── test_registry.py
    └── test_security.py
```

### 🎯 Benefits of One-Class-Per-File:
1. **Easier navigation** - Find specific tests instantly
2. **Reduced merge conflicts** - Team development friendly
3. **Parallel test execution** - Better CI/CD performance
4. **Clear responsibility** - Single purpose per file
5. **LLM-friendly** - Better context understanding
