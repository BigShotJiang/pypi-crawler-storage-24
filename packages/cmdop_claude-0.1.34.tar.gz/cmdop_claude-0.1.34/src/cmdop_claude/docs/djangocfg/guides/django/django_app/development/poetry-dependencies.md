# 📦 Poetry & Dependencies Management Guide %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Poetry-based dependency management** with conservative version strategies
- **100+ pre-installed packages** available in Django-CFG applications
- **Organized dependency groups** for development, testing, and production
- **Real configuration examples** from django-cfg pyproject.toml

## 📋 Table of Contents
1. [Poetry Overview](#poetry-overview)
2. [Available Dependencies](#available-dependencies)
3. [Dependency Groups](#dependency-groups)
4. [Adding Dependencies](#adding-dependencies)
5. [Version Strategies](#version-strategies)
6. [Best Practices](#best-practices)

## 🔑 Key Concepts at a Glance
- **Poetry Management**: Modern Python dependency management with pyproject.toml
- **Pre-installed Packages**: 100+ packages ready to use in django-cfg
- **Conservative Versioning**: Minimize conflicts with existing projects
- **Dependency Groups**: Organized by usage (dev, test, docs, full)
- **Hatchling Build**: Modern build system for package distribution

## 🚀 Quick Start

### Basic Commands
```bash
# Add a new dependency
poetry add requests

# Add development dependency
poetry add --group dev pytest

# Add optional dependency
poetry add --optional redis

# Install all dependencies
poetry install

# Install with specific groups
poetry install --with dev,test
```

### Version Constraints
```bash
# Version constraints
poetry add "package>=1.0,<2.0"            # Version range
poetry add package@latest                  # Latest version
poetry add package@^1.0                   # Compatible version
```

## 📦 Poetry Overview

### 1. **Poetry Configuration (Real Implementation)**
```toml
# pyproject.toml - Real configuration from django-cfg
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "django-cfg"
version = "1.2.31"
description = "🚀 Next-gen Django configuration: type-safety, AI features, blazing-fast setup"
requires-python = ">=3.12,<4.0"

# Core dependencies - minimal and essential only
# Note: Django is a peer dependency - users should install it themselves
dependencies = [
    # Core configuration
    "pydantic>=2.11.0,<3.0",
    "pydantic[email]>=2.11.0,<3.0",
    "PyYAML>=6.0,<7.0",
    "pydantic-yaml>=1.6.0,<2.0",
    
    # CLI and utilities
    "click>=8.2.0,<9.0",
    "questionary>=2.1.0,<3.0",
    "rich>=14.0.0,<15.0",
    # ... more dependencies
]
```

### 2. **Version Strategy Philosophy (Real Implementation)**
```toml
# VERSION STRATEGY from django-cfg:
# - Core runtime dependencies: Use minimum compatible versions (>=X.Y) to avoid conflicts
# - Development tools: Use minimum versions with upper bounds for major versions
# - Django: Allow patch updates within major version (>=5.2,<6.0)
# - Infrastructure: Use minimum versions with conservative upper bounds
# - This approach minimizes dependency conflicts when django-cfg is installed in existing projects

dependencies = [
    "pydantic>=2.11.0,<3.0",        # Conservative major version bounds
    "django>=5.2,<6.0",             # Allow patch updates within major
    "redis>=6.4.0,<7.0",            # Infrastructure with upper bounds
    "psycopg[binary,pool]>=3.2.0,<4.0",  # Database with features
]
```

### 3. **Build Configuration (Real Implementation)**
```toml
# Real build configuration from django-cfg
[tool.hatch.build.targets.wheel]
packages = ["src/django_cfg"]
exclude = [
    "examples/",            # Exclude examples directory
    "scripts/",             # Exclude scripts from wheel package
    "opensource/",          # Exclude opensource from wheel package
    "devops/",              # Exclude devops from wheel package
]

[tool.hatch.build.targets.sdist]
include = [
    "src/django_cfg",
    "src/django_cfg/template_archive/*",  # Include template archive files
    "README.md",
    "LICENSE", 
    "CHANGELOG.md",
]
exclude = [
    "@*",
    "devops",              # Exclude devops directory
    "tests",
    "scripts",             # Exclude development scripts
    "*.log",
    ".env*",
]
```

## 📚 Available Dependencies

### 1. **Core Configuration & Validation (Real Dependencies)**
```toml
# Already available in django-cfg - Real from pyproject.toml
dependencies = [
    # Configuration management
    "pydantic>=2.11.0,<3.0",              # Type-safe configuration
    "pydantic[email]>=2.11.0,<3.0",       # Email validation
    "PyYAML>=6.0,<7.0",                   # YAML configuration files
    "pydantic-yaml>=1.6.0,<2.0",          # Pydantic + YAML integration
    
    # CLI and utilities
    "click>=8.2.0,<9.0",                  # Command-line interfaces
    "questionary>=2.1.0,<3.0",            # Interactive prompts
    "rich>=14.0.0,<15.0",                 # Rich text and beautiful formatting
    
    # Configuration utilities
    "toml>=0.10.2,<0.11.0",               # TOML file parsing
    "cachetools>=5.3.0,<7.0",             # Caching utilities
    "colorlog>=6.9.0,<7.0",               # Colored logging
    "loguru>=0.7.0,<1.0",                 # Advanced logging
]
```

### 2. **Django & Web Framework (Real Dependencies)**
```toml
# Django ecosystem - Real from pyproject.toml
dependencies = [
    # Core Django packages
    "whitenoise>=6.8.0,<7.0",                    # Static file serving
    "django-cors-headers>=4.7.0,<5.0",           # CORS handling
    
    # Django REST Framework
    "djangorestframework>=3.16.0,<4.0",          # REST API framework
    "djangorestframework-simplejwt>=5.5.0,<6.0", # JWT authentication
    "djangorestframework-simplejwt[token-blacklist]>=5.5.0,<6.0", # Token blacklist
    "drf-nested-routers>=0.94.0,<1.0",           # Nested API routes
    "django-filter>=25.0,<26.0",                 # API filtering
    "drf-spectacular>=0.28.0,<1.0",              # OpenAPI documentation
    "drf-spectacular-sidecar>=2025.8.0,<2026.0", # Spectacular assets
    
    # Django utilities
    "django-json-widget>=2.0.0,<3.0",            # JSON form widget
    "django-import-export>=4.3.0,<5.0",          # Data import/export
    "django-extensions>=4.1.0,<5.0",             # Django extensions
    "django-constance>=4.3.0,<5.0",              # Dynamic settings
    "django-ratelimit>=4.1.0,<5.0.0",            # Rate limiting
    "django-admin-rangefilter>=0.13.0,<1.0",     # Admin date filters
]
```

### 3. **Database & Caching (Real Dependencies)**
```toml
# Database and caching - Real from pyproject.toml
dependencies = [
    # PostgreSQL support with connection pooling
    "psycopg[binary,pool]>=3.2.0,<4.0",    # PostgreSQL adapter with features
    "dj-database-url>=3.0.0,<4.0",         # Database URL parsing
    
    # Redis and caching
    "django-redis>=6.0.0,<7.0",            # Django Redis integration
    "redis>=6.4.0,<7.0",                   # Redis client
    "hiredis>=2.0.0,<4.0",                 # High-performance Redis parser
]
```

### 4. **Background Tasks & Processing (Real Dependencies)**
```toml
# Task processing - Real from pyproject.toml
dependencies = [
    # Dramatiq for background tasks
    "dramatiq[redis]>=1.18.0,<2.0",        # Background task processing with Redis
    "django-dramatiq>=0.14.0,<1.0",        # Django integration
    
    # Task utilities
    "tenacity>=9.1.2,<10.0.0",             # Retry logic with exponential backoff
]
```

### 5. **Admin Interface & UI (Real Dependencies)**
```toml
# Admin interface - Real from pyproject.toml
dependencies = [
    # Modern admin interface
    "django-unfold>=0.64.0,<1.0",          # Modern Django admin theme
    
    # Admin utilities (automatically included with unfold)
    # Features available:
    # - unfold.contrib.filters
    # - unfold.contrib.forms
    # - unfold.contrib.inlines
    # - unfold.contrib.import_export
    # - unfold.contrib.constance
]
```

### 6. **External Services & APIs (Real Dependencies)**
```toml
# External services - Real from pyproject.toml
dependencies = [
    # Cloud services
    "cloudflare>=4.3.0,<5.0",              # Cloudflare API (latest with Pydantic fixes)
    "requests>=2.32.0,<3.0",               # HTTP requests
    
    # Communication services
    "pyTelegramBotAPI>=4.28.0,<5.0",       # Telegram bot API
    "twilio>=9.8.0,<10.0",                 # Twilio SMS/WhatsApp
    "sendgrid>=6.12.0,<7.0",               # SendGrid email
    
    # Development tools
    "ngrok>=1.5.1; python_version>='3.12'", # Ngrok tunneling (Python 3.12+ only)
]
```

### 7. **AI & Machine Learning (Real Dependencies)**
```toml
# AI/ML services - Real from pyproject.toml
dependencies = [
    # OpenAI integration
    "openai>=1.107.0,<2.0",                # OpenAI API client
    "tiktoken>=0.11.0,<1.0",               # OpenAI tokenizer
    
    # AI framework
    "pydantic-ai>=1.0.10,<2.0",            # Pydantic AI framework
    
    # Knowledge base utilities
    "beautifulsoup4>=4.13.0,<5.0",         # HTML parsing
    "lxml>=6.0.0,<7.0",                    # XML/HTML processing
    "pgvector>=0.4.0,<1.0",                # PostgreSQL vector extension
]
```

### 8. **Utilities & Helpers (Real Dependencies)**
```toml
# Utility packages - Real from pyproject.toml
dependencies = [
    # General utilities
    "coolname>=2.2.0,<3.0",                # Generate cool names
    "currencyconverter>=0.18.0,<1.0",      # Currency conversion
    "python-json-logger>=3.3.0,<4.0",      # JSON logging
    
    # Production dependencies
    "django-revolution>=1.0.43,<2.0",      # API generation framework
]
```

## 📂 Dependency Groups

### 1. **Development Group (Real Implementation)**
```toml
# Real development dependencies from django-cfg
[project.optional-dependencies]
dev = [
    # Django for development - allow patch updates
    "django>=5.2,<6.0",
    
    # Testing - allow minor updates for testing tools
    "pytest>=8.4,<9.0",
    "pytest-django>=4.11,<5.0",
    "pytest-cov>=7.0,<8.0",
    "pytest-mock>=3.15,<4.0",
    "factory-boy>=3.3,<4.0",
    
    # Code quality - allow minor updates but pin major versions
    "black>=25.9,<26.0",                   # Code formatter
    "isort>=6.0,<7.0",                     # Import sorter
    "flake8>=6.0.0,<8.0",                  # Linter
    "mypy>=1.18,<2.0",                     # Type checker
    "pre-commit>=4.3,<5.0",                # Git hooks
    
    # Build and publish tools - allow minor updates
    "build>=1.3,<2.0",                     # Package builder
    "twine>=6.2,<7.0",                     # Package uploader
    "tomlkit>=0.13.3,<1.0",                # TOML manipulation
    "questionary>=2.1.0,<3.0",             # Interactive prompts
    "rich>=13.0.0,<15.0",                  # Rich formatting
    
    # Documentation - allow minor updates
    "mkdocs>=1.6,<2.0",                    # Documentation generator
    "mkdocs-material>=9.6,<10.0",          # Material theme
    "mkdocstrings[python]>=0.30,<1.0",     # Python docstrings
    
    # Task processing already in main dependencies
    "redis>=6.4.0,<7.0",                   # Additional Redis for development
]
```

### 2. **Testing Group (Real Implementation)**
```toml
# Real testing dependencies from django-cfg
test = [
    "django>=5.2,<6.0",                    # Django for tests
    "pytest>=8.4,<9.0",                    # Test framework
    "pytest-django>=4.11,<5.0",            # Django integration
    "pytest-cov>=7.0,<8.0",                # Coverage reporting
    "pytest-mock>=3.15,<4.0",              # Mocking utilities
    "pytest-xdist>=3.8,<4.0",              # Parallel testing
    "factory-boy>=3.3,<4.0",               # Test data generation
]
```

### 3. **Documentation Group (Real Implementation)**
```toml
# Real documentation dependencies from django-cfg
docs = [
    "mkdocs>=1.6,<2.0",                    # Documentation generator
    "mkdocs-material>=9.6,<10.0",          # Material theme
    "mkdocstrings[python]>=0.30,<1.0",     # Python docstrings
    "pymdown-extensions>=10.16,<11.0",     # Markdown extensions
]
```

### 4. **Full Feature Group (Real Implementation)**
```toml
# Real full feature set from django-cfg
full = [
    "django>=5.2,<6.0",
    # Testing - allow minor updates for testing tools
    "pytest>=8.4,<9.0",
    "pytest-django>=4.11,<5.0",
    "pytest-cov>=7.0,<8.0",
    "pytest-mock>=3.15,<4.0",
    "pytest-xdist>=3.8,<4.0",
    "factory-boy>=3.3,<4.0",
    
    # Code quality - allow minor updates but pin major versions
    "black>=25.9,<26.0",
    "isort>=6.0,<7.0",
    "flake8>=6.0.0,<8.0",
    "mypy>=1.18,<2.0",
    "pre-commit>=4.3,<5.0",
    
    # Build and publish tools - allow minor updates
    "build>=1.3,<2.0",
    "twine>=6.2,<7.0",
    "tomlkit>=0.13.3,<1.0",
    "questionary>=2.1.0,<3.0",
    "rich>=13.0.0,<15.0",
    
    # Documentation - allow minor updates
    "mkdocs>=1.6,<2.0",
    "mkdocs-material>=9.6,<10.0",
    "mkdocstrings[python]>=0.30,<1.0",
    "pymdown-extensions>=10.16,<11.0",
    
    # Task processing already in main dependencies
    "redis>=6.4.0,<7.0",                   # Additional Redis for all features
]
```

### 5. **Django Compatibility Groups (Real Implementation)**
```toml
# Real Django compatibility from django-cfg
# Django compatibility - users should install one of these (minimum 5.2)
django52 = ["django>=5.2,<6.0"]

# Local development dependencies group
local = [
    # Uncomment to use local django-revolution development version
    # "django-revolution @ file://../django-revolution"
]
```

## ➕ Adding Dependencies

### 1. **Adding Main Dependencies**
```bash
# Add to main dependencies (available in production)
poetry add requests                        # HTTP client
poetry add pillow                         # Image processing
poetry add celery                         # Alternative task queue

# With version constraints
poetry add "django-extensions>=4.0,<5.0"  # Specific version range
poetry add numpy@latest                    # Latest version
```

### 2. **Adding Development Dependencies**
```bash
# Add to development group
poetry add --group dev black              # Code formatter
poetry add --group dev mypy               # Type checker
poetry add --group dev pre-commit         # Git hooks

# Multiple packages at once
poetry add --group dev black isort flake8 mypy
```

### 3. **Adding Test Dependencies**
```bash
# Add to test group
poetry add --group test pytest            # Test framework
poetry add --group test pytest-django     # Django testing
poetry add --group test factory-boy       # Test data factories
poetry add --group test pytest-mock       # Mocking utilities
```

### 4. **Adding Optional Dependencies**
```bash
# Add as optional (user can choose to install)
poetry add --optional elasticsearch       # Search engine
poetry add --optional sentry-sdk          # Error tracking
poetry add --optional gunicorn            # WSGI server
```

### 5. **Installing Dependency Groups (Real Commands)**
```bash
# Install specific groups
poetry install --with dev                 # Main + dev
poetry install --with dev,test            # Main + dev + test
poetry install --with docs                # Main + docs

# Install only specific group
poetry install --only dev                 # Only dev dependencies
poetry install --only test                # Only test dependencies

# Install everything
poetry install --with dev,test,docs       # All groups
# or
poetry install --extras full              # Full feature set

# Install django-cfg in existing project
pip install django-cfg[django52]          # With Django 5.2
pip install django-cfg[full]              # With all features
```

## 📋 Version Strategies

### 1. **Conservative Versioning (Real Implementation)**
```toml
# Conservative approach from django-cfg - minimize conflicts
dependencies = [
    # Use minimum compatible versions with major version bounds
    "pydantic>=2.11.0,<3.0",              # Allow minor updates, block major
    "django>=5.2,<6.0",                   # Allow patch updates within major
    "redis>=6.4.0,<7.0",                  # Conservative infrastructure bounds
    "psycopg[binary,pool]>=3.2.0,<4.0",   # Database with conservative bounds
]
```

### 2. **Flexible Versioning**
```toml
# More flexible - allow more updates
dependencies = [
    # Caret constraints (compatible updates)
    "requests^2.32.0",                     # >=2.32.0, <3.0.0
    "click^8.2.0",                         # >=8.2.0, <9.0.0
    
    # Tilde constraints (patch updates only)
    "django~=5.2.0",                      # >=5.2.0, <5.3.0
]
```

### 3. **Conditional Dependencies (Real Implementation)**
```toml
# Real conditional dependencies from django-cfg
dependencies = [
    # Python version specific
    "ngrok>=1.5.1; python_version>='3.12'",  # Only for Python 3.12+
    
    # Feature-specific extras
    "pydantic[email]>=2.11.0,<3.0",          # Pydantic with email validation
    "psycopg[binary,pool]>=3.2.0,<4.0",      # PostgreSQL with binary and pool
    "dramatiq[redis]>=1.18.0,<2.0",          # Dramatiq with Redis support
    "djangorestframework-simplejwt[token-blacklist]>=5.5.0,<6.0", # JWT with blacklist
]
```

### 4. **Development vs Production (Real Pattern)**
```bash
# Different strategies for different environments
# Development - more flexible
poetry install --with dev,test

# Production - exact versions from lock file
poetry install --only main

# Export for production deployment
poetry export -f requirements.txt --output requirements.txt --without-hashes

# Generated requirements.txt will have exact versions:
# django==5.2.10
# pydantic==2.11.2
# redis==6.4.2
```

### 5. **Updating Dependencies (Real Commands)**
```bash
# Check for outdated packages
poetry show --outdated

# Update all packages within constraints
poetry update

# Update specific package
poetry update django

# Update to latest version (ignoring constraints)
poetry add django@latest

# See what would be updated
poetry update --dry-run

# Update lock file only
poetry lock --no-update
```

## 🛠️ Best Practices

### 1. **Dependency Selection (Real Examples)**
```bash
# ✅ GOOD: Use well-maintained packages (from django-cfg)
poetry add pydantic                        # Type-safe, modern, well-maintained
poetry add django-unfold                   # Modern admin, actively developed
poetry add dramatiq                        # Reliable task queue

# ❌ AVOID: Unmaintained or experimental packages
poetry add some-experimental-package       # Check maintenance status first
poetry add abandoned-library               # Check last update date
```

### 2. **Version Constraints (Real Examples)**
```toml
# ✅ GOOD: Conservative constraints (django-cfg pattern)
dependencies = [
    "django>=5.2,<6.0",                   # Allow patches, block major changes
    "pydantic>=2.11.0,<3.0",              # Allow minor updates
    "redis>=6.4.0,<7.0",                  # Infrastructure with bounds
]

# ❌ AVOID: Too restrictive or too loose
dependencies = [
    "django==5.2.10",                     # Too restrictive (no security updates)
    "requests>=2.0",                      # Too loose (major version changes)
    "pydantic>=1.0,<4.0",                 # Too wide range
]
```

### 3. **Group Organization (Real Pattern)**
```bash
# ✅ GOOD: Logical grouping (django-cfg pattern)
poetry add --group dev black isort mypy   # Development tools together
poetry add --group test pytest factory-boy # Testing tools together
poetry add --group docs mkdocs mkdocs-material # Documentation together

# ❌ AVOID: Mixing concerns
poetry add --group dev pytest django       # Mix of dev tools and runtime deps
poetry add --group test black              # Code formatter in test group
```

### 4. **Configuration Tools (Real Implementation)**
```toml
# Real tool configuration from django-cfg pyproject.toml

# Black configuration
[tool.black]
line-length = 100
target-version = ['py39']
include = '\.pyi?$'
extend-exclude = '''
/(
    \.eggs
  | \.git
  | \.mypy_cache
  | \.tox
  | \.venv
  | migrations
)/
'''

# isort configuration
[tool.isort]
profile = "black"
line_length = 100
multi_line_output = 3
known_django = ["django"]
known_first_party = ["django_cfg"]
sections = ["FUTURE", "STDLIB", "DJANGO", "THIRDPARTY", "FIRSTPARTY", "LOCALFOLDER"]

# MyPy configuration
[tool.mypy]
python_version = "3.9"
check_untyped_defs = true
ignore_missing_imports = true
warn_unused_ignores = true
disallow_untyped_defs = true

# Pytest configuration
[tool.pytest.ini_options]
addopts = [
    "--cov=django_cfg",
    "--cov-report=term-missing",
    "--cov-fail-under=50",
    "--strict-markers",
    "--verbose",
]
testpaths = ["tests"]
```

### 5. **Regular Maintenance (Real Workflow)**
```bash
# Regular dependency maintenance routine for django-cfg
poetry show --outdated                    # Check for updates
poetry update                             # Update within constraints
poetry audit                              # Check for security issues (if available)

# Test after updates
poetry run python -m pytest               # Run tests
poetry run python manage.py check         # Django system check
poetry run python manage.py migrate --check # Check migrations

# Export updated requirements
poetry export -f requirements.txt --output requirements.txt

# Update lock file
poetry lock
```

### 6. **Project Scripts (Real Implementation)**
```toml
# Real project scripts from django-cfg
[project.scripts]
django-cfg = "django_cfg.cli.main:main"

# Usage after installation:
# django-cfg create-project "My Project"
# django-cfg info
```

## 🏷️ Metadata
**Tags**: `poetry, dependencies, packages, management, versioning, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Real Examples**: 100+ dependencies from django-cfg pyproject.toml
**DEPENDS_ON**: [poetry, pyproject.toml, hatchling]
**USED_BY**: [all-django-cfg-developers, package-maintainers]
