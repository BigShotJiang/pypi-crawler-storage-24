# 🏗️ Django-CFG Application Architecture %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Layered architecture** with clear separation of concerns
- **Decomposed structure** for scalability and maintainability  
- **Type-safe design** with Pydantic 2 integration
- **Real examples** from payments, knowbase, agents, and support apps

## 📋 Table of Contents
1. [Architecture Principles](#architecture-principles)
2. [Real Directory Structure](#real-directory-structure)
3. [Layer Separation](#layer-separation)
4. [File Organization](#file-organization)
5. [Configuration Patterns](#configuration-patterns)

## 🔑 Key Concepts at a Glance
- **Layered Architecture**: Models → Managers → Services → Views → Admin
- **Decomposed Structure**: Separate files for different concerns
- **Type Safety**: Pydantic 2 for internal services, Django ORM for CRUD
- **Configuration Management**: Centralized config access patterns
- **URL Separation**: Public API vs Admin endpoints

## 🚀 Quick Start

### Standard Django-CFG App Creation
```bash
# Create new Django-CFG app
python manage.py startapp myapp

# Follow the standard structure
myapp/
├── models/           # Database models
├── managers/         # ORM managers  
├── services/         # Business logic
├── views/           # HTTP handlers
├── admin/           # Admin interfaces
├── config/          # App configuration
└── static/          # Frontend assets
```

## 🏛️ Architecture Principles

### 1. **Layered Architecture**
```
┌─────────────────┐
│   Admin Layer   │ ← Custom admin interfaces, actions
├─────────────────┤
│   View Layer    │ ← HTTP handling, serialization
├─────────────────┤
│  Service Layer  │ ← Business logic, Pydantic validation
├─────────────────┤
│ Manager Layer   │ ← Complex queries, database operations
├─────────────────┤
│  Model Layer    │ ← Database schema, relationships
└─────────────────┘
```

### 2. **Separation of Concerns**
- **Models**: Database schema only, minimal business logic
- **Managers**: Complex queries and database operations
- **Services**: Business logic, external API calls, Pydantic validation
- **Views**: HTTP request/response handling, serialization
- **Admin**: Custom admin interfaces and management actions

### 3. **Type Safety First**
```python
# ✅ CORRECT: Type-safe service layer
from pydantic import BaseModel

class PaymentRequest(BaseModel):
    user_id: int
    amount_usd: float
    currency_code: str

class PaymentService:
    def create_payment(self, data: PaymentRequest) -> PaymentResponse:
        # Business logic with type safety
        return PaymentResponse(payment_id=payment.id, status="pending")
        
# ❌ WRONG: Untyped functions
def create_payment(data):
    # No type information
    pass
```

## 📁 Real Directory Structure

### Payments App (Real Example from django-cfg)
```
payments/
├── __init__.py
├── apps.py
├── README.md
├── urls.py                    # Public API endpoints
├── urls_admin.py              # Admin endpoints
│
├── models/                    # Database layer
│   ├── __init__.py
│   ├── base.py               # Base models, mixins
│   ├── payments.py           # Payment models
│   ├── currencies.py         # Currency models
│   ├── balance.py            # Balance models
│   └── managers/             # ORM managers
│       ├── __init__.py
│       ├── payment_managers.py
│       ├── currency_managers.py
│       └── balance_managers.py
│
├── services/                  # Business logic layer
│   ├── __init__.py
│   ├── core/                 # Core services
│   │   ├── __init__.py
│   │   └── payment_service.py
│   ├── types/                # Pydantic models
│   │   ├── __init__.py
│   │   ├── requests.py       # Request models
│   │   └── responses.py      # Response models
│   ├── providers/            # Payment providers
│   │   ├── __init__.py
│   │   └── nowpayments.py
│   ├── integrations/         # External services
│   │   ├── __init__.py
│   │   └── currency_api.py
│   └── cache/                # Caching services
│       ├── __init__.py
│       └── currency_cache.py
│
├── views/                     # HTTP layer
│   ├── __init__.py
│   ├── api/                  # REST API views
│   │   ├── __init__.py
│   │   └── viewsets.py
│   └── serializers/          # DRF serializers
│       ├── __init__.py
│       └── payment_serializers.py
│
├── admin/                     # Admin interface layer
│   ├── __init__.py
│   ├── payment_admin.py      # Payment admin
│   ├── currency_admin.py     # Currency admin
│   ├── filters.py            # Custom admin filters
│   └── resources.py          # Import/Export resources
│
├── admin_interface/           # Custom admin templates/static
│   ├── templates/
│   │   └── payments/
│   │       ├── dashboard.html
│   │       └── reports.html
│   └── views/
│       ├── __init__.py
│       └── dashboard_views.py
│
├── config/                    # Configuration layer
│   ├── __init__.py
│   ├── django_cfg_integration.py  # Django-CFG integration
│   ├── helpers.py            # Config helpers
│   └── constance/            # Dynamic settings
│       ├── __init__.py
│       ├── fields.py
│       ├── settings.py
│       └── config_service.py
│
├── management/                # Django commands
│   ├── __init__.py
│   └── commands/
│       ├── __init__.py
│       ├── sync_currencies.py
│       └── process_payments.py
│
├── middleware/                # Custom middleware
│   ├── __init__.py
│   ├── api_access.py         # API access control
│   ├── rate_limiting.py      # Rate limiting
│   └── usage_tracking.py     # Usage tracking
│
├── signals/                   # Django signals
│   ├── __init__.py
│   ├── payment_signals.py    # Payment-related signals
│   ├── balance_signals.py    # Balance-related signals
│   └── subscription_signals.py
│
├── templatetags/              # Template tags
│   ├── __init__.py
│   └── payment_tags.py
│
├── static/                    # Frontend assets
│   └── payments/
│       ├── css/
│       ├── js/
│       └── images/
│
├── migrations/                # Database migrations
│   ├── __init__.py
│   └── 0001_initial.py
│
└── @docs_new/                 # Documentation
    ├── admin/
    ├── api/
    ├── models/
    └── services/
```

### Knowbase App (Real Example)
```
knowbase/
├── __init__.py
├── apps.py
├── README.md
├── urls.py
│
├── models/
│   ├── __init__.py
│   ├── document.py           # Document models
│   ├── chat.py              # Chat models
│   └── archive.py           # Archive models
│
├── managers/
│   ├── __init__.py
│   ├── base.py              # Base managers
│   └── document.py          # Document managers
│
├── services/
│   ├── __init__.py
│   ├── rag/                 # RAG services
│   │   ├── __init__.py
│   │   ├── embeddings.py
│   │   └── search.py
│   ├── chat/                # Chat services
│   │   ├── __init__.py
│   │   └── chat_service.py
│   └── archive/             # Archive services
│       ├── __init__.py
│       └── archive_service.py
│
├── views/
│   ├── __init__.py
│   ├── api_views.py         # API views
│   └── public_views.py      # Public views
│
├── admin/
│   ├── __init__.py
│   ├── document_admin.py
│   ├── chat_admin.py
│   └── archive_admin.py
│
└── @docs/                   # Documentation
    ├── models.md
    ├── services.md
    └── api.md
```

## 🔄 Layer Separation

### 1. **Model Layer (Schema Only)**
```python
# models/payments.py - Real example from django-cfg
from django.db import models
from .base import UUIDTimestampedModel

class UniversalPayment(UUIDTimestampedModel):
    """Payment model - schema definition only."""
    
    # Schema fields
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    amount_usd = models.FloatField()
    status = models.CharField(max_length=20, choices=PaymentStatus.choices)
    currency = models.ForeignKey(Currency, on_delete=models.PROTECT)
    
    # Manager assignment
    from .managers.payment_managers import PaymentManager
    objects = PaymentManager()
    
    # Simple properties only (no business logic)
    @property
    def is_completed(self) -> bool:
        return self.status == 'completed'
    
    # Delegate business operations to manager
    def mark_completed(self, actual_amount_usd=None):
        return self.__class__.objects.mark_payment_completed(self, actual_amount_usd)
```

### 2. **Manager Layer (Database Operations)**
```python
# models/managers/payment_managers.py - Real example
class PaymentManager(models.Manager):
    """Manager for payment operations with optimized queries."""
    
    def get_queryset(self):
        return PaymentQuerySet(self.model, using=self._db)
    
    def optimized(self):
        """Get optimized queryset for admin/API use."""
        return self.get_queryset().optimized()
    
    def mark_payment_completed(self, payment_id, actual_amount_usd=None, transaction_hash=None):
        """Business logic for completing payments."""
        try:
            payment = self.get(id=payment_id)
            
            # Validate payment can be completed
            if not payment.status in ['pending', 'confirming', 'confirmed']:
                return False
            
            # Update payment
            payment.status = 'completed'
            payment.completed_at = timezone.now()
            if actual_amount_usd:
                payment.actual_amount_usd = actual_amount_usd
            
            payment.save(update_fields=['status', 'completed_at', 'actual_amount_usd'])
            return True
            
        except Exception as e:
            logger.error(f"Failed to complete payment: {e}")
            return False
```

### 3. **Service Layer (Business Logic)**
```python
# services/core/payment_service.py - Real pattern
from pydantic import BaseModel
from typing import Optional

class PaymentRequest(BaseModel):
    user_id: int
    amount_usd: float
    currency_code: str
    provider: str = 'nowpayments'

class PaymentResponse(BaseModel):
    payment_id: str
    status: str
    pay_amount: Optional[float] = None
    payment_url: Optional[str] = None

class PaymentService:
    """Service layer with Pydantic validation."""
    
    def create_payment(self, data: PaymentRequest) -> PaymentResponse:
        """Create payment with business validation."""
        # Business validation
        if data.amount_usd < 1.0 or data.amount_usd > 50000.0:
            raise ValueError("Amount must be between $1.00 and $50,000.00")
        
        # Get currency
        currency = Currency.objects.get(code=data.currency_code)
        user = User.objects.get(id=data.user_id)
        
        # Create payment via manager
        payment = UniversalPayment.objects.create_payment(
            user=user,
            amount_usd=data.amount_usd,
            currency=currency,
            provider=data.provider
        )
        
        return PaymentResponse(
            payment_id=str(payment.id),
            status=payment.status,
            pay_amount=payment.pay_amount,
            payment_url=payment.payment_url
        )
```

### 4. **View Layer (HTTP Handling)**
```python
# views/api/viewsets.py - Real pattern
from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action

class PaymentViewSet(viewsets.ModelViewSet):
    """Payment API endpoints."""
    
    queryset = UniversalPayment.objects.optimized()
    serializer_class = PaymentSerializer
    
    @action(detail=False, methods=['post'])
    def create_payment(self, request):
        """Create new payment."""
        try:
            # Validate request data
            payment_data = PaymentRequest(**request.data)
            
            # Use service layer
            service = PaymentService()
            result = service.create_payment(payment_data)
            
            return Response(result.dict(), status=status.HTTP_201_CREATED)
            
        except ValueError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': 'Internal error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
```

### 5. **Admin Layer (Management Interface)**
```python
# admin/payment_admin.py - Real example
from django.contrib import admin
from unfold.admin import ModelAdmin
from django_cfg import ImportExportModelAdmin

@admin.register(UniversalPayment)
class PaymentAdmin(ModelAdmin, ImportExportModelAdmin):
    """Payment admin with Unfold styling."""
    
    list_display = [
        'internal_payment_id', 'user', 'amount_usd', 'currency',
        'status_badge', 'provider', 'created_at'
    ]
    list_filter = ['status', 'provider', 'currency', 'created_at']
    search_fields = ['internal_payment_id', 'user__email', 'transaction_hash']
    readonly_fields = ['created_at', 'updated_at']
    
    actions = ['mark_completed_action', 'mark_failed_action']
    
    @display(description="Status")
    def status_badge(self, obj):
        """Display status with colored badge."""
        colors = {
            'completed': 'green',
            'pending': 'yellow',
            'failed': 'red'
        }
        color = colors.get(obj.status, 'gray')
        return format_html(
            '<span class="badge badge-{}">{}</span>',
            color, obj.get_status_display()
        )
```

## ⚙️ Configuration Patterns

### 1. **App Configuration Integration**
```python
# config/django_cfg_integration.py - Real pattern
from django_cfg.core.config import get_current_config

def get_payments_config():
    """Get payments configuration from django-cfg."""
    config = get_current_config()
    return config.payments

def get_nowpayments_api_key():
    """Get NowPayments API key from config."""
    config = get_payments_config()
    return config.nowpayments_api_key
```

### 2. **Constance Dynamic Settings**
```python
# config/constance/settings.py - Real pattern
CONSTANCE_CONFIG = {
    'PAYMENTS_NOWPAYMENTS_API_KEY': (
        '',
        'NowPayments API Key',
        str
    ),
    'PAYMENTS_MIN_AMOUNT_USD': (
        1.0,
        'Minimum payment amount in USD',
        float
    ),
    'PAYMENTS_MAX_AMOUNT_USD': (
        50000.0,
        'Maximum payment amount in USD',
        float
    ),
}

CONSTANCE_CONFIG_FIELDSETS = {
    'Payment Settings': {
        'fields': (
            'PAYMENTS_NOWPAYMENTS_API_KEY',
            'PAYMENTS_MIN_AMOUNT_USD',
            'PAYMENTS_MAX_AMOUNT_USD',
        ),
        'collapse': False,
    },
}
```

### 3. **Service Configuration**
```python
# config/helpers.py - Real pattern
from constance import config as constance_config
from django_cfg.core.config import get_current_config

class PaymentsConfigHelper:
    """Helper for accessing payments configuration."""
    
    @staticmethod
    def get_api_key(provider: str) -> str:
        """Get API key for payment provider."""
        if provider == 'nowpayments':
            return constance_config.PAYMENTS_NOWPAYMENTS_API_KEY
        raise ValueError(f"Unknown provider: {provider}")
    
    @staticmethod
    def get_amount_limits() -> tuple[float, float]:
        """Get min/max amount limits."""
        return (
            constance_config.PAYMENTS_MIN_AMOUNT_USD,
            constance_config.PAYMENTS_MAX_AMOUNT_USD
        )
    
    @staticmethod
    def is_provider_enabled(provider: str) -> bool:
        """Check if payment provider is enabled."""
        config = get_current_config()
        return getattr(config.payments, f'enable_{provider}', False)
```

## 🏷️ Metadata
**Tags**: `architecture, structure, patterns, layers, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Real Examples**: Payments, Knowbase, Agents apps from django-cfg
**DEPENDS_ON**: [django-cfg-core, pydantic]
**USED_BY**: [all-django-cfg-apps]
