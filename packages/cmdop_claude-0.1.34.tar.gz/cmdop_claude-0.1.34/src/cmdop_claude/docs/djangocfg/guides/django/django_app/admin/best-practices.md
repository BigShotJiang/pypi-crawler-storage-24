# 🏆 Best Practices %%PRIORITY:HIGH%%

## 🎯 Overview

Proven patterns and anti-patterns for building maintainable, performant admin interfaces with our Django-CFG admin system.

## ✅ Do's - Best Practices

### 1. Admin Class Structure %%PRIORITY:HIGH%%

**✅ DO: Follow consistent inheritance order**

```python
@admin.register(MyModel)
class MyModelAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    """Always: OptimizedModelAdmin → DisplayMixin → ModelAdmin"""
    
    # 1. Performance configuration
    select_related_fields = ['user', 'category']
    annotations = {'orders_count': Count('orders')}
    
    # 2. List configuration
    list_display = ['name_display', 'status_display', 'created_display']
    list_filter = ['status', 'created_at']
    search_fields = ['name', 'description']
    
    # 3. Display methods
    @display(description="Name", ordering="name")
    def name_display(self, obj):
        return obj.name
    
    # 4. Actions
    @action(description="Activate items", variant=ActionVariant.SUCCESS)
    def activate_items(self, request, queryset):
        # Action logic
        pass
```

**✅ DO: Use type hints on display methods**

```python
@display(description="User")
def user_display(self, obj: MyModel):
    """Type hints help with IDE support and debugging."""
    return self.display_user_simple(obj, 'user')
```

### 2. Performance Optimization %%PRIORITY:HIGH%%

**✅ DO: Always optimize queries**

```python
class OrderAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    # Automatic optimization
    select_related_fields = ['user', 'payment_method', 'shipping_address']
    annotations = {
        'items_count': Count('items'),
        'total_revenue': Sum('items__price')
    }
```

**✅ DO: Use prefetch_related for many-to-many**

```python
def get_queryset(self, request):
    return super().get_queryset(request).prefetch_related(
        'tags',
        'categories',
        'items__product'
    )
```

### 3. Display Methods %%PRIORITY:HIGH%%

**✅ DO: Use utility methods consistently**

```python
@display(description="Customer", header=True)
def customer_display(self, obj):
    """Use utility methods for consistency."""
    return self.display_user_with_avatar(obj, 'customer')

@display(description="Amount")
def amount_display(self, obj):
    """Configure utilities for specific needs."""
    config = MoneyDisplayConfig(
        currency="USD",
        show_sign=False,
        thousand_separator=True
    )
    return self.display_money_amount(obj, 'amount', config)
```

**✅ DO: Handle empty/null values gracefully**

```python
@display(description="Description", empty_value="No description")
def description_display(self, obj):
    """Use empty_value parameter for null handling."""
    return obj.description or None  # Returns "No description" if None
```

### 4. Actions %%PRIORITY:HIGH%%

**✅ DO: Use appropriate action variants**

```python
# SUCCESS: Positive actions
@action(description="Approve orders", variant=ActionVariant.SUCCESS)

# WARNING: Potentially destructive but reversible
@action(description="Archive orders", variant=ActionVariant.WARNING)

# DANGER: Destructive actions
@action(description="Delete permanently", variant=ActionVariant.DANGER)

# INFO: Informational actions
@action(description="Export data", variant=ActionVariant.INFO)
```

**✅ DO: Provide meaningful feedback**

```python
@action(description="Process orders", variant=ActionVariant.INFO)
def process_orders(self, request, queryset):
    processed = 0
    failed = 0
    
    for order in queryset:
        if order.can_be_processed():
            order.process()
            processed += 1
        else:
            failed += 1
    
    # Detailed feedback
    if processed > 0:
        self.message_user(
            request,
            f"Successfully processed {processed} orders.",
            messages.SUCCESS
        )
    
    if failed > 0:
        self.message_user(
            request,
            f"Could not process {failed} orders (invalid status).",
            messages.WARNING
        )
```

### 5. Configuration %%PRIORITY:HIGH%%

**✅ DO: Use Pydantic configs for type safety**

```python
# Type-safe configuration
config = StatusBadgeConfig(
    custom_mappings={
        'draft': 'secondary',
        'published': 'success',
        'archived': 'warning'
    },
    show_icons=True,
    icon=Icons.ARTICLE
)
```

**✅ DO: Reuse configurations**

```python
class BaseContentAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    """Base admin with shared configurations."""
    
    CONTENT_STATUS_CONFIG = StatusBadgeConfig(
        custom_mappings={
            'draft': 'secondary',
            'review': 'warning',
            'published': 'success',
            'archived': 'info'
        },
        show_icons=True
    )
    
    @display(description="Status", label=True)
    def status_display(self, obj):
        return self.display_status_auto(obj, 'status', self.CONTENT_STATUS_CONFIG)

class ArticleAdmin(BaseContentAdmin):
    """Inherits shared configuration."""
    pass

class PageAdmin(BaseContentAdmin):
    """Inherits shared configuration."""
    pass
```

## ❌ Don'ts - Anti-Patterns

### 1. Performance Anti-Patterns %%PRIORITY:HIGH%%

**❌ DON'T: Ignore query optimization**

```python
# BAD: No optimization, causes N+1 queries
class BadOrderAdmin(ModelAdmin):
    list_display = ['customer_name', 'total_amount']
    
    def customer_name(self, obj):
        return obj.customer.name  # N+1 query!
```

**❌ DON'T: Use complex queries in display methods**

```python
# BAD: Complex query in display method
@display(description="Revenue")
def revenue_display(self, obj):
    # This runs for every row!
    return obj.orders.aggregate(total=Sum('amount'))['total']

# GOOD: Use annotations instead
class GoodAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    annotations = {'total_revenue': Sum('orders__amount')}
    
    @display(description="Revenue")
    def revenue_display(self, obj):
        return self.display_money_amount(obj, 'total_revenue')
```

### 2. Display Anti-Patterns %%PRIORITY:HIGH%%

**❌ DON'T: Duplicate HTML in display methods**

```python
# BAD: HTML duplication
@display(description="Status")
def status_display(self, obj):
    if obj.is_active:
        return format_html(
            '<span class="badge badge-success">Active</span>'
        )
    return format_html(
        '<span class="badge badge-secondary">Inactive</span>'
    )

# GOOD: Use utilities
@display(description="Status", label=True)
def status_display(self, obj):
    return self.display_status_auto(obj, 'is_active')
```

**❌ DON'T: Mix unfold and our decorators**

```python
# BAD: Mixed imports
from unfold.decorators import display as unfold_display
from django_cfg.modules.django_admin import display

@unfold_display(description="Bad")  # Don't mix!
def bad_display(self, obj):
    return obj.name

# GOOD: Use our decorators consistently
@display(description="Good")
def good_display(self, obj):
    return obj.name
```

### 3. Action Anti-Patterns %%PRIORITY:HIGH%%

**❌ DON'T: Use string variants**

```python
# BAD: String variants (not type-safe)
@action(description="Bad action", variant="success")  # Type error!

# GOOD: Use ActionVariant enum
@action(description="Good action", variant=ActionVariant.SUCCESS)
```

**❌ DON'T: Ignore error handling**

```python
# BAD: No error handling
@action(description="Risky action", variant=ActionVariant.WARNING)
def risky_action(self, request, queryset):
    for item in queryset:
        item.risky_operation()  # Might fail and crash admin!

# GOOD: Let decorator handle errors or handle manually
@action(description="Safe action", variant=ActionVariant.WARNING)
def safe_action(self, request, queryset):
    success = 0
    failed = 0
    
    for item in queryset:
        try:
            item.risky_operation()
            success += 1
        except Exception:
            failed += 1
    
    self.message_user(
        request,
        f"Success: {success}, Failed: {failed}",
        messages.INFO
    )
```

### 4. Configuration Anti-Patterns

**❌ DON'T: Hardcode display configurations**

```python
# BAD: Hardcoded values
@display(description="Price")
def price_display(self, obj):
    return f"${obj.price:.2f}"  # Hardcoded currency and format

# GOOD: Use configuration
@display(description="Price")
def price_display(self, obj):
    config = MoneyDisplayConfig(currency="USD", decimal_places=2)
    return self.display_money_amount(obj, 'price', config)
```

**❌ DON'T: Create configurations in display methods**

```python
# BAD: Creating config every time
@display(description="Status")
def status_display(self, obj):
    config = StatusBadgeConfig(...)  # Created for every row!
    return self.display_status_auto(obj, 'status', config)

# GOOD: Create config once
class MyAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    STATUS_CONFIG = StatusBadgeConfig(...)  # Created once
    
    @display(description="Status")
    def status_display(self, obj):
        return self.display_status_auto(obj, 'status', self.STATUS_CONFIG)
```

## 🔧 Code Organization Patterns

### 1. Admin Module Structure

```python
# apps/myapp/admin/__init__.py
from .users_admin import UserAdmin
from .orders_admin import OrderAdmin
from .products_admin import ProductAdmin

# apps/myapp/admin/base.py
class BaseMyAppAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    """Base admin for MyApp with shared configurations."""
    
    # Shared configurations
    MONEY_CONFIG = MoneyDisplayConfig(currency="USD")
    STATUS_CONFIG = StatusBadgeConfig(show_icons=True)
    
    # Shared methods
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('created_by')

# apps/myapp/admin/users_admin.py
from .base import BaseMyAppAdmin

@admin.register(User)
class UserAdmin(BaseMyAppAdmin):
    """User admin inheriting shared configuration."""
    pass
```

### 2. Configuration Management

```python
# apps/myapp/admin/configs.py
from django_cfg.modules.django_admin import (
    StatusBadgeConfig,
    MoneyDisplayConfig,
    Icons
)

class AdminConfigs:
    """Centralized admin configurations."""
    
    ORDER_STATUS = StatusBadgeConfig(
        custom_mappings={
            'pending': 'warning',
            'processing': 'info',
            'completed': 'success',
            'cancelled': 'danger'
        },
        show_icons=True,
        icon=Icons.SHOPPING_CART
    )
    
    MONEY_USD = MoneyDisplayConfig(
        currency="USD",
        show_sign=False,
        thousand_separator=True
    )
    
    MONEY_EUR = MoneyDisplayConfig(
        currency="EUR",
        show_sign=False,
        thousand_separator=True
    )

# Usage in admin
from .configs import AdminConfigs

@display(description="Status", label=True)
def status_display(self, obj):
    return self.display_status_auto(obj, 'status', AdminConfigs.ORDER_STATUS)
```

## 🧪 Testing Patterns

### 1. Admin Display Testing

```python
# tests/test_admin.py
from django.test import TestCase
from django.contrib.admin.sites import AdminSite
from django.contrib.auth import get_user_model

from myapp.admin import OrderAdmin
from myapp.models import Order

User = get_user_model()

class OrderAdminTest(TestCase):
    def setUp(self):
        self.site = AdminSite()
        self.admin = OrderAdmin(Order, self.site)
        self.user = User.objects.create_user('test', 'test@example.com')
        self.order = Order.objects.create(
            user=self.user,
            total_amount=99.99,
            status='pending'
        )
    
    def test_status_display(self):
        """Test status display method."""
        result = self.admin.status_display(self.order)
        self.assertIn('pending', result.lower())
        self.assertIn('badge', result.lower())
    
    def test_user_display(self):
        """Test user display method."""
        result = self.admin.user_display(self.order)
        self.assertIn(self.user.email, str(result))
```

### 2. Action Testing

```python
def test_activate_action(self):
    """Test activate action."""
    request = self.factory.post('/')
    request.user = self.superuser
    
    queryset = Order.objects.filter(is_active=False)
    
    # Execute action
    self.admin.activate_items(request, queryset)
    
    # Check results
    self.assertTrue(
        Order.objects.filter(id__in=queryset.values_list('id', flat=True))
        .filter(is_active=True)
        .exists()
    )
```

## 🚀 Performance Tips

### 1. Query Optimization

```python
# Use select_related for ForeignKey
select_related_fields = ['user', 'category', 'payment_method']

# Use prefetch_related for ManyToMany and reverse ForeignKey
def get_queryset(self, request):
    return super().get_queryset(request).prefetch_related(
        'tags',
        'items__product',
        'user__groups'
    )

# Use annotations for computed fields
annotations = {
    'items_count': Count('items'),
    'total_revenue': Sum('items__price'),
    'avg_rating': Avg('reviews__rating')
}
```

### 2. Display Optimization

```python
# Cache expensive computations
@display(description="Complex Calculation")
def complex_display(self, obj):
    # Use Django's cache framework for expensive operations
    from django.core.cache import cache
    
    cache_key = f"complex_calc_{obj.id}"
    result = cache.get(cache_key)
    
    if result is None:
        result = obj.expensive_calculation()
        cache.set(cache_key, result, 300)  # 5 minutes
    
    return result
```

## 🏷️ Migration Checklist

When migrating from vanilla Django admin:

- [ ] Replace `django.contrib.admin.ModelAdmin` with our stack
- [ ] Move HTML generation to utility methods
- [ ] Replace hardcoded strings with Pydantic configurations
- [ ] Add query optimization with `select_related_fields`
- [ ] Update action decorators to use `ActionVariant`
- [ ] Add type hints to display methods
- [ ] Test all display methods and actions
- [ ] Update imports to use our decorators

## 🏷️ Metadata
**Tags**: `best-practices, patterns, anti-patterns, performance, testing`
**Status**: %%ACTIVE%%
**Complexity**: %%ADVANCED%%
**Dependencies**: [django-cfg.modules.django_admin]
