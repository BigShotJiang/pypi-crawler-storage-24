# 🚀 Quick Start Guide %%PRIORITY:HIGH%%

## 🎯 5-Minute Setup

Get a modern, type-safe admin interface running in 5 minutes.

## 📦 Installation

```python
# Already included in django-cfg
from django_cfg.modules.django_admin import *
```

## 🔧 Basic Admin

### 1. Simple Model Admin

```python
from django.contrib import admin
from unfold.admin import ModelAdmin
from django_cfg.modules.django_admin import (
    OptimizedModelAdmin,
    DisplayMixin,
    display
)

@admin.register(Product)
class ProductAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    """Basic product admin with optimization."""
    
    # Automatic query optimization
    select_related_fields = ['category', 'brand']
    
    list_display = ['name', 'price_display', 'status_display']
    list_filter = ['is_active', 'category']
    search_fields = ['name', 'description']
    
    @display(description="Price")
    def price_display(self, obj):
        return self.display_money_amount(obj, 'price')
    
    @display(description="Status", label=True)
    def status_display(self, obj):
        return self.display_status_auto(obj, 'is_active')
```

### 2. Advanced Admin with Actions

```python
from django_cfg.modules.django_admin import (
    OptimizedModelAdmin,
    DisplayMixin,
    StatusBadgeConfig,
    Icons,
    ActionVariant,
    display,
    action
)

@admin.register(Order)
class OrderAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    """Advanced order admin with custom actions."""
    
    # Performance optimization
    select_related_fields = ['user', 'payment']
    annotations = {
        'items_count': Count('items')
    }
    
    list_display = [
        'order_number_display',
        'user_display', 
        'total_display',
        'status_display',
        'items_count_display'
    ]
    
    @display(description="Order #")
    def order_number_display(self, obj):
        from django_cfg.modules.django_admin.utils.badges import StatusBadge
        return StatusBadge.create(
            text=f"#{obj.order_number}",
            variant="info"
        )
    
    @display(description="User", header=True)
    def user_display(self, obj):
        return self.display_user_with_avatar(obj, 'user')
    
    @display(description="Total")
    def total_display(self, obj):
        return self.display_money_amount(obj, 'total_amount')
    
    @display(description="Status", label=True)
    def status_display(self, obj):
        config = StatusBadgeConfig(
            custom_mappings={
                'pending': 'warning',
                'processing': 'info',
                'completed': 'success',
                'cancelled': 'danger'
            },
            show_icons=True
        )
        return self.display_status_auto(obj, 'status', config)
    
    @display(description="Items")
    def items_count_display(self, obj):
        return self.display_count_simple(obj, 'items_count', 'items')
    
    # Custom actions
    @action(description="Mark as completed", variant=ActionVariant.SUCCESS)
    def mark_completed(self, request, queryset):
        updated = queryset.update(status='completed')
        self.message_user(request, f"Marked {updated} orders as completed.")
    
    @action(description="Cancel orders", variant=ActionVariant.DANGER)
    def cancel_orders(self, request, queryset):
        updated = queryset.update(status='cancelled')
        self.message_user(request, f"Cancelled {updated} orders.")
```

## 🎨 Display Utilities

### Money Display

```python
from django_cfg.modules.django_admin import MoneyDisplayConfig

@display(description="Price")
def price_display(self, obj):
    config = MoneyDisplayConfig(
        currency="USD",
        show_sign=False,
        thousand_separator=True,
        decimal_places=2
    )
    return self.display_money_amount(obj, 'price', config)
```

### User Display

```python
@display(description="Customer", header=True)
def customer_display(self, obj):
    # Automatically shows avatar, name, and email
    return self.display_user_with_avatar(obj, 'customer')
```

### Status Display

```python
@display(description="Status", label=True)
def status_display(self, obj):
    # Automatic color mapping based on status value
    return self.display_status_auto(obj, 'status')
```

### DateTime Display

```python
from django_cfg.modules.django_admin import DateTimeDisplayConfig

@display(description="Created")
def created_display(self, obj):
    config = DateTimeDisplayConfig(
        show_relative=True,
        show_seconds=False
    )
    return self.display_datetime_relative(obj, 'created_at', config)
```

## 🎯 Actions

### Basic Actions

```python
@action(description="Activate items", variant=ActionVariant.SUCCESS)
def activate_items(self, request, queryset):
    updated = queryset.update(is_active=True)
    self.message_user(request, f"Activated {updated} items.")

@action(description="Archive items", variant=ActionVariant.WARNING)
def archive_items(self, request, queryset):
    updated = queryset.update(is_archived=True)
    self.message_user(request, f"Archived {updated} items.")
```

### Actions with Error Handling

```python
@action(description="Process orders", variant=ActionVariant.INFO)
def process_orders(self, request, queryset):
    """Actions automatically handle errors and logging."""
    processed = 0
    for order in queryset:
        if order.can_be_processed():
            order.process()
            processed += 1
    
    self.message_user(
        request, 
        f"Processed {processed} out of {queryset.count()} orders."
    )
```

## 🔧 Performance Optimization

### Automatic Query Optimization

```python
class MyAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    # Automatically adds select_related()
    select_related_fields = ['user', 'category', 'brand']
    
    # Automatically adds annotations
    annotations = {
        'orders_count': Count('orders'),
        'total_spent': Sum('orders__total')
    }
```

### Manual Optimization

```python
def get_queryset(self, request):
    """Custom queryset optimization."""
    return super().get_queryset(request).prefetch_related(
        'tags',
        'images'
    ).annotate(
        avg_rating=Avg('reviews__rating')
    )
```

## 🎨 Material Icons

```python
from django_cfg.modules.django_admin import Icons

# Use in badges
StatusBadge.create(
    text="Active",
    variant="success",
    config=StatusBadgeConfig(
        show_icons=True,
        icon=Icons.CHECK_CIRCLE
    )
)

# Use in actions
@action(
    description="Export data", 
    variant=ActionVariant.INFO,
    icon=Icons.DOWNLOAD
)
def export_data(self, request, queryset):
    # Export logic
    pass
```

## 🏷️ Next Steps

1. **[Core Components](./core-components.md)** - Understand the architecture
2. **[Display System](./display-system.md)** - Master display utilities
3. **[Best Practices](./best-practices.md)** - Learn patterns and anti-patterns

## 🏷️ Metadata
**Tags**: `quick-start, tutorial, admin, unfold`
**Status**: %%ACTIVE%%
**Complexity**: %%BEGINNER%%
**Time**: 5 minutes