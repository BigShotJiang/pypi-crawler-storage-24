# 🎓 Universal Testing Principles for Documentation

## 📚 Key Lessons from Django-CFG Experience

### 1. **Code-First Documentation Principle**
When documenting testing practices, always base examples on **real, working code** rather than theoretical implementations.

```python
# ❌ DON'T: Document imaginary APIs
"""
Example: Testing payment creation
payment = PaymentService.create_payment(amount=100)  # Method doesn't exist!
"""

# ✅ DO: Document actual APIs
"""
Example: Testing payment creation (based on real PaymentService)
result = PaymentService.create_payment_request(
    user_id=1, 
    amount_usd=100.0, 
    currency_code="BTC"
)
assert result.success
"""
```

### 2. **Verification Before Documentation**
Always verify that documented patterns work in the actual codebase:

```bash
# Before documenting a testing pattern:
# 1. Implement it in real tests
# 2. Run the tests to ensure they pass
# 3. Then document the working pattern

# Example verification workflow:
cd /path/to/project
python -m django test app.tests.test_example --verbosity=2
# Only document patterns that actually work
```

### 3. **Evolution-Aware Documentation**
Document testing patterns that account for code evolution:

```python
# ✅ Flexible testing patterns that adapt to changes
class AdaptiveTestCase(TestCase):
    def setUp(self):
        # Use introspection to discover actual methods
        service_methods = [method for method in dir(PaymentService) 
                          if not method.startswith('_')]
        self.available_methods = service_methods
    
    def test_available_methods_only(self):
        # Test only methods that actually exist
        if 'create_payment_request' in self.available_methods:
            result = self.service.create_payment_request(...)
            self.assertTrue(result.success)
```

### 4. **Multi-Level Testing Documentation**
Document testing at different architectural levels:

```python
# Level 1: Unit Tests (individual methods)
class UnitTestExample(TestCase):
    def test_single_method(self):
        result = manager.get_or_create_for_user(user=self.user)
        self.assertIsNotNone(result)

# Level 2: Integration Tests (multiple components)  
class IntegrationTestExample(TestCase):
    def test_service_with_manager(self):
        result = service.create_payment_request(user_id=1, amount_usd=100)
        # Verify both service and manager interactions
        self.assertTrue(result.success)
        self.assertTrue(UserBalance.objects.filter(user_id=1).exists())

# Level 3: System Tests (full workflows)
class SystemTestExample(TestCase):
    def test_complete_payment_flow(self):
        # Test entire payment workflow from API to database
        response = self.client.post('/api/payments/', data={...})
        self.assertEqual(response.status_code, 201)
        # Verify all side effects
```

### 5. **Error-Driven Documentation**
Document common testing mistakes and their solutions:

```python
# Common Error: IntegrityError in tests
"""
Problem: NOT NULL constraint failed: payments_networks.native_currency_id

Root Cause: Test setup missing required foreign key relationships

Solution: Always create dependent objects first:
"""
def setUp(self):
    self.currency = Currency.objects.create(code="BTC", name="Bitcoin")
    self.network = Network.objects.create(
        code="bitcoin", 
        name="Bitcoin Network",
        native_currency=self.currency  # Required!
    )
```

### 6. **Database-Aware Testing Patterns**
Document testing patterns that respect database constraints:

```python
# ✅ Database-aware test setup
class DatabaseAwareTest(TestCase):
    def setUp(self):
        # Create objects in dependency order
        self.currency = Currency.objects.create(...)
        self.network = Network.objects.create(native_currency=self.currency)
        self.user = User.objects.create_user(...)
        self.balance = UserBalance.objects.get_or_create_for_user(self.user)
    
    def test_with_proper_relationships(self):
        # All foreign keys are satisfied
        payment = UniversalPayment.objects.create(
            user=self.user,
            network=self.network,
            amount_usd=100.0
        )
        self.assertIsNotNone(payment.id)
```

## 🔧 Documentation Maintenance Principles

### 1. **Living Documentation**
Keep testing documentation synchronized with code changes:

```python
# Add version comments to track documentation currency
"""
Testing Pattern: PaymentService (v2.1.0)
Last Updated: 2025-09-26
Verified Against: django-cfg payments app

Methods Available:
- create_payment_request() ✅ Tested
- get_user_payments() ✅ Tested  
- get_payment_status() ✅ Tested
- process_completed_payment() ❌ Method removed in v2.1.0
"""
```

### 2. **Executable Documentation**
Write documentation that can be executed as tests:

```python
# Documentation that doubles as working tests
class DocumentationTest(TestCase):
    """
    This test class serves as executable documentation
    for the PaymentService testing patterns.
    """
    
    def test_documented_payment_creation_pattern(self):
        """
        Documented Pattern: Creating payments with proper validation
        
        This pattern ensures all required fields are provided
        and demonstrates the correct service method usage.
        """
        result = self.service.create_payment_request(
            user_id=self.user.id,
            amount_usd=100.0,
            currency_code="BTC"
        )
        
        # This assertion validates both the pattern and the implementation
        self.assertTrue(result.success)
        self.assertIn('payment_id', result.data)
```

### 3. **Cross-Reference Validation**
Document testing patterns with references to actual code:

```markdown
## Testing PaymentService

Reference Implementation: `src/django_cfg/apps/payments/services/core/payment_service.py`

### Available Methods (verified 2025-09-26):
- `create_payment_request(user_id, amount_usd, currency_code)` → Line 45
- `get_user_payments(user_id, status=None)` → Line 120  
- `get_payment_status(payment_id)` → Line 200

### Test Example:
```python
# This example references actual method signatures
result = PaymentService().create_payment_request(
    user_id=1,           # Required: int
    amount_usd=100.0,    # Required: float  
    currency_code="BTC"  # Required: str from SUPPORTED_CURRENCIES
)
```

## 🎯 Documentation Quality Gates

1. **Accuracy Gate**: All documented patterns must work in actual codebase
2. **Currency Gate**: Documentation must be updated when referenced code changes
3. **Completeness Gate**: Cover both success and failure scenarios
4. **Maintainability Gate**: Patterns should be easy to update when code evolves

This approach ensures that testing documentation remains a valuable, accurate resource that developers can trust and rely upon.
