# 🏗️ Core Components %%PRIORITY:HIGH%%

## 🎯 Architecture Overview

Our admin system is built in layers, each providing specific functionality while maintaining clean separation of concerns.

## 📦 Component Stack

```
┌─────────────────────────────────────┐
│           Your Admin Class          │  ← Business Logic
├─────────────────────────────────────┤
│            DisplayMixin             │  ← Display Utilities
├─────────────────────────────────────┤
│        OptimizedModelAdmin          │  ← Performance Layer
├─────────────────────────────────────┤
│        unfold.admin.ModelAdmin      │  ← UI/UX Layer
├─────────────────────────────────────┤
│      django.contrib.admin.ModelAdmin │  ← Django Core
└─────────────────────────────────────┘
```

## 🔧 OptimizedModelAdmin %%PRIORITY:HIGH%%

**Purpose**: Automatic query optimization and performance enhancements.

**Location**: `django_cfg.modules.django_admin.mixins.optimization_mixin`

### Features

- **Automatic select_related()** based on `select_related_fields`
- **Automatic annotations** based on `annotations` dict
- **Query optimization** for list and detail views
- **Performance monitoring** (optional)

### Usage

```python
from django_cfg.modules.django_admin import OptimizedModelAdmin

class MyAdmin(OptimizedModelAdmin):
    # Automatically adds select_related('user', 'category')
    select_related_fields = ['user', 'category']
    
    # Automatically adds annotations
    annotations = {
        'orders_count': Count('orders'),
        'total_revenue': Sum('orders__total')
    }
```

### Implementation Details

```python
class OptimizedModelAdmin(admin.ModelAdmin):
    """Performance-optimized ModelAdmin base class."""
    
    select_related_fields: List[str] = []
    annotations: Dict[str, Any] = {}
    
    def get_queryset(self, request):
        """Apply optimizations to queryset."""
        queryset = super().get_queryset(request)
        
        # Apply select_related
        if self.select_related_fields:
            queryset = queryset.select_related(*self.select_related_fields)
        
        # Apply annotations
        if self.annotations:
            queryset = queryset.annotate(**self.annotations)
        
        return queryset
```

## 🎨 DisplayMixin %%PRIORITY:HIGH%%

**Purpose**: Utility methods for display functions with type-safe configuration.

**Location**: `django_cfg.modules.django_admin.mixins.display_mixin`

### Core Methods

#### User Display

```python
def display_user_with_avatar(self, obj, user_field='user', config=None):
    """Display user with avatar for @display(header=True)."""
    user = getattr(obj, user_field, None)
    return UserDisplay.with_avatar(user, config)

def display_user_simple(self, obj, user_field='user', config=None):
    """Simple user display without avatar."""
    user = getattr(obj, user_field, None)
    return UserDisplay.simple(user, config)
```

#### Money Display

```python
def display_money_amount(self, obj, amount_field, config=None):
    """Display money amount with currency formatting."""
    amount = getattr(obj, amount_field, None)
    return MoneyDisplay.amount(amount, config)

def display_money_breakdown(self, obj, main_field, breakdown_fields, config=None):
    """Display money with breakdown (total, tax, fees, etc.)."""
    # Implementation details...
```

#### Status Display

```python
def display_status_auto(self, obj, status_field='status', config=None):
    """Display status with automatic color mapping."""
    status = getattr(obj, status_field, '')
    return StatusBadge.auto(status, config)
```

#### DateTime Display

```python
def display_datetime_relative(self, obj, datetime_field, config=None):
    """Display datetime with relative time ('2 hours ago')."""
    dt = getattr(obj, datetime_field, None)
    return DateTimeDisplay.relative(dt, config)

def display_datetime_compact(self, obj, datetime_field, config=None):
    """Display datetime in compact format."""
    dt = getattr(obj, datetime_field, None)
    return DateTimeDisplay.compact(dt, config)
```

#### Count Display

```python
def display_count_simple(self, obj, count_field, label=None):
    """Display count as badge."""
    count = getattr(obj, count_field, 0)
    return CounterBadge.simple(count, label)

def display_related_count(self, obj, related_name, label=None):
    """Display count of related objects."""
    # Handles related manager counting
```

## 🎯 Custom Decorators %%PRIORITY:HIGH%%

### @display Decorator

**Purpose**: Enhanced display decorator with error handling and HTML safety.

```python
from django_cfg.modules.django_admin import display

@display(description="Status", label=True, empty_value="—")
def status_display(self, obj):
    """Automatically handles errors and HTML safety."""
    return self.display_status_auto(obj, 'status')
```

**Features**:
- **Error handling**: Catches exceptions and returns safe fallback
- **HTML safety**: Automatically marks HTML as safe
- **Empty value handling**: Configurable empty value display
- **Unfold integration**: Passes through to unfold.decorators.display

### @action Decorator

**Purpose**: Type-safe action decorator with our ActionVariant enum.

```python
from django_cfg.modules.django_admin import action, ActionVariant

@action(description="Activate items", variant=ActionVariant.SUCCESS)
def activate_items(self, request, queryset):
    """Automatically handles errors and logging."""
    updated = queryset.update(is_active=True)
    self.message_user(request, f"Activated {updated} items.")
```

**Features**:
- **Type safety**: Only accepts our ActionVariant enum
- **Error handling**: Catches exceptions and shows user messages
- **Logging**: Automatic error logging
- **Unfold integration**: Maps to unfold.enums.ActionVariant

## 🔧 Configuration Models %%PRIORITY:HIGH%%

### Pydantic 2 Models

All configuration uses Pydantic 2 for type safety and validation.

#### StatusBadgeConfig

```python
from django_cfg.modules.django_admin import StatusBadgeConfig

config = StatusBadgeConfig(
    custom_mappings={
        'pending': 'warning',
        'completed': 'success',
        'failed': 'danger'
    },
    show_icons=True,
    icon=Icons.CHECK_CIRCLE
)
```

#### MoneyDisplayConfig

```python
from django_cfg.modules.django_admin import MoneyDisplayConfig

config = MoneyDisplayConfig(
    currency="USD",
    show_sign=False,
    decimal_places=2,
    thousand_separator=True
)
```

#### UserDisplayConfig

```python
from django_cfg.modules.django_admin import UserDisplayConfig

config = UserDisplayConfig(
    show_email=True,
    show_avatar=True,
    avatar_size=32
)
```

#### DateTimeDisplayConfig

```python
from django_cfg.modules.django_admin import DateTimeDisplayConfig

config = DateTimeDisplayConfig(
    show_relative=True,
    show_seconds=False,
    datetime_format="%Y-%m-%d %H:%M:%S"
)
```

#### ActionVariant Enum

```python
from django_cfg.modules.django_admin import ActionVariant

# Available variants (matches unfold exactly)
ActionVariant.DEFAULT    # "default"
ActionVariant.PRIMARY    # "primary"  
ActionVariant.SUCCESS    # "success"
ActionVariant.INFO       # "info"
ActionVariant.WARNING    # "warning"
ActionVariant.DANGER     # "danger"
```

## 🎨 Utility Classes

### StatusBadge

```python
from django_cfg.modules.django_admin.utils.badges import StatusBadge

# Automatic status mapping
badge = StatusBadge.auto("pending")  # Returns warning badge

# Custom badge
badge = StatusBadge.create(
    text="Custom Status",
    variant="success",
    config=StatusBadgeConfig(show_icons=True, icon=Icons.CHECK)
)
```

### MoneyDisplay

```python
from django_cfg.modules.django_admin.utils.displays import MoneyDisplay

# Simple amount
display = MoneyDisplay.amount(
    amount=99.99,
    config=MoneyDisplayConfig(currency="USD")
)

# With breakdown
display = MoneyDisplay.with_breakdown(
    main_amount=99.99,
    breakdown_items=[
        {'label': 'Tax', 'amount': 9.99, 'color': 'warning'},
        {'label': 'Fee', 'amount': 2.50, 'color': 'info'}
    ]
)
```

### UserDisplay

```python
from django_cfg.modules.django_admin.utils.displays import UserDisplay

# With avatar (returns list for header=True)
display = UserDisplay.with_avatar(user, config)

# Simple display
display = UserDisplay.simple(user, config)
```

## 🔍 Material Icons Integration

### Icons Class

```python
from django_cfg.modules.django_admin import Icons

# Common icons
Icons.CHECK_CIRCLE      # "check_circle"
Icons.WARNING           # "warning"
Icons.ERROR             # "error"
Icons.INFO              # "info"
Icons.STAR              # "star"
Icons.PERSON            # "person"
Icons.PAYMENT           # "payment"
Icons.DOWNLOAD          # "download"
# ... 2000+ more icons
```

### Usage in Components

```python
# In badges
config = StatusBadgeConfig(
    show_icons=True,
    icon=Icons.CHECK_CIRCLE
)

# In actions
@action(
    description="Export data",
    variant=ActionVariant.INFO,
    icon=Icons.DOWNLOAD
)
def export_data(self, request, queryset):
    pass
```

## 🏷️ Integration Pattern

### Complete Admin Example

```python
from django.contrib import admin
from unfold.admin import ModelAdmin
from django_cfg.modules.django_admin import (
    OptimizedModelAdmin,
    DisplayMixin,
    StatusBadgeConfig,
    MoneyDisplayConfig,
    Icons,
    ActionVariant,
    display,
    action
)

@admin.register(Order)
class OrderAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    """Complete example showing all components."""
    
    # Performance layer
    select_related_fields = ['user', 'payment_method']
    annotations = {'items_count': Count('items')}
    
    # Unfold configuration
    list_display = ['order_display', 'user_display', 'total_display', 'status_display']
    list_filter = ['status', 'created_at']
    search_fields = ['order_number', 'user__email']
    
    # Display utilities
    @display(description="Order", ordering="order_number")
    def order_display(self, obj):
        return f"#{obj.order_number}"
    
    @display(description="Customer", header=True)
    def user_display(self, obj):
        return self.display_user_with_avatar(obj, 'user')
    
    @display(description="Total")
    def total_display(self, obj):
        return self.display_money_amount(obj, 'total_amount')
    
    @display(description="Status", label=True)
    def status_display(self, obj):
        config = StatusBadgeConfig(
            custom_mappings={'pending': 'warning', 'completed': 'success'},
            show_icons=True
        )
        return self.display_status_auto(obj, 'status', config)
    
    # Custom actions
    @action(description="Mark completed", variant=ActionVariant.SUCCESS)
    def mark_completed(self, request, queryset):
        updated = queryset.update(status='completed')
        self.message_user(request, f"Completed {updated} orders.")
```

## 🏷️ Metadata
**Tags**: `architecture, components, mixins, decorators, type-safety`
**Status**: %%ACTIVE%%
**Complexity**: %%ADVANCED%%
**Dependencies**: [unfold, pydantic>=2.0]
