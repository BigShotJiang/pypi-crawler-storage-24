# ⚙️ Django-CFG Configuration Management %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Three-layer configuration system**: Pydantic static config + Constance dynamic settings + Environment detection
- **Type-safe access patterns** with proper initialized config usage
- **Modular Constance integration** with automatic field collection from apps
- **Real examples** from payments, knowbase, and core configuration

## 📋 Table of Contents
1. [Configuration Philosophy](#configuration-philosophy)
2. [Real Configuration Examples](#real-configuration-examples)
3. [Constance Integration](#constance-integration)
4. [Config Access Patterns](#config-access-patterns)
5. [Environment Management](#environment-management)

## 🔑 Key Concepts at a Glance
- **Initialized Config Access**: Always use `get_current_config()` not new instances
- **Constance for Runtime**: Dynamic settings that admins can change
- **Pydantic for Static**: Type-safe configuration with validation
- **Environment Awareness**: Automatic sandbox/production detection
- **Centralized Management**: Single source of truth for all config

## 🚀 Quick Start

### Basic Configuration Access
```python
# ✅ CORRECT: Access initialized config
from django_cfg.core.config import get_current_config

config = get_current_config()
payments_config = config.payments

# ✅ CORRECT: Constance for runtime settings
from constance import config as constance_config
api_key = constance_config.PAYMENTS_NOWPAYMENTS_API_KEY

# ❌ WRONG: Creating new instances
payments_config = PaymentsConfig()  # Don't do this!
```

## 🏛️ Configuration Philosophy

### 1. **Three-Layer Configuration System**
```
┌─────────────────────┐
│   Constance Layer   │ ← Runtime settings (API keys, limits)
├─────────────────────┤
│   Pydantic Layer    │ ← Static config (structure, defaults)
├─────────────────────┤
│  Environment Layer  │ ← Auto-detection (dev/staging/prod)
└─────────────────────┘
```

### 2. **Configuration Responsibilities**
- **Pydantic Config**: Structure, defaults, validation, type safety
- **Constance Settings**: Runtime values, API keys, feature toggles
- **Environment Detection**: Automatic mode switching, smart defaults

### 3. **Access Patterns**
```python
# ✅ CORRECT: Layered access
from django_cfg.core.config import get_current_config
from constance import config as constance_config

# Static configuration (structure)
config = get_current_config()
payments_enabled = config.payments.enabled

# Dynamic settings (runtime values)
api_key = constance_config.PAYMENTS_NOWPAYMENTS_API_KEY
rate_limit = constance_config.PAYMENTS_RATE_LIMIT

# Combined access (recommended pattern)
class PaymentService:
    def __init__(self):
        self.config = get_current_config().payments
        self.api_key = constance_config.PAYMENTS_NOWPAYMENTS_API_KEY
```

## 🔍 Real Configuration Examples

### 1. **Payments Configuration Manager (Real Example)**
```python
# config/django_cfg_integration.py - Real pattern from payments app
from typing import Optional
from django_cfg.core.config import get_current_config
from django_cfg.modules.django_logger import get_logger

logger = get_logger("payments_django_cfg_integration")

class PaymentsConfigManager:
    """Central manager for payments configuration access."""
    
    _payments_config_cache: Optional[any] = None
    _cache_timestamp: float = 0
    _cache_ttl: float = 60.0  # Cache for 60 seconds
    
    @classmethod
    def get_payments_config(cls, force_refresh: bool = False):
        """Get payments configuration from django-cfg."""
        import time
        
        current_time = time.time()
        
        # Check if cache is valid
        if (not force_refresh and 
            cls._payments_config_cache is not None and 
            (current_time - cls._cache_timestamp) < cls._cache_ttl):
            return cls._payments_config_cache
        
        # Load fresh config
        try:
            current_config = get_current_config()
            if current_config and hasattr(current_config, 'payments'):
                cls._payments_config_cache = current_config.payments
                cls._cache_timestamp = current_time
                logger.debug("Loaded PaymentsConfig from django-cfg")
                return cls._payments_config_cache
            else:
                error_msg = "PaymentsConfig not found in current django-cfg config"
                logger.error(error_msg)
                raise ValueError(error_msg)
                
        except Exception as e:
            logger.error(f"Failed to load payments config: {e}")
            raise
    
    @classmethod
    def get_payments_config_safe(cls, force_refresh: bool = False):
        """Get payments configuration with fallback to defaults."""
        try:
            return cls.get_payments_config(force_refresh=force_refresh)
        except Exception as e:
            logger.warning(f"Using default PaymentsConfig due to error: {e}")
            from django_cfg.models.payments import PaymentsConfig
            return PaymentsConfig()

# Public API functions
def get_payments_config(safe: bool = True, force_refresh: bool = False):
    """Get payments configuration from django-cfg."""
    if safe:
        return PaymentsConfigManager.get_payments_config_safe(force_refresh=force_refresh)
    else:
        return PaymentsConfigManager.get_payments_config(force_refresh=force_refresh)
```

### 2. **Constance Settings Integration (Real Example)**
```python
# config/constance/settings.py - Real pattern from payments app
from typing import Dict, Any
from pydantic import BaseModel, Field

class PaymentConstanceSettings(BaseModel):
    """Pydantic model for payments Constance settings."""
    
    # Provider settings (sensitive data in Constance)
    nowpayments_api_key: str = Field(default="", description="NowPayments API key")
    nowpayments_ipn_secret: str = Field(default="", description="NowPayments IPN secret")
    nowpayments_sandbox_mode: bool = Field(default=True, description="NowPayments sandbox mode")
    
    # Feature toggles (dynamic settings)
    track_anonymous_usage: bool = Field(default=False, description="Track anonymous usage")
    auto_update_rates: bool = Field(default=True, description="Auto update currency rates")
    rate_update_interval_hours: int = Field(default=1, description="Rate update interval")
    
    @classmethod
    def from_constance(cls) -> 'PaymentConstanceSettings':
        """Create instance from Constance settings."""
        try:
            from constance import config
            from ..django_cfg_integration import PaymentsConfigManager
            
            # Get static config from Pydantic
            pydantic_config = PaymentsConfigManager.get_payments_config()
            
            return cls(
                # Dynamic settings from Constance
                nowpayments_api_key=getattr(config, 'PAYMENTS_NOWPAYMENTS_API_KEY', ''),
                nowpayments_ipn_secret=getattr(config, 'PAYMENTS_NOWPAYMENTS_IPN_SECRET', ''),
                nowpayments_sandbox_mode=getattr(config, 'PAYMENTS_NOWPAYMENTS_SANDBOX_MODE', True),
                track_anonymous_usage=getattr(config, 'PAYMENTS_TRACK_ANONYMOUS_USAGE', False),
                
                # Static settings from Pydantic (with fallbacks)
                auto_update_rates=True,  # Always automatic
                rate_update_interval_hours=1,  # Fixed interval
            )
        except ImportError:
            logger.warning("Constance not available, using default settings")
            return cls()
    
    def get_provider_config(self, provider: str) -> Dict[str, Any]:
        """Get provider-specific configuration."""
        if provider.lower() == 'nowpayments':
            is_enabled = bool(self.nowpayments_api_key and self.nowpayments_api_key.strip())
            return {
                'enabled': is_enabled,
                'api_key': self.nowpayments_api_key,
                'ipn_secret': self.nowpayments_ipn_secret,
                'sandbox_mode': self.nowpayments_sandbox_mode,
            }
        return {}

def get_payment_settings() -> PaymentConstanceSettings:
    """Get current payment settings from Constance."""
    return PaymentConstanceSettings.from_constance()
```

### 3. **Modular Constance Fields (Real Example)**
```python
# config/constance/fields.py - Real pattern from knowbase app
from typing import List
from django_cfg.models.constance import ConstanceField

def get_knowbase_constance_fields() -> List[ConstanceField]:
    """Get Constance fields for Knowbase app."""
    return [
        # Text processing settings
        ConstanceField(
            key="KNOWBASE_CHUNK_SIZE",
            default=1000,
            help_text="Default chunk size for text processing",
            field_type="int",
            group="Text Processing"
        ),
        ConstanceField(
            key="KNOWBASE_CHUNK_OVERLAP",
            default=200,
            help_text="Overlap between text chunks",
            field_type="int",
            group="Text Processing"
        ),
        
        # AI/LLM settings
        ConstanceField(
            key="KNOWBASE_OPENAI_API_KEY",
            default="",
            help_text="OpenAI API key for embeddings",
            field_type="str",
            group="AI Settings"
        ),
        ConstanceField(
            key="KNOWBASE_EMBEDDING_MODEL",
            default="text-embedding-ada-002",
            help_text="OpenAI embedding model to use",
            field_type="str",
            group="AI Settings"
        ),
        
        # Search settings
        ConstanceField(
            key="KNOWBASE_SEARCH_RESULTS_LIMIT",
            default=10,
            help_text="Maximum number of search results",
            field_type="int",
            group="Search"
        ),
        ConstanceField(
            key="KNOWBASE_SIMILARITY_THRESHOLD",
            default=0.7,
            help_text="Minimum similarity score for search results",
            field_type="float",
            group="Search"
        ),
    ]
```

## 🔧 Constance Integration

### 1. **Automatic Field Collection**
```python
# models/constance.py - Real implementation from django-cfg core
class ConstanceConfig(BaseModel, BaseCfgAutoModule):
    """Django Constance configuration with automatic field collection."""
    
    fields: List[ConstanceField] = Field(
        default_factory=list,
        description="List of Constance fields"
    )
    
    def _get_app_constance_fields(self) -> List[ConstanceField]:
        """Automatically collect constance fields from django-cfg apps."""
        all_fields = []
        
        # Import and collect fields from each app
        app_field_functions = [
            ('knowbase', 'django_cfg.apps.knowbase.config.constance_fields', 'get_knowbase_constance_fields'),
            ('payments', 'django_cfg.apps.payments.config.constance.fields', 'get_payments_constance_fields'),
            ('agents', 'django_cfg.apps.agents.config.constance_fields', 'get_agents_constance_fields'),
        ]
        
        for app_name, module_path, function_name in app_field_functions:
            try:
                module = importlib.import_module(module_path)
                get_fields_func = getattr(module, function_name)
                app_fields = get_fields_func()
                all_fields.extend(app_fields)
                logger.debug(f"Loaded {len(app_fields)} Constance fields from {app_name}")
            except (ImportError, AttributeError) as e:
                logger.debug(f"Could not load Constance fields from {app_name}: {e}")
        
        return all_fields
    
    def to_django_settings(self) -> Dict[str, Any]:
        """Generate Django settings for Constance."""
        all_fields = self.get_all_fields()
        if not all_fields:
            return {}

        settings = {
            "CONSTANCE_CONFIG": self.get_config_dict(),
            "CONSTANCE_FIELDSETS": self.get_fieldsets_dict(),
            "CONSTANCE_CONFIG_FIELDSETS": self.get_fieldsets_dict(),
            "CONSTANCE_BACKEND": "constance.backends.database.DatabaseBackend",
            "CONSTANCE_ADDITIONAL_FIELDS": self.get_additional_fields_dict(),
            "CONSTANCE_IGNORE_ADMIN_VERSION_CHECK": True,
        }
        
        return {k: v for k, v in settings.items() if v is not None}
```

### 2. **Unfold Admin Integration**
```python
# apps.py - Real implementation from django-cfg core
class DjangoCfgConfig(AppConfig):
    """Configuration for django_cfg app."""
    
    def ready(self):
        """Called when Django is ready - register integrations."""
        self._register_constance_admin()
    
    def _register_constance_admin(self):
        """Register Constance admin with Unfold integration."""
        try:
            # Check if Constance is configured
            if not (hasattr(settings, 'CONSTANCE_CONFIG') and settings.CONSTANCE_CONFIG):
                return
            
            # Import required modules
            from constance.admin import Config, ConstanceAdmin
            from unfold.admin import ModelAdmin

            # Create custom admin class with Unfold styling
            class ConstanceConfigAdmin(ConstanceAdmin, ModelAdmin):
                """Constance admin with Unfold integration."""
                pass
            
            # Override the registry entry
            admin.site._registry[Config] = ConstanceConfigAdmin(Config, admin.site)
            
        except ImportError:
            pass  # Constance not available
        except Exception:
            pass  # Any other error
```

## 🎯 Config Access Patterns

### 1. **Service Layer Access**
```python
# services/core/payment_service.py - Recommended pattern
class PaymentService:
    """Service with proper configuration access."""
    
    def __init__(self):
        # Static configuration (structure, defaults)
        self.config = get_current_config().payments
        
        # Dynamic settings (runtime values)
        self.settings = get_payment_settings()
    
    def create_payment(self, data: PaymentRequest) -> PaymentResponse:
        """Create payment with configuration validation."""
        # Use static config for validation
        if data.amount_usd < self.config.min_amount_usd:
            raise ValueError(f"Amount below minimum: {self.config.min_amount_usd}")
        
        # Use dynamic settings for API calls
        provider_config = self.settings.get_provider_config(data.provider)
        if not provider_config['enabled']:
            raise ValueError(f"Provider {data.provider} not configured")
        
        # Business logic here
        return self._process_payment(data, provider_config)
```

### 2. **Manager Layer Access**
```python
# models/managers/payment_managers.py - Recommended pattern
class PaymentManager(models.Manager):
    """Manager with configuration access."""
    
    def create_payment(self, user, amount_usd: float, currency_code: str):
        """Create payment with config validation."""
        # Get configuration
        config = get_current_config().payments
        settings = get_payment_settings()
        
        # Validate against static config
        if amount_usd < config.min_amount_usd or amount_usd > config.max_amount_usd:
            raise ValueError(f"Amount must be between {config.min_amount_usd} and {config.max_amount_usd}")
        
        # Check dynamic settings
        if not settings.enabled:
            raise ValueError("Payments are currently disabled")
        
        # Create payment
        return self.create(
            user=user,
            amount_usd=amount_usd,
            currency=Currency.objects.get(code=currency_code),
            status='pending'
        )
```

### 3. **Middleware Access**
```python
# middleware/api_access.py - Recommended pattern
class APIAccessMiddleware:
    """Middleware with configuration access."""
    
    def __init__(self, get_response):
        self.get_response = get_response
        # Cache configuration on startup
        self.config = get_current_config().payments
        self.settings = None  # Load dynamically
    
    def __call__(self, request):
        # Get fresh dynamic settings for each request
        if not self.settings:
            self.settings = get_payment_settings()
        
        # Check if middleware is enabled
        if not self.config.middleware_enabled or not self.settings.enabled:
            return self.get_response(request)
        
        # Apply rate limiting based on dynamic settings
        rate_limits = self.settings.get_rate_limits()
        # Rate limiting logic here
        
        return self.get_response(request)
```

## 🌍 Environment Management

### 1. **Environment Detection**
```python
# core/config.py - Real implementation
class EnvironmentMode(str, Enum):
    """Environment modes with auto-detection."""
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"
    TEST = "test"
    
    @classmethod
    def detect_from_debug(cls, debug: bool) -> 'EnvironmentMode':
        """Detect environment from DEBUG setting."""
        return cls.DEVELOPMENT if debug else cls.PRODUCTION

class DjangoConfig(BaseModel):
    """Main Django configuration with environment awareness."""
    
    environment: EnvironmentMode = Field(
        default_factory=lambda: EnvironmentMode.detect_from_debug(True),
        description="Environment mode (auto-detected from DEBUG)"
    )
    
    def get_environment_specific_settings(self) -> Dict[str, Any]:
        """Get settings specific to current environment."""
        if self.environment == EnvironmentMode.DEVELOPMENT:
            return {
                'DEBUG': True,
                'ALLOWED_HOSTS': ['localhost', '127.0.0.1'],
                'CORS_ALLOW_ALL_ORIGINS': True,
            }
        elif self.environment == EnvironmentMode.PRODUCTION:
            return {
                'DEBUG': False,
                'ALLOWED_HOSTS': self.allowed_hosts,
                'SECURE_SSL_REDIRECT': True,
            }
        return {}
```

### 2. **Environment-Aware Configuration**
```python
# Real pattern for environment-specific config
class PaymentsConfig(BaseModel):
    """Payments configuration with environment awareness."""
    
    def get_provider_settings(self, environment: EnvironmentMode) -> Dict[str, Any]:
        """Get provider settings based on environment."""
        if environment == EnvironmentMode.DEVELOPMENT:
            return {
                'nowpayments': {
                    'sandbox_mode': True,
                    'api_url': 'https://api-sandbox.nowpayments.io',
                    'webhook_url': 'https://your-ngrok-url.ngrok.io/webhooks/nowpayments/',
                }
            }
        elif environment == EnvironmentMode.PRODUCTION:
            return {
                'nowpayments': {
                    'sandbox_mode': False,
                    'api_url': 'https://api.nowpayments.io',
                    'webhook_url': 'https://your-domain.com/webhooks/nowpayments/',
                }
            }
        return {}
```

### 3. **Configuration Helpers**
```python
# config/helpers.py - Real pattern
class PaymentsConfigHelper:
    """Helper for accessing payments configuration."""
    
    @staticmethod
    def get_api_key(provider: str) -> str:
        """Get API key for payment provider."""
        settings = get_payment_settings()
        if provider == 'nowpayments':
            return settings.nowpayments_api_key
        raise ValueError(f"Unknown provider: {provider}")
    
    @staticmethod
    def is_provider_enabled(provider: str) -> bool:
        """Check if payment provider is enabled."""
        settings = get_payment_settings()
        provider_config = settings.get_provider_config(provider)
        return provider_config.get('enabled', False)
    
    @staticmethod
    def get_environment_config() -> Dict[str, Any]:
        """Get environment-specific configuration."""
        config = get_current_config()
        return config.payments.get_provider_settings(config.environment)
```

## 🏷️ Metadata
**Tags**: `configuration, constance, pydantic, environment, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Real Examples**: Payments, Knowbase configuration from django-cfg
**DEPENDS_ON**: [django-cfg-core, constance, pydantic]
**USED_BY**: [all-django-cfg-apps]
