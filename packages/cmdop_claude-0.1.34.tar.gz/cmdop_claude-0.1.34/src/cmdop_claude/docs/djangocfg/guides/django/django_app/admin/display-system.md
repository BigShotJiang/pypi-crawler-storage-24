# 🎨 Display System %%PRIORITY:HIGH%%

## 🎯 Overview

Zero-duplication display system with type-safe configuration. All display utilities are designed to eliminate HTML repetition while maintaining full customization.

## 🏗️ Architecture

```
@display decorator (error handling, HTML safety)
    ↓
DisplayMixin methods (business logic)
    ↓
Utility classes (rendering)
    ↓
Pydantic configs (type safety)
    ↓
HTML output (safe, consistent)
```

## 🎨 Display Types

### 1. User Display %%PRIORITY:HIGH%%

Display users with avatars, names, and email addresses.

#### With Avatar (for header=True)

```python
@display(description="Customer", header=True)
def customer_display(self, obj):
    """Returns list for unfold header display."""
    return self.display_user_with_avatar(obj, 'customer')
```

**Output**: `["<img src='...' />", "John Doe", "john@example.com"]`

#### Simple Display

```python
@display(description="Created By")
def created_by_display(self, obj):
    """Returns single string."""
    return self.display_user_simple(obj, 'created_by')
```

**Output**: `"John Doe (john@example.com)"`

#### Configuration

```python
from django_cfg.modules.django_admin import UserDisplayConfig

config = UserDisplayConfig(
    show_email=True,        # Show email in parentheses
    show_avatar=True,       # Include avatar image
    avatar_size=32,         # Avatar size in pixels
    fallback_initials=True  # Show initials if no avatar
)

return self.display_user_with_avatar(obj, 'user', config)
```

### 2. Money Display %%PRIORITY:HIGH%%

Display monetary amounts with proper formatting and currency.

#### Simple Amount

```python
@display(description="Price")
def price_display(self, obj):
    return self.display_money_amount(obj, 'price')
```

**Output**: `"$99.99"`

#### With Configuration

```python
from django_cfg.modules.django_admin import MoneyDisplayConfig

@display(description="Total")
def total_display(self, obj):
    config = MoneyDisplayConfig(
        currency="EUR",
        show_sign=True,         # Show + or - sign
        decimal_places=2,       # Number of decimal places
        thousand_separator=True # Use thousand separators
    )
    return self.display_money_amount(obj, 'total_amount', config)
```

**Output**: `"+€1,234.56"`

#### Money Breakdown

```python
@display(description="Pricing")
def pricing_display(self, obj):
    """Display complex pricing with breakdown."""
    monthly = self.display_money_amount(
        obj, 'monthly_price', 
        MoneyDisplayConfig(currency="USD", show_sign=False)
    )
    
    if obj.yearly_price:
        yearly = self.display_money_amount(
            obj, 'yearly_price',
            MoneyDisplayConfig(currency="USD", show_sign=False)
        )
        discount = f"{obj.yearly_discount_percentage:.0f}% off"
        return format_html("{}/mo • {}/yr ({})", monthly, yearly, discount)
    
    return format_html("{}/mo", monthly)
```

**Output**: `"$29/mo • $290/yr (17% off)"`

### 3. Status Display %%PRIORITY:HIGH%%

Display status with colored badges and icons.

#### Automatic Status Mapping

```python
@display(description="Status", label=True)
def status_display(self, obj):
    """Automatic color mapping based on status value."""
    return self.display_status_auto(obj, 'status')
```

**Default Mappings**:
- `active`, `completed`, `success` → `success` (green)
- `pending`, `processing` → `warning` (yellow)
- `failed`, `error`, `cancelled` → `danger` (red)
- `inactive`, `disabled` → `secondary` (gray)

#### Custom Status Mapping

```python
from django_cfg.modules.django_admin import StatusBadgeConfig

@display(description="Order Status", label=True)
def status_display(self, obj):
    config = StatusBadgeConfig(
        custom_mappings={
            'draft': 'secondary',
            'pending': 'warning',
            'processing': 'info',
            'shipped': 'primary',
            'delivered': 'success',
            'cancelled': 'danger',
            'refunded': 'warning'
        },
        show_icons=True,
        icon=Icons.SHOPPING_CART
    )
    return self.display_status_auto(obj, 'status', config)
```

#### Manual Badge Creation

```python
from django_cfg.modules.django_admin.utils.badges import StatusBadge

@display(description="Custom Badge")
def custom_badge_display(self, obj):
    return StatusBadge.create(
        text="VIP Customer",
        variant="primary",
        config=StatusBadgeConfig(
            show_icons=True,
            icon=Icons.STAR
        )
    )
```

### 4. DateTime Display %%PRIORITY:HIGH%%

Display dates and times with relative formatting.

#### Relative Time

```python
@display(description="Created")
def created_display(self, obj):
    """Shows '2 hours ago', 'yesterday', etc."""
    return self.display_datetime_relative(obj, 'created_at')
```

**Output**: `"2 hours ago"`, `"yesterday"`, `"3 days ago"`

#### With Configuration

```python
from django_cfg.modules.django_admin import DateTimeDisplayConfig

@display(description="Last Login")
def last_login_display(self, obj):
    config = DateTimeDisplayConfig(
        show_relative=True,     # Show relative time
        show_seconds=False,     # Hide seconds
        datetime_format="%Y-%m-%d %H:%M:%S"  # Fallback format
    )
    return self.display_datetime_relative(obj, 'last_login', config)
```

#### Compact Format

```python
@display(description="Updated")
def updated_display(self, obj):
    """Compact format: 'Dec 15, 14:30'"""
    return self.display_datetime_compact(obj, 'updated_at')
```

### 5. Count Display

Display counts with badges and labels.

#### Simple Count

```python
@display(description="Orders")
def orders_count_display(self, obj):
    """Display count from annotation."""
    return self.display_count_simple(obj, 'orders_count', 'orders')
```

**Output**: `"5 orders"` (as badge)

#### Related Count

```python
@display(description="Comments")
def comments_count_display(self, obj):
    """Count related objects."""
    return self.display_related_count(obj, 'comments', 'comments')
```

### 6. Boolean Display

Display boolean values with icons and colors.

```python
@display(description="Active", boolean=True)
def is_active_display(self, obj):
    """Boolean display with icons."""
    return self.display_boolean_icon(obj, 'is_active')
```

**Output**: ✅ (green check) or ❌ (red X)

## 🔧 Custom Display Utilities

### Creating Custom Displays

```python
from django_cfg.modules.django_admin.utils.displays import BaseDisplay
from django.utils.html import format_html

class ProgressDisplay(BaseDisplay):
    """Custom progress bar display."""
    
    @staticmethod
    def progress_bar(percentage, config=None):
        """Display progress bar."""
        color = 'success' if percentage >= 80 else 'warning' if percentage >= 50 else 'danger'
        
        return format_html(
            '<div class="progress" style="width: 100px; height: 8px; background: #e5e7eb; border-radius: 4px;">'
            '<div class="progress-bar bg-{}" style="width: {}%; height: 100%; border-radius: 4px;"></div>'
            '</div>',
            color,
            percentage
        )

# Usage in admin
@display(description="Progress")
def progress_display(self, obj):
    return ProgressDisplay.progress_bar(obj.completion_percentage)
```

### Complex Display Combinations

```python
@display(description="Order Summary")
def order_summary_display(self, obj):
    """Complex display combining multiple utilities."""
    
    # User info
    user_info = self.display_user_simple(obj, 'user')
    
    # Money amount
    total = self.display_money_amount(obj, 'total_amount')
    
    # Status badge
    status = self.display_status_auto(obj, 'status')
    
    # Items count
    items = self.display_count_simple(obj, 'items_count', 'items')
    
    return format_html(
        '<div class="order-summary">'
        '<div class="user">{}</div>'
        '<div class="amount">{}</div>'
        '<div class="status">{}</div>'
        '<div class="items">{}</div>'
        '</div>',
        user_info, total, status, items
    )
```

## 🎨 Styling and Theming

### CSS Classes

All display utilities generate consistent CSS classes:

```css
/* Status badges */
.status-badge { /* Base badge styles */ }
.status-badge.success { /* Success variant */ }
.status-badge.warning { /* Warning variant */ }
.status-badge.danger { /* Danger variant */ }

/* Money displays */
.money-display { /* Base money styles */ }
.money-positive { /* Positive amounts */ }
.money-negative { /* Negative amounts */ }

/* User displays */
.user-display { /* Base user styles */ }
.user-avatar { /* Avatar styles */ }
.user-info { /* Name/email styles */ }
```

### Custom Styling

```python
# Add custom CSS classes
config = StatusBadgeConfig(
    custom_css_classes=['my-custom-badge', 'large-badge']
)
```

## 🔍 Error Handling

### Automatic Error Handling

The `@display` decorator automatically handles errors:

```python
@display(description="Safe Display", empty_value="N/A")
def safe_display(self, obj):
    """Errors are caught and logged automatically."""
    # This might raise an exception
    return obj.complex_calculation()
```

**Error Behavior**:
1. Exception is caught and logged
2. `empty_value` is returned ("N/A")
3. Admin continues to work normally

### Manual Error Handling

```python
@display(description="Manual Error Handling")
def manual_display(self, obj):
    """Handle errors manually for custom behavior."""
    try:
        return self.display_money_amount(obj, 'amount')
    except AttributeError:
        return StatusBadge.create("Missing Data", "warning")
    except Exception as e:
        logger.error(f"Display error: {e}")
        return "Error"
```

## 🏷️ Real Examples from Payments Admin

### Network Admin

```python
@display(description="Native Currency")
def native_currency_display(self, obj: Network):
    """Native currency display."""
    if obj.native_currency:
        return f"{obj.native_currency.code} ({obj.native_currency.name})"
    return "—"

@display(description="Explorer")
def explorer_display(self, obj: Network):
    """Explorer link display."""
    if obj.block_explorer_url:
        return format_html(
            '<a href="{}" target="_blank" class="text-blue-600 hover:text-blue-800">'
            '🔍 View Explorer'
            '</a>',
            obj.block_explorer_url
        )
    return "—"
```

### Tariff Admin

```python
@display(description="Pricing", ordering="monthly_price_usd")
def pricing_display(self, obj):
    """Pricing display using utilities."""
    monthly = self.display_money_amount(
        obj,
        'monthly_price_usd',
        MoneyDisplayConfig(currency="USD", show_sign=False)
    )

    if obj.yearly_price_usd:
        yearly = self.display_money_amount(
            obj,
            'yearly_price_usd',
            MoneyDisplayConfig(currency="USD", show_sign=False)
        )
        discount = f"{obj.yearly_discount_percentage:.0f}% off"
        return format_html("{}/mo • {}/yr ({})", monthly, yearly, discount)
    return format_html("{}/mo", monthly)
```

## 🏷️ Metadata
**Tags**: `display, utilities, badges, money, users, datetime, status`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Dependencies**: [unfold, pydantic>=2.0]
