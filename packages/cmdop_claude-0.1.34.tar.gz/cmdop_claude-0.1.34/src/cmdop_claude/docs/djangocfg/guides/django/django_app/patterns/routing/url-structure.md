# 🏗️ URL Structure Philosophy

## 1. **Django-CFG URL Hierarchy**

Django-CFG follows a clear, predictable URL structure that scales across applications:

```
/api/                          # API root
├── payments/                  # App-specific endpoints
│   ├── payments/             # Resource collections
│   ├── currencies/           # Related resources
│   └── webhooks/             # Special endpoints
├── knowbase/                 # Another app
│   ├── articles/
│   └── categories/
└── cfg/                      # Django-CFG system endpoints
    └── admin/                # Admin interfaces
        └── django_cfg_payments/
            └── admin/        # App admin interface
```

**Key Principles**:
- 🎯 **Predictable**: Same pattern across all apps
- 🔍 **Discoverable**: Clear resource hierarchy
- 🚀 **Scalable**: Easy to add new apps/resources
- 📖 **Self-documenting**: URLs explain their purpose

## 2. **App Namespacing Pattern**

Every Django-CFG app follows consistent namespacing:

```python
# ✅ CORRECT: Consistent cfg_ prefix
app_name = 'cfg_payments'      # payments app
app_name = 'cfg_knowbase'      # knowbase app  
app_name = 'cfg_support'       # support app
app_name = 'cfg_newsletter'    # newsletter app

# ❌ WRONG: Inconsistent naming
app_name = 'payments'          # Missing cfg_ prefix
app_name = 'payment_system'    # Different naming pattern
```

**Benefits**:
- 🏷️ **Clear Ownership**: Immediately identifies Django-CFG apps
- 🔒 **Namespace Safety**: Prevents conflicts with other packages
- 🔗 **URL Reversing**: Consistent `{% url 'cfg_payments:payment-list' %}`
- 📋 **Documentation**: Easy to identify in logs/debugging

## 3. **URL Pattern Hierarchy**

### A. **Main Project URLs**
```python
# main_project/urls.py
urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('django_cfg.apps.urls')),  # All Django-CFG apps
]
```

### B. **Django-CFG Apps Router**
```python
# django_cfg/apps/urls.py
urlpatterns = [
    path('payments/', include('django_cfg.apps.payments.urls')),
    path('knowbase/', include('django_cfg.apps.knowbase.urls')),
    path('support/', include('django_cfg.apps.support.urls')),
    path('newsletter/', include('django_cfg.apps.newsletter.urls')),
    
    # Admin interfaces
    path('cfg/admin/django_cfg_payments/', include('django_cfg.apps.payments.urls_admin')),
    path('cfg/admin/django_cfg_knowbase/', include('django_cfg.apps.knowbase.urls_admin')),
]
```

### C. **App-Specific URLs**
```python
# django_cfg/apps/payments/urls.py
app_name = 'cfg_payments'

router = DefaultRouter()
router.register(r'payments', PaymentViewSet, basename='payment')
router.register(r'currencies', CurrencyViewSet, basename='currency')

urlpatterns = [
    path('', include(router.urls)),
    # Custom endpoints
    path('payments/create/', PaymentCreateView.as_view(), name='payment-create'),
]
```

## 4. **Resource Naming Conventions**

### A. **Collection vs Resource**
```python
# ✅ CORRECT: RESTful resource naming
/api/payments/payments/           # Collection of payments
/api/payments/payments/123/       # Specific payment resource
/api/payments/currencies/         # Collection of currencies
/api/payments/currencies/BTC/     # Specific currency

# ❌ WRONG: Inconsistent naming
/api/payments/payment/            # Singular for collection
/api/payments/get_currencies/     # RPC-style naming
```

### B. **Nested Resources**
```python
# ✅ CORRECT: Clear parent-child relationship
/api/support/tickets/             # All tickets
/api/support/tickets/123/         # Specific ticket
/api/support/tickets/123/messages/ # Messages for ticket 123

# ❌ WRONG: Flat structure loses context
/api/support/messages/?ticket=123  # Query parameter instead of nesting
```

## 5. **Special Endpoint Patterns**

### A. **Webhook Endpoints**
```python
# Provider-specific webhook patterns
path('webhooks/<str:provider>/', WebhookView.as_view(), name='webhook'),

# Results in:
# /api/payments/webhooks/nowpayments/
# /api/payments/webhooks/stripe/
# /api/payments/webhooks/coinbase/
```

### B. **Admin Interface Patterns**
```python
# Admin interface URLs are separate from API
path('cfg/admin/django_cfg_payments/admin/', include([
    path('', DashboardView.as_view(), name='dashboard'),
    path('payments/', PaymentListView.as_view(), name='payment-list'),
    path('payments/<uuid:pk>/', PaymentDetailView.as_view(), name='payment-detail'),
]))
```

### C. **Action-Based Endpoints**
```python
# Custom actions on resources
@action(detail=True, methods=['post'])
def cancel(self, request, pk=None):
    # POST /api/payments/payments/123/cancel/
    pass

@action(detail=False, methods=['get'])
def stats(self, request):
    # GET /api/payments/payments/stats/
    pass
```

## 6. **URL Pattern Ordering Rules**

**Critical Rule**: Specific patterns MUST come before generic ones

```python
# ✅ CORRECT: Specific before generic
urlpatterns = [
    path('payments/create/', PaymentCreateView.as_view()),      # Specific
    path('payments/stats/', PaymentStatsView.as_view()),       # Specific
    path('payments/<uuid:pk>/', PaymentDetailView.as_view()),  # Generic
]

# ❌ WRONG: Generic pattern catches everything
urlpatterns = [
    path('payments/<uuid:pk>/', PaymentDetailView.as_view()),  # Catches 'create'!
    path('payments/create/', PaymentCreateView.as_view()),     # Never reached
]
```

## 7. **Integration with Django-CFG**

### A. **Configuration-Driven URLs**
```python
# URLs can be configured via django-cfg settings
from django_cfg.core.config import get_app_config

config = get_app_config('payments')
if config.api_enabled:
    urlpatterns.append(path('api/', include(api_urls)))
```

### B. **Environment-Specific Patterns**
```python
# Different URL patterns for different environments
if settings.DEBUG:
    urlpatterns += [
        path('debug/payments/', include(debug_urls)),
    ]
```

## 8. **Best Practices Summary**

### ✅ **DO**
- Use consistent `cfg_` app naming
- Follow RESTful resource conventions
- Order specific patterns before generic
- Use nested routing for related resources
- Separate admin URLs from API URLs

### ❌ **DON'T**
- Mix different naming conventions
- Use RPC-style endpoint names
- Put generic patterns before specific ones
- Flatten nested resource relationships
- Mix admin and API concerns in same URLs

### 🎯 **Result**
- Predictable, discoverable URL structure
- Easy to maintain and extend
- Clear separation of concerns
- Consistent across all Django-CFG apps
