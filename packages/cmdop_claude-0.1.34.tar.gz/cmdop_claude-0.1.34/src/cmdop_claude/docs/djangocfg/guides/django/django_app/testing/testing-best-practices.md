# 🎯 Testing Best Practices

## 🚨 CRITICAL: Business Logic Only Rule

**MANDATORY**: Tests should ONLY cover business logic. Do NOT waste time testing:

### ❌ NEVER TEST:
- `__str__` methods and string representations
- Model `verbose_name` and `verbose_name_plural`
- Django framework functionality (save, delete, etc.)
- Simple property getters/setters
- Static configuration values
- Template rendering (unless complex logic)
- URL routing (unless custom logic)
- Admin interface display

### ✅ ALWAYS TEST:
- **Business calculations** (pricing, discounts, taxes)
- **Validation logic** (custom validators, business rules)
- **State transitions** (order status changes, payment flows)
- **Manager methods** (custom queries, business operations)
- **Service layer logic** (payment processing, notifications)
- **API endpoints** (request/response handling, permissions)
- **Signal handlers** (business logic in signals)
- **Background tasks** (Dramatiq tasks with business logic)

### 🎯 Example - What to Test vs What NOT to Test:

```python
# ❌ WASTE OF TIME - Don't test this crap
class PaymentModelTest(TestCase):
    def test_payment_str_representation(self):  # ❌ USELESS
        payment = UniversalPayment.objects.create(...)
        self.assertEqual(str(payment), "Payment 123 - $100.00 BTC")
    
    def test_payment_verbose_name(self):  # ❌ USELESS
        self.assertEqual(UniversalPayment._meta.verbose_name, "Universal Payment")

# ✅ VALUABLE - Test business logic
class PaymentBusinessLogicTest(TestCase):
    def test_payment_fee_calculation(self):  # ✅ BUSINESS LOGIC
        payment = UniversalPayment.objects.create(amount_usd=100.0, ...)
        fee = payment.calculate_processing_fee()
        self.assertEqual(fee, Decimal('2.50'))  # 2.5% fee
    
    def test_payment_expiration_logic(self):  # ✅ BUSINESS LOGIC
        payment = UniversalPayment.objects.create(...)
        self.assertFalse(payment.is_expired())
        
        # Move time forward
        payment.expires_at = timezone.now() - timedelta(minutes=1)
        payment.save()
        self.assertTrue(payment.is_expired())
    
    def test_payment_status_transitions(self):  # ✅ BUSINESS LOGIC
        payment = UniversalPayment.objects.create(...)
        
        # Test valid transition
        result = payment.mark_as_completed()
        self.assertTrue(result)
        self.assertEqual(payment.status, PaymentStatus.COMPLETED)
        
        # Test invalid transition
        result = payment.mark_as_pending()  # Can't go back to pending
        self.assertFalse(result)
```

### 🧠 Why This Rule Exists:
1. **Time efficiency** - Focus on what matters for business
2. **Maintenance reduction** - Less tests to maintain when refactoring
3. **Real bug detection** - Catch actual business logic errors
4. **Code coverage quality** - Meaningful coverage, not just numbers
5. **Developer sanity** - Don't waste brain cycles on trivial tests

## 🚨 CRITICAL: One Test Class Per File Rule

**MANDATORY**: Each test class MUST be in a separate file. This is non-negotiable.

### ❌ ANTI-PATTERN - Multiple classes in one file:
```python
# ❌ BAD: test_models.py (accumulating multiple classes)
class PaymentModelTest(TestCase):
    def test_payment_creation(self):
        pass

class CurrencyModelTest(TestCase):  # ❌ Second class in same file
    def test_currency_validation(self):
        pass

class UserBalanceModelTest(TestCase):  # ❌ Third class in same file
    def test_balance_calculation(self):
        pass
```

### ✅ CORRECT PATTERN - One class per file:
```python
# ✅ GOOD: test_payment_model.py (single focused class)
class PaymentModelTest(TestCase):
    def test_payment_creation(self):
        pass

# ✅ GOOD: test_currency_model.py (single focused class)
class CurrencyModelTest(TestCase):
    def test_currency_validation(self):
        pass

# ✅ GOOD: test_balance_model.py (single focused class)
class UserBalanceModelTest(TestCase):
    def test_balance_calculation(self):
        pass
```

### 🎯 Why This Rule Exists:
1. **Prevents monolithic files** - Stops accumulation of unrelated test classes
2. **Improves maintainability** - Each file has single responsibility
3. **Enables parallel testing** - Better CI/CD performance
4. **Reduces merge conflicts** - Team development friendly
5. **LLM-friendly navigation** - Easier for AI assistants to understand context

## 🚨 CRITICAL: Common Django-CFG Testing Issues & Solutions

### 🔧 Management Commands Not Found
**Error:** `Unknown command: 'currency_stats'`

**Solution:** Add your app to `tests/settings.py`:
```python
# /path/to/django-cfg/src/tests/settings.py
class TestConfig(DjangoConfig):
    project_apps: list = [
        "django_cfg.apps.accounts",
        "django_cfg.apps.knowbase", 
        "django_cfg.apps.payments",
        "django_cfg.apps.your_new_app",  # 👈 ADD HERE
    ]
```

### 🔧 Model Field Errors in Tests
**Error:** `TypeError: UniversalPayment() got unexpected keyword arguments: 'crypto_amount'`

**Solution:** Use actual model fields, not outdated ones:
```python
# ❌ Wrong - using non-existent fields
payment = UniversalPayment.objects.create(
    crypto_amount=0.001,      # Field doesn't exist
    currency_code="BTC",      # Use currency field instead
    order_id="test-123"       # Use internal_payment_id instead
)

# ✅ Correct - using actual model fields
payment = UniversalPayment.objects.create(
    amount_usd=100.0,         # Correct field
    currency=currency_obj,    # ForeignKey to Currency model
    internal_payment_id="test-123"  # Correct field name
)
```

### 🔧 Manager Method Errors
**Error:** `AttributeError: 'PaymentManager' object has no attribute 'create_payment'`

**Solution:** Use existing manager methods or standard Django methods:
```python
# ❌ Wrong - non-existent manager methods
payment = UniversalPayment.objects.create_payment(...)
payments = UniversalPayment.objects.for_user(user)
total = UniversalPayment.objects.total_amount()

# ✅ Correct - existing methods
payment = UniversalPayment.objects.create(...)
payments = UniversalPayment.objects.filter(user=user)
total = UniversalPayment.objects.aggregate(total=Sum('amount_usd'))['total']
```

### 🔧 DRF URL Routing Issues
**Error:** `Invalid version in URL path. Does not match any version namespace.`

**Solution:** Disable DRF versioning in tests:
```python
# tests/settings.py
REST_FRAMEWORK = {
    'DEFAULT_VERSIONING_CLASS': None,  # 👈 Disable versioning
    'TEST_REQUEST_DEFAULT_FORMAT': 'json',
}

# In ViewSets
class PaymentBaseViewSet(viewsets.ModelViewSet):
    versioning_class = None  # 👈 Explicitly disable
```

### 🔧 Cache Service Import Errors
**Error:** `ModuleNotFoundError: No module named 'django_cfg.apps.payments.services.cache.cache_service'`

**Solution:** Use correct import paths after decomposition:
```python
# ❌ Wrong - old import path
from django_cfg.apps.payments.services.cache.cache_service import get_cache_service

# ✅ Correct - new import path after decomposition
from django_cfg.apps.payments.services.cache_service import get_cache_service
```

## 📏 Test File Organization

### File Size Limits
- **Maximum 400 lines per test file**
- **Maximum 150 lines per test class**
- **Split by functionality**, not by file structure

### Import Rules for Tests
- **NO inline imports** - all imports at the top of the file
- **Group imports properly**: standard library, Django, third-party, local
- **Import only what you need** for better performance

### Database Configuration for Tests
- **ALWAYS specify databases** attribute in test classes when using multiple databases
- **Use only required databases** to avoid cross-database access errors
- **Default to 'default' database** for most applications
- **CRITICAL: Use `tests.settings`** instead of project settings to avoid database routing issues

```python
# ✅ Good - Proper test imports and database configuration
import time
from decimal import Decimal
from unittest.mock import Mock, patch

from django.test import TestCase
from django.contrib.auth import get_user_model

from django_cfg.apps.payments.models import Currency, Payment
from django_cfg.apps.payments.services import PaymentService

User = get_user_model()

class PaymentServiceTest(TestCase):
    """Test payment service functionality."""
    
    # ✅ CRITICAL: Always specify databases for multi-database projects
    databases = ['default']  # Most Django-CFG apps use only default database
    
    def setUp(self):
        # Test setup without inline imports
        pass

# ✅ Good - Only specify databases you actually need
class PaymentIntegrationTest(TestCase):
    """Test payment integration functionality."""
    
    databases = ['default']  # Most apps use only default database
    
    def test_payment_integration(self):
        # Test logic here
        pass

# ❌ Bad - Missing databases specification
class BadPaymentTest(TestCase):
    # Missing databases = [...] - will cause DatabaseOperationForbidden errors!
    
    def test_payment_creation(self):
        from django_cfg.apps.payments.models import Payment  # Also bad - inline import!
        payment = Payment.objects.create()

# ❌ Bad - Inline imports in tests
class AnotherBadTest(TestCase):
    databases = ['default']  # Good database config
    
    def test_payment_creation(self):
        from django_cfg.apps.payments.models import Payment  # NO! Inline import
        payment = Payment.objects.create()
```

### Database Access Errors and Solutions

**Common Error:**
```
DatabaseOperationForbidden: Database threaded connections to 'shop_db' 
are not allowed in this test. Add 'shop_db' to PaymentAPITest.databases 
to ensure proper test isolation and silence this failure.
```

**Solution:**
```python
class PaymentAPITest(TestCase):
    # ✅ Fix: Specify only the databases your test actually needs
    databases = ['default']  # Most Django-CFG apps use default database only
    
    def test_payment_api(self):
        # Your test code here
        pass
```

**Command to run tests correctly:**
```bash
# 🚀 BEST - Use the standard test runner (KISS principle)
cd /path/to/django-cfg
poetry run python run_tests.py

# ✅ CORRECT - Uses test settings without database routing
cd /path/to/django-cfg/src
poetry run python -m django test django_cfg.apps.payments.tests --settings=tests.settings

# 🔧 NON-INTERACTIVE TESTING (prevents hanging)
poetry run python -m django test django_cfg.apps.payments.tests \
    --settings=tests.settings \
    --verbosity=1 \
    --keepdb \
    --parallel auto

# ❌ WRONG - Uses project settings with multiple databases
poetry run python -m django test django_cfg.apps.payments.tests --settings=examples.sample.django.api.settings
```

**Why run_tests.py is the best choice:**
- No need to remember settings or paths
- Automatic test discovery for all Django-CFG apps
- Proper Django setup and teardown
- Follows KISS principle (Keep It Simple, Stupid)

**Why This Happens:**
- Django-CFG projects often use multiple databases with routing
- Database router tries to access different databases during tests
- Tests must explicitly declare which databases they use
- This ensures proper test isolation and prevents cross-database errors

## 1. **Performance Optimization (Real Implementation)**
```python
# Real pattern for optimized testing
class OptimizedTestCase(TestCase):
    """Optimized test case with shared fixtures."""
    
    @classmethod
    def setUpClass(cls):
        """Set up class-level fixtures (run once)."""
        super().setUpClass()
        
        # Create shared test data once
        cls.shared_user = User.objects.create_user(
            username='shareduser',
            email='shared@example.com',
            password='testpass123'
        )
        
        cls.shared_source = RegistrationSource.objects.create(
            url='https://shared.example.com',
            name='Shared Source'
        )
    
    def setUp(self):
        """Set up test-specific data (run for each test)."""
        # Only create test-specific data here
        self.test_document = ExternalData.objects.create(
            user=self.shared_user,
            title=f"Test Document {self.id()}",
            content="Test content"
        )
    
    def test_with_shared_fixtures(self):
        """Test using shared fixtures."""
        # Use shared fixtures for better performance
        self.assertIsNotNone(self.shared_user)
        self.assertIsNotNone(self.shared_source)
        self.assertIsNotNone(self.test_document)
```

## 2. **Error Handling Testing (Real Implementation)**
```python
# Real pattern for error handling tests
class ErrorHandlingTestCase(TestCase):
    """Test error handling scenarios."""
    
    def setUp(self):
        """Set up test data."""
        self.user = UserFactory.create_user()
    
    def test_database_error_handling(self):
        """Test database error handling."""
        with patch('django.db.models.Model.save') as mock_save:
            mock_save.side_effect = DatabaseError("Database connection lost")
            
            from ..services.document_service import DocumentService
            service = DocumentService()
            
            with self.assertRaises(DatabaseError):
                service.create_document(
                    user=self.user,
                    title="Test Document",
                    content="Test content"
                )
    
    def test_validation_error_handling(self):
        """Test validation error handling."""
        from ..services.document_service import DocumentService
        service = DocumentService()
        
        # Test with invalid data
        with self.assertRaises(ValidationError):
            service.create_document(
                user=None,  # Invalid user
                title="",   # Empty title
                content=""  # Empty content
            )
    
    def test_external_api_error_handling(self):
        """Test external API error handling."""
        with patch('requests.post') as mock_post:
            mock_post.side_effect = requests.exceptions.ConnectionError("API unavailable")
            
            from ..services.external_api_service import ExternalAPIService
            service = ExternalAPIService()
            
            result = service.call_external_api("test data")
            
            # Should handle error gracefully
            self.assertFalse(result.success)
            self.assertIn("API unavailable", result.error_message)
```

## 3. **Anti-Patterns to Avoid (Real Implementation)**
```python
# ❌ DON'T: Over-mocking
class BadTestCase(TestCase):
    @patch('django.db.models.Model.save')
    @patch('django.db.models.QuerySet.filter')
    @patch('django.db.models.QuerySet.get')
    def test_over_mocked(self, mock_get, mock_filter, mock_save):
        # Test becomes meaningless - too much mocking
        pass

# ✅ DO: Strategic mocking
class GoodTestCase(TestCase):
    @patch('external_api.call')  # Only mock external dependencies
    def test_strategic_mocking(self, mock_api_call):
        mock_api_call.return_value = {"status": "success"}
        
        # Test real business logic with mocked external calls
        result = my_service.process_data("test")
        self.assertTrue(result.success)

# ❌ DON'T: Ignore signal side effects
class BadSignalTestCase(TestCase):
    def test_ignoring_signals(self):
        user = User.objects.create(email="test@example.com")
        # Ignores that signals might create related objects
        
# ✅ DO: Account for signal side effects
class GoodSignalTestCase(TestCase):
    def test_with_signal_effects(self):
        user = User.objects.create(email="test@example.com")
        
        # Check that signals created expected related objects
        self.assertTrue(UserProfile.objects.filter(user=user).exists())

# ❌ DON'T: Flaky timing tests
class BadTimingTestCase(TestCase):
    def test_flaky_timing(self):
        start_async_operation()
        time.sleep(1)  # Flaky - depends on system performance
        assert operation_complete()

# ✅ DO: Deterministic async testing
class GoodAsyncTestCase(TestCase):
    @patch('async_operation')
    def test_deterministic_async(self, mock_operation):
        mock_operation.return_value = asyncio.Future()
        mock_operation.return_value.set_result("completed")
        
        result = await my_async_function()
        self.assertEqual(result, "completed")
```

## ✅ Do's
- Use `TestCase` for database-dependent tests
- Mock external API calls
- Test both success and failure scenarios
- Use descriptive test method names
- Follow AAA pattern (Arrange, Act, Assert)

## ❌ Don'ts
- Don't test Django framework functionality
- Don't make real API calls in tests
- Don't test implementation details
- Don't create unnecessary test data

## Strategic Mocking
```python
# ✅ DO: Strategic mocking
class GoodTestCase(TestCase):
    @patch('external_api.call')  # Only mock external dependencies
    def test_strategic_mocking(self, mock_api_call):
        mock_api_call.return_value = {"status": "success"}
        
        # Test real business logic with mocked external calls
        result = my_service.process_data("test")
        self.assertTrue(result.success)
```

## Account for Signal Side Effects
```python
# ✅ DO: Account for signal side effects
class GoodSignalTestCase(TestCase):
    def test_with_signal_effects(self):
        user = User.objects.create(email="test@example.com")
        
        # Check that signals created expected related objects
        self.assertTrue(UserProfile.objects.filter(user=user).exists())
```
