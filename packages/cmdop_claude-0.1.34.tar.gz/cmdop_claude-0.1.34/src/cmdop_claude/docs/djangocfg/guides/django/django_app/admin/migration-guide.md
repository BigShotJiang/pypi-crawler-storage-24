# 🔄 Migration Guide %%PRIORITY:HIGH%%

## 🎯 Overview

Step-by-step guide for migrating from vanilla Django admin or other admin systems to Django-CFG admin system.

## 📋 Migration Checklist

### ✅ Pre-Migration Checklist

- [ ] **Backup existing admin files**
- [ ] **Document current admin functionality**
- [ ] **Identify custom HTML/CSS that needs migration**
- [ ] **List all custom actions and their behavior**
- [ ] **Note performance issues in current admin**

### ✅ Dependencies Setup

```bash
# Ensure django-unfold is installed
pip install django-unfold

# Ensure pydantic 2.0+ is available
pip install "pydantic>=2.0"
```

## 🔧 Step-by-Step Migration

### Step 1: Update Imports %%PRIORITY:HIGH%%

**Before (Vanilla Django Admin):**
```python
from django.contrib import admin
from django.utils.html import format_html

class MyModelAdmin(admin.ModelAdmin):
    pass
```

**After (Django-CFG Admin):**
```python
from django.contrib import admin
from unfold.admin import ModelAdmin
from django_cfg.modules.django_admin import (
    OptimizedModelAdmin,
    DisplayMixin,
    StatusBadgeConfig,
    MoneyDisplayConfig,
    Icons,
    display,
    action,
    ActionVariant
)

class MyModelAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    pass
```

### Step 2: Update Class Inheritance %%PRIORITY:HIGH%%

**Before:**
```python
class OrderAdmin(admin.ModelAdmin):
    pass
```

**After:**
```python
class OrderAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    """Always follow this inheritance order."""
    pass
```

**Inheritance Pattern:**
1. `OptimizedModelAdmin` - Performance optimization
2. `DisplayMixin` - Display utilities
3. `ModelAdmin` - Unfold UI/UX

### Step 3: Migrate Display Methods %%PRIORITY:HIGH%%

**Before (Manual HTML):**
```python
def status_display(self, obj):
    if obj.is_active:
        return format_html(
            '<span style="color: green; font-weight: bold;">✅ Active</span>'
        )
    return format_html(
        '<span style="color: red; font-weight: bold;">❌ Inactive</span>'
    )
status_display.short_description = "Status"
```

**After (Utility Methods):**
```python
@display(description="Status", label=True)
def status_display(self, obj):
    return self.display_status_auto(obj, 'is_active')
```

### Step 4: Migrate Money Display %%PRIORITY:HIGH%%

**Before:**
```python
def price_display(self, obj):
    return f"${obj.price:.2f}"
price_display.short_description = "Price"
```

**After:**
```python
@display(description="Price")
def price_display(self, obj):
    config = MoneyDisplayConfig(
        currency="USD",
        decimal_places=2,
        thousand_separator=True
    )
    return self.display_money_amount(obj, 'price', config)
```

### Step 5: Migrate User Display %%PRIORITY:HIGH%%

**Before:**
```python
def user_display(self, obj):
    if obj.user:
        return f"{obj.user.get_full_name()} ({obj.user.email})"
    return "No user"
user_display.short_description = "User"
```

**After:**
```python
@display(description="User", header=True)
def user_display(self, obj):
    return self.display_user_with_avatar(obj, 'user')
```

### Step 6: Migrate Actions %%PRIORITY:HIGH%%

**Before:**
```python
def make_active(self, request, queryset):
    updated = queryset.update(is_active=True)
    self.message_user(request, f"Activated {updated} items.")
make_active.short_description = "Activate selected items"

actions = ['make_active']
```

**After:**
```python
@action(description="Activate selected items", variant=ActionVariant.SUCCESS)
def make_active(self, request, queryset):
    updated = queryset.update(is_active=True)
    self.message_user(request, f"Activated {updated} items.")

actions = ['make_active']
```

### Step 7: Add Performance Optimization %%PRIORITY:HIGH%%

**Before (No optimization):**
```python
class OrderAdmin(admin.ModelAdmin):
    list_display = ['customer_name', 'total_amount']
    
    def customer_name(self, obj):
        return obj.customer.name  # N+1 query!
```

**After (Optimized):**
```python
class OrderAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    # Automatic optimization
    select_related_fields = ['customer', 'payment_method']
    annotations = {'items_count': Count('items')}
    
    list_display = ['customer_display', 'total_display', 'items_count_display']
    
    @display(description="Customer")
    def customer_display(self, obj):
        return obj.customer.name  # No N+1 query!
    
    @display(description="Items")
    def items_count_display(self, obj):
        return self.display_count_simple(obj, 'items_count', 'items')
```

## 🔧 Common Migration Patterns

### Pattern 1: Status Fields

**Before:**
```python
def status_display(self, obj):
    colors = {
        'pending': 'orange',
        'completed': 'green',
        'failed': 'red'
    }
    color = colors.get(obj.status, 'gray')
    return format_html(
        '<span style="color: {};">{}</span>',
        color, obj.get_status_display()
    )
```

**After:**
```python
@display(description="Status", label=True)
def status_display(self, obj):
    config = StatusBadgeConfig(
        custom_mappings={
            'pending': 'warning',
            'completed': 'success',
            'failed': 'danger'
        },
        show_icons=True
    )
    return self.display_status_auto(obj, 'status', config)
```

### Pattern 2: Boolean Fields

**Before:**
```python
def is_active_display(self, obj):
    return "✅" if obj.is_active else "❌"
is_active_display.boolean = True
```

**After:**
```python
@display(description="Active", boolean=True)
def is_active_display(self, obj):
    return obj.is_active  # Automatic boolean display
```

### Pattern 3: DateTime Fields

**Before:**
```python
def created_display(self, obj):
    return obj.created_at.strftime("%Y-%m-%d %H:%M")
```

**After:**
```python
@display(description="Created")
def created_display(self, obj):
    config = DateTimeDisplayConfig(
        show_relative=True,
        show_seconds=False
    )
    return self.display_datetime_relative(obj, 'created_at', config)
```

### Pattern 4: Complex Displays

**Before:**
```python
def order_summary(self, obj):
    html = f"""
    <div>
        <strong>{obj.order_number}</strong><br>
        Customer: {obj.customer.name}<br>
        Total: ${obj.total_amount:.2f}<br>
        Status: <span style="color: {'green' if obj.is_completed else 'orange'}">
            {obj.get_status_display()}
        </span>
    </div>
    """
    return format_html(html)
```

**After:**
```python
@display(description="Order Summary")
def order_summary(self, obj):
    # Use multiple utility methods
    customer = self.display_user_simple(obj, 'customer')
    total = self.display_money_amount(obj, 'total_amount')
    status = self.display_status_auto(obj, 'status')
    
    return format_html(
        '<div><strong>#{}</strong><br>Customer: {}<br>Total: {}<br>Status: {}</div>',
        obj.order_number, customer, total, status
    )
```

## 🚨 Common Migration Issues

### Issue 1: Mixed Decorator Imports

**❌ Problem:**
```python
from unfold.decorators import display
from django_cfg.modules.django_admin import action
```

**✅ Solution:**
```python
from django_cfg.modules.django_admin import display, action
```

### Issue 2: Missing ModelAdmin Inheritance

**❌ Problem:**
```python
class MyAdmin(OptimizedModelAdmin, DisplayMixin):
    pass
```

**✅ Solution:**
```python
class MyAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    pass
```

### Issue 3: String Action Variants

**❌ Problem:**
```python
@action(description="Test", variant="success")  # String variant
```

**✅ Solution:**
```python
@action(description="Test", variant=ActionVariant.SUCCESS)  # Enum variant
```

### Issue 4: Hardcoded Configurations

**❌ Problem:**
```python
@display(description="Price")
def price_display(self, obj):
    return f"${obj.price:.2f}"  # Hardcoded format
```

**✅ Solution:**
```python
@display(description="Price")
def price_display(self, obj):
    config = MoneyDisplayConfig(currency="USD", decimal_places=2)
    return self.display_money_amount(obj, 'price', config)
```

## 🧪 Testing Migration

### Test Display Methods

```python
def test_status_display_migration(self):
    """Test migrated status display."""
    order = Order.objects.create(status='pending')
    admin = OrderAdmin(Order, admin.site)
    
    result = admin.status_display(order)
    
    # Should contain badge HTML
    self.assertIn('badge', result.lower())
    self.assertIn('pending', result.lower())
```

### Test Actions

```python
def test_action_migration(self):
    """Test migrated action."""
    orders = Order.objects.filter(is_active=False)
    admin = OrderAdmin(Order, admin.site)
    request = self.factory.post('/')
    request.user = self.superuser
    
    admin.activate_items(request, orders)
    
    # Check all orders are now active
    self.assertTrue(
        Order.objects.filter(id__in=orders.values_list('id', flat=True))
        .filter(is_active=True)
        .exists()
    )
```

## 📊 Performance Comparison

### Before Migration (N+1 Queries)

```python
# This generates N+1 queries
class OrderAdmin(admin.ModelAdmin):
    list_display = ['customer_name', 'payment_method_name']
    
    def customer_name(self, obj):
        return obj.customer.name  # Query per row
    
    def payment_method_name(self, obj):
        return obj.payment_method.name  # Query per row
```

### After Migration (Optimized)

```python
# This generates 1 query total
class OrderAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    select_related_fields = ['customer', 'payment_method']  # Single JOIN query
    
    list_display = ['customer_display', 'payment_method_display']
    
    @display(description="Customer")
    def customer_display(self, obj):
        return obj.customer.name  # No additional query
    
    @display(description="Payment Method")
    def payment_method_display(self, obj):
        return obj.payment_method.name  # No additional query
```

## 🎯 Migration Validation

### Checklist After Migration

- [ ] **All admin classes inherit from OptimizedModelAdmin, DisplayMixin, ModelAdmin**
- [ ] **All display methods use @display decorator**
- [ ] **All actions use @action decorator with ActionVariant**
- [ ] **No hardcoded HTML in display methods**
- [ ] **Performance optimization added (select_related_fields)**
- [ ] **Type hints added to display methods**
- [ ] **Configurations use Pydantic models**
- [ ] **All imports use django_cfg.modules.django_admin**
- [ ] **Tests updated and passing**
- [ ] **No linter errors**

### Performance Validation

```python
# Before migration - measure queries
from django.test.utils import override_settings
from django.db import connection

@override_settings(DEBUG=True)
def test_admin_performance(self):
    # Reset query count
    connection.queries_log.clear()
    
    # Load admin list view
    response = self.client.get('/admin/myapp/mymodel/')
    
    # Check query count
    query_count = len(connection.queries)
    print(f"Query count: {query_count}")
    
    # Should be significantly reduced after migration
    self.assertLess(query_count, 10)  # Adjust based on your data
```

## 🏷️ Real Migration Example

Here's a complete before/after example from our payments admin:

### Before (Vanilla Django)

```python
from django.contrib import admin
from django.utils.html import format_html

@admin.register(Currency)
class CurrencyAdmin(admin.ModelAdmin):
    list_display = ['code', 'name', 'status_display', 'rate_display']
    
    def status_display(self, obj):
        if obj.is_active:
            return format_html(
                '<span style="color: green;">✅ Active</span>'
            )
        return format_html(
            '<span style="color: red;">❌ Inactive</span>'
        )
    status_display.short_description = "Status"
    
    def rate_display(self, obj):
        return f"${obj.exchange_rate:.4f}"
    rate_display.short_description = "Exchange Rate"
    
    def make_active(self, request, queryset):
        updated = queryset.update(is_active=True)
        self.message_user(request, f"Activated {updated} currencies.")
    make_active.short_description = "Activate currencies"
    
    actions = ['make_active']
```

### After (Django-CFG)

```python
from django.contrib import admin
from unfold.admin import ModelAdmin
from django_cfg.modules.django_admin import (
    OptimizedModelAdmin,
    DisplayMixin,
    StatusBadgeConfig,
    MoneyDisplayConfig,
    Icons,
    display,
    action,
    ActionVariant
)

@admin.register(Currency)
class CurrencyAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    """Currency admin using Django-CFG utilities."""
    
    list_display = ['code', 'name', 'status_display', 'rate_display']
    
    @display(description="Status", label=True)
    def status_display(self, obj):
        return self.display_status_auto(obj, 'is_active')
    
    @display(description="Exchange Rate")
    def rate_display(self, obj):
        config = MoneyDisplayConfig(
            currency="USD",
            decimal_places=4,
            show_sign=False
        )
        return self.display_money_amount(obj, 'exchange_rate', config)
    
    @action(description="Activate currencies", variant=ActionVariant.SUCCESS)
    def make_active(self, request, queryset):
        updated = queryset.update(is_active=True)
        self.message_user(request, f"Activated {updated} currencies.")
    
    actions = ['make_active']
```

**Benefits of Migration:**
- ✅ **Zero HTML duplication** - Status display uses utility
- ✅ **Type-safe configuration** - MoneyDisplayConfig for formatting
- ✅ **Consistent styling** - Automatic badge colors
- ✅ **Error handling** - Decorators handle exceptions
- ✅ **Performance ready** - Can add select_related_fields easily
- ✅ **Material icons** - Can add icons to actions
- ✅ **Maintainable** - Configuration changes don't require HTML updates

## 🏷️ Metadata
**Tags**: `migration, upgrade, vanilla-django, unfold, step-by-step`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Time**: 2-4 hours per admin class
