# 🎯 Code-First Testing Philosophy

## ✅ The Right Approach: Tests Follow Code
**CRITICAL PRINCIPLE**: Tests must be written based on actual implementation, not assumptions or wishful thinking.

## Why Code-First Testing Matters
```python
# ❌ WRONG: Writing tests based on assumptions
class BadTestCase(TestCase):
    def test_assumed_api(self):
        # Assuming methods exist without checking
        result = MyService.get_payment_by_id("123")  # Method doesn't exist!
        self.assertIsNotNone(result)

# ✅ RIGHT: Writing tests based on actual code
class GoodTestCase(TestCase):
    def test_actual_api(self):
        # First, study the actual service implementation
        # MyService has get_payment_details(payment_id) method
        result = MyService.get_payment_details("123")
        self.assertIsNotNone(result)
```

## Universal Testing Workflow
1. **📖 Study the Code First**
   ```python
   # Before writing tests, examine actual implementation:
   # - What methods exist?
   # - What parameters do they accept?
   # - What do they return?
   # - What exceptions can they raise?
   ```

2. **🔍 Understand the Data Models**
   ```python
   # Check actual model fields before creating test data
   # ❌ DON'T assume fields exist:
   User.objects.create(name="test")  # 'name' field might not exist
   
   # ✅ DO check model definition first:
   User.objects.create(username="test", email="test@example.com")
   ```

3. **🧪 Write Tests That Match Reality**
   ```python
   # ✅ Test actual behavior, not imagined behavior
   class PaymentServiceTest(TestCase):
       def setUp(self):
           # Study PaymentService first to understand its dependencies
           self.service = PaymentService()
           
       def test_create_payment_actual_method(self):
           # Use actual method names and parameters
           result = self.service.create_payment_request(
               user_id=1,
               amount_usd=100.0,
               currency_code="BTC"  # Check if this parameter exists
           )
           self.assertTrue(result.success)
   ```

## Common Anti-Patterns to Avoid
```python
# ❌ ANTI-PATTERN 1: Assuming method names
def test_bad_assumption(self):
    # Don't assume method names without checking
    user.get_balance()  # Method might be called 'calculate_balance'

# ❌ ANTI-PATTERN 2: Assuming field names  
def test_bad_fields(self):
    Payment.objects.create(
        amount=100,      # Field might be 'amount_usd'
        currency="BTC"   # Field might be 'currency_code'
    )

# ❌ ANTI-PATTERN 3: Assuming return types
def test_bad_return_type(self):
    payments = service.get_user_payments(user_id=1)
    self.assertEqual(len(payments), 2)  # Might return ServiceResult, not list

# ✅ CORRECT PATTERN: Study first, then test
def test_correct_approach(self):
    # 1. Read the actual service code
    # 2. Understand the actual return type (ServiceResult)
    # 3. Write test accordingly
    result = service.get_user_payments(user_id=1)
    self.assertTrue(result.success)
    self.assertEqual(len(result.data), 2)
```

## Database Schema Alignment
```python
# ✅ Always check actual model definitions
class PaymentModelTest(TestCase):
    def setUp(self):
        # Study models.py first to understand required fields
        self.currency = Currency.objects.create(
            code="BTC",
            name="Bitcoin",
            currency_type="crypto"  # Check if this field exists
        )
        
        self.network = Network.objects.create(
            code="bitcoin",
            name="Bitcoin Network",
            native_currency=self.currency  # Required foreign key!
        )
    
    def test_payment_creation(self):
        # Use actual field names from the model
        payment = UniversalPayment.objects.create(
            user=self.user,
            amount_usd=100.0,        # Not 'amount'
            currency_code="BTC",     # Not 'currency'
            network=self.network,
            status="pending"         # Check valid choices
        )
        self.assertIsNotNone(payment.id)
```

## Manager Method Alignment
```python
# ✅ Study manager implementations before testing
class ManagerTest(TestCase):
    def test_actual_manager_methods(self):
        # Read the actual manager code first
        # Don't assume method names
        
        # ❌ Wrong: Assuming method name
        # balance = UserBalance.objects.create_balance(user=user)
        
        # ✅ Right: Using actual method name
        balance = UserBalance.objects.get_or_create_for_user(user=user)
        
        # ❌ Wrong: Assuming method signature
        # UserBalance.objects.add_funds(balance, 100)
        
        # ✅ Right: Using actual method signature  
        UserBalance.objects.add_funds_to_user(user=user, amount=100)
```

## 🔧 Practical Implementation Steps

### Step 1: Code Discovery
```bash
# Before writing tests, explore the actual codebase
find src/ -name "*.py" -path "*/payments/*" | head -10
grep -r "class.*Manager" src/django_cfg/apps/payments/
grep -r "def " src/django_cfg/apps/payments/services/
```

### Step 2: API Documentation
```python
# Create your own API documentation by reading code
"""
PaymentService actual methods (discovered by reading code):
- create_payment_request(user_id, amount_usd, currency_code) -> ServiceResult
- get_user_payments(user_id, status=None) -> ServiceResult  
- get_payment_status(payment_id) -> ServiceResult
- NOT: get_payment_by_id() - this method doesn't exist!
"""
```

### Step 3: Test Implementation
```python
# Write tests based on discovered API
class PaymentServiceTest(TestCase):
    def test_discovered_methods_only(self):
        # Only test methods that actually exist
        result = self.service.create_payment_request(
            user_id=self.user.id,
            amount_usd=100.0,
            currency_code="BTC"
        )
        self.assertIsInstance(result, ServiceResult)
        self.assertTrue(result.success)
```

## 🎯 Key Takeaways
1. **Never assume**: Always verify method names, parameters, and return types
2. **Study first**: Read the actual implementation before writing tests
3. **Align schemas**: Ensure test data matches actual model fields
4. **Test reality**: Verify actual behavior, not imagined behavior
5. **Maintain alignment**: Keep tests updated when code changes

This approach prevents the common pitfall of writing tests that pass in isolation but fail when run against the actual codebase, leading to more reliable and maintainable test suites.
