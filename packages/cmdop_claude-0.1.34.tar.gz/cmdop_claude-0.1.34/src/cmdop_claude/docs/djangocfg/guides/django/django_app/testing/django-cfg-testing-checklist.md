# ✅ Django-CFG Testing Checklist

## 🚀 Before Writing Tests

### 1. App Registration
- [ ] Added new app to `tests/settings.py` in `project_apps` list
- [ ] Verified management commands are discoverable
- [ ] Confirmed app models are available in tests

### 2. Test Environment Setup
- [ ] Using `tests.settings` (NOT project settings)
- [ ] DRF versioning disabled in test settings
- [ ] Database isolation configured (`databases = ['default']`)

## 🔧 Test Implementation

### 3. Authentication & Authorization
- [ ] Admin users created with `is_staff=True, is_superuser=True` for API tests
- [ ] `self.client.force_authenticate(user=self.user)` used for authenticated tests
- [ ] `self.client.force_authenticate(user=None)` used for unauthenticated tests
- [ ] API key authentication tested with proper headers (`HTTP_X_API_KEY`)

### 4. Model & Manager Testing
- [ ] Using actual model fields (not deprecated ones)
- [ ] Manager methods verified to exist before testing
- [ ] Foreign key relationships properly created in tests
- [ ] `model_validate()` and `model_dump()` used for Pydantic models

### 5. Database & Transactions
- [ ] `databases = ['default']` specified in test classes
- [ ] No references to external databases (`shop_db`, `blog_db`)
- [ ] Transaction fields use correct names (`amount_usd`, not `amount`)
- [ ] Proper field types and constraints respected

### 6. Import & Dependencies
- [ ] No inline imports in test methods
- [ ] All imports at top of file
- [ ] Correct import paths after code decomposition
- [ ] External dependencies properly mocked

## 🎯 Test Quality

### 7. Test Structure
- [ ] **🚨 CRITICAL: One test class per file** (never multiple classes in one file)
- [ ] Test files under 400 lines
- [ ] Test classes under 150 lines
- [ ] Descriptive test method names
- [ ] AAA pattern (Arrange, Act, Assert) followed
- [ ] Proper subdirectory structure for large test suites

### 8. Error Handling
- [ ] Both success and failure scenarios tested
- [ ] Proper exception types expected
- [ ] Error messages validated
- [ ] Edge cases covered

### 9. Performance & Reliability
- [ ] Shared fixtures used for class-level setup
- [ ] External API calls mocked
- [ ] No flaky timing dependencies
- [ ] Deterministic test results

## 🚨 Common Issues Checklist

### 10. Management Commands
- [ ] No `Unknown command` errors
- [ ] Commands registered in Django
- [ ] App in `INSTALLED_APPS` equivalent

### 11. Model Fields
- [ ] No `unexpected keyword arguments` errors
- [ ] Field names match actual model definitions
- [ ] Required fields provided in test data

### 12. Manager Methods
- [ ] No `object has no attribute` errors for managers
- [ ] Using existing manager methods or Django ORM
- [ ] Correct method signatures and return types

### 13. DRF & API Testing
- [ ] No versioning errors in API tests
- [ ] Correct URL patterns used
- [ ] Proper HTTP status codes expected
- [ ] Serializer fields match model fields

### 14. Cache & Services
- [ ] Correct import paths after decomposition
- [ ] Service methods return expected types
- [ ] Cache operations work as expected

## 🏃‍♂️ Running Tests

### 15. Test Execution
- [ ] `poetry run python run_tests.py` works (recommended)
- [ ] Individual app tests run successfully
- [ ] Non-interactive flags used (`--keepdb`, `--parallel auto`, `--noinput`)
- [ ] No hanging or interactive prompts

### 16. Test Results
- [ ] All tests pass (100% success rate)
- [ ] No database operation errors
- [ ] No import or module errors
- [ ] Performance acceptable

## 📝 Documentation

### 17. Test Documentation
- [ ] Test purpose clearly documented
- [ ] Complex test logic explained
- [ ] Setup requirements documented
- [ ] Known limitations noted

## 🔄 Continuous Integration

### 18. CI/CD Compatibility
- [ ] Tests run in CI environment
- [ ] No environment-specific dependencies
- [ ] Database migrations work in tests
- [ ] All required services available

---

## 🚀 Quick Commands Reference

```bash
# Register new app in tests/settings.py first!

# Run all tests (recommended)
poetry run python run_tests.py

# Run specific app tests
cd /path/to/django-cfg/src
poetry run python -m django test django_cfg.apps.your_app.tests --settings=tests.settings

# Non-interactive testing
poetry run python -m django test django_cfg.apps.your_app.tests \
    --settings=tests.settings \
    --verbosity=1 \
    --keepdb \
    --parallel auto \
    --noinput
```

## 🆘 Emergency Fixes

### If management commands not found:
1. Add app to `tests/settings.py` → `project_apps` list
2. Restart test runner

### If model field errors:
1. Check actual model definition
2. Use correct field names in tests
3. Verify field types and constraints

### If manager method errors:
1. Check manager class for actual methods
2. Use Django ORM methods as fallback
3. Verify method signatures

### If DRF versioning errors:
1. Set `DEFAULT_VERSIONING_CLASS = None` in test settings
2. Add `versioning_class = None` to ViewSets
3. Use correct URL patterns

### If database errors:
1. Add `databases = ['default']` to test classes
2. Use only default database in Django-CFG apps
3. Check for external database references
