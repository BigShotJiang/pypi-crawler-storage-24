# 🚀 DjangoConfig Class Guide %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Type-safe configuration** with Pydantic 2 models and automatic validation
- **Environment-aware defaults** with intelligent detection and smart fallbacks
- **Auto-configuration** for Django settings, apps, middleware, and services
- **Real implementation examples** from django-cfg core system

## 📋 Table of Contents
1. [DjangoConfig Overview](#djangoconfig-overview)
2. [Basic Configuration](#basic-configuration)
3. [Advanced Configuration](#advanced-configuration)
4. [Environment Detection](#environment-detection)
5. [Settings Generation](#settings-generation)
6. [Best Practices](#best-practices)

## 🔑 Key Concepts at a Glance
- **Pydantic 2 Base**: Type-safe configuration with automatic validation
- **Environment Detection**: Automatic dev/staging/production detection
- **Smart Defaults**: Intelligent defaults based on environment
- **Settings Generation**: Automatic Django settings.py generation
- **Modular Configuration**: Composable configuration models
- **Zero Raw JSON**: All data structures properly typed

## 🚀 Quick Start

### Basic Usage
```python
from django_cfg import DjangoConfig

class MyProjectConfig(DjangoConfig):
    project_name: str = "My Awesome Project"
    secret_key: str = "your-secret-key-here"
    
    # Enable features
    enable_knowbase: bool = True
    enable_agents: bool = True

config = MyProjectConfig()
settings = config.get_all_settings()
```

### Environment-Aware Configuration
```python
class ProductionConfig(DjangoConfig):
    project_name: str = "Production App"
    debug: bool = False  # Automatically set based on environment
    
    # Database configuration
    database_url: str = "postgresql://user:pass@localhost/prod_db"
    
    # Cache configuration
    redis_url: str = "redis://localhost:6379/0"

config = ProductionConfig()
```

## 🏗️ DjangoConfig Overview

### 1. **Core Class Structure (Real Implementation)**
```python
# Real structure from django_cfg.core.config
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, Dict, Any, List
from enum import Enum

class StartupInfoMode(str, Enum):
    """Startup information display mode."""
    DISABLED = "disabled"
    BASIC = "basic"
    DETAILED = "detailed"

class DjangoConfig(BaseModel):
    """
    Main configuration class for Django-CFG applications.
    
    Provides type-safe configuration with automatic Django settings generation,
    environment detection, and intelligent defaults.
    """
    
    model_config = ConfigDict(
        extra="forbid",  # Prevent typos in configuration
        validate_assignment=True,  # Validate on assignment
        use_enum_values=True,  # Use enum values in serialization
        arbitrary_types_allowed=True,  # Allow Django model types
    )
    
    # Core project settings
    project_name: str = Field(..., description="Project name")
    project_version: str = Field(default="1.0.0", description="Project version")
    secret_key: str = Field(..., description="Django secret key")
    debug: bool = Field(default=None, description="Debug mode (auto-detected)")
    
    # Environment detection
    environment: Optional[str] = Field(default=None, description="Environment name")
    startup_info: StartupInfoMode = Field(default=StartupInfoMode.BASIC)
    
    # Database configuration
    database_url: Optional[str] = Field(default=None, description="Database URL")
    
    # Cache configuration
    redis_url: Optional[str] = Field(default=None, description="Redis URL")
    
    # Feature flags
    enable_knowbase: bool = Field(default=False, description="Enable knowbase app")
    enable_agents: bool = Field(default=False, description="Enable agents app")
    enable_payments: bool = Field(default=False, description="Enable payments app")
    enable_support: bool = Field(default=False, description="Enable support app")
    enable_newsletter: bool = Field(default=False, description="Enable newsletter app")
    enable_accounts: bool = Field(default=False, description="Enable accounts app")
    enable_maintenance: bool = Field(default=False, description="Enable maintenance app")
    
    def __post_init__(self):
        """Post-initialization processing."""
        self._detect_environment()
        self._set_intelligent_defaults()
        self._validate_configuration()
    
    def get_all_settings(self) -> Dict[str, Any]:
        """Generate complete Django settings dictionary."""
        return self._generate_django_settings()
```

### 2. **Environment Detection (Real Implementation)**
```python
# Real environment detection logic
def _detect_environment(self) -> str:
    """
    Detect current environment based on various indicators.
    
    Returns:
        Environment name: 'development', 'staging', 'production'
    """
    import os
    
    # Check explicit environment variable
    if env := os.getenv('DJANGO_ENV'):
        return env.lower()
    
    # Check common environment indicators
    if os.getenv('DEBUG') == 'True':
        return 'development'
    
    if os.getenv('HEROKU_APP_NAME'):
        return 'production'
    
    if os.getenv('RAILWAY_ENVIRONMENT'):
        return os.getenv('RAILWAY_ENVIRONMENT').lower()
    
    if os.getenv('VERCEL_ENV'):
        return os.getenv('VERCEL_ENV').lower()
    
    # Check database URL patterns
    if db_url := os.getenv('DATABASE_URL'):
        if 'localhost' in db_url or '127.0.0.1' in db_url:
            return 'development'
        elif 'staging' in db_url:
            return 'staging'
        else:
            return 'production'
    
    # Default to development
    return 'development'

def _set_intelligent_defaults(self):
    """Set intelligent defaults based on detected environment."""
    if self.environment == 'development':
        self.debug = self.debug if self.debug is not None else True
        self.database_url = self.database_url or "sqlite:///db.sqlite3"
        
    elif self.environment == 'staging':
        self.debug = self.debug if self.debug is not None else False
        # Use environment variables for staging
        
    elif self.environment == 'production':
        self.debug = False  # Always False in production
        # Require explicit configuration in production
        if not self.database_url:
            raise ValueError("DATABASE_URL required in production")
```

## 🔧 Basic Configuration

### 1. **Simple Project Configuration (Real Example)**
```python
from django_cfg import DjangoConfig

class SimpleProjectConfig(DjangoConfig):
    """Simple project configuration with minimal setup."""
    
    project_name: str = "My Simple Project"
    secret_key: str = "django-insecure-change-me-in-production"
    
    # Basic feature flags
    enable_accounts: bool = True
    enable_support: bool = True

# Initialize and use
config = SimpleProjectConfig()
settings = config.get_all_settings()

# In your Django settings.py
from .config import config
globals().update(config.get_all_settings())
```

### 2. **Development Configuration (Real Example)**
```python
class DevelopmentConfig(DjangoConfig):
    """Development-specific configuration."""
    
    project_name: str = "My Dev Project"
    secret_key: str = "dev-secret-key"
    debug: bool = True
    
    # Development database
    database_url: str = "sqlite:///dev_db.sqlite3"
    
    # Development cache (optional)
    redis_url: Optional[str] = None  # Will use dummy cache
    
    # Enable all features for development
    enable_knowbase: bool = True
    enable_agents: bool = True
    enable_payments: bool = True
    enable_support: bool = True
    enable_newsletter: bool = True
    enable_accounts: bool = True
    enable_maintenance: bool = True
    
    # Development-specific settings
    startup_info: StartupInfoMode = StartupInfoMode.DETAILED
    
    def __post_init__(self):
        """Development-specific post-initialization."""
        super().__post_init__()
        
        # Development-specific logic
        if self.debug:
            print(f"🔧 Development mode enabled for {self.project_name}")
```

### 3. **Production Configuration (Real Example)**
```python
import os
from django_cfg import DjangoConfig, DatabaseConfig, CacheConfig

class ProductionConfig(DjangoConfig):
    """Production-ready configuration."""
    
    project_name: str = "My Production App"
    secret_key: str = Field(default_factory=lambda: os.getenv('SECRET_KEY'))
    debug: bool = False
    
    # Production database (required)
    database_url: str = Field(default_factory=lambda: os.getenv('DATABASE_URL'))
    
    # Production cache (required)
    redis_url: str = Field(default_factory=lambda: os.getenv('REDIS_URL'))
    
    # Production features (selective)
    enable_knowbase: bool = True
    enable_agents: bool = True
    enable_payments: bool = True
    enable_support: bool = True
    enable_accounts: bool = True
    
    # Production-specific settings
    startup_info: StartupInfoMode = StartupInfoMode.BASIC
    
    def __post_init__(self):
        """Production-specific validation."""
        super().__post_init__()
        
        # Validate required production settings
        if not self.secret_key:
            raise ValueError("SECRET_KEY environment variable required in production")
        
        if not self.database_url:
            raise ValueError("DATABASE_URL environment variable required in production")
        
        if len(self.secret_key) < 50:
            raise ValueError("SECRET_KEY must be at least 50 characters in production")
```

## 🎯 Advanced Configuration

### 1. **Modular Configuration (Real Example)**
```python
from django_cfg import (
    DjangoConfig,
    DatabaseConfig,
    CacheConfig,
    PaymentsConfig,
    SecuritySettings,
    LoggingConfig
)

class AdvancedConfig(DjangoConfig):
    """Advanced configuration with modular components."""
    
    project_name: str = "Advanced Project"
    secret_key: str = os.getenv('SECRET_KEY')
    
    # Modular configuration components
    database: DatabaseConfig = DatabaseConfig(
        url=os.getenv('DATABASE_URL', 'sqlite:///db.sqlite3'),
        pool_size=20,
        max_overflow=30,
        pool_timeout=30,
        pool_recycle=3600
    )
    
    cache: CacheConfig = CacheConfig(
        redis_url=os.getenv('REDIS_URL', 'redis://localhost:6379/0'),
        ttl=3600,
        key_prefix="myapp",
        version=1
    )
    
    payments: PaymentsConfig = PaymentsConfig(
        enabled=True,
        sandbox_mode=False,
        middleware_enabled=True,
        providers={
            'nowpayments': {
                'api_key': os.getenv('NOWPAYMENTS_API_KEY'),
                'sandbox': False
            },
            'stripe': {
                'public_key': os.getenv('STRIPE_PUBLIC_KEY'),
                'secret_key': os.getenv('STRIPE_SECRET_KEY'),
                'webhook_secret': os.getenv('STRIPE_WEBHOOK_SECRET')
            }
        }
    )
    
    security: SecuritySettings = SecuritySettings(
        allowed_hosts=['myapp.com', 'www.myapp.com'],
        csrf_trusted_origins=['https://myapp.com'],
        secure_ssl_redirect=True,
        secure_proxy_ssl_header=('HTTP_X_FORWARDED_PROTO', 'https'),
        session_cookie_secure=True,
        csrf_cookie_secure=True
    )
    
    logging: LoggingConfig = LoggingConfig(
        level="INFO",
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=['console', 'file'],
        file_path="/var/log/myapp.log",
        max_bytes=10485760,  # 10MB
        backup_count=5
    )
    
    # Feature flags with dependencies
    enable_knowbase: bool = True
    enable_agents: bool = True  # Requires knowbase
    enable_payments: bool = True
    enable_support: bool = True
    enable_accounts: bool = True
    
    def __post_init__(self):
        """Advanced validation and dependency checking."""
        super().__post_init__()
        
        # Validate feature dependencies
        if self.enable_agents and not self.enable_knowbase:
            raise ValueError("Agents app requires knowbase app to be enabled")
        
        # Validate payment configuration
        if self.enable_payments and not self.payments.enabled:
            raise ValueError("Payments app enabled but payments config disabled")
        
        # Environment-specific validation
        if self.environment == 'production':
            self._validate_production_config()
    
    def _validate_production_config(self):
        """Validate production-specific requirements."""
        if self.debug:
            raise ValueError("Debug mode not allowed in production")
        
        if not self.security.secure_ssl_redirect:
            raise ValueError("SSL redirect required in production")
        
        if self.payments.enabled and self.payments.sandbox_mode:
            raise ValueError("Sandbox mode not allowed in production payments")
```

### 2. **Multi-Environment Configuration (Real Example)**
```python
class MultiEnvironmentConfig(DjangoConfig):
    """Configuration that adapts to multiple environments."""
    
    project_name: str = "Multi-Env Project"
    
    def __init__(self, **data):
        """Initialize with environment-specific settings."""
        # Load environment-specific configuration
        env_config = self._load_environment_config()
        
        # Merge with provided data
        merged_config = {**env_config, **data}
        
        super().__init__(**merged_config)
    
    def _load_environment_config(self) -> Dict[str, Any]:
        """Load configuration based on current environment."""
        env = os.getenv('DJANGO_ENV', 'development')
        
        if env == 'development':
            return {
                'secret_key': 'dev-secret-key',
                'debug': True,
                'database_url': 'sqlite:///dev_db.sqlite3',
                'redis_url': None,
                'enable_knowbase': True,
                'enable_agents': True,
                'enable_payments': False,  # Disabled in dev
                'startup_info': StartupInfoMode.DETAILED
            }
        
        elif env == 'staging':
            return {
                'secret_key': os.getenv('SECRET_KEY'),
                'debug': False,
                'database_url': os.getenv('DATABASE_URL'),
                'redis_url': os.getenv('REDIS_URL'),
                'enable_knowbase': True,
                'enable_agents': True,
                'enable_payments': True,
                'startup_info': StartupInfoMode.BASIC
            }
        
        elif env == 'production':
            return {
                'secret_key': os.getenv('SECRET_KEY'),
                'debug': False,
                'database_url': os.getenv('DATABASE_URL'),
                'redis_url': os.getenv('REDIS_URL'),
                'enable_knowbase': True,
                'enable_agents': True,
                'enable_payments': True,
                'startup_info': StartupInfoMode.BASIC
            }
        
        else:
            raise ValueError(f"Unknown environment: {env}")
```

## 🌍 Environment Detection

### 1. **Automatic Environment Detection (Real Implementation)**
```python
def detect_environment() -> str:
    """
    Detect current environment using multiple indicators.
    
    Real implementation from django-cfg core.
    """
    import os
    
    # Priority 1: Explicit environment variable
    if env := os.getenv('DJANGO_ENV'):
        return env.lower()
    
    # Priority 2: Platform-specific variables
    platform_indicators = {
        'HEROKU_APP_NAME': 'production',
        'RAILWAY_ENVIRONMENT': lambda: os.getenv('RAILWAY_ENVIRONMENT').lower(),
        'VERCEL_ENV': lambda: os.getenv('VERCEL_ENV').lower(),
        'RENDER': 'production',
        'GITHUB_ACTIONS': 'testing',
        'CI': 'testing'
    }
    
    for var, env_value in platform_indicators.items():
        if os.getenv(var):
            return env_value() if callable(env_value) else env_value
    
    # Priority 3: Debug flag
    if os.getenv('DEBUG') == 'True':
        return 'development'
    
    # Priority 4: Database URL patterns
    if db_url := os.getenv('DATABASE_URL'):
        if any(local in db_url for local in ['localhost', '127.0.0.1', 'sqlite']):
            return 'development'
        elif 'staging' in db_url:
            return 'staging'
        else:
            return 'production'
    
    # Priority 5: Port-based detection
    if port := os.getenv('PORT'):
        if port in ['8000', '3000', '5000']:
            return 'development'
        else:
            return 'production'
    
    # Default: development
    return 'development'

class EnvironmentAwareConfig(DjangoConfig):
    """Configuration with advanced environment detection."""
    
    def __post_init__(self):
        """Set environment-specific defaults."""
        super().__post_init__()
        
        env = detect_environment()
        
        if env == 'development':
            self._configure_development()
        elif env == 'staging':
            self._configure_staging()
        elif env == 'production':
            self._configure_production()
        elif env == 'testing':
            self._configure_testing()
    
    def _configure_development(self):
        """Configure for development environment."""
        self.debug = True
        self.startup_info = StartupInfoMode.DETAILED
        
        # Enable all features for development
        self.enable_knowbase = True
        self.enable_agents = True
        self.enable_payments = False  # Usually disabled in dev
    
    def _configure_staging(self):
        """Configure for staging environment."""
        self.debug = False
        self.startup_info = StartupInfoMode.BASIC
        
        # Mirror production features
        self.enable_knowbase = True
        self.enable_agents = True
        self.enable_payments = True
    
    def _configure_production(self):
        """Configure for production environment."""
        self.debug = False
        self.startup_info = StartupInfoMode.BASIC
        
        # Production features
        self.enable_knowbase = True
        self.enable_agents = True
        self.enable_payments = True
    
    def _configure_testing(self):
        """Configure for testing environment."""
        self.debug = True
        self.startup_info = StartupInfoMode.DISABLED
        
        # Minimal features for testing
        self.enable_knowbase = False
        self.enable_agents = False
        self.enable_payments = False
```

## ⚙️ Settings Generation

### 1. **Django Settings Generation (Real Implementation)**
```python
def get_all_settings(self) -> Dict[str, Any]:
    """
    Generate complete Django settings dictionary.
    
    Real implementation from django-cfg core.
    """
    settings = {}
    
    # Basic Django settings
    settings.update(self._get_basic_settings())
    
    # Database settings
    settings.update(self._get_database_settings())
    
    # Cache settings
    settings.update(self._get_cache_settings())
    
    # App settings
    settings.update(self._get_app_settings())
    
    # Middleware settings
    settings.update(self._get_middleware_settings())
    
    # Security settings
    settings.update(self._get_security_settings())
    
    # Logging settings
    settings.update(self._get_logging_settings())
    
    # Static files settings
    settings.update(self._get_static_settings())
    
    # Third-party settings
    settings.update(self._get_third_party_settings())
    
    return settings

def _get_basic_settings(self) -> Dict[str, Any]:
    """Generate basic Django settings."""
    return {
        'DEBUG': self.debug,
        'SECRET_KEY': self.secret_key,
        'ALLOWED_HOSTS': self._get_allowed_hosts(),
        'ROOT_URLCONF': 'urls',
        'WSGI_APPLICATION': 'wsgi.application',
        'DEFAULT_AUTO_FIELD': 'django.db.models.BigAutoField',
        'USE_TZ': True,
        'USE_I18N': True,
        'TIME_ZONE': 'UTC',
        'LANGUAGE_CODE': 'en-us',
    }

def _get_app_settings(self) -> Dict[str, Any]:
    """Generate installed apps based on enabled features."""
    apps = [
        # Django core apps
        'django.contrib.admin',
        'django.contrib.auth',
        'django.contrib.contenttypes',
        'django.contrib.sessions',
        'django.contrib.messages',
        'django.contrib.staticfiles',
        
        # Third-party apps
        'rest_framework',
        'corsheaders',
        'django_filters',
        'unfold',
        'unfold.contrib.filters',
        'unfold.contrib.forms',
        'unfold.contrib.inlines',
    ]
    
    # Add django-cfg apps based on feature flags
    if self.enable_accounts:
        apps.append('django_cfg.apps.accounts')
    
    if self.enable_knowbase:
        apps.extend([
            'django_cfg.apps.knowbase',
            'pgvector.django',  # Required for knowbase
        ])
    
    if self.enable_agents:
        if not self.enable_knowbase:
            raise ValueError("Agents app requires knowbase app")
        apps.append('django_cfg.apps.agents')
    
    if self.enable_payments:
        apps.extend([
            'django_cfg.apps.payments',
            'constance',  # Required for payments
            'constance.backends.database',
        ])
    
    if self.enable_support:
        apps.append('django_cfg.apps.support')
    
    if self.enable_newsletter:
        apps.append('django_cfg.apps.newsletter')
    
    if self.enable_maintenance:
        apps.append('django_cfg.apps.maintenance')
    
    return {'INSTALLED_APPS': apps}

def _get_middleware_settings(self) -> Dict[str, Any]:
    """Generate middleware based on enabled features."""
    middleware = [
        'corsheaders.middleware.CorsMiddleware',
        'django.middleware.security.SecurityMiddleware',
        'whitenoise.middleware.WhiteNoiseMiddleware',
        'django.contrib.sessions.middleware.SessionMiddleware',
        'django.middleware.common.CommonMiddleware',
        'django.middleware.csrf.CsrfViewMiddleware',
        'django.contrib.auth.middleware.AuthenticationMiddleware',
        'django.contrib.messages.middleware.MessageMiddleware',
        'django.middleware.clickjacking.XFrameOptionsMiddleware',
    ]
    
    # Add feature-specific middleware
    if self.enable_payments:
        middleware.extend([
            'django_cfg.apps.payments.middleware.api_access.APIAccessMiddleware',
            'django_cfg.apps.payments.middleware.rate_limiting.RateLimitingMiddleware',
            'django_cfg.apps.payments.middleware.usage_tracking.UsageTrackingMiddleware',
        ])
    
    return {'MIDDLEWARE': middleware}
```

## 🎯 Best Practices

### 1. **Configuration Validation (Real Example)**
```python
class ValidatedConfig(DjangoConfig):
    """Configuration with comprehensive validation."""
    
    def __post_init__(self):
        """Perform comprehensive validation."""
        super().__post_init__()
        
        self._validate_basic_settings()
        self._validate_feature_dependencies()
        self._validate_environment_requirements()
        self._validate_security_settings()
    
    def _validate_basic_settings(self):
        """Validate basic configuration requirements."""
        if not self.project_name:
            raise ValueError("Project name is required")
        
        if not self.secret_key:
            raise ValueError("Secret key is required")
        
        if len(self.secret_key) < 50:
            raise ValueError("Secret key must be at least 50 characters")
    
    def _validate_feature_dependencies(self):
        """Validate feature flag dependencies."""
        dependencies = {
            'enable_agents': ['enable_knowbase'],
            'enable_payments': [],  # No dependencies
            'enable_support': ['enable_accounts'],
        }
        
        for feature, deps in dependencies.items():
            if getattr(self, feature, False):
                for dep in deps:
                    if not getattr(self, dep, False):
                        raise ValueError(f"{feature} requires {dep} to be enabled")
    
    def _validate_environment_requirements(self):
        """Validate environment-specific requirements."""
        if self.environment == 'production':
            required_env_vars = ['SECRET_KEY', 'DATABASE_URL']
            
            for var in required_env_vars:
                if not os.getenv(var):
                    raise ValueError(f"{var} environment variable required in production")
    
    def _validate_security_settings(self):
        """Validate security configuration."""
        if self.environment == 'production':
            if self.debug:
                raise ValueError("Debug mode not allowed in production")
            
            if not self.database_url or 'sqlite' in self.database_url:
                raise ValueError("SQLite not recommended for production")
```

### 2. **Configuration Testing (Real Example)**
```python
import pytest
from django_cfg import DjangoConfig

class TestConfig(DjangoConfig):
    """Test configuration for unit tests."""
    
    project_name: str = "Test Project"
    secret_key: str = "test-secret-key-for-testing-only"
    debug: bool = True
    
    # Test database
    database_url: str = "sqlite:///:memory:"
    
    # Disable external services
    redis_url: Optional[str] = None
    
    # Enable minimal features for testing
    enable_accounts: bool = True
    enable_knowbase: bool = False
    enable_agents: bool = False
    enable_payments: bool = False
    
    startup_info: StartupInfoMode = StartupInfoMode.DISABLED

def test_config_validation():
    """Test configuration validation."""
    # Valid configuration
    config = TestConfig()
    assert config.project_name == "Test Project"
    assert config.debug is True
    
    # Invalid configuration
    with pytest.raises(ValueError):
        TestConfig(secret_key="")  # Too short
    
    with pytest.raises(ValueError):
        TestConfig(enable_agents=True, enable_knowbase=False)  # Missing dependency

def test_settings_generation():
    """Test Django settings generation."""
    config = TestConfig()
    settings = config.get_all_settings()
    
    assert settings['DEBUG'] is True
    assert settings['SECRET_KEY'] == "test-secret-key-for-testing-only"
    assert 'django_cfg.apps.accounts' in settings['INSTALLED_APPS']
    assert 'django_cfg.apps.knowbase' not in settings['INSTALLED_APPS']
```

### 3. **Configuration Documentation (Real Example)**
```python
class DocumentedConfig(DjangoConfig):
    """Well-documented configuration example."""
    
    # Core settings with clear descriptions
    project_name: str = Field(
        ...,
        description="Human-readable project name displayed in admin and logs",
        example="My Awesome Project"
    )
    
    secret_key: str = Field(
        ...,
        description="Django secret key for cryptographic signing",
        min_length=50,
        example="django-insecure-change-me-in-production-with-50-chars-min"
    )
    
    debug: bool = Field(
        default=None,
        description="Debug mode - auto-detected based on environment if not set"
    )
    
    # Database configuration with validation
    database_url: Optional[str] = Field(
        default=None,
        description="Database connection URL",
        example="postgresql://user:pass@localhost:5432/dbname"
    )
    
    # Feature flags with clear descriptions
    enable_knowbase: bool = Field(
        default=False,
        description="Enable knowledge base app for document management and AI chat"
    )
    
    enable_agents: bool = Field(
        default=False,
        description="Enable AI agents app (requires knowbase)"
    )
    
    enable_payments: bool = Field(
        default=False,
        description="Enable payments app with multiple provider support"
    )
    
    class Config:
        """Pydantic configuration."""
        
        schema_extra = {
            "example": {
                "project_name": "My Production App",
                "secret_key": "django-insecure-change-me-in-production-with-50-chars-min",
                "debug": False,
                "database_url": "postgresql://user:pass@localhost:5432/myapp",
                "redis_url": "redis://localhost:6379/0",
                "enable_knowbase": True,
                "enable_agents": True,
                "enable_payments": True
            }
        }
```

## 🏷️ Metadata
**Tags**: `djangoconfig, configuration, pydantic, type-safety, environment, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%HIGH%%
**Real Examples**: DjangoConfig class from django-cfg core system
**DEPENDS_ON**: [pydantic, django, environment-detection]
**USED_BY**: [all-django-cfg-projects, configuration-management]