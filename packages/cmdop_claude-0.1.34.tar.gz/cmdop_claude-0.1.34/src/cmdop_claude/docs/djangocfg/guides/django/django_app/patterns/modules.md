# 🧩 Django-CFG Modules Guide %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Auto-configuring modules** that integrate seamlessly with DjangoConfig
- **Type-safe utilities** with Pydantic 2 integration for common Django needs
- **Zero setup required** - import and use immediately
- **Real examples** from currency, logger, LLM, email, and other production modules

## 📋 Table of Contents
1. [Module Architecture](#module-architecture)
2. [Core Modules](#core-modules)
3. [Communication Modules](#communication-modules)
4. [Data Processing Modules](#data-processing-modules)
5. [Development Tools](#development-tools)

## 🔑 Key Concepts at a Glance
- **Auto-Configuration**: Modules receive config from DjangoConfig automatically
- **Type Safety**: All modules use Pydantic 2 for data validation
- **Zero Setup**: Import and use - no manual configuration needed
- **BaseCfgModule**: Common base class for all django-cfg modules
- **Environment Aware**: Automatic development vs production behavior

## 🚀 Quick Start

### Basic Module Usage
```python
# Import any module - auto-configured from DjangoConfig
from django_cfg.modules.django_currency import convert_currency
from django_cfg.modules.django_logger import get_logger
from django_cfg.modules.django_llm import LLMClient

# Use immediately - no setup required
eur_amount = convert_currency(100, "USD", "EUR")
logger = get_logger(__name__)
llm_client = LLMClient()
```

## 🏗️ Module Architecture

### 1. **BaseCfgModule Pattern (Real Implementation)**
```python
# modules/base.py - Foundation for all modules
from abc import ABC
from typing import Optional, TYPE_CHECKING
from django_cfg.modules.django_logger import get_logger

if TYPE_CHECKING:
    from django_cfg.core.config import DjangoConfig

logger = get_logger(__name__)

class BaseCfgModule(ABC):
    """
    Base class for all django-cfg modules.
    
    Provides common functionality and configuration access.
    Auto-discovers configuration from Django settings.
    """
    
    _config_instance: Optional["DjangoConfig"] = None
    
    @classmethod
    def get_config(cls) -> Optional["DjangoConfig"]:
        """Get the DjangoConfig instance automatically."""
        if cls._config_instance is None:
            cls._config_instance = cls._discover_config()
        return cls._config_instance
    
    @classmethod
    def _discover_config(cls) -> Optional["DjangoConfig"]:
        """Discover config from Django settings module."""
        try:
            from django.conf import settings
            
            # Try to get config from settings
            if hasattr(settings, 'DJANGO_CFG_CONFIG'):
                return settings.DJANGO_CFG_CONFIG
            
            # Try to import from settings module
            settings_module = getattr(settings, 'SETTINGS_MODULE', None)
            if settings_module:
                module = __import__(settings_module, fromlist=['config'])
                if hasattr(module, 'config'):
                    return module.config
            
            return None
            
        except Exception as e:
            logger.debug(f"Could not discover config: {e}")
            return None
```

### 2. **Auto-Configuration Flow**
```python
# Real example from django_currency module
class CurrencyConverter(BaseCfgModule):
    """Universal currency converter with auto-configuration."""
    
    def __init__(self):
        """Initialize with auto-discovered configuration."""
        self.config = self.get_config()
        
        # Use config if available, otherwise defaults
        if self.config and hasattr(self.config, 'currency'):
            self.cache_ttl = self.config.currency.cache_ttl
            self.providers = self.config.currency.providers
        else:
            self.cache_ttl = 300  # 5 minutes default
            self.providers = ['yfinance', 'coingecko']
        
        # Initialize cache manager
        self.cache_manager = CacheManager(ttl=self.cache_ttl)
```

## 🔧 Core Modules

### 1. **django_logger - Auto-Configuring Logger**
```python
# Real implementation from django_cfg/modules/django_logger
from typing import Optional
import logging
import sys

def get_logger(name: str, level: Optional[str] = None) -> logging.Logger:
    """
    Get a configured logger instance.
    
    Args:
        name: Logger name (usually __name__)
        level: Optional log level override
        
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)
    
    # Don't reconfigure if already configured
    if logger.handlers:
        return logger
    
    # Auto-detect environment for formatting
    try:
        from django.conf import settings
        debug = getattr(settings, 'DEBUG', False)
    except:
        debug = True
    
    # Environment-aware formatting
    if debug:
        # Development: detailed formatting
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    else:
        # Production: structured logging
        formatter = logging.Formatter(
            '{"timestamp": "%(asctime)s", "logger": "%(name)s", "level": "%(levelname)s", "message": "%(message)s"}'
        )
    
    # Console handler
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    
    # Set level
    log_level = level or ('DEBUG' if debug else 'INFO')
    logger.setLevel(getattr(logging, log_level.upper()))
    
    return logger

# Usage examples
logger = get_logger(__name__)
logger.info("Application started")  # Formatted for environment
```

### 2. **django_health - Health Check System**
```python
# Real pattern from django_cfg health checks
from typing import Dict, Any, List
from django_cfg.modules.base import BaseCfgModule
from django_cfg.modules.django_logger import get_logger

logger = get_logger(__name__)

class HealthChecker(BaseCfgModule):
    """System health monitoring with auto-configuration."""
    
    def __init__(self):
        """Initialize health checker."""
        self.config = self.get_config()
        self.checks = []
        
        # Auto-register checks based on enabled features
        self._register_default_checks()
    
    def _register_default_checks(self):
        """Register default health checks."""
        self.checks = [
            self._check_database,
            self._check_cache,
        ]
        
        # Add feature-specific checks
        if self.config:
            if hasattr(self.config, 'payments') and self.config.payments.enabled:
                self.checks.append(self._check_payments)
            
            if hasattr(self.config, 'enable_knowbase') and self.config.enable_knowbase:
                self.checks.append(self._check_knowbase)
    
    def get_system_health(self) -> Dict[str, Any]:
        """Get comprehensive system health status."""
        results = {}
        overall_healthy = True
        
        for check in self.checks:
            try:
                check_name = check.__name__.replace('_check_', '')
                result = check()
                results[check_name] = result
                
                if not result.get('healthy', False):
                    overall_healthy = False
                    
            except Exception as e:
                logger.error(f"Health check failed: {check.__name__}: {e}")
                results[check.__name__] = {
                    'healthy': False,
                    'error': str(e)
                }
                overall_healthy = False
        
        return {
            'healthy': overall_healthy,
            'checks': results,
            'timestamp': timezone.now().isoformat()
        }
    
    def _check_database(self) -> Dict[str, Any]:
        """Check database connectivity."""
        try:
            from django.db import connection
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
                return {'healthy': True, 'response_time_ms': 0}
        except Exception as e:
            return {'healthy': False, 'error': str(e)}
    
    def _check_cache(self) -> Dict[str, Any]:
        """Check cache connectivity."""
        try:
            from django.core.cache import cache
            test_key = 'health_check'
            cache.set(test_key, 'ok', 10)
            result = cache.get(test_key)
            cache.delete(test_key)
            
            return {
                'healthy': result == 'ok',
                'backend': cache.__class__.__name__
            }
        except Exception as e:
            return {'healthy': False, 'error': str(e)}
```

## 📡 Communication Modules

### 1. **django_email - Email Service**
```python
# Real pattern from django_cfg email module
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, EmailStr
from django_cfg.modules.base import BaseCfgModule
from django_cfg.modules.django_logger import get_logger

logger = get_logger(__name__)

class EmailMessage(BaseModel):
    """Type-safe email message."""
    to: List[EmailStr] = Field(..., description="Recipient emails")
    subject: str = Field(..., min_length=1, max_length=200)
    html_content: Optional[str] = None
    text_content: Optional[str] = None
    attachments: List[str] = Field(default_factory=list)
    template: Optional[str] = None
    context: Dict[str, Any] = Field(default_factory=dict)

class EmailService(BaseCfgModule):
    """Email service with auto-configuration."""
    
    def __init__(self):
        """Initialize email service."""
        self.config = self.get_config()
        
        # Auto-configure based on django-cfg settings
        if self.config and hasattr(self.config, 'email'):
            self.enabled = self.config.email.enabled
            self.backend = self.config.email.backend
        else:
            self.enabled = True
            self.backend = 'django.core.mail.backends.console.EmailBackend'
    
    def send_email(self, message: EmailMessage) -> bool:
        """Send email with type safety."""
        if not self.enabled:
            logger.debug("Email sending disabled")
            return False
        
        try:
            from django.core.mail import EmailMultiAlternatives
            from django.template.loader import render_to_string
            
            # Render template if specified
            if message.template:
                html_content = render_to_string(message.template, message.context)
                text_content = render_to_string(
                    message.template.replace('.html', '.txt'), 
                    message.context
                )
            else:
                html_content = message.html_content
                text_content = message.text_content
            
            # Create email
            email = EmailMultiAlternatives(
                subject=message.subject,
                body=text_content or '',
                to=message.to
            )
            
            if html_content:
                email.attach_alternative(html_content, "text/html")
            
            # Add attachments
            for attachment_path in message.attachments:
                email.attach_file(attachment_path)
            
            # Send email
            email.send()
            logger.info(f"Email sent to {len(message.to)} recipients")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send email: {e}")
            return False

# Simple API
def send_email(to: str, subject: str, template: str = None, context: Dict[str, Any] = None, **kwargs) -> bool:
    """Simple email sending API."""
    service = EmailService()
    message = EmailMessage(
        to=[to],
        subject=subject,
        template=template,
        context=context or {},
        **kwargs
    )
    return service.send_email(message)
```

### 2. **django_telegram - Telegram Integration**
```python
# Real pattern from django_cfg telegram module
from typing import Optional, Dict, Any, List
from pydantic import BaseModel
from django_cfg.modules.base import BaseCfgModule
from django_cfg.modules.django_logger import get_logger

logger = get_logger(__name__)

class TelegramMessage(BaseModel):
    """Type-safe Telegram message."""
    chat_id: int
    text: str
    parse_mode: Optional[str] = 'HTML'
    reply_markup: Optional[Dict[str, Any]] = None

class TelegramBot(BaseCfgModule):
    """Telegram bot with auto-configuration."""
    
    def __init__(self):
        """Initialize Telegram bot."""
        self.config = self.get_config()
        
        # Auto-configure from django-cfg
        if self.config and hasattr(self.config, 'telegram'):
            self.bot_token = self.config.telegram.bot_token
            self.enabled = self.config.telegram.enabled
        else:
            self.bot_token = None
            self.enabled = False
    
    def send_message(self, chat_id: int, text: str, **kwargs) -> bool:
        """Send Telegram message."""
        if not self.enabled or not self.bot_token:
            logger.debug("Telegram bot not configured")
            return False
        
        try:
            import requests
            
            url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            data = {
                'chat_id': chat_id,
                'text': text,
                'parse_mode': kwargs.get('parse_mode', 'HTML')
            }
            
            if 'reply_markup' in kwargs:
                data['reply_markup'] = kwargs['reply_markup']
            
            response = requests.post(url, json=data)
            response.raise_for_status()
            
            logger.info(f"Telegram message sent to chat {chat_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send Telegram message: {e}")
            return False
```

## 💱 Data Processing Modules

### 1. **django_currency - Universal Currency Converter (Real Implementation)**
```python
# Real implementation from django_cfg/modules/django_currency
from typing import Optional, Dict, Any, List
from decimal import Decimal
from pydantic import BaseModel
from django_cfg.modules.base import BaseCfgModule
from django_cfg.modules.django_logger import get_logger

logger = get_logger(__name__)

class Rate(BaseModel):
    """Currency conversion rate."""
    base_currency: str
    quote_currency: str
    rate: Decimal
    source: str
    timestamp: float

class ConversionResult(BaseModel):
    """Currency conversion result."""
    amount: Decimal
    base_currency: str
    quote_currency: str
    converted_amount: Decimal
    rate: Rate

class CurrencyConverter(BaseCfgModule):
    """Universal currency converter with caching."""
    
    def __init__(self):
        """Initialize converter with auto-configuration."""
        self.config = self.get_config()
        
        # Auto-configure from django-cfg
        if self.config and hasattr(self.config, 'currency'):
            self.cache_ttl = self.config.currency.cache_ttl
            self.providers = self.config.currency.providers
        else:
            self.cache_ttl = 300  # 5 minutes default
            self.providers = ['yfinance', 'coingecko']
        
        # Initialize cache
        from .utils.cache import CacheManager
        self.cache_manager = CacheManager(ttl=self.cache_ttl)
    
    def convert(self, amount: float, base: str, quote: str) -> ConversionResult:
        """Convert currency with caching."""
        amount_decimal = Decimal(str(amount))
        
        # Check cache first
        rate = self.cache_manager.get_rate(base, quote, 'cached')
        
        if not rate:
            # Fetch fresh rate
            rate = self._fetch_rate(base, quote)
            if rate:
                self.cache_manager.set_rate(rate)
        
        if not rate:
            raise ValueError(f"Could not get rate for {base}/{quote}")
        
        converted_amount = amount_decimal * rate.rate
        
        return ConversionResult(
            amount=amount_decimal,
            base_currency=base,
            quote_currency=quote,
            converted_amount=converted_amount,
            rate=rate
        )
    
    def _fetch_rate(self, base: str, quote: str) -> Optional[Rate]:
        """Fetch rate from providers."""
        for provider in self.providers:
            try:
                if provider == 'yfinance':
                    return self._fetch_yfinance_rate(base, quote)
                elif provider == 'coingecko':
                    return self._fetch_coingecko_rate(base, quote)
            except Exception as e:
                logger.warning(f"Provider {provider} failed: {e}")
                continue
        
        return None

# Simple API
def convert_currency(amount: float, base: str, quote: str) -> float:
    """Simple currency conversion API."""
    converter = CurrencyConverter()
    result = converter.convert(amount, base, quote)
    return float(result.converted_amount)
```

### 2. **django_llm - LLM Integration (Real Implementation)**
```python
# Real implementation from django_cfg/modules/django_llm
from typing import List, Dict, Any, Optional
from pydantic import BaseModel
from django_cfg.modules.base import BaseCfgModule
from django_cfg.modules.django_logger import get_logger

logger = get_logger(__name__)

class ChatMessage(BaseModel):
    """Chat message for LLM."""
    role: str  # 'user', 'assistant', 'system'
    content: str

class LLMResponse(BaseModel):
    """LLM response with metadata."""
    content: str
    model: str
    usage: Dict[str, int]
    cost_usd: Optional[float] = None

class LLMClient(BaseCfgModule):
    """Multi-provider LLM client with cost tracking."""
    
    def __init__(self):
        """Initialize LLM client."""
        self.config = self.get_config()
        
        # Auto-configure from django-cfg
        if self.config and hasattr(self.config, 'llm'):
            self.openai_api_key = self.config.llm.openai_api_key
            self.openrouter_api_key = self.config.llm.openrouter_api_key
            self.cache_enabled = self.config.llm.cache_enabled
        else:
            self.openai_api_key = None
            self.openrouter_api_key = None
            self.cache_enabled = True
        
        # Initialize cache
        if self.cache_enabled:
            from .llm.cache import LLMCache
            self.cache = LLMCache()
        else:
            self.cache = None
    
    def chat_completion(self, messages: List[Dict[str, str]], model: str = "openai/gpt-4o-mini", **kwargs) -> LLMResponse:
        """Get chat completion with caching."""
        # Check cache first
        if self.cache:
            request_hash = self.cache.generate_request_hash(messages, model, **kwargs)
            cached_response = self.cache.get_response(request_hash)
            if cached_response:
                logger.debug(f"LLM cache hit for model {model}")
                return LLMResponse(**cached_response)
        
        # Make API call
        response = self._make_api_call(messages, model, **kwargs)
        
        # Cache response
        if self.cache and response:
            self.cache.set_response(request_hash, response.model_dump(), model)
        
        return response
    
    def _make_api_call(self, messages: List[Dict[str, str]], model: str, **kwargs) -> LLMResponse:
        """Make API call to LLM provider."""
        try:
            if model.startswith('openai/'):
                return self._call_openai(messages, model.replace('openai/', ''), **kwargs)
            elif model.startswith('openrouter/'):
                return self._call_openrouter(messages, model.replace('openrouter/', ''), **kwargs)
            else:
                raise ValueError(f"Unknown model provider: {model}")
                
        except Exception as e:
            logger.error(f"LLM API call failed: {e}")
            raise
    
    def _call_openai(self, messages: List[Dict[str, str]], model: str, **kwargs) -> LLMResponse:
        """Call OpenAI API."""
        import openai
        
        if not self.openai_api_key:
            raise ValueError("OpenAI API key not configured")
        
        client = openai.OpenAI(api_key=self.openai_api_key)
        
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            **kwargs
        )
        
        # Calculate cost (simplified)
        usage = response.usage.model_dump()
        cost_usd = self._calculate_cost(model, usage)
        
        return LLMResponse(
            content=response.choices[0].message.content,
            model=model,
            usage=usage,
            cost_usd=cost_usd
        )
```

## 🛠️ Development Tools

### 1. **django_ngrok - Webhook Development**
```python
# Real pattern for ngrok integration
from typing import Optional
from django_cfg.modules.base import BaseCfgModule
from django_cfg.modules.django_logger import get_logger

logger = get_logger(__name__)

class NgrokTunnel(BaseCfgModule):
    """Ngrok tunnel management for webhook development."""
    
    def __init__(self):
        """Initialize ngrok tunnel."""
        self.config = self.get_config()
        
        # Auto-configure from django-cfg
        if self.config and hasattr(self.config, 'ngrok'):
            self.enabled = self.config.ngrok.enabled
            self.auth_token = self.config.ngrok.auth_token
        else:
            # Auto-enable in development
            try:
                from django.conf import settings
                self.enabled = getattr(settings, 'DEBUG', False)
            except:
                self.enabled = False
            self.auth_token = None
    
    def setup_tunnel(self, port: int = 8000) -> Optional[str]:
        """Setup ngrok tunnel for webhook development."""
        if not self.enabled:
            logger.debug("Ngrok tunnel disabled")
            return None
        
        try:
            from pyngrok import ngrok
            
            # Set auth token if provided
            if self.auth_token:
                ngrok.set_auth_token(self.auth_token)
            
            # Create tunnel
            tunnel = ngrok.connect(port, "http")
            tunnel_url = tunnel.public_url
            
            logger.info(f"Ngrok tunnel created: {tunnel_url}")
            
            # Update environment variable for webhook URLs
            import os
            os.environ['NGROK_URL'] = tunnel_url
            
            return tunnel_url
            
        except Exception as e:
            logger.error(f"Failed to create ngrok tunnel: {e}")
            return None

def setup_tunnel(port: int = 8000) -> Optional[str]:
    """Simple API for tunnel setup."""
    tunnel = NgrokTunnel()
    return tunnel.setup_tunnel(port)

def get_tunnel_url() -> Optional[str]:
    """Get current tunnel URL."""
    import os
    return os.environ.get('NGROK_URL')
```

### 2. **django_unfold - Admin Interface Enhancement**
```python
# Real implementation from django_cfg/modules/django_unfold
from typing import Dict, Any, List
from django_cfg.modules.base import BaseCfgModule
from django_cfg.modules.django_logger import get_logger

logger = get_logger(__name__)

class UnfoldCallbacks(BaseCfgModule):
    """Unfold dashboard callbacks with auto-configuration."""
    
    def __init__(self):
        """Initialize Unfold callbacks."""
        self.config = self.get_config()
        
        # Auto-detect enabled apps
        self.enabled_apps = self._get_enabled_apps()
    
    def _get_enabled_apps(self) -> List[str]:
        """Get enabled django-cfg apps."""
        apps = []
        
        if self.config:
            if hasattr(self.config, 'enable_knowbase') and self.config.enable_knowbase:
                apps.append('knowbase')
            if hasattr(self.config, 'enable_agents') and self.config.enable_agents:
                apps.append('agents')
            if hasattr(self.config, 'payments') and self.config.payments.enabled:
                apps.append('payments')
        
        return apps
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        """Get dashboard data for all enabled apps."""
        dashboard_data = {
            'apps': self.enabled_apps,
            'stats': {},
            'charts': {},
            'recent_activity': []
        }
        
        # Collect stats from each enabled app
        for app in self.enabled_apps:
            try:
                app_stats = self._get_app_stats(app)
                dashboard_data['stats'][app] = app_stats
            except Exception as e:
                logger.warning(f"Failed to get stats for {app}: {e}")
        
        return dashboard_data
    
    def _get_app_stats(self, app: str) -> Dict[str, Any]:
        """Get statistics for specific app."""
        if app == 'knowbase':
            return self._get_knowbase_stats()
        elif app == 'payments':
            return self._get_payments_stats()
        elif app == 'agents':
            return self._get_agents_stats()
        
        return {}
    
    def _get_knowbase_stats(self) -> Dict[str, Any]:
        """Get knowbase statistics."""
        try:
            from django_cfg.apps.knowbase.models import Document, DocumentChunk
            
            return {
                'total_documents': Document.objects.count(),
                'processed_documents': Document.objects.filter(processing_status='completed').count(),
                'total_chunks': DocumentChunk.objects.count(),
            }
        except ImportError:
            return {}
```

## 🏷️ Metadata
**Tags**: `modules, utilities, auto-config, type-safe, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Real Examples**: Currency, Logger, LLM, Email modules from django-cfg
**DEPENDS_ON**: [django-cfg-core, pydantic]
**USED_BY**: [all-django-cfg-apps]
