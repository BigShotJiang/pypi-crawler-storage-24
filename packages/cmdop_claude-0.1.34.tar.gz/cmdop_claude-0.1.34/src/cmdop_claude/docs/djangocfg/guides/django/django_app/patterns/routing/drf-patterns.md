# ⚙️ DRF Router Patterns

## 1. **DefaultRouter Usage**

### Basic Router Setup
```python
from rest_framework.routers import DefaultRouter
from .views import PaymentViewSet, CurrencyViewSet

# Create router instance
router = DefaultRouter()

# Register ViewSets
router.register(r'payments', PaymentViewSet, basename='payment')
router.register(r'currencies', CurrencyViewSet, basename='currency')
router.register(r'balances', UserBalanceViewSet, basename='balance')

# Include in URLs
urlpatterns = [
    path('', include(router.urls)),
]
```

### Generated URL Patterns
```python
# DefaultRouter automatically creates:
# GET    /payments/           -> PaymentViewSet.list()
# POST   /payments/           -> PaymentViewSet.create()
# GET    /payments/{id}/      -> PaymentViewSet.retrieve()
# PUT    /payments/{id}/      -> PaymentViewSet.update()
# PATCH  /payments/{id}/      -> PaymentViewSet.partial_update()
# DELETE /payments/{id}/      -> PaymentViewSet.destroy()
```

## 2. **Custom ViewSet Actions**

### Detail Actions (Operate on Single Resource)
```python
from rest_framework.decorators import action
from rest_framework.response import Response

class PaymentViewSet(viewsets.ModelViewSet):
    queryset = UniversalPayment.objects.all()
    serializer_class = PaymentSerializer
    
    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        """Cancel a specific payment."""
        payment = self.get_object()
        payment.status = 'cancelled'
        payment.save()
        return Response({'status': 'cancelled'})
    
    @action(detail=True, methods=['get'])
    def status(self, request, pk=None):
        """Get payment status."""
        payment = self.get_object()
        return Response({'status': payment.status})

# Generated URLs:
# POST /payments/{id}/cancel/  -> cancel action
# GET  /payments/{id}/status/  -> status action
```

### List Actions (Operate on Collection)
```python
class PaymentViewSet(viewsets.ModelViewSet):
    
    @action(detail=False, methods=['get'])
    def stats(self, request):
        """Get payment statistics."""
        total = self.get_queryset().count()
        completed = self.get_queryset().filter(status='completed').count()
        return Response({
            'total': total,
            'completed': completed,
            'success_rate': completed / total if total > 0 else 0
        })
    
    @action(detail=False, methods=['get'])
    def recent(self, request):
        """Get recent payments."""
        recent_payments = self.get_queryset().order_by('-created_at')[:10]
        serializer = self.get_serializer(recent_payments, many=True)
        return Response(serializer.data)

# Generated URLs:
# GET /payments/stats/   -> stats action
# GET /payments/recent/  -> recent action
```

## 3. **ViewSet Customization**

### Custom Serializers per Action
```python
class PaymentViewSet(viewsets.ModelViewSet):
    queryset = UniversalPayment.objects.all()
    
    # Default serializer
    serializer_class = PaymentDetailSerializer
    
    # Custom serializers per action
    serializer_classes = {
        'list': PaymentListSerializer,
        'create': PaymentCreateSerializer,
        'update': PaymentUpdateSerializer,
        'stats': PaymentStatsSerializer,
    }
    
    def get_serializer_class(self):
        """Return appropriate serializer for action."""
        return self.serializer_classes.get(
            self.action, 
            self.serializer_class
        )
```

### Custom Permissions per Action
```python
from rest_framework.permissions import IsAuthenticated, IsAdminUser

class PaymentViewSet(viewsets.ModelViewSet):
    
    def get_permissions(self):
        """Return appropriate permissions for action."""
        if self.action in ['create', 'update', 'destroy']:
            permission_classes = [IsAuthenticated]
        elif self.action in ['stats', 'cancel']:
            permission_classes = [IsAdminUser]
        else:
            permission_classes = []  # Public read access
        
        return [permission() for permission in permission_classes]
```

## 4. **Router Configuration Options**

### Trailing Slash Configuration
```python
# Default: URLs end with slash
router = DefaultRouter()
# /payments/ (with slash)

# Remove trailing slash
router = DefaultRouter(trailing_slash=False)
# /payments (without slash)
```

### API Root View Customization
```python
# Custom API root view
class CustomAPIRootView(APIView):
    def get(self, request):
        return Response({
            'payments': reverse('payment-list', request=request),
            'currencies': reverse('currency-list', request=request),
            'version': '2.0',
            'status': 'active'
        })

router = DefaultRouter()
router.APIRootView = CustomAPIRootView
```

## 5. **Multiple Routers Pattern**

### Separate Routers for Different Concerns
```python
# Main API router
api_router = DefaultRouter()
api_router.register(r'payments', PaymentViewSet, basename='payment')
api_router.register(r'currencies', CurrencyViewSet, basename='currency')

# Admin API router
admin_router = DefaultRouter()
admin_router.register(r'payments', AdminPaymentViewSet, basename='admin-payment')
admin_router.register(r'stats', AdminStatsViewSet, basename='admin-stats')

# Webhook router
webhook_router = DefaultRouter()
webhook_router.register(r'events', WebhookEventViewSet, basename='webhook-event')

urlpatterns = [
    path('api/', include(api_router.urls)),
    path('admin/api/', include(admin_router.urls)),
    path('webhooks/', include(webhook_router.urls)),
]
```

## 6. **ViewSet Inheritance Patterns**

### Base ViewSet for Common Functionality
```python
class BasePaymentViewSet(viewsets.ModelViewSet):
    """Base ViewSet with common payment functionality."""
    
    def get_queryset(self):
        """Optimized queryset with select_related."""
        return self.queryset.select_related('user', 'currency')
    
    def perform_create(self, serializer):
        """Set user on creation."""
        serializer.save(user=self.request.user)

class PaymentViewSet(BasePaymentViewSet):
    """Public payment ViewSet."""
    queryset = UniversalPayment.objects.filter(status__in=['completed', 'pending'])
    serializer_class = PaymentSerializer

class AdminPaymentViewSet(BasePaymentViewSet):
    """Admin payment ViewSet with full access."""
    queryset = UniversalPayment.objects.all()
    serializer_class = AdminPaymentSerializer
    permission_classes = [IsAdminUser]
```

## 7. **Custom Router Classes**

### Router with Custom URL Patterns
```python
class PaymentRouter(DefaultRouter):
    """Custom router for payment-specific patterns."""
    
    def get_urls(self):
        """Add custom URLs to default router URLs."""
        urls = super().get_urls()
        
        # Add custom endpoints
        custom_urls = [
            path('payments/create/', PaymentCreateView.as_view(), name='payment-create'),
            path('payments/webhook/<str:provider>/', WebhookView.as_view(), name='webhook'),
        ]
        
        return urls + custom_urls
```

## 8. **Filtering and Pagination**

### DRF Filters Integration
```python
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter

class PaymentViewSet(viewsets.ModelViewSet):
    queryset = UniversalPayment.objects.all()
    serializer_class = PaymentSerializer
    
    # Filter backends
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    
    # Filter fields
    filterset_fields = ['status', 'provider', 'currency__code']
    
    # Search fields
    search_fields = ['internal_payment_id', 'description', 'user__email']
    
    # Ordering fields
    ordering_fields = ['created_at', 'amount_usd', 'status']
    ordering = ['-created_at']  # Default ordering
```

### Custom Pagination
```python
from rest_framework.pagination import PageNumberPagination

class PaymentPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 100

class PaymentViewSet(viewsets.ModelViewSet):
    pagination_class = PaymentPagination
```

## 9. **Error Handling in ViewSets**

### Custom Exception Handling
```python
from rest_framework.response import Response
from rest_framework import status

class PaymentViewSet(viewsets.ModelViewSet):
    
    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        try:
            payment = self.get_object()
            
            if payment.status == 'completed':
                return Response(
                    {'error': 'Cannot cancel completed payment'}, 
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            payment.status = 'cancelled'
            payment.save()
            
            return Response({'status': 'cancelled'})
            
        except Exception as e:
            return Response(
                {'error': str(e)}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
```

## 10. **Testing ViewSets**

### ViewSet Test Patterns
```python
from rest_framework.test import APITestCase
from rest_framework import status

class PaymentViewSetTest(APITestCase):
    
    def setUp(self):
        self.user = User.objects.create_user('test@example.com', 'password')
        self.payment = UniversalPayment.objects.create(
            user=self.user,
            amount_usd=100.0,
            status='pending'
        )
    
    def test_list_payments(self):
        """Test payment list endpoint."""
        url = reverse('payment-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
    
    def test_cancel_payment(self):
        """Test payment cancel action."""
        url = reverse('payment-cancel', kwargs={'pk': self.payment.pk})
        response = self.client.post(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        self.payment.refresh_from_db()
        self.assertEqual(self.payment.status, 'cancelled')
```

## 11. **Best Practices**

### ✅ **DO**
- Use meaningful basename for router registration
- Implement custom actions for business logic
- Use appropriate HTTP methods for actions
- Add proper permissions and authentication
- Include comprehensive filtering and search
- Write tests for all ViewSet actions

### ❌ **DON'T**
- Mix business logic in serializers
- Use generic names for custom actions
- Ignore proper HTTP status codes
- Skip permission checks on sensitive actions
- Create overly complex ViewSet inheritance
- Forget to handle edge cases and errors

### 🎯 **Result**
- Clean, RESTful API endpoints
- Consistent URL patterns across apps
- Proper separation of concerns
- Easy to test and maintain
- Follows Django REST Framework best practices
