# 🎯 Django ORM Managers & Business Logic %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Django ORM Managers** are the primary location for business logic in Django-CFG
- **Models contain only schema definition** - no business logic
- **Managers provide optimized queries**, business operations, and data integrity
- **Zero raw JSON policy** - all data must be properly typed (Django ORM)
- **QuerySets handle filtering and optimization**, Managers handle business operations

## 📋 Table of Contents
1. [Manager Architecture](#manager-architecture)
2. [Real Implementation Examples](#real-implementation-examples)
3. [QuerySet Optimization Patterns](#queryset-optimization-patterns)
4. [Business Logic Placement](#business-logic-placement)
5. [Manager Integration Patterns](#manager-integration-patterns)

## 🔑 Key Concepts at a Glance
- **Models = Schema Only**: No business logic in model classes
- **Managers = Business Logic**: All operations, validations, complex queries
- **QuerySets = Filtering**: Optimized database queries with proper indexing
- **Type Safety**: Django ORM for database layer, Pydantic 2 for services
- **Zero Raw JSON Policy**: All data structures must be properly typed

## 🚀 Quick Start

### Basic Manager Pattern (Real Example from Payments)
```python
# ✅ CORRECT: Manager with business logic
class PaymentManager(models.Manager):
    def get_queryset(self):
        """Return optimized queryset by default."""
        return PaymentQuerySet(self.model, using=self._db)
    
    def mark_payment_completed(self, payment_id, actual_amount_usd=None, transaction_hash=None):
        """Mark payment as completed (business logic in manager)."""
        # Business validation and logic here
        payment = self.get(id=payment_id)
        if not payment.status in ['pending', 'confirming', 'confirmed']:
            return False
        
        payment.status = 'completed'
        payment.completed_at = timezone.now()
        payment.save()
        return True

# ✅ CORRECT: Model with manager assignment
class UniversalPayment(UUIDTimestampedModel):
    # Schema definition only
    amount_usd = models.FloatField()
    status = models.CharField(max_length=20)
    
    # Manager assignment
    from .managers.payment_managers import PaymentManager
    objects = PaymentManager()
```

## 🏗️ Manager Architecture

### 1. **Three-Layer Manager System**
```
┌─────────────────────┐
│   Business Logic    │  ← Manager methods (create_payment, mark_completed)
├─────────────────────┤
│   Query Optimization│  ← QuerySet methods (optimized, by_status, recent)
├─────────────────────┤
│   Database Schema   │  ← Model fields (amount_usd, status, created_at)
└─────────────────────┘
```

### 2. **Manager + QuerySet Pattern (Real Implementation)**
```python
# Real example from django-cfg payments
class PaymentQuerySet(models.QuerySet):
    """Optimized queryset for payment operations."""
    
    def optimized(self):
        """Prevent N+1 queries with select_related and prefetch_related."""
        return self.select_related(
            'user', 'currency', 'network'
        ).prefetch_related(
            'user__payment_balance',
            'user__payment_transactions'
        )
    
    def by_status(self, status):
        """Filter by payment status with index optimization."""
        return self.filter(status=status)
    
    def completed(self):
        """Get completed payments."""
        return self.filter(status='completed')
    
    def recent(self, hours=24):
        """Get recent payments."""
        cutoff = timezone.now() - timedelta(hours=hours)
        return self.filter(created_at__gte=cutoff)

class PaymentManager(models.Manager):
    """Manager for payment operations with optimized queries."""
    
    def get_queryset(self):
        """Return optimized queryset by default."""
        return PaymentQuerySet(self.model, using=self._db)
    
    def optimized(self):
        """Get optimized queryset for admin/API use."""
        return self.get_queryset().optimized()
    
    def completed(self):
        """Get completed payments."""
        return self.get_queryset().completed()
```

## 🔍 Real Implementation Examples

### 1. **Payment Manager (from django-cfg/apps/payments)**
```python
class PaymentManager(models.Manager):
    """Real implementation from django-cfg payments app."""
    
    # Query optimization methods
    def optimized(self):
        return self.get_queryset().optimized()
    
    # Status-based methods
    def completed(self):
        return self.get_queryset().completed()
    
    def pending(self):
        return self.get_queryset().pending()
    
    # Time-based methods
    def recent(self, hours=24):
        return self.get_queryset().recent(hours)
    
    def today(self):
        return self.get_queryset().today()
    
    # Business logic methods
    def mark_payment_completed(self, payment_id, actual_amount_usd=None, transaction_hash=None):
        """Business logic for completing payments."""
        try:
            payment = self.get(id=payment_id)
            
            # Validate payment can be completed
            if not payment.status in ['pending', 'confirming', 'confirmed']:
                logger.warning(f"Cannot complete payment in status {payment.status}")
                return False
            
            # Update payment
            payment.status = 'completed'
            payment.completed_at = timezone.now()
            if actual_amount_usd:
                payment.actual_amount_usd = actual_amount_usd
            if transaction_hash:
                payment.transaction_hash = transaction_hash
            
            payment.save(update_fields=[
                'status', 'completed_at', 'actual_amount_usd', 'transaction_hash', 'updated_at'
            ])
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to complete payment: {e}")
            return False
```

### 2. **Balance Manager (from django-cfg/apps/payments)**
```python
class UserBalanceManager(models.Manager):
    """Real implementation for user balance operations."""
    
    def get_or_create_for_user(self, user):
        """Get or create balance for user with atomic operation."""
        balance, created = self.get_or_create(
            user=user,
            defaults={'balance_usd': 0.0}
        )
        return balance
    
    def add_funds(self, user, amount_usd, transaction_type='deposit'):
        """Add funds to user balance (atomic operation)."""
        with transaction.atomic():
            balance = self.get_or_create_for_user(user)
            balance.balance_usd += amount_usd
            balance.total_deposited += amount_usd
            balance.last_transaction_at = timezone.now()
            balance.save()
            
            # Create transaction record
            from .transaction_models import BalanceTransaction
            BalanceTransaction.objects.create(
                user=user,
                amount_usd=amount_usd,
                transaction_type=transaction_type,
                balance_after=balance.balance_usd
            )
            
            return balance
```

### 3. **Knowbase Manager (from django-cfg/apps/knowbase)**
```python
class BaseKnowbaseManager(models.Manager):
    """Base manager with common functionality for knowbase models."""
    
    def for_user(self, user):
        """Explicitly filter by specific user."""
        return self.get_queryset().filter(user=user)
    
    def all_users(self):
        """Get unfiltered queryset (admin use)."""
        return self.get_queryset()
    
    def public(self):
        """Get public records (if model has is_public field)."""
        if hasattr(self.model, 'is_public'):
            return self.get_queryset().filter(is_public=True)
        return self.get_queryset()
    
    def active(self):
        """Get active records (if model has is_active field)."""
        if hasattr(self.model, 'is_active'):
            return self.get_queryset().filter(is_active=True)
        return self.get_queryset()
```

## ⚡ QuerySet Optimization Patterns

### 1. **N+1 Query Prevention**
```python
# ✅ CORRECT: Optimized queryset (real pattern from django-cfg)
class PaymentQuerySet(models.QuerySet):
    def optimized(self):
        """Prevent N+1 queries with select_related and prefetch_related."""
        return self.select_related(
            'user',           # Foreign key
            'currency',       # Foreign key
            'network'         # Foreign key
        ).prefetch_related(
            'user__payment_balance',      # Reverse foreign key
            'user__payment_transactions'  # Reverse foreign key
        )

# Usage in views/admin
payments = UniversalPayment.objects.optimized().recent(days=7)
```

### 2. **Index-Optimized Filtering**
```python
# ✅ CORRECT: Index-aware filtering
class PaymentQuerySet(models.QuerySet):
    def by_status(self, status):
        """Filter by payment status with index optimization."""
        return self.filter(status=status)  # status field has db_index=True
    
    def by_user(self, user):
        """Filter by user with proper indexing."""
        return self.filter(user=user)  # Foreign key automatically indexed
    
    def by_amount_range(self, min_amount=None, max_amount=None):
        """Filter by USD amount range."""
        queryset = self
        if min_amount is not None:
            queryset = queryset.filter(amount_usd__gte=min_amount)
        if max_amount is not None:
            queryset = queryset.filter(amount_usd__lte=max_amount)
        return queryset
```

### 3. **Time-Based Queries**
```python
# ✅ CORRECT: Efficient time filtering
class PaymentQuerySet(models.QuerySet):
    def recent(self, hours=24):
        """Get recent payments with timezone awareness."""
        cutoff = timezone.now() - timedelta(hours=hours)
        return self.filter(created_at__gte=cutoff)
    
    def today(self):
        """Get today's payments."""
        today = timezone.now().date()
        return self.filter(created_at__date=today)
    
    def expired(self):
        """Get expired payments."""
        return self.filter(
            expires_at__isnull=False,
            expires_at__lt=timezone.now()
        )
```

## 🎯 Business Logic Placement

### 1. **Manager Methods for Business Operations**
```python
# ✅ CORRECT: Business logic in manager
class PaymentManager(models.Manager):
    def create_payment(self, user, amount_usd, currency_code, provider='nowpayments'):
        """Create new payment with business validation."""
        # Business validation
        if amount_usd < 1.0 or amount_usd > 50000.0:
            raise ValidationError("Amount must be between $1.00 and $50,000.00")
        
        # Get currency
        try:
            currency = Currency.objects.get(code=currency_code)
        except Currency.DoesNotExist:
            raise ValidationError(f"Currency {currency_code} not supported")
        
        # Create payment
        payment = self.create(
            user=user,
            amount_usd=amount_usd,
            currency=currency,
            provider=provider,
            status='pending',
            expires_at=timezone.now() + timedelta(hours=2)
        )
        
        return payment
    
    def mark_payment_completed(self, payment_id, actual_amount_usd=None, transaction_hash=None):
        """Complete payment with business logic."""
        # Implementation shown above
        pass

# ❌ WRONG: Business logic in model
class UniversalPayment(models.Model):
    def complete_payment(self):  # Don't do this
        # Business logic should be in manager, not model
        pass
```

### 2. **Model Methods for Simple Properties Only**
```python
# ✅ CORRECT: Simple properties in model
class UniversalPayment(UUIDTimestampedModel):
    # Schema fields
    status = models.CharField(max_length=20)
    expires_at = models.DateTimeField(null=True, blank=True)
    
    # Simple property methods (no business logic)
    @property
    def is_pending(self) -> bool:
        """Check if payment is pending."""
        return self.status == 'pending'
    
    @property
    def is_expired(self) -> bool:
        """Check if payment is expired."""
        if not self.expires_at:
            return False
        return timezone.now() > self.expires_at
    
    # Delegate business operations to manager
    def mark_completed(self, actual_amount_usd=None, transaction_hash=None):
        """Mark payment as completed (delegates to manager)."""
        return self.__class__.objects.mark_payment_completed(
            self, actual_amount_usd, transaction_hash
        )
```

## 🔗 Manager Integration Patterns

### 1. **Manager Assignment in Models**
```python
# ✅ CORRECT: Manager assignment (real pattern from django-cfg)
class UniversalPayment(UUIDTimestampedModel):
    # Schema fields
    amount_usd = models.FloatField()
    status = models.CharField(max_length=20)
    
    # Manager assignment
    from .managers.payment_managers import PaymentManager
    objects = PaymentManager()
    
    class Meta:
        db_table = 'payments_universal_payments'
```

### 2. **Multiple Managers Pattern**
```python
# ✅ CORRECT: Multiple managers for different use cases
class DocumentArchive(UserScopedModel):
    # Standard Django manager (for admin, signals, raw SQL)
    objects = models.Manager()
    
    # Custom user-scoped manager
    user_scoped = DocumentArchiveManager()
    
    # Usage:
    # DocumentArchive.objects.all()  # All records (admin use)
    # DocumentArchive.user_scoped.for_user(user)  # User-filtered
```

### 3. **Manager Inheritance**
```python
# ✅ CORRECT: Manager inheritance pattern
class BaseKnowbaseManager(models.Manager):
    """Base manager with common functionality."""
    
    def for_user(self, user):
        return self.get_queryset().filter(user=user)
    
    def active(self):
        if hasattr(self.model, 'is_active'):
            return self.get_queryset().filter(is_active=True)
        return self.get_queryset()

class DocumentManager(BaseKnowbaseManager):
    """Specialized manager for documents."""
    
    def by_type(self, doc_type):
        return self.get_queryset().filter(document_type=doc_type)
    
    def searchable(self):
        return self.active().filter(is_searchable=True)
```

## 🏷️ Metadata
**Tags**: `managers, orm, business-logic, querysets, typing, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%ADVANCED%%
**Real Examples**: Payment, Balance, Knowbase managers from django-cfg
**DEPENDS_ON**: [django-orm, django-cfg-core]
**USED_BY**: [all-django-cfg-models]
