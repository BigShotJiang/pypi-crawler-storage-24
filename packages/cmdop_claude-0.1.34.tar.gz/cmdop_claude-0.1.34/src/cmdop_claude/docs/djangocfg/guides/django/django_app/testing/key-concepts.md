# 🔑 Key Concepts at a Glance

## Core Testing Principles
- **Django TestCase**: Standard Django testing approach (not pytest-django)
- **App-Specific Testing**: Test individual apps independently for faster development
- **Code-First Testing**: Tests follow actual implementation, not assumptions
- **Mock External Services**: Comprehensive mocking patterns for isolation
- **Type Safety**: All test data uses Pydantic models with validation
- **Performance Testing**: SLA validation and regression detection
- **File Size Limits**: 400 lines per test file, 150 lines per test class
- **No Inline Imports**: All imports must be at the top of test files
- **Database Isolation**: Always specify `databases = ['default']` in test classes for multi-database projects
- **Correct Settings**: Use `tests.settings` instead of project settings to avoid database routing issues

## Quick Commands Reference
```bash
# 🚀 RECOMMENDED: Use the standard test runner (KISS principle)
cd /path/to/django-cfg
poetry run python run_tests.py

# Run specific app tests
cd /path/to/django-cfg/src
poetry run python -m django test django_cfg.apps.payments.tests \
    --settings=tests.settings \
    --verbosity=2

# Test specific module
poetry run python -m django test django_cfg.apps.payments.tests.models \
    --settings=tests.settings

# Test specific test class
poetry run python -m django test django_cfg.apps.payments.tests.models.test_payment_models.PaymentModelTest \
    --settings=tests.settings

# ⚠️ CRITICAL: Always use tests.settings for Django-CFG apps
# Project settings have database routing which breaks tests!

# 🔧 NON-INTERACTIVE TESTING (prevents hanging)
# Use --verbosity=1 or --verbosity=0 to reduce output and avoid interactive prompts
poetry run python -m django test django_cfg.apps.payments.tests \
    --settings=tests.settings \
    --verbosity=1 \
    --keepdb \
    --parallel auto
```

## Why Use run_tests.py?

The `run_tests.py` script is the **RECOMMENDED** way to run tests because:

- ✅ **Automatic Discovery**: Finds all Django-CFG app tests automatically
- ✅ **Correct Settings**: Uses `tests.settings` by default (no database routing issues)
- ✅ **Proper Setup**: Handles Django initialization correctly
- ✅ **KISS Principle**: Simple, one command to run everything
- ✅ **Consistent Environment**: Same setup every time

```bash
# Just run this - it handles everything!
cd /path/to/django-cfg
poetry run python run_tests.py

# Alternative: Using pytest for app-specific testing
poetry run python -c "
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'examples.sample.django.api.settings')
import django
django.setup()
" && poetry run python -m pytest src/django_cfg/apps/payments/tests/ -v \
    --ds=examples.sample.django.api.settings
```

## Essential Test Structure
```python
# src/django_cfg/apps/payments/tests/__init__.py
"""
Test configuration for Payments app.
"""

from django.test import TestCase
from django.contrib.auth import get_user_model

User = get_user_model()

class PaymentsTestCase(TestCase):
    """Base test case for Payments app."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test class."""
        super().setUpClass()
        # App-specific setup
    
    def setUp(self):
        """Set up test data."""
        self.user = User.objects.create_user(
            email="test@example.com",
            username="testuser"
        )
```

## Quick Start for App Testing
```bash
# Run all tests (system-wide)
python manage.py test

# Run specific app tests (recommended for development)
python manage.py test django_cfg.apps.accounts
python manage.py test django_cfg.apps.payments
python manage.py test django_cfg.apps.knowbase

# Run with coverage for specific app
coverage run --source='src/django_cfg/apps/payments' \
    -m django test django_cfg.apps.payments.tests \
    --settings=examples.sample.django.api.settings

coverage report --show-missing

# Run specific test modules
python manage.py test django_cfg.apps.knowbase.tests.test_models
python manage.py test django_cfg.apps.agents.tests.test_agent
```

## Basic Test Structure Pattern
```python
# Real pattern from django-cfg apps
from django.test import TestCase
from django.contrib.auth import get_user_model
from unittest.mock import Mock, patch

User = get_user_model()

class MyAppTestCase(TestCase):
    """Test MyApp functionality."""
    
    def setUp(self):
        """Set up test data."""
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
    
    def test_functionality(self):
        """Test specific functionality."""
        # Test implementation
        pass
```

## 🚫 Preventing Test Hanging (Non-Interactive Testing)

**Problem**: Tests sometimes hang waiting for user input or due to interactive prompts.

**Solutions:**
```bash
# 🔧 Use non-interactive flags to prevent hanging
poetry run python -m django test django_cfg.apps.payments.tests \
    --settings=tests.settings \
    --verbosity=1 \              # Reduce output (0=minimal, 1=normal, 2=verbose)
    --keepdb \                   # Reuse test database (faster)
    --parallel auto \            # Run tests in parallel
    --noinput                    # No interactive prompts

# 🚀 BEST: Use run_tests.py which handles all this automatically
cd /path/to/django-cfg
poetry run python run_tests.py  # Already configured for non-interactive testing
```

**Common Causes of Hanging Tests:**
- **Interactive prompts**: Database creation, migration confirmations
- **Infinite loops**: Poorly written test logic
- **Network timeouts**: Real API calls instead of mocks
- **Database locks**: Multiple tests accessing same resources

**Prevention Strategies:**
```python
# ✅ Mock external services to prevent network timeouts
@patch('external_api.call')
def test_with_mock(self, mock_call):
    mock_call.return_value = {"status": "success"}
    # Test logic here

# ✅ Use timeouts for potentially long-running operations
import signal
def timeout_handler(signum, frame):
    raise TimeoutError("Test timed out")

class TimeoutTestCase(TestCase):
    def setUp(self):
        signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(30)  # 30 second timeout
    
    def tearDown(self):
        signal.alarm(0)  # Cancel timeout
```
