# 🛡️ Django-CFG Middleware Guide %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Auto-registration middleware** based on enabled features in DjangoConfig
- **Smart JWT token handling** for public endpoints with PublicEndpointsMiddleware
- **App-specific middleware** with configuration integration and statistics
- **Real examples** from payments app with API access, rate limiting, and usage tracking

## 📋 Table of Contents
1. [Built-in Middleware](#built-in-middleware)
2. [Real Middleware Examples](#real-middleware-examples)
3. [Auto-Registration Patterns](#auto-registration-patterns)
4. [Custom Middleware Development](#custom-middleware-development)
5. [Statistics & Monitoring](#statistics--monitoring)

## 🔑 Key Concepts at a Glance
- **Auto-Registration**: Middleware automatically added based on enabled features
- **PublicEndpointsMiddleware**: Prevents JWT auth errors on public endpoints
- **App-Specific Middleware**: Each app can register its own middleware
- **Configuration Integration**: Middleware uses django-cfg and Constance settings
- **Statistics**: Built-in monitoring and performance tracking

## 🚀 Quick Start

### Auto-Registration in DjangoConfig
```python
# Middleware is automatically configured in DjangoConfig
class MyProjectConfig(DjangoConfig):
    enable_accounts: bool = True  # Adds UserActivityMiddleware
    payments: PaymentsConfig = PaymentsConfig(enabled=True)  # Adds payment middleware
    
    # Custom middleware
    custom_middleware: List[str] = [
        'myproject.middleware.CustomMiddleware'
    ]
```

## 🔧 Built-in Middleware

### 1. **Core Middleware Stack (Real Implementation)**
```python
# core/config.py - Automatic middleware registration
def get_middleware(self) -> List[str]:
    """Get complete middleware stack based on enabled features."""
    # Standard Django middleware (always included)
    middleware = [
        "django.middleware.security.SecurityMiddleware",
        "whitenoise.middleware.WhiteNoiseMiddleware",  # Static files
        "django.contrib.sessions.middleware.SessionMiddleware",
        "django.middleware.common.CommonMiddleware",
        "django.middleware.csrf.CsrfViewMiddleware",
        "django.contrib.auth.middleware.AuthenticationMiddleware",
        "django.contrib.messages.middleware.MessageMiddleware",
        "django.middleware.clickjacking.XFrameOptionsMiddleware",
    ]

    # Add CORS middleware if security domains are configured
    if self.security_domains:
        middleware.insert(1, "corsheaders.middleware.CorsMiddleware")

    # Add Django CFG middleware based on enabled features
    if self.enable_accounts:
        middleware.append("django_cfg.middleware.UserActivityMiddleware")

    # Add payments middleware if enabled
    if self.payments and self.payments.enabled:
        middleware.extend(self.payments.get_middleware_classes())

    # Add custom middleware
    middleware.extend(self.custom_middleware)

    return middleware
```

### 2. **Available Django-CFG Middleware**
```python
# Built-in middleware components
DJANGO_CFG_MIDDLEWARE = {
    'public_endpoints': 'django_cfg.middleware.public_endpoints.PublicEndpointsMiddleware',
    'user_activity': 'django_cfg.middleware.user_activity.UserActivityMiddleware',
    'pagination': 'django_cfg.middleware.pagination.PaginationMiddleware',
}

# App-specific middleware (auto-registered)
APP_MIDDLEWARE = {
    'payments': [
        'django_cfg.apps.payments.middleware.APIAccessMiddleware',
        'django_cfg.apps.payments.middleware.RateLimitingMiddleware',
        'django_cfg.apps.payments.middleware.UsageTrackingMiddleware',
    ]
}
```

## 🔍 Real Middleware Examples

### 1. **API Access Middleware (Real Implementation from Payments)**
```python
# payments/middleware/api_access.py - Real implementation
import re
import time
from typing import Optional, Dict, Any
from django.http import JsonResponse, HttpRequest, HttpResponse
from django.utils.deprecation import MiddlewareMixin
from django.core.cache import cache

from ..models import APIKey, Subscription
from ..config.helpers import MiddlewareConfigHelper
from django_cfg.modules.django_logger import get_logger

logger = get_logger("api_access_middleware")

class APIAccessMiddleware(MiddlewareMixin):
    """
    Enhanced API Access Control Middleware.
    
    Features:
    - API key authentication with caching
    - Subscription validation
    - Endpoint access control
    - Usage tracking and analytics
    - Rate limiting integration
    - Graceful degradation
    """
    
    def __init__(self, get_response=None):
        super().__init__(get_response)
        
        # Load configuration from django-cfg and Constance
        try:
            middleware_config = MiddlewareConfigHelper.get_middleware_config()
            
            # Configuration from django-cfg
            self.enabled = middleware_config['enabled']
            self.api_prefixes = middleware_config['api_prefixes']
            self.exempt_paths = middleware_config['exempt_paths']
            self.cache_timeout = middleware_config['cache_timeouts']['api_key']
            
            # Default settings
            self.strict_mode = False
            self.require_api_key = True
            
        except Exception as e:
            logger.warning(f"Failed to load middleware config, using defaults: {e}")
            # Fallback defaults
            self.enabled = True
            self.api_prefixes = ['/api/']
            self.exempt_paths = ['/api/health/', '/admin/']
            self.cache_timeout = 300
        
        # Compile exempt path patterns
        self.exempt_patterns = [
            re.compile(pattern) for pattern in [
                r'^/api/payments/[^/]+/status/$',
                r'^/api/webhooks/[^/]+/$',
                r'^/api/currencies/(rates|supported|convert)/$',
            ]
        ]
        
        logger.info(f"API Access Middleware initialized", extra={
            'enabled': self.enabled,
            'api_prefixes': self.api_prefixes
        })
    
    def process_request(self, request: HttpRequest) -> Optional[HttpResponse]:
        """Process incoming request for API access control."""
        
        # Skip if middleware is disabled
        if not self.enabled:
            return None
        
        # Check if this is an API request
        if not self._is_api_request(request):
            return None
        
        # Check exempt paths
        if self._is_exempt_path(request.path):
            return None
        
        # Extract API key from request
        api_key = self._extract_api_key(request)
        if not api_key:
            return self._api_key_required_response()
        
        # Validate API key
        validation_result = self._validate_api_key(api_key)
        if not validation_result['valid']:
            return self._invalid_api_key_response(validation_result['reason'])
        
        # Attach API key info to request
        request.api_key = validation_result['api_key']
        request.api_user = validation_result['user']
        request.subscription = validation_result['subscription']
        
        return None
    
    def _is_api_request(self, request: HttpRequest) -> bool:
        """Check if request is for API endpoints."""
        return any(request.path.startswith(prefix) for prefix in self.api_prefixes)
    
    def _is_exempt_path(self, path: str) -> bool:
        """Check if path is exempt from API key requirement."""
        # Check static exempt paths
        for exempt_path in self.exempt_paths:
            if path.startswith(exempt_path):
                return True
        
        # Check regex patterns
        for pattern in self.exempt_patterns:
            if pattern.match(path):
                return True
        
        return False
    
    def _extract_api_key(self, request: HttpRequest) -> Optional[str]:
        """Extract API key from request headers or query params."""
        # Check Authorization header
        auth_header = request.META.get('HTTP_AUTHORIZATION', '')
        if auth_header.startswith('Bearer '):
            return auth_header[7:]
        
        # Check X-API-Key header
        api_key_header = request.META.get('HTTP_X_API_KEY')
        if api_key_header:
            return api_key_header
        
        # Check query parameter
        return request.GET.get('api_key')
    
    def _validate_api_key(self, api_key: str) -> Dict[str, Any]:
        """Validate API key with caching."""
        cache_key = f"api_key:{api_key[:8]}"  # Use first 8 chars for cache key
        
        # Check cache first
        cached_result = cache.get(cache_key)
        if cached_result:
            logger.debug(f"API key cache hit")
            return cached_result
        
        try:
            # Query database
            api_key_obj = APIKey.objects.select_related('user', 'subscription').get(
                key=api_key,
                is_active=True
            )
            
            # Check subscription status
            subscription = api_key_obj.subscription
            if subscription and not subscription.is_active:
                result = {
                    'valid': False,
                    'reason': 'subscription_inactive',
                    'api_key': None,
                    'user': None,
                    'subscription': None
                }
            else:
                result = {
                    'valid': True,
                    'reason': 'valid',
                    'api_key': api_key_obj,
                    'user': api_key_obj.user,
                    'subscription': subscription
                }
            
            # Cache result
            cache.set(cache_key, result, self.cache_timeout)
            logger.debug(f"API key validated and cached")
            
            return result
            
        except APIKey.DoesNotExist:
            result = {
                'valid': False,
                'reason': 'key_not_found',
                'api_key': None,
                'user': None,
                'subscription': None
            }
            
            # Cache negative result for shorter time
            cache.set(cache_key, result, 60)
            return result
        
        except Exception as e:
            logger.error(f"API key validation error: {e}")
            return {
                'valid': False,
                'reason': 'validation_error',
                'api_key': None,
                'user': None,
                'subscription': None
            }
    
    def _api_key_required_response(self) -> JsonResponse:
        """Return API key required response."""
        return JsonResponse({
            'error': 'API key required',
            'code': 'API_KEY_REQUIRED',
            'message': 'This endpoint requires a valid API key'
        }, status=401)
    
    def _invalid_api_key_response(self, reason: str) -> JsonResponse:
        """Return invalid API key response."""
        messages = {
            'key_not_found': 'Invalid API key',
            'subscription_inactive': 'Subscription is not active',
            'validation_error': 'API key validation failed'
        }
        
        return JsonResponse({
            'error': 'Invalid API key',
            'code': 'INVALID_API_KEY',
            'message': messages.get(reason, 'API key validation failed'),
            'reason': reason
        }, status=401)
```

### 2. **Rate Limiting Middleware (Real Implementation)**
```python
# payments/middleware/rate_limiting.py - Real implementation
import time
import json
from typing import Optional, Dict, Any
from django.http import JsonResponse, HttpRequest, HttpResponse
from django.utils.deprecation import MiddlewareMixin
from django.core.cache import cache
from datetime import datetime, timedelta

from ..config.helpers import MiddlewareConfigHelper
from django_cfg.modules.django_logger import get_logger

logger = get_logger("rate_limiting_middleware")

class RateLimitingMiddleware(MiddlewareMixin):
    """
    Advanced Rate Limiting Middleware with sliding window algorithm.
    
    Features:
    - Sliding window rate limiting
    - Subscription-aware rate limits
    - Per-user and per-IP limiting
    - Burst allowance
    - Rate limit headers
    - Redis-based distributed limiting
    """
    
    def __init__(self, get_response=None):
        super().__init__(get_response)
        
        # Load configuration
        try:
            middleware_config = MiddlewareConfigHelper.get_middleware_config()
            
            self.enabled = middleware_config['rate_limiting_enabled']
            self.default_limits = middleware_config['default_rate_limits']
            self.api_prefixes = middleware_config['api_prefixes']
            self.cache_timeout = middleware_config['cache_timeouts']['rate_limit']
            
        except Exception as e:
            logger.warning(f"Failed to load rate limiting config: {e}")
            self.enabled = True
            self.default_limits = {'anonymous': 60, 'authenticated': 300}
            self.api_prefixes = ['/api/']
            self.cache_timeout = 3600
        
        # Rate limiting windows (in seconds)
        self.windows = {
            'minute': 60,
            'hour': 3600,
            'day': 86400
        }
        
        logger.info(f"Rate Limiting Middleware initialized", extra={
            'enabled': self.enabled,
            'default_limits': self.default_limits
        })
    
    def process_request(self, request: HttpRequest) -> Optional[HttpResponse]:
        """Process request for rate limiting."""
        
        if not self.enabled:
            return None
        
        # Only apply to API requests
        if not any(request.path.startswith(prefix) for prefix in self.api_prefixes):
            return None
        
        # Get rate limit key and limits
        rate_key, limits = self._get_rate_limit_info(request)
        
        # Check rate limits
        for window, limit in limits.items():
            if self._is_rate_limited(rate_key, window, limit):
                return self._rate_limit_exceeded_response(window, limit)
        
        # Record request
        self._record_request(rate_key)
        
        return None
    
    def process_response(self, request: HttpRequest, response: HttpResponse) -> HttpResponse:
        """Add rate limit headers to response."""
        
        if not self.enabled:
            return response
        
        # Only add headers to API responses
        if not any(request.path.startswith(prefix) for prefix in self.api_prefixes):
            return response
        
        # Get rate limit info
        rate_key, limits = self._get_rate_limit_info(request)
        
        # Add rate limit headers
        for window, limit in limits.items():
            remaining = self._get_remaining_requests(rate_key, window, limit)
            reset_time = self._get_reset_time(window)
            
            response[f'X-RateLimit-{window.title()}-Limit'] = str(limit)
            response[f'X-RateLimit-{window.title()}-Remaining'] = str(remaining)
            response[f'X-RateLimit-{window.title()}-Reset'] = str(reset_time)
        
        return response
    
    def _get_rate_limit_info(self, request: HttpRequest) -> tuple[str, Dict[str, int]]:
        """Get rate limit key and limits for request."""
        
        # Determine rate limit key
        if hasattr(request, 'api_user') and request.api_user:
            # Authenticated user with API key
            rate_key = f"user:{request.api_user.id}"
            
            # Check if user has subscription with custom limits
            if hasattr(request, 'subscription') and request.subscription:
                limits = self._get_subscription_limits(request.subscription)
            else:
                limits = {'minute': self.default_limits['authenticated']}
        else:
            # Anonymous or IP-based limiting
            ip_address = self._get_client_ip(request)
            rate_key = f"ip:{ip_address}"
            limits = {'minute': self.default_limits['anonymous']}
        
        return rate_key, limits
    
    def _is_rate_limited(self, rate_key: str, window: str, limit: int) -> bool:
        """Check if request exceeds rate limit."""
        cache_key = f"rate_limit:{rate_key}:{window}"
        
        # Get current request count
        current_count = cache.get(cache_key, 0)
        
        return current_count >= limit
    
    def _record_request(self, rate_key: str):
        """Record request for rate limiting."""
        current_time = int(time.time())
        
        for window, duration in self.windows.items():
            cache_key = f"rate_limit:{rate_key}:{window}"
            
            # Increment counter
            try:
                cache.add(cache_key, 0, duration)
                cache.incr(cache_key)
            except ValueError:
                # Key doesn't exist, set it
                cache.set(cache_key, 1, duration)
    
    def _get_remaining_requests(self, rate_key: str, window: str, limit: int) -> int:
        """Get remaining requests for window."""
        cache_key = f"rate_limit:{rate_key}:{window}"
        current_count = cache.get(cache_key, 0)
        return max(0, limit - current_count)
    
    def _get_reset_time(self, window: str) -> int:
        """Get reset time for window."""
        current_time = int(time.time())
        window_duration = self.windows[window]
        return current_time + (window_duration - (current_time % window_duration))
    
    def _rate_limit_exceeded_response(self, window: str, limit: int) -> JsonResponse:
        """Return rate limit exceeded response."""
        return JsonResponse({
            'error': 'Rate limit exceeded',
            'code': 'RATE_LIMIT_EXCEEDED',
            'message': f'Rate limit of {limit} requests per {window} exceeded',
            'window': window,
            'limit': limit
        }, status=429)
```

### 3. **Usage Tracking Middleware (Real Implementation)**
```python
# payments/middleware/usage_tracking.py - Real implementation
import time
import json
from typing import Optional, Dict, Any
from django.http import HttpRequest, HttpResponse
from django.utils.deprecation import MiddlewareMixin
from django.core.cache import cache

from ..config.helpers import MiddlewareConfigHelper
from django_cfg.modules.django_logger import get_logger

logger = get_logger("usage_tracking_middleware")

class UsageTrackingMiddleware(MiddlewareMixin):
    """
    Usage Tracking Middleware for API analytics and monitoring.
    
    Features:
    - Request/response time tracking
    - Endpoint usage statistics
    - User activity monitoring
    - Performance metrics
    - Error rate tracking
    """
    
    def __init__(self, get_response=None):
        super().__init__(get_response)
        
        # Load configuration from django-cfg
        try:
            middleware_config = MiddlewareConfigHelper.get_middleware_config()
            
            self.enabled = middleware_config['usage_tracking_enabled']
            self.track_anonymous = middleware_config['track_anonymous_usage']
            self.api_prefixes = middleware_config['api_prefixes']
            self.cache_timeout = middleware_config['cache_timeouts']['default']
            
        except Exception as e:
            logger.warning(f"Failed to load usage tracking config: {e}")
            self.enabled = True
            self.track_anonymous = False
            self.api_prefixes = ['/api/']
            self.cache_timeout = 3600
        
        logger.info(f"Usage Tracking Middleware initialized", extra={
            'enabled': self.enabled,
            'track_anonymous': self.track_anonymous
        })
    
    def process_request(self, request: HttpRequest) -> Optional[HttpResponse]:
        """Start tracking request."""
        
        if not self.enabled:
            return None
        
        # Only track API requests
        if not any(request.path.startswith(prefix) for prefix in self.api_prefixes):
            return None
        
        # Skip anonymous requests if not enabled
        if not self.track_anonymous and not hasattr(request, 'api_user'):
            return None
        
        # Record start time
        request._usage_start_time = time.time()
        
        return None
    
    def process_response(self, request: HttpRequest, response: HttpResponse) -> HttpResponse:
        """Track response and record usage statistics."""
        
        if not self.enabled or not hasattr(request, '_usage_start_time'):
            return response
        
        # Calculate response time
        response_time = time.time() - request._usage_start_time
        
        # Collect usage data
        usage_data = {
            'endpoint': request.path,
            'method': request.method,
            'status_code': response.status_code,
            'response_time_ms': round(response_time * 1000, 2),
            'timestamp': int(time.time()),
            'user_id': getattr(request, 'api_user', {}).get('id') if hasattr(request, 'api_user') else None,
            'api_key_id': getattr(request, 'api_key', {}).get('id') if hasattr(request, 'api_key') else None,
        }
        
        # Record usage asynchronously
        self._record_usage_async(usage_data)
        
        return response
    
    def _record_usage_async(self, usage_data: Dict[str, Any]):
        """Record usage data asynchronously."""
        try:
            # Update endpoint statistics
            self._update_endpoint_stats(usage_data)
            
            # Update user statistics
            if usage_data['user_id']:
                self._update_user_stats(usage_data)
            
            # Log usage for monitoring
            logger.info("API usage recorded", extra=usage_data)
            
        except Exception as e:
            logger.error(f"Failed to record usage: {e}")
    
    def _update_endpoint_stats(self, usage_data: Dict[str, Any]):
        """Update endpoint usage statistics."""
        endpoint = usage_data['endpoint']
        cache_key = f"endpoint_stats:{endpoint}"
        
        # Get current stats
        stats = cache.get(cache_key, {
            'total_requests': 0,
            'total_response_time': 0,
            'status_codes': {},
            'last_request': None
        })
        
        # Update stats
        stats['total_requests'] += 1
        stats['total_response_time'] += usage_data['response_time_ms']
        stats['last_request'] = usage_data['timestamp']
        
        # Update status code counts
        status_code = str(usage_data['status_code'])
        stats['status_codes'][status_code] = stats['status_codes'].get(status_code, 0) + 1
        
        # Cache updated stats
        cache.set(cache_key, stats, self.cache_timeout)
    
    def _update_user_stats(self, usage_data: Dict[str, Any]):
        """Update user usage statistics."""
        user_id = usage_data['user_id']
        cache_key = f"user_stats:{user_id}"
        
        # Get current stats
        stats = cache.get(cache_key, {
            'total_requests': 0,
            'total_response_time': 0,
            'endpoints': {},
            'last_request': None
        })
        
        # Update stats
        stats['total_requests'] += 1
        stats['total_response_time'] += usage_data['response_time_ms']
        stats['last_request'] = usage_data['timestamp']
        
        # Update endpoint usage
        endpoint = usage_data['endpoint']
        stats['endpoints'][endpoint] = stats['endpoints'].get(endpoint, 0) + 1
        
        # Cache updated stats
        cache.set(cache_key, stats, self.cache_timeout)
```

## ⚙️ Auto-Registration Patterns

### 1. **Feature-Based Registration (Real Implementation)**
```python
# Middleware automatically added based on enabled features
class DjangoConfig(BaseModel):
    """Main configuration with auto-middleware registration."""
    
    enable_accounts: bool = False
    payments: Optional[PaymentsConfig] = None
    
    def get_middleware(self) -> List[str]:
        """Auto-register middleware based on enabled features."""
        middleware = self._get_base_middleware()
        
        # Accounts middleware
        if self.enable_accounts:
            middleware.extend([
                'django_cfg.middleware.user_activity.UserActivityMiddleware',
                'django_cfg.middleware.public_endpoints.PublicEndpointsMiddleware',
            ])
        
        # Payments middleware
        if self.payments and self.payments.enabled:
            middleware.extend(self.payments.get_middleware_classes())
        
        return middleware
```

### 2. **App-Specific Middleware Registration (Real Implementation)**
```python
# apps/payments/models/payments.py - App middleware registration
class PaymentsConfig(BaseModel):
    """Payments configuration with middleware."""
    
    enabled: bool = Field(default=False)
    middleware_enabled: bool = Field(default=True)
    api_access_enabled: bool = Field(default=True)
    rate_limiting_enabled: bool = Field(default=True)
    usage_tracking_enabled: bool = Field(default=True)
    
    def get_middleware_classes(self) -> List[str]:
        """Get middleware classes for payments app."""
        middleware = []
        
        if not self.enabled or not self.middleware_enabled:
            return middleware
        
        # API access middleware
        if self.api_access_enabled:
            middleware.append('django_cfg.apps.payments.middleware.APIAccessMiddleware')
        
        # Rate limiting middleware
        if self.rate_limiting_enabled:
            middleware.append('django_cfg.apps.payments.middleware.RateLimitingMiddleware')
        
        # Usage tracking middleware
        if self.usage_tracking_enabled:
            middleware.append('django_cfg.apps.payments.middleware.UsageTrackingMiddleware')
        
        return middleware
```

## 📊 Statistics & Monitoring

### 1. **Built-in Statistics (Real Implementation)**
```python
# Middleware provides built-in statistics
def get_middleware_stats() -> Dict[str, Any]:
    """Get comprehensive middleware statistics."""
    stats = {}
    
    # API Access stats
    try:
        api_stats = cache.get('api_access_stats', {})
        stats['api_access'] = {
            'requests_processed': api_stats.get('requests_processed', 0),
            'valid_keys': api_stats.get('valid_keys', 0),
            'invalid_keys': api_stats.get('invalid_keys', 0),
            'cache_hits': api_stats.get('cache_hits', 0),
        }
    except:
        stats['api_access'] = {'error': 'Stats unavailable'}
    
    # Rate limiting stats
    try:
        rate_stats = cache.get('rate_limit_stats', {})
        stats['rate_limiting'] = {
            'requests_processed': rate_stats.get('requests_processed', 0),
            'rate_limited': rate_stats.get('rate_limited', 0),
            'rate_limit_percentage': rate_stats.get('rate_limit_percentage', 0),
        }
    except:
        stats['rate_limiting'] = {'error': 'Stats unavailable'}
    
    # Usage tracking stats
    try:
        usage_stats = cache.get('usage_tracking_stats', {})
        stats['usage_tracking'] = {
            'requests_tracked': usage_stats.get('requests_tracked', 0),
            'average_response_time': usage_stats.get('average_response_time', 0),
            'error_rate': usage_stats.get('error_rate', 0),
        }
    except:
        stats['usage_tracking'] = {'error': 'Stats unavailable'}
    
    return stats
```

### 2. **Health Check Integration**
```python
# Health check for middleware
def check_middleware_health() -> Dict[str, Any]:
    """Check middleware health status."""
    try:
        stats = get_middleware_stats()
        
        # Check if middleware is functioning
        healthy = all(
            'error' not in component_stats 
            for component_stats in stats.values()
        )
        
        return {
            'status': 'healthy' if healthy else 'degraded',
            'middleware_active': True,
            'components': stats,
            'last_check': timezone.now().isoformat()
        }
    except Exception as e:
        return {
            'status': 'unhealthy',
            'error': str(e),
            'last_check': timezone.now().isoformat()
        }
```

## 🏷️ Metadata
**Tags**: `middleware, jwt, authentication, monitoring, auto-config, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Real Examples**: API Access, Rate Limiting, Usage Tracking from payments app
**DEPENDS_ON**: [django-cfg-core, django-middleware]
**USED_BY**: [all-django-cfg-apps]
