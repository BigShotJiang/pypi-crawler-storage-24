# 🤖 MCP Browser Testing for Admin Interface

**Problem**: Need to test admin interface functionality without manual browser interaction.

## A. **MCP Playwright Integration**

### Basic Navigation and Login
```javascript
// Navigate to admin interface
await mcp_Playwright_browser_navigate({
    url: "http://localhost:8000/cfg/admin/django_cfg_payments/admin/payments/"
});

// Handle login redirect
await mcp_Playwright_browser_type({
    element: "Email textbox",
    ref: "e13", 
    text: "admin@example.com"
});

await mcp_Playwright_browser_type({
    element: "Password textbox", 
    ref: "e17",
    text: "admin123"
});

await mcp_Playwright_browser_click({
    element: "Log in button",
    ref: "e19"
});
```

## B. **Console Debugging**

### Checking JavaScript Errors
```javascript
// Check console messages for JavaScript errors
await mcp_Playwright_browser_console_messages({
    random_string: "get_console"
});

// Expected successful logs:
// [LOG] PaymentAPI available: object
// [LOG] PaymentAPI.admin: object  
// [LOG] PaymentAPI.admin.payments: object

// Problem indicators:
// [ERROR] Failed to load resource: 500 (Internal Server Error)
// [ERROR] PaymentAPI is not available
```

## C. **Page State Verification**

### Taking Snapshots
```javascript
// Take snapshot to verify page loaded correctly
await mcp_Playwright_browser_snapshot({
    random_string: "current_state"
});

// Expected elements:
// - heading "Payments" [level=2]
// - button "refresh Refresh"
// - table with payment columns
// - "No payments found" (if empty database)
```

## D. **Test Credentials**

### Default Admin Credentials
```bash
# Default admin credentials for testing
Email: admin@example.com
Password: admin123

# Alternative superuser creation
python manage.py createsuperuser
```

## E. **Common MCP Testing Patterns**

### 1. Navigation with Error Handling
```javascript
try {
    await mcp_Playwright_browser_navigate({url: target_url});
} catch (error) {
    console.log("Navigation failed:", error);
}
```

### 2. Form Interaction
```javascript
await mcp_Playwright_browser_fill_form({
    fields: [
        {name: "Email", type: "textbox", ref: "e13", value: "admin@example.com"},
        {name: "Password", type: "textbox", ref: "e17", value: "admin123"}
    ]
});
```

### 3. API Endpoint Testing via Browser
```javascript
await mcp_Playwright_browser_evaluate({
    function: `() => {
        return fetch('/cfg/admin/django_cfg_payments/admin/api/payments/')
            .then(r => r.json())
            .then(data => console.log('API Response:', data))
            .catch(e => console.error('API Error:', e));
    }`
});
```

## F. **Debugging Workflow**

### Step-by-Step Process
1. **Navigate** → Check for login redirect
2. **Login** → Verify successful authentication  
3. **Console** → Look for JavaScript/API errors
4. **Snapshot** → Confirm UI elements loaded
5. **Interact** → Test functionality (refresh, filters, etc.)

## G. **Real-World Debugging Example**

### Case Study: Payment List Page Not Loading

```javascript
// Step 1: Navigate and check initial state
await mcp_Playwright_browser_navigate({
    url: "http://localhost:8000/cfg/admin/django_cfg_payments/admin/payments/"
});

// Result: Redirected to login - expected behavior
// Page URL: http://localhost:8000/admin/login/?next=/cfg/admin/...

// Step 2: Login with correct credentials  
await mcp_Playwright_browser_type({
    element: "Email textbox",
    ref: "e13",
    text: "admin@example.com"  // ✅ Correct email
});

await mcp_Playwright_browser_type({
    element: "Password textbox", 
    ref: "e17",
    text: "admin123"  // ✅ Correct password
});

await mcp_Playwright_browser_click({
    element: "Log in button",
    ref: "e19"
});

// Step 3: Check console for errors
await mcp_Playwright_browser_console_messages({
    random_string: "debug_console"
});

// Found problems:
// [ERROR] Failed to load resource: 500 (Internal Server Error)
// [ERROR] API Request failed: Error: Request failed
// [ERROR] Failed to load payments: Error: Request failed

// Step 4: Analyze the error pattern
// ❌ JavaScript loads correctly (PaymentAPI available: object)
// ❌ API endpoint returns 500 error
// ✅ Conclusion: Server-side issue, not client-side

// Step 5: Check server logs (terminal)
// TypeError: 'Meta.fields' must not contain non-model field names: currency_code
// ✅ Root cause found: Wrong field name in filterset_fields

// Step 6: Fix and verify
// Changed: filterset_fields = ['status', 'provider', 'currency_code', 'user']
// To:      filterset_fields = ['status', 'provider', 'currency__code', 'user']

// Step 7: Test fix with MCP
await mcp_Playwright_browser_click({
    element: "Refresh button",
    ref: "e22"
});

// Result: No more 500 errors, page shows "No payments found" (expected)
```

## H. **Advanced MCP Techniques**

### 1. **Multiple Page Testing**
```javascript
// Test multiple admin pages in sequence
const pages = [
    '/cfg/admin/django_cfg_payments/admin/',
    '/cfg/admin/django_cfg_payments/admin/payments/',
    '/cfg/admin/django_cfg_payments/admin/webhooks/'
];

for (const page of pages) {
    await mcp_Playwright_browser_navigate({url: `http://localhost:8000${page}`});
    await mcp_Playwright_browser_console_messages({random_string: `test_${page.split('/').pop()}`});
}
```

### 2. **Form Submission Testing**
```javascript
// Test payment creation form
await mcp_Playwright_browser_navigate({
    url: "http://localhost:8000/cfg/admin/django_cfg_payments/admin/payments/create/"
});

await mcp_Playwright_browser_fill_form({
    fields: [
        {name: "Amount", type: "textbox", ref: "amount_field", value: "100.00"},
        {name: "Currency", type: "combobox", ref: "currency_field", value: "USD"}
    ]
});

await mcp_Playwright_browser_click({
    element: "Create Payment button",
    ref: "submit_button"
});
```

### 3. **Network Request Monitoring**
```javascript
// Monitor network requests
await mcp_Playwright_browser_network_requests({
    random_string: "get_requests"
});

// Look for:
// - Successful API calls (200 status)
// - Failed requests (4xx, 5xx status)
// - Missing resources (404 status)
```

## I. **Key Lessons from Real Experience**

### 1. **MCP reveals both client and server issues**
- JavaScript errors show in console logs
- Server errors show as HTTP status codes
- Network tab shows request/response details

### 2. **Console logs distinguish JavaScript vs API problems**
- `PaymentAPI available: object` = JavaScript working
- `500 Internal Server Error` = Server-side issue
- `PaymentAPI is not available` = JavaScript loading problem

### 3. **Server logs provide the exact error details**
- MCP shows symptoms (500 error)
- Terminal logs show root cause (field name error)
- Combination gives complete picture

### 4. **MCP enables rapid fix verification**
- Make code change
- Click refresh in MCP browser
- Immediately see if fix worked
- No manual browser interaction needed

## J. **Benefits of MCP Testing**

### ✅ **Advantages**
- 🤖 **Automated**: No manual browser interaction needed
- 🔍 **Detailed Logs**: Console messages and network requests
- 📸 **Visual Verification**: Page snapshots for debugging
- 🚀 **Fast Iteration**: Quick testing of fixes
- 🎯 **Precise**: Exact element references and interactions
- 📊 **Comprehensive**: Client-side and server-side debugging

### 🎯 **Best Use Cases**
- Admin interface functionality testing
- JavaScript API integration verification
- Form submission workflows
- Authentication flow testing
- Error condition reproduction
- Regression testing after fixes

### 🔧 **Integration with Development Workflow**
1. **Develop** → Write code
2. **Test** → Use MCP to verify functionality
3. **Debug** → Analyze console logs and snapshots
4. **Fix** → Make corrections
5. **Verify** → Re-test with MCP
6. **Document** → Record successful patterns
