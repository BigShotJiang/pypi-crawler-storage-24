# 🎯 Django-CFG Integration Patterns

## 1. **Main URLs Configuration**

### Project-Level URL Structure
```python
# main_project/urls.py
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # Django admin
    path('admin/', admin.site.urls),
    
    # Django-CFG apps
    path('api/', include('django_cfg.apps.urls')),
    
    # Health checks
    path('health/', include('django_cfg.core.health.urls')),
    
    # Authentication (if using custom auth)
    path('auth/', include('django_cfg.auth.urls')),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
```

### Django-CFG Apps Router
```python
# django_cfg/apps/urls.py
from django.urls import path, include

urlpatterns = [
    # Core apps
    path('payments/', include('django_cfg.apps.payments.urls')),
    path('knowbase/', include('django_cfg.apps.knowbase.urls')),
    path('support/', include('django_cfg.apps.support.urls')),
    path('newsletter/', include('django_cfg.apps.newsletter.urls')),
    
    # Admin interfaces
    path('cfg/admin/django_cfg_payments/', include('django_cfg.apps.payments.urls_admin')),
    path('cfg/admin/django_cfg_knowbase/', include('django_cfg.apps.knowbase.urls_admin')),
    path('cfg/admin/django_cfg_support/', include('django_cfg.apps.support.urls_admin')),
    
    # System endpoints
    path('system/', include('django_cfg.core.system.urls')),
]
```

## 2. **App Registration Pattern**

### Automatic App Discovery
```python
# django_cfg/apps/urls.py
import importlib
from django.urls import path, include
from django.conf import settings

def get_app_urls():
    """Automatically discover and include app URLs."""
    app_urls = []
    
    # Get Django-CFG apps from settings
    django_cfg_apps = [
        app for app in settings.INSTALLED_APPS 
        if app.startswith('django_cfg.apps.')
    ]
    
    for app_path in django_cfg_apps:
        app_name = app_path.split('.')[-1]  # Extract app name
        
        try:
            # Try to import app URLs
            urls_module = importlib.import_module(f'{app_path}.urls')
            app_urls.append(path(f'{app_name}/', include(f'{app_path}.urls')))
            
            # Try to import admin URLs
            try:
                admin_urls_module = importlib.import_module(f'{app_path}.urls_admin')
                app_urls.append(
                    path(f'cfg/admin/django_cfg_{app_name}/', 
                         include(f'{app_path}.urls_admin'))
                )
            except ImportError:
                pass  # No admin URLs for this app
                
        except ImportError:
            continue  # Skip apps without URLs
    
    return app_urls

urlpatterns = get_app_urls()
```

### Configuration-Driven Registration
```python
# django_cfg/apps/urls.py
from django.urls import path, include
from django_cfg.core.config import get_app_config

def get_configured_urls():
    """Include URLs based on app configuration."""
    urls = []
    
    # Payments app
    payments_config = get_app_config('payments')
    if payments_config.enabled:
        urls.append(path('payments/', include('django_cfg.apps.payments.urls')))
        
        if payments_config.admin_enabled:
            urls.append(
                path('cfg/admin/django_cfg_payments/', 
                     include('django_cfg.apps.payments.urls_admin'))
            )
    
    # Knowbase app
    knowbase_config = get_app_config('knowbase')
    if knowbase_config.enabled:
        urls.append(path('knowbase/', include('django_cfg.apps.knowbase.urls')))
    
    return urls

urlpatterns = get_configured_urls()
```

## 3. **Environment-Specific URLs**

### Development vs Production
```python
# django_cfg/apps/urls.py
from django.conf import settings
from django.urls import path, include

# Base URLs for all environments
urlpatterns = [
    path('payments/', include('django_cfg.apps.payments.urls')),
    path('knowbase/', include('django_cfg.apps.knowbase.urls')),
]

# Development-only URLs
if settings.DEBUG:
    urlpatterns += [
        path('debug/payments/', include('django_cfg.apps.payments.debug_urls')),
        path('test/', include('django_cfg.core.test_urls')),
    ]

# Production-only URLs
if not settings.DEBUG:
    urlpatterns += [
        path('monitoring/', include('django_cfg.core.monitoring.urls')),
    ]
```

### Feature Flag URLs
```python
from django_cfg.core.features import is_feature_enabled

def get_feature_urls():
    """Include URLs based on feature flags."""
    urls = []
    
    # Base URLs always included
    urls.extend([
        path('payments/', include('django_cfg.apps.payments.urls')),
    ])
    
    # Feature-gated URLs
    if is_feature_enabled('advanced_analytics'):
        urls.append(path('analytics/', include('django_cfg.apps.analytics.urls')))
    
    if is_feature_enabled('ai_support'):
        urls.append(path('ai/', include('django_cfg.apps.ai.urls')))
    
    return urls

urlpatterns = get_feature_urls()
```

## 4. **URL Debugging Command**

### Custom Management Command
```python
# django_cfg/core/management/commands/show_cfg_urls.py
from django.core.management.base import BaseCommand
from django.urls import get_resolver
from django.conf import settings

class Command(BaseCommand):
    help = 'Show all Django-CFG URL patterns'
    
    def add_arguments(self, parser):
        parser.add_argument(
            '--app',
            type=str,
            help='Show URLs for specific app only'
        )
        parser.add_argument(
            '--format',
            choices=['table', 'json', 'tree'],
            default='table',
            help='Output format'
        )
    
    def handle(self, *args, **options):
        resolver = get_resolver()
        patterns = self.collect_patterns(resolver.url_patterns)
        
        if options['app']:
            patterns = [p for p in patterns if options['app'] in p['name']]
        
        if options['format'] == 'table':
            self.print_table(patterns)
        elif options['format'] == 'json':
            self.print_json(patterns)
        else:
            self.print_tree(patterns)
    
    def collect_patterns(self, patterns, prefix=''):
        """Recursively collect URL patterns."""
        collected = []
        
        for pattern in patterns:
            if hasattr(pattern, 'url_patterns'):
                # URLconf include
                collected.extend(
                    self.collect_patterns(
                        pattern.url_patterns, 
                        prefix + str(pattern.pattern)
                    )
                )
            else:
                # URL pattern
                collected.append({
                    'pattern': prefix + str(pattern.pattern),
                    'name': pattern.name,
                    'view': str(pattern.callback),
                })
        
        return collected
```

### Usage Examples
```bash
# Show all Django-CFG URLs (custom command - needs to be implemented)
python manage.py show_cfg_urls

# Show payments app URLs only
python manage.py show_cfg_urls --app payments

# Output as JSON
python manage.py show_cfg_urls --format json

# Tree format
python manage.py show_cfg_urls --format tree
```

## 5. **Dynamic URL Generation**

### Provider-Based URLs
```python
# django_cfg/apps/payments/urls.py
from .providers import get_enabled_providers

def get_provider_urls():
    """Generate URLs for enabled payment providers."""
    urls = []
    
    for provider in get_enabled_providers():
        urls.extend([
            path(f'webhooks/{provider}/', 
                 WebhookView.as_view(), 
                 {'provider': provider},
                 name=f'webhook-{provider}'),
            
            path(f'callbacks/{provider}/', 
                 CallbackView.as_view(), 
                 {'provider': provider},
                 name=f'callback-{provider}'),
        ])
    
    return urls

# Add to main urlpatterns
urlpatterns += get_provider_urls()
```

### Database-Driven URLs
```python
from .models import CustomEndpoint

def get_custom_urls():
    """Generate URLs from database configuration."""
    urls = []
    
    for endpoint in CustomEndpoint.objects.filter(is_active=True):
        urls.append(
            path(f'custom/{endpoint.slug}/', 
                 CustomView.as_view(), 
                 {'endpoint_id': endpoint.id},
                 name=f'custom-{endpoint.slug}')
        )
    
    return urls

# Cached URL generation
from django.core.cache import cache

def get_cached_custom_urls():
    """Cache custom URLs for performance."""
    cache_key = 'custom_urls'
    urls = cache.get(cache_key)
    
    if urls is None:
        urls = get_custom_urls()
        cache.set(cache_key, urls, 3600)  # 1 hour
    
    return urls
```

## 6. **API Versioning Integration**

### Version-Specific Apps
```python
# django_cfg/apps/urls.py
from django.urls import path, include

urlpatterns = [
    # Version 1 (legacy)
    path('v1/payments/', include('django_cfg.apps.payments.urls_v1')),
    path('v1/knowbase/', include('django_cfg.apps.knowbase.urls_v1')),
    
    # Version 2 (current)
    path('v2/payments/', include('django_cfg.apps.payments.urls')),
    path('v2/knowbase/', include('django_cfg.apps.knowbase.urls')),
    
    # Default to latest version
    path('payments/', include('django_cfg.apps.payments.urls')),
    path('knowbase/', include('django_cfg.apps.knowbase.urls')),
]
```

### Header-Based Versioning
```python
class VersionedURLRouter:
    """Route to different URLs based on API version header."""
    
    def __init__(self):
        self.version_patterns = {
            'v1': 'django_cfg.apps.payments.urls_v1',
            'v2': 'django_cfg.apps.payments.urls',
        }
    
    def get_urls(self, request):
        """Return URLs based on version header."""
        version = request.META.get('HTTP_API_VERSION', 'v2')
        return self.version_patterns.get(version, self.version_patterns['v2'])
```

## 7. **Middleware Integration**

### URL-Based Middleware Configuration
```python
# settings.py
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django_cfg.middleware.APIVersionMiddleware',  # Custom middleware
    'django_cfg.apps.payments.middleware.APIAccessMiddleware',  # App-specific
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
]

# Custom middleware that affects URL routing
class APIVersionMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    
    def __call__(self, request):
        # Modify request based on URL patterns
        if request.path.startswith('/api/v1/'):
            request.api_version = 'v1'
        elif request.path.startswith('/api/v2/'):
            request.api_version = 'v2'
        else:
            request.api_version = 'v2'  # Default
        
        return self.get_response(request)
```

## 8. **Testing Integration**

### URL Integration Tests
```python
from django.test import TestCase
from django.urls import reverse, resolve
from django.conf import settings

class URLIntegrationTest(TestCase):
    
    def test_all_apps_registered(self):
        """Test that all Django-CFG apps have URLs registered."""
        django_cfg_apps = [
            app for app in settings.INSTALLED_APPS 
            if app.startswith('django_cfg.apps.')
        ]
        
        for app_path in django_cfg_apps:
            app_name = app_path.split('.')[-1]
            
            # Test main app URL exists
            try:
                url = reverse(f'cfg_{app_name}:some-view')
                self.assertTrue(url.startswith(f'/api/{app_name}/'))
            except:
                pass  # Some apps might not have standard views
    
    def test_admin_urls_accessible(self):
        """Test admin URLs are properly configured."""
        admin_urls = [
            'cfg_payments_admin:dashboard',
            'cfg_knowbase_admin:dashboard',
        ]
        
        for url_name in admin_urls:
            try:
                url = reverse(url_name)
                self.assertTrue(url.startswith('/api/cfg/admin/'))
            except:
                self.fail(f"Admin URL {url_name} not found")
```

## 9. **Performance Optimization**

### URL Pattern Caching
```python
from django.core.cache import cache
from django.urls import include, path

def get_cached_patterns():
    """Cache expensive URL pattern generation."""
    cache_key = 'django_cfg_url_patterns'
    patterns = cache.get(cache_key)
    
    if patterns is None:
        patterns = generate_dynamic_patterns()
        cache.set(cache_key, patterns, 3600)  # 1 hour
    
    return patterns

def generate_dynamic_patterns():
    """Generate URL patterns dynamically."""
    patterns = []
    
    # Add patterns based on configuration
    for app_config in get_enabled_apps():
        patterns.append(
            path(f'{app_config.url_prefix}/', 
                 include(f'{app_config.module}.urls'))
        )
    
    return patterns
```

### Lazy URL Loading
```python
from django.utils.functional import lazy

# Lazy load expensive URL patterns
lazy_patterns = lazy(get_expensive_patterns, list)

urlpatterns = [
    path('api/', include('django_cfg.apps.urls')),
] + lazy_patterns()
```

## 10. **Documentation Integration**

### Auto-Generated URL Documentation
```python
# django_cfg/core/docs/urls.py
from django.urls import path
from .views import URLDocumentationView

urlpatterns = [
    path('urls/', URLDocumentationView.as_view(), name='url-docs'),
]

class URLDocumentationView(TemplateView):
    template_name = 'docs/urls.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Generate URL documentation
        context['url_patterns'] = self.get_documented_patterns()
        
        return context
    
    def get_documented_patterns(self):
        """Generate documentation for all URL patterns."""
        from django.urls import get_resolver
        
        resolver = get_resolver()
        patterns = []
        
        for pattern in resolver.url_patterns:
            if 'django_cfg' in str(pattern):
                patterns.append({
                    'pattern': str(pattern.pattern),
                    'name': getattr(pattern, 'name', None),
                    'description': self.get_pattern_description(pattern),
                })
        
        return patterns
```

## 11. **Best Practices Summary**

### ✅ **DO**
- Use consistent app naming (`cfg_` prefix)
- Implement automatic app discovery
- Support environment-specific URLs
- Cache expensive URL generation
- Include comprehensive URL testing
- Document URL patterns automatically
- Use configuration-driven URL registration

### ❌ **DON'T**
- Hardcode app URLs in main configuration
- Skip URL pattern validation
- Ignore performance implications
- Mix different URL naming conventions
- Forget to handle missing apps gracefully
- Create circular URL dependencies

### 🎯 **Result**
- Scalable URL architecture
- Easy app integration
- Maintainable URL patterns
- Performance-optimized routing
- Comprehensive documentation
- Flexible configuration options
