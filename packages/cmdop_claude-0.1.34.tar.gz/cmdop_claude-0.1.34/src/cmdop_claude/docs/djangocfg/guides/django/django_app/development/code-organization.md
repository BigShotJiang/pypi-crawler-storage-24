# 📁 Code Organization & Decomposition Guidelines

## 🎯 Core Principles

### File Size Limits
- **Maximum 500 lines per file** (excluding comments and docstrings)
- **Maximum 300 lines for complex logic files** (models, services, managers)
- **Maximum 200 lines for configuration files**
- **Maximum 400 lines for test files** (tests should be focused and modular)
- **Maximum 150 lines per test class** (split large test classes by functionality)

### Decomposition Strategy
When a file exceeds size limits:

1. **Create a package directory** with the same name as the original file
2. **Split into logical components** based on functionality
3. **Create `__init__.py`** as the main entry point
4. **Delete the original file** to avoid naming conflicts
5. **Update all imports** to use the new package structure

### Import Rules
- **NO inline imports** - all imports must be at the top of the file
- **Exceptions only for**: circular import resolution, optional dependencies, performance-critical lazy loading
- **Group imports**: standard library, third-party, local imports (separated by blank lines)
- **Explicit imports**: prefer `from module import SpecificClass` over `import module`

```python
# ✅ Good - All imports at top, properly grouped
import os
import sys
from typing import Dict, List, Optional

from django.db import models
from django.contrib.auth import get_user_model

from django_cfg.apps.payments.models import Currency
from django_cfg.apps.payments.services.cache_service import CacheService

# ❌ Bad - Inline imports
def process_payment():
    from django_cfg.apps.payments.models import Payment  # NO!
    return Payment.objects.create()

# ✅ Exception - Circular import resolution
def get_payment_processor():
    from django_cfg.apps.payments.processors import PaymentProcessor  # OK - circular import
    return PaymentProcessor()
```

## 🤖 LLM-Friendly Code Guidelines

### Naming Conventions

#### Files & Directories
```python
# ✅ Good - Clear, descriptive names
cache_service/
├── __init__.py          # Main entry point
├── interfaces.py        # Abstract interfaces
├── simple_cache.py      # Basic implementation
├── api_key_cache.py     # API key specific cache
├── rate_limit_cache.py  # Rate limiting cache
└── keys.py             # Cache key generators

# ❌ Bad - Vague, abbreviated names
cache/
├── base.py
├── impl.py
├── utils.py
└── helpers.py
```

#### Classes & Functions
```python
# ✅ Good - Self-documenting names
class PaymentProcessorService:
    def process_cryptocurrency_payment(self, payment_data: PaymentRequest) -> PaymentResult:
        pass
    
    def validate_payment_amount_limits(self, amount: Decimal, currency: str) -> bool:
        pass

# ❌ Bad - Unclear purpose
class PaymentSvc:
    def process(self, data):
        pass
    
    def check(self, amt, cur):
        pass
```

### Code Structure Patterns

#### 1. Logical Grouping
```python
# Group related functionality together
class UserBalanceManager(models.Manager):
    # Creation methods
    def get_or_create_for_user(self, user: User) -> UserBalance:
        pass
    
    # Balance operations  
    def add_funds_to_user(self, user: User, amount: Decimal) -> UserBalance:
        pass
    
    def subtract_funds_from_user(self, user: User, amount: Decimal) -> UserBalance:
        pass
    
    # Query methods
    def get_balance_for_user(self, user: User) -> Decimal:
        pass
```

#### 2. Clear Separation of Concerns
```python
# ✅ Good - Each file has single responsibility
payment_service/
├── __init__.py              # Main service class
├── processors/              # Payment processing logic
│   ├── cryptocurrency.py    # Crypto payment processing
│   ├── fiat.py             # Fiat payment processing
│   └── webhook_handlers.py  # Webhook processing
├── validators/              # Validation logic
│   ├── amount_validator.py  # Amount validation
│   └── currency_validator.py # Currency validation
└── types/                   # Data structures
    ├── requests.py          # Request models
    └── responses.py         # Response models
```

### Documentation Requirements

#### File Headers
```python
"""
Brief description of the file's purpose.

Detailed explanation of what this module does and how it fits
into the larger system. Include key classes and functions.

Example:
    from django_cfg.apps.payments.services.cache_service import CacheService
    
    cache = CacheService()
    cache.simple_cache.set("key", "value")
"""
```

#### Class Documentation
```python
class PaymentProcessorService:
    """
    Handles payment processing for multiple payment providers.
    
    This service coordinates between different payment processors,
    handles validation, and manages the payment lifecycle.
    
    Attributes:
        processors: Dict of available payment processors
        validator: Payment validation service
        
    Example:
        processor = PaymentProcessorService()
        result = processor.process_payment(payment_request)
    """
```

#### Method Documentation
```python
def process_cryptocurrency_payment(
    self, 
    payment_data: PaymentRequest,
    provider: str = "nowpayments"
) -> PaymentResult:
    """
    Process a cryptocurrency payment through the specified provider.
    
    Args:
        payment_data: Payment request containing amount, currency, etc.
        provider: Payment provider name (default: "nowpayments")
        
    Returns:
        PaymentResult containing status, transaction_id, and metadata
        
    Raises:
        PaymentValidationError: If payment data is invalid
        PaymentProcessingError: If payment processing fails
        
    Example:
        request = PaymentRequest(amount=100.0, currency="BTC")
        result = service.process_cryptocurrency_payment(request)
    """
```

## 🔄 Decomposition Process

### Step-by-Step Guide

1. **Identify Large Files**
   ```bash
   find . -name "*.py" -exec wc -l {} + | sort -nr | head -20
   ```

2. **Analyze Functionality**
   - Group related classes/functions
   - Identify natural boundaries
   - Consider dependencies

3. **Create Package Structure**
   ```bash
   mkdir original_file_name/
   touch original_file_name/__init__.py
   ```

4. **Split Components**
   - Move related classes to separate files
   - Keep interfaces and base classes separate
   - Group utilities and helpers

5. **Update Entry Point**
   ```python
   # original_file_name/__init__.py
   from .main_class import MainClass
   from .utilities import helper_function
   
   __all__ = ['MainClass', 'helper_function']
   ```

6. **Update Imports**
   ```python
   # Before
   from myapp.services.large_service import SomeClass
   
   # After  
   from myapp.services.large_service import SomeClass  # Still works!
   ```

### Test File Organization

#### Test Size Limits
- **400 lines maximum per test file**
- **150 lines maximum per test class**
- **Split by functionality**, not by file structure

#### Test Decomposition Strategy
```python
# ✅ Good - Focused test classes
class UserBalanceManagerTest(TestCase):  # 45 lines
    """Test user balance operations."""
    
class PaymentManagerTest(TestCase):      # 67 lines  
    """Test payment processing."""

class CurrencyManagerTest(TestCase):     # 38 lines
    """Test currency operations."""

# ❌ Bad - Monolithic test class
class PaymentSystemTest(TestCase):       # 300+ lines
    """Test everything payment-related."""
```

#### Test File Naming
```
tests/
├── models/
│   ├── test_payment_models.py      # 120 lines - Payment model tests
│   ├── test_balance_models.py      # 95 lines - Balance model tests
│   └── test_currency_models.py     # 78 lines - Currency model tests
├── services/
│   ├── test_payment_service.py     # 145 lines - Payment service tests
│   └── test_cache_service.py       # 380 lines - Cache service tests
└── views/
    └── test_payment_api.py         # 200 lines - API endpoint tests
```

### Real Example: Cache Service Decomposition

**Before (236 lines):**
```
cache_service.py  # Too large, mixed responsibilities
```

**After (5 files, each <100 lines):**
```
cache_service/
├── __init__.py          # 67 lines - Main service + exports
├── interfaces.py        # 28 lines - Abstract interfaces  
├── simple_cache.py      # 89 lines - Basic implementation
├── api_key_cache.py     # 32 lines - API key cache
├── rate_limit_cache.py  # 42 lines - Rate limiting
└── keys.py             # 38 lines - Key generators
```

## 🎯 LLM Agent Benefits

### Improved Navigation
- **Clear file purposes** - LLM can quickly understand what each file does
- **Logical grouping** - Related functionality is co-located
- **Predictable structure** - Consistent patterns across the codebase

### Better Context Understanding
- **Self-documenting names** - Reduce need for extensive code analysis
- **Focused files** - Each file has single, clear responsibility
- **Explicit dependencies** - Import structure shows relationships

### Efficient Code Generation
- **Template patterns** - Consistent structure enables pattern reuse
- **Modular approach** - Easy to extend without affecting other components
- **Clear interfaces** - Well-defined contracts between components

## 📋 Checklist for New Code

### Before Writing
- [ ] File will be under size limits (500 lines code, 400 lines tests)
- [ ] Single responsibility principle followed
- [ ] Clear, descriptive naming chosen
- [ ] Dependencies identified and minimized
- [ ] All imports planned at top of file (no inline imports)

### During Development
- [ ] Logical grouping of related functions
- [ ] Comprehensive docstrings added
- [ ] Type hints provided where applicable
- [ ] Examples included in documentation
- [ ] Imports properly grouped (stdlib, third-party, local)

### After Implementation
- [ ] File size checked (split if needed)
- [ ] Import paths verified (no inline imports)
- [ ] Documentation updated
- [ ] Tests cover new functionality
- [ ] Test classes under 150 lines each

### For Tests Specifically
- [ ] Test file under 400 lines
- [ ] Test classes focused and under 150 lines
- [ ] Tests split by functionality, not file structure
- [ ] Clear test naming (test_specific_behavior)
- [ ] No inline imports in test files

## 🚀 Automation Opportunities

### Pre-commit Hooks
```python
# Check file sizes
def check_file_sizes():
    for file in python_files:
        if line_count(file) > 500:
            suggest_decomposition(file)
```

### IDE Integration
- **File size warnings** at 400+ lines
- **Decomposition suggestions** based on class/function analysis
- **Auto-import updates** when files are split

This approach ensures our codebase remains maintainable, navigable, and LLM-friendly as it grows!
