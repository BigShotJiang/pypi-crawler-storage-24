# 🔍 Real Test Examples

## 1. **Agent Testing (Real Implementation)**
```python
# agents/tests/test_agent.py - Real implementation
from django.test import TestCase
from django.contrib.auth.models import User
from unittest.mock import Mock, patch
from dataclasses import dataclass
from typing import Dict, Any

from pydantic import BaseModel, Field
from django_cfg.modules.django_orchestrator.core.agent import DjangoAgent
from django_cfg.modules.django_orchestrator.core.dependencies import DjangoDeps

@dataclass
class TestDeps:
    """Test dependencies."""
    user_id: int
    test_data: Dict[str, Any] = None

class TestResult(BaseModel):
    """Test result model."""
    success: bool = Field(..., description="Success status")
    message: str = Field(..., description="Result message")
    data: Dict[str, Any] = Field(default_factory=dict)

class DjangoAgentTestCase(TestCase):
    """Test DjangoAgent functionality."""
    
    def setUp(self):
        """Set up test data."""
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
        self.deps = DjangoDeps(user=self.user)
        
    def test_agent_initialization_success(self):
        """Test successful agent initialization."""
        agent = DjangoAgent[TestDeps, TestResult](
            name="test_agent",
            deps_type=TestDeps,
            output_type=TestResult,
            instructions="Test instructions"
        )
        
        self.assertEqual(agent.name, "test_agent")
        self.assertEqual(agent.deps_type, TestDeps)
        self.assertEqual(agent.output_type, TestResult)
        self.assertEqual(agent.instructions, "Test instructions")
        self.assertEqual(agent.timeout, 300)
        self.assertEqual(agent.max_retries, 3)
        self.assertTrue(agent.enable_caching)
    
    def test_agent_metrics_calculation(self):
        """Test agent metrics calculation accuracy."""
        agent = DjangoAgent[TestDeps, TestResult](
            name="perf_agent",
            deps_type=TestDeps,
            output_type=TestResult,
            instructions="Performance test"
        )
        
        # Simulate execution metrics
        agent._execution_count = 10
        agent._total_execution_time = 25.5
        agent._error_count = 2
        agent._cache_hits = 3
        
        metrics = agent.get_metrics()
        
        # Test calculations
        self.assertEqual(metrics['execution_count'], 10)
        self.assertEqual(metrics['total_execution_time'], 25.5)
        self.assertEqual(metrics['average_execution_time'], 2.55)
        self.assertEqual(metrics['error_count'], 2)
        self.assertEqual(metrics['success_rate'], 0.8)  # (10-2)/10
        self.assertEqual(metrics['cache_hits'], 3)
        self.assertEqual(metrics['cache_hit_rate'], 0.3)  # 3/10
    
    @patch('django_cfg.modules.django_orchestrator.core.agent.DjangoAgent._get_default_llm_client')
    def test_agent_with_mock_llm_client(self, mock_get_client):
        """Test agent initialization with mocked LLM client."""
        mock_client = Mock()
        mock_get_client.return_value = mock_client
        
        agent = DjangoAgent[TestDeps, TestResult](
            name="mock_client_agent",
            deps_type=TestDeps,
            output_type=TestResult,
            instructions="Test with mock client"
        )
        
        self.assertEqual(agent.llm_client, mock_client)
        mock_get_client.assert_called_once()
    
    def test_tool_registration(self):
        """Test tool registration with agent."""
        agent = DjangoAgent[TestDeps, TestResult](
            name="tool_agent",
            deps_type=TestDeps,
            output_type=TestResult,
            instructions="Agent with tools"
        )
        
        @agent.tool
        def test_tool(ctx) -> str:
            """Test tool function."""
            return "tool result"
        
        # Tool should be registered (this is handled by Pydantic AI)
        self.assertEqual(test_tool.__name__, "test_tool")
        self.assertIsNotNone(test_tool.__doc__)
```

## 2. **Model Testing (Real Implementation)**
```python
# accounts/tests/test_models.py - Real implementation
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.utils import timezone
from datetime import timedelta

from ..models import OTPSecret, RegistrationSource, UserRegistrationSource

User = get_user_model()

class CustomUserModelTest(TestCase):
    """Test CustomUser model."""

    def setUp(self):
        self.user_data = {
            'email': 'test@example.com',
            'username': 'testuser',
            'password': 'testpass123'
        }

    def test_create_user(self):
        """Test creating a user."""
        user = User.objects.create_user(**self.user_data)

        self.assertEqual(user.email, 'test@example.com')
        self.assertEqual(user.username, 'testuser')
        self.assertTrue(user.check_password('testpass123'))
        self.assertTrue(user.is_active)
        self.assertFalse(user.is_staff)

    def test_create_superuser(self):
        """Test creating a superuser."""
        user = User.objects.create_superuser(**self.user_data)

        self.assertTrue(user.is_staff)
        self.assertTrue(user.is_superuser)
        self.assertTrue(user.is_admin)

    def test_user_phone_verification(self):
        """Test user phone verification field."""
        user = User.objects.create_user(
            email='test@example.com',
            phone='+1234567890'
        )
        
        # Initially phone not verified
        self.assertFalse(user.phone_verified)
        
        # Mark phone as verified
        user.phone_verified = True
        user.save()
        
        user.refresh_from_db()
        self.assertTrue(user.phone_verified)
    
    def test_user_get_identifier_for_otp(self):
        """Test getting identifier for OTP based on channel."""
        user = User.objects.create_user(
            email='test@example.com',
            phone='+1234567890'
        )
        
        # Test email channel
        self.assertEqual(user.get_identifier_for_otp('email'), 'test@example.com')
        
        # Test phone channel  
        self.assertEqual(user.get_identifier_for_otp('phone'), '+1234567890')
        
        # Test default (email)
        self.assertEqual(user.get_identifier_for_otp(), 'test@example.com')

class OTPSecretModelTest(TestCase):
    """Test OTPSecret model."""

    def setUp(self):
        self.email = 'test@example.com'

    def test_otp_generation(self):
        """Test OTP generation."""
        otp = OTPSecret.generate_otp()
        self.assertEqual(len(otp), 6)
        self.assertTrue(otp.isdigit())

    def test_otp_expiration(self):
        """Test OTP expiration."""
        # Create OTP with past expiration
        past_time = timezone.now() - timedelta(minutes=1)
        otp = OTPSecret.objects.create(
            email=self.email,
            secret='123456',
            expires_at=past_time
        )
        self.assertFalse(otp.is_valid)

    def test_otp_create_for_email(self):
        """Test creating OTP for email channel."""
        otp = OTPSecret.create_for_email(self.email)
        
        self.assertEqual(otp.channel_type, 'email')
        self.assertEqual(otp.recipient, self.email)
        self.assertEqual(otp.email, self.email)  # Backward compatibility
        self.assertEqual(len(otp.secret), 6)
        self.assertTrue(otp.secret.isdigit())
        self.assertFalse(otp.is_used)
    
    def test_otp_create_for_phone(self):
        """Test creating OTP for phone channel."""
        phone = '+1234567890'
        otp = OTPSecret.create_for_phone(phone)
        
        self.assertEqual(otp.channel_type, 'phone')
        self.assertEqual(otp.recipient, phone)
        self.assertIsNone(otp.email)  # No email for phone OTP
        self.assertEqual(len(otp.secret), 6)
        self.assertTrue(otp.secret.isdigit())
        self.assertFalse(otp.is_used)
```

## 3. **Service Testing with Mocks (Real Implementation)**
```python
# Real pattern from knowbase tests
from django.test import TestCase
from unittest.mock import Mock, patch, AsyncMock
from django.contrib.auth import get_user_model

from ..services.embedding.processors import EmbeddingProcessor
from ..models import ExternalData, ExternalDataChunk

User = get_user_model()

class EmbeddingProcessorTestCase(TestCase):
    """Test embedding processor functionality."""
    
    def setUp(self):
        """Set up test data."""
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com'
        )
        
        self.external_data = ExternalData.objects.create(
            user=self.user,
            title="Test Document",
            content="This is test content for embedding processing.",
            source_type="manual"
        )
    
    @patch('django_cfg.modules.django_llm.get_embeddings')
    def test_process_document_success(self, mock_get_embeddings):
        """Test successful document processing."""
        # Mock embedding response
        mock_get_embeddings.return_value = [0.1, 0.2, 0.3, 0.4, 0.5]
        
        processor = EmbeddingProcessor()
        result = processor.process_document(self.external_data)
        
        # Verify processing
        self.assertTrue(result.success)
        self.assertIsNotNone(result.chunks_created)
        self.assertGreater(result.chunks_created, 0)
        
        # Verify chunks were created
        chunks = ExternalDataChunk.objects.filter(external_data=self.external_data)
        self.assertGreater(chunks.count(), 0)
        
        # Verify embedding was called
        mock_get_embeddings.assert_called()
    
    @patch('django_cfg.modules.django_llm.get_embeddings')
    def test_process_document_embedding_failure(self, mock_get_embeddings):
        """Test document processing with embedding failure."""
        # Mock embedding failure
        mock_get_embeddings.side_effect = Exception("Embedding API error")
        
        processor = EmbeddingProcessor()
        result = processor.process_document(self.external_data)
        
        # Verify failure handling
        self.assertFalse(result.success)
        self.assertIn("Embedding API error", result.error_message)
        
        # Verify no chunks were created
        chunks = ExternalDataChunk.objects.filter(external_data=self.external_data)
        self.assertEqual(chunks.count(), 0)
    
    def test_chunk_text_splitting(self):
        """Test text splitting into chunks."""
        processor = EmbeddingProcessor()
        
        # Test with long text
        long_text = "This is a test. " * 1000  # 16,000 characters
        chunks = processor._split_text(long_text, chunk_size=1000, overlap=100)
        
        # Verify chunks
        self.assertGreater(len(chunks), 1)
        
        # Verify chunk sizes
        for chunk in chunks[:-1]:  # All but last chunk
            self.assertLessEqual(len(chunk), 1000)
        
        # Verify overlap
        if len(chunks) > 1:
            # Check that consecutive chunks have some overlap
            chunk1_end = chunks[0][-50:]
            chunk2_start = chunks[1][:50]
            # Should have some common text (basic overlap check)
            self.assertTrue(any(word in chunk2_start for word in chunk1_end.split()))
```
