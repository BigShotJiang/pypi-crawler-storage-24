# 🎯 Actions System %%PRIORITY:HIGH%%

## 🎯 Overview

Type-safe action system with automatic error handling, logging, and Material Design styling. Built on Django Unfold's action system with our custom enhancements.

## 🏗️ Architecture

```
@action decorator (error handling, logging, type safety)
    ↓
ActionVariant enum (type-safe variants)
    ↓
unfold.decorators.action (UI rendering)
    ↓
unfold.enums.ActionVariant (actual styling)
```

## 🎨 Action Types

### 1. Basic Actions %%PRIORITY:HIGH%%

Simple bulk actions with automatic error handling.

```python
from django_cfg.modules.django_admin import action, ActionVariant

@action(description="Activate selected items", variant=ActionVariant.SUCCESS)
def activate_items(self, request, queryset):
    """Activate selected items."""
    updated = queryset.update(is_active=True)
    self.message_user(
        request,
        f"Successfully activated {updated} items.",
        messages.SUCCESS
    )

@action(description="Deactivate selected items", variant=ActionVariant.WARNING)
def deactivate_items(self, request, queryset):
    """Deactivate selected items."""
    updated = queryset.update(is_active=False)
    self.message_user(
        request,
        f"Successfully deactivated {updated} items.",
        messages.WARNING
    )
```

### 2. Standalone Action Buttons %%PRIORITY:HIGH%%

Create standalone action buttons (not bulk actions) using `url_path` parameter.

```python
@action(
    description="Update Rates",
    variant=ActionVariant.SUCCESS,
    url_path="update-rates",  # Creates separate button
    icon="sync"
)
def update_rates(self, request):
    """Standalone action - no queryset parameter."""
    from django.contrib import messages
    from django.shortcuts import redirect
    
    # Perform standalone action
    try:
        # Your logic here
        messages.success(request, "Rates update started!")
    except Exception as e:
        messages.error(request, f"Failed: {e}")
    
    return redirect(request.META.get('HTTP_REFERER', '/admin/'))
```

**Key Differences**:
- **`url_path`** creates a separate button (not in bulk actions dropdown)
- **No `queryset` parameter** - works on entire model/system
- **Must return HttpResponse** (usually redirect)
- **Perfect for system-wide operations** like sync, update, export all

### 3. Actions with Error Handling

Actions automatically handle errors and show user-friendly messages.

```python
@action(description="Process payments", variant=ActionVariant.INFO)
def process_payments(self, request, queryset):
    """Process selected payments with error handling."""
    processed = 0
    failed = 0
    
    for payment in queryset:
        try:
            if payment.can_be_processed():
                payment.process()
                processed += 1
            else:
                failed += 1
        except Exception as e:
            # Error is automatically logged by decorator
            failed += 1
    
    if processed > 0:
        self.message_user(
            request,
            f"Successfully processed {processed} payments.",
            messages.SUCCESS
        )
    
    if failed > 0:
        self.message_user(
            request,
            f"Failed to process {failed} payments.",
            messages.ERROR
        )
```

### 3. Actions with Icons

Add Material Design icons to actions.

```python
from django_cfg.modules.django_admin import Icons

@action(
    description="Export to CSV",
    variant=ActionVariant.INFO,
    icon=Icons.DOWNLOAD
)
def export_csv(self, request, queryset):
    """Export selected items to CSV."""
    # Export logic here
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="export.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['ID', 'Name', 'Status'])  # Headers
    
    for item in queryset:
        writer.writerow([item.id, item.name, item.status])
    
    return response

@action(
    description="Send notifications",
    variant=ActionVariant.PRIMARY,
    icon=Icons.NOTIFICATIONS
)
def send_notifications(self, request, queryset):
    """Send notifications to selected users."""
    sent = 0
    for item in queryset:
        if hasattr(item, 'user') and item.user.email:
            # Send notification logic
            sent += 1
    
    self.message_user(
        request,
        f"Sent notifications to {sent} users.",
        messages.SUCCESS
    )
```

### 4. Conditional Actions

Actions that check conditions before executing.

```python
@action(description="Archive old items", variant=ActionVariant.WARNING)
def archive_old_items(self, request, queryset):
    """Archive items older than 30 days."""
    from datetime import timedelta
    from django.utils import timezone
    
    cutoff_date = timezone.now() - timedelta(days=30)
    old_items = queryset.filter(created_at__lt=cutoff_date)
    
    if not old_items.exists():
        self.message_user(
            request,
            "No items older than 30 days found.",
            messages.INFO
        )
        return
    
    archived = old_items.update(is_archived=True)
    self.message_user(
        request,
        f"Archived {archived} old items.",
        messages.SUCCESS
    )
```

## 🎨 ActionVariant Enum %%PRIORITY:HIGH%%

Type-safe action variants that map to Unfold's styling.

```python
from django_cfg.modules.django_admin import ActionVariant

# Available variants (exactly matches unfold.enums.ActionVariant)
ActionVariant.DEFAULT    # Gray/neutral styling
ActionVariant.PRIMARY    # Blue/primary color
ActionVariant.SUCCESS    # Green/success color
ActionVariant.INFO       # Light blue/info color
ActionVariant.WARNING    # Yellow/warning color
ActionVariant.DANGER     # Red/danger color
```

### Variant Usage Guidelines

```python
# SUCCESS: Positive actions (activate, approve, complete)
@action(description="Approve items", variant=ActionVariant.SUCCESS)

# WARNING: Potentially destructive but reversible (deactivate, archive)
@action(description="Archive items", variant=ActionVariant.WARNING)

# DANGER: Destructive actions (delete, cancel)
@action(description="Delete items", variant=ActionVariant.DANGER)

# INFO: Informational actions (export, sync, refresh)
@action(description="Sync data", variant=ActionVariant.INFO)

# PRIMARY: Main actions (process, update, send)
@action(description="Process orders", variant=ActionVariant.PRIMARY)

# DEFAULT: Neutral actions (mark as read, toggle)
@action(description="Mark as read", variant=ActionVariant.DEFAULT)
```

## 🔧 Advanced Action Patterns

### 1. Actions with Permissions

```python
@action(
    description="Admin only action",
    variant=ActionVariant.DANGER,
    permissions=['delete']  # Requires delete permission
)
def admin_only_action(self, request, queryset):
    """Action only available to users with delete permission."""
    if not request.user.has_perm('myapp.delete_mymodel'):
        self.message_user(
            request,
            "You don't have permission to perform this action.",
            messages.ERROR
        )
        return
    
    # Action logic here
```

### 2. Actions with Confirmation

```python
@action(description="Delete permanently", variant=ActionVariant.DANGER)
def delete_permanently(self, request, queryset):
    """Delete items permanently with confirmation."""
    if 'confirm' not in request.POST:
        # Show confirmation page
        context = {
            'title': 'Confirm Deletion',
            'queryset': queryset,
            'action_checkbox_name': helpers.ACTION_CHECKBOX_NAME,
        }
        return render(request, 'admin/confirm_delete.html', context)
    
    # Perform deletion
    deleted = queryset.count()
    queryset.delete()
    
    self.message_user(
        request,
        f"Permanently deleted {deleted} items.",
        messages.SUCCESS
    )
```

### 3. Actions with Progress Tracking

```python
from django.http import JsonResponse
from django.views.decorators.http import require_POST

@action(description="Bulk process items", variant=ActionVariant.INFO)
def bulk_process_items(self, request, queryset):
    """Process items with progress tracking."""
    total = queryset.count()
    processed = 0
    
    for item in queryset:
        try:
            item.process()
            processed += 1
            
            # Update progress (could use cache or database)
            progress = (processed / total) * 100
            
        except Exception as e:
            # Error handling
            continue
    
    self.message_user(
        request,
        f"Processed {processed} out of {total} items.",
        messages.SUCCESS if processed == total else messages.WARNING
    )
```

## 🎨 Real Examples from Payments Admin

### Currency Admin Actions

```python
@action(description="Activate currencies", variant=ActionVariant.SUCCESS)
def activate_currencies(self, request, queryset):
    """Activate selected currencies."""
    updated = queryset.update(is_active=True)
    self.message_user(
        request,
        f"Successfully activated {updated} currencies.",
        messages.SUCCESS
    )

@action(description="Deactivate currencies", variant=ActionVariant.WARNING)
def deactivate_currencies(self, request, queryset):
    """Deactivate selected currencies."""
    updated = queryset.update(is_active=False)
    self.message_user(
        request,
        f"Successfully deactivated {updated} currencies.",
        messages.WARNING
    )

@action(description="Update exchange rates", variant=ActionVariant.INFO)
def update_rates(self, request, queryset):
    """Update exchange rates for selected currencies."""
    updated = 0
    for currency in queryset:
        try:
            # Update rate logic here
            currency.update_exchange_rate()
            updated += 1
        except Exception as e:
            logger.error(f"Failed to update rate for {currency.code}: {e}")
    
    self.message_user(
        request,
        f"Updated exchange rates for {updated} currencies.",
        messages.SUCCESS if updated > 0 else messages.WARNING
    )
```

### Subscription Admin Actions

```python
@action(description="Activate subscriptions", variant=ActionVariant.SUCCESS)
def activate_subscriptions(self, request, queryset):
    """Activate selected subscriptions."""
    activated = 0
    for subscription in queryset:
        if subscription.can_be_activated():
            subscription.activate()
            activated += 1
    
    self.message_user(
        request,
        f"Activated {activated} subscriptions.",
        messages.SUCCESS
    )

@action(description="Cancel subscriptions", variant=ActionVariant.WARNING)
def cancel_subscriptions(self, request, queryset):
    """Cancel selected subscriptions."""
    cancelled = 0
    for subscription in queryset:
        if subscription.can_be_cancelled():
            subscription.cancel()
            cancelled += 1
    
    self.message_user(
        request,
        f"Cancelled {cancelled} subscriptions.",
        messages.WARNING
    )

@action(description="Extend trial period", variant=ActionVariant.INFO)
def extend_trial(self, request, queryset):
    """Extend trial period for selected subscriptions."""
    extended = 0
    for subscription in queryset:
        if subscription.is_trial and subscription.can_extend_trial():
            subscription.extend_trial(days=7)
            extended += 1
    
    self.message_user(
        request,
        f"Extended trial for {extended} subscriptions.",
        messages.INFO
    )
```

## 🔍 Error Handling and Logging

### Automatic Error Handling

The `@action` decorator automatically handles errors:

```python
@action(description="Risky action", variant=ActionVariant.WARNING)
def risky_action(self, request, queryset):
    """Errors are automatically caught and logged."""
    for item in queryset:
        # This might raise an exception
        item.risky_operation()
    
    # If an exception occurs:
    # 1. It's logged with django_cfg.modules.django_logger
    # 2. User sees friendly error message
    # 3. Admin continues to work normally
```

### Manual Error Handling

```python
@action(description="Custom error handling", variant=ActionVariant.INFO)
def custom_error_handling(self, request, queryset):
    """Handle errors manually for custom behavior."""
    success_count = 0
    error_count = 0
    errors = []
    
    for item in queryset:
        try:
            item.complex_operation()
            success_count += 1
        except ValidationError as e:
            error_count += 1
            errors.append(f"{item}: {e}")
        except Exception as e:
            error_count += 1
            errors.append(f"{item}: Unexpected error")
    
    # Show detailed results
    if success_count > 0:
        self.message_user(
            request,
            f"Successfully processed {success_count} items.",
            messages.SUCCESS
        )
    
    if error_count > 0:
        error_details = "; ".join(errors[:5])  # Show first 5 errors
        if len(errors) > 5:
            error_details += f" and {len(errors) - 5} more..."
        
        self.message_user(
            request,
            f"Failed to process {error_count} items: {error_details}",
            messages.ERROR
        )
```

## 🎨 Action Registration

### In Admin Class

```python
class MyModelAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    """Admin with custom actions."""
    
    # Register actions
    actions = [
        'activate_items',
        'deactivate_items',
        'export_csv',
        'send_notifications'
    ]
    
    # Action methods here...
```

### Dynamic Action Registration

```python
def get_actions(self, request):
    """Dynamically register actions based on permissions."""
    actions = super().get_actions(request)
    
    # Only show delete action to superusers
    if not request.user.is_superuser:
        if 'delete_permanently' in actions:
            del actions['delete_permanently']
    
    return actions
```

## 🚀 Standalone Actions (New Approach)

### StandaloneActionsMixin

For easier management of standalone actions, use the new `StandaloneActionsMixin`:

```python
from django_cfg.modules.django_admin import (
    OptimizedModelAdmin,
    DisplayMixin,
    StandaloneActionsMixin,
    standalone_action,
    ActionVariant
)

@admin.register(Currency)
class CurrencyAdmin(OptimizedModelAdmin, DisplayMixin, StandaloneActionsMixin, ModelAdmin):
    # Register standalone actions
    actions_list = ['update_rates', 'sync_providers', 'backup_data']
    
    @standalone_action(
        description="Update Rates",
        variant=ActionVariant.SUCCESS,
        icon="sync",
        background=True,
        success_message="💱 Rates update started! Refresh in 2-3 minutes.",
        error_message="❌ Failed to start update: {error}"
    )
    def update_rates(self, request):
        """Update currency rates in background."""
        call_command('manage_currencies', '--populate')
        call_command('manage_providers', '--all')
        call_command('manage_currencies', '--rates-only')
        return "Update completed"
    
    @standalone_action(
        description="Backup Data",
        variant=ActionVariant.WARNING,
        icon="backup",
        success_message="💾 Backup completed: {result}",
        error_message="❌ Backup failed: {error}"
    )
    def backup_data(self, request):
        """Create data backup."""
        # Your backup logic here
        return "100 currencies backed up"
```

### Standalone Action Features

#### Background Execution
```python
@standalone_action(
    description="Long Running Task",
    background=True,  # Runs in separate thread
    success_message="Task started in background!"
)
def long_task(self, request):
    # This runs in background thread
    time.sleep(30)  # Won't block the UI
    return "Task completed"
```

#### Custom Messages
```python
@standalone_action(
    description="Process Data",
    success_message="✅ Processed {result} items successfully!",
    error_message="❌ Processing failed: {error}"
)
def process_data(self, request):
    processed = do_processing()
    return f"{processed}"  # Used in success_message as {result}
```

#### Auto URL Path Generation
```python
@standalone_action(description="Update Cache")
def update_cache(self, request):  # URL: /admin/app/model/update-cache/
    pass

@standalone_action(description="Sync External", url_path="sync-ext")
def sync_external_data(self, request):  # URL: /admin/app/model/sync-ext/
    pass
```

## 🎨 Admin Templates Integration

### Connecting Custom Templates

To add custom templates with statistics and enhanced UI:

```python
@admin.register(Currency)
class CurrencyAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    # Connect custom template
    change_list_template = 'admin/payments/currency/change_list.html'
    
    def changelist_view(self, request, extra_context=None):
        """Add custom context for template."""
        extra_context = extra_context or {}
        
        # Add statistics
        extra_context.update({
            'currency_stats': {
                'total_currencies': Currency.objects.count(),
                'active_count': Currency.objects.filter(is_active=True).count(),
                'rate_coverage': self.calculate_rate_coverage(),
            }
        })
        
        return super().changelist_view(request, extra_context)
```

### Template Structure

Create templates following Django admin conventions:

```
templates/
└── admin/
    └── {app_label}/
        └── {model_name}/
            ├── change_list.html      # List view template
            ├── change_form.html      # Edit form template
            └── delete_confirmation.html
```

### Example Template

```html
<!-- admin/payments/currency/change_list.html -->
{% extends "admin/change_list.html" %}
{% load static %}

{% block result_list %}
    <!-- Statistics Dashboard -->
    {% if currency_stats %}
        <div class="grid grid-cols-4 gap-4 mb-4">
            <div class="bg-base-50 dark:bg-base-800 p-4 rounded-default">
                <h3 class="text-font-important-light dark:text-font-important-dark">
                    Total Currencies
                </h3>
                <p class="text-2xl font-bold text-primary-600 dark:text-primary-400">
                    {{ currency_stats.total_currencies }}
                </p>
            </div>
            <!-- More stats cards... -->
        </div>
    {% endif %}

    {{ block.super }}
{% endblock %}
```

### Semantic Colors in Templates

Use semantic color classes for proper dark/light theme support:

```html
<!-- ✅ Good: Semantic colors -->
<div class="bg-base-50 dark:bg-base-800 text-font-default-light dark:text-font-default-dark">
    <h4 class="text-font-important-light dark:text-font-important-dark">Title</h4>
    <p class="text-font-subtle-light dark:text-font-subtle-dark">Subtitle</p>
</div>

<!-- ❌ Bad: Hard-coded colors -->
<div class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200">
    <h4 class="text-gray-900 dark:text-gray-100">Title</h4>
</div>
```

## 🏷️ Metadata
**Tags**: `actions, bulk-operations, error-handling, type-safety, unfold, standalone-actions, templates`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Dependencies**: [unfold, django-cfg.modules.django_logger]
