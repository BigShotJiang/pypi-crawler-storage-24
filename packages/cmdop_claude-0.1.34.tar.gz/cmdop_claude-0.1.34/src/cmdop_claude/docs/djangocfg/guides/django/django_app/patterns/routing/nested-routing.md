# 🔗 Nested Routing

## 1. **User-Specific Resources**

### Basic Nested Structure
```python
from rest_framework_nested import routers
from rest_framework.routers import DefaultRouter

# Main router
router = DefaultRouter()
router.register(r'users', UserViewSet, basename='user')

# Nested router for user-specific resources
users_router = routers.NestedSimpleRouter(router, r'users', lookup='user')
users_router.register(r'payments', UserPaymentViewSet, basename='user-payments')
users_router.register(r'balances', UserBalanceViewSet, basename='user-balances')

urlpatterns = [
    path('', include(router.urls)),
    path('', include(users_router.urls)),
]
```

### Generated URL Structure
```
/api/users/                    # All users
/api/users/{user_id}/          # Specific user
/api/users/{user_id}/payments/ # User's payments
/api/users/{user_id}/balances/ # User's balances
```

### ViewSet Implementation
```python
class UserPaymentViewSet(viewsets.ModelViewSet):
    serializer_class = PaymentSerializer
    
    def get_queryset(self):
        """Filter payments by user from URL."""
        user_pk = self.kwargs['user_pk']
        return UniversalPayment.objects.filter(user_id=user_pk)
    
    def perform_create(self, serializer):
        """Set user from URL parameter."""
        user_pk = self.kwargs['user_pk']
        serializer.save(user_id=user_pk)
```

## 2. **Ticket-Message Hierarchy**

### Multi-Level Nesting
```python
# Main router
router = DefaultRouter()
router.register(r'tickets', TicketViewSet, basename='ticket')

# Level 1: Ticket messages
tickets_router = routers.NestedSimpleRouter(router, r'tickets', lookup='ticket')
tickets_router.register(r'messages', TicketMessageViewSet, basename='ticket-messages')

# Level 2: Message attachments
messages_router = routers.NestedSimpleRouter(tickets_router, r'messages', lookup='message')
messages_router.register(r'attachments', MessageAttachmentViewSet, basename='message-attachments')

urlpatterns = [
    path('', include(router.urls)),
    path('', include(tickets_router.urls)),
    path('', include(messages_router.urls)),
]
```

### Generated Multi-Level Structure
```
/api/tickets/                                    # All tickets
/api/tickets/{ticket_id}/                        # Specific ticket
/api/tickets/{ticket_id}/messages/               # Ticket messages
/api/tickets/{ticket_id}/messages/{message_id}/  # Specific message
/api/tickets/{ticket_id}/messages/{message_id}/attachments/  # Message attachments
```

### Multi-Level ViewSet
```python
class MessageAttachmentViewSet(viewsets.ModelViewSet):
    serializer_class = AttachmentSerializer
    
    def get_queryset(self):
        """Filter by ticket and message from URL."""
        ticket_pk = self.kwargs['ticket_pk']
        message_pk = self.kwargs['message_pk']
        
        return Attachment.objects.filter(
            message_id=message_pk,
            message__ticket_id=ticket_pk
        )
    
    def perform_create(self, serializer):
        """Set message from URL parameters."""
        message_pk = self.kwargs['message_pk']
        serializer.save(message_id=message_pk)
```

## 3. **Category-Article Relationship**

### Content Hierarchy
```python
# Main routers
router = DefaultRouter()
router.register(r'categories', CategoryViewSet, basename='category')
router.register(r'articles', ArticleViewSet, basename='article')

# Nested router for category articles
categories_router = routers.NestedSimpleRouter(router, r'categories', lookup='category')
categories_router.register(r'articles', CategoryArticleViewSet, basename='category-articles')

urlpatterns = [
    path('', include(router.urls)),
    path('', include(categories_router.urls)),
]
```

### Dual Access Pattern
```python
class ArticleViewSet(viewsets.ModelViewSet):
    """Global article access."""
    queryset = Article.objects.all()
    serializer_class = ArticleSerializer

class CategoryArticleViewSet(viewsets.ModelViewSet):
    """Category-specific article access."""
    serializer_class = ArticleSerializer
    
    def get_queryset(self):
        """Filter articles by category."""
        category_pk = self.kwargs['category_pk']
        return Article.objects.filter(category_id=category_pk)
```

## 4. **Advanced Nested Patterns**

### Optional Nesting
```python
class PaymentViewSet(viewsets.ModelViewSet):
    """ViewSet that works both nested and standalone."""
    
    def get_queryset(self):
        """Filter by user if nested, otherwise show all."""
        queryset = UniversalPayment.objects.all()
        
        # Check if accessed via nested route
        if 'user_pk' in self.kwargs:
            user_pk = self.kwargs['user_pk']
            queryset = queryset.filter(user_id=user_pk)
        
        return queryset
```

### Conditional Nesting
```python
def get_nested_urls():
    """Generate nested URLs based on configuration."""
    urls = []
    
    # Always include main router
    urls.append(path('', include(router.urls)))
    
    # Add nested routes if enabled
    if getattr(settings, 'ENABLE_USER_NESTING', True):
        urls.append(path('', include(users_router.urls)))
    
    return urls

urlpatterns = get_nested_urls()
```

## 5. **Nested Permissions**

### Hierarchical Permission Checks
```python
class UserPaymentViewSet(viewsets.ModelViewSet):
    
    def get_permissions(self):
        """Check both user and payment permissions."""
        permissions = super().get_permissions()
        
        # Add user-specific permission
        permissions.append(CanAccessUserData())
        
        return permissions

class CanAccessUserData(BasePermission):
    """Permission to access user-specific data."""
    
    def has_permission(self, request, view):
        user_pk = view.kwargs.get('user_pk')
        
        # Users can access their own data
        if request.user.id == int(user_pk):
            return True
        
        # Staff can access any user data
        return request.user.is_staff
```

## 6. **Nested Serializers**

### Context-Aware Serialization
```python
class UserPaymentSerializer(PaymentSerializer):
    """Payment serializer for nested user context."""
    
    class Meta(PaymentSerializer.Meta):
        # Exclude user field since it's implied from URL
        exclude = ['user']
    
    def create(self, validated_data):
        """Set user from view context."""
        user_pk = self.context['view'].kwargs['user_pk']
        validated_data['user_id'] = user_pk
        return super().create(validated_data)
```

### Dynamic Field Inclusion
```python
class NestedPaymentSerializer(PaymentSerializer):
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Remove user field if accessed via user nested route
        if 'user_pk' in self.context.get('view', {}).kwargs:
            self.fields.pop('user', None)
```

## 7. **Nested Filtering**

### Combined Filter Logic
```python
class TicketMessageViewSet(viewsets.ModelViewSet):
    filter_backends = [DjangoFilterBackend, SearchFilter]
    filterset_fields = ['status', 'created_at']
    search_fields = ['content']
    
    def get_queryset(self):
        """Combine nested filtering with regular filters."""
        ticket_pk = self.kwargs['ticket_pk']
        
        # Base queryset filtered by ticket
        queryset = Message.objects.filter(ticket_id=ticket_pk)
        
        # Apply additional filters
        return self.filter_queryset(queryset)
```

## 8. **Nested Actions**

### Custom Actions on Nested Resources
```python
class UserPaymentViewSet(viewsets.ModelViewSet):
    
    @action(detail=False, methods=['get'])
    def summary(self, request, user_pk=None):
        """Get payment summary for user."""
        payments = self.get_queryset()
        
        return Response({
            'total_payments': payments.count(),
            'total_amount': payments.aggregate(Sum('amount_usd'))['amount_usd__sum'],
            'user_id': user_pk
        })
    
    @action(detail=True, methods=['post'])
    def refund(self, request, user_pk=None, pk=None):
        """Refund a user's payment."""
        payment = self.get_object()
        
        # Verify payment belongs to user
        if payment.user_id != int(user_pk):
            return Response({'error': 'Payment not found'}, status=404)
        
        # Process refund
        payment.status = 'refunded'
        payment.save()
        
        return Response({'status': 'refunded'})
```

## 9. **Testing Nested Routes**

### Nested URL Testing
```python
class NestedRoutingTest(APITestCase):
    
    def setUp(self):
        self.user = User.objects.create_user('test@example.com')
        self.payment = UniversalPayment.objects.create(
            user=self.user,
            amount_usd=100.0
        )
    
    def test_nested_payment_list(self):
        """Test nested payment list."""
        url = reverse('user-payments-list', kwargs={'user_pk': self.user.pk})
        response = self.client.get(url)
        
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data['results']), 1)
    
    def test_nested_payment_create(self):
        """Test creating payment via nested route."""
        url = reverse('user-payments-list', kwargs={'user_pk': self.user.pk})
        data = {'amount_usd': 50.0, 'currency': 'USD'}
        
        response = self.client.post(url, data)
        
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.data['user'], self.user.pk)
```

## 10. **Performance Considerations**

### Optimized Nested Queries
```python
class UserPaymentViewSet(viewsets.ModelViewSet):
    
    def get_queryset(self):
        """Optimized queryset for nested access."""
        user_pk = self.kwargs['user_pk']
        
        return UniversalPayment.objects.filter(
            user_id=user_pk
        ).select_related(
            'currency', 'network'
        ).prefetch_related(
            'user__payment_balance'
        )
```

### Cached Nested Data
```python
from django.core.cache import cache

class UserPaymentViewSet(viewsets.ModelViewSet):
    
    @action(detail=False, methods=['get'])
    def stats(self, request, user_pk=None):
        """Cached user payment statistics."""
        cache_key = f'user_payment_stats_{user_pk}'
        stats = cache.get(cache_key)
        
        if stats is None:
            payments = self.get_queryset()
            stats = {
                'count': payments.count(),
                'total': payments.aggregate(Sum('amount_usd'))['amount_usd__sum']
            }
            cache.set(cache_key, stats, 300)  # 5 minutes
        
        return Response(stats)
```

## 11. **Best Practices**

### ✅ **DO**
- Use meaningful lookup names (`user_pk`, `ticket_pk`)
- Validate parent resource exists before accessing children
- Include parent context in child serializers
- Implement proper permission checks for nested access
- Use select_related/prefetch_related for performance
- Test both nested and standalone access patterns

### ❌ **DON'T**
- Create deeply nested routes (max 2-3 levels)
- Ignore parent-child relationship validation
- Expose sensitive data through nested routes
- Forget to handle missing parent resources
- Create circular nested relationships
- Skip performance optimization for nested queries

### 🎯 **Result**
- Intuitive hierarchical API structure
- Clear parent-child relationships
- Efficient data access patterns
- Proper security boundaries
- Maintainable nested resource management
