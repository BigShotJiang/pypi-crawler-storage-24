# 🚀 App-Specific Testing

## 🔧 CRITICAL: App Registration in Test Settings

### ⚠️ MUST-DO: Register New Apps in tests/settings.py
```python
# /path/to/django-cfg/src/tests/settings.py
class TestConfig(DjangoConfig):
    # Project apps for testing
    project_apps: list = [
        "django_cfg.apps.accounts",
        "django_cfg.apps.knowbase", 
        "django_cfg.apps.payments",
        "django_cfg.apps.support",
        "django_cfg.apps.tasks",
        "django_cfg.apps.api",
        "django_cfg.apps.agents",
        "django_cfg.apps.leads",
        "django_cfg.apps.maintenance",
        "django_cfg.apps.newsletter",
        # 👆 ADD YOUR NEW APP HERE!
        # "django_cfg.apps.your_new_app",
    ]
```

**🚨 CRITICAL RULE**: Every new Django-CFG app MUST be added to `project_apps` list in `tests/settings.py`, otherwise:
- Management commands won't be discovered (`Unknown command` errors)
- App models won't be available in tests
- Migrations won't run during test setup
- App-specific URLs won't be registered

## Running Tests for Individual Apps

### Basic App Testing Commands
```bash
# 🚀 RECOMMENDED: Use the standard test runner (KISS principle)
cd /path/to/django-cfg
poetry run python run_tests.py

# Test entire payments app
cd /path/to/django-cfg/src
poetry run python -m django test django_cfg.apps.payments.tests \
    --settings=tests.settings \
    --verbosity=2

# Test specific module in payments
poetry run python -m django test django_cfg.apps.payments.tests.test_services \
    --settings=tests.settings \
    --verbosity=2

# Test specific test class
poetry run python -m django test django_cfg.apps.payments.tests.test_services.PaymentServiceTest \
    --settings=tests.settings \
    --verbosity=2

# 🔧 NON-INTERACTIVE TESTING (prevents hanging)
poetry run python -m django test django_cfg.apps.payments.tests \
    --settings=tests.settings \
    --verbosity=1 \
    --keepdb \
    --parallel auto

# ⚠️ CRITICAL: Always use tests.settings for Django-CFG apps
# Project settings (examples.sample.django.api.settings) have database routing which breaks tests!
```

### App Test Configuration
```python
# src/django_cfg/apps/payments/tests/__init__.py
"""
Test configuration for Payments app.
"""

from django.test import TestCase
from django.contrib.auth import get_user_model

User = get_user_model()

class PaymentsTestCase(TestCase):
    """Base test case for Payments app."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test class."""
        super().setUpClass()
        # App-specific setup
    
    def setUp(self):
        """Set up test data."""
        self.user = User.objects.create_user(
            email="test@example.com",
            username="testuser"
        )
```

### Quick Start for App Testing
```bash
# Run all tests (system-wide)
python manage.py test

# Run specific app tests (recommended for development)
python manage.py test django_cfg.apps.accounts
python manage.py test django_cfg.apps.payments
python manage.py test django_cfg.apps.knowbase

# Run with coverage for specific app
coverage run --source='src/django_cfg/apps/payments' \
    -m django test django_cfg.apps.payments.tests \
    --settings=examples.sample.django.api.settings

coverage report --show-missing

# Run specific test modules
python manage.py test django_cfg.apps.knowbase.tests.test_models
python manage.py test django_cfg.apps.agents.tests.test_agent
```

## 🔐 Authentication & Authorization in Tests

### 🚨 CRITICAL: Admin User Setup for API Tests
```python
# ✅ CORRECT: Admin user for testing admin-only endpoints
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase

User = get_user_model()

class PaymentAPITest(APITestCase):
    """Test Payment API endpoints."""
    
    def setUp(self):
        """Set up test data."""
        # 🔧 CRITICAL: Make user admin for testing admin endpoints
        self.user = User.objects.create_user(
            email="test@example.com",
            username="testuser",
            is_staff=True,      # 👈 REQUIRED for admin endpoints
            is_superuser=True   # 👈 REQUIRED for full access
        )
        
        # 🔧 CRITICAL: Force authenticate for API tests
        self.client.force_authenticate(user=self.user)
    
    def test_unauthenticated_access(self):
        """Test unauthenticated access."""
        # 🔧 Remove authentication for this test
        self.client.force_authenticate(user=None)
        response = self.client.get('/api/payments/')
        self.assertEqual(response.status_code, 401)
```

### 🔧 DRF Versioning Issues in Tests
```python
# tests/settings.py - Disable DRF versioning for tests
REST_FRAMEWORK = {
    'DEFAULT_VERSIONING_CLASS': None,  # 👈 CRITICAL: Disable versioning
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.SessionAuthentication',
        'rest_framework.authentication.TokenAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
    'TEST_REQUEST_DEFAULT_FORMAT': 'json',
}

# In ViewSets - Explicitly disable versioning
class PaymentBaseViewSet(viewsets.ModelViewSet):
    versioning_class = None  # 👈 Disable versioning for payments API
```

### 🔑 API Key Authentication Testing
```python
class APIAccessMiddlewareTest(TestCase):
    """Test API key authentication middleware."""
    
    def setUp(self):
        """Set up test data."""
        self.user = User.objects.create_user(
            email="test@example.com",
            username="testuser"
        )
        
        # Create API key for testing
        self.api_key = APIKey.objects.create(
            user=self.user,
            name="Test API Key",
            is_active=True
        )
    
    def test_api_request_with_valid_key(self):
        """Test API request with valid API key."""
        response = self.client.get(
            '/api/payments/',
            HTTP_X_API_KEY=self.api_key.key  # 👈 Pass API key in header
        )
        self.assertEqual(response.status_code, 200)
    
    def test_api_request_with_invalid_key(self):
        """Test API request with invalid API key."""
        response = self.client.get(
            '/api/payments/',
            HTTP_X_API_KEY='invalid-key'
        )
        self.assertEqual(response.status_code, 401)
```

### 🔒 Database Isolation for Multi-DB Projects
```python
class PaymentTestCase(TestCase):
    """Base test case for Payments app."""
    
    # 🚨 CRITICAL: Specify databases for multi-DB projects
    databases = ['default']  # 👈 REQUIRED: All Django-CFG apps use default DB only
    
    def setUp(self):
        """Set up test data."""
        # All Django-CFG apps use ONLY the default database
        # Never use shop_db, blog_db, or other external databases in tests
        pass
```

### Basic Test Structure
```python
# Real pattern from django-cfg apps
from django.test import TestCase
from django.contrib.auth import get_user_model
from unittest.mock import Mock, patch

User = get_user_model()

class MyAppTestCase(TestCase):
    """Test MyApp functionality."""
    
    # 🔧 CRITICAL: Database isolation
    databases = ['default']
    
    def setUp(self):
        """Set up test data."""
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123',
            is_staff=True,      # For admin access if needed
            is_superuser=True   # For full permissions if needed
        )
    
    def test_functionality(self):
        """Test specific functionality."""
        # Test implementation
        pass
```
