# ⚡ Django Signals in Django-CFG Guide %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Event-driven processing** for model lifecycle management with real examples
- **Cache invalidation** and logging integration patterns from django-cfg apps
- **Business logic separation** - signals for events, managers for business logic
- **Real implementations** from payments, knowbase, support, leads, and accounts apps

## 📋 Table of Contents
1. [Signal Organization](#signal-organization)
2. [Real Signal Examples](#real-signal-examples)
3. [Signal Patterns](#signal-patterns)
4. [Registration Patterns](#registration-patterns)
5. [Best Practices](#best-practices)

## 🔑 Key Concepts at a Glance
- **Event-Driven Processing**: Automatic processing triggered by model changes
- **Cache Management**: Redis cache invalidation on model updates
- **Business Logic Separation**: Signals for events, managers for business logic
- **Intelligent Change Detection**: Avoid unnecessary processing on status updates
- **Graceful Error Handling**: Robust error handling with comprehensive logging

## 🚀 Quick Start

### Basic Signal Registration
```python
# signals/__init__.py - Import all signal modules
from . import document_signals
from . import payment_signals
from . import user_signals

# apps.py - Register signals
def ready(self):
    from . import signals  # Import to register
```

## 📁 Signal Organization

### 1. **Real Signal Structure from Django-CFG**
```
# Real structure from django-cfg apps
payments/
├── signals/
│   ├── __init__.py              # Signal registration
│   ├── payment_signals.py       # Payment-related signals
│   ├── balance_signals.py       # Balance-related signals
│   └── subscription_signals.py  # Subscription signals

knowbase/
├── signals/
│   ├── __init__.py
│   ├── external_data_signals.py # External data processing
│   └── document_signals.py      # Document processing

support/
└── signals.py                   # Simple single-file approach

leads/
└── signals.py                   # Lead notifications

accounts/
└── signals.py                   # User account changes
```

### 2. **Signal Module Pattern (Real Implementation)**
```python
# Real example from support/signals.py
from django.db.models.signals import post_save
from django.dispatch import receiver
from django_cfg.modules.django_telegram import DjangoTelegram
from django_cfg.modules.django_logger import get_logger

from .models import Message, Ticket
from .utils.support_email_service import SupportEmailService

logger = get_logger(__name__)

@receiver(post_save, sender=Message)
def notify_on_message(sender, instance: Message, created: bool, **kwargs):
    """Send notifications when a new message is created."""
    logger.info(f"🔔 Signal triggered: Message {instance.uuid} created={created}")
    
    if not created:
        logger.info("   ⏭️ Not a new message, skipping")
        return

    ticket = instance.ticket
    user = ticket.user
    
    logger.info(f"   📝 Message from: {instance.sender.username}")
    logger.info(f"   🎫 Ticket author: {user.username}")
    logger.info(f"   📧 Is from author: {instance.is_from_author}")

    # If message is from staff and NOT from ticket author, send email to user
    if instance.sender.is_staff and not instance.is_from_author:
        # Send email notification logic here
        pass
```

## 🔍 Real Signal Examples

### 1. **Payment Status Processing (Real Implementation)**
```python
# payments/signals/payment_signals.py - Real implementation
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.core.cache import cache
from django.utils import timezone

from ..models import UniversalPayment
from django_cfg.modules.django_logger import get_logger

logger = get_logger("payment_signals")

@receiver(pre_save, sender=UniversalPayment)
def store_original_status(sender, instance: UniversalPayment, **kwargs):
    """Store original status for change detection."""
    if instance.pk:
        try:
            original = UniversalPayment.objects.get(pk=instance.pk)
            instance._original_status = original.status
        except UniversalPayment.DoesNotExist:
            instance._original_status = None
    else:
        instance._original_status = None

@receiver(post_save, sender=UniversalPayment)
def handle_payment_changes(sender, instance: UniversalPayment, created: bool, **kwargs):
    """
    Handle payment changes - only cache clearing and notifications.
    
    Business logic (balance updates, etc.) handled by managers.
    """
    if created:
        logger.info(f"New payment created", extra={
            'payment_id': str(instance.id),
            'user_id': instance.user.id,
            'amount_usd': instance.amount_usd,
            'provider': instance.provider,
            'status': instance.status
        })
    else:
        # Check for status changes
        if hasattr(instance, '_original_status'):
            old_status = instance._original_status
            new_status = instance.status
            
            if old_status != new_status:
                logger.info(f"Payment status changed", extra={
                    'payment_id': str(instance.id),
                    'user_id': instance.user.id,
                    'old_status': old_status,
                    'new_status': new_status
                })
                
                # Handle completed payment
                if new_status == 'completed' and old_status != 'completed':
                    _handle_payment_completed(instance)
                
                # Handle failed payment
                elif new_status in ['failed', 'expired', 'cancelled']:
                    _handle_payment_failed(instance)
    
    # Clear payment-related caches
    _clear_payment_caches(instance)

def _handle_payment_completed(payment: UniversalPayment):
    """Handle completed payment - delegate to manager for business logic."""
    try:
        # Use manager method which has all the business logic
        from ..models import UserBalance
        
        transaction_record = UserBalance.objects.add_funds_to_user(
            user=payment.user,
            amount=payment.amount_usd,
            transaction_type='payment',
            description=f"Payment completed: {payment.id}",
            payment_id=payment.id
        )
        
        # Mark payment as processed
        payment.completed_at = timezone.now()
        payment.save(update_fields=['completed_at', 'updated_at'])
        
        logger.info(f"Payment completed and processed", extra={
            'payment_id': str(payment.id),
            'user_id': payment.user.id,
            'amount_usd': payment.amount_usd,
            'transaction_id': str(transaction_record.id)
        })
        
    except Exception as e:
        logger.error(f"Failed to process completed payment", extra={
            'payment_id': str(payment.id),
            'user_id': payment.user.id,
            'error': str(e)
        })

def _clear_payment_caches(payment: UniversalPayment):
    """Clear payment-related cache entries."""
    try:
        cache_keys = [
            f"user_payments:{payment.user.id}",
            f"payment_stats:{payment.user.id}",
            f"payment_summary:{payment.user.id}",
            f"provider_stats:{payment.provider}",
        ]
        
        cache.delete_many(cache_keys)
        
        logger.debug(f"Cleared payment caches", extra={
            'payment_id': str(payment.id),
            'user_id': payment.user.id,
            'cache_keys_cleared': len(cache_keys)
        })
        
    except Exception as e:
        logger.warning(f"Failed to clear payment caches: {e}")
```

### 2. **Intelligent Document Processing (Real Implementation)**
```python
# knowbase/signals/external_data_signals.py - Real implementation
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from django.core.cache import cache

from ..models.external_data import ExternalData, ExternalDataChunk, ExternalDataStatus
from django_cfg.modules.django_logger import get_logger

logger = get_logger(__name__)

@receiver(post_save, sender=ExternalData)
def external_data_post_save(sender, instance, created, **kwargs):
    """Handle external data creation and updates with intelligent change detection."""
    
    # Clear user's external data cache on any change
    cache_key = f"user_external_data:{instance.user.id}"
    cache.delete(cache_key)
    
    if created:
        # New external data - process if has content
        logger.info(f"🔗 New external data created: {instance.title}")
        if instance.content and instance.content.strip():
            _start_external_data_processing(instance)
        else:
            logger.debug(f"📝 External data created without content: {instance.title}")
        
    else:
        # External data update - intelligent change detection
        update_fields = kwargs.get('update_fields')
        
        # Define fields that, if updated alone, should NOT trigger reprocessing
        processing_fields = {
            'status', 'processed_at', 'source_updated_at', 'processing_error',
            'total_chunks', 'total_tokens', 'processing_cost'
        }
        
        # If specific fields were updated, check if they are only processing-related
        if update_fields is not None:
            update_fields_set = set(update_fields) if update_fields else set()
            
            if update_fields_set and update_fields_set.issubset(processing_fields):
                # This is just a processing status update - don't reprocess
                logger.debug(f"📊 External data stats updated: {instance.title}")
                return
            
            # Check if content actually changed
            content_fields = {
                'content', 'content_hash', 'source_config', 
                'chunk_size', 'overlap_size', 'embedding_model'
            }
            if content_fields.intersection(update_fields_set):
                logger.info(f"📝 External data content updated: {instance.title}")
                
                # Only reprocess if there's content
                if instance.content and instance.content.strip():
                    # Clear existing chunks and reset processing state
                    _reset_external_data_processing(instance)
                    
                    # Start new processing
                    _start_external_data_processing(instance)

def _reset_external_data_processing(external_data):
    """Reset external data processing state and clear chunks."""
    logger.debug(f"🧹 Clearing chunks for external data: {external_data.title}")
    
    # Delete existing chunks
    external_data.chunks.all().delete()
    
    # Reset processing fields
    external_data.status = ExternalDataStatus.PENDING
    external_data.processed_at = None
    external_data.processing_error = ""
    external_data.total_chunks = 0
    external_data.total_tokens = 0
    external_data.processing_cost = 0.0
    
    # Save with explicit update_fields to avoid triggering this signal again
    external_data.save(update_fields=[
        'status', 'processed_at', 'processing_error',
        'total_chunks', 'total_tokens', 'processing_cost'
    ])

def _start_external_data_processing(external_data):
    """Start async external data processing."""
    try:
        # Lazy import to avoid middleware initialization issues
        from ..tasks.external_data_tasks import process_external_data_async
        process_external_data_async.send(str(external_data.id))
        logger.info(f"🚀 Started async processing for external data: {external_data.id}")
        
    except Exception as e:
        logger.error(f"❌ Failed to start external data processing: {e}")
        
        # Update external data status to failed
        external_data.status = ExternalDataStatus.FAILED
        external_data.processing_error = f"Failed to start processing: {e}"
        external_data.save(update_fields=['status', 'processing_error'])
```

### 3. **Lead Notification System (Real Implementation)**
```python
# leads/signals.py - Real implementation
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone

from .models import Lead
from django_cfg.modules.django_telegram import DjangoTelegram

@receiver(post_save, sender=Lead)
def notify_new_lead(sender, instance, created, **kwargs):
    """Send Telegram notification when a new lead is created."""
    if created:
        try:
            # Prepare notification data
            notification_data = {
                "Name": instance.name,
                "Email": instance.email,
                "Company": instance.company or "Not specified",
                "Contact Type": instance.get_contact_type_display(),
                "Contact Value": instance.contact_value or "Not specified",
                "Subject": instance.subject or "No subject",
                "Site URL": instance.site_url,
                "Status": instance.get_status_display(),
                "Created At": instance.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            }
            
            # Add extra data if available
            if instance.extra:
                notification_data["Extra Data"] = instance.extra
            
            # Add company site if available
            if instance.company_site:
                notification_data["Company Site"] = instance.company_site
            
            # Truncate message if too long
            message_preview = (
                instance.message[:200] + "..." 
                if len(instance.message) > 200 
                else instance.message
            )
            notification_data["Message Preview"] = message_preview
            
            # Send success notification
            DjangoTelegram.send_success(
                f"New lead received from {instance.site_url}",
                notification_data
            )
            
        except Exception as e:
            logger.error(f"Failed to send lead notification: {e}")
```

### 4. **User Account Changes (Real Implementation)**
```python
# accounts/signals.py - Real implementation
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.contrib.auth import get_user_model
from django.utils import timezone

from .utils.auth_email_service import AuthEmailService
from django_cfg.modules.django_telegram import DjangoTelegram
from django_cfg.modules.django_logger import get_logger

User = get_user_model()
logger = get_logger(__name__)

@receiver(post_save, sender=User)
def send_user_registration_email(sender, instance, created, **kwargs):
    """Send welcome email when new user is created - DISABLED for manual control."""
    # Welcome emails should only be sent through views, not automatically via signals
    # This prevents unwanted emails during imports, admin creation, etc.
    pass

@receiver(pre_save, sender=User)
def send_user_status_change_emails(sender, instance, **kwargs):
    """Send emails when user status changes (activation, deactivation)."""
    if instance.pk:
        try:
            old_instance = User.objects.get(pk=instance.pk)
            
            # Check for activation
            if not old_instance.is_active and instance.is_active:
                logger.info(f"User activated: {instance.email}")
                # Send activation email
                
            # Check for deactivation
            elif old_instance.is_active and not instance.is_active:
                logger.info(f"User deactivated: {instance.email}")
                # Send deactivation email
                
        except User.DoesNotExist:
            pass
```

## 🎯 Signal Patterns

### 1. **Cache Invalidation Pattern (Real Implementation)**
```python
# Real pattern from multiple django-cfg apps
@receiver([post_save, post_delete], sender=User)
def invalidate_user_cache(sender, instance, **kwargs):
    """Invalidate user-related caches."""
    
    cache_keys = [
        f"user:{instance.id}",
        f"user_profile:{instance.id}",
        f"user_permissions:{instance.id}",
        f"user_documents:{instance.id}",
    ]
    
    cache.delete_many(cache_keys)
    logger.debug(f"🗑️ Invalidated cache for user {instance.id}")

@receiver([post_save, post_delete], sender=ExternalData)
def invalidate_document_cache(sender, instance, **kwargs):
    """Invalidate document-related caches."""
    
    # User-specific caches
    cache.delete(f"user_external_data:{instance.user.id}")
    
    # Document-specific caches
    cache.delete(f"external_data:{instance.id}")
    cache.delete(f"external_data_chunks:{instance.id}")
    
    logger.debug(f"🗑️ Invalidated cache for external data {instance.id}")
```

### 2. **Audit Logging Pattern (Real Implementation)**
```python
# Real pattern from payments app
@receiver(post_save, sender=APIKey)
def api_key_audit(sender, instance, created, **kwargs):
    """Audit API key operations."""
    
    if created:
        logger.info(f"🔑 API key created for user {instance.user.id}")
    else:
        update_fields = kwargs.get('update_fields')
        if update_fields and 'is_active' in update_fields:
            status = "activated" if instance.is_active else "deactivated"
            logger.info(f"🔑 API key {status} for user {instance.user.id}")

@receiver(post_delete, sender=APIKey)
def api_key_deleted(sender, instance, **kwargs):
    """Audit API key deletion."""
    logger.warning(f"🗑️ API key deleted for user {instance.user.id}")
```

## 📋 Registration Patterns

### 1. **App Registration Pattern (Real Implementation)**
```python
# Real pattern from django-cfg apps
# apps.py
from django.apps import AppConfig

class PaymentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_cfg.apps.payments'
    
    def ready(self):
        """Register signals when Django starts."""
        # Import signals to register them
        from . import signals
        
        # Optional: explicit registration
        from .signals import register_signals
        register_signals()
```

### 2. **Explicit Registration Pattern (Real Implementation)**
```python
# payments/signals/__init__.py - Real implementation
from django_cfg.modules.django_logger import get_logger

logger = get_logger("payment_signals")

def register_signals():
    """Register all payment signals explicitly."""
    try:
        # Import signal modules to register them
        from . import payment_signals
        from . import balance_signals
        from . import subscription_signals
        
        logger.info("Payment signals registered successfully")
        
    except ImportError as e:
        logger.error(f"Failed to register payment signals: {e}")

# Auto-register signals when module is imported
register_signals()
```

### 3. **Conditional Registration Pattern (Real Implementation)**
```python
# Real pattern for conditional signal registration
from django.conf import settings
from django_cfg.modules.django_logger import get_logger

logger = get_logger("app_signals")

def register_signals():
    """Register signals based on configuration."""
    
    # Only register in certain environments
    if not getattr(settings, 'ENABLE_SIGNALS', True):
        logger.info("Signals disabled by configuration")
        return
    
    try:
        from . import payment_signals
        
        # Conditional signal registration
        if getattr(settings, 'ENABLE_CACHE_SIGNALS', True):
            from . import cache_signals
            
        if getattr(settings, 'ENABLE_NOTIFICATION_SIGNALS', True):
            from . import notification_signals
            
        logger.info("App signals registered successfully")
        
    except ImportError as e:
        logger.error(f"Failed to register app signals: {e}")
```

## 🎯 Best Practices

### 1. **Business Logic Separation (Real Implementation)**
```python
# ✅ CORRECT: Signals for events, managers for business logic
@receiver(post_save, sender=Payment)
def payment_completed(sender, instance, **kwargs):
    if instance.status == PaymentStatus.COMPLETED:
        # Use manager for business logic
        balance_manager = UserBalanceManager()
        balance_manager.add_payment_funds(instance.user, instance)
        
        # Signal handles only event notification
        cache.delete(f"user_balance:{instance.user.id}")

# ❌ WRONG: Business logic in signals
@receiver(post_save, sender=Payment)
def payment_completed(sender, instance, **kwargs):
    # Don't put complex business logic here
    if instance.status == PaymentStatus.COMPLETED:
        balance = UserBalance.objects.get(user=instance.user)
        balance.amount += instance.amount_usd
        balance.save()  # Complex logic in signal
```

### 2. **Error Handling (Real Implementation)**
```python
# ✅ CORRECT: Robust error handling
@receiver(post_save, sender=ExternalData)
def external_data_post_save(sender, instance, created, **kwargs):
    try:
        # Clear cache (safe operation)
        cache.delete(f"user_external_data:{instance.user.id}")
        
        if created:
            # Start processing (can fail)
            _start_external_data_processing(instance)
            
    except Exception as e:
        logger.error(f"Error in external data signal: {e}")
        # Don't re-raise to avoid breaking the save operation

# ❌ WRONG: No error handling
@receiver(post_save, sender=ExternalData)
def external_data_post_save(sender, instance, created, **kwargs):
    cache.delete(f"user_external_data:{instance.user.id}")
    _start_external_data_processing(instance)  # Can break save operation
```

### 3. **Performance Considerations (Real Implementation)**
```python
# ✅ CORRECT: Efficient signal processing
@receiver(post_save, sender=ExternalData)
def external_data_post_save(sender, instance, created, **kwargs):
    # Check update_fields to avoid unnecessary processing
    update_fields = kwargs.get('update_fields')
    
    if update_fields and 'status' in update_fields:
        # Only status update, skip heavy processing
        return
    
    # Clear cache (fast operation)
    cache.delete(f"user_external_data:{instance.user.id}")
    
    # Heavy processing in background task
    if created or _content_changed(update_fields):
        process_external_data_async.send(instance.id)

# ❌ WRONG: Heavy processing in signal
@receiver(post_save, sender=ExternalData)
def external_data_post_save(sender, instance, created, **kwargs):
    # Heavy processing blocks the save operation
    process_external_data_synchronously(instance)
```

## 🏷️ Metadata
**Tags**: `signals, events, django, organization, patterns, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Real Examples**: Payments, Knowbase, Support, Leads, Accounts signals from django-cfg
**DEPENDS_ON**: [django-signals, django-cache, django-logging]
**USED_BY**: [all-django-cfg-apps]
