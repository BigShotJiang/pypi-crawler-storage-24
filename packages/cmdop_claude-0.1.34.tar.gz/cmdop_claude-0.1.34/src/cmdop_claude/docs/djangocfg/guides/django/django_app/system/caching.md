# 🚀 Django-CFG Caching System Guide %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Multi-level caching architecture** with Redis/Memory backend support
- **Type-safe cache configuration** via Pydantic models with environment awareness
- **Specialized cache services** for different use cases (API keys, rate limiting, currency)
- **Real examples** from payments app and currency module with graceful fallback

## 📋 Table of Contents
1. [Cache Configuration](#cache-configuration)
2. [Real Cache Implementations](#real-cache-implementations)
3. [Specialized Cache Services](#specialized-cache-services)
4. [Multi-Level Caching](#multi-level-caching)
5. [Performance Optimization](#performance-optimization)

## 🔑 Key Concepts at a Glance
- **Environment-Aware**: Automatic backend selection based on environment
- **Type-Safe Configuration**: Pydantic models for cache settings
- **Multi-Level Caching**: Memory + Redis + TTL persistence
- **Graceful Fallback**: Continues working when cache is unavailable
- **Specialized Caches**: Different cache types for different use cases

## 🚀 Quick Start

### Basic Cache Usage
```python
# Basic Django cache usage
from django.core.cache import cache

# Set value with TTL
cache.set('my_key', 'my_value', timeout=300)

# Get value
value = cache.get('my_key')

# Delete value
cache.delete('my_key')
```

## ⚙️ Cache Configuration

### 1. **Pydantic Cache Configuration (Real Implementation)**
```python
# django_cfg/models/cache.py - Real implementation
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any

class CacheConfig(BaseModel):
    """Type-safe cache backend configuration."""
    
    # Redis configuration
    redis_url: Optional[str] = Field(
        default=None,
        description="Redis connection URL (redis://host:port/db)"
    )
    
    # Timeout settings
    timeout: int = Field(
        default=300,
        description="Default cache timeout in seconds",
        ge=0, le=86400 * 7  # Max 7 days
    )
    
    # Connection settings
    max_connections: int = Field(
        default=50,
        description="Maximum Redis connections in pool",
        ge=1, le=1000
    )
    
    # Cache key settings
    key_prefix: str = Field(
        default="",
        description="Prefix for all cache keys",
        max_length=100
    )
    
    version: int = Field(
        default=1,
        description="Cache key version for invalidation",
        ge=1
    )
    
    # Compression settings
    compress: bool = Field(
        default=False,
        description="Enable cache value compression"
    )
    
    # Backend override for testing
    backend_override: Optional[str] = Field(
        default=None,
        description="Override backend for testing"
    )
```

### 2. **Environment-Aware Backend Selection (Real Implementation)**
```python
def get_backend_type(self, environment: str, debug: bool) -> str:
    """Determine appropriate cache backend based on environment."""
    
    # Allow manual override for testing
    if self.backend_override:
        return self.backend_override
    
    # Environment-based backend selection
    if environment == "testing":
        return "django.core.cache.backends.dummy.DummyCache"
    
    elif environment == "development" or debug:
        # Use Redis if available, otherwise memory cache
        if self.redis_url:
            return "django_redis.cache.RedisCache"
        else:
            return "django.core.cache.backends.locmem.LocMemCache"
    
    elif environment in ("production", "staging"):
        # Production should use Redis
        if self.redis_url:
            return "django_redis.cache.RedisCache"
        else:
            # Fallback to file cache for production without Redis
            return "django.core.cache.backends.filebased.FileBasedCache"
    
    else:
        # Unknown environment - use Redis if available
        if self.redis_url:
            return "django_redis.cache.RedisCache"
        else:
            return "django.core.cache.backends.locmem.LocMemCache"
```

### 3. **Django Settings Generation (Real Implementation)**
```python
def to_django_config(self, environment: str, debug: bool, cache_alias: str = "default") -> Dict[str, Any]:
    """Generate Django cache configuration."""
    
    backend = self.get_backend_type(environment, debug)
    config = {
        "BACKEND": backend,
        "TIMEOUT": self.timeout,
        "VERSION": self.version,
    }
    
    # Redis-specific configuration
    if "RedisCache" in backend:
        config.update({
            "LOCATION": self.redis_url,
            "OPTIONS": {
                "CONNECTION_POOL_KWARGS": {
                    "max_connections": self.max_connections,
                },
                "COMPRESSOR": "django_redis.compressors.zlib.ZlibCompressor" if self.compress else None,
                "IGNORE_EXCEPTIONS": True,  # Graceful fallback
            }
        })
    
    # Add key prefix if specified
    if self.key_prefix:
        config["KEY_PREFIX"] = self.key_prefix
    
    return config
```

## 🔍 Real Cache Implementations

### 1. **Payments App Cache Service (Real Implementation)**
```python
# payments/services/cache/cache_service.py - Real implementation
from abc import ABC, abstractmethod
from typing import Optional, Any, Dict
from django.core.cache import cache
from django_cfg.modules.django_logger import get_logger

logger = get_logger(__name__)

class CacheInterface(ABC):
    """Abstract cache interface for type safety."""
    
    @abstractmethod
    def get(self, key: str) -> Optional[Any]: pass
    
    @abstractmethod
    def set(self, key: str, value: Any, timeout: Optional[int] = None) -> bool: pass
    
    @abstractmethod
    def delete(self, key: str) -> bool: pass

class SimpleCache(CacheInterface):
    """Simple cache with graceful fallback."""
    
    def __init__(self, prefix: str = "payments"):
        self.prefix = prefix
        self.enabled = self._is_cache_enabled()
    
    def _is_cache_enabled(self) -> bool:
        """Check if cache is enabled via PaymentsConfig."""
        try:
            from django_cfg.models.payments import PaymentsConfig
            config = PaymentsConfig.get_current_config()
            return config.enabled
        except Exception:
            return True  # Default to enabled with graceful fallback
    
    def _make_key(self, key: str) -> str:
        """Create prefixed cache key."""
        return f"{self.prefix}:{key}"
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache with error handling."""
        if not self.enabled:
            return None
        
        try:
            cache_key = self._make_key(key)
            return cache.get(cache_key)
        except Exception as e:
            logger.warning(f"Cache get failed for key {key}: {e}")
            return None
    
    def set(self, key: str, value: Any, timeout: Optional[int] = None) -> bool:
        """Set value in cache with error handling."""
        if not self.enabled:
            return False
        
        try:
            cache_key = self._make_key(key)
            cache.set(cache_key, value, timeout)
            return True
        except Exception as e:
            logger.warning(f"Cache set failed for key {key}: {e}")
            return False
    
    def delete(self, key: str) -> bool:
        """Delete value from cache with error handling."""
        if not self.enabled:
            return False
        
        try:
            cache_key = self._make_key(key)
            cache.delete(cache_key)
            return True
        except Exception as e:
            logger.warning(f"Cache delete failed for key {key}: {e}")
            return False
```

### 2. **Currency Module TTL Cache (Real Implementation)**
```python
# modules/django_currency/utils/cache.py - Real implementation
import logging
from typing import Optional
from cachetools import TTLCache

from ..core.models import Rate

logger = logging.getLogger(__name__)

class CacheManager:
    """Simple TTL cache for currency rates."""
    
    def __init__(self, ttl: int = 300, maxsize: int = 1000):
        """
        Initialize cache manager.
        
        Args:
            ttl: Time to live in seconds (default 5 minutes)
            maxsize: Maximum cache size (default 1000 items)
        """
        self.cache = TTLCache(maxsize=maxsize, ttl=ttl)
        self.ttl = ttl
    
    def get_rate(self, base: str, quote: str, source: str) -> Optional[Rate]:
        """Get cached rate."""
        key = self._make_key(base, quote, source)
        
        try:
            cached_rate = self.cache.get(key)
            if cached_rate:
                logger.debug(f"Cache hit for {key}")
                return cached_rate
            else:
                logger.debug(f"Cache miss for {key}")
                return None
        except Exception as e:
            logger.error(f"Cache get error: {e}")
            return None
    
    def set_rate(self, rate: Rate) -> bool:
        """Cache rate."""
        key = self._make_key(rate.base_currency, rate.quote_currency, rate.source)
        
        try:
            self.cache[key] = rate
            logger.debug(f"Cached rate for {key}")
            return True
        except Exception as e:
            logger.error(f"Cache set error: {e}")
            return False
    
    def _make_key(self, base: str, quote: str, source: str) -> str:
        """Make cache key."""
        return f"{source}:{base}:{quote}".upper()
```

## 🎯 Specialized Cache Services

### 1. **API Key Cache (Real Implementation)**
```python
# payments/services/cache/cache_service.py - Real implementation
class ApiKeyCache:
    """Specialized cache for API key operations."""
    
    def __init__(self):
        self.cache = SimpleCache("api_keys")
        self.default_timeout = self._get_cache_timeout('api_key')
    
    def _get_cache_timeout(self, cache_type: str) -> int:
        """Get cache timeout from PaymentsConfig."""
        try:
            from django_cfg.models.payments import PaymentsConfig
            config = PaymentsConfig.get_current_config()
            return config.cache_timeouts.get(cache_type, 300)
        except Exception:
            return 300  # 5 minutes default
    
    def get_api_key_data(self, api_key: str) -> Optional[dict]:
        """Get cached API key data."""
        return self.cache.get(f"key:{api_key}")
    
    def cache_api_key_data(self, api_key: str, data: dict) -> bool:
        """Cache API key data."""
        return self.cache.set(f"key:{api_key}", data, self.default_timeout)
    
    def invalidate_api_key(self, api_key: str) -> bool:
        """Invalidate cached API key."""
        return self.cache.delete(f"key:{api_key}")
```

### 2. **Rate Limiting Cache (Real Implementation)**
```python
# payments/services/cache/cache_service.py - Real implementation
class RateLimitCache:
    """Specialized cache for rate limiting."""
    
    def __init__(self):
        self.cache = SimpleCache("rate_limit")
    
    def get_usage_count(self, user_id: int, endpoint_group: str, window: str = "hour") -> int:
        """Get current usage count for rate limiting."""
        key = f"usage:{user_id}:{endpoint_group}:{window}"
        count = self.cache.get(key)
        return count if count is not None else 0
    
    def increment_usage(self, user_id: int, endpoint_group: str, window: str = "hour", ttl: Optional[int] = None) -> int:
        """Increment usage count and return new count."""
        key = f"usage:{user_id}:{endpoint_group}:{window}"
        
        # Get current count
        current = self.get_usage_count(user_id, endpoint_group, window)
        new_count = current + 1
        
        # Get TTL from config or use defaults
        if ttl is None:
            try:
                from django_cfg.models.payments import PaymentsConfig
                config = PaymentsConfig.get_current_config()
                ttl = config.cache_timeouts.get('rate_limit', 3600)
            except Exception:
                ttl = 3600 if window == "hour" else 86400  # 1 hour or 1 day
        
        # Set new count with TTL
        self.cache.set(key, new_count, ttl)
        return new_count
    
    def reset_usage(self, user_id: int, endpoint_group: str, window: str = "hour") -> bool:
        """Reset usage count."""
        key = f"usage:{user_id}:{endpoint_group}:{window}"
        return self.cache.delete(key)
```

### 3. **Centralized Cache Service (Real Implementation)**
```python
# payments/services/cache/cache_service.py - Real implementation
class CacheService:
    """
    Main cache service providing access to specialized caches.
    
    Provides centralized access to different cache types.
    """
    
    def __init__(self):
        """Initialize cache service with specialized caches."""
        self.simple_cache = SimpleCache()
        self.api_key_cache = ApiKeyCache()
        self.rate_limit_cache = RateLimitCache()
    
    def health_check(self) -> Dict[str, Any]:
        """Check cache health."""
        try:
            test_key = "health_check"
            test_value = "ok"
            
            # Test set/get/delete
            self.simple_cache.set(test_key, test_value, 10)
            retrieved = self.simple_cache.get(test_key)
            self.simple_cache.delete(test_key)
            
            is_healthy = retrieved == test_value
            
            return {
                'healthy': is_healthy,
                'backend': cache.__class__.__name__,
                'simple_cache': True,
                'api_key_cache': True,
                'rate_limit_cache': True
            }
        except Exception as e:
            logger.error(f"Cache health check failed: {e}")
            return {
                'healthy': False,
                'error': str(e),
                'backend': cache.__class__.__name__
            }

# Global cache service instance
_cache_service = None

def get_cache_service() -> CacheService:
    """Get global cache service instance."""
    global _cache_service
    if _cache_service is None:
        _cache_service = CacheService()
    return _cache_service
```

## 🏗️ Multi-Level Caching

### 1. **Currency Converter Multi-Level Cache (Real Implementation)**
```python
# modules/django_currency/core/converter.py - Real implementation
class CurrencyConverter:
    """Main currency converter with provider routing."""
    
    def __init__(self, cache_ttl: int = 300):
        """
        Initialize converter.
        
        Args:
            cache_ttl: Cache TTL in seconds
        """
        self.yahoo = YahooFinanceClient(cache_ttl=cache_ttl)
        self.coinpaprika = CoinPaprikaClient(cache_ttl=cache_ttl)
        self.cache = CacheManager(ttl=cache_ttl)
    
    def convert(self, amount: float, from_currency: str, to_currency: str) -> ConversionResult:
        """Convert amount with multi-level caching."""
        try:
            # Check local cache first
            rate = self.cache.get_rate(from_currency, to_currency, 'cached')
            
            if not rate:
                # Fetch from providers (they have their own caches)
                rate = self._get_rate_from_providers(from_currency, to_currency)
                
                if rate:
                    # Cache the rate locally
                    self.cache.set_rate(rate)
            
            if not rate:
                raise ConversionError(f"Could not get rate for {from_currency}/{to_currency}")
            
            # Calculate conversion
            converted_amount = amount * rate.rate
            
            return ConversionResult(
                amount=amount,
                from_currency=from_currency,
                to_currency=to_currency,
                converted_amount=converted_amount,
                rate=rate
            )
            
        except Exception as e:
            logger.error(f"Conversion failed: {e}")
            raise ConversionError(f"Conversion failed: {e}")
```

### 2. **Database Loader with Multi-Cache (Real Implementation)**
```python
# modules/django_currency/database/database_loader.py - Real implementation
from cachetools import TTLCache

class CurrencyDatabaseLoader:
    """Database loader with multiple cache layers."""
    
    def __init__(self, config: DatabaseLoaderConfig = None):
        """Initialize the database loader."""
        self.config = config or DatabaseLoaderConfig()
        
        # Initialize clients with their own caches
        self.yahoo = YahooFinanceClient(cache_ttl=self.config.cache_ttl_hours * 3600)
        self.coinpaprika = CoinPaprikaClient(cache_ttl=self.config.cache_ttl_hours * 3600)
        
        # Local caches for processed data
        cache_ttl = self.config.cache_ttl_hours * 3600
        self.crypto_cache = TTLCache(maxsize=1000, ttl=cache_ttl)
        self.fiat_cache = TTLCache(maxsize=100, ttl=cache_ttl)
        
        logger.info(f"Initialized CurrencyDatabaseLoader with config: {self.config}")
    
    def get_crypto_currency_list(self) -> List[CoinPaprikaCurrencyInfo]:
        """Get crypto currencies with caching."""
        # Check local cache first
        cached_cryptos = self.crypto_cache.get('crypto_list')
        if cached_cryptos:
            logger.debug("Using cached crypto currency list")
            return cached_cryptos
        
        # Fetch from API (which has its own cache)
        cryptos = self.coinpaprika.get_currency_list()
        
        # Filter and process
        filtered_cryptos = self._filter_crypto_currencies(cryptos)
        
        # Cache processed results
        self.crypto_cache['crypto_list'] = filtered_cryptos
        logger.info(f"Cached {len(filtered_cryptos)} crypto currencies")
        
        return filtered_cryptos
```

## 🚀 Performance Optimization

### 1. **Cache Key Strategies (Real Implementation)**
```python
# Effective cache key patterns from real implementations
class CacheKeyGenerator:
    """Generate consistent cache keys."""
    
    @staticmethod
    def user_data_key(user_id: int, data_type: str) -> str:
        """Generate user-specific data key."""
        return f"user:{user_id}:{data_type}"
    
    @staticmethod
    def api_key_validation_key(api_key_hash: str) -> str:
        """Generate API key validation cache key."""
        return f"api_key:{api_key_hash}"
    
    @staticmethod
    def rate_limit_key(user_id: int, endpoint: str, window: str) -> str:
        """Generate rate limit cache key."""
        return f"rate_limit:{user_id}:{endpoint}:{window}"
    
    @staticmethod
    def currency_rate_key(base: str, quote: str, source: str) -> str:
        """Generate currency rate cache key."""
        return f"rate:{source}:{base}:{quote}".upper()
```

### 2. **Cache Warming Strategies (Real Pattern)**
```python
# Cache warming for frequently accessed data
class CacheWarmer:
    """Warm cache with frequently accessed data."""
    
    def __init__(self, cache_service: CacheService):
        self.cache_service = cache_service
    
    def warm_api_keys(self):
        """Pre-load active API keys."""
        from ..models import APIKey
        
        active_keys = APIKey.objects.filter(is_active=True)
        for api_key in active_keys:
            cache_key = f"api_key:{api_key.key_hash}"
            self.cache_service.api_key_cache.cache_api_key_data(
                api_key.key, 
                {
                    'user_id': api_key.user.id,
                    'subscription_id': api_key.subscription.id if api_key.subscription else None,
                    'is_active': api_key.is_active,
                }, 
                timeout=300
            )
    
    def warm_currency_rates(self):
        """Pre-load popular currency rates."""
        popular_pairs = [
            ('USD', 'EUR'), ('USD', 'GBP'), ('USD', 'JPY'),
            ('EUR', 'GBP'), ('BTC', 'USD'), ('ETH', 'USD')
        ]
        
        from django_cfg.modules.django_currency import CurrencyConverter
        converter = CurrencyConverter()
        
        for base, quote in popular_pairs:
            try:
                # This will cache the rate
                converter.convert(1.0, base, quote)
                logger.debug(f"Warmed cache for {base}/{quote}")
            except Exception as e:
                logger.warning(f"Failed to warm cache for {base}/{quote}: {e}")
```

### 3. **Cache Invalidation Patterns (Real Implementation)**
```python
# Structured cache invalidation
class CacheInvalidator:
    """Handle cache invalidation patterns."""
    
    @staticmethod
    def invalidate_user_data(user_id: int):
        """Invalidate all user-related cache."""
        cache_service = get_cache_service()
        
        # Invalidate user-specific caches
        patterns = [
            f"user:{user_id}:*",
            f"api_key:user:{user_id}:*",
            f"rate_limit:{user_id}:*"
        ]
        
        # For simple cache, we need to track keys or use pattern deletion
        # This is a simplified version - real implementation would use Redis pattern deletion
        for pattern in patterns:
            try:
                cache.delete_pattern(pattern)
            except AttributeError:
                # Fallback for non-Redis backends
                logger.warning(f"Pattern deletion not supported for pattern: {pattern}")
    
    @staticmethod
    def invalidate_currency_rates(base: str = None):
        """Invalidate currency rate cache."""
        if base:
            cache.delete_pattern(f"rate:*:{base}:*")
        else:
            cache.delete_pattern("rate:*")
    
    @staticmethod
    def invalidate_api_key(api_key: str):
        """Invalidate specific API key cache."""
        cache_service = get_cache_service()
        cache_service.api_key_cache.invalidate_api_key(api_key)
```

## 🎯 Best Practices

### 1. **Cache Configuration**
```python
# ✅ CORRECT: Environment-aware configuration
class ProductionConfig(DjangoConfig):
    cache_default: CacheConfig = CacheConfig(
        redis_url=os.getenv("REDIS_URL"),
        timeout=300,
        max_connections=50,
        key_prefix="prod",
        compress=True  # Enable compression for production
    )

# ❌ WRONG: Hardcoded configuration
CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': 'redis://localhost:6379/0',  # Hardcoded
    }
}
```

### 2. **Error Handling**
```python
# ✅ CORRECT: Graceful fallback
def get_cached_data(key: str) -> Optional[Any]:
    try:
        return cache.get(key)
    except Exception as e:
        logger.warning(f"Cache get failed: {e}")
        return None  # Graceful fallback

# ❌ WRONG: No error handling
def get_cached_data(key: str) -> Any:
    return cache.get(key)  # Can raise exceptions
```

### 3. **Cache Usage Patterns**
```python
# ✅ CORRECT: Structured cache usage
class DataService:
    def __init__(self):
        self.cache_service = get_cache_service()
    
    def get_user_data(self, user_id: int) -> Dict[str, Any]:
        # Check cache first
        cache_key = f"user_data:{user_id}"
        cached_data = self.cache_service.simple_cache.get(cache_key)
        
        if cached_data:
            return cached_data
        
        # Fetch from database
        data = self._fetch_user_data_from_db(user_id)
        
        # Cache for 5 minutes
        self.cache_service.simple_cache.set(cache_key, data, 300)
        
        return data

# ❌ WRONG: Direct cache usage without error handling
def get_user_data(user_id: int) -> Dict[str, Any]:
    cache_key = f"user_data:{user_id}"
    cached_data = cache.get(cache_key)  # No error handling
    
    if cached_data:
        return cached_data
    
    data = fetch_from_db(user_id)
    cache.set(cache_key, data, 300)  # No error handling
    
    return data
```

## 🏷️ Metadata
**Tags**: `caching, redis, performance, configuration, ttl, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Real Examples**: Payments cache service, Currency TTL cache from django-cfg
**DEPENDS_ON**: [django-redis, cachetools, pydantic]
**USED_BY**: [payments, knowbase, currency, llm]
