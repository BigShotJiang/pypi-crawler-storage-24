# 🎨 Semantic Colors Guide for Django-CFG Admin %%PRIORITY:HIGH%%

## 🎯 Overview

Guide for using semantic colors in Django-CFG admin system to ensure proper dark/light theme support and consistency with Unfold design principles.

## 🚨 Problem with Non-Semantic Colors

**❌ Current Issues:**
```css
/* Non-semantic colors that break in dark mode */
.text-gray-500     /* Fixed gray - doesn't adapt to theme */
.bg-gray-100       /* Fixed background - poor contrast in dark mode */
.text-gray-800     /* Hard to read in dark theme */
```

**✅ Semantic Solution:**
```css
/* Semantic colors that adapt to theme */
.text-font-subtle-light dark:text-font-subtle-dark
.bg-base-100 dark:bg-base-800
.text-font-default-light dark:text-font-default-dark
```

## 🎨 Semantic Color System

### Base Colors (Backgrounds)
```css
/* Light backgrounds */
.bg-base-50    /* Lightest background */
.bg-base-100   /* Light card background */
.bg-base-200   /* Hover background */
.bg-base-300   /* Border color */

/* Dark backgrounds */
.bg-base-700   /* Dark card background */
.bg-base-800   /* Sidebar background */
.bg-base-900   /* Main dark background */
.bg-base-950   /* Darkest background */
```

### Font Colors (Text)
```css
/* Semantic text colors */
.text-font-subtle-light dark:text-font-subtle-dark         /* Subtle text */
.text-font-default-light dark:text-font-default-dark       /* Default text */
.text-font-important-light dark:text-font-important-dark   /* Important text */
```

### Status Colors
```css
/* Status colors (already semantic) */
.text-green-600 dark:text-green-400    /* Success */
.text-red-600 dark:text-red-400        /* Error */
.text-yellow-600 dark:text-yellow-400  /* Warning */
.text-blue-600 dark:text-blue-400      /* Info */
```

## 🔧 Migration Patterns

### Pattern 1: Text Colors

**❌ Before:**
```python
format_html('<span class="text-gray-500">—</span>')
format_html('<span class="text-gray-600">No data</span>')
format_html('<span class="text-gray-800">Value</span>')
```

**✅ After:**
```python
format_html('<span class="text-font-subtle-light dark:text-font-subtle-dark">—</span>')
format_html('<span class="text-font-default-light dark:text-font-default-dark">No data</span>')
format_html('<span class="text-font-important-light dark:text-font-important-dark">Value</span>')
```

### Pattern 2: Background Colors

**❌ Before:**
```python
format_html('<div class="bg-gray-100 text-gray-800">Content</div>')
```

**✅ After:**
```python
format_html('<div class="bg-base-100 dark:bg-base-800 text-font-default-light dark:text-font-default-dark">Content</div>')
```

### Pattern 3: Badge Colors

**❌ Before:**
```python
'secondary': 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
```

**✅ After:**
```python
'secondary': 'bg-base-100 text-font-default-light dark:bg-base-800 dark:text-font-default-dark'
```

## 🎯 Specific Fixes for Django-CFG

### 1. Badge Utilities (`badges.py`)

**Current Issues:**
```python
# Line 40
BadgeVariant.SECONDARY: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'

# Line 49
return format_html('<span class="text-gray-500">—</span>')
```

**Fixed Version:**
```python
# Semantic badge variant
BadgeVariant.SECONDARY: 'bg-base-100 text-font-default-light dark:bg-base-800 dark:text-font-default-dark'

# Semantic empty value
return format_html('<span class="text-font-subtle-light dark:text-font-subtle-dark">—</span>')
```

### 2. Display Utilities (`displays.py`)

**Current Issues:**
```python
# Multiple lines with non-semantic colors
format_html('<span class="text-gray-500">No user</span>')
format_html('{}<br><span class="text-xs text-gray-500">{}</span>', html, escape(email))
color_class = "text-gray-600 dark:text-gray-400"
'secondary': 'text-gray-500'
```

**Fixed Version:**
```python
# Semantic user display
format_html('<span class="text-font-subtle-light dark:text-font-subtle-dark">No user</span>')

# Semantic email display
format_html('{}<br><span class="text-xs text-font-subtle-light dark:text-font-subtle-dark">{}</span>', html, escape(email))

# Semantic color class
color_class = "text-font-default-light dark:text-font-default-dark"

# Semantic secondary color
'secondary': 'text-font-subtle-light dark:text-font-subtle-dark'
```

## 🎨 Complete Color Mapping

### Text Color Mapping
```python
# Old → New mapping for migration
COLOR_MIGRATION_MAP = {
    'text-gray-500': 'text-font-subtle-light dark:text-font-subtle-dark',
    'text-gray-600': 'text-font-default-light dark:text-font-default-dark', 
    'text-gray-700': 'text-font-default-light dark:text-font-default-dark',
    'text-gray-800': 'text-font-important-light dark:text-font-important-dark',
    'text-gray-900': 'text-font-important-light dark:text-font-important-dark',
    
    # Dark mode equivalents
    'dark:text-gray-200': 'dark:text-font-important-dark',
    'dark:text-gray-300': 'dark:text-font-default-dark',
    'dark:text-gray-400': 'dark:text-font-subtle-dark',
}
```

### Background Color Mapping
```python
BACKGROUND_MIGRATION_MAP = {
    'bg-gray-50': 'bg-base-50',
    'bg-gray-100': 'bg-base-100 dark:bg-base-800',
    'bg-gray-200': 'bg-base-200 dark:bg-base-700',
    'bg-gray-800': 'bg-base-800',
    'bg-gray-900': 'bg-base-900',
    
    # Dark mode equivalents
    'dark:bg-gray-800': 'dark:bg-base-800',
    'dark:bg-gray-900': 'dark:bg-base-900',
}
```

## 🔧 Implementation Guide

### Step 1: Update Badge Variants

```python
# In badges.py
BADGE_VARIANTS = {
    BadgeVariant.PRIMARY: 'bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200',
    BadgeVariant.SUCCESS: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
    BadgeVariant.WARNING: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
    BadgeVariant.DANGER: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
    BadgeVariant.INFO: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    BadgeVariant.SECONDARY: 'bg-base-100 text-font-default-light dark:bg-base-800 dark:text-font-default-dark',
}
```

### Step 2: Update Display Functions

```python
# Replace all instances of non-semantic colors
def safe_display_text(text: str, variant: str = "default") -> str:
    """Display text with semantic colors."""
    color_classes = {
        "subtle": "text-font-subtle-light dark:text-font-subtle-dark",
        "default": "text-font-default-light dark:text-font-default-dark", 
        "important": "text-font-important-light dark:text-font-important-dark",
    }
    
    color_class = color_classes.get(variant, color_classes["default"])
    return format_html('<span class="{}">{}</span>', color_class, text)
```

### Step 3: Update Empty Value Displays

```python
# Consistent empty value display
EMPTY_VALUE_HTML = '<span class="text-font-subtle-light dark:text-font-subtle-dark">—</span>'

def display_empty_value():
    return format_html(EMPTY_VALUE_HTML)
```

## 🎨 CSS Variables Setup

### Required CSS Variables
```css
:root {
  /* Base colors */
  --color-base-50: 249, 250, 251;
  --color-base-100: 243, 244, 246;
  --color-base-200: 229, 231, 235;
  --color-base-300: 209, 213, 219;
  --color-base-700: 55, 65, 81;
  --color-base-800: 31, 41, 55;
  --color-base-900: 17, 24, 39;
  --color-base-950: 3, 7, 18;

  /* Font colors */
  --color-font-subtle-light: 107, 114, 128;    /* gray-500 */
  --color-font-subtle-dark: 156, 163, 175;     /* gray-400 */
  --color-font-default-light: 75, 85, 99;      /* gray-600 */
  --color-font-default-dark: 209, 213, 219;    /* gray-300 */
  --color-font-important-light: 17, 24, 39;    /* gray-900 */
  --color-font-important-dark: 243, 244, 246;  /* gray-100 */
}
```

### Tailwind Configuration
```javascript
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        base: {
          50: 'rgb(var(--color-base-50))',
          100: 'rgb(var(--color-base-100))',
          200: 'rgb(var(--color-base-200))',
          300: 'rgb(var(--color-base-300))',
          700: 'rgb(var(--color-base-700))',
          800: 'rgb(var(--color-base-800))',
          900: 'rgb(var(--color-base-900))',
          950: 'rgb(var(--color-base-950))',
        },
        font: {
          'subtle-light': 'rgb(var(--color-font-subtle-light))',
          'subtle-dark': 'rgb(var(--color-font-subtle-dark))',
          'default-light': 'rgb(var(--color-font-default-light))',
          'default-dark': 'rgb(var(--color-font-default-dark))',
          'important-light': 'rgb(var(--color-font-important-light))',
          'important-dark': 'rgb(var(--color-font-important-dark))',
        }
      }
    }
  }
}
```

## 🧪 Testing Dark Mode

### Manual Testing Checklist
- [ ] Switch to dark mode in admin
- [ ] Check all badges render correctly
- [ ] Verify text is readable in both themes
- [ ] Test empty value displays
- [ ] Check status indicators
- [ ] Verify hover states work

### Automated Testing
```python
def test_semantic_colors():
    """Test that semantic colors are used."""
    from django_cfg.modules.django_admin.utils.badges import StatusBadge
    
    # Test badge uses semantic colors
    badge_html = StatusBadge.create("Test", "secondary")
    assert "text-font-default-light" in badge_html
    assert "dark:text-font-default-dark" in badge_html
    assert "text-gray-" not in badge_html  # No non-semantic colors
```

## 🎯 Benefits

1. **Theme Consistency** - Colors automatically adapt to light/dark themes
2. **Maintainability** - Change theme colors in one place (CSS variables)
3. **Accessibility** - Proper contrast ratios maintained across themes
4. **Future-Proof** - Easy to add new themes or adjust existing ones
5. **Unfold Compliance** - Follows Unfold's design system principles

## 🏷️ Next Steps

1. **Fix Current Issues** - Update `badges.py` and `displays.py`
2. **Add CSS Variables** - Ensure all semantic colors are defined
3. **Test Thoroughly** - Verify both light and dark modes
4. **Document Changes** - Update admin documentation
5. **Create Migration Script** - Automate color migration for future updates

## 🏷️ Metadata
**Tags**: `semantic-colors, dark-mode, unfold, tailwind, accessibility`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Dependencies**: [tailwind-css, unfold]
