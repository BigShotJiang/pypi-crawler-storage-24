# 📢 Universal Notifications System %%PRIORITY:HIGH%%

## 🎯 Overview

Comprehensive guide for implementing universal notifications in Django-CFG applications using built-in modules (email, telegram, SMS) with the `AccountNotifications` system.

## 🏗️ Architecture

```
AccountNotifications (Central Hub)
    ↓
├── DjangoEmailService (Email)
├── DjangoTelegram (Telegram)
└── SimpleTwilioService (SMS)
```

## 📦 Core Components

### AccountNotifications Class

**Location**: `django_cfg.apps.accounts.utils.notifications`

Central notification system that handles all user account events with multi-channel support.

```python
from django_cfg.apps.accounts.utils.notifications import AccountNotifications

# Send welcome notification
AccountNotifications.send_welcome_email(
    user=user,
    send_email=True,
    send_telegram=True
)

# Send security alert
AccountNotifications.send_security_alert(
    user=user,
    alert_type="Suspicious Login",
    details="Login from unknown device",
    send_email=True,
    send_telegram=True
)
```

## 🎨 Notification Types

### 1. User Lifecycle Notifications %%PRIORITY:HIGH%%

#### Welcome Notifications
```python
# New user registration
AccountNotifications.send_welcome_email(
    user=user,
    send_email=True,      # Email to user
    send_telegram=True    # System notification to admins
)
```

**Features**:
- Welcome email with dashboard link
- Admin notification with user details
- Configurable channels

#### Account Status Changes
```python
# Account activation
AccountNotifications.send_account_status_change(
    user=user,
    status_type="activated",
    reason=None,
    send_email=True,
    send_telegram=True
)

# Account deactivation
AccountNotifications.send_account_status_change(
    user=user,
    status_type="deactivated", 
    reason="Policy violation",
    send_email=True,
    send_telegram=True
)
```

### 2. Authentication Notifications %%PRIORITY:HIGH%%

#### OTP Notifications
```python
# Email OTP
AccountNotifications.send_otp_notification(
    user=user,
    otp_code="123456",
    is_new_user=False,
    source_url="https://app.com/login",
    channel='email',
    send_email=True,
    send_telegram=True  # System notification (without OTP for security)
)

# SMS OTP
AccountNotifications.send_phone_otp_notification(
    user=user,
    otp_code="123456",
    phone_number="+1234567890",
    is_new_user=False,
    source_url="https://app.com/login"
)
```

**Security Features**:
- OTP codes sent to user via SMS/Email
- System notifications to admins (without OTP codes)
- Automatic expiration handling
- Source URL tracking

#### Login Notifications
```python
# Login monitoring
AccountNotifications.send_login_notification(
    user=user,
    ip_address="192.168.1.1",
    send_email=False,     # Usually disabled for UX
    send_telegram=True    # Admin monitoring
)

# OTP verification success
AccountNotifications.send_otp_verification_success(
    user=user,
    source_url="https://app.com/dashboard",
    send_telegram=True
)
```

### 3. Security Notifications %%PRIORITY:HIGH%%

#### Security Alerts
```python
# General security alert
AccountNotifications.send_security_alert(
    user=user,
    alert_type="Password Changed",
    details="Password was changed from IP 192.168.1.1",
    send_email=True,
    send_telegram=True
)

# Suspicious activity
AccountNotifications.send_suspicious_activity(
    user=user,
    activity_type="Multiple Failed Logins",
    details={
        "description": "5 failed login attempts in 10 minutes",
        "ip_address": "192.168.1.1",
        "user_agent": "Mozilla/5.0...",
        "timestamp": "2025-01-28 10:30:00 UTC"
    },
    send_email=True,
    send_telegram=True
)

# Failed OTP attempts
AccountNotifications.send_failed_otp_attempt(
    identifier="user@example.com",
    channel='email',
    ip_address="192.168.1.1",
    reason="Invalid OTP code",
    send_telegram=True
)
```

### 4. Profile Update Notifications

```python
# Profile changes
AccountNotifications.send_profile_update_notification(
    user=user,
    changes=["email", "phone_number"],
    send_email=True,
    send_telegram=True
)
```

### 5. Admin Notifications

```python
# Admin user creation
AccountNotifications.send_admin_user_created(
    user=new_user,
    created_by=admin_user,
    send_telegram=True
)

# Bulk operations
AccountNotifications.send_bulk_operation_notification(
    operation_type="User Activation",
    count=50,
    details={"filter": "inactive_users", "admin": "admin@example.com"},
    send_telegram=True
)
```

## 🔧 Implementation Patterns

### Pattern 1: User Registration Flow

```python
# In your registration view/service
def register_user(email, username, password):
    # Create user
    user = User.objects.create_user(
        email=email,
        username=username,
        password=password,
        is_active=False  # Require activation
    )
    
    # Send welcome notifications
    AccountNotifications.send_welcome_email(
        user=user,
        send_email=True,
        send_telegram=True
    )
    
    # Generate and send OTP for activation
    from apps.accounts.services.otp_service import OTPService
    otp_code = OTPService.generate_otp(user.email)
    
    AccountNotifications.send_otp_notification(
        user=user,
        otp_code=otp_code,
        is_new_user=True,
        channel='email'
    )
    
    return user
```

### Pattern 2: Security Event Handling

```python
# In your authentication middleware/service
def handle_suspicious_login(user, request):
    # Detect suspicious activity
    if is_suspicious_activity(user, request):
        AccountNotifications.send_suspicious_activity(
            user=user,
            activity_type="Suspicious Login Attempt",
            details={
                "description": "Login from new device/location",
                "ip_address": get_client_ip(request),
                "user_agent": request.META.get('HTTP_USER_AGENT', ''),
                "timestamp": timezone.now().strftime("%Y-%m-%d %H:%M:%S UTC")
            }
        )
        
        # Block login and require additional verification
        return False
    
    return True
```

### Pattern 3: Admin Action Notifications

```python
# In your admin actions
@action(description="Activate users", variant=ActionVariant.SUCCESS)
def activate_users(self, request, queryset):
    count = queryset.count()
    updated = queryset.update(is_active=True)
    
    # Send individual notifications
    for user in queryset:
        AccountNotifications.send_account_status_change(
            user=user,
            status_type="activated",
            send_email=True,
            send_telegram=False  # Avoid spam
        )
    
    # Send bulk notification to admins
    AccountNotifications.send_bulk_operation_notification(
        operation_type="User Activation",
        count=updated,
        details={
            "admin": request.user.email,
            "timestamp": timezone.now().strftime("%Y-%m-%d %H:%M:%S UTC")
        }
    )
    
    self.message_user(request, f"Activated {updated} users.")
```

## 📧 Email Templates

### Template Structure
```
emails/
├── base_email.html          # Base template
├── welcome_email.html       # Welcome email
├── otp_email.html          # OTP email
├── security_alert.html     # Security alerts
└── account_status.html     # Status changes
```

### Base Email Template
```html
<!-- emails/base_email.html -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{{ subject }}</title>
</head>
<body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <div style="padding: 20px;">
        <h1>{{ subject }}</h1>
        
        <div style="margin: 20px 0;">
            {{ main_html_content|safe }}
        </div>
        
        <p>{{ main_text }}</p>
        
        {% if button_url %}
        <div style="text-align: center; margin: 30px 0;">
            <a href="{{ button_url }}" 
               style="background: #007bff; color: white; padding: 12px 24px; 
                      text-decoration: none; border-radius: 4px; display: inline-block;">
                {{ button_text }}
            </a>
        </div>
        {% endif %}
        
        <p style="color: #666; font-size: 14px;">{{ secondary_text }}</p>
        
        <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
        <p style="color: #999; font-size: 12px;">
            This email was sent to {{ user.email }}. 
            If you didn't request this, please contact support.
        </p>
    </div>
</body>
</html>
```

## 📱 Telegram Integration

### Telegram Message Types

```python
# Success messages (green)
DjangoTelegram.send_success("✅ User Registered", {
    "email": user.email,
    "username": user.username,
    "timestamp": timezone.now().isoformat()
})

# Warning messages (yellow)
DjangoTelegram.send_warning("⚠️ Account Deactivated", {
    "user": user.email,
    "reason": "Policy violation"
})

# Error messages (red)
DjangoTelegram.send_error("🚨 Security Alert", {
    "user": user.email,
    "alert_type": "Suspicious Activity",
    "requires_attention": True
})

# Info messages (blue)
DjangoTelegram.send_info("🔑 OTP Request", {
    "email": user.email,
    "source": "Login Page"
})
```

## 📲 SMS Integration

### SMS Configuration
```python
# In your settings
TWILIO_ACCOUNT_SID = "your_account_sid"
TWILIO_AUTH_TOKEN = "your_auth_token"
TWILIO_PHONE_NUMBER = "+1234567890"
```

### SMS Usage
```python
from django_cfg.modules.django_twilio import send_sms

# Send OTP via SMS
result = send_sms(
    to="+1234567890",
    body=f"Your verification code is: {otp_code}. Expires in 10 minutes."
)

if result:
    logger.info("SMS sent successfully")
else:
    logger.error("Failed to send SMS")
```

## 🔧 Configuration

### Settings Configuration
```python
# settings.py
DJANGO_CFG_CONFIG = {
    'project_name': 'Your App Name',
    'site_url': 'https://yourapp.com',
    
    # Email settings
    'email': {
        'from_email': 'noreply@yourapp.com',
        'from_name': 'Your App Team'
    },
    
    # Telegram settings
    'telegram': {
        'bot_token': 'your_bot_token',
        'chat_id': 'your_chat_id'
    },
    
    # Twilio settings
    'twilio': {
        'account_sid': 'your_account_sid',
        'auth_token': 'your_auth_token',
        'phone_number': '+1234567890'
    }
}
```

### Environment Variables
```bash
# .env
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_CHAT_ID=your_chat_id
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=+1234567890
```

## 🧪 Testing Notifications

### Unit Tests
```python
from django.test import TestCase
from unittest.mock import patch, MagicMock
from django_cfg.apps.accounts.utils.notifications import AccountNotifications

class NotificationTests(TestCase):
    
    def setUp(self):
        self.user = User.objects.create_user(
            email='test@example.com',
            username='testuser'
        )
    
    @patch('django_cfg.modules.django_email.DjangoEmailService.send_template')
    def test_welcome_email(self, mock_send):
        mock_send.return_value = True
        
        result = AccountNotifications.send_welcome_email(
            user=self.user,
            send_email=True,
            send_telegram=False
        )
        
        mock_send.assert_called_once()
        args, kwargs = mock_send.call_args
        self.assertEqual(kwargs['recipient_list'], [self.user.email])
        self.assertIn('Welcome', kwargs['subject'])
    
    @patch('django_cfg.modules.django_telegram.DjangoTelegram.send_success')
    def test_telegram_notification(self, mock_telegram):
        AccountNotifications.send_welcome_email(
            user=self.user,
            send_email=False,
            send_telegram=True
        )
        
        mock_telegram.assert_called_once()
        args, kwargs = mock_telegram.call_args
        self.assertIn('New User Registered', args[0])
```

### Integration Tests
```python
class NotificationIntegrationTests(TestCase):
    
    def test_full_registration_flow(self):
        """Test complete registration notification flow."""
        with patch.multiple(
            'django_cfg.modules.django_email.DjangoEmailService',
            send_template=MagicMock(return_value=True)
        ), patch.multiple(
            'django_cfg.modules.django_telegram.DjangoTelegram',
            send_success=MagicMock()
        ):
            # Simulate user registration
            user = User.objects.create_user(
                email='newuser@example.com',
                username='newuser'
            )
            
            # Send notifications
            AccountNotifications.send_welcome_email(user)
            
            # Verify both channels were called
            # Add assertions here
```

## 🔍 Monitoring and Logging

### Logging Configuration
```python
# In your logging configuration
LOGGING = {
    'loggers': {
        'django_cfg.apps.accounts.utils.notifications': {
            'handlers': ['file', 'console'],
            'level': 'INFO',
            'propagate': False,
        },
    }
}
```

### Monitoring Patterns
```python
# Add monitoring to your notifications
import logging
from django.core.cache import cache

logger = logging.getLogger(__name__)

def send_with_monitoring(notification_func, *args, **kwargs):
    """Wrapper for monitoring notification delivery."""
    start_time = time.time()
    
    try:
        result = notification_func(*args, **kwargs)
        
        # Log success
        duration = time.time() - start_time
        logger.info(f"Notification sent successfully in {duration:.2f}s")
        
        # Update metrics
        cache.set('notifications_sent_count', 
                 cache.get('notifications_sent_count', 0) + 1, 3600)
        
        return result
        
    except Exception as e:
        logger.error(f"Notification failed: {e}")
        cache.set('notifications_failed_count',
                 cache.get('notifications_failed_count', 0) + 1, 3600)
        raise
```

## 🚀 Best Practices

### 1. Channel Selection
```python
# Choose appropriate channels based on urgency
NOTIFICATION_CHANNELS = {
    'welcome': {'email': True, 'telegram': True, 'sms': False},
    'security_alert': {'email': True, 'telegram': True, 'sms': True},
    'login': {'email': False, 'telegram': True, 'sms': False},
    'otp': {'email': True, 'telegram': True, 'sms': True},
}
```

### 2. Rate Limiting
```python
from django.core.cache import cache

def rate_limited_notification(user, notification_type, limit_minutes=60):
    """Prevent notification spam."""
    cache_key = f"notification_{user.id}_{notification_type}"
    
    if cache.get(cache_key):
        logger.warning(f"Rate limited notification for {user.email}")
        return False
    
    cache.set(cache_key, True, limit_minutes * 60)
    return True
```

### 3. Graceful Degradation
```python
def send_notification_with_fallback(user, message, channels=['email', 'telegram']):
    """Send notification with fallback channels."""
    success = False
    
    for channel in channels:
        try:
            if channel == 'email':
                result = send_email_notification(user, message)
            elif channel == 'telegram':
                result = send_telegram_notification(user, message)
            
            if result:
                success = True
                break
                
        except Exception as e:
            logger.warning(f"Channel {channel} failed: {e}")
            continue
    
    if not success:
        logger.error(f"All notification channels failed for {user.email}")
    
    return success
```

## 🏷️ Migration from Legacy Systems

### Backward Compatibility
```python
# Legacy AuthEmailService wrapper (already included)
from django_cfg.apps.accounts.utils.notifications import AuthEmailService

# Old code continues to work
email_service = AuthEmailService(user)
email_service.send_welcome_email(user.username)

# But prefer new system
AccountNotifications.send_welcome_email(user)
```

### Migration Checklist
- [ ] Replace direct email service calls
- [ ] Update notification templates
- [ ] Configure Telegram/SMS channels
- [ ] Add monitoring and logging
- [ ] Test all notification flows
- [ ] Update documentation

## 🏷️ Metadata
**Tags**: `notifications, email, telegram, sms, security, user-lifecycle`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Dependencies**: [django-email, django-telegram, django-twilio]
