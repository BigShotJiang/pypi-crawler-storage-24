# 🔍 Real Implementation Examples

## 1. **Payments App URLs (Complex Example)**

### Main API URLs (`urls.py`)
```python
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_nested import routers

from .views import (
    PaymentViewSet, CurrencyViewSet, UserBalanceViewSet,
    PaymentCreateView, SupportedCurrenciesView, WebhookView
)

app_name = 'cfg_payments'

# Main router for global endpoints
router = DefaultRouter()
router.register(r'payments', PaymentViewSet, basename='payment')
router.register(r'currencies', CurrencyViewSet, basename='currency')
router.register(r'balances', UserBalanceViewSet, basename='balance')

# Nested router for user-specific payments
users_router = routers.NestedSimpleRouter(router, r'users', lookup='user')
users_router.register(r'payments', UserPaymentViewSet, basename='user-payments')

urlpatterns = [
    # Router URLs
    path('', include(router.urls)),
    path('', include(users_router.urls)),
    
    # Custom endpoints (specific patterns first!)
    path('payments/create/', PaymentCreateView.as_view(), name='payment-create'),
    path('payments/status/<str:payment_id>/', PaymentStatusView.as_view(), name='payment-status'),
    path('currencies/supported/', SupportedCurrenciesView.as_view(), name='currencies-supported'),
    path('currencies/rates/', CurrencyRatesView.as_view(), name='currency-rates'),
    
    # Webhook endpoints
    path('webhooks/<str:provider>/', WebhookView.as_view(), name='webhook'),
    
    # Health check
    path('health/', HealthCheckView.as_view(), name='health'),
]
```

### Admin Interface URLs (`urls_admin.py`)
```python
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .admin_interface.views import (
    PaymentDashboardView, PaymentListView, PaymentDetailView,
    WebhookDashboardView, PaymentFormView
)
from .admin_interface.views.api import (
    AdminPaymentViewSet, AdminStatsViewSet, AdminWebhookViewSet
)

app_name = 'cfg_payments_admin'

# Admin API router
admin_api_router = DefaultRouter()
admin_api_router.register(r'payments', AdminPaymentViewSet, basename='admin-payment')
admin_api_router.register(r'stats', AdminStatsViewSet, basename='admin-stats')
admin_api_router.register(r'webhooks', AdminWebhookViewSet, basename='admin-webhook')

urlpatterns = [
    # Template views
    path('', PaymentDashboardView.as_view(), name='dashboard'),
    path('payments/', PaymentListView.as_view(), name='payment-list'),
    path('payments/create/', PaymentFormView.as_view(), name='payment-form'),
    path('payments/<uuid:pk>/', PaymentDetailView.as_view(), name='payment-detail'),
    path('webhooks/', WebhookDashboardView.as_view(), name='webhook-dashboard'),
    
    # API endpoints for admin interface
    path('api/', include(admin_api_router.urls)),
]
```

### Generated URL Structure
```
/api/payments/
├── payments/                    # PaymentViewSet
│   ├── GET/POST /              # list/create
│   ├── GET/PUT/DELETE /{id}/   # retrieve/update/destroy
│   ├── POST /{id}/cancel/      # custom action
│   └── GET /stats/             # list action
├── currencies/                  # CurrencyViewSet
├── balances/                   # UserBalanceViewSet
├── payments/create/            # Custom create view
├── currencies/supported/       # Custom currencies view
└── webhooks/{provider}/        # Webhook endpoint

/cfg/admin/django_cfg_payments/admin/
├── /                           # Dashboard
├── payments/                   # Payment list
├── payments/create/            # Payment form
├── payments/{id}/              # Payment detail
├── webhooks/                   # Webhook dashboard
└── api/                        # Admin API
    ├── payments/               # Admin payment API
    ├── stats/                  # Admin stats API
    └── webhooks/               # Admin webhook API
```

## 2. **Knowbase App URLs (Multi-Tier Access)**

### Public + Admin Structure
```python
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_nested import routers

app_name = 'cfg_knowbase'

# Public API router
public_router = DefaultRouter()
public_router.register(r'articles', PublicArticleViewSet, basename='article')
public_router.register(r'categories', PublicCategoryViewSet, basename='category')

# Admin API router
admin_router = DefaultRouter()
admin_router.register(r'articles', AdminArticleViewSet, basename='admin-article')
admin_router.register(r'categories', AdminCategoryViewSet, basename='admin-category')

# Nested routing for category articles
category_router = routers.NestedSimpleRouter(public_router, r'categories', lookup='category')
category_router.register(r'articles', CategoryArticleViewSet, basename='category-articles')

urlpatterns = [
    # Public API
    path('', include(public_router.urls)),
    path('', include(category_router.urls)),
    
    # Search endpoints
    path('search/', ArticleSearchView.as_view(), name='article-search'),
    path('search/suggest/', SearchSuggestView.as_view(), name='search-suggest'),
    
    # Admin API (protected)
    path('admin/', include(admin_router.urls)),
]
```

### Multi-Level Access Control
```python
class PublicArticleViewSet(viewsets.ReadOnlyModelViewSet):
    """Public read-only access to published articles."""
    queryset = Article.objects.filter(status='published')
    serializer_class = PublicArticleSerializer
    permission_classes = []  # Public access

class AdminArticleViewSet(viewsets.ModelViewSet):
    """Full CRUD access for admins."""
    queryset = Article.objects.all()
    serializer_class = AdminArticleSerializer
    permission_classes = [IsAdminUser]
```

## 3. **Support App URLs (Nested Resources)**

### Ticket-Message Hierarchy
```python
from rest_framework_nested import routers

app_name = 'cfg_support'

# Main router
router = DefaultRouter()
router.register(r'tickets', TicketViewSet, basename='ticket')
router.register(r'categories', SupportCategoryViewSet, basename='support-category')

# Nested router for ticket messages
tickets_router = routers.NestedSimpleRouter(router, r'tickets', lookup='ticket')
tickets_router.register(r'messages', TicketMessageViewSet, basename='ticket-messages')

# Nested router for message attachments
messages_router = routers.NestedSimpleRouter(tickets_router, r'messages', lookup='message')
messages_router.register(r'attachments', MessageAttachmentViewSet, basename='message-attachments')

urlpatterns = [
    path('', include(router.urls)),
    path('', include(tickets_router.urls)),
    path('', include(messages_router.urls)),
    
    # Custom endpoints
    path('tickets/my/', MyTicketsView.as_view(), name='my-tickets'),
    path('tickets/<int:pk>/close/', CloseTicketView.as_view(), name='close-ticket'),
]
```

### Generated Nested Structure
```
/api/support/
├── tickets/                           # All tickets
├── tickets/{id}/                      # Specific ticket
├── tickets/{id}/messages/             # Messages for ticket
├── tickets/{id}/messages/{msg_id}/    # Specific message
├── tickets/{id}/messages/{msg_id}/attachments/  # Message attachments
└── tickets/my/                        # User's tickets
```

## 4. **Newsletter App URLs (Simple Structure)**

### Minimal Clean Structure
```python
from django.urls import path, include
from rest_framework.routers import DefaultRouter

app_name = 'cfg_newsletter'

# Simple router for basic CRUD
router = DefaultRouter()
router.register(r'campaigns', CampaignViewSet, basename='campaign')
router.register(r'subscribers', SubscriberViewSet, basename='subscriber')
router.register(r'templates', TemplateViewSet, basename='template')

urlpatterns = [
    path('', include(router.urls)),
    
    # Action endpoints
    path('subscribe/', SubscribeView.as_view(), name='subscribe'),
    path('unsubscribe/<str:token>/', UnsubscribeView.as_view(), name='unsubscribe'),
    path('campaigns/<int:pk>/send/', SendCampaignView.as_view(), name='send-campaign'),
    
    # Analytics
    path('analytics/opens/', OpenAnalyticsView.as_view(), name='open-analytics'),
    path('analytics/clicks/', ClickAnalyticsView.as_view(), name='click-analytics'),
]
```

## 5. **Integration Patterns**

### Main Project URLs Integration
```python
# main_project/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    # Django admin
    path('admin/', admin.site.urls),
    
    # Django-CFG apps API
    path('api/', include('django_cfg.apps.urls')),
    
    # Health check
    path('health/', include('django_cfg.core.health.urls')),
]
```

### Django-CFG Apps Router
```python
# django_cfg/apps/urls.py
from django.urls import path, include

urlpatterns = [
    # App APIs
    path('payments/', include('django_cfg.apps.payments.urls')),
    path('knowbase/', include('django_cfg.apps.knowbase.urls')),
    path('support/', include('django_cfg.apps.support.urls')),
    path('newsletter/', include('django_cfg.apps.newsletter.urls')),
    
    # Admin interfaces
    path('cfg/admin/django_cfg_payments/', include('django_cfg.apps.payments.urls_admin')),
    path('cfg/admin/django_cfg_knowbase/', include('django_cfg.apps.knowbase.urls_admin')),
    path('cfg/admin/django_cfg_support/', include('django_cfg.apps.support.urls_admin')),
]
```

## 6. **Advanced Routing Patterns**

### Conditional URL Registration
```python
from django.conf import settings

# Base URLs
urlpatterns = [
    path('', include(router.urls)),
]

# Add debug URLs in development
if settings.DEBUG:
    urlpatterns += [
        path('debug/', include('debug_toolbar.urls')),
        path('test/', TestView.as_view(), name='test'),
    ]

# Add admin URLs if enabled
if getattr(settings, 'PAYMENTS_ADMIN_ENABLED', True):
    urlpatterns += [
        path('admin/', include(admin_urls)),
    ]
```

### Version-Specific Routing
```python
# API versioning
urlpatterns = [
    path('v1/', include('myapp.urls.v1')),
    path('v2/', include('myapp.urls.v2')),
    path('', include('myapp.urls.v2')),  # Default to latest
]
```

### Dynamic URL Generation
```python
def get_webhook_urls():
    """Generate webhook URLs for all enabled providers."""
    from .providers import get_enabled_providers
    
    urls = []
    for provider in get_enabled_providers():
        urls.append(
            path(f'webhooks/{provider}/', 
                 WebhookView.as_view(), 
                 {'provider': provider},
                 name=f'webhook-{provider}')
        )
    return urls

# Add to urlpatterns
urlpatterns += get_webhook_urls()
```

## 7. **URL Testing Patterns**

### URL Resolution Testing
```python
from django.test import TestCase
from django.urls import reverse, resolve

class URLTest(TestCase):
    
    def test_payment_list_url(self):
        """Test payment list URL resolves correctly."""
        url = reverse('cfg_payments:payment-list')
        self.assertEqual(url, '/api/payments/payments/')
        
        resolver = resolve('/api/payments/payments/')
        self.assertEqual(resolver.view_name, 'cfg_payments:payment-list')
    
    def test_nested_url(self):
        """Test nested URL structure."""
        url = reverse('cfg_support:ticket-messages-list', kwargs={'ticket_pk': 1})
        self.assertEqual(url, '/api/support/tickets/1/messages/')
```

### URL Pattern Validation
```python
def validate_url_patterns():
    """Validate all URL patterns are accessible."""
    from django.urls import get_resolver
    
    resolver = get_resolver()
    for pattern in resolver.url_patterns:
        try:
            # Test pattern compilation
            pattern.resolve('test/')
        except Exception as e:
            print(f"Invalid pattern: {pattern} - {e}")
```

## 8. **Performance Considerations**

### Optimized ViewSet Queries
```python
class PaymentViewSet(viewsets.ModelViewSet):
    
    def get_queryset(self):
        """Optimized queryset with select_related."""
        return UniversalPayment.objects.select_related(
            'user', 'currency', 'network'
        ).prefetch_related(
            'user__payment_balance'
        )
```

### Cached URL Patterns
```python
from django.core.cache import cache

def get_cached_urls():
    """Cache expensive URL generation."""
    cache_key = 'dynamic_urls'
    urls = cache.get(cache_key)
    
    if urls is None:
        urls = generate_dynamic_urls()
        cache.set(cache_key, urls, 3600)  # 1 hour
    
    return urls
```

## 9. **Security Patterns**

### Permission-Based URL Access
```python
class PaymentViewSet(viewsets.ModelViewSet):
    
    def get_queryset(self):
        """Filter queryset based on user permissions."""
        if self.request.user.is_staff:
            return UniversalPayment.objects.all()
        return UniversalPayment.objects.filter(user=self.request.user)
```

### Rate-Limited Endpoints
```python
from django_ratelimit.decorators import ratelimit

@ratelimit(key='ip', rate='10/m', method='POST')
def webhook_view(request, provider):
    """Rate-limited webhook endpoint."""
    pass
```

## 10. **Documentation Integration**

### Auto-Generated API Docs
```python
from drf_spectacular.utils import extend_schema

class PaymentViewSet(viewsets.ModelViewSet):
    
    @extend_schema(
        summary="Cancel payment",
        description="Cancel a pending payment",
        responses={200: PaymentSerializer}
    )
    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        pass
```

These examples show real-world URL routing patterns used in Django-CFG applications, demonstrating proper structure, naming conventions, and integration patterns.
