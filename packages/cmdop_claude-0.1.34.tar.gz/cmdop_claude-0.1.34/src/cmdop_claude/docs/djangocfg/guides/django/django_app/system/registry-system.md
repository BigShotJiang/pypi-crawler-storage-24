# 📦 Django-CFG Registry System Guide %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Organized import system** for django-cfg components with centralized registry
- **Category-based organization** - Core, Services, Modules, Third-Party, Exceptions
- **Universal logic registration** vs direct app imports with clear separation
- **Real implementations** from django-cfg registry system

## 📋 Table of Contents
1. [Registry Overview](#registry-overview)
2. [Registry Categories](#registry-categories)
3. [Real Registry Examples](#real-registry-examples)
4. [Usage Patterns](#usage-patterns)
5. [Registration Guidelines](#registration-guidelines)
6. [Import Best Practices](#import-best-practices)

## 🔑 Key Concepts at a Glance
- **Centralized Registry**: All django-cfg components in organized registries
- **Category-Based**: Core, Services, Modules, Third-Party, Exceptions
- **Universal Logic Only**: Only framework-level components, not app-specific tools
- **Type-Safe Imports**: Proper import paths with lazy loading support
- **Clear Separation**: Framework components vs app-specific components

## 🚀 Quick Start

### Framework Components (Use Registry)
```python
# Import from registry (recommended for framework components)
from django_cfg import DjangoConfig, CacheConfig, get_logger

# Configuration usage
class MyProjectConfig(DjangoConfig):
    cache_default: CacheConfig = CacheConfig(
        redis_url="redis://localhost:6379/0"
    )

# Logging usage
logger = get_logger(__name__)
```

### App-Specific Components (Direct Import)
```python
# Direct import (for app-specific tools)
from myapp.services import MyAppService
from myapp.models import MyAppModel
from myapp.utils import my_utility_function
```

## 📦 Registry Overview

### 1. **Registry Architecture (Real Implementation)**
```python
# django_cfg/registry/__init__.py - Real implementation
from .core import CORE_REGISTRY
from .services import SERVICES_REGISTRY  
from .third_party import THIRD_PARTY_REGISTRY
from .modules import MODULES_REGISTRY
from .exceptions import EXCEPTIONS_REGISTRY

# Combine all registries
DJANGO_CFG_REGISTRY = {
    **CORE_REGISTRY,
    **SERVICES_REGISTRY,
    **THIRD_PARTY_REGISTRY,
    **MODULES_REGISTRY,
    **EXCEPTIONS_REGISTRY,
}

# Export all available names
__all__ = list(DJANGO_CFG_REGISTRY.keys())
```

### 2. **Registry Structure (Real Implementation)**
```
# Real structure from django-cfg
django_cfg/registry/
├── __init__.py          # Combined registry with 80+ components
├── core.py             # Core Django-CFG components (50+ items)
├── services.py         # Service integrations (15+ items)
├── modules.py          # Modules and utilities (10+ items)
├── third_party.py      # Third-party integrations (20+ items)
└── exceptions.py       # Exception classes (5+ items)
```

### 3. **Registration Format (Real Implementation)**
```python
# Registry entry format: "ComponentName": ("module.path", "ComponentName")
REGISTRY_EXAMPLE = {
    "DjangoConfig": ("django_cfg.core.config", "DjangoConfig"),
    "CacheConfig": ("django_cfg.models.cache", "CacheConfig"),
    "get_logger": ("django_cfg.modules.django_logger", "get_logger"),
}
```

## 🏗️ Registry Categories

### 1. **Core Registry (Real Implementation)**
```python
# registry/core.py - Real implementation with 50+ components
CORE_REGISTRY = {
    # Core configuration
    "DjangoConfig": ("django_cfg.core.config", "DjangoConfig"),
    "StartupInfoMode": ("django_cfg.core.config", "StartupInfoMode"),
    
    # Core exceptions
    "ConfigurationError": ("django_cfg.core.exceptions", "ConfigurationError"),
    "ValidationError": ("django_cfg.core.exceptions", "ValidationError"),
    "DatabaseError": ("django_cfg.core.exceptions", "DatabaseError"),
    "CacheError": ("django_cfg.core.exceptions", "CacheError"),
    "EnvironmentError": ("django_cfg.core.exceptions", "EnvironmentError"),
    
    # Core integration
    "DjangoIntegration": ("django_cfg.core.integration", "DjangoIntegration"),
    
    # Database models
    "DatabaseConfig": ("django_cfg.models.database", "DatabaseConfig"),
    
    # Cache models  
    "CacheConfig": ("django_cfg.models.cache", "CacheConfig"),
    
    # Security models
    "SecuritySettings": ("django_cfg.models.security", "SecuritySettings"),
    
    # Logging models
    "LoggingConfig": ("django_cfg.models.logging", "LoggingConfig"),
    
    # Environment models
    "EnvironmentConfig": ("django_cfg.models.environment", "EnvironmentConfig"),
    
    # Limits models
    "LimitsConfig": ("django_cfg.models.limits", "LimitsConfig"),
    
    # JWT models
    "JWTConfig": ("django_cfg.models.jwt", "JWTConfig"),
    
    # Task and queue models
    "TaskConfig": ("django_cfg.models.tasks", "TaskConfig"),
    "DramatiqConfig": ("django_cfg.models.tasks", "DramatiqConfig"),
    
    # Payment system models
    "PaymentsConfig": ("django_cfg.models.payments", "PaymentsConfig"),
    "PaymentProviderConfig": ("django_cfg.models.payments", "PaymentProviderConfig"),
    "NowPaymentsConfig": ("django_cfg.models.payments", "NowPaymentsConfig"),
    "CryptAPIConfig": ("django_cfg.models.payments", "CryptAPIConfig"),
    "StripeConfig": ("django_cfg.models.payments", "StripeConfig"),
    "create_nowpayments_config": ("django_cfg.models.payments", "create_nowpayments_config"),
    "create_cryptapi_config": ("django_cfg.models.payments", "create_cryptapi_config"),
    "create_stripe_config": ("django_cfg.models.payments", "create_stripe_config"),
    "create_cryptomus_config": ("django_cfg.models.payments", "create_cryptomus_config"),
    
    # Pagination classes
    "DefaultPagination": ("django_cfg.middleware.pagination", "DefaultPagination"),
    "LargePagination": ("django_cfg.middleware.pagination", "LargePagination"),
    "SmallPagination": ("django_cfg.middleware.pagination", "SmallPagination"),
    "NoPagination": ("django_cfg.middleware.pagination", "NoPagination"),
    "CursorPaginationEnhanced": ("django_cfg.middleware.pagination", "CursorPaginationEnhanced"),
    
    # Utils
    "version_check": ("django_cfg.utils.version_check", "version_check"),
    "toolkit": ("django_cfg.utils.toolkit", "toolkit"),
    "ConfigToolkit": ("django_cfg.utils.toolkit", "ConfigToolkit"),
    
    # Routing
    "DynamicRouter": ("django_cfg.routing.routers", "DynamicRouter"),
    "health_callback": ("django_cfg.routing.callbacks", "health_callback"),
    
    # Health module
    "HealthService": ("django_cfg.modules.django_health", "HealthService"),
    
    # Library configuration
    "LIB_NAME": ("django_cfg.config", "LIB_NAME"),
    "LIB_SITE_URL": ("django_cfg.config", "LIB_SITE_URL"),
    "LIB_HEALTH_URL": ("django_cfg.config", "LIB_HEALTH_URL"),
    "get_default_dropdown_items": ("django_cfg.config", "get_default_dropdown_items"),
}
```

### 2. **Services Registry (Real Implementation)**
```python
# registry/services.py - Real implementation
SERVICES_REGISTRY = {
    # Email services
    "EmailConfig": ("django_cfg.models.services", "EmailConfig"),
    "DjangoEmailService": ("django_cfg.modules.django_email", "DjangoEmailService"),
    "send_email": ("django_cfg.modules.django_email", "send_email"),
    "SendGridConfig": ("django_cfg.modules.django_twilio.models", "SendGridConfig"),
    
    # Telegram services
    "TelegramConfig": ("django_cfg.models.services", "TelegramConfig"),
    "DjangoTelegram": ("django_cfg.modules.django_telegram", "DjangoTelegram"),
    "send_telegram_message": ("django_cfg.modules.django_telegram", "send_telegram_message"),
    "send_telegram_photo": ("django_cfg.modules.django_telegram", "send_telegram_photo"),
    
    # Twilio services
    "TwilioConfig": ("django_cfg.modules.django_twilio.models", "TwilioConfig"),
    "TwilioVerifyConfig": ("django_cfg.modules.django_twilio.models", "TwilioVerifyConfig"),
    "TwilioChannelType": ("django_cfg.modules.django_twilio.models", "TwilioChannelType"),
    
    # Logging services
    "DjangoLogger": ("django_cfg.modules.django_logger", "DjangoLogger"),
    "get_logger": ("django_cfg.modules.django_logger", "get_logger"),
}
```

### 3. **Modules Registry (Real Implementation)**
```python
# registry/modules.py - Real implementation
MODULES_REGISTRY = {
    # URL integration
    "add_django_cfg_urls": ("django_cfg.core.integration", "add_django_cfg_urls"),
    "get_django_cfg_urls_info": ("django_cfg.core.integration", "get_django_cfg_urls_info"),
    
    # Configuration utilities
    "set_current_config": ("django_cfg.core.config", "set_current_config"),
    
    # Import/Export integration (simple re-exports)
    "ImportForm": ("django_cfg.modules.django_import_export", "ImportForm"),
    "ExportForm": ("django_cfg.modules.django_import_export", "ExportForm"),
    "SelectableFieldsExportForm": ("django_cfg.modules.django_import_export", "SelectableFieldsExportForm"),
    "ImportExportMixin": ("django_cfg.modules.django_import_export", "ImportExportMixin"),
    "ImportExportModelAdmin": ("django_cfg.modules.django_import_export", "ImportExportModelAdmin"),
    "ExportMixin": ("django_cfg.modules.django_import_export", "ExportMixin"),
    "ImportMixin": ("django_cfg.modules.django_import_export", "ImportMixin"),
    "BaseResource": ("django_cfg.modules.django_import_export", "BaseResource"),
}
```

## 🔍 Real Registry Examples

### 1. **Configuration Models Usage (Real Implementation)**
```python
# Real usage pattern from django-cfg projects
from django_cfg import (
    DjangoConfig,
    DatabaseConfig,
    CacheConfig,
    PaymentsConfig,
    SecuritySettings,
    LoggingConfig
)

class ProductionConfig(DjangoConfig):
    """Production configuration using registry components."""
    
    # Database configuration
    database: DatabaseConfig = DatabaseConfig(
        url="postgresql://user:pass@localhost/db",
        pool_size=20,
        max_overflow=30
    )
    
    # Cache configuration
    cache_default: CacheConfig = CacheConfig(
        redis_url="redis://localhost:6379/0",
        ttl=3600,
        key_prefix="prod"
    )
    
    # Payment configuration
    payments: PaymentsConfig = PaymentsConfig(
        enabled=True,
        sandbox_mode=False,
        middleware_enabled=True
    )
    
    # Security settings
    security: SecuritySettings = SecuritySettings(
        allowed_hosts=["myapp.com", "www.myapp.com"],
        csrf_trusted_origins=["https://myapp.com"],
        secure_ssl_redirect=True
    )
    
    # Logging configuration
    logging: LoggingConfig = LoggingConfig(
        level="INFO",
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        file_path="/var/log/myapp.log"
    )
```

### 2. **Service Integration Usage (Real Implementation)**
```python
# Real service integration pattern
from django_cfg import (
    get_logger,
    DjangoTelegram,
    DjangoEmailService,
    send_email,
    send_telegram_message
)

class NotificationService:
    """Service using registry components for notifications."""
    
    def __init__(self):
        # Framework logger from registry
        self.logger = get_logger(__name__)
        
        # Telegram service from registry
        self.telegram = DjangoTelegram()
        
        # Email service from registry
        self.email_service = DjangoEmailService()
    
    def send_notification(self, user, message, channels=None):
        """Send notification using multiple channels."""
        channels = channels or ['email', 'telegram']
        
        self.logger.info(f"Sending notification to user {user.id}")
        
        results = {}
        
        if 'email' in channels and user.email:
            try:
                # Use registry function
                result = send_email(
                    to=user.email,
                    subject="Notification",
                    message=message
                )
                results['email'] = result
                self.logger.info(f"Email sent to {user.email}")
            except Exception as e:
                self.logger.error(f"Email failed: {e}")
                results['email'] = False
        
        if 'telegram' in channels and user.telegram_id:
            try:
                # Use registry function
                result = send_telegram_message(
                    chat_id=user.telegram_id,
                    message=message
                )
                results['telegram'] = result
                self.logger.info(f"Telegram sent to {user.telegram_id}")
            except Exception as e:
                self.logger.error(f"Telegram failed: {e}")
                results['telegram'] = False
        
        return results
```

### 3. **Third-Party Integration Usage (Real Implementation)**
```python
# Real third-party integration pattern
from django_cfg import (
    UnfoldConfig,
    NavigationItem,
    StatCard,
    Icons,
    RevolutionConfig
)

class AdminConfig:
    """Admin configuration using registry components."""
    
    def get_unfold_config(self):
        """Get Unfold admin configuration."""
        return UnfoldConfig(
            site_title="My Admin",
            site_header="My Application",
            theme="dark",
            navigation=[
                NavigationItem(
                    title="Dashboard",
                    icon=Icons.DASHBOARD,
                    url="/admin/"
                ),
                NavigationItem(
                    title="Users",
                    icon=Icons.PEOPLE,
                    url="/admin/auth/user/"
                ),
                NavigationItem(
                    title="Payments",
                    icon=Icons.PAYMENT,
                    url="/admin/payments/"
                )
            ],
            dashboard_stats=[
                StatCard(
                    title="Total Users",
                    value=1250,
                    icon=Icons.PEOPLE,
                    color="primary"
                ),
                StatCard(
                    title="Revenue",
                    value="$12,500",
                    icon=Icons.MONEY,
                    color="success"
                )
            ]
        )
    
    def get_revolution_config(self):
        """Get Revolution API configuration."""
        return RevolutionConfig(
            enabled=True,
            auto_generate=True,
            base_url="/api/v1/",
            documentation_url="/docs/"
        )
```

## 🎯 Usage Patterns

### 1. **Framework vs App Components (Real Implementation)**
```python
# ✅ CORRECT: Clear separation pattern
# Framework components from registry
from django_cfg import (
    DjangoConfig,
    CacheConfig,
    get_logger,
    DjangoTelegram
)

# App components via direct import
from payments.services import PaymentService
from payments.models import UniversalPayment
from knowbase.services import DocumentService
from accounts.models import CustomUser

# Usage in Django project
class PaymentProcessingService:
    """Service combining framework and app components."""
    
    def __init__(self):
        # Framework components via registry
        self.logger = get_logger(__name__)
        self.telegram = DjangoTelegram()
        
        # App-specific components via direct import
        self.payment_service = PaymentService()
        self.payment_model = UniversalPayment
    
    def process_payment(self, user_id: int, amount: float):
        """Process payment using both framework and app components."""
        self.logger.info(f"Processing payment for user {user_id}")
        
        try:
            # Use app-specific service
            payment = self.payment_service.create_payment(
                user_id=user_id,
                amount=amount
            )
            
            # Use framework service for notification
            self.telegram.send_success(
                f"Payment processed: ${amount}",
                {"payment_id": payment.id, "user_id": user_id}
            )
            
            self.logger.info(f"Payment {payment.id} processed successfully")
            return payment
            
        except Exception as e:
            self.logger.error(f"Payment processing failed: {e}")
            
            # Use framework service for error notification
            self.telegram.send_error(
                f"Payment failed: ${amount}",
                {"error": str(e), "user_id": user_id}
            )
            raise

# ❌ WRONG: Mixing patterns
from django_cfg import PaymentService  # App service shouldn't be in registry
from django_cfg.modules.django_logger import get_logger  # Use registry import
```

### 2. **Configuration Pattern (Real Implementation)**
```python
# ✅ CORRECT: Configuration using registry components
from django_cfg import (
    DjangoConfig,
    DatabaseConfig,
    CacheConfig,
    PaymentsConfig,
    SecuritySettings,
    LoggingConfig,
    TelegramConfig,
    EmailConfig
)

class MyProjectConfig(DjangoConfig):
    """Project configuration using framework components."""
    
    project_name: str = "My Awesome Project"
    debug: bool = False
    
    # Database configuration
    database: DatabaseConfig = DatabaseConfig(
        url="postgresql://localhost/myproject",
        pool_size=10
    )
    
    # Cache configuration
    cache_default: CacheConfig = CacheConfig(
        redis_url="redis://localhost:6379/0",
        ttl=3600
    )
    
    # Payment configuration
    payments: PaymentsConfig = PaymentsConfig(
        enabled=True,
        sandbox_mode=False
    )
    
    # Security configuration
    security: SecuritySettings = SecuritySettings(
        allowed_hosts=["myproject.com"],
        secure_ssl_redirect=True
    )
    
    # Logging configuration
    logging: LoggingConfig = LoggingConfig(
        level="INFO",
        format="%(asctime)s - %(levelname)s - %(message)s"
    )
    
    # Service configurations
    telegram: TelegramConfig = TelegramConfig(
        bot_token="your-bot-token",
        chat_id="your-chat-id"
    )
    
    email: EmailConfig = EmailConfig(
        backend="django.core.mail.backends.smtp.EmailBackend",
        host="smtp.gmail.com",
        port=587,
        use_tls=True
    )

# Initialize configuration
config = MyProjectConfig()
settings = config.get_all_settings()

# ❌ WRONG: Direct model imports in config
from django_cfg.models.cache import CacheConfig  # Use registry instead
from django_cfg.models.database import DatabaseConfig  # Use registry instead
```

## 📋 Registration Guidelines

### 1. **What Should Be Registered (Real Criteria)**
```python
# ✅ REGISTER: Universal framework components
SHOULD_REGISTER = [
    # Core configuration models
    "DjangoConfig",           # Main configuration class
    "CacheConfig",           # Cache configuration
    "DatabaseConfig",        # Database configuration
    "PaymentsConfig",        # Payment system configuration
    
    # Universal services
    "get_logger",            # Logging service
    "send_email",            # Email service
    "DjangoTelegram",        # Telegram service
    
    # Framework integrations
    "UnfoldConfig",          # Admin interface
    "RevolutionConfig",      # API generation
    "DRFConfig",             # Django REST Framework
    
    # Reusable utilities
    "add_django_cfg_urls",   # URL integration
    "ImportExportMixin",     # Import/Export functionality
    "DefaultPagination",     # Pagination classes
    
    # Exception classes
    "ConfigurationError",    # Framework exceptions
    "ValidationError",       # Validation exceptions
]

# ❌ DON'T REGISTER: App-specific components
SHOULD_NOT_REGISTER = [
    # App models
    "UniversalPayment",      # Payment app model
    "ExternalData",          # Knowbase app model
    "CustomUser",            # Accounts app model
    
    # App services
    "PaymentService",        # Payment processing service
    "DocumentService",       # Document processing service
    "UserService",           # User management service
    
    # App utilities
    "payment_utils",         # Payment-specific utilities
    "document_utils",        # Document-specific utilities
    
    # App-specific views, serializers, managers
    "PaymentViewSet",        # Payment API views
    "DocumentSerializer",    # Document serializers
    "PaymentManager",        # Payment model manager
]
```

### 2. **Registration Decision Tree (Real Implementation)**
```python
def should_register_component(component_name: str, component_path: str) -> bool:
    """Determine if component should be in registry."""
    
    # Framework-level components
    if component_path.startswith("django_cfg.core"):
        return True
    
    # Configuration models
    if component_path.startswith("django_cfg.models") and "Config" in component_name:
        return True
    
    # Universal services and utilities
    if component_path.startswith("django_cfg.modules") and any([
        "get_" in component_name,
        "send_" in component_name,
        "Django" in component_name and "Service" in component_name
    ]):
        return True
    
    # Third-party integrations
    if any(integration in component_path for integration in [
        "django_unfold", "django_revolution", "django_import_export"
    ]):
        return True
    
    # Exception classes
    if "Error" in component_name or "Exception" in component_name:
        return True
    
    # App-specific components (don't register)
    if component_path.startswith("django_cfg.apps"):
        return False
    
    return False

# Examples of registration decisions
examples = [
    ("DjangoConfig", "django_cfg.core.config"),           # True - core framework
    ("get_logger", "django_cfg.modules.django_logger"),   # True - universal service
    ("PaymentService", "django_cfg.apps.payments"),       # False - app-specific
    ("UnfoldConfig", "django_cfg.modules.django_unfold"), # True - third-party integration
    ("CustomUser", "django_cfg.apps.accounts"),           # False - app model
]

for name, path in examples:
    result = should_register_component(name, path)
    print(f"{name}: {result}")
```

## 🎯 Import Best Practices

### 1. **Organized Import Pattern (Real Implementation)**
```python
# ✅ CORRECT: Well-organized imports
# Standard library
import os
import json
from typing import Dict, List, Optional
from datetime import datetime, timedelta

# Third-party
from pydantic import BaseModel, Field
from celery import shared_task

# Django
from django.conf import settings
from django.core.cache import cache
from django.contrib.auth import get_user_model
from django.db import transaction

# Django-CFG framework (via registry)
from django_cfg import (
    # Configuration
    DjangoConfig,
    CacheConfig,
    PaymentsConfig,
    
    # Services
    get_logger,
    DjangoTelegram,
    send_email,
    
    # Exceptions
    ConfigurationError,
    ValidationError
)

# App-specific (direct imports)
from .models import UniversalPayment, UserBalance
from .services import PaymentProcessor, BalanceManager
from .utils import format_currency, validate_amount
from .exceptions import PaymentError, InsufficientFundsError

# ❌ WRONG: Mixed import styles and poor organization
from django_cfg.core.config import DjangoConfig  # Use registry
from django_cfg import PaymentProcessor  # App service shouldn't be in registry
from .models import UniversalPayment
from django_cfg.modules.django_logger import get_logger  # Use registry
import os  # Should be at top
```

### 2. **Service Layer Pattern (Real Implementation)**
```python
# ✅ CORRECT: Service layer with proper imports
from django_cfg import get_logger, DjangoTelegram, ConfigurationError
from .models import UniversalPayment, UserBalance
from .managers import PaymentManager, BalanceManager
from .utils import validate_payment_data, format_payment_response

class PaymentProcessingService:
    """Payment processing service with framework integration."""
    
    def __init__(self):
        # Framework components via registry
        self.logger = get_logger(__name__)
        self.telegram = DjangoTelegram()
        
        # App-specific components via direct import
        self.payment_manager = PaymentManager()
        self.balance_manager = BalanceManager()
    
    def process_payment(self, payment_data: dict) -> dict:
        """Process payment with comprehensive error handling."""
        try:
            # Validate using app utility
            validated_data = validate_payment_data(payment_data)
            
            # Log using framework service
            self.logger.info(f"Processing payment: {validated_data['amount']}")
            
            # Process using app manager
            with transaction.atomic():
                payment = self.payment_manager.create_payment(validated_data)
                balance = self.balance_manager.update_balance(
                    user=payment.user,
                    amount=payment.amount_usd
                )
            
            # Notify using framework service
            self.telegram.send_success(
                f"Payment processed: ${payment.amount_usd}",
                {
                    "payment_id": str(payment.id),
                    "user_id": payment.user.id,
                    "new_balance": balance.amount
                }
            )
            
            # Format response using app utility
            response = format_payment_response(payment, balance)
            
            self.logger.info(f"Payment {payment.id} processed successfully")
            return response
            
        except ValidationError as e:
            self.logger.error(f"Payment validation failed: {e}")
            raise
            
        except ConfigurationError as e:
            self.logger.error(f"Payment configuration error: {e}")
            
            # Notify error using framework service
            self.telegram.send_error(
                "Payment configuration error",
                {"error": str(e), "data": payment_data}
            )
            raise
            
        except Exception as e:
            self.logger.error(f"Unexpected payment error: {e}")
            
            # Notify error using framework service
            self.telegram.send_error(
                "Payment processing failed",
                {"error": str(e), "data": payment_data}
            )
            raise

# ❌ WRONG: Poor separation and import mixing
class BadPaymentService:
    def __init__(self):
        # Mixing direct imports with registry
        from django_cfg.modules.django_logger import get_logger  # Use registry
        from django_cfg import PaymentManager  # App component in registry
        
        self.logger = get_logger(__name__)
        self.payment_manager = PaymentManager()  # Should be direct import
```

### 3. **Configuration Import Pattern (Real Implementation)**
```python
# ✅ CORRECT: Configuration with proper registry usage
from django_cfg import (
    DjangoConfig,
    DatabaseConfig,
    CacheConfig,
    PaymentsConfig,
    SecuritySettings,
    LoggingConfig,
    TelegramConfig,
    EmailConfig,
    UnfoldConfig
)

# App-specific configuration (if needed)
from .payment_providers import get_payment_provider_configs
from .custom_middleware import get_custom_middleware_list

class ProductionConfig(DjangoConfig):
    """Production configuration using registry components."""
    
    # Basic settings
    project_name: str = "My Production App"
    debug: bool = False
    
    # Framework configurations via registry
    database: DatabaseConfig = DatabaseConfig(
        url=os.getenv("DATABASE_URL"),
        pool_size=20,
        max_overflow=30
    )
    
    cache_default: CacheConfig = CacheConfig(
        redis_url=os.getenv("REDIS_URL"),
        ttl=3600,
        key_prefix="prod"
    )
    
    payments: PaymentsConfig = PaymentsConfig(
        enabled=True,
        sandbox_mode=False,
        middleware_enabled=True
    )
    
    security: SecuritySettings = SecuritySettings(
        allowed_hosts=["myapp.com", "www.myapp.com"],
        csrf_trusted_origins=["https://myapp.com"],
        secure_ssl_redirect=True
    )
    
    telegram: TelegramConfig = TelegramConfig(
        bot_token=os.getenv("TELEGRAM_BOT_TOKEN"),
        chat_id=os.getenv("TELEGRAM_CHAT_ID")
    )
    
    unfold: UnfoldConfig = UnfoldConfig(
        site_title="My Admin",
        site_header="Production Admin",
        theme="dark"
    )
    
    def __post_init__(self):
        """Post-initialization with app-specific logic."""
        # Use app-specific functions for complex configuration
        self.payment_providers = get_payment_provider_configs()
        self.custom_middleware = get_custom_middleware_list()

# Initialize configuration
config = ProductionConfig()

# ❌ WRONG: Direct imports instead of registry
from django_cfg.models.database import DatabaseConfig  # Use registry
from django_cfg.models.cache import CacheConfig  # Use registry
from django_cfg.core.config import DjangoConfig  # Use registry
```

## 🏷️ Metadata
**Tags**: `registry, imports, components, architecture, organization, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Real Examples**: Core, Services, Modules registries with 80+ components
**DEPENDS_ON**: [django-cfg-core, pydantic, typing]
**USED_BY**: [all-django-cfg-components, project-configurations]
