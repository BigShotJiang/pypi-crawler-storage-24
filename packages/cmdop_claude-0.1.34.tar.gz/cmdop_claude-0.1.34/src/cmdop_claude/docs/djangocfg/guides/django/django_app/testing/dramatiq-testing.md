# 🎭 Dramatiq Testing Patterns

## 1. **Task Mocking Pattern (Real Implementation)**
```python
# Real pattern from django-cfg tests
from unittest.mock import patch, MagicMock
import sys

# Mock Dramatiq at module level
sys.modules['dramatiq'] = MagicMock()
sys.modules['dramatiq.brokers.rabbitmq'] = MagicMock()

class BackgroundTaskTestCase(TestCase):
    """Test background task functionality."""
    
    def setUp(self):
        """Set up test data."""
        self.user = UserFactory.create_user()
        self.document = DocumentFactory.create_processing_document(self.user)
    
    @patch('django_cfg.apps.knowbase.tasks.external_data_tasks.process_external_data_async')
    def test_document_processing_task_triggered(self, mock_task):
        """Test that document processing task is triggered."""
        # Mock task
        mock_task.send = MagicMock()
        
        # Trigger document processing
        from ..signals.external_data_signals import _start_external_data_processing
        _start_external_data_processing(self.document)
        
        # Verify task was called
        mock_task.send.assert_called_once_with(str(self.document.id))
    
    @patch('django_cfg.modules.django_llm.get_embeddings')
    def test_process_document_task_execution(self, mock_get_embeddings):
        """Test actual task execution (mocked)."""
        # Mock embedding response
        mock_get_embeddings.return_value = [0.1, 0.2, 0.3]
        
        # Import and execute task directly (synchronously for testing)
        from ..tasks.external_data_tasks import process_external_data_sync
        
        result = process_external_data_sync(str(self.document.id))
        
        # Verify processing
        self.assertTrue(result['success'])
        
        # Refresh document from database
        self.document.refresh_from_db()
        self.assertEqual(self.document.processing_status, ProcessingStatus.COMPLETED)
    
    def test_task_error_handling(self):
        """Test task error handling."""
        # Import task
        from ..tasks.external_data_tasks import process_external_data_sync
        
        # Test with invalid document ID
        result = process_external_data_sync("invalid-id")
        
        # Verify error handling
        self.assertFalse(result['success'])
        self.assertIn('error', result)
```

## 2. **Async Task Testing Pattern (Real Implementation)**
```python
# Real pattern for async task testing
import asyncio
from unittest.mock import AsyncMock, patch

class AsyncTaskTestCase(TestCase):
    """Test async task functionality."""
    
    def setUp(self):
        """Set up test data."""
        self.user = UserFactory.create_user()
    
    @patch('django_cfg.modules.django_llm.get_embeddings_async')
    def test_async_embedding_processing(self, mock_get_embeddings):
        """Test async embedding processing."""
        # Mock async embedding response
        mock_get_embeddings.return_value = asyncio.Future()
        mock_get_embeddings.return_value.set_result([0.1, 0.2, 0.3])
        
        # Run async test
        async def run_test():
            from ..services.embedding.async_processor import AsyncEmbeddingProcessor
            
            processor = AsyncEmbeddingProcessor()
            result = await processor.process_document_async(self.document)
            
            return result
        
        # Execute async test
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        try:
            result = loop.run_until_complete(run_test())
            self.assertTrue(result.success)
        finally:
            loop.close()
```

## Background Task Testing
```python
from unittest.mock import patch
from django.test import TestCase
from dramatiq.testing import StubBroker

class TaskTestCase(TestCase):
    def setUp(self):
        # Use stub broker for testing
        self.broker = StubBroker()
        self.broker.flush_all()
    
    @patch('my_app.tasks.process_document.send')
    def test_task_enqueuing(self, mock_send):
        """Test that tasks are properly enqueued."""
        # Trigger action that should enqueue task
        result = my_service.process_document(document_id=1)
        
        # Verify task was enqueued
        mock_send.assert_called_once_with(document_id=1)
        self.assertTrue(result.success)
    
    def test_task_execution(self):
        """Test actual task execution."""
        from my_app.tasks import process_document
        
        # Execute task directly
        result = process_document(document_id=1)
        
        # Verify task results
        self.assertIsNotNone(result)
```

## Mocking External Services in Tasks
```python
class ExternalServiceTaskTest(TestCase):
    @patch('external_api.client.post')
    def test_external_api_task(self, mock_post):
        mock_post.return_value.json.return_value = {"status": "success"}
        
        from my_app.tasks import sync_external_data
        result = sync_external_data(user_id=1)
        
        self.assertTrue(result.success)
        mock_post.assert_called_once()
```
