# ⚙️ Configuration Guide %%PRIORITY:HIGH%%

## 🎯 Overview

Type-safe configuration system using Pydantic 2 models for all admin display and behavior settings.

## 🏗️ Configuration Architecture

```
Pydantic 2 Models (Type Safety)
    ↓
Configuration Objects (Runtime)
    ↓
Utility Functions (Rendering)
    ↓
HTML Output (Consistent)
```

## 🔧 Configuration Models

### StatusBadgeConfig %%PRIORITY:HIGH%%

Configure status badge appearance and behavior.

```python
from django_cfg.modules.django_admin import StatusBadgeConfig, Icons

# Basic configuration
config = StatusBadgeConfig()

# Advanced configuration
config = StatusBadgeConfig(
    custom_mappings={
        'draft': 'secondary',
        'pending': 'warning',
        'approved': 'success',
        'rejected': 'danger'
    },
    show_icons=True,
    icon=Icons.CHECK_CIRCLE,
    custom_css_classes=['my-badge', 'large']
)
```

**Fields:**
- `custom_mappings`: Dict[str, str] - Map status values to badge variants
- `show_icons`: bool - Show icons in badges
- `icon`: Optional[str] - Specific icon (overrides auto-selection)
- `custom_css_classes`: List[str] - Additional CSS classes

**Default Status Mappings:**
```python
DEFAULT_MAPPINGS = {
    'active': 'success',
    'inactive': 'secondary',
    'pending': 'warning',
    'completed': 'success',
    'failed': 'danger',
    'cancelled': 'danger',
    'processing': 'info',
    'draft': 'secondary'
}
```

### MoneyDisplayConfig %%PRIORITY:HIGH%%

Configure money amount formatting.

```python
from django_cfg.modules.django_admin import MoneyDisplayConfig

# USD with standard formatting
config = MoneyDisplayConfig(
    currency="USD",
    decimal_places=2,
    thousand_separator=True,
    show_sign=False
)

# EUR with sign display
config = MoneyDisplayConfig(
    currency="EUR",
    decimal_places=2,
    thousand_separator=True,
    show_sign=True  # Shows +/- for positive/negative
)

# Crypto with high precision
config = MoneyDisplayConfig(
    currency="BTC",
    decimal_places=8,
    thousand_separator=False,
    show_sign=False
)
```

**Fields:**
- `currency`: str - Currency code (USD, EUR, BTC, etc.)
- `decimal_places`: int - Number of decimal places (default: 2)
- `thousand_separator`: bool - Use thousand separators (default: False)
- `show_sign`: bool - Show +/- sign (default: False)

### UserDisplayConfig %%PRIORITY:HIGH%%

Configure user display appearance.

```python
from django_cfg.modules.django_admin import UserDisplayConfig

# Standard user display
config = UserDisplayConfig(
    show_email=True,
    show_avatar=True,
    avatar_size=32,
    fallback_initials=True
)

# Minimal user display
config = UserDisplayConfig(
    show_email=False,
    show_avatar=False,
    avatar_size=24,
    fallback_initials=False
)

# Large avatar display
config = UserDisplayConfig(
    show_email=True,
    show_avatar=True,
    avatar_size=48,
    fallback_initials=True
)
```

**Fields:**
- `show_email`: bool - Include email in display (default: True)
- `show_avatar`: bool - Show user avatar (default: True)
- `avatar_size`: int - Avatar size in pixels (default: 32)
- `fallback_initials`: bool - Show initials if no avatar (default: True)

### DateTimeDisplayConfig %%PRIORITY:HIGH%%

Configure datetime display format.

```python
from django_cfg.modules.django_admin import DateTimeDisplayConfig

# Relative time display
config = DateTimeDisplayConfig(
    show_relative=True,
    show_seconds=False,
    datetime_format="%Y-%m-%d %H:%M:%S"
)

# Absolute time display
config = DateTimeDisplayConfig(
    show_relative=False,
    show_seconds=True,
    datetime_format="%d/%m/%Y %H:%M:%S"
)

# Compact display
config = DateTimeDisplayConfig(
    show_relative=True,
    show_seconds=False,
    datetime_format="%m/%d %H:%M"
)
```

**Fields:**
- `show_relative`: bool - Show relative time ("2 hours ago") (default: True)
- `show_seconds`: bool - Include seconds in display (default: False)
- `datetime_format`: str - Fallback format string (default: "%Y-%m-%d %H:%M:%S")

## 🎨 Configuration Patterns

### Pattern 1: Shared Configurations

Create reusable configurations for consistency across admin classes.

```python
# apps/myapp/admin/configs.py
from django_cfg.modules.django_admin import (
    StatusBadgeConfig,
    MoneyDisplayConfig,
    UserDisplayConfig,
    Icons
)

class AdminConfigs:
    """Centralized admin configurations."""
    
    # Order status configuration
    ORDER_STATUS = StatusBadgeConfig(
        custom_mappings={
            'pending': 'warning',
            'processing': 'info',
            'shipped': 'primary',
            'delivered': 'success',
            'cancelled': 'danger',
            'refunded': 'warning'
        },
        show_icons=True,
        icon=Icons.SHOPPING_CART
    )
    
    # Payment status configuration
    PAYMENT_STATUS = StatusBadgeConfig(
        custom_mappings={
            'pending': 'warning',
            'processing': 'info',
            'completed': 'success',
            'failed': 'danger',
            'refunded': 'warning'
        },
        show_icons=True,
        icon=Icons.PAYMENT
    )
    
    # Money configurations
    MONEY_USD = MoneyDisplayConfig(
        currency="USD",
        decimal_places=2,
        thousand_separator=True
    )
    
    MONEY_EUR = MoneyDisplayConfig(
        currency="EUR",
        decimal_places=2,
        thousand_separator=True
    )
    
    # User configurations
    USER_STANDARD = UserDisplayConfig(
        show_email=True,
        show_avatar=True,
        avatar_size=32
    )
    
    USER_COMPACT = UserDisplayConfig(
        show_email=False,
        show_avatar=True,
        avatar_size=24
    )

# Usage in admin classes
from .configs import AdminConfigs

@admin.register(Order)
class OrderAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    
    @display(description="Status", label=True)
    def status_display(self, obj):
        return self.display_status_auto(obj, 'status', AdminConfigs.ORDER_STATUS)
    
    @display(description="Total")
    def total_display(self, obj):
        return self.display_money_amount(obj, 'total', AdminConfigs.MONEY_USD)
```

### Pattern 2: Dynamic Configurations

Create configurations based on runtime conditions.

```python
class OrderAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    
    def get_money_config(self, obj):
        """Get money configuration based on order currency."""
        currency_configs = {
            'USD': MoneyDisplayConfig(currency="USD", decimal_places=2),
            'EUR': MoneyDisplayConfig(currency="EUR", decimal_places=2),
            'BTC': MoneyDisplayConfig(currency="BTC", decimal_places=8),
        }
        return currency_configs.get(obj.currency, currency_configs['USD'])
    
    @display(description="Total")
    def total_display(self, obj):
        config = self.get_money_config(obj)
        return self.display_money_amount(obj, 'total_amount', config)
```

### Pattern 3: Conditional Configurations

Modify configurations based on object state.

```python
@display(description="Status", label=True)
def status_display(self, obj):
    # Different icons based on priority
    icon = Icons.PRIORITY_HIGH if obj.is_priority else Icons.SHOPPING_CART
    
    config = StatusBadgeConfig(
        custom_mappings={
            'pending': 'warning',
            'completed': 'success',
            'cancelled': 'danger'
        },
        show_icons=True,
        icon=icon
    )
    return self.display_status_auto(obj, 'status', config)
```

## 🔧 Advanced Configuration

### Custom Badge Variants

Extend default badge variants for specific use cases.

```python
# Custom status mappings for specific business logic
SUBSCRIPTION_STATUS = StatusBadgeConfig(
    custom_mappings={
        'trial': 'info',
        'active': 'success',
        'past_due': 'warning',
        'cancelled': 'secondary',
        'expired': 'danger'
    },
    show_icons=True,
    icon=Icons.SUBSCRIPTION
)
```

### Multi-Currency Support

```python
class PaymentAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    
    CURRENCY_CONFIGS = {
        'USD': MoneyDisplayConfig(currency="USD", decimal_places=2),
        'EUR': MoneyDisplayConfig(currency="EUR", decimal_places=2),
        'GBP': MoneyDisplayConfig(currency="GBP", decimal_places=2),
        'BTC': MoneyDisplayConfig(currency="BTC", decimal_places=8),
        'ETH': MoneyDisplayConfig(currency="ETH", decimal_places=6),
    }
    
    @display(description="Amount")
    def amount_display(self, obj):
        currency = getattr(obj.currency, 'code', 'USD') if obj.currency else 'USD'
        config = self.CURRENCY_CONFIGS.get(currency, self.CURRENCY_CONFIGS['USD'])
        return self.display_money_amount(obj, 'amount', config)
```

### Contextual User Display

```python
@display(description="Customer", header=True)
def customer_display(self, obj):
    # Show different info based on user type
    if obj.customer.is_vip:
        config = UserDisplayConfig(
            show_email=True,
            show_avatar=True,
            avatar_size=40,  # Larger for VIP
            fallback_initials=True
        )
    else:
        config = UserDisplayConfig(
            show_email=True,
            show_avatar=True,
            avatar_size=32,
            fallback_initials=True
        )
    
    return self.display_user_with_avatar(obj, 'customer', config)
```

## 🎯 Configuration Validation

### Pydantic Validation

All configurations are validated at runtime:

```python
# This will raise ValidationError
try:
    config = MoneyDisplayConfig(
        currency="USD",
        decimal_places=-1  # Invalid: negative decimal places
    )
except ValidationError as e:
    print(f"Configuration error: {e}")

# This will raise ValidationError
try:
    config = StatusBadgeConfig(
        custom_mappings="invalid"  # Invalid: should be dict
    )
except ValidationError as e:
    print(f"Configuration error: {e}")
```

### Configuration Testing

```python
# tests/test_admin_configs.py
from django.test import TestCase
from django_cfg.modules.django_admin import MoneyDisplayConfig
from pydantic import ValidationError

class ConfigurationTest(TestCase):
    
    def test_valid_money_config(self):
        """Test valid money configuration."""
        config = MoneyDisplayConfig(
            currency="USD",
            decimal_places=2,
            thousand_separator=True
        )
        self.assertEqual(config.currency, "USD")
        self.assertEqual(config.decimal_places, 2)
        self.assertTrue(config.thousand_separator)
    
    def test_invalid_money_config(self):
        """Test invalid money configuration."""
        with self.assertRaises(ValidationError):
            MoneyDisplayConfig(decimal_places=-1)
```

## 🔍 Configuration Debugging

### Debug Configuration Values

```python
@display(description="Debug Status")
def debug_status_display(self, obj):
    config = StatusBadgeConfig(
        custom_mappings={'active': 'success'},
        show_icons=True
    )
    
    # Debug configuration
    print(f"Config: {config.model_dump()}")
    
    return self.display_status_auto(obj, 'status', config)
```

### Configuration Introspection

```python
# Get all available configuration fields
from django_cfg.modules.django_admin import StatusBadgeConfig

# Print model schema
print(StatusBadgeConfig.model_json_schema())

# Print field information
for field_name, field_info in StatusBadgeConfig.model_fields.items():
    print(f"{field_name}: {field_info.annotation}")
```

## 🏷️ Configuration Examples by Use Case

### E-commerce Admin

```python
class EcommerceConfigs:
    ORDER_STATUS = StatusBadgeConfig(
        custom_mappings={
            'cart': 'secondary',
            'pending': 'warning',
            'processing': 'info',
            'shipped': 'primary',
            'delivered': 'success',
            'returned': 'warning',
            'cancelled': 'danger'
        },
        show_icons=True,
        icon=Icons.SHOPPING_CART
    )
    
    PRODUCT_PRICE = MoneyDisplayConfig(
        currency="USD",
        decimal_places=2,
        thousand_separator=True,
        show_sign=False
    )
```

### SaaS Admin

```python
class SaasConfigs:
    SUBSCRIPTION_STATUS = StatusBadgeConfig(
        custom_mappings={
            'trial': 'info',
            'active': 'success',
            'past_due': 'warning',
            'cancelled': 'secondary',
            'expired': 'danger'
        },
        show_icons=True,
        icon=Icons.SUBSCRIPTION
    )
    
    BILLING_AMOUNT = MoneyDisplayConfig(
        currency="USD",
        decimal_places=2,
        thousand_separator=True,
        show_sign=True  # Show credits/debits
    )
```

### Content Management

```python
class CMSConfigs:
    CONTENT_STATUS = StatusBadgeConfig(
        custom_mappings={
            'draft': 'secondary',
            'review': 'warning',
            'published': 'success',
            'archived': 'info'
        },
        show_icons=True,
        icon=Icons.ARTICLE
    )
    
    AUTHOR_DISPLAY = UserDisplayConfig(
        show_email=False,  # Don't show email for authors
        show_avatar=True,
        avatar_size=28,
        fallback_initials=True
    )
```

## 🏷️ Metadata
**Tags**: `configuration, pydantic, type-safety, settings, customization`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Dependencies**: [pydantic>=2.0]
