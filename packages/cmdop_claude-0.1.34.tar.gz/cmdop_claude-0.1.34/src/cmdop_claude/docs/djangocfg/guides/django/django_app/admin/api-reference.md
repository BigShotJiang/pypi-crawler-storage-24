# 📖 API Reference %%PRIORITY:HIGH%%

## 🎯 Overview

Complete API reference for Django-CFG admin system components, decorators, and utilities.

## 🏗️ Core Classes

### OptimizedModelAdmin

**Location**: `django_cfg.modules.django_admin.mixins.optimization_mixin`

```python
class OptimizedModelAdmin(admin.ModelAdmin):
    """Performance-optimized ModelAdmin base class."""
    
    # Configuration attributes
    select_related_fields: List[str] = []
    annotations: Dict[str, Any] = {}
    
    def get_queryset(self, request) -> QuerySet:
        """Apply optimizations to queryset."""
```

**Attributes**:
- `select_related_fields`: List of fields for automatic `select_related()`
- `annotations`: Dict of annotations to apply to queryset

### DisplayMixin

**Location**: `django_cfg.modules.django_admin.mixins.display_mixin`

```python
class DisplayMixin:
    """Utility methods for display functions."""
```

#### User Display Methods

```python
def display_user_with_avatar(
    self, 
    obj: Any, 
    user_field: str = 'user', 
    config: Optional[UserDisplayConfig] = None
) -> List[str]:
    """Display user with avatar for @display(header=True)."""

def display_user_simple(
    self, 
    obj: Any, 
    user_field: str = 'user', 
    config: Optional[UserDisplayConfig] = None
) -> str:
    """Simple user display without avatar."""
```

#### Money Display Methods

```python
def display_money_amount(
    self, 
    obj: Any, 
    amount_field: str, 
    config: Optional[MoneyDisplayConfig] = None
) -> str:
    """Display money amount with currency formatting."""
```

#### Status Display Methods

```python
def display_status_auto(
    self, 
    obj: Any, 
    status_field: str = 'status', 
    config: Optional[StatusBadgeConfig] = None
) -> str:
    """Display status with automatic color mapping."""
```

#### DateTime Display Methods

```python
def display_datetime_relative(
    self, 
    obj: Any, 
    datetime_field: str, 
    config: Optional[DateTimeDisplayConfig] = None
) -> str:
    """Display datetime with relative time."""

def display_datetime_compact(
    self, 
    obj: Any, 
    datetime_field: str, 
    config: Optional[DateTimeDisplayConfig] = None
) -> str:
    """Display datetime in compact format."""
```

#### Count Display Methods

```python
def display_count_simple(
    self, 
    obj: Any, 
    count_field: str, 
    label: Optional[str] = None
) -> str:
    """Display count as badge."""

def display_related_count(
    self, 
    obj: Any, 
    related_name: str, 
    label: Optional[str] = None
) -> str:
    """Display count of related objects."""
```

## 🎨 Decorators

### @display

**Location**: `django_cfg.modules.django_admin.decorators.display`

```python
def display(
    description: Optional[str] = None,
    ordering: Optional[str] = None,
    empty_value: Optional[str] = "—",
    boolean: Optional[bool] = None,
    admin_order_field: Optional[str] = None,
    header: Optional[bool] = None,
    label: Optional[bool] = None
) -> Callable:
    """Enhanced display decorator with error handling and HTML safety."""
```

**Parameters**:
- `description`: Column header text
- `ordering`: Field name for sorting
- `empty_value`: Value to show for None/empty results
- `boolean`: Display as boolean icon
- `admin_order_field`: Django admin ordering field
- `header`: Enable unfold header display (returns list)
- `label`: Enable unfold label display (badge styling)

**Features**:
- Automatic error handling and logging
- HTML safety (auto `mark_safe` for HTML strings)
- Empty value handling
- Full unfold integration

### @action

**Location**: `django_cfg.modules.django_admin.decorators.actions`

```python
def action(
    description: str,
    variant: Optional[ActionVariant] = None,
    icon: Optional[str] = None,
    permissions: Optional[list] = None
) -> Callable:
    """Type-safe action decorator with error handling."""
```

**Parameters**:
- `description`: Action description text
- `variant`: ActionVariant enum value for styling
- `icon`: Material Design icon name
- `permissions`: List of required permissions

**Features**:
- Type-safe ActionVariant enum
- Automatic error handling and logging
- User-friendly error messages
- Full unfold integration

## 🔧 Configuration Models

### StatusBadgeConfig

**Location**: `django_cfg.modules.django_admin.models.badge_models`

```python
class StatusBadgeConfig(BaseConfig):
    """Status badge configuration."""
    
    custom_mappings: Dict[str, str] = Field(default_factory=dict)
    show_icons: bool = Field(default=False)
    icon: Optional[str] = Field(default=None)
    custom_css_classes: List[str] = Field(default_factory=list)
```

**Fields**:
- `custom_mappings`: Dict mapping status values to badge variants
- `show_icons`: Whether to show icons in badges
- `icon`: Specific icon to use (overrides auto-selection)
- `custom_css_classes`: Additional CSS classes

### MoneyDisplayConfig

**Location**: `django_cfg.modules.django_admin.models.display_models`

```python
class MoneyDisplayConfig(BaseConfig):
    """Money display configuration."""
    
    currency: str = Field(default="USD")
    show_sign: bool = Field(default=False)
    decimal_places: int = Field(default=2)
    thousand_separator: bool = Field(default=False)
```

**Fields**:
- `currency`: Currency code (USD, EUR, etc.)
- `show_sign`: Show +/- sign for positive/negative amounts
- `decimal_places`: Number of decimal places
- `thousand_separator`: Use thousand separators (1,000.00)

### UserDisplayConfig

**Location**: `django_cfg.modules.django_admin.models.display_models`

```python
class UserDisplayConfig(BaseConfig):
    """User display configuration."""
    
    show_email: bool = Field(default=True)
    show_avatar: bool = Field(default=True)
    avatar_size: int = Field(default=32)
    fallback_initials: bool = Field(default=True)
```

**Fields**:
- `show_email`: Include email in display
- `show_avatar`: Show user avatar
- `avatar_size`: Avatar size in pixels
- `fallback_initials`: Show initials if no avatar

### DateTimeDisplayConfig

**Location**: `django_cfg.modules.django_admin.models.display_models`

```python
class DateTimeDisplayConfig(BaseConfig):
    """DateTime display configuration."""
    
    show_relative: bool = Field(default=True)
    show_seconds: bool = Field(default=False)
    datetime_format: str = Field(default="%Y-%m-%d %H:%M:%S")
```

**Fields**:
- `show_relative`: Show relative time ("2 hours ago")
- `show_seconds`: Include seconds in display
- `datetime_format`: Fallback datetime format string

## 🎯 Enums

### ActionVariant

**Location**: `django_cfg.modules.django_admin.models.action_models`

```python
class ActionVariant(str, Enum):
    """Action variant enum for consistent styling."""
    
    DEFAULT = "default"    # Gray/neutral
    PRIMARY = "primary"    # Blue/primary
    SUCCESS = "success"    # Green/success
    INFO = "info"         # Light blue/info
    WARNING = "warning"   # Yellow/warning
    DANGER = "danger"     # Red/danger
```

## 🎨 Utility Classes

### StatusBadge

**Location**: `django_cfg.modules.django_admin.utils.badges`

```python
class StatusBadge:
    """Status badge utility class."""
    
    @staticmethod
    def auto(status: str, config: Optional[StatusBadgeConfig] = None) -> str:
        """Create badge with automatic color mapping."""
    
    @staticmethod
    def create(
        text: str, 
        variant: str, 
        config: Optional[StatusBadgeConfig] = None
    ) -> str:
        """Create custom badge."""
```

### MoneyDisplay

**Location**: `django_cfg.modules.django_admin.utils.displays`

```python
class MoneyDisplay:
    """Money display utility class."""
    
    @staticmethod
    def amount(
        amount: Optional[Decimal], 
        config: Optional[MoneyDisplayConfig] = None
    ) -> str:
        """Format money amount."""
```

### UserDisplay

**Location**: `django_cfg.modules.django_admin.utils.displays`

```python
class UserDisplay:
    """User display utility class."""
    
    @staticmethod
    def with_avatar(
        user: Optional[Any], 
        config: Optional[UserDisplayConfig] = None
    ) -> List[str]:
        """Display user with avatar (for header=True)."""
    
    @staticmethod
    def simple(
        user: Optional[Any], 
        config: Optional[UserDisplayConfig] = None
    ) -> str:
        """Simple user display."""
```

## 🔍 Icons

### Icons Class

**Location**: `django_cfg.modules.django_admin.icons.constants`

```python
class Icons:
    """Material Design Icons constants."""
    
    # Common icons
    CHECK_CIRCLE = "check_circle"
    WARNING = "warning"
    ERROR = "error"
    INFO = "info"
    STAR = "star"
    PERSON = "person"
    PAYMENT = "payment"
    DOWNLOAD = "download"
    UPLOAD = "upload"
    EDIT = "edit"
    DELETE = "delete"
    ADD = "add"
    REMOVE = "remove"
    SEARCH = "search"
    FILTER = "filter_list"
    SORT = "sort"
    VISIBILITY = "visibility"
    VISIBILITY_OFF = "visibility_off"
    LOCK = "lock"
    LOCK_OPEN = "lock_open"
    SETTINGS = "settings"
    HOME = "home"
    DASHBOARD = "dashboard"
    ANALYTICS = "analytics"
    NOTIFICATIONS = "notifications"
    EMAIL = "email"
    PHONE = "phone"
    LOCATION = "location_on"
    CALENDAR = "calendar_today"
    CLOCK = "access_time"
    # ... 2000+ more icons
```

## 🏗️ Usage Examples

### Complete Admin Example

```python
from django.contrib import admin
from unfold.admin import ModelAdmin
from django_cfg.modules.django_admin import (
    OptimizedModelAdmin,
    DisplayMixin,
    StatusBadgeConfig,
    MoneyDisplayConfig,
    UserDisplayConfig,
    DateTimeDisplayConfig,
    Icons,
    ActionVariant,
    display,
    action
)

@admin.register(Order)
class OrderAdmin(OptimizedModelAdmin, DisplayMixin, ModelAdmin):
    """Complete example showing all API components."""
    
    # Performance optimization
    select_related_fields = ['user', 'payment_method']
    annotations = {'items_count': Count('items')}
    
    # List configuration
    list_display = [
        'order_number_display',
        'customer_display',
        'total_display',
        'status_display',
        'created_display'
    ]
    
    # Display methods
    @display(description="Order #", ordering="order_number")
    def order_number_display(self, obj: Order) -> str:
        return f"#{obj.order_number}"
    
    @display(description="Customer", header=True)
    def customer_display(self, obj: Order) -> List[str]:
        config = UserDisplayConfig(show_email=True, avatar_size=32)
        return self.display_user_with_avatar(obj, 'user', config)
    
    @display(description="Total")
    def total_display(self, obj: Order) -> str:
        config = MoneyDisplayConfig(
            currency="USD",
            thousand_separator=True
        )
        return self.display_money_amount(obj, 'total_amount', config)
    
    @display(description="Status", label=True)
    def status_display(self, obj: Order) -> str:
        config = StatusBadgeConfig(
            custom_mappings={
                'pending': 'warning',
                'processing': 'info',
                'completed': 'success',
                'cancelled': 'danger'
            },
            show_icons=True,
            icon=Icons.SHOPPING_CART
        )
        return self.display_status_auto(obj, 'status', config)
    
    @display(description="Created")
    def created_display(self, obj: Order) -> str:
        config = DateTimeDisplayConfig(show_relative=True)
        return self.display_datetime_relative(obj, 'created_at', config)
    
    # Actions
    @action(
        description="Mark as completed",
        variant=ActionVariant.SUCCESS,
        icon=Icons.CHECK_CIRCLE
    )
    def mark_completed(self, request, queryset):
        updated = queryset.update(status='completed')
        self.message_user(
            request,
            f"Marked {updated} orders as completed.",
            messages.SUCCESS
        )
    
    @action(
        description="Export orders",
        variant=ActionVariant.INFO,
        icon=Icons.DOWNLOAD
    )
    def export_orders(self, request, queryset):
        # Export logic here
        pass
```

## 🏷️ Import Paths

### Main Imports

```python
# Core components
from django_cfg.modules.django_admin import (
    OptimizedModelAdmin,
    DisplayMixin,
    display,
    action,
    ActionVariant
)

# Configuration models
from django_cfg.modules.django_admin import (
    StatusBadgeConfig,
    MoneyDisplayConfig,
    UserDisplayConfig,
    DateTimeDisplayConfig
)

# Icons
from django_cfg.modules.django_admin import Icons

# Utility classes (if needed directly)
from django_cfg.modules.django_admin.utils.badges import StatusBadge
from django_cfg.modules.django_admin.utils.displays import (
    MoneyDisplay,
    UserDisplay
)
```

### Unfold Integration

```python
# Always use unfold.admin.ModelAdmin
from unfold.admin import ModelAdmin

# Never import unfold decorators directly
# from unfold.decorators import display, action  # ❌ DON'T
# Use our decorators instead:
from django_cfg.modules.django_admin import display, action  # ✅ DO
```

## 🏷️ Metadata
**Tags**: `api-reference, documentation, types, methods, classes`
**Status**: %%ACTIVE%%
**Complexity**: %%REFERENCE%%
**Dependencies**: [unfold, pydantic>=2.0]
