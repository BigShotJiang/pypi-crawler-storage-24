# 🔄 Django-CFG Background Tasks Guide %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Dramatiq background tasks** integration with Redis broker (DB 2)
- **App-specific queue naming** and task organization patterns
- **Auto-activation** based on app dependencies (knowbase, agents, payments)
- **Real examples** from knowbase document processing and external data tasks

## 📋 Table of Contents
1. [Task System Architecture](#task-system-architecture)
2. [Real Task Examples](#real-task-examples)
3. [Queue Naming Conventions](#queue-naming-conventions)
4. [Task Definition Patterns](#task-definition-patterns)
5. [Auto-Activation Logic](#auto-activation-logic)

## 🔑 Key Concepts at a Glance
- **Dramatiq Integration**: Background task processing with Redis broker
- **App-Specific Queues**: Each app has its own queue namespace
- **Auto-Activation**: Tasks enabled automatically when required by apps
- **Type Safety**: Pydantic models for task parameters and results
- **Retry Logic**: Configurable retry policies with exponential backoff
- **Queue Separation**: Different queues for different task types

## 🚀 Quick Start

### Basic Task Definition
```python
# tasks/my_tasks.py - Basic task definition
import dramatiq
from typing import Dict, Any

@dramatiq.actor(
    queue_name="myapp",  # App-specific queue
    max_retries=3,
    min_backoff=1000,    # 1 second
    max_backoff=30000,   # 30 seconds
    priority=5
)
def process_data_async(data_id: str) -> Dict[str, Any]:
    """Process data asynchronously."""
    # Task implementation
    return {"status": "completed", "data_id": data_id}
```

## 🏗️ Task System Architecture

### 1. **Django-CFG Task Activation Logic (Real Implementation)**
```python
# core/config.py - Auto-activation conditions
def should_enable_tasks(self) -> bool:
    """
    Determine if background tasks should be enabled.
    
    Tasks are enabled if:
    1. Explicitly configured via tasks field
    2. Knowledge base is enabled (requires background processing)
    3. Agents are enabled (requires background processing)
    4. Payments app requires tasks (webhook processing, etc.)
    """
    # Check if explicitly configured
    if hasattr(self, 'tasks') and self.tasks and self.tasks.enabled:
        return True
    
    # Check if features that require tasks are enabled
    if self.enable_knowbase or self.enable_agents:
        return True
    
    # Check if payments module requires tasks
    if self.payments and self.payments.should_enable_tasks():
        return True
    
    return False
```

### 2. **Redis Database Layout (Real Configuration)**
```python
# Real configuration from django-cfg tasks
DB 0: Django cache (default)
DB 1: Sessions, general cache
DB 2: Dramatiq queues %%PRIORITY:HIGH%%

# Always use DB=2 for Dramatiq to avoid conflicts
```

### 3. **App Registration Flow (Real Implementation)**
```python
# core/config.py - App registration with task dependencies
def get_installed_apps(self) -> List[str]:
    """Get complete list of installed Django apps."""
    apps = DEFAULT_APPS.copy()
    
    # Add django-cfg apps
    if self.enable_knowbase:
        apps.append("django_cfg.apps.knowbase")
    if self.enable_agents:
        apps.append("django_cfg.apps.agents")
    if self.payments and self.payments.enabled:
        apps.append("django_cfg.apps.payments")
    
    # Auto-enable tasks if needed
    if self.should_enable_tasks():
        apps.append("django_dramatiq")  # Add django_dramatiq first
        apps.append("django_cfg.apps.tasks")
    
    return apps
```

## 🔍 Real Task Examples

### 1. **Knowbase Document Processing (Real Implementation)**
```python
# knowbase/tasks/external_data_tasks.py - Real implementation
import dramatiq
import time
from typing import Dict, Any
from django.db import transaction
from django.utils import timezone

from django_cfg.modules.django_logger import get_logger
from ..models import ExternalData
from ..services import ExternalDataService

logger = get_logger(__name__)

@dramatiq.actor(
    queue_name="knowledge",  # Dedicated queue for knowledge processing
    max_retries=3,
    min_backoff=2000,  # 2 seconds
    max_backoff=60000,  # 1 minute
    priority=6  # Higher priority for user-facing operations
)
def process_external_data_async(
    external_data_id: str,
    force_reprocess: bool = False
) -> Dict[str, Any]:
    """
    Process External Data asynchronously with full pipeline.
    
    Args:
        external_data_id: ExternalData UUID to process
        force_reprocess: Force reprocessing even if already processed
        
    Returns:
        Processing results with statistics
    """
    start_time = time.time()
    
    try:
        with transaction.atomic():
            # Get external data
            external_data = ExternalData.objects.get(id=external_data_id)
            
            # Update status
            external_data.processing_status = "processing"
            external_data.processing_started_at = timezone.now()
            external_data.save(update_fields=[
                'processing_status', 'processing_started_at', 'updated_at'
            ])
            
            # Process with service layer
            service = ExternalDataService(user=external_data.user)
            result = service.process_external_data(
                external_data, 
                force_reprocess=force_reprocess
            )
            
            # Update completion status
            external_data.processing_status = "completed"
            external_data.processing_completed_at = timezone.now()
            external_data.chunks_count = result.get('chunks_created', 0)
            external_data.save(update_fields=[
                'processing_status', 'processing_completed_at', 
                'chunks_count', 'updated_at'
            ])
            
            processing_time = time.time() - start_time
            
            logger.info(f"External data processed successfully", extra={
                'external_data_id': external_data_id,
                'chunks_created': result.get('chunks_created', 0),
                'processing_time_seconds': round(processing_time, 2)
            })
            
            return {
                'status': 'completed',
                'external_data_id': external_data_id,
                'chunks_created': result.get('chunks_created', 0),
                'processing_time_seconds': round(processing_time, 2),
                'embeddings_generated': result.get('embeddings_generated', 0)
            }
            
    except ExternalData.DoesNotExist:
        logger.error(f"External data not found: {external_data_id}")
        return {
            'status': 'error',
            'error': 'External data not found',
            'external_data_id': external_data_id
        }
        
    except Exception as e:
        logger.error(f"External data processing failed", extra={
            'external_data_id': external_data_id,
            'error': str(e)
        })
        
        # Update error status
        try:
            external_data.processing_status = "failed"
            external_data.error_message = str(e)
            external_data.save(update_fields=[
                'processing_status', 'error_message', 'updated_at'
            ])
        except:
            pass
        
        raise  # Re-raise for Dramatiq retry logic
```

### 2. **Batch Processing Task (Real Implementation)**
```python
# knowbase/tasks/external_data_tasks.py - Real implementation
@dramatiq.actor(
    queue_name="knowledge",
    max_retries=2,
    min_backoff=5000,  # 5 seconds
    max_backoff=120000,  # 2 minutes
    priority=4  # Lower priority for batch operations
)
def bulk_process_external_data_async(
    external_data_ids: List[str],
    force_reprocess: bool = False
) -> Dict[str, Any]:
    """
    Process multiple External Data items in batch.
    
    Args:
        external_data_ids: List of ExternalData UUIDs
        force_reprocess: Force reprocessing
        
    Returns:
        Batch processing results
    """
    start_time = time.time()
    results = {
        'processed': 0,
        'failed': 0,
        'errors': [],
        'total': len(external_data_ids)
    }
    
    for external_data_id in external_data_ids:
        try:
            # Process individual item
            result = process_external_data_async.send_with_options(
                args=(external_data_id, force_reprocess),
                delay=0  # Process immediately
            )
            
            results['processed'] += 1
            logger.debug(f"Queued processing for {external_data_id}")
            
        except Exception as e:
            results['failed'] += 1
            results['errors'].append({
                'external_data_id': external_data_id,
                'error': str(e)
            })
            logger.error(f"Failed to queue processing for {external_data_id}: {e}")
    
    processing_time = time.time() - start_time
    
    logger.info(f"Bulk processing queued", extra={
        'total_items': results['total'],
        'processed': results['processed'],
        'failed': results['failed'],
        'processing_time_seconds': round(processing_time, 2)
    })
    
    return results
```

### 3. **Maintenance Task (Real Implementation)**
```python
# knowbase/tasks/external_data_tasks.py - Real implementation
@dramatiq.actor(
    queue_name="low",  # Low priority queue for maintenance
    max_retries=1,
    priority=2
)
def cleanup_failed_external_data_async() -> Dict[str, Any]:
    """
    Cleanup failed External Data processing attempts.
    
    Returns:
        Cleanup results
    """
    from django.utils import timezone
    from datetime import timedelta
    
    cutoff_date = timezone.now() - timedelta(days=7)  # 7 days old
    
    try:
        # Find failed external data older than cutoff
        failed_external_data = ExternalData.objects.filter(
            processing_status='failed',
            updated_at__lt=cutoff_date
        )
        
        cleanup_count = 0
        for external_data in failed_external_data:
            # Reset for retry
            external_data.processing_status = 'pending'
            external_data.error_message = None
            external_data.save(update_fields=[
                'processing_status', 'error_message', 'updated_at'
            ])
            cleanup_count += 1
        
        logger.info(f"Cleaned up {cleanup_count} failed external data items")
        
        return {
            'status': 'completed',
            'cleaned_up': cleanup_count,
            'cutoff_date': cutoff_date.isoformat()
        }
        
    except Exception as e:
        logger.error(f"Cleanup failed: {e}")
        return {
            'status': 'error',
            'error': str(e)
        }
```

## 🏷️ Queue Naming Conventions

### 1. **App-Specific Queue Names (Real Configuration)**
```python
# Real queue names from django-cfg tasks
QUEUE_NAMES = {
    "knowledge": "knowledge",    # Knowledge base processing
    "agents": "agents",          # AI agent tasks
    "payments": "payments",      # Payment processing
    "maintenance": "maintenance", # System maintenance
    "default": "default",        # Generic tasks
    "high": "high",             # Priority tasks
    "low": "low",               # Background tasks
    "vehicles": "vehicles",      # Vehicle data processing
    "tax": "tax",               # Tax calculations
    "parsing": "parsing",        # Data parsing tasks
}

# ✅ CORRECT: App-specific queue usage
@dramatiq.actor(queue_name="knowledge")
def process_document_async(document_id: str):
    """Process document in knowledge queue."""
    pass

@dramatiq.actor(queue_name="payments")
def process_payment_webhook(payment_id: str):
    """Process payment webhook in payments queue."""
    pass

@dramatiq.actor(queue_name="low")
def cleanup_old_data():
    """Cleanup task in low priority queue."""
    pass
```

### 2. **Queue Priority and Configuration (Real Implementation)**
```python
# Real configuration from django-cfg tasks
TASK_PRIORITIES = {
    "critical": 10,    # Payment processing, security
    "high": 8,         # User-facing operations
    "normal": 6,       # Document processing
    "background": 4,   # Batch operations
    "low": 2,          # Maintenance, cleanup
    "bulk": 1,         # Bulk operations
}

# Queue-specific configurations
QUEUE_CONFIGS = {
    "knowledge": {
        "default_priority": 6,
        "max_retries": 3,
        "backoff_strategy": "exponential"
    },
    "payments": {
        "default_priority": 8,  # Higher priority for payments
        "max_retries": 5,
        "backoff_strategy": "exponential"
    },
    "low": {
        "default_priority": 2,  # Lower priority for maintenance
        "max_retries": 1,
        "backoff_strategy": "linear"
    }
}
```

## 📝 Task Definition Patterns

### 1. **Standard Task Pattern (Real Implementation)**
```python
# Real pattern from knowbase tasks
import dramatiq
import logging
from typing import Dict, Any, Optional
from django.db import transaction

logger = logging.getLogger(__name__)

@dramatiq.actor(
    queue_name="knowledge",
    max_retries=3,
    min_backoff=1000,  # 1 second
    max_backoff=30000,  # 30 seconds
    priority=6
)
def process_document_async(
    document_id: str,
    chunk_size: Optional[int] = None,
    embedding_model: Optional[str] = None
) -> Dict[str, Any]:
    """
    Process document asynchronously with full pipeline.
    
    Args:
        document_id: Document UUID to process
        chunk_size: Maximum chunk size in characters
        embedding_model: Model to use for embeddings
        
    Returns:
        Processing results with statistics
    """
    start_time = time.time()
    
    try:
        with transaction.atomic():
            # Get document
            from ..models import Document
            document = Document.objects.get(id=document_id)
            
            # Update status
            document.processing_status = "processing"
            document.save(update_fields=['processing_status'])
            
            # Process document
            result = _process_document_pipeline(document, chunk_size, embedding_model)
            
            # Update completion status
            document.processing_status = "completed"
            document.processed_at = timezone.now()
            document.save(update_fields=['processing_status', 'processed_at'])
            
            logger.info(f"Document {document_id} processed successfully")
            return result
            
    except Exception as e:
        logger.error(f"Document processing failed for {document_id}: {e}")
        
        # Update error status
        try:
            document.processing_status = "failed"
            document.error_message = str(e)
            document.save(update_fields=['processing_status', 'error_message'])
        except:
            pass
        
        raise  # Re-raise for Dramatiq retry logic
```

### 2. **Error Handling and Monitoring (Real Implementation)**
```python
# Real pattern from knowbase tasks
@dramatiq.actor(
    queue_name="knowledge",
    max_retries=5,
    min_backoff=2000,   # 2 seconds
    max_backoff=60000,  # 1 minute
    priority=8          # High priority for critical operations
)
def process_critical_task(task_data: Dict[str, Any]) -> Dict[str, Any]:
    """Process critical task with comprehensive error handling."""
    task_id = task_data.get('id', 'unknown')
    
    try:
        # Validate task data
        from ..services.types import TaskValidationRequest
        validated_data = TaskValidationRequest(**task_data)
        
        # Process task
        from ..services.task_service import TaskService
        service = TaskService()
        result = service.process_task(validated_data)
        
        logger.info(f"Task {task_id} processed successfully")
        return result.model_dump()
        
    except ValidationError as e:
        logger.error(f"Task validation failed for {task_id}: {e}")
        # Don't retry validation errors
        raise dramatiq.middleware.SkipMessage()
        
    except Exception as e:
        logger.error(f"Task processing failed for {task_id}: {e}")
        
        # Log attempt count for monitoring
        current_message = dramatiq.get_current_message()
        if current_message:
            attempt = current_message.options.get('retries', 0) + 1
            logger.warning(f"Task {task_id} retry attempt {attempt}/5")
        
        raise  # Allow Dramatiq to handle retries
```

## ⚙️ Auto-Activation Logic

### 1. **Task Module Structure (Real Implementation)**
```python
# knowbase/tasks/__init__.py - Real implementation
"""
Knowbase Background Tasks

Dramatiq tasks for document and external data processing.
"""

from .external_data_tasks import (
    process_external_data_async,
    bulk_process_external_data_async,
    cleanup_failed_external_data_async
)

from .document_tasks import (
    process_document_async,
    generate_embeddings_batch,
    reprocess_document_chunks
)

__all__ = [
    # External data processing
    'process_external_data_async',
    'bulk_process_external_data_async',
    'cleanup_failed_external_data_async',
    
    # Document processing
    'process_document_async',
    'generate_embeddings_batch',
    'reprocess_document_chunks',
]
```

### 2. **Dramatiq Configuration Integration (Real Implementation)**
```python
# Real configuration from django-cfg tasks
tasks: Optional[TaskConfig] = TaskConfig(
    enabled=True,
    dramatiq=DramatiqConfig(
        redis_db=2,  # Separate Redis DB for tasks
        processes=2 if debug else 6,
        threads=4 if debug else 8,
        queues=[
            "default", "high", "low", 
            "vehicles", "tax", "parsing", 
            "knowledge"  # Knowbase queue
        ],
        max_retries=3,
        default_priority=5,
        prometheus_enabled=not debug,
        admin_enabled=True,
    ),
)
```

### 3. **Production Deployment (Real Configuration)**
```bash
# Real deployment commands from django-cfg
# Start workers for specific queues
dramatiq django_cfg.apps.knowbase.tasks --processes 2 --threads 4 --queues knowledge
dramatiq django_cfg.apps.payments.tasks --processes 3 --threads 2 --queues payments
dramatiq django_cfg.apps.tasks --processes 1 --threads 2 --queues low

# Development mode (single process)
poetry run python manage.py rundramatiq --processes 1 --threads 2

# With specific queues
poetry run python manage.py rundramatiq --queues knowledge --queues high
```

## 🏷️ Metadata
**Tags**: `tasks, dramatiq, queues, background-processing, async, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Real Examples**: Knowbase document processing, External data tasks from django-cfg
**DEPENDS_ON**: [dramatiq, redis, django-cfg-core]
**USED_BY**: [knowbase, agents, payments, maintenance]
