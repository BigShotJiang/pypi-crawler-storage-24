# 📏 Django-CFG Coding Standards

## 🎯 File Size Limits

### Production Code
- **Maximum 500 lines** per file (excluding comments and docstrings)
- **Maximum 300 lines** for complex logic files (models, services, managers)
- **Maximum 200 lines** for configuration files

### Test Code
- **Maximum 400 lines** per test file
- **Maximum 150 lines** per test class
- **Split by functionality**, not by file structure

## 🚫 Import Rules

### Strict No Inline Imports Policy
```python
# ❌ FORBIDDEN - Inline imports
def process_payment():
    from django_cfg.apps.payments.models import Payment  # NO!
    return Payment.objects.create()

# ✅ REQUIRED - All imports at top
from django_cfg.apps.payments.models import Payment

def process_payment():
    return Payment.objects.create()
```

### Exceptions (Rare Cases Only)
- **Circular import resolution** - when two modules need each other
- **Optional dependencies** - when import might fail
- **Performance-critical lazy loading** - documented performance requirement

```python
# ✅ Exception - Circular import resolution
def get_payment_processor():
    from django_cfg.apps.payments.processors import PaymentProcessor  # OK - circular import
    return PaymentProcessor()

# ✅ Exception - Optional dependency
def send_notification():
    try:
        from django_cfg.modules.django_telegram import send_message  # OK - optional
        send_message("Payment processed")
    except ImportError:
        pass  # Telegram not configured
```

### Import Grouping
```python
# 1. Standard library imports
import os
import sys
from typing import Dict, List, Optional

# 2. Third-party imports
from django.db import models
from django.contrib.auth import get_user_model

# 3. Local application imports
from django_cfg.apps.payments.models import Currency
from django_cfg.apps.payments.services.cache_service import CacheService
```

## 🧪 Test Organization

### Test File Structure
```
tests/
├── models/
│   ├── test_payment_models.py      # 120 lines - Payment model tests
│   ├── test_balance_models.py      # 95 lines - Balance model tests
│   └── test_currency_models.py     # 78 lines - Currency model tests
├── services/
│   ├── test_payment_service.py     # 145 lines - Payment service tests
│   └── test_cache_service.py       # 380 lines - Cache service tests
└── views/
    └── test_payment_api.py         # 200 lines - API endpoint tests
```

### Test Class Organization
```python
# ✅ Good - Focused test classes
class UserBalanceManagerTest(TestCase):  # 45 lines
    """Test user balance operations."""
    
class PaymentManagerTest(TestCase):      # 67 lines  
    """Test payment processing."""

class CurrencyManagerTest(TestCase):     # 38 lines
    """Test currency operations."""

# ❌ Bad - Monolithic test class
class PaymentSystemTest(TestCase):       # 300+ lines
    """Test everything payment-related."""
```

## 🔄 Decomposition Process

### When to Decompose
1. **File exceeds size limits** (500 lines code, 400 lines tests)
2. **Multiple responsibilities** in single file
3. **Hard to navigate** or understand

### How to Decompose
1. **Create package directory** with same name as original file
2. **Split into logical components** based on functionality
3. **Create `__init__.py`** as main entry point
4. **Delete original file** to avoid naming conflicts
5. **Update all imports** to use new package structure

### Example: Cache Service Decomposition
```
# Before (236 lines)
cache_service.py

# After (5 files, each <100 lines)
cache_service/
├── __init__.py          # 67 lines - Main service + exports
├── interfaces.py        # 28 lines - Abstract interfaces  
├── simple_cache.py      # 89 lines - Basic implementation
├── api_key_cache.py     # 32 lines - API key cache
├── rate_limit_cache.py  # 42 lines - Rate limiting
└── keys.py             # 38 lines - Key generators
```

## 📋 Quality Checklist

### Before Writing Code
- [ ] File will be under size limits
- [ ] Single responsibility principle followed
- [ ] Clear, descriptive naming chosen
- [ ] All imports planned at top of file (no inline imports)

### During Development
- [ ] Logical grouping of related functions
- [ ] Comprehensive docstrings added
- [ ] Type hints provided where applicable
- [ ] Imports properly grouped (stdlib, third-party, local)

### After Implementation
- [ ] File size checked (split if needed)
- [ ] Import paths verified (no inline imports)
- [ ] Documentation updated
- [ ] Tests cover new functionality

### For Tests Specifically
- [ ] Test file under 400 lines
- [ ] Test classes focused and under 150 lines
- [ ] Tests split by functionality, not file structure
- [ ] Clear test naming (test_specific_behavior)
- [ ] No inline imports in test files

## 🚀 Benefits for LLM Agents

### Improved Navigation
- **Clear file purposes** - LLM can quickly understand what each file does
- **Logical grouping** - Related functionality is co-located
- **Predictable structure** - Consistent patterns across the codebase

### Better Context Understanding
- **Self-documenting names** - Reduce need for extensive code analysis
- **Focused files** - Each file has single, clear responsibility
- **Explicit dependencies** - Import structure shows relationships

### Efficient Code Generation
- **Template patterns** - Consistent structure enables pattern reuse
- **Modular approach** - Easy to extend without affecting other components
- **Clear interfaces** - Well-defined contracts between components

---

**Remember**: These standards ensure our codebase remains maintainable, navigable, and LLM-friendly as it grows! 🏆
