# 🎨 Django-CFG Admin Interface Guide %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Django Unfold** modern admin interface with Material Design
- **Type-safe configuration** with Pydantic 2 models for all admin settings
- **Import/Export functionality** with django-import-export integration
- **Custom actions and buttons** with Unfold decorators and styling
- **Real examples** from accounts, agents, leads, maintenance, and support apps

## 📋 Table of Contents
1. [Unfold Configuration](#unfold-configuration)
2. [Real Admin Examples](#real-admin-examples)
3. [Import/Export Integration](#importexport-integration)
4. [Custom Actions & Buttons](#custom-actions--buttons)
5. [Fieldsets & Display](#fieldsets--display)

## 🔑 Key Concepts at a Glance
- **Django Unfold**: Modern admin interface with Material Design
- **ModelAdmin**: Base admin class with Unfold styling
- **ImportExportModelAdmin**: Combined admin with import/export functionality
- **Custom Actions**: Unfold decorators for action buttons and bulk operations
- **Type-Safe Config**: Pydantic 2 models for all admin configuration

## 🚀 Quick Start

### Basic Unfold Admin (Real Example from Leads)
```python
from django.contrib import admin
from unfold.admin import ModelAdmin
from django_cfg import ImportExportModelAdmin, ImportForm, ExportForm
from .models import Lead
from .resources import LeadResource

@admin.register(Lead)
class LeadAdmin(ModelAdmin, ImportExportModelAdmin):
    # Import/Export configuration
    resource_class = LeadResource
    import_form_class = ImportForm
    export_form_class = ExportForm
    
    list_display = [
        'name', 'email', 'company', 'contact_type', 'contact_value',
        'subject', 'status_display', 'created_at'
    ]
    list_display_links = ['name', 'email']
    list_filter = ['status', 'contact_type', 'company', 'created_at']
    search_fields = ['name', 'email', 'company', 'message', 'subject']
    readonly_fields = ['created_at', 'updated_at', 'ip_address', 'user_agent']
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'email', 'company', 'company_site')
        }),
        ('Contact Information', {
            'fields': ('contact_type', 'contact_value')
        }),
        ('Message', {
            'fields': ('subject', 'message', 'extra')
        }),
        ('Status and Processing', {
            'fields': ('status', 'user', 'admin_notes')
        }),
    )
```

## ⚙️ Unfold Configuration

### 1. **Type-Safe Unfold Configuration**
```python
# Real configuration from django-cfg core
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any

class UnfoldConfig(BaseModel):
    """Complete Unfold configuration with type safety."""
    
    # Site branding
    site_title: str = Field(
        default="ConfigToolkit Admin",
        description="Site title shown in admin"
    )
    
    site_header: str = Field(
        default="Django Config Toolkit",
        description="Site header text"
    )
    
    site_subheader: str = Field(
        default="🚀 Type-safe Django Configuration",
        description="Site subheader text"
    )
    
    site_symbol: str = Field(
        default="settings",
        description="Material icon symbol for site"
    )
    
    # UI settings
    show_history: bool = Field(default=True, description="Show history in admin")
    show_view_on_site: bool = Field(default=True, description="Show 'View on site' links")
    show_back_button: bool = Field(default=False, description="Show back button in admin")
    
    # Theme settings
    theme: Optional[str] = Field(default=None, description="Theme setting (light/dark/auto)")
    border_radius: str = Field(default="8px", description="Border radius for UI elements")
    
    # Dashboard settings
    dashboard_enabled: bool = Field(default=True, description="Enable custom dashboard")
    dashboard_callback: Optional[str] = Field(
        default="django_cfg.routing.callbacks.dashboard_callback",
        description="Dashboard callback function path"
    )
    
    def to_django_settings(self) -> Dict[str, Any]:
        """Generate Django settings for Unfold."""
        unfold_settings = {
            "SITE_TITLE": self.site_title,
            "SITE_HEADER": self.site_header,
            "SITE_SUBHEADER": self.site_subheader,
            "SITE_URL": self.site_url,
            "SITE_SYMBOL": self.site_symbol,
            "SHOW_HISTORY": self.show_history,
            "SHOW_VIEW_ON_SITE": self.show_view_on_site,
            "SHOW_BACK_BUTTON": self.show_back_button,
            "THEME": self.theme,
            "BORDER_RADIUS": self.border_radius,
            "COLORS": self.get_color_scheme(),
        }
        
        # Add callbacks if configured
        if self.dashboard_callback:
            unfold_settings["DASHBOARD_CALLBACK"] = self.dashboard_callback
        
        return {"UNFOLD": unfold_settings}
```

### 2. **Color Scheme Configuration**
```python
# Real color scheme from django-cfg
def get_color_scheme(self) -> Dict[str, Any]:
    """Get semantic color scheme for Unfold."""
    return {
        # Primary brand color (teal)
        "primary": {
            "50": "240, 253, 250",
            "100": "204, 251, 241", 
            "200": "153, 246, 228",
            "300": "94, 234, 212",
            "400": "45, 212, 191",
            "500": "20, 184, 166",    # Main primary color
            "600": "13, 148, 136",
            "700": "15, 118, 110", 
            "800": "17, 94, 89",
            "900": "19, 78, 74",
            "950": "4, 47, 46",
        },
        # Success semantic color
        "success": {
            "50": "240, 253, 244",
            "500": "34, 197, 94",    # Main success color
        },
        # Warning semantic color  
        "warning": {
            "50": "255, 251, 235",
            "500": "245, 158, 11",   # Main warning color
        },
        # Danger semantic color
        "danger": {
            "50": "254, 242, 242", 
            "500": "239, 68, 68",    # Main danger color
        },
    }
```

## 🔍 Real Admin Examples

### 1. **User Admin (Complex Example with Inlines)**
```python
# Real example from django-cfg accounts app
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.utils.html import format_html
from unfold.admin import ModelAdmin
from unfold.forms import AdminPasswordChangeForm, UserChangeForm, UserCreationForm
from django_cfg import ImportExportModelAdmin

@admin.register(CustomUser)
class CustomUserAdmin(BaseUserAdmin, ModelAdmin, ImportExportModelAdmin):
    # Import/Export configuration
    resource_class = CustomUserResource
    
    # Forms loaded from unfold.forms
    form = UserChangeForm
    add_form = UserCreationForm
    change_password_form = AdminPasswordChangeForm

    list_display = [
        "avatar",
        "email", 
        "full_name",
        "status",
        "sources_count",
        "activity_count",
        "emails_count",
        "tickets_count",
        "last_login_display",
        "date_joined_display",
    ]
    list_display_links = ["avatar", "email", "full_name"]
    search_fields = ["email", "first_name", "last_name"]
    list_filter = [UserStatusFilter, "is_staff", "is_active", "date_joined"]
    ordering = ["-date_joined"]
    readonly_fields = ["date_joined", "last_login"]
    
    def get_inlines(self, request, obj):
        """Get inlines based on enabled apps."""
        inlines = []
        
        # Always available inlines
        inlines.append(UserRegistrationSourceInline)
        inlines.append(UserActivityInline)
        
        # Conditional inlines based on enabled apps
        if self.is_newsletter_enabled():
            inlines.append(UserEmailLogInline)
        
        if self.is_support_enabled():
            inlines.append(UserSupportTicketsInline)
        
        return inlines
    
    @display(description="Avatar")
    def avatar(self, obj):
        """Display user avatar."""
        if obj.avatar:
            return format_html(
                '<img src="{}" width="32" height="32" style="border-radius: 50%;" />',
                obj.avatar.url
            )
        return format_html(
            '<div style="width: 32px; height: 32px; background: #e5e7eb; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; color: #6b7280;">{}</div>',
            obj.get_initials()
        )
```

### 2. **Maintenance Admin (Action Buttons Example)**
```python
# Real example from django-cfg maintenance app
@admin.register(CloudflareSite)
class CloudflareSiteAdmin(ModelAdmin):
    """Admin for CloudflareSite with Unfold styling and action buttons."""
    
    list_display = [
        'status_display',
        'name', 
        'domain',
        'subdomain_config_badge',
        'maintenance_badge',
        'active_badge',
        'last_maintenance_at',
        'logs_count',
        'action_buttons'
    ]
    
    list_display_links = ['name', 'domain']
    search_fields = ['name', 'domain', 'zone_id']
    list_filter = ['maintenance_active', 'is_active', 'created_at']
    readonly_fields = ['created_at', 'updated_at', 'last_maintenance_at', 'logs_preview']
    
    fieldsets = [
        ('Basic Information', {
            'fields': ['name', 'domain']
        }),
        ('Subdomain Configuration', {
            'fields': ['include_subdomains', 'subdomain_list'],
            'description': 'Configure which subdomains should be affected by maintenance mode'
        }),
        ('Cloudflare Configuration', {
            'fields': ['zone_id', 'account_id', 'api_key'],
            'classes': ['collapse']
        }),
        ('Status', {
            'fields': ['maintenance_active', 'maintenance_url', 'is_active']
        }),
    ]
    
    inlines = [MaintenanceLogInline]
    
    # Bulk actions
    actions = [
        'enable_maintenance_action',
        'disable_maintenance_action', 
        'sync_from_cloudflare_action'
    ]
    
    # Unfold action buttons
    actions_detail = [
        'sync_with_cloudflare_detail',
        'enable_maintenance_detail',
        'disable_maintenance_detail'
    ]
    actions_list = [
        'bulk_sync_sites',
        'bulk_discover_sites'
    ]
    
    @display(description="Status")
    def status_display(self, obj):
        """Display site status with colored badge."""
        if obj.maintenance_active:
            return format_html(
                '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">'
                '🚧 Maintenance'
                '</span>'
            )
        elif obj.is_active:
            return format_html(
                '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">'
                '✅ Active'
                '</span>'
            )
        else:
            return format_html(
                '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">'
                '⏸️ Inactive'
                '</span>'
            )
    
    @display(description="Actions")
    def action_buttons(self, obj):
        """Display action buttons for each site."""
        buttons = []
        
        if obj.maintenance_active:
            buttons.append(
                format_html(
                    '<a href="{}?action=disable_maintenance" class="inline-flex items-center px-3 py-1 border border-transparent text-xs leading-4 font-medium rounded-md text-white bg-green-600 hover:bg-green-700">'
                    '🟢 Disable Maintenance'
                    '</a>',
                    reverse('admin:maintenance_cloudflareosite_change', args=[obj.pk])
                )
            )
        else:
            buttons.append(
                format_html(
                    '<a href="{}?action=enable_maintenance" class="inline-flex items-center px-3 py-1 border border-transparent text-xs leading-4 font-medium rounded-md text-white bg-red-600 hover:bg-red-700">'
                    '🔴 Enable Maintenance'
                    '</a>',
                    reverse('admin:maintenance_cloudflaresite_change', args=[obj.pk])
                )
            )
        
        return format_html(' '.join(buttons))
```

### 3. **Agent Configuration Admin (Advanced Fieldsets)**
```python
# Real example from django-cfg agents app
@admin.register(ToolsetConfiguration)
class ToolsetConfigurationAdmin(ModelAdmin, ImportExportModelAdmin):
    """Admin interface for ToolsetConfiguration with Unfold styling."""
    
    # Import/Export configuration
    import_form_class = ImportForm
    export_form_class = ExportForm
    
    list_display = [
        'name_display', 'toolset_class_badge', 'status_badge', 'usage_info', 'created_by', 'created_at'
    ]
    ordering = ['-created_at']
    list_filter = [
        'is_active', 'created_at',
        ('created_by', AutocompleteSelectFilter)
    ]
    search_fields = ['name', 'description', 'toolset_class']
    autocomplete_fields = ['created_by', 'allowed_users', 'allowed_groups']
    readonly_fields = ['created_at', 'updated_at', 'config_preview']
    
    # Unfold form field overrides
    formfield_overrides = {
        models.TextField: {"widget": WysiwygWidget},
        JSONField: {"widget": JSONEditorWidget},
    }
    
    fieldsets = (
        ("🔧 Basic Information", {
            'fields': ('name', 'description', 'toolset_class'),
            'classes': ('tab',)
        }),
        ("⚙️ Configuration", {
            'fields': ('config_preview', 'config'),
            'classes': ('tab',)
        }),
        ("🔐 Access Control", {
            'fields': ('is_active', 'allowed_users', 'allowed_groups'),
            'classes': ('tab',)
        }),
        ("📝 Metadata", {
            'fields': ('created_by', 'created_at', 'updated_at'),
            'classes': ('tab', 'collapse')
        }),
    )
    
    actions = ['activate_toolsets', 'deactivate_toolsets']
    
    @display(description="Toolset Name")
    def name_display(self, obj):
        """Enhanced name display."""
        return format_html(
            '<div class="flex items-center space-x-2">'
            '<span class="text-teal-600 font-medium">{}</span>'
            '</div>',
            obj.name
        )
    
    @display(description="Class")
    def toolset_class_badge(self, obj):
        """Toolset class badge."""
        return format_html(
            '<span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">'
            '{}'
            '</span>',
            obj.toolset_class.split('.')[-1] if obj.toolset_class else 'Unknown'
        )
```

## 📊 Import/Export Integration

### 1. **Resource Configuration**
```python
# Real example from django-cfg leads app
from import_export import resources, fields
from import_export.widgets import ForeignKeyWidget
from .models import Lead

class LeadResource(resources.ModelResource):
    """Import/Export resource for Lead model."""
    
    # Custom field mappings
    user = fields.Field(
        column_name='user',
        attribute='user',
        widget=ForeignKeyWidget(User, 'email')
    )
    
    class Meta:
        model = Lead
        fields = (
            'id', 'name', 'email', 'company', 'company_site',
            'contact_type', 'contact_value', 'subject', 'message',
            'status', 'user', 'admin_notes', 'created_at'
        )
        export_order = fields
        
    def before_import_row(self, row, **kwargs):
        """Process row before import."""
        # Normalize email
        if 'email' in row:
            row['email'] = row['email'].lower().strip()
        
        # Set default status
        if 'status' not in row or not row['status']:
            row['status'] = 'new'
    
    def after_save_instance(self, instance, using_transactions, dry_run):
        """Process instance after save."""
        if not dry_run:
            # Send notification for new leads
            if instance.status == 'new':
                # Trigger notification logic
                pass
```

### 2. **Admin Integration**
```python
# Import/Export admin integration
from django_cfg import ImportExportModelAdmin, ImportForm, ExportForm

@admin.register(Lead)
class LeadAdmin(ModelAdmin, ImportExportModelAdmin):
    # Import/Export configuration
    resource_class = LeadResource
    import_form_class = ImportForm
    export_form_class = ExportForm
    
    # Standard admin configuration
    list_display = ['name', 'email', 'status', 'created_at']
    
    def get_export_queryset(self, request):
        """Customize export queryset."""
        queryset = super().get_export_queryset(request)
        # Only export leads from last 30 days by default
        return queryset.filter(created_at__gte=timezone.now() - timedelta(days=30))
```

## 🎯 Custom Actions & Buttons

### 1. **Unfold Action Decorators**
```python
from unfold.decorators import action
from unfold.enums import ActionVariant

class MyModelAdmin(ModelAdmin):
    
    @action(description="Activate selected items", variant=ActionVariant.SUCCESS)
    def activate_items(self, request, queryset):
        """Bulk activate action."""
        updated = queryset.update(is_active=True)
        self.message_user(
            request,
            f"Successfully activated {updated} items.",
            messages.SUCCESS
        )
    
    @action(description="Deactivate selected items", variant=ActionVariant.WARNING)
    def deactivate_items(self, request, queryset):
        """Bulk deactivate action."""
        updated = queryset.update(is_active=False)
        self.message_user(
            request,
            f"Successfully deactivated {updated} items.",
            messages.WARNING
        )
    
    actions = ['activate_items', 'deactivate_items']
```

### 2. **Detail Page Action Buttons**
```python
# Real pattern from django-cfg maintenance app
class CloudflareSiteAdmin(ModelAdmin):
    
    # Detail page actions
    actions_detail = [
        'sync_with_cloudflare_detail',
        'enable_maintenance_detail',
        'disable_maintenance_detail'
    ]
    
    @action(description="Sync with Cloudflare", variant=ActionVariant.INFO)
    def sync_with_cloudflare_detail(self, request, obj):
        """Sync single site with Cloudflare."""
        try:
            # Sync logic here
            success = obj.sync_with_cloudflare()
            if success:
                self.message_user(
                    request,
                    f"Successfully synced {obj.name} with Cloudflare.",
                    messages.SUCCESS
                )
            else:
                self.message_user(
                    request,
                    f"Failed to sync {obj.name} with Cloudflare.",
                    messages.ERROR
                )
        except Exception as e:
            self.message_user(
                request,
                f"Error syncing {obj.name}: {str(e)}",
                messages.ERROR
            )
        
        return HttpResponseRedirect(request.get_full_path())
```

## 📋 Fieldsets & Display

### 1. **Advanced Fieldsets with Tabs**
```python
# Real example from django-cfg agents app
fieldsets = (
    ("🔧 Basic Information", {
        'fields': ('name', 'description', 'toolset_class'),
        'classes': ('tab',)  # Unfold tab styling
    }),
    ("⚙️ Configuration", {
        'fields': ('config_preview', 'config'),
        'classes': ('tab',)
    }),
    ("🔐 Access Control", {
        'fields': ('is_active', 'allowed_users', 'allowed_groups'),
        'classes': ('tab',)
    }),
    ("📝 Metadata", {
        'fields': ('created_by', 'created_at', 'updated_at'),
        'classes': ('tab', 'collapse')  # Collapsible tab
    }),
)
```

### 2. **Custom Display Methods with HTML**
```python
from django.utils.html import format_html
from django.contrib.admin import display

class MyModelAdmin(ModelAdmin):
    
    @display(description="Status Badge")
    def status_badge(self, obj):
        """Display status with colored badge."""
        if obj.is_active:
            return format_html(
                '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">'
                '✅ Active'
                '</span>'
            )
        else:
            return format_html(
                '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">'
                '❌ Inactive'
                '</span>'
            )
    
    @display(description="Usage Info")
    def usage_info(self, obj):
        """Display usage statistics."""
        return format_html(
            '<div class="text-sm">'
            '<div class="text-gray-600">Used: <span class="font-medium">{}</span> times</div>'
            '<div class="text-gray-500">Last: {}</div>'
            '</div>',
            obj.usage_count,
            obj.last_used_at.strftime('%Y-%m-%d %H:%M') if obj.last_used_at else 'Never'
        )
```

### 3. **Inline Configuration**
```python
# Real example from django-cfg support app
class MessageInline(TabularInline):
    """Inline for ticket messages."""
    model = Message
    extra = 0
    readonly_fields = ['created_at', 'sender_avatar']
    fields = ['sender_avatar', 'sender', 'message_preview', 'created_at']
    
    def get_queryset(self, request):
        """Optimize queryset for inlines."""
        return super().get_queryset(request).select_related('sender').order_by('-created_at')
    
    @display(description="Avatar")
    def sender_avatar(self, obj):
        """Display sender avatar in inline."""
        if obj.sender and obj.sender.avatar:
            return format_html(
                '<img src="{}" width="24" height="24" style="border-radius: 50%;" />',
                obj.sender.avatar.url
            )
        return format_html(
            '<div style="width: 24px; height: 24px; background: #e5e7eb; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 10px; color: #6b7280;">'
            '{}'
            '</div>',
            obj.sender.get_initials() if obj.sender else '?'
        )
    
    @display(description="Message")
    def message_preview(self, obj):
        """Display message preview."""
        preview = obj.message[:100] + '...' if len(obj.message) > 100 else obj.message
        return format_html('<div class="text-sm text-gray-600">{}</div>', preview)
```

## 🏷️ Metadata
**Tags**: `admin, unfold, ui, dashboard, actions, import-export, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Real Examples**: User, Maintenance, Agent, Lead, Support admins from django-cfg
**DEPENDS_ON**: [django-unfold, django-import-export, django-cfg-core]
**USED_BY**: [all-django-cfg-apps]
