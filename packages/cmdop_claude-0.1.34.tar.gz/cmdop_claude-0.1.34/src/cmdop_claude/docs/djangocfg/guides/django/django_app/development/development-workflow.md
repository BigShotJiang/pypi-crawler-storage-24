# 🔧 Django-CFG Development Workflow Guide %%PRIORITY:HIGH%%

## 🎯 Quick Summary
- **Comprehensive development workflow** with CLI tools and management commands
- **Built-in management commands** for debugging, testing, and administration
- **CLI automation** with Click-based tools and Poetry integration
- **Real implementations** from django-cfg apps with working examples

## 📋 Table of Contents
1. [CLI Tools & Project Creation](#cli-tools--project-creation)
2. [Built-in Management Commands](#built-in-management-commands)
3. [App-Specific Commands](#app-specific-commands)
4. [Development Server & Tools](#development-server--tools)
5. [Testing & Debugging](#testing--debugging)
6. [Best Practices](#best-practices)

## 🔑 Key Concepts at a Glance
- **CLI Automation**: Click-based CLI with automatic project setup
- **Management Commands**: 20+ built-in commands for debugging and administration
- **Auto-Configuration**: Automatic dependency installation and setup
- **Environment Configs**: YAML-based configuration for different environments
- **Ready Module Integration**: Uses django_currency, django_logger, django_ngrok

## 🚀 Quick Start

### Project Creation
```bash
# Full automatic installation
django-cfg create-project "My Awesome Project"

# Create in specific directory
django-cfg create-project "My Project" --path ./projects/

# Use pip instead of Poetry
django-cfg create-project "My Project" --use-pip

# Skip dependency installation
django-cfg create-project "My Project" --no-deps
```

### Development Commands
```bash
# Show all available commands
python manage.py help

# Show django-cfg configuration
python manage.py show_config --format json

# Run development server with ngrok
python manage.py runserver_ngrok 8000

# Monitor logs during development
tail -f logs/django.log
tail -f logs/djangocfg/payments.log
```

## 🛠️ CLI Tools & Project Creation

### 1. **Django-CFG CLI (Real Implementation)**
```python
# cli/main.py - Real implementation
import click
from pathlib import Path
from typing import Optional

from .commands.create_project import create_project
from .commands.info import info
from .utils import get_package_info
from ..utils.version_check import check_python_version

@click.group(name="django-cfg")
@click.version_option(version=get_package_info()["version"], prog_name="django-cfg")
@click.help_option("--help", "-h")
def cli():
    """
    🚀 Django CFG - Production-ready Django configuration framework
    
    A powerful CLI for managing Django projects with type-safe configuration,
    smart automation, and modern developer experience.
    """
    # Check Python version before any operations
    check_python_version("django-cfg CLI")

# Register commands
cli.add_command(create_project)
cli.add_command(info)
```

### 2. **Project Creation Command (Real Implementation)**
```bash
# Available CLI commands
django-cfg create-project "My Awesome Project"
django-cfg create-project "My Project" --path ./projects/
django-cfg create-project "My Project" --use-pip
django-cfg create-project "My Project" --no-deps
django-cfg create-project "My Project" --no-setup
django-cfg create-project "My Project" --force
django-cfg info  # Show package information
```

### 3. **Automatic Setup Process (Real Implementation)**
```python
# What happens automatically during project creation:
# 1. Template extraction from archive with local-dev blocks cleaning
# 2. Structure creation:
#    - db/ - for SQLite database
#    - cache/ - for caching
#    - .gitignore - proper exclusions
#    - README.md - project documentation
# 3. Dependency installation via Poetry or pip
# 4. Database migrations
# 5. Static files collection
# 6. Initial superuser creation (optional)
```

## 🛠️ Built-in Management Commands

### 1. **Configuration & Debugging Commands (Real Implementation)**
```bash
# Show complete django-cfg configuration
python manage.py show_config
python manage.py show_config --format json --include-secrets

# Validate configuration and test connections
python manage.py validate_config --show-details --check-connections

# Check django-cfg settings and diagnose issues
python manage.py check_settings --verbose --email-test

# Display all URL patterns with filtering
python manage.py show_urls --format table --filter api
python manage.py show_urls --namespace cfg_payments

# Show project structure as tree
python manage.py tree --max-depth 3
```

### 2. **Development Server Commands (Real Implementation)**
```bash
# Standard Django development server
python manage.py runserver 8000

# Development server with automatic ngrok tunnel
python manage.py runserver_ngrok 8000
python manage.py runserver_ngrok --domain custom-domain.ngrok.io

# Collect static files for development
python manage.py collectstatic --noinput

# Create superuser for admin access
python manage.py createsuperuser
```

### 3. **Background Tasks Commands (Real Implementation)**
```bash
# Run Dramatiq workers
python manage.py rundramatiq --processes 2 --threads 4
python manage.py rundramatiq --queues knowbase,payments

# Check task status and queue information
python manage.py task_status --queue knowbase
python manage.py task_status --format json

# Clear task queues
python manage.py clear_queues --queue payments
python manage.py clear_queues --all
```

## 🎯 App-Specific Commands

### 1. **Payments App Commands (Real Implementation)**
```bash
# Currency management with django_currency integration
python manage.py manage_currencies --populate
python manage.py manage_currencies --rates-only
python manage.py manage_currencies --currency BTC
python manage.py manage_currencies --force
python manage.py manage_currencies --dry-run

# Provider management
python manage.py manage_providers
python manage.py manage_providers --provider nowpayments
python manage.py manage_providers --stats
python manage.py manage_providers --health-check

# Payment testing
python manage.py test_payment --user-email user@example.com
python manage.py test_payment --monitor
python manage.py payment_stats --detailed
```

### 2. **Agents App Commands (Real Implementation)**
```bash
# Create new agent
python manage.py create_agent --name "Support Agent" --type customer_support
python manage.py create_agent --from-template basic_assistant

# List available agents
python manage.py list_agents --active-only
python manage.py list_agents --format json

# Agent management
python manage.py activate_agent --name "Support Agent"
python manage.py deactivate_agent --id 123
```

### 3. **Maintenance App Commands (Real Implementation)**
```bash
# Site maintenance mode
python manage.py maintenance --enable
python manage.py maintenance --disable
python manage.py maintenance --status

# Cloudflare synchronization
python manage.py sync_cloudflare --zone-id your-zone-id
python manage.py sync_cloudflare --dry-run
```

### 4. **Command API Integration (Real Implementation)**
```python
# api/commands/views.py - Real implementation
from django.core.management import get_commands
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import user_passes_test

@require_http_methods(["GET"])
@user_passes_test(lambda u: u.is_superuser)
def list_commands_view(request):
    """List all available Django management commands."""
    try:
        # Get all available commands
        commands_dict = get_commands()
        
        # Categorize commands
        categorized_commands = {
            "django_cfg": [],
            "django_core": [],
            "third_party": [],
            "project": [],
        }
        
        for command_name, app_name in commands_dict.items():
            command_info = {
                "name": command_name,
                "app": app_name,
                "description": _get_command_description(command_name),
            }
            
            if app_name == "django_cfg":
                categorized_commands["django_cfg"].append(command_info)
            elif app_name.startswith("django."):
                categorized_commands["django_core"].append(command_info)
            elif app_name.startswith(("src.", "api.", "accounts.")):
                categorized_commands["project"].append(command_info)
            else:
                categorized_commands["third_party"].append(command_info)
        
        return JsonResponse({
            "status": "success",
            "commands": categorized_commands,
            "total_commands": len(commands_dict),
            "timestamp": timezone.now().isoformat(),
        })
        
    except Exception as e:
        logger.error(f"Error listing commands: {e}")
        return JsonResponse({
            "status": "error",
            "error": str(e),
        }, status=500)
```

## 🔧 Development Server & Tools

### 1. **Ngrok Integration (Real Implementation)**
```python
# Real pattern for ngrok integration
from django_cfg.modules.django_ngrok import NgrokManager

class Command(BaseCommand):
    """Run development server with ngrok tunnel."""
    
    def add_arguments(self, parser):
        parser.add_argument('--port', type=int, default=8000)
        parser.add_argument('--domain', type=str, help='Custom ngrok domain')
        parser.add_argument('--no-ngrok', action='store_true', help='Disable ngrok')
    
    def handle(self, *args, **options):
        port = options['port']
        
        if not options['no_ngrok']:
            # Start ngrok tunnel
            ngrok = NgrokManager()
            tunnel_url = ngrok.start_tunnel(
                port=port,
                domain=options.get('domain')
            )
            
            self.stdout.write(
                self.style.SUCCESS(f'🌐 Ngrok tunnel: {tunnel_url}')
            )
        
        # Start Django development server
        call_command('runserver', f'0.0.0.0:{port}')
```

### 2. **Configuration Display (Real Implementation)**
```python
# Real pattern for configuration display
from django_cfg.core.config import get_current_config

class Command(BaseCommand):
    """Show django-cfg configuration."""
    
    def add_arguments(self, parser):
        parser.add_argument('--format', choices=['json', 'yaml', 'table'])
        parser.add_argument('--include-secrets', action='store_true')
        parser.add_argument('--filter', help='Filter by key pattern')
    
    def handle(self, *args, **options):
        config = get_current_config()
        
        # Get configuration data
        config_data = config.model_dump(
            exclude_secrets=not options['include_secrets']
        )
        
        # Apply filter if provided
        if options['filter']:
            config_data = self._filter_config(config_data, options['filter'])
        
        # Format output
        if options['format'] == 'json':
            self.stdout.write(json.dumps(config_data, indent=2))
        elif options['format'] == 'yaml':
            self.stdout.write(yaml.dump(config_data, default_flow_style=False))
        else:
            self._display_table(config_data)
```

## 🧪 Testing & Debugging

### 1. **Testing Commands (Real Implementation)**
```bash
# Run tests with coverage
python manage.py test --keepdb --parallel
python manage.py test apps.payments --verbosity=2

# Test specific functionality
python manage.py test_payment --user-email test@example.com
python manage.py test_currency_conversion --from BTC --to USD --amount 1.0

# Database testing
python manage.py test --debug-mode
python manage.py test --failfast
```

### 2. **Debugging Tools (Real Implementation)**
```bash
# Show URL patterns
python manage.py show_urls --format table
python manage.py show_urls --include-views

# Check system health
python manage.py check --deploy
python manage.py validate_config --check-connections

# Database inspection
python manage.py dbshell
python manage.py inspectdb > models_backup.py
```

### 3. **Logging and Monitoring (Real Implementation)**
```bash
# Monitor application logs
tail -f logs/django.log
tail -f logs/djangocfg/payments.log
tail -f logs/djangocfg/knowbase.log

# Check log levels
python manage.py check_logging --show-handlers
python manage.py rotate_logs --compress

# Performance monitoring
python manage.py profile_views --duration 60
python manage.py check_queries --slow-only
```

## 🎯 Best Practices

### 1. **Command Development Pattern (Real Implementation)**
```python
# Real pattern for creating management commands
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone
from typing import Optional, List, Dict, Any

from django_cfg.modules.django_logger import get_logger

logger = get_logger("command_name")

class Command(BaseCommand):
    """Command description."""
    
    help = "Detailed command help text"
    
    def add_arguments(self, parser):
        """Add command arguments."""
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be done without making changes'
        )
        parser.add_argument(
            '--verbose',
            action='store_true',
            help='Enable verbose output'
        )
        parser.add_argument(
            '--format',
            choices=['json', 'table', 'csv'],
            default='table',
            help='Output format'
        )
    
    def handle(self, *args, **options):
        """Main command logic."""
        try:
            self.verbosity = options.get('verbosity', 1)
            self.dry_run = options.get('dry_run', False)
            
            if self.dry_run:
                self.stdout.write(
                    self.style.WARNING('🔍 DRY RUN MODE - No changes will be made')
                )
            
            # Main command logic
            result = self._execute_command(options)
            
            # Success message
            self.stdout.write(
                self.style.SUCCESS(f'✅ Command completed successfully')
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Command failed: {e}")
            raise CommandError(f"Command failed: {e}")
    
    def _execute_command(self, options: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the main command logic."""
        with transaction.atomic():
            # Command implementation
            pass
    
    def _log_progress(self, message: str, level: str = 'info'):
        """Log progress with appropriate styling."""
        if self.verbosity >= 1:
            if level == 'success':
                self.stdout.write(self.style.SUCCESS(f'✅ {message}'))
            elif level == 'warning':
                self.stdout.write(self.style.WARNING(f'⚠️ {message}'))
            elif level == 'error':
                self.stdout.write(self.style.ERROR(f'❌ {message}'))
            else:
                self.stdout.write(f'ℹ️ {message}')
```

### 2. **Error Handling Pattern (Real Implementation)**
```python
# Real pattern for robust error handling
class Command(BaseCommand):
    def handle(self, *args, **options):
        try:
            # Main logic
            self._execute_safely(options)
            
        except KeyboardInterrupt:
            self.stdout.write(
                self.style.WARNING('\n⏹️ Command interrupted by user')
            )
            return
            
        except CommandError:
            # Re-raise Django command errors
            raise
            
        except Exception as e:
            logger.error(f"Unexpected error in command: {e}")
            
            if options.get('verbosity', 1) >= 2:
                # Show full traceback in verbose mode
                import traceback
                self.stdout.write(
                    self.style.ERROR(traceback.format_exc())
                )
            
            raise CommandError(f"Command failed: {e}")
    
    def _execute_safely(self, options):
        """Execute command with proper error handling."""
        try:
            # Command logic here
            pass
            
        except ValidationError as e:
            raise CommandError(f"Validation error: {e}")
            
        except DatabaseError as e:
            raise CommandError(f"Database error: {e}")
            
        except Exception as e:
            logger.error(f"Execution error: {e}")
            raise
```

### 3. **Performance Optimization (Real Implementation)**
```python
# Real pattern for performance optimization
class Command(BaseCommand):
    def handle(self, *args, **options):
        # Use bulk operations for large datasets
        batch_size = options.get('batch_size', 1000)
        
        # Process in batches
        queryset = Model.objects.all()
        total_count = queryset.count()
        
        self.stdout.write(f'Processing {total_count} records in batches of {batch_size}')
        
        for i in range(0, total_count, batch_size):
            batch = queryset[i:i + batch_size]
            
            with transaction.atomic():
                self._process_batch(batch)
            
            # Progress indicator
            progress = min(i + batch_size, total_count)
            percentage = (progress / total_count) * 100
            
            self.stdout.write(f'Progress: {progress}/{total_count} ({percentage:.1f}%)')
    
    def _process_batch(self, batch):
        """Process a batch of records efficiently."""
        # Use bulk_create, bulk_update for efficiency
        updates = []
        
        for item in batch:
            # Process item
            updates.append(item)
        
        # Bulk update
        Model.objects.bulk_update(updates, ['field1', 'field2'])
```

## 🏷️ Metadata
**Tags**: `development, workflow, commands, cli, management, django-cfg`
**Status**: %%ACTIVE%%
**Complexity**: %%MODERATE%%
**Real Examples**: CLI tools, management commands from payments, agents, maintenance apps
**DEPENDS_ON**: [django-management, click, poetry, django-cfg-core]
**USED_BY**: [developers, devops, system-administrators]
