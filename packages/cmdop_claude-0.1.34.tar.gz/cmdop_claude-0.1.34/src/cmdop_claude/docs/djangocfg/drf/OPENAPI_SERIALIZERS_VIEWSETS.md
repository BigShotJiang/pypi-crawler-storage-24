# Writing OpenAPI-Compatible Serializers & ViewSets

A practical guide to building DRF serializers and viewsets that produce clean, valid OpenAPI schemas with drf-spectacular.

## Table of Contents

- [ViewSet Base Classes](#viewset-base-classes)
- [Serializer Class Declaration](#serializer-class-declaration)
- [Decorator Order](#decorator-order)
- [Nullable and Optional Fields](#nullable-and-optional-fields)
- [Action-Specific Serializers](#action-specific-serializers)
- [APIView Schema Annotations](#apiview-schema-annotations)
- [Authentication Extensions](#authentication-extensions)
- [Queryset and Ordering](#queryset-and-ordering)
- [Pydantic Models in Schema](#pydantic-models-in-schema)
- [SPECTACULAR_SETTINGS](#spectacular_settings)
- [Validation and Debugging](#validation-and-debugging)
- [Non-Model ViewSet Queryset](#non-model-viewset-queryset)
- [Path Parameter Name: id vs pk](#path-parameter-name-id-vs-pk)
- [Quick Checklist](#quick-checklist)

---

## ViewSet Base Classes

### Problem

Using `viewsets.ViewSet` causes drf-spectacular to fail with:

```
Error [MyViewSet]: unable to guess serializer. This is graceful fallback handling
for APIViews. Consider using GenericAPIView as view base class.
```

The view is silently **excluded** from the generated schema.

### Rule

Always use `viewsets.GenericViewSet` (not `viewsets.ViewSet`) as the base class, even for viewsets that don't use a Django queryset.

```python
# BAD — invisible to schema generation
class QueueViewSet(viewsets.ViewSet):
    pass

# GOOD — schema-compatible
class QueueViewSet(viewsets.GenericViewSet):
    serializer_class = QueueStatsSerializer  # required
```

### Why

`GenericViewSet` provides `get_serializer_class()` which drf-spectacular inspects to determine request/response types. Without it, the introspection chain breaks.

For viewsets without a Django model queryset, you get "Failed to obtain model through queryset" warnings. See [Non-Model ViewSet Queryset](#non-model-viewset-queryset) for how to suppress them.

---

## Serializer Class Declaration

### Problem

A `GenericViewSet` without `serializer_class` produces a warning for every endpoint on that viewset.

### Rule

Every viewset must declare `serializer_class` at the class level, even if individual actions override it via `get_serializer_class()`.

```python
class TradeDecisionViewSet(
    mixins.ListModelMixin,
    mixins.CreateModelMixin,
    mixins.RetrieveModelMixin,
    viewsets.GenericViewSet,
):
    queryset = TradeDecision.objects.all()
    serializer_class = TradeDecisionListSerializer  # default / fallback

    def get_serializer_class(self):
        if self.action == "create":
            return TradeDecisionCreateSerializer
        if self.action == "retrieve":
            return TradeDecisionDetailSerializer
        if self.action == "close":
            return DecisionCloseSerializer
        return TradeDecisionListSerializer
```

The class-level `serializer_class` serves as the schema fallback. `get_serializer_class()` overrides it at runtime but drf-spectacular reads both.

---

## Decorator Order

### Problem

Placing `@extend_schema` after `@action` makes drf-spectacular ignore the schema annotation — the generated schema falls back to the class-level serializer or becomes empty.

### Rule

`@extend_schema` must come **before** `@action`:

```python
# BAD — schema annotation is ignored
@action(detail=True, methods=["post"], url_path="close")
@extend_schema(
    summary="Close decision",
    request=DecisionCloseSerializer,
    responses={200: TradeDecisionDetailSerializer},
)
def close(self, request, pk=None):
    ...

# GOOD — schema annotation is applied
@extend_schema(
    summary="Close decision",
    request=DecisionCloseSerializer,
    responses={200: TradeDecisionDetailSerializer},
)
@action(detail=True, methods=["post"], url_path="close")
def close(self, request, pk=None):
    ...
```

For class-level schema, use `@extend_schema_view` on the class and `@extend_schema(tags=[...])` for tag grouping:

```python
@extend_schema(tags=["Trading"])
@extend_schema_view(
    list=extend_schema(summary="List decisions", parameters=[...]),
    create=extend_schema(summary="Create decision"),
    retrieve=extend_schema(summary="Get decision detail"),
)
class TradeDecisionViewSet(...):
    ...
```

---

## Nullable and Optional Fields

### Problem: `null` in enum values

When a model field has `choices` + `null=True` + `blank=True`, drf-spectacular adds `null` as an explicit enum value:

```yaml
category:
  enum:
    - pattern
    - failure
    - success
    - ''
    - null          # ← invalid in OpenAPI 3.0
  type: string
  nullable: true
```

This causes `SchemaValidationError` in OpenAPI 3.0 (`null` is not a valid type). In OpenAPI 3.1 it is valid, but the redundant `null` in enum alongside `nullable: true` is still messy.

### Solution 1: Disable globally

In `SPECTACULAR_SETTINGS`:

```python
SPECTACULAR_SETTINGS = {
    "ENUM_ADD_EXPLICIT_BLANK_NULL_CHOICE": False,
}
```

This prevents `null` and `''` from being added to enum values globally. Nullable is expressed via `nullable: true` instead.

### Solution 2: Override per-field

Declare the field explicitly on the serializer with controlled options:

```python
class ArchivalMemorySerializer(serializers.ModelSerializer):
    category = serializers.ChoiceField(
        choices=MemoryCategory.choices,
        allow_blank=True,
        allow_null=True,
        required=False,
    )

    class Meta:
        model = ArchivalMemory
        fields = ["id", "content", "category", ...]
```

With `ENUM_ADD_EXPLICIT_BLANK_NULL_CHOICE = False`, this generates:

```yaml
category:
  enum: [pattern, failure, success, regime_transition, decision_reason]
  type: string
  nullable: true
```

### Problem: Nullable non-enum fields

For regular nullable fields (no choices), both approaches work:

```python
# ModelSerializer auto-detects null=True from the model field
# and generates: {type: string, nullable: true}

# For plain Serializer, be explicit:
summary = serializers.CharField(allow_null=True, required=False)
```

---

## Action-Specific Serializers

### Problem

Actions with no request body (e.g., POST actions that only need the URL pk) generate "could not resolve request body" warnings.

### Rule

Use `request=None` for bodyless POST actions:

```python
@extend_schema(
    summary="Empty queue",
    request=None,  # ← no request body
    responses={200: {"type": "object"}},
)
@action(detail=True, methods=["post"], url_path="empty")
def empty(self, request, pk=None):
    ...
```

For actions returning non-serializer responses (dicts, lists), use inline schema:

```python
@extend_schema(
    summary="Get full ledger",
    responses={200: {"type": "object", "additionalProperties": {"type": "number"}}},
)
@action(detail=False, methods=["get"], url_path="full_ledger")
def full_ledger(self, request):
    return Response({"total_pnl": 1234.56, "trade_count": 42})
```

---

## APIView Schema Annotations

### Problem

`APIView` subclasses (not `GenericAPIView`) cause the error:

```
Error [MyView]: unable to guess serializer. This is graceful fallback handling
for APIViews. Ignoring view for now.
```

The view is **excluded** from the schema entirely.

### Solution

Use `@extend_schema` on the class with explicit `request` and `responses`:

```python
@extend_schema(
    tags=["User Profile"],
    summary="Delete user account",
    request=None,  # POST with no body
    responses={
        200: AccountDeleteResponseSerializer,
        400: {"description": "Account is already deleted."},
    }
)
class AccountDeleteView(APIView):
    def post(self, request):
        ...
```

If the view has a GET method returning arbitrary JSON:

```python
@extend_schema(
    tags=["System"],
    summary="Compact URL list",
    responses={200: {"type": "object"}},
)
class DRFURLsListCompactView(APIView):
    def get(self, request):
        return Response({"total": 42, "urls": [...]})
```

### Alternative

Switch to `generics.GenericAPIView` and set `serializer_class`:

```python
class AccountDeleteView(generics.GenericAPIView):
    serializer_class = AccountDeleteResponseSerializer

    def post(self, request):
        ...
```

---

## Authentication Extensions

### Problem

Custom authentication classes produce warnings:

```
Warning: APIKeyAuthentication: could not determine security definition.
```

This warning repeats for **every endpoint** using that authentication, flooding the output.

### Solution

Register an `OpenApiAuthenticationExtension`:

```python
# apps/api_keys/openapi.py
from drf_spectacular.extensions import OpenApiAuthenticationExtension


class APIKeyAuthenticationScheme(OpenApiAuthenticationExtension):
    target_class = "apps.api_keys.authentication.APIKeyAuthentication"
    name = "apiKeyAuth"

    def get_security_definition(self, auto_schema):
        return {
            "type": "apiKey",
            "in": "header",
            "name": "X-API-Key",
        }
```

Register it in `apps.py` so it loads at startup:

```python
class ApiKeysConfig(AppConfig):
    name = "apps.api_keys"

    def ready(self):
        import apps.api_keys.openapi  # noqa: F401
```

---

## Queryset and Ordering

### Problem

Paginated viewsets without ordering on the queryset produce:

```
UnorderedObjectListWarning: Pagination may yield inconsistent results
with an unordered object_list.
```

### Rule

Set ordering on `queryset`, not as a class attribute:

```python
# BAD — ordering attribute requires OrderingFilter backend
class LedgerViewSet(viewsets.GenericViewSet):
    queryset = NumericalLedger.objects.all()
    ordering = ["-updated_at"]  # ← ignored without OrderingFilter

# GOOD — ordering applied at the database level
class LedgerViewSet(viewsets.GenericViewSet):
    queryset = NumericalLedger.objects.all().order_by("-updated_at")
```

The `ordering` class attribute only works when `OrderingFilter` is in `filter_backends`. For default ordering, always use `.order_by()` on the queryset.

---

## Pydantic Models in Schema

### Problem

Pydantic v2 models with `Optional[str]` fields generate OpenAPI 3.1 syntax:

```yaml
pattern:
  anyOf:
    - type: string
    - type: 'null'    # ← invalid in OpenAPI 3.0
  default: null
```

This causes `SchemaValidationError: 'null' is not one of ['array', 'boolean', 'integer', 'number', 'object', 'string']` when validating against OpenAPI 3.0.

### Solution

Set `OAS_VERSION` to `3.1.0` in SPECTACULAR_SETTINGS:

```python
SPECTACULAR_SETTINGS = {
    "OAS_VERSION": "3.1.0",
}
```

OpenAPI 3.1 natively supports `type: 'null'` in `anyOf`/`oneOf`. If you have Pydantic models in your schema (e.g., Centrifugo, RQ serializers), you must use 3.1.

### If you must stay on OpenAPI 3.0

Avoid `Optional` in Pydantic models used as DRF request/response types. Use explicit defaults instead:

```python
# Generates type: null (invalid in 3.0)
class MyRequest(BaseModel):
    pattern: Optional[str] = None

# Safe for 3.0
class MyRequest(BaseModel):
    pattern: str = ""
```

---

## SPECTACULAR_SETTINGS

Recommended settings for clean schema generation:

```python
SPECTACULAR_SETTINGS = {
    # Schema metadata
    "TITLE": "My API",
    "VERSION": "1.0.0",
    "SERVE_INCLUDE_SCHEMA": False,
    "SCHEMA_PATH_PREFIX": "/api/",

    # OpenAPI 3.1 for Pydantic nullable field compatibility
    "OAS_VERSION": "3.1.0",

    # Prevent null/blank from appearing as explicit enum values
    "ENUM_ADD_EXPLICIT_BLANK_NULL_CHOICE": False,

    # Split request/response schemas (important for client generation)
    "COMPONENT_SPLIT_REQUEST": True,
    "COMPONENT_SPLIT_PATCH": True,
}
```

### Key settings explained

| Setting | Default | Recommended | Why |
|---------|---------|-------------|-----|
| `OAS_VERSION` | `3.0.3` | `3.1.0` | Required if Pydantic models have `Optional` fields |
| `ENUM_ADD_EXPLICIT_BLANK_NULL_CHOICE` | `True` | `False` | Prevents `null` and `''` in enum lists |
| `COMPONENT_SPLIT_REQUEST` | `False` | `True` | Separates request/response schemas (cleaner client types) |
| `COMPONENT_SPLIT_PATCH` | `False` | `True` | Generates separate patch schemas |

---

## Validation and Debugging

### Step 1: Run schema validation

```bash
python manage.py spectacular --validate
```

Read the output carefully. It reports three severity levels:

| Level | Meaning | Action |
|-------|---------|--------|
| **Error** | View excluded from schema | Must fix — endpoints are invisible |
| **Warning** | Schema generated with fallbacks | Should fix — may produce wrong types |
| **SchemaValidationError** | Generated schema is invalid | Must fix — clients will reject it |

### Step 2: Generate and inspect the schema file

```bash
python manage.py spectacular --file /tmp/schema.yaml
```

Search for problems:

```bash
# Find null type violations (OpenAPI 3.0)
grep -n "type: null" /tmp/schema.yaml
grep -n "type: 'null'" /tmp/schema.yaml

# Find null in enum values
grep -n "- null" /tmp/schema.yaml

# Find missing descriptions
grep -n "description: ''" /tmp/schema.yaml
```

### Step 3: Check registered endpoints

```bash
python manage.py show_urls | grep api
```

Compare against the schema — any endpoint in `show_urls` but missing from the schema means an Error suppressed it.

### Step 4: Verify settings are applied

```python
# In Django shell
from drf_spectacular.settings import spectacular_settings
print(spectacular_settings.OAS_VERSION)
print(spectacular_settings.ENUM_ADD_EXPLICIT_BLANK_NULL_CHOICE)
```

### Step 5: Test with a real client

Generate a TypeScript or Python client from the schema and verify types match your expectations. Schema warnings often surface as incorrect types in generated code.

### Common warning patterns and fixes

| Warning | Fix |
|---------|-----|
| `could not derive type of path parameter` | Add `@extend_schema` with `OpenApiParameter(name="id", type=str, location=PATH)` |
| `could not resolve request body` | Add `request=MySerializer` or `request=None` to `@extend_schema` |
| `Failed to obtain model through queryset` | Use queryset sentinel: `queryset = type("_", (), {"model": None})()` |
| `Encountered 2 components with identical names` | Rename one serializer class to avoid collision |
| `unable to guess serializer` (Error) | Add `serializer_class` or switch to `GenericViewSet`/`GenericAPIView` |
| `AnonymousUser` in queryset filter | Add `swagger_fake_view` guard in `get_queryset()` |

---

## Non-Model ViewSet Queryset

### Problem

`GenericViewSet` subclasses that don't use a Django model produce warnings:

```
Warning [MyViewSet]: Failed to obtain model through view's queryset due to raised
exception. Prevent this either by setting "queryset = Model.objects.none()" ...
```

This warning appears once per viewset and cascades into other warnings like "could not derive type of path parameter".

### Why standard approaches fail

| Approach | Result |
|----------|--------|
| `queryset = []` | `'list' object has no attribute 'model'` — crash |
| `get_queryset()` returning `None` with `swagger_fake_view` | drf-spectacular probes `view.queryset` at class level (line 215 in `plumbing.py`) **before** calling `get_queryset()`, so the guard is never reached |
| No `queryset` at all | The "Failed to obtain model" warning |

### Solution: queryset sentinel

Set `queryset` to an anonymous object with `.model = None`:

```python
class QueueViewSet(AdminAPIMixin, viewsets.GenericViewSet):
    serializer_class = QueueStatsSerializer
    queryset = type("_", (), {"model": None})()
```

### How it works

drf-spectacular's `get_view_model()` in `plumbing.py` does:

```python
# line 215
model = getattr(getattr(view, 'queryset', None), 'model', None)
# line 217
if model is not None:
    return model
# line 221 — only reached if model is not None
view.queryset = view.get_queryset()  # ← this is where the warning fires
```

By setting `queryset` to an object with `.model = None`, line 215 returns `None`, line 217 returns early, and line 221 is never reached. No warning, no crash.

### When to use `swagger_fake_view` instead

Use the `swagger_fake_view` guard when the viewset **has** a real model queryset but filters by `self.request.user` (which is `AnonymousUser` during schema generation):

```python
class DeviceViewSet(viewsets.ModelViewSet):
    serializer_class = DeviceSerializer

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return TOTPDevice.objects.none()
        return TOTPDevice.objects.filter(user=self.request.user)
```

---

## Path Parameter Name: id vs pk

### Problem

Detail actions on non-model viewsets produce:

```
Warning [MyViewSet]: could not derive type of path parameter "id" because it is
untyped and obtaining queryset from the viewset failed.
```

### Key insight: drf-spectacular renames `pk` to `id`

Even though DRF routers generate URL patterns with `{pk}` and your method signature is `def retrieve(self, request, pk=None)`, drf-spectacular normalizes the parameter name to `id` in the OpenAPI schema.

### Rule

Always use `name="id"` (not `name="pk"`) in `OpenApiParameter` for detail views:

```python
# BAD — does not match the schema parameter name
@extend_schema(
    parameters=[
        OpenApiParameter(name="pk", type=str, location=OpenApiParameter.PATH),
    ],
)
def retrieve(self, request, pk=None):
    ...

# GOOD — matches what drf-spectacular generates
@extend_schema(
    parameters=[
        OpenApiParameter(name="id", type=str, location=OpenApiParameter.PATH,
                         description="Resource identifier"),
    ],
)
def retrieve(self, request, pk=None):
    ...
```

This applies to all detail actions: `retrieve`, `destroy`, `@action(detail=True)`.

---

## Quick Checklist

Before running `spectacular --validate`, verify each viewset/view:

- [ ] Base class is `GenericViewSet` or `GenericAPIView` (not `ViewSet` or `APIView`)
- [ ] `serializer_class` is set at the class level
- [ ] `@extend_schema` comes before `@action` on every action method
- [ ] Bodyless POST actions have `request=None` in `@extend_schema`
- [ ] Custom auth classes have `OpenApiAuthenticationExtension` registered
- [ ] Queryset has `.order_by()` if pagination is used
- [ ] Non-model viewsets use queryset sentinel: `queryset = type("_", (), {"model": None})()`
- [ ] Detail actions have `OpenApiParameter(name="id", type=str, location=PATH)` (not `"pk"`)
- [ ] Viewsets filtering by `request.user` have `swagger_fake_view` guard in `get_queryset()`
- [ ] No `Optional` Pydantic fields without `OAS_VERSION: 3.1.0`
- [ ] `ENUM_ADD_EXPLICIT_BLANK_NULL_CHOICE` is `False` if you have nullable choice fields
- [ ] No two serializer classes with identical names across different apps

Target: **0 Warnings, 0 Errors, 0 SchemaValidationError**.
