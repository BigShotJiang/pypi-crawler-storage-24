# API Client Generation - ViewSet Requirements

## Overview

django_cfg auto-generates typed Python/TypeScript clients from DRF ViewSets using drf-spectacular for OpenAPI schema generation.

## Critical Requirements

### 1. Do NOT Use `@extend_schema(tags=[...])` as Class Decorator

**Problem**: Using `@extend_schema(tags=["MyTag"])` directly on a ViewSet class creates an `ExtendedSchema` object that does NOT inherit from `drf_spectacular.openapi.AutoSchema`. This causes schema generation to fail with:

```
AssertionError: Incompatible AutoSchema used on View <class 'MyViewSet'>
```

**Solution**: Do NOT use `@extend_schema` as a class decorator for tags. The `PathBasedAutoSchema` (configured via `DEFAULT_SCHEMA_CLASS`) automatically derives tags from URL paths.

```python
# BAD - will break schema generation
@extend_schema(tags=["Vision"])
class VisionViewSet(viewsets.GenericViewSet):
    pass

# GOOD - tags derived automatically from URL path
class VisionViewSet(viewsets.GenericViewSet):
    pass
```

### 2. Use `@extend_schema_view` for Method-Level Schemas

To specify request/response serializers for actions, use `@extend_schema_view`:

```python
from drf_spectacular.utils import extend_schema, extend_schema_view

@extend_schema_view(
    analyze=extend_schema(
        summary="Analyze image",
        description="Analyze an image with vision model.",
        request=VisionAnalyzeRequestSerializer,
        responses={200: VisionAnalyzeResponseSerializer},
    ),
    ocr=extend_schema(
        summary="OCR extraction",
        request=OCRRequestSerializer,
        responses={200: OCRResponseSerializer},
    ),
)
class VisionViewSet(viewsets.GenericViewSet):
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=["post"], url_path="analyze")
    def analyze(self, request):
        ...
```

### 3. Prefer `GenericViewSet` Over `ViewSet`

For custom action-based ViewSets, use `GenericViewSet`:

```python
# Recommended
class MyViewSet(viewsets.GenericViewSet):
    pass

# Also works
class MyViewSet(viewsets.ReadOnlyModelViewSet):
    pass

class MyViewSet(viewsets.ModelViewSet):
    pass
```

### 4. DRF api_settings Caching Bug

**Problem**: DRF's `api_settings` is a singleton that caches settings on first access. If DRF is imported before django_cfg generates settings, `DEFAULT_SCHEMA_CLASS` will be the default `rest_framework.schemas.openapi.AutoSchema` instead of `PathBasedAutoSchema`.

**Solution**: django_cfg automatically reloads `api_settings` in `get_all_settings()` to ensure correct schema class is used. This is handled in `django_cfg/core/integration/drf.py`.

## Serializer Best Practices

### Separate Request and Response Serializers

For proper client generation with typed request AND response models:

```python
class VisionAnalyzeRequestSerializer(serializers.Serializer):
    """Request serializer - write fields only."""
    image = serializers.CharField(required=False)
    image_url = serializers.URLField(required=False)
    prompt = serializers.CharField(required=False, max_length=2000)

class VisionAnalyzeResponseSerializer(serializers.Serializer):
    """Response serializer - read fields only."""
    extracted_text = serializers.CharField(read_only=True)
    description = serializers.CharField(read_only=True)
    model = serializers.CharField(read_only=True)
    cost_usd = serializers.FloatField(read_only=True)
```

### Use Enums for Choices

For typed enum generation in clients:

```python
from rest_framework import serializers

class MySerializer(serializers.Serializer):
    mode = serializers.ChoiceField(
        choices=[
            ("fast", "Fast"),
            ("balanced", "Balanced"),
            ("best", "Best"),
        ],
        required=False,
    )
```

This generates typed enums in Python client:
```python
class MySerializerMode(str, Enum):
    FAST = "fast"
    BALANCED = "balanced"
    BEST = "best"
```

## Generated Client Structure

```
_api/generated/
├── vision/
│   ├── client.py           # Async client
│   ├── sync_client.py      # Sync client
│   ├── enums.py            # Generated enums
│   ├── vision__api__vision/
│   │   ├── client.py       # Vision API methods
│   │   ├── sync_client.py
│   │   └── models.py       # Request/Response models
│   └── CLAUDE.md           # Auto-generated docs
```

## Troubleshooting

### "Incompatible AutoSchema" Error

1. Remove `@extend_schema(tags=[...])` from class decorator
2. Verify `DEFAULT_SCHEMA_CLASS` is set to `PathBasedAutoSchema` in `REST_FRAMEWORK` settings
3. Check that django_cfg is properly configured

### Missing Response Types in Generated Client

1. Add `responses={200: ResponseSerializer}` to `@extend_schema`
2. Use `@extend_schema_view` for action methods
3. Ensure serializer has proper fields with types

### Tags Not Showing in OpenAPI

Tags are derived from URL paths by `PathBasedAutoSchema`. The URL pattern determines the tag:
- `/api/vision/` -> "Vision" tag
- `/api/keys/` -> "Keys" tag

## Configuration

In `api/config.py`:

```python
openapi_client = OpenAPIClientConfig(
    enabled=True,
    groups=[
        OpenAPIGroupConfig(
            name="vision",
            apps=["apps.vision"],
            title="Vision API",
        ),
        OpenAPIGroupConfig(
            name="keys",
            apps=["apps.keys"],
            title="API Keys",
        ),
    ],
)
```

## Commands

```bash
# Generate all clients
make api-sdk

# Generate specific group
python manage.py generate_client --groups vision --python

# Generate OpenAPI schema only
python manage.py spectacular --file schema.yaml
```
