VAR_DELIMITER = r"\{.*?\}"
