"""HTTP client for Connect RPC communication with Next.js server."""

import json
import logging
import struct
from typing import Any, Dict, Iterable, Iterator, Optional

import requests

from ._config import AIAUTO_BASE_URL, AIAUTO_INSECURE
from ._version import CLIENT_VERSION as _CLIENT_VERSION

logger = logging.getLogger(__name__)

CONNECT_FRAME_HEADER_SIZE = 5  # flags(1B) + length(4B BE)
_ITER_CHUNK_SIZE = 65536  # 64KB, matches common network I/O block size


class _StreamingBody:
    """bytes generator를 wrapping하는 file-like 객체. pre-calculated Content-Length 제공.

    requests: __len__() -> Content-Length 설정
    urllib3: read(size) 반복 호출 -> streaming 전송
    __iter__: fallback iterable (urllib3가 read()를 사용하므로 직접 호출되지 않음)
    메모리: ~1MB (현재 generator yield + read buffer)

    성능 특성:
    - offset 추적으로 read(size) 시 O(1) 소비 (del buf[:size] O(n) memmove 제거)
    - memoryview 슬라이스로 zero-copy 뷰 생성 후 bytes 변환 (복사 1회, 이전과 동일)
    - 소비된 영역이 buffer 절반 이상이면 compact하여 메모리 회수
    - urllib3 blocksize=16384 기준: 1MB chunk 소비 후 compact 시 잔여 ~5B memmove만 발생
    """

    def __init__(self, generator: Iterator[bytes], total_size: int):
        self._gen = generator
        self._size = total_size
        self._buf = bytearray()
        self._off = 0  # 소비된 위치 추적
        self._done = False

    def __len__(self) -> int:
        return self._size

    def __iter__(self):
        while True:
            chunk = self.read(_ITER_CHUNK_SIZE)
            if not chunk:
                break
            yield chunk

    @property
    def _available(self) -> int:
        """buffer에 남은 미소비 데이터 크기."""
        return len(self._buf) - self._off

    def _compact(self) -> None:
        """소비된 영역이 buffer 절반 이상이면 앞으로 이동하여 메모리 회수."""
        if self._off > 0 and self._off >= len(self._buf) // 2:
            del self._buf[: self._off]
            self._off = 0

    def read(self, size: int = -1) -> bytes:
        if size == 0:
            return b""
        while not self._done and (size < 0 or self._available < size):
            try:
                data = next(self._gen)
                if data:
                    self._compact()
                    self._buf.extend(data)
            except StopIteration:
                self._done = True
                break
        if size < 0 or size >= self._available:
            result = bytes(memoryview(self._buf)[self._off :])
            self._buf.clear()
            self._off = 0
            return result
        result = bytes(memoryview(self._buf)[self._off : self._off + size])
        self._off += size
        return result


class ConnectRPCError(Exception):
    """Exception raised for Connect RPC errors with code and message."""

    def __init__(self, code: str, message: str):
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")

    def is_retryable(self) -> bool:
        """Check if this error should be retried."""
        # Only retry on temporary unavailability
        # failed_precondition (webhook 거절 등)은 영구 실패이므로 재시도 대상에서 제외
        return self.code == "unavailable"


class ConnectRPCClient:
    """Client for calling Connect RPC endpoints via HTTP/JSON."""

    def __init__(self, token: str, base_url: Optional[str] = None):
        self.token = token
        # Use base URL for path-based routing
        if base_url:
            self.base_url = base_url
        elif AIAUTO_BASE_URL:
            # Path-based routing: use AIAUTO_BASE_URL directly
            self.base_url = AIAUTO_BASE_URL.rstrip("/")
        else:
            raise ValueError(
                "AIAUTO_BASE_URL environment variable must be set. "
                "Example: export AIAUTO_BASE_URL=https://aiauto.pangyo.ainode.ai"
            )
        if not self.base_url.startswith(("http://", "https://")):
            raise ValueError(
                f"base_url must use http:// or https:// scheme, got: {self.base_url!r}"
            )

        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Connect-Protocol-Version": "1",
            "X-Client-Version": _CLIENT_VERSION,
        }

    @staticmethod
    def _raise_for_status(response: requests.Response) -> None:
        """Raise ConnectRPCError or RuntimeError for non-OK HTTP responses."""
        try:
            error_data = response.json()
            if isinstance(error_data, dict):
                raise ConnectRPCError(
                    error_data.get("code") or "unknown",
                    error_data.get("message") or f"HTTP {response.status_code}",
                )
        except ValueError:
            pass
        raise RuntimeError(f"HTTP {response.status_code}: {response.text}")

    def call_rpc(self, method: str, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Call a Connect RPC method and return the response."""
        url = f"{self.base_url}/api/aiauto.v1.AIAutoService/{method}"

        try:
            response = requests.post(
                url, json=request_data, headers=self.headers, verify=not AIAUTO_INSECURE
            )
        except requests.exceptions.ConnectionError as e:
            logger.debug("Connection failed: %s", e)
            raise ConnectRPCError("unavailable", "Service unavailable: connection failed") from e
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"Request failed: {e}") from e

        if not response.ok:
            self._raise_for_status(response)

        return response.json()

    def _call_client_streaming(
        self, method: str, request_iterator: Iterable[Any], content_length: int
    ) -> bytes:
        """Call a Connect protocol client-streaming RPC with pre-calculated Content-Length.

        Each message from request_iterator is serialized with SerializeToString()
        and wrapped in a Connect streaming frame: [flags:1B][length:4B BE][data].
        Uses _StreamingBody for lazy streaming: memory ~2MB regardless of total size.

        Args:
            method: RPC method name.
            request_iterator: Iterable of protobuf messages.
            content_length: Pre-calculated total body size (caller computes).

        Returns the protobuf bytes from the first data frame in the response.

        Raises:
            ConnectRPCError: If the server returns a Connect error (HTTP or EOS frame).
            RuntimeError: If the response is empty, truncated, or the request fails.
        """
        url = f"{self.base_url}/api/aiauto.v1.AIAutoService/{method}"

        def frame_gen():
            for msg in request_iterator:
                data = msg.SerializeToString()
                yield struct.pack(">BI", 0x00, len(data))
                yield data

        body = _StreamingBody(frame_gen(), content_length)

        try:
            response = requests.post(
                url,
                data=body,
                headers={**self.headers, "Content-Type": "application/connect+proto"},
                verify=not AIAUTO_INSECURE,
                timeout=(10, 7200),  # 10s connect, 2h read (large file upload)
            )
        except requests.exceptions.ConnectionError as e:
            logger.debug("Connection failed: %s", e)
            raise ConnectRPCError("unavailable", "Service unavailable: connection failed") from e
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"Request failed: {e}") from e

        if not response.ok:
            self._raise_for_status(response)

        return self._parse_streaming_response(response.content)

    @staticmethod
    def _check_eos_error(frame_data: bytes) -> None:
        """Check EOS frame for Connect streaming error. Raises ConnectRPCError if found."""
        try:
            eos = json.loads(frame_data)
            if "error" in eos:
                err = eos["error"]
                raise ConnectRPCError(
                    err.get("code", "unknown"),
                    err.get("message", "streaming error"),
                )
        except (ValueError, KeyError, AttributeError, TypeError):
            pass

    @staticmethod
    def _parse_streaming_response(body: bytes) -> bytes:
        """Parse Connect streaming response frames.

        Connect streaming response format:
        - Data frames: [flags=0x00][length:4B BE][protobuf data]
        - End-of-stream frame: [flags=0x02][length:4B BE][JSON with optional error]

        Returns the protobuf bytes from the first data frame.

        Raises:
            ConnectRPCError: If the end-of-stream frame contains an error.
            RuntimeError: If the body is empty or a frame is truncated/corrupted.
        """
        if not body:
            raise RuntimeError("Empty streaming response")

        offset = 0
        result_data = None

        while offset < len(body):
            if offset + 5 > len(body):
                raise RuntimeError(
                    f"Truncated streaming frame header at offset {offset} (body length {len(body)})"
                )

            flags = body[offset]
            length = struct.unpack(">I", body[offset + 1 : offset + 5])[0]
            offset += 5

            if offset + length > len(body):
                raise RuntimeError(
                    f"Truncated streaming frame data at offset {offset}: "
                    f"expected {length} bytes, got {len(body) - offset}"
                )

            frame_data = body[offset : offset + length]
            offset += length

            if flags & 0x02:
                # End-of-stream frame (flags bit 1 set) — JSON payload
                if length > 0:
                    ConnectRPCClient._check_eos_error(frame_data)
            elif result_data is None:
                # Data frame
                result_data = frame_data

        return result_data if result_data is not None else b""
