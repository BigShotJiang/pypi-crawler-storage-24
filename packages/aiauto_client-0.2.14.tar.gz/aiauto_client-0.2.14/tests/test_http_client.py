"""Tests for HTTP client module."""

from http import HTTPStatus
from unittest.mock import MagicMock, patch

import pytest
import requests

from aiauto.http_client import ConnectRPCClient, ConnectRPCError


class TestConnectRPCError:
    """Test ConnectRPCError exception class."""

    def test_init(self):
        """Test error initialization."""
        error = ConnectRPCError("not_found", "Resource not found")
        assert error.code == "not_found"
        assert error.message == "Resource not found"
        assert str(error) == "[not_found] Resource not found"

    def test_is_retryable_unavailable(self):
        """Test unavailable error is retryable."""
        error = ConnectRPCError("unavailable", "Service unavailable")
        assert error.is_retryable() is True

    def test_is_retryable_failed_precondition(self):
        """Test failed_precondition error is NOT retryable (영구 실패)."""
        error = ConnectRPCError("failed_precondition", "Precondition failed")
        assert error.is_retryable() is False

    def test_is_retryable_not_found(self):
        """Test not_found error is not retryable."""
        error = ConnectRPCError("not_found", "Not found")
        assert error.is_retryable() is False

    def test_is_retryable_invalid_argument(self):
        """Test invalid_argument error is not retryable."""
        error = ConnectRPCError("invalid_argument", "Invalid argument")
        assert error.is_retryable() is False

    def test_is_retryable_unknown(self):
        """Test unknown error is not retryable."""
        error = ConnectRPCError("unknown", "Unknown error")
        assert error.is_retryable() is False


class TestConnectRPCClient:
    """Test ConnectRPCClient class."""

    def test_init_with_custom_base_url(self):
        """Test client initialization with custom base URL."""
        client = ConnectRPCClient("test-token", base_url="https://custom.example.com")
        assert client.token == "test-token"
        assert client.base_url == "https://custom.example.com"
        assert client.headers["Authorization"] == "Bearer test-token"
        assert client.headers["Content-Type"] == "application/json"
        assert client.headers["Connect-Protocol-Version"] == "1"
        assert "X-Client-Version" in client.headers

    def test_x_client_version_header_matches_module_version(self):
        """Test X-Client-Version header value matches _CLIENT_VERSION in module."""
        import aiauto.http_client as http_client_module

        client = ConnectRPCClient("test-token", base_url="https://custom.example.com")
        assert client.headers["X-Client-Version"] == http_client_module._CLIENT_VERSION

    def test_x_client_version_is_sent_in_rpc_call(self):
        """Test X-Client-Version header is actually sent in HTTP requests."""
        with patch("aiauto.http_client.requests.post") as mock_post:
            mock_response = MagicMock()
            mock_response.ok = True
            mock_response.json.return_value = {"result": "ok"}
            mock_post.return_value = mock_response

            client = ConnectRPCClient("test-token", base_url="https://api.example.com")
            client.call_rpc("TestMethod", {})

            # requests.post(url, json=..., headers=..., verify=...) 형태로 호출됨
            call_kwargs = mock_post.call_args.kwargs
            sent_headers = call_kwargs["headers"]
            assert "X-Client-Version" in sent_headers

    def test_init_with_default_base_url(self):
        """Test client initialization with default base URL from config."""
        with patch("aiauto.http_client.AIAUTO_BASE_URL", "https://api.example.com:443"):
            client = ConnectRPCClient("test-token")
            assert client.base_url == "https://api.example.com:443"

    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_success(self, mock_post):
        """Test successful RPC call."""
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {"result": "success"}
        mock_post.return_value = mock_response

        client = ConnectRPCClient("test-token", base_url="https://api.example.com")
        result = client.call_rpc("TestMethod", {"param": "value"})

        assert result == {"result": "success"}
        mock_post.assert_called_once_with(
            "https://api.example.com/api/aiauto.v1.AIAutoService/TestMethod",
            json={"param": "value"},
            headers=client.headers,
            verify=True,
        )

    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_http_error_with_connect_rpc_error(self, mock_post):
        """Test RPC call with HTTP error containing Connect RPC error format."""
        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = HTTPStatus.NOT_FOUND
        mock_response.json.return_value = {"code": "not_found", "message": "Study not found"}
        mock_post.return_value = mock_response

        client = ConnectRPCClient("test-token", base_url="https://api.example.com")

        with pytest.raises(ConnectRPCError) as exc_info:
            client.call_rpc("TestMethod", {})

        assert exc_info.value.code == "not_found"
        assert exc_info.value.message == "Study not found"

    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_http_error_with_non_json_response(self, mock_post):
        """Test RPC call with HTTP error containing non-JSON response."""
        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = HTTPStatus.INTERNAL_SERVER_ERROR
        mock_response.json.side_effect = ValueError("No JSON")
        mock_response.text = "Internal Server Error"
        mock_post.return_value = mock_response

        client = ConnectRPCClient("test-token", base_url="https://api.example.com")

        with pytest.raises(RuntimeError, match=f"HTTP {HTTPStatus.INTERNAL_SERVER_ERROR}"):
            client.call_rpc("TestMethod", {})

    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_request_exception(self, mock_post):
        """Test RPC call with request exception (network error)."""
        mock_post.side_effect = requests.exceptions.RequestException("Connection failed")

        client = ConnectRPCClient("test-token", base_url="https://api.example.com")

        with pytest.raises(RuntimeError, match="Request failed"):
            client.call_rpc("TestMethod", {})

    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_http_error_with_json_unknown_code(self, mock_post):
        """Test RPC call with JSON error response with unknown code."""
        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = HTTPStatus.BAD_REQUEST
        # When no code/message, defaults to code="unknown", message="HTTP {status}"
        mock_response.json.return_value = {"error": "some other format"}
        mock_post.return_value = mock_response

        client = ConnectRPCClient("test-token", base_url="https://api.example.com")

        with pytest.raises(ConnectRPCError) as exc_info:
            client.call_rpc("TestMethod", {})

        assert exc_info.value.code == "unknown"
        assert exc_info.value.message == f"HTTP {HTTPStatus.BAD_REQUEST}"

    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_http_error_fallback_to_error_data(self, mock_post):
        """Test RPC call raises ConnectRPCError even when code/message are empty."""
        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = HTTPStatus.BAD_REQUEST
        # Both code and message are empty strings (falsy) — defaults applied
        mock_response.json.return_value = {"code": "", "message": "", "details": "extra info"}
        mock_post.return_value = mock_response

        client = ConnectRPCClient("test-token", base_url="https://api.example.com")

        with pytest.raises(ConnectRPCError) as exc_info:
            client.call_rpc("TestMethod", {})

        assert exc_info.value.code == "unknown"
        assert exc_info.value.message == f"HTTP {HTTPStatus.BAD_REQUEST}"


class TestWebhookErrorPropagation:
    """Test webhook error message propagation from server to client."""

    @patch("aiauto.http_client.requests.post")
    def test_webhook_denial_error_is_propagated(self, mock_post):
        """Test that webhook denial error message is properly received by client.

        When OptunaWorkspace creation is blocked by webhook (PVCs from previous
        workspace still exist), the error message should reach the client.
        """
        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = HTTPStatus.PRECONDITION_FAILED
        # This is the format the front server sends for webhook denial
        mock_response.json.return_value = {
            "code": "failed_precondition",
            "message": 'admission webhook "voptunaworkspace-v1.kb.io" denied the request: PVCs from previous workspace still exist',
        }
        mock_post.return_value = mock_response

        client = ConnectRPCClient("test-token", base_url="https://api.example.com")

        with pytest.raises(ConnectRPCError) as exc_info:
            client.call_rpc("EnsureWorkspace", {})

        assert exc_info.value.code == "failed_precondition"
        assert "PVCs from previous workspace still exist" in exc_info.value.message

    @patch("aiauto.http_client.requests.post")
    def test_webhook_denial_error_str_representation(self, mock_post):
        """Test that webhook denial error has readable string representation."""
        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = HTTPStatus.PRECONDITION_FAILED
        mock_response.json.return_value = {
            "code": "failed_precondition",
            "message": "PVCs from previous workspace still exist",
        }
        mock_post.return_value = mock_response

        client = ConnectRPCClient("test-token", base_url="https://api.example.com")

        with pytest.raises(ConnectRPCError) as exc_info:
            client.call_rpc("EnsureWorkspace", {})

        error_str = str(exc_info.value)
        assert "[failed_precondition]" in error_str
        assert "PVCs from previous workspace still exist" in error_str

    def test_failed_precondition_is_not_retryable(self):
        """Test that failed_precondition errors are NOT retryable.

        Webhook denial (e.g., PVC still deleting) is a permanent failure
        that won't resolve with automatic retries.
        User should wait and manually retry.
        """
        error = ConnectRPCError(
            "failed_precondition",
            "PVCs from previous workspace still exist",
        )
        # failed_precondition is NOT retryable - permanent failure
        assert error.is_retryable() is False


class TestModuleVersion:
    """Test _version module's get_version() and version propagation."""

    def test_version_is_string(self):
        """Test __version__ is a string."""
        import aiauto

        assert isinstance(aiauto.__version__, str)

    def test_version_is_not_empty(self):
        """Test __version__ is not empty."""
        import aiauto

        assert aiauto.__version__ != ""

    def test_get_version_returns_installed_version(self):
        """Test get_version() returns installed package version."""
        from aiauto._version import get_version

        with patch("aiauto._version.version", return_value="1.2.3"):
            assert get_version() == "1.2.3"

    def test_get_version_fallback_when_not_installed(self):
        """Test get_version() returns '0.0.0' when package is not installed."""
        from importlib.metadata import PackageNotFoundError

        from aiauto._version import get_version

        with patch("aiauto._version.version", side_effect=PackageNotFoundError("aiauto-client")):
            assert get_version() == "0.0.0"

    def test_get_version_rejects_pep440_suffix(self):
        """Test get_version() returns '0.0.0' for PEP 440 versions that aren't valid semver.

        pyproject.toml 버전이 0.3.0rc1 같은 PEP 440 형식이면 Front의 semver.valid()가
        거절하므로, Python 측에서 먼저 '0.0.0'으로 치환하여 명확한 에러를 유도한다.
        """
        from aiauto._version import get_version

        for pep440_version in ["0.3.0rc1", "0.3.0.post1", "0.3.0.dev1", "0.3.0a1"]:
            with patch("aiauto._version.version", return_value=pep440_version):
                assert get_version() == "0.0.0", f"PEP 440 '{pep440_version}' should be rejected"

    def test_get_version_accepts_valid_semver(self):
        """Test get_version() accepts standard X.Y.Z semver versions."""
        from aiauto._version import get_version

        for semver_version in ["0.2.6", "1.0.0", "10.20.30"]:
            with patch("aiauto._version.version", return_value=semver_version):
                assert get_version() == semver_version

    def test_http_client_version_matches_version_module(self):
        """Test http_client._CLIENT_VERSION comes from _version module."""
        import aiauto._version as version_module
        import aiauto.http_client as http_client_module

        assert version_module.__version__ == http_client_module._CLIENT_VERSION
