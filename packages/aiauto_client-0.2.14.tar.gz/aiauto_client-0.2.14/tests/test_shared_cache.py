"""Tests for shared-cache file management methods in AIAutoController (ConnectRPC).

Covers upload/list/delete operations, retry behavior, validation, and file handle cleanup.
"""

import json
from unittest.mock import MagicMock, patch

import pytest

from aiauto.core import AIAutoController
from aiauto.http_client import (
    ConnectRPCClient,
    ConnectRPCError,
)


@pytest.fixture
def mock_controller():
    """Create an AIAutoController with mocked dependencies (bypass __init__)."""
    ctrl = object.__new__(AIAutoController)
    ctrl.token = "test-token-abc"
    ctrl.client = MagicMock(spec=ConnectRPCClient)
    ctrl.client.base_url = "https://api.example.com"
    return ctrl


@pytest.fixture
def tmp_files(tmp_path):
    """Create temporary files for upload testing."""
    f1 = tmp_path / "train.csv"
    f1.write_text("col1,col2\n1,2\n")
    f2 = tmp_path / "test.csv"
    f2.write_text("col1,col2\n3,4\n")
    return str(f1), str(f2)


class TestUploadToSharedCache:
    """Test upload_to_shared_cache method (ConnectRPC client streaming)."""

    def test_single_file(self, mock_controller, tmp_files):
        resp_json = {"uploaded": ["train.csv"]}
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = json.dumps(resp_json)
        mock_controller.client._call_client_streaming.return_value = resp.SerializeToString()

        result = mock_controller.upload_to_shared_cache(tmp_files[0])

        assert result == resp_json
        mock_controller.client._call_client_streaming.assert_called_once()
        call_args = mock_controller.client._call_client_streaming.call_args
        assert call_args[0][0] == "UploadToSharedCache"

    def test_multiple_files(self, mock_controller, tmp_files):
        resp_json = {"uploaded": ["train.csv", "test.csv"]}
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = json.dumps(resp_json)
        mock_controller.client._call_client_streaming.return_value = resp.SerializeToString()

        result = mock_controller.upload_to_shared_cache(list(tmp_files))

        assert result == resp_json

    def test_with_dest_dir(self, mock_controller, tmp_files):
        """Verify file_info messages include dest_dir."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = json.dumps({"uploaded": ["data/train.csv"]})

        # Capture the request iterator to inspect messages
        captured_messages = []

        def capture_call(method, iterator, content_length=0):
            for msg in iterator:
                captured_messages.append(msg)
            return resp.SerializeToString()

        mock_controller.client._call_client_streaming.side_effect = capture_call

        mock_controller.upload_to_shared_cache(tmp_files[0], dest_dir="/data/")

        # First message should be file_info with dest_dir="data"
        assert len(captured_messages) >= 2  # at least file_info + 1 chunk
        file_info_msg = captured_messages[0]
        assert file_info_msg.HasField("file_info")
        assert file_info_msg.file_info.dest_dir == "data"
        assert file_info_msg.file_info.filename == "train.csv"

    def test_streaming_error_raises(self, mock_controller, tmp_files):
        mock_controller.client._call_client_streaming.side_effect = ConnectRPCError(
            "internal", "Upload failed"
        )

        with pytest.raises(ConnectRPCError, match="Upload failed"):
            mock_controller.upload_to_shared_cache(tmp_files[0])

    def test_empty_list_raises_value_error(self, mock_controller):
        with pytest.raises(ValueError, match="must not be empty"):
            mock_controller.upload_to_shared_cache([])

    def test_dest_dir_path_traversal_raises(self, mock_controller, tmp_files):
        with pytest.raises(ValueError, match="must not contain"):
            mock_controller.upload_to_shared_cache(tmp_files[0], dest_dir="../etc")

    def test_dest_dir_dotdot_only_raises(self, mock_controller, tmp_files):
        with pytest.raises(ValueError, match="must not contain"):
            mock_controller.upload_to_shared_cache(tmp_files[0], dest_dir="..")

    def test_dest_dir_middle_traversal_raises(self, mock_controller, tmp_files):
        with pytest.raises(ValueError, match="must not contain"):
            mock_controller.upload_to_shared_cache(tmp_files[0], dest_dir="data/../secret")

    def test_nonexistent_file_raises(self, mock_controller):
        """open() in calculation phase raises FileNotFoundError before streaming."""
        with pytest.raises(FileNotFoundError):
            mock_controller.upload_to_shared_cache("/nonexistent/path/file.csv")

        # _call_client_streaming should never be called
        mock_controller.client._call_client_streaming.assert_not_called()

    def test_dest_dir_null_byte_raises(self, mock_controller, tmp_files):
        with pytest.raises(ValueError, match="null bytes"):
            mock_controller.upload_to_shared_cache(tmp_files[0], dest_dir="data\x00evil")

    def test_file_path_null_byte_raises(self, mock_controller):
        with pytest.raises(ValueError, match="null bytes"):
            mock_controller.upload_to_shared_cache("/tmp/file\x00evil.csv")

    def test_empty_basename_raises(self, mock_controller):
        """os.path.basename('/') -> '' should raise ValueError."""
        with pytest.raises(ValueError, match="no filename"):
            mock_controller.upload_to_shared_cache("/")

    def test_trailing_slash_empty_basename_raises(self, mock_controller):
        """os.path.basename('dir/') -> '' should raise ValueError."""
        with pytest.raises(ValueError, match="no filename"):
            mock_controller.upload_to_shared_cache("dir/")

    def test_filename_exceeds_255_bytes_raises(self, mock_controller):
        """Filename longer than 255 bytes should raise ValueError."""
        long_name = "a" * 256
        with pytest.raises(ValueError, match="exceeds 255 bytes"):
            mock_controller.upload_to_shared_cache(f"/tmp/{long_name}")

    def test_fstat_failure_closes_all_handles(self, tmp_files):
        """If fstat() fails on 2nd file, both handles are closed by outer except."""
        mock_stat1 = MagicMock()
        mock_stat1.st_size = 10

        mock_fh1 = MagicMock()
        mock_fh1.fileno.return_value = 3

        mock_fh2 = MagicMock()
        mock_fh2.fileno.return_value = 4

        with patch("builtins.open", side_effect=[mock_fh1, mock_fh2]), patch(
            "os.fstat", side_effect=[mock_stat1, OSError("fstat failed")]
        ), pytest.raises(OSError, match="fstat failed"):
            ctrl = object.__new__(AIAutoController)
            ctrl.upload_to_shared_cache(list(tmp_files))

        # Both handles closed: fh2 registered immediately after open(),
        # outer except closes all entries including the failed one
        mock_fh1.close.assert_called_once()
        mock_fh2.close.assert_called_once()

    def test_empty_response_returns_empty_dict(self, mock_controller, tmp_files):
        """When UploadToSharedCacheResponse has empty json_response, return {}."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        # json_response defaults to empty string
        mock_controller.client._call_client_streaming.return_value = resp.SerializeToString()

        result = mock_controller.upload_to_shared_cache(tmp_files[0])
        assert result == {}

    def test_string_input_converted_to_list(self, mock_controller, tmp_files):
        """Test that a single string path is automatically wrapped in a list."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = "{}"
        mock_controller.client._call_client_streaming.return_value = resp.SerializeToString()

        mock_controller.upload_to_shared_cache(tmp_files[0])

        mock_controller.client._call_client_streaming.assert_called_once()


class TestUploadResponseParsing:
    """Test upload_to_shared_cache response parsing error handling (Fix 2 검증)."""

    @pytest.fixture
    def mock_controller(self):
        ctrl = object.__new__(AIAutoController)
        ctrl.token = "test-token-abc"
        ctrl.client = MagicMock(spec=ConnectRPCClient)
        ctrl.client.base_url = "https://api.example.com"
        return ctrl

    def test_malformed_protobuf_raises_runtime_error(self, mock_controller, tmp_path):
        """잘못된 protobuf bytes -> RuntimeError 래핑."""
        f = tmp_path / "data.csv"
        f.write_text("a,b\n1,2\n")

        # 유효하지 않은 protobuf bytes 반환
        mock_controller.client._call_client_streaming.return_value = b"\xff\xff\xff"

        with pytest.raises(RuntimeError, match="Failed to parse upload response"):
            mock_controller.upload_to_shared_cache(str(f))

    def test_malformed_json_raises_runtime_error(self, mock_controller, tmp_path):
        """유효 protobuf + 잘못된 JSON string -> RuntimeError 래핑."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        f = tmp_path / "data.csv"
        f.write_text("a,b\n1,2\n")

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = "{invalid json!!"
        mock_controller.client._call_client_streaming.return_value = resp.SerializeToString()

        with pytest.raises(RuntimeError, match="Failed to decode upload response JSON"):
            mock_controller.upload_to_shared_cache(str(f))


class TestListSharedCache:
    """Test list_shared_cache method (ConnectRPC unary)."""

    def test_success(self, mock_controller):
        mock_controller.client.call_rpc.return_value = {
            "jsonResponse": json.dumps({"files": ["train.csv", "test.csv"]})
        }

        result = mock_controller.list_shared_cache()

        assert result == {"files": ["train.csv", "test.csv"]}
        mock_controller.client.call_rpc.assert_called_once_with("ListSharedCache", {})

    def test_empty_response(self, mock_controller):
        mock_controller.client.call_rpc.return_value = {"jsonResponse": "{}"}

        result = mock_controller.list_shared_cache()

        assert result == {}

    def test_missing_json_response_field(self, mock_controller):
        """When jsonResponse field is missing, should return empty dict."""
        mock_controller.client.call_rpc.return_value = {}

        result = mock_controller.list_shared_cache()

        assert result == {}

    def test_rpc_error_raises(self, mock_controller):
        mock_controller.client.call_rpc.side_effect = ConnectRPCError(
            "unauthenticated", "Invalid token"
        )

        with pytest.raises(ConnectRPCError, match="Invalid token"):
            mock_controller.list_shared_cache()


class TestDeleteFromSharedCache:
    """Test delete_from_shared_cache method (ConnectRPC unary)."""

    def test_success(self, mock_controller):
        mock_controller.client.call_rpc.return_value = {
            "jsonResponse": json.dumps({"deleted": "data/train.csv"})
        }

        result = mock_controller.delete_from_shared_cache("data/train.csv")

        assert result == {"deleted": "data/train.csv"}
        mock_controller.client.call_rpc.assert_called_once_with(
            "DeleteFromSharedCache", {"path": "data/train.csv"}
        )

    def test_empty_path_raises_value_error(self, mock_controller):
        with pytest.raises(ValueError, match="must not be empty"):
            mock_controller.delete_from_shared_cache("")

    def test_path_traversal_raises(self, mock_controller):
        with pytest.raises(ValueError, match="must not contain"):
            mock_controller.delete_from_shared_cache("../etc/passwd")

    def test_path_dotdot_only_raises(self, mock_controller):
        with pytest.raises(ValueError, match="must not contain"):
            mock_controller.delete_from_shared_cache("..")

    def test_path_middle_traversal_raises(self, mock_controller):
        with pytest.raises(ValueError, match="must not contain"):
            mock_controller.delete_from_shared_cache("data/../secret")

    def test_rpc_error_raises(self, mock_controller):
        mock_controller.client.call_rpc.side_effect = ConnectRPCError("not_found", "File not found")

        with pytest.raises(ConnectRPCError, match="File not found"):
            mock_controller.delete_from_shared_cache("nonexistent.csv")


class TestUploadMultiFileProtocol:
    """Test the multi-file upload protocol message ordering."""

    def test_multi_file_message_order(self, mock_controller, tmp_files):
        """Verify file_info -> chunks -> file_info -> chunks ordering for 2 files."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = json.dumps({"uploaded": ["train.csv", "test.csv"]})

        captured = []

        def capture(method, iterator, content_length=0):
            for msg in iterator:
                captured.append(msg)
            return resp.SerializeToString()

        mock_controller.client._call_client_streaming.side_effect = capture

        mock_controller.upload_to_shared_cache(list(tmp_files))

        # Expected: file_info(train.csv), chunk(s), file_info(test.csv), chunk(s)
        # Each file is small enough to fit in 1 chunk (1MB chunk_size)
        assert len(captured) == 4  # 2 files x (1 file_info + 1 chunk)

        # File 1: file_info
        assert captured[0].HasField("file_info")
        assert captured[0].file_info.filename == "train.csv"
        # File 1: chunk
        assert captured[1].HasField("chunk_data")
        assert captured[1].chunk_data == b"col1,col2\n1,2\n"

        # File 2: file_info
        assert captured[2].HasField("file_info")
        assert captured[2].file_info.filename == "test.csv"
        # File 2: chunk
        assert captured[3].HasField("chunk_data")
        assert captured[3].chunk_data == b"col1,col2\n3,4\n"

    def test_dest_dir_none_sends_empty_string(self, mock_controller, tmp_files):
        """When dest_dir is None, file_info.dest_dir should be empty string."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = "{}"

        captured = []

        def capture(method, iterator, content_length=0):
            for msg in iterator:
                captured.append(msg)
            return resp.SerializeToString()

        mock_controller.client._call_client_streaming.side_effect = capture

        mock_controller.upload_to_shared_cache(tmp_files[0], dest_dir=None)

        file_info_msg = captured[0]
        assert file_info_msg.HasField("file_info")
        assert file_info_msg.file_info.dest_dir == ""


class TestDeleteSpecialPaths:
    """Test delete_from_shared_cache with special characters in path."""

    def test_special_characters_in_path(self, mock_controller):
        """Path with spaces and unicode should be passed through to call_rpc."""
        mock_controller.client.call_rpc.return_value = {
            "jsonResponse": json.dumps({"deleted": "data/my file (1).csv"})
        }

        result = mock_controller.delete_from_shared_cache("data/my file (1).csv")

        assert result == {"deleted": "data/my file (1).csv"}
        mock_controller.client.call_rpc.assert_called_once_with(
            "DeleteFromSharedCache", {"path": "data/my file (1).csv"}
        )

    def test_unicode_path(self, mock_controller):
        """Path with unicode characters should work."""
        mock_controller.client.call_rpc.return_value = {
            "jsonResponse": json.dumps({"deleted": "데이터/학습.csv"})
        }

        result = mock_controller.delete_from_shared_cache("데이터/학습.csv")

        assert result == {"deleted": "데이터/학습.csv"}

    def test_absolute_path_rejected(self, mock_controller):
        """Absolute path should be rejected."""
        with pytest.raises(ValueError, match="path must be relative"):
            mock_controller.delete_from_shared_cache("/etc/passwd")

    def test_null_byte_rejected(self, mock_controller):
        """Path containing null byte should be rejected."""
        with pytest.raises(ValueError, match="null bytes"):
            mock_controller.delete_from_shared_cache("file\x00.csv")

    def test_dotdot_in_filename_not_segment(self, mock_controller):
        """Filename containing '..' as substring (not path segment) should be allowed."""
        mock_controller.client.call_rpc.return_value = {
            "jsonResponse": json.dumps({"deleted": "file..backup.csv"})
        }

        # "file..backup.csv".split("/") == ["file..backup.csv"]
        # ".." not in ["file..backup.csv"], so this should pass
        result = mock_controller.delete_from_shared_cache("file..backup.csv")
        assert result == {"deleted": "file..backup.csv"}


class TestFileHandleCleanup:
    """Test TOCTOU fix: file handle lifecycle in upload_to_shared_cache."""

    @pytest.fixture
    def mock_controller(self):
        ctrl = object.__new__(AIAutoController)
        ctrl.token = "test-token-abc"
        ctrl.client = MagicMock(spec=ConnectRPCClient)
        ctrl.client.base_url = "https://api.example.com"
        return ctrl

    def test_handles_closed_after_normal_upload(self, mock_controller, tmp_path):
        """정상 업로드 완료 후 모든 파일 핸들이 닫혀야 함."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        f1 = tmp_path / "a.csv"
        f1.write_text("data1")
        f2 = tmp_path / "b.csv"
        f2.write_text("data2")

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = "{}"

        opened_handles = []
        real_open = open

        def tracking_open(path, mode="r", **kwargs):
            fh = real_open(path, mode, **kwargs)
            opened_handles.append(fh)
            return fh

        with patch("builtins.open", side_effect=tracking_open):

            def consume(method, iterator, content_length=0):
                for _ in iterator:
                    pass
                return resp.SerializeToString()

            mock_controller.client._call_client_streaming.side_effect = consume
            mock_controller.upload_to_shared_cache([str(f1), str(f2)])

        assert len(opened_handles) == 2
        for fh in opened_handles:
            assert fh.closed, f"File handle {fh.name} was not closed after upload"

    def test_handles_closed_on_calculation_phase_error(self, mock_controller, tmp_path):
        """2번째 파일 open 실패 시 1번째 핸들이 정리되어야 함 (except 블록)."""
        f1 = tmp_path / "valid.csv"
        f1.write_text("data")

        opened_handles = []
        real_open = open

        def tracking_open(path, mode="r", **kwargs):
            fh = real_open(path, mode, **kwargs)
            opened_handles.append(fh)
            return fh

        with patch("builtins.open", side_effect=tracking_open):  # noqa: SIM117
            with pytest.raises(FileNotFoundError):
                mock_controller.upload_to_shared_cache([str(f1), "/nonexistent/missing.csv"])

        # 1번째 핸들은 열렸다가 닫혀야 함
        assert len(opened_handles) == 1
        assert opened_handles[0].closed, (
            "First file handle was not closed when second file open failed"
        )

    def test_handles_closed_on_iterator_error(self, mock_controller, tmp_path):
        """네트워크 에러 발생 시 try/finally의 gen.close()로 핸들이 즉시 정리됨.

        upload_to_shared_cache()는 _call_client_streaming 호출을 try/finally로
        감싸서 예외 시 generator를 명시적으로 close한다. 이로써 CPython GC에
        의존하지 않고 모든 런타임에서 파일 핸들이 즉시 정리된다.
        """
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        f1 = tmp_path / "c.csv"
        f1.write_text("data")

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = "{}"

        opened_handles = []
        real_open = open

        def tracking_open(path, mode="r", **kwargs):
            fh = real_open(path, mode, **kwargs)
            opened_handles.append(fh)
            return fh

        with patch("builtins.open", side_effect=tracking_open):

            def partial_consume_then_error(method, iterator, content_length=0):
                # 첫 메시지(file_info)만 소비하고 에러
                next(iterator)
                raise ConnectionError("upload interrupted")

            mock_controller.client._call_client_streaming.side_effect = partial_consume_then_error

            with pytest.raises(ConnectionError, match="upload interrupted"):
                mock_controller.upload_to_shared_cache(str(f1))

        assert len(opened_handles) == 1
        # gen.close()가 finally에서 호출되어 핸들이 이미 닫혀 있어야 함
        assert opened_handles[0].closed, "File handle was not closed after network error"

    def test_handles_closed_on_partial_iterator_consume(self, mock_controller, tmp_path):
        """Iterator 부분 소비 후 try/finally의 gen.close()로 핸들이 즉시 정리됨.

        _call_client_streaming이 generator를 부분 소비 후 정상 반환해도,
        upload_to_shared_cache의 finally에서 gen.close()가 호출되어
        GeneratorExit -> finally -> 파일 핸들 close 경로가 보장된다.
        """
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        # 2MB 파일 -> 2개 chunk. 첫 chunk만 소비 후 중단.
        chunk_size = 1024 * 1024
        big_file = tmp_path / "big.bin"
        big_file.write_bytes(b"\x00" * (chunk_size + 100))

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = "{}"

        opened_handles = []
        real_open = open

        def tracking_open(path, mode="r", **kwargs):
            fh = real_open(path, mode, **kwargs)
            opened_handles.append(fh)
            return fh

        with patch("builtins.open", side_effect=tracking_open):

            def partial_consume(method, iterator, content_length=0):
                # file_info + 첫 chunk만 소비, 2번째 chunk는 소비 안 함
                next(iterator)  # file_info
                next(iterator)  # first chunk
                return resp.SerializeToString()

            mock_controller.client._call_client_streaming.side_effect = partial_consume
            mock_controller.upload_to_shared_cache(str(big_file))

        assert len(opened_handles) == 1
        # gen.close()가 finally에서 호출되어 핸들이 이미 닫혀 있어야 함
        assert opened_handles[0].closed, "File handle was not closed after partial consume"


class TestValidateDestDir:
    """Test AIAutoController._validate_dest_dir static method directly."""

    def test_none_returns_empty(self):
        """None input -> 빈 문자열 반환 (falsy 분기)."""
        result = AIAutoController._validate_dest_dir(None)
        assert result == ""

    def test_empty_string_returns_empty(self):
        """빈 문자열 -> 그대로 반환 (falsy 분기)."""
        result = AIAutoController._validate_dest_dir("")
        assert result == ""

    def test_whitespace_only_returns_empty(self):
        """공백만 있는 문자열 -> strip 후 빈 문자열 반환."""
        result = AIAutoController._validate_dest_dir("   ")
        assert result == ""

    def test_strips_leading_trailing_slashes(self):
        """앞뒤 슬래시 제거 (strip('/'))."""
        result = AIAutoController._validate_dest_dir("/data/subdir/")
        assert result == "data/subdir"

    def test_normal_path_passthrough(self):
        """정상 경로 -> 그대로 반환."""
        result = AIAutoController._validate_dest_dir("data/subdir")
        assert result == "data/subdir"

    def test_dotdot_as_filename_substring_allowed(self):
        """'..'이 path segment가 아닌 파일명 substring이면 허용."""
        # "dir..name".split("/") == ["dir..name"], ".." not in -> 허용
        result = AIAutoController._validate_dest_dir("dir..name")
        assert result == "dir..name"

    def test_dotdot_path_segment_raises(self):
        """'..'이 path segment이면 ValueError."""
        with pytest.raises(ValueError, match="must not contain"):
            AIAutoController._validate_dest_dir("data/../secret")

    def test_null_byte_raises(self):
        """null byte 포함 시 ValueError."""
        with pytest.raises(ValueError, match="null bytes"):
            AIAutoController._validate_dest_dir("data\x00evil")

    def test_slash_only_returns_empty(self):
        """'/' 만 입력 -> strip('/') 후 빈 문자열."""
        result = AIAutoController._validate_dest_dir("/")
        assert result == ""

    def test_whitespace_with_slashes(self):
        """공백+슬래시 조합 -> strip().strip('/') 후 빈 문자열."""
        result = AIAutoController._validate_dest_dir("  /  ")
        assert result == ""


class TestCheckNoNullBytes:
    """Test AIAutoController._check_no_null_bytes static method directly."""

    def test_normal_string_passes(self):
        """정상 문자열은 에러 없이 통과."""
        # Should not raise
        AIAutoController._check_no_null_bytes("normal/path/file.csv", "test_param")

    def test_null_byte_raises_with_param_name(self):
        """null byte 포함 시 ValueError, 파라미터 이름이 메시지에 포함."""
        with pytest.raises(ValueError, match="dest_dir must not contain null bytes"):
            AIAutoController._check_no_null_bytes("path\x00evil", "dest_dir")

    def test_empty_string_passes(self):
        """빈 문자열은 null byte 없으므로 통과."""
        AIAutoController._check_no_null_bytes("", "param")

    def test_unicode_passes(self):
        """유니코드 문자열은 null byte 없으면 통과."""
        AIAutoController._check_no_null_bytes("데이터/학습.csv", "path")


class TestSharedCacheRetry:
    """Test retry behavior on shared-cache methods when service is unavailable.

    tenacity.nap.time.sleep is patched to eliminate actual wait_fixed(10) delays.
    Without this, each retry test would wait 10+ seconds per retry attempt.
    """

    @pytest.fixture(autouse=True)
    def _no_tenacity_sleep(self):
        with patch("tenacity.nap.time.sleep", return_value=None):
            yield

    @pytest.fixture
    def mock_controller(self):
        ctrl = object.__new__(AIAutoController)
        ctrl.token = "test-token-abc"
        ctrl.client = MagicMock(spec=ConnectRPCClient)
        ctrl.client.base_url = "https://api.example.com"
        return ctrl

    def test_upload_retries_on_unavailable(self, mock_controller, tmp_path):
        """upload_to_shared_cache should retry on ConnectRPCError(unavailable)."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        f = tmp_path / "data.csv"
        f.write_text("a,b\n1,2\n")

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = json.dumps({"uploaded": ["data.csv"]})

        # Fail once with unavailable, then succeed
        mock_controller.client._call_client_streaming.side_effect = [
            ConnectRPCError("unavailable", "Service unavailable"),
            resp.SerializeToString(),
        ]

        result = mock_controller.upload_to_shared_cache(str(f))
        assert result == {"uploaded": ["data.csv"]}
        assert mock_controller.client._call_client_streaming.call_count == 2

    def test_upload_no_retry_on_internal(self, mock_controller, tmp_path):
        """upload_to_shared_cache should NOT retry on non-retryable errors."""
        f = tmp_path / "data.csv"
        f.write_text("a,b\n1,2\n")

        mock_controller.client._call_client_streaming.side_effect = ConnectRPCError(
            "internal", "Server error"
        )

        with pytest.raises(ConnectRPCError) as exc_info:
            mock_controller.upload_to_shared_cache(str(f))

        assert exc_info.value.code == "internal"
        assert mock_controller.client._call_client_streaming.call_count == 1

    def test_list_retries_on_unavailable(self, mock_controller):
        """list_shared_cache should retry on ConnectRPCError(unavailable)."""
        mock_controller.client.call_rpc.side_effect = [
            ConnectRPCError("unavailable", "Service unavailable"),
            {"jsonResponse": json.dumps({"files": ["a.csv"]})},
        ]

        result = mock_controller.list_shared_cache()
        assert result == {"files": ["a.csv"]}
        assert mock_controller.client.call_rpc.call_count == 2

    def test_delete_retries_on_unavailable(self, mock_controller):
        """delete_from_shared_cache should retry on ConnectRPCError(unavailable)."""
        mock_controller.client.call_rpc.side_effect = [
            ConnectRPCError("unavailable", "Service unavailable"),
            {"jsonResponse": json.dumps({"deleted": "a.csv"})},
        ]

        result = mock_controller.delete_from_shared_cache("a.csv")
        assert result == {"deleted": "a.csv"}
        assert mock_controller.client.call_rpc.call_count == 2

    def test_upload_no_retry_on_validation_error(self, mock_controller):
        """Validation errors (ValueError) should not trigger retry."""
        with pytest.raises(ValueError, match="must not be empty"):
            mock_controller.upload_to_shared_cache([])

    def test_list_no_retry_on_auth_error(self, mock_controller):
        """Auth errors should not trigger retry."""
        mock_controller.client.call_rpc.side_effect = ConnectRPCError(
            "unauthenticated", "Invalid token"
        )

        with pytest.raises(ConnectRPCError) as exc_info:
            mock_controller.list_shared_cache()

        assert exc_info.value.code == "unauthenticated"
        assert mock_controller.client.call_rpc.call_count == 1

    def test_delete_no_retry_on_not_found(self, mock_controller):
        """delete_from_shared_cache should NOT retry on not_found errors."""
        mock_controller.client.call_rpc.side_effect = ConnectRPCError("not_found", "File not found")

        with pytest.raises(ConnectRPCError) as exc_info:
            mock_controller.delete_from_shared_cache("missing.csv")

        assert exc_info.value.code == "not_found"
        assert mock_controller.client.call_rpc.call_count == 1

    def test_upload_multiple_retries_on_unavailable(self, mock_controller, tmp_path):
        """upload_to_shared_cache retries multiple times before succeeding."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        f = tmp_path / "data.csv"
        f.write_text("a,b\n1,2\n")

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = json.dumps({"uploaded": ["data.csv"]})

        # Fail 3 times with unavailable, then succeed on 4th call
        mock_controller.client._call_client_streaming.side_effect = [
            ConnectRPCError("unavailable", "Service unavailable"),
            ConnectRPCError("unavailable", "Service unavailable"),
            ConnectRPCError("unavailable", "Service unavailable"),
            resp.SerializeToString(),
        ]

        result = mock_controller.upload_to_shared_cache(str(f))
        assert result == {"uploaded": ["data.csv"]}
        assert mock_controller.client._call_client_streaming.call_count == 4
