"""Tests for ConnectRPC protocol handling in http_client.py.

Covers _parse_streaming_response, _check_eos_error, _call_client_streaming,
_raise_for_status, ConnectionError conversion, and base_url scheme validation.
"""

import json
import struct
from unittest.mock import MagicMock, patch

import pytest
import requests

from aiauto.http_client import (
    ConnectRPCClient,
    ConnectRPCError,
)


class TestParseStreamingResponse:
    """Test ConnectRPCClient._parse_streaming_response static method."""

    def test_data_frame_only(self):
        """Test parsing a response with just a data frame."""
        data = b"hello protobuf"
        body = struct.pack(">BI", 0x00, len(data)) + data

        result = ConnectRPCClient._parse_streaming_response(body)
        assert result == data

    def test_data_frame_plus_eos(self):
        """Test parsing a response with data frame + EOS frame."""
        data = b"response data"
        body = struct.pack(">BI", 0x00, len(data)) + data

        eos = b"{}"
        body += struct.pack(">BI", 0x02, len(eos)) + eos

        result = ConnectRPCClient._parse_streaming_response(body)
        assert result == data

    def test_eos_with_error_raises(self):
        """Test that EOS frame with error raises ConnectRPCError."""
        data = b"partial data"
        body = struct.pack(">BI", 0x00, len(data)) + data

        eos = json.dumps({"error": {"code": "internal", "message": "server error"}}).encode()
        body += struct.pack(">BI", 0x02, len(eos)) + eos

        with pytest.raises(ConnectRPCError) as exc_info:
            ConnectRPCClient._parse_streaming_response(body)

        assert exc_info.value.code == "internal"
        assert exc_info.value.message == "server error"

    def test_empty_body(self):
        """Test parsing empty response body raises RuntimeError."""
        with pytest.raises(RuntimeError, match="Empty streaming response"):
            ConnectRPCClient._parse_streaming_response(b"")

    def test_eos_only_no_data(self):
        """Test parsing a response with only EOS frame (no data)."""
        eos = b"{}"
        body = struct.pack(">BI", 0x02, len(eos)) + eos

        result = ConnectRPCClient._parse_streaming_response(body)
        assert result == b""

    def test_truncated_header_raises(self):
        """Incomplete frame header (< 5 bytes) should raise RuntimeError."""
        # 3 bytes is not enough for flags(1) + length(4)
        body = b"\x00\x00\x00"

        with pytest.raises(RuntimeError, match="Truncated streaming frame header"):
            ConnectRPCClient._parse_streaming_response(body)

    def test_truncated_payload_raises(self):
        """Frame header claims more data than available -> raise RuntimeError."""
        # Header says 100 bytes, but only 3 bytes follow
        body = struct.pack(">BI", 0x00, 100) + b"abc"

        with pytest.raises(RuntimeError, match="Truncated streaming frame data"):
            ConnectRPCClient._parse_streaming_response(body)

    def test_multiple_data_frames_takes_first(self):
        """Only the first data frame is returned; subsequent data frames are ignored."""
        first = b"first-payload"
        second = b"second-payload"
        body = struct.pack(">BI", 0x00, len(first)) + first
        body += struct.pack(">BI", 0x00, len(second)) + second

        result = ConnectRPCClient._parse_streaming_response(body)
        assert result == first

    def test_eos_empty_length_no_error(self):
        """EOS frame with length=0 should not raise (no JSON to parse)."""
        data = b"payload"
        body = struct.pack(">BI", 0x00, len(data)) + data
        # EOS with 0-length payload -> condition `if length > 0` is False -> skip
        body += struct.pack(">BI", 0x02, 0)

        result = ConnectRPCClient._parse_streaming_response(body)
        assert result == data


class TestCheckEosError:
    """Test ConnectRPCClient._check_eos_error static method directly."""

    def test_error_present_raises(self):
        """EOS frame containing error should raise ConnectRPCError."""
        frame = json.dumps({"error": {"code": "aborted", "message": "conflict"}}).encode()

        with pytest.raises(ConnectRPCError) as exc_info:
            ConnectRPCClient._check_eos_error(frame)

        assert exc_info.value.code == "aborted"
        assert exc_info.value.message == "conflict"

    def test_no_error_key_passes(self):
        """EOS frame without 'error' key should not raise."""
        frame = json.dumps({"status": "ok"}).encode()
        # Should not raise
        ConnectRPCClient._check_eos_error(frame)

    def test_malformed_json_passes(self):
        """Non-JSON EOS frame should not raise (caught by except ValueError)."""
        frame = b"this is not json"
        # Should not raise
        ConnectRPCClient._check_eos_error(frame)

    def test_empty_json_passes(self):
        """Empty JSON object should not raise."""
        frame = b"{}"
        ConnectRPCClient._check_eos_error(frame)

    def test_error_missing_code_uses_default(self):
        """Error without 'code' key should default to 'unknown'."""
        frame = json.dumps({"error": {"message": "something went wrong"}}).encode()

        with pytest.raises(ConnectRPCError) as exc_info:
            ConnectRPCClient._check_eos_error(frame)

        assert exc_info.value.code == "unknown"

    def test_error_missing_message_uses_default(self):
        """Error without 'message' key should default to 'streaming error'."""
        frame = json.dumps({"error": {"code": "internal"}}).encode()

        with pytest.raises(ConnectRPCError) as exc_info:
            ConnectRPCClient._check_eos_error(frame)

        assert exc_info.value.message == "streaming error"


class TestCallClientStreaming:
    """Test ConnectRPCClient._call_client_streaming method."""

    @pytest.fixture
    def client(self):
        """Create a ConnectRPCClient with test token."""
        return ConnectRPCClient(token="test-tok", base_url="https://api.test.com")

    def _make_ok_response(self, data=b"response-data"):
        """Build a mock Response with a valid streaming body (data + EOS)."""
        body = struct.pack(">BI", 0x00, len(data)) + data
        eos = b"{}"
        body += struct.pack(">BI", 0x02, len(eos)) + eos

        resp = MagicMock(spec=requests.Response)
        resp.ok = True
        resp.content = body
        return resp

    @patch("aiauto.http_client.requests.post")
    def test_frame_encoding(self, mock_post, client):
        """Each message should be encoded as [0x00][4B BE length][serialized data]."""
        mock_post.return_value = self._make_ok_response()

        msg1 = MagicMock()
        msg1.SerializeToString.return_value = b"msg-one"
        msg2 = MagicMock()
        msg2.SerializeToString.return_value = b"msg-two"

        # 2 frames: each 5B header + 7B data = 24B total
        total_size = (5 + 7) + (5 + 7)
        client._call_client_streaming("TestMethod", [msg1, msg2], content_length=total_size)

        # Verify the request was made
        mock_post.assert_called_once()
        call_kwargs = mock_post.call_args

        # Verify URL
        assert call_kwargs[0][0] == "https://api.test.com/api/aiauto.v1.AIAutoService/TestMethod"

        # Verify headers
        headers = call_kwargs[1]["headers"]
        assert headers["Content-Type"] == "application/connect+proto"
        assert headers["Connect-Protocol-Version"] == "1"
        assert headers["Authorization"] == "Bearer test-tok"

        # Verify _StreamingBody is used (has read() and __len__())
        body = call_kwargs[1]["data"]
        assert hasattr(body, "read")
        assert len(body) == total_size

        # Read all frames and verify content
        all_data = body.read(-1)
        expected1 = struct.pack(">BI", 0x00, 7) + b"msg-one"
        expected2 = struct.pack(">BI", 0x00, 7) + b"msg-two"
        assert all_data == expected1 + expected2

    @patch("aiauto.http_client.requests.post")
    def test_http_error_json_raises_connect_error(self, mock_post, client):
        """Non-OK response with JSON error body should raise ConnectRPCError."""
        resp = MagicMock(spec=requests.Response)
        resp.ok = False
        resp.status_code = 403
        resp.json.return_value = {"code": "permission_denied", "message": "forbidden"}
        mock_post.return_value = resp

        with pytest.raises(ConnectRPCError) as exc_info:
            client._call_client_streaming("Upload", iter([]), content_length=0)

        assert exc_info.value.code == "permission_denied"
        assert "forbidden" in exc_info.value.message

    @patch("aiauto.http_client.requests.post")
    def test_http_error_non_json_raises_runtime_error(self, mock_post, client):
        """Non-OK response with non-JSON body should raise RuntimeError."""
        resp = MagicMock(spec=requests.Response)
        resp.ok = False
        resp.status_code = 502
        resp.json.side_effect = ValueError("No JSON")
        resp.text = "Bad Gateway"
        mock_post.return_value = resp

        with pytest.raises(RuntimeError, match="HTTP 502"):
            client._call_client_streaming("Upload", iter([]), content_length=0)

    @patch("aiauto.http_client.requests.post")
    def test_empty_iterator(self, mock_post, client):
        """Empty iterator should still make the HTTP call and parse response."""
        mock_post.return_value = self._make_ok_response(b"empty-resp")

        result = client._call_client_streaming("Upload", iter([]), content_length=0)

        assert result == b"empty-resp"
        mock_post.assert_called_once()

        # Verify _StreamingBody with size 0
        body = mock_post.call_args[1]["data"]
        assert len(body) == 0
        assert body.read(-1) == b""

    @patch("aiauto.http_client.requests.post")
    def test_returns_parsed_data_frame(self, mock_post, client):
        """Should return the first data frame bytes from the streaming response."""
        payload = b"protobuf-bytes-here"
        mock_post.return_value = self._make_ok_response(payload)

        result = client._call_client_streaming("Method", iter([]), content_length=0)

        assert result == payload

    @patch("aiauto.http_client.requests.post")
    def test_connection_error_raises_unavailable(self, mock_post, client):
        """ConnectionError (ECONNREFUSED etc.) should raise ConnectRPCError(unavailable)."""
        mock_post.side_effect = requests.exceptions.ConnectionError("Connection refused")

        with pytest.raises(ConnectRPCError) as exc_info:
            client._call_client_streaming("Upload", iter([]), content_length=0)

        assert exc_info.value.code == "unavailable"
        assert "connection failed" in exc_info.value.message

    @patch("aiauto.http_client.requests.post")
    def test_timeout_raises_runtime_error(self, mock_post, client):
        """Timeout should raise RuntimeError."""
        mock_post.side_effect = requests.exceptions.Timeout("Read timed out")

        with pytest.raises(RuntimeError, match="Request failed"):
            client._call_client_streaming("Upload", iter([]), content_length=0)


class TestRaiseForStatus:
    """Test ConnectRPCClient._raise_for_status independently."""

    def test_json_error_raises_connect_error(self):
        """JSON body with code/message -> ConnectRPCError."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 403
        resp.json.return_value = {"code": "permission_denied", "message": "forbidden"}

        with pytest.raises(ConnectRPCError) as exc_info:
            ConnectRPCClient._raise_for_status(resp)

        assert exc_info.value.code == "permission_denied"
        assert exc_info.value.message == "forbidden"

    def test_json_error_missing_code_defaults_unknown(self):
        """JSON body without 'code' key -> defaults to 'unknown'."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 500
        resp.json.return_value = {"message": "internal error"}

        with pytest.raises(ConnectRPCError) as exc_info:
            ConnectRPCClient._raise_for_status(resp)

        assert exc_info.value.code == "unknown"
        assert exc_info.value.message == "internal error"

    def test_json_error_missing_message_defaults_http_code(self):
        """JSON body without 'message' key -> defaults to HTTP status code."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 418
        resp.json.return_value = {"code": "aborted"}

        with pytest.raises(ConnectRPCError) as exc_info:
            ConnectRPCClient._raise_for_status(resp)

        assert exc_info.value.code == "aborted"
        assert exc_info.value.message == "HTTP 418"

    def test_non_json_raises_runtime_error(self):
        """Non-JSON body -> RuntimeError with status code and text."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 502
        resp.json.side_effect = ValueError("No JSON")
        resp.text = "Bad Gateway"

        with pytest.raises(RuntimeError, match="HTTP 502.*Bad Gateway"):
            ConnectRPCClient._raise_for_status(resp)

    def test_empty_json_raises_connect_error_with_defaults(self):
        """Empty JSON {} -> ConnectRPCError with default code/message."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 500
        resp.json.return_value = {}

        with pytest.raises(ConnectRPCError) as exc_info:
            ConnectRPCClient._raise_for_status(resp)

        assert exc_info.value.code == "unknown"
        assert exc_info.value.message == "HTTP 500"

    def test_non_dict_json_raises_runtime_error(self):
        """JSON array/string/number -> RuntimeError (not ConnectRPCError)."""
        for non_dict in [[1, 2], "string", 42, True]:
            resp = MagicMock(spec=requests.Response)
            resp.status_code = 500
            resp.json.return_value = non_dict
            resp.text = str(non_dict)

            with pytest.raises(RuntimeError, match="HTTP 500"):
                ConnectRPCClient._raise_for_status(resp)


class TestCallClientStreamingDetails:
    """Test _call_client_streaming 세부 파라미터 검증."""

    @pytest.fixture
    def client(self):
        return ConnectRPCClient(token="test-tok", base_url="https://api.test.com")

    def _make_ok_response(self, data=b"resp"):
        body = struct.pack(">BI", 0x00, len(data)) + data
        eos = b"{}"
        body += struct.pack(">BI", 0x02, len(eos)) + eos
        resp = MagicMock(spec=requests.Response)
        resp.ok = True
        resp.content = body
        return resp

    @patch("aiauto.http_client.requests.post")
    def test_timeout_parameter(self, mock_post, client):
        """timeout=(10, 7200)이 requests.post에 전달되는지 검증."""
        mock_post.return_value = self._make_ok_response()

        client._call_client_streaming("Upload", iter([]), content_length=0)

        call_kwargs = mock_post.call_args[1]
        assert call_kwargs["timeout"] == (10, 7200)

    @patch("aiauto.http_client.requests.post")
    def test_verify_parameter(self, mock_post, client):
        """verify=not AIAUTO_INSECURE가 전달되는지 검증."""
        mock_post.return_value = self._make_ok_response()

        client._call_client_streaming("Upload", iter([]), content_length=0)

        call_kwargs = mock_post.call_args[1]
        # AIAUTO_INSECURE 기본값은 False -> verify=True
        assert call_kwargs["verify"] is True

    @patch("aiauto.http_client.requests.post")
    def test_x_client_version_header(self, mock_post, client):
        """X-Client-Version 헤더가 streaming 호출에도 전달되는지 검증."""
        mock_post.return_value = self._make_ok_response()

        client._call_client_streaming("Upload", iter([]), content_length=0)

        headers = mock_post.call_args[1]["headers"]
        assert "X-Client-Version" in headers
        # _CLIENT_VERSION과 동일 값인지
        from aiauto.http_client import _CLIENT_VERSION

        assert headers["X-Client-Version"] == _CLIENT_VERSION


class TestParseStreamingResponseEdgeCases:
    """_parse_streaming_response 추가 edge case."""

    def test_truncated_header_on_second_frame(self):
        """첫 프레임 정상 + 두 번째 프레임 헤더 truncated -> RuntimeError."""
        data = b"valid-data"
        body = struct.pack(">BI", 0x00, len(data)) + data
        # 두 번째 프레임: 3바이트만 (5바이트 헤더 미완성)
        body += b"\x00\x00\x00"

        with pytest.raises(RuntimeError, match="Truncated streaming frame header"):
            ConnectRPCClient._parse_streaming_response(body)

    def test_truncated_payload_on_second_frame(self):
        """첫 프레임 정상 + 두 번째 프레임 payload truncated -> RuntimeError."""
        data = b"valid-data"
        body = struct.pack(">BI", 0x00, len(data)) + data
        # 두 번째 프레임: 헤더는 100바이트라 하지만 실제 2바이트만
        body += struct.pack(">BI", 0x00, 100) + b"ab"

        with pytest.raises(RuntimeError, match="Truncated streaming frame data"):
            ConnectRPCClient._parse_streaming_response(body)

    def test_eos_with_non_dict_json(self):
        """EOS frame의 JSON이 dict가 아닌 경우 (list 등) -> 에러 없이 통과."""
        data = b"payload"
        body = struct.pack(">BI", 0x00, len(data)) + data
        eos = b"[1, 2, 3]"  # JSON array, not dict
        body += struct.pack(">BI", 0x02, len(eos)) + eos

        result = ConnectRPCClient._parse_streaming_response(body)
        assert result == data

    def test_zero_length_data_frame(self):
        """Data frame with length=0 -> 빈 bytes가 result_data로 설정."""
        body = struct.pack(">BI", 0x00, 0)
        eos = b"{}"
        body += struct.pack(">BI", 0x02, len(eos)) + eos

        result = ConnectRPCClient._parse_streaming_response(body)
        # sentinel=None이므로 0-length frame(b"")도 첫 data frame으로 캡처됨
        assert result == b""

    def test_zero_length_then_real_data_frame(self):
        """0-length data frame 후 real data frame -> 첫 frame(b"")이 반환되어야 함.

        sentinel fix 검증: result_data=None -> b""로 설정 후,
        후속 real data frame이 덮어쓰지 않아야 함.
        """
        # 첫 data frame: length=0
        body = struct.pack(">BI", 0x00, 0)
        # 두 번째 data frame: real data
        real_data = b"should-not-be-returned"
        body += struct.pack(">BI", 0x00, len(real_data)) + real_data
        # EOS frame
        eos = b"{}"
        body += struct.pack(">BI", 0x02, len(eos)) + eos

        result = ConnectRPCClient._parse_streaming_response(body)
        # 첫 data frame(b"")이 반환되어야 함, 두 번째가 덮어쓰면 안 됨
        assert result == b""


class TestCheckEosErrorEdgeCases:
    """Test _check_eos_error with non-dict JSON payloads (TypeError/AttributeError paths)."""

    def test_json_null_passes(self):
        """JSON null -> None, item access raises TypeError -> caught by except, no error."""
        frame = b"null"
        # Should not raise: json.loads("null") -> None, None["error"] -> TypeError
        ConnectRPCClient._check_eos_error(frame)

    def test_json_number_passes(self):
        """JSON number -> int, item access raises TypeError -> caught, no error."""
        frame = b"42"
        ConnectRPCClient._check_eos_error(frame)

    def test_json_boolean_passes(self):
        """JSON true -> bool, item access raises TypeError -> caught, no error."""
        frame = b"true"
        ConnectRPCClient._check_eos_error(frame)

    def test_json_array_passes(self):
        """JSON array -> list, 'error' in list raises TypeError -> caught, no error."""
        frame = b'["error"]'
        ConnectRPCClient._check_eos_error(frame)

    def test_error_with_empty_dict_uses_defaults(self):
        """error key maps to empty dict -> code='unknown', message='streaming error'."""
        frame = json.dumps({"error": {}}).encode()

        with pytest.raises(ConnectRPCError) as exc_info:
            ConnectRPCClient._check_eos_error(frame)

        assert exc_info.value.code == "unknown"
        assert exc_info.value.message == "streaming error"

    def test_error_value_is_non_dict_passes(self):
        """error key maps to a string (not dict) -> .get() raises AttributeError -> caught."""
        frame = json.dumps({"error": "some string"}).encode()
        # "some string".get("code") -> AttributeError -> caught
        ConnectRPCClient._check_eos_error(frame)


class TestConnectionErrorToUnavailable:
    """Test that ConnectionError from requests is converted to ConnectRPCError(unavailable)."""

    @pytest.fixture
    def client(self):
        return ConnectRPCClient(token="test-tok", base_url="https://api.test.com")

    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_connection_error(self, mock_post, client):
        """call_rpc ConnectionError -> ConnectRPCError(unavailable)."""
        mock_post.side_effect = requests.exceptions.ConnectionError("Connection refused")

        with pytest.raises(ConnectRPCError) as exc_info:
            client.call_rpc("TestMethod", {})

        assert exc_info.value.code == "unavailable"
        assert "connection failed" in exc_info.value.message

    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_read_timeout_still_runtime(self, mock_post, client):
        """call_rpc ReadTimeout (not ConnectionError) -> RuntimeError."""
        mock_post.side_effect = requests.exceptions.ReadTimeout("Read timed out")

        with pytest.raises(RuntimeError, match="Request failed"):
            client.call_rpc("TestMethod", {})

    @patch("aiauto.http_client.requests.post")
    def test_streaming_connection_error(self, mock_post, client):
        """_call_client_streaming ConnectionError -> ConnectRPCError(unavailable)."""
        mock_post.side_effect = requests.exceptions.ConnectionError("ECONNREFUSED")

        with pytest.raises(ConnectRPCError) as exc_info:
            client._call_client_streaming("Upload", iter([]), content_length=0)

        assert exc_info.value.code == "unavailable"
        assert exc_info.value.is_retryable()

    @patch("aiauto.http_client.requests.post")
    def test_streaming_read_timeout_still_runtime(self, mock_post, client):
        """_call_client_streaming ReadTimeout (not ConnectionError) -> RuntimeError."""
        mock_post.side_effect = requests.exceptions.ReadTimeout("Read timed out")

        with pytest.raises(RuntimeError, match="Request failed"):
            client._call_client_streaming("Upload", iter([]), content_length=0)


class TestConnectionErrorLogging:
    """Test that ConnectionError triggers logger.debug before raising ConnectRPCError."""

    @pytest.fixture
    def client(self):
        return ConnectRPCClient(token="test-tok", base_url="https://api.test.com")

    @patch("aiauto.http_client.logger")
    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_logs_debug_on_connection_error(self, mock_post, mock_logger, client):
        """call_rpc: ConnectionError 발생 시 logger.debug가 원본 예외와 함께 호출되어야 함."""
        original_exc = requests.exceptions.ConnectionError("Connection refused")
        mock_post.side_effect = original_exc

        with pytest.raises(ConnectRPCError):
            client.call_rpc("TestMethod", {})

        mock_logger.debug.assert_called_once_with("Connection failed: %s", original_exc)

    @patch("aiauto.http_client.logger")
    @patch("aiauto.http_client.requests.post")
    def test_streaming_logs_debug_on_connection_error(self, mock_post, mock_logger, client):
        """_call_client_streaming: ConnectionError 발생 시 logger.debug가 호출되어야 함."""
        original_exc = requests.exceptions.ConnectionError("ECONNREFUSED")
        mock_post.side_effect = original_exc

        with pytest.raises(ConnectRPCError):
            client._call_client_streaming("Upload", iter([]), content_length=0)

        mock_logger.debug.assert_called_once_with("Connection failed: %s", original_exc)

    @patch("aiauto.http_client.logger")
    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_no_debug_on_other_request_exception(self, mock_post, mock_logger, client):
        """call_rpc: ConnectionError가 아닌 RequestException에서는 logger.debug가 호출되지 않아야 함."""
        mock_post.side_effect = requests.exceptions.ReadTimeout("Read timed out")

        with pytest.raises(RuntimeError):
            client.call_rpc("TestMethod", {})

        mock_logger.debug.assert_not_called()

    @patch("aiauto.http_client.logger")
    @patch("aiauto.http_client.requests.post")
    def test_streaming_no_debug_on_other_request_exception(self, mock_post, mock_logger, client):
        """_call_client_streaming: ConnectionError가 아닌 RequestException에서는 debug 로그 없음."""
        mock_post.side_effect = requests.exceptions.Timeout("Connect timed out")

        with pytest.raises(RuntimeError):
            client._call_client_streaming("Upload", iter([]), content_length=0)

        mock_logger.debug.assert_not_called()


class TestConnectionErrorMessageExactMatch:
    """Test that ConnectionError produces exact error message regardless of original exception message."""

    @pytest.fixture
    def client(self):
        return ConnectRPCClient(token="test-tok", base_url="https://api.test.com")

    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_exact_message(self, mock_post, client):
        """call_rpc: ConnectRPCError 메시지가 정확히 'Service unavailable: connection failed'여야 함."""
        mock_post.side_effect = requests.exceptions.ConnectionError("Connection refused")

        with pytest.raises(ConnectRPCError) as exc_info:
            client.call_rpc("TestMethod", {})

        assert exc_info.value.message == "Service unavailable: connection failed"

    @patch("aiauto.http_client.requests.post")
    def test_streaming_exact_message(self, mock_post, client):
        """_call_client_streaming: ConnectRPCError 메시지가 정확히 일치해야 함."""
        mock_post.side_effect = requests.exceptions.ConnectionError("ECONNREFUSED")

        with pytest.raises(ConnectRPCError) as exc_info:
            client._call_client_streaming("Upload", iter([]), content_length=0)

        assert exc_info.value.message == "Service unavailable: connection failed"

    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_dns_failure_generalized(self, mock_post, client):
        """DNS resolution failure도 동일한 일반화 메시지로 변환되어야 함."""
        mock_post.side_effect = requests.exceptions.ConnectionError(
            "HTTPSConnectionPool(host='api.test.com', port=443): "
            "Max retries exceeded with url: /api/... "
            "(Caused by NewConnectionError('<urllib3.connection.HTTPSConnection object>: "
            "Failed to establish a new connection: [Errno -2] Name or service not known'))"
        )

        with pytest.raises(ConnectRPCError) as exc_info:
            client.call_rpc("TestMethod", {})

        assert exc_info.value.code == "unavailable"
        assert exc_info.value.message == "Service unavailable: connection failed"

    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_connect_timeout_as_connection_error(self, mock_post, client):
        """connect timeout이 ConnectionError로 wrapping된 경우도 일반화되어야 함."""
        mock_post.side_effect = requests.exceptions.ConnectionError(
            "HTTPSConnectionPool(host='api.test.com', port=443): "
            "Max retries exceeded (Caused by ConnectTimeoutError)"
        )

        with pytest.raises(ConnectRPCError) as exc_info:
            client.call_rpc("TestMethod", {})

        assert exc_info.value.code == "unavailable"
        assert exc_info.value.message == "Service unavailable: connection failed"

    @patch("aiauto.http_client.requests.post")
    def test_streaming_dns_failure_generalized(self, mock_post, client):
        """_call_client_streaming에서도 DNS failure가 일반화되어야 함."""
        mock_post.side_effect = requests.exceptions.ConnectionError(
            "HTTPSConnectionPool: Failed to establish a new connection: "
            "[Errno -2] Name or service not known"
        )

        with pytest.raises(ConnectRPCError) as exc_info:
            client._call_client_streaming("Upload", iter([]), content_length=0)

        assert exc_info.value.code == "unavailable"
        assert exc_info.value.message == "Service unavailable: connection failed"

    @patch("aiauto.http_client.requests.post")
    def test_call_rpc_connection_reset_generalized(self, mock_post, client):
        """Connection reset도 동일한 일반화 메시지로 변환되어야 함."""
        mock_post.side_effect = requests.exceptions.ConnectionError(
            "('Connection aborted.', ConnectionResetError(104, 'Connection reset by peer'))"
        )

        with pytest.raises(ConnectRPCError) as exc_info:
            client.call_rpc("TestMethod", {})

        assert exc_info.value.code == "unavailable"
        assert exc_info.value.message == "Service unavailable: connection failed"

    @patch("aiauto.http_client.requests.post")
    def test_connection_error_chains_original(self, mock_post, client):
        """원본 ConnectionError가 __cause__로 체이닝되어야 함 (from e)."""
        original = requests.exceptions.ConnectionError("original error")
        mock_post.side_effect = original

        with pytest.raises(ConnectRPCError) as exc_info:
            client.call_rpc("TestMethod", {})

        assert exc_info.value.__cause__ is original

    @patch("aiauto.http_client.requests.post")
    def test_streaming_connection_error_chains_original(self, mock_post, client):
        """_call_client_streaming에서도 원본 예외가 __cause__로 체이닝되어야 함."""
        original = requests.exceptions.ConnectionError("original error")
        mock_post.side_effect = original

        with pytest.raises(ConnectRPCError) as exc_info:
            client._call_client_streaming("Upload", iter([]), content_length=0)

        assert exc_info.value.__cause__ is original


class TestBaseUrlSchemeValidation:
    """Test ConnectRPCClient rejects non-http(s) base_url."""

    def test_ftp_scheme_raises(self):
        with pytest.raises(ValueError, match="http:// or https://"):
            ConnectRPCClient(token="tok", base_url="ftp://evil.com")

    def test_file_scheme_raises(self):
        with pytest.raises(ValueError, match="http:// or https://"):
            ConnectRPCClient(token="tok", base_url="file:///etc/passwd")

    def test_no_scheme_raises(self):
        with pytest.raises(ValueError, match="http:// or https://"):
            ConnectRPCClient(token="tok", base_url="evil.com:443")

    def test_http_accepted(self):
        client = ConnectRPCClient(token="tok", base_url="http://localhost:8080")
        assert client.base_url == "http://localhost:8080"

    def test_https_accepted(self):
        client = ConnectRPCClient(token="tok", base_url="https://api.example.com")
        assert client.base_url == "https://api.example.com"
