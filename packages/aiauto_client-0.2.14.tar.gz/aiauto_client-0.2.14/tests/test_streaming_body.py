"""Tests for _StreamingBody class and protobuf size calculation utilities.

Covers _StreamingBody (file-like wrapper for streaming uploads),
_varint_size, _chunk_data_message_size, and ContentLength accuracy.
"""

import pytest

from aiauto.core import AIAutoController
from aiauto.http_client import (
    _ITER_CHUNK_SIZE,
    _StreamingBody,
)


class TestVarintSize:
    """Test AIAutoController._varint_size helper."""

    def test_zero(self):
        assert AIAutoController._varint_size(0) == 1

    def test_single_byte_max(self):
        # 127 = 0x7F, fits in 1 byte
        assert AIAutoController._varint_size(127) == 1

    def test_two_byte_min(self):
        # 128 = 0x80, needs 2 bytes
        assert AIAutoController._varint_size(128) == 2

    def test_two_byte_max(self):
        # 16383 = 0x3FFF, fits in 2 bytes
        assert AIAutoController._varint_size(16383) == 2

    def test_three_byte_min(self):
        # 16384 = 0x4000, needs 3 bytes
        assert AIAutoController._varint_size(16384) == 3

    def test_1mb(self):
        # 1048576 = 0x100000, needs 3 bytes
        assert AIAutoController._varint_size(1048576) == 3

    def test_negative_raises(self):
        """Negative value should raise ValueError."""
        with pytest.raises(ValueError, match="non-negative"):
            AIAutoController._varint_size(-1)


class TestChunkDataMessageSize:
    """Test _chunk_data_message_size against actual protobuf serialization."""

    def test_matches_real_protobuf(self):
        """Calculated size must match actual SerializeToString() length."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        for size in [0, 1, 127, 128, 1024, 16383, 16384, 1024 * 1024]:
            msg = aiauto_pb2.UploadToSharedCacheRequest(chunk_data=b"\x00" * size)
            actual = len(msg.SerializeToString())
            calculated = AIAutoController._chunk_data_message_size(size)
            assert calculated == actual, f"Mismatch at size={size}: {calculated} != {actual}"


class TestStreamingBody:
    """Test _StreamingBody file-like wrapper."""

    def test_len(self):
        body = _StreamingBody(iter([]), 42)
        assert len(body) == 42

    def test_read_all(self):
        body = _StreamingBody(iter([b"abc", b"def"]), 6)
        assert body.read(-1) == b"abcdef"

    def test_read_zero(self):
        body = _StreamingBody(iter([b"abc"]), 3)
        assert body.read(0) == b""

    def test_read_partial(self):
        body = _StreamingBody(iter([b"abcdef"]), 6)
        assert body.read(3) == b"abc"
        assert body.read(3) == b"def"
        assert body.read(-1) == b""

    def test_read_across_chunks(self):
        """read(n) that spans multiple generator yields."""
        body = _StreamingBody(iter([b"ab", b"cd", b"ef"]), 6)
        assert body.read(4) == b"abcd"
        assert body.read(-1) == b"ef"

    def test_empty_generator(self):
        body = _StreamingBody(iter([]), 0)
        assert body.read(-1) == b""
        assert body.read(10) == b""

    def test_read_default_arg(self):
        """read() without argument should return all remaining data (default size=-1)."""
        body = _StreamingBody(iter([b"hello", b"world"]), 10)
        assert body.read() == b"helloworld"

    def test_generator_yields_empty_bytes(self):
        """Generator yielding empty bytes should be transparent."""
        body = _StreamingBody(iter([b"", b"abc", b"", b"def"]), 6)
        assert body.read(-1) == b"abcdef"

    def test_read_larger_than_available(self):
        """read(n) where n > total data should return all available data."""
        body = _StreamingBody(iter([b"abc"]), 3)
        assert body.read(100) == b"abc"
        assert body.read(100) == b""

    def test_sequential_small_reads(self):
        """Multiple read(1) calls should return one byte at a time."""
        body = _StreamingBody(iter([b"abc"]), 3)
        assert body.read(1) == b"a"
        assert body.read(1) == b"b"
        assert body.read(1) == b"c"
        assert body.read(1) == b""

    def test_iter(self):
        """__iter__ should yield chunks via read(_ITER_CHUNK_SIZE)."""
        data = b"x" * 100
        body = _StreamingBody(iter([data]), len(data))
        collected = b"".join(body)
        assert collected == data


class TestContentLengthAccuracy:
    """Test that pre-calculated content_length matches actual frame bytes."""

    @pytest.fixture
    def mock_controller(self):
        from unittest.mock import MagicMock

        from aiauto.http_client import ConnectRPCClient

        ctrl = object.__new__(AIAutoController)
        ctrl.token = "test-token-abc"
        ctrl.client = MagicMock(spec=ConnectRPCClient)
        ctrl.client.base_url = "https://api.example.com"
        return ctrl

    @pytest.fixture
    def tmp_files(self, tmp_path):
        f1 = tmp_path / "train.csv"
        f1.write_text("col1,col2\n1,2\n")
        f2 = tmp_path / "test.csv"
        f2.write_text("col1,col2\n3,4\n")
        return str(f1), str(f2)

    def test_content_length_matches_actual_frames(self, mock_controller, tmp_files):
        """pre-calculated content_length == 실제 프레임 총 크기."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = "{}"

        captured = {}

        def capture(method, iterator, content_length=0):
            actual = 0
            for msg in iterator:
                data = msg.SerializeToString()
                actual += 5 + len(data)
            captured["content_length"] = content_length
            captured["actual"] = actual
            return resp.SerializeToString()

        mock_controller.client._call_client_streaming.side_effect = capture
        mock_controller.upload_to_shared_cache(list(tmp_files))

        assert captured["content_length"] == captured["actual"]
        assert captured["content_length"] > 0

    def test_empty_file_content_length(self, mock_controller, tmp_path):
        """0바이트 파일: file_info frame만 존재, chunk frame 없음."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        empty_file = tmp_path / "empty.csv"
        empty_file.write_bytes(b"")

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = "{}"

        captured = {}

        def capture(method, iterator, content_length=0):
            actual = 0
            msgs = []
            for msg in iterator:
                data = msg.SerializeToString()
                actual += 5 + len(data)
                msgs.append(msg)
            captured["content_length"] = content_length
            captured["actual"] = actual
            captured["msgs"] = msgs
            return resp.SerializeToString()

        mock_controller.client._call_client_streaming.side_effect = capture
        mock_controller.upload_to_shared_cache(str(empty_file))

        assert captured["content_length"] == captured["actual"]
        # 0바이트 파일: file_info 1개만, chunk 0개
        assert len(captured["msgs"]) == 1
        assert captured["msgs"][0].HasField("file_info")

    def test_exact_chunk_boundary_content_length(self, mock_controller, tmp_path):
        """정확히 1MB 파일: chunk 1개로 처리, content_length 정확성 검증."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        chunk_size = 1024 * 1024  # 1MB
        big_file = tmp_path / "exact_1mb.bin"
        big_file.write_bytes(b"\x00" * chunk_size)

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = "{}"

        captured = {}

        def capture(method, iterator, content_length=0):
            actual = 0
            chunk_count = 0
            for msg in iterator:
                data = msg.SerializeToString()
                actual += 5 + len(data)
                if msg.HasField("chunk_data"):
                    chunk_count += 1
            captured["content_length"] = content_length
            captured["actual"] = actual
            captured["chunk_count"] = chunk_count
            return resp.SerializeToString()

        mock_controller.client._call_client_streaming.side_effect = capture
        mock_controller.upload_to_shared_cache(str(big_file))

        assert captured["content_length"] == captured["actual"]
        assert captured["chunk_count"] == 1  # 정확히 1MB -> 1 chunk

    def test_chunk_boundary_plus_one_content_length(self, mock_controller, tmp_path):
        """1MB + 1B 파일: 2개 chunk로 분할, content_length 정확성 검증."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        chunk_size = 1024 * 1024  # 1MB
        big_file = tmp_path / "over_1mb.bin"
        big_file.write_bytes(b"\x00" * (chunk_size + 1))

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = "{}"

        captured = {}

        def capture(method, iterator, content_length=0):
            actual = 0
            chunk_count = 0
            for msg in iterator:
                data = msg.SerializeToString()
                actual += 5 + len(data)
                if msg.HasField("chunk_data"):
                    chunk_count += 1
            captured["content_length"] = content_length
            captured["actual"] = actual
            captured["chunk_count"] = chunk_count
            return resp.SerializeToString()

        mock_controller.client._call_client_streaming.side_effect = capture
        mock_controller.upload_to_shared_cache(str(big_file))

        assert captured["content_length"] == captured["actual"]
        assert captured["chunk_count"] == 2  # 1MB + 1B -> 2 chunks

    def test_content_length_with_dest_dir(self, mock_controller, tmp_files):
        """dest_dir="subdir" 지정 시 content_length == 실제 프레임 크기.

        dest_dir가 file_info protobuf 크기에 영향을 주므로,
        사전 계산된 content_length가 정확해야 함.
        """
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        resp = aiauto_pb2.UploadToSharedCacheResponse()
        resp.json_response = "{}"

        captured = {}

        def capture(method, iterator, content_length=0):
            actual = 0
            for msg in iterator:
                data = msg.SerializeToString()
                actual += 5 + len(data)
            captured["content_length"] = content_length
            captured["actual"] = actual
            return resp.SerializeToString()

        mock_controller.client._call_client_streaming.side_effect = capture
        mock_controller.upload_to_shared_cache(list(tmp_files), dest_dir="subdir")

        assert captured["content_length"] == captured["actual"]
        assert captured["content_length"] > 0


class TestStreamingBodyIterMultiChunk:
    """Test __iter__ with data larger than read(_ITER_CHUNK_SIZE) chunk size."""

    def test_iter_multi_chunk(self):
        """_ITER_CHUNK_SIZE 이상 데이터에서 __iter__가 여러 chunk를 yield해야 함."""
        size = _ITER_CHUNK_SIZE * 3 + 100  # 3개 full chunk + 100B 잔여
        data = bytes(range(256)) * (size // 256 + 1)
        data = data[:size]

        body = _StreamingBody(iter([data]), size)
        chunks = list(body)

        # 최소 4개 chunk가 나와야 함 (3 full + 1 partial)
        assert len(chunks) >= 4, f"Expected at least 4 chunks, got {len(chunks)}"
        assert b"".join(chunks) == data

    def test_iter_exact_boundary(self):
        """정확히 _ITER_CHUNK_SIZE 데이터 -> 1개 chunk + 빈 read 종료."""
        size = _ITER_CHUNK_SIZE
        data = b"\xab" * size
        body = _StreamingBody(iter([data]), size)
        chunks = list(body)

        assert len(chunks) == 1
        assert chunks[0] == data

    def test_iter_empty(self):
        """빈 body의 __iter__는 아무것도 yield하지 않아야 함."""
        body = _StreamingBody(iter([]), 0)
        chunks = list(body)
        assert chunks == []


class TestStreamingBodyReturnType:
    """Test that _StreamingBody.read() returns bytes (not bytearray)."""

    def test_read_all_returns_bytes(self):
        body = _StreamingBody(iter([b"hello"]), 5)
        result = body.read(-1)
        assert type(result) is bytes, f"Expected bytes, got {type(result).__name__}"

    def test_read_partial_returns_bytes(self):
        body = _StreamingBody(iter([b"hello"]), 5)
        result = body.read(3)
        assert type(result) is bytes, f"Expected bytes, got {type(result).__name__}"

    def test_read_remaining_after_partial_returns_bytes(self):
        body = _StreamingBody(iter([b"hello"]), 5)
        body.read(2)  # consume "he"
        result = body.read(-1)  # remaining "llo"
        assert type(result) is bytes, f"Expected bytes, got {type(result).__name__}"

    def test_read_empty_returns_bytes(self):
        body = _StreamingBody(iter([]), 0)
        result = body.read(-1)
        assert type(result) is bytes, f"Expected bytes, got {type(result).__name__}"


class TestVarintSizeEdgeCases:
    """Additional edge cases for _varint_size."""

    def test_large_negative_raises(self):
        """큰 음수 값도 ValueError 발생해야 함."""
        import sys

        with pytest.raises(ValueError, match="non-negative"):
            AIAutoController._varint_size(-sys.maxsize)

    def test_max_4byte_varint(self):
        """2^28 - 1 = 268435455 -> 4 bytes."""
        assert AIAutoController._varint_size(268435455) == 4

    def test_five_byte_varint(self):
        """2^28 = 268435456 -> 5 bytes."""
        assert AIAutoController._varint_size(268435456) == 5


class TestStreamingBodyCompact:
    """Test _StreamingBody._compact behavior via observable side effects."""

    def test_compact_triggers_on_half_consumed(self):
        """_off가 buf의 절반 이상이면 compact가 발동하여 메모리를 회수해야 함.

        compact 발동 검증: read(partial) 후 내부 _buf 크기가 감소하는지 확인.
        이 테스트는 _compact의 조건 (self._off >= len(self._buf) // 2)을 직접 검증한다.
        """
        # 10바이트 데이터, 6바이트 read -> _off=6, _buf=10, 6 >= 10//2=5 -> compact 발동
        body = _StreamingBody(iter([b"0123456789"]), 10)
        body.read(6)  # _off = 6

        # compact는 다음 read 시 data가 truthy일 때 호출됨
        # generator에 데이터가 없으므로 수동으로 검증
        # compact 전: _off=6, _buf=b"0123456789" (len=10)
        # compact 안 됐으면 _off=6이 유지

        # 추가 데이터를 넣고 read -> compact 발동 확인
        body2 = _StreamingBody(iter([b"0123456789", b"abcd"]), 14)
        body2.read(6)  # _off=6, _buf=b"0123456789"

        # 두 번째 chunk fetch 시 compact 발동:
        # _off=6 >= len(b"0123456789")//2 = 5 -> del _buf[:6] -> _buf=b"6789"
        # 그 후 extend(b"abcd") -> _buf=b"6789abcd"
        result = body2.read(8)  # remaining: "6789" + "abcd" = "6789abcd"
        assert result == b"6789abcd"

    def test_compact_does_not_trigger_when_offset_low(self):
        """_off가 buf의 절반 미만이면 compact가 발동하지 않아야 함."""
        # 10바이트, 4바이트 read -> _off=4, buf=10, 4 < 10//2=5 -> compact 안 됨
        body = _StreamingBody(iter([b"0123456789", b"ab"]), 12)
        body.read(4)  # _off=4

        # 두 번째 chunk fetch시 compact 조건 미충족
        # _off=4 < len(b"0123456789")//2 = 5 -> compact 안 됨
        # 내부적으로 _buf에 여전히 전체가 남아있고 extend 됨
        result = body.read(-1)  # "456789" + "ab"
        assert result == b"456789ab"

    def test_read_all_after_partial_clears_buffer(self):
        """read(-1)은 남은 모든 데이터를 반환하고 buffer를 완전히 비워야 함."""
        body = _StreamingBody(iter([b"abcdefgh"]), 8)
        body.read(3)  # "abc", _off=3
        remaining = body.read(-1)  # "defgh"
        assert remaining == b"defgh"
        # buffer cleared
        assert body.read(-1) == b""


class TestStreamingBodyAllEmptyChunks:
    """Test _StreamingBody with generator yielding only empty bytes."""

    def test_all_empty_chunks(self):
        """Generator yielding only empty bytes -> read(-1) returns empty bytes."""
        body = _StreamingBody(iter([b"", b"", b""]), 0)
        assert body.read(-1) == b""

    def test_empty_then_data(self):
        """Generator yielding empty bytes then real data."""
        body = _StreamingBody(iter([b"", b"", b"hello"]), 5)
        assert body.read(-1) == b"hello"


class TestChunkDataMessageSizeZero:
    """Test _chunk_data_message_size(0) matches protobuf reality."""

    def test_zero_chunk_size(self):
        """0-byte chunk: protobuf omits default-value bytes field -> size should be 0."""
        from aiauto.proto.aiauto.v1 import aiauto_pb2

        msg = aiauto_pb2.UploadToSharedCacheRequest(chunk_data=b"")
        actual = len(msg.SerializeToString())
        calculated = AIAutoController._chunk_data_message_size(0)
        assert calculated == actual, (
            f"_chunk_data_message_size(0)={calculated} != actual protobuf size={actual}"
        )
