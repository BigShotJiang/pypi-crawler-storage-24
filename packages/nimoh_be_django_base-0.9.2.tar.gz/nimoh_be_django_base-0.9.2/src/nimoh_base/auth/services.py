"""Authentication Services.

This module provides business logic for authentication operations including
token exchange, user sessions, and secure authentication flows.
"""

import logging
import secrets
import uuid
from datetime import timedelta
from typing import Any

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.db import transaction
from django.db.utils import DatabaseError
from django.utils import timezone
from rest_framework_simplejwt.tokens import RefreshToken

from nimoh_base.conf import nimoh_setting

from .models import AuditLog, EmailChangeToken, EmailVerificationToken, PasswordResetToken, UserSession
from .tasks import enforce_session_limit_task

User = get_user_model()
logger = logging.getLogger(__name__)


class TwoFactorService:
    """Orchestrates TOTP 2FA setup, confirmation, verification, and tear-down.

    The login flow for 2FA-enabled users is:

    1. ``POST /auth/login/`` — password verified → ``202`` with
       ``{ "two_factor_required": true, "challenge_token": "<tok>" }``
    2. ``POST /auth/2fa/verify/`` with ``challenge_token`` + TOTP
       ``code`` → full JWT tokens issued.

    Setup flow:
    1. ``POST /auth/2fa/setup/`` → returns ``secret`` + ``otpauth_uri``
       (client renders QR code).
    2. ``POST /auth/2fa/confirm/`` with valid TOTP code → 2FA enabled,
       8 plain-text backup codes returned.
    """

    CHALLENGE_PREFIX = "nimoh_base:mfa_challenge"
    CHALLENGE_TTL = 300  # 5 minutes

    # ── Setup ────────────────────────────────────────────────────────────────

    @classmethod
    def begin_setup(cls, user) -> dict:
        """Create (or replace) an *unconfirmed* ``TOTPDevice`` and return the
        provisioning URI + raw secret so the frontend can render a QR code.

        Any existing unconfirmed device for the user is discarded first so
        repeated ``/setup/`` calls don't accumulate stale records.
        """
        from .models import TOTPDevice, _generate_totp_secret

        TOTPDevice.objects.filter(user=user, confirmed=False).delete()

        secret = _generate_totp_secret()
        device = TOTPDevice.objects.create(user=user, secret=secret, confirmed=False)
        issuer = nimoh_setting("SITE_NAME", "nimoh-app")
        uri = f"otpauth://totp/{issuer}:{user.email}?secret={secret}&issuer={issuer}&algorithm=SHA1&digits=6&period=30"
        logger.info("TOTP setup initiated", extra={"user_id": str(user.pk)})
        return {"secret": secret, "otpauth_uri": uri, "device_id": device.pk}

    @classmethod
    def confirm_setup(cls, user, code: str) -> list[str]:
        """Confirm an unconfirmed ``TOTPDevice`` and enable 2FA on the account.

        Returns the list of plain-text backup codes.

        Raises:
            ValueError: if the code is incorrect or there is no pending device.
        """
        from .models import BackupCode, TOTPDevice

        try:
            device = TOTPDevice.objects.get(user=user, confirmed=False)
        except TOTPDevice.DoesNotExist:
            raise ValueError("No pending TOTP setup found for this user. Call /auth/2fa/setup/ first.")

        if not device.verify(code):
            raise ValueError("Invalid TOTP code.")

        with transaction.atomic():
            device.confirmed = True
            device.save(update_fields=["confirmed"])
            User.objects.filter(pk=user.pk).update(two_factor_enabled=True)
            backup_codes = BackupCode.generate_for_user(user)

        logger.info("2FA enabled", extra={"user_id": str(user.pk)})
        return backup_codes

    # ── Login challenge ───────────────────────────────────────────────────────

    @classmethod
    def create_challenge(cls, user) -> str:
        """Cache a short-lived MFA challenge token and return it."""
        token = secrets.token_urlsafe(32)
        cache.set(
            f"{cls.CHALLENGE_PREFIX}:{token}",
            str(user.pk),
            timeout=cls.CHALLENGE_TTL,
        )
        logger.debug("MFA challenge created", extra={"user_id": str(user.pk)})
        return token

    @classmethod
    def resolve_challenge(cls, challenge_token: str):
        """Return the ``User`` for *challenge_token*, consuming it (single-use).

        Raises:
            ValueError: if the token is invalid, expired, or the user is gone.
        """
        key = f"{cls.CHALLENGE_PREFIX}:{challenge_token}"
        user_pk = cache.get(key)
        if not user_pk:
            raise ValueError("Invalid or expired MFA challenge token.")
        cache.delete(key)
        try:
            return User.objects.get(pk=user_pk)
        except User.DoesNotExist:
            raise ValueError("User not found.")

    # ── Verification ─────────────────────────────────────────────────────────

    @classmethod
    def verify(cls, user, code: str) -> bool:
        """Verify a TOTP code *or* a backup code for *user*.

        Tries the confirmed ``TOTPDevice`` first; falls back to consuming a
        ``BackupCode`` if TOTP fails.

        Returns:
            ``True`` if the code was valid (and, for backup codes, has now
            been consumed).
        """
        from .models import BackupCode, TOTPDevice

        try:
            device = TOTPDevice.objects.get(user=user, confirmed=True)
            if device.verify(code):
                return True
        except TOTPDevice.DoesNotExist:
            pass

        return BackupCode.consume(user, code)

    # ── Management ───────────────────────────────────────────────────────────

    @classmethod
    def regenerate_backup_codes(cls, user) -> list[str]:
        """Regenerate and return 8 fresh plain-text backup codes."""
        from .models import BackupCode

        codes = BackupCode.generate_for_user(user)
        logger.info("Backup codes regenerated", extra={"user_id": str(user.pk)})
        return codes

    @classmethod
    def disable(cls, user, code: str) -> None:
        """Disable 2FA after verifying *code*.

        Raises:
            ValueError: if *code* is invalid.
        """
        if not cls.verify(user, code):
            raise ValueError("Invalid TOTP or backup code.  Cannot disable 2FA.")

        from .models import BackupCode, TOTPDevice

        with transaction.atomic():
            TOTPDevice.objects.filter(user=user).delete()
            BackupCode.objects.filter(user=user).delete()
            User.objects.filter(pk=user.pk).update(two_factor_enabled=False)

        logger.info("2FA disabled", extra={"user_id": str(user.pk)})


class ExchangeTokenService:
    """
    Service for managing temporary exchange tokens for secure authentication flows.

    Exchange tokens are short-lived, single-use tokens that can be exchanged
    for JWT access/refresh tokens. This pattern is more secure than passing
    JWT tokens directly in URLs.
    """

    # Cache key prefix for exchange tokens
    CACHE_PREFIX = "exchange_token"

    # Exchange token expiry (short-lived for security)
    TOKEN_EXPIRY_SECONDS = 60  # 1 minute

    @classmethod
    def generate_exchange_token(cls, user: User, context: dict[str, Any] | None = None) -> str:
        """
        Generate a one-time exchange token for a user.

        Args:
            user: The user to generate the token for
            context: Optional context data to store with the token

        Returns:
            The exchange token string
        """
        # Generate cryptographically secure random token
        exchange_token = secrets.token_urlsafe(32)

        # Prepare token data
        token_data = {
            "user_id": user.id,
            "created_at": timezone.now().isoformat(),
            "context": context or {},
            "used": False,
        }

        # Store in cache with expiry
        cache_key = f"{cls.CACHE_PREFIX}:{exchange_token}"
        cache.set(cache_key, token_data, timeout=cls.TOKEN_EXPIRY_SECONDS)

        logger.info(f"Generated exchange token for user {user.id}")

        return exchange_token

    @classmethod
    def exchange_for_jwt_tokens(cls, exchange_token: str, request_meta: dict[str, Any] | None = None) -> dict[str, Any]:
        """
        Exchange a one-time token for JWT access/refresh tokens.

        Args:
            exchange_token: The exchange token to validate and consume
            request_meta: Request metadata for session creation

        Returns:
            Dict containing access_token, refresh_token, and user info

        Raises:
            ValueError: If token is invalid, expired, or already used
        """
        cache_key = f"{cls.CACHE_PREFIX}:{exchange_token}"

        # Atomically claim the token using cache.add() — this returns True only
        # if the claim key did NOT already exist, preventing a TOCTOU race where
        # two concurrent requests both read "used=False" before either writes
        # "used=True".
        claimed_key = f"{cls.CACHE_PREFIX}:claimed:{exchange_token}"
        if not cache.add(claimed_key, 1, timeout=cls.TOKEN_EXPIRY_SECONDS + 5):
            raise ValueError("Exchange token has already been used")

        # Retrieve token data from cache
        token_data = cache.get(cache_key)

        if not token_data:
            # Token expired between the claim-check and the get — release claim.
            cache.delete(claimed_key)
            raise ValueError("Invalid or expired exchange token")

        # Get user
        try:
            user = User.objects.get(id=token_data["user_id"])
        except User.DoesNotExist:
            raise ValueError("User not found for exchange token")

        # Generate JWT tokens
        refresh = RefreshToken.for_user(user)
        access_token = refresh.access_token

        # Create user session and audit log atomically
        with transaction.atomic():
            session = cls._create_user_session(user, refresh, request_meta)
            cls._log_token_exchange(user, request_meta, success=True)

        # Delete the exchange token from cache (single use)
        cache.delete(cache_key)

        return {
            "access_token": str(access_token),
            "refresh_token": str(refresh),
            "user_id": user.id,
            "email": user.email,
            "session_id": str(session.id),
            # 15 minutes default
            "expires_in": access_token.get("exp") - timezone.now().timestamp() if access_token.get("exp") else 900,
            "context": token_data.get("context", {}),
        }

    @classmethod
    def _create_user_session(
        cls, user: User, refresh_token: RefreshToken, request_meta: dict[str, Any] | None = None
    ) -> UserSession:
        """Create a user session for the token exchange login."""
        request_meta = request_meta or {}

        # Generate a shorter session key that fits in 40 characters
        # Format: {jti}_{short_timestamp}
        timestamp = str(int(timezone.now().timestamp()))
        session_key = f"{refresh_token['jti'][:24]}_{timestamp[:8]}"

        session = UserSession.objects.create(
            user=user,
            device_fingerprint=request_meta.get("device_fingerprint", ""),
            device_name=request_meta.get("device_name", "Email Verification Login"),
            user_agent=request_meta.get("user_agent", ""),
            ip_address=request_meta.get("ip_address", ""),
            refresh_token_jti=str(refresh_token["jti"]),
            session_key=session_key,
            expires_at=timezone.now() + timedelta(days=14),  # Match refresh token expiry
        )

        _uid = user.pk
        transaction.on_commit(lambda: enforce_session_limit_task.delay(_uid))
        return session

    @classmethod
    def _log_token_exchange(cls, user: User, request_meta: dict[str, Any] | None = None, success: bool = True):
        """Log the token exchange attempt for audit purposes."""
        request_meta = request_meta or {}

        AuditLog.log_event(
            event_type="security_event",
            user=user,
            description=f"Exchange token {'used' if success else 'failed'} for auto-login",
            ip_address=request_meta.get("ip_address", ""),
            user_agent=request_meta.get("user_agent", ""),
            success=success,
            risk_level="low" if success else "medium",
            metadata={
                "auto_login": True,
                "method": "email_verification_exchange",
            },
        )


class AuthenticationService:
    """
    Service for core authentication operations.

    Provides high-level authentication methods that can be used
    across different views and flows.
    """

    @staticmethod
    def authenticate_user(validated_data: dict[str, Any], request) -> dict[str, Any]:
        """
        Authenticate user and create session with JWT tokens.

        Args:
            validated_data: Dictionary containing user and session data from serializer
            request: HTTP request object

        Returns:
            Dict containing access_token, refresh_token, user, session, and metadata
        """
        user = validated_data["user"]
        device_name = validated_data.get("device_name", "Unknown Device")
        device_fingerprint = validated_data.get("device_fingerprint", "")
        remember_me = validated_data.get("remember_me", False)

        # If 2FA is enabled for this account, don't issue tokens yet.
        # Instead return a short-lived challenge token; the client must call
        # POST /auth/2fa/verify/ to complete authentication.
        if getattr(user, "two_factor_enabled", False):
            challenge_token = TwoFactorService.create_challenge(user)
            return {
                "two_factor_required": True,
                "challenge_token": challenge_token,
                "expires_in": TwoFactorService.CHALLENGE_TTL,
            }

        # Generate JWT tokens
        refresh = RefreshToken.for_user(user)
        access_token = refresh.access_token

        # Extract request metadata
        request_meta = {
            "device_fingerprint": device_fingerprint or AuthenticationService.get_device_fingerprint(request),
            "device_name": device_name,
            "user_agent": request.META.get("HTTP_USER_AGENT", "Unknown"),
            "ip_address": request.META.get("REMOTE_ADDR", ""),
        }

        # Create user session and log atomically
        from .models import UserSession

        with transaction.atomic():
            session = UserSession.objects.create(
                user=user,
                device_fingerprint=request_meta["device_fingerprint"],
                device_name=request_meta["device_name"],
                user_agent=request_meta["user_agent"],
                ip_address=request_meta["ip_address"],
                refresh_token_jti=str(refresh["jti"]),
                session_key=f"{refresh['jti'][:24]}_{str(int(timezone.now().timestamp()))[:8]}",
                expires_at=timezone.now() + timedelta(days=14 if remember_me else 7),
            )

            _uid = user.pk
            transaction.on_commit(lambda: enforce_session_limit_task.delay(_uid))

            AuditLog.log_event(
                event_type="login_success",
                description="User logged in successfully",
                user=user,
                ip_address=request.META.get("REMOTE_ADDR", ""),
                user_agent=request.META.get("HTTP_USER_AGENT", ""),
                session_id=str(session.id),
                metadata={
                    "device_name": device_name,
                    "remember_me": remember_me,
                },
            )

        return {
            "access_token": str(access_token),
            "refresh_token": str(refresh),
            "user": user,
            "session": session,
            "expires_in": 900,  # 15 minutes
            "token_type": "Bearer",
        }

    @classmethod
    def complete_two_factor_login(
        cls,
        challenge_token: str,
        code: str,
        request,
        device_name: str = "Unknown Device",
        device_fingerprint: str = "",
        remember_me: bool = False,
    ) -> dict:
        """Complete a 2FA login by verifying *code* against *challenge_token*.

        Args:
            challenge_token: Token returned by the first login step (202 response).
            code: 6-digit TOTP code or ``XXXX-XXXX`` backup code.
            request: The HTTP request (for session/audit metadata).
            device_name: Optional device label for the new session.
            device_fingerprint: Optional device fingerprint.
            remember_me: Whether to extend session lifetime to 14 days.

        Returns:
            Same shape as ``authenticate_user`` (access_token, refresh_token, …).

        Raises:
            ValueError: if the challenge token or TOTP code is invalid.
        """
        user = TwoFactorService.resolve_challenge(challenge_token)

        if not TwoFactorService.verify(user, code):
            AuditLog.log_event(
                event_type="login_failure",
                description="2FA verification failed",
                user=user,
                ip_address=request.META.get("REMOTE_ADDR", ""),
                user_agent=request.META.get("HTTP_USER_AGENT", ""),
                success=False,
                risk_level="high",
                metadata={"method": "totp"},
            )
            raise ValueError("Invalid 2FA code.")

        # Issue JWT tokens and create session
        refresh = RefreshToken.for_user(user)
        access_token = refresh.access_token

        request_meta = {
            "device_fingerprint": device_fingerprint or cls.get_device_fingerprint(request),
            "device_name": device_name,
            "user_agent": request.META.get("HTTP_USER_AGENT", "Unknown"),
            "ip_address": request.META.get("REMOTE_ADDR", ""),
        }

        with transaction.atomic():
            session = UserSession.objects.create(
                user=user,
                device_fingerprint=request_meta["device_fingerprint"],
                device_name=request_meta["device_name"],
                user_agent=request_meta["user_agent"],
                ip_address=request_meta["ip_address"],
                refresh_token_jti=str(refresh["jti"]),
                session_key=f"{refresh['jti'][:24]}_{str(int(timezone.now().timestamp()))[:8]}",
                expires_at=timezone.now() + timedelta(days=14 if remember_me else 7),
                is_verified=True,
            )

            _uid = user.pk
            transaction.on_commit(lambda: enforce_session_limit_task.delay(_uid))

            AuditLog.log_event(
                event_type="login_success",
                description="User logged in via 2FA",
                user=user,
                ip_address=request_meta["ip_address"],
                user_agent=request_meta["user_agent"],
                session_id=str(session.id),
                metadata={"device_name": device_name, "method": "totp"},
            )

        return {
            "access_token": str(access_token),
            "refresh_token": str(refresh),
            "user": user,
            "session": session,
            "expires_in": 900,
            "token_type": "Bearer",
        }

    @staticmethod
    def get_device_fingerprint(request) -> str:
        """
        Generate a device fingerprint from request headers.

        This is a simple implementation - in production you might want
        to use more sophisticated fingerprinting.
        """
        user_agent = request.META.get("HTTP_USER_AGENT", "Test Client")
        accept_language = request.META.get("HTTP_ACCEPT_LANGUAGE", "")
        accept_encoding = request.META.get("HTTP_ACCEPT_ENCODING", "")

        # Create a simple hash of key headers
        import hashlib

        fingerprint_data = f"{user_agent}:{accept_language}:{accept_encoding}"
        return hashlib.sha256(fingerprint_data.encode()).hexdigest()[:16]

    @staticmethod
    def extract_request_metadata(request) -> dict[str, Any]:
        """Extract metadata from request for session creation and logging."""
        return {
            "device_fingerprint": AuthenticationService.get_device_fingerprint(request),
            "device_name": "Email Verification Login",
            "user_agent": request.META.get("HTTP_USER_AGENT", "Test Client"),
            "ip_address": request.META.get("REMOTE_ADDR", ""),
        }

    @staticmethod
    def logout_user(user, request) -> bool:
        """
        Logout user and invalidate their active sessions.

        Args:
            user: User instance to logout
            request: HTTP request object

        Returns:
            bool: Success status
        """
        try:
            from .models import UserSession

            with transaction.atomic():
                active_sessions = UserSession.objects.filter(user=user, is_active=True)

                terminated_count = active_sessions.update(is_active=False)

                AuditLog.log_event(
                    event_type="logout",
                    description=f"User logged out successfully. Terminated {terminated_count} session(s)",
                    user=user,
                    ip_address=request.META.get("REMOTE_ADDR", ""),
                    user_agent=request.META.get("HTTP_USER_AGENT", ""),
                    metadata={"sessions_terminated": terminated_count},
                )

            logger.info("User logout successful", user_id=str(user.id), sessions_terminated=terminated_count)

            return True
        except DatabaseError as e:
            logger.error("Logout failed with exception", user_id=str(user.id), error=str(e))

            # Log the failure
            AuditLog.log_event(
                event_type="security_event",
                description="User logout failed",
                user=user,
                ip_address=request.META.get("REMOTE_ADDR", ""),
                user_agent=request.META.get("HTTP_USER_AGENT", ""),
                success=False,
                risk_level="medium",
                metadata={"error_type": type(e).__name__},
            )

            return False


class EmailChangeService:
    """Orchestrates the email-address change flow.

    Flow
    ----
    1. ``request_change(user, new_email, request)``
       — invalidates any pending token for this user, creates a fresh
         :class:`~nimoh_base.auth.models.EmailChangeToken`, and sends a
         confirmation link to *new_email*.
    2. ``confirm_change(token_str)``
       — validates the token, sets ``user.email = new_email``, marks the
         token used, and logs an audit event.
    """

    @classmethod
    def request_change(cls, user, new_email: str, request=None) -> EmailChangeToken:
        """Initiate an email-address change for *user*.

        Args:
            user: The currently-authenticated user.
            new_email: The desired new address (must not be taken by another account).
            request: Optional Django request (used for IP logging).

        Returns:
            The new :class:`~nimoh_base.auth.models.EmailChangeToken` instance.

        Raises:
            ValueError: if *new_email* equals the current address or is already taken.
        """
        if new_email.lower() == user.email.lower():
            raise ValueError("The new email address must be different from the current one.")

        if User.objects.filter(email__iexact=new_email).exclude(pk=user.pk).exists():
            raise ValueError("An account with this email address already exists.")

        expiry_hours = nimoh_setting("EMAIL_CHANGE_EXPIRY_HOURS", 24)

        with transaction.atomic():
            # Invalidate any previous pending tokens for this user
            EmailChangeToken.objects.filter(user=user, is_used=False).delete()

            token_str = secrets.token_urlsafe(32)
            token = EmailChangeToken.objects.create(
                user=user,
                new_email=new_email,
                token=token_str,
                expires_at=timezone.now() + timedelta(hours=expiry_hours),
                ip_address=request.META.get("REMOTE_ADDR") if request else None,
            )

        # Send confirmation email (fire-and-forget via Celery if available)
        try:
            from django.template.loader import render_to_string

            from nimoh_base.core.tasks import send_email_task

            site_name = nimoh_setting("SITE_NAME", "nimoh-app")
            ctx = {
                "user": user,
                "new_email": new_email,
                "token": token_str,
                "expiry_hours": expiry_hours,
                "site_name": site_name,
                "support_email": nimoh_setting("SUPPORT_EMAIL", ""),
            }
            body = render_to_string("emails/email_change_confirm.txt", ctx)
            send_email_task.delay(
                subject=f"[{site_name}] Confirm your new email address",
                message=body,
                recipient_list=[new_email],
            )
        except Exception as exc:
            logger.warning("EmailChangeService: could not send confirmation email: %s", exc)

        logger.info(
            "Email change requested",
            extra={"user_id": str(user.pk), "new_email": new_email},
        )
        return token

    @classmethod
    def confirm_change(cls, token_str: str, request=None) -> tuple:
        """Apply a pending email-address change.

        Args:
            token_str: The raw token string from the confirmation link.
            request: Optional Django request (used for audit logging).

        Returns:
            ``(user, new_email)`` tuple on success.

        Raises:
            ValueError: if the token is invalid, expired, or already used.
        """
        try:
            token = EmailChangeToken.objects.select_related("user").get(token=token_str, is_used=False)
        except EmailChangeToken.DoesNotExist:
            raise ValueError("Invalid or expired email-change token.") from None

        if not token.is_valid():
            raise ValueError("Email-change token has expired or already been used.")

        user = token.user
        new_email = token.new_email
        old_email = user.email

        with transaction.atomic():
            user.email = new_email
            user.save(update_fields=["email"])
            token.use_token()

            AuditLog.log_event(
                event_type="email_change",
                user=user,
                description=f"Email changed from {old_email} to {new_email}",
                ip_address=request.META.get("REMOTE_ADDR", "") if request else "",
                user_agent=request.META.get("HTTP_USER_AGENT", "") if request else "",
                metadata={"old_email": old_email, "new_email": new_email},
            )

        logger.info(
            "Email changed",
            extra={"user_id": str(user.pk), "old_email": old_email, "new_email": new_email},
        )
        return user, new_email


class PasswordService:
    """
    Service class for password-related operations.
    """

    @staticmethod
    def validate_password_change(user, old_password, new_password):
        """
        Validate password change request.

        Args:
            user: User instance
            old_password: Current password
            new_password: New password

        Returns:
            dict: Validation result
        """
        # Check if old password is correct
        if not user.check_password(old_password):
            return {"valid": False, "error": "Current password is incorrect"}

        # Validate new password strength
        from .utils.auth import validate_password_strength

        strength_result = validate_password_strength(new_password, user)

        if not strength_result.get("valid", False):
            return {
                "valid": False,
                "error": "New password does not meet security requirements",
                "details": strength_result,
            }

        return {"valid": True, "message": "Password validation successful"}

    @staticmethod
    def request_password_reset(email: str, request=None) -> bool:
        """
        Create a PasswordResetToken and send the reset email.
        Always returns True to prevent user enumeration.
        """
        from .utils.email import EmailService

        try:
            user = User.objects.get(email__iexact=email)
        except User.DoesNotExist:
            return True

        PasswordResetToken.objects.filter(user=user, is_used=False).update(is_used=True)

        token = str(uuid.uuid4())
        reset_token = PasswordResetToken.objects.create(
            user=user,
            token=token,
            expires_at=timezone.now() + timedelta(hours=1),
            ip_address=request.META.get("REMOTE_ADDR") if request else None,
            user_agent=(request.META.get("HTTP_USER_AGENT") or "")[:500] if request else "",
        )

        EmailService.send_password_reset_email(user=user, reset_token=reset_token)
        return True

    @staticmethod
    def reset_password(reset_token, new_password: str, request=None):
        """
        Set the user's new password, mark the token used, and invalidate all sessions.
        """
        with transaction.atomic():
            user = reset_token.user
            user.set_password(new_password)
            user.save(update_fields=["password"])
            reset_token.use_token()

            UserSession.objects.filter(user=user, is_active=True).update(is_active=False)

            AuditLog.log_event(
                event_type="password_reset_complete",
                user=user,
                description="Password reset via email link — all sessions terminated",
                ip_address=request.META.get("REMOTE_ADDR") if request else "127.0.0.1",
                risk_level="medium",
            )

        return user

    @staticmethod
    def change_password(user, new_password):
        """
        Change user password, invalidate all sessions/tokens, and log the action.

        After the password is set the method:
        1. Blacklists the refresh token for every active session.
        2. Deactivates all ``UserSession`` rows for the user.
        3. Creates an audit log entry.

        Args:
            user: User instance
            new_password: New password

        Returns:
            bool: Success status
        """
        try:
            with transaction.atomic():
                # Set the new password
                user.set_password(new_password)
                user.save()

                # Invalidate all active sessions and blacklist their tokens
                active_sessions = UserSession.objects.filter(user=user, is_active=True)
                for session in active_sessions:
                    session.invalidate_session_tokens(reason="password_change")
                # Bulk-deactivate any remaining active rows (belt-and-suspenders)
                active_sessions.update(is_active=False)

                # Log the password change
                AuditLog.log_event(
                    event_type="password_change",
                    user=user,
                    description="User changed their password — all sessions terminated",
                    ip_address="127.0.0.1",
                    risk_level="medium",
                )

            return True
        except DatabaseError as e:
            logger.error(f"Failed to change password for user {user.id}: {e}")
            return False


class SessionService:
    """
    Service class for session management operations.
    """

    @staticmethod
    def get_user_sessions(user):
        """
        Get all active sessions for a user.

        Args:
            user: User instance

        Returns:
            QuerySet of UserSession objects
        """
        return UserSession.objects.filter(user=user, is_active=True).order_by("-last_activity_at")

    @staticmethod
    def terminate_session(user, session_id):
        """
        Terminate a specific user session.

        Args:
            user: User instance
            session_id: ID of session to terminate

        Returns:
            bool: Success status
        """
        try:
            with transaction.atomic():
                session = UserSession.objects.get(id=session_id, user=user, is_active=True)
                session.is_active = False
                session.save()

                AuditLog.log_event(
                    event_type="session_terminated",
                    user=user,
                    description=f"Session {session_id} terminated",
                    ip_address="127.0.0.1",
                )

            return True
        except UserSession.DoesNotExist:
            logger.warning(f"Session {session_id} not found for user {user.id}")
            return False
        except DatabaseError as e:
            logger.error(f"Failed to terminate session {session_id}: {e}")
            return False

    @staticmethod
    def terminate_all_sessions(user, exclude_current=True, current_session_id=None):
        """
        Terminate all user sessions.

        Args:
            user: User instance
            exclude_current: Whether to exclude the current session
            current_session_id: ID of current session to exclude

        Returns:
            int: Number of sessions terminated
        """
        try:
            with transaction.atomic():
                sessions = UserSession.objects.filter(user=user, is_active=True)

                if exclude_current and current_session_id:
                    sessions = sessions.exclude(id=current_session_id)

                terminated_count = sessions.update(is_active=False)

                AuditLog.log_event(
                    event_type="session_terminated",
                    user=user,
                    description=f"Terminated {terminated_count} sessions",
                    ip_address="127.0.0.1",
                    risk_level="medium",
                )

            return terminated_count
        except DatabaseError as e:
            logger.error(f"Failed to terminate all sessions for user {user.id}: {e}")
            return 0

    @staticmethod
    def create_session(user, request):
        """
        Create a new user session.

        Args:
            user: User instance
            request: Django request object

        Returns:
            UserSession instance or None
        """
        try:
            from .utils.sessions import get_device_fingerprint

            session = UserSession.objects.create(
                user=user,
                device_name=request.META.get("HTTP_USER_AGENT", "Unknown Device")[:100],
                device_fingerprint=get_device_fingerprint(request),
                ip_address=request.META.get("REMOTE_ADDR", ""),
                user_agent=request.META.get("HTTP_USER_AGENT", ""),
                is_active=True,
            )

            _uid = user.pk
            transaction.on_commit(lambda: enforce_session_limit_task.delay(_uid))
            return session
        except DatabaseError as e:
            logger.error("Failed to create session", extra={"user_id": str(user.id), "error": str(e)})
            return None


class EmailVerificationService:
    """
    Service for handling email verification operations.

    Provides functionality for sending verification emails,
    validating tokens, and managing email verification state.
    """

    @staticmethod
    def send_verification_email(user):
        """
        Send verification email to user.

        Args:
            user: User instance to send verification email to

        Returns:
            bool: Success status
        """
        try:
            from .utils.auth import send_verification_email

            with transaction.atomic():
                # Generate verification token
                token = EmailVerificationToken.objects.create(user=user)

                # Send email
                send_verification_email(user, str(token.token))

                AuditLog.log_event(
                    event_type="email_verification",
                    user=user,
                    description="Email verification sent",
                )

            logger.info(f"Verification email sent to user {user.id}")
            return True

        except (DatabaseError, OSError) as e:
            logger.error(f"Failed to send verification email for user {user.id}: {e}")

            # Log the failure
            AuditLog.log_event(
                event_type="email_verification",
                user=user,
                description="Failed to send verification email",
                success=False,
                risk_level="medium",
                metadata={"error_type": type(e).__name__},
            )

            return False

    @staticmethod
    def verify_email_token(token_string):
        """
        Verify email verification token and mark email as verified.

        Args:
            token_string: Verification token string

        Returns:
            dict: Verification result with user and status
        """
        try:
            from .utils.auth import verify_email_token

            # Verify token using existing utility
            result = verify_email_token(token_string)

            if result.get("valid"):
                user = result.get("user")

                with transaction.atomic():
                    # Mark email as verified
                    user.email_verified = True
                    user.email_verified_at = timezone.now()
                    user.save()

                    AuditLog.log_event(
                        event_type="email_verification",
                        user=user,
                        description="Email verified successfully",
                    )

                logger.info(f"Email verified for user {user.id}")

                return {"valid": True, "user": user, "message": "Email verified successfully"}
            else:
                return {"valid": False, "error": result.get("error", "Invalid or expired token")}

        except DatabaseError as e:
            logger.error(f"Email verification failed: {e}")
            return {"valid": False, "error": "Verification failed"}

    @staticmethod
    def resend_verification_email(user):
        """
        Resend verification email to user.

        Args:
            user: User instance

        Returns:
            bool: Success status
        """
        # Check if email is already verified
        if user.email_verified:
            logger.warning(f"Attempted to resend verification to already verified user {user.id}")
            return False

        # Invalidate any existing tokens
        EmailVerificationToken.objects.filter(user=user, used=False).update(used=True)

        # Send new verification email
        return EmailVerificationService.send_verification_email(user)


class TokenService:
    """
    Service for token management operations.

    Placeholder for future token-related functionality beyond
    what's already provided by ExchangeTokenService.
    """

    pass
