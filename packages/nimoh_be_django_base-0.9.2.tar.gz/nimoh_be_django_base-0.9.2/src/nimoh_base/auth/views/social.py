"""
nimoh_base.auth.views.social
=============================
Ready-to-use done-view for the PSA OAuth dance.

Mount it in your project URLs::

    from nimoh_base.auth.views.social import social_login_done_view

    urlpatterns = [
        path("api/v1/auth/social/done/", social_login_done_view, name="social-auth-done"),
        path("api/v1/auth/social/", include("social_django.urls", namespace="social")),
    ]

Point PSA at it for fallback only (do NOT set SOCIAL_AUTH_NEW_USER_REDIRECT_URL)::

    SOCIAL_AUTH_LOGIN_REDIRECT_URL = "/api/v1/auth/social/done/"
"""

import logging
from urllib.parse import urlparse

from django.conf import settings as django_settings
from django.http import HttpResponseRedirect
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny

from nimoh_base.conf.social import SOCIAL_EXCHANGE_TOKEN_SESSION_KEY, _frontend_netloc

logger = logging.getLogger(__name__)


@api_view(["GET"])
@permission_classes([AllowAny])
def social_login_done_view(request):
    """
    GET handler for SOCIAL_AUTH_LOGIN_REDIRECT_URL (fallback when pipeline fails).

    Normally the pipeline step ``nimoh_social_generate_exchange_token`` embeds
    the exchange token in PSA's ``next`` URL, so the user is redirected
    directly to ``{FRONTEND_URL}/auth/verified?exchange_token=...`` and this
    view is never hit. If the pipeline step raises, PSA redirects here; this
    view then tries to read the token from the session (legacy path), handles
    PSA's ``?next=`` (defense-in-depth when NEW_USER_REDIRECT_URL was set), or
    redirects to /auth/verify-error.
    """
    frontend_url = getattr(django_settings, "FRONTEND_URL", "http://localhost:3000")
    frontend_netloc = _frontend_netloc(frontend_url)

    # Defense-in-depth: PSA may append our exchange-token URL as ?next= when
    # NEW_USER_REDIRECT_URL is set; forward there if host matches and URL has token.
    next_url = request.GET.get("next", "")
    if next_url and "exchange_token=" in next_url:
        parsed = urlparse(next_url)
        if not parsed.netloc or parsed.netloc == frontend_netloc:
            target = next_url if parsed.netloc else f"{frontend_url.rstrip('/')}/{next_url.lstrip('/')}"
            logger.info("Social auth done — forwarding to ?next= URL")
            return HttpResponseRedirect(target)

    # Legacy: token in session (when pipeline used session before we switched to 'next').
    django_request = getattr(request, "_request", request)
    exchange_token = django_request.session.pop(SOCIAL_EXCHANGE_TOKEN_SESSION_KEY, None)
    if exchange_token:
        django_request.session.save()
        logger.info("Social auth done — redirecting to /auth/verified")
        return HttpResponseRedirect(f"{frontend_url}/auth/verified?exchange_token={exchange_token}")

    logger.warning("social_login_done_view: no exchange token in session or next — pipeline step missing?")
    return HttpResponseRedirect(f"{frontend_url}/auth/verify-error?reason=social_auth_failed")
