# KRIM SDK

Programmable coding agent core. Build custom AI agents with ease.

## Installation

```bash
pip install krim-sdk
```

## Quick Start

```python
from krim_sdk import Agent, AgentOptions
from krim_sdk.models import ClaudeModel
from krim_sdk.tools import default_tools

# Create agent
agent = Agent(
    model=ClaudeModel(),
    provider="claude",
    system_prompt="You are a helpful coding assistant.",
    tools=default_tools(),
)

# Run
result = agent.run("Hello!")
print(agent.last_response)
```

## Custom Tools

```python
from krim_sdk import Tool

class MyTool(Tool):
    name = "my_tool"
    description = "Does something useful"
    parameters = {
        "input": {"type": "string", "description": "Input data"},
    }

    def run(self, input: str) -> str:
        return f"Processed: {input}"
```

## Event Handling

```python
from krim_sdk import Agent, EventHandler

class MyHandler(EventHandler):
    def on_stream(self, text: str) -> None:
        print(text, end="", flush=True)

    def on_tool_start(self, name: str, args: dict) -> None:
        print(f"\nRunning {name}...")

agent = Agent(
    model=model,
    system_prompt=prompt,
    tools=tools,
    event_handler=MyHandler(),
)
```

## License

MIT
