#!/usr/bin/env python3
"""Deep verification test suite for krim-sdk v0.4.1."""

import sys
import os
import json
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
for src_dir in (ROOT / "packages" / "krim-sdk" / "src", ROOT / "packages" / "krim" / "src"):
    src_path = str(src_dir)
    if src_path not in sys.path:
        sys.path.insert(0, src_path)

RUN_AS_SCRIPT = __name__ == "__main__"

PASS = 0
FAIL = 0
ERRORS = []

def test(name, fn):
    if not RUN_AS_SCRIPT:
        return
    global PASS, FAIL
    try:
        fn()
        PASS += 1
        print(f"  PASS  {name}")
    except Exception as e:
        FAIL += 1
        ERRORS.append((name, str(e)))
        print(f"  FAIL  {name}: {e}")

test.__test__ = False

# ============================================================
# 1. IMPORTS
# ============================================================
print("\n=== IMPORTS ===")

def test_core_imports():
    from krim_sdk import Agent, AgentOptions, RunStats
    from krim_sdk import EventHandler, Event, EventType
    from krim_sdk import Tool, Model, ModelResponse, ToolCall
    from krim_sdk import Hooks, HookMatcher, HookContext, HookResult
    from krim_sdk import KrimConfig, load_config
    from krim_sdk import KrimSDKError, RetryableError, ToolError, ModelError
    assert Agent is not None
    assert Tool is not None
test("imports: core classes", test_core_imports)

def test_tools_imports():
    from krim_sdk.tools import default_tools, BashTool, ReadTool, WriteTool
    from krim_sdk.tools import EditTool, GrepTool, GlobTool, SubmitTool
    tools = default_tools()
    assert len(tools) == 7
    names = {t.name for t in tools}
    assert names == {"bash", "read", "write", "edit", "grep", "glob", "submit"}
test("imports: tools", test_tools_imports)

def test_models_imports():
    from krim_sdk.models import ClaudeModel, OpenAIModel, VertexModel
    from krim_sdk.models import Model, ModelResponse, ToolCall
    assert ClaudeModel is not None
    assert OpenAIModel is not None
test("imports: models", test_models_imports)

# ============================================================
# 2. SAFETY MODULE
# ============================================================
print("\n=== SAFETY MODULE ===")

def test_safety_word_boundary():
    from krim_sdk.safety import Action, check_command
    assert check_command("ls", [], ["ls"], True) == Action.ALLOW
    assert check_command("lsblk", [], ["ls"], True) == Action.ASK
    assert check_command("ls -la", [], ["ls"], True) == Action.ALLOW
test("safety: word boundary ls vs lsblk", test_safety_word_boundary)

def test_safety_deny_priority():
    from krim_sdk.safety import Action, check_command
    assert check_command("rm -rf /", ["rm -rf /"], ["rm"], True) == Action.DENY
test("safety: deny > allow priority", test_safety_deny_priority)

def test_safety_dd_no_false_positive():
    from krim_sdk.safety import Action, check_command
    assert check_command("add if=something", ["dd if="], [], True) == Action.ASK
    assert check_command("dd if=/dev/zero", ["dd if="], [], True) == Action.DENY
test("safety: dd if= no false positive", test_safety_dd_no_false_positive)

# ============================================================
# 3. BASH TOOL
# ============================================================
print("\n=== BASH TOOL ===")

def test_bash_cwd_persistence():
    from krim_sdk.tools import BashTool
    bt = BashTool()
    bt.configure(deny_patterns=[], allow_commands=[], ask_by_default=False)
    bt.run("cd /tmp")
    assert "/tmp" in bt.cwd or "/private/tmp" in bt.cwd
test("bash: cwd persistence", test_bash_cwd_persistence)

def test_bash_exit_code():
    from krim_sdk.tools import BashTool
    bt = BashTool()
    bt.configure(deny_patterns=[], allow_commands=[], ask_by_default=False)
    result = bt.run("exit 42")
    assert "[exit code: 42]" in result
test("bash: exit code preservation", test_bash_exit_code)

def test_bash_denied():
    from krim_sdk.tools import BashTool
    bt = BashTool()
    bt.configure(deny_patterns=["rm -rf /"], allow_commands=[], ask_by_default=False)
    result = bt.run("rm -rf /")
    assert "denied" in result
test("bash: denied command", test_bash_denied)

def test_bash_ask_without_callback():
    from krim_sdk.tools import BashTool
    bt = BashTool()
    bt.configure(deny_patterns=[], allow_commands=[], ask_by_default=True, ask_callback=None)
    result = bt.run("some_command")
    assert "requires approval" in result or "no ask_callback" in result
test("bash: ask without callback", test_bash_ask_without_callback)

def test_bash_ask_with_callback():
    from krim_sdk.tools import BashTool
    bt = BashTool()
    approved = []
    def callback(cmd):
        approved.append(cmd)
        return True
    bt.configure(deny_patterns=[], allow_commands=[], ask_by_default=True, ask_callback=callback)
    result = bt.run("echo hello")
    assert "hello" in result
    assert "echo hello" in approved
test("bash: ask with callback", test_bash_ask_with_callback)

# ============================================================
# 4. COMPACTION
# ============================================================
print("\n=== COMPACTION ===")

def test_compact_short():
    from krim_sdk.compaction import compact
    msgs = [
        {"role": "system", "content": "sys"},
        {"role": "user", "content": "hi"},
    ]
    result = compact(msgs)
    assert len(result) == 2
test("compaction: short messages unchanged", test_compact_short)

def test_compact_token_estimation():
    from krim_sdk.compaction import estimate_tokens
    assert estimate_tokens("") == 0
    assert estimate_tokens("a" * 35) == 10  # 35 / 3.5 = 10
    korean = "안녕하세요"  # 5 CJK chars
    assert estimate_tokens(korean) >= 3
test("compaction: token estimation", test_compact_token_estimation)

# ============================================================
# 5. EDIT TOOL
# ============================================================
print("\n=== EDIT TOOL ===")

def test_edit_hashline_replace():
    from krim_sdk.tools import EditTool
    from krim_sdk.tools.hashline import hash_line
    et = EditTool()
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write("def foo():\n    return 1\n")
        f.flush()
        path = f.name
    try:
        line_hash = hash_line("    return 1")
        result = et.run(path, line=f"2:{line_hash}", new="    return 2")
        assert "edited" in result
        with open(path) as fh:
            assert "return 2" in fh.read()
    finally:
        os.unlink(path)
test("edit: hashline replace", test_edit_hashline_replace)

def test_edit_hash_mismatch():
    from krim_sdk.tools import EditTool
    et = EditTool()
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write("x = 1\n")
        f.flush()
        path = f.name
    try:
        result = et.run(path, line="1:fff", new="x = 2")
        assert "hash mismatch" in result
    finally:
        os.unlink(path)
test("edit: hash mismatch", test_edit_hash_mismatch)

# ============================================================
# 6. READ TOOL
# ============================================================
print("\n=== READ TOOL ===")

def test_read_basic():
    from krim_sdk.tools import ReadTool
    rt = ReadTool()
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write("line1\nline2\n")
        f.flush()
        path = f.name
    try:
        result = rt.run(path)
        assert "line1" in result
        assert "line2" in result
    finally:
        os.unlink(path)
test("read: basic file read", test_read_basic)

def test_read_hashlines():
    from krim_sdk.tools import ReadTool
    rt = ReadTool()
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write("hello\nworld\n")
        f.flush()
        path = f.name
    try:
        result = rt.run(path)
        # hashline format: 1:xxx|hello
        assert "|hello" in result
        assert "|world" in result
    finally:
        os.unlink(path)
test("read: hashline format", test_read_hashlines)

# ============================================================
# 7. WRITE TOOL
# ============================================================
print("\n=== WRITE TOOL ===")

def test_write_creates_parent():
    from krim_sdk.tools import WriteTool
    wt = WriteTool()
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "sub", "dir", "file.py")
        result = wt.run(path, "hello")
        assert "wrote" in result
        with open(path) as f:
            assert f.read() == "hello"
test("write: creates parent directories", test_write_creates_parent)

# ============================================================
# 8. EVENT HANDLER
# ============================================================
print("\n=== EVENT HANDLER ===")

def test_null_handler():
    from krim_sdk import NullEventHandler, Event, EventType
    handler = NullEventHandler()
    handler.on_stream("test")
    handler.on_tool_start("bash", {})
    handler.on_tool_end("bash", "result")
    assert handler.on_tool_ask("bash", "ls") == True  # default allow
test("event: null handler", test_null_handler)

def test_print_handler():
    from krim_sdk import PrintEventHandler
    handler = PrintEventHandler()
    # Should not raise
    handler.on_stream("test")
    handler.on_tool_start("bash", {"command": "ls"})
test("event: print handler", test_print_handler)

def test_custom_handler():
    from krim_sdk import EventHandler

    class MyHandler(EventHandler):
        def __init__(self):
            self.events = []
        def on_stream(self, text):
            self.events.append(("stream", text))
        def on_tool_start(self, name, args):
            self.events.append(("tool_start", name))
        def on_tool_ask(self, tool_name, command):
            return False  # deny all

    handler = MyHandler()
    handler.on_stream("hello")
    handler.on_tool_start("bash", {})
    assert ("stream", "hello") in handler.events
    assert ("tool_start", "bash") in handler.events
    assert handler.on_tool_ask("bash", "rm -rf /") == False
test("event: custom handler", test_custom_handler)

# ============================================================
# 9. HOOKS
# ============================================================
print("\n=== HOOKS ===")

def test_hook_matcher():
    from krim_sdk import HookMatcher
    m = HookMatcher("bash")
    assert m.matches("bash")
    assert not m.matches("read")
test("hooks: matcher basic", test_hook_matcher)

def test_hook_matcher_regex():
    from krim_sdk import HookMatcher
    m = HookMatcher("Write|Edit")
    assert m.matches("Write")
    assert m.matches("Edit")
    assert not m.matches("read")
test("hooks: matcher regex", test_hook_matcher_regex)

def test_hooks_pre_tool():
    from krim_sdk import Hooks, HookMatcher, HookContext, HookResult

    blocked_commands = []
    def block_rm(ctx):
        if "rm" in str(ctx.tool_args):
            blocked_commands.append(ctx.tool_args)
            return HookResult(block=True, block_message="rm blocked")
        return None

    hooks = Hooks(pre_tool_use=[HookMatcher("bash", hooks=[block_rm])])
    result = hooks.run_pre_tool_hooks("bash", {"command": "rm -rf /"}, [], 1)
    assert result is not None
    assert result.block == True
    assert "rm blocked" in result.block_message
test("hooks: pre-tool blocking", test_hooks_pre_tool)

# ============================================================
# 10. TOOL SCHEMA
# ============================================================
print("\n=== TOOL SCHEMA ===")

def test_tool_schema():
    from krim_sdk.tools import default_tools
    tools = default_tools()
    for t in tools:
        schema = t.schema()
        assert "name" in schema
        assert "description" in schema
        assert "input_schema" in schema
        assert schema["input_schema"]["type"] == "object"
        assert "properties" in schema["input_schema"]
        assert "required" in schema["input_schema"]
test("schema: correct structure", test_tool_schema)

def test_tool_schema_optional():
    from krim_sdk.tools import BashTool
    bt = BashTool()
    schema = bt.schema()
    assert "command" in schema["input_schema"]["required"]
    assert "timeout" not in schema["input_schema"]["required"]
    assert "optional" not in schema["input_schema"]["properties"]["timeout"]
test("schema: optional params excluded", test_tool_schema_optional)

# ============================================================
# 11. CUSTOM TOOL
# ============================================================
print("\n=== CUSTOM TOOL ===")

def test_custom_tool():
    from krim_sdk import Tool

    class MyTool(Tool):
        name = "my_tool"
        description = "Does something"
        parameters = {
            "input": {"type": "string", "description": "Input data"},
            "optional_param": {"type": "string", "optional": True},
        }
        def run(self, input: str, optional_param: str = None) -> str:
            return f"processed: {input}"

    tool = MyTool()
    assert tool.name == "my_tool"
    result = tool.run(input="hello")
    assert "processed: hello" in result

    schema = tool.schema()
    assert schema["name"] == "my_tool"
    assert "input" in schema["input_schema"]["required"]
    assert "optional_param" not in schema["input_schema"]["required"]
test("custom tool: creation and run", test_custom_tool)

# ============================================================
# 12. RETRY
# ============================================================
print("\n=== RETRY ===")

def test_retry_success():
    from krim_sdk.retry import with_retry
    call_count = 0
    def fn():
        nonlocal call_count
        call_count += 1
        return "ok"
    wrapped = with_retry(fn, max_retries=3, base_delay=0.01)
    result = wrapped()
    assert result == "ok"
    assert call_count == 1
test("retry: success first attempt", test_retry_success)

def test_retry_callback():
    from krim_sdk.retry import with_retry
    retries = []
    def on_retry(attempt, max_retries, error, delay):
        retries.append((attempt, max_retries))

    call_count = 0
    def fn():
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            raise TimeoutError("timeout")
        return "ok"

    wrapped = with_retry(fn, max_retries=3, base_delay=0.01, on_retry=on_retry)
    result = wrapped()
    assert result == "ok"
    assert len(retries) == 2  # 2 retries before success
test("retry: callback called", test_retry_callback)

# ============================================================
# 13. CONFIG
# ============================================================
print("\n=== CONFIG ===")

def test_config_merge():
    from krim_sdk.config import _merge_config
    base = {"a": 1, "b": {"x": 1, "y": 2}}
    override = {"b": {"y": 3, "z": 4}, "c": 5}
    result = _merge_config(base, override)
    assert result == {"a": 1, "b": {"x": 1, "y": 3, "z": 4}, "c": 5}
test("config: deep merge", test_config_merge)

def test_config_defaults():
    from krim_sdk import KrimConfig
    cfg = KrimConfig()
    assert cfg.provider == "claude"
    assert cfg.max_turns == 10
    assert len(cfg.deny_patterns) > 0
test("config: defaults", test_config_defaults)

# ============================================================
# 14. TRUNCATE
# ============================================================
print("\n=== TRUNCATE ===")

def test_truncate_short():
    from krim_sdk.truncate import truncate
    assert truncate("short", 100) == "short"
test("truncate: short unchanged", test_truncate_short)

def test_truncate_long():
    from krim_sdk.truncate import truncate
    text = "A" * 100 + "B" * 100
    result = truncate(text, 50)
    assert "A" in result
    assert "B" in result
    assert "truncated" in result
test("truncate: head/tail preserved", test_truncate_long)

# ============================================================
# 15. AGENT MESSAGE FORMAT
# ============================================================
print("\n=== AGENT MESSAGE FORMAT ===")

def test_claude_assistant_msg():
    from krim_sdk.agent import _build_assistant_msg_claude
    from krim_sdk import ModelResponse, ToolCall
    resp = ModelResponse(
        text="thinking...",
        tool_calls=[ToolCall(id="t1", name="bash", args={"command": "ls"})],
        stop=False,
    )
    msg = _build_assistant_msg_claude(resp)
    assert msg["role"] == "assistant"
    assert len(msg["content"]) == 2
    assert msg["content"][0] == {"type": "text", "text": "thinking..."}
    assert msg["content"][1]["type"] == "tool_use"
test("agent: claude assistant message", test_claude_assistant_msg)

def test_openai_assistant_msg():
    from krim_sdk.agent import _build_assistant_msg_openai
    from krim_sdk import ModelResponse, ToolCall
    resp = ModelResponse(
        text="thinking...",
        tool_calls=[ToolCall(id="t1", name="bash", args={"command": "ls"})],
        stop=False,
    )
    msg = _build_assistant_msg_openai(resp)
    assert msg["role"] == "assistant"
    assert msg["content"] == "thinking..."
    assert len(msg["tool_calls"]) == 1
test("agent: openai assistant message", test_openai_assistant_msg)

# ============================================================
# 16. AGENT DOOM LOOP
# ============================================================
print("\n=== AGENT DOOM LOOP ===")

def test_doom_loop_detection():
    from krim_sdk import Agent, AgentOptions, Model, ModelResponse, ToolCall

    class MockModel(Model):
        def chat(self, messages, tools, stream_callback=None):
            return ModelResponse(text="ok", tool_calls=[], stop=True)

    agent = Agent(MockModel(), "claude", "sys", [], options=AgentOptions(max_turns=10))
    tc = [ToolCall(id="t1", name="bash", args={"command": "ls"})]
    assert not agent._check_doom_loop(tc)
    assert not agent._check_doom_loop(tc)
    assert agent._check_doom_loop(tc)  # 3rd triggers
test("doom loop: triggers on 3rd identical", test_doom_loop_detection)

# ============================================================
# 17. AGENT FULL LOOP
# ============================================================
print("\n=== AGENT FULL LOOP ===")

def test_agent_tool_execution():
    from krim_sdk import Agent, AgentOptions, Model, ModelResponse
    from krim_sdk.tools import default_tools

    class MockModel(Model):
        def chat(self, messages, tools, stream_callback=None):
            return ModelResponse(text="ok", tool_calls=[], stop=True)

    tools = default_tools()
    agent = Agent(MockModel(), "claude", "sys", tools, options=AgentOptions(max_turns=1))

    result = agent._execute_tool("read", {"path": "/nonexistent/file.py"}, 1)
    assert "not found" in result

    result = agent._execute_tool("unknown_tool", {}, 1)
    assert "unknown tool" in result
test("agent: tool execution dispatch", test_agent_tool_execution)

def test_agent_with_event_handler():
    from krim_sdk import Agent, AgentOptions, Model, ModelResponse, EventHandler, ToolCall
    from krim_sdk.tools import default_tools, BashTool

    events = []
    class TrackingHandler(EventHandler):
        def on_tool_start(self, name, args):
            events.append(("start", name))
        def on_tool_end(self, name, result):
            events.append(("end", name))
        def on_tool_ask(self, tool_name, command):
            return True

    call_count = 0
    class MockModel(Model):
        def chat(self, messages, tools, stream_callback=None):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return ModelResponse(
                    text=None,
                    tool_calls=[ToolCall(id="t1", name="bash", args={"command": "echo hi"})],
                    stop=False,
                )
            return ModelResponse(text="done", tool_calls=[], stop=True)

    tools = default_tools()
    for t in tools:
        if isinstance(t, BashTool):
            t.configure(deny_patterns=[], allow_commands=[], ask_by_default=False)

    agent = Agent(
        MockModel(), "claude", "sys", tools,
        options=AgentOptions(max_turns=5),
        event_handler=TrackingHandler()
    )
    agent.run("test")

    assert ("start", "bash") in events
    assert ("end", "bash") in events
test("agent: event handler integration", test_agent_with_event_handler)

def test_agent_tracks_model_error():
    from krim_sdk import Agent, AgentOptions, Model, EventHandler, EventType

    events = []

    class TrackingHandler(EventHandler):
        def on_event(self, event):
            events.append((event.type, event.data))

    class FailingModel(Model):
        def chat(self, messages, tools, stream_callback=None):
            raise RuntimeError("missing api key")

    agent = Agent(
        FailingModel(),
        "claude",
        "sys",
        [],
        options=AgentOptions(max_turns=2),
        event_handler=TrackingHandler(),
    )

    stats = agent.run("test")

    assert stats.turns == 1
    assert agent.last_response is None
    assert agent.last_error is not None
    assert "missing api key" in str(agent.last_error)
    assert any(event_type == EventType.MODEL_ERROR for event_type, _ in events)
test("agent: model error tracking", test_agent_tracks_model_error)

def test_agent_tracks_finalize_error_after_max_turns():
    from krim_sdk import Agent, AgentOptions, Model, EventHandler, EventType, ToolCall, ModelResponse
    from krim_sdk.tools.base import Tool

    events = []

    class TrackingHandler(EventHandler):
        def on_event(self, event):
            events.append((event.type, event.data))

    class NoopTool(Tool):
        name = "noop"
        description = "No-op tool"
        parameters = {}

        def run(self, **kwargs):
            return "ok"

    class FinalizeFailingModel(Model):
        def __init__(self):
            self.calls = 0

        def chat(self, messages, tools, stream_callback=None):
            self.calls += 1
            if self.calls == 1:
                return ModelResponse(
                    text=None,
                    tool_calls=[ToolCall(id="t1", name="noop", args={})],
                    stop=False,
                )
            raise RuntimeError("finalize failed")

    agent = Agent(
        FinalizeFailingModel(),
        "claude",
        "sys",
        [NoopTool()],
        options=AgentOptions(max_turns=1),
        event_handler=TrackingHandler(),
    )

    stats = agent.run("test")

    assert stats.turns == 1
    assert agent.last_error is not None
    assert "finalize failed" in str(agent.last_error)
    assert any(event_type == EventType.MAX_TURNS for event_type, _ in events)
    assert any(event_type == EventType.MODEL_ERROR for event_type, _ in events)
test("agent: finalize error tracking after max turns", test_agent_tracks_finalize_error_after_max_turns)

# ============================================================
# 18. SKILLS
# ============================================================
print("\n=== SKILLS ===")

def test_skill_discovery():
    from krim_sdk import discover_skills, Skill
    from pathlib import Path
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        skills_dir = Path(td) / "skills"
        deploy_dir = skills_dir / "deploy"
        deploy_dir.mkdir(parents=True)
        (deploy_dir / "SKILL.md").write_text("""---
name: deploy
description: Deploy to production
---
Deploy instructions here.""")

        skills = discover_skills(global_dir=Path(td))
        assert "deploy" in skills
        assert skills["deploy"].name == "deploy"
        assert skills["deploy"].description == "Deploy to production"
        assert "Deploy instructions" in skills["deploy"].prompt
test("skills: discovery", test_skill_discovery)

def test_skill_tool():
    from krim_sdk.tools import SkillTool
    from krim_sdk import Skill

    tool = SkillTool()

    # Not configured
    result = tool.run("test")
    assert "no skills configured" in result

    # Configure
    tool.configure({
        "deploy": Skill(name="deploy", prompt="Deploy now!", path="/tmp", description="Deploy")
    })

    # Valid skill
    result = tool.run("deploy")
    assert "# Skill: deploy" in result
    assert "Deploy now!" in result

    # Invalid skill
    result = tool.run("nonexistent")
    assert "not found" in result
test("skills: skill tool", test_skill_tool)

def test_skill_tool_with_args():
    from krim_sdk.tools import SkillTool
    from krim_sdk import Skill

    tool = SkillTool()
    tool.configure({
        "greet": Skill(name="greet", prompt="Say hello to $ARGUMENTS", path="/tmp")
    })

    result = tool.run("greet", args="World")
    assert "Say hello to World" in result
test("skills: skill tool with args", test_skill_tool_with_args)

def test_skills_in_prompt():
    from krim_sdk import build_system_prompt, KrimConfig, Skill

    config = KrimConfig()
    skills = {
        "deploy": Skill(name="deploy", prompt="...", path="/tmp", description="Deploy to prod"),
        "test": Skill(name="test", prompt="...", path="/tmp", description="Run tests"),
    }

    prompt = build_system_prompt(config, skills=skills)
    assert "# Available Skills" in prompt
    assert "deploy" in prompt
    assert "Deploy to prod" in prompt
    assert "test" in prompt
test("skills: in system prompt", test_skills_in_prompt)

def test_core_prompt_overlay():
    from krim_sdk import build_core_prompt

    prompt = build_core_prompt(
        identity_line="You are KiraClaw, a coding agent running in the user's local daemon.",
        tool_names=["read", "write", "edit", "bash", "grep", "glob", "submit"],
    )

    lines = prompt.splitlines()
    assert lines[0] == "You are KiraClaw, a coding agent running in the user's local daemon."
    assert lines[1] == "You have tools: read, write, edit, bash, grep, glob, submit."
    assert "IMPORTANT: submit(summary) ends session." in prompt
test("prompt: core overlay preserves KRIM contract", test_core_prompt_overlay)

def test_default_tools_with_skills():
    from krim_sdk.tools import default_tools_with_skills
    from krim_sdk import Skill

    tools, skill_tool = default_tools_with_skills()
    assert len(tools) == 8  # 7 + skill

    # Configure and test
    skill_tool.configure({"test": Skill(name="test", prompt="Test!", path="/tmp")})
    result = skill_tool.run("test")
    assert "Test!" in result
test("skills: default_tools_with_skills", test_default_tools_with_skills)

# ============================================================
# SUMMARY
# ============================================================
if RUN_AS_SCRIPT:
    print(f"\n{'='*60}")
    print(f"RESULTS: {PASS} PASS, {FAIL} FAIL (total: {PASS + FAIL})")
    print(f"{'='*60}")

    if ERRORS:
        print("\nFAILURES:")
        for name, err in ERRORS:
            print(f"  {name}")
            print(f"    {err}")

    sys.exit(1 if FAIL > 0 else 0)
