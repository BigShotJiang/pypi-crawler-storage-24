from __future__ import annotations

import sys
from types import SimpleNamespace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "packages" / "krim-sdk" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from krim_sdk.models.openai import OpenAIModel


class _FakeCompletions:
    def __init__(self) -> None:
        self.calls: list[dict] = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        message = SimpleNamespace(content="ok", tool_calls=None)
        choice = SimpleNamespace(message=message, finish_reason="stop")
        return SimpleNamespace(choices=[choice])


class _FakeClient:
    def __init__(self) -> None:
        self.chat = SimpleNamespace(completions=_FakeCompletions())


def test_openai_model_uses_max_completion_tokens_for_gpt_5(monkeypatch) -> None:
    fake_client = _FakeClient()
    monkeypatch.setattr("krim_sdk.models.openai.OpenAI", lambda api_key=None: fake_client)

    model = OpenAIModel(model="gpt-5.2", max_tokens=1234)
    model.chat(messages=[{"role": "user", "content": "hi"}], tools=[])

    kwargs = fake_client.chat.completions.calls[0]
    assert kwargs["max_completion_tokens"] == 1234
    assert "max_tokens" not in kwargs


def test_openai_model_keeps_max_tokens_for_legacy_chat_models(monkeypatch) -> None:
    fake_client = _FakeClient()
    monkeypatch.setattr("krim_sdk.models.openai.OpenAI", lambda api_key=None: fake_client)

    model = OpenAIModel(model="gpt-4o-mini", max_tokens=4321)
    model.chat(messages=[{"role": "user", "content": "hi"}], tools=[])

    kwargs = fake_client.chat.completions.calls[0]
    assert kwargs["max_tokens"] == 4321
    assert "max_completion_tokens" not in kwargs
