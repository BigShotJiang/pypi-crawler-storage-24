"""KRIM SDK - Programmable coding agent core.

Example:
    from krim_sdk import Agent, AgentOptions
    from krim_sdk.models import ClaudeModel

    agent = Agent(
        model=ClaudeModel(),
        provider="claude",
        system_prompt="You are a helpful assistant.",
        tools=[],
    )
    result = agent.run("Hello!")
    print(agent.last_response)
"""

__version__ = "0.4.1"

from krim_sdk.agent import Agent, AgentOptions, RunStats
from krim_sdk.events import (
    Event,
    EventType,
    EventHandler,
    NullEventHandler,
    PrintEventHandler,
)
from krim_sdk.hooks import (
    Hooks,
    HookMatcher,
    HookContext,
    HookResult,
    HookCallback,
)
from krim_sdk.errors import (
    KrimSDKError,
    RetryableError,
    ToolError,
    ModelError,
    ConfigError,
    HookBlockedError,
)
from krim_sdk.models.base import Model, ModelResponse, ToolCall
from krim_sdk.tools.base import Tool
from krim_sdk.config import KrimConfig, load_config
from krim_sdk.skills import Skill, discover_skills, get_skill_content
from krim_sdk.prompt import build_core_prompt, build_system_prompt

__all__ = [
    # Version
    "__version__",
    # Core
    "Agent",
    "AgentOptions",
    "RunStats",
    # Events
    "Event",
    "EventType",
    "EventHandler",
    "NullEventHandler",
    "PrintEventHandler",
    # Hooks
    "Hooks",
    "HookMatcher",
    "HookContext",
    "HookResult",
    "HookCallback",
    # Models
    "Model",
    "ModelResponse",
    "ToolCall",
    # Tools
    "Tool",
    # Config
    "KrimConfig",
    "load_config",
    # Prompt
    "build_core_prompt",
    "build_system_prompt",
    # Skills
    "Skill",
    "discover_skills",
    "get_skill_content",
    # Errors
    "KrimSDKError",
    "RetryableError",
    "ToolError",
    "ModelError",
    "ConfigError",
    "HookBlockedError",
]
