"""Core agent loop. Single loop, no sub-agents. Trust the model.

Features:
- Retry on API errors with exponential backoff
- Tool execution with error boundaries
- Doom loop detection (same tool call repeated)
- Context compaction when approaching token limits
- Max turns enforcement with graceful degradation
- Per-run stats tracking (turns, tool calls, token estimates)
- EventHandler-based output (no direct console output)
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from krim_sdk.models.base import Model, ModelResponse, ToolCall
from krim_sdk.tools.base import Tool
from krim_sdk.compaction import needs_compaction, compact, estimate_message_tokens
from krim_sdk.retry import with_retry
from krim_sdk.events import EventHandler, Event, EventType, NullEventHandler
from krim_sdk.hooks import Hooks
from krim_sdk.errors import ModelError


@dataclass
class RunStats:
    """Stats for a single agent.run() invocation."""
    turns: int = 0
    tool_calls: int = 0
    compactions: int = 0
    tool_call_names: dict[str, int] = field(default_factory=dict)

    def record_tool_call(self, name: str):
        self.tool_calls += 1
        self.tool_call_names[name] = self.tool_call_names.get(name, 0) + 1


@dataclass
class AgentOptions:
    """Configuration options for Agent."""
    max_turns: int = 10
    token_limit: int = 120_000
    log_dir: str | None = None


MAX_STEPS_PROMPT = (
    "You have reached the maximum number of turns. "
    "You MUST finish now. If there are pending changes, finalize them immediately. "
    "Write any remaining files and verify critical results. "
    "Then provide a brief summary of what was accomplished and what remains."
)

DOOM_RECOVERY_PROMPT = (
    "You are repeating the same action. This approach is not working. "
    "Stop and reconsider: try a completely different strategy, "
    "read error messages carefully, or check your assumptions."
)

LAST_TURN_WARNING = (
    "\n[SYSTEM: You have {remaining} turn(s) remaining. "
    "Prioritize completing the task over exploration. "
    "Finalize any changes and verify results NOW.]"
)

NUDGE_PROMPT = (
    "You provided thoughts but did not call any tools. "
    "If you are still working, please proceed with your next action. "
    "If you have completed the task, you MUST call the `submit` tool to finish."
)

NUDGE_WARNING_PROMPT = (
    "WARNING: You have not used any tools for 3 consecutive turns. "
    "Stop thinking and take ACTION now. Either use tools to continue working, "
    "or call `submit` if you are done."
)


# -- message builders (provider-specific formatting) --

def _build_assistant_msg_claude(response: ModelResponse) -> dict:
    content = []
    if response.text:
        content.append({"type": "text", "text": response.text})
    for tc in response.tool_calls:
        content.append({
            "type": "tool_use",
            "id": tc.id,
            "name": tc.name,
            "input": tc.args,
        })
    return {"role": "assistant", "content": content}


def _build_assistant_msg_openai(response: ModelResponse) -> dict:
    msg: dict = {"role": "assistant"}
    if response.text:
        msg["content"] = response.text
    if response.tool_calls:
        msg["tool_calls"] = [
            {
                "id": tc.id,
                "type": "function",
                "function": {
                    "name": tc.name,
                    "arguments": json.dumps(tc.args),
                },
            }
            for tc in response.tool_calls
        ]
    return msg


def _build_tool_result_openai(tool_call_id: str, name: str, result: str) -> dict:
    return {
        "role": "tool",
        "tool_call_id": tool_call_id,
        "name": name,
        "content": result,
    }


# Image marker from read.py
_IMAGE_MARKER = "<<<IMAGE:"


def _parse_image_result(result: str) -> dict | None:
    """Parse image marker and return Claude API image block, or None if not an image."""
    if not result.startswith(_IMAGE_MARKER):
        return None
    try:
        # Format: <<<IMAGE:media_type:base64_data>>>
        content = result[len(_IMAGE_MARKER):-3]  # Remove marker and closing >>>
        media_type, b64_data = content.split(":", 1)
        return {
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": media_type,
                "data": b64_data,
            }
        }
    except Exception:
        return None


def _build_tool_result_content_claude(result: str) -> list | str:
    """Build tool result content for Claude API. Returns image block list or string."""
    image_block = _parse_image_result(result)
    if image_block:
        return [image_block]
    return result


def tool_schemas(tools: list[Tool]) -> list[dict]:
    """Generate tool schemas from Tool instances."""
    return [t.schema() for t in tools]


def get_tool(tools: list[Tool], name: str) -> Tool | None:
    """Find a tool by name."""
    for t in tools:
        if t.name == name:
            return t
    return None


class Agent:
    def __init__(
        self,
        model: Model,
        provider: str,
        system_prompt: str,
        tools: list[Tool],
        mcp_tools: list[Tool] | None = None,
        options: AgentOptions | None = None,
        event_handler: EventHandler | None = None,
        hooks: Hooks | None = None,
    ):
        self.model = model
        self.provider = provider
        self.tools = tools
        self.mcp_tools = mcp_tools or []

        opts = options or AgentOptions()
        self.max_turns = opts.max_turns
        self.token_limit = opts.token_limit
        self.log_dir = opts.log_dir

        self._system_prompt = system_prompt  # keep for logging
        self.messages: list = [{"role": "system", "content": system_prompt}]

        # event handler for output
        self._handler = event_handler or NullEventHandler()

        # hooks for intercepting behavior
        self._hooks = hooks or Hooks()

        # doom loop detection: track recent tool calls + recovery count
        self._recent_calls: list[str] = []
        self._doom_recoveries: int = 0

        # consecutive no-tool turns (for nudge logic)
        self._consecutive_no_tool_turns: int = 0

        # track last meaningful response for final output
        self._last_response: str | None = None
        self._last_error: ModelError | None = None

        # cumulative stats
        self.last_stats: RunStats | None = None
        self.total_turns: int = 0
        self.total_tool_calls: int = 0

    def _record_model_error(self, error: Exception) -> None:
        """Store the latest model error and emit a single error event."""
        self._last_error = error if isinstance(error, ModelError) else ModelError(str(error))
        self._handler.on_event(Event(type=EventType.MODEL_ERROR, data={"error": str(self._last_error)}))

    # -- tool management --

    def _all_tool_schemas(self) -> list[dict]:
        schemas = tool_schemas(self.tools)
        for mt in self.mcp_tools:
            schemas.append(mt.schema())
        return schemas

    def _execute_tool(self, name: str, args: dict, turn: int) -> str:
        """Execute a tool with hooks and error boundary."""
        # Run pre-tool hooks
        hook_result = self._hooks.run_pre_tool_hooks(name, args, self.messages, turn)
        if hook_result and hook_result.block:
            return f"blocked by hook: {hook_result.block_message or name}"
        if hook_result and hook_result.modified_args:
            args = hook_result.modified_args

        # Emit tool start event
        self._handler.on_tool_start(name, args)

        # check mcp tools first
        for mt in self.mcp_tools:
            if mt.name == name:
                try:
                    result = mt.run(**args)
                except Exception as e:
                    result = f"error: tool '{name}' raised: {e}"
                break
        else:
            tool = get_tool(self.tools, name)
            if not tool:
                result = f"error: unknown tool '{name}'"
            else:
                try:
                    result = tool.run(**args)
                except Exception as e:
                    result = f"error: tool '{name}' raised: {e}"

        # Run post-tool hooks
        result = self._hooks.run_post_tool_hooks(name, result, self.messages, turn)

        # Emit tool end event
        self._handler.on_tool_end(name, result)

        return result

    # -- doom loop detection --

    def _check_doom_loop(self, tool_calls: list[ToolCall]) -> bool:
        """Detect if the agent is stuck calling the same tools repeatedly."""
        sig = json.dumps([(tc.name, tc.args) for tc in tool_calls], sort_keys=True)
        self._recent_calls.append(sig)
        if len(self._recent_calls) > 10:
            self._recent_calls = self._recent_calls[-10:]

        # same call 3 times in a row
        if len(self._recent_calls) >= 3:
            last3 = self._recent_calls[-3:]
            if last3[0] == last3[1] == last3[2]:
                return True
        return False

    def _build_turn_hint(self, current_turn: int) -> str | None:
        """Build context hint for the agent based on current state."""
        parts = []
        # doom recovery nudge (1st doom loop was detected this turn)
        if self._doom_recoveries == 1 and len(self._recent_calls) == 0:
            parts.append(DOOM_RECOVERY_PROMPT)
        # last turn warning (only when max_turns > 5 to avoid noise in short runs)
        remaining = self.max_turns - current_turn
        if self.max_turns > 5 and remaining <= 2 and remaining > 0:
            parts.append(LAST_TURN_WARNING.format(remaining=remaining))
        return "\n".join(parts) if parts else None

    # -- core loop --

    def run(self, user_input: str) -> RunStats:
        """Execute a single user request through the agent loop."""
        # Initialize submit tool state for this run (instance-level, thread-safe)
        from krim_sdk.tools.submit import SubmitTool
        for tool in self.tools:
            if isinstance(tool, SubmitTool):
                tool.reset(user_input)
                break

        self.messages.append({"role": "user", "content": user_input})
        self._recent_calls.clear()
        self._doom_recoveries = 0
        self._consecutive_no_tool_turns = 0
        self._last_response = None
        self._last_error = None
        stats = RunStats()

        # cache tool schemas (deterministic order for prompt cache)
        cached_schemas = self._all_tool_schemas()

        # wrap model.chat with retry, using event handler for retry notifications
        def on_retry(attempt: int, max_retries: int, error: Exception, delay: float):
            self._handler.on_retry(attempt, max_retries, error, delay)

        chat_with_retry = with_retry(self.model.chat, on_retry=on_retry)

        # stream callback
        def stream_cb(text: str):
            self._handler.on_stream(text)

        turn = 0
        while turn < self.max_turns:
            turn += 1
            stats.turns = turn

            self._handler.on_event(Event(
                type=EventType.TURN_START,
                data={"turn": turn, "max_turns": self.max_turns, "tokens": estimate_message_tokens(self.messages)}
            ))

            # check for compaction
            if needs_compaction(self.messages, max_tokens=self.token_limit):
                before = estimate_message_tokens(self.messages)
                self.messages = compact(self.messages, max_tokens=self.token_limit)
                after = estimate_message_tokens(self.messages)
                self._handler.on_compaction(before, after)
                stats.compactions += 1

            # call model with retry
            try:
                response = chat_with_retry(
                    messages=self.messages,
                    tools=cached_schemas,
                    stream_callback=stream_cb,
                )
            except Exception as e:
                self._record_model_error(e)
                break

            if response.text:
                # capture longest response (real answers are longer than meta-commentary)
                if self._last_response is None or len(response.text) > len(self._last_response):
                    self._last_response = response.text

            # no tool calls -> nudge to continue or use submit
            if not response.tool_calls:
                self._consecutive_no_tool_turns += 1

                if response.text:
                    self.messages.append({"role": "assistant", "content": response.text})

                # after 3 consecutive no-tool turns, give stronger warning
                if self._consecutive_no_tool_turns >= 3:
                    self.messages.append({"role": "user", "content": NUDGE_WARNING_PROMPT})
                else:
                    self.messages.append({"role": "user", "content": NUDGE_PROMPT})

                continue

            # doom loop detection with recovery
            if self._check_doom_loop(response.tool_calls):
                self._doom_recoveries += 1
                self._handler.on_event(Event(type=EventType.DOOM_LOOP, data={"recovery_count": self._doom_recoveries}))

                if self._doom_recoveries >= 2:
                    # 2nd doom loop: hard stop
                    self.messages.append({"role": "user", "content": MAX_STEPS_PROMPT})
                    try:
                        final = chat_with_retry(
                            messages=self.messages,
                            tools=[],  # no tools, force text response
                            stream_callback=stream_cb,
                        )
                        if final.text:
                            self._last_response = final.text
                            self.messages.append({"role": "assistant", "content": final.text})
                    except Exception as e:
                        self._record_model_error(e)
                    break
                else:
                    # 1st doom loop: warn but keep tools available
                    self._recent_calls.clear()  # reset so it gets a fresh chance

            # reset consecutive no-tool counter since we have tool calls
            self._consecutive_no_tool_turns = 0

            # check for submit tool first
            from krim_sdk.tools.submit import VERIFICATION_MARKER, SUBMIT_MARKER
            submitted = False
            submit_verification = False

            for tc in response.tool_calls:
                if tc.name == "submit":
                    # Execute submit tool to check if verification needed
                    result = self._execute_tool(tc.name, tc.args, turn)
                    stats.record_tool_call("submit")

                    if VERIFICATION_MARKER in result:
                        # First submit: verification required
                        submit_verification = True
                        if self.provider in ("claude", "vertex_ai"):
                            self.messages.append(_build_assistant_msg_claude(response))
                            self.messages.append({"role": "user", "content": [
                                {"type": "tool_result", "tool_use_id": tc.id, "content": result}
                            ]})
                        else:
                            self.messages.append(_build_assistant_msg_openai(response))
                            self.messages.append(_build_tool_result_openai(tc.id, tc.name, result))
                    else:
                        # Second submit: actually done - extract summary as final response
                        summary = result.replace(SUBMIT_MARKER, "", 1) if result.startswith(SUBMIT_MARKER) else result
                        self._last_response = summary
                        self._handler.on_submit(summary)
                        if self.provider in ("claude", "vertex_ai"):
                            self.messages.append(_build_assistant_msg_claude(response))
                            self.messages.append({"role": "user", "content": [
                                {"type": "tool_result", "tool_use_id": tc.id, "content": result}
                            ]})
                        else:
                            self.messages.append(_build_assistant_msg_openai(response))
                            self.messages.append(_build_tool_result_openai(tc.id, tc.name, result))
                        submitted = True
                    break

            if submitted:
                break

            if submit_verification:
                continue  # Skip normal tool processing, go to next turn

            # add assistant message with tool calls
            if self.provider in ("claude", "vertex_ai"):
                self.messages.append(_build_assistant_msg_claude(response))
            else:
                self.messages.append(_build_assistant_msg_openai(response))

            # execute each tool call
            tool_results = []
            for tc in response.tool_calls:
                result = self._execute_tool(tc.name, tc.args, turn)
                tool_results.append((tc, result))
                stats.record_tool_call(tc.name)

            # add tool results to messages
            if self.provider in ("claude", "vertex_ai"):
                content = []
                for tc, result in tool_results:
                    content.append({
                        "type": "tool_result",
                        "tool_use_id": tc.id,
                        "content": _build_tool_result_content_claude(result),
                    })
                # inject recovery/warning hints as text block in same message
                hint = self._build_turn_hint(turn)
                if hint:
                    content.append({"type": "text", "text": hint})
                self.messages.append({"role": "user", "content": content})
            else:
                for tc, result in tool_results:
                    self.messages.append(_build_tool_result_openai(tc.id, tc.name, result))
                # inject recovery/warning hints as separate user message
                hint = self._build_turn_hint(turn)
                if hint:
                    self.messages.append({"role": "user", "content": hint})

        else:
            # while-else: loop condition became false (not break) = all turns used with tool calls still pending
            self._handler.on_event(Event(type=EventType.MAX_TURNS, data={"max_turns": self.max_turns}))
            # inject max_steps prompt for graceful summary
            self.messages.append({"role": "user", "content": MAX_STEPS_PROMPT})
            try:
                final = chat_with_retry(
                    messages=self.messages,
                    tools=[],
                    stream_callback=stream_cb,
                )
                if final.text:
                    self._last_response = final.text
                    self.messages.append({"role": "assistant", "content": final.text})
            except Exception as e:
                self._record_model_error(e)

        self.last_stats = stats
        self.total_turns += stats.turns
        self.total_tool_calls += stats.tool_calls

        # save logs if log_dir specified
        self._save_logs(stats)

        return stats

    @property
    def last_response(self) -> str | None:
        """Get the last meaningful response from the agent."""
        return self._last_response

    @property
    def last_error(self) -> ModelError | None:
        """Get the last model error encountered during the run, if any."""
        return self._last_error

    def token_count(self) -> int:
        return estimate_message_tokens(self.messages)

    def force_compact(self) -> tuple[int, int]:
        """Manually trigger compaction. Returns (before, after) token counts."""
        before = estimate_message_tokens(self.messages)
        self.messages = compact(self.messages)
        after = estimate_message_tokens(self.messages)
        self._handler.on_compaction(before, after)
        return before, after

    def _save_logs(self, stats: RunStats):
        """Save conversation logs to log_dir (Terminus-compatible format)."""
        if not self.log_dir:
            return

        try:
            log_path = Path(self.log_dir)
            log_path.mkdir(parents=True, exist_ok=True)

            # prompt.txt - system prompt
            (log_path / "prompt.txt").write_text(self._system_prompt)

            # messages.json - full conversation history
            (log_path / "messages.json").write_text(
                json.dumps(self.messages, indent=2, ensure_ascii=False)
            )

            # meta.json - run metadata
            meta = {
                "provider": self.provider,
                "max_turns": self.max_turns,
                "turns": stats.turns,
                "tool_calls": stats.tool_calls,
                "tool_call_names": stats.tool_call_names,
                "compactions": stats.compactions,
                "tokens": estimate_message_tokens(self.messages),
            }
            (log_path / "meta.json").write_text(
                json.dumps(meta, indent=2, ensure_ascii=False)
            )

        except Exception:
            pass  # Silent fail for logging
