"""Submit tool for explicit task completion with verification."""

from __future__ import annotations

from krim_sdk.tools.base import Tool

# Unique marker to detect verification response
VERIFICATION_MARKER = "<<<VERIFICATION_REQUIRED>>>"
# Marker for final submission
SUBMIT_MARKER = "<<<SUBMITTED>>>"


class SubmitTool(Tool):
    name = "submit"
    description = (
        "Call this tool when you have completed the task. "
        "First call shows original task for review, second call completes. "
        "IMPORTANT: summary is your FINAL RESPONSE shown to the user. Put your actual answer, not meta-commentary."
    )
    parameters = {
        "summary": {
            "type": "string",
            "description": "Your final response to the user. This is what they will see.",
        },
    }

    def __init__(self):
        """Initialize submit tool with instance-level state."""
        self._original_instruction: str | None = None
        self._first_call: bool = True

    def reset(self, instruction: str) -> None:
        """Reset state for a new run. Called by Agent at start of each run()."""
        self._original_instruction = instruction
        self._first_call = True

    def run(self, summary: str) -> str:
        if self._first_call:
            self._first_call = False
            instruction = self._original_instruction or "(instruction not available)"
            return f"""{VERIFICATION_MARKER}

=== ORIGINAL TASK ===
{instruction}
=====================

Review above. If complete, call `submit` again with your final response. If not, fix first."""
        else:
            # Return marker + summary for agent.py to parse
            return f"{SUBMIT_MARKER}{summary}"
