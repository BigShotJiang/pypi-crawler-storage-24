"""Tools for KRIM SDK."""

from krim_sdk.tools.base import Tool
from krim_sdk.tools.bash import BashTool
from krim_sdk.tools.read import ReadTool
from krim_sdk.tools.write import WriteTool
from krim_sdk.tools.edit import EditTool
from krim_sdk.tools.grep import GrepTool
from krim_sdk.tools.glob import GlobTool
from krim_sdk.tools.submit import SubmitTool
from krim_sdk.tools.skill import SkillTool

__all__ = [
    "Tool",
    "BashTool",
    "ReadTool",
    "WriteTool",
    "EditTool",
    "GrepTool",
    "GlobTool",
    "SubmitTool",
    "SkillTool",
]


def default_tools() -> list[Tool]:
    """Create default tool set (without SkillTool - configure separately)."""
    return [
        BashTool(),
        ReadTool(),
        WriteTool(),
        EditTool(),
        GrepTool(),
        GlobTool(),
        SubmitTool(),
    ]


def default_tools_with_skills() -> tuple[list[Tool], SkillTool]:
    """Create default tools including SkillTool.

    Returns a tuple of (tools_list, skill_tool) so you can configure
    the skill_tool separately with skill_tool.configure(skills).
    """
    skill_tool = SkillTool()
    tools = [
        BashTool(),
        ReadTool(),
        WriteTool(),
        EditTool(),
        GrepTool(),
        GlobTool(),
        SubmitTool(),
        skill_tool,
    ]
    return tools, skill_tool
