"""
vizzpy CLI entry point.

Usage:
  vizzpy --serve [--host HOST] [--port PORT]
  vizzpy --headless <project_path> [--output output.svg]
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path


def cli() -> None:
    parser = argparse.ArgumentParser(
        prog="vizzpy",
        description="Python call tree visualizer",
    )
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--serve", action="store_true", help="Start the web server")
    mode.add_argument("--headless", metavar="PROJECT_PATH", help="Render SVG without a web server")

    parser.add_argument("--host", default="127.0.0.1", help="Host to bind (serve mode)")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind (serve mode)")
    parser.add_argument("--output", default="call_tree.svg", help="Output SVG path (headless mode)")

    args = parser.parse_args()

    if args.serve:
        _run_server(args.host, args.port)
    else:
        _run_headless(Path(args.headless), Path(args.output))


def _run_server(host: str, port: int) -> None:
    try:
        import uvicorn
    except ImportError:
        sys.exit("uvicorn is required for serve mode: pip install uvicorn[standard]")

    from vizzpy.server import app
    uvicorn.run(app, host=host, port=port)


def _run_headless(project_path: Path, output_path: Path) -> None:
    if not project_path.exists():
        sys.exit(f"Project path does not exist: {project_path}")

    from vizzpy.render import render_svg
    print(f"Analyzing {project_path} ...")
    render_svg(project_path, output_path)
    print(f"SVG written to {output_path}")


if __name__ == "__main__":
    cli()
