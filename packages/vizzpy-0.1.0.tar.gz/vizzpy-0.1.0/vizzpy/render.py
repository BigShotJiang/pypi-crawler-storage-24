"""
Headless SVG rendering via the graphviz Python package.

The graphviz package is a thin wrapper around the `dot` binary (Graphviz).
Install Graphviz system package first:
  macOS:  brew install graphviz
  Ubuntu: apt install graphviz
"""
from __future__ import annotations
from pathlib import Path

import graphviz  # type: ignore

from .graph import build_graph


def render_svg(project_root: Path, output_path: Path) -> None:
    """
    Analyze *project_root* and write the call graph as an SVG to *output_path*.
    """
    graph_data = build_graph(project_root)
    dot = _to_dot(graph_data)
    svg_source = dot.pipe(format="svg").decode("utf-8")
    output_path.write_text(svg_source, encoding="utf-8")


def _to_dot(graph_data: dict) -> graphviz.Digraph:
    dot = graphviz.Digraph(
        graph_attr={
            "rankdir": "LR",
            "fontname": "Helvetica",
            "splines": "ortho",
            "nodesep": "0.5",
            "ranksep": "1.0",
        },
        node_attr={
            "shape": "box",
            "style": "rounded,filled",
            "fillcolor": "#dbe9f4",
            "fontname": "Helvetica",
            "fontsize": "11",
        },
        edge_attr={
            "fontname": "Helvetica",
            "fontsize": "9",
        },
    )

    # Add module subgraphs (clusters)
    for module_name, node_ids in graph_data["modules"].items():
        with dot.subgraph(name=f"cluster_{module_name}") as sub:
            sub.attr(label=module_name, style="rounded", color="#aaaaaa", fontsize="10")
            for nid in node_ids:
                # Find label for this node
                label = nid  # fallback
                for n in graph_data["nodes"]:
                    if n["id"] == nid:
                        label = n["label"]
                        break
                sub.node(nid, label=label)

    # Add edges
    for edge in graph_data["edges"]:
        label = str(edge["count"]) if edge["count"] > 1 else ""
        dot.edge(edge["source"], edge["target"], label=label)

    return dot
