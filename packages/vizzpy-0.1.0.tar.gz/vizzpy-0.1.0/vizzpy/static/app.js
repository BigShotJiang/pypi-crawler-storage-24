"use strict";

// ── State ────────────────────────────────────────────────────────────────────
let graphData      = null;
let collapsedNodes = new Set();
let currentZoomK   = 1;          // tracks current zoom scale for drag compensation
let uploadMode     = null;       // "zip" | "folder" — set when user selects a source

// ── DOM refs ─────────────────────────────────────────────────────────────────
const fileInput    = document.getElementById("file-input");
const folderInput  = document.getElementById("folder-input");
const folderBtn    = document.getElementById("folder-btn");
const dropZone     = document.getElementById("drop-zone");
const analyzeBtn   = document.getElementById("analyze-btn");
const statusMsg    = document.getElementById("status-msg");
const uploadPanel  = document.getElementById("upload-panel");
const uploadSummary= document.getElementById("upload-summary");
const uploadToggle = document.getElementById("upload-toggle");
const graphPanel   = document.getElementById("graph-panel");
const fitBtn       = document.getElementById("fit-btn");
const darkToggle   = document.getElementById("dark-toggle");
const nodeCountEl  = document.getElementById("node-count");
const tooltip      = document.getElementById("tooltip");
const svgEl        = document.getElementById("graph-svg");
const svg          = d3.select("#graph-svg");
const inner        = d3.select("#graph-inner");

// ── Dark mode ─────────────────────────────────────────────────────────────────
(function initDark() {
  if (localStorage.getItem("vizpy-dark") === "1") {
    document.body.classList.add("dark");
    darkToggle.textContent = "Light";
  }
})();

darkToggle.addEventListener("click", () => {
  const isDark = document.body.classList.toggle("dark");
  darkToggle.textContent = isDark ? "Light" : "Dark";
  localStorage.setItem("vizpy-dark", isDark ? "1" : "0");
});

// ── File selection ────────────────────────────────────────────────────────────
fileInput.addEventListener("change", () => {
  if (fileInput.files.length) {
    const name = fileInput.files[0].name;
    statusMsg.textContent = `Selected: ${name}`;
    uploadSummary.textContent = name;
    analyzeBtn.disabled = false;
    uploadMode = "zip";
  }
});

dropZone.addEventListener("dragover", e => { e.preventDefault(); dropZone.classList.add("drag-over"); });
dropZone.addEventListener("dragleave", () => dropZone.classList.remove("drag-over"));
dropZone.addEventListener("drop", e => {
  e.preventDefault();
  dropZone.classList.remove("drag-over");
  const file = e.dataTransfer.files[0];
  if (file && file.name.endsWith(".zip")) {
    fileInput._droppedFile = file;
    statusMsg.textContent = `Selected: ${file.name}`;
    uploadSummary.textContent = file.name;
    analyzeBtn.disabled = false;
    uploadMode = "zip";
  } else {
    statusMsg.textContent = "Please drop a .zip file.";
  }
});

// ── Folder selection ─────────────────────────────────────────────────────────
folderBtn.addEventListener("click", () => folderInput.click());

folderInput.addEventListener("change", () => {
  if (folderInput.files.length) {
    const name = folderInput.files[0].webkitRelativePath.split("/")[0] || "folder";
    statusMsg.textContent = `Selected folder: ${name} (${folderInput.files.length} files)`;
    uploadSummary.textContent = name + "/";
    analyzeBtn.disabled = false;
    uploadMode = "folder";
  }
});

// ── Analyze ───────────────────────────────────────────────────────────────────
analyzeBtn.addEventListener("click", async () => {
  analyzeBtn.disabled = true;
  statusMsg.textContent = "Analyzing…";

  try {
    let res;
    if (uploadMode === "folder") {
      const form = new FormData();
      for (const f of folderInput.files) {
        form.append("files", f, f.webkitRelativePath);
      }
      res = await fetch("/api/analyze-folder", { method: "POST", body: form });
    } else {
      const file = fileInput._droppedFile || fileInput.files[0];
      if (!file) { analyzeBtn.disabled = false; return; }
      const form = new FormData();
      form.append("file", file);
      res = await fetch("/api/analyze", { method: "POST", body: form });
    }

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail || res.statusText);
    }
    graphData = await res.json();
    collapsedNodes.clear();
    showGraph();
  } catch (err) {
    statusMsg.textContent = `Error: ${err.message}`;
    analyzeBtn.disabled = false;
  }
});

// ── Upload panel toggle ───────────────────────────────────────────────────────
uploadToggle.addEventListener("click", () => {
  uploadPanel.classList.toggle("collapsed");
});

// ── Render ────────────────────────────────────────────────────────────────────
function showGraph() {
  graphPanel.hidden = false;
  uploadPanel.classList.add("collapsed");
  renderGraph();
}

function renderGraph() {
  inner.selectAll("*").remove();

  const g = buildDagreGraph();
  const render = new dagreD3.render();
  render(inner, g);

  attachNodeHandlers(g);

  nodeCountEl.textContent =
    `${graphData.nodes.length} nodes · ${graphData.edges.length} edges`;

  const zoomBg = document.getElementById("zoom-bg");
  zoomBg.setAttribute("width",  svgEl.clientWidth);
  zoomBg.setAttribute("height", svgEl.clientHeight);

  fitToScreen(g);
}

function buildDagreGraph() {
  const g = new dagreD3.graphlib.Graph({ compound: true, multigraph: false })
    .setGraph({ rankdir: "LR", nodesep: 40, ranksep: 80, marginx: 20, marginy: 20 })
    .setDefaultEdgeLabel(() => ({}));

  const hiddenNodes = computeHiddenNodes();

  for (const [moduleName] of Object.entries(graphData.modules)) {
    g.setNode(`__cluster__${moduleName}`, {
      label: moduleName,
      clusterLabelPos: "top",
      class: "cluster-node",
    });
  }

  for (const node of graphData.nodes) {
    if (hiddenNodes.has(node.id)) continue;
    g.setNode(node.id, {
      label: node.label,
      class: collapsedNodes.has(node.id) ? "collapsed" : "",
      rx: 6,
      ry: 6,
    });
    g.setParent(node.id, `__cluster__${node.module}`);
  }

  for (const edge of graphData.edges) {
    if (hiddenNodes.has(edge.source) || hiddenNodes.has(edge.target)) continue;
    g.setEdge(edge.source, edge.target, {
      label: edge.count > 1 ? String(edge.count) : "",
      curve: d3.curveBasis,
    });
  }

  return g;
}

function computeHiddenNodes() {
  const adj = new Map();
  for (const node of graphData.nodes) adj.set(node.id, []);
  for (const edge of graphData.edges) {
    if (adj.has(edge.source)) adj.get(edge.source).push(edge.target);
  }
  const hidden = new Set();
  for (const nid of collapsedNodes) {
    const queue = [...(adj.get(nid) || [])];
    while (queue.length) {
      const cur = queue.shift();
      if (hidden.has(cur) || collapsedNodes.has(cur)) continue;
      hidden.add(cur);
      queue.push(...(adj.get(cur) || []));
    }
  }
  return hidden;
}

// ── Interaction ───────────────────────────────────────────────────────────────
function attachNodeHandlers(g) {
  const docMap = new Map(graphData.nodes.map(n => [n.id, n.docstring]));

  // Build nodeId → [connected edge path elements] lookup for drag
  const connectedEdges = new Map();
  graphData.nodes.forEach(n => connectedEdges.set(n.id, []));
  // "path.path" is the visible edge line — avoids descending into <defs> marker paths
  inner.selectAll("g.edgePath").each(function(ek) {
    const pathEl = d3.select(this).select("path.path");
    if (connectedEdges.has(ek.v)) connectedEdges.get(ek.v).push({ pathEl, v: ek.v, w: ek.w });
    if (connectedEdges.has(ek.w)) connectedEdges.get(ek.w).push({ pathEl, v: ek.v, w: ek.w });
  });

  const drag = d3.drag()
    .on("start", function() {
      d3.event.sourceEvent.stopPropagation(); // prevent SVG pan
      d3.select(this).raise();               // bring node to front
    })
    .on("drag", function(nodeId) {
      const node = g.node(nodeId);
      node.x += d3.event.dx / currentZoomK;
      node.y += d3.event.dy / currentZoomK;
      d3.select(this).attr("transform", `translate(${node.x},${node.y})`);
      // Redraw connected edges, ending at node boundaries (not centers)
      (connectedEdges.get(nodeId) || []).forEach(({ pathEl, v, w }) => {
        const src = g.node(v);
        const tgt = g.node(w);
        if (src && tgt) pathEl.attr("d", cubicPath(src, tgt));
      });
      updateClusters(g);
    });

  inner.selectAll("g.node")
    .call(drag)
    .on("mouseover", function(nodeId) {
      const doc = docMap.get(nodeId);
      if (!doc) return;
      const firstLine = doc.split("\n").map(l => l.trim()).find(l => l.length > 0) || doc;
      tooltip.textContent = firstLine.length > 100 ? firstLine.slice(0, 97) + "…" : firstLine;
      tooltip.style.display = "block";
    })
    .on("mousemove", function() {
      const tw = tooltip.offsetWidth;
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      let x = d3.event.clientX + 14;
      let y = d3.event.clientY + 14;
      if (x + tw + 10 > vw) x = d3.event.clientX - tw - 8;
      if (y + 30    > vh)  y = d3.event.clientY - 30;
      tooltip.style.left = x + "px";
      tooltip.style.top  = y + "px";
    })
    .on("mouseout",  () => { tooltip.style.display = "none"; })
    .on("dblclick",  function(nodeId) {
      tooltip.style.display = "none";
      if (collapsedNodes.has(nodeId)) collapsedNodes.delete(nodeId);
      else                            collapsedNodes.add(nodeId);
      renderGraph();
    });
}

// Draw a cubic bezier edge between two node objects, connecting at their boundaries.
// ARROW_PAD: marker refX=9, tip at x=10, strokeWidth=1.5 → tip overshoots endpoint by
// (10-9)*1.5 = 1.5px.  Back the endpoint up by 2px so the tip lands at the node edge.
const ARROW_PAD = 2;
function cubicPath(srcNode, tgtNode) {
  // LR layout: exit from right edge of source, enter left edge of target
  const x1 = srcNode.x + (srcNode.width  || 0) / 2;
  const y1 = srcNode.y;
  const x2 = tgtNode.x - (tgtNode.width  || 0) / 2 - ARROW_PAD;
  const y2 = tgtNode.y;
  // If target has been dragged behind source, fall back to center-to-center
  if (x2 <= x1) {
    const cx = (srcNode.x + tgtNode.x) / 2;
    return `M${x1},${y1} C${cx},${y1} ${cx},${y2} ${tgtNode.x + (tgtNode.width || 0) / 2 - ARROW_PAD},${y2}`;
  }
  const cx = (x1 + x2) / 2;
  return `M${x1},${y1} C${cx},${y1} ${cx},${y2} ${x2},${y2}`;
}

// Recalculate each cluster rect to tightly wrap its current child node positions.
function updateClusters(g) {
  const PAD      = 20;  // padding around child nodes
  const TOP_PAD  = 28;  // extra room at top for the cluster label

  inner.selectAll("g.cluster").each(function(clusterId) {
    const childIds = (g.children(clusterId) || []).filter(id => g.node(id));
    if (childIds.length === 0) return;

    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const nid of childIds) {
      const n  = g.node(nid);
      const hw = (n.width  || 50) / 2;
      const hh = (n.height || 20) / 2;
      minX = Math.min(minX, n.x - hw);
      minY = Math.min(minY, n.y - hh);
      maxX = Math.max(maxX, n.x + hw);
      maxY = Math.max(maxY, n.y + hh);
    }
    if (!isFinite(minX)) return;

    const w  = maxX - minX + PAD * 2;
    const h  = maxY - minY + PAD + TOP_PAD;
    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2 + (TOP_PAD - PAD) / 2;

    d3.select(this).attr("transform", `translate(${cx},${cy})`);
    const clusterSel = d3.select(this);
    const rectSel    = clusterSel.select("rect");
    const labelSel   = clusterSel.select("g.label");

    // Read current label offset relative to rect top before we change anything,
    // so we preserve dagre-d3's initial interior padding on subsequent resizes.
    const curH = +rectSel.attr("height") || h;
    const curLabelTransform = labelSel.attr("transform") || "translate(0,0)";
    const yMatch = curLabelTransform.match(/translate\s*\([^,]+,\s*([^)]+)\)/);
    const curLabelY = yMatch ? +yMatch[1] : 0;
    const labelOffsetFromTop = curLabelY + curH / 2;  // positive = inside rect

    rectSel
      .attr("x", -w / 2)
      .attr("y", -h / 2)
      .attr("width",  w)
      .attr("height", h);
    labelSel.attr("transform", `translate(0, ${-h / 2 + labelOffsetFromTop})`);
  });
}

// ── Zoom & fit ────────────────────────────────────────────────────────────────
const zoom = d3.zoom()
  .on("start", () => svgEl.classList.add("panning"))
  .on("zoom",  () => {
    inner.attr("transform", d3.event.transform);
    currentZoomK = d3.event.transform.k;
  })
  .on("end",   () => svgEl.classList.remove("panning"));
svg.call(zoom);

function fitToScreen(g) {
  const W = svgEl.clientWidth;
  const H = svgEl.clientHeight;
  if (!g.graph().width || !g.graph().height) return;
  const scale = Math.min(W / (g.graph().width + 40), H / (g.graph().height + 40), 1);
  const tx = (W - g.graph().width  * scale) / 2;
  const ty = (H - g.graph().height * scale) / 2;
  svg.call(zoom.transform, d3.zoomIdentity.translate(tx, ty).scale(scale));
}

fitBtn.addEventListener("click", () => {
  if (graphData) {
    const g = buildDagreGraph();
    fitToScreen(g);
  }
});
