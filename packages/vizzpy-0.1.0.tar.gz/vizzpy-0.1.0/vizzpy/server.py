"""
FastAPI application.

Routes:
  GET  /              → serves static/index.html
  POST /api/analyze   → accepts a zip upload, returns graph JSON
  GET  /static/*      → static assets (JS, CSS, vendor libs)
"""
from __future__ import annotations
import logging
import shutil
import tempfile
import zipfile
from pathlib import Path

from typing import List

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .graph import build_graph

logger = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).parent / "static"

app = FastAPI(title="VizPy")

# Serve static assets under /static
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/")
async def index():
    return FileResponse(str(STATIC_DIR / "index.html"))


@app.post("/api/analyze")
async def analyze(file: UploadFile = File(...)):
    """
    Accept a .zip archive of a Python project and return the call graph as JSON.
    """
    if not file.filename or not file.filename.endswith(".zip"):
        raise HTTPException(status_code=400, detail="Upload must be a .zip file")

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        zip_path = tmp_path / "upload.zip"

        # Save upload to disk
        content = await file.read()
        zip_path.write_bytes(content)

        # Extract
        try:
            with zipfile.ZipFile(zip_path) as zf:
                zf.extractall(tmp_path / "project")
        except zipfile.BadZipFile:
            raise HTTPException(status_code=400, detail="Invalid zip file")

        project_root = _find_project_root(tmp_path / "project")

        try:
            graph = build_graph(project_root)
        except Exception as exc:
            logger.exception("Error analyzing project")
            raise HTTPException(status_code=500, detail=str(exc))

    return JSONResponse(content=graph)


@app.post("/api/analyze-folder")
async def analyze_folder(files: List[UploadFile] = File(...)):
    """
    Accept a flat list of files with webkitRelativePath as their filenames.
    Reconstruct the directory tree in a temp dir, then analyze.
    """
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)

        for upload in files:
            # filename is the webkitRelativePath, e.g. "myproject/pkg/module.py"
            rel = Path(upload.filename or "file")
            # Strip any leading slashes / ".." components to prevent path traversal
            rel = Path(*[p for p in rel.parts if p not in ("", "..", ".")] or ["file"])
            dest = tmp_path / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(await upload.read())

        project_root = _find_project_root(tmp_path)

        try:
            graph = build_graph(project_root)
        except Exception as exc:
            logger.exception("Error analyzing project")
            raise HTTPException(status_code=500, detail=str(exc))

    return JSONResponse(content=graph)


def _find_project_root(extracted: Path) -> Path:
    """
    If the zip contained a single top-level directory, use that as the root
    so that module names are computed from the actual package, not the zip wrapper.
    """
    children = [c for c in extracted.iterdir() if not c.name.startswith(".")]
    if len(children) == 1 and children[0].is_dir():
        return children[0]
    return extracted
