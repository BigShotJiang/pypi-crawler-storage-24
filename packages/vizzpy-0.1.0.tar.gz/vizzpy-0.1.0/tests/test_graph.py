"""Tests for graph.py: build_graph, _fallback_label, _fallback_module."""
import pytest
from pathlib import Path

from vizzpy.graph import build_graph, _fallback_label, _fallback_module


# ── _fallback_label / _fallback_module ───────────────────────────────────────

def test_fallback_label_simple():
    assert _fallback_label("pkg.utils.helper") == "helper"

def test_fallback_label_no_dot():
    assert _fallback_label("main") == "main"

def test_fallback_module_with_dot():
    assert _fallback_module("pkg.utils.helper") == "pkg.utils"

def test_fallback_module_no_dot():
    assert _fallback_module("main") == "main"


# ── build_graph ───────────────────────────────────────────────────────────────

def test_build_graph_basic(tmp_path):
    (tmp_path / "foo.py").write_text("def a(): pass\ndef b():\n    a()")
    g = build_graph(tmp_path)
    node_ids = {n["id"] for n in g["nodes"]}
    assert "foo.a" in node_ids
    assert "foo.b" in node_ids
    assert any(e["source"] == "foo.b" and e["target"] == "foo.a" for e in g["edges"])


def test_build_graph_edge_count(tmp_path):
    # Two calls to the same callee → count == 2
    (tmp_path / "m.py").write_text("def a(): pass\ndef b():\n    a()\n    a()")
    g = build_graph(tmp_path)
    edge = next(e for e in g["edges"] if e["source"] == "m.b" and e["target"] == "m.a")
    assert edge["count"] == 2


def test_build_graph_modules_grouping(tmp_path):
    (tmp_path / "pkg").mkdir()
    (tmp_path / "pkg" / "utils.py").write_text("def helper(): pass\ndef run():\n    helper()")
    g = build_graph(tmp_path)
    assert "pkg.utils" in g["modules"]
    assert "pkg.utils.helper" in g["modules"]["pkg.utils"]


def test_build_graph_node_label_and_module(tmp_path):
    (tmp_path / "svc.py").write_text("def process(): pass\ndef main():\n    process()")
    g = build_graph(tmp_path)
    node = next(n for n in g["nodes"] if n["id"] == "svc.process")
    assert node["label"] == "process"
    assert node["module"] == "svc"


def test_build_graph_cross_module(tmp_path):
    (tmp_path / "a.py").write_text("def helper(): pass")
    (tmp_path / "b.py").write_text("from a import helper\ndef caller():\n    helper()")
    g = build_graph(tmp_path)
    assert any(e["source"] == "b.caller" and e["target"] == "a.helper" for e in g["edges"])


def test_build_graph_fallback_node_for_unknown_callee(tmp_path):
    # Callee comes from an external package — still shows up as a node if referenced
    # within-project edges only (external callee won't appear unless it's in all_names)
    # This test just verifies build_graph doesn't crash on an empty project.
    g = build_graph(tmp_path)
    assert g["nodes"] == []
    assert g["edges"] == []
    assert g["modules"] == {}


def test_build_graph_node_docstring(tmp_path):
    (tmp_path / "m.py").write_text(
        'def a():\n    """Does something."""\n    pass\ndef b():\n    a()'
    )
    g = build_graph(tmp_path)
    node = next(n for n in g["nodes"] if n["id"] == "m.a")
    assert node["docstring"] == "Does something."
