# VizPy

Interactive Python call tree visualizer. Upload a Python project and explore its function call graph in the browser.

## Features

- **Interactive web UI** — zoom, pan, drag nodes, collapse subtrees
- **Cross-module resolution** — follows imports across files to draw edges between modules
- **Dark mode** — toggle with one click
- **Headless mode** — render a static SVG from the command line (requires Graphviz)
- **Folder or zip upload** — drag-and-drop a `.zip` or browse for a local folder

## Installation

```bash
pip install vizzpy
```

Headless SVG rendering additionally requires the [Graphviz](https://graphviz.org/download/) system package:

```bash
# macOS
brew install graphviz

# Debian/Ubuntu
apt install graphviz
```

## Usage

### Web UI (recommended)

```bash
vizzpy --serve
# open http://127.0.0.1:8000
```

Upload a `.zip` of your Python project or select a local folder, then click **Analyze**.

- **Scroll / pinch** to zoom
- **Drag background** to pan
- **Drag nodes** to rearrange
- **Double-click a node** to collapse/expand its call subtree
- **Hover** a node to see its docstring

### Headless SVG

```bash
vizzpy --headless ./myproject --output call_tree.svg
```

### Options

```
vizzpy --serve   [--host HOST] [--port PORT]
vizzpy --headless PROJECT_PATH [--output OUTPUT.svg]
```

## How it works

VizPy uses Python's `ast` module to do a two-pass analysis of your source files:

1. **Scope pass** — collects every top-level function and class method with its qualified name (`module.ClassName.method`)
2. **Edge pass** — walks each file again, resolves `self.method()`, `cls.method()`, imported names, and direct calls to project-internal functions

Results are rendered in the browser with [dagre-d3](https://github.com/dagrejs/dagre-d3) (vendored, works offline). Calls to stdlib or third-party libraries are silently excluded.

## Development

```bash
git clone https://github.com/atulsaurav/vizzpy
cd vizzpy
pip install -e ".[dev]"

# run tests
pytest

# run with coverage
pytest --cov=vizzpy --cov-report=term-missing
```

## License

MIT
