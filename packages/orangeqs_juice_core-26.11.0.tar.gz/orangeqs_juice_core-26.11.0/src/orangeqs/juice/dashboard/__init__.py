"""Implements the dashboard for the Juice application."""

import logging

import panel as pn
import tornado

from orangeqs.juice.dashboard.dashboard_server import Dashboard
from orangeqs.juice.dashboard.utils import (
    JuiceEnvironment,
    collect_dashboard_applications,
)

from ._logging import setup_logging

_logger = logging.getLogger(__name__)

juice_environment = JuiceEnvironment()


def main() -> None:
    """Define entry point for the dashboard server."""
    setup_logging()

    # Globally define which JavaScript libraries Panel should load.
    pn.extension("echarts", "tabulator")

    _logger.info("Collecting dashboard applications")
    applications, bokeh_apps = collect_dashboard_applications()
    _logger.info(
        f"Tornado applications - {applications}/nBokeh applications - {bokeh_apps}"
    )

    _logger.info("Creating Dashboard")
    dashboard = Dashboard(applications=applications, bokeh_apps=bokeh_apps)
    dashboard.start()

    tornado.ioloop.IOLoop.current().start()
