"""Reverse proxy for the InfluxDB2 UI.

This proxy is responsible for:
- Rewriting URLs and cookies in the response body to include the JupyterHub prefix.
    The InfluxDB2 UI does not support being served under a subpath.
- Serving a `/auto-login` endpoint that automatically logs the user in.
    The InfluxDB2 UI does not support auto-login.

This proxy is built on top of the the `proxy.py` package. To run this proxy, use the
following command. This command for the `/influxdb2` proxy in the jupyter-server-proxy
configuration.

```bash
proxy \
    --enable-reverse-proxy \
    --plugins orangeqs.juice.dashboard._influxdb2_proxy.InfluxReverseProxyPlugin \
    --port 8086
```
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from urllib.parse import urlsplit

import tornado
from proxy.common.utils import build_http_response
from proxy.http import Url
from proxy.http.exception import HttpProtocolException
from proxy.http.parser import HttpParser, httpParserTypes
from proxy.http.server import ReverseProxyBasePlugin
from proxy.http.server.reverse import ReverseProxy

from orangeqs.juice.dashboard.utils import influxdb2_base_url
from orangeqs.juice.orchestration.influxdb2 import (
    READONLY_USER_PASSWORD,
    READONLY_USER_USERNAME,
)
from orangeqs.juice.orchestration.settings import OrchestrationSettings

if TYPE_CHECKING:
    import re

    from proxy.core.connection import TcpServerConnection


PREFIX = influxdb2_base_url().encode()

CONTENT_TYPES_TO_FILTER: tuple[str, ...] = (
    "text/css",
    "text/javascript",
    "application/javascript",
    "application/json",
    "text/html",
)

_settings = OrchestrationSettings.load()
_upstream_url = urlsplit(_settings.influxdb2.url)
UPSTREAM_HOST = _upstream_url.hostname or "host.docker.internal"
UPSTREAM_PORT = _upstream_url.port or 8086


class InfluxReverseProxyPlugin(ReverseProxyBasePlugin):
    """
    Proxy plugin to handle prefixing for InfluxDB2 UI when served under a subpath.

    Has the following responsibilities:
    - Serve /env.js
    - Serve /auto-login
    - Forward to upstream host/port from env vars
    """

    def routes(self) -> list[str | tuple[str, list[bytes]]]:
        return [
            r"^.*$",
        ]

    def before_routing(self, request: HttpParser) -> HttpParser | None:
        """Set the accept encoding header to none to avoid compression."""
        request.add_header(b"Accept-Encoding", b"identity")
        return request

    def handle_route(
        self,
        request: HttpParser,
        pattern: re.Pattern[Any],
    ) -> memoryview | Url | TcpServerConnection:
        assert request.path
        path = Url.from_bytes(request.path)
        print(f"Received request with path: {path}")
        if path.remainder == b"/env.js":
            return self._build_env_js()
        if path.remainder == b"/auto-login":
            return self._build_auto_login(request)

        return Url(
            scheme=b"http",
            hostname=UPSTREAM_HOST.encode(),
            port=UPSTREAM_PORT,
            remainder=request.path,
        )

    def _build_env_js(self) -> memoryview:
        body_str = (
            f"var prefix='{PREFIX.decode()}/'; "
            "process = {'env' : {'STATIC_PREFIX':prefix,"
            "'API_PREFIX':prefix, "
            "'BASE_PATH': prefix, "
            "'API_BASE_PATH':prefix}};"
        )
        body = body_str.encode()
        headers = {
            b"Content-Type": b"application/javascript",
            b"Content-Length": str(len(body)).encode(),
        }
        resp = build_http_response(
            200,
            reason=b"OK",
            headers=headers,
            body=body,
        )
        return memoryview(resp)

    def _build_auto_login(self, request: HttpParser) -> memoryview:
        """Login to the InfluxDB UI and redirect to the UI with the correct cookie set.

        1. Send a login request to the InfluxDB API.
        2. Extract the Set-Cookie header from the response.
        3. Return a redirect response to the UI with the login Set-Cookie header.
        """
        import base64
        import threading

        credentials = f"{READONLY_USER_USERNAME}:{READONLY_USER_PASSWORD}"
        basic_auth = "Basic " + base64.b64encode(credentials.encode()).decode()
        headers = {
            "Authorization": basic_auth,
        }
        login_url = f"http://{UPSTREAM_HOST}:{UPSTREAM_PORT}/api/v2/signin"

        # Pass existing cookies
        if request.has_header(b"Cookie"):
            headers["Cookie"] = request.header(b"Cookie").decode()

        result_container: dict[str, Any] = {}

        def run_fetch() -> None:
            """Run the fetch in a separate thread.

            The blocking HTTP client will attempt to start a new event loop,
            which is not possible in the main thread.
            """
            client = tornado.httpclient.HTTPClient()
            try:
                response = client.fetch(
                    tornado.httpclient.HTTPRequest(
                        url=login_url,
                        method="POST",
                        headers=headers,
                        body="",  # No body needed for InfluxDB login
                    )
                )
                result_container["response"] = response
            except Exception as e:
                result_container["response"] = e
            finally:
                client.close()

        thread = threading.Thread(target=run_fetch)
        thread.start()
        thread.join(timeout=10)
        response = result_container.get("response")
        if response is None:
            raise HttpProtocolException("Auto-login request timed out")

        if not isinstance(response, tornado.httpclient.HTTPResponse) or response.error:
            raise HttpProtocolException(f"Auto-login request failed: {response}")

        if response.error:
            raise HttpProtocolException(
                f"Auto-login request failed: {response.error}"
            ) from response.error

        if (new_cookie := response.headers.get("Set-Cookie")) is None:
            raise HttpProtocolException(  # pragma: no cover
                "No Set-Cookie header in login response from upstream server"
            )

        new_cookie = new_cookie.replace("Path=/api", f"Path={PREFIX.decode()}/api")

        response_headers = {
            b"Set-Cookie": new_cookie.encode(),
            b"Location": PREFIX,
        }

        return memoryview(
            build_http_response(
                status_code=302,
                reason=b"Found",
                headers=response_headers,
            )
        )


def handle_upstream_data(self: ReverseProxy, raw: memoryview) -> None:
    """Replace URLs in response body and cookies to include the Jupyterhub prefix."""
    if not hasattr(self, "_response") or getattr(self, "_response") is None:
        # First chunk of response, create a new parser
        response = HttpParser(httpParserTypes.RESPONSE_PARSER)
        self._response = response  # pyright: ignore[reportAttributeAccessIssue]
    else:
        response = getattr(self, "_response")
        assert isinstance(response, HttpParser)

    response.parse(raw)

    if not response.is_complete:
        # Waiting for more data
        return

    # Update the path of the cookie
    try:
        cookie = response.header(b"Set-Cookie")
    except KeyError:
        pass
    else:
        updated_cookie = cookie.decode().replace(
            "Path=/api", f"Path={PREFIX.decode()}/api"
        )
        response.add_header(b"Set-Cookie", updated_cookie.encode())

    try:
        content_type = response.header(b"Content-Type").decode().split(";")[0]
    except KeyError:
        content_type = ""

    # Update all URLs in the body to include the prefix
    if content_type in CONTENT_TYPES_TO_FILTER and response.body:
        body = response.body
        for old, new in (
            (b'src="/', b'src="' + PREFIX + b"/"),
            (b'href="/', b'href="' + PREFIX + b"/"),
            (b'data-basepath="', b'data-basepath="' + PREFIX + b"/"),
            (b'n.p="/"', b'n.p="' + PREFIX + b'/"'),
            (b'o.p="/"', b'o.p="' + PREFIX + b'/"'),
            (b"/api/", PREFIX + b"/api/"),
            (b"api/v2/query", PREFIX[1:] + b"/api/v2/query"),
            (b"/health`", PREFIX + b"/health`"),
            (b"</head>", b'<script src="' + PREFIX + b'/env.js"></script></head>'),
        ):
            body = body.replace(old, new)

        if response.is_chunked_encoded:
            # There is a bug in `update_body` that wrongly applies chunked encoding to
            # the body. This is not required as chunked encoding will be already applied
            # when building the response. As a work-around we set the body directly.
            response.body = body
        else:
            response.update_body(body, response.header(b"Content-Type"))

    data = response.build_response()
    self.client.queue(memoryview(data))


# Patch the ReverseProxy class to use our custom upstream data handler
# Doing this using a plugin is not yet supported.
ReverseProxy.handle_upstream_data = handle_upstream_data
