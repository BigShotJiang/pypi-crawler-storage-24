> **Navigation**: [Home](../INDEX.md) > Guides > Migrating to v0.4.0 Node Architecture

# Migrating to v0.4.0 Node Architecture

**Version**: 0.4.0
**Last Updated**: 2025-12-06
**Correlation ID**: `dec-migration-guide-001`

> **BREAKING CHANGE (v0.4.0)**: Legacy node implementations have been **REMOVED**. `NodeReducer` and `NodeOrchestrator` are now the only implementations, using declarative YAML contracts. There is no deprecation period - direct migration is required.

## Table of Contents

1. [Overview](#overview)
2. [Why Migrate?](#why-migrate)
3. [Migration Path](#migration-path)
4. [Reducer Nodes Migration](#reducer-nodes-migration)
5. [Orchestrator Nodes Migration](#orchestrator-nodes-migration)
6. [Testing Your Migration](#testing-your-migration)
7. [Troubleshooting](#troubleshooting)
8. [Complete Examples](#complete-examples)
9. [Import Path Changes Summary](#import-path-changes-summary)
10. [Additional Resources](#additional-resources)

---

## Overview

This guide shows how to migrate from code-based reducer and orchestrator patterns to the v0.4.0 declarative YAML-driven nodes. Legacy implementations have been removed - this migration is required for any code using the old patterns.

The declarative approach enables:

- **Zero Custom Code**: All logic defined in YAML contracts
- **Type Safety**: Complete Pydantic validation
- **Maintainability**: Changes don't require code redeployment
- **Testability**: YAML contracts are unit-testable
- **Consistency**: Standardized patterns across all nodes

### Implementation Status

**Production-Ready** (omnibase_core v0.4.0)

| Component | Status | Details |
|-----------|--------|---------|
| **FSM Models** | Complete | ModelFSMSubcontract with full state machine support |
| **Workflow Models** | Complete | ModelWorkflowDefinition with dependency resolution |
| **FSM Runtime** | Complete | util_fsm_executor.py + MixinFSMExecution |
| **Workflow Runtime** | Complete | util_workflow_executor.py + MixinWorkflowExecution |
| **Node Base Classes** | Complete | `NodeReducer` (FSM-driven), `NodeOrchestrator` (workflow-driven) |
| **Legacy Code** | Removed | No legacy implementations available |

All code examples in this guide are functional and tested.

### What Changes?

| Aspect | Before (Code-Based) | After (Declarative) |
|--------|-------------------|-------------------|
| **Logic Location** | Python code | YAML contract |
| **State Management** | Custom Python methods | FSM subcontract (reducers) |
| **Workflow Coordination** | Custom Python methods | Workflow definition (orchestrators) |
| **Testing** | Unit tests for Python code | Unit tests verify YAML behavior |
| **Deployment** | Code changes require redeployment | YAML changes hot-reload |

---

## Why Migrate?

### Benefits for Reducer Nodes

1. **Declarative State Machines**: FSM defined in YAML, not Python
2. **Intent Emission**: Pure FSM pattern - all side effects via intents
3. **State Persistence**: Automatic crash recovery
4. **Condition Evaluation**: Expression-based transitions
5. **Wildcard Transitions**: Global error handling

### Benefits for Orchestrator Nodes

1. **Workflow Definition**: Multi-step workflows in YAML
2. **Action Emission**: Deferred execution via actions
3. **Dependency Resolution**: Automatic topological ordering
4. **Parallel Execution**: Wave-based parallel coordination
5. **Cycle Detection**: Automatic dependency cycle detection

---

## Migration Path

### Step 1: Identify Node Type

**Reducer Node** - Manages state and aggregates data:
```python
class NodeMyReducer(NodeReducer):
    async def process(self, input_data):
        # Custom state management code
        pass
```

**Orchestrator Node** - Coordinates multi-step workflows:
```python
class NodeMyOrchestrator(NodeOrchestrator):
    async def process(self, input_data):
        # Custom workflow coordination code
        pass
```

### Step 2: Analyze Current Implementation

Document your current logic:
- **Reducer**: What states exist? What triggers transitions?
- **Orchestrator**: What steps exist? What are the dependencies?

### Step 3: Create YAML Contract

Convert your logic to YAML using the appropriate pattern:
- **Reducer**: FSM subcontract
- **Orchestrator**: Workflow definition

### Step 4: Update Node Class

Replace custom implementation with the new base class:
- **Reducer**: Inherit from `NodeReducer` (from `omnibase_core.nodes`)
- **Orchestrator**: Inherit from `NodeOrchestrator` (from `omnibase_core.nodes`)

These are the only implementations available in v0.4.0. All nodes use declarative YAML contracts.

### Step 5: Test & Validate

Verify behavior matches original implementation.

---

## Reducer Nodes Migration

### Example: Metrics Aggregation Reducer

#### Before (Code-Based)

```python
from omnibase_core.nodes import NodeReducer, ModelReducerInput, ModelReducerOutput

class NodeMetricsAggregator(NodeReducer):
    """Aggregates metrics with custom state management."""

    def __init__(self, container):
        super().__init__(container)
        self.current_state = "idle"
        self.collected_metrics = []
        self.validation_errors = []

    async def process(self, input_data: ModelReducerInput) -> ModelReducerOutput:
        """Custom state management logic."""

        # State: idle → collecting
        if self.current_state == "idle" and input_data.metadata.get("trigger") == "collect":
            if len(input_data.metadata.get("data_sources", [])) < 1:
                raise ValueError("No data sources configured")

            self.current_state = "collecting"
            self.collected_metrics = []
            await self._start_collection()

        # State: collecting → validating
        elif self.current_state == "collecting" and input_data.metadata.get("trigger") == "validate":
            if len(self.collected_metrics) < 10:
                raise ValueError("Insufficient metrics collected")

            self.current_state = "validating"
            await self._validate_metrics()

        # State: validating → aggregating
        elif self.current_state == "validating" and input_data.metadata.get("trigger") == "aggregate":
            if self.validation_errors:
                # Retry collection
                self.current_state = "collecting"
                self.collected_metrics = []
                await self._retry_collection()
            else:
                self.current_state = "aggregating"
                result = await self._aggregate_metrics()

        # State: aggregating → completed
        elif self.current_state == "aggregating" and input_data.metadata.get("trigger") == "complete":
            self.current_state = "completed"
            await self._persist_results()
            await self._emit_metrics()

        return ModelReducerOutput(
            result=self.collected_metrics,
            metadata={"state": self.current_state}
        )

    async def _start_collection(self):
        """Start metric collection - side effect."""
        print("Starting collection...")

    async def _validate_metrics(self):
        """Validate collected metrics."""
        self.validation_errors = []

    async def _aggregate_metrics(self):
        """Aggregate metrics."""
        return {"sum": sum(self.collected_metrics)}

    async def _persist_results(self):
        """Persist results - side effect."""
        print("Persisting results...")

    async def _emit_metrics(self):
        """Emit metrics - side effect."""
        print("Emitting metrics...")
```

**Problems with this approach:**
- ❌ State management scattered across methods
- ❌ Side effects (print statements) not testable
- ❌ Transition logic mixed with business logic
- ❌ No crash recovery (state lost on restart)
- ❌ Hard to visualize state machine
- ❌ Changes require code redeployment

#### After (Declarative)

**Node Implementation (99% reduction in code):**

```python
from omnibase_core.nodes import NodeReducer

class NodeMetricsAggregator(NodeReducer):
    """Aggregates metrics using FSM - all logic driven by YAML contract."""
    pass  # All logic driven by YAML contract

# NodeReducer is FSM-driven. All node classes are exported from omnibase_core.nodes.
```

**YAML Contract (`contracts/metrics_aggregator.yaml`):**

```yaml
state_transitions:
  state_machine_name: metrics_aggregation_fsm
  initial_state: idle

  states:
    - state_name: idle
      entry_actions: []
      exit_actions: []

    - state_name: collecting
      entry_actions:
        - "start_collection_timer"
        - "initialize_metric_buffers"
      exit_actions:
        - "flush_metric_buffers"

    - state_name: validating
      entry_actions:
        - "start_validation"
      exit_actions:
        - "log_validation_results"

    - state_name: aggregating
      entry_actions:
        - "begin_aggregation"
      exit_actions:
        - "finalize_aggregation"

    - state_name: completed
      is_terminal: true
      entry_actions:
        - "emit_completion_event"

    - state_name: failed
      is_terminal: true
      entry_actions:
        - "emit_failure_event"

  transitions:
    - from_state: idle
      to_state: collecting
      trigger: collect_metrics
      conditions:
        - expression: "data_sources min_length 1"
          required: true
      actions:
        - action_name: "emit_collection_started"
          action_type: "event"

    - from_state: collecting
      to_state: validating
      trigger: collection_complete
      conditions:
        - expression: "collected_metrics min_length 10"
          required: true

    - from_state: validating
      to_state: aggregating
      trigger: validation_success

    - from_state: validating
      to_state: collecting
      trigger: validation_failed
      conditions:
        - expression: "retry_count less_than 3"
          required: true

    - from_state: aggregating
      to_state: completed
      trigger: aggregation_success
      actions:
        - action_name: "persist_final_results"
          action_type: "persistence"
          is_critical: true

    - from_state: "*"
      to_state: failed
      trigger: error_occurred

  terminal_states:
    - completed
    - failed

  persistence_enabled: true
```

**Benefits:**
- ✅ State machine clearly defined in YAML
- ✅ All side effects via intents (testable)
- ✅ Transitions with conditions explicit
- ✅ State persistence for crash recovery
- ✅ Easy to visualize and understand
- ✅ Changes don't require code redeployment

---

## Orchestrator Nodes Migration

### Example: Data Processing Pipeline

#### Before (Code-Based)

```python
from omnibase_core.nodes import NodeOrchestrator, ModelOrchestratorInput, ModelOrchestratorOutput

class NodeDataPipeline(NodeOrchestrator):
    """Orchestrates data processing pipeline with custom coordination."""

    async def process(self, input_data: ModelOrchestratorInput) -> ModelOrchestratorOutput:
        """Custom workflow coordination logic."""

        completed_steps = []
        actions = []

        # Step 1: Fetch data (sequential)
        fetch_action = await self._create_fetch_action(input_data)
        actions.append(fetch_action)
        await self._wait_for_completion(fetch_action)
        completed_steps.append("fetch")

        # Step 2: Parallel validation and enrichment
        validate_action = await self._create_validate_action(input_data)
        enrich_action = await self._create_enrich_action(input_data)
        actions.extend([validate_action, enrich_action])

        # Wait for both parallel steps
        await asyncio.gather(
            self._wait_for_completion(validate_action),
            self._wait_for_completion(enrich_action)
        )
        completed_steps.extend(["validate", "enrich"])

        # Step 3: Aggregate (depends on validate + enrich)
        aggregate_action = await self._create_aggregate_action(input_data)
        actions.append(aggregate_action)
        await self._wait_for_completion(aggregate_action)
        completed_steps.append("aggregate")

        # Step 4: Quality check
        quality_action = await self._create_quality_action(input_data)
        actions.append(quality_action)
        await self._wait_for_completion(quality_action)
        completed_steps.append("quality")

        # Step 5: Parallel persist and notify
        persist_action = await self._create_persist_action(input_data)
        notify_action = await self._create_notify_action(input_data)
        actions.extend([persist_action, notify_action])

        await asyncio.gather(
            self._wait_for_completion(persist_action),
            self._wait_for_completion(notify_action)
        )
        completed_steps.extend(["persist", "notify"])

        return ModelOrchestratorOutput(
            execution_status="completed",
            completed_steps=completed_steps,
            actions_emitted=actions
        )

    async def _create_fetch_action(self, input_data):
        """Create fetch action."""
        return ModelAction(...)

    # ... many more helper methods ...
```

**Problems with this approach:**
- ❌ Dependencies hardcoded in Python
- ❌ Parallel execution manually coordinated
- ❌ No cycle detection
- ❌ Changes require code redeployment
- ❌ Hard to visualize workflow graph
- ❌ Error handling scattered

#### After (Declarative)

**Node Implementation (99% reduction in code):**

```python
from omnibase_core.nodes import NodeOrchestrator

class NodeDataPipeline(NodeOrchestrator):
    """Data processing pipeline using workflow - all logic driven by YAML contract."""
    pass  # All logic driven by YAML contract

# NodeOrchestrator is workflow-driven. All node classes are exported from omnibase_core.nodes.
```

**YAML Contract (`contracts/data_pipeline.yaml`):**

```yaml
workflow_coordination:
  workflow_definition:
    workflow_metadata:
      workflow_name: data_processing_pipeline
      workflow_version: "1.0.0"
      execution_mode: parallel

    execution_graph:
      nodes:
        - node_id: "fetch_raw_data"
          node_type: effect
          description: "Fetch raw data from API"

        - node_id: "validate_schema"
          node_type: compute
          depends_on:
            - fetch_raw_data

        - node_id: "enrich_data"
          node_type: compute
          depends_on:
            - fetch_raw_data

        - node_id: "aggregate_metrics"
          node_type: reducer
          depends_on:
            - validate_schema
            - enrich_data

        - node_id: "quality_check"
          node_type: compute
          depends_on:
            - aggregate_metrics

        - node_id: "persist_results"
          node_type: effect
          depends_on:
            - quality_check

        - node_id: "send_notification"
          node_type: effect
          depends_on:
            - quality_check

    coordination_rules:
      parallel_execution_allowed: true
      max_parallel_steps: 4
      failure_recovery_strategy: retry
      dependency_resolution_enabled: true
      detect_cycles: true
```

**Benefits:**
- ✅ Dependencies explicit in YAML
- ✅ Automatic parallel coordination
- ✅ Automatic cycle detection
- ✅ Changes don't require code redeployment
- ✅ Easy to visualize workflow graph
- ✅ Centralized error handling

---

## Testing Your Migration

### Test Reducer Migration

```python
import pytest
from uuid import uuid4

def test_reducer_fsm_transitions():
    """Test reducer FSM transitions work as expected."""
    node = NodeMetricsAggregator(container)

    # Initialize FSM
    node.initialize_fsm_state(node.fsm_contract, context={})
    assert node.get_current_state() == "idle"

    # Transition: idle → collecting
    input1 = ModelReducerInput(
        data=[],
        reduction_type=EnumReductionType.AGGREGATE,
        metadata={"trigger": "collect_metrics", "data_sources": ["db1", "db2"]}
    )
    result1 = await node.process(input1)
    assert result1.metadata["fsm_state"] == "collecting"
    assert len(result1.intents) > 0  # Intents emitted

    # Transition: collecting → validating
    input2 = ModelReducerInput(
        data=list(range(20)),  # 20 metrics (> 10 minimum)
        reduction_type=EnumReductionType.AGGREGATE,
        metadata={"trigger": "collection_complete", "collected_metrics": list(range(20))}
    )
    result2 = await node.process(input2)
    assert result2.metadata["fsm_state"] == "validating"

    # Verify state persistence
    state = node.get_current_state()
    assert state == "validating"

    # Verify terminal state detection
    assert not node.is_complete()  # Not yet terminal
```

### Test Orchestrator Migration

```python
def test_orchestrator_workflow_execution():
    """Test orchestrator workflow execution."""
    node = NodeDataPipeline(container)

    # Define workflow steps
    steps_config = [
        {"step_name": "Fetch Raw Data", "step_type": "effect"},
        {"step_name": "Validate Schema", "step_type": "compute", "depends_on": [...]},
        {"step_name": "Enrich Data", "step_type": "compute", "depends_on": [...]},
        # ... more steps
    ]

    # Execute workflow
    input_data = ModelOrchestratorInput(
        workflow_id=uuid4(),
        steps=steps_config,
        execution_mode=EnumExecutionMode.PARALLEL
    )

    result = await node.process(input_data)

    # Verify execution
    assert result.execution_status == "completed"
    assert len(result.completed_steps) == 7  # All 7 steps
    assert len(result.actions_emitted) == 7  # One action per step

    # Verify parallel execution (should be faster than sequential)
    assert result.execution_time_ms < SEQUENTIAL_BASELINE_MS
```

---

## Troubleshooting

### Common Migration Issues

#### Issue 1: "FSM contract not loaded"

**Cause**: Node contract doesn't have `state_transitions` field

**Solution**:

```python
# Ensure your contract has FSM subcontract
class MyNodeContract(BaseModel):
    state_transitions: ModelFSMSubcontract  # Add this field

# OR manually load contract from the nested key
from pathlib import Path
import yaml
data = yaml.safe_load(Path("contract.yaml").read_text())
node.fsm_contract = ModelFSMSubcontract.model_validate(data["state_transitions"])
```

#### Issue 2: "Workflow definition not loaded"

**Cause**: Node contract doesn't have `workflow_coordination` field

**Solution**:

```python
# Ensure your contract has workflow coordination
class MyNodeContract(BaseModel):
    workflow_coordination: ModelWorkflowCoordination  # Add this field

# OR manually load definition from the nested key
from pathlib import Path
import yaml
data = yaml.safe_load(Path("workflow.yaml").read_text())
node.workflow_definition = ModelWorkflowDefinition.model_validate(
    data["workflow_coordination"]["workflow_definition"]
)
```

#### Issue 3: "Condition expression failed"

**Cause**: Condition syntax incorrect or context missing

**Solution**:
```yaml
# Verify expression syntax
conditions:
  - expression: "data_sources min_length 1"  # Correct
    required: true

# NOT: expression: "len(data_sources) >= 1"  # Python syntax not supported
```

#### Issue 4: "Cycle detected in workflow"

**Cause**: Workflow has circular dependencies

**Solution**:

```yaml
# Fix circular dependency
nodes:
  - node_id: "step1"
    depends_on:
      - step2  # Circular: step1 -> step2 -> step1 (WRONG)

# Should be:
  - node_id: "step1"
    depends_on: []  # No circular dependency (CORRECT)
```

---

## Complete Examples

See the `examples/contracts/` directory for complete working examples:

1. **Reducer Example**: [`reducer_metrics_aggregator.yaml`](../../examples/contracts/reducer_metrics_aggregator.yaml)
   - Complete FSM with 6 states
   - Conditional transitions
   - Intent emission
   - Error handling

2. **Orchestrator Example**: [`orchestrator_data_pipeline.yaml`](../../examples/contracts/orchestrator_data_pipeline.yaml)
   - 7-step workflow with dependencies
   - Parallel execution
   - Action emission
   - Failure recovery

---

## Next Steps

1. **Review Examples**: Study the complete YAML contracts in `examples/contracts/`
2. **Identify Candidates**: Find reducer/orchestrator nodes to migrate
3. **Create YAML**: Convert logic to FSM/workflow contracts
4. **Update Classes**: Inherit from the v0.4.0 base classes
5. **Test**: Verify behavior matches original implementation
6. **Deploy**: Replace code-based nodes with declarative versions

---

## Import Path Changes Summary

With v0.4.0, all node classes are exported from `omnibase_core.nodes`:

```python
# Primary import (recommended) - v0.4.0 top-level API
from omnibase_core.nodes import NodeCompute, NodeReducer, NodeOrchestrator, NodeEffect

# Also available: Input/Output models
from omnibase_core.nodes import (
    ModelComputeInput, ModelComputeOutput,
    ModelEffectInput, ModelEffectOutput,
    ModelReducerInput, ModelReducerOutput,
    ModelOrchestratorInput, ModelOrchestratorOutput,
)

# Also available: Public enums
from omnibase_core.nodes import (
    EnumReductionType, EnumConflictResolution, EnumStreamingMode,  # Reducer
    EnumExecutionMode, EnumWorkflowStatus, EnumActionType, EnumBranchCondition,  # Orchestrator
)
```

| Node Type | v0.4.0 Import Path | Notes |
|-----------|--------------------|---------------------------------|
| **Compute** | `from omnibase_core.nodes import NodeCompute` | Unchanged |
| **Effect** | `from omnibase_core.nodes import NodeEffect` | Unchanged |
| **Reducer** | `from omnibase_core.nodes import NodeReducer` | FSM-driven (formerly `NodeReducerDeclarative`) |
| **Orchestrator** | `from omnibase_core.nodes import NodeOrchestrator` | Workflow-driven (formerly `NodeOrchestratorDeclarative`) |

### Migration from Pre-v0.4.0 Code

If you have code using old import patterns, update your imports:

```python
# Old patterns (removed in v0.4.0) - will cause ImportError
# from omnibase_core.nodes.node_reducer_declarative import NodeReducerDeclarative
# from omnibase_core.nodes.node_orchestrator_declarative import NodeOrchestratorDeclarative

# v0.4.0 - use these instead
from omnibase_core.nodes import NodeReducer, NodeOrchestrator
```

**Important Notes**:

- Legacy node implementations have been **removed** - there is no `nodes/legacy/` module
- `NodeCompute` and `NodeEffect` remain unchanged (no declarative variants existed)
- `NodeReducer` is now FSM-driven via YAML contracts
- `NodeOrchestrator` is now workflow-driven via YAML contracts

**Required Migration Steps**:

1. Update imports to use `from omnibase_core.nodes import NodeReducer, NodeOrchestrator`
2. Convert custom state management logic to FSM YAML contracts (for reducers)
3. Convert custom workflow logic to workflow YAML contracts (for orchestrators)
4. Follow the examples in this guide to create declarative contracts
5. Run tests to verify behavior matches the original implementation

---

## Additional Resources

- **FSM Executor Documentation**: [`src/omnibase_core/utils/util_fsm_executor.py`](../../src/omnibase_core/utils/util_fsm_executor.py)
- **Workflow Executor Documentation**: [`src/omnibase_core/utils/util_workflow_executor.py`](../../src/omnibase_core/utils/util_workflow_executor.py)
- **Mixin Documentation**: [`src/omnibase_core/mixins/mixin_metadata.yaml`](../../src/omnibase_core/mixins/mixin_metadata.yaml)

---

**Last Updated**: 2025-12-06
**Version**: 0.4.0
**Maintainer**: ONEX Framework Team
