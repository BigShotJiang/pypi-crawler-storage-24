"""Exceptions raised by the Garo Entity Pro local API client."""

from __future__ import annotations


class GaroApiError(Exception):
    """Base error for Garo API failures."""


class GaroAuthError(GaroApiError):
    """Invalid credentials or unsupported auth scheme."""


class GaroConnectionError(GaroApiError):
    """Network-level failure (timeout, refused, TLS, etc.)."""


class GaroHttpError(GaroApiError):
    """Non-success HTTP status from the device."""

    def __init__(self, message: str, *, status: int, body: str | None = None) -> None:
        super().__init__(message)
        self.status = status
        self.body = body
