"""Garo Entity Pro local API — async client and response parsing.

Install from PyPI: ``pip install garo-entity-pro`` (import name ``garo_entity_pro``).
"""

from __future__ import annotations

from .client import GaroApiClient
from .exceptions import GaroApiError, GaroAuthError, GaroConnectionError, GaroHttpError
from .parsing import CHARGING_STATE_LABELS

__all__ = [
    "CHARGING_STATE_LABELS",
    "GaroApiClient",
    "GaroApiError",
    "GaroAuthError",
    "GaroConnectionError",
    "GaroHttpError",
]
