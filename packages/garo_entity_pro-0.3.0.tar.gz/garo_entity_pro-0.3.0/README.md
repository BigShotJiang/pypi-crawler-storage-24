# garo-entity-pro

Async Python client for the **Garo Entity Pro** wallbox local HTTPS API (`/status/energy-meter`, `/status/temperatures`, etc.).

## Install

```bash
pip install garo-entity-pro
```

## Library usage

```python
from garo_entity_pro import GaroApiClient

async def main():
    async with GaroApiClient("https://192.168.1.10", "user", "pass", verify_ssl=False) as client:
        data = await client.get_status()
```

Parsing helpers live under `garo_entity_pro.parsing` (OCPP-style meter payloads, state labels).

## Home Assistant

The custom integration in `custom_components/garo_entity_pro/` depends on this package (see `manifest.json`). Install the integration and ensure Home Assistant can install requirements, or run `pip install -e .` from this repository when developing.

## Development

```bash
pip install -e ".[ha]"
```

Build a wheel:

```bash
pip install build && python -m build
```
