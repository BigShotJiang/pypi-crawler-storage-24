"""Core utilities and abstractions"""
