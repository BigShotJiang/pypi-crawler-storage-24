"""Provenance verification methods"""
