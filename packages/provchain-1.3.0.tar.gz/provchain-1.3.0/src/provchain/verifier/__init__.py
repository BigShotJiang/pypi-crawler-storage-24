"""Verifier: Provenance checking engine"""
