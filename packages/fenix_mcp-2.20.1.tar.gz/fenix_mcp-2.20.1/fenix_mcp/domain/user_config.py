# SPDX-License-Identifier: MIT
"""Domain helpers for user configuration documents."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fenix_mcp.domain._service_base import run_in_context
from fenix_mcp.infrastructure.fenix_api.client import FenixApiClient


def _strip_none(data: Dict[str, Any]) -> Dict[str, Any]:
    return {key: value for key, value in data.items() if value not in (None, "")}


class UserConfigService:
    def __init__(self, api: FenixApiClient):
        self._api = api

    async def create(
        self, data: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        payload = _strip_none(data)
        result = await run_in_context(
            self._api.create_user_core_document, payload, team_id=team_id
        )
        if isinstance(result, dict) and "document" in result:
            return result["document"]
        return result or {}

    async def list(
        self,
        *,
        returnContent: Optional[bool] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        team_id: Optional[str] = None,
        **_: Any,
    ) -> List[Dict[str, Any]]:
        return (
            await run_in_context(
                self._api.list_user_core_documents,
                return_content=bool(returnContent),
                limit=limit,
                offset=offset,
                team_id=team_id,
            )
            or []
        )

    async def get(
        self,
        doc_id: str,
        *,
        returnContent: Optional[bool] = None,
        team_id: Optional[str] = None,
        **_: Any,
    ) -> Dict[str, Any]:
        return await run_in_context(
            self._api.get_user_core_document,
            doc_id,
            return_content=bool(returnContent),
            team_id=team_id,
        )

    async def update(
        self, doc_id: str, data: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        payload = _strip_none(data)
        result = await run_in_context(
            self._api.update_user_core_document, doc_id, payload, team_id=team_id
        )
        if isinstance(result, dict) and "document" in result:
            return result["document"]
        return result or {}

    async def delete(self, doc_id: str, *, team_id: Optional[str] = None) -> None:
        await run_in_context(
            self._api.delete_user_core_document, doc_id, team_id=team_id
        )
