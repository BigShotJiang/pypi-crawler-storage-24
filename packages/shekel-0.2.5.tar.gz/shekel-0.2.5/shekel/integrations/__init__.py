"""Observability integrations for Shekel.

This package provides adapters for integrating Shekel with observability platforms
like Langfuse, DataDog, Arize, etc.
"""

from shekel.integrations.async_queue import AsyncEventQueue
from shekel.integrations.base import ObservabilityAdapter
from shekel.integrations.registry import AdapterRegistry

__all__ = ["ObservabilityAdapter", "AdapterRegistry", "AsyncEventQueue"]

# Optional Langfuse adapter (only if langfuse is installed)
try:
    from shekel.integrations.langfuse import LangfuseAdapter  # noqa: F401

    __all__.append("LangfuseAdapter")
except ImportError:
    # langfuse is an optional dependency
    pass
