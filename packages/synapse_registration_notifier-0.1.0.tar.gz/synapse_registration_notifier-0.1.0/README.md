# Synapse Registration Notifier

A simple [Synapse](https://github.com/element-hq/synapse) module that sends a notification to a specified room whenever
a new user registers on the server, containing some basic information and also configurable alerting capabilities.

## Installing

Install the module:
```sh
pip install git+https://codeberg.org/timedout/synapse-registration-notifier.git
```

And then configure it:
```yaml
modules:
  - module: synapse_registration_notifier.RegistrationNotifier
    config:
      # (required) The room to send the notification to, in the form of !roomid:server.name
      notification_room: "!yourroomid:yourserver.example"
      # (required) The user to send the notification as. Must be joined to the notification_room.
      admin_user_id: "@modbot:yourserver.example"
      # Whether to include a mention of @room in the notification
      mention_room: false
      # Whether to include individual user mentions in the notification, in the form of @user:server.name
      mention_user_ids:
        - "@user1:yourserver.example"
```
