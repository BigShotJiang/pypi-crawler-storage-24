from notee.cli.utils.config import get_config
import chromadb
import uuid

def add_file_to_db(text: str, path: str, created_at = ""):
    config = get_config()
    db_path = config["settings"]["db_path"]
    client = chromadb.PersistentClient(db_path)
    collection = client.get_collection("notee")
    collection.add(ids=str(uuid.uuid4()), documents=[text], metadatas=[{
        "path": path,
        "created_at": created_at
    }])