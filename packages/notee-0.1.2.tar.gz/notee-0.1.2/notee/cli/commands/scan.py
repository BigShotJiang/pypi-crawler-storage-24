from notee.cli.utils.logs import send_success
from notee.cli.utils.config import get_config
from notee.cli.utils.scaner import scan
from rich.console import Console
import typer

app = typer.Typer()

@app.command("scan")
def scan_folder():
    """Scan folder to add notes to the db if they're not already there."""
    console = Console()
    with console.status(" ", spinner="dots"):
        config = get_config()
        notes_folder = config["patches"]["base_folder"]
        n_new_files = scan(notes_folder)
    if n_new_files:
        send_success(f"Scanned your vault, added {n_new_files} new files to the db!")
    else:
        send_success("Scanned your vault. Nothing new appeared from last scan.")
