"""Tests for the operation registry and registration."""

import pytest

from stitchflow_local_agent.automation.operation import (
    OPERATION_REGISTRY,
    Operation,
    clear_registry,
    get_operation,
    register_operation,
)
from stitchflow_local_agent.automation.workflow import WorkflowContext, WorkflowResult


async def _dummy_workflow(ctx: WorkflowContext, params: None = None) -> WorkflowResult:
    return WorkflowResult(success=True, output={"test": True})


@pytest.fixture(autouse=True)
def _clean_registry():
    clear_registry()
    yield
    clear_registry()


def test_register_and_get_operation():
    op = Operation(operation_key="test_op", workflow=_dummy_workflow)
    register_operation(op)
    assert "test_op" in OPERATION_REGISTRY
    retrieved = get_operation("test_op")
    assert retrieved.operation_key == "test_op"


def test_get_unknown_operation_raises():
    with pytest.raises(KeyError, match="Operation not found: missing_op"):
        get_operation("missing_op")


def test_duplicate_registration_is_idempotent():
    op = Operation(operation_key="dup_op", workflow=_dummy_workflow)
    register_operation(op)
    register_operation(op)
    assert len([k for k in OPERATION_REGISTRY if k == "dup_op"]) == 1


def test_clear_registry():
    register_operation(Operation(operation_key="a", workflow=_dummy_workflow))
    register_operation(Operation(operation_key="b", workflow=_dummy_workflow))
    assert len(OPERATION_REGISTRY) == 2
    clear_registry()
    assert len(OPERATION_REGISTRY) == 0


def test_register_all_operations():
    from stitchflow_local_agent.integrations import register_all_operations

    register_all_operations()
    assert "openai_get_users" in OPERATION_REGISTRY
    assert "openai_create_user" in OPERATION_REGISTRY
    assert "openai_delete_user" in OPERATION_REGISTRY
    assert "calendly_remove_user" in OPERATION_REGISTRY
    assert "calendly_change_role" in OPERATION_REGISTRY
