"""Tests for scraping plan schema validation."""

import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from stitchflow_local_agent.automation.scraping_plan import (
    AddUserPlan,
    GetUsersPlan,
    PaginationConfig,
    RemoveUserPlan,
)


PLANS_DIR = Path(__file__).parent.parent / "stitchflow_local_agent" / "integrations"


def test_get_users_plan_minimal():
    plan = GetUsersPlan(
        start_url_template="https://example.com/users",
        extraction_code="rows = []",
        parsing_code="def parse_user(cells): return {'name': '', 'email': '', 'role': '', 'added_date': None}",
    )
    assert plan.operation_type == "get_users"
    assert plan.pagination_code is None


def test_add_user_plan_minimal():
    plan = AddUserPlan(
        start_url_template="https://example.com/users",
        email_input_selector="#email",
        submit_button_selector="#submit",
    )
    assert plan.operation_type == "add_user"
    assert plan.wait_after_submit_seconds == 2


def test_remove_user_plan_with_pagination():
    plan = RemoveUserPlan(
        start_url_template="https://example.com/users",
        row_selector="tbody tr",
        email_selector=".email",
        delete_button_selector=".delete",
        pagination=PaginationConfig(
            has_pagination=True,
            next_button_selector=".next-btn",
        ),
    )
    assert plan.pagination is not None
    assert plan.pagination.has_pagination is True


def test_openai_get_users_plan_json():
    plan_file = PLANS_DIR / "openai" / "plans" / "get_users.json"
    assert plan_file.exists(), f"Plan file not found: {plan_file}"
    data = json.loads(plan_file.read_text())
    plan = GetUsersPlan.model_validate(data)
    assert plan.extraction_code
    assert plan.parsing_code
    assert plan.pagination_code


def test_openai_create_user_plan_json():
    plan_file = PLANS_DIR / "openai" / "plans" / "create_user.json"
    assert plan_file.exists()
    data = json.loads(plan_file.read_text())
    plan = AddUserPlan.model_validate(data)
    assert plan.email_input_selector


def test_openai_delete_user_plan_json():
    plan_file = PLANS_DIR / "openai" / "plans" / "delete_user.json"
    assert plan_file.exists()
    data = json.loads(plan_file.read_text())
    plan = RemoveUserPlan.model_validate(data)
    assert plan.row_selector
    assert plan.has_confirmation_modal


def test_get_users_plan_missing_required():
    with pytest.raises(ValidationError):
        GetUsersPlan()  # type: ignore[call-arg]
