"""Tests for workflow types and WorkflowResult."""

from stitchflow_local_agent.automation.workflow import ConnectionInfo, WorkflowResult


def test_workflow_result_success():
    result = WorkflowResult(success=True, output={"users": []})
    assert result.success is True
    assert result.error is None


def test_workflow_result_failure():
    result = WorkflowResult(success=False, output={}, error="Something went wrong")
    assert result.success is False
    assert result.error == "Something went wrong"


def test_connection_info():
    info = ConnectionInfo(default_url="https://example.com", integration_key="openai")
    assert info.default_url == "https://example.com"
    assert info.integration_key == "openai"
