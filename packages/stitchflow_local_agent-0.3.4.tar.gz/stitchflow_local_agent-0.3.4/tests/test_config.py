"""Tests for config module (non-filesystem operations)."""

import os
import tempfile
from pathlib import Path
from unittest.mock import patch

from stitchflow_local_agent.common import config


def test_safe_int_env_valid():
    with patch.dict(os.environ, {"TEST_INT": "42"}):
        assert config._safe_int_env("TEST_INT", 10) == 42


def test_safe_int_env_missing():
    with patch.dict(os.environ, {}, clear=True):
        assert config._safe_int_env("MISSING", 99) == 99


def test_safe_int_env_invalid():
    with patch.dict(os.environ, {"BAD": "abc"}):
        assert config._safe_int_env("BAD", 7) == 7


def test_save_and_load_connections():
    with tempfile.TemporaryDirectory() as tmpdir:
        conn_file = Path(tmpdir) / "connections.json"
        connections = [
            {"connection_id": "c1", "integration_key": "openai", "default_url": "https://chatgpt.com"},
            {"connection_id": "c2", "integration_key": "calendly", "default_url": "https://calendly.com"},
        ]
        with patch.object(config, "CONNECTIONS_FILE", conn_file):
            config.save_connections(connections)
            loaded = config.load_connections()
            assert len(loaded) == 2
            assert loaded[0]["connection_id"] == "c1"

            ids = config.get_connection_ids()
            assert ids == ["c1", "c2"]

            meta = config.get_connection_metadata()
            assert "c1" in meta
            assert meta["c1"]["integration_key"] == "openai"


def test_load_connections_missing_file():
    with patch.object(config, "CONNECTIONS_FILE", Path("/nonexistent/path.json")):
        assert config.load_connections() == []
