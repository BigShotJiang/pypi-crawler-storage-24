"""Export users CSV from Linear members settings."""

from __future__ import annotations

import pathlib
import time
import zipfile
from datetime import datetime, timezone
from typing import Any

import undetected_chromedriver as uc
from selenium.common.exceptions import (
    ElementClickInterceptedException,
    NoSuchElementException,
    TimeoutException,
    WebDriverException,
)
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from stitchflow_local_agent.common import config
from stitchflow_local_agent.common.logging import append_jsonl

LINEAR_MEMBERS_URL = "https://linear.app/settings/members"
LINEAR_DOWNLOAD_DIR = config.DATA_SYNC_DIR / "linear"
# sync_cli currently initializes browser download_dir to ~/.stitchflow/data-sync/calendly
# so we watch there for new downloads and move to LINEAR_DOWNLOAD_DIR.
LINEAR_DOWNLOAD_WATCH_DIR = config.DATA_SYNC_DIR / "calendly"
EXPORT_LOG_PATH = config.LOGS_DIR / "linear-export.jsonl"
MAX_KEPT_CSVS = 5


def _ensure_dirs() -> None:
    config.ensure_dirs()
    LINEAR_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    LINEAR_DOWNLOAD_WATCH_DIR.mkdir(parents=True, exist_ok=True)


def _export_fail(msg: str) -> None:
    append_jsonl(
        EXPORT_LOG_PATH,
        {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "app": "linear",
            "status": "failed",
            "error": msg,
        },
    )


def _snapshot_files(directory: pathlib.Path) -> dict[pathlib.Path, tuple[int, int]]:
    snapshot: dict[pathlib.Path, tuple[int, int]] = {}
    for path in directory.glob("*"):
        if not path.is_file():
            continue
        try:
            stat = path.stat()
            snapshot[path] = (stat.st_mtime_ns, stat.st_size)
        except OSError:
            continue
    return snapshot


def _wait_for_download(
    directory: pathlib.Path,
    existing: dict[pathlib.Path, tuple[int, int]],
    timeout: int = 90,
) -> pathlib.Path | None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        current = _snapshot_files(directory)
        candidates: list[pathlib.Path] = []
        for path, meta in current.items():
            if path.name.endswith((".crdownload", ".tmp", ".part")):
                continue
            old_meta = existing.get(path)
            if old_meta is None or old_meta != meta:
                candidates.append(path)
        if candidates:
            return max(candidates, key=lambda f: f.stat().st_mtime_ns)
        time.sleep(1)
    return None


def _click_with_fallback(driver: uc.Chrome, element: Any) -> bool:
    try:
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center', inline:'nearest'});",
            element,
        )
    except Exception:
        pass

    try:
        ActionChains(driver).move_to_element(element).pause(0.1).click(element).perform()
        return True
    except (ElementClickInterceptedException, WebDriverException):
        try:
            element.click()
            return True
        except (ElementClickInterceptedException, WebDriverException):
            pass
        try:
            driver.execute_script("arguments[0].click();", element)
            return True
        except Exception:
            return False


def _extract_csv_from_download(download_path: pathlib.Path, timestamp: str) -> pathlib.Path | None:
    csv_target = LINEAR_DOWNLOAD_DIR / f"linear_users_{timestamp}.csv"

    if zipfile.is_zipfile(download_path):
        print("  Downloaded file is a ZIP archive, extracting...")
        try:
            with zipfile.ZipFile(download_path, "r") as zf:
                csv_members = [m for m in zf.namelist() if m.endswith(".csv")]
                if not csv_members:
                    print("  x ZIP contains no CSV files")
                    return None
                csv_name = csv_members[0]
                print(f"  Extracting {csv_name} from ZIP")
                with zf.open(csv_name) as src, open(csv_target, "wb") as dst:
                    dst.write(src.read())
            download_path.unlink(missing_ok=True)
            return csv_target
        except zipfile.BadZipFile:
            print("  x File appears corrupt")
            return None

    try:
        download_path.rename(csv_target)
        return csv_target
    except Exception as exc:
        print(f"  x Failed to process download: {exc}")
        return None


def export_linear_users(driver: uc.Chrome) -> str | None:
    """Export members from Linear settings and return the CSV path."""
    print("\n=== Linear: Exporting members ===")
    _ensure_dirs()

    print("  Opening Linear members settings page...")
    driver.get(LINEAR_MEMBERS_URL)

    wait = WebDriverWait(driver, 60)
    try:
        wait.until(
            EC.presence_of_element_located(
                (
                    By.XPATH,
                    "//button[contains(.,'Export CSV')] | //button[contains(.,'Export')]",
                )
            )
        )
    except TimeoutException:
        pass
    time.sleep(2)

    current_url = (driver.current_url or "").lower()
    if "linear.app" not in current_url:
        print(f"  x Not on Linear (at {driver.current_url}). Session may have expired.")
        print("  Run 'stitchflow-sync setup' to re-authenticate.")
        _export_fail("Not on Linear – session may have expired")
        return None
    if "/login" in current_url or "/signin" in current_url:
        print("  x Redirected to Linear login page. Session expired.")
        print("  Run 'stitchflow-sync setup' to re-authenticate.")
        _export_fail("Redirected to Linear login – session expired")
        return None

    try:
        export_btn = driver.find_element(
            By.XPATH,
            "//button[contains(.,'Export CSV')] | //button[contains(.,'Export')]",
        )
    except NoSuchElementException:
        print("  x Could not find Export CSV button on page")
        _export_fail("Could not find Export CSV button on page")
        return None

    print("  Found Export CSV button")
    existing_files = _snapshot_files(LINEAR_DOWNLOAD_WATCH_DIR)
    if not _click_with_fallback(driver, export_btn):
        print("  x Could not click Export CSV button")
        _export_fail("Could not click Export CSV button")
        return None

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    download_path = _wait_for_download(LINEAR_DOWNLOAD_WATCH_DIR, existing_files, timeout=90)
    if download_path is None:
        print("  x No new file detected after export")
        _export_fail("No new file detected after export")
        return None

    file_size = download_path.stat().st_size
    if file_size == 0:
        print("  x Downloaded file is empty")
        _export_fail("Downloaded file is empty")
        return None

    csv_path = _extract_csv_from_download(download_path, timestamp)
    if not csv_path:
        _export_fail("Failed to process downloaded Linear export")
        return None

    csv_size = csv_path.stat().st_size
    print(f"  CSV ready: {csv_path} ({csv_size} bytes)")
    append_jsonl(
        EXPORT_LOG_PATH,
        {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "app": "linear",
            "status": "success",
            "csv_path": str(csv_path),
            "csv_size_bytes": csv_size,
        },
    )
    return str(csv_path)


def cleanup_old_csvs() -> None:
    csv_files = sorted(
        LINEAR_DOWNLOAD_DIR.glob("linear_users_*.csv"),
        key=lambda f: f.stat().st_mtime,
        reverse=True,
    )
    for old_file in csv_files[MAX_KEPT_CSVS:]:
        try:
            old_file.unlink()
            print(f"  Cleaned up old CSV: {old_file.name}")
        except OSError:
            pass
