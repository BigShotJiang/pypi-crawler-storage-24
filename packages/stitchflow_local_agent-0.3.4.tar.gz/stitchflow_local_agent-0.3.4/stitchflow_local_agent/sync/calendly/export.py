"""Export active users CSV from Calendly admin."""

from __future__ import annotations

import pathlib
import time
import zipfile
from datetime import datetime, timezone
from typing import Any

import undetected_chromedriver as uc
from selenium.common.exceptions import (
    ElementClickInterceptedException,
    NoSuchElementException,
    TimeoutException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from stitchflow_local_agent.common import config
from stitchflow_local_agent.common.logging import append_jsonl

CALENDLY_ADMIN_USERS_URL = "https://calendly.com/app/admin/users"
CALENDLY_DOWNLOAD_DIR = config.DATA_SYNC_DIR / "calendly"
EXPORT_LOG_PATH = config.LOGS_DIR / "calendly-export.jsonl"
MAX_KEPT_CSVS = 5


def _ensure_dirs() -> None:
    config.ensure_dirs()
    CALENDLY_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)


def _export_fail(msg: str) -> None:
    append_jsonl(
        EXPORT_LOG_PATH,
        {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "app": "calendly",
            "status": "failed",
            "error": msg,
        },
    )


def _snapshot_files(directory: pathlib.Path) -> dict[pathlib.Path, tuple[int, int]]:
    """Return file metadata map: path -> (mtime_ns, size)."""
    snapshot: dict[pathlib.Path, tuple[int, int]] = {}
    for path in directory.glob("*"):
        if not path.is_file():
            continue
        try:
            stat = path.stat()
            snapshot[path] = (stat.st_mtime_ns, stat.st_size)
        except OSError:
            continue
    return snapshot


def _wait_for_download(
    directory: pathlib.Path,
    existing: dict[pathlib.Path, tuple[int, int]],
    timeout: int = 60,
) -> pathlib.Path | None:
    """Poll for a new or changed completed download in *directory*."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        current = _snapshot_files(directory)
        candidates: list[pathlib.Path] = []
        for path, meta in current.items():
            if path.name.endswith((".crdownload", ".tmp", ".part")):
                continue
            old_meta = existing.get(path)
            if old_meta is None or old_meta != meta:
                candidates.append(path)
        if candidates:
            return max(candidates, key=lambda f: f.stat().st_mtime_ns)
        time.sleep(1)
    return None


def _click_with_fallback(driver: uc.Chrome, element: Any) -> bool:
    """Click an element with pointer action first, then JS click fallback."""
    click_target = element
    try:
        maybe_target = driver.execute_script(
            """
            const el = arguments[0];
            return el.closest('button,[role="menuitem"],li,[role="option"]') || el;
            """,
            element,
        )
        if maybe_target is not None:
            click_target = maybe_target
    except Exception:
        pass

    try:
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center', inline:'nearest'});",
            click_target,
        )
    except Exception:
        pass

    try:
        ActionChains(driver).move_to_element(click_target).pause(0.15).click(click_target).perform()
        return True
    except (ElementClickInterceptedException, WebDriverException):
        try:
            click_target.click()
            return True
        except (ElementClickInterceptedException, WebDriverException):
            pass
        try:
            driver.execute_script("arguments[0].click();", click_target)
            return True
        except Exception:
            return False


def _find_active_option(driver: uc.Chrome, wait: WebDriverWait) -> Any | None:
    """Find the export dropdown Active option using resilient selectors."""
    selectors = (
        # Most specific for current Calendly DOM:
        # Export button -> sibling dropdown -> button containing div.tswlbdx "Active"
        "//button[.//span[contains(normalize-space(),'Export')]]"
        "/following-sibling::div//button[.//div[normalize-space()='Active']]",
        # Fallbacks for minor DOM changes.
        "//div[contains(@class,'b1uekb9q')]//button[.//div[normalize-space()='Active']]",
        "//button[.//div[normalize-space()='Active']]",
        "//li[.//text()[contains(.,'Active')]]",
        "//*[@role='menuitem' and contains(.,'Active')]",
    )
    for selector in selectors:
        try:
            return wait.until(EC.element_to_be_clickable((By.XPATH, selector)))
        except TimeoutException:
            continue
    return None


def export_calendly_users(driver: uc.Chrome) -> str | None:
    """Export active users from Calendly admin and return the CSV file path."""
    print("\n=== Calendly: Exporting active users ===")
    _ensure_dirs()

    print("  Opening Calendly admin users page...")
    driver.get(CALENDLY_ADMIN_USERS_URL)

    wait = WebDriverWait(driver, 30)
    try:
        wait.until(EC.presence_of_element_located((By.XPATH, "//*[contains(text(),'Export')]")))
    except TimeoutException:
        pass
    time.sleep(2)

    current_url = driver.current_url
    if "calendly.com" not in current_url:
        print(f"  x Not on Calendly (at {current_url}). Session may have expired.")
        print("  Run 'stitchflow-sync setup' to re-authenticate.")
        _export_fail("Not on Calendly – session may have expired")
        return None
    if "/login" in current_url or "/signup" in current_url:
        print("  x Redirected to Calendly login page. Session expired.")
        print("  Run 'stitchflow-sync setup' to re-authenticate.")
        _export_fail("Redirected to Calendly login – session expired")
        return None

    try:
        export_btn = driver.find_element(By.XPATH, "//button[.//span[contains(normalize-space(),'Export')]]")
    except NoSuchElementException:
        try:
            export_btn = driver.find_element(By.XPATH, "//*[contains(text(),'Export')]")
        except NoSuchElementException:
            print("  x Could not find Export button on page")
            _export_fail("Could not find Export button on page")
            return None

    print("  Found Export button")
    existing_files = _snapshot_files(CALENDLY_DOWNLOAD_DIR)
    if not _click_with_fallback(driver, export_btn):
        print("  x Could not click Export button")
        _export_fail("Could not click Export button")
        return None
    time.sleep(2)

    active_opt = _find_active_option(driver, wait)
    if active_opt is None:
        print("  x Could not find Active option in export dropdown")
        _export_fail("Could not find Active option in export dropdown")
        return None

    print("  Found Active option, clicking to start download...")
    if not _click_with_fallback(driver, active_opt):
        print("  x Could not click Active option in export dropdown")
        _export_fail("Could not click Active option in export dropdown")
        return None

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    download_path = _wait_for_download(CALENDLY_DOWNLOAD_DIR, existing_files, timeout=90)

    if download_path is None:
        print("  x No new file detected after export")
        _export_fail("No new file detected after export")
        return None

    file_size = download_path.stat().st_size
    if file_size == 0:
        print("  x Downloaded file is empty")
        _export_fail("Downloaded file is empty")
        return None

    csv_path = _extract_csv_from_download(download_path, timestamp)
    if not csv_path:
        _export_fail("Failed to extract CSV from downloaded file")
        return None

    csv_size = csv_path.stat().st_size
    print(f"  CSV ready: {csv_path} ({csv_size} bytes)")

    append_jsonl(
        EXPORT_LOG_PATH,
        {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "app": "calendly",
            "status": "success",
            "csv_path": str(csv_path),
            "csv_size_bytes": csv_size,
        },
    )

    return str(csv_path)


def _extract_csv_from_download(download_path: pathlib.Path, timestamp: str) -> pathlib.Path | None:
    """Extract the CSV from the downloaded file (ZIP or plain CSV)."""
    csv_target = CALENDLY_DOWNLOAD_DIR / f"calendly_users_{timestamp}.csv"

    if zipfile.is_zipfile(download_path):
        print("  Downloaded file is a ZIP archive, extracting...")
        try:
            with zipfile.ZipFile(download_path, "r") as zf:
                csv_members = [m for m in zf.namelist() if m.endswith(".csv")]
                if not csv_members:
                    print("  x ZIP contains no CSV files")
                    return None
                csv_name = csv_members[0]
                print(f"  Extracting {csv_name} from ZIP")
                with zf.open(csv_name) as src, open(csv_target, "wb") as dst:
                    dst.write(src.read())
            download_path.unlink(missing_ok=True)
            return csv_target
        except zipfile.BadZipFile:
            print("  x File appears corrupt")
            return None

    try:
        head = download_path.read_bytes()[:200]
        if head[:1] in (b"\x50", b"\x1f"):
            print("  x Downloaded file is binary but not a valid ZIP")
            return None
        download_path.rename(csv_target)
        return csv_target
    except Exception as exc:
        print(f"  x Failed to process download: {exc}")
        return None


def cleanup_old_csvs() -> None:
    """Remove old CSV files, keeping the most recent ``MAX_KEPT_CSVS``."""
    csv_files = sorted(
        CALENDLY_DOWNLOAD_DIR.glob("calendly_users_*.csv"),
        key=lambda f: f.stat().st_mtime,
        reverse=True,
    )
    for old_file in csv_files[MAX_KEPT_CSVS:]:
        try:
            old_file.unlink()
            print(f"  Cleaned up old CSV: {old_file.name}")
        except OSError:
            pass
    for leftover in CALENDLY_DOWNLOAD_DIR.glob("calendly_export_*"):
        try:
            leftover.unlink()
            print(f"  Cleaned up leftover: {leftover.name}")
        except OSError:
            pass
