"""Export ChatGPT workspace users via the browser session API."""

from __future__ import annotations

import csv
import io
import json
import time
from datetime import datetime, timezone
from typing import Any

import undetected_chromedriver as uc
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from stitchflow_local_agent.common import config
from stitchflow_local_agent.common.logging import append_jsonl

CHATGPT_URL = "https://chatgpt.com"
CHATGPT_ADMIN_URL = "https://chatgpt.com/admin/members"
CHATGPT_DOWNLOAD_DIR = config.DATA_SYNC_DIR / "chatgpt"
EXPORT_LOG_PATH = config.LOGS_DIR / "chatgpt-export.jsonl"
MAX_KEPT_CSVS = 5

_EXPORT_JS = """
return await (async () => {
    try {
        var aId = "__ACCOUNT_ID_OVERRIDE__";
        if (!aId) {
            var c = document.cookie.split(';');
            for (var j = 0; j < c.length; j++) {
                var p = c[j].trim();
                if (p.startsWith('_account=')) { aId = p.substring(9); break; }
            }
        }
        if (!aId) return {error: "_account cookie not found"};
        const r = await fetch("https://chatgpt.com/api/auth/session",
            {credentials: "include"});
        const s = await r.json();
        if (!s.accessToken) return {error: "Not authenticated"};
        const t = s.accessToken;
        const lim = 100; const all = [];
        async function gp(off) {
            const res = await fetch(
                "https://chatgpt.com/backend-api/accounts/" + aId +
                "/users?offset=" + off + "&limit=" + lim + "&query=",
                {credentials: "include", headers: {"Authorization": "Bearer " + t}});
            const d = await res.json();
            const us = d.users || d.items || d.results || [];
            for (var i = 0; i < us.length; i++) all.push(us[i]);
            if (us.length >= lim) return gp(off + lim);
        }
        await gp(0);
        if (all.length === 0) return {error: "No users found"};
        return {users: all, count: all.length, accountId: aId};
    } catch(e) { return {error: e.message || String(e)}; }
})();
"""


def _ensure_dirs() -> None:
    config.ensure_dirs()
    CHATGPT_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)


def _export_fail(msg: str) -> None:
    append_jsonl(
        EXPORT_LOG_PATH,
        {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "app": "chatgpt",
            "status": "failed",
            "error": msg,
        },
    )


def _users_to_csv(users: list[dict[str, Any]]) -> str:
    """Convert a list of user dicts to a CSV string."""
    if not users:
        return ""
    all_keys: list[str] = []
    seen: set[str] = set()
    for u in users:
        for k in u:
            if k not in seen:
                all_keys.append(k)
                seen.add(k)

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=all_keys, extrasaction="ignore")
    writer.writeheader()
    for u in users:
        flat: dict[str, Any] = {}
        for k in all_keys:
            v = u.get(k)
            if isinstance(v, (dict, list)):
                flat[k] = json.dumps(v)
            elif v is None:
                flat[k] = ""
            else:
                flat[k] = v
        writer.writerow(flat)
    return output.getvalue()


def _parse_eval_result(result: Any) -> dict[str, Any]:
    """Normalise the eval result into a plain dict regardless of wrapping."""
    if isinstance(result, dict):
        if "users" in result or "error" in result:
            return result
    if isinstance(result, str):
        try:
            parsed = json.loads(result)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
    if result is None:
        return {"error": "Script returned None"}
    return {"error": f"Unexpected result type: {type(result).__name__}"}


def _wait_for_chatgpt_admin_ready(driver: uc.Chrome, timeout: int = 30) -> bool:
    """Wait until ChatGPT admin page appears ready before running API fetch JS."""
    try:
        WebDriverWait(driver, timeout).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
    except TimeoutException:
        return False

    selectors = (
        (By.CSS_SELECTOR, "input[placeholder='Filter by name']"),
        (By.CSS_SELECTOR, "table tbody tr"),
        (By.XPATH, "//button[contains(., 'Invite') or contains(., 'Add')]"),
    )
    for by, value in selectors:
        try:
            WebDriverWait(driver, 8).until(EC.presence_of_element_located((by, value)))
            return True
        except TimeoutException:
            continue
    return False


def _should_retry_export_error(error: str) -> bool:
    lowered = error.lower()
    retry_markers = (
        "no users found",
        "not authenticated",
        "_account cookie not found",
        "unexpected result type",
    )
    return any(marker in lowered for marker in retry_markers)


def export_chatgpt_users(driver: uc.Chrome) -> str | None:
    """Export all users from the ChatGPT workspace and return the CSV path.

    Uses ``driver.execute_script()`` to call the ChatGPT session API from
    within the authenticated browser context.
    """
    print("\n=== ChatGPT: Exporting workspace users ===")
    _ensure_dirs()

    print("  Opening ChatGPT admin page...")
    driver.get(CHATGPT_ADMIN_URL)

    # Give ChatGPT admin enough time to initialize workspace context.
    if not _wait_for_chatgpt_admin_ready(driver, timeout=35):
        time.sleep(3)

    current_url = driver.current_url
    if "chatgpt.com" not in current_url:
        msg = f"Not on ChatGPT (at {current_url}). Session may have expired."
        print(f"  x {msg}")
        print("  Run 'stitchflow-sync setup' to re-authenticate.")
        _export_fail("Not on ChatGPT – session may have expired")
        return None
    if "/auth" in current_url or "/login" in current_url:
        msg = "Redirected to ChatGPT auth page. Session expired."
        print(f"  x {msg}")
        print("  Run 'stitchflow-sync setup' to re-authenticate.")
        _export_fail("Redirected to ChatGPT auth – session expired")
        return None

    override = config.CHATGPT_ACCOUNT_ID or ""
    js = _EXPORT_JS.replace("__ACCOUNT_ID_OVERRIDE__", override)
    if override:
        print(f"  Using explicit account ID: {override}")
    else:
        print("  Reading account ID from _account cookie...")

    data: dict[str, Any] = {"error": "Export did not run"}
    for attempt in range(1, 4):
        result = driver.execute_script(js)
        data = _parse_eval_result(result)
        if not data.get("error"):
            break
        err = str(data.get("error", "unknown error"))
        if attempt >= 3 or not _should_retry_export_error(err):
            break
        wait_seconds = attempt * 3
        print(f"  Retry {attempt}/2 after API warmup wait ({err})...")
        time.sleep(wait_seconds)
        try:
            driver.get(CHATGPT_ADMIN_URL)
            _wait_for_chatgpt_admin_ready(driver, timeout=20)
        except Exception:
            pass

    if data.get("error"):
        msg = f"API error: {data['error']}"
        print(f"  x {msg}")
        if data.get("debug"):
            print(f"  debug: {data['debug']}")
        _export_fail(msg)
        return None

    account_id = data.get("accountId", override or "unknown")
    users = data.get("users", [])
    count = data.get("count", len(users))
    if not users:
        msg = "No users returned from API"
        print(f"  x {msg}")
        _export_fail(msg)
        return None

    print(f"  Fetched {count} users (account {account_id}), generating CSV...")
    csv_content = _users_to_csv(users)
    if not csv_content:
        msg = "Failed to generate CSV from user data"
        print(f"  x {msg}")
        _export_fail(msg)
        return None

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    csv_path = CHATGPT_DOWNLOAD_DIR / f"chatgpt_users_{timestamp}.csv"
    csv_path.write_text(csv_content, encoding="utf-8")

    csv_size = csv_path.stat().st_size
    print(f"  CSV ready: {csv_path} ({csv_size} bytes, {count} users)")

    append_jsonl(
        EXPORT_LOG_PATH,
        {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "app": "chatgpt",
            "status": "success",
            "csv_path": str(csv_path),
            "csv_size_bytes": csv_size,
            "user_count": count,
            "account_id": account_id,
        },
    )

    return str(csv_path)


def cleanup_old_csvs() -> None:
    """Remove old ChatGPT CSV files, keeping the most recent ``MAX_KEPT_CSVS``."""
    csv_files = sorted(
        CHATGPT_DOWNLOAD_DIR.glob("chatgpt_users_*.csv"),
        key=lambda f: f.stat().st_mtime,
        reverse=True,
    )
    for old_file in csv_files[MAX_KEPT_CSVS:]:
        try:
            old_file.unlink()
            print(f"  Cleaned up old CSV: {old_file.name}")
        except OSError:
            pass
