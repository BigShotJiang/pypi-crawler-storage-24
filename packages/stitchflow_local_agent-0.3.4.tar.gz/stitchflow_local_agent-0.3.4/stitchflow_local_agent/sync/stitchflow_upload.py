"""Upload a CSV file to the Stitchflow.io connections UI."""

from __future__ import annotations

import time
from typing import Any

import undetected_chromedriver as uc
from selenium.common.exceptions import (
    NoSuchElementException,
    TimeoutException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from stitchflow_local_agent.common import config

STITCHFLOW_APP_URL = "https://app.stitchflow.io"
STITCHFLOW_INITIAL_LOAD_TIMEOUT_SECONDS = 90
STITCHFLOW_SEARCH_BAR_TIMEOUT_SECONDS = 90


def get_workspace_connections_url() -> str:
    """Return the workspace-scoped connections URL for the configured workspace."""
    workspace_id = (config.WORKSPACE_ID or "").strip().strip("/")
    if not workspace_id:
        return STITCHFLOW_APP_URL
    return f"{STITCHFLOW_APP_URL}/{workspace_id}/connections"


def upload_csv_to_stitchflow(driver: uc.Chrome, csv_path: str, app_name: str = "Calendly") -> dict[str, Any]:
    """Upload a CSV file to Stitchflow.io for the given app connection.

    Returns ``{"status": "connected"}`` on success or
    ``{"status": "failed", "error": "..."}`` on failure.
    """
    print(f"\n=== Stitchflow: Uploading CSV for {app_name} ===")

    def _fail(msg: str) -> dict[str, str]:
        return {"status": "failed", "error": msg}

    if not config.WORKSPACE_ID:
        print("  x STITCHFLOW_WORKSPACE_ID not set")
        return _fail("STITCHFLOW_WORKSPACE_ID not set")

    target_url = get_workspace_connections_url()
    print(f"  Opening {target_url}...")
    driver.get(target_url)

    wait = WebDriverWait(driver, STITCHFLOW_INITIAL_LOAD_TIMEOUT_SECONDS)
    try:
        wait.until(EC.presence_of_element_located((By.XPATH, "//*[contains(text(),'Connections')]")))
    except TimeoutException:
        pass
    time.sleep(2)

    current_url = driver.current_url
    if "stitchflow.io" not in current_url:
        print(f"  x Not on Stitchflow (at {current_url}). Session may have expired.")
        print("  Run 'stitchflow-sync setup' to re-authenticate.")
        return _fail("Not on Stitchflow – session may have expired")

    conn_link = None
    for _ in range(STITCHFLOW_INITIAL_LOAD_TIMEOUT_SECONDS):
        try:
            conn_link = driver.find_element(
                By.XPATH,
                "//a[contains(.,'Connections')] | //button[contains(.,'Connections')] | //*[contains(text(),'Connections')]",
            )
            break
        except NoSuchElementException:
            time.sleep(1)

    if conn_link is None:
        print("  x Could not find 'Connections' in sidebar")
        return _fail("Could not find Connections in sidebar")

    print("  Found Connections link")
    conn_link.click()

    search_input = None
    search_wait = WebDriverWait(driver, STITCHFLOW_SEARCH_BAR_TIMEOUT_SECONDS)
    try:
        search_input = search_wait.until(
            EC.element_to_be_clickable(
                (
                    By.XPATH,
                    "//input[contains(@placeholder,'Search connections')] | //input[contains(@placeholder,'Search')]",
                )
            )
        )
    except TimeoutException:
        pass

    if search_input is None:
        print("  x Could not find search bar on connections page")
        return _fail("Could not find search bar on connections page")

    print("  Found search bar")
    search_input.clear()
    search_input.send_keys(app_name)
    time.sleep(2)

    app_name_lower = app_name.lower()
    try:
        app_row = driver.find_element(
            By.XPATH,
            (
                "//*[contains(@href,'/connections') and "
                f"contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{app_name_lower}')]"
            ),
        )
    except NoSuchElementException:
        try:
            app_row = driver.find_element(
                By.XPATH,
                (
                    "//*[contains(@class,'authorized') or contains(@class,'connection')]["
                    f"contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{app_name_lower}')"
                    "]"
                ),
            )
        except NoSuchElementException:
            try:
                app_row = driver.find_element(
                    By.XPATH,
                    (
                        "//*[contains(translate(normalize-space(text()), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), "
                        f"'{app_name_lower}')]"
                    ),
                )
            except NoSuchElementException:
                print(f"  x Could not find {app_name} in connections list")
                return _fail(f"Could not find {app_name} in connections list")

    print(f"  Found {app_name} row")
    app_row.click()

    try:
        wait.until(EC.presence_of_element_located((By.XPATH, "//*[contains(text(),'Connected')]")))
    except TimeoutException:
        pass
    time.sleep(2)

    if not _click_users_action_menu(driver):
        return _fail("Could not click action menu on Users object row")

    time.sleep(2)

    try:
        update_opt = driver.find_element(
            By.XPATH, "//*[contains(text(),'Update with new CSV file')] | //*[contains(text(),'Update with new CSV')]"
        )
    except NoSuchElementException:
        print("  x Could not find 'Update with new CSV file' option")
        return _fail("Could not find 'Update with new CSV file' option")

    print("  Found 'Update with new CSV file'")
    update_opt.click()
    time.sleep(2)

    return _upload_file(driver, csv_path)


def _click_users_action_menu(driver: uc.Chrome) -> bool:
    try:
        btn = driver.find_element(By.CSS_SELECTOR, 'button[aria-label="More object options"]')
        btn.click()
        print("  Action menu opened via CSS selector")
        return True
    except (NoSuchElementException, WebDriverException):
        pass

    try:
        btn = driver.find_element(By.CSS_SELECTOR, 'button[data-testid="icon-button"][aria-haspopup="menu"]')
        btn.click()
        print("  Action menu opened via data-testid selector")
        return True
    except (NoSuchElementException, WebDriverException):
        pass

    print("  Trying JS-based approach to find action menu...")
    js = """
    (() => {
        let btn = document.querySelector('button[aria-label="More object options"]');
        if (btn) { btn.click(); return 'clicked_aria'; }
        btn = document.querySelector('button[data-testid="icon-button"][aria-haspopup="menu"]');
        if (btn) { btn.click(); return 'clicked_testid'; }
        return 'not_found';
    })()
    """
    result = driver.execute_script(f"return {js}")
    output = str(result).lower()
    if "not_found" in output:
        print("  x Could not find action menu button")
        return False
    print(f"  Action menu opened via JS ({output})")
    return True


def _upload_file(driver: uc.Chrome, csv_path: str) -> dict[str, Any]:
    """Upload a file via the popover, click Save, poll for Connected status."""

    def _fail(msg: str) -> dict[str, str]:
        return {"status": "failed", "error": msg}

    uploaded = False

    try:
        file_input = driver.find_element(By.CSS_SELECTOR, 'input[type="file"]')
        file_input.send_keys(str(csv_path))
        print("  CSV file attached via file input")
        uploaded = True
    except NoSuchElementException:
        pass

    if not uploaded:
        js_check = driver.execute_script(
            "return document.querySelector('input[type=\"file\"]') ? 'found' : 'not_found';"
        )
        if js_check == "found":
            try:
                file_input = driver.find_element(By.CSS_SELECTOR, 'input[type="file"]')
                file_input.send_keys(str(csv_path))
                print("  CSV file attached via file input (JS-found)")
                uploaded = True
            except (NoSuchElementException, WebDriverException) as exc:
                print(f"  x Upload via file input failed: {exc}")

    if not uploaded:
        print("  x Could not upload CSV file")
        return _fail("Could not upload CSV file")

    print("  Waiting for upload to complete...")
    for attempt in range(1, 16):
        time.sleep(2)
        page_text = driver.find_element(By.TAG_NAME, "body").text
        if "Uploading 100%" in page_text:
            print("  Upload complete (100%)")
            break
        if "Save" in page_text and "Uploading" not in page_text:
            print("  Upload complete")
            break
        print(f"  ... upload in progress (attempt {attempt})")

    try:
        save_btn = driver.find_element(By.XPATH, "//button[contains(.,'Save')]")
    except NoSuchElementException:
        print("  x Could not find Save button")
        return _fail("Could not find Save button after upload")

    print("  Found Save button")
    save_btn.click()
    print("  Save clicked, waiting for sync to complete...")

    for attempt in range(1, 31):
        time.sleep(5)
        page_text = driver.find_element(By.TAG_NAME, "body").text
        if "Connected" in page_text and "Syncing" not in page_text:
            print("  Status: Connected")
            return {"status": "connected"}
        if "Syncing" in page_text:
            print(f"  ... status: Syncing (attempt {attempt})")
            continue
        print(f"  ... waiting for status update (attempt {attempt})")

    print("  ! Timed out waiting for Connected status")
    return _fail("Timed out waiting for Connected status after upload")
