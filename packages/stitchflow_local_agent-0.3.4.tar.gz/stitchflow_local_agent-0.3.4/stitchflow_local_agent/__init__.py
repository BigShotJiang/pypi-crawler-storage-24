"""Stitchflow local agent package."""
