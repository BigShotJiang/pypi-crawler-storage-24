"""Generic plan executor utilities for all integrations.

These utilities execute operation plans (GetUsersPlan, AddUserPlan, RemoveUserPlan)
using Selenium WebDriver without any LLM calls.
"""

from __future__ import annotations

import logging
import time
from typing import Any

import undetected_chromedriver as uc
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.ui import WebDriverWait

from stitchflow_local_agent.automation.scraping_plan import AddUserPlan, GetUsersPlan, RemoveUserPlan

logger = logging.getLogger(__name__)


class PlanExecutionError(Exception):
    """Raised when plan execution fails."""

    pass


def execute_get_users_plan(
    driver: uc.Chrome,
    plan: GetUsersPlan,
    connection_default_url: str,
) -> list[dict[str, Any]]:
    """Execute a GetUsersPlan to scrape user data using generated code.

    Args:
        driver: UC Chrome WebDriver instance
        plan: GetUsersPlan with extraction_code, parsing_code, and pagination_code
        connection_default_url: Default URL for the connection (used in template)

    Returns:
        List of user dictionaries with keys: name, email, role, added_date (optional)

    Raises:
        PlanExecutionError: If scraping fails
    """
    start_url = plan.start_url_template.format(connection={"default_url": connection_default_url})
    logger.info(f"Navigating to {start_url}")
    driver.get(start_url)
    time.sleep(10)

    all_users: list[dict[str, Any]] = []
    seen_emails: set[str] = set()
    current_page = 1
    duplicate_page_count = 0
    max_duplicate_pages = 2

    try:
        parsing_globals: dict[str, Any] = {}
        exec(plan.parsing_code, parsing_globals)
        parse_user = parsing_globals.get("parse_user")
        if not parse_user:
            raise PlanExecutionError("parsing_code must define a 'parse_user' function")
    except Exception as e:
        raise PlanExecutionError(f"Failed to compile parsing_code: {e}")

    while True:
        logger.info(f"Scraping page {current_page}")

        max_retries = 3
        retry_count = 0
        rows: list[Any] = []

        while retry_count < max_retries:
            try:
                extraction_globals: dict[str, Any] = {"driver": driver, "By": By}
                exec(plan.extraction_code, extraction_globals)

                extracted_rows = extraction_globals.get("rows")
                if extracted_rows is None:
                    raise PlanExecutionError("extraction_code must assign results to 'rows' variable")
                rows = extracted_rows

                if len(rows) > 0:
                    break

                retry_count += 1
                if retry_count < max_retries:
                    logger.warning(f"No rows found on page {current_page}, retry {retry_count}/{max_retries}")
                    time.sleep(3)
                else:
                    logger.warning(f"No rows found after {max_retries} retries on page {current_page}")
                    break

            except Exception as e:
                raise PlanExecutionError(f"Failed to execute extraction_code: {e}")

        logger.info(f"Found {len(rows)} user rows on page {current_page}")

        new_users_on_page = 0
        for cell_texts in rows:
            try:
                user_data = parse_user(cell_texts)
                email = user_data.get("email", "")

                if email and email not in seen_emails:
                    seen_emails.add(email)
                    all_users.append(user_data)
                    new_users_on_page += 1
                elif email:
                    logger.debug(f"Skipping duplicate user: {email}")
            except Exception as e:
                logger.warning(f"Failed to parse user data from {cell_texts}: {e}")
                continue

        if new_users_on_page == 0 and len(rows) > 0:
            duplicate_page_count += 1
            logger.warning(
                f"Page {current_page} had no new users (duplicate page {duplicate_page_count}/{max_duplicate_pages})"
            )

            if duplicate_page_count >= max_duplicate_pages:
                logger.info(f"Stopping: {max_duplicate_pages} consecutive pages with all duplicates")
                break
        else:
            duplicate_page_count = 0
            logger.info(f"Added {new_users_on_page} new users from page {current_page}")

        if plan.pagination_code:
            try:
                pagination_globals: dict[str, Any] = {
                    "driver": driver,
                    "By": By,
                    "time": time,
                }
                exec(plan.pagination_code, pagination_globals)

                has_next = pagination_globals.get("has_next") or pagination_globals.get("result")

                if has_next is None:
                    logger.warning("pagination_code did not return has_next/result variable")
                    break

                if not has_next:
                    logger.info(f"No more pages after page {current_page}")
                    break

                current_page += 1

            except Exception as e:
                logger.warning(f"Pagination failed: {e}")
                break
        else:
            logger.info("No pagination code provided, done scraping")
            break

    logger.info(f"Scraped {len(all_users)} total users across {current_page} pages")
    return all_users


def execute_add_user_plan(
    driver: uc.Chrome,
    plan: AddUserPlan,
    email: str,
    role: str | None = None,
    connection_default_url: str = "",
) -> dict[str, Any]:
    """Execute an AddUserPlan to add/invite a user.

    Returns:
        {"success": true} or {"success": false, "error": "..."}
    """
    try:
        start_url = plan.start_url_template.format(connection={"default_url": connection_default_url})
        logger.info(f"Navigating to {start_url}")
        driver.get(start_url)
        time.sleep(2)

        if plan.add_button_selector:
            logger.info("Clicking add button to open form")
            add_button = WebDriverWait(driver, 10).until(
                expected_conditions.element_to_be_clickable((By.CSS_SELECTOR, plan.add_button_selector))
            )
            add_button.click()
            time.sleep(1)

        logger.info(f"Filling email: {email}")
        email_input = WebDriverWait(driver, 10).until(
            expected_conditions.presence_of_element_located((By.CSS_SELECTOR, plan.email_input_selector))
        )
        email_input.clear()
        email_input.send_keys(email)

        if role and plan.role_selector:
            logger.info(f"Selecting role: {role}")
            role_dropdown = driver.find_element(By.CSS_SELECTOR, plan.role_selector)
            role_dropdown.click()
            time.sleep(0.5)
            role_option = driver.find_element(By.XPATH, f"//option[contains(text(), '{role}')]")
            role_option.click()

        logger.info("Clicking submit button")
        submit_button = WebDriverWait(driver, 10).until(
            expected_conditions.element_to_be_clickable((By.CSS_SELECTOR, plan.submit_button_selector))
        )
        submit_button.click()

        time.sleep(plan.wait_after_submit_seconds)

        if plan.success_indicator_selector:
            try:
                success_elem = driver.find_element(By.CSS_SELECTOR, plan.success_indicator_selector)
                success_text = success_elem.text.strip()

                if plan.success_text_contains:
                    if plan.success_text_contains.lower() not in success_text.lower():
                        return {
                            "success": False,
                            "error": f"Success indicator found but text doesn't match: {success_text}",
                        }

                logger.info(f"User added successfully: {email}")
                return {"success": True}

            except NoSuchElementException:
                if plan.error_indicator_selector:
                    try:
                        error_elem = driver.find_element(By.CSS_SELECTOR, plan.error_indicator_selector)
                        error_text = error_elem.text.strip()
                        return {"success": False, "error": error_text}
                    except NoSuchElementException:
                        pass

                return {
                    "success": False,
                    "error": "Success indicator not found after submit",
                }

        logger.info(f"User added (no verification configured): {email}")
        return {"success": True}

    except TimeoutException as e:
        return {"success": False, "error": f"Timeout waiting for element: {e}"}
    except NoSuchElementException as e:
        return {"success": False, "error": f"Element not found: {e}"}
    except Exception as e:
        logger.exception(f"Failed to add user: {e}")
        return {"success": False, "error": str(e)}


def execute_remove_user_plan(
    driver: uc.Chrome,
    plan: RemoveUserPlan,
    email: str,
    connection_default_url: str = "",
) -> dict[str, Any]:
    """Execute a RemoveUserPlan to remove/delete a user.

    Returns:
        {"success": true} or {"success": false, "error": "..."}
    """
    try:
        start_url = plan.start_url_template.format(connection={"default_url": connection_default_url})
        logger.info(f"Navigating to {start_url}")
        driver.get(start_url)
        time.sleep(2)

        max_pages = 10
        current_page = 0

        while current_page < max_pages:
            current_page += 1
            logger.info(f"Searching for user {email} on page {current_page}")

            try:
                rows = driver.find_elements(By.CSS_SELECTOR, plan.row_selector)
            except NoSuchElementException:
                return {
                    "success": False,
                    "error": f"User rows not found with selector: {plan.row_selector}",
                }

            user_row = None
            for row in rows:
                try:
                    email_elem = row.find_element(By.CSS_SELECTOR, plan.email_selector)
                    if email_elem.text.strip().lower() == email.lower():
                        user_row = row
                        break
                except NoSuchElementException:
                    continue

            if user_row:
                logger.info(f"Found user {email}, clicking delete button")

                delete_button = user_row.find_element(By.CSS_SELECTOR, plan.delete_button_selector)
                delete_button.click()
                time.sleep(1)

                if plan.has_confirmation_modal:
                    if not plan.confirm_button_selector:
                        return {
                            "success": False,
                            "error": "Confirmation modal enabled but no confirm button selector",
                        }

                    logger.info("Confirming deletion in modal")
                    confirm_button = WebDriverWait(driver, 5).until(
                        expected_conditions.element_to_be_clickable((By.CSS_SELECTOR, plan.confirm_button_selector))
                    )
                    confirm_button.click()

                time.sleep(plan.wait_after_delete_seconds)

                if plan.success_indicator_selector:
                    try:
                        driver.find_element(By.CSS_SELECTOR, plan.success_indicator_selector)
                        logger.info(f"User removed successfully: {email}")
                        return {"success": True}
                    except NoSuchElementException:
                        return {
                            "success": False,
                            "error": "Success indicator not found after deletion",
                        }

                logger.info(f"User removed (no verification configured): {email}")
                return {"success": True}

            if plan.pagination and plan.pagination.has_pagination:
                if not plan.pagination.next_button_selector:
                    break

                try:
                    next_button = driver.find_element(By.CSS_SELECTOR, plan.pagination.next_button_selector)

                    disabled_attr = plan.pagination.disabled_attribute or "disabled"
                    if next_button.get_attribute(disabled_attr) is not None:
                        break

                    next_button.click()
                    time.sleep(2)

                except NoSuchElementException:
                    break
            else:
                break

        return {
            "success": False,
            "error": f"User with email {email} not found in list",
        }

    except TimeoutException as e:
        return {"success": False, "error": f"Timeout waiting for element: {e}"}
    except NoSuchElementException as e:
        return {"success": False, "error": f"Element not found: {e}"}
    except Exception as e:
        logger.exception(f"Failed to remove user: {e}")
        return {"success": False, "error": str(e)}
