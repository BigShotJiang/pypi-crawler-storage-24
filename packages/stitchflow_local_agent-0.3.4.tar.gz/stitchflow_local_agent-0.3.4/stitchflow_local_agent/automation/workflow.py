"""Workflow abstraction: executable code with runtime access to browser and context."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from selenium.webdriver.chrome.webdriver import WebDriver

    from stitchflow_local_agent.common.browser import BrowserManager


@dataclass
class ConnectionInfo:
    """Minimal connection metadata needed by workflows."""

    default_url: str
    integration_key: str


@dataclass
class WorkflowContext:
    """Context for workflow execution.

    Simplified from browser-api's version: no domain aggregates,
    just the driver and connection metadata.
    """

    connection_info: ConnectionInfo
    driver: WebDriver
    browser: BrowserManager | None = None
    artifact_dir: Path | None = None


@dataclass
class WorkflowResult:
    """Result of workflow execution.

    Attributes:
        success: Whether workflow completed successfully
        output: Structured output matching operation's output_schema
        error: Error message if workflow failed
    """

    success: bool
    output: dict[str, Any]
    error: str | None = None


IWorkflow = Callable[[WorkflowContext, Any], Awaitable[WorkflowResult]]
