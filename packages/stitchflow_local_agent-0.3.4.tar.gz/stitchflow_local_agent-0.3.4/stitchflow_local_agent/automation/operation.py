"""Operation: Defines a business capability with its workflow implementation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pydantic import BaseModel

    from stitchflow_local_agent.automation.workflow import IWorkflow


@dataclass(frozen=True)
class Operation:
    """Defines a business capability (e.g., 'openai_delete_user').

    Attributes:
        operation_key: Unique identifier (e.g., 'openai_get_users', 'calendly_remove_user')
        workflow: Executable workflow function that implements this operation
        input_params_schema: Pydantic model for input parameters
        expected_output_schema: Pydantic model for output data
    """

    operation_key: str
    workflow: IWorkflow
    input_params_schema: type[BaseModel] | None = None
    expected_output_schema: type[BaseModel] | None = None


OPERATION_REGISTRY: dict[str, Operation] = {}


def register_operation(operation: Operation) -> None:
    """Register an operation in the global registry."""
    if operation.operation_key in OPERATION_REGISTRY:
        return

    OPERATION_REGISTRY[operation.operation_key] = operation


def clear_registry() -> None:
    """Clear all registered operations. Used primarily for testing."""
    OPERATION_REGISTRY.clear()


def get_operation(operation_key: str) -> Operation:
    """Get operation by key.

    Raises:
        KeyError: If operation not found
    """
    if operation_key not in OPERATION_REGISTRY:
        raise KeyError(f"Operation not found: {operation_key}")

    return OPERATION_REGISTRY[operation_key]
