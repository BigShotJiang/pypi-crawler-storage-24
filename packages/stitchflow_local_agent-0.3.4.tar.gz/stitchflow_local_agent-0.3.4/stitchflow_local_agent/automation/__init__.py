from stitchflow_local_agent.automation.operation import (
    OPERATION_REGISTRY,
    Operation,
    clear_registry,
    get_operation,
    register_operation,
)
from stitchflow_local_agent.automation.workflow import ConnectionInfo, IWorkflow, WorkflowContext, WorkflowResult

__all__ = [
    "ConnectionInfo",
    "IWorkflow",
    "OPERATION_REGISTRY",
    "Operation",
    "WorkflowContext",
    "WorkflowResult",
    "clear_registry",
    "get_operation",
    "register_operation",
]
