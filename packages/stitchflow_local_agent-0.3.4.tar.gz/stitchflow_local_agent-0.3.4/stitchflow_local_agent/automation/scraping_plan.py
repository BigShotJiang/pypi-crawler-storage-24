"""Generic operation plan schemas for all integrations.

Every integration needs 3 operations: get_users, add_user, remove_user.
Each operation has an action plan that defines the selectors and steps to execute.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class PaginationConfig(BaseModel):
    """Pagination configuration for multi-page scraping."""

    has_pagination: bool = Field(description="Whether pagination exists")
    next_button_selector: str | None = Field(default=None, description="CSS selector for next page button")
    disabled_attribute: str | None = Field(
        default="disabled", description="Attribute that indicates button is disabled"
    )
    page_count_selector: str | None = Field(default=None, description="CSS selector for total page count text")


class GetUsersPlan(BaseModel):
    """Scraping plan for get_users operation (READ).

    Defines how to extract user data from a list/table page with pagination.
    Uses a two-phase approach: extract raw text, then parse with Python strings.
    """

    operation_type: str = Field(default="get_users", description="Operation type identifier")

    start_url_template: str = Field(description="URL template with placeholders like {connection.default_url}")

    extraction_code: str = Field(
        description="Python code to extract raw TEXT from page (not WebElements). "
        "Available variables: 'driver' (undetected_chromedriver.Chrome instance), 'By'. "
        "Should assign result to 'rows' variable as list of text arrays. "
        "Example: rows = [[cell.text for cell in row.find_elements(By.TAG_NAME, 'td')] "
        "for row in driver.find_elements(By.CSS_SELECTOR, 'table tbody tr')]"
    )

    parsing_code: str = Field(
        description="Python code to parse text arrays into user dictionaries. "
        "Should define a function 'parse_user(cell_texts: list[str]) -> dict' that returns "
        "{'name': str, 'email': str, 'role': str, 'added_date': str | None}. "
        "Parameter 'cell_texts' is a list of strings (one per table cell). "
        "Use built-in Python string functions: strip(), split(), replace(), splitlines(), etc."
    )

    pagination_code: str | None = Field(
        default=None,
        description="Python code to navigate to next page/scroll. "
        "Available variables: 'driver' (undetected_chromedriver.Chrome instance), 'By', 'time'. "
        "Should assign result to 'has_next' or 'result' variable (True if more pages, False if done).",
    )

    notes: str = Field(default="", description="Additional notes about the page structure")


class AddUserPlan(BaseModel):
    """Action plan for add_user operation (CREATE).

    Defines the steps to add/invite a user. No data extraction needed.
    Output: {"success": true} or {"success": false, "error": "..."}
    """

    operation_type: str = Field(default="add_user", description="Operation type identifier")

    start_url_template: str = Field(description="Starting URL")
    add_button_selector: str | None = Field(
        default=None, description="CSS selector for button to open add/invite form (if separate modal/page)"
    )

    email_input_selector: str = Field(description="CSS selector for email input field")
    role_selector: str | None = Field(default=None, description="CSS selector for role dropdown (optional)")
    submit_button_selector: str = Field(description="CSS selector for submit/invite button")

    success_indicator_selector: str | None = Field(
        default=None, description="CSS selector for success message or confirmation"
    )
    success_text_contains: str | None = Field(default=None, description="Text that should appear in success message")

    error_indicator_selector: str | None = Field(default=None, description="CSS selector for error message")

    wait_after_submit_seconds: int = Field(default=2, description="Seconds to wait after submit")

    notes: str = Field(default="", description="Additional notes")


class RemoveUserPlan(BaseModel):
    """Action plan for remove_user operation (DELETE).

    Defines how to find a user by email and remove them.
    Output: {"success": true} or {"success": false, "error": "..."}
    """

    operation_type: str = Field(default="remove_user", description="Operation type identifier")

    start_url_template: str = Field(description="Starting URL (usually users list page)")

    row_selector: str = Field(description="CSS selector for user rows")
    email_selector: str = Field(description="CSS selector for email field within row")
    delete_button_selector: str = Field(description="CSS selector for delete/remove button within row")

    has_confirmation_modal: bool = Field(default=True, description="Whether delete requires confirmation")
    confirmation_modal_selector: str | None = Field(default=None, description="CSS selector for confirmation modal")
    confirm_button_selector: str | None = Field(default=None, description="CSS selector for confirm button in modal")

    success_indicator_selector: str | None = Field(default=None, description="CSS selector for success message")

    pagination: PaginationConfig | None = Field(
        default=None, description="Pagination config if need to search across pages"
    )

    wait_after_delete_seconds: int = Field(default=2, description="Seconds to wait after deletion")

    notes: str = Field(default="", description="Additional notes")
