"""Browser lifecycle management using undetected-chromedriver.

Manages a single Chrome instance with a shared persistent profile.
Replaces the agent-browser npm CLI subprocess approach.
"""

from __future__ import annotations

import logging
import sys
import time
from pathlib import Path
from typing import Any

if sys.version_info >= (3, 14):
    raise RuntimeError(
        "stitchflow-local-agent does not support Python 3.14+ yet because "
        "undetected-chromedriver depends on distutils. Please use Python 3.11-3.13."
    )

import undetected_chromedriver as uc
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.keys import Keys

logger = logging.getLogger(__name__)

_CHROME_PATHS = (
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/usr/bin/google-chrome",
    "/usr/bin/google-chrome-stable",
)


def _detect_chrome_version() -> int | None:
    """Return the major version of the locally installed Chrome, or None."""
    import subprocess

    for path in _CHROME_PATHS:
        try:
            out = subprocess.check_output([path, "--version"], stderr=subprocess.DEVNULL, text=True)
            # "Google Chrome 145.0.7632.160" -> 145
            for token in out.strip().split():
                if "." in token:
                    return int(token.split(".")[0])
        except Exception:
            continue
    return None


AUTOMATION_LOCK_ELEMENT_ID = "stitchflow-automation-lock-overlay"

CLOUDFLARE_MARKERS = (
    "verify you are human",
    "just a moment",
    "enable javascript and cookies",
    "checking your browser",
    "challenges.cloudflare.com",
    "cf-challenge",
    "page crashed",
)

OPENAI_RENDER_SELECTORS = (
    "input[placeholder='Filter by name']",
    "button",
    "[role='row']",
    "table tbody tr",
)

_LOCK_INJECT_JS = (
    """
(() => {
    const id = '%s';
    if (document.getElementById(id)) return 'already_locked';
    const overlay = document.createElement('div');
    overlay.id = id;
    overlay.style.position = 'fixed';
    overlay.style.inset = '0';
    overlay.style.zIndex = '2147483647';
    overlay.style.background = 'rgba(0, 0, 0, 0.12)';
    overlay.style.display = 'flex';
    overlay.style.alignItems = 'flex-start';
    overlay.style.justifyContent = 'center';
    overlay.style.paddingTop = '12px';
    // Keep this overlay non-blocking so WebDriver clicks are not intercepted.
    overlay.style.pointerEvents = 'none';
    overlay.style.cursor = 'default';
    overlay.innerHTML = "<div style='background:#111827;color:#fff;padding:8px 12px;border-radius:8px;" +
        "font:600 12px/1.3 -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;opacity:.95;'>" +
        "Stitchflow automation in progress</div>";
    document.body.appendChild(overlay);
    return 'locked';
})()
"""
    % AUTOMATION_LOCK_ELEMENT_ID
)

_LOCK_REMOVE_JS = (
    """
(() => {
    const overlay = document.getElementById('%s');
    if (overlay) overlay.remove();
    if (window.__stitchflowLockKeyHandler) {
        document.removeEventListener('keydown', window.__stitchflowLockKeyHandler, true);
        delete window.__stitchflowLockKeyHandler;
    }
    return 'unlocked';
})()
"""
    % AUTOMATION_LOCK_ELEMENT_ID
)


class BrowserManager:
    """Manages Chrome browser lifecycle with persistent local profiles."""

    def __init__(self) -> None:
        self._driver: uc.Chrome | None = None
        self._current_integration: str | None = None

    @property
    def driver(self) -> uc.Chrome:
        if self._driver is None:
            raise RuntimeError("Browser not initialized. Call initialize() first.")
        return self._driver

    @property
    def is_alive(self) -> bool:
        if self._driver is None:
            return False
        try:
            _ = self._driver.current_url
            return True
        except Exception:
            return False

    def initialize(
        self,
        integration: str,
        profile_dir: str | Path,
        headless: bool = False,
        download_dir: str | Path | None = None,
    ) -> uc.Chrome:
        """Launch Chrome with a persistent profile for the given integration.

        Args:
            integration: Integration key (e.g. 'openai', 'calendly') for logging.
            profile_dir: Path to the Chrome user data directory.
            headless: Run headless (default False -- user sees the browser).
            download_dir: Optional directory for browser downloads.

        Returns:
            The undetected-chromedriver Chrome instance.
        """
        if self._driver is not None:
            if self._current_integration == integration and self.is_alive:
                logger.info(f"Reusing existing browser session for {integration}")
                return self._driver
            self.shutdown()

        profile_path = Path(profile_dir).resolve()
        profile_path.mkdir(parents=True, exist_ok=True)

        options = uc.ChromeOptions()
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--no-first-run")
        options.add_argument("--no-default-browser-check")
        options.add_argument("--profile-directory=Default")

        if download_dir:
            dl_path = str(Path(download_dir).resolve())
            prefs = {
                "download.default_directory": dl_path,
                "download.prompt_for_download": False,
                "download.directory_upgrade": True,
            }
            options.add_experimental_option("prefs", prefs)

        version_main = _detect_chrome_version()
        logger.info(
            f"Launching Chrome for {integration} (profile: {profile_path}, headless={headless}, version={version_main})"
        )
        self._driver = uc.Chrome(
            options=options,
            headless=headless,
            version_main=version_main,
            user_data_dir=str(profile_path),
        )
        self._current_integration = integration
        return self._driver

    def shutdown(self) -> None:
        """Quit the browser and clean up."""
        if self._driver is not None:
            try:
                self._driver.quit()
            except Exception as e:
                logger.warning(f"Error shutting down browser: {e}")
            finally:
                self._driver = None
                self._current_integration = None

    def set_interaction_lock(self, enabled: bool) -> None:
        """Inject or remove the UI lock overlay to prevent user interference."""
        if self._driver is None:
            return
        try:
            if enabled:
                self._driver.execute_script(_LOCK_INJECT_JS)
            else:
                self._driver.execute_script(_LOCK_REMOVE_JS)
        except WebDriverException as e:
            logger.warning(f"Failed to {'set' if enabled else 'remove'} interaction lock: {e}")

    def cleanup_stale_overlay(self) -> None:
        """Remove leftover lock overlay from a previous session."""
        if self._driver is None:
            return
        try:
            result = self._driver.execute_script(
                f"(() => {{ const el = document.getElementById('{AUTOMATION_LOCK_ELEMENT_ID}'); "
                f"if (el) {{ el.remove(); return 'cleaned'; }} return 'none'; }})()"
            )
            if result == "cleaned":
                logger.info("Removed stale automation overlay from previous session")
        except WebDriverException:
            pass

    def capture_screenshot(self, path: str | Path) -> bool:
        """Save a screenshot of the current page."""
        if self._driver is None:
            return False
        try:
            self._driver.save_screenshot(str(path))
            return True
        except WebDriverException as e:
            logger.warning(f"Screenshot failed: {e}")
            return False

    def is_cloudflare_challenge(self) -> bool:
        """Check whether the current page is a Cloudflare interstitial."""
        if self._driver is None:
            return False
        try:
            page_text = self._driver.page_source.lower()
            return any(marker in page_text for marker in CLOUDFLARE_MARKERS)
        except WebDriverException:
            return False

    def wait_for_cloudflare(self, max_wait: int = 30) -> bool:
        """Wait for a Cloudflare challenge to clear, polling every 2 seconds.

        Returns True if the challenge cleared, False if it's still present.
        """
        elapsed = 0
        while elapsed < max_wait:
            if not self.is_cloudflare_challenge():
                return True
            time.sleep(2)
            elapsed += 2
        return False

    def wait_for_any_selector(self, selectors: tuple[str, ...], max_wait: int = 30) -> bool:
        """Wait until at least one selector resolves to a displayed element."""
        if self._driver is None:
            return False
        if not selectors:
            return True

        deadline = time.time() + max_wait
        while time.time() < deadline:
            for selector in selectors:
                try:
                    elements = self._driver.find_elements("css selector", selector)
                    if any(elem.is_displayed() for elem in elements):
                        return True
                except Exception:
                    continue
            time.sleep(0.5)
        return False

    def _is_interactable(self, element: Any) -> bool:
        """Return True when element appears visible and actionable."""
        try:
            if not (element.is_displayed() and element.is_enabled()):
                return False
            rect = element.rect or {}
            if rect.get("width", 0) <= 0 or rect.get("height", 0) <= 0:
                return False
            return True
        except Exception:
            return False

    def wait_for_interactable(
        self,
        selectors: tuple[str, ...],
        max_wait: int = 20,
    ) -> Any | None:
        """Wait for the first interactable element matching any selector."""
        if self._driver is None:
            return None
        if not selectors:
            return None

        deadline = time.time() + max_wait
        while time.time() < deadline:
            for selector in selectors:
                try:
                    elements = self._driver.find_elements("css selector", selector)
                except Exception:
                    continue

                for element in elements:
                    if not self._is_interactable(element):
                        continue
                    try:
                        self._driver.execute_script(
                            "arguments[0].scrollIntoView({block:'center',inline:'nearest'});",
                            element,
                        )
                    except Exception:
                        pass
                    if self._is_interactable(element):
                        return element
            time.sleep(0.25)
        return None

    def set_input_value(
        self,
        selectors: tuple[str, ...],
        value: str,
        max_wait: int = 20,
    ) -> bool:
        """Reliably focus, clear, and type into an input across dynamic UIs."""
        if self._driver is None:
            return False

        element = self.wait_for_interactable(selectors, max_wait=max_wait)
        if element is None:
            return False

        try:
            element.click()
        except Exception:
            try:
                self._driver.execute_script("arguments[0].focus();", element)
            except Exception:
                pass

        typed = False
        for modifier in (Keys.COMMAND, Keys.CONTROL):
            try:
                element.send_keys(modifier, "a")
                element.send_keys(Keys.BACKSPACE)
                element.send_keys(value)
                typed = True
                break
            except Exception:
                continue

        if typed:
            return True

        try:
            self._driver.execute_script(
                """
                const el = arguments[0];
                const val = arguments[1];
                el.focus();
                el.value = val;
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
                """,
                element,
                value,
            )
            return True
        except Exception:
            return False

    def wait_for_interactable_in_container(
        self,
        container: Any,
        selectors: tuple[str, ...],
        max_wait: int = 30,
    ) -> Any | None:
        """Wait for an interactable element inside a container (e.g. table row)."""
        if self._driver is None:
            return None
        if container is None or not selectors:
            return None

        deadline = time.time() + max_wait
        while time.time() < deadline:
            for selector in selectors:
                try:
                    elements = container.find_elements("css selector", selector)
                except Exception:
                    continue

                for element in elements:
                    if not self._is_interactable(element):
                        continue
                    try:
                        self._driver.execute_script(
                            "arguments[0].scrollIntoView({block:'center',inline:'nearest'});",
                            element,
                        )
                    except Exception:
                        pass
                    if self._is_interactable(element):
                        return element
            time.sleep(0.25)
        return None

    def wait_for_openai_render(self, max_wait: int = 15) -> bool:
        """Wait for OpenAI/ChatGPT workspace UI to render after navigation."""
        return self.wait_for_any_selector(OPENAI_RENDER_SELECTORS, max_wait=max_wait)

    def navigate_and_wait(
        self,
        url: str,
        ready_selector: str | None = None,
        max_wait: int = 30,
    ) -> None:
        """Navigate to a URL and wait until the page is fully interactive.

        1. Navigates to the URL (skips if already there).
        2. Waits for Cloudflare challenges to clear.
        3. Waits for document.readyState == 'complete'.
        4. If ready_selector is given, waits for that element to appear.
        """
        if self._driver is None:
            raise RuntimeError("Browser not initialized.")

        current = self._driver.current_url or ""
        if not current.startswith(url.rstrip("/")):
            self._driver.get(url)

        self.wait_for_cloudflare(max_wait=max_wait)

        from selenium.webdriver.support.ui import WebDriverWait

        WebDriverWait(self._driver, max_wait).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )

        time.sleep(1)

        if ready_selector:
            from selenium.webdriver.common.by import By
            from selenium.webdriver.support import expected_conditions

            WebDriverWait(self._driver, max_wait).until(
                expected_conditions.presence_of_element_located((By.CSS_SELECTOR, ready_selector))
            )

        current_url = (self._driver.current_url or "").lower()
        if "chatgpt.com" in current_url or "openai.com" in current_url:
            rendered = self.wait_for_openai_render(max_wait=min(max_wait, 15))
            if not rendered:
                logger.warning("OpenAI page did not reach rendered state before timeout")


