"""Shared configuration: env loading, paths, constants."""

from __future__ import annotations

import json
import os
import pathlib
import platform
import shutil

try:
    import keyring
except ImportError:
    keyring = None  # type: ignore[assignment]


LOCAL_ENV_FILE = pathlib.Path.home() / ".stitchflow" / "agent.env"
STITCHFLOW_HOME_DIR = pathlib.Path.home() / ".stitchflow"
BROWSER_PROFILE_DIR = STITCHFLOW_HOME_DIR / "browser-profile"
ARTIFACTS_DIR = STITCHFLOW_HOME_DIR / "artifacts"
LOGS_DIR = STITCHFLOW_HOME_DIR / "logs"
DATA_SYNC_DIR = STITCHFLOW_HOME_DIR / "data-sync"
CONNECTIONS_FILE = STITCHFLOW_HOME_DIR / "connections.json"

_OLD_PROFILES_DIR = STITCHFLOW_HOME_DIR / "profiles"

KEYRING_SERVICE_NAME = "stitchflow-local-agent"

# Firestore integration keys may differ from operation key prefixes.
# This maps Firestore keys to the canonical names used in operation keys.
INTEGRATION_KEY_ALIASES: dict[str, str] = {
    "chatgpt": "openai",
}

INTEGRATION_LOGIN_URLS: dict[str, str] = {
    "openai": "https://chatgpt.com/admin/members",
    "calendly": "https://calendly.com/app/admin/users",
}


def normalize_integration_key(key: str) -> str:
    """Map a Firestore integration key to its canonical operation/profile name."""
    return INTEGRATION_KEY_ALIASES.get(key, key)


API_URL = ""
API_KEY = ""
WORKSPACE_ID = ""
MACHINE_ID = ""

HEARTBEAT_INTERVAL_SECONDS = 30
POLL_INTERVAL_SECONDS = 60
POLL_MAX_IDLE_SECONDS = 900
POLL_MAX_ERROR_SECONDS = 300

SYNC_INTERVAL_SECONDS = 600
CHATGPT_ACCOUNT_ID = ""

_CONFIG_LOADED = False


def _load_persisted_env() -> None:
    """Load persisted agent env values into process env if missing."""
    if not LOCAL_ENV_FILE.exists():
        return
    try:
        for raw_line in LOCAL_ENV_FILE.read_text().splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[len("export ") :]
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value
    except Exception as exc:
        print(f"WARNING: Could not load persisted env file: {exc}")


def _safe_int_env(key: str, default: int) -> int:
    raw = os.environ.get(key, "")
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        print(f"WARNING: Invalid integer for {key}={raw!r}, using default {default}")
        return default


def _get_api_key_from_keyring(workspace_id: str) -> str:
    if not workspace_id or keyring is None:
        return ""
    try:
        return keyring.get_password(KEYRING_SERVICE_NAME, workspace_id) or ""
    except Exception:
        return ""


def _set_api_key_in_keyring(workspace_id: str, api_key: str) -> bool:
    if not workspace_id or keyring is None:
        return False
    try:
        keyring.set_password(KEYRING_SERVICE_NAME, workspace_id, api_key)
        return True
    except Exception as exc:
        print(f"WARNING: Failed to store API key in system keychain: {exc}")
        return False


def init_config() -> None:
    """Load persisted env and populate module-level config variables."""
    global API_URL, API_KEY, WORKSPACE_ID, MACHINE_ID
    global POLL_INTERVAL_SECONDS, POLL_MAX_IDLE_SECONDS, POLL_MAX_ERROR_SECONDS
    global SYNC_INTERVAL_SECONDS, CHATGPT_ACCOUNT_ID, _CONFIG_LOADED

    if _CONFIG_LOADED:
        return
    _CONFIG_LOADED = True

    _load_persisted_env()

    API_URL = os.environ.get("STITCHFLOW_API_URL", "http://localhost:3030")
    API_KEY = os.environ.get("STITCHFLOW_API_KEY", "")
    WORKSPACE_ID = os.environ.get("STITCHFLOW_WORKSPACE_ID", "")
    if not API_KEY and WORKSPACE_ID:
        API_KEY = _get_api_key_from_keyring(WORKSPACE_ID)

    POLL_INTERVAL_SECONDS = _safe_int_env("STITCHFLOW_AGENT_POLL_INTERVAL_SECONDS", 60)
    POLL_MAX_IDLE_SECONDS = _safe_int_env("STITCHFLOW_AGENT_POLL_MAX_IDLE_SECONDS", 900)
    POLL_MAX_ERROR_SECONDS = _safe_int_env("STITCHFLOW_AGENT_POLL_MAX_ERROR_SECONDS", 300)
    SYNC_INTERVAL_SECONDS = _safe_int_env("STITCHFLOW_SYNC_INTERVAL_SECONDS", 86400)
    CHATGPT_ACCOUNT_ID = os.environ.get("CHATGPT_ACCOUNT_ID", "")
    MACHINE_ID = f"{platform.node()}-{os.getpid()}"


def command_exists(name: str) -> bool:
    return shutil.which(name) is not None


def _migrate_old_profiles() -> None:
    """One-time migration: move the best old per-integration profile to the new shared location."""
    if BROWSER_PROFILE_DIR.exists() or not _OLD_PROFILES_DIR.exists():
        return

    candidates = [
        d for d in _OLD_PROFILES_DIR.iterdir()
        if d.is_dir() and (d / "Default").is_dir()
    ]
    if not candidates:
        return

    best = max(candidates, key=lambda d: d.stat().st_mtime)
    try:
        shutil.copytree(str(best), str(BROWSER_PROFILE_DIR))
        print(f"Migrated browser profile from {best} to {BROWSER_PROFILE_DIR}")
        print("  You may need to re-run 'stitchflow-agent login' or 'stitchflow-sync setup' if sessions are stale.")
    except Exception as exc:
        print(f"WARNING: Could not migrate old profile: {exc}")


def ensure_dirs() -> None:
    """Create standard directories if they don't exist."""
    for d in [STITCHFLOW_HOME_DIR, BROWSER_PROFILE_DIR, ARTIFACTS_DIR, LOGS_DIR, DATA_SYNC_DIR]:
        d.mkdir(parents=True, exist_ok=True)
    _migrate_old_profiles()


def load_connections() -> list[dict]:
    """Load saved connections from ~/.stitchflow/connections.json."""
    if not CONNECTIONS_FILE.exists():
        return []
    try:
        return json.loads(CONNECTIONS_FILE.read_text())
    except Exception:
        return []


def save_connections(connections: list[dict]) -> None:
    """Save connections to ~/.stitchflow/connections.json."""
    CONNECTIONS_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONNECTIONS_FILE.write_text(json.dumps(connections, indent=2))


def get_connection_ids() -> list[str]:
    """Return the list of connection IDs from saved connections."""
    return [c["connection_id"] for c in load_connections() if "connection_id" in c]


def get_connection_metadata() -> dict[str, dict]:
    """Return a map of connection_id -> metadata for dispatching."""
    result = {}
    for c in load_connections():
        cid = c.get("connection_id")
        if cid:
            result[cid] = {
                "integration_key": c.get("integration_key", ""),
                "default_url": c.get("default_url", ""),
                "name": c.get("name", ""),
            }
    return result


def persist_agent_env(
    api_url: str,
    workspace_id: str,
    api_key: str = "",
) -> None:
    """Persist agent config to ~/.stitchflow/agent.env for future runs."""
    LOCAL_ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        f'export STITCHFLOW_API_URL="{api_url}"',
        f'export STITCHFLOW_WORKSPACE_ID="{workspace_id}"',
    ]
    if api_key:
        lines.insert(1, f'export STITCHFLOW_API_KEY="{api_key}"')
    LOCAL_ENV_FILE.write_text("\n".join(lines) + "\n")
    os.chmod(LOCAL_ENV_FILE, 0o600)


def configure_agent_env_interactive() -> tuple[str, str, str]:
    """Collect setup values from user and persist them locally.

    Returns:
        (api_url, api_key, workspace_id)
    """
    global API_URL, API_KEY, WORKSPACE_ID

    print("Configure Stitchflow agent:")
    api_url_input = input(f"  STITCHFLOW_API_URL [{API_URL}]: ").strip()
    api_url = api_url_input or API_URL

    workspace_default = WORKSPACE_ID or ""
    while True:
        prompt = (
            f"  STITCHFLOW_WORKSPACE_ID [{workspace_default}]: "
            if workspace_default
            else "  STITCHFLOW_WORKSPACE_ID [required]: "
        )
        workspace_id_input = input(prompt).strip()
        workspace_id = workspace_id_input or workspace_default
        if workspace_id:
            break
        print("  STITCHFLOW_WORKSPACE_ID is required.")

    key_prompt = "  STITCHFLOW_API_KEY [stored securely in Keychain/DPAPI; leave blank to keep current]: "
    if not keyring:
        key_prompt = "  STITCHFLOW_API_KEY [optional; keyring unavailable so this stays in env only]: "
    api_key_input = input(key_prompt).strip()
    api_key = api_key_input

    API_URL = api_url
    WORKSPACE_ID = workspace_id

    if api_key:
        if _set_api_key_in_keyring(WORKSPACE_ID, api_key):
            print("Saved API key to system keychain.")
    API_KEY = api_key or _get_api_key_from_keyring(WORKSPACE_ID)

    os.environ["STITCHFLOW_API_URL"] = API_URL
    os.environ["STITCHFLOW_API_KEY"] = API_KEY
    os.environ["STITCHFLOW_WORKSPACE_ID"] = WORKSPACE_ID

    fallback_api_key = API_KEY if not keyring else ""
    persist_agent_env(API_URL, WORKSPACE_ID, api_key=fallback_api_key)
    print(f"Saved setup config to: {LOCAL_ENV_FILE}")
    if keyring and not API_KEY:
        print("No API key set. If required, re-run setup to save one to keychain.")
    elif not keyring and API_KEY:
        print("WARNING: keyring not available; API key was saved in ~/.stitchflow/agent.env.")
    return API_URL, API_KEY, WORKSPACE_ID
