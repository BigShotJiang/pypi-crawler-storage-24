"""PID file management, signal handling, background daemon launch."""

from __future__ import annotations

import os
import pathlib
import subprocess
import sys

from stitchflow_local_agent.common import config


def acquire_pid_file(pid_path: pathlib.Path) -> bool:
    """Write current PID to file. Returns False if another daemon is running."""
    if pid_path.exists():
        try:
            old_pid = int(pid_path.read_text().strip())
            try:
                os.kill(old_pid, 0)
                print(f"ERROR: Daemon already running (pid {old_pid}). Remove {pid_path} to override.")
                return False
            except OSError:
                pass
        except (ValueError, OSError):
            pass
    pid_path.parent.mkdir(parents=True, exist_ok=True)
    pid_path.write_text(str(os.getpid()))
    return True


def release_pid_file(pid_path: pathlib.Path) -> None:
    try:
        if pid_path.exists():
            stored_pid = int(pid_path.read_text().strip())
            if stored_pid == os.getpid():
                pid_path.unlink()
    except (ValueError, OSError):
        pass


def start_daemon_background(
    module_path: str,
    log_filename: str,
    daemon_args: list[str] | None = None,
) -> bool:
    """Start a daemon as a detached background process.

    *module_path*: path to the Python file to run (e.g. ``__file__``).
    *log_filename*: filename for the log file inside ``~/.stitchflow/logs/``.
    """
    config.LOGS_DIR.mkdir(parents=True, exist_ok=True)
    log_path = config.LOGS_DIR / log_filename

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    script_path = pathlib.Path(module_path).resolve()
    cmd = [sys.executable, "-u", str(script_path), "daemon"]
    if daemon_args:
        cmd.extend(daemon_args)

    try:
        with open(log_path, "a") as log_file:
            subprocess.Popen(
                cmd,
                stdout=log_file,
                stderr=log_file,
                env=env,
                start_new_session=True,
            )
        print(f"Daemon started in background. Logs: {log_path}")
        return True
    except Exception as exc:
        print(f"ERROR: Failed to start daemon in background: {exc}")
        return False
