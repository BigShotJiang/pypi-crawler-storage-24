"""Generic JSONL logging helpers."""

from __future__ import annotations

import json
import pathlib
from typing import Any


def append_jsonl(path: pathlib.Path, entry: dict[str, Any]) -> None:
    """Append a single JSON object as one line to the given file."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=True) + "\n")
    except Exception as exc:
        print(f"WARNING: Failed to append to {path.name}: {exc}")
