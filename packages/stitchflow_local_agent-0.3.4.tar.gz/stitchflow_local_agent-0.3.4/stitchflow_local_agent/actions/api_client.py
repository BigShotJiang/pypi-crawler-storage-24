"""Stitchflow API client for OperationRun polling, claiming, and reporting."""

from __future__ import annotations

import asyncio
from typing import Any

import httpx

from stitchflow_local_agent.common import config


class StitchflowAPIClient:
    MAX_RETRIES = 3
    RETRY_BACKOFF_SECONDS = [0, 1, 2]

    def __init__(self, base_url: str, api_key: str, workspace_id: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.workspace_id = workspace_id
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._client = httpx.AsyncClient(headers=headers, timeout=30)

    async def aclose(self) -> None:
        await self._client.aclose()

    async def _request_with_retry(
        self,
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        last_exc: Exception | None = None
        for attempt in range(self.MAX_RETRIES):
            try:
                resp = await self._client.request(method, url, **kwargs)
                resp.raise_for_status()
                return resp
            except (httpx.ConnectError, httpx.TimeoutException, httpx.RemoteProtocolError) as exc:
                last_exc = exc
                if attempt < self.MAX_RETRIES - 1:
                    delay = self.RETRY_BACKOFF_SECONDS[min(attempt, len(self.RETRY_BACKOFF_SECONDS) - 1)]
                    print(f"  ! API request failed (attempt {attempt + 1}): {exc}, retrying in {delay}s")
                    await asyncio.sleep(delay)
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code >= 500 and attempt < self.MAX_RETRIES - 1:
                    last_exc = exc
                    delay = self.RETRY_BACKOFF_SECONDS[min(attempt, len(self.RETRY_BACKOFF_SECONDS) - 1)]
                    print(f"  ! API {exc.response.status_code} (attempt {attempt + 1}), retrying in {delay}s")
                    await asyncio.sleep(delay)
                else:
                    raise
        raise last_exc  # type: ignore[misc]

    async def get_connections(self) -> list[dict[str, Any]]:
        """Fetch browser-managed connections for the workspace."""
        resp = await self._request_with_retry(
            "GET",
            f"{self.base_url}/agent-browser/operations/connections",
            params={"workspace_id": self.workspace_id},
        )
        return resp.json()

    async def get_pending_operations(self) -> list[dict[str, Any]]:
        """Poll for pending OperationRuns across all workspace connections."""
        resp = await self._request_with_retry(
            "GET",
            f"{self.base_url}/agent-browser/operations/pending",
            params={"workspace_id": self.workspace_id},
        )
        return resp.json()

    async def claim_operation(self, operation_run_id: str) -> dict[str, Any]:
        resp = await self._request_with_retry(
            "POST",
            f"{self.base_url}/agent-browser/operations/{operation_run_id}/claim",
            json={"worker_id": config.MACHINE_ID},
        )
        return resp.json()

    async def complete_operation(self, operation_run_id: str, output: dict[str, Any]) -> dict[str, Any]:
        resp = await self._request_with_retry(
            "POST",
            f"{self.base_url}/agent-browser/operations/{operation_run_id}/complete",
            json={"output": output},
        )
        return resp.json()

    async def fail_operation(self, operation_run_id: str, error: str) -> dict[str, Any]:
        resp = await self._request_with_retry(
            "POST",
            f"{self.base_url}/agent-browser/operations/{operation_run_id}/fail",
            json={"error": error},
        )
        return resp.json()

    async def send_heartbeat(self, operation_run_id: str) -> None:
        await self._request_with_retry(
            "POST",
            f"{self.base_url}/agent-browser/operations/{operation_run_id}/heartbeat",
        )


async def heartbeat_loop(api: StitchflowAPIClient, operation_run_id: str, stop_event: asyncio.Event) -> None:
    while not stop_event.is_set():
        try:
            await api.send_heartbeat(operation_run_id)
        except Exception as exc:
            print(f"  ! Heartbeat failed: {exc}")
        await asyncio.sleep(config.HEARTBEAT_INTERVAL_SECONDS)
