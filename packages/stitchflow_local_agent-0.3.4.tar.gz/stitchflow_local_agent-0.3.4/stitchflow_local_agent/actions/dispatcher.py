"""Task dispatcher: poll, claim, and route operations via the operation registry."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from stitchflow_local_agent.actions.api_client import (
    StitchflowAPIClient,
    heartbeat_loop,
)
from stitchflow_local_agent.automation.operation import get_operation
from stitchflow_local_agent.automation.workflow import ConnectionInfo, WorkflowContext, WorkflowResult
from stitchflow_local_agent.common.browser import BrowserManager
from stitchflow_local_agent.common import config

logger = logging.getLogger(__name__)
AUDIT_LOG_PATH = config.LOGS_DIR / "audit.log"
ARTIFACTS_DIR = config.ARTIFACTS_DIR
ARTIFACT_RETENTION_DAYS = 30

AUTH_PAGE_MARKERS: dict[str, list[str]] = {
    "openai": ["auth0.openai.com", "login.chatgpt.com", "/auth/login", "Log in to ChatGPT"],
    "calendly": ["auth.calendly.com", "login", "Sign in"],
}

DESTRUCTIVE_OPERATIONS = {"openai_delete_user", "calendly_remove_user"}


def _integration_from_operation_key(operation_key: str) -> str:
    """Extract integration name from operation_key (e.g. 'openai_get_users' -> 'openai')."""
    return operation_key.split("_")[0]


def _check_auth(driver: Any, integration: str) -> str | None:
    """Return an error message if the browser landed on a login page, else None."""
    markers = AUTH_PAGE_MARKERS.get(integration, [])
    if not markers:
        return None
    try:
        current_url = driver.current_url or ""
        page_source = driver.page_source or ""
    except Exception:
        return None

    url_lower = current_url.lower()
    source_lower = page_source.lower()
    for marker in markers:
        if marker.lower() in url_lower or marker.lower() in source_lower:
            return (
                f"Not authenticated to {integration}. "
                f"Browser is on login page: {current_url}\n"
                f"  Run 'stitchflow-agent login' to authenticate first."
            )
    return None


def _artifact_dir_for_operation(op_run_id: str) -> Path:
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    d = ARTIFACTS_DIR / f"{ts}_{op_run_id}"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _write_audit_entry(entry: dict[str, Any]) -> None:
    AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(AUDIT_LOG_PATH, "a") as f:
        f.write(json.dumps(entry, default=str) + "\n")


def _cleanup_old_artifacts() -> None:
    if not ARTIFACTS_DIR.exists():
        return
    cutoff = time.time() - (ARTIFACT_RETENTION_DAYS * 86400)
    for d in ARTIFACTS_DIR.iterdir():
        if d.is_dir() and d.stat().st_mtime < cutoff:
            try:
                import shutil

                shutil.rmtree(d)
                logger.info(f"Cleaned up old artifact: {d.name}")
            except Exception:
                pass


async def process_pending_operations(
    api: StitchflowAPIClient,
    connection_metadata: dict[str, dict[str, Any]],
) -> dict[str, int]:
    """Poll for pending operations, execute them, and report results.

    Args:
        api: The API client for polling/reporting.
        connection_metadata: Map of connection_id -> {integration_key, default_url, name}.

    Returns:
        Summary dict with total, completed, failed counts.
    """
    print("Fetching pending operations...")
    try:
        operations = await api.get_pending_operations()
    except Exception as exc:
        print(f"ERROR: Failed to fetch operations: {exc}")
        return {"total": 0, "completed": 0, "failed": 1}

    if not operations:
        print("No pending operations.")
        return {"total": 0, "completed": 0, "failed": 0}

    print(f"Found {len(operations)} operation(s)")
    completed = 0
    failed = 0

    _cleanup_old_artifacts()

    browser_mgr = BrowserManager()

    try:
        for idx, op_run in enumerate(operations, 1):
            op_run_id = op_run["id"]
            operation_key = op_run.get("operation_type", op_run.get("operation_key", "unknown"))
            params = op_run.get("params", {})
            conn_id = op_run.get("connection_id", "")

            integration = _integration_from_operation_key(operation_key)
            conn_meta = connection_metadata.get(conn_id, {})
            default_url = conn_meta.get("default_url", "") or config.INTEGRATION_LOGIN_URLS.get(integration, "")

            is_destructive = operation_key in DESTRUCTIVE_OPERATIONS
            artifact_dir = _artifact_dir_for_operation(op_run_id) if is_destructive else None
            started_at = datetime.now(timezone.utc)

            print(f"--- Operation {idx}/{len(operations)}: {operation_key} (connection: {conn_id}) ---")

            try:
                operation = get_operation(operation_key)
            except KeyError:
                print(f"  x Unknown operation: {operation_key}")
                try:
                    await api.fail_operation(op_run_id, f"Unknown operation: {operation_key}")
                except Exception:
                    pass
                failed += 1
                continue

            try:
                await api.claim_operation(op_run_id)
            except Exception as exc:
                print(f"  x Claim failed: {exc}")
                failed += 1
                continue

            stop_event = asyncio.Event()
            hb_task = asyncio.create_task(heartbeat_loop(api, op_run_id, stop_event))

            result_status = "FAILED"
            result_error: str | None = None

            try:
                driver = browser_mgr.initialize(integration, config.BROWSER_PROFILE_DIR)
                browser_mgr.cleanup_stale_overlay()

                if default_url:
                    browser_mgr.navigate_and_wait(default_url)
                    auth_err = _check_auth(driver, integration)
                    if auth_err:
                        raise RuntimeError(auth_err)

                browser_mgr.set_interaction_lock(True)

                if artifact_dir and is_destructive:
                    browser_mgr.capture_screenshot(str(artifact_dir / "before.png"))
                    print(f"  Screenshot saved: {artifact_dir / 'before.png'}")

                context = WorkflowContext(
                    connection_info=ConnectionInfo(
                        default_url=default_url,
                        integration_key=integration,
                    ),
                    driver=driver,
                    browser=browser_mgr,
                    artifact_dir=artifact_dir,
                )

                validated_params = None
                if operation.input_params_schema and params:
                    validated_params = operation.input_params_schema.model_validate(params)

                result: WorkflowResult = await operation.workflow(context, validated_params)

                if result.success:
                    if artifact_dir and is_destructive:
                        time.sleep(2)
                        browser_mgr.capture_screenshot(str(artifact_dir / "after.png"))
                        print(f"  Screenshot saved: {artifact_dir / 'after.png'}")

                    await api.complete_operation(op_run_id, result.output)
                    completed += 1
                    result_status = "COMPLETED"
                    print(f"  OK: {operation_key} completed successfully")
                else:
                    result_error = result.error or "Workflow returned success=False"
                    await api.fail_operation(op_run_id, result_error)
                    failed += 1
                    print(f"  x {operation_key}: {result_error}")

            except Exception as exc:
                failed += 1
                result_error = str(exc)
                try:
                    await api.fail_operation(op_run_id, result_error)
                except Exception:
                    pass
                if artifact_dir:
                    browser_mgr.capture_screenshot(str(artifact_dir / "error.png"))
                print(f"  x {operation_key}: exception {exc}")
            finally:
                browser_mgr.set_interaction_lock(False)
                stop_event.set()
                hb_task.cancel()
                try:
                    await hb_task
                except asyncio.CancelledError:
                    pass

                _write_audit_entry(
                    {
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "operation_run_id": op_run_id,
                        "operation_key": operation_key,
                        "connection_id": conn_id,
                        "integration": integration,
                        "params": params,
                        "status": result_status,
                        "error": result_error,
                        "duration_seconds": round((datetime.now(timezone.utc) - started_at).total_seconds(), 1),
                        "artifacts": str(artifact_dir) if artifact_dir else None,
                    }
                )
    finally:
        browser_mgr.shutdown()

    print(f"Summary: {completed} completed, {failed} failed")
    return {"total": len(operations), "completed": completed, "failed": failed}
