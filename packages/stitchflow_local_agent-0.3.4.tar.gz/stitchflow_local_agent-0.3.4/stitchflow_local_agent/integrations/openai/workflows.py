"""OpenAI/ChatGPT workflows - plan-based execution without LLM calls."""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING

from selenium.common.exceptions import StaleElementReferenceException
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.ui import WebDriverWait

from stitchflow_local_agent.automation.plan_executor import execute_get_users_plan
from stitchflow_local_agent.automation.scraping_plan import AddUserPlan, GetUsersPlan, RemoveUserPlan
from stitchflow_local_agent.integrations.openai.schemas import (
    OpenAIAddUserFields,
    OpenAIAddUserResult,
    OpenAIRemoveUserFields,
    OpenAIRemoveUserResult,
    OpenAIUser,
    OpenAIUserList,
)

if TYPE_CHECKING:
    from stitchflow_local_agent.automation.workflow import WorkflowContext, WorkflowResult

logger = logging.getLogger(__name__)

GET_USERS_PLAN_PATH = Path(__file__).parent / "plans" / "get_users.json"
CREATE_USER_PLAN_PATH = Path(__file__).parent / "plans" / "create_user.json"
DELETE_USER_PLAN_PATH = Path(__file__).parent / "plans" / "delete_user.json"


async def openai_get_users_workflow(
    workflow_context: WorkflowContext,
    params: None = None,
) -> WorkflowResult:
    """Get all OpenAI users by executing pre-generated code-based plan.

    Zero LLM costs at runtime - plan was generated once offline.
    """
    from stitchflow_local_agent.automation.workflow import WorkflowResult

    driver = workflow_context.driver
    connection_info = workflow_context.connection_info

    try:
        if not GET_USERS_PLAN_PATH.exists():
            return WorkflowResult(
                success=False,
                output={},
                error=f"Operation plan not found: {GET_USERS_PLAN_PATH}.",
            )

        logger.info(f"Loading operation plan from {GET_USERS_PLAN_PATH}")
        with open(GET_USERS_PLAN_PATH) as f:
            plan_data = json.load(f)

        plan = GetUsersPlan.model_validate(plan_data)
        logger.info(f"Loaded {plan.operation_type} plan")

        users_data = execute_get_users_plan(
            driver=driver,
            plan=plan,
            connection_default_url=connection_info.default_url,
        )

        users = [OpenAIUser.model_validate(user) for user in users_data]

        output = OpenAIUserList(
            users=users,
            total_pages=1,
            total_users=len(users),
        )

        logger.info(f"Successfully scraped {len(users)} users")

        return WorkflowResult(
            success=True,
            output=output.model_dump(),
        )

    except Exception as e:
        logger.exception(f"Failed to execute get_users plan: {e}")
        return WorkflowResult(
            success=False,
            output={},
            error=f"Failed to scrape users: {str(e)}",
        )


async def openai_create_user_workflow(
    workflow_context: WorkflowContext,
    params: OpenAIAddUserFields,
) -> WorkflowResult:
    """Create/invite a user in OpenAI using pre-generated action plan.

    Uses custom logic for OpenAI's react-select email input
    (requires pressing Enter after typing).
    """
    from stitchflow_local_agent.automation.workflow import WorkflowResult

    driver = workflow_context.driver
    connection_info = workflow_context.connection_info

    try:
        if not CREATE_USER_PLAN_PATH.exists():
            return WorkflowResult(
                success=False,
                output={},
                error=f"Operation plan not found: {CREATE_USER_PLAN_PATH}.",
            )

        logger.info(f"Loading operation plan from {CREATE_USER_PLAN_PATH}")
        with open(CREATE_USER_PLAN_PATH) as f:
            plan_data = json.load(f)

        plan = AddUserPlan.model_validate(plan_data)
        logger.info(f"Loaded {plan.operation_type} plan")

        start_url = connection_info.default_url

        logger.info(f"Navigating to {start_url}")
        if workflow_context.browser:
            workflow_context.browser.navigate_and_wait(start_url)
        else:
            driver.get(start_url)
            time.sleep(5)

        if plan.add_button_selector:
            logger.info("Clicking Invite member button")
            invite_buttons = driver.find_elements(By.CSS_SELECTOR, plan.add_button_selector)
            invite_button = None
            for btn in invite_buttons:
                if "Invite member" in btn.text:
                    invite_button = btn
                    break

            if not invite_button:
                return WorkflowResult(
                    success=False,
                    output=OpenAIAddUserResult(success=False, error="Invite member button not found").model_dump(),
                    error="Invite member button not found",
                )

            invite_button.click()
            time.sleep(2)

        logger.info(f"Typing email: {params.email}")
        email_input = WebDriverWait(driver, 10).until(
            expected_conditions.presence_of_element_located((By.CSS_SELECTOR, plan.email_input_selector))
        )
        email_input.clear()
        email_input.send_keys(params.email)
        time.sleep(0.5)

        logger.info("Pressing Enter to add email to selection")
        email_input.send_keys(Keys.RETURN)
        time.sleep(1)

        logger.info("Clicking Next button")
        next_buttons = driver.find_elements(By.CSS_SELECTOR, plan.submit_button_selector)
        next_button = None
        for btn in next_buttons:
            if "Next" in btn.text and not btn.get_attribute("disabled"):
                next_button = btn
                break

        if not next_button:
            return WorkflowResult(
                success=False,
                output=OpenAIAddUserResult(success=False, error="Next button not found or disabled").model_dump(),
                error="Next button not found or disabled",
            )

        next_button.click()
        time.sleep(plan.wait_after_submit_seconds)

        output = OpenAIAddUserResult(success=True, error=None)
        logger.info(f"User {params.email} invited successfully")

        return WorkflowResult(
            success=True,
            output=output.model_dump(),
        )

    except Exception as e:
        logger.exception(f"Failed to create user: {e}")
        output = OpenAIAddUserResult(success=False, error=str(e))
        return WorkflowResult(
            success=False,
            output=output.model_dump(),
            error=f"Failed to invite user: {str(e)}",
        )


async def openai_delete_user_workflow(
    workflow_context: WorkflowContext,
    params: OpenAIRemoveUserFields,
) -> WorkflowResult:
    """Delete/remove a user in OpenAI using pre-generated action plan.

    Steps:
    1. Load saved operation plan from delete_user_plan.json
    2. Use "Filter by name" search to find user by email
    3. Find matching user row
    4. Click three-dot menu button
    5. Click "Remove member" option
    """
    from stitchflow_local_agent.automation.workflow import WorkflowResult

    driver = workflow_context.driver
    connection_info = workflow_context.connection_info

    try:
        if not DELETE_USER_PLAN_PATH.exists():
            return WorkflowResult(
                success=False,
                output={},
                error=f"Operation plan not found: {DELETE_USER_PLAN_PATH}.",
            )

        logger.info(f"Loading operation plan from {DELETE_USER_PLAN_PATH}")
        with open(DELETE_USER_PLAN_PATH) as f:
            plan_data = json.load(f)

        plan = RemoveUserPlan.model_validate(plan_data)
        logger.info(f"Loaded {plan.operation_type} plan")

        start_url = connection_info.default_url
        ready_sel = "input[placeholder='Filter by name']"

        logger.info(f"Navigating to {start_url}")
        if workflow_context.browser:
            workflow_context.browser.navigate_and_wait(start_url, ready_selector=ready_sel)
        else:
            driver.get(start_url)
            WebDriverWait(driver, 30).until(
                expected_conditions.presence_of_element_located((By.CSS_SELECTOR, ready_sel))
            )

        logger.info(f"Searching for user: {params.email}")
        if workflow_context.browser:
            ok = workflow_context.browser.set_input_value((ready_sel, "input[type='search']"), params.email)
            if not ok:
                raise RuntimeError("OpenAI search input was not interactable")
        else:
            search_input = driver.find_element(By.CSS_SELECTOR, ready_sel)
            search_input.clear()
            search_input.send_keys(params.email)
        time.sleep(0.5)

        logger.info("Looking for matching user row")
        user_row = None

        def _find_matching_row() -> bool:
            nonlocal user_row
            rows = driver.find_elements(By.CSS_SELECTOR, plan.row_selector)
            for row in rows:
                try:
                    email_elems = row.find_elements(By.CSS_SELECTOR, plan.email_selector)
                    for elem in email_elems:
                        if params.email.lower() in elem.text.lower():
                            user_row = row
                            return True
                except Exception:
                    continue
            return False

        def _has_matching_row() -> bool:
            rows = driver.find_elements(By.CSS_SELECTOR, plan.row_selector)
            for row in rows:
                try:
                    email_elems = row.find_elements(By.CSS_SELECTOR, plan.email_selector)
                    for elem in email_elems:
                        if params.email.lower() in elem.text.lower():
                            return True
                except Exception:
                    continue
            return False

        try:
            WebDriverWait(driver, 15, poll_frequency=0.5).until(lambda _d: _find_matching_row())
        except Exception:
            user_row = None

        if not user_row:
            return WorkflowResult(
                success=False,
                output=OpenAIRemoveUserResult(
                    success=False, error=f"User with email {params.email} not found"
                ).model_dump(),
                error=f"User with email {params.email} not found",
            )

        if workflow_context.browser and workflow_context.artifact_dir:
            workflow_context.browser.capture_screenshot(str(workflow_context.artifact_dir / "before.png"))

        logger.info(f"Found user {params.email}, clicking menu button")
        menu_selectors = (
            plan.delete_button_selector,
            "button[aria-haspopup='menu']",
            "button[id^='radix-'][aria-haspopup='menu']",
            "button[aria-expanded='false']",
        )

        def _find_menu_button_in_row() -> object | None:
            nonlocal user_row
            if user_row is None:
                return None

            try:
                driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", user_row)
            except Exception:
                pass

            try:
                ActionChains(driver).move_to_element(user_row).pause(0.1).perform()
            except Exception:
                pass

            candidates = []
            for selector in menu_selectors:
                try:
                    candidates.extend(user_row.find_elements(By.CSS_SELECTOR, selector))
                except Exception:
                    continue

            if not candidates:
                try:
                    candidates = user_row.find_elements(By.TAG_NAME, "button")
                except Exception:
                    candidates = []

            for btn in candidates:
                try:
                    if not (btn.is_displayed() and btn.is_enabled()):
                        continue
                    aria_has_popup = (btn.get_attribute("aria-haspopup") or "").lower()
                    aria_label = (btn.get_attribute("aria-label") or "").lower()
                    text = (btn.text or "").lower()
                    if aria_has_popup == "menu" or "more" in aria_label or "menu" in aria_label or "more" in text:
                        return btn
                except StaleElementReferenceException:
                    continue
                except Exception:
                    continue

            return None

        menu_button = None
        deadline = time.time() + 15
        while time.time() < deadline and menu_button is None:
            menu_button = _find_menu_button_in_row()
            if menu_button:
                break
            _find_matching_row()
            time.sleep(0.4)

        if not menu_button:
            return WorkflowResult(
                success=False,
                output=OpenAIRemoveUserResult(
                    success=False,
                    error=(
                        "User row rendered but action menu button not found. "
                        f"Tried selectors: {', '.join(menu_selectors)}"
                    ),
                ).model_dump(),
                error="Action menu button not found for matching user row",
            )

        try:
            menu_button.click()
        except Exception:
            menu_button = _find_menu_button_in_row()
            if not menu_button:
                raise
            driver.execute_script("arguments[0].click();", menu_button)
        time.sleep(1)

        logger.info("Clicking Remove member option from dropdown")
        if not plan.confirm_button_selector:
            return WorkflowResult(
                success=False,
                output=OpenAIRemoveUserResult(success=False, error="No confirm button selector in plan").model_dump(),
                error="No confirm button selector in plan",
            )

        remove_option = WebDriverWait(driver, 5).until(
            expected_conditions.element_to_be_clickable((By.CSS_SELECTOR, plan.confirm_button_selector))
        )
        remove_option.click()
        time.sleep(1)

        logger.info("Clicking Delete in confirmation modal")
        delete_btn = None
        buttons = WebDriverWait(driver, 5).until(lambda d: d.find_elements(By.TAG_NAME, "button"))
        for btn in buttons:
            try:
                if btn.text.strip() == "Delete" and btn.is_displayed():
                    delete_btn = btn
                    break
            except Exception:
                continue

        if not delete_btn:
            return WorkflowResult(
                success=False,
                output=OpenAIRemoveUserResult(
                    success=False, error="Delete confirmation button not found in modal"
                ).model_dump(),
                error="Delete confirmation button not found in modal",
            )

        delete_btn.click()
        try:
            WebDriverWait(driver, 15, poll_frequency=0.5).until(lambda _d: not _has_matching_row())
        except Exception:
            logger.warning("User row still visible after delete attempt; capturing screenshot anyway")

        time.sleep(plan.wait_after_delete_seconds)

        if workflow_context.browser and workflow_context.artifact_dir:
            workflow_context.browser.capture_screenshot(str(workflow_context.artifact_dir / "after.png"))

        output = OpenAIRemoveUserResult(success=True, error=None)
        logger.info(f"User {params.email} removed successfully")

        return WorkflowResult(
            success=True,
            output=output.model_dump(),
        )

    except Exception as e:
        logger.exception(f"Failed to delete user: {e}")
        output = OpenAIRemoveUserResult(success=False, error=str(e))
        return WorkflowResult(
            success=False,
            output=output.model_dump(),
            error=f"Failed to remove user: {str(e)}",
        )
