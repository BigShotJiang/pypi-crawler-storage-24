"""OpenAI/ChatGPT resource schemas and parameter models."""

from pydantic import BaseModel, Field


class OpenAIUser(BaseModel):
    """Schema for an OpenAI/ChatGPT user resource."""

    name: str = Field(description="Full name of the user")
    email: str = Field(description="Email address of the user")
    role: str = Field(description="Role/permission level (e.g., Owner, Member)")
    added_date: str | None = Field(default=None, description="Date user was added (if visible)")


class OpenAIUserList(BaseModel):
    """Schema for a list of OpenAI users."""

    users: list[OpenAIUser] = Field(description="List of all users from all pages")
    total_pages: int = Field(description="Total number of pages scraped")
    total_users: int = Field(description="Total number of users found")


class OpenAIGetUsersFields(BaseModel):
    """Fields required to get list of users in OpenAI. No parameters required."""

    pass


class OpenAIAddUserFields(BaseModel):
    """Fields required to add/invite a user in OpenAI."""

    email: str = Field(description="Email address of user to invite")
    role: str | None = Field(default=None, description="Role to assign (e.g., Member, Admin)")


class OpenAIAddUserResult(BaseModel):
    """Result of adding a user in OpenAI."""

    success: bool = Field(description="Whether the user was added successfully")
    error: str | None = Field(default=None, description="Error message if operation failed")


class OpenAIRemoveUserFields(BaseModel):
    """Fields required to remove a user in OpenAI."""

    email: str = Field(description="Email address of user to remove")


class OpenAIRemoveUserResult(BaseModel):
    """Result of removing a user in OpenAI."""

    success: bool = Field(description="Whether the user was removed successfully")
    error: str | None = Field(default=None, description="Error message if operation failed")
