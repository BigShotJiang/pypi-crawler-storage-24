"""Register OpenAI operations in the global registry."""

from stitchflow_local_agent.automation.operation import Operation, register_operation
from stitchflow_local_agent.integrations.openai.schemas import (
    OpenAIAddUserFields,
    OpenAIAddUserResult,
    OpenAIGetUsersFields,
    OpenAIRemoveUserFields,
    OpenAIRemoveUserResult,
    OpenAIUserList,
)
from stitchflow_local_agent.integrations.openai.workflows import (
    openai_create_user_workflow,
    openai_delete_user_workflow,
    openai_get_users_workflow,
)

OPENAI_GET_USERS_OPERATION = Operation(
    operation_key="openai_get_users",
    workflow=openai_get_users_workflow,
    input_params_schema=OpenAIGetUsersFields,
    expected_output_schema=OpenAIUserList,
)

OPENAI_CREATE_USER_OPERATION = Operation(
    operation_key="openai_create_user",
    workflow=openai_create_user_workflow,
    input_params_schema=OpenAIAddUserFields,
    expected_output_schema=OpenAIAddUserResult,
)

OPENAI_DELETE_USER_OPERATION = Operation(
    operation_key="openai_delete_user",
    workflow=openai_delete_user_workflow,
    input_params_schema=OpenAIRemoveUserFields,
    expected_output_schema=OpenAIRemoveUserResult,
)


def register_openai_operations() -> None:
    """Register all OpenAI operations."""
    register_operation(OPENAI_GET_USERS_OPERATION)
    register_operation(OPENAI_CREATE_USER_OPERATION)
    register_operation(OPENAI_DELETE_USER_OPERATION)
