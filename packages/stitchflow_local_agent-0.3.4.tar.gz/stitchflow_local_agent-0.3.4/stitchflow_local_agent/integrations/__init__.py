from stitchflow_local_agent.integrations.calendly.register import register_calendly_operations
from stitchflow_local_agent.integrations.openai.register import register_openai_operations


def register_all_operations() -> None:
    """Register all integration operations. Call once at agent startup."""
    register_openai_operations()
    register_calendly_operations()
