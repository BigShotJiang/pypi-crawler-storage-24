"""Calendly workflows - Selenium-based execution without LLM calls."""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING

from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.ui import WebDriverWait

from stitchflow_local_agent.integrations.calendly.schemas import (
    CalendlyChangeRoleFields,
    CalendlyChangeRoleResult,
    CalendlyRemoveUserFields,
    CalendlyRemoveUserResult,
)

if TYPE_CHECKING:
    from stitchflow_local_agent.automation.workflow import (
        WorkflowContext,
        WorkflowResult,
    )

logger = logging.getLogger(__name__)

REMOVE_USER_PLAN_PATH = Path(__file__).parent / "plans" / "remove_user.json"
CHANGE_ROLE_PLAN_PATH = Path(__file__).parent / "plans" / "change_role.json"
MENU_RENDER_WAIT_SECONDS = 60


def _load_plan(plan_path: Path) -> dict:
    with open(plan_path) as f:
        return json.load(f)


def _find_user_row(driver, rows, email: str) -> object | None:
    """Iterate rows looking for one that contains the target email text."""
    for row in rows:
        try:
            if email.lower() in row.text.lower():
                return row
        except Exception:
            continue
    return None


def _wait_for_user_row(driver, row_selector: str, email: str, timeout: int = 30) -> object | None:
    """Wait until the searched user row is rendered in the table."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        rows = driver.find_elements(By.CSS_SELECTOR, row_selector)
        user_row = _find_user_row(driver, rows, email)
        if user_row:
            return user_row
        time.sleep(0.4)
    return None


def _find_menu_button_fallback(user_row) -> object | None:
    """Fallback row scan for kebab menu buttons when selector is unstable."""
    candidates = []
    for selector in (
        "button[aria-haspopup='menu']",
        "button[id^='radix-'][aria-haspopup='menu']",
        "button[aria-expanded='false']",
        "button",
    ):
        try:
            candidates.extend(user_row.find_elements(By.CSS_SELECTOR, selector))
        except Exception:
            continue

    for btn in candidates:
        try:
            text = (btn.text or "").lower()
            aria_label = (btn.get_attribute("aria-label") or "").lower()
            aria_has_popup = (btn.get_attribute("aria-haspopup") or "").lower()
            if aria_has_popup == "menu" or "more" in aria_label or "menu" in aria_label or "..." in text:
                return btn
        except Exception:
            continue
    return None


def _find_clickable_text_element(elements: list[object], text: str) -> object | None:
    """Find a displayed element whose text matches target text."""
    target = text.strip().lower()
    for element in elements:
        try:
            if not element.is_displayed():
                continue
            value = (element.text or "").strip().lower()
            if value == target:
                return element
        except Exception:
            continue
    for element in elements:
        try:
            if not element.is_displayed():
                continue
            value = (element.text or "").strip().lower()
            if target in value:
                return element
        except Exception:
            continue
    return None


async def calendly_remove_user_workflow(
    workflow_context: WorkflowContext,
    params: CalendlyRemoveUserFields,
) -> WorkflowResult:
    """Remove a user from Calendly via the admin UI.

    Steps:
    1. Navigate to the Calendly admin users page
    2. Search for the user by email
    3. Click the kebab menu on the matching row
    4. Select "Remove" from the dropdown
    5. Confirm removal in the dialog
    6. Verify user is no longer listed
    """
    from stitchflow_local_agent.automation.workflow import WorkflowResult

    driver = workflow_context.driver
    connection_info = workflow_context.connection_info

    try:
        if not REMOVE_USER_PLAN_PATH.exists():
            return WorkflowResult(
                success=False,
                output={},
                error=f"Operation plan not found: {REMOVE_USER_PLAN_PATH}.",
            )

        plan = _load_plan(REMOVE_USER_PLAN_PATH)
        logger.info(f"Loaded {plan['operation_type']} plan")

        start_url = connection_info.default_url
        logger.info(f"Navigating to {start_url}")
        if workflow_context.browser:
            workflow_context.browser.navigate_and_wait(
                start_url,
                ready_selector="input[placeholder*='Search']",
            )
        else:
            driver.get(start_url)
            time.sleep(3)

        logger.info(f"Searching for user: {params.email}")
        if workflow_context.browser:
            ok = workflow_context.browser.set_input_value(
                ("input[placeholder*='Search']", "input[type='search']"),
                params.email,
            )
            if not ok:
                raise RuntimeError("Calendly search input was not interactable")
        else:
            search_input = WebDriverWait(driver, 10).until(
                expected_conditions.presence_of_element_located((By.CSS_SELECTOR, "input[placeholder*='Search']"))
            )
            search_input.clear()
            search_input.send_keys(params.email)
        time.sleep(2)

        logger.info("Looking for matching user row")
        user_row = _wait_for_user_row(driver, plan["row_selector"], params.email, timeout=30)

        if not user_row:
            output = CalendlyRemoveUserResult(success=False, error=f"User with email {params.email} not found")
            return WorkflowResult(
                success=False,
                output=output.model_dump(),
                error=output.error,
            )

        logger.info(f"Found user {params.email}, clicking kebab menu")
        menu_btn = None
        if workflow_context.browser:
            menu_btn = workflow_context.browser.wait_for_interactable_in_container(
                user_row,
                (
                    plan["delete_button_selector"],
                    "button[aria-haspopup='menu']",
                    "button[id^='radix-'][aria-haspopup='menu']",
                    "button[aria-expanded='false']",
                ),
                max_wait=MENU_RENDER_WAIT_SECONDS,
            )
        else:
            try:
                menu_btn = user_row.find_element(By.CSS_SELECTOR, plan["delete_button_selector"])
            except Exception:
                menu_btn = None

        if not menu_btn:
            menu_btn = _find_menu_button_fallback(user_row)
        if not menu_btn:
            raise RuntimeError("Calendly row menu button did not render in time")
        try:
            menu_btn.click()
        except Exception:
            driver.execute_script("arguments[0].click()", menu_btn)
        time.sleep(1)

        logger.info("Clicking 'Remove' menu item")
        menu_items = WebDriverWait(driver, 5).until(
            expected_conditions.presence_of_all_elements_located(
                (By.CSS_SELECTOR, "[role='menuitem'], [role='option'], li")
            )
        )
        remove_item = None
        for item in menu_items:
            if "Remove" in item.text and "Change" not in item.text:
                remove_item = item
                break

        if not remove_item:
            output = CalendlyRemoveUserResult(success=False, error="'Remove' menu item not found in dropdown")
            return WorkflowResult(
                success=False,
                output=output.model_dump(),
                error=output.error,
            )

        remove_item.click()
        time.sleep(1)

        if plan.get("has_confirmation_modal"):
            logger.info("Waiting for confirmation dialog")
            dialog = WebDriverWait(driver, 5).until(
                expected_conditions.presence_of_element_located((By.CSS_SELECTOR, plan["confirmation_modal_selector"]))
            )

            confirm_buttons = dialog.find_elements(By.CSS_SELECTOR, "button")
            confirm_btn = None
            for btn in confirm_buttons:
                if "Remove" in btn.text:
                    confirm_btn = btn
                    break

            if not confirm_btn:
                output = CalendlyRemoveUserResult(success=False, error="Confirm 'Remove' button not found in dialog")
                return WorkflowResult(
                    success=False,
                    output=output.model_dump(),
                    error=output.error,
                )

            logger.info("Clicking confirm 'Remove' button")
            confirm_btn.click()
            time.sleep(plan.get("wait_after_delete_seconds", 3))

        logger.info("Verifying user was removed")
        if workflow_context.browser:
            ok = workflow_context.browser.set_input_value(
                ("input[placeholder*='Search']", "input[type='search']"),
                params.email,
            )
            if not ok:
                raise RuntimeError("Calendly search input was not interactable during verification")
        else:
            search_input = WebDriverWait(driver, 10).until(
                expected_conditions.presence_of_element_located((By.CSS_SELECTOR, "input[placeholder*='Search']"))
            )
            search_input.clear()
            search_input.send_keys(params.email)
        time.sleep(2)

        rows = driver.find_elements(By.CSS_SELECTOR, plan["row_selector"])
        remaining = _find_user_row(driver, rows, params.email)

        if remaining:
            output = CalendlyRemoveUserResult(success=False, error=f"User {params.email} still appears after removal")
            return WorkflowResult(
                success=False,
                output=output.model_dump(),
                error=output.error,
            )

        output = CalendlyRemoveUserResult(success=True, error=None)
        logger.info(f"User {params.email} removed successfully")
        return WorkflowResult(success=True, output=output.model_dump())

    except Exception as e:
        logger.exception(f"Failed to remove user: {e}")
        output = CalendlyRemoveUserResult(success=False, error=str(e))
        return WorkflowResult(
            success=False,
            output=output.model_dump(),
            error=f"Failed to remove user: {e!s}",
        )


async def calendly_change_role_workflow(
    workflow_context: WorkflowContext,
    params: CalendlyChangeRoleFields,
) -> WorkflowResult:
    """Change a user's role in Calendly via the admin UI.

    Steps:
    1. Navigate to the Calendly admin users page
    2. Search for the user by email
    3. Click the kebab menu on the matching row
    4. Select "Change Role" from the dropdown
    5. Pick the target role in the dialog
    6. Click "Apply"
    7. Verify the change
    """
    from stitchflow_local_agent.automation.workflow import WorkflowResult

    driver = workflow_context.driver
    connection_info = workflow_context.connection_info

    try:
        if not CHANGE_ROLE_PLAN_PATH.exists():
            return WorkflowResult(
                success=False,
                output={},
                error=f"Operation plan not found: {CHANGE_ROLE_PLAN_PATH}.",
            )

        plan = _load_plan(CHANGE_ROLE_PLAN_PATH)
        logger.info(f"Loaded {plan['operation_type']} plan")

        start_url = connection_info.default_url
        logger.info(f"Navigating to {start_url}")
        if workflow_context.browser:
            workflow_context.browser.navigate_and_wait(
                start_url,
                ready_selector="input[placeholder*='Search']",
            )
        else:
            driver.get(start_url)
            time.sleep(3)

        logger.info(f"Searching for user: {params.email}")
        if workflow_context.browser:
            ok = workflow_context.browser.set_input_value(
                ("input[placeholder*='Search']", "input[type='search']"),
                params.email,
            )
            if not ok:
                raise RuntimeError("Calendly search input was not interactable")
        else:
            search_input = WebDriverWait(driver, 10).until(
                expected_conditions.presence_of_element_located((By.CSS_SELECTOR, "input[placeholder*='Search']"))
            )
            search_input.clear()
            search_input.send_keys(params.email)
        time.sleep(2)

        logger.info("Looking for matching user row")
        user_row = _wait_for_user_row(driver, plan["row_selector"], params.email, timeout=30)

        if not user_row:
            output = CalendlyChangeRoleResult(success=False, error=f"User with email {params.email} not found")
            return WorkflowResult(
                success=False,
                output=output.model_dump(),
                error=output.error,
            )

        logger.info(f"Found user {params.email}, clicking kebab menu")
        menu_btn = None
        if workflow_context.browser:
            menu_btn = workflow_context.browser.wait_for_interactable_in_container(
                user_row,
                (
                    plan["menu_button_selector"],
                    "button[aria-haspopup='menu']",
                    "button[id^='radix-'][aria-haspopup='menu']",
                    "button[aria-expanded='false']",
                ),
                max_wait=MENU_RENDER_WAIT_SECONDS,
            )
        else:
            try:
                menu_btn = user_row.find_element(By.CSS_SELECTOR, plan["menu_button_selector"])
            except Exception:
                menu_btn = None

        if not menu_btn:
            menu_btn = _find_menu_button_fallback(user_row)
        if not menu_btn:
            raise RuntimeError("Calendly row menu button did not render in time")
        try:
            menu_btn.click()
        except Exception:
            driver.execute_script("arguments[0].click()", menu_btn)
        time.sleep(1)

        logger.info("Clicking 'Change Role' menu item")
        change_role_text = plan.get("change_role_menu_item_text", "Change Role")
        menu_item_selectors = (
            "[role='menuitem']",
            "[role='menu'] button",
            "[role='menu'] li",
            "[role='menu'] [role='option']",
            "[data-radix-popper-content-wrapper] button",
            "[data-radix-popper-content-wrapper] [role='menuitem']",
            "button",
        )
        change_role_item = None
        deadline = time.time() + 30
        while time.time() < deadline and change_role_item is None:
            for selector in menu_item_selectors:
                items = driver.find_elements(By.CSS_SELECTOR, selector)
                found = _find_clickable_text_element(items, change_role_text)
                if found:
                    change_role_item = found
                    break
            if change_role_item is None:
                time.sleep(0.25)

        if not change_role_item:
            output = CalendlyChangeRoleResult(success=False, error="'Change Role' menu item not found in dropdown")
            return WorkflowResult(
                success=False,
                output=output.model_dump(),
                error=output.error,
            )

        change_role_item.click()
        time.sleep(1)

        logger.info("Waiting for role dialog")
        # Poll until a [role='dialog'] containing "Change Role" text is visible.
        dialog = None
        deadline = time.time() + 20
        while time.time() < deadline and dialog is None:
            for el in driver.find_elements(By.CSS_SELECTOR, "[role='dialog']"):
                try:
                    if el.is_displayed() and "change role" in (el.text or "").lower():
                        dialog = el
                        break
                except Exception:
                    continue
            if dialog is None:
                time.sleep(0.25)

        if dialog is None:
            output = CalendlyChangeRoleResult(success=False, error="Change Role dialog did not appear")
            return WorkflowResult(success=False, output=output.model_dump(), error=output.error)

        logger.info(f"Selecting role: {params.role}")
        # The combobox is a div[role='combobox'].  Find it inside our known dialog element
        # and click via ActionChains so it works regardless of Selenium interactability checks.
        combobox = None
        deadline = time.time() + 15
        while time.time() < deadline and combobox is None:
            try:
                combobox = dialog.find_element(By.CSS_SELECTOR, "[role='combobox']")
            except Exception:
                time.sleep(0.25)

        if combobox is None:
            output = CalendlyChangeRoleResult(success=False, error="Role combobox did not render in dialog")
            return WorkflowResult(success=False, output=output.model_dump(), error=output.error)

        # Scroll into view + ActionChains click (most reliable for custom div-based comboboxes).
        driver.execute_script("arguments[0].scrollIntoView({block:'center'})", combobox)
        time.sleep(0.2)
        try:
            ActionChains(driver).move_to_element(combobox).click().perform()
        except Exception:
            driver.execute_script("arguments[0].click()", combobox)

        time.sleep(0.5)

        # The combobox exposes aria-controls pointing to its listbox, e.g.
        # aria-controls="select-4193a-options" → option IDs are "select-4193a-option-user".
        # This is the most targeted selector available; fall back to text search.
        import json as _json

        role_lower = params.role.lower()
        controls_id = combobox.get_attribute("aria-controls") or ""
        # derive option id: "select-4193a-options" → "select-4193a-option-user"
        derived_option_id = controls_id.replace("-options", f"-option-{role_lower}") if controls_id else ""

        role_json = _json.dumps(role_lower)
        derived_id_js = _json.dumps(derived_option_id)
        js_select = (
            f"const target = {role_json};"
            f"const derivedId = {derived_id_js};"
            # 1) try the derived ID directly (most precise)
            "if (derivedId) {"
            "  const byId = document.getElementById(derivedId);"
            "  if (byId) { byId.click(); return 'selected:id'; }"
            "}"
            # 2) any [role='option'] matching text (works even when aria-hidden)
            'const opts = document.querySelectorAll(\'[role="option"], [role="listbox"] button\');'
            "for (const el of opts) {"
            "  if ((el.textContent || '').trim().toLowerCase() === target) {"
            "    el.click(); return 'selected:text';"
            "  }"
            "}"
            "return 'not_found';"
        )
        selected = False
        deadline = time.time() + 20
        while time.time() < deadline and not selected:
            sel_result = driver.execute_script(js_select)
            if sel_result and sel_result.startswith("selected"):
                selected = True
                logger.info(f"Role option selected via: {sel_result}")
            else:
                time.sleep(0.25)

        if not selected:
            output = CalendlyChangeRoleResult(
                success=False,
                error=f"Role '{params.role}' not found in dropdown options",
            )
            return WorkflowResult(success=False, output=output.model_dump(), error=output.error)

        time.sleep(0.5)

        logger.info("Clicking 'Apply' button")
        apply_text = plan.get("apply_button_text", "Apply")
        # Re-fetch the dialog in case DOM updated after selecting role.
        dialog = None
        for el in driver.find_elements(By.CSS_SELECTOR, "[role='dialog']"):
            try:
                if el.is_displayed() and "change role" in (el.text or "").lower():
                    dialog = el
                    break
            except Exception:
                continue
        if dialog is None:
            dialog = driver.find_element(By.CSS_SELECTOR, "[role='dialog']")

        apply_btn = None
        deadline = time.time() + 15
        while time.time() < deadline and not apply_btn:
            dialog_buttons = dialog.find_elements(By.CSS_SELECTOR, "button")
            apply_btn = _find_clickable_text_element(dialog_buttons, apply_text)
            if not apply_btn:
                submit_buttons = dialog.find_elements(By.CSS_SELECTOR, "button[type='submit']")
                apply_btn = submit_buttons[0] if submit_buttons else None
            if not apply_btn:
                time.sleep(0.25)

        if not apply_btn:
            output = CalendlyChangeRoleResult(success=False, error=f"'{apply_text}' button not found in dialog")
            return WorkflowResult(
                success=False,
                output=output.model_dump(),
                error=output.error,
            )

        apply_btn.click()
        time.sleep(plan.get("wait_after_apply_seconds", 3))

        output = CalendlyChangeRoleResult(success=True, error=None)
        logger.info(f"Role for {params.email} changed to {params.role} successfully")
        return WorkflowResult(success=True, output=output.model_dump())

    except Exception as e:
        logger.exception(f"Failed to change role: {e}")
        output = CalendlyChangeRoleResult(success=False, error=str(e))
        return WorkflowResult(
            success=False,
            output=output.model_dump(),
            error=f"Failed to change role: {e!s}",
        )
