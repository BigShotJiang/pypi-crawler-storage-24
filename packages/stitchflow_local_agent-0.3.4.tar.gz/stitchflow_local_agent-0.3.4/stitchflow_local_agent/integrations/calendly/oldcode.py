"""Calendly admin: change a user's role (Admin / User)."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Any

from stitchflow_local_agent.common.browser import (
    capture_screenshot,
    find_ref_by_text,
    run_agent_browser,
    snapshot_text,
    take_snapshot,
)
from stitchflow_local_agent.common.logging import append_jsonl
from stitchflow_local_agent.actions.calendly.common import (
    AUDIT_LOG_PATH,
    artifact_dir_for_task,
    clear_search,
    ensure_calendly_authenticated,
    find_user_row,
    open_kebab_menu,
    refresh_users_page,
    search_for_user,
    wait_for_users_table,
)


async def change_calendly_role(
    email: str,
    role: str = "User",
    task_id: str = "",
    page_ready: bool = False,
) -> dict[str, Any]:
    """Change a Calendly user's role via the admin UI.

    Steps:
    1. Navigate to admin users page (or reuse session if *page_ready*).
    2. Search for the user by email.
    3. Click the kebab menu on the user row.
    4. Click "Change Role" in the popup menu.
    5. In the "Change Role" dialog, open the dropdown and select *role*.
    6. Click "Apply".
    7. Refresh and verify the role changed.
    """
    print(f"\n  Changing role for {email} to {role} in Calendly...")
    artifact_dir = artifact_dir_for_task(task_id, email)
    audit_file = artifact_dir / "audit.json"
    before_screenshot = artifact_dir / "before.png"
    after_screenshot = artifact_dir / "after.png"
    audit: dict[str, Any] = {
        "task_id": task_id,
        "email": email,
        "integration": "calendly",
        "action": "change_role",
        "target_role": role,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "artifact_dir": str(artifact_dir),
        "events": [],
    }
    final_status = "unknown"

    def add_event(message: str, **extra: Any) -> None:
        event = {"ts": datetime.now(timezone.utc).isoformat(), "message": message}
        event.update(extra)
        audit["events"].append(event)

    if not page_ready:
        auth_err = await ensure_calendly_authenticated()
        if auth_err:
            add_event("authentication_failed", error=auth_err.get("error"))
            final_status = "error"
            return {**auth_err, "email": email}
        table = await wait_for_users_table()
        if table.get("error"):
            add_event("users_table_load_failed", error=table.get("error"))
            final_status = "error"
            return {"status": "error", "error": table["error"], "email": email}

    try:
        # Search for user
        snap = await search_for_user(email)
        if snap.get("error"):
            add_event("search_failed", error=snap.get("error"))
            final_status = "error"
            return {"status": "error", "error": snap["error"], "email": email}
        add_event("search_completed")

        found = await find_user_row(email, snap)
        if not found:
            await clear_search()
            add_event("user_not_found")
            final_status = "skipped"
            return {
                "status": "skipped",
                "reason": "User not found in Calendly",
                "email": email,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        await capture_screenshot(str(before_screenshot))
        add_event("before_screenshot_captured")

        # Open kebab menu
        if not await open_kebab_menu(email):
            await clear_search()
            add_event("open_menu_failed")
            final_status = "error"
            return {"status": "error", "error": "Could not open user actions menu", "email": email}
        add_event("menu_opened")

        await asyncio.sleep(1)

        # Click "Change Role" in popup menu
        snap = await take_snapshot()
        snap_text_val = snapshot_text(snap)
        change_ref = find_ref_by_text(snap_text_val, "Change Role")
        if not change_ref:
            change_ref = find_ref_by_text(snap_text_val, "Change role")
        if not change_ref:
            await clear_search()
            add_event("change_role_option_not_found")
            final_status = "error"
            return {"status": "error", "error": "Could not find Change Role option in menu", "email": email}

        res = await run_agent_browser(["click", change_ref], timeout=15)
        if res.get("error"):
            await clear_search()
            add_event("change_role_click_failed", error=res["error"])
            final_status = "error"
            return {"status": "error", "error": f"Failed to click Change Role: {res['error']}", "email": email}
        add_event("change_role_dialog_opened")

        await asyncio.sleep(2)

        # "Change Role" dialog: click the dropdown to open options, then select role
        # The dropdown shows the current role. Click it to reveal options.
        snap = await take_snapshot()
        snap_text_val = snapshot_text(snap)

        # Find and click the dropdown (it's a combobox or select-like element)
        # The dropdown button typically shows "Admin" or "User" text
        dropdown_ref = find_ref_by_text(snap_text_val, "Admin")
        if not dropdown_ref:
            dropdown_ref = find_ref_by_text(snap_text_val, "User")
        if not dropdown_ref:
            # Try to find any combobox/select in the dialog
            js_open_dropdown = (
                "(() => {"
                "  const dialog = document.querySelector('[role=\"dialog\"]');"
                "  if (!dialog) return 'no_dialog';"
                "  const trigger = dialog.querySelector('[role=\"combobox\"], select, [data-state]');"
                "  if (!trigger) return 'no_trigger';"
                "  trigger.click();"
                "  return 'clicked';"
                "})()"
            )
            dd_result = await run_agent_browser(["eval", js_open_dropdown], timeout=15)
            if "clicked" not in str(dd_result.get("output", "")).lower():
                await clear_search()
                add_event("dropdown_not_found")
                final_status = "error"
                return {"status": "error", "error": "Could not find role dropdown in dialog", "email": email}
        else:
            res = await run_agent_browser(["click", dropdown_ref], timeout=15)
            if res.get("error"):
                await clear_search()
                add_event("dropdown_click_failed", error=res["error"])
                final_status = "error"
                return {"status": "error", "error": f"Failed to open dropdown: {res['error']}", "email": email}

        add_event("dropdown_opened")
        await asyncio.sleep(1)

        # Select the target role from the dropdown options
        snap = await take_snapshot()
        snap_text_val = snapshot_text(snap)
        role_ref = find_ref_by_text(snap_text_val, role)
        if not role_ref:
            # Try JS approach to click option by text
            role_json = json.dumps(role.lower())
            js_select = (
                "(() => {"
                f"  const target = {role_json};"
                '  const options = document.querySelectorAll(\'[role="option"], [role="menuitem"], li\');'
                "  for (const opt of options) {"
                "    if ((opt.textContent || '').trim().toLowerCase() === target) {"
                "      opt.click();"
                "      return 'selected';"
                "    }"
                "  }"
                "  return 'not_found';"
                "})()"
            )
            sel_result = await run_agent_browser(["eval", js_select], timeout=15)
            if "selected" not in str(sel_result.get("output", "")).lower():
                await clear_search()
                add_event("role_option_not_found", target_role=role)
                final_status = "error"
                return {"status": "error", "error": f"Could not select role '{role}' in dropdown", "email": email}
        else:
            res = await run_agent_browser(["click", role_ref], timeout=15)
            if res.get("error"):
                await clear_search()
                add_event("role_select_failed", error=res["error"])
                final_status = "error"
                return {"status": "error", "error": f"Failed to select role: {res['error']}", "email": email}

        add_event("role_selected", role=role)
        await asyncio.sleep(1)

        # Click "Apply" button
        snap = await take_snapshot()
        snap_text_val = snapshot_text(snap)
        apply_ref = find_ref_by_text(snap_text_val, "Apply")
        if not apply_ref:
            await clear_search()
            add_event("apply_button_not_found")
            final_status = "error"
            return {"status": "error", "error": "Could not find Apply button", "email": email}

        res = await run_agent_browser(["click", apply_ref], timeout=15)
        if res.get("error"):
            await clear_search()
            add_event("apply_click_failed", error=res["error"])
            final_status = "error"
            return {"status": "error", "error": f"Failed to click Apply: {res['error']}", "email": email}
        add_event("apply_clicked")

        await asyncio.sleep(3)

        # Refresh and verify
        refreshed = await refresh_users_page()
        add_event("page_refreshed", success=refreshed)

        verified = False
        role_matches = False

        if refreshed:
            verify_snap = await search_for_user(email)
            if not verify_snap.get("error"):
                snap_text_val = snapshot_text(verify_snap)
                if email.lower() in snap_text_val.lower() and role in snap_text_val:
                    role_matches = True
                    verified = True
                add_event("post_change_verification", role_matches=role_matches)
                await clear_search()

        await capture_screenshot(str(after_screenshot))
        add_event("after_screenshot_captured")

        final_status = "changed"
        return {
            "status": "changed",
            "email": email,
            "role": role,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "verified": verified,
            "artifacts": {
                "audit_file": str(audit_file),
                "before_screenshot": str(before_screenshot),
                "after_screenshot": str(after_screenshot),
            },
        }
    finally:
        audit["ended_at"] = datetime.now(timezone.utc).isoformat()
        audit_file.write_text(json.dumps(audit, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
        append_jsonl(
            AUDIT_LOG_PATH,
            {
                "task_id": task_id,
                "email": email,
                "integration": "calendly",
                "action": "change_role",
                "target_role": role,
                "ended_at": audit["ended_at"],
                "status": final_status,
                "artifact_dir": str(artifact_dir),
                "audit_file": str(audit_file),
            },
        )
