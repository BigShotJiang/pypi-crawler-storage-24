"""Register Calendly operations in the global registry."""

from stitchflow_local_agent.automation.operation import Operation, register_operation
from stitchflow_local_agent.integrations.calendly.schemas import (
    CalendlyChangeRoleFields,
    CalendlyChangeRoleResult,
    CalendlyRemoveUserFields,
    CalendlyRemoveUserResult,
)
from stitchflow_local_agent.integrations.calendly.workflows import (
    calendly_change_role_workflow,
    calendly_remove_user_workflow,
)

CALENDLY_REMOVE_USER_OPERATION = Operation(
    operation_key="calendly_remove_user",
    workflow=calendly_remove_user_workflow,
    input_params_schema=CalendlyRemoveUserFields,
    expected_output_schema=CalendlyRemoveUserResult,
)

CALENDLY_CHANGE_ROLE_OPERATION = Operation(
    operation_key="calendly_change_role",
    workflow=calendly_change_role_workflow,
    input_params_schema=CalendlyChangeRoleFields,
    expected_output_schema=CalendlyChangeRoleResult,
)


def register_calendly_operations() -> None:
    """Register all Calendly operations."""
    register_operation(CALENDLY_REMOVE_USER_OPERATION)
    register_operation(CALENDLY_CHANGE_ROLE_OPERATION)
