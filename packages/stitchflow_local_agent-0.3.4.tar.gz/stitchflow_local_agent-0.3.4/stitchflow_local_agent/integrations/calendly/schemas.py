"""Calendly resource schemas and parameter models."""

from pydantic import BaseModel, Field


class CalendlyRemoveUserFields(BaseModel):
    """Fields required to remove a user in Calendly."""

    email: str = Field(description="Email address of user to remove")


class CalendlyRemoveUserResult(BaseModel):
    """Result of removing a user in Calendly."""

    success: bool = Field(description="Whether the user was removed successfully")
    error: str | None = Field(default=None, description="Error message if operation failed")


class CalendlyChangeRoleFields(BaseModel):
    """Fields required to change a user's role in Calendly."""

    email: str = Field(description="Email address of user whose role to change")
    role: str = Field(default="User", description="Target role (e.g., User, Admin)")


class CalendlyChangeRoleResult(BaseModel):
    """Result of changing a user's role in Calendly."""

    success: bool = Field(description="Whether the role was changed successfully")
    error: str | None = Field(default=None, description="Error message if operation failed")
