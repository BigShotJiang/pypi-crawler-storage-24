"""Calendly admin: remove a user from the organization."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Any

from stitchflow_local_agent.common.browser import (
    capture_screenshot,
    find_ref_by_text,
    run_agent_browser,
    snapshot_text,
    take_snapshot,
)
from stitchflow_local_agent.common.logging import append_jsonl
from stitchflow_local_agent.actions.calendly.common import (
    AUDIT_LOG_PATH,
    artifact_dir_for_task,
    clear_search,
    ensure_calendly_authenticated,
    find_user_row,
    open_kebab_menu,
    refresh_users_page,
    search_for_user,
    wait_for_users_table,
)


async def remove_calendly_user(
    email: str,
    task_id: str = "",
    page_ready: bool = False,
) -> dict[str, Any]:
    """Remove a user from Calendly via the admin UI.

    Steps:
    1. Navigate to admin users page (or reuse session if *page_ready*).
    2. Search for the user by email.
    3. Click the kebab menu on the user row.
    4. Click "Remove" in the popup menu.
    5. In the "Remove User" dialog, ensure "Remove" radio is selected.
    6. Click the "Remove" confirmation button.
    7. Refresh and verify the user is gone.
    """
    print(f"\n  Removing {email} from Calendly...")
    artifact_dir = artifact_dir_for_task(task_id, email)
    audit_file = artifact_dir / "audit.json"
    before_screenshot = artifact_dir / "before.png"
    after_screenshot = artifact_dir / "after.png"
    audit: dict[str, Any] = {
        "task_id": task_id,
        "email": email,
        "integration": "calendly",
        "action": "remove_user",
        "started_at": datetime.now(timezone.utc).isoformat(),
        "artifact_dir": str(artifact_dir),
        "events": [],
    }
    final_status = "unknown"

    def add_event(message: str, **extra: Any) -> None:
        event = {"ts": datetime.now(timezone.utc).isoformat(), "message": message}
        event.update(extra)
        audit["events"].append(event)

    if not page_ready:
        auth_err = await ensure_calendly_authenticated()
        if auth_err:
            add_event("authentication_failed", error=auth_err.get("error"))
            final_status = "error"
            return {**auth_err, "email": email}
        table = await wait_for_users_table()
        if table.get("error"):
            add_event("users_table_load_failed", error=table.get("error"))
            final_status = "error"
            return {"status": "error", "error": table["error"], "email": email}

    try:
        # Search for user
        snap = await search_for_user(email)
        if snap.get("error"):
            add_event("search_failed", error=snap.get("error"))
            final_status = "error"
            return {"status": "error", "error": snap["error"], "email": email}
        add_event("search_completed")

        found = await find_user_row(email, snap)
        if not found:
            await clear_search()
            add_event("user_not_found")
            final_status = "skipped"
            return {
                "status": "skipped",
                "reason": "User not found in Calendly",
                "email": email,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        await capture_screenshot(str(before_screenshot))
        add_event("before_screenshot_captured")

        # Open kebab menu
        if not await open_kebab_menu(email):
            await clear_search()
            add_event("open_menu_failed")
            final_status = "error"
            return {"status": "error", "error": "Could not open user actions menu", "email": email}
        add_event("menu_opened")

        await asyncio.sleep(1)

        # Click "Remove" in popup menu
        snap = await take_snapshot()
        snap_text_val = snapshot_text(snap)
        remove_ref = find_ref_by_text(snap_text_val, "Remove")
        if not remove_ref:
            await clear_search()
            add_event("remove_option_not_found")
            final_status = "error"
            return {"status": "error", "error": "Could not find Remove option in menu", "email": email}

        res = await run_agent_browser(["click", remove_ref], timeout=15)
        if res.get("error"):
            await clear_search()
            add_event("remove_click_failed", error=res["error"])
            final_status = "error"
            return {"status": "error", "error": f"Failed to click Remove: {res['error']}", "email": email}
        add_event("remove_option_clicked")

        await asyncio.sleep(2)

        # "Remove User" dialog: ensure "Remove" radio is selected (it's the default),
        # then click the "Remove" confirmation button.
        snap = await take_snapshot()
        snap_text_val = snapshot_text(snap)

        # The dialog has a "Remove" radio (default) and a "Remove and delete" radio.
        # The confirmation button is also labelled "Remove".
        # We need the button, not the radio. Look for a button element.
        js_confirm = (
            "(() => {"
            "  const dialog = document.querySelector('[role=\"dialog\"]') ||"
            "    document.querySelector('[role=\"alertdialog\"]');"
            "  if (!dialog) return 'no_dialog';"
            "  const buttons = dialog.querySelectorAll('button');"
            "  for (const btn of buttons) {"
            "    const text = (btn.textContent || '').trim().toLowerCase();"
            "    if (text === 'remove') {"
            "      btn.click();"
            "      return 'clicked';"
            "    }"
            "  }"
            "  return 'button_not_found';"
            "})()"
        )
        confirm = await run_agent_browser(["eval", js_confirm], timeout=15)
        output = str(confirm.get("output", "")).lower()
        if "clicked" not in output:
            await clear_search()
            add_event("confirm_remove_failed", output=output)
            final_status = "error"
            return {"status": "error", "error": "Could not click Remove confirm button", "email": email}
        add_event("remove_confirmed")

        await asyncio.sleep(3)

        # Refresh and verify
        refreshed = await refresh_users_page()
        add_event("page_refreshed", success=refreshed)

        verified = False
        still_present = False

        if refreshed:
            verify_snap = await search_for_user(email)
            if not verify_snap.get("error"):
                still_present = (await find_user_row(email, verify_snap)) is not None
                verified = True
                add_event("post_removal_verification", still_present=still_present)
                await clear_search()

        await capture_screenshot(str(after_screenshot))
        add_event("after_screenshot_captured")

        if still_present:
            final_status = "error"
            return {
                "status": "error",
                "error": "User still present after removal attempt",
                "email": email,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "artifacts": {
                    "audit_file": str(audit_file),
                    "before_screenshot": str(before_screenshot),
                    "after_screenshot": str(after_screenshot),
                },
            }

        final_status = "removed"
        return {
            "status": "removed",
            "email": email,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "verified": verified,
            "artifacts": {
                "audit_file": str(audit_file),
                "before_screenshot": str(before_screenshot),
                "after_screenshot": str(after_screenshot),
            },
        }
    finally:
        audit["ended_at"] = datetime.now(timezone.utc).isoformat()
        audit_file.write_text(json.dumps(audit, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
        append_jsonl(
            AUDIT_LOG_PATH,
            {
                "task_id": task_id,
                "email": email,
                "integration": "calendly",
                "action": "remove_user",
                "ended_at": audit["ended_at"],
                "status": final_status,
                "artifact_dir": str(artifact_dir),
                "audit_file": str(audit_file),
            },
        )
