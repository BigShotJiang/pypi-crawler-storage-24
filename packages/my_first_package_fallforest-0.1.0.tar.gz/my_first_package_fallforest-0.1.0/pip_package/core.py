def hello(name: str) -> str:
    """
    简单的示例函数：返回问候语
    :param name: 用户名
    :return: 问候字符串
    """
    return f"Hello, {name}! This is my first pip package."

def add(a: int, b: int) -> int:
    """简单的加法函数"""
    return a + b