# 从core模块导出函数，让用户可以直接 from my_first_package import hello
from .core import hello, add

# 定义包的版本号
__version__ = "0.1.0"