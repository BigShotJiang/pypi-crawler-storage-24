from setuptools import setup, find_packages

# 读取README.md作为包的长描述
with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="my_first_package_fallforest",          # 包名（必须唯一，pypi上不能重名）
    version="0.1.0",                  # 版本号（遵循语义化：主版本.次版本.修订号）
    author="Your Name",               # 作者名
    author_email="your_email@example.com",  # 作者邮箱
    description="A simple pip package example",  # 简短描述
    long_description=long_description,         # 长描述（从README读取）
    long_description_content_type="text/markdown",  # 长描述格式
    url="https://github.com/yourname/my_first_package",  # 项目地址（如GitHub）
    packages=find_packages(),         # 自动查找所有包（替代手动列包）
    classifiers=[                     # 分类标签（帮助用户找到你的包）
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",          # 支持的Python版本
    # install_requires=["requests"],  # 依赖的第三方包（如有则填）
)