# minidarkmimi-start-cli

A secure launcher and encrypted config bootstrap library for Python projects.

## Install

```bash
pip install minidarkmimi-start-cli
```

Import path stays the same:

```python
from start_cli import EncryptedConfig, ConfigLoader, AppSettings, create_cli
```

## What it provides

- encrypted config storage via `EncryptedConfig`
- smart config loading with `ConfigLoader` and `load_config`
- reusable Click CLI bootstrap via `create_cli`
- environment-aware settings via `AppSettings`
- helper utilities for masking secrets and maintaining `.gitignore`

## Quick example

```python
from start_cli import EncryptedConfig, create_cli

cfg = EncryptedConfig.create("config.env", password="example-password")
cfg["API_TOKEN"] = "example-token"
cfg.save()


def start_app() -> None:
    print("app started")


cli = create_cli(
    app_name="My Project",
    app_callable=start_app,
    required_envs={"API_TOKEN": "API token"},
)
```

## Links

- Source: https://github.com/minidarkmimi/start_cli_public
- Chinese README: https://github.com/minidarkmimi/start_cli_public/blob/main/README.zh-CN.md
