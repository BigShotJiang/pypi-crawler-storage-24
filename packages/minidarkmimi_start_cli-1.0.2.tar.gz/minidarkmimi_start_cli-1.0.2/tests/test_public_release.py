"""公开发布版本的回归测试。"""

import os

from click.testing import CliRunner

from start_cli import ConfigLoader, EncryptedConfig, __version__
from start_cli.cli.factory import create_cli
from start_cli.loader.config_loader import ensure_gitignore
from start_cli.settings.environment import AppSettings


def test_encrypted_config_does_not_override_existing_env(tmp_path):
    config_path = tmp_path / "config.env"
    cfg = EncryptedConfig.create(str(config_path), password="example-password")
    cfg["API_TOKEN"] = "value_from_config"
    cfg.save()

    os.environ["API_TOKEN"] = "value_from_process"
    try:
        loaded = EncryptedConfig(str(config_path), password="example-password")
        loaded.init_dotenv()
        assert os.environ["API_TOKEN"] == "value_from_process"
    finally:
        os.environ.pop("API_TOKEN", None)


def test_config_loader_tracks_plain_metadata(tmp_path):
    config_path = tmp_path / ".env.dev"
    config_path.write_text("DEMO_KEY=demo_value\n", encoding="utf-8")

    settings = AppSettings()
    loader = ConfigLoader(settings)
    loader.load(str(config_path), force_plain=True)

    assert loader.last_loaded_path == str(config_path)
    assert loader.last_loaded_format == "plain"
    assert loader.last_loaded_values["DEMO_KEY"] == "demo_value"
    os.environ.pop("DEMO_KEY", None)


def test_ensure_gitignore_adds_history_rule(tmp_path):
    gitignore_path = tmp_path / ".gitignore"
    ensure_gitignore(gitignore_path=str(gitignore_path))
    content = gitignore_path.read_text(encoding="utf-8")
    assert ".history/" in content


def test_generated_cli_shows_version():
    runner = CliRunner()
    cli = create_cli(app_name="start_cli", version=__version__)
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert __version__ in result.output
