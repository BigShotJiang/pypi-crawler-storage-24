"""
基于 questionary 的交互式配置编辑器（内部模块）

提供在终端中通过菜单方式编辑 EncryptedConfig 实例的功能。
通常由 ``config edit`` 命令调用，不建议直接使用。
"""

from typing import TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:
    from start_cli.crypto.config_manager import EncryptedConfig


def run_config_editor(config: "EncryptedConfig") -> None:
    """
    启动交互式配置编辑菜单。

    功能:
    - 查看所有配置（脱敏）
    - 查看单个配置项
    - 修改配置项
    - 新增配置项
    - 删除配置项

    Args:
        config: 已加载的 EncryptedConfig 实例；操作完成后调用 save()。

    Example::

        cfg = EncryptedConfig("app.env", password="secret")
        run_config_editor(cfg)
    """
    try:
        import questionary
        from colorama import Fore, Style, init

        init(autoreset=True)
    except ImportError as exc:
        missing = str(exc).split("'")[1] if "'" in str(exc) else str(exc)
        logger.error(f"❌ 缺少依赖 {missing}，请运行: pip install {missing}")
        return

    while True:
        action = questionary.select(
            "请选择操作:",
            choices=[
                "📋 查看所有配置（脱敏）",
                "🔍 查看单个配置项",
                "✏️  修改配置项",
                "➕ 新增配置项",
                "🗑️  删除配置项",
                "💾 保存并退出",
                "❌ 放弃修改并退出",
            ],
        ).ask()

        if action is None or action.startswith("❌"):
            logger.warning("⚠️  已放弃修改")
            break

        elif action.startswith("📋"):
            _print_all(config)

        elif action.startswith("🔍"):
            key = questionary.text("请输入配置项键名:").ask()
            if key:
                if key in config:
                    print(Fore.CYAN + f"  {key} = {config[key]}" + Style.RESET_ALL)
                else:
                    print(Fore.RED + f"  配置项 {key!r} 不存在" + Style.RESET_ALL)

        elif action.startswith("✏️"):
            key = questionary.text("请输入要修改的配置项键名:").ask()
            if key and key in config:
                is_sensitive = any(
                    kw in key.lower() for kw in config.SENSITIVE_KEYWORDS
                )
                value = questionary.password("请输入新值:").ask() if is_sensitive else questionary.text(
                    f"请输入 {key} 的新值:", default=config[key]
                ).ask()
                if value is not None:
                    config[key] = value
                    print(Fore.YELLOW + f"  ✓ {key} 已更新" + Style.RESET_ALL)
            elif key:
                print(Fore.RED + f"  配置项 {key!r} 不存在，使用「新增」添加" + Style.RESET_ALL)

        elif action.startswith("➕"):
            key = questionary.text("请输入新配置项键名:").ask()
            if key:
                if key in config and not questionary.confirm(
                    f"  {key!r} 已存在，是否覆盖？", default=False
                ).ask():
                    continue
                is_sensitive = any(kw in key.lower() for kw in config.SENSITIVE_KEYWORDS)
                value = (
                    questionary.password("请输入值（密码类型，输入不可见）:").ask()
                    if is_sensitive
                    else questionary.text("请输入值:").ask()
                )
                if value is not None:
                    config[key] = value
                    print(Fore.GREEN + f"  ✓ {key} 已添加" + Style.RESET_ALL)

        elif action.startswith("🗑️"):
            key = questionary.text("请输入要删除的配置项键名:").ask()
            if key and key in config:
                if questionary.confirm(f"  确认删除 {key!r}？", default=False).ask():
                    del config[key]
                    print(Fore.RED + f"  ✓ {key} 已删除" + Style.RESET_ALL)
            elif key:
                print(Fore.RED + f"  配置项 {key!r} 不存在" + Style.RESET_ALL)

        elif action.startswith("💾"):
            config.save()
            logger.success("✅ 配置已保存")
            break


def _print_all(config: "EncryptedConfig") -> None:
    """打印所有配置项（脱敏）。"""
    try:
        from colorama import Fore, Style
    except ImportError:
        for k, v in config.to_dict(masked=True).items():
            print(f"  {k} = {v}")
        return

    print(Fore.CYAN + "\n当前配置（脱敏）:" + Style.RESET_ALL)
    print("-" * 50)
    for k, v in sorted(config.to_dict(masked=True).items()):
        print(f"  {Fore.GREEN}{k:<28}{Style.RESET_ALL} = {v}")
    print("-" * 50)
    print(f"  共 {len(config)} 项\n")
