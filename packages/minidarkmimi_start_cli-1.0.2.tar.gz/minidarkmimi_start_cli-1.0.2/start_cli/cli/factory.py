"""
CLI 工厂模块

提供 ``create_cli()`` 工厂函数，根据传入参数生成完整的 Click CLI 应用，
包含以下内置命令:
- ``run``              启动应用（生产/手动模式）
- ``dev``              开发模式快捷启动
- ``config``           配置文件管理子命令组
- ``doctor``           环境诊断
- ``generate-script``  生成启动脚本
- ``interactive``      启动 TUI 交互式菜单

使用方式::

    from start_cli.cli import create_cli

    def my_app():
        print("App is running!")

    cli = create_cli(
        app_name="My App",
        app_callable=my_app,
        required_envs={"APP_TOKEN": "应用 Token"},
        config_file="config.env",
    )

    if __name__ == "__main__":
        cli()
"""

import os
import platform
import sys
from importlib import import_module
from typing import Callable, Dict, List, Optional, Tuple

import click
from loguru import logger

from start_cli.cli.config_cmds import config_group


def create_cli(
    app_name: str = "App",
    app_callable: Optional[Callable] = None,
    required_envs: Optional[Dict[str, str]] = None,
    optional_envs: Optional[Dict[str, str]] = None,
    config_file: Optional[str] = None,
    banner: Optional[str] = None,
    dependencies: Optional[List[Tuple[str, str]]] = None,
    version: str = "1.0.0",
    env_var: str = "APP_ENV",
    post_load_hook: Optional[Callable] = None,
) -> click.Group:
    """
    创建完整的应用 CLI（Click Group）。

    生成的 CLI 包含以下子命令:
    - ``run``              启动应用（生产/手动模式）
    - ``dev``              开发模式快速启动
    - ``config``           配置文件管理
    - ``doctor``           环境诊断
    - ``generate-script``  生成启动脚本
    - ``interactive`` / ``-i``  TUI 交互式菜单

    Args:
        app_name: 应用名称，显示在横幅和 --help 中。
        app_callable: 配置加载完成后调用的函数（实际应用入口）。
        required_envs: 必需的环境变量字典 ``{变量名: 说明}``，缺失时提示或退出。
        optional_envs: 可选的环境变量字典 ``{变量名: 说明}``，缺失时仅警告。
        config_file: 默认配置文件路径（覆盖 settings 的推断值）。
        banner: 自定义横幅文本（用于 TUI 菜单）。
        dependencies: 诊断命令中检查的依赖列表 ``[(module, display_name), ...]``。
        version: 版本字符串，显示在 ``--version`` 输出中。
        env_var: 环境类型变量名，默认 ``APP_ENV``（同时设置 ``BOT_ENV``）。
        post_load_hook: 配置加载并注入 ``os.environ`` 后、``app_callable`` 被调用
            前执行的钩子函数（无参数）。适合在此处初始化项目自有的 settings 单例、
            执行额外验证等项目特有逻辑。若钩子抛出 ``SystemExit``，则直接终止；
            若抛出其他异常，则记录错误后以状态码 1 退出。

    Returns:
        配置好的 Click Group 对象，可直接调用或挂载到父 CLI。

    Example::

        def after_loaded():
            # 将已注入的 os.environ 同步到项目 settings 单例
            from myapp.config import settings
            settings.load_from_env()
            settings.validate()

        cli = create_cli(
            app_name="My Bot",
            app_callable=start_bot,
            required_envs={"BOT_TOKEN": "Telegram Bot Token"},
            config_file="config.env",
            version="2.0.0",
            post_load_hook=after_loaded,
        )
        cli()  # 运行 CLI
    """
    _required = required_envs or {}
    _optional = optional_envs or {}
    _deps = dependencies or [
        ("click", "click"),
        ("loguru", "loguru"),
        ("dotenv", "python-dotenv"),
        ("cryptography", "cryptography"),
    ]

    # ── 内部辅助：启动应用流程 ────────────────────────────────

    def _run_app(cf: Optional[str] = None) -> None:
        """加载配置 → 验证环境变量 → post_load_hook → 调用 app_callable。"""
        from start_cli.loader.config_loader import ConfigLoader, ensure_gitignore
        from start_cli.settings.environment import AppSettings

        # 显式指定的配置文件（-c / -f 参数）优先级最高
        if cf:
            os.environ["CONFIG_FILE"] = cf

        # 确保敏感文件在 .gitignore
        try:
            ensure_gitignore()
        except Exception:
            pass

        # 先构建 AppSettings，读取当前运行环境（BOT_ENV/APP_ENV）
        settings = AppSettings()
        settings.print_banner(app_name)

        # create_cli 的 config_file 默认值仅用于非开发环境，且优先级低于
        # CONFIG_FILE 环境变量和 AppSettings 的环境专属默认（.env.dev 等）。
        # 开发环境有自己的默认路径（.env.dev），不应被此参数覆盖。
        if (
            config_file
            and not cf
            and not os.environ.get("CONFIG_FILE")
            and not settings.is_development
        ):
            os.environ["CONFIG_FILE"] = config_file

        loader = ConfigLoader(settings)
        loader.load()
        loader.validate_env(required=_required, optional=_optional)

        settings.load_from_env()
        try:
            settings.validate()
        except ValueError as exc:
            logger.error(f"配置验证失败: {exc}")
            sys.exit(1)

        # 项目特有后处理钩子（如同步项目 settings 单例、额外校验等）
        if post_load_hook is not None:
            try:
                post_load_hook()
            except SystemExit:
                raise
            except Exception as exc:
                logger.exception(f"post_load_hook 执行失败: {exc}")
                sys.exit(1)

        if app_callable is None:
            logger.warning("⚠️  未配置 app_callable，应用无法启动")
            return

        app_callable()

    # ── Click Group ────────────────────────────────────────────

    @click.group(
        invoke_without_command=True,
        context_settings={"help_option_names": ["-h", "--help"]},
        help=f"🤖 {app_name} - 命令行工具",
    )
    @click.option(
        "--env",
        type=click.Choice(["development", "staging", "production"]),
        default=None,
        help="覆盖运行环境",
    )
    @click.option("--debug/--no-debug", default=None, help="启用/禁用调试模式")
    @click.option("--version", "show_version", is_flag=True, help="显示版本信息")
    @click.option(
        "-i", "--interactive", "interactive_mode", is_flag=True, help="启动交互式菜单"
    )
    @click.pass_context
    def cli(
        ctx: click.Context,
        env: Optional[str],
        debug: Optional[bool],
        show_version: bool,
        interactive_mode: bool,
    ) -> None:
        """CLI 主命令组，详细帮助信息参见 --help。"""
        if show_version:
            click.echo(f"{app_name} v{version}")
            ctx.exit(0)

        if env:
            os.environ[env_var] = env
            os.environ["BOT_ENV"] = env  # 兼容旧代码

        if debug is not None:
            os.environ["DEBUG"] = "true" if debug else "false"

        if interactive_mode:
            from start_cli.cli.menu import run_interactive_menu

            run_interactive_menu(
                app_name=app_name,
                app_callable=lambda: _run_app(),
                config_file=config_file,
                banner=banner,
                dependencies=_deps,
                required_env_vars=list(_required.keys()),
            )
            ctx.exit(0)

        if ctx.invoked_subcommand is None:
            # 默认启动交互式菜单
            from start_cli.cli.menu import run_interactive_menu

            run_interactive_menu(
                app_name=app_name,
                app_callable=lambda: _run_app(),
                config_file=config_file,
                banner=banner,
                dependencies=_deps,
                required_env_vars=list(_required.keys()),
            )

    # ── run 命令 ──────────────────────────────────────────────

    @cli.command("run")
    @click.option("-c", "--config", "cf", default=None, help="配置文件路径")
    @click.option(
        "-p",
        "--password",
        default=None,
        help="配置密码（建议用 CONFIG_PASSWORD 环境变量）",
    )
    @click.option("--no-sync", is_flag=True, help="禁用后端同步")
    @click.option("--mock", is_flag=True, help="启用 Mock 服务")
    @click.option("--reload", is_flag=True, help="启用自动重载（需 watchdog）")
    def run_cmd(
        cf: Optional[str],
        password: Optional[str],
        no_sync: bool,
        mock: bool,
        reload: bool,
    ) -> None:
        """启动应用（生产/手动模式）。"""
        if password:
            logger.warning("⚠️  命令行传递密码不安全，建议使用环境变量 CONFIG_PASSWORD")
            os.environ["CONFIG_PASSWORD"] = password
        if no_sync:
            os.environ["ENABLE_SYNC"] = "false"
        if mock:
            os.environ["MOCK_SERVICES"] = "true"
        if reload:
            os.environ["AUTO_RELOAD"] = "true"
        _run_app(cf)

    # ── dev 命令 ──────────────────────────────────────────────

    @cli.command("dev")
    @click.option(
        "-f", "--file", "cf", default=None, help="配置文件路径（默认 .env.dev）"
    )
    @click.option("--no-reload", is_flag=True, help="禁用自动重载")
    def dev_cmd(cf: Optional[str], no_reload: bool) -> None:
        """🚀 开发模式快捷启动（DEBUG=true，自动重载）。"""
        os.environ[env_var] = "development"
        os.environ["BOT_ENV"] = "development"
        os.environ["DEBUG"] = "true"
        if not no_reload:
            os.environ["AUTO_RELOAD"] = "true"
        logger.info("🚀 开发模式启动...")
        _run_app(cf)

    # ── config 命令组 ─────────────────────────────────────────
    cli.add_command(config_group)

    # ── doctor 命令 ───────────────────────────────────────────

    @cli.command("doctor")
    def doctor_cmd() -> None:
        """🔍 运行环境诊断，检查 Python、依赖、配置文件和环境变量。"""
        click.echo("=" * 60)
        click.echo("🔍 环境诊断报告")
        click.echo("=" * 60)

        click.echo(f"\n📌 Python:")
        click.echo(f"  版本: {platform.python_version()}")
        click.echo(f"  路径: {sys.executable}")
        click.echo(f"  平台: {platform.platform()}")

        click.echo(f"\n📁 工作目录: {os.getcwd()}")

        click.echo(f"\n🌍 运行环境:")
        for k in (env_var, "BOT_ENV", "DEBUG", "CONFIG_FILE"):
            click.echo(f"  {k:<25} = {os.environ.get(k, '未设置')}")

        if _required or _optional:
            click.echo(f"\n🔑 应用环境变量:")
            for k, desc in {**_required, **_optional}.items():
                val = os.environ.get(k, "未设置")
                if any(
                    kw in k.upper() for kw in ("TOKEN", "SECRET", "PASSWORD", "KEY")
                ):
                    val = (
                        val[:8] + "***"
                        if val != "未设置" and len(val) > 8
                        else ("未设置" if val == "未设置" else "***")
                    )
                click.echo(f"  {k:<25} = {val}  ({desc})")

        click.echo(f"\n📄 配置文件:")
        check_files = []
        if config_file:
            check_files.append(config_file)
        check_files += [".env.dev", "config.env"]
        for cf_ in dict.fromkeys(check_files):
            if os.path.exists(cf_):
                size = os.path.getsize(cf_)
                click.echo(f"  ✅ {cf_:<30} ({size:,} bytes)")
            else:
                click.echo(f"  ⚪ {cf_:<30} (不存在)")

        click.echo(f"\n📦 依赖状态:")
        for mod_name, display in _deps:
            try:
                mod = import_module(mod_name)
                ver = getattr(mod, "__version__", "已安装")
                click.echo(f"  ✅ {display:<35} {ver}")
            except ImportError:
                opt = "可选" in display
                click.echo(f"  {'⚠️  可选' if opt else '❌ 缺失'} {display}")

        click.echo("\n" + "=" * 60)
        click.echo("💡 诊断完成")
        click.echo("=" * 60)

    # ── generate-script 命令 ──────────────────────────────────

    @cli.command("generate-script")
    @click.option(
        "--env",
        "script_env",
        type=click.Choice(["dev", "prod"]),
        default="dev",
        help="生成 dev.sh 或 prod.sh",
    )
    def generate_script_cmd(script_env: str) -> None:
        """生成 Bash 启动脚本（dev.sh / prod.sh）。"""
        if script_env == "dev":
            content = f"""#!/bin/bash
# {app_name} - 开发环境启动脚本
# 自动生成，可根据需要修改

export {env_var}=development
export BOT_ENV=development
export DEBUG=true
export AUTO_RELOAD=true

python cli.py dev
"""
            filename = "dev.sh"
        else:
            content = f"""#!/bin/bash
# {app_name} - 生产环境启动脚本
# 自动生成，可根据需要修改

export {env_var}=production
export BOT_ENV=production

# 从密钥管理系统或环境中注入密码
# export CONFIG_PASSWORD="your_password"

python cli.py run
"""
            filename = "prod.sh"

        with open(filename, "w", encoding="utf-8") as f:
            f.write(content)
        os.chmod(filename, 0o755)
        click.echo(f"✅ 已生成: {filename}")
        click.echo(f"💡 执行: ./{filename}")

    return cli
