"""
cli 子包：Click 命令行工具集。

公开接口::

    from start_cli.cli import create_cli, config_group, run_interactive_menu
"""

from .config_cmds import config_group
from .factory import create_cli
from .menu import InteractiveMenu, run_interactive_menu

__all__ = [
    "create_cli",
    "config_group",
    "InteractiveMenu",
    "run_interactive_menu",
]
