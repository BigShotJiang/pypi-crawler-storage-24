"""
Click 配置管理子命令组

提供 ``config`` 命令组，子命令包括:
- ``create``         创建新配置文件（明文或加密）
- ``edit``           交互式编辑配置（questionary 菜单）
- ``show``           查看配置内容（脱敏）
- ``change-password`` 修改加密配置密码
- ``upgrade``        升级旧版加密格式到最新（V3）

使用方式（在用户 cli.py 中）::

    from start_cli.cli import config_group
    cli.add_command(config_group)
"""

import getpass
import os
import subprocess
from typing import Dict, Optional

import click
from loguru import logger

from start_cli.crypto.config_manager import EncryptedConfig


@click.group("config")
def config_group() -> None:
    """
    ⚙️  配置文件管理

    子命令:
        create           创建新配置文件
        edit             修改现有配置（交互式菜单）
        show             查看配置内容（脱敏）
        change-password  修改加密配置密码
        upgrade          升级加密格式到最新版本
    """


# ── create ────────────────────────────────────────────────────


@config_group.command("create")
@click.option("-f", "--file", "config_file", default="config.env", help="配置文件路径")
@click.option("--dev", is_flag=True, help="创建明文开发配置（无需密码）")
@click.option(
    "--vars",
    "extra_vars",
    multiple=True,
    metavar="KEY=VALUE",
    help="预填配置项（可多次使用）",
)
def create_config(config_file: str, dev: bool, extra_vars: tuple) -> None:
    """
    创建新配置文件。

    \b
    示例:
        start-cli config create                      # 交互式创建加密配置
        start-cli config create --dev                # 创建明文开发配置
        start-cli config create -f app.env           # 指定文件名
        start-cli config create --vars KEY=value     # 预填配置项
    """
    parsed_vars: Dict[str, str] = {}
    for item in extra_vars:
        if "=" in item:
            k, _, v = item.partition("=")
            parsed_vars[k.strip()] = v.strip()
        else:
            logger.warning(f"忽略格式不正确的 --vars 参数: {item!r}（应为 KEY=VALUE）")

    if dev:
        target = config_file if config_file != "config.env" else ".env.dev"
        _create_plain_interactive(target, pre_fill=parsed_vars)
    else:
        _create_encrypted_interactive(config_file, pre_fill=parsed_vars)


# ── edit ──────────────────────────────────────────────────────


@config_group.command("edit")
@click.option("-f", "--file", "config_file", default=None, help="配置文件路径")
def edit_config(config_file: Optional[str]) -> None:
    """
    交互式编辑配置文件（questionary 菜单）。

    \b
    示例:
        start-cli config edit
        start-cli config edit -f config.env
    """
    from start_cli.cli._config_editor import run_config_editor

    path = config_file or _default_config_path()

    if not os.path.exists(path):
        logger.error(f"配置文件不存在: {path}")
        if click.confirm("是否创建新配置?", default=True):
            _create_encrypted_interactive(path)
        return

    if EncryptedConfig._detect_file_encrypted(path):
        password = getpass.getpass(f"🔑 请输入 {path} 的密码: ")
        try:
            config = EncryptedConfig(path, password)
            run_config_editor(config)
            logger.success("✅ 配置已保存")
        except ValueError:
            logger.error("❌ 密码错误")
    else:
        logger.info(f"明文配置: {path}，请直接用文本编辑器编辑")
        editor = os.environ.get("EDITOR", "nano")
        subprocess.call([editor, path])


# ── show ──────────────────────────────────────────────────────


@config_group.command("show")
@click.option("-f", "--file", "config_file", default=None, help="配置文件路径")
@click.option("--raw", is_flag=True, help="显示原始值（包含敏感信息）")
def show_config(config_file: Optional[str], raw: bool) -> None:
    """
    显示配置内容（默认对敏感字段脱敏）。

    \b
    示例:
        start-cli config show           # 脱敏显示
        start-cli config show --raw     # 完整显示（慎用）
        start-cli config show -f app.env
    """
    path = config_file or _default_config_path()

    if not os.path.exists(path):
        logger.error(f"❌ 配置文件不存在: {path}")
        raise SystemExit(1)

    # 明文文件
    if not EncryptedConfig._detect_file_encrypted(path):
        logger.info(f"📖 明文配置: {path}")
        _display_plain_config(path, masked=not raw)
        return

    # 加密文件
    password = getpass.getpass(f"🔑 请输入 {path} 的密码: ")
    try:
        config = EncryptedConfig(path, password)
        _display_config_dict(config.to_dict(masked=not raw), title=path)
    except ValueError:
        logger.error("❌ 密码错误")
        raise SystemExit(1)


# ── change-password ───────────────────────────────────────────


@config_group.command("change-password")
@click.option("-f", "--file", "config_file", default=None, help="配置文件路径")
def change_password(config_file: Optional[str]) -> None:
    """
    修改加密配置文件的密码，并自动升级到最新加密格式（V3）。

    \b
    示例:
        start-cli config change-password
        start-cli config change-password -f config.env
    """
    path = config_file or _default_config_path()

    if not os.path.exists(path):
        logger.error(f"配置文件不存在: {path}")
        return

    if not EncryptedConfig._detect_file_encrypted(path):
        logger.error("❌ 此文件不是加密配置，无需修改密码")
        return

    old_pwd = getpass.getpass("请输入当前密码: ")
    try:
        config = EncryptedConfig(path, old_pwd)
    except ValueError:
        logger.error("❌ 当前密码错误")
        return

    new_pwd = getpass.getpass("请输入新密码（至少 6 位）: ")
    if len(new_pwd) < 6:
        logger.error("❌ 密码长度不能小于 6 位")
        return

    confirm = getpass.getpass("再次输入新密码确认: ")
    if new_pwd != confirm:
        logger.error("❌ 两次输入的密码不匹配")
        return

    try:
        config.change_password(new_pwd)
        logger.success("✅ 密码修改成功")
        logger.warning("⚠️  请妥善保管新密码，遗失后无法恢复数据！")
    except Exception as exc:
        logger.error(f"💥 修改密码失败: {exc}")


# ── upgrade ───────────────────────────────────────────────────


@config_group.command("upgrade")
@click.option("-f", "--file", "config_file", default=None, help="配置文件路径")
def upgrade_encryption(config_file: Optional[str]) -> None:
    """
    将旧版加密配置（V1 MD5 / V2 PBKDF2 固定盐）升级到 V3（PBKDF2 随机盐）。

    \b
    示例:
        start-cli config upgrade
        start-cli config upgrade -f old.env
    """
    path = config_file or _default_config_path()

    if not os.path.exists(path):
        logger.error(f"配置文件不存在: {path}")
        return

    password = getpass.getpass(f"🔑 请输入 {path} 的密码: ")
    try:
        config = EncryptedConfig(path, password)
    except ValueError:
        logger.error("❌ 密码错误")
        return

    if not config.needs_upgrade():
        logger.info("✅ 配置文件已是最新加密格式（V3），无需升级")
        return

    info = config.get_encryption_info()
    logger.info(f"当前加密版本: {info['version_name']}")

    if not click.confirm("确认升级到 V3（PBKDF2 + 随机盐值）加密格式？", default=True):
        logger.info("操作已取消")
        return

    config.upgrade_encryption()
    logger.success("✅ 加密格式升级成功（V3）")
    logger.info(f"🔐 新加密信息: {config.get_encryption_info()}")


# ── 交互式创建辅助函数 ─────────────────────────────────────────


def _create_plain_interactive(
    config_file: str,
    *,
    pre_fill: Optional[Dict[str, str]] = None,
) -> None:
    """创建明文开发配置（交互式）。"""
    from start_cli.loader.config_loader import create_dev_template

    if os.path.exists(config_file):
        if not click.confirm(f"⚠️  {config_file} 已存在，是否覆盖？", default=False):
            return

    create_dev_template(config_file, extra_vars=pre_fill)
    logger.warning("⚠️  请确保此文件已添加到 .gitignore")


def _create_encrypted_interactive(
    config_file: str,
    *,
    pre_fill: Optional[Dict[str, str]] = None,
) -> None:
    """创建加密配置（交互式）。"""
    if os.path.exists(config_file):
        if not click.confirm(f"⚠️  {config_file} 已存在，是否覆盖？", default=False):
            return

    logger.info(f"正在创建加密配置: {config_file}")

    password = getpass.getpass("设置配置文件密码（至少 6 位）: ")
    if len(password) < 6:
        logger.error("❌ 密码太短，操作取消")
        return
    confirm = getpass.getpass("再次输入密码确认: ")
    if password != confirm:
        logger.error("❌ 两次密码不匹配，操作取消")
        return

    try:
        config = EncryptedConfig.create(config_file, password)

        if pre_fill:
            config.update(pre_fill)

        # 交互式填写常用字段
        common_keys = [
            ("APP_TOKEN", "应用 Token", True),
            ("SERVICE_URL", "服务地址", False),
        ]
        for key, desc, secret in common_keys:
            if key not in config:
                value = click.prompt(
                    f"{desc} ({key})（回车跳过）",
                    default="",
                    hide_input=secret,
                    show_default=False,
                )
                if value:
                    config[key] = value

        config.save()
        logger.success(f"✅ 加密配置已创建: {config_file}")
        logger.info("💡 使用 start-cli config edit 修改配置")
    except Exception as exc:
        logger.error(f"💥 创建配置失败: {exc}")


# ── 内部工具 ─────────────────────────────────────────────────


def _default_config_path() -> str:
    """获取当前环境的默认配置文件路径。"""
    from start_cli.settings.environment import AppSettings

    return AppSettings().get_config_file()


def _display_plain_config(path: str, *, masked: bool = True) -> None:
    """显示明文配置文件内容。"""
    config_dict: Dict[str, str] = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, _, v = line.partition("=")
                    config_dict[k.strip()] = v.strip()
        _display_config_dict(
            (
                EncryptedConfig.__new__(EncryptedConfig).to_dict(masked=masked)
                if False
                else _mask_dict(config_dict, masked=masked)
            ),
            title=path,
        )
    except Exception as exc:
        logger.error(f"读取配置失败: {exc}")


def _mask_dict(data: Dict[str, str], *, masked: bool) -> Dict[str, str]:
    """对敏感字段脱敏。"""
    if not masked:
        return data
    sensitive = EncryptedConfig.SENSITIVE_KEYWORDS
    result: Dict[str, str] = {}
    for k, v in data.items():
        if any(kw in k.lower() for kw in sensitive):
            result[k] = "********" + v[-4:] if len(v) > 4 else "********"
        else:
            result[k] = v
    return result


def _display_config_dict(data: Dict[str, str], *, title: str = "") -> None:
    """打印配置字典（表格格式）。"""
    logger.info("=" * 60)
    if title:
        logger.info(f"📋 配置文件: {title}")
    logger.info("=" * 60)
    if not data:
        logger.warning("⚠️  未找到任何配置项")
        return
    for key in sorted(data.keys()):
        logger.info(f"  {key:<30} = {data[key]}")
    logger.info("=" * 60)
    logger.info(f"共 {len(data)} 项")
