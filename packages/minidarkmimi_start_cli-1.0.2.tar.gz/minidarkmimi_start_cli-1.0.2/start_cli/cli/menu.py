"""
交互式终端菜单模块（TUI）

基于 ``simple_term_menu`` 提供可配置的交互式菜单界面。
适合不熟悉命令行的用户，通过方向键选择操作。

功能:
- 主菜单（启动应用 / 配置管理 / 诊断 / 帮助 / 退出）
- 应用启动子菜单（快速模式 / 自定义参数 / 生产模式）
- 配置管理子菜单（创建 / 编辑 / 查看 / 改密）
- 环境诊断（Python 信息 / 依赖检查 / 配置状态）

使用方式::

    from start_cli.cli.menu import InteractiveMenu

    menu = InteractiveMenu(
        app_name="My Bot",
        app_callable=my_main_function,
        config_file="config.env",
        dependencies=[("telegram", "python-telegram-bot"), ("click", "click")],
        required_env_vars=["BOT_TOKEN", "SERVICE_URL"],
    )
    menu.run()

    # 或者使用快捷函数
    from start_cli.cli.menu import run_interactive_menu
    run_interactive_menu(app_name="My Bot", app_callable=my_main_function)
"""

import os
import platform
import sys
from importlib import import_module
from typing import Callable, Dict, List, Optional, Tuple

import click
from loguru import logger


class InteractiveMenu:
    """
    交互式终端菜单控制器。

    Attributes:
        app_name (str): 应用名称，显示在横幅中。
        app_callable (Callable): 应用启动函数（加载配置后调用）。
        config_file (str): 默认配置文件路径。
        banner (str): 自定义横幅文本；为 None 时使用默认横幅。
        dependencies (list): 依赖检查列表，格式 [(模块名, 显示名), ...]。
        required_env_vars (list): 需要在诊断中显示的环境变量列表。

    Example::

        menu = InteractiveMenu(
            app_name="My Telegram Bot",
            app_callable=start_bot,
        )
        menu.run()
    """

    def __init__(
        self,
        app_name: str = "App",
        app_callable: Optional[Callable] = None,
        config_file: Optional[str] = None,
        banner: Optional[str] = None,
        dependencies: Optional[List[Tuple[str, str]]] = None,
        required_env_vars: Optional[List[str]] = None,
    ) -> None:
        """
        初始化交互式菜单。

        Args:
            app_name: 显示在横幅和菜单标题中的应用名称。
            app_callable: 点击「启动应用」时调用的函数。
            config_file: 配置文件默认路径（用于配置管理子菜单）。
            banner: 自定义 ASCII 横幅；为 None 时自动生成。
            dependencies: 诊断时检查的依赖列表，``[(module_name, display_name), ...]``。
            required_env_vars: 诊断时显示的环境变量名列表。
        """
        self.app_name = app_name
        self.app_callable = app_callable
        self.config_file = config_file
        self.banner = banner or self._default_banner(app_name)
        self.dependencies: List[Tuple[str, str]] = dependencies or [
            ("click", "click"),
            ("loguru", "loguru"),
            ("dotenv", "python-dotenv"),
            ("cryptography", "cryptography"),
        ]
        self.required_env_vars: List[str] = required_env_vars or []

    # ── 主入口 ────────────────────────────────────────────────

    def run(self) -> None:
        """
        启动交互式菜单主循环，直到用户选择退出。

        Example::

            menu.run()
        """
        while True:
            self._clear()
            self._show_banner()
            print("请选择操作:\n")

            options = [
                "🚀 启动应用",
                "⚙️  配置管理",
                "🔍 环境诊断",
                "📚 查看帮助",
                "❌ 退出",
            ]

            choice = self._menu(options)

            if choice is None or choice == 4:
                print("\n👋 再见！\n")
                sys.exit(0)
            elif choice == 0:
                self._startup_menu()
            elif choice == 1:
                self._config_menu()
            elif choice == 2:
                self._doctor()
                input("\n按回车键返回主菜单...")
            elif choice == 3:
                self._help()
                input("\n按回车键返回主菜单...")

    # ── 启动子菜单 ────────────────────────────────────────────

    def _startup_menu(self) -> None:
        """应用启动子菜单。"""
        self._clear()
        self._show_banner()
        print(f"🚀 启动 {self.app_name}\n")

        options = [
            "⚡ 开发模式（快速启动，DEBUG=true）",
            "🔧 自定义启动参数",
            "🏭 生产模式启动",
            "🔙 返回主菜单",
        ]

        choice = self._menu(options)

        if choice is None or choice == 3:
            return

        if choice == 0:
            self._start_dev()
        elif choice == 1:
            self._start_custom()
        elif choice == 2:
            self._start_production()

    def _start_dev(self) -> None:
        """开发模式启动。"""
        print("\n✨ 正在以开发模式启动...\n")
        os.environ["APP_ENV"] = "development"
        os.environ["BOT_ENV"] = "development"
        os.environ["DEBUG"] = "true"
        self._invoke_app()

    def _start_production(self) -> None:
        """生产模式启动。"""
        self._clear()
        self._show_banner()
        print("🏭 生产模式启动\n")
        print("⚠️  注意事项:")
        print("  - 需要提供加密配置文件密码")
        print("  - 启用完整安全检查")
        print("  - 调试功能将被禁用\n")

        if not click.confirm("确认以生产模式启动?", default=False):
            return

        if self.config_file:
            cf = click.prompt("配置文件路径", default=self.config_file, show_default=True)
            os.environ["CONFIG_FILE"] = cf

        os.environ["APP_ENV"] = "production"
        os.environ["BOT_ENV"] = "production"
        os.environ.pop("DEBUG", None)
        print("\n🚀 正在启动生产模式...\n")
        self._invoke_app()

    def _start_custom(self) -> None:
        """自定义启动参数菜单。"""
        self._clear()
        self._show_banner()
        print("🔧 自定义启动参数\n")

        # 选择环境
        env_opts = ["Development（开发）", "Staging（预发）", "Production（生产）"]
        env_map = ["development", "staging", "production"]
        env_idx = self._menu(env_opts, title="1️⃣ 选择运行环境:") or 0
        selected_env = env_map[env_idx]
        print(f"   ✓ 环境: {env_opts[env_idx]}\n")

        # 配置文件
        cf = click.prompt(
            "2️⃣ 配置文件路径（回车使用默认）",
            default=self.config_file or "",
            show_default=False,
        )

        # 功能开关
        print("\n3️⃣ 功能开关:")
        enable_sync = click.confirm("   启用后端同步?", default=True)
        enable_mock = click.confirm("   启用 Mock 服务?", default=False)
        enable_reload = click.confirm("   启用自动重载?", default=False)

        # 确认
        print("\n" + "=" * 50)
        print(f"  环境: {selected_env}")
        if cf:
            print(f"  配置文件: {cf}")
        print(f"  后端同步: {'✓' if enable_sync else '✗'}")
        print(f"  Mock 服务: {'✓' if enable_mock else '✗'}")
        print(f"  自动重载: {'✓' if enable_reload else '✗'}")
        print("=" * 50 + "\n")

        if not click.confirm("确认启动?", default=True):
            return

        os.environ["APP_ENV"] = selected_env
        os.environ["BOT_ENV"] = selected_env
        if cf:
            os.environ["CONFIG_FILE"] = cf
        if not enable_sync:
            os.environ["ENABLE_SYNC"] = "false"
        if enable_mock:
            os.environ["MOCK_SERVICES"] = "true"
        if enable_reload:
            os.environ["AUTO_RELOAD"] = "true"

        self._invoke_app()

    def _invoke_app(self) -> None:
        """调用应用启动函数。"""
        if self.app_callable is None:
            logger.warning("⚠️  未配置应用启动函数 (app_callable=None)")
            input("\n按回车键返回...")
            return
        try:
            self.app_callable()
        except KeyboardInterrupt:
            logger.warning("\n⚠️  应用被用户中断")
        except Exception as exc:
            logger.exception(f"💥 应用异常: {exc}")
            input("\n按回车键返回...")

    # ── 配置管理子菜单 ────────────────────────────────────────

    def _config_menu(self) -> None:
        """配置管理子菜单。"""
        self._clear()
        self._show_banner()
        print("⚙️  配置管理\n")

        options = [
            "📝 创建新配置文件",
            "✏️  修改配置（交互式）",
            "👁️  查看配置（脱敏）",
            "🔑 修改配置密码",
            "🔙 返回主菜单",
        ]

        choice = self._menu(options)

        if choice is None or choice == 4:
            return

        from start_cli.cli.config_cmds import (
            _create_encrypted_interactive,
            _create_plain_interactive,
        )

        if choice == 0:
            # 创建配置
            self._clear()
            self._show_banner()
            types = ["🔓 明文配置（开发用）", "🔐 加密配置（生产推荐）"]
            t = self._menu(types, title="选择配置类型:")
            cf = click.prompt(
                "配置文件名",
                default=self.config_file or ("config.env" if t == 1 else ".env.dev"),
                show_default=True,
            )
            if t == 0:
                _create_plain_interactive(cf)
            else:
                _create_encrypted_interactive(cf)
            input("\n按回车键返回...")

        elif choice == 1:
            # 修改配置
            self._clear()
            self._show_banner()
            cf = click.prompt(
                "配置文件路径",
                default=self.config_file or "config.env",
                show_default=True,
            )
            from click import Context
            from start_cli.cli.config_cmds import edit_config
            ctx = Context(edit_config)
            ctx.invoke(edit_config, config_file=cf)
            input("\n按回车键返回...")

        elif choice == 2:
            # 查看配置
            self._clear()
            self._show_banner()
            cf = click.prompt(
                "配置文件路径",
                default=self.config_file or "config.env",
                show_default=True,
            )
            raw = click.confirm("显示完整值（含敏感信息）?", default=False)
            from click import Context
            from start_cli.cli.config_cmds import show_config
            ctx = Context(show_config)
            ctx.invoke(show_config, config_file=cf, raw=raw)
            input("\n按回车键返回...")

        elif choice == 3:
            # 修改密码
            self._clear()
            self._show_banner()
            cf = click.prompt(
                "配置文件路径",
                default=self.config_file or "config.env",
                show_default=True,
            )
            from click import Context
            from start_cli.cli.config_cmds import change_password
            ctx = Context(change_password)
            ctx.invoke(change_password, config_file=cf)
            input("\n按回车键返回...")

    # ── 诊断 ──────────────────────────────────────────────────

    def _doctor(self) -> None:
        """环境诊断。"""
        self._clear()
        self._show_banner()
        print("🔍 环境诊断\n")

        click.echo("=" * 60)
        click.echo("🔍 环境诊断报告")
        click.echo("=" * 60)

        # Python 信息
        click.echo(f"\n📌 Python 信息:")
        click.echo(f"  版本   : {platform.python_version()}")
        click.echo(f"  路径   : {sys.executable}")
        click.echo(f"  平台   : {platform.platform()}")

        # 工作目录
        click.echo(f"\n📁 工作目录:")
        click.echo(f"  {os.getcwd()}")

        # 环境变量
        if self.required_env_vars:
            click.echo(f"\n🌍 关键环境变量:")
            for var in self.required_env_vars:
                value = os.environ.get(var, "未设置")
                if ("TOKEN" in var.upper() or "SECRET" in var.upper() or "PASSWORD" in var.upper()):
                    if value != "未设置":
                        value = value[:8] + "***" if len(value) > 8 else "***"
                click.echo(f"  {var:<25} = {value}")

        # 配置文件
        click.echo(f"\n📄 配置文件状态:")
        check_files = []
        if self.config_file:
            check_files.append(self.config_file)
        check_files += [".env.dev", "config.env"]
        for cf in dict.fromkeys(check_files):  # 去重保序
            if os.path.exists(cf):
                size = os.path.getsize(cf)
                click.echo(f"  ✅ {cf:<30} ({size:,} bytes)")
            else:
                click.echo(f"  ⚪ {cf:<30} (不存在)")

        # 依赖检查
        click.echo(f"\n📦 依赖包状态:")
        for mod_name, display_name in self.dependencies:
            try:
                mod = import_module(mod_name)
                version = getattr(mod, "__version__", "已安装")
                click.echo(f"  ✅ {display_name:<35} {version}")
            except ImportError:
                is_optional = "可选" in display_name
                status = "⚠️  可选" if is_optional else "❌ 缺失"
                click.echo(f"  {status} {display_name}")

        click.echo("\n" + "=" * 60)
        click.echo("💡 诊断完成")
        click.echo("=" * 60)

    # ── 帮助 ──────────────────────────────────────────────────

    def _help(self) -> None:
        """显示帮助信息。"""
        self._clear()
        self._show_banner()

        print("📚 使用帮助\n")
        help_text = f"""
🎯 快速开始:
    1. 首次使用：「配置管理」→「创建新配置文件」
    2. 填写应用所需配置项（Token、URL 等）
    3. 返回主菜单 → 「启动应用」

💡 推荐工作流:
    开发测试 → 「开发模式启动」（明文配置，快速迭代）
    生产部署 → 「生产模式启动」（加密配置，严格安全）

⚙️  配置文件说明:
    明文配置  (.env.dev)   - 开发用，不需要密码
    加密配置  (config.env) - 生产用，需要密码保护

🔐 加密版本:
    当前使用 V3 加密（PBKDF2-SHA256 + 随机盐值 + Fernet AES-128）
    旧版配置可通过「config upgrade」命令升级

📝 命令行方式（适合熟悉命令行的用户）:
    python cli.py dev           # 开发模式启动
    python cli.py run           # 生产模式启动
    python cli.py config --help # 配置管理帮助
    python cli.py doctor        # 环境诊断

🌐 环境变量:
    APP_ENV / BOT_ENV  - 环境名称 (development/staging/production)
    DEBUG              - 调试模式 (true/false)
    CONFIG_FILE        - 配置文件路径（覆盖默认值）
    CONFIG_PASSWORD    - 配置文件密码（自动化场景使用）
"""
        print(help_text)

    # ── 内部工具 ──────────────────────────────────────────────

    @staticmethod
    def _clear() -> None:
        """清屏。"""
        os.system("cls" if os.name == "nt" else "clear")

    def _show_banner(self) -> None:
        """打印横幅。"""
        print(self.banner)

    @staticmethod
    def _menu(
        options: List[str],
        title: str = "",
        cycle: bool = True,
    ) -> Optional[int]:
        """
        显示 simple_term_menu 菜单并返回选中索引。

        Args:
            options: 菜单选项列表。
            title: 菜单标题（可选）。
            cycle: 是否循环选择（默认 True）。

        Returns:
            选中的索引（从 0 开始），用户取消时返回 None。
        """
        try:
            from simple_term_menu import TerminalMenu

            menu = TerminalMenu(
                options,
                title=title,
                cycle_cursor=cycle,
                clear_screen=False,
            )
            return menu.show()
        except ImportError:
            # 降级到 click.prompt 数字选择
            if title:
                print(title)
            for i, opt in enumerate(options, 1):
                print(f"  {i}. {opt}")
            raw = click.prompt(
                "请输入序号",
                type=click.IntRange(1, len(options)),
                default=1,
            )
            return raw - 1

    @staticmethod
    def _default_banner(app_name: str) -> str:
        """生成默认横幅文字。"""
        border = "═" * (len(app_name) + 10)
        return f"""
╔{border}╗
║     {app_name}     ║
╚{border}╝
"""


def run_interactive_menu(
    app_name: str = "App",
    app_callable: Optional[Callable] = None,
    config_file: Optional[str] = None,
    banner: Optional[str] = None,
    dependencies: Optional[List[Tuple[str, str]]] = None,
    required_env_vars: Optional[List[str]] = None,
) -> None:
    """
    快捷函数：启动交互式菜单。

    Args:
        app_name: 应用名称。
        app_callable: 点击「启动应用」时调用的函数。
        config_file: 默认配置文件路径。
        banner: 自定义横幅文本。
        dependencies: 诊断时检查的依赖列表。
        required_env_vars: 诊断时显示的环境变量列表。

    Example::

        from start_cli.cli.menu import run_interactive_menu

        run_interactive_menu(
            app_name="My Telegram Bot",
            app_callable=start_bot,
            config_file="config.env",
            required_env_vars=["BOT_TOKEN", "SERVICE_URL"],
        )
    """
    InteractiveMenu(
        app_name=app_name,
        app_callable=app_callable,
        config_file=config_file,
        banner=banner,
        dependencies=dependencies,
        required_env_vars=required_env_vars,
    ).run()
