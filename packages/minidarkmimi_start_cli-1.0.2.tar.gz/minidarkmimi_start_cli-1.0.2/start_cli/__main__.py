"""Package-level CLI entry point for the published start_cli distribution."""

from __future__ import annotations

import click

from start_cli import __version__


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(__version__, prog_name="start-cli")
def cli() -> None:
    """Utilities for the published start_cli package."""


@cli.command()
def about() -> None:
    """Show a short introduction to the package."""
    click.echo("start_cli is a secure launcher and encrypted config bootstrap library.")
    click.echo("Use it as a library in your project, or visit the docs on GitHub:")
    click.echo("https://github.com/minidarkmimi/start_cli_public")


def main() -> None:
    """Run the package-level CLI."""
    cli()


if __name__ == "__main__":
    main()
