"""
start_cli - secure launcher toolkit for Python projects
======================================================

提供配置加密管理、交互式 CLI 菜单、智能配置加载三大核心功能，
适用于需要安全启动流程的 Python 项目。

核心模块:
    crypto      加密配置管理（EncryptedConfig / ConfigManager）
    settings    环境配置（AppSettings / Environment）
    loader      智能配置加载（ConfigLoader / load_config）
    cli         Click CLI 工厂 + TUI 菜单（create_cli / run_interactive_menu）
    utils       日志配置、脱敏工具（setup_logger / mask_sensitive）

快速开始::

    # 1. 创建加密配置
    from start_cli import EncryptedConfig
    cfg = EncryptedConfig.create("myapp.env", password="s3cr3t")
    cfg["API_TOKEN"] = "tok_xxx"
    cfg.save()

    # 2. 加载配置并注入环境变量
    cfg = EncryptedConfig("myapp.env", password="s3cr3t")
    cfg.init_dotenv()

    # 3. 一键构建完整 CLI
    from start_cli import create_cli
    cli = create_cli(
        app_name="My Bot",
        app_callable=start_app,
        required_envs={"API_TOKEN": "API Token"},
    )
    cli()  # 运行

    # 4. 启动 TUI 交互式菜单
    from start_cli import run_interactive_menu
    run_interactive_menu(app_name="My Bot", app_callable=start_app)
"""

__version__ = "1.0.2"
__author__ = "minidarkmimi"
__license__ = "MIT"

# ── 核心导出 ─────────────────────────────────────────────────

# 加密配置
from start_cli.crypto.config_manager import ConfigManager, EncryptedConfig

# 环境设置
from start_cli.settings.environment import AppSettings, Environment

# 智能配置加载
from start_cli.loader.config_loader import (
    ConfigLoader,
    create_dev_template,
    ensure_gitignore,
    load_config,
)

# CLI 工厂 + 交互菜单
from start_cli.cli.factory import create_cli
from start_cli.cli.menu import InteractiveMenu, run_interactive_menu
from start_cli.cli.config_cmds import config_group

# 工具函数
from start_cli.utils.helpers import mask_sensitive, setup_logger

__all__ = [
    # ── 加密配置 ──
    "EncryptedConfig",
    "ConfigManager",          # 别名
    # ── 环境设置 ──
    "AppSettings",
    "Environment",
    # ── 配置加载 ──
    "ConfigLoader",
    "load_config",
    "create_dev_template",
    "ensure_gitignore",
    # ── CLI ──────
    "create_cli",
    "config_group",
    "InteractiveMenu",
    "run_interactive_menu",
    # ── 工具 ─────
    "setup_logger",
    "mask_sensitive",
    # ── 元数据 ───
    "__version__",
    "__author__",
]
