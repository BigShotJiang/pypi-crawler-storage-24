"""
环境配置管理模块

提供以下核心功能:
- ``Environment`` 枚举：标准化的环境类型定义（development / staging / production）
- ``AppSettings`` 类：通用应用配置，支持从环境变量加载、类型安全读取、完整性验证

此模块不依赖任何具体业务逻辑，可直接在任何 Python 项目中复用。

典型用法::

    from start_cli.settings import AppSettings, Environment

    # 读取当前环境（BOT_ENV 环境变量）
    settings = AppSettings()
    print(settings.environment)  # Environment.DEVELOPMENT

    # 自定义必需字段和业务字段
    class MySettings(AppSettings):
        def load_from_env(self) -> None:
            super().load_from_env()
            self.my_token = os.environ.get("MY_TOKEN")
            self.my_url = os.environ.get("MY_URL")

        def validate(self) -> None:
            super().validate()
            if not self.my_token:
                raise ValueError("MY_TOKEN 未设置")
"""

import os
from enum import Enum
from typing import Dict, List, Optional

from loguru import logger


class Environment(str, Enum):
    """
    应用运行环境枚举。

    继承 ``str``，可直接与字符串比较::

        env = Environment.DEVELOPMENT
        assert env == "development"
        assert env.value == "development"
    """

    DEVELOPMENT = "development"
    """开发环境：宽松安全策略，详细日志，允许交互输入。"""

    STAGING = "staging"
    """预发布环境：接近生产配置，用于最终测试。"""

    PRODUCTION = "production"
    """生产环境：严格安全策略，禁止 Mock/调试功能。"""

    @classmethod
    def from_str(
        cls, value: str, default: Optional["Environment"] = None
    ) -> "Environment":
        """
        从字符串解析环境，无效值时返回默认值。

        Args:
            value: 环境名称字符串（大小写不敏感）。
            default: 无效值时的回退环境；默认 DEVELOPMENT。

        Returns:
            对应的 Environment 枚举值。

        Example::

            env = Environment.from_str("production")
            # Environment.PRODUCTION
        """
        default = default or cls.DEVELOPMENT
        try:
            return cls(value.lower().strip())
        except (ValueError, AttributeError):
            return default


class AppSettings:
    """
    通用应用配置类。

    从环境变量中读取配置，提供类型安全的属性访问和完整性验证。
    可通过子类扩展自定义字段。

    环境变量说明:
        APP_ENV / BOT_ENV:
            运行环境，取值 development / staging / production。
            优先读取 APP_ENV，回退到 BOT_ENV，默认 development。
        DEBUG:
            是否开启调试模式（true/false）。开发环境默认 true。
        LOG_LEVEL:
            日志级别（DEBUG/INFO/WARNING/ERROR）。
        AUTO_RELOAD:
            启用文件监听热重载（需安装 watchdog）。
        MOCK_SERVICES:
            使用 Mock 服务（仅开发环境）。
        SKIP_PASSWORD:
            跳过配置文件密码验证（仅开发环境）。
        CONFIG_FILE:
            配置文件路径（覆盖默认值）。
        LOG_TO_FILE:
            是否将日志写入文件。

    Example::

        settings = AppSettings()
        if settings.is_development:
            print("开发模式")
        settings.load_from_env()
        settings.validate()
    """

    #: 环境变量名称（按优先级）
    ENV_VAR_NAMES: List[str] = ["APP_ENV", "BOT_ENV"]

    #: 各环境的默认配置文件名
    DEFAULT_CONFIG_FILES: Dict[str, str] = {
        "development": ".env.dev",
        "staging": "config.staging.env",
        "production": "config.env",
    }

    def __init__(self) -> None:
        """
        初始化 AppSettings，从环境变量读取基础配置。

        所有属性均有默认值，调用 ``load_from_env()`` 可刷新从环境变量中读取的值。
        """
        # ── 环境类型 ──────────────────────────────────────────
        env_name = self._read_env_name()
        self.environment: Environment = Environment.from_str(env_name)

        # ── 功能开关（从环境变量读取） ─────────────────────────
        self.debug: bool = self._bool_env("DEBUG", default=self.is_development)
        self.log_level: str = os.environ.get(
            "LOG_LEVEL", "DEBUG" if self.is_development else "INFO"
        )
        self.auto_reload: bool = self._bool_env("AUTO_RELOAD", default=False)
        self.mock_services: bool = self._bool_env("MOCK_SERVICES", default=False)
        self.skip_password: bool = self._bool_env("SKIP_PASSWORD", default=False)
        self.log_to_file: bool = self._bool_env("LOG_TO_FILE", default=True)

    # ── 环境属性 ─────────────────────────────────────────────

    @property
    def is_development(self) -> bool:
        """当前是否为开发环境。"""
        return self.environment == Environment.DEVELOPMENT

    @property
    def is_staging(self) -> bool:
        """当前是否为预发布环境。"""
        return self.environment == Environment.STAGING

    @property
    def is_production(self) -> bool:
        """当前是否为生产环境。"""
        return self.environment == Environment.PRODUCTION

    # ── 配置文件路径 ──────────────────────────────────────────

    def get_config_file(self) -> str:
        """
        获取当前环境的默认配置文件路径。

        优先级:
        1. ``CONFIG_FILE`` 环境变量
        2. ``DEFAULT_CONFIG_FILES[environment]``

        Returns:
            配置文件路径字符串。

        Example::

            os.environ["CONFIG_FILE"] = "/etc/myapp/prod.env"
            path = settings.get_config_file()  # "/etc/myapp/prod.env"
        """
        if explicit := os.environ.get("CONFIG_FILE"):
            return explicit
        return self.DEFAULT_CONFIG_FILES.get(self.environment.value, "config.env")

    def requires_encryption(self) -> bool:
        """
        当前环境是否必须使用加密配置。

        规则:
        - 生产环境: 强制加密（忽略 SKIP_PASSWORD）。
        - 其他环境: ``SKIP_PASSWORD=true`` 时可跳过。

        Returns:
            True 表示需要加密配置。
        """
        if self.is_production:
            return True
        return not self.skip_password

    # ── 数据加载与验证 ────────────────────────────────────────

    def load_from_env(self) -> None:
        """
        从 ``os.environ`` 刷新配置到实例属性。

        此方法设计为可被子类覆盖，用于加载业务特定配置::

            class MySettings(AppSettings):
                def load_from_env(self) -> None:
                    super().load_from_env()
                    self.api_key = os.environ.get("MY_API_KEY")

        通常在 ``config.init_dotenv()`` 之后调用。
        """
        self.debug = self._bool_env("DEBUG", default=self.is_development)
        self.log_level = os.environ.get(
            "LOG_LEVEL", "DEBUG" if self.is_development else "INFO"
        )
        self.auto_reload = self._bool_env("AUTO_RELOAD", default=False)
        self.mock_services = self._bool_env("MOCK_SERVICES", default=False)
        self.skip_password = self._bool_env("SKIP_PASSWORD", default=False)
        self.log_to_file = self._bool_env("LOG_TO_FILE", default=True)

    def validate(self) -> None:
        """
        验证配置完整性。

        在生产环境中施加额外约束::
        - 禁止 mock_services
        - 禁止 skip_password
        - 禁止 auto_reload

        Raises:
            ValueError: 验证失败，消息包含所有错误详情。

        Example::

            try:
                settings.validate()
            except ValueError as e:
                print(f"配置错误: {e}")
        """
        errors: List[str] = []

        if self.is_production:
            if self.mock_services:
                errors.append("生产环境禁止启用 MOCK_SERVICES")
            if self.skip_password:
                errors.append("生产环境禁止跳过密码验证 (SKIP_PASSWORD)")
            if self.auto_reload:
                errors.append("生产环境禁止启用 AUTO_RELOAD")

        if errors:
            raise ValueError("配置验证失败:\n" + "\n".join(f"  - {e}" for e in errors))

    # ── 打印与调试 ────────────────────────────────────────────

    def print_banner(self, app_name: str = "App") -> None:
        """
        打印环境信息横幅（使用 loguru 输出）。

        Args:
            app_name: 应用名称，显示在横幅中。

        Example::

            settings.print_banner("My Telegram Bot")
        """
        icons = {
            Environment.DEVELOPMENT: "🟢",
            Environment.STAGING: "🟡",
            Environment.PRODUCTION: "🔴",
        }
        icon = icons.get(self.environment, "⚪")

        logger.info("=" * 60)
        logger.info(f"  {app_name}")
        logger.info(f"{icon} 运行环境: {self.environment.value.upper()}")
        logger.info(f"📝 日志级别: {self.log_level}")
        logger.info(f"🔧 调试模式: {'✅ 开启' if self.debug else '❌ 关闭'}")

        if self.is_development:
            logger.warning("⚠️  开发模式：部分安全检查已禁用")
        if self.mock_services:
            logger.warning("🎭 Mock 模式：使用模拟数据")
        if self.auto_reload:
            logger.info("🔄 自动重载：代码变更时自动重启")

        logger.info("=" * 60)

    def to_dict(self) -> Dict[str, object]:
        """
        将配置导出为字典（用于序列化或调试）。

        Returns:
            配置键值字典。
        """
        return {
            "environment": self.environment.value,
            "debug": self.debug,
            "log_level": self.log_level,
            "auto_reload": self.auto_reload,
            "mock_services": self.mock_services,
            "skip_password": self.skip_password,
            "log_to_file": self.log_to_file,
            "config_file": self.get_config_file(),
        }

    def __repr__(self) -> str:
        return (
            f"AppSettings(env={self.environment.value!r}, "
            f"debug={self.debug}, log_level={self.log_level!r})"
        )

    # ── 内部工具 ──────────────────────────────────────────────

    def _read_env_name(self) -> str:
        """按优先级读取环境名称环境变量，默认 development。"""
        for var in self.ENV_VAR_NAMES:
            if value := os.environ.get(var):
                return value
        return "development"

    @staticmethod
    def _bool_env(key: str, *, default: bool = False) -> bool:
        """
        从环境变量读取布尔值。

        Args:
            key: 环境变量名。
            default: 变量未设置或值无法识别时的默认值。

        Returns:
            布尔值。
        """
        raw = os.environ.get(key, "").lower().strip()
        if raw in ("true", "1", "yes", "on"):
            return True
        if raw in ("false", "0", "no", "off"):
            return False
        return default
