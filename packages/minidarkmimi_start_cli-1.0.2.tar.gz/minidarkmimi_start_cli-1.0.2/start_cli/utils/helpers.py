"""
通用工具函数

提供日志配置、字符串脱敏、脚本生成等实用功能。
"""

import os
import sys
from typing import Dict, Iterable, Optional

from loguru import logger


def setup_logger(
    level: str = "INFO",
    *,
    to_file: bool = False,
    log_dir: str = "logs",
    rotation: str = "10 MB",
    retention: str = "7 days",
    fmt: Optional[str] = None,
) -> None:
    """
    配置 loguru 日志系统。

    重置所有已有 handler，然后按参数重新添加。

    Args:
        level: 日志级别（DEBUG / INFO / WARNING / ERROR / CRITICAL）。
        to_file: 是否同时写入日志文件。
        log_dir: 日志文件目录（当 to_file=True 时有效）。
        rotation: 日志轮转条件，如 ``"10 MB"`` 或 ``"1 day"``。
        retention: 日志保留时长，如 ``"7 days"``。
        fmt: 自定义日志格式；为 None 时使用内置格式。

    Example::

        setup_logger("DEBUG", to_file=True, log_dir="logs")
    """
    default_fmt = (
        "<green>[{time:YYYY-MM-DD HH:mm:ss}]</green> "
        "<level>{level:<8}</level> "
        "<cyan>{name}</cyan>:<cyan>{line}</cyan> - "
        "{message}"
    )
    console_fmt = fmt or default_fmt

    logger.remove()
    logger.add(
        sys.stderr,
        format=console_fmt,
        level=level,
        colorize=True,
    )

    if to_file:
        os.makedirs(log_dir, exist_ok=True)
        logger.add(
            os.path.join(log_dir, "{time:YYYY-MM-DD}.log"),
            format=default_fmt,
            level=level,
            rotation=rotation,
            retention=retention,
            encoding="utf-8",
        )
        logger.debug(f"日志文件将写入: {log_dir}/")


def mask_sensitive(
    data: Dict[str, str],
    keywords: Optional[Iterable[str]] = None,
    *,
    show_last: int = 4,
    mask_char: str = "*",
    mask_len: int = 8,
) -> Dict[str, str]:
    """
    对字典中的敏感字段进行脱敏处理。

    Args:
        data: 原始键值字典。
        keywords: 敏感关键词列表（大小写不敏感，匹配键名）；默认为常见敏感词。
        show_last: 保留原始值末尾的字符数（默认 4）。
        mask_char: 掩码字符（默认 ``*``）。
        mask_len: 掩码长度（默认 8）。

    Returns:
        脱敏后的新字典（不修改原字典）。

    Example::

        data = {"API_TOKEN": "abc123xyz", "USERNAME": "admin"}
        safe = mask_sensitive(data)
        # {"API_TOKEN": "********xyz", "USERNAME": "admin"}
    """
    default_kws = ("pass", "password", "token", "secret", "key", "auth", "credential")
    kws = tuple(kw.lower() for kw in (keywords or default_kws))

    result: Dict[str, str] = {}
    for k, v in data.items():
        if any(kw in k.lower() for kw in kws):
            if len(v) > show_last:
                result[k] = mask_char * mask_len + v[-show_last:]
            else:
                result[k] = mask_char * mask_len
        else:
            result[k] = v
    return result


def generate_startup_script(
    filename: str,
    env: str = "development",
    *,
    app_env_var: str = "APP_ENV",
    extra_envs: Optional[Dict[str, str]] = None,
    python_cmd: str = "python",
    cli_script: str = "cli.py",
    cli_subcommand: str = "dev",
) -> None:
    """
    生成 Bash 启动脚本。

    Args:
        filename: 输出文件名（如 ``dev.sh``）。
        env: 目标环境名称（development / staging / production）。
        app_env_var: 设置的环境变量名（默认 ``APP_ENV``）。
        extra_envs: 额外的环境变量字典。
        python_cmd: Python 可执行文件路径（默认 ``python``）。
        cli_script: CLI 脚本文件名（默认 ``cli.py``）。
        cli_subcommand: 子命令（默认 ``dev``）。

    Example::

        generate_startup_script("start.sh", env="production", cli_subcommand="run")
    """
    lines = [
        "#!/bin/bash",
        f"# 启动脚本 - {env} 环境（由 start_cli 自动生成）",
        "",
        f"export {app_env_var}={env}",
    ]
    # 若应用使用不同的环境变量名，同时写入 BOT_ENV 作为兼容别名
    if app_env_var != "BOT_ENV":
        lines.append(f"export BOT_ENV={env}")

    if env == "development":
        lines += ["export DEBUG=true", "export AUTO_RELOAD=true"]

    if extra_envs:
        lines.append("")
        for k, v in extra_envs.items():
            lines.append(f"export {k}={v}")

    lines += ["", f"{python_cmd} {cli_script} {cli_subcommand}"]

    content = "\n".join(lines) + "\n"

    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)
    os.chmod(filename, 0o755)

    logger.success(f"✅ 启动脚本已生成: {filename}")
