"""
加密配置管理模块

提供基于 Fernet (AES-128-CBC) + PBKDF2 的配置文件加解密功能。
支持多版本兼容，可从旧版本透明升级到最新加密格式。

加密版本说明:
    - V1: MD5 哈希密钥（已弃用，仅向后兼容读取）
    - V2: PBKDF2 + 固定盐值（向后兼容读取，写入时自动升级）
    - V3: PBKDF2 + 随机盐值（推荐，当前默认）

V3 文件格式::

    [MAGIC_HEADER_V3][salt_length: 4 bytes big-endian][salt: N bytes][Fernet ciphertext]

典型使用场景::

    # 创建加密配置
    config = EncryptedConfig.create("myapp.env", password="s3cr3t")
    config["API_KEY"] = "abc123"
    config["DB_URL"] = "postgresql://localhost/mydb"
    config.save()

    # 读取加密配置并注入环境变量
    config = EncryptedConfig("myapp.env", password="s3cr3t")
    config.init_dotenv()  # 所有配置项写入 os.environ

    # 从明文文件导入并加密
    config = EncryptedConfig.create("myapp.env", password="s3cr3t")
    config.import_from_plain("myapp.env.template")
    config.save()
"""

import base64
import hashlib
import io
import os
import secrets
from typing import Dict, Iterator, Optional, Tuple

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from dotenv import load_dotenv


class EncryptedConfig:
    """
    加密配置管理器。

    以键值对形式存储配置，数据使用 Fernet 对称加密保存到磁盘。
    密钥通过 PBKDF2-HMAC-SHA256（随机盐值）从用户密码派生。

    Attributes:
        filename (str): 配置文件路径。
        VERSION_MD5 (int): 加密版本1 - MD5 密钥（已弃用）。
        VERSION_PBKDF2 (int): 加密版本2 - PBKDF2 固定盐值。
        VERSION_PBKDF2_RANDOM_SALT (int): 加密版本3 - PBKDF2 随机盐值（推荐）。

    Example::

        config = EncryptedConfig("app.env", password="mypassword")
        config["KEY"] = "value"
        config.save()
        print(config["KEY"])  # "value"
    """

    # ── 加密版本常量 ─────────────────────────────────────────
    VERSION_MD5: int = 1
    """V1: MD5 哈希密钥（已弃用，仅向后兼容）"""

    VERSION_PBKDF2: int = 2
    """V2: PBKDF2 + 固定盐值（向后兼容）"""

    VERSION_PBKDF2_RANDOM_SALT: int = 3
    """V3: PBKDF2 + 随机盐值（推荐）"""

    # ── PBKDF2 参数 ──────────────────────────────────────────
    PBKDF2_ITERATIONS: int = 480_000
    """PBKDF2 迭代次数，遵循 OWASP 2023 推荐值"""

    PBKDF2_FIXED_SALT: bytes = b"start-cli-config-salt-v1"
    """V2 兼容用固定盐值（不再用于新配置）"""

    SALT_SIZE: int = 32
    """随机盐值字节长度"""

    MAGIC_HEADER_V3: bytes = b"START_CLI_CFG_V3:"
    """V3 文件魔数头标识"""

    LEGACY_V3_HEADERS: Tuple[bytes, ...] = (
        b"START_CLI_CFG_V3:",
        b"NIUNIU_CONFIG_V3:",  # 兼容旧版 niuniu-telegram-bot 项目
    )
    """所有已知的 V3 魔数头（含旧项目兼容头，长度必须一致均为 17 字节）"""

    # ── 敏感字段关键词（用于脱敏显示） ───────────────────────
    SENSITIVE_KEYWORDS: Tuple[str, ...] = (
        "pass",
        "password",
        "token",
        "secret",
        "key",
        "auth",
    )

    def __init__(
        self,
        filename: str,
        password: str,
        *,
        create: bool = False,
    ) -> None:
        """
        初始化加密配置管理器。

        Args:
            filename: 配置文件路径。
            password: 加密/解密密码。
            create: 为 True 时创建新的空配置文件（文件存在则覆盖）。

        Raises:
            ValueError: 密码错误（加载已有文件时）。
            FileNotFoundError: 文件不存在且 create=False。

        Example::

            # 加载已有配置
            cfg = EncryptedConfig("app.env", password="secret")

            # 创建新配置
            cfg = EncryptedConfig("app.env", password="secret", create=True)
        """
        self._data: Dict[str, str] = {}
        self.filename: str = filename
        self._password: str = password
        self._version: int = self.VERSION_PBKDF2_RANDOM_SALT
        self._salt: Optional[bytes] = None
        self._needs_upgrade: bool = False
        self._cipher: Fernet = self._make_key(password, version=self._version)

        if create:
            self.save()
        else:
            self._load()

    # ── 工厂方法 ────────────────────────────────────────────

    @classmethod
    def create(cls, filename: str, password: str) -> "EncryptedConfig":
        """
        创建新的加密配置文件（工厂方法）。

        等同于 ``EncryptedConfig(filename, password, create=True)``，
        语义更清晰。

        Args:
            filename: 配置文件路径。
            password: 加密密码（建议至少 8 位）。

        Returns:
            新建的 EncryptedConfig 实例，文件已写入磁盘。

        Example::

            cfg = EncryptedConfig.create("myapp.env", password="strongpwd")
            cfg["API_KEY"] = "abc"
            cfg.save()
        """
        return cls(filename, password, create=True)

    # ── 内部密钥派生 ────────────────────────────────────────

    def _make_key(
        self,
        password: str,
        version: Optional[int] = None,
        salt: Optional[bytes] = None,
    ) -> Fernet:
        """
        从密码派生 Fernet 加密密钥。

        Args:
            password: 用户密码。
            version: 加密版本号；为 None 时使用当前实例版本。
            salt: 已有盐值（仅在读取 V3 文件时传入）。

        Returns:
            配置好的 Fernet 实例。
        """
        if version is None:
            version = self._version

        if version == self.VERSION_PBKDF2_RANDOM_SALT:
            if salt is None:
                # 新建配置：生成随机盐值
                salt = secrets.token_bytes(self.SALT_SIZE)
                self._salt = salt
            else:
                # 加载已有配置：使用文件中存储的盐值
                self._salt = salt

            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=self.PBKDF2_ITERATIONS,
            )

        elif version == self.VERSION_PBKDF2:
            self._salt = self.PBKDF2_FIXED_SALT
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=self.PBKDF2_FIXED_SALT,
                iterations=self.PBKDF2_ITERATIONS,
            )

        else:
            # V1: MD5（向后兼容，不再使用）
            md5_key = self._md5(password).encode()
            key = base64.urlsafe_b64encode(md5_key)
            self._key = key
            return Fernet(key)

        key = base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8")))
        self._key = key
        return Fernet(key)

    @staticmethod
    def _md5(text: str) -> str:
        """计算 MD5 哈希（仅供 V1 向后兼容）。"""
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    @staticmethod
    def _strip_quotes(value: str) -> str:
        """剥离 .env 值的首尾引号（与 python-dotenv 行为一致）。"""
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            return value[1:-1]
        return value

    # ── 加载 ────────────────────────────────────────────────

    def _load(self) -> None:
        """
        从磁盘加载并解密配置文件。

        自动检测文件版本（V1/V2/V3）并选择对应的解密策略。
        如果检测到旧版本，标记 ``_needs_upgrade = True``。

        Raises:
            ValueError: 密码错误（InvalidToken）。
            FileNotFoundError: 文件不存在。
        """
        try:
            with open(self.filename, "rb") as f:
                raw = f.read()
        except FileNotFoundError:
            raise FileNotFoundError(f"配置文件不存在: {self.filename}")

        decrypted = self._decrypt_raw(raw)

        # 解析 KEY=VALUE 格式
        for line in decrypted.decode("utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            key, _, value = line.partition("=")
            self._data[key.strip()] = self._strip_quotes(value.strip())

    def _decrypt_raw(self, raw: bytes) -> bytes:
        """
        根据文件内容自动选择解密策略。

        Args:
            raw: 文件原始字节内容。

        Returns:
            解密后的明文字节。

        Raises:
            ValueError: 密码错误。
        """
        # V3：文件以已知魔数头开始（支持新旧两种头，均为 17 字节）
        if any(raw.startswith(h) for h in self.LEGACY_V3_HEADERS):
            return self._decrypt_v3(raw)

        # V2/V1：尝试 PBKDF2 固定盐值
        try:
            cipher = self._make_key(self._password, version=self.VERSION_PBKDF2)
            data = cipher.decrypt(raw)
            self._version = self.VERSION_PBKDF2
            self._cipher = cipher
            self._needs_upgrade = True
            return data
        except InvalidToken:
            pass

        # V1：尝试 MD5 密钥
        try:
            cipher = self._make_key(self._password, version=self.VERSION_MD5)
            data = cipher.decrypt(raw)
            self._version = self.VERSION_MD5
            self._cipher = cipher
            self._needs_upgrade = True
            return data
        except InvalidToken:
            raise ValueError("Incorrect password")

    def _decrypt_v3(self, raw: bytes) -> bytes:
        """
        解密 V3 格式文件。

        V3 格式: ``[MAGIC_HEADER][salt_len: 4B big-endian][salt][ciphertext]``

        Args:
            raw: 文件原始字节。

        Returns:
            解密后的明文字节。

        Raises:
            ValueError: 密码错误。
        """
        header_len = len(self.MAGIC_HEADER_V3)
        salt_length = int.from_bytes(raw[header_len : header_len + 4], "big")
        salt_start = header_len + 4
        salt_end = salt_start + salt_length
        salt = raw[salt_start:salt_end]
        ciphertext = raw[salt_end:]

        cipher = self._make_key(
            self._password, version=self.VERSION_PBKDF2_RANDOM_SALT, salt=salt
        )
        try:
            data = cipher.decrypt(ciphertext)
            self._version = self.VERSION_PBKDF2_RANDOM_SALT
            self._cipher = cipher
            return data
        except InvalidToken:
            raise ValueError("Incorrect password")

    # ── 保存 ────────────────────────────────────────────────

    def save(self) -> None:
        """
        将当前配置加密后写入磁盘。

        V3 格式写入: ``[MAGIC_HEADER][salt_len][salt][ciphertext]``
        旧版本（V1/V2）写入: ``[ciphertext]``（保持原格式）。

        Note:
            若文件已存在，将先删除再写入（原子替换）。
        """
        plain_text = "".join(self._iter_lines()).encode("utf-8")
        ciphertext = self._cipher.encrypt(plain_text)

        # 确保目录存在
        parent = os.path.dirname(self.filename)
        if parent:
            os.makedirs(parent, exist_ok=True)

        if self._version == self.VERSION_PBKDF2_RANDOM_SALT:
            if self._salt is None:
                # 安全兜底：重新生成盐值
                self._cipher = self._make_key(
                    self._password, version=self.VERSION_PBKDF2_RANDOM_SALT
                )
                ciphertext = self._cipher.encrypt(plain_text)
            header_bytes = (
                self.MAGIC_HEADER_V3
                + len(self._salt).to_bytes(4, "big")  # type: ignore[arg-type]
                + self._salt  # type: ignore[arg-type]
            )
            payload = header_bytes + ciphertext
        else:
            # V1/V2 向后兼容保存
            payload = ciphertext

        # 原子写入：写临时文件后用 os.replace() 替换，避免中断导致数据丢失
        tmp_path = self.filename + ".tmp"
        try:
            with open(tmp_path, "wb") as f:
                f.write(payload)
            os.replace(tmp_path, self.filename)
        except Exception:
            # 清理临时文件，重新抛出
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise

    # ── 密码管理 ────────────────────────────────────────────

    def change_password(self, new_password: str) -> None:
        """
        修改配置文件密码，并自动升级到最新加密版本（V3）。

        Args:
            new_password: 新密码（建议至少 8 位）。

        Raises:
            ValueError: 新密码长度不足 6 位。

        Example::

            cfg = EncryptedConfig("app.env", password="oldpwd")
            cfg.change_password("newstrongpwd")
            # 文件已用新密码重新加密
        """
        if len(new_password) < 6:
            raise ValueError("密码长度不能小于 6 位")
        self._password = new_password
        self._version = self.VERSION_PBKDF2_RANDOM_SALT
        self._cipher = self._make_key(
            new_password, version=self.VERSION_PBKDF2_RANDOM_SALT
        )
        self.save()

    def upgrade_encryption(self) -> bool:
        """
        将配置文件升级到最新加密版本（V3，PBKDF2 + 随机盐值）。

        Returns:
            True 表示升级成功，False 表示已是最新版本。

        Example::

            cfg = EncryptedConfig("old.env", password="pwd")
            if cfg.needs_upgrade():
                cfg.upgrade_encryption()
                print("已升级到 V3 加密格式")
        """
        if self._version == self.VERSION_PBKDF2_RANDOM_SALT:
            return False
        self._version = self.VERSION_PBKDF2_RANDOM_SALT
        self._cipher = self._make_key(
            self._password, version=self.VERSION_PBKDF2_RANDOM_SALT
        )
        self.save()
        self._needs_upgrade = False
        return True

    # ── 环境变量注入 ─────────────────────────────────────────

    def init_dotenv(self, *, override: bool = False) -> None:
        """
        将所有配置项写入 ``os.environ``（注入当前进程环境变量）。

        默认情况下不会覆盖已有同名环境变量；如需覆盖，请传入
        ``override=True``。

        Example::

            cfg = EncryptedConfig("app.env", password="pwd")
            cfg.init_dotenv()
            import os
            print(os.environ.get("API_KEY"))  # 配置中的值
        """
        load_dotenv(stream=self._to_stream(), override=override)

    def _to_stream(self) -> io.StringIO:
        """将配置数据转换为 dotenv 格式的 StringIO 流。"""
        return io.StringIO("".join(self._iter_lines()))

    # ── 导入/导出 ────────────────────────────────────────────

    def import_from_plain(self, file_path: str) -> None:
        """
        从明文 .env 文件导入配置项（合并到当前配置，不覆盖已有键）。

        Args:
            file_path: 明文 .env 文件路径。

        Example::

            cfg = EncryptedConfig.create("app.env", password="pwd")
            cfg.import_from_plain(".env.template")
            cfg.save()
        """
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                key, _, value = line.partition("=")
                self._data.setdefault(key.strip(), self._strip_quotes(value.strip()))

    def export_to_plain(self, file_path: str, *, masked: bool = False) -> None:
        """
        将配置导出为明文 .env 文件。

        Args:
            file_path: 输出文件路径。
            masked: 为 True 时对敏感字段进行脱敏（仅用于调试/显示）。

        Warning:
            导出的明文文件包含敏感信息，请勿提交到版本控制！
        """
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("# 由 start_cli 导出的配置（明文）\n")
            f.write("# ⚠️  请勿提交到版本控制！\n\n")
            for line in self._iter_lines(masked=masked):
                f.write(line)

    def to_dict(self, *, masked: bool = True) -> Dict[str, str]:
        """
        将配置以字典形式返回。

        Args:
            masked: 为 True 时对敏感字段进行脱敏（默认 True）。

        Returns:
            配置键值字典。
        """
        result: Dict[str, str] = {}
        for key, value in self._data.items():
            if masked and any(kw in key.lower() for kw in self.SENSITIVE_KEYWORDS):
                value = "*" * 8 + value[-4:] if len(value) > 4 else "********"
            result[key] = value
        return result

    # ── 版本/诊断信息 ─────────────────────────────────────────

    def get_version(self) -> int:
        """返回当前配置文件的加密版本号。"""
        return self._version

    def needs_upgrade(self) -> bool:
        """返回 True 表示配置文件使用旧版本加密，可调用 upgrade_encryption() 升级。"""
        return self._needs_upgrade

    def get_encryption_info(self) -> Dict[str, object]:
        """
        获取加密详情（用于诊断/调试）。

        Returns:
            包含版本号、盐值信息的字典。
        """
        version_names = {
            self.VERSION_MD5: "V1 (MD5, 已弃用)",
            self.VERSION_PBKDF2: "V2 (PBKDF2 + 固定盐值)",
            self.VERSION_PBKDF2_RANDOM_SALT: "V3 (PBKDF2 + 随机盐值, 推荐)",
        }
        info: Dict[str, object] = {
            "version": self._version,
            "version_name": version_names.get(self._version, f"未知 ({self._version})"),
            "needs_upgrade": self._needs_upgrade,
            "pbkdf2_iterations": self.PBKDF2_ITERATIONS,
        }
        if self._salt:
            info["salt_length"] = len(self._salt)
            info["salt_hex_preview"] = self._salt.hex()[:16] + "..."
            info["is_random_salt"] = self._version == self.VERSION_PBKDF2_RANDOM_SALT
        return info

    # ── 内部迭代 ─────────────────────────────────────────────

    def _iter_lines(self, *, masked: bool = False) -> Iterator[str]:
        """生成 KEY=VALUE 行序列（供序列化使用）。"""
        for key, value in self._data.items():
            if masked and any(kw in key.lower() for kw in self.SENSITIVE_KEYWORDS):
                value = "*" * 8 + value[-4:] if len(value) > 4 else "********"
            yield f"{key}={value}\n"

    # ── 字典接口 ─────────────────────────────────────────────

    def __getitem__(self, key: str) -> str:
        """获取配置项，键不存在时抛出 KeyError（与 dict 行为一致）。"""
        return self._data[key]

    def __setitem__(self, key: str, value: str) -> None:
        """设置配置项。"""
        self._data[key] = value

    def __delitem__(self, key: str) -> None:
        """删除配置项。"""
        del self._data[key]

    def __contains__(self, key: object) -> bool:
        """支持 ``key in config`` 语法。"""
        return key in self._data

    def __len__(self) -> int:
        """返回配置项数量。"""
        return len(self._data)

    def __str__(self) -> str:
        """返回脱敏后的配置字符串（用于打印）。"""
        return "".join(self._iter_lines(masked=True))

    def __repr__(self) -> str:
        return f"EncryptedConfig(filename={self.filename!r}, version=V{self._version}, items={len(self)})"

    def items(self):  # noqa: D102
        """返回 (key, value) 迭代器（与 dict.items() 兼容）。"""
        return self._data.items()

    def keys(self):  # noqa: D102
        """返回配置键迭代器。"""
        return self._data.keys()

    def get(self, key: str, default: str = "") -> str:
        """获取配置项，不存在时返回 default。"""
        return self._data.get(key, default)

    def update(self, data: Dict[str, str]) -> None:
        """批量更新配置项。"""
        self._data.update(data)

    # ── 上下文管理器 ─────────────────────────────────────────

    def __enter__(self) -> "EncryptedConfig":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if exc_type is None:
            self.save()

    # ── 文件类型检测（静态工具） ──────────────────────────────

    @staticmethod
    def _detect_file_encrypted(path: str) -> bool:
        """
        通过读取文件头检测是否为加密格式。

        Args:
            path: 文件路径。

        Returns:
            True 表示加密文件，False 表示明文文件。
        """
        try:
            with open(path, "rb") as f:
                header = f.read(128)
            if header.startswith(b"gAAAAA"):
                return True
            for magic in (b"START_CLI_CFG_V3:", b"NIUNIU_CONFIG_V3:"):
                if header.startswith(magic):
                    return True
            try:
                header.decode("utf-8")
                if b"=" in header:
                    return False
            except UnicodeDecodeError:
                pass
            return True
        except Exception:
            return False


# 向后兼容别名
ConfigManager = EncryptedConfig
"""EncryptedConfig 的别名，便于迁移旧代码。"""
