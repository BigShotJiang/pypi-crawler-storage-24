"""
配置加载模块

提供智能配置加载逻辑，支持:
- 自动检测明文 / 加密配置文件
- 密码重试机制（最多 N 次）
- 环境变量注入
- 必需环境变量验证
- 开发配置模板生成
- .gitignore 自动维护

典型用法::

    from start_cli.loader import ConfigLoader

    # 全自动加载（根据 settings 决定加载方式）
    loader = ConfigLoader(settings)
    loader.load()         # 自动选择明文或加密
    loader.validate_env(required={"API_KEY": "API 密钥", "DB_URL": "数据库地址"})

    # 也可直接使用快捷函数
    from start_cli.loader import load_config
    load_config("config.env")  # 自动检测并加载
"""

import os
import sys
from typing import Callable, Dict, List, Optional, Union

import click
from dotenv import load_dotenv
from loguru import logger

from start_cli.crypto.config_manager import EncryptedConfig
from start_cli.settings.environment import AppSettings


class ConfigLoader:
    """
    智能配置加载器。

    根据文件类型（明文/加密）、当前环境、环境变量自动选择加载策略。

    Args:
        settings: AppSettings 实例；为 None 时自动创建。
        max_password_attempts: 密码重试最大次数（默认 3）。

    Example::

        from start_cli.settings import AppSettings
        from start_cli.loader import ConfigLoader

        settings = AppSettings()
        loader = ConfigLoader(settings)
        loader.load("config.env")
    """

    def __init__(
        self,
        settings: Optional[AppSettings] = None,
        max_password_attempts: int = 3,
    ) -> None:
        self.settings: AppSettings = settings or AppSettings()
        self.max_password_attempts: int = max_password_attempts
        self._loaded_config: Optional[EncryptedConfig] = None

    # ── 主入口 ────────────────────────────────────────────────

    def load(
        self,
        config_file: Optional[str] = None,
        *,
        force_plain: bool = False,
        force_encrypted: bool = False,
    ) -> Optional[EncryptedConfig]:
        """
        智能加载配置文件并注入环境变量。

        自动检测策略（无 force_* 时）:
        1. 检查文件头是否包含 Fernet 密文或 MAGIC_HEADER → 加密
        2. 包含 ``=`` 的可读文本行 → 明文
        3. 开发环境 + .dev / .env 后缀 → 倾向明文

        Args:
            config_file: 配置文件路径；为 None 时从 settings 获取默认路径。
            force_plain: 强制使用明文加载（跳过自动检测）。
            force_encrypted: 强制使用加密加载（跳过自动检测）。

        Returns:
            加载成功时返回 EncryptedConfig 实例（明文加载时返回 None）。

        Raises:
            FileNotFoundError: 文件不存在且无法创建（非开发环境）。
            SystemExit: 密码错误次数超过限制。
        """
        path = config_file or self.settings.get_config_file()

        logger.info(f"🌍 运行环境: {self.settings.environment.value}")
        logger.info(f"📄 配置文件: {path}")

        # 文件不存在处理
        if not os.path.exists(path):
            self._handle_missing_file(path)

        # 确定加载方式
        if force_plain:
            self._load_plain(path)
            return None
        elif force_encrypted:
            return self._load_encrypted(path)
        else:
            if self._detect_encrypted(path):
                return self._load_encrypted(path)
            else:
                self._load_plain(path)
                return None

    # ── 明文加载 ─────────────────────────────────────────────

    def _load_plain(self, path: str) -> None:
        """
        加载明文 .env 文件，注入环境变量。

        Args:
            path: 明文配置文件路径。
        """
        logger.info("📖 使用明文配置加载（开发模式）")
        try:
            load_dotenv(path, override=True)
            logger.success(f"✅ 明文配置加载成功: {path}")
        except Exception as exc:
            logger.error(f"加载明文配置失败: {exc}")
            raise

    # ── 加密加载 ─────────────────────────────────────────────

    def _load_encrypted(self, path: str) -> EncryptedConfig:
        """
        加载加密配置，支持密码重试与自动升级。

        优先使用 ``CONFIG_PASSWORD`` 环境变量；若不存在则交互式询问。

        Args:
            path: 加密配置文件路径。

        Returns:
            解密成功的 EncryptedConfig 实例。

        Raises:
            SystemExit: 超过最大密码尝试次数。
        """
        logger.info("🔐 使用加密配置加载")

        password: Optional[str] = os.environ.get("CONFIG_PASSWORD")
        attempt = 0

        while attempt < self.max_password_attempts:
            try:
                if not password:
                    remaining = self.max_password_attempts - attempt
                    prompt = (
                        "🔑 请输入配置文件密码"
                        if attempt == 0
                        else f"❌ 密码错误，请重试 (剩余 {remaining} 次)"
                    )
                    password = click.prompt(prompt, hide_input=True)

                config = EncryptedConfig(path, password)
                config.init_dotenv()

                # 缓存正确密码，避免后续重复输入
                os.environ["CONFIG_PASSWORD"] = password

                # 检查并提示升级
                if config.needs_upgrade():
                    logger.warning(
                        "⚠️  配置文件使用旧版加密格式，建议运行 config upgrade-encryption 升级"
                    )

                logger.success(f"✅ 加密配置加载成功: {path}")
                self._loaded_config = config
                return config

            except ValueError as exc:
                if str(exc) == "Incorrect password":
                    attempt += 1
                    password = None
                    if attempt >= self.max_password_attempts:
                        logger.critical(
                            f"🚫 密码错误次数过多（{self.max_password_attempts} 次），程序退出"
                        )
                        sys.exit(1)
                else:
                    logger.error(f"配置解析错误: {exc}")
                    raise

            except FileNotFoundError:
                logger.error(f"配置文件不存在: {path}")
                raise

            except Exception as exc:
                logger.error(f"加载配置时发生未知错误: {exc}")
                raise

        # 此处逻辑上不可达（sys.exit 保证不会走出循环），保留作为安全兜底
        sys.exit(1)  # pragma: no cover

    # ── 文件格式检测 ──────────────────────────────────────────

    @staticmethod
    def _detect_encrypted(path: str) -> bool:
        """
        通过文件头检测是否为加密配置。

        检测规则:
        - 以 ``gAAAAA``（Fernet 密文前缀）开头 → 加密
        - 以 ``START_CLI_CFG_V3:`` 等魔数头开头 → 加密
        - 包含 ``=`` 且可 UTF-8 解码 → 明文

        Args:
            path: 文件路径。

        Returns:
            True 表示加密文件。
        """
        try:
            with open(path, "rb") as f:
                header = f.read(128)

            # Fernet V1/V2 密文以 base64 字符开头
            if header.startswith(b"gAAAAA"):
                return True

            # 检查所有已知魔数头
            known_headers = (
                b"START_CLI_CFG_V3:",
                b"NIUNIU_CONFIG_V3:",  # 兼容旧项目
            )
            for magic in known_headers:
                if header.startswith(magic):
                    return True

            # 如果是可读 UTF-8 文本且含有 = → 明文
            try:
                header.decode("utf-8")
                if b"=" in header:
                    return False
            except UnicodeDecodeError:
                pass

            # 无法确定 → 尝试加密
            return True

        except Exception:
            return False

    # ── 缺失文件处理 ──────────────────────────────────────────

    def _handle_missing_file(self, path: str) -> None:
        """
        处理配置文件不存在的情况。

        开发环境: 提示是否创建模板文件。
        非开发环境: 直接抛出 FileNotFoundError。

        Args:
            path: 不存在的配置文件路径。

        Raises:
            FileNotFoundError: 非开发环境或用户拒绝创建。
        """
        if self.settings.is_development:
            logger.warning(f"⚠️  配置文件不存在: {path}")
            if click.confirm("📝 是否创建开发配置模板？", default=True):
                create_dev_template(path)
                logger.info("请编辑配置文件后重新启动")
                sys.exit(0)
            else:
                raise FileNotFoundError(f"配置文件不存在: {path}")
        else:
            logger.error(f"🚫 生产配置文件不存在: {path}")
            raise FileNotFoundError(f"配置文件不存在: {path}")

    # ── 环境变量验证 ──────────────────────────────────────────

    def validate_env(
        self,
        required: Optional[Dict[str, str]] = None,
        optional: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        验证必需和可选的环境变量。

        Args:
            required: ``{环境变量名: 描述}`` 字典，缺失时报错（生产环境退出）。
            optional: ``{环境变量名: 描述}`` 字典，缺失时仅警告。

        Raises:
            SystemExit: 生产环境中必需变量缺失。

        Example::

            loader.validate_env(
                required={"BOT-TOKEN": "Telegram Bot Token", "DB_URL": "数据库地址"},
                optional={"SENTRY_DSN": "Sentry 错误追踪"},
            )
        """
        required = required or {}
        optional = optional or {}

        missing_required: List[str] = [
            f"{k} ({v})" for k, v in required.items() if not os.environ.get(k)
        ]

        if missing_required:
            logger.critical("❌ 缺少必需环境变量:")
            for item in missing_required:
                logger.critical(f"   - {item}")

            if not self.settings.is_development:
                logger.critical("💀 非开发环境禁止交互式输入，程序退出")
                sys.exit(1)

            logger.warning("⚠️  开发模式：尝试交互式补全...")
            for key, desc in required.items():
                if not os.environ.get(key):
                    value = click.prompt(
                        f"请输入 {desc} ({key})",
                        hide_input=(
                            "TOKEN" in key.upper() or "PASSWORD" in key.upper()
                        ),
                    )
                    os.environ[key] = value

        for key, desc in optional.items():
            if not os.environ.get(key):
                logger.warning(f"⚠️  可选变量未设置: {key} ({desc})")

        logger.success("✅ 环境变量验证通过")

    @property
    def loaded_config(self) -> Optional[EncryptedConfig]:
        """最近一次加载的 EncryptedConfig 实例（明文加载时为 None）。"""
        return self._loaded_config


# ── 便捷函数 ────────────────────────────────────────────────────


def load_config(
    config_file: Optional[str] = None,
    settings: Optional[AppSettings] = None,
    max_password_attempts: int = 3,
) -> Optional[EncryptedConfig]:
    """
    快捷函数：一行加载配置。

    Args:
        config_file: 配置文件路径；为 None 时从 settings 自动推断。
        settings: AppSettings 实例；为 None 时自动创建。
        max_password_attempts: 密码重试次数（默认 3）。

    Returns:
        加密配置时返回 EncryptedConfig，明文配置时返回 None。

    Example::

        from start_cli.loader import load_config
        load_config()                         # 全自动
        load_config("myapp.env")              # 指定文件
        load_config("config.env", settings)   # 指定 settings
    """
    loader = ConfigLoader(settings, max_password_attempts=max_password_attempts)
    return loader.load(config_file)


def create_dev_template(
    output_path: str,
    *,
    extra_vars: Optional[Dict[str, str]] = None,
    app_name: str = "MyApp",
) -> None:
    """
    生成开发配置模板文件（明文 .env 格式）。

    模板包含常用配置项的示例和说明注释，方便开发者快速上手。

    Args:
        output_path: 模板文件输出路径。
        extra_vars: 额外的配置项（将追加到模板末尾）。
        app_name: 应用名称，用于注释标题。

    Example::

        create_dev_template(".env.dev", extra_vars={"MY_API": "your_api_key"})
    """
    extra_section = ""
    if extra_vars:
        extra_section = "\n# ============= 自定义配置 =============\n"
        for k, v in extra_vars.items():
            extra_section += f"{k}={v}\n"

    template = f"""# {app_name} - 开发环境配置（明文）
# ⚠️  此文件包含敏感信息，请勿提交到版本控制！
# 已添加到 .gitignore

# ============= 应用核心配置 =============
# 请替换为真实值

# APP_TOKEN=your_token_here
# SERVICE_URL=http://localhost:8000
# SERVICE_TOKEN=dev_token_123
# APP_MANAGERS=123456789

# ============= 运行环境 =============
APP_ENV=development
DEBUG=true
LOG_LEVEL=DEBUG

# ============= 开发特性 =============
# 自动重载（需安装 watchdog）
AUTO_RELOAD=false

# 使用 Mock 数据（开发测试）
MOCK_SERVICES=false

# 跳过配置文件密码（仅开发）
SKIP_PASSWORD=true

# ============= 功能开关 =============
LOG_TO_FILE=true
{extra_section}"""

    parent = os.path.dirname(output_path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(template)

    logger.success(f"✅ 开发配置模板已创建: {output_path}")
    logger.warning("⚠️  请编辑文件并填入真实配置值")


def ensure_gitignore(
    patterns: Optional[List[str]] = None,
    gitignore_path: str = ".gitignore",
) -> None:
    """
    确保敏感配置文件已添加到 .gitignore。

    若 .gitignore 不存在则自动创建；只添加尚未存在的条目。

    Args:
        patterns: 要添加的文件名/通配符列表；默认为常见敏感文件模式。
        gitignore_path: .gitignore 文件路径，默认为当前目录。

    Example::

        ensure_gitignore()
        ensure_gitignore(["secrets.env", "*.key"], gitignore_path=".gitignore")
    """
    default_patterns = [
        ".env.dev",
        ".env.local",
        ".env.*.local",
        "config.env",
        "config.*.env",
        "*.log",
        "logs/",
        "__pycache__/",
        "*.pyc",
        ".venv/",
        "venv/",
    ]
    targets = patterns or default_patterns

    if not os.path.exists(gitignore_path):
        logger.warning(f"⚠️  {gitignore_path} 不存在，正在创建...")
        with open(gitignore_path, "w", encoding="utf-8") as f:
            f.write("# 自动生成的 .gitignore\n\n")

    with open(gitignore_path, "r", encoding="utf-8") as f:
        existing = f.read()

    # 按行匹配，避免子串误判（如 config.env 被 config.staging.env 误判为已存在）
    existing_lines = {line.strip() for line in existing.splitlines()}
    to_add = [p for p in targets if p not in existing_lines]

    if to_add:
        with open(gitignore_path, "a", encoding="utf-8") as f:
            f.write("\n# 敏感配置文件（由 start_cli 自动添加）\n")
            for pattern in to_add:
                f.write(f"{pattern}\n")
        logger.info(f"✅ 已向 {gitignore_path} 添加 {len(to_add)} 条规则")
