"""Packaging configuration for publishing start_cli to PyPI."""

from pathlib import Path

from setuptools import find_packages, setup

HERE = Path(__file__).parent
README = (HERE / "README_PYPI.md").read_text(encoding="utf-8")

INSTALL_REQUIRES = [
    "click>=8.1.0",
    "loguru>=0.7.0",
    "python-dotenv>=1.0.0",
    "cryptography>=41.0.0",
    "colorama>=0.4.6",
    "questionary>=2.0.0",
]

EXTRAS_REQUIRE = {
    "tui": [
        "simple_term_menu>=1.6.0",
    ],
    "dev": [
        "simple_term_menu>=1.6.0",
        "pytest>=7.0.0",
        "pytest-cov>=4.0.0",
        "black>=23.0.0",
        "isort>=5.12.0",
        "mypy>=1.0.0",
        "flake8>=6.0.0",
        "build>=1.2.0",
        "twine>=5.1.0",
    ],
}

setup(
    name="minidarkmimi-start-cli",
    version="1.0.2",
    description="Secure launcher and encrypted config bootstrap library for Python projects",
    long_description=README,
    long_description_content_type="text/markdown",
    author="minidarkmimi",
    license="MIT",
    url="https://github.com/minidarkmimi/start_cli_public",
    project_urls={
        "Source": "https://github.com/minidarkmimi/start_cli_public",
        "Issues": "https://github.com/minidarkmimi/start_cli_public/issues",
        "Security": "https://github.com/minidarkmimi/start_cli_public/security/policy",
    },
    python_requires=">=3.10",
    packages=find_packages(exclude=["tests*", "examples*"]),
    include_package_data=True,
    package_data={
        "start_cli": ["py.typed"],
    },
    install_requires=INSTALL_REQUIRES,
    extras_require=EXTRAS_REQUIRE,
    entry_points={
        "console_scripts": [
            "start-cli=start_cli.__main__:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Operating System :: MacOS",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Typing :: Typed",
    ],
    keywords=[
        "secure launcher",
        "secure startup",
        "encrypted env",
        "encrypted dotenv",
        "config encryption",
        "click cli",
        "bootstrap cli",
    ],
)
