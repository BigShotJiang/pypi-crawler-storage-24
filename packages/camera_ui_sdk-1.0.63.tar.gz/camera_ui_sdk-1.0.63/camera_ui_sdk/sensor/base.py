from __future__ import annotations

import asyncio
import contextlib
import time
from abc import ABC, abstractmethod
from collections.abc import Callable, Mapping
from enum import Enum
from typing import (
    TYPE_CHECKING,
    Any,
    Generic,
    NotRequired,
    Protocol,
    TypeAlias,
    TypedDict,
    TypeVar,
    runtime_checkable,
)
from uuid import uuid4

from ..observable import Observable, Subject
from ..utils import is_equal

if TYPE_CHECKING:
    from ..storage import DeviceStorage, JsonSchema
    from .audio import AudioProperty
    from .battery import BatteryCapability, BatteryProperty
    from .classifier import ClassifierProperty
    from .contact import ContactProperty
    from .doorbell import DoorbellProperty
    from .face import FaceProperty
    from .license_plate import LicensePlateProperty
    from .light import LightCapability, LightProperty
    from .motion import MotionProperty
    from .object import ObjectProperty
    from .ptz import PTZCapability, PTZProperty
    from .security_system import SecuritySystemProperty
    from .siren import SirenCapability, SirenProperty
    from .spec import ModelSpec
    from .switch import SwitchProperty

    SensorPropertyType: TypeAlias = (
        AudioProperty
        | BatteryProperty
        | ClassifierProperty
        | ContactProperty
        | DoorbellProperty
        | FaceProperty
        | LicensePlateProperty
        | LightProperty
        | MotionProperty
        | ObjectProperty
        | PTZProperty
        | SecuritySystemProperty
        | SirenProperty
        | SwitchProperty
    )

    SensorCapability: TypeAlias = PTZCapability | LightCapability | SirenCapability | BatteryCapability


class SensorType(str, Enum):
    """Type of sensor. Each maps to a smart-home concept (HomeKit service)."""

    Motion = "motion"  # Video-based motion detection
    Object = "object"  # Object detection (person, vehicle, animal, etc.)
    Audio = "audio"  # Audio event detection (glass break, scream, etc.)
    Face = "face"  # Face detection and recognition
    LicensePlate = "licensePlate"  # License plate detection and OCR
    Classifier = "classifier"  # General-purpose image classifier
    Contact = "contact"  # Contact/open-close sensor (door, window)
    Light = "light"  # Light on/off and brightness control
    Siren = "siren"  # Siren on/off and volume control
    Switch = "switch"  # Generic on/off switch
    PTZ = "ptz"  # Pan-tilt-zoom camera control
    SecuritySystem = "securitySystem"  # Security system arm/disarm control
    Doorbell = "doorbell"  # Doorbell ring trigger
    Battery = "battery"  # Battery level and charging state


class SensorCategory(str, Enum):
    """Categorizes a sensor's role in the system."""

    Sensor = "sensor"  # Read-only detection sensor
    Control = "control"  # Controllable sensor with set methods
    Trigger = "trigger"  # Event trigger
    Info = "info"  # Informational read-only state


class PropertyChangedEvent(TypedDict):
    """Emitted when a sensor property value changes."""

    cameraId: str
    sensorId: str
    sensorType: SensorType
    property: str
    value: object
    previousValue: NotRequired[object]
    timestamp: int


class SensorPropertyChangeData(TypedDict):
    """Emitted on the onPropertyChanged Observable."""

    property: str
    value: object


PropertyUpdateFn = Callable[[str, Any], None]
PropertyChangeListener = Callable[[PropertyChangedEvent], None]
CapabilityUpdateFn = Callable[[list[str]], None]


@runtime_checkable
class SensorLike(Protocol):
    """Read-only proxy interface for a sensor. Use this type when consuming sensors, not creating them."""

    @property
    def id(self) -> str: ...
    @property
    def type(self) -> SensorType: ...
    @property
    def name(self) -> str: ...
    @property
    def pluginId(self) -> str | None: ...
    @property
    def capabilities(self) -> list[str]: ...

    @property
    def displayName(self) -> str: ...
    @displayName.setter
    def displayName(self, value: str) -> None: ...

    def getPropertyValue(self, property: str) -> Any | None: ...
    def getAllPropertyValues(self) -> dict[str, Any]: ...
    async def setPropertyValue(self, property: str, value: Any) -> None: ...
    @property
    def onPropertyChanged(self) -> Observable[Any]: ...
    @property
    def onCapabilitiesChanged(self) -> Observable[Any]: ...
    def hasCapability(self, capability: str) -> bool: ...


class SensorJSON(TypedDict):
    """JSON-serializable representation of a sensor for RPC transport."""

    id: str
    type: SensorType
    name: str
    displayName: str
    category: SensorCategory
    cameraId: str
    pluginId: NotRequired[str]
    properties: dict[str, Any]
    capabilities: NotRequired[list[str]]
    requiresFrames: NotRequired[bool]
    modelSpec: NotRequired[ModelSpec]


TProperties = TypeVar("TProperties", bound=Mapping[str, Any])
TStorage = TypeVar("TStorage", bound=Mapping[str, Any])
TCapability = TypeVar("TCapability", bound=str)


class PropertiesProxy(Generic[TProperties]):
    """Reactive property proxy. Assignments automatically notify the backend and listeners if values changed (deep-compared)."""

    _store: dict[str, Any]
    _on_change: Callable[[str, Any, Any], None]

    def __init__(
        self,
        store: dict[str, Any],
        on_change: Callable[[str, Any, Any], None],
    ) -> None:
        object.__setattr__(self, "_store", store)
        object.__setattr__(self, "_on_change", on_change)

    def __getattr__(self, key: str) -> Any:
        store: dict[str, Any] = object.__getattribute__(self, "_store")
        if key.startswith("_"):
            return object.__getattribute__(self, key)
        return store.get(key)

    def __setattr__(self, key: str, value: Any) -> None:
        if key.startswith("_"):
            object.__setattr__(self, key, value)
            return

        store: dict[str, Any] = object.__getattribute__(self, "_store")
        on_change: Callable[[str, Any, Any], None] = object.__getattribute__(self, "_on_change")

        old_value = store.get(key)
        if not is_equal(old_value, value, True):
            store[key] = value
            on_change(key, value, old_value)

    def __getitem__(self, key: str) -> Any:
        store: dict[str, Any] = object.__getattribute__(self, "_store")
        return store.get(key)

    def __setitem__(self, key: str, value: Any) -> None:
        self.__setattr__(key, value)

    def get(self, key: str, default: Any = None) -> Any:
        store: dict[str, Any] = object.__getattribute__(self, "_store")
        return store.get(key, default)


class Sensor(ABC, Generic[TProperties, TStorage, TCapability]):
    """Abstract base class for all sensors. Plugins extend this (or use specialized subclasses like MotionSensor, LightControl, etc.) to implement sensor logic."""

    _requires_frames: bool = False

    def __init__(self, name: str) -> None:
        self._camera_id: str | None = None
        self._name = name
        self._id = str(uuid4())
        self._display_name = name
        self._plugin_id: str | None = None
        self._capabilities: list[TCapability] = []
        self._property_changed_subject: Subject[SensorPropertyChangeData] = Subject()
        self._capabilities_changed_subject: Subject[list[TCapability]] = Subject()
        self._detailed_listeners: set[PropertyChangeListener] = set()
        self._assignment_changed_subject: Subject[bool] = Subject()

        self._update_fn: Callable[[str, Any], None] | None = None
        self._capabilities_change_fn: Callable[[list[str]], None] | None = None
        self._storage: DeviceStorage[TStorage] | None = None
        self._is_assigned: bool = False
        self._properties_store: dict[str, Any] = {}
        self._properties_proxy: PropertiesProxy[TProperties] = PropertiesProxy(
            self._properties_store,
            self._on_property_change,
        )

    @property
    @abstractmethod
    def type(self) -> SensorType: ...

    @property
    @abstractmethod
    def category(self) -> SensorCategory: ...

    @property
    def id(self) -> str:
        return self._id

    @property
    def name(self) -> str:
        return self._name

    @property
    def displayName(self) -> str:
        return self._display_name

    @displayName.setter
    def displayName(self, value: str) -> None:
        self._display_name = value

    @property
    def pluginId(self) -> str | None:
        return self._plugin_id

    @property
    def cameraId(self) -> str | None:
        return self._camera_id

    @property
    def capabilities(self) -> list[TCapability]:
        return self._capabilities.copy()

    @capabilities.setter
    def capabilities(self, value: list[TCapability]) -> None:
        self._capabilities = list(dict.fromkeys(value))
        if self._capabilities_change_fn:
            caps_list: list[str] = [str(c) for c in self._capabilities]
            self._capabilities_change_fn(caps_list)
        self._capabilities_changed_subject.next(list(self._capabilities))

    @property
    def requiresFrames(self) -> bool:
        return self._requires_frames

    @property
    def storage_schema(self) -> list[JsonSchema]:
        """Override to provide a JSON schema for per-sensor storage settings UI."""
        return []

    @property
    def storage(self) -> DeviceStorage[TStorage]:
        """Per-sensor persistent storage. Raises if not yet added to a camera."""
        assert self._storage is not None, "Storage not initialized - sensor not added to camera yet"
        return self._storage

    @property
    def isAssigned(self) -> bool:
        return self._is_assigned

    @property
    def props(self) -> PropertiesProxy[TProperties]:
        return self._properties_proxy

    @property
    def rawProps(self) -> dict[str, Any]:
        return self._properties_store

    def _notify_metadata_update(self, property: str, value: Any) -> None:
        if self._update_fn:
            self._update_fn(property, value)

    def _on_property_change(self, key: str, value: Any, old_value: Any) -> None:
        if self._update_fn:
            self._update_fn(key, value)
        self._notifyListeners(key, value, old_value)

    def _setStorage(self, storage: DeviceStorage[TStorage]) -> None:
        self._storage = storage

    def _setAssigned(self, assigned: bool) -> None:
        if self._is_assigned != assigned:
            self._is_assigned = assigned
            self._assignment_changed_subject.next(assigned)

    @property
    def onAssignmentChanged(self) -> Observable[bool]:
        """Observable for assignment state changes (sensor added/removed from camera)."""
        return self._assignment_changed_subject.as_observable()

    def toJSON(self) -> SensorJSON:
        """Serialize this sensor to a JSON-safe dict for RPC transport."""
        result: SensorJSON = {
            "id": self.id,
            "type": self.type,
            "name": self.name,
            "displayName": self.displayName or self.name,
            "category": self.category,
            "cameraId": self._camera_id or "",
            "properties": self._getProperties(),
            "capabilities": [str(c) for c in self.capabilities],
            "requiresFrames": self._requires_frames,
        }
        if self._plugin_id:
            result["pluginId"] = self._plugin_id
        return result

    def _setPropertyInternal(self, key: str, value: Any) -> None:
        old_value = self._properties_store.get(key)
        if old_value != value:
            self._properties_store[key] = value
            self._notifyListeners(key, value, old_value)

    def _onBackendPropertyChanged(self, property: str, value: Any) -> None:
        self._setPropertyInternal(property, value)

    def getPropertyValue(self, property: str) -> Any | None:
        return self._properties_store.get(property)

    def getAllPropertyValues(self) -> dict[str, Any]:
        return self._properties_store.copy()

    async def setPropertyValue(self, property: str, value: Any) -> None:
        """Set a property value. For control sensors, this routes to the setX() method for hardware interaction."""
        method_name = f"set{property[0].upper()}{property[1:]}"
        method = getattr(self, method_name, None)

        if callable(method):
            result = method(value)
            if asyncio.iscoroutine(result):
                await result
        else:
            if self._properties_store.get(property) != value:
                setattr(self._properties_proxy, property, value)

    def hasCapability(self, capability: TCapability | str) -> bool:
        return capability in self._capabilities

    @property
    def onPropertyChanged(self) -> Observable[SensorPropertyChangeData]:
        """Observable for property changes."""
        return self._property_changed_subject.as_observable()

    def _notifyListeners(self, property: str, value: Any, previousValue: Any) -> None:
        if not self._camera_id:
            return

        if self._detailed_listeners:
            event: PropertyChangedEvent = {
                "cameraId": self._camera_id,
                "sensorId": self._id,
                "sensorType": self.type,
                "property": property,
                "value": value,
                "previousValue": previousValue,
                "timestamp": int(time.time() * 1000),
            }
            for detailed_listener in self._detailed_listeners:
                with contextlib.suppress(Exception):
                    detailed_listener(event)
        self._property_changed_subject.next({"property": property, "value": value})

    @property
    def onCapabilitiesChanged(self) -> Observable[list[TCapability]]:
        """Observable for capability changes. Emits the full capabilities array when capabilities change."""
        return self._capabilities_changed_subject.as_observable()

    def _setCameraId(self, camera_id: str) -> None:
        self._camera_id = camera_id

    def _setPluginId(self, plugin_id: str) -> None:
        self._plugin_id = plugin_id

    def _init(self, update_fn: PropertyUpdateFn) -> None:
        self._update_fn = update_fn

    def _initCapabilities(self, update_fn: CapabilityUpdateFn) -> None:
        self._capabilities_change_fn = update_fn

    def _cleanup(self) -> None:
        self._update_fn = None
        self._capabilities_change_fn = None
        self._storage = None
        self._is_assigned = False
        self._detailed_listeners.clear()
        self._property_changed_subject.complete()
        self._capabilities_changed_subject.complete()
        self._assignment_changed_subject.complete()

    def _getProperties(self) -> dict[str, Any]:
        return self._properties_store.copy()
