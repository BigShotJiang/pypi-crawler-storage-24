# Django Nexum Base

![Build Status](https://img.shields.io/badge/build-passing-brightgreen)
![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)
![PyPI](https://img.shields.io/pypi/v/django-nexum-base)
![Python Version](https://img.shields.io/pypi/pyversions/django-nexum-base)

## Descrição

Boilerplate modular para construção de sites Standard, feito em Django e Django REST Framework. Permite criar projetos robustos e escaláveis rapidamente, com autenticação JWT, 2FA, permissões, API RESTful e integração de email.

## Ambiente virtual

Antes de instalar, crie e ative um ambiente virtual Python:

```bash
python -m venv venv
source venv/bin/activate  # Linux/macOS
venv\Scripts\activate     # Windows
```

## Instalação

```bash
pip install django-nexum-base
```

## Configuração Inicial do Django

Se ainda não possui um projeto Django, crie um novo projeto e um app:

```bash
django-admin startproject project_name
cd meu_projeto
python manage.py startapp app_name
```

## Setup

Adicione `base`, `rest_framework` e `django_filters` ao seu `INSTALLED_APPS` no `settings.py`:

```python
INSTALLED_APPS = [
    ...
    'rest_framework',
    'django_filters',
    'base',
]
```

Configure o usuário customizado:

```python
AUTH_USER_MODEL = 'base.BaseCustomUser'
```
Rode as migrações:

```bash
python manage.py migrate
```

## Exemplo de Uso:

# Criando um produto
from base.models import BaseProduct

produto = BaseProduct.objects.create(
    name="Produto Exemplo",
    price=99.99,
    stock=100
)



```

Envie email (exemplo):

```python
from base.utils import send_otp_email
send_otp_email(user)
```

## Documentação

Consulte a documentação completa dos endpoints, modelos e exemplos de uso no repositório ou no diretório `docs/`.

## Licença

MIT