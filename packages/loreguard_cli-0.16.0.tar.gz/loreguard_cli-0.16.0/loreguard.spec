# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules

hiddenimports = ['src', 'src.config', 'src.llm', 'src.llama_server', 'src.tunnel', 'src.term_ui', 'src.models_registry', 'src.cli', 'src.npc_chat', 'httpx', 'websockets', 'aiofiles', 'pydantic']
hiddenimports += collect_submodules('src')


a = Analysis(
    ['loreguard_entry.py'],
    pathex=['.'],
    binaries=[],
    datas=[('templates', 'templates')],
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='loreguard',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
