import time
from colorama import Fore, Back, Style, init
init(autoreset=True)

class StyledText:
    def __init__(self, text):
        self.text = str(text)
        self.styles = []

    def _add(self, style):
        self.styles.append(style)
        return self

    # ---------- Text Colors ----------
    def red(self): return self._add(Fore.RED)
    def green(self): return self._add(Fore.GREEN)
    def yellow(self): return self._add(Fore.YELLOW)
    def blue(self): return self._add(Fore.BLUE)
    def magenta(self): return self._add(Fore.MAGENTA)
    def cyan(self): return self._add(Fore.CYAN)
    def white(self): return self._add(Fore.WHITE)

    # ---------- Background Colors ----------
    def bg_red(self): return self._add(Back.RED)
    def bg_green(self): return self._add(Back.GREEN)
    def bg_yellow(self): return self._add(Back.YELLOW)
    def bg_blue(self): return self._add(Back.BLUE)
    def bg_magenta(self): return self._add(Back.MAGENTA)
    def bg_cyan(self): return self._add(Back.CYAN)
    def bg_white(self): return self._add(Back.WHITE)

    # ---------- Styles ----------
    def bold(self): return self._add(Style.BRIGHT)
    def dim(self): return self._add(Style.DIM)
    def normal(self): return self._add(Style.NORMAL)

    def underline(self):
        return self._add('\033[4m')

    def reverse(self):
        return self._add('\033[7m')

    # ---------- RGB ----------
    def rgb(self, r, g, b):
        r = max(0, min(255, r))
        g = max(0, min(255, g))
        b = max(0, min(255, b))
        return self._add(f"\033[38;2;{r};{g};{b}m")

    def bg_rgb(self, r, g, b):
        r = max(0, min(255, r))
        g = max(0, min(255, g))
        b = max(0, min(255, b))
        return self._add(f"\033[48;2;{r};{g};{b}m")

    # ---------- Rainbow 🌈 ----------
    def rainbow(self):
        colors = [
            Fore.RED, Fore.YELLOW, Fore.GREEN,
            Fore.CYAN, Fore.BLUE, Fore.MAGENTA
        ]
        result = ""
        for i, char in enumerate(self.text):
            result += colors[i % len(colors)] + char
        self.text = result
        return self

    # ---------- Gradient ----------
    def gradient(self, start=(255, 0, 0), end=(0, 0, 255)):
        result = ""
        length = len(self.text)

        for i, char in enumerate(self.text):
            r = int(start[0] + (end[0] - start[0]) * i / max(length - 1, 1))
            g = int(start[1] + (end[1] - start[1]) * i / max(length - 1, 1))
            b = int(start[2] + (end[2] - start[2]) * i / max(length - 1, 1))

            result += f"\033[38;2;{r};{g};{b}m{char}"

        self.text = result
        return self

    # ---------- Typing Animation ----------
    def type(self, speed=0.05):
        styled = "".join(self.styles)
        for char in self.text:
            print(styled + char + Style.RESET_ALL, end='', flush=True)
            time.sleep(speed)
        print()
        return self

    # ---------- Output ----------
    def build(self):
        return "".join(self.styles) + self.text + Style.RESET_ALL

    def print(self):
        print(self.build())

    def __str__(self):
        return self.build()


def text(content):
    return StyledText(content)