__version__ = "0.1.0"

from .core import text

# Simple functions
def red(content):
    text(content).red().print()

def green(content):
    text(content).green().print()

def yellow(content):
    text(content).yellow().print()

def blue(content):
    text(content).blue().print()

def magenta(content):
    text(content).magenta().print()

def cyan(content):
    text(content).cyan().print()

def white(content):
    text(content).white().print()

# Styles
def bold(content):
    text(content).bold().print()

def underline(content):
    text(content).underline().print()

# Background
def bg_red(content):
    text(content).bg_red().print()

def bg_green(content):
    text(content).bg_green().print()

# Rainbow 🌈
def rainbow(content):
    text(content).rainbow().print()



__all__ = [
    "text",
    "red", "green", "yellow", "blue", "magenta", "cyan", "white",
    "bold", "underline",
    "bg_red", "bg_green",
    "rainbow"
]