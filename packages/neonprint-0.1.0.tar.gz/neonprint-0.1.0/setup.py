from setuptools import setup, find_packages

setup(
    name="neonprint",
    version="0.1.0",
    packages=find_packages(),
    description="Chainable colored and styled text printing for Python",
    author="Samarth Chugh",
    install_requires=["colorama"],
    python_requires=">=3.6",
    keywords=["color", "terminal", "cli", "text", "style"],
)