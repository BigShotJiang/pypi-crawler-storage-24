# neonprint

A simple and powerful Python library for printing colored and styled text using a clean chaining API.

## Installation

pip install neonprint

## Usage

from neonprint import text

text("Hello").red().bold().print()
text("Warning").yellow().bg_red().underline().print()
text("Rainbow!").rainbow().bold().print()

## Features

- Chainable API
- Multiple colors
- Background colors
- Bold, underline, reverse
- Rainbow text 🌈

## Example

text("Cool").cyan().underline().print()