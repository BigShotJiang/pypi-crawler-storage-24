# __init__.py
from .Client import (
    register_node,
    submit_tasks_batch,
    request_tasks_batch,
    submit_results_batch,
    get_results_batch,
    compute_task
)

__all__ = [
    "register_node",
    "submit_tasks_batch",
    "request_tasks_batch",
    "submit_results_batch",
    "get_results_batch",
    "compute_task"
]
