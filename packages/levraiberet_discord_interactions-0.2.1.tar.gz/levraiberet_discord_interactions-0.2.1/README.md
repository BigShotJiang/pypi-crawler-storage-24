# discord-interactions-py

Toolkit simple pour `discord.py`, inspire de la logique Discord.js, avec controle direct des payloads Discord API.

## Ce que fait le module

- Boutons et selects sans `View`
- Routing par `custom_id` (avec donnees encodees)
- Envoi/edition via HTTP Discord direct
- Containers V2 (`ContainerBuilder`, `SectionBuilder`, ...)
- Modales modernes (`Label`, `TextDisplay`, `RadioGroup`, `CheckboxGroup`, `Checkbox`)

## Installation

```bash
pip install levraiberet-discord-interactions
```

Nom du package PyPI: `levraiberet-discord-interactions`
Nom d'import Python: `discord_interactions`

## Demarrage rapide

```bash
$env:DISCORD_BOT_TOKEN="votre_token"
python examples/01_minimal.py
```

## Exemples (1 fichier = 1 sujet)

- `examples/01_minimal.py`
- `examples/02_buttons_routing.py`
- `examples/03_selects.py`
- `examples/04_modales_modernes.py`
- `examples/05_containers_v2.py`
- `examples/06_signed_custom_ids.py`

## Validation rapide

Tu peux valider le module en lancant les exemples un par un, selon le sujet a verifier.

```bash
python examples/01_minimal.py
python examples/04_modales_modernes.py
```

## Note sur les modales modernes

Format recommande:

- top-level: `Label (18)` / `TextDisplay (10)`
- `Label.component`: `TextInput (4)`, selects, `FileUpload (19)`, `RadioGroup (21)`, `CheckboxGroup (22)`, `Checkbox (23)`

## Licence

MIT
