from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import discord

from .components import create_action_row, create_button
from .sender import MessageFlags


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64url_decode(raw: str) -> bytes:
    padding = "=" * ((4 - (len(raw) % 4)) % 4)
    return base64.urlsafe_b64decode((raw + padding).encode("ascii"))


def _sign(payload: str, secret: str) -> str:
    mac = hmac.new(secret.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).digest()
                                                                           
    return _b64url_encode(mac[:12])


def build_signed_custom_id(
    base_id: str,
    data: Optional[Dict[str, Any]],
    secret: str,
    ttl_seconds: Optional[int] = None,
    max_length: int = 100,
) -> str:      
    if not base_id:
        raise ValueError("base_id must not be empty")
    if not secret:
        raise ValueError("secret must not be empty")

    payload_obj: Dict[str, Any] = {"d": data or {}}
    if ttl_seconds is not None:
        payload_obj["exp"] = int(time.time()) + int(ttl_seconds)

    payload_json = json.dumps(payload_obj, separators=(",", ":"), ensure_ascii=True)
    payload_encoded = _b64url_encode(payload_json.encode("utf-8"))
    signature = _sign(payload_encoded, secret)

    custom_id = f"{base_id}:{payload_encoded}.{signature}"
    if len(custom_id) > max_length:
        raise ValueError(
            f"custom_id too long ({len(custom_id)}>{max_length}). Reduce embedded data size."
        )

    return custom_id


def parse_signed_custom_id(
    custom_id: str,
    secret: str,
    enforce_expiry: bool = True,
) -> Tuple[str, Dict[str, Any], bool, str]:     
    if ":" not in custom_id:
        return custom_id, {}, False, "missing_separator"

    base_id, signed = custom_id.split(":", 1)
    if "." not in signed:
        return base_id, {}, False, "missing_signature"

    payload_encoded, provided_sig = signed.rsplit(".", 1)
    expected_sig = _sign(payload_encoded, secret)

    if not hmac.compare_digest(provided_sig, expected_sig):
        return base_id, {}, False, "bad_signature"

    try:
        payload_obj = json.loads(_b64url_decode(payload_encoded).decode("utf-8"))
    except Exception:
        return base_id, {}, False, "bad_payload"

    exp = payload_obj.get("exp")
    if enforce_expiry and exp is not None and int(time.time()) > int(exp):
        return base_id, payload_obj.get("d", {}), False, "expired"

    return base_id, payload_obj.get("d", {}), True, "ok"


def create_signed_button(
    base_id: str,
    secret: str,
    data: Optional[Dict[str, Any]] = None,
    ttl_seconds: Optional[int] = None,
    label: str = "",
    style: int | str = "Primary",
    emoji: Optional[str | Dict[str, Any]] = None,
    disabled: bool = False,
    max_custom_id_length: int = 100,
) -> Dict[str, Any]:
                                                                                  
    signed_custom_id = build_signed_custom_id(
        base_id=base_id,
        data=data,
        secret=secret,
        ttl_seconds=ttl_seconds,
        max_length=max_custom_id_length,
    )
    return create_button(
        custom_id=signed_custom_id,
        label=label,
        style=style,
        emoji=emoji,
        data=None,
        disabled=disabled,
    )


def create_auto_rows(
    components: Sequence[Dict[str, Any]],
    max_buttons_per_row: int = 5,
) -> List[Dict[str, Any]]:    
    rows: List[Dict[str, Any]] = []
    pending_buttons: List[Dict[str, Any]] = []

    def flush_buttons() -> None:
        nonlocal pending_buttons
        while pending_buttons:
            chunk = pending_buttons[:max_buttons_per_row]
            pending_buttons = pending_buttons[max_buttons_per_row:]
            rows.append(create_action_row(*chunk))

    for comp in components:
        ctype = comp.get("type")
        if ctype == 2:
            pending_buttons.append(comp)
            continue

        if ctype in {3, 5, 6, 7, 8}:
            flush_buttons()
            rows.append(create_action_row(comp))
            continue

        raise ValueError(f"Unsupported component type for action row layout: {ctype}")

    flush_buttons()
    return rows


async def respond_or_followup(
    interaction: discord.Interaction,
    *,
    content: Optional[str] = None,
    embed: Optional[discord.Embed] = None,
    embeds: Optional[List[discord.Embed]] = None,
    components: Optional[Iterable[Dict[str, Any]]] = None,
    ephemeral: bool = False,
    flags: Optional[int] = None,
) -> Optional[discord.Message]:       
    payload: Dict[str, Any] = {}
    if content is not None:
        payload["content"] = content
    if embed is not None and embeds is not None:
        raise ValueError("Cannot set both embed and embeds")
    if embed is not None:
        payload["embeds"] = [embed]
    elif embeds is not None:
        payload["embeds"] = embeds
    if components is not None:
        payload["components"] = list(components)

    final_flags = int(flags or 0)
    if ephemeral:
        final_flags |= MessageFlags.EPHEMERAL

    if not interaction.response.is_done():
        await interaction.response.send_message(
            **payload,
            ephemeral=ephemeral,
        )
        return None

                                                       
    return await interaction.followup.send(
        **payload,
        ephemeral=ephemeral,
        wait=True,
    )
