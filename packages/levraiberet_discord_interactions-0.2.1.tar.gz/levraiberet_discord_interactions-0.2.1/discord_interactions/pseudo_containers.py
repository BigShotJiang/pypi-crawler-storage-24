from typing import List, Dict, Any, Optional, Union
import discord
from .components import create_action_row


class PseudoContainerBuilder:
    def __init__(self):
        self._embeds: List[discord.Embed] = []
        self._action_rows: List[Dict[str, Any]] = []
        self._current_embed: Optional[discord.Embed] = None

    def addTextDisplay(self, content: str, color: int = 0x2B2D31) -> "PseudoContainerBuilder":                                                        
        if self._current_embed:
            self._embeds.append(self._current_embed)

                                             
        embed = discord.Embed(description=content, color=color)
        self._current_embed = embed
        return self

    def addSeparator(self) -> "PseudoContainerBuilder":          
        if self._current_embed:
            self._embeds.append(self._current_embed)
            self._current_embed = None

                                           
        separator_embed = discord.Embed(description="━━━━━━━━━━━━━━━━━━━━", color=0x36393F)
        self._embeds.append(separator_embed)
        return self

    def addSection(self, text: str, button_accessory: Optional[Dict[str, Any]] = None, color: int = 0x5865F2) -> "PseudoContainerBuilder":        
        if self._current_embed:
            self._embeds.append(self._current_embed)
            self._current_embed = None

                                     
        section_embed = discord.Embed(description=text, color=color)
        self._embeds.append(section_embed)

                                                     
        if button_accessory:
            button_row = create_action_row(button_accessory)
            self._action_rows.append(button_row)

        return self

    def addActionRow(self, *components) -> "PseudoContainerBuilder":        
        if self._current_embed:
            self._embeds.append(self._current_embed)
            self._current_embed = None

                                                  
        action_row = create_action_row(*components)
        self._action_rows.append(action_row)
        return self

    def to_message_data(self) -> Dict[str, Any]:                                                 
        if self._current_embed:
            self._embeds.append(self._current_embed)

        return {
            "embeds": [embed.to_dict() for embed in self._embeds] if self._embeds else None,
            "components": self._action_rows if self._action_rows else None
        }


class PseudoTextDisplayBuilder:
    def __init__(self):
        self._content: str = ""
        self._color: int = 0x2B2D31

    def setContent(self, content: str) -> "PseudoTextDisplayBuilder":
                                
        self._content = content
        return self

    def setColor(self, color: int) -> "PseudoTextDisplayBuilder":
                                
        self._color = color
        return self

    def build(self) -> str:
                                   
        return self._content


class PseudoSectionBuilder:     
    def __init__(self):
        self._content: str = ""
        self._button_accessory: Optional[Dict[str, Any]] = None
        self._color: int = 0x5865F2

    def setContent(self, content: str) -> "PseudoSectionBuilder":
                                              
        self._content = content
        return self

    def setButtonAccessory(self, button: Dict[str, Any]) -> "PseudoSectionBuilder":
                                          
        self._button_accessory = button
        return self

    def setColor(self, color: int) -> "PseudoSectionBuilder":
                                
        self._color = color
        return self

    def build(self) -> tuple:
                                   
        return (self._content, self._button_accessory, self._color)


                                          
def pseudoContainer() -> PseudoContainerBuilder:
                                   
    return PseudoContainerBuilder()

def pseudoTextDisplay(content: str = "") -> PseudoTextDisplayBuilder:
                                      
    return PseudoTextDisplayBuilder().setContent(content)

def pseudoSection(content: str = "") -> PseudoSectionBuilder:
                                  
    return PseudoSectionBuilder().setContent(content)