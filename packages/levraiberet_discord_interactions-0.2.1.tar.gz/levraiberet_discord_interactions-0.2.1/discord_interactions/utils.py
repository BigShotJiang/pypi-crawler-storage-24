import json
import base64
from typing import Dict, Any, Tuple, Optional


def encode_data(data: Dict[str, Any]) -> str:     
    json_str = json.dumps(data, separators=(',', ':'))
    encoded = base64.b64encode(json_str.encode('utf-8')).decode('utf-8')
    return encoded


def decode_data(encoded: str) -> Dict[str, Any]:     
    try:
        decoded = base64.b64decode(encoded.encode('utf-8')).decode('utf-8')
        return json.loads(decoded)
    except (ValueError, json.JSONDecodeError):
        return {}


def parse_custom_id(custom_id: str) -> Tuple[str, Dict[str, Any]]:     
    if ':' not in custom_id:
        return custom_id, {}

    parts = custom_id.split(':', 1)
    base_id = parts[0]

    if len(parts) > 1:
        data = decode_data(parts[1])
    else:
        data = {}

    return base_id, data


def get_base_custom_id(custom_id: str) -> str:     
    return custom_id.split(':', 1)[0]


def build_custom_id(base_id: str, data: Optional[Dict[str, Any]] = None) -> str:     
    if not data:
        return base_id

    encoded = encode_data(data)
    return f"{base_id}:{encoded}"