from typing import List, Dict, Any, Optional, Union
from .utils import build_custom_id


class ButtonStyle:
                                
    Primary = 1
    Secondary = 2
    Success = 3
    Danger = 4
    Link = 5


class ComponentType:
                                           

    ActionRow = 1
    Button = 2
    StringSelect = 3
    TextInput = 4
    UserSelect = 5
    RoleSelect = 6
    MentionableSelect = 7
    ChannelSelect = 8
    Section = 9
    TextDisplay = 10
    Thumbnail = 11
    MediaGallery = 12
    File = 13
    Separator = 14
    Container = 17
    Label = 18
    FileUpload = 19
    RadioGroup = 21
    CheckboxGroup = 22
    Checkbox = 23


class TextInputStyle:
                                     

    Short = 1
    Paragraph = 2


def create_component(component_type: int, **fields: Any) -> Dict[str, Any]:
                                                                                             
    component = {"type": int(component_type)}
    component.update(fields)
    return component


def create_modal_row(component: Dict[str, Any]) -> Dict[str, Any]:
                                                           
    return create_action_row(component)


def create_button(
    custom_id: str,
    label: str = "",
    style: Union[str, int] = "Primary",
    emoji: Optional[Union[str, dict]] = None,
    data: Optional[Dict[str, Any]] = None,
    disabled: bool = False,
    url: Optional[str] = None,
) -> Dict[str, Any]:                               
    if isinstance(style, str):
        style = getattr(ButtonStyle, style, ButtonStyle.Primary)

                                        
    final_custom_id = build_custom_id(custom_id, data) if style != ButtonStyle.Link else custom_id

                           
    button = {
        "type": 2,                         
        "style": style,
        "disabled": disabled
    }

                           
    if label:
        button["label"] = label

                           
    if emoji:
        if isinstance(emoji, str):
            button["emoji"] = {"name": emoji}
        else:
            button["emoji"] = emoji

                                         
    if style == ButtonStyle.Link:
        if url:
            button["url"] = url
    else:
        button["custom_id"] = final_custom_id

    return button


def create_select_menu(
    custom_id: str,
    placeholder: str = "Select an option",
    options: List[Dict[str, Any]] = None,
    min_values: int = 1,
    max_values: int = 1,
    disabled: bool = False,
    required: Optional[bool] = None,
    component_id: Optional[int] = None,
) -> Dict[str, Any]:    
    if options is None:
        options = []

                            
    formatted_options = []
    for opt in options:
        option = {
            "label": opt.get("label", "Option"),
            "value": opt.get("value", opt.get("label", "option")),
        }

        if "description" in opt and opt["description"]:
            option["description"] = opt["description"]

        if "emoji" in opt and opt["emoji"]:
            if isinstance(opt["emoji"], str):
                option["emoji"] = {"name": opt["emoji"]}
            else:
                option["emoji"] = opt["emoji"]

        if "default" in opt:
            option["default"] = opt["default"]

        formatted_options.append(option)

    payload: Dict[str, Any] = {
        "type": ComponentType.StringSelect,
        "custom_id": custom_id,
        "placeholder": placeholder,
        "min_values": min_values,
        "max_values": max_values,
        "options": formatted_options,
        "disabled": disabled,
    }

                                                                             
    if required is not None:
        payload["required"] = bool(required)
    if component_id is not None:
        payload["id"] = int(component_id)

    return payload


def create_radio_group(
    custom_id: str,
    options: List[Dict[str, Any]],
    placeholder: Optional[str] = None,
    disabled: bool = False,
    required: bool = True,
    component_id: Optional[int] = None,
) -> Dict[str, Any]:
                                                      
                                                                          
                                                                              
    _ = placeholder, disabled

    payload: Dict[str, Any] = {
        "type": ComponentType.RadioGroup,
        "custom_id": custom_id,
        "options": [
            {
                "label": opt.get("label", "Option"),
                "value": opt.get("value", opt.get("label", "option")),
                **({"description": opt["description"]} if opt.get("description") else {}),
                **({"default": bool(opt["default"])} if "default" in opt else {}),
            }
            for opt in options
        ],
        "required": bool(required),
    }

    if component_id is not None:
        payload["id"] = int(component_id)

    return payload


def create_checkbox_group(
    custom_id: str,
    options: List[Dict[str, Any]],
    placeholder: Optional[str] = None,
    min_values: int = 0,
    max_values: Optional[int] = None,
    disabled: bool = False,
    required: bool = False,
    component_id: Optional[int] = None,
) -> Dict[str, Any]:
                                                         
                                                                          
                                                                                 
    _ = placeholder, disabled

    if max_values is None:
        max_values = len(options)

    payload: Dict[str, Any] = {
        "type": ComponentType.CheckboxGroup,
        "custom_id": custom_id,
        "options": [
            {
                "label": opt.get("label", "Option"),
                "value": opt.get("value", opt.get("label", "option")),
                **({"description": opt["description"]} if opt.get("description") else {}),
                **({"default": bool(opt["default"])} if "default" in opt else {}),
            }
            for opt in options
        ],
        "min_values": int(min_values),
        "max_values": int(max_values),
        "required": bool(required),
    }

    if component_id is not None:
        payload["id"] = int(component_id)

    return payload


def create_checkbox(
    custom_id: str,
    default: bool = False,
    component_id: Optional[int] = None,
) -> Dict[str, Any]:
                                                   
    payload: Dict[str, Any] = {
        "type": ComponentType.Checkbox,
        "custom_id": custom_id,
        "default": bool(default),
    }
    if component_id is not None:
        payload["id"] = int(component_id)
    return payload


def create_entity_select_menu(
    custom_id: str,
    select_type: int,
    placeholder: str = "Select",
    min_values: int = 1,
    max_values: int = 1,
    disabled: bool = False,
    default_values: Optional[List[Dict[str, Any]]] = None,
    channel_types: Optional[List[int]] = None,
    required: Optional[bool] = None,
    component_id: Optional[int] = None,
) -> Dict[str, Any]:
                                                                   
    if select_type not in {
        ComponentType.UserSelect,
        ComponentType.RoleSelect,
        ComponentType.MentionableSelect,
        ComponentType.ChannelSelect,
    }:
        raise ValueError("select_type must be one of 5, 6, 7, 8")

    payload: Dict[str, Any] = {
        "type": select_type,
        "custom_id": custom_id,
        "placeholder": placeholder,
        "min_values": min_values,
        "max_values": max_values,
        "disabled": disabled,
    }

    if default_values:
        payload["default_values"] = default_values

    if channel_types is not None and select_type == ComponentType.ChannelSelect:
        payload["channel_types"] = channel_types

    if required is not None:
        payload["required"] = bool(required)

    if component_id is not None:
        payload["id"] = int(component_id)

    return payload


def create_user_select_menu(
    custom_id: str,
    placeholder: str = "Select users",
    min_values: int = 1,
    max_values: int = 1,
    disabled: bool = False,
    default_values: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    return create_entity_select_menu(
        custom_id=custom_id,
        select_type=ComponentType.UserSelect,
        placeholder=placeholder,
        min_values=min_values,
        max_values=max_values,
        disabled=disabled,
        default_values=default_values,
    )


def create_role_select_menu(
    custom_id: str,
    placeholder: str = "Select roles",
    min_values: int = 1,
    max_values: int = 1,
    disabled: bool = False,
    default_values: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    return create_entity_select_menu(
        custom_id=custom_id,
        select_type=ComponentType.RoleSelect,
        placeholder=placeholder,
        min_values=min_values,
        max_values=max_values,
        disabled=disabled,
        default_values=default_values,
    )


def create_mentionable_select_menu(
    custom_id: str,
    placeholder: str = "Select mentionables",
    min_values: int = 1,
    max_values: int = 1,
    disabled: bool = False,
    default_values: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    return create_entity_select_menu(
        custom_id=custom_id,
        select_type=ComponentType.MentionableSelect,
        placeholder=placeholder,
        min_values=min_values,
        max_values=max_values,
        disabled=disabled,
        default_values=default_values,
    )


def create_channel_select_menu(
    custom_id: str,
    placeholder: str = "Select channels",
    min_values: int = 1,
    max_values: int = 1,
    disabled: bool = False,
    default_values: Optional[List[Dict[str, Any]]] = None,
    channel_types: Optional[List[int]] = None,
) -> Dict[str, Any]:
    return create_entity_select_menu(
        custom_id=custom_id,
        select_type=ComponentType.ChannelSelect,
        placeholder=placeholder,
        min_values=min_values,
        max_values=max_values,
        disabled=disabled,
        default_values=default_values,
        channel_types=channel_types,
    )


def create_text_input(
    custom_id: str,
    label: str,
    style: Union[str, int] = TextInputStyle.Short,
    placeholder: Optional[str] = None,
    min_length: Optional[int] = None,
    max_length: Optional[int] = None,
    required: bool = True,
    value: Optional[str] = None,
) -> Dict[str, Any]:
                                                       
    if isinstance(style, str):
        style = getattr(TextInputStyle, style, TextInputStyle.Short)

    payload: Dict[str, Any] = {
        "type": ComponentType.TextInput,
        "custom_id": custom_id,
        "label": label,
        "style": int(style),
        "required": bool(required),
    }

    if placeholder is not None:
        payload["placeholder"] = placeholder
    if min_length is not None:
        payload["min_length"] = int(min_length)
    if max_length is not None:
        payload["max_length"] = int(max_length)
    if value is not None:
        payload["value"] = value

    return payload


def create_label_component(
    label: str,
    description: Optional[str] = None,
    component: Optional[Dict[str, Any]] = None,
    component_id: Optional[int] = None,
) -> Dict[str, Any]:     
    payload: Dict[str, Any] = {
        "type": ComponentType.Label,
        "label": label,
    }
    if description is not None:
        payload["description"] = description
    if component is not None:
        wrapped = dict(component)
                                                                                
                                                                             
        if wrapped.get("type") == ComponentType.TextInput:
            wrapped.pop("label", None)
        payload["component"] = wrapped
    if component_id is not None:
        payload["id"] = int(component_id)
    return payload


def create_text_display_component(content: str) -> Dict[str, Any]:
                                                    
    return {
        "type": ComponentType.TextDisplay,
        "content": content,
    }


def create_file_upload_component(
    custom_id: str,
    min_values: int = 1,
    max_values: int = 1,
    required: bool = True,
) -> Dict[str, Any]:
                                                                                       
    return {
        "type": ComponentType.FileUpload,
        "custom_id": custom_id,
        "min_values": min_values,
        "max_values": max_values,
        "required": required,
    }


def create_modal(
    custom_id: str,
    title: str,
    *components: Dict[str, Any],
    strict_text_inputs: bool = False,
) -> Dict[str, Any]:   
    modal_components: List[Dict[str, Any]] = []

    modern_detected = any(
        isinstance(comp, dict) and comp.get("type") in {ComponentType.Label, ComponentType.TextDisplay}
        for comp in components
    )

    if modern_detected:
        for comp in components:
            if not isinstance(comp, dict):
                continue

            ctype = comp.get("type")
            if ctype in {ComponentType.Label, ComponentType.TextDisplay}:
                modal_components.append(comp)
                continue

                                                                           
            if ctype in {
                ComponentType.TextInput,
                ComponentType.StringSelect,
                ComponentType.UserSelect,
                ComponentType.RoleSelect,
                ComponentType.MentionableSelect,
                ComponentType.ChannelSelect,
                ComponentType.FileUpload,
                ComponentType.RadioGroup,
                ComponentType.CheckboxGroup,
                ComponentType.Checkbox,
            }:
                generated_label = comp.get("label") or comp.get("custom_id") or "Field"
                modal_components.append(create_label_component(generated_label, component=comp))

        if not modal_components:
            raise ValueError("Modal invalide: aucun composant modal moderne valide.")
    else:
        for comp in components:
            if not isinstance(comp, dict):
                continue

            if comp.get("type") == ComponentType.ActionRow:
                children = comp.get("components") or []
                if not isinstance(children, list):
                    continue

                for child in children:
                    if not isinstance(child, dict):
                        continue
                    if strict_text_inputs and child.get("type") != ComponentType.TextInput:
                        continue
                    modal_components.append(create_modal_row(child))
                continue

            if strict_text_inputs and comp.get("type") != ComponentType.TextInput:
                continue

            modal_components.append(create_modal_row(comp))

        if strict_text_inputs and not modal_components:
            raise ValueError(
                "Modal invalide: aucun TextInput (type 4). "
                "Discord rejette ce payload sur cet endpoint."
            )

    return {
        "custom_id": custom_id,
        "title": title,
        "components": modal_components,
    }


def create_action_row(*components) -> Dict[str, Any]:    
    normalized = []
    for comp in components:
        if hasattr(comp, "to_dict"):
            normalized.append(comp.to_dict())
        else:
            normalized.append(comp)

    return {
        "type": ComponentType.ActionRow,
        "components": normalized,
    }


def create_button_row(*buttons) -> Dict[str, Any]:    
    return create_action_row(*buttons)


def create_select_row(select_menu: Dict[str, Any]) -> Dict[str, Any]:
    return create_action_row(select_menu)


def disable_all_components(components: List[Dict[str, Any]]) -> List[Dict[str, Any]]:     
    disabled_rows = []
    for row in components:
        if row.get("type") == 1:             
            new_row = {
                "type": 1,
                "components": []
            }
            for component in row.get("components", []):
                component_copy = component.copy()
                component_copy["disabled"] = True
                new_row["components"].append(component_copy)
            disabled_rows.append(new_row)
    return disabled_rows