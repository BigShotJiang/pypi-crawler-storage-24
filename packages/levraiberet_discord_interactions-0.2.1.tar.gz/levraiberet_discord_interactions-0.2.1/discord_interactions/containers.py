from typing import List, Dict, Any, Optional, Union


class TextDisplayBuilder:
    def __init__(self):
        self._content: str = ""

    def setContent(self, content: str) -> "TextDisplayBuilder":     
        self._content = content
        return self

    def to_dict(self) -> Dict[str, Any]:
                                           
        return {
            "type": 10,                               
            "content": self._content
        }


class SeparatorBuilder:
    def __init__(self):
        pass

    def to_dict(self) -> Dict[str, Any]:
                                           
        return {
            "type": 14                            
        }


class SectionBuilder:
    def __init__(self):
        self._text_displays: List[TextDisplayBuilder] = []
        self._button_accessory: Optional[Dict[str, Any]] = None

    def addTextDisplayComponents(self, text_display: TextDisplayBuilder) -> "SectionBuilder":        
        self._text_displays.append(text_display)
        return self

    def setButtonAccessory(self, button: Any) -> "SectionBuilder":        
        if hasattr(button, "to_dict"):
            button = button.to_dict()

        if not isinstance(button, dict) or button.get("type") != 2:
            raise ValueError("L'accessoire bouton doit être un dict de bouton depuis create_button()")

        self._button_accessory = button
        return self

                                                                        
    def addTextDisplay(self, text_display: TextDisplayBuilder) -> "SectionBuilder":
        return self.addTextDisplayComponents(text_display)

    def to_dict(self) -> Dict[str, Any]:
                                           
        section = {
            "type": 9,                          
            "components": [td.to_dict() for td in self._text_displays]
        }

        if self._button_accessory:
            section["accessory"] = self._button_accessory

        return section


class ActionRowBuilder:
    def __init__(self):
        self._components: List[Dict[str, Any]] = []

    def addComponents(self, *components) -> "ActionRowBuilder":        
        normalized_components = []
        for comp in components:
            if hasattr(comp, "to_dict"):
                normalized_components.append(comp.to_dict())
            else:
                normalized_components.append(comp)

        self._components.extend(normalized_components)
        return self

    def to_dict(self) -> Dict[str, Any]:
                                           
        return {
            "type": 1,                             
            "components": self._components
        }


class ContainerBuilder:
    def __init__(self):
        self._components: List[Union[TextDisplayBuilder, SeparatorBuilder, SectionBuilder, ActionRowBuilder]] = []
        self._accent_color: Optional[int] = None

    def setAccentColor(self, color: int) -> "ContainerBuilder":         
        self._accent_color = color
        return self

    def addTextDisplayComponents(self, text_display: TextDisplayBuilder) -> "ContainerBuilder":        
        self._components.append(text_display)
        return self

    def addSeparatorComponents(self, separator: Optional[SeparatorBuilder] = None) -> "ContainerBuilder":         
        if separator is None:
            separator = SeparatorBuilder()
        self._components.append(separator)
        return self

    def addSectionComponents(self, section: SectionBuilder) -> "ContainerBuilder":         
        self._components.append(section)
        return self

    def addActionRowComponents(self, action_row: Union[ActionRowBuilder, Dict[str, Any]]) -> "ContainerBuilder":         
        if isinstance(action_row, dict):
            if action_row.get("type") != 1:
                raise ValueError("Action row dict must have type=1")
            row_builder = ActionRowBuilder()
            row_builder._components = action_row.get("components", [])
            self._components.append(row_builder)
        elif isinstance(action_row, ActionRowBuilder):
            self._components.append(action_row)
        else:
            raise ValueError("action_row must be ActionRowBuilder or action row dict")

        return self

                                                                    
    def addTextDisplay(self, text_display: TextDisplayBuilder) -> "ContainerBuilder":
        return self.addTextDisplayComponents(text_display)

    def addSeparator(self, separator: Optional[SeparatorBuilder] = None) -> "ContainerBuilder":
        return self.addSeparatorComponents(separator)

    def addSection(self, section: SectionBuilder) -> "ContainerBuilder":
        return self.addSectionComponents(section)

    def addActionRow(self, action_row: Union[ActionRowBuilder, Dict[str, Any]]) -> "ContainerBuilder":
        return self.addActionRowComponents(action_row)

    def to_dict(self) -> Dict[str, Any]:
                                           
        container = {
            "type": 17,                            
            "components": [comp.to_dict() for comp in self._components]
        }

        if self._accent_color is not None:
            container["accent_color"] = self._accent_color

        return container


                                                             
def textDisplay(content: str = "") -> TextDisplayBuilder:      
    return TextDisplayBuilder().setContent(content)


def separator() -> SeparatorBuilder:     
    return SeparatorBuilder()


def section() -> SectionBuilder:   
    return SectionBuilder()


def container() -> ContainerBuilder:     
    return ContainerBuilder()


def actionRow() -> ActionRowBuilder:    
    return ActionRowBuilder()