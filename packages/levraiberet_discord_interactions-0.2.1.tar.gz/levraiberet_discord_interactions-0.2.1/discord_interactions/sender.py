                                                                               

from typing import Any, Dict, List, Optional, Sequence, Union
import json

import discord
from discord.ext import commands
from discord.http import Route


class MessageFlags:
                                                              

    EPHEMERAL = 1 << 6      
    IS_COMPONENTS_V2 = 1 << 15         


ComponentInput = Union[Dict[str, Any], Any]


def _component_to_dict(component: ComponentInput) -> Dict[str, Any]:
    if hasattr(component, "to_dict"):
        return component.to_dict()
    if isinstance(component, dict):
        return component
    raise TypeError(f"Unsupported component type: {type(component)}")


def _normalize_components(
    components: Optional[Union[ComponentInput, Sequence[ComponentInput]]],
) -> Optional[List[Dict[str, Any]]]:
    if components is None:
        return None

    if isinstance(components, (list, tuple)):
        return [_component_to_dict(comp) for comp in components]

    return [_component_to_dict(components)]


def _apply_common_message_fields(
    payload: Dict[str, Any],
    content: Optional[str],
    embed: Optional[discord.Embed],
    embeds: Optional[List[discord.Embed]],
    components: Optional[Union[ComponentInput, Sequence[ComponentInput]]],
    flags: Optional[int] = None,
    tts: bool = False,
) -> None:
    if embed and embeds:
        raise ValueError("Cannot specify both embed and embeds")

    if content is not None:
        payload["content"] = str(content)

    if tts:
        payload["tts"] = True

    if embed is not None:
        payload["embeds"] = [embed.to_dict()] if embed else []
    elif embeds is not None:
        payload["embeds"] = [e.to_dict() for e in embeds]

    normalized_components = _normalize_components(components)
    if normalized_components is not None:
        payload["components"] = normalized_components

                                                                                      
        if any(comp.get("type") != 1 for comp in normalized_components):
            flags = int(flags or 0) | MessageFlags.IS_COMPONENTS_V2

    if flags:
        payload["flags"] = int(flags)


async def send_message(
    destination,
    content: Optional[str] = None,
    embed: Optional[discord.Embed] = None,
    embeds: Optional[List[discord.Embed]] = None,
    components: Optional[Union[ComponentInput, Sequence[ComponentInput]]] = None,
    tts: bool = False,
    files: Optional[List[discord.File]] = None,
    flags: Optional[int] = None,
    **kwargs,
) -> Union[discord.Message, None]:
                                                                                 

    if isinstance(destination, commands.Context):
        channel = destination.channel
        http = destination.bot.http
        state = destination.bot._connection
    elif isinstance(destination, (discord.TextChannel, discord.DMChannel, discord.Thread)):
        channel = destination
        http = channel._state.http
        state = channel._state
    elif isinstance(destination, discord.Interaction):
        return await send_interaction_message(
            destination,
            content=content,
            embed=embed,
            embeds=embeds,
            components=components,
            flags=flags,
            **kwargs,
        )
    else:
        raise TypeError(f"Unsupported destination type: {type(destination)}")

    if files:
        send_kwargs = {k: v for k, v in kwargs.items() if k != "components"}
        return await channel.send(
            content=content,
            embed=embed,
            embeds=embeds,
            tts=tts,
            files=files,
            **send_kwargs,
        )

    payload: Dict[str, Any] = {}
    _apply_common_message_fields(payload, content, embed, embeds, components, flags=flags, tts=tts)

    try:
        data = await http.request(
            Route("POST", "/channels/{channel_id}/messages", channel_id=channel.id),
            json=payload,
        )
        return state.create_message(channel=channel, data=data)
    except Exception as exc:
        print(f"Error sending message: {exc}")
        raise


async def send_interaction_message(
    interaction: discord.Interaction,
    content: Optional[str] = None,
    embed: Optional[discord.Embed] = None,
    embeds: Optional[List[discord.Embed]] = None,
    components: Optional[Union[ComponentInput, Sequence[ComponentInput]]] = None,
    ephemeral: bool = False,
    flags: Optional[int] = None,
    **kwargs,
) -> None:
                                                        

    payload: Dict[str, Any] = {"type": 4, "data": {}}
    final_flags = int(flags or 0)
    if ephemeral:
        final_flags |= MessageFlags.EPHEMERAL

    _apply_common_message_fields(
        payload["data"],
        content,
        embed,
        embeds,
        components,
        flags=final_flags or None,
    )

    try:
        await interaction._state.http.request(
            Route(
                "POST",
                "/interactions/{interaction_id}/{interaction_token}/callback",
                interaction_id=interaction.id,
                interaction_token=interaction.token,
            ),
            json=payload,
        )
    except Exception as exc:
        print(f"Error sending interaction: {exc}")
        raise


async def edit_message(
    message: Union[discord.Message, discord.InteractionMessage],
    content: Optional[str] = None,
    embed: Optional[discord.Embed] = None,
    embeds: Optional[List[discord.Embed]] = None,
    components: Optional[Union[ComponentInput, Sequence[ComponentInput]]] = None,
    flags: Optional[int] = None,
    **kwargs,
) -> discord.Message:
                                                            

    payload: Dict[str, Any] = {}
    _apply_common_message_fields(payload, content, embed, embeds, components, flags=flags)

    try:
        data = await message._state.http.request(
            Route(
                "PATCH",
                "/channels/{channel_id}/messages/{message_id}",
                channel_id=message.channel.id,
                message_id=message.id,
            ),
            json=payload,
        )
        message._update(data)
        return message
    except Exception as exc:
        print(f"Error editing message: {exc}")
        raise


async def respond_to_interaction(
    interaction: discord.Interaction,
    content: Optional[str] = None,
    embed: Optional[discord.Embed] = None,
    embeds: Optional[List[discord.Embed]] = None,
    components: Optional[Union[ComponentInput, Sequence[ComponentInput]]] = None,
    ephemeral: bool = False,
    update: bool = False,
    flags: Optional[int] = None,
    **kwargs,
) -> None:
                                                                     

    response_type = 7 if update else 4
    payload: Dict[str, Any] = {"type": response_type, "data": {}}

    final_flags = int(flags or 0)
    if ephemeral:
        final_flags |= MessageFlags.EPHEMERAL

    _apply_common_message_fields(
        payload["data"],
        content,
        embed,
        embeds,
        components,
        flags=final_flags or None,
    )

    try:
        await interaction._state.http.request(
            Route(
                "POST",
                "/interactions/{interaction_id}/{interaction_token}/callback",
                interaction_id=interaction.id,
                interaction_token=interaction.token,
            ),
            json=payload,
        )
    except Exception as exc:
        print(f"Error responding to interaction: {exc}")
        raise


async def defer_interaction(
    interaction: discord.Interaction,
    update: bool = False,
    ephemeral: bool = False,
) -> None:
                                                           
    response_type = 6 if update else 5
    payload: Dict[str, Any] = {"type": response_type}

    if not update and ephemeral:
        payload["data"] = {"flags": MessageFlags.EPHEMERAL}

    try:
        await interaction._state.http.request(
            Route(
                "POST",
                "/interactions/{interaction_id}/{interaction_token}/callback",
                interaction_id=interaction.id,
                interaction_token=interaction.token,
            ),
            json=payload,
        )
    except Exception as exc:
        print(f"Error deferring interaction: {exc}")
        raise


async def send_modal(
    interaction: discord.Interaction,
    custom_id: str,
    title: str,
    components: Sequence[ComponentInput],
) -> None:
                                                           

    def _sanitize_modal_node(node: Any, in_label: bool = False) -> Any:
        if isinstance(node, list):
            return [_sanitize_modal_node(item, in_label=in_label) for item in node]

        if not isinstance(node, dict):
            return node

        cleaned = dict(node)
        node_type = cleaned.get("type")

        if in_label and node_type == 4:
            cleaned.pop("label", None)

        if "component" in cleaned:
            cleaned["component"] = _sanitize_modal_node(cleaned["component"], in_label=(node_type == 18))

        if "components" in cleaned and isinstance(cleaned["components"], list):
            cleaned["components"] = [
                _sanitize_modal_node(child, in_label=in_label) for child in cleaned["components"]
            ]

        return cleaned

    normalized = _normalize_components(components) or []
    normalized = [_sanitize_modal_node(comp, in_label=False) for comp in normalized]

    payload = {
        "type": 9,
        "data": {
            "custom_id": custom_id,
            "title": title,
            "components": normalized,
        },
    }

    try:
        await interaction._state.http.request(
            Route(
                "POST",
                "/interactions/{interaction_id}/{interaction_token}/callback",
                interaction_id=interaction.id,
                interaction_token=interaction.token,
            ),
            json=payload,
        )
    except Exception as exc:
        print(f"Error sending modal: {exc}")
        try:
            print("Modal payload:")
            print(json.dumps(payload, ensure_ascii=True, indent=2))
        except Exception:
            pass
        raise


async def send_followup(
    interaction: discord.Interaction,
    content: Optional[str] = None,
    embed: Optional[discord.Embed] = None,
    embeds: Optional[List[discord.Embed]] = None,
    components: Optional[Union[ComponentInput, Sequence[ComponentInput]]] = None,
    ephemeral: bool = False,
    flags: Optional[int] = None,
) -> Dict[str, Any]:
                                                                                   
    payload: Dict[str, Any] = {}
    final_flags = int(flags or 0)
    if ephemeral:
        final_flags |= MessageFlags.EPHEMERAL

    _apply_common_message_fields(
        payload,
        content,
        embed,
        embeds,
        components,
        flags=final_flags or None,
    )

    try:
        return await interaction._state.http.request(
            Route(
                "POST",
                "/webhooks/{application_id}/{interaction_token}",
                application_id=interaction.application_id,
                interaction_token=interaction.token,
            ),
            json=payload,
        )
    except Exception as exc:
        print(f"Error sending followup: {exc}")
        raise
