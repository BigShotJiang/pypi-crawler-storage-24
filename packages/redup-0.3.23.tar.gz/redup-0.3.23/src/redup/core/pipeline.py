"""Pipeline — orchestrates scan → hash → match → group → plan."""

from __future__ import annotations

import time
from typing import Any
from collections import defaultdict
import itertools

from redup.core.hasher import (
    HashedBlock,
    HashIndex,
    build_hash_index,
    find_exact_duplicates,
    find_structural_duplicates,
)
from redup.core.lsh_matcher import find_near_duplicates
from redup.core.matcher import MatchResult, refine_structural_matches
from redup.core.parallel_scanner import scan_project_parallel
from redup.core.models import (
    DuplicateFragment,
    DuplicateGroup,
    DuplicateType,
    DuplicationMap,
    ScanConfig,
    ScanStats,
)
from redup.core.planner import generate_suggestions
from redup.core.scanner import CodeBlock, ScannedFile, scan_project
from redup.core.cache import HashCache, build_hash_index_with_cache
from redup.core.lazy_grouper import find_all_duplicates_lazy, DuplicateGroupCollector
from redup.core.memory_scanner import scan_project_memory_optimized, scan_project_parallel_memory_optimized


def _blocks_to_group(
    group_id: str,
    blocks: list[HashedBlock],
    dup_type: DuplicateType,
    similarity: float = 1.0,
    normalized_hash: str = "",
) -> DuplicateGroup:
    """Convert a list of hashed blocks into a DuplicateGroup."""
    seen: set[tuple[str, int]] = set()
    fragments: list[DuplicateFragment] = []

    for hb in blocks:
        block = hb.block
        key = (block.file, block.line_start)
        if key in seen:
            continue
        seen.add(key)
        fragments.append(
            DuplicateFragment(
                file=block.file,
                line_start=block.line_start,
                line_end=block.line_end,
                text=block.text,
                function_name=block.function_name,
                class_name=block.class_name,
            )
        )

    if len(fragments) < 2:
        return DuplicateGroup(id=group_id, duplicate_type=dup_type)

    name = fragments[0].function_name if fragments[0].function_name else None

    return DuplicateGroup(
        id=group_id,
        duplicate_type=dup_type,
        fragments=fragments,
        similarity_score=similarity,
        normalized_hash=normalized_hash,
        normalized_name=name,
    )


def _deduplicate_groups(groups: list[DuplicateGroup]) -> list[DuplicateGroup]:
    """Remove groups that are subsets of larger groups."""
    if not groups:
        return groups

    # Sort by impact (largest first)
    sorted_groups = sorted(groups, key=lambda g: g.impact_score, reverse=True)
    kept: list[DuplicateGroup] = []
    seen_locations: set[tuple[str, int, int]] = set()

    for group in sorted_groups:
        if group.occurrences < 2:
            continue

        # Check if this group's fragments are already covered
        locations = {
            (f.file, f.line_start, f.line_end)
            for f in group.fragments
        }
        new_locations = locations - seen_locations

        if len(new_locations) >= 2:
            kept.append(group)
            seen_locations.update(locations)

    return kept


def analyze(
    config: ScanConfig | None = None,
    function_level_only: bool = False,
) -> DuplicationMap:
    """Run the full reDUP analysis pipeline.

    Args:
        config: Scan configuration. Defaults to current directory, .py files.
        function_level_only: If True, only analyze function-level blocks
            (skip sliding-window line blocks). Faster but misses inline duplicates.

    Returns:
        A DuplicationMap with all duplicate groups and refactoring suggestions.
    """
    config = _ensure_config(config)

    # Phase 1: Scan with function_level_only optimization
    scanned_files, stats = _scan_phase(config, function_level_only=function_level_only)

    # Phase 2: Process blocks
    all_blocks = _process_blocks(scanned_files, function_level_only)

    # Phase 3: Hash and find duplicates with optimizations
    groups = _find_duplicates_phase_optimized(all_blocks, config)

    # Phase 4: Deduplicate and suggest
    final_groups = _deduplicate_phase(groups)

    dup_map = DuplicationMap(
        project_path=config.root.as_posix(),
        config=config,
        stats=stats,
        groups=final_groups,
    )
    dup_map.suggestions = generate_suggestions(dup_map)

    return dup_map


def analyze_optimized(
    config: ScanConfig | None = None,
    function_level_only: bool = False,
    use_memory_cache: bool = True,
    max_cache_mb: int = 512,
) -> DuplicationMap:
    """Run reDUP analysis with all performance optimizations enabled.
    
    Uses parallel scanning, hash caching, lazy grouping, and memory optimization for maximum speed.
    
    Args:
        config: Scan configuration. Defaults to current directory, .py files.
        function_level_only: If True, only analyze function-level blocks.
        use_memory_cache: If True, load files into RAM for faster processing.
        max_cache_mb: Maximum memory to use for file caching.
        
    Returns:
        A DuplicationMap with all duplicate groups and refactoring suggestions.
    """
    config = _ensure_config(config)
    
    # Initialize cache if enabled
    cache = None
    if config.enable_cache:
        cache = HashCache(config.cache_dir)
    
    import time
    import signal
    start_time = time.time()
    
    def handle_interrupt(signum, frame):
        """Handle Ctrl+C gracefully."""
        print("\n⚠️  Scan interrupted by user")
        raise KeyboardInterrupt()
    
    # Set up signal handler for graceful interruption
    old_handler = signal.signal(signal.SIGINT, handle_interrupt)
    
    try:
        # Phase 1: Optimized scanning with memory cache
        if config.parallel_workers and config.parallel_workers > 1:
            # Explicit worker count specified
            if use_memory_cache:
                scanned_files, stats = scan_project_parallel_memory_optimized(
                    config, config.parallel_workers, max_cache_mb
                )
            else:
                scanned_files, stats = _scan_phase_parallel(config, config.parallel_workers)
        elif config.parallel_workers is None and (getattr(config, '_parallel_enabled', False) or config.parallel_workers is None):
            # Auto-detect CPU count when parallel_workers is None (default behavior)
            import multiprocessing as mp
            auto_workers = mp.cpu_count()
            if use_memory_cache:
                scanned_files, stats = scan_project_parallel_memory_optimized(
                    config, auto_workers, max_cache_mb
                )
            else:
                scanned_files, stats = _scan_phase_parallel(config, auto_workers)
        elif use_memory_cache:
            scanned_files, stats = scan_project_memory_optimized(config, max_cache_mb)
        else:
            scanned_files, stats = _scan_phase(config)

        # Phase 2: Process blocks
        all_blocks = _process_blocks(scanned_files, function_level_only)

        # Phase 3: Hash and find duplicates with caching and lazy grouping
        groups = _find_duplicates_phase_lazy(all_blocks, config, cache)

        # Phase 4: Deduplicate and suggest
        final_groups = _deduplicate_phase(groups)

        # Update scan time
        stats.scan_time_ms = (time.time() - start_time) * 1000

        dup_map = DuplicationMap(
            project_path=config.root.as_posix(),
            config=config,
            stats=stats,
            groups=final_groups,
        )
        dup_map.suggestions = generate_suggestions(dup_map)
        
        # Store cache data if caching is enabled
        if cache is not None:
            try:
                cache.cleanup_old_entries()
            except Exception:
                pass  # Ignore cache cleanup errors

        return dup_map
    except KeyboardInterrupt:
        print("\n⚠️  Scan cancelled by user")
        # Return empty results
        return DuplicationMap(
            project_path=config.root.as_posix() if config else ".",
            config=config,
            stats=ScanStats(scan_time_ms=(time.time() - start_time) * 1000),
            groups=[],
        )
    finally:
        # Restore original signal handler
        signal.signal(signal.SIGINT, old_handler)


def _ensure_config(config: ScanConfig | None) -> ScanConfig:
    """Ensure we have a valid configuration."""
    return config or ScanConfig()


def _scan_phase(config: ScanConfig, function_level_only: bool = False) -> tuple[list[ScannedFile], ScanStats]:
    """Phase 1: Scan project files."""
    # Use standard scan_project (ultra_fast_scanner disabled - doesn't extract function names)
    return scan_project(config, function_level_only=function_level_only)


def _scan_phase_parallel(config: ScanConfig, max_workers: int | None = None) -> tuple[list[ScannedFile], ScanStats]:
    """Phase 1: Scan project files in parallel."""
    return scan_project_parallel(
        root=config.root,
        extensions=config.extensions,
        exclude_patterns=config.exclude_patterns,
        include_tests=config.include_tests,
        function_level_only=True,  # Always function-level for parallel
        max_file_size=config.max_file_size_kb,
        max_workers=max_workers,
    )


def _process_blocks(
    scanned_files: list[ScannedFile],
    function_level_only: bool
) -> list[CodeBlock]:
    """Phase 2: Extract and filter code blocks with memory optimization."""
    all_blocks: list[CodeBlock] = []
    
    # Batch process files to reduce memory overhead
    batch_size = 100
    for i in range(0, len(scanned_files), batch_size):
        batch = scanned_files[i:i + batch_size]
        for sf in batch:
            for block in sf.blocks:
                if function_level_only and block.function_name is None:
                    continue
                all_blocks.append(block)
    
    return all_blocks


def _find_duplicates_phase_optimized(
    all_blocks: list[CodeBlock],
    config: ScanConfig
) -> list[DuplicateGroup]:
    """Phase 3: Hash and find duplicate groups with performance optimizations."""
    start_time = time.time()
    
    # Build hash index with progress tracking
    index = build_hash_index(all_blocks, min_lines=config.min_block_lines)
    
    # Find duplicates using lazy evaluation for better performance
    groups = list(find_all_duplicates_lazy(index, min_lines=config.min_block_lines))
    
    # Add near-duplicates if LSH is enabled
    near_duplicate_groups = _find_near_duplicate_groups(all_blocks, config)
    groups.extend(near_duplicate_groups)
    
    # Sort by impact
    groups.sort(key=lambda g: g.impact_score, reverse=True)
    
    processing_time = (time.time() - start_time) * 1000
    print(f"Duplicate finding completed in {processing_time:.1f}ms")
    
    return groups


def _find_duplicates_phase_lazy(
    all_blocks: list[CodeBlock],
    config: ScanConfig,
    cache: HashCache | None = None
) -> list[DuplicateGroup]:
    """Phase 3: Hash and find duplicates with caching and lazy evaluation."""
    start_time = time.time()
    
    # Build hash index with optional caching
    if cache is not None:
        index, block_hash_cache = build_hash_index_with_cache(
            all_blocks, min_lines=config.min_block_lines, cache=cache
        )
        
        # Store cache data for incremental scans
        for file_path, hashes in block_hash_cache.items():
            if file_path.exists():
                try:
                    content = file_path.read_text()
                    cache.store_file_hashes(file_path, content, hashes)
                except OSError:
                    pass
    else:
        index = build_hash_index(all_blocks, min_lines=config.min_block_lines)
    
    # Use lazy grouping with early exit
    groups = list(find_all_duplicates_lazy(index, min_lines=config.min_block_lines))
    
    # Add near-duplicates if LSH is enabled
    near_duplicate_groups = _find_near_duplicate_groups(all_blocks, config)
    groups.extend(near_duplicate_groups)
    
    # Sort by impact
    groups.sort(key=lambda g: g.impact_score, reverse=True)
    
    processing_time = (time.time() - start_time) * 1000
    if cache is not None:
        cache_stats = cache.get_stats()
        print(f"Duplicate finding completed in {processing_time:.1f}ms (cache: {cache_stats.get('cached_files', 0)} files)")
    else:
        print(f"Duplicate finding completed in {processing_time:.1f}ms")
    
    return groups


def _find_exact_groups(index: HashIndex) -> list[DuplicateGroup]:
    """Find exact duplicate groups."""
    groups: list[DuplicateGroup] = []
    exact_groups = find_exact_duplicates(index)

    for i, (h, blocks) in enumerate(exact_groups.items(), 1):
        func_blocks = [b for b in blocks if b.block.function_name]
        if len(func_blocks) >= 2:
            g = _blocks_to_group(
                group_id=f"E{i:04d}",
                blocks=func_blocks,
                dup_type=DuplicateType.EXACT,
                normalized_hash=h,
            )
            if g.occurrences >= 2:
                groups.append(g)

    return groups


def _find_structural_groups(
    index: HashIndex,
    exact_groups_list: list[DuplicateGroup]
) -> list[DuplicateGroup]:
    """Find structural duplicate groups."""
    groups: list[DuplicateGroup] = []
    exact_hashes: set[str] = set()
    for group in exact_groups_list:
        exact_hashes.add(group.normalized_hash)

    structural_groups = find_structural_duplicates(index)

    for i, (h, blocks) in enumerate(structural_groups.items(), 1):
        if h in exact_hashes:
            continue

        func_blocks = [b for b in blocks if b.block.function_name]
        if len(func_blocks) >= 2:
            refined = refine_structural_matches(func_blocks)
            refined_blocks = _match_results_to_blocks(refined)
            if len(refined_blocks) >= 2:
                g = _blocks_to_group(
                    group_id=f"S{i:04d}",
                    blocks=refined_blocks,
                    dup_type=DuplicateType.STRUCTURAL,
                    normalized_hash=h,
                    similarity=_calculate_similarity(refined),
                )
                if g.occurrences >= 2:
                    groups.append(g)

    return groups


def _deduplicate_phase(groups: list[DuplicateGroup]) -> list[DuplicateGroup]:
    """Phase 4: Remove overlapping groups."""
    return _deduplicate_groups(groups)


def _match_results_to_blocks(matches: list[MatchResult]) -> list[HashedBlock]:
    """Flatten a list of pairwise matches into unique hashed blocks."""
    seen: set[tuple[str, int]] = set()
    blocks: list[HashedBlock] = []

    for match in matches:
        for candidate in (match.block_a, match.block_b):
            key = (candidate.block.file, candidate.block.line_start)
            if key in seen:
                continue
            seen.add(key)
            blocks.append(candidate)

    return blocks


def _calculate_similarity(matches: list[MatchResult]) -> float:
    """Calculate similarity score for a group of pairwise matches."""
    if not matches:
        return 1.0

    return sum(match.similarity for match in matches) / len(matches)


def _find_near_duplicate_groups(
    all_blocks: list[CodeBlock],
    config: ScanConfig
) -> list[DuplicateGroup]:
    """Find near-duplicate groups using LSH."""
    groups: list[DuplicateGroup] = []
    
    # Check if LSH is enabled
    if not getattr(config, 'lsh_enabled', True):
        return groups
    
    # Only use LSH for blocks larger than configured threshold
    lsh_min_lines = getattr(config, 'lsh_min_lines', 50)
    lsh_threshold = getattr(config, 'lsh_threshold', 0.8)
    
    # Filter blocks for LSH
    lsh_blocks = [b for b in all_blocks if b.line_count >= lsh_min_lines]
    
    if not lsh_blocks:
        return groups
    
    try:
        # Find near-duplicates
        near_dup_groups = find_near_duplicates(
            lsh_blocks, 
            threshold=lsh_threshold, 
            min_lines=lsh_min_lines
        )
        
        for i, (group_id, block_similarities) in enumerate(near_dup_groups.items(), 1):
            if len(block_similarities) < 2:
                continue
            
            # Convert to DuplicateGroup format
            fragments = []
            avg_similarity = 0.0
            
            for block, similarity in block_similarities:
                fragments.append(DuplicateFragment(
                    file=block.file,
                    line_start=block.line_start,
                    line_end=block.line_end,
                    text=block.text,
                    function_name=block.function_name,
                    class_name=block.class_name,
                ))
                avg_similarity += similarity
            
            if len(fragments) >= 2:
                avg_similarity /= len(fragments)
                
                # Use function name if available
                name = fragments[0].function_name if fragments[0].function_name else None
                
                group = DuplicateGroup(
                    id=f"L{i:04d}",
                    duplicate_type=DuplicateType.NEAR_DUPLICATE,
                    fragments=fragments,
                    similarity_score=avg_similarity,
                    normalized_hash=f"lsh_{group_id}",
                    normalized_name=name,
                )
                groups.append(group)
    
    except Exception:
        # Silently fail if LSH is not available or has issues
        pass
    
    return groups


def analyze_optimized(
    config: ScanConfig | None = None,
    function_level_only: bool = False,
    use_memory_cache: bool = True,
    max_cache_mb: int = 512,
) -> DuplicationMap:
    """Run reDUP analysis with all optimizations enabled.

    Combines parallel scanning, memory caching, and incremental scanning
    for maximum performance.

    Args:
        config: Scan configuration.
        function_level_only: If True, only analyze function-level blocks.
        use_memory_cache: If True, cache files in RAM for faster access.
        max_cache_mb: Maximum memory for file cache in MB.

    Returns:
        A DuplicationMap with all duplicate groups and refactoring suggestions.
    """
    import time
    import signal
    start_time = time.time()

    config = _ensure_config(config)

    def handle_interrupt(signum, frame):
        """Handle Ctrl+C gracefully."""
        print("\n⚠️  Scan interrupted by user")
        raise KeyboardInterrupt()

    # Set up signal handler for graceful interruption
    old_handler = signal.signal(signal.SIGINT, handle_interrupt)

    try:
        # Phase 1: Optimized Scan (parallel + memory cache)
        if use_memory_cache:
            scanned_files, stats = scan_project_parallel_memory_optimized(
                config, max_workers=None, max_cache_mb=max_cache_mb
            )
        else:
            scanned_files, stats = scan_project_parallel(config)

        # Phase 2: Process blocks
        all_blocks = _process_blocks(scanned_files, function_level_only)

        # Phase 3: Hash and find duplicates with cache
        groups = _find_duplicates_phase_optimized(all_blocks, config)

        # Phase 4: Deduplicate and suggest
        final_groups = _deduplicate_phase(groups)

        # Update scan time
        stats.scan_time_ms = (time.time() - start_time) * 1000

        dup_map = DuplicationMap(
            project_path=config.root.as_posix(),
            config=config,
            stats=stats,
            groups=final_groups,
        )
        dup_map.suggestions = generate_suggestions(dup_map)

        return dup_map
    except KeyboardInterrupt:
        print("\n⚠️  Scan cancelled by user")
        # Return empty results
        return DuplicationMap(
            project_path=config.root.as_posix() if config else ".",
            config=config,
            stats=ScanStats(scan_time_ms=(time.time() - start_time) * 1000),
            groups=[],
        )
    finally:
        # Restore original signal handler
        signal.signal(signal.SIGINT, old_handler)


def analyze_parallel(
    config: ScanConfig | None = None,
    function_level_only: bool = False,
    max_workers: int | None = None,
) -> DuplicationMap:
    """Run reDUP analysis with parallel scanning for large projects.

    Args:
        config: Scan configuration. Defaults to current directory, .py files.
        function_level_only: If True, only analyze function-level blocks.
        max_workers: Number of parallel workers. Defaults to CPU count.

    Returns:
        A DuplicationMap with all duplicate groups and refactoring suggestions.
    """
    import time
    import signal
    start_time = time.time()
    
    config = _ensure_config(config)

    def handle_interrupt(signum, frame):
        """Handle Ctrl+C gracefully."""
        print("\n⚠️  Scan interrupted by user")
        raise KeyboardInterrupt()
    
    # Set up signal handler for graceful interruption
    old_handler = signal.signal(signal.SIGINT, handle_interrupt)
    
    try:
        # Phase 1: Parallel Scan
        scanned_files, stats = _scan_phase_parallel(config, max_workers)

        # Phase 2: Process blocks
        all_blocks = _process_blocks(scanned_files, function_level_only)

        # Phase 3: Hash and find duplicates
        groups = _find_duplicates_phase_optimized(all_blocks, config)

        # Phase 4: Deduplicate and suggest
        final_groups = _deduplicate_phase(groups)

        # Update scan time
        stats.scan_time_ms = (time.time() - start_time) * 1000

        dup_map = DuplicationMap(
            project_path=config.root.as_posix(),
            config=config,
            stats=stats,
            groups=final_groups,
        )
        dup_map.suggestions = generate_suggestions(dup_map)

        return dup_map
    except KeyboardInterrupt:
        print("\n⚠️  Scan cancelled by user")
        # Return empty results
        return DuplicationMap(
            project_path=config.root.as_posix() if config else ".",
            config=config,
            stats=ScanStats(scan_time_ms=(time.time() - start_time) * 1000),
            groups=[],
        )
    finally:
        # Restore original signal handler
        signal.signal(signal.SIGINT, old_handler)


