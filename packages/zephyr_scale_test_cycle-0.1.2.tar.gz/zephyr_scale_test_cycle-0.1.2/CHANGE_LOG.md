# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.2] - 2025-03-22

- Code cleanup

## [0.1.1] - 2025-03-22

### Added

- CLI flag `--version` (console script and `python -m zephyr_scale_test_cycle`).
- Console script alias `zephyr_scale_test_cycle` (same entry point as `zephyr-scale-cycle-update`).

## [0.1.0] - 2025-03-22

### Added

- Initial PyPI packaging.
- Zephyr Scale Cloud client for test cycle execution updates.
- CLI: `zephyr-scale-cycle-update` and `python -m zephyr_scale_test_cycle`.
