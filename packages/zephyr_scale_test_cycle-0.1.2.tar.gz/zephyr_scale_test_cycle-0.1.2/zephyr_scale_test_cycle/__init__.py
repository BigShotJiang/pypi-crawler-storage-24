"""
Zephyr Scale test cycle client: fetch execution keys and update execution status.

Use from workflows/BDD via CLI (``python -m zephyr_scale_test_cycle``) or import
``update_test_execution`` / ``get_execution_keys``.
"""

from .client import (
    STATUS_BLOCKED,
    STATUS_FAIL,
    STATUS_INPROGRESS,
    STATUS_NOTEXECUTED,
    STATUS_PASS,
    add_test_execution,
    get_execution_keys,
    get_headers,
    get_token,
    update_test_execution,
    verify_token_access,
    ZephyrLog,
)

__all__ = [
    "STATUS_PASS",
    "STATUS_FAIL",
    "STATUS_INPROGRESS",
    "STATUS_NOTEXECUTED",
    "STATUS_BLOCKED",
    "add_test_execution",
    "get_execution_keys",
    "get_headers",
    "get_token",
    "update_test_execution",
    "verify_token_access",
    "ZephyrLog",
]

__version__ = "0.1.2"
