"""
CLI entry: ``python -m zephyr_scale_test_cycle`` or console script ``zephyr-scale-cycle-update``.
"""

from __future__ import annotations

import argparse
import os
import sys

from zephyr_scale_test_cycle import __version__
from zephyr_scale_test_cycle.client import update_test_execution


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Update Zephyr Scale test execution status for a test cycle "
        "(workflow / BDD friendly)."
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--test-cycle-id",
        required=True,
        help="Test cycle id, e.g. R123 or PROJ-R123",
    )
    parser.add_argument(
        "--testcase-id",
        required=True,
        help="Test case id, e.g. T123 or PROJ-T123",
    )
    parser.add_argument(
        "--status",
        required=True,
        help="Zephyr status name, e.g. Pass, Fail, In Progress, Not Executed, Blocked",
    )
    parser.add_argument(
        "--duration",
        type=int,
        default=0,
        help="Execution duration in seconds (default 0)",
    )
    parser.add_argument(
        "--comment",
        default="Test execution status updated via API",
        help="Execution comment",
    )
    parser.add_argument(
        "--project-key",
        default=os.getenv("ZEPHYR_PROJECT_KEY", ""),
        help="Jira project key; required if --test-cycle-id is short (e.g. R123 only). "
        "Default: ZEPHYR_PROJECT_KEY env.",
    )
    parser.add_argument(
        "--environment",
        default="",
        help="Optional environmentName for Zephyr (default: auto-detect for In Progress / Not Executed)",
    )
    parser.add_argument(
        "--no-create-execution",
        action="store_true",
        help="Do not POST a new execution if the testcase is missing from the cycle",
    )

    args = parser.parse_args(argv)

    pk = (args.project_key or "").strip() or None

    ok = update_test_execution(
        test_cycle_id=args.test_cycle_id,
        testcase_id=args.testcase_id,
        status=args.status,
        duration=args.duration,
        comment=args.comment,
        environment_name=args.environment,
        project_key=pk,
        create_execution_if_missing=not args.no_create_execution,
    )
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
