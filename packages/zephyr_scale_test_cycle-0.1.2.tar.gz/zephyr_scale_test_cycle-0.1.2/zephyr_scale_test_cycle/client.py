"""
Zephyr Scale Cloud API client for test cycles and execution updates.

Combines patterns from legacy TestComplete and web automation helper scripts:
dynamic token/headers, robust testcase key extraction, and optional execution creation.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import re
from datetime import datetime
from logging.handlers import RotatingFileHandler
from typing import Any, Dict, Optional
import requests

# --- Logging -----------------------------------------------------------------

class ZephyrLog:
    """File (rotating) + console logger."""

    def __init__(self) -> None:
        self.logger = logging.getLogger("zephyr_scale_test_cycle")
        self.logger.setLevel(logging.INFO)
        for handler in self.logger.handlers[:]:
            self.logger.removeHandler(handler)

        if not os.path.exists("logs"):
            os.makedirs("logs")

        log_format = "%(asctime)s - %(levelname)s - %(message)s"
        date_format = "%Y-%m-%d %H:%M:%S"
        formatter = logging.Formatter(log_format, date_format)

        log_file = "logs/zephyr_test_status.log"
        file_handler = RotatingFileHandler(
            log_file, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8"
        )
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)

        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)

    def info(self, message: str) -> None:
        self.logger.info(message)

    def warning(self, message: str) -> None:
        self.logger.warning(message)

    def error(self, message: str) -> None:
        self.logger.error(message)

    def debug(self, message: str) -> None:
        self.logger.debug(message)


zephyrlog = ZephyrLog()

# --- Constants ---------------------------------------------------------------

STATUS_PASS = "Pass"
STATUS_FAIL = "Fail"
STATUS_INPROGRESS = "In Progress"
STATUS_NOTEXECUTED = "Not Executed"
STATUS_BLOCKED = "Blocked"

DEFAULT_BASE_URL = "https://api.zephyrscale.smartbear.com/v2"
MAX_RESULTS = 1000

# --- Auth / config -----------------------------------------------------------


def get_token() -> str:
    """Read Zephyr Scale API token from ``ZEPHYR_SCALE_TOKEN`` (required for API calls)."""
    token = (os.getenv("ZEPHYR_SCALE_TOKEN") or "").strip()
    if not token:
        zephyrlog.warning(
            "ZEPHYR_SCALE_TOKEN is not set or empty. Set it in your workflow or environment."
        )
    return token


def get_headers() -> Dict[str, str]:
    return {"Authorization": f"Bearer {get_token()}", "Content-Type": "application/json"}


def verify_token_access() -> bool:
    return bool(get_token())


def _resolve_project_and_cycle_key(
    test_cycle_id: str,
    project_key: Optional[str] = None,
) -> tuple[str, str]:
    """
    Zephyr requires full cycle keys like ``PROJ-R123`` (regex ``[A-Z][A-Z_0-9]+-R[0-9]+``).

    Accepts ``PROJ-R123`` or short ``R123`` when ``project_key`` or ``ZEPHYR_PROJECT_KEY`` is set.
    """
    s = test_cycle_id.strip()
    m = re.fullmatch(r"([A-Za-z][A-Za-z0-9_]*)-(R[0-9]+)", s, re.IGNORECASE)
    if m:
        pk = m.group(1).upper()
        rpart = m.group(2).upper()
        return pk, f"{pk}-{rpart}"
    m2 = re.fullmatch(r"(R[0-9]+)", s, re.IGNORECASE)
    if m2:
        pk = (project_key or os.getenv("ZEPHYR_PROJECT_KEY") or "").strip().upper()
        if not pk or not re.fullmatch(r"[A-Z][A-Z0-9_]*", pk):
            raise ValueError(
                "Short cycle id (e.g. R123) requires --project-key or ZEPHYR_PROJECT_KEY."
            )
        return pk, f"{pk}-{m2.group(1).upper()}"
    raise ValueError(
        f"Invalid test_cycle_id {test_cycle_id!r}; expected PROJ-R123 or R123 with a project key."
    )


def _resolve_testcase_key(project_key: str, testcase_id: str) -> str:
    """
    Zephyr requires full case keys matching ``.+-T[0-9]+`` (e.g. ``PROJ-T547``).
    """
    pk = project_key.upper()
    s = testcase_id.strip()
    m = re.fullmatch(rf"{re.escape(pk)}-T([0-9]+)", s, re.IGNORECASE)
    if m:
        return f"{pk}-T{m.group(1)}"
    m = re.fullmatch(r"T([0-9]+)", s, re.IGNORECASE)
    if m:
        return f"{pk}-T{m.group(1)}"
    m = re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*-T([0-9]+)", s, re.IGNORECASE)
    if m:
        return f"{pk}-T{m.group(1)}"
    raise ValueError(
        f"Invalid testcase_id {testcase_id!r}; expected T123 or PROJ-T123."
    )


# --- API helpers -------------------------------------------------------------


def extract_test_case_id_from_self_url(test_case_self_url: str, proj_key: str) -> str:
    """Extract project testcase key (e.g. PROJ-T123) from a Zephyr testcase self URL."""
    pk = proj_key.upper()
    m = re.search(
        r"/([A-Za-z][A-Za-z0-9_]*-T[0-9]+)(?:\?|/|$)", test_case_self_url, re.IGNORECASE
    )
    if m:
        try:
            return _resolve_testcase_key(pk, m.group(1))
        except ValueError:
            return ""
    marker = f"{pk}-T"
    upper_url = test_case_self_url
    idx = upper_url.upper().find(marker)
    if idx >= 0:
        after = upper_url[idx + len(marker) :]
        suffix = after.split("/")[0].split("?")[0]
        if suffix.isdigit():
            return f"{pk}-T{suffix}"
    for part in upper_url.split("/"):
        if f"{pk}-T" in part.upper():
            try:
                return _resolve_testcase_key(pk, part.split("?")[0])
            except ValueError:
                return ""
    return ""


def get_execution_keys(
    test_cycle_id: str,
    *,
    project_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: float = 30.0,
) -> Dict[str, str]:
    """
    Map testcase keys (``PROJ-T123``) to Zephyr execution keys for the given cycle.

    ``test_cycle_id`` may be ``R123`` or ``PROJ-R123`` (API always receives full ``PROJ-R123``).
    """
    try:
        project_key_resolved, full_cycle_key = _resolve_project_and_cycle_key(
            test_cycle_id, project_key
        )
    except ValueError as exc:
        zephyrlog.error(str(exc))
        return {}

    root = (base_url or os.getenv("ZEPHYR_SCALE_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")

    if not verify_token_access():
        zephyrlog.error("Cannot call API without ZEPHYR_SCALE_TOKEN.")
        return {}

    url = f"{root}/testexecutions"
    params = {
        "projectKey": project_key_resolved,
        "testCycle": full_cycle_key,
        "startAt": 0,
        "maxResults": MAX_RESULTS,
        "onlyLastExecutions": "true",
    }
    try:
        response = requests.get(url, headers=get_headers(), params=params, timeout=timeout)
        if response.status_code != 200:
            zephyrlog.error(
                f"GET testexecutions failed {response.status_code}: {response.text}"
            )
            return {}

        data = response.json()
        if isinstance(data, dict) and "error" in data:
            zephyrlog.error(f"API error: {data.get('error', data)}")
            return {}

        values = data.get("values") if isinstance(data, dict) else None
        if not values:
            zephyrlog.warning(f"No executions found for cycle {full_cycle_key}")
            return {}

        mapping: Dict[str, str] = {}
        for item in values:
            key = item.get("key")
            tc = item.get("testCase") or {}
            self_url = tc.get("self") or ""
            api_tc = extract_test_case_id_from_self_url(self_url, project_key_resolved)
            if not api_tc or not key:
                continue
            mapping[api_tc] = key

        return dict(sorted(mapping.items(), key=lambda x: x[0]))
    except Exception as exc:
        zephyrlog.error(f"Error getting execution keys: {exc}")
        return {}


def add_test_execution(
    testcase_id: str,
    test_cycle_id: str,
    test_state: str = STATUS_NOTEXECUTED,
    *,
    project_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: float = 30.0,
) -> bool:
    """Create a test execution in the cycle when one does not exist yet."""
    try:
        pk, full_cycle_key = _resolve_project_and_cycle_key(test_cycle_id, project_key)
        tc_key = _resolve_testcase_key(pk, testcase_id)
    except ValueError as exc:
        zephyrlog.error(str(exc))
        return False

    root = (base_url or os.getenv("ZEPHYR_SCALE_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")

    url = f"{root}/testexecutions"
    current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
    body: Dict[str, Any] = {
        "projectKey": pk,
        "testCaseKey": tc_key,
        "testCycleKey": full_cycle_key,
        "statusName": test_state,
        "actualEndDate": current_time,
        "executionTime": 0,
        "comment": "",
    }

    try:
        response = requests.post(url, headers=get_headers(), json=body, timeout=timeout)
        if response.status_code in (200, 201):
            zephyrlog.info(f"Created execution for {tc_key} in {full_cycle_key}")
            return True
        zephyrlog.error(
            f"add_test_execution failed for {tc_key}: {response.status_code} {response.text}"
        )
        return False
    except requests.RequestException as exc:
        zephyrlog.error(f"add_test_execution request error for {tc_key}: {exc}")
        return False


def get_environment() -> str:
    """Best-effort OS label for Zephyr ``environmentName``."""
    system = platform.system()
    release = platform.release()
    version = platform.version()

    if system == "Windows":
        try:
            build = int(version.split(".")[-1])
        except ValueError:
            build = 0
        if build >= 22000:
            return "Windows11"
        if "20348" in version:
            return "WinServer2022"
        if build >= 18362:
            return "Windows10"
        if "17763" in version:
            return "WinServer2019"
        if "14393" in version:
            return "WinServer2016"
        return f"Windows{release}"
    return f"{system}{release}"


def update_test_execution(
    *,
    test_cycle_id: str,
    testcase_id: str,
    status: str,
    duration: int = 0,
    comment: str = "",
    environment_name: str = "",
    project_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: float = 5.0,
    create_execution_if_missing: bool = True,
) -> bool:
    """
    Update a single test execution in Zephyr Scale.

    - ``duration`` is in **seconds** (sent as milliseconds to the API).
    - ``status`` is the Zephyr status name (e.g. Pass, Fail, In Progress).
    """
    try:
        pk, full_cycle_key = _resolve_project_and_cycle_key(
            test_cycle_id, project_key
        )
        tc_key = _resolve_testcase_key(pk, testcase_id)
    except ValueError as exc:
        zephyrlog.error(str(exc))
        return False

    root = (base_url or os.getenv("ZEPHYR_SCALE_BASE_URL") or DEFAULT_BASE_URL).rstrip(
        "/"
    )

    if not isinstance(duration, int):
        zephyrlog.error("duration must be an integer (seconds).")
        return False

    keys = get_execution_keys(
        test_cycle_id,
        project_key=project_key,
        base_url=root,
        timeout=timeout,
    )
    execution_key = keys.get(tc_key)

    if not execution_key and create_execution_if_missing:
        add_test_execution(
            testcase_id,
            test_cycle_id,
            STATUS_NOTEXECUTED,
            project_key=project_key,
            base_url=root,
            timeout=timeout,
        )
        keys = get_execution_keys(
            test_cycle_id,
            project_key=project_key,
            base_url=root,
            timeout=timeout,
        )
        execution_key = keys.get(tc_key)

    if not execution_key:
        zephyrlog.error(
            f"No execution key for {tc_key} in cycle {full_cycle_key}."
        )
        return False

    current_date = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
    effective_status = status
    if effective_status == STATUS_BLOCKED:
        effective_status = STATUS_FAIL

    exec_ms = duration * 1000
    if effective_status not in (STATUS_PASS, STATUS_FAIL):
        exec_ms = 0

    payload: Dict[str, Any] = {
        "statusName": effective_status,
        "executionTime": exec_ms,
        "comment": comment or "",
        "automated": True,
    }

    env = environment_name.strip()
    if not env and effective_status in (STATUS_INPROGRESS, STATUS_NOTEXECUTED):
        env = get_environment()
    if env:
        payload["environmentName"] = env

    if effective_status in (STATUS_PASS, STATUS_FAIL):
        payload["actualEndDate"] = current_date

    url = f"{root}/testexecutions/{execution_key}"
    try:
        response = requests.put(url, headers=get_headers(), json=payload, timeout=timeout)
        if response.status_code in (200, 201):
            zephyrlog.info(f"{tc_key}: {effective_status}")
            return True

        err_text = response.text
        try:
            err_json = response.json()
            if isinstance(err_json, dict) and "error" in err_json:
                err_text = str(err_json.get("error", err_text))
        except (json.JSONDecodeError, ValueError):
            pass

        zephyrlog.error(
            f"Update failed for {tc_key}: HTTP {response.status_code} {err_text}"
        )
        return False
    except requests.RequestException as exc:
        zephyrlog.error(f"Update request error for {tc_key}: {exc}")
        return False
