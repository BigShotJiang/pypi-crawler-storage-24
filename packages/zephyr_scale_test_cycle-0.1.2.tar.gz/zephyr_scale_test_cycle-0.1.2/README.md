# zephyr-scale-test-cycle

Update [Zephyr Scale Cloud](https://smartbear.com/test-management/zephyr/) test cycle executions from CI, workflows, or BDD.

## Install

```bash
pip install zephyr-scale-test-cycle
```

Requires Python 3.10+.

## CLI

After install, use a console script (both names call the same CLI), or the module form:

```bash
zephyr_scale_test_cycle --test-cycle-id R123 --testcase-id T456 --status Pass
```

```bash
zephyr-scale-cycle-update --test-cycle-id R123 --testcase-id T456 --status Pass
```

```bash
python -m zephyr_scale_test_cycle --test-cycle-id R123 --testcase-id T456 --status Pass
```

Common options:

- `--version` — Print the program version and exit.
- `--project-key` — Jira project key when ids are short (default: `ZEPHYR_PROJECT_KEY` env).
- `--duration` — Execution duration in seconds.
- `--comment` — Execution comment.
- `--environment` — Optional `environmentName` for Zephyr.
- `--no-create-execution` — Do not POST a new execution if the testcase is missing from the cycle.

## Environment variables

| Variable | Required | Description |
| -------- | -------- | ----------- |
| `ZEPHYR_SCALE_TOKEN` | **Yes** (for API calls) | Zephyr Scale Cloud API bearer token. If unset or empty, requests run without a valid token and the API will fail. |
| `ZEPHYR_PROJECT_KEY` | When using short cycle ids | Jira / project key (e.g. `PROJ`). Needed when `--test-cycle-id` is only the numeric part (e.g. `R123`) instead of a full key like `PROJ-R123`. Same as passing `--project-key`. |
| `ZEPHYR_SCALE_BASE_URL` | No | API root URL. Default: `https://api.zephyrscale.smartbear.com/v2`. Override for custom endpoints or testing. |

Example:

```bash
export ZEPHYR_SCALE_TOKEN="your-api-token"
export ZEPHYR_PROJECT_KEY="PROJ"
zephyr-scale-cycle-update --test-cycle-id R123 --testcase-id T456 --status Pass
```

## Library

```python
from zephyr_scale_test_cycle import update_test_execution, get_execution_keys

ok = update_test_execution(
    test_cycle_id="PROJ-R123",
    testcase_id="PROJ-T456",
    status="Pass",
)
```

## License

Proprietary — see [LICENSE](LICENSE).
