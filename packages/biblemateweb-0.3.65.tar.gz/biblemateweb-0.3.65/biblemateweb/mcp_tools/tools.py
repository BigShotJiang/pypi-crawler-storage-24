TOOLS = {'anyalyze_psalms': 'analyze the context and background of the Psalms in the '
                    'bible; Psalm reference must be given, e.g. Psalm 23:1-3',
 'ask_bible_scholar': 'ask a bible scholar about the bible',
 'ask_pastor': 'ask a church pastor about the bible',
 'ask_theologian': 'ask a theologian about the bible',
 'compare_bible_translations': 'compare Bible translations; bible verse '
                               'reference(s) must be given',
 'explain_bible_meaning': 'Explain the meaning of the user-given content in '
                          'reference to the Bible',
 'expound_bible_topic': 'Expound the user-given topic in reference to the '
                        'Bible; a topic must be given',
 'identify_bible_keywords': 'Identify bible key words from the user-given '
                            'content',
 'interpret_new_testament_verse': 'Interpret the user-given bible verse from '
                                  'the New Testament in the light of its '
                                  'context, together with insights of biblical '
                                  'Greek studies; a new testament bible verse '
                                  '/ reference(s) must be given',
 'interpret_old_testament_verse': 'Interpret the user-given bible verse from '
                                  'the Old Testament in the light of its '
                                  'context, together with insights of biblical '
                                  'Hebrew studies; an old testament bible '
                                  'verse / reference(s) must be given',
 'quote_bible_promises': 'Quote relevant Bible promises in response to user '
                         'request',
 'quote_bible_verses': 'quote multiple bible verses in response to user '
                       'request',
 'read_bible_commentary': 'read bible commentary on individual bible verses; '
                          'bible verse reference(s) must be given, like , like '
                          'John 3:16 or John 3:16-18',
 'read_chinese_bible_commentary': 'read Chinese bible commentary on individual bible verses; '
                          'bible verse reference(s) must be given, like , like '
                          'John 3:16 or John 3:16-18 or 約翰福音 3:16 or 約翰福音 3:16-18',
 'refine_bible_translation': 'refine the translation of a Bible verse or '
                             'passage',
 'retrieve_bible_chapter': 'retrieve a whole Bible chapter; bible chapter '
                           'reference must be given, e.g. John 3',
 'retrieve_bible_cross_references': 'retrieve cross-references of Bible '
                                    'verses; bible verse reference(s) must be '
                                    'given',
 'retrieve_bible_verses': 'retrieve Bible verses; bible verse reference(s) '
                          'must be given, e.g. John 3:16-17; single or '
                          'multiple references accepted, e.g. Deut 6:4; Gen '
                          '1:26-27',
 'retrieve_chinese_bible_verses': 'retrieve Chinese Bible verses; bible verse reference(s) '
                          'must be given, e.g. John 3:16-17; single or '
                          'multiple references accepted, e.g. Deut 6:4; Gen '
                          '1:26-27 or 申命記 6:4; 創世記 1:26-27',
 'retrieve_hebrew_or_greek_bible_verses': 'retrieve Hebrew or Greek Bible '
                                          'verses; bible verse reference(s) '
                                          'must be given, e.g. John 3:16-17; '
                                          'single or multiple references '
                                          'accepted, e.g. Deut 6:4; Gen '
                                          '1:26-27',
 'retrieve_interlinear_hebrew_or_greek_bible_verses': 'retrieve interlinear '
                                                      'Hebrew-English or '
                                                      'Greek-English Bible '
                                                      'verses; bible verse '
                                                      'reference(s) must be '
                                                      'given, e.g. John '
                                                      '3:16-17; single or '
                                                      'multiple references '
                                                      'accepted, e.g. Deut '
                                                      '6:4; Gen 1:26-27',
 'retrieve_verse_morphology': 'retrieve parsing and morphology of individual '
                              'bible verses; bible verse reference(s) must be '
                              'given, e.g. John 3:16-17; single or multiple '
                              'references accepted, e.g. Deut 6:4; Gen 1:26-27',
 'search_1_chronicles_only': 'search the book of 1 Chronicles only; search '
                             'string must be given',
 'search_1_corinthians_only': 'search the book of 1 Corinthians only; search '
                              'string must be given',
 'search_1_john_only': 'search the book of 1 John only; search string must be '
                       'given',
 'search_1_kings_only': 'search the book of 1 Kings only; search string must '
                        'be given',
 'search_1_peter_only': 'search the book of 1 Peter only; search string must '
                        'be given',
 'search_1_samuel_only': 'search the book of 1 Samuel only; search string must '
                         'be given',
 'search_1_thessalonians_only': 'search the book of 1 Thessalonians only; '
                                'search string must be given',
 'search_1_timothy_only': 'search the book of 1 Timothy only; search string '
                          'must be given',
 'search_2_chronicles_only': 'search the book of 2 Chronicles only; search '
                             'string must be given',
 'search_2_corinthians_only': 'search the book of 2 Corinthians only; search '
                              'string must be given',
 'search_2_john_only': 'search the book of 2 John only; search string must be '
                       'given',
 'search_2_kings_only': 'search the book of 2 Kings only; search string must '
                        'be given',
 'search_2_peter_only': 'search the book of 2 Peter only; search string must '
                        'be given',
 'search_2_samuel_only': 'search the book of 2 Samuel only; search string must '
                         'be given',
 'search_2_thessalonians_only': 'search the book of 2 Thessalonians only; '
                                'search string must be given',
 'search_2_timothy_only': 'search the book of 2 Timothy only; search string '
                          'must be given',
 'search_3_john_only': 'search the book of 3 John only; search string must be '
                       'given',
 'search_acts_only': 'search the book of Acts only; search string must be '
                     'given',
 'search_amos_only': 'search the book of Amos only; search string must be '
                     'given',
 'search_colossians_only': 'search the book of Colossians only; search string '
                           'must be given',
 'search_daniel_only': 'search the book of Daniel only; search string must be '
                       'given',
 'search_deuteronomy_only': 'search the book of Deuteronomy only; search '
                            'string must be given',
 'search_ecclesiastes_only': 'search the book of Ecclesiastes only; search '
                             'string must be given',
 'search_ephesians_only': 'search the book of Ephesians only; search string '
                          'must be given',
 'search_esther_only': 'search the book of Esther only; search string must be '
                       'given',
 'search_exodus_only': 'search the book of Exodus only; search string must be '
                       'given',
 'search_ezekiel_only': 'search the book of Ezekiel only; search string must '
                        'be given',
 'search_ezra_only': 'search the book of Ezra only; search string must be '
                     'given',
 'search_galatians_only': 'search the book of Galatians only; search string '
                          'must be given',
 'search_genesis_only': 'search the book of Genesis only; search string must '
                        'be given',
 'search_habakkuk_only': 'search the book of Habakkuk only; search string must '
                         'be given',
 'search_haggai_only': 'search the book of Haggai only; search string must be '
                       'given',
 'search_hebrews_only': 'search the book of Hebrews only; search string must '
                        'be given',
 'search_hosea_only': 'search the book of Hosea only; search string must be '
                      'given',
 'search_isaiah_only': 'search the book of Isaiah only; search string must be '
                       'given',
 'search_james_only': 'search the book of James only; search string must be '
                      'given',
 'search_jeremiah_only': 'search the book of Jeremiah only; search string must '
                         'be given',
 'search_job_only': 'search the book of Job only; search string must be given',
 'search_joel_only': 'search the book of Joel only; search string must be '
                     'given',
 'search_john_only': 'search the book of John only; search string must be '
                     'given',
 'search_jonah_only': 'search the book of Jonah only; search string must be '
                      'given',
 'search_joshua_only': 'search the book of Joshua only; search string must be '
                       'given',
 'search_jude_only': 'search the book of Jude only; search string must be '
                     'given',
 'search_judges_only': 'search the book of Judges only; search string must be '
                       'given',
 'search_lamentations_only': 'search the book of Lamentations only; search '
                             'string must be given',
 'search_leviticus_only': 'search the book of Leviticus only; search string '
                          'must be given',
 'search_luke_only': 'search the book of Luke only; search string must be '
                     'given',
 'search_malachi_only': 'search the book of Malachi only; search string must '
                        'be given',
 'search_mark_only': 'search the book of Mark only; search string must be '
                     'given',
 'search_matthew_only': 'search the book of Matthew only; search string must '
                        'be given',
 'search_micah_only': 'search the book of Micah only; search string must be '
                      'given',
 'search_nahum_only': 'search the book of Nahum only; search string must be '
                      'given',
 'search_nehemiah_only': 'search the book of Nehemiah only; search string must '
                         'be given',
 'search_numbers_only': 'search the book of Numbers only; search string must '
                        'be given',
 'search_obadiah_only': 'search the book of Obadiah only; search string must '
                        'be given',
 'search_philemon_only': 'search the book of Philemon only; search string must '
                         'be given',
 'search_philippians_only': 'search the book of Philippians only; search '
                            'string must be given',
 'search_proverbs_only': 'search the book of Proverbs only; search string must '
                         'be given',
 'search_psalms_only': 'search the book of Psalms only; search string must be '
                       'given',
 'search_revelation_only': 'search the book of Revelation only; search string '
                           'must be given',
 'search_romans_only': 'search the book of Romans only; search string must be '
                       'given',
 'search_ruth_only': 'search the book of Ruth only; search string must be '
                     'given',
 'search_song_of_songs_only': 'search the book of Song of Songs only; search '
                              'string must be given',
 'search_titus_only': 'search the book of Titus only; search string must be '
                      'given',
 'search_zechariah_only': 'search the book of Zechariah only; search string '
                          'must be given',
 'search_zephaniah_only': 'search the book of Zephaniah only; search string '
                          'must be given',
 'study_bible_themes': 'Study Bible Themes in relation to the user content',
 'study_new_testament_themes': 'Study Bible Themes in a New Testament passage; '
                               'new testament bible book / chapter / passage / '
                               'reference(s) must be given',
 'study_old_testament_themes': 'Study Bible Themes in a Old Testament passage; '
                               'old testatment bible book / chapter / passage '
                               '/ reference(s) must be given',
 'translate_greek_bible_verse': 'Translate a Greek bible verse: Greek bible '
                                'text must be given',
 'translate_hebrew_bible_verse': 'Translate a Hebrew bible verse; Hebrew bible '
                                 'text must be given',
 'write_bible_applications': 'Provide detailed applications of a bible '
                             'passages; bible book / chapter / passage / '
                             'reference(s) must be given',
 'write_bible_book_introduction': 'Write a detailed introduction on a book in '
                                  'the bible; bible book must be given',
 'write_bible_canonical_context': 'Write about canonical context of a bible '
                                  'book / chapter / passage; bible book / '
                                  'chapter / passage / reference(s) must be '
                                  'given',
 'write_bible_chapter_summary': 'Write a detailed interpretation on a bible '
                                'chapter; a bible chapter must be given',
 'write_bible_character_study': 'Write comprehensive information on a given '
                                'bible character in the bible; a bible '
                                'character name must be given',
 'write_bible_devotion': 'Write a devotion on a bible passage; bible book / '
                         'chapter / passage / reference(s) must be given',
 'write_bible_insights': 'Write exegetical insights in detail on a bible '
                         'passage; bible book / chapter / passage / '
                         'reference(s) must be given',
 'write_bible_location_study': 'write comprehensive information on a bible '
                               'location; a bible location name must be given',
 'write_bible_outline': 'provide a detailed outline of a bible book / chapter '
                        '/ passage; bible book / chapter / passage / '
                        'reference(s) must be given',
 'write_bible_perspectives': 'Write biblical perspectives and principles in '
                             'relation to the user content',
 'write_bible_prayer': 'Write a prayer pertaining to the user content in '
                       'reference to the Bible',
 'write_bible_questions': 'Write thought-provoking questions for bible study '
                          'group discussion; bible book / chapter / passage / '
                          'reference(s) must be given',
 'write_bible_related_summary': 'Write a summary on the user-given content in '
                                'reference to the Bible',
 'write_bible_sermon': 'Write a bible sermon based on a bible passage; bible '
                       'book / chapter / passage / reference(s) must be given',
 'write_bible_theology': 'write the theological messages conveyed in the '
                         'user-given content, in reference to the Bible',
 'write_bible_thought_progression': 'write Bible Thought Progression of a '
                                    'bible book / chapter / passage; bible '
                                    'book / chapter / passage / reference(s) '
                                    'must be given',
 'write_new_testament_highlights': 'Write Highlights in a New Testament '
                                   'passage in the bible; new testament bible '
                                   'book / chapter / passage / reference(s) '
                                   'must be given',
 'write_new_testament_historical_context': 'write the Bible Historical Context '
                                           'of a New Testament passage in the '
                                           'bible; new testament bible book / '
                                           'chapter / passage / reference(s) '
                                           'must be given',
 'write_old_testament_highlights': 'Write Highlights in a Old Testament '
                                   'passage in the bible; old testament bible '
                                   'book / chapter / passage / reference(s) '
                                   'must be given',
 'write_old_testament_historical_context': 'write the Bible Historical Context '
                                           'of a Old Testament passage in the '
                                           'bible; old testament bible book / '
                                           'chapter / passage / reference(s) '
                                           'must be given',
 'write_pastor_prayer': 'write a prayer, out of a church pastor heart, based '
                        'on user input',
 'write_short_bible_prayer': 'Write a short prayer, in one paragraph only, '
                             'pertaining to the user content in reference to '
                             'the Bible',
 'search_the_bible': '''search the bible; search string must be given as the tool instruction

ATTENTION: Special notes about searching the bibles:

* Search the whole English Bible
A simple search string searches the whole English Bible by default, e.g. "love one another"

* Search the whole Chinese Bible
Prefix the search string with "CUV:::", to search the whole Chinese Bible, e.g. "CUV:::彼此相愛"

* Search specific books in the Bible
You have to use the following book abbreviations (case-sensitive) with exact spellings, e.g. use "Rom", instead of "Romans", for searching the book of Romans:

['Gen', 'Exod', 'Lev', 'Num', 'Deut', 'Josh', 'Judg', 'Ruth', '1Sam', '2Sam', '1Kgs', '2Kgs', '1Chr', '2Chr', 'Ezra', 'Neh', 'Esth', 'Job', 'Ps', 'Prov', 'Eccl', 'Song', 'Isa', 'Jer', 'Lam', 'Ezek', 'Dan', 'Hos', 'Joel', 'Amos', 'Obad', 'Jonah', 'Mic', 'Nah', 'Hab', 'Zeph', 'Hag', 'Zech', 'Mal', 'Matt', 'Mark', 'Luke', 'John', 'Acts', 'Rom', '1Cor', '2Cor', 'Gal', 'Eph', 'Phil', 'Col', '1Thess', '2Thess', '1Tim', '2Tim', 'Titus', 'Phlm', 'Heb', 'Jas', '1Pet', '2Pet', '1John', '2John', '3John', 'Jude', 'Rev']

For examples (use comma "," as separator when more than one condition is specified):

* to search for "love one another" in the book of John in the English Bible, use the following search string: "John:::love one another"
* to search for "彼此相愛" in the book of John in the Chinese Bible, use the following search string: "CUV,John:::彼此相愛"

Multiple books search is supported, for examples (use comma "," as separator):

* to search for "love one another" in the book of John and Romans in the English Bible, use the following search string: "John,Rom:::love one another"
* to search for "彼此相愛" in the book of John and Romans in the Chinese Bible, use the following search string: "CUV,John,Rom:::彼此相愛"

REMEMBER: The tool instruction for using this tool should be the search string ONLY, without any other text.'''}