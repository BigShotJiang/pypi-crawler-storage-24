# Ouroboros Mode History (Archived)

**Status**: Completed and archived. All legacy modes removed in v12.66+.

## Timeline

1. **v10.x**: Introduced ouroboros modes — year, month, week, day
2. **v11.x**: Switched production from year → month (Issue #134)
3. **v12.57+**: Switched production from month → day (day-mode migration)
4. **v12.66+**: Removed year, month, week modes entirely from codebase

## Current State

Only `"day"` mode exists. Every day is an independent, atomically re-backfillable unit.
All 41M+ bars on bigblack are day mode. Legacy bars were deleted via
`ALTER TABLE DELETE WHERE ouroboros_mode != 'day'`.

The original 7-phase switchover runbook (Issue #134) is no longer relevant
since all legacy modes have been removed from the codebase.
