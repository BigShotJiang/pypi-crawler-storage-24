from dataclasses import dataclass
from datetime import date, datetime
from enum import Enum
from typing import Literal

class OuroborosMode(str, Enum):
    DAY = "day"

@dataclass(frozen=True)
class OuroborosBoundary:
    timestamp: datetime
    mode: OuroborosMode
    reason: str

    @property
    def timestamp_ms(self) -> int: ...
    @property
    def timestamp_us(self) -> int: ...

@dataclass
class OrphanedBarMetadata:
    is_orphan: bool = True
    ouroboros_boundary: datetime | None = None
    reason: str | None = None
    expected_duration_us: int | None = None

def get_ouroboros_boundaries(
    start: date,
    end: date,
    mode: Literal["day"] = "day",
) -> list[OuroborosBoundary]: ...
def get_operational_ouroboros_mode() -> Literal["day"]: ...
def validate_ouroboros_mode(mode: str) -> Literal["day"]: ...
