# Asynchronous Portals Marketplace API fork

#### Installation

`pip install faportalsmp`

## Documentation

You can find detailed documentation & what's changed here -> [https://bleach-1.gitbook.io/aportalsmp](https://bleach-1.gitbook.io/aportalsmp)
