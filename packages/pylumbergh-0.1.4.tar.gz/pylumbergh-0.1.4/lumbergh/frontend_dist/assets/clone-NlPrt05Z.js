import{b as r}from"./graph-DcycWcGa.js";var e=4;function a(o){return r(o,e)}export{a as c};
