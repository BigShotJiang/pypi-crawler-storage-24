# CARLA Traffic Scenario MCP Server

用于阿里云百炼平台的 MCP 服务，生成 CARLA 交通仿真场景配置脚本。

## 功能

- 生成道路/路口类型配置
- 生成交通流配置
- 生成信号灯控制配置
- 生成车辆行为配置
- 生成行人配置
- 生成天气配置
- 生成完整的 CARLA 交通场景 Python 脚本

## 安装

### 从 PyPI 安装（推荐）

```bash
pip install carla-traffic-mcp
```

### 使用 uvx 运行

```bash
uvx -y carla-traffic-mcp
```

## 使用

在百炼平台配置 MCP 服务时使用以下 JSON：

```json
{
  "mcpServers": {
    "carla-traffic-mcp": {
      "command": "uvx",
      "args": [
        "-y",
        "carla-traffic-mcp"
      ]
    }
  }
}
```

## MCP 工具列表

| 工具名称 | 功能描述 |
|---------|---------|
| `generate_road_junction` | 生成道路/路口类型配置 |
| `generate_traffic_flow` | 生成交通流配置 |
| `generate_signal_control` | 生成信号灯控制配置 |
| `generate_vehicle_behavior` | 生成车辆行为配置 |
| `generate_pedestrian` | 生成行人配置 |
| `generate_weather` | 生成天气配置 |
| `generate_full_scenario` | 生成完整的 CARLA 交通场景 Python 脚本 |

## 支持的场景类型

| 场景 | 地图 | 说明 |
|-----|------|------|
| 十字路口 | Town03 | 标准城市十字路口 |
| T字路口 | Town02 | T型交叉口 |
| 环岛 | Town03 | 圆形环岛 |
| 五岔路口 | Town04 | 复杂五岔路口 |
| 高速公路 | Town05 | 高速公路场景 |

## 开发

### 本地开发

```bash
# 克隆仓库
git clone https://github.com/your-username/carla-traffic-mcp.git
cd carla-traffic-mcp

# 安装开发依赖
pip install -e ".[dev]"

# 运行测试
pytest
```

### 发布到 PyPI

参考 [PyPI发布指南.md](../PyPI发布指南.md)

## 许可证

MIT
