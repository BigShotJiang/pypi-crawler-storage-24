"""CARLA Traffic Scenario MCP Server"""
__version__ = "0.1.0"
