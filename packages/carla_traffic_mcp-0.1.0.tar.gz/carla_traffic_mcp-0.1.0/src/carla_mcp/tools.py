#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CARLA Traffic Scenario Generation Tools
MCP工具函数实现，用于生成CARLA交通仿真场景配置
"""

from typing import Optional


# ========== 地图与场景映射 ==========
MAP_MAPPING = {
    "cross": {"map": "Town03", "desc": "十字路口场景"},
    "T": {"map": "Town02", "desc": "T字路口场景"},
    "roundabout": {"map": "Town03", "desc": "环岛场景"},
    "five_way": {"map": "Town04", "desc": "五岔路口场景"},
    "highway": {"map": "Town05", "desc": "高速公路场景"},
}

# ========== 车流密度参数 ==========
DENSITY_CONFIG = {
    "low": {"count": 20, "distance": 5.0, "speed_diff": 0.0, "desc": "低密度"},
    "normal": {"count": 50, "distance": 3.5, "speed_diff": 10.0, "desc": "正常密度"},
    "high": {"count": 80, "distance": 2.5, "speed_diff": 15.0, "desc": "高密度"},
    "peak": {"count": 120, "distance": 2.0, "speed_diff": 20.0, "desc": "高峰期"},
}

# ========== 天气参数映射 ==========
WEATHER_MAPPING = {
    "clear": {"params": "carla.WeatherParameters.ClearNoon", "desc": "晴天中午"},
    "cloudy": {"params": "carla.WeatherParameters.CloudyNoon", "desc": "多云"},
    "rain": {"params": "carla.WeatherParameters.HardRainNoon", "desc": "雨天"},
    "fog": {"params": "carla.WeatherParameters.Fog", "desc": "雾天"},
    "night": {"params": "carla.WeatherParameters.ClearNight", "desc": "夜间"},
}


def generate_road_junction(junction_type: str) -> str:
    """生成道路/路口类型配置代码片段"""
    config = MAP_MAPPING.get(junction_type, MAP_MAPPING["cross"])
    map_name = config["map"]
    desc = config["desc"]

    code = f'''# ========== 道路/路口配置 ==========
# {desc}
world = client.load_world('{map_name}')
print("[✓] 场景加载完成：{desc}（{map_name}）")'''

    return code


def generate_traffic_flow(density: str, vehicle_count: Optional[int] = None) -> str:
    """生成交通流配置代码片段"""
    config = DENSITY_CONFIG.get(density, DENSITY_CONFIG["normal"])
    count = vehicle_count if vehicle_count else config["count"]
    distance = config["distance"]
    speed_diff = config["speed_diff"]
    desc = config["desc"]

    code = f'''# ========== 交通流配置（{desc}）==========
vehicles = []
vehicle_count = {count}

for i in range(vehicle_count):
    bp = random.choice(blueprint_library.filter('vehicle.*'))
    spawn_point = random.choice(spawn_points)
    vehicle = world.try_spawn_actor(bp, spawn_point)
    if vehicle:
        vehicle.set_autopilot(True)
        vehicles.append(vehicle)

# 车流控制参数
traffic_manager.set_synchronous_mode(True)
traffic_manager.set_global_distance_to_leading_vehicle({distance})
traffic_manager.global_percentage_speed_difference({speed_diff})

print(f"[✓] 交通流配置完成：{{len(vehicles)}}辆车（{desc}）")'''

    return code


def generate_signal_control(cycle: int, green_time: int = 30,
                           red_time: int = 25, yellow_time: int = 5) -> str:
    """生成信号灯控制配置代码片段"""

    code = f'''# ========== 信号灯控制配置 ==========
traffic_lights = world.get_actors().filter('traffic.traffic_light')
print(f"[✓] 检测到 {{len(traffic_lights)}} 个信号灯")

# 信号灯配时（周期{cycle}秒）
for tl in traffic_lights:
    tl.set_red_time({red_time})
    tl.set_green_time({green_time})
    tl.set_yellow_time({yellow_time})

print("[✓] 信号灯配时完成：周期{cycle}秒（绿灯{green_time}秒/红灯{red_time}秒/黄灯{yellow_time}秒）")'''

    return code


def generate_vehicle_behavior(avg_speed: float, lane_change_freq: str = "normal",
                              aggressive_level: str = "normal") -> str:
    """生成车辆行为配置代码片段"""

    # 速度转换为m/s
    speed_ms = avg_speed / 3.6

    # 换道频率映射
    lc_mapping = {"low": 0.1, "normal": 0.3, "high": 0.6}
    lc_prob = lc_mapping.get(lane_change_freq, 0.3)

    # 激进程度映射
    aggr_mapping = {"cautious": 30.0, "normal": 10.0, "aggressive": -10.0}
    aggr_value = aggr_mapping.get(aggressive_level, 10.0)

    code = f'''# ========== 车辆行为配置 ==========
# 平均车速：{avg_speed} km/h
# 换道频率：{lane_change_freq}
# 驾驶激进程度：{aggressive_level}

for vehicle in vehicles:
    traffic_manager.auto_lane_change(vehicle, {lc_prob})
    traffic_manager.vehicle_percentage_speed_difference(vehicle, {aggr_value})
    traffic_manager.distance_to_leading_vehicle(vehicle, 3.0)

print("[✓] 车辆行为配置完成")'''

    return code


def generate_pedestrian(count: int, crossing_freq: str = "normal") -> str:
    """生成行人配置代码片段"""

    code = f'''# ========== 行人配置 ==========
walkers = []
walker_count = {count}

for i in range(walker_count):
    walker_bp = random.choice(blueprint_library.filter('walker.pedestrian.*'))
    spawn_point = carla.Transform()
    spawn_point.location = random.choice(spawn_points).location
    spawn_point.location.z += 1.0

    walker = world.try_spawn_actor(walker_bp, spawn_point)
    if walker:
        ctrl_bp = blueprint_library.find('controller.ai.walker')
        ctrl = world.spawn_actor(ctrl_bp, carla.Transform(), walker)
        ctrl.start()
        ctrl.go_to_location(world.get_random_location_from_navigation())
        ctrl.set_max_speed(1.2)  # 正常步行速度
        walkers.extend([walker, ctrl])

print(f"[✓] 行人配置完成：{{len(walkers)//2}}个行人")'''

    return code


def generate_weather(weather_type: str) -> str:
    """生成天气配置代码片段"""
    config = WEATHER_MAPPING.get(weather_type, WEATHER_MAPPING["clear"])
    params = config["params"]
    desc = config["desc"]

    code = f'''# ========== 天气配置 ==========
# {desc}
world.set_weather({params})
print("[✓] 天气配置完成：{desc}")'''

    return code


def generate_full_scenario(
    scenario_name: str,
    junction_type: str = "cross",
    traffic_density: str = "normal",
    signal_cycle: int = 60,
    pedestrian_count: int = 20,
    weather_type: str = "clear"
) -> str:
    """生成完整的CARLA交通场景Python脚本"""

    # 获取配置参数
    map_config = MAP_MAPPING.get(junction_type, MAP_MAPPING["cross"])
    density_config = DENSITY_CONFIG.get(traffic_density, DENSITY_CONFIG["normal"])
    weather_config = WEATHER_MAPPING.get(weather_type, WEATHER_MAPPING["clear"])

    map_name = map_config["map"]
    vehicle_count = density_config["count"]
    distance = density_config["distance"]
    speed_diff = density_config["speed_diff"]
    density_desc = density_config["desc"]
    weather_params = weather_config["params"]
    weather_desc = weather_config["desc"]

    # 计算信号灯时间
    green_time = int(signal_cycle * 0.5)
    red_time = int(signal_cycle * 0.42)
    yellow_time = signal_cycle - green_time - red_time

    script = f'''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CARLA 交通仿真场景配置脚本
场景名称：{scenario_name}
生成时间：2026-03-15
由 CARLA MCP Agent 自动生成
"""

import carla
import random
import time

def main():
    # ========== 连接CARLA服务器 ==========
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)

    # ========== 道路/路口配置 ==========
    world = client.load_world('{map_name}')
    print("[✓] 场景加载完成：{map_config['desc']}（{map_name}）")

    # ========== 天气配置 ==========
    world.set_weather({weather_params})
    print("[✓] 天气配置完成：{weather_desc}")

    # ========== 获取蓝图库和生成点 ==========
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    traffic_manager = client.get_trafficmanager()

    # ========== 交通流配置（{density_desc}）==========
    vehicles = []
    vehicle_count = {vehicle_count}

    for i in range(vehicle_count):
        bp = random.choice(blueprint_library.filter('vehicle.*'))
        spawn_point = random.choice(spawn_points)
        vehicle = world.try_spawn_actor(bp, spawn_point)
        if vehicle:
            vehicle.set_autopilot(True)
            vehicles.append(vehicle)

    traffic_manager.set_synchronous_mode(True)
    traffic_manager.set_global_distance_to_leading_vehicle({distance})
    traffic_manager.global_percentage_speed_difference({speed_diff})

    print(f"[✓] 交通流配置完成：{{len(vehicles)}}辆车（{density_desc}）")

    # ========== 信号灯控制配置 ==========
    traffic_lights = world.get_actors().filter('traffic.traffic_light')
    for tl in traffic_lights:
        tl.set_red_time({red_time})
        tl.set_green_time({green_time})
        tl.set_yellow_time({yellow_time})

    print(f"[✓] 信号灯配时完成：周期{signal_cycle}秒")

    # ========== 行人配置 ==========
    walkers = []
    for i in range({pedestrian_count}):
        walker_bp = random.choice(blueprint_library.filter('walker.pedestrian.*'))
        spawn_point = carla.Transform()
        spawn_point.location = random.choice(spawn_points).location
        spawn_point.location.z += 1.0

        walker = world.try_spawn_actor(walker_bp, spawn_point)
        if walker:
            ctrl_bp = blueprint_library.find('controller.ai.walker')
            ctrl = world.spawn_actor(ctrl_bp, carla.Transform(), walker)
            ctrl.start()
            ctrl.go_to_location(world.get_random_location_from_navigation())
            ctrl.set_max_speed(1.2)
            walkers.extend([walker, ctrl])

    print(f"[✓] 行人配置完成：{{len(walkers)//2}}个行人")

    # ========== 场景配置汇总 ==========
    print(f"""
╔════════════════════════════════════════╗
║       交通场景配置完成                  ║
╠════════════════════════════════════════╣
║ 场景名称：{scenario_name:<24s}  ║
║ 场景类型：{map_config['desc']:<24s}  ║
║ 车流密度：{density_desc:<24s}  ║
║ 车辆数量：{{len(vehicles):3d}} 辆                      ║
║ 行人数量：{{len(walkers)//2:3d}} 个                      ║
║ 信号周期：{signal_cycle:3d} 秒                         ║
║ 天气条件：{weather_desc:<24s}  ║
╚════════════════════════════════════════╝
    """)

    # ========== 运行仿真 ==========
    print("开始仿真运行（按Ctrl+C停止）...")
    try:
        while True:
            world.tick()
            time.sleep(0.01)
    except KeyboardInterrupt:
        print("\\n正在清理场景...")
        for vehicle in vehicles:
            vehicle.destroy()
        for actor in walkers:
            actor.destroy()
        print("场景清理完成，再见！")

if __name__ == '__main__':
    main()
'''

    return script
