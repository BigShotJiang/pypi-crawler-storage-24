# tibet-anticheat

**Anti-cheat through provenance, not surveillance — every game action is a TIBET token, no kernel driver needed.**

Part of the [TIBET protocol suite](https://pypi.org/project/tibet-core/) by [Humotica AI Lab](https://humotica.com).

## The Problem

Current anti-cheat is broken:
- **Kernel drivers** (EAC, Vanguard) — ring-0 access, security risk, privacy nightmare
- **Signature scanning** — always behind, cheat devs update faster
- **Always-online DRM** — punishes legitimate players
- **Server-side only** — can't work for P2P/indie games

## The Solution

**Every game action is a TIBET token.** Math catches cheaters, not surveillance.

```python
from tibet_anticheat import AntiCheatEngine, ActionType, Vec3

engine = AntiCheatEngine()
session = engine.start_session("player-42")

# Game server records actions (each = TIBET token)
session.record_action(ActionType.MOVE, position=Vec3(10, 0, 5))
session.record_action(ActionType.SHOOT, position=Vec3(10, 0, 5),
                      target_position=Vec3(50, 2, 30))

# End session — all detectors run automatically
report = engine.end_session(session.session_id)
print(report["verdict"])  # CLEAN / SUSPICIOUS / GUILTY
```

## Install

```bash
pip install tibet-anticheat
```

## What It Detects

| Cheat | How TIBET Catches It |
|-------|---------------------|
| **Aimbot** | Aim snap analysis: instant corrections, zero jitter, perfect tracking |
| **Speedhack** | Position/time ratio exceeds game physics |
| **Teleport** | Position jumps with no movement chain |
| **Triggerbot** | Reaction times below human limits (<100ms consistently) |
| **Macro** | Unnatural timing regularity (coefficient of variation) |
| **Item dupe** | No TIBET token for how you acquired that item |
| **Chain tamper** | Action chain hash broken — someone modified the sequence |

## How It Works

```
Player Input → Game Action → TIBET Token → Chain → Analysis
                                ↓
                         ERIN: what happened
                         ERAAN: previous action (hash-linked)
                         EROMHEEN: input sample, tick, position
                         ERACHTER: intent
```

**Human players** have natural patterns:
- Aim has jitter (hand tremor), acceleration curves
- Movement has inertia and reaction delays
- Reaction time: 150-250ms (pros: 130-180ms)
- Accuracy varies with distance and stress

**Cheaters** break these patterns:
- Aimbot: instant corrections, zero jitter, constant speed
- Speedhack: impossible velocity for game physics
- Triggerbot: consistent sub-100ms reactions

## Player Trust (FIR/A)

Players get a trust score that evolves over time:

- **Fair Play (30%)**: clean sessions / total sessions
- **Integrity (30%)**: action chain integrity
- **Recency (15%)**: recent clean play recovers trust
- **Anomaly (25%)**: severe cheats reduce trust faster

High-trust players → less scrutiny. Low-trust → more analysis. Zero-trust → auto-ban.

## CLI

```bash
# Full demo with fair players + cheaters
tibet-anticheat demo

# Only fair players
tibet-anticheat demo --scenario fair

# Only cheaters
tibet-anticheat demo --scenario cheater
```

## For Indie Developers

```python
# That's it. No SDK integration. No kernel driver.
# No monthly fees. No account system. MIT licensed.

from tibet_anticheat import AntiCheatEngine

engine = AntiCheatEngine(max_speed=10.0, max_sprint_speed=18.0)
```

## P2P Games (with tibet-mesh)

```python
from tibet_mesh import MeshNode
from tibet_anticheat import AntiCheatEngine

# No central server — each node validates actions
node = MeshNode(device_id="game-host")
engine = AntiCheatEngine()

# Players connect via mesh, actions verified by all peers
# Cheater's action chain doesn't match → consensus rejects
```

## Also Works As DRM

Every game copy can get a TIBET token at purchase. The provenance chain IS the proof of ownership. No always-online server needed.

## IETF Drafts

- [TIBET Provenance](https://datatracker.ietf.org/doc/draft-vandemeent-tibet-provenance/)
- [JIS Identity](https://datatracker.ietf.org/doc/draft-vandemeent-jis-identity/)

## License

MIT — Humotica AI Lab 2025-2026
