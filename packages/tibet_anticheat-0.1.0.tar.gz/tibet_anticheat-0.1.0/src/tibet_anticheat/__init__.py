"""
tibet-anticheat — Anti-Cheat Through Provenance
================================================

No kernel driver. No spyware. No surveillance.
Every game action is a TIBET token. Math catches cheaters.

Aimbot? The input provenance doesn't match human patterns.
Speedhack? The position/time ratio is physically impossible.
Wallhack? Actions target things not in the provenance chain.
Item duplication? No TIBET token for how you got that item.

Works for:
- AAA studios (Valve, Epic, EA)
- Indie developers (pip install tibet-anticheat)
- P2P games (no central server needed — combine with tibet-mesh)

Usage::

    from tibet_anticheat import AntiCheatEngine, ActionType, Vec3

    engine = AntiCheatEngine()
    session = engine.start_session("player-42")
    session.record_action(ActionType.MOVE, position=Vec3(10, 0, 5))
    session.record_action(ActionType.SHOOT,
        position=Vec3(10, 0, 5),
        target_position=Vec3(50, 2, 30),
    )
    report = engine.end_session(session.session_id)
    print(report["verdict"])  # CLEAN / SUSPICIOUS / GUILTY

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica AI Lab 2025-2026
"""

from .engine import AntiCheatEngine, GameSession
from .action import ActionRecorder, ActionType, GameAction, Vec3, InputSample
from .detector import (
    AimbotDetector,
    SpeedhackDetector,
    ReactionDetector,
    MacroDetector,
    Detection,
    CheatType,
)
from .player import PlayerProfile

__version__ = "0.1.0"

__all__ = [
    "AntiCheatEngine",
    "GameSession",
    "ActionRecorder",
    "ActionType",
    "GameAction",
    "Vec3",
    "InputSample",
    "AimbotDetector",
    "SpeedhackDetector",
    "ReactionDetector",
    "MacroDetector",
    "Detection",
    "CheatType",
    "PlayerProfile",
]
