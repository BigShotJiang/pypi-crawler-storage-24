"""
MemoraLabs Python SDK.

Quick start:
    from memoralabs import MemoraLabs

    client = MemoraLabs(api_key="ml_your_key")
    memory = client.add("User prefers dark mode", user_id="user_42")
    results = client.search("display preferences", user_id="user_42")
    print(results.results[0].text)
"""
from .client import MemoraLabs
from .exceptions import (
    AuthError,
    MemoraLabsError,
    NotFoundError,
    PlanLimitError,
    RateLimitError,
    ValidationError,
)
from .models import (
    BillingStatusResponse,
    CheckoutResponse,
    GapResponse,
    KeyRotateResponse,
    MemoryListResponse,
    MemoryResponse,
    SearchResponse,
    SearchResult,
    SignupResponse,
)

__all__ = [
    # Client
    "MemoraLabs",
    # Models
    "SignupResponse",
    "KeyRotateResponse",
    "MemoryResponse",
    "MemoryListResponse",
    "SearchResult",
    "SearchResponse",
    "GapResponse",
    "BillingStatusResponse",
    "CheckoutResponse",
    # Exceptions
    "MemoraLabsError",
    "AuthError",
    "PlanLimitError",
    "NotFoundError",
    "RateLimitError",
    "ValidationError",
]

__version__ = "1.0.0"
