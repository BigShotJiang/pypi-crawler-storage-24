Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Global Implementation Plan

## Goal

Execute the client-server synchronization defined in `docs/tech_spec/tech_spec.md` while preserving adapter-centric architecture and full security-mode coverage.

## Input Artifacts

Before executing this plan, these parent artifacts must exist and remain the source of truth:

- `docs/tech_spec/tech_spec.md`
- `docs/tech_spec/steps/adapter-centric-client-foundation.md`
- `docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- `docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- `docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`

## Global Steps

Each global step is executed only through its own parent document:

1. `docs/tech_spec/steps/adapter-centric-client-foundation.md`
   Goal: establish the adapter-only runtime foundation for auth, transport, TLS/mTLS, and client construction.
2. `docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
   Goal: align public embed-related APIs and result normalization with the real server contract.
3. `docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
   Goal: make queue/job/WebSocket identifier handling explicit, safe, and non-ambiguous.
4. `docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
   Goal: validate the synchronized implementation across all required modes and real runtime scenarios.

## Dependency Model

- Step 1 has no upstream dependency and must complete first.
- Step 2 depends on Step 1 because it consumes the adapter-centric runtime model defined there.
- Step 3 depends on Step 1 because it also consumes the adapter-centric runtime model defined there.
- Step 2 and Step 3 must remain mutually synchronized because they both modify embed execution behavior and must preserve the same identifier semantics.
- Step 4 depends on Steps 1-3 and validates the integrated result only after coding work for those steps is complete.

## Coordination Protocol For Parallel Steps

After Step 1 completes, Steps 2 and 3 may run in parallel only under these rules:

1. Both branches must consume the same current `docs/tech_spec/tech_spec.md`.
2. Both branches must consume the same current Step 1 outputs and assumptions.
3. They must not silently redefine shared terms such as:
   - adapter response format
   - immediate JSON-RPC result
   - queued result
   - `job_id`
   - JSON-RPC request `id`
   - WebSocket delivery/correlation identifier
4. If both branches need to touch the same source file, ownership and order must be made explicit in tactical planning before coding starts.
5. Step 2 must not define result handling in a way that collapses identifier distinctions required by Step 3.
6. Step 3 must not define identifier behavior that contradicts the server response and result-handling semantics defined in Step 2.
7. Before coding begins, both branches must perform a cross-check of:
   - shared method signatures
   - shared response structures
   - shared identifier semantics
8. If a contradiction is found, both branches must pause and escalate to the global orchestrator before execution continues.

## Change Management Protocol

If `docs/tech_spec/tech_spec.md` or any global step document changes during execution:

1. Pause all affected tactical branches.
2. Update all affected global parent documents first.
3. Require affected `orchestrator_tactical` branches to resynchronize tactical and atomic planning.
4. Do not resume coding on affected branches until explicit resynchronization completion is reported.

## Conflict Resolution Protocol

If Steps 2 and 3 conflict during parallel execution:

1. Pause both branches.
2. Report the exact conflicting artifact paths and conflicting definitions.
3. Resolve the conflict at the global level by updating parent documents.
4. Resynchronize both branches through `orchestrator_tactical`.
5. Resume only after the conflict is explicitly cleared.

## Monitoring And Status Protocol

- Monitoring cadence: every `30` seconds by default while delegated work is active.
- Every status report from `orchestrator_tactical` must include:
  - `Tactical Branch State`
  - `Subordinate Agents State`
  - blockers or waiting conditions
  - recommended next action
- `Subordinate Agents State` must explicitly track:
  - `planner_auto`
  - `coder_auto`
  - `tester_auto`
- A branch is not accepted as complete until claimed artifacts are verified against files on disk.

## Failure And Recovery Protocol

If a branch fails or verification fails:

1. Report the exact failure point and failure category.
2. Decide whether to retry, resynchronize, or escalate.
3. Block downstream completion until the failure is resolved.
4. If parent documents must change, apply the change-management protocol above.

## Delegation Protocol

For every global step, the global orchestrator must brief `orchestrator_tactical` with:

- exact path to `docs/tech_spec/tech_spec.md`
- exact path to the parent global step document
- the requirement to create or update tactical tasks only under:
  - `docs/tech_spec/branches/<global_step_slug>/tasks/`
- the requirement to create atomic steps only through `planner_auto` under:
  - `docs/tech_spec/branches/<global_step_slug>/tasks/<tactical_task_slug>/steps/`
- the requirement to preserve LLAMA-readiness at tactical and atomic levels
- the requirement to preserve safe parallelism where dependencies allow
- the requirement to verify all claimed planning artifacts against files on disk before reporting completion
- the requirement to report subordinate agent state in every monitoring/status response

## Step References

The implementation plan is intentionally brief. The execution-ready detail lives in:

- `docs/tech_spec/steps/adapter-centric-client-foundation.md`
- `docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- `docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- `docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`

## Verification Requirements

The integrated work is considered verified only when all of the following are true:

1. All required tests in `tests/` pass.
2. Security matrix validation passes for:
   - http
   - http + token
   - http + token + roles
   - https
   - https + token
   - https + token + roles
   - mtls
   - mtls + roles
3. Real vectorization validation on `localhost:8001` passes.
4. Adapter integration tests pass.
5. Identifier-separation tests pass.
6. Immediate JSON-RPC result mode and deferred WebSocket/JSON-RPC completion mode both pass.

## Completion Condition

The assignment is complete only when:

1. All four global steps are finished.
2. Tactical and atomic planning for those steps are synchronized with the latest parent documents.
3. Coding and verification have completed for all required branches.
4. All verification requirements in this document have passed.

## Glossary

- `Adapter-centric`: architecture in which authentication, transport, TLS/mTLS, JSON-RPC execution, queue access, and WebSocket communication rely exclusively on `mcp-proxy-adapter` client facilities.
- `Immediate JSON-RPC result`: a server response where the final business payload is returned directly in the JSON-RPC success result without a follow-up job lifecycle.
- `Queued result`: a server response where the initial JSON-RPC success result contains `job_id` and status metadata, requiring follow-up status or wait handling.
- `Identifier-safe`: a design that does not conflate JSON-RPC request `id`, server `job_id`, and adapter-managed WebSocket delivery/correlation identifiers.
- `Tactical task`: a branch-local planning document created by `orchestrator_tactical` under one global step.
- `Atomic step`: the smallest executable coding/planning unit created by `planner_auto` under one tactical task.
- `Subordinate agent state`: the current reported state of `planner_auto`, `coder_auto`, and `tester_auto` for a branch.
- `Blocker`: a condition that prevents safe forward execution without correction, clarification, or resynchronization.
- `Resynchronization`: the required refresh of tactical and atomic planning after any parent-level document change.
