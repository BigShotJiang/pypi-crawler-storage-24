Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Global Step: Queue And WebSocket Identifier Separation

## Goal

Make identifier handling explicit, non-ambiguous, and contract-safe across JSON-RPC requests, queued embed jobs, and adapter-managed WebSocket completion flows.

## Input Artifacts

- `docs/tech_spec/tech_spec.md`
- `docs/tech_spec/implementation_plan.md`
- `embed_client/adapter_transport.py`
- `embed_client/async_client_queue_mixin.py`
- `embed_client/async_client_api_mixin.py`
- `embed_client/testing_client.py`
- `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- `/home/vasilyvz/projects/embed/embed/main.py`
- `/home/vasilyvz/projects/embed/embed/main_startup.py`
- `/home/vasilyvz/projects/embed/embed/commands/embed_router.py`
- `/home/vasilyvz/projects/embed/embed/commands/embed_job_status_command.py`

## Output Artifacts

- Modify `embed_client/adapter_transport.py`
- Modify `embed_client/async_client_queue_mixin.py`
- Modify `embed_client/async_client_api_mixin.py`
- Modify `embed_client/testing_client.py`
- Create or modify `embed_client/identifier_types.py`
- Modify or create `tests/test_identifier_extraction.py`
- Modify or create `tests/test_identifier_separation.py`
- Modify or create `tests/test_queue_identifier_behavior.py`
- Modify or create `tests/test_websocket_identifier_behavior.py`
- Modify runtime/performance scripts under `scripts/` only if they currently encode ambiguous identifier assumptions

## Module Inventory For This Step

- `embed_client.adapter_transport.AdapterTransport`
  - base: adapter-backed transport facade
  - purpose: expose queue and WebSocket waiting through adapter semantics
- `embed_client.async_client_queue_mixin.AsyncClientQueueMixin`
  - base: mixin
  - purpose: expose queue/job wait/status APIs without identifier conflation
- `embed_client.async_client_api_mixin.AsyncClientAPIMixin`
  - base: mixin
  - purpose: extract/route public `job_id`-centric behavior safely
- `embed_client.testing_client.EmbeddingServiceClient`
  - base: sync/testing facade
  - purpose: expose sync/testing queue and WebSocket behaviors safely

## Public Interface

- `AsyncClientQueueMixin.submit_job(command: str, params: dict | None = None, timeout: float | None = None) -> str | dict`
- `AsyncClientQueueMixin.job_status(job_id: str) -> dict`
- `AsyncClientQueueMixin.wait_for_job(job_id: str, timeout: float | None = None) -> dict`
- `AsyncClientQueueMixin.wait_for_job_via_websocket(job_id: str, timeout: float | None = None) -> dict`
- `AsyncClientQueueMixin.get_job_status_or_result(job_id: str, timeout: float | None = None) -> dict`
- `AdapterTransport.queue_get_job_status(job_id: str) -> dict`
- `AdapterTransport.wait_for_job_via_websocket(job_id: str, timeout: float | None = None) -> dict`
- `AdapterTransport.execute_async(command: str, params: dict | None = None, on_result: object | None = None, timeout: float | None = None) -> dict`
- `EmbeddingServiceClient.job_status(job_id: str) -> dict`
- `EmbeddingServiceClient.wait_for_job(job_id: str, timeout: float | None = None) -> dict`
- `EmbeddingServiceClient.wait_for_job_via_websocket(job_id: str, timeout: float | None = None) -> dict`

Behavioral contract for this step:

- JSON-RPC request `id` must remain transport-internal
- `job_id` must remain the public queued-operation identifier
- adapter-managed WebSocket delivery/correlation identifiers must not be collapsed into `job_id` unless adapter behavior explicitly guarantees that mapping
- public wait APIs must document and preserve whether they are job-based or adapter-async-delivery-based
- compatibility with Step 2 means preserving result-mode handling without redefining business payload semantics

## Inter-Step Contracts

- Consumes adapter-centric runtime from Step 1.
- Must stay compatible with command/result behavior from Step 2.

## Shared Data Contracts Used In This Step

- `JobId`
  - opaque string returned by server queued flows
- `JsonRpcRequestId`
  - transport-layer JSON-RPC `id`, never a public job identifier
- `WebSocketCorrelationId`
  - adapter-managed delivery/correlation identifier for async WebSocket flows
- `WebSocketChannelHandle`
  - adapter-returned channel/session object, not a project-defined protocol identifier

## Error Handling

- `EmbeddingServiceTimeoutError`
  - raised when queue polling or adapter-managed WebSocket waiting exceeds timeout
- `EmbeddingServiceAPIError`
  - raised when job lookup or completion payload indicates business/API failure
- `EmbeddingServiceConnectionError`
  - raised when queue or WebSocket communication cannot be established
- `EmbeddingServiceJSONError`
  - raised when identifier-bearing payloads cannot be parsed structurally

Caller rule:

- the client must not silently fallback across mismatched identifier types
- the client must not treat missing correlation semantics as success

## Config Keys Used

- `client.timeout: float | None`
- runtime wait inputs:
  - `timeout`
  - `receive_timeout`
  - `heartbeat`

## Forbidden Approaches

- Treating JSON-RPC request `id` as a domain identifier
- Assuming any WebSocket callback payload uses the same identifier semantics as queue polling without proof
- Inventing a client-owned WebSocket protocol outside adapter semantics

## Glossary

- `JSON-RPC request id`: the protocol-level `id` field carried by JSON-RPC transport, owned by the transport/runtime layer
- `job_id`: the public queued-operation identifier returned by server flows and used for queue lifecycle APIs
- `WebSocket correlation identifier`: adapter-managed async delivery/correlation identity that may differ from `job_id`
- `compatible with Step 2`: preserves the same immediate-vs-queued result interpretation while keeping identifier boundaries explicit

## Import Map

### `embed_client/adapter_transport.py`
- import adapter runtime from `mcp_proxy_adapter.client.jsonrpc_client`
- import project exceptions from `embed_client.exceptions`
- import identifier aliases from `embed_client.identifier_types` if created

### `embed_client/async_client_queue_mixin.py`
- import transport/client accessors from the owning async client
- import project exceptions from `embed_client.exceptions`
- import identifier aliases from `embed_client.identifier_types` if created

### `embed_client/testing_client.py`
- import transport from `embed_client.adapter_transport`
- import project exceptions from `embed_client.exceptions`
- import identifier aliases from `embed_client.identifier_types` if created

## Algorithm Descriptions

### `job_id` Extraction

1. Inspect the adapter/server response shape.
2. Extract `job_id` only from fields that explicitly represent queued-job identity.
3. If no unambiguous `job_id` exists, raise an explicit parsing/contract error instead of guessing.

### Queue Polling vs WebSocket Waiting

1. Use `job_id` for queue/status lifecycle methods only.
2. Use adapter-managed WebSocket waiting/correlation only in adapter async/WebSocket flows.
3. Preserve both identities separately unless adapter behavior explicitly guarantees equivalence.

## Concrete Examples

### Queued Response To `job_id`

- Input category:
  - JSON-RPC/adapter queued response containing `job_id`
- Output category:
  - public `job_id` used for status and waiting APIs

### WebSocket Completion With Separate Correlation

- Input category:
  - WebSocket completion payload containing public `job_id` plus adapter-managed correlation metadata
- Output category:
  - normalized business result while preserving identifier separation semantics

## Test Plan

- `tests/test_identifier_extraction.py`
  - validate unambiguous `job_id` extraction rules
- `tests/test_identifier_separation.py`
  - validate separation of JSON-RPC request `id`, `job_id`, and WebSocket correlation
- `tests/test_queue_identifier_behavior.py`
  - validate queue lifecycle methods use only `job_id`
- `tests/test_websocket_identifier_behavior.py`
  - validate WebSocket waiting/correlation behavior remains identifier-safe

## Acceptance Criteria

1. JSON-RPC request id, `job_id`, and adapter-managed WebSocket correlation are explicitly separated in client logic.
2. Queue polling and WebSocket waiting paths are contract-consistent.
3. Identifier-focused tests cover immediate mode, queued mode, and WS-assisted completion mode.
