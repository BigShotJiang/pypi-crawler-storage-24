Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Global Step: Adapter-Centric Client Foundation

## Goal

Make the client runtime architecture depend only on `mcp-proxy-adapter` client facilities for authentication, transport, protocol selection, and TLS/mTLS behavior.

## Input Artifacts

- `docs/tech_spec/tech_spec.md`
- `docs/tech_spec/implementation_plan.md`
- `embed_client/adapter_transport.py`
- `embed_client/adapter_config_factory.py`
- `embed_client/adapter_config_normalizer.py`
- `embed_client/adapter_generator_bridge.py`
- `embed_client/config_validator.py`
- `embed_client/auth.py`
- `embed_client/ssl_manager.py`
- `embed_client/client_factory.py`

## Output Artifacts

- Modify `embed_client/adapter_transport.py`
- Modify `embed_client/adapter_config_factory.py`
- Modify `embed_client/adapter_config_normalizer.py`
- Modify `embed_client/adapter_generator_bridge.py`
- Modify `embed_client/config_validator.py`
- Modify `embed_client/auth.py`
- Modify `embed_client/ssl_manager.py`
- Modify `embed_client/client_factory.py`
- Modify `embed_client/async_client.py` only where construction/runtime bootstrapping depends on this step
- Modify `tests/test_adapter_transport.py`
- Modify `tests/test_client_factory.py`
- Modify or create `tests/test_adapter_config_factory.py`
- Modify or create `tests/test_auth_manager.py`
- Modify or create `tests/test_ssl_manager.py`

## Module Inventory For This Step

- `embed_client.adapter_transport.AdapterTransport`
  - base: concrete project facade
  - purpose: delegate runtime transport/auth/TLS work to `mcp-proxy-adapter`
- `embed_client.adapter_config_factory.AdapterConfigFactory`
  - base: concrete project mapper
  - purpose: map project config to adapter constructor params
- `embed_client.adapter_config_normalizer`
  - base: module helpers
  - purpose: normalize project config into adapter-compatible validation/generation shape
- `embed_client.adapter_generator_bridge`
  - base: module helpers
  - purpose: bridge project config generation to adapter config generation
- `embed_client.config_validator.ConfigValidator`
  - base: project validator facade
  - purpose: validate project config through adapter-compatible rules
- `embed_client.client_factory.ClientFactory`
  - base: concrete project factory
  - purpose: create only adapter-backed client instances

## Public Interface

The step must leave these public interfaces explicit and adapter-backed:

- `AdapterTransport.__init__(config: dict | object | None = None, **kwargs: object) -> None`
- `AdapterTransport.jsonrpc_call(method: str, params: dict | None = None) -> dict`
- `AdapterTransport.execute_command_unified(command: str, params: dict | None = None, auto_poll: bool = False, timeout: float | None = None, **kwargs: object) -> dict`
- `AdapterTransport.execute_async(command: str, params: dict | None = None, on_result: object | None = None, timeout: float | None = None) -> dict`
- `AdapterTransport.queue_get_job_status(job_id: str) -> dict`
- `AdapterTransport.wait_for_job_via_websocket(job_id: str, timeout: float | None = None) -> dict`
- `AdapterTransport.open_bidirectional_ws_channel(receive_timeout: float | None = None, heartbeat: float | None = None) -> object`
- `AdapterConfigFactory.from_config_dict(config: dict) -> AdapterClientParams`
- `AdapterConfigFactory.from_client_config(config: object) -> AdapterClientParams`
- `AdapterConfigFactory.from_legacy_params(**kwargs: object) -> AdapterClientParams`
- `ClientFactory.create_client(config: dict | object) -> object`
- `ClientFactory.from_config_file(path: str) -> object`

Behavioral contract for this step:

- client construction must reduce to adapter-compatible settings only
- auth and TLS inputs must map only to adapter constructor/config inputs
- retained project helpers may validate and normalize, but must not execute auth or transport

## Inter-Step Contracts

- Produces `AdapterClientParams` as defined in `docs/tech_spec/tech_spec.md`.
- Produces the canonical client construction rules consumed by Steps 2 and 3.
- Produces the exact boundary that later steps must respect:
  - auth runtime belongs to adapter
  - TLS/mTLS runtime belongs to adapter
  - JSON-RPC transport runtime belongs to adapter
  - WebSocket runtime belongs to adapter

## Error Handling

- `EmbeddingServiceConfigError`
  - raised when config mapping/validation fails for adapter-backed execution
- `EmbeddingServiceConnectionError`
  - raised when adapter-backed client creation or transport bootstrap fails
- `AuthenticationError`
  - may remain only as a project wrapper if it no longer performs real auth execution

Caller rule:

- no fallback custom auth/TLS runtime is allowed after these exceptions

## Config Keys Used

- `server.host: str`
- `server.port: int`
- `server.protocol: str`
- `server.ssl.cert: str | None`
- `server.ssl.key: str | None`
- `server.ssl.ca: str | None`
- `auth.use_token: bool | None`
- `auth.tokens: dict | None`
- `auth.roles: dict | None`
- `client.timeout: float | None`

## Forbidden Approaches

- Any direct production HTTP/WebSocket implementation outside adapter client usage
- Any client-side auth execution manager that simulates or duplicates authentication
- Any separate TLS/session builder outside adapter behavior

## Glossary

- `adapter-compatible settings`: a config shape that can be deterministically mapped to adapter constructor params without custom runtime transport logic
- `non-executing compatibility wrapper`: a retained project helper that may validate, normalize, or expose API compatibility, but does not perform real auth/transport/TLS work
- `adapter-backed client construction`: any client creation path that ends in adapter-owned runtime behavior

## Import Map

Expected import roots for this step:

### `embed_client/adapter_transport.py`
- `from mcp_proxy_adapter.client.jsonrpc_client import JsonRpcClient`
- `from mcp_proxy_adapter.client.jsonrpc_client import open_bidirectional_ws_channel`
- `from embed_client.exceptions import EmbeddingServiceConnectionError`

### `embed_client/adapter_config_factory.py`
- `from embed_client.adapter_config_normalizer import ...`
- `from embed_client.exceptions import EmbeddingServiceConfigError`

### `embed_client/config_validator.py`
- `from mcp_proxy_adapter.core.validation.config_validator import ConfigValidator`
- `from embed_client.exceptions import EmbeddingServiceConfigError`

### `embed_client/client_factory.py`
- `from embed_client.adapter_config_factory import AdapterConfigFactory`
- `from embed_client.adapter_transport import AdapterTransport`

## Algorithm Descriptions

### `AdapterConfigFactory.from_config_dict()`

1. Read project config keys defined in `docs/tech_spec/tech_spec.md`.
2. Normalize protocol/security/auth selections into adapter-compatible values.
3. Reject invalid combinations with `EmbeddingServiceConfigError`.
4. Produce `AdapterClientParams`.

### `AdapterConfigFactory.from_client_config()`

1. Read the client config object.
2. Convert it into the same normalized vocabulary as `from_config_dict()`.
3. Delegate to the same mapping rules.
4. Produce `AdapterClientParams`.

### `ConfigValidator`

1. Validate presence and type of required config keys.
2. Validate protocol/auth/TLS combinations.
3. Delegate structural validation to adapter-compatible validation where available.
4. Raise `EmbeddingServiceConfigError` on invalid config.

## Concrete Examples

### Config Dict To Adapter Params

- Input:
  - `{ "server": { "host": "localhost", "port": 8001, "protocol": "https", "ssl": { "ca": "/tmp/ca.crt" } }, "auth": { "use_token": true, "tokens": { "default": "abc" } }, "client": { "timeout": 30.0 } }`
- Output category:
  - `AdapterClientParams(protocol="https", host="localhost", port=8001, token="abc", ca="/tmp/ca.crt", timeout=30.0, ...)`

## Test Plan

- `tests/test_adapter_config_factory.py`
  - validate config-to-adapter mapping for http/https/mtls variants
- `tests/test_adapter_transport.py`
  - verify adapter-only transport/bootstrap behavior
- `tests/test_client_factory.py`
  - verify all factory paths create adapter-backed clients only
- `tests/test_auth_manager.py`
  - verify retained auth wrapper performs validation only
- `tests/test_ssl_manager.py`
  - verify retained SSL wrapper performs validation only

## Acceptance Criteria

1. Public client construction paths use adapter-backed auth and transport only.
2. Redundant auth/TLS runtime logic is removed or reduced to non-executing compatibility wrappers.
3. Configuration generation and validation rely on adapter-compatible behavior.
