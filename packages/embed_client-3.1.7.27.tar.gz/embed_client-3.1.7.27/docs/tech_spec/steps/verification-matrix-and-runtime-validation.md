Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Global Step: Verification Matrix And Runtime Validation

## Goal

Validate the synchronized client across all required security modes, result-delivery modes, and real runtime vectorization scenarios.

## Input Artifacts

- `docs/tech_spec/tech_spec.md`
- `docs/tech_spec/implementation_plan.md`
- `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- all modified client modules from prior global steps
- existing test suites and runtime scripts under `tests/` and `scripts/`
- Real runtime endpoint `localhost:8001`

## Output Artifacts

- Modify or create `tests/test_async_client.py`
- Modify or create `tests/test_adapter_transport.py`
- Modify or create `tests/test_security_matrix.py`
- Modify or create `tests/test_embed_immediate_mode.py`
- Modify or create `tests/test_embed_queued_mode.py`
- Modify or create `tests/test_websocket_completion.py`
- Modify or create `tests/test_identifier_separation.py`
- Modify or create runtime validation scripts:
  - `scripts/run_real_server_mtls_test.py`
  - `scripts/run_real_server_performance.py`
  - `scripts/run_bidirectional_ws_performance.py`
  - `scripts/run_testing_client_performance.py`
  - `scripts/run_cuda_stress.py` if it is part of the maintained real-server pipeline
  - `scripts/compare_direct_vs_client.py` if it is part of the maintained real-server pipeline
  - `scripts/run_timing_statistics.py` if it is part of the maintained real-server pipeline
  - `scripts/run_batch_performance.py` if it is part of the maintained real-server pipeline
- Produce validation result artifacts/logs under project-controlled output paths if the testing flow requires them

## Module Inventory For This Step

- test modules under `tests/` that validate:
  - adapter-centric construction
  - embed immediate mode
  - embed queued mode
  - queue/job status
  - WebSocket completion
  - identifier separation
  - security matrix
- runtime validation scripts under `scripts/` for real endpoint checks on `localhost:8001`
- all maintained real-server scripts that:
  - use `EmbeddingServiceAsyncClient` or `EmbeddingServiceClient`
  - use `ClientConfig` or generated config files
  - target `localhost:8001`
  - use `mtls_certificates`
  - exercise queue, polling, or WebSocket flows affected by Steps 1-3

## Public Interface Under Validation

- `EmbeddingServiceAsyncClient.embed(...) -> dict`
- `EmbeddingServiceAsyncClient.job_status(job_id: str) -> dict`
- `EmbeddingServiceAsyncClient.wait_for_job(job_id: str, timeout: float | None = None) -> dict`
- `EmbeddingServiceAsyncClient.wait_for_job_via_websocket(job_id: str, timeout: float | None = None) -> dict`
- `EmbeddingServiceAsyncClient.models() -> dict`
- `EmbeddingServiceAsyncClient.timing_stats(file_path: str | None = None) -> dict`
- corresponding sync/testing facade methods in `EmbeddingServiceClient`

Behavioral validation requirement:

- public client behavior must be validated for both:
  - immediate JSON-RPC result mode
  - queued plus WebSocket/JSON-RPC completion mode

## Inter-Step Contracts

- Validates the outcomes of Steps 1-3 as a complete synchronized client.

The validator for this step must assume these upstream contracts are already fixed:

- Step 1: adapter-only runtime construction
- Step 2: command/result alignment
- Step 3: identifier-safe queue/WebSocket handling

## Error Handling

- Test failures must preserve enough detail to distinguish:
  - security configuration failure
  - transport failure
  - JSON-RPC contract failure
  - queue/status failure
  - WebSocket identifier or delivery failure

Expected project exception categories under test:

- `EmbeddingServiceConfigError`
- `EmbeddingServiceConnectionError`
- `EmbeddingServiceAPIError`
- `EmbeddingServiceHTTPError`
- `EmbeddingServiceTimeoutError`
- `EmbeddingServiceJSONError`

## Config Keys Used

- `server.host`
- `server.port`
- `server.protocol`
- `server.ssl.cert`
- `server.ssl.key`
- `server.ssl.ca`
- `auth.use_token`
- `auth.tokens`
- `auth.roles`
- `client.timeout`
- runtime endpoint and certificate settings for `localhost:8001`

## Validation Matrix

The step must verify all of the following exact runtime categories:

- http
- http + token
- http + token + roles
- https
- https + token
- https + token + roles
- mtls
- mtls + roles

It must also verify both result-delivery categories:

- immediate JSON-RPC result
- queued result with JSON-RPC status and/or adapter-managed WebSocket completion

## Runtime Validation Structure

The runtime validation path must explicitly cover:

1. adapter-backed client construction
2. command execution through JSON-RPC
3. immediate result normalization
4. queued result submission and `job_id` handling
5. status polling handling
6. WebSocket completion handling
7. identifier-separation assertions
8. real vectorization on `localhost:8001`
9. successful execution of all maintained real-server pipeline scripts

## Forbidden Approaches

- Partial validation of only one protocol/security mode
- Skipping the real runtime vectorization validation on `localhost:8001`
- Accepting passing unit tests without full matrix coverage

## Glossary

- `synchronized client`: a client implementation aligned with both the server contract and the adapter-only runtime architecture
- `WS-assisted completion mode`: a queued operation whose completion is observed through adapter-managed WebSocket waiting or callback flow
- `full matrix coverage`: validation of all required security modes plus both delivery modes and identifier-separation behavior

## Import Map

### Test Modules Under `tests/`
- import public clients from `embed_client`
- import project exceptions from `embed_client.exceptions`
- import fixtures/helpers from local test support modules

### Runtime Validation Scripts Under `scripts/`
- import public clients from `embed_client`
- import config helpers from `embed_client` or local runtime helpers

## Algorithm Descriptions

### Security Matrix Validation

1. Build one runtime configuration per required security mode.
2. Execute the required public client flows for that mode.
3. Record pass/fail together with failure category.
4. Reject completion if any required mode fails.

### Runtime Validation On `localhost:8001`

1. Build the real runtime configuration for the target endpoint.
2. Execute real vectorization through adapter-backed client flows.
3. Verify successful embedding/business result.
4. Record failure category and stop completion if validation fails.

## Concrete Examples

### Example: `http + token`

- Input category:
  - config with `server.protocol="http"` and token auth enabled
- Expected result category:
  - successful command execution through adapter-backed JSON-RPC flow

### Example: `mtls + roles`

- Input category:
  - config with `server.protocol="mtls"` and role-constrained auth behavior
- Expected result category:
  - successful authenticated execution and correct authorization behavior

## Test Plan

- `tests/test_security_matrix.py`
  - validate all 8 required protocol/security combinations
- `tests/test_embed_immediate_mode.py`
  - validate immediate JSON-RPC result mode
- `tests/test_embed_queued_mode.py`
  - validate queued result plus status handling
- `tests/test_websocket_completion.py`
  - validate adapter-managed WebSocket completion flow
- `tests/test_identifier_separation.py`
  - validate no identifier mixing remains
- `scripts/run_real_server_mtls_test.py`
  - validate real runtime vectorization on `localhost:8001`
- `scripts/run_real_server_performance.py`
  - validate real-server polling/performance path against the synchronized client contract
- `scripts/run_bidirectional_ws_performance.py`
  - validate real-server WebSocket completion/performance path against the synchronized client contract
- maintained real-server scripts under `scripts/`
  - must be updated and executed if they target `localhost:8001` and use `mtls_certificates`

## Acceptance Criteria

1. All required security modes pass validation:
   - http
   - http + token
   - http + token + roles
   - https
   - https + token
   - https + token + roles
   - mtls
   - mtls + roles
2. Real vectorization on `localhost:8001` passes.
3. Immediate JSON-RPC and deferred WS/JSON-RPC completion flows both pass.
4. No identifier-mixing failures remain in queue or WebSocket execution paths.
