Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Global Step: Embed Command And Result Contract Alignment

## Goal

Align the public client API with the real server-side command contract and result modes for embedding operations and related introspection commands.

## Input Artifacts

- `docs/tech_spec/tech_spec.md`
- `docs/tech_spec/implementation_plan.md`
- `embed_client/async_client.py`
- `embed_client/async_client_api_mixin.py`
- `embed_client/async_client_response_mixin.py`
- `embed_client/testing_client.py`
- `embed_client/exceptions.py`
- `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- `/home/vasilyvz/projects/embed/embed/main.py`
- `/home/vasilyvz/projects/embed/embed/main_startup.py`
- `/home/vasilyvz/projects/embed/embed/commands/embed_router.py`
- `/home/vasilyvz/projects/embed/embed/commands/embed_command_schema.py`
- `/home/vasilyvz/projects/embed/embed/commands/embed_job_status_command.py`
- `/home/vasilyvz/projects/embed/embed/commands/models_command.py`

## Output Artifacts

- Modify `embed_client/async_client.py`
- Modify `embed_client/async_client_api_mixin.py`
- Modify `embed_client/async_client_response_mixin.py`
- Modify `embed_client/testing_client.py`
- Modify `embed_client/exceptions.py` only if exception mapping must be tightened
- Modify `tests/test_async_client.py`
- Modify or create `tests/test_embed_immediate_mode.py`
- Modify or create `tests/test_embed_queued_mode.py`
- Modify or create `tests/test_embed_job_status.py`

## Module Inventory For This Step

- `embed_client.async_client.EmbeddingServiceAsyncClient`
  - base: project async facade composed from mixins
  - purpose: expose adapter-backed async business API
- `embed_client.async_client_api_mixin.AsyncClientAPIMixin`
  - base: mixin
  - purpose: build embed-related requests and normalize top-level command behavior
- `embed_client.async_client_response_mixin.AsyncClientResponseMixin`
  - base: mixin
  - purpose: normalize embedding/business payloads only
- `embed_client.testing_client.EmbeddingServiceClient`
  - base: project sync/testing facade
  - purpose: expose a sync/testing-friendly API over the same contract

## Public Interface

- `EmbeddingServiceAsyncClient.embed(texts: list[str], model: str | None = None, dimension: int | None = None, error_policy: str | None = None, device: str | None = None, wait: bool = False, timeout: float | None = None, use_push: bool = True, **extra_params: object) -> dict`
- `EmbeddingServiceAsyncClient.models() -> dict`
- `EmbeddingServiceAsyncClient.timing_stats(file_path: str | None = None) -> dict`
- `EmbeddingServiceAsyncClient.job_status(job_id: str) -> dict`
- `EmbeddingServiceClient.embed(texts: list[str], model: str | None = None, dimension: int | None = None, error_policy: str | None = None, device: str | None = None, wait: bool = False, timeout: float | None = None) -> dict`
- `EmbeddingServiceClient.models() -> dict`
- `EmbeddingServiceClient.timing_stats(file_path: str | None = None) -> dict`
- `EmbeddingServiceClient.job_status(job_id: str) -> dict`

Behavioral contract for this step:

- public embed methods must send canonical `embed` requests with `texts`
- public result parsing must support both:
  - immediate JSON-RPC success payloads
  - queued submission followed by resolved result payloads
- public command methods for `models` and `timing_stats` must remain aligned with server command semantics
- this step must be identifier-safe and must not define result handling that erases distinctions required by Step 3

## Inter-Step Contracts

- Consumes `AdapterClientParams` and adapter-centric construction rules from Step 1.
- Produces canonical business-facing request/result handling for:
  - `EmbedRequest`
  - `ImmediateEmbedResult`
  - `QueuedEmbedSubmission`
  - `JobStatusPayload`
- Must remain identifier-safe with Step 3.

## Shared Data Contracts Used In This Step

- `EmbedRequest`
  - fields: `texts`, `model`, `dimension`, `error_policy`, `device`
- `ImmediateEmbedResult`
  - fields: business payload such as `embeddings`, `results`, `model`, `dimension`, `device`
- `QueuedEmbedSubmission`
  - fields: `job_id`, `status`, `message`

## Error Handling

- `EmbeddingServiceAPIError`
  - raised when the server returns a business/API error payload
- `EmbeddingServiceHTTPError`
  - raised when transport-level HTTP failure is surfaced through adapter/project wrapper
- `EmbeddingServiceJSONError`
  - raised when response parsing/normalization fails structurally
- `EmbeddingServiceConnectionError`
  - raised when adapter-backed execution cannot reach the server

Caller rule:

- top-level command errors and per-item embedding errors must both remain representable
- no result-mode normalization may hide a top-level failure as if it were a successful business result

## Config Keys Used

- `client.timeout: float | None`
- method-level runtime inputs:
  - `texts`
  - `model`
  - `dimension`
  - `error_policy`
  - `device`
  - `wait`
  - `use_push`
  - `timeout`

## Forbidden Approaches

- Reimplementing JSON-RPC transport or queue submission logic
- Depending on non-canonical `text` input when `texts` is the server contract
- Maintaining legacy response transformations that hide real server modes

## Glossary

- `immediate JSON-RPC success payload`: a success result containing final embedding/business data and no public queued lifecycle
- `queued submission`: a success result containing public `job_id` and requiring status/wait handling
- `identifier-safe`: result handling that does not conflate JSON-RPC request `id`, public `job_id`, and adapter-managed WebSocket correlation identifiers

## Import Map

### `embed_client/async_client.py`
- import mixins from `embed_client.async_client_api_mixin`, `embed_client.async_client_response_mixin`, `embed_client.async_client_queue_mixin`
- import transport from `embed_client.adapter_transport`
- import project exceptions from `embed_client.exceptions`

### `embed_client/async_client_api_mixin.py`
- import shared transport/client helpers from `embed_client.adapter_transport` or owning client facade
- import exception types from `embed_client.exceptions`

### `embed_client/async_client_response_mixin.py`
- import exception types from `embed_client.exceptions`

### `embed_client/testing_client.py`
- import transport from `embed_client.adapter_transport`
- import config mapping from `embed_client.adapter_config_factory`
- import project exceptions from `embed_client.exceptions`

## Algorithm Descriptions

### Canonical Embed Request Construction

1. Accept public method inputs.
2. Validate and normalize `texts`.
3. Build canonical `EmbedRequest` with `texts`, `model`, `dimension`, `error_policy`, and `device`.
4. Submit through adapter-backed execution only.

### Immediate vs Queued Result Detection

1. Inspect adapter/server response shape.
2. If public `job_id` is present, treat as queued submission.
3. Otherwise treat as immediate result.
4. Normalize into stable project response shape without redefining transport semantics.

## Concrete Examples

### Public Embed Call To Canonical Payload

- Input:
  - `embed(texts=["hello"], model="m1", dimension=768, error_policy="fail_fast", device="cpu")`
- Payload:
  - `{ "texts": ["hello"], "model": "m1", "dimension": 768, "error_policy": "fail_fast", "device": "cpu" }`

### Queued Submission Normalization

- Input category:
  - adapter/server response exposing `job_id`
- Output category:
  - project result exposing `job_id`, status metadata, and wait/status compatibility

## Test Plan

- `tests/test_async_client.py`
  - validate async embed immediate and queued behavior
- `tests/test_embed_immediate_mode.py`
  - validate immediate result normalization
- `tests/test_embed_queued_mode.py`
  - validate queued submission and follow-up handling
- `tests/test_embed_job_status.py`
  - validate `embed_job_status` alignment and normalization

## Acceptance Criteria

1. Public embed APIs align with `embed` and `embed_job_status` server semantics.
2. Immediate and queued result modes are both correctly supported.
3. Public response parsing remains stable without masking adapter/server identifier semantics.
