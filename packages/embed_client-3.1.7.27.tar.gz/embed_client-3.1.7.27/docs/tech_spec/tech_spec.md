Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Embed Client Synchronization Tech Spec

## Goal

Bring `/home/vasilyvz/projects/embed-client` into full architectural alignment with the vectorization server in `/home/vasilyvz/projects/embed`.

The synchronized client must be a thin adapter-based client. All authentication, protocol selection, TLS/mTLS behavior, JSON-RPC transport, queue handling, and WebSocket interaction must rely on the client facilities of `mcp-proxy-adapter`. The client project may keep only product-specific configuration mapping, response normalization, high-level API ergonomics, and project-specific exceptions.

## Source Of Truth

The external server contract is defined by these server artifacts:

- `/home/vasilyvz/projects/embed/embed/main.py`
- `/home/vasilyvz/projects/embed/embed/main_startup.py`
- `/home/vasilyvz/projects/embed/embed/commands/embed_router.py`
- `/home/vasilyvz/projects/embed/embed/commands/embed_command_schema.py`
- `/home/vasilyvz/projects/embed/embed/commands/embed_job_status_command.py`
- `/home/vasilyvz/projects/embed/embed/commands/models_command.py`
- `/home/vasilyvz/projects/embed/embed/middleware/permissions_middleware.py`

The allowed client transport/auth implementation is defined by these adapter-facing client artifacts:

- `embed_client/adapter_transport.py`
- `embed_client/adapter_config_factory.py`
- `embed_client/adapter_config_normalizer.py`
- `embed_client/adapter_generator_bridge.py`
- `embed_client/config_validator.py`

The current public client surface that must be reconciled with the server contract is defined by:

- `embed_client/async_client.py`
- `embed_client/async_client_api_mixin.py`
- `embed_client/async_client_queue_mixin.py`
- `embed_client/async_client_response_mixin.py`
- `embed_client/testing_client.py`
- `embed_client/client_factory.py`

## Global File Inventory

### Files To Modify

- `embed_client/adapter_transport.py`
- `embed_client/adapter_config_factory.py`
- `embed_client/adapter_config_normalizer.py`
- `embed_client/adapter_generator_bridge.py`
- `embed_client/config_validator.py`
- `embed_client/auth.py`
- `embed_client/ssl_manager.py`
- `embed_client/async_client.py`
- `embed_client/async_client_api_mixin.py`
- `embed_client/async_client_queue_mixin.py`
- `embed_client/async_client_response_mixin.py`
- `embed_client/testing_client.py`
- `embed_client/client_factory.py`
- `embed_client/exceptions.py`
- `tests/test_async_client.py`
- `tests/test_adapter_transport.py`
- `tests/test_client_factory.py`
- `tests/test_adapter_integration.py`

### Files To Create Or Split If Needed

- `embed_client/identifier_types.py`
- additional focused test files under `tests/` for:
  - identifier separation
  - immediate-mode behavior
  - queued-mode behavior
  - WebSocket-completion behavior
  - security-matrix behavior

### Files Not Allowed To Become Independent Runtime Transports

- any new production module that performs direct HTTP, TLS, socket, or WebSocket runtime logic outside `mcp-proxy-adapter`

## Mandatory Architecture Decisions

1. The client must use only `mcp-proxy-adapter` client facilities for authentication.
2. The client must use only `mcp-proxy-adapter` client facilities for network transport.
3. Protocol and security mode selection must be configuration-driven and reduced to adapter client constructor/config choices.
4. The server request path is JSON-RPC over `/api/jsonrpc`.
5. The server result path is either:
   - immediate JSON-RPC result, or
   - deferred completion via queue/job semantics, observable through JSON-RPC status and/or WebSocket delivery.
6. The client must not implement parallel custom auth stacks, custom HTTP stacks, or custom WebSocket protocol stacks outside the adapter.
7. The identifier model must remain explicitly separated:
   - JSON-RPC request `id`
   - server-returned `job_id`
   - server-internal logical/coalesced job mapping if present
   - WebSocket-local delivery/correlation identifier(s) handled by the adapter
   - WebSocket channel/session object identity, if exposed by the adapter
8. The phrase `synchronized with the server` means:
   - request fields match the server contract
   - result handling matches the server contract
   - adapter response shapes are normalized consistently
   - identifier semantics are preserved without conflation
   - all required protocol/security modes are validated
9. The phrase `identifier-safe` means:
   - JSON-RPC request `id` is never used as a domain/job identifier
   - `job_id` remains the public queued-operation identifier
   - adapter-managed WebSocket delivery/correlation identifiers remain distinct unless explicit adapter guarantees prove equivalence
10. The phrase `compatible with Step X` means:
   - no contradiction with the parent document for that step
   - no contradiction with shared type definitions in this document
   - no contradiction with the common adapter response format defined below

## Public Contract To Support

### Public HTTP Endpoints

- `GET /health`
- `POST /api/jsonrpc`
- `GET /docs`
- `GET /openapi.json`
- `WS /ws` when queue/job push is enabled by the server

### JSON-RPC Commands

The client must support these server-visible commands:

- `embed`
- `embed_queue`
- `embed_job_status`
- `models`
- `timing_stats`

The client must also remain compatible with adapter-provided queue commands used indirectly or directly:

- `queue_get_job_status`
- `queue_list_jobs`
- `queue_stop_job`
- `queue_delete_job`
- `queue_get_job_logs`
- `help`
- `commands` / command-list introspection

### Embed Request Contract

The canonical outgoing request for embedding is built around:

- `texts: list[str]`
- `model: str | None`
- `dimension: int | None`
- `error_policy: str | None`
- `device: str | None`

The client must prefer canonical `texts` and must not depend on server-side convenience normalization from `text` to `texts`.

### Supported Result Modes

The client must accept both server modes:

1. Immediate mode:
   - JSON-RPC result contains final embedding payload.
2. Queued mode:
   - JSON-RPC result contains `job_id` and status metadata.
   - Completion is then obtained through `embed_job_status` and/or adapter-managed WebSocket waiting.

### Adapter Response Format

The client must treat the adapter as the only legal transport/runtime surface.

The global plan must assume these response categories exist and must be normalized explicitly:

1. Raw JSON-RPC response:
   - shape: `{ "jsonrpc": "2.0", "result": ..., "id": ... }`
   - or `{ "jsonrpc": "2.0", "error": ..., "id": ... }`
2. Adapter immediate execution response:
   - shape category: immediate result payload with no public `job_id`
3. Adapter queued execution response:
   - shape category: success payload that contains or exposes `job_id`
4. Adapter WebSocket completion response:
   - shape category: completion or failure payload received through adapter-managed waiting/callback flow

The exact implementation may expose wrapper fields such as `mode`, nested `result`, nested `data`, or callback payloads. The synchronized client must normalize these variants without creating a second transport contract of its own.

Concrete response examples required by this specification:

- immediate example:
  - `{ "mode": "immediate", "result": { "success": true, "data": { "results": [...], "embeddings": [...], "model": "m1", "dimension": 768, "device": "cpu" } } }`
- queued example:
  - `{ "mode": "queued", "job_id": "job-123", "result": { "success": true, "data": { "job_id": "job-123", "status": "pending", "message": "accepted" } } }`
- job-status example:
  - `{ "result": { "success": true, "data": { "exists": true, "status": "completed", "done": true, "result": { "results": [...], "embeddings": [...] } } } }`
- WebSocket-completion example:
  - `{ "event": "job_completed", "job_id": "job-123", "result": { "success": true, "data": { "results": [...], "embeddings": [...] } }, "correlation_id": "ws-delivery-1" }`

## Shared Data Contracts

### EmbedRequest

- `texts: list[str]`
  - required
  - must be non-empty
  - each item must be a non-empty string after validation rules defined by the client API
- `model: str | None`
- `dimension: int | None`
- `error_policy: str | None`
- `device: str | None`

### ImmediateEmbedResult

- final business payload with embeddings data
- must preserve server fields such as:
  - `embeddings`
  - `results`
  - `model`
  - `dimension`
  - `device`

### QueuedEmbedSubmission

- `job_id: str`
- `status: str | None`
- `message: str | None`

### JobStatusPayload

- `exists: bool | None`
- `status: str | None`
- `done: bool | None`
- `result: dict | None`
- `error: dict | None`

### AdapterClientParams

- `protocol: str`
- `host: str`
- `port: int`
- `token_header: str | None`
- `token: str | None`
- `cert: str | None`
- `key: str | None`
- `ca: str | None`
- `check_hostname: bool`
- `timeout: float | None`

### Identifier Types

- `JsonRpcRequestId`
  - transport-layer identifier managed by adapter/runtime
- `JobId`
  - public queued-operation identifier returned by server flows
- `WebSocketCorrelationId`
  - adapter-managed delivery/correlation identifier for async WebSocket flows
- `WebSocketChannelHandle`
  - adapter-returned channel object or channel/session abstraction

## Global Public Interface Inventory

The weak-model-ready planning contract for public interfaces is:

### `embed_client.async_client.EmbeddingServiceAsyncClient`

- purpose: main async facade over adapter-backed transport and normalization
- public methods that must remain aligned with this spec:
  - `embed(texts: list[str], model: str | None = None, dimension: int | None = None, error_policy: str | None = None, device: str | None = None, wait: bool = False, timeout: float | None = None, use_push: bool = True, **extra_params: object) -> dict`
  - `models() -> dict`
  - `timing_stats(file_path: str | None = None) -> dict`
  - `job_status(job_id: str) -> dict`
  - `wait_for_job(job_id: str, timeout: float | None = None) -> dict`
  - `wait_for_job_via_websocket(job_id: str, timeout: float | None = None) -> dict`
  - `open_bidirectional_ws_channel(receive_timeout: float | None = None, heartbeat: float | None = None) -> object`

### `embed_client.testing_client.EmbeddingServiceClient`

- purpose: sync/testing-facing facade over the same adapter-based contract
- public methods that must remain aligned with this spec:
  - `embed(texts: list[str], model: str | None = None, dimension: int | None = None, error_policy: str | None = None, device: str | None = None, wait: bool = False, timeout: float | None = None) -> dict`
  - `models() -> dict`
  - `timing_stats(file_path: str | None = None) -> dict`
  - `job_status(job_id: str) -> dict`
  - `wait_for_job(job_id: str, timeout: float | None = None) -> dict`
  - `wait_for_job_via_websocket(job_id: str, timeout: float | None = None) -> dict`

### `embed_client.adapter_transport.AdapterTransport`

- purpose: adapter-backed transport facade only; no custom auth/transport runtime
- public methods that must remain delegation-only:
  - `jsonrpc_call(method: str, params: dict | None = None) -> dict`
  - `execute_command_unified(command: str, params: dict | None = None, auto_poll: bool = False, timeout: float | None = None, **kwargs: object) -> dict`
  - `execute_async(command: str, params: dict | None = None, on_result: object | None = None, timeout: float | None = None) -> dict`
  - `queue_get_job_status(job_id: str) -> dict`
  - `wait_for_job_via_websocket(job_id: str, timeout: float | None = None) -> dict`
  - `open_bidirectional_ws_channel(receive_timeout: float | None = None, heartbeat: float | None = None) -> object`

### `embed_client.adapter_config_factory.AdapterConfigFactory`

- purpose: deterministic mapping from project config shape to adapter client params
- public methods that must remain explicit mapping-only:
  - `from_config_dict(config: dict) -> AdapterClientParams`
  - `from_client_config(config: object) -> AdapterClientParams`
  - `from_legacy_params(**kwargs: object) -> AdapterClientParams`

### `embed_client.async_client_api_mixin.AsyncClientAPIMixin`

- purpose: build canonical request payloads and top-level command/result behavior
- methods in global scope:
  - `embed(...) -> dict`
  - `models() -> dict`
  - `timing_stats(file_path: str | None = None) -> dict`
  - `cmd(command: str, params: dict | None = None, timeout: float | None = None, wait: bool = False, use_push: bool = True) -> dict`

### `embed_client.async_client_queue_mixin.AsyncClientQueueMixin`

- purpose: expose queue, job-status, and WebSocket waiting behavior without identifier conflation
- methods in global scope:
  - `submit_job(command: str, params: dict | None = None, timeout: float | None = None) -> str | dict`
  - `job_status(job_id: str) -> dict`
  - `wait_for_job(job_id: str, timeout: float | None = None) -> dict`
  - `wait_for_job_via_websocket(job_id: str, timeout: float | None = None) -> dict`
  - `get_job_status_or_result(job_id: str, timeout: float | None = None) -> dict`
  - `open_bidirectional_ws_channel(receive_timeout: float | None = None, heartbeat: float | None = None) -> object`

### `embed_client.async_client_response_mixin.AsyncClientResponseMixin`

- purpose: normalize business payloads only
- methods in global scope:
  - `extract_embeddings(response: dict) -> list`
  - `extract_embedding_data(response: dict) -> list[dict]`
  - `extract_texts(response: dict) -> list[str]`
  - `extract_chunks(response: dict) -> list`
  - `extract_tokens(response: dict) -> list`
  - `extract_bm25_tokens(response: dict) -> list`

## Dependency And Import Contract

The synchronized client may import runtime transport/auth facilities only from:

- `mcp_proxy_adapter.client.jsonrpc_client`
- `mcp_proxy_adapter.core.validation.config_validator`
- `mcp_proxy_adapter.core.config.simple_config_generator`

Project-internal import roles must remain:

- adapter mapping and transport facades under `embed_client/adapter_*`
- async public facade under `embed_client/async_client.py`
- sync/testing facade under `embed_client/testing_client.py`
- exception mapping layer under `embed_client/exceptions.py`

Per-file import contract for primary runtime modules:

### `embed_client/adapter_transport.py`
- import adapter runtime from `mcp_proxy_adapter.client.jsonrpc_client`
- import project exceptions from `embed_client.exceptions`

### `embed_client/async_client.py`
- import adapter-backed transport from `embed_client.adapter_transport`
- import mixins from `embed_client.async_client_api_mixin`, `embed_client.async_client_queue_mixin`, and `embed_client.async_client_response_mixin`
- import project exceptions from `embed_client.exceptions`

### `embed_client/testing_client.py`
- import adapter-backed transport from `embed_client.adapter_transport`
- import config mapping from `embed_client.adapter_config_factory`
- import project exceptions from `embed_client.exceptions`

## Identifier Model

### JSON-RPC Request ID

- Scope: JSON-RPC protocol only.
- Ownership: adapter transport layer.
- Requirement: do not expose it as the domain/job identifier of the embed client API.

### Job ID

- Scope: queue/job lifecycle for embed operations.
- Source: server queued response.
- Uses:
  - status lookup
  - wait-for-completion APIs
  - queue management commands
  - WebSocket subscription flows that are job-based

### Logical Job Mapping

- Scope: server-side coalescing implementation.
- Requirement: the client may treat returned `job_id` as opaque.
- Requirement: the client must not implement separate local semantics for physical vs logical job identifiers unless the server externally exposes that distinction.

### WebSocket Delivery / Correlation Identifier

- Scope: adapter-managed async/WebSocket execution path.
- Requirement: do not collapse this identifier into `job_id` unless the adapter explicitly guarantees equivalence.
- Requirement: the client API and internal normalization must preserve the distinction between:
  - adapter-managed async delivery correlation
  - server job identity

### WebSocket Channel Identity

- Scope: bidirectional channel object created by adapter facilities.
- Requirement: if the adapter exposes only a channel object and not a channel id, the client must not invent one as a protocol identifier.

### Operational Identifier-Safety Rule

An implementation is identifier-safe only if all of the following are true:

1. JSON-RPC request `id` is never exposed as a public API parameter or public return value for queue/job semantics.
2. `job_id` is extracted only from server/adapter fields that explicitly represent queued-job identity.
3. WebSocket correlation identifiers are used only inside adapter-managed async/WebSocket flows.
4. `job_id` and WebSocket correlation identifiers are not merged unless the adapter contract explicitly guarantees equivalence.
5. A missing or ambiguous identifier must be treated as an explicit error, not silently guessed.

## Config Dependency Contract

The canonical global config vocabulary that later steps must use is:

- `server.host: str`
- `server.port: int`
- `server.protocol: str`
- `server.ssl.cert: str | None`
- `server.ssl.key: str | None`
- `server.ssl.ca: str | None`
- `auth.use_token: bool | None`
- `auth.tokens: dict | None`
- `auth.roles: dict | None`
- `client.timeout: float | None`
- method-level runtime parameters, not persistent config keys:
  - `texts`
  - `model`
  - `dimension`
  - `error_policy`
  - `device`
  - `wait`
  - `use_push`
  - `timeout`

The planning hierarchy must not invent additional competing config vocabularies unless they are strictly compatibility wrappers that map back to this contract.

## Required Module-Level Outcome

### Modules To Keep As Adapter-Based Facades

- `embed_client/adapter_transport.py`
- `embed_client/adapter_config_factory.py`
- `embed_client/adapter_config_normalizer.py`
- `embed_client/adapter_generator_bridge.py`
- `embed_client/config_validator.py`

These modules must remain adapter-oriented wrappers only. Their allowed responsibilities are:

- config-to-adapter mapping
- adapter-backed validation/generation bridges
- adapter call delegation
- project-level normalization that does not duplicate transport logic

### Modules To Simplify

- `embed_client/auth.py`
- `embed_client/ssl_manager.py`
- `embed_client/async_client_api_mixin.py`
- `embed_client/async_client_queue_mixin.py`
- `embed_client/async_client_response_mixin.py`
- `embed_client/testing_client.py`
- `embed_client/client_factory.py`

These modules must be reduced so that they no longer duplicate adapter responsibilities. The exact global expectation is:

- `embed_client/auth.py`
  - may remain only as validation/wrapper surface
  - must not execute real authentication logic on its own
- `embed_client/ssl_manager.py`
  - may remain only as validation/wrapper surface
  - must not build a parallel TLS runtime
- `embed_client/async_client_api_mixin.py`
  - may build canonical request params and normalize public results
  - must not implement transport logic outside the adapter
- `embed_client/async_client_queue_mixin.py`
  - may orchestrate adapter-backed waiting/status behavior
  - must not redefine identifier semantics
- `embed_client/async_client_response_mixin.py`
  - may normalize server/adapter business payloads
  - must not hide transport identity boundaries
- `embed_client/testing_client.py`
  - may remain a sync/testing facade
  - must obey the same adapter-backed contract as async client
- `embed_client/client_factory.py`
  - must create only adapter-backed clients

## Error Handling Map

The global exception contract is:

- `EmbeddingServiceError`
  - expected common project base error for service-related failures
- `EmbeddingServiceConfigError`
  - base: `EmbeddingServiceError`
  - raised when project config cannot be mapped or validated for adapter-backed execution
- `EmbeddingServiceConnectionError`
  - base: `EmbeddingServiceError`
  - raised when adapter-backed connection/transport establishment fails
- `EmbeddingServiceAPIError`
  - base: `EmbeddingServiceError`
  - raised when server-side business/API failure is returned
- `EmbeddingServiceHTTPError`
  - base: `EmbeddingServiceError`
  - raised when transport-level HTTP failure is surfaced through the adapter/project wrapper
- `EmbeddingServiceTimeoutError`
  - base: `EmbeddingServiceError`
  - raised when polling or WebSocket wait exceeds the allowed timeout
- `EmbeddingServiceJSONError`
  - base: `EmbeddingServiceError`
  - raised when response parsing/normalization fails structurally
- `AuthenticationError`
  - base: project wrapper-only error
  - may remain only as a compatibility or validation wrapper and must not own real authentication runtime logic

Caller policy for all later planning:

- preserve original adapter/server payloads where possible
- never replace transport/auth behavior with custom fallback runtime logic
- never silently convert one identifier type into another to avoid raising an explicit error

## Forbidden Approaches

- Direct `aiohttp`, `httpx`, `requests`, or custom socket transport for production client-server interaction.
- Custom auth execution logic that pretends to authenticate independently from adapter facilities.
- Custom TLS or certificate session building outside adapter usage.
- Client-owned WebSocket protocol distinct from adapter channel/wait APIs.
- Treating JSON-RPC request `id` as a job identifier.
- Assuming adapter WebSocket delivery correlation and server `job_id` are always the same identifier.
- Maintaining multiple incompatible client config schemas for the same runtime behavior.

## Compatibility Requirements

1. Preserve public high-level client ergonomics exactly where they do not contradict this specification; otherwise prioritize the server contract and adapter-backed behavior.
2. Preserve all security modes required by the repository:
   - http
   - http + token
   - http + token + roles
   - https
   - https + token
   - https + token + roles
   - mtls
   - mtls + roles
3. Preserve both result delivery modes:
   - JSON-RPC immediate
   - JSON-RPC submit plus WebSocket completion
4. Preserve `models`, `timing_stats`, queue inspection, queue stop, and queue log flows where they are publicly exposed.

## Global Logic Descriptions

### Config Normalization Logic

1. Read project config and method inputs.
2. Map protocol/security/auth fields to adapter-compatible constructor params.
3. Preserve token-based and certificate-based security choices as configuration choices only.
4. Reject or normalize incompatible combinations before transport use.
5. Produce `AdapterClientParams` for all runtime client creation paths.

### Embed Request Logic

1. Validate and normalize the public embed call inputs.
2. Build canonical `EmbedRequest` using `texts`.
3. Call the adapter-backed JSON-RPC execution path.
4. Detect whether the returned payload is immediate or queued.
5. Normalize the result into the public client response shape without redefining transport semantics.

### Job/Wait Logic

1. Treat returned `job_id` as opaque.
2. Use adapter-backed waiting or status facilities only.
3. Preserve distinction between job-based waiting and adapter-managed WebSocket correlation.
4. Surface timeout, completion, and failure results through explicit project-level exception or normalized result behavior.

### Identifier-Safety Logic

1. Do not expose JSON-RPC request `id` as a public job/domain identifier.
2. Do not assume WebSocket correlation id equals `job_id`.
3. Use `job_id` for queue/status lifecycle only.
4. Use adapter-managed WebSocket correlation only in adapter-specific async delivery flows.
5. If equivalence is not explicitly guaranteed by adapter behavior, preserve both identities separately.

## Concrete Examples

### Example: Canonical Embed Request

- Input public call:
  - `embed(texts=["a", "b"], model="m1", dimension=768, error_policy="fail_fast", device="cpu")`
- Canonical request payload:
  - `{ "texts": ["a", "b"], "model": "m1", "dimension": 768, "error_policy": "fail_fast", "device": "cpu" }`

### Example: Immediate Result Handling

- Input adapter/server category:
  - JSON-RPC success result with final embedding payload
- Required client behavior:
  - normalize final business data
  - return public result without inventing `job_id`

### Example: Queued Result Handling

- Input adapter/server category:
  - JSON-RPC success result containing `job_id`
- Required client behavior:
  - expose `job_id`
  - allow polling or adapter-managed WebSocket wait
  - keep `job_id` separate from JSON-RPC request `id`

### Example: WebSocket Completion Handling

- Input adapter/server category:
  - adapter-managed WebSocket completion payload
- Required client behavior:
  - normalize business result
  - preserve any adapter-managed correlation identity separately from `job_id` unless explicit equivalence is guaranteed

## Test Strategy

The final synchronized implementation must be validated against:

- adapter integration tests already present in `tests/`
- client API tests for immediate and queued results
- explicit identifier-separation tests for JSON-RPC, `job_id`, and adapter-managed WebSocket correlation
- full security-mode matrix required by repository rules
- real vectorization verification on `localhost:8001`

The global test inventory expected by downstream planning is:

- `tests/test_async_client.py`
- `tests/test_adapter_transport.py`
- `tests/test_client_factory.py`
- `tests/test_adapter_integration.py`
- focused identifier tests under `tests/`
- focused immediate/queued/WebSocket result tests under `tests/`
- security-matrix validation tests/scripts under `tests/` and `scripts/`

## Acceptance Criteria

1. No production client path performs auth or transport outside adapter client facilities.
2. Public embed execution correctly supports both immediate JSON-RPC results and deferred completion flows.
3. The client no longer conflates JSON-RPC `id`, `job_id`, and WebSocket-local correlation identifiers.
4. Security mode selection is configuration-driven and delegated to adapter-compatible settings.
5. Public client methods return stable project-level responses while using adapter-native transport behavior underneath.
6. All repository-required security-mode tests pass.
7. Real vectorization on `localhost:8001` passes.

## Glossary

- `mcp-proxy-adapter`: the only allowed runtime implementation source for client authentication, transport, TLS/mTLS, JSON-RPC execution, queue operations, and WebSocket communication.
- `adapter`: shorthand in this specification for `mcp-proxy-adapter`.
- `Adapter-based facade`: a project module that delegates runtime behavior to adapter facilities and may only add config mapping, normalization, or project-level exceptions.
- `Immediate JSON-RPC result`: a final business result returned directly in JSON-RPC success flow without public queued lifecycle.
- `Queued result`: an initial success payload exposing `job_id`, after which completion is resolved through status or adapter-managed waiting.
- `WebSocket correlation identifier`: any adapter-managed delivery identifier used to correlate async WebSocket completion, distinct from `job_id` unless explicit equivalence is guaranteed.
- `Synchronized with the server`: request fields, response handling, identifier semantics, and protocol/security behavior all match the current server contract and required validation matrix.
