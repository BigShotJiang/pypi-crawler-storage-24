Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Update TestingClient Docstrings and Type Hints

## Executor Role

**Executor:** `coder_auto`

**Role:** Implement documentation and type hint updates in `embed_client/testing_client.py` to explicitly document identifier types used by `_embed_via_execute_async()` and `wait_for_job_via_websocket()` methods.

## Execution Directive

Update docstrings and type hints in `embed_client/testing_client.py` to explicitly document:
1. `_embed_via_execute_async()` uses adapter `execute_async()` which manages `deliver_id` internally for WebSocket correlation (distinct from queue `job_id`)
2. `wait_for_job_via_websocket()` uses `job_id` (queue-based identifier) for WebSocket subscription

Add type hints using `JobId` and `DeliverId` types from `embed_client.identifier_types` module.

## Parent Links

- **Tech spec:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- **Parent tactical task:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/websocket-correlation-identifier-handling.md`

## Step Scope

**Target file:** `embed_client/testing_client.py`

**Action:** modify

**Lines to modify:**
- Lines 357-403: `_embed_via_execute_async()` method - update docstring
- Lines 423-453: `wait_for_job_via_websocket()` method - update docstring and add type hint

**No code logic changes** - only documentation and type hints.

## Dependency Contract

**Depends on:**
- `identifier-extraction-and-type-separation` tactical task must be completed first (provides `JobId` and `DeliverId` types from `embed_client.identifier_types` module)

**If types are not available:**
- The step must still update docstrings (they don't require the types)
- Type hints can be added conditionally or the step can wait for types to be available
- Document in the step that type hints depend on the identifier types module existing

## Required Context

- Understanding that `_embed_via_execute_async()` uses adapter `execute_async()` which manages `deliver_id` internally
- Understanding that `wait_for_job_via_websocket()` is for queue operations and uses `job_id` (not `deliver_id`)
- Understanding that `deliver_id` and `job_id` are distinct identifier types and must not be confused
- Current docstrings in the target file (read from lines 360-364 for `_embed_via_execute_async`, lines 426-428 for `wait_for_job_via_websocket`)

## Read First

**Required files to read before implementation:**
1. `/home/vasilyvz/projects/embed-client/embed_client/testing_client.py` - current implementation
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/websocket-correlation-identifier-handling.md` - tactical task requirements
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation.md` - to understand `JobId` and `DeliverId` type definitions (if available)

## Expected File Change

**File:** `embed_client/testing_client.py`

**Changes:**
1. **Import section (around line 20):** Add import for `JobId` and `DeliverId` types:
   ```python
   from embed_client.identifier_types import JobId, DeliverId
   ```

2. **`_embed_via_execute_async()` method (lines 357-403):** Update docstring to explicitly state:
   - Uses adapter `execute_async()` which manages `deliver_id` internally for WebSocket correlation
   - The `deliver_id` is distinct from queue `job_id`
   - This method does not expose `deliver_id` to the caller

3. **`wait_for_job_via_websocket()` method (lines 423-453):** 
   - Update docstring to explicitly state:
     - Uses `job_id` (queue-based identifier) for WebSocket subscription
     - This method is for queue operations only
     - The `job_id` parameter must be a queue job identifier obtained from queue submission, not a `deliver_id` from `execute_async`
   - Add type hint: change `job_id: str` to `job_id: JobId`

**No method signatures change** - only docstrings and type hints.

## Forbidden Alternatives

1. **DO NOT** change method signatures (parameters, return types, async/await)
2. **DO NOT** modify method implementation logic
3. **DO NOT** add new methods or classes
4. **DO NOT** remove existing docstrings
5. **DO NOT** assume `deliver_id` and `job_id` are interchangeable
6. **DO NOT** use `job_id` type hint for `_embed_via_execute_async()` parameters (it doesn't use `job_id`)
7. **DO NOT** modify any other methods in the file
8. **DO NOT** change import order or add unrelated imports

## Atomic Operations

### Operation 1: Add Import Statement

**Location:** After existing imports (around line 20, after `from embed_client.exceptions import ...`)

**Action:** Add:
```python
from embed_client.identifier_types import JobId, DeliverId
```

**If module doesn't exist yet:** Add the import anyway (it will be created by the identifier-extraction task). The import may cause a temporary mypy error until the module exists, but that's acceptable.

### Operation 2: Update `_embed_via_execute_async()` Docstring

**Location:** Lines 360-364 (inside the `_embed_via_execute_async()` method)

**Current docstring:**
```python
"""
Run embed in-process via execute_async (WebSocket push).

Uses adapter execute_async; server runs embed_execute and pushes
result via WebSocket. Returns embed result shape; raises on failure/timeout.
"""
```

**New docstring (replace entire docstring):**
```python
"""
Run embed in-process via execute_async (WebSocket push).

Uses adapter `execute_async()` which manages `deliver_id` internally for WebSocket
correlation. The adapter generates a `deliver_id`, subscribes to WebSocket with
that `deliver_id`, sends the execute_async RPC, and waits for server push. The
server runs embed_execute and pushes result via WebSocket using the `deliver_id`
for correlation.

**Identifier semantics:**
- Uses adapter `execute_async()` which manages `deliver_id` internally
- The `deliver_id` is distinct from queue `job_id` and must not be confused with it
- This method does not expose `deliver_id` to the caller (adapter handles it internally)
- For queue operations, use `embed()` with `wait=False` and then `wait_for_job_via_websocket(job_id)`

Returns embed result shape (results, model, dimension); raises on failure/timeout.
"""
```

### Operation 3: Update `wait_for_job_via_websocket()` Docstring and Type Hint

**Location:** Lines 423-453 (method signature and docstring)

**Current method signature:**
```python
async def wait_for_job_via_websocket(
    self, job_id: str, timeout: int = 60
) -> Dict[str, Any]:
```

**New method signature (add type hint):**
```python
async def wait_for_job_via_websocket(
    self, job_id: JobId, timeout: int = 60
) -> Dict[str, Any]:
```

**Current docstring:**
```python
"""
Wait for job completion via adapter WebSocket /ws (push).
"""
```

**New docstring (replace entire docstring):**
```python
"""
Wait for job completion via adapter WebSocket /ws (push).

Uses `job_id` (queue-based identifier) for WebSocket subscription. This method
subscribes to WebSocket push events for a queued job. The server must expose /ws
and job_push. Returns embed result shape (results, model, dimension) when job completes.

**Identifier semantics:**
- Uses `job_id` (queue-based identifier) for WebSocket subscription
- This method is for queue operations only
- The `job_id` parameter must be a queue job identifier obtained from queue
  submission (e.g., from `embed()` with `wait=False`), not a `deliver_id` from
  `execute_async()` or `_embed_via_execute_async()`
- Do not pass a `deliver_id` from `execute_async()` response to this method
- For `execute_async` operations, use `_embed_via_execute_async()` (which uses
  `execute_async()` internally) instead

Args:
    job_id: Queue job identifier from embed submit or queue submission. Must be
        a `job_id` from queue operations, not a `deliver_id` from `execute_async()`.
    timeout: Max seconds to wait for a terminal event.

Returns:
    Embed result data (results, model, dimension, optional device).

Raises:
    EmbeddingServiceTimeoutError: If timeout exceeded.
    EmbeddingServiceAPIError: If job failed or WebSocket error.
"""
```

## Expected Deliverables

1. **Modified file:** `embed_client/testing_client.py` with:
   - Import statement for `JobId` and `DeliverId` types added
   - Updated docstring for `_embed_via_execute_async()` method documenting `deliver_id` usage
   - Updated docstring and type hint for `wait_for_job_via_websocket()` method documenting `job_id` usage

2. **No new files created**

3. **No test files modified** (tests are in a separate tactical task)

## Mandatory Validation

**After implementation, run these exact commands:**

1. **Format check:**
   ```bash
   black embed_client/testing_client.py
   ```
   **Expected:** "reformatted" or "already well formatted" (exit code 0)

2. **Lint check:**
   ```bash
   flake8 embed_client/testing_client.py
   ```
   **Expected:** No output (exit code 0)

3. **Type check:**
   ```bash
   mypy embed_client/testing_client.py
   ```
   **Expected:** 
   - If `identifier_types` module exists: "Success: no issues found" (exit code 0)
   - If `identifier_types` module doesn't exist yet: May show import error, which is acceptable until the identifier-extraction task completes

4. **Syntax check:**
   ```bash
   python -m py_compile embed_client/testing_client.py
   ```
   **Expected:** No output (exit code 0)

**All validation commands must pass before marking step complete.**

## Decision Rules

1. **If `identifier_types` module doesn't exist:**
   - Still add the import statement (it will be created by identifier-extraction task)
   - mypy may show an error, which is acceptable
   - Document in commit message that type hints depend on identifier-extraction task

2. **Docstring format:**
   - Use triple-quoted strings with proper indentation
   - Follow existing docstring style in the file
   - Use **bold** for important semantic notes (Identifier semantics section)

3. **Type hint placement:**
   - Place type hint directly in method signature parameter
   - Do not use type comments (`# type: JobId`)

## Blackstops

**Stop and escalate if:**
1. The `_embed_via_execute_async()` method signature changes (it should remain unchanged)
2. The `wait_for_job_via_websocket()` method signature changes beyond adding type hint (parameters, return type, async should remain unchanged)
3. Any method implementation logic needs to change (this step is documentation-only)
4. Import statement causes syntax errors that cannot be resolved

## Handoff Package

**For `coder_auto` executor:**

1. **Target file:** `embed_client/testing_client.py` (modify existing file)

2. **Exact changes:**
   - Add import: `from embed_client.identifier_types import JobId, DeliverId` (after line 20, in import section)
   - Replace `_embed_via_execute_async()` docstring (lines 360-364) with new docstring documenting `deliver_id` usage
   - Replace `wait_for_job_via_websocket()` docstring (lines 426-428) with new docstring documenting `job_id` usage
   - Change `wait_for_job_via_websocket()` parameter type from `job_id: str` to `job_id: JobId` (line 424)

3. **Validation commands:** Run black, flake8, mypy, py_compile (see Mandatory Validation section)

4. **Dependencies:** This step depends on `identifier-extraction-and-type-separation` task providing `JobId` and `DeliverId` types. If types don't exist yet, add import anyway (mypy error is acceptable until types are created).

5. **No code logic changes** - only documentation and type hints.

## Complete Import List

**Current imports in file (lines 14-37):**
```python
from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union, cast

from embed_client.adapter_config_factory import AdapterConfigFactory
from embed_client.adapter_transport import AdapterTransport
from embed_client.constants import EMBED_DEFAULT_ERROR_POLICY
from embed_client.config_generator import ClientConfigGenerator
from embed_client.config_validator import ConfigValidator
from embed_client.exceptions import (
    EmbeddingServiceAPIError,
    EmbeddingServiceConfigError,
    EmbeddingServiceError,
    EmbeddingServiceTimeoutError,
)
from embed_client.testing_client_helpers import (
    list_commands_via_client,
    wait_for_job_poll,
)
```

**Add after line 37 (after `from embed_client.testing_client_helpers import ...`):**
```python
from embed_client.identifier_types import JobId, DeliverId
```

## Method Signatures (No Changes Except Type Hint)

**`_embed_via_execute_async()` method signature (unchanged):**
```python
async def _embed_via_execute_async(
    self, params: Dict[str, Any], timeout: int = 60
) -> Dict[str, Any]:
```

**`wait_for_job_via_websocket()` method signature (only type hint change):**
```python
async def wait_for_job_via_websocket(
    self, job_id: JobId, timeout: int = 60
) -> Dict[str, Any]:
```

## Step-by-Step Algorithm

### Step 1: Read Current File
1. Read `embed_client/testing_client.py` completely
2. Identify import section (around line 20)
3. Identify `_embed_via_execute_async()` method (lines 357-403)
4. Identify `wait_for_job_via_websocket()` method (lines 423-453)

### Step 2: Add Import Statement
1. Locate the import section (after `from embed_client.testing_client_helpers import ...`)
2. Add new line: `from embed_client.identifier_types import JobId, DeliverId`
3. Ensure proper spacing and formatting

### Step 3: Update `_embed_via_execute_async()` Docstring
1. Locate the docstring inside `_embed_via_execute_async()` method (lines 360-364)
2. Replace entire docstring with new docstring from "Atomic Operations" section
3. Ensure proper indentation (4 spaces, aligned with method body)
4. Preserve triple quotes format

### Step 4: Update `wait_for_job_via_websocket()` Method
1. Locate method signature (line 424)
2. Change parameter type from `job_id: str` to `job_id: JobId`
3. Locate docstring (lines 426-428)
4. Replace entire docstring with new docstring from "Atomic Operations" section
5. Ensure proper indentation

### Step 5: Validate Changes
1. Run `black embed_client/testing_client.py`
2. Run `flake8 embed_client/testing_client.py`
3. Run `mypy embed_client/testing_client.py` (may show import error if types don't exist yet - acceptable)
4. Run `python -m py_compile embed_client/testing_client.py`
5. Verify file syntax is correct

## Error Handling Specification

**No error handling changes needed.** This step only updates documentation and type hints. Existing error handling in methods remains unchanged.

**If import fails:**
- If `identifier_types` module doesn't exist, mypy will show import error
- This is acceptable until identifier-extraction task completes
- Do not remove the import - it will be needed once types are created

## Edge Cases

**Edge case 1: `identifier_types` module doesn't exist yet**
- **Behavior:** Add import anyway, mypy may show error
- **Action:** Acceptable - types will be created by identifier-extraction task
- **Documentation:** Note in commit message that type hints depend on identifier-extraction task

**Edge case 2: Existing docstring format differs slightly**
- **Behavior:** Follow existing docstring style in the file
- **Action:** Match indentation and formatting style of other docstrings in the file

**Edge case 3: Type hint causes mypy error if types don't exist**
- **Behavior:** mypy reports "Cannot find implementation or library stub"
- **Action:** Acceptable - error will resolve when identifier-extraction task completes
- **Documentation:** Do not remove type hint - it's required by the tactical task

## Exact Constants and Literals

**No new constants or literals needed.** This step only updates documentation strings and type hints.

**String literals in docstrings:**
- All docstring text is provided in the "Atomic Operations" section
- Use exact text as specified (including **bold** markers for emphasis)

## Forbidden Patterns

1. **DO NOT** use `# type: JobId` comments instead of inline type hints
2. **DO NOT** change method implementation code
3. **DO NOT** add new methods or modify other methods
4. **DO NOT** remove existing imports
5. **DO NOT** change import order (add new import at the end of import section)
6. **DO NOT** use `Any` type for `job_id` parameter
7. **DO NOT** assume `deliver_id` and `job_id` are the same type
8. **DO NOT** modify docstrings of other methods
9. **DO NOT** add implementation code to methods
10. **DO NOT** change async/await keywords or method signatures beyond type hints
