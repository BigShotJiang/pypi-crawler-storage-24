Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Queue Polling Identifier Handling

## Purpose

Ensure all queue polling operations use only `job_id` (queue-based identifier) and never confuse it with `deliver_id` (adapter-managed WebSocket async delivery). Update queue status polling, job management, and wait methods to explicitly document `job_id` usage and ensure type safety.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`

## Scope

**Included:**
- Updates to `job_status()` to document `job_id` usage
- Updates to `wait_for_job()` to document `job_id` usage
- Updates to `queue_get_job_status()` wrapper to document `job_id` usage
- Updates to `submit_job()` to ensure it returns `job_id` (not `deliver_id`)
- Updates to `get_job_status_or_result()` to document `job_id` usage
- Updates to queue management methods (`cancel_command`, `list_queued_commands`, `get_job_logs`) to document `job_id` usage
- Type hints using `JobId` type

**Excluded:**
- Changes to identifier extraction logic (separate tactical task)
- Changes to WebSocket correlation logic (separate tactical task)
- Test code (separate tactical task)

## Boundaries

**Must NOT touch:**
- Adapter transport methods that delegate to adapter (they handle JSON-RPC request IDs internally)
- `execute_async()` flow (uses `deliver_id`, separate concern)
- WebSocket waiting methods (separate tactical task)

## Dependencies

- **Depends on:** `identifier-extraction-and-type-separation` (needs `JobId` type)

## Parallelization Note

This task can run in parallel with `websocket-correlation-identifier-handling` but must wait for `identifier-extraction-and-type-separation` to complete.

## Expected Outcome

1. All queue polling methods explicitly use `job_id` (queue-based identifier)
2. Method docstrings clearly state `job_id` usage
3. Type hints use `JobId` type for queue identifiers
4. No confusion between `job_id` and `deliver_id` in queue polling paths

## Correction Items

**Existing code to update:**
- `embed_client/adapter_transport.py:274-300` - `queue_get_job_status()` docstring must explicitly state it uses `job_id` (queue-based)
- `embed_client/async_client_queue_mixin.py:35-207` - `wait_for_job()` docstring must explicitly state it uses `job_id` (queue-based)
- `embed_client/async_client_queue_mixin.py:269-278` - `job_status()` docstring must explicitly state it uses `job_id` (queue-based)
- `embed_client/async_client_queue_mixin.py:280-286` - `cancel_command()` docstring must explicitly state it uses `job_id` (queue-based)
- `embed_client/async_client_queue_mixin.py:319-374` - `submit_job()` must ensure it returns `job_id` (not `deliver_id`) and document this
- `embed_client/async_client_queue_mixin.py:376-413` - `get_job_status_or_result()` docstring must explicitly state it uses `job_id` (queue-based)
- `embed_client/testing_client.py:405-421` - `wait_for_job()` docstring must explicitly state it uses `job_id` (queue-based)
- `embed_client/testing_client.py:471-501` - `job_status()` docstring must explicitly state it uses `job_id` (queue-based)

## Questions/Escalation Rule

**Escalate to orchestrator if:**
- Server queue contract changes identifier semantics (requires global spec update)
- Adapter behavior changes and queue operations start using `deliver_id` (requires global decision)

## File Inventory

**Action: modify**
- **Path:** `embed_client/adapter_transport.py`
- **Purpose:** Update `queue_get_job_status()` docstring to document `job_id` usage

**Action: modify**
- **Path:** `embed_client/async_client_queue_mixin.py`
- **Purpose:** Update all queue polling methods to document `job_id` usage and add type hints

**Action: modify**
- **Path:** `embed_client/testing_client.py`
- **Purpose:** Update `wait_for_job()` and `job_status()` docstrings to document `job_id` usage

## Class/Function Inventory

### `embed_client.adapter_transport` (modify)

**Functions to modify:**
- `queue_get_job_status(job_id: str) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses `job_id` (queue-based identifier) for status lookup. This method is for queue operations only. The `job_id` parameter must be a queue job identifier obtained from queue submission, not a `deliver_id` from `execute_async`." Update parameter type hint to `JobId` after import.

**Imports to add:**
```python
from embed_client.identifier_types import JobId
```

### `embed_client.async_client_queue_mixin` (modify)

**Functions to modify:**
- `wait_for_job(job_id: str, timeout: Optional[float] = 60.0, poll_interval: float = DEFAULT_POLL_INTERVAL) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses `job_id` (queue-based identifier) for status polling. This method polls queue status via HTTP, not WebSocket. For WebSocket waiting, use `wait_for_job_via_websocket()`. The `job_id` parameter must be a queue job identifier, not a `deliver_id`." Update parameter type hint to `JobId` after import.

- `job_status(job_id: str) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses `job_id` (queue-based identifier) for status lookup. The `job_id` parameter must be a queue job identifier obtained from queue submission." Update parameter type hint to `JobId` after import.

- `cancel_command(job_id: str) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses `job_id` (queue-based identifier) to cancel and delete a queued job. The `job_id` parameter must be a queue job identifier." Update parameter type hint to `JobId` after import.

- `submit_job(command: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]` - Update docstring to explicitly state: "Returns `job_id` (queue-based identifier) in the response. This `job_id` is distinct from `deliver_id` used by `execute_async`. Use this `job_id` for queue status polling and WebSocket subscription, not for `execute_async` operations." Ensure return type documents `job_id` field as `JobId`.

- `get_job_status_or_result(job_id: str, timeout: Optional[float] = None) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses `job_id` (queue-based identifier) for status checking. The `job_id` parameter must be a queue job identifier." Update parameter type hint to `JobId` after import.

- `list_queued_commands(status: Optional[str] = None, limit: Optional[int] = None) -> Dict[str, Any]` - Update docstring to note that returned jobs contain `job_id` fields (queue-based identifiers).

- `get_job_logs(job_id: str) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses `job_id` (queue-based identifier) to retrieve job logs. The `job_id` parameter must be a queue job identifier." Update parameter type hint to `JobId` after import.

**Imports to add:**
```python
from embed_client.identifier_types import JobId
```

### `embed_client.testing_client` (modify)

**Functions to modify:**
- `wait_for_job(job_id: str, timeout: int = 60, poll_interval: float = 1.0) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses `job_id` (queue-based identifier) for status polling. The `job_id` parameter must be a queue job identifier obtained from queue submission." Update parameter type hint to `JobId` after import.

- `job_status(job_id: str) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses `job_id` (queue-based identifier) for status lookup. The `job_id` parameter must be a queue job identifier." Update parameter type hint to `JobId` after import.

**Imports to add:**
```python
from embed_client.identifier_types import JobId
```

## Data Structures

**No new data structures needed.** This task only updates documentation and type hints.

## Import Map

### `embed_client/adapter_transport.py` (additions)
```python
from embed_client.identifier_types import JobId
```

### `embed_client/async_client_queue_mixin.py` (additions)
```python
from embed_client.identifier_types import JobId
```

### `embed_client/testing_client.py` (additions)
```python
from embed_client.identifier_types import JobId
```

## Error Handling Map

**No error handling changes needed.** This task only updates documentation and type hints. Existing error handling remains unchanged.

## Config Dependency

**No config keys used in this task** (queue polling uses identifiers from responses, not configuration).

## Test Plan

**Test file:** `tests/test_queue_polling_identifier_separation.py` (to be created in separate tactical task)

**Test functions:**
- `test_job_status_uses_job_id()` - Verify that `job_status()` uses `job_id` for queue status lookup
- `test_wait_for_job_uses_job_id()` - Verify that `wait_for_job()` uses `job_id` for polling
- `test_submit_job_returns_job_id()` - Verify that `submit_job()` returns `job_id` (not `deliver_id`)
- `test_queue_methods_reject_deliver_id()` - Verify that queue methods fail or reject `deliver_id` values
- `test_cancel_command_uses_job_id()` - Verify that `cancel_command()` uses `job_id`
- `test_get_job_logs_uses_job_id()` - Verify that `get_job_logs()` uses `job_id`

**Fixtures/mocks:** Mock adapter `queue_get_job_status()` responses

## Concrete Examples

### Example 1: job_status uses job_id
**Scenario:** Client calls `job_status(job_id="queue-job-123")`
**Adapter behavior:** Adapter calls `queue_get_job_status("queue-job-123")` via JSON-RPC
**Server behavior:** Server returns status for queue job with `job_id="queue-job-123"`
**Note:** `job_id` is queue-based identifier, not `deliver_id`

### Example 2: wait_for_job uses job_id for polling
**Scenario:** Client calls `wait_for_job(job_id="queue-job-456", timeout=60.0)`
**Client behavior:** Client polls `job_status("queue-job-456")` repeatedly until completion
**Adapter behavior:** Each poll calls `queue_get_job_status("queue-job-456")` via JSON-RPC
**Note:** This is HTTP polling, not WebSocket. Uses `job_id`, not `deliver_id`

### Example 3: submit_job returns job_id
**Scenario:** Client calls `submit_job("embed", params)`
**Server response:** `{"mode": "queued", "job_id": "queue-job-789", "status": "pending"}`
**Client extraction:** Extracts `job_id="queue-job-789"` using queue-specific extraction
**Return value:** `{"job_id": "queue-job-789", "status": "pending", "mode": "queued"}`
**Note:** Returned `job_id` is queue-based, distinct from any `deliver_id`

### Example 4: Mixing identifiers fails
**Scenario:** Client gets `deliver_id="deliver-abc"` from `execute_async`, then calls `job_status(job_id="deliver-abc")`
**Expected behavior:** Server queue lookup with `job_id="deliver-abc"` will fail (queue doesn't know about `deliver_id`)
**Result:** Error or "job not found" (identifier mismatch)

## Algorithm/Logic Description

**No algorithm changes needed.** This task only updates documentation and type hints. The actual queue polling logic remains unchanged.

### Documentation updates:

1. **All queue polling methods:**
   - Add explicit statement: "Uses `job_id` (queue-based identifier)"
   - Add explicit statement: "The `job_id` parameter must be a queue job identifier obtained from queue submission"
   - Add explicit statement: "This is distinct from `deliver_id` used by `execute_async`"

2. **Type hints:**
   - Update all `job_id: str` parameters to `job_id: JobId` (after import)

3. **Return value documentation:**
   - Document that methods returning `job_id` return `JobId` type (queue-based identifier)

## Forbidden Approaches

1. **DO NOT** use `deliver_id` for queue polling operations (use `job_id` only)
2. **DO NOT** assume `job_id` and `deliver_id` are interchangeable (they are distinct identifier types)
3. **DO NOT** use queue polling methods with `deliver_id` values (will fail due to identifier mismatch)
4. **DO NOT** change method signatures (only update docstrings and type hints)
5. **DO NOT** modify adapter transport delegation logic (adapter handles JSON-RPC request IDs internally)
