Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Create Identifier Types Module

## Executor Role

**Executor:** `coder_auto`

## Execution Directive

Create a new module `embed_client/identifier_types.py` that defines type aliases for identifier types (`JobId`, `DeliverId`) and validation functions to ensure identifier type safety and prevent confusion between queue job identifiers and adapter-managed WebSocket delivery identifiers.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation.md`

## Step Scope

**Target file:** `embed_client/identifier_types.py`  
**Action:** create

## Dependency Contract

**Dependencies:** None (this is the foundation module)  
**Dependents:** 
- `embed_client/async_client_api_mixin.py` (will import `JobId`, `DeliverId`, `is_valid_job_id`, `is_valid_deliver_id`)
- `embed_client/async_client_queue_mixin.py` (will import `JobId`)

## Required Context

This module provides type-safe identifier handling to prevent confusion between:
- `JobId`: Queue job identifiers returned from server queue operations
- `DeliverId`: Adapter-managed WebSocket delivery/correlation identifiers from `execute_async` responses

These identifiers are distinct types and must not be collapsed into each other unless the adapter explicitly guarantees equivalence (which it does not).

## Read First

- `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` (Identifier Model section)
- `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation.md` (Type aliases and validation functions section)

## Expected File Change

Create new file `embed_client/identifier_types.py` with:
- Module docstring (author, email, description)
- Type aliases: `JobId`, `DeliverId` using `NewType`
- Validation functions: `is_valid_job_id()`, `is_valid_deliver_id()`
- `__all__` export list

## Forbidden Alternatives

- **DO NOT** use `TypeVar` or generic types (use `NewType` for type safety)
- **DO NOT** create classes or dataclasses (use type aliases only)
- **DO NOT** add any business logic beyond validation (this is a pure type/validation module)
- **DO NOT** import from other embed_client modules (this module has no dependencies)
- **DO NOT** add constants or configuration (this module is type-only)

## Atomic Operations

### File Header

Create file with module docstring:
```python
"""
Type definitions and validation functions for identifier types.

This module provides type-safe identifiers to distinguish between:
- JobId: Queue job identifiers from server queue operations
- DeliverId: Adapter-managed WebSocket delivery/correlation identifiers

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
```

### Imports

Add exactly these imports at the top of the file (after `from __future__ import annotations` if present):
```python
from __future__ import annotations

from typing import NewType
```

### Type Aliases

Define two type aliases using `NewType`:
1. `JobId = NewType("JobId", str)` - Type alias for queue job identifiers
2. `DeliverId = NewType("DeliverId", str)` - Type alias for adapter-managed WebSocket delivery identifiers

### Validation Functions

#### Function: `is_valid_job_id(identifier: str) -> bool`

**Signature:**
```python
def is_valid_job_id(identifier: str) -> bool:
```

**Docstring:**
```python
"""
Validate that a string is a valid job_id.

A valid job_id is a non-empty string after stripping whitespace.

Args:
    identifier: String to validate.

Returns:
    True if identifier is a non-empty string after stripping, False otherwise.
"""
```

**Algorithm:**
1. Check if `identifier` is a string (if not, return `False`)
2. Strip whitespace from `identifier` using `identifier.strip()`
3. Check if stripped result is non-empty (length > 0)
4. Return `True` if non-empty, `False` otherwise

**Edge cases:**
- Empty string `""` → return `False`
- Whitespace-only string `"   "` → return `False`
- Non-string input (e.g., `None`, `123`) → return `False`
- Valid string `"abc123"` → return `True`
- String with whitespace `"  abc123  "` → strip and return `True`

**Error handling:**
- No exceptions raised (returns `False` for invalid input)
- If `identifier` is not a string, return `False` (do not raise TypeError)

#### Function: `is_valid_deliver_id(identifier: str) -> bool`

**Signature:**
```python
def is_valid_deliver_id(identifier: str) -> bool:
```

**Docstring:**
```python
"""
Validate that a string is a valid deliver_id.

A valid deliver_id is a non-empty string after stripping whitespace.

Args:
    identifier: String to validate.

Returns:
    True if identifier is a non-empty string after stripping, False otherwise.
"""
```

**Algorithm:**
1. Check if `identifier` is a string (if not, return `False`)
2. Strip whitespace from `identifier` using `identifier.strip()`
3. Check if stripped result is non-empty (length > 0)
4. Return `True` if non-empty, `False` otherwise

**Edge cases:**
- Empty string `""` → return `False`
- Whitespace-only string `"   "` → return `False`
- Non-string input (e.g., `None`, `123`) → return `False`
- Valid string `"deliver-abc-123"` → return `True`
- String with whitespace `"  deliver-xyz  "` → strip and return `True`

**Error handling:**
- No exceptions raised (returns `False` for invalid input)
- If `identifier` is not a string, return `False` (do not raise TypeError)

### Export List

Add `__all__` at the end of the file:
```python
__all__ = ["JobId", "DeliverId", "is_valid_job_id", "is_valid_deliver_id"]
```

## Expected Deliverables

1. New file `embed_client/identifier_types.py` exists
2. File contains type aliases `JobId` and `DeliverId`
3. File contains validation functions `is_valid_job_id()` and `is_valid_deliver_id()`
4. File has proper module docstring with author and email
5. File has `__all__` export list
6. All imports are at the top of the file
7. File passes black, flake8, and mypy validation

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Format check:**
   ```bash
   black embed_client/identifier_types.py
   ```
   **Expected:** "reformatted embed_client/identifier_types.py" or "All done! ✨ 🍰 ✨" or "would reformat" (if check-only mode)

2. **Lint check:**
   ```bash
   flake8 embed_client/identifier_types.py
   ```
   **Expected:** No output (exit code 0)

3. **Type check:**
   ```bash
   mypy embed_client/identifier_types.py
   ```
   **Expected:** "Success: no issues found in 1 source file"

4. **Import test:**
   ```bash
   python3 -c "from embed_client.identifier_types import JobId, DeliverId, is_valid_job_id, is_valid_deliver_id; print('OK')"
   ```
   **Expected:** "OK" printed, no errors

5. **Type safety test:**
   ```bash
   python3 -c "from embed_client.identifier_types import JobId, DeliverId; j = JobId('test'); d = DeliverId('test'); print('Types distinct:', type(j) != type(d) or j != d)"
   ```
   **Expected:** No errors (types are distinct at runtime via NewType)

## Decision Rules

- Use `NewType` (not `TypeVar`) because we want distinct types that prevent mixing, not generic type variables
- Validation functions return `bool` (not raise exceptions) to allow caller flexibility in error handling
- Validation checks for non-empty after strip (not just truthiness) to be explicit about whitespace handling
- No default values or optional parameters in validation functions (keep API simple)

## Blackstops

**STOP and escalate if:**
- `NewType` is not available in the Python typing module (should be available in Python 3.5.2+)
- Project uses a different type system (e.g., Pydantic models for identifiers) - check with orchestrator_tactical

## Handoff Package

**File to create:** `embed_client/identifier_types.py`

**Complete file structure:**
- Module docstring with author/email
- `from __future__ import annotations`
- `from typing import NewType`
- `JobId = NewType("JobId", str)`
- `DeliverId = NewType("DeliverId", str)`
- `is_valid_job_id(identifier: str) -> bool` function with implementation
- `is_valid_deliver_id(identifier: str) -> bool` function with implementation
- `__all__ = ["JobId", "DeliverId", "is_valid_job_id", "is_valid_deliver_id"]`

**Validation commands to run:**
- `black embed_client/identifier_types.py`
- `flake8 embed_client/identifier_types.py`
- `mypy embed_client/identifier_types.py`
- Import test commands (see Mandatory Validation section)

**Completion condition:** All validation commands pass, file is created and importable.
