Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Test Identifier Separation in Queue, WebSocket, and Public API

## Executor Role

**Executor:** `coder_auto`

**Execution directive:** Create comprehensive test file for identifier separation in queue polling, WebSocket correlation, and public API methods. Verify that `job_id` and `deliver_id` are used correctly and not confused.

## Parent Links

- **Tech spec:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- **Parent tactical task:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-focused-tests.md`

## Step Scope

**Target file:** `tests/test_identifier_separation.py`

**Action:** create

**Purpose:** Test identifier separation in queue polling (uses `job_id`), WebSocket correlation (uses `deliver_id` for `execute_async`, `job_id` for queue-based WebSocket), public API methods (embed, cmd), and verify identifier confusion fails appropriately.

## Dependency Contract

**Depends on:**
- `embed_client/async_client_api_mixin.py` - contains `AsyncClientAPIMixin` with `embed()`, `cmd()` methods
- `embed_client/async_client_queue_mixin.py` - contains `AsyncClientQueueMixin` with `submit_job()`, `job_status()`, `wait_for_job()`, `wait_for_job_via_websocket()` methods
- `embed_client/testing_client.py` - contains `EmbeddingServiceClient` class
- `embed_client/adapter_transport.py` - contains `AdapterTransport` with `execute_async()`, `queue_get_job_status()`, `wait_for_job_via_websocket()` methods
- `embed_client/identifier_types.py` - contains `JobId`, `DeliverId` type definitions

**No dependencies on other test files** (can run in parallel with `test_identifier_extraction.py`).

## Required Context

This step tests:
1. Queue polling methods use `job_id` (not `deliver_id`)
2. WebSocket correlation uses correct identifiers (`deliver_id` for `execute_async`, `job_id` for queue-based WebSocket)
3. Public API methods (`embed()`, `cmd()`) return correct identifier types
4. Identifier confusion scenarios fail appropriately (e.g., using `deliver_id` for queue operations)
5. JSON-RPC request IDs are not exposed in public API

## Read First

Before starting implementation, read these files:
- `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` - to understand `embed()`, `cmd()` method signatures
- `/home/vasilyvz/projects/embed-client/embed_client/async_client_queue_mixin.py` - to understand queue method signatures
- `/home/vasilyvz/projects/embed-client/embed_client/testing_client.py` - to understand `EmbeddingServiceClient` structure
- `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - to understand adapter transport method signatures
- `/home/vasilyvz/projects/embed-client/tests/test_queue_methods.py` - to understand test structure and mocking patterns
- `/home/vasilyvz/projects/embed-client/tests/test_async_client.py` - to understand async client testing patterns

## Expected File Change

**File:** `tests/test_identifier_separation.py`

**Action:** create new file

**File header docstring:**
```python
"""
Tests for identifier separation in queue polling, WebSocket correlation, and public API.

Verifies that job_id (queue operations) and deliver_id (execute_async operations)
are used correctly and not confused. Tests identifier confusion scenarios fail appropriately.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
```

## Complete Import List

```python
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from typing import Dict, Any
from embed_client.async_client_api_mixin import AsyncClientAPIMixin
from embed_client.async_client_queue_mixin import AsyncClientQueueMixin
from embed_client.testing_client import EmbeddingServiceClient
from embed_client.identifier_types import JobId, DeliverId
```

## Class/Function Skeleton

### Test Classes

**Class:** `TestQueuePollingIdentifiers`
- **Purpose:** Test queue polling methods use `job_id`
- **Methods:**
  - `test_job_status_uses_job_id(self)` -> None
  - `test_wait_for_job_uses_job_id(self)` -> None
  - `test_submit_job_returns_job_id(self)` -> None
  - `test_cancel_command_uses_job_id(self)` -> None

**Class:** `TestWebSocketCorrelationIdentifiers`
- **Purpose:** Test WebSocket correlation uses correct identifiers
- **Methods:**
  - `test_execute_async_uses_deliver_id(self)` -> None
  - `test_wait_for_job_via_websocket_uses_job_id(self)` -> None
  - `test_execute_async_deliver_id_distinct_from_job_id(self)` -> None

**Class:** `TestPublicAPIIdentifiers`
- **Purpose:** Test public API identifier behavior
- **Methods:**
  - `test_embed_wait_false_returns_job_id(self)` -> None
  - `test_embed_wait_true_use_push_true_uses_internal_deliver_id(self)` -> None
  - `test_embed_wait_true_use_push_false_uses_job_id(self)` -> None
  - `test_cmd_queued_returns_job_id(self)` -> None
  - `test_cmd_immediate_returns_no_identifier(self)` -> None

**Class:** `TestIdentifierConfusion`
- **Purpose:** Test that identifier confusion fails appropriately
- **Methods:**
  - `test_deliver_id_not_usable_for_queue_operations(self)` -> None
  - `test_job_id_not_usable_for_execute_async(self)` -> None
  - `test_jsonrpc_request_id_not_exposed(self)` -> None

## Method Logic - Step-by-Step Algorithm

### `TestQueuePollingIdentifiers.test_job_status_uses_job_id()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport` (or use `patch` to mock `_adapter_transport` attribute)
3. Set up mock: `mock_transport.queue_get_job_status = AsyncMock(return_value={"status": "completed", "result": {}})`
4. Create test `job_id`: `test_job_id = JobId("queue-123")`
5. Call client method: `await client.job_status(str(test_job_id))` (or `await client.job_status(test_job_id)` if method accepts `JobId`)
6. Assert `mock_transport.queue_get_job_status` was called exactly once
7. Assert `mock_transport.queue_get_job_status` was called with `job_id` argument equal to `"queue-123"` (or `test_job_id`)
8. Assert returned value contains expected status information

### `TestQueuePollingIdentifiers.test_wait_for_job_uses_job_id()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `queue_get_job_status`: first call returns `{"status": "pending"}`, second call returns `{"status": "completed", "result": {"data": {"embeddings": []}}}`
4. Create test `job_id`: `test_job_id = JobId("queue-456")`
5. Call client method: `await client.wait_for_job(str(test_job_id), timeout=1.0)`
6. Assert `mock_transport.queue_get_job_status` was called with `job_id` argument equal to `"queue-456"` (or `test_job_id`)
7. Assert returned value contains job result

### `TestQueuePollingIdentifiers.test_submit_job_returns_job_id()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `execute_command_unified` (or `jsonrpc_call`): return `{"mode": "queued", "job_id": "queue-789", "status": "pending"}`
4. Call client method: `result = await client.submit_job("embed", {"texts": ["test"]})`
5. Assert `result` is a dictionary
6. Assert `result.get("job_id")` equals `"queue-789"` (or `JobId("queue-789")`)
7. Assert `result.get("job_id")` is NOT a `deliver_id` (verify it's a `job_id` type, not `deliver_id` type)
8. Assert `result` does NOT contain `deliver_id` field

### `TestQueuePollingIdentifiers.test_cancel_command_uses_job_id()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `queue_stop_job`: return `{"stopped": True}`
4. Create test `job_id`: `test_job_id = JobId("queue-abc")`
5. Call client method: `await client.cancel_command(str(test_job_id))` (or find the actual cancel method name)
6. Assert `mock_transport.queue_stop_job` was called with `job_id` argument equal to `"queue-abc"` (or `test_job_id`)
7. If cancel method doesn't exist, skip this test or test via `queue_stop_job` directly

### `TestWebSocketCorrelationIdentifiers.test_execute_async_uses_deliver_id()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `execute_async`: return `{"accepted": True, "deliver_id": "deliver-xyz-123"}`
4. Create mock callback function: `mock_callback = MagicMock()`
5. Call client method: `result = await client._adapter_transport.execute_async("embed_execute", {"texts": ["test"]}, on_result=mock_callback, timeout=1.0)`
6. Assert `mock_transport.execute_async` was called exactly once
7. Assert `result.get("deliver_id")` equals `"deliver-xyz-123"` (or `DeliverId("deliver-xyz-123")`)
8. Assert `result.get("deliver_id")` is NOT a `job_id` (verify it's a `deliver_id` type, not `job_id` type)
9. Assert `result` does NOT contain `job_id` field (or if it does, it's different from `deliver_id`)

### `TestWebSocketCorrelationIdentifiers.test_wait_for_job_via_websocket_uses_job_id()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `wait_for_job_via_websocket`: return `{"event": "job_completed", "job_id": "queue-456", "result": {}}`
4. Create test `job_id`: `test_job_id = JobId("queue-456")`
5. Call client method: `result = await client.wait_for_job_via_websocket(str(test_job_id), timeout=1.0)`
6. Assert `mock_transport.wait_for_job_via_websocket` was called with `job_id` argument equal to `"queue-456"` (or `test_job_id`)
7. Assert returned value contains expected result

### `TestWebSocketCorrelationIdentifiers.test_execute_async_deliver_id_distinct_from_job_id()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `execute_async`: return `{"accepted": True, "deliver_id": "deliver-abc-789"}`
4. Set up mock for `submit_job` (via `execute_command_unified`): return `{"mode": "queued", "job_id": "queue-xyz-789", "status": "pending"}`
5. Call `execute_async`: `async_result = await client._adapter_transport.execute_async("embed_execute", {"texts": ["test"]}, on_result=MagicMock(), timeout=1.0)`
6. Call `submit_job`: `queue_result = await client.submit_job("embed", {"texts": ["test"]})`
7. Extract `deliver_id` from `async_result`: `deliver_id = async_result.get("deliver_id")`
8. Extract `job_id` from `queue_result`: `job_id = queue_result.get("job_id")`
9. Assert `deliver_id` is not equal to `job_id` (they are distinct identifiers)
10. Assert `deliver_id` is instance of `DeliverId` (or string that represents deliver_id)
11. Assert `job_id` is instance of `JobId` (or string that represents job_id)

### `TestPublicAPIIdentifiers.test_embed_wait_false_returns_job_id()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `execute_command_unified` (or method that `embed()` calls when `wait=False`): return `{"mode": "queued", "job_id": "queue-embed-123", "status": "pending"}`
4. Call client method: `result = await client.embed(["test text"], wait=False)`
5. Assert `result` is a dictionary
6. Assert `result.get("job_id")` equals `"queue-embed-123"` (or `JobId("queue-embed-123")`)
7. Assert `result.get("job_id")` is NOT `None`
8. Assert `result` does NOT contain `deliver_id` field

### `TestPublicAPIIdentifiers.test_embed_wait_true_use_push_true_uses_internal_deliver_id()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `execute_async`: return `{"accepted": True, "deliver_id": "deliver-embed-456"}`, and set up callback to be called with completion result
4. Set up mock callback to simulate WebSocket completion: when `execute_async` callback is invoked, it receives `{"event": "job_completed", "deliver_id": "deliver-embed-456", "result": {"embeddings": []}}`
5. Call client method: `result = await client.embed(["test text"], wait=True, use_push=True)`
6. Assert `mock_transport.execute_async` was called (verify `execute_async` is used, not queue polling)
7. Assert `result` contains embedding data (final result, not intermediate identifiers)
8. Assert `result` does NOT contain `deliver_id` field (internal identifier, not exposed)
9. Assert `result` does NOT contain `job_id` field (when using `execute_async`, no `job_id` should be exposed)

### `TestPublicAPIIdentifiers.test_embed_wait_true_use_push_false_uses_job_id()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `execute_command_unified`: first call returns `{"mode": "queued", "job_id": "queue-embed-789", "status": "pending"}`
4. Set up mock for `queue_get_job_status`: first call returns `{"status": "pending"}`, second call returns `{"status": "completed", "result": {"embeddings": []}}`
5. Call client method: `result = await client.embed(["test text"], wait=True, use_push=False)`
6. Assert `mock_transport.queue_get_job_status` was called with `job_id` argument equal to `"queue-embed-789"`
7. Assert `result` contains embedding data (final result)
8. Assert `result` does NOT contain `job_id` field in final result (internal identifier used for polling, not exposed in final result)
9. Verify that `queue_get_job_status` was called with the `job_id` from initial response

### `TestPublicAPIIdentifiers.test_cmd_queued_returns_job_id()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `execute_command_unified`: return `{"mode": "queued", "job_id": "queue-cmd-123", "status": "pending"}`
4. Call client method: `result = await client.cmd("embed_queue", {"texts": ["test"]}, wait=False)`
5. Assert `result` is a dictionary
6. Assert `result.get("job_id")` equals `"queue-cmd-123"` (or `JobId("queue-cmd-123")`)
7. Assert `result.get("job_id")` is NOT `None`

### `TestPublicAPIIdentifiers.test_cmd_immediate_returns_no_identifier()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `execute_command_unified`: return `{"mode": "immediate", "result": {"data": {"embeddings": []}}}`
4. Call client method: `result = await client.cmd("embed", {"texts": ["test"]}, wait=False)`
5. Assert `result` is a dictionary
6. Assert `result.get("job_id")` is `None` (immediate mode, no job_id)
7. Assert `result.get("deliver_id")` is `None` (immediate mode, no deliver_id)
8. Assert `result` contains result data (e.g., `result.get("result")` is not `None`)

### `TestIdentifierConfusion.test_deliver_id_not_usable_for_queue_operations()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `queue_get_job_status`: return `{"error": "Job not found"}` or raise exception when called with invalid `job_id`
4. Create test `deliver_id`: `test_deliver_id = DeliverId("deliver-confusion-123")`
5. Attempt to call queue operation with `deliver_id`: `result = await client.job_status(str(test_deliver_id))`
6. Assert `mock_transport.queue_get_job_status` was called with the `deliver_id` value (to verify it was attempted)
7. Assert result indicates error or "job not found" (identifier mismatch - `deliver_id` is not a valid `job_id` for queue operations)
8. Optionally, verify that using `deliver_id` for `wait_for_job()` also fails appropriately

### `TestIdentifierConfusion.test_job_id_not_usable_for_execute_async()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `execute_async`: return `{"accepted": True, "deliver_id": "deliver-new-456"}` (new deliver_id generated, not the job_id)
4. Create test `job_id`: `test_job_id = JobId("queue-confusion-456")`
5. Call `execute_async`: `result = await client._adapter_transport.execute_async("embed_execute", {"texts": ["test"]}, on_result=MagicMock(), timeout=1.0)`
6. Extract `deliver_id` from result: `deliver_id = result.get("deliver_id")`
7. Assert `deliver_id` is NOT equal to `str(test_job_id)` (execute_async generates new deliver_id, does not use job_id)
8. Assert `deliver_id` is instance of `DeliverId` (or string representing deliver_id)
9. Verify that `job_id` cannot be used to correlate `execute_async` results (they use different identifier systems)

### `TestIdentifierConfusion.test_jsonrpc_request_id_not_exposed()`
1. Create mock `AdapterTransport` instance: `mock_transport = MagicMock(spec=AdapterTransport)`
2. Create mock client instance that uses `mock_transport`
3. Set up mock for `jsonrpc_call` (or `execute_command_unified`): return response that might contain JSON-RPC `id` field internally
4. Call client method: `result = await client.embed(["test text"], wait=False)`
5. Assert `result` is a dictionary
6. Assert `result` does NOT contain `"id"` field (JSON-RPC request id is transport-internal, not exposed)
7. Assert `result` does NOT contain `"request_id"` field
8. Assert `result` does NOT contain `"jsonrpc_id"` field
9. Verify that only domain identifiers (`job_id`, `deliver_id`) are exposed, not transport identifiers

## Error Handling Per Method

**All test methods:**
- **Exceptions to catch:** None (tests should not catch exceptions, let pytest handle failures)
- **Mock setup:** Use `AsyncMock` for async methods, `MagicMock` for sync methods
- **Assertions:** Use `assert` statements with descriptive messages
- **Mock verification:** Use `assert_called_once()`, `assert_called_with()`, `call_count` to verify mock invocations

**Edge cases:**
- Missing identifier in response: test should verify behavior (return `None` or raise exception)
- Invalid identifier format: test should verify error handling
- Identifier confusion: test should verify that using wrong identifier type fails appropriately

## Return Value Specification

**All test methods:**
- Return type: `None` (test methods do not return values)
- Assertions verify expected behavior and mock invocations

## Edge Cases

**For queue polling tests:**
- Queue operation with `None` job_id (should fail or return error)
- Queue operation with empty string job_id (should fail or return error)
- Queue operation with non-existent job_id (should return "not found" or error)

**For WebSocket correlation tests:**
- `execute_async` with missing `deliver_id` in response (should handle gracefully)
- `wait_for_job_via_websocket` with non-existent `job_id` (should timeout or return error)
- WebSocket completion with mismatched identifier (should not match callback)

**For public API tests:**
- `embed()` with `wait=False` and immediate mode (no `job_id` returned)
- `embed()` with `wait=True` and `use_push=True` but WebSocket fails (should fallback or error)
- `cmd()` with invalid command (should return error, no identifiers)

**For identifier confusion tests:**
- Using `deliver_id` that looks like valid `job_id` format (should still fail)
- Using `job_id` that looks like valid `deliver_id` format (should still fail)
- JSON-RPC `id` field present in adapter response but not exposed (verify it's filtered out)

## Exact Validation Commands

After implementation, run these commands:

```bash
# Format code
black tests/test_identifier_separation.py
# Expected: "reformatted tests/test_identifier_separation.py" or "already well formatted"

# Lint code
flake8 tests/test_identifier_separation.py
# Expected: no output (exit code 0)

# Type check
mypy tests/test_identifier_separation.py
# Expected: "Success: no issues found" or acceptable type errors

# Run tests
pytest tests/test_identifier_separation.py -v
# Expected: all tests PASSED (all test functions should pass)
```

## Exact Test Expectations

**Test count:** 16 test functions total
- 4 tests in `TestQueuePollingIdentifiers`
- 3 tests in `TestWebSocketCorrelationIdentifiers`
- 5 tests in `TestPublicAPIIdentifiers`
- 3 tests in `TestIdentifierConfusion`

**All tests must pass** without requiring real server or network connections (unit tests only, use mocks).

## Forbidden Patterns

1. **DO NOT** create real network connections (use mocks exclusively)
2. **DO NOT** test adapter internals (test client behavior only)
3. **DO NOT** assume `job_id` and `deliver_id` are the same (test they are distinct)
4. **DO NOT** expose JSON-RPC request IDs in tests or test results
5. **DO NOT** create integration tests (this is unit test file)
6. **DO NOT** use `print()` for logging (use pytest's assertion messages)
7. **DO NOT** use bare `except:` clauses
8. **DO NOT** skip tests with `pytest.skip()` unless absolutely necessary
9. **DO NOT** test server implementation details (test client contract only)
10. **DO NOT** use real `EmbeddingServiceClient` instances without mocking transport layer

## Constants and Literals

**Test data constants:**
- `"queue-123"` - sample job_id value for queue polling tests
- `"queue-456"` - sample job_id value for wait_for_job tests
- `"queue-789"` - sample job_id value for submit_job tests
- `"queue-abc"` - sample job_id value for cancel tests
- `"queue-embed-123"` - sample job_id value for embed tests
- `"queue-embed-789"` - sample job_id value for embed wait tests
- `"queue-cmd-123"` - sample job_id value for cmd tests
- `"deliver-xyz-123"` - sample deliver_id value for execute_async tests
- `"deliver-abc-789"` - sample deliver_id value for distinct test
- `"deliver-embed-456"` - sample deliver_id value for embed push tests
- `"deliver-confusion-123"` - sample deliver_id value for confusion tests
- `"queue-confusion-456"` - sample job_id value for confusion tests
- `"embed_execute"` - command name for execute_async tests
- `"embed"` - command name for immediate mode tests
- `"embed_queue"` - command name for queued mode tests
- `["test text"]` - sample text input for embed tests
- `{"texts": ["test"]}` - sample params for command tests
- `{"status": "pending"}` - sample pending status response
- `{"status": "completed", "result": {"embeddings": []}}` - sample completed status response
- `{"mode": "queued", "job_id": "...", "status": "pending"}` - sample queued response
- `{"mode": "immediate", "result": {"data": {"embeddings": []}}}` - sample immediate response
- `{"accepted": True, "deliver_id": "..."}` - sample execute_async response
- `{"event": "job_completed", "deliver_id": "...", "result": {...}}` - sample WebSocket completion event
- `1.0` - timeout value in seconds for tests

**No magic numbers** (all test data is string/dict literals or constants).

## Mandatory Completion Condition

**All tests must pass** when running `pytest tests/test_identifier_separation.py -v`.

## Decision Rules

1. **If client method signature differs from expected:** Adjust test to match actual signature (e.g., if `embed()` takes different parameters)
2. **If mock setup requires different method names:** Use actual method names from `adapter_transport.py` (e.g., `execute_command_unified` vs `jsonrpc_call`)
3. **If identifier types are strings at runtime:** Test should verify string values and optionally type annotations, but focus on runtime behavior
4. **If `cancel_command()` method doesn't exist:** Skip that test or test via `queue_stop_job` directly if available
5. **If `use_push` parameter doesn't exist in `embed()`:** Adjust test to match actual `embed()` signature (may need to test via `execute_async` directly)

## Blackstops

**Stop and escalate if:**
- Required client methods do not exist (e.g., `embed()`, `cmd()`, `job_status()`, `wait_for_job()`)
- `AdapterTransport` methods do not exist (e.g., `execute_async()`, `queue_get_job_status()`, `wait_for_job_via_websocket()`)
- Identifier types (`JobId`, `DeliverId`) do not exist in `identifier_types.py`
- Client class structure differs significantly from expected (requires tactical task update)

## Handoff Package

**For coder_auto:**
- Target file: `tests/test_identifier_separation.py` (create new file)
- All imports listed above
- All test classes and methods with full signatures listed above
- Step-by-step algorithm for each test method
- Mock setup patterns and verification
- Edge cases and error handling specified
- Validation commands with expected output patterns
- Forbidden patterns list

**No code implementation** - only test structure, mocks, and assertions as specified above.
