Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Queue Polling Identifier Handling

## Goal

Update all queue polling methods to explicitly document `job_id` (queue-based identifier) usage and add `JobId` type hints. Ensure clear separation from `deliver_id` (adapter-managed WebSocket async delivery identifier).

## Parent Links

- **Tech spec:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- **Parent tactical task:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling.md`

## Atomic Steps Summary

**Total steps:** 3

**Dependency order:** All steps can execute in parallel (same dependency: identifier-extraction-and-type-separation task)

**Execution waves:** 1 wave (all steps parallel)

## Step Inventory

### Step 1: Update adapter_transport.queue_get_job_status()

**File:** `update-adapter-transport-queue-get-job-status.md`

**Target file:** `embed_client/adapter_transport.py`

**Method:** `queue_get_job_status()`

**Changes:**
- Add `JobId` import
- Update parameter type: `job_id: str` → `job_id: JobId`
- Update docstring to explicitly document `job_id` as queue-based identifier

**Dependencies:**
- `identifier-extraction-and-type-separation` task (provides `JobId` type)

**Can execute in parallel with:** Step 2, Step 3

---

### Step 2: Update async_client_queue_mixin Queue Polling Methods

**File:** `update-async-client-queue-mixin-methods.md`

**Target file:** `embed_client/async_client_queue_mixin.py`

**Methods:** 7 methods
- `wait_for_job()`
- `job_status()`
- `cancel_command()`
- `submit_job()`
- `get_job_status_or_result()`
- `list_queued_commands()`
- `get_job_logs()`

**Changes:**
- Add `JobId` import
- Update parameter types: `job_id: str` → `job_id: JobId` (for methods with `job_id` parameter)
- Update docstrings to explicitly document `job_id` as queue-based identifier
- For `submit_job()`: Document that returned `job_id` field is `JobId` type
- For `list_queued_commands()`: Document that returned jobs contain `job_id` fields (JobId type)

**Dependencies:**
- `identifier-extraction-and-type-separation` task (provides `JobId` type)

**Can execute in parallel with:** Step 1, Step 3

---

### Step 3: Update testing_client Queue Polling Methods

**File:** `update-testing-client-queue-methods.md`

**Target file:** `embed_client/testing_client.py`

**Methods:** 2 methods
- `wait_for_job()`
- `job_status()`

**Changes:**
- Add `JobId` import
- Update parameter types: `job_id: str` → `job_id: JobId`
- Update docstrings to explicitly document `job_id` as queue-based identifier

**Dependencies:**
- `identifier-extraction-and-type-separation` task (provides `JobId` type)

**Can execute in parallel with:** Step 1, Step 2

---

## Dependency Graph

```
identifier-extraction-and-type-separation (external dependency)
    │
    ├── Step 1: adapter_transport.queue_get_job_status()
    ├── Step 2: async_client_queue_mixin methods (7 methods)
    └── Step 3: testing_client methods (2 methods)
```

All three steps depend on the same external task and can execute in parallel once that dependency is satisfied.

## Validation Requirements

Each step must pass:
1. `black` formatting check
2. `flake8` linting check
3. `mypy` type checking
4. Docstring verification (explicit `job_id` documentation)

## Completion Criteria

All atomic steps are complete when:
1. All 3 target files have `JobId` import
2. All queue polling methods have `JobId` type hints
3. All queue polling methods have docstrings explicitly documenting `job_id` as queue-based identifier
4. All validation commands pass
5. No confusion between `job_id` and `deliver_id` in queue polling paths
