Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: WebSocket Correlation Identifier Handling

## Purpose

Update WebSocket waiting and correlation logic to explicitly preserve the distinction between `job_id` (queue-based operations) and `deliver_id` (adapter-managed `execute_async` operations). Ensure `execute_async` uses `deliver_id` for WebSocket correlation, while queue-based WebSocket waiting uses `job_id`. Document identifier semantics in method signatures and docstrings.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`

## Scope

**Included:**
- Updates to `execute_async()` wrapper to extract and preserve `deliver_id` from adapter response
- Updates to `wait_for_job_via_websocket()` to document it uses `job_id` (queue-based)
- Updates to `_embed_via_execute_async()` to use `deliver_id` semantics
- Updates to `wait_for_job_via_websocket()` in queue mixin to document `job_id` usage
- Documentation updates clarifying when to use `job_id` vs `deliver_id` for WebSocket operations

**Excluded:**
- Changes to adapter transport `execute_async()` delegation (adapter handles deliver_id internally)
- Changes to identifier extraction logic (separate tactical task)
- Changes to queue polling logic (separate tactical task)
- Test code (separate tactical task)

## Boundaries

**Must NOT touch:**
- `embed_client/adapter_transport.py:176-207` - `execute_async()` method signature (it delegates to adapter, which handles deliver_id internally)
- Adapter's internal WebSocket correlation logic (adapter manages deliver_id subscription internally)
- JSON-RPC request ID handling (transport-internal, not exposed)

## Dependencies

- **Depends on:** `identifier-extraction-and-type-separation` (needs `DeliverId` type and extraction function)

## Parallelization Note

This task can run in parallel with `queue-polling-identifier-handling` but must wait for `identifier-extraction-and-type-separation` to complete.

## Expected Outcome

1. `execute_async()` flow explicitly uses `deliver_id` for WebSocket correlation
2. `wait_for_job_via_websocket()` explicitly documents it uses `job_id` (queue-based)
3. Method docstrings clearly state which identifier type is used
4. No confusion between `job_id` and `deliver_id` in WebSocket correlation paths

## Correction Items

**Existing code to update:**
- `embed_client/adapter_transport.py:176-207` - `execute_async()` docstring must document that it uses `deliver_id` internally (adapter-managed)
- `embed_client/adapter_transport.py:369-391` - `wait_for_job_via_websocket()` docstring must explicitly state it uses `job_id` (queue-based), not `deliver_id`
- `embed_client/async_client_queue_mixin.py:209-247` - `wait_for_job_via_websocket()` docstring must explicitly state it uses `job_id` (queue-based)
- `embed_client/testing_client.py:357-403` - `_embed_via_execute_async()` must document that it uses `execute_async` which uses `deliver_id`, not `job_id`
- `embed_client/testing_client.py:423-453` - `wait_for_job_via_websocket()` docstring must explicitly state it uses `job_id` (queue-based)

## Questions/Escalation Rule

**Escalate to orchestrator if:**
- Adapter behavior changes and `deliver_id` and `job_id` are guaranteed to be equivalent (requires global decision)
- Server WebSocket push message format changes identifier semantics (requires global spec update)

## File Inventory

**Action: modify**
- **Path:** `embed_client/adapter_transport.py`
- **Purpose:** Update docstrings for `execute_async()` and `wait_for_job_via_websocket()` to document identifier types

**Action: modify**
- **Path:** `embed_client/async_client_queue_mixin.py`
- **Purpose:** Update `wait_for_job_via_websocket()` docstring to document `job_id` usage

**Action: modify**
- **Path:** `embed_client/testing_client.py`
- **Purpose:** Update `_embed_via_execute_async()` and `wait_for_job_via_websocket()` docstrings to document identifier types

## Class/Function Inventory

### `embed_client.adapter_transport` (modify)

**Functions to modify:**
- `execute_async(command: str, params: Optional[Dict[str, Any]] = None, *, on_result: Callable[[Dict[str, Any]], Any], timeout: float = 60.0) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses adapter-managed `deliver_id` for WebSocket correlation. The `deliver_id` is distinct from queue `job_id`. Returns server response containing `deliver_id` field."

- `wait_for_job_via_websocket(job_id: str, timeout: float = 60.0) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses `job_id` (queue-based identifier) for WebSocket subscription. This method is for queue operations only. For `execute_async` operations, use `execute_async()` with callback instead. The `job_id` parameter must be a queue job identifier, not a `deliver_id`."

**Imports to add:**
```python
from embed_client.identifier_types import JobId, DeliverId
```

### `embed_client.async_client_queue_mixin` (modify)

**Functions to modify:**
- `wait_for_job_via_websocket(job_id: str, timeout: float = 60.0) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses `job_id` (queue-based identifier) for WebSocket subscription. This method subscribes to WebSocket push events for a queued job. For adapter-managed `execute_async` operations, the adapter handles `deliver_id` correlation internally via `execute_async()` callback mechanism."

**Imports to add:**
```python
from embed_client.identifier_types import JobId
```

### `embed_client.testing_client` (modify)

**Functions to modify:**
- `_embed_via_execute_async(params: Dict[str, Any], timeout: int = 60) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses adapter `execute_async()` which manages `deliver_id` internally for WebSocket correlation. The `deliver_id` is distinct from queue `job_id`. This method does not expose `deliver_id` to the caller."

- `wait_for_job_via_websocket(job_id: str, timeout: int = 60) -> Dict[str, Any]` - Update docstring to explicitly state: "Uses `job_id` (queue-based identifier) for WebSocket subscription. This method is for queue operations only. The `job_id` parameter must be a queue job identifier obtained from queue submission, not a `deliver_id` from `execute_async`."

**Imports to add:**
```python
from embed_client.identifier_types import JobId, DeliverId
```

## Data Structures

**No new data structures needed.** This task only updates documentation and ensures identifier types are used correctly in type hints.

## Import Map

### `embed_client/adapter_transport.py` (additions)
```python
from embed_client.identifier_types import JobId, DeliverId
```

### `embed_client/async_client_queue_mixin.py` (additions)
```python
from embed_client.identifier_types import JobId
```

### `embed_client/testing_client.py` (additions)
```python
from embed_client.identifier_types import JobId, DeliverId
```

## Error Handling Map

**No error handling changes needed.** This task only updates documentation and type hints. Existing error handling remains unchanged.

## Config Dependency

**No config keys used in this task** (WebSocket correlation uses identifiers from responses, not configuration).

## Test Plan

**Test file:** `tests/test_websocket_identifier_separation.py` (to be created in separate tactical task)

**Test functions:**
- `test_execute_async_uses_deliver_id()` - Verify that `execute_async` response contains `deliver_id` and it's distinct from any `job_id`
- `test_wait_for_job_via_websocket_uses_job_id()` - Verify that `wait_for_job_via_websocket` uses `job_id` for subscription, not `deliver_id`
- `test_execute_async_deliver_id_not_usable_for_queue_wait()` - Verify that `deliver_id` from `execute_async` cannot be used with `wait_for_job_via_websocket`
- `test_queue_job_id_not_usable_for_execute_async()` - Verify that queue `job_id` is not used in `execute_async` flow

**Fixtures/mocks:** Mock adapter `execute_async()` and `wait_for_job_via_websocket()` responses

## Concrete Examples

### Example 1: execute_async uses deliver_id
**Scenario:** Client calls `execute_async("embed_execute", params, on_result=callback)`
**Adapter behavior:** Adapter generates `deliver_id`, subscribes WebSocket with `deliver_id`, sends RPC
**Response:** `{"accepted": True, "deliver_id": "deliver-abc-123"}`
**WebSocket correlation:** Server pushes event with `deliver_id` matching subscription
**Note:** `deliver_id` is distinct from any queue `job_id`

### Example 2: wait_for_job_via_websocket uses job_id
**Scenario:** Client calls `wait_for_job_via_websocket(job_id="queue-job-xyz")`
**Adapter behavior:** Adapter subscribes WebSocket with `job_id="queue-job-xyz"`
**Server behavior:** Server pushes event with `job_id="queue-job-xyz"` matching subscription
**Note:** This is for queue operations only, not for `execute_async` operations

### Example 3: Mixing identifiers fails
**Scenario:** Client gets `deliver_id="deliver-123"` from `execute_async`, then calls `wait_for_job_via_websocket(job_id="deliver-123")`
**Expected behavior:** WebSocket subscription with `job_id="deliver-123"` will not match server push events (which use `deliver_id` for execute_async operations)
**Result:** Timeout or no correlation (identifier mismatch)

## Algorithm/Logic Description

**No algorithm changes needed.** This task only updates documentation and type hints. The actual WebSocket correlation logic remains in the adapter layer.

### Documentation updates:

1. **`execute_async()` docstring:**
   - Add explicit statement: "Uses adapter-managed `deliver_id` for WebSocket correlation"
   - Add explicit statement: "The `deliver_id` is distinct from queue `job_id`"
   - Document that response contains `deliver_id` field

2. **`wait_for_job_via_websocket()` docstring:**
   - Add explicit statement: "Uses `job_id` (queue-based identifier) for WebSocket subscription"
   - Add explicit statement: "This method is for queue operations only"
   - Add explicit statement: "For `execute_async` operations, use `execute_async()` with callback instead"
   - Add explicit statement: "The `job_id` parameter must be a queue job identifier, not a `deliver_id`"

3. **Type hints:**
   - Update `wait_for_job_via_websocket(job_id: JobId, ...)` to use `JobId` type (after import)

## Forbidden Approaches

1. **DO NOT** use `job_id` for `execute_async` WebSocket correlation (use `deliver_id` via adapter)
2. **DO NOT** use `deliver_id` for queue-based `wait_for_job_via_websocket()` (use `job_id`)
3. **DO NOT** assume `deliver_id` and `job_id` are interchangeable (they are distinct identifier types)
4. **DO NOT** expose adapter's internal `deliver_id` management to public API (adapter handles it internally)
5. **DO NOT** change method signatures (only update docstrings and type hints)
