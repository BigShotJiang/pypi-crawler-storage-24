Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Update testing_client Queue Polling Methods Documentation and Type Hints

## Executor Role

**Executor:** `coder_auto`

**Execution directive:** Update `wait_for_job()` and `job_status()` methods in `embed_client/testing_client.py` to add explicit `job_id` documentation and `JobId` type hints.

## Parent Links

- **Tech spec:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- **Parent tactical task:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling.md`

## Step Scope

**Target file:** `embed_client/testing_client.py`

**Action:** modify

**Methods to update:**
1. `wait_for_job()` (lines 405-421)
2. `job_status()` (lines 471-501)

## Dependency Contract

**Depends on:**
- `identifier-extraction-and-type-separation` tactical task must be completed first (provides `JobId` type from `embed_client.identifier_types`)

**No dependencies on other atomic steps in this tactical task** (can be executed in parallel with other steps)

## Required Context

This step updates documentation and type hints only. Method implementations remain unchanged. The `JobId` type must be available from `embed_client.identifier_types` module (created by the identifier-extraction-and-type-separation task).

## Read First

Before starting, read these files:

1. `/home/vasilyvz/projects/embed-client/embed_client/testing_client.py` (full file to understand context, especially lines 405-501)
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` (identifier model section)
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling.md` (tactical task requirements)

## Expected File Change

**File:** `embed_client/testing_client.py`

### Changes:

1. **Add import** (at top of file, after existing imports):
   - Find the import section (typically after module docstring)
   - Add: `from embed_client.identifier_types import JobId`

2. **Update method signatures and docstrings:**

   **Method 1: `wait_for_job()` (line 405)**
   - Change signature: `job_id: str` → `job_id: JobId`
   - Replace docstring (lines 411-415) with:
   ```python
        """
        Wait for job completion by polling job_status.

        Uses `job_id` (queue-based identifier) for status polling. The `job_id` parameter
        must be a queue job identifier obtained from queue submission (e.g., from
        submit_job() or embed_queue response), not a `deliver_id` from `execute_async()`.

        This method polls job_status() repeatedly until completion. Returns embed result
        shape: results, model, dimension (optional device).

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission. This is distinct from `deliver_id` used by execute_async().
            timeout: Maximum time to wait in seconds. Default: 60.
            poll_interval: Time between status checks in seconds. Default: 1.0.

        Returns:
            Embed result dictionary with keys: results, model, dimension (optional device).

        Raises:
            EmbeddingServiceTimeoutError: If timeout is exceeded.
            EmbeddingServiceError: If job fails or status check fails.
        """
   ```

   **Method 2: `job_status()` (line 471)**
   - Change signature: `job_id: str` → `job_id: JobId`
   - Replace docstring (lines 472-474) with:
   ```python
        """
        Get job status (queue_get_job_status or embed_job_status).

        Uses `job_id` (queue-based identifier) for status lookup. The `job_id` parameter
        must be a queue job identifier obtained from queue submission (e.g., from
        submit_job() or embed_queue response), not a `deliver_id` from `execute_async()`.

        This method first attempts to use queue_get_job_status. If that is not available,
        it falls back to embed_job_status.

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission. This is distinct from `deliver_id` used by execute_async().

        Returns:
            Job status dictionary.

        Raises:
            EmbeddingServiceAPIError: If status check fails or job not found.
        """
   ```

## Forbidden Alternatives

1. **DO NOT** change the method implementation logic (only docstrings and type hints)
2. **DO NOT** use `deliver_id` or any WebSocket correlation identifier in these methods
3. **DO NOT** modify other methods in this file (e.g., `wait_for_job_via_websocket`, `open_bidirectional_ws_channel`)
4. **DO NOT** change exception handling behavior
5. **DO NOT** add validation logic for `job_id` format (type hint is sufficient)
6. **DO NOT** import `JobId` from anywhere other than `embed_client.identifier_types`
7. **DO NOT** modify the helper function `wait_for_job_poll()` if it exists (only update the wrapper method)

## Atomic Operations

1. **Add import statement:**
   - Location: Find import section at top of file (after module docstring, with other imports)
   - Add: `from embed_client.identifier_types import JobId`
   - Ensure it's placed logically with other `embed_client` imports

2. **Update `wait_for_job()` method:**
   - Location: Line 405
   - Change parameter type: `job_id: str` → `job_id: JobId`
   - Location: Lines 411-415
   - Replace entire docstring with new docstring (provided above)

3. **Update `job_status()` method:**
   - Location: Line 471
   - Change parameter type: `job_id: str` → `job_id: JobId`
   - Location: Lines 472-474
   - Replace entire docstring with new docstring (provided above)

## Expected Deliverables

After completion, the file must have:

1. Import statement: `from embed_client.identifier_types import JobId`
2. Both methods updated with:
   - Type hints: `job_id: str` parameters changed to `job_id: JobId`
   - Docstrings explicitly stating:
     - "Uses `job_id` (queue-based identifier)"
     - "Must be obtained from queue submission"
     - "Distinct from `deliver_id` used by `execute_async`"
3. No changes to method implementation bodies
4. No changes to other methods in the file

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Format check:**
   ```bash
   black embed_client/testing_client.py
   ```
   Expected: "reformatted" or "already well formatted" (exit code 0)

2. **Lint check:**
   ```bash
   flake8 embed_client/testing_client.py
   ```
   Expected: No output (exit code 0)

3. **Type check:**
   ```bash
   mypy embed_client/testing_client.py
   ```
   Expected: "Success: no issues found" (exit code 0)

4. **Import verification:**
   - Verify that `JobId` type exists in `embed_client/identifier_types.py` (created by identifier-extraction-and-type-separation task)
   - If `JobId` does not exist, this step cannot proceed - escalate to orchestrator_tactical

5. **Docstring verification:**
   - Verify both methods have updated docstrings that explicitly mention:
     - "Uses `job_id` (queue-based identifier)"
     - "distinct from `deliver_id`"
     - "Must be obtained from queue submission"

## Decision Rules

1. **If `JobId` type does not exist:** Stop execution and report that identifier-extraction-and-type-separation task must complete first
2. **If import fails:** Verify that `embed_client/identifier_types.py` exists and contains `JobId` type alias
3. **If type check fails:** Ensure `JobId` is properly defined as a type alias (e.g., `JobId = str` or `JobId = NewType("JobId", str)`)
4. **If docstring replacement fails:** Ensure exact line numbers match current file state (read file first to verify line numbers)
5. **If method calls helper function:** Verify that helper function (e.g., `wait_for_job_poll`) accepts `JobId` type (should work if `JobId` is a type alias for `str`)

## Edge Cases

1. **Docstring spans multiple lines:**
   - Replace entire existing docstring (from opening `"""` to closing `"""`) with new docstring
   - Preserve indentation (4 spaces for method docstrings)

2. **Method calls other methods with `job_id` parameter:**
   - Type checker will validate that `JobId` is compatible with called method signatures
   - If called methods also use `JobId` type (from other atomic steps), compatibility is guaranteed

3. **Method uses `job_id` in f-strings or logging:**
   - No changes needed - `JobId` type alias for `str` will work in string contexts

## Blackstops

**Stop execution and escalate if:**

1. `embed_client/identifier_types.py` does not exist (identifier-extraction-and-type-separation task not completed)
2. `JobId` type is not defined in `embed_client/identifier_types.py`
3. Method signature change causes type errors in callers (should not happen if `JobId` is a type alias for `str`, but verify)
4. Line numbers in this step do not match current file (file may have been modified - read file first to get current line numbers)
5. Helper function `wait_for_job_poll()` has incompatible type signature (should not happen, but verify)

## Handoff Package

**For coder_auto:**

- Target file: `embed_client/testing_client.py`
- Action: modify
- Exact import to add: `from embed_client.identifier_types import JobId`
- 2 methods to update with exact signature changes and docstring replacements (provided above)
- Validation commands (provided above)
- Dependency: Must verify `JobId` type exists before starting

**Completion condition:** All validation commands pass, both methods have updated docstrings explicitly documenting `job_id` as queue-based identifier, type hints use `JobId`.
