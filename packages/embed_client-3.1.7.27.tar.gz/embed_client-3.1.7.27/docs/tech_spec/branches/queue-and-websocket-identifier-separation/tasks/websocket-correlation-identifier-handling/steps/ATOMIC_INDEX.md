Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: WebSocket Correlation Identifier Handling

## Goal

Update docstrings and type hints in three files to explicitly document identifier types used by WebSocket correlation methods:
- `execute_async()` uses adapter-managed `deliver_id` (distinct from queue `job_id`)
- `wait_for_job_via_websocket()` uses `job_id` (queue-based identifier)

## Parent Links

- **Tech spec:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- **Parent tactical task:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/websocket-correlation-identifier-handling.md`

## Atomic Steps Summary

| Step ID | Target File | Methods Updated | Dependencies |
|---------|-------------|-----------------|--------------|
| `update-adapter-transport-docstrings` | `embed_client/adapter_transport.py` | `execute_async()`, `wait_for_job_via_websocket()` | `identifier-extraction-and-type-separation` |
| `update-queue-mixin-docstrings` | `embed_client/async_client_queue_mixin.py` | `wait_for_job_via_websocket()` | `identifier-extraction-and-type-separation` |
| `update-testing-client-docstrings` | `embed_client/testing_client.py` | `_embed_via_execute_async()`, `wait_for_job_via_websocket()` | `identifier-extraction-and-type-separation` |

## Dependency Order

**All three steps can execute in parallel** (they modify different files and have no dependencies on each other).

**External dependency:**
- All steps depend on `identifier-extraction-and-type-separation` tactical task providing `JobId` and `DeliverId` types from `embed_client.identifier_types` module.

**If types are not available:**
- Steps can still update docstrings (they don't require the types)
- Type hints may cause temporary mypy errors until types are created
- This is acceptable - types will be created by the identifier-extraction task

## Atomic Waves

See `ATOMIC_PARALLEL_WAVES.md` for parallel execution plan.

## Step Details

### Step 1: `update-adapter-transport-docstrings`

**File:** `embed_client/adapter_transport.py`

**Changes:**
- Add import: `from embed_client.identifier_types import JobId, DeliverId`
- Update `execute_async()` docstring to document `deliver_id` usage
- Update `wait_for_job_via_websocket()` docstring and type hint (`job_id: JobId`)

**Full path:** `steps/update-adapter-transport-docstrings.md`

### Step 2: `update-queue-mixin-docstrings`

**File:** `embed_client/async_client_queue_mixin.py`

**Changes:**
- Add import: `from embed_client.identifier_types import JobId`
- Update `wait_for_job_via_websocket()` docstring and type hint (`job_id: JobId`)

**Full path:** `steps/update-queue-mixin-docstrings.md`

### Step 3: `update-testing-client-docstrings`

**File:** `embed_client/testing_client.py`

**Changes:**
- Add import: `from embed_client.identifier_types import JobId, DeliverId`
- Update `_embed_via_execute_async()` docstring to document `deliver_id` usage
- Update `wait_for_job_via_websocket()` docstring and type hint (`job_id: JobId`)

**Full path:** `steps/update-testing-client-docstrings.md`

## Validation Requirements

Each step must pass:
- `black` (formatting)
- `flake8` (linting)
- `mypy` (type checking - may show import error if types don't exist yet, which is acceptable)
- `python -m py_compile` (syntax check)

## Completion Criteria

All three atomic steps must be completed:
- All docstrings updated with identifier semantics
- All type hints added using `JobId` and `DeliverId` types
- All validation commands pass
- No code logic changes (documentation-only task)
