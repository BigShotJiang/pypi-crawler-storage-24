Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Identifier-Focused Tests

## Purpose

Create comprehensive tests that verify identifier separation between `job_id` (queue operations), `deliver_id` (adapter-managed WebSocket async delivery), and JSON-RPC request IDs (transport-internal). Ensure tests cover immediate mode, queued mode, and WebSocket-assisted completion mode. Verify that identifier types are not confused or collapsed.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`

## Scope

**Included:**
- Tests for identifier extraction functions (`_extract_job_id_from_response`, `_extract_deliver_id_from_response`)
- Tests for identifier type separation (JobId vs DeliverId)
- Tests for queue polling using `job_id`
- Tests for WebSocket correlation using `deliver_id` (execute_async)
- Tests for WebSocket waiting using `job_id` (queue-based)
- Tests that verify identifier confusion fails (e.g., using `deliver_id` for queue operations)
- Tests for immediate mode (no identifiers returned)
- Tests for queued mode (job_id returned)
- Tests for WebSocket completion mode (deliver_id used internally)

**Excluded:**
- Integration tests with real server (separate step 4)
- Performance tests (out of scope)
- Security mode matrix tests (separate step 4)

## Boundaries

**Must NOT touch:**
- Production code (test code only)
- Adapter internals (mock adapter behavior)
- Server implementation (test client behavior only)

## Dependencies

- **Depends on:** All other tactical tasks (needs identifier extraction, WebSocket handling, queue polling, and documentation to be complete before testing)

## Parallelization Note

This task must run after all other tactical tasks complete (it tests their implementations).

## Expected Outcome

1. Comprehensive test coverage for identifier separation
2. Tests verify that `job_id` and `deliver_id` are distinct and not confused
3. Tests verify that JSON-RPC request IDs are not exposed
4. Tests cover all three completion modes (immediate, queued, WebSocket)
5. Tests verify identifier extraction functions work correctly

## Correction Items

**No existing test code to update** (new test file).

## Questions/Escalation Rule

**Escalate to orchestrator if:**
- Test requirements reveal architectural issues (requires global decision)
- Adapter behavior changes require test updates (requires coordination)

## File Inventory

**Action: create**
- **Path:** `tests/test_identifier_extraction.py`
- **Purpose:** Test identifier extraction functions and type separation

**Action: create**
- **Path:** `tests/test_identifier_separation.py`
- **Purpose:** Test identifier separation in queue polling, WebSocket correlation, and public API

## Class/Function Inventory

### `tests/test_identifier_extraction.py` (new file)

**Test classes:**
- `TestJobIdExtraction` - Test class for `_extract_job_id_from_response()`
- `TestDeliverIdExtraction` - Test class for `_extract_deliver_id_from_response()`
- `TestIdentifierTypes` - Test class for identifier type system

**Test functions:**
- `TestJobIdExtraction.test_extract_job_id_from_top_level()` - Test extraction from `result.get("job_id")`
- `TestJobIdExtraction.test_extract_job_id_from_nested_result()` - Test extraction from `result.get("result", {}).get("job_id")`
- `TestJobIdExtraction.test_extract_job_id_from_nested_data()` - Test extraction from `result.get("result", {}).get("data", {}).get("job_id")`
- `TestJobIdExtraction.test_extract_job_id_from_data()` - Test extraction from `result.get("data", {}).get("job_id")`
- `TestJobIdExtraction.test_extract_job_id_returns_none_when_missing()` - Test that extraction returns `None` when job_id not present
- `TestJobIdExtraction.test_extract_job_id_strips_whitespace()` - Test that extraction strips whitespace
- `TestJobIdExtraction.test_extract_job_id_returns_none_for_empty_string()` - Test that empty string returns `None`
- `TestDeliverIdExtraction.test_extract_deliver_id_from_top_level()` - Test extraction from `result.get("deliver_id")`
- `TestDeliverIdExtraction.test_extract_deliver_id_from_nested_result()` - Test extraction from `result.get("result", {}).get("deliver_id")`
- `TestDeliverIdExtraction.test_extract_deliver_id_from_nested_data()` - Test extraction from `result.get("result", {}).get("data", {}).get("deliver_id")`
- `TestDeliverIdExtraction.test_extract_deliver_id_from_data()` - Test extraction from `result.get("data", {}).get("deliver_id")`
- `TestDeliverIdExtraction.test_extract_deliver_id_returns_none_when_missing()` - Test that extraction returns `None` when deliver_id not present
- `TestDeliverIdExtraction.test_extract_deliver_id_strips_whitespace()` - Test that extraction strips whitespace
- `TestDeliverIdExtraction.test_extract_deliver_id_returns_none_for_empty_string()` - Test that empty string returns `None`
- `TestIdentifierTypes.test_job_id_type()` - Test that `JobId` type is distinct from `str`
- `TestIdentifierTypes.test_deliver_id_type()` - Test that `DeliverId` type is distinct from `str`
- `TestIdentifierTypes.test_job_id_and_deliver_id_are_distinct()` - Test that `JobId` and `DeliverId` are distinct types
- `TestIdentifierTypes.test_is_valid_job_id()` - Test validation function
- `TestIdentifierTypes.test_is_valid_deliver_id()` - Test validation function

**Imports needed:**
```python
import pytest
from typing import Dict, Any
from embed_client.async_client_api_mixin import (
    _extract_job_id_from_response,
    _extract_deliver_id_from_response,
)
from embed_client.identifier_types import (
    JobId,
    DeliverId,
    is_valid_job_id,
    is_valid_deliver_id,
)
```

### `tests/test_identifier_separation.py` (new file)

**Test classes:**
- `TestQueuePollingIdentifiers` - Test queue polling uses `job_id`
- `TestWebSocketCorrelationIdentifiers` - Test WebSocket correlation uses correct identifiers
- `TestPublicAPIIdentifiers` - Test public API identifier behavior
- `TestIdentifierConfusion` - Test that identifier confusion fails appropriately

**Test functions:**
- `TestQueuePollingIdentifiers.test_job_status_uses_job_id()` - Mock `queue_get_job_status()` and verify it's called with `job_id`
- `TestQueuePollingIdentifiers.test_wait_for_job_uses_job_id()` - Mock polling and verify `job_id` is used
- `TestQueuePollingIdentifiers.test_submit_job_returns_job_id()` - Verify `submit_job()` returns `job_id` (not `deliver_id`)
- `TestQueuePollingIdentifiers.test_cancel_command_uses_job_id()` - Verify `cancel_command()` uses `job_id`
- `TestWebSocketCorrelationIdentifiers.test_execute_async_uses_deliver_id()` - Mock `execute_async()` and verify response contains `deliver_id`
- `TestWebSocketCorrelationIdentifiers.test_wait_for_job_via_websocket_uses_job_id()` - Mock `wait_for_job_via_websocket()` and verify it's called with `job_id`
- `TestWebSocketCorrelationIdentifiers.test_execute_async_deliver_id_distinct_from_job_id()` - Verify `deliver_id` from `execute_async` is distinct from any `job_id`
- `TestPublicAPIIdentifiers.test_embed_wait_false_returns_job_id()` - Test that `embed(wait=False)` returns `job_id` when queued
- `TestPublicAPIIdentifiers.test_embed_wait_true_use_push_true_uses_internal_deliver_id()` - Test that `embed(wait=True, use_push=True)` uses internal `deliver_id` (not exposed)
- `TestPublicAPIIdentifiers.test_embed_wait_true_use_push_false_uses_job_id()` - Test that `embed(wait=True, use_push=False)` uses `job_id` for polling
- `TestPublicAPIIdentifiers.test_cmd_queued_returns_job_id()` - Test that `cmd()` with queued command returns `job_id` in result
- `TestPublicAPIIdentifiers.test_cmd_immediate_returns_no_identifier()` - Test that `cmd()` with immediate command returns no identifier
- `TestIdentifierConfusion.test_deliver_id_not_usable_for_queue_operations()` - Test that `deliver_id` cannot be used with `job_status()` or `wait_for_job()`
- `TestIdentifierConfusion.test_job_id_not_usable_for_execute_async()` - Test that queue `job_id` is not used in `execute_async` flow
- `TestIdentifierConfusion.test_jsonrpc_request_id_not_exposed()` - Test that JSON-RPC request IDs are not exposed in public API

**Imports needed:**
```python
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from typing import Dict, Any
from embed_client.async_client_api_mixin import AsyncClientAPIMixin
from embed_client.async_client_queue_mixin import AsyncClientQueueMixin
from embed_client.testing_client import EmbeddingServiceClient
from embed_client.identifier_types import JobId, DeliverId
```

## Data Structures

**Test fixtures:**
- `mock_adapter_transport` - Mock `AdapterTransport` for testing
- `mock_queue_response` - Sample queue response with `job_id`
- `mock_execute_async_response` - Sample `execute_async` response with `deliver_id`
- `mock_immediate_response` - Sample immediate response (no identifiers)

**No dataclasses, TypedDict, NamedTuple, or Pydantic models needed.**

## Import Map

### `tests/test_identifier_extraction.py`
```python
import pytest
from typing import Dict, Any
from embed_client.async_client_api_mixin import (
    _extract_job_id_from_response,
    _extract_deliver_id_from_response,
)
from embed_client.identifier_types import (
    JobId,
    DeliverId,
    is_valid_job_id,
    is_valid_deliver_id,
)
```

### `tests/test_identifier_separation.py`
```python
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from typing import Dict, Any
from embed_client.async_client_api_mixin import AsyncClientAPIMixin
from embed_client.async_client_queue_mixin import AsyncClientQueueMixin
from embed_client.testing_client import EmbeddingServiceClient
from embed_client.identifier_types import JobId, DeliverId
```

## Error Handling Map

**Test error scenarios:**
- Missing identifier returns `None` (not an error, expected behavior)
- Invalid identifier format (empty string, whitespace-only) returns `None`
- Identifier confusion (using `deliver_id` for queue operations) should fail or return error
- Type system prevents mixing `JobId` and `DeliverId` (type checker should catch)

## Config Dependency

**No config keys used in tests** (tests use mocks, not real configuration).

## Test Plan

**Test file:** `tests/test_identifier_extraction.py`
- Test identifier extraction functions with various response formats
- Test that extraction returns `None` when identifier missing
- Test that extraction strips whitespace
- Test identifier type system (JobId vs DeliverId)

**Test file:** `tests/test_identifier_separation.py`
- Test queue polling uses `job_id`
- Test WebSocket correlation uses correct identifiers (`deliver_id` for execute_async, `job_id` for queue)
- Test public API identifier behavior in different modes
- Test that identifier confusion fails appropriately

**Fixtures/mocks:**
- Mock `AdapterTransport` for testing client methods
- Mock adapter responses with `job_id` and `deliver_id`
- Mock WebSocket behavior for testing correlation

## Concrete Examples

### Example 1: Test job_id extraction from queue response
**Input:**
```python
result = {
    "mode": "queued",
    "job_id": "queue-123",
    "status": "pending"
}
```
**Expected output:** `JobId("queue-123")`
**Test:** `test_extract_job_id_from_top_level()`

### Example 2: Test deliver_id extraction from execute_async response
**Input:**
```python
result = {
    "accepted": True,
    "deliver_id": "deliver-abc-123"
}
```
**Expected output:** `DeliverId("deliver-abc-123")`
**Test:** `test_extract_deliver_id_from_top_level()`

### Example 3: Test identifier confusion fails
**Scenario:** Client gets `deliver_id="deliver-123"` from `execute_async`, then calls `job_status(job_id="deliver-123")`
**Expected behavior:** Mock adapter `queue_get_job_status()` should be called with `job_id="deliver-123"`, but server should return error or "job not found" (identifier mismatch)
**Test:** `test_deliver_id_not_usable_for_queue_operations()`

### Example 4: Test embed() with wait=False returns job_id
**Scenario:** Mock `execute_command_unified()` to return queued response with `job_id`
**Expected behavior:** `embed(wait=False)` should return `{"job_id": "queue-456", ...}`
**Test:** `test_embed_wait_false_returns_job_id()`

### Example 5: Test embed() with wait=True and use_push=True uses internal deliver_id
**Scenario:** Mock `execute_async()` to return response with `deliver_id`
**Expected behavior:** `embed(wait=True, use_push=True)` should use `execute_async()` which handles `deliver_id` internally (not exposed to caller)
**Test:** `test_embed_wait_true_use_push_true_uses_internal_deliver_id()`

## Algorithm/Logic Description

**Test implementation patterns:**

1. **Identifier extraction tests:**
   - Create test response dictionaries with identifiers in various locations
   - Call extraction function
   - Assert returned value matches expected identifier type
   - Test edge cases (missing, empty, whitespace)

2. **Identifier separation tests:**
   - Mock adapter transport methods
   - Call client methods with specific identifiers
   - Verify adapter methods are called with correct identifier types
   - Verify identifier confusion scenarios fail appropriately

3. **Public API identifier tests:**
   - Mock adapter responses for different modes (immediate, queued, WebSocket)
   - Call public API methods
   - Verify returned identifiers match expected types
   - Verify internal identifiers are not exposed

## Forbidden Approaches

1. **DO NOT** test adapter internals (test client behavior only)
2. **DO NOT** create real network connections (use mocks)
3. **DO NOT** assume `job_id` and `deliver_id` are the same (test they are distinct)
4. **DO NOT** expose JSON-RPC request IDs in tests (they're transport-internal)
5. **DO NOT** create tests that depend on server implementation details (test client contract only)
