Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Public API Identifier Documentation

## Goal

Update public client API method docstrings to explicitly document identifier semantics (`job_id` vs `deliver_id`, immediate vs queued vs WebSocket completion modes).

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/public-api-identifier-documentation.md`

## Atomic Steps

1. **step-01-update-embed-docstring-async-client-api-mixin.md** (target: `embed_client/async_client_api_mixin.py`)
   - Updates `embed()` method docstring (lines 314-398)
   - Adds "Identifier Semantics" section
   - Dependencies: none

2. **step-02-update-cmd-docstring-async-client-api-mixin.md** (target: `embed_client/async_client_api_mixin.py`)
   - Updates `cmd()` method docstring (lines 148-270)
   - Adds "Identifier Semantics" section
   - Dependencies: step-01 (same file, sequential to avoid conflicts)

3. **step-03-update-embed-docstring-testing-client.md** (target: `embed_client/testing_client.py`)
   - Updates `embed()` method docstring (lines 271-355)
   - Adds "Identifier Semantics" section
   - Dependencies: none (different file, can run in parallel with step-01)

## Execution Waves

**Wave 1 (parallel):**
- step-01-update-embed-docstring-async-client-api-mixin.md
- step-03-update-embed-docstring-testing-client.md

**Wave 2 (sequential after wave 1):**
- step-02-update-cmd-docstring-async-client-api-mixin.md

## Summary

- **Total steps:** 3
- **Files modified:** 2 (`embed_client/async_client_api_mixin.py`, `embed_client/testing_client.py`)
- **Methods updated:** 3 (`embed()` in async_client_api_mixin, `cmd()` in async_client_api_mixin, `embed()` in testing_client)
- **Type:** Documentation-only (docstring updates)
