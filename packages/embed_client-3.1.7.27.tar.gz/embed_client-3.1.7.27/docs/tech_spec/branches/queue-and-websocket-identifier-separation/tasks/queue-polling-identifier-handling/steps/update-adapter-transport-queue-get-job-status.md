Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Update adapter_transport.queue_get_job_status() Documentation and Type Hints

## Executor Role

**Executor:** `coder_auto`

**Execution directive:** Update the `queue_get_job_status()` method in `embed_client/adapter_transport.py` to add explicit `job_id` documentation and `JobId` type hint.

## Parent Links

- **Tech spec:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- **Parent tactical task:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling.md`

## Step Scope

**Target file:** `embed_client/adapter_transport.py`

**Action:** modify

**Method to update:** `queue_get_job_status()` (lines 274-300)

## Dependency Contract

**Depends on:**
- `identifier-extraction-and-type-separation` tactical task must be completed first (provides `JobId` type from `embed_client.identifier_types`)

**No dependencies on other atomic steps in this tactical task** (can be executed in parallel with other steps)

## Required Context

This step updates documentation and type hints only. The method implementation remains unchanged. The `JobId` type must be available from `embed_client.identifier_types` module (created by the identifier-extraction-and-type-separation task).

## Read First

Before starting, read these files:

1. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` (full file to understand context)
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` (identifier model section)
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling.md` (tactical task requirements)

## Expected File Change

**File:** `embed_client/adapter_transport.py`

**Changes:**

1. **Add import** (at top of file, after existing imports):
   ```python
   from embed_client.identifier_types import JobId
   ```

2. **Update method signature** (line 274):
   - Change: `async def queue_get_job_status(self, job_id: str) -> Dict[str, Any]:`
   - To: `async def queue_get_job_status(self, job_id: JobId) -> Dict[str, Any]:`

3. **Update docstring** (lines 275-290):
   - Replace the entire docstring with the following content that explicitly documents `job_id` usage:

```python
        """
        Get queue job status.

        Uses `job_id` (queue-based identifier) for status lookup. This method is for
        queue operations only. The `job_id` parameter must be a queue job identifier
        obtained from queue submission, not a `deliver_id` from `execute_async`.

        This method uses the standard queue_get_job_status endpoint. The embed_job_status
        command is handled internally by execute_command_unified for embed_queue commands.

        This method is called when job status is checked directly (e.g., via job_status()).
        Since we don't know which command created the job, we use the standard endpoint
        to avoid MethodNotFoundError in server logs for non-embed_queue jobs.

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission (e.g., from submit_job() or embed_queue response).
                   This is distinct from `deliver_id` used by execute_async().

        Returns:
            Job status dictionary in format expected by execute_command_unified

        Raises:
            (No changes to exception handling - existing exceptions remain unchanged)
        """
```

## Forbidden Alternatives

1. **DO NOT** change the method implementation logic (only docstring and type hint)
2. **DO NOT** use `deliver_id` or any WebSocket correlation identifier in this method
3. **DO NOT** modify other methods in this file
4. **DO NOT** change exception handling behavior
5. **DO NOT** add validation logic for `job_id` format (type hint is sufficient)
6. **DO NOT** import `JobId` from anywhere other than `embed_client.identifier_types`

## Atomic Operations

1. **Add import statement:**
   - Location: After line 21 (after `from embed_client.constants import DEFAULT_POLL_INTERVAL`)
   - Add: `from embed_client.identifier_types import JobId`

2. **Update method signature:**
   - Location: Line 274
   - Change parameter type from `job_id: str` to `job_id: JobId`

3. **Replace docstring:**
   - Location: Lines 275-290
   - Replace entire existing docstring with the new docstring that explicitly documents `job_id` as queue-based identifier

## Expected Deliverables

After completion, the file must have:

1. Import statement: `from embed_client.identifier_types import JobId`
2. Method signature: `async def queue_get_job_status(self, job_id: JobId) -> Dict[str, Any]:`
3. Updated docstring that explicitly states:
   - Uses `job_id` (queue-based identifier)
   - Must be obtained from queue submission
   - Distinct from `deliver_id` used by `execute_async`
4. No changes to method implementation body (lines 291-300 remain unchanged)

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Format check:**
   ```bash
   black embed_client/adapter_transport.py
   ```
   Expected: "reformatted" or "already well formatted" (exit code 0)

2. **Lint check:**
   ```bash
   flake8 embed_client/adapter_transport.py
   ```
   Expected: No output (exit code 0)

3. **Type check:**
   ```bash
   mypy embed_client/adapter_transport.py
   ```
   Expected: "Success: no issues found" (exit code 0)

4. **Import verification:**
   - Verify that `JobId` type exists in `embed_client/identifier_types.py` (created by identifier-extraction-and-type-separation task)
   - If `JobId` does not exist, this step cannot proceed - escalate to orchestrator_tactical

## Decision Rules

1. **If `JobId` type does not exist:** Stop execution and report that identifier-extraction-and-type-separation task must complete first
2. **If import fails:** Verify that `embed_client/identifier_types.py` exists and contains `JobId` type alias
3. **If type check fails:** Ensure `JobId` is properly defined as a type alias (e.g., `JobId = str` or `JobId = NewType("JobId", str)`)

## Blackstops

**Stop execution and escalate if:**

1. `embed_client/identifier_types.py` does not exist (identifier-extraction-and-type-separation task not completed)
2. `JobId` type is not defined in `embed_client/identifier_types.py`
3. Method signature change causes type errors in callers (should not happen if `JobId` is a type alias for `str`, but verify)

## Handoff Package

**For coder_auto:**

- Target file: `embed_client/adapter_transport.py`
- Action: modify
- Exact import to add: `from embed_client.identifier_types import JobId`
- Exact method signature change: `job_id: str` → `job_id: JobId`
- Exact docstring replacement (provided above)
- Validation commands (provided above)
- Dependency: Must verify `JobId` type exists before starting

**Completion condition:** All validation commands pass, docstring explicitly documents `job_id` as queue-based identifier, type hint uses `JobId`.
