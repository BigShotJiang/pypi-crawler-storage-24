Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Identifier Extraction And Type Separation

## Goal

Create type-safe identifier extraction functions that explicitly separate `job_id` (queue operations) and `deliver_id` (adapter-managed WebSocket async delivery). Ensure these identifiers are never confused or collapsed into each other.

## Atomic Steps Summary

**Total steps:** 3  
**Dependency order:** Sequential (Step 1 → Step 2 → Step 3)  
**Parallel waves:** 1 (all steps are sequential)

## Step List

### Step 1: Create Identifier Types Module
- **File:** `create-identifier-types-module.md`
- **Target file:** `embed_client/identifier_types.py`
- **Action:** create
- **Purpose:** Define `JobId` and `DeliverId` type aliases and validation functions
- **Dependencies:** None
- **Dependents:** Step 2, Step 3

### Step 2: Update API Mixin Extraction Functions
- **File:** `update-api-mixin-extraction-functions.md`
- **Target file:** `embed_client/async_client_api_mixin.py`
- **Action:** modify
- **Purpose:** Update `_extract_job_id_from_response()` to return `Optional[JobId]` and add `_extract_deliver_id_from_response()` function
- **Dependencies:** Step 1
- **Dependents:** Step 3

### Step 3: Update Queue Mixin Submit Job
- **File:** `update-queue-mixin-submit-job.md`
- **Target file:** `embed_client/async_client_queue_mixin.py`
- **Action:** modify
- **Purpose:** Update `submit_job()` to use `_extract_job_id_from_response()` instead of inline extraction
- **Dependencies:** Step 1, Step 2
- **Dependents:** None

## Execution Order

1. **Wave 1:** Step 1 (create identifier_types.py)
2. **Wave 2:** Step 2 (update api_mixin)
3. **Wave 3:** Step 3 (update queue_mixin)

## Files Created/Modified

**Created:**
- `embed_client/identifier_types.py`

**Modified:**
- `embed_client/async_client_api_mixin.py`
- `embed_client/async_client_queue_mixin.py`

## Validation Requirements

All steps must pass:
- `black` formatting check
- `flake8` linting check
- `mypy` type checking
- Import/function availability tests

## Completion Criteria

All atomic steps complete when:
1. `identifier_types.py` exists with `JobId`, `DeliverId` types and validation functions
2. `_extract_job_id_from_response()` returns `Optional[JobId]` with updated docstring
3. `_extract_deliver_id_from_response()` exists and returns `Optional[DeliverId]`
4. `submit_job()` uses `_extract_job_id_from_response()` instead of inline extraction
5. All validation commands pass for all modified files
