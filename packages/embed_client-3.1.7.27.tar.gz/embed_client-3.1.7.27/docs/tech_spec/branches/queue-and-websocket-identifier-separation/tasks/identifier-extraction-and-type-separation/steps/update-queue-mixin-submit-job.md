Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Update Queue Mixin Submit Job

## Executor Role

**Executor:** `coder_auto`

## Execution Directive

Update `embed_client/async_client_queue_mixin.py` method `submit_job()` to use `_extract_job_id_from_response()` function from `async_client_api_mixin` module instead of inline job_id extraction logic. Import the function and use it to extract job_id. Ensure the extracted value is treated as `JobId` type.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation.md`

## Step Scope

**Target file:** `embed_client/async_client_queue_mixin.py`  
**Action:** modify

## Dependency Contract

**Dependencies:**
- `embed_client/async_client_api_mixin.py` (must have updated `_extract_job_id_from_response()` that returns `Optional[JobId]`)
- `embed_client/identifier_types.py` (must exist with `JobId` type)

**Dependents:** None (this is a leaf change)

## Required Context

The `submit_job()` method (lines 319-374) currently has inline job_id extraction logic at lines 352-357:
```python
job_id = (
    result.get("job_id")
    or result.get("result", {}).get("job_id")
    or result.get("result", {}).get("data", {}).get("job_id")
    or result.get("data", {}).get("job_id")
)
```

This inline logic must be replaced with a call to `_extract_job_id_from_response(result)`. The function `_extract_job_id_from_response()` is a module-level function in `async_client_api_mixin.py` (not a method), so it must be imported at the top of the file.

The extracted `job_id` will be of type `Optional[JobId]`, but since it's used as a string in the return dictionary, it can be used directly (JobId is a NewType of str, so it's compatible with str operations).

## Read First

- `/home/vasilyvz/projects/embed-client/embed_client/async_client_queue_mixin.py` (current implementation, especially lines 319-374)
- `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` (to verify `_extract_job_id_from_response()` signature)
- `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` (to verify mixin inheritance order)
- `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation.md` (correction items section)

## Expected File Change

**Modify method:** `submit_job()` (lines 319-374)

**Change location:** Lines 352-357 (inline job_id extraction)

**Replace this code:**
```python
# Extract job_id from result
job_id = (
    result.get("job_id")
    or result.get("result", {}).get("job_id")
    or result.get("result", {}).get("data", {}).get("job_id")
    or result.get("data", {}).get("job_id")
)
```

**With this code:**
```python
# Extract job_id from result using queue-specific extraction function
job_id = _extract_job_id_from_response(result)
```

**Import needed:** Add import at top of file (after line 26, with other imports):
```python
from embed_client.async_client_api_mixin import _extract_job_id_from_response
```

The function `_extract_job_id_from_response()` is a module-level function (not a method), so it must be imported. This import is safe (no circular dependency) because `async_client_api_mixin.py` does not import from `async_client_queue_mixin.py`.

**Type handling:** The `job_id` variable will be of type `Optional[JobId]`, but since `JobId` is a `NewType("JobId", str)`, it can be used directly in string contexts (e.g., in dictionary values, string comparisons). The existing code that uses `job_id` does not need to change because:
- `JobId` instances are compatible with `str` operations
- The `if job_id:` check works the same (JobId is truthy if non-None)
- Dictionary assignment `"job_id": job_id` works (JobId is accepted where str is expected)

## Forbidden Alternatives

- **DO NOT** try to access `_extract_job_id_from_response` via `self.` (it's a module-level function, not a method)
- **DO NOT** change the return dictionary structure (keep `"job_id": job_id` as-is)
- **DO NOT** modify any other methods in this file
- **DO NOT** add type annotations to `job_id` variable (type inference will handle it, or add `Optional[JobId]` if needed for clarity)
- **DO NOT** change the logic that handles `None` job_id (existing `if job_id:` check is correct)
- **DO NOT** convert `JobId` to `str` explicitly (not needed, JobId is compatible with str)

## Atomic Operations

### Import Addition

**Location:** Top of file, after line 26 (with other imports)

**Add import:**
```python
from embed_client.async_client_api_mixin import _extract_job_id_from_response
```

**Note:** This import is safe because `async_client_api_mixin.py` does not import from `async_client_queue_mixin.py`, so there is no circular dependency.

### Method: `submit_job()` (Modify)

**Current location:** Lines 319-374

**Method signature:** (unchanged)
```python
async def submit_job(
    self,
    command: str,
    params: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
```

**Change location:** Inside the method, after line 349 (after `execute_command_unified` call), replace lines 352-357

**Before (lines 351-357):**
```python
# Extract job_id from result
job_id = (
    result.get("job_id")
    or result.get("result", {}).get("job_id")
    or result.get("result", {}).get("data", {}).get("job_id")
    or result.get("data", {}).get("job_id")
)
```

**After:**
```python
# Extract job_id from result using queue-specific extraction function
job_id = _extract_job_id_from_response(result)
```

**Algorithm:**
1. Call `_extract_job_id_from_response(result)` (function is imported at module level)
2. Assign result to `job_id` variable
3. Rest of method logic unchanged:
   - If `job_id` is truthy (not None), return dict with `job_id`, `status`, `mode: "queued"`
   - If `job_id` is None/falsy, return dict with `job_id: None`, `status: "completed"`, `mode: "immediate"`, `result: result.get("result", result)`

**Edge cases:**
- `result` is `None` → `_extract_job_id_from_response(None)` returns `None`, method returns immediate result dict
- `result` is not a dict → `_extract_job_id_from_response()` returns `None`, method returns immediate result dict
- `result` has no `job_id` → `_extract_job_id_from_response()` returns `None`, method returns immediate result dict
- `result` has valid `job_id` → `_extract_job_id_from_response()` returns `JobId("abc123")`, method returns queued result dict with `job_id: JobId("abc123")`

**Error handling:**
- No changes to error handling (existing try/except at method level is preserved)
- `_extract_job_id_from_response()` never raises exceptions (returns `None` for invalid input)
- Existing `if job_id:` check handles `None` case correctly

**Return value:**
- Return type unchanged: `Dict[str, Any]`
- Return structure unchanged: `{"job_id": job_id, "status": ..., "mode": ...}` or `{"job_id": None, "status": "completed", "mode": "immediate", "result": ...}`
- The `job_id` value in return dict will be `JobId` type (compatible with str, so no conversion needed)

## Expected Deliverables

1. `submit_job()` method uses `_extract_job_id_from_response(result)` instead of inline extraction
2. Inline extraction code (lines 352-357) is removed
3. Method behavior is unchanged (same return values for same inputs)
4. File passes black, flake8, and mypy validation
5. No new imports added (function available via mixin inheritance)

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Format check:**
   ```bash
   black embed_client/async_client_queue_mixin.py
   ```
   **Expected:** "reformatted embed_client/async_client_queue_mixin.py" or "All done! ✨ 🍰 ✨" or "would reformat" (if check-only mode)

2. **Lint check:**
   ```bash
   flake8 embed_client/async_client_queue_mixin.py
   ```
   **Expected:** No output (exit code 0)

3. **Type check:**
   ```bash
   mypy embed_client/async_client_queue_mixin.py
   ```
   **Expected:** "Success: no issues found in 1 source file" (or existing type errors if any, but no NEW errors from this change)

4. **Verify mixin inheritance:**
   ```bash
   python3 -c "from embed_client.async_client import EmbeddingServiceAsyncClient; import inspect; mro = inspect.getmro(EmbeddingServiceAsyncClient); print('APIMixin in MRO:', any('APIMixin' in str(c) for c in mro))"
   ```
   **Expected:** "APIMixin in MRO: True" (verifies mixin inheritance)

5. **Verify method availability:**
   ```bash
   python3 -c "from embed_client.async_client_api_mixin import _extract_job_id_from_response; print('Function available:', callable(_extract_job_id_from_response))"
   ```
   **Expected:** "Function available: True"

## Decision Rules

- `_extract_job_id_from_response()` is a module-level function (not a method), so it must be imported
- Import at top of file: `from embed_client.async_client_api_mixin import _extract_job_id_from_response`
- Call the function directly: `_extract_job_id_from_response(result)` (no `self.` prefix)
- Import is safe (no circular dependency) because `async_client_api_mixin.py` does not import from `async_client_queue_mixin.py`
- The function returns `Optional[JobId]`, which is compatible with string operations (JobId is NewType of str)

## Blackstops

**STOP and escalate if:**
- `_extract_job_id_from_response()` is not available as a module-level function (check actual implementation)
- Circular import error occurs when importing from `async_client_api_mixin`
- Mixin inheritance structure is different than expected (check `async_client.py` to verify mixin order)

## Handoff Package

**File to modify:** `embed_client/async_client_queue_mixin.py`

**Changes to make:**
1. **Add import** at top of file (after line 26, with other imports):
   ```python
   from embed_client.async_client_api_mixin import _extract_job_id_from_response
   ```
2. **Replace lines 351-357** in `submit_job()` method:
   - Remove inline extraction code
   - Replace with: `job_id = _extract_job_id_from_response(result)`
   - Update comment to: `# Extract job_id from result using queue-specific extraction function`

**Validation commands to run:**
- `black embed_client/async_client_queue_mixin.py`
- `flake8 embed_client/async_client_queue_mixin.py`
- `mypy embed_client/async_client_queue_mixin.py`
- Mixin inheritance and method availability tests (see Mandatory Validation section)

**Completion condition:** All validation commands pass, inline extraction replaced with function call, method behavior unchanged.
