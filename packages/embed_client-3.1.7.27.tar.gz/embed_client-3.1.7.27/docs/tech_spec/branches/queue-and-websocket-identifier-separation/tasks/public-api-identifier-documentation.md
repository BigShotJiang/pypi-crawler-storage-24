Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Public API Identifier Documentation

## Purpose

Update public client API methods to explicitly document identifier semantics. Ensure public methods that accept or return identifiers clearly document whether they use `job_id` (queue-based) or `deliver_id` (adapter-managed WebSocket async delivery). Update high-level embed methods to document identifier behavior in immediate vs queued vs WebSocket completion modes.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`

## Scope

**Included:**
- Updates to `embed()` method docstrings to document identifier behavior
- Updates to `cmd()` method docstrings to document identifier behavior
- Updates to public wait methods to document identifier semantics
- Updates to public job management methods to document identifier semantics
- Documentation of identifier behavior in immediate vs queued vs WebSocket completion modes

**Excluded:**
- Changes to method implementations (only documentation updates)
- Changes to identifier extraction logic (separate tactical task)
- Test code (separate tactical task)

## Boundaries

**Must NOT touch:**
- Method signatures (only docstring updates)
- Implementation logic (only documentation)
- Adapter transport layer (adapter handles identifiers internally)

## Dependencies

- **Depends on:** `identifier-extraction-and-type-separation` (needs identifier type definitions for documentation)

## Parallelization Note

This task can run in parallel with other documentation-only tasks but should complete after identifier extraction and type separation is done.

## Expected Outcome

1. Public API methods clearly document identifier semantics
2. Users understand when to use `job_id` vs when identifiers are handled internally
3. Documentation explains identifier behavior in different completion modes (immediate, queued, WebSocket)

## Correction Items

**Existing code to update:**
- `embed_client/async_client_api_mixin.py:314-398` - `embed()` method docstring must document identifier behavior in immediate vs queued vs WebSocket modes
- `embed_client/async_client_api_mixin.py:148-270` - `cmd()` method docstring must document identifier behavior
- `embed_client/testing_client.py:271-355` - `embed()` method docstring must document identifier behavior

## Questions/Escalation Rule

**Escalate to orchestrator if:**
- Public API contract changes require identifier exposure (requires global decision)
- Documentation requirements conflict with adapter behavior (requires global coordination)

## File Inventory

**Action: modify**
- **Path:** `embed_client/async_client_api_mixin.py`
- **Purpose:** Update `embed()` and `cmd()` docstrings to document identifier semantics

**Action: modify**
- **Path:** `embed_client/testing_client.py`
- **Purpose:** Update `embed()` docstring to document identifier semantics

## Class/Function Inventory

### `embed_client.async_client_api_mixin` (modify)

**Functions to modify:**
- `embed(texts: List[str], *, model: Optional[str] = None, dimension: Optional[int] = None, error_policy: Optional[str] = None, device: Optional[str] = None, job_id: Optional[str] = None, timeout: Optional[float] = None, wait: bool = True, use_push: bool = True, poll_interval: float = 0.3, ...) -> Dict[str, Any]` - Update docstring to add section: "Identifier Semantics: When `wait=False`, this method returns a `job_id` (queue-based identifier) if the operation was queued. When `wait=True` and `use_push=True`, the method uses adapter-managed WebSocket delivery with internal `deliver_id` correlation (not exposed to caller). When `wait=True` and `use_push=False`, the method uses `job_id` for HTTP polling. The `job_id` parameter (if provided) is a queue job identifier suggestion; the server may generate its own `job_id`."

- `cmd(command: str, params: Optional[Dict[str, Any]] = None, base_url: Optional[str] = None, port: Optional[int] = None, validate_texts: bool = True) -> Dict[str, Any]` - Update docstring to add section: "Identifier Semantics: For queued commands, the response may contain a `job_id` (queue-based identifier) in the result. For immediate commands, no identifier is returned. JSON-RPC request IDs are transport-internal and not exposed."

**Imports:** No new imports needed (documentation only)

### `embed_client.testing_client` (modify)

**Functions to modify:**
- `embed(texts: List[str], model: Optional[str] = None, dimension: Optional[int] = None, job_id: Optional[str] = None, error_policy: Optional[str] = None, device: Optional[str] = None, wait: bool = False, wait_timeout: int = 60, poll_interval: float = 1.0, use_push: bool = True) -> Dict[str, Any]` - Update docstring to add section: "Identifier Semantics: When `wait=False`, this method returns a `job_id` (queue-based identifier) if the operation was queued. When `wait=True`, the method uses adapter `execute_async()` which manages `deliver_id` internally for WebSocket correlation (not exposed to caller). The `job_id` parameter (if provided) is a queue job identifier suggestion; the server may generate its own `job_id`."

**Imports:** No new imports needed (documentation only)

## Data Structures

**No new data structures needed.** This task only updates documentation.

## Import Map

**No new imports needed.** This task only updates docstrings.

## Error Handling Map

**No error handling changes needed.** This task only updates documentation.

## Config Dependency

**No config keys used in this task** (documentation only).

## Test Plan

**Test file:** Documentation verification (no code tests needed, but docstring content should be verified)

**Verification:**
- Docstrings contain identifier semantics sections
- Identifier terminology is consistent (`job_id` for queue, `deliver_id` for execute_async)
- Documentation explains when identifiers are exposed vs internal

## Concrete Examples

### Example 1: embed() with wait=False returns job_id
**Scenario:** Client calls `embed(texts=["hello"], wait=False)`
**Server response:** `{"mode": "queued", "job_id": "queue-123", "status": "pending"}`
**Client return:** `{"job_id": "queue-123", "status": "pending", "message": "Job queued successfully"}`
**Documentation note:** Returned `job_id` is queue-based identifier, can be used with `job_status()` or `wait_for_job()`

### Example 2: embed() with wait=True and use_push=True uses internal deliver_id
**Scenario:** Client calls `embed(texts=["hello"], wait=True, use_push=True)`
**Client behavior:** Calls `execute_async()` which uses adapter-managed `deliver_id` internally
**WebSocket correlation:** Adapter handles `deliver_id` subscription and correlation internally
**Client return:** `{"results": [...], "model": "...", "dimension": 384}`
**Documentation note:** `deliver_id` is not exposed to caller; WebSocket correlation is handled internally by adapter

### Example 3: embed() with wait=True and use_push=False uses job_id for polling
**Scenario:** Client calls `embed(texts=["hello"], wait=True, use_push=False)`
**Client behavior:** Extracts `job_id` from response, then polls `job_status(job_id)` via HTTP
**Client return:** `{"results": [...], "model": "...", "dimension": 384}`
**Documentation note:** Uses `job_id` (queue-based identifier) for HTTP polling

### Example 4: cmd() with queued command returns job_id in result
**Scenario:** Client calls `cmd("embed_queue", params)`
**Server response:** `{"mode": "queued", "job_id": "queue-456", "status": "pending"}`
**Client return:** `{"result": {"job_id": "queue-456", "status": "pending", ...}}`
**Documentation note:** `job_id` is queue-based identifier, can be used with queue management methods

## Algorithm/Logic Description

**No algorithm changes needed.** This task only updates docstrings.

### Documentation updates:

1. **`embed()` method docstring additions:**
   - Add "Identifier Semantics" section explaining:
     - When `wait=False`: returns `job_id` (queue-based) if queued
     - When `wait=True` and `use_push=True`: uses internal `deliver_id` (not exposed)
     - When `wait=True` and `use_push=False`: uses `job_id` for HTTP polling
     - `job_id` parameter is a suggestion; server may generate its own

2. **`cmd()` method docstring additions:**
   - Add "Identifier Semantics" section explaining:
     - Queued commands may return `job_id` in result
     - Immediate commands return no identifier
     - JSON-RPC request IDs are transport-internal (not exposed)

3. **Consistent terminology:**
   - Use "queue-based identifier" for `job_id`
   - Use "adapter-managed WebSocket delivery identifier" or "internal deliver_id" for `deliver_id`
   - Use "transport-internal" for JSON-RPC request IDs

## Forbidden Approaches

1. **DO NOT** expose `deliver_id` in public API (it's adapter-managed and internal)
2. **DO NOT** expose JSON-RPC request IDs in public API (they're transport-internal)
3. **DO NOT** change method signatures (only update docstrings)
4. **DO NOT** assume `job_id` and `deliver_id` are the same (document them as distinct)
5. **DO NOT** create confusion about when identifiers are exposed vs internal (be explicit)
