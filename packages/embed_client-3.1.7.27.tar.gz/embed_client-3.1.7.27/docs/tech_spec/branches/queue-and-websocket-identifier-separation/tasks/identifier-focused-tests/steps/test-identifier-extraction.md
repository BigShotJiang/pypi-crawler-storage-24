Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Test Identifier Extraction Functions

## Executor Role

**Executor:** `coder_auto`

**Execution directive:** Create comprehensive test file for identifier extraction functions and type system. Test all extraction paths, edge cases, and type validation.

## Parent Links

- **Tech spec:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- **Parent tactical task:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-focused-tests.md`

## Step Scope

**Target file:** `tests/test_identifier_extraction.py`

**Action:** create

**Purpose:** Test identifier extraction functions (`_extract_job_id_from_response`, `_extract_deliver_id_from_response`) and identifier type system (`JobId`, `DeliverId`, validation functions).

## Dependency Contract

**Depends on:**
- `embed_client/async_client_api_mixin.py` must contain `_extract_job_id_from_response()` and `_extract_deliver_id_from_response()` functions
- `embed_client/identifier_types.py` must contain `JobId`, `DeliverId`, `is_valid_job_id()`, `is_valid_deliver_id()` definitions

**No dependencies on other test files** (this is the first identifier-focused test file).

## Required Context

This step tests:
1. Extraction of `job_id` from various response dictionary structures (top-level, nested in `result`, nested in `result.data`, nested in `data`)
2. Extraction of `deliver_id` from various response dictionary structures (same locations as `job_id`)
3. Edge cases: missing identifiers, empty strings, whitespace-only strings
4. Type system: `JobId` and `DeliverId` are distinct types, validation functions work correctly

## Read First

Before starting implementation, read these files:
- `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` - to understand extraction function signatures and behavior
- `/home/vasilyvz/projects/embed-client/embed_client/identifier_types.py` - to understand type definitions and validation functions
- `/home/vasilyvz/projects/embed-client/tests/test_queue_methods.py` - to understand test structure and patterns used in this project

## Expected File Change

**File:** `tests/test_identifier_extraction.py`

**Action:** create new file

**File header docstring:**
```python
"""
Tests for identifier extraction functions and type system.

Tests extraction of job_id and deliver_id from various response formats,
edge cases (missing, empty, whitespace), and identifier type validation.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
```

## Complete Import List

```python
import pytest
from typing import Dict, Any
from embed_client.async_client_api_mixin import (
    _extract_job_id_from_response,
    _extract_deliver_id_from_response,
)
from embed_client.identifier_types import (
    JobId,
    DeliverId,
    is_valid_job_id,
    is_valid_deliver_id,
)
```

## Class/Function Skeleton

### Test Classes

**Class:** `TestJobIdExtraction`
- **Purpose:** Test `_extract_job_id_from_response()` function
- **Methods:**
  - `test_extract_job_id_from_top_level(self)` -> None
  - `test_extract_job_id_from_nested_result(self)` -> None
  - `test_extract_job_id_from_nested_data(self)` -> None
  - `test_extract_job_id_from_data(self)` -> None
  - `test_extract_job_id_returns_none_when_missing(self)` -> None
  - `test_extract_job_id_strips_whitespace(self)` -> None
  - `test_extract_job_id_returns_none_for_empty_string(self)` -> None

**Class:** `TestDeliverIdExtraction`
- **Purpose:** Test `_extract_deliver_id_from_response()` function
- **Methods:**
  - `test_extract_deliver_id_from_top_level(self)` -> None
  - `test_extract_deliver_id_from_nested_result(self)` -> None
  - `test_extract_deliver_id_from_nested_data(self)` -> None
  - `test_extract_deliver_id_from_data(self)` -> None
  - `test_extract_deliver_id_returns_none_when_missing(self)` -> None
  - `test_extract_deliver_id_strips_whitespace(self)` -> None
  - `test_extract_deliver_id_returns_none_for_empty_string(self)` -> None

**Class:** `TestIdentifierTypes`
- **Purpose:** Test identifier type system and validation functions
- **Methods:**
  - `test_job_id_type(self)` -> None
  - `test_deliver_id_type(self)` -> None
  - `test_job_id_and_deliver_id_are_distinct(self)` -> None
  - `test_is_valid_job_id(self)` -> None
  - `test_is_valid_deliver_id(self)` -> None

## Method Logic - Step-by-Step Algorithm

### `TestJobIdExtraction.test_extract_job_id_from_top_level()`
1. Create test response dictionary: `{"job_id": "queue-123", "status": "pending"}`
2. Call `_extract_job_id_from_response(result)`
3. Assert returned value is not `None`
4. Assert returned value equals `JobId("queue-123")` (or string "queue-123" if function returns str)
5. Assert returned value is instance of `JobId` (or `str` if function returns str)

### `TestJobIdExtraction.test_extract_job_id_from_nested_result()`
1. Create test response dictionary: `{"result": {"job_id": "queue-456"}, "mode": "queued"}`
2. Call `_extract_job_id_from_response(result)`
3. Assert returned value is not `None`
4. Assert returned value equals `JobId("queue-456")` (or string "queue-456")
5. Assert returned value is instance of `JobId` (or `str`)

### `TestJobIdExtraction.test_extract_job_id_from_nested_data()`
1. Create test response dictionary: `{"result": {"data": {"job_id": "queue-789"}}, "mode": "queued"}`
2. Call `_extract_job_id_from_response(result)`
3. Assert returned value is not `None`
4. Assert returned value equals `JobId("queue-789")` (or string "queue-789")
5. Assert returned value is instance of `JobId` (or `str`)

### `TestJobIdExtraction.test_extract_job_id_from_data()`
1. Create test response dictionary: `{"data": {"job_id": "queue-abc"}, "status": "pending"}`
2. Call `_extract_job_id_from_response(result)`
3. Assert returned value is not `None`
4. Assert returned value equals `JobId("queue-abc")` (or string "queue-abc")
5. Assert returned value is instance of `JobId` (or `str`)

### `TestJobIdExtraction.test_extract_job_id_returns_none_when_missing()`
1. Create test response dictionary: `{"status": "pending", "mode": "queued"}` (no `job_id` field)
2. Call `_extract_job_id_from_response(result)`
3. Assert returned value is `None`

### `TestJobIdExtraction.test_extract_job_id_strips_whitespace()`
1. Create test response dictionary: `{"job_id": "  queue-123  ", "status": "pending"}`
2. Call `_extract_job_id_from_response(result)`
3. Assert returned value is not `None`
4. Assert returned value equals `JobId("queue-123")` (or string "queue-123" without leading/trailing whitespace)
5. Assert returned value does not contain leading or trailing whitespace

### `TestJobIdExtraction.test_extract_job_id_returns_none_for_empty_string()`
1. Create test response dictionary: `{"job_id": "", "status": "pending"}`
2. Call `_extract_job_id_from_response(result)`
3. Assert returned value is `None`
4. Create test response dictionary: `{"job_id": "   ", "status": "pending"}` (whitespace-only)
5. Call `_extract_job_id_from_response(result)`
6. Assert returned value is `None`

### `TestDeliverIdExtraction.test_extract_deliver_id_from_top_level()`
1. Create test response dictionary: `{"accepted": True, "deliver_id": "deliver-abc-123"}`
2. Call `_extract_deliver_id_from_response(result)`
3. Assert returned value is not `None`
4. Assert returned value equals `DeliverId("deliver-abc-123")` (or string "deliver-abc-123")
5. Assert returned value is instance of `DeliverId` (or `str`)

### `TestDeliverIdExtraction.test_extract_deliver_id_from_nested_result()`
1. Create test response dictionary: `{"result": {"deliver_id": "deliver-xyz-456"}, "accepted": True}`
2. Call `_extract_deliver_id_from_response(result)`
3. Assert returned value is not `None`
4. Assert returned value equals `DeliverId("deliver-xyz-456")` (or string "deliver-xyz-456")
5. Assert returned value is instance of `DeliverId` (or `str`)

### `TestDeliverIdExtraction.test_extract_deliver_id_from_nested_data()`
1. Create test response dictionary: `{"result": {"data": {"deliver_id": "deliver-def-789"}}, "accepted": True}`
2. Call `_extract_deliver_id_from_response(result)`
3. Assert returned value is not `None`
4. Assert returned value equals `DeliverId("deliver-def-789")` (or string "deliver-def-789")
5. Assert returned value is instance of `DeliverId` (or `str`)

### `TestDeliverIdExtraction.test_extract_deliver_id_from_data()`
1. Create test response dictionary: `{"data": {"deliver_id": "deliver-ghi-012"}, "accepted": True}`
2. Call `_extract_deliver_id_from_response(result)`
3. Assert returned value is not `None`
4. Assert returned value equals `DeliverId("deliver-ghi-012")` (or string "deliver-ghi-012")
5. Assert returned value is instance of `DeliverId` (or `str`)

### `TestDeliverIdExtraction.test_extract_deliver_id_returns_none_when_missing()`
1. Create test response dictionary: `{"accepted": True}` (no `deliver_id` field)
2. Call `_extract_deliver_id_from_response(result)`
3. Assert returned value is `None`

### `TestDeliverIdExtraction.test_extract_deliver_id_strips_whitespace()`
1. Create test response dictionary: `{"deliver_id": "  deliver-123  ", "accepted": True}`
2. Call `_extract_deliver_id_from_response(result)`
3. Assert returned value is not `None`
4. Assert returned value equals `DeliverId("deliver-123")` (or string "deliver-123" without leading/trailing whitespace)
5. Assert returned value does not contain leading or trailing whitespace

### `TestDeliverIdExtraction.test_extract_deliver_id_returns_none_for_empty_string()`
1. Create test response dictionary: `{"deliver_id": "", "accepted": True}`
2. Call `_extract_deliver_id_from_response(result)`
3. Assert returned value is `None`
4. Create test response dictionary: `{"deliver_id": "   ", "accepted": True}` (whitespace-only)
5. Call `_extract_deliver_id_from_response(result)`
6. Assert returned value is `None`

### `TestIdentifierTypes.test_job_id_type()`
1. Create `JobId` instance: `job_id = JobId("queue-123")`
2. Assert `job_id` is instance of `JobId`
3. Assert `str(job_id)` equals `"queue-123"`
4. Assert `job_id` can be used as string (e.g., `len(job_id) > 0`)

### `TestIdentifierTypes.test_deliver_id_type()`
1. Create `DeliverId` instance: `deliver_id = DeliverId("deliver-123")`
2. Assert `deliver_id` is instance of `DeliverId`
3. Assert `str(deliver_id)` equals `"deliver-123"`
4. Assert `deliver_id` can be used as string (e.g., `len(deliver_id) > 0`)

### `TestIdentifierTypes.test_job_id_and_deliver_id_are_distinct()`
1. Create `JobId` instance: `job_id = JobId("queue-123")`
2. Create `DeliverId` instance: `deliver_id = DeliverId("deliver-123")`
3. Assert `job_id` is instance of `JobId`
4. Assert `deliver_id` is instance of `DeliverId`
5. Assert `job_id` is NOT instance of `DeliverId`
6. Assert `deliver_id` is NOT instance of `JobId`
7. Assert type checking would fail if trying to assign `JobId` to `DeliverId` variable (use `type()` comparison or `isinstance()` checks)

### `TestIdentifierTypes.test_is_valid_job_id()`
1. Call `is_valid_job_id("queue-123")` and assert returns `True`
2. Call `is_valid_job_id("  queue-123  ")` and assert returns `True` (after stripping)
3. Call `is_valid_job_id("")` and assert returns `False`
4. Call `is_valid_job_id("   ")` and assert returns `False` (whitespace-only)
5. Call `is_valid_job_id("valid-id")` and assert returns `True`

### `TestIdentifierTypes.test_is_valid_deliver_id()`
1. Call `is_valid_deliver_id("deliver-123")` and assert returns `True`
2. Call `is_valid_deliver_id("  deliver-123  ")` and assert returns `True` (after stripping)
3. Call `is_valid_deliver_id("")` and assert returns `False`
4. Call `is_valid_deliver_id("   ")` and assert returns `False` (whitespace-only)
5. Call `is_valid_deliver_id("valid-id")` and assert returns `True`

## Error Handling Per Method

**All test methods:**
- **Exceptions to catch:** None (tests should not catch exceptions, let pytest handle failures)
- **Assertions:** Use `assert` statements with descriptive messages
- **Test failures:** If extraction function raises exception, test should fail (this indicates bug in extraction function)

**Edge cases:**
- Missing identifier: extraction function should return `None`, not raise exception
- Empty string: extraction function should return `None`, not raise exception
- Whitespace-only: extraction function should return `None`, not raise exception
- Non-dict input: extraction function should return `None`, not raise exception

## Return Value Specification

**All test methods:**
- Return type: `None` (test methods do not return values)
- Assertions verify expected behavior

## Edge Cases

**For extraction tests:**
- Empty response dictionary: `{}`
- Response with `None` values: `{"job_id": None}`
- Response with non-string values: `{"job_id": 123}`
- Response with nested `None`: `{"result": None}`
- Response with non-dict nested: `{"result": "not-a-dict"}`

**For type tests:**
- Creating `JobId` from empty string (should be allowed by type system, but validation function should reject)
- Creating `DeliverId` from empty string (should be allowed by type system, but validation function should reject)
- Type compatibility: `JobId` and `DeliverId` should not be interchangeable

## Exact Validation Commands

After implementation, run these commands:

```bash
# Format code
black tests/test_identifier_extraction.py
# Expected: "reformatted tests/test_identifier_extraction.py" or "already well formatted"

# Lint code
flake8 tests/test_identifier_extraction.py
# Expected: no output (exit code 0)

# Type check
mypy tests/test_identifier_extraction.py
# Expected: "Success: no issues found" or type errors that are acceptable (e.g., if extraction functions return str instead of JobId/DeliverId)

# Run tests
pytest tests/test_identifier_extraction.py -v
# Expected: all tests PASSED (all test functions should pass)
```

## Exact Test Expectations

**Test count:** 18 test functions total
- 7 tests in `TestJobIdExtraction`
- 7 tests in `TestDeliverIdExtraction`
- 4 tests in `TestIdentifierTypes`

**All tests must pass** without requiring real server or network connections (unit tests only, use mocks if needed for type imports).

## Forbidden Patterns

1. **DO NOT** create real network connections (use mocks if needed)
2. **DO NOT** test adapter internals (test extraction functions only)
3. **DO NOT** assume `job_id` and `deliver_id` are the same (test they are distinct)
4. **DO NOT** expose JSON-RPC request IDs in tests
5. **DO NOT** create integration tests (this is unit test file)
6. **DO NOT** use `print()` for logging (use pytest's assertion messages)
7. **DO NOT** use bare `except:` clauses
8. **DO NOT** skip tests with `pytest.skip()` unless absolutely necessary

## Constants and Literals

**Test data constants:**
- `"queue-123"` - sample job_id value
- `"queue-456"` - sample job_id value for nested tests
- `"queue-789"` - sample job_id value for nested data tests
- `"queue-abc"` - sample job_id value for data tests
- `"deliver-abc-123"` - sample deliver_id value
- `"deliver-xyz-456"` - sample deliver_id value for nested tests
- `"deliver-def-789"` - sample deliver_id value for nested data tests
- `"deliver-ghi-012"` - sample deliver_id value for data tests
- `"  queue-123  "` - job_id with whitespace (for stripping test)
- `"  deliver-123  "` - deliver_id with whitespace (for stripping test)
- `""` - empty string (for empty test)
- `"   "` - whitespace-only string (for whitespace-only test)

**No magic numbers** (all test data is string literals).

## Mandatory Completion Condition

**All tests must pass** when running `pytest tests/test_identifier_extraction.py -v`.

## Decision Rules

1. **If extraction function returns `str` instead of `JobId`/`DeliverId`:** Test should assert string value and optionally check that it can be converted to `JobId`/`DeliverId` type
2. **If extraction function raises exception for invalid input:** Test should expect exception (this indicates extraction function needs to handle edge cases)
3. **If type system uses `NewType`:** `JobId` and `DeliverId` are distinct types at type-checking time, but runtime they are strings (test both type checking and runtime behavior)

## Blackstops

**Stop and escalate if:**
- Extraction functions do not exist in `async_client_api_mixin.py` (dependency missing)
- `identifier_types.py` does not exist or does not contain required types (dependency missing)
- Extraction function signatures differ from expected (requires tactical task update)

## Handoff Package

**For coder_auto:**
- Target file: `tests/test_identifier_extraction.py` (create new file)
- All imports listed above
- All test classes and methods with full signatures listed above
- Step-by-step algorithm for each test method
- Edge cases and error handling specified
- Validation commands with expected output patterns
- Forbidden patterns list

**No code implementation** - only test structure and assertions as specified above.
