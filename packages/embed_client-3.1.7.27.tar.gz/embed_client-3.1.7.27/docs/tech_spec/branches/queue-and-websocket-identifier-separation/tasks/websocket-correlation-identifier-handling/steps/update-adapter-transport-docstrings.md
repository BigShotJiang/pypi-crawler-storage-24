Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Update AdapterTransport Docstrings and Type Hints

## Executor Role

**Executor:** `coder_auto`

**Role:** Implement documentation and type hint updates in `embed_client/adapter_transport.py` to explicitly document identifier types used by `execute_async()` and `wait_for_job_via_websocket()` methods.

## Execution Directive

Update docstrings and type hints in `embed_client/adapter_transport.py` to explicitly document:
1. `execute_async()` uses adapter-managed `deliver_id` for WebSocket correlation (distinct from queue `job_id`)
2. `wait_for_job_via_websocket()` uses `job_id` (queue-based identifier) for WebSocket subscription

Add type hints using `JobId` and `DeliverId` types from `embed_client.identifier_types` module.

## Parent Links

- **Tech spec:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- **Parent tactical task:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/websocket-correlation-identifier-handling.md`

## Step Scope

**Target file:** `embed_client/adapter_transport.py`

**Action:** modify

**Lines to modify:**
- Lines 176-207: `execute_async()` method - update docstring
- Lines 369-391: `wait_for_job_via_websocket()` method - update docstring and add type hint

**No code logic changes** - only documentation and type hints.

## Dependency Contract

**Depends on:**
- `identifier-extraction-and-type-separation` tactical task must be completed first (provides `JobId` and `DeliverId` types from `embed_client.identifier_types` module)

**If types are not available:**
- The step must still update docstrings (they don't require the types)
- Type hints can be added conditionally or the step can wait for types to be available
- Document in the step that type hints depend on the identifier types module existing

## Required Context

- Understanding that `execute_async()` uses adapter-managed `deliver_id` internally (adapter handles WebSocket subscription with `deliver_id`)
- Understanding that `wait_for_job_via_websocket()` is for queue operations and uses `job_id` (not `deliver_id`)
- Understanding that `deliver_id` and `job_id` are distinct identifier types and must not be confused
- Current docstrings in the target file (read from lines 184-199 for `execute_async`, lines 372-388 for `wait_for_job_via_websocket`)

## Read First

**Required files to read before implementation:**
1. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - current implementation
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/websocket-correlation-identifier-handling.md` - tactical task requirements
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation.md` - to understand `JobId` and `DeliverId` type definitions (if available)

## Expected File Change

**File:** `embed_client/adapter_transport.py`

**Changes:**
1. **Import section (around line 13):** Add import for `JobId` and `DeliverId` types:
   ```python
   from embed_client.identifier_types import JobId, DeliverId
   ```

2. **`execute_async()` method (lines 176-207):** Update docstring to explicitly state:
   - Uses adapter-managed `deliver_id` for WebSocket correlation
   - The `deliver_id` is distinct from queue `job_id`
   - Response contains `deliver_id` field
   - Adapter handles `deliver_id` subscription internally

3. **`wait_for_job_via_websocket()` method (lines 369-391):** 
   - Update docstring to explicitly state:
     - Uses `job_id` (queue-based identifier) for WebSocket subscription
     - This method is for queue operations only
     - For `execute_async` operations, use `execute_async()` with callback instead
     - The `job_id` parameter must be a queue job identifier, not a `deliver_id`
   - Add type hint: change `job_id: str` to `job_id: JobId`

**No method signatures change** - only docstrings and type hints.

## Forbidden Alternatives

1. **DO NOT** change method signatures (parameters, return types, async/await)
2. **DO NOT** modify method implementation logic
3. **DO NOT** add new methods or classes
4. **DO NOT** remove existing docstrings
5. **DO NOT** assume `deliver_id` and `job_id` are interchangeable
6. **DO NOT** use `job_id` type hint for `execute_async()` parameters (it doesn't use `job_id`)
7. **DO NOT** modify any other methods in the file
8. **DO NOT** change import order or add unrelated imports

## Atomic Operations

### Operation 1: Add Import Statement

**Location:** After existing imports (around line 13, after `from typing import ...`)

**Action:** Add:
```python
from embed_client.identifier_types import JobId, DeliverId
```

**If module doesn't exist yet:** Add the import anyway (it will be created by the identifier-extraction task). The import may cause a temporary mypy error until the module exists, but that's acceptable.

### Operation 2: Update `execute_async()` Docstring

**Location:** Lines 184-199 (inside the `execute_async()` method)

**Current docstring structure:**
```python
"""
Submit command for async execution; result is delivered via WebSocket callback.

Uses adapter execute_async: generates deliver_id, subscribes on /ws, sends
execute_async RPC, returns immediately. When server pushes job_completed/
job_failed for this deliver_id, on_result(payload) is invoked once.

Args:
    command: Command name to execute (e.g. embed_execute).
    params: Optional command parameters.
    on_result: Callback invoked with the push message (event, result or error).
        May be sync or async.
    timeout: Max seconds to wait for push (default 60).

Returns:
    Server response with accepted and deliver_id.
"""
```

**New docstring (replace entire docstring):**
```python
"""
Submit command for async execution; result is delivered via WebSocket callback.

Uses adapter-managed `deliver_id` for WebSocket correlation. The adapter generates
a `deliver_id`, subscribes to WebSocket with that `deliver_id`, sends the
execute_async RPC, and returns immediately. When the server pushes
job_completed/job_failed for this `deliver_id`, on_result(payload) is invoked once.

**Identifier semantics:**
- Uses adapter-managed `deliver_id` for WebSocket correlation (distinct from queue `job_id`)
- The `deliver_id` is generated by the adapter and used internally for WebSocket subscription
- The `deliver_id` is distinct from queue `job_id` and must not be confused with it
- Response contains `deliver_id` field which is adapter-managed

Args:
    command: Command name to execute (e.g. embed_execute).
    params: Optional command parameters.
    on_result: Callback invoked with the push message (event, result or error).
        May be sync or async.
    timeout: Max seconds to wait for push (default 60).

Returns:
    Server response containing `accepted` and `deliver_id` fields. The `deliver_id`
    is adapter-managed and used for WebSocket correlation. Do not use this `deliver_id`
    with queue-based methods like `wait_for_job_via_websocket()`.
"""
```

### Operation 3: Update `wait_for_job_via_websocket()` Docstring and Type Hint

**Location:** Lines 369-391 (method signature and docstring)

**Current method signature:**
```python
async def wait_for_job_via_websocket(
    self, job_id: str, timeout: float = 60.0
) -> Dict[str, Any]:
```

**New method signature (add type hint):**
```python
async def wait_for_job_via_websocket(
    self, job_id: JobId, timeout: float = 60.0
) -> Dict[str, Any]:
```

**Current docstring:**
```python
"""
Wait for job completion via WebSocket /ws (push) instead of HTTP polling.

Uses the same auth and TLS as the client. Requires server to expose /ws
and job_push. Sends subscribe for job_id and returns when server sends
job_completed, job_failed, or job_stopped.

Args:
    job_id: Job identifier from embed submit.
    timeout: Max seconds to wait for a terminal event.

Returns:
    Last event payload (event, job_id, result or error).

Raises:
    asyncio.TimeoutError: If no terminal event within timeout.
    RuntimeError: On WebSocket connection or protocol errors.
"""
```

**New docstring (replace entire docstring):**
```python
"""
Wait for job completion via WebSocket /ws (push) instead of HTTP polling.

Uses `job_id` (queue-based identifier) for WebSocket subscription. This method
subscribes to WebSocket push events for a queued job. The server must expose /ws
and job_push. Sends subscribe for `job_id` and returns when server sends
job_completed, job_failed, or job_stopped.

**Identifier semantics:**
- Uses `job_id` (queue-based identifier) for WebSocket subscription
- This method is for queue operations only
- For `execute_async` operations, use `execute_async()` with callback instead
- The `job_id` parameter must be a queue job identifier obtained from queue
  submission (e.g., from `submit_job()` or `embed()` with `wait=False`), not a
  `deliver_id` from `execute_async()`
- Do not pass a `deliver_id` from `execute_async()` response to this method

Args:
    job_id: Queue job identifier from embed submit or queue submission. Must be
        a `job_id` from queue operations, not a `deliver_id` from `execute_async()`.
    timeout: Max seconds to wait for a terminal event.

Returns:
    Last event payload (event, job_id, result or error).

Raises:
    asyncio.TimeoutError: If no terminal event within timeout.
    RuntimeError: On WebSocket connection or protocol errors.
"""
```

## Expected Deliverables

1. **Modified file:** `embed_client/adapter_transport.py` with:
   - Import statement for `JobId` and `DeliverId` types added
   - Updated docstring for `execute_async()` method documenting `deliver_id` usage
   - Updated docstring and type hint for `wait_for_job_via_websocket()` method documenting `job_id` usage

2. **No new files created**

3. **No test files modified** (tests are in a separate tactical task)

## Mandatory Validation

**After implementation, run these exact commands:**

1. **Format check:**
   ```bash
   black embed_client/adapter_transport.py
   ```
   **Expected:** "reformatted" or "already well formatted" (exit code 0)

2. **Lint check:**
   ```bash
   flake8 embed_client/adapter_transport.py
   ```
   **Expected:** No output (exit code 0)

3. **Type check:**
   ```bash
   mypy embed_client/adapter_transport.py
   ```
   **Expected:** 
   - If `identifier_types` module exists: "Success: no issues found" (exit code 0)
   - If `identifier_types` module doesn't exist yet: May show import error, which is acceptable until the identifier-extraction task completes

4. **Syntax check:**
   ```bash
   python -m py_compile embed_client/adapter_transport.py
   ```
   **Expected:** No output (exit code 0)

**All validation commands must pass before marking step complete.**

## Decision Rules

1. **If `identifier_types` module doesn't exist:**
   - Still add the import statement (it will be created by identifier-extraction task)
   - mypy may show an error, which is acceptable
   - Document in commit message that type hints depend on identifier-extraction task

2. **Docstring format:**
   - Use triple-quoted strings with proper indentation
   - Follow existing docstring style in the file
   - Use **bold** for important semantic notes (Identifier semantics section)

3. **Type hint placement:**
   - Place type hint directly in method signature parameter
   - Do not use type comments (`# type: JobId`)

## Blackstops

**Stop and escalate if:**
1. The `execute_async()` method signature changes (it should remain unchanged)
2. The `wait_for_job_via_websocket()` method signature changes beyond adding type hint (parameters, return type, async should remain unchanged)
3. Any method implementation logic needs to change (this step is documentation-only)
4. Import statement causes syntax errors that cannot be resolved

## Handoff Package

**For `coder_auto` executor:**

1. **Target file:** `embed_client/adapter_transport.py` (modify existing file)

2. **Exact changes:**
   - Add import: `from embed_client.identifier_types import JobId, DeliverId` (after line 13)
   - Replace `execute_async()` docstring (lines 184-199) with new docstring documenting `deliver_id` usage
   - Replace `wait_for_job_via_websocket()` docstring (lines 372-388) with new docstring documenting `job_id` usage
   - Change `wait_for_job_via_websocket()` parameter type from `job_id: str` to `job_id: JobId` (line 370)

3. **Validation commands:** Run black, flake8, mypy, py_compile (see Mandatory Validation section)

4. **Dependencies:** This step depends on `identifier-extraction-and-type-separation` task providing `JobId` and `DeliverId` types. If types don't exist yet, add import anyway (mypy error is acceptable until types are created).

5. **No code logic changes** - only documentation and type hints.

## Complete Import List

**Current imports in file (lines 11-21):**
```python
import logging
import time
from typing import Any, Awaitable, Callable, Dict, Optional

from mcp_proxy_adapter.client.jsonrpc_client import (  # type: ignore[import-untyped]
    BidirectionalWsChannel,
    JsonRpcClient,
    open_bidirectional_ws_channel as adapter_open_bidirectional_ws_channel,
)

from embed_client.constants import DEFAULT_POLL_INTERVAL
```

**Add after line 21:**
```python
from embed_client.identifier_types import JobId, DeliverId
```

## Method Signatures (No Changes)

**`execute_async()` method signature (unchanged):**
```python
async def execute_async(
    self,
    command: str,
    params: Optional[Dict[str, Any]] = None,
    *,
    on_result: Callable[[Dict[str, Any]], Any],
    timeout: float = 60.0,
) -> Dict[str, Any]:
```

**`wait_for_job_via_websocket()` method signature (only type hint change):**
```python
async def wait_for_job_via_websocket(
    self, job_id: JobId, timeout: float = 60.0
) -> Dict[str, Any]:
```

## Step-by-Step Algorithm

### Step 1: Read Current File
1. Read `embed_client/adapter_transport.py` completely
2. Identify import section (around line 13)
3. Identify `execute_async()` method (lines 176-207)
4. Identify `wait_for_job_via_websocket()` method (lines 369-391)

### Step 2: Add Import Statement
1. Locate the import section (after `from embed_client.constants import DEFAULT_POLL_INTERVAL`)
2. Add new line: `from embed_client.identifier_types import JobId, DeliverId`
3. Ensure proper spacing and formatting

### Step 3: Update `execute_async()` Docstring
1. Locate the docstring inside `execute_async()` method (lines 184-199)
2. Replace entire docstring with new docstring from "Atomic Operations" section
3. Ensure proper indentation (4 spaces, aligned with method body)
4. Preserve triple quotes format

### Step 4: Update `wait_for_job_via_websocket()` Method
1. Locate method signature (line 370)
2. Change parameter type from `job_id: str` to `job_id: JobId`
3. Locate docstring (lines 372-388)
4. Replace entire docstring with new docstring from "Atomic Operations" section
5. Ensure proper indentation

### Step 5: Validate Changes
1. Run `black embed_client/adapter_transport.py`
2. Run `flake8 embed_client/adapter_transport.py`
3. Run `mypy embed_client/adapter_transport.py` (may show import error if types don't exist yet - acceptable)
4. Run `python -m py_compile embed_client/adapter_transport.py`
5. Verify file syntax is correct

## Error Handling Specification

**No error handling changes needed.** This step only updates documentation and type hints. Existing error handling in methods remains unchanged.

**If import fails:**
- If `identifier_types` module doesn't exist, mypy will show import error
- This is acceptable until identifier-extraction task completes
- Do not remove the import - it will be needed once types are created

## Edge Cases

**Edge case 1: `identifier_types` module doesn't exist yet**
- **Behavior:** Add import anyway, mypy may show error
- **Action:** Acceptable - types will be created by identifier-extraction task
- **Documentation:** Note in commit message that type hints depend on identifier-extraction task

**Edge case 2: Existing docstring format differs slightly**
- **Behavior:** Follow existing docstring style in the file
- **Action:** Match indentation and formatting style of other docstrings in the file

**Edge case 3: Type hint causes mypy error if types don't exist**
- **Behavior:** mypy reports "Cannot find implementation or library stub"
- **Action:** Acceptable - error will resolve when identifier-extraction task completes
- **Documentation:** Do not remove type hint - it's required by the tactical task

## Exact Constants and Literals

**No new constants or literals needed.** This step only updates documentation strings and type hints.

**String literals in docstrings:**
- All docstring text is provided in the "Atomic Operations" section
- Use exact text as specified (including **bold** markers for emphasis)

## Forbidden Patterns

1. **DO NOT** use `# type: JobId` comments instead of inline type hints
2. **DO NOT** change method implementation code
3. **DO NOT** add new methods or modify other methods
4. **DO NOT** remove existing imports
5. **DO NOT** change import order (add new import at the end of import section)
6. **DO NOT** use `Any` type for `job_id` parameter
7. **DO NOT** assume `deliver_id` and `job_id` are the same type
8. **DO NOT** modify docstrings of other methods
9. **DO NOT** add implementation code to methods
10. **DO NOT** change async/await keywords or method signatures beyond type hints
