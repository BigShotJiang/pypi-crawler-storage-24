Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Update async_client_queue_mixin Queue Polling Methods Documentation and Type Hints

## Executor Role

**Executor:** `coder_auto`

**Execution directive:** Update all queue polling methods in `embed_client/async_client_queue_mixin.py` to add explicit `job_id` documentation and `JobId` type hints.

## Parent Links

- **Tech spec:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- **Parent tactical task:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling.md`

## Step Scope

**Target file:** `embed_client/async_client_queue_mixin.py`

**Action:** modify

**Methods to update:**
1. `wait_for_job()` (lines 35-207)
2. `job_status()` (lines 269-278)
3. `cancel_command()` (lines 280-286)
4. `submit_job()` (lines 319-374)
5. `get_job_status_or_result()` (lines 376-413)
6. `list_queued_commands()` (lines 288-310)
7. `get_job_logs()` (lines 312-317)

## Dependency Contract

**Depends on:**
- `identifier-extraction-and-type-separation` tactical task must be completed first (provides `JobId` type from `embed_client.identifier_types`)

**No dependencies on other atomic steps in this tactical task** (can be executed in parallel with other steps)

## Required Context

This step updates documentation and type hints only. Method implementations remain unchanged. The `JobId` type must be available from `embed_client.identifier_types` module (created by the identifier-extraction-and-type-separation task).

## Read First

Before starting, read these files:

1. `/home/vasilyvz/projects/embed-client/embed_client/async_client_queue_mixin.py` (full file to understand all methods)
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` (identifier model section)
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling.md` (tactical task requirements)

## Expected File Change

**File:** `embed_client/async_client_queue_mixin.py`

### Changes:

1. **Add import** (at top of file, after existing imports, around line 26):
   ```python
   from embed_client.identifier_types import JobId
   ```

2. **Update method signatures and docstrings:**

   **Method 1: `wait_for_job()` (line 35)**
   - Change signature: `job_id: str` → `job_id: JobId`
   - Replace docstring (lines 41-50) with:
   ```python
        """
        Wait for job completion and return results.

        Uses `job_id` (queue-based identifier) for status polling. This method polls
        queue status via HTTP, not WebSocket. For WebSocket waiting, use
        `wait_for_job_via_websocket()`. The `job_id` parameter must be a queue job
        identifier obtained from queue submission (e.g., from submit_job() or
        embed_queue response), not a `deliver_id` from `execute_async()`.

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission. This is distinct from `deliver_id` used by execute_async().
            timeout: Maximum time to wait in seconds.
                    If None, return immediately without waiting.
                    If 0, wait indefinitely (no timeout).
                    Default: 60.0 seconds.
            poll_interval: Time between queue status checks in seconds.
                          Default: DEFAULT_POLL_INTERVAL.

        Returns:
            Job result dictionary when job completes.

        Raises:
            EmbeddingServiceTimeoutError: If timeout is exceeded.
            EmbeddingServiceError: If job fails or status check fails.
        """
   ```

   **Method 2: `job_status()` (line 269)**
   - Change signature: `job_id: str` → `job_id: JobId`
   - Replace docstring (line 270) with:
   ```python
        """
        Get job status from the queue.

        Uses `job_id` (queue-based identifier) for status lookup. The `job_id` parameter
        must be a queue job identifier obtained from queue submission (e.g., from
        submit_job() or embed_queue response), not a `deliver_id` from `execute_async()`.

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission. This is distinct from `deliver_id` used by execute_async().

        Returns:
            Normalized job status dictionary.

        Raises:
            EmbeddingServiceError: If status check fails.
        """
   ```

   **Method 3: `cancel_command()` (line 280)**
   - Change signature: `job_id: str` → `job_id: JobId`
   - Replace docstring (line 281) with:
   ```python
        """
        Cancel a command execution in queue.

        Uses `job_id` (queue-based identifier) to cancel and delete a queued job. The
        `job_id` parameter must be a queue job identifier obtained from queue submission
        (e.g., from submit_job() or embed_queue response), not a `deliver_id` from
        `execute_async()`.

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission. This is distinct from `deliver_id` used by execute_async().

        Returns:
            Deletion result dictionary.

        Raises:
            EmbeddingServiceError: If cancellation fails.
        """
   ```

   **Method 4: `submit_job()` (line 319)**
   - No signature change (no `job_id` parameter - it returns `job_id`)
   - Replace docstring (lines 324-342) with:
   ```python
        """
        Submit a job to the queue and return job ID.

        This method submits a command to the queue without waiting for completion.
        Use get_job_status_or_result() to check status or get results.

        Returns `job_id` (queue-based identifier) in the response. This `job_id` is
        distinct from `deliver_id` used by `execute_async()`. Use this `job_id` for
        queue status polling and WebSocket subscription, not for `execute_async`
        operations.

        Args:
            command: Command name to execute (e.g., "embed").
            params: Command parameters dictionary.

        Returns:
            Dictionary with job information:
            - job_id: Queue job identifier (JobId type) for status checking.
                     This is distinct from `deliver_id` used by execute_async().
            - status: Initial job status (usually "queued" or "pending")
            - mode: "queued" if job was queued, "immediate" if completed immediately

        Raises:
            EmbeddingServiceError: If job submission fails.
        """
   ```

   **Method 5: `get_job_status_or_result()` (line 376)**
   - Change signature: `job_id: str` → `job_id: JobId`
   - Replace docstring (lines 381-402) with:
   ```python
        """
        Get job status or result if job is completed.

        Uses `job_id` (queue-based identifier) for status checking. The `job_id`
        parameter must be a queue job identifier obtained from queue submission
        (e.g., from submit_job() or embed_queue response), not a `deliver_id` from
        `execute_async()`.

        This method checks job status and returns result if job is completed.
        If timeout is specified and job is not completed, waits up to timeout seconds.

        Args:
            job_id: Queue job identifier (JobId type) from submit_job(). Must be
                   obtained from queue submission. This is distinct from `deliver_id`
                   used by execute_async().
            timeout: Optional timeout in seconds. If None, returns current status immediately.
                    If 0, waits indefinitely. If > 0, waits up to specified seconds.

        Returns:
            Dictionary with job status and result:
            - status: Job status ("queued", "pending", "running", "completed", "failed", "error")
            - result: Job result data (if completed)
            - job_id: Queue job identifier (JobId type)

        Raises:
            EmbeddingServiceTimeoutError: If timeout > 0 and job doesn't complete in time.
            EmbeddingServiceAPIError: If job fails.
            EmbeddingServiceError: If status check fails.
        """
   ```

   **Method 6: `list_queued_commands()` (line 288)**
   - No signature change (no `job_id` parameter)
   - Update docstring (line 293) to note that returned jobs contain `job_id` fields:
   ```python
        """
        List commands currently in the queue.

        Returns a list of queued commands with their status. Each job in the result
        contains a `job_id` field (queue-based identifier, JobId type). These `job_id`
        values can be used with other queue polling methods (job_status(), cancel_command(),
        get_job_logs(), etc.). The `job_id` values are distinct from `deliver_id` values
        used by `execute_async()`.

        Args:
            status: Optional status filter (e.g., "pending", "running", "completed").
            limit: Optional limit on number of jobs to return.

        Returns:
            Dictionary containing:
            - data.jobs: List of job dictionaries, each containing `job_id` (JobId type)
            - data.total_count: Total number of jobs matching filter

        Raises:
            EmbeddingServiceError: If listing fails.
        """
   ```

   **Method 7: `get_job_logs()` (line 312)**
   - Change signature: `job_id: str` → `job_id: JobId`
   - Replace docstring (line 313) with:
   ```python
        """
        Get job logs (stdout/stderr) from the queue.

        Uses `job_id` (queue-based identifier) to retrieve job logs. The `job_id`
        parameter must be a queue job identifier obtained from queue submission
        (e.g., from submit_job() or embed_queue response), not a `deliver_id` from
        `execute_async()`.

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission. This is distinct from `deliver_id` used by execute_async().

        Returns:
            Dictionary containing job logs (stdout/stderr).

        Raises:
            EmbeddingServiceError: If log retrieval fails.
        """
   ```

## Forbidden Alternatives

1. **DO NOT** change method implementation logic (only docstrings and type hints)
2. **DO NOT** use `deliver_id` or any WebSocket correlation identifier in these methods
3. **DO NOT** modify other methods in this file (e.g., `wait_for_job_via_websocket`, `open_bidirectional_ws_channel`)
4. **DO NOT** change exception handling behavior
5. **DO NOT** add validation logic for `job_id` format (type hint is sufficient)
6. **DO NOT** import `JobId` from anywhere other than `embed_client.identifier_types`
7. **DO NOT** modify the return value structure of `submit_job()` (only update docstring to document that `job_id` field is `JobId` type)

## Atomic Operations

1. **Add import statement:**
   - Location: After line 26 (after `from embed_client.response_normalizer import ResponseNormalizer`)
   - Add: `from embed_client.identifier_types import JobId`

2. **Update `wait_for_job()` method:**
   - Location: Line 35
   - Change parameter type: `job_id: str` → `job_id: JobId`
   - Location: Lines 41-50
   - Replace entire docstring with new docstring (provided above)

3. **Update `job_status()` method:**
   - Location: Line 269
   - Change parameter type: `job_id: str` → `job_id: JobId`
   - Location: Line 270
   - Replace entire docstring with new docstring (provided above)

4. **Update `cancel_command()` method:**
   - Location: Line 280
   - Change parameter type: `job_id: str` → `job_id: JobId`
   - Location: Line 281
   - Replace entire docstring with new docstring (provided above)

5. **Update `submit_job()` method:**
   - Location: Lines 324-342
   - Replace entire docstring with new docstring (provided above)
   - No signature change needed (no `job_id` parameter)

6. **Update `get_job_status_or_result()` method:**
   - Location: Line 376
   - Change parameter type: `job_id: str` → `job_id: JobId`
   - Location: Lines 381-402
   - Replace entire docstring with new docstring (provided above)

7. **Update `list_queued_commands()` method:**
   - Location: Line 293
   - Replace entire docstring with new docstring (provided above)
   - No signature change needed (no `job_id` parameter)

8. **Update `get_job_logs()` method:**
   - Location: Line 312
   - Change parameter type: `job_id: str` → `job_id: JobId`
   - Location: Line 313
   - Replace entire docstring with new docstring (provided above)

## Expected Deliverables

After completion, the file must have:

1. Import statement: `from embed_client.identifier_types import JobId`
2. All 7 methods updated with:
   - Type hints: All `job_id: str` parameters changed to `job_id: JobId`
   - Docstrings explicitly stating:
     - Uses `job_id` (queue-based identifier)
     - Must be obtained from queue submission
     - Distinct from `deliver_id` used by `execute_async`
   - For `submit_job()`: Docstring documents that returned `job_id` field is `JobId` type
   - For `list_queued_commands()`: Docstring notes that returned jobs contain `job_id` fields (JobId type)
3. No changes to method implementation bodies
4. No changes to other methods in the file

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Format check:**
   ```bash
   black embed_client/async_client_queue_mixin.py
   ```
   Expected: "reformatted" or "already well formatted" (exit code 0)

2. **Lint check:**
   ```bash
   flake8 embed_client/async_client_queue_mixin.py
   ```
   Expected: No output (exit code 0)

3. **Type check:**
   ```bash
   mypy embed_client/async_client_queue_mixin.py
   ```
   Expected: "Success: no issues found" (exit code 0)

4. **Import verification:**
   - Verify that `JobId` type exists in `embed_client/identifier_types.py` (created by identifier-extraction-and-type-separation task)
   - If `JobId` does not exist, this step cannot proceed - escalate to orchestrator_tactical

5. **Docstring verification:**
   - Verify all 7 methods have updated docstrings that explicitly mention:
     - "Uses `job_id` (queue-based identifier)"
     - "distinct from `deliver_id`"
     - "Must be obtained from queue submission"

## Decision Rules

1. **If `JobId` type does not exist:** Stop execution and report that identifier-extraction-and-type-separation task must complete first
2. **If import fails:** Verify that `embed_client/identifier_types.py` exists and contains `JobId` type alias
3. **If type check fails:** Ensure `JobId` is properly defined as a type alias (e.g., `JobId = str` or `JobId = NewType("JobId", str)`)
4. **If docstring replacement fails:** Ensure exact line numbers match current file state (read file first to verify)

## Edge Cases

1. **Method has no `job_id` parameter (`submit_job`, `list_queued_commands`):**
   - Only update docstring to document that returned values contain `job_id` fields (JobId type)
   - Do not add `job_id` parameter to signature

2. **Docstring spans multiple lines:**
   - Replace entire existing docstring (from opening `"""` to closing `"""`) with new docstring
   - Preserve indentation (4 spaces for method docstrings)

3. **Type hint in method call (e.g., `await self._adapter_transport.queue_get_job_status(job_id)`):**
   - No changes needed - type checker will validate that `JobId` is compatible with adapter method signature

## Blackstops

**Stop execution and escalate if:**

1. `embed_client/identifier_types.py` does not exist (identifier-extraction-and-type-separation task not completed)
2. `JobId` type is not defined in `embed_client/identifier_types.py`
3. Method signature change causes type errors in callers (should not happen if `JobId` is a type alias for `str`, but verify)
4. Line numbers in this step do not match current file (file may have been modified - read file first to get current line numbers)

## Handoff Package

**For coder_auto:**

- Target file: `embed_client/async_client_queue_mixin.py`
- Action: modify
- Exact import to add: `from embed_client.identifier_types import JobId`
- 7 methods to update with exact signature changes and docstring replacements (provided above)
- Validation commands (provided above)
- Dependency: Must verify `JobId` type exists before starting

**Completion condition:** All validation commands pass, all 7 methods have updated docstrings explicitly documenting `job_id` as queue-based identifier, all type hints use `JobId`.
