Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Update API Mixin Extraction Functions

## Executor Role

**Executor:** `coder_auto`

## Execution Directive

Update `embed_client/async_client_api_mixin.py` to:
1. Modify `_extract_job_id_from_response()` to return `Optional[JobId]` instead of `Optional[str]`, update docstring to explicitly state this is for queue operations only (not for `execute_async` responses)
2. Add new function `_extract_deliver_id_from_response()` that extracts `deliver_id` from `execute_async` responses and returns `Optional[DeliverId]`

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation.md`

## Step Scope

**Target file:** `embed_client/async_client_api_mixin.py`  
**Action:** modify

## Dependency Contract

**Dependencies:** 
- `embed_client/identifier_types.py` (must exist with `JobId`, `DeliverId` types)

**Dependents:**
- `embed_client/async_client_queue_mixin.py` (will use `_extract_job_id_from_response()` via mixin inheritance)
- `embed_client/async_client_api_mixin.py` (will use both functions internally in `embed()` method)

## Required Context

The existing `_extract_job_id_from_response()` function (lines 30-50) currently returns `Optional[str]` and has a docstring that doesn't explicitly state it's for queue operations only. This function must be updated to:
- Return `Optional[JobId]` type
- Have docstring that explicitly states it's for queue operations only, not for `execute_async` responses
- Preserve existing extraction logic (checking multiple locations in response dict)

A new function `_extract_deliver_id_from_response()` must be added to extract `deliver_id` from `execute_async` responses, following the same pattern but looking for `deliver_id` instead of `job_id`.

## Read First

- `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` (current implementation)
- `/home/vasilyvz/projects/embed-client/embed_client/identifier_types.py` (after step 1 completes)
- `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation.md` (algorithm descriptions)

## Expected File Change

**Modify existing function:** `_extract_job_id_from_response()` (lines 30-50)
- Change return type from `Optional[str]` to `Optional[JobId]`
- Update docstring to explicitly state: "Extract job_id from server queue response. This function is for queue operations only. Do NOT use for execute_async responses (use _extract_deliver_id_from_response() instead)."
- Wrap return value with `JobId()` constructor when returning non-None values
- Add import for `JobId` from `embed_client.identifier_types`

**Add new function:** `_extract_deliver_id_from_response()` (after `_extract_job_id_from_response()`)
- Function signature: `def _extract_deliver_id_from_response(result: Dict[str, Any]) -> Optional[DeliverId]:`
- Extract `deliver_id` from response following same pattern as job_id extraction
- Check locations: `result.get("deliver_id")`, `result.get("result", {}).get("deliver_id")`, `result.get("result", {}).get("data", {}).get("deliver_id")`, `result.get("data", {}).get("deliver_id")`
- Return `Optional[DeliverId]` (wrap with `DeliverId()` constructor)
- Add import for `DeliverId` from `embed_client.identifier_types`

## Forbidden Alternatives

- **DO NOT** change the extraction logic of `_extract_job_id_from_response()` (only change return type and docstring)
- **DO NOT** use `_extract_job_id_from_response()` for `execute_async` responses in docstring examples
- **DO NOT** assume `job_id` and `deliver_id` are the same value
- **DO NOT** modify any other functions in this file
- **DO NOT** change function visibility (keep as module-level function, not method)
- **DO NOT** add error handling that raises exceptions (functions return `None` for missing identifiers)

## Atomic Operations

### Import Updates

Add to existing imports section (after line 12, with other typing imports):
```python
from embed_client.identifier_types import JobId, DeliverId
```

The file already has `from typing import Any, Dict, List, Optional` at line 12, so `Optional` is already imported.

### Function: `_extract_job_id_from_response()` (Modify)

**Current location:** Lines 30-50

**New signature:**
```python
def _extract_job_id_from_response(result: Dict[str, Any]) -> Optional[JobId]:
```

**New docstring:**
```python
"""
Extract job_id from server queue response.

This function is for queue operations only. It extracts job_id from responses
returned by queue-based commands (e.g., embed_queue, queue_get_job_status).

DO NOT use this function for execute_async responses. For execute_async responses,
use _extract_deliver_id_from_response() instead.

Server returns either sync result (data.results) or queue (data.job_id).
Adapter may wrap with mode=queued and job_id at top level or in result.data.

Args:
    result: Response dictionary from server/adapter.

Returns:
    JobId if job_id found and valid, None otherwise.
"""
```

**Algorithm (preserve existing logic, wrap return with JobId):**
1. If `result` is not a dict (check with `isinstance(result, dict)`), return `None`
2. Create list of candidate locations to check:
   - `result.get("job_id")`
   - `(result.get("result") or {}).get("job_id")`
   - `(result.get("result") or {}).get("data")` (may be dict with job_id key)
   - `result.get("data")` (may be dict with job_id key)
3. Iterate through candidates:
   - If candidate is a string and non-empty after strip: return `JobId(candidate.strip())`
   - If candidate is a dict and has `job_id` key: extract `j = candidate.get("job_id")`, if `j` is string and non-empty after strip: return `JobId(j.strip())`
4. If no valid job_id found, return `None`

**Edge cases:**
- `result` is `None` → return `None` (handled by `isinstance` check)
- `result` is not a dict → return `None`
- `result` is empty dict `{}` → return `None`
- `job_id` is empty string `""` → return `None` (after strip check)
- `job_id` is whitespace-only `"   "` → return `None` (after strip check)
- `job_id` found at top level → return `JobId("abc123")`
- `job_id` found nested in `result.data` → return `JobId("xyz789")`
- `job_id` is non-string (e.g., int) → skip (not extracted)

**Error handling:**
- No exceptions raised (returns `None` for invalid/missing job_id)
- If `result.get("result")` returns non-dict, `or {}` fallback handles it
- If `result.get("data")` returns non-dict, `isinstance(candidate, dict)` check prevents errors

**Return value:**
- Returns `Optional[JobId]`: `JobId` instance if found, `None` if not found or invalid

### Function: `_extract_deliver_id_from_response()` (Add New)

**Location:** Add immediately after `_extract_job_id_from_response()` function (after line 50, before `class AsyncClientAPIMixin:`)

**Signature:**
```python
def _extract_deliver_id_from_response(result: Dict[str, Any]) -> Optional[DeliverId]:
```

**Docstring:**
```python
"""
Extract deliver_id from execute_async response.

This function extracts deliver_id from responses returned by adapter's
execute_async method. The deliver_id is an adapter-managed WebSocket
delivery/correlation identifier, distinct from server job_id.

DO NOT use _extract_job_id_from_response() for execute_async responses.
Use this function instead.

Args:
    result: Response dictionary from adapter execute_async.

Returns:
    DeliverId if deliver_id found and valid, None otherwise.
"""
```

**Algorithm:**
1. If `result` is not a dict (check with `isinstance(result, dict)`), return `None`
2. Create list of candidate locations to check:
   - `result.get("deliver_id")`
   - `(result.get("result") or {}).get("deliver_id")`
   - `(result.get("result") or {}).get("data", {})` (if dict, check `.get("deliver_id")`)
   - `result.get("data", {})` (if dict, check `.get("deliver_id")`)
3. Iterate through candidates:
   - If candidate is a string and non-empty after strip: return `DeliverId(candidate.strip())`
   - If candidate is a dict and has `deliver_id` key: extract `d = candidate.get("deliver_id")`, if `d` is string and non-empty after strip: return `DeliverId(d.strip())`
4. If no valid deliver_id found, return `None`

**Edge cases:**
- `result` is `None` → return `None` (handled by `isinstance` check)
- `result` is not a dict → return `None`
- `result` is empty dict `{}` → return `None`
- `deliver_id` is empty string `""` → return `None` (after strip check)
- `deliver_id` is whitespace-only `"   "` → return `None` (after strip check)
- `deliver_id` found at top level → return `DeliverId("deliver-abc-123")`
- `deliver_id` found nested in `result.data` → return `DeliverId("deliver-xyz-789")`
- `deliver_id` is non-string (e.g., int) → skip (not extracted)

**Error handling:**
- No exceptions raised (returns `None` for invalid/missing deliver_id)
- If `result.get("result")` returns non-dict, `or {}` fallback handles it
- If `result.get("data")` returns non-dict, `isinstance(candidate, dict)` check prevents errors

**Return value:**
- Returns `Optional[DeliverId]`: `DeliverId` instance if found, `None` if not found or invalid

## Expected Deliverables

1. `_extract_job_id_from_response()` returns `Optional[JobId]` (not `Optional[str]`)
2. `_extract_job_id_from_response()` docstring explicitly states it's for queue operations only
3. New function `_extract_deliver_id_from_response()` exists and returns `Optional[DeliverId]`
4. Both functions are importable and type-check correctly
5. File passes black, flake8, and mypy validation
6. Existing functionality of `_extract_job_id_from_response()` is preserved (same extraction logic)

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Format check:**
   ```bash
   black embed_client/async_client_api_mixin.py
   ```
   **Expected:** "reformatted embed_client/async_client_api_mixin.py" or "All done! ✨ 🍰 ✨" or "would reformat" (if check-only mode)

2. **Lint check:**
   ```bash
   flake8 embed_client/async_client_api_mixin.py
   ```
   **Expected:** No output (exit code 0)

3. **Type check:**
   ```bash
   mypy embed_client/async_client_api_mixin.py
   ```
   **Expected:** "Success: no issues found in 1 source file" (or existing type errors if any, but no NEW errors from this change)

4. **Import test:**
   ```bash
   python3 -c "from embed_client.async_client_api_mixin import _extract_job_id_from_response, _extract_deliver_id_from_response; from embed_client.identifier_types import JobId, DeliverId; print('OK')"
   ```
   **Expected:** "OK" printed, no errors

5. **Function test:**
   ```bash
   python3 -c "from embed_client.async_client_api_mixin import _extract_job_id_from_response, _extract_deliver_id_from_response; r1 = {'job_id': 'test123'}; r2 = {'deliver_id': 'deliver-test'}; j = _extract_job_id_from_response(r1); d = _extract_deliver_id_from_response(r2); print('Types:', type(j).__name__, type(d).__name__)"
   ```
   **Expected:** "Types: JobId DeliverId" or similar (types are distinct)

## Decision Rules

- Preserve existing extraction logic exactly (only change return type wrapping)
- Use same extraction pattern for `deliver_id` as for `job_id` (consistency)
- Return `None` for missing/invalid identifiers (no exceptions) to match existing behavior
- Keep functions as module-level (not methods) to match existing code style
- Update docstring to be explicit about queue-only scope to prevent misuse

## Blackstops

**STOP and escalate if:**
- `embed_client/identifier_types.py` does not exist (dependency not met)
- Existing `_extract_job_id_from_response()` logic is significantly different from described algorithm (check actual implementation)
- Type errors occur that cannot be resolved by adding `JobId()`/`DeliverId()` wrappers

## Handoff Package

**File to modify:** `embed_client/async_client_api_mixin.py`

**Changes to make:**
1. Add import: `from embed_client.identifier_types import JobId, DeliverId` (after line 12)
2. Modify `_extract_job_id_from_response()` (lines 30-50):
   - Change return type to `Optional[JobId]`
   - Update docstring to state queue-only scope
   - Wrap return values with `JobId()` constructor
3. Add new function `_extract_deliver_id_from_response()` after line 50 (before `class AsyncClientAPIMixin:`)

**Validation commands to run:**
- `black embed_client/async_client_api_mixin.py`
- `flake8 embed_client/async_client_api_mixin.py`
- `mypy embed_client/async_client_api_mixin.py`
- Import and function test commands (see Mandatory Validation section)

**Completion condition:** All validation commands pass, both functions exist and return correct types, docstring updated.
