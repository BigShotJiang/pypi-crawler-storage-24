Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Identifier-Focused Tests

## Parent Links

- **Tech spec:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`
- **Parent tactical task:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-focused-tests.md`

## Atomic Steps Summary

**Goal:** Create comprehensive test files for identifier extraction functions, type system, and identifier separation in queue polling, WebSocket correlation, and public API.

**Total atomic steps:** 2

**Dependency order:** Both steps can be executed in parallel (no dependencies between them).

## Atomic Steps

### Step 1: Test Identifier Extraction Functions

**File:** `test-identifier-extraction.md`

**Target file:** `tests/test_identifier_extraction.py`

**Purpose:** Test identifier extraction functions (`_extract_job_id_from_response`, `_extract_deliver_id_from_response`) and identifier type system (`JobId`, `DeliverId`, validation functions).

**Test count:** 18 test functions
- 7 tests for `job_id` extraction
- 7 tests for `deliver_id` extraction
- 4 tests for identifier type system

**Dependencies:**
- `embed_client/async_client_api_mixin.py` - extraction functions
- `embed_client/identifier_types.py` - type definitions

### Step 2: Test Identifier Separation

**File:** `test-identifier-separation.md`

**Target file:** `tests/test_identifier_separation.py`

**Purpose:** Test identifier separation in queue polling (uses `job_id`), WebSocket correlation (uses `deliver_id` for `execute_async`, `job_id` for queue-based WebSocket), public API methods, and verify identifier confusion fails appropriately.

**Test count:** 16 test functions
- 4 tests for queue polling identifiers
- 3 tests for WebSocket correlation identifiers
- 5 tests for public API identifiers
- 3 tests for identifier confusion scenarios

**Dependencies:**
- `embed_client/async_client_api_mixin.py` - public API methods
- `embed_client/async_client_queue_mixin.py` - queue methods
- `embed_client/testing_client.py` - client class
- `embed_client/adapter_transport.py` - adapter transport methods
- `embed_client/identifier_types.py` - type definitions

## Parallel Execution

Both atomic steps can be executed in parallel (Wave 1):
- `test-identifier-extraction.md` - no dependencies on other test files
- `test-identifier-separation.md` - no dependencies on other test files

Both steps depend on production code modules, but those dependencies should be satisfied by previous tactical tasks.

## Completion Criteria

Both atomic steps are complete when:
1. All test files are created
2. All tests pass (`pytest tests/test_identifier_extraction.py -v` and `pytest tests/test_identifier_separation.py -v`)
3. Code formatting passes (`black`, `flake8`, `mypy`)
4. All test functions are implemented as specified in atomic step documents
