Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Identifier Extraction And Type Separation

## Purpose

Explicitly separate identifier extraction logic for `job_id` (queue operations) and `deliver_id` (adapter-managed WebSocket async delivery). Ensure these identifiers are never confused or collapsed into each other unless the adapter explicitly guarantees equivalence. Make identifier types explicit in code with clear naming and documentation.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/queue-and-websocket-identifier-separation.md`

## Scope

**Included:**
- Identifier extraction functions for `job_id` from queue responses
- Identifier extraction functions for `deliver_id` from `execute_async` responses
- Type definitions or constants that distinguish identifier types
- Helper functions that preserve identifier type information through the call chain
- Updates to `_extract_job_id_from_response()` to be explicit about queue-only scope
- New extraction function for `deliver_id` from `execute_async` responses

**Excluded:**
- Changes to adapter transport layer (adapter handles JSON-RPC request IDs internally)
- Changes to WebSocket waiting logic (separate tactical task)
- Changes to queue polling logic (separate tactical task)
- Test code (separate tactical task)

## Boundaries

**Must NOT touch:**
- `embed_client/adapter_transport.py` adapter delegation methods (they delegate to adapter, which handles JSON-RPC request IDs internally)
- Public API method signatures (identifier separation is internal implementation detail)
- Adapter's internal JSON-RPC request ID handling (transport-internal, not exposed)

## Dependencies

- None (this is the foundation for other identifier-separation tasks)

## Parallelization Note

This task can run in parallel with tactical tasks that do not depend on identifier extraction logic. However, tasks that modify WebSocket waiting or queue polling should wait for this task to complete.

## Expected Outcome

1. Clear separation between `job_id` extraction (queue operations) and `deliver_id` extraction (`execute_async` operations)
2. Type-safe identifier handling with explicit naming that prevents confusion
3. Documentation in code that explains when to use `job_id` vs `deliver_id`
4. Helper functions that preserve identifier type information

## Correction Items

**Existing code to update:**
- `embed_client/async_client_api_mixin.py:30-50` - `_extract_job_id_from_response()` function must be documented as queue-only and must not be used for `execute_async` responses
- `embed_client/async_client_queue_mixin.py:352-357` - `submit_job()` job_id extraction must use the queue-specific extraction function
- `embed_client/async_client_api_mixin.py:492-496` - `embed()` method job_id extraction must use queue-specific extraction and must not assume `execute_async` responses contain `job_id`

## Questions/Escalation Rule

**Escalate to orchestrator if:**
- Adapter behavior changes and `deliver_id` and `job_id` are guaranteed to be equivalent (requires global decision on identifier model)
- Server contract changes identifier semantics (requires global spec update)

## File Inventory

**Action: modify**
- **Path:** `embed_client/async_client_api_mixin.py`
- **Purpose:** Update `_extract_job_id_from_response()` to be explicit about queue-only scope, add new `_extract_deliver_id_from_response()` function

**Action: modify**
- **Path:** `embed_client/async_client_queue_mixin.py`
- **Purpose:** Update `submit_job()` to use queue-specific identifier extraction

**Action: create**
- **Path:** `embed_client/identifier_types.py`
- **Purpose:** Define type aliases and constants for identifier types (JobId, DeliverId) and helper functions

## Class/Function Inventory

### `embed_client.identifier_types` (new file)

**Classes:**
- None

**Standalone functions:**
- `JobId = NewType("JobId", str)` - Type alias for queue job identifiers
- `DeliverId = NewType("DeliverId", str)` - Type alias for adapter-managed WebSocket delivery identifiers
- `is_valid_job_id(identifier: str) -> bool` - Validate job_id format (non-empty string)
- `is_valid_deliver_id(identifier: str) -> bool` - Validate deliver_id format (non-empty string)

**Imports needed:**
```python
from typing import NewType
```

### `embed_client.async_client_api_mixin` (modify)

**Functions to modify:**
- `_extract_job_id_from_response(result: Dict[str, Any]) -> Optional[str]` - Update docstring to explicitly state this is for queue operations only, not for `execute_async` responses. Add type hint return `Optional[JobId]` after import.

**Functions to add:**
- `_extract_deliver_id_from_response(result: Dict[str, Any]) -> Optional[DeliverId]` - Extract `deliver_id` from `execute_async` response. Check `result.get("deliver_id")`, `result.get("result", {}).get("deliver_id")`, `result.get("result", {}).get("data", {}).get("deliver_id")`, `result.get("data", {}).get("deliver_id")`. Return `None` if not found or empty. Return type: `Optional[DeliverId]`.

**Imports to add:**
```python
from typing import Optional
from embed_client.identifier_types import JobId, DeliverId
```

### `embed_client.async_client_queue_mixin` (modify)

**Functions to modify:**
- `submit_job(command: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]` - Update job_id extraction to use `_extract_job_id_from_response()` from `AsyncClientAPIMixin` (via mixin inheritance). Ensure extracted value is treated as `JobId` type.

**Imports to add:**
```python
from embed_client.identifier_types import JobId
```

## Data Structures

**Type aliases (in `embed_client/identifier_types.py`):**
- `JobId = NewType("JobId", str)` - Opaque type for queue job identifiers
- `DeliverId = NewType("DeliverId", str)` - Opaque type for adapter-managed WebSocket delivery identifiers

**No dataclasses, TypedDict, NamedTuple, or Pydantic models needed.**

## Import Map

### `embed_client/identifier_types.py`
```python
from typing import NewType
```

### `embed_client/async_client_api_mixin.py` (additions)
```python
from typing import Optional
from embed_client.identifier_types import JobId, DeliverId
```

### `embed_client/async_client_queue_mixin.py` (additions)
```python
from embed_client.identifier_types import JobId
```

## Error Handling Map

### `_extract_job_id_from_response(result: Dict[str, Any]) -> Optional[JobId]`
- **Exception:** None (returns `None` if not found)
- **Conditions:** Returns `None` if `result` is not a dict, if no `job_id` found in any checked location, or if found `job_id` is empty/whitespace
- **Caller action:** Caller must check for `None` and handle missing identifier appropriately

### `_extract_deliver_id_from_response(result: Dict[str, Any]) -> Optional[DeliverId]`
- **Exception:** None (returns `None` if not found)
- **Conditions:** Returns `None` if `result` is not a dict, if no `deliver_id` found in any checked location, or if found `deliver_id` is empty/whitespace
- **Caller action:** Caller must check for `None` and handle missing identifier appropriately

### `is_valid_job_id(identifier: str) -> bool`
- **Exception:** None
- **Conditions:** Returns `False` if identifier is empty or whitespace-only, `True` otherwise
- **Caller action:** Use for validation before using identifier

### `is_valid_deliver_id(identifier: str) -> bool`
- **Exception:** None
- **Conditions:** Returns `False` if identifier is empty or whitespace-only, `True` otherwise
- **Caller action:** Use for validation before using identifier

## Config Dependency

**No config keys used in this task** (identifier extraction is response parsing, not configuration-driven).

## Test Plan

**Test file:** `tests/test_identifier_extraction.py` (to be created in separate tactical task)

**Test functions:**
- `test_extract_job_id_from_queue_response()` - Test job_id extraction from various queue response formats
- `test_extract_job_id_returns_none_when_missing()` - Test that extraction returns None when job_id not present
- `test_extract_deliver_id_from_execute_async_response()` - Test deliver_id extraction from execute_async response
- `test_extract_deliver_id_returns_none_when_missing()` - Test that extraction returns None when deliver_id not present
- `test_job_id_and_deliver_id_are_distinct_types()` - Test that type system prevents mixing JobId and DeliverId
- `test_is_valid_job_id()` - Test validation function
- `test_is_valid_deliver_id()` - Test validation function

**Fixtures/mocks:** None required (pure function tests)

## Concrete Examples

### Example 1: Extract job_id from queue response
**Input:**
```python
result = {
    "mode": "queued",
    "job_id": "abc123",
    "status": "pending"
}
```
**Output:** `JobId("abc123")`

### Example 2: Extract job_id from nested queue response
**Input:**
```python
result = {
    "result": {
        "data": {
            "job_id": "xyz789"
        }
    }
}
```
**Output:** `JobId("xyz789")`

### Example 3: Extract deliver_id from execute_async response
**Input:**
```python
result = {
    "accepted": True,
    "deliver_id": "deliver-abc-123"
}
```
**Output:** `DeliverId("deliver-abc-123")`

### Example 4: Extract deliver_id from nested execute_async response
**Input:**
```python
result = {
    "result": {
        "deliver_id": "deliver-xyz-789"
    }
}
```
**Output:** `DeliverId("deliver-xyz-789")`

### Example 5: Missing identifier returns None
**Input:**
```python
result = {
    "mode": "immediate",
    "result": {"data": "some data"}
}
```
**Output:** `None` (for both job_id and deliver_id extraction)

## Algorithm/Logic Description

### `_extract_job_id_from_response(result: Dict[str, Any]) -> Optional[JobId]`
1. If `result` is not a dict, return `None`
2. Check `result.get("job_id")` - if present and non-empty string, strip whitespace and return as `JobId`
3. Check `result.get("result", {}).get("job_id")` - if present and non-empty string, strip whitespace and return as `JobId`
4. Check `result.get("result", {}).get("data", {})` - if it's a dict with `job_id` key, extract and return as `JobId` if non-empty
5. Check `result.get("data", {})` - if it's a dict with `job_id` key, extract and return as `JobId` if non-empty
6. Return `None` if no valid job_id found

### `_extract_deliver_id_from_response(result: Dict[str, Any]) -> Optional[DeliverId]`
1. If `result` is not a dict, return `None`
2. Check `result.get("deliver_id")` - if present and non-empty string, strip whitespace and return as `DeliverId`
3. Check `result.get("result", {}).get("deliver_id")` - if present and non-empty string, strip whitespace and return as `DeliverId`
4. Check `result.get("result", {}).get("data", {}).get("deliver_id")` - if present and non-empty string, strip whitespace and return as `DeliverId`
5. Check `result.get("data", {}).get("deliver_id")` - if present and non-empty string, strip whitespace and return as `DeliverId`
6. Return `None` if no valid deliver_id found

### `is_valid_job_id(identifier: str) -> bool`
1. Check if `identifier` is a non-empty string after stripping whitespace
2. Return `True` if valid, `False` otherwise

### `is_valid_deliver_id(identifier: str) -> bool`
1. Check if `identifier` is a non-empty string after stripping whitespace
2. Return `True` if valid, `False` otherwise

## Forbidden Approaches

1. **DO NOT** use `_extract_job_id_from_response()` for `execute_async` responses (use `_extract_deliver_id_from_response()` instead)
2. **DO NOT** assume `job_id` and `deliver_id` are the same value (they are distinct identifier types)
3. **DO NOT** collapse `deliver_id` into `job_id` unless adapter explicitly guarantees equivalence (no such guarantee exists)
4. **DO NOT** expose JSON-RPC request IDs (they are transport-internal)
5. **DO NOT** create identifier extraction that depends on adapter internals (use only response payload structure)
