# Atomic Steps Index: Update Maintained Real-Server Scripts

## Goal
Update all maintained real-server test scripts and pipelines that target `localhost:8001` with `mtls`/`mtls_certificates` to work correctly with the synchronized client architecture from Steps 1-3.

## Parent Documents
- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

## Atomic Steps

### Step 1: Update run_real_server_mtls_test.py
**File**: `update-run-real-server-mtls-test.md`
**Target**: `scripts/run_real_server_mtls_test.py`
**Dependencies**: Steps 1-3 (adapter-centric-client-foundation, embed-command-and-result-contract-alignment, queue-and-websocket-identifier-separation)
**Key Changes**:
- Verify identifier handling (job_id extraction, not JSON-RPC id)
- Add immediate mode handling
- Verify context manager usage
- Verify certificate path resolution

### Step 2: Update run_bidirectional_ws_performance.py
**File**: `update-run-bidirectional-ws-performance.md`
**Target**: `scripts/run_bidirectional_ws_performance.py`
**Dependencies**: Steps 1-3
**Key Changes**:
- Verify identifier handling in all job submission functions
- Verify immediate mode handling in all waiting functions
- Verify context manager usage
- Verify certificate path resolution

### Step 3: Update run_real_server_performance.py
**File**: `update-run-real-server-performance.md`
**Target**: `scripts/run_real_server_performance.py`
**Dependencies**: Steps 1-3
**Key Changes**:
- Fix context manager usage (replace manual `__aenter__`/`close()` with `async with`)
- Verify identifier handling
- Verify immediate mode handling
- Verify certificate path resolution

### Step 4: Update compare_direct_vs_client.py
**File**: `update-compare-direct-vs-client.md`
**Target**: `scripts/compare_direct_vs_client.py`
**Dependencies**: Steps 1-3
**Key Changes**:
- Verify context manager usage
- Verify certificate path resolution for both config file and programmatic config

### Step 5: Update run_cuda_stress.py
**File**: `update-run-cuda-stress.md`
**Target**: `scripts/run_cuda_stress.py`
**Dependencies**: Steps 1-3
**Key Changes**:
- Verify identifier handling
- Add immediate mode handling in `_embed_and_report`
- Verify context manager usage
- Verify certificate path resolution

### Step 6: Update run_timing_statistics.py
**File**: `update-run-timing-statistics.md`
**Target**: `scripts/run_timing_statistics.py`
**Dependencies**: Steps 1-3
**Key Changes**:
- Fix context manager usage (replace manual `__aenter__`/`close()` with `async with`)
- Verify certificate path resolution

### Step 7: Update run_batch_performance.py
**File**: `update-run-batch-performance.md`
**Target**: `scripts/run_batch_performance.py`
**Dependencies**: Steps 1-3
**Key Changes**:
- Fix context manager usage (replace manual `__aenter__`/`close()` with `async with`)
- Verify certificate path resolution

### Step 8: Update run_testing_client_performance.py
**File**: `update-run-testing-client-performance.md`
**Target**: `scripts/run_testing_client_performance.py`
**Dependencies**: Steps 1-3
**Key Changes**:
- Verify context manager usage
- Verify certificate path resolution when generating config
- Verify adapter-backed client construction

## Parallel Execution

All atomic steps can be executed in parallel because:
1. Each step modifies a different script file
2. All steps depend only on Steps 1-3 (which are already complete)
3. No step depends on another atomic step in this tactical task

## Common Patterns Across All Steps

### Identifier Handling
- Always use `result.get("job_id")` (safe extraction), never `result["job_id"]` or `result.get("id")`
- Never use JSON-RPC request `id` as job identifier
- Always use extracted `job_id` for status/waiting operations

### Immediate Mode Handling
- If `job_id` is None, check for immediate result (presence of `"embeddings"`/`"results"` or `mode == "immediate"`)
- Handle immediate results correctly (no waiting needed)
- Handle queued results correctly (extract job_id and wait)

### Context Manager Usage
- Always use `async with EmbeddingServiceAsyncClient.from_config(config) as client:` or `async with EmbeddingServiceClient.from_config(config_path) as client:`
- Never use manual `__aenter__`/`close()` pattern
- All client operations must be inside the `async with` block

### Certificate Path Resolution
- Always resolve relative paths using `PROJECT_ROOT` before passing to config
- Always call `_resolve_cert_paths` after `config.load_config()` when loading from file
- Always convert paths to strings when passing to config creation methods

## Validation Requirements

Each step must pass:
1. Syntax check (`python -m py_compile`)
2. Type check (`mypy`, if configured)
3. Lint check (`flake8`)
4. Format check (`black --check`)
5. Manual verification (`--help` flag)

## Completion Criteria

All atomic steps are complete when:
1. All 8 script files are updated
2. All validation commands pass for each script
3. All scripts use adapter-backed client construction
4. All scripts correctly handle identifier separation
5. All scripts correctly handle both immediate and queued result modes
6. All scripts use context manager for client lifecycle
7. All scripts resolve certificate paths correctly
