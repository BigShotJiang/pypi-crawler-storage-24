# Atomic Step: Update Timeout Default in run_bidirectional_ws_performance.py

## Executor Role
`coder_auto` — implement the code changes described in this step.

## Execution Directive
Update timeout defaults in `scripts/run_bidirectional_ws_performance.py` from 60.0 seconds to 300.0 seconds in both the function signature and argparse default to match server performance characteristics.

## Parent Links
- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

## Step Scope
**Target file**: `scripts/run_bidirectional_ws_performance.py`
**Action**: modify

## Dependency Contract
- Depends on: Steps 1-3 (adapter-centric-client-foundation, embed-command-and-result-contract-alignment, queue-and-websocket-identifier-separation)
- No dependencies on other atomic steps in this tactical task
- Can execute in parallel with other timeout policy update steps

## Required Context
The script `run_bidirectional_ws_performance.py` currently uses a default timeout of 60.0 seconds, which may be too conservative for current server performance. The timeout policy needs to be updated to 300.0 seconds to match other performance scripts and server characteristics. This is a configuration/timeout policy change only — no client code logic changes.

## Read First
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` — timeout policy context
2. `/home/vasilyvz/projects/embed-client/scripts/run_bidirectional_ws_performance.py` — current script implementation
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md` — tactical task context (lines 99-103)

## Expected File Change
The file `scripts/run_bidirectional_ws_performance.py` will be modified to:
1. Change default timeout from 60.0 to 300.0 in `main_async()` function signature (line 283)
2. Change default timeout from 60.0 to 300.0 in argparse default (line 368)
3. Preserve `--timeout` argument functionality (users can still override)

## Forbidden Alternatives
- Do NOT change client code logic (this is timeout policy only)
- Do NOT remove `--timeout` argument functionality
- Do NOT change timeout values in other locations (only function signature and argparse default)
- Do NOT modify timeout handling logic, only default values

## Atomic Operations

### Operation 1: Update Function Signature Default

**Location**: Function `main_async`, line 283

**Current code**:
```python
async def main_async(
    iterations: int = 5,
    timeout: float = 60.0,
    compare_polling: bool = False,
    poll_interval: float = 0.3,
) -> int:
```

**Required change**:
```python
async def main_async(
    iterations: int = 5,
    timeout: float = 300.0,
    compare_polling: bool = False,
    poll_interval: float = 0.3,
) -> int:
```

**Algorithm**:
1. Locate the `main_async` function definition starting at line 281
2. Find the `timeout: float = 60.0` parameter on line 283
3. Replace `60.0` with `300.0` in the function signature
4. Ensure the change is exact: `timeout: float = 300.0`

**Exact replacement**:
- **old_string**: `    timeout: float = 60.0,`
- **new_string**: `    timeout: float = 300.0,`

### Operation 2: Update Argparse Default

**Location**: Function `main`, line 368

**Current code**:
```python
    parser.add_argument(
        "--timeout",
        type=float,
        default=60.0,
        help="Max wait per job in seconds (default: 60)",
    )
```

**Required change**:
```python
    parser.add_argument(
        "--timeout",
        type=float,
        default=300.0,
        help="Max wait per job in seconds (default: 300)",
    )
```

**Algorithm**:
1. Locate the `parser.add_argument` call for `--timeout` starting around line 365
2. Find the `default=60.0` parameter on line 368
3. Replace `default=60.0` with `default=300.0`
4. Update the help text from `(default: 60)` to `(default: 300)` for consistency

**Exact replacement**:
- **old_string**: 
```python
    parser.add_argument(
        "--timeout",
        type=float,
        default=60.0,
        help="Max wait per job in seconds (default: 60)",
    )
```
- **new_string**:
```python
    parser.add_argument(
        "--timeout",
        type=float,
        default=300.0,
        help="Max wait per job in seconds (default: 300)",
    )
```

## Expected Deliverables
1. Updated `scripts/run_bidirectional_ws_performance.py` with:
   - Timeout default changed from 60.0 to 300.0 in `main_async()` function signature
   - Timeout default changed from 60.0 to 300.0 in argparse default
   - Help text updated to reflect new default (300 instead of 60)
   - `--timeout` argument functionality preserved (users can still override)

## Mandatory Validation

### Validation Commands
1. **Syntax check**:
   ```bash
   python -m py_compile scripts/run_bidirectional_ws_performance.py
   ```
   Expected: No output (exit code 0)

2. **Type check** (if mypy is configured):
   ```bash
   mypy scripts/run_bidirectional_ws_performance.py --ignore-missing-imports
   ```
   Expected: "Success: no issues found" or acceptable type warnings

3. **Lint check**:
   ```bash
   flake8 scripts/run_bidirectional_ws_performance.py --max-line-length=120 --ignore=E501,W503
   ```
   Expected: No output (exit code 0) or only acceptable warnings

4. **Black format check**:
   ```bash
   black --check scripts/run_bidirectional_ws_performance.py
   ```
   Expected: "would reformat" or "already well formatted"

5. **Verify timeout defaults**:
   ```bash
   python scripts/run_bidirectional_ws_performance.py --help | grep -A 1 timeout
   ```
   Expected: Help text shows `(default: 300)` or `default: 300.0`

6. **Verify function signature** (manual inspection):
   ```bash
   grep -n "timeout: float = " scripts/run_bidirectional_ws_performance.py
   ```
   Expected: Line shows `timeout: float = 300.0`

### Test Expectations
- Script should execute without syntax errors
- Script should show timeout default of 300.0 in help message
- Script should accept `--timeout` argument to override default
- Function signature should have `timeout: float = 300.0`
- Argparse should have `default=300.0`

## Decision Rules
1. **Function signature default**: Always match argparse default for consistency
2. **Help text**: Always update help text to reflect new default value
3. **Argument preservation**: Always preserve `--timeout` argument functionality (users can override)
4. **No logic changes**: Only change default values, not timeout handling logic

## Edge Cases
- If `--timeout` is explicitly provided, it should override the default (existing behavior preserved)
- If timeout is passed programmatically to `main_async()`, it should use the provided value (existing behavior preserved)
- If timeout is None, it should be handled by downstream code (existing behavior preserved)

## Constants and Literals
- **Old default timeout**: `60.0` (float, seconds)
- **New default timeout**: `300.0` (float, seconds)
- **Location 1**: Function parameter default in `main_async()` signature (line 283)
- **Location 2**: Argparse `default` parameter (line 368)
- **Location 3**: Help text string `(default: 60)` → `(default: 300)` (line 369)

## Blackstops
Stop and escalate if:
- Function signature or argparse structure has changed significantly from expected pattern
- Timeout handling logic needs modification (this step is timeout policy only)
- Changes conflict with other timeout-related modifications

## Handoff Package
- Updated `scripts/run_bidirectional_ws_performance.py` file
- All validation commands pass
- Timeout defaults verified to be 300.0 in both locations
- Script ready for execution with new timeout defaults
