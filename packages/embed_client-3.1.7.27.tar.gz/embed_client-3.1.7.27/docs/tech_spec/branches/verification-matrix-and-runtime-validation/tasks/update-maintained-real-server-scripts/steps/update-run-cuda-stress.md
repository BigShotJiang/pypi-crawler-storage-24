# Atomic Step: Update run_cuda_stress.py

## Executor Role
`coder_auto` — implement the code changes described in this step.

## Execution Directive
Update `scripts/run_cuda_stress.py` to ensure it fully complies with the synchronized client architecture from Steps 1-3. Verify and fix identifier handling, result mode handling, and adapter-backed client construction patterns.

## Parent Links
- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

## Step Scope
**Target file**: `scripts/run_cuda_stress.py`
**Action**: modify

## Dependency Contract
- Depends on: Steps 1-3 (adapter-centric-client-foundation, embed-command-and-result-contract-alignment, queue-and-websocket-identifier-separation)
- No dependencies on other atomic steps in this tactical task
- Can execute in parallel with other script update steps

## Required Context
The script `run_cuda_stress.py` performs CUDA memory stress testing on localhost:8001 with mTLS. It must:
1. Use adapter-backed client construction via `EmbeddingServiceAsyncClient.from_config(config)`
2. Correctly extract `job_id` from `submit_job` results (not JSON-RPC request `id`)
3. Handle both immediate and queued result modes correctly
4. Use `job_id` for `wait_for_job_via_websocket` calls (not JSON-RPC request id)
5. Use context manager (`async with`) for proper resource cleanup

## Read First
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` — identifier model and result mode contracts
2. `/home/vasilyvz/projects/embed-client/scripts/run_cuda_stress.py` — current script implementation
3. `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` — client construction and method signatures
4. `/home/vasilyvz/projects/embed-client/embed_client/config.py` — ClientConfig.create_mtls_config signature

## Expected File Change
The file `scripts/run_cuda_stress.py` will be modified to:
1. Ensure `job_id` extraction uses `result.get("job_id")` (safe extraction, not `result["job_id"]`)
2. Verify immediate mode handling is correct (when `job_id` is None, handle immediate result)
3. Ensure all `wait_for_job_via_websocket` calls use extracted `job_id` (not JSON-RPC request id)
4. Verify context manager usage is correct (`async with EmbeddingServiceAsyncClient.from_config(config)`)
5. Ensure certificate paths are resolved correctly relative to PROJECT_ROOT

## Forbidden Alternatives
- Do NOT use JSON-RPC request `id` as job identifier
- Do NOT assume all results are queued (must handle immediate mode)
- Do NOT use direct client instantiation (must use `from_config`)
- Do NOT bypass context manager (must use `async with`)
- Do NOT pass JSON-RPC request id to `wait_for_job_via_websocket` (must use `job_id`)

## Atomic Operations

### Operation 1: Verify Identifier Handling in `_embed_and_report`

**Location**: Function `_embed_and_report`, around line 76-124

**Current pattern** (should already be correct):
```python
submit = await client.submit_job(
    command="embed_queue",
    params={"texts": texts, "error_policy": "continue"},
)
job_id = submit.get("job_id")
```

**Verification**:
1. Ensure `job_id` extraction uses `submit.get("job_id")` (safe `.get()` method, not `submit["job_id"]`)
2. Ensure no use of `submit.get("id")` or `submit["id"]` (JSON-RPC request id)
3. Ensure immediate mode is handled: if `job_id` is None, check for immediate result

**If incorrect**, fix to use `submit.get("job_id")` pattern.

### Operation 2: Verify Immediate Mode Handling in `_embed_and_report`

**Location**: Function `_embed_and_report`, around line 93-98

**Current pattern** (should already be correct):
```python
job_id = submit.get("job_id")
if not job_id:
    elapsed = time.perf_counter() - t0
    return False, f"{label}: no job_id returned ({elapsed:.1f}s)"
```

**Verification**:
1. Ensure immediate mode is detected: if `job_id` is None, check if result contains embeddings
2. If immediate mode detected, extract and validate embeddings from `submit` result
3. If immediate mode, return success with timing info
4. Only return error if neither queued nor immediate mode is detected

**Required fix** (if immediate mode handling is missing):
```python
job_id = submit.get("job_id")
if not job_id:
    # Check for immediate result mode
    elapsed = time.perf_counter() - t0
    data = submit if isinstance(submit, dict) else {}
    embeddings = extract_embeddings(data)
    if len(embeddings) >= len(texts):
        # Immediate mode: result is already complete
        first_val = embeddings[0][0] if embeddings and embeddings[0] else None
        if isinstance(first_val, (int, float)):
            dim = len(embeddings[0])
            return True, (
                f"{label}: OK (immediate) — {len(embeddings)} emb, dim={dim}, "
                f"first={first_val:.6f} ({elapsed:.1f}s)"
            )
    # Error: expected queued but no job_id and not immediate
    return False, f"{label}: no job_id returned ({elapsed:.1f}s)"
```

### Operation 3: Verify `job_id` Usage in WebSocket Waiting

**Location**: Function `_embed_and_report`, around line 98

**Current pattern** (should already be correct):
```python
result = await client.wait_for_job_via_websocket(job_id, timeout=timeout)
```

**Verification**:
1. Ensure `wait_for_job_via_websocket` is only called when `job_id` is not None
2. Ensure `job_id` passed to `wait_for_job_via_websocket` is the extracted `job_id`, not JSON-RPC request id
3. Ensure `job_id` is used consistently throughout the function

**If incorrect**, fix to use `job_id` correctly.

### Operation 4: Verify Context Manager Usage

**Location**: Function `main_async`, around line 271

**Current pattern** (should already be correct):
```python
async with EmbeddingServiceAsyncClient.from_config(config) as client:
    # ... test code
```

**Verification**:
1. Ensure the `async with` statement is used (not manual `__aenter__`/`__aexit__`)
2. Ensure all client operations are inside the `async with` block
3. No manual `await client.close()` calls needed (context manager handles it)

**If incorrect**, fix to use `async with` pattern.

### Operation 5: Verify Certificate Path Resolution

**Location**: Function `_make_mtls_config`, around line 56-66

**Current pattern** (should already be correct):
```python
cert_dir = PROJECT_ROOT / "mtls_certificates" / "client"
ca_dir = PROJECT_ROOT / "mtls_certificates" / "ca"
return ClientConfig.create_mtls_config(
    host="localhost",
    port=8001,
    cert_file=str(cert_dir / "embedding-service.crt"),
    key_file=str(cert_dir / "embedding-service.key"),
    ca_cert_file=str(ca_dir / "ca.crt"),
)
```

**Verification**:
1. Ensure certificate paths are resolved relative to `PROJECT_ROOT`
2. Ensure paths are converted to strings using `str()` before passing to `create_mtls_config`
3. Ensure all three certificate files (cert, key, ca) are specified

**If incorrect**, fix to resolve paths correctly.

## Expected Deliverables
1. Updated `scripts/run_cuda_stress.py` with:
   - Correct identifier handling (job_id extraction, not JSON-RPC id)
   - Immediate mode handling in `_embed_and_report`
   - Proper use of `job_id` for WebSocket waiting operations
   - Proper context manager usage
   - Correct certificate path resolution

## Mandatory Validation

### Validation Commands
1. **Syntax check**:
   ```bash
   python -m py_compile scripts/run_cuda_stress.py
   ```
   Expected: No output (exit code 0)

2. **Type check** (if mypy is configured):
   ```bash
   mypy scripts/run_cuda_stress.py --ignore-missing-imports
   ```
   Expected: "Success: no issues found" or acceptable type warnings

3. **Lint check**:
   ```bash
   flake8 scripts/run_cuda_stress.py --max-line-length=120 --ignore=E501,W503
   ```
   Expected: No output (exit code 0) or only acceptable warnings

4. **Black format check**:
   ```bash
   black --check scripts/run_cuda_stress.py
   ```
   Expected: "would reformat" or "already well formatted"

5. **Manual verification** (if server available):
   ```bash
   python scripts/run_cuda_stress.py --help
   ```
   Expected: Help message displayed, exit code 0

### Test Expectations
- Script should execute without syntax errors
- Script should handle both immediate and queued result modes
- Script should correctly extract `job_id` from queued results
- Script should not use JSON-RPC request `id` as job identifier
- Script should use `job_id` for all WebSocket waiting operations
- Script should use context manager for client lifecycle

## Decision Rules
1. **Identifier extraction**: Always use `result.get("job_id")` (safe extraction), never `result["job_id"]` or `result.get("id")`
2. **Immediate mode detection**: If `job_id` is None, check for embeddings in submit result and validate them
3. **WebSocket waiting**: Always use extracted `job_id` for `wait_for_job_via_websocket` calls, never JSON-RPC request id
4. **Context manager**: Always use `async with EmbeddingServiceAsyncClient.from_config(config) as client:`
5. **Certificate paths**: Always resolve relative paths using `PROJECT_ROOT` before passing to config

## Blackstops
Stop and escalate if:
- Script requires changes to core client architecture (affects Steps 1-3)
- Script reveals bugs in synchronized client that require global fixes
- Script execution reveals contradictions between adapter behavior and expected server contract

## Handoff Package
- Updated `scripts/run_cuda_stress.py` file
- All validation commands pass
- Script ready for execution on `localhost:8001` with mTLS certificates
