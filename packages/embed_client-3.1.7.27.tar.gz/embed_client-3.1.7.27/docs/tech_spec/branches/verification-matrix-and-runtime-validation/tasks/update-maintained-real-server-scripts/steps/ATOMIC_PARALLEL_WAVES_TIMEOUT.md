# Atomic Parallel Waves: Timeout Policy Improvements (Step 4)

## Overview
This document defines parallel execution waves for timeout policy improvement atomic steps. All steps are independent and can execute in parallel.

## Wave 1: Parallel Timeout Updates (All Steps)

All three timeout policy update steps can execute in parallel because:
- Each modifies a different script file
- No cross-file dependencies
- No shared state or resources
- All depend only on Steps 1-3 (already complete)

### Wave 1 Steps (Parallel Execution)

1. **Step 4.1**: `update-timeout-bidirectional-ws-performance.md`
   - Target: `scripts/run_bidirectional_ws_performance.py`
   - Changes: 60.0 → 300.0 in function signature and argparse

2. **Step 4.2**: `update-timeout-compare-direct-vs-client.md`
   - Target: `scripts/compare_direct_vs_client.py`
   - Changes: 60.0 → 300.0 in function signature and argparse

3. **Step 4.3**: `update-timeout-batch-performance.md`
   - Target: `scripts/run_batch_performance.py`
   - Changes: 120.0 → 300.0 in argparse

### Execution Order
- **All steps in Wave 1**: Execute in parallel
- **No sequential dependencies**: All steps are independent

### Completion Criteria
Wave 1 is complete when:
- All three scripts have updated timeout defaults
- All validation commands pass for each script
- All scripts preserve `--timeout` argument functionality

## Summary

- **Total waves**: 1
- **Total steps**: 3
- **Parallel steps**: 3
- **Sequential steps**: 0
- **Estimated parallel execution time**: Time of longest step (all steps are similar complexity)
