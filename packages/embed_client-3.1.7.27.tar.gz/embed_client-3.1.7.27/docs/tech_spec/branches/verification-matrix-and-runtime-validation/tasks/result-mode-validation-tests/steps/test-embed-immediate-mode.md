Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Test Embed Immediate Mode

## Executor Role

`coder_auto` - implements test file for immediate JSON-RPC result mode validation.

## Execution Directive

Create test file `tests/test_embed_immediate_mode.py` that validates immediate JSON-RPC result mode behavior. The test file must verify that the client correctly detects immediate results (no job_id), normalizes result structure, and does not invent job_id for immediate results.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/result-mode-validation-tests.md`

## Step Scope

**Target file**: `tests/test_embed_immediate_mode.py`
**Action**: create

This step creates a new test file that validates immediate JSON-RPC result mode. The file must test:
- Immediate result detection (no job_id in response)
- Result normalization (embeddings, results, model, dimension, device fields)
- Result structure matches server contract
- No job_id is invented or exposed for immediate results

## Dependency Contract

**Prerequisites**:
- Step 1: adapter-centric-client-foundation (must complete first)
- Step 2: embed-command-and-result-contract-alignment (must complete first)
- Step 3: queue-and-websocket-identifier-separation (must complete first)

**Dependencies on other atomic steps**:
- None (this step can run in parallel with other test file creation steps)

**Downstream dependencies**:
- None (this is a test file, no code depends on it)

## Required Context

The test file must validate:
1. Immediate result detection: when server returns final embedding payload directly (no job_id), client must detect this as immediate mode
2. Result normalization: immediate results must be normalized to match server contract structure
3. No job_id invention: client must not create or expose job_id for immediate results
4. Result structure: immediate results must contain expected fields (embeddings, results, model, dimension, device)

## Read First

Before implementing, read these files:
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - for result mode contracts and identifier model
2. `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` - for client methods and result structures
3. `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` - for embed() method and result normalization
4. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - for adapter response formats
5. `/home/vasilyvz/projects/embed-client/tests/conftest.py` - for existing test fixtures and patterns
6. `/home/vasilyvz/projects/embed-client/tests/test_async_client.py` - for test structure examples

## Expected File Change

**File**: `tests/test_embed_immediate_mode.py`
**Action**: create

The file must contain:
- File header docstring with author and email
- Import statements (pytest, asyncio, EmbeddingServiceAsyncClient, exceptions, etc.)
- Test class `TestEmbedImmediateMode` with pytest-style test methods
- Test methods for immediate result detection, normalization, structure validation, and no job_id verification
- Proper async test fixtures and mock setup if needed

## Forbidden Alternatives

- Do NOT assume all results are immediate (must handle queued mode in separate tests)
- Do NOT use JSON-RPC request id as job_id
- Do NOT invent job_id for immediate results
- Do NOT skip result normalization validation
- Do NOT create tests that depend on real server (use mocks or fixtures)
- Do NOT modify core client implementation files
- Do NOT use unittest.TestCase if project uses pytest (check conftest.py pattern)

## Atomic Operations

### File Structure

1. **File header docstring**:
   - Author: Vasiliy Zdanovskiy
   - email: vasilyvz@gmail.com
   - Brief description: "Tests for immediate JSON-RPC result mode validation"

2. **Import section** (exact imports required):
   ```python
   import pytest
   import pytest_asyncio
   from typing import Dict, Any, Optional
   from unittest.mock import AsyncMock, MagicMock, patch
   from embed_client.async_client import EmbeddingServiceAsyncClient
   from embed_client.exceptions import (
       EmbeddingServiceError,
       EmbeddingServiceAPIError,
       EmbeddingServiceTimeoutError,
   )
   from embed_client.config import ClientConfig
   ```

3. **Test class**: `TestEmbedImmediateMode`
   - Base: pytest class (no base class needed, use pytest fixtures)
   - Purpose: Test immediate JSON-RPC result mode

### Test Methods

#### Method 1: `test_immediate_result_detection() -> None`

**Purpose**: Verify immediate result is detected correctly (no job_id in response)

**Algorithm**:
1. Create mock adapter transport that returns immediate result (no job_id)
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test text"], wait=True)` or `embed(texts=["test text"])`
4. Assert result does not contain "job_id" key at any level
5. Assert result contains final business payload (either "results" or "embeddings" key)
6. Assert result structure indicates immediate mode (no queue-related fields)

**Expected result structure**:
- `{"results": [...], "embeddings": [...], "model": "...", "dimension": 768, "device": "cpu"}` OR
- `{"embeddings": [...], "model": "...", "dimension": 768, "device": "cpu"}`

**Error handling**:
- If result contains job_id: test fails with assertion error
- If result does not contain embeddings/results: test fails with assertion error

**Edge cases**:
- Empty texts list: should raise validation error (not tested here, covered in API tests)
- None result: should raise assertion error
- Result with mode="immediate" but also job_id: should fail (invalid server response)

#### Method 2: `test_immediate_result_normalization() -> None`

**Purpose**: Verify result normalization matches server contract

**Algorithm**:
1. Create mock adapter transport that returns immediate result with server contract structure
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test text 1", "test text 2"], model="test-model", dimension=768, device="cpu")`
4. Extract result from embed() call
5. Assert result contains "results" list OR "embeddings" list (at least one)
6. If "results" present: assert each result item contains expected fields (body, embedding, tokens, bm25_tokens)
7. If "embeddings" present: assert embeddings is a list of lists (or list of arrays)
8. Assert result contains "model" field matching input model
9. Assert result contains "dimension" field matching input dimension
10. Assert result contains "device" field matching input device

**Expected normalized structure**:
- `{"results": [{"body": "text", "embedding": [...], "tokens": [...], "bm25_tokens": [...]}], "model": "test-model", "dimension": 768, "device": "cpu"}` OR
- `{"embeddings": [[...], [...]], "model": "test-model", "dimension": 768, "device": "cpu"}`

**Error handling**:
- If normalization fails: test fails with assertion error
- If required fields missing: test fails with assertion error

**Edge cases**:
- Result with both "results" and "embeddings": both should be valid (test should pass)
- Result with only "results": should pass
- Result with only "embeddings": should pass
- Result with neither "results" nor "embeddings": should fail

#### Method 3: `test_immediate_result_structure() -> None`

**Purpose**: Verify result structure matches server contract exactly

**Algorithm**:
1. Create mock adapter transport that returns immediate result matching server contract
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test"])` with wait=True or default
4. Extract result
5. Assert result is a dictionary
6. Assert result does NOT contain "job_id" key
7. Assert result does NOT contain "status" key (queue-related)
8. Assert result does NOT contain "mode" key with value "queued"
9. Assert result contains at least one of: "results", "embeddings"
10. If "results" present: assert it is a list, assert each item is a dict
11. If "embeddings" present: assert it is a list, assert each item is a list or array

**Expected structure validation**:
- Type checks: result must be dict
- Forbidden keys: "job_id", "status" (queue-related), "mode"="queued"
- Required keys: at least one of "results" or "embeddings"
- Type checks for nested structures

**Error handling**:
- If structure does not match: test fails with assertion error
- If forbidden keys present: test fails with assertion error

**Edge cases**:
- Result with mode="immediate": should pass (explicit mode marker is OK)
- Result with extra fields: should pass (as long as required fields present and forbidden fields absent)
- Result with null/None values in required fields: should fail

#### Method 4: `test_immediate_no_job_id() -> None`

**Purpose**: Verify no job_id is present or invented for immediate results

**Algorithm**:
1. Create mock adapter transport that returns immediate result (no job_id at any level)
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test"])`
4. Extract result
5. Assert "job_id" not in result (top level)
6. Assert "job_id" not in result.get("result", {}) (nested in result)
7. Assert "job_id" not in result.get("result", {}).get("data", {}) (nested in result.data)
8. Assert "job_id" not in result.get("data", {}) (top-level data)
9. Assert result contains final business payload (embeddings or results)

**Identifier separation validation**:
- Verify job_id is not present at any nesting level
- Verify JSON-RPC request id (if exposed) is not used as job_id
- Verify result is treated as immediate (final payload present)

**Error handling**:
- If job_id found at any level: test fails with assertion error
- If result does not contain final payload: test fails with assertion error

**Edge cases**:
- Result with job_id=None: should fail (job_id key should not exist at all)
- Result with empty string job_id: should fail (job_id should not exist)
- Result with job_id in unexpected nested location: should fail

### Test Fixtures

**Fixture**: `mock_immediate_result() -> Dict[str, Any]`
- Returns: Dictionary representing immediate result from server
- Structure: `{"results": [...], "embeddings": [...], "model": "...", "dimension": 768, "device": "cpu"}`
- Purpose: Reusable mock data for immediate results

**Fixture**: `mock_adapter_transport_immediate() -> AsyncMock`
- Returns: Mocked AdapterTransport that returns immediate results
- Purpose: Mock transport layer for immediate mode tests
- Behavior: `execute_command_unified()` returns immediate result dict

### Constants and Literals

- Test texts: `["test text"]`, `["test text 1", "test text 2"]`
- Test model: `"test-model"`
- Test dimension: `768`
- Test device: `"cpu"`
- Expected result keys: `"results"`, `"embeddings"`, `"model"`, `"dimension"`, `"device"`
- Forbidden keys: `"job_id"`, `"status"` (when indicating queue mode)
- Expected status values for immediate: none (no status field expected)

## Expected Deliverables

1. File `tests/test_embed_immediate_mode.py` created
2. File contains class `TestEmbedImmediateMode` with 4 test methods
3. All test methods are async and use pytest-asyncio
4. All test methods validate immediate result mode behavior
5. File follows project code style (black, flake8, mypy compliant)
6. File contains proper docstrings and type annotations

## Mandatory Validation

After implementation, run these exact commands:

1. **Format check**:
   ```bash
   black tests/test_embed_immediate_mode.py
   ```
   Expected: "reformatted" or "already well formatted" (exit 0)

2. **Lint check**:
   ```bash
   flake8 tests/test_embed_immediate_mode.py
   ```
   Expected: no output (exit 0)

3. **Type check**:
   ```bash
   mypy tests/test_embed_immediate_mode.py
   ```
   Expected: "Success: no issues found" (exit 0)

4. **Test execution**:
   ```bash
   pytest tests/test_embed_immediate_mode.py -v
   ```
   Expected: all tests PASSED (may require mocks/fixtures to be set up correctly)

**All validation commands must pass before considering this step complete.**

## Decision Rules

1. **Test framework**: Use pytest (not unittest) based on conftest.py patterns
2. **Async tests**: Use `@pytest.mark.asyncio` decorator for async test methods
3. **Mocking strategy**: Mock AdapterTransport, not internal adapter client
4. **Result structure**: Accept both "results" and "embeddings" formats (server may return either)
5. **Identifier validation**: Check all nesting levels for job_id (top-level, result, result.data, data)
6. **Error assertions**: Use pytest.raises() for exception testing if needed

## Blackstops

Stop and escalate if:
- Core client implementation needs changes to support immediate mode detection (affects Step 2)
- Adapter response format contradicts expected immediate result structure (affects Step 1)
- Result normalization logic requires changes to async_client_api_mixin (affects Step 2)

## Handoff Package

**For coder_auto**:
- Target file: `tests/test_embed_immediate_mode.py`
- Action: create
- Test class: `TestEmbedImmediateMode`
- Test methods: 4 methods (test_immediate_result_detection, test_immediate_result_normalization, test_immediate_result_structure, test_immediate_no_job_id)
- Required imports: pytest, pytest_asyncio, typing, unittest.mock, embed_client modules
- Validation commands: black, flake8, mypy, pytest
- Expected outcome: All tests pass, file follows project standards
