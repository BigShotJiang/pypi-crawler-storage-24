# Atomic Step: Update run_real_server_performance.py

## Executor Role
`coder_auto` — implement the code changes described in this step.

## Execution Directive
Update `scripts/run_real_server_performance.py` to ensure it fully complies with the synchronized client architecture from Steps 1-3. Verify and fix identifier handling, result mode handling, and adapter-backed client construction patterns.

## Parent Links
- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

## Step Scope
**Target file**: `scripts/run_real_server_performance.py`
**Action**: modify

## Dependency Contract
- Depends on: Steps 1-3 (adapter-centric-client-foundation, embed-command-and-result-contract-alignment, queue-and-websocket-identifier-separation)
- No dependencies on other atomic steps in this tactical task
- Can execute in parallel with other script update steps

## Required Context
The script `run_real_server_performance.py` tests real-server performance with parallel job submission and polling. It must:
1. Use adapter-backed client construction via `EmbeddingServiceAsyncClient.from_config(config)`
2. Correctly extract `job_id` from `submit_job` results (not JSON-RPC request `id`)
3. Handle both immediate and queued result modes correctly
4. Use `job_id` for `job_status` and `wait_for_job` calls (not JSON-RPC request id)
5. Use context manager (`async with`) for proper resource cleanup

## Read First
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` — identifier model and result mode contracts
2. `/home/vasilyvz/projects/embed-client/scripts/run_real_server_performance.py` — current script implementation
3. `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` — client construction and method signatures
4. `/home/vasilyvz/projects/embed-client/embed_client/config.py` — ClientConfig signature

## Expected File Change
The file `scripts/run_real_server_performance.py` will be modified to:
1. Ensure `job_id` extraction uses `result.get("job_id")` (safe extraction, not `result["job_id"]`)
2. Verify immediate mode handling is correct (when `job_id` is None, handle immediate result)
3. Ensure all `job_status` and `wait_for_job` calls use extracted `job_id` (not JSON-RPC request id)
4. Fix context manager usage (currently uses manual `__aenter__`/`close()`, should use `async with`)
5. Ensure certificate paths are resolved correctly relative to PROJECT_ROOT

## Forbidden Alternatives
- Do NOT use JSON-RPC request `id` as job identifier
- Do NOT assume all results are queued (must handle immediate mode)
- Do NOT use direct client instantiation (must use `from_config`)
- Do NOT use manual `__aenter__`/`close()` (must use `async with` context manager)
- Do NOT pass JSON-RPC request id to `job_status` or `wait_for_job` (must use `job_id`)

## Atomic Operations

### Operation 1: Fix Context Manager Usage in `main` Function

**Location**: Function `main`, around line 566-631

**Current pattern** (incorrect):
```python
client = EmbeddingServiceAsyncClient.from_config(config)
try:
    await client.__aenter__()
    # ... test code
finally:
    await client.close()
```

**Required pattern**:
```python
async with EmbeddingServiceAsyncClient.from_config(config) as client:
    # ... test code
    # No manual close() needed
```

**Algorithm**:
1. Find the client instantiation in `main` function (around line 566)
2. Replace manual `__aenter__`/`close()` pattern with `async with` context manager
3. Remove `try`/`finally` block that manually calls `__aenter__` and `close()`
4. Ensure all client operations are inside the `async with` block
5. Remove any `await client.close()` calls (context manager handles cleanup)

### Operation 2: Verify Identifier Handling in `_submit_and_wait_one`

**Location**: Function `_submit_and_wait_one`, around line 137-270

**Current pattern** (should already be correct):
```python
job_info = await client.submit_job("embed", {"texts": texts})
job_id = job_info.get("job_id")
```

**Verification**:
1. Ensure `job_id` extraction uses `job_info.get("job_id")` (safe `.get()` method, not `job_info["job_id"]`)
2. Ensure no use of `job_info.get("id")` or `job_info["id"]` (JSON-RPC request id)
3. Ensure immediate mode is handled: if `job_id` is None, check for immediate result

**If incorrect**, fix to use `job_info.get("job_id")` pattern.

### Operation 3: Verify Immediate Mode Handling in `_submit_and_wait_one`

**Location**: Function `_submit_and_wait_one`, around line 164-193

**Current pattern** (should already be correct):
```python
job_id = job_info.get("job_id")
if not job_id:
    # Server may return immediate result (no queue) when queue disabled or sync path
    if job_info.get("mode") == "immediate" and job_info.get("result") is not None:
        return {
            "status": "ok",
            # ... timing info
        }
    return {
        "status": "no_job_id",
        "error": "submit did not return job_id",
    }
```

**Verification**:
1. Ensure immediate mode is detected: check for `mode == "immediate"` or presence of `"embeddings"`/`"results"` in result
2. Ensure immediate mode returns success status with timing info
3. Ensure error is only returned if neither queued nor immediate mode is detected

**If incorrect**, fix to handle immediate mode correctly.

### Operation 4: Verify `job_id` Usage in Polling Loop

**Location**: Function `_submit_and_wait_one`, around line 195-223

**Current pattern** (should already be correct):
```python
status = await client.job_status(job_id)
# ... check status and poll until done
```

**Verification**:
1. Ensure `job_status` is called with extracted `job_id`, not JSON-RPC request id
2. Ensure polling loop uses `job_id` consistently
3. Ensure timeout and error handling use `job_id` in error messages

**If incorrect**, fix to use `job_id` correctly.

### Operation 5: Verify Certificate Path Resolution

**Location**: Function `_make_config`, around line 128-134

**Current pattern** (should already be correct):
```python
def _make_config(config_path: Path) -> ClientConfig:
    path = config_path if config_path.is_absolute() else PROJECT_ROOT / config_path
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")
    config = ClientConfig(str(path))
    config.load_config()
    return config
```

**Verification**:
1. Ensure config path is resolved relative to `PROJECT_ROOT` if not absolute
2. Ensure `FileNotFoundError` is raised if config file doesn't exist
3. Ensure certificate paths in config are resolved (may need `_resolve_cert_paths` helper if config contains relative paths)

**If certificate path resolution is missing**, add helper function similar to other scripts:
```python
def _resolve_cert_paths(config_data: Dict[str, Any]) -> None:
    """Resolve relative cert paths under PROJECT_ROOT (in-place)."""
    for section in ("auth", "ssl"):
        sect = config_data.get(section, {})
        if not isinstance(sect, dict):
            continue
        cert_sect = sect.get("certificate", sect) if section == "auth" else sect
        if not isinstance(cert_sect, dict):
            continue
        for key in ("cert_file", "key_file", "ca_cert_file", "crl_file"):
            val = cert_sect.get(key)
            if isinstance(val, str) and not val.startswith("/"):
                resolved = PROJECT_ROOT / val
                if resolved.exists():
                    cert_sect[key] = str(resolved)
        if section == "ssl" and isinstance(sect, dict):
            for key in ("cert_file", "key_file", "ca_cert_file", "crl_file"):
                val = sect.get(key)
                if isinstance(val, str) and not val.startswith("/"):
                    resolved = PROJECT_ROOT / val
                    if resolved.exists():
                        sect[key] = str(resolved)
```

Then call it in `_make_config`:
```python
config = ClientConfig(str(path))
config.load_config()
_resolve_cert_paths(config.config_data)
return config
```

## Expected Deliverables
1. Updated `scripts/run_real_server_performance.py` with:
   - Correct context manager usage (`async with` instead of manual `__aenter__`/`close()`)
   - Correct identifier handling (job_id extraction, not JSON-RPC id)
   - Immediate mode handling in `_submit_and_wait_one`
   - Proper use of `job_id` for status polling operations
   - Correct certificate path resolution (if needed)

## Mandatory Validation

### Validation Commands
1. **Syntax check**:
   ```bash
   python -m py_compile scripts/run_real_server_performance.py
   ```
   Expected: No output (exit code 0)

2. **Type check** (if mypy is configured):
   ```bash
   mypy scripts/run_real_server_performance.py --ignore-missing-imports
   ```
   Expected: "Success: no issues found" or acceptable type warnings

3. **Lint check**:
   ```bash
   flake8 scripts/run_real_server_performance.py --max-line-length=120 --ignore=E501,W503
   ```
   Expected: No output (exit code 0) or only acceptable warnings

4. **Black format check**:
   ```bash
   black --check scripts/run_real_server_performance.py
   ```
   Expected: "would reformat" or "already well formatted"

5. **Manual verification** (if server available):
   ```bash
   python scripts/run_real_server_performance.py --help
   ```
   Expected: Help message displayed, exit code 0

### Test Expectations
- Script should execute without syntax errors
- Script should handle both immediate and queued result modes
- Script should correctly extract `job_id` from queued results
- Script should not use JSON-RPC request `id` as job identifier
- Script should use context manager for client lifecycle
- Script should use `job_id` for all status polling operations

## Decision Rules
1. **Context manager**: Always use `async with EmbeddingServiceAsyncClient.from_config(config) as client:`, never manual `__aenter__`/`close()`
2. **Identifier extraction**: Always use `result.get("job_id")` (safe extraction), never `result["job_id"]` or `result.get("id")`
3. **Immediate mode detection**: If `job_id` is None, check for `mode == "immediate"` or presence of `"embeddings"`/`"results"` in result
4. **Status polling**: Always use extracted `job_id` for `job_status` calls, never JSON-RPC request id
5. **Certificate paths**: Always resolve relative paths using `PROJECT_ROOT` before passing to config

## Blackstops
Stop and escalate if:
- Script requires changes to core client architecture (affects Steps 1-3)
- Script reveals bugs in synchronized client that require global fixes
- Script execution reveals contradictions between adapter behavior and expected server contract

## Handoff Package
- Updated `scripts/run_real_server_performance.py` file
- All validation commands pass
- Script ready for execution on `localhost:8001` with mTLS certificates
