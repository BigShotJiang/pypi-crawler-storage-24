Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Create Security Matrix Test File

## Executor Role

`coder_auto` - Implement the test file described in this step.

## Execution Directive

Create a comprehensive test file `tests/test_security_matrix.py` that validates all 8 required security modes (http, http + token, http + token + roles, https, https + token, https + token + roles, mtls, mtls + roles) using adapter-backed client construction and command execution. The test file must validate both immediate and queued result modes for each security mode, verify adapter-backed transport usage, and test proper error handling for invalid configurations.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/security-matrix-validation-tests.md`

## Step Scope

**Target file:** `tests/test_security_matrix.py`
**Action:** create

This step creates a new test file that comprehensively validates all 8 required security modes through adapter-backed client construction and command execution.

## Dependency Contract

**Dependencies:** 
- Step 1: adapter-centric-client-foundation (must complete first)
- Step 2: embed-command-and-result-contract-alignment (must complete first)
- Step 3: queue-and-websocket-identifier-separation (must complete first)

**Dependents:** None identified. This test file validates the integrated synchronized client.

## Required Context

- The synchronized client uses adapter-only transport (AdapterTransport) for all network operations
- All authentication, TLS/mTLS operations, and protocol selection are handled exclusively by mcp-proxy-adapter client facilities
- The client converts configuration to adapter parameters via AdapterConfigFactory
- All 8 security modes must be validated:
  1. http (no auth)
  2. http + token (token-based auth)
  3. http + token + roles (token-based auth with role constraints)
  4. https (HTTPS without auth)
  5. https + token (HTTPS with token-based auth)
  6. https + token + roles (HTTPS with token-based auth and role constraints)
  7. mtls (mutual TLS without roles)
  8. mtls + roles (mutual TLS with role-based access control)
- Tests must use mock/test server or real test server (NOT localhost:8001, which is covered in separate tactical task)
- Tests must validate both immediate JSON-RPC result mode and queued result mode
- Tests must verify that adapter-backed transport is used (no custom auth/transport logic)

## Read First

Before starting implementation, read these files:

1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - Architecture and contract definitions
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md` - Global step context
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/security-matrix-validation-tests.md` - Tactical task details
4. `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` - Client construction and method signatures
5. `/home/vasilyvz/projects/embed-client/embed_client/client_factory.py` - Config construction patterns
6. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - Adapter-backed transport behavior
7. `/home/vasilyvz/projects/embed-client/tests/conftest.py` - Test fixtures and helpers
8. `/home/vasilyvz/projects/embed-client/tests/test_async_client_real_fixtures.py` - Real server fixture patterns

## Expected File Change

**File:** `tests/test_security_matrix.py`

**Changes:**
1. Create new test file with comprehensive security matrix validation
2. Implement helper function `create_test_config()` to generate configs for each security mode
3. Implement test class `TestSecurityMatrix` with 8 test methods (one per security mode)
4. Implement helper method `_test_security_mode()` for common test logic
5. Each test validates: client construction, command execution, adapter-backed transport usage, error handling

## Forbidden Alternatives

- Do NOT use localhost:8001 (use test server or mocks - localhost:8001 is covered in separate tactical task)
- Do NOT create custom transport/auth logic in tests (must use adapter-backed client)
- Do NOT bypass adapter-backed client construction (must use EmbeddingServiceAsyncClient.from_config or equivalent)
- Do NOT test only one security mode (must test all 8)
- Do NOT skip security modes due to test server limitations (use mocks if needed)
- Do NOT modify core client implementation files (this is a test-only change)
- Do NOT use direct HTTP/TLS libraries (must use adapter-backed client)
- Do NOT assume WebSocket correlation id equals job_id (preserve identifier separation)

## Atomic Operations

### Operation 1: Create File Header and Imports

**Location:** Top of `tests/test_security_matrix.py`

**Content:**
```python
"""
Comprehensive Security Matrix Validation Tests

Tests all 8 required security modes using adapter-backed client:
- http (no auth)
- http + token
- http + token + roles
- https (no auth)
- https + token
- https + token + roles
- mtls (no auth)
- mtls + roles

All tests validate adapter-backed transport usage (no custom auth/transport logic).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import pytest
import pytest_asyncio
from typing import Dict, Any, Optional
from pathlib import Path

from embed_client.async_client import EmbeddingServiceAsyncClient
from embed_client.exceptions import (
    EmbeddingServiceError,
    EmbeddingServiceConfigError,
    EmbeddingServiceConnectionError,
    EmbeddingServiceAPIError,
    EmbeddingServiceHTTPError,
    EmbeddingServiceTimeoutError,
    EmbeddingServiceJSONError,
)
```

**Action:** Write this exact header and import block at the top of the file.

### Operation 2: Implement `create_test_config()` Helper Function

**Location:** After imports, before test class

**Function signature:**
```python
def create_test_config(
    mode: str,
    host: str = "localhost",
    port: int = 8000,
    **overrides: Any
) -> Dict[str, Any]:
```

**Purpose:** Create test configuration dictionary for a specific security mode.

**Parameters:**
- `mode: str` - Security mode name. Must be one of: "http", "http_token", "http_token_roles", "https", "https_token", "https_token_roles", "mtls", "mtls_roles"
- `host: str` - Server host (default: "localhost")
- `port: int` - Server port (default: 8000)
- `**overrides: Any` - Optional config overrides to merge into the base config

**Returns:** `Dict[str, Any]` - Configuration dictionary compatible with `EmbeddingServiceAsyncClient.from_config()` or `EmbeddingServiceAsyncClient(config_dict=...)`

**Method logic - step-by-step algorithm:**

1. Initialize empty dict `config: Dict[str, Any] = {}`
2. Initialize empty dict `server_config: Dict[str, Any] = {"host": host, "port": port}`
3. Initialize empty dict `auth_config: Dict[str, Any] = {}`
4. Initialize empty dict `ssl_config: Dict[str, Any] = {}`
5. Initialize empty dict `security_config: Dict[str, Any] = {}`

6. **If mode == "http":**
   - Set `server_config["protocol"] = "http"` (or omit, let client derive from ssl.enabled)
   - Set `ssl_config["enabled"] = False`
   - Set `auth_config["method"] = "none"`
   - Set `security_config["enabled"] = False`

7. **If mode == "http_token":**
   - Set `server_config["protocol"] = "http"`
   - Set `ssl_config["enabled"] = False`
   - Set `auth_config["method"] = "api_key"`
   - Set `security_config["enabled"] = True`
   - Set `security_config["tokens"] = {"admin": "admin-secret-key", "user": "user-secret-key"}`

8. **If mode == "http_token_roles":**
   - Set `server_config["protocol"] = "http"`
   - Set `ssl_config["enabled"] = False`
   - Set `auth_config["method"] = "api_key"`
   - Set `security_config["enabled"] = True`
   - Set `security_config["tokens"] = {"admin": "admin-secret-key", "user": "user-secret-key", "readonly": "readonly-secret-key"}`
   - Set `security_config["roles"] = {"admin": ["read", "write", "delete", "admin"], "user": ["read", "write"], "readonly": ["read"]}`

9. **If mode == "https":**
   - Set `server_config["protocol"] = "https"`
   - Set `ssl_config["enabled"] = True`
   - Set `ssl_config["verify_mode"] = "CERT_NONE"`
   - Set `ssl_config["check_hostname"] = False`
   - Set `ssl_config["cert_file"] = overrides.get("cert_file", "/home/vasilyvz/projects/embed-client/mtls_certificates/server/embedding-service.crt")`
   - Set `ssl_config["key_file"] = overrides.get("key_file", "/home/vasilyvz/projects/embed-client/mtls_certificates/server/embedding-service.key")`
   - Set `auth_config["method"] = "none"`
   - Set `security_config["enabled"] = False`

10. **If mode == "https_token":**
    - Set `server_config["protocol"] = "https"`
    - Set `ssl_config["enabled"] = True`
    - Set `ssl_config["verify_mode"] = "CERT_NONE"`
    - Set `ssl_config["check_hostname"] = False`
    - Set `ssl_config["cert_file"] = overrides.get("cert_file", "/home/vasilyvz/projects/embed-client/mtls_certificates/server/embedding-service.crt")`
    - Set `ssl_config["key_file"] = overrides.get("key_file", "/home/vasilyvz/projects/embed-client/mtls_certificates/server/embedding-service.key")`
    - Set `auth_config["method"] = "api_key"`
    - Set `security_config["enabled"] = True`
    - Set `security_config["tokens"] = {"admin": "admin-secret-key", "user": "user-secret-key"}`

11. **If mode == "https_token_roles":**
    - Set `server_config["protocol"] = "https"`
    - Set `ssl_config["enabled"] = True`
    - Set `ssl_config["verify_mode"] = "CERT_NONE"`
    - Set `ssl_config["check_hostname"] = False`
    - Set `ssl_config["cert_file"] = overrides.get("cert_file", "/home/vasilyvz/projects/embed-client/mtls_certificates/server/embedding-service.crt")`
    - Set `ssl_config["key_file"] = overrides.get("key_file", "/home/vasilyvz/projects/embed-client/mtls_certificates/server/embedding-service.key")`
    - Set `auth_config["method"] = "api_key"`
    - Set `security_config["enabled"] = True`
    - Set `security_config["tokens"] = {"admin": "admin-secret-key", "user": "user-secret-key", "readonly": "readonly-secret-key"}`
    - Set `security_config["roles"] = {"admin": ["read", "write", "delete", "admin"], "user": ["read", "write"], "readonly": ["read"]}`

12. **If mode == "mtls":**
    - Set `server_config["protocol"] = "mtls"` (or "https" with client certs)
    - Set `ssl_config["enabled"] = True`
    - Set `ssl_config["verify_mode"] = "CERT_REQUIRED"`
    - Set `ssl_config["check_hostname"] = True`
    - Set `ssl_config["cert_file"] = overrides.get("cert_file", "/home/vasilyvz/projects/embed-client/mtls_certificates/client/client.crt")`
    - Set `ssl_config["key_file"] = overrides.get("key_file", "/home/vasilyvz/projects/embed-client/mtls_certificates/client/client.key")`
    - Set `ssl_config["ca_cert_file"] = overrides.get("ca_cert_file", "/home/vasilyvz/projects/embed-client/mtls_certificates/ca/ca.crt")`
    - Set `auth_config["method"] = "certificate"`
    - Set `security_config["enabled"] = False`

13. **If mode == "mtls_roles":**
    - Set `server_config["protocol"] = "mtls"`
    - Set `ssl_config["enabled"] = True`
    - Set `ssl_config["verify_mode"] = "CERT_REQUIRED"`
    - Set `ssl_config["check_hostname"] = True`
    - Set `ssl_config["cert_file"] = overrides.get("cert_file", "/home/vasilyvz/projects/embed-client/mtls_certificates/client/client.crt")`
    - Set `ssl_config["key_file"] = overrides.get("key_file", "/home/vasilyvz/projects/embed-client/mtls_certificates/client/client.key")`
    - Set `ssl_config["ca_cert_file"] = overrides.get("ca_cert_file", "/home/vasilyvz/projects/embed-client/mtls_certificates/ca/ca.crt")`
    - Set `auth_config["method"] = "certificate"`
    - Set `security_config["enabled"] = True`
    - Set `security_config["roles"] = {"admin": ["read", "write", "delete", "admin"], "user": ["read", "write"], "readonly": ["read"]}`

14. **If mode is not one of the above 8 values:**
    - Raise `ValueError(f"Unknown security mode: {mode}. Must be one of: http, http_token, http_token_roles, https, https_token, https_token_roles, mtls, mtls_roles")`

15. Build final config dict:
    - Set `config["server"] = server_config`
    - Set `config["auth"] = auth_config`
    - Set `config["ssl"] = ssl_config`
    - Set `config["security"] = security_config`

16. **If overrides dict is not empty:**
    - Recursively merge overrides into config (deep merge, not shallow)
    - For nested dicts in overrides, merge into corresponding nested dicts in config
    - For non-dict values in overrides, replace corresponding values in config

17. Return `config`

**Error handling:**
- If mode is not recognized: raise `ValueError` with message describing valid modes
- If required certificate files are missing (for https/mtls modes): do NOT raise here (let client construction or test execution handle it)
- If overrides contain invalid keys: merge anyway (let client validation handle it)

**Edge cases:**
- Empty overrides dict: config is built with defaults only
- Overrides with nested dicts: deep merge into config
- Overrides with non-dict values: replace config values
- Missing certificate file paths: do not validate file existence (let client handle it)

**Return value specification:**
- Returns dict with keys: "server", "auth", "ssl", "security"
- "server" dict contains: "host" (str), "port" (int), optionally "protocol" (str)
- "auth" dict contains: "method" (str)
- "ssl" dict contains: "enabled" (bool), and optionally "verify_mode", "check_hostname", "cert_file", "key_file", "ca_cert_file"
- "security" dict contains: "enabled" (bool), and optionally "tokens" (dict), "roles" (dict)

### Operation 3: Implement `TestSecurityMatrix` Test Class

**Location:** After `create_test_config()` function

**Class definition:**
```python
class TestSecurityMatrix:
    """Test suite for security matrix validation across all 8 required modes."""
```

**Base class:** None (pytest-style class, not unittest.TestCase)

**Instance attributes:** None (pytest-style, no __init__ needed)

**Public methods:**

1. `test_http_mode() -> None` - Validate http mode
2. `test_http_token_mode() -> None` - Validate http + token mode
3. `test_http_token_roles_mode() -> None` - Validate http + token + roles mode
4. `test_https_mode() -> None` - Validate https mode
5. `test_https_token_mode() -> None` - Validate https + token mode
6. `test_https_token_roles_mode() -> None` - Validate https + token + roles mode
7. `test_mtls_mode() -> None` - Validate mtls mode
8. `test_mtls_roles_mode() -> None` - Validate mtls + roles mode
9. `_test_security_mode(mode_name: str, config: Dict[str, Any]) -> None` - Helper to test a security mode

**Method signatures and docstrings:**

```python
@pytest.mark.asyncio
async def test_http_mode():
    """
    Test HTTP mode (no authentication).
    
    Validates:
    - Client construction succeeds
    - Command execution succeeds (embed, models)
    - Adapter-backed transport is used
    """
    pass

@pytest.mark.asyncio
async def test_http_token_mode():
    """
    Test HTTP + token mode.
    
    Validates:
    - Client construction succeeds with token config
    - Command execution succeeds with token auth
    - Adapter-backed transport is used
    """
    pass

@pytest.mark.asyncio
async def test_http_token_roles_mode():
    """
    Test HTTP + token + roles mode.
    
    Validates:
    - Client construction succeeds with token and roles config
    - Command execution succeeds with role-based auth
    - Adapter-backed transport is used
    """
    pass

@pytest.mark.asyncio
async def test_https_mode():
    """
    Test HTTPS mode (no authentication).
    
    Validates:
    - Client construction succeeds with SSL config
    - Command execution succeeds over HTTPS
    - Adapter-backed transport is used
    """
    pass

@pytest.mark.asyncio
async def test_https_token_mode():
    """
    Test HTTPS + token mode.
    
    Validates:
    - Client construction succeeds with SSL and token config
    - Command execution succeeds over HTTPS with token auth
    - Adapter-backed transport is used
    """
    pass

@pytest.mark.asyncio
async def test_https_token_roles_mode():
    """
    Test HTTPS + token + roles mode.
    
    Validates:
    - Client construction succeeds with SSL, token, and roles config
    - Command execution succeeds over HTTPS with role-based auth
    - Adapter-backed transport is used
    """
    pass

@pytest.mark.asyncio
async def test_mtls_mode():
    """
    Test mTLS mode (no roles).
    
    Validates:
    - Client construction succeeds with client certificates
    - Command execution succeeds over mTLS
    - Adapter-backed transport is used
    """
    pass

@pytest.mark.asyncio
async def test_mtls_roles_mode():
    """
    Test mTLS + roles mode.
    
    Validates:
    - Client construction succeeds with client certificates and roles
    - Command execution succeeds over mTLS with role-based access
    - Adapter-backed transport is used
    """
    pass

async def _test_security_mode(mode_name: str, config: Dict[str, Any]) -> None:
    """
    Helper method to test a security mode.
    
    Args:
        mode_name: Name of the security mode (for logging/error messages)
        config: Configuration dictionary for the security mode
    
    Validates:
    - Client construction succeeds
    - embed() command executes successfully
    - models() command executes successfully
    - Result structure is valid
    - Adapter-backed transport is used (no custom auth/transport)
    
    Raises:
        AssertionError: If any validation fails
        EmbeddingServiceConfigError: If config is invalid
        EmbeddingServiceConnectionError: If connection fails
        EmbeddingServiceAPIError: If API call fails
    """
    pass
```

**Method logic for `test_http_mode()` - step-by-step algorithm:**

1. Call `create_test_config("http", host="localhost", port=8000)` → store in `config`
2. Call `_test_security_mode("http", config)` → await result
3. If `_test_security_mode` raises exception: let it propagate (test fails)
4. If `_test_security_mode` completes without exception: test passes

**Method logic for `test_http_token_mode()` - step-by-step algorithm:**

1. Call `create_test_config("http_token", host="localhost", port=8000)` → store in `config`
2. Call `_test_security_mode("http_token", config)` → await result
3. If `_test_security_mode` raises exception: let it propagate (test fails)
4. If `_test_security_mode` completes without exception: test passes

**Method logic for `test_http_token_roles_mode()` - step-by-step algorithm:**

1. Call `create_test_config("http_token_roles", host="localhost", port=8000)` → store in `config`
2. Call `_test_security_mode("http_token_roles", config)` → await result
3. If `_test_security_mode` raises exception: let it propagate (test fails)
4. If `_test_security_mode` completes without exception: test passes

**Method logic for `test_https_mode()` - step-by-step algorithm:**

1. Call `create_test_config("https", host="localhost", port=8000)` → store in `config`
2. Call `_test_security_mode("https", config)` → await result
3. If `_test_security_mode` raises exception: let it propagate (test fails)
4. If `_test_security_mode` completes without exception: test passes

**Method logic for `test_https_token_mode()` - step-by-step algorithm:**

1. Call `create_test_config("https_token", host="localhost", port=8000)` → store in `config`
2. Call `_test_security_mode("https_token", config)` → await result
3. If `_test_security_mode` raises exception: let it propagate (test fails)
4. If `_test_security_mode` completes without exception: test passes

**Method logic for `test_https_token_roles_mode()` - step-by-step algorithm:**

1. Call `create_test_config("https_token_roles", host="localhost", port=8000)` → store in `config`
2. Call `_test_security_mode("https_token_roles", config)` → await result
3. If `_test_security_mode` raises exception: let it propagate (test fails)
4. If `_test_security_mode` completes without exception: test passes

**Method logic for `test_mtls_mode()` - step-by-step algorithm:**

1. Call `create_test_config("mtls", host="localhost", port=8000)` → store in `config`
2. Call `_test_security_mode("mtls", config)` → await result
3. If `_test_security_mode` raises exception: let it propagate (test fails)
4. If `_test_security_mode` completes without exception: test passes

**Method logic for `test_mtls_roles_mode()` - step-by-step algorithm:**

1. Call `create_test_config("mtls_roles", host="localhost", port=8000)` → store in `config`
2. Call `_test_security_mode("mtls_roles", config)` → await result
3. If `_test_security_mode` raises exception: let it propagate (test fails)
4. If `_test_security_mode` completes without exception: test passes

**Method logic for `_test_security_mode()` - step-by-step algorithm:**

1. **Client Construction:**
   - Create async context manager: `async with EmbeddingServiceAsyncClient(config_dict=config) as client:`
   - If `EmbeddingServiceConfigError` is raised: let it propagate (test fails with config error)
   - If `EmbeddingServiceConnectionError` is raised: let it propagate (test fails with connection error)
   - If any other exception is raised: let it propagate (test fails)

2. **Verify Adapter-Backed Transport:**
   - Assert `hasattr(client, "_adapter_transport")` → must be True
   - Assert `client._adapter_transport is not None` → must be True
   - Assert `hasattr(client._adapter_transport, "_client")` → must be True (adapter client exists)
   - This verifies adapter-backed transport is used (no custom auth/transport)

3. **Test embed() Command (Immediate Mode):**
   - Call `result = await client.embed(texts=["test text 1", "test text 2"])` → store in `result`
   - If `EmbeddingServiceAPIError` is raised: let it propagate (test fails with API error)
   - If `EmbeddingServiceHTTPError` is raised: let it propagate (test fails with HTTP error)
   - If `EmbeddingServiceTimeoutError` is raised: let it propagate (test fails with timeout)
   - If `EmbeddingServiceJSONError` is raised: let it propagate (test fails with JSON error)
   - Assert `result is not None` → must be True
   - Assert `isinstance(result, dict)` → must be True
   - Assert `"result" in result or "embeddings" in result or "results" in result` → must be True (valid result structure)
   - This validates immediate JSON-RPC result mode

4. **Test embed() Command (Queued Mode - if supported):**
   - Call `result = await client.embed(texts=["test text 3"], wait=False)` → store in `queued_result`
   - If `EmbeddingServiceAPIError` is raised: let it propagate (test fails)
   - If result contains `"job_id"`:
     - Assert `isinstance(queued_result.get("job_id"), str)` → must be True
     - Assert `len(queued_result["job_id"]) > 0` → must be True
     - Call `status_result = await client.job_status(queued_result["job_id"])` → store in `status_result`
     - Assert `status_result is not None` → must be True
     - Assert `isinstance(status_result, dict)` → must be True
     - This validates queued result mode and job_id handling
   - If result does not contain `"job_id"`: skip queued mode validation (server may not support queuing)

5. **Test models() Command:**
   - Call `models_result = await client.models()` → store in `models_result`
   - If `EmbeddingServiceAPIError` is raised: let it propagate (test fails)
   - Assert `models_result is not None` → must be True
   - Assert `isinstance(models_result, dict)` → must be True
   - This validates command execution through adapter-backed transport

6. **Test Error Handling (Invalid Config):**
   - Create invalid config: `invalid_config = config.copy()` then set `invalid_config["server"]["port"] = -1` (invalid port)
   - Try: `async with EmbeddingServiceAsyncClient(config_dict=invalid_config) as invalid_client:`
   - Expect `EmbeddingServiceConfigError` or `EmbeddingServiceConnectionError` to be raised
   - If exception is raised: test passes (error handling works)
   - If no exception is raised: assert False with message "Expected config error for invalid port"

7. **If all steps complete without exceptions:** test passes

**Error handling per method:**

- `test_*_mode()` methods: Let all exceptions from `_test_security_mode()` propagate (pytest will report failure)
- `_test_security_mode()` method:
  - `EmbeddingServiceConfigError`: Let propagate (config validation failure)
  - `EmbeddingServiceConnectionError`: Let propagate (connection failure - may indicate test server unavailable)
  - `EmbeddingServiceAPIError`: Let propagate (API failure - may indicate auth/authorization issue)
  - `EmbeddingServiceHTTPError`: Let propagate (HTTP transport failure)
  - `EmbeddingServiceTimeoutError`: Let propagate (timeout failure)
  - `EmbeddingServiceJSONError`: Let propagate (JSON parsing failure)
  - `AssertionError`: Let propagate (test assertion failure)
  - Any other exception: Let propagate (unexpected error)

**Edge cases for `_test_security_mode()`:**

- Test server unavailable: `EmbeddingServiceConnectionError` is raised → test fails (expected, indicates test server not running)
- Invalid certificate files: `EmbeddingServiceConfigError` or `EmbeddingServiceConnectionError` is raised → test fails (expected)
- Server returns error response: `EmbeddingServiceAPIError` is raised → test fails (expected, indicates server-side issue)
- Queued mode not supported: result does not contain `"job_id"` → skip queued validation (acceptable)
- Empty result from embed(): Assert `"result" in result or "embeddings" in result or "results" in result` fails → test fails (unexpected empty result)
- models() returns empty dict: Assert `isinstance(models_result, dict)` passes, but content validation may fail → acceptable if dict is valid structure

**Return value specification:**

- All test methods return `None` (pytest async test functions)
- `_test_security_mode()` returns `None` (helper method, raises exceptions on failure)

### Operation 4: Add Test Markers and Fixtures (Optional)

**Location:** After test class, or in separate section if needed

**Content:** None required. Tests use pytest-asyncio automatically via `@pytest.mark.asyncio` decorator.

**Action:** No additional markers or fixtures needed. Tests are self-contained.

## Expected Deliverables

1. **File:** `tests/test_security_matrix.py`
   - Complete file with header, imports, helper function, test class, and all 8 test methods
   - All methods fully implemented (no `pass` or `NotImplemented`)
   - All docstrings in English
   - All type annotations present

2. **Test Coverage:**
   - All 8 security modes tested
   - Client construction validated
   - Command execution validated (embed, models)
   - Adapter-backed transport usage verified
   - Error handling validated

## Mandatory Validation

After implementation, run these exact commands and verify success:

1. **Format check:**
   ```bash
   black tests/test_security_matrix.py
   ```
   **Expected:** "reformatted tests/test_security_matrix.py" or "All done! ✨ 🍰 ✨"

2. **Lint check:**
   ```bash
   flake8 tests/test_security_matrix.py
   ```
   **Expected:** Exit code 0, no output (or only warnings about line length if lines exceed 100 chars)

3. **Type check:**
   ```bash
   mypy tests/test_security_matrix.py
   ```
   **Expected:** "Success: no issues found" or exit code 0

4. **Test execution (dry run):**
   ```bash
   pytest tests/test_security_matrix.py --collect-only
   ```
   **Expected:** Shows 8 test functions collected (test_http_mode, test_http_token_mode, test_http_token_roles_mode, test_https_mode, test_https_token_mode, test_https_token_roles_mode, test_mtls_mode, test_mtls_roles_mode)

5. **Test execution (if test server available):**
   ```bash
   pytest tests/test_security_matrix.py -v
   ```
   **Expected:** All 8 tests pass (or skip if test server unavailable, but tests must be collectable and executable)

**All validation commands must pass before considering this step complete.**

## Decision Rules

1. **Test server availability:** If test server is unavailable, tests will fail with `EmbeddingServiceConnectionError`. This is acceptable - tests validate client construction and error handling. Tests should NOT be skipped automatically - let them fail if server is unavailable.

2. **Certificate file paths:** Use hardcoded paths from project root: `/home/vasilyvz/projects/embed-client/mtls_certificates/...`. If files don't exist, client construction will fail with appropriate error - this is acceptable.

3. **Port numbers:** Use default port 8000 in `create_test_config()`. Tests can override via `overrides` parameter if needed.

4. **Result structure validation:** Accept both old format (`{"embeddings": [...]}`) and new format (`{"result": {"data": {"embeddings": [...], "results": [...]}}}`). Check for any of: "result", "embeddings", "results" keys.

5. **Queued mode validation:** If `embed(wait=False)` returns result without `job_id`, skip queued validation (server may not support queuing). If `job_id` is present, validate job_status() call.

## Blackstops

Stop implementation and escalate if:

1. **Adapter client construction fails:** If `EmbeddingServiceAsyncClient(config_dict=...)` raises unexpected exception that indicates adapter integration issue → escalate to orchestrator_tactical

2. **Config structure mismatch:** If `create_test_config()` produces config that `EmbeddingServiceAsyncClient` cannot accept → escalate to orchestrator_tactical (may indicate config contract change)

3. **Missing adapter transport attribute:** If `client._adapter_transport` does not exist → escalate to orchestrator_tactical (may indicate client implementation change)

4. **Test framework incompatibility:** If pytest-asyncio decorators don't work → escalate to orchestrator_tactical (may indicate test environment issue)

## Handoff Package

**For `coder_auto`:**

1. **Target file:** `tests/test_security_matrix.py` (create new file)

2. **Required imports:**
   - `import pytest`
   - `import pytest_asyncio`
   - `from typing import Dict, Any, Optional`
   - `from pathlib import Path`
   - `from embed_client.async_client import EmbeddingServiceAsyncClient`
   - `from embed_client.exceptions import EmbeddingServiceError, EmbeddingServiceConfigError, EmbeddingServiceConnectionError, EmbeddingServiceAPIError, EmbeddingServiceHTTPError, EmbeddingServiceTimeoutError, EmbeddingServiceJSONError`

3. **Helper function:** `create_test_config(mode: str, host: str = "localhost", port: int = 8000, **overrides: Any) -> Dict[str, Any]`

4. **Test class:** `TestSecurityMatrix` with 8 test methods and 1 helper method

5. **Test methods:** All 8 security mode tests call `_test_security_mode()` with appropriate config

6. **Helper method:** `_test_security_mode()` validates client construction, command execution, adapter-backed transport, and error handling

7. **Validation:** Run black, flake8, mypy, pytest --collect-only, and pytest -v (if server available)

8. **Constants:**
   - Certificate paths: `/home/vasilyvz/projects/embed-client/mtls_certificates/server/embedding-service.crt`, `/home/vasilyvz/projects/embed-client/mtls_certificates/server/embedding-service.key`, `/home/vasilyvz/projects/embed-client/mtls_certificates/client/client.crt`, `/home/vasilyvz/projects/embed-client/mtls_certificates/client/client.key`, `/home/vasilyvz/projects/embed-client/mtls_certificates/ca/ca.crt`
   - Test tokens: `"admin-secret-key"`, `"user-secret-key"`, `"readonly-secret-key"`
   - Test roles: `{"admin": ["read", "write", "delete", "admin"], "user": ["read", "write"], "readonly": ["read"]}`
   - Default host: `"localhost"`
   - Default port: `8000`
   - Test texts: `["test text 1", "test text 2"]`, `["test text 3"]`

**All code must be production-ready (no `pass`, no `NotImplemented`, no placeholders).**
