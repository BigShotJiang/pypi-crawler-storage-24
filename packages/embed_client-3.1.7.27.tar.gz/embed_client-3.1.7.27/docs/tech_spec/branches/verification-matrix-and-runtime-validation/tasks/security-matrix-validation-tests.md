Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Security Matrix Validation Tests

## Purpose

Create and execute comprehensive test coverage for all 8 required security modes (http, http + token, http + token + roles, https, https + token, https + token + roles, mtls, mtls + roles) to validate that the synchronized client correctly handles all protocol and authentication combinations through adapter-backed transport.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`

## Scope

### Included

- Create or modify `tests/test_security_matrix.py` to validate all 8 security modes
- Test adapter-backed client construction for each mode
- Test command execution (embed, models, timing_stats) for each mode
- Test both immediate and queued result modes for each security mode
- Validate that all modes use adapter-backed transport (no custom auth/transport logic)
- Verify proper error handling for invalid configurations

### Excluded

- Real-server runtime validation on localhost:8001 (covered in separate tactical task)
- Identifier separation validation (covered in separate tactical task)
- Result mode behavior details (covered in separate tactical task)
- Unit tests for individual client methods (covered in other test files)

## Boundaries

This task must NOT touch:
- Core client implementation files (already updated in Steps 1-3)
- Adapter transport layer (already updated in Step 1)
- Real-server scripts (covered in separate tactical task)

## Dependencies

- Step 1: adapter-centric-client-foundation (must complete first)
- Step 2: embed-command-and-result-contract-alignment (must complete first)
- Step 3: queue-and-websocket-identifier-separation (must complete first)

This tactical task depends on all prior steps because it validates the integrated synchronized client.

## Parallelization Note

This tactical task can run in parallel with:
- `result-mode-validation-tests.md`
- `identifier-separation-validation-tests.md`
- `update-maintained-real-server-scripts.md`

## Expected Outcome

1. Test file `tests/test_security_matrix.py` exists and validates all 8 security modes
2. All 8 security modes pass validation:
   - http
   - http + token
   - http + token + roles
   - https
   - https + token
   - https + token + roles
   - mtls
   - mtls + roles
3. Each security mode test validates:
   - Successful client construction
   - Successful command execution (embed, models, timing_stats)
   - Correct adapter-backed transport usage
   - Proper error handling for invalid configs
4. Tests use mock/test server or real test server (not localhost:8001)
5. All tests pass and produce clear failure messages if any mode fails

## Correction Items

None (this is a new test file creation task).

## Questions/Escalation Rule

Escalate to global orchestrator if:
- A security mode cannot be validated due to adapter limitations (affects Step 1)
- Test validation reveals bugs in core client that require global fixes (affects Steps 1-3)
- Security mode behavior contradicts adapter contract or server contract

## File Inventory

### Files to Create

1. **Action**: create
   **Path**: `tests/test_security_matrix.py`
   **Purpose**: Comprehensive test suite for all 8 security modes

### Files to Read (Reference Only)

1. **Path**: `embed_client/async_client.py`
   **Purpose**: Reference for client construction and method signatures

2. **Path**: `embed_client/config.py` or `embed_client/client_factory.py`
   **Purpose**: Reference for config construction for each security mode

3. **Path**: `embed_client/adapter_transport.py`
   **Purpose**: Reference for adapter-backed transport behavior

4. **Path**: `tests/conftest.py`
   **Purpose**: Reference for test fixtures and helpers

## Class/Function Inventory

### Test File Structure

1. **Class name**: `TestSecurityMatrix`
   **Base class**: `unittest.TestCase` or pytest class
   **Purpose**: Test suite for security matrix validation
   **Public methods**:
   - `test_http_mode() -> None`: Validate http mode
   - `test_http_token_mode() -> None`: Validate http + token mode
   - `test_http_token_roles_mode() -> None`: Validate http + token + roles mode
   - `test_https_mode() -> None`: Validate https mode
   - `test_https_token_mode() -> None`: Validate https + token mode
   - `test_https_token_roles_mode() -> None`: Validate https + token + roles mode
   - `test_mtls_mode() -> None`: Validate mtls mode
   - `test_mtls_roles_mode() -> None`: Validate mtls + roles mode
   - `_test_security_mode(mode_name: str, config: dict) -> None`: Helper to test a security mode

2. **Function name**: `create_test_config(mode: str, **overrides: Any) -> dict`
   **Purpose**: Create test configuration for a security mode
   **Parameters**:
   - `mode: str`: Security mode name (e.g., "http", "https", "mtls")
   - `**overrides: Any`: Optional config overrides
   **Returns**: `dict`: Configuration dict for client construction

## Data Structures

### Test Configuration Patterns

1. **HTTP Mode Config**:
   - `{"server": {"host": "test_host", "port": 8000}, "protocol": "http"}`

2. **HTTP + Token Mode Config**:
   - `{"server": {"host": "test_host", "port": 8000}, "protocol": "http", "auth": {"use_token": True, "tokens": {...}}}`

3. **HTTP + Token + Roles Mode Config**:
   - `{"server": {"host": "test_host", "port": 8000}, "protocol": "http", "auth": {"use_token": True, "tokens": {...}, "roles": {...}}}`

4. **HTTPS Mode Config**:
   - `{"server": {"host": "test_host", "port": 8000}, "protocol": "https", "ssl": {...}}`

5. **HTTPS + Token Mode Config**:
   - `{"server": {"host": "test_host", "port": 8000}, "protocol": "https", "auth": {"use_token": True, "tokens": {...}}, "ssl": {...}}`

6. **HTTPS + Token + Roles Mode Config**:
   - `{"server": {"host": "test_host", "port": 8000}, "protocol": "https", "auth": {"use_token": True, "tokens": {...}, "roles": {...}}, "ssl": {...}}`

7. **mTLS Mode Config**:
   - `{"server": {"host": "test_host", "port": 8000}, "protocol": "mtls", "ssl": {"cert_file": "...", "key_file": "...", "ca_cert_file": "..."}}`

8. **mTLS + Roles Mode Config**:
   - `{"server": {"host": "test_host", "port": 8000}, "protocol": "mtls", "auth": {"roles": {...}}, "ssl": {"cert_file": "...", "key_file": "...", "ca_cert_file": "..."}}`

## Import Map

### For tests/test_security_matrix.py

- `import pytest` or `import unittest`
- `import asyncio`
- `from embed_client.async_client import EmbeddingServiceAsyncClient`
- `from embed_client.config import ClientConfig` (if needed)
- `from embed_client.exceptions import EmbeddingServiceError, EmbeddingServiceConfigError, EmbeddingServiceConnectionError`
- `from tests.conftest import *` (if fixtures available)

## Error Handling Map

### For Test Execution

1. **Config Construction Failure**:
   - **Exception**: `EmbeddingServiceConfigError`
   - **Condition**: Invalid security mode configuration
   - **Action**: Test should assert config error is raised with appropriate message

2. **Client Construction Failure**:
   - **Exception**: `EmbeddingServiceConfigError` or `EmbeddingServiceConnectionError`
   - **Condition**: Invalid config or connection failure
   - **Action**: Test should assert connection error is raised (for invalid configs) or skip (for unavailable test server)

3. **Command Execution Failure**:
   - **Exception**: `EmbeddingServiceAPIError` or `EmbeddingServiceError`
   - **Condition**: Server rejects command or returns error
   - **Action**: Test should assert API error is raised or verify error handling

## Config Dependency

### Tests Use These Config Keys

1. **Server Endpoint**:
   - **Key**: `server.host`, `server.port`
   - **Type**: `str`, `int`
   - **Default**: Test server host/port
   - **Access**: Via test config construction

2. **Protocol**:
   - **Key**: `protocol` or `server.protocol`
   - **Type**: `str`
   - **Values**: `"http"`, `"https"`, `"mtls"`
   - **Access**: Via test config construction

3. **Authentication**:
   - **Key**: `auth.use_token`, `auth.tokens`, `auth.roles`
   - **Type**: `bool`, `dict`, `dict`
   - **Access**: Via test config construction

4. **SSL/TLS**:
   - **Key**: `ssl.cert_file`, `ssl.key_file`, `ssl.ca_cert_file`
   - **Type**: `str`
   - **Access**: Via test config construction (for https/mtls modes)

## Test Plan

### For tests/test_security_matrix.py

1. **Test Structure**:
   - One test method per security mode (8 total)
   - Each test method:
     - Creates config for the security mode
     - Constructs client using adapter-backed methods
     - Executes test command (embed, models, or timing_stats)
     - Validates successful execution
     - Validates adapter-backed transport usage (no custom auth/transport)

2. **Test Commands**:
   - `embed()` with simple test texts
   - `models()` to verify command execution
   - `timing_stats()` if available

3. **Test Assertions**:
   - Client construction succeeds
   - Command execution succeeds (returns valid result)
   - No custom auth/transport logic is used (adapter-backed only)
   - Error handling works correctly for invalid configs

4. **Test Fixtures**:
   - Mock test server or real test server (not localhost:8001)
   - Test certificates for https/mtls modes (if using real server)
   - Test tokens for token-based modes (if using real server)

## Concrete Examples

### Example: HTTP Mode Test

```python
async def test_http_mode():
    config = create_test_config("http", host="test_host", port=8000)
    async with EmbeddingServiceAsyncClient.from_config(config) as client:
        result = await client.embed(["test text"])
        assert "results" in result or "embeddings" in result
```

### Example: mTLS Mode Test

```python
async def test_mtls_mode():
    config = create_test_config(
        "mtls",
        host="test_host",
        port=8000,
        cert_file="test_cert.crt",
        key_file="test_key.key",
        ca_cert_file="test_ca.crt"
    )
    async with EmbeddingServiceAsyncClient.from_config(config) as client:
        result = await client.embed(["test text"])
        assert "results" in result or "embeddings" in result
```

### Example: Invalid Config Test

```python
async def test_invalid_config():
    config = create_test_config("mtls", host="test_host", port=8000)
    # Missing cert files
    with pytest.raises(EmbeddingServiceConfigError):
        async with EmbeddingServiceAsyncClient.from_config(config) as client:
            pass
```

## Algorithm Descriptions

### Security Mode Test Algorithm

1. **Create Test Config**:
   - Determine security mode parameters (protocol, auth, ssl)
   - Build configuration dict with required fields
   - Apply any test-specific overrides

2. **Construct Client**:
   - Use `EmbeddingServiceAsyncClient.from_config()` or equivalent adapter-backed method
   - Verify no custom transport/auth logic is used
   - Use context manager for proper cleanup

3. **Execute Test Command**:
   - Call `embed()`, `models()`, or `timing_stats()`
   - Verify command executes successfully
   - Verify result structure is valid

4. **Validate Adapter Usage**:
   - Verify client uses adapter-backed transport (no direct HTTP/TLS)
   - Verify config maps to adapter-compatible params
   - Verify no custom auth execution logic

5. **Test Error Handling**:
   - Test invalid configs raise appropriate exceptions
   - Test connection failures are handled correctly

## Forbidden Approaches

- Do not use localhost:8001 (use test server or mocks)
- Do not create custom transport/auth logic in tests
- Do not bypass adapter-backed client construction
- Do not test only one security mode (must test all 8)
- Do not skip security modes due to test server limitations (use mocks if needed)
