# Atomic Steps Index: Timeout Policy Improvements (Step 4)

## Goal
Update timeout defaults in maintained real-server scripts to match server performance characteristics. These are configuration/timeout policy changes only — no client code logic changes.

## Parent Documents
- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

## Atomic Steps

### Step 4.1: Update Timeout in run_bidirectional_ws_performance.py
**File**: `update-timeout-bidirectional-ws-performance.md`
**Target**: `scripts/run_bidirectional_ws_performance.py`
**Dependencies**: Steps 1-3 (adapter-centric-client-foundation, embed-command-and-result-contract-alignment, queue-and-websocket-identifier-separation)
**Key Changes**:
- Change default timeout from 60.0 to 300.0 in `main_async()` function signature (line 283)
- Change default timeout from 60.0 to 300.0 in argparse default (line 368)
- Update help text to reflect new default (300 instead of 60)
- Preserve `--timeout` argument functionality

### Step 4.2: Update Timeout in compare_direct_vs_client.py
**File**: `update-timeout-compare-direct-vs-client.md`
**Target**: `scripts/compare_direct_vs_client.py`
**Dependencies**: Steps 1-3
**Key Changes**:
- Change default timeout from 60.0 to 300.0 in `run_client_timing()` function signature (line 86)
- Change default timeout from 60.0 to 300.0 in argparse default (line 131)
- Preserve `--timeout` argument functionality

### Step 4.3: Update Timeout in run_batch_performance.py
**File**: `update-timeout-batch-performance.md`
**Target**: `scripts/run_batch_performance.py`
**Dependencies**: Steps 1-3
**Key Changes**:
- Change default timeout from 120.0 to 300.0 in argparse default (line 133)
- Preserve `--timeout` argument functionality

## Parallel Execution

All three atomic steps can be executed in parallel because:
1. Each step modifies a different script file
2. All steps depend only on Steps 1-3 (which are already complete)
3. No step depends on another atomic step in this timeout policy update set
4. These are independent timeout default changes with no cross-file dependencies

## Common Patterns Across All Steps

### Timeout Policy Updates
- Always update both function signature defaults AND argparse defaults for consistency (when both exist)
- Always preserve `--timeout` argument functionality (users can still override)
- Always update help text if it mentions the default value
- Never change timeout handling logic, only default values

### Validation Requirements
- Syntax check (`python -m py_compile`)
- Type check (`mypy`, if configured)
- Lint check (`flake8`)
- Format check (`black --check`)
- Verify timeout defaults are updated correctly
- Manual verification (`--help` flag)

## Completion Criteria

All timeout policy atomic steps are complete when:
1. All 3 script files have updated timeout defaults (60.0 → 300.0 or 120.0 → 300.0)
2. All validation commands pass for each script
3. All scripts preserve `--timeout` argument functionality
4. All scripts use consistent timeout defaults (300.0 seconds)
