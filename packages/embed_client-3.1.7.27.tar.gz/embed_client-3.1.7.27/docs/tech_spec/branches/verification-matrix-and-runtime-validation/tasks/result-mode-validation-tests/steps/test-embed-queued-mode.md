Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Test Embed Queued Mode

## Executor Role

`coder_auto` - implements test file for queued result mode validation with status polling.

## Execution Directive

Create test file `tests/test_embed_queued_mode.py` that validates queued result mode behavior. The test file must verify that the client correctly detects queued results (job_id present), extracts job_id, performs status polling, waits for completion, normalizes results, and maintains identifier separation.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/result-mode-validation-tests.md`

## Step Scope

**Target file**: `tests/test_embed_queued_mode.py`
**Action**: create

This step creates a new test file that validates queued JSON-RPC result mode. The file must test:
- Queued result detection (job_id present in response)
- job_id extraction from queued result
- Status polling via `job_status()` method
- Waiting for completion via `wait_for_job()` method
- Result normalization after completion
- Identifier separation (no mixing of JSON-RPC request id with job_id)

## Dependency Contract

**Prerequisites**:
- Step 1: adapter-centric-client-foundation (must complete first)
- Step 2: embed-command-and-result-contract-alignment (must complete first)
- Step 3: queue-and-websocket-identifier-separation (must complete first)

**Dependencies on other atomic steps**:
- None (this step can run in parallel with other test file creation steps)

**Downstream dependencies**:
- None (this is a test file, no code depends on it)

## Required Context

The test file must validate:
1. Queued result detection: when server returns job_id, client must detect this as queued mode
2. job_id extraction: client must extract job_id from correct location in response (not JSON-RPC request id)
3. Status polling: client must correctly poll job status via `job_status()` method
4. Wait for completion: client must correctly wait for job completion via `wait_for_job()` method
5. Result normalization: final result after completion must be normalized correctly
6. Identifier separation: JSON-RPC request id must not be used as job_id

## Read First

Before implementing, read these files:
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - for result mode contracts and identifier model
2. `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` - for client methods and result structures
3. `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` - for embed() method and job_id extraction
4. `/home/vasilyvz/projects/embed-client/embed_client/async_client_queue_mixin.py` - for queue methods and waiting behavior
5. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - for adapter response formats
6. `/home/vasilyvz/projects/embed-client/tests/conftest.py` - for existing test fixtures and patterns
7. `/home/vasilyvz/projects/embed-client/tests/test_async_client.py` - for test structure examples

## Expected File Change

**File**: `tests/test_embed_queued_mode.py`
**Action**: create

The file must contain:
- File header docstring with author and email
- Import statements (pytest, asyncio, EmbeddingServiceAsyncClient, exceptions, etc.)
- Test class `TestEmbedQueuedMode` with pytest-style test methods
- Test methods for queued result detection, job_id extraction, status polling, waiting, normalization, and identifier separation
- Proper async test fixtures and mock setup if needed

## Forbidden Alternatives

- Do NOT assume all results are queued (must handle immediate mode in separate tests)
- Do NOT use JSON-RPC request id as job_id
- Do NOT mix job_id with WebSocket correlation identifier (covered in separate test)
- Do NOT skip result normalization validation
- Do NOT create tests that depend on real server (use mocks or fixtures)
- Do NOT modify core client implementation files
- Do NOT use unittest.TestCase if project uses pytest (check conftest.py pattern)
- Do NOT test WebSocket completion here (covered in test_websocket_completion.py)

## Atomic Operations

### File Structure

1. **File header docstring**:
   - Author: Vasiliy Zdanovskiy
   - email: vasilyvz@gmail.com
   - Brief description: "Tests for queued JSON-RPC result mode validation with status polling"

2. **Import section** (exact imports required):
   ```python
   import pytest
   import pytest_asyncio
   import asyncio
   from typing import Dict, Any, Optional
   from unittest.mock import AsyncMock, MagicMock, patch
   from embed_client.async_client import EmbeddingServiceAsyncClient
   from embed_client.exceptions import (
       EmbeddingServiceError,
       EmbeddingServiceAPIError,
       EmbeddingServiceTimeoutError,
   )
   from embed_client.config import ClientConfig
   from embed_client.identifier_types import JobId
   ```

3. **Test class**: `TestEmbedQueuedMode`
   - Base: pytest class (no base class needed, use pytest fixtures)
   - Purpose: Test queued JSON-RPC result mode with status polling

### Test Methods

#### Method 1: `test_queued_result_detection() -> None`

**Purpose**: Verify queued result is detected correctly (job_id present in response)

**Algorithm**:
1. Create mock adapter transport that returns queued result (with job_id)
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test text"], wait=False)` or `submit_job(...)`
4. Extract result from embed() call
5. Assert result contains "job_id" key at appropriate level (top-level or nested in result.data)
6. Assert result does NOT contain final business payload (embeddings/results) at top level
7. Assert result may contain status metadata ("status": "pending", "message": "accepted")

**Expected result structure**:
- `{"job_id": "job-123", "status": "pending", "message": "accepted"}` OR
- `{"result": {"success": true, "data": {"job_id": "job-123", "status": "pending"}}}` OR
- `{"mode": "queued", "job_id": "job-123", "result": {...}}`

**Error handling**:
- If result does not contain job_id: test fails with assertion error
- If result contains final payload at top level: test fails (should be queued, not immediate)

**Edge cases**:
- Result with job_id at top level: should pass
- Result with job_id nested in result.data: should pass
- Result with job_id in multiple locations: should pass (extract from first valid location)
- Result with job_id=None: should fail (job_id must be non-empty string)

#### Method 2: `test_job_id_extraction() -> None`

**Purpose**: Verify job_id is extracted correctly from queued result

**Algorithm**:
1. Create mock adapter transport that returns queued result with job_id at different nesting levels
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test"], wait=False)`
4. Extract result
5. Extract job_id from result (using client's extraction logic or manual extraction for test)
6. Assert job_id is a non-empty string
7. Assert job_id matches expected value from mock response
8. Assert job_id is NOT equal to JSON-RPC request id (if JSON-RPC id is exposed in mocks)
9. Assert job_id is of type JobId (if using identifier_types.JobId)

**Job ID extraction locations to test**:
- Top-level: `result.get("job_id")`
- Nested in result: `result.get("result", {}).get("job_id")`
- Nested in result.data: `result.get("result", {}).get("data", {}).get("job_id")`
- Top-level data: `result.get("data", {}).get("job_id")`

**Error handling**:
- If job_id not found: test fails with assertion error
- If job_id is empty string: test fails with assertion error
- If job_id equals JSON-RPC request id: test fails (identifier mixing)

**Edge cases**:
- job_id at top level: should extract from top level
- job_id nested in result.data: should extract from nested location
- job_id in multiple locations: should extract from first valid location (priority order)
- job_id with whitespace: should be stripped (if extraction logic strips)

#### Method 3: `test_job_status_polling() -> None`

**Purpose**: Verify status polling via `job_status()` method

**Algorithm**:
1. Create mock adapter transport that returns queued result with job_id="job-123"
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test"], wait=False)` to get job_id
4. Mock `job_status()` to return status progression: "pending" -> "running" -> "completed"
5. Call `job_status(job_id)` multiple times
6. Assert first call returns status="pending" or status="running"
7. Assert subsequent calls return status progression
8. Assert final call returns status="completed" with done=True
9. Assert status result contains expected structure: `{"exists": True, "status": "...", "done": bool, "result": {...}}`

**Status progression to test**:
- Initial: `{"exists": True, "status": "pending", "done": False}`
- Intermediate: `{"exists": True, "status": "running", "done": False}`
- Final: `{"exists": True, "status": "completed", "done": True, "result": {...}}`

**Error handling**:
- If job_status() raises exception: test should verify exception type and message
- If status never progresses: test should handle timeout scenario
- If status returns "failed": test should verify error handling

**Edge cases**:
- Status "pending" indefinitely: should handle gracefully (timeout scenario)
- Status "failed": should raise EmbeddingServiceAPIError
- Status with exists=False: should handle job not found scenario
- Status with missing fields: should handle gracefully

#### Method 4: `test_wait_for_job() -> None`

**Purpose**: Verify `wait_for_job()` completes successfully

**Algorithm**:
1. Create mock adapter transport that returns queued result with job_id="job-123"
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test"], wait=False)` to get job_id
4. Mock `job_status()` to return status progression: "pending" -> "completed" (after delay)
5. Call `wait_for_job(job_id, timeout=60.0)`
6. Assert method returns final result (not status dict)
7. Assert final result contains business payload (embeddings or results)
8. Assert final result contains model, dimension, device fields
9. Assert method completes within timeout

**Wait behavior to test**:
- Job already completed: should return immediately
- Job pending then completes: should wait and return final result
- Job fails: should raise EmbeddingServiceAPIError
- Timeout exceeded: should raise EmbeddingServiceTimeoutError

**Error handling**:
- If timeout exceeded: should raise EmbeddingServiceTimeoutError
- If job fails: should raise EmbeddingServiceAPIError
- If job not found: should raise appropriate error

**Edge cases**:
- Timeout=None: should return immediately without waiting
- Timeout=0: should wait indefinitely (test with mock that eventually completes)
- Job completes immediately: should return without polling delay
- Multiple wait_for_job calls: should work correctly

#### Method 5: `test_queued_result_normalization() -> None`

**Purpose**: Verify result normalization after completion

**Algorithm**:
1. Create mock adapter transport that returns queued result with job_id
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test 1", "test 2"], model="test-model", dimension=768, device="cpu", wait=False)`
4. Get job_id from result
5. Mock `wait_for_job()` to return completed result with server contract structure
6. Call `wait_for_job(job_id)` to get final result
7. Assert final result contains "results" list OR "embeddings" list
8. If "results" present: assert each result item contains expected fields (body, embedding, tokens, bm25_tokens)
9. If "embeddings" present: assert embeddings is a list of lists
10. Assert final result contains "model" field matching input model
11. Assert final result contains "dimension" field matching input dimension
12. Assert final result contains "device" field matching input device
13. Assert final result does NOT contain "job_id" (normalized out)

**Normalized structure after completion**:
- `{"results": [{"body": "text", "embedding": [...], ...}], "model": "test-model", "dimension": 768, "device": "cpu"}` OR
- `{"embeddings": [[...], [...]], "model": "test-model", "dimension": 768, "device": "cpu"}`

**Error handling**:
- If normalization fails: test fails with assertion error
- If required fields missing: test fails with assertion error

**Edge cases**:
- Result with both "results" and "embeddings": both should be valid
- Result with only "results": should pass
- Result with only "embeddings": should pass
- Result with job_id still present: should fail (should be normalized out)

#### Method 6: `test_identifier_separation() -> None`

**Purpose**: Verify JSON-RPC request id is not used as job_id

**Algorithm**:
1. Create mock adapter transport that tracks JSON-RPC request id separately from job_id
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test"], wait=False)`
4. Extract JSON-RPC request id from mock (if exposed in mocks)
5. Extract job_id from result
6. Assert job_id is NOT equal to JSON-RPC request id
7. Assert job_id is a valid job identifier (non-empty string, matches expected pattern if any)
8. Assert JSON-RPC request id (if exposed) is distinct from job_id
9. Call `job_status(job_id)` and verify it uses job_id (not JSON-RPC id)
10. Call `wait_for_job(job_id)` and verify it uses job_id (not JSON-RPC id)

**Identifier separation validation**:
- Verify job_id extracted from result is not JSON-RPC request id
- Verify job_id is used for status polling (not JSON-RPC id)
- Verify job_id is used for waiting (not JSON-RPC id)
- Verify JSON-RPC id (if exposed) remains separate from job_id throughout flow

**Error handling**:
- If job_id equals JSON-RPC request id: test fails (identifier mixing)
- If job_id is None or empty: test fails

**Edge cases**:
- JSON-RPC id is numeric, job_id is string: should be distinct
- JSON-RPC id is string, job_id is string: should be distinct even if same format
- Multiple embed calls: each should have distinct JSON-RPC id and job_id pairs

### Test Fixtures

**Fixture**: `mock_queued_result(job_id: str = "job-123") -> Dict[str, Any]`
- Parameters: job_id (optional, default "job-123")
- Returns: Dictionary representing queued result from server
- Structure: `{"job_id": job_id, "status": "pending", "message": "accepted"}` OR nested format
- Purpose: Reusable mock data for queued results

**Fixture**: `mock_job_status(status: str, done: bool, result: Optional[Dict] = None) -> Dict[str, Any]`
- Parameters: status (str), done (bool), result (optional dict)
- Returns: Dictionary representing job status response
- Structure: `{"exists": True, "status": status, "done": done, "result": result}`
- Purpose: Reusable mock data for job status responses

**Fixture**: `mock_adapter_transport_queued() -> AsyncMock`
- Returns: Mocked AdapterTransport that returns queued results
- Purpose: Mock transport layer for queued mode tests
- Behavior: `execute_command_unified()` returns queued result dict with job_id

### Constants and Literals

- Test texts: `["test text"]`, `["test text 1", "test text 2"]`
- Test model: `"test-model"`
- Test dimension: `768`
- Test device: `"cpu"`
- Test job_id: `"job-123"` (example value)
- Expected status values: `"pending"`, `"running"`, `"completed"`, `"failed"`
- Expected result keys: `"results"`, `"embeddings"`, `"model"`, `"dimension"`, `"device"`
- Required queued result keys: `"job_id"`
- Timeout values: `60.0` (default), `None` (no wait), `0` (indefinite)

## Expected Deliverables

1. File `tests/test_embed_queued_mode.py` created
2. File contains class `TestEmbedQueuedMode` with 6 test methods
3. All test methods are async and use pytest-asyncio
4. All test methods validate queued result mode behavior
5. File follows project code style (black, flake8, mypy compliant)
6. File contains proper docstrings and type annotations

## Mandatory Validation

After implementation, run these exact commands:

1. **Format check**:
   ```bash
   black tests/test_embed_queued_mode.py
   ```
   Expected: "reformatted" or "already well formatted" (exit 0)

2. **Lint check**:
   ```bash
   flake8 tests/test_embed_queued_mode.py
   ```
   Expected: no output (exit 0)

3. **Type check**:
   ```bash
   mypy tests/test_embed_queued_mode.py
   ```
   Expected: "Success: no issues found" (exit 0)

4. **Test execution**:
   ```bash
   pytest tests/test_embed_queued_mode.py -v
   ```
   Expected: all tests PASSED (may require mocks/fixtures to be set up correctly)

**All validation commands must pass before considering this step complete.**

## Decision Rules

1. **Test framework**: Use pytest (not unittest) based on conftest.py patterns
2. **Async tests**: Use `@pytest.mark.asyncio` decorator for async test methods
3. **Mocking strategy**: Mock AdapterTransport, not internal adapter client
4. **Result structure**: Accept both "results" and "embeddings" formats (server may return either)
5. **Identifier validation**: Verify job_id is distinct from JSON-RPC request id at all stages
6. **Status progression**: Test status transitions (pending -> running -> completed)
7. **Timeout handling**: Test timeout=None (immediate), timeout=0 (indefinite), timeout>0 (limited)

## Blackstops

Stop and escalate if:
- Core client implementation needs changes to support queued mode detection (affects Step 2)
- job_id extraction logic requires changes to async_client_api_mixin (affects Step 2)
- Status polling logic requires changes to async_client_queue_mixin (affects Step 3)
- Adapter response format contradicts expected queued result structure (affects Step 1)

## Handoff Package

**For coder_auto**:
- Target file: `tests/test_embed_queued_mode.py`
- Action: create
- Test class: `TestEmbedQueuedMode`
- Test methods: 6 methods (test_queued_result_detection, test_job_id_extraction, test_job_status_polling, test_wait_for_job, test_queued_result_normalization, test_identifier_separation)
- Required imports: pytest, pytest_asyncio, asyncio, typing, unittest.mock, embed_client modules, identifier_types
- Validation commands: black, flake8, mypy, pytest
- Expected outcome: All tests pass, file follows project standards
