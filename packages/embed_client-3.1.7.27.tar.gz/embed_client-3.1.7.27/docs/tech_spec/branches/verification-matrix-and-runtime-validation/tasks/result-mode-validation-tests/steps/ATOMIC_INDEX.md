Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Result Mode Validation Tests

## Goal

Create comprehensive test coverage to validate that the synchronized client correctly handles both immediate JSON-RPC result mode and queued result mode (with JSON-RPC status polling and/or adapter-managed WebSocket completion).

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/result-mode-validation-tests.md`

## Atomic Steps Summary

This tactical task is decomposed into **3 atomic steps**, each creating one test file:

1. **test-embed-immediate-mode.md** → `tests/test_embed_immediate_mode.py`
2. **test-embed-queued-mode.md** → `tests/test_embed_queued_mode.py`
3. **test-websocket-completion.md** → `tests/test_websocket_completion.py`

## Dependency Order

All 3 atomic steps are **parallel-safe** and can be executed concurrently:

- No dependencies between atomic steps (each creates a separate test file)
- All steps depend on the same prerequisites (Steps 1-3 from global plan)
- No step modifies files that other steps read or write

## Atomic Waves

### Wave 1 (Parallel Execution)

All 3 steps can run in parallel:

1. **Step 1**: `test-embed-immediate-mode.md`
   - Target: `tests/test_embed_immediate_mode.py`
   - Tests: Immediate JSON-RPC result mode

2. **Step 2**: `test-embed-queued-mode.md`
   - Target: `tests/test_embed_queued_mode.py`
   - Tests: Queued result mode with status polling

3. **Step 3**: `test-websocket-completion.md`
   - Target: `tests/test_websocket_completion.py`
   - Tests: Adapter-managed WebSocket completion

## Step Details

### Step 1: test-embed-immediate-mode.md

**File**: `tests/test_embed_immediate_mode.py`
**Action**: create
**Test class**: `TestEmbedImmediateMode`
**Test methods**: 4 methods
- `test_immediate_result_detection()` - Verify immediate result is detected (no job_id)
- `test_immediate_result_normalization()` - Verify result normalization
- `test_immediate_result_structure()` - Verify result structure matches contract
- `test_immediate_no_job_id()` - Verify no job_id is invented

**Validation focus**:
- Immediate result detection (no job_id in response)
- Result normalization (embeddings, results, model, dimension, device)
- Result structure validation
- No job_id invention

### Step 2: test-embed-queued-mode.md

**File**: `tests/test_embed_queued_mode.py`
**Action**: create
**Test class**: `TestEmbedQueuedMode`
**Test methods**: 6 methods
- `test_queued_result_detection()` - Verify queued result is detected (job_id present)
- `test_job_id_extraction()` - Verify job_id is extracted correctly
- `test_job_status_polling()` - Verify status polling via job_status()
- `test_wait_for_job()` - Verify wait_for_job() completes successfully
- `test_queued_result_normalization()` - Verify result normalization after completion
- `test_identifier_separation()` - Verify JSON-RPC id is not used as job_id

**Validation focus**:
- Queued result detection (job_id present)
- job_id extraction and storage
- Status polling and waiting
- Result normalization after completion
- Identifier separation

### Step 3: test-websocket-completion.md

**File**: `tests/test_websocket_completion.py`
**Action**: create
**Test class**: `TestWebSocketCompletion`
**Test methods**: 4 methods
- `test_websocket_waiting()` - Verify wait_for_job_via_websocket() works
- `test_websocket_result_delivery()` - Verify result delivery through WebSocket
- `test_websocket_timeout()` - Verify timeout handling
- `test_websocket_identifier_separation()` - Verify job_id vs WebSocket correlation id separation

**Validation focus**:
- WebSocket waiting behavior
- Result delivery through WebSocket
- Timeout handling
- Identifier separation (job_id vs WebSocket correlation id)

## Execution Strategy

### Recommended: Parallel Execution

Execute all 3 steps in parallel to maximize efficiency:
- Each step creates a separate test file
- No file conflicts or dependencies
- Faster overall completion

### Alternative: Sequential Execution

If parallel execution is not available, execute in any order:
1. Step 1 → Step 2 → Step 3
2. Or any other order (all are independent)

## Validation Requirements

After all steps complete, verify:
1. All 3 test files exist
2. All test files pass black, flake8, mypy checks
3. All test files can be executed with pytest (may require mocks/fixtures)
4. Test coverage validates:
   - Immediate mode detection and normalization
   - Queued mode detection, job_id extraction, polling, waiting
   - WebSocket completion, timeout handling, identifier separation

## Completion Criteria

All atomic steps are complete when:
1. All 3 test files are created
2. All test files follow project code standards (black, flake8, mypy)
3. All test files contain proper docstrings and type annotations
4. All test methods are implemented according to step specifications
5. All validation commands pass for each test file
