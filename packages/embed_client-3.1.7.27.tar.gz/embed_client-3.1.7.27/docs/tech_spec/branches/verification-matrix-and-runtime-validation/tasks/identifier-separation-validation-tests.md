Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Identifier Separation Validation Tests

## Purpose

Create comprehensive test coverage to validate that the synchronized client correctly separates and handles different identifier types (JSON-RPC request `id`, server `job_id`, adapter-managed WebSocket correlation identifier) without conflation. Ensure tests verify identifier-safe behavior across all execution paths.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`

## Scope

### Included

- Create or modify `tests/test_identifier_separation.py` to validate identifier separation
- Test JSON-RPC request `id` is never exposed as public API parameter or return value
- Test `job_id` is extracted only from server/adapter fields that explicitly represent queued-job identity
- Test WebSocket correlation identifiers are used only inside adapter-managed async/WebSocket flows
- Test `job_id` and WebSocket correlation identifiers are not merged unless adapter contract explicitly guarantees equivalence
- Test missing or ambiguous identifiers are treated as explicit errors, not silently guessed
- Validate identifier-safe behavior in all execution paths (immediate, queued, WebSocket)

### Excluded

- Result mode validation (covered in separate tactical task)
- Security matrix validation (covered in separate tactical task)
- Real-server runtime validation on localhost:8001 (covered in separate tactical task)

## Boundaries

This task must NOT touch:
- Core client implementation files (already updated in Steps 1-3)
- Adapter transport layer (already updated in Step 1)
- Real-server scripts (covered in separate tactical task)

## Dependencies

- Step 1: adapter-centric-client-foundation (must complete first)
- Step 2: embed-command-and-result-contract-alignment (must complete first)
- Step 3: queue-and-websocket-identifier-separation (must complete first)

This tactical task depends on all prior steps, especially Step 3 which implements identifier separation.

## Parallelization Note

This tactical task can run in parallel with:
- `security-matrix-validation-tests.md`
- `result-mode-validation-tests.md`
- `update-maintained-real-server-scripts.md`

## Expected Outcome

1. Test file `tests/test_identifier_separation.py` exists and validates identifier separation
2. Tests validate:
   - JSON-RPC request `id` is never exposed as public API parameter or return value
   - `job_id` is extracted only from server/adapter fields that explicitly represent queued-job identity
   - WebSocket correlation identifiers are used only inside adapter-managed async/WebSocket flows
   - `job_id` and WebSocket correlation identifiers are not merged unless adapter contract explicitly guarantees equivalence
   - Missing or ambiguous identifiers are treated as explicit errors
3. Tests cover all execution paths:
   - Immediate JSON-RPC result mode
   - Queued result with status polling
   - Queued result with WebSocket completion
4. All tests pass and produce clear failure messages

## Correction Items

None (this is a new test file creation task).

## Questions/Escalation Rule

Escalate to global orchestrator if:
- Identifier separation logic requires changes to core client (affects Step 3)
- Adapter contract changes affect identifier equivalence guarantees (affects Step 1 or 3)
- Identifier handling contradicts server contract (affects Step 2 or 3)

## File Inventory

### Files to Create or Modify

1. **Action**: create or modify
   **Path**: `tests/test_identifier_separation.py`
   **Purpose**: Comprehensive test suite for identifier separation validation

### Files to Read (Reference Only)

1. **Path**: `embed_client/async_client.py`
   **Purpose**: Reference for client methods and identifier handling

2. **Path**: `embed_client/async_client_queue_mixin.py`
   **Purpose**: Reference for queue methods and identifier extraction

3. **Path**: `embed_client/adapter_transport.py`
   **Purpose**: Reference for adapter response formats and identifier fields

4. **Path**: `embed_client/identifier_types.py` (if exists)
   **Purpose**: Reference for identifier type definitions

5. **Path**: `docs/tech_spec/tech_spec.md`
   **Purpose**: Reference for identifier model and operational identifier-safety rules

## Class/Function Inventory

### Test File Structure

1. **Class name**: `TestIdentifierSeparation`
   **Base class**: `unittest.TestCase` or pytest class
   **Purpose**: Test suite for identifier separation validation
   **Public methods**:
   - `test_jsonrpc_id_not_exposed() -> None`: Verify JSON-RPC request id is not exposed in public API
   - `test_job_id_extraction() -> None`: Verify job_id is extracted only from correct fields
   - `test_websocket_correlation_separation() -> None`: Verify WebSocket correlation id is kept separate from job_id
   - `test_identifier_not_merged() -> None`: Verify identifiers are not merged unless adapter guarantees equivalence
   - `test_missing_identifier_error() -> None`: Verify missing identifiers raise explicit errors
   - `test_ambiguous_identifier_error() -> None`: Verify ambiguous identifiers raise explicit errors
   - `test_immediate_mode_no_job_id() -> None`: Verify immediate mode does not invent job_id
   - `test_queued_mode_job_id_extraction() -> None`: Verify queued mode extracts job_id correctly
   - `test_websocket_mode_identifier_separation() -> None`: Verify WebSocket mode keeps identifiers separate

## Data Structures

### Identifier Test Patterns

1. **JSON-RPC Request ID**:
   - Scope: JSON-RPC protocol only
   - Ownership: adapter transport layer
   - Must not be exposed in public API

2. **Job ID**:
   - Scope: queue/job lifecycle
   - Source: server queued response (`job_id` field)
   - Uses: status lookup, wait-for-completion APIs, queue management

3. **WebSocket Correlation ID**:
   - Scope: adapter-managed async/WebSocket execution
   - Ownership: adapter-managed delivery/correlation
   - Must be kept separate from job_id unless adapter guarantees equivalence

## Import Map

### For tests/test_identifier_separation.py

- `import pytest` or `import unittest`
- `import asyncio`
- `from embed_client.async_client import EmbeddingServiceAsyncClient`
- `from embed_client.config import ClientConfig` (if needed)
- `from embed_client.exceptions import EmbeddingServiceError, EmbeddingServiceJSONError`
- `from tests.conftest import *` (if fixtures available)

## Error Handling Map

### For Test Execution

1. **Missing job_id Error**:
   - **Exception**: `EmbeddingServiceJSONError` or `ValueError`
   - **Condition**: Queued operation result does not contain `job_id` when expected
   - **Action**: Test should assert explicit error is raised, not silent guess

2. **Ambiguous Identifier Error**:
   - **Exception**: `EmbeddingServiceJSONError` or `ValueError`
   - **Condition**: Response contains ambiguous identifier fields
   - **Action**: Test should assert explicit error is raised

3. **Identifier Mixing Detection**:
   - **Condition**: JSON-RPC request id used as job_id or WebSocket correlation id
   - **Action**: Test should assert identifiers are kept separate

## Config Dependency

### Tests Use These Config Keys

1. **Server Endpoint**:
   - **Key**: `server.host`, `server.port`
   - **Type**: `str`, `int`
   - **Access**: Via test config construction

2. **Protocol**:
   - **Key**: `protocol` or `server.protocol`
   - **Type**: `str`
   - **Access**: Via test config construction

## Test Plan

### For tests/test_identifier_separation.py

1. **Test JSON-RPC ID Not Exposed**:
   - Verify JSON-RPC request id is not in public API parameters
   - Verify JSON-RPC request id is not in public API return values
   - Verify JSON-RPC request id is not used as job identifier

2. **Test Job ID Extraction**:
   - Verify job_id is extracted only from `job_id` field in server response
   - Verify job_id is not extracted from JSON-RPC request id
   - Verify job_id is not extracted from WebSocket correlation id

3. **Test WebSocket Correlation Separation**:
   - Verify WebSocket correlation id is kept separate from job_id
   - Verify WebSocket correlation id is used only in adapter-managed flows
   - Verify job_id is used for WebSocket waiting operations

4. **Test Identifier Not Merged**:
   - Verify identifiers are not merged unless adapter contract explicitly guarantees equivalence
   - Verify each identifier type maintains its own scope

5. **Test Missing/Ambiguous Identifier Errors**:
   - Verify missing job_id in queued result raises explicit error
   - Verify ambiguous identifier fields raise explicit error
   - Verify no silent guessing or default values

6. **Test Immediate Mode**:
   - Verify immediate mode does not invent job_id
   - Verify immediate mode does not expose JSON-RPC request id

7. **Test Queued Mode**:
   - Verify queued mode extracts job_id correctly
   - Verify queued mode does not use JSON-RPC request id as job_id

8. **Test WebSocket Mode**:
   - Verify WebSocket mode keeps job_id and correlation id separate
   - Verify WebSocket waiting uses job_id, not correlation id

## Concrete Examples

### Example: JSON-RPC ID Not Exposed Test

```python
async def test_jsonrpc_id_not_exposed():
    async with EmbeddingServiceAsyncClient.from_config(config) as client:
        result = await client.embed(["test text"])
        # JSON-RPC request id should not be in public API result
        assert "id" not in result  # JSON-RPC protocol id
        # If job_id is present, it should be from server, not JSON-RPC id
        if "job_id" in result:
            # job_id should be a string, not a number (JSON-RPC id is usually number)
            assert isinstance(result["job_id"], str)
```

### Example: Job ID Extraction Test

```python
async def test_job_id_extraction():
    async with EmbeddingServiceAsyncClient.from_config(config) as client:
        # Submit queued job
        result = await client.embed(["test text"], wait=False)
        # job_id should be extracted from server response, not JSON-RPC id
        assert "job_id" in result
        job_id = result["job_id"]
        # job_id should be a string (server job identifier)
        assert isinstance(job_id, str)
        # job_id should not be a number (JSON-RPC id is usually number)
        assert not job_id.isdigit() or len(job_id) > 10  # Server job_id format
```

### Example: WebSocket Correlation Separation Test

```python
async def test_websocket_correlation_separation():
    async with EmbeddingServiceAsyncClient.from_config(config) as client:
        # Submit queued job
        result = await client.embed(["test text"], wait=False)
        job_id = result["job_id"]
        # Wait via WebSocket
        final_result = await client.wait_for_job_via_websocket(job_id, timeout=60.0)
        # WebSocket correlation id (if present) should be separate from job_id
        # job_id should still be used for the operation
        assert "results" in final_result or "embeddings" in final_result
        # If adapter exposes correlation id, it should be separate field
        # (implementation depends on adapter contract)
```

### Example: Missing Identifier Error Test

```python
async def test_missing_job_id_error():
    async with EmbeddingServiceAsyncClient.from_config(config) as client:
        # Simulate queued operation that should return job_id but doesn't
        # (requires mock or test server configuration)
        # Expected: explicit error, not silent guess
        with pytest.raises(EmbeddingServiceJSONError) or pytest.raises(ValueError):
            # Operation that should have job_id but doesn't
            pass
```

## Algorithm Descriptions

### Identifier Separation Test Algorithm

1. **Test JSON-RPC ID Isolation**:
   - Execute client operations
   - Verify JSON-RPC request id is not in public API results
   - Verify JSON-RPC request id is not used as job identifier

2. **Test Job ID Extraction**:
   - Submit queued job
   - Verify job_id is extracted from correct field (`job_id` in server response)
   - Verify job_id is not extracted from JSON-RPC request id
   - Verify job_id format matches server contract (string, not number)

3. **Test WebSocket Correlation Separation**:
   - Submit queued job and wait via WebSocket
   - Verify job_id is used for WebSocket waiting
   - Verify WebSocket correlation id (if present) is kept separate
   - Verify no mixing of job_id and correlation id

4. **Test Identifier Not Merged**:
   - Execute operations that involve multiple identifier types
   - Verify each identifier maintains its own scope
   - Verify identifiers are not merged unless adapter contract guarantees equivalence

5. **Test Missing/Ambiguous Identifier Errors**:
   - Simulate missing job_id scenarios
   - Verify explicit errors are raised, not silent guesses
   - Verify error messages are clear

6. **Test All Execution Paths**:
   - Test immediate mode (no job_id)
   - Test queued mode with status polling (job_id extraction)
   - Test queued mode with WebSocket completion (job_id and correlation id separation)

## Forbidden Approaches

- Do not use JSON-RPC request id as job_id
- Do not merge job_id with WebSocket correlation id unless adapter guarantees equivalence
- Do not silently guess identifiers when missing
- Do not expose JSON-RPC request id in public API
- Do not skip identifier separation validation in any execution path
- Do not assume identifier equivalence without adapter contract guarantee
