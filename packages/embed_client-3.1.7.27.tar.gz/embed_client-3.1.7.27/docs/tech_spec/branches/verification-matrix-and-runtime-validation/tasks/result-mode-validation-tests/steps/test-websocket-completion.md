Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Test WebSocket Completion

## Executor Role

`coder_auto` - implements test file for adapter-managed WebSocket completion validation.

## Execution Directive

Create test file `tests/test_websocket_completion.py` that validates adapter-managed WebSocket completion behavior. The test file must verify that the client correctly waits for WebSocket completion, receives result delivery through WebSocket, handles timeouts, and maintains proper identifier separation between job_id and WebSocket correlation identifier.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/result-mode-validation-tests.md`

## Step Scope

**Target file**: `tests/test_websocket_completion.py`
**Action**: create

This step creates a new test file that validates adapter-managed WebSocket completion. The file must test:
- WebSocket waiting via `wait_for_job_via_websocket()` method
- Result delivery through adapter-managed WebSocket flow
- Timeout handling for WebSocket waiting
- Proper identifier handling (job_id vs WebSocket correlation id separation)

## Dependency Contract

**Prerequisites**:
- Step 1: adapter-centric-client-foundation (must complete first)
- Step 2: embed-command-and-result-contract-alignment (must complete first)
- Step 3: queue-and-websocket-identifier-separation (must complete first)

**Dependencies on other atomic steps**:
- None (this step can run in parallel with other test file creation steps)

**Downstream dependencies**:
- None (this is a test file, no code depends on it)

## Required Context

The test file must validate:
1. WebSocket waiting: client must correctly wait for job completion via `wait_for_job_via_websocket()` method
2. Result delivery: client must receive and normalize results delivered through adapter-managed WebSocket flow
3. Timeout handling: client must raise timeout exception when WebSocket wait exceeds timeout
4. Identifier separation: client must keep job_id and WebSocket correlation identifier separate (unless adapter explicitly guarantees equivalence)

## Read First

Before implementing, read these files:
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - for result mode contracts and identifier model
2. `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` - for client methods and result structures
3. `/home/vasilyvz/projects/embed-client/embed_client/async_client_queue_mixin.py` - for `wait_for_job_via_websocket()` method
4. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - for adapter WebSocket methods
5. `/home/vasilyvz/projects/embed-client/embed_client/identifier_types.py` - for DeliverId and JobId types
6. `/home/vasilyvz/projects/embed-client/tests/conftest.py` - for existing test fixtures and patterns
7. `/home/vasilyvz/projects/embed-client/tests/test_async_client.py` - for test structure examples

## Expected File Change

**File**: `tests/test_websocket_completion.py`
**Action**: create

The file must contain:
- File header docstring with author and email
- Import statements (pytest, asyncio, EmbeddingServiceAsyncClient, exceptions, identifier_types, etc.)
- Test class `TestWebSocketCompletion` with pytest-style test methods
- Test methods for WebSocket waiting, result delivery, timeout handling, and identifier separation
- Proper async test fixtures and mock setup if needed

## Forbidden Alternatives

- Do NOT test status polling here (covered in test_embed_queued_mode.py)
- Do NOT use JSON-RPC request id as job_id or WebSocket correlation id
- Do NOT mix job_id with WebSocket correlation identifier unless adapter explicitly guarantees equivalence
- Do NOT skip result normalization validation
- Do NOT create tests that depend on real server (use mocks or fixtures)
- Do NOT modify core client implementation files
- Do NOT use unittest.TestCase if project uses pytest (check conftest.py pattern)
- Do NOT test bidirectional WebSocket channels here (that's a separate feature)

## Atomic Operations

### File Structure

1. **File header docstring**:
   - Author: Vasiliy Zdanovskiy
   - email: vasilyvz@gmail.com
   - Brief description: "Tests for adapter-managed WebSocket completion validation"

2. **Import section** (exact imports required):
   ```python
   import pytest
   import pytest_asyncio
   import asyncio
   from typing import Dict, Any, Optional
   from unittest.mock import AsyncMock, MagicMock, patch
   from embed_client.async_client import EmbeddingServiceAsyncClient
   from embed_client.exceptions import (
       EmbeddingServiceError,
       EmbeddingServiceAPIError,
       EmbeddingServiceTimeoutError,
   )
   from embed_client.config import ClientConfig
   from embed_client.identifier_types import JobId, DeliverId
   ```

3. **Test class**: `TestWebSocketCompletion`
   - Base: pytest class (no base class needed, use pytest fixtures)
   - Purpose: Test adapter-managed WebSocket completion

### Test Methods

#### Method 1: `test_websocket_waiting() -> None`

**Purpose**: Verify `wait_for_job_via_websocket()` works correctly

**Algorithm**:
1. Create mock adapter transport that returns queued result with job_id="job-123"
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test"], wait=False)` to get job_id
4. Mock `wait_for_job_via_websocket()` to simulate WebSocket completion (return final result after delay)
5. Call `wait_for_job_via_websocket(job_id, timeout=60.0)`
6. Assert method returns final result (not status dict)
7. Assert final result contains business payload (embeddings or results)
8. Assert final result contains model, dimension, device fields
9. Assert method completes within timeout

**WebSocket waiting behavior to test**:
- Job completes via WebSocket: should return final result
- WebSocket connection established: should wait for completion
- Result delivered through WebSocket: should normalize and return

**Error handling**:
- If WebSocket connection fails: should raise EmbeddingServiceConnectionError or EmbeddingServiceError
- If timeout exceeded: should raise EmbeddingServiceTimeoutError (tested in separate method)
- If job fails: should raise EmbeddingServiceAPIError

**Edge cases**:
- Job already completed: should return immediately (if adapter supports this)
- WebSocket connection delay: should handle connection establishment time
- Multiple WebSocket waits: should work correctly for multiple jobs

#### Method 2: `test_websocket_result_delivery() -> None`

**Purpose**: Verify result delivery through WebSocket

**Algorithm**:
1. Create mock adapter transport that returns queued result with job_id="job-123"
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test 1", "test 2"], model="test-model", dimension=768, device="cpu", wait=False)`
4. Get job_id from result
5. Mock `wait_for_job_via_websocket()` to return completed result with server contract structure
6. Call `wait_for_job_via_websocket(job_id)` to get final result
7. Assert final result contains "results" list OR "embeddings" list
8. If "results" present: assert each result item contains expected fields (body, embedding, tokens, bm25_tokens)
9. If "embeddings" present: assert embeddings is a list of lists
10. Assert final result contains "model" field matching input model
11. Assert final result contains "dimension" field matching input dimension
12. Assert final result contains "device" field matching input device
13. Assert final result structure matches server contract

**WebSocket result structure**:
- Final business payload delivered through WebSocket
- May contain adapter-managed correlation identifier (separate from job_id)
- Structure: `{"results": [...], "embeddings": [...], "model": "...", "dimension": 768, "device": "cpu"}`

**Error handling**:
- If result delivery fails: should raise EmbeddingServiceError
- If result structure invalid: should raise EmbeddingServiceJSONError or assertion error
- If required fields missing: test fails with assertion error

**Edge cases**:
- Result with both "results" and "embeddings": both should be valid
- Result with only "results": should pass
- Result with only "embeddings": should pass
- Result with adapter correlation identifier: should preserve it separately from job_id

#### Method 3: `test_websocket_timeout() -> None`

**Purpose**: Verify timeout handling for WebSocket waiting

**Algorithm**:
1. Create mock adapter transport that returns queued result with job_id="job-123"
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test"], wait=False)` to get job_id
4. Mock `wait_for_job_via_websocket()` to simulate timeout (never completes, or completes after timeout)
5. Call `wait_for_job_via_websocket(job_id, timeout=1.0)` with short timeout
6. Assert method raises `EmbeddingServiceTimeoutError` when timeout exceeded
7. Assert exception message indicates timeout
8. Assert exception contains job_id or relevant context

**Timeout scenarios to test**:
- Timeout exceeded: should raise EmbeddingServiceTimeoutError
- Timeout=None: should wait indefinitely (test with mock that eventually completes)
- Timeout=0: should wait indefinitely (test with mock that eventually completes)
- Timeout with job that eventually completes: should raise timeout if exceeds timeout value

**Error handling**:
- If timeout exceeded: must raise EmbeddingServiceTimeoutError (not generic exception)
- If timeout is None: should wait indefinitely (no timeout exception)
- If timeout is 0: should wait indefinitely (no timeout exception)

**Edge cases**:
- Timeout exactly at completion time: should return result (not raise timeout)
- Timeout slightly before completion: should raise timeout
- Multiple timeout calls: should handle correctly

#### Method 4: `test_websocket_identifier_separation() -> None`

**Purpose**: Verify job_id vs WebSocket correlation id separation

**Algorithm**:
1. Create mock adapter transport that tracks job_id and WebSocket correlation identifier separately
2. Create EmbeddingServiceAsyncClient with mocked transport
3. Call `embed(texts=["test"], wait=False)` to get job_id
4. Extract job_id from result (should be JobId type)
5. Mock `wait_for_job_via_websocket()` to return result with WebSocket correlation identifier (deliver_id)
6. Call `wait_for_job_via_websocket(job_id)` and capture result
7. Extract WebSocket correlation identifier from result or adapter response (if exposed)
8. Assert job_id is NOT equal to WebSocket correlation identifier
9. Assert job_id is of type JobId (if using identifier_types.JobId)
10. Assert WebSocket correlation identifier is of type DeliverId (if using identifier_types.DeliverId and exposed)
11. Assert job_id is used for WebSocket subscription/waiting (not correlation id)
12. Assert result contains final business payload (not correlation identifier as business data)

**Identifier separation validation**:
- Verify job_id (JobId) is distinct from WebSocket correlation identifier (DeliverId)
- Verify job_id is used for WebSocket waiting (not correlation id)
- Verify correlation identifier (if exposed) remains separate from job_id
- Verify result normalization does not mix identifiers

**Error handling**:
- If job_id equals WebSocket correlation identifier (and adapter doesn't guarantee equivalence): test fails (identifier mixing)
- If identifiers are mixed in result: test fails

**Edge cases**:
- Adapter guarantees equivalence: should document this in test (but still verify separation in general case)
- Correlation identifier not exposed: should still verify job_id is used correctly
- Multiple WebSocket completions: each should have distinct correlation identifiers

### Test Fixtures

**Fixture**: `mock_websocket_result(job_id: str = "job-123", correlation_id: Optional[str] = None) -> Dict[str, Any]`
- Parameters: job_id (optional, default "job-123"), correlation_id (optional)
- Returns: Dictionary representing WebSocket completion result
- Structure: Final business payload with optional correlation identifier
- Purpose: Reusable mock data for WebSocket completion results

**Fixture**: `mock_adapter_transport_websocket() -> AsyncMock`
- Returns: Mocked AdapterTransport that supports WebSocket waiting
- Purpose: Mock transport layer for WebSocket completion tests
- Behavior: `wait_for_job_via_websocket()` returns final result after simulated delay

### Constants and Literals

- Test texts: `["test text"]`, `["test text 1", "test text 2"]`
- Test model: `"test-model"`
- Test dimension: `768`
- Test device: `"cpu"`
- Test job_id: `"job-123"` (example value)
- Test correlation_id: `"ws-delivery-1"` (example value, if exposed)
- Expected result keys: `"results"`, `"embeddings"`, `"model"`, `"dimension"`, `"device"`
- Timeout values: `60.0` (default), `1.0` (short timeout for timeout test), `None` (no timeout), `0` (indefinite)

## Expected Deliverables

1. File `tests/test_websocket_completion.py` created
2. File contains class `TestWebSocketCompletion` with 4 test methods
3. All test methods are async and use pytest-asyncio
4. All test methods validate WebSocket completion behavior
5. File follows project code style (black, flake8, mypy compliant)
6. File contains proper docstrings and type annotations

## Mandatory Validation

After implementation, run these exact commands:

1. **Format check**:
   ```bash
   black tests/test_websocket_completion.py
   ```
   Expected: "reformatted" or "already well formatted" (exit 0)

2. **Lint check**:
   ```bash
   flake8 tests/test_websocket_completion.py
   ```
   Expected: no output (exit 0)

3. **Type check**:
   ```bash
   mypy tests/test_websocket_completion.py
   ```
   Expected: "Success: no issues found" (exit 0)

4. **Test execution**:
   ```bash
   pytest tests/test_websocket_completion.py -v
   ```
   Expected: all tests PASSED (may require mocks/fixtures to be set up correctly)

**All validation commands must pass before considering this step complete.**

## Decision Rules

1. **Test framework**: Use pytest (not unittest) based on conftest.py patterns
2. **Async tests**: Use `@pytest.mark.asyncio` decorator for async test methods
3. **Mocking strategy**: Mock AdapterTransport, not internal adapter client
4. **Result structure**: Accept both "results" and "embeddings" formats (server may return either)
5. **Identifier validation**: Verify job_id (JobId) is distinct from WebSocket correlation identifier (DeliverId)
6. **Timeout handling**: Test timeout=None (indefinite), timeout=0 (indefinite), timeout>0 (limited)
7. **WebSocket behavior**: Test adapter-managed WebSocket flow, not raw WebSocket protocol

## Blackstops

Stop and escalate if:
- Core client implementation needs changes to support WebSocket completion (affects Step 3)
- WebSocket waiting logic requires changes to async_client_queue_mixin (affects Step 3)
- Identifier separation logic requires changes to identifier handling (affects Step 3)
- Adapter WebSocket contract contradicts expected behavior (affects Step 1)

## Handoff Package

**For coder_auto**:
- Target file: `tests/test_websocket_completion.py`
- Action: create
- Test class: `TestWebSocketCompletion`
- Test methods: 4 methods (test_websocket_waiting, test_websocket_result_delivery, test_websocket_timeout, test_websocket_identifier_separation)
- Required imports: pytest, pytest_asyncio, asyncio, typing, unittest.mock, embed_client modules, identifier_types
- Validation commands: black, flake8, mypy, pytest
- Expected outcome: All tests pass, file follows project standards
