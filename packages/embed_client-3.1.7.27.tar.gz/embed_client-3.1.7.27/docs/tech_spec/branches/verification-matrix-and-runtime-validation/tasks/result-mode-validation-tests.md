Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Result Mode Validation Tests

## Purpose

Create comprehensive test coverage to validate that the synchronized client correctly handles both immediate JSON-RPC result mode and queued result mode (with JSON-RPC status polling and/or adapter-managed WebSocket completion). Ensure tests verify proper result normalization, identifier separation, and mode detection.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`

## Scope

### Included

- Create or modify test files:
  - `tests/test_embed_immediate_mode.py` - immediate JSON-RPC result mode
  - `tests/test_embed_queued_mode.py` - queued result with status polling
  - `tests/test_websocket_completion.py` - adapter-managed WebSocket completion
- Test immediate result detection and normalization
- Test queued result submission, job_id extraction, and status polling
- Test WebSocket completion waiting and result delivery
- Validate proper identifier separation (no mixing of JSON-RPC id, job_id, WebSocket correlation)
- Verify result normalization matches server contract

### Excluded

- Security matrix validation (covered in separate tactical task)
- Identifier separation unit tests (covered in separate tactical task)
- Real-server runtime validation on localhost:8001 (covered in separate tactical task)

## Boundaries

This task must NOT touch:
- Core client implementation files (already updated in Steps 1-3)
- Adapter transport layer (already updated in Step 1)
- Real-server scripts (covered in separate tactical task)

## Dependencies

- Step 1: adapter-centric-client-foundation (must complete first)
- Step 2: embed-command-and-result-contract-alignment (must complete first)
- Step 3: queue-and-websocket-identifier-separation (must complete first)

This tactical task depends on all prior steps because it validates result handling from the integrated synchronized client.

## Parallelization Note

This tactical task can run in parallel with:
- `security-matrix-validation-tests.md`
- `identifier-separation-validation-tests.md`
- `update-maintained-real-server-scripts.md`

## Expected Outcome

1. Test files exist:
   - `tests/test_embed_immediate_mode.py`
   - `tests/test_embed_queued_mode.py`
   - `tests/test_websocket_completion.py`
2. Immediate mode tests validate:
   - Immediate result detection (no job_id in response)
   - Result normalization (embeddings, results, model, dimension, device fields)
   - No job_id is invented or exposed
3. Queued mode tests validate:
   - Queued result detection (job_id in response)
   - job_id extraction and storage
   - Status polling via `job_status()` and `wait_for_job()`
   - Result normalization after completion
   - No mixing of JSON-RPC request id with job_id
4. WebSocket completion tests validate:
   - WebSocket waiting via `wait_for_job_via_websocket()`
   - Result delivery through adapter-managed WebSocket flow
   - Proper identifier handling (job_id vs WebSocket correlation id)
   - Timeout handling
5. All tests pass and produce clear failure messages

## Correction Items

None (these are new test file creation tasks).

## Questions/Escalation Rule

Escalate to global orchestrator if:
- Result mode detection logic requires changes to core client (affects Step 2)
- WebSocket completion behavior contradicts adapter contract (affects Step 1 or 3)
- Result normalization contradicts server contract (affects Step 2)

## File Inventory

### Files to Create or Modify

1. **Action**: create or modify
   **Path**: `tests/test_embed_immediate_mode.py`
   **Purpose**: Test immediate JSON-RPC result mode

2. **Action**: create or modify
   **Path**: `tests/test_embed_queued_mode.py`
   **Purpose**: Test queued result mode with status polling

3. **Action**: create or modify
   **Path**: `tests/test_websocket_completion.py`
   **Purpose**: Test adapter-managed WebSocket completion

### Files to Read (Reference Only)

1. **Path**: `embed_client/async_client.py`
   **Purpose**: Reference for client methods and result structures

2. **Path**: `embed_client/async_client_api_mixin.py`
   **Purpose**: Reference for embed() method and result normalization

3. **Path**: `embed_client/async_client_queue_mixin.py`
   **Purpose**: Reference for queue methods and waiting behavior

4. **Path**: `embed_client/adapter_transport.py`
   **Purpose**: Reference for adapter response formats

5. **Path**: `docs/tech_spec/tech_spec.md`
   **Purpose**: Reference for result mode contracts and identifier model

## Class/Function Inventory

### Test File Structures

1. **File**: `tests/test_embed_immediate_mode.py`
   **Class name**: `TestEmbedImmediateMode`
   **Base class**: `unittest.TestCase` or pytest class
   **Purpose**: Test immediate JSON-RPC result mode
   **Public methods**:
   - `test_immediate_result_detection() -> None`: Verify immediate result is detected correctly
   - `test_immediate_result_normalization() -> None`: Verify result normalization
   - `test_immediate_result_structure() -> None`: Verify result structure matches contract
   - `test_immediate_no_job_id() -> None`: Verify no job_id is present or invented

2. **File**: `tests/test_embed_queued_mode.py`
   **Class name**: `TestEmbedQueuedMode`
   **Base class**: `unittest.TestCase` or pytest class
   **Purpose**: Test queued result mode with status polling
   **Public methods**:
   - `test_queued_result_detection() -> None`: Verify queued result is detected (job_id present)
   - `test_job_id_extraction() -> None`: Verify job_id is extracted correctly
   - `test_job_status_polling() -> None`: Verify status polling via job_status()
   - `test_wait_for_job() -> None`: Verify wait_for_job() completes successfully
   - `test_queued_result_normalization() -> None`: Verify result normalization after completion
   - `test_identifier_separation() -> None`: Verify JSON-RPC id is not used as job_id

3. **File**: `tests/test_websocket_completion.py`
   **Class name**: `TestWebSocketCompletion`
   **Base class**: `unittest.TestCase` or pytest class
   **Purpose**: Test adapter-managed WebSocket completion
   **Public methods**:
   - `test_websocket_waiting() -> None`: Verify wait_for_job_via_websocket() works
   - `test_websocket_result_delivery() -> None`: Verify result delivery through WebSocket
   - `test_websocket_timeout() -> None`: Verify timeout handling
   - `test_websocket_identifier_separation() -> None`: Verify job_id vs WebSocket correlation id separation

## Data Structures

### Test Result Patterns

1. **Immediate Result Structure**:
   - `{"results": [...], "embeddings": [...], "model": "...", "dimension": 768, "device": "cpu"}`
   - No `job_id` field
   - Final business payload directly in result

2. **Queued Submission Result Structure**:
   - `{"job_id": "job-123", "status": "pending", "message": "accepted"}`
   - Contains `job_id` for follow-up status/waiting

3. **Job Status Result Structure**:
   - `{"exists": True, "status": "completed", "done": True, "result": {...}}`
   - Contains final result in `result` field when completed

4. **WebSocket Completion Result Structure**:
   - Final business payload (same as immediate result structure)
   - May contain adapter-managed correlation identifier (separate from job_id)

## Import Map

### For Each Test File

1. **tests/test_embed_immediate_mode.py**:
   - `import pytest` or `import unittest`
   - `import asyncio`
   - `from embed_client.async_client import EmbeddingServiceAsyncClient`
   - `from embed_client.config import ClientConfig` (if needed)
   - `from embed_client.exceptions import EmbeddingServiceError`

2. **tests/test_embed_queued_mode.py**:
   - `import pytest` or `import unittest`
   - `import asyncio`
   - `from embed_client.async_client import EmbeddingServiceAsyncClient`
   - `from embed_client.config import ClientConfig` (if needed)
   - `from embed_client.exceptions import EmbeddingServiceError, EmbeddingServiceTimeoutError`

3. **tests/test_websocket_completion.py**:
   - `import pytest` or `import unittest`
   - `import asyncio`
   - `from embed_client.async_client import EmbeddingServiceAsyncClient`
   - `from embed_client.config import ClientConfig` (if needed)
   - `from embed_client.exceptions import EmbeddingServiceError, EmbeddingServiceTimeoutError`

## Error Handling Map

### For Test Execution

1. **Immediate Mode Detection Failure**:
   - **Condition**: Client incorrectly treats immediate result as queued (or vice versa)
   - **Action**: Test should assert correct mode detection

2. **Job ID Extraction Failure**:
   - **Condition**: job_id not extracted correctly from queued result
   - **Action**: Test should assert job_id is present and correctly extracted

3. **Status Polling Failure**:
   - **Exception**: `EmbeddingServiceAPIError` or `EmbeddingServiceError`
   - **Condition**: job_status() or wait_for_job() fails
   - **Action**: Test should assert appropriate error or verify error handling

4. **WebSocket Waiting Timeout**:
   - **Exception**: `EmbeddingServiceTimeoutError`
   - **Condition**: wait_for_job_via_websocket() exceeds timeout
   - **Action**: Test should assert timeout exception is raised

5. **Identifier Mixing**:
   - **Condition**: JSON-RPC request id used as job_id or WebSocket correlation id
   - **Action**: Test should assert identifiers are kept separate

## Config Dependency

### Tests Use These Config Keys

1. **Server Endpoint**:
   - **Key**: `server.host`, `server.port`
   - **Type**: `str`, `int`
   - **Access**: Via test config construction

2. **Protocol**:
   - **Key**: `protocol` or `server.protocol`
   - **Type**: `str`
   - **Access**: Via test config construction

3. **Client Timeout**:
   - **Key**: `client.timeout`
   - **Type**: `float`
   - **Access**: Via test config or method parameter

## Test Plan

### For Each Test File

1. **tests/test_embed_immediate_mode.py**:
   - Test immediate result detection (no job_id)
   - Test result normalization (embeddings, results, model, dimension, device)
   - Test result structure matches server contract
   - Test no job_id is invented or exposed

2. **tests/test_embed_queued_mode.py**:
   - Test queued result detection (job_id present)
   - Test job_id extraction
   - Test status polling via job_status()
   - Test wait_for_job() completion
   - Test result normalization after completion
   - Test identifier separation (no JSON-RPC id mixing)

3. **tests/test_websocket_completion.py**:
   - Test WebSocket waiting via wait_for_job_via_websocket()
   - Test result delivery through WebSocket
   - Test timeout handling
   - Test identifier separation (job_id vs WebSocket correlation id)

## Concrete Examples

### Example: Immediate Mode Test

```python
async def test_immediate_result_detection():
    async with EmbeddingServiceAsyncClient.from_config(config) as client:
        result = await client.embed(["test text"], wait=True)
        # Immediate mode: no job_id
        assert "job_id" not in result
        # Immediate mode: final result present
        assert "results" in result or "embeddings" in result
```

### Example: Queued Mode Test

```python
async def test_queued_result_with_polling():
    async with EmbeddingServiceAsyncClient.from_config(config) as client:
        # Submit job (queued mode)
        result = await client.embed(["test text"], wait=False)
        # Queued mode: job_id present
        assert "job_id" in result
        job_id = result["job_id"]
        # Poll for status
        status = await client.job_status(job_id)
        assert status.get("status") in ["pending", "running", "completed"]
        # Wait for completion
        final_result = await client.wait_for_job(job_id, timeout=60.0)
        assert "results" in final_result or "embeddings" in final_result
```

### Example: WebSocket Completion Test

```python
async def test_websocket_completion():
    async with EmbeddingServiceAsyncClient.from_config(config) as client:
        # Submit job
        result = await client.embed(["test text"], wait=False)
        job_id = result["job_id"]
        # Wait via WebSocket
        final_result = await client.wait_for_job_via_websocket(job_id, timeout=60.0)
        assert "results" in final_result or "embeddings" in final_result
```

## Algorithm Descriptions

### Immediate Mode Test Algorithm

1. **Construct Client**: Use adapter-backed client construction
2. **Execute Embed**: Call `embed()` with `wait=True` or default
3. **Detect Mode**: Verify result does not contain `job_id`
4. **Validate Result**: Verify result contains final business payload (embeddings, results, model, dimension, device)
5. **Verify Normalization**: Verify result structure matches server contract

### Queued Mode Test Algorithm

1. **Construct Client**: Use adapter-backed client construction
2. **Submit Job**: Call `embed()` with `wait=False` or `submit_job()`
3. **Detect Mode**: Verify result contains `job_id`
4. **Extract job_id**: Extract `job_id` from result (not JSON-RPC request id)
5. **Poll Status**: Call `job_status(job_id)` and verify status progression
6. **Wait for Completion**: Call `wait_for_job(job_id)` and verify completion
7. **Validate Result**: Verify final result contains business payload
8. **Verify Identifier Separation**: Verify JSON-RPC request id was not used as job_id

### WebSocket Completion Test Algorithm

1. **Construct Client**: Use adapter-backed client construction
2. **Submit Job**: Call `embed()` with `wait=False` or `submit_job()`
3. **Extract job_id**: Extract `job_id` from result
4. **Wait via WebSocket**: Call `wait_for_job_via_websocket(job_id, timeout=...)`
5. **Validate Result**: Verify result delivered through WebSocket contains business payload
6. **Verify Identifier Separation**: Verify job_id vs WebSocket correlation id are kept separate
7. **Test Timeout**: Verify timeout exception is raised when timeout exceeded

## Forbidden Approaches

- Do not assume all results are immediate (must handle queued mode)
- Do not assume all results are queued (must handle immediate mode)
- Do not use JSON-RPC request id as job_id
- Do not mix job_id with WebSocket correlation identifier
- Do not invent job_id for immediate results
- Do not skip result normalization validation
