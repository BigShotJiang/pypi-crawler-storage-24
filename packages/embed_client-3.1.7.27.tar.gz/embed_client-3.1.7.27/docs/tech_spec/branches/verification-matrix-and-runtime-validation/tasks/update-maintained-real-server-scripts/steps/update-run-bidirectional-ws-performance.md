# Atomic Step: Update run_bidirectional_ws_performance.py

## Executor Role
`coder_auto` — implement the code changes described in this step.

## Execution Directive
Update `scripts/run_bidirectional_ws_performance.py` to ensure it fully complies with the synchronized client architecture from Steps 1-3. Verify and fix identifier handling, result mode handling, and adapter-backed client construction patterns.

## Parent Links
- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

## Step Scope
**Target file**: `scripts/run_bidirectional_ws_performance.py`
**Action**: modify

## Dependency Contract
- Depends on: Steps 1-3 (adapter-centric-client-foundation, embed-command-and-result-contract-alignment, queue-and-websocket-identifier-separation)
- No dependencies on other atomic steps in this tactical task
- Can execute in parallel with other script update steps

## Required Context
The script `run_bidirectional_ws_performance.py` tests bidirectional WebSocket performance on localhost:8001 with mTLS. It must:
1. Use adapter-backed client construction via `EmbeddingServiceAsyncClient.from_config(config)`
2. Correctly extract `job_id` from `submit_job` results (not JSON-RPC request `id`)
3. Handle both immediate and queued result modes correctly
4. Use `job_id` for `wait_for_job_via_websocket` calls (not JSON-RPC request id)
5. Use context manager (`async with`) for proper resource cleanup

## Read First
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` — identifier model and result mode contracts
2. `/home/vasilyvz/projects/embed-client/scripts/run_bidirectional_ws_performance.py` — current script implementation
3. `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` — client construction and method signatures
4. `/home/vasilyvz/projects/embed-client/embed_client/config.py` — ClientConfig.create_mtls_config signature

## Expected File Change
The file `scripts/run_bidirectional_ws_performance.py` will be modified to:
1. Ensure `job_id` extraction uses `result.get("job_id")` (safe extraction, not `result["job_id"]`)
2. Verify immediate mode handling is correct (when `job_id` is None, validate embeddings from submit result)
3. Ensure all `wait_for_job_via_websocket` calls use extracted `job_id` (not JSON-RPC request id)
4. Verify context manager usage is correct (`async with EmbeddingServiceAsyncClient.from_config(config)`)
5. Ensure certificate paths are resolved correctly relative to PROJECT_ROOT

## Forbidden Alternatives
- Do NOT use JSON-RPC request `id` as job identifier
- Do NOT assume all results are queued (must handle immediate mode)
- Do NOT use direct client instantiation (must use `from_config`)
- Do NOT bypass context manager (must use `async with`)
- Do NOT pass JSON-RPC request id to `wait_for_job_via_websocket` (must use `job_id`)

## Atomic Operations

### Operation 1: Verify Identifier Handling in `_submit_embed_queue_job` and `_submit_embed_queue_batch`

**Location**: Functions `_submit_embed_queue_job` (line 98-108) and `_submit_embed_queue_batch` (line 110-119)

**Current pattern** (should already be correct):
```python
result = await client.submit_job(...)
return result.get("job_id"), result
```

**Verification**:
1. Ensure `job_id` extraction uses `result.get("job_id")` (safe `.get()` method, not `result["job_id"]`)
2. Ensure function returns tuple `(job_id, result)` where `job_id` may be None
3. Ensure no use of `result.get("id")` or `result["id"]` (JSON-RPC request id)

**If incorrect**, fix to use `result.get("job_id")` pattern.

### Operation 2: Verify Immediate Mode Handling in `run_batch_ws`

**Location**: Function `run_batch_ws`, around line 122-140

**Current pattern** (should already be correct):
```python
job_id, submit_result = await _submit_embed_queue_batch(client, texts)
if not job_id:
    validate_embeddings(submit_result, len(texts), ...)
    return (time.perf_counter() - t0, False)
result = await client.wait_for_job_via_websocket(job_id, timeout=timeout)
```

**Verification**:
1. Ensure immediate mode is handled: if `job_id` is None, validate embeddings from `submit_result` and return early
2. Ensure `wait_for_job_via_websocket` is only called when `job_id` is not None
3. Ensure `job_id` passed to `wait_for_job_via_websocket` is the extracted `job_id`, not JSON-RPC request id

**If incorrect**, fix to handle immediate mode correctly.

### Operation 3: Verify Immediate Mode Handling in `run_single_ws`

**Location**: Function `run_single_ws`, around line 143-164

**Current pattern** (should already be correct):
```python
job_id, submit_result = await _submit_embed_queue_job(client, text)
if job_id:
    any_queued = True
    result = await client.wait_for_job_via_websocket(job_id, timeout=timeout)
    validate_embeddings(result, 1, ...)
else:
    validate_embeddings(submit_result, 1, ...)
```

**Verification**:
1. Ensure immediate mode is handled: if `job_id` is None, validate embeddings from `submit_result`
2. Ensure `wait_for_job_via_websocket` is only called when `job_id` is not None
3. Ensure `job_id` passed to `wait_for_job_via_websocket` is the extracted `job_id`, not JSON-RPC request id

**If incorrect**, fix to handle immediate mode correctly.

### Operation 4: Verify Immediate Mode Handling in `run_ws_push_timings`

**Location**: Function `run_ws_push_timings`, around line 167-188

**Current pattern** (should already be correct):
```python
job_id, submit_result = await _submit_embed_queue_job(client, text)
if not job_id:
    validate_embeddings(submit_result, 1, ...)
    continue
result = await client.wait_for_job_via_websocket(job_id, timeout=timeout)
```

**Verification**:
1. Ensure immediate mode is handled: if `job_id` is None, validate embeddings and continue (skip timing)
2. Ensure `wait_for_job_via_websocket` is only called when `job_id` is not None
3. Ensure `job_id` passed to `wait_for_job_via_websocket` is the extracted `job_id`, not JSON-RPC request id

**If incorrect**, fix to handle immediate mode correctly.

### Operation 5: Verify Immediate Mode Handling in `run_bidirectional_channel_timings`

**Location**: Function `run_bidirectional_channel_timings`, around line 191-234

**Current pattern** (should already be correct):
```python
job_id, submit_result = await _submit_embed_queue_job(client, text)
if not job_id:
    validate_embeddings(submit_result, 1, ...)
    continue
# ... channel subscription logic using job_id
```

**Verification**:
1. Ensure immediate mode is handled: if `job_id` is None, validate embeddings and continue (skip timing)
2. Ensure channel subscription uses extracted `job_id`, not JSON-RPC request id
3. Ensure `job_id` in subscription message is the extracted `job_id`

**If incorrect**, fix to handle immediate mode correctly.

### Operation 6: Verify Context Manager Usage

**Location**: Function `main_async`, around line 292

**Current pattern** (should already be correct):
```python
async with EmbeddingServiceAsyncClient.from_config(config) as client:
    # ... test code
```

**Verification**:
1. Ensure the `async with` statement is used (not manual `__aenter__`/`__aexit__`)
2. Ensure all client operations are inside the `async with` block
3. No manual `await client.close()` calls needed (context manager handles it)

**If incorrect**, fix to use `async with` pattern.

### Operation 7: Verify Certificate Path Resolution

**Location**: Function `_make_mtls_config_8001`, around line 85-95

**Current pattern** (should already be correct):
```python
cert_dir = PROJECT_ROOT / "mtls_certificates" / "client"
ca_dir = PROJECT_ROOT / "mtls_certificates" / "ca"
return ClientConfig.create_mtls_config(
    host="localhost",
    port=8001,
    cert_file=str(cert_dir / "embedding-service.crt"),
    key_file=str(cert_dir / "embedding-service.key"),
    ca_cert_file=str(ca_dir / "ca.crt"),
)
```

**Verification**:
1. Ensure certificate paths are resolved relative to `PROJECT_ROOT`
2. Ensure paths are converted to strings using `str()` before passing to `create_mtls_config`
3. Ensure all three certificate files (cert, key, ca) are specified

**If incorrect**, fix to resolve paths correctly.

## Expected Deliverables
1. Updated `scripts/run_bidirectional_ws_performance.py` with:
   - Correct identifier handling (job_id extraction, not JSON-RPC id)
   - Immediate mode handling in all functions that submit jobs
   - Proper use of `job_id` for WebSocket waiting operations
   - Proper context manager usage
   - Correct certificate path resolution

## Mandatory Validation

### Validation Commands
1. **Syntax check**:
   ```bash
   python -m py_compile scripts/run_bidirectional_ws_performance.py
   ```
   Expected: No output (exit code 0)

2. **Type check** (if mypy is configured):
   ```bash
   mypy scripts/run_bidirectional_ws_performance.py --ignore-missing-imports
   ```
   Expected: "Success: no issues found" or acceptable type warnings

3. **Lint check**:
   ```bash
   flake8 scripts/run_bidirectional_ws_performance.py --max-line-length=120 --ignore=E501,W503
   ```
   Expected: No output (exit code 0) or only acceptable warnings

4. **Black format check**:
   ```bash
   black --check scripts/run_bidirectional_ws_performance.py
   ```
   Expected: "would reformat" or "already well formatted"

5. **Manual verification** (if server available):
   ```bash
   python scripts/run_bidirectional_ws_performance.py --help
   ```
   Expected: Help message displayed, exit code 0

### Test Expectations
- Script should execute without syntax errors
- Script should handle both immediate and queued result modes
- Script should correctly extract `job_id` from queued results
- Script should not use JSON-RPC request `id` as job identifier
- Script should use `job_id` for all WebSocket waiting operations
- Script should use context manager for client lifecycle

## Decision Rules
1. **Identifier extraction**: Always use `result.get("job_id")` (safe extraction), never `result["job_id"]` or `result.get("id")`
2. **Immediate mode detection**: If `job_id` is None, validate embeddings from submit result and skip waiting
3. **WebSocket waiting**: Always use extracted `job_id` for `wait_for_job_via_websocket` calls, never JSON-RPC request id
4. **Context manager**: Always use `async with EmbeddingServiceAsyncClient.from_config(config) as client:`
5. **Certificate paths**: Always resolve relative paths using `PROJECT_ROOT` before passing to config

## Blackstops
Stop and escalate if:
- Script requires changes to core client architecture (affects Steps 1-3)
- Script reveals bugs in synchronized client that require global fixes
- Script execution reveals contradictions between adapter behavior and expected server contract

## Handoff Package
- Updated `scripts/run_bidirectional_ws_performance.py` file
- All validation commands pass
- Script ready for execution on `localhost:8001` with mTLS certificates
