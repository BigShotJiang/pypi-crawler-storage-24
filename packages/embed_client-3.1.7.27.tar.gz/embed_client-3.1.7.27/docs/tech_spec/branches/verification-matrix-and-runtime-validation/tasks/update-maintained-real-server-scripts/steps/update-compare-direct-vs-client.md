# Atomic Step: Update compare_direct_vs_client.py

## Executor Role
`coder_auto` — implement the code changes described in this step.

## Execution Directive
Update `scripts/compare_direct_vs_client.py` to ensure it fully complies with the synchronized client architecture from Steps 1-3. Verify adapter-backed client construction and certificate path resolution patterns.

## Parent Links
- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

## Step Scope
**Target file**: `scripts/compare_direct_vs_client.py`
**Action**: modify

## Dependency Contract
- Depends on: Steps 1-3 (adapter-centric-client-foundation, embed-command-and-result-contract-alignment, queue-and-websocket-identifier-separation)
- No dependencies on other atomic steps in this tactical task
- Can execute in parallel with other script update steps

## Required Context
The script `compare_direct_vs_client.py` compares timing between direct HTTP script and embed_client. It must:
1. Use adapter-backed client construction via `EmbeddingServiceAsyncClient.from_config(config)`
2. Use context manager (`async with`) for proper resource cleanup
3. Resolve certificate paths correctly relative to PROJECT_ROOT

## Read First
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` — client construction patterns
2. `/home/vasilyvz/projects/embed-client/scripts/compare_direct_vs_client.py` — current script implementation
3. `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` — client construction and method signatures
4. `/home/vasilyvz/projects/embed-client/embed_client/config.py` — ClientConfig.create_mtls_config signature

## Expected File Change
The file `scripts/compare_direct_vs_client.py` will be modified to:
1. Verify context manager usage is correct (`async with EmbeddingServiceAsyncClient.from_config(config)`)
2. Ensure certificate path resolution works correctly for both config file and programmatic config creation
3. Verify `_resolve_cert_paths` helper is called when loading config from file

## Forbidden Alternatives
- Do NOT use direct client instantiation (must use `from_config`)
- Do NOT bypass context manager (must use `async with`)
- Do NOT hardcode certificate paths without PROJECT_ROOT resolution

## Atomic Operations

### Operation 1: Verify Context Manager Usage

**Location**: Function `run_client_timing`, around line 104

**Current pattern** (should already be correct):
```python
async with EmbeddingServiceAsyncClient.from_config(config) as client:
    # ... test code
```

**Verification**:
1. Ensure the `async with` statement is used (not manual `__aenter__`/`__aexit__`)
2. Ensure all client operations are inside the `async with` block
3. No manual `await client.close()` calls needed (context manager handles it)

**If incorrect**, fix to use `async with` pattern.

### Operation 2: Verify Certificate Path Resolution in Config File Loading

**Location**: Function `run_client_timing`, around line 86-97

**Current pattern** (should already be correct):
```python
if path and path.exists() and path.is_file():
    config = ClientConfig(str(path))
    config.load_config()
    _resolve_cert_paths(config.config_data)
else:
    config = _make_mtls_config_8001()
```

**Verification**:
1. Ensure `_resolve_cert_paths` is called after `config.load_config()` when loading from file
2. Ensure `_resolve_cert_paths` receives `config.config_data` (the dict, not the ClientConfig object)
3. Ensure programmatic config creation (`_make_mtls_config_8001`) resolves paths correctly

**If `_resolve_cert_paths` is not called**, add the call after `config.load_config()`.

### Operation 3: Verify Certificate Path Resolution in `_make_mtls_config_8001`

**Location**: Function `_make_mtls_config_8001`, around line 70-83

**Current pattern** (should already be correct):
```python
cert_dir = PROJECT_ROOT / "mtls_certificates" / "client"
ca_dir = PROJECT_ROOT / "mtls_certificates" / "ca"
config = ClientConfig.create_mtls_config(
    host="localhost",
    port=8001,
    cert_file=str(cert_dir / "embedding-service.crt"),
    key_file=str(cert_dir / "embedding-service.key"),
    ca_cert_file=str(ca_dir / "ca.crt"),
)
```

**Verification**:
1. Ensure certificate paths are resolved relative to `PROJECT_ROOT`
2. Ensure paths are converted to strings using `str()` before passing to `create_mtls_config`
3. Ensure all three certificate files (cert, key, ca) are specified

**If incorrect**, fix to resolve paths correctly.

### Operation 4: Verify `_resolve_cert_paths` Helper Function

**Location**: Function `_resolve_cert_paths`, around line 46-67

**Current pattern** (should already exist):
```python
def _resolve_cert_paths(config_data: dict) -> None:
    """Resolve relative cert paths under PROJECT_ROOT (in-place)."""
    # ... existing logic
```

**Verification**:
1. Ensure function modifies `config_data` in-place
2. Ensure both `auth.certificate.*` and `ssl.*` paths are resolved
3. Ensure paths are only resolved if they are relative (not starting with "/")
4. Ensure resolved paths are converted to strings

**If function is missing or incorrect**, implement or fix it:
```python
def _resolve_cert_paths(config_data: dict) -> None:
    """Resolve relative cert paths under PROJECT_ROOT (in-place)."""
    for section in ("auth", "ssl"):
        sect = config_data.get(section, {})
        if not isinstance(sect, dict):
            continue
        cert_sect = sect.get("certificate", sect) if section == "auth" else sect
        if not isinstance(cert_sect, dict):
            continue
        for key in ("cert_file", "key_file", "ca_cert_file"):
            val = cert_sect.get(key)
            if isinstance(val, str) and not val.startswith("/"):
                resolved = PROJECT_ROOT / val
                if resolved.exists():
                    cert_sect[key] = str(resolved)
        if section == "ssl" and isinstance(sect, dict):
            for key in ("cert_file", "key_file", "ca_cert_file"):
                val = sect.get(key)
                if isinstance(val, str) and not val.startswith("/"):
                    resolved = PROJECT_ROOT / val
                    if resolved.exists():
                        sect[key] = str(resolved)
```

## Expected Deliverables
1. Updated `scripts/compare_direct_vs_client.py` with:
   - Proper context manager usage
   - Correct certificate path resolution for both config file and programmatic config
   - Proper error handling for config loading

## Mandatory Validation

### Validation Commands
1. **Syntax check**:
   ```bash
   python -m py_compile scripts/compare_direct_vs_client.py
   ```
   Expected: No output (exit code 0)

2. **Type check** (if mypy is configured):
   ```bash
   mypy scripts/compare_direct_vs_client.py --ignore-missing-imports
   ```
   Expected: "Success: no issues found" or acceptable type warnings

3. **Lint check**:
   ```bash
   flake8 scripts/compare_direct_vs_client.py --max-line-length=120 --ignore=E501,W503
   ```
   Expected: No output (exit code 0) or only acceptable warnings

4. **Black format check**:
   ```bash
   black --check scripts/compare_direct_vs_client.py
   ```
   Expected: "would reformat" or "already well formatted"

5. **Manual verification** (if server available):
   ```bash
   python scripts/compare_direct_vs_client.py --help
   ```
   Expected: Help message displayed, exit code 0

### Test Expectations
- Script should execute without syntax errors
- Script should use context manager for client lifecycle
- Script should resolve certificate paths correctly
- Script should handle both config file and programmatic config creation

## Decision Rules
1. **Context manager**: Always use `async with EmbeddingServiceAsyncClient.from_config(config) as client:`
2. **Certificate paths**: Always resolve relative paths using `PROJECT_ROOT` before passing to config
3. **Config loading**: Always call `_resolve_cert_paths` after `config.load_config()` when loading from file
4. **Error handling**: Always handle `FileNotFoundError` for missing config files

## Blackstops
Stop and escalate if:
- Script requires changes to core client architecture (affects Steps 1-3)
- Script reveals bugs in synchronized client that require global fixes
- Script execution reveals contradictions between adapter behavior and expected server contract

## Handoff Package
- Updated `scripts/compare_direct_vs_client.py` file
- All validation commands pass
- Script ready for execution on `localhost:8001` with mTLS certificates
