# Atomic Step: Update run_real_server_mtls_test.py

## Executor Role
`coder_auto` — implement the code changes described in this step.

## Execution Directive
Update `scripts/run_real_server_mtls_test.py` to ensure it fully complies with the synchronized client architecture from Steps 1-3. Verify and fix identifier handling, result mode handling, and adapter-backed client construction patterns.

## Parent Links
- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

## Step Scope
**Target file**: `scripts/run_real_server_mtls_test.py`
**Action**: modify

## Dependency Contract
- Depends on: Steps 1-3 (adapter-centric-client-foundation, embed-command-and-result-contract-alignment, queue-and-websocket-identifier-separation)
- No dependencies on other atomic steps in this tactical task
- Can execute in parallel with other script update steps

## Required Context
The script `run_real_server_mtls_test.py` tests the client against a real embedding server with mTLS. It must:
1. Use adapter-backed client construction via `EmbeddingServiceAsyncClient.from_config(config)`
2. Correctly extract `job_id` from `submit_job` results (not JSON-RPC request `id`)
3. Handle both immediate and queued result modes correctly
4. Use context manager (`async with`) for proper resource cleanup
5. Resolve certificate paths relative to PROJECT_ROOT

## Read First
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` — identifier model and result mode contracts
2. `/home/vasilyvz/projects/embed-client/scripts/run_real_server_mtls_test.py` — current script implementation
3. `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` — client construction and method signatures
4. `/home/vasilyvz/projects/embed-client/embed_client/config.py` — ClientConfig.create_mtls_config signature

## Expected File Change
The file `scripts/run_real_server_mtls_test.py` will be modified to:
1. Ensure `job_id` extraction uses `result.get("job_id")` (safe extraction, not `result["job_id"]`)
2. Add explicit handling for immediate result mode (when `job_id` is None)
3. Verify context manager usage is correct (`async with EmbeddingServiceAsyncClient.from_config(config)`)
4. Ensure certificate path resolution works correctly for both config file and programmatic config creation
5. Add error handling for missing `job_id` in queued mode scenarios

## Forbidden Alternatives
- Do NOT use JSON-RPC request `id` as job identifier
- Do NOT assume all results are queued (must handle immediate mode)
- Do NOT use direct client instantiation (must use `from_config`)
- Do NOT bypass context manager (must use `async with`)
- Do NOT hardcode certificate paths without PROJECT_ROOT resolution

## Atomic Operations

### Operation 1: Verify and Fix Identifier Handling in `_run_tests` Function

**Location**: Function `_run_tests`, around line 132-156

**Current pattern** (if exists):
```python
result = await client.embed(..., wait=False)
job_id = result.get("job_id")
if not job_id:
    # Error handling
```

**Required pattern**:
```python
result = await client.embed(..., wait=False)
job_id = result.get("job_id")  # Safe extraction, not result["job_id"]
if not job_id:
    # Check if immediate result mode
    if result.get("mode") == "immediate" or "embeddings" in result or "results" in result:
        # Immediate mode: result is already complete
        results["embed_fire_and_check"] = {
            "ok": True,
            "mode": "immediate",
            "result": result,
        }
        print("embed(wait=False): OK (immediate mode, no job_id)")
    else:
        # Error: expected queued but no job_id
        results["embed_fire_and_check"] = {"ok": False, "error": "No job_id in queued mode"}
        print("embed(wait=False): FAIL (no job_id)")
else:
    # Queued mode: use job_id for status check
    status = await client.job_status(job_id)
    # ... rest of existing logic
```

**Algorithm**:
1. Find the `embed(wait=False)` call in `_run_tests` function
2. Verify `job_id` extraction uses `result.get("job_id")` (safe `.get()` method)
3. Add immediate mode check: if `job_id` is None, check if result contains `"embeddings"` or `"results"` or has `mode == "immediate"`
4. If immediate mode detected, set result status to OK with mode="immediate"
5. If queued mode (job_id exists), continue with existing `job_status` logic
6. If neither (no job_id and no immediate result), treat as error

### Operation 2: Verify Context Manager Usage

**Location**: Function `_run_tests`, around line 91

**Current pattern** (should already be correct):
```python
async with EmbeddingServiceAsyncClient.from_config(config) as client:
    # ... test code
```

**Verification**:
1. Ensure the `async with` statement is used (not manual `__aenter__`/`__aexit__`)
2. Ensure all client operations are inside the `async with` block
3. No manual `await client.close()` calls needed (context manager handles it)

**If incorrect**, fix to use `async with` pattern.

### Operation 3: Verify Certificate Path Resolution

**Location**: Function `_load_config`, around line 60-76

**Current pattern** (should already be correct):
```python
def _resolve_cert_paths(config_data: Dict[str, Any], root: Path) -> None:
    """Resolve relative cert paths under root (in-place)."""
    # ... existing logic
```

**Verification**:
1. Ensure `_resolve_cert_paths` is called after `config.load_config()`
2. Ensure paths are resolved relative to `PROJECT_ROOT`
3. Ensure both `auth.certificate.*` and `ssl.*` paths are resolved

**If missing or incorrect**, ensure certificate paths are resolved correctly.

### Operation 4: Add Error Handling for Config Loading

**Location**: Function `main`, around line 196-202

**Current pattern** (should already exist):
```python
try:
    config = _load_config(...)
except FileNotFoundError as e:
    print(e, file=sys.stderr)
    return 1
```

**Verification**:
1. Ensure `FileNotFoundError` is caught for missing config files
2. Ensure error message is printed to stderr
3. Ensure exit code is 1 on error

**If missing**, add proper error handling.

## Expected Deliverables
1. Updated `scripts/run_real_server_mtls_test.py` with:
   - Correct identifier handling (job_id extraction, not JSON-RPC id)
   - Immediate mode handling (when job_id is None but result is complete)
   - Proper context manager usage
   - Correct certificate path resolution
   - Proper error handling

## Mandatory Validation

### Validation Commands
1. **Syntax check**:
   ```bash
   python -m py_compile scripts/run_real_server_mtls_test.py
   ```
   Expected: No output (exit code 0)

2. **Type check** (if mypy is configured):
   ```bash
   mypy scripts/run_real_server_mtls_test.py --ignore-missing-imports
   ```
   Expected: "Success: no issues found" or acceptable type warnings

3. **Lint check**:
   ```bash
   flake8 scripts/run_real_server_mtls_test.py --max-line-length=120 --ignore=E501,W503
   ```
   Expected: No output (exit code 0) or only acceptable warnings

4. **Black format check**:
   ```bash
   black --check scripts/run_real_server_mtls_test.py
   ```
   Expected: "would reformat" or "already well formatted"

5. **Manual verification** (if server available):
   ```bash
   python scripts/run_real_server_mtls_test.py --help
   ```
   Expected: Help message displayed, exit code 0

### Test Expectations
- Script should execute without syntax errors
- Script should handle both immediate and queued result modes
- Script should correctly extract `job_id` from queued results
- Script should not use JSON-RPC request `id` as job identifier
- Script should use context manager for client lifecycle

## Decision Rules
1. **Identifier extraction**: Always use `result.get("job_id")` (safe extraction), never `result["job_id"]` or `result.get("id")`
2. **Immediate mode detection**: If `job_id` is None, check for `"embeddings"`, `"results"`, or `mode == "immediate"` in result
3. **Error handling**: If queued mode is expected but `job_id` is None and result is not immediate, treat as error
4. **Context manager**: Always use `async with EmbeddingServiceAsyncClient.from_config(config) as client:`
5. **Certificate paths**: Always resolve relative paths using `PROJECT_ROOT` before passing to config

## Blackstops
Stop and escalate if:
- Script requires changes to core client architecture (affects Steps 1-3)
- Script reveals bugs in synchronized client that require global fixes
- Script execution reveals contradictions between adapter behavior and expected server contract

## Handoff Package
- Updated `scripts/run_real_server_mtls_test.py` file
- All validation commands pass
- Script ready for execution on `localhost:8001` with mTLS certificates
