# Atomic Step: Update Timeout Default in compare_direct_vs_client.py

## Executor Role
`coder_auto` — implement the code changes described in this step.

## Execution Directive
Update timeout defaults in `scripts/compare_direct_vs_client.py` from 60.0 seconds to 300.0 seconds in both the function signature and argparse default to match server performance characteristics.

## Parent Links
- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

## Step Scope
**Target file**: `scripts/compare_direct_vs_client.py`
**Action**: modify

## Dependency Contract
- Depends on: Steps 1-3 (adapter-centric-client-foundation, embed-command-and-result-contract-alignment, queue-and-websocket-identifier-separation)
- No dependencies on other atomic steps in this tactical task
- Can execute in parallel with other timeout policy update steps

## Required Context
The script `compare_direct_vs_client.py` currently uses a default timeout of 60.0 seconds, which may be too conservative for current server performance. The timeout policy needs to be updated to 300.0 seconds to match server performance characteristics. This is a configuration/timeout policy change only — no client code logic changes.

## Read First
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` — timeout policy context
2. `/home/vasilyvz/projects/embed-client/scripts/compare_direct_vs_client.py` — current script implementation
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md` — tactical task context (lines 110-114)

## Expected File Change
The file `scripts/compare_direct_vs_client.py` will be modified to:
1. Change default timeout from 60.0 to 300.0 in `run_client_timing()` function signature (line 86)
2. Change default timeout from 60.0 to 300.0 in argparse default (line 131)
3. Preserve `--timeout` argument functionality (users can still override)

## Forbidden Alternatives
- Do NOT change client code logic (this is timeout policy only)
- Do NOT remove `--timeout` argument functionality
- Do NOT change timeout values in other locations (only function signature and argparse default)
- Do NOT modify timeout handling logic, only default values

## Atomic Operations

### Operation 1: Update Function Signature Default

**Location**: Function `run_client_timing`, line 86

**Current code**:
```python
async def run_client_timing(config_path: Path | None, timeout: float = 60.0) -> dict:
```

**Required change**:
```python
async def run_client_timing(config_path: Path | None, timeout: float = 300.0) -> dict:
```

**Algorithm**:
1. Locate the `run_client_timing` function definition starting at line 86
2. Find the `timeout: float = 60.0` parameter
3. Replace `60.0` with `300.0` in the function signature
4. Ensure the change is exact: `timeout: float = 300.0`

**Exact replacement**:
- **old_string**: `async def run_client_timing(config_path: Path | None, timeout: float = 60.0) -> dict:`
- **new_string**: `async def run_client_timing(config_path: Path | None, timeout: float = 300.0) -> dict:`

### Operation 2: Update Argparse Default

**Location**: Function `main`, line 131

**Current code**:
```python
    parser.add_argument("--timeout", type=float, default=60.0, help="Embed timeout (s)")
```

**Required change**:
```python
    parser.add_argument("--timeout", type=float, default=300.0, help="Embed timeout (s)")
```

**Algorithm**:
1. Locate the `parser.add_argument` call for `--timeout` on line 131
2. Find the `default=60.0` parameter
3. Replace `default=60.0` with `default=300.0`
4. Keep the help text unchanged (it doesn't specify the default value)

**Exact replacement**:
- **old_string**: `    parser.add_argument("--timeout", type=float, default=60.0, help="Embed timeout (s)")`
- **new_string**: `    parser.add_argument("--timeout", type=float, default=300.0, help="Embed timeout (s)")`

## Expected Deliverables
1. Updated `scripts/compare_direct_vs_client.py` with:
   - Timeout default changed from 60.0 to 300.0 in `run_client_timing()` function signature
   - Timeout default changed from 60.0 to 300.0 in argparse default
   - `--timeout` argument functionality preserved (users can still override)

## Mandatory Validation

### Validation Commands
1. **Syntax check**:
   ```bash
   python -m py_compile scripts/compare_direct_vs_client.py
   ```
   Expected: No output (exit code 0)

2. **Type check** (if mypy is configured):
   ```bash
   mypy scripts/compare_direct_vs_client.py --ignore-missing-imports
   ```
   Expected: "Success: no issues found" or acceptable type warnings

3. **Lint check**:
   ```bash
   flake8 scripts/compare_direct_vs_client.py --max-line-length=120 --ignore=E501,W503
   ```
   Expected: No output (exit code 0) or only acceptable warnings

4. **Black format check**:
   ```bash
   black --check scripts/compare_direct_vs_client.py
   ```
   Expected: "would reformat" or "already well formatted"

5. **Verify timeout defaults**:
   ```bash
   python scripts/compare_direct_vs_client.py --help | grep timeout
   ```
   Expected: Help text shows `--timeout` argument exists

6. **Verify function signature** (manual inspection):
   ```bash
   grep -n "timeout: float = " scripts/compare_direct_vs_client.py
   ```
   Expected: Line shows `timeout: float = 300.0`

### Test Expectations
- Script should execute without syntax errors
- Script should accept `--timeout` argument to override default
- Function signature should have `timeout: float = 300.0`
- Argparse should have `default=300.0`

## Decision Rules
1. **Function signature default**: Always match argparse default for consistency
2. **Argument preservation**: Always preserve `--timeout` argument functionality (users can override)
3. **No logic changes**: Only change default values, not timeout handling logic

## Edge Cases
- If `--timeout` is explicitly provided, it should override the default (existing behavior preserved)
- If timeout is passed programmatically to `run_client_timing()`, it should use the provided value (existing behavior preserved)
- If timeout is None, it should be handled by downstream code (existing behavior preserved)

## Constants and Literals
- **Old default timeout**: `60.0` (float, seconds)
- **New default timeout**: `300.0` (float, seconds)
- **Location 1**: Function parameter default in `run_client_timing()` signature (line 86)
- **Location 2**: Argparse `default` parameter (line 131)

## Blackstops
Stop and escalate if:
- Function signature or argparse structure has changed significantly from expected pattern
- Timeout handling logic needs modification (this step is timeout policy only)
- Changes conflict with other timeout-related modifications

## Handoff Package
- Updated `scripts/compare_direct_vs_client.py` file
- All validation commands pass
- Timeout defaults verified to be 300.0 in both locations
- Script ready for execution with new timeout defaults
