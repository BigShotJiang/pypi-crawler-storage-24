# Atomic Step: Update Timeout Default in run_batch_performance.py

## Executor Role
`coder_auto` — implement the code changes described in this step.

## Execution Directive
Update timeout default in `scripts/run_batch_performance.py` from 120.0 seconds to 300.0 seconds in argparse default to match server performance characteristics.

## Parent Links
- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

## Step Scope
**Target file**: `scripts/run_batch_performance.py`
**Action**: modify

## Dependency Contract
- Depends on: Steps 1-3 (adapter-centric-client-foundation, embed-command-and-result-contract-alignment, queue-and-websocket-identifier-separation)
- No dependencies on other atomic steps in this tactical task
- Can execute in parallel with other timeout policy update steps

## Required Context
The script `run_batch_performance.py` currently uses a default timeout of 120.0 seconds, which may be too conservative for current server performance. The timeout policy needs to be updated to 300.0 seconds to match server performance characteristics. This is a configuration/timeout policy change only — no client code logic changes.

## Read First
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` — timeout policy context
2. `/home/vasilyvz/projects/embed-client/scripts/run_batch_performance.py` — current script implementation
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md` — tactical task context (lines 127-132)

## Expected File Change
The file `scripts/run_batch_performance.py` will be modified to:
1. Change default timeout from 120.0 to 300.0 in argparse default (line 133)
2. Preserve `--timeout` argument functionality (users can still override)

**Note**: This script does not have a function signature default for timeout (it's only in argparse), so only one location needs to be updated.

## Forbidden Alternatives
- Do NOT change client code logic (this is timeout policy only)
- Do NOT remove `--timeout` argument functionality
- Do NOT change timeout values in other locations (only argparse default)
- Do NOT modify timeout handling logic, only default value

## Atomic Operations

### Operation 1: Update Argparse Default

**Location**: Function `main`, line 133

**Current code**:
```python
    parser.add_argument(
        "--timeout",
        type=float,
        default=120.0,
        help="Timeout per request (s)",
    )
```

**Required change**:
```python
    parser.add_argument(
        "--timeout",
        type=float,
        default=300.0,
        help="Timeout per request (s)",
    )
```

**Algorithm**:
1. Locate the `parser.add_argument` call for `--timeout` starting around line 130
2. Find the `default=120.0` parameter on line 133
3. Replace `default=120.0` with `default=300.0`
4. Keep the help text unchanged (it doesn't specify the default value)

**Exact replacement**:
- **old_string**:
```python
    parser.add_argument(
        "--timeout",
        type=float,
        default=120.0,
        help="Timeout per request (s)",
    )
```
- **new_string**:
```python
    parser.add_argument(
        "--timeout",
        type=float,
        default=300.0,
        help="Timeout per request (s)",
    )
```

## Expected Deliverables
1. Updated `scripts/run_batch_performance.py` with:
   - Timeout default changed from 120.0 to 300.0 in argparse default
   - `--timeout` argument functionality preserved (users can still override)

## Mandatory Validation

### Validation Commands
1. **Syntax check**:
   ```bash
   python -m py_compile scripts/run_batch_performance.py
   ```
   Expected: No output (exit code 0)

2. **Type check** (if mypy is configured):
   ```bash
   mypy scripts/run_batch_performance.py --ignore-missing-imports
   ```
   Expected: "Success: no issues found" or acceptable type warnings

3. **Lint check**:
   ```bash
   flake8 scripts/run_batch_performance.py --max-line-length=120 --ignore=E501,W503
   ```
   Expected: No output (exit code 0) or only acceptable warnings

4. **Black format check**:
   ```bash
   black --check scripts/run_batch_performance.py
   ```
   Expected: "would reformat" or "already well formatted"

5. **Verify timeout defaults**:
   ```bash
   python scripts/run_batch_performance.py --help | grep -A 1 timeout
   ```
   Expected: Help text shows `--timeout` argument exists

6. **Verify argparse default** (manual inspection):
   ```bash
   grep -n "default=" scripts/run_batch_performance.py | grep timeout
   ```
   Expected: Line shows `default=300.0`

### Test Expectations
- Script should execute without syntax errors
- Script should accept `--timeout` argument to override default
- Argparse should have `default=300.0`

## Decision Rules
1. **Argument preservation**: Always preserve `--timeout` argument functionality (users can override)
2. **No logic changes**: Only change default value, not timeout handling logic

## Edge Cases
- If `--timeout` is explicitly provided, it should override the default (existing behavior preserved)
- If timeout is passed programmatically to functions that use it, it should use the provided value (existing behavior preserved)
- If timeout is None, it should be handled by downstream code (existing behavior preserved)

## Constants and Literals
- **Old default timeout**: `120.0` (float, seconds)
- **New default timeout**: `300.0` (float, seconds)
- **Location**: Argparse `default` parameter (line 133)

## Blackstops
Stop and escalate if:
- Argparse structure has changed significantly from expected pattern
- Timeout handling logic needs modification (this step is timeout policy only)
- Changes conflict with other timeout-related modifications

## Handoff Package
- Updated `scripts/run_batch_performance.py` file
- All validation commands pass
- Timeout default verified to be 300.0
- Script ready for execution with new timeout default
