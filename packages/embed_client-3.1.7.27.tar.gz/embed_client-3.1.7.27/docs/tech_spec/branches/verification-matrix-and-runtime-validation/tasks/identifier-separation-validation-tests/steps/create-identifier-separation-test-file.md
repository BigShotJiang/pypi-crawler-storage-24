Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Create Identifier Separation Test File

## Executor Role

**Coder**: `coder_auto`

## Execution Directive

Create a comprehensive test file `tests/test_identifier_separation.py` that validates identifier separation across all execution paths (immediate, queued, WebSocket). The test file must verify that JSON-RPC request `id`, server `job_id`, and adapter-managed WebSocket correlation identifiers are correctly separated and never conflated.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/identifier-separation-validation-tests.md`

## Step Scope

**Target file**: `tests/test_identifier_separation.py`
**Action**: create

This step creates a new test file that validates identifier separation behavior. The file does not exist yet.

## Dependency Contract

**Prerequisites**:
- Step 1: adapter-centric-client-foundation (must complete first)
- Step 2: embed-command-and-result-contract-alignment (must complete first)
- Step 3: queue-and-websocket-identifier-separation (must complete first)

**Dependencies on other files**:
- `embed_client/async_client.py` - client implementation
- `embed_client/async_client_queue_mixin.py` - queue methods
- `embed_client/async_client_api_mixin.py` - job_id extraction logic
- `embed_client/adapter_transport.py` - adapter transport layer
- `embed_client/identifier_types.py` - identifier type definitions
- `embed_client/exceptions.py` - exception classes
- `tests/conftest.py` - test fixtures

**No dependencies on other atomic steps** - this is a standalone test file creation.

## Required Context

The test file must validate:

1. **JSON-RPC request `id` isolation**: JSON-RPC request `id` is never exposed as public API parameter or return value
2. **Job ID extraction**: `job_id` is extracted only from server/adapter fields that explicitly represent queued-job identity
3. **WebSocket correlation separation**: WebSocket correlation identifiers are used only inside adapter-managed async/WebSocket flows
4. **Identifier non-merging**: `job_id` and WebSocket correlation identifiers are not merged unless adapter contract explicitly guarantees equivalence
5. **Missing identifier errors**: Missing or ambiguous identifiers are treated as explicit errors, not silently guessed
6. **Execution path coverage**: All execution paths (immediate, queued with polling, queued with WebSocket) are tested

## Read First

Before implementing, read these files:

1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - identifier model and operational identifier-safety rules (lines 359-405)
2. `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` - client implementation and identifier handling
3. `/home/vasilyvz/projects/embed-client/embed_client/async_client_queue_mixin.py` - queue methods and identifier usage
4. `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` - `_extract_job_id_from_response()` function (lines 31-85)
5. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - adapter response formats
6. `/home/vasilyvz/projects/embed-client/embed_client/identifier_types.py` - `JobId` and `DeliverId` type definitions
7. `/home/vasilyvz/projects/embed-client/embed_client/exceptions.py` - exception classes
8. `/home/vasilyvz/projects/embed-client/tests/conftest.py` - available test fixtures
9. `/home/vasilyvz/projects/embed-client/tests/test_adapter_phase2.py` - test structure examples

## Expected File Change

**File**: `tests/test_identifier_separation.py`
**Action**: create new file

The file will contain:
- Module docstring with author and email
- Imports (pytest, pytest_asyncio, unittest.mock, embed_client modules)
- Test class `TestIdentifierSeparation` with pytest async test methods
- All test methods listed in the "Class/Function Inventory" section below

## Forbidden Alternatives

- Do NOT use JSON-RPC request `id` as `job_id` in tests
- Do NOT merge `job_id` with WebSocket correlation `id` in tests unless adapter guarantees equivalence
- Do NOT silently guess identifiers when missing - tests must assert explicit errors
- Do NOT expose JSON-RPC request `id` in public API assertions
- Do NOT skip identifier separation validation in any execution path
- Do NOT assume identifier equivalence without adapter contract guarantee
- Do NOT create tests that modify core client implementation files
- Do NOT create tests that bypass adapter transport layer

## Atomic Operations

### File Header

**Module docstring**:
```python
"""
Comprehensive test suite for identifier separation validation.

This module validates that the synchronized client correctly separates and handles
different identifier types (JSON-RPC request id, server job_id, adapter-managed
WebSocket correlation identifier) without conflation.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
```

### Complete Import List

**Exact imports**:
```python
from __future__ import annotations

import pytest
import pytest_asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from typing import Any, Dict, Optional

from embed_client.async_client import EmbeddingServiceAsyncClient
from embed_client.exceptions import (
    EmbeddingServiceError,
    EmbeddingServiceAPIError,
    EmbeddingServiceJSONError,
    EmbeddingServiceTimeoutError,
)
from embed_client.identifier_types import JobId, DeliverId, is_valid_job_id, is_valid_deliver_id
```

### Class Structure

**Class name**: `TestIdentifierSeparation`
**Base class**: None (pytest-style test class, no base class needed)
**Purpose**: Test suite for identifier separation validation

**Instance attributes**: None (test class, no instance state)

### Method Signatures and Algorithms

#### Method 1: `test_jsonrpc_id_not_exposed() -> None`

**Purpose**: Verify JSON-RPC request `id` is never exposed in public API parameters or return values.

**Algorithm**:
1. Create test client using `EmbeddingServiceAsyncClient.from_config()` or constructor with test config
2. Execute `client.embed(["test text"])` with `wait=True` to get immediate or queued result
3. Assert that the result dictionary does NOT contain key `"id"` (JSON-RPC protocol id)
4. If result contains `"job_id"`, assert that `job_id` is a string (not a number, which JSON-RPC id usually is)
5. Assert that `job_id` (if present) is not a simple integer or matches JSON-RPC id format
6. Execute `client.models()` and assert result does NOT contain `"id"` key
7. Execute `client.job_status("test-job-id")` with mock adapter and assert result does NOT contain `"id"` key

**Error handling**: None (test assertions only)

**Return value**: None (pytest test)

**Edge cases**:
- Immediate mode result (no job_id) - verify no `id` field
- Queued mode result (with job_id) - verify job_id is string, not JSON-RPC id
- Error responses - verify error dict does not expose JSON-RPC id

#### Method 2: `test_job_id_extraction() -> None`

**Purpose**: Verify `job_id` is extracted only from server/adapter fields that explicitly represent queued-job identity.

**Algorithm**:
1. Create test client
2. Mock `_adapter_transport.execute_command_unified()` to return queued response with `job_id` in top-level: `{"mode": "queued", "job_id": "job-123", "result": {...}}`
3. Execute `client.embed(["test"], wait=False)` to get queued response
4. Assert result contains `"job_id"` key
5. Assert `result["job_id"] == "job-123"` (extracted from top-level)
6. Mock adapter to return nested job_id: `{"mode": "queued", "result": {"job_id": "job-456"}}`
7. Execute `client.embed(["test"], wait=False)` again
8. Assert `result["job_id"] == "job-456"` (extracted from nested location)
9. Mock adapter to return job_id in result.data: `{"mode": "queued", "result": {"data": {"job_id": "job-789"}}}`
10. Execute `client.embed(["test"], wait=False)` again
11. Assert `result["job_id"] == "job-789"` (extracted from result.data)
12. Verify job_id is NOT extracted from JSON-RPC request id by mocking adapter to return response with numeric `id` field and no `job_id`, then asserting no `job_id` in result

**Error handling**: None (test assertions only)

**Return value**: None (pytest test)

**Edge cases**:
- job_id in multiple locations - should extract from first valid location (top-level, then nested)
- job_id is empty string - should not extract (use `is_valid_job_id()`)
- job_id is None - should not extract
- job_id is not a string - should not extract

#### Method 3: `test_websocket_correlation_separation() -> None`

**Purpose**: Verify WebSocket correlation identifiers are kept separate from `job_id`.

**Algorithm**:
1. Create test client
2. Mock `_adapter_transport.execute_command_unified()` to return queued response: `{"mode": "queued", "job_id": "job-123"}`
3. Execute `client.embed(["test"], wait=False)` to get `job_id`
4. Store `job_id` from result
5. Mock `_adapter_transport.wait_for_job_via_websocket()` to return WebSocket completion with correlation id: `{"event": "job_completed", "job_id": "job-123", "correlation_id": "ws-delivery-1", "result": {...}}`
6. Execute `client.wait_for_job_via_websocket(job_id, timeout=10.0)`
7. Assert final result contains business data (results/embeddings)
8. If adapter exposes `correlation_id` in response, assert it is separate field from `job_id`
9. Verify that `job_id` parameter passed to `wait_for_job_via_websocket()` is the queue `job_id`, not correlation id
10. Verify that WebSocket correlation id (if present) is not used as `job_id` for status polling

**Error handling**: None (test assertions only)

**Return value**: None (pytest test)

**Edge cases**:
- WebSocket response without correlation_id - should still work with job_id
- WebSocket response with correlation_id matching job_id - should preserve both separately
- WebSocket response with correlation_id different from job_id - should keep separate

#### Method 4: `test_identifier_not_merged() -> None`

**Purpose**: Verify identifiers are not merged unless adapter contract explicitly guarantees equivalence.

**Algorithm**:
1. Create test client
2. Execute queued operation to get `job_id`: `result = await client.embed(["test"], wait=False)`
3. Store `job_id` from result
4. Execute WebSocket wait: `final_result = await client.wait_for_job_via_websocket(job_id, timeout=10.0)`
5. If adapter response contains both `job_id` and `correlation_id`, assert they are separate fields
6. Assert that `job_id` used for status polling (`client.job_status(job_id)`) is the queue job_id, not correlation id
7. Verify that if adapter exposes `deliver_id` from `execute_async`, it is distinct from `job_id`
8. Mock `execute_async` response with `deliver_id` and verify it is not used as `job_id`

**Error handling**: None (test assertions only)

**Return value**: None (pytest test)

**Edge cases**:
- Adapter guarantees equivalence - test should document this explicitly
- Adapter does not guarantee equivalence - test should assert separation
- Multiple identifiers in same response - test should verify all are distinct

#### Method 5: `test_missing_job_id_error() -> None`

**Purpose**: Verify missing `job_id` in queued result raises explicit error.

**Algorithm**:
1. Create test client
2. Mock `_adapter_transport.execute_command_unified()` to return queued response without `job_id`: `{"mode": "queued", "status": "pending"}` (no job_id field)
3. Execute `client.embed(["test"], wait=False)`
4. Assert that result either:
   - Contains `job_id: None` and `mode: "immediate"` (if treated as immediate), OR
   - Raises `EmbeddingServiceJSONError` or `ValueError` with message indicating missing job_id
5. Mock adapter to return queued response with empty string job_id: `{"mode": "queued", "job_id": ""}`
6. Execute `client.embed(["test"], wait=False)` again
7. Assert explicit error is raised (empty string is not valid job_id)
8. Verify error message is clear about missing or invalid job_id

**Error handling**: Test must use `pytest.raises()` to catch expected exceptions

**Return value**: None (pytest test)

**Edge cases**:
- Missing job_id in queued mode - should raise error or return None explicitly
- Empty string job_id - should raise error (use `is_valid_job_id()`)
- None job_id in queued mode - should raise error
- job_id is not a string - should raise error

#### Method 6: `test_ambiguous_identifier_error() -> None`

**Purpose**: Verify ambiguous identifier fields raise explicit errors.

**Algorithm**:
1. Create test client
2. Mock adapter to return response with conflicting identifiers: `{"mode": "queued", "job_id": "job-123", "id": 456, "correlation_id": "ws-789"}` where `id` might be confused with job_id
3. Execute `client.embed(["test"], wait=False)`
4. Assert that `job_id` is extracted correctly from `job_id` field, not from `id` field
5. Assert that numeric `id` field is not used as `job_id`
6. Mock adapter to return response where job_id appears in multiple locations with different values: `{"job_id": "job-1", "result": {"job_id": "job-2"}}`
7. Execute `client.embed(["test"], wait=False)` again
8. Assert that extraction follows priority order (top-level first) and does not merge values
9. Verify that if job_id extraction finds multiple valid locations, it uses first match, not merged value

**Error handling**: Test may need to verify no silent merging occurs

**Return value**: None (pytest test)

**Edge cases**:
- Multiple job_id fields with same value - should extract one, not error
- Multiple job_id fields with different values - should use first match, not merge
- job_id and numeric id field - should use job_id, ignore numeric id

#### Method 7: `test_immediate_mode_no_job_id() -> None`

**Purpose**: Verify immediate mode does not invent `job_id`.

**Algorithm**:
1. Create test client
2. Mock `_adapter_transport.execute_command_unified()` to return immediate response: `{"mode": "immediate", "result": {"success": True, "data": {"results": [...]}}}`
3. Execute `client.embed(["test"], wait=True)`
4. Assert result contains business data (results/embeddings)
5. Assert result does NOT contain `"job_id"` key
6. Assert result does NOT contain `"id"` key (JSON-RPC id)
7. Verify that immediate mode response is returned directly without queue lifecycle
8. Execute `client.models()` and verify response does not contain `job_id`

**Error handling**: None (test assertions only)

**Return value**: None (pytest test)

**Edge cases**:
- Immediate response with mode="immediate" - should not have job_id
- Immediate response without mode field but with results - should not have job_id
- Immediate response that looks like queued but has results - should not invent job_id

#### Method 8: `test_queued_mode_job_id_extraction() -> None`

**Purpose**: Verify queued mode extracts `job_id` correctly.

**Algorithm**:
1. Create test client
2. Mock `_adapter_transport.execute_command_unified()` to return queued response: `{"mode": "queued", "job_id": "job-123", "status": "pending"}`
3. Execute `client.embed(["test"], wait=False)`
4. Assert result contains `"job_id"` key
5. Assert `result["job_id"] == "job-123"`
6. Assert `result["status"] == "pending"` (or extracted status)
7. Verify that `job_id` is a string (use `is_valid_job_id()`)
8. Verify that `job_id` is not extracted from JSON-RPC request id by checking it's not a number
9. Use extracted `job_id` to call `client.job_status(job_id)` and verify it works
10. Mock `_adapter_transport.queue_get_job_status()` to return status for the job_id
11. Assert status lookup uses the correct `job_id` string

**Error handling**: None (test assertions only)

**Return value**: None (pytest test)

**Edge cases**:
- job_id in top-level - should extract
- job_id in nested result - should extract
- job_id in result.data - should extract
- job_id is valid string - should extract and validate

#### Method 9: `test_websocket_mode_identifier_separation() -> None`

**Purpose**: Verify WebSocket mode keeps `job_id` and correlation `id` separate.

**Algorithm**:
1. Create test client
2. Execute queued operation: `result = await client.embed(["test"], wait=False)`
3. Extract `job_id` from result
4. Mock `_adapter_transport.wait_for_job_via_websocket()` to return completion: `{"event": "job_completed", "job_id": job_id, "correlation_id": "ws-correlation-1", "result": {"success": True, "data": {...}}}`
5. Execute `final_result = await client.wait_for_job_via_websocket(job_id, timeout=10.0)`
6. Assert final_result contains business data
7. If adapter response contains `correlation_id`, verify it is separate from `job_id`
8. Verify that `job_id` parameter passed to `wait_for_job_via_websocket()` is the queue job_id
9. Verify that WebSocket subscription uses `job_id`, not correlation_id
10. Mock bidirectional channel subscription: `{"action": "subscribe", "job_id": job_id}` and verify it uses queue job_id

**Error handling**: None (test assertions only)

**Return value**: None (pytest test)

**Edge cases**:
- WebSocket completion with job_id only - should work
- WebSocket completion with both job_id and correlation_id - should keep separate
- WebSocket subscription uses job_id - should not use correlation_id

### Test Fixtures (if needed)

If tests require shared fixtures, add them using `pytest_asyncio.fixture`:

**Fixture name**: `test_client` (optional, if needed)
**Purpose**: Create test client instance
**Algorithm**:
1. Create config dict with test server settings
2. Create `EmbeddingServiceAsyncClient` instance
3. Enter async context (`await client.__aenter__()`)
4. Yield client
5. Exit async context (`await client.__aexit__()`)

**Usage**: Use `@pytest_asyncio.fixture` decorator

## Expected Deliverables

1. **File**: `tests/test_identifier_separation.py`
   - Complete test file with all 9 test methods
   - Module docstring with author and email
   - All required imports
   - Test class `TestIdentifierSeparation`
   - All test methods implemented with proper assertions

2. **Test coverage**:
   - JSON-RPC request id isolation
   - Job ID extraction from correct fields
   - WebSocket correlation separation
   - Identifier non-merging
   - Missing identifier error handling
   - Ambiguous identifier error handling
   - Immediate mode (no job_id)
   - Queued mode (job_id extraction)
   - WebSocket mode (identifier separation)

## Mandatory Validation

After implementation, run these exact commands:

1. **Format check**:
   ```bash
   black tests/test_identifier_separation.py
   ```
   **Expected**: "reformatted" or "already well formatted" (exit 0)

2. **Lint check**:
   ```bash
   flake8 tests/test_identifier_separation.py
   ```
   **Expected**: No output (exit 0)

3. **Type check**:
   ```bash
   mypy tests/test_identifier_separation.py
   ```
   **Expected**: "Success: no issues found" or acceptable type errors only

4. **Run tests**:
   ```bash
   pytest tests/test_identifier_separation.py -v
   ```
   **Expected**: All tests PASSED (may require mock setup or test server)

**All tests must pass** before considering this step complete.

## Decision Rules

1. **Mock strategy**: Use `unittest.mock.patch` to mock `_adapter_transport` methods. Mock at the transport level, not adapter client level.

2. **Test data**: Use realistic but simple test data:
   - Test texts: `["test text"]`
   - Test job_id: `"job-123"`, `"job-456"`, etc.
   - Test correlation_id: `"ws-correlation-1"`, `"ws-delivery-1"`, etc.

3. **Assertion style**: Use explicit assertions with clear messages:
   - `assert "job_id" in result`
   - `assert result["job_id"] == "job-123"`
   - `assert "id" not in result` (JSON-RPC id not exposed)

4. **Error testing**: Use `pytest.raises()` for expected exceptions:
   - `with pytest.raises(EmbeddingServiceJSONError):`
   - `with pytest.raises(ValueError):`

5. **Async tests**: Use `@pytest.mark.asyncio` decorator for async test methods.

6. **Identifier validation**: Use `is_valid_job_id()` and `is_valid_deliver_id()` from `identifier_types.py` when validating identifier formats.

## Blackstops

**Stop immediately if**:
- Core client implementation files need modification (this step is test-only)
- Adapter transport layer needs modification (already implemented in Step 1)
- Identifier separation logic needs changes (already implemented in Step 3)
- Tests cannot be written without modifying production code (escalate to tactical orchestrator)

## Handoff Package

**For coder_auto**:

1. **Target file**: `tests/test_identifier_separation.py` (create new file)

2. **Required imports** (exact list provided above)

3. **Test class**: `TestIdentifierSeparation` with 9 test methods:
   - `test_jsonrpc_id_not_exposed()`
   - `test_job_id_extraction()`
   - `test_websocket_correlation_separation()`
   - `test_identifier_not_merged()`
   - `test_missing_job_id_error()`
   - `test_ambiguous_identifier_error()`
   - `test_immediate_mode_no_job_id()`
   - `test_queued_mode_job_id_extraction()`
   - `test_websocket_mode_identifier_separation()`

4. **Algorithm details**: Each method has step-by-step algorithm provided above

5. **Validation commands**: Exact commands provided in "Mandatory Validation" section

6. **Success criteria**: All 9 tests pass, file passes black/flake8/mypy

7. **Forbidden patterns**: Listed in "Forbidden Alternatives" section

**No implementation code in this step file** - only specifications for the coder.
