# Atomic Step: Update run_testing_client_performance.py

## Executor Role
`coder_auto` — implement the code changes described in this step.

## Execution Directive
Update `scripts/run_testing_client_performance.py` to ensure it fully complies with the synchronized client architecture from Steps 1-3. Verify adapter-backed client construction and certificate path resolution patterns.

## Parent Links
- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

## Step Scope
**Target file**: `scripts/run_testing_client_performance.py`
**Action**: modify

## Dependency Contract
- Depends on: Steps 1-3 (adapter-centric-client-foundation, embed-command-and-result-contract-alignment, queue-and-websocket-identifier-separation)
- No dependencies on other atomic steps in this tactical task
- Can execute in parallel with other script update steps

## Required Context
The script `run_testing_client_performance.py` tests performance of `EmbeddingServiceClient` (sync/testing client) on a real server. It must:
1. Use adapter-backed client construction via `EmbeddingServiceClient.from_config(config_path)`
2. Use context manager (`async with`) for proper resource cleanup
3. Resolve certificate paths correctly when generating or loading config

## Read First
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` — client construction patterns
2. `/home/vasilyvz/projects/embed-client/scripts/run_testing_client_performance.py` — current script implementation
3. `/home/vasilyvz/projects/embed-client/embed_client/testing_client.py` — EmbeddingServiceClient construction and method signatures
4. `/home/vasilyvz/projects/embed-client/embed_client/config_generator.py` — ClientConfigGenerator signature

## Expected File Change
The file `scripts/run_testing_client_performance.py` will be modified to:
1. Verify context manager usage is correct (`async with EmbeddingServiceClient.from_config(config_path)`)
2. Ensure certificate path resolution works correctly when generating config
3. Verify adapter-backed client construction is used (not direct instantiation)

## Forbidden Alternatives
- Do NOT use direct client instantiation (must use `from_config`)
- Do NOT bypass context manager (must use `async with`)
- Do NOT hardcode certificate paths without PROJECT_ROOT resolution

## Atomic Operations

### Operation 1: Verify Context Manager Usage

**Location**: Function `_run_performance`, around line 178-186

**Current pattern** (should already be correct):
```python
client = EmbeddingServiceClient.from_config(config_path)
# ...
async with client:
    # ... test code
```

**Verification**:
1. Ensure `EmbeddingServiceClient.from_config(config_path)` is used (not direct instantiation)
2. Ensure the `async with` statement is used (not manual `__aenter__`/`__aexit__`)
3. Ensure all client operations are inside the `async with` block
4. No manual `await client.close()` calls needed (context manager handles it)

**If incorrect**, fix to use `async with` pattern.

### Operation 2: Verify Certificate Path Resolution in Config Generation

**Location**: Function `_generate_config`, around line 47-100

**Current pattern** (should already be correct):
```python
def _generate_config(
    mode: str,
    host: str,
    port: int,
    cert_file: str | None = None,
    key_file: str | None = None,
    ca_cert_file: str | None = None,
) -> Path:
    # ... config generation logic
    if mode == "mtls":
        gen.generate_mtls_config(
            host=host,
            port=port,
            cert_file=cert_file,
            key_file=key_file,
            ca_cert_file=ca_cert_file,
        )
```

**Verification**:
1. Ensure certificate paths passed to `generate_mtls_config` are resolved relative to `PROJECT_ROOT` if they are relative
2. Ensure paths are converted to strings if needed
3. Ensure all three certificate files (cert, key, ca) are specified for mTLS mode

**If certificate path resolution is missing**, add resolution logic:
```python
def _resolve_cert_path(cert_path: str | None) -> str | None:
    """Resolve relative cert path under PROJECT_ROOT."""
    if cert_path is None:
        return None
    if cert_path.startswith("/"):
        return cert_path  # Already absolute
    resolved = _project_root / cert_path
    return str(resolved) if resolved.exists() else cert_path
```

Then use it in `_generate_config`:
```python
cert_file = _resolve_cert_path(cert_file)
key_file = _resolve_cert_path(key_file)
ca_cert_file = _resolve_cert_path(ca_cert_file)
```

### Operation 3: Verify Adapter-Backed Client Construction

**Location**: Function `_run_performance`, around line 178

**Current pattern** (should already be correct):
```python
client = EmbeddingServiceClient.from_config(config_path)
```

**Verification**:
1. Ensure `EmbeddingServiceClient.from_config(config_path)` is used (not direct instantiation with custom transport/auth)
2. Ensure `config_path` is a valid Path or string pointing to a config file
3. Ensure no custom transport or auth logic is used (all handled by adapter)

**If incorrect**, fix to use `from_config` pattern.

## Expected Deliverables
1. Updated `scripts/run_testing_client_performance.py` with:
   - Proper context manager usage
   - Correct certificate path resolution when generating config
   - Proper adapter-backed client construction

## Mandatory Validation

### Validation Commands
1. **Syntax check**:
   ```bash
   python -m py_compile scripts/run_testing_client_performance.py
   ```
   Expected: No output (exit code 0)

2. **Type check** (if mypy is configured):
   ```bash
   mypy scripts/run_testing_client_performance.py --ignore-missing-imports
   ```
   Expected: "Success: no issues found" or acceptable type warnings

3. **Lint check**:
   ```bash
   flake8 scripts/run_testing_client_performance.py --max-line-length=120 --ignore=E501,W503
   ```
   Expected: No output (exit code 0) or only acceptable warnings

4. **Black format check**:
   ```bash
   black --check scripts/run_testing_client_performance.py
   ```
   Expected: "would reformat" or "already well formatted"

5. **Manual verification** (if server available):
   ```bash
   python scripts/run_testing_client_performance.py --help
   ```
   Expected: Help message displayed, exit code 0

### Test Expectations
- Script should execute without syntax errors
- Script should use context manager for client lifecycle
- Script should resolve certificate paths correctly when generating config
- Script should use adapter-backed client construction

## Decision Rules
1. **Context manager**: Always use `async with EmbeddingServiceClient.from_config(config_path) as client:`
2. **Certificate paths**: Always resolve relative paths using `PROJECT_ROOT` before passing to config generator
3. **Client construction**: Always use `from_config` factory method, never direct instantiation
4. **Config generation**: Always resolve certificate paths when generating mTLS config

## Blackstops
Stop and escalate if:
- Script requires changes to core client architecture (affects Steps 1-3)
- Script reveals bugs in synchronized client that require global fixes
- Script execution reveals contradictions between adapter behavior and expected server contract

## Handoff Package
- Updated `scripts/run_testing_client_performance.py` file
- All validation commands pass
- Script ready for execution on `localhost:8001` with mTLS certificates
