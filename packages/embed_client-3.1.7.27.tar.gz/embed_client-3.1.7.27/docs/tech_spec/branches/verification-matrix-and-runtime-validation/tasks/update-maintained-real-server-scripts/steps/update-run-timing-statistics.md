# Atomic Step: Update run_timing_statistics.py

## Executor Role
`coder_auto` — implement the code changes described in this step.

## Execution Directive
Update `scripts/run_timing_statistics.py` to ensure it fully complies with the synchronized client architecture from Steps 1-3. Fix context manager usage and verify adapter-backed client construction patterns.

## Parent Links
- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

## Step Scope
**Target file**: `scripts/run_timing_statistics.py`
**Action**: modify

## Dependency Contract
- Depends on: Steps 1-3 (adapter-centric-client-foundation, embed-command-and-result-contract-alignment, queue-and-websocket-identifier-separation)
- No dependencies on other atomic steps in this tactical task
- Can execute in parallel with other script update steps

## Required Context
The script `run_timing_statistics.py` computes timing statistics for batch and single requests. It must:
1. Use adapter-backed client construction via `EmbeddingServiceAsyncClient.from_config(config)`
2. Use context manager (`async with`) for proper resource cleanup (currently uses manual `__aenter__`/`close()`)
3. Resolve certificate paths correctly relative to PROJECT_ROOT

## Read First
1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` — client construction patterns
2. `/home/vasilyvz/projects/embed-client/scripts/run_timing_statistics.py` — current script implementation
3. `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` — client construction and method signatures
4. `/home/vasilyvz/projects/embed-client/embed_client/config.py` — ClientConfig signature

## Expected File Change
The file `scripts/run_timing_statistics.py` will be modified to:
1. Fix context manager usage (replace manual `__aenter__`/`close()` with `async with`)
2. Ensure certificate path resolution works correctly when loading config from file
3. Verify `_resolve_cert_paths` helper is called when loading config from file

## Forbidden Alternatives
- Do NOT use direct client instantiation (must use `from_config`)
- Do NOT use manual `__aenter__`/`close()` (must use `async with` context manager)
- Do NOT hardcode certificate paths without PROJECT_ROOT resolution

## Atomic Operations

### Operation 1: Fix Context Manager Usage in `main` Function

**Location**: Function `main`, around line 356-394

**Current pattern** (incorrect):
```python
client = EmbeddingServiceAsyncClient.from_config(config)
try:
    await client.__aenter__()
    # ... test code
finally:
    await client.close()
```

**Required pattern**:
```python
async with EmbeddingServiceAsyncClient.from_config(config) as client:
    # ... test code
    # No manual close() needed
```

**Algorithm**:
1. Find the client instantiation in `main` function (around line 356)
2. Replace manual `__aenter__`/`close()` pattern with `async with` context manager
3. Remove `try`/`finally` block that manually calls `__aenter__` and `close()`
4. Ensure all client operations are inside the `async with` block
5. Remove any `await client.close()` calls (context manager handles cleanup)
6. Ensure health check and test phases are inside the `async with` block

### Operation 2: Verify Certificate Path Resolution

**Location**: Function `_make_config`, around line 139-147

**Current pattern** (should already be correct):
```python
def _make_config(config_path: Path) -> ClientConfig:
    path = config_path if config_path.is_absolute() else PROJECT_ROOT / config_path
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")
    config = ClientConfig(str(path))
    config.load_config()
    # Resolve relative cert paths so mtls_certificates works from project root
    _resolve_cert_paths(config.config_data)
    return config
```

**Verification**:
1. Ensure config path is resolved relative to `PROJECT_ROOT` if not absolute
2. Ensure `FileNotFoundError` is raised if config file doesn't exist
3. Ensure `_resolve_cert_paths` is called after `config.load_config()`
4. Ensure `_resolve_cert_paths` receives `config.config_data` (the dict, not the ClientConfig object)

**If `_resolve_cert_paths` is not called**, add the call after `config.load_config()`.

### Operation 3: Verify `_resolve_cert_paths` Helper Function

**Location**: Function `_resolve_cert_paths`, around line 95-116

**Current pattern** (should already exist):
```python
def _resolve_cert_paths(config_data: Dict[str, Any]) -> None:
    """Resolve relative paths under mtls_certificates to PROJECT_ROOT (in-place)."""
    # ... existing logic
```

**Verification**:
1. Ensure function modifies `config_data` in-place
2. Ensure both `auth.certificate.*` and `ssl.*` paths are resolved
3. Ensure paths are only resolved if they are relative (not starting with "/")
4. Ensure resolved paths are converted to strings
5. Ensure function checks if resolved path exists before updating

**If function is missing or incorrect**, implement or fix it:
```python
def _resolve_cert_paths(config_data: Dict[str, Any]) -> None:
    """Resolve relative cert paths under PROJECT_ROOT (in-place)."""
    for section in ("auth", "ssl"):
        sect = config_data.get(section, {})
        if not isinstance(sect, dict):
            continue
        cert_sect = sect.get("certificate", sect) if section == "auth" else sect
        if not isinstance(cert_sect, dict):
            continue
        for key in ("cert_file", "key_file", "ca_cert_file", "crl_file"):
            val = cert_sect.get(key)
            if isinstance(val, str) and not val.startswith("/"):
                resolved = PROJECT_ROOT / val
                if resolved.exists():
                    cert_sect[key] = str(resolved)
        if section == "ssl" and isinstance(sect, dict):
            for key in ("cert_file", "key_file", "ca_cert_file", "crl_file"):
                val = sect.get(key)
                if isinstance(val, str) and not val.startswith("/"):
                    resolved = PROJECT_ROOT / val
                    if resolved.exists():
                        sect[key] = str(resolved)
```

## Expected Deliverables
1. Updated `scripts/run_timing_statistics.py` with:
   - Correct context manager usage (`async with` instead of manual `__aenter__`/`close()`)
   - Correct certificate path resolution when loading config from file
   - Proper error handling for config loading

## Mandatory Validation

### Validation Commands
1. **Syntax check**:
   ```bash
   python -m py_compile scripts/run_timing_statistics.py
   ```
   Expected: No output (exit code 0)

2. **Type check** (if mypy is configured):
   ```bash
   mypy scripts/run_timing_statistics.py --ignore-missing-imports
   ```
   Expected: "Success: no issues found" or acceptable type warnings

3. **Lint check**:
   ```bash
   flake8 scripts/run_timing_statistics.py --max-line-length=120 --ignore=E501,W503
   ```
   Expected: No output (exit code 0) or only acceptable warnings

4. **Black format check**:
   ```bash
   black --check scripts/run_timing_statistics.py
   ```
   Expected: "would reformat" or "already well formatted"

5. **Manual verification** (if server available):
   ```bash
   python scripts/run_timing_statistics.py --help
   ```
   Expected: Help message displayed, exit code 0

### Test Expectations
- Script should execute without syntax errors
- Script should use context manager for client lifecycle
- Script should resolve certificate paths correctly
- Script should handle config file loading with proper error handling

## Decision Rules
1. **Context manager**: Always use `async with EmbeddingServiceAsyncClient.from_config(config) as client:`, never manual `__aenter__`/`close()`
2. **Certificate paths**: Always resolve relative paths using `PROJECT_ROOT` before passing to config
3. **Config loading**: Always call `_resolve_cert_paths` after `config.load_config()` when loading from file
4. **Error handling**: Always handle `FileNotFoundError` for missing config files

## Blackstops
Stop and escalate if:
- Script requires changes to core client architecture (affects Steps 1-3)
- Script reveals bugs in synchronized client that require global fixes
- Script execution reveals contradictions between adapter behavior and expected server contract

## Handoff Package
- Updated `scripts/run_timing_statistics.py` file
- All validation commands pass
- Script ready for execution on `localhost:8001` with mTLS certificates
