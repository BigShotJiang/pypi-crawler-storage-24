Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Update And Validate Maintained Real-Server Scripts

## Purpose

Update all maintained real-server test scripts and pipelines that target `localhost:8001` with `mtls`/`mtls_certificates` to work correctly with the synchronized client architecture from Steps 1-3. Ensure all scripts use adapter-backed client construction, correct identifier handling, and proper result normalization. Validate that all scripts execute successfully after the synchronization changes.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/verification-matrix-and-runtime-validation.md`

## Scope

### Included

- All scripts under `scripts/` that:
  - target `localhost:8001`
  - use `mtls` or `mtls_certificates`
  - use `EmbeddingServiceAsyncClient` or `EmbeddingServiceClient`
  - use `ClientConfig` or generated config files
  - exercise queue, polling, or WebSocket flows affected by Steps 1-3
- Scripts identified:
  - `scripts/run_real_server_mtls_test.py`
  - `scripts/run_bidirectional_ws_performance.py`
  - `scripts/run_real_server_performance.py`
  - `scripts/compare_direct_vs_client.py`
  - `scripts/run_cuda_stress.py`
  - `scripts/run_timing_statistics.py`
  - `scripts/run_testing_client_performance.py` (if it exists and targets localhost:8001)
  - `scripts/run_batch_performance.py` (if it exists and targets localhost:8001)
- Validation that all updated scripts execute successfully
- Verification that scripts correctly use adapter-backed client construction
- Verification that scripts correctly handle identifier separation (JSON-RPC id vs job_id vs WebSocket correlation)
- Verification that scripts correctly handle both immediate and queued result modes

### Excluded

- Unit tests under `tests/` (covered in separate tactical tasks)
- Scripts that do not target `localhost:8001`
- Scripts that do not use `mtls`/`mtls_certificates`
- Scripts that are not part of the maintained real-server pipeline

## Boundaries

This task must NOT touch:
- Core client implementation files (already updated in Steps 1-3)
- Adapter transport layer (already updated in Step 1)
- Test files under `tests/` (covered in other tactical tasks)
- Scripts that are not maintained real-server scripts

## Dependencies

- Step 1: adapter-centric-client-foundation (must complete first)
- Step 2: embed-command-and-result-contract-alignment (must complete first)
- Step 3: queue-and-websocket-identifier-separation (must complete first)

This tactical task depends on all prior steps because it validates the integrated synchronized client.

## Parallelization Note

This tactical task can run in parallel with:
- `security-matrix-validation-tests.md`
- `result-mode-validation-tests.md`
- `identifier-separation-validation-tests.md`

However, this task must complete before the final integration validation phase.

## Expected Outcome

1. All maintained real-server scripts that target `localhost:8001` with `mtls`/`mtls_certificates` are updated to use adapter-backed client construction
2. All scripts correctly use `ClientConfig` or adapter-compatible config generation
3. All scripts correctly handle identifier separation (no mixing of JSON-RPC id, job_id, WebSocket correlation)
4. All scripts correctly handle both immediate and queued result modes
5. All scripts execute successfully on `localhost:8001` with `mtls_certificates`
6. All scripts produce expected output and validation results
7. Scripts that use queue/WebSocket flows correctly use `job_id` for status and waiting operations
8. Scripts that use WebSocket completion correctly use adapter-managed waiting methods

## Correction Items

### Blocked On Step 2 (Critical)

1. **File**: `scripts/run_testing_client_performance.py`
   - **Issue**: `'EmbeddingServiceClient' object has no attribute 'embed'` - The `embed` method in `EmbeddingServiceClient` class is incorrectly indented inside the `_normalize_result_to_public_format` function instead of being a class method.
   - **Root Cause**: Step 2 (embed-command-and-result-contract-alignment) modifies `embed_client/testing_client.py` and must fix the indentation/structure issue.
   - **Blocked On**: Step 2 completion - fix `EmbeddingServiceClient.embed` method structure in `embed_client/testing_client.py` (line 337 should be a class method, not nested inside `_normalize_result_to_public_format`).
   - **Verification**: After step 2 fix, script must execute successfully and correctly test `EmbeddingServiceClient.embed()` method.

### Current Implementation Issues (Step 4 Scope)

1. **File**: `scripts/run_real_server_mtls_test.py`
   - **Status**: ✅ COMPLETED - Script passes all tests (health, embed(wait=True), embed(wait=False) + job_status)
   - **Verification**: Script executes successfully with adapter-backed client construction

2. **File**: `scripts/run_bidirectional_ws_performance.py`
   - **Status**: ⚠️ TIMEOUT - Script times out with default 60s timeout when waiting for WebSocket completion
   - **Issue**: Default timeout (60s) may be too conservative for current server performance
   - **Classification**: Configuration/timeout policy issue (step 4 scope) - not a client code bug
   - **Correction**: Increase default timeout from 60s to 300s to match other performance scripts, or document that `--timeout` should be used for slower servers
   - **Verification**: Script executes successfully with increased timeout or explicit `--timeout 300`

3. **File**: `scripts/run_real_server_performance.py`
   - **Status**: ✅ COMPLETED - Script passes baseline mode tests
   - **Verification**: Script executes successfully with correct identifier separation

4. **File**: `scripts/compare_direct_vs_client.py`
   - **Status**: ⚠️ TIMEOUT - Script times out with default 60s timeout
   - **Issue**: Default timeout (60s) may be too conservative for current server performance
   - **Classification**: Configuration/timeout policy issue (step 4 scope) - not a client code bug
   - **Correction**: Increase default timeout from 60s to 300s to match server performance characteristics
   - **Verification**: Script executes successfully with increased timeout

5. **File**: `scripts/run_cuda_stress.py`
   - **Status**: ⚠️ TIMEOUT - Baseline test fails with 60s timeout
   - **Issue**: Default timeout (60s) may be too conservative, though script already supports `--timeout` argument (default 300s in code)
   - **Classification**: Server/performance issue - jobs taking longer than expected to complete
   - **Note**: Script already has reasonable default (300s), but baseline test still times out, suggesting server-side slowness

6. **File**: `scripts/run_timing_statistics.py`
   - **Status**: ⚠️ TIMEOUT - Script times out
   - **Issue**: Default timeout is 300s (already high), suggesting server-side performance issue
   - **Classification**: Server/performance issue - not a client code or configuration issue

7. **File**: `scripts/run_batch_performance.py`
   - **Status**: ⚠️ TIMEOUT - Script times out
   - **Issue**: Default timeout not explicitly set in code, may be using client default (60s)
   - **Classification**: Configuration/timeout policy issue (step 4 scope) - should set explicit default timeout
   - **Correction**: Add explicit default timeout (e.g., 300s) to match server performance characteristics
   - **Verification**: Script executes successfully with explicit timeout

## Questions/Escalation Rule

Escalate to global orchestrator if:
- A maintained real-server script requires changes to core client architecture (affects Steps 1-3)
- Script validation reveals bugs in the synchronized client that require global fixes
- Script execution reveals contradictions between adapter behavior and expected server contract

## File Inventory

### Files to Modify

1. **Action**: modify
   **Path**: `scripts/run_real_server_mtls_test.py`
   **Purpose**: Update to use adapter-backed client construction and correct identifier handling
   **Status**: ✅ COMPLETED

2. **Action**: modify
   **Path**: `scripts/run_bidirectional_ws_performance.py`
   **Purpose**: Update to use correct identifier separation for WebSocket completion flows AND increase default timeout from 60s to 300s
   **Status**: ⚠️ PARTIAL - Identifier handling completed, timeout policy needs update

3. **Action**: modify
   **Path**: `scripts/run_real_server_performance.py`
   **Purpose**: Update to use correct identifier separation for queue/polling flows
   **Status**: ✅ COMPLETED

4. **Action**: modify
   **Path**: `scripts/compare_direct_vs_client.py`
   **Purpose**: Update to use adapter-compatible config construction AND increase default timeout from 60s to 300s
   **Status**: ⚠️ PARTIAL - Config construction completed, timeout policy needs update

5. **Action**: modify
   **Path**: `scripts/run_cuda_stress.py`
   **Purpose**: Update to use correct identifier separation for WebSocket completion flows
   **Status**: ⚠️ TIMEOUT - Identifier handling completed, but script times out (server performance issue)

6. **Action**: modify
   **Path**: `scripts/run_timing_statistics.py`
   **Purpose**: Update to use adapter-backed client construction
   **Status**: ⚠️ TIMEOUT - Client construction completed, but script times out (server performance issue)

7. **Action**: modify
   **Path**: `scripts/run_batch_performance.py`
   **Purpose**: Increase default timeout from 120s to 300s to match server performance characteristics
   **Status**: ⚠️ TIMEOUT - Needs timeout policy update

8. **Action**: BLOCKED
   **Path**: `scripts/run_testing_client_performance.py`
   **Purpose**: Blocked on Step 2 - `EmbeddingServiceClient.embed` method structure fix required
   **Status**: 🔒 BLOCKED ON STEP 2

### Files to Read (Reference Only)

1. **Path**: `embed_client/async_client.py`
   **Purpose**: Reference for correct client construction and method signatures

2. **Path**: `embed_client/config.py` or `embed_client/client_factory.py`
   **Purpose**: Reference for correct config construction methods

3. **Path**: `embed_client/adapter_transport.py`
   **Purpose**: Reference for adapter-backed transport behavior

4. **Path**: `docs/tech_spec/tech_spec.md`
   **Purpose**: Reference for identifier model and result mode contracts

## Class/Function Inventory

### Scripts Use These Public Interfaces

1. **Import path**: `embed_client.async_client.EmbeddingServiceAsyncClient`
   **Base class**: None
   **Purpose**: Main async client facade for real-server testing
   **Public methods used by scripts**:
   - `from_config(config: ClientConfig) -> EmbeddingServiceAsyncClient` (class method, context manager)
   - `embed(texts: list[str], model: str | None = None, dimension: int | None = None, error_policy: str | None = None, device: str | None = None, wait: bool = False, timeout: float | None = None, use_push: bool = True, **extra_params: object) -> dict`
   - `submit_job(command: str, params: dict | None = None, timeout: float | None = None) -> str | dict`
   - `job_status(job_id: str) -> dict`
   - `wait_for_job(job_id: str, timeout: float | None = None) -> dict`
   - `wait_for_job_via_websocket(job_id: str, timeout: float | None = None) -> dict`
   - `health() -> dict` (if available)

2. **Import path**: `embed_client.config.ClientConfig`
   **Base class**: None
   **Purpose**: Configuration object for client construction
   **Public methods used by scripts**:
   - `create_mtls_config(host: str, port: int, cert_file: str, key_file: str, ca_cert_file: str) -> ClientConfig` (class method)
   - `__init__(config_path: str)` (constructor)
   - `load_config() -> None`
   - `get(key: str) -> Any` (if available)

3. **Import path**: `embed_client.exceptions.EmbeddingServiceError`
   **Base class**: Exception
   **Purpose**: Base exception for client errors
   **Public methods**: Standard exception methods

4. **Import path**: `embed_client.exceptions.EmbeddingServiceTimeoutError`
   **Base class**: EmbeddingServiceError
   **Purpose**: Timeout exception
   **Public methods**: Standard exception methods

## Data Structures

### Script Configuration Patterns

1. **mTLS Config Construction**:
   - Pattern: `ClientConfig.create_mtls_config(host="localhost", port=8001, cert_file=..., key_file=..., ca_cert_file=...)`
   - Cert paths: `mtls_certificates/client/embedding-service.crt`, `mtls_certificates/client/embedding-service.key`, `mtls_certificates/ca/ca.crt`
   - All paths must be absolute or resolved relative to PROJECT_ROOT

2. **Client Construction Pattern**:
   - Pattern: `async with EmbeddingServiceAsyncClient.from_config(config) as client: ...`
   - Must use context manager for proper resource cleanup

3. **Job Submission Pattern**:
   - Pattern: `result = await client.submit_job("embed_queue", {"texts": [...], "error_policy": "continue"})`
   - Extract `job_id`: `job_id = result.get("job_id")`
   - Must not use JSON-RPC request `id` as job identifier

4. **WebSocket Waiting Pattern**:
   - Pattern: `result = await client.wait_for_job_via_websocket(job_id, timeout=timeout)`
   - Must use `job_id` extracted from `submit_job` result, not JSON-RPC request id

5. **Polling Waiting Pattern**:
   - Pattern: `result = await client.wait_for_job(job_id, timeout=timeout)`
   - Must use `job_id` extracted from `submit_job` result, not JSON-RPC request id

## Import Map

### For Each Script File

1. **scripts/run_real_server_mtls_test.py**:
   - `from embed_client.async_client import EmbeddingServiceAsyncClient`
   - `from embed_client.config import ClientConfig`
   - Standard library: `argparse`, `asyncio`, `sys`, `pathlib.Path`, `typing.Dict`, `typing.Any`

2. **scripts/run_bidirectional_ws_performance.py**:
   - `from embed_client.async_client import EmbeddingServiceAsyncClient`
   - `from embed_client.config import ClientConfig`
   - `from embed_client.exceptions import EmbeddingServiceError, EmbeddingServiceTimeoutError, EmbeddingServiceAPIError`
   - `from embedding_validator import validate_embeddings` (if available)
   - Standard library: `argparse`, `asyncio`, `statistics`, `sys`, `time`, `pathlib.Path`, `typing.List`, `typing.Optional`, `typing.Tuple`

3. **scripts/run_real_server_performance.py**:
   - `from embed_client.async_client import EmbeddingServiceAsyncClient`
   - `from embed_client.config import ClientConfig`
   - `from embed_client.exceptions import EmbeddingServiceError, EmbeddingServiceTimeoutError, EmbeddingServiceAPIError`
   - `from embedding_validator import validate_embeddings` (if available)
   - Standard library: `argparse`, `asyncio`, `json`, `logging`, `sys`, `time`, `pathlib.Path`, `typing.*`

4. **scripts/compare_direct_vs_client.py**:
   - `from embed_client.async_client import EmbeddingServiceAsyncClient`
   - `from embed_client.config import ClientConfig`
   - Standard library: `asyncio`, `sys`, `time`, `pathlib.Path`, `typing.*`

5. **scripts/run_cuda_stress.py**:
   - `from embed_client.async_client import EmbeddingServiceAsyncClient`
   - `from embed_client.config import ClientConfig`
   - `from embedding_validator import extract_embeddings` (if available)
   - Standard library: `argparse`, `asyncio`, `sys`, `time`, `pathlib.Path`, `typing.*`

6. **scripts/run_timing_statistics.py**:
   - `from embed_client.async_client import EmbeddingServiceAsyncClient`
   - `from embed_client.config import ClientConfig`
   - Standard library: `argparse`, `asyncio`, `statistics`, `sys`, `time`, `pathlib.Path`, `typing.*`

## Error Handling Map

### For Script Execution

1. **Config Loading Failure**:
   - **Exception**: `FileNotFoundError` (config file not found)
   - **Condition**: Config file path does not exist
   - **Action**: Script should print error message and exit with non-zero code

2. **Client Construction Failure**:
   - **Exception**: `EmbeddingServiceConfigError` or `EmbeddingServiceConnectionError`
   - **Condition**: Invalid config or connection failure during client construction
   - **Action**: Script should print error message and exit with non-zero code

3. **Job Submission Failure**:
   - **Exception**: `EmbeddingServiceAPIError` or `EmbeddingServiceError`
   - **Condition**: Server rejects job submission or returns error
   - **Action**: Script should report failure and continue or exit based on script logic

4. **Job Waiting Timeout**:
   - **Exception**: `EmbeddingServiceTimeoutError`
   - **Condition**: `wait_for_job` or `wait_for_job_via_websocket` exceeds timeout
   - **Action**: Script should report timeout and continue or exit based on script logic

5. **Missing job_id**:
   - **Condition**: `submit_job` result does not contain `job_id` (immediate result mode)
   - **Action**: Script should handle immediate result mode correctly, not treat as error

## Config Dependency

### Scripts Read These Config Keys

1. **mTLS Certificate Paths**:
   - **Key pattern**: `mtls_certificates/client/embedding-service.crt`, `mtls_certificates/client/embedding-service.key`, `mtls_certificates/ca/ca.crt`
   - **Type**: `str` (file paths)
   - **Default**: Relative to PROJECT_ROOT
   - **Access**: Via `ClientConfig.create_mtls_config()` or config file loading

2. **Server Endpoint**:
   - **Key**: `server.host`, `server.port`
   - **Type**: `str`, `int`
   - **Default**: `localhost`, `8001`
   - **Access**: Via `ClientConfig.create_mtls_config()` or config file

3. **Protocol**:
   - **Key**: `protocol` or `server.protocol`
   - **Type**: `str`
   - **Default**: `mtls`
   - **Access**: Via config construction

## Test Plan

### For Each Script

1. **scripts/run_real_server_mtls_test.py**:
   - **Test**: Execute script with valid mTLS config targeting localhost:8001
   - **Assert**: Script exits with code 0, all test phases (health, embed_wait, embed_fire_and_check) pass
   - **Fixtures**: Real server on localhost:8001 with mTLS, valid certificates in mtls_certificates/

2. **scripts/run_bidirectional_ws_performance.py**:
   - **Test**: Execute script with valid mTLS config
   - **Assert**: Script exits with code 0, reports batch and single performance metrics, WebSocket completion works correctly
   - **Fixtures**: Real server on localhost:8001 with mTLS and WebSocket support, valid certificates

3. **scripts/run_real_server_performance.py**:
   - **Test**: Execute script with valid mTLS config
   - **Assert**: Script exits with code 0, reports performance metrics, queue operations work correctly
   - **Fixtures**: Real server on localhost:8001 with mTLS, valid certificates

4. **scripts/compare_direct_vs_client.py**:
   - **Test**: Execute script with valid mTLS config
   - **Assert**: Script exits with code 0, reports timing comparison
   - **Fixtures**: Real server on localhost:8001 with mTLS, valid certificates

5. **scripts/run_cuda_stress.py**:
   - **Test**: Execute script with valid mTLS config
   - **Assert**: Script exits with code 0, completes all stress test phases
   - **Fixtures**: Real server on localhost:8001 with mTLS and CUDA support, valid certificates

6. **scripts/run_timing_statistics.py**:
   - **Test**: Execute script with valid mTLS config
   - **Assert**: Script exits with code 0, reports timing statistics
   - **Fixtures**: Real server on localhost:8001 with mTLS, valid certificates

## Concrete Examples

### Example: Updated Script Pattern (run_real_server_mtls_test.py)

**Before (if legacy)**:
```python
# Legacy config loading (if exists)
config = load_legacy_config(...)
client = create_client_directly(...)
```

**After (adapter-backed)**:
```python
config = ClientConfig.create_mtls_config(
    host="localhost",
    port=8001,
    cert_file=str(cert_dir / "embedding-service.crt"),
    key_file=str(cert_dir / "embedding-service.key"),
    ca_cert_file=str(ca_dir / "ca.crt"),
)
async with EmbeddingServiceAsyncClient.from_config(config) as client:
    # Use client methods
```

### Example: Correct Identifier Handling (run_bidirectional_ws_performance.py)

**Before (if incorrect)**:
```python
result = await client.submit_job(...)
# WRONG: using JSON-RPC request id
wait_result = await client.wait_for_job_via_websocket(result.get("id"))
```

**After (correct)**:
```python
result = await client.submit_job("embed_queue", {"texts": texts})
job_id = result.get("job_id")  # Extract job_id, not JSON-RPC id
if job_id:
    wait_result = await client.wait_for_job_via_websocket(job_id, timeout=timeout)
else:
    # Handle immediate result mode
    validate_embeddings(result, len(texts))
```

### Example: Correct Result Mode Handling

**Before (if incorrect)**:
```python
result = await client.submit_job(...)
# Assumes always queued, fails if immediate
job_id = result["job_id"]  # KeyError if immediate mode
```

**After (correct)**:
```python
result = await client.submit_job("embed_queue", {"texts": texts})
job_id = result.get("job_id")  # Safe extraction
if job_id:
    # Queued mode: wait for completion
    final_result = await client.wait_for_job_via_websocket(job_id, timeout=timeout)
else:
    # Immediate mode: result is already complete
    validate_embeddings(result, len(texts))
```

## Algorithm Descriptions

### Script Update Algorithm

1. **Identify Script Dependencies**:
   - Read script file
   - Identify imports from `embed_client`
   - Identify client construction patterns
   - Identify config loading patterns
   - Identify job submission and waiting patterns

2. **Update Config Construction**:
   - Replace legacy config loading with `ClientConfig.create_mtls_config()` or `ClientConfig(config_path)` with `load_config()`
   - Ensure certificate paths are resolved relative to PROJECT_ROOT
   - Verify config uses adapter-compatible structure

3. **Update Client Construction**:
   - Replace direct client instantiation with `EmbeddingServiceAsyncClient.from_config(config)`
   - Ensure context manager usage (`async with`)
   - Verify no custom transport/auth logic

4. **Update Identifier Handling**:
   - Find all `submit_job` calls
   - Verify `job_id` extraction uses `result.get("job_id")`, not `result.get("id")` or `result["id"]`
   - Verify all `wait_for_job` and `wait_for_job_via_websocket` calls use extracted `job_id`, not JSON-RPC request id
   - Verify no mixing of identifier types

5. **Update Result Mode Handling**:
   - Find all job submission and waiting patterns
   - Add checks for immediate vs queued mode
   - Handle immediate results correctly (no waiting needed)
   - Handle queued results correctly (extract job_id and wait)

6. **Validate Script Execution**:
   - Execute script with valid mTLS config targeting localhost:8001
   - Verify script completes successfully (exit code 0)
   - Verify script produces expected output
   - Verify script correctly exercises client functionality

## Forbidden Approaches

- Do not use legacy config loading methods that bypass adapter-centric architecture
- Do not use JSON-RPC request `id` as job identifier
- Do not assume all results are queued (must handle immediate mode)
- Do not create custom transport/auth logic in scripts
- Do not bypass adapter-backed client construction
- Do not mix identifier types (JSON-RPC id, job_id, WebSocket correlation)
- Do not hardcode certificate paths without PROJECT_ROOT resolution
