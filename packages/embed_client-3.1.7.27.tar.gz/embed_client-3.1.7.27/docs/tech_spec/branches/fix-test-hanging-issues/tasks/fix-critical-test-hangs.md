Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Fix Critical Test Hanging Issues

## Purpose

Fix critical test hanging issues identified in TEST_SUITE_HANG_ANALYSIS.md by:
1. Adding pytest-xdist and pytest-timeout dependencies
2. Configuring parallel execution and timeout settings
3. Replacing blocking time.sleep() operations with async alternatives
4. Adding timeout to is_service_available() function
5. Replacing blocking subprocess operations with async versions

## Parent Links

- Tech spec: N/A (critical fix, not part of feature branch)
- Parent global step: N/A (standalone critical fix)

## Scope

**Included:**
- Add pytest-xdist and pytest-timeout to pyproject.toml test dependencies
- Add pytest timeout and parallel execution configuration to pytest.ini or pyproject.toml
- Fix blocking time.sleep(2) in test_comprehensive_server.py line 218
- Fix blocking time.sleep(1) infinite loop in test_comprehensive_server.py line 415
- Add timeout to is_service_available() in test_async_client_real_fixtures.py (lines 53-63)
- Replace blocking subprocess.Popen.wait() with async alternatives in:
  - run_all_tests.py line 281
  - run_comprehensive_tests.py line 436
  - test_server_runner.py line 267
- Replace blocking subprocess.Popen.communicate() with async alternatives in:
  - run_all_tests.py line 79
  - test_server_runner.py line 249
- Replace blocking subprocess.Popen with asyncio.create_subprocess_exec in:
  - run_all_tests.py line 61
  - run_comprehensive_tests.py line 187
  - test_server_runner.py line 233

**Excluded:**
- Fixing timeout=0 issues (medium priority, separate task)
- Replacing synchronous file I/O (low priority)
- Refactoring server management (long-term improvement)

## Boundaries

**Must NOT touch:**
- Production code (only test code)
- Test logic (only fix blocking operations)
- Other test files not listed above

## Dependencies

None - standalone critical fix

## Parallelization Note

All fixes can be applied in parallel as they affect different files.

## Expected Outcome

1. All blocking operations replaced with async alternatives
2. pytest-xdist and pytest-timeout added to dependencies
3. Timeout configuration added to pytest.ini or pyproject.toml
4. All identified blocking operations fixed
5. Tests can run without hanging the event loop

## File Inventory

1. **Action**: modify
   **Path**: `pyproject.toml`
   **Purpose**: Add pytest-xdist and pytest-timeout to test dependencies

2. **Action**: modify
   **Path**: `pytest.ini` or `pyproject.toml`
   **Purpose**: Add timeout and parallel execution configuration

3. **Action**: modify
   **Path**: `tests/test_comprehensive_server.py`
   **Purpose**: Replace blocking time.sleep() with async alternatives (lines 218, 415)

4. **Action**: modify
   **Path**: `tests/test_async_client_real_fixtures.py`
   **Purpose**: Add timeout to is_service_available() function (lines 53-63)

5. **Action**: modify
   **Path**: `tests/run_all_tests.py`
   **Purpose**: Replace blocking subprocess operations with async versions (lines 61, 79, 281)

6. **Action**: modify
   **Path**: `tests/run_comprehensive_tests.py`
   **Purpose**: Replace blocking subprocess operations with async versions (lines 187, 436)

7. **Action**: modify
   **Path**: `tests/test_server_runner.py`
   **Purpose**: Replace blocking subprocess operations with async versions (lines 233, 249, 267)

## Class/Function Inventory

No new classes or functions needed. Only modifications to existing code.

## Import Map

Files will need these imports:
- `asyncio` (for async subprocess and sleep)
- `asyncio.subprocess` (for async subprocess operations)

## Error Handling Map

- Subprocess operations: Handle subprocess errors gracefully, log failures
- Timeout operations: Handle asyncio.TimeoutError appropriately
- Thread operations: Maintain existing error handling for thread.join()

## Config Dependency

- pytest timeout: Configure in pytest.ini or pyproject.toml
- pytest parallel: Configure with pytest-xdist

## Test Plan

After fixes:
1. Run pytest to verify no hanging
2. Run tests with pytest-xdist to verify parallel execution works
3. Verify timeout configuration works
4. Check that all blocking operations are replaced

## Concrete Examples

### Example 1: Replace time.sleep(2) with asyncio.sleep(2)
```python
# Before (BLOCKING):
time.sleep(2)

# After (ASYNC):
await asyncio.sleep(2)
```

### Example 2: Replace subprocess.Popen with async version
```python
# Before (BLOCKING):
process = subprocess.Popen([...], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
await asyncio.sleep(1)
if process.poll() is None:
    ...

# After (ASYNC):
process = await asyncio.create_subprocess_exec(
    ...,
    stdout=asyncio.subprocess.PIPE,
    stderr=asyncio.subprocess.PIPE
)
await asyncio.sleep(1)
if process.returncode is None:
    ...
```

### Example 3: Replace process.wait() with async version
```python
# Before (BLOCKING):
process.wait(timeout=5)

# After (ASYNC):
try:
    await asyncio.wait_for(process.wait(), timeout=5.0)
except asyncio.TimeoutError:
    process.kill()
    await process.wait()
```

### Example 4: Add timeout to is_service_available()
```python
# Before:
async def is_service_available(security_mode="http"):
    config = TEST_CONFIGS[security_mode]
    try:
        async with EmbeddingServiceAsyncClient(config_dict=config["config_dict"]) as client:
            await client.health()
        return True
    except Exception:
        return False

# After:
async def is_service_available(security_mode="http", timeout: float = 5.0):
    config = TEST_CONFIGS[security_mode]
    try:
        async with EmbeddingServiceAsyncClient(config_dict=config["config_dict"]) as client:
            await asyncio.wait_for(client.health(), timeout=timeout)
        return True
    except (Exception, asyncio.TimeoutError):
        return False
```

## Algorithm/Logic Description

### Fix 1: Add dependencies
1. Open pyproject.toml
2. Add "pytest-xdist" and "pytest-timeout" to [project.optional-dependencies.test]
3. Add "pytest-xdist" and "pytest-timeout" to [project.optional-dependencies.dev]

### Fix 2: Add pytest configuration
1. Open pytest.ini or pyproject.toml
2. Add timeout configuration: `timeout = 300` (5 minutes default)
3. Add timeout method: `timeout_method = thread`
4. Optionally add parallel configuration note (pytest-xdist is installed but not auto-enabled)

### Fix 3: Fix time.sleep() in test_comprehensive_server.py
1. Line 218: Replace `time.sleep(2)` with `await asyncio.sleep(2)` (ensure function is async)
2. Line 415: Replace `time.sleep(1)` in infinite loop with `await asyncio.sleep(1)` (ensure function is async)

### Fix 4: Add timeout to is_service_available()
1. Add timeout parameter with default 5.0 seconds
2. Wrap client.health() call with asyncio.wait_for()
3. Catch asyncio.TimeoutError in exception handler

### Fix 5: Replace subprocess operations
For each file (run_all_tests.py, run_comprehensive_tests.py, test_server_runner.py):
1. Replace subprocess.Popen with asyncio.create_subprocess_exec
2. Replace process.poll() with process.returncode check
3. Replace process.wait(timeout=X) with await asyncio.wait_for(process.wait(), timeout=X)
4. Replace process.communicate() with await process.communicate()
5. Ensure all functions using these are async

## Forbidden Approaches

1. DO NOT use blocking operations in async functions
2. DO NOT remove error handling when converting to async
3. DO NOT change test logic, only fix blocking operations
4. DO NOT use time.sleep() in async context
5. DO NOT use subprocess.Popen in async context without async alternatives

## Questions/Escalation Rule

- If pytest configuration conflicts with existing setup, escalate
- If async conversion breaks test logic, escalate
- If subprocess conversion requires significant refactoring, escalate
