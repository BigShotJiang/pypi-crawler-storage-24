Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Embed Command Contract Alignment

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-command-contract-alignment.md`

## Atomic Summary

**Goal**: Align public `embed()` methods in `AsyncClientAPIMixin` and `EmbeddingServiceClient` with canonical server command contract by adding parameter validation and ensuring canonical params building.

**Number of atomic steps**: 2

**Dependency order**: No dependencies between steps (can run in parallel)

**Atomic waves**: Both steps in Wave 1 (parallel execution)

## Atomic Step Index

### Step 1: Validate and Align AsyncClientAPIMixin.embed()

**Step ID**: `validate-and-align-async-client-api-mixin-embed`

**File**: `docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-command-contract-alignment/steps/validate-and-align-async-client-api-mixin-embed.md`

**Target file**: `embed_client/async_client_api_mixin.py`

**Purpose**: Add parameter validation and verify canonical contract alignment for `AsyncClientAPIMixin.embed()` method

**Dependencies**: None

**Status**: Ready for execution

### Step 2: Validate and Align EmbeddingServiceClient.embed()

**Step ID**: `validate-and-align-testing-client-embed`

**File**: `docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-command-contract-alignment/steps/validate-and-align-testing-client-embed.md`

**Target file**: `embed_client/testing_client.py`

**Purpose**: Add parameter validation and verify canonical contract alignment for `EmbeddingServiceClient.embed()` method

**Dependencies**: None

**Status**: Ready for execution

## Execution Order

Both steps can be executed in parallel (Wave 1) since they modify different files and have no dependencies.
