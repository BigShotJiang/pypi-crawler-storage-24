Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Extract Job ID from Adapter Response

## Executor Role

**Executor**: `coder_auto`  
**Role**: Implement function to extract job_id from adapter/server response for queued mode detection.

## Execution Directive

Update the `_extract_job_id_from_response()` function in `embed_client/async_client_api_mixin.py` to correctly handle adapter response format with `mode="queued"` and job_id at various nesting levels.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling.md`

## Step Scope

**Target file**: `embed_client/async_client_api_mixin.py`  
**Action**: modify  
**Function to modify**: `_extract_job_id_from_response()` (lines 30-50)

## Dependency Contract

- **Depends on**: None (this is the first step in the sequence)
- **Required by**: `async-client-api-mixin-embed-result-handling.md` (uses this function)
- **Can run in parallel with**: None (must complete before result handling step)

## Required Context

The adapter may return responses in these formats:

1. **Adapter queued format (top-level)**:
   ```python
   {"mode": "queued", "job_id": "job-123", "status": "pending", "result": {...}}
   ```

2. **Adapter queued format (nested in result)**:
   ```python
   {"mode": "queued", "result": {"job_id": "job-123", "status": "pending"}}
   ```

3. **Server response format (nested in result.data)**:
   ```python
   {"result": {"data": {"job_id": "job-123", "status": "pending"}}}
   ```

4. **Alternative server format (top-level data)**:
   ```python
   {"data": {"job_id": "job-123", "status": "pending"}}
   ```

The function must check all these locations and return the first non-empty string job_id found, or `None` if no job_id is present.

## Read First

Before starting implementation, read these files:

1. `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` (lines 30-50) - current implementation
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling.md` - tactical task specification
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - tech spec for context

## Expected File Change

**File**: `embed_client/async_client_api_mixin.py`

**Function signature** (keep unchanged):
```python
def _extract_job_id_from_response(result: Dict[str, Any]) -> Optional[str]:
```

**Function docstring** (update to reflect adapter format support):
```python
"""
Extract job_id from adapter/server response to detect queued mode.

Checks multiple locations in the response:
- Top-level job_id (adapter format: {"mode": "queued", "job_id": "..."})
- Nested in result: result.get("job_id")
- Nested in result.data: result.get("result", {}).get("data", {}).get("job_id")
- Top-level data: result.get("data", {}).get("job_id")

Args:
    result: Response dictionary from adapter or server

Returns:
    First non-empty string job_id found, or None if no job_id present
"""
```

**Function implementation** (replace lines 30-50):

The function must:
1. Check if `result` is a dict, return `None` if not
2. Check `result.get("job_id")` - if it's a non-empty string, return it (strip whitespace)
3. Check `result.get("result", {}).get("job_id")` - if it's a non-empty string, return it (strip whitespace)
4. Check `result.get("result", {}).get("data", {}).get("job_id")` - if it's a non-empty string, return it (strip whitespace)
5. Check `result.get("data", {}).get("job_id")` - if it's a non-empty string, return it (strip whitespace)
6. Return `None` if no job_id found in any location

**Exact algorithm**:
1. If `not isinstance(result, dict)`: return `None`
2. Check `result.get("job_id")`:
   - If it's a string and `result.get("job_id").strip()` is non-empty: return `result.get("job_id").strip()`
3. Check `result.get("result", {})`:
   - If it's a dict:
     - Check `result.get("result", {}).get("job_id")`:
       - If it's a string and `.strip()` is non-empty: return `.strip()`
     - Check `result.get("result", {}).get("data", {})`:
       - If it's a dict:
         - Check `result.get("result", {}).get("data", {}).get("job_id")`:
           - If it's a string and `.strip()` is non-empty: return `.strip()`
4. Check `result.get("data", {})`:
   - If it's a dict:
     - Check `result.get("data", {}).get("job_id")`:
       - If it's a string and `.strip()` is non-empty: return `.strip()`
5. Return `None`

## Forbidden Alternatives

- **DO NOT** check `result.get("mode")` to determine queued mode - job_id presence is the indicator
- **DO NOT** return empty strings - return `None` if no job_id found
- **DO NOT** modify any other functions or methods in this step
- **DO NOT** change function signature or return type
- **DO NOT** add logging or other side effects
- **DO NOT** use `Any` type annotation - use `Dict[str, Any]` and `Optional[str]`

## Atomic Operations

1. Read current `_extract_job_id_from_response()` implementation (lines 30-50)
2. Replace function body with new implementation that checks all four locations
3. Update function docstring to document all checked locations
4. Ensure function handles all edge cases (non-dict input, missing keys, empty strings)

## Expected Deliverables

- Updated `_extract_job_id_from_response()` function in `embed_client/async_client_api_mixin.py`
- Function correctly extracts job_id from all adapter response formats
- Function returns `None` when no job_id is present
- Function strips whitespace from job_id strings before returning

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Code formatting**:
   ```bash
   black embed_client/async_client_api_mixin.py
   ```
   **Expected**: "reformatted" or "already well formatted" (exit code 0)

2. **Linting**:
   ```bash
   flake8 embed_client/async_client_api_mixin.py
   ```
   **Expected**: No output (exit code 0)

3. **Type checking**:
   ```bash
   mypy embed_client/async_client_api_mixin.py
   ```
   **Expected**: "Success: no issues found" (exit code 0)

4. **Tests** (if test file exists or is created in a separate step):
   ```bash
   pytest tests/test_embed_result_mode_handling.py::test_extract_job_id_from_adapter_response -v
   ```
   **Expected**: All test cases pass

## Decision Rules

- **Job ID extraction order**: Check top-level first, then nested locations (matches adapter format priority)
- **Empty string handling**: Treat empty or whitespace-only strings as "no job_id" (return `None`)
- **Type safety**: Always check `isinstance(candidate, str)` before calling `.strip()`
- **Dict safety**: Use `.get()` with defaults to avoid KeyError

## Blackstops

**STOP and escalate** if:
- Adapter response format changes require checking additional locations not listed in this step
- Function signature must change (breaks existing callers)
- Return type must change from `Optional[str]` to something else

## Handoff Package

**For coder_auto**:

1. **Target file**: `embed_client/async_client_api_mixin.py`
2. **Function to modify**: `_extract_job_id_from_response()` (lines 30-50)
3. **Imports** (already present, no changes needed):
   - `from typing import Any, Dict, Optional`
4. **Function signature** (keep unchanged):
   ```python
   def _extract_job_id_from_response(result: Dict[str, Any]) -> Optional[str]:
   ```
5. **Implementation requirements**:
   - Check 4 locations in order: top-level job_id, result.job_id, result.data.job_id, data.job_id
   - Return first non-empty string found (strip whitespace)
   - Return `None` if no job_id found
   - Handle non-dict input by returning `None`
6. **Edge cases**:
   - Non-dict input → return `None`
   - Missing keys → use `.get()` with defaults, continue checking
   - Empty or whitespace-only strings → treat as "no job_id", return `None`
   - Nested dicts that are not dicts → use `.get()` safely, continue checking
7. **Validation commands**: See "Mandatory Validation" section above
8. **Completion condition**: All validation commands pass, function extracts job_id from all adapter formats

## Constants and Literals

- No constants or literals used in this function
- All values come from the `result` parameter dictionary
