Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Embed Result Mode Handling

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling.md`

## Goal

Ensure the client correctly handles both immediate JSON-RPC results and queued job results for embed operations. The client must normalize both modes to a stable public response format without hiding server semantics or reimplementing transport behavior.

## Atomic Steps

### Step 1: Extract Job ID from Adapter Response

**File**: `extract-job-id-from-adapter-response.md`  
**Target file**: `embed_client/async_client_api_mixin.py`  
**Function**: `_extract_job_id_from_response()`  
**Dependencies**: None (first step)  
**Status**: Ready for implementation

**Purpose**: Update `_extract_job_id_from_response()` function to correctly handle adapter response format with `mode="queued"` and job_id at various nesting levels.

### Step 2: AsyncClientAPIMixin.embed() Result Handling

**File**: `async-client-api-mixin-embed-result-handling.md`  
**Target file**: `embed_client/async_client_api_mixin.py`  
**Method**: `AsyncClientAPIMixin.embed()` - result handling section  
**Dependencies**: Step 1 (uses `_extract_job_id_from_response()`)  
**Status**: Ready for implementation

**Purpose**: Update result handling section in `embed()` method to correctly detect and handle immediate vs queued result modes from adapter responses.

### Step 3: EmbeddingServiceClient.embed() Result Handling

**File**: `testing-client-embed-result-handling.md`  
**Target file**: `embed_client/testing_client.py`  
**Method**: `EmbeddingServiceClient.embed()` - result handling section  
**Dependencies**: Step 1 (may use similar job_id extraction logic)  
**Status**: Ready for implementation

**Purpose**: Update result handling in `embed()` method to correctly detect and handle immediate vs queued result modes from adapter/server responses.

## Dependency Graph

```
Step 1: extract-job-id-from-adapter-response
  │
  ├─> Step 2: async-client-api-mixin-embed-result-handling
  │
  └─> Step 3: testing-client-embed-result-handling
```

## Execution Order

1. **Wave 1** (serial): Step 1 must complete first
2. **Wave 2** (parallel): Steps 2 and 3 can run in parallel after Step 1 completes

## Completion Criteria

All atomic steps are complete when:
- Step 1: `_extract_job_id_from_response()` correctly extracts job_id from all adapter response formats
- Step 2: `AsyncClientAPIMixin.embed()` correctly handles both immediate and queued modes
- Step 3: `EmbeddingServiceClient.embed()` correctly handles both immediate and queued modes
- All validation commands pass (black, flake8, mypy, pytest)
- All tests pass
