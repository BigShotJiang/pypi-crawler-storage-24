Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Models and Timing Stats Command Alignment

## Purpose

Ensure the `models` and `timing_stats` public client methods align with the server command contract. These commands are introspection/utility commands that should use the adapter transport layer without reimplementing transport semantics.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`

## Scope

### Included

- `embed_client/async_client_api_mixin.py` - `models()` and `timing_stats()` methods
- `embed_client/testing_client.py` - `models()` and `timing_stats()` methods (if present)
- Parameter validation and request building for these commands
- Result normalization for command responses

### Excluded

- Embed command implementation (covered in other tactical tasks)
- Queue/WebSocket handling (these commands are typically immediate)
- Response normalizer implementation details (only usage)

## Boundaries

This task must NOT touch:
- `embed_client/adapter_transport.py` - adapter transport layer (only uses existing methods)
- Embed command logic
- Queue handling logic

## Dependencies

- None (can run in parallel with other tactical tasks)

## Parallelization Note

This tactical task can run in parallel with:
- `embed-command-contract-alignment.md`
- `embed-result-mode-handling.md`
- `embed-job-status-alignment.md`

## Expected Outcome

1. `models()` method correctly calls `models` command via adapter transport
2. `timing_stats()` method correctly calls `timing_stats` command with optional `file_path` parameter
3. Both methods normalize server responses to stable public formats
4. Parameter validation ensures correct types (file_path is string or None)
5. Both `AsyncClientAPIMixin` and `EmbeddingServiceClient` (if present) implement these methods correctly

## Correction Items

### Current Implementation Issues

1. **File**: `embed_client/async_client_api_mixin.py`, method `models()` (lines 272-284)
   - **Issue**: May not normalize response correctly for all server response shapes
   - **Correction**: Ensure normalization handles: `{"result": {"models": [...]}}` and `{"result": {"data": {"models": [...]}}}`
   - **Verification**: Test with different server response formats

2. **File**: `embed_client/async_client_api_mixin.py`, method `timing_stats()` (lines 286-312)
   - **Issue**: May not normalize response correctly
   - **Correction**: Ensure normalization handles various response shapes
   - **Verification**: Test with different server response formats

3. **File**: `embed_client/testing_client.py`, method `models()` (if present, lines 503+)
   - **Issue**: May not align with canonical command contract
   - **Correction**: Ensure it uses `models` command correctly
   - **Verification**: Test method signature and implementation

## Questions/Escalation Rule

Escalate to global orchestrator if:
- Server command contract changes require breaking public API changes
- Response format changes require global normalization changes

## File Inventory

### Files to Modify

1. **Action**: modify
   **Path**: `embed_client/async_client_api_mixin.py`
   **Purpose**: Align `models()` and `timing_stats()` methods with server contract

2. **Action**: modify (if method exists)
   **Path**: `embed_client/testing_client.py`
   **Purpose**: Align `models()` and `timing_stats()` methods with server contract

### Files to Read (Reference Only)

1. **Path**: `/home/vasilyvz/projects/embed/embed/commands/models_command.py`
   **Purpose**: Verify server `models` command contract (if accessible)

2. **Path**: `embed_client/adapter_transport.py`
   **Purpose**: Understand how `cmd()` or `execute_command_unified()` works

## Class/Function Inventory

### Class: `AsyncClientAPIMixin`

**Public methods to modify**:

1. **Method**: `models() -> Dict[str, Any]`
   **Current behavior**: Calls `self.cmd("models")`, normalizes response
   **New behavior**:
   - Call `self.cmd("models")` (which uses adapter transport)
   - Normalize response to: `{"models": [...]}` where models list contains model info dicts
   - Handle response shapes: `{"result": {"models": [...]}}`, `{"result": {"data": {"models": [...]}}}`, `{"result": [...]}` (direct list)

2. **Method**: `timing_stats(file_path: Optional[str] = None) -> Dict[str, Any]`
   **Current behavior**: Calls `self.cmd("timing_stats", params={"file_path": file_path})` if file_path provided
   **New behavior**:
   - Validate `file_path` is string or None
   - Build params: `{"file_path": file_path.strip()}` if file_path is not None and not empty, else `{}`
   - Call `self.cmd("timing_stats", params=params or None)`
   - Normalize response to dict with timing statistics keys: `total_requests`, `success_count`, `encode_seconds`, `rpc_seconds`, `by_device`, `batch_vs_single`, etc.

### Class: `EmbeddingServiceClient`

**Public methods to modify** (if methods exist):

1. **Method**: `models() -> Dict[str, Any]`
   **Behavior**: Same as `AsyncClientAPIMixin.models()`

2. **Method**: `timing_stats(file_path: Optional[str] = None) -> Dict[str, Any]`
   **Behavior**: Same as `AsyncClientAPIMixin.timing_stats()`

## Data Structures

### Models Response Format

**Server response** (various shapes):
```python
# Shape 1
{
    "result": {
        "models": [
            {
                "name": str,
                "dimension": int,
                "supported_dimensions": List[int],
                "max_tokens": int,
                ...
            },
            ...
        ]
    }
}

# Shape 2
{
    "result": {
        "data": {
            "models": [...]
        }
    }
}

# Shape 3
{
    "result": [...]
}
```

**Normalized public format**:
```python
{
    "models": [
        {
            "name": str,
            "dimension": int,
            "supported_dimensions": List[int],
            "max_tokens": int,
            ...
        },
        ...
    ]
}
```

### Timing Stats Response Format

**Server response** (various shapes):
```python
# Shape 1
{
    "result": {
        "total_requests": int,
        "success_count": int,
        "encode_seconds": float,
        "rpc_seconds": float,
        "by_device": Dict[str, Any],
        "batch_vs_single": Dict[str, Any],
        "calculation_time_seconds": float,
        ...
    }
}

# Shape 2
{
    "result": {
        "data": {
            "total_requests": int,
            ...
        }
    }
}
```

**Normalized public format**:
```python
{
    "total_requests": int,
    "success_count": int,
    "encode_seconds": float,
    "rpc_seconds": float,
    "by_device": Dict[str, Any],
    "batch_vs_single": Dict[str, Any],
    "calculation_time_seconds": float,
    ...
}
```

## Import Map

### File: `embed_client/async_client_api_mixin.py`

**Existing imports** (keep):
```python
from typing import Any, Dict, Optional
```

**No additional imports needed**

### File: `embed_client/testing_client.py`

**Existing imports** (keep):
```python
from typing import Any, Dict, Optional
```

**No additional imports needed**

## Error Handling Map

### Method: `AsyncClientAPIMixin.models()`

1. **Adapter transport errors**:
   - **Exception**: `EmbeddingServiceAPIError` or `EmbeddingServiceError` (from `cmd()`)
   - **Condition**: Adapter transport fails or server returns error
   - **Message**: Adapter/server error message
   - **Caller action**: Check server connectivity and command availability

2. **Response normalization errors**:
   - **Exception**: `EmbeddingServiceAPIError` or `ValueError`
   - **Condition**: Response format is unexpected and cannot be normalized
   - **Message**: "Failed to extract models from response"
   - **Caller action**: Check server response format or report bug

### Method: `AsyncClientAPIMixin.timing_stats()`

1. **Parameter validation errors**:
   - **Exception**: `ValueError`
   - **Condition**: `file_path` is not None and not a string
   - **Message**: "file_path must be a string or None"
   - **Caller action**: Fix parameter type

2. **Adapter transport errors**:
   - **Exception**: `EmbeddingServiceAPIError` or `EmbeddingServiceError` (from `cmd()`)
   - **Condition**: Adapter transport fails or server returns error
   - **Message**: Adapter/server error message
   - **Caller action**: Check server connectivity, timing_registration enabled, and file_path validity

3. **Response normalization errors**:
   - **Exception**: `EmbeddingServiceAPIError` or `ValueError`
   - **Condition**: Response format is unexpected
   - **Message**: "Failed to extract timing statistics from response"
   - **Caller action**: Check server response format

## Config Dependency

### Config Keys Used

1. **Key**: `file_path` (method parameter, not config)
   - **Type**: `Optional[str]`
   - **Default**: `None` (server uses config default)
   - **Valid values**: Non-empty string (file path on server), or `None`
   - **Access location**: Method parameter in `timing_stats()`

## Test Plan

### Test File: `tests/test_models_timing_stats_alignment.py`

**Test class**: `TestModelsTimingStatsAlignment`

**Test methods**:

1. **Test**: `test_models_command_calls_adapter()`
   - **Setup**: Mock `self.cmd()` method
   - **Action**: Call `models()`
   - **Assert**: `cmd()` called with `command="models"`, `params=None`

2. **Test**: `test_models_normalizes_response_shapes()`
   - **Test cases**:
     - `{"result": {"models": [...]}}` → returns `{"models": [...]}`
     - `{"result": {"data": {"models": [...]}}}` → returns `{"models": [...]}`
     - `{"result": [...]}` → returns `{"models": [...]}`
   - **Assert**: All shapes normalized correctly

3. **Test**: `test_timing_stats_without_file_path()`
   - **Setup**: Mock `self.cmd()` method
   - **Action**: Call `timing_stats()`
   - **Assert**: `cmd()` called with `command="timing_stats"`, `params=None` or `params={}`

4. **Test**: `test_timing_stats_with_file_path()`
   - **Setup**: Mock `self.cmd()` method
   - **Action**: Call `timing_stats(file_path="/path/to/file.jsonl")`
   - **Assert**: `cmd()` called with `command="timing_stats"`, `params={"file_path": "/path/to/file.jsonl"}`

5. **Test**: `test_timing_stats_normalizes_response()`
   - **Setup**: Mock `cmd()` to return timing stats response
   - **Mock response**: `{"result": {"total_requests": 100, "success_count": 95, ...}}`
   - **Action**: Call `timing_stats()`
   - **Assert**: Returns normalized dict with `total_requests`, `success_count`, etc.

6. **Test**: `test_timing_stats_validates_file_path()`
   - **Test cases**:
     - `timing_stats(file_path=123)` → raises `ValueError` or `TypeError`
     - `timing_stats(file_path="")` → may strip or handle empty string
     - `timing_stats(file_path="  /path  ")` → strips whitespace: `"/path"`

7. **Test**: `test_testing_client_models_timing_stats()`
   - **Setup**: Mock `_transport` for `EmbeddingServiceClient`
   - **Test cases**: `models()`, `timing_stats()`, `timing_stats(file_path="...")`
   - **Assert**: All methods call correct commands and normalize responses

**Required fixtures/mocks**:
- Mock `self.cmd()` method for `AsyncClientAPIMixin` tests
- Mock `_transport` for `EmbeddingServiceClient` tests

## Concrete Examples

### Example 1: Models Command

**Input**:
```python
await client.models()
```

**Adapter call** (via `cmd()`):
```python
await adapter_transport.execute_command_unified(
    command="models",
    params=None,
    use_cmd_endpoint=False,
    auto_poll=False
)
```

**Server response**:
```python
{
    "result": {
        "models": [
            {
                "name": "sentence-transformers/all-MiniLM-L6-v2",
                "dimension": 384,
                "supported_dimensions": [384],
                "max_tokens": 256
            },
            {
                "name": "custom-model",
                "dimension": 512,
                "supported_dimensions": [512, 256],
                "max_tokens": 512
            }
        ]
    }
}
```

**Expected public return**:
```python
{
    "models": [
        {
            "name": "sentence-transformers/all-MiniLM-L6-v2",
            "dimension": 384,
            "supported_dimensions": [384],
            "max_tokens": 256
        },
        {
            "name": "custom-model",
            "dimension": 512,
            "supported_dimensions": [512, 256],
            "max_tokens": 512
        }
    ]
}
```

### Example 2: Timing Stats Without File Path

**Input**:
```python
await client.timing_stats()
```

**Adapter call**:
```python
await adapter_transport.execute_command_unified(
    command="timing_stats",
    params={},
    use_cmd_endpoint=False,
    auto_poll=False
)
```

**Server response**:
```python
{
    "result": {
        "total_requests": 1000,
        "success_count": 995,
        "encode_seconds": 45.2,
        "rpc_seconds": 12.3,
        "by_device": {"cpu": 500, "cuda:0": 500},
        "batch_vs_single": {"batch": 800, "single": 200},
        "calculation_time_seconds": 0.05
    }
}
```

**Expected public return**:
```python
{
    "total_requests": 1000,
    "success_count": 995,
    "encode_seconds": 45.2,
    "rpc_seconds": 12.3,
    "by_device": {"cpu": 500, "cuda:0": 500},
    "batch_vs_single": {"batch": 800, "single": 200},
    "calculation_time_seconds": 0.05
}
```

### Example 3: Timing Stats With File Path

**Input**:
```python
await client.timing_stats(file_path="/server/path/timings.jsonl")
```

**Adapter call**:
```python
await adapter_transport.execute_command_unified(
    command="timing_stats",
    params={"file_path": "/server/path/timings.jsonl"},
    use_cmd_endpoint=False,
    auto_poll=False
)
```

**Server response**: Same format as Example 2

**Expected public return**: Same format as Example 2

## Algorithm/Logic Description

### Method: `AsyncClientAPIMixin.models() -> Dict[str, Any]`

1. **Call adapter transport**:
   - `result = await self.cmd("models")`
   - Note: `cmd()` internally calls `_adapter_transport.execute_command_unified()`

2. **Extract models from response**:
   - Check `result.get("result", {})` for `"models"` key
   - If found: `models_list = result["result"]["models"]`
   - Else check `result.get("result", {}).get("data", {})` for `"models"` key
   - If found: `models_list = result["result"]["data"]["models"]`
   - Else check if `result.get("result")` is a list directly
   - If found: `models_list = result["result"]`
   - Else: `models_list = []`

3. **Return normalized format**:
   - Return `{"models": models_list}`

### Method: `AsyncClientAPIMixin.timing_stats(file_path: Optional[str] = None) -> Dict[str, Any]`

1. **Validate file_path parameter**:
   - If `file_path is not None` and not `isinstance(file_path, str)`: raise `ValueError("file_path must be a string or None")`

2. **Build params dict**:
   - If `file_path is not None and file_path.strip()`: `params = {"file_path": file_path.strip()}`
   - Else: `params = {}`

3. **Call adapter transport**:
   - `result = await self.cmd("timing_stats", params=params or None)`

4. **Extract timing stats from response**:
   - Check `result.get("result", {})` for timing stats keys (`total_requests`, `success_count`, etc.)
   - If found: `stats = result["result"]`
   - Else check `result.get("result", {}).get("data", {})`
   - If found: `stats = result["result"]["data"]`
   - Else: `stats = result.get("result", {})` if it's a dict, else `{}`

5. **Return normalized format**:
   - Return `stats` dict directly (already in correct format)

### Method: `EmbeddingServiceClient.models()` (if exists)

1. **Call adapter transport**:
   - Use `_transport.execute_command_unified(command="models", params=None, ...)`

2. **Normalize response**:
   - Same logic as `AsyncClientAPIMixin.models()`

3. **Return normalized format**:
   - Return `{"models": [...]}`

### Method: `EmbeddingServiceClient.timing_stats(file_path: Optional[str] = None)` (if exists)

1. **Validate and build params**:
   - Same as `AsyncClientAPIMixin.timing_stats()`

2. **Call adapter transport**:
   - Use `_transport.execute_command_unified(command="timing_stats", params=params, ...)`

3. **Normalize response**:
   - Same logic as `AsyncClientAPIMixin.timing_stats()`

4. **Return normalized format**:
   - Return timing stats dict

## Forbidden Approaches

1. **DO NOT** reimplement transport semantics - use `cmd()` or `execute_command_unified()` via adapter
2. **DO NOT** assume response format - handle multiple server response shapes
3. **DO NOT** skip parameter validation - validate `file_path` type
4. **DO NOT** modify adapter transport layer - only use existing methods
5. **DO NOT** hardcode response structure - normalize flexibly
6. **DO NOT** implement queue/WebSocket logic for these commands - they are typically immediate
