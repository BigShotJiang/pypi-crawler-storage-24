Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Embed Job Status Command Alignment

## Purpose

Ensure the client correctly uses the `embed_job_status` command for embed-specific job status queries, while maintaining compatibility with the generic `queue_get_job_status` command. The client must use the appropriate endpoint based on job type without reimplementing transport semantics.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`

## Scope

### Included

- `embed_client/adapter_transport.py` - `queue_get_job_status()` method and job status handling
- `embed_client/async_client_queue_mixin.py` - `get_job_status_or_result()` and `wait_for_job()` methods
- `embed_client/testing_client.py` - job status methods
- Command selection logic: when to use `embed_job_status` vs `queue_get_job_status`
- Result normalization for job status responses

### Excluded

- Queue submission logic (uses existing methods)
- WebSocket waiting logic (uses existing methods, only job status polling)
- Identifier model separation (covered in Step 3)
- Embed command implementation (covered in `embed-command-contract-alignment.md`)

## Boundaries

This task must NOT touch:
- Adapter transport core (`execute_command_unified` implementation)
- WebSocket correlation logic (Step 3 responsibility)
- Queue submission endpoints

## Dependencies

- None (can run in parallel with other tactical tasks)

## Parallelization Note

This tactical task can run in parallel with:
- `embed-command-contract-alignment.md`
- `embed-result-mode-handling.md`
- `models-timing-stats-alignment.md`

## Expected Outcome

1. Client uses `embed_job_status` command for embed job status queries when job type is known to be embed
2. Client falls back to `queue_get_job_status` for generic queue jobs or when job type is unknown
3. `AdapterTransport.queue_get_job_status()` correctly selects endpoint or delegates to adapter
4. Job status result normalization handles both `embed_job_status` and `queue_get_job_status` response formats
5. Public API methods (`get_job_status_or_result()`, `wait_for_job()`) work correctly with both endpoints

## Correction Items

### Current Implementation Issues

1. **File**: `embed_client/adapter_transport.py`, method `queue_get_job_status()` (lines 274-300)
   - **Issue**: Always uses `queue_get_job_status` endpoint, may not use `embed_job_status` for embed jobs
   - **Correction**: Check if adapter's `execute_command_unified` handles endpoint selection automatically, or add logic to use `embed_job_status` when job type is known
   - **Verification**: Test with embed job_id - should use `embed_job_status` if adapter supports it

2. **File**: `embed_client/testing_client.py`, method `job_status()` (lines 473-492)
   - **Issue**: Tries `queue_get_job_status` first, then falls back to `embed_job_status`
   - **Correction**: Ensure this fallback logic is correct and handles both response formats
   - **Verification**: Test both endpoints return correctly normalized results

3. **File**: `embed_client/async_client_queue_mixin.py`, method `get_job_status_or_result()` (lines 376-435)
   - **Issue**: May not use `embed_job_status` for embed jobs
   - **Correction**: Ensure it uses appropriate endpoint based on job context
   - **Verification**: Test with embed job_id

## Questions/Escalation Rule

Escalate to global orchestrator if:
- Adapter's `execute_command_unified` already handles endpoint selection automatically (may not need changes)
- Server contract changes require breaking changes to public API
- Endpoint selection logic conflicts with identifier separation (Step 3)

## File Inventory

### Files to Modify

1. **Action**: modify
   **Path**: `embed_client/adapter_transport.py`
   **Purpose**: Ensure `queue_get_job_status()` uses correct endpoint or delegates correctly

2. **Action**: modify
   **Path**: `embed_client/async_client_queue_mixin.py`
   **Purpose**: Ensure job status methods use `embed_job_status` when appropriate

3. **Action**: modify
   **Path**: `embed_client/testing_client.py`
   **Purpose**: Ensure `job_status()` method uses correct endpoint selection

### Files to Read (Reference Only)

1. **Path**: `embed_client/adapter_transport.py`
   **Purpose**: Understand how `execute_command_unified` handles command selection

2. **Path**: `/home/vasilyvz/projects/embed/embed/commands/embed_job_status_command.py`
   **Purpose**: Verify server `embed_job_status` command contract (if accessible)

3. **Path**: `ADAPTER_QUEUE_GET_JOB_STATUS_BUG.md` or `BUG_ANALYSIS.md`
   **Purpose**: Understand historical issues with endpoint selection

## Class/Function Inventory

### Class: `AdapterTransport`

**Public methods to modify**:

1. **Method**: `queue_get_job_status(job_id: str) -> Dict[str, Any]`
   **Current behavior**: Always calls `client.queue_get_job_status(job_id)`
   **New behavior**: 
   - Option A: If adapter's `execute_command_unified` handles endpoint selection automatically, keep current behavior
   - Option B: If adapter does not handle selection, add logic to try `embed_job_status` first for embed jobs, fall back to `queue_get_job_status`
   - Return normalized job status dict

### Class: `AsyncClientQueueMixin`

**Public methods to modify**:

1. **Method**: `get_job_status_or_result(job_id: str, timeout: Optional[float] = None) -> Dict[str, Any]`
   **Current behavior**: Uses `queue_get_job_status()` method
   **New behavior**: 
   - Use `queue_get_job_status()` which should handle endpoint selection
   - Normalize response to consistent format
   - Handle both `embed_job_status` and `queue_get_job_status` response shapes

2. **Method**: `wait_for_job(job_id: str, timeout: Optional[float] = None, poll_interval: float = 0.3) -> Dict[str, Any]`
   **Current behavior**: Polls using `queue_get_job_status()`
   **New behavior**: 
   - Use `queue_get_job_status()` which handles endpoint selection
   - Poll until status is "completed", "failed", or timeout
   - Return final result when completed

### Class: `EmbeddingServiceClient`

**Public methods to modify**:

1. **Method**: `job_status(job_id: str) -> Dict[str, Any]`
   **Current behavior**: Tries `queue_get_job_status`, falls back to `embed_job_status`
   **New behavior**: 
   - Try `embed_job_status` first if adapter supports it
   - Fall back to `queue_get_job_status` if needed
   - Normalize both response formats to consistent shape
   - Return normalized status dict

## Data Structures

### Job Status Response Format (embed_job_status)

```python
{
    "result": {
        "data": {
            "job_id": str,
            "status": str,  # "pending", "running", "completed", "failed"
            "message": str,
            "result": Optional[Dict[str, Any]],  # Present when status="completed"
            "error": Optional[str]  # Present when status="failed"
        }
    }
}
```

### Job Status Response Format (queue_get_job_status)

```python
{
    "result": {
        "job_id": str,
        "status": str,
        "message": str,
        "result": Optional[Dict[str, Any]],
        "error": Optional[str]
    }
}
```

### Normalized Public Format

```python
{
    "job_id": str,
    "status": str,
    "message": str,
    "result": Optional[Dict[str, Any]],  # Embed result when completed
    "error": Optional[str]  # Error message when failed
}
```

## Import Map

### File: `embed_client/adapter_transport.py`

**Existing imports** (keep):
```python
from typing import Any, Dict, Optional
import time
import logging
```

**No additional imports needed**

### File: `embed_client/async_client_queue_mixin.py`

**Existing imports** (keep):
```python
from typing import Any, Dict, Optional
import time
import logging
from embed_client.exceptions import EmbeddingServiceError, EmbeddingServiceTimeoutError
```

**No additional imports needed**

### File: `embed_client/testing_client.py`

**Existing imports** (keep):
```python
from typing import Any, Dict, Optional
from embed_client.exceptions import EmbeddingServiceError
```

**No additional imports needed**

## Error Handling Map

### Method: `AdapterTransport.queue_get_job_status()`

1. **Job not found**:
   - **Exception**: `EmbeddingServiceAPIError` (from adapter)
   - **Condition**: Adapter returns error indicating job_id not found
   - **Message**: Adapter error message
   - **Caller action**: Check job_id is correct

2. **Adapter transport errors**:
   - **Exception**: `EmbeddingServiceError` (from adapter)
   - **Condition**: Adapter transport fails
   - **Message**: Adapter error message
   - **Caller action**: Check server connectivity

### Method: `AsyncClientQueueMixin.get_job_status_or_result()`

1. **Job not found**:
   - **Exception**: `EmbeddingServiceError`
   - **Condition**: Job_id does not exist
   - **Message**: "Job not found: {job_id}"
   - **Caller action**: Check job_id is correct

2. **Timeout**:
   - **Exception**: `EmbeddingServiceTimeoutError`
   - **Condition**: Job does not complete within `timeout` seconds
   - **Message**: "Job did not complete within {timeout} seconds"
   - **Caller action**: Increase timeout or check job status separately

### Method: `AsyncClientQueueMixin.wait_for_job()`

1. **Timeout**:
   - **Exception**: `EmbeddingServiceTimeoutError`
   - **Condition**: Job does not complete within `timeout` seconds
   - **Message**: "Job {job_id} did not complete within {timeout} seconds"
   - **Caller action**: Increase timeout or check job status separately

2. **Job failed**:
   - **Exception**: `EmbeddingServiceAPIError`
   - **Condition**: Job status is "failed"
   - **Message**: Error message from job status response
   - **Caller action**: Check job error details

## Config Dependency

### Config Keys Used

1. **Key**: `timeout` (method parameter, not config)
   - **Type**: `float`
   - **Default**: `None` (unlimited) for `get_job_status_or_result()`, method-specific for `wait_for_job()`
   - **Valid values**: `>= 0.0` (0 means unlimited)
   - **Access location**: Method parameters

2. **Key**: `poll_interval` (method parameter, not config)
   - **Type**: `float`
   - **Default**: `0.3` seconds
   - **Valid values**: `> 0.0`
   - **Access location**: Method parameter in `wait_for_job()`

## Test Plan

### Test File: `tests/test_embed_job_status_alignment.py`

**Test class**: `TestEmbedJobStatusAlignment`

**Test methods**:

1. **Test**: `test_queue_get_job_status_uses_embed_job_status_for_embed_jobs()`
   - **Setup**: Mock adapter client to track which command is called
   - **Action**: Call `queue_get_job_status("embed-job-123")`
   - **Assert**: Adapter called with `embed_job_status` command (if adapter supports automatic selection) OR `queue_get_job_status` (if adapter handles it)

2. **Test**: `test_queue_get_job_status_normalizes_response()`
   - **Setup**: Mock adapter to return `embed_job_status` response format
   - **Mock response**: `{"result": {"data": {"job_id": "job-123", "status": "completed", "result": {...}}}}`
   - **Action**: Call `queue_get_job_status("job-123")`
   - **Assert**: Returns normalized format: `{"job_id": "job-123", "status": "completed", "result": {...}}`

3. **Test**: `test_get_job_status_or_result_handles_both_endpoints()`
   - **Setup**: Mock `queue_get_job_status` to return normalized status
   - **Test cases**: 
     - Status "pending" → returns status dict
     - Status "completed" → returns result dict
     - Status "failed" → raises `EmbeddingServiceAPIError`
   - **Assert**: All cases handled correctly

4. **Test**: `test_wait_for_job_polls_until_completion()`
   - **Setup**: Mock `queue_get_job_status` to return "pending" then "completed"
   - **Action**: Call `wait_for_job("job-123", timeout=10.0, poll_interval=0.1)`
   - **Assert**: Polls multiple times, returns final result when status="completed"

5. **Test**: `test_wait_for_job_timeout()`
   - **Setup**: Mock `queue_get_job_status` to always return "pending"
   - **Action**: Call `wait_for_job("job-123", timeout=0.5, poll_interval=0.1)`
   - **Assert**: Raises `EmbeddingServiceTimeoutError` after timeout

6. **Test**: `test_testing_client_job_status_fallback()`
   - **Setup**: Mock `_transport` to fail on `queue_get_job_status`, succeed on `embed_job_status`
   - **Action**: Call `EmbeddingServiceClient.job_status("job-123")`
   - **Assert**: Falls back to `embed_job_status` and returns normalized result

**Required fixtures/mocks**:
- Mock adapter client methods (`queue_get_job_status`, `embed_job_status`)
- Mock `_adapter_transport` for `AsyncClientQueueMixin` tests
- Mock `_transport` for `EmbeddingServiceClient` tests

## Concrete Examples

### Example 1: Get Job Status (Pending)

**Input**:
```python
await client.get_job_status_or_result("job-abc123")
```

**Adapter call** (via `queue_get_job_status`):
```python
await adapter_client.embed_job_status("job-abc123")
# OR
await adapter_client.queue_get_job_status("job-abc123")
```

**Adapter response**:
```python
{
    "result": {
        "data": {
            "job_id": "job-abc123",
            "status": "pending",
            "message": "Job is queued"
        }
    }
}
```

**Expected public return**:
```python
{
    "job_id": "job-abc123",
    "status": "pending",
    "message": "Job is queued",
    "result": None,
    "error": None
}
```

### Example 2: Get Job Status (Completed)

**Input**:
```python
await client.get_job_status_or_result("job-abc123")
```

**Adapter response**:
```python
{
    "result": {
        "data": {
            "job_id": "job-abc123",
            "status": "completed",
            "message": "Job completed successfully",
            "result": {
                "results": [...],
                "model": "test-model",
                "dimension": 384
            }
        }
    }
}
```

**Expected public return**:
```python
{
    "job_id": "job-abc123",
    "status": "completed",
    "message": "Job completed successfully",
    "result": {
        "results": [...],
        "model": "test-model",
        "dimension": 384
    },
    "error": None
}
```

### Example 3: Wait for Job

**Input**:
```python
await client.wait_for_job("job-abc123", timeout=60.0, poll_interval=0.3)
```

**Poll sequence**:
1. Poll 1: `{"status": "pending"}`
2. Poll 2: `{"status": "pending"}`
3. Poll 3: `{"status": "completed", "result": {...}}`

**Expected return** (after poll 3):
```python
{
    "data": {
        "results": [...],
        "model": "test-model",
        "dimension": 384
    }
}
```

## Algorithm/Logic Description

### Method: `AdapterTransport.queue_get_job_status(job_id: str) -> Dict[str, Any]`

1. **Check adapter behavior**:
   - If adapter's `execute_command_unified` automatically selects `embed_job_status` for embed jobs: use `client.queue_get_job_status(job_id)` (adapter handles selection)
   - Else: try `client.embed_job_status(job_id)` first, catch `MethodNotFoundError`, fall back to `client.queue_get_job_status(job_id)`

2. **Call adapter client**:
   - `result = await client.queue_get_job_status(job_id)` OR `result = await client.embed_job_status(job_id)`

3. **Normalize response**:
   - Extract from `result.get("result", {})` or `result.get("result", {}).get("data", {})`
   - Return normalized format: `{"job_id": ..., "status": ..., "message": ..., "result": ..., "error": ...}`

### Method: `AsyncClientQueueMixin.get_job_status_or_result(job_id: str, timeout: Optional[float] = None) -> Dict[str, Any]`

1. **Get initial status**:
   - Call `self._adapter_transport.queue_get_job_status(job_id)`
   - Store normalized status dict

2. **Check if completed**:
   - If `status == "completed"`: return `{"job_id": ..., "status": "completed", "result": ...}`
   - If `status == "failed"`: raise `EmbeddingServiceAPIError` with error message
   - If `status in ("pending", "running")` and `timeout is None`: return status dict immediately
   - If `status in ("pending", "running")` and `timeout is not None`: proceed to polling

3. **Poll until completion** (if timeout provided):
   - Start timer
   - While elapsed < timeout:
     - Call `queue_get_job_status(job_id)`
     - If `status == "completed"`: return result
     - If `status == "failed"`: raise error
     - Sleep `poll_interval` seconds
   - If timeout exceeded: raise `EmbeddingServiceTimeoutError`

### Method: `AsyncClientQueueMixin.wait_for_job(job_id: str, timeout: Optional[float] = None, poll_interval: float = 0.3) -> Dict[str, Any]`

1. **Start polling loop**:
   - Set start time
   - While True:
     - Call `queue_get_job_status(job_id)`
     - If `status == "completed"`: return `result` from status response
     - If `status == "failed"`: raise `EmbeddingServiceAPIError` with error message
     - If `timeout is not None` and elapsed >= timeout: raise `EmbeddingServiceTimeoutError`
     - Sleep `poll_interval` seconds

### Method: `EmbeddingServiceClient.job_status(job_id: str) -> Dict[str, Any]`

1. **Try embed_job_status first**:
   - Try: `result = await _transport.execute_command_unified(command="embed_job_status", params={"job_id": job_id})`
   - If succeeds: normalize and return

2. **Fall back to queue_get_job_status**:
   - If `embed_job_status` fails with `MethodNotFoundError`: try `queue_get_job_status`
   - Normalize response and return

3. **Normalize response**:
   - Extract from response structure
   - Return normalized format: `{"job_id": ..., "status": ..., "message": ..., "result": ..., "error": ...}`

## Forbidden Approaches

1. **DO NOT** reimplement transport semantics - use adapter client methods
2. **DO NOT** assume all jobs use `queue_get_job_status` - embed jobs should use `embed_job_status` when available
3. **DO NOT** hardcode endpoint selection - check adapter behavior first
4. **DO NOT** modify adapter transport core - only use existing methods
5. **DO NOT** conflate job_id with JSON-RPC request id - they are separate identifiers
6. **DO NOT** skip response normalization - both endpoints may return different shapes
