Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: AdapterTransport.queue_get_job_status() Endpoint Selection

## Executor Role

**coder_auto** - Implement endpoint selection logic in `AdapterTransport.queue_get_job_status()` method.

## Execution Directive

Modify the `queue_get_job_status()` method in `AdapterTransport` class to attempt using `embed_job_status` command first when available, falling back to `queue_get_job_status` if the embed-specific command is not available. Normalize the response from both endpoints to a consistent format.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-job-status-alignment.md`

## Step Scope

**Target file**: `embed_client/adapter_transport.py`
**Action**: modify
**Target method**: `AdapterTransport.queue_get_job_status(job_id: str) -> Dict[str, Any]`
**Lines to modify**: 274-300

## Dependency Contract

**Dependencies**: None (this is the first step in the sequence)
**Dependents**: 
- `async_client_queue_mixin.py` methods will use this method
- `testing_client.py` methods will use this method

## Required Context

The adapter client (`JsonRpcClient`) provides two methods:
- `client.embed_job_status(job_id: str)` - embed-specific job status command
- `client.queue_get_job_status(job_id: str)` - generic queue job status command

The adapter may raise exceptions when a command is not available. We need to try `embed_job_status` first, catch any "method not found" type errors, and fall back to `queue_get_job_status`.

Both endpoints return different response formats:
- `embed_job_status`: `{"result": {"success": bool, "data": {"job_id": str, "status": str, "message": str, "result": Optional[Dict], "error": Optional[str]}}}`
- `queue_get_job_status`: `{"result": {"job_id": str, "status": str, "message": str, "result": Optional[Dict], "error": Optional[str]}}`

The normalized format should be: `{"job_id": str, "status": str, "message": str, "result": Optional[Dict], "error": Optional[str]}`

## Read First

1. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - current implementation
2. `/home/vasilyvz/projects/embed-client/embed_client/response_normalizer.py` - understand normalization patterns
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-job-status-alignment.md` - full tactical task requirements

## Expected File Change

**File**: `embed_client/adapter_transport.py`

**Method signature** (unchanged):
```python
async def queue_get_job_status(self, job_id: str) -> Dict[str, Any]:
```

**Method implementation changes**:
1. Try calling `client.embed_job_status(job_id)` first
2. Catch exceptions that indicate method not found (check for `AttributeError`, `RuntimeError` with "not found" or "not available" messages, or JSON-RPC error responses with method-not-found codes)
3. If `embed_job_status` fails with method-not-found type error, fall back to `client.queue_get_job_status(job_id)`
4. Normalize the response from either endpoint to the consistent format
5. Return normalized dict

**Import changes**: No new imports needed (all required types already imported)

## Forbidden Alternatives

1. **DO NOT** assume `embed_job_status` is always available - must handle fallback
2. **DO NOT** hardcode endpoint selection - must try embed first, then fall back
3. **DO NOT** skip normalization - both endpoints return different shapes
4. **DO NOT** modify other methods in this file
5. **DO NOT** change method signature or return type
6. **DO NOT** remove timing logging - keep existing `_timing_log.debug()` calls

## Atomic Operations

### Method: `queue_get_job_status(job_id: str) -> Dict[str, Any]`

**Step-by-step algorithm**:

1. Get client via `await self._ensure_client()` → store in `client` variable
2. Record start time: `t0 = time.perf_counter()`
3. Try block:
   - Call `result = await client.embed_job_status(job_id)`
   - If successful, proceed to normalization step 5
4. Except block (catch method-not-found errors):
   - Catch `AttributeError` (if method doesn't exist on client)
   - Catch `RuntimeError` where error message contains "not found", "not available", "method not found", or similar
   - Catch JSON-RPC error responses: if `result` is a dict with `"error"` key and error code indicates method not found (typically -32601)
   - If caught, call `result = await client.queue_get_job_status(job_id)` instead
   - If any other exception occurs, re-raise it (don't catch generic `Exception`)
5. Normalize response:
   - Check if `result` is a dict
   - If `result` has key `"result"` and `result["result"]` is a dict:
     - If `result["result"].get("success")` is True and `result["result"].get("data")` exists:
       - Extract `data = result["result"]["data"]`
       - Build normalized: `{"job_id": data.get("job_id", job_id), "status": data.get("status", "unknown"), "message": data.get("message", ""), "result": data.get("result"), "error": data.get("error")}`
     - Else if `result["result"]` has direct keys (queue format):
       - Extract from `result["result"]`: `{"job_id": result["result"].get("job_id", job_id), "status": result["result"].get("status", "unknown"), "message": result["result"].get("message", ""), "result": result["result"].get("result"), "error": result["result"].get("error")}`
   - Else if `result` has direct keys at top level:
     - Use `result` directly but ensure all required keys exist: `{"job_id": result.get("job_id", job_id), "status": result.get("status", "unknown"), "message": result.get("message", ""), "result": result.get("result"), "error": result.get("error")}`
   - Else: create minimal normalized dict with `job_id` and `status="unknown"`
6. Record elapsed time: `elapsed = time.perf_counter() - t0`
7. Log timing: `_timing_log.debug("queue_get_job_status job_id=%s duration_sec=%.3f", (job_id or "")[:16], elapsed)`
8. Return normalized dict

**Error handling**:
- If `embed_job_status` raises `AttributeError`: catch and fall back to `queue_get_job_status`
- If `embed_job_status` raises `RuntimeError` with "not found"/"not available" in message: catch and fall back
- If `embed_job_status` returns dict with `{"error": {"code": -32601, ...}}` (method not found): catch and fall back
- If `queue_get_job_status` raises any exception: let it propagate (don't catch)
- If normalization fails (e.g., result is None or wrong type): return minimal dict with `{"job_id": job_id, "status": "unknown", "message": "", "result": None, "error": None}`

**Return value**: Dict with keys: `job_id` (str), `status` (str), `message` (str), `result` (Optional[Dict]), `error` (Optional[str])

**Edge cases**:
- `job_id` is empty string: use as-is, don't validate
- `embed_job_status` returns None: fall back to `queue_get_job_status`
- `embed_job_status` returns non-dict: fall back to `queue_get_job_status`
- Response missing `status` key: use `"unknown"` as default
- Response missing `job_id` in nested structure: use input `job_id` parameter
- Both endpoints fail: let exception propagate from `queue_get_job_status`

## Expected Deliverables

1. Modified `queue_get_job_status()` method in `embed_client/adapter_transport.py`
2. Method tries `embed_job_status` first, falls back to `queue_get_job_status`
3. Method normalizes responses from both endpoints to consistent format
4. Method preserves existing timing logging
5. Method handles all edge cases gracefully

## Mandatory Validation

**Validation commands** (run from project root):

1. **Code formatting**:
   ```bash
   black embed_client/adapter_transport.py
   ```
   Expected: "reformatted" or "already well formatted"

2. **Linting**:
   ```bash
   flake8 embed_client/adapter_transport.py
   ```
   Expected: no output (exit code 0)

3. **Type checking**:
   ```bash
   mypy embed_client/adapter_transport.py
   ```
   Expected: "Success: no issues found"

4. **Import validation**: Verify no new imports were added (check file imports match current imports)

**Test expectations**: Tests for this method should be written in a separate test step. This step only implements the production code.

## Decision Rules

1. **Exception detection**: Check exception type AND message content to determine if it's a "method not found" error
2. **Normalization priority**: Handle `embed_job_status` format first (has `result.success` and `result.data`), then queue format (direct keys in `result`), then top-level keys
3. **Fallback strategy**: Only fall back on method-not-found errors; other errors should propagate
4. **Default values**: Use empty string for `message`, `None` for `result` and `error`, `"unknown"` for `status` when missing

## Blackstops

**STOP and escalate if**:
- Adapter client doesn't have `embed_job_status` method (check adapter client interface)
- Adapter client exception types are different than expected
- Response normalization logic conflicts with existing `ResponseNormalizer.normalize_queue_status()` usage elsewhere

## Handoff Package

**For coder_auto**:
- Target file: `embed_client/adapter_transport.py`
- Method to modify: `queue_get_job_status()` (lines 274-300)
- Key requirement: Try `embed_job_status` first, fall back to `queue_get_job_status`, normalize response
- Critical: Preserve timing logging, handle all exception cases, normalize both response formats
- Validation: Run black, flake8, mypy after implementation

**Completion condition**: All validation commands pass, method correctly handles both endpoints and normalizes responses.
