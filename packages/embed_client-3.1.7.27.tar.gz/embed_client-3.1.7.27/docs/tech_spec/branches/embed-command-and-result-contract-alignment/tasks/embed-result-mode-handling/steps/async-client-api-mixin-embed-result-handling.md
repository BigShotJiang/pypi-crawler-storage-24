Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: AsyncClientAPIMixin.embed() Result Handling

## Executor Role

**Executor**: `coder_auto`  
**Role**: Update result handling section in `AsyncClientAPIMixin.embed()` method to correctly detect and handle immediate vs queued result modes from adapter responses.

## Execution Directive

Modify the result handling section of `embed()` method in `embed_client/async_client_api_mixin.py` (lines 492-588) to:
1. Correctly detect immediate vs queued modes using `_extract_job_id_from_response()`
2. Handle queued mode with `wait=False` by returning job metadata
3. Handle queued mode with `wait=True` by waiting and normalizing final result
4. Handle immediate mode by extracting and normalizing result to public format
5. Normalize both immediate and queued final results to: `{"results": [...], "model": "...", "dimension": N, "device": "..."}`

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling.md`

## Step Scope

**Target file**: `embed_client/async_client_api_mixin.py`  
**Action**: modify  
**Method to modify**: `AsyncClientAPIMixin.embed()` - result handling section (lines 492-588)

## Dependency Contract

- **Depends on**: `extract-job-id-from-adapter-response.md` (must complete first - uses `_extract_job_id_from_response()`)
- **Required by**: None (this is a terminal step)
- **Can run in parallel with**: `testing-client-embed-result-handling.md` (independent implementation)

## Required Context

After calling `execute_command_unified()`, the adapter returns a response that may be:

1. **Immediate mode**: `{"mode": "immediate", "result": {"result": {"data": {"results": [...], "model": "...", "dimension": N, "device": "..."}}}}`
2. **Queued mode**: `{"mode": "queued", "job_id": "job-123", "status": "pending", "result": {"result": {"data": {"job_id": "job-123", "status": "pending", "message": "..."}}}}`

The method must:
- Extract job_id using `_extract_job_id_from_response(result)`
- If `wait=False` and job_id found: return `{"job_id": job_id, "status": "...", "message": "..."}`
- If `wait=True` and job_id found: call `wait_for_job_via_websocket()` or `wait_for_job()`, then normalize result
- If no job_id (immediate mode): extract result from `result.get("result", {})` and normalize to public format

The public format is: `{"results": [...], "model": "...", "dimension": N, "device": "..."}`

## Read First

Before starting implementation, read these files:

1. `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` (lines 480-593) - current implementation
2. `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` (lines 30-50) - `_extract_job_id_from_response()` function
3. `/home/vasilyvz/projects/embed-client/embed_client/async_client_queue_mixin.py` (lines 35-208) - `wait_for_job()` and `wait_for_job_via_websocket()` methods
4. `/home/vasilyvz/projects/embed-client/embed_client/response_parsers.py` - `extract_embedding_data()` and `extract_embeddings()` functions
5. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling.md` - tactical task specification

## Expected File Change

**File**: `embed_client/async_client_api_mixin.py`

**Method**: `AsyncClientAPIMixin.embed()` - result handling section (replace lines 492-588)

**Current code location**: After line 491 (`_timing_log.debug("embed submit_sec=...")`), before line 589 (`finally:` block)

**New implementation** (replace lines 492-588):

The result handling logic must be:

1. **Extract job_id**:
   ```python
   extracted_job_id = (
       _extract_job_id_from_response(result)
       if isinstance(result, Dict)
       else None
   )
   ```

2. **Extract data for status/message** (for queued mode):
   ```python
   data = (
       (result or {}).get("result", {}).get("data", {})
       if isinstance(result, Dict)
       else {}
   )
   ```

3. **Handle queued mode (wait=False)**:
   ```python
   if not wait and extracted_job_id:
       return {
           "job_id": extracted_job_id,
           "status": data.get("status", "pending"),
           "message": data.get("message", "Job queued successfully"),
       }
   ```

4. **Handle queued mode (wait=True)**:
   ```python
   wait_timeout = timeout if timeout is not None else 60.0
   if extracted_job_id and wait:
       t_wait0 = time.perf_counter()
       if use_push:
           try:
               job_result = await client_to_use.wait_for_job_via_websocket(  # type: ignore[attr-defined]
                   extracted_job_id, timeout=wait_timeout
               )
           except EmbeddingServiceTimeoutError:
               raise
       else:
           job_result = await client_to_use.wait_for_job(  # type: ignore[attr-defined]
               extracted_job_id,
               timeout=wait_timeout,
               poll_interval=poll_interval,
           )
       _timing_log.debug(
           "embed wait_sec=%.3f",
           time.perf_counter() - t_wait0,
       )
       
       # Extract result from job_result
       normalized_result = _normalize_job_result_to_public_format(job_result)
       _timing_log.debug(
           "embed total_sec=%.3f",
           time.perf_counter() - t_embed_start,
       )
       return normalized_result
   ```

5. **Handle immediate mode**:
   ```python
   # Immediate mode: server returned full result immediately
   normalized_result = _normalize_immediate_result_to_public_format(result)
   _timing_log.debug(
       "embed total_sec=%.3f",
       time.perf_counter() - t_embed_start,
   )
   return normalized_result
   ```

**Helper function to add** (add before `embed()` method, after `_extract_job_id_from_response()`):

```python
def _normalize_job_result_to_public_format(job_result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize job result from wait_for_job/wait_for_job_via_websocket to public format.
    
    Args:
        job_result: Result from wait_for_job or wait_for_job_via_websocket
        
    Returns:
        Public format: {"results": [...], "model": "...", "dimension": N, "device": "..."}
    """
    # Extract data from various nested structures
    if isinstance(job_result, Dict):
        if "data" in job_result:
            data = job_result["data"]
        elif "result" in job_result:
            data = job_result["result"]
        else:
            data = job_result
    else:
        data = {}
    
    # If data already has results/embeddings at top level, return it
    if isinstance(data, Dict):
        if "results" in data:
            return data
        if "embeddings" in data:
            return data
        if "data" in data:
            nested_data = data["data"]
            if isinstance(nested_data, Dict):
                if "results" in nested_data:
                    return nested_data
                if "embeddings" in nested_data:
                    return nested_data
    
    # Try to extract using parsers
    try:
        wrapped = {"result": {"success": True, "data": data}}
        results = extract_embedding_data(wrapped)
        # Extract model, dimension, device from data if available
        model = data.get("model") if isinstance(data, Dict) else None
        dimension = data.get("dimension") if isinstance(data, Dict) else None
        device = data.get("device") if isinstance(data, Dict) else None
        normalized = {"results": results}
        if model is not None:
            normalized["model"] = model
        if dimension is not None:
            normalized["dimension"] = dimension
        if device is not None:
            normalized["device"] = device
        return normalized
    except ValueError:
        try:
            embeddings = extract_embeddings(wrapped)
            normalized = {"embeddings": embeddings}
            if isinstance(data, Dict):
                if "model" in data:
                    normalized["model"] = data["model"]
                if "dimension" in data:
                    normalized["dimension"] = data["dimension"]
                if "device" in data:
                    normalized["device"] = data["device"]
            return normalized
        except ValueError:
            return data if isinstance(data, Dict) else {"results": []}
    
    return {"results": []}


def _normalize_immediate_result_to_public_format(result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize immediate adapter result to public format.
    
    Args:
        result: Immediate result from execute_command_unified
        
    Returns:
        Public format: {"results": [...], "model": "...", "dimension": N, "device": "..."}
    """
    # Extract result from adapter response
    raw_result = (
        {"result": result.get("result", result)}
        if isinstance(result, Dict)
        else {}
    )
    
    # Try to extract from result.data structure
    embed_data: Optional[Dict[str, Any]] = None
    if "result" in raw_result and isinstance(raw_result["result"], Dict):
        res = raw_result["result"]
        if "data" in res and isinstance(res["data"], Dict):
            embed_data = res["data"]
        elif "data" in res and isinstance(res["data"], list):
            embed_data = {"results": res["data"]}
    
    # If not found, try using parsers
    if embed_data is None:
        try:
            results = extract_embedding_data(raw_result)
            embed_data = {"results": results}
        except ValueError:
            try:
                embeddings = extract_embeddings(raw_result)
                embed_data = {"embeddings": embeddings}
            except ValueError:
                embed_data = {"results": []}
    
    return embed_data
```

**Exact algorithm for main result handling** (lines 492-588 replacement):

1. **Extract job_id**:
   - Call `_extract_job_id_from_response(result)` if `result` is a Dict, else `None`
   - Store in `extracted_job_id`

2. **Extract data for status/message**:
   - Extract `result.get("result", {}).get("data", {})` if `result` is a Dict, else `{}`
   - Store in `data`

3. **Handle queued mode (wait=False)**:
   - If `not wait and extracted_job_id`:
     - Return `{"job_id": extracted_job_id, "status": data.get("status", "pending"), "message": data.get("message", "Job queued successfully")}`

4. **Handle queued mode (wait=True)**:
   - If `extracted_job_id and wait`:
     - Set `wait_timeout = timeout if timeout is not None else 60.0`
     - Record start time: `t_wait0 = time.perf_counter()`
     - If `use_push`:
       - Call `await client_to_use.wait_for_job_via_websocket(extracted_job_id, timeout=wait_timeout)`
       - Catch `EmbeddingServiceTimeoutError` and re-raise
     - Else:
       - Call `await client_to_use.wait_for_job(extracted_job_id, timeout=wait_timeout, poll_interval=poll_interval)`
     - Log wait time: `_timing_log.debug("embed wait_sec=%.3f", time.perf_counter() - t_wait0)`
     - Call `_normalize_job_result_to_public_format(job_result)` to normalize
     - Log total time: `_timing_log.debug("embed total_sec=%.3f", time.perf_counter() - t_embed_start)`
     - Return normalized result

5. **Handle immediate mode**:
   - Call `_normalize_immediate_result_to_public_format(result)` to normalize
   - Log total time: `_timing_log.debug("embed total_sec=%.3f", time.perf_counter() - t_embed_start)`
   - Return normalized result

## Forbidden Alternatives

- **DO NOT** reimplement transport semantics - use existing `wait_for_job()` and `wait_for_job_via_websocket()` methods
- **DO NOT** hide server semantics - preserve job_id and status when `wait=False`
- **DO NOT** assume all results are immediate - always check for job_id first
- **DO NOT** modify adapter transport layer - only use existing methods
- **DO NOT** conflate JSON-RPC request id with job_id
- **DO NOT** modify response normalizer internal implementation - only use existing normalization functions
- **DO NOT** implement custom WebSocket waiting - use existing `wait_for_job_via_websocket()` method
- **DO NOT** remove timing logs - keep all `_timing_log.debug()` calls
- **DO NOT** change method signature or parameters

## Atomic Operations

1. Read current `embed()` method result handling section (lines 492-588)
2. Add two helper functions before `embed()` method: `_normalize_job_result_to_public_format()` and `_normalize_immediate_result_to_public_format()`
3. Replace result handling section (lines 492-588) with new logic that:
   - Extracts job_id using `_extract_job_id_from_response()`
   - Handles queued mode (wait=False) by returning job metadata
   - Handles queued mode (wait=True) by waiting and normalizing
   - Handles immediate mode by normalizing result
4. Ensure all timing logs are preserved
5. Ensure error handling (EmbeddingServiceTimeoutError) is preserved

## Expected Deliverables

- Updated `embed()` method result handling section in `embed_client/async_client_api_mixin.py`
- Two new helper functions: `_normalize_job_result_to_public_format()` and `_normalize_immediate_result_to_public_format()`
- Method correctly detects immediate vs queued modes
- Method returns correct public format for both modes
- All timing logs preserved
- Error handling preserved

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Code formatting**:
   ```bash
   black embed_client/async_client_api_mixin.py
   ```
   **Expected**: "reformatted" or "already well formatted" (exit code 0)

2. **Linting**:
   ```bash
   flake8 embed_client/async_client_api_mixin.py
   ```
   **Expected**: No output (exit code 0)

3. **Type checking**:
   ```bash
   mypy embed_client/async_client_api_mixin.py
   ```
   **Expected**: "Success: no issues found" (exit code 0)

4. **Tests** (if test file exists or is created in a separate step):
   ```bash
   pytest tests/test_embed_result_mode_handling.py::TestEmbedResultModeHandling::test_embed_immediate_result_normalization -v
   pytest tests/test_embed_result_mode_handling.py::TestEmbedResultModeHandling::test_embed_queued_result_detection -v
   pytest tests/test_embed_result_mode_handling.py::TestEmbedResultModeHandling::test_embed_queued_result_wait_and_normalize -v
   pytest tests/test_embed_result_mode_handling.py::TestEmbedResultModeHandling::test_embed_handles_legacy_embeddings_format -v
   ```
   **Expected**: All test cases pass

## Decision Rules

- **Mode detection**: Use `_extract_job_id_from_response()` - if job_id found, it's queued mode; if not, it's immediate mode
- **Normalization priority**: Check for `results` or `embeddings` at top level first, then try parsers, then return empty results
- **Model/dimension/device extraction**: Extract from data dict if available, include in normalized result
- **Error handling**: Re-raise `EmbeddingServiceTimeoutError` from `wait_for_job_via_websocket()`, let other exceptions propagate
- **Timing logs**: Preserve all existing timing log calls with same format

## Blackstops

**STOP and escalate** if:
- Adapter response format changes require different extraction logic
- `wait_for_job()` or `wait_for_job_via_websocket()` return format changes
- Public format requirements change (must match tactical task specification)
- Method signature must change (breaks existing callers)

## Handoff Package

**For coder_auto**:

1. **Target file**: `embed_client/async_client_api_mixin.py`
2. **Method to modify**: `AsyncClientAPIMixin.embed()` - result handling section (lines 492-588)
3. **Helper functions to add**: `_normalize_job_result_to_public_format()` and `_normalize_immediate_result_to_public_format()` (add before `embed()` method)
4. **Imports** (already present, no changes needed):
   - `from typing import Any, Dict, List, Optional`
   - `from embed_client.exceptions import EmbeddingServiceTimeoutError`
   - `from embed_client.response_parsers import extract_embedding_data, extract_embeddings`
   - `import time`
   - `import logging` (for `_timing_log`)
5. **Implementation requirements**:
   - Extract job_id using `_extract_job_id_from_response(result)`
   - Handle queued mode (wait=False): return job metadata
   - Handle queued mode (wait=True): wait and normalize result
   - Handle immediate mode: normalize result to public format
   - Preserve all timing logs
   - Preserve error handling
6. **Edge cases**:
   - Non-dict result → treat as immediate mode, try to normalize
   - Missing job_id in queued response → treat as immediate mode
   - Missing results/embeddings in normalized data → return empty results list
   - Parser exceptions → try alternative parser, then return empty results
7. **Validation commands**: See "Mandatory Validation" section above
8. **Completion condition**: All validation commands pass, method handles both immediate and queued modes correctly

## Constants and Literals

- **Default timeout**: `60.0` (used when `timeout=None` and `wait=True`)
- **Default status**: `"pending"` (used when status not found in queued response)
- **Default message**: `"Job queued successfully"` (used when message not found in queued response)
- **Timing log format**: `"embed wait_sec=%.3f"` and `"embed total_sec=%.3f"` (preserve existing format)
