Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Align models() and Add timing_stats() in EmbeddingServiceClient

## Executor Role

**Executor**: `coder_auto` (weak model implementation agent)

## Execution Directive

Modify the `models()` method and add the `timing_stats()` method in `embed_client/testing_client.py` to align with the server command contract. Ensure both methods correctly normalize server responses from various response shapes to stable public formats, matching the behavior of `AsyncClientAPIMixin` methods.

## Parent Links

- **Tech spec**: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step**: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- **Parent tactical task**: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/models-timing-stats-alignment.md`

## Step Scope

**Target file**: `embed_client/testing_client.py`  
**Action**: modify  
**Lines to modify**: 
- `models()` method: line 503-516 (modify existing)
- `timing_stats()` method: add new method after `models()` method (after line 516)

## Dependency Contract

**Dependencies**: None (can run in parallel with other atomic steps)

**Dependents**: None (this step does not block other steps)

## Required Context

1. The `EmbeddingServiceClient` class uses `self._transport` which is an `AdapterTransport` instance.
2. The `_transport` has a `jsonrpc_call()` method that directly calls the JSON-RPC endpoint.
3. Current `models()` method (lines 503-516) calls `self._transport.jsonrpc_call("models", {})` and expects `result.data` format.
4. Server responses can have multiple shapes (same as in `AsyncClientAPIMixin`).
5. The `EmbeddingServiceClient` class does not have a `timing_stats()` method yet - it must be added.
6. Both methods must return normalized public formats that are stable regardless of server response shape.

## Read First

Before starting implementation, read these files in order:

1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - understand overall architecture
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md` - understand global step context
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/models-timing-stats-alignment.md` - understand tactical task requirements
4. `/home/vasilyvz/projects/embed-client/embed_client/testing_client.py` - current implementation (especially lines 503-516)
5. `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` - reference implementation for normalization logic (lines 272-312)
6. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - understand `jsonrpc_call()` method

## Expected File Change

**File**: `embed_client/testing_client.py`

**Changes**:

1. **Method `models()` (lines 503-516)**:
   - Keep existing call to `self._transport.jsonrpc_call("models", {})`
   - Replace current normalization logic that expects `result.data` format
   - Handle three response shapes:
     - `{"result": {"success": True, "data": {"models": [...]}}}` → extract `result["result"]["data"]["models"]`
     - `{"result": {"models": [...]}}` → extract `result["result"]["models"]`
     - `{"result": {"data": {"models": [...]}}}` → extract `result["result"]["data"]["models"]`
     - `{"result": [...]}` → extract `result["result"]` directly (if it's a list)
   - Return normalized format: `{"models": [...]}` where the list contains model info dicts
   - If models cannot be extracted, return `{"models": []}`
   - Keep existing error handling for JSON-RPC errors

2. **Method `timing_stats()` (new method, add after `models()`)**:
   - Add new async method with signature: `async def timing_stats(self, file_path: Optional[str] = None) -> Dict[str, Any]:`
   - Add parameter validation: if `file_path is not None` and not `isinstance(file_path, str)`, raise `ValueError("file_path must be a string or None")`
   - Build params: if `file_path is not None and file_path.strip()`, set `params = {"file_path": file_path.strip()}`, else `params = {}`
   - Call `self._transport.jsonrpc_call("timing_stats", params)`
   - Handle error responses: if `"error" in response`, raise `EmbeddingServiceAPIError`
   - Handle two response shapes:
     - `{"result": {"success": True, "data": {"total_requests": ..., ...}}}` → extract `result["result"]["data"]`
     - `{"result": {"total_requests": ..., ...}}` → extract `result["result"]` directly
     - `{"result": {"data": {"total_requests": ..., ...}}}` → extract `result["result"]["data"]`
   - Return normalized format: dict with timing stats keys
   - If timing stats cannot be extracted, return `{}`

## Forbidden Alternatives

1. **DO NOT** use `cmd()` method - `EmbeddingServiceClient` uses `_transport.jsonrpc_call()` directly
2. **DO NOT** assume a single response format - handle all documented response shapes
3. **DO NOT** skip parameter validation for `file_path` in `timing_stats()`
4. **DO NOT** modify other methods in the file
5. **DO NOT** modify adapter transport layer
6. **DO NOT** hardcode response structure - normalize flexibly
7. **DO NOT** use `Any` type annotation - use proper types
8. **DO NOT** add methods not listed in this step
9. **DO NOT** modify files other than the target file
10. **DO NOT** use `print()` for logging - use the project logger if needed
11. **DO NOT** change the class structure or other existing methods

## Atomic Operations

### Operation 1: Modify `models()` method

**Location**: Lines 503-516 in `embed_client/testing_client.py`

**Current signature** (keep):
```python
async def models(self) -> Dict[str, Any]:
```

**New implementation algorithm**:

1. Call `response = await self._transport.jsonrpc_call("models", {})`
   - This returns a dict with structure `{"result": ...}` or `{"error": ...}`

2. Handle JSON-RPC errors:
   - If `"error" in response`:
     - Raise `EmbeddingServiceAPIError({"message": str(response["error"])})`

3. Extract result:
   - Let `result = response.get("result", {})`

4. Handle result success flag (if present):
   - If `result` is a dict and `result.get("success") is False`:
     - Let `error = result.get("error", {})`
     - Raise `EmbeddingServiceAPIError({"message": error.get("message", "Unknown error")})`

5. Extract models list from response (handle multiple shapes):
   - Let `result_data = result.get("data", result)` (try data first, fallback to result)
   - If `result_data` is a dict and `"models" in result_data`:
     - Set `models_list = result_data["models"]`
   - Else if `result_data` is a dict and `"data" in result_data`:
     - Let `nested_data = result_data["data"]`
     - If `nested_data` is a dict and `"models" in nested_data`:
       - Set `models_list = nested_data["models"]`
     - Else:
       - Set `models_list = []`
   - Else if `result_data` is a list:
     - Set `models_list = result_data`
   - Else:
     - Set `models_list = []`

6. Validate `models_list`:
   - If `models_list` is not a list, set `models_list = []`

7. Return normalized format:
   - Return `{"models": models_list}`

**Error handling**:
- If `jsonrpc_call()` raises an exception, let it propagate (do not catch)
- If JSON-RPC error response, raise `EmbeddingServiceAPIError` with message from error
- If result format is unexpected and models cannot be extracted, return `{"models": []}` (do not raise exception)

### Operation 2: Add `timing_stats()` method

**Location**: After line 516 (after `models()` method) in `embed_client/testing_client.py`

**New method signature**:
```python
async def timing_stats(
    self,
    file_path: Optional[str] = None,
) -> Dict[str, Any]:
```

**New implementation algorithm**:

1. Validate `file_path` parameter:
   - If `file_path is not None` and not `isinstance(file_path, str)`:
     - Raise `ValueError("file_path must be a string or None")`

2. Build params dict:
   - If `file_path is not None and file_path.strip()`:
     - Set `params = {"file_path": file_path.strip()}`
   - Else:
     - Set `params = {}`

3. Call `response = await self._transport.jsonrpc_call("timing_stats", params)`
   - This returns a dict with structure `{"result": ...}` or `{"error": ...}`

4. Handle JSON-RPC errors:
   - If `"error" in response`:
     - Raise `EmbeddingServiceAPIError({"message": str(response["error"])})`

5. Extract result:
   - Let `result = response.get("result", {})`

6. Handle result success flag (if present):
   - If `result` is a dict and `result.get("success") is False`:
     - Let `error = result.get("error", {})`
     - Raise `EmbeddingServiceAPIError({"message": error.get("message", "Unknown error")})`

7. Extract timing stats from response (handle multiple shapes):
   - Let `result_data = result.get("data", result)` (try data first, fallback to result)
   - If `result_data` is a dict and (`"total_requests" in result_data` or `"success_count" in result_data`):
     - Set `stats = result_data`
   - Else if `result_data` is a dict and `"data" in result_data`:
     - Let `nested_data = result_data["data"]`
     - If `nested_data` is a dict:
       - Set `stats = nested_data`
     - Else:
       - Set `stats = {}`
   - Else if `result_data` is a dict:
     - Set `stats = result_data`
   - Else:
     - Set `stats = {}`

8. Return normalized format:
   - Return `stats` dict directly

**Error handling**:
- If parameter validation fails, raise `ValueError` with exact message: `"file_path must be a string or None"`
- If `jsonrpc_call()` raises an exception, let it propagate (do not catch)
- If JSON-RPC error response, raise `EmbeddingServiceAPIError` with message from error
- If result format is unexpected and timing stats cannot be extracted, return `{}` (do not raise exception)

## Expected Deliverables

1. Modified `embed_client/testing_client.py` with:
   - Updated `models()` method that handles all response shapes
   - New `timing_stats()` method with parameter validation and all response shapes
   - Both methods return normalized public formats
   - No changes to other methods or file structure

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Format check**:
   ```bash
   black embed_client/testing_client.py
   ```
   **Expected**: "reformatted" or "already well formatted" (exit code 0)

2. **Lint check**:
   ```bash
   flake8 embed_client/testing_client.py
   ```
   **Expected**: No output (exit code 0)

3. **Type check**:
   ```bash
   mypy embed_client/testing_client.py
   ```
   **Expected**: "Success: no issues found" (exit code 0)

4. **Tests** (if test file exists):
   ```bash
   pytest tests/test_models_timing_stats_alignment.py::TestModelsTimingStatsAlignment::test_testing_client_models_timing_stats -v
   ```
   **Expected**: All tests PASSED

**Completion condition**: All validation commands must pass. All tests must pass.

## Decision Rules

1. **Response shape detection**: Check for keys in order: first check `result.data`, then check top-level keys in `result`, then check nested `result.data.data`, then check if `result` is a list/dict directly.

2. **Empty response handling**: If models cannot be extracted, return `{"models": []}`. If timing stats cannot be extracted, return `{}`. Do not raise exceptions for normalization failures.

3. **Parameter validation**: Only validate `file_path` type. Do not validate file path existence or format (server will handle that).

4. **Whitespace handling**: Strip `file_path` before adding to params if it's not None and not empty.

5. **Error handling**: Match the pattern used in existing `models()` method - check for `"error"` key and `result.success` flag.

6. **Method placement**: Add `timing_stats()` method immediately after `models()` method, before `list_commands()` method.

## Blackstops

**STOP and escalate** if:
- `_transport.jsonrpc_call()` method signature changes in a way that breaks these method calls
- Server response format requires breaking changes to public API
- Adapter transport layer changes require modifications beyond using `jsonrpc_call()`

## Handoff Package

**For coder_auto**:

1. **Target file**: `embed_client/testing_client.py`
2. **Methods to modify**: 
   - `models()` (lines 503-516) - modify existing
   - `timing_stats()` (new method) - add after `models()`
3. **Key requirements**:
   - `models()`: Handle 3+ response shapes, return `{"models": [...]}`
   - `timing_stats()`: Validate `file_path`, handle 2+ response shapes, return timing stats dict
   - Use `_transport.jsonrpc_call()` directly (not `cmd()`)
4. **Validation**: Run black, flake8, mypy, and relevant tests
5. **No guessing**: All response shapes, error conditions, and return formats are explicitly specified above

## Constants and Literals

**No new constants needed** - use existing imports and types:
- `Dict[str, Any]` from `typing`
- `Optional[str]` from `typing`
- `ValueError` (built-in)
- `EmbeddingServiceAPIError` from `embed_client.exceptions`
- String literal: `"file_path must be a string or None"` (exact message for ValueError)
- String literal: `"models"` (key name in response)
- String literal: `"data"` (key name in nested response)
- String literal: `"total_requests"` (key name for timing stats detection)
- String literal: `"success_count"` (key name for timing stats detection)
- String literal: `"error"` (key name for JSON-RPC error)
- String literal: `"result"` (key name for JSON-RPC result)
- String literal: `"success"` (key name for result success flag)
- String literal: `"message"` (key name for error message)

## File Header

**Keep existing file header** (lines 1-12):
```python
"""
Embedding service client (adapter-based).

Thin wrapper over mcp_proxy_adapter JsonRpcClient: health, embed (with
execute_async when wait=True), job_status, models, list_commands,
wait_for_job, WebSocket channel. Uses adapter async exchange: execute_async,
wait_for_job_via_websocket, open_bidirectional_ws_channel.
Supports from_config, validate_config, generate_config.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
```

## Complete Import List

**Keep existing imports** (no changes needed):
```python
from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union, cast

from embed_client.adapter_config_factory import AdapterConfigFactory
from embed_client.adapter_transport import AdapterTransport
from embed_client.constants import EMBED_DEFAULT_ERROR_POLICY
from embed_client.config_generator import ClientConfigGenerator
from embed_client.config_validator import ConfigValidator
from embed_client.exceptions import (
    EmbeddingServiceAPIError,
    EmbeddingServiceConfigError,
    EmbeddingServiceError,
    EmbeddingServiceTimeoutError,
)
from embed_client.testing_client_helpers import (
    list_commands_via_client,
    wait_for_job_poll,
)
```

## Edge Cases

### For `models()` method:

1. **Empty response**: `{"result": {}}` → return `{"models": []}`
2. **Missing result key**: `{}` → return `{"models": []}`
3. **Result is None**: `{"result": None}` → return `{"models": []}`
4. **Result has success=False**: `{"result": {"success": False, "error": {...}}}` → raise `EmbeddingServiceAPIError`
5. **Result is string**: `{"result": "error"}` → return `{"models": []}`
6. **Nested data is not dict**: `{"result": {"data": "string"}}` → return `{"models": []}`
7. **Models key exists but value is not list**: `{"result": {"models": "not a list"}}` → return `{"models": []}`
8. **JSON-RPC error**: `{"error": {...}}` → raise `EmbeddingServiceAPIError`

### For `timing_stats()` method:

1. **file_path is None**: No params sent → server uses default
2. **file_path is empty string**: No params sent → server uses default
3. **file_path is whitespace only**: No params sent (after strip) → server uses default
4. **file_path is non-string**: Raise `ValueError("file_path must be a string or None")`
5. **Empty response**: `{"result": {}}` → return `{}`
6. **Missing result key**: `{}` → return `{}`
7. **Result is None**: `{"result": None}` → return `{}`
8. **Result has success=False**: `{"result": {"success": False, "error": {...}}}` → raise `EmbeddingServiceAPIError`
9. **Nested data is not dict**: `{"result": {"data": "string"}}` → return `{}`
10. **JSON-RPC error**: `{"error": {...}}` → raise `EmbeddingServiceAPIError`

## Method Docstrings

### For `models()` method:

**Update existing docstring** to:
```python
"""
List available models from the service.

Returns:
    Dictionary with "models" key containing list of model info
    (name, dimension, supported_dimensions, max_tokens, etc.).

Raises:
    EmbeddingServiceAPIError: If JSON-RPC error or server returns error.
"""
```

### For `timing_stats()` method (new):

**Add docstring**:
```python
"""
Get timing statistics from the embedding service (when timing_registration is enabled).

Args:
    file_path: Optional path to JSONL timing file on the server.
              If omitted, server uses config default (e.g. ./logs/embed_timings.jsonl).

Returns:
    Dictionary with total_requests, success_count, encode_seconds, rpc_seconds,
    by_device, batch_vs_single, calculation_time_seconds, etc.

Raises:
    ValueError: If file_path is not None and not a string.
    EmbeddingServiceAPIError: If JSON-RPC error or server returns error.
"""
```
