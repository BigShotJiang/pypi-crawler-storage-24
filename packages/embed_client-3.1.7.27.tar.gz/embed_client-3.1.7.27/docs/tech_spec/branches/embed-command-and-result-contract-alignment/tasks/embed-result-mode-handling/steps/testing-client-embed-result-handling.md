Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: EmbeddingServiceClient.embed() Result Handling

## Executor Role

**Executor**: `coder_auto`  
**Role**: Update result handling in `EmbeddingServiceClient.embed()` method in `testing_client.py` to correctly detect and handle immediate vs queued result modes from adapter/server responses.

## Execution Directive

Modify the result handling section of `embed()` method in `embed_client/testing_client.py` (lines 271-356) to:
1. Correctly detect immediate vs queued modes using job_id extraction
2. Handle queued mode with `wait=False` by returning job metadata
3. Handle queued mode with `wait=True` by waiting and normalizing final result
4. Handle immediate mode by normalizing result to public format
5. Normalize both immediate and queued final results to: `{"results": [...], "model": "...", "dimension": N, "device": "..."}`

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling.md`

## Step Scope

**Target file**: `embed_client/testing_client.py`  
**Action**: modify  
**Method to modify**: `EmbeddingServiceClient.embed()` - result handling section (lines 271-356)

## Dependency Contract

- **Depends on**: `extract-job-id-from-adapter-response.md` (may use similar job_id extraction logic, but can implement locally if needed)
- **Required by**: None (this is a terminal step)
- **Can run in parallel with**: `async-client-api-mixin-embed-result-handling.md` (independent implementation)

## Required Context

The `EmbeddingServiceClient.embed()` method currently:
- Uses `execute_async("embed_execute", ...)` when `wait=True` (WebSocket push)
- Uses `jsonrpc_call("embed", ...)` when `wait=False` (HTTP JSON-RPC)

After calling the transport, the response may be:

1. **Immediate mode**: Response contains `results` or `embeddings` directly, no `job_id`
2. **Queued mode**: Response contains `job_id` and status metadata

The method must:
- Extract job_id from response (check `data.get("job_id")` and `result.get("job_id")`)
- If `wait=False` and job_id found: return `{"job_id": job_id, "status": "...", "message": "..."}`
- If `wait=True` and job_id found: wait for completion (via `_embed_via_execute_async` or `wait_for_job_via_websocket`), then normalize result
- If no job_id (immediate mode): normalize result to public format

The public format is: `{"results": [...], "model": "...", "dimension": N, "device": "..."}`

## Read First

Before starting implementation, read these files:

1. `/home/vasilyvz/projects/embed-client/embed_client/testing_client.py` (lines 271-356) - current `embed()` implementation
2. `/home/vasilyvz/projects/embed-client/embed_client/testing_client.py` (lines 357-403) - `_embed_via_execute_async()` method
3. `/home/vasilyvz/projects/embed-client/embed_client/testing_client.py` (lines 405-456) - `wait_for_job()` and `wait_for_job_via_websocket()` methods
4. `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` (lines 30-50) - `_extract_job_id_from_response()` function (for reference)
5. `/home/vasilyvz/projects/embed-client/embed_client/response_parsers.py` - `extract_embedding_data()` and `extract_embeddings()` functions
6. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling.md` - tactical task specification

## Expected File Change

**File**: `embed_client/testing_client.py`

**Method**: `EmbeddingServiceClient.embed()` - result handling section (modify lines 271-356)

**Current implementation flow**:
- Lines 325-326: If `wait=True`, call `_embed_via_execute_async()` and return
- Lines 328-355: If `wait=False`, call `jsonrpc_call()`, check for errors, extract job_id, return job metadata or results

**New implementation** (modify lines 325-356):

The result handling logic must be:

1. **When wait=True** (lines 325-326, keep but ensure normalization):
   ```python
   if wait:
       result = await self._embed_via_execute_async(params, wait_timeout)
       # Normalize result to public format
       return _normalize_result_to_public_format(result)
   ```

2. **When wait=False** (replace lines 328-355):
   ```python
   # Call JSON-RPC endpoint
   response = await self._transport.jsonrpc_call("embed", params)
   if "error" in response:
       raise EmbeddingServiceError(
           f"Embedding failed: {response['error']}"
       ) from None
   
   result = response.get("result", {})
   if not result.get("success"):
       error = result.get("error", {})
       raise EmbeddingServiceAPIError(
           {"message": error.get("message", "Unknown error")}
       )
   
   data = result.get("data", {})
   
   # Extract job_id from multiple locations
   extracted_job_id = (
       data.get("job_id")
       or result.get("job_id")
       or (data if isinstance(data, dict) and "job_id" in data else None)
   )
   
   # Check if immediate result (has results/embeddings, no job_id)
   has_results = isinstance(data.get("results"), list) or isinstance(data.get("embeddings"), list)
   
   if not extracted_job_id and has_results:
       # Immediate mode: normalize and return
       return _normalize_result_to_public_format(data)
   
   if not extracted_job_id:
       raise EmbeddingServiceError(
           "No job_id or results returned from server"
       ) from None
   
   # Queued mode: return job metadata
   return {
       "job_id": extracted_job_id,
       "status": data.get("status") or result.get("status", "pending"),
       "message": data.get("message") or result.get("message", "Job queued successfully"),
   }
   ```

**Helper function to add** (add before `embed()` method, or at module level):

```python
def _normalize_result_to_public_format(result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize embed result to public format.
    
    Args:
        result: Result from _embed_via_execute_async or immediate jsonrpc_call response
        
    Returns:
        Public format: {"results": [...], "model": "...", "dimension": N, "device": "..."}
    """
    if not isinstance(result, Dict):
        return {"results": []}
    
    # If already in public format (has results or embeddings at top level)
    if "results" in result:
        return result
    if "embeddings" in result:
        return result
    
    # Try to extract from nested structures
    data = result.get("data", result)
    if isinstance(data, Dict):
        if "results" in data:
            return data
        if "embeddings" in data:
            return data
        if "data" in data:
            nested_data = data["data"]
            if isinstance(nested_data, Dict):
                if "results" in nested_data:
                    return nested_data
                if "embeddings" in nested_data:
                    return nested_data
    
    # Try using parsers
    try:
        wrapped = {"result": {"success": True, "data": result}}
        results = extract_embedding_data(wrapped)
        normalized = {"results": results}
        # Extract model, dimension, device if available
        if isinstance(result, Dict):
            if "model" in result:
                normalized["model"] = result["model"]
            if "dimension" in result:
                normalized["dimension"] = result["dimension"]
            if "device" in result:
                normalized["device"] = result["device"]
        return normalized
    except ValueError:
        try:
            embeddings = extract_embeddings(wrapped)
            normalized = {"embeddings": embeddings}
            if isinstance(result, Dict):
                if "model" in result:
                    normalized["model"] = result["model"]
                if "dimension" in result:
                    normalized["dimension"] = result["dimension"]
                if "device" in result:
                    normalized["device"] = result["device"]
            return normalized
        except ValueError:
            return result if isinstance(result, Dict) else {"results": []}
```

**Exact algorithm for result handling**:

1. **When wait=True** (lines 325-326):
   - Call `await self._embed_via_execute_async(params, wait_timeout)` → `result`
   - Call `_normalize_result_to_public_format(result)` → `normalized_result`
   - Return `normalized_result`

2. **When wait=False** (replace lines 328-355):
   - Call `await self._transport.jsonrpc_call("embed", params)` → `response`
   - If `"error" in response`: raise `EmbeddingServiceError(f"Embedding failed: {response['error']}")`
   - Extract `result = response.get("result", {})`
   - If `not result.get("success")`: extract error and raise `EmbeddingServiceAPIError({"message": error.get("message", "Unknown error")})`
   - Extract `data = result.get("data", {})`
   - Extract job_id: `extracted_job_id = data.get("job_id") or result.get("job_id")`
   - Check for immediate results: `has_results = isinstance(data.get("results"), list) or isinstance(data.get("embeddings"), list)`
   - If `not extracted_job_id and has_results`:
     - Call `_normalize_result_to_public_format(data)` → `normalized_result`
     - Return `normalized_result`
   - If `not extracted_job_id`:
     - Raise `EmbeddingServiceError("No job_id or results returned from server")`
   - Return `{"job_id": extracted_job_id, "status": data.get("status") or result.get("status", "pending"), "message": data.get("message") or result.get("message", "Job queued successfully")}`

## Forbidden Alternatives

- **DO NOT** reimplement transport semantics - use existing `jsonrpc_call()` and `execute_async()` methods
- **DO NOT** hide server semantics - preserve job_id and status when `wait=False`
- **DO NOT** assume all results are immediate - always check for job_id
- **DO NOT** modify adapter transport layer - only use existing methods
- **DO NOT** modify `_embed_via_execute_async()` method - only use it and normalize its result
- **DO NOT** remove error handling - preserve all existing error checks
- **DO NOT** change method signature or parameters
- **DO NOT** modify `wait_for_job()` or `wait_for_job_via_websocket()` methods

## Atomic Operations

1. Read current `embed()` method (lines 271-356)
2. Add helper function `_normalize_result_to_public_format()` (add before `embed()` method or at module level)
3. Modify `wait=True` branch (lines 325-326) to normalize result before returning
4. Replace `wait=False` branch (lines 328-355) with new logic that:
   - Extracts job_id from response
   - Detects immediate vs queued mode
   - Returns job metadata for queued mode (wait=False)
   - Normalizes and returns results for immediate mode
5. Ensure all error handling is preserved
6. Ensure method signature and parameters are unchanged

## Expected Deliverables

- Updated `embed()` method result handling section in `embed_client/testing_client.py`
- New helper function: `_normalize_result_to_public_format()`
- Method correctly detects immediate vs queued modes
- Method returns correct public format for both modes
- All error handling preserved
- Method signature unchanged

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Code formatting**:
   ```bash
   black embed_client/testing_client.py
   ```
   **Expected**: "reformatted" or "already well formatted" (exit code 0)

2. **Linting**:
   ```bash
   flake8 embed_client/testing_client.py
   ```
   **Expected**: No output (exit code 0)

3. **Type checking**:
   ```bash
   mypy embed_client/testing_client.py
   ```
   **Expected**: "Success: no issues found" (exit code 0)

4. **Tests** (if test file exists or is created in a separate step):
   ```bash
   pytest tests/test_embed_result_mode_handling.py::TestEmbedResultModeHandling::test_testing_client_embed_result_modes -v
   ```
   **Expected**: All test cases pass

## Decision Rules

- **Mode detection**: Check for job_id in `data.get("job_id")` and `result.get("job_id")` - if found, it's queued mode; if not and has results/embeddings, it's immediate mode
- **Normalization priority**: Check for `results` or `embeddings` at top level first, then try parsers, then return empty results
- **Model/dimension/device extraction**: Extract from result dict if available, include in normalized result
- **Error handling**: Preserve all existing error checks and raise same exception types
- **wait=True path**: Keep using `_embed_via_execute_async()`, but normalize result before returning

## Blackstops

**STOP and escalate** if:
- Transport response format changes require different extraction logic
- `_embed_via_execute_async()` return format changes significantly
- Public format requirements change (must match tactical task specification)
- Method signature must change (breaks existing callers)

## Handoff Package

**For coder_auto**:

1. **Target file**: `embed_client/testing_client.py`
2. **Method to modify**: `EmbeddingServiceClient.embed()` - result handling section (lines 271-356)
3. **Helper function to add**: `_normalize_result_to_public_format()` (add before `embed()` method or at module level)
4. **Imports** (check if present, add if missing):
   - `from typing import Any, Dict, List, Optional`
   - `from embed_client.exceptions import EmbeddingServiceError, EmbeddingServiceAPIError, EmbeddingServiceTimeoutError`
   - `from embed_client.response_parsers import extract_embedding_data, extract_embeddings`
5. **Implementation requirements**:
   - When `wait=True`: call `_embed_via_execute_async()`, normalize result, return
   - When `wait=False`: call `jsonrpc_call()`, extract job_id, detect mode, return job metadata or normalized results
   - Preserve all error handling
   - Normalize all results to public format
6. **Edge cases**:
   - Non-dict response → raise appropriate error
   - Missing job_id and no results → raise `EmbeddingServiceError`
   - Missing results/embeddings in normalized data → return empty results list
   - Parser exceptions → try alternative parser, then return empty results
7. **Validation commands**: See "Mandatory Validation" section above
8. **Completion condition**: All validation commands pass, method handles both immediate and queued modes correctly

## Constants and Literals

- **Default status**: `"pending"` (used when status not found in queued response)
- **Default message**: `"Job queued successfully"` (used when message not found in queued response)
- **Error message**: `"Embedding failed: {response['error']}"` (preserve existing format)
- **Error message**: `"No job_id or results returned from server"` (preserve existing format)
