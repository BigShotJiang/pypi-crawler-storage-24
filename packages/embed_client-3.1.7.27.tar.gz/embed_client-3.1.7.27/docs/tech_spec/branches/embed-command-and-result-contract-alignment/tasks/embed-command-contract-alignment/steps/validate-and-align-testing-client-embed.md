Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Validate and Align EmbeddingServiceClient.embed()

## Executor Role

**Executor**: `coder_auto`

**Execution directive**: Implement parameter validation and ensure canonical contract alignment for `EmbeddingServiceClient.embed()` method.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-command-contract-alignment.md`

## Step Scope

**Target file**: `embed_client/testing_client.py`

**Action**: modify

**Method to modify**: `EmbeddingServiceClient.embed()` (lines 271-339)

## Dependency Contract

**Dependencies**: None (can run in parallel with step for `async_client_api_mixin.py`)

**Dependents**: Result parsing steps (separate tactical task)

## Required Context

This step ensures the `embed()` method in `EmbeddingServiceClient`:
1. Validates `texts` parameter is a non-empty list of strings
2. Builds canonical request params dict with all server-expected parameters
3. Does not depend on server-side `text` to `texts` normalization

## Read First

Before starting implementation, read these files in order:

1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - overall architecture
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-command-contract-alignment.md` - tactical task details
3. `/home/vasilyvz/projects/embed-client/embed_client/testing_client.py` - current implementation (lines 271-339)
4. `/home/vasilyvz/projects/embed-client/embed_client/constants.py` - `EMBED_DEFAULT_ERROR_POLICY` constant

## Expected File Change

**File**: `embed_client/testing_client.py`

**Changes**:
1. Add parameter validation at the start of `embed()` method (after line 309, before line 310)
2. Ensure canonical params dict building is correct (verify lines 311-323)

## Forbidden Alternatives

**DO NOT**:
- Accept `text` parameter (singular) - only `texts` (plural list)
- Depend on server-side normalization from `text` to `texts`
- Skip parameter validation - always validate `texts` is non-empty list of strings
- Modify adapter transport layer - only use existing transport methods
- Implement result parsing in this step - that is handled by separate tactical task
- Modify identifier handling - JSON-RPC id, job_id, WebSocket correlation are handled in Step 3
- Use `Any` type annotation for `texts` parameter
- Add methods not listed in this step
- Modify files other than the target file
- Use `print()` for logging; use the project logger
- Use bare `except:`

## Atomic Operations

### Operation 1: Add Parameter Validation

**Location**: After line 309 (end of docstring), before line 310 (start of method body: `del poll_interval, use_push`)

**Code to add**:
```python
        # Validate texts parameter
        if not isinstance(texts, list):
            raise ValueError("texts must be a list")
        if len(texts) == 0:
            raise ValueError("texts must be a non-empty list")
        if not all(isinstance(t, str) for t in texts):
            raise ValueError("texts must contain only strings")
```

**Algorithm**:
1. Check if `texts` is a list using `isinstance(texts, list)`
2. If not a list: raise `ValueError` with message `"texts must be a list"`
3. Check if `texts` is non-empty using `len(texts) == 0`
4. If empty: raise `ValueError` with message `"texts must be a non-empty list"`
5. Check if all items are strings using `all(isinstance(t, str) for t in texts)`
6. If any item is not a string: raise `ValueError` with message `"texts must contain only strings"`

### Operation 2: Verify Canonical Params Building

**Location**: Lines 311-323 (existing code, verify correctness)

**Current code** (verify it matches this exactly):
```python
        params: Dict[str, Any] = {"texts": texts}
        if model is not None:
            params["model"] = model
        if dimension is not None:
            params["dimension"] = dimension
        if job_id is not None:
            params["job_id"] = job_id
        if error_policy is not None:
            params["error_policy"] = error_policy
        else:
            params["error_policy"] = EMBED_DEFAULT_ERROR_POLICY
        if device is not None:
            params["device"] = device
```

**Verification checklist**:
- [ ] `params` dict starts with `{"texts": texts}` (canonical parameter)
- [ ] `model` is added only if `model is not None`
- [ ] `dimension` is added only if `dimension is not None`
- [ ] `job_id` is added only if `job_id is not None`
- [ ] `error_policy` is always set (defaults to `EMBED_DEFAULT_ERROR_POLICY` if `error_policy is None`)
- [ ] `device` is added only if `device is not None`

**If verification fails**: Fix the code to match the expected behavior above.

**Note**: The current code uses `if device is not None:` without `.strip()`. This is acceptable for this client, but if `device` can be an empty string, consider adding `and device.strip()` check. However, since the tactical task does not specify this change, keep current behavior unless it causes issues.

## Expected Deliverables

1. **Modified file**: `embed_client/testing_client.py`
   - Parameter validation added at start of `embed()` method
   - Canonical params building verified/corrected

2. **Validation**: All existing tests pass, new validation tests pass

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Format check**:
   ```bash
   black embed_client/testing_client.py
   ```
   **Expected**: "reformatted" or "All done! ✨ 🍰 ✨" or "already well formatted"

2. **Lint check**:
   ```bash
   flake8 embed_client/testing_client.py
   ```
   **Expected**: No output (exit code 0)

3. **Type check**:
   ```bash
   mypy embed_client/testing_client.py
   ```
   **Expected**: "Success: no issues found" (or existing type issues that are not related to this change)

4. **Run existing tests**:
   ```bash
   pytest tests/ -k "embed" -v
   ```
   **Expected**: All tests pass (or existing failures unrelated to this change)

5. **Run validation tests** (if test file exists or is created in separate step):
   ```bash
   pytest tests/test_embed_command_contract.py::TestEmbedCommandContract::test_testing_client_embed_contract -v
   ```
   **Expected**: Test passes

## Decision Rules

1. **Parameter validation order**: Validate type first, then length, then item types (most specific error first)
2. **Error messages**: Use exact messages specified in "Atomic Operations" section
3. **Canonical params**: Always include `texts`, always include `error_policy` (with default), conditionally include others

## Blackstops

**STOP and escalate** if:
- Parameter validation rules conflict with existing public API compatibility requirements
- Transport layer needs modification (affects adapter architecture)

## Handoff Package

**For coder_auto**:

1. **Target file**: `embed_client/testing_client.py`
2. **Method to modify**: `EmbeddingServiceClient.embed()` (lines 271-339)
3. **Primary change**: Add parameter validation after docstring (after line 309)
4. **Secondary change**: Verify canonical params building (lines 311-323)
5. **Validation**: Run black, flake8, mypy, pytest
6. **Success criteria**: All tests pass, validation added, canonical contract verified

## File Header

**No changes to file header** - existing header is correct.

## Complete Import List

**No new imports needed** - use existing imports:
- `from typing import Any, Dict, List, Optional` (already imported)
- `from embed_client.constants import EMBED_DEFAULT_ERROR_POLICY` (already imported at line 24)
- `isinstance()` and `all()` are built-in functions

## Class/Method Skeleton

**Class**: `EmbeddingServiceClient` (no base class)

**Method signature** (no changes to signature):
```python
async def embed(
    self,
    texts: List[str],
    model: Optional[str] = None,
    dimension: Optional[int] = None,
    job_id: Optional[str] = None,
    error_policy: Optional[str] = None,
    device: Optional[str] = None,
    wait: bool = False,
    wait_timeout: int = 60,
    poll_interval: float = 1.0,
    use_push: bool = True,
) -> Dict[str, Any]:
```

**Method docstring**: Keep existing docstring (lines 284-309)

## Method Logic - Step-by-Step Algorithm

**Method**: `embed()` - add validation at start

**Algorithm for validation** (add after docstring, before line 310):
1. Check `isinstance(texts, list)` → if False: raise `ValueError("texts must be a list")`
2. Check `len(texts) == 0` → if True: raise `ValueError("texts must be a non-empty list")`
3. Check `all(isinstance(t, str) for t in texts)` → if False: raise `ValueError("texts must contain only strings")`
4. Continue with existing method body (params building, transport call)

**Algorithm for canonical params building** (verify existing code at lines 311-323):
1. Initialize `params: Dict[str, Any] = {"texts": texts}`
2. If `model is not None`: set `params["model"] = model`
3. If `dimension is not None`: set `params["dimension"] = dimension`
4. If `job_id is not None`: set `params["job_id"] = job_id`
5. If `error_policy is not None`: set `params["error_policy"] = error_policy`
6. Else: set `params["error_policy"] = EMBED_DEFAULT_ERROR_POLICY` (always set)
7. If `device is not None`: set `params["device"] = device`
8. Continue with existing transport call logic

## Error Handling Per Method

**Method**: `embed()`

**Parameter validation errors**:
- **Exception**: `ValueError`
- **Condition**: `texts` is not a list
- **Message**: `"texts must be a list"`
- **Action**: Raise immediately, do not catch

- **Exception**: `ValueError`
- **Condition**: `texts` is empty list
- **Message**: `"texts must be a non-empty list"`
- **Action**: Raise immediately, do not catch

- **Exception**: `ValueError`
- **Condition**: `texts` contains non-string items
- **Message**: `"texts must contain only strings"`
- **Action**: Raise immediately, do not catch

**Transport errors**:
- **Exception**: `EmbeddingServiceError` (from transport)
- **Condition**: Transport fails
- **Message**: Transport error message
- **Action**: Let exception propagate (existing error handling in method)

## Return Value Specification

**Method**: `embed()`

**Return type**: `Dict[str, Any]`

**Return value**: Unchanged from existing implementation - result parsing is handled by separate tactical task. This step only ensures:
- Parameter validation happens before any processing
- Canonical params dict is built correctly

## Edge Cases

**Edge cases for parameter validation**:
- `texts = []` → raise `ValueError("texts must be a non-empty list")`
- `texts = None` → raise `ValueError("texts must be a list")` (or `TypeError` if `isinstance(None, list)` is False, but `isinstance()` will catch it)
- `texts = "single string"` → raise `ValueError("texts must be a list")`
- `texts = [1, 2, 3]` → raise `ValueError("texts must contain only strings")`
- `texts = ["valid", 123, "also valid"]` → raise `ValueError("texts must contain only strings")`
- `texts = [""]` → valid (empty string is still a string, list is non-empty)
- `texts = ["text1", "text2"]` → valid

**Edge cases for canonical params**:
- `model = None` → do not add to params
- `dimension = None` → do not add to params
- `job_id = None` → do not add to params
- `error_policy = None` → use `EMBED_DEFAULT_ERROR_POLICY` ("fail_fast")
- `error_policy = "continue"` → use `"continue"`
- `device = None` → do not add to params
- `device = ""` → add `"device": ""` (current behavior, keep as-is)

## Exact Constants and Literals

**Constants used**:
- `EMBED_DEFAULT_ERROR_POLICY` - imported from `embed_client.constants`, value is `"fail_fast"` (string)

**String literals**:
- `"texts must be a list"` - error message for non-list input
- `"texts must be a non-empty list"` - error message for empty list
- `"texts must contain only strings"` - error message for non-string items

## Test Expectations

**Test file**: `tests/test_embed_command_contract.py` (may need to be created in separate step)

**Test class**: `TestEmbedCommandContract`

**Test method to verify** (if test exists):
- `test_testing_client_embed_contract()` - asserts transport called with canonical `texts` parameter, not `text`, and validation works correctly

**If tests don't exist**: This step does not create tests - tests are created in separate step. This step only implements the validation and verifies existing code correctness.
