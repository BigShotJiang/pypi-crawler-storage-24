Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Align models() and timing_stats() in AsyncClientAPIMixin

## Executor Role

**Executor**: `coder_auto` (weak model implementation agent)

## Execution Directive

Modify the `models()` and `timing_stats()` methods in `embed_client/async_client_api_mixin.py` to align with the server command contract. Ensure both methods correctly normalize server responses from various response shapes to stable public formats.

## Parent Links

- **Tech spec**: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step**: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- **Parent tactical task**: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/models-timing-stats-alignment.md`

## Step Scope

**Target file**: `embed_client/async_client_api_mixin.py`  
**Action**: modify  
**Lines to modify**: 
- `models()` method: lines 272-284
- `timing_stats()` method: lines 286-312

## Dependency Contract

**Dependencies**: None (can run in parallel with other atomic steps)

**Dependents**: None (this step does not block other steps)

## Required Context

1. The `cmd()` method (lines 148-270) already calls `self._adapter_transport.execute_command_unified()` which handles adapter transport.
2. Server responses can have multiple shapes:
   - `{"result": {"models": [...]}}`
   - `{"result": {"data": {"models": [...]}}}`
   - `{"result": [...]}` (direct list for models)
   - `{"result": {"total_requests": ..., ...}}` (direct dict for timing_stats)
   - `{"result": {"data": {"total_requests": ..., ...}}}`
3. The `cmd()` method returns a dict with `{"result": ...}` structure.
4. Both methods must return normalized public formats that are stable regardless of server response shape.

## Read First

Before starting implementation, read these files in order:

1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - understand overall architecture
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md` - understand global step context
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/models-timing-stats-alignment.md` - understand tactical task requirements
4. `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` - current implementation (lines 272-312)
5. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - understand how `cmd()` uses adapter transport

## Expected File Change

**File**: `embed_client/async_client_api_mixin.py`

**Changes**:

1. **Method `models()` (lines 272-284)**:
   - Keep existing call to `self.cmd("models")`
   - Replace current normalization logic with comprehensive response shape handling
   - Handle three response shapes:
     - `{"result": {"models": [...]}}` → extract `result["result"]["models"]`
     - `{"result": {"data": {"models": [...]}}}` → extract `result["result"]["data"]["models"]`
     - `{"result": [...]}` → extract `result["result"]` directly (if it's a list)
   - Return normalized format: `{"models": [...]}` where the list contains model info dicts
   - If models cannot be extracted, return `{"models": []}`

2. **Method `timing_stats()` (lines 286-312)**:
   - Add parameter validation: if `file_path is not None` and not `isinstance(file_path, str)`, raise `ValueError("file_path must be a string or None")`
   - Modify params building: if `file_path is not None and file_path.strip()`, set `params = {"file_path": file_path.strip()}`, else `params = {}`
   - Keep existing call to `self.cmd("timing_stats", params=params or None)`
   - Replace current normalization logic with comprehensive response shape handling
   - Handle two response shapes:
     - `{"result": {"total_requests": ..., ...}}` → extract `result["result"]` directly
     - `{"result": {"data": {"total_requests": ..., ...}}}` → extract `result["result"]["data"]`
   - Return normalized format: dict with timing stats keys (`total_requests`, `success_count`, `encode_seconds`, `rpc_seconds`, `by_device`, `batch_vs_single`, `calculation_time_seconds`, etc.)
   - If timing stats cannot be extracted, return `{}`

## Forbidden Alternatives

1. **DO NOT** reimplement transport semantics - use `cmd()` method which already uses adapter transport
2. **DO NOT** assume a single response format - handle all documented response shapes
3. **DO NOT** skip parameter validation for `file_path` in `timing_stats()`
4. **DO NOT** modify `cmd()` method - only use it
5. **DO NOT** modify adapter transport layer
6. **DO NOT** hardcode response structure - normalize flexibly
7. **DO NOT** use `Any` type annotation - use proper types
8. **DO NOT** add methods not listed in this step
9. **DO NOT** modify files other than the target file
10. **DO NOT** use `print()` for logging - use the project logger if needed

## Atomic Operations

### Operation 1: Modify `models()` method

**Location**: Lines 272-284 in `embed_client/async_client_api_mixin.py`

**Current signature** (keep):
```python
async def models(self) -> Dict[str, Any]:
```

**New implementation algorithm**:

1. Call `result = await self.cmd("models")`
   - This returns a dict with structure `{"result": ...}`

2. Extract models list from response (handle multiple shapes):
   - Let `result_data = result.get("result", {})`
   - If `result_data` is a dict and `"models" in result_data`:
     - Set `models_list = result_data["models"]`
   - Else if `result_data` is a dict and `"data" in result_data`:
     - Let `nested_data = result_data["data"]`
     - If `nested_data` is a dict and `"models" in nested_data`:
       - Set `models_list = nested_data["models"]`
     - Else:
       - Set `models_list = []`
   - Else if `result_data` is a list:
     - Set `models_list = result_data`
   - Else:
     - Set `models_list = []`

3. Validate `models_list`:
   - If `models_list` is not a list, set `models_list = []`

4. Return normalized format:
   - Return `{"models": models_list}`

**Error handling**:
- If `cmd()` raises `EmbeddingServiceAPIError` or `EmbeddingServiceError`, let it propagate (do not catch)
- If response format is unexpected and models cannot be extracted, return `{"models": []}` (do not raise exception)

### Operation 2: Modify `timing_stats()` method

**Location**: Lines 286-312 in `embed_client/async_client_api_mixin.py`

**Current signature** (modify parameter validation):
```python
async def timing_stats(
    self,
    file_path: Optional[str] = None,
) -> Dict[str, Any]:
```

**New implementation algorithm**:

1. Validate `file_path` parameter:
   - If `file_path is not None` and not `isinstance(file_path, str)`:
     - Raise `ValueError("file_path must be a string or None")`

2. Build params dict:
   - If `file_path is not None and file_path.strip()`:
     - Set `params = {"file_path": file_path.strip()}`
   - Else:
     - Set `params = {}`

3. Call `result = await self.cmd("timing_stats", params=params or None)`
   - This returns a dict with structure `{"result": ...}`

4. Extract timing stats from response (handle multiple shapes):
   - Let `result_data = result.get("result", {})`
   - If `result_data` is a dict and (`"total_requests" in result_data` or `"success_count" in result_data`):
     - Set `stats = result_data`
   - Else if `result_data` is a dict and `"data" in result_data`:
     - Let `nested_data = result_data["data"]`
     - If `nested_data` is a dict:
       - Set `stats = nested_data`
     - Else:
       - Set `stats = {}`
   - Else if `result_data` is a dict:
     - Set `stats = result_data`
   - Else:
     - Set `stats = {}`

5. Return normalized format:
   - Return `stats` dict directly

**Error handling**:
- If parameter validation fails, raise `ValueError` with exact message: `"file_path must be a string or None"`
- If `cmd()` raises `EmbeddingServiceAPIError` or `EmbeddingServiceError`, let it propagate (do not catch)
- If response format is unexpected and timing stats cannot be extracted, return `{}` (do not raise exception)

## Expected Deliverables

1. Modified `embed_client/async_client_api_mixin.py` with:
   - Updated `models()` method that handles all three response shapes
   - Updated `timing_stats()` method with parameter validation and all two response shapes
   - Both methods return normalized public formats
   - No changes to other methods or file structure

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Format check**:
   ```bash
   black embed_client/async_client_api_mixin.py
   ```
   **Expected**: "reformatted" or "already well formatted" (exit code 0)

2. **Lint check**:
   ```bash
   flake8 embed_client/async_client_api_mixin.py
   ```
   **Expected**: No output (exit code 0)

3. **Type check**:
   ```bash
   mypy embed_client/async_client_api_mixin.py
   ```
   **Expected**: "Success: no issues found" (exit code 0)

4. **Tests** (if test file exists):
   ```bash
   pytest tests/test_models_timing_stats_alignment.py::TestModelsTimingStatsAlignment::test_models_normalizes_response_shapes -v
   pytest tests/test_models_timing_stats_alignment.py::TestModelsTimingStatsAlignment::test_timing_stats_normalizes_response -v
   pytest tests/test_models_timing_stats_alignment.py::TestModelsTimingStatsAlignment::test_timing_stats_validates_file_path -v
   ```
   **Expected**: All tests PASSED

**Completion condition**: All validation commands must pass. All tests must pass.

## Decision Rules

1. **Response shape detection**: Check for keys in order: first check top-level keys in `result["result"]`, then check nested `result["result"]["data"]`, then check if `result["result"]` is a list/dict directly.

2. **Empty response handling**: If models cannot be extracted, return `{"models": []}`. If timing stats cannot be extracted, return `{}`. Do not raise exceptions for normalization failures.

3. **Parameter validation**: Only validate `file_path` type. Do not validate file path existence or format (server will handle that).

4. **Whitespace handling**: Strip `file_path` before adding to params if it's not None and not empty.

5. **Params dict**: Use `params or None` when calling `cmd()` to pass `None` if params is empty dict (allows `cmd()` to handle empty params correctly).

## Blackstops

**STOP and escalate** if:
- `cmd()` method signature changes in a way that breaks these method calls
- Server response format requires breaking changes to public API
- Adapter transport layer changes require modifications beyond using `cmd()`

## Handoff Package

**For coder_auto**:

1. **Target file**: `embed_client/async_client_api_mixin.py`
2. **Methods to modify**: 
   - `models()` (lines 272-284)
   - `timing_stats()` (lines 286-312)
3. **Key requirements**:
   - `models()`: Handle 3 response shapes, return `{"models": [...]}`
   - `timing_stats()`: Validate `file_path`, handle 2 response shapes, return timing stats dict
4. **Validation**: Run black, flake8, mypy, and relevant tests
5. **No guessing**: All response shapes, error conditions, and return formats are explicitly specified above

## Constants and Literals

**No new constants needed** - use existing imports and types:
- `Dict[str, Any]` from `typing`
- `Optional[str]` from `typing`
- `ValueError` (built-in)
- String literal: `"file_path must be a string or None"` (exact message for ValueError)
- String literal: `"models"` (key name in response)
- String literal: `"data"` (key name in nested response)
- String literal: `"total_requests"` (key name for timing stats detection)
- String literal: `"success_count"` (key name for timing stats detection)

## File Header

**Keep existing file header** (lines 1-6):
```python
"""
Core API methods for EmbeddingServiceAsyncClient (embed, cmd, health, etc.).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
```

## Complete Import List

**Keep existing imports** (no changes needed):
```python
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from embed_client.constants import EMBED_DEFAULT_ERROR_POLICY
from embed_client.exceptions import (
    EmbeddingServiceAPIError,
    EmbeddingServiceError,
    EmbeddingServiceTimeoutError,
)
from embed_client.response_normalizer import ResponseNormalizer
from embed_client.response_parsers import (
    extract_embedding_data,
    extract_embeddings,
)
```

## Edge Cases

### For `models()` method:

1. **Empty response**: `{"result": {}}` → return `{"models": []}`
2. **Missing result key**: `{}` → return `{"models": []}`
3. **Result is None**: `{"result": None}` → return `{"models": []}`
4. **Result is string**: `{"result": "error"}` → return `{"models": []}`
5. **Nested data is not dict**: `{"result": {"data": "string"}}` → return `{"models": []}`
6. **Models key exists but value is not list**: `{"result": {"models": "not a list"}}` → return `{"models": []}`

### For `timing_stats()` method:

1. **file_path is None**: No params sent → server uses default
2. **file_path is empty string**: No params sent → server uses default
3. **file_path is whitespace only**: No params sent (after strip) → server uses default
4. **file_path is non-string**: Raise `ValueError("file_path must be a string or None")`
5. **Empty response**: `{"result": {}}` → return `{}`
6. **Missing result key**: `{}` → return `{}`
7. **Result is None**: `{"result": None}` → return `{}`
8. **Nested data is not dict**: `{"result": {"data": "string"}}` → return `{}`
