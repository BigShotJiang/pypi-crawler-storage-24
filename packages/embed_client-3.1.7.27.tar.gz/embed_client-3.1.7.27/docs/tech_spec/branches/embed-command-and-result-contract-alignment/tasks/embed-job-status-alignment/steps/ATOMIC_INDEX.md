Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Embed Job Status Alignment

## Goal

Ensure the client correctly uses the `embed_job_status` command for embed-specific job status queries, while maintaining compatibility with the generic `queue_get_job_status` command. All job status methods must normalize responses from both endpoints to a consistent format.

## Atomic Steps Summary

**Total steps**: 3
**Dependency order**: Sequential (Step 1 → Step 2, Step 1 → Step 3 can run in parallel after Step 1)

### Step 1: AdapterTransport.queue_get_job_status() Endpoint Selection

**File**: `adapter-transport-queue-get-job-status.md`
**Target file**: `embed_client/adapter_transport.py`
**Method**: `AdapterTransport.queue_get_job_status(job_id: str) -> Dict[str, Any]`
**Purpose**: Modify `queue_get_job_status()` to try `embed_job_status` first, fall back to `queue_get_job_status`, and normalize responses.

**Dependencies**: None
**Dependents**: Step 2

### Step 2: AsyncClientQueueMixin Job Status Methods

**File**: `async-client-queue-mixin-job-status-methods.md`
**Target file**: `embed_client/async_client_queue_mixin.py`
**Methods**: 
- `AsyncClientQueueMixin.job_status(job_id: str) -> Dict[str, Any]`
- `AsyncClientQueueMixin.get_job_status_or_result(job_id: str, timeout: Optional[float] = None) -> Dict[str, Any]`
- `AsyncClientQueueMixin.wait_for_job(job_id: str, timeout: Optional[float] = None, poll_interval: float = DEFAULT_POLL_INTERVAL) -> Dict[str, Any]`

**Purpose**: Update queue mixin methods to correctly handle normalized job status responses from `queue_get_job_status()`.

**Dependencies**: Step 1
**Dependents**: None

### Step 3: EmbeddingServiceClient.job_status() Endpoint Selection

**File**: `testing-client-job-status.md`
**Target file**: `embed_client/testing_client.py`
**Method**: `EmbeddingServiceClient.job_status(job_id: str) -> Dict[str, Any]`
**Purpose**: Update `job_status()` to try `embed_job_status` first, fall back to `queue_get_job_status`, and normalize responses.

**Dependencies**: Step 1 (for consistency, but uses `jsonrpc_call` directly)
**Dependents**: None

## Dependency Graph

```
Step 1 (adapter_transport.queue_get_job_status)
    ├──> Step 2 (async_client_queue_mixin methods)
    └──> Step 3 (testing_client.job_status) [can run in parallel with Step 2]
```

## Execution Order

1. **Step 1** must be completed first (foundation for endpoint selection and normalization)
2. **Step 2** and **Step 3** can run in parallel after Step 1 (they use different files and don't depend on each other)

## Files Modified

1. `embed_client/adapter_transport.py` - endpoint selection in `queue_get_job_status()`
2. `embed_client/async_client_queue_mixin.py` - handle normalized responses in queue methods
3. `embed_client/testing_client.py` - endpoint selection in `job_status()`

## Expected Outcome

After all steps:
- Client uses `embed_job_status` command for embed job status queries when available
- Client falls back to `queue_get_job_status` for generic queue jobs or when embed command is not available
- All job status methods normalize responses from both endpoints to consistent format
- Public API methods work correctly with both endpoints
