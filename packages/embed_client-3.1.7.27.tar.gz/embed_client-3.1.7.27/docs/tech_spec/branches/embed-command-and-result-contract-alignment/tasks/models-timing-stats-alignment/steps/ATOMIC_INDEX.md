Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Models and Timing Stats Alignment

## Parent Links

- **Tech spec**: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- **Parent global step**: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- **Parent tactical task**: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/models-timing-stats-alignment.md`

## Goal

Align `models()` and `timing_stats()` methods in both `AsyncClientAPIMixin` and `EmbeddingServiceClient` with the server command contract. Ensure proper parameter validation and response normalization for various server response shapes.

## Atomic Steps Summary

### Total Steps: 2

1. **Step 1**: `async-client-api-mixin-models-timing-stats.md`
   - **Target**: `embed_client/async_client_api_mixin.py`
   - **Action**: Modify `models()` and `timing_stats()` methods
   - **Dependencies**: None

2. **Step 2**: `testing-client-models-timing-stats.md`
   - **Target**: `embed_client/testing_client.py`
   - **Action**: Modify `models()` method and add `timing_stats()` method
   - **Dependencies**: None

## Dependency Order

Both steps are independent and can be executed in parallel:
- Step 1 modifies `AsyncClientAPIMixin` class
- Step 2 modifies `EmbeddingServiceClient` class
- No shared code or dependencies between steps

## Parallel Execution

Both steps can be executed in **Wave 1** (parallel).

See `ATOMIC_PARALLEL_WAVES.md` for detailed parallel execution plan.

## Step Details

### Step 1: async-client-api-mixin-models-timing-stats.md

**File**: `embed_client/async_client_api_mixin.py`

**Changes**:
- Modify `models()` method (lines 272-284): Handle 3 response shapes, return `{"models": [...]}`
- Modify `timing_stats()` method (lines 286-312): Add parameter validation, handle 2 response shapes, return timing stats dict

**Key Requirements**:
- Use `cmd()` method which calls adapter transport
- Normalize responses from multiple server shapes
- Validate `file_path` parameter in `timing_stats()`

### Step 2: testing-client-models-timing-stats.md

**File**: `embed_client/testing_client.py`

**Changes**:
- Modify `models()` method (lines 503-516): Handle 3+ response shapes, return `{"models": [...]}`
- Add `timing_stats()` method (new): Validate `file_path`, handle 2+ response shapes, return timing stats dict

**Key Requirements**:
- Use `_transport.jsonrpc_call()` directly (not `cmd()`)
- Normalize responses from multiple server shapes
- Add new `timing_stats()` method after `models()` method

## Validation Requirements

After all steps complete:
1. Run `black` on both modified files
2. Run `flake8` on both modified files
3. Run `mypy` on both modified files
4. Run tests: `pytest tests/test_models_timing_stats_alignment.py -v`

All validation must pass before considering the tactical task complete.
