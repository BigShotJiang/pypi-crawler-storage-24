Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: EmbeddingServiceClient.job_status() Endpoint Selection

## Executor Role

**coder_auto** - Update `job_status()` method in `EmbeddingServiceClient` to try `embed_job_status` first, then fall back to `queue_get_job_status`, and normalize both response formats consistently.

## Execution Directive

Modify the `job_status()` method in `EmbeddingServiceClient` class to try `embed_job_status` command first via `execute_command_unified`, then fall back to `queue_get_job_status` if the embed-specific command is not available. Normalize responses from both endpoints to a consistent format.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-job-status-alignment.md`

## Step Scope

**Target file**: `embed_client/testing_client.py`
**Action**: modify
**Target method**: `EmbeddingServiceClient.job_status(job_id: str) -> Dict[str, Any]`
**Lines to modify**: 471-501

## Dependency Contract

**Dependencies**: 
- Step 1: `adapter-transport-queue-get-job-status.md` should be completed (for consistency, but this method uses `jsonrpc_call` directly)

**Dependents**: None (this is a public API method)

## Required Context

The `EmbeddingServiceClient` uses `_transport.jsonrpc_call()` to make direct JSON-RPC calls. Current implementation:
1. Tries `queue_get_job_status` first
2. Falls back to `embed_job_status` if first fails

New requirement:
1. Try `embed_job_status` first (embed-specific command)
2. Fall back to `queue_get_job_status` if embed command is not available
3. Normalize both response formats to consistent shape

Response formats:
- `embed_job_status`: `{"result": {"success": bool, "data": {"job_id": str, "status": str, "message": str, "result": Optional[Dict], "error": Optional[str]}}}`
- `queue_get_job_status`: `{"result": {"job_id": str, "status": str, "message": str, "result": Optional[Dict], "error": Optional[str]}}` OR `{"result": {"success": bool, "data": {...}}}`

Normalized format:
```python
{
    "job_id": str,
    "status": str,
    "message": str,
    "result": Optional[Dict[str, Any]],
    "error": Optional[str]
}
```

## Read First

1. `/home/vasilyvz/projects/embed-client/embed_client/testing_client.py` - current implementation
2. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - understand `jsonrpc_call()` method
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-job-status-alignment.md` - full requirements

## Expected File Change

**File**: `embed_client/testing_client.py`

**Method signature** (unchanged):
```python
async def job_status(self, job_id: str) -> Dict[str, Any]:
```

**Method implementation changes**:
1. Try calling `embed_job_status` command first via `jsonrpc_call()`
2. Check for JSON-RPC error response (key `"error"` in response)
3. If `embed_job_status` fails with method-not-found error, fall back to `queue_get_job_status`
4. Normalize response from either endpoint to consistent format
5. Return normalized dict

**Import changes**: No new imports needed (all required types already imported)

## Forbidden Alternatives

1. **DO NOT** use `queue_get_job_status()` method from adapter_transport - use `jsonrpc_call()` directly
2. **DO NOT** change method signature or return type
3. **DO NOT** skip normalization - both endpoints return different shapes
4. **DO NOT** modify other methods in this file
5. **DO NOT** remove existing error handling patterns

## Atomic Operations

### Method: `job_status(job_id: str) -> Dict[str, Any]`

**Step-by-step algorithm**:

1. Try block: call `embed_job_status` first
   - Call: `response = await self._transport.jsonrpc_call("embed_job_status", {"job_id": job_id})`
   - Check if response has `"error"` key:
     - If `"error"` exists: check error code
       - If error code is -32601 (method not found) or error message contains "not found"/"not available": proceed to fallback step 2
       - Else: raise `EmbeddingServiceAPIError` with error message
     - If no error: proceed to normalization step 3
2. Fallback: if `embed_job_status` failed with method-not-found
   - Call: `response = await self._transport.jsonrpc_call("queue_get_job_status", {"job_id": job_id})`
   - Check if response has `"error"` key:
     - If `"error"` exists: raise `EmbeddingServiceAPIError` with error message
     - Else: proceed to normalization step 3
3. Normalize response:
   - Extract `result = response.get("result", {})`
   - Check if `result` is a dict
   - If `result.get("success")` is True and `result.get("data")` exists (embed_job_status format):
     - Extract `data = result["data"]`
     - Build normalized: `{"job_id": data.get("job_id", job_id), "status": data.get("status", "unknown"), "message": data.get("message", ""), "result": data.get("result"), "error": data.get("error")}`
   - Else if `result` has direct keys like `"job_id"`, `"status"` (queue format):
     - Build normalized: `{"job_id": result.get("job_id", job_id), "status": result.get("status", "unknown"), "message": result.get("message", ""), "result": result.get("result"), "error": result.get("error")}`
   - Else if `result` is empty or not a dict:
     - Create minimal normalized: `{"job_id": job_id, "status": "unknown", "message": "", "result": None, "error": None}`
4. Return normalized dict

**Error handling**:
- If `embed_job_status` returns `{"error": {"code": -32601, "message": "Method not found"}}`: catch by checking error code, fall back to `queue_get_job_status`
- If `embed_job_status` returns `{"error": {...}}` with other code: raise `EmbeddingServiceAPIError({"message": str(response["error"])})`
- If `queue_get_job_status` returns `{"error": {...}}`: raise `EmbeddingServiceAPIError({"message": str(response["error"])})`
- If `result.get("success")` is False: extract error from `result.get("error", {})` and raise `EmbeddingServiceAPIError({"message": error.get("message", "Unknown error")})`
- If normalization fails (e.g., result is None): return minimal dict with `{"job_id": job_id, "status": "unknown", "message": "", "result": None, "error": None}`

**Return value**: Dict with keys: `job_id` (str), `status` (str), `message` (str), `result` (Optional[Dict]), `error` (Optional[str])

**Edge cases**:
- `job_id` is empty string: use as-is, don't validate
- `embed_job_status` returns None: fall back to `queue_get_job_status`
- `embed_job_status` returns non-dict: fall back to `queue_get_job_status`
- Response missing `result` key: create minimal normalized dict
- Response `result` is not a dict: create minimal normalized dict
- Response missing `status` key: use `"unknown"` as default
- Response missing `job_id` in nested structure: use input `job_id` parameter
- `result.get("success")` is False: raise `EmbeddingServiceAPIError` with error message from `result.get("error", {})`

## Expected Deliverables

1. Modified `job_status()` method in `embed_client/testing_client.py`
2. Method tries `embed_job_status` first, falls back to `queue_get_job_status`
3. Method normalizes responses from both endpoints to consistent format
4. Method handles all error cases appropriately
5. Method returns normalized dict with all required keys

## Mandatory Validation

**Validation commands** (run from project root):

1. **Code formatting**:
   ```bash
   black embed_client/testing_client.py
   ```
   Expected: "reformatted" or "already well formatted"

2. **Linting**:
   ```bash
   flake8 embed_client/testing_client.py
   ```
   Expected: no output (exit code 0)

3. **Type checking**:
   ```bash
   mypy embed_client/testing_client.py
   ```
   Expected: "Success: no issues found"

**Test expectations**: Tests for this method should be written in a separate test step. This step only implements the production code.

## Decision Rules

1. **Error detection**: Check JSON-RPC error response format: `{"error": {"code": int, "message": str}}`
2. **Method-not-found detection**: Error code -32601 OR error message contains "not found", "not available", "method not found" (case-insensitive)
3. **Normalization priority**: Handle `embed_job_status` format first (has `result.success` and `result.data`), then queue format (direct keys in `result`)
4. **Fallback strategy**: Only fall back on method-not-found errors; other errors should raise `EmbeddingServiceAPIError`
5. **Default values**: Use empty string for `message`, `None` for `result` and `error`, `"unknown"` for `status` when missing

## Blackstops

**STOP and escalate if**:
- JSON-RPC error response format is different than expected
- `embed_job_status` command name is incorrect (verify with server contract)
- Response normalization logic conflicts with existing usage patterns

## Handoff Package

**For coder_auto**:
- Target file: `embed_client/testing_client.py`
- Method to modify: `job_status()` (lines 471-501)
- Key requirement: Try `embed_job_status` first, fall back to `queue_get_job_status`, normalize response
- Critical: Handle JSON-RPC error responses correctly, normalize both response formats, return consistent format
- Validation: Run black, flake8, mypy after implementation

**Completion condition**: All validation commands pass, method correctly handles both endpoints and normalizes responses to consistent format.
