Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Validate and Align AsyncClientAPIMixin.embed()

## Executor Role

**Executor**: `coder_auto`

**Execution directive**: Implement parameter validation and ensure canonical contract alignment for `AsyncClientAPIMixin.embed()` method.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-command-contract-alignment.md`

## Step Scope

**Target file**: `embed_client/async_client_api_mixin.py`

**Action**: modify

**Method to modify**: `AsyncClientAPIMixin.embed()` (lines 314-593)

## Dependency Contract

**Dependencies**: None (can run in parallel with step for `testing_client.py`)

**Dependents**: Result parsing steps (separate tactical task)

## Required Context

This step ensures the `embed()` method in `AsyncClientAPIMixin`:
1. Validates `texts` parameter is a non-empty list of strings
2. Builds canonical request params dict with all server-expected parameters
3. Uses adapter-backed clients for connection overrides (already implemented, verify correctness)
4. Does not depend on server-side `text` to `texts` normalization

## Read First

Before starting implementation, read these files in order:

1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - overall architecture
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-command-contract-alignment.md` - tactical task details
3. `/home/vasilyvz/projects/embed-client/embed_client/async_client_api_mixin.py` - current implementation (lines 314-593)
4. `/home/vasilyvz/projects/embed-client/embed_client/constants.py` - `EMBED_DEFAULT_ERROR_POLICY` constant
5. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - `execute_command_unified()` method signature
6. `/home/vasilyvz/projects/embed-client/embed_client/adapter_config_factory.py` - adapter config factory usage

## Expected File Change

**File**: `embed_client/async_client_api_mixin.py`

**Changes**:
1. Add parameter validation at the start of `embed()` method (after line 399, before line 400)
2. Ensure canonical params dict building is correct (verify lines 463-477)
3. Verify connection override logic uses adapter-backed clients (verify lines 400-459)

## Forbidden Alternatives

**DO NOT**:
- Accept `text` parameter (singular) - only `texts` (plural list)
- Depend on server-side normalization from `text` to `texts`
- Create direct HTTP/WebSocket connections for connection overrides - must use adapter-backed clients
- Skip parameter validation - always validate `texts` is non-empty list of strings
- Modify adapter transport layer - only use existing `execute_command_unified()` method
- Implement result parsing in this step - that is handled by separate tactical task
- Modify identifier handling - JSON-RPC id, job_id, WebSocket correlation are handled in Step 3
- Use `Any` type annotation for `texts` parameter
- Add methods not listed in this step
- Modify files other than the target file
- Use `print()` for logging; use the project logger
- Use bare `except:`

## Atomic Operations

### Operation 1: Add Parameter Validation

**Location**: After line 399 (end of docstring), before line 400 (start of method body)

**Code to add**:
```python
        # Validate texts parameter
        if not isinstance(texts, list):
            raise ValueError("texts must be a list")
        if len(texts) == 0:
            raise ValueError("texts must be a non-empty list")
        if not all(isinstance(t, str) for t in texts):
            raise ValueError("texts must contain only strings")
```

**Algorithm**:
1. Check if `texts` is a list using `isinstance(texts, list)`
2. If not a list: raise `ValueError` with message `"texts must be a list"`
3. Check if `texts` is non-empty using `len(texts) == 0`
4. If empty: raise `ValueError` with message `"texts must be a non-empty list"`
5. Check if all items are strings using `all(isinstance(t, str) for t in texts)`
6. If any item is not a string: raise `ValueError` with message `"texts must contain only strings"`

### Operation 2: Verify Canonical Params Building

**Location**: Lines 463-477 (existing code, verify correctness)

**Current code** (verify it matches this exactly):
```python
            params: Dict[str, Any] = {"texts": texts}
            if model is not None:
                params["model"] = model
            if dimension is not None:
                params["dimension"] = dimension
            eff_error_policy = (
                error_policy if error_policy is not None else EMBED_DEFAULT_ERROR_POLICY
            )
            params["error_policy"] = eff_error_policy
            if device is not None and device.strip():
                params["device"] = device.strip()
            if job_id is not None:
                params["job_id"] = job_id
            if extra_params:
                params.update(extra_params)
```

**Verification checklist**:
- [ ] `params` dict starts with `{"texts": texts}` (canonical parameter)
- [ ] `model` is added only if `model is not None`
- [ ] `dimension` is added only if `dimension is not None`
- [ ] `error_policy` is always set (defaults to `EMBED_DEFAULT_ERROR_POLICY` if `error_policy is None`)
- [ ] `device` is added only if `device is not None and device.strip()` (stripped)
- [ ] `job_id` is added only if `job_id is not None`
- [ ] `extra_params` are merged into params dict if provided

**If verification fails**: Fix the code to match the expected behavior above.

### Operation 3: Verify Connection Override Logic

**Location**: Lines 400-459 (existing code, verify correctness)

**Current code structure** (verify it matches this pattern):
- Checks if any override parameters are provided (host, port, protocol, token, cert files)
- Gets current config from `self.config_dict` or `self.config.get_all()`
- Creates new config dict by copying current config
- Applies overrides to new config
- Creates temporary `EmbeddingServiceAsyncClient` with new config
- Enters async context: `await temp_client.__aenter__()`
- Uses `temp_client` for transport calls
- Cleans up in `finally` block: `await temp_client.__aexit__(None, None, None)`

**Verification checklist**:
- [ ] Connection overrides create temporary `EmbeddingServiceAsyncClient` (adapter-backed)
- [ ] Temporary client uses `AdapterTransport`, not direct HTTP
- [ ] Temporary client is properly entered via `__aenter__()`
- [ ] Temporary client is properly cleaned up in `finally` block via `__aexit__()`
- [ ] No direct HTTP/WebSocket connections are created

**If verification fails**: Fix the code to use adapter-backed clients only.

## Expected Deliverables

1. **Modified file**: `embed_client/async_client_api_mixin.py`
   - Parameter validation added at start of `embed()` method
   - Canonical params building verified/corrected
   - Connection override logic verified/corrected

2. **Validation**: All existing tests pass, new validation tests pass

## Mandatory Validation

After implementation, run these exact commands and verify output:

1. **Format check**:
   ```bash
   black embed_client/async_client_api_mixin.py
   ```
   **Expected**: "reformatted" or "All done! ✨ 🍰 ✨" or "already well formatted"

2. **Lint check**:
   ```bash
   flake8 embed_client/async_client_api_mixin.py
   ```
   **Expected**: No output (exit code 0)

3. **Type check**:
   ```bash
   mypy embed_client/async_client_api_mixin.py
   ```
   **Expected**: "Success: no issues found" (or existing type issues that are not related to this change)

4. **Run existing tests**:
   ```bash
   pytest tests/ -k "embed" -v
   ```
   **Expected**: All tests pass (or existing failures unrelated to this change)

5. **Run validation tests** (if test file exists or is created in separate step):
   ```bash
   pytest tests/test_embed_command_contract.py::TestEmbedCommandContract::test_embed_requires_non_empty_texts_list -v
   pytest tests/test_embed_command_contract.py::TestEmbedCommandContract::test_embed_builds_canonical_params -v
   pytest tests/test_embed_command_contract.py::TestEmbedCommandContract::test_embed_uses_default_error_policy -v
   pytest tests/test_embed_command_contract.py::TestEmbedCommandContract::test_embed_passes_extra_params -v
   pytest tests/test_embed_command_contract.py::TestEmbedCommandContract::test_embed_connection_overrides_create_adapter_client -v
   ```
   **Expected**: All tests pass

## Decision Rules

1. **Parameter validation order**: Validate type first, then length, then item types (most specific error first)
2. **Error messages**: Use exact messages specified in "Atomic Operations" section
3. **Canonical params**: Always include `texts`, always include `error_policy` (with default), conditionally include others
4. **Connection overrides**: Always use `EmbeddingServiceAsyncClient` with adapter-backed transport, never direct HTTP

## Blackstops

**STOP and escalate** if:
- Adapter transport layer needs modification (affects Step 1 foundation)
- Parameter validation rules conflict with existing public API compatibility requirements
- Connection override logic cannot use adapter-backed clients without breaking architecture

## Handoff Package

**For coder_auto**:

1. **Target file**: `embed_client/async_client_api_mixin.py`
2. **Method to modify**: `AsyncClientAPIMixin.embed()` (lines 314-593)
3. **Primary change**: Add parameter validation after docstring (after line 399)
4. **Secondary changes**: Verify canonical params building (lines 463-477) and connection override logic (lines 400-459)
5. **Validation**: Run black, flake8, mypy, pytest
6. **Success criteria**: All tests pass, validation added, canonical contract verified

## File Header

**No changes to file header** - existing header is correct.

## Complete Import List

**No new imports needed** - use existing imports:
- `from typing import Any, Dict, List, Optional` (already imported)
- `from embed_client.constants import EMBED_DEFAULT_ERROR_POLICY` (already imported)
- `isinstance()` and `all()` are built-in functions

## Class/Method Skeleton

**Class**: `AsyncClientAPIMixin` (mixin class, no base class)

**Method signature** (no changes to signature):
```python
async def embed(
    self,
    texts: List[str],
    *,
    model: Optional[str] = None,
    dimension: Optional[int] = None,
    error_policy: Optional[str] = None,
    device: Optional[str] = None,
    job_id: Optional[str] = None,
    timeout: Optional[float] = None,
    wait: bool = True,
    use_push: bool = True,
    poll_interval: float = 0.3,
    host: Optional[str] = None,
    port: Optional[int] = None,
    protocol: Optional[str] = None,
    token: Optional[str] = None,
    cert_file: Optional[str] = None,
    key_file: Optional[str] = None,
    ca_cert_file: Optional[str] = None,
    crl_file: Optional[str] = None,
    **extra_params: Any,
) -> Dict[str, Any]:
```

**Method docstring**: Keep existing docstring (lines 338-399)

## Method Logic - Step-by-Step Algorithm

**Method**: `embed()` - add validation at start

**Algorithm for validation** (add after docstring, before existing method body):
1. Check `isinstance(texts, list)` → if False: raise `ValueError("texts must be a list")`
2. Check `len(texts) == 0` → if True: raise `ValueError("texts must be a non-empty list")`
3. Check `all(isinstance(t, str) for t in texts)` → if False: raise `ValueError("texts must contain only strings")`
4. Continue with existing method body (connection override logic, params building, transport call)

**Algorithm for canonical params building** (verify existing code at lines 463-477):
1. Initialize `params: Dict[str, Any] = {"texts": texts}`
2. If `model is not None`: set `params["model"] = model`
3. If `dimension is not None`: set `params["dimension"] = dimension`
4. Compute `eff_error_policy = error_policy if error_policy is not None else EMBED_DEFAULT_ERROR_POLICY`
5. Set `params["error_policy"] = eff_error_policy` (always set)
6. If `device is not None and device.strip()`: set `params["device"] = device.strip()`
7. If `job_id is not None`: set `params["job_id"] = job_id`
8. If `extra_params` dict is non-empty: call `params.update(extra_params)`

**Algorithm for connection overrides** (verify existing code at lines 400-459):
1. Initialize `client_to_use = self`
2. Check if any override parameters provided: `any([host, port, protocol, token, cert_file, key_file, ca_cert_file, crl_file])`
3. If overrides provided:
   - Import `EmbeddingServiceAsyncClient` (lazy import to avoid circular dependency)
   - Get current config from `self.config_dict` or `self.config.get_all()`
   - Create `new_config = current_config.copy()`
   - Apply overrides to `new_config` (host, port, protocol, token, cert files)
   - Create `client_to_use = EmbeddingServiceAsyncClient(config_dict=new_config)`
   - Enter async context: `await client_to_use.__aenter__()`
4. In `finally` block: if `client_to_use is not self`: call `await client_to_use.__aexit__(None, None, None)`

## Error Handling Per Method

**Method**: `embed()`

**Parameter validation errors**:
- **Exception**: `ValueError`
- **Condition**: `texts` is not a list
- **Message**: `"texts must be a list"`
- **Action**: Raise immediately, do not catch

- **Exception**: `ValueError`
- **Condition**: `texts` is empty list
- **Message**: `"texts must be a non-empty list"`
- **Action**: Raise immediately, do not catch

- **Exception**: `ValueError`
- **Condition**: `texts` contains non-string items
- **Message**: `"texts must contain only strings"`
- **Action**: Raise immediately, do not catch

**Connection override errors**:
- **Exception**: `EmbeddingServiceConfigError` (from adapter config factory or client init)
- **Condition**: Invalid connection override parameters
- **Message**: Adapter config factory or client error message
- **Action**: Let exception propagate (do not catch)

**Adapter transport errors**:
- **Exception**: `EmbeddingServiceAPIError` or `EmbeddingServiceError` (from adapter transport)
- **Condition**: Adapter transport fails
- **Message**: Adapter transport error message
- **Action**: Let exception propagate (existing error handling in method)

## Return Value Specification

**Method**: `embed()`

**Return type**: `Dict[str, Any]`

**Return value**: Unchanged from existing implementation - result parsing is handled by separate tactical task. This step only ensures:
- Parameter validation happens before any processing
- Canonical params dict is built correctly
- Connection overrides use adapter-backed clients

## Edge Cases

**Edge cases for parameter validation**:
- `texts = []` → raise `ValueError("texts must be a non-empty list")`
- `texts = None` → raise `ValueError("texts must be a list")` (or `TypeError` if `isinstance(None, list)` is False, but `isinstance()` will catch it)
- `texts = "single string"` → raise `ValueError("texts must be a list")`
- `texts = [1, 2, 3]` → raise `ValueError("texts must contain only strings")`
- `texts = ["valid", 123, "also valid"]` → raise `ValueError("texts must contain only strings")`
- `texts = [""]` → valid (empty string is still a string, list is non-empty)
- `texts = ["text1", "text2"]` → valid

**Edge cases for canonical params**:
- `model = None` → do not add to params
- `dimension = None` → do not add to params
- `error_policy = None` → use `EMBED_DEFAULT_ERROR_POLICY` ("fail_fast")
- `device = None` → do not add to params
- `device = ""` → do not add to params (empty string after strip)
- `device = "  cpu  "` → add `"device": "cpu"` (stripped)
- `job_id = None` → do not add to params
- `extra_params = {}` → do not update params
- `extra_params = {"custom": "value"}` → merge into params

**Edge cases for connection overrides**:
- No override parameters → use `self` (existing client)
- All override parameters provided → create temporary client with all overrides
- Partial override parameters → create temporary client with partial overrides
- Temporary client creation fails → exception propagates (no catch)
- Temporary client `__aenter__()` fails → exception propagates (no catch)
- Method raises exception after client creation → `finally` block cleans up client

## Exact Constants and Literals

**Constants used**:
- `EMBED_DEFAULT_ERROR_POLICY` - imported from `embed_client.constants`, value is `"fail_fast"` (string)

**String literals**:
- `"texts must be a list"` - error message for non-list input
- `"texts must be a non-empty list"` - error message for empty list
- `"texts must contain only strings"` - error message for non-string items
- `"embed"` - command name for `execute_command_unified()` (existing code)

## Test Expectations

**Test file**: `tests/test_embed_command_contract.py` (may need to be created in separate step)

**Test class**: `TestEmbedCommandContract`

**Test methods to verify** (if tests exist):
1. `test_embed_requires_non_empty_texts_list()` - asserts `embed([])` raises `ValueError` with message containing "non-empty list"
2. `test_embed_builds_canonical_params()` - asserts `execute_command_unified` called with canonical params dict
3. `test_embed_uses_default_error_policy()` - asserts default error policy is used when `error_policy=None`
4. `test_embed_passes_extra_params()` - asserts `extra_params` are merged into params dict
5. `test_embed_connection_overrides_create_adapter_client()` - asserts temporary adapter-backed client is created

**If tests don't exist**: This step does not create tests - tests are created in separate step. This step only implements the validation and verifies existing code correctness.
