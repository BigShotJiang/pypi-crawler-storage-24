Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Embed Command Contract Alignment

## Purpose

Align the public `embed()` method in `AsyncClientAPIMixin` and `EmbeddingServiceClient` with the canonical server command contract. Ensure the method uses `texts` as the primary parameter, correctly passes all server-expected parameters (`model`, `dimension`, `error_policy`, `device`), and does not depend on server-side convenience normalization from `text` to `texts`.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`

## Scope

### Included

- `embed_client/async_client_api_mixin.py` - `AsyncClientAPIMixin.embed()` method
- `embed_client/testing_client.py` - `EmbeddingServiceClient.embed()` method
- Parameter validation and canonical request building for `embed` command
- Removal of any dependency on non-canonical `text` parameter normalization

### Excluded

- Result parsing and normalization (covered in separate tactical task)
- Queue/WebSocket waiting logic (covered in separate tactical task)
- `embed_job_status` command implementation (covered in separate tactical task)
- `models` and `timing_stats` commands (covered in separate tactical task)

## Boundaries

This task must NOT touch:
- `embed_client/adapter_transport.py` - adapter transport layer
- `embed_client/response_normalizer.py` - response normalization logic
- `embed_client/async_client_queue_mixin.py` - queue waiting methods
- Result extraction and parsing logic
- Identifier model separation (covered in Step 3)

## Dependencies

- None (can run in parallel with other tactical tasks in this step)

## Parallelization Note

This tactical task can run in parallel with:
- `embed-result-mode-handling.md`
- `embed-job-status-alignment.md`
- `models-timing-stats-alignment.md`

## Expected Outcome

1. `AsyncClientAPIMixin.embed()` accepts only `texts: List[str]` as the primary input parameter
2. All server-expected parameters (`model`, `dimension`, `error_policy`, `device`) are correctly passed to the adapter transport layer
3. No code path depends on server-side `text` to `texts` normalization
4. Parameter validation ensures `texts` is a non-empty list of strings
5. The method builds canonical request params dict: `{"texts": [...], "model": ..., "dimension": ..., "error_policy": ..., "device": ...}`
6. Connection override parameters (host, port, protocol, token, cert files) are handled correctly without breaking adapter-centric architecture

## Correction Items

### Current Implementation Issues

1. **File**: `embed_client/async_client_api_mixin.py`, method `embed()` (lines 314-593)
   - **Issue**: Method accepts many connection override parameters that may bypass adapter-centric architecture
   - **Correction**: Ensure connection overrides create temporary adapter-backed clients, not custom transport
   - **Verification**: All connection override paths use `AdapterConfigFactory` and `AdapterTransport`, not direct HTTP

2. **File**: `embed_client/async_client_api_mixin.py`, method `embed()` (lines 463-477)
   - **Issue**: Parameter building logic may not validate `texts` is non-empty list
   - **Correction**: Add explicit validation: `if not texts or not isinstance(texts, list) or not all(isinstance(t, str) for t in texts): raise ValueError`
   - **Verification**: Test with empty list, non-list, non-string items

3. **File**: `embed_client/testing_client.py`, method `embed()` (lines 271-313)
   - **Issue**: May not align with canonical `texts` parameter contract
   - **Correction**: Ensure it uses `texts` only, no `text` parameter support
   - **Verification**: Method signature and implementation match canonical contract

## Questions/Escalation Rule

Escalate to global orchestrator if:
- Server contract changes require global architecture changes
- Adapter transport layer needs modification (affects Step 1 foundation)
- Parameter validation rules conflict with existing public API compatibility requirements

## File Inventory

### Files to Modify

1. **Action**: modify
   **Path**: `embed_client/async_client_api_mixin.py`
   **Purpose**: Align `AsyncClientAPIMixin.embed()` method with canonical server contract

2. **Action**: modify
   **Path**: `embed_client/testing_client.py`
   **Purpose**: Align `EmbeddingServiceClient.embed()` method with canonical server contract

### Files to Read (Reference Only)

1. **Path**: `embed_client/adapter_transport.py`
   **Purpose**: Understand how `execute_command_unified()` accepts command and params

2. **Path**: `embed_client/adapter_config_factory.py`
   **Purpose**: Understand how to create temporary adapter-backed clients for connection overrides

3. **Path**: `/home/vasilyvz/projects/embed/embed/commands/embed_command_schema.py`
   **Purpose**: Verify exact server parameter contract (if accessible)

## Class/Function Inventory

### Class: `AsyncClientAPIMixin`

**Base class**: None (mixin)

**Purpose**: Provides high-level API methods for embedding service client

**Public methods to modify**:

1. **Method**: `embed(texts: List[str], *, model: Optional[str] = None, dimension: Optional[int] = None, error_policy: Optional[str] = None, device: Optional[str] = None, job_id: Optional[str] = None, timeout: Optional[float] = None, wait: bool = True, use_push: bool = True, poll_interval: float = 0.3, host: Optional[str] = None, port: Optional[int] = None, protocol: Optional[str] = None, token: Optional[str] = None, cert_file: Optional[str] = None, key_file: Optional[str] = None, ca_cert_file: Optional[str] = None, crl_file: Optional[str] = None, **extra_params: Any) -> Dict[str, Any]`
   **Behavior**: 
   - Validates `texts` is non-empty list of strings
   - Builds canonical params dict: `{"texts": texts, "model": model, "dimension": dimension, "error_policy": error_policy or "fail_fast", "device": device}`
   - Adds `job_id` and `extra_params` if provided
   - Handles connection overrides by creating temporary adapter-backed client
   - Calls `_adapter_transport.execute_command_unified(command="embed", params=params, use_cmd_endpoint=False, auto_poll=False)`
   - Returns result (result parsing handled by separate tactical task)

### Class: `EmbeddingServiceClient`

**Base class**: None

**Purpose**: Testing/synchronous client wrapper

**Public methods to modify**:

1. **Method**: `embed(texts: List[str], model: Optional[str] = None, dimension: Optional[int] = None, job_id: Optional[str] = None, error_policy: Optional[str] = None, device: Optional[str] = None, wait: bool = False, wait_timeout: int = 60, poll_interval: float = 1.0, use_push: bool = True) -> Dict[str, Any]`
   **Behavior**:
   - Validates `texts` is non-empty list of strings
   - Builds canonical params dict: `{"texts": texts, "model": model, "dimension": dimension, "error_policy": error_policy, "device": device}`
   - Adds `job_id` if provided
   - Calls adapter transport with `embed` command
   - Returns result (result parsing handled by separate tactical task)

## Data Structures

No new data structures required. Uses existing:
- `Dict[str, Any]` for request params and responses
- `List[str]` for `texts` parameter

## Import Map

### File: `embed_client/async_client_api_mixin.py`

**Existing imports** (keep):
```python
from typing import Any, Dict, List, Optional
from embed_client.constants import EMBED_DEFAULT_ERROR_POLICY
from embed_client.exceptions import EmbeddingServiceAPIError, EmbeddingServiceError, EmbeddingServiceTimeoutError
```

**Additional imports** (if needed for validation):
```python
# No additional imports needed - use isinstance() and all() built-ins
```

### File: `embed_client/testing_client.py`

**Existing imports** (keep):
```python
from typing import Any, Dict, List, Optional
```

**Additional imports** (if needed):
```python
# No additional imports needed
```

## Error Handling Map

### Method: `AsyncClientAPIMixin.embed()`

1. **Parameter validation errors**:
   - **Exception**: `ValueError`
   - **Condition**: `texts` is empty list, not a list, or contains non-string items
   - **Message**: `"texts must be a non-empty list of strings"`
   - **Caller action**: Fix input parameter

2. **Connection override client creation errors**:
   - **Exception**: `EmbeddingServiceConfigError` (from adapter config factory)
   - **Condition**: Invalid connection override parameters
   - **Message**: Adapter config factory error message
   - **Caller action**: Fix connection override parameters

3. **Adapter transport errors**:
   - **Exception**: `EmbeddingServiceAPIError` or `EmbeddingServiceError` (from adapter transport)
   - **Condition**: Adapter transport fails
   - **Message**: Adapter transport error message
   - **Caller action**: Check server connectivity and parameters

### Method: `EmbeddingServiceClient.embed()`

1. **Parameter validation errors**:
   - **Exception**: `ValueError`
   - **Condition**: `texts` is empty list, not a list, or contains non-string items
   - **Message**: `"texts must be a non-empty list of strings"`
   - **Caller action**: Fix input parameter

2. **Adapter transport errors**:
   - **Exception**: `EmbeddingServiceError` (from adapter transport)
   - **Condition**: Adapter transport fails
   - **Message**: Adapter transport error message
   - **Caller action**: Check server connectivity and parameters

## Config Dependency

### Config Keys Used

1. **Key**: `error_policy` (default: `"fail_fast"` from `EMBED_DEFAULT_ERROR_POLICY`)
   - **Type**: `str`
   - **Default**: `"fail_fast"`
   - **Valid values**: `"fail_fast"`, `"continue"`
   - **Access location**: Parameter default in `embed()` method

2. **Key**: Connection override parameters (host, port, protocol, token, cert files)
   - **Type**: Various (str, int, str, str, str, str, str)
   - **Default**: None (uses client's default config)
   - **Valid values**: Valid hostname, valid port (1-65535), protocol in ("http", "https", "mtls"), valid file paths
   - **Access location**: Method parameters, used to create temporary adapter-backed client

## Test Plan

### Test File: `tests/test_embed_command_contract.py`

**Test class**: `TestEmbedCommandContract`

**Test methods**:

1. **Test**: `test_embed_requires_non_empty_texts_list()`
   - **Assert**: `embed([])` raises `ValueError` with message containing "non-empty list"
   - **Assert**: `embed(None)` raises `ValueError` or `TypeError`
   - **Assert**: `embed("single string")` raises `ValueError` or `TypeError`
   - **Assert**: `embed([1, 2, 3])` raises `ValueError` (non-string items)

2. **Test**: `test_embed_builds_canonical_params()`
   - **Setup**: Mock `_adapter_transport.execute_command_unified`
   - **Action**: Call `embed(texts=["text1", "text2"], model="test-model", dimension=128, error_policy="continue", device="cpu")`
   - **Assert**: `execute_command_unified` called with `command="embed"` and `params={"texts": ["text1", "text2"], "model": "test-model", "dimension": 128, "error_policy": "continue", "device": "cpu"}`

3. **Test**: `test_embed_uses_default_error_policy()`
   - **Setup**: Mock `_adapter_transport.execute_command_unified`
   - **Action**: Call `embed(texts=["text"], model=None, error_policy=None)`
   - **Assert**: `execute_command_unified` called with `params` containing `"error_policy": "fail_fast"`

4. **Test**: `test_embed_passes_extra_params()`
   - **Setup**: Mock `_adapter_transport.execute_command_unified`
   - **Action**: Call `embed(texts=["text"], custom_param="value", another_param=123)`
   - **Assert**: `execute_command_unified` called with `params` containing `"custom_param": "value"` and `"another_param": 123`

5. **Test**: `test_embed_connection_overrides_create_adapter_client()`
   - **Setup**: Mock `AdapterConfigFactory` and `EmbeddingServiceAsyncClient.__init__`
   - **Action**: Call `embed(texts=["text"], host="override-host", port=9999)`
   - **Assert**: Temporary `EmbeddingServiceAsyncClient` created with config containing overrides
   - **Assert**: Temporary client uses `AdapterTransport`, not direct HTTP

6. **Test**: `test_testing_client_embed_contract()`
   - **Setup**: Mock `_transport.execute_command_unified` or `execute_async`
   - **Action**: Call `EmbeddingServiceClient.embed(texts=["text1", "text2"], model="test")`
   - **Assert**: Transport called with canonical `texts` parameter, not `text`

**Required fixtures/mocks**:
- Mock `_adapter_transport.execute_command_unified` for `AsyncClientAPIMixin` tests
- Mock `AdapterConfigFactory` and `EmbeddingServiceAsyncClient` for connection override tests
- Mock `_transport` for `EmbeddingServiceClient` tests

## Concrete Examples

### Example 1: Basic Embed Call

**Input**:
```python
await client.embed(
    texts=["Hello world", "How are you"],
    model="sentence-transformers/all-MiniLM-L6-v2",
    dimension=384
)
```

**Expected adapter transport call**:
```python
await adapter_transport.execute_command_unified(
    command="embed",
    params={
        "texts": ["Hello world", "How are you"],
        "model": "sentence-transformers/all-MiniLM-L6-v2",
        "dimension": 384,
        "error_policy": "fail_fast"
    },
    use_cmd_endpoint=False,
    auto_poll=False
)
```

### Example 2: Embed with All Parameters

**Input**:
```python
await client.embed(
    texts=["Text 1", "Text 2"],
    model="custom-model",
    dimension=512,
    error_policy="continue",
    device="cuda:0",
    job_id="custom-job-123"
)
```

**Expected adapter transport call**:
```python
await adapter_transport.execute_command_unified(
    command="embed",
    params={
        "texts": ["Text 1", "Text 2"],
        "model": "custom-model",
        "dimension": 512,
        "error_policy": "continue",
        "device": "cuda:0",
        "job_id": "custom-job-123"
    },
    use_cmd_endpoint=False,
    auto_poll=False
)
```

### Example 3: Invalid Input (Empty List)

**Input**:
```python
await client.embed(texts=[])
```

**Expected behavior**: Raises `ValueError` with message: `"texts must be a non-empty list of strings"`

### Example 4: Invalid Input (Non-String Items)

**Input**:
```python
await client.embed(texts=["valid", 123, "also valid"])
```

**Expected behavior**: Raises `ValueError` with message indicating all items must be strings

## Algorithm/Logic Description

### Method: `AsyncClientAPIMixin.embed()`

1. **Parameter validation**:
   - Check `texts` is a list: `if not isinstance(texts, list): raise ValueError("texts must be a list")`
   - Check `texts` is non-empty: `if len(texts) == 0: raise ValueError("texts must be a non-empty list")`
   - Check all items are strings: `if not all(isinstance(t, str) for t in texts): raise ValueError("texts must contain only strings")`

2. **Build canonical params dict**:
   - Start with `{"texts": texts}`
   - If `model is not None`: add `"model": model`
   - If `dimension is not None`: add `"dimension": dimension`
   - Set `"error_policy": error_policy if error_policy is not None else EMBED_DEFAULT_ERROR_POLICY`
   - If `device is not None and device.strip()`: add `"device": device.strip()`
   - If `job_id is not None`: add `"job_id": job_id`
   - If `extra_params`: update params dict with `extra_params`

3. **Handle connection overrides** (if any override parameters provided):
   - Get current client config (from `self.config_dict` or `self.config.get_all()`)
   - Create new config dict by copying current config
   - Apply overrides: host, port, protocol, token, cert files
   - Create temporary `EmbeddingServiceAsyncClient` with new config
   - Enter async context: `await temp_client.__aenter__()`
   - Use `temp_client` for transport calls
   - Store reference for cleanup in `finally` block

4. **Call adapter transport**:
   - Use `client_to_use._adapter_transport.execute_command_unified(command="embed", params=params, use_cmd_endpoint=False, auto_poll=False)`
   - Store result for processing (result processing handled by separate tactical task)

5. **Cleanup** (in `finally` block):
   - If temporary client was created: `await temp_client.__aexit__(None, None, None)`

### Method: `EmbeddingServiceClient.embed()`

1. **Parameter validation**:
   - Same validation as `AsyncClientAPIMixin.embed()`: non-empty list of strings

2. **Build canonical params dict**:
   - Same as `AsyncClientAPIMixin.embed()`: `{"texts": texts, "model": model, "dimension": dimension, "error_policy": error_policy, "device": device}`
   - Add `job_id` if provided

3. **Call adapter transport**:
   - Use `_transport.execute_async("embed_execute", params)` if `wait=True` and WebSocket available
   - Or use `_transport.execute_command_unified(command="embed", params=params, ...)` otherwise
   - Store result for processing (result processing handled by separate tactical task)

## Forbidden Approaches

1. **DO NOT** accept `text` parameter (singular) - only `texts` (plural list)
2. **DO NOT** depend on server-side normalization from `text` to `texts`
3. **DO NOT** create direct HTTP/WebSocket connections for connection overrides - must use adapter-backed clients
4. **DO NOT** skip parameter validation - always validate `texts` is non-empty list of strings
5. **DO NOT** modify adapter transport layer - only use existing `execute_command_unified()` method
6. **DO NOT** implement result parsing in this task - that is handled by separate tactical task
7. **DO NOT** modify identifier handling - JSON-RPC id, job_id, WebSocket correlation are handled in Step 3
