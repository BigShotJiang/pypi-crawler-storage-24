Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: AsyncClientQueueMixin Job Status Methods

## Executor Role

**coder_auto** - Update `get_job_status_or_result()` and `wait_for_job()` methods in `AsyncClientQueueMixin` to work correctly with the updated `queue_get_job_status()` that handles both endpoints.

## Execution Directive

Modify `get_job_status_or_result()` and `wait_for_job()` methods in `AsyncClientQueueMixin` to ensure they correctly handle normalized job status responses from `queue_get_job_status()`. The methods should work with the normalized format that includes `job_id`, `status`, `message`, `result`, and `error` keys.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`
- Parent tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-job-status-alignment.md`

## Step Scope

**Target file**: `embed_client/async_client_queue_mixin.py`
**Action**: modify
**Target methods**:
1. `AsyncClientQueueMixin.get_job_status_or_result(job_id: str, timeout: Optional[float] = None) -> Dict[str, Any]` (lines 376-435)
2. `AsyncClientQueueMixin.wait_for_job(job_id: str, timeout: Optional[float] = None, poll_interval: float = DEFAULT_POLL_INTERVAL) -> Dict[str, Any]` (lines 35-208)
3. `AsyncClientQueueMixin.job_status(job_id: str) -> Dict[str, Any]` (lines 269-278) - ensure it uses normalized response correctly

## Dependency Contract

**Dependencies**: 
- Step 1: `adapter-transport-queue-get-job-status.md` must be completed first (this step uses the updated `queue_get_job_status()` method)

**Dependents**: 
- `testing_client.py` may use these methods indirectly

## Required Context

After Step 1, `queue_get_job_status()` returns normalized format:
```python
{
    "job_id": str,
    "status": str,  # "pending", "running", "completed", "failed", "error"
    "message": str,
    "result": Optional[Dict[str, Any]],  # Present when status="completed"
    "error": Optional[str]  # Present when status="failed"
}
```

The `job_status()` method already uses `ResponseNormalizer.normalize_queue_status()` which may return a different format. We need to ensure consistency:
- `job_status()` should return the normalized format from `queue_get_job_status()` directly (since it's already normalized)
- `get_job_status_or_result()` should handle the normalized format correctly
- `wait_for_job()` should extract result from normalized format correctly

Current `wait_for_job()` implementation checks for status values: `"completed"`, `"success"`, `"done"` for completion, and `"failed"`, `"error"` for failure. This should continue to work.

## Read First

1. `/home/vasilyvz/projects/embed-client/embed_client/async_client_queue_mixin.py` - current implementation
2. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - understand `queue_get_job_status()` return format after Step 1
3. `/home/vasilyvz/projects/embed-client/embed_client/response_normalizer.py` - understand current normalization
4. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-job-status-alignment.md` - full requirements

## Expected File Change

**File**: `embed_client/async_client_queue_mixin.py`

### Method 1: `job_status(job_id: str) -> Dict[str, Any]`

**Current implementation** (lines 269-278):
- Calls `queue_get_job_status(job_id)`
- Normalizes with `ResponseNormalizer.normalize_queue_status()`
- Returns normalized dict

**New implementation**:
- Call `await self._adapter_transport.queue_get_job_status(job_id)` (already normalized by Step 1)
- Since `queue_get_job_status()` now returns normalized format directly, we can return it as-is OR apply `ResponseNormalizer.normalize_queue_status()` for backward compatibility
- **Decision**: Keep using `ResponseNormalizer.normalize_queue_status()` to ensure consistent format with existing code, but the normalizer should handle the already-normalized format gracefully

**Changes**:
- No changes needed if `ResponseNormalizer.normalize_queue_status()` handles normalized input correctly
- If normalizer expects raw adapter response, we may need to adjust, but based on the normalizer code, it should handle both formats

### Method 2: `get_job_status_or_result(job_id: str, timeout: Optional[float] = None) -> Dict[str, Any]`

**Current implementation** (lines 376-435):
- If `timeout is None`: calls `self.job_status(job_id)` and returns immediately
- If `timeout is not None`: calls `self.wait_for_job(job_id, timeout=timeout)` and wraps result

**New implementation**:
- Same logic, but ensure it handles normalized format correctly
- When `timeout is None`: return `job_status()` result (already normalized)
- When `timeout is not None`: `wait_for_job()` returns result dict, wrap it in format: `{"status": "completed", "result": result, "job_id": job_id}`

**Changes**:
- Ensure return format is consistent: always include `job_id`, `status`, and `result` keys
- When `timeout is None` and status is not completed: return full normalized status dict from `job_status()`
- When `timeout is not None` and job completes: return `{"status": "completed", "result": <result_data>, "job_id": job_id}`

### Method 3: `wait_for_job(job_id: str, timeout: Optional[float] = None, poll_interval: float = DEFAULT_POLL_INTERVAL) -> Dict[str, Any]`

**Current implementation** (lines 35-208):
- Calls `self.job_status(job_id)` to get initial status
- Checks status values: `"completed"`, `"success"`, `"done"` for completion
- Checks status values: `"failed"`, `"error"` for failure
- Extracts result from `status.get("result")` and handles nested `result["data"]` structure
- Polls in loop until completion or timeout

**New implementation**:
- Same polling logic, but ensure it correctly extracts result from normalized format
- Normalized format has `result` key directly (not nested in `data`)
- When status is `"completed"`: return `status.get("result")` directly (it's already the result data)
- When status is `"failed"` or `"error"`: raise `EmbeddingServiceAPIError` with `status.get("error")` or `status.get("message")`

**Changes**:
- Simplify result extraction: `status.get("result")` is already the result data (no need to check for `result["data"]`)
- Error extraction: use `status.get("error")` first, fall back to `status.get("message")` if error is None
- Keep existing status value checks (`"completed"`, `"success"`, `"done"` for completion)

**Import changes**: No new imports needed

## Forbidden Alternatives

1. **DO NOT** remove existing status value checks (`"success"`, `"done"` in addition to `"completed"`)
2. **DO NOT** change method signatures or return types
3. **DO NOT** modify `ResponseNormalizer` in this step
4. **DO NOT** change timeout handling logic
5. **DO NOT** remove timing logging
6. **DO NOT** modify other methods in this file

## Atomic Operations

### Method 1: `job_status(job_id: str) -> Dict[str, Any]`

**Step-by-step algorithm**:
1. Call `status = await self._adapter_transport.queue_get_job_status(job_id)` (returns normalized format from Step 1)
2. Apply `normalized = ResponseNormalizer.normalize_queue_status(status)` (handles both raw and normalized input)
3. Get logger: `logger = logging.getLogger("EmbeddingServiceAsyncClient.job_status")`
4. Log debug: `logger.debug("Raw status: %s, Normalized: %s", status, normalized)`
5. Return `normalized`
6. Exception handling: catch all exceptions, wrap in `EmbeddingServiceError` with message `f"Failed to get job status: {exc}"`

**Error handling**:
- Catch `Exception` (broad catch): wrap in `EmbeddingServiceError` and re-raise
- Preserve original exception as `from exc`

**Return value**: Dict with normalized status format (from `ResponseNormalizer.normalize_queue_status()`)

### Method 2: `get_job_status_or_result(job_id: str, timeout: Optional[float] = None) -> Dict[str, Any]`

**Step-by-step algorithm**:
1. If `timeout is None`:
   - Call `status = await self.job_status(job_id)` (returns normalized dict)
   - Return `status` as-is (already has `job_id`, `status`, `result`, `error` keys)
2. Else (timeout is not None):
   - Call `result = await self.wait_for_job(job_id, timeout=timeout)` (returns result data dict)
   - Return dict: `{"status": "completed", "result": result, "job_id": job_id}`

**Error handling**:
- Let exceptions from `job_status()` or `wait_for_job()` propagate (they already wrap errors appropriately)
- No additional error handling needed

**Return value**: 
- If `timeout is None`: normalized status dict from `job_status()`
- If `timeout is not None`: `{"status": "completed", "result": <result_data>, "job_id": job_id}`

**Edge cases**:
- `timeout is None` and status is `"completed"`: return status dict with `result` key populated
- `timeout is None` and status is `"failed"`: return status dict with `error` key populated
- `timeout is None` and status is `"pending"` or `"running"`: return status dict as-is

### Method 3: `wait_for_job(job_id: str, timeout: Optional[float] = None, poll_interval: float = DEFAULT_POLL_INTERVAL) -> Dict[str, Any]`

**Step-by-step algorithm**:
1. Record start time: `t_start = time.perf_counter()`
2. Initialize poll count: `poll_count = 0`
3. Get logger: `logger = logging.getLogger("EmbeddingServiceAsyncClient.wait_for_job")`
4. Get initial status: `status = await self.job_status(job_id)` (normalized format)
5. Increment poll count: `poll_count = 1`
6. Calculate first RTT: `first_rtt = time.perf_counter() - t_start`
7. Log timing: `_timing_log.debug("wait_for_job job_id=%s first_rtt_sec=%.3f poll_count=1", (job_id or "")[:16], first_rtt)`
8. Log debug: `logger.debug("Initial job status: %s", status)`
9. If `timeout is None`:
   - Log timing: `_timing_log.debug("wait_for_job job_id=%s done total_sec=%.3f poll_count=%s status=return_immediate", (job_id or "")[:16], time.perf_counter() - t_start, poll_count)`
   - Return `status` (normalized dict)
10. Extract current status: `current_status = status.get("status", "unknown")`
11. Check if already completed:
    - If `current_status in ("completed", "success", "done")`:
      - Extract result: `result = status.get("result")`
      - If `result` exists and is a dict:
        - If `result` has key `"data"` (legacy format): `out = result["data"]`
        - Else: `out = result`
      - Else: `out = status` (return full status dict)
      - Log timing: `_timing_log.debug("wait_for_job job_id=%s done total_sec=%.3f poll_count=%s status=completed", (job_id or "")[:16], time.perf_counter() - t_start, poll_count)`
      - Return `out`
12. Check if already failed:
    - If `current_status in ("failed", "error")`:
      - Extract error: `error = status.get("error") or status.get("message") or "Job failed"`
      - Log timing: `_timing_log.debug("wait_for_job job_id=%s done total_sec=%.3f poll_count=%s status=failed", (job_id or "")[:16], time.perf_counter() - t_start, poll_count)`
      - Raise `EmbeddingServiceAPIError({"message": str(error)})`
13. If `timeout == 0` (wait indefinitely):
    - While True:
      - Sleep: `await asyncio.sleep(poll_interval)`
      - Increment poll count: `poll_count += 1`
      - Get status: `status = await self.job_status(job_id)`
      - Extract status: `current_status = status.get("status", "unknown")`
      - Log debug: `logger.debug("Job %s status: %s, full status: %s", job_id, current_status, status)`
      - If `current_status in ("completed", "success", "done")`:
        - Extract result: `result = status.get("result")`
        - If `result` exists and is a dict and has `"data"` key: `out = result["data"]`
        - Else if `result` exists: `out = result`
        - Else: `out = status`
        - Log timing and return `out`
      - If `current_status in ("failed", "error")`:
        - Extract error and raise `EmbeddingServiceAPIError`
14. Else (timeout > 0):
    - Record start time: `start_time = time.time()`
    - While `time.time() - start_time < timeout`:
      - Sleep: `await asyncio.sleep(poll_interval)`
      - Increment poll count: `poll_count += 1`
      - Get status: `status = await self.job_status(job_id)`
      - Extract status: `current_status = status.get("status", "unknown")`
      - Log debug: `logger.debug("Job %s status: %s, full status: %s", job_id, current_status, status)`
      - If `current_status in ("completed", "success", "done")`:
        - Extract result and return (same logic as step 11)
      - If `current_status in ("failed", "error")`:
        - Extract error and raise (same logic as step 12)
    - If loop exits (timeout exceeded):
      - Log timing: `_timing_log.debug("wait_for_job job_id=%s done total_sec=%.3f poll_count=%s status=timeout", (job_id or "")[:16], time.perf_counter() - t_start, poll_count)`
      - Raise `EmbeddingServiceTimeoutError(f"Job {job_id} did not complete within {timeout} seconds")`
15. Exception handling:
    - Catch `EmbeddingServiceTimeoutError`: re-raise
    - Catch `EmbeddingServiceAPIError`: re-raise
    - Catch `Exception`: wrap in `EmbeddingServiceError(f"Failed to wait for job: {exc}")` and raise with `from exc`

**Error handling**:
- `EmbeddingServiceTimeoutError`: re-raise (from timeout check or from `job_status()`)
- `EmbeddingServiceAPIError`: re-raise (from failed job status)
- Other exceptions: wrap in `EmbeddingServiceError` with message

**Return value**: 
- If job completes: result data dict (extracted from `status.get("result")`)
- If `timeout is None`: normalized status dict

**Edge cases**:
- `status.get("result")` is None: return full status dict
- `status.get("result")` is dict with `"data"` key: extract `result["data"]` (legacy format support)
- `status.get("result")` is dict without `"data"` key: use `result` directly (normalized format)
- `status.get("error")` is None but status is `"failed"`: use `status.get("message")` or `"Job failed"`

## Expected Deliverables

1. Modified `job_status()` method that correctly handles normalized input from `queue_get_job_status()`
2. Modified `get_job_status_or_result()` that returns consistent format
3. Modified `wait_for_job()` that correctly extracts result from normalized format
4. All methods preserve existing timing logging
5. All methods handle edge cases gracefully

## Mandatory Validation

**Validation commands** (run from project root):

1. **Code formatting**:
   ```bash
   black embed_client/async_client_queue_mixin.py
   ```
   Expected: "reformatted" or "already well formatted"

2. **Linting**:
   ```bash
   flake8 embed_client/async_client_queue_mixin.py
   ```
   Expected: no output (exit code 0)

3. **Type checking**:
   ```bash
   mypy embed_client/async_client_queue_mixin.py
   ```
   Expected: "Success: no issues found"

**Test expectations**: Tests for these methods should be written in a separate test step. This step only implements the production code changes.

## Decision Rules

1. **Result extraction**: Support both legacy format (`result["data"]`) and normalized format (`result` directly)
2. **Error extraction**: Prefer `status.get("error")`, fall back to `status.get("message")`, then `"Job failed"`
3. **Status value checks**: Keep existing checks for `"completed"`, `"success"`, `"done"` (for completion) and `"failed"`, `"error"` (for failure)
4. **Return format**: `wait_for_job()` returns result data dict, not full status dict (for backward compatibility)

## Blackstops

**STOP and escalate if**:
- `ResponseNormalizer.normalize_queue_status()` doesn't handle already-normalized input correctly
- Normalized format from Step 1 conflicts with existing code expectations
- Result extraction logic breaks existing tests

## Handoff Package

**For coder_auto**:
- Target file: `embed_client/async_client_queue_mixin.py`
- Methods to modify: `job_status()`, `get_job_status_or_result()`, `wait_for_job()`
- Key requirement: Handle normalized format from `queue_get_job_status()`, support both legacy and normalized result extraction
- Critical: Preserve timing logging, maintain backward compatibility with existing status value checks
- Validation: Run black, flake8, mypy after implementation

**Completion condition**: All validation commands pass, methods correctly handle normalized format while maintaining backward compatibility.
