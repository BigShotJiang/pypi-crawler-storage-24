Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Embed Result Mode Handling Alignment

## Purpose

Ensure the client correctly handles both immediate JSON-RPC results and queued job results for embed operations. The client must normalize both modes to a stable public response format without hiding server semantics or reimplementing transport behavior.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Parent global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/embed-command-and-result-contract-alignment.md`

## Scope

### Included

- `embed_client/async_client_api_mixin.py` - result handling in `embed()` method (lines 492-588)
- `embed_client/testing_client.py` - result handling in `embed()` method
- `embed_client/async_client_queue_mixin.py` - `wait_for_job()` and `wait_for_job_via_websocket()` methods
- Response extraction and normalization logic for immediate vs queued results
- Job ID extraction from adapter responses

### Excluded

- Parameter building for embed command (covered in `embed-command-contract-alignment.md`)
- `embed_job_status` command implementation (covered in `embed-job-status-alignment.md`)
- Identifier model separation (JSON-RPC id vs job_id vs WebSocket correlation) - covered in Step 3
- Response normalizer implementation details (only usage, not internal logic changes)

## Boundaries

This task must NOT touch:
- `embed_client/adapter_transport.py` - adapter transport layer (only uses existing methods)
- Identifier correlation logic (Step 3 responsibility)
- Queue submission logic (uses existing `execute_command_unified`)

## Dependencies

- Depends on: `embed-command-contract-alignment.md` (must complete first to ensure canonical params are built)
- Can run in parallel with: `embed-job-status-alignment.md`, `models-timing-stats-alignment.md`

## Parallelization Note

This tactical task can run in parallel with:
- `embed-job-status-alignment.md` (after embed command contract is aligned)
- `models-timing-stats-alignment.md`

## Expected Outcome

1. `embed()` method correctly detects immediate vs queued results from adapter response
2. Immediate results are normalized to public format: `{"results": [...], "model": "...", "dimension": N, "device": "..."}`
3. Queued results trigger waiting logic (WebSocket or polling) and normalize final result to same public format
4. Job ID extraction correctly identifies queued mode from various adapter response shapes
5. Response normalization preserves server semantics (does not hide job_id or status when appropriate)
6. Both `AsyncClientAPIMixin.embed()` and `EmbeddingServiceClient.embed()` handle both modes correctly

## Correction Items

### Current Implementation Issues

1. **File**: `embed_client/async_client_api_mixin.py`, method `embed()` (lines 492-558)
   - **Issue**: Complex nested result extraction logic may not handle all adapter response shapes correctly
   - **Correction**: Simplify result extraction to handle adapter response format: `{"mode": "immediate|queued", "result": {...}, "job_id": "..."}`
   - **Verification**: Test with both immediate and queued adapter responses

2. **File**: `embed_client/async_client_api_mixin.py`, method `embed()` (lines 560-588)
   - **Issue**: Immediate result extraction may not handle all server response shapes
   - **Correction**: Ensure extraction handles: `{"result": {"data": {"results": [...]}}}` and `{"result": {"data": {"embeddings": [...]}}}`
   - **Verification**: Test with both `results` and `embeddings` formats

3. **File**: `embed_client/async_client_api_mixin.py`, function `_extract_job_id_from_response()` (lines 30-50)
   - **Issue**: May not handle adapter response format correctly
   - **Correction**: Ensure it checks `result.get("job_id")` and `result.get("result", {}).get("data", {}).get("job_id")` and adapter `mode="queued"` format
   - **Verification**: Test with adapter queued response format

4. **File**: `embed_client/testing_client.py`, method `embed()` (lines 271-313)
   - **Issue**: May not handle both immediate and queued modes correctly
   - **Correction**: Ensure it detects queued mode and waits appropriately
   - **Verification**: Test with both immediate and queued server responses

## Questions/Escalation Rule

Escalate to global orchestrator if:
- Adapter response format changes require global architecture changes
- Server result format changes require breaking public API changes
- Response normalization requirements conflict with identifier separation (Step 3)

## File Inventory

### Files to Modify

1. **Action**: modify
   **Path**: `embed_client/async_client_api_mixin.py`
   **Purpose**: Align result handling in `embed()` method for immediate and queued modes

2. **Action**: modify
   **Path**: `embed_client/testing_client.py`
   **Purpose**: Align result handling in `embed()` method for immediate and queued modes

3. **Action**: modify
   **Path**: `embed_client/async_client_api_mixin.py`
   **Purpose**: Update `_extract_job_id_from_response()` to handle adapter response format

### Files to Read (Reference Only)

1. **Path**: `embed_client/async_client_queue_mixin.py`
   **Purpose**: Understand `wait_for_job()` and `wait_for_job_via_websocket()` return formats

2. **Path**: `embed_client/response_normalizer.py`
   **Purpose**: Understand existing normalization logic (use, don't modify internal implementation)

3. **Path**: `embed_client/response_parsers.py`
   **Purpose**: Understand `extract_embedding_data()` and `extract_embeddings()` functions

4. **Path**: `embed_client/adapter_transport.py`
   **Purpose**: Understand `execute_command_unified()` return format

## Class/Function Inventory

### Function: `_extract_job_id_from_response(result: Dict[str, Any]) -> Optional[str]`

**Base class**: None (module-level function)

**Purpose**: Extract job_id from adapter/server response to detect queued mode

**Behavior**:
- Checks `result.get("job_id")` (adapter top-level)
- Checks `result.get("result", {}).get("job_id")` (nested in result)
- Checks `result.get("result", {}).get("data", {}).get("job_id")` (server response shape)
- Checks `result.get("data", {}).get("job_id")` (alternative server shape)
- Returns first non-empty string found, or `None` if no job_id found

### Class: `AsyncClientAPIMixin`

**Public methods to modify**:

1. **Method**: `embed()` - result handling section (lines 492-588)
   **Behavior**:
   - After calling `execute_command_unified()`, extract job_id using `_extract_job_id_from_response()`
   - If `wait=False` and job_id found: return `{"job_id": job_id, "status": "...", "message": "..."}`
   - If `wait=True` and job_id found: call `wait_for_job_via_websocket()` or `wait_for_job()`, then normalize result
   - If no job_id (immediate mode): extract result from `result.get("result", {})` and normalize to public format
   - Normalize both immediate and queued final results to: `{"results": [...], "model": "...", "dimension": N, "device": "..."}`

### Class: `EmbeddingServiceClient`

**Public methods to modify**:

1. **Method**: `embed()` - result handling section
   **Behavior**:
   - After calling adapter transport, detect immediate vs queued mode
   - If queued and `wait=True`: wait for completion, then normalize result
   - If queued and `wait=False`: return `{"job_id": "...", "status": "...", "message": "..."}`
   - If immediate: normalize result to public format

## Data Structures

### Response Format: Immediate Mode

```python
{
    "results": [
        {
            "body": str,
            "embedding": List[float],
            "tokens": List[str],
            "bm25_tokens": List[str]
        },
        ...
    ],
    "model": str,
    "dimension": int,
    "device": str
}
```

### Response Format: Queued Mode (wait=False)

```python
{
    "job_id": str,
    "status": str,  # "pending", "queued", etc.
    "message": str
}
```

### Response Format: Queued Mode (wait=True, final)

```python
{
    "results": [
        {
            "body": str,
            "embedding": List[float],
            "tokens": List[str],
            "bm25_tokens": List[str]
        },
        ...
    ],
    "model": str,
    "dimension": int,
    "device": str
}
```

### Adapter Response Format: Immediate

```python
{
    "mode": "immediate",
    "result": {
        "result": {
            "data": {
                "results": [...],
                "model": "...",
                "dimension": N,
                "device": "..."
            }
        }
    }
}
```

### Adapter Response Format: Queued

```python
{
    "mode": "queued",
    "job_id": "job-123",
    "status": "pending",
    "result": {
        "result": {
            "data": {
                "job_id": "job-123",
                "status": "pending",
                "message": "..."
            }
        }
    }
}
```

## Import Map

### File: `embed_client/async_client_api_mixin.py`

**Existing imports** (keep):
```python
from typing import Any, Dict, List, Optional
from embed_client.exceptions import EmbeddingServiceTimeoutError
from embed_client.response_parsers import extract_embedding_data, extract_embeddings
```

**No additional imports needed**

### File: `embed_client/testing_client.py`

**Existing imports** (keep):
```python
from typing import Any, Dict, List, Optional
from embed_client.exceptions import EmbeddingServiceError, EmbeddingServiceTimeoutError
```

**No additional imports needed**

## Error Handling Map

### Method: `AsyncClientAPIMixin.embed()` - Result Handling

1. **Job waiting timeout**:
   - **Exception**: `EmbeddingServiceTimeoutError`
   - **Condition**: `wait=True`, job_id found, but job does not complete within `timeout` seconds
   - **Message**: Adapter timeout error message
   - **Caller action**: Increase timeout or check job status separately

2. **Result extraction failure**:
   - **Exception**: `EmbeddingServiceAPIError` or `ValueError`
   - **Condition**: Result format is unexpected and cannot be normalized
   - **Message**: "Failed to extract embedding results from response"
   - **Caller action**: Check server response format or report bug

3. **Adapter transport errors**:
   - **Exception**: `EmbeddingServiceError` or `EmbeddingServiceAPIError` (from adapter)
   - **Condition**: Adapter transport fails during command execution or job waiting
   - **Message**: Adapter error message
   - **Caller action**: Check server connectivity and parameters

### Method: `EmbeddingServiceClient.embed()` - Result Handling

1. **Job waiting timeout**:
   - **Exception**: `EmbeddingServiceTimeoutError`
   - **Condition**: `wait=True`, job does not complete within `wait_timeout` seconds
   - **Message**: Adapter timeout error message
   - **Caller action**: Increase `wait_timeout` or check job status separately

2. **Result extraction failure**:
   - **Exception**: `EmbeddingServiceError`
   - **Condition**: Result format is unexpected
   - **Message**: "Failed to extract embedding results"
   - **Caller action**: Check server response format

## Config Dependency

### Config Keys Used

1. **Key**: `timeout` (method parameter, not config)
   - **Type**: `float`
   - **Default**: `60.0` seconds (if `timeout=None` and `wait=True`)
   - **Valid values**: `>= 0.0` (0 means unlimited)
   - **Access location**: Method parameter, used in `wait_for_job()` and `wait_for_job_via_websocket()`

2. **Key**: `poll_interval` (method parameter, not config)
   - **Type**: `float`
   - **Default**: `0.3` seconds (for `AsyncClientAPIMixin`), `1.0` seconds (for `EmbeddingServiceClient`)
   - **Valid values**: `> 0.0`
   - **Access location**: Method parameter, used in `wait_for_job()` when `use_push=False`

## Test Plan

### Test File: `tests/test_embed_result_mode_handling.py`

**Test class**: `TestEmbedResultModeHandling`

**Test methods**:

1. **Test**: `test_embed_immediate_result_normalization()`
   - **Setup**: Mock `_adapter_transport.execute_command_unified` to return immediate result
   - **Mock response**: `{"mode": "immediate", "result": {"result": {"data": {"results": [...], "model": "test", "dimension": 384}}}}`
   - **Action**: Call `embed(texts=["text"], wait=True)`
   - **Assert**: Returns `{"results": [...], "model": "test", "dimension": 384}`

2. **Test**: `test_embed_queued_result_detection()`
   - **Setup**: Mock `_adapter_transport.execute_command_unified` to return queued result
   - **Mock response**: `{"mode": "queued", "job_id": "job-123", "status": "pending"}`
   - **Action**: Call `embed(texts=["text"], wait=False)`
   - **Assert**: Returns `{"job_id": "job-123", "status": "pending", "message": "..."}`

3. **Test**: `test_embed_queued_result_wait_and_normalize()`
   - **Setup**: Mock `execute_command_unified` to return queued, mock `wait_for_job_via_websocket` to return final result
   - **Mock queued response**: `{"mode": "queued", "job_id": "job-123"}`
   - **Mock final response**: `{"data": {"results": [...], "model": "test", "dimension": 384}}`
   - **Action**: Call `embed(texts=["text"], wait=True, use_push=True)`
   - **Assert**: Returns normalized `{"results": [...], "model": "test", "dimension": 384}`

4. **Test**: `test_extract_job_id_from_adapter_response()`
   - **Test cases**:
     - `{"job_id": "job-123"}` → returns `"job-123"`
     - `{"result": {"job_id": "job-123"}}` → returns `"job-123"`
     - `{"result": {"data": {"job_id": "job-123"}}}` → returns `"job-123"`
     - `{"mode": "queued", "job_id": "job-123"}` → returns `"job-123"`
     - `{"result": {"data": {"results": [...]}}}` → returns `None` (no job_id)

5. **Test**: `test_embed_handles_legacy_embeddings_format()`
   - **Setup**: Mock immediate result with `embeddings` instead of `results`
   - **Mock response**: `{"result": {"data": {"embeddings": [[0.1, 0.2], [0.3, 0.4]]}}}`
   - **Action**: Call `embed(texts=["text1", "text2"], wait=True)`
   - **Assert**: Returns normalized format (may convert `embeddings` to `results` or preserve both)

6. **Test**: `test_testing_client_embed_result_modes()`
   - **Setup**: Mock `_transport.execute_async` or `execute_command_unified`
   - **Test cases**: Immediate result, queued result with `wait=True`, queued result with `wait=False`
   - **Assert**: All modes return correct normalized format

**Required fixtures/mocks**:
- Mock `_adapter_transport.execute_command_unified` for `AsyncClientAPIMixin` tests
- Mock `wait_for_job_via_websocket` and `wait_for_job` methods
- Mock `_transport` for `EmbeddingServiceClient` tests

## Concrete Examples

### Example 1: Immediate Result

**Adapter response**:
```python
{
    "mode": "immediate",
    "result": {
        "result": {
            "data": {
                "results": [
                    {"body": "Hello", "embedding": [0.1, 0.2, 0.3], "tokens": ["hello"], "bm25_tokens": ["hello"]}
                ],
                "model": "test-model",
                "dimension": 384,
                "device": "cpu"
            }
        }
    }
}
```

**Expected public return**:
```python
{
    "results": [
        {"body": "Hello", "embedding": [0.1, 0.2, 0.3], "tokens": ["hello"], "bm25_tokens": ["hello"]}
    ],
    "model": "test-model",
    "dimension": 384,
    "device": "cpu"
}
```

### Example 2: Queued Result (wait=False)

**Adapter response**:
```python
{
    "mode": "queued",
    "job_id": "job-abc123",
    "status": "pending",
    "result": {
        "result": {
            "data": {
                "job_id": "job-abc123",
                "status": "pending",
                "message": "Job queued successfully"
            }
        }
    }
}
```

**Expected public return**:
```python
{
    "job_id": "job-abc123",
    "status": "pending",
    "message": "Job queued successfully"
}
```

### Example 3: Queued Result (wait=True, final)

**Initial adapter response** (same as Example 2)

**After waiting, final result from `wait_for_job_via_websocket()`**:
```python
{
    "data": {
        "results": [
            {"body": "Hello", "embedding": [0.1, 0.2, 0.3], "tokens": ["hello"], "bm25_tokens": ["hello"]}
        ],
        "model": "test-model",
        "dimension": 384,
        "device": "cpu"
    }
}
```

**Expected public return**:
```python
{
    "results": [
        {"body": "Hello", "embedding": [0.1, 0.2, 0.3], "tokens": ["hello"], "bm25_tokens": ["hello"]}
    ],
    "model": "test-model",
    "dimension": 384,
    "device": "cpu"
}
```

## Algorithm/Logic Description

### Function: `_extract_job_id_from_response(result: Dict[str, Any]) -> Optional[str]`

1. **Check top-level job_id**:
   - If `result.get("job_id")` is a non-empty string: return it

2. **Check nested in result**:
   - If `result.get("result", {}).get("job_id")` is a non-empty string: return it

3. **Check nested in result.data**:
   - If `result.get("result", {}).get("data", {}).get("job_id")` is a non-empty string: return it

4. **Check top-level data**:
   - If `result.get("data", {}).get("job_id")` is a non-empty string: return it

5. **Return None** if no job_id found

### Method: `AsyncClientAPIMixin.embed()` - Result Handling Section

1. **Call adapter transport**:
   - `result = await client_to_use._adapter_transport.execute_command_unified(command="embed", params=params, use_cmd_endpoint=False, auto_poll=False)`

2. **Extract job_id**:
   - `extracted_job_id = _extract_job_id_from_response(result) if isinstance(result, Dict) else None`

3. **Handle queued mode (wait=False)**:
   - If `not wait and extracted_job_id`:
     - Extract status and message from `result.get("result", {}).get("data", {})`
     - Return `{"job_id": extracted_job_id, "status": status, "message": message}`

4. **Handle queued mode (wait=True)**:
   - If `extracted_job_id and wait`:
     - Set `wait_timeout = timeout if timeout is not None else 60.0`
     - If `use_push`: call `wait_for_job_via_websocket(extracted_job_id, timeout=wait_timeout)`
     - Else: call `wait_for_job(extracted_job_id, timeout=wait_timeout, poll_interval=poll_interval)`
     - Extract result from `job_result`: check `job_result.get("data")`, then `job_result.get("result")`, then `job_result` itself
     - Normalize to public format: `{"results": [...], "model": "...", "dimension": N, "device": "..."}`

5. **Handle immediate mode**:
   - If no `extracted_job_id`:
     - Extract from `result.get("result", {})`
     - Check for `result.get("result", {}).get("data", {})` containing `results` or `embeddings`
     - Normalize to public format using `extract_embedding_data()` or `extract_embeddings()` if needed
     - Return `{"results": [...], "model": "...", "dimension": N, "device": "..."}`

### Method: `EmbeddingServiceClient.embed()` - Result Handling Section

1. **Call adapter transport**:
   - If `wait=True` and WebSocket available: use `execute_async("embed_execute", params)`
   - Else: use `execute_command_unified(command="embed", params=params, ...)`

2. **Detect mode and handle**:
   - Extract job_id from response
   - If queued and `wait=False`: return `{"job_id": ..., "status": ..., "message": ...}`
   - If queued and `wait=True`: wait for completion, then normalize result
   - If immediate: normalize result to public format

## Forbidden Approaches

1. **DO NOT** reimplement transport semantics - use adapter `execute_command_unified()` and waiting methods
2. **DO NOT** hide server semantics - preserve job_id and status when `wait=False`
3. **DO NOT** assume all results are immediate - always check for job_id
4. **DO NOT** modify adapter transport layer - only use existing methods
5. **DO NOT** conflate JSON-RPC request id with job_id - job_id is for queue lifecycle
6. **DO NOT** modify response normalizer internal implementation - only use existing normalization functions
7. **DO NOT** implement custom WebSocket waiting - use existing `wait_for_job_via_websocket()` method
