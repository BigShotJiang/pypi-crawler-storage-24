Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Clean Up AdapterTransport Token Generation

## Purpose

Remove the unused token generation method `_generate_token_from_config` from `AdapterTransport`. This method currently returns `None` for all cases and is not actually generating tokens, since token generation is handled by the adapter's JsonRpcClient. The method call should be removed, and token handling should rely entirely on adapter parameters passed during JsonRpcClient construction.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`

## Scope

**Included:**
- Remove `_generate_token_from_config` method from `AdapterTransport`
- Remove the call to `_generate_token_from_config` in `_ensure_client` method
- Simplify `_ensure_client` to use adapter parameters directly without token generation attempt
- Ensure token is passed directly from `adapter_params` to JsonRpcClient constructor
- Update docstrings to clarify that token must be provided in adapter_params

**Excluded:**
- Changes to `AdapterConfigFactory` (it already provides token in adapter_params)
- Changes to authentication manager (handled in separate task)
- Changes to client factory (handled in separate task)
- Changes to test files (handled in separate task)

## Boundaries

- Do not modify `AdapterConfigFactory` - it's responsible for providing correct adapter_params
- Do not modify authentication logic - adapter handles all authentication
- Do not add new token generation logic - adapter handles token generation

## Dependencies

None. This task can run in parallel with other tasks in this global step.

## Parallelization Note

This task can run in parallel with:
- "Remove fake auth execution from ClientAuthManager"
- "Verify and update client construction paths"

## Expected Outcome

1. `AdapterTransport._generate_token_from_config` method is removed
2. `AdapterTransport._ensure_client` no longer attempts to generate tokens
3. Token is passed directly from `adapter_params` to JsonRpcClient constructor
4. All token handling is delegated to adapter
5. Code is simpler and clearer about adapter-only responsibility

## Correction Items

**File: `embed_client/adapter_transport.py`**
- Remove method: `_generate_token_from_config`
- Simplify `_ensure_client`: remove token generation attempt, use token directly from `adapter_params`
- Update docstrings to clarify token must be in adapter_params

## Questions/Escalation Rule

- If token generation is actually needed for JWT/Basic auth and adapter doesn't handle it, escalate to orchestrator
- If `_original_config` is needed for other purposes beyond token generation, keep it but remove token generation logic

## File Inventory

**Action: modify**
- Path: `embed_client/adapter_transport.py`
- Purpose: Remove unused token generation method and simplify client initialization

## Class/Function Inventory

**Class: `AdapterTransport`**
- Base class: None
- Purpose: Wrapper around JsonRpcClient providing transport layer
- Methods to modify:
  - `_ensure_client() -> JsonRpcClient`: Remove token generation call, use token directly from adapter_params
- Methods to remove:
  - `_generate_token_from_config() -> Optional[str]`: REMOVE - unused, returns None always
- Other methods: No changes needed

## Data Structures

No new data structures. Existing `adapter_params` dict structure remains unchanged:
- `adapter_params["token"]`: Optional[str] - Token value (may be None)
- `adapter_params["token_header"]`: Optional[str] - Header name for token
- `adapter_params["_original_config"]`: Optional[Dict[str, Any]] - Original config (may be removed if only used for token generation)

## Import Map

**File: `embed_client/adapter_transport.py`**
```python
import logging
import time
from typing import Any, Awaitable, Callable, Dict, Optional

from mcp_proxy_adapter.client.jsonrpc_client import (
    BidirectionalWsChannel,
    JsonRpcClient,
    open_bidirectional_ws_channel as adapter_open_bidirectional_ws_channel,
)

from embed_client.constants import DEFAULT_POLL_INTERVAL
```
No import changes needed.

## Error Handling Map

**Method: `_ensure_client() -> JsonRpcClient`**
- Exception: None (may raise exceptions from JsonRpcClient constructor)
- Conditions: Creates JsonRpcClient with parameters from adapter_params
- Caller action: Handle JsonRpcClient construction errors as adapter errors

## Config Dependency

**Config keys read:**
- None directly - all config is provided via `adapter_params` dict
- `adapter_params["token"]`: Token value (may be None)
- `adapter_params["token_header"]`: Token header name (may be None)
- `adapter_params["protocol"]`: Protocol (http, https, mtls)
- `adapter_params["host"]`: Server host
- `adapter_params["port"]`: Server port
- `adapter_params["cert"]`: Client certificate file path (optional)
- `adapter_params["key"]`: Client private key file path (optional)
- `adapter_params["ca"]`: CA certificate file path (optional)
- `adapter_params["check_hostname"]`: Whether to check hostname (default False)

**Where accessed:**
- `AdapterTransport.__init__`: Stores adapter_params
- `AdapterTransport._ensure_client`: Reads adapter_params to construct JsonRpcClient

## Test Plan

**Test file: `tests/test_adapter_transport.py` (update existing)**
- Test class: `TestAdapterTransport`
- Test methods:
  - `test_ensure_client_with_token`: Assert JsonRpcClient created with token from adapter_params
  - `test_ensure_client_without_token`: Assert JsonRpcClient created without token when None
  - `test_generate_token_method_removed`: Assert `_generate_token_from_config` method no longer exists
  - `test_token_passed_to_adapter`: Assert token from adapter_params is passed to JsonRpcClient

## Concrete Examples

**Input: adapter_params with token**
```python
adapter_params = {
    "protocol": "https",
    "host": "localhost",
    "port": 8001,
    "token_header": "X-API-Key",
    "token": "test-api-key-123",
    "cert": None,
    "key": None,
    "ca": None,
    "check_hostname": False,
}
transport = AdapterTransport(adapter_params)
client = await transport._ensure_client()
```

**Expected output:**
- JsonRpcClient created with `token="test-api-key-123"` and `token_header="X-API-Key"`
- No call to `_generate_token_from_config` (method doesn't exist)
- Token comes directly from `adapter_params["token"]`

**Input: adapter_params without token (JWT/Basic auth)**
```python
adapter_params = {
    "protocol": "https",
    "host": "localhost",
    "port": 8001,
    "token_header": "Authorization",
    "token": None,  # Will be generated by adapter
    "cert": None,
    "key": None,
    "ca": None,
    "check_hostname": False,
}
transport = AdapterTransport(adapter_params)
client = await transport._ensure_client()
```

**Expected output:**
- JsonRpcClient created with `token=None` and `token_header="Authorization"`
- Adapter handles token generation internally if needed
- No attempt to generate token in AdapterTransport

## Algorithm/Logic Description

**Method: `_ensure_client() -> JsonRpcClient` (simplified version)**
1. Check if `self._client` is already initialized
2. If not initialized:
   - Read `token` directly from `self.adapter_params.get("token")`
   - Read `token_header` from `self.adapter_params.get("token_header")`
   - Create JsonRpcClient with all parameters from adapter_params:
     - `protocol=self.adapter_params["protocol"]`
     - `host=self.adapter_params["host"]`
     - `port=self.adapter_params["port"]`
     - `token_header=token_header`
     - `token=token` (use value directly, no generation)
     - `cert=self.adapter_params.get("cert")`
     - `key=self.adapter_params.get("key")`
     - `ca=self.adapter_params.get("ca")`
     - `check_hostname=self.adapter_params.get("check_hostname", False)`
   - Store in `self._client`
3. Return `self._client`

**Removed method: `_generate_token_from_config() -> Optional[str]`**
- This method is completely removed
- It previously returned None for all cases
- Token generation is handled by adapter's JsonRpcClient

## Forbidden Approaches

- Do NOT add new token generation logic - adapter handles all token generation
- Do NOT modify `AdapterConfigFactory` - it already provides correct adapter_params
- Do NOT keep `_generate_token_from_config` "for future use" - remove it completely
- Do NOT add fallback token generation - adapter must handle all token generation
- Do NOT modify JsonRpcClient usage - use it as provided by adapter
