Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Update Tests for Adapter-Centric Architecture

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- Tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric.md`

## Atomic Steps Summary

This tactical task is decomposed into 5 atomic steps that update tests to reflect the adapter-centric architecture.

### Step 1: Update Tests for ClientAuthManager
- **File**: `update-test-auth-manager.md`
- **Target**: `tests/test_auth_manager.py`
- **Action**: Remove fake authentication execution tests, keep config validation tests, add test for removed methods
- **Dependencies**: None

### Step 2: Update Tests for AdapterTransport
- **File**: `update-test-adapter-transport.md`
- **Target**: `tests/test_adapter_transport.py` (create new)
- **Action**: Create tests verifying token is passed from adapter_params, no token generation
- **Dependencies**: None

### Step 3: Update Tests for ClientFactory
- **File**: `update-test-client-factory.md`
- **Target**: `tests/test_client_factory.py`
- **Action**: Add tests verifying all factory methods create clients with adapter transport
- **Dependencies**: None

### Step 4: Update Tests for EmbeddingServiceAsyncClient
- **File**: `update-test-async-client.md`
- **Target**: `tests/test_async_client.py`
- **Action**: Add tests verifying client uses adapter transport and config factory
- **Dependencies**: None

### Step 5: Update Adapter Integration Tests
- **File**: `update-test-adapter-integration.md`
- **Target**: `tests/test_adapter_phase1.py`, `tests/test_adapter_phase2.py`, `tests/test_adapter_integration.py`
- **Action**: Update integration tests to verify adapter-centric architecture
- **Dependencies**: None

## Parallel Execution

All 5 atomic steps can be executed in parallel as they:
- Modify different test files
- Have no dependencies on each other
- Test different aspects of the adapter-centric architecture

See `parallel-waves.md` for parallel execution plan.

## Completion Criteria

All atomic steps are complete when:
1. All test files are updated
2. All tests pass
3. No tests verify fake authentication execution
4. All tests verify adapter-only behavior
5. Integration tests verify adapter integration works correctly
