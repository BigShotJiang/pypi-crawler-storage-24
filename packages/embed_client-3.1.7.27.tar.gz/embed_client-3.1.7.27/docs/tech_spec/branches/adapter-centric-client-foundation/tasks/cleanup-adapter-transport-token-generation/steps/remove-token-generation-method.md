Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Remove Token Generation Method from AdapterTransport

## Executor Role

`coder_auto` - Implement the code changes described in this step.

## Execution Directive

Remove the unused `_generate_token_from_config` method from `AdapterTransport` class and simplify `_ensure_client` to use token directly from `adapter_params` without attempting token generation. Remove the `_original_config` instance attribute since it's only used for token generation.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- Tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/cleanup-adapter-transport-token-generation.md`

## Step Scope

**Target file:** `embed_client/adapter_transport.py`
**Action:** modify

This step removes unused token generation logic and simplifies client initialization to rely entirely on adapter parameters.

## Dependency Contract

**Dependencies:** None. This step can run in parallel with other atomic steps.

**Dependents:** None identified. This is a cleanup step that removes unused code.

## Required Context

- The `_generate_token_from_config` method currently always returns `None` and is not actually generating tokens
- Token generation is handled by the adapter's `JsonRpcClient`, not by `AdapterTransport`
- The `_original_config` attribute is only used by `_generate_token_from_config` and can be removed
- The `adapter_params` dictionary already contains the `token` value that should be used directly
- All token handling must be delegated to the adapter

## Read First

Before starting implementation, read these files:

1. `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` - Current implementation
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - Architecture context
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md` - Global step context
4. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/cleanup-adapter-transport-token-generation.md` - Tactical task details

## Expected File Change

**File:** `embed_client/adapter_transport.py`

**Changes:**
1. Remove the `_original_config` instance attribute from `__init__` method (line 47)
2. Remove the token generation call from `_ensure_client` method (lines 65-67)
3. Simplify `_ensure_client` to read token directly from `adapter_params` without conditional generation
4. Remove the entire `_generate_token_from_config` method (lines 83-103)
5. Update docstrings in `__init__` and `_ensure_client` to clarify that token must be provided in `adapter_params`

## Forbidden Alternatives

- Do NOT keep `_generate_token_from_config` method "for future use" - remove it completely
- Do NOT add fallback token generation logic - adapter must handle all token generation
- Do NOT modify `JsonRpcClient` usage - use it as provided by adapter
- Do NOT add new token generation logic - adapter handles token generation
- Do NOT keep `_original_config` attribute - it's only used for token generation
- Do NOT modify other methods in the class - only `__init__` and `_ensure_client` are affected

## Atomic Operations

### Operation 1: Remove `_original_config` from `__init__`

**Location:** `AdapterTransport.__init__` method
**Current code (line 47):**
```python
self._original_config = adapter_params.get("_original_config")
```

**Action:** Remove this line completely.

**Result:** The `_original_config` attribute is no longer stored in the instance.

### Operation 2: Simplify `_ensure_client` method

**Location:** `AdapterTransport._ensure_client` method
**Current code (lines 58-81):**
```python
async def _ensure_client(self) -> JsonRpcClient:
    """Ensure JsonRpcClient is initialized."""
    if self._client is None:
        # Extract token dynamically if needed (for JWT/Basic)
        token = self.adapter_params.get("token")
        token_header = self.adapter_params.get("token_header")

        # If token is None but we have auth config, generate it
        if token is None and token_header and self._original_config:
            token = await self._generate_token_from_config()

        self._client = JsonRpcClient(
            protocol=self.adapter_params["protocol"],
            host=self.adapter_params["host"],
            port=self.adapter_params["port"],
            token_header=token_header,
            token=token,
            cert=self.adapter_params.get("cert"),
            key=self.adapter_params.get("key"),
            ca=self.adapter_params.get("ca"),
            check_hostname=self.adapter_params.get("check_hostname", False),
        )

    return self._client
```

**Action:** Replace with simplified version that removes token generation attempt.

**New code:**
```python
async def _ensure_client(self) -> JsonRpcClient:
    """
    Ensure JsonRpcClient is initialized.
    
    Token must be provided in adapter_params. Token generation is handled
    by the adapter's JsonRpcClient, not by this transport layer.
    """
    if self._client is None:
        token = self.adapter_params.get("token")
        token_header = self.adapter_params.get("token_header")

        self._client = JsonRpcClient(
            protocol=self.adapter_params["protocol"],
            host=self.adapter_params["host"],
            port=self.adapter_params["port"],
            token_header=token_header,
            token=token,
            cert=self.adapter_params.get("cert"),
            key=self.adapter_params.get("key"),
            ca=self.adapter_params.get("ca"),
            check_hostname=self.adapter_params.get("check_hostname", False),
        )

    return self._client
```

**Changes:**
- Remove comment "Extract token dynamically if needed (for JWT/Basic)"
- Remove the conditional block that calls `_generate_token_from_config` (lines 65-67)
- Update docstring to clarify that token must be in `adapter_params` and generation is handled by adapter
- Keep all other logic unchanged

### Operation 3: Update `__init__` docstring

**Location:** `AdapterTransport.__init__` method docstring
**Current docstring (lines 38-44):**
```python
"""
Initialize adapter transport with configuration parameters.

Args:
    adapter_params: Dictionary with protocol, host, port, token_header, token,
                  cert, key, ca, check_hostname, timeout
"""
```

**Action:** Update to clarify that token must be provided in `adapter_params`.

**New docstring:**
```python
"""
Initialize adapter transport with configuration parameters.

Token must be provided in adapter_params if authentication is required.
Token generation is handled by the adapter's JsonRpcClient, not by this
transport layer.

Args:
    adapter_params: Dictionary with protocol, host, port, token_header, token,
                  cert, key, ca, check_hostname, timeout. Token value may be
                  None if adapter handles token generation internally.
"""
```

### Operation 4: Remove `_generate_token_from_config` method

**Location:** `AdapterTransport._generate_token_from_config` method
**Current code (lines 83-103):**
```python
async def _generate_token_from_config(self) -> Optional[str]:
    """
    Generate authentication token from original config if needed.

    This handles JWT and Basic auth token generation.
    """
    if not self._original_config:
        return None

    auth_config = self._original_config.get("auth", {})
    auth_method = auth_config.get("method", "none")

    if auth_method == "jwt":
        # JWT tokens are typically generated by auth manager
        # For now, return None - adapter will handle it via headers
        return None
    elif auth_method == "basic":
        # Basic auth is handled via adapter's token mechanism
        return None

    return None
```

**Action:** Remove this entire method completely (all 21 lines).

**Result:** The method no longer exists in the class.

## Expected Deliverables

After implementation, the file `embed_client/adapter_transport.py` must:

1. Not contain `_original_config` instance attribute
2. Not contain `_generate_token_from_config` method
3. Have `_ensure_client` method that reads token directly from `adapter_params` without conditional generation
4. Have updated docstrings in `__init__` and `_ensure_client` clarifying that token must be in `adapter_params`
5. Pass all existing tests (tests are updated in a separate task)
6. Maintain all other functionality unchanged

## Mandatory Validation

After implementation, run these exact commands and verify the expected output:

**Formatting check:**
```bash
black embed_client/adapter_transport.py
```
**Expected:** "reformatted" or "already well formatted" (exit code 0)

**Linting check:**
```bash
flake8 embed_client/adapter_transport.py
```
**Expected:** No output (exit code 0)

**Type checking:**
```bash
mypy embed_client/adapter_transport.py
```
**Expected:** "Success: no issues found" (exit code 0)

**Import verification:**
```bash
python -c "from embed_client.adapter_transport import AdapterTransport; print('Import successful')"
```
**Expected:** "Import successful" (exit code 0)

**Method removal verification:**
```bash
python -c "from embed_client.adapter_transport import AdapterTransport; assert not hasattr(AdapterTransport, '_generate_token_from_config'), 'Method still exists'"
```
**Expected:** No output (exit code 0) - method should not exist

**All tests must pass:**
```bash
pytest tests/ -v -k "adapter_transport" --tb=short
```
**Expected:** All tests pass (tests are updated in a separate task, but existing tests should not break)

## Decision Rules

1. **Token value handling:** Always use `adapter_params.get("token")` directly, even if it's `None`. Do not attempt to generate it.
2. **Token header handling:** Always use `adapter_params.get("token_header")` directly, even if it's `None`.
3. **JsonRpcClient construction:** Pass `token` and `token_header` exactly as they appear in `adapter_params`, without modification.
4. **Docstring updates:** Clarify that token must be provided in `adapter_params` and that adapter handles token generation.
5. **Method removal:** Remove `_generate_token_from_config` completely - do not leave it as a stub or comment it out.

## Blackstops

Stop implementation and escalate if:

1. `_original_config` is used in other methods besides `_generate_token_from_config` - escalate to orchestrator_tactical
2. Token generation is actually needed and adapter doesn't handle it - escalate to orchestrator
3. Removing `_generate_token_from_config` breaks existing functionality that depends on it - escalate to orchestrator_tactical
4. `adapter_params` structure is different than expected - escalate to orchestrator_tactical

## Handoff Package

**For coder_auto:**

1. **Target file:** `embed_client/adapter_transport.py` (modify existing file)

2. **File header:** Keep existing header unchanged:
```python
"""
Adapter Transport Wrapper

This module provides a wrapper around mcp_proxy_adapter JsonRpcClient
that exposes methods needed by EmbeddingServiceAsyncClient.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
```

3. **Imports:** Keep all existing imports unchanged:
```python
import logging
import time
from typing import Any, Awaitable, Callable, Dict, Optional

from mcp_proxy_adapter.client.jsonrpc_client import (
    BidirectionalWsChannel,
    JsonRpcClient,
    open_bidirectional_ws_channel as adapter_open_bidirectional_ws_channel,
)

from embed_client.constants import DEFAULT_POLL_INTERVAL
```

4. **Class structure:** `AdapterTransport` class remains the same, with these modifications:
   - Remove `_original_config` from `__init__`
   - Simplify `_ensure_client` (remove token generation call)
   - Remove `_generate_token_from_config` method completely
   - Update docstrings in `__init__` and `_ensure_client`

5. **Method signatures to modify:**

   **Method: `__init__(self, adapter_params: Dict[str, Any]) -> None`**
   - Remove line: `self._original_config = adapter_params.get("_original_config")`
   - Update docstring as specified in Operation 3

   **Method: `_ensure_client(self) -> JsonRpcClient`**
   - Remove token generation conditional block
   - Update docstring as specified in Operation 2
   - Keep all JsonRpcClient construction parameters unchanged

6. **Method to remove completely:**
   - `_generate_token_from_config(self) -> Optional[str]` - remove entire method (lines 83-103)

7. **Constants and literals:**
   - No new constants needed
   - Use existing `adapter_params` dictionary keys: `"token"`, `"token_header"`, `"protocol"`, `"host"`, `"port"`, `"cert"`, `"key"`, `"ca"`, `"check_hostname"`

8. **Error handling:**
   - No changes to error handling - JsonRpcClient constructor may raise exceptions, which should propagate as-is
   - No new exception handling needed

9. **Edge cases:**
   - `adapter_params.get("token")` returns `None`: Pass `None` to JsonRpcClient (adapter handles it)
   - `adapter_params.get("token_header")` returns `None`: Pass `None` to JsonRpcClient (adapter handles it)
   - `adapter_params` missing required keys: JsonRpcClient constructor will handle validation

10. **Validation commands:** See "Mandatory Validation" section above

11. **Forbidden patterns:**
    - Do NOT use `_original_config` anywhere
    - Do NOT call `_generate_token_from_config` anywhere
    - Do NOT add token generation logic
    - Do NOT modify JsonRpcClient constructor call signature
    - Do NOT modify other methods in the class
    - Do NOT use `Any` type annotation (keep existing types)
    - Do NOT add `print()` statements - use existing logger if needed

## Completion Condition

This step is complete when:

1. ✅ `_generate_token_from_config` method is completely removed
2. ✅ `_original_config` attribute is removed from `__init__`
3. ✅ `_ensure_client` no longer attempts token generation
4. ✅ Token is read directly from `adapter_params` and passed to JsonRpcClient
5. ✅ Docstrings are updated to clarify token must be in `adapter_params`
6. ✅ All validation commands pass (black, flake8, mypy, import check, method removal check)
7. ✅ All existing tests pass (tests are updated separately, but must not break)
8. ✅ File size remains under 400 lines (current file is ~419 lines, removing ~25 lines should help)
