Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Update Tests for ClientFactory

## Executor Role

**Executor**: `coder_auto`

## Execution Directive

Update `tests/test_client_factory.py` to add tests verifying that all factory methods create clients with `AdapterTransport` and that no custom auth/TLS execution happens in factory methods.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- Tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric.md`

## Step Scope

**Target file**: `tests/test_client_factory.py`  
**Action**: modify

## Dependency Contract

**Depends on**: None (can run in parallel with other test update steps)  
**Required by**: None

## Required Context

- `ClientFactory` creates clients that use `AdapterTransport` (stored in `client._adapter_transport` or `client._transport`)
- Factory methods do not execute custom authentication or TLS logic
- All security modes (HTTP, HTTPS, mTLS) use adapter transport
- Factory methods create `EmbeddingServiceAsyncClient` instances

## Read First

- `/home/vasilyvz/projects/embed-client/tests/test_client_factory.py` (current state)
- `/home/vasilyvz/projects/embed-client/embed_client/client_factory.py` (to understand factory methods)
- `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` (to understand client structure)

## Expected File Change

**Add new test methods to existing `TestClientFactory` class**:

1. `test_create_client_uses_adapter_transport` - Assert created client uses AdapterTransport
2. `test_factory_methods_no_custom_auth` - Assert no custom auth execution in factory methods
3. `test_factory_methods_no_custom_tls` - Assert no custom TLS execution in factory methods
4. `test_create_http_client_uses_adapter` - Assert HTTP client uses adapter transport
5. `test_create_https_client_uses_adapter` - Assert HTTPS client uses adapter transport
6. `test_create_mtls_client_uses_adapter` - Assert mTLS client uses adapter transport

**Update existing test methods** (if they test security mode detection):
- Update security mode detection tests to verify adapter transport usage

## Forbidden Alternatives

- Do NOT test adapter behavior itself (test only that adapter transport is used)
- Do NOT test authentication execution (adapter handles that)
- Do NOT test TLS execution (adapter handles that)
- Do NOT remove existing factory method tests (keep them, add new ones)

## Atomic Operations

### Step 1: Add test_create_client_uses_adapter_transport

1. Method signature: `def test_create_client_uses_adapter_transport(self):`
2. Method docstring: `"""Assert that created client uses AdapterTransport."""`
3. Method body:
   - Call `client = ClientFactory.create_client("http://localhost", port=8001)`
   - Assert `hasattr(client, "_adapter_transport")` or `hasattr(client, "_transport")`
   - Import `AdapterTransport` if needed
   - Assert `isinstance(client._adapter_transport, AdapterTransport)` or `isinstance(client._transport, AdapterTransport)`

### Step 2: Add test_factory_methods_no_custom_auth

1. Method signature: `def test_factory_methods_no_custom_auth(self):`
2. Method docstring: `"""Assert no custom auth execution in factory methods."""`
3. Method body:
   - Patch `ClientAuthManager.authenticate_api_key` (if it exists) to raise `AssertionError` if called
   - Patch `ClientAuthManager.authenticate_jwt` (if it exists) to raise `AssertionError` if called
   - Patch `ClientAuthManager.authenticate_basic` (if it exists) to raise `AssertionError` if called
   - Call `ClientFactory.create_client("http://localhost", port=8001, auth_method="api_key", api_key="test")`
   - Assert no `AssertionError` was raised (auth methods were not called)
   - Alternative: Assert client has adapter transport (which handles auth)

### Step 3: Add test_factory_methods_no_custom_tls

1. Method signature: `def test_factory_methods_no_custom_tls(self):`
2. Method docstring: `"""Assert no custom TLS execution in factory methods."""`
3. Method body:
   - Patch `ClientSSLManager.create_ssl_context` (if it exists) to raise `AssertionError` if called
   - Call `ClientFactory.create_client("https://localhost", port=8443, ssl_enabled=True)`
   - Assert no `AssertionError` was raised (TLS methods were not called)
   - Alternative: Assert client has adapter transport (which handles TLS)

### Step 4: Add test_create_http_client_uses_adapter

1. Method signature: `def test_create_http_client_uses_adapter(self):`
2. Method docstring: `"""Assert HTTP client uses adapter transport."""`
3. Method body:
   - Call `client = ClientFactory.create_http_client("http://localhost", 8001)`
   - Assert `hasattr(client, "_adapter_transport")` or `hasattr(client, "_transport")`
   - Assert `isinstance(client._adapter_transport, AdapterTransport)` or `isinstance(client._transport, AdapterTransport)`

### Step 5: Add test_create_https_client_uses_adapter

1. Method signature: `def test_create_https_client_uses_adapter(self):`
2. Method docstring: `"""Assert HTTPS client uses adapter transport."""`
3. Method body:
   - Call `client = ClientFactory.create_https_client("https://localhost", 8443)`
   - Assert `hasattr(client, "_adapter_transport")` or `hasattr(client, "_transport")`
   - Assert `isinstance(client._adapter_transport, AdapterTransport)` or `isinstance(client._transport, AdapterTransport)`

### Step 6: Add test_create_mtls_client_uses_adapter

1. Method signature: `def test_create_mtls_client_uses_adapter(self):`
2. Method docstring: `"""Assert mTLS client uses adapter transport."""`
3. Method body:
   - Call `client = ClientFactory.create_mtls_client("https://localhost", "cert.pem", "key.pem", 8443)`
   - Assert `hasattr(client, "_adapter_transport")` or `hasattr(client, "_transport")`
   - Assert `isinstance(client._adapter_transport, AdapterTransport)` or `isinstance(client._transport, AdapterTransport)`

### Step 7: Update security mode tests (if needed)

1. Locate existing security mode detection tests (e.g., `test_detect_security_mode_*`)
2. If they create clients, add assertions that clients use adapter transport
3. If they only test detection logic, leave them unchanged

## Expected Deliverables

- Updated `tests/test_client_factory.py` with:
  - 6 new test methods added to `TestClientFactory` class
  - Existing tests kept (unless they need updates for adapter transport)
  - All tests pass

## Mandatory Validation

**Validation commands** (run after implementation):

1. `black tests/test_client_factory.py`
   - Expected: "reformatted" or "already well formatted"
   - Exit code: 0

2. `flake8 tests/test_client_factory.py`
   - Expected: no output (exit 0)
   - Exit code: 0

3. `mypy tests/test_client_factory.py`
   - Expected: "Success: no issues found" or type checking passes
   - Exit code: 0

4. `pytest tests/test_client_factory.py -v`
   - Expected: all tests PASSED
   - Exit code: 0
   - All test methods must pass, including:
     - `test_create_client_uses_adapter_transport` (new)
     - `test_factory_methods_no_custom_auth` (new)
     - `test_factory_methods_no_custom_tls` (new)
     - `test_create_http_client_uses_adapter` (new)
     - `test_create_https_client_uses_adapter` (new)
     - `test_create_mtls_client_uses_adapter` (new)
     - All existing tests

## Decision Rules

- If client uses `_adapter_transport` attribute, use that in assertions
- If client uses `_transport` attribute, use that in assertions
- If `ClientAuthManager` fake auth methods don't exist, skip patching them in `test_factory_methods_no_custom_auth`
- If `ClientSSLManager` TLS methods don't exist, skip patching them in `test_factory_methods_no_custom_tls`
- If factory methods have different signatures, adjust test calls accordingly

## Blackstops

- Stop if factory methods do not create clients with adapter transport (escalate)
- Stop if client does not have `_adapter_transport` or `_transport` attribute (escalate)
- Stop if tests fail due to missing imports (add imports)

## Handoff Package

**File to modify**: `tests/test_client_factory.py`

**Changes summary**:
- Add 6 new test methods to `TestClientFactory` class
- Verify all factory methods create clients with adapter transport
- Verify no custom auth/TLS execution in factory methods
- Update security mode tests if needed

**Test count**: 
- Before: ~20 test methods (existing)
- After: ~26 test methods (existing + 6 new)

**Dependencies**: None

**Completion condition**: All tests pass, file follows project style rules, adapter transport verified for all factory methods
