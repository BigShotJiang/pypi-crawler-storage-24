Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Clean Up AdapterTransport Token Generation

## Tactical Task

**Task:** Clean Up AdapterTransport Token Generation
**Path:** `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/cleanup-adapter-transport-token-generation.md`

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`

## Atomic Steps Summary

**Goal:** Remove unused token generation method from `AdapterTransport` and simplify client initialization to use token directly from `adapter_params`.

**Total steps:** 1
**Dependency order:** None (single step)
**Parallel execution:** N/A (single step)

## Atomic Steps

### Step 1: Remove Token Generation Method from AdapterTransport

**Step ID:** `remove-token-generation-method`
**File:** `remove-token-generation-method.md`
**Target file:** `embed_client/adapter_transport.py`
**Action:** modify

**Changes:**
- Remove `_original_config` instance attribute from `__init__`
- Remove `_generate_token_from_config` method completely
- Simplify `_ensure_client` to use token directly from `adapter_params`
- Update docstrings to clarify token must be in `adapter_params`

**Dependencies:** None
**Status:** Ready for execution

## Execution Order

All steps can be executed in a single wave (sequential, but no dependencies):

1. `remove-token-generation-method` - Remove token generation method and simplify client initialization

## Validation

After all steps are complete:

1. Run `black embed_client/adapter_transport.py` - must pass
2. Run `flake8 embed_client/adapter_transport.py` - must pass
3. Run `mypy embed_client/adapter_transport.py` - must pass
4. Run `pytest tests/ -v -k "adapter_transport"` - all tests must pass
5. Verify `_generate_token_from_config` method does not exist
6. Verify `_original_config` attribute does not exist

## Notes

- This is a cleanup step that removes unused code
- No new functionality is added
- All token generation is delegated to adapter's JsonRpcClient
- Tests are updated in a separate task, but existing tests should not break
