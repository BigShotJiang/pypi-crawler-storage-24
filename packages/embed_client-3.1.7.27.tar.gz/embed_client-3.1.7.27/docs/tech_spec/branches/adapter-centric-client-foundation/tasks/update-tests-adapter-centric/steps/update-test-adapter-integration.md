Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Update Adapter Integration Tests

## Executor Role

**Executor**: `coder_auto`

## Execution Directive

Update `tests/test_adapter_phase1.py`, `tests/test_adapter_phase2.py`, and `tests/test_adapter_integration.py` to verify they still pass with adapter-centric architecture and update them if they test fake auth methods or custom transport.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- Tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric.md`

## Step Scope

**Target files**: 
- `tests/test_adapter_phase1.py` (modify)
- `tests/test_adapter_phase2.py` (modify)
- `tests/test_adapter_integration.py` (modify)

## Dependency Contract

**Depends on**: None (can run in parallel with other test update steps)  
**Required by**: None

## Required Context

- These tests verify adapter integration works correctly
- They should NOT test fake auth methods (those are removed)
- They should NOT test custom transport (adapter handles transport)
- They should verify adapter-backed clients work correctly
- They may need updates if they reference removed methods or legacy transport

## Read First

- `/home/vasilyvz/projects/embed-client/tests/test_adapter_phase1.py` (current state)
- `/home/vasilyvz/projects/embed-client/tests/test_adapter_phase2.py` (current state)
- `/home/vasilyvz/projects/embed-client/tests/test_adapter_integration.py` (current state)

## Expected File Change

**For each file**:

1. **test_adapter_phase1.py**:
   - Verify tests still pass
   - Remove any tests for fake auth methods if present
   - Update tests that reference custom transport to verify adapter transport
   - Keep tests that verify adapter config factory works correctly

2. **test_adapter_phase2.py**:
   - Verify tests still pass
   - Remove any tests for fake auth methods if present
   - Update tests that reference custom transport to verify adapter transport
   - Keep tests that verify response normalization works correctly

3. **test_adapter_integration.py**:
   - Verify tests still pass
   - Update `test_factory_creates_client_with_adapter` to use `_adapter_transport` or `_transport`
   - Update `test_client_from_config_always_uses_adapter` to use `_adapter_transport` or `_transport`
   - Update `test_all_security_modes_with_adapter` to use `_adapter_transport` or `_transport`
   - Update `test_context_manager_with_adapter` to use `_adapter_transport` or `_transport`

## Forbidden Alternatives

- Do NOT remove integration tests that verify adapter integration works
- Do NOT test fake authentication execution (those methods are removed)
- Do NOT test custom transport creation (adapter handles transport)
- Do NOT mock adapter behavior unnecessarily (use real adapter when possible)

## Atomic Operations

### Step 1: Update test_adapter_integration.py

1. **Update test_factory_creates_client_with_adapter**:
   - Change `assert client._adapter_transport is not None` to check `_adapter_transport` or `_transport`
   - Import `AdapterTransport` if needed
   - Add `isinstance(client._adapter_transport, AdapterTransport)` or `isinstance(client._transport, AdapterTransport)`

2. **Update test_client_from_config_always_uses_adapter**:
   - Change `assert client._adapter_transport is not None` to check `_adapter_transport` or `_transport`
   - Add `isinstance` check for `AdapterTransport`

3. **Update test_all_security_modes_with_adapter**:
   - Change `assert client._adapter_transport is not None` to check `_adapter_transport` or `_transport`
   - Add `isinstance` check for `AdapterTransport`

4. **Update test_context_manager_with_adapter**:
   - Change `assert client._adapter_transport is not None` to check `_adapter_transport` or `_transport`
   - Change `assert hasattr(client._adapter_transport, "_client")` to check correct attribute name
   - Verify adapter transport is initialized correctly

### Step 2: Review test_adapter_phase1.py

1. Read the file and identify any tests that:
   - Test fake auth methods (remove or update)
   - Test custom transport (update to verify adapter transport)
   - Reference removed methods (update or remove)

2. **If tests reference fake auth methods**:
   - Remove the test or update it to verify adapter handles auth
   - Example: If test calls `ClientAuthManager.authenticate_api_key()`, remove it

3. **If tests reference custom transport**:
   - Update to verify adapter transport is used
   - Example: If test checks `client._session`, change to check `client._adapter_transport`

4. **If tests verify adapter config factory**:
   - Keep them as-is (they're correct)

### Step 3: Review test_adapter_phase2.py

1. Read the file and identify any tests that:
   - Test fake auth methods (remove or update)
   - Test custom transport (update to verify adapter transport)
   - Reference removed methods (update or remove)

2. **If tests reference fake auth methods**:
   - Remove the test or update it to verify adapter handles auth

3. **If tests reference custom transport**:
   - Update to verify adapter transport is used

4. **If tests verify response normalization**:
   - Keep them as-is (they're correct)

### Step 4: Add imports if needed

1. If `AdapterTransport` is used in assertions, add import:
   - `from embed_client.adapter_transport import AdapterTransport`

2. If other imports are needed, add them

## Expected Deliverables

- Updated `tests/test_adapter_phase1.py`:
  - No tests for fake auth methods
  - Tests verify adapter transport usage
  - All tests pass

- Updated `tests/test_adapter_phase2.py`:
  - No tests for fake auth methods
  - Tests verify adapter transport usage
  - All tests pass

- Updated `tests/test_adapter_integration.py`:
  - All tests use `_adapter_transport` or `_transport` attribute
  - All tests verify `AdapterTransport` instance
  - All tests pass

## Mandatory Validation

**Validation commands** (run after implementation):

1. `black tests/test_adapter_phase1.py tests/test_adapter_phase2.py tests/test_adapter_integration.py`
   - Expected: "reformatted" or "already well formatted"
   - Exit code: 0

2. `flake8 tests/test_adapter_phase1.py tests/test_adapter_phase2.py tests/test_adapter_integration.py`
   - Expected: no output (exit 0)
   - Exit code: 0

3. `mypy tests/test_adapter_phase1.py tests/test_adapter_phase2.py tests/test_adapter_integration.py`
   - Expected: "Success: no issues found" or type checking passes
   - Exit code: 0

4. `pytest tests/test_adapter_phase1.py -v`
   - Expected: all tests PASSED
   - Exit code: 0

5. `pytest tests/test_adapter_phase2.py -v`
   - Expected: all tests PASSED
   - Exit code: 0

6. `pytest tests/test_adapter_integration.py -v`
   - Expected: all tests PASSED
   - Exit code: 0

## Decision Rules

- If tests reference `_adapter_transport`, use that attribute
- If tests reference `_transport`, use that attribute
- If tests reference both, check which one exists and use that
- If tests reference fake auth methods that don't exist, remove the test
- If tests reference custom transport that doesn't exist, update to verify adapter transport
- If tests verify adapter integration correctly, keep them as-is

## Blackstops

- Stop if tests fail due to missing `_adapter_transport` or `_transport` attribute (escalate)
- Stop if tests fail due to fake auth methods still being called (escalate)
- Stop if tests fail due to custom transport still being used (escalate)
- Stop if adapter integration tests are broken (fix them, don't remove)

## Handoff Package

**Files to modify**: 
- `tests/test_adapter_phase1.py`
- `tests/test_adapter_phase2.py`
- `tests/test_adapter_integration.py`

**Changes summary**:
- Update adapter integration tests to use `_adapter_transport` or `_transport`
- Remove or update tests for fake auth methods
- Remove or update tests for custom transport
- Verify all tests pass with adapter-centric architecture

**Test count**: 
- Keep all existing tests (update them, don't remove unless they test removed functionality)

**Dependencies**: None

**Completion condition**: All tests pass, adapter integration verified, no fake auth or custom transport tests
