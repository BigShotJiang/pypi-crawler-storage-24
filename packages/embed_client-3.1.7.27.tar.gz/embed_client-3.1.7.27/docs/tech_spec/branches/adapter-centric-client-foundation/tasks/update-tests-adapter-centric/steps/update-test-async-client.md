Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Update Tests for EmbeddingServiceAsyncClient

## Executor Role

**Executor**: `coder_auto`

## Execution Directive

Update `tests/test_async_client.py` to add tests verifying that `EmbeddingServiceAsyncClient` uses `AdapterTransport` and `AdapterConfigFactory`, and that no legacy transport code exists. The file currently has `pytestmark.skip` which should remain (it's marked as legacy), but we need to add new tests that are not skipped.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- Tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric.md`

## Step Scope

**Target file**: `tests/test_async_client.py`  
**Action**: modify

## Dependency Contract

**Depends on**: None (can run in parallel with other test update steps)  
**Required by**: None

## Required Context

- `EmbeddingServiceAsyncClient` uses `AdapterTransport` (stored in `client._adapter_transport`)
- `EmbeddingServiceAsyncClient` uses `AdapterConfigFactory` for config conversion
- Client can be created without `auth_manager` (adapter handles auth)
- Client converts config to adapter params using `AdapterConfigFactory`
- Legacy aiohttp transport code no longer exists in client

## Read First

- `/home/vasilyvz/projects/embed-client/tests/test_async_client.py` (current state - note it's skipped)
- `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` (to understand client structure)
- `/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py` (to understand AdapterTransport)
- `/home/vasilyvz/projects/embed-client/embed_client/adapter_config_factory.py` (to understand AdapterConfigFactory)

## Expected File Change

**Add new test class and methods** (after the existing skipped tests):

1. Create new test class `TestEmbeddingServiceAsyncClientAdapter` (not skipped)
2. Add test methods:
   - `test_client_init_uses_adapter_transport` - Assert client uses AdapterTransport
   - `test_client_init_uses_adapter_config_factory` - Assert client uses AdapterConfigFactory
   - `test_client_no_legacy_transport` - Assert no legacy transport code exists
   - `test_client_config_to_adapter_params` - Assert config is converted to adapter params correctly
   - `test_client_init_without_auth_manager` - Assert client can be created without auth_manager
   - `test_client_uses_adapter_for_auth` - Assert client uses adapter transport for authentication

**Note**: Keep existing skipped tests as-is (they're marked as legacy)

## Forbidden Alternatives

- Do NOT remove `pytestmark.skip` from existing tests (they're legacy)
- Do NOT test adapter behavior itself (test only that adapter is used)
- Do NOT test legacy aiohttp transport (it's removed)
- Do NOT test authentication execution (adapter handles that)

## Atomic Operations

### Step 1: Add new test class (not skipped)

1. After the existing `pytestmark = pytest.mark.skip(...)` block and existing test classes
2. Create new test class `TestEmbeddingServiceAsyncClientAdapter`:
   - Docstring: `"""Tests for EmbeddingServiceAsyncClient adapter-centric architecture."""`
   - Do NOT add `pytestmark.skip` to this class (it should run)

### Step 2: Add test_client_init_uses_adapter_transport

1. Method signature: `def test_client_init_uses_adapter_transport(self):`
2. Method docstring: `"""Assert that client initialization uses AdapterTransport."""`
3. Method body:
   - Create config dict: `config_dict = {"server": {"host": "localhost", "port": 8001}, "auth": {"method": "none"}, "ssl": {"enabled": False}}`
   - Create client: `client = EmbeddingServiceAsyncClient(config_dict=config_dict)`
   - Assert `hasattr(client, "_adapter_transport")`
   - Import `AdapterTransport` if needed
   - Assert `isinstance(client._adapter_transport, AdapterTransport)`

### Step 3: Add test_client_init_uses_adapter_config_factory

1. Method signature: `def test_client_init_uses_adapter_config_factory(self):`
2. Method docstring: `"""Assert that client initialization uses AdapterConfigFactory."""`
3. Method body:
   - Create config dict: `config_dict = {"server": {"host": "localhost", "port": 8001}, "auth": {"method": "none"}, "ssl": {"enabled": False}}`
   - Patch `AdapterConfigFactory.from_config_dict` to track calls
   - Create client: `client = EmbeddingServiceAsyncClient(config_dict=config_dict)`
   - Assert `AdapterConfigFactory.from_config_dict` was called with `config_dict`
   - Alternative: Assert client has adapter transport (which uses AdapterConfigFactory)

### Step 4: Add test_client_no_legacy_transport

1. Method signature: `def test_client_no_legacy_transport(self):`
2. Method docstring: `"""Assert no legacy transport code exists."""`
3. Method body:
   - Create client: `client = EmbeddingServiceAsyncClient(config_dict={"server": {"host": "localhost", "port": 8001}})`
   - Assert `not hasattr(client, "_session")` (legacy aiohttp session)
   - Assert `not hasattr(client, "_aiohttp_session")` (if such attribute existed)
   - Assert `hasattr(client, "_adapter_transport")` (adapter transport exists)

### Step 5: Add test_client_config_to_adapter_params

1. Method signature: `def test_client_config_to_adapter_params(self):`
2. Method docstring: `"""Assert config is converted to adapter params correctly."""`
3. Method body:
   - Create config dict: `config_dict = {"server": {"host": "http://localhost", "port": 8001}, "auth": {"method": "api_key", "api_keys": {"user": "key123"}}, "ssl": {"enabled": False}}`
   - Create client: `client = EmbeddingServiceAsyncClient(config_dict=config_dict)`
   - Assert `client._adapter_transport` exists
   - Assert `client._adapter_transport.adapter_params` contains expected values:
     - `protocol == "http"`
     - `host == "localhost"`
     - `port == 8001`
     - `token` may be present if converted from auth config

### Step 6: Add test_client_init_without_auth_manager

1. Method signature: `def test_client_init_without_auth_manager(self):`
2. Method docstring: `"""Assert client can be created without auth_manager."""`
3. Method body:
   - Create config dict without auth: `config_dict = {"server": {"host": "localhost", "port": 8001}}`
   - Create client: `client = EmbeddingServiceAsyncClient(config_dict=config_dict)`
   - Assert client is created successfully (no exception)
   - Assert `hasattr(client, "_adapter_transport")`
   - Assert client does not require `auth_manager` parameter

### Step 7: Add test_client_uses_adapter_for_auth

1. Method signature: `def test_client_uses_adapter_for_auth(self):`
2. Method docstring: `"""Assert client uses adapter transport for authentication."""`
3. Method body:
   - Create config dict with auth: `config_dict = {"server": {"host": "localhost", "port": 8001}, "auth": {"method": "api_key", "api_keys": {"user": "key123"}}}`
   - Create client: `client = EmbeddingServiceAsyncClient(config_dict=config_dict)`
   - Assert `hasattr(client, "_adapter_transport")`
   - Assert `client._adapter_transport.adapter_params` contains auth-related params (token or token_header)
   - Assert adapter transport handles auth, not client directly

## Expected Deliverables

- Updated `tests/test_async_client.py` with:
  - New test class `TestEmbeddingServiceAsyncClientAdapter` (not skipped)
  - 6 new test methods verifying adapter-centric architecture
  - Existing skipped tests kept as-is
  - All new tests pass

## Mandatory Validation

**Validation commands** (run after implementation):

1. `black tests/test_async_client.py`
   - Expected: "reformatted" or "already well formatted"
   - Exit code: 0

2. `flake8 tests/test_async_client.py`
   - Expected: no output (exit 0)
   - Exit code: 0

3. `mypy tests/test_async_client.py`
   - Expected: "Success: no issues found" or type checking passes
   - Exit code: 0

4. `pytest tests/test_async_client.py::TestEmbeddingServiceAsyncClientAdapter -v`
   - Expected: all tests PASSED (only new class, not skipped)
   - Exit code: 0
   - All test methods must pass:
     - `test_client_init_uses_adapter_transport`
     - `test_client_init_uses_adapter_config_factory`
     - `test_client_no_legacy_transport`
     - `test_client_config_to_adapter_params`
     - `test_client_init_without_auth_manager`
     - `test_client_uses_adapter_for_auth`

## Decision Rules

- If client uses `_adapter_transport` attribute, use that in assertions
- If client uses different attribute name, adjust assertions
- If `AdapterConfigFactory` is not directly used in client init, verify through adapter transport
- If auth_manager is still required, adjust `test_client_init_without_auth_manager` accordingly
- If legacy transport attributes have different names, adjust `test_client_no_legacy_transport`

## Blackstops

- Stop if client does not use adapter transport (escalate)
- Stop if client still has legacy aiohttp session (escalate)
- Stop if tests fail due to missing imports (add imports)
- Stop if client requires auth_manager when it shouldn't (escalate)

## Handoff Package

**File to modify**: `tests/test_async_client.py`

**Changes summary**:
- Add new test class `TestEmbeddingServiceAsyncClientAdapter` (not skipped)
- Add 6 new test methods verifying adapter-centric architecture
- Keep existing skipped tests as-is
- Verify adapter transport usage, config conversion, no legacy transport

**Test count**: 
- Before: ~50 test methods (all skipped)
- After: ~50 skipped + 6 new active tests

**Dependencies**: None

**Completion condition**: All new tests pass, file follows project style rules, adapter-centric architecture verified
