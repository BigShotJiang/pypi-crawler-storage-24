Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Verify and Update Client Construction Paths

## Purpose

Verify that all client construction paths in `ClientFactory` and `EmbeddingServiceAsyncClient` use only adapter-backed transport and configuration. Ensure no custom auth execution, custom TLS execution, or custom HTTP/WebSocket transport remains in production paths. All security mode selection and protocol/auth/TLS configuration must be reduced to adapter-compatible settings passed to `AdapterConfigFactory` and `AdapterTransport`.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`

## Scope

**Included:**
- Verify `ClientFactory` methods use `AdapterConfigFactory` to convert config to adapter params
- Verify `ClientFactory` creates clients that use `AdapterTransport` (via `EmbeddingServiceAsyncClient`)
- Verify `EmbeddingServiceAsyncClient.__init__` uses `AdapterConfigFactory` and `AdapterTransport`
- Verify no direct HTTP/WebSocket client creation outside adapter
- Verify security mode detection only affects config structure, not execution
- Update docstrings to clarify adapter-only responsibility
- Remove any remaining references to custom auth/TLS execution

**Excluded:**
- Changes to `ClientAuthManager` (handled in separate task)
- Changes to `AdapterTransport` token generation (handled in separate task)
- Changes to test files (handled in separate task)
- Changes to adapter-facing modules (they're already correct)

## Boundaries

- Do not modify `AdapterTransport` or `AdapterConfigFactory` - they're already adapter-centric
- Do not modify `ClientAuthManager` or `ClientSSLManager` in this task
- Do not add new configuration formats - use existing adapter-compatible format

## Dependencies

None. This task can run in parallel with other tasks in this global step, but should complete after "Remove fake auth execution from ClientAuthManager" to ensure no fake auth methods are called.

## Parallelization Note

This task can run in parallel with:
- "Clean up AdapterTransport token generation"

But should coordinate with:
- "Remove fake auth execution from ClientAuthManager" (to ensure removed methods aren't called)

## Expected Outcome

1. All `ClientFactory` methods create clients using `AdapterConfigFactory` and `AdapterTransport`
2. `EmbeddingServiceAsyncClient` always uses `AdapterTransport` (no legacy transport)
3. Security mode detection only affects config structure, not execution
4. No custom auth or TLS execution code remains in construction paths
5. All docstrings clarify adapter-only responsibility
6. Public API remains compatible

## Correction Items

**File: `embed_client/client_factory.py`**
- Verify all `create_*` methods use `AdapterConfigFactory.from_config_dict` or similar
- Verify all methods create `EmbeddingServiceAsyncClient` which uses adapter transport
- Update docstrings to clarify adapter-only transport
- Remove any comments suggesting custom auth/TLS execution

**File: `embed_client/async_client.py`**
- Verify `__init__` uses `AdapterConfigFactory.from_config_dict` to get adapter params
- Verify `__init__` creates `AdapterTransport` with adapter params
- Verify no legacy transport creation code remains
- Update docstrings to clarify adapter-only transport
- Remove `auth_manager` parameter if it's only used for fake auth execution (coordinate with auth task)

## Questions/Escalation Rule

- If `auth_manager` parameter in `async_client.py` is used for config validation (not execution), keep it but document as config-only
- If security mode detection logic needs to change, escalate to orchestrator
- If any construction path requires custom transport, escalate to orchestrator immediately

## File Inventory

**Action: verify and modify**
- Path: `embed_client/client_factory.py`
- Purpose: Verify all factory methods use adapter-only construction

**Action: verify and modify**
- Path: `embed_client/async_client.py`
- Purpose: Verify client initialization uses adapter-only transport

**Action: read (for verification)**
- Path: `embed_client/adapter_config_factory.py`
- Purpose: Verify it's used correctly in construction paths

**Action: read (for verification)**
- Path: `embed_client/adapter_transport.py`
- Purpose: Verify it's used correctly in construction paths

## Class/Function Inventory

**Class: `ClientFactory`**
- Base class: None
- Purpose: Factory for creating EmbeddingServiceAsyncClient instances
- Methods to verify:
  - `detect_security_mode(...) -> str`: Verify it only returns mode string, doesn't execute auth/TLS
  - `create_client(...) -> EmbeddingServiceAsyncClient`: Verify uses AdapterConfigFactory and creates client with adapter transport
  - `_create_config_for_mode(...) -> Dict[str, Any]`: Verify creates config dict only, doesn't execute auth/TLS
  - `_create_auth_config(...) -> Dict[str, Any]`: Verify creates config dict only, doesn't execute auth
  - `_create_ssl_config(...) -> Dict[str, Any]`: Verify creates config dict only, doesn't execute TLS
  - `create_http_client(...) -> EmbeddingServiceAsyncClient`: Verify uses adapter transport
  - `create_http_token_client(...) -> EmbeddingServiceAsyncClient`: Verify uses adapter transport
  - `create_https_client(...) -> EmbeddingServiceAsyncClient`: Verify uses adapter transport
  - `create_https_token_client(...) -> EmbeddingServiceAsyncClient`: Verify uses adapter transport
  - `create_mtls_client(...) -> EmbeddingServiceAsyncClient`: Verify uses adapter transport
  - `create_mtls_roles_client(...) -> EmbeddingServiceAsyncClient`: Verify uses adapter transport
  - `from_config_file(...) -> EmbeddingServiceAsyncClient`: Verify uses adapter transport
  - `from_environment() -> EmbeddingServiceAsyncClient`: Verify uses adapter transport

**Class: `EmbeddingServiceAsyncClient`**
- Base class: Multiple mixins
- Purpose: Asynchronous client for Embedding Service API
- Methods to verify:
  - `__init__(...)`: Verify uses AdapterConfigFactory and AdapterTransport
  - Verify no legacy transport creation code
  - Verify auth_manager parameter usage (coordinate with auth task)

## Data Structures

**Config dict structure (used by AdapterConfigFactory):**
```python
{
    "server": {
        "base_url": str,  # or "host": str
        "port": int
    },
    "auth": {
        "method": str,  # "none", "api_key", "jwt", "basic", "certificate"
        "api_keys": Dict[str, str],  # for api_key method
        "jwt": {...},  # for jwt method
        "basic": {...},  # for basic method
        "certificate": {...}  # for certificate method
    },
    "ssl": {
        "enabled": bool,
        "cert_file": Optional[str],
        "key_file": Optional[str],
        "ca_cert_file": Optional[str],
        "check_hostname": bool
    },
    "client": {
        "timeout": float
    }
}
```

**Adapter params structure (output of AdapterConfigFactory):**
```python
{
    "protocol": str,  # "http", "https", "mtls"
    "host": str,
    "port": int,
    "token_header": Optional[str],
    "token": Optional[str],
    "cert": Optional[str],
    "key": Optional[str],
    "ca": Optional[str],
    "check_hostname": bool,
    "timeout": float,
    "_original_config": Optional[Dict[str, Any]]
}
```

## Import Map

**File: `embed_client/client_factory.py`**
```python
import os
from typing import Optional, Dict, Any
from urllib.parse import urlparse

from embed_client.async_client import EmbeddingServiceAsyncClient
from embed_client.config import ClientConfig
from embed_client.client_factory_helpers import (
    create_client,
    create_client_from_config,
    create_client_from_env,
    detect_security_mode,
)
```
Verify imports don't include custom transport or auth execution modules.

**File: `embed_client/async_client.py`**
```python
from typing import Any, Dict, Optional
import os

from embed_client.adapter_config_factory import AdapterConfigFactory
from embed_client.adapter_transport import AdapterTransport
from embed_client.auth import ClientAuthManager  # Review if needed
from embed_client.config import ClientConfig
from embed_client.constants import (
    DEFAULT_BASE_URL,
    DEFAULT_PORT,
    EMBEDDING_SERVICE_BASE_URL_ENV,
    EMBEDDING_SERVICE_PORT_ENV,
)
from embed_client.exceptions import (
    EmbeddingServiceError,
    EmbeddingServiceHTTPError,
    EmbeddingServiceConnectionError,
    EmbeddingServiceConfigError,
    EmbeddingServiceTimeoutError,
    EmbeddingServiceAPIError,
    EmbeddingServiceJSONError,
)
from embed_client.async_client_api_mixin import AsyncClientAPIMixin
from embed_client.async_client_config_mixin import AsyncClientConfigMixin
from embed_client.async_client_factory_mixin import AsyncClientFactoryMixin
from embed_client.async_client_introspection_mixin import AsyncClientIntrospectionMixin
from embed_client.async_client_lifecycle_mixin import AsyncClientLifecycleMixin
from embed_client.async_client_queue_mixin import AsyncClientQueueMixin
from embed_client.async_client_response_mixin import AsyncClientResponseMixin
```
Verify `ClientAuthManager` import is only used for config validation, not execution.

## Error Handling Map

**Method: `ClientFactory.create_client(...) -> EmbeddingServiceAsyncClient`**
- Exception: May raise `EmbeddingServiceConfigError` if config is invalid
- Conditions: Config validation fails
- Caller action: Handle config errors before client creation

**Method: `EmbeddingServiceAsyncClient.__init__(...)`**
- Exception: May raise `EmbeddingServiceConfigError` if base_url or port is invalid
- Conditions: Invalid configuration provided
- Caller action: Provide valid config or handle exceptions

## Config Dependency

**Config keys read by ClientFactory:**
- `base_url`: Server base URL
- `port`: Server port
- `auth_method`: Authentication method
- `ssl_enabled`: Whether SSL is enabled
- `cert_file`: Client certificate file path
- `key_file`: Client private key file path
- `ca_cert_file`: CA certificate file path
- `api_key`: API key value
- `jwt_secret`, `jwt_username`, `jwt_password`: JWT credentials
- `username`, `password`: Basic auth credentials
- `roles`, `role_attributes`: Role-based access control

**Where accessed:**
- `ClientFactory.detect_security_mode`: Reads parameters to determine security mode
- `ClientFactory._create_config_for_mode`: Creates config dict from parameters
- `ClientFactory._create_auth_config`: Creates auth config section
- `ClientFactory._create_ssl_config`: Creates SSL config section
- `AdapterConfigFactory.from_config_dict`: Converts config dict to adapter params

## Test Plan

**Test file: `tests/test_client_factory.py` (update existing)**
- Test class: `TestClientFactory`
- Test methods:
  - `test_create_client_uses_adapter_transport`: Assert created client uses AdapterTransport
  - `test_detect_security_mode_http`: Assert correct mode detection for HTTP
  - `test_detect_security_mode_https`: Assert correct mode detection for HTTPS
  - `test_detect_security_mode_mtls`: Assert correct mode detection for mTLS
  - `test_create_http_client`: Assert HTTP client uses adapter transport
  - `test_create_https_client`: Assert HTTPS client uses adapter transport
  - `test_create_mtls_client`: Assert mTLS client uses adapter transport
  - `test_factory_methods_no_custom_auth`: Assert no custom auth execution in factory methods
  - `test_factory_methods_no_custom_tls`: Assert no custom TLS execution in factory methods

**Test file: `tests/test_async_client.py` (update existing)**
- Test class: `TestEmbeddingServiceAsyncClient`
- Test methods:
  - `test_client_init_uses_adapter_transport`: Assert client uses AdapterTransport
  - `test_client_init_uses_adapter_config_factory`: Assert client uses AdapterConfigFactory
  - `test_client_no_legacy_transport`: Assert no legacy transport code exists
  - `test_client_config_to_adapter_params`: Assert config is converted to adapter params correctly

## Concrete Examples

**Input: Create HTTP client**
```python
client = ClientFactory.create_http_client("http://localhost", port=8001)
```

**Expected output:**
- `ClientFactory._create_config_for_mode` creates config dict with `auth.method="none"` and `ssl.enabled=False`
- `EmbeddingServiceAsyncClient.__init__` receives config dict
- `AdapterConfigFactory.from_config_dict` converts to adapter params: `{"protocol": "http", "host": "localhost", "port": 8001, ...}`
- `AdapterTransport` is created with adapter params
- Client uses `AdapterTransport` for all network operations

**Input: Create HTTPS client with API key**
```python
client = ClientFactory.create_https_token_client(
    "https://localhost",
    port=8001,
    auth_method="api_key",
    api_key="test-key"
)
```

**Expected output:**
- `ClientFactory._create_config_for_mode` creates config dict with `auth.method="api_key"`, `auth.api_keys={"user": "test-key"}`, `ssl.enabled=True`
- `AdapterConfigFactory.from_config_dict` converts to adapter params: `{"protocol": "https", "token": "test-key", "token_header": "X-API-Key", ...}`
- `AdapterTransport` is created with adapter params including token
- Client uses `AdapterTransport` with token for authentication

**Input: Create mTLS client**
```python
client = ClientFactory.create_mtls_client(
    "https://localhost",
    cert_file="/path/to/cert.pem",
    key_file="/path/to/key.pem",
    port=8001
)
```

**Expected output:**
- `ClientFactory._create_config_for_mode` creates config dict with `ssl.enabled=True`, `ssl.cert_file="/path/to/cert.pem"`, `ssl.key_file="/path/to/key.pem"`
- `AdapterConfigFactory.from_config_dict` converts to adapter params: `{"protocol": "mtls", "cert": "/path/to/cert.pem", "key": "/path/to/key.pem", ...}`
- `AdapterTransport` is created with adapter params including cert/key
- Client uses `AdapterTransport` with mTLS for authentication

## Algorithm/Logic Description

**Method: `ClientFactory.create_client(...) -> EmbeddingServiceAsyncClient`**
1. Call `detect_security_mode` to determine security mode string
2. Call `_create_config_for_mode` to create config dict from parameters
3. Create `EmbeddingServiceAsyncClient` with `config_dict=config_dict`
4. Return client instance
5. Note: No auth or TLS execution happens here - only config creation

**Method: `EmbeddingServiceAsyncClient.__init__(...)`**
1. Store config/config_dict in instance variables
2. If config_dict provided:
   - Call `AdapterConfigFactory.from_config_dict(config_dict)` to get adapter params
   - Create `AdapterTransport` with adapter params
   - Store transport in instance variable
3. If config provided:
   - Convert config to dict via `config.get_all()`
   - Call `AdapterConfigFactory.from_config_dict(config_dict)` to get adapter params
   - Create `AdapterTransport` with adapter params
   - Store transport in instance variable
4. If base_url/port provided directly:
   - Create minimal config dict
   - Call `AdapterConfigFactory.from_config_dict(config_dict)` to get adapter params
   - Create `AdapterTransport` with adapter params
   - Store transport in instance variable
5. Note: All transport creation goes through AdapterTransport - no legacy transport

**Method: `ClientFactory.detect_security_mode(...) -> str`**
1. Parse base_url to determine if HTTPS
2. Determine SSL status from ssl_enabled parameter or URL scheme
3. Check for client certificates (cert_file and key_file)
4. Check for authentication (auth_method not "none")
5. Return appropriate SecurityMode constant based on combination
6. Note: This only returns a string - no execution happens

## Forbidden Approaches

- Do NOT create custom HTTP/WebSocket clients outside adapter
- Do NOT execute authentication in factory methods - only create config
- Do NOT execute TLS operations in factory methods - only create config
- Do NOT use legacy transport code paths
- Do NOT bypass AdapterConfigFactory or AdapterTransport
- Do NOT add new configuration formats - use existing adapter-compatible format
