Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Remove Fake Auth Methods from ClientAuthManager

## Executor Role

**Executor**: `coder_auto`

**Execution directive**: Remove all fake authentication execution methods from `ClientAuthManager` class. Keep only configuration validation and helper methods. Keep `AuthResult` class for test compatibility.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- Tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/remove-fake-auth-execution.md`

## Step Scope

**Target file**: `embed_client/auth.py`

**Action**: modify

**Single target**: This step modifies only `embed_client/auth.py`. No other files are modified in this step.

## Dependency Contract

**Dependencies**: None. This step can run in parallel with other steps.

**Dependents**: 
- Step: "Update async_client.py to remove auth_manager execution dependency"
- Step: "Update __init__.py exports for ClientAuthManager"

## Required Context

This step removes fake authentication execution methods that return fake success results without performing actual authentication. All actual authentication is handled by `mcp-proxy-adapter` JsonRpcClient. The `ClientAuthManager` class must become a pure configuration validation facade.

## Read First

Before starting implementation, read these files:

1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - Overall architecture requirements
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md` - Global step context
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/remove-fake-auth-execution.md` - Tactical task details
4. `/home/vasilyvz/projects/embed-client/embed_client/auth.py` - Current implementation

## Expected File Change

**File**: `embed_client/auth.py`

**Changes**:
1. Remove method `authenticate_api_key(api_key: str, header_name: str = "X-API-Key") -> AuthResult` (lines 65-82)
2. Remove method `authenticate_jwt(token: str) -> AuthResult` (lines 84-98)
3. Remove method `authenticate_basic(username: str, password: str) -> AuthResult` (lines 100-117)
4. Remove method `authenticate_certificate(cert_file: str, key_file: str) -> AuthResult` (lines 119-134)
5. Remove method `create_jwt_token(user_id: str, roles: Optional[List[str]] = None, expiry_hours: Optional[int] = None) -> str` (lines 136-162)
6. Keep `AuthResult` class (lines 26-39) - used in tests, keep for compatibility
7. Keep all configuration validation methods: `validate_auth_config()`, `is_auth_enabled()`, `get_auth_method()`, `get_supported_methods()`
8. Keep `get_auth_headers(auth_method: str, **kwargs) -> Dict[str, str]` - used for header generation, not execution
9. Update class docstring to clarify it's config-only, no execution methods
10. Keep `create_auth_manager()` factory function
11. Keep `create_auth_headers()` standalone function

## Forbidden Alternatives

**Forbidden**:
- Do NOT keep fake authentication methods "for compatibility" - remove them completely
- Do NOT create new authentication execution logic - adapter handles all execution
- Do NOT remove `AuthResult` class - it's used in tests
- Do NOT remove configuration validation methods
- Do NOT remove `get_auth_headers()` - it's used for header generation
- Do NOT modify `AuthenticationError` class
- Do NOT modify `create_auth_manager()` or `create_auth_headers()` functions
- Do NOT modify any other files in this step

## Atomic Operations

1. Open file `embed_client/auth.py`
2. Locate method `authenticate_api_key` (starts at line 65)
3. Delete entire method definition including docstring (lines 65-82)
4. Locate method `authenticate_jwt` (starts at line 84)
5. Delete entire method definition including docstring (lines 84-98)
6. Locate method `authenticate_basic` (starts at line 100)
7. Delete entire method definition including docstring (lines 100-117)
8. Locate method `authenticate_certificate` (starts at line 119)
9. Delete entire method definition including docstring (lines 119-134)
10. Locate method `create_jwt_token` (starts at line 136)
11. Delete entire method definition including docstring (lines 136-162)
12. Update class docstring for `ClientAuthManager` (lines 42-49) to remove any mention of authentication execution and clarify it's config-only:
    - Change: "This class provides authentication configuration validation for the embed-client."
    - Add: "This class provides ONLY configuration validation. All actual authentication execution is handled by mcp_proxy_adapter JsonRpcClient."
    - Remove any mention of "authentication" in the context of execution
13. Verify `AuthResult` class remains (lines 26-39)
14. Verify all config validation methods remain: `validate_auth_config`, `is_auth_enabled`, `get_auth_method`, `get_supported_methods`, `get_auth_headers`
15. Verify `create_auth_manager()` and `create_auth_headers()` functions remain

## Expected Deliverables

**File**: `embed_client/auth.py`

**Final state**:
- `ClientAuthManager` class contains only:
  - `__init__(config: Dict[str, Any])` - constructor
  - `validate_auth_config() -> List[str]` - config validation
  - `is_auth_enabled() -> bool` - check if auth enabled
  - `get_auth_method() -> str` - get current auth method
  - `get_supported_methods() -> List[str]` - get supported methods
  - `get_auth_headers(auth_method: str, **kwargs) -> Dict[str, str]` - header generation
- `ClientAuthManager` class does NOT contain:
  - `authenticate_api_key()` - REMOVED
  - `authenticate_jwt()` - REMOVED
  - `authenticate_basic()` - REMOVED
  - `authenticate_certificate()` - REMOVED
  - `create_jwt_token()` - REMOVED
- `AuthResult` class remains (for test compatibility)
- `AuthenticationError` class remains
- `create_auth_manager()` function remains
- `create_auth_headers()` function remains
- Class docstring updated to clarify config-only usage

## Mandatory Validation

After implementation, run these exact commands and verify success:

1. **Format check**:
   ```bash
   black embed_client/auth.py
   ```
   **Expected**: "reformatted" or "already well formatted" (exit code 0)

2. **Lint check**:
   ```bash
   flake8 embed_client/auth.py
   ```
   **Expected**: No output (exit code 0)

3. **Type check**:
   ```bash
   mypy embed_client/auth.py
   ```
   **Expected**: "Success: no issues found" (exit code 0)

4. **Import verification**:
   ```bash
   python -c "from embed_client.auth import ClientAuthManager, AuthResult, create_auth_manager, create_auth_headers; print('Imports OK')"
   ```
   **Expected**: "Imports OK" (exit code 0)

5. **Method removal verification**:
   ```bash
   python -c "from embed_client.auth import ClientAuthManager; m = ClientAuthManager({}); assert not hasattr(m, 'authenticate_api_key'); assert not hasattr(m, 'authenticate_jwt'); assert not hasattr(m, 'authenticate_basic'); assert not hasattr(m, 'authenticate_certificate'); assert not hasattr(m, 'create_jwt_token'); print('Methods removed OK')"
   ```
   **Expected**: "Methods removed OK" (exit code 0)

6. **Config methods verification**:
   ```bash
   python -c "from embed_client.auth import ClientAuthManager; m = ClientAuthManager({'auth': {'method': 'api_key', 'api_keys': {'k': 'v'}}}); assert hasattr(m, 'validate_auth_config'); assert hasattr(m, 'is_auth_enabled'); assert hasattr(m, 'get_auth_method'); assert hasattr(m, 'get_supported_methods'); assert hasattr(m, 'get_auth_headers'); print('Config methods present OK')"
   ```
   **Expected**: "Config methods present OK" (exit code 0)

**All validation commands must pass before marking this step complete.**

## Decision Rules

1. **If `AuthResult` is imported elsewhere in production code**: Keep it but add comment that it's for test compatibility only
2. **If removing methods breaks imports**: This is expected - dependent steps will fix imports
3. **If class docstring mentions execution**: Update to clarify config-only usage
4. **If `get_auth_headers` is used for execution**: Escalate to orchestrator (should not happen per tactical task)

## Blackstops

**Stop immediately and escalate if**:
- `get_auth_headers()` is used in production code paths for actual authentication execution (not just header generation)
- Removing methods causes import errors in adapter-facing modules (should not happen)
- `AuthResult` is required by adapter transport layer (should not happen)

## Handoff Package

**For coder_auto**:

1. **Target file**: `embed_client/auth.py`
2. **Action**: Remove 5 methods, update 1 docstring
3. **Methods to remove**:
   - `authenticate_api_key(api_key: str, header_name: str = "X-API-Key") -> AuthResult`
   - `authenticate_jwt(token: str) -> AuthResult`
   - `authenticate_basic(username: str, password: str) -> AuthResult`
   - `authenticate_certificate(cert_file: str, key_file: str) -> AuthResult`
   - `create_jwt_token(user_id: str, roles: Optional[List[str]] = None, expiry_hours: Optional[int] = None) -> str`
4. **Methods to keep**:
   - `validate_auth_config() -> List[str]`
   - `is_auth_enabled() -> bool`
   - `get_auth_method() -> str`
   - `get_supported_methods() -> List[str]`
   - `get_auth_headers(auth_method: str, **kwargs) -> Dict[str, str]`
5. **Classes to keep**: `AuthResult`, `AuthenticationError`
6. **Functions to keep**: `create_auth_manager()`, `create_auth_headers()`
7. **Docstring update**: Clarify `ClientAuthManager` is config-only, no execution
8. **Validation**: Run all 6 validation commands, all must pass

## File Header

**Exact module docstring** (keep existing, already correct):
```python
"""
Authentication system for embed-client.

This module provides authentication configuration validation for the embed-client.
All actual authentication is handled by mcp_proxy_adapter JsonRpcClient,
which uses mcp_security_framework internally.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
```

## Complete Import List

**Exact imports** (keep existing):
```python
import base64
import logging
from typing import Any, Dict, List, Optional
```

## Class Skeleton

**Class: `AuthenticationError`**
- Base class: `Exception`
- `__init__(self, message: str, error_code: int = 401) -> None`
- Attributes: `self.message: str`, `self.error_code: int`
- Status: KEEP - no changes

**Class: `AuthResult`**
- Base class: None
- `__init__(self, success: bool, user_id: Optional[str] = None, roles: Optional[List[str]] = None, error: Optional[str] = None) -> None`
- Attributes: `self.success: bool`, `self.user_id: Optional[str]`, `self.roles: List[str]`, `self.error: Optional[str]`
- Status: KEEP - for test compatibility

**Class: `ClientAuthManager`**
- Base class: None
- `__init__(self, config: Dict[str, Any]) -> None`
- Attributes: `self.config: Dict[str, Any]`, `self.logger: logging.Logger`
- Methods to KEEP:
  - `validate_auth_config(self) -> List[str]`
  - `is_auth_enabled(self) -> bool`
  - `get_auth_method(self) -> str`
  - `get_supported_methods(self) -> List[str]`
  - `get_auth_headers(self, auth_method: str, **kwargs) -> Dict[str, str]`
- Methods to REMOVE:
  - `authenticate_api_key(self, api_key: str, header_name: str = "X-API-Key") -> AuthResult` - DELETE
  - `authenticate_jwt(self, token: str) -> AuthResult` - DELETE
  - `authenticate_basic(self, username: str, password: str) -> AuthResult` - DELETE
  - `authenticate_certificate(self, cert_file: str, key_file: str) -> AuthResult` - DELETE
  - `create_jwt_token(self, user_id: str, roles: Optional[List[str]] = None, expiry_hours: Optional[int] = None) -> str` - DELETE

**Function: `create_auth_manager(config: Dict[str, Any]) -> ClientAuthManager`**
- Status: KEEP - no changes

**Function: `create_auth_headers(auth_method: str, **kwargs) -> Dict[str, str]`**
- Status: KEEP - no changes

## Method Logic - Step-by-Step Algorithm

**Method: `validate_auth_config(self) -> List[str]`** (KEEP - no changes)
1. Initialize empty list `errors = []`
2. Read `auth_config = self.config.get("auth", {})`
3. Read `auth_method = auth_config.get("method", "none")`
4. If `auth_method == "api_key"`:
   - Read `api_keys = auth_config.get("api_keys", {})`
   - If `not api_keys`: append `"API keys not configured for api_key authentication"` to `errors`
5. If `auth_method == "jwt"`:
   - Read `jwt_config = auth_config.get("jwt", {})`
   - If `not jwt_config.get("secret")`: append `"JWT secret not configured"` to `errors`
   - If `not jwt_config.get("username")`: append `"JWT username not configured"` to `errors`
   - If `not jwt_config.get("password")`: append `"JWT password not configured"` to `errors`
6. If `auth_method == "certificate"`:
   - Read `cert_config = auth_config.get("certificate", {})`
   - If `not cert_config.get("cert_file")`: append `"Certificate file not configured"` to `errors`
   - If `not cert_config.get("key_file")`: append `"Key file not configured"` to `errors`
7. If `auth_method == "basic"`:
   - Read `basic_config = auth_config.get("basic", {})`
   - If `not basic_config.get("username")`: append `"Basic auth username not configured"` to `errors`
   - If `not basic_config.get("password")`: append `"Basic auth password not configured"` to `errors`
8. Return `errors`

**Method: `is_auth_enabled(self) -> bool`** (KEEP - no changes)
1. Read `auth_config = self.config.get("auth", {})`
2. Read `auth_method = auth_config.get("method", "none")`
3. Return `auth_method != "none"`

**Method: `get_auth_method(self) -> str`** (KEEP - no changes)
1. Read `auth_config = self.config.get("auth", {})`
2. Return `auth_config.get("method", "none")`

**Method: `get_supported_methods(self) -> List[str]`** (KEEP - no changes)
1. Return `["api_key", "jwt", "certificate", "basic"]`

**Method: `get_auth_headers(self, auth_method: str, **kwargs) -> Dict[str, str]`** (KEEP - no changes)
1. Initialize empty dict `headers = {}`
2. If `auth_method == "api_key"`:
   - Read `api_key = kwargs.get("api_key")`
   - Read `header_name = kwargs.get("header", "X-API-Key")`
   - If `api_key`: set `headers[header_name] = api_key`
3. If `auth_method == "jwt"`:
   - Read `token = kwargs.get("token")`
   - If `token`: set `headers["Authorization"] = f"Bearer {token}"`
4. If `auth_method == "basic"`:
   - Read `username = kwargs.get("username")`
   - Read `password = kwargs.get("password")`
   - If `username and password`:
     - Encode `f"{username}:{password}"` to bytes, then base64 encode, then decode to string → `credentials`
     - Set `headers["Authorization"] = f"Basic {credentials}"`
5. If `auth_method == "certificate"`:
   - Do nothing (certificate auth handled at SSL level)
6. Return `headers`

## Error Handling per Method

**Method: `validate_auth_config()`**
- Exceptions to raise: None (returns list of error strings)
- Exceptions to catch: None
- Return: `List[str]` - empty list if valid, list of error messages if invalid

**Method: `is_auth_enabled()`**
- Exceptions to raise: None
- Exceptions to catch: None
- Return: `bool` - True if auth enabled, False if disabled

**Method: `get_auth_method()`**
- Exceptions to raise: None
- Exceptions to catch: None
- Return: `str` - auth method name or "none"

**Method: `get_supported_methods()`**
- Exceptions to raise: None
- Exceptions to catch: None
- Return: `List[str]` - list of supported method names

**Method: `get_auth_headers()`**
- Exceptions to raise: None
- Exceptions to catch: None
- Return: `Dict[str, str]` - headers dict, may be empty

## Return Value Specification

**Method: `validate_auth_config() -> List[str]`**
- Returns: List of error message strings
- Empty list `[]` means config is valid
- Non-empty list means config has validation errors

**Method: `is_auth_enabled() -> bool`**
- Returns: `True` if `auth.method != "none"`, `False` otherwise

**Method: `get_auth_method() -> str`**
- Returns: String value of `auth.method` from config, or `"none"` if not set

**Method: `get_supported_methods() -> List[str]`**
- Returns: `["api_key", "jwt", "certificate", "basic"]`

**Method: `get_auth_headers(auth_method: str, **kwargs) -> Dict[str, str]`**
- Returns: Dictionary with header names as keys and header values as strings
- May return empty dict `{}` if auth_method is "certificate" or if required kwargs are missing

## Edge Cases

**Method: `validate_auth_config()`**
- Empty config `{}` → returns `[]` (no errors, auth disabled)
- Config without `auth` key → returns `[]` (no errors, auth disabled)
- Config with `auth.method = "none"` → returns `[]` (no errors, auth disabled)
- Config with `auth.method = "api_key"` but empty `api_keys` → returns `["API keys not configured for api_key authentication"]`
- Config with `auth.method = "jwt"` but missing fields → returns list with specific error for each missing field
- Config with `auth.method = "invalid"` → returns `[]` (method not validated, only structure)

**Method: `is_auth_enabled()`**
- Config without `auth` key → returns `False`
- Config with `auth.method = "none"` → returns `False`
- Config with `auth.method = "api_key"` → returns `True`
- Config with `auth.method = ""` → returns `True` (empty string != "none")

**Method: `get_auth_method()`**
- Config without `auth` key → returns `"none"`
- Config with `auth.method = "api_key"` → returns `"api_key"`
- Config with `auth.method = None` → returns `"none"`

**Method: `get_supported_methods()`**
- Always returns `["api_key", "jwt", "certificate", "basic"]` regardless of config

**Method: `get_auth_headers()`**
- `auth_method = "api_key"` without `api_key` in kwargs → returns `{}`
- `auth_method = "jwt"` without `token` in kwargs → returns `{}`
- `auth_method = "basic"` without `username` or `password` in kwargs → returns `{}`
- `auth_method = "certificate"` → always returns `{}` (handled at SSL level)
- `auth_method = "invalid"` → returns `{}`

## Constants and Literals

**String literals**:
- `"auth"` - config key for auth section
- `"method"` - config key for auth method
- `"none"` - value for disabled auth
- `"api_key"` - auth method name
- `"jwt"` - auth method name
- `"certificate"` - auth method name
- `"basic"` - auth method name
- `"api_keys"` - config key for API keys dict
- `"X-API-Key"` - default header name for API key
- `"Authorization"` - header name for JWT and basic auth
- `"Bearer "` - prefix for JWT token in Authorization header
- `"Basic "` - prefix for basic auth in Authorization header
- Error messages (exact strings from algorithm above)

**No numeric constants** used in this step.

## Completion Condition

**All tests must pass** after this step. However, tests that call removed methods will fail - this is expected and will be fixed in a separate test update task per tactical task scope.
