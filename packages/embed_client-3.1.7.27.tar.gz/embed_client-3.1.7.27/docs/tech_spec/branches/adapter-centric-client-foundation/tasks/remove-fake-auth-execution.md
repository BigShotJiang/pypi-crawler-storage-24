Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Remove Fake Auth Execution from ClientAuthManager

## Purpose

Convert `ClientAuthManager` from a fake authentication executor to a pure configuration validation facade. The class currently contains methods (`authenticate_api_key`, `authenticate_jwt`, `authenticate_basic`, `authenticate_certificate`, `create_jwt_token`) that claim to perform authentication but only return fake success results. These methods must be removed or converted to configuration-only helpers, since all actual authentication is handled by `mcp-proxy-adapter` JsonRpcClient.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`

## Scope

**Included:**
- Remove or deprecate fake authentication execution methods from `ClientAuthManager`
- Keep configuration validation methods (`validate_auth_config`, `is_auth_enabled`, `get_auth_method`, `get_supported_methods`)
- Keep `get_auth_headers` if it's used for header generation (not execution)
- Update all imports and usages of removed methods
- Update `async_client.py` to remove dependency on `ClientAuthManager` for execution (keep only for config validation if needed)
- Update `__init__.py` exports if needed

**Excluded:**
- Changes to adapter transport layer (handled in separate task)
- Changes to client factory (handled in separate task)
- Changes to test files (handled in separate task)

## Boundaries

- Do not modify `AdapterTransport` or `AdapterConfigFactory` in this task
- Do not modify `ClientSSLManager` (it's already config-only)
- Do not modify adapter-facing modules (`adapter_transport.py`, `adapter_config_factory.py`, etc.)

## Dependencies

None. This task can run in parallel with other tasks in this global step.

## Parallelization Note

This task can run in parallel with:
- "Clean up AdapterTransport token generation"
- "Verify and update client construction paths"

## Expected Outcome

1. `ClientAuthManager` contains only configuration validation and helper methods
2. No fake authentication execution methods remain
3. All code that called fake auth methods is updated to use adapter-backed behavior
4. `async_client.py` no longer depends on `ClientAuthManager` for authentication execution
5. Public API remains compatible (validation methods still available)

## Correction Items

**File: `embed_client/auth.py`**
- Remove methods: `authenticate_api_key`, `authenticate_jwt`, `authenticate_basic`, `authenticate_certificate`, `create_jwt_token`
- Keep methods: `validate_auth_config`, `is_auth_enabled`, `get_auth_method`, `get_supported_methods`
- Review `get_auth_headers`: if used only for header generation (not execution), keep it; otherwise remove or simplify

**File: `embed_client/async_client.py`**
- Remove `auth_manager: Optional[ClientAuthManager]` parameter from `__init__` if it's not used for execution
- If `auth_manager` is only used for config validation, keep it but document that it's config-only
- Remove any calls to fake authentication methods

**File: `embed_client/__init__.py`**
- Keep `ClientAuthManager` export if it's still used for config validation
- Update docstring if needed to clarify it's config-only

## Questions/Escalation Rule

- If `get_auth_headers` is used in production paths for actual request header generation (not just config), escalate to orchestrator to determine if adapter should handle this
- If removing `auth_manager` parameter from `async_client.py` breaks public API compatibility, escalate to orchestrator

## File Inventory

**Action: modify**
- Path: `embed_client/auth.py`
- Purpose: Remove fake authentication execution methods, keep only config validation

**Action: modify**
- Path: `embed_client/async_client.py`
- Purpose: Remove dependency on ClientAuthManager for authentication execution

**Action: modify**
- Path: `embed_client/__init__.py`
- Purpose: Update exports and docstrings if needed

## Class/Function Inventory

**Class: `ClientAuthManager`**
- Base class: None
- Purpose: Configuration validation facade for authentication settings
- Public methods to keep:
  - `validate_auth_config() -> List[str]`: Validate auth config structure, return list of errors
  - `is_auth_enabled() -> bool`: Check if authentication is enabled in config
  - `get_auth_method() -> str`: Get current authentication method from config
  - `get_supported_methods() -> List[str]`: Get list of supported auth methods
  - `get_auth_headers(auth_method: str, **kwargs) -> Dict[str, str]`: Generate auth headers for requests (keep only if used for header generation, not execution)
- Public methods to remove:
  - `authenticate_api_key(api_key: str, header_name: str = "X-API-Key") -> AuthResult`: REMOVE - fake execution
  - `authenticate_jwt(token: str) -> AuthResult`: REMOVE - fake execution
  - `authenticate_basic(username: str, password: str) -> AuthResult`: REMOVE - fake execution
  - `authenticate_certificate(cert_file: str, key_file: str) -> AuthResult`: REMOVE - fake execution
  - `create_jwt_token(user_id: str, roles: Optional[List[str]] = None, expiry_hours: Optional[int] = None) -> str`: REMOVE - raises error, not needed

**Class: `AuthResult`**
- Base class: None
- Purpose: Container for authentication results
- Status: REMOVE if no longer used after removing fake auth methods, or keep if used elsewhere

**Class: `AuthenticationError`**
- Base class: Exception
- Purpose: Exception for authentication failures
- Status: KEEP - may be used for config validation errors

**Function: `create_auth_manager(config: Dict[str, Any]) -> ClientAuthManager`**
- Purpose: Factory function to create ClientAuthManager
- Status: KEEP - still needed for config validation

**Function: `create_auth_headers(auth_method: str, **kwargs) -> Dict[str, str]`**
- Purpose: Create authentication headers
- Status: REVIEW - keep only if used for header generation, remove if used for execution

## Data Structures

**Class: `AuthResult`**
- Fields:
  - `success: bool` - Authentication success status
  - `user_id: Optional[str]` - User identifier
  - `roles: Optional[List[str]]` - User roles
  - `error: Optional[str]` - Error message
- Status: REMOVE if unused after removing fake auth methods

## Import Map

**File: `embed_client/auth.py`**
```python
import logging
from typing import Any, Dict, List, Optional
```

**File: `embed_client/async_client.py`**
- Remove: `from embed_client.auth import ClientAuthManager` (if auth_manager parameter is removed)
- Or keep: `from embed_client.auth import ClientAuthManager` (if still used for config validation only)

**File: `embed_client/__init__.py`**
- Keep: `from embed_client.auth import ClientAuthManager` (if still exported)
- Update docstring to clarify config-only usage

## Error Handling Map

**Method: `validate_auth_config() -> List[str]`**
- Exception: None (returns list of error strings)
- Conditions: Validates config structure, returns empty list if valid
- Caller action: Check returned list, raise `EmbeddingServiceConfigError` if errors found

**Method: `get_auth_headers(auth_method: str, **kwargs) -> Dict[str, str]`**
- Exception: None
- Conditions: Returns empty dict if auth_method is "none" or invalid
- Caller action: Use returned headers if needed (but adapter should handle this)

## Config Dependency

**Config keys read:**
- `auth.method`: Authentication method (none, api_key, jwt, basic, certificate)
- `auth.api_keys`: API keys dictionary (for api_key method)
- `auth.jwt.secret`: JWT secret (for jwt method)
- `auth.jwt.username`: JWT username (for jwt method)
- `auth.jwt.password`: JWT password (for jwt method)
- `auth.basic.username`: Basic auth username (for basic method)
- `auth.basic.password`: Basic auth password (for basic method)
- `auth.certificate.cert_file`: Certificate file path (for certificate method)
- `auth.certificate.key_file`: Key file path (for certificate method)

**Where accessed:**
- `ClientAuthManager.__init__`: Stores config in `self.config`
- `ClientAuthManager.validate_auth_config`: Reads config to validate structure
- `ClientAuthManager.is_auth_enabled`: Reads `auth.method`
- `ClientAuthManager.get_auth_method`: Reads `auth.method`

## Test Plan

**Test file: `tests/test_auth_manager.py` (create if missing, or update existing)**
- Test class: `TestClientAuthManager`
- Test methods:
  - `test_validate_auth_config_valid`: Assert valid config returns empty error list
  - `test_validate_auth_config_invalid`: Assert invalid config returns error list
  - `test_is_auth_enabled`: Assert correct detection of enabled/disabled auth
  - `test_get_auth_method`: Assert correct method retrieval
  - `test_get_supported_methods`: Assert returns correct method list
  - `test_get_auth_headers_api_key`: Assert correct header generation for api_key
  - `test_get_auth_headers_jwt`: Assert correct header generation for jwt
  - `test_get_auth_headers_basic`: Assert correct header generation for basic
  - `test_fake_auth_methods_removed`: Assert removed methods no longer exist

**Test file: `tests/test_async_client.py` (update existing)**
- Test class: `TestEmbeddingServiceAsyncClient`
- Test methods:
  - `test_client_init_without_auth_manager`: Assert client can be created without auth_manager
  - `test_client_uses_adapter_for_auth`: Assert client uses adapter transport for authentication

## Concrete Examples

**Input: Config with api_key auth**
```python
config = {
    "auth": {
        "method": "api_key",
        "api_keys": {"user": "test-key"},
        "api_key_header": "X-API-Key"
    }
}
auth_manager = ClientAuthManager(config)
```

**Expected output:**
- `auth_manager.validate_auth_config()` returns `[]` (no errors)
- `auth_manager.is_auth_enabled()` returns `True`
- `auth_manager.get_auth_method()` returns `"api_key"`
- `auth_manager.get_auth_headers("api_key", api_key="test-key")` returns `{"X-API-Key": "test-key"}`
- `auth_manager.authenticate_api_key("test-key")` does NOT exist (method removed)

**Input: Config with jwt auth**
```python
config = {
    "auth": {
        "method": "jwt",
        "jwt": {
            "secret": "secret",
            "username": "user",
            "password": "pass"
        }
    }
}
auth_manager = ClientAuthManager(config)
```

**Expected output:**
- `auth_manager.validate_auth_config()` returns `[]` if all fields present, or error list if missing
- `auth_manager.get_auth_method()` returns `"jwt"`
- `auth_manager.create_jwt_token(...)` does NOT exist (method removed)

## Algorithm/Logic Description

**Method: `validate_auth_config() -> List[str]`**
1. Read `auth.method` from config
2. If method is "api_key":
   - Check `auth.api_keys` exists and is non-empty
   - If missing or empty, append error "API keys not configured for api_key authentication"
3. If method is "jwt":
   - Check `auth.jwt.secret` exists
   - Check `auth.jwt.username` exists
   - Check `auth.jwt.password` exists
   - Append errors for missing fields
4. If method is "basic":
   - Check `auth.basic.username` exists
   - Check `auth.basic.password` exists
   - Append errors for missing fields
5. If method is "certificate":
   - Check `auth.certificate.cert_file` exists
   - Check `auth.certificate.key_file` exists
   - Append errors for missing fields
6. Return list of error strings

**Method: `get_auth_headers(auth_method: str, **kwargs) -> Dict[str, str]`**
1. Initialize empty headers dict
2. If auth_method is "api_key":
   - Read `api_key` from kwargs
   - Read `header` from kwargs (default "X-API-Key")
   - If api_key present, set `headers[header] = api_key`
3. If auth_method is "jwt":
   - Read `token` from kwargs
   - If token present, set `headers["Authorization"] = f"Bearer {token}"`
4. If auth_method is "basic":
   - Read `username` and `password` from kwargs
   - If both present, base64 encode "username:password" and set `headers["Authorization"] = f"Basic {encoded}"`
5. If auth_method is "certificate":
   - Do nothing (certificate auth handled at SSL level)
6. Return headers dict

## Forbidden Approaches

- Do NOT keep fake authentication methods "for compatibility" - remove them completely
- Do NOT create new authentication execution logic - adapter handles all execution
- Do NOT use `ClientAuthManager` for actual authentication in production code paths
- Do NOT modify adapter-facing modules in this task
- Do NOT remove configuration validation methods - they are still needed
