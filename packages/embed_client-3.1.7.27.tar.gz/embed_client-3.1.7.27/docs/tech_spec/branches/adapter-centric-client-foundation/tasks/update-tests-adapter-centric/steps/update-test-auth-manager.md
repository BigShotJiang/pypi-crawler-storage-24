Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Update Tests for ClientAuthManager

## Executor Role

**Executor**: `coder_auto`

## Execution Directive

Update `tests/test_auth_manager.py` to remove tests for fake authentication execution methods and add tests verifying that removed methods no longer exist. Keep all config validation tests.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- Tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric.md`

## Step Scope

**Target file**: `tests/test_auth_manager.py`  
**Action**: modify

## Dependency Contract

**Depends on**: None (can run in parallel with other test update steps)  
**Required by**: None

## Required Context

- `ClientAuthManager` no longer has fake authentication execution methods: `authenticate_api_key`, `authenticate_jwt`, `authenticate_basic`, `authenticate_certificate`, `create_jwt_token`
- `ClientAuthManager` still has config validation methods: `validate_auth_config`, `is_auth_enabled`, `get_auth_method`, `get_supported_methods`, `get_auth_headers`
- The file currently has `pytestmark = pytest.mark.skip` which must be removed
- The file currently tests fake authentication execution which must be removed

## Read First

- `/home/vasilyvz/projects/embed-client/tests/test_auth_manager.py` (current state)
- `/home/vasilyvz/projects/embed-client/embed_client/auth.py` (to understand current ClientAuthManager interface)

## Expected File Change

1. Remove `pytestmark = pytest.mark.skip` decorator and its comment block
2. Remove all test methods for fake authentication execution:
   - `test_authenticate_api_key_success`
   - `test_authenticate_api_key_failure`
   - `test_authenticate_api_key_empty_config`
   - `test_authenticate_basic_success`
   - `test_authenticate_basic_failure`
   - `test_authenticate_basic_wrong_username`
   - `test_authenticate_certificate_success`
   - `test_authenticate_certificate_file_not_found`
   - `test_create_jwt_token_fallback`
   - `test_create_jwt_token_no_secret`
3. Keep all config validation test methods:
   - `test_validate_auth_config_valid_api_key`
   - `test_validate_auth_config_invalid_api_key`
   - `test_validate_auth_config_valid_basic`
   - `test_validate_auth_config_invalid_basic`
   - `test_validate_auth_config_valid_certificate`
   - `test_validate_auth_config_invalid_certificate`
   - `test_is_auth_enabled_true`
   - `test_is_auth_enabled_false`
   - `test_get_auth_method`
   - `test_get_supported_methods`
   - `test_get_auth_headers_api_key`
   - `test_get_auth_headers_api_key_custom_header`
   - `test_get_auth_headers_jwt`
   - `test_get_auth_headers_basic`
   - `test_get_auth_headers_certificate`
4. Keep initialization tests:
   - `test_init_with_security_framework`
   - `test_init_without_security_framework`
5. Add new test method: `test_fake_auth_methods_removed`

## Forbidden Alternatives

- Do NOT keep tests for fake authentication execution methods
- Do NOT remove config validation tests
- Do NOT remove header generation tests (`get_auth_headers_*`)
- Do NOT add tests that verify authentication execution (adapter handles that)
- Do NOT skip the test file (remove pytestmark)

## Atomic Operations

### Step 1: Remove skip decorator

1. Locate the `pytestmark = pytest.mark.skip(...)` block at the top of the file (lines 16-31)
2. Remove the entire block including the comment above it (lines 16-31)
3. Keep only the module docstring and imports

### Step 2: Remove fake authentication execution tests

1. Remove method `test_authenticate_api_key_success` (lines 49-62)
2. Remove method `test_authenticate_api_key_failure` (lines 64-72)
3. Remove method `test_authenticate_api_key_empty_config` (lines 74-81)
4. Remove method `test_authenticate_basic_success` (lines 83-96)
5. Remove method `test_authenticate_basic_failure` (lines 98-111)
6. Remove method `test_authenticate_basic_wrong_username` (lines 113-125)
7. Remove method `test_authenticate_certificate_success` (lines 127-155)
8. Remove method `test_authenticate_certificate_file_not_found` (lines 157-174)
9. Remove method `test_create_jwt_token_fallback` (lines 328-344)
10. Remove method `test_create_jwt_token_no_secret` (lines 346-352)

### Step 3: Add test for removed methods

1. Add new test method `test_fake_auth_methods_removed` after `test_get_supported_methods`
2. Method signature: `def test_fake_auth_methods_removed(self):`
3. Method docstring: `"""Assert that fake authentication methods no longer exist."""`
4. Method body:
   - Create config dict: `config = {"auth": {"method": "api_key", "api_keys": {"user": "key"}}}`
   - Create `ClientAuthManager` instance: `auth_manager = ClientAuthManager(config)`
   - Assert `authenticate_api_key` does not exist: `assert not hasattr(auth_manager, "authenticate_api_key")`
   - Assert `authenticate_jwt` does not exist: `assert not hasattr(auth_manager, "authenticate_jwt")`
   - Assert `authenticate_basic` does not exist: `assert not hasattr(auth_manager, "authenticate_basic")`
   - Assert `authenticate_certificate` does not exist: `assert not hasattr(auth_manager, "authenticate_certificate")`
   - Assert `create_jwt_token` does not exist: `assert not hasattr(auth_manager, "create_jwt_token")`

## Expected Deliverables

- Updated `tests/test_auth_manager.py` with:
  - No `pytestmark.skip` decorator
  - All fake authentication execution tests removed
  - All config validation tests kept
  - New test `test_fake_auth_methods_removed` added
  - All tests pass

## Mandatory Validation

**Validation commands** (run after implementation):

1. `black tests/test_auth_manager.py`
   - Expected: "reformatted" or "already well formatted"
   - Exit code: 0

2. `flake8 tests/test_auth_manager.py`
   - Expected: no output (exit 0)
   - Exit code: 0

3. `mypy tests/test_auth_manager.py`
   - Expected: "Success: no issues found" or type checking passes
   - Exit code: 0

4. `pytest tests/test_auth_manager.py -v`
   - Expected: all tests PASSED
   - Exit code: 0
   - All test methods must pass:
     - `test_init_with_security_framework`
     - `test_init_without_security_framework`
     - `test_get_auth_headers_api_key`
     - `test_get_auth_headers_api_key_custom_header`
     - `test_get_auth_headers_jwt`
     - `test_get_auth_headers_basic`
     - `test_get_auth_headers_certificate`
     - `test_validate_auth_config_valid_api_key`
     - `test_validate_auth_config_invalid_api_key`
     - `test_validate_auth_config_valid_basic`
     - `test_validate_auth_config_invalid_basic`
     - `test_validate_auth_config_valid_certificate`
     - `test_validate_auth_config_invalid_certificate`
     - `test_is_auth_enabled_true`
     - `test_is_auth_enabled_false`
     - `test_get_auth_method`
     - `test_get_supported_methods`
     - `test_fake_auth_methods_removed` (new)

## Decision Rules

- If `ClientAuthManager` still has any of the removed methods, escalate to orchestrator_tactical
- If config validation tests fail, check that `ClientAuthManager.validate_auth_config()` still exists
- If `hasattr()` checks fail, verify that methods are actually removed from `ClientAuthManager`

## Blackstops

- Stop if `ClientAuthManager` still implements fake authentication execution methods (escalate)
- Stop if config validation methods are missing from `ClientAuthManager` (escalate)
- Stop if tests fail after removal (investigate and fix)

## Handoff Package

**File to modify**: `tests/test_auth_manager.py`

**Changes summary**:
- Remove `pytestmark.skip` decorator
- Remove 10 test methods for fake authentication execution
- Keep 15 test methods for config validation and header generation
- Add 1 new test method `test_fake_auth_methods_removed`

**Test count**: 
- Before: ~25 test methods (10 fake auth + 15 config)
- After: 16 test methods (15 config + 1 new)

**Dependencies**: None

**Completion condition**: All tests pass, no skipped tests, file follows project style rules
