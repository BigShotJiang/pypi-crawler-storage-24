Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Tactical Task: Update Tests for Adapter-Centric Architecture

## Purpose

Update all existing tests to reflect the adapter-centric architecture where all authentication, transport, TLS, and protocol behavior is handled by `mcp-proxy-adapter` client facilities. Remove tests that verify fake authentication execution, add tests that verify adapter-only behavior, and ensure all security mode tests use adapter-backed transport.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`

## Scope

**Included:**
- Update tests for `ClientAuthManager` to remove tests for fake authentication methods
- Add tests verifying adapter-only transport usage
- Update tests for `ClientFactory` to verify adapter transport usage
- Update tests for `EmbeddingServiceAsyncClient` to verify adapter transport usage
- Update tests for `AdapterTransport` to verify no token generation
- Update security mode matrix tests to use adapter-backed clients
- Remove or update tests that verify custom auth/TLS execution
- Add tests verifying config validation only (not execution) for auth/SSL managers

**Excluded:**
- Changes to production code (handled in other tasks)
- Changes to adapter-facing modules (they're already correct)
- Integration tests that test adapter behavior itself (those should remain)

## Boundaries

- Do not modify production code in this task
- Do not modify adapter-facing modules
- Do not remove integration tests that verify adapter integration works correctly

## Dependencies

This task should complete after:
- "Remove fake auth execution from ClientAuthManager"
- "Clean up AdapterTransport token generation"
- "Verify and update client construction paths"

This ensures tests are updated to match the new code structure.

## Parallelization Note

This task cannot run in parallel with other tasks - it depends on code changes from other tasks.

## Expected Outcome

1. All tests verify adapter-only behavior
2. No tests verify fake authentication execution
3. Security mode tests use adapter-backed clients
4. Config validation tests remain (for ClientAuthManager and ClientSSLManager)
5. Integration tests verify adapter integration works correctly
6. All tests pass with adapter-centric architecture

## Correction Items

**File: `tests/test_auth_manager.py` (create or update)**
- Remove tests for: `authenticate_api_key`, `authenticate_jwt`, `authenticate_basic`, `authenticate_certificate`, `create_jwt_token`
- Keep tests for: `validate_auth_config`, `is_auth_enabled`, `get_auth_method`, `get_supported_methods`
- Add test: `test_fake_auth_methods_removed` to verify methods don't exist

**File: `tests/test_adapter_transport.py` (update existing)**
- Remove tests for: `_generate_token_from_config` (if any)
- Add tests for: token passed directly from adapter_params, no token generation

**File: `tests/test_client_factory.py` (update existing)**
- Add tests verifying all factory methods create clients with adapter transport
- Add tests verifying no custom auth/TLS execution in factory methods
- Update security mode tests to verify adapter transport usage

**File: `tests/test_async_client.py` (update existing)**
- Add tests verifying client uses AdapterTransport
- Add tests verifying client uses AdapterConfigFactory
- Remove tests verifying legacy transport (if any)
- Update initialization tests to verify adapter-only construction

**File: `tests/test_adapter_phase1.py`, `tests/test_adapter_phase2.py`, `tests/test_adapter_integration.py` (update existing)**
- Verify these tests still pass with adapter-centric architecture
- Update if they test fake auth methods or custom transport

## Questions/Escalation Rule

- If integration tests fail due to adapter behavior changes, escalate to orchestrator
- If test coverage drops significantly after removing fake auth tests, escalate to orchestrator
- If security mode matrix tests require mock adapter behavior, escalate to orchestrator

## File Inventory

**Action: create or modify**
- Path: `tests/test_auth_manager.py`
- Purpose: Update tests for config-only ClientAuthManager

**Action: modify**
- Path: `tests/test_adapter_transport.py`
- Purpose: Update tests for simplified AdapterTransport

**Action: modify**
- Path: `tests/test_client_factory.py`
- Purpose: Add tests verifying adapter-only construction

**Action: modify**
- Path: `tests/test_async_client.py`
- Purpose: Add tests verifying adapter-only transport

**Action: modify**
- Path: `tests/test_adapter_phase1.py`
- Purpose: Update if needed for adapter-centric architecture

**Action: modify**
- Path: `tests/test_adapter_phase2.py`
- Purpose: Update if needed for adapter-centric architecture

**Action: modify**
- Path: `tests/test_adapter_integration.py`
- Purpose: Update if needed for adapter-centric architecture

## Class/Function Inventory

**Test class: `TestClientAuthManager` (in `tests/test_auth_manager.py`)**
- Test methods to keep:
  - `test_validate_auth_config_valid`: Assert valid config returns empty error list
  - `test_validate_auth_config_invalid_api_key`: Assert missing API keys returns errors
  - `test_validate_auth_config_invalid_jwt`: Assert missing JWT fields returns errors
  - `test_validate_auth_config_invalid_basic`: Assert missing basic auth fields returns errors
  - `test_validate_auth_config_invalid_certificate`: Assert missing cert fields returns errors
  - `test_is_auth_enabled`: Assert correct detection of enabled/disabled auth
  - `test_get_auth_method`: Assert correct method retrieval
  - `test_get_supported_methods`: Assert returns correct method list
  - `test_get_auth_headers_api_key`: Assert correct header generation for api_key
  - `test_get_auth_headers_jwt`: Assert correct header generation for jwt
  - `test_get_auth_headers_basic`: Assert correct header generation for basic
- Test methods to remove:
  - `test_authenticate_api_key`: REMOVE - fake execution method removed
  - `test_authenticate_jwt`: REMOVE - fake execution method removed
  - `test_authenticate_basic`: REMOVE - fake execution method removed
  - `test_authenticate_certificate`: REMOVE - fake execution method removed
  - `test_create_jwt_token`: REMOVE - method removed
- Test methods to add:
  - `test_fake_auth_methods_removed`: Assert removed methods don't exist

**Test class: `TestAdapterTransport` (in `tests/test_adapter_transport.py`)**
- Test methods to add:
  - `test_ensure_client_with_token`: Assert JsonRpcClient created with token from adapter_params
  - `test_ensure_client_without_token`: Assert JsonRpcClient created without token when None
  - `test_generate_token_method_removed`: Assert `_generate_token_from_config` method no longer exists
  - `test_token_passed_to_adapter`: Assert token from adapter_params is passed to JsonRpcClient
- Test methods to remove:
  - `test_generate_token_from_config`: REMOVE - method removed (if exists)

**Test class: `TestClientFactory` (in `tests/test_client_factory.py`)**
- Test methods to add:
  - `test_create_client_uses_adapter_transport`: Assert created client uses AdapterTransport
  - `test_factory_methods_no_custom_auth`: Assert no custom auth execution in factory methods
  - `test_factory_methods_no_custom_tls`: Assert no custom TLS execution in factory methods
  - `test_create_http_client_uses_adapter`: Assert HTTP client uses adapter transport
  - `test_create_https_client_uses_adapter`: Assert HTTPS client uses adapter transport
  - `test_create_mtls_client_uses_adapter`: Assert mTLS client uses adapter transport
- Test methods to update:
  - Update security mode detection tests to verify adapter transport usage

**Test class: `TestEmbeddingServiceAsyncClient` (in `tests/test_async_client.py`)**
- Test methods to add:
  - `test_client_init_uses_adapter_transport`: Assert client uses AdapterTransport
  - `test_client_init_uses_adapter_config_factory`: Assert client uses AdapterConfigFactory
  - `test_client_no_legacy_transport`: Assert no legacy transport code exists
  - `test_client_config_to_adapter_params`: Assert config is converted to adapter params correctly
  - `test_client_init_without_auth_manager`: Assert client can be created without auth_manager
  - `test_client_uses_adapter_for_auth`: Assert client uses adapter transport for authentication

## Data Structures

**Test fixtures:**
- `valid_api_key_config`: Dict with api_key auth config
- `valid_jwt_config`: Dict with jwt auth config
- `valid_basic_config`: Dict with basic auth config
- `valid_certificate_config`: Dict with certificate auth config
- `adapter_params_with_token`: Dict with adapter params including token
- `adapter_params_without_token`: Dict with adapter params without token

## Import Map

**File: `tests/test_auth_manager.py`**
```python
import pytest
from embed_client.auth import ClientAuthManager, AuthenticationError
```

**File: `tests/test_adapter_transport.py`**
```python
import pytest
from embed_client.adapter_transport import AdapterTransport
```

**File: `tests/test_client_factory.py`**
```python
import pytest
from embed_client.client_factory import ClientFactory
from embed_client.async_client import EmbeddingServiceAsyncClient
from embed_client.adapter_transport import AdapterTransport
```

**File: `tests/test_async_client.py`**
```python
import pytest
from embed_client.async_client import EmbeddingServiceAsyncClient
from embed_client.adapter_transport import AdapterTransport
from embed_client.adapter_config_factory import AdapterConfigFactory
```

## Error Handling Map

**Test methods:**
- Exception: `pytest.raises` for expected exceptions
- Conditions: Test various invalid configs and verify error handling
- Test action: Assert correct exceptions raised or error lists returned

## Config Dependency

**Test configs used:**
- HTTP config: `{"server": {"host": "localhost", "port": 8001}, "auth": {"method": "none"}, "ssl": {"enabled": False}}`
- HTTPS config: `{"server": {"host": "localhost", "port": 8001}, "auth": {"method": "none"}, "ssl": {"enabled": True}}`
- API key config: `{"server": {...}, "auth": {"method": "api_key", "api_keys": {"user": "key"}}, "ssl": {...}}`
- mTLS config: `{"server": {...}, "auth": {...}, "ssl": {"enabled": True, "cert_file": "...", "key_file": "..."}}`

## Test Plan

**Test file: `tests/test_auth_manager.py`**
- Test class: `TestClientAuthManager`
- Test methods: See "Class/Function Inventory" section above
- Fixtures: Valid and invalid config dicts for each auth method
- Assertions: Config validation returns correct errors, methods return correct values, fake methods don't exist

**Test file: `tests/test_adapter_transport.py`**
- Test class: `TestAdapterTransport`
- Test methods: See "Class/Function Inventory" section above
- Fixtures: Adapter params with and without tokens
- Assertions: JsonRpcClient created correctly, token passed from adapter_params, no token generation method

**Test file: `tests/test_client_factory.py`**
- Test class: `TestClientFactory`
- Test methods: See "Class/Function Inventory" section above
- Fixtures: Various security mode parameters
- Assertions: Clients use adapter transport, no custom auth/TLS execution

**Test file: `tests/test_async_client.py`**
- Test class: `TestEmbeddingServiceAsyncClient`
- Test methods: See "Class/Function Inventory" section above
- Fixtures: Various config dicts
- Assertions: Client uses adapter transport, config converted correctly

## Concrete Examples

**Test: `test_fake_auth_methods_removed`**
```python
def test_fake_auth_methods_removed():
    """Assert that fake authentication methods no longer exist."""
    config = {"auth": {"method": "api_key", "api_keys": {"user": "key"}}}
    auth_manager = ClientAuthManager(config)
    
    # Assert removed methods don't exist
    assert not hasattr(auth_manager, "authenticate_api_key")
    assert not hasattr(auth_manager, "authenticate_jwt")
    assert not hasattr(auth_manager, "authenticate_basic")
    assert not hasattr(auth_manager, "authenticate_certificate")
    assert not hasattr(auth_manager, "create_jwt_token")
```

**Test: `test_create_client_uses_adapter_transport`**
```python
def test_create_client_uses_adapter_transport():
    """Assert that created client uses AdapterTransport."""
    client = ClientFactory.create_http_client("http://localhost", port=8001)
    
    # Assert client has adapter transport
    assert hasattr(client, "_transport")
    assert isinstance(client._transport, AdapterTransport)
```

**Test: `test_client_init_uses_adapter_transport`**
```python
def test_client_init_uses_adapter_transport():
    """Assert that client initialization uses AdapterTransport."""
    config_dict = {
        "server": {"host": "localhost", "port": 8001},
        "auth": {"method": "none"},
        "ssl": {"enabled": False}
    }
    client = EmbeddingServiceAsyncClient(config_dict=config_dict)
    
    # Assert client has adapter transport
    assert hasattr(client, "_transport")
    assert isinstance(client._transport, AdapterTransport)
```

## Algorithm/Logic Description

**Test pattern: Verify adapter-only behavior**
1. Create client using factory or direct initialization
2. Assert client has `_transport` attribute
3. Assert `_transport` is instance of `AdapterTransport`
4. Optionally verify `AdapterTransport` was created with correct adapter params
5. Optionally verify no legacy transport code exists

**Test pattern: Verify config validation only**
1. Create `ClientAuthManager` or `ClientSSLManager` with config
2. Call validation method
3. Assert returns error list (not execution result)
4. Assert no authentication or TLS execution happened
5. Verify removed execution methods don't exist

## Forbidden Approaches

- Do NOT test fake authentication execution - those methods are removed
- Do NOT test custom TLS execution - adapter handles all TLS
- Do NOT test custom transport creation - adapter handles all transport
- Do NOT remove integration tests that verify adapter integration works
- Do NOT mock adapter behavior unnecessarily - use real adapter when possible
- Do NOT test implementation details of adapter - test client behavior only
