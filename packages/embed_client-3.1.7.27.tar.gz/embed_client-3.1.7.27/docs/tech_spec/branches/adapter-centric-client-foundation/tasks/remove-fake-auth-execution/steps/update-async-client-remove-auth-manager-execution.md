Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Step: Update async_client.py to Remove auth_manager Execution Dependency

## Executor Role

**Executor**: `coder_auto`

**Execution directive**: Update `EmbeddingServiceAsyncClient.__init__` to remove or clarify that `auth_manager` parameter is used only for config validation, not for authentication execution. Remove any calls to fake authentication methods if present. Update docstring to clarify that authentication is handled by adapter transport.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- Tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/remove-fake-auth-execution.md`

## Step Scope

**Target file**: `embed_client/async_client.py`

**Action**: modify

**Single target**: This step modifies only `embed_client/async_client.py`. No other files are modified in this step.

## Dependency Contract

**Dependencies**: 
- Step: "Remove Fake Auth Methods from ClientAuthManager" (must complete first)

**Dependents**: 
- Step: "Update __init__.py exports for ClientAuthManager"

## Required Context

The `EmbeddingServiceAsyncClient` class currently accepts an optional `auth_manager: Optional[ClientAuthManager]` parameter. This parameter should only be used for configuration validation, not for authentication execution. All actual authentication is handled by `AdapterTransport` which uses `mcp-proxy-adapter` JsonRpcClient. The `auth_manager` parameter may be kept for config validation purposes, but must be clearly documented as config-only.

## Read First

Before starting implementation, read these files:

1. `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md` - Overall architecture requirements
2. `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md` - Global step context
3. `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/remove-fake-auth-execution.md` - Tactical task details
4. `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` - Current implementation
5. `/home/vasilyvz/projects/embed-client/embed_client/auth.py` - Updated ClientAuthManager (after step 1)

## Expected File Change

**File**: `embed_client/async_client.py`

**Changes**:
1. Update `__init__` method docstring to clarify that `auth_manager` is optional and used only for config validation, not execution
2. Update comment at line 244-246 to clarify that `auth_manager` is stored for config validation only, not execution
3. Verify no calls to fake authentication methods exist (should not exist, but verify)
4. Keep `auth_manager` parameter in `__init__` signature (optional, for config validation)
5. Keep `self.auth_manager = auth_manager` assignment (line 246) - still useful for config validation
6. Update class docstring if it mentions authentication execution via auth_manager

## Forbidden Alternatives

**Forbidden**:
- Do NOT remove `auth_manager` parameter from `__init__` signature - it's still used for config validation
- Do NOT add calls to fake authentication methods
- Do NOT modify `AdapterTransport` initialization or usage
- Do NOT modify any mixin classes
- Do NOT modify imports unless removing unused `ClientAuthManager` import (but keep it if auth_manager parameter is kept)
- Do NOT modify any other files in this step

## Atomic Operations

1. Open file `embed_client/async_client.py`
2. Locate `__init__` method docstring (lines 86-98)
3. Update docstring for `auth_manager` parameter:
   - Change: `auth_manager (ClientAuthManager, optional): Authentication manager instance.`
   - To: `auth_manager (ClientAuthManager, optional): Authentication manager instance for configuration validation only. All actual authentication is handled by AdapterTransport via mcp-proxy-adapter.`
4. Locate comment at lines 244-246:
   - Current: `# Store auth_manager if provided (for diagnostics only).\n        # Actual authentication is handled by the adapter transport.`
   - Update to: `# Store auth_manager if provided (for configuration validation only).\n        # All actual authentication execution is handled by AdapterTransport via mcp-proxy-adapter.`
5. Search entire file for any calls to:
   - `self.auth_manager.authenticate_api_key(...)`
   - `self.auth_manager.authenticate_jwt(...)`
   - `self.auth_manager.authenticate_basic(...)`
   - `self.auth_manager.authenticate_certificate(...)`
   - `self.auth_manager.create_jwt_token(...)`
6. If any such calls exist, remove them (should not exist, but verify)
7. Verify class docstring (lines 57-85) - if it mentions authentication execution via auth_manager, update to clarify adapter handles execution
8. Verify import `from embed_client.auth import ClientAuthManager` exists (line 22) - keep it since auth_manager parameter is kept

## Expected Deliverables

**File**: `embed_client/async_client.py`

**Final state**:
- `__init__` method signature unchanged: `auth_manager: Optional[ClientAuthManager] = None` parameter remains
- `__init__` method docstring updated: clarifies `auth_manager` is for config validation only
- Comment at line 244-246 updated: clarifies config validation only, not execution
- `self.auth_manager = auth_manager` assignment remains (line 246)
- No calls to fake authentication methods exist in the file
- Class docstring (if updated) clarifies adapter handles authentication execution
- Import `from embed_client.auth import ClientAuthManager` remains

## Mandatory Validation

After implementation, run these exact commands and verify success:

1. **Format check**:
   ```bash
   black embed_client/async_client.py
   ```
   **Expected**: "reformatted" or "already well formatted" (exit code 0)

2. **Lint check**:
   ```bash
   flake8 embed_client/async_client.py
   ```
   **Expected**: No output (exit code 0)

3. **Type check**:
   ```bash
   mypy embed_client/async_client.py
   ```
   **Expected**: "Success: no issues found" (exit code 0)

4. **Import verification**:
   ```bash
   python -c "from embed_client.async_client import EmbeddingServiceAsyncClient; print('Import OK')"
   ```
   **Expected**: "Import OK" (exit code 0)

5. **No fake method calls verification**:
   ```bash
   python -c "import ast; tree = ast.parse(open('embed_client/async_client.py').read()); methods = ['authenticate_api_key', 'authenticate_jwt', 'authenticate_basic', 'authenticate_certificate', 'create_jwt_token']; calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in methods]; assert len(calls) == 0, f'Found calls to removed methods: {calls}'; print('No fake method calls OK')"
   ```
   **Expected**: "No fake method calls OK" (exit code 0)

6. **Client instantiation verification**:
   ```bash
   python -c "from embed_client.async_client import EmbeddingServiceAsyncClient; c = EmbeddingServiceAsyncClient(base_url='http://localhost', port=8001); print('Client instantiation OK')"
   ```
   **Expected**: "Client instantiation OK" (exit code 0)

**All validation commands must pass before marking this step complete.**

## Decision Rules

1. **If `auth_manager` parameter is used for execution elsewhere in the file**: Remove those usages, keep only config validation usage
2. **If removing `auth_manager` parameter breaks public API**: Keep parameter but document as config-only (current approach)
3. **If class docstring mentions execution via auth_manager**: Update to clarify adapter handles execution
4. **If fake method calls are found**: Remove them immediately

## Blackstops

**Stop immediately and escalate if**:
- `auth_manager` is used for authentication execution in production code paths (not just config validation)
- Removing `auth_manager` parameter breaks public API compatibility in a way that cannot be resolved with documentation
- `AdapterTransport` requires `auth_manager` for initialization (should not happen)

## Handoff Package

**For coder_auto**:

1. **Target file**: `embed_client/async_client.py`
2. **Action**: Update docstrings and comments, verify no fake method calls
3. **Changes**:
   - Update `__init__` docstring for `auth_manager` parameter
   - Update comment at lines 244-246
   - Verify and remove any calls to fake authentication methods
   - Update class docstring if needed
4. **Keep unchanged**:
   - `auth_manager` parameter in `__init__` signature
   - `self.auth_manager = auth_manager` assignment
   - Import `from embed_client.auth import ClientAuthManager`
5. **Validation**: Run all 6 validation commands, all must pass

## File Header

**Exact module docstring** (keep existing, already correct):
```python
"""
Async client for Embedding Service API (OpenAPI 3.0.2)

- 100% type-annotated
- English docstrings and examples
- Ready for PyPi
- Supports new API format with body, embedding, and chunks
- Supports all authentication methods (API Key, JWT, Basic Auth, Certificate)
- Integrates with mcp_security_framework
- Supports all security modes (HTTP, HTTPS, mTLS)

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
```

## Complete Import List

**Exact imports** (keep existing, no changes):
```python
from typing import Any, Dict, Optional

import os

from embed_client.adapter_config_factory import AdapterConfigFactory
from embed_client.adapter_transport import AdapterTransport
from embed_client.auth import ClientAuthManager
from embed_client.config import ClientConfig
from embed_client.constants import (
    DEFAULT_BASE_URL,
    DEFAULT_PORT,
    EMBEDDING_SERVICE_BASE_URL_ENV,
    EMBEDDING_SERVICE_PORT_ENV,
)
from embed_client.exceptions import (
    EmbeddingServiceError,  # noqa: F401
    EmbeddingServiceHTTPError,  # noqa: F401
    EmbeddingServiceConnectionError,  # noqa: F401
    EmbeddingServiceConfigError,
    EmbeddingServiceTimeoutError,  # noqa: F401
    EmbeddingServiceAPIError,  # noqa: F401
    EmbeddingServiceJSONError,  # noqa: F401
)
from embed_client.async_client_api_mixin import AsyncClientAPIMixin
from embed_client.async_client_config_mixin import AsyncClientConfigMixin
from embed_client.async_client_factory_mixin import AsyncClientFactoryMixin
from embed_client.async_client_introspection_mixin import AsyncClientIntrospectionMixin
from embed_client.async_client_lifecycle_mixin import AsyncClientLifecycleMixin
from embed_client.async_client_queue_mixin import AsyncClientQueueMixin
from embed_client.async_client_response_mixin import AsyncClientResponseMixin
```

## Class Skeleton

**Class: `EmbeddingServiceAsyncClient`**
- Base classes: Multiple mixins (keep existing)
- `__init__(self, base_url: Optional[str] = None, port: Optional[int] = None, timeout: float = 30.0, config: Optional[ClientConfig] = None, config_dict: Optional[Dict[str, Any]] = None, auth_manager: Optional[ClientAuthManager] = None, validate_on_init: bool = False) -> None`
- Attributes: `self.config`, `self.config_dict`, `self.auth_manager`, `self.base_url`, `self.port`, `self.timeout`, `self._adapter_transport: AdapterTransport`
- Methods: All mixin methods (no changes to method implementations in this step)
- Status: MODIFY - update docstrings and comments only

## Method Logic - Step-by-Step Algorithm

**Method: `__init__()`** (MODIFY - update docstrings and comments only, no logic changes)
1. All existing logic remains unchanged
2. Only docstring and comment updates:
   - Update `auth_manager` parameter docstring to clarify config validation only
   - Update comment at line 244-246 to clarify config validation only
3. Verify no calls to fake authentication methods exist in the method body
4. All other initialization logic remains exactly as is

## Error Handling per Method

**Method: `__init__()`**
- Exceptions to raise: `EmbeddingServiceConfigError` (unchanged)
- Exceptions to catch: None (unchanged)
- Return: None (unchanged)

## Return Value Specification

**Method: `__init__()`**
- Returns: None (unchanged)
- Side effects: Initializes instance attributes (unchanged)

## Edge Cases

**Method: `__init__()`**
- All edge cases remain unchanged
- `auth_manager=None` → stored as None, no execution attempted (unchanged)
- `auth_manager=ClientAuthManager(...)` → stored for config validation, no execution attempted (unchanged)

## Constants and Literals

**No new constants or literals** - only docstring text updates.

**Docstring text to update**:
- Parameter description: `"Authentication manager instance for configuration validation only. All actual authentication is handled by AdapterTransport via mcp-proxy-adapter."`
- Comment text: `"# Store auth_manager if provided (for configuration validation only).\n        # All actual authentication execution is handled by AdapterTransport via mcp-proxy-adapter."`

## Completion Condition

**All tests must pass** after this step. Tests that depend on `auth_manager` for config validation should continue to work. Tests that call fake authentication methods will fail (expected, handled in separate test task).
