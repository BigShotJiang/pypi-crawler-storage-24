Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Remove Fake Auth Execution from ClientAuthManager

## Goal

Remove all fake authentication execution methods from `ClientAuthManager` and update dependent code to clarify that `ClientAuthManager` is used only for configuration validation, not authentication execution.

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- Tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/remove-fake-auth-execution.md`

## Atomic Steps Summary

**Total steps**: 3

**Dependency order**: Sequential (steps 2 and 3 depend on step 1)

**Parallel execution**: None - steps must run sequentially due to dependencies

## Atomic Steps

### Step 1: Remove Fake Auth Methods from ClientAuthManager

**File**: `remove-fake-auth-methods-from-clientauthmanager.md`

**Target file**: `embed_client/auth.py`

**Action**: Remove 5 fake authentication execution methods from `ClientAuthManager` class:
- `authenticate_api_key()`
- `authenticate_jwt()`
- `authenticate_basic()`
- `authenticate_certificate()`
- `create_jwt_token()`

**Keep**: Configuration validation methods and `AuthResult` class (for test compatibility)

**Dependencies**: None

**Dependents**: Steps 2 and 3

### Step 2: Update async_client.py to Remove auth_manager Execution Dependency

**File**: `update-async-client-remove-auth-manager-execution.md`

**Target file**: `embed_client/async_client.py`

**Action**: Update docstrings and comments to clarify that `auth_manager` parameter is used only for configuration validation, not authentication execution. Verify no calls to fake authentication methods exist.

**Dependencies**: Step 1

**Dependents**: Step 3

### Step 3: Update __init__.py Exports for ClientAuthManager

**File**: `update-init-exports-for-clientauthmanager.md`

**Target file**: `embed_client/__init__.py`

**Action**: Review and optionally update module docstring to clarify that `ClientAuthManager` is for configuration validation only. Verify exports remain correct.

**Dependencies**: Steps 1 and 2

**Dependents**: None

## Execution Order

1. **Step 1** (no dependencies) → Remove fake auth methods
2. **Step 2** (depends on Step 1) → Update async_client.py
3. **Step 3** (depends on Steps 1 and 2) → Update __init__.py

## Parallel Execution

**No parallel execution possible** - all steps must run sequentially due to dependencies.

## Validation Requirements

Each step includes mandatory validation commands that must pass before the step is considered complete:

- Format check (black)
- Lint check (flake8)
- Type check (mypy)
- Import/export verification
- Functional verification

**All tests must pass** after all steps complete (test updates are handled in a separate task per tactical task scope).

## Expected Outcome

After all atomic steps complete:

1. `ClientAuthManager` contains only configuration validation methods
2. No fake authentication execution methods remain
3. `async_client.py` clarifies that `auth_manager` is config-only
4. `__init__.py` exports remain correct with updated documentation
5. All validation commands pass
6. All imports/exports remain functional
