Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Atomic Steps Index: Verify and Update Client Construction Paths

## Parent Links

- Tech spec: `/home/vasilyvz/projects/embed-client/docs/tech_spec/tech_spec.md`
- Global step: `/home/vasilyvz/projects/embed-client/docs/tech_spec/steps/adapter-centric-client-foundation.md`
- Tactical task: `/home/vasilyvz/projects/embed-client/docs/tech_spec/branches/adapter-centric-client-foundation/tasks/verify-client-construction-paths.md`

## Goal

Verify that all client construction paths in `ClientFactory` and `EmbeddingServiceAsyncClient` use only adapter-backed transport and configuration. Ensure no custom auth execution, custom TLS execution, or custom HTTP/WebSocket transport remains in production paths.

## Atomic Steps Summary

### Step 1: Verify and Update ClientFactory for Adapter-Only Construction

**File:** `verify-client-factory-adapter-usage.md`

**Target file:** `embed_client/client_factory.py`

**Purpose:**
- Verify all `ClientFactory` methods use adapter-only construction paths
- Update docstrings to clarify adapter-only responsibility
- Remove comments suggesting custom auth/TLS execution

**Dependencies:** None

### Step 2: Verify and Update EmbeddingServiceAsyncClient for Adapter-Only Transport

**File:** `verify-async-client-adapter-usage.md`

**Target file:** `embed_client/async_client.py`

**Purpose:**
- Verify `EmbeddingServiceAsyncClient.__init__` uses `AdapterConfigFactory` and `AdapterTransport`
- Verify no legacy transport code remains
- Update docstrings to clarify adapter-only transport
- Document `auth_manager` parameter usage

**Dependencies:** None

## Dependency Graph

```
Step 1 (ClientFactory) ──┐
                         ├──> No dependencies - can run in parallel
Step 2 (AsyncClient) ────┘
```

## Parallel Execution

Both steps can be executed in parallel (Wave 1) because:
- They modify different files (`client_factory.py` vs `async_client.py`)
- They have no dependencies on each other
- They both only update docstrings and verify correctness (no code logic changes)

## Completion Criteria

All atomic steps are complete when:
1. ✅ Step 1: `ClientFactory` docstrings updated, no custom auth/TLS execution verified
2. ✅ Step 2: `EmbeddingServiceAsyncClient` docstrings updated, adapter-only transport verified
3. ✅ All validation commands pass for both files
4. ✅ Both files remain under 400 lines
5. ✅ All tests pass (handled by coder_auto)
