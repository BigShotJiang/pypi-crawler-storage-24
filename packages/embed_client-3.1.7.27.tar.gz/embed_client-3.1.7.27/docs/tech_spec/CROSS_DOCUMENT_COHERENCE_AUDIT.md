Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

# Cross-Document Coherence Audit Report

## 1. Verdict

**Status**: **INCOMPLETE** — Multiple coherence gaps prevent 100% execution readiness by a weak model.

**Critical Issues Found**: 4
**Medium Issues Found**: 6
**Minor Issues Found**: 3

The documents contain sufficient high-level direction but lack:
- Explicit adapter response format definitions in global documents
- Operational definitions for parallel step coordination
- Consistent terminology across all documents
- Explicit cross-references to server contract artifacts
- Clear operational definitions for "synchronized with" and "identifier-safe"

## 2. Cross-Document Inconsistencies

### 2.1 Terminology Inconsistencies

#### "adapter" vs "mcp-proxy-adapter"
- **tech_spec.md**: Uses both "adapter" (lines 10, 43-44, 50, 55-56, 115, 136, 144-145, 157, 174-178, 208-209, 217, 223, 226-227) and "mcp-proxy-adapter" (line 10)
- **adapter-centric-client-foundation.md**: Uses "mcp-proxy-adapter" (line 8)
- **Impact**: Weak model may not recognize these refer to the same entity
- **Fix Required**: Standardize on "mcp-proxy-adapter" in all global documents, allow "adapter" only as shorthand in tactical tasks

#### "JSON-RPC request id" vs "JSON-RPC `id`"
- **tech_spec.md**: Uses "JSON-RPC request `id`" (line 52, 177) and "JSON-RPC `id`" (line 225)
- **queue-and-websocket-identifier-separation.md**: Uses "JSON-RPC request ids" (line 35) and "JSON-RPC request `id`" (line 58)
- **Impact**: Minor, but should be consistent
- **Fix Required**: Standardize on "JSON-RPC request `id`" (with backticks) throughout

#### "immediate mode" vs "immediate JSON-RPC result"
- **tech_spec.md**: Uses "Immediate mode" (line 104) and "immediate JSON-RPC result" (line 48, 194, 224)
- **embed-command-and-result-contract-alignment.md**: Uses "immediate JSON-RPC success payloads" (line 38) and "immediate JSON-RPC result mode" (line 33)
- **Impact**: Medium — weak model may treat these as different concepts
- **Fix Required**: Define canonical term "immediate mode" and use consistently; allow "immediate JSON-RPC result" as descriptive phrase only

#### "queued mode" vs "queued submission"
- **tech_spec.md**: Uses "Queued mode" (line 106) and "deferred completion via queue/job semantics" (line 49)
- **embed-command-and-result-contract-alignment.md**: Uses "queued submission followed by resolved result payloads" (line 39)
- **Impact**: Medium — weak model may not recognize equivalence
- **Fix Required**: Define canonical term "queued mode" and use consistently

#### "WebSocket" vs "WS"
- **tech_spec.md**: Uses "WebSocket" throughout (lines 10, 50, 55-56, 66, 108, 136, 144, 176, 195, 217)
- **verification-matrix-and-runtime-validation.md**: Uses "WS" abbreviation (line 45, 72)
- **Impact**: Minor — abbreviation acceptable but should be defined on first use
- **Fix Required**: Define "WS" as abbreviation for "WebSocket" on first use in verification step

### 2.2 Response Format Definition Gap

**Issue**: Adapter response format is defined in code (`embed_client/response_normalizer.py`) and referenced in tactical tasks, but **not defined in global documents**.

- **tech_spec.md**: References adapter behavior but does not define response structure
- **embed-command-and-result-contract-alignment.md**: References "adapter response format" but does not define it
- **Actual Format** (from code):
  - Immediate: `{"mode": "immediate", "command": "...", "result": {...}, "queued": False}`
  - Queued: `{"mode": "queued", "job_id": "...", "status": "...", "result": {...}, "queued": True}`
- **Impact**: **CRITICAL** — weak model cannot implement Step 2 without this definition
- **Fix Required**: Add adapter response format section to `tech_spec.md` under "Public Contract To Support"

### 2.3 Identifier Terminology

**Status**: Mostly consistent — all documents use `job_id` (with underscore) correctly.

**Minor Issue**: "queue/job id" used in implementation_plan.md (line 41) should be "queue/job identifier" or "`job_id`" for consistency.

## 3. Missing Shared Definitions

### 3.1 Adapter Response Format Structure

**Missing**: Explicit definition of adapter response format in global documents.

**Required Addition to tech_spec.md**:
```markdown
### Adapter Response Format

The adapter's `execute_command_unified()` returns responses in this structure:

**Immediate Mode Response**:
```json
{
  "mode": "immediate",
  "command": "<command_name>",
  "result": { ... },
  "queued": false
}
```

**Queued Mode Response**:
```json
{
  "mode": "queued",
  "job_id": "<server_job_id>",
  "status": "<pending|running|completed|failed>",
  "result": { ... },
  "queued": true
}
```

The `result` field structure depends on the command and server response shape.
```

### 3.2 "Synchronized With" Operational Definition

**Missing**: What "synchronized with" means operationally.

- **implementation_plan.md** (line 21): "Step 3 depends on Step 1 and must be synchronized with Step 2"
- **queue-and-websocket-identifier-separation.md** (line 43): "Must stay compatible with command/result behavior from Step 2"
- **embed-command-and-result-contract-alignment.md** (line 45): "Must remain identifier-safe with Step 3"

**Impact**: **CRITICAL** — weak model cannot determine coordination mechanism for parallel steps

**Required Addition to implementation_plan.md**:
```markdown
### Coordination Protocol for Parallel Steps

When steps are marked as "parallelizable with coordination" or "synchronized with":

1. **Shared Interface Contracts**: Both steps must agree on:
   - Method signatures for shared modules
   - Response format expectations
   - Identifier handling rules

2. **Coordination Checkpoints**:
   - Before Step 2 and Step 3 begin tactical decomposition, both must review:
     - Adapter response format expectations
     - Identifier extraction rules
   - If conflicts are detected, escalate to orchestrator before proceeding

3. **Compatibility Guarantees**:
   - Step 2 must not assume identifier handling that Step 3 will change
   - Step 3 must not assume command/result contracts that Step 2 will change
   - Both steps must use the same adapter response format definition
```

### 3.3 "Identifier-Safe" Definition

**Missing**: What "identifier-safe" means operationally.

- **embed-command-and-result-contract-alignment.md** (line 45): "Must remain identifier-safe with Step 3"

**Impact**: **MEDIUM** — weak model cannot verify compliance

**Required Addition to embed-command-and-result-contract-alignment.md**:
```markdown
### Identifier-Safe Requirement

"Identifier-safe" means:
- Do not extract or expose JSON-RPC request `id` as a domain identifier
- Do not assume `job_id` and WebSocket correlation identifiers are equivalent
- Preserve all identifier types separately in internal data structures
- Do not collapse identifier namespaces (JSON-RPC, job, WebSocket) into one
```

### 3.4 "Compatible With" Definition

**Missing**: What "compatible with" means operationally.

- **queue-and-websocket-identifier-separation.md** (line 43): "Must stay compatible with command/result behavior from Step 2"

**Impact**: **MEDIUM** — weak model cannot verify compliance

**Required Addition to queue-and-websocket-identifier-separation.md**:
```markdown
### Compatibility Requirement

"Compatible with command/result behavior from Step 2" means:
- Do not change method signatures that Step 2 defines for command execution
- Do not change response format expectations that Step 2 normalizes
- Do not break identifier extraction logic that Step 2 implements
- Preserve all public API contracts that Step 2 establishes
```

## 4. Missing Dependency Or Ordering Information

### 4.1 Parallel Step Coordination Mechanism

**Issue**: Steps 2 and 3 are marked as parallelizable, but coordination mechanism is undefined.

- **implementation_plan.md** (line 26): "Steps 2 and 3 are parallelizable with coordination"
- **Missing**: What coordination means, when it happens, who performs it

**Impact**: **CRITICAL** — weak model cannot execute parallel steps safely

**Fix Required**: Add "Coordination Protocol for Parallel Steps" section (see Section 3.2)

### 4.2 Server Contract Artifact Links

**Issue**: Server contract artifacts are listed but not linked.

- **tech_spec.md** (lines 14-22): Lists server artifacts with absolute paths
- **Missing**: Verification that these paths exist, or links to alternative locations
- **Impact**: **MEDIUM** — weak model cannot verify source of truth

**Fix Required**: Add verification note or alternative reference locations

### 4.3 Adapter Client Facility References

**Issue**: Adapter client facilities are referenced but not explicitly linked.

- **tech_spec.md** (lines 24-30): Lists adapter-facing client artifacts
- **Missing**: Links to adapter library documentation or interface definitions
- **Impact**: **MEDIUM** — weak model may not understand adapter API contracts

**Fix Required**: Add reference to adapter library documentation or interface definitions

### 4.4 Test Strategy Dependencies

**Issue**: Test strategy references existing tests but does not specify which tests.

- **tech_spec.md** (line 215): "adapter integration tests already present in `tests/`"
- **Missing**: Specific test file names or test class names
- **Impact**: **LOW** — can be discovered, but explicit would be better

**Fix Required**: List specific test files or add "see tests/ directory" with pattern

## 5. Required Global Clarifications

### 5.1 Adapter Response Format Must Be Defined Globally

**Clarification Needed**: The adapter response format structure must be defined in `tech_spec.md` before any step can reference it.

**Action**: Add "Adapter Response Format" section to `tech_spec.md` under "Public Contract To Support" (after line 109).

### 5.2 Parallel Step Execution Protocol

**Clarification Needed**: When Steps 2 and 3 run in parallel, what is the coordination protocol?

**Action**: Add "Coordination Protocol for Parallel Steps" section to `implementation_plan.md` (after line 28).

### 5.3 Identifier Model Completeness

**Clarification Needed**: The identifier model in `tech_spec.md` (lines 110-146) is comprehensive, but Step 2 and Step 3 reference "identifier-safe" and "compatible" without explicit operational definitions.

**Action**: Add operational definitions to both step documents (see Sections 3.3 and 3.4).

### 5.4 Server Contract Verification

**Clarification Needed**: Are the server contract artifact paths in `tech_spec.md` (lines 14-22) verified to exist and be current?

**Action**: Add verification note or update paths if needed.

### 5.5 Adapter Library Interface Documentation

**Clarification Needed**: Where is the authoritative documentation for `mcp-proxy-adapter` client facilities?

**Action**: Add reference link or note about adapter library documentation location.

## 6. Minimal Concrete Edit Plan

### 6.1 tech_spec.md

**Location**: After line 109 (after "Supported Result Modes" section)

**Addition**:
```markdown
### Adapter Response Format

The adapter's `execute_command_unified()` method returns responses in this canonical structure:

**Immediate Mode Response**:
```json
{
  "mode": "immediate",
  "command": "<command_name>",
  "result": { ... },
  "queued": false
}
```

**Queued Mode Response**:
```json
{
  "mode": "queued",
  "job_id": "<server_job_id>",
  "status": "<pending|running|completed|failed>",
  "result": { ... },
  "queued": true
}
```

The `result` field structure depends on the command and server response shape. For `embed` commands:
- Immediate: `result` contains `{"data": {"results": [...], "model": "...", "dimension": N, "device": "..."}}`
- Queued: `result` may be empty or contain initial status; final result is obtained via `embed_job_status` or WebSocket completion.
```

**Location**: Line 10

**Change**: "adapter" → "mcp-proxy-adapter" (first occurrence, keep "adapter" as shorthand in rest of document with note)

**Location**: Line 225

**Change**: "JSON-RPC `id`" → "JSON-RPC request `id`" (for consistency)

### 6.2 implementation_plan.md

**Location**: After line 28 (after "Parallelization" section)

**Addition**:
```markdown
## Coordination Protocol for Parallel Steps

When steps are marked as "parallelizable with coordination" (Steps 2 and 3):

1. **Shared Interface Contracts**: Both steps must agree on:
   - Method signatures for shared modules (`embed_client/adapter_transport.py`, `embed_client/async_client_api_mixin.py`)
   - Adapter response format expectations (defined in `tech_spec.md`)
   - Identifier handling rules (defined in `tech_spec.md` Identifier Model section)

2. **Coordination Checkpoints**:
   - Before tactical decomposition begins for Steps 2 and 3, both tactical orchestrators must:
     - Review adapter response format definition in `tech_spec.md`
     - Review identifier model rules in `tech_spec.md`
     - Agree on method signature changes to shared modules
   - If conflicts are detected, escalate to global orchestrator before proceeding
   - After tactical tasks are written, both orchestrators must verify no conflicting changes to shared modules

3. **Compatibility Guarantees**:
   - Step 2 must not assume identifier handling that Step 3 will change
   - Step 3 must not assume command/result contracts that Step 2 will change
   - Both steps must use the same adapter response format definition from `tech_spec.md`
   - Both steps must preserve the identifier separation rules from `tech_spec.md`
```

**Location**: Line 41

**Change**: "queue/job id" → "queue/job identifier" or "`job_id`"

### 6.3 embed-command-and-result-contract-alignment.md

**Location**: After line 45 (after "Inter-Step Contracts" section)

**Addition**:
```markdown
## Identifier-Safe Requirement

"Identifier-safe" (referenced in Inter-Step Contracts) means:
- Do not extract or expose JSON-RPC request `id` as a domain identifier
- Do not assume `job_id` and WebSocket correlation identifiers are equivalent
- Preserve all identifier types separately in internal data structures
- Do not collapse identifier namespaces (JSON-RPC, job, WebSocket) into one
- Follow the identifier model rules defined in `tech_spec.md` (lines 110-146)
```

**Location**: Line 38

**Change**: "immediate JSON-RPC success payloads" → "immediate mode (JSON-RPC success payloads)"

**Location**: Line 39

**Change**: "queued submission followed by resolved result payloads" → "queued mode (submission followed by resolved result payloads)"

### 6.4 queue-and-websocket-identifier-separation.md

**Location**: After line 43 (after "Inter-Step Contracts" section)

**Addition**:
```markdown
## Compatibility Requirement

"Compatible with command/result behavior from Step 2" (referenced in Inter-Step Contracts) means:
- Do not change method signatures that Step 2 defines for command execution
- Do not change response format expectations that Step 2 normalizes
- Do not break identifier extraction logic that Step 2 implements
- Preserve all public API contracts that Step 2 establishes
- Follow the adapter response format definition from `tech_spec.md`
```

### 6.5 verification-matrix-and-runtime-validation.md

**Location**: Line 45

**Change**: "WS" → "WebSocket (WS)" on first occurrence, then "WS" is acceptable

**Location**: Line 72

**Change**: "WS/JSON-RPC" → "WebSocket/JSON-RPC" (for consistency with tech_spec.md)

---

## Summary

**Total Edits Required**: 5 files, 8 specific changes

**Priority**:
1. **CRITICAL**: Add adapter response format to tech_spec.md (blocks Step 2 execution)
2. **CRITICAL**: Add coordination protocol to implementation_plan.md (blocks parallel execution)
3. **MEDIUM**: Add identifier-safe and compatibility definitions (blocks verification)
4. **LOW**: Terminology standardization (improves clarity)

**Estimated Impact**: Without these edits, a weak model cannot safely execute Steps 2 and 3 in parallel, and cannot implement Step 2 without guessing the adapter response format.
