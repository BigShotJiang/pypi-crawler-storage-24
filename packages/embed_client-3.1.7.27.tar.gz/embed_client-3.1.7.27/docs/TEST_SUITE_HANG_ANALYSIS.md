# Test Suite Hang Analysis Report

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com  
**Date:** 2026-03-20

## Executive Summary

This report analyzes the test suite in `/home/vasilyvz/projects/embed-client` to identify potential causes of test hangs or blocking behavior. The analysis covers test structure, blocking operations, async/await issues, parallelization, infinite loops, deadlocks, and resource waits.

## 1. Test Suite Structure

### Test Configuration Files

- **`pytest.ini`**: Basic configuration with async fixture scope set to `function`
  - No parallel execution configuration found
  - No pytest-xdist configuration
  
- **`tests/conftest.py`**: Test fixtures and markers
  - Imports fixtures from `test_async_client_real_fixtures`
  - Configures stress test markers
  - Skips legacy tests

- **`pyproject.toml`**: Project configuration
  - Test dependencies: `pytest`, `pytest-asyncio`
  - **No pytest-xdist dependency** (parallel execution not configured)

### Test Files Found

52 test files identified in `tests/` directory, including:
- Integration tests (marked with `@pytest.mark.integration`)
- Stress tests (marked with `@pytest.mark.stress`)
- Coverage tests
- Real server tests

## 2. Blocking Operations

### 2.1 Synchronous `time.sleep()` in Async Context

**CRITICAL ISSUE**: Blocking `time.sleep()` used in async context

#### File: `tests/test_comprehensive_server.py`

**Line 218**: Blocking sleep in async context
```python
def start_background(self):
    """Start server in background thread."""
    self.thread = threading.Thread(target=self.start_server, daemon=True)
    self.thread.start()
    time.sleep(2)  # Give server time to start  ⚠️ BLOCKING
    return self.thread.is_alive()
```

**Line 415**: Infinite loop with blocking sleep
```python
try:
    while True:
        time.sleep(1)  # ⚠️ BLOCKING - infinite loop
except KeyboardInterrupt:
    print("\n🛑 Stopping background server...")
    server.stop_server()
```

**Impact**: These blocking sleeps will freeze the event loop if called from async context.

### 2.2 Blocking Subprocess Operations

#### File: `tests/run_all_tests.py`

**Line 281**: Blocking `process.wait()` in async function
```python
for mode, process in self.servers.items():
    try:
        process.terminate()
        process.wait(timeout=5)  # ⚠️ BLOCKING - should use asyncio subprocess
        print(f"✅ {mode} server stopped")
    except Exception as e:
        print(f"❌ Failed to stop {mode} server: {e}")
```

**Impact**: `subprocess.Popen.wait()` is a blocking call that will freeze the async event loop.

#### File: `tests/run_comprehensive_tests.py`

**Line 436**: Same issue
```python
process.wait(timeout=5)  # ⚠️ BLOCKING
```

#### File: `tests/test_server_runner.py`

**Line 267**: Blocking wait in async function
```python
async def stop_server(self, mode: str) -> bool:
    try:
        process = self.servers[mode]
        process.terminate()
        process.wait(timeout=5)  # ⚠️ BLOCKING
        del self.servers[mode]
```

#### File: `tests/test_comprehensive_server.py`

**Line 226**: Blocking thread join
```python
def stop_server(self):
    """Stop the server."""
    if self.server:
        self.server.shutdown()
    if self.thread:
        self.thread.join(timeout=5)  # ⚠️ BLOCKING
```

**Impact**: Thread join is blocking and will freeze if called from async context.

### 2.3 Blocking File I/O

Multiple files use synchronous `open()` and file operations:

- `tests/test_comprehensive_server.py:52` - `with open(self.config_path, "r")`
- `tests/run_comprehensive_tests.py:181` - `with open(config_path, "w")`
- `tests/test_server_runner.py:196` - `with open(config_path, "w")`
- `tests/test_async_completeness.py:133, 147, 211` - Multiple `with open()` calls

**Impact**: While these are typically fast, they can block if files are on slow storage or network mounts.

## 3. Async/Await Issues

### 3.1 Missing Async Subprocess

All subprocess operations use synchronous `subprocess.Popen` instead of `asyncio.create_subprocess_exec`:

**Files affected:**
- `tests/run_all_tests.py:61`
- `tests/run_comprehensive_tests.py:187`
- `tests/test_server_runner.py:233`

**Example:**
```python
# Current (BLOCKING):
process = subprocess.Popen([...], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
await asyncio.sleep(1)  # Workaround for blocking
if process.poll() is None:  # Non-blocking check
    ...

# Should be:
process = await asyncio.create_subprocess_exec(...)
await asyncio.sleep(1)
if process.returncode is None:
    ...
```

### 3.2 Blocking `process.communicate()`

**File: `tests/run_all_tests.py:79`**
```python
else:
    stdout, stderr = process.communicate()  # ⚠️ BLOCKING
    print(f"❌ {mode} server failed to start")
```

**File: `tests/test_server_runner.py:249`**
```python
stdout, stderr = process.communicate()  # ⚠️ BLOCKING
```

**Impact**: `communicate()` blocks until process terminates, freezing the event loop.

## 4. Parallelization

### 4.1 No Parallel Execution Configuration

**Finding**: Tests are **NOT configured for parallel execution**.

- No `pytest-xdist` in dependencies
- No `-n` or `--numprocesses` in pytest configuration
- No `pytest.ini` options for parallel execution

**Impact**: All tests run sequentially, which is safe but slow. However, if tests are run with `pytest-xdist` manually, the blocking operations identified above will cause hangs.

### 4.2 Test Isolation Issues

Tests that start servers may conflict if run in parallel:
- `tests/test_comprehensive_server.py` - Starts servers on fixed ports (10001-10022)
- `tests/run_all_tests.py` - Starts multiple servers
- `tests/run_comprehensive_tests.py` - Starts multiple servers

**Port conflicts** would occur if these tests run in parallel.

## 5. Infinite Loops

### 5.1 Infinite Loop with Sleep

#### File: `tests/test_comprehensive_server.py:414-415`

```python
try:
    while True:
        time.sleep(1)  # ⚠️ INFINITE LOOP with blocking sleep
except KeyboardInterrupt:
    print("\n🛑 Stopping background server...")
    server.stop_server()
```

**Impact**: This loop will run forever until KeyboardInterrupt. If called from async context, it blocks the event loop.

#### File: `tests/test_server_runner.py:300-301`

```python
try:
    while True:
        await asyncio.sleep(1)  # ✅ Async sleep, but still infinite loop
except KeyboardInterrupt:
    print("\n🛑 Stopping all servers...")
    await self.stop_all_servers()
```

**Impact**: Infinite loop, but uses async sleep (non-blocking). However, if KeyboardInterrupt is not handled properly, this could hang.

## 6. Deadlocks

### 6.1 Potential Deadlock: Thread Join in Async Context

**File: `tests/test_comprehensive_server.py:226`**

```python
def stop_server(self):
    if self.thread:
        self.thread.join(timeout=5)  # ⚠️ BLOCKING
```

**Risk**: If `stop_server()` is called from async context while the thread is waiting on async operations, this could deadlock.

### 6.2 Semaphore Usage

**Files:**
- `tests/test_async_client_stress.py:106`
- `tests/test_async_client_stress_new.py:106`
- `tests/test_async_client_stress_updated.py:106`

```python
semaphore = asyncio.Semaphore(max_concurrent)
```

**Status**: ✅ Properly used with `async with semaphore:` pattern. No deadlock risk identified.

## 7. Resource Waits

### 7.1 Unbounded Waits with `timeout=0` or `timeout=None`

Multiple tests use `timeout=0` or `timeout=None` which can wait indefinitely:

**Files with `timeout=0` (wait indefinitely):**
- `tests/test_embed_overrides_coverage.py:322` - `timeout=0`
- `tests/test_queue_methods.py:163` - `timeout=0`
- `tests/test_embed_with_overrides.py:293` - `timeout=0`
- `tests/test_final_coverage.py:210, 272` - `timeout=0`
- `tests/test_adapter_transport_coverage.py:156` - `timeout=0` (with test timeout wrapper)

**Files with `timeout=None` (no timeout):**
- Multiple files use `timeout=None` in embed/wait_for_job calls

**Risk**: If the underlying operation never completes, these tests will hang indefinitely.

**Example from `tests/test_adapter_transport_coverage.py:148-163`:**
```python
# This will wait indefinitely, so we'll timeout the test
import asyncio
try:
    result = await asyncio.wait_for(
        transport.execute_command_unified(
            "embed",
            {"texts": ["test"]},
            auto_poll=True,
            timeout=0,  # ⚠️ Wait indefinitely
            poll_interval=0.01,
        ),
        timeout=0.1,  # ✅ Test has safety timeout
    )
except asyncio.TimeoutError:
    # Expected - timeout=0 means wait indefinitely
    pass
```

**Status**: Most tests with `timeout=0` have safety timeouts, but not all.

### 7.2 Server Startup Waits

**Files:**
- `tests/run_all_tests.py:177` - `await asyncio.sleep(3)` - Wait for servers
- `tests/run_comprehensive_tests.py:302` - `await asyncio.sleep(3)` - Wait for servers
- `tests/test_server_runner.py:242` - `await asyncio.sleep(2)` - Wait for server

**Risk**: Fixed sleep times may not be sufficient if servers are slow to start, leading to test failures. If servers never start, tests will proceed and fail, but won't hang.

### 7.3 WebSocket Timeout Test

**File: `tests/test_websocket_completion.py:252`**

```python
async def mock_wait_timeout(job_id: JobId, timeout: float) -> Dict[str, Any]:
    await asyncio.sleep(timeout + 0.1)  # Sleep longer than timeout
    raise TimeoutError(...)
```

**Status**: ✅ Properly implemented with async sleep and timeout handling.

## 8. Specific Test Files with Issues

### High Priority Issues

1. **`tests/test_comprehensive_server.py`**
   - Line 218: `time.sleep(2)` - Blocking sleep
   - Line 226: `thread.join(timeout=5)` - Blocking join
   - Line 414-415: Infinite loop with blocking sleep

2. **`tests/run_all_tests.py`**
   - Line 281: `process.wait(timeout=5)` - Blocking wait
   - Line 79: `process.communicate()` - Blocking I/O

3. **`tests/run_comprehensive_tests.py`**
   - Line 436: `process.wait(timeout=5)` - Blocking wait

4. **`tests/test_server_runner.py`**
   - Line 267: `process.wait(timeout=5)` - Blocking wait
   - Line 249: `process.communicate()` - Blocking I/O
   - Line 300-301: Infinite loop (but async, lower risk)

### Medium Priority Issues

5. **Tests with `timeout=0`** (multiple files)
   - May wait indefinitely if operations don't complete
   - Most have safety timeouts, but should be verified

6. **Synchronous file I/O** (multiple files)
   - Low risk, but should use async file operations in async context

## 9. Recommendations

### Immediate Actions

1. **Replace blocking `time.sleep()` with `asyncio.sleep()`**
   - `tests/test_comprehensive_server.py:218, 415`

2. **Replace blocking subprocess operations with async versions**
   - Use `asyncio.create_subprocess_exec()` instead of `subprocess.Popen()`
   - Use `await process.wait()` instead of `process.wait()`
   - Use `await process.communicate()` instead of `process.communicate()`
   - Files: `tests/run_all_tests.py`, `tests/run_comprehensive_tests.py`, `tests/test_server_runner.py`

3. **Replace blocking thread operations**
   - `tests/test_comprehensive_server.py:226` - Use async-compatible thread management

4. **Add safety timeouts to all `timeout=0` tests**
   - Ensure every test with `timeout=0` has a wrapper timeout

### Medium-Term Improvements

5. **Configure parallel test execution** (if desired)
   - Add `pytest-xdist` to dependencies
   - Configure test isolation for server tests
   - Use dynamic port allocation to avoid conflicts

6. **Replace synchronous file I/O with async versions**
   - Use `aiofiles` for file operations in async context

7. **Add test timeouts globally**
   - Configure pytest timeouts for all tests
   - Use `pytest-timeout` plugin

### Long-Term Improvements

8. **Refactor server management**
   - Create async-compatible server fixtures
   - Use async context managers for server lifecycle

9. **Add test monitoring**
   - Log test execution times
   - Alert on tests exceeding expected duration

## 10. Summary

### Critical Issues Found

- **3 files** with blocking `time.sleep()` in async context
- **4 files** with blocking subprocess operations
- **1 file** with blocking thread join
- **2 files** with infinite loops (1 blocking, 1 async)
- **Multiple files** with `timeout=0` that could wait indefinitely

### Test Configuration

- **No parallel execution** configured (safe but slow)
- **Async fixture scope**: `function` (correct)
- **No global test timeouts** configured

### Risk Assessment

**High Risk**: Tests that use blocking operations in async context will hang the event loop, causing all tests to freeze.

**Medium Risk**: Tests with `timeout=0` may hang if operations don't complete, but most have safety timeouts.

**Low Risk**: Synchronous file I/O is typically fast, but could block on slow storage.

## Appendix: File-by-File Issue List

| File | Line | Issue | Severity |
|------|------|-------|----------|
| `tests/test_comprehensive_server.py` | 218 | `time.sleep(2)` blocking | CRITICAL |
| `tests/test_comprehensive_server.py` | 226 | `thread.join()` blocking | CRITICAL |
| `tests/test_comprehensive_server.py` | 414-415 | Infinite loop with blocking sleep | CRITICAL |
| `tests/run_all_tests.py` | 79 | `process.communicate()` blocking | CRITICAL |
| `tests/run_all_tests.py` | 281 | `process.wait()` blocking | CRITICAL |
| `tests/run_comprehensive_tests.py` | 436 | `process.wait()` blocking | CRITICAL |
| `tests/test_server_runner.py` | 249 | `process.communicate()` blocking | CRITICAL |
| `tests/test_server_runner.py` | 267 | `process.wait()` blocking | CRITICAL |
| `tests/test_server_runner.py` | 300-301 | Infinite loop (async) | MEDIUM |
| Multiple files | Various | `timeout=0` unbounded waits | MEDIUM |
| Multiple files | Various | Synchronous file I/O | LOW |
