"""
Tests for queued JSON-RPC result mode validation with status polling.

This module tests queued result mode behavior, including:
- Queued result detection (job_id present in response)
- job_id extraction from queued result
- Status polling via job_status() method
- Waiting for completion via wait_for_job() method
- Result normalization after completion
- Identifier separation (no mixing of JSON-RPC request id with job_id)

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import pytest
from typing import Dict, Any, Optional
from unittest.mock import AsyncMock, patch

from embed_client.async_client import EmbeddingServiceAsyncClient
from embed_client.identifier_types import JobId


class TestEmbedQueuedMode:
    """Test queued JSON-RPC result mode with status polling."""

    @pytest.mark.asyncio
    async def test_queued_result_detection(self) -> None:
        """Verify queued result is detected correctly (job_id present in response)."""
        client = EmbeddingServiceAsyncClient(
            config_dict={
                "server": {"host": "http://localhost", "port": 8001},
                "client": {"timeout": 30.0},
            }
        )

        # Mock queued result with job_id at top level
        mock_queued_result = {
            "mode": "queued",
            "job_id": "job-123",
            "status": "pending",
            "message": "accepted",
            "result": {
                "success": True,
                "data": {
                    "job_id": "job-123",
                    "status": "pending",
                    "message": "accepted",
                },
            },
        }

        with patch.object(
            client._adapter_transport,
            "execute_command_unified",
            new_callable=AsyncMock,
        ) as mock_execute:
            mock_execute.return_value = mock_queued_result

            async with client:
                result = await client.embed(texts=["test text"], wait=False)

                # Assert queued result contains job_id
                assert "job_id" in result
                assert result["job_id"] == "job-123"

                # Assert result does NOT contain final business payload at top level
                assert "results" not in result
                assert "embeddings" not in result

                # Assert result may contain status metadata
                assert "status" in result
                assert result["status"] == "pending"
                assert "message" in result
                assert result["message"] == "accepted"

    @pytest.mark.asyncio
    async def test_job_id_extraction(self) -> None:
        """Verify job_id is extracted correctly from queued result."""
        client = EmbeddingServiceAsyncClient(
            config_dict={
                "server": {"host": "http://localhost", "port": 8001},
                "client": {"timeout": 30.0},
            }
        )

        # Test job_id at top level
        mock_result_top = {
            "job_id": "job-456",
            "status": "pending",
        }

        with patch.object(
            client._adapter_transport,
            "execute_command_unified",
            new_callable=AsyncMock,
        ) as mock_execute:
            mock_execute.return_value = mock_result_top

            async with client:
                result = await client.embed(texts=["test"], wait=False)

                # Extract job_id from result
                job_id = result.get("job_id")
                assert job_id is not None
                assert isinstance(job_id, str)
                assert job_id == "job-456"
                assert job_id.strip() == "job-456"

                # Assert job_id is of type JobId (when extracted by client)
                # The client should extract it correctly

        # Test job_id nested in result.data
        mock_result_nested = {
            "result": {
                "success": True,
                "data": {
                    "job_id": "job-789",
                    "status": "pending",
                },
            },
        }

        with patch.object(
            client._adapter_transport,
            "execute_command_unified",
            new_callable=AsyncMock,
        ) as mock_execute:
            mock_execute.return_value = mock_result_nested

            async with client:
                result = await client.embed(texts=["test"], wait=False)

                # Extract job_id from nested location
                job_id = result.get("job_id")
                assert job_id is not None
                assert isinstance(job_id, str)
                assert job_id == "job-789"

    @pytest.mark.asyncio
    async def test_job_status_polling(self) -> None:
        """Verify status polling via job_status() method."""
        client = EmbeddingServiceAsyncClient(
            config_dict={
                "server": {"host": "http://localhost", "port": 8001},
                "client": {"timeout": 30.0},
            }
        )

        # Mock queued result with job_id
        mock_queued_result = {
            "mode": "queued",
            "job_id": "job-123",
            "status": "pending",
        }

        # Mock status progression: pending -> running -> completed
        status_progression = [
            {"exists": True, "status": "pending", "done": False},
            {"exists": True, "status": "running", "done": False},
            {
                "exists": True,
                "status": "completed",
                "done": True,
                "result": {
                    "results": [
                        {
                            "body": "test text",
                            "embedding": [0.1, 0.2, 0.3],
                            "tokens": ["test", "text"],
                            "bm25_tokens": ["test", "text"],
                        }
                    ],
                    "model": "test-model",
                    "dimension": 768,
                    "device": "cpu",
                },
            },
        ]

        status_call_count = 0

        async def mock_job_status(job_id: JobId) -> Dict[str, Any]:
            nonlocal status_call_count
            if status_call_count < len(status_progression):
                result = status_progression[status_call_count]
                status_call_count += 1
                return result
            return status_progression[-1]

        with patch.object(
            client._adapter_transport,
            "execute_command_unified",
            new_callable=AsyncMock,
        ) as mock_execute:
            mock_execute.return_value = mock_queued_result

            with patch.object(
                client,
                "job_status",
                side_effect=mock_job_status,
            ):
                async with client:
                    # Get job_id from embed call
                    result = await client.embed(texts=["test"], wait=False)
                    job_id = result["job_id"]

                    # First call: pending
                    status1 = await client.job_status(JobId(job_id))
                    assert status1.get("status") == "pending"
                    assert status1.get("done") is False

                    # Second call: running
                    status2 = await client.job_status(JobId(job_id))
                    assert status2.get("status") == "running"
                    assert status2.get("done") is False

                    # Third call: completed
                    status3 = await client.job_status(JobId(job_id))
                    assert status3.get("status") == "completed"
                    assert status3.get("done") is True
                    assert "result" in status3

    @pytest.mark.asyncio
    async def test_wait_for_job(self) -> None:
        """Verify wait_for_job() completes successfully."""
        client = EmbeddingServiceAsyncClient(
            config_dict={
                "server": {"host": "http://localhost", "port": 8001},
                "client": {"timeout": 30.0},
            }
        )

        # Mock queued result with job_id
        mock_queued_result = {
            "mode": "queued",
            "job_id": "job-123",
            "status": "pending",
        }

        # Mock final result after completion
        mock_final_result = {
            "results": [
                {
                    "body": "test text",
                    "embedding": [0.1, 0.2, 0.3],
                    "tokens": ["test", "text"],
                    "bm25_tokens": ["test", "text"],
                }
            ],
            "model": "test-model",
            "dimension": 768,
            "device": "cpu",
        }

        # Mock status progression: pending -> completed
        status_calls = 0

        async def mock_job_status(job_id: JobId) -> Dict[str, Any]:
            nonlocal status_calls
            status_calls += 1
            if status_calls == 1:
                return {"exists": True, "status": "pending", "done": False}
            return {
                "exists": True,
                "status": "completed",
                "done": True,
                "result": mock_final_result,
            }

        with patch.object(
            client._adapter_transport,
            "execute_command_unified",
            new_callable=AsyncMock,
        ) as mock_execute:
            mock_execute.return_value = mock_queued_result

            with patch.object(
                client,
                "job_status",
                side_effect=mock_job_status,
            ):
                async with client:
                    # Get job_id from embed call
                    result = await client.embed(texts=["test"], wait=False)
                    job_id = result["job_id"]

                    # Wait for job completion (this will use the real wait_for_job method
                    # which calls job_status, which we've mocked to progress)
                    final_result = await client.wait_for_job(
                        JobId(job_id), timeout=60.0
                    )

                    # Assert method returns final result (not status dict)
                    assert "results" in final_result or "embeddings" in final_result

                    # Assert final result contains business payload
                    if "results" in final_result:
                        assert isinstance(final_result["results"], list)
                        assert len(final_result["results"]) > 0

                    # Assert final result contains model, dimension, device fields
                    assert "model" in final_result
                    assert final_result["model"] == "test-model"
                    assert "dimension" in final_result
                    assert final_result["dimension"] == 768
                    assert "device" in final_result
                    assert final_result["device"] == "cpu"

    @pytest.mark.asyncio
    async def test_queued_result_normalization(self) -> None:
        """Verify result normalization after completion."""
        client = EmbeddingServiceAsyncClient(
            config_dict={
                "server": {"host": "http://localhost", "port": 8001},
                "client": {"timeout": 30.0},
            }
        )

        # Mock queued result with job_id
        mock_queued_result = {
            "mode": "queued",
            "job_id": "job-123",
            "status": "pending",
        }

        # Mock completed result with server contract structure
        mock_completed_result = {
            "results": [
                {
                    "body": "test 1",
                    "embedding": [0.1, 0.2, 0.3],
                    "tokens": ["test", "1"],
                    "bm25_tokens": ["test", "1"],
                },
                {
                    "body": "test 2",
                    "embedding": [0.4, 0.5, 0.6],
                    "tokens": ["test", "2"],
                    "bm25_tokens": ["test", "2"],
                },
            ],
            "model": "test-model",
            "dimension": 768,
            "device": "cpu",
        }

        async def mock_wait_for_job(
            job_id: JobId, timeout: Optional[float] = 60.0, poll_interval: float = 0.3
        ) -> Dict[str, Any]:
            return mock_completed_result

        with patch.object(
            client._adapter_transport,
            "execute_command_unified",
            new_callable=AsyncMock,
        ) as mock_execute:
            mock_execute.return_value = mock_queued_result

            with patch.object(
                client,
                "wait_for_job",
                side_effect=mock_wait_for_job,
            ):
                async with client:
                    # Submit job
                    result = await client.embed(
                        texts=["test 1", "test 2"],
                        model="test-model",
                        dimension=768,
                        device="cpu",
                        wait=False,
                    )

                    # Get job_id
                    job_id = result["job_id"]

                    # Wait for completion
                    final_result = await client.wait_for_job(JobId(job_id))

                    # Assert final result contains "results" list OR "embeddings" list
                    assert "results" in final_result or "embeddings" in final_result

                    # If "results" present: assert each result item contains expected fields
                    if "results" in final_result:
                        assert isinstance(final_result["results"], list)
                        for result_item in final_result["results"]:
                            assert "body" in result_item
                            assert "embedding" in result_item
                            assert "tokens" in result_item
                            assert "bm25_tokens" in result_item

                    # If "embeddings" present: assert embeddings is a list of lists
                    if "embeddings" in final_result:
                        assert isinstance(final_result["embeddings"], list)
                        for emb in final_result["embeddings"]:
                            assert isinstance(emb, list)

                    # Assert final result contains "model" field matching input model
                    assert "model" in final_result
                    assert final_result["model"] == "test-model"

                    # Assert final result contains "dimension" field matching input dimension
                    assert "dimension" in final_result
                    assert final_result["dimension"] == 768

                    # Assert final result contains "device" field matching input device
                    assert "device" in final_result
                    assert final_result["device"] == "cpu"

                    # Assert final result does NOT contain "job_id" (normalized out)
                    assert "job_id" not in final_result

    @pytest.mark.asyncio
    async def test_identifier_separation(self) -> None:
        """Verify JSON-RPC request id is not used as job_id."""
        client = EmbeddingServiceAsyncClient(
            config_dict={
                "server": {"host": "http://localhost", "port": 8001},
                "client": {"timeout": 30.0},
            }
        )

        # Mock queued result with job_id (distinct from JSON-RPC request id)
        # JSON-RPC request id would be something like "req-123" or numeric
        # job_id should be "job-123" (different format/value)
        mock_queued_result = {
            "mode": "queued",
            "job_id": "job-123",
            "status": "pending",
            # JSON-RPC id would be in adapter's internal structure, not exposed here
        }

        # Track JSON-RPC request id separately (if exposed in mocks)
        jsonrpc_request_id = "req-456"  # Example JSON-RPC request id

        with patch.object(
            client._adapter_transport,
            "execute_command_unified",
            new_callable=AsyncMock,
        ) as mock_execute:
            mock_execute.return_value = mock_queued_result

            async with client:
                # Call embed to get queued result
                result = await client.embed(texts=["test"], wait=False)

                # Extract job_id from result
                job_id = result.get("job_id")
                assert job_id is not None
                assert isinstance(job_id, str)
                assert job_id == "job-123"

                # Assert job_id is NOT equal to JSON-RPC request id
                # (JSON-RPC id is not exposed in result, but if it were, it should be different)
                assert job_id != jsonrpc_request_id

                # Assert job_id is a valid job identifier (non-empty string)
                assert len(job_id.strip()) > 0

                # Mock job_status to verify it uses job_id (not JSON-RPC id)
                mock_status_result = {
                    "exists": True,
                    "status": "pending",
                    "done": False,
                }

                with patch.object(
                    client._adapter_transport,
                    "queue_get_job_status",
                    new_callable=AsyncMock,
                ) as mock_status:
                    mock_status.return_value = mock_status_result

                    # Call job_status with job_id
                    status = await client.job_status(JobId(job_id))

                    # Verify status result is correct
                    assert status.get("exists") is True
                    assert status.get("status") == "pending"

                    # Verify job_status was called with job_id (not JSON-RPC id)
                    mock_status.assert_called_once()
                    call_args = mock_status.call_args[0]
                    assert len(call_args) > 0
                    called_job_id = str(call_args[0])
                    assert called_job_id == job_id
                    assert called_job_id != jsonrpc_request_id

                # Mock wait_for_job to verify it uses job_id (not JSON-RPC id)
                mock_final_result = {
                    "results": [
                        {
                            "body": "test",
                            "embedding": [0.1, 0.2, 0.3],
                            "tokens": ["test"],
                            "bm25_tokens": ["test"],
                        }
                    ],
                    "model": "test-model",
                    "dimension": 768,
                    "device": "cpu",
                }

                async def mock_wait_for_job(
                    job_id_param: JobId,
                    timeout: Optional[float] = 60.0,
                    poll_interval: float = 0.3,
                ) -> Dict[str, Any]:
                    # Verify job_id_param matches extracted job_id (not JSON-RPC id)
                    assert str(job_id_param) == job_id
                    assert str(job_id_param) != jsonrpc_request_id
                    return mock_final_result

                with patch.object(
                    client,
                    "wait_for_job",
                    side_effect=mock_wait_for_job,
                ):
                    # Call wait_for_job with job_id
                    final_result = await client.wait_for_job(JobId(job_id))

                    # Verify result is correct
                    assert "results" in final_result or "embeddings" in final_result
