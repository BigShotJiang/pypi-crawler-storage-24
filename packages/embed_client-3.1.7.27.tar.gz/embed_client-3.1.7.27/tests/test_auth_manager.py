"""
Tests for ClientAuthManager class.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from embed_client.auth import ClientAuthManager


class TestClientAuthManager:
    """Test cases for ClientAuthManager class."""

    def test_init_with_security_framework(self):
        """Test initialization with security framework available."""
        config = {"auth": {"method": "api_key", "api_keys": {"user1": "key123"}}}
        auth_manager = ClientAuthManager(config)
        assert auth_manager.config == config

    def test_init_without_security_framework(self):
        """Test initialization without security framework."""
        config = {"auth": {"method": "api_key", "api_keys": {"user1": "key123"}}}
        auth_manager = ClientAuthManager(config)
        assert auth_manager.config == config

    def test_get_auth_headers_api_key(self):
        """Test getting auth headers for API key."""
        config = {"auth": {"method": "api_key"}}
        auth_manager = ClientAuthManager(config)

        headers = auth_manager.get_auth_headers("api_key", api_key="test_key")
        assert headers == {"X-API-Key": "test_key"}

    def test_get_auth_headers_api_key_custom_header(self):
        """Test getting auth headers for API key with custom header."""
        config = {"auth": {"method": "api_key"}}
        auth_manager = ClientAuthManager(config)

        headers = auth_manager.get_auth_headers(
            "api_key", api_key="test_key", header="X-Custom-Key"
        )
        assert headers == {"X-Custom-Key": "test_key"}

    def test_get_auth_headers_jwt(self):
        """Test getting auth headers for JWT."""
        config = {"auth": {"method": "jwt"}}
        auth_manager = ClientAuthManager(config)

        headers = auth_manager.get_auth_headers("jwt", token="test_token")
        assert headers == {"Authorization": "Bearer test_token"}

    def test_get_auth_headers_basic(self):
        """Test getting auth headers for basic auth."""
        config = {"auth": {"method": "basic"}}
        auth_manager = ClientAuthManager(config)

        headers = auth_manager.get_auth_headers(
            "basic", username="user", password="pass"
        )
        expected_auth = "Basic " + "dXNlcjpwYXNz"  # base64 of "user:pass"
        assert headers == {"Authorization": expected_auth}

    def test_get_auth_headers_certificate(self):
        """Test getting auth headers for certificate (should be empty)."""
        config = {"auth": {"method": "certificate"}}
        auth_manager = ClientAuthManager(config)

        headers = auth_manager.get_auth_headers("certificate")
        assert headers == {}

    def test_validate_auth_config_valid_api_key(self):
        """Test validating valid API key config."""
        config = {"auth": {"method": "api_key", "api_keys": {"user1": "key123"}}}
        auth_manager = ClientAuthManager(config)

        errors = auth_manager.validate_auth_config()
        assert len(errors) == 0

    def test_validate_auth_config_invalid_api_key(self):
        """Test validating invalid API key config."""
        config = {"auth": {"method": "api_key", "api_keys": {}}}
        auth_manager = ClientAuthManager(config)

        errors = auth_manager.validate_auth_config()
        assert len(errors) == 1
        assert "API keys not configured" in errors[0]

    def test_validate_auth_config_valid_basic(self):
        """Test validating valid basic auth config."""
        config = {
            "auth": {
                "method": "basic",
                "basic": {"username": "user", "password": "pass"},
            }
        }
        auth_manager = ClientAuthManager(config)

        errors = auth_manager.validate_auth_config()
        assert len(errors) == 0

    def test_validate_auth_config_invalid_basic(self):
        """Test validating invalid basic auth config."""
        config = {
            "auth": {
                "method": "basic",
                "basic": {
                    "username": "user"
                    # missing password
                },
            }
        }
        auth_manager = ClientAuthManager(config)

        errors = auth_manager.validate_auth_config()
        assert len(errors) == 1
        assert "password not configured" in errors[0]

    def test_validate_auth_config_valid_certificate(self):
        """Test validating valid certificate config."""
        config = {
            "auth": {
                "method": "certificate",
                "certificate": {"cert_file": "test.crt", "key_file": "test.key"},
            }
        }
        auth_manager = ClientAuthManager(config)

        errors = auth_manager.validate_auth_config()
        assert len(errors) == 0

    def test_validate_auth_config_invalid_certificate(self):
        """Test validating invalid certificate config."""
        config = {
            "auth": {
                "method": "certificate",
                "certificate": {
                    "cert_file": "test.crt"
                    # missing key_file
                },
            }
        }
        auth_manager = ClientAuthManager(config)

        errors = auth_manager.validate_auth_config()
        assert len(errors) == 1
        assert "Key file not configured" in errors[0]

    def test_is_auth_enabled_true(self):
        """Test checking if auth is enabled."""
        config = {"auth": {"method": "api_key"}}
        auth_manager = ClientAuthManager(config)

        assert auth_manager.is_auth_enabled() is True

    def test_is_auth_enabled_false(self):
        """Test checking if auth is disabled."""
        config = {"auth": {"method": "none"}}
        auth_manager = ClientAuthManager(config)

        assert auth_manager.is_auth_enabled() is False

    def test_get_auth_method(self):
        """Test getting auth method."""
        config = {"auth": {"method": "api_key"}}
        auth_manager = ClientAuthManager(config)

        assert auth_manager.get_auth_method() == "api_key"

    def test_get_supported_methods(self):
        """Test getting supported authentication methods."""
        config = {"auth": {"method": "api_key"}}
        auth_manager = ClientAuthManager(config)

        methods = auth_manager.get_supported_methods()
        assert "api_key" in methods
        assert "basic" in methods

    def test_fake_auth_methods_removed(self):
        """Assert that fake authentication methods no longer exist."""
        config = {"auth": {"method": "api_key", "api_keys": {"user": "key"}}}
        auth_manager = ClientAuthManager(config)

        assert not hasattr(auth_manager, "authenticate_api_key")
        assert not hasattr(auth_manager, "authenticate_jwt")
        assert not hasattr(auth_manager, "authenticate_basic")
        assert not hasattr(auth_manager, "authenticate_certificate")
        assert not hasattr(auth_manager, "create_jwt_token")
