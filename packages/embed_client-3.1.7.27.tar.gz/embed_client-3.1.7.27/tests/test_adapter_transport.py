"""
Tests for AdapterTransport class.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import pytest
import pytest_asyncio
from unittest.mock import AsyncMock, MagicMock, patch

from embed_client.adapter_transport import AdapterTransport


@pytest_asyncio.fixture
async def transport_with_token():
    """Transport fixture with token."""
    transport = AdapterTransport(
        adapter_params={
            "protocol": "http",
            "host": "localhost",
            "port": 8001,
            "token": "test_token_123",
            "token_header": "X-API-Key",
        }
    )
    yield transport
    await transport.close()


@pytest_asyncio.fixture
async def transport_without_token():
    """Transport fixture without token."""
    transport = AdapterTransport(
        adapter_params={
            "protocol": "http",
            "host": "localhost",
            "port": 8001,
        }
    )
    yield transport
    await transport.close()


class TestAdapterTransport:
    """Test cases for AdapterTransport class."""

    @pytest.mark.asyncio
    async def test_ensure_client_with_token(self, transport_with_token):
        """Assert JsonRpcClient created with token from adapter_params."""
        with patch(
            "embed_client.adapter_transport.JsonRpcClient",
            new_callable=MagicMock,
        ) as mock_jsonrpc_client:
            mock_instance = AsyncMock()
            mock_jsonrpc_client.return_value = mock_instance

            await transport_with_token._ensure_client()

            mock_jsonrpc_client.assert_called_once()
            call_kwargs = mock_jsonrpc_client.call_args.kwargs
            assert call_kwargs.get("token") == "test_token_123"
            assert call_kwargs.get("token_header") == "X-API-Key"

    @pytest.mark.asyncio
    async def test_ensure_client_without_token(self, transport_without_token):
        """Assert JsonRpcClient created without token when None."""
        with patch(
            "embed_client.adapter_transport.JsonRpcClient",
            new_callable=MagicMock,
        ) as mock_jsonrpc_client:
            mock_instance = AsyncMock()
            mock_jsonrpc_client.return_value = mock_instance

            await transport_without_token._ensure_client()

            mock_jsonrpc_client.assert_called_once()
            call_kwargs = mock_jsonrpc_client.call_args.kwargs
            assert call_kwargs.get("token") is None
            assert call_kwargs.get("token_header") is None

    @pytest.mark.asyncio
    async def test_generate_token_method_removed(self, transport_with_token):
        """Assert _generate_token_from_config method no longer exists or returns None."""
        # Method should not exist
        assert not hasattr(transport_with_token, "_generate_token_from_config")

    @pytest.mark.asyncio
    async def test_token_passed_to_adapter(self, transport_with_token):
        """Assert token from adapter_params is passed to JsonRpcClient."""
        with patch(
            "embed_client.adapter_transport.JsonRpcClient",
            new_callable=MagicMock,
        ) as mock_jsonrpc_client:
            mock_instance = AsyncMock()
            mock_jsonrpc_client.return_value = mock_instance

            await transport_with_token._ensure_client()

            # Verify JsonRpcClient was called with token from adapter_params
            mock_jsonrpc_client.assert_called_once()
            call_kwargs = mock_jsonrpc_client.call_args.kwargs
            assert call_kwargs.get("token") == "test_token_123"
            assert call_kwargs.get("token_header") == "X-API-Key"
            # Verify token comes from adapter_params, not generated
            assert call_kwargs.get("token") == transport_with_token.adapter_params.get(
                "token"
            )
