"""
Tests for adapter-managed WebSocket completion validation.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import pytest
import asyncio
from typing import Dict, Any
from unittest.mock import AsyncMock, patch

from embed_client.async_client import EmbeddingServiceAsyncClient
from embed_client.exceptions import EmbeddingServiceTimeoutError
from embed_client.identifier_types import JobId


class TestWebSocketCompletion:
    """Test adapter-managed WebSocket completion."""

    @pytest.mark.asyncio
    async def test_websocket_waiting(self) -> None:
        """Verify wait_for_job_via_websocket() works correctly."""
        # Create test client
        config_dict = {
            "server": {"host": "http://localhost", "port": 8001},
            "client": {"timeout": 30.0},
        }
        client = EmbeddingServiceAsyncClient(config_dict=config_dict)
        await client.__aenter__()

        try:
            # Mock adapter transport that returns queued result with job_id="job-123"
            with patch.object(
                client._adapter_transport,
                "execute_command_unified",
                new_callable=AsyncMock,
            ) as mock_execute:
                mock_execute.return_value = {
                    "mode": "queued",
                    "job_id": "job-123",
                    "status": "pending",
                    "message": "accepted",
                }

                # Call embed(texts=["test"], wait=False) to get job_id
                result = await client.embed(texts=["test"], wait=False)
                job_id = result["job_id"]

            # Mock wait_for_job_via_websocket to simulate WebSocket completion
            final_result = {
                "results": [
                    {
                        "body": "test",
                        "embedding": [0.1, 0.2, 0.3],
                        "tokens": [1, 2, 3],
                        "bm25_tokens": [4, 5, 6],
                    }
                ],
                "embeddings": [[0.1, 0.2, 0.3]],
                "model": "test-model",
                "dimension": 768,
                "device": "cpu",
            }
            with patch.object(
                client._adapter_transport,
                "wait_for_job_via_websocket",
                new_callable=AsyncMock,
            ) as mock_ws:
                mock_ws.return_value = {
                    "event": "job_completed",
                    "result": final_result,
                }

                # Call wait_for_job_via_websocket(job_id, timeout=60.0)
                final = await client.wait_for_job_via_websocket(
                    JobId(job_id), timeout=60.0
                )

                # Assert method returns final result (not status dict)
                assert isinstance(final, dict)
                assert "results" in final or "embeddings" in final

                # Assert final result contains business payload (embeddings or results)
                if "results" in final:
                    assert isinstance(final["results"], list)
                    assert len(final["results"]) > 0
                if "embeddings" in final:
                    assert isinstance(final["embeddings"], list)
                    assert len(final["embeddings"]) > 0

                # Assert final result contains model, dimension, device fields
                assert "model" in final
                assert final["model"] == "test-model"
                assert "dimension" in final
                assert final["dimension"] == 768
                assert "device" in final
                assert final["device"] == "cpu"

                # Assert method completes within timeout
                mock_ws.assert_called_once()
                call_args = mock_ws.call_args
                assert call_args[0][0] == "job-123" or call_args[0][0] == JobId(
                    "job-123"
                )
                assert call_args[1]["timeout"] == 60.0
        finally:
            await client.__aexit__(None, None, None)

    @pytest.mark.asyncio
    async def test_websocket_result_delivery(self) -> None:
        """Verify result delivery through WebSocket."""
        # Create test client
        config_dict = {
            "server": {"host": "http://localhost", "port": 8001},
            "client": {"timeout": 30.0},
        }
        client = EmbeddingServiceAsyncClient(config_dict=config_dict)
        await client.__aenter__()

        try:
            # Mock adapter transport that returns queued result with job_id="job-123"
            with patch.object(
                client._adapter_transport,
                "execute_command_unified",
                new_callable=AsyncMock,
            ) as mock_execute:
                mock_execute.return_value = {
                    "mode": "queued",
                    "job_id": "job-123",
                    "status": "pending",
                    "message": "accepted",
                }

                # Call embed(texts=["test 1", "test 2"], model="test-model", dimension=768, device="cpu", wait=False)
                result = await client.embed(
                    texts=["test 1", "test 2"],
                    model="test-model",
                    dimension=768,
                    device="cpu",
                    wait=False,
                )
                job_id = result["job_id"]

            # Mock wait_for_job_via_websocket to return completed result with server contract structure
            server_result = {
                "results": [
                    {
                        "body": "test 1",
                        "embedding": [0.1, 0.2, 0.3],
                        "tokens": [1, 2, 3],
                        "bm25_tokens": [4, 5, 6],
                    },
                    {
                        "body": "test 2",
                        "embedding": [0.4, 0.5, 0.6],
                        "tokens": [7, 8, 9],
                        "bm25_tokens": [10, 11, 12],
                    },
                ],
                "embeddings": [[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]],
                "model": "test-model",
                "dimension": 768,
                "device": "cpu",
            }
            with patch.object(
                client._adapter_transport,
                "wait_for_job_via_websocket",
                new_callable=AsyncMock,
            ) as mock_ws:
                mock_ws.return_value = {
                    "event": "job_completed",
                    "result": server_result,
                }

                # Call wait_for_job_via_websocket(job_id) to get final result
                final_result = await client.wait_for_job_via_websocket(JobId(job_id))

                # Assert final result contains "results" list OR "embeddings" list
                assert "results" in final_result or "embeddings" in final_result

                # If "results" present: assert each result item contains expected fields
                if "results" in final_result:
                    assert isinstance(final_result["results"], list)
                    assert len(final_result["results"]) > 0
                    for result_item in final_result["results"]:
                        assert "body" in result_item
                        assert "embedding" in result_item
                        assert "tokens" in result_item
                        assert "bm25_tokens" in result_item

                # If "embeddings" present: assert embeddings is a list of lists
                if "embeddings" in final_result:
                    assert isinstance(final_result["embeddings"], list)
                    assert len(final_result["embeddings"]) > 0
                    for embedding in final_result["embeddings"]:
                        assert isinstance(embedding, list)

                # Assert final result contains "model" field matching input model
                assert "model" in final_result
                assert final_result["model"] == "test-model"

                # Assert final result contains "dimension" field matching input dimension
                assert "dimension" in final_result
                assert final_result["dimension"] == 768

                # Assert final result contains "device" field matching input device
                assert "device" in final_result
                assert final_result["device"] == "cpu"

                # Assert final result structure matches server contract
                assert isinstance(final_result, dict)
                assert "model" in final_result
                assert "dimension" in final_result
                assert "device" in final_result
        finally:
            await client.__aexit__(None, None, None)

    @pytest.mark.asyncio
    async def test_websocket_timeout(self) -> None:
        """Verify timeout handling for WebSocket waiting."""
        # Create test client
        config_dict = {
            "server": {"host": "http://localhost", "port": 8001},
            "client": {"timeout": 30.0},
        }
        client = EmbeddingServiceAsyncClient(config_dict=config_dict)
        await client.__aenter__()

        try:
            # Mock adapter transport that returns queued result with job_id="job-123"
            with patch.object(
                client._adapter_transport,
                "execute_command_unified",
                new_callable=AsyncMock,
            ) as mock_execute:
                mock_execute.return_value = {
                    "mode": "queued",
                    "job_id": "job-123",
                    "status": "pending",
                    "message": "accepted",
                }

                # Call embed(texts=["test"], wait=False) to get job_id
                result = await client.embed(texts=["test"], wait=False)
                job_id = result["job_id"]

            # Mock wait_for_job_via_websocket to simulate timeout (never completes)
            async def mock_wait_timeout(
                job_id: JobId, timeout: float
            ) -> Dict[str, Any]:
                await asyncio.sleep(timeout + 0.1)  # Sleep longer than timeout
                raise TimeoutError(
                    f"Job {job_id} did not complete within {timeout} seconds"
                )

            with patch.object(
                client._adapter_transport,
                "wait_for_job_via_websocket",
                new_callable=AsyncMock,
            ) as mock_ws:
                mock_ws.side_effect = mock_wait_timeout

                # Call wait_for_job_via_websocket(job_id, timeout=1.0) with short timeout
                with pytest.raises(EmbeddingServiceTimeoutError) as exc_info:
                    await client.wait_for_job_via_websocket(JobId(job_id), timeout=1.0)

                # Assert method raises EmbeddingServiceTimeoutError when timeout exceeded
                assert isinstance(exc_info.value, EmbeddingServiceTimeoutError)

                # Assert exception message indicates timeout
                assert (
                    "timeout" in str(exc_info.value).lower()
                    or "did not complete" in str(exc_info.value).lower()
                )

                # Assert exception contains job_id or relevant context
                assert "job-123" in str(exc_info.value) or job_id in str(exc_info.value)
        finally:
            await client.__aexit__(None, None, None)

    @pytest.mark.asyncio
    async def test_websocket_identifier_separation(self) -> None:
        """Verify job_id vs WebSocket correlation id separation."""
        # Create test client
        config_dict = {
            "server": {"host": "http://localhost", "port": 8001},
            "client": {"timeout": 30.0},
        }
        client = EmbeddingServiceAsyncClient(config_dict=config_dict)
        await client.__aenter__()

        try:
            # Mock adapter transport that tracks job_id and WebSocket correlation identifier separately
            with patch.object(
                client._adapter_transport,
                "execute_command_unified",
                new_callable=AsyncMock,
            ) as mock_execute:
                mock_execute.return_value = {
                    "mode": "queued",
                    "job_id": "job-123",
                    "status": "pending",
                    "message": "accepted",
                }

                # Call embed(texts=["test"], wait=False) to get job_id
                result = await client.embed(texts=["test"], wait=False)
                job_id_str = result["job_id"]

            # Extract job_id from result (should be JobId type)
            job_id = JobId(job_id_str)

            # Mock wait_for_job_via_websocket to return result with WebSocket correlation identifier
            websocket_correlation_id = "ws-delivery-1"
            final_result = {
                "results": [
                    {
                        "body": "test",
                        "embedding": [0.1, 0.2, 0.3],
                        "tokens": [1, 2, 3],
                        "bm25_tokens": [4, 5, 6],
                    }
                ],
                "embeddings": [[0.1, 0.2, 0.3]],
                "model": "test-model",
                "dimension": 768,
                "device": "cpu",
            }
            with patch.object(
                client._adapter_transport,
                "wait_for_job_via_websocket",
                new_callable=AsyncMock,
            ) as mock_ws:
                mock_ws.return_value = {
                    "event": "job_completed",
                    "job_id": "job-123",
                    "result": final_result,
                    "correlation_id": websocket_correlation_id,
                }

                # Call wait_for_job_via_websocket(job_id) and capture result
                final = await client.wait_for_job_via_websocket(job_id)

                # Extract WebSocket correlation identifier from result or adapter response (if exposed)
                # Note: The correlation_id may be in the raw payload, but the normalized result
                # should not mix it with business data
                call_args = mock_ws.call_args
                called_job_id = call_args[0][0]

                # Assert job_id is NOT equal to WebSocket correlation identifier
                assert job_id_str != websocket_correlation_id
                assert str(job_id) != websocket_correlation_id

                # Assert job_id is of type JobId (if using identifier_types.JobId)
                assert isinstance(
                    job_id, str
                )  # JobId is NewType(str), so isinstance check works
                assert job_id == JobId(job_id_str)

                # Assert job_id is used for WebSocket subscription/waiting (not correlation id)
                assert called_job_id == job_id_str or called_job_id == job_id

                # Assert result contains final business payload (not correlation identifier as business data)
                assert isinstance(final, dict)
                assert "results" in final or "embeddings" in final
                assert "model" in final
                assert "dimension" in final
                assert "device" in final
                # Correlation identifier should not be in business payload
                assert (
                    "correlation_id" not in final
                    or final.get("correlation_id") != websocket_correlation_id
                )
        finally:
            await client.__aexit__(None, None, None)
