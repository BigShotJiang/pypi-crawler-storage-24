"""
Tests for immediate JSON-RPC result mode validation.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import pytest
from typing import Dict, Any
from unittest.mock import AsyncMock, MagicMock

from embed_client.adapter_transport import AdapterTransport


@pytest.fixture
def mock_immediate_result() -> Dict[str, Any]:
    """
    Return mock immediate result from server.

    Returns:
        Dictionary representing immediate result from server.
    """
    return {
        "results": [
            {
                "body": "test text",
                "embedding": [0.1, 0.2, 0.3],
                "tokens": ["test", "text"],
                "bm25_tokens": ["test", "text"],
            }
        ],
        "embeddings": [[0.1, 0.2, 0.3]],
        "model": "test-model",
        "dimension": 768,
        "device": "cpu",
    }


@pytest.fixture
def mock_adapter_transport_immediate(
    mock_immediate_result: Dict[str, Any],
) -> AsyncMock:
    """
    Return mocked AdapterTransport that returns immediate results.

    Args:
        mock_immediate_result: Mock immediate result data.

    Returns:
        Mocked AdapterTransport that returns immediate results.
    """
    mock_transport = MagicMock(spec=AdapterTransport)
    # Set up mock for execute_command_unified: return immediate response
    # Structure matches adapter response: {"mode": "immediate", "result": {"success": True, "data": {...}}}
    mock_transport.execute_command_unified = AsyncMock(
        return_value={
            "mode": "immediate",
            "result": {
                "success": True,
                "data": mock_immediate_result,
            },
        }
    )
    return mock_transport


class TestEmbedImmediateMode:
    """Test immediate JSON-RPC result mode."""

    @pytest.mark.asyncio
    async def test_immediate_result_detection(
        self, mock_adapter_transport_immediate: AsyncMock
    ) -> None:
        """
        Verify immediate result is detected correctly (no job_id in response).

        Algorithm:
        1. Create mock adapter transport that returns immediate result (no job_id)
        2. Create EmbeddingServiceAsyncClient with mocked transport
        3. Call embed(texts=["test text"], wait=True) or embed(texts=["test text"])
        4. Assert result does not contain "job_id" key at any level
        5. Assert result contains final business payload (either "results" or "embeddings" key)
        6. Assert result structure indicates immediate mode (no queue-related fields)
        """
        # Create mock client instance that uses mock_transport
        client = MagicMock()
        client._adapter_transport = mock_adapter_transport_immediate
        client.config_dict = {}
        client.config = None

        # Import the mixin to get the embed method
        from embed_client.async_client_api_mixin import AsyncClientAPIMixin

        client.embed = AsyncClientAPIMixin.embed.__get__(client, AsyncClientAPIMixin)

        # Call embed method
        result = await client.embed(texts=["test text"], wait=True)

        # Assert result does not contain "job_id" key at any level
        assert "job_id" not in result
        if isinstance(result.get("result"), dict):
            assert "job_id" not in result.get("result", {})
        if isinstance(result.get("result", {}).get("data"), dict):
            assert "job_id" not in result.get("result", {}).get("data", {})
        if isinstance(result.get("data"), dict):
            assert "job_id" not in result.get("data", {})

        # Assert result contains final business payload
        assert "results" in result or "embeddings" in result

        # Assert result structure indicates immediate mode (no queue-related fields)
        assert "status" not in result or result.get("status") != "pending"

    @pytest.mark.asyncio
    async def test_immediate_result_normalization(
        self, mock_adapter_transport_immediate: AsyncMock
    ) -> None:
        """
        Verify result normalization matches server contract.

        Algorithm:
        1. Create mock adapter transport that returns immediate result with server contract structure
        2. Create EmbeddingServiceAsyncClient with mocked transport
        3. Call embed(texts=["test text 1", "test text 2"], model="test-model", dimension=768, device="cpu")
        4. Extract result from embed() call
        5. Assert result contains "results" list OR "embeddings" list (at least one)
        6. If "results" present: assert each result item contains expected fields (body, embedding, tokens, bm25_tokens)
        7. If "embeddings" present: assert embeddings is a list of lists (or list of arrays)
        8. Assert result contains "model" field matching input model
        9. Assert result contains "dimension" field matching input dimension
        10. Assert result contains "device" field matching input device
        """
        # Create mock client instance that uses mock_transport
        client = MagicMock()
        client._adapter_transport = mock_adapter_transport_immediate
        client.config_dict = {}
        client.config = None

        # Import the mixin to get the embed method
        from embed_client.async_client_api_mixin import AsyncClientAPIMixin

        client.embed = AsyncClientAPIMixin.embed.__get__(client, AsyncClientAPIMixin)

        # Call embed method with multiple texts and parameters
        result = await client.embed(
            texts=["test text 1", "test text 2"],
            model="test-model",
            dimension=768,
            device="cpu",
        )

        # Assert result contains "results" list OR "embeddings" list (at least one)
        assert "results" in result or "embeddings" in result

        # If "results" present: assert each result item contains expected fields
        if "results" in result:
            assert isinstance(result["results"], list)
            for result_item in result["results"]:
                assert isinstance(result_item, dict)
                assert "body" in result_item
                assert "embedding" in result_item
                assert "tokens" in result_item
                assert "bm25_tokens" in result_item

        # If "embeddings" present: assert embeddings is a list of lists
        if "embeddings" in result:
            assert isinstance(result["embeddings"], list)
            for embedding in result["embeddings"]:
                assert isinstance(embedding, list)

        # Assert result contains "model" field matching input model
        assert "model" in result
        assert result["model"] == "test-model"

        # Assert result contains "dimension" field matching input dimension
        assert "dimension" in result
        assert result["dimension"] == 768

        # Assert result contains "device" field matching input device
        assert "device" in result
        assert result["device"] == "cpu"

    @pytest.mark.asyncio
    async def test_immediate_result_structure(
        self, mock_adapter_transport_immediate: AsyncMock
    ) -> None:
        """
        Verify result structure matches server contract exactly.

        Algorithm:
        1. Create mock adapter transport that returns immediate result matching server contract
        2. Create EmbeddingServiceAsyncClient with mocked transport
        3. Call embed(texts=["test"]) with wait=True or default
        4. Extract result
        5. Assert result is a dictionary
        6. Assert result does NOT contain "job_id" key
        7. Assert result does NOT contain "status" key (queue-related)
        8. Assert result does NOT contain "mode" key with value "queued"
        9. Assert result contains at least one of: "results", "embeddings"
        10. If "results" present: assert it is a list, assert each item is a dict
        11. If "embeddings" present: assert it is a list, assert each item is a list or array
        """
        # Create mock client instance that uses mock_transport
        client = MagicMock()
        client._adapter_transport = mock_adapter_transport_immediate
        client.config_dict = {}
        client.config = None

        # Import the mixin to get the embed method
        from embed_client.async_client_api_mixin import AsyncClientAPIMixin

        client.embed = AsyncClientAPIMixin.embed.__get__(client, AsyncClientAPIMixin)

        # Call embed method with default wait=True
        result = await client.embed(texts=["test"])

        # Assert result is a dictionary
        assert isinstance(result, dict)

        # Assert result does NOT contain "job_id" key
        assert "job_id" not in result

        # Assert result does NOT contain "status" key (queue-related)
        # Note: status might be present if it's not queue-related, but we check it's not "pending"
        if "status" in result:
            assert result["status"] != "pending"

        # Assert result does NOT contain "mode" key with value "queued"
        if "mode" in result:
            assert result["mode"] != "queued"

        # Assert result contains at least one of: "results", "embeddings"
        assert "results" in result or "embeddings" in result

        # If "results" present: assert it is a list, assert each item is a dict
        if "results" in result:
            assert isinstance(result["results"], list)
            for item in result["results"]:
                assert isinstance(item, dict)

        # If "embeddings" present: assert it is a list, assert each item is a list or array
        if "embeddings" in result:
            assert isinstance(result["embeddings"], list)
            for embedding in result["embeddings"]:
                assert isinstance(embedding, list)

    @pytest.mark.asyncio
    async def test_immediate_no_job_id(
        self, mock_adapter_transport_immediate: AsyncMock
    ) -> None:
        """
        Verify no job_id is present or invented for immediate results.

        Algorithm:
        1. Create mock adapter transport that returns immediate result (no job_id at any level)
        2. Create EmbeddingServiceAsyncClient with mocked transport
        3. Call embed(texts=["test"])
        4. Extract result
        5. Assert "job_id" not in result (top level)
        6. Assert "job_id" not in result.get("result", {}) (nested in result)
        7. Assert "job_id" not in result.get("result", {}).get("data", {}) (nested in result.data)
        8. Assert "job_id" not in result.get("data", {}) (top-level data)
        9. Assert result contains final business payload (embeddings or results)
        """
        # Create mock client instance that uses mock_transport
        client = MagicMock()
        client._adapter_transport = mock_adapter_transport_immediate
        client.config_dict = {}
        client.config = None

        # Import the mixin to get the embed method
        from embed_client.async_client_api_mixin import AsyncClientAPIMixin

        client.embed = AsyncClientAPIMixin.embed.__get__(client, AsyncClientAPIMixin)

        # Call embed method
        result = await client.embed(texts=["test"])

        # Assert "job_id" not in result (top level)
        assert "job_id" not in result

        # Assert "job_id" not in result.get("result", {}) (nested in result)
        if isinstance(result.get("result"), dict):
            assert "job_id" not in result.get("result", {})

        # Assert "job_id" not in result.get("result", {}).get("data", {}) (nested in result.data)
        if isinstance(result.get("result", {}).get("data"), dict):
            assert "job_id" not in result.get("result", {}).get("data", {})

        # Assert "job_id" not in result.get("data", {}) (top-level data)
        if isinstance(result.get("data"), dict):
            assert "job_id" not in result.get("data", {})

        # Assert result contains final business payload (embeddings or results)
        assert "results" in result or "embeddings" in result
