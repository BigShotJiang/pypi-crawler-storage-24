"""
Tests for identifier extraction functions and type system.

Tests extraction of job_id and deliver_id from various response formats,
edge cases (missing, empty, whitespace), and identifier type validation.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import Dict, Any

from embed_client.async_client_api_mixin import (
    _extract_job_id_from_response,
    _extract_deliver_id_from_response,
)
from embed_client.identifier_types import (
    JobId,
    DeliverId,
    is_valid_job_id,
    is_valid_deliver_id,
)


class TestJobIdExtraction:
    """Test class for _extract_job_id_from_response() function."""

    def test_extract_job_id_from_top_level(self) -> None:
        """Test extraction from top-level job_id field."""
        result: Dict[str, Any] = {"job_id": "queue-123", "status": "pending"}
        extracted = _extract_job_id_from_response(result)
        assert extracted is not None
        assert extracted == JobId("queue-123")
        assert str(extracted) == "queue-123"

    def test_extract_job_id_from_nested_result(self) -> None:
        """Test extraction from nested result.job_id field."""
        result: Dict[str, Any] = {"result": {"job_id": "queue-456"}, "mode": "queued"}
        extracted = _extract_job_id_from_response(result)
        assert extracted is not None
        assert extracted == JobId("queue-456")
        assert str(extracted) == "queue-456"

    def test_extract_job_id_from_nested_data(self) -> None:
        """Test extraction from nested result.data.job_id field."""
        result: Dict[str, Any] = {
            "result": {"data": {"job_id": "queue-789"}},
            "mode": "queued",
        }
        extracted = _extract_job_id_from_response(result)
        assert extracted is not None
        assert extracted == JobId("queue-789")
        assert str(extracted) == "queue-789"

    def test_extract_job_id_from_data(self) -> None:
        """Test extraction from top-level data.job_id field."""
        result: Dict[str, Any] = {"data": {"job_id": "queue-abc"}, "status": "pending"}
        extracted = _extract_job_id_from_response(result)
        assert extracted is not None
        assert extracted == JobId("queue-abc")
        assert str(extracted) == "queue-abc"

    def test_extract_job_id_returns_none_when_missing(self) -> None:
        """Test that extraction returns None when job_id is missing."""
        result: Dict[str, Any] = {"status": "pending", "mode": "queued"}
        extracted = _extract_job_id_from_response(result)
        assert extracted is None

    def test_extract_job_id_strips_whitespace(self) -> None:
        """Test that extraction strips whitespace from job_id."""
        result: Dict[str, Any] = {"job_id": "  queue-123  ", "status": "pending"}
        extracted = _extract_job_id_from_response(result)
        assert extracted is not None
        assert extracted == JobId("queue-123")
        assert str(extracted) == "queue-123"
        assert str(extracted).strip() == str(extracted)

    def test_extract_job_id_returns_none_for_empty_string(self) -> None:
        """Test that empty string or whitespace-only string returns None."""
        result_empty: Dict[str, Any] = {"job_id": "", "status": "pending"}
        extracted_empty = _extract_job_id_from_response(result_empty)
        assert extracted_empty is None

        result_whitespace: Dict[str, Any] = {"job_id": "   ", "status": "pending"}
        extracted_whitespace = _extract_job_id_from_response(result_whitespace)
        assert extracted_whitespace is None


class TestDeliverIdExtraction:
    """Test class for _extract_deliver_id_from_response() function."""

    def test_extract_deliver_id_from_top_level(self) -> None:
        """Test extraction from top-level deliver_id field."""
        result: Dict[str, Any] = {"accepted": True, "deliver_id": "deliver-abc-123"}
        extracted = _extract_deliver_id_from_response(result)
        assert extracted is not None
        assert extracted == DeliverId("deliver-abc-123")
        assert str(extracted) == "deliver-abc-123"

    def test_extract_deliver_id_from_nested_result(self) -> None:
        """Test extraction from nested result.deliver_id field."""
        result: Dict[str, Any] = {
            "result": {"deliver_id": "deliver-xyz-456"},
            "accepted": True,
        }
        extracted = _extract_deliver_id_from_response(result)
        assert extracted is not None
        assert extracted == DeliverId("deliver-xyz-456")
        assert str(extracted) == "deliver-xyz-456"

    def test_extract_deliver_id_from_nested_data(self) -> None:
        """Test extraction from nested result.data.deliver_id field."""
        result: Dict[str, Any] = {
            "result": {"data": {"deliver_id": "deliver-def-789"}},
            "accepted": True,
        }
        extracted = _extract_deliver_id_from_response(result)
        assert extracted is not None
        assert extracted == DeliverId("deliver-def-789")
        assert str(extracted) == "deliver-def-789"

    def test_extract_deliver_id_from_data(self) -> None:
        """Test extraction from top-level data.deliver_id field."""
        result: Dict[str, Any] = {
            "data": {"deliver_id": "deliver-ghi-012"},
            "accepted": True,
        }
        extracted = _extract_deliver_id_from_response(result)
        assert extracted is not None
        assert extracted == DeliverId("deliver-ghi-012")
        assert str(extracted) == "deliver-ghi-012"

    def test_extract_deliver_id_returns_none_when_missing(self) -> None:
        """Test that extraction returns None when deliver_id is missing."""
        result: Dict[str, Any] = {"accepted": True}
        extracted = _extract_deliver_id_from_response(result)
        assert extracted is None

    def test_extract_deliver_id_strips_whitespace(self) -> None:
        """Test that extraction strips whitespace from deliver_id."""
        result: Dict[str, Any] = {"deliver_id": "  deliver-123  ", "accepted": True}
        extracted = _extract_deliver_id_from_response(result)
        assert extracted is not None
        assert extracted == DeliverId("deliver-123")
        assert str(extracted) == "deliver-123"
        assert str(extracted).strip() == str(extracted)

    def test_extract_deliver_id_returns_none_for_empty_string(self) -> None:
        """Test that empty string or whitespace-only string returns None."""
        result_empty: Dict[str, Any] = {"deliver_id": "", "accepted": True}
        extracted_empty = _extract_deliver_id_from_response(result_empty)
        assert extracted_empty is None

        result_whitespace: Dict[str, Any] = {"deliver_id": "   ", "accepted": True}
        extracted_whitespace = _extract_deliver_id_from_response(result_whitespace)
        assert extracted_whitespace is None


class TestIdentifierTypes:
    """Test class for identifier type system and validation functions."""

    def test_job_id_type(self) -> None:
        """Test that JobId type is distinct from str."""
        job_id = JobId("queue-123")
        assert str(job_id) == "queue-123"
        assert len(job_id) > 0

    def test_deliver_id_type(self) -> None:
        """Test that DeliverId type is distinct from str."""
        deliver_id = DeliverId("deliver-123")
        assert str(deliver_id) == "deliver-123"
        assert len(deliver_id) > 0

    def test_job_id_and_deliver_id_are_distinct(self) -> None:
        """Test that JobId and DeliverId are distinct types."""
        job_id = JobId("queue-123")
        deliver_id = DeliverId("deliver-123")
        # At runtime, NewType types are just the underlying type (str)
        # but type checking will catch mixing them
        assert str(job_id) == "queue-123"
        assert str(deliver_id) == "deliver-123"
        # Verify they are different values
        assert job_id != deliver_id
        # Type checking would fail if trying to assign JobId to DeliverId variable
        # At runtime, both are str, but type system enforces distinction
        assert type(job_id) is type(deliver_id)  # Both are str at runtime

    def test_is_valid_job_id(self) -> None:
        """Test validation function for job_id."""
        assert is_valid_job_id("queue-123") is True
        assert is_valid_job_id("  queue-123  ") is True
        assert is_valid_job_id("") is False
        assert is_valid_job_id("   ") is False
        assert is_valid_job_id("valid-id") is True

    def test_is_valid_deliver_id(self) -> None:
        """Test validation function for deliver_id."""
        assert is_valid_deliver_id("deliver-123") is True
        assert is_valid_deliver_id("  deliver-123  ") is True
        assert is_valid_deliver_id("") is False
        assert is_valid_deliver_id("   ") is False
        assert is_valid_deliver_id("valid-id") is True
