"""
Queue and job management methods for EmbeddingServiceAsyncClient.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from mcp_proxy_adapter.client.jsonrpc_client import (  # type: ignore[import-untyped]
        BidirectionalWsChannel,
    )

from embed_client.constants import DEFAULT_POLL_INTERVAL
from embed_client.exceptions import (
    EmbeddingServiceAPIError,
    EmbeddingServiceError,
    EmbeddingServiceTimeoutError,
)
from embed_client.response_normalizer import ResponseNormalizer
from embed_client.identifier_types import JobId
from embed_client.async_client_api_mixin import _extract_job_id_from_response

# Timing logger: set to DEBUG to see wait_for_job control points
_timing_log = logging.getLogger("embed_client.timing")


class AsyncClientQueueMixin:
    """Mixin that provides queue-related operations for the async client."""

    async def wait_for_job(
        self,
        job_id: JobId,
        timeout: Optional[float] = 60.0,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
    ) -> Dict[str, Any]:
        """
        Wait for job completion and return results.

        Uses `job_id` (queue-based identifier) for status polling. This method polls
        queue status via HTTP, not WebSocket. For WebSocket waiting, use
        `wait_for_job_via_websocket()`. The `job_id` parameter must be a queue job
        identifier obtained from queue submission (e.g., from submit_job() or
        embed_queue response), not a `deliver_id` from `execute_async()`.

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission. This is distinct from `deliver_id` used by execute_async().
            timeout: Maximum time to wait in seconds.
                    If None, return immediately without waiting.
                    If 0, wait indefinitely (no timeout).
                    Default: 60.0 seconds.
            poll_interval: Time between queue status checks in seconds.
                          Default: DEFAULT_POLL_INTERVAL.

        Returns:
            Job result dictionary when job completes.

        Raises:
            EmbeddingServiceTimeoutError: If timeout is exceeded.
            EmbeddingServiceError: If job fails or status check fails.
        """
        t_start = time.perf_counter()
        poll_count = 0
        logger = logging.getLogger("EmbeddingServiceAsyncClient.wait_for_job")
        try:
            status = await self.job_status(job_id)  # type: ignore[attr-defined]
            poll_count = 1
            first_rtt = time.perf_counter() - t_start
            _timing_log.debug(
                "wait_for_job job_id=%s first_rtt_sec=%.3f poll_count=1",
                (job_id or "")[:16],
                first_rtt,
            )
            logger.debug("Initial job status: %s", status)

            # If timeout is None, return immediately without waiting
            if timeout is None:
                _timing_log.debug(
                    "wait_for_job job_id=%s done total_sec=%.3f poll_count=%s status=return_immediate",
                    (job_id or "")[:16],
                    time.perf_counter() - t_start,
                    poll_count,
                )
                return status

            # Check initial status - job might already be completed
            current_status = status.get("status", "unknown")
            if current_status in ("completed", "success", "done"):
                result = status.get("result")
                if result:
                    # Support both legacy format (result["data"]) and normalized format (result directly)
                    if isinstance(result, Dict) and "data" in result:
                        out = result["data"]
                    else:
                        out = result
                else:
                    out = status
                _timing_log.debug(
                    "wait_for_job job_id=%s done total_sec=%.3f poll_count=%s status=completed",
                    (job_id or "")[:16],
                    time.perf_counter() - t_start,
                    poll_count,
                )
                return out

            if current_status in ("failed", "error"):
                # Prefer error key, fall back to message, then default
                error = status.get("error") or status.get("message") or "Job failed"
                _timing_log.debug(
                    "wait_for_job job_id=%s done total_sec=%.3f poll_count=%s status=failed",
                    (job_id or "")[:16],
                    time.perf_counter() - t_start,
                    poll_count,
                )
                raise EmbeddingServiceAPIError({"message": str(error)})

            # If timeout is 0, wait indefinitely
            if timeout == 0:
                while True:
                    await asyncio.sleep(poll_interval)
                    poll_count += 1
                    status = await self.job_status(job_id)  # type: ignore[attr-defined]
                    current_status = status.get("status", "unknown")
                    logger.debug(
                        "Job %s status: %s, full status: %s",
                        job_id,
                        current_status,
                        status,
                    )

                    if current_status in ("completed", "success", "done"):
                        result = status.get("result")
                        if result:
                            # Support both legacy format (result["data"]) and normalized format (result directly)
                            if isinstance(result, Dict) and "data" in result:
                                out = result["data"]
                            else:
                                out = result
                        else:
                            out = status
                        _timing_log.debug(
                            "wait_for_job job_id=%s done total_sec=%.3f poll_count=%s status=completed",
                            (job_id or "")[:16],
                            time.perf_counter() - t_start,
                            poll_count,
                        )
                        return out
                    if current_status in ("failed", "error"):
                        # Prefer error key, fall back to message, then default
                        error = (
                            status.get("error") or status.get("message") or "Job failed"
                        )
                        _timing_log.debug(
                            "wait_for_job job_id=%s done total_sec=%.3f poll_count=%s status=failed",
                            (job_id or "")[:16],
                            time.perf_counter() - t_start,
                            poll_count,
                        )
                        raise EmbeddingServiceAPIError({"message": str(error)})

            # Wait with timeout
            start_time = time.time()

            while time.time() - start_time < timeout:
                await asyncio.sleep(poll_interval)
                poll_count += 1
                status = await self.job_status(job_id)  # type: ignore[attr-defined]
                current_status = status.get("status", "unknown")
                logger.debug(
                    "Job %s status: %s, full status: %s",
                    job_id,
                    current_status,
                    status,
                )

                if current_status in ("completed", "success", "done"):
                    result = status.get("result")
                    if result:
                        # Support both legacy format (result["data"]) and normalized format (result directly)
                        if isinstance(result, Dict) and "data" in result:
                            out = result["data"]
                        else:
                            out = result
                    else:
                        out = status
                    _timing_log.debug(
                        "wait_for_job job_id=%s done total_sec=%.3f poll_count=%s status=completed",
                        (job_id or "")[:16],
                        time.perf_counter() - t_start,
                        poll_count,
                    )
                    return out
                if current_status in ("failed", "error"):
                    # Prefer error key, fall back to message, then default
                    error = status.get("error") or status.get("message") or "Job failed"
                    _timing_log.debug(
                        "wait_for_job job_id=%s done total_sec=%.3f poll_count=%s status=failed",
                        (job_id or "")[:16],
                        time.perf_counter() - t_start,
                        poll_count,
                    )
                    raise EmbeddingServiceAPIError({"message": str(error)})

            _timing_log.debug(
                "wait_for_job job_id=%s done total_sec=%.3f poll_count=%s status=timeout",
                (job_id or "")[:16],
                time.perf_counter() - t_start,
                poll_count,
            )
            raise EmbeddingServiceTimeoutError(
                f"Job {job_id} did not complete within {timeout} seconds"
            )
        except (EmbeddingServiceTimeoutError, EmbeddingServiceAPIError):
            raise
        except Exception as exc:  # noqa: BLE001
            raise EmbeddingServiceError(f"Failed to wait for job: {exc}") from exc

    async def wait_for_job_via_websocket(
        self, job_id: JobId, timeout: float = 60.0
    ) -> Dict[str, Any]:
        """
        Wait for job completion via WebSocket /ws (push) instead of HTTP polling.

        Uses `job_id` (queue-based identifier) for WebSocket subscription. This method
        subscribes to WebSocket push events for a queued job. The server must expose /ws
        and job_push. Returns the same shape as wait_for_job (results, model, dimension)
        for embed jobs.

        **Identifier semantics:**
        - Uses `job_id` (queue-based identifier) for WebSocket subscription
        - This method is for queue operations only
        - For adapter-managed `execute_async` operations, the adapter handles `deliver_id`
          correlation internally via `execute_async()` callback mechanism
        - The `job_id` parameter must be a queue job identifier obtained from queue
          submission (e.g., from `submit_job()` or `embed()` with `wait=False`), not a
          `deliver_id` from `execute_async()`
        - Do not pass a `deliver_id` from `execute_async()` response to this method

        Args:
            job_id: Queue job identifier from embed submit or queue submission. Must be
                a `job_id` from queue operations, not a `deliver_id` from `execute_async()`.
            timeout: Max seconds to wait for a terminal event.

        Returns:
            Embed result data (results, model, dimension, optional device).

        Raises:
            asyncio.TimeoutError: If no terminal event within timeout.
            EmbeddingServiceAPIError: If job failed or WebSocket error.
        """
        try:
            payload = await self._adapter_transport.wait_for_job_via_websocket(  # type: ignore[attr-defined]
                job_id, timeout=timeout
            )
        except TimeoutError as e:
            raise EmbeddingServiceTimeoutError(str(e)) from e
        except RuntimeError as e:
            raise EmbeddingServiceAPIError({"message": str(e)}) from e
        ev = payload.get("event") or payload.get("type")
        if ev == "job_failed":
            err = payload.get("error", payload.get("message", "Job failed"))
            raise EmbeddingServiceAPIError({"message": str(err)})
        if ev in ("job_completed", "job_completed_success"):
            raw = payload.get("result") or payload.get("data") or payload
            if isinstance(raw, dict) and "data" in raw:
                return raw["data"]
            return raw if isinstance(raw, dict) else {}
        raise EmbeddingServiceAPIError({"message": f"Unexpected WebSocket event: {ev}"})

    def open_bidirectional_ws_channel(
        self,
        receive_timeout: float = 60.0,
        heartbeat: float = 30.0,
    ) -> "BidirectionalWsChannel":
        """
        Open adapter's bidirectional WebSocket channel to /ws (send + receive).

        Use after entering the client (async with client). Returns a context
        manager: use send_json() to send (e.g. subscribe/unsubscribe),
        receive_iter() to consume server events (job_completed, job_failed).

        Returns:
            Adapter BidirectionalWsChannel (use with async with).
        """
        return self._adapter_transport.open_bidirectional_ws_channel(  # type: ignore[attr-defined]
            receive_timeout=receive_timeout,
            heartbeat=heartbeat,
        )

    async def job_status(self, job_id: JobId) -> Dict[str, Any]:
        """
        Get job status from the queue.

        Uses `job_id` (queue-based identifier) for status lookup. The `job_id` parameter
        must be a queue job identifier obtained from queue submission (e.g., from
        submit_job() or embed_queue response), not a `deliver_id` from `execute_async()`.

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission. This is distinct from `deliver_id` used by execute_async().

        Returns:
            Normalized job status dictionary.

        Raises:
            EmbeddingServiceError: If status check fails.
        """
        try:
            status = await self._adapter_transport.queue_get_job_status(job_id)  # type: ignore[attr-defined]
            normalized = ResponseNormalizer.normalize_queue_status(status)
            logger = logging.getLogger("EmbeddingServiceAsyncClient.job_status")
            logger.debug("Raw status: %s, Normalized: %s", status, normalized)
            return normalized
        except Exception as exc:  # noqa: BLE001
            raise EmbeddingServiceError(f"Failed to get job status: {exc}") from exc

    async def cancel_command(self, job_id: JobId) -> Dict[str, Any]:
        """
        Cancel a command execution in queue.

        Uses `job_id` (queue-based identifier) to cancel and delete a queued job. The
        `job_id` parameter must be a queue job identifier obtained from queue submission
        (e.g., from submit_job() or embed_queue response), not a `deliver_id` from
        `execute_async()`.

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission. This is distinct from `deliver_id` used by execute_async().

        Returns:
            Deletion result dictionary.

        Raises:
            EmbeddingServiceError: If cancellation fails.
        """
        try:
            await self._adapter_transport.queue_stop_job(job_id)  # type: ignore[attr-defined]
            return await self._adapter_transport.queue_delete_job(job_id)  # type: ignore[attr-defined]
        except Exception as exc:  # noqa: BLE001
            raise EmbeddingServiceError(f"Failed to cancel command: {exc}") from exc

    async def list_queued_commands(
        self,
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        List commands currently in the queue.

        Returns a list of queued commands with their status. Each job in the result
        contains a `job_id` field (queue-based identifier, JobId type). These `job_id`
        values can be used with other queue polling methods (job_status(), cancel_command(),
        get_job_logs(), etc.). The `job_id` values are distinct from `deliver_id` values
        used by `execute_async()`.

        Args:
            status: Optional status filter (e.g., "pending", "running", "completed").
            limit: Optional limit on number of jobs to return.

        Returns:
            Dictionary containing:
            - data.jobs: List of job dictionaries, each containing `job_id` (JobId type)
            - data.total_count: Total number of jobs matching filter

        Raises:
            EmbeddingServiceError: If listing fails.
        """
        try:
            result = await self._adapter_transport.queue_list_jobs(  # type: ignore[attr-defined]
                status=status,
                job_type="command_execution",
            )

            if limit and "data" in result:
                jobs = result.get("data", {}).get("jobs", [])
                if len(jobs) > limit:
                    result["data"]["jobs"] = jobs[:limit]
                    result["data"]["total_count"] = limit

            return result
        except Exception as exc:  # noqa: BLE001
            raise EmbeddingServiceError(
                f"Failed to list queued commands: {exc}"
            ) from exc

    async def get_job_logs(self, job_id: JobId) -> Dict[str, Any]:
        """
        Get job logs (stdout/stderr) from the queue.

        Uses `job_id` (queue-based identifier) to retrieve job logs. The `job_id`
        parameter must be a queue job identifier obtained from queue submission
        (e.g., from submit_job() or embed_queue response), not a `deliver_id` from
        `execute_async()`.

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission. This is distinct from `deliver_id` used by execute_async().

        Returns:
            Dictionary containing job logs (stdout/stderr).

        Raises:
            EmbeddingServiceError: If log retrieval fails.
        """
        try:
            return await self._adapter_transport.queue_get_job_logs(job_id)  # type: ignore[attr-defined]
        except Exception as exc:  # noqa: BLE001
            raise EmbeddingServiceError(f"Failed to get job logs: {exc}") from exc

    async def submit_job(
        self,
        command: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Submit a job to the queue and return job ID.

        This method submits a command to the queue without waiting for completion.
        Use get_job_status_or_result() to check status or get results.

        Returns `job_id` (queue-based identifier) in the response. This `job_id` is
        distinct from `deliver_id` used by `execute_async()`. Use this `job_id` for
        queue status polling and WebSocket subscription, not for `execute_async`
        operations.

        Args:
            command: Command name to execute (e.g., "embed").
            params: Command parameters dictionary.

        Returns:
            Dictionary with job information:
            - job_id: Queue job identifier (JobId type) for status checking.
                     This is distinct from `deliver_id` used by execute_async().
            - status: Initial job status (usually "queued" or "pending")
            - mode: "queued" if job was queued, "immediate" if completed immediately

        Raises:
            EmbeddingServiceError: If job submission fails.
        """
        try:
            result = await self._adapter_transport.execute_command_unified(  # type: ignore[attr-defined]
                command=command,
                params=params or {},
                use_cmd_endpoint=False,
                auto_poll=False,
            )

            # Extract job_id from result using queue-specific extraction function
            job_id = _extract_job_id_from_response(result)

            if job_id:
                return {
                    "job_id": job_id,
                    "status": result.get("status", "queued"),
                    "mode": "queued",
                }
            else:
                # If not queued, return immediate result
                return {
                    "job_id": None,
                    "status": "completed",
                    "mode": "immediate",
                    "result": result.get("result", result),
                }
        except Exception as exc:  # noqa: BLE001
            raise EmbeddingServiceError(f"Failed to submit job: {exc}") from exc

    async def get_job_status_or_result(
        self,
        job_id: JobId,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Get job status or result if job is completed.

        Uses `job_id` (queue-based identifier) for status checking. The `job_id`
        parameter must be a queue job identifier obtained from queue submission
        (e.g., from submit_job() or embed_queue response), not a `deliver_id` from
        `execute_async()`.

        This method checks job status and returns result if job is completed.
        If timeout is specified and job is not completed, waits up to timeout seconds.

        Args:
            job_id: Queue job identifier (JobId type) from submit_job(). Must be
                   obtained from queue submission. This is distinct from `deliver_id`
                   used by execute_async().
            timeout: Optional timeout in seconds. If None, returns current status immediately.
                    If 0, waits indefinitely. If > 0, waits up to specified seconds.

        Returns:
            Dictionary with job status and result:
            - status: Job status ("queued", "pending", "running", "completed", "failed", "error")
            - result: Job result data (if completed)
            - job_id: Queue job identifier (JobId type)

        Raises:
            EmbeddingServiceTimeoutError: If timeout > 0 and job doesn't complete in time.
            EmbeddingServiceAPIError: If job fails.
            EmbeddingServiceError: If status check fails.
        """
        if timeout is None:
            # Return current status immediately (already normalized format)
            status = await self.job_status(job_id)  # type: ignore[attr-defined]
            return status
        else:
            # Wait for completion with timeout
            result = await self.wait_for_job(job_id, timeout=timeout)  # type: ignore[attr-defined]
            return {
                "status": "completed",
                "result": result,
                "job_id": job_id,
            }

    async def list_queue(
        self,
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Get list of jobs in the queue.

        This is an alias for list_queued_commands() for consistency.

        Args:
            status: Optional status filter ("queued", "running", "completed", "failed").
            limit: Optional limit on number of jobs to return.

        Returns:
            Dictionary with queue information:
            - jobs: List of job dictionaries
            - total_count: Total number of jobs (if limit is specified, may be less)

        Raises:
            EmbeddingServiceError: If queue listing fails.
        """
        return await self.list_queued_commands(status=status, limit=limit)  # type: ignore[attr-defined]


__all__ = ["AsyncClientQueueMixin"]
