"""
Adapter Transport Wrapper

This module provides a wrapper around mcp_proxy_adapter JsonRpcClient
that exposes methods needed by EmbeddingServiceAsyncClient.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import logging
import time
from typing import Any, Awaitable, Callable, Dict, Optional

from mcp_proxy_adapter.client.jsonrpc_client import (  # type: ignore[import-untyped]
    BidirectionalWsChannel,
    JsonRpcClient,
    open_bidirectional_ws_channel as adapter_open_bidirectional_ws_channel,
)

from embed_client.constants import DEFAULT_POLL_INTERVAL
from embed_client.identifier_types import JobId, DeliverId  # noqa: F401

logger = logging.getLogger(__name__)
# Timing logger: set level to DEBUG to see control-point timings
# e.g. logging.getLogger("embed_client.timing").setLevel(logging.DEBUG)
_timing_log = logging.getLogger("embed_client.timing")


class AdapterTransport:
    """
    Wrapper around JsonRpcClient that provides transport layer for EmbeddingServiceAsyncClient.

    This class encapsulates all adapter-specific logic and provides a clean interface
    that matches the expected behavior of the legacy aiohttp-based transport.
    """

    def __init__(self, adapter_params: Dict[str, Any]):
        """
        Initialize adapter transport with configuration parameters.

        Token must be provided in adapter_params if authentication is required.
        Token generation is handled by the adapter's JsonRpcClient, not by this
        transport layer.

        Args:
            adapter_params: Dictionary with protocol, host, port, token_header, token,
                          cert, key, ca, check_hostname, timeout. Token value may be
                          None if adapter handles token generation internally.
        """
        self.adapter_params = adapter_params
        self._client: Optional[JsonRpcClient] = None

    async def __aenter__(self):
        """Async context manager entry."""
        await self._ensure_client()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        """Async context manager exit."""
        await self.close()

    async def _ensure_client(self) -> JsonRpcClient:
        """
        Ensure JsonRpcClient is initialized.

        Token must be provided in adapter_params. Token generation is handled
        by the adapter's JsonRpcClient, not by this transport layer.
        """
        if self._client is None:
            token = self.adapter_params.get("token")
            token_header = self.adapter_params.get("token_header")

            self._client = JsonRpcClient(
                protocol=self.adapter_params["protocol"],
                host=self.adapter_params["host"],
                port=self.adapter_params["port"],
                token_header=token_header,
                token=token,
                cert=self.adapter_params.get("cert"),
                key=self.adapter_params.get("key"),
                ca=self.adapter_params.get("ca"),
                check_hostname=self.adapter_params.get("check_hostname", False),
            )

        return self._client

    async def close(self) -> None:
        """Close the underlying adapter client."""
        if self._client:
            await self._client.close()
            self._client = None

    async def jsonrpc_call(self, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform raw JSON-RPC call (for testing client and low-level use).

        Args:
            method: JSON-RPC method name.
            params: Method parameters.

        Returns:
            Full JSON-RPC response (result or error).
        """
        client = await self._ensure_client()
        return await client.jsonrpc_call(method, params)

    async def health(self) -> Dict[str, Any]:
        """
        Check service health.

        Returns:
            Health status dictionary
        """
        client = await self._ensure_client()
        return await client.health()

    async def get_openapi_schema(self) -> Dict[str, Any]:
        """
        Get OpenAPI schema.

        Returns:
            OpenAPI schema dictionary
        """
        client = await self._ensure_client()
        return await client.get_openapi_schema()

    async def execute_command(
        self,
        command: str,
        params: Optional[Dict[str, Any]] = None,
        use_cmd_endpoint: bool = False,
    ) -> Dict[str, Any]:
        """
        Execute a command via adapter.

        Args:
            command: Command name
            params: Command parameters
            use_cmd_endpoint: Whether to use /cmd endpoint

        Returns:
            Command execution result
        """
        client = await self._ensure_client()

        logger.info(f"Executing command via adapter: {command}, params={params}")

        if use_cmd_endpoint:
            result = await client.cmd_call(command, params or {})
        else:
            result = await client.execute_command(
                command, params, use_cmd_endpoint=False
            )

        logger.debug(f"Command result: {str(result)[:300]}")
        return result

    async def execute_async(
        self,
        command: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        on_result: Callable[[Dict[str, Any]], Any],
        timeout: float = 60.0,
    ) -> Dict[str, Any]:
        """
        Submit command for async execution; result is delivered via WebSocket callback.

        Uses adapter-managed `deliver_id` for WebSocket correlation. The adapter generates
        a `deliver_id`, subscribes to WebSocket with that `deliver_id`, sends the
        execute_async RPC, and returns immediately. When the server pushes
        job_completed/job_failed for this `deliver_id`, on_result(payload) is invoked once.

        **Identifier semantics:**
        - Uses adapter-managed `deliver_id` for WebSocket correlation (distinct from queue `job_id`)
        - The `deliver_id` is generated by the adapter and used internally for WebSocket subscription
        - The `deliver_id` is distinct from queue `job_id` and must not be confused with it
        - Response contains `deliver_id` field which is adapter-managed

        Args:
            command: Command name to execute (e.g. embed_execute).
            params: Optional command parameters.
            on_result: Callback invoked with the push message (event, result or error).
                May be sync or async.
            timeout: Max seconds to wait for push (default 60).

        Returns:
            Server response containing `accepted` and `deliver_id` fields. The `deliver_id`
            is adapter-managed and used for WebSocket correlation. Do not use this `deliver_id`
            with queue-based methods like `wait_for_job_via_websocket()`.
        """
        client = await self._ensure_client()

        # Log execute_async call for debugging
        logger.debug(
            f"Calling execute_async: command={command}, "
            f"protocol={self.adapter_params.get('protocol')}, "
            f"host={self.adapter_params.get('host')}, "
            f"port={self.adapter_params.get('port')}"
        )

        try:
            response = await client.execute_async(
                command,
                params,
                on_result=on_result,
                timeout=timeout,
            )

            # Log response for debugging
            logger.debug(
                f"execute_async response: accepted={response.get('accepted')}, "
                f"deliver_id={response.get('deliver_id', 'N/A')[:16] if response.get('deliver_id') else 'N/A'}"
            )

            # Verify response indicates acceptance
            if isinstance(response, dict) and not response.get("accepted", True):
                logger.warning(f"execute_async response indicates failure: {response}")

            return response
        except Exception as e:
            logger.error(
                f"execute_async failed: {e}",
                exc_info=True,
            )
            raise

    async def execute_command_unified(
        self,
        command: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        use_cmd_endpoint: bool = False,
        expect_queue: Optional[bool] = None,
        auto_poll: bool = True,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        timeout: Optional[float] = None,
        status_hook: Optional[Callable[[Dict[str, Any]], Awaitable[None]]] = None,
    ) -> Dict[str, Any]:
        """
        Execute command with unified queue/immediate handling.

        Delegates to adapter's execute_command_unified which handles:
        - Automatic queue detection
        - Polling with configurable delays (poll_interval)
        - Timeout handling
        - Status hooks
        - Proper endpoint selection (embed_job_status vs queue_get_job_status)

        Args:
            command: Command name
            params: Command parameters
            use_cmd_endpoint: Whether to use /cmd endpoint
            expect_queue: Force queue assumption
            auto_poll: Auto-poll queue status (default: True)
            poll_interval: Polling interval in seconds (default: 0.3)
            timeout: Overall timeout in seconds (None = no timeout, 0 = wait indefinitely)
            status_hook: Progress callback invoked after each poll

        Returns:
            Unified result with mode indicator:
            - {"mode": "immediate", "result": ...} for immediate commands
            - {"mode": "queued", "job_id": ..., "status": ..., "result": ...} for queued commands

        Raises:
            RuntimeError: If job fails or expected queue job id is missing
            TimeoutError: When polling exceeds the specified timeout
        """
        client = await self._ensure_client()

        # Delegate to adapter's built-in execute_command_unified
        t0 = time.perf_counter()
        result = await client.execute_command_unified(
            command=command,
            params=params,
            use_cmd_endpoint=use_cmd_endpoint,
            expect_queue=expect_queue,
            auto_poll=auto_poll,
            poll_interval=poll_interval,
            timeout=timeout,
            status_hook=status_hook,
        )
        elapsed = time.perf_counter() - t0
        mode = result.get("mode", "?") if isinstance(result, dict) else "?"
        _timing_log.debug(
            "execute_command_unified command=%s duration_sec=%.3f mode=%s",
            command,
            elapsed,
            mode,
        )
        return result

    async def queue_get_job_status(self, job_id: JobId) -> Dict[str, Any]:
        """
        Get queue job status.

        Uses `job_id` (queue-based identifier) for status lookup. This method is for
        queue operations only. The `job_id` parameter must be a queue job identifier
        obtained from queue submission, not a `deliver_id` from `execute_async`.

        This method uses the standard queue_get_job_status endpoint. The embed_job_status
        command is handled internally by execute_command_unified for embed_queue commands.

        This method is called when job status is checked directly (e.g., via job_status()).
        Since we don't know which command created the job, we use the standard endpoint
        to avoid MethodNotFoundError in server logs for non-embed_queue jobs.

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission (e.g., from submit_job() or embed_queue response).
                   This is distinct from `deliver_id` used by execute_async().

        Returns:
            Job status dictionary in format expected by execute_command_unified

        Raises:
            (No changes to exception handling - existing exceptions remain unchanged)
        """
        client = await self._ensure_client()
        t0 = time.perf_counter()
        result: Dict[str, Any]

        # Try embed_job_status first
        try:
            # Check if embed_job_status method exists on client
            if hasattr(client, "embed_job_status"):
                result = await client.embed_job_status(job_id)
            else:
                # Method doesn't exist, use jsonrpc_call directly
                response = await client.jsonrpc_call(
                    "embed_job_status", {"job_id": job_id}
                )
                # Check for JSON-RPC error response
                if "error" in response:
                    error = response.get("error", {})
                    error_code = error.get("code")
                    error_msg = str(error.get("message", "")).lower()
                    # Method not found error code is -32601
                    if (
                        error_code == -32601
                        or "not found" in error_msg
                        or "not available" in error_msg
                    ):
                        # Fall back to queue_get_job_status
                        result = await client.queue_get_job_status(job_id)
                    else:
                        # Other error, re-raise or return error response
                        result = response
                else:
                    result = response

            # Check if result is None or not a dict, fall back to queue_get_job_status
            if result is None or not isinstance(result, dict):
                result = await client.queue_get_job_status(job_id)
        except AttributeError:
            # Method doesn't exist on client, fall back
            result = await client.queue_get_job_status(job_id)
        except RuntimeError as e:
            # Check if error message indicates method not found
            error_msg = str(e).lower()
            if (
                "not found" in error_msg
                or "not available" in error_msg
                or "method not found" in error_msg
            ):
                # Fall back to queue_get_job_status
                result = await client.queue_get_job_status(job_id)
            else:
                # Other RuntimeError, re-raise
                raise

        # Normalize response from either endpoint
        normalized: Dict[str, Any]
        if isinstance(result, dict):
            # Check for embed_job_status format: {"result": {"success": bool, "data": {...}}}
            if "result" in result and isinstance(result["result"], dict):
                result_data = result["result"]
                # Check if it's embed_job_status format with success and data
                if result_data.get("success") is not None and "data" in result_data:
                    data = result_data["data"]
                    normalized = {
                        "job_id": data.get("job_id", job_id),
                        "status": data.get("status", "unknown"),
                        "message": data.get("message", ""),
                        "result": data.get("result"),
                        "error": data.get("error"),
                    }
                # Check if it's queue format: {"result": {"job_id": ..., "status": ...}}
                elif "job_id" in result_data or "status" in result_data:
                    normalized = {
                        "job_id": result_data.get("job_id", job_id),
                        "status": result_data.get("status", "unknown"),
                        "message": result_data.get("message", ""),
                        "result": result_data.get("result"),
                        "error": result_data.get("error"),
                    }
                else:
                    # Unknown nested structure, use result as-is but ensure required keys
                    normalized = {
                        "job_id": result_data.get("job_id", job_id),
                        "status": result_data.get("status", "unknown"),
                        "message": result_data.get("message", ""),
                        "result": result_data.get("result"),
                        "error": result_data.get("error"),
                    }
            # Check if result has direct keys at top level
            elif "job_id" in result or "status" in result:
                normalized = {
                    "job_id": result.get("job_id", job_id),
                    "status": result.get("status", "unknown"),
                    "message": result.get("message", ""),
                    "result": result.get("result"),
                    "error": result.get("error"),
                }
            else:
                # Unknown structure, create minimal normalized dict
                normalized = {
                    "job_id": job_id,
                    "status": "unknown",
                    "message": "",
                    "result": None,
                    "error": None,
                }
        else:
            # Result is not a dict, create minimal normalized dict
            normalized = {
                "job_id": job_id,
                "status": "unknown",
                "message": "",
                "result": None,
                "error": None,
            }

        elapsed = time.perf_counter() - t0
        _timing_log.debug(
            "queue_get_job_status job_id=%s duration_sec=%.3f",
            (job_id or "")[:16],
            elapsed,
        )
        return normalized

    async def queue_list_jobs(
        self,
        status: Optional[str] = None,
        job_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List queue jobs.

        Args:
            status: Filter by status
            job_type: Filter by job type

        Returns:
            List of jobs
        """
        client = await self._ensure_client()
        return await client.queue_list_jobs(status=status, job_type=job_type)

    async def queue_stop_job(self, job_id: str) -> Dict[str, Any]:
        """
        Stop a queue job.

        Args:
            job_id: Job identifier

        Returns:
            Stop operation result
        """
        client = await self._ensure_client()
        return await client.queue_stop_job(job_id)

    async def queue_delete_job(self, job_id: str) -> Dict[str, Any]:
        """
        Delete a queue job.

        Args:
            job_id: Job identifier

        Returns:
            Delete operation result
        """
        client = await self._ensure_client()
        return await client.queue_delete_job(job_id)

    async def queue_get_job_logs(self, job_id: str) -> Dict[str, Any]:
        """
        Get job logs.

        Args:
            job_id: Job identifier

        Returns:
            Job logs dictionary
        """
        client = await self._ensure_client()
        return await client.queue_get_job_logs(job_id)

    async def get_commands_list(self) -> Dict[str, Any]:
        """
        Get list of available commands.

        Returns:
            Dictionary containing list of commands
        """
        client = await self._ensure_client()
        return await client.get_commands_list()

    async def wait_for_job_via_websocket(
        self, job_id: JobId, timeout: float = 60.0
    ) -> Dict[str, Any]:
        """
        Wait for job completion via WebSocket /ws (push) instead of HTTP polling.

        Uses `job_id` (queue-based identifier) for WebSocket subscription. This method
        subscribes to WebSocket push events for a queued job. The server must expose /ws
        and job_push. Sends subscribe for `job_id` and returns when server sends
        job_completed, job_failed, or job_stopped.

        **Identifier semantics:**
        - Uses `job_id` (queue-based identifier) for WebSocket subscription
        - This method is for queue operations only
        - For `execute_async` operations, use `execute_async()` with callback instead
        - The `job_id` parameter must be a queue job identifier obtained from queue
          submission (e.g., from `submit_job()` or `embed()` with `wait=False`), not a
          `deliver_id` from `execute_async()`
        - Do not pass a `deliver_id` from `execute_async()` response to this method

        Args:
            job_id: Queue job identifier from embed submit or queue submission. Must be
                a `job_id` from queue operations, not a `deliver_id` from `execute_async()`.
            timeout: Max seconds to wait for a terminal event.

        Returns:
            Last event payload (event, job_id, result or error).

        Raises:
            asyncio.TimeoutError: If no terminal event within timeout.
            RuntimeError: On WebSocket connection or protocol errors.
        """
        client = await self._ensure_client()
        return await client.wait_for_job_via_websocket(job_id, timeout=timeout)

    def open_bidirectional_ws_channel(
        self,
        receive_timeout: float = 60.0,
        heartbeat: float = 30.0,
    ) -> BidirectionalWsChannel:
        """
        Open adapter's bidirectional WebSocket channel to /ws (send + receive).

        Call after the client is connected (e.g. inside async with client).
        Returns a context manager: use send_json() to send, receive_iter() to
        consume server events (job_completed, job_failed, etc.).

        Returns:
            Adapter BidirectionalWsChannel (use with async with).
        """
        # Client must be already ensured by caller (e.g. async with client)
        if self._client is None:
            raise RuntimeError(
                "Adapter not connected; use async with client before "
                "open_bidirectional_ws_channel"
            )
        return adapter_open_bidirectional_ws_channel(
            self._client,
            receive_timeout=receive_timeout,
            heartbeat=heartbeat,
        )
