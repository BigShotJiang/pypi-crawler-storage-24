"""
Core API methods for EmbeddingServiceAsyncClient (embed, cmd, health, etc.).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from embed_client.constants import EMBED_DEFAULT_ERROR_POLICY
from embed_client.identifier_types import DeliverId, JobId
from embed_client.exceptions import (
    EmbeddingServiceAPIError,
    EmbeddingServiceError,
    EmbeddingServiceTimeoutError,
)
from embed_client.response_normalizer import ResponseNormalizer
from embed_client.response_parsers import (
    extract_embedding_data,
    extract_embeddings,
)

# Timing logger: set to DEBUG to see cmd/embed control points
_timing_log = logging.getLogger("embed_client.timing")


def _extract_job_id_from_response(result: Dict[str, Any]) -> Optional[JobId]:
    """
    Extract job_id from server queue response.

    This function is for queue operations only. It extracts job_id from responses
    returned by queue-based commands (e.g., embed_queue, queue_get_job_status).

    DO NOT use this function for execute_async responses. For execute_async responses,
    use _extract_deliver_id_from_response() instead.

    Server returns either sync result (data.results) or queue (data.job_id).
    Adapter may wrap with mode=queued and job_id at top level or in result.data.

    Checks multiple locations in the response:
    - Top-level job_id (adapter format: {"mode": "queued", "job_id": "..."})
    - Nested in result: result.get("job_id")
    - Nested in result.data: result.get("result", {}).get("data", {}).get("job_id")
    - Top-level data: result.get("data", {}).get("job_id")

    Args:
        result: Response dictionary from server/adapter.

    Returns:
        JobId if job_id found and valid, None otherwise.
    """
    if not isinstance(result, dict):
        return None

    # Check top-level job_id
    job_id_candidate = result.get("job_id")
    if isinstance(job_id_candidate, str) and job_id_candidate.strip():
        return JobId(job_id_candidate.strip())

    # Check nested in result
    result_dict = result.get("result")
    if isinstance(result_dict, dict):
        job_id_candidate = result_dict.get("job_id")
        if isinstance(job_id_candidate, str) and job_id_candidate.strip():
            return JobId(job_id_candidate.strip())

        # Check nested in result.data
        data_dict = result_dict.get("data")
        if isinstance(data_dict, dict):
            job_id_candidate = data_dict.get("job_id")
            if isinstance(job_id_candidate, str) and job_id_candidate.strip():
                return JobId(job_id_candidate.strip())

    # Check top-level data
    data_dict = result.get("data")
    if isinstance(data_dict, dict):
        job_id_candidate = data_dict.get("job_id")
        if isinstance(job_id_candidate, str) and job_id_candidate.strip():
            return JobId(job_id_candidate.strip())

    return None


def _extract_deliver_id_from_response(result: Dict[str, Any]) -> Optional[DeliverId]:
    """
    Extract deliver_id from execute_async response.

    This function extracts deliver_id from responses returned by adapter's
    execute_async method. The deliver_id is an adapter-managed WebSocket
    delivery/correlation identifier, distinct from server job_id.

    DO NOT use _extract_job_id_from_response() for execute_async responses.
    Use this function instead.

    Args:
        result: Response dictionary from adapter execute_async.

    Returns:
        DeliverId if deliver_id found and valid, None otherwise.
    """
    if not isinstance(result, dict):
        return None
    for candidate in [
        result.get("deliver_id"),
        (result.get("result") or {}).get("deliver_id"),
        (result.get("result") or {}).get("data", {}),
        result.get("data", {}),
    ]:
        if isinstance(candidate, str) and candidate.strip():
            return DeliverId(candidate.strip())
        if isinstance(candidate, dict) and candidate.get("deliver_id"):
            d = candidate.get("deliver_id")
            if isinstance(d, str) and d.strip():
                return DeliverId(d.strip())
    return None


def _normalize_job_result_to_public_format(
    job_result: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Normalize job result from wait_for_job/wait_for_job_via_websocket to public format.

    Args:
        job_result: Result from wait_for_job or wait_for_job_via_websocket

    Returns:
        Public format: {"results": [...], "model": "...", "dimension": N, "device": "..."}
    """
    # Extract data from various nested structures
    if isinstance(job_result, Dict):
        if "data" in job_result:
            data = job_result["data"]
        elif "result" in job_result:
            data = job_result["result"]
        else:
            data = job_result
    else:
        data = {}

    # If data already has results/embeddings at top level, return it
    if isinstance(data, Dict):
        if "results" in data:
            return data
        if "embeddings" in data:
            return data
        if "data" in data:
            nested_data = data["data"]
            if isinstance(nested_data, Dict):
                if "results" in nested_data:
                    return nested_data
                if "embeddings" in nested_data:
                    return nested_data

    # Try to extract using parsers
    try:
        wrapped = {"result": {"success": True, "data": data}}
        results = extract_embedding_data(wrapped)
        # Extract model, dimension, device from data if available
        model = data.get("model") if isinstance(data, Dict) else None
        dimension = data.get("dimension") if isinstance(data, Dict) else None
        device = data.get("device") if isinstance(data, Dict) else None
        normalized: Dict[str, Any] = {"results": results}
        if model is not None:
            normalized["model"] = model
        if dimension is not None:
            normalized["dimension"] = dimension
        if device is not None:
            normalized["device"] = device
        return normalized
    except ValueError:
        try:
            embeddings = extract_embeddings(wrapped)
            normalized_emb: Dict[str, Any] = {"embeddings": embeddings}
            if isinstance(data, Dict):
                if "model" in data:
                    normalized_emb["model"] = data["model"]
                if "dimension" in data:
                    normalized_emb["dimension"] = data["dimension"]
                if "device" in data:
                    normalized_emb["device"] = data["device"]
            return normalized_emb
        except ValueError:
            return data if isinstance(data, Dict) else {"results": []}

    return {"results": []}


def _normalize_immediate_result_to_public_format(
    result: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Normalize immediate adapter result to public format.

    Args:
        result: Immediate result from execute_command_unified

    Returns:
        Public format: {"results": [...], "model": "...", "dimension": N, "device": "..."}
    """
    # Extract result from adapter response
    raw_result = (
        {"result": result.get("result", result)} if isinstance(result, Dict) else {}
    )

    # Try to extract from result.data structure
    embed_data: Optional[Dict[str, Any]] = None
    if "result" in raw_result and isinstance(raw_result["result"], Dict):
        res = raw_result["result"]
        if "data" in res and isinstance(res["data"], Dict):
            embed_data = res["data"]
        elif "data" in res and isinstance(res["data"], list):
            embed_data = {"results": res["data"]}

    # If not found, try using parsers
    if embed_data is None:
        try:
            results = extract_embedding_data(raw_result)
            embed_data = {"results": results}
        except ValueError:
            try:
                embeddings = extract_embeddings(raw_result)
                embed_data = {"embeddings": embeddings}
            except ValueError:
                embed_data = {"results": []}

    return embed_data


class AsyncClientAPIMixin:
    """Mixin that provides high-level API methods for the async client."""

    async def health(
        self,
        base_url: Optional[str] = None,
        port: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Check the health of the service.

        Args:
            base_url: Override base URL (not used with adapter).
            port: Override port (not used with adapter).
        """
        del base_url, port  # kept for backward-compatible signature
        try:
            return await self._adapter_transport.health()  # type: ignore[attr-defined]
        except Exception as exc:  # noqa: BLE001
            raise EmbeddingServiceError(f"Health check failed: {exc}") from exc

    async def get_openapi_schema(
        self,
        base_url: Optional[str] = None,
        port: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Get the OpenAPI schema of the service.

        Args:
            base_url: Override base URL (not used with adapter).
            port: Override port (not used with adapter).
        """
        del base_url, port
        try:
            return await self._adapter_transport.get_openapi_schema()  # type: ignore[attr-defined]
        except Exception as exc:  # noqa: BLE001
            raise EmbeddingServiceError(f"Failed to get OpenAPI schema: {exc}") from exc

    async def get_commands(
        self,
        base_url: Optional[str] = None,
        port: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Get the list of available commands.

        Args:
            base_url: Override base URL (not used with adapter).
            port: Override port (not used with adapter).
        """
        del base_url, port
        try:
            return await self._adapter_transport.get_commands_list()  # type: ignore[attr-defined]
        except Exception as exc:  # noqa: BLE001
            raise EmbeddingServiceError(f"Failed to get commands: {exc}") from exc

    def _validate_texts(self, texts: List[str]) -> None:
        """
        Validate input texts before sending to the API.

        Args:
            texts: List of texts to validate

        Raises:
            EmbeddingServiceAPIError: If texts are invalid
        """
        if not texts:
            raise EmbeddingServiceAPIError(
                {"code": -32602, "message": "Empty texts list provided"}
            )

        invalid_texts: List[str] = []
        for i, text in enumerate(texts):
            if not isinstance(text, str):
                invalid_texts.append(f"Text at index {i} is not a string")
                continue
            if not text or not text.strip():
                invalid_texts.append(
                    f"Text at index {i} is empty or contains only whitespace"
                )
            elif len(text.strip()) < 2:
                invalid_texts.append(
                    f"Text at index {i} is too short (minimum 2 characters)"
                )

        if invalid_texts:
            raise EmbeddingServiceAPIError(
                {
                    "code": -32602,
                    "message": "Invalid input texts",
                    "details": invalid_texts,
                }
            )

    async def cmd(
        self,
        command: str,
        params: Optional[Dict[str, Any]] = None,
        base_url: Optional[str] = None,
        port: Optional[int] = None,
        validate_texts: bool = True,
    ) -> Dict[str, Any]:
        """
        Execute a command via JSON-RPC protocol.

        Args:
            command: Command to execute (embed, models, health, help, config).
            params: Parameters for the command.
            base_url: Override base URL (not used with adapter).
            port: Override port (not used with adapter).
            validate_texts: When True, perform local validation for ``embed`` texts
                via ``_validate_texts`` before sending the request.

        Identifier Semantics:
            This method handles identifiers differently for queued vs immediate commands:

            - For queued commands: The response may contain a ``job_id`` (queue-based
              identifier) in the result. This ``job_id`` can be used with queue
              management methods (e.g., ``job_status()``, ``wait_for_job()``).

            - For immediate commands: No identifier is returned in the result. The
              command completes synchronously and returns the final result directly.

            - JSON-RPC request IDs are transport-internal and not exposed in the public
              API. The adapter transport layer manages these IDs for protocol correlation
              only.
        """
        del base_url, port
        if not command:
            raise EmbeddingServiceAPIError(
                {"code": -32602, "message": "Command is required"}
            )

        # Local validation for embed texts (legacy fail-fast behavior).
        # High-level helpers (e.g. embed()) may disable this to rely entirely
        # on server-side error_policy semantics.
        if validate_texts and command == "embed" and params and "texts" in params:
            self._validate_texts(params["texts"])

        logger = logging.getLogger("EmbeddingServiceAsyncClient.cmd")
        t0 = time.perf_counter()

        try:
            logger.info("Executing command via adapter: %s, params=%s", command, params)
            t1 = time.perf_counter()
            result = await self._adapter_transport.execute_command_unified(  # type: ignore[attr-defined]
                command=command,
                params=params,
                use_cmd_endpoint=False,
                auto_poll=True,
            )
            after_unified = time.perf_counter() - t1
            _timing_log.debug(
                "cmd command=%s after_execute_command_unified_sec=%.3f",
                command,
                after_unified,
            )

            if isinstance(result, Dict):
                mode = result.get("mode", "immediate")

                # If adapter completed the job (auto_poll=True), result is already available
                if mode == "queued" and result.get("status") == "completed":
                    nested_result = result.get("result")
                    if nested_result and isinstance(nested_result, Dict):
                        if "result" in nested_result:
                            return {"result": nested_result["result"]}
                        return {"result": nested_result}
                    return {"result": result.get("result", {})}

                if mode == "immediate":
                    return {"result": result.get("result", result)}

                if mode == "queued" and not result.get("status") == "completed":
                    job_id = (
                        result.get("job_id")
                        or result.get("result", {}).get("job_id")
                        or result.get("result", {}).get("data", {}).get("job_id")
                        or result.get("data", {}).get("job_id")
                    )
                    if job_id:
                        t_before_wait = time.perf_counter()
                        job_result = await self.wait_for_job(job_id, timeout=60.0)  # type: ignore[attr-defined]
                        wait_sec = time.perf_counter() - t_before_wait
                        _timing_log.debug(
                            "cmd command=%s wait_for_job_sec=%.3f",
                            command,
                            wait_sec,
                        )
                        if isinstance(job_result, Dict):
                            if "result" in job_result:
                                return {"result": job_result["result"]}
                            if "data" in job_result:
                                return {
                                    "result": {
                                        "success": True,
                                        "data": job_result["data"],
                                    }
                                }
                            return {"result": {"success": True, "data": job_result}}
                        return {"result": {"success": True, "data": job_result}}

            # Normalize adapter response to legacy format
            normalized = ResponseNormalizer.normalize_command_response(result)

            if "error" in normalized:
                raise EmbeddingServiceAPIError(normalized["error"])

            if "result" in normalized:
                result_data = normalized["result"]
                if isinstance(result_data, Dict) and (
                    result_data.get("success") is False or "error" in result_data
                ):
                    raise EmbeddingServiceAPIError(
                        result_data.get("error", result_data)
                    )

            _timing_log.debug(
                "cmd command=%s total_sec=%.3f",
                command,
                time.perf_counter() - t0,
            )
            return normalized
        except EmbeddingServiceAPIError:
            raise
        except Exception as exc:  # noqa: BLE001
            logger.error("Error in adapter cmd: %s", exc, exc_info=True)
            error_dict = ResponseNormalizer.extract_error_from_adapter(exc)
            raise EmbeddingServiceAPIError(
                error_dict.get("error", {"message": str(exc)})
            ) from exc

    async def models(self) -> Dict[str, Any]:
        """
        Get list of available embedding models from the service.

        Returns:
            Dictionary with "models" key containing list of model info
            (name, dimension, supported_dimensions, max_tokens, etc.).
        """
        result = await self.cmd("models")
        result_data = result.get("result", {})

        # Handle multiple response shapes
        models_list: List[Any] = []
        if isinstance(result_data, dict) and "models" in result_data:
            models_list = result_data["models"]
        elif isinstance(result_data, dict) and "data" in result_data:
            nested_data = result_data["data"]
            if isinstance(nested_data, dict) and "models" in nested_data:
                models_list = nested_data["models"]
        elif isinstance(result_data, list):
            models_list = result_data

        # Validate models_list is a list
        if not isinstance(models_list, list):
            models_list = []

        return {"models": models_list}

    async def timing_stats(
        self,
        file_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Get timing statistics from the embedding service (when timing_registration is enabled).

        Args:
            file_path: Optional path to JSONL timing file on the server.
                      If omitted, server uses config default (e.g. ./logs/embed_timings.jsonl).

        Returns:
            Dictionary with total_requests, success_count, encode_seconds, rpc_seconds,
            by_device, batch_vs_single, calculation_time_seconds, etc.

        Raises:
            ValueError: If file_path is not None and not a string.
        """
        # Validate file_path parameter
        if file_path is not None and not isinstance(file_path, str):
            raise ValueError("file_path must be a string or None")

        # Build params dict
        params: Dict[str, Any] = {}
        if file_path is not None and file_path.strip():
            params["file_path"] = file_path.strip()

        result = await self.cmd("timing_stats", params=params or None)
        result_data = result.get("result", {})

        # Handle multiple response shapes
        stats: Dict[str, Any] = {}
        if isinstance(result_data, dict) and (
            "total_requests" in result_data or "success_count" in result_data
        ):
            stats = result_data
        elif isinstance(result_data, dict) and "data" in result_data:
            nested_data = result_data["data"]
            if isinstance(nested_data, dict):
                stats = nested_data
        elif isinstance(result_data, dict):
            stats = result_data

        return stats

    async def embed(
        self,
        texts: List[str],
        *,
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        error_policy: Optional[str] = None,
        device: Optional[str] = None,
        job_id: Optional[str] = None,
        timeout: Optional[float] = None,
        wait: bool = True,
        use_push: bool = True,
        poll_interval: float = 0.3,
        # Connection override parameters
        host: Optional[str] = None,
        port: Optional[int] = None,
        protocol: Optional[str] = None,
        token: Optional[str] = None,
        cert_file: Optional[str] = None,
        key_file: Optional[str] = None,
        ca_cert_file: Optional[str] = None,
        crl_file: Optional[str] = None,
        **extra_params: Any,
    ) -> Dict[str, Any]:
        """
        High-level helper for the ``embed`` command.

        This method fully hides all intermediate status polling calls.
        If a job is queued, it automatically waits for completion (if timeout is specified).

        Returns a dictionary with the following structure:
            {
                "results": [
                    {
                        "body": str,           # Original text
                        "embedding": List[float],  # Vector embedding
                        "tokens": List[str],    # Tokenized text
                        "bm25_tokens": List[str]  # BM25 tokens for search
                    },
                    ...
                ],
                "embeddings": List[List[float]],  # Alternative format (legacy)
                "model": str,                   # Model name used
                "dimension": int,               # Embedding dimension
                "device": str                   # Device used
            }

        Args:
            texts: List of texts to vectorize.
            model: Optional model name.
            dimension: Optional expected vector dimension.
            error_policy: Error handling policy: "fail_fast" or "continue"
                    (default: "fail_fast", matches server API).
            device: Optional device: "auto", "cpu", "cuda", "cuda:0" (server-side).
            job_id: Optional custom job ID (server may ignore and generate own).
            timeout: Maximum time to wait for vectorization completion in seconds.
                    If None and wait=True, default 60s. If 0, wait indefinitely.
            wait: If True (default), wait for job completion and return results.
                    If False, return immediately with job_id only.
            use_push: If True (default) and wait=True, wait via WebSocket /ws push;
                    no HTTP polling. Set False to use polling. Requires server /ws.
            poll_interval: Seconds between status checks when use_push=False.
            host: Override server host (optional).
            port: Override server port (optional).
            protocol: Override protocol - "http", "https", or "mtls" (optional).
            token: Override authentication token (optional).
            cert_file: Override client certificate file path (optional).
            key_file: Override client key file path (optional).
            ca_cert_file: Override CA certificate file path (optional).
            crl_file: Override CRL file path (optional).
            **extra_params: Additional parameters to pass to the embed command.

        Returns:
            Dictionary with embeddings data (results, model, dimension, etc.).
            Sync and queue modes are transparent: the method always waits for
            server processing (polling when job_id is returned) and returns
            the final result. When timeout is None, defaults to 60s wait for
            queued jobs.

        Identifier Semantics:
            This method uses different identifier types depending on completion mode:

            - When ``wait=False``: If the operation is queued, the method returns a
              ``job_id`` (queue-based identifier) in the response. This ``job_id`` can
              be used with ``job_status()`` or ``wait_for_job()`` methods.

            - When ``wait=True`` and ``use_push=True``: The method uses adapter-managed
              WebSocket delivery with an internal ``deliver_id`` for correlation. The
              ``deliver_id`` is not exposed to the caller; WebSocket correlation is
              handled internally by the adapter.

            - When ``wait=True`` and ``use_push=False``: The method extracts ``job_id``
              from the server response and uses it for HTTP polling via ``wait_for_job()``.
              The ``job_id`` is a queue-based identifier.

            - The ``job_id`` parameter (if provided) is a queue job identifier suggestion;
              the server may generate its own ``job_id`` and ignore the provided value.

            - JSON-RPC request IDs are transport-internal and not exposed in the public API.

        Raises:
            EmbeddingServiceTimeoutError: If timeout > 0 and job doesn't complete in time.
            EmbeddingServiceAPIError: If vectorization or job fails.
            EmbeddingServiceError: If request fails.

        See project documentation for full contract description.
        """
        # Validate texts parameter
        if not isinstance(texts, list):
            raise ValueError("texts must be a list")
        if len(texts) == 0:
            raise ValueError("texts must be a non-empty list")
        if not all(isinstance(t, str) for t in texts):
            raise ValueError("texts must contain only strings")

        # Create temporary client with overridden settings if any override parameters are provided
        client_to_use = self
        if any(
            [host, port, protocol, token, cert_file, key_file, ca_cert_file, crl_file]
        ):
            # Import here to avoid circular dependency
            from embed_client.async_client import EmbeddingServiceAsyncClient

            # Get current config
            current_config = (
                self.config_dict
                if hasattr(self, "config_dict") and self.config_dict
                else {}
            )
            if hasattr(self, "config") and self.config:
                current_config = self.config.get_all()

            # Create new config with overrides
            new_config = current_config.copy()
            if host:
                new_config.setdefault("server", {})["host"] = host
            if port:
                new_config.setdefault("server", {})["port"] = port
            if protocol:
                new_config["protocol"] = protocol
                if protocol in ("https", "mtls"):
                    new_config.setdefault("ssl", {})["enabled"] = True
                else:
                    new_config.setdefault("ssl", {})["enabled"] = False

            if token:
                new_config.setdefault("auth", {}).setdefault("api_key", {})[
                    "key"
                ] = token
                new_config.setdefault("auth", {})["method"] = "api_key"

            if cert_file:
                new_config.setdefault("ssl", {})["cert_file"] = cert_file
                new_config.setdefault("auth", {}).setdefault("certificate", {})[
                    "cert_file"
                ] = cert_file
            if key_file:
                new_config.setdefault("ssl", {})["key_file"] = key_file
                new_config.setdefault("auth", {}).setdefault("certificate", {})[
                    "key_file"
                ] = key_file
            if ca_cert_file:
                new_config.setdefault("ssl", {})["ca_cert_file"] = ca_cert_file
                new_config.setdefault("auth", {}).setdefault("certificate", {})[
                    "ca_cert_file"
                ] = ca_cert_file
            if crl_file:
                new_config.setdefault("ssl", {})["crl_file"] = crl_file

            if timeout is not None:
                new_config.setdefault("client", {})["timeout"] = timeout

            # Create temporary client
            client_to_use = EmbeddingServiceAsyncClient(config_dict=new_config)
            await client_to_use.__aenter__()

        try:
            t_embed_start = time.perf_counter()
            params: Dict[str, Any] = {"texts": texts}
            if model is not None:
                params["model"] = model
            if dimension is not None:
                params["dimension"] = dimension
            eff_error_policy = (
                error_policy if error_policy is not None else EMBED_DEFAULT_ERROR_POLICY
            )
            params["error_policy"] = eff_error_policy
            if device is not None and device.strip():
                params["device"] = device.strip()
            if job_id is not None:
                params["job_id"] = job_id
            if extra_params:
                params.update(extra_params)

            # Single path: get response, then either wait for job_id or use immediate result.
            t_submit0 = time.perf_counter()
            result = await client_to_use._adapter_transport.execute_command_unified(  # type: ignore[attr-defined]
                command="embed",
                params=params,
                use_cmd_endpoint=False,
                auto_poll=False,
            )
            _timing_log.debug(
                "embed submit_sec=%.3f",
                time.perf_counter() - t_submit0,
            )

            # Extract job_id
            extracted_job_id = (
                _extract_job_id_from_response(result)
                if isinstance(result, Dict)
                else None
            )

            # Extract data for status/message (for queued mode)
            data = (
                (result or {}).get("result", {}).get("data", {})
                if isinstance(result, Dict)
                else {}
            )

            # Handle queued mode (wait=False)
            if not wait and extracted_job_id:
                return {
                    "job_id": extracted_job_id,
                    "status": data.get("status", "pending"),
                    "message": data.get("message", "Job queued successfully"),
                }

            # Handle queued mode (wait=True)
            wait_timeout = timeout if timeout is not None else 60.0
            if extracted_job_id and wait:
                t_wait0 = time.perf_counter()
                if use_push:
                    try:
                        job_result = await client_to_use.wait_for_job_via_websocket(  # type: ignore[attr-defined]
                            extracted_job_id, timeout=wait_timeout
                        )
                    except EmbeddingServiceTimeoutError:
                        raise
                else:
                    job_result = await client_to_use.wait_for_job(  # type: ignore[attr-defined]
                        extracted_job_id,
                        timeout=wait_timeout,
                        poll_interval=poll_interval,
                    )
                _timing_log.debug(
                    "embed wait_sec=%.3f",
                    time.perf_counter() - t_wait0,
                )

                # Extract result from job_result
                normalized_result = _normalize_job_result_to_public_format(job_result)
                _timing_log.debug(
                    "embed total_sec=%.3f",
                    time.perf_counter() - t_embed_start,
                )
                return normalized_result

            # Immediate mode: server returned full result immediately
            normalized_result = _normalize_immediate_result_to_public_format(result)
            _timing_log.debug(
                "embed total_sec=%.3f",
                time.perf_counter() - t_embed_start,
            )
            return normalized_result
        finally:
            # Clean up temporary client if it was created
            if client_to_use is not self and hasattr(client_to_use, "__aexit__"):
                await client_to_use.__aexit__(None, None, None)


__all__ = ["AsyncClientAPIMixin"]
