"""
Type definitions and validation functions for identifier types.

This module provides type-safe identifiers to distinguish between:
- JobId: Queue job identifiers from server queue operations
- DeliverId: Adapter-managed WebSocket delivery/correlation identifiers

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

from typing import NewType

JobId = NewType("JobId", str)
DeliverId = NewType("DeliverId", str)


def is_valid_job_id(identifier: str) -> bool:
    """
    Validate that a string is a valid job_id.

    A valid job_id is a non-empty string after stripping whitespace.

    Args:
        identifier: String to validate.

    Returns:
        True if identifier is a non-empty string after stripping, False otherwise.
    """
    if not isinstance(identifier, str):
        return False
    stripped = identifier.strip()
    return len(stripped) > 0


def is_valid_deliver_id(identifier: str) -> bool:
    """
    Validate that a string is a valid deliver_id.

    A valid deliver_id is a non-empty string after stripping whitespace.

    Args:
        identifier: String to validate.

    Returns:
        True if identifier is a non-empty string after stripping, False otherwise.
    """
    if not isinstance(identifier, str):
        return False
    stripped = identifier.strip()
    return len(stripped) > 0


__all__ = ["JobId", "DeliverId", "is_valid_job_id", "is_valid_deliver_id"]
