"""
Embedding service client (adapter-based).

Thin wrapper over mcp_proxy_adapter JsonRpcClient: health, embed (with
execute_async when wait=True), job_status, models, list_commands,
wait_for_job, WebSocket channel. Uses adapter async exchange: execute_async,
wait_for_job_via_websocket, open_bidirectional_ws_channel.
Supports from_config, validate_config, generate_config.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union, cast

from embed_client.adapter_config_factory import AdapterConfigFactory
from embed_client.adapter_transport import AdapterTransport
from embed_client.constants import EMBED_DEFAULT_ERROR_POLICY
from embed_client.config_generator import ClientConfigGenerator
from embed_client.config_validator import ConfigValidator
from embed_client.exceptions import (
    EmbeddingServiceAPIError,
    EmbeddingServiceConfigError,
    EmbeddingServiceError,
    EmbeddingServiceTimeoutError,
)
from embed_client.response_parsers import extract_embedding_data, extract_embeddings
from embed_client.testing_client_helpers import (
    list_commands_via_client,
    wait_for_job_poll,
)
from embed_client.identifier_types import JobId, DeliverId  # noqa: F401

logger = logging.getLogger(__name__)


def _adapter_params(
    protocol: str = "http",
    host: str = "127.0.0.1",
    port: int = 8080,
    cert: Optional[str] = None,
    key: Optional[str] = None,
    ca: Optional[str] = None,
    check_hostname: bool = False,
    token: Optional[str] = None,
    token_header: Optional[str] = None,
    timeout: float = 120.0,
) -> Dict[str, Any]:
    """Build adapter params dict from keyword arguments."""
    return {
        "protocol": protocol,
        "host": host,
        "port": port,
        "cert": cert,
        "key": key,
        "ca": ca,
        "check_hostname": check_hostname,
        "token": token,
        "token_header": token_header or ("X-API-Key" if token else None),
        "timeout": timeout,
    }


class EmbeddingServiceClient:
    """
    Client for embedding service API (adapter-based).

    Uses JsonRpcClient via AdapterTransport; supports embed with wait=True
    via execute_async (WebSocket push), job_status, models, list_commands,
    wait_for_job (poll or WS). from_config, validate_config, generate_config.
    """

    def __init__(
        self,
        protocol: str = "http",
        host: str = "127.0.0.1",
        port: int = 8080,
        cert: Optional[str] = None,
        key: Optional[str] = None,
        ca: Optional[str] = None,
        check_hostname: bool = False,
        token: Optional[str] = None,
        token_header: Optional[str] = None,
        timeout: float = 120.0,
    ) -> None:
        """
        Initialize embedding service client.

        Args:
            protocol: Transport protocol (http, https, mtls).
            host: Server hostname.
            port: Server port.
            cert: Path to client certificate file (mTLS).
            key: Path to client private key file (mTLS).
            ca: Path to CA certificate file (mTLS).
            check_hostname: Whether to verify hostname in SSL.
            token: Authentication token.
            token_header: Header name for token (default X-API-Key if token set).
            timeout: Request/timeout in seconds.
        """
        self._transport = AdapterTransport(
            _adapter_params(
                protocol=protocol,
                host=host,
                port=port,
                cert=cert,
                key=key,
                ca=ca,
                check_hostname=check_hostname,
                token=token,
                token_header=token_header,
                timeout=timeout,
            )
        )
        self.protocol = protocol
        self.host = host
        self.port = port

    @classmethod
    def validate_config(
        cls, config: Union[str, Path, Dict[str, Any]]
    ) -> Tuple[bool, List[str]]:
        """
        Validate configuration file or dictionary (adapter-based validator).

        Returns:
            (is_valid, list of error messages).
        """
        validator = ConfigValidator()
        if isinstance(config, (str, Path)):
            path = Path(config)
            if not path.exists():
                return False, [f"Config file not found: {path}"]
            ok, _msg, errs = validator.validate_config_file(path)
            return ok, errs
        if isinstance(config, dict):
            return validator.validate_config_dict(config)
        return False, ["config must be path (str|Path) or dict"]

    @classmethod
    def generate_config(
        cls,
        mode: str,
        host: str = "localhost",
        port: int = 8001,
        output_path: Optional[Path] = None,
        cert_file: Optional[str] = None,
        key_file: Optional[str] = None,
        ca_cert_file: Optional[str] = None,
        crl_file: Optional[str] = None,
        token: Optional[str] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Generate client configuration (adapter-based generator).

        Modes: http, http_token, http_token_roles, https, https_token,
        https_token_roles, mtls, mtls_roles.
        """
        gen = ClientConfigGenerator()
        common_http: Dict[str, Any] = {
            "host": host,
            "port": port,
            "output_path": output_path,
            "crl_file": crl_file,
            "token": token,
            **kwargs,
        }
        common_ssl: Dict[str, Any] = {
            **common_http,
            "cert_file": cert_file,
            "key_file": key_file,
            "ca_cert_file": ca_cert_file,
        }
        if mode == "http":
            return gen.generate_http_config(**common_http)
        if mode == "http_token":
            return gen.generate_http_token_config(**common_http)
        if mode == "http_token_roles":
            return gen.generate_http_token_roles_config(**common_http)
        if mode == "https":
            return gen.generate_https_config(**common_ssl)
        if mode == "https_token":
            return gen.generate_https_token_config(**common_ssl)
        if mode == "https_token_roles":
            return gen.generate_https_token_roles_config(**common_ssl)
        if mode == "mtls":
            return gen.generate_mtls_config(**common_ssl)
        if mode == "mtls_roles":
            return gen.generate_mtls_roles_config(**common_ssl)
        raise ValueError(
            f"Unknown mode: {mode}. Use one of: http, http_token, http_token_roles, "
            "https, https_token, https_token_roles, mtls, mtls_roles"
        )

    @classmethod
    def from_config(
        cls,
        config: Union[str, Path, Dict[str, Any]],
        validate: bool = True,
    ) -> "EmbeddingServiceClient":
        """
        Create client from config file path or config dictionary.

        Uses AdapterConfigFactory; supports auth.api_key.key / auth.api_key.header
        from generator output. When validate=True (default), runs adapter-based
        validator and raises EmbeddingServiceConfigError if invalid.
        """
        if isinstance(config, (str, Path)):
            path = Path(config)
            with open(path, "r", encoding="utf-8") as f:
                config_dict = cast(Dict[str, Any], json.load(f))
        elif isinstance(config, dict):
            config_dict = config
        else:
            raise TypeError("config must be path (str|Path) or dict")

        if validate:
            valid, errs = cls.validate_config(
                path if isinstance(config, (str, Path)) else config_dict
            )
            if not valid:
                raise EmbeddingServiceConfigError(
                    "Configuration validation failed: "
                    + "; ".join(errs[:5])
                    + ("..." if len(errs) > 5 else "")
                )

        params = AdapterConfigFactory.from_config_dict(config_dict)
        params.pop("_original_config", None)
        # Generator uses auth.api_key.key / .header; factory uses api_keys
        api_key = (config_dict.get("auth") or {}).get("api_key") or {}
        if api_key.get("key"):
            params["token"] = api_key["key"]
            params["token_header"] = api_key.get("header", "X-API-Key")
        kwargs = {
            k: params[k]
            for k in (
                "protocol",
                "host",
                "port",
                "cert",
                "key",
                "ca",
                "check_hostname",
                "token",
                "token_header",
                "timeout",
            )
            if k in params
        }
        return cls(**kwargs)

    async def __aenter__(self) -> "EmbeddingServiceClient":
        """Ensure transport client is created."""
        await self._transport._ensure_client()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Close transport."""
        await self._transport.close()

    async def health(self) -> Dict[str, Any]:
        """Check server health."""
        return await self._transport.health()

    async def embed(
        self,
        texts: List[str],
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        job_id: Optional[str] = None,
        error_policy: Optional[str] = None,
        device: Optional[str] = None,
        wait: bool = False,
        wait_timeout: int = 60,
        poll_interval: float = 1.0,
        use_push: bool = True,
    ) -> Dict[str, Any]:
        """
        Generate embeddings for texts (queue or execute_async when wait=True).

        When wait=True uses adapter execute_async("embed_execute", ...) and
        WebSocket push for result (no HTTP polling).

        Args:
            texts: List of texts to embed.
            model: Optional model name.
            dimension: Optional vector dimension.
            job_id: Optional custom job ID.
            error_policy: fail_fast or continue; default from server.
            device: auto, cpu, cuda, etc.; default from server.
            wait: If True, wait for completion via WebSocket.
            wait_timeout: Max wait in seconds when wait=True.
            poll_interval: Unused (kept for API compatibility).
            use_push: Unused; WS used when wait=True.

        Returns:
            If wait=False: {"job_id", "status", "message"}.
            If wait=True: {"results": [...], "model", "dimension"} (embed result shape).

        Identifier Semantics:
            This method uses different identifier types depending on the ``wait`` parameter:

            - When ``wait=False``: If the operation is queued, the method returns a
              ``job_id`` (queue-based identifier) in the response. This ``job_id`` can
              be used with ``job_status()`` or ``wait_for_job()`` methods.

            - When ``wait=True``: The method uses adapter ``execute_async()`` which
              manages an internal ``deliver_id`` for WebSocket correlation. The
              ``deliver_id`` is not exposed to the caller; WebSocket correlation is
              handled internally by the adapter.

            - The ``job_id`` parameter (if provided) is a queue job identifier suggestion;
              the server may generate its own ``job_id`` and ignore the provided value.

        Raises:
            EmbeddingServiceError: On request or job failure.
            EmbeddingServiceTimeoutError: When wait_timeout exceeded.
        """
        # Validate texts parameter
        if not isinstance(texts, list):
            raise ValueError("texts must be a list")
        if len(texts) == 0:
            raise ValueError("texts must be a non-empty list")
        if not all(isinstance(t, str) for t in texts):
            raise ValueError("texts must contain only strings")
        del poll_interval, use_push
        params: Dict[str, Any] = {"texts": texts}
        if model is not None:
            params["model"] = model
        if dimension is not None:
            params["dimension"] = dimension
        if job_id is not None:
            params["job_id"] = job_id
        if error_policy is not None:
            params["error_policy"] = error_policy
        else:
            params["error_policy"] = EMBED_DEFAULT_ERROR_POLICY
        if device is not None:
            params["device"] = device

        if wait:
            result = await self._embed_via_execute_async(params, wait_timeout)
            # Normalize result to public format
            return _normalize_result_to_public_format(result)

        # Call JSON-RPC endpoint
        response = await self._transport.jsonrpc_call("embed", params)
        if "error" in response:
            raise EmbeddingServiceError(
                f"Embedding failed: {response['error']}"
            ) from None

        result = response.get("result", {})
        if not result.get("success"):
            error = result.get("error", {})
            raise EmbeddingServiceAPIError(
                {"message": error.get("message", "Unknown error")}
            )

        data = result.get("data", {})

        # Extract job_id from multiple locations
        extracted_job_id = (
            data.get("job_id")
            or result.get("job_id")
            or (data if isinstance(data, dict) and "job_id" in data else None)
        )

        # Check if immediate result (has results/embeddings, no job_id)
        has_results = isinstance(data.get("results"), list) or isinstance(
            data.get("embeddings"), list
        )

        if not extracted_job_id and has_results:
            # Immediate mode: normalize and return
            return _normalize_result_to_public_format(data)

        if not extracted_job_id:
            raise EmbeddingServiceError(
                "No job_id or results returned from server"
            ) from None

        # Queued mode: return job metadata
        return {
            "job_id": extracted_job_id,
            "status": data.get("status") or result.get("status", "pending"),
            "message": data.get("message")
            or result.get("message", "Job queued successfully"),
        }

    async def _embed_via_execute_async(
        self, params: Dict[str, Any], timeout: int = 60
    ) -> Dict[str, Any]:
        """
        Run embed in-process via execute_async (WebSocket push).

        Uses adapter `execute_async()` which manages `deliver_id` internally for WebSocket
        correlation. The adapter generates a `deliver_id`, subscribes to WebSocket with
        that `deliver_id`, sends the execute_async RPC, and waits for server push. The
        server runs embed_execute and pushes result via WebSocket using the `deliver_id`
        for correlation.

        **Identifier semantics:**
        - Uses adapter `execute_async()` which manages `deliver_id` internally
        - The `deliver_id` is distinct from queue `job_id` and must not be confused with it
        - This method does not expose `deliver_id` to the caller (adapter handles it internally)
        - For queue operations, use `embed()` with `wait=False` and then `wait_for_job_via_websocket(job_id)`

        Returns embed result shape (results, model, dimension); raises on failure/timeout.
        """
        timeout_sec = float(timeout) if timeout > 0 else 60.0
        loop = asyncio.get_running_loop()
        fut: asyncio.Future[Dict[str, Any]] = loop.create_future()
        callback_called = False
        subscription_error: Optional[str] = None

        def on_result(event: Dict[str, Any]) -> None:
            nonlocal callback_called
            callback_called = True
            if not fut.done():
                fut.set_result(event)

        # Ensure client is ready before execute_async
        await self._transport._ensure_client()

        try:
            response = await self._transport.execute_async(
                "embed_execute",
                params,
                on_result=on_result,
                timeout=timeout_sec,
            )
            # Verify response indicates subscription succeeded
            if isinstance(response, dict) and not response.get("accepted", True):
                subscription_error = "execute_async was not accepted by server"
                logger.warning(f"execute_async response indicates failure: {response}")
        except Exception as e:
            subscription_error = str(e)
            logger.error(
                f"execute_async failed: {e}",
                exc_info=True,
            )
            if not fut.done():
                fut.set_exception(e)
            raise

        try:
            event = await asyncio.wait_for(fut, timeout=timeout_sec + 5.0)
        except asyncio.TimeoutError as e:
            error_msg = f"Embed (execute_async) did not complete within {timeout_sec}s"
            if not callback_called:
                error_msg += " (WebSocket callback was never invoked"
                if subscription_error:
                    error_msg += f"; subscription error: {subscription_error}"
                error_msg += ")"
                logger.error(
                    f"{error_msg}. This may indicate WebSocket connection issue. "
                    f"Response: {response if 'response' in locals() else 'N/A'}"
                )
            raise EmbeddingServiceTimeoutError(error_msg) from e

        ev = event.get("event") or event.get("type")
        if ev == "job_failed":
            err = event.get("error", "Unknown error")
            raise EmbeddingServiceAPIError({"message": str(err)})
        if ev not in ("job_completed", "job_completed_success"):
            raise EmbeddingServiceAPIError(
                {"message": f"Unexpected WebSocket event: {ev}"}
            )

        raw = event.get("result") or {}
        if isinstance(raw.get("data"), dict):
            return raw["data"]
        result_val = raw.get("result")
        inner = result_val if isinstance(result_val, dict) else {}
        if isinstance(inner.get("data"), dict):
            return inner["data"]
        return raw

    async def wait_for_job(
        self,
        job_id: JobId,
        timeout: int = 60,
        poll_interval: float = 1.0,
    ) -> Dict[str, Any]:
        """
        Wait for job completion by polling job_status.

        Uses `job_id` (queue-based identifier) for status polling. The `job_id` parameter
        must be a queue job identifier obtained from queue submission (e.g., from
        submit_job() or embed_queue response), not a `deliver_id` from `execute_async()`.

        This method polls job_status() repeatedly until completion. Returns embed result
        shape: results, model, dimension (optional device).

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission. This is distinct from `deliver_id` used by execute_async().
            timeout: Maximum time to wait in seconds. Default: 60.
            poll_interval: Time between status checks in seconds. Default: 1.0.

        Returns:
            Embed result dictionary with keys: results, model, dimension (optional device).

        Raises:
            EmbeddingServiceTimeoutError: If timeout is exceeded.
            EmbeddingServiceError: If job fails or status check fails.
        """
        return await wait_for_job_poll(
            self.job_status,
            job_id,
            timeout=timeout,
            poll_interval=poll_interval,
        )

    async def wait_for_job_via_websocket(
        self, job_id: JobId, timeout: int = 60
    ) -> Dict[str, Any]:
        """
        Wait for job completion via adapter WebSocket /ws (push).

        Uses `job_id` (queue-based identifier) for WebSocket subscription. This method
        subscribes to WebSocket push events for a queued job. The server must expose /ws
        and job_push. Returns embed result shape (results, model, dimension) when job completes.

        **Identifier semantics:**
        - Uses `job_id` (queue-based identifier) for WebSocket subscription
        - This method is for queue operations only
        - The `job_id` parameter must be a queue job identifier obtained from queue
          submission (e.g., from `embed()` with `wait=False`), not a `deliver_id` from
          `execute_async()` or `_embed_via_execute_async()`
        - Do not pass a `deliver_id` from `execute_async()` response to this method
        - For `execute_async` operations, use `_embed_via_execute_async()` (which uses
          `execute_async()` internally) instead

        Args:
            job_id: Queue job identifier from embed submit or queue submission. Must be
                a `job_id` from queue operations, not a `deliver_id` from `execute_async()`.
            timeout: Max seconds to wait for a terminal event.

        Returns:
            Embed result data (results, model, dimension, optional device).

        Raises:
            EmbeddingServiceTimeoutError: If timeout exceeded.
            EmbeddingServiceAPIError: If job failed or WebSocket error.
        """
        timeout_sec = float(timeout) if timeout > 0 else 60.0
        try:
            payload = await self._transport.wait_for_job_via_websocket(
                job_id, timeout=timeout_sec
            )
        except asyncio.TimeoutError as e:
            raise EmbeddingServiceTimeoutError(
                f"Job {job_id} did not complete within {timeout_sec} seconds"
            ) from e
        except RuntimeError as e:
            raise EmbeddingServiceAPIError({"message": str(e)}) from e
        ev = payload.get("event") or payload.get("type")
        if ev == "job_failed":
            err = payload.get("error", "Unknown error")
            raise EmbeddingServiceAPIError({"message": str(err)})
        if ev in ("job_completed", "job_completed_success"):
            raw = payload.get("result") or {}
            if isinstance(raw.get("data"), dict):
                return raw["data"]
            result_val = raw.get("result")
            inner = result_val if isinstance(result_val, dict) else {}
            if isinstance(inner.get("data"), dict):
                return inner["data"]
            return raw
        raise EmbeddingServiceAPIError({"message": f"Unexpected WebSocket event: {ev}"})

    def open_bidirectional_ws_channel(
        self,
        receive_timeout: float = 60.0,
        heartbeat: float = 30.0,
    ) -> Any:
        """
        Open adapter bidirectional WebSocket channel to /ws.

        Use after entering client (async with client). Returns context manager:
        send_json() to send, receive_iter() to consume events.
        """
        return self._transport.open_bidirectional_ws_channel(
            receive_timeout=receive_timeout,
            heartbeat=heartbeat,
        )

    async def job_status(self, job_id: JobId) -> Dict[str, Any]:
        """
        Get job status (queue_get_job_status or embed_job_status).

        Uses `job_id` (queue-based identifier) for status lookup. The `job_id` parameter
        must be a queue job identifier obtained from queue submission (e.g., from
        submit_job() or embed_queue response), not a `deliver_id` from `execute_async()`.

        This method first attempts to use queue_get_job_status. If that is not available,
        it falls back to embed_job_status.

        Args:
            job_id: Queue job identifier (JobId type). Must be obtained from queue
                   submission. This is distinct from `deliver_id` used by execute_async().

        Returns:
            Job status dictionary.

        Raises:
            EmbeddingServiceAPIError: If status check fails or job not found.
        """
        # Try embed_job_status first
        response = await self._transport.jsonrpc_call(
            "embed_job_status", {"job_id": job_id}
        )

        # Check for JSON-RPC error response
        if "error" in response:
            error_info = response["error"]
            error_code = (
                error_info.get("code") if isinstance(error_info, dict) else None
            )
            error_message = (
                error_info.get("message", "")
                if isinstance(error_info, dict)
                else str(error_info)
            )

            # Check if it's a method-not-found error
            is_method_not_found = (
                error_code == -32601
                or "not found" in str(error_message).lower()
                or "not available" in str(error_message).lower()
                or "method not found" in str(error_message).lower()
            )

            if is_method_not_found:
                # Fall back to queue_get_job_status
                response = await self._transport.jsonrpc_call(
                    "queue_get_job_status", {"job_id": job_id}
                )
                if "error" in response:
                    raise EmbeddingServiceAPIError(
                        {"message": str(response["error"])}
                    ) from None
            else:
                # Other errors should raise exception
                raise EmbeddingServiceAPIError(
                    {"message": str(response["error"])}
                ) from None

        # Normalize response from either endpoint
        result = response.get("result", {})
        if not isinstance(result, dict):
            # Create minimal normalized dict if result is not a dict
            return {
                "job_id": job_id,
                "status": "unknown",
                "message": "",
                "result": None,
                "error": None,
            }

        # Check if result has success/data structure (embed_job_status format)
        if result.get("success") is True and isinstance(result.get("data"), dict):
            data = result["data"]
            return {
                "job_id": data.get("job_id", job_id),
                "status": data.get("status", "unknown"),
                "message": data.get("message", ""),
                "result": data.get("result"),
                "error": data.get("error"),
            }

        # Check if result has direct keys (queue format)
        if "job_id" in result or "status" in result:
            return {
                "job_id": result.get("job_id", job_id),
                "status": result.get("status", "unknown"),
                "message": result.get("message", ""),
                "result": result.get("result"),
                "error": result.get("error"),
            }

        # Check if result.success is False
        if result.get("success") is False:
            error = result.get("error", {})
            if isinstance(error, dict):
                error_message = error.get("message", "Unknown error")
            else:
                error_message = str(error) if error else "Unknown error"
            raise EmbeddingServiceAPIError({"message": error_message})

        # Create minimal normalized dict if result structure is unexpected
        return {
            "job_id": job_id,
            "status": "unknown",
            "message": "",
            "result": None,
            "error": None,
        }

    async def models(self) -> Dict[str, Any]:
        """
        List available models from the service.

        Returns:
            Dictionary with "models" key containing list of model info
            (name, dimension, supported_dimensions, max_tokens, etc.).

        Raises:
            EmbeddingServiceAPIError: If JSON-RPC error or server returns error.
        """
        response = await self._transport.jsonrpc_call("models", {})
        if "error" in response:
            raise EmbeddingServiceAPIError(
                {"message": str(response["error"])}
            ) from None
        result = response.get("result", {})
        if isinstance(result, dict) and result.get("success") is False:
            error = result.get("error", {})
            raise EmbeddingServiceAPIError(
                {"message": error.get("message", "Unknown error")}
            )
        # Extract models list from response (handle multiple shapes)
        result_data = result.get("data", result)
        if isinstance(result_data, dict) and "models" in result_data:
            models_list = result_data["models"]
        elif isinstance(result_data, dict) and "data" in result_data:
            nested_data = result_data["data"]
            if isinstance(nested_data, dict) and "models" in nested_data:
                models_list = nested_data["models"]
            else:
                models_list = []
        elif isinstance(result_data, list):
            models_list = result_data
        else:
            models_list = []
        # Validate models_list
        if not isinstance(models_list, list):
            models_list = []
        return {"models": models_list}

    async def timing_stats(
        self,
        file_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Get timing statistics from the embedding service (when timing_registration is enabled).

        Args:
            file_path: Optional path to JSONL timing file on the server.
                      If omitted, server uses config default (e.g. ./logs/embed_timings.jsonl).

        Returns:
            Dictionary with total_requests, success_count, encode_seconds, rpc_seconds,
            by_device, batch_vs_single, calculation_time_seconds, etc.

        Raises:
            ValueError: If file_path is not None and not a string.
            EmbeddingServiceAPIError: If JSON-RPC error or server returns error.
        """
        # Validate file_path parameter
        if file_path is not None and not isinstance(file_path, str):
            raise ValueError("file_path must be a string or None")
        # Build params dict
        if file_path is not None and file_path.strip():
            params = {"file_path": file_path.strip()}
        else:
            params = {}
        # Call JSON-RPC
        response = await self._transport.jsonrpc_call("timing_stats", params)
        if "error" in response:
            raise EmbeddingServiceAPIError(
                {"message": str(response["error"])}
            ) from None
        result = response.get("result", {})
        if isinstance(result, dict) and result.get("success") is False:
            error = result.get("error", {})
            raise EmbeddingServiceAPIError(
                {"message": error.get("message", "Unknown error")}
            )
        # Extract timing stats from response (handle multiple shapes)
        result_data = result.get("data", result)
        if isinstance(result_data, dict) and (
            "total_requests" in result_data or "success_count" in result_data
        ):
            stats = result_data
        elif isinstance(result_data, dict) and "data" in result_data:
            nested_data = result_data["data"]
            if isinstance(nested_data, dict):
                stats = nested_data
            else:
                stats = {}
        elif isinstance(result_data, dict):
            stats = result_data
        else:
            stats = {}
        return stats

    async def list_commands(self) -> Dict[str, Any]:
        """List available commands (list/help/commands via JSON-RPC)."""
        return await list_commands_via_client(self._transport.jsonrpc_call)

    def __repr__(self) -> str:
        return f"EmbeddingServiceClient({self.protocol}://{self.host}:{self.port})"


def _normalize_result_to_public_format(result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize embed result to public format.

    Args:
        result: Result from _embed_via_execute_async or immediate jsonrpc_call response

    Returns:
        Public format: {"results": [...], "model": "...", "dimension": N, "device": "..."}
    """
    if not isinstance(result, Dict):
        return {"results": []}

    # If already in public format (has results or embeddings at top level)
    if "results" in result:
        return result
    if "embeddings" in result:
        return result

    # Try to extract from nested structures
    data = result.get("data", result)
    if isinstance(data, Dict):
        if "results" in data:
            return data
        if "embeddings" in data:
            return data
        if "data" in data:
            nested_data = data["data"]
            if isinstance(nested_data, Dict):
                if "results" in nested_data:
                    return nested_data
                if "embeddings" in nested_data:
                    return nested_data

    # Try using parsers
    wrapped = {"result": {"success": True, "data": result}}
    try:
        results = extract_embedding_data(wrapped)
        normalized_result: Dict[str, Any] = {"results": results}
        # Extract model, dimension, device if available
        if isinstance(result, Dict):
            if "model" in result:
                normalized_result["model"] = result["model"]
            if "dimension" in result:
                normalized_result["dimension"] = result["dimension"]
            if "device" in result:
                normalized_result["device"] = result["device"]
        return normalized_result
    except ValueError:
        try:
            embeddings = extract_embeddings(wrapped)
            normalized_embeddings: Dict[str, Any] = {"embeddings": embeddings}
            if isinstance(result, Dict):
                if "model" in result:
                    normalized_embeddings["model"] = result["model"]
                if "dimension" in result:
                    normalized_embeddings["dimension"] = result["dimension"]
                if "device" in result:
                    normalized_embeddings["device"] = result["device"]
            return normalized_embeddings
        except ValueError:
            return result if isinstance(result, Dict) else {"results": []}


__all__ = ["EmbeddingServiceClient"]
