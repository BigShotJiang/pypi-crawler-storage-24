"""
embed-client: Async client for Embedding Service API with comprehensive
authentication configuration, SSL/TLS, and mTLS support

All actual authentication execution is handled by mcp-proxy-adapter.
ClientAuthManager provides configuration validation only.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from embed_client.async_client import EmbeddingServiceAsyncClient
from embed_client.config import ClientConfig
from embed_client.auth import ClientAuthManager
from embed_client.ssl_manager import ClientSSLManager
from embed_client.client_factory import ClientFactory
from embed_client.config_generator import ClientConfigGenerator
from embed_client.config_validator import ConfigValidator
from embed_client.async_client_config_mixin import AsyncClientConfigMixin
from embed_client.testing_client import EmbeddingServiceClient
from embed_client.testing_client_helpers import (
    list_commands_via_client,
    wait_for_job_poll,
)

# Deprecated: use EmbeddingServiceClient (name was misleading)
TestingEmbeddingClient = EmbeddingServiceClient

__version__ = "3.1.7.25"
__all__ = [
    "EmbeddingServiceAsyncClient",
    "ClientConfig",
    "ClientAuthManager",
    "ClientSSLManager",
    "ClientFactory",
    "ClientConfigGenerator",
    "ConfigValidator",
    "AsyncClientConfigMixin",
    "EmbeddingServiceClient",
    "TestingEmbeddingClient",
    "wait_for_job_poll",
    "list_commands_via_client",
]
