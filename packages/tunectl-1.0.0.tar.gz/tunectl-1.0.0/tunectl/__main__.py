"""Allow running tunectl as a module: python -m tunectl."""

from tunectl.cli import main

if __name__ == "__main__":
    main()
