"""
SovereignShield Python SDK
~~~~~~~~~~~~~~~~~~~~~~~~~~

Official Python client for the SovereignShield API — AI Firewall as a Service.

Usage:
    from sovereign_shield import SovereignShield

    shield = SovereignShield(api_key="ss_your_key")
    result = shield.scan("user input here")

    if result.allowed:
        response = your_llm.generate(result.clean_input)

Copyright (c) 2026 Mattijs Moens. All rights reserved.
"""

from sovereign_shield_client.client import SovereignShield
from sovereign_shield_client.models import ScanResult, UsageInfo, ReportResult
from sovereign_shield_client.exceptions import (
    SovereignShieldError,
    AuthenticationError,
    RateLimitError,
    QuotaExceededError,
    ValidationError,
    ServerError,
)

__version__ = "1.0.0"

__all__ = [
    "SovereignShield",
    "ScanResult",
    "UsageInfo",
    "ReportResult",
    "SovereignShieldError",
    "AuthenticationError",
    "RateLimitError",
    "QuotaExceededError",
    "ValidationError",
    "ServerError",
]
