"""
Response models for the SovereignShield SDK.
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any


@dataclass(frozen=True)
class ScanResult:
    """Result of a security scan.

    Attributes:
        allowed: Whether the input passed all security checks.
        stage: The security layer that made the decision.
        reason: Explanation for the allow/block decision.
        clean_input: Sanitized input (only present if allowed).
        scan_id: Unique identifier for audit trails.
        latency_ms: Processing time in milliseconds.
    """
    allowed: bool
    stage: str
    reason: str
    clean_input: Optional[str]
    scan_id: str
    latency_ms: float

    def __bool__(self) -> bool:
        """ScanResult is truthy if the input was allowed."""
        return self.allowed


@dataclass(frozen=True)
class UsageInfo:
    """Account usage information.

    Attributes:
        tier: Account tier (free, pro, enterprise).
        scans_today: Number of scans used today.
        scans_this_month: Number of scans used this month.
        monthly_limit: Total scans allowed per month.
        remaining: Scans remaining this month.
    """
    tier: str
    scans_today: int
    scans_this_month: int
    monthly_limit: int
    remaining: int


@dataclass(frozen=True)
class ReportResult:
    """Result of a false-negative report.

    Attributes:
        report_id: Unique report identifier.
        status: Processing result.
        rule_created: Whether a new filter rule was auto-deployed.
        sandbox_result: Sandbox replay test results (if applicable).
        message: Human-readable status message.
    """
    report_id: str
    status: str
    rule_created: bool
    sandbox_result: Optional[Dict[str, Any]]
    message: str
