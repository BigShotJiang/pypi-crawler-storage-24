"""
Exceptions for the SovereignShield SDK.
"""


class SovereignShieldError(Exception):
    """Base exception for all SovereignShield API errors."""

    def __init__(self, message: str, status_code: int = None):
        self.status_code = status_code
        super().__init__(message)


class AuthenticationError(SovereignShieldError):
    """Raised when the API key is invalid or missing."""
    pass


class RateLimitError(SovereignShieldError):
    """Raised when the per-minute rate limit is exceeded."""

    def __init__(self, message: str, retry_after: float = None):
        self.retry_after = retry_after
        super().__init__(message, status_code=429)


class QuotaExceededError(SovereignShieldError):
    """Raised when the monthly scan quota is exceeded."""
    pass


class ValidationError(SovereignShieldError):
    """Raised when the request payload is invalid."""
    pass


class ServerError(SovereignShieldError):
    """Raised on unexpected server-side errors."""
    pass
