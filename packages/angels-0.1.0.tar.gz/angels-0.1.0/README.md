# angels

数据分析过程工具整合包，包含数据获取、数据清洗、逻辑加工、分析算法、可视化等五个核心模块。

## 安装

```bash
pip install angels
```

## 打包说明

本项目使用现代的 `pyproject.toml` 打包方式，替代了传统的 `setup.py`。

## 核心模块

### 1. 数据获取 (data_acquisition)

- `load_csv(file_path)`: 加载CSV文件
- `load_excel(file_path, sheet_name=0)`: 加载Excel文件
- `load_json(file_path)`: 加载JSON文件
- `load_from_api(url, params=None)`: 从API获取数据
- `load_from_web(url, table_selector)`: 从网页表格获取数据

### 2. 数据清洗 (data_cleaning)

- `remove_duplicates(df)`: 移除重复行
- `handle_missing_values(df, strategy='drop', fill_value=None)`: 处理缺失值
- `convert_data_types(df, dtypes=None)`: 转换数据类型
- `remove_outliers(df, columns=None, method='iqr', threshold=1.5)`: 移除异常值
- `standardize_columns(df)`: 标准化列名

### 3. 逻辑加工 (logic_processing)

- `group_by_aggregate(df, group_by, aggregations)`: 按列分组并聚合
- `pivot_table(df, index, columns, values, aggfunc='mean')`: 创建透视表
- `calculate_rolling_stats(df, column, window, stats=['mean', 'std'])`: 计算滚动统计量
- `calculate_diff(df, column, periods=1)`: 计算差值
- `merge_dataframes(df1, df2, on=None, how='inner')`: 合并数据框
- `create_features(df)`: 创建特征

### 4. 分析算法 (analysis_algorithms)

- `descriptive_statistics(df)`: 计算描述性统计量
- `correlation_analysis(df, method='pearson')`: 计算相关性矩阵
- `kmeans_clustering(df, n_clusters=3, random_state=42)`: K均值聚类
- `linear_regression(X, y)`: 线性回归
- `time_series_analysis(df, time_column, value_column)`: 时间序列分析
- `hypothesis_testing(sample1, sample2)`: 假设检验

### 5. 可视化 (visualization)

- `plot_histogram(df, column, bins=30, title=None)`: 绘制直方图
- `plot_scatter(df, x, y, hue=None, title=None)`: 绘制散点图
- `plot_bar(df, x, y, title=None)`: 绘制柱状图
- `plot_box(df, x, y=None, title=None)`: 绘制箱线图
- `plot_correlation_heatmap(df, title=None)`: 绘制相关性热图
- `plot_time_series(df, x, y, title=None)`: 绘制时间序列图

## 使用示例

```python
from angels import *

# 1. 数据获取
df = load_csv('data.csv')

# 2. 数据清洗
df = remove_duplicates(df)
df = handle_missing_values(df, strategy='mean')
df = standardize_columns(df)

# 3. 逻辑加工
df = group_by_aggregate(df, 'category', {'value': 'sum'})

# 4. 分析算法
stats = descriptive_statistics(df)
corr = correlation_analysis(df)

# 5. 可视化
plt = plot_histogram(df, 'value')
plt.show()

plt = plot_correlation_heatmap(df)
plt.show()
```

## 依赖

- pandas
- numpy
- matplotlib
- seaborn
- scikit-learn
- requests
- beautifulsoup4
