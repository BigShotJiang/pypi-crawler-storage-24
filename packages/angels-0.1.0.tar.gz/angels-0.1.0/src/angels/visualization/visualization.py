import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

def plot_histogram(df, column, bins=30, title=None):
    """绘制直方图"""
    plt.figure(figsize=(10, 6))
    sns.histplot(df[column], bins=bins, kde=True)
    plt.title(title or f'{column} 分布')
    plt.xlabel(column)
    plt.ylabel('频率')
    plt.tight_layout()
    return plt

def plot_scatter(df, x, y, hue=None, title=None):
    """绘制散点图"""
    plt.figure(figsize=(10, 6))
    sns.scatterplot(data=df, x=x, y=y, hue=hue)
    plt.title(title or f'{x} vs {y}')
    plt.tight_layout()
    return plt

def plot_bar(df, x, y, title=None):
    """绘制柱状图"""
    plt.figure(figsize=(10, 6))
    sns.barplot(data=df, x=x, y=y)
    plt.title(title or f'{y} by {x}')
    plt.xticks(rotation=45)
    plt.tight_layout()
    return plt

def plot_box(df, x, y=None, title=None):
    """绘制箱线图"""
    plt.figure(figsize=(10, 6))
    if y:
        sns.boxplot(data=df, x=x, y=y)
    else:
        sns.boxplot(data=df[x])
    plt.title(title or f'{y or x} 分布')
    plt.xticks(rotation=45)
    plt.tight_layout()
    return plt

def plot_correlation_heatmap(df, title=None):
    """绘制相关性热图"""
    plt.figure(figsize=(12, 10))
    corr = df.corr()
    sns.heatmap(corr, annot=True, cmap='coolwarm', vmin=-1, vmax=1)
    plt.title(title or '相关性矩阵')
    plt.tight_layout()
    return plt

def plot_time_series(df, x, y, title=None):
    """绘制时间序列图"""
    plt.figure(figsize=(12, 6))
    plt.plot(df[x], df[y])
    plt.title(title or f'{y} 时间序列')
    plt.xlabel('时间')
    plt.ylabel(y)
    plt.tight_layout()
    return plt
