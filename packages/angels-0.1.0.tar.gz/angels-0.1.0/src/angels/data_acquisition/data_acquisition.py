import pandas as pd
import requests
from bs4 import BeautifulSoup
import json
import pymysql
from pymysql.cursors import DictCursor
import os

def load_csv(file_path):
    """加载CSV文件"""
    return pd.read_csv(file_path)

def load_excel(file_path, sheet_name=0):
    """加载Excel文件"""
    return pd.read_excel(file_path, sheet_name=sheet_name)

def load_json(file_path):
    """加载JSON文件"""
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return pd.DataFrame(data)

def load_from_api(url, params=None):
    """从API获取数据"""
    response = requests.get(url, params=params)
    response.raise_for_status()
    return pd.DataFrame(response.json())

def load_from_web(url, table_selector):
    """从网页表格获取数据"""
    response = requests.get(url)
    response.raise_for_status()
    soup = BeautifulSoup(response.content, 'html.parser')
    table = soup.select_one(table_selector)
    return pd.read_html(str(table))[0]

def get_db_config():
    """获取数据库配置"""
    # 从环境变量获取配置文件路径，不设置默认值
    CONFIG_PATH = os.getenv('DB_INFO')
    if not CONFIG_PATH:
        # 环境变量未设置时的提示
        error_msg = "环境变量 DB_INFO 未设置。请按照以下方式配置：\n"
        error_msg += "1. 环境变量配置：\n"
        error_msg += "   - Windows (图形界面): 设置环境变量 DB_INFO 为配置文件路径\n"
        error_msg += "   - Windows (PowerShell): 执行 $env:DB_INFO='配置文件路径'\n"
        error_msg += "   - Linux/Mac: 执行 export DB_INFO=配置文件路径\n"
        raise ValueError(error_msg)
    
    try:
        # 尝试读取配置文件
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except FileNotFoundError:
        # 文件不存在时的提示
        error_msg = f"配置文件 {CONFIG_PATH} 不存在。请确保文件路径正确。\n"
        raise FileNotFoundError(error_msg)
    except PermissionError:
        # 权限不足时的提示
        raise PermissionError(f"没有权限读取配置文件 {CONFIG_PATH}")

DB_CONFIG = get_db_config()

def fetch_dataframe(sql, db_name='rpt'):
    """从数据库获取DataFrame"""
    if db_name not in DB_CONFIG:
        raise ValueError(f"未知数据库标识: {db_name}")
    # 使用配置文件中的连接信息
    conn_params = DB_CONFIG[db_name]
    conn = pymysql.connect(**conn_params)
    
    try:
        with conn.cursor(DictCursor) as cursor:
            cursor.execute(sql)
            res = cursor.fetchall()
            if res:
                df = pd.DataFrame(res)
            else:
                # 如果没有数据，返回空DataFrame
                df = pd.DataFrame()
            return df
    except Exception as e:
        raise e
    finally:
        conn.close()
