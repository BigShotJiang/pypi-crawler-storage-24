import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler

def descriptive_statistics(df):
    """计算描述性统计量"""
    return df.describe()

def correlation_analysis(df, method='pearson'):
    """计算相关性矩阵"""
    return df.corr(method=method)

def kmeans_clustering(df, n_clusters=3, random_state=42):
    """K均值聚类"""
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(df.select_dtypes(include=[np.number]))
    kmeans = KMeans(n_clusters=n_clusters, random_state=random_state)
    clusters = kmeans.fit_predict(scaled_data)
    df['cluster'] = clusters
    return df, kmeans

def linear_regression(X, y):
    """线性回归"""
    model = LinearRegression()
    model.fit(X, y)
    predictions = model.predict(X)
    return model, predictions

def time_series_analysis(df, time_column, value_column):
    """时间序列分析"""
    df[time_column] = pd.to_datetime(df[time_column])
    df = df.sort_values(time_column)
    df.set_index(time_column, inplace=True)
    
    # 计算移动平均
    df['moving_average'] = df[value_column].rolling(window=7).mean()
    # 计算同比增长
    df['year_over_year'] = df[value_column].pct_change(periods=365)
    
    return df

def hypothesis_testing(sample1, sample2):
    """假设检验"""
    from scipy import stats
    t_stat, p_value = stats.ttest_ind(sample1, sample2)
    return t_stat, p_value
