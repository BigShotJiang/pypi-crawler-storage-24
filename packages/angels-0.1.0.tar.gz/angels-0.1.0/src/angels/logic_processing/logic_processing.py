import pandas as pd
import numpy as np

def group_by_aggregate(df, group_by, aggregations):
    """按列分组并聚合"""
    return df.groupby(group_by).agg(aggregations).reset_index()

def pivot_table(df, index, columns, values, aggfunc='mean'):
    """创建透视表"""
    return pd.pivot_table(df, index=index, columns=columns, values=values, aggfunc=aggfunc)

def calculate_rolling_stats(df, column, window, stats=['mean', 'std']):
    """计算滚动统计量"""
    for stat in stats:
        if stat == 'mean':
            df[f'{column}_rolling_{window}_mean'] = df[column].rolling(window=window).mean()
        elif stat == 'std':
            df[f'{column}_rolling_{window}_std'] = df[column].rolling(window=window).std()
        elif stat == 'sum':
            df[f'{column}_rolling_{window}_sum'] = df[column].rolling(window=window).sum()
    return df

def calculate_diff(df, column, periods=1):
    """计算差值"""
    df[f'{column}_diff_{periods}'] = df[column].diff(periods=periods)
    return df

def merge_dataframes(df1, df2, on=None, how='inner'):
    """合并数据框"""
    return pd.merge(df1, df2, on=on, how=how)

def create_features(df):
    """创建特征"""
    # 示例特征创建
    for col in df.select_dtypes(include=[np.number]).columns:
        df[f'{col}_log'] = np.log(df[col] + 1)  # 对数变换
        df[f'{col}_squared'] = df[col] ** 2  # 平方
    return df
