import pandas as pd
import numpy as np

def remove_duplicates(df):
    """移除重复行"""
    return df.drop_duplicates()

def handle_missing_values(df, strategy='drop', fill_value=None):
    """处理缺失值"""
    if strategy == 'drop':
        return df.dropna()
    elif strategy == 'fill':
        return df.fillna(fill_value)
    elif strategy == 'mean':
        return df.fillna(df.mean())
    elif strategy == 'median':
        return df.fillna(df.median())
    else:
        raise ValueError("Invalid strategy. Use 'drop', 'fill', 'mean', or 'median'")

def convert_data_types(df, dtypes=None):
    """转换数据类型"""
    if dtypes:
        return df.astype(dtypes)
    else:
        return df.infer_objects()

def remove_outliers(df, columns=None, method='iqr', threshold=1.5):
    """移除异常值"""
    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns
    
    for col in columns:
        if method == 'iqr':
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - threshold * IQR
            upper_bound = Q3 + threshold * IQR
            df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]
        elif method == 'zscore':
            z_scores = np.abs((df[col] - df[col].mean()) / df[col].std())
            df = df[z_scores < threshold]
    
    return df

def standardize_columns(df):
    """标准化列名"""
    df.columns = [col.strip().lower().replace(' ', '_') for col in df.columns]
    return df
