# 🧠 Marziel AI

**Private Local Intelligence — runs entirely on your hardware.**

Marziel AI is a locally-powered AI assistant that can search the web, analyze GitHub repositories, read any URL, write code, and have intelligent conversations — all without sending a single byte to the cloud.

## Quick Install

**macOS (Apple Silicon)**
```bash
curl -fsSL https://get.marziel.ai/install.sh | bash
```

**Linux (NVIDIA GPU)**
```bash
curl -fsSL https://get.marziel.ai/install.sh | bash
```

**Windows (WSL2)**
```powershell
irm https://get.marziel.ai/install.ps1 | iex
```

The installer auto-detects your hardware and configures the optimal inference engine.

## What It Does

| Feature | Description |
|---------|-------------|
| 🧠 **AI Chat** | Conversational AI with personality, code generation, data analysis |
| 🔍 **Web Search** | Real-time internet search via DuckDuckGo |
| 🐙 **GitHub Analysis** | Paste any repo URL — get stars, languages, architecture, README |
| 🔗 **URL Analysis** | Share any link — reads, extracts, and analyzes content |
| 📊 **Data Intel** | Weather, market data, risk assessment, operations monitoring |
| 🔒 **100% Private** | Everything runs locally. Zero cloud dependency |

## Requirements

- **RAM**: 8GB minimum (16GB recommended)
- **Disk**: ~5GB for the model
- **Python**: 3.10+
- **Supported hardware**:
  - Apple Silicon (M1/M2/M3/M4) — uses MLX inference
  - NVIDIA GPU (8GB+ VRAM) — uses vLLM with CUDA
  - CPU fallback — uses llama.cpp (slower)

## Usage

```bash
cd ~/marziel-ai
./start.sh
```

Then open **http://localhost:3001**

## Architecture

```
┌─────────────────────────────────────────┐
│  Browser (localhost:3001)               │
│  ┌───────────────────────────────────┐  │
│  │  Marziel Dashboard (React)       │  │
│  │  Chat · Settings · Landing       │  │
│  └──────────────┬────────────────────┘  │
│                 │ API calls             │
│  ┌──────────────▼────────────────────┐  │
│  │  Marziel Backend (Flask:8001)    │  │
│  │  Web Search · GitHub · URL Parse │  │
│  └──────────────┬────────────────────┘  │
│                 │ LLM inference         │
│  ┌──────────────▼────────────────────┐  │
│  │  LLM Server (MLX/vLLM:8000)     │  │
│  │  Llama 3.1 8B (4-bit quantized) │  │
│  └───────────────────────────────────┘  │
│                YOUR MACHINE             │
└─────────────────────────────────────────┘
```

## License

Proprietary. All rights reserved.

---

Built with ❤️ by the Marziel team.
