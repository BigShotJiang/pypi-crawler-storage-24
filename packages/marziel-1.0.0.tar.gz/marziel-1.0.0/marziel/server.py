#!/usr/bin/env python3
"""
Marziel Server — Flask app serving API + bundled React UI.

When users run `marziel serve`, this serves:
  - / → React UI (from marziel/static/)
  - /llm/chat → LLM chat endpoint
  - /health → Health check
  - /system/status → System status
"""

import os
import json
import time
import logging
from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory

logger = logging.getLogger("marziel.server")

# ── Static files directory (bundled React build) ──
STATIC_DIR = Path(__file__).parent / "static"


def create_app():
    """Create the Flask application."""
    app = Flask(__name__, static_folder=str(STATIC_DIR), static_url_path="")

    # ── CORS ──
    @app.after_request
    def add_cors(response):
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        return response

    # ── Serve React UI ──
    @app.route("/")
    def serve_ui():
        index = STATIC_DIR / "index.html"
        if index.exists():
            return send_from_directory(str(STATIC_DIR), "index.html")
        return jsonify({
            "name": "Marziel AI",
            "status": "running",
            "message": "UI not bundled. Run 'npm run build' and copy dist/ to marziel/static/",
            "api": "/llm/chat",
        })

    @app.route("/<path:path>")
    def serve_static(path):
        """Serve static files, fallback to index.html for SPA routing."""
        file_path = STATIC_DIR / path
        if file_path.exists() and file_path.is_file():
            return send_from_directory(str(STATIC_DIR), path)
        # SPA fallback
        index = STATIC_DIR / "index.html"
        if index.exists():
            return send_from_directory(str(STATIC_DIR), "index.html")
        return jsonify({"error": "Not found"}), 404

    # ── Health ──
    @app.route("/health")
    def health():
        return jsonify({"status": "ok", "version": "1.0.0"})

    # ── System Status ──
    @app.route("/system/status")
    def system_status():
        import platform
        return jsonify({
            "status": "running",
            "version": "1.0.0",
            "platform": platform.system(),
            "arch": platform.machine(),
            "python": platform.python_version(),
        })

    # ── LLM Chat ──
    @app.route("/llm/chat", methods=["POST", "OPTIONS"])
    def llm_chat():
        if request.method == "OPTIONS":
            return "", 204

        data = request.get_json() or {}
        message = data.get("message", "")
        history = data.get("history", [])
        temperature = data.get("temperature", 0.7)
        max_tokens = data.get("maxTokens", 512)

        if not message:
            return jsonify({"error": "No message provided"}), 400

        t0 = time.monotonic()

        # Try Agent for tool-augmented response
        agent_context = ""
        try:
            from marziel.agent import get_agent
            agent = get_agent()
            result = agent.process(message)
            agent_context = result.get("context", "")
            logger.info(f"Agent: {result.get('tools_used', 0)} tools, "
                       f"{result.get('duration_ms', 0):.0f}ms")
        except Exception as e:
            logger.warning(f"Agent unavailable: {e}")

        # Try local LLM (auto-detect engine)
        response_text = None

        # 1. Try MLX/vLLM (OpenAI-compatible on port 8000)
        llm_url = os.environ.get("VLLM_URL", "http://localhost:8000")
        llm_model = os.environ.get("VLLM_MODEL", "")  # auto-detect if empty
        try:
            if not llm_model:
                llm_model = _detect_model(llm_url)
            if llm_model:
                response_text = _call_vllm(
                    llm_url, llm_model, message, history,
                    agent_context, temperature, max_tokens
                )
        except Exception as e:
            logger.warning(f"MLX/vLLM unavailable: {e}")

        # 2. Try Ollama (port 11434)
        if not response_text:
            try:
                response_text = _call_ollama(
                    message, history, agent_context, temperature, max_tokens
                )
            except Exception as e:
                logger.warning(f"Ollama unavailable: {e}")

        # 3. Fallback — use agent context if available
        if not response_text:
            response_text = _fallback_response(message, agent_context)

        duration = (time.monotonic() - t0) * 1000
        return jsonify({
            "response": response_text,
            "duration_ms": round(duration, 1),
            "agent_tools_used": len(agent_context) > 0,
        })

    return app


# ══════════════════════════════════════════════════════════════
# LLM BACKENDS
# ══════════════════════════════════════════════════════════════

def _detect_model(url):
    """Auto-detect model from MLX/vLLM server."""
    import urllib.request
    try:
        req = urllib.request.Request(f"{url}/v1/models")
        resp = urllib.request.urlopen(req, timeout=3)
        data = json.loads(resp.read().decode())
        models = data.get("data", [])
        if models:
            model_id = models[0].get("id", "")
            logger.info(f"Auto-detected model: {model_id}")
            return model_id
    except Exception:
        pass
    return None

def _call_vllm(url, model, message, history, context, temp, max_tokens):
    """Call vLLM OpenAI-compatible API."""
    import urllib.request

    messages = []
    system = ("You are Marziel, a private AI assistant. "
              "You run locally on the user's device. Be helpful, concise, and accurate.")
    if context:
        system += f"\n\nRelevant context from tools:\n{context}"
    messages.append({"role": "system", "content": system})

    for h in history[-6:]:
        messages.append({"role": h["role"], "content": h["content"]})
    messages.append({"role": "user", "content": message})

    payload = json.dumps({
        "model": model,
        "messages": messages,
        "temperature": temp,
        "max_tokens": max_tokens,
    }).encode()

    req = urllib.request.Request(
        f"{url}/v1/chat/completions",
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    resp = urllib.request.urlopen(req, timeout=60)
    data = json.loads(resp.read().decode())
    return data["choices"][0]["message"]["content"]


def _call_ollama(message, history, context, temp, max_tokens):
    """Call Ollama API (localhost:11434)."""
    import urllib.request

    system = ("You are Marziel, a private AI assistant. "
              "You run locally on the user's device.")
    if context:
        system += f"\n\nRelevant context:\n{context}"

    prompt = f"{system}\n\n"
    for h in history[-6:]:
        role = "User" if h["role"] == "user" else "Marziel"
        prompt += f"{role}: {h['content']}\n"
    prompt += f"User: {message}\nMarziel:"

    payload = json.dumps({
        "model": "llama3.1:8b",
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": temp, "num_predict": max_tokens},
    }).encode()

    req = urllib.request.Request(
        "http://localhost:11434/api/generate",
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    resp = urllib.request.urlopen(req, timeout=60)
    data = json.loads(resp.read().decode())
    return data.get("response", "")


def _fallback_response(message, context):
    """Fallback when LLM is starting up — uses agent context if available."""
    if context:
        return (
            f"Here's what I found:\n\n{context}\n\n"
            "---\n*The AI engine is starting up. "
            "Full conversational responses will be available in a moment.*"
        )

    msg = message.lower()
    if any(w in msg for w in ["hello", "hi", "hey"]):
        return ("👋 Hello! I'm Marziel, your private AI assistant.\n\n"
                "The AI engine is warming up — give it a moment and try again.\n"
                "In the meantime, my web search, URL analysis, and code tools are ready!")

    return ("🧠 Marziel is running on your machine.\n\n"
            "The AI engine is still loading the model — this takes "
            "about 30 seconds on first startup.\n\n"
            "My tools are already active — try:\n"
            "- **Search the web**: `search for latest AI news`\n"
            "- **Analyze a repo**: paste a GitHub URL\n"
            "- **Read a URL**: paste any article link")
