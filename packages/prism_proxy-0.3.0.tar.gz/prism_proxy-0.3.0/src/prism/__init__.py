"""Prism — Multi-API Intelligent Router CLI."""

__version__ = "0.3.0"
__app_name__ = "prism"
