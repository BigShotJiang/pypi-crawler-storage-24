#!/usr/bin/env python3
"""Generate standalone run.sh script for production containers."""

from pathlib import Path

from jinja2 import Environment, PackageLoader

from container_magic.core.config import ContainerMagicConfig
from container_magic.core.steps import has_create_user_in_stages
from container_magic.core.templates import detect_shell, resolve_base_image


def generate_run_script(config: ContainerMagicConfig, project_dir: Path) -> None:
    """Generate run.sh script from production containers.

    Args:
        config: Configuration object
        project_dir: Path to project directory
    """
    env = Environment(
        loader=PackageLoader("container_magic", "templates"),
        keep_trailing_newline=True,
    )
    template = env.get_template("run.sh.j2")

    # Determine runtime backend
    backend = config.backend

    # Get user and workspace info from config.names
    has_user = has_create_user_in_stages(config.stages)
    production_user = config.names.user or "root"
    workspace_name = config.names.workspace

    # Determine workdir based on production user
    if production_user == "root" or not has_user:
        workdir = "/root"
    else:
        workdir = f"/home/{production_user}"

    # Determine shell from production or base stage
    prod_stage = "production" if "production" in config.stages else "base"
    stage_config = config.stages[prod_stage]
    shell = stage_config.shell or detect_shell(
        resolve_base_image(stage_config.frm, config.stages)
    )

    # Escape dollar signs in command strings so they expand in the container
    commands_escaped = {}
    if config.commands:
        for cmd_name, cmd_spec in config.commands.items():
            cmd_copy = cmd_spec.copy(deep=True)
            cmd_copy.command = cmd_spec.command.replace("$", r"\$")
            commands_escaped[cmd_name] = cmd_copy

    # Build feature flags
    runtime_features = config.runtime.features if config.runtime else []
    features = {
        "display": "display" in runtime_features,
        "gpu": "gpu" in runtime_features,
        "audio": "audio" in runtime_features,
        "aws_credentials": "aws_credentials" in runtime_features,
    }

    content = template.render(
        project_name=config.names.image,
        workspace_name=workspace_name,
        workdir=workdir,
        shell=shell,
        backend=backend,
        privileged=config.runtime.privileged if config.runtime else False,
        network=config.runtime.network_mode if config.runtime else None,
        features=features,
        volumes=config.runtime.volumes if config.runtime else [],
        devices=config.runtime.devices if config.runtime else [],
        commands=commands_escaped,
        ipc=config.runtime.ipc if config.runtime else None,
    )

    run_script = project_dir / "run.sh"
    run_script.write_text(content)
    run_script.chmod(0o755)
