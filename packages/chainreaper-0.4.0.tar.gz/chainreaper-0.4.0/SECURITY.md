# Security Policy

## Active Security Advisory

**LiteLLM Supply Chain Attack (March 24, 2026)**

LiteLLM versions **1.82.7 and 1.82.8** were compromised by the TeamPCP threat actor.
The malicious versions contained a 3-stage credential stealer targeting SSH keys, cloud
credentials, Kubernetes secrets, cryptocurrency wallets, and CI/CD tokens.

**ChainReaper status**: We are pinned to `litellm==1.82.6` (last known-clean version).
Our `pyproject.toml` uses exact version pinning to prevent accidental upgrade to
compromised versions.

**Action required**: If you installed ChainReaper before this advisory, verify your
LiteLLM version: `pip show litellm | grep Version`. If you see 1.82.7 or 1.82.8,
**immediately rotate all API keys and credentials** in the environment where ChainReaper ran.

References:
- https://docs.litellm.ai/blog/security-update-march-2026
- https://thehackernews.com/2026/03/teampcp-backdoors-litellm-versions.html

## Supported Versions

| Version | Supported |
|---------|-----------|
| 0.3.x   | Yes       |
| 0.2.x   | Yes       |
| 0.1.x   | Yes       |

## Reporting a Vulnerability

Please report security vulnerabilities to: **security@breachline.io**

Do NOT create a public GitHub issue for security vulnerabilities.

We will acknowledge receipt within 48 hours and provide a detailed response within 7 days.

## Scope

ChainReaper is a **read-only analysis tool**. It:
- NEVER modifies or publishes to package registries
- NEVER executes untrusted code from analyzed packages
- Only performs GET requests to public registry APIs
- Only reads local filesystem files (manifests, lockfiles)

## Security Controls

### SSRF Protection
- Package names validated against per-ecosystem naming rules before API calls
  (npm regex, PyPI PEP 508, Maven groupId:artifactId, Go module paths, Cargo crate names, RubyGems names, NuGet IDs)
- URL encoding applied to all package names in registry requests
- Registry domain allowlists per ecosystem (npmjs.org, pypi.org, search.maven.org, proxy.golang.org, crates.io, rubygems.org, api.nuget.org)
- Lockfile `resolved` URLs validated against allowlist
- HTTP redirect following disabled

### Prompt Injection Defense
- Untrusted package data wrapped in `<package_data>` XML tags
- System prompt includes explicit instruction to treat data as untrusted
- Input sanitizer strips control characters and enforces length limits
- LLM constrained to READ-ONLY operations via system prompt

### Rate Limiting
- asyncio Semaphore limits concurrent registry requests (max 10)
- Configurable delay between requests (100ms default)
- 429 responses raise `RegistryRateLimitError`

### Cost Control
- Per-scan cost limit enforced ($5.00 default, configurable)
- Cost tracked for both raw and structured LLM calls
- Pre-call AND post-call limit enforcement
- Token usage recorded for all LLM interactions

### Path Safety
- Target paths validated: must exist, must be a directory
- Repository URL scanning explicitly blocked (clone locally first)
- No symlink following for target resolution

### Credential Protection
- API keys read from environment variables only (never stored in config)
- Registry tokens excluded from YAML serialization (`Field(exclude=True)`)
- `.chainreaper.yml` included in default `.gitignore`
- Error messages sanitized to prevent key leakage

## Security Design Principles

1. **Read-only by design**: All registry interactions are GET requests only
2. **Defense in depth**: Multiple validation layers (input, URL, domain, redirect)
3. **Fail safe**: Errors in individual analyzers don't crash the scan
4. **Cost bounded**: Hard limits on LLM spend with tracking
5. **No telemetry**: No data collection unless explicitly opted in
