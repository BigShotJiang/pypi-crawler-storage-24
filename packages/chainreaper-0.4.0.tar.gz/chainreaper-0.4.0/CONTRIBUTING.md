# Contributing to ChainReaper

Thank you for your interest in contributing to ChainReaper!

## Development Setup

```bash
git clone https://github.com/breachline/chainreaper.git
cd chainreaper
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pre-commit install
```

## Running Tests

```bash
# All tests (107 passing)
pytest tests/ -v

# Unit tests only (fast, no network)
pytest tests/unit/ -v

# E2E tests (requires LLM API key)
pytest tests/e2e/ -v

# All tests with coverage
pytest --cov=chainreaper --cov-report=html
```

## Code Style

- **Formatter/Linter**: Ruff (`ruff check src/ tests/ && ruff format src/ tests/`)
- **Type checker**: mypy (`mypy src/ --ignore-missing-imports`)
- **Line length**: 100 characters
- **Python**: 3.11+ with type annotations on all public APIs

## Adding a New Analyzer

ChainReaper has 12 analyzers covering all supply chain attack vectors. To add a new one:

1. Create `src/chainreaper/analyzers/your_analyzer.py`
2. Subclass `BaseAnalyzer` and implement `analyze()`
3. Define a Pydantic response model for structured LLM output
4. Use `@AnalyzerRegistry.register` decorator
5. Import in `src/chainreaper/analyzers/registry.py`
6. Add LLM prompts in `src/chainreaper/llm/prompts/analysis.py`
7. Add tests in `tests/unit/test_analyzers/`

**Required patterns** (see `dependency_confusion.py` as reference):
- Use `CHAINREAPER_SYSTEM` as system prompt
- Wrap untrusted data in `<package_data>` XML tags
- Use `_sanitize()` for input cleaning
- Use `StructuredLLM.extract()` with Pydantic response models
- Return `list[Finding]` with CWE IDs
- Include rate limiting guards (dep count caps)

## Adding a New Ecosystem

ChainReaper supports 7 ecosystems (npm, PyPI, Maven, Go, Cargo, RubyGems, NuGet). To add a new one:

1. Create `src/chainreaper/ecosystems/your_ecosystem.py`
2. Subclass `BaseEcosystem` and implement all abstract methods
3. Use `@EcosystemRegistry.register` decorator
4. Import in `src/chainreaper/ecosystems/registry.py`
5. Add tests in `tests/unit/test_ecosystems/`
6. Add fixture files in `tests/fixtures/`

**Required security patterns** (see `npm.py` or `pypi.py` as reference):
- Package name validation regex
- URL encoding for API calls
- Shared httpx.AsyncClient with connection pooling
- Rate limiting (asyncio.Semaphore)
- File size limits (50MB)
- SSRF protection on resolved URLs

## Pull Request Process

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Ensure all tests pass (`pytest tests/ -v`)
5. Ensure linting passes (`ruff check src/ tests/ && ruff format --check src/ tests/`)
6. Ensure type checking passes (`mypy src/ --ignore-missing-imports`)
7. Commit with a descriptive message
8. Push and create a Pull Request

## Code of Conduct

Be respectful, constructive, and collaborative.
