# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

ChainReaper is an autonomous AI supply chain attack simulator. An LLM-driven agent reasons about attack paths, simulates supply chain attacks across 7 ecosystems (npm, PyPI, Maven, Go, Cargo, RubyGems, NuGet), and generates interactive attack graph visualizations. Zero hardcoded rules — the LLM makes all analysis decisions via a ReAct (Reasoning + Acting) loop.

## Commands

```bash
# Install for development
pip install -e ".[dev]" && pre-commit install

# Run all tests (299 passing)
pytest tests/ -v

# Unit tests only (fast, no network, no LLM keys needed)
pytest tests/unit/ -v

# Single test file
pytest tests/unit/test_models.py -v

# Single test
pytest tests/unit/test_models.py::test_function_name -v

# E2E tests (requires LLM API key)
pytest tests/e2e/ -v

# Lint and format
ruff check src/ tests/
ruff format src/ tests/

# Type check
mypy src/ --ignore-missing-imports

# Full check (lint + types + tests)
make check
```

## Architecture

### Core Data Flow

```
Target → Discovery (parse manifests/lockfiles, detect ecosystems)
       → Phase 0: CVE Scan (OSV.dev) + Threat Intel (MAL- advisories) + Source Provenance
       → LLM Planning (attack strategy)
       → ReAct Analysis Loop (LLM picks 13 analyzers autonomously)
       → LLM Verification (validate findings, score exploitability)
       → Confidence Calibration (ground LLM findings against factual data)
       → Attack Graph Construction (chain findings into multi-step paths)
       → Output (JSON, SARIF, CycloneDX SBOM, interactive HTML with D3.js)
```

### Key Modules (`src/chainreaper/`)

- **agents/**: Autonomous agent system.
  - `ScanOrchestrator` drives the scan pipeline
  - `ReActReasoner` implements Thought→Action→Observation loop
  - `AttackPathPlanner` builds attack graphs
  - `FindingsVerifier` validates results via LLM
  - `cve_scanner.py` queries OSV.dev for known CVEs (Phase 0)
  - `threat_intel.py` checks OpenSSF malicious packages database
  - `source_verifier.py` checks provenance (repo link, hashes, Sigstore)
  - `confidence.py` calibrates LLM confidence against factual data
- **analyzers/**: 13 attack vector analyzers (dependency confusion, typosquatting, compromised maintainer, build system, malicious package, install script, shadow dependency, lockfile integrity, registry spoofing, abandoned takeover, source-binary mismatch, protestware, code inspection). All subclass `BaseAnalyzer` and register via `@AnalyzerRegistry.register`.
- **ecosystems/**: 7 package ecosystem plugins. All subclass `BaseEcosystem` and register via `@EcosystemRegistry.register`. Handle manifest parsing, lockfile parsing, and registry API access.
- **llm/**: LLM integration via direct provider SDKs (Google, Anthropic, OpenAI). `router.py` handles provider chain with fallback. `structured.py` guarantees typed Pydantic responses. Prompts in `llm/prompts/`.
- **core/**: `models.py` (Pydantic v2 data models), `config.py` (YAML/env config), `constants.py` (enums), `events.py` (event bus), `diff.py` (incremental scanning), `policy.py` (block/allow/warn rules).
- **cli/**: Typer CLI. Entry point is `chainreaper.cli.app:main`. Main command is `chainreaper scan <target>`.
- **output/**: Formatters (JSON, SARIF 2.1.0, CycloneDX 1.5, HTML). HTML uses a D3.js template in `graph/templates/`.

### Plugin Architecture

Analyzers and ecosystems use auto-discovery registries. To add a new one:
- Subclass the base class, decorate with `@Registry.register`, import in the corresponding `registry.py`
- Reference implementation: `dependency_confusion.py` for analyzers, `npm.py` for ecosystems

### LLM Integration Patterns

- System prompts in `llm/prompts/system.py` and `llm/prompts/analysis.py`
- Untrusted data (package names, metadata) must be wrapped in `<package_data>` XML tags for prompt injection defense
- Use `_sanitize()` for input cleaning before sending to LLM
- Use `StructuredLLM.extract()` with Pydantic response models for typed output
- All analyzers cap dependency counts for rate limiting

### Security Constraints

- **Read-only**: All registry interactions are GET-only. No package publishing or code execution.
- **SSRF protection**: Package name validation, URL encoding, domain allowlists for downloads
- **Cost control**: Pre/post call enforcement with configurable USD limits
- **Async I/O**: All network calls use `httpx.AsyncClient` with connection pooling and `asyncio.Semaphore` (max 10 concurrent)
- **Confidence calibration**: LLM findings grounded against CVE data + threat intel to catch hallucinations

### CI/CD Integration

- **GitHub Action**: `action.yml` at repo root — composite action with SARIF upload + PR comments
- **GitLab CI**: `ci-templates/gitlab-ci.yml` — SAST artifact integration
- **Policy engine**: `core/policy.py` — YAML block/allow/warn rules with glob patterns

## Code Style

- Python 3.11+, full type annotations on all public APIs
- Ruff for linting and formatting (line length 100)
- mypy in strict mode
- Pydantic v2 for all data models with Field descriptions
- asyncio_mode = "auto" in pytest (async tests need no decorator)
- `RUF012` ignored: mutable class attributes use ClassVar pattern intentionally
- `B008` ignored: function calls in default args required by Typer API
