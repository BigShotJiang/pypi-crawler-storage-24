# Changelog

All notable changes to ChainReaper will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.4.0] - 2026-03-27

### Added
- **CVE Scanner (Phase 0)**: Queries OSV.dev for every dependency before LLM runs.
  CVSS v3 vector parsing, concurrent API calls, CVE ignore lists.
- **Threat Intelligence Feed**: Checks OpenSSF malicious packages database (MAL- advisories).
  Confirmed malware gets confidence=1.0.
- **Source Provenance Checker**: Verifies repo link, integrity hash, Sigstore attestation
  for npm/PyPI packages. Flags provenance gaps.
- **Package Code Inspector**: Downloads .tgz/.whl, AST-parses Python + string-matches JS
  for suspicious calls (eval, exec, subprocess, env access, obfuscation). LLM reviews
  flagged snippets to filter false positives.
- **SARIF 2.1.0 Output**: GitHub Security tab integration with deterministic fingerprints,
  CWE UUID relationships, security-severity scores.
- **CycloneDX 1.5 SBOM**: Components with PURL, scope, hashes + vulnerability section.
  Enterprise compliance ready (EO 14028).
- **Incremental Scanning**: Diff engine compares dependency trees, `--baseline` and
  `--diff-only` flags to only scan changed deps in CI.
- **Policy Engine**: YAML block/allow/warn rules matching on severity, attack vector,
  ecosystem, package globs, CVE IDs, confidence ranges. `--policy` CLI flag.
- **Confidence Calibration**: Grounds LLM findings against CVE/threat intel data. Boosts
  corroborated findings, penalizes ungrounded claims, drops very low confidence.
- **GitHub Action** (`action.yml`): Composite action with SARIF upload, PR comments,
  artifact upload. Auto-detects API key provider.
- **GitLab CI Template**: SAST artifact integration, triggered on manifest changes.
- **PR Comment Bot**: Summarizes findings on PRs via `actions/github-script`.

### Changed

- LLM router: retry on 429/504/rate limit with exponential backoff (2s, 4s)
- Structured extraction: force max_tokens >= 65536 to prevent JSON truncation
- Malicious package prompt: stricter rules to reduce false positives on popular packages
- Anthropic SDK: streaming responses to prevent timeout on large extractions
- Package resolver: parse name@version specs, fetch transitive deps from registry

### Fixed

- "0 dependencies" bug when scanning single packages (resolver now fetches deps)
- CVSS vector strings from OSV.dev were not being parsed (only numeric scores worked)
- CVE ignore only checked aliases, not vuln ID field
- SARIF CWE guids were strings instead of valid UUIDs
- SARIF fingerprints were random (broke GitHub dedup across runs)
- Threat intel false positive on "malicious URLs" in CVE descriptions
- Module-level asyncio.Semaphore caused issues across event loop boundaries

## [0.3.0] - 2026-03-26

### Added
- **Complete 12/12 attack vector coverage**:
  - build_system: CI/CD pipeline poisoning (GitHub Actions, GitLab CI, Jenkins)
  - malicious_package: Suspicious metadata patterns (bot inflation, obfuscation)
  - registry_spoofing: Misconfigured private/public registry mixing
  - abandoned_takeover: Dormant packages vulnerable to maintainer takeover
  - source_binary_mismatch: Published artifacts diverging from source code
  - protestware: Conditional destructive behavior detection
- All analyzers support all 7 ecosystems (npm, PyPI, Maven, Go, Cargo, RubyGems, NuGet)
- Typosquatting analyzer: 115 popular packages across all ecosystems
- Package URLs in all findings (clickable links to registry pages)
- Package info in HTML sidebar (URL, repository, license, maintainers, description)
- Comprehensive CLI: `list`, `config --validate/--set/--path`, scan options
  (`--model`, `--cost-limit`, `--ecosystem`, `--no-verify`, `--verbose`, `--quiet`)

## [0.2.0] - 2026-03-25

### Added
- 5 new LLM-driven analyzers (typosquatting, compromised maintainer, install script,
  shadow dependency, lockfile integrity)
- PyPI ecosystem plugin
- Interactive D3.js HTML attack graph (zoom, pan, click, search, export PNG)
- LLM findings verification phase (exploitability scoring, false positive filtering)
- LLM scan planning phase
- Enhanced CLI output (scan progress, top risks, remediation summary, cost breakdown)
- Per-provider Instructor mode (JSON for Gemini/Claude, TOOLS for OpenAI)

### Fixed
- Dependency confusion filter: `exists_on_public` -> `available_on_public_registry`
- Instructor TOOLS mode -> JSON mode for Gemini compatibility
- CLI scan command refactored from sub-Typer to direct command

## [0.1.0] - 2026-03-25

### Added
- Multi-LLM router with LiteLLM (100+ provider support)
- ReAct-style autonomous agent system (no hardcoded rules)
- npm ecosystem plugin
- Dependency confusion analyzer
- Typer CLI with Rich terminal output
- JSON output formatter
- Pydantic v2 data models

### Security
- SSRF protection, prompt injection defense, rate limiting, path traversal protection,
  cost control, config security, error isolation
