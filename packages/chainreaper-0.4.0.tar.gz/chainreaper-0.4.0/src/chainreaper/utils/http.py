"""Shared async HTTP client with sensible defaults."""

from __future__ import annotations

import httpx

DEFAULT_TIMEOUT = 15.0
DEFAULT_HEADERS = {
    "User-Agent": "ChainReaper/0.1.0 (https://github.com/breachline/chainreaper)",
}


def create_client(timeout: float = DEFAULT_TIMEOUT) -> httpx.AsyncClient:
    """Create a configured async HTTP client."""
    return httpx.AsyncClient(
        timeout=timeout,
        headers=DEFAULT_HEADERS,
        follow_redirects=True,
    )
