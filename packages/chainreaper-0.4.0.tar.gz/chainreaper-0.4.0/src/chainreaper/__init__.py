"""ChainReaper — Autonomous AI Supply Chain Attack Simulator by Breachline Labs."""

__version__ = "0.4.0"
__author__ = "Breachline Labs"
