"""Protestware analyzer — detects packages with protest-driven or geo-targeted destructive behavior."""

from __future__ import annotations

import logging

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.ecosystems.base import EcosystemRegistry
from chainreaper.llm.prompts.analysis import PROTESTWARE
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

# Max length for package names/metadata in prompts to prevent abuse
_MAX_NAME_LEN = 214
_MAX_DESC_LEN = 500

# Packages with known history of protestware incidents (for reference context)
_KNOWN_PROTESTWARE_PACKAGES: dict[str, list[str]] = {
    "npm": [
        "node-ipc",
        "colors",
        "faker",
        "es5-ext",
        "event-source-polyfill",
    ],
    "pypi": [
        "ctx",
        "atomicwrites",
    ],
    "rubygems": [
        "rest-client",
    ],
}


def _sanitize(value: str, max_len: int = _MAX_NAME_LEN) -> str:
    """Sanitize untrusted data before including in LLM prompts."""
    clean = value[:max_len].strip()
    clean = "".join(c for c in clean if c.isprintable())
    return clean


class ProtestwareSuspect(BaseModel):
    """A single package suspected of protestware behavior, identified by the LLM."""

    package_name: str
    risk_type: str = Field(
        description="Type of protestware risk: known_incident, geo_targeted_behavior, "
        "conditional_execution, suspicious_version_bump, locale_based_logic, "
        "destructive_payload, wiper_behavior, political_messaging"
    )
    reasoning: str = Field(description="Why this package is suspected of protestware behavior")
    is_likely_protestware: bool = Field(
        description="Whether the LLM assesses this package as likely protestware"
    )
    has_known_history: bool = Field(
        description="Whether this package has a known protestware incident history"
    )
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str = Field(description="Recommended fix")


class ProtestwareResult(BaseModel):
    """Structured output from the protestware analysis."""

    suspects: list[ProtestwareSuspect] = []
    overall_assessment: str = ""


@AnalyzerRegistry.register
class ProtestwareAnalyzer(BaseAnalyzer):
    """Detects packages with protest-driven or geo-targeted destructive behavior.

    Analyzes the dependency tree for protestware/wiper risk by examining:
    - Known packages with protestware incident history
    - Patterns of geo-targeted destructive behavior (locale/timezone/IP checks)
    - Conditional code execution based on geographic or political context
    - Recent version bumps with suspicious changelog entries
    - Packages from ecosystems with documented protestware waves

    Uses LLM reasoning to assess risk based on package metadata and
    ecosystem context, cross-referencing against known protestware patterns.
    """

    analyzer_name = "protestware"
    attack_vector = AttackVector.PROTESTWARE
    applicable_ecosystems = [
        EcosystemName.NPM,
        EcosystemName.PYPI,
        EcosystemName.MAVEN,
        EcosystemName.GO,
        EcosystemName.CARGO,
        EcosystemName.RUBYGEMS,
        EcosystemName.NUGET,
    ]
    description = (
        "Detects packages with protest-driven or geo-targeted destructive behavior "
        "including wipers, conditional execution, and political sabotage."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Analyze dependencies for protestware and wiper risks."""
        findings: list[Finding] = []

        for tree in context.dependency_trees:
            eco_cls = EcosystemRegistry.get(tree.ecosystem.value)
            if not eco_cls:
                continue

            eco = eco_cls()

            # Gather package metadata for analysis
            packages_info: list[dict[str, object]] = []
            all_deps = tree.direct_dependencies + tree.transitive_dependencies

            # Get the known protestware list for this ecosystem
            known_list = _KNOWN_PROTESTWARE_PACKAGES.get(tree.ecosystem.value, [])

            for dep in all_deps[:100]:  # Limit to prevent excessive API calls
                metadata = await eco.get_package_metadata(dep.name)

                is_known_protestware = dep.name.lower() in [k.lower() for k in known_list]

                if metadata:
                    packages_info.append(
                        {
                            "name": dep.name,
                            "version": dep.version,
                            "is_direct": dep.is_direct,
                            "description": metadata.description,
                            "maintainer_count": len(metadata.maintainers),
                            "maintainer_names": [m.username for m in metadata.maintainers[:5]],
                            "repository_url": metadata.repository_url or "none",
                            "publish_date": (
                                metadata.publish_date.isoformat()
                                if metadata.publish_date
                                else "unknown"
                            ),
                            "download_count": metadata.download_count,
                            "has_install_scripts": metadata.has_install_scripts,
                            "license": metadata.license or "unknown",
                            "is_known_protestware": is_known_protestware,
                        }
                    )
                elif is_known_protestware:
                    # Even without metadata, flag known protestware packages
                    packages_info.append(
                        {
                            "name": dep.name,
                            "version": dep.version,
                            "is_direct": dep.is_direct,
                            "description": "metadata unavailable",
                            "maintainer_count": 0,
                            "maintainer_names": [],
                            "repository_url": "unknown",
                            "publish_date": "unknown",
                            "download_count": None,
                            "has_install_scripts": False,
                            "license": "unknown",
                            "is_known_protestware": True,
                        }
                    )

            if not packages_info:
                continue

            # Wrap untrusted package data in XML tags for prompt injection defense
            packages_text = "\n".join(
                f"- {_sanitize(str(p['name']))}@{_sanitize(str(p['version']))} "
                f"(direct={p['is_direct']}, "
                f"description={_sanitize(str(p['description']), _MAX_DESC_LEN)}, "
                f"maintainers={p['maintainer_count']} "
                f"[{', '.join(_sanitize(n) for n in p['maintainer_names'])}], "
                f"repo={_sanitize(str(p['repository_url']))}, "
                f"published={p['publish_date']}, "
                f"downloads={p['download_count']}, "
                f"install_scripts={p['has_install_scripts']}, "
                f"license={_sanitize(str(p['license']))}, "
                f"KNOWN_PROTESTWARE={p['is_known_protestware']})"
                for p in packages_info
            )

            # Include known protestware packages as context
            known_text = ", ".join(known_list) if known_list else "none documented"

            prompt = PROTESTWARE.format(
                ecosystem=tree.ecosystem.value,
                package_count=len(packages_info),
                known_protestware=known_text,
                packages=f"<package_data>\n{packages_text}\n</package_data>",
            )

            messages = [
                {"role": "system", "content": CHAINREAPER_SYSTEM},
                {"role": "user", "content": prompt},
            ]

            result = await llm.extract(
                response_model=ProtestwareResult,
                messages=messages,
            )

            # Convert LLM results to findings
            for suspect in result.suspects:
                if suspect.is_likely_protestware or suspect.has_known_history:
                    findings.append(
                        Finding(
                            title=f"Protestware risk: {suspect.package_name}",
                            description=(
                                f"Package '{suspect.package_name}' shows indicators of "
                                f"protestware or geo-targeted destructive behavior. Risk type: "
                                f"{suspect.risk_type}. Protestware can silently delete files, "
                                f"corrupt data, display political messages, or execute "
                                f"destructive payloads based on the user's geographic location, "
                                f"timezone, or IP address. "
                                f"{'This package has a KNOWN protestware incident history. ' if suspect.has_known_history else ''}"
                                f"Reasoning: {suspect.reasoning}"
                            ),
                            severity=suspect.severity,
                            confidence=suspect.confidence,
                            attack_vector=AttackVector.PROTESTWARE,
                            ecosystem=tree.ecosystem,
                            package_name=suspect.package_name,
                            evidence=Evidence(
                                description=suspect.reasoning,
                                raw_data={
                                    "risk_type": suspect.risk_type,
                                    "is_likely_protestware": suspect.is_likely_protestware,
                                    "has_known_history": suspect.has_known_history,
                                    "analysis": suspect.reasoning,
                                },
                            ),
                            remediation=suspect.remediation,
                            cwe_ids=["CWE-912"],
                            package_url=f"{eco.registry_url}/{suspect.package_name}",
                            package_registry_url=eco.registry_url,
                        )
                    )

        return findings
