"""Attack vector analyzers."""
