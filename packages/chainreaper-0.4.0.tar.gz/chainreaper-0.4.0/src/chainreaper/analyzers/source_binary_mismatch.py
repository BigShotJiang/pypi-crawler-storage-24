"""Source-binary mismatch analyzer — detects packages without verifiable source provenance."""

from __future__ import annotations

import logging

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.ecosystems.base import EcosystemRegistry
from chainreaper.llm.prompts.analysis import SOURCE_BINARY_MISMATCH
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

# Max length for package names/URLs in prompts to prevent abuse
_MAX_NAME_LEN = 214
_MAX_URL_LEN = 500


def _sanitize(value: str, max_len: int = _MAX_NAME_LEN) -> str:
    """Sanitize untrusted data before including in LLM prompts."""
    clean = value[:max_len].strip()
    clean = "".join(c for c in clean if c.isprintable())
    return clean


class SourceBinaryMismatchIssue(BaseModel):
    """A single source-binary mismatch issue identified by the LLM."""

    package_name: str
    issue_type: str = Field(
        description="Type of issue: no_source_repo, repo_url_mismatch, "
        "no_build_provenance, unreproducible_build, stale_source_repo, "
        "missing_vcs_info, suspicious_artifact"
    )
    reasoning: str = Field(description="Why this package has a source-binary integrity concern")
    has_verifiable_source: bool = Field(
        description="Whether the package has verifiable, linked source code"
    )
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str = Field(description="Recommended fix")


class SourceBinaryMismatchResult(BaseModel):
    """Structured output from the source-binary mismatch analysis."""

    issues: list[SourceBinaryMismatchIssue] = []
    overall_assessment: str = ""


@AnalyzerRegistry.register
class SourceBinaryMismatchAnalyzer(BaseAnalyzer):
    """Detects packages without verifiable source provenance.

    Checks whether published artifacts can be traced back to their source:
    - Compares repository_url in metadata vs registry listing
    - Checks if the package has a linked source repository
    - Looks for build provenance or reproducible build indicators
    - Identifies gaps between published artifact and available source

    An attacker who gains publish access can push a backdoored artifact
    that doesn't match the public source repository, making the attack
    invisible to code review.
    """

    analyzer_name = "source_binary_mismatch"
    attack_vector = AttackVector.SOURCE_BINARY_MISMATCH
    applicable_ecosystems = [
        EcosystemName.NPM,
        EcosystemName.PYPI,
        EcosystemName.CARGO,
        EcosystemName.MAVEN,
    ]
    description = (
        "Detects packages without verifiable source provenance, where the "
        "published artifact may not match the public source repository."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Analyze dependencies for source-binary mismatch risks."""
        findings: list[Finding] = []

        for tree in context.dependency_trees:
            eco_cls = EcosystemRegistry.get(tree.ecosystem.value)
            if not eco_cls:
                continue

            eco = eco_cls()

            # Gather package metadata with source provenance signals
            packages_info: list[dict[str, object]] = []
            all_deps = tree.direct_dependencies + tree.transitive_dependencies

            for dep in all_deps[:80]:  # Limit to prevent excessive API calls
                metadata = await eco.get_package_metadata(dep.name)
                if not metadata:
                    continue

                packages_info.append(
                    {
                        "name": dep.name,
                        "version": dep.version,
                        "is_direct": dep.is_direct,
                        "description": metadata.description,
                        "repository_url": metadata.repository_url or "none",
                        "maintainer_count": len(metadata.maintainers),
                        "publish_date": (
                            metadata.publish_date.isoformat()
                            if metadata.publish_date
                            else "unknown"
                        ),
                        "download_count": metadata.download_count,
                        "license": metadata.license or "unknown",
                        "has_install_scripts": metadata.has_install_scripts,
                    }
                )

            if not packages_info:
                continue

            # Wrap untrusted package data in XML tags for prompt injection defense
            packages_text = "\n".join(
                f"- {_sanitize(str(p['name']))}@{_sanitize(str(p['version']))} "
                f"(direct={p['is_direct']}, "
                f"repo={_sanitize(str(p['repository_url']), _MAX_URL_LEN)}, "
                f"maintainers={p['maintainer_count']}, "
                f"published={p['publish_date']}, "
                f"downloads={p['download_count']}, "
                f"license={_sanitize(str(p['license']))}, "
                f"install_scripts={p['has_install_scripts']})"
                for p in packages_info
            )

            prompt = SOURCE_BINARY_MISMATCH.format(
                ecosystem=tree.ecosystem.value,
                registry_url=eco.registry_url,
                package_count=len(packages_info),
                packages=f"<package_data>\n{packages_text}\n</package_data>",
            )

            messages = [
                {"role": "system", "content": CHAINREAPER_SYSTEM},
                {"role": "user", "content": prompt},
            ]

            result = await llm.extract(
                response_model=SourceBinaryMismatchResult,
                messages=messages,
            )

            # Convert LLM results to findings — only emit issues where source is NOT verifiable
            for issue in result.issues:
                if not issue.has_verifiable_source:
                    findings.append(
                        Finding(
                            title=(
                                f"Source-binary mismatch: {issue.package_name} ({issue.issue_type})"
                            ),
                            description=(
                                f"Package '{issue.package_name}' has a source-binary integrity "
                                f"concern of type '{issue.issue_type}'. The published artifact "
                                f"on {tree.ecosystem.value} cannot be reliably traced back to "
                                f"its source code. This means a compromised publish credential "
                                f"or malicious maintainer could push a backdoored version that "
                                f"appears legitimate in the source repository. "
                                f"Reasoning: {issue.reasoning}"
                            ),
                            severity=issue.severity,
                            confidence=issue.confidence,
                            attack_vector=AttackVector.SOURCE_BINARY_MISMATCH,
                            ecosystem=tree.ecosystem,
                            package_name=issue.package_name,
                            evidence=Evidence(
                                description=issue.reasoning,
                                raw_data={
                                    "issue_type": issue.issue_type,
                                    "has_verifiable_source": issue.has_verifiable_source,
                                    "analysis": issue.reasoning,
                                },
                            ),
                            remediation=issue.remediation,
                            cwe_ids=["CWE-345"],
                            package_url=f"{eco.registry_url}/{issue.package_name}",
                            package_registry_url=eco.registry_url,
                        )
                    )

        return findings
