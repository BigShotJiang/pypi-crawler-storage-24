"""Registry spoofing analyzer — detects registry misconfiguration that could allow package spoofing."""

from __future__ import annotations

import logging
from pathlib import Path

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.llm.prompts.analysis import REGISTRY_SPOOFING
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

# Max length for data in prompts to prevent abuse
_MAX_NAME_LEN = 214
# Max size for registry config file content sent to the LLM (characters)
_MAX_FILE_CONTENT_LEN = 20_000
# Max file size to read from disk (bytes)
_MAX_FILE_SIZE_BYTES = 2_000_000

# Registry config file patterns per ecosystem
_REGISTRY_CONFIG_FILES: dict[str, list[tuple[str, str]]] = {
    "npm": [
        (".npmrc", "npm registry config"),
        (".yarnrc", "Yarn v1 registry config"),
        (".yarnrc.yml", "Yarn v2+ registry config"),
        (".pnpmrc", "pnpm registry config"),
    ],
    "pypi": [
        (".pypirc", "PyPI upload config"),
        ("pip.conf", "pip registry config"),
        ("setup.cfg", "setuptools config"),
        ("pyproject.toml", "PEP 621 project config"),
    ],
    "cargo": [
        (".cargo/config", "Cargo registry config"),
        (".cargo/config.toml", "Cargo registry config (TOML)"),
    ],
    "rubygems": [
        (".gemrc", "RubyGems registry config"),
        ("Gemfile", "Bundler dependency file"),
    ],
}


def _sanitize(value: str) -> str:
    """Sanitize untrusted data before including in LLM prompts."""
    clean = value[:_MAX_NAME_LEN].strip()
    clean = "".join(c for c in clean if c.isprintable())
    return clean


def _read_file_safe(path: Path) -> str | None:
    """Safely read a file with size limits."""
    if not path.exists() or not path.is_file():
        return None
    try:
        if path.stat().st_size > _MAX_FILE_SIZE_BYTES:
            logger.warning("Registry config file exceeds size limit, skipping: %s", path)
            return None
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        logger.warning("Failed to read %s: %s", path, e)
        return None


def _discover_registry_configs(target_path: Path, ecosystems: list[str]) -> list[dict[str, str]]:
    """Discover registry configuration files for the given ecosystems.

    Returns a list of dicts with keys: file_path, ecosystem, config_type, content.
    """
    configs: list[dict[str, str]] = []

    for eco_name in ecosystems:
        patterns = _REGISTRY_CONFIG_FILES.get(eco_name, [])
        for filename, config_type in patterns:
            full_path = target_path / filename
            content = _read_file_safe(full_path)
            if content:
                configs.append(
                    {
                        "file_path": filename,
                        "ecosystem": eco_name,
                        "config_type": config_type,
                        "content": content[:_MAX_FILE_CONTENT_LEN],
                    }
                )

        # Also check home directory patterns for pip.conf
        if eco_name == "pypi":
            for alt_path in [
                target_path / "pip.conf",
                target_path / ".pip" / "pip.conf",
            ]:
                content = _read_file_safe(alt_path)
                if content:
                    configs.append(
                        {
                            "file_path": str(alt_path.relative_to(target_path)),
                            "ecosystem": eco_name,
                            "config_type": "pip registry config",
                            "content": content[:_MAX_FILE_CONTENT_LEN],
                        }
                    )

    return configs


class RegistrySpoofingIssue(BaseModel):
    """A single registry spoofing issue identified by the LLM."""

    file_path: str = Field(description="Path to the registry config file with the issue")
    issue_type: str = Field(
        description="Type of issue: mixed_registries, missing_scope_binding, "
        "http_registry, unverified_registry, missing_auth, "
        "private_registry_leak, proxy_misconfiguration"
    )
    description: str = Field(description="Detailed description of the spoofing risk")
    affected_packages: list[str] = Field(
        default_factory=list,
        description="Package names or scopes affected by this misconfiguration",
    )
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str = Field(description="Recommended fix")


class RegistrySpoofingResult(BaseModel):
    """Structured output from the registry spoofing analysis."""

    issues: list[RegistrySpoofingIssue] = []
    overall_assessment: str = ""


@AnalyzerRegistry.register
class RegistrySpoofingAnalyzer(BaseAnalyzer):
    """Detects registry configuration issues that could allow package spoofing.

    Reads registry configuration files (.npmrc, .pypirc, pip.conf, Cargo config,
    .gemrc) and analyzes them for misconfigurations that could allow an attacker
    to inject malicious packages via:
    - Mixed public/private registry usage without proper scoping
    - Missing scope bindings for private registries
    - HTTP (non-TLS) registry URLs
    - Unverified or suspicious third-party registries
    - Missing authentication for private registries
    - Registry proxy misconfigurations
    """

    analyzer_name = "registry_spoofing"
    attack_vector = AttackVector.REGISTRY_SPOOFING
    applicable_ecosystems = [
        EcosystemName.NPM,
        EcosystemName.PYPI,
        EcosystemName.CARGO,
        EcosystemName.RUBYGEMS,
    ]
    description = (
        "Detects registry configuration issues that could allow attackers "
        "to spoof packages via misconfigured private/public registry usage."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Analyze registry configurations for spoofing vulnerabilities."""
        findings: list[Finding] = []

        # Resolve the target path from context
        target_path = Path(context.target.value)
        if not target_path.is_dir():
            target_path = target_path.parent

        # Determine which ecosystems are present
        ecosystems_present = [tree.ecosystem.value for tree in context.dependency_trees]
        # Filter to only applicable ecosystems
        relevant_ecosystems = [eco for eco in ecosystems_present if eco in _REGISTRY_CONFIG_FILES]

        if not relevant_ecosystems:
            return findings

        # Discover registry config files
        registry_configs = _discover_registry_configs(target_path, relevant_ecosystems)

        if not registry_configs:
            # No registry configs found — this itself can be informational
            # (using default public registries is generally safe)
            logger.info(
                "No custom registry configs found at %s, skipping registry spoofing analysis",
                target_path,
            )
            return findings

        # Build prompt text with sanitized file contents
        configs_text_parts: list[str] = []
        for config in registry_configs:
            sanitized_content = "".join(
                c for c in config["content"] if c.isprintable() or c in ("\n", "\t", " ")
            )
            configs_text_parts.append(
                f"### File: {_sanitize(config['file_path'])} "
                f"(Ecosystem: {_sanitize(config['ecosystem'])}, "
                f"Type: {_sanitize(config['config_type'])})\n"
                f"```\n{sanitized_content}\n```"
            )

        configs_text = "\n\n".join(configs_text_parts)

        # Build dependency context for the LLM
        dep_summary_parts: list[str] = []
        for tree in context.dependency_trees:
            direct_names = [_sanitize(d.name) for d in tree.direct_dependencies[:50]]
            dep_summary_parts.append(
                f"Ecosystem: {tree.ecosystem.value}, "
                f"Direct deps ({len(tree.direct_dependencies)}): "
                f"{', '.join(direct_names[:20])}"
                + (f" ... and {len(direct_names) - 20} more" if len(direct_names) > 20 else "")
            )

        dep_summary = "\n".join(dep_summary_parts)

        prompt = REGISTRY_SPOOFING.format(
            registry_configs=f"<package_data>\n{configs_text}\n</package_data>",
            dependency_summary=f"<package_data>\n{dep_summary}\n</package_data>",
            ecosystems=", ".join(relevant_ecosystems),
        )

        messages = [
            {"role": "system", "content": CHAINREAPER_SYSTEM},
            {"role": "user", "content": prompt},
        ]

        result = await llm.extract(
            response_model=RegistrySpoofingResult,
            messages=messages,
        )

        # Convert LLM results to findings
        for issue in result.issues:
            affected_str = (
                f" Affected packages/scopes: {', '.join(issue.affected_packages)}."
                if issue.affected_packages
                else ""
            )
            # Determine ecosystem from the config file
            config_eco = EcosystemName.NPM  # default
            for config in registry_configs:
                if config["file_path"] == issue.file_path:
                    try:
                        config_eco = EcosystemName(config["ecosystem"])
                    except ValueError:
                        pass
                    break

            findings.append(
                Finding(
                    title=(f"Registry spoofing risk: {issue.issue_type} in {issue.file_path}"),
                    description=(
                        f"Registry configuration file '{issue.file_path}' contains a "
                        f"'{issue.issue_type}' misconfiguration that could allow an "
                        f"attacker to serve malicious packages. Registry spoofing attacks "
                        f"can redirect package installations to attacker-controlled servers "
                        f"or exploit mixed public/private registry resolution.{affected_str} "
                        f"{issue.description}"
                    ),
                    severity=issue.severity,
                    confidence=issue.confidence,
                    attack_vector=AttackVector.REGISTRY_SPOOFING,
                    ecosystem=config_eco,
                    package_name=_sanitize(issue.file_path),
                    evidence=Evidence(
                        description=issue.description,
                        raw_data={
                            "file_path": issue.file_path,
                            "issue_type": issue.issue_type,
                            "affected_packages": issue.affected_packages,
                            "configs_scanned": len(registry_configs),
                        },
                    ),
                    remediation=issue.remediation,
                    cwe_ids=["CWE-346"],
                )
            )

        return findings
