"""Lockfile integrity analyzer — verifies lockfile consistency against the manifest."""

from __future__ import annotations

import json
import logging
from pathlib import Path

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.llm.prompts.analysis import LOCKFILE_INTEGRITY
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

# Max length for data in prompts to prevent abuse
_MAX_NAME_LEN = 214
# Max size for manifest/lockfile content sent to the LLM (characters)
_MAX_FILE_CONTENT_LEN = 50_000
# Max file size to read from disk (bytes)
_MAX_FILE_SIZE_BYTES = 50_000_000


def _sanitize(value: str) -> str:
    """Sanitize untrusted data before including in LLM prompts."""
    clean = value[:_MAX_NAME_LEN].strip()
    clean = "".join(c for c in clean if c.isprintable())
    return clean


def _read_json_file(path: Path, max_size: int = _MAX_FILE_SIZE_BYTES) -> dict | None:
    """Safely read and parse a JSON file with size limits."""
    if not path.exists():
        return None
    if path.stat().st_size > max_size:
        logger.warning("File exceeds size limit, skipping: %s", path)
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Failed to parse %s: %s", path, e)
        return None


def _summarize_manifest(manifest: dict) -> str:
    """Create a concise text summary of a package.json manifest."""
    lines: list[str] = []
    lines.append(f"name: {_sanitize(manifest.get('name', 'unknown'))}")
    lines.append(f"version: {_sanitize(manifest.get('version', 'unknown'))}")

    for dep_group in (
        "dependencies",
        "devDependencies",
        "peerDependencies",
        "optionalDependencies",
    ):
        deps = manifest.get(dep_group, {})
        if deps:
            lines.append(f"\n{dep_group}:")
            for name, version_spec in list(deps.items())[:100]:
                lines.append(f"  {_sanitize(name)}: {_sanitize(str(version_spec))}")

    return "\n".join(lines)


def _summarize_lockfile(lockfile: dict) -> str:
    """Create a concise text summary of a package-lock.json lockfile."""
    lines: list[str] = []
    lock_version = lockfile.get("lockfileVersion", "unknown")
    lines.append(f"lockfileVersion: {lock_version}")

    packages = lockfile.get("packages", {})
    deps = lockfile.get("dependencies", {})

    # Use packages if available (lockfileVersion 2+), fall back to dependencies
    source = packages if packages else deps
    entry_count = len(source)
    lines.append(f"total entries: {entry_count}")

    # Sample entries — enough context for LLM analysis without overwhelming the prompt
    count = 0
    for key, data in source.items():
        if count >= 100:
            lines.append(f"  ... and {entry_count - 100} more entries")
            break
        if not key:
            continue

        name = data.get("name") or key.split("node_modules/")[-1] if "/" in key else key
        version = data.get("version", "?")
        integrity = data.get("integrity", "MISSING")
        resolved = data.get("resolved", "MISSING")

        integrity_status = "present" if integrity != "MISSING" else "MISSING"
        resolved_status = _sanitize(resolved) if resolved != "MISSING" else "MISSING"

        lines.append(
            f"  {_sanitize(str(name))}@{_sanitize(str(version))} "
            f"integrity={integrity_status} resolved={resolved_status}"
        )
        count += 1

    return "\n".join(lines)


class LockfileIssue(BaseModel):
    """A single lockfile integrity issue identified by the LLM."""

    issue_type: str = Field(
        description="Type of issue: phantom_dependency, version_mismatch, "
        "missing_integrity, registry_anomaly, manual_manipulation, outdated_format"
    )
    package_name: str
    description: str = Field(description="Detailed description of the integrity issue")
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str = Field(description="Recommended fix")


class LockfileIntegrityResult(BaseModel):
    """Structured output from the lockfile integrity analysis."""

    issues: list[LockfileIssue] = []
    overall_assessment: str = ""


@AnalyzerRegistry.register
class LockfileIntegrityAnalyzer(BaseAnalyzer):
    """Verifies lockfile consistency and integrity against the manifest.

    Reads both the manifest (package.json) and lockfile (package-lock.json),
    then sends both to an LLM to check for:
    - Phantom dependencies (in lockfile but not in manifest)
    - Version mismatches between lockfile and manifest constraints
    - Missing integrity hashes
    - Registry URL anomalies
    - Signs of manual lockfile manipulation
    - Outdated lockfile format
    """

    analyzer_name = "lockfile_integrity"
    attack_vector = AttackVector.LOCKFILE_MANIPULATION
    applicable_ecosystems = [
        EcosystemName.NPM,
        EcosystemName.PYPI,
        EcosystemName.CARGO,
        EcosystemName.GO,
        EcosystemName.RUBYGEMS,
    ]
    description = (
        "Verifies lockfile integrity against the manifest to detect "
        "phantom dependencies, missing hashes, and manual tampering."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Analyze lockfile integrity against the manifest."""
        findings: list[Finding] = []

        # Resolve the target path from context
        target_path = Path(context.target.value)
        if not target_path.is_dir():
            # For non-directory targets (e.g., single lockfile), use parent
            target_path = target_path.parent

        manifest_path = target_path / "package.json"
        lockfile_path = target_path / "package-lock.json"

        manifest = _read_json_file(manifest_path)
        lockfile = _read_json_file(lockfile_path)

        if not manifest:
            logger.info(
                "No package.json found at %s, skipping lockfile integrity check", target_path
            )
            return findings

        if not lockfile:
            # Missing lockfile is itself a finding
            findings.append(
                Finding(
                    title="Missing lockfile: package-lock.json not found",
                    description=(
                        "No package-lock.json was found alongside package.json. "
                        "Without a lockfile, dependency resolution is non-deterministic "
                        "and vulnerable to version substitution attacks. An attacker could "
                        "publish a malicious version that satisfies the semver range and "
                        "it would be installed on next 'npm install'."
                    ),
                    severity=Severity.MEDIUM,
                    confidence=0.95,
                    attack_vector=AttackVector.LOCKFILE_MANIPULATION,
                    ecosystem=EcosystemName.NPM,
                    package_name=manifest.get("name", "unknown"),
                    evidence=Evidence(
                        description="package-lock.json not found in project root",
                        raw_data={
                            "manifest_path": str(manifest_path),
                            "lockfile_path": str(lockfile_path),
                        },
                    ),
                    remediation=(
                        "Run 'npm install' to generate a package-lock.json and commit it "
                        "to version control. Ensure 'package-lock.json' is not in .gitignore."
                    ),
                    cwe_ids=["CWE-345"],
                )
            )
            return findings

        # Summarize both files for the LLM (truncate to avoid prompt overflow)
        manifest_summary = _summarize_manifest(manifest)[:_MAX_FILE_CONTENT_LEN]
        lockfile_summary = _summarize_lockfile(lockfile)[:_MAX_FILE_CONTENT_LEN]

        prompt = LOCKFILE_INTEGRITY.format(
            manifest=f"<package_data>\n{manifest_summary}\n</package_data>",
            lockfile=f"<package_data>\n{lockfile_summary}\n</package_data>",
        )

        messages = [
            {"role": "system", "content": CHAINREAPER_SYSTEM},
            {"role": "user", "content": prompt},
        ]

        result = await llm.extract(
            response_model=LockfileIntegrityResult,
            messages=messages,
        )

        # Convert LLM results to findings
        for issue in result.issues:
            findings.append(
                Finding(
                    title=f"Lockfile integrity issue: {issue.issue_type} ({issue.package_name})",
                    description=(
                        f"Lockfile integrity check found a '{issue.issue_type}' issue "
                        f"affecting package '{issue.package_name}'. "
                        f"{issue.description}"
                    ),
                    severity=issue.severity,
                    confidence=issue.confidence,
                    attack_vector=AttackVector.LOCKFILE_MANIPULATION,
                    ecosystem=EcosystemName.NPM,
                    package_name=issue.package_name,
                    evidence=Evidence(
                        description=issue.description,
                        raw_data={
                            "issue_type": issue.issue_type,
                            "manifest_path": str(manifest_path),
                            "lockfile_path": str(lockfile_path),
                        },
                    ),
                    remediation=issue.remediation,
                    cwe_ids=["CWE-345"],
                )
            )

        return findings
