"""Base class and registry for attack vector analyzers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import ClassVar

from chainreaper.core.constants import AttackVector, EcosystemName
from chainreaper.core.models import AnalysisContext, Finding
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM


class BaseAnalyzer(ABC):
    """Base class for attack vector analyzers.

    Each analyzer implements one attack vector's analysis logic.
    The LLM decides WHEN to invoke each analyzer and with what parameters.
    Analyzers provide tools and data; the LLM provides reasoning.
    """

    analyzer_name: ClassVar[str]
    attack_vector: ClassVar[AttackVector]
    applicable_ecosystems: ClassVar[list[EcosystemName]]
    description: ClassVar[str] = ""

    @abstractmethod
    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Run the analysis and return findings.

        Args:
            context: Current scan context with dependency trees and prior findings
            llm: Structured LLM client for guaranteed Pydantic model responses
            router: Raw LLM router for free-form completions
        """
        ...


class AnalyzerRegistry:
    """Auto-discovery registry for analyzer plugins."""

    _registry: ClassVar[dict[str, type[BaseAnalyzer]]] = {}

    @classmethod
    def register(cls, analyzer_cls: type[BaseAnalyzer]) -> type[BaseAnalyzer]:
        """Register an analyzer plugin."""
        cls._registry[analyzer_cls.analyzer_name] = analyzer_cls
        return analyzer_cls

    @classmethod
    def get(cls, name: str) -> type[BaseAnalyzer] | None:
        """Get an analyzer by name."""
        return cls._registry.get(name)

    @classmethod
    def get_all(cls) -> dict[str, type[BaseAnalyzer]]:
        """Get all registered analyzers."""
        return dict(cls._registry)
