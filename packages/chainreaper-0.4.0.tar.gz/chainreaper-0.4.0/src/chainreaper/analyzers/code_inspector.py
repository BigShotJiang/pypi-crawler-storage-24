"""Package code inspector — downloads packages and AST-parses for suspicious patterns.

This is a SECURITY SCANNER. String literals in this file (like function names in
_SUSPICIOUS_CALLS) are detection patterns, not code to be executed.
"""

from __future__ import annotations

import ast
import io
import logging
import tarfile
import zipfile
from typing import ClassVar

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

_MAX_DOWNLOAD_SIZE = 10 * 1024 * 1024  # 10MB per package
_MAX_FILES_TO_INSPECT = 50
_MAX_SNIPPET_LEN = 2000
_MAX_DEPS_TO_INSPECT = 20


def _get_suspicious_calls() -> set[str]:
    """Return set of suspicious Python function call patterns for AST detection."""
    return {
        "eval",
        "exec",
        "compile",
        "__import__",
        "getattr",
        "setattr",
        "subprocess.run",
        "subprocess.call",
        "subprocess.Popen",
        "subprocess.check_output",
        "os.system",
        "os.popen",
        "os.environ",
        "os.getenv",
        "socket.socket",
        "socket.connect",
        "urllib.request.urlopen",
        "urllib.request.urlretrieve",
        "requests.get",
        "requests.post",
        "httpx.get",
        "httpx.post",
        "open",
        "shutil.rmtree",
        "shutil.move",
        "base64.b64decode",
        "base64.decodebytes",
        "marshal.loads",
        "ctypes.cdll",
        "ctypes.CDLL",
    }


def _get_js_patterns() -> list[str]:
    """Return list of suspicious JS/Node patterns for string detection."""
    return [
        "child_process",
        "process.env",
        "fs.readFile",
        "fs.writeFile",
        "fs.unlink",
        "http.request",
        "https.request",
        "net.connect",
        "execSync",
        "spawnSync",
    ]


CODE_INSPECTION_PROMPT = """\
Analyze the following code snippets extracted from package dependencies for suspicious behavior.

## CONTEXT
These snippets were flagged by static analysis for containing potentially suspicious patterns.
Your job is to determine which are genuinely malicious vs. benign usage.

## CODE SNIPPETS
<package_data>
{code_snippets}
</package_data>

## ANALYSIS INSTRUCTIONS
For each flagged snippet:
1. Is this a normal, expected usage of the API (e.g., open() to read config files)?
2. Or is this suspicious (e.g., dynamic code execution with decoded payloads)?
3. Does the code exfiltrate data (network calls with env vars or file contents)?
4. Does it execute dynamically constructed code with external input?
5. Does it access credentials or tokens from environment variables?
6. Is there obfuscation (base64, marshal, encoded strings)?

Only flag code that is GENUINELY suspicious. open() to read a config file is normal.
Network calls with hardcoded credentials or env var exfiltration is malicious.

Rate each finding's severity and confidence.
"""


class SuspiciousSnippet(BaseModel):
    """A code snippet flagged as suspicious by the LLM."""

    package_name: str
    file_path: str
    pattern_type: str = Field(description="e.g., network_call, env_access, obfuscation")
    code_snippet: str
    is_genuinely_suspicious: bool = Field(
        description="True if this is actually malicious, not benign"
    )
    reasoning: str
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str


class CodeInspectionResult(BaseModel):
    """Structured output from code inspection analysis."""

    findings: list[SuspiciousSnippet] = []
    overall_assessment: str = ""


class _StaticFinding:
    """A suspicious pattern found by static analysis (pre-LLM)."""

    def __init__(
        self, package_name: str, file_path: str, pattern: str, snippet: str, line: int
    ) -> None:
        self.package_name = package_name
        self.file_path = file_path
        self.pattern = pattern
        self.snippet = snippet[:_MAX_SNIPPET_LEN]
        self.line = line


def _analyze_python_ast(source: str, file_path: str, package_name: str) -> list[_StaticFinding]:
    """AST-parse Python source for suspicious function calls."""
    suspicious = _get_suspicious_calls()
    findings: list[_StaticFinding] = []
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return findings

    lines = source.splitlines()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            call_name = _resolve_call_name(node)
            if call_name and call_name in suspicious:
                lineno = getattr(node, "lineno", 0)
                start = max(0, lineno - 2)
                end = min(len(lines), lineno + 3)
                snippet = "\n".join(lines[start:end])
                findings.append(_StaticFinding(package_name, file_path, call_name, snippet, lineno))
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name in ("ctypes", "marshal", "subprocess"):
                    lineno = getattr(node, "lineno", 0)
                    findings.append(
                        _StaticFinding(
                            package_name,
                            file_path,
                            f"import:{alias.name}",
                            f"import {alias.name}",
                            lineno,
                        )
                    )
    return findings


def _resolve_call_name(node: ast.Call) -> str | None:
    """Resolve a Call node to a dotted name string."""
    func = node.func
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        parts: list[str] = []
        current = func
        while isinstance(current, ast.Attribute):
            parts.append(current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.append(current.id)
            return ".".join(reversed(parts))
    return None


def _analyze_js_source(source: str, file_path: str, package_name: str) -> list[_StaticFinding]:
    """String-match JS/Node source for suspicious patterns."""
    patterns = _get_js_patterns()
    findings: list[_StaticFinding] = []
    lines = source.splitlines()
    for i, line in enumerate(lines):
        for pattern in patterns:
            if pattern in line:
                start = max(0, i - 1)
                end = min(len(lines), i + 4)
                snippet = "\n".join(lines[start:end])
                findings.append(_StaticFinding(package_name, file_path, pattern, snippet, i + 1))
                break
    return findings


def _extract_and_inspect_tarball(
    data: bytes, package_name: str, ecosystem: EcosystemName
) -> list[_StaticFinding]:
    """Extract a .tgz and inspect source files."""
    findings: list[_StaticFinding] = []
    try:
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tar:
            inspected = 0
            for member in tar.getmembers():
                if inspected >= _MAX_FILES_TO_INSPECT:
                    break
                if not member.isfile() or member.size > _MAX_DOWNLOAD_SIZE:
                    continue
                name_lower = member.name.lower()
                if name_lower.endswith((".py", ".pyi")):
                    f = tar.extractfile(member)
                    if f:
                        source = f.read().decode("utf-8", errors="replace")
                        findings.extend(_analyze_python_ast(source, member.name, package_name))
                        inspected += 1
                elif name_lower.endswith((".js", ".mjs", ".cjs")):
                    f = tar.extractfile(member)
                    if f:
                        source = f.read().decode("utf-8", errors="replace")
                        findings.extend(_analyze_js_source(source, member.name, package_name))
                        inspected += 1
    except (tarfile.TarError, OSError) as e:
        logger.warning("Failed to extract tarball for %s: %s", package_name, e)
    return findings


def _extract_and_inspect_wheel(data: bytes, package_name: str) -> list[_StaticFinding]:
    """Extract a .whl (zip) and inspect Python source files."""
    findings: list[_StaticFinding] = []
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            inspected = 0
            for info in zf.infolist():
                if inspected >= _MAX_FILES_TO_INSPECT:
                    break
                if info.is_dir() or info.file_size > _MAX_DOWNLOAD_SIZE:
                    continue
                if info.filename.lower().endswith((".py", ".pyi")):
                    source = zf.read(info.filename).decode("utf-8", errors="replace")
                    findings.extend(_analyze_python_ast(source, info.filename, package_name))
                    inspected += 1
    except (zipfile.BadZipFile, OSError) as e:
        logger.warning("Failed to extract wheel for %s: %s", package_name, e)
    return findings


async def _resolve_npm_version(client: "httpx.AsyncClient", name: str, spec: str) -> str | None:
    """Resolve a semver range like '^2.6.9' to an exact version via npm registry."""
    from urllib.parse import quote

    encoded = quote(name, safe="@")
    # For exact versions (digits only), return as-is
    if spec and spec[0].isdigit() and all(c in "0123456789." for c in spec):
        return spec
    # Fetch latest version from registry
    try:
        resp = await client.get(f"https://registry.npmjs.org/{encoded}/latest")
        if resp.status_code == 200:
            return resp.json().get("version")
    except Exception:
        pass
    return None


async def _download_package(
    package_name: str,
    package_version: str,
    ecosystem: EcosystemName,
) -> tuple[bytes | None, str]:
    """Download package archive from registry. Returns (data, archive_type).

    Handles semver ranges by resolving to latest version when needed.
    """
    from urllib.parse import quote, urlparse

    import httpx

    async with httpx.AsyncClient(follow_redirects=False, timeout=15.0) as client:
        if ecosystem == EcosystemName.NPM:
            # Resolve semver ranges to exact versions
            version = package_version
            if version and not (version[0].isdigit() and all(c in "0123456789." for c in version)):
                resolved = await _resolve_npm_version(client, package_name, version)
                if resolved:
                    version = resolved
                else:
                    logger.debug("Could not resolve version %s for %s", version, package_name)
                    return None, ""

            encoded = quote(package_name, safe="@")
            url = f"https://registry.npmjs.org/{encoded}/{version}"
            try:
                resp = await client.get(url)
                if resp.status_code != 200:
                    return None, ""
                tarball_url = resp.json().get("dist", {}).get("tarball")
                if not tarball_url:
                    return None, ""
                parsed = urlparse(tarball_url)
                if parsed.hostname not in ("registry.npmjs.org", "registry.yarnpkg.com"):
                    logger.warning("Rejecting npm tarball URL: %s", parsed.hostname)
                    return None, ""
                dl_resp = await client.get(tarball_url)
                if dl_resp.status_code == 200 and len(dl_resp.content) <= _MAX_DOWNLOAD_SIZE:
                    return dl_resp.content, "tgz"
            except (httpx.HTTPError, Exception) as e:
                logger.warning("Failed to download npm package %s: %s", package_name, e)

        elif ecosystem == EcosystemName.PYPI:
            # For PyPI, try exact version first, then fall back to latest
            version = package_version
            url = f"https://pypi.org/pypi/{package_name}/{version}/json"
            try:
                resp = await client.get(url)
                if resp.status_code != 200:
                    # Version spec isn't exact — try latest
                    resp = await client.get(f"https://pypi.org/pypi/{package_name}/json")
                    if resp.status_code != 200:
                        return None, ""
                for pkg_url in resp.json().get("urls", []):
                    filename = pkg_url.get("filename", "")
                    download_url = pkg_url.get("url", "")
                    parsed = urlparse(download_url)
                    if parsed.hostname not in ("files.pythonhosted.org", "pypi.org"):
                        continue
                    if filename.endswith(".whl") or filename.endswith(".tar.gz"):
                        dl_resp = await client.get(download_url)
                        if (
                            dl_resp.status_code == 200
                            and len(dl_resp.content) <= _MAX_DOWNLOAD_SIZE
                        ):
                            ext = "whl" if filename.endswith(".whl") else "tgz"
                            return dl_resp.content, ext
            except (httpx.HTTPError, Exception) as e:
                logger.warning("Failed to download PyPI package %s: %s", package_name, e)

    return None, ""


@AnalyzerRegistry.register
class CodeInspectorAnalyzer(BaseAnalyzer):
    """Downloads and inspects actual package source code for suspicious patterns.

    Phase 1: Static analysis via AST parsing (Python) and string matching (JS)
    Phase 2: LLM reviews flagged snippets to filter false positives
    """

    analyzer_name: ClassVar[str] = "code_inspector"
    attack_vector: ClassVar[AttackVector] = AttackVector.CODE_INSPECTION
    applicable_ecosystems: ClassVar[list[EcosystemName]] = [EcosystemName.NPM, EcosystemName.PYPI]
    description: ClassVar[str] = (
        "Downloads actual package archives, extracts source code, and uses AST parsing "
        "to detect suspicious patterns (dynamic code execution, network calls, env access, "
        "obfuscation). LLM reviews flagged snippets to filter false positives."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Download packages, AST-parse, then LLM-review flagged code."""
        all_static: list[_StaticFinding] = []
        last_eco = EcosystemName.NPM

        for tree in context.dependency_trees:
            if tree.ecosystem not in (EcosystemName.NPM, EcosystemName.PYPI):
                continue
            last_eco = tree.ecosystem
            for dep in tree.direct_dependencies[:_MAX_DEPS_TO_INSPECT]:
                if not dep.version:
                    continue
                data, atype = await _download_package(dep.name, dep.version, tree.ecosystem)
                if not data:
                    continue
                if atype == "tgz":
                    all_static.extend(_extract_and_inspect_tarball(data, dep.name, tree.ecosystem))
                elif atype == "whl":
                    all_static.extend(_extract_and_inspect_wheel(data, dep.name))

        if not all_static:
            return []

        snippets_text = "\n\n".join(
            f"### {sf.package_name} -- {sf.file_path}:{sf.line}\n"
            f"Pattern: {sf.pattern}\n```\n{sf.snippet}\n```"
            for sf in all_static[:30]
        )
        prompt = CODE_INSPECTION_PROMPT.format(code_snippets=snippets_text)
        messages = [
            {"role": "system", "content": CHAINREAPER_SYSTEM},
            {"role": "user", "content": prompt},
        ]

        try:
            result = await llm.extract(response_model=CodeInspectionResult, messages=messages)
        except Exception as e:
            logger.warning("Code inspection LLM analysis failed: %s", e)
            return []

        findings: list[Finding] = []
        for s in result.findings:
            if not s.is_genuinely_suspicious:
                continue
            findings.append(
                Finding(
                    title=f"Suspicious code in {s.package_name}: {s.pattern_type}",
                    description=(
                        f"Static analysis flagged suspicious code in {s.package_name} "
                        f"({s.file_path}): {s.reasoning}"
                    ),
                    severity=s.severity,
                    confidence=s.confidence,
                    attack_vector=AttackVector.CODE_INSPECTION,
                    ecosystem=last_eco,
                    package_name=s.package_name,
                    evidence=Evidence(
                        description=s.reasoning,
                        raw_data={
                            "file_path": s.file_path,
                            "pattern_type": s.pattern_type,
                            "code_snippet": s.code_snippet[:500],
                        },
                    ),
                    remediation=s.remediation,
                    cwe_ids=["CWE-506"],
                )
            )
        return findings
