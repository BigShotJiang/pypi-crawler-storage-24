"""Compromised maintainer analyzer — assesses maintainer trust signals for supply chain risk."""

from __future__ import annotations

import logging

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.ecosystems.base import EcosystemRegistry
from chainreaper.llm.prompts.analysis import COMPROMISED_MAINTAINER
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

# Max length for package names/usernames in prompts to prevent abuse
_MAX_NAME_LEN = 214


def _sanitize(value: str) -> str:
    """Sanitize untrusted data before including in LLM prompts."""
    clean = value[:_MAX_NAME_LEN].strip()
    clean = "".join(c for c in clean if c.isprintable())
    return clean


class MaintainerAssessment(BaseModel):
    """A single maintainer trust assessment identified by the LLM."""

    package_name: str
    maintainer_username: str
    risk_level: str = Field(description="Risk level: low, medium, high, critical")
    concerns: list[str] = Field(
        default_factory=list,
        description="Specific concerns about this maintainer's trustworthiness",
    )
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str = Field(description="Recommended fix")


class MaintainerAnalysisResult(BaseModel):
    """Structured output from the compromised maintainer analysis."""

    assessments: list[MaintainerAssessment] = []
    overall_assessment: str = ""


@AnalyzerRegistry.register
class CompromisedMaintainerAnalyzer(BaseAnalyzer):
    """Assesses maintainer trust signals for potential account compromise.

    Analyzes maintainer metadata (account age, 2FA status, package count,
    activity patterns) to identify accounts that may have been compromised
    or are high-risk for takeover.  Sends the collected data to an LLM for
    contextual risk assessment.
    """

    analyzer_name = "compromised_maintainer"
    attack_vector = AttackVector.COMPROMISED_MAINTAINER
    applicable_ecosystems = [
        EcosystemName.NPM,
        EcosystemName.PYPI,
        EcosystemName.RUBYGEMS,
        EcosystemName.CARGO,
    ]
    description = (
        "Assesses maintainer trust signals to identify compromised or high-risk "
        "maintainer accounts in the dependency tree."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Analyze dependencies for compromised maintainer risks."""
        findings: list[Finding] = []

        for tree in context.dependency_trees:
            eco_cls = EcosystemRegistry.get(tree.ecosystem.value)
            if not eco_cls:
                continue

            eco = eco_cls()

            # Gather maintainer info for each dependency
            maintainer_entries: list[dict[str, object]] = []
            all_deps = tree.direct_dependencies + tree.transitive_dependencies

            for dep in all_deps[:50]:  # Limit to prevent excessive API calls
                maintainers = await eco.get_maintainer_info(dep.name)
                if not maintainers:
                    continue

                for m in maintainers:
                    maintainer_entries.append(
                        {
                            "package_name": dep.name,
                            "package_version": dep.version,
                            "is_direct": dep.is_direct,
                            "username": m.username,
                            "email": m.email or "unknown",
                            "package_count": m.package_count,
                            "account_age_days": m.account_age_days,
                            "has_2fa": m.has_2fa,
                        }
                    )

            if not maintainer_entries:
                continue

            # Wrap untrusted data in XML tags for prompt injection defense
            maintainer_text = "\n".join(
                f"- package={_sanitize(str(e['package_name']))}@"
                f"{_sanitize(str(e['package_version']))} "
                f"maintainer={_sanitize(str(e['username']))} "
                f"email={_sanitize(str(e['email']))} "
                f"packages={e['package_count']} "
                f"account_age_days={e['account_age_days']} "
                f"has_2fa={e['has_2fa']} "
                f"direct={e['is_direct']}"
                for e in maintainer_entries
            )

            prompt = COMPROMISED_MAINTAINER.format(
                maintainer_data=f"<package_data>\n{maintainer_text}\n</package_data>",
            )

            messages = [
                {"role": "system", "content": CHAINREAPER_SYSTEM},
                {"role": "user", "content": prompt},
            ]

            result = await llm.extract(
                response_model=MaintainerAnalysisResult,
                messages=messages,
            )

            # Convert LLM results to findings — only emit for medium+ risk
            for assessment in result.assessments:
                if assessment.risk_level in ("medium", "high", "critical") and assessment.concerns:
                    findings.append(
                        Finding(
                            title=(
                                f"Compromised maintainer risk: "
                                f"{assessment.maintainer_username} "
                                f"({assessment.package_name})"
                            ),
                            description=(
                                f"Maintainer '{assessment.maintainer_username}' of package "
                                f"'{assessment.package_name}' shows concerning trust signals. "
                                f"Risk level: {assessment.risk_level}. "
                                f"Concerns: {'; '.join(assessment.concerns)}"
                            ),
                            severity=assessment.severity,
                            confidence=assessment.confidence,
                            attack_vector=AttackVector.COMPROMISED_MAINTAINER,
                            ecosystem=tree.ecosystem,
                            package_name=assessment.package_name,
                            evidence=Evidence(
                                description=f"Maintainer trust assessment for {assessment.maintainer_username}",
                                raw_data={
                                    "maintainer": assessment.maintainer_username,
                                    "risk_level": assessment.risk_level,
                                    "concerns": assessment.concerns,
                                },
                            ),
                            remediation=assessment.remediation,
                            cwe_ids=["CWE-522"],
                            package_url=f"{eco.registry_url}/{assessment.package_name}",
                            package_registry_url=eco.registry_url,
                        )
                    )

        return findings
