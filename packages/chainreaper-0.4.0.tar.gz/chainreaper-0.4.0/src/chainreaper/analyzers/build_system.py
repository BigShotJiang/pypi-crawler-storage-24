"""Build system analyzer — detects CI/CD pipeline poisoning risks."""

from __future__ import annotations

import logging
from pathlib import Path

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.llm.prompts.analysis import BUILD_SYSTEM
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

# Max length for file content in prompts to prevent abuse
_MAX_NAME_LEN = 214
# Max size for CI config file content sent to the LLM (characters)
_MAX_FILE_CONTENT_LEN = 30_000
# Max file size to read from disk (bytes)
_MAX_FILE_SIZE_BYTES = 5_000_000

# CI/CD config file patterns to search for
_CI_CONFIG_PATTERNS: list[tuple[str, str]] = [
    (".github/workflows", "GitHub Actions"),
    (".gitlab-ci.yml", "GitLab CI"),
    ("Jenkinsfile", "Jenkins"),
    (".circleci", "CircleCI"),
    (".travis.yml", "Travis CI"),
    ("azure-pipelines.yml", "Azure Pipelines"),
    ("bitbucket-pipelines.yml", "Bitbucket Pipelines"),
    (".buildkite", "Buildkite"),
]


def _sanitize(value: str) -> str:
    """Sanitize untrusted data before including in LLM prompts."""
    clean = value[:_MAX_NAME_LEN].strip()
    clean = "".join(c for c in clean if c.isprintable())
    return clean


def _read_file_safe(path: Path) -> str | None:
    """Safely read a file with size limits."""
    if not path.exists() or not path.is_file():
        return None
    try:
        if path.stat().st_size > _MAX_FILE_SIZE_BYTES:
            logger.warning("CI config file exceeds size limit, skipping: %s", path)
            return None
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        logger.warning("Failed to read %s: %s", path, e)
        return None


def _discover_ci_configs(target_path: Path) -> list[dict[str, str]]:
    """Discover CI/CD configuration files in the target directory.

    Returns a list of dicts with keys: file_path, ci_system, content.
    """
    configs: list[dict[str, str]] = []

    for pattern, ci_system in _CI_CONFIG_PATTERNS:
        full_path = target_path / pattern

        if full_path.is_dir():
            # Directory-based configs (e.g., .github/workflows/, .circleci/)
            for child in sorted(full_path.rglob("*")):
                if child.is_file() and child.suffix in (".yml", ".yaml", ""):
                    content = _read_file_safe(child)
                    if content:
                        rel_path = str(child.relative_to(target_path))
                        configs.append(
                            {
                                "file_path": rel_path,
                                "ci_system": ci_system,
                                "content": content[:_MAX_FILE_CONTENT_LEN],
                            }
                        )
        elif full_path.is_file():
            # Single-file configs (e.g., .gitlab-ci.yml, Jenkinsfile)
            content = _read_file_safe(full_path)
            if content:
                configs.append(
                    {
                        "file_path": pattern,
                        "ci_system": ci_system,
                        "content": content[:_MAX_FILE_CONTENT_LEN],
                    }
                )

    return configs


class BuildSystemIssue(BaseModel):
    """A single CI/CD pipeline security issue identified by the LLM."""

    file_path: str = Field(description="Path to the CI config file with the issue")
    issue_type: str = Field(
        description="Type of issue: unpinned_action, secret_exposure, workflow_injection, "
        "overpermissive_token, insecure_runner, code_injection, artifact_poisoning"
    )
    description: str = Field(description="Detailed description of the security issue")
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str = Field(description="Recommended fix")


class BuildSystemResult(BaseModel):
    """Structured output from the build system analysis."""

    issues: list[BuildSystemIssue] = []
    overall_assessment: str = ""


@AnalyzerRegistry.register
class BuildSystemAnalyzer(BaseAnalyzer):
    """Detects CI/CD pipeline poisoning risks in build system configurations.

    Scans for CI/CD configuration files (.github/workflows/, .gitlab-ci.yml,
    Jenkinsfile, .circleci/, etc.) and sends them to an LLM to check for:
    - Unpinned action/image versions (tag-based instead of SHA-pinned)
    - Secret exposure in logs or environment variables
    - Workflow injection via untrusted inputs (e.g., pull_request_target)
    - Over-permissive GITHUB_TOKEN or service account permissions
    - Insecure runner configurations
    - Artifact poisoning vectors
    """

    analyzer_name = "build_system"
    attack_vector = AttackVector.BUILD_SYSTEM
    applicable_ecosystems = [
        EcosystemName.NPM,
        EcosystemName.PYPI,
        EcosystemName.MAVEN,
        EcosystemName.GO,
        EcosystemName.CARGO,
        EcosystemName.RUBYGEMS,
        EcosystemName.NUGET,
    ]
    description = (
        "Detects CI/CD pipeline poisoning risks including unpinned actions, "
        "secret exposure, workflow injection, and over-permissive tokens."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Analyze CI/CD configurations for build system attack vectors."""
        findings: list[Finding] = []

        # Resolve the target path from context
        target_path = Path(context.target.value)
        if not target_path.is_dir():
            target_path = target_path.parent

        # Discover CI/CD config files
        ci_configs = _discover_ci_configs(target_path)
        if not ci_configs:
            logger.info(
                "No CI/CD config files found at %s, skipping build system analysis", target_path
            )
            return findings

        # Cap at 20 config files to avoid overwhelming the LLM
        ci_configs = ci_configs[:20]

        # Build prompt text with sanitized file contents
        configs_text_parts: list[str] = []
        for config in ci_configs:
            # Sanitize file content — it's untrusted
            sanitized_content = "".join(
                c for c in config["content"] if c.isprintable() or c in ("\n", "\t", " ")
            )
            configs_text_parts.append(
                f"### File: {_sanitize(config['file_path'])} "
                f"(CI System: {_sanitize(config['ci_system'])})\n"
                f"```\n{sanitized_content[:_MAX_FILE_CONTENT_LEN]}\n```"
            )

        configs_text = "\n\n".join(configs_text_parts)

        # Determine ecosystems present for context
        ecosystems_present = ", ".join(tree.ecosystem.value for tree in context.dependency_trees)

        prompt = BUILD_SYSTEM.format(
            ci_configs=f"<package_data>\n{configs_text}\n</package_data>",
            ecosystems=ecosystems_present or "unknown",
            config_count=len(ci_configs),
        )

        messages = [
            {"role": "system", "content": CHAINREAPER_SYSTEM},
            {"role": "user", "content": prompt},
        ]

        result = await llm.extract(
            response_model=BuildSystemResult,
            messages=messages,
        )

        # Convert LLM results to findings
        for issue in result.issues:
            findings.append(
                Finding(
                    title=f"Build system risk: {issue.issue_type} in {issue.file_path}",
                    description=(
                        f"CI/CD configuration file '{issue.file_path}' contains a "
                        f"'{issue.issue_type}' security issue. Build system attacks can "
                        f"compromise the entire software supply chain by injecting malicious "
                        f"code during the build or deployment process. {issue.description}"
                    ),
                    severity=issue.severity,
                    confidence=issue.confidence,
                    attack_vector=AttackVector.BUILD_SYSTEM,
                    ecosystem=(
                        context.dependency_trees[0].ecosystem
                        if context.dependency_trees
                        else EcosystemName.NPM
                    ),
                    package_name=_sanitize(issue.file_path),
                    evidence=Evidence(
                        description=issue.description,
                        raw_data={
                            "file_path": issue.file_path,
                            "issue_type": issue.issue_type,
                            "ci_configs_scanned": len(ci_configs),
                        },
                    ),
                    remediation=issue.remediation,
                    cwe_ids=["CWE-829"],
                )
            )

        return findings
