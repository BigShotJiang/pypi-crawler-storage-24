"""Typosquatting analyzer — detects dependencies with names suspiciously similar to popular packages."""

from __future__ import annotations

import logging

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.llm.prompts.analysis import TYPOSQUATTING
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

# Max length for package names/versions in prompts to prevent abuse
_MAX_NAME_LEN = 214

_ECO_REGISTRIES: dict[str, str] = {
    "npm": "https://www.npmjs.com/package",
    "pypi": "https://pypi.org/project",
    "maven": "https://search.maven.org/artifact",
    "go": "https://pkg.go.dev",
    "cargo": "https://crates.io/crates",
    "rubygems": "https://rubygems.org/gems",
    "nuget": "https://www.nuget.org/packages",
}


def _eco_url(ecosystem: EcosystemName, package_name: str) -> str:
    base = _ECO_REGISTRIES.get(ecosystem.value, "")
    return f"{base}/{package_name}" if base else ""


# Popular packages per ecosystem to check against for typosquatting
_POPULAR_PACKAGES_BY_ECO: dict[str, list[str]] = {
    "npm": [
        "express",
        "lodash",
        "react",
        "axios",
        "moment",
        "request",
        "chalk",
        "debug",
        "commander",
        "inquirer",
        "webpack",
        "babel",
        "eslint",
        "jest",
        "mocha",
        "gulp",
        "grunt",
        "underscore",
        "async",
        "bluebird",
    ],
    "pypi": [
        "requests",
        "flask",
        "django",
        "numpy",
        "pandas",
        "scipy",
        "tensorflow",
        "torch",
        "boto3",
        "sqlalchemy",
        "celery",
        "fastapi",
        "pydantic",
        "httpx",
        "pillow",
        "cryptography",
        "paramiko",
        "beautifulsoup4",
    ],
    "maven": [
        "spring-core",
        "spring-boot",
        "jackson-databind",
        "guava",
        "slf4j-api",
        "log4j-core",
        "commons-lang3",
        "commons-io",
        "junit",
        "mockito-core",
        "gson",
        "httpclient",
        "lombok",
        "netty-all",
        "hibernate-core",
    ],
    "go": [
        "github.com/gin-gonic/gin",
        "github.com/gorilla/mux",
        "github.com/stretchr/testify",
        "github.com/spf13/cobra",
        "github.com/spf13/viper",
        "google.golang.org/grpc",
        "github.com/sirupsen/logrus",
        "github.com/go-sql-driver/mysql",
    ],
    "cargo": [
        "serde",
        "tokio",
        "reqwest",
        "clap",
        "rand",
        "log",
        "regex",
        "hyper",
        "actix-web",
        "diesel",
        "rocket",
        "warp",
        "axum",
        "tracing",
    ],
    "rubygems": [
        "rails",
        "devise",
        "sidekiq",
        "puma",
        "nokogiri",
        "rspec",
        "sinatra",
        "pg",
        "redis",
        "rack",
        "capistrano",
        "rubocop",
        "jwt",
        "faraday",
    ],
    "nuget": [
        "Newtonsoft.Json",
        "Serilog",
        "AutoMapper",
        "MediatR",
        "Dapper",
        "FluentValidation",
        "xunit",
        "NUnit",
        "Moq",
        "EntityFramework",
    ],
}

# Flattened list for backward compat
_POPULAR_PACKAGES = [pkg for pkgs in _POPULAR_PACKAGES_BY_ECO.values() for pkg in pkgs]

# Maximum Levenshtein distance to consider as a potential typosquat
_MAX_DISTANCE_THRESHOLD = 2


def _sanitize(value: str) -> str:
    """Sanitize untrusted data before including in LLM prompts."""
    clean = value[:_MAX_NAME_LEN].strip()
    clean = "".join(c for c in clean if c.isprintable())
    return clean


def _levenshtein_distance(s1: str, s2: str) -> int:
    """Compute the Levenshtein edit distance between two strings."""
    if len(s1) < len(s2):
        return _levenshtein_distance(s2, s1)

    if len(s2) == 0:
        return len(s1)

    previous_row = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            # Insertions, deletions, substitutions
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row

    return previous_row[-1]


class TyposquatCandidate(BaseModel):
    """A single typosquatting candidate identified by the LLM."""

    package_name: str
    similar_to: str = Field(description="The popular package this is similar to")
    distance: int = Field(description="Levenshtein distance to the popular package")
    is_likely_typosquat: bool = Field(
        description="Whether this is likely a malicious typosquat vs a legitimate package"
    )
    reasoning: str = Field(description="Why this is or isn't a typosquat")
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str = Field(description="Recommended fix")


class TyposquattingResult(BaseModel):
    """Structured output from the typosquatting analysis."""

    candidates: list[TyposquatCandidate] = []
    overall_assessment: str = ""


@AnalyzerRegistry.register
class TyposquattingAnalyzer(BaseAnalyzer):
    """Detects dependencies with names suspiciously similar to popular packages.

    Uses Levenshtein distance to find dependencies that are close (but not
    identical) to well-known packages.  Then sends the candidates to an LLM
    to reason about whether the similarity is a genuine typosquat or a
    legitimate, unrelated package.
    """

    analyzer_name = "typosquatting"
    attack_vector = AttackVector.TYPOSQUATTING
    applicable_ecosystems = [
        EcosystemName.NPM,
        EcosystemName.PYPI,
        EcosystemName.MAVEN,
        EcosystemName.GO,
        EcosystemName.CARGO,
        EcosystemName.RUBYGEMS,
        EcosystemName.NUGET,
    ]
    description = (
        "Detects dependencies with names suspiciously similar to popular packages, "
        "indicating potential typosquatting attacks."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Analyze dependencies for typosquatting vulnerabilities."""
        findings: list[Finding] = []

        for tree in context.dependency_trees:
            all_deps = tree.direct_dependencies + tree.transitive_dependencies
            if not all_deps:
                continue

            # Pre-filter: find deps within Levenshtein distance threshold of popular packages
            suspects: list[dict[str, object]] = []
            for dep in all_deps[:200]:  # Limit to prevent excessive computation
                dep_name_lower = dep.name.lower().split("/")[-1]  # Handle scoped packages
                for popular in _POPULAR_PACKAGES:
                    # Skip exact matches — those are legitimate
                    if dep_name_lower == popular:
                        continue
                    dist = _levenshtein_distance(dep_name_lower, popular)
                    if 0 < dist <= _MAX_DISTANCE_THRESHOLD:
                        suspects.append(
                            {
                                "name": dep.name,
                                "version": dep.version,
                                "similar_to": popular,
                                "distance": dist,
                                "is_direct": dep.is_direct,
                            }
                        )
                        break  # One match per dep is enough

            if not suspects:
                continue

            # Wrap untrusted package data in XML tags for prompt injection defense
            packages_text = "\n".join(
                f"- {_sanitize(str(s['name']))}@{_sanitize(str(s['version']))} "
                f"(similar_to={s['similar_to']}, distance={s['distance']}, "
                f"direct={s['is_direct']})"
                for s in suspects
            )

            prompt = TYPOSQUATTING.format(
                packages=f"<package_data>\n{packages_text}\n</package_data>",
            )

            messages = [
                {"role": "system", "content": CHAINREAPER_SYSTEM},
                {"role": "user", "content": prompt},
            ]

            result = await llm.extract(
                response_model=TyposquattingResult,
                messages=messages,
            )

            # Convert LLM results to findings
            for candidate in result.candidates:
                if candidate.is_likely_typosquat:
                    findings.append(
                        Finding(
                            title=f"Typosquatting risk: {candidate.package_name}",
                            description=(
                                f"Package '{candidate.package_name}' has a name suspiciously "
                                f"similar to the popular package '{candidate.similar_to}' "
                                f"(Levenshtein distance: {candidate.distance}). "
                                f"This may be a typosquatting attack designed to trick "
                                f"developers into installing a malicious package. "
                                f"Reasoning: {candidate.reasoning}"
                            ),
                            severity=candidate.severity,
                            confidence=candidate.confidence,
                            attack_vector=AttackVector.TYPOSQUATTING,
                            ecosystem=tree.ecosystem,
                            package_name=candidate.package_name,
                            evidence=Evidence(
                                description=candidate.reasoning,
                                raw_data={
                                    "similar_to": candidate.similar_to,
                                    "levenshtein_distance": candidate.distance,
                                    "analysis": candidate.reasoning,
                                },
                            ),
                            remediation=candidate.remediation,
                            cwe_ids=["CWE-349"],
                            package_url=_eco_url(tree.ecosystem, candidate.package_name),
                            package_registry_url=_ECO_REGISTRIES.get(tree.ecosystem.value, ""),
                        )
                    )

        return findings
