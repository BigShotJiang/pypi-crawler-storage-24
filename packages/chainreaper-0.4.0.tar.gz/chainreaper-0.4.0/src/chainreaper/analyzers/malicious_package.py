"""Malicious package analyzer — detects packages with indicators of intentional malice."""

from __future__ import annotations

import logging

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.ecosystems.base import EcosystemRegistry
from chainreaper.llm.prompts.analysis import MALICIOUS_PACKAGE
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

# Max length for package names/descriptions in prompts to prevent abuse
_MAX_NAME_LEN = 214
_MAX_DESC_LEN = 500


def _sanitize(value: str, max_len: int = _MAX_NAME_LEN) -> str:
    """Sanitize untrusted data before including in LLM prompts."""
    clean = value[:max_len].strip()
    clean = "".join(c for c in clean if c.isprintable())
    return clean


class MaliciousSuspect(BaseModel):
    """A single package suspected of being malicious, identified by the LLM."""

    package_name: str
    indicator_type: str = Field(
        description="Type of malicious indicator: bot_inflation, obfuscated_code, "
        "unauthorized_access, name_description_mismatch, suspicious_metadata, "
        "known_malware_pattern, data_exfiltration"
    )
    reasoning: str = Field(description="Why this package appears malicious")
    is_likely_malicious: bool = Field(
        description="Whether the LLM assesses this as likely malicious"
    )
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str = Field(description="Recommended fix")


class MaliciousPackageResult(BaseModel):
    """Structured output from the malicious package analysis."""

    suspects: list[MaliciousSuspect] = []
    overall_assessment: str = ""


@AnalyzerRegistry.register
class MaliciousPackageAnalyzer(BaseAnalyzer):
    """Detects packages with indicators of intentional malicious behavior.

    Uses package metadata from the registry to identify suspicious patterns
    such as:
    - Very new packages with artificially inflated download counts
    - Packages with obfuscated code indicators in their metadata
    - Packages that access network/filesystem/env vars unnecessarily
    - Packages whose description doesn't match their name or purpose
    - Packages matching known malware distribution patterns

    Sends the collected metadata to an LLM for contextual analysis.
    """

    analyzer_name = "malicious_package"
    attack_vector = AttackVector.MALICIOUS_PACKAGE
    applicable_ecosystems = [
        EcosystemName.NPM,
        EcosystemName.PYPI,
        EcosystemName.MAVEN,
        EcosystemName.GO,
        EcosystemName.CARGO,
        EcosystemName.RUBYGEMS,
        EcosystemName.NUGET,
    ]
    description = (
        "Detects packages with indicators of intentional malicious behavior "
        "including bot-inflated downloads, obfuscated code, and suspicious metadata."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Analyze dependencies for malicious package indicators."""
        findings: list[Finding] = []

        for tree in context.dependency_trees:
            eco_cls = EcosystemRegistry.get(tree.ecosystem.value)
            if not eco_cls:
                continue

            eco = eco_cls()

            # Gather package metadata for analysis
            packages_info: list[dict[str, object]] = []
            all_deps = tree.direct_dependencies + tree.transitive_dependencies

            for dep in all_deps[:80]:  # Limit to prevent excessive API calls
                metadata = await eco.get_package_metadata(dep.name)
                if not metadata:
                    continue

                packages_info.append(
                    {
                        "name": dep.name,
                        "version": dep.version,
                        "is_direct": dep.is_direct,
                        "description": metadata.description,
                        "maintainer_count": len(metadata.maintainers),
                        "repository_url": metadata.repository_url or "none",
                        "publish_date": (
                            metadata.publish_date.isoformat()
                            if metadata.publish_date
                            else "unknown"
                        ),
                        "download_count": metadata.download_count,
                        "has_install_scripts": metadata.has_install_scripts,
                        "license": metadata.license or "unknown",
                    }
                )

            if not packages_info:
                continue

            # Wrap untrusted package data in XML tags for prompt injection defense
            packages_text = "\n".join(
                f"- {_sanitize(str(p['name']))}@{_sanitize(str(p['version']))} "
                f"(direct={p['is_direct']}, "
                f"description={_sanitize(str(p['description']), _MAX_DESC_LEN)}, "
                f"maintainers={p['maintainer_count']}, "
                f"repo={_sanitize(str(p['repository_url']))}, "
                f"published={p['publish_date']}, "
                f"downloads={p['download_count']}, "
                f"install_scripts={p['has_install_scripts']}, "
                f"license={_sanitize(str(p['license']))})"
                for p in packages_info
            )

            prompt = MALICIOUS_PACKAGE.format(
                ecosystem=tree.ecosystem.value,
                package_count=len(packages_info),
                packages=f"<package_data>\n{packages_text}\n</package_data>",
            )

            messages = [
                {"role": "system", "content": CHAINREAPER_SYSTEM},
                {"role": "user", "content": prompt},
            ]

            result = await llm.extract(
                response_model=MaliciousPackageResult,
                messages=messages,
            )

            # Convert LLM results to findings
            for suspect in result.suspects:
                if suspect.is_likely_malicious:
                    findings.append(
                        Finding(
                            title=f"Malicious package suspect: {suspect.package_name}",
                            description=(
                                f"Package '{suspect.package_name}' shows indicators of "
                                f"intentional malicious behavior. Indicator type: "
                                f"{suspect.indicator_type}. Malicious packages can steal "
                                f"credentials, exfiltrate data, install backdoors, or "
                                f"perform cryptocurrency mining on build/deployment systems. "
                                f"Reasoning: {suspect.reasoning}"
                            ),
                            severity=suspect.severity,
                            confidence=suspect.confidence,
                            attack_vector=AttackVector.MALICIOUS_PACKAGE,
                            ecosystem=tree.ecosystem,
                            package_name=suspect.package_name,
                            evidence=Evidence(
                                description=suspect.reasoning,
                                raw_data={
                                    "indicator_type": suspect.indicator_type,
                                    "is_likely_malicious": suspect.is_likely_malicious,
                                    "analysis": suspect.reasoning,
                                },
                            ),
                            remediation=suspect.remediation,
                            cwe_ids=["CWE-506"],
                            package_url=f"{eco.registry_url}/{suspect.package_name}",
                            package_registry_url=eco.registry_url,
                        )
                    )

        return findings
