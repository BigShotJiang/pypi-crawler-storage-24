"""Auto-discovery for analyzer plugins. Import all analyzers to register them."""

from chainreaper.analyzers.abandoned_takeover import AbandonedTakeoverAnalyzer  # noqa: F401
from chainreaper.analyzers.build_system import BuildSystemAnalyzer  # noqa: F401
from chainreaper.analyzers.code_inspector import CodeInspectorAnalyzer  # noqa: F401
from chainreaper.analyzers.compromised_maintainer import CompromisedMaintainerAnalyzer  # noqa: F401
from chainreaper.analyzers.dependency_confusion import DependencyConfusionAnalyzer  # noqa: F401
from chainreaper.analyzers.install_script import InstallScriptAnalyzer  # noqa: F401
from chainreaper.analyzers.lockfile_integrity import LockfileIntegrityAnalyzer  # noqa: F401
from chainreaper.analyzers.malicious_package import MaliciousPackageAnalyzer  # noqa: F401
from chainreaper.analyzers.protestware import ProtestwareAnalyzer  # noqa: F401
from chainreaper.analyzers.registry_spoofing import RegistrySpoofingAnalyzer  # noqa: F401
from chainreaper.analyzers.shadow_dependency import ShadowDependencyAnalyzer  # noqa: F401
from chainreaper.analyzers.source_binary_mismatch import SourceBinaryMismatchAnalyzer  # noqa: F401
from chainreaper.analyzers.typosquatting import TyposquattingAnalyzer  # noqa: F401
