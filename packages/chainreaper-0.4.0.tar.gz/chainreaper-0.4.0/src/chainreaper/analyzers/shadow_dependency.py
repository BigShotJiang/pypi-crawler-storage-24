"""Shadow dependency analyzer — identifies hidden risks in transitive dependency trees."""

from __future__ import annotations

import logging

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.llm.prompts.analysis import SHADOW_DEPENDENCY
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

# Max length for package names/versions in prompts to prevent abuse
_MAX_NAME_LEN = 214


def _sanitize(value: str) -> str:
    """Sanitize untrusted data before including in LLM prompts."""
    clean = value[:_MAX_NAME_LEN].strip()
    clean = "".join(c for c in clean if c.isprintable())
    return clean


class ShadowDependencyRisk(BaseModel):
    """A single shadow dependency risk identified by the LLM."""

    package_name: str
    depth_in_tree: int = Field(
        description="How deep in the transitive dependency tree this package sits"
    )
    concern: str = Field(
        description="The specific supply chain concern with this transitive dependency"
    )
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str = Field(description="Recommended fix")


class ShadowDependencyResult(BaseModel):
    """Structured output from the shadow dependency analysis."""

    risks: list[ShadowDependencyRisk] = []
    overall_assessment: str = ""


def _compute_depth(node, current_depth: int = 1) -> list[tuple[str, str, int]]:
    """Recursively compute the depth of each node in the dependency tree.

    Returns a list of (name, version, depth) tuples.
    """
    results = [(node.name, node.version, current_depth)]
    for child in node.children:
        results.extend(_compute_depth(child, current_depth + 1))
    return results


@AnalyzerRegistry.register
class ShadowDependencyAnalyzer(BaseAnalyzer):
    """Identifies hidden risks buried deep in the transitive dependency tree.

    Analyzes the full dependency graph structure to find:
    - Deep transitive deps with high blast radius but few maintainers
    - Unmaintained packages deep in the tree
    - Version pinning issues that could pull malicious versions
    - Packages with unexpectedly broad capabilities

    Sends the tree structure to an LLM for contextual risk assessment.
    """

    analyzer_name = "shadow_dependency"
    attack_vector = AttackVector.SHADOW_DEPENDENCY
    applicable_ecosystems = [
        EcosystemName.NPM,
        EcosystemName.PYPI,
        EcosystemName.MAVEN,
        EcosystemName.GO,
        EcosystemName.CARGO,
        EcosystemName.RUBYGEMS,
        EcosystemName.NUGET,
    ]
    description = (
        "Identifies hidden risks in transitive dependency trees that are not "
        "visible from the direct dependency list."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Analyze transitive dependency trees for shadow dependency risks."""
        findings: list[Finding] = []

        for tree in context.dependency_trees:
            if not tree.transitive_dependencies and not tree.direct_dependencies:
                continue

            # Build a text representation of the dependency tree
            tree_lines: list[str] = []

            # Direct dependencies at depth 0
            for dep in tree.direct_dependencies[:50]:
                tree_lines.append(
                    f"[depth=0, direct] {_sanitize(dep.name)}@{_sanitize(dep.version)} "
                    f"(registry={_sanitize(dep.source_registry)}, "
                    f"integrity={'present' if dep.integrity_hash else 'missing'})"
                )
                # Include children if available
                for child_name, child_version, child_depth in _compute_depth(dep):
                    if child_depth > 1:  # Skip the root itself
                        tree_lines.append(
                            f"[depth={child_depth}, transitive] "
                            f"{_sanitize(child_name)}@{_sanitize(child_version)}"
                        )

            # Transitive dependencies (flat list from tree)
            for dep in tree.transitive_dependencies[:150]:
                tree_lines.append(
                    f"[depth=1+, transitive] {_sanitize(dep.name)}@{_sanitize(dep.version)} "
                    f"(registry={_sanitize(dep.source_registry)}, "
                    f"integrity={'present' if dep.integrity_hash else 'missing'})"
                )

            if not tree_lines:
                continue

            tree_text = "\n".join(tree_lines)

            prompt = SHADOW_DEPENDENCY.format(
                dependency_tree=f"<package_data>\n"
                f"Project: {_sanitize(tree.root_package)}\n"
                f"Ecosystem: {tree.ecosystem.value}\n"
                f"Direct deps: {len(tree.direct_dependencies)}\n"
                f"Transitive deps: {len(tree.transitive_dependencies)}\n\n"
                f"{tree_text}\n"
                f"</package_data>",
            )

            messages = [
                {"role": "system", "content": CHAINREAPER_SYSTEM},
                {"role": "user", "content": prompt},
            ]

            result = await llm.extract(
                response_model=ShadowDependencyResult,
                messages=messages,
            )

            # Convert LLM results to findings
            for risk in result.risks:
                findings.append(
                    Finding(
                        title=f"Shadow dependency risk: {risk.package_name}",
                        description=(
                            f"Transitive dependency '{risk.package_name}' at depth "
                            f"{risk.depth_in_tree} in the dependency tree poses a hidden "
                            f"supply chain risk. These deeply nested dependencies are often "
                            f"overlooked in security reviews but can be exploited to inject "
                            f"malicious code. Concern: {risk.concern}"
                        ),
                        severity=risk.severity,
                        confidence=risk.confidence,
                        attack_vector=AttackVector.SHADOW_DEPENDENCY,
                        ecosystem=tree.ecosystem,
                        package_name=risk.package_name,
                        evidence=Evidence(
                            description=risk.concern,
                            raw_data={
                                "depth_in_tree": risk.depth_in_tree,
                                "concern": risk.concern,
                                "total_transitive_deps": len(tree.transitive_dependencies),
                            },
                        ),
                        remediation=risk.remediation,
                        cwe_ids=["CWE-1357"],
                    )
                )

        return findings
