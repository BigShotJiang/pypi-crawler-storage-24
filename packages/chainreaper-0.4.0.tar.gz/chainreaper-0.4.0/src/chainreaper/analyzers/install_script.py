"""Install script analyzer — detects suspicious pre/post install scripts in packages."""

from __future__ import annotations

import logging

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.ecosystems.base import EcosystemRegistry
from chainreaper.llm.prompts.analysis import INSTALL_SCRIPT
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

# Max length for package names/script content in prompts to prevent abuse
_MAX_NAME_LEN = 214


def _sanitize(value: str) -> str:
    """Sanitize untrusted data before including in LLM prompts."""
    clean = value[:_MAX_NAME_LEN].strip()
    clean = "".join(c for c in clean if c.isprintable())
    return clean


class InstallScriptFinding(BaseModel):
    """A single install script finding identified by the LLM."""

    package_name: str
    script_type: str = Field(
        description="Type of install script: preinstall, install, postinstall, prepare"
    )
    suspicious_behavior: str = Field(description="Description of the suspicious behavior detected")
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str = Field(description="Recommended fix")


class InstallScriptResult(BaseModel):
    """Structured output from the install script analysis."""

    findings: list[InstallScriptFinding] = []
    overall_assessment: str = ""


@AnalyzerRegistry.register
class InstallScriptAnalyzer(BaseAnalyzer):
    """Detects suspicious pre/post install scripts in npm packages.

    Fetches package metadata to identify packages that declare install
    scripts (preinstall, install, postinstall, prepare).  For packages
    with install scripts, sends the metadata to an LLM for behavioral
    analysis to determine if the scripts exhibit suspicious patterns
    such as network requests, filesystem access, or environment variable
    exfiltration.
    """

    analyzer_name = "install_script"
    attack_vector = AttackVector.INSTALL_SCRIPT
    applicable_ecosystems = [EcosystemName.NPM, EcosystemName.PYPI, EcosystemName.RUBYGEMS]
    description = (
        "Detects suspicious pre/post install scripts that may execute malicious "
        "code during package installation."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Analyze dependencies for suspicious install scripts."""
        findings: list[Finding] = []

        for tree in context.dependency_trees:
            eco_cls = EcosystemRegistry.get(tree.ecosystem.value)
            if not eco_cls:
                continue

            eco = eco_cls()

            # Gather metadata to find packages with install scripts
            packages_with_scripts: list[dict[str, object]] = []
            all_deps = tree.direct_dependencies + tree.transitive_dependencies

            for dep in all_deps[:100]:  # Limit to prevent excessive API calls
                metadata = await eco.get_package_metadata(dep.name)
                if metadata and metadata.has_install_scripts:
                    packages_with_scripts.append(
                        {
                            "name": dep.name,
                            "version": dep.version,
                            "is_direct": dep.is_direct,
                            "description": metadata.description,
                            "maintainer_count": len(metadata.maintainers),
                            "has_install_scripts": True,
                        }
                    )

            if not packages_with_scripts:
                continue

            # Wrap untrusted data in XML tags for prompt injection defense
            packages_text = "\n".join(
                f"- {_sanitize(str(p['name']))}@{_sanitize(str(p['version']))} "
                f"(direct={p['is_direct']}, description={_sanitize(str(p['description']))}, "
                f"maintainers={p['maintainer_count']})"
                for p in packages_with_scripts
            )

            prompt = INSTALL_SCRIPT.format(
                packages_with_scripts=f"<package_data>\n{packages_text}\n</package_data>",
            )

            messages = [
                {"role": "system", "content": CHAINREAPER_SYSTEM},
                {"role": "user", "content": prompt},
            ]

            result = await llm.extract(
                response_model=InstallScriptResult,
                messages=messages,
            )

            # Convert LLM results to findings
            for script_finding in result.findings:
                findings.append(
                    Finding(
                        title=(
                            f"Suspicious install script: {script_finding.package_name} "
                            f"({script_finding.script_type})"
                        ),
                        description=(
                            f"Package '{script_finding.package_name}' contains a "
                            f"'{script_finding.script_type}' script with suspicious behavior. "
                            f"Install scripts execute automatically during 'npm install' and "
                            f"can perform arbitrary actions with the user's permissions. "
                            f"Suspicious behavior: {script_finding.suspicious_behavior}"
                        ),
                        severity=script_finding.severity,
                        confidence=script_finding.confidence,
                        attack_vector=AttackVector.INSTALL_SCRIPT,
                        ecosystem=tree.ecosystem,
                        package_name=script_finding.package_name,
                        evidence=Evidence(
                            description=script_finding.suspicious_behavior,
                            raw_data={
                                "script_type": script_finding.script_type,
                                "suspicious_behavior": script_finding.suspicious_behavior,
                            },
                        ),
                        remediation=script_finding.remediation,
                        cwe_ids=["CWE-829"],
                        package_url=f"{eco.registry_url}/{script_finding.package_name}",
                        package_registry_url=eco.registry_url,
                    )
                )

        return findings
