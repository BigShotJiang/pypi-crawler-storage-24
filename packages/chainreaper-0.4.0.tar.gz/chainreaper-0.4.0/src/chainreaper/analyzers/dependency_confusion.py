"""Dependency confusion analyzer — checks if internal package names exist on public registries."""

from __future__ import annotations

import logging

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.ecosystems.base import EcosystemRegistry
from chainreaper.llm.prompts.analysis import DEPENDENCY_CONFUSION
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

# Max length for package names/versions in prompts to prevent abuse
_MAX_NAME_LEN = 214


def _sanitize(value: str) -> str:
    """Sanitize untrusted data before including in LLM prompts."""
    # Truncate, strip control characters, collapse whitespace
    clean = value[:_MAX_NAME_LEN].strip()
    clean = "".join(c for c in clean if c.isprintable())
    return clean


class ConfusionCandidate(BaseModel):
    """A single dependency confusion candidate identified by the LLM."""

    package_name: str
    is_likely_internal: bool = Field(
        description="Whether this looks like an internal/private package"
    )
    reasoning: str = Field(description="Why this is or isn't a dependency confusion risk")
    available_on_public_registry: bool = Field(
        description="True if the package name is available (NOT taken) on the public registry. "
        "This matches the available_on_public flag from the input data."
    )
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str = Field(description="Recommended fix")


class ConfusionAnalysisResult(BaseModel):
    """Structured output from the dependency confusion analysis."""

    candidates: list[ConfusionCandidate] = []
    overall_assessment: str = ""


@AnalyzerRegistry.register
class DependencyConfusionAnalyzer(BaseAnalyzer):
    """Checks if internal-looking package names are available on public registries.

    This is a critical attack vector where an attacker registers a package
    on a public registry with the same name as an internal/private package,
    with a higher version number. Package managers may then install the
    malicious public package instead of the internal one.
    """

    analyzer_name = "dependency_confusion"
    attack_vector = AttackVector.DEPENDENCY_CONFUSION
    applicable_ecosystems = [
        EcosystemName.NPM,
        EcosystemName.PYPI,
        EcosystemName.MAVEN,
        EcosystemName.GO,
        EcosystemName.CARGO,
        EcosystemName.RUBYGEMS,
        EcosystemName.NUGET,
    ]
    description = (
        "Checks if internal-looking package names are available on public registries, "
        "indicating dependency confusion attack risk."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Analyze dependencies for dependency confusion vulnerabilities."""
        findings: list[Finding] = []

        for tree in context.dependency_trees:
            eco_cls = EcosystemRegistry.get(tree.ecosystem.value)
            if not eco_cls:
                continue

            eco = eco_cls()

            # Gather package names and their public registry status
            packages_info: list[dict[str, object]] = []
            all_deps = tree.direct_dependencies + tree.transitive_dependencies

            for dep in all_deps[:100]:  # Limit to prevent excessive API calls
                is_available = await eco.check_name_available(dep.name)
                packages_info.append(
                    {
                        "name": dep.name,
                        "version": dep.version,
                        "is_direct": dep.is_direct,
                        "available_on_public": is_available,
                    }
                )

            if not packages_info:
                continue

            # Wrap untrusted package data in XML tags for prompt injection defense
            packages_text = "\n".join(
                f"- {_sanitize(str(p['name']))}@{_sanitize(str(p['version']))} "
                f"(direct={p['is_direct']}, available_on_public={p['available_on_public']})"
                for p in packages_info
            )

            prompt = DEPENDENCY_CONFUSION.format(
                project_name=_sanitize(tree.root_package),
                registry_config=eco.registry_url,
                packages=f"<package_data>\n{packages_text}\n</package_data>",
                registry_data="See available_on_public flags above.",
            )

            messages = [
                {"role": "system", "content": CHAINREAPER_SYSTEM},
                {"role": "user", "content": prompt},
            ]

            result = await llm.extract(
                response_model=ConfusionAnalysisResult,
                messages=messages,
            )

            # Convert LLM results to findings
            # A finding exists when: package looks internal AND name is available on public registry
            for candidate in result.candidates:
                if candidate.is_likely_internal and candidate.available_on_public_registry:
                    findings.append(
                        Finding(
                            title=f"Dependency confusion risk: {candidate.package_name}",
                            description=(
                                f"Package '{candidate.package_name}' appears to be an internal "
                                f"package whose name is AVAILABLE on the public {tree.ecosystem.value} "
                                f"registry. An attacker could register this name with a higher "
                                f"version number to inject malicious code. "
                                f"Reasoning: {candidate.reasoning}"
                            ),
                            severity=candidate.severity,
                            confidence=candidate.confidence,
                            attack_vector=AttackVector.DEPENDENCY_CONFUSION,
                            ecosystem=tree.ecosystem,
                            package_name=candidate.package_name,
                            evidence=Evidence(
                                description=candidate.reasoning,
                                raw_data={
                                    "available_on_public": candidate.available_on_public_registry,
                                    "analysis": candidate.reasoning,
                                },
                            ),
                            remediation=candidate.remediation,
                            cwe_ids=["CWE-427"],
                            package_url=f"{eco.registry_url}/{candidate.package_name}",
                            package_registry_url=eco.registry_url,
                        )
                    )

        return findings
