"""Abandoned takeover analyzer — detects unmaintained packages at risk of account takeover."""

from __future__ import annotations

import logging
from datetime import UTC, datetime

from pydantic import BaseModel, Field

from chainreaper.analyzers.base import AnalyzerRegistry, BaseAnalyzer
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import AnalysisContext, Evidence, Finding
from chainreaper.ecosystems.base import EcosystemRegistry
from chainreaper.llm.prompts.analysis import ABANDONED_TAKEOVER
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)

# Max length for package names/metadata in prompts to prevent abuse
_MAX_NAME_LEN = 214

# Threshold for considering a package abandoned (days without update)
_ABANDONMENT_THRESHOLD_DAYS = 730  # ~2 years


def _sanitize(value: str) -> str:
    """Sanitize untrusted data before including in LLM prompts."""
    clean = value[:_MAX_NAME_LEN].strip()
    clean = "".join(c for c in clean if c.isprintable())
    return clean


def _days_since(dt: datetime) -> int:
    """Calculate days since a given datetime (UTC)."""
    now = datetime.now(UTC)
    # Ensure both datetimes are offset-aware
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    delta = now - dt
    return max(0, delta.days)


class AbandonedPackageAssessment(BaseModel):
    """A single abandoned package risk assessment identified by the LLM."""

    package_name: str
    days_since_update: int = Field(description="Days since the package was last published/updated")
    maintainer_count: int = Field(description="Number of known maintainers")
    takeover_risk: str = Field(
        description="Risk level for account takeover: low, medium, high, critical"
    )
    reasoning: str = Field(description="Why this package is at risk of abandonment and takeover")
    is_abandoned: bool = Field(
        description="Whether the LLM assesses this package as effectively abandoned"
    )
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    remediation: str = Field(description="Recommended fix")


class AbandonedTakeoverResult(BaseModel):
    """Structured output from the abandoned takeover analysis."""

    assessments: list[AbandonedPackageAssessment] = []
    overall_assessment: str = ""


@AnalyzerRegistry.register
class AbandonedTakeoverAnalyzer(BaseAnalyzer):
    """Detects unmaintained packages at risk of account takeover.

    Fetches package metadata for each dependency and flags packages that
    show signs of abandonment:
    - Not updated in 2+ years
    - Single maintainer (bus factor risk)
    - Low maintainer activity relative to download count
    - Signs of dormant or abandoned maintainer accounts

    Sends the collected signals to an LLM to reason about abandonment
    risk and the likelihood of a malicious takeover.
    """

    analyzer_name = "abandoned_takeover"
    attack_vector = AttackVector.ABANDONED_TAKEOVER
    applicable_ecosystems = [
        EcosystemName.NPM,
        EcosystemName.PYPI,
        EcosystemName.MAVEN,
        EcosystemName.GO,
        EcosystemName.CARGO,
        EcosystemName.RUBYGEMS,
        EcosystemName.NUGET,
    ]
    description = (
        "Detects unmaintained or abandoned packages that are at risk of "
        "malicious account takeover by attackers."
    )

    async def analyze(
        self,
        context: AnalysisContext,
        llm: StructuredLLM,
        router: ChainReaperRouter,
    ) -> list[Finding]:
        """Analyze dependencies for abandoned package takeover risks."""
        findings: list[Finding] = []

        for tree in context.dependency_trees:
            eco_cls = EcosystemRegistry.get(tree.ecosystem.value)
            if not eco_cls:
                continue

            eco = eco_cls()

            # Gather package metadata with abandonment signals
            packages_info: list[dict[str, object]] = []
            all_deps = tree.direct_dependencies + tree.transitive_dependencies

            for dep in all_deps[:80]:  # Limit to prevent excessive API calls
                metadata = await eco.get_package_metadata(dep.name)
                if not metadata:
                    continue

                days_since_update = (
                    _days_since(metadata.publish_date) if metadata.publish_date else -1  # Unknown
                )

                # Pre-filter: focus on potentially abandoned packages
                # Include packages that are old, have few maintainers, or have unknown dates
                is_potentially_stale = (
                    days_since_update >= _ABANDONMENT_THRESHOLD_DAYS
                    or days_since_update == -1  # unknown publish date is suspicious
                    or len(metadata.maintainers) <= 1
                )

                if not is_potentially_stale:
                    continue

                packages_info.append(
                    {
                        "name": dep.name,
                        "version": dep.version,
                        "is_direct": dep.is_direct,
                        "description": metadata.description,
                        "maintainer_count": len(metadata.maintainers),
                        "maintainer_names": [m.username for m in metadata.maintainers[:5]],
                        "publish_date": (
                            metadata.publish_date.isoformat()
                            if metadata.publish_date
                            else "unknown"
                        ),
                        "days_since_update": days_since_update,
                        "download_count": metadata.download_count,
                        "repository_url": metadata.repository_url or "none",
                        "license": metadata.license or "unknown",
                    }
                )

            if not packages_info:
                continue

            # Wrap untrusted package data in XML tags for prompt injection defense
            packages_text = "\n".join(
                f"- {_sanitize(str(p['name']))}@{_sanitize(str(p['version']))} "
                f"(direct={p['is_direct']}, "
                f"maintainers={p['maintainer_count']} [{', '.join(_sanitize(n) for n in p['maintainer_names'])}], "
                f"published={p['publish_date']}, "
                f"days_since_update={p['days_since_update']}, "
                f"downloads={p['download_count']}, "
                f"repo={_sanitize(str(p['repository_url']))}, "
                f"license={_sanitize(str(p['license']))})"
                for p in packages_info
            )

            prompt = ABANDONED_TAKEOVER.format(
                ecosystem=tree.ecosystem.value,
                package_count=len(packages_info),
                total_deps=len(all_deps),
                packages=f"<package_data>\n{packages_text}\n</package_data>",
            )

            messages = [
                {"role": "system", "content": CHAINREAPER_SYSTEM},
                {"role": "user", "content": prompt},
            ]

            result = await llm.extract(
                response_model=AbandonedTakeoverResult,
                messages=messages,
            )

            # Convert LLM results to findings
            for assessment in result.assessments:
                if assessment.is_abandoned and assessment.takeover_risk in (
                    "medium",
                    "high",
                    "critical",
                ):
                    findings.append(
                        Finding(
                            title=(f"Abandoned package takeover risk: {assessment.package_name}"),
                            description=(
                                f"Package '{assessment.package_name}' appears to be abandoned "
                                f"({assessment.days_since_update} days since last update, "
                                f"{assessment.maintainer_count} maintainer(s)). Abandoned "
                                f"packages are prime targets for malicious takeover — an "
                                f"attacker can claim the maintainer account or request "
                                f"ownership transfer, then push a malicious update to all "
                                f"downstream consumers. Takeover risk: {assessment.takeover_risk}. "
                                f"Reasoning: {assessment.reasoning}"
                            ),
                            severity=assessment.severity,
                            confidence=assessment.confidence,
                            attack_vector=AttackVector.ABANDONED_TAKEOVER,
                            ecosystem=tree.ecosystem,
                            package_name=assessment.package_name,
                            evidence=Evidence(
                                description=assessment.reasoning,
                                raw_data={
                                    "days_since_update": assessment.days_since_update,
                                    "maintainer_count": assessment.maintainer_count,
                                    "takeover_risk": assessment.takeover_risk,
                                    "analysis": assessment.reasoning,
                                },
                            ),
                            remediation=assessment.remediation,
                            cwe_ids=["CWE-1104"],
                            package_url=f"{eco.registry_url}/{assessment.package_name}",
                            package_registry_url=eco.registry_url,
                        )
                    )

        return findings
