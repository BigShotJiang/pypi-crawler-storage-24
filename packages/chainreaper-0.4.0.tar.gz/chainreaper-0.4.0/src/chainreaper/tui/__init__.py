"""Optional TUI interface using Textual (Phase 4)."""
