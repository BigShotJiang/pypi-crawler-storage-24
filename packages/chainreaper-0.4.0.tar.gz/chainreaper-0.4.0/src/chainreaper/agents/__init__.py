"""Autonomous agent system with ReAct reasoning."""
