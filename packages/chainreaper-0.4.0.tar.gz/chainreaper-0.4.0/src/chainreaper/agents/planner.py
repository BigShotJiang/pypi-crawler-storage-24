"""Attack path planner — LLM chains findings into attack graphs."""

from __future__ import annotations

import logging

from pydantic import BaseModel, Field

from chainreaper.agents.state import ScanState
from chainreaper.core.constants import EdgeType, NodeType, Severity
from chainreaper.core.models import (
    AttackGraph,
    AttackGraphEdge,
    AttackGraphNode,
    AttackPath,
)
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM, GRAPH_BUILDER
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)


class LLMAttackPath(BaseModel):
    """Attack path as described by the LLM."""

    name: str = Field(description="Descriptive name for this attack path")
    description: str = Field(description="Full description of the attack sequence")
    severity: Severity
    likelihood: float = Field(ge=0.0, le=1.0)
    steps: list[str] = Field(description="Ordered list of attack step descriptions")
    involved_packages: list[str] = Field(description="Package names involved in this path")


class LLMGraphOutput(BaseModel):
    """Structured output for attack graph generation."""

    attack_paths: list[LLMAttackPath] = []
    summary: str = Field(description="Overall attack surface summary")


class AttackPathPlanner:
    """Uses the LLM to identify attack chains across findings."""

    def __init__(self, structured_llm: StructuredLLM) -> None:
        self.llm = structured_llm

    async def build_graph(self, state: ScanState) -> AttackGraph:
        """Build an attack graph from scan findings using LLM reasoning."""
        if not state.findings:
            return AttackGraph()

        findings_text = "\n".join(
            f"- [{f.severity.value}] {f.title} ({f.package_name}): {f.description}"
            for f in state.findings
        )
        trees_text = "\n".join(
            f"- {t.ecosystem.value}: {t.total_count} dependencies" for t in state.dependency_trees
        )

        prompt = GRAPH_BUILDER.format(
            findings=findings_text,
            dependency_trees=trees_text,
        )

        messages = [
            {"role": "system", "content": CHAINREAPER_SYSTEM},
            {"role": "user", "content": prompt},
        ]

        result = await self.llm.extract(
            response_model=LLMGraphOutput,
            messages=messages,
        )

        return self._build_graph_from_llm(result, state)

    def _build_graph_from_llm(self, llm_output: LLMGraphOutput, state: ScanState) -> AttackGraph:
        """Convert LLM output to a structured attack graph."""
        nodes: list[AttackGraphNode] = []
        edges: list[AttackGraphEdge] = []
        paths: list[AttackPath] = []
        node_id_counter = 0

        # Add finding nodes
        finding_node_ids: dict[str, str] = {}
        for finding in state.findings:
            node_id = f"finding-{node_id_counter}"
            node_id_counter += 1
            nodes.append(
                AttackGraphNode(
                    id=node_id,
                    label=finding.title,
                    node_type=NodeType.VULNERABILITY,
                    severity=finding.severity,
                    metadata={
                        "package": finding.package_name,
                        "vector": finding.attack_vector.value,
                    },
                )
            )
            finding_node_ids[finding.package_name] = node_id

        # Add attack paths from LLM
        for llm_path in llm_output.attack_paths:
            path_node_ids: list[str] = []

            for step_desc in llm_path.steps:
                node_id = f"step-{node_id_counter}"
                node_id_counter += 1
                nodes.append(
                    AttackGraphNode(
                        id=node_id,
                        label=step_desc,
                        node_type=NodeType.ATTACK_STEP,
                        severity=llm_path.severity,
                    )
                )
                path_node_ids.append(node_id)

            # Chain steps together
            for i in range(len(path_node_ids) - 1):
                edges.append(
                    AttackGraphEdge(
                        source=path_node_ids[i],
                        target=path_node_ids[i + 1],
                        label="leads to",
                        edge_type=EdgeType.LEADS_TO,
                    )
                )

            # Connect findings to path steps
            for pkg in llm_path.involved_packages:
                if pkg in finding_node_ids and path_node_ids:
                    edges.append(
                        AttackGraphEdge(
                            source=finding_node_ids[pkg],
                            target=path_node_ids[0],
                            label="exploits",
                            edge_type=EdgeType.EXPLOITS,
                        )
                    )

            paths.append(
                AttackPath(
                    name=llm_path.name,
                    description=llm_path.description,
                    severity=llm_path.severity,
                    likelihood=llm_path.likelihood,
                    node_ids=path_node_ids,
                )
            )

        return AttackGraph(nodes=nodes, edges=edges, paths=paths)
