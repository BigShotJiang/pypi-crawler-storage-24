"""ReAct-style reasoning engine. LLM makes ALL decisions — no hardcoded logic."""

from __future__ import annotations

import json
import logging
from typing import Any

from pydantic import BaseModel, Field

from chainreaper.agents.state import ScanState
from chainreaper.analyzers.base import AnalyzerRegistry
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM, REACT_REASONER
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)


class ReActDecision(BaseModel):
    """Structured output from the ReAct reasoner."""

    thought: str = Field(description="Your reasoning about the current state")
    should_continue: bool = Field(description="Whether to continue analysis or stop")
    next_action: str | None = Field(
        default=None,
        description="The analyzer to run next (e.g., 'dependency_confusion', 'typosquatting')",
    )
    action_params: dict[str, Any] = Field(
        default_factory=dict,
        description="Parameters to pass to the analyzer",
    )
    reasoning_for_stop: str | None = Field(
        default=None,
        description="If stopping, explain why analysis is complete",
    )


class ReActReasoner:
    """ReAct reasoning engine — LLM decides what to analyze and when to stop.

    Each iteration:
    - Thought: LLM reasons about current state, what it knows, what it needs
    - Action: LLM selects an analyzer + parameters
    - Observation: Analyzer returns results
    - Reflection: LLM integrates results into understanding

    NO hardcoded rules about which analyzer to use when.
    The LLM sees the full state and decides autonomously.
    """

    def __init__(self, structured_llm: StructuredLLM) -> None:
        self.llm = structured_llm

    async def decide_next(self, state: ScanState) -> ReActDecision:
        """Ask the LLM what to do next based on current scan state."""
        history = self._format_history(state)
        available_actions = self._format_available_actions(state)

        ecosystems = ", ".join(
            f"{t.ecosystem.value} ({t.total_count} deps)" for t in state.dependency_trees
        )

        prompt = REACT_REASONER.format(
            target=state.target.value,
            ecosystems=ecosystems or "none discovered yet",
            iteration=state.iteration,
            max_iterations=state.max_iterations,
            findings_count=len(state.findings),
            history=history or "No actions taken yet.",
            available_actions=available_actions,
        )

        messages = [
            {"role": "system", "content": CHAINREAPER_SYSTEM},
            {"role": "user", "content": prompt},
        ]

        decision = await self.llm.extract(
            response_model=ReActDecision,
            messages=messages,
        )

        logger.info(
            "ReAct decision: continue=%s action=%s",
            decision.should_continue,
            decision.next_action,
        )
        return decision

    def _format_history(self, state: ScanState) -> str:
        """Format previous thoughts and observations for context."""
        parts: list[str] = []
        for t in state.thoughts[-10:]:  # Last 10 thoughts to fit context
            parts.append(f"[Thought] {t.thought}")
            if t.action:
                parts.append(f"[Action] {t.action}({json.dumps(t.action_params)})")
            if t.observation:
                parts.append(f"[Observation] {t.observation}")
        return "\n".join(parts)

    def _format_available_actions(self, state: ScanState) -> str:
        """List analyzers that can still be run."""
        analyzers = AnalyzerRegistry.get_all()
        ecosystems = {t.ecosystem for t in state.dependency_trees}
        used_vectors = {t.action for t in state.thoughts if t.action}

        lines: list[str] = []
        for name, analyzer_cls in analyzers.items():
            applicable = set(analyzer_cls.applicable_ecosystems) & ecosystems
            status = "DONE" if name in used_vectors else "available"
            if applicable or not ecosystems:
                lines.append(
                    f"- {name} [{status}]: {analyzer_cls.description} "
                    f"(ecosystems: {', '.join(e.value for e in applicable) or 'any'})"
                )
        return "\n".join(lines) or "No analyzers available."
