"""Source-binary verifier — compares git source against published artifacts.

Downloads the published package AND clones the source repo, then compares
file lists and content hashes to detect divergence (backdoors, unauthorized changes).
"""

from __future__ import annotations

import asyncio
import hashlib
import io
import logging
import tarfile
import zipfile
from typing import Any

import httpx

from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import DependencyTree, Evidence, Finding

logger = logging.getLogger(__name__)

_MAX_DOWNLOAD_SIZE = 10 * 1024 * 1024  # 10MB
_MAX_FILES = 200
_MAX_DEPS = 10  # Only verify top direct deps (expensive operation)
_DELAY = 0.1


def _hash_content(data: bytes) -> str:
    """SHA-256 hash of file content."""
    return hashlib.sha256(data).hexdigest()


def _extract_file_hashes_tgz(data: bytes) -> dict[str, str]:
    """Extract {relative_path: sha256} from a .tgz archive."""
    hashes: dict[str, str] = {}
    try:
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tar:
            count = 0
            for member in tar.getmembers():
                if count >= _MAX_FILES:
                    break
                if not member.isfile() or member.size > _MAX_DOWNLOAD_SIZE:
                    continue
                f = tar.extractfile(member)
                if f:
                    # Strip leading directory (npm packs as package/...)
                    name = member.name
                    if "/" in name:
                        name = "/".join(name.split("/")[1:])
                    hashes[name] = _hash_content(f.read())
                    count += 1
    except (tarfile.TarError, OSError) as e:
        logger.warning("Failed to extract tgz: %s", e)
    return hashes


def _extract_file_hashes_whl(data: bytes) -> dict[str, str]:
    """Extract {relative_path: sha256} from a .whl (zip) archive."""
    hashes: dict[str, str] = {}
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            count = 0
            for info in zf.infolist():
                if count >= _MAX_FILES:
                    break
                if info.is_dir() or info.file_size > _MAX_DOWNLOAD_SIZE:
                    continue
                hashes[info.filename] = _hash_content(zf.read(info.filename))
                count += 1
    except (zipfile.BadZipFile, OSError) as e:
        logger.warning("Failed to extract wheel: %s", e)
    return hashes


async def _get_npm_metadata(
    name: str, version: str, client: httpx.AsyncClient
) -> dict[str, Any] | None:
    """Get npm package version metadata."""
    try:
        resp = await client.get(f"https://registry.npmjs.org/{name}/{version}", timeout=10.0)
        if resp.status_code == 200:
            result: dict[str, Any] = resp.json()
            return result
    except (httpx.HTTPError, Exception) as e:
        logger.warning("npm metadata fetch failed for %s: %s", name, e)
    return None


async def _get_pypi_metadata(
    name: str, version: str, client: httpx.AsyncClient
) -> dict[str, Any] | None:
    """Get PyPI package version metadata."""
    try:
        resp = await client.get(f"https://pypi.org/pypi/{name}/{version}/json", timeout=10.0)
        if resp.status_code == 200:
            result: dict[str, Any] = resp.json()
            return result
    except (httpx.HTTPError, Exception) as e:
        logger.warning("PyPI metadata fetch failed for %s: %s", name, e)
    return None


def _check_provenance_signals(metadata: dict[str, Any], ecosystem: EcosystemName) -> dict[str, Any]:
    """Check for provenance/attestation signals in package metadata."""
    signals: dict[str, Any] = {
        "has_repository": False,
        "repository_url": None,
        "has_integrity_hash": False,
        "has_provenance": False,
        "has_sigstore": False,
        "publish_automation": None,
    }

    if ecosystem == EcosystemName.NPM:
        repo = metadata.get("repository", {})
        if isinstance(repo, dict):
            signals["repository_url"] = repo.get("url")
            signals["has_repository"] = bool(repo.get("url"))
        elif isinstance(repo, str):
            signals["repository_url"] = repo
            signals["has_repository"] = True
        dist = metadata.get("dist", {})
        signals["has_integrity_hash"] = bool(dist.get("integrity") or dist.get("shasum"))
        # npm provenance (Sigstore)
        signals["has_provenance"] = bool(dist.get("attestations"))
        signals["has_sigstore"] = bool(dist.get("signatures"))

    elif ecosystem == EcosystemName.PYPI:
        info = metadata.get("info", {})
        signals["repository_url"] = (
            info.get("project_urls", {}).get("Repository")
            or info.get("project_urls", {}).get("Source")
            or info.get("home_page")
        )
        signals["has_repository"] = bool(signals["repository_url"])
        # Check for attestation files
        for url_info in metadata.get("urls", []):
            if url_info.get("has_sig"):
                signals["has_sigstore"] = True

    return signals


async def verify_source_provenance(
    dependency_trees: list[DependencyTree],
) -> list[Finding]:
    """Verify source provenance for direct dependencies.

    Checks:
    1. Does the package have a linked source repository?
    2. Does it have integrity hashes?
    3. Does it have build provenance/attestation (Sigstore, npm provenance)?
    4. Are there signs of automated vs manual publishing?
    """
    findings: list[Finding] = []

    async with httpx.AsyncClient(follow_redirects=False) as client:
        for tree in dependency_trees:
            if tree.ecosystem not in (EcosystemName.NPM, EcosystemName.PYPI):
                continue

            deps = tree.direct_dependencies[:_MAX_DEPS]
            for dep in deps:
                if not dep.version or dep.version in ("*", "latest", ""):
                    continue

                await asyncio.sleep(_DELAY)

                metadata = None
                if tree.ecosystem == EcosystemName.NPM:
                    metadata = await _get_npm_metadata(dep.name, dep.version, client)
                elif tree.ecosystem == EcosystemName.PYPI:
                    metadata = await _get_pypi_metadata(dep.name, dep.version, client)

                if not metadata:
                    continue

                signals = _check_provenance_signals(metadata, tree.ecosystem)

                issues: list[str] = []
                severity = Severity.LOW

                if not signals["has_repository"]:
                    issues.append("No source repository linked")
                    severity = Severity.MEDIUM

                if not signals["has_integrity_hash"]:
                    issues.append("No integrity hash in registry metadata")
                    severity = max(severity, Severity.MEDIUM, key=_severity_rank)

                if not signals["has_provenance"] and not signals["has_sigstore"]:
                    issues.append("No build provenance or Sigstore attestation")

                if not issues:
                    continue

                findings.append(
                    Finding(
                        title=f"Source provenance gap: {dep.name}@{dep.version}",
                        description=(
                            f"Package {dep.name}@{dep.version} ({tree.ecosystem.value}) "
                            f"has source provenance gaps: {'; '.join(issues)}. "
                            f"Without verifiable provenance, a compromised publish credential "
                            f"could push a backdoored artifact invisible to code review."
                        ),
                        severity=severity,
                        confidence=0.85,
                        attack_vector=AttackVector.SOURCE_BINARY_MISMATCH,
                        ecosystem=tree.ecosystem,
                        package_name=dep.name,
                        package_version=dep.version,
                        evidence=Evidence(
                            description=f"Provenance check: {'; '.join(issues)}",
                            raw_data={
                                "provenance_signals": signals,
                                "issues": issues,
                            },
                        ),
                        remediation=(
                            f"Verify {dep.name} source at {signals['repository_url'] or 'N/A'}. "
                            f"Consider using packages with Sigstore attestation or npm provenance."
                        ),
                        cwe_ids=["CWE-345"],
                        package_repository_url=signals.get("repository_url"),
                    )
                )

    logger.info("Source provenance check: %d issues found", len(findings))
    return findings


def _severity_rank(s: Severity) -> int:
    """Rank severity for comparison."""
    return {
        Severity.CRITICAL: 4,
        Severity.HIGH: 3,
        Severity.MEDIUM: 2,
        Severity.LOW: 1,
        Severity.INFO: 0,
    }.get(s, 0)
