"""Main scan orchestrator — drives the autonomous ReAct loop."""

from __future__ import annotations

import logging
from pathlib import Path

from chainreaper.agents.planner import AttackPathPlanner
from chainreaper.agents.reasoner import ReActReasoner
from chainreaper.agents.state import AnalyzerStatus, ScanState
from chainreaper.agents.verifier import FindingsVerifier
from chainreaper.analyzers.base import AnalyzerRegistry
from chainreaper.core.config import ChainReaperConfig
from chainreaper.core.constants import ScanPhase, TargetType
from chainreaper.core.events import EventBus
from chainreaper.core.exceptions import ScanError
from chainreaper.core.models import (
    AgentThought,
    DependencyTree,
    ScanMetadata,
    ScanResult,
    ScanSummary,
    ScanTarget,
)
from chainreaper.ecosystems.base import EcosystemRegistry
from chainreaper.llm.router import ChainReaperRouter
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)


class ScanOrchestrator:
    """Main scan loop. LLM makes ALL decisions.

    1. Parse target (repo URL, lockfile path, SBOM)
    2. Discover ecosystems and build dependency trees
    3. LLM plans attack strategy
    4. ReAct loop: LLM selects analyzers, interprets results, decides next steps
    5. LLM builds attack graph from findings
    6. Generate output
    """

    def __init__(self, config: ChainReaperConfig, event_bus: EventBus | None = None) -> None:
        self.config = config
        self.event_bus = event_bus or EventBus()
        self.router = ChainReaperRouter(config)
        self.cost_tracker = self.router.cost_tracker
        self.structured_llm = StructuredLLM(config, self.cost_tracker)
        self.reasoner = ReActReasoner(self.structured_llm)
        self.planner = AttackPathPlanner(self.structured_llm)
        self.verifier = FindingsVerifier(self.structured_llm)

    async def scan(
        self,
        target_value: str,
        target_type: TargetType | None = None,
        skip_verification: bool = False,
        baseline_trees: list[DependencyTree] | None = None,
        diff_only: bool = False,
    ) -> ScanResult:
        """Run a complete supply chain security scan.

        Supports:
        - Local paths: ./my-project, /abs/path
        - Git URLs: https://github.com/org/repo
        - Registry URLs: https://www.npmjs.com/package/express
        - Package names: express, flask, serde
        """
        from chainreaper.core.resolver import resolve_target

        # Phase 0: Resolve target (URL, package name, or local path)
        resolved = await resolve_target(target_value)
        if resolved.source != "local":
            await self.event_bus.phase(
                ScanPhase.INITIALIZING,
                f"Resolved {resolved.source}: {target_value} -> {resolved.path}",
            )

        target_type = target_type or self._detect_target_type(str(resolved.path))
        target = ScanTarget(target_type=target_type, value=str(resolved.path))
        state = ScanState(target=target, max_iterations=self.config.scan.max_iterations)

        try:
            # Phase 1: Discovery
            await self.event_bus.phase(ScanPhase.DISCOVERING, "Discovering ecosystems...")
            state = await self._discover(state)

            if not state.dependency_trees:
                await self.event_bus.phase(ScanPhase.FAILED, "No ecosystems detected")
                raise ScanError(f"No supported ecosystems found in {target_value}")

            # Phase 1a: Incremental diff filtering
            if baseline_trees is not None:
                from chainreaper.core.diff import compute_diff, filter_trees_to_diff

                diff = compute_diff(baseline_trees, state.dependency_trees)
                await self.event_bus.phase(
                    ScanPhase.DISCOVERING,
                    f"Incremental scan: {diff.summary}",
                )
                if diff_only:
                    if not diff.has_changes:
                        await self.event_bus.phase(
                            ScanPhase.COMPLETED,
                            "No dependency changes detected — nothing to scan",
                        )
                        state.is_complete = True
                        return self._compile_result(state)
                    state.dependency_trees = filter_trees_to_diff(state.dependency_trees, diff)
                    total = sum(t.total_count for t in state.dependency_trees)
                    await self.event_bus.phase(
                        ScanPhase.DISCOVERING,
                        f"Scanning {total} changed dependencies only",
                    )

            # Phase 1b: CVE scan (known vulnerabilities from OSV.dev)
            await self.event_bus.phase(ScanPhase.CVE_SCANNING, "Scanning for known CVEs...")
            state = await self._cve_scan(state)

            # Phase 1c: Source provenance verification
            await self.event_bus.phase(ScanPhase.CVE_SCANNING, "Checking source provenance...")
            state = await self._source_provenance(state)

            # Phase 2: LLM plans attack strategy
            await self.event_bus.phase(ScanPhase.PLANNING, "LLM planning attack strategy...")
            state = await self._plan_attack(state)

            # Phase 3: ReAct analysis loop
            await self.event_bus.phase(ScanPhase.ANALYZING, "Starting LLM-driven analysis...")
            state = await self._analyze(state)

            # Phase 4: LLM verifies findings (optional)
            if not skip_verification and state.findings:
                await self.event_bus.phase(ScanPhase.REPORTING, "LLM verifying findings...")
                state = await self._verify_findings(state)
            elif skip_verification:
                state.pre_verification_count = len(state.findings)
                state.post_verification_count = len(state.findings)

            # Phase 4b: Confidence calibration
            state = self._calibrate_confidence(state)

            # Phase 5: Attack graph construction
            await self.event_bus.phase(ScanPhase.BUILDING_GRAPH, "Building attack graph...")
            state.attack_graph = await self.planner.build_graph(state)

            # Phase 6: Compile result
            await self.event_bus.phase(ScanPhase.COMPLETED, "Scan complete")
            return self._compile_result(state)

        except Exception as e:
            state.phase = ScanPhase.FAILED
            state.error = str(e)
            await self.event_bus.phase(ScanPhase.FAILED, str(e))
            raise

    async def _discover(self, state: ScanState) -> ScanState:
        """Discover ecosystems and build dependency trees."""
        target_path = self._resolve_target_path(state.target)
        ecosystems = EcosystemRegistry.get_all()

        for name, eco_cls in ecosystems.items():
            eco = eco_cls()
            if eco.detect(target_path):
                logger.info("Detected ecosystem: %s", name)
                tree = await eco.parse(target_path)
                if tree:
                    state.dependency_trees.append(tree)
                    await self.event_bus.phase(
                        ScanPhase.DISCOVERING,
                        f"Found {name}: {tree.total_count} dependencies",
                        ecosystem=name,
                        dependency_count=tree.total_count,
                    )

        return state

    async def _cve_scan(self, state: ScanState) -> ScanState:
        """Scan dependencies for known CVEs via OSV.dev (Phase 1b)."""
        from chainreaper.agents.cve_scanner import scan_cves

        try:
            cve_findings = await scan_cves(
                state.dependency_trees,
                ignore_cve_ids=self.config.ignore.cve_ids,
            )
            for finding in cve_findings:
                state.add_finding(finding)

            if cve_findings:
                await self.event_bus.phase(
                    ScanPhase.CVE_SCANNING,
                    f"Found {len(cve_findings)} known vulnerabilities",
                )
            else:
                await self.event_bus.phase(
                    ScanPhase.CVE_SCANNING,
                    "No known CVEs found",
                )
        except Exception as e:
            logger.warning("CVE scan failed (non-critical): %s", e)
            await self.event_bus.phase(ScanPhase.CVE_SCANNING, "CVE scan skipped (error)")

        # Threat intelligence: check for known-malicious packages
        from chainreaper.agents.threat_intel import check_malicious_packages

        try:
            malicious_findings = await check_malicious_packages(state.dependency_trees)
            for finding in malicious_findings:
                state.add_finding(finding)
            if malicious_findings:
                await self.event_bus.phase(
                    ScanPhase.CVE_SCANNING,
                    f"Found {len(malicious_findings)} known-malicious packages!",
                )
        except Exception as e:
            logger.warning("Threat intel check failed: %s", e)

        return state

    async def _source_provenance(self, state: ScanState) -> ScanState:
        """Check source provenance for direct dependencies (Phase 1c)."""
        from chainreaper.agents.source_verifier import verify_source_provenance

        try:
            provenance_findings = await verify_source_provenance(state.dependency_trees)
            for finding in provenance_findings:
                state.add_finding(finding)
            if provenance_findings:
                await self.event_bus.phase(
                    ScanPhase.CVE_SCANNING,
                    f"Found {len(provenance_findings)} provenance gaps",
                )
        except Exception as e:
            logger.warning("Source provenance check failed: %s", e)

        return state

    def _calibrate_confidence(self, state: ScanState) -> ScanState:
        """Calibrate finding confidence against ground truth (Phase 4b)."""
        from chainreaper.agents.confidence import ConfidenceCalibrator
        from chainreaper.core.constants import AttackVector

        cve_findings = [f for f in state.findings if f.attack_vector == AttackVector.KNOWN_CVE]
        malicious_findings = [
            f
            for f in state.findings
            if f.attack_vector == AttackVector.MALICIOUS_PACKAGE and f.confidence == 1.0
        ]

        calibrator = ConfidenceCalibrator(
            cve_findings=cve_findings,
            malicious_findings=malicious_findings,
        )

        state.findings = calibrator.calibrate(state.findings)

        warnings = calibrator.flag_inconsistencies(state.findings)
        for w in warnings:
            logger.warning("Confidence warning: %s", w["message"])

        return state

    async def _plan_attack(self, state: ScanState) -> ScanState:
        """LLM plans the attack strategy before analysis begins."""
        from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM, SCAN_PLANNER

        ecosystems_summary = "\n".join(
            f"- {t.ecosystem.value}: {t.total_count} dependencies "
            f"({len(t.direct_dependencies)} direct, {len(t.transitive_dependencies)} transitive)"
            for t in state.dependency_trees
        )

        available = AnalyzerRegistry.get_all()
        analyzers_summary = "\n".join(
            f"- {name}: {cls.description}" for name, cls in available.items()
        )

        prompt = SCAN_PLANNER.format(
            ecosystems_summary=ecosystems_summary,
            available_analyzers=analyzers_summary,
        )

        try:
            response = await self.router.complete(
                messages=[
                    {"role": "system", "content": CHAINREAPER_SYSTEM},
                    {"role": "user", "content": prompt},
                ],
            )
            plan_text = response.content[:500]
            logger.info("LLM attack plan: %s", plan_text)
            await self.event_bus.phase(
                ScanPhase.PLANNING,
                f"Attack strategy planned: {plan_text[:100]}...",
            )
        except Exception as e:
            logger.warning("Planning phase failed (non-critical): %s", e)
            await self.event_bus.phase(ScanPhase.PLANNING, "Using default strategy")

        return state

    async def _analyze(self, state: ScanState) -> ScanState:
        """Run the ReAct analysis loop until LLM decides to stop."""
        while not state.is_complete and state.iteration < state.max_iterations:
            try:
                # Ask LLM what to do next
                decision = await self.reasoner.decide_next(state)

                thought = AgentThought(
                    thought=decision.thought,
                    action=decision.next_action,
                    action_params=decision.action_params,
                )

                if not decision.should_continue:
                    thought.observation = decision.reasoning_for_stop or "Analysis complete."
                    state.add_thought(thought)
                    state.is_complete = True
                    break

                # Execute the chosen analyzer
                if decision.next_action:
                    analyzer_cls = AnalyzerRegistry.get(decision.next_action)
                    if analyzer_cls:
                        analyzer = analyzer_cls()
                        state.analyzer_statuses[decision.next_action] = AnalyzerStatus(
                            name=decision.next_action, status="running"
                        )
                        await self.event_bus.phase(
                            ScanPhase.ANALYZING,
                            f"Running {decision.next_action}...",
                            analyzer=decision.next_action,
                        )

                        try:
                            findings = await analyzer.analyze(
                                context=state.to_context(),
                                llm=self.structured_llm,
                                router=self.router,
                            )

                            above_threshold = [
                                f
                                for f in findings
                                if f.confidence >= self.config.scan.min_confidence
                            ]
                            for finding in above_threshold:
                                state.add_finding(finding)

                            state.analyzer_statuses[decision.next_action].status = "done"
                            state.analyzer_statuses[decision.next_action].findings_count = len(
                                above_threshold
                            )

                            thought.observation = (
                                f"Found {len(findings)} potential issues, "
                                f"{len(above_threshold)} above confidence threshold."
                            )
                        except Exception as analyzer_err:
                            logger.warning(
                                "Analyzer %s failed: %s", decision.next_action, analyzer_err
                            )
                            state.analyzer_statuses[decision.next_action].status = "failed"
                            state.analyzer_statuses[decision.next_action].error = str(analyzer_err)
                            thought.observation = (
                                f"Analyzer '{decision.next_action}' failed: {type(analyzer_err).__name__}. "
                                f"Skipping and continuing."
                            )

                        await self.event_bus.phase(
                            ScanPhase.ANALYZING,
                            f"{decision.next_action}: done",
                        )
                    else:
                        thought.observation = f"Analyzer '{decision.next_action}' not found."

                state.add_thought(thought)

            except Exception as loop_err:
                logger.error("ReAct iteration %d failed: %s", state.iteration, loop_err)
                state.add_thought(
                    AgentThought(
                        thought=f"Iteration failed: {type(loop_err).__name__}",
                        observation=f"Error: {loop_err}. Continuing to next iteration.",
                    )
                )
                # Don't crash the entire scan for one bad iteration
                if state.iteration >= state.max_iterations - 1:
                    break

        return state

    async def _verify_findings(self, state: ScanState) -> ScanState:
        """LLM verifies, filters, and prioritizes findings."""
        if not state.findings:
            logger.info("No findings to verify, skipping verification phase.")
            return state

        pre_count = len(state.findings)
        state.pre_verification_count = pre_count
        verified = await self.verifier.verify(state.findings)
        state.findings = verified
        post_count = len(state.findings)
        state.post_verification_count = post_count

        await self.event_bus.phase(
            ScanPhase.REPORTING,
            f"Verification complete: {post_count}/{pre_count} findings verified "
            f"({pre_count - post_count} filtered as false positives)",
        )

        return state

    def _compile_result(self, state: ScanState) -> ScanResult:
        """Compile the final scan result."""
        from datetime import UTC, datetime

        from chainreaper import __version__
        from chainreaper.core.models import AnalyzerRunInfo

        summary = ScanSummary.from_findings(state.findings, state.dependency_trees)
        summary.attack_paths_found = len(state.attack_graph.paths)

        analyzer_runs = [
            AnalyzerRunInfo(
                name=s.name,
                status=s.status,
                findings_count=s.findings_count,
                error=s.error,
            )
            for s in state.analyzer_statuses.values()
        ]

        return ScanResult(
            target=state.target,
            findings=state.findings,
            dependency_trees=state.dependency_trees,
            attack_graph=state.attack_graph,
            summary=summary,
            metadata=ScanMetadata(
                chainreaper_version=__version__,
                llm_model=self.config.llm.provider_chain[0].model
                if self.config.llm.provider_chain
                else "",
                llm_cost_usd=self.cost_tracker.total_cost_usd,
                llm_input_tokens=self.cost_tracker.total_input_tokens,
                llm_output_tokens=self.cost_tracker.total_output_tokens,
                completed_at=datetime.now(UTC),
                analyzer_runs=analyzer_runs,
                pre_verification_count=state.pre_verification_count,
                post_verification_count=state.post_verification_count,
            ),
        )

    def _detect_target_type(self, value: str) -> TargetType:
        """Auto-detect target type from the value."""
        if value.startswith(("http://", "https://", "git@")):
            return TargetType.REPO_URL
        path = Path(value)
        if path.is_dir():
            return TargetType.LOCAL_PATH
        if path.is_file():
            name = path.name.lower()
            if name.endswith((".json", ".lock", ".txt", ".toml", ".sum")):
                return TargetType.LOCKFILE
            if name.endswith((".spdx", ".cdx", ".bom")):
                return TargetType.SBOM
        return TargetType.LOCAL_PATH

    def _resolve_target_path(self, target: ScanTarget) -> Path:
        """Resolve a scan target to a local filesystem path with validation."""
        if target.target_type == TargetType.REPO_URL:
            # URLs are now resolved in scan() before reaching here
            pass

        resolved = Path(target.value).resolve()

        # Validate path exists
        if not resolved.exists():
            raise ScanError(f"Target path does not exist: {resolved}")

        # For lockfiles, use parent directory
        if target.target_type == TargetType.LOCKFILE:
            if not resolved.is_file():
                raise ScanError(f"Lockfile target is not a file: {resolved}")
            resolved = resolved.parent

        # Validate it's a directory
        if not resolved.is_dir():
            raise ScanError(f"Target path is not a directory: {resolved}")

        return resolved
