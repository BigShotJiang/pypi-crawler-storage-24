"""Confidence calibration — grounds LLM findings against factual data sources.

Addresses LLM hallucination risk by:
1. Cross-referencing findings with OSV.dev / registry APIs (ground truth)
2. Penalizing findings that contradict factual data
3. Boosting findings corroborated by multiple sources
4. Detecting inconsistent severity/confidence patterns
5. Flagging non-deterministic findings across repeated analysis
"""

from __future__ import annotations

import logging
from typing import Any

from chainreaper.core.constants import AttackVector, Severity
from chainreaper.core.models import Finding

logger = logging.getLogger(__name__)

# Findings from these vectors are grounded in factual data (not LLM-generated)
_FACTUAL_VECTORS = {
    AttackVector.KNOWN_CVE,  # From OSV.dev API
}

# These vectors produce findings the LLM can hallucinate about
_LLM_GENERATED_VECTORS = {
    AttackVector.DEPENDENCY_CONFUSION,
    AttackVector.TYPOSQUATTING,
    AttackVector.COMPROMISED_MAINTAINER,
    AttackVector.MALICIOUS_PACKAGE,
    AttackVector.ABANDONED_TAKEOVER,
    AttackVector.PROTESTWARE,
    AttackVector.SOURCE_BINARY_MISMATCH,
}

# Confidence adjustments
_CONFIDENCE_BOOST_MULTI_SOURCE = 0.1  # Corroborated by factual source
_CONFIDENCE_PENALTY_NO_EVIDENCE = -0.3  # No API evidence backing the claim (aggressive FP filter)
_CONFIDENCE_PENALTY_HIGH_SEVERITY_LOW_CONF = -0.2  # Critical finding with low confidence
_CONFIDENCE_PENALTY_MALICIOUS_UNCONFIRMED = -0.85  # "malicious" without threat intel = almost certainly FP


class ConfidenceCalibrator:
    """Calibrates finding confidence scores against ground truth data."""

    def __init__(
        self,
        cve_findings: list[Finding] | None = None,
        malicious_findings: list[Finding] | None = None,
    ) -> None:
        """Initialize with ground truth findings from Phase 0.

        Args:
            cve_findings: Findings from OSV.dev CVE scanner (factual)
            malicious_findings: Findings from threat intel feed (factual)
        """
        self._cve_packages: set[str] = set()
        self._malicious_packages: set[str] = set()

        for f in cve_findings or []:
            self._cve_packages.add(f"{f.ecosystem.value}:{f.package_name}")
        for f in malicious_findings or []:
            self._malicious_packages.add(f"{f.ecosystem.value}:{f.package_name}")

    def calibrate(self, findings: list[Finding]) -> list[Finding]:
        """Calibrate confidence scores and add calibration metadata.

        Returns a new list of findings with adjusted confidence.
        Findings below 0.1 confidence after calibration are dropped.
        """
        calibrated: list[Finding] = []
        dropped = 0

        for finding in findings:
            if finding.attack_vector in _FACTUAL_VECTORS:
                # Don't adjust factual findings
                calibrated.append(finding)
                continue

            adjusted = finding.model_copy(deep=True)
            adjustments: list[dict[str, Any]] = []

            pkg_key = f"{finding.ecosystem.value}:{finding.package_name}"

            # Boost: package also has known CVEs (corroborating signal)
            if pkg_key in self._cve_packages:
                adjusted.confidence = min(1.0, adjusted.confidence + _CONFIDENCE_BOOST_MULTI_SOURCE)
                adjustments.append(
                    {
                        "type": "boost_cve_corroboration",
                        "delta": _CONFIDENCE_BOOST_MULTI_SOURCE,
                        "reason": "Package has known CVEs confirming it's a real dependency",
                    }
                )

            # Boost: package is known-malicious (strong corroboration)
            if pkg_key in self._malicious_packages:
                adjusted.confidence = min(1.0, adjusted.confidence + 0.2)
                adjustments.append(
                    {
                        "type": "boost_malicious_corroboration",
                        "delta": 0.2,
                        "reason": "Package flagged by threat intelligence as malicious",
                    }
                )

            # Penalty: no API evidence in raw_data
            has_api_evidence = bool(finding.evidence.api_responses)
            if not has_api_evidence and finding.attack_vector in _LLM_GENERATED_VECTORS:
                adjusted.confidence = max(
                    0.0, adjusted.confidence + _CONFIDENCE_PENALTY_NO_EVIDENCE
                )
                adjustments.append(
                    {
                        "type": "penalty_no_api_evidence",
                        "delta": _CONFIDENCE_PENALTY_NO_EVIDENCE,
                        "reason": "Finding has no API evidence backing the LLM's claim",
                    }
                )

            # Penalty: high severity with low original confidence
            if finding.severity in (Severity.CRITICAL, Severity.HIGH) and finding.confidence < 0.5:
                adjusted.confidence = max(
                    0.0, adjusted.confidence + _CONFIDENCE_PENALTY_HIGH_SEVERITY_LOW_CONF
                )
                adjustments.append(
                    {
                        "type": "penalty_severity_confidence_mismatch",
                        "delta": _CONFIDENCE_PENALTY_HIGH_SEVERITY_LOW_CONF,
                        "reason": f"High severity ({finding.severity.value}) but low confidence "
                        f"({finding.confidence:.0%}) suggests LLM uncertainty",
                    }
                )

            # Penalty: LLM claims package is malicious but threat intel doesn't confirm
            if (
                finding.attack_vector == AttackVector.MALICIOUS_PACKAGE
                and pkg_key not in self._malicious_packages
            ):
                adjusted.confidence = max(
                    0.0, adjusted.confidence + _CONFIDENCE_PENALTY_MALICIOUS_UNCONFIRMED
                )
                adjustments.append(
                    {
                        "type": "penalty_malicious_unconfirmed",
                        "delta": _CONFIDENCE_PENALTY_MALICIOUS_UNCONFIRMED,
                        "reason": "LLM claims malicious but not confirmed by threat intel feeds "
                        "(OSV/OpenSSF). Likely a false positive from LLM hallucination.",
                    }
                )

            # Store calibration metadata
            adjusted.evidence.raw_data["confidence_calibration"] = {
                "original_confidence": finding.confidence,
                "calibrated_confidence": adjusted.confidence,
                "adjustments": adjustments,
            }

            # Drop findings that fall below minimum threshold
            if adjusted.confidence < 0.1:
                logger.info(
                    "Dropping low-confidence finding after calibration: %s (%.0f%%)",
                    finding.title,
                    adjusted.confidence * 100,
                )
                dropped += 1
                continue

            calibrated.append(adjusted)

        if dropped:
            logger.info(
                "Confidence calibration: %d findings kept, %d dropped",
                len(calibrated),
                dropped,
            )

        return calibrated

    def flag_inconsistencies(self, findings: list[Finding]) -> list[dict[str, str]]:
        """Flag findings with inconsistent signals (for logging/debugging).

        Returns list of warning dicts, not finding modifications.
        """
        warnings: list[dict[str, str]] = []

        for f in findings:
            # Flag: critical severity but only medium confidence
            if f.severity == Severity.CRITICAL and f.confidence < 0.7:
                warnings.append(
                    {
                        "finding_id": f.id,
                        "type": "severity_confidence_gap",
                        "message": (
                            f"Critical finding '{f.title}' has only {f.confidence:.0%} confidence. "
                            "Consider manual review."
                        ),
                    }
                )

            # Flag: LLM-generated finding contradicts factual data
            pkg_key = f"{f.ecosystem.value}:{f.package_name}"
            if (
                f.attack_vector == AttackVector.MALICIOUS_PACKAGE
                and pkg_key not in self._malicious_packages
                and f.confidence < 0.8
            ):
                warnings.append(
                    {
                        "finding_id": f.id,
                        "type": "unconfirmed_malicious",
                        "message": (
                            f"'{f.package_name}' flagged as malicious by LLM but not found in "
                            "threat intelligence feeds. May be a false positive."
                        ),
                    }
                )

        return warnings
