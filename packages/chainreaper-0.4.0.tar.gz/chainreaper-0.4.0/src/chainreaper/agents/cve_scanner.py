"""CVE scanner — queries OSV.dev for known vulnerabilities before LLM analysis."""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Any

import httpx

from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import DependencyNode, DependencyTree, Evidence, Finding

logger = logging.getLogger(__name__)

OSV_API_URL = "https://api.osv.dev/v1/query"

# Map ecosystem names to OSV ecosystem identifiers
_ECOSYSTEM_TO_OSV: dict[EcosystemName, str] = {
    EcosystemName.NPM: "npm",
    EcosystemName.PYPI: "PyPI",
    EcosystemName.MAVEN: "Maven",
    EcosystemName.GO: "Go",
    EcosystemName.CARGO: "crates.io",
    EcosystemName.RUBYGEMS: "RubyGems",
    EcosystemName.NUGET: "NuGet",
}

# Map CVSS score ranges to severity
_CVSS_TO_SEVERITY: list[tuple[float, Severity]] = [
    (9.0, Severity.CRITICAL),
    (7.0, Severity.HIGH),
    (4.0, Severity.MEDIUM),
    (0.1, Severity.LOW),
]

# Rate limiting
_MAX_CONCURRENCY = 10
_DELAY = 0.05  # 50ms between requests

# Package name validation: alphanumeric, hyphens, dots, underscores, slashes, @scopes
_VALID_PACKAGE_RE = re.compile(r"^[@a-zA-Z0-9][\w./@-]{0,213}$")


def _cvss_to_severity(score: float) -> Severity:
    """Convert CVSS score to ChainReaper severity."""
    for threshold, severity in _CVSS_TO_SEVERITY:
        if score >= threshold:
            return severity
    return Severity.INFO


def _parse_cvss_vector_score(vector: str) -> float | None:
    """Parse a numeric CVSS score from a CVSS v3 vector string.

    Uses the base metrics to compute an approximate score.
    Falls back to None if the vector cannot be parsed.
    """
    # Try to extract score if appended (some sources use "CVSS:3.1/.../score:7.5")
    score_match = re.search(r"/score[:/](\d+\.?\d*)", vector, re.IGNORECASE)
    if score_match:
        return float(score_match.group(1))

    # Approximate CVSS 3.x base score from vector metrics
    # Weights based on CVSS v3.1 specification
    av_scores = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.20}
    ac_scores = {"L": 0.77, "H": 0.44}
    pr_scores = {"N": 0.85, "L": 0.62, "H": 0.27}
    ui_scores = {"N": 0.85, "R": 0.62}
    ci_scores = {"H": 0.56, "L": 0.22, "N": 0.0}  # C, I, A use same scale

    metrics: dict[str, str] = {}
    for part in vector.split("/"):
        if ":" in part:
            key, val = part.split(":", 1)
            metrics[key.upper()] = val.upper()

    try:
        av = av_scores.get(metrics.get("AV", ""))
        ac = ac_scores.get(metrics.get("AC", ""))
        pr = pr_scores.get(metrics.get("PR", ""))
        ui = ui_scores.get(metrics.get("UI", ""))
        c = ci_scores.get(metrics.get("C", ""))
        i = ci_scores.get(metrics.get("I", ""))
        a = ci_scores.get(metrics.get("A", ""))

        if any(v is None for v in [av, ac, pr, ui, c, i, a]):
            return None

        # ISS = 1 - [(1-C) * (1-I) * (1-A)]
        iss = 1.0 - ((1.0 - c) * (1.0 - i) * (1.0 - a))  # type: ignore[operator]
        if iss <= 0:
            return 0.0

        # Impact
        scope_changed = metrics.get("S", "U") == "C"
        impact = 7.52 * (iss - 0.029) - 3.25 * ((iss - 0.02) ** 15) if scope_changed else 6.42 * iss

        # Exploitability = 8.22 * AV * AC * PR * UI
        exploitability = 8.22 * av * ac * pr * ui  # type: ignore[operator]

        if impact <= 0:
            return 0.0

        if scope_changed:
            base = min(1.08 * (impact + exploitability), 10.0)
        else:
            base = min(impact + exploitability, 10.0)

        # Round up to 1 decimal
        return round(base * 10) / 10
    except (KeyError, TypeError):
        return None


def _extract_cvss(vuln: dict[str, Any]) -> float | None:
    """Extract CVSS score from OSV vulnerability data.

    OSV severity[].score is a CVSS vector string (not a numeric score).
    We parse the vector to compute the numeric score.
    Also checks database_specific for numeric scores.
    """
    for severity_entry in vuln.get("severity", []):
        if severity_entry.get("type") == "CVSS_V3":
            score_str = severity_entry.get("score", "")
            if not score_str:
                continue
            # First try as a numeric score (some feeds provide this directly)
            try:
                return float(score_str)
            except (ValueError, TypeError):
                pass
            # Parse as CVSS vector string
            if score_str.startswith("CVSS:"):
                parsed = _parse_cvss_vector_score(score_str)
                if parsed is not None:
                    return parsed
    # Try database_specific
    db = vuln.get("database_specific", {})
    if "cvss" in db:
        try:
            return float(db["cvss"])
        except (ValueError, TypeError):
            pass
    return None


def _extract_severity_from_osv(vuln: dict[str, Any]) -> Severity:
    """Extract severity from OSV data, falling back to CVSS."""
    cvss = _extract_cvss(vuln)
    if cvss is not None:
        return _cvss_to_severity(cvss)

    # Try database_specific severity string
    db = vuln.get("database_specific", {})
    sev_str = db.get("severity", "").upper()
    try:
        return Severity(sev_str.lower())
    except ValueError:
        pass

    # Default based on whether it has a CVE
    aliases = vuln.get("aliases", [])
    has_cve = any(a.startswith("CVE-") for a in aliases)
    return Severity.HIGH if has_cve else Severity.MEDIUM


def _is_valid_package_name(name: str) -> bool:
    """Validate package name before sending to external API."""
    if not name or len(name) > 214:
        return False
    if any(c in name for c in ("\n", "\r", "\x00")):
        return False
    return bool(_VALID_PACKAGE_RE.match(name))


async def query_osv(
    package_name: str,
    package_version: str,
    osv_ecosystem: str,
    client: httpx.AsyncClient,
    semaphore: asyncio.Semaphore | None = None,
) -> list[dict[str, Any]]:
    """Query OSV.dev for vulnerabilities affecting a specific package version."""
    if not _is_valid_package_name(package_name):
        logger.warning("Invalid package name, skipping OSV query: %r", package_name[:50])
        return []

    payload = {
        "version": package_version,
        "package": {"name": package_name, "ecosystem": osv_ecosystem},
    }

    async def _do_query() -> list[dict[str, Any]]:
        await asyncio.sleep(_DELAY)
        try:
            resp = await client.post(OSV_API_URL, json=payload, timeout=10.0)
            if resp.status_code == 200:
                data = resp.json()
                vulns: list[dict[str, Any]] = data.get("vulns", [])
                return vulns
            logger.warning("OSV API returned %d for %s", resp.status_code, package_name)
        except (httpx.HTTPError, httpx.TimeoutException) as e:
            logger.warning("OSV query failed for %s: %s", package_name, e)
        return []

    if semaphore:
        async with semaphore:
            return await _do_query()
    return await _do_query()


def _vuln_to_finding(
    vuln: dict[str, Any],
    dep: DependencyNode,
    ecosystem: EcosystemName,
) -> Finding:
    """Convert an OSV vulnerability to a ChainReaper Finding."""
    vuln_id = vuln.get("id", "unknown")
    summary = vuln.get("summary", vuln.get("details", "No description available."))[:500]
    aliases = vuln.get("aliases", [])
    cve_ids = [a for a in aliases if a.startswith("CVE-")]
    references = [ref.get("url", "") for ref in vuln.get("references", []) if ref.get("url")]
    cvss = _extract_cvss(vuln)
    severity = _extract_severity_from_osv(vuln)

    return Finding(
        title=f"Known vulnerability: {vuln_id} in {dep.name}@{dep.version}",
        description=(
            f"{vuln_id}: {summary}\n\n"
            f"Package: {dep.name}@{dep.version} ({ecosystem.value})\n"
            f"CVEs: {', '.join(cve_ids) if cve_ids else 'None assigned'}"
        ),
        severity=severity,
        confidence=1.0,  # CVE data is factual, not probabilistic
        attack_vector=AttackVector.KNOWN_CVE,
        ecosystem=ecosystem,
        package_name=dep.name,
        package_version=dep.version,
        evidence=Evidence(
            description=f"Reported by OSV.dev ({vuln_id})",
            raw_data={"osv_id": vuln_id, "aliases": aliases},
            api_responses=[{"source": "osv.dev", "vuln_id": vuln_id}],
        ),
        remediation=_build_remediation(vuln, dep),
        references=references[:5],
        cwe_ids=_extract_cwes(vuln),
        cve_ids=cve_ids,
        cvss_score=cvss,
    )


def _build_remediation(vuln: dict[str, Any], dep: DependencyNode) -> str:
    """Build remediation text from OSV fix data."""
    for affected in vuln.get("affected", []):
        for rng in affected.get("ranges", []):
            for event in rng.get("events", []):
                fixed = event.get("fixed")
                if fixed:
                    return f"Upgrade {dep.name} from {dep.version} to >={fixed}"
    return f"Check {vuln.get('id', 'advisory')} for patched versions of {dep.name}."


def _extract_cwes(vuln: dict[str, Any]) -> list[str]:
    """Extract CWE IDs from OSV data."""
    cwes: list[str] = []
    db = vuln.get("database_specific", {})
    for cwe in db.get("cwe_ids", []):
        if isinstance(cwe, str) and cwe.startswith("CWE-"):
            cwes.append(cwe)
    return cwes


def _should_ignore_vuln(vuln: dict[str, Any], ignore_set: set[str]) -> bool:
    """Check if a vulnerability should be ignored by id or aliases."""
    if not ignore_set:
        return False
    vuln_id = vuln.get("id", "")
    if vuln_id in ignore_set:
        return True
    aliases = set(vuln.get("aliases", []))
    return bool(aliases & ignore_set)


async def scan_cves(
    dependency_trees: list[DependencyTree],
    ignore_cve_ids: list[str] | None = None,
) -> list[Finding]:
    """Scan all dependencies for known CVEs via OSV.dev.

    Runs before the LLM analysis loop. Uses concurrent API calls
    with a semaphore for rate limiting.
    """
    ignore_set = set(ignore_cve_ids or [])
    findings: list[Finding] = []
    semaphore = asyncio.Semaphore(_MAX_CONCURRENCY)

    async with httpx.AsyncClient(follow_redirects=False) as client:
        for tree in dependency_trees:
            osv_eco = _ECOSYSTEM_TO_OSV.get(tree.ecosystem)
            if not osv_eco:
                logger.info("No OSV mapping for ecosystem %s, skipping CVE scan", tree.ecosystem)
                continue

            all_deps = tree.direct_dependencies + tree.transitive_dependencies
            # Cap at 200 deps to avoid excessive API calls
            deps_to_scan = [
                dep
                for dep in all_deps[:200]
                if dep.version and dep.version not in ("*", "latest", "")
            ]

            # Concurrent queries with semaphore rate limiting
            tasks = [
                query_osv(dep.name, dep.version, osv_eco, client, semaphore) for dep in deps_to_scan
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for dep, result in zip(deps_to_scan, results, strict=True):
                if isinstance(result, BaseException):
                    logger.warning("OSV query failed for %s: %s", dep.name, result)
                    continue
                vulns: list[dict[str, Any]] = result
                for vuln in vulns:
                    if _should_ignore_vuln(vuln, ignore_set):
                        logger.debug("Skipping ignored vuln: %s", vuln.get("id"))
                        continue
                    findings.append(_vuln_to_finding(vuln, dep, tree.ecosystem))

    logger.info("CVE scan complete: %d known vulnerabilities found", len(findings))
    return findings
