"""LLM-powered findings verification — validates, enriches, and filters findings."""

from __future__ import annotations

import logging

from pydantic import BaseModel, Field

from chainreaper.core.models import Finding
from chainreaper.llm.prompts.system import CHAINREAPER_SYSTEM, FINDINGS_VERIFIER
from chainreaper.llm.structured import StructuredLLM

logger = logging.getLogger(__name__)


# ── Pydantic models for structured LLM output ────────────────


class VerifiedFinding(BaseModel):
    """LLM verification result for a single finding."""

    original_finding_id: str = Field(description="ID of the original finding being verified")
    is_verified: bool = Field(
        description="Whether the finding appears to be a real, legitimate security issue"
    )
    exploitability_score: int = Field(
        ge=0,
        le=10,
        description="How exploitable this finding is (0=theoretical, 10=trivially exploitable)",
    )
    false_positive_likelihood: float = Field(
        ge=0.0,
        le=1.0,
        description="Probability this is a false positive (0.0=definitely real, 1.0=definitely FP)",
    )
    priority_rank: int = Field(
        ge=1,
        description="Suggested priority rank (1=fix first, higher=lower priority)",
    )
    additional_context: str = Field(
        description=(
            "Extra context the LLM provides: why it's real/FP, "
            "exploitation scenario details, or caveats"
        ),
    )


class VerificationResult(BaseModel):
    """Complete verification output from the LLM."""

    verified_findings: list[VerifiedFinding] = Field(
        description="Verification results for each finding"
    )
    overall_assessment: str = Field(
        description="High-level summary of the findings quality and risk posture"
    )


# ── Verifier agent ───────────────────────────────────────────


class FindingsVerifier:
    """Uses the LLM to validate and enrich findings after analysis.

    Responsibilities:
    - Verify each finding is a real issue (not hallucinated by analyzers)
    - Rate exploitability on a 0-10 scale
    - Estimate false-positive likelihood
    - Suggest priority ordering across all findings
    - Filter out likely false positives (false_positive_likelihood > 0.7)
    - Add exploitability context to remaining findings
    """

    FP_THRESHOLD = 0.7

    def __init__(self, structured_llm: StructuredLLM) -> None:
        self.llm = structured_llm

    async def verify(self, findings: list[Finding]) -> list[Finding]:
        """Verify findings via LLM and return filtered, enriched results.

        Findings with false_positive_likelihood > 0.7 are removed.
        Remaining findings are enriched with exploitability context
        and re-ordered by priority.
        """
        if not findings:
            logger.info("No findings to verify.")
            return []

        # Build the prompt
        findings_text = self._format_findings_for_prompt(findings)
        prompt = FINDINGS_VERIFIER.format(
            findings_text=findings_text,
            findings_count=len(findings),
        )

        messages = [
            {"role": "system", "content": CHAINREAPER_SYSTEM},
            {"role": "user", "content": prompt},
        ]

        try:
            result = await self.llm.extract(
                response_model=VerificationResult,
                messages=messages,
                max_retries=2,
            )
        except Exception as e:
            logger.warning(
                "LLM verification failed (non-critical), returning unfiltered findings: %s", e
            )
            return findings

        logger.info("LLM verification complete: %s", result.overall_assessment[:120])

        return self._apply_verification(findings, result)

    def _format_findings_for_prompt(self, findings: list[Finding]) -> str:
        """Format findings into a structured text block for the LLM."""
        parts: list[str] = []
        for i, f in enumerate(findings, 1):
            parts.append(
                f"### Finding {i} (ID: {f.id})\n"
                f"- **Title**: {f.title}\n"
                f"- **Severity**: {f.severity.value}\n"
                f"- **Package**: {f.package_name}"
                f"{f' v{f.package_version}' if f.package_version else ''}\n"
                f"- **Ecosystem**: {f.ecosystem.value}\n"
                f"- **Attack Vector**: {f.attack_vector.value}\n"
                f"- **Confidence**: {f.confidence:.0%}\n"
                f"- **Description**: {f.description}\n"
                f"- **Evidence**: {f.evidence.description}\n"
                f"- **CWE**: {', '.join(f.cwe_ids) if f.cwe_ids else 'N/A'}\n"
                f"- **Remediation**: {f.remediation}\n"
            )
        return "\n".join(parts)

    def _apply_verification(
        self, findings: list[Finding], result: VerificationResult
    ) -> list[Finding]:
        """Apply LLM verification: filter FPs, enrich, and re-order."""
        # Index verification results by finding ID
        verification_map: dict[str, VerifiedFinding] = {
            vf.original_finding_id: vf for vf in result.verified_findings
        }

        enriched: list[tuple[int, Finding]] = []

        for finding in findings:
            vf = verification_map.get(finding.id)

            if vf is None:
                # LLM didn't return verification for this finding — keep it
                logger.debug("No verification for finding %s, keeping as-is.", finding.id)
                enriched.append((999, finding))
                continue

            # Filter out likely false positives
            if vf.false_positive_likelihood > self.FP_THRESHOLD:
                logger.info(
                    "Filtering out likely false positive: %s (FP likelihood: %.0f%%)",
                    finding.title,
                    vf.false_positive_likelihood * 100,
                )
                continue

            # Enrich the finding with verification context
            enriched_finding = finding.model_copy(deep=True)

            # Add exploitability context to description
            context_suffix = (
                f"\n\n[LLM Verification] Exploitability: {vf.exploitability_score}/10 | "
                f"FP Likelihood: {vf.false_positive_likelihood:.0%} | "
                f"{vf.additional_context}"
            )
            enriched_finding.description += context_suffix

            # Store verification metadata in evidence
            enriched_finding.evidence.raw_data["verification"] = {
                "is_verified": vf.is_verified,
                "exploitability_score": vf.exploitability_score,
                "false_positive_likelihood": vf.false_positive_likelihood,
                "priority_rank": vf.priority_rank,
                "additional_context": vf.additional_context,
            }

            enriched.append((vf.priority_rank, enriched_finding))

        # Sort by priority rank (lower = higher priority)
        enriched.sort(key=lambda x: x[0])

        verified_findings = [f for _, f in enriched]

        logger.info(
            "Verification result: %d/%d findings kept (filtered %d FPs)",
            len(verified_findings),
            len(findings),
            len(findings) - len(verified_findings),
        )

        return verified_findings
