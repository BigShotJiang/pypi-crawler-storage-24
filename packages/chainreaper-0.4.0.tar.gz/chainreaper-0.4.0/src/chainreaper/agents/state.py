"""Scan state management for the agent system."""

from __future__ import annotations

from dataclasses import dataclass, field

from chainreaper.core.constants import ScanPhase
from chainreaper.core.models import (
    AgentThought,
    AnalysisContext,
    AttackGraph,
    DependencyTree,
    Finding,
    ScanTarget,
)


@dataclass
class AnalyzerStatus:
    """Track the execution status of a single analyzer."""

    name: str
    status: str = "pending"  # pending | running | done | failed
    findings_count: int = 0
    error: str | None = None


@dataclass
class ScanState:
    """Mutable state for a scan in progress."""

    target: ScanTarget
    phase: ScanPhase = ScanPhase.INITIALIZING
    dependency_trees: list[DependencyTree] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)
    thoughts: list[AgentThought] = field(default_factory=list)
    attack_graph: AttackGraph = field(default_factory=AttackGraph)
    iteration: int = 0
    max_iterations: int = 20
    is_complete: bool = False
    error: str | None = None
    analyzer_statuses: dict[str, AnalyzerStatus] = field(default_factory=dict)
    pre_verification_count: int = 0
    post_verification_count: int = 0

    def add_finding(self, finding: Finding) -> None:
        """Add a finding, deduplicating by package + version + vector."""
        key = (finding.package_name, finding.package_version, finding.attack_vector)
        existing_keys = {
            (f.package_name, f.package_version, f.attack_vector) for f in self.findings
        }
        if key not in existing_keys:
            self.findings.append(finding)

    def add_thought(self, thought: AgentThought) -> None:
        """Record a reasoning step."""
        self.thoughts.append(thought)
        self.iteration += 1

    def to_context(self) -> AnalysisContext:
        """Convert state to an analysis context for analyzers."""
        return AnalysisContext(
            target=self.target,
            dependency_trees=self.dependency_trees,
            findings_so_far=self.findings,
            thoughts=self.thoughts,
            iteration=self.iteration,
            max_iterations=self.max_iterations,
        )
