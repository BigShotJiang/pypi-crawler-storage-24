"""Threat intelligence feed — checks OpenSSF Malicious Packages via OSV.dev."""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Any

import httpx

from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import DependencyNode, DependencyTree, Evidence, Finding

logger = logging.getLogger(__name__)

OSV_API_URL = "https://api.osv.dev/v1/query"

# Map ecosystem names to OSV ecosystem identifiers
_ECOSYSTEM_TO_OSV: dict[EcosystemName, str] = {
    EcosystemName.NPM: "npm",
    EcosystemName.PYPI: "PyPI",
    EcosystemName.MAVEN: "Maven",
    EcosystemName.GO: "Go",
    EcosystemName.CARGO: "crates.io",
    EcosystemName.RUBYGEMS: "RubyGems",
    EcosystemName.NUGET: "NuGet",
}

# Rate limiting
_MAX_CONCURRENCY = 10
_DELAY = 0.05  # 50ms between requests

# Package name validation: alphanumeric, hyphens, dots, underscores, slashes, @scopes
_VALID_PACKAGE_RE = re.compile(r"^[@a-zA-Z0-9][\w./@-]{0,213}$")


def _is_valid_package_name(name: str) -> bool:
    """Validate package name before sending to external API."""
    if not name or len(name) > 214:
        return False
    if any(c in name for c in ("\n", "\r", "\x00")):
        return False
    return bool(_VALID_PACKAGE_RE.match(name))


def _is_malicious_advisory(vuln: dict[str, Any]) -> bool:
    """Determine if an OSV advisory indicates a confirmed malicious package.

    Returns True if:
    - Vuln ID starts with "MAL-" (OpenSSF Malicious Packages)
    - "malicious" appears in summary or details text
    - database_specific contains malicious indicators
    """
    vuln_id = vuln.get("id", "")
    if vuln_id.startswith("MAL-"):
        return True

    # Check for phrases that indicate the PACKAGE ITSELF is malicious,
    # not just that it's vulnerable to malicious input
    _MALICIOUS_PHRASES = [
        "malicious package",
        "malicious code",
        "malware",
        "backdoor",
        "trojan",
        "supply chain attack",
        "intentionally malicious",
    ]
    summary = vuln.get("summary", "").lower()
    details = vuln.get("details", "").lower()
    text = summary + " " + details
    if any(phrase in text for phrase in _MALICIOUS_PHRASES):
        return True

    db_specific = vuln.get("database_specific", {})
    if db_specific.get("malicious", False):
        return True
    db_type = str(db_specific.get("type", "")).lower()
    return db_type == "malicious_package"


async def query_osv_malicious(
    package_name: str,
    package_version: str,
    osv_ecosystem: str,
    client: httpx.AsyncClient,
    semaphore: asyncio.Semaphore | None = None,
) -> list[dict[str, Any]]:
    """Query OSV.dev and filter for malicious package advisories.

    Same pattern as cve_scanner.query_osv but returns only entries
    that indicate confirmed malicious packages (MAL- IDs, etc.).
    """
    if not _is_valid_package_name(package_name):
        logger.warning(
            "Invalid package name, skipping threat intel query: %r",
            package_name[:50],
        )
        return []

    payload = {
        "version": package_version,
        "package": {"name": package_name, "ecosystem": osv_ecosystem},
    }

    async def _do_query() -> list[dict[str, Any]]:
        await asyncio.sleep(_DELAY)
        try:
            resp = await client.post(OSV_API_URL, json=payload, timeout=10.0)
            if resp.status_code == 200:
                data = resp.json()
                vulns: list[dict[str, Any]] = data.get("vulns", [])
                return [v for v in vulns if _is_malicious_advisory(v)]
            logger.warning(
                "OSV API returned %d for %s (threat intel)",
                resp.status_code,
                package_name,
            )
        except (httpx.HTTPError, httpx.TimeoutException) as e:
            logger.warning("Threat intel query failed for %s: %s", package_name, e)
        return []

    if semaphore:
        async with semaphore:
            return await _do_query()
    return await _do_query()


def _malicious_to_finding(
    vuln: dict[str, Any],
    dep: DependencyNode,
    ecosystem: EcosystemName,
) -> Finding:
    """Convert a malicious package advisory to a ChainReaper Finding."""
    vuln_id = vuln.get("id", "unknown")
    summary = vuln.get("summary", vuln.get("details", "No description available."))[:500]
    aliases = vuln.get("aliases", [])
    references = [ref.get("url", "") for ref in vuln.get("references", []) if ref.get("url")]

    # MAL- prefixed IDs are confirmed malicious — highest confidence
    is_confirmed = vuln_id.startswith("MAL-")
    confidence = 1.0 if is_confirmed else 0.9

    return Finding(
        title=f"Known malicious package: {vuln_id} in {dep.name}@{dep.version}",
        description=(
            f"{vuln_id}: {summary}\n\n"
            f"Package: {dep.name}@{dep.version} ({ecosystem.value})\n"
            f"Source: OpenSSF Malicious Packages database\n"
            f"Aliases: {', '.join(aliases) if aliases else 'None'}"
        ),
        severity=Severity.CRITICAL,
        confidence=confidence,
        attack_vector=AttackVector.MALICIOUS_PACKAGE,
        ecosystem=ecosystem,
        package_name=dep.name,
        package_version=dep.version,
        evidence=Evidence(
            description=f"Reported by OSV.dev ({vuln_id}) — malicious package advisory",
            raw_data={"osv_id": vuln_id, "aliases": aliases, "malicious": True},
            api_responses=[{"source": "osv.dev", "vuln_id": vuln_id}],
        ),
        remediation=(
            f"IMMEDIATELY remove {dep.name}@{dep.version} from your project. "
            f"This package has been identified as malicious ({vuln_id}). "
            f"Audit your environment for signs of compromise."
        ),
        references=references[:5],
        cve_ids=[a for a in aliases if a.startswith("CVE-")],
    )


async def check_malicious_packages(
    dependency_trees: list[DependencyTree],
) -> list[Finding]:
    """Check all dependencies against threat intelligence feeds.

    Queries OSV.dev for each dependency and filters for malicious
    package advisories (MAL- prefixed IDs from OpenSSF, plus any
    advisory with "malicious" indicators).

    Uses concurrent API calls with a semaphore for rate limiting.
    """
    findings: list[Finding] = []
    semaphore = asyncio.Semaphore(_MAX_CONCURRENCY)

    async with httpx.AsyncClient(follow_redirects=False) as client:
        for tree in dependency_trees:
            osv_eco = _ECOSYSTEM_TO_OSV.get(tree.ecosystem)
            if not osv_eco:
                logger.info(
                    "No OSV mapping for ecosystem %s, skipping threat intel",
                    tree.ecosystem,
                )
                continue

            all_deps = tree.direct_dependencies + tree.transitive_dependencies
            # Cap at 200 deps to avoid excessive API calls
            deps_to_scan = [
                dep
                for dep in all_deps[:200]
                if dep.version and dep.version not in ("*", "latest", "")
            ]

            # Concurrent queries with semaphore rate limiting
            tasks = [
                query_osv_malicious(dep.name, dep.version, osv_eco, client, semaphore)
                for dep in deps_to_scan
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for dep, result in zip(deps_to_scan, results, strict=True):
                if isinstance(result, BaseException):
                    logger.warning("Threat intel query failed for %s: %s", dep.name, result)
                    continue
                malicious_vulns: list[dict[str, Any]] = result
                for vuln in malicious_vulns:
                    findings.append(_malicious_to_finding(vuln, dep, tree.ecosystem))

    logger.info(
        "Threat intel scan complete: %d known-malicious packages found",
        len(findings),
    )
    return findings
