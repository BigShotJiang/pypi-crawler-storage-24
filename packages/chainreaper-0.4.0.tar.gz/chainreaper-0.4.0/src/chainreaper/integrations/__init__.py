"""External service integrations (OSV, NVD, OpenSSF, etc.)."""
