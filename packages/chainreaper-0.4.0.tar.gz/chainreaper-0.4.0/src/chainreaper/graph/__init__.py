"""Attack graph engine."""
