"""Allow running as `python -m chainreaper`."""

from chainreaper.cli.app import main

main()
