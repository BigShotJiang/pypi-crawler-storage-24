"""Base class for output formatters."""

from __future__ import annotations

from abc import ABC, abstractmethod

from chainreaper.core.models import ScanResult


class BaseFormatter(ABC):
    """Base class for output formatters."""

    format_name: str = ""

    @abstractmethod
    def format(self, result: ScanResult) -> str:
        """Format a scan result to a string representation."""
        ...
