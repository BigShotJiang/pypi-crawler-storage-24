"""CycloneDX 1.5 SBOM output formatter."""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime
from typing import Any

from chainreaper.core.constants import EcosystemName, Severity
from chainreaper.core.models import DependencyNode, DependencyTree, Finding, ScanResult
from chainreaper.output.base import BaseFormatter

_ECOSYSTEM_TO_PURL: dict[EcosystemName, str] = {
    EcosystemName.NPM: "npm",
    EcosystemName.PYPI: "pypi",
    EcosystemName.MAVEN: "maven",
    EcosystemName.GO: "golang",
    EcosystemName.CARGO: "cargo",
    EcosystemName.RUBYGEMS: "gem",
    EcosystemName.NUGET: "nuget",
}

_SEVERITY_TO_CDX: dict[Severity, str] = {
    Severity.CRITICAL: "critical",
    Severity.HIGH: "high",
    Severity.MEDIUM: "medium",
    Severity.LOW: "low",
    Severity.INFO: "info",
}


def _make_purl(name: str, version: str, ecosystem: EcosystemName) -> str:
    """Build a Package URL (purl) from dependency info."""
    purl_type = _ECOSYSTEM_TO_PURL.get(ecosystem, ecosystem.value)
    return f"pkg:{purl_type}/{name}@{version}"


def _make_bom_ref(name: str, version: str, ecosystem: EcosystemName) -> str:
    """Generate a deterministic bom-ref for a component."""
    key = f"{ecosystem.value}:{name}:{version}"
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"urn:chainreaper:component:{key}"))


def _build_component(node: DependencyNode, is_direct: bool) -> dict[str, Any]:
    """Build a CycloneDX component from a DependencyNode."""
    purl = _make_purl(node.name, node.version, node.ecosystem)
    bom_ref = _make_bom_ref(node.name, node.version, node.ecosystem)

    component: dict[str, Any] = {
        "type": "library",
        "bom-ref": bom_ref,
        "name": node.name,
        "version": node.version,
        "purl": purl,
        "scope": "required" if is_direct else "optional",
    }

    if node.integrity_hash:
        # Detect hash algorithm from prefix (e.g. "sha256-..." or "sha512-...")
        # or fall back to SHA-256
        hash_value = node.integrity_hash
        alg = "SHA-256"
        for prefix in ("sha512-", "sha384-", "sha256-", "sha1-", "md5-"):
            if hash_value.lower().startswith(prefix):
                alg = prefix.rstrip("-").upper().replace("SHA", "SHA-")
                hash_value = hash_value[len(prefix) :]
                break
        component["hashes"] = [{"alg": alg, "content": hash_value}]

    return component


def _collect_components(trees: list[DependencyTree]) -> list[dict[str, Any]]:
    """Collect all unique components from dependency trees."""
    seen: set[str] = set()
    components: list[dict[str, Any]] = []

    def _add_nodes(nodes: list[DependencyNode], is_direct: bool) -> None:
        for node in nodes:
            key = f"{node.ecosystem.value}:{node.name}:{node.version}"
            if key not in seen:
                seen.add(key)
                components.append(_build_component(node, is_direct))
            # Recurse into children (always transitive)
            _add_nodes(node.children, is_direct=False)

    for tree in trees:
        _add_nodes(tree.direct_dependencies, is_direct=True)
        _add_nodes(tree.transitive_dependencies, is_direct=False)

    return components


def _build_vulnerability(
    finding: Finding,
    component_refs: dict[str, str],
) -> dict[str, Any] | None:
    """Build a CycloneDX vulnerability from a Finding with CVE IDs."""
    if not finding.cve_ids:
        return None

    cve_id = finding.cve_ids[0]
    vuln: dict[str, Any] = {
        "id": cve_id,
        "source": {
            "name": "OSV",
            "url": "https://osv.dev",
        },
        "ratings": [],
        "description": finding.description,
    }

    # Ratings
    severity_label = _SEVERITY_TO_CDX.get(finding.severity, "unknown")
    rating: dict[str, Any] = {"severity": severity_label}
    if finding.cvss_score is not None:
        rating["score"] = finding.cvss_score
        rating["method"] = "CVSSv31"
    vuln["ratings"].append(rating)

    # Affects
    ref_key = f"{finding.ecosystem.value}:{finding.package_name}:{finding.package_version or ''}"
    bom_ref = component_refs.get(ref_key)
    if bom_ref:
        affects_entry: dict[str, Any] = {"ref": bom_ref}
        if finding.package_version:
            affects_entry["versions"] = [{"version": finding.package_version, "status": "affected"}]
        vuln["affects"] = [affects_entry]

    # CWEs
    if finding.cwe_ids:
        vuln["cwes"] = [
            int(cwe.replace("CWE-", "")) for cwe in finding.cwe_ids if cwe.startswith("CWE-")
        ]

    # Recommendation
    if finding.remediation:
        vuln["recommendation"] = finding.remediation

    # Additional CVE IDs as references
    if len(finding.cve_ids) > 1:
        vuln["references"] = [
            {"id": cid, "source": {"name": "OSV", "url": "https://osv.dev"}}
            for cid in finding.cve_ids[1:]
        ]

    return vuln


class CycloneDxFormatter(BaseFormatter):
    """Format scan results as CycloneDX 1.5 JSON SBOM."""

    format_name = "cyclonedx"

    def format(self, result: ScanResult) -> str:
        """Serialize scan result to CycloneDX 1.5 JSON."""
        components = _collect_components(result.dependency_trees)

        # Build ref lookup: "ecosystem:name:version" -> bom-ref
        component_refs: dict[str, str] = {}
        for tree in result.dependency_trees:
            for node in tree.direct_dependencies + tree.transitive_dependencies:
                key = f"{node.ecosystem.value}:{node.name}:{node.version}"
                component_refs[key] = _make_bom_ref(node.name, node.version, node.ecosystem)
                for child in node.children:
                    child_key = f"{child.ecosystem.value}:{child.name}:{child.version}"
                    component_refs[child_key] = _make_bom_ref(
                        child.name, child.version, child.ecosystem
                    )

        # Build vulnerabilities
        vulnerabilities: list[dict[str, Any]] = []
        for finding in result.findings:
            vuln = _build_vulnerability(finding, component_refs)
            if vuln is not None:
                vulnerabilities.append(vuln)

        bom: dict[str, Any] = {
            "bomFormat": "CycloneDX",
            "specVersion": "1.5",
            "version": 1,
            "serialNumber": f"urn:uuid:{uuid.uuid4()}",
            "metadata": {
                "timestamp": datetime.now(UTC).isoformat(),
                "tools": [
                    {
                        "name": "ChainReaper",
                        "version": result.metadata.chainreaper_version or "0.3.0",
                        "vendor": "ChainReaper",
                    }
                ],
            },
            "components": components,
            "vulnerabilities": vulnerabilities,
        }

        return json.dumps(bom, indent=2)
