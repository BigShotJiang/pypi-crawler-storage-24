"""SARIF 2.1.0 output formatter for GitHub Security tab integration."""

from __future__ import annotations

import hashlib
import json
import uuid
from typing import Any

from chainreaper.core.constants import Severity
from chainreaper.core.models import Finding, ScanResult
from chainreaper.output.base import BaseFormatter

SARIF_SCHEMA = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json"
SARIF_VERSION = "2.1.0"

_SEVERITY_TO_LEVEL: dict[Severity, str] = {
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "note",
    Severity.INFO: "none",
}

_SEVERITY_TO_SCORE: dict[Severity, float] = {
    Severity.CRITICAL: 9.5,
    Severity.HIGH: 8.0,
    Severity.MEDIUM: 5.5,
    Severity.LOW: 3.0,
    Severity.INFO: 1.0,
}

_ECOSYSTEM_MANIFESTS: dict[str, str] = {
    "npm": "package.json",
    "pypi": "requirements.txt",
    "maven": "pom.xml",
    "go": "go.mod",
    "cargo": "Cargo.toml",
    "rubygems": "Gemfile",
    "nuget": "packages.config",
}


def _build_rule(finding: Finding) -> dict[str, Any]:
    """Build a SARIF rule (reporting descriptor) from a Finding."""
    score = (
        finding.cvss_score
        if finding.cvss_score is not None
        else _SEVERITY_TO_SCORE.get(finding.severity, 5.5)
    )
    rule: dict[str, Any] = {
        "id": finding.attack_vector.value,
        "name": finding.attack_vector.value.replace("_", " ").title().replace(" ", ""),
        "shortDescription": {"text": finding.title},
        "fullDescription": {"text": finding.description[:1000]},
        "help": {
            "text": finding.remediation or "No remediation guidance available.",
            "markdown": finding.remediation or "No remediation guidance available.",
        },
        "properties": {
            "security-severity": str(score),
            "tags": ["security", "supply-chain", finding.attack_vector.value],
        },
    }
    if finding.references:
        rule["helpUri"] = finding.references[0]
    if finding.cwe_ids:
        rule["relationships"] = [
            {
                "target": {
                    "id": cwe,
                    "guid": str(uuid.uuid5(uuid.NAMESPACE_URL, f"https://cwe.mitre.org/{cwe}")),
                    "toolComponent": {"name": "CWE"},
                },
                "kinds": ["superset"],
            }
            for cwe in finding.cwe_ids
        ]
    return rule


def _deterministic_fingerprint(finding: Finding) -> str:
    """Generate a stable fingerprint from finding attributes for deduplication."""
    key = f"{finding.ecosystem.value}:{finding.package_name}:{finding.package_version or ''}:{finding.attack_vector.value}"
    # Include first CVE ID if present for uniqueness within same package+vector
    if finding.cve_ids:
        key += f":{finding.cve_ids[0]}"
    return hashlib.sha256(key.encode()).hexdigest()[:40]


def _build_result(finding: Finding, rule_index: int) -> dict[str, Any]:
    """Build a SARIF result from a Finding."""
    fqn = f"{finding.ecosystem.value}/{finding.package_name}"
    if finding.package_version:
        fqn += f"@{finding.package_version}"

    result: dict[str, Any] = {
        "ruleId": finding.attack_vector.value,
        "ruleIndex": rule_index,
        "level": _SEVERITY_TO_LEVEL.get(finding.severity, "warning"),
        "message": {"text": finding.description},
        "locations": [
            {
                "physicalLocation": {
                    "artifactLocation": {
                        "uri": _ECOSYSTEM_MANIFESTS.get(finding.ecosystem.value, "package.json"),
                        "uriBaseId": "%SRCROOT%",
                    },
                },
                "logicalLocations": [
                    {"name": finding.package_name, "kind": "package", "fullyQualifiedName": fqn}
                ],
            }
        ],
        "fingerprints": {
            "chainreaper/finding/v1": _deterministic_fingerprint(finding),
        },
        "properties": {
            "confidence": finding.confidence,
            "ecosystem": finding.ecosystem.value,
            "attackVector": finding.attack_vector.value,
        },
    }
    if finding.cve_ids:
        result["properties"]["cveIds"] = finding.cve_ids
    if finding.cvss_score is not None:
        result["properties"]["cvssScore"] = finding.cvss_score
    return result


class SarifFormatter(BaseFormatter):
    """Format scan results as SARIF 2.1.0 for GitHub Security tab."""

    format_name = "sarif"

    def format(self, result: ScanResult) -> str:
        """Serialize scan result to SARIF 2.1.0 JSON."""
        rules: list[dict[str, Any]] = []
        rule_indices: dict[str, int] = {}

        for finding in result.findings:
            vec = finding.attack_vector.value
            if vec not in rule_indices:
                rule_indices[vec] = len(rules)
                rules.append(_build_rule(finding))

        results = [_build_result(f, rule_indices[f.attack_vector.value]) for f in result.findings]

        sarif: dict[str, Any] = {
            "$schema": SARIF_SCHEMA,
            "version": SARIF_VERSION,
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "ChainReaper",
                            "semanticVersion": result.metadata.chainreaper_version or "0.3.0",
                            "informationUri": "https://github.com/breachline/chainreaper",
                            "rules": rules,
                        }
                    },
                    "results": results,
                    "invocations": [
                        {
                            "executionSuccessful": True,
                            "properties": {
                                "llmModel": result.metadata.llm_model,
                                "llmCostUsd": result.metadata.llm_cost_usd,
                                "ecosystemsScanned": [
                                    e.value for e in result.summary.ecosystems_scanned
                                ],
                                "totalDependencies": result.summary.total_dependencies,
                            },
                        }
                    ],
                }
            ],
        }
        return json.dumps(sarif, indent=2)
