"""HTML output formatter with interactive D3.js attack graph."""

from __future__ import annotations

import json
from datetime import datetime
from importlib import resources

from chainreaper.core.models import ScanResult
from chainreaper.output.base import BaseFormatter


class HtmlFormatter(BaseFormatter):
    """Generate an interactive HTML report with D3.js attack graph.

    Features:
    - Force-directed graph layout with zoom, pan, drag
    - Click nodes to see finding details in sidebar with tabs (Details + Remediation)
    - Attack path highlighting (click a path to isolate it)
    - Findings list panel with click-to-highlight
    - Severity-colored nodes with shape-based type indicators
    - Ecosystem-colored nodes (npm=red, PyPI=blue, Maven=orange, etc.)
    - Scan summary bar with ecosystem badges
    - Package search box to find nodes in the graph
    - Export as PNG button
    - Dark theme with gradient backgrounds and smooth animations
    """

    format_name = "html"

    def format(self, result: ScanResult) -> str:
        """Generate standalone HTML with embedded graph data."""
        template = self._load_template()

        # Prepare graph data for D3.js
        graph_data = {
            "nodes": [n.model_dump(mode="json") for n in result.attack_graph.nodes],
            "edges": [
                {
                    "source": e.source,
                    "target": e.target,
                    "label": e.label,
                    "edge_type": e.edge_type,
                }
                for e in result.attack_graph.edges
            ],
        }

        paths_data = [
            {
                "name": p.name,
                "description": p.description,
                "severity": p.severity.value if hasattr(p.severity, "value") else p.severity,
                "likelihood": p.likelihood,
                "node_ids": p.node_ids,
            }
            for p in result.attack_graph.paths
        ]

        findings_data = [
            {
                "title": f.title,
                "description": f.description,
                "severity": f.severity.value,
                "confidence": f.confidence,
                "package_name": f.package_name,
                "package_version": f.package_version,
                "remediation": f.remediation,
                "cwe_ids": f.cwe_ids,
                "attack_vector": f.attack_vector.value,
                "ecosystem": f.ecosystem.value if hasattr(f.ecosystem, "value") else f.ecosystem,
                "package_url": f.package_url,
                "package_registry_url": f.package_registry_url,
                "package_description": f.package_description,
                "package_license": f.package_license,
                "package_maintainers": f.package_maintainers,
                "package_repository_url": f.package_repository_url,
                "exploitability_score": f.evidence.raw_data.get("verification", {}).get(
                    "exploitability_score"
                ),
            }
            for f in result.findings
        ]

        # Scan metadata for the summary bar
        scan_meta = {
            "llm_model": result.metadata.llm_model,
            "llm_cost_usd": result.metadata.llm_cost_usd,
            "llm_input_tokens": result.metadata.llm_input_tokens,
            "llm_output_tokens": result.metadata.llm_output_tokens,
            "total_dependencies": result.summary.total_dependencies,
            "analyzer_runs": [
                {"name": r.name, "status": r.status, "findings_count": r.findings_count}
                for r in result.metadata.analyzer_runs
            ],
            "pre_verification_count": result.metadata.pre_verification_count,
            "post_verification_count": result.metadata.post_verification_count,
        }

        # Compute ecosystem dep counts
        eco_dep_counts: dict[str, int] = {}
        for tree in result.dependency_trees:
            eco_dep_counts[tree.ecosystem.value] = tree.total_count
        scan_meta["ecosystem_dep_counts"] = eco_dep_counts

        # Template substitution
        html = template
        html = html.replace("{{scan_target}}", result.target.value)
        html = html.replace("{{timestamp}}", datetime.now().strftime("%Y-%m-%d %H:%M"))
        html = html.replace("{{critical}}", str(result.summary.critical))
        html = html.replace("{{high}}", str(result.summary.high))
        html = html.replace("{{medium}}", str(result.summary.medium))
        html = html.replace("{{low}}", str(result.summary.low))
        html = html.replace("{{cost}}", f"{result.metadata.llm_cost_usd:.4f}")
        html = html.replace("{{path_count}}", str(len(paths_data)))
        html = html.replace("{{total_findings}}", str(len(findings_data)))
        html = html.replace("{{total_deps}}", str(result.summary.total_dependencies))
        html = html.replace("{{llm_model}}", result.metadata.llm_model or "N/A")
        html = html.replace("{{graph_json}}", json.dumps(graph_data))
        html = html.replace("{{paths_json}}", json.dumps(paths_data))
        html = html.replace("{{findings_json}}", json.dumps(findings_data))
        html = html.replace("{{scan_meta_json}}", json.dumps(scan_meta))

        return html

    def _load_template(self) -> str:
        """Load the HTML template from package resources."""
        template_path = resources.files("chainreaper.graph") / "templates" / "attack_graph.html"
        return template_path.read_text(encoding="utf-8")
