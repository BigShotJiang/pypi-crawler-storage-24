"""JSON output formatter."""

from __future__ import annotations

from chainreaper.core.models import ScanResult
from chainreaper.output.base import BaseFormatter


class JsonFormatter(BaseFormatter):
    """Format scan results as JSON."""

    format_name = "json"

    def format(self, result: ScanResult) -> str:
        """Serialize scan result to pretty JSON."""
        return result.model_dump_json(indent=2)
