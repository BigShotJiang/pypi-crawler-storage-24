"""CLI layer using Typer + Rich."""
