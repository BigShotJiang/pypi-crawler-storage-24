"""Rich console output rendering for scan results."""

from __future__ import annotations

from collections import defaultdict

from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.tree import Tree

from chainreaper.cli.themes import BANNER, CHAINREAPER_THEME, SEVERITY_SYMBOLS
from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import Finding, ScanResult

console = Console(theme=CHAINREAPER_THEME)

# ── Human-readable attack vector names ───────────────────────

ATTACK_VECTOR_NAMES: dict[str, str] = {
    AttackVector.DEPENDENCY_CONFUSION.value: "Dependency Confusion",
    AttackVector.TYPOSQUATTING.value: "Typosquatting",
    AttackVector.COMPROMISED_MAINTAINER.value: "Compromised Maintainer",
    AttackVector.BUILD_SYSTEM.value: "Build System",
    AttackVector.MALICIOUS_PACKAGE.value: "Malicious Package",
    AttackVector.INSTALL_SCRIPT.value: "Install Script",
    AttackVector.SHADOW_DEPENDENCY.value: "Shadow Dependency",
    AttackVector.LOCKFILE_MANIPULATION.value: "Lockfile Manipulation",
    AttackVector.REGISTRY_SPOOFING.value: "Registry Spoofing",
    AttackVector.ABANDONED_TAKEOVER.value: "Abandoned Takeover",
    AttackVector.SOURCE_BINARY_MISMATCH.value: "Source-Binary Mismatch",
    AttackVector.PROTESTWARE.value: "Protestware",
}

# ── Ecosystem badge styling ──────────────────────────────────

ECOSYSTEM_BADGES: dict[str, str] = {
    EcosystemName.NPM.value: "[bold white on red] npm [/]",
    EcosystemName.PYPI.value: "[bold white on blue] PyPI [/]",
    EcosystemName.MAVEN.value: "[bold white on #d2691e] Maven [/]",
    EcosystemName.GO.value: "[bold white on cyan] Go [/]",
    EcosystemName.CARGO.value: "[bold white on #d4a017] Cargo [/]",
    EcosystemName.RUBYGEMS.value: "[bold white on #cc3366] Ruby [/]",
    EcosystemName.NUGET.value: "[bold white on #5c2d91] NuGet [/]",
    EcosystemName.DOCKER.value: "[bold white on #0db7ed] Docker [/]",
}

# ── Analyzer status symbols ──────────────────────────────────

ANALYZER_STATUS_SYMBOLS: dict[str, str] = {
    "done": "[bold green]PASS[/]",
    "failed": "[bold red]FAIL[/]",
    "running": "[bold yellow]RUN[/]",
    "pending": "[dim]WAIT[/]",
}


def print_banner(version: str) -> None:
    """Print the ChainReaper banner."""
    console.print(BANNER.format(version=version), style="cr.banner")


def print_scan_result(result: ScanResult) -> None:
    """Print a complete scan result to the terminal."""
    _print_summary(result)
    _print_scan_progress(result)

    if result.findings:
        _print_findings(result)
        _print_top_risks(result)

    if result.attack_graph.paths:
        _print_attack_paths(result)

    if result.findings:
        _print_remediation_summary(result)

    _print_cost_breakdown(result)


# ── Summary Panel ────────────────────────────────────────────


def _print_summary(result: ScanResult) -> None:
    """Print the results summary panel."""
    s = result.summary
    severity_line = (
        f"  {SEVERITY_SYMBOLS['critical']} CRITICAL {s.critical}    "
        f"{SEVERITY_SYMBOLS['high']} HIGH {s.high}    "
        f"{SEVERITY_SYMBOLS['medium']} MEDIUM {s.medium}    "
        f"{SEVERITY_SYMBOLS['low']} LOW {s.low}    "
        f"{SEVERITY_SYMBOLS['info']} INFO {s.info}"
    )

    # Ecosystem badges with dep counts
    eco_parts: list[str] = []
    for tree in result.dependency_trees:
        badge = ECOSYSTEM_BADGES.get(tree.ecosystem.value, tree.ecosystem.value)
        eco_parts.append(f"{badge} {tree.total_count} deps")
    ecosystems_line = "  ".join(eco_parts) if eco_parts else "  none"

    # Verification info
    m = result.metadata
    verification_line = ""
    if m.pre_verification_count > 0:
        filtered = m.pre_verification_count - m.post_verification_count
        verification_line = (
            f"\n  LLM Verification: [bold]{m.post_verification_count}[/]/"
            f"{m.pre_verification_count} verified"
        )
        if filtered > 0:
            verification_line += f" ([bold red]{filtered} false positives filtered[/])"

    lines = [
        severity_line,
        "",
        f"  Ecosystems: {ecosystems_line}",
        f"  Dependencies: [bold]{s.total_dependencies}[/]",
        f"  Attack Paths: [bold]{s.attack_paths_found}[/]",
    ]
    if verification_line:
        lines.append(verification_line)

    console.print(Panel("\n".join(lines), title="RESULTS SUMMARY", border_style="cr.info"))


# ── Scan Progress ────────────────────────────────────────────


def _print_scan_progress(result: ScanResult) -> None:
    """Print which analyzers ran and their status."""
    runs = result.metadata.analyzer_runs
    if not runs:
        return

    table = Table(title="Scan Progress", show_lines=False, pad_edge=True, expand=False)
    table.add_column("Analyzer", style="bold")
    table.add_column("Status", width=8)
    table.add_column("Findings", width=10, justify="right")
    table.add_column("Details", style="dim")

    for run in runs:
        status = ANALYZER_STATUS_SYMBOLS.get(run.status, run.status)
        name = ATTACK_VECTOR_NAMES.get(run.name, run.name)
        findings_str = str(run.findings_count) if run.status == "done" else "-"
        detail = run.error[:60] if run.error else ""
        table.add_row(name, status, findings_str, detail)

    console.print(table)


# ── Findings Table ───────────────────────────────────────────


def _print_findings(result: ScanResult) -> None:
    """Print findings table with ecosystem badges and attack vector names."""
    table = Table(title="Findings", show_lines=True, expand=True)
    table.add_column("Severity", width=12)
    table.add_column("Ecosystem", width=10)
    table.add_column("Package", style="cr.package", min_width=16)
    table.add_column("Attack Vector", min_width=18)
    table.add_column("Title", ratio=2)
    table.add_column("Confidence", width=10, justify="right")

    severity_order = {
        Severity.CRITICAL: 0,
        Severity.HIGH: 1,
        Severity.MEDIUM: 2,
        Severity.LOW: 3,
        Severity.INFO: 4,
    }
    sorted_findings = sorted(result.findings, key=lambda f: severity_order.get(f.severity, 5))

    for f in sorted_findings:
        sym = SEVERITY_SYMBOLS.get(f.severity.value, "")
        eco_badge = ECOSYSTEM_BADGES.get(f.ecosystem.value, f.ecosystem.value)
        vector_name = ATTACK_VECTOR_NAMES.get(f.attack_vector.value, f.attack_vector.value)

        # Bold package name with optional version
        pkg_display = f"[bold]{f.package_name}[/]"
        if f.package_version:
            pkg_display += f" [dim]v{f.package_version}[/]"

        # Exploitability info if available
        verification = f.evidence.raw_data.get("verification", {})
        exploit_score = verification.get("exploitability_score")
        confidence_text = f"{f.confidence:.0%}"
        if exploit_score is not None:
            confidence_text += f" [{exploit_score}/10]"

        table.add_row(
            f"{sym} {f.severity.value.upper()}",
            eco_badge,
            pkg_display,
            vector_name,
            f.title,
            confidence_text,
        )

    console.print(table)


# ── Top Risks ────────────────────────────────────────────────


def _print_top_risks(result: ScanResult) -> None:
    """Print the top 3 most exploitable findings."""
    if not result.findings:
        return

    # Score findings: severity * confidence * exploitability
    severity_weights = {
        Severity.CRITICAL: 5,
        Severity.HIGH: 4,
        Severity.MEDIUM: 3,
        Severity.LOW: 2,
        Severity.INFO: 1,
    }

    def _risk_score(f: Finding) -> float:
        sev_w = severity_weights.get(f.severity, 1)
        verification = f.evidence.raw_data.get("verification", {})
        exploit = verification.get("exploitability_score", 5)
        return sev_w * f.confidence * (exploit / 10.0)

    ranked = sorted(result.findings, key=_risk_score, reverse=True)[:3]

    if not ranked:
        return

    panels: list[Panel] = []
    for i, f in enumerate(ranked, 1):
        sym = SEVERITY_SYMBOLS.get(f.severity.value, "")
        eco_badge = ECOSYSTEM_BADGES.get(f.ecosystem.value, f.ecosystem.value)
        vector_name = ATTACK_VECTOR_NAMES.get(f.attack_vector.value, f.attack_vector.value)
        verification = f.evidence.raw_data.get("verification", {})
        exploit_score = verification.get("exploitability_score", "?")

        url_line = ""
        if f.package_url:
            url_line = f"\nURL: {f.package_url}"

        body = (
            f"{sym} [bold]{f.title}[/]\n"
            f"{eco_badge} [bold]{f.package_name}[/]"
            f"{f' v{f.package_version}' if f.package_version else ''}\n"
            f"Vector: {vector_name}\n"
            f"Exploitability: [bold]{exploit_score}[/]/10  |  "
            f"Confidence: {f.confidence:.0%}"
            f"{url_line}"
        )

        sev_style = f"cr.finding.{f.severity.value}"
        panels.append(Panel(body, title=f"#{i} Risk", border_style=sev_style, width=38))

    console.print(
        Panel(Columns(panels, equal=True, expand=True), title="TOP RISKS", border_style="bold red")
    )


# ── Attack Paths ─────────────────────────────────────────────


def _print_attack_paths(result: ScanResult) -> None:
    """Print attack paths as a tree."""
    tree = Tree("Attack Paths", style="cr.phase")
    for path in result.attack_graph.paths:
        sym = SEVERITY_SYMBOLS.get(path.severity.value, "")
        branch = tree.add(
            f"{sym} [{path.severity.value}] {path.name} (likelihood: {path.likelihood:.0%})"
        )
        branch.add(path.description)
        for node_id in path.node_ids:
            node = next((n for n in result.attack_graph.nodes if n.id == node_id), None)
            if node:
                branch.add(f"  -> {node.label}")

    console.print(tree)


# ── Remediation Summary ──────────────────────────────────────


def _print_remediation_summary(result: ScanResult) -> None:
    """Print grouped remediation recommendations."""
    if not result.findings:
        return

    # Group remediations by attack vector
    grouped: dict[str, list[tuple[Finding, str]]] = defaultdict(list)
    for f in result.findings:
        if f.remediation:
            vector_name = ATTACK_VECTOR_NAMES.get(f.attack_vector.value, f.attack_vector.value)
            grouped[vector_name].append((f, f.remediation))

    if not grouped:
        return

    tree = Tree("[bold]Remediation Summary[/]", style="cr.success")

    severity_order = {
        Severity.CRITICAL: 0,
        Severity.HIGH: 1,
        Severity.MEDIUM: 2,
        Severity.LOW: 3,
        Severity.INFO: 4,
    }

    for vector_name, items in grouped.items():
        # Sort by severity within group
        items.sort(key=lambda x: severity_order.get(x[0].severity, 5))
        branch = tree.add(f"[bold]{vector_name}[/] ({len(items)} findings)")
        for finding, remediation in items:
            sym = SEVERITY_SYMBOLS.get(finding.severity.value, "")
            eco_badge = ECOSYSTEM_BADGES.get(finding.ecosystem.value, finding.ecosystem.value)
            # Truncate long remediation text
            short_rem = remediation[:120] + "..." if len(remediation) > 120 else remediation
            branch.add(f"{sym} {eco_badge} [bold]{finding.package_name}[/]: {short_rem}")

    console.print(Panel(tree, title="REMEDIATION", border_style="cr.success"))


# ── Cost Breakdown ───────────────────────────────────────────


def _print_cost_breakdown(result: ScanResult) -> None:
    """Print LLM cost breakdown at the bottom."""
    m = result.metadata

    total_tokens = m.llm_input_tokens + m.llm_output_tokens
    cost_per_1k = (m.llm_cost_usd / (total_tokens / 1000)) if total_tokens > 0 else 0.0

    lines: list[str] = []

    # Model info
    model_text = Text()
    model_text.append("  Model: ", style="dim")
    model_text.append(m.llm_model or "unknown", style="cr.info")
    lines.append(f"  Model: [cr.info]{m.llm_model or 'unknown'}[/]")

    # Token usage
    lines.append(
        f"  Tokens: [bold]{m.llm_input_tokens:,}[/] input + "
        f"[bold]{m.llm_output_tokens:,}[/] output = "
        f"[bold]{total_tokens:,}[/] total"
    )

    # Cost
    lines.append(
        f"  Cost: [cr.cost][bold]${m.llm_cost_usd:.4f}[/][/] ([dim]${cost_per_1k:.6f}/1K tokens[/])"
    )

    # Analyzer stats
    total_analyzers = len(m.analyzer_runs)
    if total_analyzers > 0:
        passed = sum(1 for r in m.analyzer_runs if r.status == "done")
        failed = sum(1 for r in m.analyzer_runs if r.status == "failed")
        lines.append(
            f"  Analyzers: [bold]{total_analyzers}[/] ran"
            f" ([green]{passed} passed[/]"
            + (f", [red]{failed} failed[/]" if failed > 0 else "")
            + ")"
        )

    # Verification
    if m.pre_verification_count > 0:
        filtered = m.pre_verification_count - m.post_verification_count
        lines.append(
            f"  Verification: [bold]{m.post_verification_count}[/]/"
            f"{m.pre_verification_count} kept"
            + (f" ([red]{filtered} FPs removed[/])" if filtered > 0 else "")
        )

    # Scan ID
    lines.append(f"  Scan ID: [dim]{m.scan_id}[/]")

    console.print(Panel("\n".join(lines), title="LLM COST BREAKDOWN", border_style="cr.cost"))
