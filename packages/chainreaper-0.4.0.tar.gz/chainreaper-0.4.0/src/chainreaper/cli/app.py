"""Root Typer CLI application for ChainReaper."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from chainreaper.cli.commands.scan import scan_command
from chainreaper.cli.themes import CHAINREAPER_THEME

console = Console(theme=CHAINREAPER_THEME)

app = typer.Typer(
    name="chainreaper",
    help="ChainReaper — Autonomous AI Supply Chain Attack Simulator by Breachline Labs",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

# Register scan as a direct command
app.command(name="scan")(scan_command)


@app.command()
def version() -> None:
    """Show ChainReaper version and build info."""
    from chainreaper import __version__

    console.print(f"\n  [cr.banner]ChainReaper[/] v{__version__}")
    console.print("  by [cr.info]Breachline Labs[/] (https://breachline.io)")

    import chainreaper.analyzers.registry
    import chainreaper.ecosystems.registry  # noqa: F401
    from chainreaper.analyzers.base import AnalyzerRegistry
    from chainreaper.ecosystems.base import EcosystemRegistry

    console.print(f"  Analyzers: {len(AnalyzerRegistry.get_all())}")
    console.print(f"  Ecosystems: {len(EcosystemRegistry.get_all())}\n")


@app.command(name="list")
def list_components(
    analyzers: bool = typer.Option(False, "--analyzers", "-a", help="List available analyzers"),
    ecosystems: bool = typer.Option(False, "--ecosystems", "-e", help="List supported ecosystems"),
    formats: bool = typer.Option(False, "--formats", "-f", help="List output formats"),
    all_: bool = typer.Option(False, "--all", help="List everything"),
) -> None:
    """List available analyzers, ecosystems, and output formats."""
    import chainreaper.analyzers.registry
    import chainreaper.ecosystems.registry  # noqa: F401
    from chainreaper.analyzers.base import AnalyzerRegistry
    from chainreaper.core.constants import OutputFormat
    from chainreaper.ecosystems.base import EcosystemRegistry

    show_all = all_ or not (analyzers or ecosystems or formats)

    if analyzers or show_all:
        table = Table(title="Attack Vector Analyzers", show_lines=True)
        table.add_column("Name", style="bold")
        table.add_column("Attack Vector")
        table.add_column("Ecosystems")
        table.add_column("Description")
        for name, cls in sorted(AnalyzerRegistry.get_all().items()):
            ecos = ", ".join(e.value for e in cls.applicable_ecosystems)
            table.add_row(name, cls.attack_vector.value, ecos, cls.description[:80])
        console.print(table)
        console.print()

    if ecosystems or show_all:
        table = Table(title="Supported Ecosystems", show_lines=True)
        table.add_column("Name", style="bold")
        table.add_column("Manifest Files")
        table.add_column("Lockfiles")
        table.add_column("Registry")
        for name, cls in sorted(EcosystemRegistry.get_all().items()):
            manifests = ", ".join(cls.manifest_files[:3])
            locks = ", ".join(cls.lockfile_files[:2]) if cls.lockfile_files else "—"
            table.add_row(name, manifests, locks, cls.registry_url[:40])
        console.print(table)
        console.print()

    if formats or show_all:
        table = Table(title="Output Formats")
        table.add_column("Format", style="bold")
        table.add_column("Status")
        table.add_column("Description")
        format_info = {
            "json": ("Available", "Machine-readable JSON with findings + attack graph"),
            "html": ("Available", "Interactive D3.js attack graph (opens in browser)"),
            "sarif": ("Planned", "SARIF 2.1 for IDE/CI integration"),
            "cyclonedx": ("Planned", "CycloneDX SBOM standard"),
            "spdx": ("Planned", "SPDX SBOM standard"),
            "pdf": ("Planned", "Printable PDF report"),
            "console": ("Default", "Rich terminal output (always shown)"),
        }
        for fmt in OutputFormat:
            status, desc = format_info.get(fmt.value, ("Unknown", ""))
            style = "green" if status == "Available" else "dim" if status == "Planned" else ""
            table.add_row(fmt.value, f"[{style}]{status}[/]", desc)
        console.print(table)
        console.print()


@app.command()
def config(
    init: bool = typer.Option(False, "--init", help="Generate a default .chainreaper.yml"),
    show: bool = typer.Option(False, "--show", help="Show current configuration"),
    path: bool = typer.Option(False, "--path", help="Show config file path"),
    validate: bool = typer.Option(False, "--validate", help="Validate current configuration"),
    set_value: Optional[str] = typer.Option(
        None, "--set", help="Set a config value (e.g., 'llm.cost_limit_usd=10.0')"
    ),
) -> None:
    """Manage ChainReaper configuration."""
    from chainreaper.core.config import CONFIG_FILENAME, ChainReaperConfig, _find_config_file

    if init:
        cfg = ChainReaperConfig()
        cfg_path = Path.cwd() / CONFIG_FILENAME
        cfg_path.write_text(cfg.to_yaml())
        console.print(f"  Created: {cfg_path}", style="cr.success")
    elif show:
        cfg = ChainReaperConfig.load()
        console.print(cfg.to_yaml())
    elif path:
        found = _find_config_file()
        if found:
            console.print(f"  Config: {found}", style="cr.info")
        else:
            console.print(
                "  No .chainreaper.yml found. Run: chainreaper config --init", style="cr.warning"
            )
    elif validate:
        try:
            cfg = ChainReaperConfig.load()
            console.print("  Config is valid", style="cr.success")
            console.print(f"  LLM providers: {len(cfg.llm.provider_chain)}")
            console.print(f"  Cost limit: ${cfg.llm.cost_limit_usd:.2f}")
            console.print(f"  Max iterations: {cfg.scan.max_iterations}")
            console.print(f"  Attack vectors: {len(cfg.scan.attack_vectors)}")
            fmts = ", ".join(f.value for f in cfg.output.formats)
            console.print(f"  Output formats: {fmts}")
        except Exception as e:
            console.print(f"  Config error: {e}", style="cr.error")
            raise typer.Exit(code=1) from e
    elif set_value:
        found = _find_config_file()
        if not found:
            console.print(
                "  No config file found. Run: chainreaper config --init", style="cr.error"
            )
            raise typer.Exit(code=1)
        # Parse key=value
        if "=" not in set_value:
            console.print(
                "  Usage: --set 'key=value' (e.g., 'llm.cost_limit_usd=10.0')", style="cr.error"
            )
            raise typer.Exit(code=1)
        import yaml

        key, value = set_value.split("=", 1)
        with open(found) as f:
            data = yaml.safe_load(f) or {}
        # Navigate nested keys
        parts = key.split(".")
        target = data
        for part in parts[:-1]:
            target = target.setdefault(part, {})
        # Auto-convert types
        try:
            target[parts[-1]] = yaml.safe_load(value)
        except Exception:
            target[parts[-1]] = value
        with open(found, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)
        console.print(f"  Set {key} = {value}", style="cr.success")
    else:
        console.print(
            "  Use --init, --show, --path, --validate, or --set. Run: chainreaper config --help"
        )


def main() -> None:
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
