"""Breachline Labs branding and terminal color themes."""

from rich.theme import Theme

CHAINREAPER_THEME = Theme(
    {
        "cr.banner": "bold red",
        "cr.info": "cyan",
        "cr.success": "bold green",
        "cr.warning": "bold yellow",
        "cr.error": "bold red",
        "cr.phase": "bold magenta",
        "cr.finding.critical": "bold white on red",
        "cr.finding.high": "bold red",
        "cr.finding.medium": "bold yellow",
        "cr.finding.low": "bold cyan",
        "cr.finding.info": "dim",
        "cr.package": "bold white",
        "cr.version": "dim",
        "cr.cost": "green",
        "cr.progress": "blue",
    }
)

BANNER = r"""
 ╔══════════════════════════════════════════════════════════════╗
 ║  ⛓️  ChainReaper v{version} — Supply Chain Attack Simulator  ║
 ║     by Breachline Labs                                      ║
 ╚══════════════════════════════════════════════════════════════╝
"""

SEVERITY_SYMBOLS = {
    "critical": "🔴",
    "high": "🟠",
    "medium": "🟡",
    "low": "🟢",
    "info": "🔵",
}
