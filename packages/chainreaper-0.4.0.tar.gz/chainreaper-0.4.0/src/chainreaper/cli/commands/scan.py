"""The `chainreaper scan` command."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from chainreaper.cli.output import print_banner, print_scan_result
from chainreaper.cli.themes import CHAINREAPER_THEME
from chainreaper.core.config import ChainReaperConfig, LLMProviderConfig
from chainreaper.core.constants import OutputFormat, ScanPhase, Severity
from chainreaper.core.events import EventBus, ScanEvent
from chainreaper.core.models import ScanResult

console = Console(theme=CHAINREAPER_THEME)


def _create_event_handler() -> tuple[EventBus, list[str]]:
    """Create an event bus with a console-printing handler."""
    bus = EventBus()
    log: list[str] = []

    async def handler(event: ScanEvent) -> None:
        log.append(event.message)
        style = "cr.success" if event.phase == ScanPhase.COMPLETED else "cr.progress"
        if event.phase == ScanPhase.FAILED:
            style = "cr.error"
        console.print(f"  {event.message}", style=style)

    bus.subscribe(handler)
    return bus, log


def scan_command(
    target: str = typer.Argument(
        help="Target: local path, GitHub URL, package name, or registry URL"
    ),
    format: list[OutputFormat] = typer.Option(
        [OutputFormat.JSON],
        "--format",
        "-f",
        help="Output format(s): json, sarif, cyclonedx, html (repeatable)",
    ),
    output_dir: Path = typer.Option(
        Path("./chainreaper-results"),
        "--output",
        "-o",
        help="Output directory for reports",
    ),
    config_file: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        help="Config file path (.chainreaper.yml)",
    ),
    model: Optional[str] = typer.Option(
        None,
        "--model",
        "-m",
        help="LLM model override (e.g., 'gemini/gemini-2.5-flash', 'anthropic/claude-sonnet-4-20250514')",
    ),
    cost_limit: Optional[float] = typer.Option(
        None,
        "--cost-limit",
        help="Max LLM cost in USD per scan (default: $5.00)",
    ),
    ecosystem: Optional[list[str]] = typer.Option(
        None,
        "--ecosystem",
        "-e",
        help="Filter to specific ecosystems (e.g., --ecosystem npm --ecosystem pypi)",
    ),
    no_verify: bool = typer.Option(
        False,
        "--no-verify",
        help="Skip LLM findings verification step",
    ),
    ci: bool = typer.Option(False, "--ci", help="CI mode (exit non-zero on findings)"),
    fail_on: Severity = typer.Option(
        Severity.HIGH,
        "--fail-on",
        help="Minimum severity to fail in CI mode",
    ),
    max_iterations: Optional[int] = typer.Option(
        None,
        "--max-iterations",
        help="Maximum LLM reasoning iterations (default: 20)",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed LLM reasoning and debug info",
    ),
    baseline: Optional[Path] = typer.Option(
        None,
        "--baseline",
        "-b",
        help="Baseline scan result JSON for incremental comparison",
    ),
    diff_only: bool = typer.Option(
        False,
        "--diff-only",
        help="Only scan changed dependencies (requires --baseline or git)",
    ),
    policy_file: Optional[Path] = typer.Option(
        None,
        "--policy",
        help="Path to a standalone policy YAML file",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Minimal output (findings only, for CI pipelines)",
    ),
) -> None:
    """Scan a target for supply chain attack vulnerabilities.

    Analyzes npm, PyPI, Maven, Go, Cargo, RubyGems, and NuGet projects
    using 12 LLM-driven autonomous attack vector analyzers.

    Supports local paths, GitHub URLs, package names, and registry URLs.

    Examples:
        chainreaper scan ./my-project
        chainreaper scan https://github.com/org/repo
        chainreaper scan express
        chainreaper scan flask
        chainreaper scan https://www.npmjs.com/package/lodash
        chainreaper scan https://pypi.org/project/requests
        chainreaper scan ./project --format html --format json
        chainreaper scan . --ci --fail-on high
    """
    from chainreaper import __version__

    if not quiet:
        print_banner(__version__)

    # Load config
    config = ChainReaperConfig.load(config_file)
    config.output.formats = list(format)
    config.output.directory = str(output_dir)

    # Apply CLI overrides
    if model:
        config.llm.provider_chain = [
            LLMProviderConfig(model=model, temperature=0.1, max_tokens=8192)
        ]
        if not quiet:
            console.print(f"  Using model: {model}", style="cr.info")

    if cost_limit is not None:
        config.llm.cost_limit_usd = cost_limit

    if max_iterations:
        config.scan.max_iterations = max_iterations

    if policy_file:
        from chainreaper.core.policy import PolicyConfig as PolicyCfg

        config.policy = PolicyCfg.from_yaml(policy_file)
        if not quiet:
            console.print(f"  Loaded policy: {policy_file}", style="cr.info")

    if ecosystem:
        config.scan.ecosystems = list(ecosystem)
        if not quiet:
            console.print(f"  Filtering ecosystems: {', '.join(ecosystem)}", style="cr.info")

    # Set up logging for verbose mode
    if verbose:
        import logging

        logging.basicConfig(
            level=logging.DEBUG,
            format="%(name)s [%(levelname)s]: %(message)s",
        )
        # Suppress noisy libs
        for lib in ("httpx", "httpcore", "litellm", "LiteLLM"):
            logging.getLogger(lib).setLevel(logging.WARNING)

    # Ensure registries are loaded
    import chainreaper.analyzers.registry
    import chainreaper.ecosystems.registry  # noqa: F401

    # Run scan
    event_bus, _ = _create_event_handler()

    from chainreaper.agents.orchestrator import ScanOrchestrator

    orchestrator = ScanOrchestrator(config, event_bus=event_bus)

    # Load baseline trees for incremental scanning
    baseline_trees = None
    if baseline:
        from chainreaper.core.diff import load_baseline

        try:
            baseline_trees = load_baseline(baseline)
            if not quiet:
                console.print(
                    f"  Loaded baseline: {sum(t.total_count for t in baseline_trees)} deps",
                    style="cr.info",
                )
        except Exception as e:
            console.print(f"  Failed to load baseline: {e}", style="cr.error")
            if diff_only:
                raise typer.Exit(code=2) from e

    # Pass no_verify flag and baseline
    try:
        result = asyncio.run(
            orchestrator.scan(
                target,
                skip_verification=no_verify,
                baseline_trees=baseline_trees,
                diff_only=diff_only,
            )
        )
    except Exception as e:
        console.print(f"\n  Scan failed: {type(e).__name__}: {e}", style="cr.error")
        raise typer.Exit(code=2) from e

    # Print results
    if not quiet:
        print_scan_result(result)
    else:
        # Quiet mode: just findings summary
        for f in result.findings:
            console.print(
                f"[{f.severity.value.upper()}] {f.package_name}: {f.title} "
                f"({f.attack_vector.value}, {f.confidence:.0%})"
            )

    # Write output files
    output_dir.mkdir(parents=True, exist_ok=True)
    _write_outputs(result, output_dir, config.output.formats, quiet=quiet)

    # Apply policy engine
    from chainreaper.core.policy import PolicyEngine

    config.policy.fail_on = fail_on
    policy_engine = PolicyEngine(config.policy)
    policy_result = policy_engine.evaluate(result.findings)

    # CI mode exit code
    if ci and policy_result.should_fail:
        blocked = policy_result.blocked
        if blocked:
            console.print(
                f"\n  CI FAILED: {len(blocked)} finding(s) blocked by policy",
                style="cr.error",
            )
            for finding in blocked:
                console.print(
                    f"    - [{finding.severity.value.upper()}] "
                    f"{finding.package_name}: {finding.title}",
                    style="cr.error",
                )
        raise typer.Exit(code=1)


def _write_outputs(
    result: ScanResult,
    output_dir: Path,
    formats: list[OutputFormat],
    quiet: bool = False,
) -> None:
    """Write scan results to files in requested formats."""
    from chainreaper.output.json_output import JsonFormatter

    for fmt in formats:
        if fmt == OutputFormat.JSON:
            formatter = JsonFormatter()
            path = output_dir / "chainreaper-results.json"
            path.write_text(formatter.format(result))
            if not quiet:
                console.print(f"  JSON report → {path}", style="cr.success")
        elif fmt == OutputFormat.HTML:
            import webbrowser

            from chainreaper.output.html import HtmlFormatter

            html_formatter = HtmlFormatter()
            path = output_dir / "chainreaper-attack-graph.html"
            path.write_text(html_formatter.format(result))
            if not quiet:
                console.print(f"  HTML attack graph → {path}", style="cr.success")
            try:
                webbrowser.open(f"file://{path.resolve()}")
                if not quiet:
                    console.print("  Opened attack graph in browser", style="cr.info")
            except Exception:
                pass
        elif fmt == OutputFormat.SARIF:
            from chainreaper.output.sarif import SarifFormatter

            sarif_formatter = SarifFormatter()
            path = output_dir / "chainreaper-results.sarif"
            path.write_text(sarif_formatter.format(result))
            if not quiet:
                console.print(f"  SARIF report → {path}", style="cr.success")
        elif fmt == OutputFormat.CYCLONEDX:
            from chainreaper.output.cyclonedx import CycloneDxFormatter

            cdx_formatter = CycloneDxFormatter()
            path = output_dir / "chainreaper-sbom.cdx.json"
            path.write_text(cdx_formatter.format(result))
            if not quiet:
                console.print(f"  CycloneDX SBOM → {path}", style="cr.success")
