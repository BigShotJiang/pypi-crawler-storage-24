"""Auto-discovery for ecosystem plugins. Import all ecosystems to register them."""

from chainreaper.ecosystems.cargo import CargoEcosystem  # noqa: F401
from chainreaper.ecosystems.go import GoEcosystem  # noqa: F401
from chainreaper.ecosystems.maven import MavenEcosystem  # noqa: F401
from chainreaper.ecosystems.npm import NpmEcosystem  # noqa: F401
from chainreaper.ecosystems.nuget import NuGetEcosystem  # noqa: F401
from chainreaper.ecosystems.pypi import PyPIEcosystem  # noqa: F401
from chainreaper.ecosystems.rubygems import RubyGemsEcosystem  # noqa: F401

# Future ecosystems will be imported here as they're built:
# from chainreaper.ecosystems.docker import DockerEcosystem
