"""Cargo (Rust) ecosystem plugin — Cargo.toml, Cargo.lock."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx

from chainreaper.core.constants import EcosystemName
from chainreaper.core.exceptions import RegistryRateLimitError
from chainreaper.core.models import DependencyNode, DependencyTree, MaintainerInfo, PackageMetadata
from chainreaper.ecosystems.base import BaseEcosystem, EcosystemRegistry

logger = logging.getLogger(__name__)

CRATES_IO_REGISTRY = "https://crates.io"
CRATES_IO_API = "https://crates.io/api/v1/crates"

# Crate name validation:
# Must start with a letter, and contain only ASCII letters, digits, hyphens, or underscores.
# Length: 1-64 characters.
_CRATE_NAME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_-]*$")

# Allowed registry domains for SSRF protection
_ALLOWED_REGISTRY_DOMAINS = {
    "crates.io",
    "static.crates.io",
    "index.crates.io",
}

# Rate limiting
_MAX_CONCURRENT_REQUESTS = 10
_REQUEST_DELAY_SECONDS = 0.1

# File size limit
_MAX_FILE_SIZE = 50_000_000  # 50MB


def _validate_crate_name(name: str) -> bool:
    """Validate a crate name against crates.io naming rules."""
    if not name or len(name) > 64:
        return False
    return _CRATE_NAME_RE.match(name) is not None


@EcosystemRegistry.register
class CargoEcosystem(BaseEcosystem):
    """Cargo (Rust) package ecosystem plugin."""

    ecosystem_name = EcosystemName.CARGO
    manifest_files = ["Cargo.toml"]
    lockfile_files = ["Cargo.lock"]
    registry_url = CRATES_IO_REGISTRY
    description = "Rust / crates.io ecosystem"

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None
        self._semaphore = asyncio.Semaphore(_MAX_CONCURRENT_REQUESTS)

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create shared HTTP client with connection pooling."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=15.0,
                headers={
                    "User-Agent": "ChainReaper/0.1.0 (https://github.com/breachline/chainreaper)",
                    "Accept": "application/json",
                },
                follow_redirects=False,  # Prevent SSRF via redirects
            )
        return self._client

    async def close(self) -> None:
        """Close the shared HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def parse(self, target_path: Path) -> DependencyTree | None:
        """Parse Cargo.toml and optionally Cargo.lock to build dependency tree."""
        cargo_toml_path = target_path / "Cargo.toml"
        if not cargo_toml_path.exists():
            return None

        if cargo_toml_path.stat().st_size > _MAX_FILE_SIZE:
            logger.warning("Cargo.toml exceeds 50MB, skipping: %s", cargo_toml_path)
            return None

        direct_deps, root_name = self._parse_cargo_toml(cargo_toml_path)

        if root_name is None:
            root_name = target_path.name

        # Parse Cargo.lock for transitive dependencies
        transitive_deps: list[DependencyNode] = []
        cargo_lock_path = target_path / "Cargo.lock"
        if cargo_lock_path.exists():
            if cargo_lock_path.stat().st_size <= _MAX_FILE_SIZE:
                transitive_deps = self._parse_cargo_lock(cargo_lock_path, direct_deps)
            else:
                logger.warning("Cargo.lock exceeds 50MB, skipping: %s", cargo_lock_path)

        return DependencyTree(
            ecosystem=EcosystemName.CARGO,
            root_package=root_name,
            direct_dependencies=direct_deps,
            transitive_dependencies=transitive_deps,
        )

    def _parse_cargo_toml(self, cargo_toml_path: Path) -> tuple[list[DependencyNode], str | None]:
        """Parse Cargo.toml to extract dependencies.

        Returns (dependencies, package_name).
        """
        try:
            try:
                import tomllib
            except ImportError:
                import tomli as tomllib  # type: ignore[no-redef]

            content = cargo_toml_path.read_bytes()
            data = tomllib.loads(content.decode("utf-8"))
        except Exception as e:
            logger.warning("Failed to parse Cargo.toml: %s", e)
            return [], None

        # Extract package name
        package_name = None
        package_section = data.get("package", {})
        if isinstance(package_section, dict):
            package_name = package_section.get("name")

        deps: list[DependencyNode] = []

        # Parse [dependencies], [dev-dependencies], [build-dependencies]
        for section_key in ("dependencies", "dev-dependencies", "build-dependencies"):
            section = data.get(section_key, {})
            if not isinstance(section, dict):
                continue

            for name, spec in section.items():
                if not _validate_crate_name(name):
                    logger.warning("Skipping invalid crate name in Cargo.toml: %s", name[:100])
                    continue

                version = self._extract_version_from_spec(spec)
                source = self._extract_source_from_spec(spec)

                deps.append(
                    DependencyNode(
                        name=name,
                        version=version,
                        ecosystem=EcosystemName.CARGO,
                        is_direct=True,
                        source_registry=source,
                    )
                )

        # Parse [target.'cfg(...)'.dependencies] sections
        target_section = data.get("target", {})
        if isinstance(target_section, dict):
            for _target_cfg, target_data in target_section.items():
                if not isinstance(target_data, dict):
                    continue
                for section_key in ("dependencies", "dev-dependencies", "build-dependencies"):
                    section = target_data.get(section_key, {})
                    if not isinstance(section, dict):
                        continue
                    for name, spec in section.items():
                        if not _validate_crate_name(name):
                            continue
                        # Skip if already present from main sections
                        if any(d.name == name for d in deps):
                            continue
                        version = self._extract_version_from_spec(spec)
                        source = self._extract_source_from_spec(spec)
                        deps.append(
                            DependencyNode(
                                name=name,
                                version=version,
                                ecosystem=EcosystemName.CARGO,
                                is_direct=True,
                                source_registry=source,
                            )
                        )

        return deps, package_name

    @staticmethod
    def _extract_version_from_spec(spec: Any) -> str:
        """Extract version string from a Cargo dependency specification.

        Specs can be:
        - A string: "1.0"
        - A dict: { version = "1.0", features = ["derive"] }
        """
        if isinstance(spec, str):
            return spec
        if isinstance(spec, dict):
            return spec.get("version", "")
        return ""

    @staticmethod
    def _extract_source_from_spec(spec: Any) -> str:
        """Extract source registry from a Cargo dependency specification.

        If the dep specifies a git or path source, note it; otherwise default.
        """
        if isinstance(spec, dict):
            if spec.get("git"):
                return spec["git"]
            if spec.get("path"):
                return f"path:{spec['path']}"
            if spec.get("registry"):
                return spec["registry"]
        return CRATES_IO_REGISTRY

    def _parse_cargo_lock(
        self, cargo_lock_path: Path, direct_deps: list[DependencyNode]
    ) -> list[DependencyNode]:
        """Parse Cargo.lock for transitive dependencies."""
        try:
            try:
                import tomllib
            except ImportError:
                import tomli as tomllib  # type: ignore[no-redef]

            content = cargo_lock_path.read_bytes()
            data = tomllib.loads(content.decode("utf-8"))
        except Exception as e:
            logger.warning("Failed to parse Cargo.lock: %s", e)
            return []

        direct_names = {d.name for d in direct_deps}
        transitive: list[DependencyNode] = []

        for package in data.get("package", []):
            if not isinstance(package, dict):
                continue

            name = package.get("name", "")
            if not _validate_crate_name(name):
                continue

            # Skip direct deps
            if name in direct_names:
                continue

            version = package.get("version", "")
            source = package.get("source", CRATES_IO_REGISTRY)
            checksum = package.get("checksum")

            # Validate source URL
            if isinstance(source, str) and source.startswith("registry+"):
                # e.g., registry+https://github.com/rust-lang/crates.io-index
                source = CRATES_IO_REGISTRY

            transitive.append(
                DependencyNode(
                    name=name,
                    version=version,
                    ecosystem=EcosystemName.CARGO,
                    is_direct=False,
                    source_registry=CRATES_IO_REGISTRY,
                    integrity_hash=checksum,
                )
            )

        return transitive

    async def check_name_available(self, name: str) -> bool:
        """Check if a crate name is available on crates.io.

        Args:
            name: Crate name.

        Returns:
            True if the crate is not registered (404 from API).
        """
        if not _validate_crate_name(name):
            logger.warning("Invalid crate name for availability check: %s", name[:100])
            return False

        encoded = quote(name, safe="")
        url = f"{CRATES_IO_API}/{encoded}"

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"crates.io rate limit hit for {name}")
                return resp.status_code == 404
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to check crates.io for %s: %s", name, e)
                return False

    async def get_package_metadata(self, name: str) -> PackageMetadata | None:
        """Fetch package metadata from crates.io API."""
        if not _validate_crate_name(name):
            return None

        encoded = quote(name, safe="")
        url = f"{CRATES_IO_API}/{encoded}"

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 404:
                    return None
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"crates.io rate limit hit for {name}")
                resp.raise_for_status()
                data = resp.json()
                return self._parse_crate_metadata(data)
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to fetch crates.io metadata for %s: %s", name, e)
                return None

    def _parse_crate_metadata(self, data: dict[str, Any]) -> PackageMetadata:
        """Parse crates.io API response into PackageMetadata."""
        crate = data.get("crate", {})
        versions = data.get("versions", [])

        latest_version = crate.get("newest_version", "")
        description = crate.get("description", "")
        repository_url = crate.get("repository")

        # Extract publish date from the latest version
        publish_date = None
        if versions and isinstance(versions, list):
            for v in versions:
                if isinstance(v, dict) and v.get("num") == latest_version:
                    created = v.get("created_at")
                    if created:
                        with contextlib.suppress(ValueError, TypeError):
                            publish_date = datetime.fromisoformat(created.replace("Z", "+00:00"))
                    break

        # Extract owners as maintainers (if available in response)
        maintainers: list[MaintainerInfo] = []

        return PackageMetadata(
            name=crate.get("name", ""),
            version=latest_version,
            description=description,
            maintainers=maintainers,
            repository_url=repository_url,
            publish_date=publish_date,
            download_count=crate.get("downloads"),
            has_install_scripts=False,  # Cargo build scripts are build.rs, not install hooks
            license=crate.get("license"),
        )

    async def get_maintainer_info(self, package_name: str) -> list[MaintainerInfo]:
        """Get maintainer info from crates.io owners endpoint."""
        if not _validate_crate_name(package_name):
            return []

        encoded = quote(package_name, safe="")
        url = f"{CRATES_IO_API}/{encoded}/owners"

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code in (404, 403):
                    return []
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"crates.io rate limit hit for {package_name}")
                resp.raise_for_status()
                data = resp.json()

                maintainers: list[MaintainerInfo] = []
                for user in data.get("users", []):
                    if isinstance(user, dict):
                        maintainers.append(
                            MaintainerInfo(
                                username=user.get("login", ""),
                                email=None,  # crates.io doesn't expose emails
                            )
                        )
                return maintainers
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to fetch crates.io owners for %s: %s", package_name, e)
                return []
