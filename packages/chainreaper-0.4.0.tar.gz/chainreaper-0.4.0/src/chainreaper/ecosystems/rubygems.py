"""RubyGems ecosystem plugin — Gemfile, Gemfile.lock."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx

from chainreaper.core.constants import EcosystemName
from chainreaper.core.exceptions import RegistryRateLimitError
from chainreaper.core.models import DependencyNode, DependencyTree, MaintainerInfo, PackageMetadata
from chainreaper.ecosystems.base import BaseEcosystem, EcosystemRegistry

logger = logging.getLogger(__name__)

RUBYGEMS_REGISTRY = "https://rubygems.org"
RUBYGEMS_API = "https://rubygems.org/api/v1"

# Gem name validation:
# Must contain only letters, numbers, hyphens, underscores, and dots.
# Must start with a letter or number.
_GEM_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]*$")

# Gemfile dependency patterns:
# gem 'name'
# gem 'name', '~> 1.0'
# gem "name", ">= 1.0", "< 2.0"
# gem 'name', git: 'https://...'
# gem 'name', path: '../local'
_GEMFILE_GEM_RE = re.compile(
    r"""^\s*gem\s+['"]([a-zA-Z0-9][a-zA-Z0-9._-]*)['"]"""
    r"""(?:\s*,\s*['"]([^'"]*)['"]\s*)?"""
    r"""(?:\s*,\s*['"]([^'"]*)['"]\s*)?"""
)

# Gemfile.lock GEM section parsing
_LOCKFILE_SPEC_RE = re.compile(r"^\s{4}(\S+)\s+\(([^)]+)\)")
_LOCKFILE_TRANSITIVE_RE = re.compile(r"^\s{6}(\S+)")

# Allowed registry domains for SSRF protection
_ALLOWED_REGISTRY_DOMAINS = {
    "rubygems.org",
    "index.rubygems.org",
    "rubygems.pkg.github.com",
}

# Rate limiting
_MAX_CONCURRENT_REQUESTS = 10
_REQUEST_DELAY_SECONDS = 0.1

# File size limit
_MAX_FILE_SIZE = 50_000_000  # 50MB


def _validate_gem_name(name: str) -> bool:
    """Validate a gem name against RubyGems naming rules."""
    if not name or len(name) > 200:
        return False
    return _GEM_NAME_RE.match(name) is not None


@EcosystemRegistry.register
class RubyGemsEcosystem(BaseEcosystem):
    """RubyGems ecosystem plugin."""

    ecosystem_name = EcosystemName.RUBYGEMS
    manifest_files = ["Gemfile"]
    lockfile_files = ["Gemfile.lock"]
    registry_url = RUBYGEMS_REGISTRY
    description = "RubyGems (rubygems.org) ecosystem"

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None
        self._semaphore = asyncio.Semaphore(_MAX_CONCURRENT_REQUESTS)

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create shared HTTP client with connection pooling."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=15.0,
                headers={
                    "User-Agent": "ChainReaper/0.1.0 (https://github.com/breachline/chainreaper)",
                    "Accept": "application/json",
                },
                follow_redirects=False,  # Prevent SSRF via redirects
            )
        return self._client

    async def close(self) -> None:
        """Close the shared HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def parse(self, target_path: Path) -> DependencyTree | None:
        """Parse Gemfile and optionally Gemfile.lock to build dependency tree."""
        gemfile_path = target_path / "Gemfile"
        if not gemfile_path.exists():
            return None

        if gemfile_path.stat().st_size > _MAX_FILE_SIZE:
            logger.warning("Gemfile exceeds 50MB, skipping: %s", gemfile_path)
            return None

        direct_deps = self._parse_gemfile(gemfile_path)
        root_name = target_path.name

        # Parse Gemfile.lock for transitive dependencies
        transitive_deps: list[DependencyNode] = []
        lockfile_path = target_path / "Gemfile.lock"
        if lockfile_path.exists():
            if lockfile_path.stat().st_size <= _MAX_FILE_SIZE:
                transitive_deps = self._parse_gemfile_lock(lockfile_path, direct_deps)
            else:
                logger.warning("Gemfile.lock exceeds 50MB, skipping: %s", lockfile_path)

        return DependencyTree(
            ecosystem=EcosystemName.RUBYGEMS,
            root_package=root_name,
            direct_dependencies=direct_deps,
            transitive_dependencies=transitive_deps,
        )

    def _parse_gemfile(self, gemfile_path: Path) -> list[DependencyNode]:
        """Parse Gemfile to extract gem declarations.

        Handles:
        - gem 'name'
        - gem 'name', '~> 1.0'
        - gem 'name', '>= 1.0', '< 2.0'
        - Skips gems with git:/path: sources (local/git deps)
        - Skips comments and blank lines
        """
        content = gemfile_path.read_text(encoding="utf-8", errors="replace")
        deps: list[DependencyNode] = []
        seen: set[str] = set()

        for line in content.splitlines():
            stripped = line.strip()

            # Skip empty lines and comments
            if not stripped or stripped.startswith("#"):
                continue

            # Skip gems with git or path sources
            if "git:" in stripped or "github:" in stripped or "path:" in stripped:
                logger.debug("Skipping Gemfile dep with non-registry source: %s", stripped[:100])
                continue

            match = _GEMFILE_GEM_RE.match(stripped)
            if not match:
                continue

            name = match.group(1)
            version_spec = match.group(2) or ""

            if not _validate_gem_name(name):
                logger.warning("Skipping invalid gem name in Gemfile: %s", name[:100])
                continue

            if name in seen:
                continue
            seen.add(name)

            deps.append(
                DependencyNode(
                    name=name,
                    version=version_spec,
                    ecosystem=EcosystemName.RUBYGEMS,
                    is_direct=True,
                    source_registry=RUBYGEMS_REGISTRY,
                )
            )

        return deps

    def _parse_gemfile_lock(
        self, lockfile_path: Path, direct_deps: list[DependencyNode]
    ) -> list[DependencyNode]:
        """Parse Gemfile.lock for transitive dependencies.

        Gemfile.lock format:
        GEM
          remote: https://rubygems.org/
          specs:
            gem_name (1.2.3)
              dep_name (~> 1.0)
            another_gem (4.5.6)
        """
        content = lockfile_path.read_text(encoding="utf-8", errors="replace")
        direct_names = {d.name for d in direct_deps}
        transitive: list[DependencyNode] = []
        seen: set[str] = set()

        in_gem_section = False
        in_specs = False
        current_source = RUBYGEMS_REGISTRY

        for line in content.splitlines():
            stripped = line.rstrip()

            # Detect GEM section
            if stripped == "GEM":
                in_gem_section = True
                in_specs = False
                continue

            # Detect end of GEM section (new top-level section)
            if in_gem_section and stripped and not stripped.startswith(" "):
                in_gem_section = False
                in_specs = False
                continue

            if not in_gem_section:
                continue

            # Detect remote URL
            remote_match = re.match(r"^\s+remote:\s+(\S+)", stripped)
            if remote_match:
                remote_url = remote_match.group(1)
                # Validate remote URL for SSRF protection
                try:
                    from urllib.parse import urlparse

                    parsed = urlparse(remote_url)
                    if parsed.hostname in _ALLOWED_REGISTRY_DOMAINS:
                        current_source = remote_url
                    else:
                        logger.warning(
                            "Untrusted registry URL in Gemfile.lock: %s (using default)",
                            parsed.hostname,
                        )
                        current_source = RUBYGEMS_REGISTRY
                except Exception:
                    current_source = RUBYGEMS_REGISTRY
                continue

            # Detect specs section
            if stripped.strip() == "specs:":
                in_specs = True
                continue

            if not in_specs:
                continue

            # Parse spec line: 4-space indent = top-level gem, 6-space = transitive dep
            spec_match = _LOCKFILE_SPEC_RE.match(stripped)
            if spec_match:
                name = spec_match.group(1)
                version = spec_match.group(2)

                if not _validate_gem_name(name):
                    continue

                # Skip direct deps
                if name in direct_names:
                    continue

                if name in seen:
                    continue
                seen.add(name)

                transitive.append(
                    DependencyNode(
                        name=name,
                        version=version,
                        ecosystem=EcosystemName.RUBYGEMS,
                        is_direct=False,
                        source_registry=current_source,
                    )
                )

        return transitive

    async def check_name_available(self, name: str) -> bool:
        """Check if a gem name is available on RubyGems.

        Args:
            name: Gem name.

        Returns:
            True if the gem is not registered (404 from API).
        """
        if not _validate_gem_name(name):
            logger.warning("Invalid gem name for availability check: %s", name[:100])
            return False

        encoded = quote(name, safe="")
        url = f"{RUBYGEMS_API}/gems/{encoded}.json"

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"RubyGems rate limit hit for {name}")
                return resp.status_code == 404
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to check RubyGems for %s: %s", name, e)
                return False

    async def get_package_metadata(self, name: str) -> PackageMetadata | None:
        """Fetch package metadata from the RubyGems API."""
        if not _validate_gem_name(name):
            return None

        encoded = quote(name, safe="")
        url = f"{RUBYGEMS_API}/gems/{encoded}.json"

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 404:
                    return None
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"RubyGems rate limit hit for {name}")
                resp.raise_for_status()
                data = resp.json()
                return self._parse_gem_metadata(data)
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to fetch RubyGems metadata for %s: %s", name, e)
                return None

    def _parse_gem_metadata(self, data: dict[str, Any]) -> PackageMetadata:
        """Parse RubyGems API response into PackageMetadata."""
        # Extract maintainers from authors field
        maintainers: list[MaintainerInfo] = []
        authors = data.get("authors")
        if authors and isinstance(authors, str):
            for author in authors.split(","):
                author = author.strip()
                if author:
                    maintainers.append(
                        MaintainerInfo(
                            username=author,
                            email=None,
                        )
                    )

        # Extract publish date
        publish_date = None
        version_created = data.get("version_created_at")
        if version_created:
            with contextlib.suppress(ValueError, TypeError):
                publish_date = datetime.fromisoformat(version_created.replace("Z", "+00:00"))

        # Extract repository URL
        repo_url = (
            data.get("source_code_uri") or data.get("homepage_uri") or data.get("project_uri")
        )

        return PackageMetadata(
            name=data.get("name", ""),
            version=data.get("version", ""),
            description=data.get("info", ""),
            maintainers=maintainers,
            repository_url=repo_url,
            publish_date=publish_date,
            download_count=data.get("downloads"),
            has_install_scripts=False,  # Ruby gems can have extensions but not install scripts
            license=", ".join(data.get("licenses", [])) if data.get("licenses") else None,
        )

    async def get_maintainer_info(self, package_name: str) -> list[MaintainerInfo]:
        """Get maintainer info from RubyGems owners endpoint."""
        if not _validate_gem_name(package_name):
            return []

        encoded = quote(package_name, safe="")
        url = f"{RUBYGEMS_API}/gems/{encoded}/owners.json"

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code in (404, 401, 403):
                    # Owners endpoint may require auth; fall back to metadata
                    metadata = await self.get_package_metadata(package_name)
                    return metadata.maintainers if metadata else []
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"RubyGems rate limit hit for {package_name}")
                resp.raise_for_status()
                data = resp.json()

                maintainers: list[MaintainerInfo] = []
                if isinstance(data, list):
                    for owner in data:
                        if isinstance(owner, dict):
                            maintainers.append(
                                MaintainerInfo(
                                    username=owner.get("handle", owner.get("login", "")),
                                    email=owner.get("email"),
                                )
                            )
                return maintainers
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to fetch RubyGems owners for %s: %s", package_name, e)
                return []
