"""Go module ecosystem plugin — go.mod, go.sum."""

from __future__ import annotations

import asyncio
import logging
import re
from pathlib import Path
from urllib.parse import quote

import httpx

from chainreaper.core.constants import EcosystemName
from chainreaper.core.exceptions import RegistryRateLimitError
from chainreaper.core.models import DependencyNode, DependencyTree, MaintainerInfo, PackageMetadata
from chainreaper.ecosystems.base import BaseEcosystem, EcosystemRegistry

logger = logging.getLogger(__name__)

GO_PROXY = "https://proxy.golang.org"

# Go module path validation:
# Must start with a domain-like component (e.g., github.com, golang.org)
# Segments separated by /, each segment is alphanumeric with dots/hyphens/underscores/tildes
_GO_MODULE_RE = re.compile(
    r"^[a-zA-Z0-9][-a-zA-Z0-9._~]*\.[a-zA-Z]{2,}"  # domain part (e.g., github.com)
    r"(/[a-zA-Z0-9][-a-zA-Z0-9._~]*)*$"  # path segments
)

# go.mod require line: module/path vX.Y.Z
_REQUIRE_LINE_RE = re.compile(r"^\s*([a-zA-Z0-9][-a-zA-Z0-9._~/]*)\s+(v[^\s]+)\s*$")

# go.mod module declaration
_MODULE_LINE_RE = re.compile(r"^module\s+(\S+)")

# Allowed registry domains for SSRF protection
_ALLOWED_REGISTRY_DOMAINS = {
    "proxy.golang.org",
    "sum.golang.org",
    "index.golang.org",
}

# Rate limiting
_MAX_CONCURRENT_REQUESTS = 10
_REQUEST_DELAY_SECONDS = 0.1

# File size limit
_MAX_FILE_SIZE = 50_000_000  # 50MB


def _validate_module_path(path: str) -> bool:
    """Validate a Go module path."""
    if not path or len(path) > 500:
        return False
    return _GO_MODULE_RE.match(path) is not None


@EcosystemRegistry.register
class GoEcosystem(BaseEcosystem):
    """Go module ecosystem plugin."""

    ecosystem_name = EcosystemName.GO
    manifest_files = ["go.mod"]
    lockfile_files = ["go.sum"]
    registry_url = GO_PROXY
    description = "Go module ecosystem (proxy.golang.org)"

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None
        self._semaphore = asyncio.Semaphore(_MAX_CONCURRENT_REQUESTS)

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create shared HTTP client with connection pooling."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=15.0,
                headers={
                    "User-Agent": "ChainReaper/0.1.0 (https://github.com/breachline/chainreaper)",
                },
                follow_redirects=False,  # Prevent SSRF via redirects
            )
        return self._client

    async def close(self) -> None:
        """Close the shared HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def parse(self, target_path: Path) -> DependencyTree | None:
        """Parse go.mod and optionally go.sum to build dependency tree."""
        gomod_path = target_path / "go.mod"
        if not gomod_path.exists():
            return None

        if gomod_path.stat().st_size > _MAX_FILE_SIZE:
            logger.warning("go.mod exceeds 50MB, skipping: %s", gomod_path)
            return None

        direct_deps, root_name = self._parse_go_mod(gomod_path)

        if root_name is None:
            root_name = target_path.name

        # Parse go.sum for transitive deps and integrity hashes
        transitive_deps: list[DependencyNode] = []
        gosum_path = target_path / "go.sum"
        if gosum_path.exists():
            if gosum_path.stat().st_size <= _MAX_FILE_SIZE:
                transitive_deps = self._parse_go_sum(gosum_path, direct_deps)
            else:
                logger.warning("go.sum exceeds 50MB, skipping: %s", gosum_path)

        return DependencyTree(
            ecosystem=EcosystemName.GO,
            root_package=root_name,
            direct_dependencies=direct_deps,
            transitive_dependencies=transitive_deps,
        )

    def _parse_go_mod(self, gomod_path: Path) -> tuple[list[DependencyNode], str | None]:
        """Parse go.mod to extract direct dependencies.

        Returns (dependencies, module_name).
        """
        content = gomod_path.read_text(encoding="utf-8", errors="replace")
        lines = content.splitlines()

        module_name: str | None = None
        deps: list[DependencyNode] = []
        in_require_block = False
        in_replace_block = False

        for line in lines:
            stripped = line.strip()

            # Skip empty lines and comments
            if not stripped or stripped.startswith("//"):
                continue

            # Detect module declaration
            module_match = _MODULE_LINE_RE.match(stripped)
            if module_match:
                module_name = module_match.group(1)
                continue

            # Track require/replace blocks
            if stripped == "require (" or stripped.startswith("require ("):
                in_require_block = True
                continue
            if stripped == "replace (" or stripped.startswith("replace ("):
                in_replace_block = True
                continue
            if stripped == ")":
                in_require_block = False
                in_replace_block = False
                continue

            # Skip replace directives (we only care about declared deps)
            if in_replace_block or stripped.startswith("replace "):
                continue

            # Handle single-line require: require module/path v1.2.3
            if stripped.startswith("require ") and "(" not in stripped:
                stripped = stripped[len("require ") :].strip()

            # Parse require line (either in block or standalone)
            if in_require_block or _REQUIRE_LINE_RE.match(stripped):
                req_match = _REQUIRE_LINE_RE.match(stripped)
                if req_match:
                    module_path = req_match.group(1)
                    version = req_match.group(2)

                    # Remove // indirect comment
                    if "//" in version:
                        version = version.split("//")[0].strip()

                    if not _validate_module_path(module_path):
                        logger.warning("Skipping invalid Go module path: %s", module_path[:100])
                        continue

                    # Check if marked as indirect
                    is_indirect = "// indirect" in line

                    deps.append(
                        DependencyNode(
                            name=module_path,
                            version=version,
                            ecosystem=EcosystemName.GO,
                            is_direct=not is_indirect,
                            source_registry=GO_PROXY,
                        )
                    )

        return deps, module_name

    def _parse_go_sum(
        self, gosum_path: Path, direct_deps: list[DependencyNode]
    ) -> list[DependencyNode]:
        """Parse go.sum for transitive dependencies with integrity hashes.

        go.sum format: module/path vX.Y.Z h1:hash=
                       module/path vX.Y.Z/go.mod h1:hash=
        """
        content = gosum_path.read_text(encoding="utf-8", errors="replace")
        direct_names = {d.name for d in direct_deps}
        seen: set[str] = set()
        transitive: list[DependencyNode] = []

        for line in content.splitlines():
            line = line.strip()
            if not line:
                continue

            parts = line.split()
            if len(parts) < 3:
                continue

            module_path = parts[0]
            version = parts[1]
            integrity_hash = parts[2]

            # Skip /go.mod entries — we only want source entries
            if version.endswith("/go.mod"):
                continue

            if not _validate_module_path(module_path):
                continue

            # Skip direct deps — they're already captured from go.mod
            if module_path in direct_names:
                continue

            # Deduplicate
            key = f"{module_path}@{version}"
            if key in seen:
                continue
            seen.add(key)

            transitive.append(
                DependencyNode(
                    name=module_path,
                    version=version,
                    ecosystem=EcosystemName.GO,
                    is_direct=False,
                    source_registry=GO_PROXY,
                    integrity_hash=integrity_hash,
                )
            )

        return transitive

    async def check_name_available(self, name: str) -> bool:
        """Check if a Go module exists on the Go module proxy.

        Queries proxy.golang.org/{module}/@v/list — if empty or 404, the module
        is potentially available for takeover.

        Args:
            name: Go module path (e.g., github.com/org/repo).

        Returns:
            True if no versions are registered (available for takeover).
        """
        if not _validate_module_path(name):
            logger.warning("Invalid Go module path for availability check: %s", name[:100])
            return False

        # Go proxy uses case-encoded paths: upper -> !lower
        encoded_module = self._encode_module_path(name)
        url = f"{GO_PROXY}/{encoded_module}/@v/list"

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"Go proxy rate limit hit for {name}")
                if resp.status_code == 404:
                    return True
                if resp.status_code == 410:
                    # Gone — module was retracted or removed
                    return True
                resp.raise_for_status()

                # Empty response body means no versions found
                body = resp.text.strip()
                return len(body) == 0
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to check Go proxy for %s: %s", name, e)
                return False

    async def get_package_metadata(self, name: str) -> PackageMetadata | None:
        """Fetch package metadata from the Go module proxy."""
        if not _validate_module_path(name):
            return None

        encoded_module = self._encode_module_path(name)
        url = f"{GO_PROXY}/{encoded_module}/@latest"

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code in (404, 410):
                    return None
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"Go proxy rate limit hit for {name}")
                resp.raise_for_status()
                data = resp.json()

                return PackageMetadata(
                    name=name,
                    version=data.get("Version", ""),
                    description="",
                    maintainers=[],
                    repository_url=f"https://{name}" if name.startswith("github.com/") else None,
                    publish_date=None,
                    has_install_scripts=False,
                    license=None,
                )
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to fetch Go module metadata for %s: %s", name, e)
                return None

    async def get_maintainer_info(self, package_name: str) -> list[MaintainerInfo]:
        """Get maintainer info — Go proxy doesn't expose maintainer data."""
        return []

    @staticmethod
    def _encode_module_path(module_path: str) -> str:
        """Encode a Go module path for the proxy URL.

        The Go module proxy uses case-encoding: uppercase letters in module
        paths are replaced with !lowercase (e.g., GitHub -> !github).
        Each path segment is also URL-encoded.
        """
        parts = module_path.split("/")
        encoded_parts: list[str] = []
        for part in parts:
            # Case-encode: A -> !a
            encoded = ""
            for ch in part:
                if ch.isupper():
                    encoded += f"!{ch.lower()}"
                else:
                    encoded += ch
            encoded_parts.append(quote(encoded, safe=""))
        return "/".join(encoded_parts)
