"""npm ecosystem plugin — package.json, package-lock.json, node_modules."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx

from chainreaper.core.constants import EcosystemName
from chainreaper.core.exceptions import RegistryRateLimitError
from chainreaper.core.models import DependencyNode, DependencyTree, MaintainerInfo, PackageMetadata
from chainreaper.ecosystems.base import BaseEcosystem, EcosystemRegistry

logger = logging.getLogger(__name__)

NPM_REGISTRY = "https://registry.npmjs.org"

# npm package name validation: scoped or unscoped
_NPM_NAME_RE = re.compile(r"^(@[a-z0-9\-~][a-z0-9\-._~]*/)?[a-z0-9\-~][a-z0-9\-._~]*$")

# Allowed registry domains for SSRF protection
_ALLOWED_REGISTRY_DOMAINS = {
    "registry.npmjs.org",
    "registry.yarnpkg.com",
    "npm.pkg.github.com",
}

# Rate limiting: max concurrent requests
_MAX_CONCURRENT_REQUESTS = 10
_REQUEST_DELAY_SECONDS = 0.1


def _validate_package_name(name: str) -> bool:
    """Validate npm package name against npm naming rules."""
    if not name or len(name) > 214:
        return False
    return _NPM_NAME_RE.match(name) is not None


def _safe_registry_url(base_url: str, package_name: str) -> str | None:
    """Build a safe registry URL, encoding the package name."""
    if not _validate_package_name(package_name):
        logger.warning("Invalid package name rejected: %s", package_name[:100])
        return None
    # Scoped packages use %2f for the slash: @scope%2fname
    encoded = quote(package_name, safe="@")
    return f"{base_url}/{encoded}"


@EcosystemRegistry.register
class NpmEcosystem(BaseEcosystem):
    """npm package ecosystem plugin."""

    ecosystem_name = EcosystemName.NPM
    manifest_files = ["package.json"]
    lockfile_files = ["package-lock.json", "yarn.lock", "pnpm-lock.yaml"]
    registry_url = NPM_REGISTRY
    description = "Node.js / npm package ecosystem"

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None
        self._semaphore = asyncio.Semaphore(_MAX_CONCURRENT_REQUESTS)

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create shared HTTP client with connection pooling."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=15.0,
                headers={
                    "User-Agent": "ChainReaper/0.1.0 (https://github.com/breachline/chainreaper)",
                },
                follow_redirects=False,  # Prevent SSRF via redirects
            )
        return self._client

    async def close(self) -> None:
        """Close the shared HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def parse(self, target_path: Path) -> DependencyTree | None:
        """Parse package.json and lockfile to build dependency tree."""
        manifest_path = target_path / "package.json"
        if not manifest_path.exists():
            return None

        # Size check to prevent memory exhaustion
        if manifest_path.stat().st_size > 50_000_000:  # 50MB limit
            logger.warning("package.json exceeds 50MB, skipping: %s", manifest_path)
            return None

        with open(manifest_path) as f:
            manifest = json.load(f)

        root_name = manifest.get("name", target_path.name)
        direct_deps: list[DependencyNode] = []
        transitive_deps: list[DependencyNode] = []

        for dep_group in ("dependencies", "devDependencies"):
            for name, version_spec in manifest.get(dep_group, {}).items():
                if not _validate_package_name(name):
                    logger.warning("Skipping invalid package name in manifest: %s", name[:100])
                    continue
                direct_deps.append(
                    DependencyNode(
                        name=name,
                        version=version_spec,
                        ecosystem=EcosystemName.NPM,
                        is_direct=True,
                        source_registry=NPM_REGISTRY,
                    )
                )

        lockfile_path = target_path / "package-lock.json"
        if lockfile_path.exists():
            if lockfile_path.stat().st_size <= 50_000_000:
                transitive_deps = self._parse_lockfile(lockfile_path, direct_deps)
            else:
                logger.warning("package-lock.json exceeds 50MB, skipping lockfile parsing")

        return DependencyTree(
            ecosystem=EcosystemName.NPM,
            root_package=root_name,
            direct_dependencies=direct_deps,
            transitive_dependencies=transitive_deps,
        )

    def _parse_lockfile(
        self, lockfile_path: Path, direct_deps: list[DependencyNode]
    ) -> list[DependencyNode]:
        """Extract transitive dependencies from package-lock.json."""
        with open(lockfile_path) as f:
            lockfile = json.load(f)

        direct_names = {d.name for d in direct_deps}
        transitive: list[DependencyNode] = []

        packages = lockfile.get("packages", {})
        for pkg_path, pkg_data in packages.items():
            if not pkg_path or pkg_path == "":
                continue

            name = pkg_data.get("name") or pkg_path.split("node_modules/")[-1]
            if not _validate_package_name(name):
                continue
            if name in direct_names:
                continue

            version = pkg_data.get("version", "")
            integrity = pkg_data.get("integrity")
            resolved = pkg_data.get("resolved", "")

            # SSRF protection: validate resolved URL domain
            safe_registry = NPM_REGISTRY
            if resolved:
                try:
                    from urllib.parse import urlparse

                    parsed = urlparse(resolved)
                    if parsed.hostname in _ALLOWED_REGISTRY_DOMAINS:
                        safe_registry = resolved
                    else:
                        logger.warning(
                            "Untrusted registry URL for %s: %s (using default)",
                            name,
                            parsed.hostname,
                        )
                except Exception:
                    pass

            transitive.append(
                DependencyNode(
                    name=name,
                    version=version,
                    ecosystem=EcosystemName.NPM,
                    is_direct=False,
                    source_registry=safe_registry,
                    integrity_hash=integrity,
                )
            )

        return transitive

    async def get_package_metadata(self, name: str) -> PackageMetadata | None:
        """Fetch package metadata from the npm registry."""
        url = _safe_registry_url(NPM_REGISTRY, name)
        if not url:
            return None

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 404:
                    return None
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"npm rate limit hit for {name}")
                resp.raise_for_status()
                data = resp.json()
                return self._parse_npm_metadata(data)
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to fetch npm metadata for %s: %s", name, e)
                return None

    async def check_name_available(self, name: str) -> bool:
        """Check if a package name is available on npm."""
        url = _safe_registry_url(NPM_REGISTRY, name)
        if not url:
            return False

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"npm rate limit hit for {name}")
                return resp.status_code == 404
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError:
                return False

    async def get_maintainer_info(self, package_name: str) -> list[MaintainerInfo]:
        """Get maintainer info from npm registry."""
        metadata = await self.get_package_metadata(package_name)
        if metadata:
            return metadata.maintainers
        return []

    def _parse_npm_metadata(self, data: dict[str, Any]) -> PackageMetadata:
        """Parse npm registry API response into PackageMetadata."""
        latest_version = data.get("dist-tags", {}).get("latest", "")
        latest_data = data.get("versions", {}).get(latest_version, {})

        maintainers = [
            MaintainerInfo(
                username=m.get("name", ""),
                email=m.get("email"),
            )
            for m in data.get("maintainers", [])
        ]

        scripts = latest_data.get("scripts", {})
        has_install_scripts = any(
            key in scripts for key in ("preinstall", "install", "postinstall", "prepare")
        )

        time_data = data.get("time", {})
        publish_date = None
        if latest_version in time_data:
            with contextlib.suppress(ValueError, TypeError):
                publish_date = datetime.fromisoformat(
                    time_data[latest_version].replace("Z", "+00:00")
                )

        return PackageMetadata(
            name=data.get("name", ""),
            version=latest_version,
            description=data.get("description", ""),
            maintainers=maintainers,
            repository_url=self._extract_repo_url(data),
            publish_date=publish_date,
            has_install_scripts=has_install_scripts,
            license=latest_data.get("license") or data.get("license"),
        )

    def _extract_repo_url(self, data: dict[str, Any]) -> str | None:
        """Extract repository URL from npm metadata."""
        repo = data.get("repository")
        if isinstance(repo, dict):
            return repo.get("url")
        if isinstance(repo, str):
            return repo
        return None
