"""NuGet ecosystem plugin — .csproj, packages.config."""

from __future__ import annotations

import asyncio
import logging
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import quote

import httpx

from chainreaper.core.constants import EcosystemName
from chainreaper.core.exceptions import RegistryRateLimitError
from chainreaper.core.models import DependencyNode, DependencyTree, MaintainerInfo, PackageMetadata
from chainreaper.ecosystems.base import BaseEcosystem, EcosystemRegistry

logger = logging.getLogger(__name__)

NUGET_REGISTRY = "https://api.nuget.org"
NUGET_FLAT_CONTAINER = "https://api.nuget.org/v3-flatcontainer"
NUGET_REGISTRATION = "https://api.nuget.org/v3/registration5-semver1"

# NuGet package ID validation:
# Must consist of alphanumeric characters, dots, hyphens, and underscores.
# Cannot start or end with a dot, hyphen, or underscore.
# 1-128 characters.
_NUGET_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,126}[a-zA-Z0-9]$|^[a-zA-Z0-9]$")

# Allowed registry domains for SSRF protection
_ALLOWED_REGISTRY_DOMAINS = {
    "api.nuget.org",
    "nuget.org",
    "azureedge.net",
    "nuget.pkg.github.com",
}

# Rate limiting
_MAX_CONCURRENT_REQUESTS = 10
_REQUEST_DELAY_SECONDS = 0.1

# File size limit
_MAX_FILE_SIZE = 50_000_000  # 50MB


def _validate_nuget_name(name: str) -> bool:
    """Validate a NuGet package ID against naming rules."""
    if not name or len(name) > 128:
        return False
    return _NUGET_NAME_RE.match(name) is not None


@EcosystemRegistry.register
class NuGetEcosystem(BaseEcosystem):
    """NuGet (.NET) package ecosystem plugin."""

    ecosystem_name = EcosystemName.NUGET
    manifest_files = ["*.csproj", "packages.config"]
    lockfile_files: list[str] = []
    registry_url = NUGET_REGISTRY
    description = "NuGet (.NET) ecosystem"

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None
        self._semaphore = asyncio.Semaphore(_MAX_CONCURRENT_REQUESTS)

    def detect(self, target_path: Path) -> bool:
        """Check if this ecosystem exists in the target directory.

        Override base to handle *.csproj glob pattern.
        """
        # Check for packages.config
        if (target_path / "packages.config").exists():
            return True

        # Check for *.csproj files
        csproj_files = list(target_path.glob("*.csproj"))
        return len(csproj_files) > 0

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create shared HTTP client with connection pooling."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=15.0,
                headers={
                    "User-Agent": "ChainReaper/0.1.0 (https://github.com/breachline/chainreaper)",
                    "Accept": "application/json",
                },
                follow_redirects=False,  # Prevent SSRF via redirects
            )
        return self._client

    async def close(self) -> None:
        """Close the shared HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def parse(self, target_path: Path) -> DependencyTree | None:
        """Parse .csproj and/or packages.config to build dependency tree.

        Priority order:
        1. *.csproj files (modern SDK-style PackageReference)
        2. packages.config (legacy NuGet format)
        """
        direct_deps: list[DependencyNode] = []
        root_name = target_path.name

        # Try .csproj files first (modern format)
        csproj_files = list(target_path.glob("*.csproj"))
        for csproj_path in csproj_files:
            if csproj_path.stat().st_size > _MAX_FILE_SIZE:
                logger.warning("*.csproj exceeds 50MB, skipping: %s", csproj_path)
                continue
            deps, project_name = self._parse_csproj(csproj_path)
            direct_deps.extend(deps)
            if project_name and root_name == target_path.name:
                root_name = project_name

        # Try packages.config if no deps from .csproj
        if not direct_deps:
            packages_config_path = target_path / "packages.config"
            if packages_config_path.exists():
                if packages_config_path.stat().st_size > _MAX_FILE_SIZE:
                    logger.warning(
                        "packages.config exceeds 50MB, skipping: %s",
                        packages_config_path,
                    )
                    return None
                direct_deps = self._parse_packages_config(packages_config_path)

        if not direct_deps:
            # Check if any manifest exists at all
            if not self.detect(target_path):
                return None
            logger.info(
                "NuGet manifest detected but no dependencies extracted in %s",
                target_path,
            )

        # Deduplicate by package name (keep first occurrence)
        seen: set[str] = set()
        unique_deps: list[DependencyNode] = []
        for dep in direct_deps:
            key = dep.name.lower()  # NuGet package IDs are case-insensitive
            if key not in seen:
                seen.add(key)
                unique_deps.append(dep)

        return DependencyTree(
            ecosystem=EcosystemName.NUGET,
            root_package=root_name,
            direct_dependencies=unique_deps,
            transitive_dependencies=[],
        )

    def _parse_csproj(self, csproj_path: Path) -> tuple[list[DependencyNode], str | None]:
        """Parse .csproj file to extract PackageReference elements.

        Modern SDK-style .csproj format:
        <Project Sdk="Microsoft.NET.Sdk">
          <ItemGroup>
            <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
          </ItemGroup>
        </Project>

        Returns (dependencies, project_name).
        """
        try:
            tree = ET.parse(csproj_path)
        except ET.ParseError as e:
            logger.warning("Failed to parse %s: %s", csproj_path.name, e)
            return [], None

        root = tree.getroot()

        # Detect namespace — .csproj may use MSBuild namespace
        ns = ""
        if root.tag.startswith("{"):
            ns = root.tag.split("}")[0] + "}"

        # Extract project name from AssemblyName or RootNamespace
        project_name = None
        for prop_group in root.iter(f"{ns}PropertyGroup"):
            assembly_name = prop_group.find(f"{ns}AssemblyName")
            if assembly_name is not None and assembly_name.text:
                project_name = assembly_name.text.strip()
                break
            root_ns = prop_group.find(f"{ns}RootNamespace")
            if root_ns is not None and root_ns.text:
                project_name = root_ns.text.strip()
                break

        # If no explicit name, use the filename
        if not project_name:
            project_name = csproj_path.stem

        deps: list[DependencyNode] = []

        # Extract PackageReference elements from all ItemGroups
        for item_group in root.iter(f"{ns}ItemGroup"):
            for pkg_ref in item_group.findall(f"{ns}PackageReference"):
                name = pkg_ref.get("Include") or pkg_ref.get("include") or ""
                version = pkg_ref.get("Version") or pkg_ref.get("version") or ""

                # Version might be in a child element instead of attribute
                if not version:
                    version_el = pkg_ref.find(f"{ns}Version")
                    if version_el is not None and version_el.text:
                        version = version_el.text.strip()

                name = name.strip()
                version = version.strip()

                if not name:
                    continue

                if not _validate_nuget_name(name):
                    logger.warning(
                        "Skipping invalid NuGet package name in %s: %s",
                        csproj_path.name,
                        name[:100],
                    )
                    continue

                deps.append(
                    DependencyNode(
                        name=name,
                        version=version,
                        ecosystem=EcosystemName.NUGET,
                        is_direct=True,
                        source_registry=NUGET_REGISTRY,
                    )
                )

        return deps, project_name

    def _parse_packages_config(self, packages_config_path: Path) -> list[DependencyNode]:
        """Parse packages.config (legacy NuGet format).

        Format:
        <?xml version="1.0" encoding="utf-8"?>
        <packages>
          <package id="Newtonsoft.Json" version="13.0.3" targetFramework="net48" />
        </packages>
        """
        try:
            tree = ET.parse(packages_config_path)
        except ET.ParseError as e:
            logger.warning("Failed to parse packages.config: %s", e)
            return []

        root = tree.getroot()
        deps: list[DependencyNode] = []

        for pkg_el in root.findall("package"):
            name = pkg_el.get("id", "").strip()
            version = pkg_el.get("version", "").strip()

            if not name:
                continue

            if not _validate_nuget_name(name):
                logger.warning(
                    "Skipping invalid NuGet package name in packages.config: %s",
                    name[:100],
                )
                continue

            deps.append(
                DependencyNode(
                    name=name,
                    version=version,
                    ecosystem=EcosystemName.NUGET,
                    is_direct=True,
                    source_registry=NUGET_REGISTRY,
                )
            )

        return deps

    async def check_name_available(self, name: str) -> bool:
        """Check if a NuGet package name is available.

        Queries the flat container API — 404 means the package doesn't exist.

        Args:
            name: NuGet package ID.

        Returns:
            True if the package is not registered (available for takeover).
        """
        if not _validate_nuget_name(name):
            logger.warning("Invalid NuGet package name for availability check: %s", name[:100])
            return False

        # NuGet flat container uses lowercase package IDs
        encoded = quote(name.lower(), safe="")
        url = f"{NUGET_FLAT_CONTAINER}/{encoded}/index.json"

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"NuGet rate limit hit for {name}")
                return resp.status_code == 404
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to check NuGet for %s: %s", name, e)
                return False

    async def get_package_metadata(self, name: str) -> PackageMetadata | None:
        """Fetch package metadata from NuGet registration API."""
        if not _validate_nuget_name(name):
            return None

        # First check if the package exists via flat container
        encoded = quote(name.lower(), safe="")
        url = f"{NUGET_FLAT_CONTAINER}/{encoded}/index.json"

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 404:
                    return None
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"NuGet rate limit hit for {name}")
                resp.raise_for_status()
                data = resp.json()

                versions = data.get("versions", [])
                latest_version = versions[-1] if versions else ""

                return PackageMetadata(
                    name=name,
                    version=latest_version,
                    description="",
                    maintainers=[],
                    repository_url=None,
                    publish_date=None,
                    has_install_scripts=False,
                    license=None,
                )
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to fetch NuGet metadata for %s: %s", name, e)
                return None

    async def get_maintainer_info(self, package_name: str) -> list[MaintainerInfo]:
        """Get maintainer info — NuGet doesn't expose owner info via public API easily."""
        return []
