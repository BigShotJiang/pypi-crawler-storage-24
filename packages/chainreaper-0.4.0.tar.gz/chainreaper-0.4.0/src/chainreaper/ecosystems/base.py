"""Base class and registry for package ecosystem plugins."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import ClassVar

from chainreaper.core.constants import EcosystemName
from chainreaper.core.models import DependencyTree, MaintainerInfo, PackageMetadata


class BaseEcosystem(ABC):
    """Base class for package ecosystem plugins.

    Each ecosystem plugin provides:
    - Manifest file detection
    - Dependency tree parsing
    - Registry API access
    - Lock file parsing and integrity checking
    """

    ecosystem_name: ClassVar[EcosystemName]
    manifest_files: ClassVar[list[str]]
    lockfile_files: ClassVar[list[str]] = []
    registry_url: ClassVar[str] = ""
    description: ClassVar[str] = ""

    def detect(self, target_path: Path) -> bool:
        """Check if this ecosystem exists in the target directory."""
        return any((target_path / manifest).exists() for manifest in self.manifest_files)

    @abstractmethod
    async def parse(self, target_path: Path) -> DependencyTree | None:
        """Parse manifest and lockfile to build a dependency tree."""
        ...

    async def get_package_metadata(self, name: str) -> PackageMetadata | None:
        """Fetch metadata for a package from the registry."""
        return None

    async def check_name_available(self, name: str) -> bool:
        """Check if a package name is available (not registered) on the public registry."""
        return False

    async def get_maintainer_info(self, package_name: str) -> list[MaintainerInfo]:
        """Get maintainer information for a package."""
        return []


class EcosystemRegistry:
    """Auto-discovery registry for ecosystem plugins."""

    _registry: ClassVar[dict[str, type[BaseEcosystem]]] = {}

    @classmethod
    def register(cls, ecosystem_cls: type[BaseEcosystem]) -> type[BaseEcosystem]:
        """Register an ecosystem plugin."""
        cls._registry[ecosystem_cls.ecosystem_name.value] = ecosystem_cls
        return ecosystem_cls

    @classmethod
    def get(cls, name: str) -> type[BaseEcosystem] | None:
        """Get an ecosystem plugin by name."""
        return cls._registry.get(name)

    @classmethod
    def get_all(cls) -> dict[str, type[BaseEcosystem]]:
        """Get all registered ecosystem plugins."""
        return dict(cls._registry)
