"""PyPI ecosystem plugin — requirements.txt, pyproject.toml, setup.py, setup.cfg."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx

from chainreaper.core.constants import EcosystemName
from chainreaper.core.exceptions import RegistryRateLimitError
from chainreaper.core.models import DependencyNode, DependencyTree, MaintainerInfo, PackageMetadata
from chainreaper.ecosystems.base import BaseEcosystem, EcosystemRegistry

logger = logging.getLogger(__name__)

PYPI_API = "https://pypi.org/pypi"
PYPI_REGISTRY = "https://pypi.org"

# PyPI package name validation per PEP 508 / PEP 625:
# Must start and end with alphanumeric, can contain letters, digits, hyphens,
# underscores, and dots in between. PyPI normalizes these to lowercase with hyphens.
_PYPI_NAME_RE = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?$")

# Requirements.txt line pattern: name[extras] (operator version) (, operator version)*
# Captures package name and optional pinned version (==X.Y.Z)
_REQUIREMENTS_LINE_RE = re.compile(
    r"^([A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)(\[[^\]]*\])?\s*(.*)"
)

# Version specifier pattern (matches ==1.0.0, >=1.0.0, etc.)
_VERSION_SPEC_RE = re.compile(r"^(~=|==|!=|<=?|>=?|===)\s*([^\s,;]+)")

# Allowed registry domains for SSRF protection
_ALLOWED_REGISTRY_DOMAINS = {
    "pypi.org",
    "files.pythonhosted.org",
    "pypi.python.org",
}

# Rate limiting: max concurrent requests
_MAX_CONCURRENT_REQUESTS = 10
_REQUEST_DELAY_SECONDS = 0.1

# File size limit to prevent memory exhaustion
_MAX_FILE_SIZE = 50_000_000  # 50MB


def _validate_package_name(name: str) -> bool:
    """Validate PyPI package name against PEP 508 naming rules."""
    if not name or len(name) > 200:
        return False
    return _PYPI_NAME_RE.match(name) is not None


def _safe_api_url(package_name: str) -> str | None:
    """Build a safe PyPI JSON API URL, encoding the package name.

    PyPI normalizes names: underscores/dots become hyphens, lowercase.
    We URL-encode for safety but PyPI handles normalization server-side.
    """
    if not _validate_package_name(package_name):
        logger.warning("Invalid PyPI package name rejected: %s", package_name[:100])
        return None
    encoded = quote(package_name, safe="")
    return f"{PYPI_API}/{encoded}/json"


@EcosystemRegistry.register
class PyPIEcosystem(BaseEcosystem):
    """PyPI package ecosystem plugin."""

    ecosystem_name = EcosystemName.PYPI
    manifest_files = ["requirements.txt", "setup.py", "setup.cfg", "pyproject.toml"]
    lockfile_files = ["requirements.lock", "poetry.lock", "Pipfile.lock"]
    registry_url = PYPI_REGISTRY
    description = "Python Package Index (PyPI) ecosystem"

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None
        self._semaphore = asyncio.Semaphore(_MAX_CONCURRENT_REQUESTS)

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create shared HTTP client with connection pooling."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=15.0,
                headers={
                    "User-Agent": "ChainReaper/0.1.0 (https://github.com/breachline/chainreaper)",
                    "Accept": "application/json",
                },
                follow_redirects=False,  # Prevent SSRF via redirects
            )
        return self._client

    async def close(self) -> None:
        """Close the shared HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def parse(self, target_path: Path) -> DependencyTree | None:
        """Parse Python dependency files to build dependency tree.

        Priority order:
        1. requirements.txt (most common, explicit)
        2. pyproject.toml [project.dependencies]
        3. setup.py / setup.cfg (legacy, detection only)
        """
        direct_deps: list[DependencyNode] = []
        root_name = target_path.name

        # Try requirements.txt first (primary source)
        req_path = target_path / "requirements.txt"
        if req_path.exists():
            if req_path.stat().st_size > _MAX_FILE_SIZE:
                logger.warning("requirements.txt exceeds 50MB, skipping: %s", req_path)
                return None
            direct_deps = self._parse_requirements_txt(req_path)

        # Try pyproject.toml if no deps from requirements.txt
        if not direct_deps:
            pyproject_path = target_path / "pyproject.toml"
            if pyproject_path.exists():
                if pyproject_path.stat().st_size > _MAX_FILE_SIZE:
                    logger.warning("pyproject.toml exceeds 50MB, skipping: %s", pyproject_path)
                    return None
                direct_deps, pyproject_name = self._parse_pyproject_toml(pyproject_path)
                if pyproject_name:
                    root_name = pyproject_name

        # Try setup.cfg for project name if we still have defaults
        if not direct_deps:
            setup_cfg_path = target_path / "setup.cfg"
            if setup_cfg_path.exists():
                if setup_cfg_path.stat().st_size > _MAX_FILE_SIZE:
                    logger.warning("setup.cfg exceeds 50MB, skipping: %s", setup_cfg_path)
                    return None
                direct_deps, cfg_name = self._parse_setup_cfg(setup_cfg_path)
                if cfg_name:
                    root_name = cfg_name

        # Detect setup.py existence (we don't parse it dynamically for safety)
        if not direct_deps:
            setup_py_path = target_path / "setup.py"
            if not setup_py_path.exists():
                return None
            # setup.py exists but we can't safely parse it; return empty tree
            logger.info(
                "setup.py detected but not parsed (dynamic execution risk): %s", setup_py_path
            )

        # Parse lockfiles for transitive dependencies
        transitive_deps: list[DependencyNode] = []
        direct_names = {d.name for d in direct_deps}

        for lockfile_name in self.lockfile_files:
            lockfile_path = target_path / lockfile_name
            if lockfile_path.exists():
                if lockfile_path.stat().st_size <= _MAX_FILE_SIZE:
                    transitive_deps = self._parse_lockfile(
                        lockfile_path, lockfile_name, direct_names
                    )
                    break  # Use first lockfile found
                else:
                    logger.warning("%s exceeds 50MB, skipping lockfile parsing", lockfile_name)

        return DependencyTree(
            ecosystem=EcosystemName.PYPI,
            root_package=root_name,
            direct_dependencies=direct_deps,
            transitive_dependencies=transitive_deps,
        )

    def _parse_requirements_txt(self, req_path: Path) -> list[DependencyNode]:
        """Parse requirements.txt format.

        Handles:
        - name==version (pinned)
        - name>=version (minimum)
        - name (unpinned)
        - name[extra]==version (extras)
        - -r other-file.txt (ignored, not followed for security)
        - # comments
        - blank lines
        """
        deps: list[DependencyNode] = []
        content = req_path.read_text(encoding="utf-8", errors="replace")

        for line in content.splitlines():
            line = line.strip()

            # Skip empty lines, comments, options, and -r/-c includes
            if not line or line.startswith("#") or line.startswith("-"):
                continue

            # Skip URLs (e.g., git+https://..., https://...)
            if "://" in line:
                logger.debug("Skipping URL dependency: %s", line[:100])
                continue

            # Remove inline comments
            if " #" in line:
                line = line[: line.index(" #")].strip()

            # Remove environment markers (everything after ;)
            if ";" in line:
                line = line[: line.index(";")].strip()

            match = _REQUIREMENTS_LINE_RE.match(line)
            if not match:
                continue

            name = match.group(1)
            version_part = match.group(4).strip() if match.group(4) else ""

            if not _validate_package_name(name):
                logger.warning("Skipping invalid PyPI package name: %s", name[:100])
                continue

            # Extract version from specifier
            version = ""
            if version_part:
                version_match = _VERSION_SPEC_RE.match(version_part)
                if version_match:
                    version = f"{version_match.group(1)}{version_match.group(2)}"

            deps.append(
                DependencyNode(
                    name=name,
                    version=version,
                    ecosystem=EcosystemName.PYPI,
                    is_direct=True,
                    source_registry=PYPI_REGISTRY,
                )
            )

        return deps

    def _parse_pyproject_toml(
        self, pyproject_path: Path
    ) -> tuple[list[DependencyNode], str | None]:
        """Parse pyproject.toml [project.dependencies] section.

        Returns (dependencies, project_name).
        """
        try:
            # Use tomllib (Python 3.11+) or tomli as fallback
            try:
                import tomllib
            except ImportError:
                import tomli as tomllib  # type: ignore[no-redef]

            content = pyproject_path.read_bytes()
            data = tomllib.loads(content.decode("utf-8"))
        except Exception as e:
            logger.warning("Failed to parse pyproject.toml: %s", e)
            return [], None

        project_name = None
        project = data.get("project", {})
        if isinstance(project, dict):
            project_name = project.get("name")

        deps: list[DependencyNode] = []
        raw_deps = project.get("dependencies", []) if isinstance(project, dict) else []

        if not isinstance(raw_deps, list):
            return deps, project_name

        for dep_str in raw_deps:
            if not isinstance(dep_str, str):
                continue
            dep_str = dep_str.strip()
            if not dep_str:
                continue

            # Remove environment markers
            if ";" in dep_str:
                dep_str = dep_str[: dep_str.index(";")].strip()

            match = _REQUIREMENTS_LINE_RE.match(dep_str)
            if not match:
                continue

            name = match.group(1)
            version_part = match.group(4).strip() if match.group(4) else ""

            if not _validate_package_name(name):
                logger.warning(
                    "Skipping invalid PyPI package name in pyproject.toml: %s", name[:100]
                )
                continue

            version = ""
            if version_part:
                version_match = _VERSION_SPEC_RE.match(version_part)
                if version_match:
                    version = f"{version_match.group(1)}{version_match.group(2)}"

            deps.append(
                DependencyNode(
                    name=name,
                    version=version,
                    ecosystem=EcosystemName.PYPI,
                    is_direct=True,
                    source_registry=PYPI_REGISTRY,
                )
            )

        return deps, project_name

    def _parse_setup_cfg(self, setup_cfg_path: Path) -> tuple[list[DependencyNode], str | None]:
        """Parse setup.cfg [options] install_requires section.

        Returns (dependencies, project_name).
        """
        import configparser

        config = configparser.ConfigParser()
        try:
            config.read(str(setup_cfg_path), encoding="utf-8")
        except Exception as e:
            logger.warning("Failed to parse setup.cfg: %s", e)
            return [], None

        project_name = config.get("metadata", "name", fallback=None)

        deps: list[DependencyNode] = []
        install_requires = config.get("options", "install_requires", fallback="")

        for line in install_requires.splitlines():
            line = line.strip()
            if not line:
                continue

            # Remove environment markers
            if ";" in line:
                line = line[: line.index(";")].strip()

            match = _REQUIREMENTS_LINE_RE.match(line)
            if not match:
                continue

            name = match.group(1)
            version_part = match.group(4).strip() if match.group(4) else ""

            if not _validate_package_name(name):
                continue

            version = ""
            if version_part:
                version_match = _VERSION_SPEC_RE.match(version_part)
                if version_match:
                    version = f"{version_match.group(1)}{version_match.group(2)}"

            deps.append(
                DependencyNode(
                    name=name,
                    version=version,
                    ecosystem=EcosystemName.PYPI,
                    is_direct=True,
                    source_registry=PYPI_REGISTRY,
                )
            )

        return deps, project_name

    def _parse_lockfile(
        self,
        lockfile_path: Path,
        lockfile_name: str,
        direct_names: set[str],
    ) -> list[DependencyNode]:
        """Parse lockfile for transitive dependencies.

        Supports:
        - poetry.lock (TOML format)
        - Pipfile.lock (JSON format)
        - requirements.lock (requirements.txt format)
        """
        if lockfile_name == "poetry.lock":
            return self._parse_poetry_lock(lockfile_path, direct_names)
        elif lockfile_name == "Pipfile.lock":
            return self._parse_pipfile_lock(lockfile_path, direct_names)
        elif lockfile_name == "requirements.lock":
            return self._parse_requirements_lock(lockfile_path, direct_names)
        return []

    def _parse_poetry_lock(
        self, lockfile_path: Path, direct_names: set[str]
    ) -> list[DependencyNode]:
        """Parse poetry.lock (TOML) for transitive dependencies."""
        try:
            try:
                import tomllib
            except ImportError:
                import tomli as tomllib  # type: ignore[no-redef]

            content = lockfile_path.read_bytes()
            data = tomllib.loads(content.decode("utf-8"))
        except Exception as e:
            logger.warning("Failed to parse poetry.lock: %s", e)
            return []

        transitive: list[DependencyNode] = []
        # Normalize direct names for comparison (PyPI normalizes to lowercase with hyphens)
        normalized_direct = {self._normalize_name(n) for n in direct_names}

        for package in data.get("package", []):
            name = package.get("name", "")
            if not _validate_package_name(name):
                continue
            if self._normalize_name(name) in normalized_direct:
                continue

            version = package.get("version", "")
            source_url = PYPI_REGISTRY

            # Validate source URL if present
            source = package.get("source", {})
            if isinstance(source, dict) and source.get("url"):
                source_url = self._validate_registry_url(source["url"], name)

            transitive.append(
                DependencyNode(
                    name=name,
                    version=version,
                    ecosystem=EcosystemName.PYPI,
                    is_direct=False,
                    source_registry=source_url,
                )
            )

        return transitive

    def _parse_pipfile_lock(
        self, lockfile_path: Path, direct_names: set[str]
    ) -> list[DependencyNode]:
        """Parse Pipfile.lock (JSON) for transitive dependencies."""
        import json

        try:
            content = lockfile_path.read_text(encoding="utf-8")
            data = json.loads(content)
        except Exception as e:
            logger.warning("Failed to parse Pipfile.lock: %s", e)
            return []

        transitive: list[DependencyNode] = []
        normalized_direct = {self._normalize_name(n) for n in direct_names}

        for section in ("default", "develop"):
            packages = data.get(section, {})
            if not isinstance(packages, dict):
                continue

            for name, info in packages.items():
                if not _validate_package_name(name):
                    continue
                if self._normalize_name(name) in normalized_direct:
                    continue

                version = ""
                if isinstance(info, dict):
                    raw_version = info.get("version", "")
                    # Pipfile.lock uses "==X.Y.Z" format
                    version = (
                        raw_version.lstrip("=") if raw_version.startswith("==") else raw_version
                    )

                    # Validate index URL if present
                    index = info.get("index")
                    if index:
                        # Pipfile.lock stores index name, not URL; use default
                        pass

                transitive.append(
                    DependencyNode(
                        name=name,
                        version=version,
                        ecosystem=EcosystemName.PYPI,
                        is_direct=False,
                        source_registry=PYPI_REGISTRY,
                        integrity_hash=info.get("hashes", [None])[0]
                        if isinstance(info, dict)
                        else None,
                    )
                )

        return transitive

    def _parse_requirements_lock(
        self, lockfile_path: Path, direct_names: set[str]
    ) -> list[DependencyNode]:
        """Parse requirements.lock (same format as requirements.txt) for transitive deps."""
        all_deps = self._parse_requirements_txt(lockfile_path)
        normalized_direct = {self._normalize_name(n) for n in direct_names}

        transitive: list[DependencyNode] = []
        for dep in all_deps:
            if self._normalize_name(dep.name) not in normalized_direct:
                dep.is_direct = False
                transitive.append(dep)

        return transitive

    @staticmethod
    def _normalize_name(name: str) -> str:
        """Normalize PyPI package name per PEP 503.

        Lowercases, replaces underscores/dots/hyphens with a single hyphen.
        """
        return re.sub(r"[-_.]+", "-", name).lower()

    def _validate_registry_url(self, url: str, package_name: str) -> str:
        """Validate a registry URL against allowed domains. SSRF protection."""
        try:
            from urllib.parse import urlparse

            parsed = urlparse(url)
            if parsed.hostname in _ALLOWED_REGISTRY_DOMAINS:
                return url
            else:
                logger.warning(
                    "Untrusted registry URL for %s: %s (using default)",
                    package_name,
                    parsed.hostname,
                )
        except Exception:
            pass
        return PYPI_REGISTRY

    async def get_package_metadata(self, name: str) -> PackageMetadata | None:
        """Fetch package metadata from the PyPI JSON API."""
        url = _safe_api_url(name)
        if not url:
            return None

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 404:
                    return None
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"PyPI rate limit hit for {name}")
                resp.raise_for_status()
                data = resp.json()
                return self._parse_pypi_metadata(data)
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to fetch PyPI metadata for %s: %s", name, e)
                return None

    async def check_name_available(self, name: str) -> bool:
        """Check if a package name is available on PyPI (404 = available)."""
        url = _safe_api_url(name)
        if not url:
            return False

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"PyPI rate limit hit for {name}")
                return resp.status_code == 404
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError:
                return False

    async def get_maintainer_info(self, package_name: str) -> list[MaintainerInfo]:
        """Get maintainer info from PyPI registry."""
        metadata = await self.get_package_metadata(package_name)
        if metadata:
            return metadata.maintainers
        return []

    def _parse_pypi_metadata(self, data: dict[str, Any]) -> PackageMetadata:
        """Parse PyPI JSON API response into PackageMetadata."""
        info = data.get("info", {})
        latest_version = info.get("version", "")

        # Extract maintainers — PyPI provides author and maintainer fields
        maintainers: list[MaintainerInfo] = []
        author = info.get("author")
        author_email = info.get("author_email")
        maintainer = info.get("maintainer")
        maintainer_email = info.get("maintainer_email")

        if maintainer:
            maintainers.append(
                MaintainerInfo(
                    username=maintainer,
                    email=maintainer_email,
                )
            )
        if author and author != maintainer:
            maintainers.append(
                MaintainerInfo(
                    username=author,
                    email=author_email,
                )
            )

        # Check for setup.py install hooks — PyPI packages with setup.py
        # can run arbitrary code during install
        has_install_scripts = False

        # Extract repository URL from project_urls
        repo_url = self._extract_repo_url(info)

        # Extract publish date from release data
        publish_date = None
        releases = data.get("releases", {})
        if latest_version and latest_version in releases:
            release_files = releases[latest_version]
            if release_files and isinstance(release_files, list) and len(release_files) > 0:
                upload_time = release_files[0].get("upload_time_iso_8601")
                if upload_time:
                    with contextlib.suppress(ValueError, TypeError):
                        publish_date = datetime.fromisoformat(upload_time.replace("Z", "+00:00"))

        return PackageMetadata(
            name=info.get("name", ""),
            version=latest_version,
            description=info.get("summary", ""),
            maintainers=maintainers,
            repository_url=repo_url,
            publish_date=publish_date,
            download_count=None,  # PyPI doesn't include this in JSON API
            has_install_scripts=has_install_scripts,
            license=info.get("license"),
        )

    def _extract_repo_url(self, info: dict[str, Any]) -> str | None:
        """Extract repository URL from PyPI metadata project_urls."""
        project_urls = info.get("project_urls") or {}
        if not isinstance(project_urls, dict):
            return None

        # Try common keys for source repository
        for key in ("Source", "Source Code", "Repository", "GitHub", "Homepage", "Code"):
            url = project_urls.get(key)
            if url and isinstance(url, str) and url.startswith(("https://", "http://")):
                return url

        # Fallback to home_page field
        home_page = info.get("home_page")
        if (
            home_page
            and isinstance(home_page, str)
            and home_page.startswith(("https://", "http://"))
        ):
            return home_page

        return None
