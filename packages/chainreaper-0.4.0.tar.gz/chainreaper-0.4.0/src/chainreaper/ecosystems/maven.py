"""Maven ecosystem plugin — pom.xml, build.gradle, build.gradle.kts."""

from __future__ import annotations

import asyncio
import logging
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import quote

import httpx

from chainreaper.core.constants import EcosystemName
from chainreaper.core.exceptions import RegistryRateLimitError
from chainreaper.core.models import DependencyNode, DependencyTree, MaintainerInfo, PackageMetadata
from chainreaper.ecosystems.base import BaseEcosystem, EcosystemRegistry

logger = logging.getLogger(__name__)

MAVEN_REGISTRY = "https://search.maven.org"
MAVEN_CENTRAL_API = "https://search.maven.org/solrsearch/select"

# Maven coordinate validation: groupId:artifactId
# groupId/artifactId segments: Java identifier rules (letters, digits, hyphens, underscores, dots)
_MAVEN_COORD_RE = re.compile(
    r"^[a-zA-Z0-9][a-zA-Z0-9._-]*(\.[a-zA-Z0-9][a-zA-Z0-9._-]*)+"
    r":"
    r"[a-zA-Z0-9][a-zA-Z0-9._-]*$"
)

# Gradle dependency pattern: 'groupId:artifactId:version' or "groupId:artifactId:version"
_GRADLE_DEP_RE = re.compile(
    r"""(?:implementation|api|compile|runtime|testImplementation|testCompile|"""
    r"""classpath|compileOnly|runtimeOnly|testRuntimeOnly|annotationProcessor)"""
    r"""\s*[\(\s]*['"]([a-zA-Z0-9._-]+):([a-zA-Z0-9._-]+):([^'"]+)['"]"""
)

# Gradle Kotlin DSL dependency pattern: implementation("groupId:artifactId:version")
_GRADLE_KTS_DEP_RE = re.compile(
    r"""(?:implementation|api|compile|runtime|testImplementation|testCompile|"""
    r"""classpath|compileOnly|runtimeOnly|testRuntimeOnly|annotationProcessor)"""
    r"""\s*\(\s*"([a-zA-Z0-9._-]+):([a-zA-Z0-9._-]+):([^"]+)"\s*\)"""
)

# POM XML namespace
_POM_NS = {"m": "http://maven.apache.org/POM/4.0.0"}

# Allowed registry domains for SSRF protection
_ALLOWED_REGISTRY_DOMAINS = {
    "search.maven.org",
    "repo1.maven.org",
    "repo.maven.apache.org",
    "central.sonatype.com",
}

# Rate limiting
_MAX_CONCURRENT_REQUESTS = 10
_REQUEST_DELAY_SECONDS = 0.1

# File size limit
_MAX_FILE_SIZE = 50_000_000  # 50MB


def _validate_maven_coordinate(coord: str) -> bool:
    """Validate a Maven coordinate in groupId:artifactId format."""
    if not coord or len(coord) > 500:
        return False
    return _MAVEN_COORD_RE.match(coord) is not None


def _validate_artifact_component(name: str) -> bool:
    """Validate a single groupId or artifactId component."""
    if not name or len(name) > 250:
        return False
    return re.match(r"^[a-zA-Z0-9][a-zA-Z0-9._-]*$", name) is not None


@EcosystemRegistry.register
class MavenEcosystem(BaseEcosystem):
    """Maven / Gradle package ecosystem plugin."""

    ecosystem_name = EcosystemName.MAVEN
    manifest_files = ["pom.xml", "build.gradle", "build.gradle.kts"]
    lockfile_files: list[str] = []
    registry_url = MAVEN_REGISTRY
    description = "Maven Central / Gradle (JVM) ecosystem"

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None
        self._semaphore = asyncio.Semaphore(_MAX_CONCURRENT_REQUESTS)

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create shared HTTP client with connection pooling."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=15.0,
                headers={
                    "User-Agent": "ChainReaper/0.1.0 (https://github.com/breachline/chainreaper)",
                    "Accept": "application/json",
                },
                follow_redirects=False,  # Prevent SSRF via redirects
            )
        return self._client

    async def close(self) -> None:
        """Close the shared HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def parse(self, target_path: Path) -> DependencyTree | None:
        """Parse Maven/Gradle manifest files to build dependency tree.

        Priority order:
        1. pom.xml (Maven — full XML parsing)
        2. build.gradle (Groovy DSL — regex extraction)
        3. build.gradle.kts (Kotlin DSL — regex extraction)
        """
        direct_deps: list[DependencyNode] = []
        root_name = target_path.name

        # Try pom.xml first (primary source)
        pom_path = target_path / "pom.xml"
        if pom_path.exists():
            if pom_path.stat().st_size > _MAX_FILE_SIZE:
                logger.warning("pom.xml exceeds 50MB, skipping: %s", pom_path)
                return None
            direct_deps, pom_name = self._parse_pom_xml(pom_path)
            if pom_name:
                root_name = pom_name

        # Try build.gradle if no deps from pom.xml
        if not direct_deps:
            gradle_path = target_path / "build.gradle"
            if gradle_path.exists():
                if gradle_path.stat().st_size > _MAX_FILE_SIZE:
                    logger.warning("build.gradle exceeds 50MB, skipping: %s", gradle_path)
                    return None
                direct_deps = self._parse_build_gradle(gradle_path, kotlin_dsl=False)

        # Try build.gradle.kts if still no deps
        if not direct_deps:
            gradle_kts_path = target_path / "build.gradle.kts"
            if gradle_kts_path.exists():
                if gradle_kts_path.stat().st_size > _MAX_FILE_SIZE:
                    logger.warning("build.gradle.kts exceeds 50MB, skipping: %s", gradle_kts_path)
                    return None
                direct_deps = self._parse_build_gradle(gradle_kts_path, kotlin_dsl=True)

        if not direct_deps:
            # Check if any manifest exists at all
            if not any((target_path / m).exists() for m in self.manifest_files):
                return None
            # Manifest exists but we couldn't extract deps
            logger.info(
                "Maven/Gradle manifest detected but no dependencies extracted in %s", target_path
            )

        return DependencyTree(
            ecosystem=EcosystemName.MAVEN,
            root_package=root_name,
            direct_dependencies=direct_deps,
            transitive_dependencies=[],
        )

    def _parse_pom_xml(self, pom_path: Path) -> tuple[list[DependencyNode], str | None]:
        """Parse pom.xml to extract dependencies using xml.etree.ElementTree.

        Returns (dependencies, project_name).
        """
        try:
            tree = ET.parse(pom_path)
        except ET.ParseError as e:
            logger.warning("Failed to parse pom.xml: %s", e)
            return [], None

        root = tree.getroot()

        # Detect namespace — pom.xml may or may not use the Maven namespace
        ns = ""
        if root.tag.startswith("{"):
            ns = root.tag.split("}")[0] + "}"

        # Extract project name (groupId:artifactId)
        project_name = None
        group_id_el = root.find(f"{ns}groupId")
        artifact_id_el = root.find(f"{ns}artifactId")
        if group_id_el is not None and artifact_id_el is not None:
            gid = (group_id_el.text or "").strip()
            aid = (artifact_id_el.text or "").strip()
            if gid and aid:
                project_name = f"{gid}:{aid}"

        # Extract properties for variable substitution
        properties: dict[str, str] = {}
        props_el = root.find(f"{ns}properties")
        if props_el is not None:
            for prop in props_el:
                tag = prop.tag.replace(ns, "")
                if prop.text:
                    properties[tag] = prop.text.strip()

        # Extract dependencies
        deps: list[DependencyNode] = []
        deps_el = root.find(f"{ns}dependencies")
        if deps_el is not None:
            for dep_el in deps_el.findall(f"{ns}dependency"):
                dep_group_el = dep_el.find(f"{ns}groupId")
                dep_artifact_el = dep_el.find(f"{ns}artifactId")
                dep_version_el = dep_el.find(f"{ns}version")

                if dep_group_el is None or dep_artifact_el is None:
                    continue

                dep_gid = (dep_group_el.text or "").strip()
                dep_aid = (dep_artifact_el.text or "").strip()
                dep_version = (
                    (dep_version_el.text or "").strip() if dep_version_el is not None else ""
                )

                if not dep_gid or not dep_aid:
                    continue

                # Resolve property placeholders like ${spring.version}
                dep_version = self._resolve_properties(dep_version, properties)

                if not _validate_artifact_component(dep_gid) or not _validate_artifact_component(
                    dep_aid
                ):
                    logger.warning(
                        "Skipping invalid Maven dependency: %s:%s",
                        dep_gid[:100],
                        dep_aid[:100],
                    )
                    continue

                coord = f"{dep_gid}:{dep_aid}"

                # Detect scope
                scope_el = dep_el.find(f"{ns}scope")
                (scope_el.text or "").strip() if scope_el is not None else "compile"

                deps.append(
                    DependencyNode(
                        name=coord,
                        version=dep_version,
                        ecosystem=EcosystemName.MAVEN,
                        is_direct=True,
                        source_registry=MAVEN_REGISTRY,
                    )
                )

        # Also check dependencyManagement section
        dep_mgmt = root.find(f"{ns}dependencyManagement")
        if dep_mgmt is not None:
            mgmt_deps_el = dep_mgmt.find(f"{ns}dependencies")
            if mgmt_deps_el is not None:
                for dep_el in mgmt_deps_el.findall(f"{ns}dependency"):
                    dep_group_el = dep_el.find(f"{ns}groupId")
                    dep_artifact_el = dep_el.find(f"{ns}artifactId")
                    dep_version_el = dep_el.find(f"{ns}version")

                    if dep_group_el is None or dep_artifact_el is None:
                        continue

                    dep_gid = (dep_group_el.text or "").strip()
                    dep_aid = (dep_artifact_el.text or "").strip()
                    dep_version = (
                        (dep_version_el.text or "").strip() if dep_version_el is not None else ""
                    )

                    if not dep_gid or not dep_aid:
                        continue

                    dep_version = self._resolve_properties(dep_version, properties)

                    if not _validate_artifact_component(
                        dep_gid
                    ) or not _validate_artifact_component(dep_aid):
                        continue

                    coord = f"{dep_gid}:{dep_aid}"

                    # Skip if already present from direct dependencies
                    if any(d.name == coord for d in deps):
                        continue

                    deps.append(
                        DependencyNode(
                            name=coord,
                            version=dep_version,
                            ecosystem=EcosystemName.MAVEN,
                            is_direct=True,
                            source_registry=MAVEN_REGISTRY,
                        )
                    )

        return deps, project_name

    @staticmethod
    def _resolve_properties(value: str, properties: dict[str, str]) -> str:
        """Resolve Maven property placeholders like ${property.name}."""
        if not value or "${" not in value:
            return value

        def _replace(match: re.Match) -> str:
            prop_name = match.group(1)
            return properties.get(prop_name, match.group(0))

        # Resolve up to 5 levels of nesting to prevent infinite loops
        for _ in range(5):
            resolved = re.sub(r"\$\{([^}]+)\}", _replace, value)
            if resolved == value:
                break
            value = resolved

        return value

    def _parse_build_gradle(
        self, gradle_path: Path, *, kotlin_dsl: bool = False
    ) -> list[DependencyNode]:
        """Parse build.gradle or build.gradle.kts using regex extraction.

        This is best-effort — Gradle files are Groovy/Kotlin scripts and
        can contain arbitrary logic. We extract common dependency patterns.
        """
        content = gradle_path.read_text(encoding="utf-8", errors="replace")
        deps: list[DependencyNode] = []
        seen: set[str] = set()

        # Use appropriate regex for Groovy vs Kotlin DSL
        patterns = [_GRADLE_DEP_RE]
        if kotlin_dsl:
            patterns.append(_GRADLE_KTS_DEP_RE)

        for pattern in patterns:
            for match in pattern.finditer(content):
                group_id = match.group(1).strip()
                artifact_id = match.group(2).strip()
                version = match.group(3).strip()

                if not _validate_artifact_component(group_id) or not _validate_artifact_component(
                    artifact_id
                ):
                    continue

                coord = f"{group_id}:{artifact_id}"
                if coord in seen:
                    continue
                seen.add(coord)

                deps.append(
                    DependencyNode(
                        name=coord,
                        version=version,
                        ecosystem=EcosystemName.MAVEN,
                        is_direct=True,
                        source_registry=MAVEN_REGISTRY,
                    )
                )

        return deps

    async def check_name_available(self, name: str) -> bool:
        """Check if a Maven coordinate is available on Maven Central.

        Args:
            name: Maven coordinate in groupId:artifactId format.

        Returns:
            True if the coordinate is not registered (available for takeover).
        """
        if not _validate_maven_coordinate(name):
            logger.warning("Invalid Maven coordinate for availability check: %s", name[:100])
            return False

        parts = name.split(":", 1)
        if len(parts) != 2:
            return False

        group_id, artifact_id = parts

        # URL-encode for safety
        encoded_gid = quote(group_id, safe="")
        encoded_aid = quote(artifact_id, safe="")
        url = f"{MAVEN_CENTRAL_API}?q=g:{encoded_gid}+AND+a:{encoded_aid}&rows=1&wt=json"

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"Maven Central rate limit hit for {name}")
                resp.raise_for_status()
                data = resp.json()

                # If numFound == 0, the coordinate is available
                num_found = data.get("response", {}).get("numFound", 0)
                return num_found == 0
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to check Maven Central for %s: %s", name, e)
                return False

    async def get_package_metadata(self, name: str) -> PackageMetadata | None:
        """Fetch package metadata from Maven Central."""
        if not _validate_maven_coordinate(name):
            return None

        parts = name.split(":", 1)
        if len(parts) != 2:
            return None

        group_id, artifact_id = parts
        encoded_gid = quote(group_id, safe="")
        encoded_aid = quote(artifact_id, safe="")
        url = f"{MAVEN_CENTRAL_API}?q=g:{encoded_gid}+AND+a:{encoded_aid}&rows=1&wt=json"

        async with self._semaphore:
            await asyncio.sleep(_REQUEST_DELAY_SECONDS)
            try:
                client = await self._get_client()
                resp = await client.get(url)
                if resp.status_code == 404:
                    return None
                if resp.status_code == 429:
                    raise RegistryRateLimitError(f"Maven Central rate limit hit for {name}")
                resp.raise_for_status()
                data = resp.json()

                docs = data.get("response", {}).get("docs", [])
                if not docs:
                    return None

                doc = docs[0]
                return PackageMetadata(
                    name=name,
                    version=doc.get("latestVersion", ""),
                    description="",
                    maintainers=[],
                    repository_url=None,
                    publish_date=None,
                    has_install_scripts=False,
                    license=None,
                )
            except RegistryRateLimitError:
                raise
            except httpx.HTTPError as e:
                logger.warning("Failed to fetch Maven metadata for %s: %s", name, e)
                return None

    async def get_maintainer_info(self, package_name: str) -> list[MaintainerInfo]:
        """Get maintainer info — Maven Central doesn't expose this easily."""
        return []
