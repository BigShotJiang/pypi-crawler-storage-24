"""Policy engine for evaluating scan findings against configurable rules."""

from __future__ import annotations

from fnmatch import fnmatch
from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import BaseModel, Field

from chainreaper.core.constants import AttackVector, EcosystemName, Severity
from chainreaper.core.models import Finding

# Severity ordering: lower number = more severe
_SEVERITY_ORDER: dict[Severity, int] = {
    Severity.CRITICAL: 0,
    Severity.HIGH: 1,
    Severity.MEDIUM: 2,
    Severity.LOW: 3,
    Severity.INFO: 4,
}


class PolicyRule(BaseModel):
    """A single policy rule that matches findings by criteria (AND logic)."""

    name: str = Field(description="Human-readable rule name")
    severity: Optional[list[Severity]] = Field(default=None, description="Match by severity levels")
    attack_vectors: Optional[list[AttackVector]] = Field(
        default=None, description="Match by attack vectors"
    )
    ecosystems: Optional[list[EcosystemName]] = Field(
        default=None, description="Match by ecosystem"
    )
    packages: Optional[list[str]] = Field(
        default=None, description="Match by package name (glob patterns)"
    )
    cve_ids: Optional[list[str]] = Field(default=None, description="Match specific CVE IDs")
    min_confidence: Optional[float] = Field(default=None, description="Minimum confidence to match")
    max_confidence: Optional[float] = Field(default=None, description="Maximum confidence to match")


class PolicyDecision(BaseModel):
    """Decision for a single finding after policy evaluation."""

    finding_id: str
    action: str = Field(description="One of: block, allow, warn, default")
    matched_rule: Optional[str] = Field(default=None, description="Name of the rule that matched")


class PolicyResult(BaseModel):
    """Result of evaluating all findings against the policy."""

    decisions: list[PolicyDecision] = Field(
        default_factory=list, description="Per-finding decisions"
    )
    should_fail: bool = Field(default=False, description="Whether the scan should exit non-zero")
    blocked: list[Finding] = Field(default_factory=list, description="Findings that cause failure")
    allowed: list[Finding] = Field(default_factory=list, description="Acknowledged findings")
    warnings: list[Finding] = Field(default_factory=list, description="Downgraded findings")


class PolicyConfig(BaseModel):
    """Policy configuration with block/allow/warn rules."""

    fail_on: Severity = Field(
        default=Severity.HIGH,
        description="Minimum severity to fail the scan",
    )
    block_rules: list[PolicyRule] = Field(
        default_factory=list, description="Rules that cause scan to fail"
    )
    allow_rules: list[PolicyRule] = Field(
        default_factory=list, description="Rules that acknowledge findings"
    )
    warn_rules: list[PolicyRule] = Field(
        default_factory=list, description="Rules that downgrade to warnings"
    )

    @classmethod
    def from_yaml(cls, path: Path) -> PolicyConfig:
        """Load policy configuration from a YAML file."""
        with open(path) as f:
            data: dict[str, Any] = yaml.safe_load(f) or {}
        return cls(**data)


def _matches_rule(finding: Finding, rule: PolicyRule) -> bool:
    """Check if a finding matches all specified criteria in a rule (AND logic).

    Only criteria that are not None are checked. If all specified criteria
    match, the rule matches. A rule with no criteria matches everything.
    """
    if rule.severity is not None and finding.severity not in rule.severity:
        return False
    if rule.attack_vectors is not None and finding.attack_vector not in rule.attack_vectors:
        return False
    if rule.ecosystems is not None and finding.ecosystem not in rule.ecosystems:
        return False
    if rule.packages is not None and not any(
        fnmatch(finding.package_name, pat) for pat in rule.packages
    ):
        return False
    if rule.cve_ids is not None and not any(cve in rule.cve_ids for cve in finding.cve_ids):
        return False
    if rule.min_confidence is not None and finding.confidence < rule.min_confidence:
        return False
    return not (rule.max_confidence is not None and finding.confidence > rule.max_confidence)


class PolicyEngine:
    """Evaluates findings against a policy configuration.

    Rules are applied in order: block_rules first, then allow_rules,
    then warn_rules. The first matching rule determines the action.
    Findings that match no rule get a default action based on fail_on
    severity threshold.
    """

    def __init__(self, policy: PolicyConfig) -> None:
        self.policy = policy

    def evaluate(self, findings: list[Finding]) -> PolicyResult:
        """Evaluate all findings against the policy and return decisions."""
        decisions: list[PolicyDecision] = []
        blocked: list[Finding] = []
        allowed: list[Finding] = []
        warnings: list[Finding] = []

        fail_threshold = _SEVERITY_ORDER.get(self.policy.fail_on, 1)

        for finding in findings:
            decision = self._evaluate_finding(finding, fail_threshold)
            decisions.append(decision)

            if decision.action == "block":
                blocked.append(finding)
            elif decision.action == "allow":
                allowed.append(finding)
            elif decision.action == "warn":
                warnings.append(finding)
            elif decision.action == "default":
                # Default findings at or above fail_on threshold count
                # as blocked
                finding_severity = _SEVERITY_ORDER.get(finding.severity, 5)
                if finding_severity <= fail_threshold:
                    blocked.append(finding)

        return PolicyResult(
            decisions=decisions,
            should_fail=len(blocked) > 0,
            blocked=blocked,
            allowed=allowed,
            warnings=warnings,
        )

    def _evaluate_finding(self, finding: Finding, fail_threshold: int) -> PolicyDecision:
        """Evaluate a single finding against all rules in priority order."""
        # Block rules first
        for rule in self.policy.block_rules:
            if _matches_rule(finding, rule):
                return PolicyDecision(
                    finding_id=finding.id,
                    action="block",
                    matched_rule=rule.name,
                )

        # Allow rules second
        for rule in self.policy.allow_rules:
            if _matches_rule(finding, rule):
                return PolicyDecision(
                    finding_id=finding.id,
                    action="allow",
                    matched_rule=rule.name,
                )

        # Warn rules third
        for rule in self.policy.warn_rules:
            if _matches_rule(finding, rule):
                return PolicyDecision(
                    finding_id=finding.id,
                    action="warn",
                    matched_rule=rule.name,
                )

        # No rule matched — default action
        return PolicyDecision(
            finding_id=finding.id,
            action="default",
            matched_rule=None,
        )
