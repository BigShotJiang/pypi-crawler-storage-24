"""Core data models for ChainReaper. All models use Pydantic v2."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Optional
from uuid import uuid4

from pydantic import BaseModel, Field

from chainreaper.core.constants import (
    AttackVector,
    EcosystemName,
    EdgeType,
    NodeType,
    OutputFormat,
    Severity,
    TargetType,
)

# ── Scan Target ──────────────────────────────────────────────


class ScanTarget(BaseModel):
    """What to scan."""

    target_type: TargetType
    value: str
    ecosystems: list[EcosystemName] = []


# ── Dependency Tree ──────────────────────────────────────────


class DependencyNode(BaseModel):
    """Single dependency in the tree."""

    name: str
    version: str
    ecosystem: EcosystemName
    is_direct: bool = True
    source_registry: str = ""
    integrity_hash: Optional[str] = None
    children: list[DependencyNode] = []


class DependencyTree(BaseModel):
    """Full dependency tree for one ecosystem."""

    ecosystem: EcosystemName
    root_package: str
    direct_dependencies: list[DependencyNode] = []
    transitive_dependencies: list[DependencyNode] = []

    @property
    def total_count(self) -> int:
        return len(self.direct_dependencies) + len(self.transitive_dependencies)


# ── Package Metadata ─────────────────────────────────────────


class MaintainerInfo(BaseModel):
    """Maintainer trust signals."""

    username: str
    email: Optional[str] = None
    package_count: int = 0
    account_age_days: Optional[int] = None
    has_2fa: Optional[bool] = None


class PackageMetadata(BaseModel):
    """Metadata from a package registry."""

    name: str
    version: str
    description: str = ""
    maintainers: list[MaintainerInfo] = []
    repository_url: Optional[str] = None
    publish_date: Optional[datetime] = None
    download_count: Optional[int] = None
    has_install_scripts: bool = False
    license: Optional[str] = None


# ── Findings ─────────────────────────────────────────────────


class Evidence(BaseModel):
    """Proof supporting a finding."""

    description: str
    raw_data: dict[str, Any] = {}
    api_responses: list[dict[str, Any]] = []


class Finding(BaseModel):
    """A discovered supply chain security issue."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    title: str
    description: str
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    attack_vector: AttackVector
    ecosystem: EcosystemName
    package_name: str
    package_version: Optional[str] = None
    evidence: Evidence
    exploitation_path: Optional[str] = None
    remediation: str = ""
    references: list[str] = []
    cwe_ids: list[str] = []
    cve_ids: list[str] = []
    cvss_score: Optional[float] = None
    slsa_threat: Optional[str] = None
    openssf_scorecard: Optional[float] = None
    # Package info — populated by analyzers from registry data
    package_url: Optional[str] = None
    package_registry_url: Optional[str] = None
    package_description: Optional[str] = None
    package_license: Optional[str] = None
    package_maintainers: list[str] = []
    package_repository_url: Optional[str] = None


# ── Attack Graph ─────────────────────────────────────────────


class AttackGraphNode(BaseModel):
    """Node in the attack graph."""

    id: str
    label: str
    node_type: NodeType
    severity: Optional[Severity] = None
    metadata: dict[str, Any] = {}


class AttackGraphEdge(BaseModel):
    """Edge in the attack graph."""

    source: str
    target: str
    label: str
    edge_type: EdgeType


class AttackPath(BaseModel):
    """Ordered sequence of nodes forming a complete attack path."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    description: str
    severity: Severity
    likelihood: float = Field(ge=0.0, le=1.0)
    node_ids: list[str] = []
    edge_ids: list[str] = []


class AttackGraph(BaseModel):
    """Complete attack graph."""

    nodes: list[AttackGraphNode] = []
    edges: list[AttackGraphEdge] = []
    paths: list[AttackPath] = []


# ── Scan Result ──────────────────────────────────────────────


class ScanSummary(BaseModel):
    """Summary statistics for a scan."""

    total_findings: int = 0
    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0
    info: int = 0
    ecosystems_scanned: list[EcosystemName] = []
    total_dependencies: int = 0
    attack_paths_found: int = 0

    @classmethod
    def from_findings(cls, findings: list[Finding], trees: list[DependencyTree]) -> ScanSummary:
        severity_counts = {s: 0 for s in Severity}
        for f in findings:
            severity_counts[f.severity] += 1
        return cls(
            total_findings=len(findings),
            critical=severity_counts[Severity.CRITICAL],
            high=severity_counts[Severity.HIGH],
            medium=severity_counts[Severity.MEDIUM],
            low=severity_counts[Severity.LOW],
            info=severity_counts[Severity.INFO],
            ecosystems_scanned=[t.ecosystem for t in trees],
            total_dependencies=sum(t.total_count for t in trees),
        )


class AnalyzerRunInfo(BaseModel):
    """Record of one analyzer's execution."""

    name: str
    status: str = "pending"
    findings_count: int = 0
    error: Optional[str] = None


class ScanMetadata(BaseModel):
    """Metadata about the scan execution."""

    scan_id: str = Field(default_factory=lambda: str(uuid4()))
    started_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    completed_at: Optional[datetime] = None
    chainreaper_version: str = ""
    llm_model: str = ""
    llm_cost_usd: float = 0.0
    llm_input_tokens: int = 0
    llm_output_tokens: int = 0
    analyzer_runs: list[AnalyzerRunInfo] = []
    pre_verification_count: int = 0
    post_verification_count: int = 0


class ScanResult(BaseModel):
    """Complete scan output."""

    target: ScanTarget
    findings: list[Finding] = []
    dependency_trees: list[DependencyTree] = []
    attack_graph: AttackGraph = Field(default_factory=AttackGraph)
    summary: ScanSummary = Field(default_factory=ScanSummary)
    metadata: ScanMetadata = Field(default_factory=ScanMetadata)
    output_formats: list[OutputFormat] = [OutputFormat.JSON]


# ── Agent State ──────────────────────────────────────────────


class AgentThought(BaseModel):
    """A single reasoning step from the ReAct loop."""

    thought: str
    action: Optional[str] = None
    action_params: dict[str, Any] = {}
    observation: Optional[str] = None


class AnalysisContext(BaseModel):
    """Context passed to analyzers."""

    target: ScanTarget
    dependency_trees: list[DependencyTree] = []
    findings_so_far: list[Finding] = []
    thoughts: list[AgentThought] = []
    iteration: int = 0
    max_iterations: int = 20
