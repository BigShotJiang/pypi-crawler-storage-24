"""Configuration management using Pydantic Settings + YAML."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from chainreaper.core.constants import AttackVector, OutputFormat, Severity
from chainreaper.core.policy import PolicyConfig

CONFIG_FILENAME = ".chainreaper.yml"
DEFAULT_COST_LIMIT = 5.0
DEFAULT_MAX_ITERATIONS = 20
DEFAULT_MIN_CONFIDENCE = 0.5


class LLMProviderConfig(BaseModel):
    """Configuration for a single LLM provider in the chain."""

    model: str = "gemini/gemini-2.5-flash"
    temperature: float = 0.1
    max_tokens: int = 65536


class LLMConfig(BaseModel):
    """LLM router configuration."""

    provider_chain: list[LLMProviderConfig] = Field(default_factory=lambda: [LLMProviderConfig()])
    fallback_on_error: bool = True
    cost_limit_usd: float = DEFAULT_COST_LIMIT
    cache_responses: bool = True


class ScanConfig(BaseModel):
    """Scan behavior configuration."""

    attack_vectors: list[AttackVector] = Field(default_factory=lambda: list(AttackVector))
    ecosystems: list[str] = Field(default_factory=list)
    max_iterations: int = DEFAULT_MAX_ITERATIONS
    min_confidence: float = DEFAULT_MIN_CONFIDENCE


class OutputConfig(BaseModel):
    """Output configuration."""

    formats: list[OutputFormat] = Field(default_factory=lambda: [OutputFormat.JSON])
    directory: str = "./chainreaper-results"
    include_attack_graph: bool = True
    include_evidence: bool = True


class CIConfig(BaseModel):
    """CI mode configuration."""

    fail_on: Severity = Severity.HIGH
    sarif_upload: bool = True


class RegistryConfig(BaseModel):
    """Package registry configuration."""

    url: str
    token: Optional[str] = Field(default=None, exclude=True)  # Never serialize tokens


class IgnoreConfig(BaseModel):
    """Ignore rules."""

    packages: list[str] = Field(default_factory=list)
    cve_ids: list[str] = Field(default_factory=list)
    paths: list[str] = Field(default_factory=list)


class ChainReaperConfig(BaseSettings):
    """Root configuration for ChainReaper."""

    model_config = SettingsConfigDict(
        env_prefix="CHAINREAPER_",
        env_nested_delimiter="__",
    )

    llm: LLMConfig = Field(default_factory=LLMConfig)
    scan: ScanConfig = Field(default_factory=ScanConfig)
    output: OutputConfig = Field(default_factory=OutputConfig)
    ci: CIConfig = Field(default_factory=CIConfig)
    registries: dict[str, RegistryConfig] = Field(default_factory=dict)
    ignore: IgnoreConfig = Field(default_factory=IgnoreConfig)
    policy: PolicyConfig = Field(default_factory=PolicyConfig)

    @classmethod
    def load(cls, config_path: Optional[Path] = None) -> ChainReaperConfig:
        """Load config from YAML file, falling back to defaults."""
        data: dict[str, Any] = {}

        if config_path is None:
            config_path = _find_config_file()

        if config_path and config_path.exists():
            with open(config_path) as f:
                data = yaml.safe_load(f) or {}

        return cls(**data)

    def to_yaml(self) -> str:
        """Serialize config to YAML string."""
        result: str = yaml.dump(
            self.model_dump(mode="json", exclude_defaults=True),
            default_flow_style=False,
            sort_keys=False,
        )
        return result


def _find_config_file() -> Optional[Path]:
    """Walk up from CWD looking for .chainreaper.yml."""
    current = Path.cwd()
    for parent in [current, *current.parents]:
        candidate = parent / CONFIG_FILENAME
        if candidate.exists():
            return candidate
    return None
