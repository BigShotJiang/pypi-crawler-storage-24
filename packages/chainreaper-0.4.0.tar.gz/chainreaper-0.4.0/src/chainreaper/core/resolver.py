"""Target resolver — handles URLs, package names, and registry lookups."""

from __future__ import annotations

import logging
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import urlparse

import httpx

logger = logging.getLogger(__name__)

# Git hosting patterns
_GIT_HOSTS = {"github.com", "gitlab.com", "bitbucket.org", "codeberg.org"}

# Registry URL patterns -> (ecosystem, package_name)
_REGISTRY_PATTERNS = [
    (re.compile(r"https?://(?:www\.)?npmjs\.com/package/(.+)"), "npm"),
    (re.compile(r"https?://pypi\.org/project/([^/]+)"), "pypi"),
    (re.compile(r"https?://crates\.io/crates/([^/]+)"), "cargo"),
    (re.compile(r"https?://rubygems\.org/gems/([^/]+)"), "rubygems"),
    (re.compile(r"https?://(?:www\.)?nuget\.org/packages/([^/]+)"), "nuget"),
    (re.compile(r"https?://pkg\.go\.dev/(.+)"), "go"),
    (re.compile(r"https?://search\.maven\.org/artifact/([^/]+)/([^/]+)"), "maven"),
]

# Simple package name patterns (no slashes, no URLs)
_SIMPLE_PKG_NAME = re.compile(r"^[a-zA-Z0-9@._\-/]+$")

# Version separators: express@4.21.0, flask==2.0, serde:1.0
_VERSION_SPLIT_RE = re.compile(r"^(@?[a-zA-Z0-9._\-/]+?)(?:@|==|>=|<=|~=|:)(.+)$")


class ResolvedTarget:
    """Result of resolving a target string."""

    def __init__(
        self,
        path: Path,
        source: str,
        cleanup: bool = False,
        package_name: str | None = None,
        ecosystem: str | None = None,
    ) -> None:
        self.path = path
        self.source = source  # "local", "git", "registry", "package"
        self.cleanup = cleanup  # True if we created a temp dir that needs cleanup
        self.package_name = package_name
        self.ecosystem = ecosystem

    def __del__(self) -> None:
        if self.cleanup and self.path.exists():
            shutil.rmtree(self.path, ignore_errors=True)


async def resolve_target(value: str) -> ResolvedTarget:
    """Resolve a target string to a local path.

    Supports:
    - Local paths: ./my-project, /abs/path
    - Git URLs: https://github.com/org/repo, git@github.com:org/repo.git
    - Registry URLs: https://www.npmjs.com/package/express, https://pypi.org/project/flask
    - Package names: express, flask, serde (auto-detects ecosystem)
    """
    value = value.strip()

    # 1. Check if it's a local path
    local = Path(value)
    if local.exists():
        return ResolvedTarget(path=local.resolve(), source="local")

    # 2. Check if it's a registry URL (npmjs.com, pypi.org, etc.)
    for pattern, ecosystem in _REGISTRY_PATTERNS:
        match = pattern.match(value)
        if match:
            pkg_name = match.group(1)
            logger.info("Registry URL detected: %s package '%s'", ecosystem, pkg_name)
            return await _resolve_package_name(pkg_name, ecosystem)

    # 3. Check if it's a git URL
    if _is_git_url(value):
        logger.info("Git URL detected: %s", value)
        return await _clone_repo(value)

    # 4. Assume it's a package name (possibly with version: express@4.21.0, flask==2.0)
    if _SIMPLE_PKG_NAME.match(value) and not value.startswith("."):
        # Parse name@version, name==version, etc.
        pkg_name, pkg_version = _split_name_version(value)
        logger.info("Package name detected: %s", value)
        return await _resolve_package_name(pkg_name, version=pkg_version)

    # 5. Fallback — treat as local path (will fail with clear error)
    return ResolvedTarget(path=Path(value).resolve(), source="local")


def _split_name_version(value: str) -> tuple[str, str | None]:
    """Split 'express@4.21.0' or 'flask==2.0' into (name, version).

    Handles scoped npm packages: '@scope/pkg@1.0' → ('@scope/pkg', '1.0')
    """
    match = _VERSION_SPLIT_RE.match(value)
    if match:
        name, version = match.group(1), match.group(2)
        # Sanity check: version should look like a version, not a scope
        if version and version[0].isdigit():
            return name, version
    return value, None


def _is_git_url(value: str) -> bool:
    """Check if value looks like a git URL."""
    if value.startswith("git@"):
        return True
    if value.startswith(("http://", "https://")):
        parsed = urlparse(value)
        if parsed.hostname in _GIT_HOSTS:
            return True
        if value.endswith(".git"):
            return True
    return False


async def _clone_repo(url: str) -> ResolvedTarget:
    """Shallow clone a git repository to a temp directory."""
    # Validate URL for SSRF
    if url.startswith(("http://", "https://")):
        parsed = urlparse(url)
        if parsed.hostname and parsed.hostname not in _GIT_HOSTS:
            # Allow but warn for unknown hosts
            logger.warning("Cloning from non-standard host: %s", parsed.hostname)

    tmp_dir = Path(tempfile.mkdtemp(prefix="chainreaper-"))
    clone_path = tmp_dir / "repo"

    logger.info("Cloning %s -> %s", url, clone_path)

    try:
        result = subprocess.run(
            ["git", "clone", "--depth", "1", "--single-branch", url, str(clone_path)],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            shutil.rmtree(tmp_dir, ignore_errors=True)
            raise RuntimeError(f"git clone failed: {result.stderr.strip()}")

        logger.info("Cloned successfully to %s", clone_path)
        return ResolvedTarget(path=clone_path, source="git", cleanup=True)

    except subprocess.TimeoutExpired as e:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        raise RuntimeError(f"git clone timed out after 120s: {url}") from e
    except FileNotFoundError as e:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        raise RuntimeError("git is not installed. Install git to scan repository URLs.") from e


async def _resolve_package_name(
    name: str, ecosystem: str | None = None, version: str | None = None
) -> ResolvedTarget:
    """Fetch package metadata and create a minimal project for scanning."""
    tmp_dir = Path(tempfile.mkdtemp(prefix="chainreaper-pkg-"))

    if ecosystem is None:
        ecosystem = _guess_ecosystem(name)

    logger.info("Resolving package '%s' (version=%s) from %s", name, version or "latest", ecosystem)

    if ecosystem == "npm":
        await _create_npm_project(tmp_dir, name, version)
    elif ecosystem == "pypi":
        await _create_pypi_project(tmp_dir, name, version)
    elif ecosystem == "cargo":
        await _create_cargo_project(tmp_dir, name, version)
    elif ecosystem == "rubygems":
        await _create_rubygems_project(tmp_dir, name, version)
    elif ecosystem == "go":
        await _create_go_project(tmp_dir, name, version)
    elif ecosystem == "maven":
        await _create_maven_project(tmp_dir, name, version)
    elif ecosystem == "nuget":
        await _create_nuget_project(tmp_dir, name, version)
    else:
        await _create_npm_project(tmp_dir, name, version)

    return ResolvedTarget(
        path=tmp_dir,
        source="package",
        cleanup=True,
        package_name=name,
        ecosystem=ecosystem,
    )


def _guess_ecosystem(name: str) -> str:
    """Guess ecosystem from package name patterns."""
    if name.startswith("@") or ("-" in name and name.islower()):
        return "npm"
    if "." in name and "/" in name:  # github.com/org/repo pattern
        return "go"
    if name[0].isupper():  # NuGet packages are PascalCase
        return "nuget"
    # Default to npm (most common)
    return "npm"


async def _fetch_npm_metadata(name: str, version: str | None = None) -> dict | None:
    """Fetch package metadata from npm registry.

    If version is specified, fetches that exact version's metadata.
    Otherwise, fetches the latest version.
    """
    from urllib.parse import quote

    encoded = quote(name, safe="@")
    async with httpx.AsyncClient(timeout=15, follow_redirects=False) as client:
        if version:
            # Try exact version first
            resp = await client.get(f"https://registry.npmjs.org/{encoded}/{version}")
            if resp.status_code == 200:
                return resp.json()
        # Fall back to latest
        resp = await client.get(f"https://registry.npmjs.org/{encoded}/latest")
        if resp.status_code == 200:
            return resp.json()
    return None


async def _fetch_npm_full_metadata(name: str) -> dict | None:
    """Fetch FULL package doc from npm (all versions, maintainers, etc.)."""
    from urllib.parse import quote

    encoded = quote(name, safe="@")
    async with httpx.AsyncClient(timeout=15, follow_redirects=False) as client:
        resp = await client.get(f"https://registry.npmjs.org/{encoded}")
        if resp.status_code == 200:
            return resp.json()
    return None


async def _create_npm_project(tmp_dir: Path, name: str, version: str | None = None) -> None:
    """Create a minimal npm project with the given package as dependency.

    Fetches the package's own dependencies from npm registry so the dependency
    tree is populated for deep scanning of the entire supply chain.
    """
    import json

    metadata = await _fetch_npm_metadata(name, version)
    resolved_version = version or (metadata.get("version") if metadata else "latest")
    deps: dict[str, str] = {}

    if metadata:
        # Include the package's own dependencies — this is what we're scanning
        for dep_name, dep_spec in metadata.get("dependencies", {}).items():
            deps[dep_name] = dep_spec

    # Add the target package itself as a dependency
    deps[name] = resolved_version or "latest"

    # Safe project name (no @ in project name)
    safe_name = name.replace("@", "").replace("/", "-")

    package_json: dict = {
        "name": f"chainreaper-scan-{safe_name}",
        "version": "0.0.0",
        "private": True,
        "dependencies": deps,
    }
    (tmp_dir / "package.json").write_text(json.dumps(package_json, indent=2))


async def _create_pypi_project(tmp_dir: Path, name: str, version: str | None = None) -> None:
    """Create a minimal Python project with the given package."""
    spec = f"{name}=={version}" if version else name
    (tmp_dir / "requirements.txt").write_text(f"{spec}\n")


async def _create_cargo_project(tmp_dir: Path, name: str, version: str | None = None) -> None:
    """Create a minimal Cargo.toml."""
    ver = f'"{version}"' if version else '"*"'
    content = f'[package]\nname = "chainreaper-scan"\nversion = "0.0.0"\n\n[dependencies]\n{name} = {ver}\n'
    (tmp_dir / "Cargo.toml").write_text(content)


async def _create_rubygems_project(tmp_dir: Path, name: str, version: str | None = None) -> None:
    """Create a minimal Gemfile."""
    gem_line = f'gem "{name}", "{version}"' if version else f'gem "{name}"'
    (tmp_dir / "Gemfile").write_text(f'source "https://rubygems.org"\n{gem_line}\n')


async def _create_go_project(tmp_dir: Path, name: str, version: str | None = None) -> None:
    """Create a minimal go.mod."""
    ver = f"v{version}" if version else "v0.0.0"
    (tmp_dir / "go.mod").write_text(
        f"module chainreaper-scan\n\ngo 1.21\n\nrequire {name} {ver}\n"
    )


async def _create_maven_project(tmp_dir: Path, name: str, version: str | None = None) -> None:
    """Create a minimal pom.xml."""
    parts = name.split(":", 1) if ":" in name else (name, name)
    group_id, artifact_id = parts[0], parts[-1]
    ver = version or "LATEST"
    pom = f"""<?xml version="1.0" encoding="UTF-8"?>
<project>
  <modelVersion>4.0.0</modelVersion>
  <groupId>chainreaper</groupId>
  <artifactId>scan</artifactId>
  <version>0.0.0</version>
  <dependencies>
    <dependency>
      <groupId>{group_id}</groupId>
      <artifactId>{artifact_id}</artifactId>
      <version>{ver}</version>
    </dependency>
  </dependencies>
</project>"""
    (tmp_dir / "pom.xml").write_text(pom)


async def _create_nuget_project(tmp_dir: Path, name: str, version: str | None = None) -> None:
    """Create a minimal .csproj."""
    ver = version or "*"
    csproj = f"""<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="{name}" Version="{ver}" />
  </ItemGroup>
</Project>"""
    (tmp_dir / "scan.csproj").write_text(csproj)
