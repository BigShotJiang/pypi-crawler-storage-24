"""Enums and constants for ChainReaper."""

from __future__ import annotations

from enum import Enum


class Severity(str, Enum):
    """Finding severity levels."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class AttackVector(str, Enum):
    """Supply chain attack vectors."""

    DEPENDENCY_CONFUSION = "dependency_confusion"
    TYPOSQUATTING = "typosquatting"
    COMPROMISED_MAINTAINER = "compromised_maintainer"
    BUILD_SYSTEM = "build_system"
    MALICIOUS_PACKAGE = "malicious_package"
    INSTALL_SCRIPT = "install_script"
    SHADOW_DEPENDENCY = "shadow_dependency"
    LOCKFILE_MANIPULATION = "lockfile_manipulation"
    REGISTRY_SPOOFING = "registry_spoofing"
    ABANDONED_TAKEOVER = "abandoned_takeover"
    SOURCE_BINARY_MISMATCH = "source_binary_mismatch"
    PROTESTWARE = "protestware"
    KNOWN_CVE = "known_cve"
    CODE_INSPECTION = "code_inspection"


class TargetType(str, Enum):
    """Scan target types."""

    REPO_URL = "repo_url"
    LOCAL_PATH = "local_path"
    LOCKFILE = "lockfile"
    SBOM = "sbom"
    DOCKER_IMAGE = "docker_image"


class EcosystemName(str, Enum):
    """Supported package ecosystems."""

    NPM = "npm"
    PYPI = "pypi"
    MAVEN = "maven"
    GO = "go"
    CARGO = "cargo"
    RUBYGEMS = "rubygems"
    NUGET = "nuget"
    DOCKER = "docker"


class NodeType(str, Enum):
    """Attack graph node types."""

    PACKAGE = "package"
    VULNERABILITY = "vulnerability"
    ATTACK_STEP = "attack_step"
    IMPACT = "impact"
    REGISTRY = "registry"
    MAINTAINER = "maintainer"
    BUILD_SYSTEM = "build_system"
    ARTIFACT = "artifact"


class EdgeType(str, Enum):
    """Attack graph edge types."""

    DEPENDS_ON = "depends_on"
    EXPLOITS = "exploits"
    LEADS_TO = "leads_to"
    ENABLES = "enables"
    MAINTAINED_BY = "maintained_by"
    PUBLISHED_TO = "published_to"
    BUILT_BY = "built_by"


class ScanPhase(str, Enum):
    """Scan lifecycle phases."""

    INITIALIZING = "initializing"
    DISCOVERING = "discovering"
    CVE_SCANNING = "cve_scanning"
    PLANNING = "planning"
    ANALYZING = "analyzing"
    BUILDING_GRAPH = "building_graph"
    REPORTING = "reporting"
    COMPLETED = "completed"
    FAILED = "failed"


class OutputFormat(str, Enum):
    """Supported output formats."""

    JSON = "json"
    SARIF = "sarif"
    CYCLONEDX = "cyclonedx"
    SPDX = "spdx"
    HTML = "html"
    PDF = "pdf"
    CONSOLE = "console"
