"""Core engine: models, config, exceptions, events."""
