"""Exception hierarchy for ChainReaper."""

from __future__ import annotations


class ChainReaperError(Exception):
    """Base exception for all ChainReaper errors."""


class ConfigError(ChainReaperError):
    """Configuration error."""


class LLMError(ChainReaperError):
    """LLM provider error."""


class LLMProviderExhaustedError(LLMError):
    """All LLM providers in the chain failed."""


class LLMCostLimitError(LLMError):
    """Scan cost limit exceeded."""


class ScanError(ChainReaperError):
    """Error during scan execution."""


class TargetError(ScanError):
    """Invalid or inaccessible scan target."""


class EcosystemError(ChainReaperError):
    """Ecosystem plugin error."""


class EcosystemNotFoundError(EcosystemError):
    """No ecosystem detected in target."""


class AnalyzerError(ChainReaperError):
    """Analyzer execution error."""


class RegistryError(ChainReaperError):
    """Package registry API error."""


class RegistryRateLimitError(RegistryError):
    """Registry API rate limit hit."""


class OutputError(ChainReaperError):
    """Output generation error."""


class GraphError(ChainReaperError):
    """Attack graph construction error."""
