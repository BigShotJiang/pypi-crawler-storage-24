"""Dependency diff engine for incremental/diff scanning."""

from __future__ import annotations

import json
import logging
import subprocess
from pathlib import Path

from pydantic import BaseModel

from chainreaper.core.models import DependencyNode, DependencyTree, ScanResult

logger = logging.getLogger(__name__)

# Manifest/lockfile patterns used by diff_from_git
_DEPENDENCY_FILE_GLOBS = [
    "package.json",
    "package-lock.json",
    "yarn.lock",
    "pnpm-lock.yaml",
    "requirements*.txt",
    "Pipfile.lock",
    "poetry.lock",
    "pyproject.toml",
    "go.mod",
    "go.sum",
    "Cargo.toml",
    "Cargo.lock",
    "Gemfile",
    "Gemfile.lock",
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    "packages.config",
    "*.csproj",
]


def _dep_key(node: DependencyNode) -> tuple[str, str]:
    """Return the unique key for a dependency: (ecosystem, name)."""
    return (node.ecosystem.value, node.name)


class DependencyDiff(BaseModel):
    """Result of comparing two sets of dependency trees."""

    added: list[DependencyNode] = []
    removed: list[DependencyNode] = []
    changed: list[tuple[DependencyNode, DependencyNode]] = []
    unchanged: list[DependencyNode] = []

    @property
    def has_changes(self) -> bool:
        """True if there are any added, removed, or changed dependencies."""
        return bool(self.added or self.removed or self.changed)

    @property
    def summary(self) -> str:
        """Human-readable summary of the diff."""
        parts = []
        if self.added:
            parts.append(f"{len(self.added)} added")
        if self.removed:
            parts.append(f"{len(self.removed)} removed")
        if self.changed:
            parts.append(f"{len(self.changed)} changed")
        if self.unchanged:
            parts.append(f"{len(self.unchanged)} unchanged")
        return ", ".join(parts) if parts else "no changes"


def _collect_all_deps(
    trees: list[DependencyTree],
) -> dict[tuple[str, str], DependencyNode]:
    """Collect all dependencies from trees into a dict keyed by (ecosystem, name)."""
    result: dict[tuple[str, str], DependencyNode] = {}
    for tree in trees:
        for dep in tree.direct_dependencies:
            result[_dep_key(dep)] = dep
        for dep in tree.transitive_dependencies:
            result[_dep_key(dep)] = dep
    return result


def compute_diff(
    old_trees: list[DependencyTree],
    new_trees: list[DependencyTree],
) -> DependencyDiff:
    """Compare two sets of dependency trees and compute the diff.

    - added: in new but not old
    - removed: in old but not new
    - changed: same (ecosystem, name) but different version
    - unchanged: same (ecosystem, name) and same version
    """
    old_deps = _collect_all_deps(old_trees)
    new_deps = _collect_all_deps(new_trees)

    old_keys = set(old_deps.keys())
    new_keys = set(new_deps.keys())

    added: list[DependencyNode] = []
    removed: list[DependencyNode] = []
    changed: list[tuple[DependencyNode, DependencyNode]] = []
    unchanged: list[DependencyNode] = []

    # Added: in new but not old
    for key in sorted(new_keys - old_keys):
        added.append(new_deps[key])

    # Removed: in old but not new
    for key in sorted(old_keys - new_keys):
        removed.append(old_deps[key])

    # Common keys: check version
    for key in sorted(old_keys & new_keys):
        old_node = old_deps[key]
        new_node = new_deps[key]
        if old_node.version != new_node.version:
            changed.append((old_node, new_node))
        else:
            unchanged.append(new_node)

    return DependencyDiff(
        added=added,
        removed=removed,
        changed=changed,
        unchanged=unchanged,
    )


def filter_trees_to_diff(
    trees: list[DependencyTree],
    diff: DependencyDiff,
) -> list[DependencyTree]:
    """Filter dependency trees to only contain added + changed dependencies.

    Preserves tree structure (ecosystem, root_package) but filters deps.
    Returns only trees that have at least one relevant dependency.
    """
    # Build set of keys that should be included
    include_keys: set[tuple[str, str]] = set()
    for node in diff.added:
        include_keys.add(_dep_key(node))
    for _old, new in diff.changed:
        include_keys.add(_dep_key(new))

    filtered_trees: list[DependencyTree] = []
    for tree in trees:
        direct = [dep for dep in tree.direct_dependencies if _dep_key(dep) in include_keys]
        transitive = [dep for dep in tree.transitive_dependencies if _dep_key(dep) in include_keys]
        if direct or transitive:
            filtered_trees.append(
                DependencyTree(
                    ecosystem=tree.ecosystem,
                    root_package=tree.root_package,
                    direct_dependencies=direct,
                    transitive_dependencies=transitive,
                )
            )

    return filtered_trees


def load_baseline(baseline_path: Path) -> list[DependencyTree]:
    """Load a previously saved scan result JSON and extract dependency trees.

    Args:
        baseline_path: Path to a ChainReaper JSON scan result file.

    Returns:
        List of DependencyTree from the baseline scan.

    Raises:
        FileNotFoundError: If baseline_path does not exist.
        ValueError: If the JSON cannot be parsed as a ScanResult.
    """
    raw = baseline_path.read_text(encoding="utf-8")
    data = json.loads(raw)
    result = ScanResult.model_validate(data)
    return result.dependency_trees


def diff_from_git(
    target_path: Path,
    base_ref: str = "HEAD~1",
) -> DependencyDiff | None:
    """Check git diff for changes to dependency manifest/lockfile files.

    This is a lightweight check that identifies WHICH files changed,
    not a full dependency parse. Returns None if git is unavailable
    or no dependency files changed.

    Args:
        target_path: Path to the git repository.
        base_ref: Git ref to compare against (default: HEAD~1).

    Returns:
        Empty DependencyDiff (with has_changes=True sentinel via added)
        if dependency files changed, or None if no changes / git unavailable.
    """
    # Build the git diff command with all manifest/lockfile patterns
    diff_patterns = [f"**/{pattern}" for pattern in _DEPENDENCY_FILE_GLOBS]

    cmd = [
        "git",
        "diff",
        "--name-only",
        base_ref,
        "--",
        *diff_patterns,
    ]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=str(target_path),
            timeout=30,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        logger.debug("git diff failed: %s", e)
        return None

    if result.returncode != 0:
        logger.debug("git diff returned %d: %s", result.returncode, result.stderr)
        return None

    changed_files = [line.strip() for line in result.stdout.splitlines() if line.strip()]

    if not changed_files:
        return None

    logger.info("Dependency files changed: %s", changed_files)
    return DependencyDiff()
