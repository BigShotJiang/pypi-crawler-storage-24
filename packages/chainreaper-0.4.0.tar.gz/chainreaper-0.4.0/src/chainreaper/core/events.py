"""Event bus for scan lifecycle notifications."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from typing import Any

from chainreaper.core.constants import ScanPhase


@dataclass
class ScanEvent:
    """A scan lifecycle event."""

    phase: ScanPhase
    message: str
    data: dict[str, Any] = field(default_factory=dict)


EventHandler = Callable[[ScanEvent], Coroutine[Any, Any, None]]


class EventBus:
    """Simple async event bus for scan lifecycle."""

    def __init__(self) -> None:
        self._handlers: list[EventHandler] = []

    def subscribe(self, handler: EventHandler) -> None:
        """Register an event handler."""
        self._handlers.append(handler)

    async def emit(self, event: ScanEvent) -> None:
        """Emit an event to all handlers. Errors in handlers are logged, not propagated."""
        results = await asyncio.gather(*(h(event) for h in self._handlers), return_exceptions=True)
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logging.getLogger(__name__).warning("Event handler %d failed: %s", i, result)

    async def phase(self, phase: ScanPhase, message: str, **data: Any) -> None:
        """Emit a phase change event."""
        await self.emit(ScanEvent(phase=phase, message=message, data=data))
