"""Multi-provider LLM router using direct SDKs — no LiteLLM dependency.

Supports: Google Gemini, Anthropic Claude, OpenAI GPT, and OpenAI-compatible
providers (Ollama, Groq, Together, etc.) via base_url override.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Optional

from chainreaper.core.config import ChainReaperConfig, LLMProviderConfig
from chainreaper.core.exceptions import LLMError, LLMProviderExhaustedError
from chainreaper.llm.cost_tracker import CostTracker

logger = logging.getLogger(__name__)

# Approximate cost per 1K tokens (input/output) for common models
_COST_PER_1K: dict[str, tuple[float, float]] = {
    "gemini-2.5-flash": (0.00015, 0.0006),
    "gemini-2.5-pro": (0.00125, 0.005),
    "gemini-2.0-flash": (0.0001, 0.0004),
    "claude-sonnet-4": (0.003, 0.015),
    "claude-opus-4": (0.015, 0.075),
    "claude-haiku-4": (0.0008, 0.004),
    "gpt-4o": (0.0025, 0.01),
    "gpt-4o-mini": (0.00015, 0.0006),
}


class LLMResponse:
    """Wrapper around an LLM completion response."""

    def __init__(self, content: str, model: str, input_tokens: int, output_tokens: int) -> None:
        self.content = content
        self.model = model
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens


def _detect_provider(model: str) -> str:
    """Detect provider from model string. Supports 'provider/model' format."""
    model_lower = model.lower()
    if "/" in model:
        prefix = model.split("/")[0].lower()
        if prefix in ("gemini", "google"):
            return "google"
        if prefix in ("anthropic", "claude"):
            return "anthropic"
        if prefix in ("openai", "gpt"):
            return "openai"
        if prefix == "ollama":
            return "ollama"
        # Default to openai-compatible for unknown prefixes (groq, together, etc.)
        return "openai_compatible"
    if "gemini" in model_lower:
        return "google"
    if "claude" in model_lower:
        return "anthropic"
    if "gpt" in model_lower:
        return "openai"
    return "openai"


def _get_model_name(model: str) -> str:
    """Strip provider prefix from model string."""
    if "/" in model:
        return model.split("/", 1)[1]
    return model


def _estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Estimate cost based on known pricing."""
    model_name = _get_model_name(model).lower()
    for key, (input_cost, output_cost) in _COST_PER_1K.items():
        if key in model_name:
            return (input_tokens / 1000 * input_cost) + (output_tokens / 1000 * output_cost)
    # Default: assume cheap model
    return (input_tokens + output_tokens) / 1000 * 0.001


class ChainReaperRouter:
    """Multi-LLM router with automatic fallback chain.

    Uses direct provider SDKs instead of LiteLLM:
    - Google: google-generativeai
    - Anthropic: anthropic
    - OpenAI + compatible: openai

    Provider chain is fully configurable via .chainreaper.yml.
    """

    def __init__(self, config: ChainReaperConfig) -> None:
        self.config = config
        self.provider_chain = config.llm.provider_chain
        self.cost_tracker = CostTracker(cost_limit_usd=config.llm.cost_limit_usd)

    async def complete(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        response_format: Optional[dict[str, Any]] = None,
    ) -> LLMResponse:
        """Send a completion request, falling back through the provider chain."""
        errors: list[str] = []

        for provider in self.provider_chain:
            try:
                return await self._call_provider(
                    provider,
                    messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    response_format=response_format,
                )
            except Exception as e:
                error_msg = f"{provider.model}: {e}"
                errors.append(error_msg)
                logger.warning("Provider failed: %s", error_msg)
                if not self.config.llm.fallback_on_error:
                    raise LLMError(error_msg) from e

        raise LLMProviderExhaustedError(f"All providers failed: {'; '.join(errors)}")

    async def _call_provider(
        self,
        provider: LLMProviderConfig,
        messages: list[dict[str, str]],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        response_format: Optional[dict[str, Any]] = None,
    ) -> LLMResponse:
        """Call a single LLM provider with retry on transient errors (429/504)."""
        import asyncio

        self.cost_tracker.check_limit()

        detected = _detect_provider(provider.model)
        model_name = _get_model_name(provider.model)
        temp = temperature if temperature is not None else provider.temperature
        tokens = max_tokens or provider.max_tokens

        max_retries = 3
        for attempt in range(max_retries):
            try:
                if detected == "google":
                    content, in_tok, out_tok = await self._call_google(
                        model_name, messages, temp, tokens
                    )
                elif detected == "anthropic":
                    content, in_tok, out_tok = await self._call_anthropic(
                        model_name, messages, temp, tokens
                    )
                else:
                    content, in_tok, out_tok = await self._call_openai(
                        model_name, messages, temp, tokens, response_format, detected
                    )
                break  # Success
            except Exception as e:
                err_str = str(e).lower()
                is_transient = any(
                    k in err_str for k in ("429", "504", "rate", "deadline", "overloaded", "503")
                )
                if is_transient and attempt < max_retries - 1:
                    wait = 2 ** (attempt + 1)  # 2s, 4s
                    logger.warning(
                        "Transient error (attempt %d/%d), retrying in %ds: %s",
                        attempt + 1, max_retries, wait, str(e)[:100],
                    )
                    await asyncio.sleep(wait)
                    continue
                raise

        cost = _estimate_cost(provider.model, in_tok, out_tok)
        self.cost_tracker.record(
            model=provider.model,
            input_tokens=in_tok,
            output_tokens=out_tok,
            cost_usd=cost,
        )

        return LLMResponse(
            content=content, model=provider.model, input_tokens=in_tok, output_tokens=out_tok
        )

    async def _call_google(
        self, model: str, messages: list[dict[str, str]], temperature: float, max_tokens: int
    ) -> tuple[str, int, int]:
        """Call Google Gemini via google-generativeai SDK."""
        import google.generativeai as genai

        api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            raise LLMError("GEMINI_API_KEY or GOOGLE_API_KEY not set")

        genai.configure(api_key=api_key)
        gen_model = genai.GenerativeModel(model)

        # Convert messages to Gemini format
        system_msg = ""
        history = []
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg["content"]
            elif msg["role"] == "user":
                content = msg["content"]
                if system_msg:
                    content = f"{system_msg}\n\n{content}"
                    system_msg = ""
                history.append({"role": "user", "parts": [content]})
            elif msg["role"] == "assistant":
                history.append({"role": "model", "parts": [msg["content"]]})

        config = genai.GenerationConfig(
            temperature=temperature,
            max_output_tokens=max_tokens,
            response_mime_type="application/json",
        )

        response = await gen_model.generate_content_async(
            history,
            generation_config=config,
        )

        content = response.text or ""
        usage = response.usage_metadata
        in_tok = usage.prompt_token_count if usage else 0
        out_tok = usage.candidates_token_count if usage else 0

        return content, in_tok, out_tok

    async def _call_anthropic(
        self, model: str, messages: list[dict[str, str]], temperature: float, max_tokens: int
    ) -> tuple[str, int, int]:
        """Call Anthropic Claude via anthropic SDK."""
        import anthropic

        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise LLMError("ANTHROPIC_API_KEY not set")

        client = anthropic.AsyncAnthropic(api_key=api_key)

        # Extract system message
        system_msg = ""
        api_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg["content"]
            else:
                api_messages.append({"role": msg["role"], "content": msg["content"]})

        # Use streaming to avoid Anthropic's 10-minute timeout on large responses
        content_parts: list[str] = []
        in_tok = 0
        out_tok = 0
        async with client.messages.stream(
            model=model,
            system=system_msg,
            messages=api_messages,
            temperature=temperature,
            max_tokens=max_tokens,
        ) as stream:
            async for text in stream.text_stream:
                content_parts.append(text)
            final_message = await stream.get_final_message()
            in_tok = final_message.usage.input_tokens
            out_tok = final_message.usage.output_tokens

        content = "".join(content_parts)

        return content, in_tok, out_tok

    async def _call_openai(
        self,
        model: str,
        messages: list[dict[str, str]],
        temperature: float,
        max_tokens: int,
        response_format: Optional[dict[str, Any]] = None,
        provider_type: str = "openai",
    ) -> tuple[str, int, int]:
        """Call OpenAI or OpenAI-compatible API (Ollama, Groq, Together, etc.)."""
        import openai

        api_key = os.environ.get("OPENAI_API_KEY", "")
        base_url = None

        if provider_type == "ollama":
            base_url = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434/v1")
            api_key = "ollama"  # Ollama doesn't need a real key

        client = openai.AsyncOpenAI(api_key=api_key, base_url=base_url)

        kwargs: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if response_format:
            kwargs["response_format"] = response_format

        response = await client.chat.completions.create(**kwargs)

        content = response.choices[0].message.content or ""
        usage = response.usage
        in_tok = usage.prompt_tokens if usage else 0
        out_tok = usage.completion_tokens if usage else 0

        return content, in_tok, out_tok
