"""LLM router with multi-provider support via LiteLLM."""
