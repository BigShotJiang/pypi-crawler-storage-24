"""Analysis prompt templates for each attack vector."""

DEPENDENCY_CONFUSION = """\
Analyze the following packages for dependency confusion vulnerability.

## CONTEXT
These packages are dependencies of the project "{project_name}".
Registry configuration: {registry_config}

## PACKAGES TO ANALYZE
{packages}

## PUBLIC REGISTRY DATA
{registry_data}

## ANALYSIS INSTRUCTIONS
For each package, determine:
1. Is this likely an internal/private package? Look for:
   - Scoped names (@org/pkg, @company/pkg)
   - Company-prefix patterns (acme-*, myco-internal-*)
   - Names that reference internal concepts (auth-core, billing-api, etc.)
2. Does this package name exist on the public registry?
3. If it does NOT exist publicly, this is a dependency confusion candidate
4. What is the exploitation impact? (code execution at install time, etc.)

Rate each finding's severity and confidence.
"""

TYPOSQUATTING = """\
Analyze the following packages for typosquatting risk.

## PACKAGES TO ANALYZE
{packages}

## ANALYSIS INSTRUCTIONS
For each popular package in the dependency tree:
1. Generate plausible typosquats:
   - Character swaps (lodash → lodahs)
   - Missing characters (express → expres)
   - Extra characters (react → reactt)
   - Homoglyphs (request → reguest)
   - Scope confusion (@types/node → @typos/node)
2. Check if any actual dependencies match known typosquat patterns
3. For each dependency, calculate string distance to popular packages
4. Flag any dependency with suspiciously similar names to well-known packages

Rate each finding's severity and confidence.
"""

COMPROMISED_MAINTAINER = """\
Analyze maintainer trust signals for the following packages.

## PACKAGES AND MAINTAINER DATA
{maintainer_data}

## ANALYSIS INSTRUCTIONS
For each package maintainer, assess risk based on:
1. Account age — newer accounts are higher risk
2. Number of packages — single-package maintainers may be disposable accounts
3. 2FA status — no 2FA means easier account takeover
4. Activity patterns — sudden ownership transfers or long dormancy
5. Package popularity vs. maintainer profile — mismatch is suspicious
6. Multiple maintainers — single maintainer is a bus factor risk

Rate each finding's severity and confidence.
"""

INSTALL_SCRIPT = """\
Analyze pre/post install scripts in the following packages.

## PACKAGES WITH INSTALL SCRIPTS
{packages_with_scripts}

## ANALYSIS INSTRUCTIONS
For each package with install scripts:
1. What does the install script do?
2. Does it make network requests? (downloading code, calling home)
3. Does it access the filesystem beyond the package directory?
4. Does it execute system commands?
5. Does it access environment variables? (token theft)
6. Is the behavior consistent with the package's stated purpose?

Flag scripts with suspicious behavior patterns.
Rate each finding's severity and confidence.
"""

SHADOW_DEPENDENCY = """\
Analyze the transitive dependency tree for hidden risks.

## DEPENDENCY TREE
{dependency_tree}

## ANALYSIS INSTRUCTIONS
Look for risky patterns in the transitive dependency graph:
1. Deep transitive deps with high download counts but few maintainers
2. Packages that are dependencies of many packages (high blast radius)
3. Packages with known history of supply chain incidents
4. Unmaintained packages deep in the tree (no updates in 2+ years)
5. Packages with unexpectedly broad permissions or capabilities
6. Version pinning issues (ranges that could pull malicious versions)

Rate each finding's severity and confidence.
"""

LOCKFILE_INTEGRITY = """\
Verify the integrity of the lockfile against the manifest.

## MANIFEST
{manifest}

## LOCKFILE
{lockfile}

## ANALYSIS INSTRUCTIONS
Check for:
1. Packages in lockfile not declared in manifest (phantom dependencies)
2. Version mismatches between lockfile and manifest constraints
3. Missing integrity hashes
4. Registry URL anomalies (packages from unexpected registries)
5. Signs of manual lockfile manipulation
6. Outdated lockfile format

Rate each finding's severity and confidence.
"""

BUILD_SYSTEM = """\
Analyze the following CI/CD pipeline configurations for supply chain security risks.

## CONTEXT
Ecosystems in use: {ecosystems}
Number of CI config files found: {config_count}

## CI/CD CONFIGURATION FILES
{ci_configs}

## ANALYSIS INSTRUCTIONS
For each CI/CD configuration file, check for these attack vectors:

1. **Unpinned action/image versions**: Actions referenced by tag (e.g., `uses: actions/checkout@v3`)
   instead of SHA hash (e.g., `uses: actions/checkout@abc123...`). Tag-based references can be
   silently updated by the action maintainer to inject malicious code.

2. **Secret exposure**: Secrets printed to logs, passed as command-line arguments (visible in
   process listings), or exposed via environment variables to untrusted steps.

3. **Workflow injection**: Use of `pull_request_target` with checkout of PR code, expression
   injection via `${{{{ github.event.issue.title }}}}` or similar untrusted inputs in `run:` blocks.

4. **Over-permissive tokens**: GITHUB_TOKEN with `permissions: write-all` or missing permission
   restrictions. Service account tokens with broader scope than needed.

5. **Insecure runner configuration**: Self-hosted runners without proper isolation, or use of
   `runs-on` with untrusted labels.

6. **Artifact poisoning**: Build artifacts uploaded/downloaded without integrity verification,
   or cache poisoning vectors.

7. **Code injection via inputs**: Workflow dispatch inputs, repository dispatch payloads, or
   comment bodies used directly in shell commands without sanitization.

For each issue found, specify the file path, issue type, detailed description, severity,
confidence, and specific remediation steps.

Rate each finding's severity and confidence.
"""

MALICIOUS_PACKAGE = """\
Analyze the following {ecosystem} packages for indicators of intentional malicious behavior.

## CONTEXT
Ecosystem: {ecosystem}
Packages analyzed: {package_count}

## PACKAGES TO ANALYZE
{packages}

## ANALYSIS INSTRUCTIONS
For each package, assess whether it shows indicators of being intentionally malicious:

1. **Bot-inflated downloads**: Very new packages (published recently) with suspiciously high
   download counts that don't match their age or utility. Legitimate packages grow organically.

2. **Obfuscated code indicators**: Package descriptions or metadata suggesting code obfuscation
   (eval/exec usage, base64-encoded payloads, minified non-production code, dynamic imports of
   encoded strings).

3. **Unauthorized access patterns**: Packages whose stated purpose doesn't require network access,
   filesystem operations outside their directory, or environment variable reading — but metadata
   suggests they perform these actions.

4. **Name-description mismatch**: Package name suggests one purpose (e.g., "color-utils") but
   description reveals a completely different or vague purpose. This is a common pattern for
   malware disguised as utility packages.

5. **Suspicious metadata patterns**: Missing or vague descriptions, no repository URL, very few
   maintainers with new accounts, packages that are forks of popular packages with slight
   modifications.

6. **Known malware indicators**: Packages matching known malware distribution patterns — name
   variations of popular packages, packages with install scripts that download remote code,
   packages that access credentials or tokens.

CRITICAL RULES — READ CAREFULLY:
- Only flag packages with GENUINE malicious indicators, not hypothetical risks
- Do NOT flag well-known, popular packages (express, lodash, debug, qs, body-parser, etc.)
- Do NOT flag packages simply for being small, having few downloads, or having install scripts
- Do NOT flag packages for "potential" risks — only flag OBSERVED suspicious patterns
- Having install scripts is NORMAL for many packages and is NOT a malicious indicator alone
- A package with >100K weekly downloads and a known GitHub repo is ALMOST NEVER malicious
- If in doubt, set is_likely_malicious=false — false negatives are better than false positives
- Empty suspects list is a VALID response when no packages are genuinely suspicious

Rate each finding's severity and confidence.
"""

REGISTRY_SPOOFING = """\
Analyze the following registry configuration files for spoofing vulnerabilities.

## CONTEXT
Ecosystems: {ecosystems}

## REGISTRY CONFIGURATION FILES
{registry_configs}

## DEPENDENCY SUMMARY
{dependency_summary}

## ANALYSIS INSTRUCTIONS
For each registry configuration file, check for misconfigurations that could allow
an attacker to serve malicious packages:

1. **Mixed public/private registries**: Configuration uses both public (npmjs.com, pypi.org)
   and private registries without properly scoping which packages come from where. An attacker
   could register a package on the public registry with the same name as an internal package.

2. **Missing scope bindings**: Private registries configured without explicit scope bindings
   (e.g., `@myorg:registry=https://private.reg` is missing). Without scope binding, the
   package manager may fall through to the public registry for scoped packages.

3. **HTTP (non-TLS) registry URLs**: Registry URLs using `http://` instead of `https://`,
   enabling man-in-the-middle attacks to serve modified packages.

4. **Unverified/suspicious registries**: Registry URLs pointing to unknown, suspicious, or
   potentially compromised third-party registries.

5. **Missing authentication**: Private registry configured without authentication tokens or
   credentials, potentially falling back to public registry.

6. **Private registry information leak**: Configuration files that expose internal registry
   URLs, organization names, or scope patterns that could aid reconnaissance.

7. **Proxy misconfiguration**: Registry proxies (Verdaccio, Nexus, Artifactory) configured
   with overly permissive upstream proxying rules.

Rate each finding's severity and confidence.
"""

ABANDONED_TAKEOVER = """\
Analyze the following packages for abandonment and maintainer takeover risk.

## CONTEXT
Ecosystem: {ecosystem}
Potentially stale packages analyzed: {package_count} (out of {total_deps} total dependencies)

## PACKAGES TO ANALYZE
{packages}

## ANALYSIS INSTRUCTIONS
For each package flagged as potentially stale, assess the abandonment and takeover risk:

1. **Last update age**: Packages not updated in 2+ years are significantly more likely to have
   dormant maintainer accounts that could be claimed by attackers. Consider whether the package
   type justifies infrequent updates (e.g., a math utility may not need updates, while a
   security library should be actively maintained).

2. **Maintainer count (bus factor)**: Single-maintainer packages are high risk — if that one
   account is compromised or abandoned, there's no peer review. No maintainer should be the
   sole gatekeeper for widely-used packages.

3. **Download count vs. maintainer activity**: High download counts with low maintainer activity
   suggests a package that many projects depend on but nobody is watching. These are prime
   targets for attackers.

4. **Repository status**: Missing or broken repository URLs, archived repositories, or repos
   with no recent commits are indicators of abandonment.

5. **Known takeover patterns**: npm has had cases where abandoned packages were transferred to
   new maintainers who injected malware (event-stream incident). Assess whether this package's
   profile matches these patterns.

6. **Ecosystem-specific risks**: Some ecosystems (npm) allow maintainer transfer requests for
   dormant accounts. Others (PyPI) have name-squatting policies that could be exploited.

Consider the COMBINATION of signals. A 3-year-old single-maintainer package with 1M weekly
downloads is FAR more concerning than a 3-year-old single-maintainer package with 10 downloads.

Rate each finding's severity and confidence.
"""

SOURCE_BINARY_MISMATCH = """\
Analyze the following packages for source-binary provenance integrity.

## CONTEXT
Ecosystem: {ecosystem}
Registry: {registry_url}
Packages analyzed: {package_count}

## PACKAGES TO ANALYZE
{packages}

## ANALYSIS INSTRUCTIONS
For each package, assess whether the published artifact can be traced back to its source:

1. **Missing source repository**: Packages with no linked repository URL. Without a repository,
   there's no way to verify what code is actually in the published package. This is the most
   basic provenance gap.

2. **Repository URL mismatch**: The repository URL in the package metadata doesn't match what's
   expected — e.g., pointing to a fork instead of the original, or to an unrelated repository.

3. **No build provenance**: Packages without SLSA provenance attestations, Sigstore signatures,
   or other build provenance indicators. Without provenance, there's no cryptographic proof the
   artifact was built from the claimed source.

4. **Unreproducible builds**: Packages from ecosystems that support reproducible builds (e.g.,
   Cargo, Maven) but don't use them. Reproducible builds ensure anyone can verify the binary
   matches the source.

5. **Stale source repository**: The repository exists but hasn't been updated in a long time,
   while the package continues to receive updates — suggesting the published versions may
   contain code not present in the repository.

6. **Missing VCS info**: No commit hash, tag, or branch reference linking the published version
   to a specific source snapshot.

Focus on packages where the gap between source and artifact is exploitable. A compromised
maintainer or stolen publish token could push a backdoored version that's invisible to anyone
reviewing the source repository.

Rate each finding's severity and confidence.
"""

PROTESTWARE = """\
Analyze the following dependency tree for protestware and geo-targeted destructive behavior.

## CONTEXT
Ecosystem: {ecosystem}
Packages analyzed: {package_count}
Known protestware packages in this ecosystem: {known_protestware}

## PACKAGES TO ANALYZE
{packages}

## ANALYSIS INSTRUCTIONS
Assess each package for protestware/wiper risk. Protestware is legitimate software that has
been intentionally modified by its maintainer to include destructive, political, or protest-driven
behavior — often targeting users based on geographic location.

Check for these indicators:

1. **Known protestware history**: Packages flagged as KNOWN_PROTESTWARE=True have documented
   incidents. Verify the current version is safe or still compromised. Known examples include
   node-ipc (wiped files for Russian IPs), colors/faker (infinite loop DoS), es5-ext (protest
   messages for Russian locales).

2. **Geo-targeted behavior**: Packages that check locale, timezone, IP geolocation, or language
   settings to conditionally execute different code paths. Legitimate packages rarely need
   geographic checks outside of i18n.

3. **Conditional destructive behavior**: Code that deletes files, overwrites data, corrupts
   databases, or performs denial-of-service based on environmental conditions.

4. **Suspicious version bumps**: Recent major or minor version bumps with vague changelog entries
   like "performance improvements" or "minor updates" that could mask injected protest code.
   Check if the maintainer has a history of political statements.

5. **Locale/timezone-based logic**: Packages that import locale, timezone, or IP geolocation
   libraries without a clear functional reason.

6. **Political messaging**: Packages that display political messages, open URLs, or modify
   system state to deliver a political message.

7. **Self-sabotage patterns**: Maintainers who have publicly expressed intent to sabotage their
   own packages (like the colors/faker maintainer), or who have transferred ownership under
   duress.

NOTE: Do NOT flag packages simply for being from a specific country or having maintainers with
certain nationalities. Focus on BEHAVIORAL indicators and KNOWN incidents.

Rate each finding's severity and confidence.
"""
