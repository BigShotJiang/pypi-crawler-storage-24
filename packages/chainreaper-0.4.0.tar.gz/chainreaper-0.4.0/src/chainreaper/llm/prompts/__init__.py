"""LLM prompt templates for ChainReaper agents."""
