"""Token and cost tracking for LLM usage."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from chainreaper.core.exceptions import LLMCostLimitError

logger = logging.getLogger(__name__)


@dataclass
class UsageRecord:
    """Single LLM call usage."""

    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float


@dataclass
class CostTracker:
    """Tracks cumulative LLM token usage and cost across a scan."""

    cost_limit_usd: float = 5.0
    records: list[UsageRecord] = field(default_factory=list)

    @property
    def total_input_tokens(self) -> int:
        return sum(r.input_tokens for r in self.records)

    @property
    def total_output_tokens(self) -> int:
        return sum(r.output_tokens for r in self.records)

    @property
    def total_cost_usd(self) -> float:
        return sum(r.cost_usd for r in self.records)

    def record(self, model: str, input_tokens: int, output_tokens: int, cost_usd: float) -> None:
        """Record a single LLM call's usage."""
        self.records.append(
            UsageRecord(
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cost_usd=cost_usd,
            )
        )
        logger.debug(
            "LLM call: model=%s tokens=%d/%d cost=$%.4f total=$%.4f",
            model,
            input_tokens,
            output_tokens,
            cost_usd,
            self.total_cost_usd,
        )

    def check_limit(self) -> None:
        """Raise if cost limit exceeded."""
        if self.total_cost_usd > self.cost_limit_usd:
            raise LLMCostLimitError(
                f"LLM cost ${self.total_cost_usd:.4f} exceeds limit ${self.cost_limit_usd:.2f}"
            )
