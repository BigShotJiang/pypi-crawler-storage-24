"""Structured LLM output using direct JSON parsing — no Instructor dependency.

Replaces Instructor with:
1. JSON schema injection into prompts (Pydantic model_json_schema())
2. JSON response parsing with Pydantic model_validate_json()
3. Retry on validation failure with error feedback
"""

from __future__ import annotations

import json
import logging
from typing import TypeVar

from pydantic import BaseModel, ValidationError

from chainreaper.core.config import ChainReaperConfig, LLMProviderConfig
from chainreaper.core.exceptions import LLMError, LLMProviderExhaustedError
from chainreaper.llm.cost_tracker import CostTracker
from chainreaper.llm.router import ChainReaperRouter, LLMResponse

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)


def _build_schema_prompt(response_model: type[BaseModel]) -> str:
    """Generate a JSON schema instruction for the LLM."""
    schema = response_model.model_json_schema()
    return (
        "\n\nAs a genius expert, your task is to understand the content and provide "
        "the parsed objects in json that match the following json_schema:\n\n"
        f"```json\n{json.dumps(schema, indent=2)}\n```\n\n"
        "Make sure to return an instance of the JSON, not the schema itself. "
        "Return ONLY valid JSON, no markdown code fences, no explanation."
    )


def _extract_json(text: str) -> str:
    """Extract JSON from LLM response, handling markdown code fences."""
    text = text.strip()
    # Strip markdown code fences
    if text.startswith("```"):
        lines = text.split("\n")
        # Remove first line (```json or ```) and last line (```)
        start = 1
        end = len(lines)
        for i in range(len(lines) - 1, 0, -1):
            if lines[i].strip() == "```":
                end = i
                break
        text = "\n".join(lines[start:end]).strip()
    return text


class StructuredLLM:
    """LLM client that guarantees Pydantic model responses.

    Uses JSON schema injection + Pydantic validation instead of Instructor.
    Retries with error feedback on validation failure.
    """

    def __init__(self, config: ChainReaperConfig, cost_tracker: CostTracker) -> None:
        self.config = config
        self.provider_chain = config.llm.provider_chain
        self.cost_tracker = cost_tracker
        self._router = ChainReaperRouter(config)
        # Share cost tracker
        self._router.cost_tracker = cost_tracker

    async def extract(
        self,
        response_model: type[T],
        messages: list[dict[str, str]],
        *,
        max_retries: int = 3,
        temperature: float | None = None,
    ) -> T:
        """Extract a structured Pydantic model from an LLM response.

        Tries each provider in the chain until one succeeds.
        Retries with validation error feedback on parse failure.
        """
        errors: list[str] = []

        for provider in self.provider_chain:
            try:
                return await self._extract_from_provider(
                    provider,
                    response_model,
                    messages,
                    max_retries=max_retries,
                    temperature=temperature,
                )
            except Exception as e:
                error_msg = f"{provider.model}: {e}"
                errors.append(error_msg)
                logger.warning("Structured extraction failed: %s", error_msg)
                if not self.config.llm.fallback_on_error:
                    raise LLMError(error_msg) from e

        raise LLMProviderExhaustedError(
            f"All providers failed structured extraction: {'; '.join(errors)}"
        )

    async def _extract_from_provider(
        self,
        provider: LLMProviderConfig,
        response_model: type[T],
        messages: list[dict[str, str]],
        *,
        max_retries: int = 3,
        temperature: float | None = None,
    ) -> T:
        """Extract from a single provider with retry on validation failure."""
        self.cost_tracker.check_limit()

        # Inject JSON schema into the last user message
        schema_prompt = _build_schema_prompt(response_model)
        augmented_messages = list(messages)

        # Add schema instruction to the system message if present, else to last user msg
        if augmented_messages and augmented_messages[0]["role"] == "system":
            augmented_messages[0] = {
                "role": "system",
                "content": augmented_messages[0]["content"] + schema_prompt,
            }
        elif augmented_messages:
            last_idx = len(augmented_messages) - 1
            augmented_messages[last_idx] = {
                "role": augmented_messages[last_idx]["role"],
                "content": augmented_messages[last_idx]["content"] + schema_prompt,
            }

        last_error: str = ""

        for attempt in range(max_retries):
            if attempt > 0 and last_error:
                # Add retry message with validation error
                retry_messages = [
                    *augmented_messages,
                    {
                        "role": "user",
                        "content": (
                            f"Your previous response had a JSON validation error: {last_error}\n"
                            "Please fix the JSON and try again. Return ONLY valid JSON."
                        ),
                    },
                ]
            else:
                retry_messages = augmented_messages

            # Use higher max_tokens for structured extraction since JSON responses
            # are verbose — prevents truncation that causes parse failures
            structured_max_tokens = max(provider.max_tokens, 65536)

            response: LLMResponse = await self._router.complete(
                retry_messages,
                temperature=temperature if temperature is not None else provider.temperature,
                max_tokens=structured_max_tokens,
            )

            # Parse JSON from response
            try:
                json_text = _extract_json(response.content)
                result = response_model.model_validate_json(json_text)
                return result
            except (json.JSONDecodeError, ValidationError) as e:
                last_error = str(e)[:500]
                logger.warning(
                    "Structured parse attempt %d/%d failed: %s",
                    attempt + 1,
                    max_retries,
                    last_error[:100],
                )
                continue

        # All retries exhausted
        raise LLMError(
            f"Failed to parse structured output after {max_retries} attempts. "
            f"Last error: {last_error}"
        )
