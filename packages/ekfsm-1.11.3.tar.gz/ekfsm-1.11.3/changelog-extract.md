## [1.11.3] - 2026-03-17

### Changed
- Release 1.11.3
