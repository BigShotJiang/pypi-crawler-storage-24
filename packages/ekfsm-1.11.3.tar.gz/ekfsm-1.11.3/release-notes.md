## 🎨 Version 1.11.3 - March 17, 2026

**"Enhanced ColorLED Control - Multiple Format Support"**

### What's New
- **Multiple Color Format Support**: The `ColorLED.set()` method now accepts multiple color formats for maximum flexibility
- **RGB Tuple Format**: Set colors using precise RGB values: `(255, 128, 0)`
- **Hexadecimal Colors**: Use web-compatible hex colors: `"#FF8000"`
- **Backward Compatibility**: All existing single-parameter usage continues to work

### For Users
- **Flexible Color Control**: Choose the most convenient color format for your use case
- **Enhanced Validation**: Better error messages for invalid color inputs
- **No Breaking Changes**: Existing code continues to work without modification
- **Improved Documentation**: Clear examples for all supported formats

### Code Examples

New methods to invoke color setting:

```python
# RGB tuple format - precise control
led.set((255, 128, 0))  # Orange

# Hexadecimal format - web colors
led.set("#FF8000")      # Orange
```

### Technical Details
- Enhanced color validation with comprehensive format checking
- Improved error handling for invalid color format inputs
- Added support for common named color constants
- Maintained full backward compatibility with existing API

