# kya — Know Your Agent

Trust scoring for AI agents. Check any wallet's trust score, verify ERC-8004 identity, get tier. **Zero dependencies.**

```
pip install agent-kya
```

## Quick start

```python
from kya import check, is_trusted

# Trust score (0–100) — FREE, no API key
result = check("0xABC...")
print(result["score"])  # 73
print(result["tier"])   # "trusted"

# Quick boolean
if is_trusted("0xABC...", min_score=50):
    # safe to transact
    pass
```

## API

### Free (no API key)

| Function | What it does |
|----------|-------------|
| `check(address)` | Trust score 0–100, tier, components, blocked status |
| `verify(address)` | ERC-8004 identity verification |
| `tier(address)` | Trust tier + transaction limits |
| `batch_check(addresses)` | Batch trust check (max 10) |
| `framework()` | Scoring methodology, tiers, endpoints |
| `is_trusted(address, min_score=50)` | Quick boolean |

### Premium ($0.01/query via x402)

| Function | What it does |
|----------|-------------|
| `deep_analysis(address)` | Behavioral signals, velocity scoring, anomaly flags, recommendation |

## Examples

### Check before paying

```python
from kya import check

trust = check("0xABC...")
if trust["blocked"]:
    raise Exception("Agent is sanctioned")
if trust["score"] < 20:
    raise Exception("Trust too low")
# proceed...
```

### Verify identity

```python
from kya import verify

result = verify("0xABC...")
if not result["verified"]:
    print("Not a registered agent")
```

### Batch

```python
from kya import batch_check

results = batch_check(["0xAgent1...", "0xAgent2..."])
for r in results:
    print(r["address"], r["score"], r["tier"])
```

## Trust tiers

| Tier | Score | Max per TX |
|------|-------|-----------|
| Open | 0–19 | $1 |
| Verified | 20–49 | $1,000 |
| Trusted | 50–79 | $10,000 |
| Enterprise | 80–100 | Unlimited |

## License

MIT — [AsterPay](https://asterpay.io)
