"""
kya — Know Your Agent

Trust scoring for AI agents. Check any wallet's trust score,
verify ERC-8004 identity, get tier. Zero dependencies (uses urllib).

    from kya import check, verify, is_trusted

    result = check("0xABC...")
    print(result["score"], result["tier"])

    if is_trusted("0xABC...", min_score=50):
        # safe to transact
"""

from __future__ import annotations

import json
import urllib.request
import urllib.error
from typing import Any, Optional

__version__ = "0.1.0"
__all__ = [
    "check", "verify", "tier", "batch_check",
    "deep_analysis", "framework", "is_trusted", "configure",
]

_BASE_URL = "https://x402.asterpay.io"
_TIMEOUT = 10


def configure(*, base_url: Optional[str] = None, timeout: Optional[int] = None) -> None:
    """Configure the KYA client."""
    global _BASE_URL, _TIMEOUT
    if base_url:
        _BASE_URL = base_url.rstrip("/")
    if timeout:
        _TIMEOUT = timeout


def _get(path: str) -> Any:
    req = urllib.request.Request(
        f"{_BASE_URL}{path}",
        headers={"User-Agent": f"kya-python/{__version__}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            body = json.loads(resp.read())
            return body.get("data", body)
    except urllib.error.HTTPError as e:
        body = json.loads(e.read()) if e.readable() else {}
        raise RuntimeError(body.get("error", f"HTTP {e.code}")) from None


def _post(path: str, payload: Any) -> Any:
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        f"{_BASE_URL}{path}",
        data=data,
        headers={
            "Content-Type": "application/json",
            "User-Agent": f"kya-python/{__version__}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            body = json.loads(resp.read())
            return body.get("data", body)
    except urllib.error.HTTPError as e:
        body = json.loads(e.read()) if e.readable() else {}
        raise RuntimeError(body.get("error", f"HTTP {e.code}")) from None


def _enc(s: str) -> str:
    return urllib.request.quote(s, safe="")


def check(address: str) -> dict:
    """
    Trust score (0-100) for any wallet address.
    FREE — no API key.

        result = check("0xABC...")
        print(result["score"])  # 73
        print(result["tier"])   # "trusted"
    """
    return _get(f"/v1/agent/trust-score/{_enc(address)}")


def verify(address: str) -> dict:
    """
    Verify ERC-8004 agent identity.
    FREE.

        result = verify("0xABC...")
        print(result["verified"])  # True
    """
    return _get(f"/v1/agent/verify/{_enc(address)}")


def tier(address: str) -> dict:
    """
    Get trust tier and transaction limits.
    FREE.

        result = tier("0xABC...")
        print(result["tier"])     # "trusted"
        print(result["maxPerTx"]) # 10000
    """
    return _get(f"/v1/agent/tier/{_enc(address)}")


def batch_check(addresses: list[str]) -> list[dict]:
    """
    Batch trust check (max 10 addresses).
    FREE.
    """
    return _post("/v1/agent/trust-score/batch", {"addresses": addresses})


def deep_analysis(address: str) -> dict:
    """
    Deep behavioral analysis.
    PAID — $0.01 per query via x402 (USDC on Base).

        result = deep_analysis("0xABC...")
        print(result["recommendation"])  # "allow" | "review" | "block"
    """
    return _get(f"/v1/agent/deep-analysis/{_enc(address)}")


def framework() -> dict:
    """KYA framework info (scoring, tiers, endpoints). FREE."""
    return _get("/v1/agent/framework")


def is_trusted(address: str, min_score: int = 50) -> bool:
    """
    Quick boolean: does this address meet a minimum trust score?
    FREE.

        if is_trusted("0xABC...", min_score=50):
            # proceed
    """
    result = check(address)
    return result.get("score", 0) >= min_score and not result.get("blocked", True)
