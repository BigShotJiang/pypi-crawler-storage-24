import matplotlib.pyplot as plt
import numpy as np
import matplotlib.colors as mcolors

def hello():
    print("Hello from Aymene!")

def auto_split(text, max_len=12):
        # إذا كان النص قصير لا يحتاج تقسيم
        if len(text) <= max_len:
            return text
        
        # تقسيم النص إلى كلمات
        words = text.split()
        lines = []
        current_line = ""
        
        for word in words:
            if len(current_line + " " + word) <= max_len:
                current_line += " " + word if current_line else word
            else:
                lines.append(current_line)
                current_line = word
        lines.append(current_line)
        
        # دمج الأسطر مع فاصل سطر جديد
        return "\n".join(lines)

def make_lighter(color, factor=0.3):
    rgb = mcolors.to_rgb(color)
    lighter_rgb = [(1 - (1 - c) * (1 - factor)) for c in rgb]
    return lighter_rgb

def ordinal_suffix(n: int) -> str:
    # الحالات الخاصة للأرقام التي تنتهي بـ 11, 12, 13
    if 11 <= n % 100 <= 13:
        suffix = "th"
    else:
        # اختيار اللاحقة حسب الرقم الأخير
        last_digit = n % 10
        if last_digit == 1:
            suffix = "st"
        elif last_digit == 2:
            suffix = "nd"
        elif last_digit == 3:
            suffix = "rd"
        else:
            suffix = "th"
    return f"{n}{suffix}"

def player(dataset):
       
    # العنوان 
    Tittle = "Frenkie de Jong - FC Barcelona"
    # 1 or 2
    chosse = 1
    #حجم الدائرة الداخية
    bottom_Circle = 10
    
    selected_players = dataset["Player"].unique()

    if len(selected_players) > 0:
        player_name = selected_players[0]
        player_data = dataset[dataset["Player"] == player_name]

        # ترتيب البيانات حسب الصنف
        player_data = player_data.sort_values(by="Category")

        metrics = player_data["Metric"].astype(str).tolist()
        values = player_data["Value"].astype(float).tolist()
        colors = player_data["Color"].astype(str).tolist()
        categories = player_data["Category"].astype(str).tolist()

        rank = player_data["Rank"].tolist()

        N = len(metrics)
        angles = np.linspace(0, 2*np.pi, N+1)

        fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))
        # إعدادات الشكل
        ax.set_ylim(0, 110)
        ax.set_xticks([])
        ax.set_yticks([20, 40, 60, 80, 100])
        ax.set_yticklabels(["20", "40", "60", "80", "100"], fontsize=0)

        ax.spines["polar"].set_visible(False)
        
        ax.grid(color="gray", linestyle="--", linewidth=0.7, alpha=0.6)
        ax.grid(False)
        theta = np.linspace(0, 2*np.pi, 500)
        ax.plot(theta, [100]*500, color="black", linewidth=0)

        for angle in angles[:-1]:
            ax.plot([angle, angle], [0, 100], color="white", linestyle="--", linewidth=0.7)

        for i in range(N):
            start_angle = angles[i]
            end_angle = angles[i+1]
            mid_angle = (start_angle + end_angle) / 2

            val1 = values[i]
            rank1 = rank[i]
            base_color = colors[i]

            # الجزء الخارجي (لون فاتح)
            ax.bar(mid_angle, 100, width=end_angle-start_angle, 
                color=make_lighter(base_color,0.8), edgecolor="white" ,bottom=bottom_Circle)
            # الجزء الداخلي (القيمة الفعلية)
            ax.bar(mid_angle, val1, width=end_angle-start_angle, 
                color=base_color, edgecolor="white", bottom=bottom_Circle)
            if chosse == 1 :
                # كتابة القيمة
                ax.text(mid_angle, 80 + bottom_Circle, f"{val1:02.0f}", ha="center", va="center", fontsize=8,fontweight="bold", color="white",bbox=dict(facecolor=make_lighter(base_color,0.1), edgecolor="none", boxstyle="round,pad=0.2"))
            elif chosse == 2 : 
                # كتابة الترتيب
                ax.text(mid_angle, 80, ordinal_suffix(rank1), ha="center", va="center", fontsize=8,fontweight="bold", color="white",bbox=dict(facecolor=base_color, edgecolor="none", boxstyle="round,pad=0.2"))

            # كتابة اسم المقياس
            rotation_angle = np.degrees(mid_angle) + 90
            if 0< np.degrees(mid_angle) < 180:
                rotation_angle += 180
            ax.text(mid_angle, 108+bottom_Circle, auto_split(metrics[i], max_len=12), ha="center", va="center", 
                    fontsize=8, fontweight="bold", rotation=rotation_angle, rotation_mode="anchor",color="black")


        plt.title(Tittle, size=12, y=1.08, color = "#b22222")
        fig.text(0.515, 0.975, "Frenkie de Jong - FC Barcelona", size=16, ha="center", color="#000000")

        import matplotlib.patches as mpatches

        categories = list(dict(zip(categories, colors)).items())
        """
        legend_patches = [mpatches.Patch(color=color, label=label) for label, color in categories]


        legend = plt.legend(
            handles=legend_patches,
            loc='upper center',
            bbox_to_anchor=(0.515, 1.1),
            ncol=len(categories),
            frameon=False,
            fontsize=13
        )

        for text, (_, color) in zip(legend.get_texts(), categories):
            text.set_color(color)
        """
        #-----------------

        legend_handles = [
            plt.Line2D([0], [0], color="none", label=label) for label, _ in categories
        ]

        # عرض الأسطورة في الأعلى بسطر واحد
        legend = fig.legend(
            handles=legend_handles,
            loc='upper center',
            bbox_to_anchor=(0.5, 0.06),
            ncol=len(categories),
            frameon=False,
            fontsize=8
        )

    # تلوين النصوص بنفس لون الفئة وجعلها Bold
    for text, (_, color) in zip(legend.get_texts(), categories):
        text.set_color(color)





    plt.show()









    