from abc import ABC
from abc import abstractmethod
import time

import annoy
import faiss
import numpy as np
from sklearn.neighbors import NearestNeighbors

import pynear


# Supported 3rd party indices are: FaissIndexFlatL2, FaissIndexBinaryFlat, AnnoyL2, AnnoyManhattan, AnnoyHamming, SKLearnL2
class IndexAdapter(ABC):
    @abstractmethod
    def build_index(self, data: np.ndarray):
        pass

    def clock_search(self, query: np.ndarray, k: int) -> float:
        """
        Searchs in index and retrieves the time it took to search
        """
        s = time.time()
        self._search_implementation(query, k)
        return time.time() - s

    @abstractmethod
    def _search_implementation(self, query, k: int):
        pass


class PyNearVPAdapter(IndexAdapter):
    def __init__(self, pyvp_index_name: str):
        self._index = None
        self._pyvp_index_name = pyvp_index_name
        self._pyvp_index_map = {
            "VPTreeL2Index": pynear.VPTreeL2Index,
            "VPTreeBinaryIndex": pynear.VPTreeBinaryIndex,
            "VPTreeChebyshevIndex": pynear.VPTreeChebyshevIndex,
            "VPTreeL1Index": pynear.VPTreeL1Index,
        }

    def build_index(self, data: np.ndarray):
        self._index = self._pyvp_index_map[self._pyvp_index_name]()
        self._index.set(data)

    def _search_implementation(self, query, k: int):
        self._index.searchKNN(query, k)


class PyNearBKTreeAdapter(IndexAdapter):
    def __init__(self):
        self._index = pynear.BKTreeBinaryIndex()
        self._dimensions = 0

    def build_index(self, data: np.ndarray):
        self._index.set(data)
        self._dimensions = data.shape[1]

    def _search_implementation(self, query, k: int):
        self._index.find_threshold(query, self._dimensions)


class FaissIndexFlatL2Adapter(IndexAdapter):
    def __init__(self):
        self._index = None

    def build_index(self, data: np.ndarray):
        d = data.shape[1]
        self._index = faiss.IndexFlatL2(d)
        self._index.add(data)

    def _search_implementation(self, query, k: int):
        self._index.search(query, k=k)


class FaissIndexBinaryFlatAdapter(IndexAdapter):
    def __init__(self):
        self._index = None

    def build_index(self, data: np.ndarray):
        d = data.shape[1] * 8
        self._index = faiss.IndexBinaryFlat(d)
        self._index.add(data)

    def _search_implementation(self, query, k: int):
        self._index.search(query, k=k)


class AnnoyL2Adapter(IndexAdapter):
    def __init__(self):
        self._index = None
        pass

    def build_index(self, data: np.ndarray):
        self._index = annoy.AnnoyIndex(data.shape[1], "euclidean")
        for i, v in enumerate(data):
            self._index.add_item(i, v)

        self._index.build(10)

    def _search_implementation(self, query, k: int):
        for v in query:
            self._index.get_nns_by_vector(v, k)


class AnnoyManhattanAdapter(IndexAdapter):
    def __init__(self):
        self._index = None

    def build_index(self, data: np.ndarray):
        self._index = annoy.AnnoyIndex(data.shape[1], "manhattan")
        for i, v in enumerate(data):
            self._index.add_item(i, v)

    def _search_implementation(self, query, k: int):
        for v in query:
            self._index.get_nns_by_vector(v, k)


class AnnoyHammingAdapter(IndexAdapter):
    def __init__(self):
        self._index = None

    def build_index(self, data: np.ndarray):
        self._index = annoy.AnnoyIndex(data.shape[1], "hamming")
        for i, v in enumerate(data):
            self._index.add_item(i, v)

        self._index.build(10)

    def _search_implementation(self, query, k: int):
        for v in query:
            self._index.get_nns_by_vector(v, k)


class IVFFlatL2Adapter(IndexAdapter):
    """Approximate L2 index using IVFFlatL2Index (IVF-style flat BLAS scan)."""

    def __init__(self, n_probe: int = 10):
        self._n_probe = n_probe
        self._index = None

    def build_index(self, data: np.ndarray):
        n_clusters = max(10, int(np.sqrt(len(data))))
        self._index = pynear.IVFFlatL2Index(
            n_clusters=n_clusters,
            n_probe=min(self._n_probe, n_clusters),
        )
        self._index.set(data)

    def _search_implementation(self, query, k: int):
        self._index.searchKNN(query, k)

    def search(self, query: np.ndarray, k: int):
        return self._index.searchKNN(query, k)


class FaissIVFAdapter(IndexAdapter):
    """Approximate L2 index using Faiss IndexIVFFlat (standard IVF baseline)."""

    def __init__(self, n_probe: int = 10):
        self._n_probe = n_probe
        self._index = None

    def build_index(self, data: np.ndarray):
        d = data.shape[1]
        n_clusters = max(10, int(np.sqrt(len(data))))
        quantizer = faiss.IndexFlatL2(d)
        self._index = faiss.IndexIVFFlat(quantizer, d, n_clusters, faiss.METRIC_L2)
        self._index.train(data)
        self._index.add(data)
        self._index.nprobe = min(self._n_probe, n_clusters)

    def _search_implementation(self, query, k: int):
        self._index.search(query, k)

    def search(self, query: np.ndarray, k: int):
        distances, indices = self._index.search(query, k)
        return indices.tolist(), distances.tolist()


class SKLearnL2Adapter(IndexAdapter):
    def __init__(self):
        self._index = None

    def build_index(self, data: np.ndarray):
        self._data = data
        pass

    def _search_implementation(self, query, k: int):
        # sklearn uses index based on k, so need to build on the fly
        pass

    def clock_search(self, query: np.ndarray, k: int) -> float:
        """
        Searchs in index and retrieves the time it took to search
        """
        # sklearn uses index based on k, so need to build on the fly
        # we will not clock index training stage
        self._index = NearestNeighbors(n_neighbors=k, algorithm="kd_tree", metric="euclidean")
        self._index.fit(self._data)

        s = time.time()
        self._index.kneighbors(query)
        return time.time() - s


def create_index_adapter(index_name: str):
    """
    Factory for index adapters.

    Supported names:
      VPTreeL2Index, VPTreeL1Index, VPTreeBinaryIndex, VPTreeChebyshevIndex
      IVFFlatL2Index, IVFFlatL2Index_nprobeN   (approximate, n_probe=N)
      FaissIndexFlatL2, FaissIndexBinaryFlat
      FaissIVFL2, FaissIVFL2_nprobeN             (approximate, n_probe=N)
      AnnoyL2, AnnoyManhattan, AnnoyHamming
      SKLearnL2, BKTreeBinaryIndex
    """
    if index_name.startswith("IVFFlatL2Index"):
        n_probe = int(index_name.split("_nprobe")[1]) if "_nprobe" in index_name else 10
        return IVFFlatL2Adapter(n_probe=n_probe)

    if index_name.startswith("FaissIVFL2"):
        n_probe = int(index_name.split("_nprobe")[1]) if "_nprobe" in index_name else 10
        return FaissIVFAdapter(n_probe=n_probe)

    if index_name.startswith("VPTree"):
        return PyNearVPAdapter(index_name)

    mapper = {
        "FaissIndexFlatL2": FaissIndexFlatL2Adapter,
        "FaissIndexBinaryFlat": FaissIndexBinaryFlatAdapter,
        "AnnoyL2": AnnoyL2Adapter,
        "AnnoyManhattan": AnnoyManhattanAdapter,
        "AnnoyHamming": AnnoyHammingAdapter,
        "SKLearnL2": SKLearnL2Adapter,
        "BKTreeBinaryIndex": PyNearBKTreeAdapter,
    }
    if index_name not in mapper:
        raise ValueError(f"Index name '{index_name}' not supported")
    return mapper[index_name]()
