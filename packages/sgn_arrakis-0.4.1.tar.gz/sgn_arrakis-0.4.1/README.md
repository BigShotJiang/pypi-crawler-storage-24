<h1 align="center">sgn-arrakis</h1>

<p align="center"><a href="https://git.ligo.org/ngdd/arrakis-python">Arrakis</a> source and sink elements for <a href="https://git.ligo.org/greg/sgn-ts">sgn-ts</a></p>

<p align="center">
  <a href="https://git.ligo.org/ngdd/sgn-arrakis/-/pipelines/latest">
    <img alt="ci" src="https://git.ligo.org/ngdd/sgn-arrakis/badges/main/pipeline.svg" />
  </a>
  <a href="https://git.ligo.org/ngdd/sgn-arrakis/-/pipelines/latest">
    <img alt="coverage" src="https://git.ligo.org/ngdd/sgn-arrakis/badges/main/coverage.svg" />
  </a>
  <a href="https://docs.ligo.org/ngdd/sgn-arrakis">
    <img alt="documentation" src="https://img.shields.io/badge/docs-mkdocs%20material-blue.svg?style=flat" />
  </a>
  <a href="https://pypi.org/project/sgn-arrakis/">
    <img alt="pypi version" src="https://img.shields.io/pypi/v/sgn-arrakis.svg" />
  </a>
</p>

---

## Resources

* [Documentation](https://docs.ligo.org/ngdd/sgn-arrakis)
* [Source Code](https://git.ligo.org/ngdd/sgn-arrakis)
* [Issue Tracker](https://git.ligo.org/ngdd/sgn-arrakis/-/issues)

## Installation

```
pip install sgn-arrakis
```

## Quickstart

### Stream data from Arrakis

``` python
from sgn_arrakis import ArrakisSource
from sgn.apps import Pipeline

src = ArrakisSource(
    source_pad_names=["L1:GDS-CALIB_STRAIN"],
    start=1187008882,
    duration=64,
)

pipeline = Pipeline()
pipeline.insert(src, ...)
pipeline.run()
```

### Publish data to Arrakis

``` python
from sgn_arrakis import ArrakisSink
from sgn.apps import Pipeline

sink = ArrakisSink(
    publisher_id="my-publisher-id",
    sink_pad_names=["H1:GDS-CALIB_STRAIN"],
)

pipeline = Pipeline()
pipeline.insert(..., sink)
pipeline.run()
```
