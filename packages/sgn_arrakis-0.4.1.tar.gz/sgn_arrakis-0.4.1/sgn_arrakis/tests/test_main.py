"""Tests for the sgn-arrakis CLI."""

from sgn_arrakis.__main__ import main

FAKE_H1_CHANNELS = [
    "H1:TEST-CHANNEL_SIN",
    "H1:TEST-CHANNEL_COS",
    "H1:TEST-STATE_ONES",
]


def test_source(arrakis_server):
    """Test the 'source' subcommand with the mock Arrakis server."""
    main(["source", *FAKE_H1_CHANNELS, "--start", "1000000000", "--duration", "10"])


def test_sink(arrakis_sink_publisher):
    """Test the 'sink' subcommand with the mock publisher."""
    _publisher, published_blocks = arrakis_sink_publisher
    main(["sink", "FAKE_H1", "--duration", "1"])
    assert len(published_blocks) > 0
