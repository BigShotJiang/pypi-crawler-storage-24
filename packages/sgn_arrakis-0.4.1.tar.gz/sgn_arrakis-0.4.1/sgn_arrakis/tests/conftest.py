# Skip entire module if arrakis-server not available (Python < 3.11)
from unittest.mock import patch

import pytest

pytest.importorskip("arrakis_server")


@pytest.fixture
def arrakis_sink_publisher(arrakis_mock_publisher):
    """Mock publisher adapted for ArrakisSink pipeline tests."""
    publisher, _fake_producer, published_blocks = arrakis_mock_publisher
    with patch("sgn_arrakis.sink.Publisher", return_value=publisher):
        yield publisher, published_blocks
