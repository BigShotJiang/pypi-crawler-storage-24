"""Tests for ArrakisSink."""

from unittest.mock import patch

import numpy
import pytest
from arrakis import SeriesBlock
from arrakis.block import Freq, Time
from sgn import Pipeline, SignalEOS
from sgnts.sources import FakeSeriesSource

from sgn_arrakis import ArrakisSink


def _fake_h1_channels(arrakis_channels):
    """Filter arrakis_channels to FAKE_H1 publisher channels."""
    return {
        name: ch for name, ch in arrakis_channels.items() if ch.publisher == "FAKE_H1"
    }


def _make_fake_source(channels, duration=1.0):
    """Build a FakeSeriesSource matching channel metadata."""
    signals = {}
    for name, ch in channels.items():
        signals[name] = {
            "signal_type": "const",
            "sample_shape": (1,),
            "rate": ch.sample_rate,
            "const": 1,
        }
    return FakeSeriesSource(
        source_pad_names=list(channels),
        signals=signals,
        duration=duration,
    )


def _run_sink_pipeline(channels, duration=1.0):
    """Build and run a FakeSeriesSource -> ArrakisSink pipeline."""
    source = _make_fake_source(channels, duration=duration)
    sink = ArrakisSink(
        publisher_id="FAKE_H1",
        sink_pad_names=list(channels),
    )
    pipeline = Pipeline()
    pipeline.connect(source, sink)
    with SignalEOS():
        pipeline.run()
    return sink, source


def test_raises_on_channel_mismatch(arrakis_mock_publisher):
    """Sink pads that don't match publisher channels raises ValueError in start()."""
    publisher, _, _ = arrakis_mock_publisher
    mismatched_pads = ["H1:WRONG-CHANNEL"]
    with patch("sgn_arrakis.sink.Publisher", return_value=publisher):
        sink = ArrakisSink(
            publisher_id="FAKE_H1",
            sink_pad_names=mismatched_pads,
        )
        with pytest.raises(ValueError, match="sink pad names do not match"):
            sink.start()


def test_publishes_blocks(arrakis_sink_publisher, arrakis_channels):
    """Run 1-second pipeline and verify blocks are published."""
    _, published_blocks = arrakis_sink_publisher
    channels = _fake_h1_channels(arrakis_channels)
    _run_sink_pipeline(channels, duration=1.0)
    assert len(published_blocks) > 0, "Expected at least one published block"
    for block in published_blocks:
        assert isinstance(block, SeriesBlock)


def test_published_blocks_have_all_channels(arrakis_sink_publisher, arrakis_channels):
    """Each published SeriesBlock contains all FAKE_H1 channel names."""
    _, published_blocks = arrakis_sink_publisher
    channels = _fake_h1_channels(arrakis_channels)
    _run_sink_pipeline(channels, duration=1.0)
    expected = set(channels)
    for block in published_blocks:
        assert set(block.keys()) == expected


def test_block_timestamps_are_sequential(arrakis_sink_publisher, arrakis_channels):
    """Timestamps from successive blocks are strictly increasing."""
    _, published_blocks = arrakis_sink_publisher
    channels = _fake_h1_channels(arrakis_channels)
    _run_sink_pipeline(channels, duration=2.0)
    assert len(published_blocks) >= 2, "Need at least 2 blocks to check ordering"
    timestamps = [block.start_ns for block in published_blocks]
    for i in range(1, len(timestamps)):
        assert timestamps[i] > timestamps[i - 1], (
            f"Block timestamps not increasing: {timestamps[i - 1]} >= {timestamps[i]}"
        )


def test_block_data_integrity(arrakis_sink_publisher, arrakis_channels):
    """Verify dtype and sample count for each channel in each block."""
    _, published_blocks = arrakis_sink_publisher
    channels = _fake_h1_channels(arrakis_channels)
    _run_sink_pipeline(channels, duration=1.0)

    block_duration_s = (16 * Freq.Hz) / Time.s  # default block_duration in seconds

    for block in published_blocks:
        for name, ch in channels.items():
            data = block[name]
            expected_dtype = numpy.dtype(ch.data_type)
            assert data.dtype == expected_dtype, (
                f"{name}: expected dtype {expected_dtype}, got {data.dtype}"
            )
            expected_samples = int(ch.sample_rate * block_duration_s)
            assert len(data) == expected_samples, (
                f"{name}: expected {expected_samples} samples, got {len(data)}"
            )
