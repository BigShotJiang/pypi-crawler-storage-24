# Copyright (c) 2024, California Institute of Technology and contributors
#
# You should have received a copy of the licensing terms for this
# software included in the file "LICENSE" located in the top-level
# directory of this package. If you did not, you can view a copy at
# https://git.ligo.org/ngdd/sgn-arrakis/-/raw/main/LICENSE

"""Arrakis sink element."""

from __future__ import annotations

import queue
import threading
from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy
import numpy.ma
from arrakis import Publisher, SeriesBlock
from arrakis.block import Freq
from sgnts.base import Offset, SeriesBuffer, TSFrame, TSSink

if TYPE_CHECKING:
    from collections.abc import Iterable

    from sgn.base import SinkPad


def buffers_to_masked_array(
    bufs: Iterable[SeriesBuffer],
    dtype: numpy.dtype,
) -> numpy.ma.MaskedArray:
    """convert list of SeriesBuffer objects into a numpy masked array

    Returns a single masked array, with the data from all buffers in
    the frame, with the data from gap bufers masked out.

    """
    return numpy.ma.concatenate(
        [
            numpy.ma.array(
                buf.filleddata(),
                mask=buf.data is None,
                dtype=dtype,
            )
            for buf in bufs
        ]
    )


@dataclass(kw_only=True)
class ArrakisSink(TSSink):
    """Sink element that streams channel data to Arrakis.

    Sink pads should be named after the channel that they will
    publish into Arrakis.

    Parameters
    ----------
    publisher_id : str
        admin-assigned publisher ID
    block_duration : int
        the duration (in nanoseconds) of data to publish in a single block.
        Default is 1/16th of a second.

    """

    publisher_id: str
    block_duration: int = 16 * Freq.Hz

    def configure(self) -> None:
        """Configure the ArrakisSink."""
        # ensure data is aligned to block_duration boundaries
        stride = Offset.fromns(self.block_duration)
        self.adapter_config.alignment(stride=stride, align_to=stride)

        self.publisher: Publisher = Publisher(self.publisher_id)
        self.queue: queue.Queue = queue.Queue()
        self.exception_event: threading.Event = threading.Event()
        # publish in a background thread so that we don't eat time
        # from the main sgn graph execution (makes internal pad
        # execution ~10x faster)
        self.thread: threading.Thread = threading.Thread(target=self._arrakis_publish)

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.publisher.register()
        pub_chans = set(self.publisher.channels.keys())
        if set(self.sink_pad_names) != pub_chans:
            msg = f"sink pad names do not match all publisher channels {pub_chans}"
            raise ValueError(msg)
        self.thread.start()

    def stop(self):
        if self.thread and self.thread.is_alive():
            self.thread.join()

    def _arrakis_publish(self) -> None:
        # FIXME: check that we're not falling behind, maybe by
        # checking that the queue isn't growing in size
        try:
            with self.publisher as publisher:
                while True:
                    if self.at_eos:
                        break
                    try:
                        sblock = self.queue.get(
                            block=True,
                            timeout=1,
                        )
                    except queue.Empty:
                        continue
                    publisher.publish(sblock)
        except Exception:
            self.exception_event.set()
            raise

    def process(self, input_frames: dict[SinkPad, TSFrame]) -> None:
        """Process input frames and publish to Arrakis.

        Parameters
        ----------
        input_frames : dict[SinkPad, TSFrame]
            mapping of sink pads to their input frames
        """
        if self.exception_event.is_set():
            self.stop()
            msg = "exception raised in resource thread, aborting."
            raise RuntimeError(msg)

        self.start()

        time_ns: int | None = None
        series: dict[str, numpy.ma.MaskedArray] = {}

        for pad, frame in input_frames.items():
            channel_name = pad.pad_name
            channel = self.publisher.channels[channel_name]

            if frame.EOS:
                self.mark_eos(pad)

            time_ns = Offset.tons(frame.offset)
            # FIXME: check continuity

            data = buffers_to_masked_array(frame, numpy.dtype(channel.data_type))

            assert frame.sample_rate == channel.sample_rate
            assert data.dtype == channel.data_type

            series[channel_name] = data.reshape(-1)

        assert time_ns is not None

        sblock = SeriesBlock(
            time_ns,
            series,
            self.publisher.channels,
        )

        self.queue.put(sblock)

        if self.at_eos:
            self.stop()
