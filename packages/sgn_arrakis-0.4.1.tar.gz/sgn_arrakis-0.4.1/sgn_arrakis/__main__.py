# Copyright (c) 2024, California Institute of Technology and contributors
#
# You should have received a copy of the licensing terms for this
# software included in the file "LICENSE" located in the top-level
# directory of this package. If you did not, you can view a copy at
# https://git.ligo.org/ngdd/sgn-arrakis/-/raw/main/LICENSE

"""sgn-arrakis CLI."""

from __future__ import annotations

import argparse
import logging
import os
from typing import TYPE_CHECKING

from arrakis import Client
from sgn import Pipeline, SignalEOS
from sgnts.sinks import NullSeriesSink
from sgnts.sources import FakeSeriesSource

from . import ArrakisSink, ArrakisSource, __version__

if TYPE_CHECKING:
    from sgn.base import SinkElement, SourceElement


def main(argv: list[str] | None = None) -> None:
    for logname in ["sgn-ts", "arrakis"]:
        logger = logging.getLogger(logname)
        logger.setLevel(os.getenv("LOG_LEVEL", "DEBUG").upper())
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(asctime)s %(name)s %(message)s"))
        logger.addHandler(handler)

    parser = argparse.ArgumentParser(
        description="Arrakis Source/Sink test application",
    )

    parser.add_argument(
        "--version",
        action="version",
        version=__version__,
    )
    parser.add_argument(
        "--url",
        "-u",
        type=str,
        help="initial server url",
    )

    subparsers = parser.add_subparsers(
        title="subcommands",
        metavar="",
        dest="cmd",
    )

    sp = subparsers.add_parser(
        "source",
        help="channel streaming (ArrakisSource to NullSeriesSink)",
    )
    sp.add_argument(
        "channels",
        metavar="channel",
        nargs="+",
        help="channels to stream",
    )
    sp.add_argument(
        "--start",
        type=float,
        default=None,
        help="start time in GPS seconds",
    )
    egroup = sp.add_mutually_exclusive_group()
    egroup.add_argument(
        "--end",
        type=float,
        default=None,
        help="end time in GPS seconds",
    )
    egroup.add_argument(
        "--duration",
        type=float,
        default=None,
        help="duration in seconds",
    )

    sp = subparsers.add_parser(
        "sink",
        help="channel publication (FakeSeriesSource to ArrakisSink)",
        description="This will stream zeros to all publisher channels.",
    )
    sp.add_argument(
        "publisher_id",
        help="publisher ID",
    )
    sp.add_argument(
        "--include-gaps",
        dest="ngap",
        action="store_const",
        const=-1,
        default=0,
        help="include gaps in the source stream",
    )
    sp.add_argument(
        "--start",
        type=float,
        default=None,
        help="start time in GPS seconds",
    )
    egroup = sp.add_mutually_exclusive_group()
    egroup.add_argument(
        "--end",
        type=float,
        default=None,
        help="end time in GPS seconds",
    )
    egroup.add_argument(
        "--duration",
        type=float,
        default=None,
        help="duration in seconds",
    )

    args = parser.parse_args(argv)

    source: SourceElement
    sink: SinkElement

    if args.cmd == "source":
        channels = args.channels

        source = ArrakisSource(
            source_pad_names=channels,
            start=args.start,
            end=args.end,
            duration=args.duration,
        )
        sink = NullSeriesSink(
            sink_pad_names=channels,
            verbose=True,
        )

    elif args.cmd == "sink":
        channels = {
            channel.name: channel
            for channel in Client(args.url).find(publisher=args.publisher_id)
        }

        signals = {}
        for name, channel in channels.items():
            signals[name] = {
                "signal_type": "const",
                "sample_shape": (1,),
                "rate": channel.sample_rate,
                "const": 1,
            }

        source = FakeSeriesSource(
            source_pad_names=list(channels),
            signals=signals,
            start=args.start,
            end=args.end,
            duration=args.duration,
            ngap=args.ngap,
            real_time=True,
        )
        sink = ArrakisSink(
            publisher_id=args.publisher_id,
            sink_pad_names=list(channels),
        )

    pipeline = Pipeline()
    pipeline.connect(source, sink)
    with SignalEOS():
        pipeline.run()


if __name__ == "__main__":
    main()
