"""
AlvitrSentinel - Automated Scientific Literature Monitoring Pipeline

Fetches RSS/Atom feeds daily, performs AI-powered summarization, topic
classification, and relevance scoring, then generates HTML daily briefings
and a cumulative dashboard for convenient manual archiving to Zotero.
"""

__version__ = "1.0.0"
__author__ = "AlvitrSentinel Contributors"

from alvitr_sentinel.fetcher import Fetcher
from alvitr_sentinel.parser import Parser
from alvitr_sentinel.ai_engine import AIEngine
from alvitr_sentinel.storage import Storage
from alvitr_sentinel.report_generator import ReportGenerator

__all__ = [
    "Fetcher",
    "Parser",
    "AIEngine",
    "Storage",
    "ReportGenerator",
    "__version__",
]
