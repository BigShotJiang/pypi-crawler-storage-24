#!/usr/bin/env python3
"""
pipeline.py - AlvitrSentinel CLI and Pipeline Orchestrator

Main entry point that orchestrates the full literature monitoring workflow:
Fetch -> Parse -> Deduplicate -> AI Process -> Store -> Report.
Provides several run modes via command-line arguments:

  alvitr-sentinel                 Full pipeline run
  alvitr-sentinel --init          Initialize project directory
  alvitr-sentinel --fetch-only    Fetch and parse only, skip AI
  alvitr-sentinel --no-ai         Skip AI processing, still store and report
  alvitr-sentinel --report-only   Regenerate reports from existing data
  alvitr-sentinel --date DATE     Process a specific date
  alvitr-sentinel -v              Verbose logging
"""

import argparse
import logging
import sys
import os
import shutil
from datetime import date, datetime
from pathlib import Path

import yaml
from tqdm import tqdm

from alvitr_sentinel import __version__
from alvitr_sentinel.fetcher import Fetcher
from alvitr_sentinel.parser import Parser
from alvitr_sentinel.ai_engine import AIEngine
from alvitr_sentinel.storage import Storage
from alvitr_sentinel.report_generator import ReportGenerator

logger = logging.getLogger('alvitr_sentinel.pipeline')

# Package resource directories
PACKAGE_DIR = Path(__file__).parent
DEFAULTS_DIR = PACKAGE_DIR / 'defaults'


# ======================================================================
#  Configuration loading
# ======================================================================
def load_config(config_path='config.yaml', project_root=None):
    """Load and validate the YAML configuration file."""
    project_root = project_root or Path.cwd()
    config_file = project_root / config_path

    if not config_file.exists():
        print(f"Error: Configuration file not found: {config_file}")
        print("   Please run: alvitr-sentinel --init")
        sys.exit(1)

    with open(config_file, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    # Resolve relative paths against the project root
    for key in ('feeds', 'data_dir', 'reports_dir', 'logs_dir'):
        if key in config.get('paths', {}):
            p = config['paths'][key]
            if not os.path.isabs(p):
                config['paths'][key] = str(project_root / p)

    # Template directory: prefer user-configured, fall back to bundled
    templates_key = config.get('paths', {}).get('templates_dir', '')
    if templates_key:
        templates_path = Path(templates_key)
        if not templates_path.is_absolute():
            templates_path = project_root / templates_key
        if templates_path.is_dir():
            config['paths']['templates_dir'] = str(templates_path)
        else:
            config['paths']['templates_dir'] = str(PACKAGE_DIR / 'templates')
    else:
        config['paths']['templates_dir'] = str(PACKAGE_DIR / 'templates')

    return config


def validate_config(config):
    """Check that critical configuration values have been filled in."""
    warnings = []

    api_key = config.get('ai', {}).get('llm', {}).get('api_key', '')
    if not api_key or api_key.startswith('your-') or 'YOUR_' in api_key:
        warnings.append("LLM API key not configured -> AI processing will be skipped")

    interests = config.get('research_interests', '')
    if not interests or 'Please fill' in interests or interests.strip().endswith('...'):
        warnings.append("Research interests not configured -> AI scoring will use default strategy")

    feeds_path = config.get('paths', {}).get('feeds', '')
    if not Path(feeds_path).exists():
        warnings.append(f"Feed list file not found: {feeds_path}")

    return warnings


# ======================================================================
#  Project initialization
# ======================================================================
def init_project(project_root=None):
    """Initialize the project directory structure and default config files."""
    project_root = project_root or Path.cwd()

    print(f"Initializing AlvitrSentinel v{__version__}...\n")

    # Create directory structure
    dirs = [
        'data/cache', 'data/articles', 'data/reports/daily',
        'templates', 'logs',
    ]
    for d in dirs:
        p = project_root / d
        p.mkdir(parents=True, exist_ok=True)
        print(f"  [dir] {d}/")

    # Copy default configuration
    config_file = project_root / 'config.yaml'
    if config_file.exists():
        print(f"\n  [ok] config.yaml already exists")
    else:
        default_config = DEFAULTS_DIR / 'config.yaml'
        if default_config.exists():
            shutil.copy2(default_config, config_file)
            print(f"\n  [new] config.yaml created (please edit API key and research interests)")
        else:
            print(f"\n  [err] Default config.yaml not found, please create manually")

    # Copy default feed list
    feeds_file = project_root / 'journal-feeds.txt'
    if feeds_file.exists():
        count = sum(1 for line in feeds_file.read_text().splitlines()
                    if line.strip() and not line.strip().startswith('#'))
        print(f"  [ok] journal-feeds.txt already exists ({count} feeds)")
    else:
        default_feeds = DEFAULTS_DIR / 'journal-feeds.txt'
        if default_feeds.exists():
            shutil.copy2(default_feeds, feeds_file)
            count = sum(1 for line in feeds_file.read_text().splitlines()
                        if line.strip() and not line.strip().startswith('#'))
            print(f"  [new] journal-feeds.txt created ({count} feeds)")
        else:
            print(f"  [err] Default journal-feeds.txt not found")

    # Copy default templates
    templates_dir = project_root / 'templates'
    pkg_templates = PACKAGE_DIR / 'templates'
    for tmpl_name in ('daily_report.html', 'dashboard.html'):
        src = pkg_templates / tmpl_name
        dst = templates_dir / tmpl_name
        if not dst.exists() and src.exists():
            shutil.copy2(src, dst)
            print(f"  [new] templates/{tmpl_name} created")

    # Check Python dependencies
    print("\nChecking dependencies...")
    missing = []
    for pkg in ('feedparser', 'requests', 'openai', 'jinja2', 'yaml', 'bs4', 'lxml', 'tqdm'):
        try:
            __import__(pkg)
            print(f"  [ok] {pkg}")
        except ImportError:
            print(f"  [missing] {pkg}")
            missing.append(pkg)

    if missing:
        print(f"\nMissing dependencies. Please run:")
        print(f"   pip install alvitr-sentinel")
    else:
        print(f"\nAll dependencies installed.")

    print("\nNext steps:")
    print("  1. Edit config.yaml (fill in API key and research interests)")
    print("  2. Review journal-feeds.txt (add/remove feed sources)")
    print("  3. Run: alvitr-sentinel")
    print()


# ======================================================================
#  Main pipeline
# ======================================================================
def run_pipeline(config, args):
    """Execute the full Fetch -> Parse -> AI -> Store -> Report pipeline."""
    target_date = args.date or date.today().isoformat()

    print(f"\n{'='*60}")
    print(f"  AlvitrSentinel v{__version__} - {target_date}")
    print(f"{'='*60}\n")

    # Step 1: Fetch
    print("Step 1/5: Fetching RSS feeds...")
    fetcher = Fetcher(config)
    feed_results = fetcher.fetch_all()

    if not feed_results:
        print("Error: No feed data retrieved. Exiting.")
        return

    # Step 2: Parse
    print(f"\nStep 2/5: Parsing article metadata...")
    parser_module = Parser(config)
    all_articles = parser_module.parse_all_feeds(feed_results)

    if not all_articles:
        print("Error: No articles parsed. Exiting.")
        return

    # Step 3: Deduplicate
    storage = Storage(config)
    new_articles = storage.filter_new(all_articles)
    print(f"\nNew articles: {len(new_articles)} / Total: {len(all_articles)}")

    if not new_articles:
        print("No new articles to process.")
        if not args.fetch_only:
            _generate_reports(config, storage, target_date)
        return

    if args.fetch_only:
        print("\n--fetch-only mode: skipping further processing.")
        for a in new_articles:
            a['ai_processed'] = False
            a['ai_summary'] = ''
            a['ai_tags'] = []
            a['ai_relevance'] = 0
            a['ai_reasoning'] = ''
        storage.save_articles(new_articles, target_date)
        return

    # Step 4: AI processing
    if args.no_ai:
        print("\n--no-ai mode: skipping AI processing.")
        processed = new_articles
        for a in processed:
            a['ai_processed'] = False
            a['ai_summary'] = ''
            a['ai_tags'] = []
            a['ai_relevance'] = 0
            a['ai_reasoning'] = 'AI processing skipped'
    else:
        api_key = config.get('ai', {}).get('llm', {}).get('api_key', '')
        if not api_key or api_key.startswith('your-') or 'YOUR_' in api_key:
            print("\nWarning: API key not configured, skipping AI processing.")
            processed = new_articles
            for a in processed:
                a['ai_processed'] = False
                a['ai_summary'] = ''
                a['ai_tags'] = []
                a['ai_relevance'] = 0
                a['ai_reasoning'] = 'API key not configured'
        else:
            print(f"\nStep 3/5: AI processing {len(new_articles)} articles...")
            ai_engine = AIEngine(config)

            pbar = tqdm(total=len(new_articles), desc="AI Processing", unit="article")
            def progress_cb(done, total):
                pbar.n = done
                pbar.refresh()

            processed = ai_engine.process_articles(new_articles, progress_callback=progress_cb)
            pbar.close()

            if config.get('ai', {}).get('embedding', {}).get('enabled', False):
                print("\nComputing embeddings...")
                processed = ai_engine.compute_embeddings(processed)

            stats = ai_engine.get_stats()
            print(f"   API calls: {stats['llm_calls']} | "
                  f"Tokens: {stats['llm_tokens_in']}+{stats['llm_tokens_out']} | "
                  f"Errors: {stats['errors']}")

    # Step 5: Store
    print(f"\nStep 4/5: Saving data...")
    storage.save_articles(processed, target_date)

    # Step 6: Generate reports
    print(f"\nStep 5/5: Generating reports...")
    _generate_reports(config, storage, target_date)

    # Done
    print(f"\n{'='*60}")
    print(f"  Pipeline complete!")
    print(f"{'='*60}")
    _print_summary(processed, config)


def _generate_reports(config, storage, target_date):
    """Generate the daily briefing and cumulative dashboard."""
    reporter = ReportGenerator(config)

    today_articles = storage.load_articles(target_date)
    if today_articles:
        daily_path = reporter.generate_daily_report(today_articles, target_date)
        print(f"  Daily briefing: {daily_path}")
    else:
        print("  No articles for today, skipping daily briefing")

    max_days = config.get('dashboard', {}).get('max_days', 30)
    all_articles = storage.load_all_articles(max_days=max_days)
    if all_articles:
        dashboard_path = reporter.generate_dashboard(all_articles)
        print(f"  Dashboard:      {dashboard_path}")


def _print_summary(articles, config):
    """Print a post-run summary."""
    processed = [a for a in articles if a.get('ai_processed')]
    high = [a for a in articles if a.get('ai_relevance', 0) >= 4]

    print(f"\n  Processed: {len(articles)} articles")
    print(f"  AI success: {len(processed)} articles")

    if high:
        print(f"  Highly relevant: {len(high)} articles")
        for a in high[:5]:
            print(f"    [{a.get('ai_relevance')}] {a.get('journal', '?')} - {a['title'][:60]}")
        if len(high) > 5:
            print(f"    ... and {len(high)-5} more")

    reports_dir = config.get('paths', {}).get('reports_dir', 'data/reports')
    print(f"\n  Reports directory: {reports_dir}")
    print()


# ======================================================================
#  Report-only mode
# ======================================================================
def report_only_mode(config, args):
    """Regenerate reports from existing stored data."""
    target_date = args.date or date.today().isoformat()
    print(f"\nReport-only mode (date: {target_date})\n")

    storage = Storage(config)
    _generate_reports(config, storage, target_date)
    print("\nReport generation complete.")


# ======================================================================
#  Logging setup
# ======================================================================
def setup_logging(verbose=False, log_dir=None):
    """Configure console and file logging."""
    level = logging.DEBUG if verbose else logging.INFO

    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_fmt = logging.Formatter('%(message)s')
    console_handler.setFormatter(console_fmt)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.addHandler(console_handler)

    if log_dir:
        log_path = Path(log_dir)
        log_path.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(
            log_path / f"{date.today().isoformat()}.log",
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)
        file_fmt = logging.Formatter('%(asctime)s [%(name)s] %(levelname)s: %(message)s')
        file_handler.setFormatter(file_fmt)
        root.addHandler(file_handler)

    # Suppress noisy third-party loggers
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('openai').setLevel(logging.WARNING)
    logging.getLogger('httpx').setLevel(logging.WARNING)
    logging.getLogger('chardet').setLevel(logging.WARNING)
    logging.getLogger('charset_normalizer').setLevel(logging.WARNING)

    import warnings
    warnings.filterwarnings('ignore', category=UserWarning, module='bs4')


# ======================================================================
#  CLI entry point
# ======================================================================
def main():
    ap = argparse.ArgumentParser(
        description=f'AlvitrSentinel v{__version__} - Automated Scientific Literature Monitoring Pipeline',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  alvitr-sentinel                      Full pipeline run
  alvitr-sentinel --init               Initialize project
  alvitr-sentinel --fetch-only         Fetch only, no AI
  alvitr-sentinel --no-ai              Skip AI processing
  alvitr-sentinel --report-only        Regenerate reports
  alvitr-sentinel --date 2026-03-20    Specific date
  alvitr-sentinel -v                   Verbose logging
        """
    )
    ap.add_argument('--version', action='version',
                    version=f'AlvitrSentinel {__version__}')
    ap.add_argument('--init', action='store_true',
                    help='Initialize project directory and config')
    ap.add_argument('--config', default='config.yaml',
                    help='Path to config file (default: config.yaml)')
    ap.add_argument('--fetch-only', action='store_true',
                    help='Fetch and parse only, skip AI')
    ap.add_argument('--no-ai', action='store_true',
                    help='Skip AI processing, still store and report')
    ap.add_argument('--report-only', action='store_true',
                    help='Regenerate reports from existing data')
    ap.add_argument('--date',
                    help='Target date (YYYY-MM-DD)')
    ap.add_argument('--days', type=int,
                    help='Override dashboard display days')
    ap.add_argument('-v', '--verbose', action='store_true',
                    help='Enable verbose logging')

    args = ap.parse_args()

    if args.init:
        init_project()
        return

    config = load_config(args.config)

    if args.days:
        config.setdefault('dashboard', {})['max_days'] = args.days

    log_dir = config.get('paths', {}).get('logs_dir')
    setup_logging(args.verbose, log_dir)

    warnings = validate_config(config)
    for w in warnings:
        print(f"Warning: {w}")

    if args.report_only:
        report_only_mode(config, args)
    else:
        run_pipeline(config, args)


if __name__ == '__main__':
    main()
