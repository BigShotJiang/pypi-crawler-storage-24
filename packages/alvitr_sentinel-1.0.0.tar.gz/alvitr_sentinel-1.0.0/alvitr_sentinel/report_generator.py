"""
report_generator.py - HTML Report Generation Module

Produces two types of HTML reports using Jinja2 templates:
  1. Daily Briefing - articles grouped by relevance tier (high / medium / low)
  2. Cumulative Dashboard - a single-page application with full-text search,
     date-range filtering, topic tag filtering, relevance threshold slider,
     and sortable, paginated results.
"""

import json
import logging
from collections import Counter
from datetime import date
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

logger = logging.getLogger(__name__)

# Default template directory bundled with the package
_PACKAGE_TEMPLATES_DIR = Path(__file__).parent / 'templates'


class ReportGenerator:
    def __init__(self, config):
        self.reports_dir = Path(config['paths']['reports_dir'])
        self.daily_dir = self.reports_dir / 'daily'
        self.highlight_threshold = config.get('filter', {}).get('highlight_threshold', 4)
        self.min_relevance = config.get('filter', {}).get('min_relevance', 1)
        self.dashboard_max_days = config.get('dashboard', {}).get('max_days', 30)
        self.articles_per_page = config.get('dashboard', {}).get('articles_per_page', 50)

        self.daily_dir.mkdir(parents=True, exist_ok=True)

        # Template loading: prefer user-specified directory, fall back to bundled templates
        templates_dir = config.get('paths', {}).get('templates_dir', '')
        if templates_dir and Path(templates_dir).is_dir():
            self.templates_dir = Path(templates_dir)
        else:
            self.templates_dir = _PACKAGE_TEMPLATES_DIR

        self.env = Environment(
            loader=FileSystemLoader(str(self.templates_dir)),
            autoescape=False,
        )

    # ------------------------------------------------------------------
    #  Daily briefing
    # ------------------------------------------------------------------
    def generate_daily_report(self, articles, target_date=None):
        """
        Generate a daily briefing HTML report.

        Articles are grouped into relevance tiers: high (>= threshold),
        medium (2 to threshold-1), and low (below 2).
        """
        target_date = target_date or date.today().isoformat()

        # Filter and stratify by relevance
        filtered = [a for a in articles if a.get('ai_relevance', 0) >= self.min_relevance]
        high = [a for a in filtered if a.get('ai_relevance', 0) >= self.highlight_threshold]
        medium = [a for a in filtered if 2 <= a.get('ai_relevance', 0) < self.highlight_threshold]
        low = [a for a in filtered if a.get('ai_relevance', 0) < 2 and a.get('ai_relevance', 0) >= self.min_relevance]
        unscored = [a for a in articles if not a.get('ai_processed', False)]

        for lst in (high, medium, low):
            lst.sort(key=lambda x: x.get('ai_relevance', 0), reverse=True)

        stats = self._compute_stats(articles)

        template = self.env.get_template('daily_report.html')
        html = template.render(
            date=target_date,
            stats=stats,
            high_articles=high,
            medium_articles=medium,
            low_articles=low,
            unscored_articles=unscored,
            total_shown=len(filtered),
            total_all=len(articles),
        )

        output_path = self.daily_dir / f"{target_date}.html"
        output_path.write_text(html, encoding='utf-8')
        logger.info(f"Daily briefing generated: {output_path}")
        return output_path

    # ------------------------------------------------------------------
    #  Cumulative dashboard
    # ------------------------------------------------------------------
    def generate_dashboard(self, all_articles):
        """
        Generate a cumulative dashboard HTML (single-page application).

        The dashboard embeds all article data as JSON and provides
        client-side search, filtering, sorting, and pagination.
        """
        all_topics = set()
        all_journals = set()
        for a in all_articles:
            for tag in a.get('ai_tags', []):
                all_topics.add(tag)
            if a.get('journal'):
                all_journals.add(a['journal'])

        dates = [a.get('fetched_date', a.get('published_date', ''))
                 for a in all_articles if a.get('fetched_date') or a.get('published_date')]
        date_min = min(dates) if dates else ''
        date_max = max(dates) if dates else ''

        # Trim article data for embedding in HTML
        clean_articles = []
        for a in all_articles:
            clean = {
                'id': a.get('id', ''),
                'title': a.get('title', ''),
                'authors': a.get('authors', [])[:5],
                'abstract': (a.get('abstract', '') or '')[:500],
                'doi': a.get('doi', ''),
                'url': a.get('url', ''),
                'journal': a.get('journal', ''),
                'published_date': a.get('published_date', ''),
                'fetched_date': a.get('fetched_date', ''),
                'ai_summary': a.get('ai_summary', ''),
                'ai_tags': a.get('ai_tags', []),
                'ai_relevance': a.get('ai_relevance', 0),
                'ai_reasoning': a.get('ai_reasoning', ''),
                'ai_processed': a.get('ai_processed', False),
                'abstract_source': a.get('abstract_source', ''),
            }
            clean_articles.append(clean)

        template = self.env.get_template('dashboard.html')
        html = template.render(
            generated_date=date.today().isoformat(),
            articles_json=json.dumps(clean_articles, ensure_ascii=False),
            all_topics=sorted(all_topics),
            all_journals=sorted(all_journals),
            date_min=date_min,
            date_max=date_max,
            articles_per_page=self.articles_per_page,
            total_articles=len(clean_articles),
        )

        output_path = self.reports_dir / 'dashboard.html'
        output_path.write_text(html, encoding='utf-8')
        logger.info(f"Dashboard generated: {output_path}")
        return output_path

    # ------------------------------------------------------------------
    #  Statistics
    # ------------------------------------------------------------------
    @staticmethod
    def _compute_stats(articles):
        """Compute summary statistics for a collection of articles."""
        journal_counts = Counter(a.get('journal', 'Unknown') for a in articles)
        topic_counts = Counter()
        for a in articles:
            for tag in a.get('ai_tags', []):
                topic_counts[tag] += 1

        relevance_dist = Counter(a.get('ai_relevance', 0) for a in articles)
        processed = sum(1 for a in articles if a.get('ai_processed', False))

        return {
            'total': len(articles),
            'processed': processed,
            'high_relevance': sum(1 for a in articles if a.get('ai_relevance', 0) >= 4),
            'medium_relevance': sum(1 for a in articles if 2 <= a.get('ai_relevance', 0) < 4),
            'low_relevance': sum(1 for a in articles if 0 < a.get('ai_relevance', 0) < 2),
            'by_journal': dict(journal_counts.most_common(20)),
            'by_topic': dict(topic_counts.most_common(20)),
            'relevance_distribution': dict(relevance_dist),
        }
