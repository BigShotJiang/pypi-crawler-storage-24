"""Entry point for running as: python -m alvitr_sentinel"""
from alvitr_sentinel.pipeline import main

if __name__ == "__main__":
    main()
