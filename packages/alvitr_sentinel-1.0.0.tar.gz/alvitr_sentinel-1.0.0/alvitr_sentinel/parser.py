"""
parser.py - Article Metadata Extraction and Normalization Module

Extracts standardized metadata (title, authors, abstract, DOI, URL, etc.)
from parsed feed entries.  Implements a three-tier abstract acquisition
strategy: RSS-embedded content -> web-page scraping -> title-only fallback.
Normalizes heterogeneous publisher formats into a uniform schema.
"""

import re
import hashlib
import logging
import time
from datetime import datetime

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


class Parser:
    def __init__(self, config):
        parser_conf = config.get('parser', {})
        self.min_abstract_length = parser_conf.get('min_abstract_length', 100)
        self.scrape_enabled = parser_conf.get('scrape_abstract', True)
        self.scrape_timeout = parser_conf.get('scrape_timeout', 10)
        self.user_agent = config.get('fetcher', {}).get(
            'user_agent',
            'Mozilla/5.0 (compatible; AlvitrSentinel/1.0; +research)'
        )

    # ------------------------------------------------------------------
    #  Public parsing interface
    # ------------------------------------------------------------------
    def parse_feed(self, journal_name, feed):
        """Extract all articles from a single parsed feed."""
        articles = []
        for entry in feed.entries:
            article = self._extract_article(journal_name, entry)
            if article:
                articles.append(article)
        return articles

    def parse_all_feeds(self, feed_results):
        """
        Parse articles from all fetched feeds.

        Parameters
        ----------
        feed_results : list of (alias, feed_data)
            Return value of Fetcher.fetch_all().
        """
        all_articles = []
        for alias, feed in feed_results:
            articles = self.parse_feed(alias, feed)
            all_articles.extend(articles)
            logger.info(f"  [{alias}] parsed {len(articles)} articles")
        logger.info(f"Total parsed: {len(all_articles)} articles")
        return all_articles

    # ------------------------------------------------------------------
    #  Single article extraction
    # ------------------------------------------------------------------
    def _extract_article(self, journal_name, entry):
        """Extract normalized article data from a feed entry."""
        title = self._clean_html(entry.get('title', ''))
        if not title:
            return None

        url = entry.get('link', '')
        doi = self._extract_doi(entry)
        authors = self._extract_authors(entry)
        published = self._parse_date(entry)
        abstract, abstract_source = self._get_abstract(entry, url)

        # Unique ID: prefer DOI, fall back to URL/title hash
        article_id = doi if doi else hashlib.md5(
            (url or title).encode()
        ).hexdigest()[:16]

        return {
            'id': article_id,
            'title': title,
            'authors': authors,
            'abstract': abstract,
            'abstract_source': abstract_source,
            'doi': doi,
            'url': url,
            'journal': journal_name,
            'published_date': published,
        }

    # ------------------------------------------------------------------
    #  Three-tier abstract acquisition strategy
    # ------------------------------------------------------------------
    def _get_abstract(self, entry, url):
        """
        Acquire the abstract using a three-tier strategy:

        Tier 1 - RSS feed embedded description/summary
        Tier 2 - HTTP scrape of the article page abstract section
        Tier 3 - Title-only fallback (marked as 'title_only')
        """
        # Tier 1: RSS content
        abstract = self._extract_feed_abstract(entry)
        if abstract and len(abstract) >= self.min_abstract_length:
            return abstract, 'rss'

        # Tier 2: Web page scraping
        if self.scrape_enabled and url:
            scraped = self._scrape_abstract(url)
            if scraped and len(scraped) >= self.min_abstract_length:
                return scraped, 'scraped'

        # Tier 3: Fallback
        if abstract and len(abstract) > 20:
            return abstract, 'partial'
        return '', 'title_only'

    def _extract_feed_abstract(self, entry):
        """Try to extract abstract text from multiple feed entry fields."""
        candidates = []

        if hasattr(entry, 'summary'):
            candidates.append(entry.summary)

        if hasattr(entry, 'description') and entry.description != getattr(entry, 'summary', None):
            candidates.append(entry.description)

        if hasattr(entry, 'content'):
            for c in entry.content:
                val = c.get('value', '')
                if val:
                    candidates.append(val)

        # Pick the longest cleaned candidate
        best = ''
        for text in candidates:
            cleaned = self._clean_html(text)
            if len(cleaned) > len(best):
                best = cleaned

        return best

    def _scrape_abstract(self, url):
        """
        Scrape the abstract section from an article web page (Tier 2).

        Only targets the abstract region, not the full text.  Covers
        common selectors for Nature, Cell, OUP, bioRxiv, and others.
        """
        try:
            headers = {'User-Agent': self.user_agent}
            resp = requests.get(
                url, headers=headers, timeout=self.scrape_timeout,
                allow_redirects=True
            )
            if resp.status_code != 200:
                return None

            soup = BeautifulSoup(resp.text, 'lxml')

            selectors = [
                'div#Abs1', 'div#abstract', 'section#abstract',
                'div#Abs1-content',
                'div.c-article-section__content[id*="Abs"]',
                'div.abstract', 'section.abstract',
                'div.abstractSection', 'div.hlFld-Abstract',
                'div[class*="abstract"]', 'section[class*="abstract"]',
                'div.section.abstract',
                'meta[name="citation_abstract"]',
                'meta[name="description"]',
                'meta[property="og:description"]',
            ]

            for sel in selectors:
                if sel.startswith('meta'):
                    elem = soup.select_one(sel)
                    if elem and elem.get('content'):
                        text = elem['content'].strip()
                        if len(text) >= self.min_abstract_length:
                            return text
                else:
                    elem = soup.select_one(sel)
                    if elem:
                        text = elem.get_text(separator=' ', strip=True)
                        text = re.sub(r'^Abstract\s*', '', text, flags=re.IGNORECASE)
                        if len(text) >= self.min_abstract_length:
                            return text

            return None

        except Exception as e:
            logger.debug(f"Page scrape failed for {url}: {e}")
            return None

    # ------------------------------------------------------------------
    #  Metadata extraction helpers
    # ------------------------------------------------------------------
    def _extract_authors(self, entry):
        """Extract the author list from a feed entry."""
        authors = []
        if hasattr(entry, 'authors'):
            for a in entry.authors:
                name = a.get('name', '').strip()
                if name:
                    authors.append(name)
        elif hasattr(entry, 'author') and entry.author:
            authors = [entry.author.strip()]

        # Some feeds concatenate all authors into a single string
        if len(authors) == 1 and ', ' in authors[0]:
            authors = [a.strip() for a in authors[0].split(',')]

        return authors

    def _extract_doi(self, entry):
        """Extract a DOI identifier from a feed entry."""
        for attr in ('prism_doi', 'doi', 'dc_identifier'):
            val = getattr(entry, attr, '')
            if val and '10.' in val:
                doi = self._normalize_doi(val)
                if doi:
                    return doi

        entry_id = entry.get('id', '')
        doi = self._normalize_doi(entry_id)
        if doi:
            return doi

        link = entry.get('link', '')
        doi = self._normalize_doi(link)
        if doi:
            return doi

        return ''

    @staticmethod
    def _normalize_doi(text):
        """Extract and normalize a DOI from arbitrary text."""
        match = re.search(r'(10\.\d{4,}/[^\s<>"\']+)', text)
        if match:
            doi = match.group(1)
            doi = doi.rstrip('.,;:)')
            return doi
        return ''

    def _parse_date(self, entry):
        """Parse publication date and return a YYYY-MM-DD string."""
        for field in ('published_parsed', 'updated_parsed'):
            parsed = entry.get(field)
            if parsed:
                try:
                    return datetime(*parsed[:6]).strftime('%Y-%m-%d')
                except (TypeError, ValueError):
                    pass

        for field in ('published', 'updated', 'dc_date'):
            date_str = entry.get(field, '')
            if not date_str:
                continue
            for fmt in (
                '%Y-%m-%dT%H:%M:%S%z',
                '%Y-%m-%dT%H:%M:%S',
                '%Y-%m-%d',
                '%a, %d %b %Y %H:%M:%S %z',
                '%a, %d %b %Y %H:%M:%S %Z',
                '%a, %d %b %Y %H:%M:%S',
                '%d %b %Y',
            ):
                try:
                    return datetime.strptime(date_str[:30].strip(), fmt).strftime('%Y-%m-%d')
                except ValueError:
                    continue

        return datetime.now().strftime('%Y-%m-%d')

    # ------------------------------------------------------------------
    #  Text cleaning
    # ------------------------------------------------------------------
    @staticmethod
    def _clean_html(text):
        """Strip HTML tags and normalize whitespace."""
        if not text:
            return ''
        soup = BeautifulSoup(text, 'html.parser')
        text = soup.get_text(separator=' ', strip=True)
        text = re.sub(r'\s+', ' ', text).strip()
        return text
