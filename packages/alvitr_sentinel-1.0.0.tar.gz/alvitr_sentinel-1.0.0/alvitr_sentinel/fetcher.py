"""
fetcher.py - RSS/Atom Feed Fetcher Module

Reads a list of journal RSS/Atom feed URLs from a text file and fetches
each feed with support for ETag / If-Modified-Since conditional requests,
automatic retries with exponential back-off, configurable timeouts, and
raw XML caching organized by date.
"""

import json
import hashlib
import logging
import time
from datetime import date, datetime
from pathlib import Path

import feedparser
import requests

logger = logging.getLogger(__name__)


class Fetcher:
    def __init__(self, config):
        self.feeds_file = Path(config['paths']['feeds'])
        self.cache_dir = Path(config['paths']['data_dir']) / 'cache'
        fetcher_conf = config.get('fetcher', {})
        self.timeout = fetcher_conf.get('timeout', 15)
        self.retries = fetcher_conf.get('retries', 3)
        self.user_agent = fetcher_conf.get(
            'user_agent',
            'Mozilla/5.0 (compatible; AlvitrSentinel/1.0; +research)'
        )
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    #  Feed list loading
    # ------------------------------------------------------------------
    def load_feeds(self):
        """Parse journal-feeds.txt and return a list of (alias, url) tuples."""
        feeds = []
        with open(self.feeds_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if '|' in line:
                    alias, url = line.split('|', 1)
                    feeds.append((alias.strip(), url.strip()))
                else:
                    feeds.append((self._guess_alias(line.strip()), line.strip()))
        logger.info(f"Loaded {len(feeds)} feed sources")
        return feeds

    # ------------------------------------------------------------------
    #  Single feed fetching
    # ------------------------------------------------------------------
    def fetch_feed(self, alias, url):
        """
        Fetch a single RSS/Atom feed.

        Supports ETag / If-Modified-Since conditional requests to avoid
        redundant downloads.  Returns a feedparser.FeedParserDict on
        success, or None on failure.
        """
        today_str = date.today().isoformat()
        safe_name = self._safe_filename(alias)
        cache_file = self.cache_dir / today_str / f"{safe_name}.xml"
        cache_file.parent.mkdir(parents=True, exist_ok=True)

        # Load previous ETag / Last-Modified metadata
        meta_file = self.cache_dir / f"{safe_name}.meta.json"
        headers = {'User-Agent': self.user_agent}
        if meta_file.exists():
            try:
                meta = json.loads(meta_file.read_text(encoding='utf-8'))
                if meta.get('etag'):
                    headers['If-None-Match'] = meta['etag']
                if meta.get('last_modified'):
                    headers['If-Modified-Since'] = meta['last_modified']
            except (json.JSONDecodeError, KeyError):
                pass

        # Retry loop with exponential back-off
        for attempt in range(1, self.retries + 1):
            try:
                resp = requests.get(
                    url, headers=headers, timeout=self.timeout,
                    allow_redirects=True
                )

                if resp.status_code == 304:
                    logger.debug(f"  [{alias}] 304 Not Modified, using cache")
                    if cache_file.exists():
                        return feedparser.parse(cache_file.read_text(encoding='utf-8'))
                    # No cache available; retry without conditional headers
                    headers.pop('If-None-Match', None)
                    headers.pop('If-Modified-Since', None)
                    continue

                if resp.status_code == 200:
                    cache_file.write_text(resp.text, encoding='utf-8')
                    # Persist metadata for next conditional request
                    new_meta = {
                        'etag': resp.headers.get('ETag'),
                        'last_modified': resp.headers.get('Last-Modified'),
                        'fetched_at': datetime.now().isoformat(),
                    }
                    meta_file.write_text(
                        json.dumps(new_meta, ensure_ascii=False),
                        encoding='utf-8'
                    )
                    return feedparser.parse(resp.text)

                logger.warning(f"  [{alias}] HTTP {resp.status_code}, attempt {attempt}")

            except requests.RequestException as e:
                logger.warning(f"  [{alias}] Request error: {e}, attempt {attempt}")
                if attempt < self.retries:
                    time.sleep(2 ** (attempt - 1))

        logger.error(f"  [{alias}] Fetch failed after {self.retries} retries")
        return None

    # ------------------------------------------------------------------
    #  Batch fetching
    # ------------------------------------------------------------------
    def fetch_all(self):
        """
        Fetch all configured feed sources.

        Returns a list of (alias, feed_data) tuples containing only the
        feeds that were fetched successfully and have entries.
        """
        feeds = self.load_feeds()
        results = []
        failed = 0

        for alias, url in feeds:
            logger.info(f"Fetching: {alias}")
            feed = self.fetch_feed(alias, url)
            if feed and feed.entries:
                results.append((alias, feed))
                logger.info(f"  -> {len(feed.entries)} entries")
            else:
                failed += 1
                logger.warning(f"  -> no entries or fetch failed")

        logger.info(f"Fetch complete: {len(results)} succeeded, {failed} failed")
        return results

    # ------------------------------------------------------------------
    #  Helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _safe_filename(name):
        """Generate a filesystem-safe filename from an arbitrary string."""
        clean = ''.join(c if c.isalnum() or c in '-_ ' else '_' for c in name)
        clean = clean.strip()[:50]
        short_hash = hashlib.md5(name.encode()).hexdigest()[:8]
        return f"{clean}_{short_hash}" if clean else short_hash

    @staticmethod
    def _guess_alias(url):
        """Infer a short alias from a feed URL."""
        from urllib.parse import urlparse
        host = urlparse(url).netloc
        if host.startswith('www.'):
            host = host[4:]
        return host
