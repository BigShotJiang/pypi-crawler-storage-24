"""
storage.py - JSON File Storage Layer

Stores processed articles as date-partitioned JSON files, maintains a
deduplication index, and keeps embedding vectors in separate files to
control main data file size.  Provides query and statistics utilities.
"""

import json
import logging
from datetime import date
from pathlib import Path

logger = logging.getLogger(__name__)


class Storage:
    def __init__(self, config):
        self.data_dir = Path(config['paths']['data_dir'])
        self.articles_dir = self.data_dir / 'articles'
        self.index_file = self.articles_dir / 'index.json'

        self.articles_dir.mkdir(parents=True, exist_ok=True)
        self._index = self._load_index()

    # ------------------------------------------------------------------
    #  Index management
    # ------------------------------------------------------------------
    def _load_index(self):
        """Load the article ID index used for deduplication."""
        if self.index_file.exists():
            try:
                data = json.loads(self.index_file.read_text(encoding='utf-8'))
                return data
            except (json.JSONDecodeError, KeyError):
                logger.warning("Index file corrupted, rebuilding index")
        return {'articles': {}}

    def _save_index(self):
        """Persist the deduplication index to disk."""
        self.index_file.write_text(
            json.dumps(self._index, ensure_ascii=False, indent=2),
            encoding='utf-8'
        )

    # ------------------------------------------------------------------
    #  Deduplication
    # ------------------------------------------------------------------
    def is_duplicate(self, article_id):
        """Check whether an article has already been processed."""
        return article_id in self._index.get('articles', {})

    def filter_new(self, articles):
        """Filter out previously processed articles, keeping only new ones."""
        new = [a for a in articles if not self.is_duplicate(a['id'])]
        dup_count = len(articles) - len(new)
        if dup_count > 0:
            logger.info(f"Filtered {dup_count} duplicates, {len(new)} new articles remain")
        return new

    # ------------------------------------------------------------------
    #  Write
    # ------------------------------------------------------------------
    def save_articles(self, articles, target_date=None):
        """
        Save articles to a date-partitioned JSON file.

        Embedding vectors are separated into a dedicated file to keep the
        main article JSON compact.
        """
        if not articles:
            logger.info("No articles to save")
            return

        target_date = target_date or date.today().isoformat()
        file_path = self.articles_dir / f"{target_date}.json"

        # Load existing articles for this date
        existing = []
        if file_path.exists():
            try:
                existing = json.loads(file_path.read_text(encoding='utf-8'))
            except json.JSONDecodeError:
                existing = []

        # Separate embedding vectors from article data
        articles_to_save = []
        embeddings = {}
        for article in articles:
            a = dict(article)
            emb = a.pop('embedding', None)
            if emb is not None:
                embeddings[a['id']] = emb
            a['fetched_date'] = target_date
            articles_to_save.append(a)

        existing.extend(articles_to_save)

        # Write article JSON
        file_path.write_text(
            json.dumps(existing, ensure_ascii=False, indent=2),
            encoding='utf-8'
        )

        # Write embeddings to a separate file
        if embeddings:
            emb_file = self.articles_dir / f"{target_date}_embeddings.json"
            existing_emb = {}
            if emb_file.exists():
                try:
                    existing_emb = json.loads(emb_file.read_text(encoding='utf-8'))
                except json.JSONDecodeError:
                    existing_emb = {}
            existing_emb.update(embeddings)
            emb_file.write_text(json.dumps(existing_emb), encoding='utf-8')

        # Update deduplication index
        for article in articles_to_save:
            self._index['articles'][article['id']] = target_date
        self._save_index()

        logger.info(f"Saved {len(articles_to_save)} articles to {file_path.name}")

    # ------------------------------------------------------------------
    #  Read
    # ------------------------------------------------------------------
    def load_articles(self, target_date=None):
        """Load articles for a specific date."""
        target_date = target_date or date.today().isoformat()
        file_path = self.articles_dir / f"{target_date}.json"
        if file_path.exists():
            try:
                return json.loads(file_path.read_text(encoding='utf-8'))
            except json.JSONDecodeError:
                return []
        return []

    def load_all_articles(self, max_days=None):
        """
        Load all articles in reverse chronological order.

        Parameters
        ----------
        max_days : int, optional
            Limit to the most recent N days of data.
        """
        all_articles = []
        files = sorted(self.articles_dir.glob('????-??-??.json'), reverse=True)
        if max_days:
            files = files[:max_days]
        for f in files:
            try:
                articles = json.loads(f.read_text(encoding='utf-8'))
                all_articles.extend(articles)
            except json.JSONDecodeError:
                logger.warning(f"Failed to read {f.name}, skipping")
        return all_articles

    def load_all_embeddings(self):
        """Load all stored embedding vectors."""
        all_emb = {}
        for f in self.articles_dir.glob('*_embeddings.json'):
            try:
                emb = json.loads(f.read_text(encoding='utf-8'))
                all_emb.update(emb)
            except json.JSONDecodeError:
                pass
        return all_emb

    # ------------------------------------------------------------------
    #  Statistics
    # ------------------------------------------------------------------
    def get_stats(self):
        """Return storage statistics."""
        files = sorted(self.articles_dir.glob('????-??-??.json'))
        total_articles = len(self._index.get('articles', {}))
        return {
            'total_days': len(files),
            'total_articles': total_articles,
            'first_date': files[0].stem if files else None,
            'last_date': files[-1].stem if files else None,
        }
