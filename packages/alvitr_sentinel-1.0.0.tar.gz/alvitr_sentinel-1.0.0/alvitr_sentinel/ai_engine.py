"""
ai_engine.py - AI Summarization, Classification and Relevance Scoring Engine

Calls an LLM through the OpenAI-compatible API (supports Alibaba Cloud
DashScope, SiliconCloud, and others) to perform batch article processing:
Chinese-language summary generation, topic classification, and research-
interest relevance scoring.  Optionally computes embedding vectors via a
separate model for semantic search.  Includes rate limiting and retry logic.
"""

import json
import logging
import re
import time
from typing import List, Dict, Optional, Callable

from openai import OpenAI

logger = logging.getLogger(__name__)


class AIEngine:
    def __init__(self, config):
        ai_config = config['ai']

        # LLM inference model
        llm_conf = ai_config['llm']
        self.llm_client = OpenAI(
            base_url=llm_conf['base_url'],
            api_key=llm_conf['api_key'],
        )
        self.llm_model = llm_conf['model']
        self.batch_size = llm_conf.get('batch_size', 5)
        self.max_retries = llm_conf.get('max_retries', 3)
        self.temperature = llm_conf.get('temperature', 0.3)

        # Embedding model (optional)
        emb_conf = ai_config.get('embedding', {})
        self.embedding_enabled = emb_conf.get('enabled', False)
        if self.embedding_enabled:
            self.emb_client = OpenAI(
                base_url=emb_conf['base_url'],
                api_key=emb_conf['api_key'],
            )
            self.emb_model = emb_conf['model']
            self.emb_dimensions = emb_conf.get('dimensions', 1024)

        # Research interests and topic taxonomy
        self.research_interests = config.get('research_interests', '').strip()
        self.topic_taxonomy = config.get('topic_taxonomy', [])

        # Runtime statistics
        self._stats = {
            'llm_calls': 0,
            'llm_tokens_in': 0,
            'llm_tokens_out': 0,
            'emb_calls': 0,
            'errors': 0,
        }

    # ==================================================================
    #  Public processing interface
    # ==================================================================
    def process_articles(
        self,
        articles: List[Dict],
        progress_callback: Optional[Callable] = None
    ) -> List[Dict]:
        """
        Process articles in batches: summarize, classify, and score.

        Returns the article list augmented with ai_* fields.
        """
        processed = []
        total = len(articles)

        for i in range(0, total, self.batch_size):
            batch = articles[i:i + self.batch_size]
            batch_num = i // self.batch_size + 1
            total_batches = (total + self.batch_size - 1) // self.batch_size

            logger.info(f"AI batch {batch_num}/{total_batches} ({len(batch)} articles)")

            try:
                results = self._process_batch(batch)
                processed.extend(results)
            except Exception as e:
                logger.error(f"Batch {batch_num} failed: {e}")
                self._stats['errors'] += 1
                for article in batch:
                    article.update({
                        'ai_summary': '',
                        'ai_tags': [],
                        'ai_relevance': 0,
                        'ai_reasoning': f'AI processing failed: {str(e)[:100]}',
                        'ai_processed': False,
                    })
                    processed.append(article)

            if progress_callback:
                progress_callback(min(i + self.batch_size, total), total)

            # Rate limiting between batches
            if i + self.batch_size < total:
                time.sleep(1.0)

        logger.info(
            f"AI processing complete: {len(processed)} articles, "
            f"{self._stats['llm_calls']} API calls, "
            f"{self._stats['errors']} errors"
        )
        return processed

    # ==================================================================
    #  Batch LLM call
    # ==================================================================
    def _process_batch(self, articles: List[Dict]) -> List[Dict]:
        """Process a batch of articles in a single LLM call."""
        prompt = self._build_batch_prompt(articles)

        for attempt in range(1, self.max_retries + 1):
            try:
                response = self.llm_client.chat.completions.create(
                    model=self.llm_model,
                    messages=[
                        {"role": "system", "content": self._system_prompt()},
                        {"role": "user", "content": prompt},
                    ],
                    temperature=self.temperature,
                )

                self._stats['llm_calls'] += 1
                if response.usage:
                    self._stats['llm_tokens_in'] += response.usage.prompt_tokens
                    self._stats['llm_tokens_out'] += response.usage.completion_tokens

                content = response.choices[0].message.content
                return self._parse_batch_response(content, articles)

            except Exception as e:
                logger.warning(f"LLM call failed (attempt {attempt}): {e}")
                if attempt < self.max_retries:
                    time.sleep(2 ** (attempt - 1))
                else:
                    raise

    # ==================================================================
    #  Prompt construction
    # ==================================================================
    def _system_prompt(self) -> str:
        topics_str = ', '.join(self.topic_taxonomy) if self.topic_taxonomy else '(auto-detect topics)'

        interests_part = self.research_interests
        if not interests_part or interests_part.startswith('Please fill'):
            interests_part = 'No specific research interests configured. Score all articles at relevance 3 based on academic value and novelty.'

        return f"""You are a professional scientific literature analysis assistant.
For each article provided by the user, perform the following tasks:

1. **Chinese Summary**: Generate a 2-3 sentence concise Chinese summary highlighting core findings and methodological innovations.
   - If the abstract is unavailable (marked as "title only"), infer the research direction from the title and note "inferred from title".

2. **Topic Classification**: Select 1-3 best-matching tags from: {topics_str}
   - Use "Other" if none match.

3. **Relevance Score** (1-5): Evaluate relevance based on the user's research interests.
   - 5 = directly relevant, must-read
   - 4 = highly relevant
   - 3 = moderately relevant, worth knowing
   - 2 = marginally relevant
   - 1 = not very relevant

4. **Scoring Rationale**: One sentence explaining the score.

User's research interests:
{interests_part}

Reply strictly in the following JSON format with no additional text:
{{
  "articles": [
    {{
      "index": 1,
      "summary": "Chinese summary...",
      "tags": ["tag1", "tag2"],
      "relevance": 4,
      "reasoning": "Scoring rationale..."
    }}
  ]
}}"""

    def _build_batch_prompt(self, articles: List[Dict]) -> str:
        """Build the user prompt for a batch of articles."""
        parts = [f"Please analyze the following {len(articles)} articles:\n"]

        for idx, article in enumerate(articles, 1):
            abstract = article.get('abstract', '') or ''
            source = article.get('abstract_source', 'unknown')

            if source == 'title_only' or not abstract:
                abstract_display = '(title only, no abstract available)'
            elif source == 'partial':
                abstract_display = f'(incomplete abstract) {abstract}'
            else:
                abstract_display = abstract[:1500]

            parts.append(f"""--- Article {idx} ---
Title: {article['title']}
Journal: {article.get('journal', 'Unknown')}
Abstract: {abstract_display}
""")

        return '\n'.join(parts)

    # ==================================================================
    #  Response parsing
    # ==================================================================
    def _parse_batch_response(
        self,
        content: str,
        articles: List[Dict]
    ) -> List[Dict]:
        """Parse the LLM response and merge results into article dicts."""
        results_list = self._extract_json_results(content)

        processed = []
        for idx, article in enumerate(articles):
            ai_data = None
            for r in results_list:
                if r.get('index') == idx + 1:
                    ai_data = r
                    break
            if ai_data is None and idx < len(results_list):
                ai_data = results_list[idx]

            if ai_data:
                article['ai_summary'] = ai_data.get('summary', '')
                article['ai_tags'] = ai_data.get('tags', [])
                article['ai_relevance'] = self._clamp(
                    ai_data.get('relevance', 0), 0, 5
                )
                article['ai_reasoning'] = ai_data.get('reasoning', '')
                article['ai_processed'] = True
            else:
                article['ai_summary'] = ''
                article['ai_tags'] = []
                article['ai_relevance'] = 0
                article['ai_reasoning'] = 'AI response parsing failed: no matching result'
                article['ai_processed'] = False

            processed.append(article)

        return processed

    def _extract_json_results(self, content: str) -> List[Dict]:
        """Extract the JSON results list from an LLM response string."""
        # Direct JSON parse
        try:
            data = json.loads(content)
            return data.get('articles', [])
        except json.JSONDecodeError:
            pass

        # Extract from markdown code blocks
        for marker in ('```json', '```'):
            if marker in content:
                try:
                    json_str = content.split(marker)[1]
                    if '```' in json_str:
                        json_str = json_str.split('```')[0]
                    data = json.loads(json_str.strip())
                    return data.get('articles', [])
                except (json.JSONDecodeError, IndexError):
                    pass

        # Regex fallback to locate the JSON object
        json_match = re.search(r'\{[\s\S]*"articles"[\s\S]*\}', content)
        if json_match:
            try:
                data = json.loads(json_match.group())
                return data.get('articles', [])
            except json.JSONDecodeError:
                pass

        logger.warning(f"Cannot parse LLM response (first 200 chars): {content[:200]}")
        return []

    # ==================================================================
    #  Embedding computation
    # ==================================================================
    def compute_embeddings(self, articles: List[Dict]) -> List[Dict]:
        """Compute embedding vectors for articles if enabled."""
        if not self.embedding_enabled:
            return articles

        logger.info(f"Computing embeddings for {len(articles)} articles...")

        texts = []
        for article in articles:
            text = f"{article['title']}. {article.get('abstract', '')}"
            texts.append(text[:2000])

        batch_size = 20
        all_embeddings = []

        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            try:
                kwargs = {
                    'model': self.emb_model,
                    'input': batch,
                }
                if self.emb_dimensions:
                    kwargs['dimensions'] = self.emb_dimensions

                resp = self.emb_client.embeddings.create(**kwargs)
                self._stats['emb_calls'] += 1

                for item in resp.data:
                    all_embeddings.append(item.embedding)

            except Exception as e:
                logger.error(f"Embedding batch failed: {e}")
                all_embeddings.extend([None] * len(batch))

            if i + batch_size < len(texts):
                time.sleep(0.3)

        for idx, article in enumerate(articles):
            if idx < len(all_embeddings) and all_embeddings[idx] is not None:
                article['embedding'] = all_embeddings[idx]

        embedded_count = sum(1 for a in articles if 'embedding' in a)
        logger.info(f"Embedding complete: {embedded_count}/{len(articles)} succeeded")
        return articles

    # ==================================================================
    #  Helpers
    # ==================================================================
    @staticmethod
    def _clamp(value, min_val, max_val):
        """Clamp a value to the given range."""
        try:
            return max(min_val, min(max_val, int(value)))
        except (TypeError, ValueError):
            return 0

    def get_stats(self) -> Dict:
        """Return AI processing statistics."""
        return dict(self._stats)
