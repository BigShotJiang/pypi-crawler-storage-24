import iisi_app_core as core


def test_public_api_exports_expected_symbols() -> None:
    assert "EventBridgeEventHandler" in core.__all__
    assert "build_lambda_handler" in core.__all__
    assert "driving_port" in core.__all__
    assert "driven_port" in core.__all__
    assert "PortsAndAdaptersViolationError" in core.__all__
    assert "set_default_container" not in core.__all__
