import pytest

from iisi_app_core import DomainValidationError, Principal, Role


def test_principal_of_allows_empty_tenant_id() -> None:
    principal = Principal.of(name="reader@example.com", role=Role.READER, tenant_id="")
    assert principal.tenant_id == ""


def test_principal_of_rejects_non_string_tenant_id() -> None:
    with pytest.raises(DomainValidationError, match="tenant_id must be a string"):
        Principal.of(name="reader@example.com", role=Role.READER, tenant_id=None)  # type: ignore[arg-type]
