"""Shared error types."""


class DomainError(Exception):
    """Base domain error."""


class DomainValidationError(DomainError):
    """Invalid domain input."""


class NotFoundError(DomainError):
    """Resource was not found."""


class RoutingError(DomainError):
    """Routing failed."""


class RouteNotFoundError(RoutingError):
    """No API handler matched the request."""


class AmbiguousRouteError(RoutingError):
    """More than one API handler matched the request."""


class PolicyNotFoundError(RoutingError):
    """No policy handler matched the event."""


class AmbiguousPolicyError(RoutingError):
    """More than one policy handler matched the event."""


class FeatureDisabledError(DomainError):
    """Feature is disabled."""


class MissingRequestScopeError(RuntimeError):
    """No request scope is active."""


class ForbiddenError(PermissionError):
    """Access is forbidden."""


class UnauthorizedError(PermissionError):
    """Authentication failed."""


__all__ = [
    "AmbiguousPolicyError",
    "AmbiguousRouteError",
    "DomainError",
    "DomainValidationError",
    "FeatureDisabledError",
    "ForbiddenError",
    "MissingRequestScopeError",
    "NotFoundError",
    "PolicyNotFoundError",
    "RouteNotFoundError",
    "RoutingError",
    "UnauthorizedError",
]
