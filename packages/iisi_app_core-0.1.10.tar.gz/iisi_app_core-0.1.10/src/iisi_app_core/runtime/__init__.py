"""Runtime internals."""

__all__: list[str] = []
