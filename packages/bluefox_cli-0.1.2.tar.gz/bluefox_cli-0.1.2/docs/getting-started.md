# Getting started

## Prerequisites

- [uv](https://docs.astral.sh/uv/) installed
- [Docker](https://docs.docker.com/get-docker/) running (for `make dev`)

## Install the CLI

```bash
uv tool install bluefox-cli
```

This installs two commands: `bluefox` and `bfx` (a shorter alias).

## Create a project

```bash
bluefox init myapp
```

This will:

1. Create the `myapp/` directory with all project files
2. Run `uv init` to set up the Python project
3. Run `uv add bluefox-core alembic asyncpg` for runtime dependencies
4. Run `uv add --dev bluefox-test pytest` for test dependencies

## Start developing

```bash
cd myapp
make dev
```

Docker Compose starts a local Postgres container, runs Alembic migrations, and launches the FastAPI app with `--reload`. Visit `http://localhost:8000/docs` to see the OpenAPI UI.

## Create your first migration

The generated project includes an `Example` model. To create a migration for it:

```bash
make migrate-make name=initial
```

This generates a migration file in `migrations/versions/`. The next time you run `make dev`, it will be applied automatically.

## Run tests

```bash
make test
```

Tests use [bluefox-test](https://bluefox-test.bluefox.software) with real Postgres via testcontainers. Each test runs inside a SAVEPOINT — no cleanup needed.

## Project structure

```
myapp/
  main.py                     # App factory
  models.py                   # SQLAlchemy models
  .env                        # Dev environment variables
  .env.example                # Template for production
  Makefile                    # Dev workflow commands
  Dockerfile                  # Multi-stage production build
  docker-compose.yml          # Production compose
  docker-compose.dev.yml      # Dev compose (local Postgres)
  alembic.ini                 # Migration config
  migrations/
    env.py                    # One-line Alembic setup
    versions/                 # Migration files
  tests/
    conftest.py               # Test fixtures
    test_health.py            # Smoke test
  pyproject.toml              # Dependencies
```

## Next steps

- Add your own models to `models.py` and generate migrations
- Add routes to `main.py` using FastAPI routers
- See [Generated files](reference/generated-files.md) for details on each file
- See [Deployment](guides/deployment.md) for deploying with Dokploy
