# Adding models

## Define a model

Add new models to `models.py` (or create additional modules). All models must inherit from `BluefoxBase`:

```python
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from bluefox_core import BluefoxBase


class User(BluefoxBase):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    email = Column(String, unique=True, nullable=False)
    name = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)

    todos = relationship("Todo", back_populates="owner")


class Todo(BluefoxBase):
    __tablename__ = "todos"

    id = Column(Integer, primary_key=True)
    title = Column(String, nullable=False)
    done = Column(Boolean, default=False)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    owner = relationship("User", back_populates="todos")
```

## Generate a migration

```bash
make migrate-make name=add_users_and_todos
```

This compares your models against the database and creates a migration file in `migrations/versions/`.

## Apply the migration

```bash
make migrate
```

Or just run `make dev` — migrations run automatically on startup.

## Multiple model files

If you split models across files, make sure they're imported somewhere that runs at startup. The simplest approach is to import them in `models.py`:

```python
# models.py
from bluefox_core import BluefoxBase
from app.users.models import User  # noqa: F401
from app.todos.models import Todo  # noqa: F401
```

The `MODELS_MODULE="models"` setting in `main.py` ensures this file is imported, which transitively imports all your models.

## Register models for tests

Update `tests/conftest.py` to import any new models so they're visible to the test database setup:

```python
from bluefox_test import bluefox_test_setup
from models import User, Todo  # noqa: F401 — register models
from bluefox_core import BluefoxBase

globals().update(bluefox_test_setup(base=BluefoxBase, app_factory="main:create_app"))
```
