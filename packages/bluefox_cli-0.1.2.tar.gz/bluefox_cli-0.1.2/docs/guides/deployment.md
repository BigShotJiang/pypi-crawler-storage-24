# Deployment

The generated project follows the [Bluefox Stack deployment pattern](https://bluefox-stack.bluefox.software) using Docker Compose with Dokploy.

## Production compose

`docker-compose.yml` defines two services:

```yaml
services:
  migrate:
    build: .
    command: ["python", "-m", "alembic", "upgrade", "head"]
    networks:
      - dokploy-network

  app:
    build: .
    depends_on:
      migrate:
        condition: service_completed_successfully
    networks:
      - dokploy-network

networks:
  dokploy-network:
    external: true
```

The **migrate** service runs first, applies any pending migrations, then exits. The **app** service only starts after migrate completes successfully.

## Environment variables

Set these in your Dokploy application settings:

| Variable | Example | Required |
|----------|---------|----------|
| `DATABASE_URL` | `postgresql+asyncpg://user:pass@db:5432/myapp` | Yes |
| `SECRET_KEY` | A long random string | Yes |
| `APP_NAME` | `myapp` | No |
| `ENVIRONMENT` | `production` | No |
| `LOG_LEVEL` | `INFO` | No |
| `REDIS_URL` | `redis://redis:6379/0` | No |

## Dockerfile

The multi-stage build keeps the production image small:

1. **Build stage** uses `uv` to install dependencies and build the project
2. **Runtime stage** copies only the virtualenv, runs as non-root user

The health check endpoint at `/health` is used by Docker for container health monitoring.

## Dev vs production

| Concern | Dev (`docker-compose.dev.yml`) | Production (`docker-compose.yml`) |
|---------|------|------------|
| Database | Local Postgres container | External (Dokploy-managed) |
| Network | Local bridge | `dokploy-network: external` |
| Code | Volume-mounted, `--reload` | Copied into image |
| Debug | `DEBUG=true` | `DEBUG=false` |

## Deploy with Dokploy

1. Push your code to a Git repository
2. Create a new application in Dokploy pointing to the repo
3. Set the environment variables listed above
4. Deploy — Dokploy runs Docker Compose, which handles migrations and starts the app
