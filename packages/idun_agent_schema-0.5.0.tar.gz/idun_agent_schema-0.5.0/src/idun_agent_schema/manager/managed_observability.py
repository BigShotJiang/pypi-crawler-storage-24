"""Main managed observability configuration model."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from idun_agent_schema.engine.observability_v2 import ObservabilityConfig


class ManagedObservabilityCreate(BaseModel):
    """Create managed observability model for requests."""

    name: str
    observability: ObservabilityConfig = Field(
        ..., description="Observability configuration"
    )


class ManagedObservabilityRead(BaseModel):
    """Complete managed observability model for responses."""

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    name: str
    observability: ObservabilityConfig = Field(
        ..., description="Observability configuration"
    )
    agent_count: int = Field(0, description="Number of agents using this config")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")


class ManagedObservabilityPatch(BaseModel):
    """Full replacement schema for PUT of a managed observability."""

    name: str
    observability: ObservabilityConfig = Field(
        ..., description="Observability configuration"
    )
