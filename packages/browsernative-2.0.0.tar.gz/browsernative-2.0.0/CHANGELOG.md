# Changelog

All notable changes to the Browser Native Python Client will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.0] - 2026-03-07

### Added
- `bulk_scrape()` method and convenience function with concurrent execution via ThreadPoolExecutor
- `method` option to force specific scraping method (`'auto'`, `'direct'`, `'lightpanda'`, `'puppeteer'`)
- Progress callback support for bulk operations

### Changed
- Minimum Python version bumped to 3.9 (3.8 is EOL)
- Updated User-Agent to 2.0.0
- Rewrote README — removed emojis, simplified documentation

## [1.0.1] - 2025-06-04

### Fixed
- Updated minimum Python version to 3.8 to fix GitHub Actions CI/CD
- Python 3.7 is no longer supported by GitHub Actions Ubuntu 24.04 runners

### Changed
- Removed Python 3.7 from test matrix in GitHub Actions workflows
- Updated package metadata to require Python 3.8+

## [1.0.0] - 2025-06-04

### Added
- Initial release of Browser Native Python Client
- Full API compatibility with JavaScript client
- `BrowserNativeClient` class with all API methods:
  - `scrape()` - Extract structured content from webpages
  - `analyze()` - AI-powered Q&A about webpage content
  - `screenshot()` - Full page screenshots
  - `quickshot()` - Optimized screenshot capture
  - `get_usage()` - Account usage statistics
  - `health_check()` - API health status
- Convenience functions for quick operations:
  - `quick_scrape()`
  - `quick_analyze()`
  - `quick_screenshot()`
  - `quick_shot()`
- Automatic retry logic with exponential backoff
- Connection pooling for improved performance
- Context manager support for resource cleanup
- Comprehensive error handling
- Full type hints for better IDE support
- Example scripts and documentation
- Support for Python 3.7+

### Performance
- 11x faster than traditional scrapers
- Intelligent fallback system (Direct → Lightpanda → Puppeteer)
- Optimized for high-throughput operations

[1.0.0]: https://github.com/monostate/browsernative-python/releases/tag/v1.0.0