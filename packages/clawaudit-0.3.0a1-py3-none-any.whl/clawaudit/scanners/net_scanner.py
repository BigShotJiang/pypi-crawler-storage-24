"""PA-NET* — Network exposure scanner."""

import re
import socket
import subprocess
from typing import List, Optional

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class NetScanner(BaseScanner):
    category = Category.NET
    mode = "both"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-NET01": self._net01_gateway_18789,
            "PA-NET02": self._net02_tls,
            "PA-NET03": self._net03_anon_access,
            "PA-NET04": self._net04_ioc,
        }
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    # ------------------------------------------------------------------
    # PA-NET01: Gateway 18789 binding 0.0.0.0
    # ------------------------------------------------------------------
    def _net01_gateway_18789(self):
        check_id = "PA-NET01"
        title = "Gateway port 18789 binding 0.0.0.0"

        if self.target:
            # Remote: try to connect
            if self._port_open(self.target, 18789):
                self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                 detail=f"{self.target}:18789 is reachable",
                                 remediation="Bind gateway to 127.0.0.1",
                                 fix_actions=[
                                     FixAction(
                                         description="Bind gateway to loopback",
                                         fix_type="manual",
                                         manual_steps='Set "gateway": {"bind": "loopback"} in openclaw.json on the target host and restart the gateway.',
                                     ),
                                 ])
            else:
                self.add_finding(check_id, title, Severity.CRITICAL, "PASS")
            return

        # Local: check ss/netstat
        exposed = self._check_port_binding(18789)
        if exposed == "no_cmd":
            self.skip(check_id, title, Severity.CRITICAL,
                      "ss/netstat/lsof not available")
        elif exposed is True:
            fix_actions = self._net01_build_fix_actions()
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail="Port 18789 listening on 0.0.0.0 or [::]",
                             remediation="Bind gateway to 127.0.0.1",
                             fix_actions=fix_actions)
        elif exposed is None:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                             detail="Port 18789 not listening (gateway not running)")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                             detail="Port 18789 bound to localhost only")

    def _net01_build_fix_actions(self) -> list:
        """Build fix actions for NET01: find gateway bind config set to non-loopback."""
        bind_pattern = re.compile(
            r'(["\']?bind["\']?\s*[:=]\s*["\']?)(lan|0\.0\.0\.0)(["\']?)',
            re.IGNORECASE,
        )
        actions = []
        for f in self.discovery.config_files:
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            m = bind_pattern.search(text)
            if m:
                actions.append(FixAction(
                    description=f"Change gateway bind to loopback in {f.name}",
                    fix_type="file_edit",
                    target_file=str(f),
                    old_value=m.group(0),
                    new_value=m.group(1) + "loopback" + m.group(3),
                ))
        actions.append(FixAction(
            description="Restart gateway for binding change to take effect",
            fix_type="manual",
            manual_steps="Gateway bind address was changed to loopback. Restart the OpenClaw gateway service for the change to take effect.",
        ))
        return actions

    # ------------------------------------------------------------------
    # PA-NET02: TLS/HTTPS missing
    # ------------------------------------------------------------------
    def _net02_tls(self):
        check_id = "PA-NET02"
        title = "TLS/HTTPS not configured"

        if self.target:
            self._net02_tls_remote(check_id, title)
        else:
            # TLS is configured via reverse proxy, not in openclaw.json
            self.skip(check_id, title, Severity.WARNING,
                      "TLS configuration is external (reverse proxy). Use remote mode to test")

    def _net02_tls_remote(self, check_id: str, title: str):
        import ssl

        # Step 1: check if target is reachable
        try:
            sock = socket.create_connection((self.target, self.port), timeout=5)
            sock.close()
        except (OSError, socket.timeout):
            self.skip(check_id, title, Severity.WARNING,
                      f"Cannot connect to {self.target}:{self.port}")
            return

        # Step 2: TLS handshake without cert verification (detect TLS presence)
        has_tls = False
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            with socket.create_connection((self.target, self.port), timeout=5) as s:
                with ctx.wrap_socket(s, server_hostname=self.target):
                    has_tls = True
        except Exception:
            pass

        if not has_tls:
            self.add_finding(check_id, title, Severity.WARNING, "FAIL",
                             detail=f"No TLS on {self.target}:{self.port}",
                             remediation="Put a TLS-terminating reverse proxy (Nginx/Caddy) in front of Gateway",
                             fix_actions=[
                                 FixAction(
                                     description="Configure TLS for gateway",
                                     fix_type="manual",
                                     manual_steps="Set up a TLS-terminating reverse proxy (Nginx/Caddy) in front of the Gateway.",
                                 ),
                             ])
            return

        # Step 3: TLS handshake with cert verification (detect self-signed)
        try:
            ctx = ssl.create_default_context()
            with socket.create_connection((self.target, self.port), timeout=5) as s:
                with ctx.wrap_socket(s, server_hostname=self.target):
                    self.add_finding(check_id, title, Severity.WARNING, "PASS",
                                     detail="TLS with trusted certificate")
        except ssl.SSLCertVerificationError:
            self.add_finding(check_id, title, Severity.WARNING, "FAIL",
                             detail=f"TLS enabled but certificate is not trusted (self-signed) on {self.target}:{self.port}",
                             remediation="Replace self-signed certificate with a trusted CA certificate",
                             fix_actions=[
                                 FixAction(
                                     description="Replace self-signed certificate",
                                     fix_type="manual",
                                     manual_steps="Replace the self-signed certificate with one from a trusted CA (e.g., Let's Encrypt).",
                                 ),
                             ])
        except Exception:
            self.add_finding(check_id, title, Severity.WARNING, "PASS",
                             detail="TLS enabled (certificate verification inconclusive)")

    # ------------------------------------------------------------------
    # PA-NET03: Anonymous remote access
    # ------------------------------------------------------------------
    def _net03_anon_access(self):
        check_id = "PA-NET03"
        title = "Anonymous remote access (unauthenticated)"

        if not self.target:
            self.skip(check_id, title, Severity.CRITICAL, "Remote mode only")
            return

        import urllib.request
        import urllib.error
        import ssl

        # Try both HTTP and HTTPS
        urls = [
            f"https://{self.target}:{self.port}",
            f"http://{self.target}:{self.port}",
        ]

        # SSL context that skips cert verification (for self-signed)
        nossl = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        nossl.check_hostname = False
        nossl.verify_mode = ssl.CERT_NONE

        for url in urls:
            ctx = nossl if url.startswith("https") else None
            try:
                req = urllib.request.Request(url, method="GET")
                with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
                    if resp.status == 200:
                        self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                         detail=f"HTTP 200 from {url} without auth",
                                         remediation="Enable authentication for gateway",
                                         fix_actions=[
                                             FixAction(
                                                 description="Enable gateway authentication",
                                                 fix_type="manual",
                                                 manual_steps='Set a strong token in gateway.auth.token in openclaw.json.',
                                             ),
                                         ])
                        return
            except urllib.error.HTTPError as e:
                # 401/403 means auth is required — PASS
                if e.code in (401, 403):
                    self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                                     detail=f"{url} requires authentication (HTTP {e.code})")
                    return
                # Other HTTP errors (500, etc.) — service exists but not anonymous access
                continue
            except (urllib.error.URLError, OSError, socket.timeout):
                # Connection failed on this protocol, try next
                continue

        # All attempts failed to connect
        self.skip(check_id, title, Severity.CRITICAL,
                  f"Cannot connect to {self.target}:{self.port}")

    # ------------------------------------------------------------------
    # PA-NET04: Network IOC detection
    # ------------------------------------------------------------------
    def _net04_ioc(self):
        check_id = "PA-NET04"
        title = "Network IOC detection (outbound C2 connections)"

        if self.target:
            self.skip(check_id, title, Severity.HIGH, "Local mode only")
            return

        # Load IOC list (IPs only; domains don't appear in ss/netstat output)
        ioc_ips = self._load_ioc_ips()
        if not ioc_ips:
            self.skip(check_id, title, Severity.HIGH, "IOC database could not be loaded")
            return

        # Check established connections
        result = None
        for cmd in (
            ["ss", "-tunp", "state", "established"],
            ["netstat", "-an"],
        ):
            try:
                result = subprocess.run(
                    cmd, capture_output=True, text=True, timeout=5,
                )
                if result.returncode == 0:
                    break
                result = None
            except (FileNotFoundError, subprocess.TimeoutExpired):
                result = None

        if result is None:
            self.skip(check_id, title, Severity.HIGH, "ss/netstat command not available")
            return

        # Build regex patterns with word boundaries for each IOC IP
        ip_patterns = {}
        for ip in ioc_ips:
            ip_patterns[ip] = re.compile(r'(?<!\d)' + re.escape(ip) + r'(?!\d)')

        hits = set()
        for line in result.stdout.splitlines():
            for ip, pat in ip_patterns.items():
                if pat.search(line):
                    hits.add(ip)

        if hits:
            sorted_hits = sorted(hits)
            ip_list = ' '.join(sorted_hits)
            block_cmds = ' '.join(f'iptables -A OUTPUT -d {ip} -j DROP;' for ip in sorted_hits)
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Matched {len(sorted_hits)} IOC IP(s): {'; '.join(sorted_hits)}",
                             remediation="Investigate outbound connections to known malicious hosts",
                             fix_actions=[
                                 FixAction(
                                     description="Investigate and block malicious C2 connections",
                                     fix_type="manual",
                                     manual_steps=(
                                         f"Detected outbound connections to known malicious IP(s): {ip_list}\n"
                                         f"Step 1: Find which process is connecting:\n"
                                         f"  ss -tunp | grep -E '{ip_list.replace(' ', '|')}'\n"
                                         f"  or: lsof -i | grep -E '{ip_list.replace(' ', '|')}'\n"
                                         f"Step 2: Kill the malicious process (replace <PID>):\n"
                                         f"  kill -9 <PID>\n"
                                         f"Step 3: Block these IPs at firewall (requires root):\n"
                                         f"  {block_cmds}\n"
                                         f"Step 4: Locate and remove the malicious binary/script that spawned the process.\n"
                                         f"Step 5: Check if sensitive data (API keys, tokens) was exfiltrated. "
                                         f"Rotate all credentials in openclaw.json."
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail=f"No IOC matches ({len(ioc_ips)} IPs checked)")

    def _load_ioc_ips(self):
        """Load IOC IP list from bundled YAML data."""
        from pathlib import Path
        ioc_path = Path(__file__).resolve().parent.parent / "data" / "ioc_list.yaml"
        if not ioc_path.is_file():
            return []
        try:
            import yaml
            data = yaml.safe_load(ioc_path.read_text())
            return data.get("ips", []) if data else []
        except Exception:
            return []

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _port_open(self, host: str, port: int, timeout: float = 3) -> bool:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except (OSError, socket.timeout):
            return False

    def _check_port_binding(self, port: int):
        """Check if port is bound to 0.0.0.0.

        Returns:
            True  — port listening on 0.0.0.0 / [::] / *
            False — port listening on localhost only
            None  — port not listening (gateway not running)
            "no_cmd" — ss/netstat/lsof all unavailable
        """
        result = None
        for cmd in (
            ["ss", "-tunlp"],
            ["netstat", "-tunlp"],
            ["lsof", "-iTCP", "-sTCP:LISTEN", "-nP"],
        ):
            try:
                result = subprocess.run(
                    cmd, capture_output=True, text=True, timeout=5,
                )
                if result.returncode == 0:
                    break
                result = None
            except (FileNotFoundError, subprocess.TimeoutExpired):
                result = None

        if result is None:
            return "no_cmd"

        port_re = re.compile(rf'(?<!\d):{port}\b')
        wild_re = re.compile(rf'(?:0\.0\.0\.0|(?:\[::\])|(?:\*)):{port}\b')

        found = False
        for line in result.stdout.splitlines():
            if not port_re.search(line):
                continue
            found = True
            if wild_re.search(line):
                return True

        return None if not found else False
