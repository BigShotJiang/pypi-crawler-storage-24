"""PA-AUTH* — Authentication & authorization scanner."""

import re
import secrets
from typing import List, Optional

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class AuthScanner(BaseScanner):
    category = Category.AUTH
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-AUTH01": self._auth01_default_creds,
            "PA-AUTH02": self._auth02_ui_bypass,
        }
        if not self.discovery.config_files:
            for check_id in all_checks:
                if checks and check_id not in checks:
                    continue
                self.skip(check_id, check_id, Severity.HIGH,
                          "No OpenClaw config files found")
            return self.findings
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    # ------------------------------------------------------------------
    # PA-AUTH01: Default/weak credentials
    # ------------------------------------------------------------------
    _CRED_FIELDS = r'token|secret|password|api[_-]?key|apiKey'
    _WEAK_WORDS = (
        r'changeme|password|admin|default|test|12345|123456'
        r'|undefined|root|qwerty|letmein|welcome|monkey|master'
    )

    def _auth01_default_creds(self):
        check_id = "PA-AUTH01"
        title = "Default/weak credentials"
        found = False

        weak_pattern = re.compile(
            rf'["\']?({self._CRED_FIELDS})["\']?\s*[:=]\s*["\']?({self._WEAK_WORDS})\b["\']?',
            re.IGNORECASE,
        )

        short_pattern = re.compile(
            rf'["\']?({self._CRED_FIELDS})["\']?\s*[:=]\s*["\']?([^\s"\',:${{}}]{{1,7}})["\']?',
            re.IGNORECASE,
        )

        reported = set()  # (file, field) pairs already reported

        for f in self.discovery.config_files:
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue

            # Phase 1: weak well-known passwords
            for m in weak_pattern.finditer(text):
                field, value = m.group(1), m.group(2)
                key = (str(f), field.lower())
                if key in reported:
                    continue
                reported.add(key)
                new_token = secrets.token_urlsafe(32)
                self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                 detail=f"Weak credential ({field}={value}) in {f.name}",
                                 remediation="Set a strong, unique token (>= 16 chars)",
                                 fix_actions=[
                                     FixAction(
                                         description=f"Replace {field} value in {f.name}",
                                         fix_type="file_edit",
                                         target_file=str(f),
                                         old_value=value,
                                         new_value=new_token,
                                     ),
                                     FixAction(
                                         description=f"Sync {field} to other services",
                                         fix_type="manual",
                                         manual_steps=f"{field} in {f.name} was auto-replaced. Check the new value in {f.name} and update any clients that use this {field} to connect to the gateway.",
                                     ),
                                 ])
                found = True

            # Phase 2: credential too short (<= 7 chars)
            for m in short_pattern.finditer(text):
                field, value = m.group(1), m.group(2)
                key = (str(f), field.lower())
                if key in reported:
                    continue
                reported.add(key)
                new_token = secrets.token_urlsafe(32)
                self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                 detail=f"{field} too short ({len(value)} chars) in {f.name}",
                                 remediation="Use a credential with at least 16 characters",
                                 fix_actions=[
                                     FixAction(
                                         description=f"Replace {field} value in {f.name}",
                                         fix_type="file_edit",
                                         target_file=str(f),
                                         old_value=value,
                                         new_value=new_token,
                                     ),
                                     FixAction(
                                         description=f"Sync {field} to other services",
                                         fix_type="manual",
                                         manual_steps=f"{field} in {f.name} was auto-replaced. Check the new value in {f.name} and update any clients that use this {field} to connect to the gateway.",
                                     ),
                                 ])
                found = True

        if not found:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-AUTH02: Control UI auth bypass
    # ------------------------------------------------------------------
    _BYPASS_FLAGS = [
        ("dangerouslyDisableDeviceAuth", "Disables device-level authentication for the control UI"),
        ("allowInsecureAuth", "Allows insecure (non-TLS) authentication"),
    ]

    def _auth02_ui_bypass(self):
        check_id = "PA-AUTH02"
        title = "Control UI auth bypass enabled"
        found = False

        for flag, desc in self._BYPASS_FLAGS:
            pattern = re.compile(
                rf'(["\']?{flag}["\']?\s*[:=]\s*)(true|yes|1)',
                re.IGNORECASE,
            )
            for f in self.discovery.config_files:
                try:
                    text = f.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                m = pattern.search(text)
                if m:
                    self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                     detail=f"{flag} is enabled in {f.name} — {desc}",
                                     remediation=f"Set {flag} to false",
                                     fix_actions=[
                                         FixAction(
                                             description=f"Set {flag} to false in {f.name}",
                                             fix_type="file_edit",
                                             target_file=str(f),
                                             old_value=m.group(0),
                                             new_value=m.group(1) + "false",
                                         ),
                                     ])
                    found = True

        if not found:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

