# Emulator Manager

A Python tool to manage multiple instances of the **THW Emulator**. Launch, stop, reboot, organize windows, and monitor the status of your emulator instances effortlessly.  

## Features

- Launch multiple emulator instances  
- Stop or reboot instances  
- Organize emulator windows on the screen  
- Check the status of each instance  
- Calculate virtual machine sizes  

## Usage
```python
from dc_thw_emulator import EmulatorManager

# Create an instance of EmulatorManager
manager = EmulatorManager()

# Launch 3 emulator instances
manager.launch_instances(3)

# Stop all instances
manager.stop_instances()

# Reboot all instances with a 3-second delay
manager.reboot_instances(delay=3)

# Organize emulator windows on screen
manager.organize_windows()

# Check the status of each instance
manager.check_status()

# Get the name of each instance
manager.get_instance_name()

# Calculate the size of the virtual machines
manager.calculate_vms_size()
```

## Installation

Install via pip:

```bash
pip install dc-thw-emulator