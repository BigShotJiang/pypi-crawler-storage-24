"""update table: objects_data, add field: region

Revision ID: 537cea3f189f
Revises: e54bcbed571b
Create Date: 2025-12-16 15:40:27.084195

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "537cea3f189f"
down_revision: Union[str, None] = "e54bcbed571b"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "objects_data", sa.Column("region", sa.String(), nullable=True), schema="webapp"
    )


def downgrade() -> None:
    op.drop_column("objects_data", "region", schema="webapp")
