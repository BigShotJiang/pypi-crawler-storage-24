"""update table: objects_data

Revision ID: 1ebc7996032c
Revises: ae7589156ff3
Create Date: 2025-06-26 15:02:33.121356

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "1ebc7996032c"
down_revision: Union[str, None] = "ae7589156ff3"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "objects_data",
        sa.Column("actual", sa.Boolean(), nullable=True),
        schema="webapp",
    )


def downgrade() -> None:
    op.drop_column("objects_data", "actual", schema="webapp")
