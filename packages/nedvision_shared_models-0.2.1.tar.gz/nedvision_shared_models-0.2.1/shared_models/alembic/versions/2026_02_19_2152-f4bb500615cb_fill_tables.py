"""fill tables

Revision ID: f4bb500615cb
Revises: a836a6259ba6
Create Date: 2026-02-19 21:52:10.898059

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "f4bb500615cb"
down_revision: Union[str, None] = "a836a6259ba6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute(
        """
        INSERT INTO user_subscriptions (id, user_id, subscription_id, expires_at, is_active)
        SELECT
            gen_random_uuid(),
            u.id,
            s.id,
            NULL,
            TRUE
        FROM users u
        CROSS JOIN subscriptions s
        WHERE s.code = 'FREE'
        ON CONFLICT DO NOTHING
    """
    )


def downgrade() -> None:
    op.execute(
        """
        DELETE FROM user_subscriptions us
        USING subscriptions s
        WHERE us.subscription_id = s.id AND s.code = 'FREE'
    """
    )
