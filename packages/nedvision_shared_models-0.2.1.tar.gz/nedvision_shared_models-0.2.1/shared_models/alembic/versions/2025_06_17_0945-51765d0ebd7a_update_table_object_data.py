"""update table: object_data

Revision ID: 51765d0ebd7a
Revises: c8110cc6d1d3
Create Date: 2025-06-17 09:45:02.624678

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "51765d0ebd7a"
down_revision: Union[str, None] = "c8110cc6d1d3"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "objects_data",
        sa.Column("region_rating", postgresql.JSONB(), nullable=True),
        schema="webapp",
    )


def downgrade() -> None:
    op.drop_column("objects_data", "region_rating", schema="webapp")
