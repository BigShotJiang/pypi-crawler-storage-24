"""merge heads

Revision ID: 4341de3d13ba
Revises: f992958d7b39, 27e352f10ac1
Create Date: 2025-11-21 10:53:28.621514

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "4341de3d13ba"
down_revision: Union[str, None] = ("f992958d7b39", "27e352f10ac1")
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
