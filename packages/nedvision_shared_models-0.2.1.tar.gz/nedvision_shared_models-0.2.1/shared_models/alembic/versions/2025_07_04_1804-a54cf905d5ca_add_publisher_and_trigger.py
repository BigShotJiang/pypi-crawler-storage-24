"""add publisher and trigger

Revision ID: a54cf905d5ca
Revises: 0616a6ef152b
Create Date: 2025-07-04 18:04:10.481829

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "a54cf905d5ca"
down_revision: Union[str, None] = "0616a6ef152b"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    op.execute(
        """
               CREATE OR REPLACE FUNCTION notify_objects_data_change()
        RETURNS TRIGGER AS $$
               BEGIN
            PERFORM pg_notify('objects_data_updated', 'objects updated');
               RETURN COALESCE(NEW, OLD);
               END;
        $$ LANGUAGE plpgsql;
               """
    )
    op.execute(
        """
               CREATE OR REPLACE TRIGGER objects_data_insert_trigger
            AFTER INSERT ON webapp.objects_data
            FOR EACH STATEMENT
            EXECUTE FUNCTION notify_objects_data_change();
               """
    )
    op.execute(
        """
               CREATE OR REPLACE TRIGGER objects_data_update_trigger
            AFTER UPDATE ON webapp.objects_data
                                            FOR EACH STATEMENT
                                            EXECUTE FUNCTION notify_objects_data_change();
               """
    )


def downgrade():
    op.execute(
        "DROP TRIGGER IF EXISTS objects_data_insert_trigger ON webapp.objects_data;"
    )
    op.execute(
        "DROP TRIGGER IF EXISTS objects_data_update_trigger ON webapp.objects_data;"
    )
    op.execute("DROP FUNCTION IF EXISTS notify_objects_data_change();")
