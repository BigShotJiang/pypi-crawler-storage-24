"""update table: objects

Revision ID: 2085c1251fb8
Revises: 9e6be4ad3215
Create Date: 2025-04-01 18:01:38.086835

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "2085c1251fb8"
down_revision: Union[str, None] = "9e6be4ad3215"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.alter_column(
        "objects",
        "separate_entrance",
        existing_type=sa.VARCHAR(),
        type_=sa.Boolean(),
        existing_nullable=True,
        postgresql_using="separate_entrance::boolean",
    )
    op.alter_column(
        "objects",
        "communications",
        existing_type=sa.VARCHAR(),
        type_=sa.Boolean(),
        existing_nullable=True,
        postgresql_using="communications::boolean",
    )


def downgrade() -> None:
    pass
