"""add new field: rental_rate

Revision ID: b54518b3c384
Revises: bcff10c39b42
Create Date: 2025-11-11 15:23:14.265938

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "b54518b3c384"
down_revision: Union[str, None] = "9abea1089508"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute(
        """
               ALTER TABLE webapp.objects_data
                   ADD COLUMN IF NOT EXISTS rental_rate FLOAT
               """
    )


def downgrade() -> None:
    op.drop_column("objects_data", "rental_rate", schema="webapp")
