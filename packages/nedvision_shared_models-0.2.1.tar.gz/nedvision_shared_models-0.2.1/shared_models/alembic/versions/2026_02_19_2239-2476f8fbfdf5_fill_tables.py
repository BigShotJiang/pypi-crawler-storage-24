"""fill tables

Revision ID: 2476f8fbfdf5
Revises: f4bb500615cb
Create Date: 2026-02-19 22:39:32.283898

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "2476f8fbfdf5"
down_revision: Union[str, None] = "f4bb500615cb"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 1. collection
    op.execute(
        """
        INSERT INTO collections (code) VALUES ('inv-profile')
    """
    )

    # 2. poll
    op.execute(
        """
        INSERT INTO polls (code, name, step_by)
        VALUES ('inv-profile', 'Выбор инвестиционного профиля', FALSE)
    """
    )

    # 3. question
    op.execute(
        """
        INSERT INTO questions (poll_id, index, text, view_type, control_name, required, placeholder, is_calculated)
        VALUES (
            (SELECT id FROM polls WHERE code = 'inv-profile'),
            1,
            'Выберите ваш инвестиционный профиль',
            'radio_v',
            'preferred_profile',
            TRUE,
            NULL,
            FALSE
        )
    """
    )

    # 4. answers
    op.execute(
        """
        INSERT INTO answers (question_id, value, text, description, is_active, is_disabled)
        VALUES
            ((SELECT id FROM questions WHERE control_name = 'preferred_profile'), 'SPECULATION',   'Спекуляция',  'Вы стремитесь купить объект дешевле и продать дороже в короткие сроки', TRUE, FALSE),
            ((SELECT id FROM questions WHERE control_name = 'preferred_profile'), 'LIQUIDITY',     'Ликвидность', 'Вы стремитесь вкладывать в объекты, которые можно быстро продать по рыночной цене', TRUE, FALSE),
            ((SELECT id FROM questions WHERE control_name = 'preferred_profile'), 'PROFITABILITY', 'Доходность',  'Вы стремитесь получать большой процент прибыли год к году', TRUE, FALSE),
            ((SELECT id FROM questions WHERE control_name = 'preferred_profile'), 'STRATEGY',      'Стратегия',   'Вы стремитесь к долгосрочному росту капитала через продуманные инвестиции в недвижимость', TRUE, FALSE)
    """
    )


def downgrade() -> None:
    op.execute(
        """
        DELETE FROM answers WHERE question_id = (
            SELECT id FROM questions WHERE control_name = 'preferred_profile'
        )
    """
    )
    op.execute("DELETE FROM questions WHERE control_name = 'preferred_profile'")
    op.execute("DELETE FROM polls WHERE code = 'inv-profile'")
    op.execute("DELETE FROM collections WHERE code = 'inv-profile'")
