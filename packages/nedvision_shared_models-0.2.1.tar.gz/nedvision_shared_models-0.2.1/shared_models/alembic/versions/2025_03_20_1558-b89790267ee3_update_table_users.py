"""update table: users

Revision ID: b89790267ee3
Revises: 3281b7a2c945
Create Date: 2025-03-20 15:58:06.922756

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "b89790267ee3"
down_revision: Union[str, None] = "3281b7a2c945"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "objects_data",
        sa.Column("distance_ac", sa.Float(), nullable=True),
        schema="webapp",
    )
    op.add_column(
        "objects_data",
        sa.Column("distance_c", sa.Float(), nullable=True),
        schema="webapp",
    )
    op.add_column(
        "objects_data",
        sa.Column("distance_r", sa.Float(), nullable=True),
        schema="webapp",
    )
    op.add_column(
        "objects_data",
        sa.Column("main_entrance", sa.String(), nullable=True),
        schema="webapp",
    )
    op.add_column(
        "objects_data",
        sa.Column("ceiling_height", sa.Float(), nullable=True),
        schema="webapp",
    )
    op.add_column(
        "objects_data",
        sa.Column("building_type", sa.String(), nullable=True),
        schema="webapp",
    )
    op.add_column(
        "objects_data",
        sa.Column("type", sa.String(), nullable=True),
        schema="webapp",
    )

    op.drop_column(
        "objects_data",
        "view",
        schema="webapp",
    )


def downgrade() -> None:
    pass
