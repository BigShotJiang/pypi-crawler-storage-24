"""create table: tenants

Revision ID: 86ec3a4662d8
Revises: a757d674627b
Create Date: 2025-09-16 01:52:45.352364

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "86ec3a4662d8"
down_revision: Union[str, None] = "a757d674627b"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "objects_data",
        sa.Column("category", sa.String(length=255), nullable=True),
        schema="webapp",
    )


def downgrade() -> None:
    op.drop_column(
        "objects_data",
        "category",
        schema="webapp",
    )
