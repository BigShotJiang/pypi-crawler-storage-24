"""extra fields

Revision ID: e93b0c14e73f
Revises: ec5adbcad2d7
Create Date: 2025-10-16 15:57:28.442511

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "e93b0c14e73f"
down_revision: Union[str, None] = "ec5adbcad2d7"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.alter_column(
        "objects_data",
        "power_capacity",
        existing_type=sa.Integer(),
        nullable=True,
        schema="webapp",
    )


def downgrade() -> None:
    op.alter_column(
        "objects_data",
        "power_capacity",
        existing_type=sa.Integer(),
        nullable=False,
        schema="webapp",
    )
