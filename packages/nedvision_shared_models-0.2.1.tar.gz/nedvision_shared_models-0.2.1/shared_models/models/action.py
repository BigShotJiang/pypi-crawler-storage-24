from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import DECIMAL, Boolean, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import UUIDMixin

from .base import Base

if TYPE_CHECKING:
    from . import UserAction


class Action(UUIDMixin, Base):
    codename: Mapped[str] = mapped_column(String(100))
    name: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(Text)
    value_xp: Mapped[float] = mapped_column(
        DECIMAL(precision=10, scale=2), nullable=True
    )
    value_tokens: Mapped[float] = mapped_column(
        DECIMAL(precision=10, scale=2), nullable=True
    )
    condition: Mapped[list[dict]] = mapped_column(JSONB, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean)

    user_actions: Mapped[list[UserAction]] = relationship(
        back_populates="action",
    )
