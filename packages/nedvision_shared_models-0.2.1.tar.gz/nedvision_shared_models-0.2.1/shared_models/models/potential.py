from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import Object


class Potential(IdMixin, TimestampMixin, Base):
    object_id: Mapped[int] = mapped_column(
        ForeignKey("objects.id", ondelete="CASCADE"), unique=True
    )

    stairs: Mapped[bool] = mapped_column(nullable=True)
    panoramic_glazing: Mapped[bool] = mapped_column(nullable=True)
    ceiling_height: Mapped[float] = mapped_column(nullable=True)
    total_vacancy_pct: Mapped[float] = mapped_column(nullable=True)
    first_floor_vacancy_pct: Mapped[float] = mapped_column(nullable=True)

    federal_tenants_in_h3: Mapped[int] = mapped_column(nullable=True)
    federal_tenants_density_100m2: Mapped[float] = mapped_column(nullable=True)

    spec_potential_h3: Mapped[float] = mapped_column(nullable=True)
    spec_potential_nano: Mapped[float] = mapped_column(nullable=True)
    spec_potential_micro: Mapped[float] = mapped_column(nullable=True)
    spec_potential_macro: Mapped[float] = mapped_column(nullable=True)

    is_facade: Mapped[bool] = mapped_column(nullable=True)
    undeveloped_area_pct: Mapped[float] = mapped_column(nullable=True)
    is_corner: Mapped[bool] = mapped_column(nullable=True)
    facade_depth_ratio: Mapped[float] = mapped_column(nullable=True)
    construction_year: Mapped[int] = mapped_column(nullable=True)

    object: Mapped[Object] = relationship(
        back_populates="potential",
    )
