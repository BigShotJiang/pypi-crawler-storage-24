from sqlalchemy import ForeignKey, Index, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base


class Segment(UUIDMixin, TimestampZoneMixin, Base):
    object_id: Mapped[int] = mapped_column(ForeignKey("objects.id", ondelete="CASCADE"))

    segment_code: Mapped[str] = mapped_column(String(20))
    segment_name: Mapped[str] = mapped_column(String(255))
    functional_group: Mapped[str] = mapped_column(String(100))
    area_range: Mapped[str | None] = mapped_column(String(20), nullable=True)
    object_format: Mapped[str] = mapped_column(String(50))
    floor: Mapped[str | None] = mapped_column(String(10), nullable=True)
    region: Mapped[str] = mapped_column(String(100))

    __table_args__ = (
        UniqueConstraint(
            "object_id",
            name="uix_object_id_object_segments",
        ),
        Index("idx_segment_code_object_segments", "segment_code"),
        Index("idx_object_id_object_segments", "object_id"),
    )
