from __future__ import annotations

from sqlalchemy import Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class SaleAnalytics(IdMixin, TimestampMixin, Base):
    __tablename__ = "sale_analytics"

    h3: Mapped[str] = mapped_column(nullable=False)
    view: Mapped[str] = mapped_column(nullable=False)
    avg_price_cell: Mapped[float] = mapped_column(nullable=False)
    avg_price_m2: Mapped[float] = mapped_column(nullable=False)
    object_count_cell: Mapped[int] = mapped_column(nullable=False)
    density: Mapped[float] = mapped_column(nullable=False)

    __table_args__ = (
        UniqueConstraint("h3", "view", name="uix_sale_h3_view"),
        Index("idx_sale_analytics_h3", "h3"),
    )
