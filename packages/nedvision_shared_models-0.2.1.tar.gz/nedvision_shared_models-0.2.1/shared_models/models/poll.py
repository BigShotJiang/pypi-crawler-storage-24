from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import ForeignKey, sql
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin

from .base import Base

if TYPE_CHECKING:
    from . import Question


class Poll(IdMixin, Base):
    code: Mapped[str] = mapped_column(
        ForeignKey("collections.code", ondelete="CASCADE"), unique=True
    )
    name: Mapped[str]
    step_by: Mapped[bool] = mapped_column(default=False, server_default=sql.false())

    questions: Mapped[list[Question]] = relationship(
        back_populates="poll", order_by="Question.index"
    )
