from __future__ import annotations

from typing import TYPE_CHECKING

import sqlalchemy
from sqlalchemy import BIGINT, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import Object, RegionBase


class Region(IdMixin, TimestampMixin, Base):
    system_id: Mapped[int] = mapped_column(BIGINT, nullable=False, unique=True)
    name: Mapped[str] = mapped_column(nullable=False)
    level: Mapped[int] = mapped_column(nullable=False)
    href: Mapped[str] = mapped_column(nullable=False)
    type: Mapped[str]
    coordinates: Mapped[dict[str, float]] = mapped_column(JSON, nullable=True)
    commercial_center_coordinates: Mapped[dict[str, float]] = mapped_column(
        JSON, nullable=True
    )
    has_region_base: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )

    objects: Mapped[list[Object]] = relationship(
        secondary="object_region_association",
        back_populates="regions",
        cascade="all, delete",
        passive_deletes=True,
    )
    region_base: Mapped[RegionBase] = relationship(
        back_populates="region",
    )
