from datetime import datetime

from sqlalchemy import BIGINT, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class GeoTraffic(IdMixin, TimestampMixin, Base):
    __tablename__ = "geo_traffic"

    h3: Mapped[str] = mapped_column()
    business_dt: Mapped[datetime] = mapped_column()
    monthly_traffic: Mapped[int] = mapped_column(BIGINT)
    daily_traffic: Mapped[float] = mapped_column()

    __table_args__ = (
        UniqueConstraint("h3", "business_dt", name="uix_geo_traffic_h3_business_dt"),
        Index("idx_geo_traffic_h3", "h3"),
    )
