from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any

import sqlalchemy
from sqlalchemy import BIGINT, JSON, Index
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

if TYPE_CHECKING:
    from .object import Object

from .base import Base


class Advertisement(IdMixin, TimestampMixin, Base):
    ads_id: Mapped[int] = mapped_column(BIGINT, nullable=False, unique=True)
    title: Mapped[str] = mapped_column(nullable=False)
    description: Mapped[str] = mapped_column(nullable=False)
    url: Mapped[str] = mapped_column(nullable=False)
    price: Mapped[int] = mapped_column(BIGINT, nullable=False)
    price_metric: Mapped[str] = mapped_column(nullable=True)
    time: Mapped[datetime] = mapped_column(nullable=False)
    phone: Mapped[str] = mapped_column(nullable=False)
    phone_operator: Mapped[str] = mapped_column(nullable=False)
    phone_protected: Mapped[int] = mapped_column(nullable=True)
    person: Mapped[str] = mapped_column(nullable=False)
    contactname: Mapped[str] = mapped_column(nullable=False)
    person_type: Mapped[str] = mapped_column(nullable=False)
    person_type_id: Mapped[int] = mapped_column(nullable=False)
    city: Mapped[str] = mapped_column(nullable=False)
    region: Mapped[str] = mapped_column(nullable=False)
    region_city: Mapped[str] = mapped_column(nullable=True)
    address: Mapped[str] = mapped_column(nullable=False)
    metro: Mapped[str] = mapped_column(nullable=True)
    nedvigimost_type: Mapped[str] = mapped_column(nullable=False)
    nedvigimost_type_id: Mapped[int] = mapped_column(nullable=False)
    avitoid: Mapped[int] = mapped_column(BIGINT, nullable=False, unique=True)
    source: Mapped[str] = mapped_column(nullable=False)
    source_id: Mapped[int] = mapped_column(BIGINT, nullable=False)
    images: Mapped[list[dict[str, str]]] = mapped_column(JSON, nullable=True)
    params: Mapped[dict[str, Any]] = mapped_column(nullable=True)
    category1: Mapped[int] = mapped_column(nullable=False)
    category2: Mapped[int] = mapped_column(nullable=False)
    category_name_1: Mapped[str] = mapped_column(nullable=False)
    category_name_2: Mapped[str] = mapped_column(nullable=False)
    coordinates: Mapped[dict[str, float]] = mapped_column(JSON, nullable=False)
    object_class: Mapped[str] = mapped_column(nullable=True)
    floors_count: Mapped[int] = mapped_column(nullable=True)
    count_ads_same_phone: Mapped[int] = mapped_column(nullable=True)
    phone_region: Mapped[str] = mapped_column(nullable=False)
    km_do_metro: Mapped[float] = mapped_column(nullable=True)
    avito_params: Mapped[dict[str, Any]] = mapped_column(nullable=True)
    time_source_created: Mapped[datetime] = mapped_column(nullable=True)
    time_source_updated: Mapped[datetime] = mapped_column(nullable=True)
    is_actual: Mapped[int] = mapped_column(nullable=False)
    metro_only: Mapped[str] = mapped_column(nullable=True)
    district_only: Mapped[str] = mapped_column(nullable=True)
    view: Mapped[str] = mapped_column(nullable=True)
    area: Mapped[str] = mapped_column(nullable=True)
    floor: Mapped[str] = mapped_column(nullable=True)
    views: Mapped[int] = mapped_column(BIGINT, nullable=True)
    processed: Mapped[bool] = mapped_column(
        default=False, server_default=sqlalchemy.sql.false()
    )
    verified: Mapped[bool] = mapped_column(nullable=True)

    object: Mapped[Object] = relationship(back_populates="advertisement")

    __table_args__ = (Index("idx_processed", "processed"),)
