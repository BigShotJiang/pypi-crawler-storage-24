from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

import sqlalchemy
from sqlalchemy import BigInteger, Index, String, Text
from sqlalchemy.dialects.postgresql import BYTEA
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base

if TYPE_CHECKING:
    pass


class RentalInvestorFeedback(Base):
    __tablename__ = "rental_investor_feedback"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
    )
    username: Mapped[str] = mapped_column(
        String(255),
        nullable=True,
    )
    text: Mapped[str] = mapped_column(
        Text,
        nullable=True,
    )
    docs: Mapped[list[bytes]] = mapped_column(
        sqlalchemy.ARRAY(BYTEA),
        nullable=True,
    )
    state: Mapped[str] = mapped_column(
        String(255),
        nullable=True,
    )
    images: Mapped[list[str]] = mapped_column(
        sqlalchemy.ARRAY(Text),
        nullable=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        server_default=sqlalchemy.text("CURRENT_TIMESTAMP"),
        nullable=True,
    )

    __table_args__ = (
        Index("idx_user_messages_user_id", "user_id"),
        Index("idx_user_messages_created_at", "created_at"),
    )
