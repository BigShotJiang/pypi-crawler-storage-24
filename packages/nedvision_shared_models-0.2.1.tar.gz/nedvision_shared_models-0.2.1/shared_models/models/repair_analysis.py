from sqlalchemy import Boolean, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base


class RepairAnalysis(UUIDMixin, Base, TimestampZoneMixin):
    __tablename__ = "repair_analysis"

    object_id: Mapped[int] = mapped_column(
        ForeignKey("objects.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
        index=True,
    )
    capital_repair: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
    )
    work_items: Mapped[list | None] = mapped_column(
        JSONB,
        nullable=True,
    )
    capital_repair_cost: Mapped[str | None] = mapped_column(
        String,
        nullable=True,
    )
    photos_total: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )
    photos_capital: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )
    per_image_results: Mapped[list | None] = mapped_column(
        JSONB,
        nullable=True,
    )
