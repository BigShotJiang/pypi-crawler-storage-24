from datetime import datetime

from sqlalchemy import BIGINT, INTEGER, TEXT, TIMESTAMP
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class ChannelStats(Base):
    __tablename__ = "channel_stats"

    channel_id: Mapped[int] = mapped_column(BIGINT, primary_key=True)
    channel_name: Mapped[str] = mapped_column(TEXT, nullable=False)
    username: Mapped[str | None] = mapped_column(TEXT, nullable=True)
    last_post_id: Mapped[int | None] = mapped_column(INTEGER, nullable=True)
    last_post_date: Mapped[datetime | None] = mapped_column(TIMESTAMP, nullable=True)
    total_posts: Mapped[int] = mapped_column(
        INTEGER, nullable=False, server_default="0"
    )
