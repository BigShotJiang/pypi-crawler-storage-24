from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import DECIMAL, CheckConstraint, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base

if TYPE_CHECKING:
    from . import User


class Balance(UUIDMixin, TimestampZoneMixin, Base):
    __tablename__ = "balances"

    user_id: Mapped[UUID] = mapped_column(
        ForeignKey(
            "users.id",
            ondelete="CASCADE",
        ),
        unique=True,
    )

    tokens: Mapped[float] = mapped_column(DECIMAL(precision=30, scale=18), default=0)
    xp: Mapped[float] = mapped_column(DECIMAL(precision=20, scale=2), default=0)

    user: Mapped[User] = relationship(
        back_populates="balance",
    )

    __table_args__ = (
        CheckConstraint("tokens >= 0", name="check_tokens_positive"),
        CheckConstraint("xp >= 0", name="check_xp_positive"),
    )
