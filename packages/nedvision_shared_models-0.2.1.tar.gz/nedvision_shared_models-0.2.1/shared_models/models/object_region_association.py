from sqlalchemy import Column, ForeignKey, Integer, Table, UniqueConstraint

from .base import Base

object_region_association_table = Table(
    "object_region_association",
    Base.metadata,
    Column("id", Integer, primary_key=True),
    Column(
        "object_id",
        ForeignKey("objects.id", ondelete="CASCADE"),
        nullable=False,
    ),
    Column(
        "region_id",
        ForeignKey("regions.id", ondelete="CASCADE"),
        nullable=False,
    ),
    UniqueConstraint("object_id", "region_id", name="idx_unique_object_region"),
)
