from sqlalchemy import Enum, ForeignKey, Index, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.enums import ImageType
from shared_models.mixins import TimestampMixin, UUIDMixin

from .base import Base


class Image(Base, TimestampMixin, UUIDMixin):
    object_id: Mapped[int] = mapped_column(
        ForeignKey("objects.id", ondelete="CASCADE"),
        nullable=False,
    )
    url: Mapped[str] = mapped_column(nullable=False)

    image_type: Mapped[str] = mapped_column(
        Enum(
            ImageType,
            name="ImageType",
            create_type=True,
        ),
        default=ImageType.OBJ,
    )
    image_data: Mapped[str | None] = mapped_column(nullable=True)

    analysis_result: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    __table_args__ = (
        UniqueConstraint("object_id", "url", name="uix_images_object_id_url"),
        Index("idx_images_analysis_result", "analysis_result", postgresql_using="gin"),
        Index("idx_images_object_id", "object_id"),
        Index("idx_images_type", "image_type"),
    )
