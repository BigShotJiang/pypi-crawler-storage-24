from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import ForeignKey, UniqueConstraint, sql
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin

from .base import Base

if TYPE_CHECKING:
    from . import Answer, Poll


class Question(IdMixin, Base):
    poll_id: Mapped[int] = mapped_column(ForeignKey("polls.id", ondelete="CASCADE"))
    index: Mapped[int]
    text: Mapped[str]
    view_type: Mapped[str]
    control_name: Mapped[str] = mapped_column(nullable=False)
    required: Mapped[bool] = mapped_column(default=False, server_default=sql.false())
    placeholder: Mapped[str] = mapped_column(nullable=True)
    is_calculated: Mapped[bool] = mapped_column(
        default=False, server_default=sql.false()
    )

    poll: Mapped[Poll] = relationship(back_populates="questions")
    answers: Mapped[list[Answer]] = relationship(
        back_populates="question", foreign_keys="Answer.question_id"
    )
    previous_answers: Mapped[list[Answer]] = relationship(
        back_populates="next_question", foreign_keys="Answer.next_question_id"
    )

    __table_args__ = (
        UniqueConstraint("poll_id", "index", name="uix_poll_id_index_questions"),
        UniqueConstraint(
            "poll_id", "control_name", name="uix_poll_id_control_name_questions"
        ),
    )
