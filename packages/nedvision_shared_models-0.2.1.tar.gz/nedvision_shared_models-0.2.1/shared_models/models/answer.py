from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import ForeignKey, UniqueConstraint, sql
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin

from .base import Base

if TYPE_CHECKING:
    from . import Question


class Answer(IdMixin, Base):
    question_id: Mapped[int] = mapped_column(
        ForeignKey("questions.id", ondelete="CASCADE")
    )
    next_question_id: Mapped[int] = mapped_column(
        ForeignKey("questions.id"), nullable=True
    )
    value: Mapped[str]
    text: Mapped[str]
    description: Mapped[str] = mapped_column(nullable=True)
    is_disabled: Mapped[bool] = mapped_column(
        server_default=sql.false(), default=False, comment="Flag to display on frontend"
    )
    is_active: Mapped[bool] = mapped_column(server_default=sql.true(), default=True)

    question: Mapped[Question] = relationship(
        foreign_keys=[question_id], back_populates="answers"
    )
    next_question: Mapped[Question | None] = relationship(
        foreign_keys=[next_question_id], back_populates="previous_answers"
    )

    __table_args__ = (
        UniqueConstraint("question_id", "value", name="uix_question_id_value_answers"),
    )
