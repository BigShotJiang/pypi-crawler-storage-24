from datetime import datetime

from sqlalchemy import BIGINT, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class GeoIncome(IdMixin, TimestampMixin, Base):
    __tablename__ = "geo_income"

    h3: Mapped[str] = mapped_column()
    business_dt: Mapped[datetime] = mapped_column()

    income_0_20000: Mapped[int] = mapped_column(BIGINT)
    income_20000_30000: Mapped[int] = mapped_column(BIGINT)
    income_30000_40000: Mapped[int] = mapped_column(BIGINT)
    income_40000_50000: Mapped[int] = mapped_column(BIGINT)
    income_50000_60000: Mapped[int] = mapped_column(BIGINT)
    income_60000_70000: Mapped[int] = mapped_column(BIGINT)
    income_70000_80000: Mapped[int] = mapped_column(BIGINT)
    income_80000_90000: Mapped[int] = mapped_column(BIGINT)
    income_90000_100000: Mapped[int] = mapped_column(BIGINT)
    income_100000_110000: Mapped[int] = mapped_column(BIGINT)
    income_110000_120000: Mapped[int] = mapped_column(BIGINT)
    income_120000_130000: Mapped[int] = mapped_column(BIGINT)
    income_130000_140000: Mapped[int] = mapped_column(BIGINT)
    income_140000_150000: Mapped[int] = mapped_column(BIGINT)
    income_150000_200000: Mapped[int] = mapped_column(BIGINT)
    income_200000_250000: Mapped[int] = mapped_column(BIGINT)
    income_250000_300000: Mapped[int] = mapped_column(BIGINT)
    income_300000_400000: Mapped[int] = mapped_column(BIGINT)
    income_400000_500000: Mapped[int] = mapped_column(BIGINT)
    income_500000_plus: Mapped[int] = mapped_column(BIGINT)

    __table_args__ = (
        UniqueConstraint("h3", "business_dt", name="uix_geo_income_h3_business_dt"),
        Index("idx_geo_income_dt_h3", "business_dt", "h3"),
    )
