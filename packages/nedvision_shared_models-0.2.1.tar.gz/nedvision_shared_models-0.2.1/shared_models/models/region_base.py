from __future__ import annotations

from typing import TYPE_CHECKING

import sqlalchemy
from sqlalchemy import BIGINT, ForeignKey, Index, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.enums import RegionType
from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import (Hexagon, Region, RegionAges, RegionAverages,
                   RegionEconomics, RegionExpenses, RegionIncome,
                   TrafficAndResidents)


class RegionBase(IdMixin, TimestampMixin, Base):
    __tablename__ = "region_base"

    region_id: Mapped[int] = mapped_column(
        BIGINT,
        ForeignKey("regions.id", ondelete="CASCADE"),
        unique=True,
    )
    osm_id: Mapped[int] = mapped_column(unique=True)
    name: Mapped[str] = mapped_column(nullable=False, unique=True)
    href: Mapped[str] = mapped_column(nullable=False)
    osm_string: Mapped[str] = mapped_column(nullable=False, unique=True)
    type: Mapped[RegionType]

    has_hexagons: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )

    hexagons: Mapped[list[Hexagon]] = relationship(
        secondary="region_hexagon",
        back_populates="regions",
    )

    traffic_and_residents: Mapped[TrafficAndResidents] = relationship(
        back_populates="region_base",
    )

    averages: Mapped[RegionAverages] = relationship(back_populates="region_base")

    region_ages: Mapped[RegionAges] = relationship(back_populates="region_base")

    region_income: Mapped[RegionIncome] = relationship(back_populates="region_base")

    region_expenses: Mapped[RegionExpenses] = relationship(back_populates="region_base")

    region: Mapped[Region] = relationship(back_populates="region_base")

    region_economics: Mapped[list[RegionEconomics]] = relationship(
        back_populates="region_base"
    )

    __table_args__ = (
        Index(
            "ix_region_base_name_trgm",
            text("lower(name) gin_trgm_ops"),
            postgresql_using="gin",
        ),
        Index("ix_region_base_type", "type"),
    )
