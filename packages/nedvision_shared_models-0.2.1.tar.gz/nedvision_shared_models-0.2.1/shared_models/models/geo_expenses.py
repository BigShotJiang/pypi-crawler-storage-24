from datetime import datetime

from sqlalchemy import Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class GeoExpenses(IdMixin, TimestampMixin, Base):
    __tablename__ = "geo_expenses"

    h3: Mapped[str]
    business_dt: Mapped[datetime]

    flowers: Mapped[float] = mapped_column(nullable=False, default=0.0)
    financial_services: Mapped[float] = mapped_column(nullable=False, default=0.0)
    fast_food: Mapped[float] = mapped_column(nullable=False, default=0.0)
    travel_agencies: Mapped[float] = mapped_column(nullable=False, default=0.0)
    transport: Mapped[float] = mapped_column(nullable=False, default=0.0)
    fuel: Mapped[float] = mapped_column(nullable=False, default=0.0)
    taxi: Mapped[float] = mapped_column(nullable=False, default=0.0)
    supermarkets: Mapped[float] = mapped_column(nullable=False, default=0.0)
    sports_goods: Mapped[float] = mapped_column(nullable=False, default=0.0)
    services: Mapped[float] = mapped_column(nullable=False, default=0.0)
    telecom: Mapped[float] = mapped_column(nullable=False, default=0.0)
    restaurants: Mapped[float] = mapped_column(nullable=False, default=0.0)
    misc_goods: Mapped[float] = mapped_column(nullable=False, default=0.0)
    entertainment: Mapped[float] = mapped_column(nullable=False, default=0.0)
    budget_payments: Mapped[float] = mapped_column(nullable=False, default=0.0)
    hotels: Mapped[float] = mapped_column(nullable=False, default=0.0)
    clothing_shoes: Mapped[float] = mapped_column(nullable=False, default=0.0)
    nko: Mapped[float] = mapped_column(nullable=False, default=0.0)
    cash: Mapped[float] = mapped_column(nullable=False, default=0.0)
    medical_services: Mapped[float] = mapped_column(nullable=False, default=0.0)
    beauty: Mapped[float] = mapped_column(nullable=False, default=0.0)
    books: Mapped[float] = mapped_column(nullable=False, default=0.0)
    cinema: Mapped[float] = mapped_column(nullable=False, default=0.0)
    carsharing: Mapped[float] = mapped_column(nullable=False, default=0.0)
    utilities: Mapped[float] = mapped_column(nullable=False, default=0.0)
    pets: Mapped[float] = mapped_column(nullable=False, default=0.0)
    railway_tickets: Mapped[float] = mapped_column(nullable=False, default=0.0)
    home_repair: Mapped[float] = mapped_column(nullable=False, default=0.0)
    pharmacy: Mapped[float] = mapped_column(nullable=False, default=0.0)
    auto_services: Mapped[float] = mapped_column(nullable=False, default=0.0)
    plane_tickets: Mapped[float] = mapped_column(nullable=False, default=0.0)

    __table_args__ = (
        UniqueConstraint("h3", "business_dt", name="uix_h3_business_dt"),
        Index("idx_geo_expenses_dt_h3", "business_dt", "h3"),
    )
