from __future__ import annotations

from typing import TYPE_CHECKING, Any

import sqlalchemy
from sqlalchemy import (BIGINT, JSON, CheckConstraint, Enum, ForeignKey, Index,
                        String)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from ..enums import Profile
from .base import Base

if TYPE_CHECKING:
    from . import (Advertisement, Economic, ObjectData, Potential, Region,
                   RentBase, SaleBase)


class Object(IdMixin, TimestampMixin, Base):
    ad_id: Mapped[int] = mapped_column(
        ForeignKey("advertisements.id", ondelete="CASCADE"), unique=True
    )
    suggested_profile: Mapped[Profile] = mapped_column(
        Enum(
            Profile,
            name="Profile",
            create_type=True,
        ),
        nullable=True,
    )
    title: Mapped[str] = mapped_column(nullable=False)
    description: Mapped[str] = mapped_column(nullable=False)
    url: Mapped[str] = mapped_column(nullable=False)
    price: Mapped[int] = mapped_column(BIGINT, nullable=False)
    price_metric: Mapped[str] = mapped_column(nullable=True)
    city: Mapped[str] = mapped_column(nullable=False)
    region: Mapped[str] = mapped_column(nullable=False)
    region_city: Mapped[str] = mapped_column(nullable=True)
    address: Mapped[str] = mapped_column(nullable=False)
    nedvigimost_type: Mapped[str] = mapped_column(nullable=False)
    images: Mapped[list[dict[str, str]]] = mapped_column(JSON, nullable=True)
    coordinates: Mapped[dict[str, float]] = mapped_column(JSON, nullable=False)
    area: Mapped[float] = mapped_column(nullable=False)
    floor: Mapped[str] = mapped_column(nullable=True)
    floors_coef: Mapped[float] = mapped_column(nullable=True)
    floors_count: Mapped[int] = mapped_column(nullable=True)
    view: Mapped[str] = mapped_column(nullable=True)
    params: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=True)

    # columns for analyzer
    separate_entrance: Mapped[bool] = mapped_column(nullable=True)
    location_floor: Mapped[int] = mapped_column(nullable=True)
    communications: Mapped[bool] = mapped_column(nullable=True)
    tenants: Mapped[str] = mapped_column(nullable=True)

    category: Mapped[str] = mapped_column(String(length=50), nullable=True)
    type: Mapped[str] = mapped_column(nullable=True)

    profile: Mapped[str] = mapped_column(nullable=True)

    trash: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )
    is_marked: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )
    regions_set: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )
    analyzed: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )
    has_potential: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )
    has_economics: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )
    nano_region_set: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )
    has_rent_base: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )
    ready: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )
    skipped: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )
    is_actual: Mapped[bool] = mapped_column(nullable=True)
    views: Mapped[int] = mapped_column(BIGINT, default=0, server_default="0")

    regions: Mapped[list[Region]] = relationship(
        secondary="object_region_association",
        back_populates="objects",
    )

    potential: Mapped[Potential] = relationship(
        back_populates="object",
    )

    economic: Mapped[Economic] = relationship(
        back_populates="object",
    )

    rent_base: Mapped[RentBase] = relationship(
        back_populates="object",
    )

    sale_base: Mapped[SaleBase] = relationship(
        back_populates="object",
    )

    object_data: Mapped[ObjectData] = relationship(
        back_populates="object",
    )
    advertisement: Mapped[Advertisement] = relationship(back_populates="object")

    __table_args__ = (
        Index("idx_regions_set", "regions_set"),
        Index("idx_analyzed", "analyzed"),
        Index("idx_is_marked", "is_marked"),
        Index("idx_type_rent_base", "nedvigimost_type", "has_rent_base"),
        CheckConstraint("views >= 0", name="views_non_negative"),
    )
