from __future__ import annotations

from uuid import UUID

from sqlalchemy import Enum, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.enums import MessageContentType, MessageRole
from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base


class Message(UUIDMixin, Base, TimestampZoneMixin):
    dialog_id: Mapped[UUID] = mapped_column(
        ForeignKey("dialogs.id", ondelete="CASCADE"),
    )
    text: Mapped[str] = mapped_column(nullable=False)
    content_type: Mapped[MessageContentType] = mapped_column(
        Enum(
            MessageContentType,
            name="MessageContentType",
            create_type=True,
        ),
        nullable=False,
    )
    role: Mapped[MessageRole] = mapped_column(
        Enum(
            MessageRole,
            name="MessageRole",
            create_type=True,
        ),
        nullable=False,
    )

    meta: Mapped[dict] = mapped_column(JSONB, nullable=True)
