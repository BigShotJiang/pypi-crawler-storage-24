from datetime import datetime
from uuid import UUID

from sqlalchemy import BIGINT, ForeignKey, func
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import UUIDMixin

from .base import Base


class CollectionCounter(UUIDMixin, Base):
    collection_id: Mapped[UUID] = mapped_column(
        ForeignKey("answers_collections.id", ondelete="CASCADE"),
        unique=True,
    )
    objects_count: Mapped[int] = mapped_column(BIGINT, default=0)
    last_counted_at: Mapped[datetime] = mapped_column(
        server_default=func.now(),
        onupdate=func.now(),
    )
