from datetime import datetime

from sqlalchemy import BIGINT, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class GeoPopulation(IdMixin, TimestampMixin, Base):
    __tablename__ = "geo_population"

    h3: Mapped[str] = mapped_column()
    business_dt: Mapped[datetime] = mapped_column()
    total_residents: Mapped[int] = mapped_column(BIGINT)

    __table_args__ = (
        UniqueConstraint("h3", "business_dt", name="uix_geo_population_h3_business_dt"),
        Index("idx_geo_population_h3", "h3"),
    )
