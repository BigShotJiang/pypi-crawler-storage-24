from sqlalchemy import Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class Building(IdMixin, TimestampMixin, Base):
    address: Mapped[str]
    latitude: Mapped[float]
    longitude: Mapped[float]
    h3: Mapped[str]

    construction_year: Mapped[int] = mapped_column(nullable=True)
    floor_count: Mapped[int | None] = mapped_column(nullable=True)
    cadastral_number: Mapped[str] = mapped_column(nullable=True)
    building_area: Mapped[float] = mapped_column(nullable=True)
    first_floor_area: Mapped[float] = mapped_column(nullable=True)

    is_facade: Mapped[bool]
    is_corner: Mapped[bool]
    facade_depth_ratio: Mapped[float]

    land_cadastral_number: Mapped[str] = mapped_column(nullable=True)
    land_area: Mapped[float] = mapped_column(nullable=True)

    __table_args__ = (
        Index("idx_buildings_h3", "h3"),
        Index("idx_buildings_cadastral", "cadastral_number"),
        Index("idx_buildings_land_cadastral", "land_cadastral_number"),
        Index("idx_buildings_coords", "latitude", "longitude"),
        UniqueConstraint("latitude", "longitude", name="uix_buildings_coordinates"),
    )
