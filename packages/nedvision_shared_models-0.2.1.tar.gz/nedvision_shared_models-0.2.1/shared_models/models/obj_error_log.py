from sqlalchemy import Enum, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.enums.reason import Reason
from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base


class ObjErrorLog(UUIDMixin, Base, TimestampZoneMixin):
    __tablename__ = "obj_error_logs"

    obj_id: Mapped[int] = mapped_column(
        ForeignKey("objects.id", ondelete="CASCADE"),
        unique=True,
    )
    reason: Mapped[Reason] = mapped_column(
        Enum(Reason, name="reason", create_type=True),
        nullable=False,
        index=True,
    )
    meta: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
