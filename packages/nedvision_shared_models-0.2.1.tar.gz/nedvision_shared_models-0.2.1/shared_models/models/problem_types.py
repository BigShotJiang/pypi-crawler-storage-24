from sqlalchemy.orm import Mapped

from shared_models.mixins import IdMixin

from .base import Base


class ProblemType(Base, IdMixin):
    __tablename__ = "problem_types"

    name: Mapped[str]
