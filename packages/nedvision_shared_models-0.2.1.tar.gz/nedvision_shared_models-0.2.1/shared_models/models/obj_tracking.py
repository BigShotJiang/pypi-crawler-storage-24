import sqlalchemy.sql
from sqlalchemy import BIGINT, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base


class ObjTracking(UUIDMixin, Base, TimestampZoneMixin):
    __tablename__ = "object_tracking"

    telegram_id: Mapped[int] = mapped_column(BIGINT, nullable=False)
    ad_id: Mapped[int] = mapped_column(
        ForeignKey("advertisements.id", ondelete="CASCADE")
    )
    processed: Mapped[bool] = mapped_column(
        nullable=False,
        server_default=sqlalchemy.sql.false(),
    )

    __table_args__ = (UniqueConstraint("telegram_id", "ad_id", name="uq_telegram_ad"),)
