from sqlalchemy import Enum, sql
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.enums import Profile
from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base


class InvProfileDictionary(Base, TimestampZoneMixin, UUIDMixin):
    __tablename__ = "inv_profile_dictionary"

    profile: Mapped[Profile] = mapped_column(
        Enum(Profile, name="profile"),
        nullable=False,
        unique=True,
    )

    name_ru: Mapped[str] = mapped_column(nullable=False)
    name_eng: Mapped[str] = mapped_column(nullable=False)
    is_active: Mapped[bool] = mapped_column(nullable=False, server_default=sql.true())

    description: Mapped[str] = mapped_column(nullable=False)
