from sqlalchemy import ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class EconomicsDataset(IdMixin, TimestampMixin, Base):
    __tablename__ = "economics_dataset"

    object_id: Mapped[int] = mapped_column(
        ForeignKey("objects.id", ondelete="CASCADE"), unique=True
    )
    economics: Mapped[dict] = mapped_column(JSONB)
