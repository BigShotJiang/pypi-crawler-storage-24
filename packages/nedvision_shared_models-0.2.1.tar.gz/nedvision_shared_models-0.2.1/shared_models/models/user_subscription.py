from datetime import datetime
from uuid import UUID

from sqlalchemy import DateTime, ForeignKey, UniqueConstraint, sql
from sqlalchemy.orm import Mapped, mapped_column
from . import Base

from shared_models.mixins import TimestampZoneMixin, UUIDMixin


class UserSubscription(UUIDMixin, Base, TimestampZoneMixin):
    user_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    subscription_id: Mapped[UUID] = mapped_column(
        ForeignKey("subscriptions.id", ondelete="RESTRICT"), nullable=False
    )
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    is_active: Mapped[bool] = mapped_column(
        nullable=False,
        server_default=sql.true(),
    )

    __table_args__ = (UniqueConstraint("user_id", name="uq_user_active_subscription"),)
