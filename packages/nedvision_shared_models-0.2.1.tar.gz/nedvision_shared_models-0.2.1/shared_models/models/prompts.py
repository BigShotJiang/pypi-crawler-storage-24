from sqlalchemy import TEXT
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import TimestampMixin, UUIDMixin

from .base import Base


class Prompt(UUIDMixin, TimestampMixin, Base):
    text: Mapped[str] = mapped_column(TEXT, nullable=False)
    type: Mapped[str] = mapped_column(nullable=False)
