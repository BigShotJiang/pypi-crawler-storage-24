from __future__ import annotations

from typing import Any

from sqlalchemy import ForeignKey, Text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import TimestampMixin, UUIDMixin

from .base import Base


class GeoChecks(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "geo_checks"

    object_id: Mapped[int] = mapped_column(
        ForeignKey("objects.id", ondelete="SET NULL"), unique=True
    )
    actual_address: Mapped[str] = mapped_column(nullable=False)
    hexagon_size: Mapped[int] = mapped_column(nullable=False)
    top_categories: Mapped[list[str]] = mapped_column(ARRAY(Text), nullable=True)

    data: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
