from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import RegionBase


class Hexagon(TimestampMixin, Base):
    index: Mapped[str] = mapped_column(primary_key=True)

    regions: Mapped[list[RegionBase]] = relationship(
        secondary="region_hexagon",
        back_populates="hexagons",
    )
