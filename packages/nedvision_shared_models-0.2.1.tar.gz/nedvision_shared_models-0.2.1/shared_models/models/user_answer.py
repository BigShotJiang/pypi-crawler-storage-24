from sqlalchemy import UUID, ForeignKey, Index, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin

from .base import Base


class UserAnswer(IdMixin, Base):
    control_name: Mapped[str] = mapped_column(nullable=False)
    value: Mapped[str] = mapped_column(nullable=True)
    value_arr: Mapped[list[str]] = mapped_column(ARRAY(String), nullable=True)
    user_id: Mapped[UUID] = mapped_column(
        ForeignKey(
            "users.id",
            ondelete="CASCADE",
        )
    )

    collection_id: Mapped[int] = mapped_column(
        ForeignKey(
            "answers_collections.id",
            ondelete="CASCADE",
        ),
        nullable=True,
    )

    object_id: Mapped[int] = mapped_column(
        ForeignKey("objects.id", ondelete="CASCADE"), nullable=True
    )

    __table_args__ = (
        UniqueConstraint(
            "user_id",
            "control_name",
            "collection_id",
            "object_id",
            name="uix_user_answer_collection",
        ),
        Index(
            "ix_user_answer_no_collection",
            "user_id",
            "control_name",
            postgresql_where=collection_id.is_(None),
            unique=True,
        ),
    )
