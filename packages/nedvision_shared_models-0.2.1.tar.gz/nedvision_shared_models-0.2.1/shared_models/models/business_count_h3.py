from sqlalchemy import BIGINT
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class BusinessesCountH3(IdMixin, TimestampMixin, Base):
    __tablename__ = "businesses_count_h3"

    h3: Mapped[str] = mapped_column(nullable=False)
    category: Mapped[str]
    count: Mapped[int] = mapped_column(BIGINT)
