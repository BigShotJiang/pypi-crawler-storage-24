from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

import sqlalchemy
from sqlalchemy import BigInteger, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base

if TYPE_CHECKING:
    pass


class RentalInvestorLikes(Base):
    __tablename__ = "rental_investor_likes"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    is_like: Mapped[bool] = mapped_column(nullable=False)

    user_id: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
    )
    username: Mapped[str] = mapped_column(
        String(255),
        nullable=True,
    )

    service: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )

    info: Mapped[str] = mapped_column(
        Text,
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        server_default=sqlalchemy.text("CURRENT_TIMESTAMP"),
        nullable=True,
    )
