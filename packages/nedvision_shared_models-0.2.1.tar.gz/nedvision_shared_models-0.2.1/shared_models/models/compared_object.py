from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import ForeignKey, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import TimestampMixin, UUIDMixin

from .base import Base

if TYPE_CHECKING:
    from . import ObjectData, User


class ComparedObject(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "compared_objects"

    user_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"),
    )
    object_data_id: Mapped[UUID] = mapped_column(
        ForeignKey("webapp.objects_data.id", ondelete="CASCADE"),
    )

    user: Mapped[User] = relationship(
        back_populates="compared_objects",
    )
    object_data: Mapped[ObjectData] = relationship(
        back_populates="compared_objects",
    )

    __table_args__ = (
        UniqueConstraint("user_id", "object_data_id", name="uq_user_object"),
        Index("idx_user_id", "user_id", postgresql_using="btree"),
        Index("idx_object_data_id", "object_data_id", postgresql_using="btree"),
    )
