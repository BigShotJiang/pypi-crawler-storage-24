from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

import sqlalchemy
from sqlalchemy import CheckConstraint, Index, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base

if TYPE_CHECKING:
    from .tenant_term import TenantTerm


class TenantInfo(Base):
    __tablename__ = "tenants_info"

    tenant_id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True,
        server_default=sqlalchemy.text(
            "nextval('tenants_info_tenant_id_seq'::regclass)"
        ),
    )
    tenant_name: Mapped[str] = mapped_column(String(255), nullable=False)
    network_sign: Mapped[bool] = mapped_column(nullable=False)
    federal_regional_sign: Mapped[str] = mapped_column(String(20), nullable=False)
    tenant_region: Mapped[str] = mapped_column(String(255), nullable=False)
    site_link: Mapped[str] = mapped_column(Text, nullable=True)
    lease_form_link: Mapped[str] = mapped_column(Text, nullable=True)
    icon: Mapped[str] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        server_default=sqlalchemy.text("CURRENT_TIMESTAMP"), nullable=True
    )
    updated_at: Mapped[datetime] = mapped_column(
        server_default=sqlalchemy.text("CURRENT_TIMESTAMP"),
        onupdate=sqlalchemy.text("CURRENT_TIMESTAMP"),
        nullable=True,
    )

    terms: Mapped[list[TenantTerm]] = relationship(
        back_populates="tenant_info", cascade="all, delete-orphan"
    )

    __table_args__ = (
        Index("idx_tenant_name", "tenant_name"),
        Index("idx_region", "tenant_region"),
        CheckConstraint(
            "federal_regional_sign IN ('federal', 'regional')",
            name="tenants_info_federal_regional_sign_check",
        ),
    )
