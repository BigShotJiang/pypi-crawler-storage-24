from datetime import datetime

import sqlalchemy
from sqlalchemy import UUID, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin

from .base import Base


class UserMetadata(IdMixin, Base):
    object_id: Mapped[int] = mapped_column(
        ForeignKey("objects.id", ondelete="CASCADE"),
    )
    user_id: Mapped[UUID] = mapped_column(
        ForeignKey(
            "users.id",
            ondelete="CASCADE",
        ),
    )

    read_at: Mapped[datetime] = mapped_column(nullable=True)
    rating: Mapped[float] = mapped_column(nullable=True)
    favourites: Mapped[bool] = mapped_column(
        default=False,
        nullable=False,
        server_default=sqlalchemy.sql.false(),
    )

    __table_args__ = (
        UniqueConstraint(
            "user_id",
            "object_id",
            name="uix_user_id_object_id_user_metadata",
        ),
    )
