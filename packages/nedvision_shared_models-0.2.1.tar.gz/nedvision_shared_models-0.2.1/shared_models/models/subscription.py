from decimal import Decimal

from sqlalchemy import DECIMAL, Boolean, Enum, String, sql
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.enums import SubscriptionCode
from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base


class Subscription(UUIDMixin, Base, TimestampZoneMixin):
    code: Mapped[SubscriptionCode] = mapped_column(
        Enum(
            SubscriptionCode,
            name="subscription_code",
            create_type=True,
            native_enum=True,
        ),
        unique=True,
        nullable=False,
    )
    name_ru: Mapped[str] = mapped_column(String(100), nullable=False)
    name_eng: Mapped[str] = mapped_column(String(100), nullable=False)

    price_monthly: Mapped[Decimal] = mapped_column(DECIMAL(30, 18), nullable=False)
    price_annual: Mapped[Decimal] = mapped_column(DECIMAL(30, 18), nullable=False)
    price_monthly_tokens: Mapped[Decimal] = mapped_column(
        DECIMAL(30, 18), nullable=False
    )
    price_annual_tokens: Mapped[Decimal] = mapped_column(
        DECIMAL(30, 18), nullable=False
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean, nullable=False, server_default=sql.true()
    )
