from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import BIGINT, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import TimestampMixin, UUIDMixin

from ..enums import Profile
from .base import Base

if TYPE_CHECKING:
    from . import Balance, ComparedObject, Flag, UserAction, UserRank


class User(UUIDMixin, TimestampMixin, Base):
    name: Mapped[str]
    tg_id: Mapped[int | None] = mapped_column(BIGINT, unique=True, nullable=True)

    preferred_profile: Mapped[Profile | None] = mapped_column(
        Enum(Profile, name="profile", create_type=True), nullable=True
    )

    email: Mapped[str | None] = mapped_column(unique=True, nullable=True)
    hashed_password: Mapped[str | None] = mapped_column(nullable=True)

    flags: Mapped[Flag] = relationship(
        back_populates="user",
    )
    user_actions: Mapped[list[UserAction]] = relationship(
        back_populates="user",
    )
    balance: Mapped[Balance] = relationship(
        back_populates="user",
    )
    user_rank: Mapped[UserRank] = relationship(
        back_populates="user",
    )
    compared_objects: Mapped[list[ComparedObject]] = relationship(
        back_populates="user",
    )
