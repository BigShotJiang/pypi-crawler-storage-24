from datetime import datetime

from sqlalchemy import BIGINT, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class GeoAge(IdMixin, TimestampMixin, Base):
    __tablename__ = "geo_age"

    h3: Mapped[str] = mapped_column()
    business_dt: Mapped[datetime] = mapped_column()
    age_0_17: Mapped[int] = mapped_column(BIGINT)
    age_18_24: Mapped[int] = mapped_column(BIGINT)
    age_25_34: Mapped[int] = mapped_column(BIGINT)
    age_35_44: Mapped[int] = mapped_column(BIGINT)
    age_45_54: Mapped[int] = mapped_column(BIGINT)
    age_55_64: Mapped[int] = mapped_column(BIGINT)
    age_65_plus: Mapped[int] = mapped_column(BIGINT)

    __table_args__ = (
        UniqueConstraint("h3", "business_dt", name="uix_geo_age_h3_business_dt"),
        Index("idx_geo_age_dt_h3", "business_dt", "h3"),
    )
