from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import BIGINT, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import RegionBase


class RegionAges(IdMixin, TimestampMixin, Base):
    __tablename__ = "region_ages"

    region_base_id: Mapped[int] = mapped_column(
        ForeignKey("region_base.id", ondelete="CASCADE"), unique=True
    )

    age_0_17: Mapped[int] = mapped_column(BIGINT, nullable=True)
    age_18_24: Mapped[int] = mapped_column(BIGINT, nullable=True)
    age_25_34: Mapped[int] = mapped_column(BIGINT, nullable=True)
    age_35_44: Mapped[int] = mapped_column(BIGINT, nullable=True)
    age_45_54: Mapped[int] = mapped_column(BIGINT, nullable=True)
    age_55_64: Mapped[int] = mapped_column(BIGINT, nullable=True)
    age_65_plus: Mapped[int] = mapped_column(BIGINT, nullable=True)

    region_base: Mapped[RegionBase] = relationship(
        back_populates="region_ages",
    )
