from sqlalchemy import Column, ForeignKey, Table, UniqueConstraint

from .base import Base

region_hexagon_association_table = Table(
    "region_hexagon",
    Base.metadata,
    Column(
        "hexagon_index",
        ForeignKey("hexagons.index", ondelete="CASCADE"),
        nullable=False,
    ),
    Column(
        "region_base_id",
        ForeignKey("region_base.id", ondelete="CASCADE"),
        nullable=False,
    ),
    UniqueConstraint("hexagon_index", "region_base_id", name="idx_unique_h3_region"),
)
