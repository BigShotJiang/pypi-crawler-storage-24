from enum import Enum


class LLM(str, Enum):
    DEEPSEEK = "deepseek-chat"
