from enum import Enum


class Reason(str, Enum):
    DESCRIPTION_ANALYSIS_FAIL = "description_analysis_fail"
    SCRAPPER_PARSE_FAIL = "scrapper_parse_fail"
