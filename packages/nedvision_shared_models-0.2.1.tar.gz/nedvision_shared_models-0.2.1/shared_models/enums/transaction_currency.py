from enum import Enum


class TransactionCurrency(Enum):
    XP = "XP"
    TOKENS = "TOKENS"
