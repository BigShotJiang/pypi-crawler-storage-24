from enum import Enum


class TransactionBatchStatus(Enum):
    OPEN = "OPEN"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
