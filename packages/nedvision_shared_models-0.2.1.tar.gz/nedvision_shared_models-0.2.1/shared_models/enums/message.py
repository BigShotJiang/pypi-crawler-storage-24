from enum import Enum


class MessageContentType(str, Enum):
    TEXT = "text"
    SQL = "sql"
