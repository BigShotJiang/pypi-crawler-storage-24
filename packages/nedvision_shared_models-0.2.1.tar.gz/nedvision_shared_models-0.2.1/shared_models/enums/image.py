from enum import Enum


class ImageType(str, Enum):
    OBJ = "object"
    MAP = "map"
