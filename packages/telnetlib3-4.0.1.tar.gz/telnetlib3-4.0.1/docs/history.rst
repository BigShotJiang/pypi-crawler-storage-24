History
=======
4.0.1
  * new: ``--encoding=big5bbs``, BBS 半形字 (half-width characters) encoding, matching PCMan/PttBBS
    terminal clients, popular with Taiwanese BBS culture.
  * enhancement: ``telnetlib3-client`` now works on Windows by using the optional
    ``blessed>=1.20`` dependency, installed automatically for Windows platforms.
  * bugfix: ``telnetlib3-client`` could begin a shell in wrong ECHO mode, depending on order of
    options in a "connection burst".
  * bugfix: :class:`~telnetlib3._session_context.TelnetSessionContext` ``gmcp_data``
    mutable default argument caused all instances to share a single dict, so GMCP data
    from one connection contaminated subsequent connections.
  * bugfix: keyboard escape detection raised :exc:`UnicodeDecodeError` on non-UTF-8
    terminal input bytes; now uses ``errors="replace"``.

4.0.0
  * removed: ``telnetlib3.color_filter``. ``ColorFilter``, ``ColorConfig``, ``PALETTES``,
    ``PetsciiColorFilter``, and ``AtasciiControlFilter`` have all been moved to the downstream
    `Telix <https://github.com/jquast/Telix>`_ project, recommended for connecting to legacy `BBSs
    <https://bbs.modem.xyz/>`_ systems requiring color correction.

    ``telnetlib3-client`` CLI args ``--colormatch``, ``--color-brightness``, ``--color-contrast``,
    ``--background-color``, ``--ice-colors`` removed.

3.0.3
  * bugfix: server and client now correctly complete LINEMODE negotiation when prompted to.
  * new: ``--logfile-mode {append,rewrite}`` and ``--typescript-mode`` CLI flags
    and :func:`~telnetlib3.accessories.make_logger` ``filemode`` argument control whether the log
    file is appended to (default) or overwritten on each connection.
  * new: :class:`~telnetlib3.client_shell.LinemodeBuffer` used by ``telnetlib3-client``, a
    client-side line buffer for LINEMODE EDIT mode with local erase-char, erase-line, erase-word
    editing, forwardmask flushing, and TRAPSIG IAC command generation. The default 'telsh' server
    was also updated to support linemode.

3.0.2
  * bugfix: :meth:`~telnetlib3.stream_writer.TelnetWriter.request_charset` raised :exc:`TypeError`,
    :ghissue:`128`.  Offer callbacks (no-arg, returning a list of items to propose) are now
    separated from send callbacks (which respond to received requests) via new
    :meth:`~telnetlib3.stream_writer.TelnetWriter.set_ext_offer_callback` method.

3.0.1
  * change: Unused client argument ``gmcp_log`` removed.
  * new: MCCP2 and MCCP3. Both client and server ends passively support if requested, and request
    support by --compression or deny support by --no-compression.
  * new: :meth:`~telnetlib3.client.TelnetClient.on_request_charset` and
    :meth:`~telnetlib3.client.TelnetClient.on_request_environ` offer callbacks
    on the client, symmetric with the existing server-side callbacks.

3.0.0
  * change: :attr:`~telnetlib3.client_base.BaseClient.connect_minwait` default
    now 0 (was 1.0 seconds in library API).
  * change: ``force_binary`` auto-enabled when CHARSET is negotiated
    (:rfc:`2066`) or ``LANG``/``CHARSET`` received via NEW_ENVIRON
    (:rfc:`1572`).  SyncTERM font detection also enables it unconditionally.
  * change: ``--connect-timeout`` default changed from no limit to 10 seconds.
  * change: ``--reverse-video`` CLI option from 2.4.0 was removed.
  * change: CGA, EGA, and Amiga palettes removed from ``--colormatch``;
    only ``vga`` is available at this time.  ``ice_colors`` are now True by default.
  * bugfix: ``read_some()`` in synchronous API (``TelnetConnection`` and
    ``ServerConnection``) blocked until EOF instead of returning available
    data.  Now returns as soon as any data is available.
  * new: ``TelnetSessionContext`` base class
    and ``writer.ctx`` attribute for
    per-connection session state.  Subclass to add application-specific
    attributes (e.g. MUD client state).
  * new: ``--ice-colors`` (default on) treats SGR 5 (blink) as bright
    background for proper 16-color BBS/ANSI art display.
  * new: ``--typescript FILE`` records session output to a file, similar to
    the Unix ``script(1)`` command.
  * new: shared ``TelnetProtocolBase`` mixin extracted from duplicated
    server and client protocol code.
  * new: ``_atomic_json_write()`` and ``_BytesSafeEncoder`` helpers in
    ``_paths`` module for fingerprinting subsystem.
  * enhancement: Microsoft Telnet (``telnet.exe``) compatibility refined — server
    now sends ``DO NEW_ENVIRON`` but excludes ``USER`` variable instead of
    skipping the option entirely, :ghissue:`24`.
  * enhancement: comprehensive pylint and mypy cleanup across the codebase.

2.6.1
  * bugfix: dependency of ``wcwidth`` version.

2.6.0
  * new: TLS support (TELNETS).  :func:`~telnetlib3.client.open_connection`
    accepts an *ssl* parameter (``True``, or an :class:`ssl.SSLContext`).
    :func:`~telnetlib3.server.create_server` accepts an *ssl* parameter
    (:class:`ssl.SSLContext`).  New CLI options: ``--ssl``, ``--ssl-cafile``,
    ``--ssl-no-verify`` for ``telnetlib3-client``; ``--ssl-certfile``,
    ``--ssl-keyfile``, and ``--tls-auto`` for ``telnetlib3-server``.
  * new: the default server shell now displays ``Ready (secure: TLSv1.3).``
    for TLS connections (the protocol version shown is negotiated dynamically).
  * bugfix: ``telnetlib3-client`` now sets terminal mode to the server's
    preference via ``WILL ECHO`` and ``WILL SGA`` negotiation.  Use
    ``--raw-mode`` to restore legacy raw mode for servers that don't negotiate.
  * bugfix: ``telnetlib3-client`` declines MUD protocol options (GMCP, MSDP,
    MSSP, MSP, MXP, ZMP, AARDWOLF, ATCP) by default.  Use ``--always-do`` or
    ``--always-will`` to opt in.
  * bugfix: log output "staircase text" in raw terminal mode.
  * bugfix: graceful EOF handling — connection close no longer prints a traceback.

2.5.0
  * change: ``telnetlib3-client`` now defaults to raw terminal mode (no line
    buffering, no local echo), which is correct for most servers.  Use
    ``--line-mode`` to restore line-buffered local-echo behavior.
  * change: ``telnetlib3-server --pty-exec`` now defaults to raw PTY mode.  Use
    ``--line-mode`` to restore cooked PTY mode with echo.
  * change: ``connect_minwait`` default reduced to 0 across
    :class:`~telnetlib3.client_base.BaseClient`,
    :func:`~telnetlib3.client.open_connection`, and ``telnetlib3-client``.
    Negotiation continues asynchronously.  Use ``--connect-minwait`` to restore a
    delay if needed, or use
    :meth:`~telnetlib3.stream_writer.TelnetWriter.wait_for` in server or client
    shells to await a specific negotiation state.
  * new: color, keyboard input translation, and ``--encoding`` support for
    ATASCII (ATARI ASCII) and PETSCII (Commodore ASCII).
  * new: SyncTERM/CTerm font selection sequence detection
    (``CSI Ps1 ; Ps2 SP D``).  Both ``telnetlib3-fingerprint`` and
    ``telnetlib3-client`` detect font switching and auto-switch encoding to the
    matching codec (e.g. font 36 = ATASCII, 32--35 = PETSCII, 0 = CP437).
    Explicit ``--encoding`` takes precedence.
  * new: :data:`~telnetlib3.accessories.TRACE` log level (5, below ``DEBUG``)
    with :func:`~telnetlib3.accessories.hexdump`-style output for all sent and
    received bytes.  Use ``--loglevel=trace``.
  * bugfix: :func:`~telnetlib3.guard_shells.robot_check` now uses a narrow
    character (space) instead of a wide Unicode character, allowing retro
    terminal emulators to pass.
  * bugfix: ATASCII codec now maps bytes 0x0D and 0x0A to CR and LF instead
    of graphics characters, fixing garbled output when connecting to Atari
    BBS systems.
  * bugfix: ATASCII codec normalizes CR and CRLF to the native ATASCII
    EOL (0x9B) during encoding, so the Return key works correctly.
  * bugfix: PETSCII bare CR (0x0D) is now normalized to CRLF in raw
    terminal mode and to LF in ``telnetlib3-fingerprint`` banners.
  * bugfix: ``telnetlib3-fingerprint`` re-encodes prompt responses for retro
    encodings so servers receive the correct EOL byte.
  * bugfix: ``telnetlib3-fingerprint`` no longer crashes with
    :exc:`LookupError` when the server negotiates an unknown charset.
    Banner formatting falls back to ``latin-1``.
  * bugfix: :meth:`~telnetlib3.client.TelnetClient.send_charset` normalizes
    non-standard encoding names (``iso-8859-02`` to ``iso-8859-2``,
    ``cp-1250`` to ``cp1250``, etc.).
  * enhancement: ``telnetlib3-fingerprint`` responds more like a terminal and
    to more y/n prompts about colors, encoding, etc. to collect more banners
    for the `bbs.modem.xyz <https://bbs.modem.xyz/>`_ project.
  * enhancement: ``telnetlib3-fingerprint`` banner formatting uses
    ``surrogateescape`` error handler, preserving raw high bytes (e.g. CP437
    art) as surrogates instead of replacing them with U+FFFD.

2.4.0
  * new: ``telnetlib3.color_filter`` module — translates 16-color ANSI SGR
    codes to 24-bit RGB from hardware palettes (EGA, CGA, VGA, xterm).
    Enabled by default.  New client CLI options: ``--colormatch``,
    ``--color-brightness``, ``--color-contrast``, ``--background-color``,
    ``--reverse-video``.
  * new: :func:`~telnetlib3.mud.zmp_decode`,
    :func:`~telnetlib3.mud.atcp_decode`, and
    :func:`~telnetlib3.mud.aardwolf_decode` decode functions for ZMP (option
    93), ATCP (option 200), and Aardwolf (option 102) MUD protocols.
  * new: :meth:`~telnetlib3.stream_writer.TelnetWriter.handle_zmp`,
    :meth:`~telnetlib3.stream_writer.TelnetWriter.handle_atcp`,
    :meth:`~telnetlib3.stream_writer.TelnetWriter.handle_aardwolf`,
    :meth:`~telnetlib3.stream_writer.TelnetWriter.handle_msp`, and
    :meth:`~telnetlib3.stream_writer.TelnetWriter.handle_mxp` callbacks for
    receiving MUD extended protocol subnegotiations, with accumulated data
    stored in ``zmp_data``, ``atcp_data``, and ``aardwolf_data`` attributes.
  * new: COM-PORT-OPTION (:rfc:`2217`) subnegotiation parsing with
    ``comport_data`` attribute and
    :meth:`~telnetlib3.stream_writer.TelnetWriter.request_comport_signature`.
  * enhancement: ``telnetlib3-fingerprint`` now always probes extended MUD
    options (MSP, MXP, ZMP, AARDWOLF, ATCP) during server scans and captures
    ZMP, ATCP, Aardwolf, MXP, and COM-PORT data in session output.
  * enhancement: ``telnetlib3-fingerprint`` smart prompt detection —
    auto-answers yes/no, color, UTF-8 menu, ``who``, and ``help`` prompts.
  * enhancement: ``--banner-max-bytes`` option for ``telnetlib3-fingerprint``;
    default raised from 1024 to 65536.
  * new: ATASCII (Atari 8-bit) codec — ``--encoding=atascii`` for connecting
    to Atari BBS systems.  Maps all 256 byte values to Unicode including
    graphics characters, card suits, and the inverse-video range (0x80--0xFF).
    ATASCII EOL (0x9B) maps to newline.  Aliases: ``atari8bit``, ``atari_8bit``.
  * enhancement: ``--encoding=atascii``, ``--encoding=petscii``, and
    ``--encoding=atarist`` now auto-enable ``--force-binary`` for both client
    and server, since these encodings use bytes 0x80--0xFF for standard glyphs.
  * bugfix: rare LINEMODE ACK loop with misbehaving servers that re-send
    unchanged MODE without ACK.
  * bugfix: unknown IAC commands no longer raise :exc:`ValueError`; treated as
    data.
  * bugfix: client no longer asserts on ``TTYPE IS`` from server.
  * bugfix: :meth:`~telnetlib3.stream_writer.TelnetWriter.request_forwardmask`
    only called on server side.
  * change: ``wcwidth`` is now a required dependency.

2.3.0
  * bugfix: repeat "socket.send() raised exception." exceptions.
  * bugfix: server incorrectly accepted ``DO TSPEED`` and ``DO SNDLOC``
    with ``WILL`` responses.  These are client-only options per :rfc:`1079`
    and :rfc:`779`; the server now correctly rejects them.
  * bugfix: ``LINEMODE DO FORWARDMASK`` subnegotiation no longer raises
    :exc:`NotImplementedError`; the mask is accepted (logged only).
  * bugfix: echo doubling in ``--pty-exec`` without ``--pty-raw`` (linemode).
  * bugfix: missing ``LICENSE.txt`` in sdist file.
  * bugfix: GMCP, MSDP, and MSSP decoding now uses ``--encoding`` when set,
    falling back to ``latin-1`` for non-UTF-8 bytes instead of lossy replacement.
  * bugfix: ``NEW_ENVIRON SEND`` with empty payload now correctly
    interpreted as "send all" per :rfc:`1572`.
  * new: :mod:`telnetlib3.mud` module with encode/decode functions for
    GMCP (option 201), MSDP (option 69), and MSSP (option 70) MUD telnet
    protocols.
  * new: :meth:`~telnetlib3.stream_writer.TelnetWriter.send_gmcp`,
    :meth:`~telnetlib3.stream_writer.TelnetWriter.send_msdp`, and
    :meth:`~telnetlib3.stream_writer.TelnetWriter.send_mssp` methods for
    sending MUD protocol data, with corresponding
    :meth:`~telnetlib3.stream_writer.TelnetWriter.handle_gmcp`,
    :meth:`~telnetlib3.stream_writer.TelnetWriter.handle_msdp`, and
    :meth:`~telnetlib3.stream_writer.TelnetWriter.handle_mssp` callbacks.
  * new: ``connect_timeout`` parameter for client and ``--connect-timeout``
    CLI argument, :ghissue:`30`.
  * new: ``telnetlib3-fingerprint-server`` CLI with extended ``NEW_ENVIRON``
    for fingerprinting of connected clients.
  * new: ``telnetlib3-fingerprint`` CLI for fingerprinting the given remote
    server, probing telnet option support and capturing banners.
  * enhancement: reversed ``WILL``/``DO`` for directional options (e.g. ``WILL
    NAWS`` from server, ``DO TTYPE`` from client) now gracefully refused with
    ``DONT``/``WONT`` instead of raising :exc:`ValueError`.
  * enhancement: ``NEW_ENVIRON SEND`` and response logging improved —
    ``SEND (all)`` / ``env send: (empty)`` instead of raw byte dumps.
  * enhancement: ``telnetlib3-fingerprint`` now probes MSDP and MSSP options
    and captures MSSP server status data in session output.
  * new: ``--always-will``, ``--always-do``, ``--scan-type``, ``--mssp-wait``,
    ``--banner-quiet-time``, ``--banner-max-wait`` options for
    ``telnetlib3-fingerprint``.

2.2.0
  * bugfix: workaround for Microsoft Telnet client crash on
    ``SB NEW_ENVIRON SEND``, :ghissue:`24`.  Server now defers ``DO
    NEW_ENVIRON`` until TTYPE cycling identifies the client, skipping it
    entirely for MS Telnet (ANSI/VT100).
  * bugfix: handling of LINEMODE FORWARDMASK command bytes.
  * bugfix: SLC fingerprinting byte handling.
  * bugfix: send IAC GA (Go-Ahead) after prompts when SGA is not negotiated.
    Fixes hanging for MUD clients like Mudlet.  PTY shell uses a 500ms idle
    timer.  Use ``--never-send-ga`` to suppress like old behavior.
  * performance: with smarter negotiation, default ``connect_maxwait``
    reduced from 4.0s to 1.5s.
  * performance: both client and server protocol ``data_received`` methods
    have approximately 50x throughput improvement in bulk data transfers.
  * new: :class:`~telnetlib3.server.Server` class returned by
    :func:`~telnetlib3.server.create_server` with
    :meth:`~telnetlib3.server.Server.wait_for_client` method and
    :attr:`~telnetlib3.server.Server.clients` property for tracking connected
    clients.
  * new: :meth:`~telnetlib3.stream_writer.TelnetWriter.wait_for` and
    :meth:`~telnetlib3.stream_writer.TelnetWriter.wait_for_condition` methods
    for waiting on telnet option negotiation state.
  * new: :mod:`telnetlib3.sync` module with blocking (non-asyncio) APIs:
    :class:`~telnetlib3.sync.TelnetConnection` for clients,
    :class:`~telnetlib3.sync.BlockingTelnetServer` for servers.
  * new: :mod:`~telnetlib3.server_pty_shell` module demonstrating
    ``telnetlib3-server --pty-exec`` CLI argument and related ``--pty-raw``
    server CLI option for raw PTY mode, used by most programs that handle their
    own terminal I/O.
  * new: :mod:`~telnetlib3.guard_shells` module with ``--robot-check`` and
    ``--pty-fork-limit`` CLI arguments for connection limiting and bot
    detection.
  * new: :mod:`~telnetlib3.fingerprinting` module for telnet client
    identification and capability probing.
  * new: ``--send-environ`` client CLI option to control which environment
    variables are sent via NEW_ENVIRON.  Default no longer includes HOME or
    SHELL.

2.0.8
  * bugfix: object has no attribute ``_extra``, :ghissue:`100`.

2.0.7
  * bugfix: respond WILL CHARSET with DO CHARSET.

2.0.6
  * bugfix: corrected CHARSET protocol client/server role behavior,
    :ghissue:`59`.
  * bugfix: allow ``--force-binary`` and ``--encoding`` to be combined to
    prevent long "encoding failed after 4.00s" delays in ``telnetlib3-server``
    with non-compliant clients, :ghissue:`74`.
  * bugfix: reduce ``telnetlib3-client`` connection delay; session begins as
    soon as TTYPE and either NEW_ENVIRON or CHARSET negotiation is completed.
  * bugfix: remove "'NoneType' object has no attribute 'is_closing'" message
    on some types of closed connections.
  * bugfix: further improve ``telnetlib3-client`` performance, capable of
    11.2 Mbit/s or more.
  * bugfix: more gracefully handle unsupported SB STATUS codes.
  * feature: ``telnetlib3-client`` now negotiates terminal resize events.

2.0.5
  * feature: legacy ``telnetlib.py`` from Python 3.11 now redistributed;
    note change to project ``LICENSE.txt`` file.
  * feature: add :meth:`~telnetlib3.stream_reader.TelnetReader.readuntil_pattern`,
    :ghissue:`92` by :ghuser:`agicy`.
  * feature: add :meth:`~telnetlib3.stream_writer.TelnetWriter.wait_closed`
    async method in response to :ghissue:`82`.
  * bugfix: README examples do not work, :ghissue:`81`.
  * bugfix: ``TypeError: buf expected bytes, got <class 'str'>`` on client
    timeout in :class:`~telnetlib3.server.TelnetServer`, :ghissue:`87`.
  * bugfix: performance issues with client protocol under heavy load;
    demonstrating server ``telnet://1984.ws`` now documented in README.
  * bugfix: annoying "socket.send() raised exception" repeating warning,
    :ghissue:`89`.
  * bugfix: legacy use of ``get_event_loop``, :ghissue:`85`.
  * document: about encoding and ``force_binary`` in response to :ghissue:`90`.
  * feature: add tests to source distribution, :ghissue:`37`.
  * test coverage increased by ~20%.

2.0.4
  * change: stop using setuptools library to get current software version.

2.0.3
  * bugfix: :exc:`NameError` when ``debug=True`` is used with
    :func:`asyncio.run`, :ghissue:`75`.

2.0.2
  * bugfix: :exc:`NameError`: name ``sleep`` is not defined in
    ``stream_writer.py``.

2.0.1
  * bugfix: "write after close" is disregarded, caused many errors logged in
    ``socket.send()``.
  * bugfix: in ``accessories.repr_mapping()`` about using
    :func:`shlex.quote` on non-str, ``TypeError: expected string or
    bytes-like object, got 'int'``.
  * bugfix: about ``fn_encoding`` using :func:`repr` on
    :class:`~telnetlib3.stream_reader.TelnetReaderUnicode`.
  * bugfix: ``TelnetReader.is_closing()`` raises :exc:`AttributeError`.
  * deprecation: :meth:`~telnetlib3.stream_reader.TelnetReader.close` and
    :meth:`~telnetlib3.stream_reader.TelnetReader.connection_closed` emit
    warning; use :meth:`~telnetlib3.stream_reader.TelnetReader.at_eof` and
    :meth:`~telnetlib3.stream_reader.TelnetReader.feed_eof` instead.
  * deprecation: the ``loop`` argument is no longer accepted by
    :class:`~telnetlib3.stream_reader.TelnetReader`.
  * enhancement: add Generic MUD Communication Protocol support, :ghissue:`63`
    by :ghuser:`gtaylor`.
  * change: :class:`~telnetlib3.stream_reader.TelnetReader` and
    :class:`~telnetlib3.stream_writer.TelnetWriter` no longer derive
    from :class:`asyncio.StreamReader` and :class:`asyncio.StreamWriter`;
    this fixes some :exc:`TypeError` in signatures and runtime.

2.0.0
  * change: support Python 3.9, 3.10, 3.11.  Drop Python 3.6 and earlier.
    All code and examples have been updated to the new-style PEP-492 syntax.
  * change: the ``loop``, ``event_loop``, and ``log`` arguments are no longer
    accepted by any class initializers.
  * note: this release has a known memory leak when using the
    ``_waiter_connected`` and ``_waiter_closed`` arguments to Client or Shell
    class initializers; please do not use them.  A replacement
    ``wait_for_negotiation`` awaitable is planned for a future release.
  * enhancement: add COM-PORT-OPTION subnegotiation support, :ghissue:`57` by
    :ghuser:`albireox`.

1.0.4
  * bugfix: :exc:`TypeError` on EOF/Timeout, introduced in previous
    version 1.0.3, :ghissue:`51` by :ghuser:`zofy`.

1.0.3
  * bugfix: circular reference between transport and protocol, :ghissue:`43` by
    :ghuser:`fried`.

1.0.2
  * add ``--speed`` argument to telnet client, :ghissue:`35` by
    :ghuser:`hughpyle`.

1.0.1
  * add Python 3.7 support, drop Python 3.4 and earlier, :ghissue:`33` by
    :ghuser:`AndrewNelis`.

1.0.0
  * First general release for standard API: instead of encouraging Twisted-like
    override of protocol methods, we provide a "shell" callback interface,
    receiving argument pairs (reader, writer).

0.5.0
  * bugfix: linemode MODE is now acknowledged.
  * bugfix: default stream handler sends 80 x 24 in cols x rows, not 24 x 80.
  * bugfix: ``waiter_closed`` future on client defaulted to wrong type.
  * bugfix: telnet shell (TelSh) no longer paints over final exception line.

0.4.0
  * bugfix: cannot connect to IPv6 address as client.
  * change: ``TelnetClient.CONNECT_DEFERED`` class attribute renamed
    ``DEFERRED``.  Default value changed to 50ms from 100ms.
  * change: ``TelnetClient.waiter`` renamed to ``TelnetClient.waiter_closed``.
  * enhancement: ``TelnetClient.waiter_connected`` future added.

0.3.0
  * bugfix: cannot bind to IPv6 address, :ghissue:`5`.
  * enhancement: futures ``waiter_connected`` and ``waiter_closed`` added to
    server.
  * change: ``TelSh.feed_slc`` merged into ``TelSh.feed_byte`` as
    ``slc_function`` keyword.
  * change: ``TelnetServer.CONNECT_DEFERED`` class attribute renamed
    ``DEFERRED``.  Default value changed to 50ms from 100ms.
  * enhancement: default ``TelnetServer.PROMPT_IMMEDIATELY = False`` ensures
    prompt is not displayed until negotiation is considered final.  It is no
    longer "aggressive".
  * enhancement: ``TelnetServer.pause_writing`` and ``resume_writing`` callback
    wired.
  * enhancement: ``TelSh.pause_writing`` and ``resume_writing`` methods added.

0.2.4
  * bugfix: pip installation issue, :ghissue:`8`.

0.2
  * enhancement: various example programs were included in this release.

0.1
  * Initial release.
