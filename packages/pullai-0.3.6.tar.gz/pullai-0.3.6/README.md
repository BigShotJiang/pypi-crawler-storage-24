# PullAI Python SDK

```bash
pip install pullai
```

Requires the server running: `pullai serve`

---

## Quick start

```python
from pullai import PullAI

ai = PullAI()

# List installed models
ai.models()

# Single message (streaming)
ai.chat("llm/mistral:7b", "What is Python?")

# Multi-turn conversation (model remembers everything)
conv = ai.conversation("llm/mistral:7b")
conv.say("My name is Marco and I love Python.")
conv.say("What is my name?")        # → "Your name is Marco."
conv.say("What language do I love?") # → "You love Python."
conv.clear()                         # wipe memory, start fresh

# Generate an image
ai.image("image/sdxl", "an astronaut cat on Mars", "cat.png")

# Transcribe audio
ai.transcribe("audio/whisper:large", "meeting.mp3")

# Text to speech
ai.speak("audio/kokoro", "Hello!", "hello.wav")

# Generate a video
ai.video("video/cogvideo:5b", "a panda running", "panda.mp4")

# Generate a 3D model from text
ai.model3d("3d/shap-e", "chair.ply", description="a wooden chair")

# Generate a 3D model from image
ai.model3d("3d/triposr", "chair.obj", image="photo.jpg")
```

---

## License

Apache-2.0 © Metiu — PullAI Contributors
