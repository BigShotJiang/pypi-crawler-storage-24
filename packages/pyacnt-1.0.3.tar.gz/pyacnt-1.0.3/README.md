# Pyacnt

Pyacnt is a Python extension that allows you to manage profiles: easily create, connect, delete, add data, read data and greet users.

## Installation

```bash
pip install pyacnt
```

## Usage

```python
import pyacnt

# Create an account
pyacnt.enter("Alice", "password123")

# Log in
pyacnt.connect("Alice", "password123")

# Welcome message
pyacnt.welcome("Alice")

# Add data
pyacnt.set_data("Alice", "age", 20)

#Delete data
pyacnt.delete_data("Alice", "age")

#Change data
pyacnt.change_data("Alice", "age", "21")

# Read data
pyacnt.get_data("Alice", "age")

# Disconnect
pyacnt.exit("Alice")
```

## Commands

| Command | Description |
|---|---|
| `enter(name, password)` | Create an account |
| `connect(name, password)` | Log in |
| `exit(name)` | Disconnect |
| `welcome(name)` | Display welcome message |
| `set_data(name, key, value)` | Add data to account |
| `get_data(name, key)` | Read data from account |
| `delete_data(name, key)` | Delete data from account |
| `change_data(name, key, value)` | Change data from account |

> 💡 Passwords are secured using **SHA-256** hashing.

## License

MIT
