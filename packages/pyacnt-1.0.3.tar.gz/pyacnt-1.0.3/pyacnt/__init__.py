import json
import hashlib
import os

_databank_path = os.path.join(os.getcwd(), "databank.json")

def _load():
    if not os.path.exists(_databank_path):
        with open(_databank_path, "w") as f:
            json.dump({"users": {}}, f)
    with open(_databank_path, "r") as f:
        return json.load(f)

def _save(data):
    with open(_databank_path, "w") as f:
        json.dump(data, f)

def hash_pwd(pwd):
    return hashlib.sha256(pwd.encode()).hexdigest()

conctdprsn = []

def enter(name, password):
    data = _load()
    if name in data["users"]:
        print("User already exists.")
    else:
        data["users"][name] = {"password": hash_pwd(password), "data": {}}
        _save(data)
        print("User created successfully.")

def connect(name, pwd):
    data = _load()
    if name not in data["users"]:
        print("User not found")
    elif hash_pwd(pwd) != data["users"][name]["password"]:
        print("Wrong password")
    elif name in conctdprsn:
        print("Already connected")
    else:
        conctdprsn.append(name)
        print("Connected!")

def exit(name):
    if name in conctdprsn:
        conctdprsn.remove(name)
        print(f"{name} disconnected!")
    else:
        print("Can't disconnect, user not connected.")

def set_data(name, key, value):
    data = _load()
    if name not in data["users"]:
        print("User not found")
        return
    if name in conctdprsn:
        data["users"][name]["data"][key] = value
        _save(data)
        print(f"Data '{key}' added to user {name} successfully.")
    else:
        print("Can't add data, user is not connected")

def get_data(name, key):
    data = _load()
    if name not in data["users"]:
        print("User not found")
        return
    if name in conctdprsn:
        return data["users"][name]["data"].get(key, None)
    else:
        print("Can't read data, user is not connected")

def change_data(name, key, value):
    data = _load()
    if name not in data["users"]:
        print("User not found")
        return
    if name in conctdprsn:
        if key in data["users"][name]["data"]:
            data["users"][name]["data"][key] = value
            _save(data)
            print(f"Data '{key}' changed to user {name} successfully.")
        else:
            print("Can't change data, key doesn't exist")
    else:
        print("Can't change data, user is not connected")

def delete_data(name, key):
    data = _load()
    if name not in data["users"]:
        print("User not found")
        return
    if name in conctdprsn:
        if key in data["users"][name]["data"]:
            del data["users"][name]["data"][key]
        else:
            print("Can't delete data, key doesn't exist")
    else:
        print("Can't delete data, user is not connected")

def welcome(name):
    if name in conctdprsn:
        print(f"Welcome {name}!")
    else:
        print("Sorry, you're not connected to this account.")
