"""MCP CLI subcommands — workpilot mcp list|add|add-json|remove|get|add-agency."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import typer
import yaml
from rich.table import Table

from workpilot.cli.commands import (
    _load_config_safe,
    console,
    mcp_app,
)


def _resolve_config_path(config: str) -> Path:
    """Resolve workpilot.yaml path from config arg (file or directory)."""
    config_path = Path(config)
    if config_path.is_dir():
        for candidate in ("workpilot.yaml", "workpilot.yml"):
            p = config_path / candidate
            if p.exists():
                return p
        console.print("[red]No workpilot.yaml found.[/red]")
        raise typer.Exit(1)
    if not config_path.is_file():
        console.print(f"[red]Config file not found:[/red] {config_path}")
        raise typer.Exit(1)
    return config_path


def _resolve_local_config_path(config_path: Path) -> Path:
    """Derive the .local.yaml sibling path."""
    return config_path.parent / f"{config_path.stem}.local{config_path.suffix}"


def _load_yaml(config_path: Path) -> dict[str, Any]:
    return yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}


def _save_mcp_servers(config_path: Path, servers: dict[str, dict[str, Any]]) -> None:
    """Update only the tools.mcp_servers section in workpilot.yaml.

    Preserves the rest of the file as-is by doing targeted text replacement.
    """

    content = config_path.read_text(encoding="utf-8") if config_path.is_file() else ""

    # Build the new mcp_servers YAML block
    lines: list[str] = []
    for name, srv in servers.items():
        lines.append(f"    {name}:")
        for key, val in srv.items():
            if isinstance(val, list):
                # Flow style for short lists: args: ["mcp", "icm"]
                items = ", ".join(f'"{v}"' if isinstance(v, str) else str(v) for v in val)
                lines.append(f"      {key}: [{items}]")
            elif isinstance(val, dict):
                lines.append(f"      {key}:")
                for dk, dv in val.items():
                    lines.append(f"        {dk}: {_yaml_scalar(dv)}")
            else:
                lines.append(f"      {key}: {_yaml_scalar(val)}")
    new_block = "\n".join(lines)

    # Try to find and replace existing tools.mcp_servers section
    # Pattern: "tools:\n  mcp_servers:\n" followed by indented content until next top-level key
    pattern = r"(tools:\s*\n\s*mcp_servers:\s*\n)((?:\s{4,}\S.*\n)*)"
    if re.search(pattern, content):
        replacement = f"tools:\n  mcp_servers:\n{new_block}\n"
        content = re.sub(pattern, replacement, content)
    else:
        # No existing section — insert before channels: or append
        insert_before = re.search(r"^(channels:|cron:|logging:)", content, re.MULTILINE)
        block = f"\ntools:\n  mcp_servers:\n{new_block}\n\n"
        if insert_before:
            pos = insert_before.start()
            content = content[:pos] + block + content[pos:]
        else:
            content = content.rstrip() + "\n" + block

    config_path.write_text(content, encoding="utf-8")


def _yaml_scalar(val: Any) -> str:
    """Format a scalar value for inline YAML."""
    if isinstance(val, bool):
        return "true" if val else "false"
    if isinstance(val, (int, float)):
        return str(val)
    if isinstance(val, str):
        if any(c in val for c in ":#{}[]|>&*!%@`"):
            return f'"{val}"'
        return f'"{val}"'
    return str(val)


@mcp_app.command("list")
def mcp_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """List configured MCP servers."""
    cfg = _load_config_safe(config)

    servers = cfg.tools.mcp_servers
    if not servers:
        console.print("[dim]No MCP servers configured.[/dim]")
        return

    table = Table(title="MCP Servers")
    table.add_column("Name", style="bold")
    table.add_column("Description")
    table.add_column("Status")

    for name, srv in servers.items():
        desc = srv.description or ""
        if not srv.enabled:
            status = "[dim]disabled[/dim]"
        elif srv.is_agency:
            status = "[green]agency[/green]"
        elif srv.url:
            status = "http"
        else:
            status = "stdio"

        name_display = f"[dim]{name}[/dim]" if not srv.enabled else name
        table.add_row(name_display, desc, status)

    console.print(table)


@mcp_app.command("add")
def mcp_add(
    name: str = typer.Argument(..., help="MCP server name"),
    command: list[str] | None = typer.Argument(None, help="Server command and args (after --)"),
    transport: str = typer.Option(
        "stdio", "--transport", "-t", help="Transport: stdio (default) or http"
    ),
    url: str | None = typer.Option(
        None, "--url", help="HTTP endpoint URL (alternative to command)"
    ),
    env: list[str] | None = typer.Option(
        None, "-e", "--env", help="Environment variable KEY=VALUE (repeatable)"
    ),
    timeout: int | None = typer.Option(None, "--timeout", help="Tool call timeout in seconds"),
    risk_level: str | None = typer.Option(
        None, "--risk-level", help="Risk level: low, medium, high"
    ),
    namespace: str | None = typer.Option(None, "--namespace", help="Override namespace prefix"),
    header: list[str] | None = typer.Option(
        None, "--header", help="HTTP header 'Key: Value' (repeatable)"
    ),
    force: bool = typer.Option(False, "--force", help="Overwrite existing server config"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add an MCP server to the configuration.

    Stdio: workpilot mcp add <name> -- <command> [args...]
    HTTP:  workpilot mcp add --transport http <name> --url <url>
    """
    config_path = _resolve_config_path(config)
    raw = _load_yaml(config_path)
    tools_section = raw.setdefault("tools", {})
    mcp_section = tools_section.setdefault("mcp_servers", {})

    if name in mcp_section and not force:
        console.print(
            f"[yellow]MCP server '{name}' already exists. Use --force to overwrite.[/yellow]"
        )
        raise typer.Exit(1)

    entry: dict[str, Any] = {}

    if transport == "http" or url:
        # HTTP transport
        if not url and command:
            url = command[0]  # first positional arg as URL
        if not url:
            console.print("[red]HTTP transport requires --url or a URL argument.[/red]")
            raise typer.Exit(1)
        entry["url"] = url
        # Headers → auth config
        if header:
            for h in header:
                if ":" in h:
                    key, val = h.split(":", 1)
                    key, val = key.strip(), val.strip()
                    if key.lower() == "authorization" and val.lower().startswith("bearer "):
                        entry.setdefault("auth", {})["type"] = "bearer"
                        entry["auth"]["token"] = val[7:]  # strip "Bearer "
        # Env for HTTP (rare but supported)
        if env:
            env_dict: dict[str, str] = {}
            for e in env:
                if "=" in e:
                    k, v = e.split("=", 1)
                    env_dict[k] = v
            if env_dict:
                entry["env"] = env_dict
    else:
        # Stdio transport
        if not command:
            console.print(
                "[red]Stdio transport requires a command. Usage: workpilot mcp add <name> -- <command> [args...][/red]"
            )
            raise typer.Exit(1)
        entry["command"] = command[0]
        if len(command) > 1:
            entry["args"] = list(command[1:])
        # Env vars
        if env:
            env_dict = {}
            for e in env:
                if "=" in e:
                    k, v = e.split("=", 1)
                    env_dict[k] = v
            if env_dict:
                entry["env"] = env_dict

    # Optional per-server overrides
    if timeout is not None:
        entry["timeout"] = timeout
    if risk_level:
        entry["risk_level"] = risk_level
    if namespace:
        entry["namespace"] = namespace

    mcp_section[name] = entry
    _save_mcp_servers(config_path, mcp_section)
    console.print(f"[green]MCP server '{name}' added to {config_path}[/green]")


@mcp_app.command("add-json")
def mcp_add_json(
    name: str = typer.Argument(..., help="MCP server name"),
    json_config: str = typer.Argument(..., help="JSON configuration string"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing server config"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add an MCP server from a JSON configuration string.

    Example: workpilot mcp add-json icm '{"command":"agency","args":["mcp","icm"],"timeout":60}'
    """

    config_path = _resolve_config_path(config)
    raw = _load_yaml(config_path)
    tools_section = raw.setdefault("tools", {})
    mcp_section = tools_section.setdefault("mcp_servers", {})

    if name in mcp_section and not force:
        console.print(
            f"[yellow]MCP server '{name}' already exists. Use --force to overwrite.[/yellow]"
        )
        raise typer.Exit(1)

    try:
        entry = json.loads(json_config)
    except json.JSONDecodeError as exc:
        console.print(f"[red]Invalid JSON: {exc}[/red]")
        raise typer.Exit(1)

    if not isinstance(entry, dict):
        console.print("[red]JSON must be an object.[/red]")
        raise typer.Exit(1)

    mcp_section[name] = entry
    _save_mcp_servers(config_path, mcp_section)
    console.print(f"[green]MCP server '{name}' added to {config_path}[/green]")


@mcp_app.command("remove")
def mcp_remove(
    name: str = typer.Argument(..., help="MCP server name to remove"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Remove an MCP server from the configuration."""
    config_path = _resolve_config_path(config)
    raw = _load_yaml(config_path)
    mcp_servers = raw.get("tools", {}).get("mcp_servers", {})

    if name not in mcp_servers:
        console.print(f"[yellow]MCP server '{name}' not found in config.[/yellow]")
        raise typer.Exit(1)

    del mcp_servers[name]
    _save_mcp_servers(config_path, mcp_servers)
    console.print(f"[green]MCP server '{name}' removed from {config_path}[/green]")


@mcp_app.command("get")
def mcp_get(
    name: str = typer.Argument(..., help="MCP server name"),
    raw_output: bool = typer.Option(False, "--raw", help="Output as JSON"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show detailed configuration for a specific MCP server."""

    cfg = _load_config_safe(config)
    srv = cfg.tools.mcp_servers.get(name)

    if srv is None:
        console.print(f"[yellow]MCP server '{name}' not found in config.[/yellow]")
        raise typer.Exit(1)

    if raw_output:
        console.print(json.dumps(srv.model_dump(exclude_none=True), indent=2))
        return

    # Formatted output
    if srv.command:
        transport = "stdio"
        target = f"{srv.command} {' '.join(srv.args)}"
    elif srv.url:
        transport = "http"
        target = srv.url
    else:
        transport = "unknown"
        target = ""

    console.print(f"[bold]Server:[/bold] {name}")
    if srv.description:
        console.print(f"[bold]Description:[/bold] {srv.description}")
    console.print(f"[bold]Enabled:[/bold] {'yes' if srv.enabled else '[red]no[/red]'}")
    console.print(f"[bold]Transport:[/bold] {transport}")
    console.print(f"[bold]{'Command' if srv.command else 'URL'}:[/bold] {target}")

    if srv.is_agency:
        console.print("[bold]Agency:[/bold] yes (auto-detected)")

    if srv.timeout is not None:
        console.print(f"[bold]Timeout:[/bold] {srv.timeout}s")
    else:
        default = "120s" if srv.is_agency else "60s"
        console.print(f"[bold]Timeout:[/bold] {default} (default)")

    if srv.risk_level:
        console.print(f"[bold]Risk level:[/bold] {srv.risk_level}")
    else:
        console.print("[bold]Risk level:[/bold] medium (default)")

    if srv.approval:
        console.print(f"[bold]Approval:[/bold] {srv.approval}")
    else:
        console.print("[bold]Approval:[/bold] auto (profile default)")

    if srv.namespace:
        console.print(f"[bold]Namespace:[/bold] {srv.namespace}")
    else:
        console.print(f"[bold]Namespace:[/bold] {name}")

    if srv.env:
        env_str = ", ".join(f"{k}=..." for k in srv.env)
        console.print(f"[bold]Env:[/bold] {env_str}")

    if srv.command:
        console.print("[bold]Auth:[/bold] none (stdio — handled internally)")
    else:
        console.print(f"[bold]Auth:[/bold] {srv.auth.type}")


def _refresh_path() -> None:
    """Refresh PATH so a just-installed binary can be found."""

    if sys.platform == "win32":
        try:
            r = subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    '[System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + '
                    '[System.Environment]::GetEnvironmentVariable("Path","User")',
                ],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if r.returncode == 0 and r.stdout.strip():
                os.environ["PATH"] = r.stdout.strip()
        except Exception:
            pass
    else:
        # Append common install directories if not already in PATH
        for d in ("~/.local/bin", "~/bin", "/usr/local/bin"):
            expanded = os.path.expanduser(d)
            if os.path.isdir(expanded) and expanded not in os.environ.get("PATH", ""):
                os.environ["PATH"] = expanded + os.pathsep + os.environ.get("PATH", "")


def _ensure_agency_installed() -> str:
    """Check for Agency CLI binary; auto-install if missing. Returns binary path."""

    agency_bin = shutil.which("agency")
    if agency_bin:
        return agency_bin

    console.print("[yellow]Agency CLI not found in PATH.[/yellow]")
    console.print("Attempting auto-install...")

    if sys.platform == "win32":
        cmd = [
            "powershell",
            "-NoProfile",
            "-Command",
            'iex "& { $(irm https://aka.ms/InstallTool.ps1)} agency"',
        ]
        manual = 'iex "& { $(irm https://aka.ms/InstallTool.ps1)} agency"'
    else:
        dl = "curl -sSfL" if shutil.which("curl") else "wget -qO-"
        if not shutil.which(dl.split()[0]):
            console.print("[red]Neither curl nor wget found.[/red]")
            raise typer.Exit(1)
        cmd = ["sh", "-c", f"{dl} https://aka.ms/InstallTool.sh | sh -s agency"]
        manual = f"{dl} https://aka.ms/InstallTool.sh | sh -s agency"

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired:
        console.print(f"[red]Install timed out.[/red] Manual install:\n  {manual}")
        raise typer.Exit(1)

    if result.returncode != 0:
        if result.stderr.strip():
            console.print(f"[dim]{result.stderr.strip()[:500]}[/dim]")
        console.print(f"[red]Install failed.[/red] Manual install:\n  {manual}")
        raise typer.Exit(1)

    _refresh_path()

    agency_bin = shutil.which("agency")
    if not agency_bin:
        console.print(
            "[red]Agency installed but not found in PATH.[/red]\n"
            "Please restart your terminal and retry."
        )
        raise typer.Exit(1)

    console.print(f"[green]Agency installed: {agency_bin}[/green]")
    return agency_bin


def _discover_agency_servers(agency_bin: str) -> list[tuple[str, str]]:
    """Run `agency mcp --help` and parse available servers.

    Returns list of (name, description) tuples.
    """

    try:
        result = subprocess.run(
            [agency_bin, "mcp", "--help"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        help_text = result.stdout + result.stderr
    except Exception as exc:
        console.print(f"[red]Failed to run 'agency mcp --help': {exc}[/red]")
        raise typer.Exit(1)

    skip = {"help", "remote", "local", "npx", "calculator", "stack", "msft-learn"}
    discovered: list[tuple[str, str]] = []
    in_commands = False
    for line in help_text.splitlines():
        stripped = line.strip()
        if stripped.startswith("Commands:"):
            in_commands = True
            continue
        if stripped.startswith("Options:"):
            in_commands = False
            continue
        if in_commands and stripped:
            parts = stripped.split(None, 1)
            if parts and parts[0] not in skip:
                name = parts[0]
                desc = parts[1].strip() if len(parts) > 1 else ""
                # Clean up common prefixes from descriptions
                for prefix in ("Launch ", "Launch a "):
                    if desc.startswith(prefix):
                        desc = desc[len(prefix) :]
                        break
                # Use curated description if available, else cleaned help text
                desc = _AGENCY_DESCRIPTIONS.get(name, desc)
                discovered.append((name, desc))

    return discovered


# Servers that need extra CLI arguments
_AGENCY_SERVER_PARAMS: dict[str, dict[str, str]] = {
    "ado": {"--organization": "ADO org URL"},
    "bluebird": {
        "--org": "ADO org URL",
        "--project": "ADO project name",
        "--repository": "ADO repository name",
    },
    "kusto": {"--service-uri": "Kusto cluster URL"},
}

# Default values for server params
_AGENCY_PARAM_DEFAULTS: dict[str, dict[str, str]] = {
    "ado": {"--organization": "https://microsoft.visualstudio.com"},
    "bluebird": {"--org": "https://microsoft.visualstudio.com"},
    "kusto": {"--service-uri": "https://kusto.aria.microsoft.com"},
}


# Servers not pre-selected in interactive mode (niche, most users don't need)
_AGENCY_NOT_RECOMMENDED = frozenset({"cloudbuild"})

# Servers that use npx/uvx (need package download — longer timeout)
_AGENCY_PACKAGE_SERVERS = frozenset({"ado", "kusto", "workiq"})


def _detect_ado_org() -> str | None:
    """Try to detect ADO org from current git remote."""

    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        url = result.stdout.strip()
        # https://dev.azure.com/org/project or https://org.visualstudio.com/project
        if "dev.azure.com" in url:
            parts = url.split("dev.azure.com/")
            if len(parts) > 1:
                org = parts[1].split("/")[0]
                return f"https://dev.azure.com/{org}"
        elif "visualstudio.com" in url:
            host = url.split("//")[1].split("/")[0] if "//" in url else ""
            if host:
                return f"https://{host}"
    except Exception:
        pass
    return None


def _resolve_server_args(name: str) -> list[str]:
    """Prompt user for required server args, using defaults where available."""
    params = _AGENCY_SERVER_PARAMS.get(name, {})
    defaults = _AGENCY_PARAM_DEFAULTS.get(name, {})
    args: list[str] = []

    # Special handling for ADO: auto-detect org from git remote
    if name in ("ado", "bluebird"):
        detected_org = _detect_ado_org()
        if detected_org:
            console.print(f"    [dim]Detected ADO org: {detected_org}[/dim]")
            if name == "ado":
                defaults = {**defaults, "--organization": detected_org}
            else:
                defaults = {**defaults, "--org": detected_org}

    for flag, desc in params.items():
        default = defaults.get(flag, "")
        prompt = f"    {flag} ({desc})"
        if default:
            prompt += f" [{default}]"
        prompt += ": "
        val = console.input(prompt).strip() or default
        if val:
            args.extend([flag, val])
        else:
            return []  # user skipped

    return args


def _test_agency_server(
    agency_bin: str, name: str, extra_args: list[str] | None = None
) -> tuple[bool, str]:
    """Test an Agency MCP server using the same MCPClient used at runtime.

    Timeout: 90s for HTTP proxy servers, 180s for npx/uvx servers.
    """
    import asyncio as _asyncio

    timeout = 180 if name in _AGENCY_PACKAGE_SERVERS else 90
    cmd = agency_bin
    args = ["mcp", name] + (extra_args or [])

    async def _test() -> tuple[bool, str]:
        from loguru import logger as _logger

        from workpilot.mcp.client import MCPClient

        _logger.disable("workpilot.mcp.transport")
        _logger.disable("workpilot.mcp.client")
        try:
            client = MCPClient(command=cmd, args=args, name=name)
            try:
                await _asyncio.wait_for(client.connect(), timeout=timeout)
                tools = await _asyncio.wait_for(client.list_tools(), timeout=30)
                await client.disconnect()
                return True, f"{len(tools)} tools"
            except TimeoutError:
                await client.disconnect()
                return False, f"timeout ({timeout}s) — try: agency mcp {name}"
            except Exception as exc:
                try:
                    await client.disconnect()
                except Exception:
                    pass
                msg = str(exc)
                if "required arguments" in msg.lower():
                    return False, msg.split("\n")[-1].strip()[:80]
                return False, msg[:80]
        finally:
            _logger.enable("workpilot.mcp.transport")
            _logger.enable("workpilot.mcp.client")

    # Run async test in a thread, print dots every 30s from main thread
    import threading

    result_holder: list[tuple[bool, str]] = []

    def _run():
        try:
            result_holder.append(_asyncio.run(_test()))
        except Exception as exc:
            result_holder.append((False, str(exc)[:80]))

    t = threading.Thread(target=_run, daemon=True)
    t.start()

    # Print progress dots while waiting
    while t.is_alive():
        t.join(timeout=15)
        if t.is_alive():
            sys.stdout.write(".")
            sys.stdout.flush()

    return result_holder[0] if result_holder else (False, "no result")


# Curated descriptions for Agency MCP servers (overrides help output)
_AGENCY_DESCRIPTIONS: dict[str, str] = {
    "ado": "work items, repos, pipelines, PRs",
    "enghub": "docs, TSGs, ServiceTree search",
    "kusto": "run KQL queries on Azure Data Explorer",
    "bluebird": "Engineering Copilot, semantic code search in ADO repos",
    "icm": "incident management, query/create/update incidents",
    "security-context": "Azure security posture and threat intelligence",
    "es-chat": "engineering knowledge Q&A across eng.ms, ADO Wiki, OneDoc",
    "workiq": "query Microsoft 365 Copilot data, emails, docs, meetings",
    "teams": "send messages, search chats, manage channels",
    "mail": "read, send, search Outlook emails",
    "calendar": "view, create, manage Outlook calendar events",
    "s360-breeze": "service health, compliance, and operational insights",
    "cloudbuild": "cloud build status, logs, and pipelines",
}

# Risk levels: low = read-only/search, medium = create/modify or send via user's account
_AGENCY_RISK_LEVELS: dict[str, str] = {
    "enghub": "low",
    "es-chat": "low",
    "security-context": "low",
    "s360-breeze": "low",
    "bluebird": "low",
    "cloudbuild": "low",
    "icm": "medium",
    "ado": "medium",
    "kusto": "medium",
    "workiq": "low",
    "calendar": "medium",
    "teams": "medium",
    "mail": "medium",
}


def _run_add_agency(
    config_path: Path,
    *,
    select_all: bool = False,
    dry_run: bool = False,
    skip_test: bool = False,
) -> dict[str, dict[str, Any]] | None:
    """Core add-agency logic shared by ``init`` and ``mcp add-agency``."""

    # 1. Ensure Agency CLI + discover servers
    agency_bin = _ensure_agency_installed()
    console.print(f"Using agency: {agency_bin}")

    discovered = _discover_agency_servers(agency_bin)
    if not discovered:
        console.print("[yellow]No MCP servers found.[/yellow]")
        return None

    # 2. Filter already-configured (merged base + local)
    try:
        existing = set(_load_config_safe(str(config_path.parent)).tools.mcp_servers.keys())
    except SystemExit:
        existing = set()

    local_path = _resolve_local_config_path(config_path)
    local_raw = (_load_yaml(local_path) if local_path.is_file() else {}) or {}
    tools_val = local_raw.get("tools")
    tools_sec: dict[str, Any] = tools_val if isinstance(tools_val, dict) else {}
    local_raw["tools"] = tools_sec
    mcp_val = tools_sec.get("mcp_servers")
    mcp_sec: dict[str, Any] = mcp_val if isinstance(mcp_val, dict) else {}
    tools_sec["mcp_servers"] = mcp_sec

    known = existing | set(mcp_sec.keys())
    available = [(n, d) for n, d in discovered if n not in known]

    if not available:
        console.print(f"All {len(known)} discovered servers already configured.")
        return None
    if known:
        console.print(
            f"[dim]Already configured: {', '.join(n for n, _ in discovered if n in known)}[/dim]"
        )

    # 3. Select servers
    if select_all:
        selected = [n for n, _ in available]
    else:
        selected = _interactive_select(available)

    if not selected:
        console.print("No servers selected.")
        return None
    if dry_run:
        console.print(f"\n[dim]--dry-run: would add {len(selected)}: {', '.join(selected)}[/dim]")
        return None

    # 4. Install each server
    total = len(selected)
    if skip_test:
        console.print(f"\nAdding {total} servers [dim](skipping auth test)...[/dim]\n")
    else:
        console.print(f"\nInstalling {total} servers [dim](verifying auth)...[/dim]\n")

    added: dict[str, dict[str, Any]] = {}
    auth_pending: list[str] = []

    for idx, name in enumerate(selected, 1):
        sys.stdout.write(f"  [{idx}/{total}] {name:20s} ")
        sys.stdout.flush()

        # Resolve extra args
        extra_args = _resolve_extra_args(name, select_all)
        if extra_args is None:
            print("skipped")
            continue

        # Test auth
        if skip_test:
            print("added")
        else:
            timeout = 180 if name in _AGENCY_PACKAGE_SERVERS else 90
            sys.stdout.write(f"testing (up to {timeout}s) ")
            sys.stdout.flush()
            ok, info = _test_agency_server(agency_bin, name, extra_args or None)
            if ok:
                print(f" OK  {info}")
            else:
                print(" added (auth pending)")
                auth_pending.append(name)

        # Write entry
        entry: dict[str, Any] = {"command": "agency", "args": ["mcp", name] + extra_args}
        desc = _AGENCY_DESCRIPTIONS.get(name)
        if desc:
            entry["description"] = desc
        risk = _AGENCY_RISK_LEVELS.get(name)
        if risk:
            entry["risk_level"] = risk
        added[name] = entry
        mcp_sec[name] = entry
        _save_mcp_servers(local_path, mcp_sec)

    # Summary
    if added:
        console.print(f"\n[green]Added {len(added)} MCP servers to {local_path}.[/green]")
    if auth_pending:
        console.print("[yellow]Auth pending — run to complete login:[/yellow]")
        for n in auth_pending:
            console.print(f"  agency mcp {n}")

    return added or None


def _interactive_select(available: list[tuple[str, str]]) -> list[str]:
    """Show interactive checkbox for server selection."""
    console.print(f"\nAvailable Agency MCP servers ({len(available)}):")
    console.print(
        "[dim]Enter numbers to toggle, 'a' for all, 'n' for none, Enter to confirm.[/dim]\n"
    )

    items = [(n, d) for n, d in available]
    selected: set[str] = {
        n for n, _ in items if n not in _AGENCY_SERVER_PARAMS and n not in _AGENCY_NOT_RECOMMENDED
    }

    while True:
        for i, (n, d) in enumerate(items, 1):
            mark = "[green]x[/green]" if n in selected else " "
            tag = " [dim](needs config)[/dim]" if n in _AGENCY_SERVER_PARAMS else ""
            console.print(f"  [{mark}] {i:2d}. {n:20s} {d}{tag}")

        choice = (
            console.input(
                f"\n[bold]Toggle ([cyan]1-{len(items)}[/cyan], [cyan]a[/cyan]ll, [cyan]n[/cyan]one) or Enter:[/bold] "
            )
            .strip()
            .lower()
        )

        if not choice:
            break
        elif choice == "a":
            selected = {n for n, _ in items}
        elif choice == "n":
            selected.clear()
        else:
            for p in choice.replace(",", " ").split():
                try:
                    idx = int(p) - 1
                    if 0 <= idx < len(items):
                        selected ^= {items[idx][0]}
                except ValueError:
                    pass
        console.print()

    return [n for n, _ in items if n in selected]


def _resolve_extra_args(name: str, use_defaults: bool) -> list[str] | None:
    """Resolve extra CLI args for servers that need them.

    Returns [] for no-param servers, list of args, or None if user skips.
    """
    if name not in _AGENCY_SERVER_PARAMS:
        return []

    if use_defaults:
        args: list[str] = []
        for flag, val in _AGENCY_PARAM_DEFAULTS.get(name, {}).items():
            args.extend([flag, val])
        return args or None

    print("configuring...")
    return _resolve_server_args(name) or None


@mcp_app.command("add-agency")
def mcp_add_agency(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    all_servers: bool = typer.Option(
        False, "--all", help="Add all discovered servers without prompting"
    ),
    skip_test: bool = typer.Option(
        False, "--skip-test", help="Skip auth testing (add without verifying)"
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Show what would be added without writing"
    ),
) -> None:
    """Auto-discover Agency MCP servers and add them to the config.

    Shows an interactive selection with recommended servers pre-selected.
    Use --all to skip the prompt and add everything.
    Use --skip-test to skip auth verification (faster, no timeout waits).
    """
    config_path = _resolve_config_path(config)
    result = _run_add_agency(
        config_path=config_path,
        select_all=all_servers,
        skip_test=skip_test,
        dry_run=dry_run,
    )
    if result is None and not dry_run:
        raise typer.Exit(0)
