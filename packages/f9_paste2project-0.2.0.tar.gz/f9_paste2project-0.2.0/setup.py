from setuptools import setup, find_packages

setup(
    name="f9-Paste2Project",
    version="0.2.0",
    packages=find_packages(),
    install_requires=[],
    entry_points={
        "console_scripts": [
            "f9=f9.cli:main",
        ],
    },
    author="Forex911",
    description="CLI tool to create folder structures from tree input",
)