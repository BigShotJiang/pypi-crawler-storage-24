# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
from aliyunsdkeds_user.endpoint import endpoint_data

class CreateResourceGroupRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'eds-user', '2021-03-08', 'CreateResourceGroup','eds-user')
		self.set_method('POST')

		if hasattr(self, "endpoint_map"):
			setattr(self, "endpoint_map", endpoint_data.getEndpointMap())
		if hasattr(self, "endpoint_regional"):
			setattr(self, "endpoint_regional", endpoint_data.getEndpointRegional())

	def get_ResourceGroupName(self): # String
		return self.get_query_params().get('ResourceGroupName')

	def set_ResourceGroupName(self, ResourceGroupName):  # String
		self.add_query_param('ResourceGroupName', ResourceGroupName)
	def get_BusinessChannel(self): # String
		return self.get_query_params().get('BusinessChannel')

	def set_BusinessChannel(self, BusinessChannel):  # String
		self.add_query_param('BusinessChannel', BusinessChannel)
	def get_Platform(self): # String
		return self.get_query_params().get('Platform')

	def set_Platform(self, Platform):  # String
		self.add_query_param('Platform', Platform)
	def get_IsResourceGroupWithOfficeSite(self): # Long
		return self.get_query_params().get('IsResourceGroupWithOfficeSite')

	def set_IsResourceGroupWithOfficeSite(self, IsResourceGroupWithOfficeSite):  # Long
		self.add_query_param('IsResourceGroupWithOfficeSite', IsResourceGroupWithOfficeSite)
