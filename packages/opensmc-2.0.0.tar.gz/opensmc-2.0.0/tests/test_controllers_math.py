"""Thorough mathematical validation of controllers.

Tests closed-loop convergence on DoubleIntegrator for every controller
that supports 2nd-order systems.
"""

import numpy as np
import pytest


def run_regulation(ctrl, x0=None, T=5.0, dt=1e-4, tol=0.05):
    """Helper: run regulation on DoubleIntegrator, check convergence."""
    from opensmc.plants import DoubleIntegrator
    from opensmc.simulator import Simulator

    plant = DoubleIntegrator()
    if x0 is None:
        x0 = [2.0, 0.0]
    sim = Simulator(dt=dt, T=T)
    result = sim.run(ctrl, plant, x0=x0)
    final_x = result['x'][-1, 0]
    return result, final_x


class TestClassicalSMC:
    def test_converges(self):
        from opensmc.controllers import ClassicalSMC
        ctrl = ClassicalSMC(c=10.0, k=5.0, eta=1.0)
        _, final_x = run_regulation(ctrl)
        assert abs(final_x) < 0.01, f"ClassicalSMC final x = {final_x}"

    def test_returns_info_with_s(self):
        from opensmc.controllers import ClassicalSMC
        ctrl = ClassicalSMC(c=10.0, k=5.0, eta=1.0)
        u, info = ctrl.compute(0, np.array([2.0, 0.0]), np.array([0.0, 0.0]))
        assert 's' in info
        assert isinstance(info['s'], (float, np.floating))

    def test_different_x0(self):
        from opensmc.controllers import ClassicalSMC
        ctrl = ClassicalSMC(c=10.0, k=5.0, eta=1.0)
        for x0 in [[1.0, 0.0], [5.0, 0.0], [-3.0, 1.0], [0.5, -2.0]]:
            _, final_x = run_regulation(ctrl, x0=x0)
            assert abs(final_x) < 0.05, f"ClassicalSMC x0={x0}, final={final_x}"


class TestAdaptiveSMC:
    def test_converges(self):
        from opensmc.controllers import AdaptiveSMC
        ctrl = AdaptiveSMC(c=10.0, eta0=0.5, gamma=2.0, dt=1e-4)
        _, final_x = run_regulation(ctrl)
        assert abs(final_x) < 0.05, f"AdaptiveSMC final x = {final_x}"


class TestITSMC:
    def test_converges(self):
        from opensmc.controllers import ITSMC
        ctrl = ITSMC(c1=5, c2=2, p=5, q=7, K=5, lambda_s=3, phi=0.05, dt=1e-4)
        _, final_x = run_regulation(ctrl)
        assert abs(final_x) < 0.05, f"ITSMC final x = {final_x}"

    def test_reset(self):
        from opensmc.controllers import ITSMC
        ctrl = ITSMC(c1=5, c2=2, p=5, q=7, K=5, lambda_s=3, phi=0.05, dt=1e-4)
        # Run once
        run_regulation(ctrl, T=1.0)
        # Reset and run again — should get same result
        ctrl.reset()
        _, final_x = run_regulation(ctrl)
        assert abs(final_x) < 0.05


class TestNFTSMC:
    def test_converges(self):
        from opensmc.controllers import NFTSMC
        ctrl = NFTSMC(alpha=5.0, beta=2.0, gamma=1.4,
                      k1=10.0, k2=3.0, rho=0.714,
                      eta=1.0, delta=1e-6, dt=1e-4)
        _, final_x = run_regulation(ctrl)
        assert abs(final_x) < 0.05, f"NFTSMC final x = {final_x}"


class TestFixedTimeSMC:
    def test_converges(self):
        from opensmc.controllers import FixedTimeSMC
        ctrl = FixedTimeSMC(c=10.0, alpha=15.0, beta=15.0, p=0.5, q=1.5)
        _, final_x = run_regulation(ctrl)
        assert abs(final_x) < 0.05, f"FixedTimeSMC final x = {final_x}"


class TestDiscreteSMC:
    def test_converges(self):
        from opensmc.controllers import DiscreteSMC
        ctrl = DiscreteSMC(c=10.0, q_rate=5.0, epsilon=0.1, Ts=1e-4)
        _, final_x = run_regulation(ctrl)
        assert abs(final_x) < 0.1, f"DiscreteSMC final x = {final_x}"


class TestFuzzySMC:
    def test_converges(self):
        from opensmc.controllers import FuzzySMC
        ctrl = FuzzySMC(c=10.0, k=15.0, dt=1e-4)
        _, final_x = run_regulation(ctrl)
        assert abs(final_x) < 0.1, f"FuzzySMC final x = {final_x}"


class TestComposability:
    """Test that different surface+reaching combinations all converge."""

    def test_linear_constant(self):
        from opensmc.surfaces import LinearSurface
        from opensmc.reaching import ConstantRate
        from opensmc.controllers import ClassicalSMC
        surf = LinearSurface(c=10.0)
        reach = ConstantRate(k=10.0)
        ctrl = ClassicalSMC(surface=surf, reaching=reach)
        _, final_x = run_regulation(ctrl)
        assert abs(final_x) < 0.1

    def test_linear_saturation(self):
        from opensmc.surfaces import LinearSurface
        from opensmc.reaching import Saturation
        from opensmc.controllers import ClassicalSMC
        surf = LinearSurface(c=10.0)
        reach = Saturation(k=15.0, phi=0.1)
        ctrl = ClassicalSMC(surface=surf, reaching=reach)
        _, final_x = run_regulation(ctrl)
        assert abs(final_x) < 0.1

    def test_fast_terminal_super_twisting(self):
        from opensmc.surfaces import FastTerminalSurface
        from opensmc.reaching import SuperTwisting
        from opensmc.controllers import ClassicalSMC
        surf = FastTerminalSurface(alpha=10.0, beta=2.0, p=5, q=7)
        reach = SuperTwisting(k1=5.0, k2=3.0, dt=1e-4)
        ctrl = ClassicalSMC(surface=surf, reaching=reach)
        _, final_x = run_regulation(ctrl)
        assert abs(final_x) < 0.1
