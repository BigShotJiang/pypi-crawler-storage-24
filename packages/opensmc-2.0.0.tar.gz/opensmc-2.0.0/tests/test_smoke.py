"""OpenSMC smoke tests — verify all components import and basic simulation works."""

import numpy as np
import pytest


# ── Import tests ──────────────────────────────────────────────────

def test_import_core():
    from opensmc.core import SlidingSurface, ReachingLaw, Plant, Controller, Estimator, Architecture, NoEstimator


def test_import_surfaces():
    from opensmc.surfaces import (LinearSurface, TerminalSurface, NonsingularTerminalSurface,
        FastTerminalSurface, IntegralTerminalSurface, IntegralSlidingSurface,
        PIDSurface, HierarchicalSurface, NonlinearDampingSurface,
        GlobalSurface, PredefinedTimeSurface)


def test_import_reaching():
    from opensmc.reaching import ConstantRate, ExponentialRate, PowerRate, SuperTwisting, Saturation


def test_import_controllers():
    from opensmc.controllers import (ClassicalSMC, AdaptiveSMC, DynamicSMC,
        AggregatedHSMC, IncrementalHSMC, CombiningHSMC,
        DiscreteSMC, FixedTimeSMC, FuzzySMC, ITSMC, NFTSMC)


def test_import_plants():
    from opensmc.plants import (DoubleIntegrator, InvertedPendulum,
        SinglePendulumCrane, DoublePendulumCrane, Quadrotor6DOF,
        DualStageNanopositioner, TwoLinkArm, PMSM, SurfaceVessel)


def test_import_estimators():
    from opensmc.estimators import (NoEstimator, DisturbanceObserver, ExtendedStateObserver,
        HighGainObserver, IntegralChainDifferentiator, LevantDifferentiator, RBF_ELM)


def test_import_simulator():
    from opensmc.simulator import Simulator, rk4_step


def test_import_metrics():
    from opensmc.metrics import rmse, ise, settling_time, chattering_index, compute_all


# ── Surface tests ─────────────────────────────────────────────────

def test_linear_surface():
    from opensmc.surfaces import LinearSurface
    s = LinearSurface(c=10.0)
    assert abs(s.compute(1.0, 0.0) - 10.0) < 1e-12
    assert abs(s.compute(0.0, 1.0) - 1.0) < 1e-12
    assert abs(s.compute(0.0, 0.0)) < 1e-12


def test_terminal_surface():
    from opensmc.surfaces import TerminalSurface
    s = TerminalSurface(beta=1.0, p=5, q=7)
    val = s.compute(1.0, 0.0)
    assert abs(val - 1.0) < 1e-10  # |1|^(5/7)*sign(1) = 1


def test_fast_terminal_surface():
    from opensmc.surfaces import FastTerminalSurface
    s = FastTerminalSurface(alpha=5.0, beta=2.0, p=5, q=7)
    val = s.compute(0.0, 0.0)
    assert abs(val) < 1e-12  # origin: s=0


# ── Reaching law tests ────────────────────────────────────────────

def test_constant_rate():
    from opensmc.reaching import ConstantRate
    r = ConstantRate(k=5.0)
    assert r.compute(1.0) == -5.0
    assert r.compute(-1.0) == 5.0


def test_super_twisting():
    from opensmc.reaching import SuperTwisting
    r = SuperTwisting(k1=5.0, k2=3.0, dt=0.01)
    u1 = r.compute(1.0)
    assert u1 < 0  # should push s toward 0
    r.reset()


# ── Plant tests ───────────────────────────────────────────────────

def test_double_integrator():
    from opensmc.plants import DoubleIntegrator
    p = DoubleIntegrator()
    assert p.n_states == 2
    assert p.n_inputs == 1
    xdot = p.dynamics(0, np.zeros(2), 1.0)
    assert abs(xdot[1] - 1.0) < 1e-12  # xddot = u = 1


def test_quadrotor_hover():
    from opensmc.plants import Quadrotor6DOF
    q = Quadrotor6DOF()
    u_hover = np.array([q.mass * q.g, 0, 0, 0])
    xdot = q.dynamics(0, np.zeros(12), u_hover)
    assert np.max(np.abs(xdot)) < 1e-10


def test_two_link_arm_dims():
    from opensmc.plants import TwoLinkArm
    arm = TwoLinkArm()
    assert arm.n_states == 4
    assert arm.n_inputs == 2


# ── Controller tests ──────────────────────────────────────────────

def test_classical_smc_regulation():
    from opensmc.controllers import ClassicalSMC
    from opensmc.plants import DoubleIntegrator
    from opensmc.simulator import Simulator

    plant = DoubleIntegrator()
    ctrl = ClassicalSMC(c=10.0, k=5.0, eta=1.0)
    sim = Simulator(dt=1e-4, T=3.0)
    result = sim.run(ctrl, plant, x0=[1.0, 0.0])
    assert abs(result['x'][-1, 0]) < 0.01, f"Final x = {result['x'][-1, 0]}"


def test_itsmc_regulation():
    from opensmc.controllers import ITSMC
    from opensmc.plants import DoubleIntegrator
    from opensmc.simulator import Simulator

    plant = DoubleIntegrator()
    ctrl = ITSMC(c1=5, c2=2, p=5, q=7, K=5, lambda_s=3, phi=0.05, dt=1e-4)
    sim = Simulator(dt=1e-4, T=5.0)
    result = sim.run(ctrl, plant, x0=[2.0, 0.0])
    assert abs(result['x'][-1, 0]) < 0.05, f"Final x = {result['x'][-1, 0]}"


# ── Metrics test ──────────────────────────────────────────────────

def test_metrics_on_result():
    from opensmc.controllers import ClassicalSMC
    from opensmc.plants import DoubleIntegrator
    from opensmc.simulator import Simulator
    from opensmc.metrics import compute_all

    plant = DoubleIntegrator()
    ctrl = ClassicalSMC(c=10.0, k=5.0, eta=1.0)
    sim = Simulator(dt=1e-4, T=3.0)
    result = sim.run(ctrl, plant, x0=[1.0, 0.0])
    m = compute_all(result, axis=0)
    assert 'rmse' in m
    assert 'ise' in m
    assert 'settling_time' in m
    assert m['rmse'] > 0
    assert m['settling_time'] < 3.0


# ── Composability test ────────────────────────────────────────────

def test_surface_swap():
    """Verify any surface can plug into ClassicalSMC."""
    from opensmc.surfaces import LinearSurface, FastTerminalSurface, GlobalSurface
    from opensmc.reaching import Saturation
    from opensmc.controllers import ClassicalSMC
    from opensmc.plants import DoubleIntegrator
    from opensmc.simulator import Simulator

    plant = DoubleIntegrator()
    sim = Simulator(dt=1e-4, T=3.0)
    reach = Saturation(k=10.0, phi=0.1)

    for SurfClass, kwargs in [
        (LinearSurface, {'c': 10}),
        (FastTerminalSurface, {'alpha': 10, 'beta': 2, 'p': 5, 'q': 7}),
        (GlobalSurface, {'c': 10, 'alpha': 5}),
    ]:
        surf = SurfClass(**kwargs)
        ctrl = ClassicalSMC(surface=surf, reaching=reach)
        result = sim.run(ctrl, plant, x0=[1.0, 0.0])
        # All should at least not diverge
        assert np.max(np.abs(result['x'][-1])) < 10.0, \
            f"{SurfClass.__name__} diverged: x_final = {result['x'][-1]}"
