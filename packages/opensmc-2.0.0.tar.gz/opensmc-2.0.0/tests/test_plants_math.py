"""Thorough mathematical validation of all 9 plants.

Cross-checks dynamics against known analytical results from notebooks.
"""

import numpy as np
import pytest


class TestDoubleIntegrator:
    def test_dimensions(self):
        from opensmc.plants import DoubleIntegrator
        p = DoubleIntegrator()
        assert p.n_states == 2
        assert p.n_inputs == 1
        assert p.n_outputs == 1

    def test_free_response(self):
        from opensmc.plants import DoubleIntegrator
        p = DoubleIntegrator()
        xdot = p.dynamics(0, np.array([0.0, 0.0]), 0.0)
        assert np.allclose(xdot, [0.0, 0.0])

    def test_unit_force(self):
        from opensmc.plants import DoubleIntegrator
        p = DoubleIntegrator(J=1.0)
        xdot = p.dynamics(0, np.array([0.0, 0.0]), 1.0)
        assert abs(xdot[0]) < 1e-12  # velocity unchanged instantly
        assert abs(xdot[1] - 1.0) < 1e-12  # acceleration = u/J = 1

    def test_inertia_scaling(self):
        from opensmc.plants import DoubleIntegrator
        p = DoubleIntegrator(J=2.0)
        xdot = p.dynamics(0, np.array([0.0, 0.0]), 1.0)
        assert abs(xdot[1] - 0.5) < 1e-12  # acceleration = u/J = 0.5

    def test_velocity_propagation(self):
        from opensmc.plants import DoubleIntegrator
        p = DoubleIntegrator()
        xdot = p.dynamics(0, np.array([0.0, 3.0]), 0.0)
        assert abs(xdot[0] - 3.0) < 1e-12  # position derivative = velocity


class TestQuadrotor6DOF:
    def test_dimensions(self):
        from opensmc.plants import Quadrotor6DOF
        q = Quadrotor6DOF()
        assert q.n_states == 12
        assert q.n_inputs == 4

    def test_hover_equilibrium(self):
        """U1=mg, U2=U3=U4=0 at origin: all derivatives should be zero."""
        from opensmc.plants import Quadrotor6DOF
        q = Quadrotor6DOF()
        u = np.array([q.mass * q.g, 0.0, 0.0, 0.0])
        xdot = q.dynamics(0, np.zeros(12), u)
        assert np.max(np.abs(xdot)) < 1e-10, f"Hover xdot max = {np.max(np.abs(xdot))}"

    def test_free_fall(self):
        """U=0 at origin: az should be -g."""
        from opensmc.plants import Quadrotor6DOF
        q = Quadrotor6DOF()
        xdot = q.dynamics(0, np.zeros(12), np.zeros(4))
        assert abs(xdot[8] - (-q.g)) < 1e-10, f"Free fall az = {xdot[8]}"
        # No lateral acceleration
        assert abs(xdot[6]) < 1e-10
        assert abs(xdot[7]) < 1e-10

    def test_roll_pitch_symmetry(self):
        """Ixx=Iyy means roll and pitch are symmetric."""
        from opensmc.plants import Quadrotor6DOF
        q = Quadrotor6DOF()
        assert q.Ixx == q.Iyy
        u_hover = np.array([q.mass * q.g, 0, 0, 0])
        # Roll torque
        u_roll = u_hover.copy(); u_roll[1] = 0.01
        xdot_roll = q.dynamics(0, np.zeros(12), u_roll)
        # Pitch torque
        u_pitch = u_hover.copy(); u_pitch[2] = 0.01
        xdot_pitch = q.dynamics(0, np.zeros(12), u_pitch)
        # pdot from roll == qdot from pitch
        assert abs(xdot_roll[9] - xdot_pitch[10]) < 1e-14


class TestSinglePendulumCrane:
    def test_dimensions(self):
        from opensmc.plants import SinglePendulumCrane
        c = SinglePendulumCrane()
        assert c.n_states == 4
        assert c.n_inputs == 1

    def test_equilibrium_at_origin(self):
        from opensmc.plants import SinglePendulumCrane
        c = SinglePendulumCrane()
        xdot = c.dynamics(0, np.zeros(4), 0.0)
        assert np.max(np.abs(xdot)) < 1e-12

    def test_dynamics_decomposition(self):
        """Verify f1+b1*u matches xddot, f2+b2*u matches phiddot."""
        from opensmc.plants import SinglePendulumCrane
        c = SinglePendulumCrane()
        x_test = np.array([0.5, 0.3, 0.4, 0.8])
        u_test = 2.0
        xdot = c.dynamics(0, x_test, u_test)
        f1, b1, f2, b2 = c.get_dynamics_components(x_test)
        assert abs(xdot[1] - (f1 + b1 * u_test)) < 1e-10
        assert abs(xdot[3] - (f2 + b2 * u_test)) < 1e-10


class TestTwoLinkArm:
    def test_dimensions(self):
        from opensmc.plants import TwoLinkArm
        a = TwoLinkArm()
        assert a.n_states == 4
        assert a.n_inputs == 2

    def test_mass_matrix_symmetric_pd(self):
        from opensmc.plants import TwoLinkArm
        a = TwoLinkArm()
        for _ in range(10):
            q1 = np.random.uniform(-np.pi, np.pi)
            q2 = np.random.uniform(-np.pi, np.pi)
            M = a.mass_matrix(q1, q2)
            # Symmetric
            assert abs(M[0, 1] - M[1, 0]) < 1e-12
            # Positive definite
            eigvals = np.linalg.eigvalsh(M)
            assert np.all(eigvals > 0), f"M not PD at q=[{q1:.3f},{q2:.3f}]"

    def test_gravity_compensation(self):
        """tau = G(q) should produce zero acceleration."""
        from opensmc.plants import TwoLinkArm
        a = TwoLinkArm()
        x = np.array([0.3, 0.0, 0.5, 0.0])  # zero velocity
        G = a.gravity_vector(x[0], x[2])
        xdot = a.dynamics(0, x, G)
        # With tau=G and zero velocity, accelerations should be ~0
        assert abs(xdot[1]) < 1e-6, f"q1ddot = {xdot[1]}"
        assert abs(xdot[3]) < 1e-6, f"q2ddot = {xdot[3]}"


class TestNanopositioner:
    def test_dimensions(self):
        from opensmc.plants import DualStageNanopositioner
        n = DualStageNanopositioner()
        assert n.n_states == 4
        assert n.n_inputs == 1
        assert n.n_outputs == 1

    def test_equilibrium(self):
        from opensmc.plants import DualStageNanopositioner
        n = DualStageNanopositioner()
        xdot = n.dynamics(0, np.zeros(4), 0.0)
        assert np.max(np.abs(xdot)) < 1e-12

    def test_dc_gain(self):
        """DC gain should be Kp1 + Kp2."""
        from opensmc.plants import DualStageNanopositioner
        n = DualStageNanopositioner()
        expected = n.Kp1 + n.Kp2
        assert abs(expected - 0.160e-6) < 1e-9  # 0.160 um/V


class TestPMSM:
    def test_dimensions(self):
        from opensmc.plants import PMSM
        p = PMSM()
        assert p.n_states == 4
        assert p.n_inputs == 2


class TestSurfaceVessel:
    def test_dimensions(self):
        from opensmc.plants import SurfaceVessel
        v = SurfaceVessel()
        assert v.n_states == 6
        assert v.n_inputs == 3

    def test_rest_equilibrium(self):
        from opensmc.plants import SurfaceVessel
        v = SurfaceVessel()
        xdot = v.dynamics(0, np.zeros(6), np.zeros(3))
        assert np.max(np.abs(xdot)) < 1e-12


class TestInvertedPendulum:
    def test_dimensions(self):
        from opensmc.plants import InvertedPendulum
        p = InvertedPendulum()
        assert p.n_states == 4
        assert p.n_inputs == 1
