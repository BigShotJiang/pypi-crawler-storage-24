"""Phase C validation: PID/LQR baselines and Gymnasium environments."""

import numpy as np
import pytest


# ── PID Baseline ──────────────────────────────────────────────────

class TestPID:
    def test_converges_on_double_integrator(self):
        from opensmc.controllers import PID
        from opensmc.plants import DoubleIntegrator
        from opensmc.simulator import Simulator

        plant = DoubleIntegrator()
        ctrl = PID(Kp=20.0, Kd=10.0, Ki=0.0, dt=1e-4)
        sim = Simulator(dt=1e-4, T=5.0)
        result = sim.run(ctrl, plant, x0=[2.0, 0.0])
        assert abs(result['x'][-1, 0]) < 0.1, f"PID final x = {result['x'][-1, 0]}"

    def test_integral_eliminates_ss_error(self):
        """With constant disturbance, Ki>0 should reduce SS error."""
        from opensmc.controllers import PID
        from opensmc.plants import DoubleIntegrator
        from opensmc.simulator import Simulator
        from opensmc import utils

        plant = DoubleIntegrator()
        sim = Simulator(dt=1e-4, T=10.0)
        dist = utils.step_disturbance(amplitude=1.0, t_start=0.0, n_states=2, axis=1)

        # PD only (Ki=0): will have steady-state error under constant d
        ctrl_pd = PID(Kp=20.0, Kd=10.0, Ki=0.0, dt=1e-4)
        r_pd = sim.run(ctrl_pd, plant, x0=[0.0, 0.0], dist_fn=dist)

        # PID (Ki>0): should eliminate SS error
        ctrl_pid = PID(Kp=20.0, Kd=10.0, Ki=5.0, dt=1e-4)
        r_pid = sim.run(ctrl_pid, plant, x0=[0.0, 0.0], dist_fn=dist)

        ss_pd = np.mean(np.abs(r_pd['x'][-10000:, 0]))
        ss_pid = np.mean(np.abs(r_pid['x'][-10000:, 0]))
        assert ss_pid < ss_pd, f"PID SS error {ss_pid} should be < PD SS error {ss_pd}"

    def test_reset_clears_integral(self):
        from opensmc.controllers import PID
        ctrl = PID(Kp=10, Kd=5, Ki=1.0, dt=0.01)
        # Accumulate integral
        for _ in range(100):
            ctrl.compute(0, np.array([1.0, 0.0]), np.array([0.0, 0.0]))
        ctrl.reset()
        assert ctrl._e_int[0] == 0.0

    def test_info_has_s(self):
        from opensmc.controllers import PID
        ctrl = PID(Kp=10, Kd=5)
        u, info = ctrl.compute(0, np.array([2.0, 0.0]), np.array([0.0, 0.0]))
        assert 's' in info


# ── LQR Baseline ──────────────────────────────────────────────────

class TestLQR:
    def test_converges_on_double_integrator(self):
        from opensmc.controllers import LQR
        from opensmc.plants import DoubleIntegrator
        from opensmc.simulator import Simulator

        A = np.array([[0, 1], [0, 0]])
        B = np.array([[0], [1]])
        Q = np.diag([10.0, 1.0])
        R = np.array([[1.0]])

        plant = DoubleIntegrator()
        ctrl = LQR(A, B, Q, R)
        sim = Simulator(dt=1e-4, T=5.0)
        result = sim.run(ctrl, plant, x0=[2.0, 0.0])
        assert abs(result['x'][-1, 0]) < 0.01, f"LQR final x = {result['x'][-1, 0]}"

    def test_gain_matrix_shape(self):
        from opensmc.controllers import LQR
        A = np.array([[0, 1], [0, 0]])
        B = np.array([[0], [1]])
        ctrl = LQR(A, B)
        assert ctrl.K.shape == (1, 2)

    def test_info_has_s(self):
        from opensmc.controllers import LQR
        A = np.array([[0, 1], [0, 0]])
        B = np.array([[0], [1]])
        ctrl = LQR(A, B)
        u, info = ctrl.compute(0, np.array([2.0, 0.0]), np.array([0.0, 0.0]))
        assert 's' in info

    def test_optimal_vs_pid(self):
        """LQR should outperform PID in ISE (it's optimal by definition)."""
        from opensmc.controllers import LQR, PID
        from opensmc.plants import DoubleIntegrator
        from opensmc.simulator import Simulator
        from opensmc import metrics

        A = np.array([[0, 1], [0, 0]])
        B = np.array([[0], [1]])
        Q = np.diag([10.0, 1.0])
        R = np.array([[0.1]])

        plant = DoubleIntegrator()
        sim = Simulator(dt=1e-4, T=5.0)

        ctrl_lqr = LQR(A, B, Q, R)
        ctrl_pid = PID(Kp=10, Kd=5, dt=1e-4)

        r_lqr = sim.run(ctrl_lqr, plant, x0=[2.0, 0.0])
        r_pid = sim.run(ctrl_pid, plant, x0=[2.0, 0.0])

        ise_lqr = metrics.ise(r_lqr, axis=0)
        ise_pid = metrics.ise(r_pid, axis=0)
        # LQR should have lower or comparable ISE
        # (not strictly guaranteed since PID might be well-tuned,
        #  but LQR with proper Q,R should generally win)
        assert ise_lqr < ise_pid * 2, f"LQR ISE {ise_lqr} vs PID ISE {ise_pid}"


# ── Gymnasium Environments ────────────────────────────────────────

class TestGymnasiumEnvs:
    @pytest.fixture(autouse=True)
    def check_gymnasium(self):
        try:
            import gymnasium
        except ImportError:
            pytest.skip("gymnasium not installed")

    def test_double_integrator_env_reset_step(self):
        from opensmc.envs import DoubleIntegratorEnv
        env = DoubleIntegratorEnv(dt=1e-3, T_max=1.0)
        obs, info = env.reset(seed=42)
        assert obs.shape == (2,)

        # Take one step with zero action
        obs, reward, terminated, truncated, info = env.step(np.array([0.0]))
        assert obs.shape == (2,)
        assert isinstance(reward, float)
        assert not terminated

    def test_double_integrator_env_episode(self):
        from opensmc.envs import DoubleIntegratorEnv
        env = DoubleIntegratorEnv(dt=1e-2, T_max=1.0)
        obs, _ = env.reset(seed=42)
        total_reward = 0.0
        steps = 0
        truncated = False
        while not truncated:
            action = -5.0 * obs[:1]  # simple proportional control
            obs, reward, _, truncated, _ = env.step(action)
            total_reward += reward
            steps += 1
        assert steps == 100  # T_max / dt = 1.0 / 0.01

    def test_crane_env_reset_step(self):
        from opensmc.envs import CraneEnv
        env = CraneEnv(dt=1e-3, T_max=1.0)
        obs, info = env.reset(seed=42)
        assert obs.shape == (4,)
        obs, reward, _, _, info = env.step(np.array([1.0]))
        assert obs.shape == (4,)
        assert 'phi' in info

    def test_quadrotor_env_reset_step(self):
        from opensmc.envs import QuadrotorEnv
        env = QuadrotorEnv(dt=1e-3, T_max=1.0)
        obs, info = env.reset(seed=42)
        assert obs.shape == (12,)
        # Hover thrust
        hover = np.array([env.mass * env.g, 0, 0, 0])
        obs, reward, _, _, info = env.step(hover)
        assert obs.shape == (12,)

    def test_double_integrator_env_action_clipping(self):
        from opensmc.envs import DoubleIntegratorEnv
        env = DoubleIntegratorEnv(u_max=5.0)
        env.reset(seed=42)
        # Action exceeds u_max — should be clipped
        obs, _, _, _, _ = env.step(np.array([100.0]))
        # State should not explode (clipped to 5)
        assert np.all(np.isfinite(obs))
