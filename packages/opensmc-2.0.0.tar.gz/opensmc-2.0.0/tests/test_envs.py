"""Tests for all 5 Gymnasium environments and RLDiscoveredSurface."""

import numpy as np
import pytest

gymnasium = pytest.importorskip("gymnasium")
from gymnasium.utils.env_checker import check_env

from opensmc.envs import (
    DoubleIntegratorEnv, CraneEnv, QuadrotorEnv,
    InvertedPendulumEnv, PMSMEnv,
)


# ── check_env passes for all envs ─────────────────────────────────────────

class TestCheckEnv:
    def test_double_integrator(self):
        check_env(DoubleIntegratorEnv(), skip_render_check=True)

    def test_crane(self):
        check_env(CraneEnv(), skip_render_check=True)

    def test_quadrotor(self):
        check_env(QuadrotorEnv(), skip_render_check=True)

    def test_inverted_pendulum(self):
        check_env(InvertedPendulumEnv(), skip_render_check=True)

    def test_pmsm(self):
        check_env(PMSMEnv(), skip_render_check=True)


# ── gym.make registration ────────────────────────────────────────────────

class TestRegistration:
    @pytest.fixture(autouse=True)
    def _register(self):
        import opensmc  # triggers registration

    @pytest.mark.parametrize("env_id", [
        "OpenSMC/DoubleIntegrator-v0",
        "OpenSMC/Crane-v0",
        "OpenSMC/Quadrotor-v0",
        "OpenSMC/InvertedPendulum-v0",
        "OpenSMC/PMSM-v0",
    ])
    def test_gym_make(self, env_id):
        env = gymnasium.make(env_id)
        obs, info = env.reset(seed=42)
        assert obs.shape == env.observation_space.shape
        obs2, r, term, trunc, info2 = env.step(env.action_space.sample())
        assert obs2.shape == env.observation_space.shape
        assert isinstance(r, float)
        env.close()


# ── Functional tests ─────────────────────────────────────────────────────

class TestDoubleIntegratorEnv:
    def test_zero_action_drifts(self):
        env = DoubleIntegratorEnv(x0_range=0.0)
        obs, _ = env.reset(seed=0)
        obs, r, _, _, _ = env.step(np.array([0.0]))
        assert obs.shape == (2,)

    def test_reward_is_negative(self):
        env = DoubleIntegratorEnv()
        env.reset(seed=1)
        _, r, _, _, _ = env.step(np.array([1.0]))
        assert r <= 0

    def test_disturbance(self):
        env = DoubleIntegratorEnv(disturbance=5.0)
        env.reset(seed=42)
        obs, _, _, _, _ = env.step(np.array([0.0]))
        assert np.all(np.isfinite(obs))


class TestCraneEnv:
    def test_reset_at_origin(self):
        env = CraneEnv()
        obs, _ = env.reset()
        np.testing.assert_array_almost_equal(obs, 0.0)

    def test_force_moves_trolley(self):
        env = CraneEnv(dt=1e-2)
        env.reset()
        for _ in range(100):
            obs, _, _, _, _ = env.step(np.array([10.0]))
        assert obs[0] > 0


class TestQuadrotorEnv:
    def test_hover_thrust(self):
        env = QuadrotorEnv(dt=1e-3)
        env.reset()
        hover = np.array([env.mass * env.g, 0, 0, 0])
        for _ in range(100):
            obs, _, _, _, _ = env.step(hover)
        assert abs(obs[2]) < 0.1

    def test_obs_shape(self):
        env = QuadrotorEnv()
        obs, _ = env.reset()
        assert obs.shape == (12,)


class TestInvertedPendulumEnv:
    def test_terminates_on_fall(self):
        env = InvertedPendulumEnv(theta_threshold=0.3, dt=1e-2)
        env.reset(seed=0)
        terminated = False
        for _ in range(10000):
            _, _, terminated, truncated, _ = env.step(np.array([0.0]))
            if terminated or truncated:
                break
        assert terminated or truncated

    def test_obs_shape(self):
        env = InvertedPendulumEnv()
        obs, _ = env.reset()
        assert obs.shape == (4,)


class TestPMSMEnv:
    def test_obs_includes_ref(self):
        env = PMSMEnv(omega_ref=100.0)
        obs, _ = env.reset()
        assert obs.shape == (5,)
        assert obs[4] == pytest.approx(100.0)

    def test_voltage_drives_motor(self):
        env = PMSMEnv(dt=1e-3, T_max=1.0, omega_ref=50.0)
        env.reset()
        for _ in range(500):
            obs, _, _, _, _ = env.step(np.array([0.0, 20.0]))
        assert obs[2] > 0


# ── RLDiscoveredSurface ──────────────────────────────────────────────────

class TestRLDiscoveredSurface:
    def test_callable_model(self):
        from opensmc.rl import RLDiscoveredSurface

        def mock_policy(obs):
            e, edot = obs[0], obs[1]
            return np.array([edot + 10 * e])

        surface = RLDiscoveredSurface(model=mock_policy)
        s = surface.compute(e=1.0, edot=-2.0)
        expected = -2.0 + 10 * 1.0
        assert s == pytest.approx(expected, abs=1e-6)

    def test_scale_factor(self):
        from opensmc.rl import RLDiscoveredSurface

        def identity(obs):
            return np.array([obs[0] + obs[1]])

        surface = RLDiscoveredSurface(model=identity, scale=2.0)
        s = surface.compute(e=1.0, edot=1.0)
        assert s == pytest.approx(4.0, abs=1e-6)

    def test_custom_obs_fn(self):
        from opensmc.rl import RLDiscoveredSurface

        def custom_obs(e, edot, t):
            return np.array([e, edot, t], dtype=np.float32)

        def policy(obs):
            return np.array([obs[0] + obs[2]])

        surface = RLDiscoveredSurface(model=policy, obs_fn=custom_obs)
        s = surface.compute(e=1.0, edot=0.0, t=5.0)
        assert s == pytest.approx(6.0, abs=1e-6)

    def test_reset_is_noop(self):
        from opensmc.rl import RLDiscoveredSurface
        surface = RLDiscoveredSurface(model=lambda obs: np.array([0.0]))
        surface.reset()

    def test_invalid_model_type(self):
        from opensmc.rl import RLDiscoveredSurface
        with pytest.raises(TypeError):
            RLDiscoveredSurface(model=42)
