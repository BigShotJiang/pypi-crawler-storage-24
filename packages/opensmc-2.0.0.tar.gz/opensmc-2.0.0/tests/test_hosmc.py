"""Thorough validation of HOSMC controllers.

Tests 2nd-order (Twisting, QC2SM) and arbitrary-order (Nested, QC-HOSMC)
against formulas from Shtessel et al. (2014), Chapters 4 and 6.
"""

import numpy as np
import pytest
from opensmc.core import Plant


def run_regulation(ctrl, x0, T=5.0, dt=1e-4):
    from opensmc.plants import DoubleIntegrator
    from opensmc.simulator import Simulator
    plant = DoubleIntegrator()
    sim = Simulator(dt=dt, T=T)
    return sim.run(ctrl, plant, x0=x0)


class TripleIntegrator(Plant):
    """x_dddot = u, for testing r=3 HOSMC."""
    def __init__(self):
        super().__init__(3, 1, 1, 'TripleIntegrator')
    def dynamics(self, t, x, u, d=None):
        u_s = float(np.ravel(u)[0]) if np.ndim(u) > 0 else float(u)
        return np.array([x[1], x[2], u_s])


class TestTwistingSMC:
    """Shtessel Sec 4.2.1, Eq 4.13."""

    def test_convergence_multiple_ics(self):
        from opensmc.controllers import TwistingSMC
        ctrl = TwistingSMC(r1=10.0, r2=5.0, c=1.0)
        for x0 in [[2, 0], [0, 3], [-1, 2], [5, -1]]:
            result = run_regulation(ctrl, x0)
            assert abs(result['x'][-1, 0]) < 0.1, f"x0={x0}"

    def test_output_is_discrete(self):
        """Twisting produces discrete u values (combinations of sign(σ), sign(σ̇))."""
        from opensmc.controllers import TwistingSMC
        ctrl = TwistingSMC(r1=10.0, r2=5.0, c=1.0)
        result = run_regulation(ctrl, [2.0, 0.0])
        u_vals = np.unique(np.round(result['u'][:, 0], 4))
        # With g_sign=-1: u = (r1*sign(σ) + r2*sign(σ̇))
        # Possible values: ±(r1±r2), ±r1 (when sign(σ̇)=0), ±r2 (when sign(σ)=0)
        allowed = {-15, -10, -5, 0, 5, 10, 15}
        assert set(u_vals).issubset(allowed), f"Got {u_vals}"

    def test_r1_gt_r2_enforced(self):
        from opensmc.controllers import TwistingSMC
        with pytest.raises(ValueError):
            TwistingSMC(r1=5.0, r2=10.0)

    def test_info_has_s_and_sdot(self):
        from opensmc.controllers import TwistingSMC
        ctrl = TwistingSMC(r1=10.0, r2=5.0, c=1.0)
        u, info = ctrl.compute(0, np.array([2.0, 0.0]), np.array([0.0, 0.0]))
        assert 's' in info
        assert 'sdot' in info

    def test_larger_r1_faster_convergence(self):
        from opensmc.controllers import TwistingSMC
        from opensmc import metrics
        r1 = run_regulation(TwistingSMC(r1=10, r2=5, c=1), [2, 0])
        r2 = run_regulation(TwistingSMC(r1=20, r2=10, c=1), [2, 0])
        ise1 = metrics.ise(r1, axis=0)
        ise2 = metrics.ise(r2, axis=0)
        assert ise2 < ise1, f"Larger gains should give lower ISE: {ise2} vs {ise1}"


class TestQuasiContinuous2SMC:
    """Shtessel Sec 4.2.4, Eq 4.30."""

    def test_convergence_multiple_ics(self):
        from opensmc.controllers import QuasiContinuous2SMC
        ctrl = QuasiContinuous2SMC(alpha=10.0, beta=2.0, c=1.0)
        for x0 in [[2, 0], [0, 3], [-1, 2], [5, -1]]:
            result = run_regulation(ctrl, x0)
            assert abs(result['x'][-1, 0]) < 0.1, f"x0={x0}"

    def test_control_bounded_by_alpha(self):
        """QC control is always bounded by |u| <= alpha."""
        from opensmc.controllers import QuasiContinuous2SMC
        ctrl = QuasiContinuous2SMC(alpha=10.0, beta=2.0, c=1.0)
        result = run_regulation(ctrl, [5.0, -1.0])
        assert np.max(np.abs(result['u'])) <= 10.0 + 1e-6

    def test_much_less_chattering_than_twisting(self):
        """QC should have orders-of-magnitude less TV(u) than Twisting."""
        from opensmc.controllers import TwistingSMC, QuasiContinuous2SMC
        res_tw = run_regulation(TwistingSMC(r1=10, r2=5, c=1), [2, 0])
        res_qc = run_regulation(QuasiContinuous2SMC(alpha=10, beta=2, c=1), [2, 0])
        tv_tw = np.sum(np.abs(np.diff(res_tw['u'][:, 0])))
        tv_qc = np.sum(np.abs(np.diff(res_qc['u'][:, 0])))
        assert tv_qc < tv_tw * 0.01, f"QC TV={tv_qc:.0f} not much less than TW TV={tv_tw:.0f}"

    def test_alpha_positive_required(self):
        from opensmc.controllers import QuasiContinuous2SMC
        with pytest.raises(ValueError):
            QuasiContinuous2SMC(alpha=-1.0)

    def test_info_has_s_and_sdot(self):
        from opensmc.controllers import QuasiContinuous2SMC
        ctrl = QuasiContinuous2SMC(alpha=10.0, beta=2.0, c=1.0)
        u, info = ctrl.compute(0, np.array([2.0, 0.0]), np.array([0.0, 0.0]))
        assert 's' in info
        assert 'sdot' in info

    def test_continuous_control_signal(self):
        """QC control should be smooth (small max|du|)."""
        from opensmc.controllers import QuasiContinuous2SMC
        ctrl = QuasiContinuous2SMC(alpha=10.0, beta=2.0, c=1.0)
        result = run_regulation(ctrl, [2.0, 0.0])
        max_du = np.max(np.abs(np.diff(result['u'][:, 0])))
        # Continuous control: max step-to-step change should be small
        # (compared to twisting which jumps 10-20 per step)
        assert max_du < 1.0, f"max|du| = {max_du:.4f}, should be < 1 for continuous control"


# ── Arbitrary-order HOSMC tests (Sec 6.6) ─────────────────────────

class TestNestedHOSMC:
    """Shtessel Sec 6.6.1 — Nested r-sliding controllers."""

    def test_r1_is_relay(self):
        """r=1 Nested reduces to u = -alpha*sign(sigma)/g_sign."""
        from opensmc.controllers import NestedHOSMC
        ctrl = NestedHOSMC(order=1, alpha=5.0, c=1.0)
        u, info = ctrl.compute(0, np.array([2.0, 0.0]), np.array([0.0, 0.0]))
        assert abs(u - (-5.0)) < 1e-6

    def test_r2_converges(self):
        from opensmc.controllers import NestedHOSMC
        ctrl = NestedHOSMC(order=2, alpha=10.0, betas=[1.0], c=1.0)
        result = run_regulation(ctrl, [2.0, 0.0])
        assert abs(result['x'][-1, 0]) < 0.1

    def test_r2_matches_qc2sm_formula_at_r2(self):
        """r=2 QuasiContinuousHOSMC should match QuasiContinuous2SMC exactly."""
        from opensmc.controllers import QuasiContinuous2SMC, QuasiContinuousHOSMC
        ctrl_2sm = QuasiContinuous2SMC(alpha=10.0, beta=1.0, c=1.0)
        ctrl_qch = QuasiContinuousHOSMC(order=2, alpha=10.0, betas=[1.0], c=1.0)
        r1 = run_regulation(ctrl_2sm, [2.0, 0.0])
        r2 = run_regulation(ctrl_qch, [2.0, 0.0])
        # Results should be identical (same formula)
        assert abs(r1['x'][-1, 0] - r2['x'][-1, 0]) < 1e-6

    def test_betas_length_check(self):
        from opensmc.controllers import NestedHOSMC
        with pytest.raises(ValueError):
            NestedHOSMC(order=3, betas=[1.0])  # needs 2 betas


class TestQuasiContinuousHOSMC:
    """Shtessel Sec 6.6.2 — Quasi-continuous r-sliding controllers."""

    def test_r2_converges(self):
        from opensmc.controllers import QuasiContinuousHOSMC
        ctrl = QuasiContinuousHOSMC(order=2, alpha=10.0, betas=[1.0], c=1.0)
        result = run_regulation(ctrl, [2.0, 0.0])
        assert abs(result['x'][-1, 0]) < 0.1

    def test_r2_bounded_by_alpha(self):
        from opensmc.controllers import QuasiContinuousHOSMC
        ctrl = QuasiContinuousHOSMC(order=2, alpha=10.0, betas=[1.0], c=1.0)
        result = run_regulation(ctrl, [2.0, 0.0])
        assert np.max(np.abs(result['u'])) <= 10.0 + 1e-6

    def test_r3_converges_on_triple_integrator(self):
        """r=3 QC-HOSMC on triple integrator (relative degree 3)."""
        from opensmc.controllers import QuasiContinuousHOSMC
        from opensmc.simulator import Simulator

        class QCR3(QuasiContinuousHOSMC):
            def compute(self, t, x, xref, plant=None, **kwargs):
                sigma = xref[0] - x[0]
                sigma_dot = -x[1]
                sigma_ddot = -x[2]
                return super().compute(t, x, xref, plant,
                                       sigma_derivs=[sigma, sigma_dot, sigma_ddot])

        plant3 = TripleIntegrator()
        sim3 = Simulator(dt=1e-4, T=10.0)
        ctrl = QCR3(order=3, alpha=15.0, betas=[1.0, 2.0])
        result = sim3.run(ctrl, plant3, x0=[1.0, 0.5, 0.0])
        final = result['x'][-1]
        assert np.max(np.abs(final)) < 0.05, f"r=3 QC final={final}"

    def test_r3_bounded_by_alpha(self):
        from opensmc.controllers import QuasiContinuousHOSMC
        from opensmc.simulator import Simulator

        class QCR3(QuasiContinuousHOSMC):
            def compute(self, t, x, xref, plant=None, **kwargs):
                sigma = xref[0] - x[0]
                sigma_dot = -x[1]
                sigma_ddot = -x[2]
                return super().compute(t, x, xref, plant,
                                       sigma_derivs=[sigma, sigma_dot, sigma_ddot])

        plant3 = TripleIntegrator()
        sim3 = Simulator(dt=1e-4, T=10.0)
        ctrl = QCR3(order=3, alpha=15.0, betas=[1.0, 2.0])
        result = sim3.run(ctrl, plant3, x0=[1.0, 0.5, 0.0])
        assert np.max(np.abs(result['u'])) <= 15.0 + 1e-6

    def test_qc_less_chattering_than_nested_r3(self):
        """QC-HOSMC should produce much smoother control than Nested at r=3."""
        from opensmc.controllers import NestedHOSMC, QuasiContinuousHOSMC
        from opensmc.simulator import Simulator

        class NestedR3(NestedHOSMC):
            def compute(self, t, x, xref, plant=None, **kwargs):
                sigma = xref[0] - x[0]
                sigma_dot = -x[1]
                sigma_ddot = -x[2]
                return super().compute(t, x, xref, plant,
                                       sigma_derivs=[sigma, sigma_dot, sigma_ddot])

        class QCR3(QuasiContinuousHOSMC):
            def compute(self, t, x, xref, plant=None, **kwargs):
                sigma = xref[0] - x[0]
                sigma_dot = -x[1]
                sigma_ddot = -x[2]
                return super().compute(t, x, xref, plant,
                                       sigma_derivs=[sigma, sigma_dot, sigma_ddot])

        plant3 = TripleIntegrator()
        sim3 = Simulator(dt=1e-4, T=10.0)
        r_n = sim3.run(NestedR3(order=3, alpha=15, betas=[1, 2]), plant3, x0=[1, 0.5, 0])
        r_q = sim3.run(QCR3(order=3, alpha=15, betas=[1, 2]), plant3, x0=[1, 0.5, 0])
        tv_n = np.sum(np.abs(np.diff(r_n['u'][:, 0])))
        tv_q = np.sum(np.abs(np.diff(r_q['u'][:, 0])))
        assert tv_q < tv_n, f"QC TV={tv_q:.0f} should be < Nested TV={tv_n:.0f}"
