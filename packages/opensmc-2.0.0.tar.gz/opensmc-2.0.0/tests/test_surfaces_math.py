"""Thorough mathematical validation of all 11 surfaces.

Each test cross-checks the Python opensmc class against the analytical
formulas from the source notebooks and published references.
"""

import numpy as np
import pytest


class TestLinearSurface:
    """s = edot + c*e (Liu 2017, Ch 1)."""

    def test_formula_basic(self):
        from opensmc.surfaces import LinearSurface
        s = LinearSurface(c=10.0)
        assert abs(s.compute(1.0, 0.0) - 10.0) < 1e-12
        assert abs(s.compute(0.0, 1.0) - 1.0) < 1e-12
        assert abs(s.compute(1.0, 1.0) - 11.0) < 1e-12
        assert abs(s.compute(-1.0, 5.0) - (-5.0)) < 1e-12

    def test_origin_is_zero(self):
        from opensmc.surfaces import LinearSurface
        s = LinearSurface(c=10.0)
        assert s.compute(0.0, 0.0) == 0.0

    def test_different_c(self):
        from opensmc.surfaces import LinearSurface
        for c in [1.0, 5.0, 20.0, 100.0]:
            s = LinearSurface(c=c)
            assert abs(s.compute(1.0, 0.0) - c) < 1e-12


class TestTerminalSurface:
    """s = edot + beta * |e|^(p/q) * sign(e) (Zak 1988)."""

    def test_formula(self):
        from opensmc.surfaces import TerminalSurface
        s = TerminalSurface(beta=1.0, p=5, q=7)
        # |1|^(5/7)*sign(1) = 1.0
        assert abs(s.compute(1.0, 0.0) - 1.0) < 1e-10
        # |-1|^(5/7)*sign(-1) = -1.0
        assert abs(s.compute(-1.0, 0.0) - (-1.0)) < 1e-10

    def test_origin(self):
        from opensmc.surfaces import TerminalSurface
        s = TerminalSurface(beta=2.0, p=5, q=7)
        assert abs(s.compute(0.0, 0.0)) < 1e-12

    def test_symmetry(self):
        from opensmc.surfaces import TerminalSurface
        s = TerminalSurface(beta=2.0, p=5, q=7)
        assert abs(s.compute(1.0, 0.0) + s.compute(-1.0, 0.0)) < 1e-10


class TestNonsingularTerminalSurface:
    """s = e + (1/beta) * |edot|^(q/p) * sign(edot)."""

    def test_no_singularity_at_e_zero(self):
        from opensmc.surfaces import NonsingularTerminalSurface
        s = NonsingularTerminalSurface(beta=2.0, p=5, q=7)
        # At e=0, edot=1: s = 0 + (1/2)*|1|^(7/5)*1 = 0.5
        val = s.compute(0.0, 1.0)
        expected = 0.5 * 1.0  # |1|^(7/5) = 1
        assert abs(val - expected) < 1e-10

    def test_origin(self):
        from opensmc.surfaces import NonsingularTerminalSurface
        s = NonsingularTerminalSurface(beta=2.0, p=5, q=7)
        assert abs(s.compute(0.0, 0.0)) < 1e-12


class TestFastTerminalSurface:
    """s = edot + alpha*e + beta*|e|^(q/p)*sign(e)."""

    def test_formula(self):
        from opensmc.surfaces import FastTerminalSurface
        s = FastTerminalSurface(alpha=5.0, beta=2.0, p=5, q=7)
        # At e=1, edot=0: s = 0 + 5*1 + 2*|1|^(7/5)*1 = 5 + 2 = 7
        assert abs(s.compute(1.0, 0.0) - 7.0) < 1e-10

    def test_rejects_beta_zero(self):
        from opensmc.surfaces import FastTerminalSurface
        import pytest
        # FastTerminalSurface correctly requires beta > 0
        with pytest.raises(ValueError, match="beta must be positive"):
            FastTerminalSurface(alpha=10.0, beta=0.0, p=5, q=7)

    def test_small_beta_approaches_linear(self):
        from opensmc.surfaces import FastTerminalSurface
        # With very small beta, the terminal term is negligible
        s = FastTerminalSurface(alpha=10.0, beta=1e-10, p=5, q=7)
        # At e=1, edot=0: s ≈ alpha*e = 10.0
        assert abs(s.compute(1.0, 0.0) - 10.0) < 1e-8


class TestIntegralTerminalSurface:
    """s = edot + c1*e + c2*integral(|e|^(p/q)*sign(e))."""

    def test_initial_no_integral(self):
        from opensmc.surfaces import IntegralTerminalSurface
        s = IntegralTerminalSurface(c1=5.0, c2=2.0, p=5, q=7, dt=1e-4)
        # First compute() call accumulates one dt worth of integral:
        # integral = |1|^(5/7)*sign(1)*dt = 1e-4
        # s = edot + c1*e + c2*integral = 0 + 5 + 2*1e-4 = 5.0002
        val = s.compute(1.0, 0.0)
        assert abs(val - 5.0) < 1e-3  # within dt-scale offset

    def test_reset_clears_integral(self):
        from opensmc.surfaces import IntegralTerminalSurface
        s = IntegralTerminalSurface(c1=5.0, c2=2.0, p=5, q=7, dt=1e-4)
        # Accumulate some integral
        for _ in range(100):
            s.compute(1.0, 0.0)
        val_before = s.compute(1.0, 0.0)
        s.reset()
        val_after = s.compute(1.0, 0.0)
        # After reset, first call still accumulates one dt of integral
        # s = 0 + 5*1 + 2*(1e-4) = 5.0002
        assert abs(val_after - 5.0) < 1e-3  # within dt-scale offset
        # The key check: val_after should be much closer to 5.0 than val_before
        assert abs(val_after - 5.0) < abs(val_before - 5.0)


class TestPIDSurface:
    """s = alpha*edot + beta*e + gamma*eint."""

    def test_degenerates_to_linear(self):
        from opensmc.surfaces import PIDSurface
        s = PIDSurface(alpha=1.0, beta=10.0, gamma=0.0, dt=1e-4)
        # With gamma=0, this is just edot + 10*e
        assert abs(s.compute(1.0, 0.0) - 10.0) < 1e-10

    def test_integral_accumulates(self):
        from opensmc.surfaces import PIDSurface
        # PIDSurface requires alpha > 0, so use small alpha
        s = PIDSurface(alpha=0.01, beta=0.01, gamma=1.0, dt=0.1)
        # s = alpha*edot + beta*e + gamma*eint
        # With e=1, edot=0: each call adds e*dt=0.1 to integral
        s.compute(1.0, 0.0)  # first call: eint = 0.1
        val = s.compute(1.0, 0.0)  # second call: eint = 0.2
        # val = 0.01*0 + 0.01*1 + 1.0*0.2 = 0.21
        assert val > 0  # integral should be positive for positive e


class TestGlobalSurface:
    """s(0) = 0 via exponential correction (Bartoszewicz 1998)."""

    def test_s_zero_at_t_zero(self):
        from opensmc.surfaces import GlobalSurface
        s = GlobalSurface(c=10.0, alpha=5.0)
        # At t=0, GlobalSurface should give s(0) = 0 regardless of e, edot
        # The correction term should cancel the initial s_linear
        val = s.compute(2.0, 1.0, t=0.0)
        # s = edot + c*e - (edot0 + c*e0)*exp(-alpha*t)
        # At t=0: s = edot + c*e - (edot + c*e) = 0
        assert abs(val) < 1e-10

    def test_approaches_linear_for_large_t(self):
        from opensmc.surfaces import GlobalSurface
        s = GlobalSurface(c=10.0, alpha=5.0)
        # First call at t=0 sets the initial values
        s.compute(2.0, 1.0, t=0.0)
        # At large t, exp(-alpha*t) -> 0, so s -> edot + c*e (linear)
        val = s.compute(1.0, 0.5, t=100.0)
        linear = 0.5 + 10.0 * 1.0  # edot + c*e
        assert abs(val - linear) < 0.01


class TestHierarchicalSurface:
    """S = s_act + lambda * s_unact."""

    def test_two_subsystems(self):
        from opensmc.surfaces import HierarchicalSurface
        s = HierarchicalSurface(c1=5.0, c2=8.0, lam=2.0)
        # s1 = edot + c1*e, s2 = edot_u + c2*e_u
        val = s.compute(1.0, 0.0, e_u=0.5, edot_u=0.1)
        s_act = 0.0 + 5.0 * 1.0  # = 5.0
        s_unact = 0.1 + 8.0 * 0.5  # = 4.1
        expected = s_act + 2.0 * s_unact  # = 5 + 8.2 = 13.2
        assert abs(val - expected) < 1e-10


class TestPredefinedTimeSurface:
    """Convergence before user-set Tc (Sanchez-Torres 2018)."""

    def test_gain_increases_before_Tc(self):
        from opensmc.surfaces import PredefinedTimeSurface
        s = PredefinedTimeSurface(Tc=2.0)
        g1 = s.gain(0.0)
        g2 = s.gain(1.0)
        g3 = s.gain(1.9)
        # Gain should increase as t approaches Tc
        assert g2 > g1
        assert g3 > g2

    def test_reverts_to_linear_after_Tc(self):
        from opensmc.surfaces import PredefinedTimeSurface
        s = PredefinedTimeSurface(Tc=2.0, c_inf=10.0)
        # After Tc, should behave like linear surface
        val = s.compute(1.0, 0.0, t=5.0)
        # Post-Tc: s = edot + c_inf * e = 0 + 10*1 = 10
        assert abs(val - 10.0) < 1.0  # allow some tolerance


class TestNonlinearDampingSurface:
    """s = edot + (c + Psi(y))*e (Bandyopadhyay 2009)."""

    def test_degenerates_to_linear_when_psi_zero(self):
        from opensmc.surfaces import NonlinearDampingSurface
        # With large k_tilde, Psi(y) ~ 0 for y far from 0
        # Psi(y) = -beta * exp(-k_tilde * y^2)
        # At large y with large k_tilde, Psi -> 0, so s -> edot + c*e
        s = NonlinearDampingSurface(c=10.0, beta=5.0, psi_type='gaussian', k_tilde=1e10)
        val = s.compute(1.0, 0.0, y=100.0)
        # Psi(100) = -5*exp(-1e10*10000) ≈ 0, so s ≈ 0 + 10*1 = 10
        assert abs(val - 10.0) < 1e-6


# ── Cross-validation: compare with notebook computed values ───────

class TestCrossValidation:
    """Compare opensmc values against known-good notebook outputs."""

    def test_linear_matches_notebook_01(self):
        """Notebook 01: s = edot + c*e with c=10, e=-2, edot=0 -> s = -20."""
        from opensmc.surfaces import LinearSurface
        s = LinearSurface(c=10.0)
        assert abs(s.compute(-2.0, 0.0) - (-20.0)) < 1e-12

    def test_itsmc_surface_matches_notebook_24(self):
        """Notebook 24: s = edot + c1*e + c2*E. First call has E = one dt of integral."""
        from opensmc.surfaces import IntegralTerminalSurface
        s = IntegralTerminalSurface(c1=5.0, c2=2.0, p=5, q=7, dt=1e-4)
        # First call accumulates one dt: E = |1|^(5/7)*1*1e-4 = 1e-4
        # s = 0 + 5*1 + 2*1e-4 = 5.0002
        val = s.compute(1.0, 0.0)
        assert abs(val - 5.0) < 1e-3  # within dt-scale offset

    def test_nftsmc_surface_matches_notebook_25(self):
        """Notebook 25: s = edot + alpha*e + beta*|e|^gamma*sign(e)."""
        from opensmc.surfaces import FastTerminalSurface
        # NFTSMC uses FastTerminal-like surface with gamma > 1
        s = FastTerminalSurface(alpha=5.0, beta=2.0, p=5, q=7)
        # e=1, edot=0: s = 0 + 5 + 2*1 = 7
        assert abs(s.compute(1.0, 0.0) - 7.0) < 1e-10
        # e=0, edot=0: s = 0
        assert abs(s.compute(0.0, 0.0)) < 1e-12
        # Symmetry: s(e) = -s(-e) when edot=0
        assert abs(s.compute(1.0, 0.0) + s.compute(-1.0, 0.0)) < 1e-10
