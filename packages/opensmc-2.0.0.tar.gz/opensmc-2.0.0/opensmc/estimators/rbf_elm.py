"""RBF-ELM Estimator (Huang 2006, Liang 2006 OS-ELM).

Radial Basis Function network with Online Sequential Extreme Learning
Machine (OS-ELM) update rule for real-time disturbance estimation.

Architecture:
    Input x --> Gaussian RBF hidden layer (L neurons) --> Linear output --> d_hat

RBF activation:
    h_j(x) = exp(-||x - c_j||^2 / (2 * w_j^2)),   j = 1, ..., L

Output:
    d_hat = W_out^T * h(x)

Online update (Woodbury identity):
    Ph    = P * h
    denom = 1 + h^T * P * h
    P     = P - (Ph * Ph^T) / denom
    e     = target - h^T * W_out
    W_out = W_out + P * h * e

Center placement: Latin Hypercube Sampling (LHS).
Width computation: mean of k nearest neighbor distances.

References
----------
Huang, G.-B., Zhu, Q.-Y., & Siew, C.-K. (2006). Extreme Learning Machine:
    Theory and Applications. Neurocomputing, 70(1-3), 489-501.
Liang, N.-Y., Huang, G.-B., et al. (2006). A fast and accurate online
    sequential learning algorithm for feedforward networks. IEEE Trans.
    Neural Netw., 17(6), 1411-1423.
"""

import numpy as np
from opensmc.core import Estimator


class RBF_ELM(Estimator):
    """RBF network with OS-ELM online learning for disturbance estimation.

    Parameters
    ----------
    n_input : int
        Input dimension (default 2).
    n_hidden : int
        Number of RBF hidden neurons / centers (default 50).
    x_min : array-like
        Lower bounds for center placement domain (default [-3, -5]).
    x_max : array-like
        Upper bounds for center placement domain (default [3, 5]).
    lam : float
        Regularization parameter for initial P matrix:
        P_0 = I / lam (default 1e-4).
    k_nn : int
        Number of nearest neighbors for width computation (default 3).
    seed : int or None
        Random seed for reproducible center placement (default None).
    dt : float
        Not used directly (kept for interface consistency). Default 1e-3.
    """

    def __init__(self, n_input=2, n_hidden=50, x_min=None, x_max=None,
                 lam=1e-4, k_nn=3, seed=None, dt=1e-3):
        self.n_input = n_input
        self.n_hidden = n_hidden
        self.lam = lam
        self.k_nn = k_nn
        self.dt = dt

        if x_min is None:
            x_min = -np.ones(n_input) * 3.0
        if x_max is None:
            x_max = np.ones(n_input) * 3.0

        self.x_min = np.asarray(x_min, dtype=float)
        self.x_max = np.asarray(x_max, dtype=float)

        if len(self.x_min) != n_input or len(self.x_max) != n_input:
            raise ValueError(
                f"x_min/x_max length must match n_input={n_input}"
            )

        # Initialize random state
        self._rng = np.random.RandomState(seed)

        # Place centers via Latin Hypercube Sampling
        self.centers = self._lhs_centers()

        # Compute widths via mean of k nearest neighbor distances
        self.widths = self._compute_widths()

        # Output weights: W_out (n_hidden,)
        self.W_out = np.zeros(n_hidden)

        # Inverse correlation matrix: P (n_hidden x n_hidden)
        self.P = np.eye(n_hidden) / lam

    def _lhs_centers(self):
        """Latin Hypercube Sampling for center placement."""
        centers = np.zeros((self.n_hidden, self.n_input))
        for d in range(self.n_input):
            perm = self._rng.permutation(self.n_hidden)
            for i in range(self.n_hidden):
                centers[i, d] = (perm[i] + self._rng.rand()) / self.n_hidden
            # Scale to [x_min, x_max]
            centers[:, d] = (self.x_min[d]
                             + centers[:, d] * (self.x_max[d] - self.x_min[d]))
        return centers

    def _compute_widths(self):
        """Compute RBF widths as mean of k nearest neighbor distances."""
        # Pairwise squared distances
        diff = self.centers[:, np.newaxis, :] - self.centers[np.newaxis, :, :]
        D = np.sqrt(np.sum(diff**2, axis=2))  # (L, L)

        widths = np.zeros(self.n_hidden)
        for j in range(self.n_hidden):
            dists = np.sort(D[j])
            # Skip index 0 (distance to self = 0), take next k_nn
            k_dists = dists[1:self.k_nn + 1]
            widths[j] = np.mean(k_dists)

        # Safety: ensure no zero widths
        widths = np.maximum(widths, 1e-6)
        return widths

    def _rbf_activation(self, x):
        """Compute RBF hidden layer output h(x).

        h_j(x) = exp(-||x - c_j||^2 / (2 * w_j^2))

        Parameters
        ----------
        x : ndarray (n_input,)
            Input vector.

        Returns
        -------
        h : ndarray (n_hidden,)
            Hidden layer activations.
        """
        x = np.asarray(x, dtype=float)
        diff = x - self.centers  # (n_hidden, n_input)
        sq_dists = np.sum(diff**2, axis=1)  # (n_hidden,)
        h = np.exp(-sq_dists / (2.0 * self.widths**2))
        return h

    def forward(self, x):
        """Forward pass: d_hat = W_out^T * h(x).

        Parameters
        ----------
        x : ndarray (n_input,)
            Input feature vector.

        Returns
        -------
        d_hat : float
            Network output (disturbance estimate).
        """
        h = self._rbf_activation(x)
        return float(np.dot(self.W_out, h))

    def online_update(self, x, target):
        """OS-ELM update via Woodbury identity (Liang 2006).

        Parameters
        ----------
        x : ndarray (n_input,)
            Input feature vector.
        target : float
            Target value (reconstructed disturbance).

        Returns
        -------
        d_hat : float
            Prediction BEFORE the weight update.
        """
        h = self._rbf_activation(x)        # (L,)
        d_hat = float(np.dot(self.W_out, h))  # prediction before update

        # Woodbury update
        Ph = self.P @ h                     # (L,)
        denom = 1.0 + h @ Ph                # scalar
        self.P = self.P - np.outer(Ph, Ph) / denom

        e = target - d_hat                  # prediction error
        self.W_out = self.W_out + self.P @ h * e

        return d_hat

    def estimate(self, t, x, u, y=None, **kwargs):
        """Compute disturbance estimate from state features.

        Uses the RBF-ELM network to estimate d_hat from the plant
        state x (used as input features). If a target is provided
        via kwargs, an online update is performed.

        Parameters
        ----------
        t : float
            Current time.
        x : ndarray
            Plant state (used as input features for the network).
        u : float or ndarray
            Control input (not used directly by the network).
        y : float or None
            Measured output (not used directly).
        **kwargs :
            target : float, optional — if provided, perform an online
                update with this target value after computing the estimate.

        Returns
        -------
        dhat : float
            Estimated disturbance.
        """
        x_feat = np.asarray(x, dtype=float).ravel()

        # If the input dimension doesn't match, try to use the first
        # n_input elements
        if len(x_feat) > self.n_input:
            x_feat = x_feat[:self.n_input]

        target = kwargs.get('target', None)
        if target is not None:
            dhat = self.online_update(x_feat, float(target))
        else:
            dhat = self.forward(x_feat)

        return dhat

    def reset(self):
        """Reset output weights and P matrix (keep centers and widths)."""
        self.W_out = np.zeros(self.n_hidden)
        self.P = np.eye(self.n_hidden) / self.lam
