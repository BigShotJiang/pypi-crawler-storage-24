"""High-Gain Observer (Khalil 2015, Liu & Wang 2012 Ch 8.1-8.2).

Recovers full state (position and velocity) from output-only measurement.

Plant (2nd order):
    x1_dot = x2
    x2_dot = f(x, u)  (nonlinear dynamics)

Only y = x1 is measured.

HGO:
    x_hat1_dot = x_hat2 - (alpha2 / eps) * (x_hat1 - y)
    x_hat2_dot = -(alpha1 / eps^2) * (x_hat1 - y)

With default alpha1=9, alpha2=6, the observer error polynomial is
s^2 + 6s + 9 = (s+3)^2, ensuring stable estimation.

The HGO estimates state only (x_hat1 ~ x1, x_hat2 ~ x2).
It does NOT estimate disturbance (dhat = 0). Use ESO or DOB if
disturbance estimation is needed.

References
----------
Khalil, H. K. (2015). Nonlinear Control, Pearson.
Liu, J. & Wang, X. (2012). Advanced Sliding Mode Control for Mechanical
    Systems, Ch 8.1-8.2, Springer.
"""

import numpy as np
from opensmc.core import Estimator


class HighGainObserver(Estimator):
    """High-Gain Observer for velocity recovery from position measurement.

    Parameters
    ----------
    alpha1 : float
        Observer gain 1 (default 9.0).
    alpha2 : float
        Observer gain 2 (default 6.0).
    epsilon : float
        Bandwidth parameter; smaller => faster convergence but more
        peaking (default 0.01).
    dt : float
        Integration time step for Euler update (default 1e-4).
    """

    def __init__(self, alpha1=9.0, alpha2=6.0, epsilon=0.01, dt=1e-4):
        self.alpha1 = alpha1
        self.alpha2 = alpha2
        self.epsilon = epsilon
        self.dt = dt

        # Internal state: [x_hat1, x_hat2]
        self._z = np.zeros(2)

    def _dynamics(self, z, y, eps):
        """Compute dz/dt for the HGO.

        Parameters
        ----------
        z : ndarray (2,)
            Observer state [x_hat1, x_hat2].
        y : float
            Measured output (x1).
        eps : float
            Current bandwidth parameter.

        Returns
        -------
        zdot : ndarray (2,)
        """
        x_hat1, x_hat2 = z
        e1 = x_hat1 - y
        x_hat1_dot = x_hat2 - (self.alpha2 / eps) * e1
        x_hat2_dot = -(self.alpha1 / eps**2) * e1
        return np.array([x_hat1_dot, x_hat2_dot])

    def estimate(self, t, x, u, y=None, **kwargs):
        """Compute state estimate and advance one Euler step.

        The HGO recovers velocity from position-only measurement.
        It returns x_hat2 (estimated velocity) as the estimate, since
        the primary purpose is to provide unmeasured state information.
        For disturbance estimation, use ESO or DOB instead.

        Parameters
        ----------
        t : float
            Current time.
        x : ndarray
            Plant state (used for output measurement if y is None).
        u : float or ndarray
            Control input (not used in HGO dynamics, kept for interface).
        y : float or None
            Measured output. If None, x[0] is used.
        **kwargs :
            dt : float, optional — override the default time step.
            epsilon : float, optional — override bandwidth parameter.

        Returns
        -------
        x_hat2 : float
            Estimated velocity (second state).
        """
        dt = kwargs.get('dt', self.dt)
        eps = kwargs.get('epsilon', self.epsilon)

        if y is None:
            y_meas = float(x[0]) if hasattr(x, '__len__') else float(x)
        else:
            y_meas = float(y)

        # Current estimate (before update)
        x_hat2 = float(self._z[1])

        # Euler integration
        zdot = self._dynamics(self._z, y_meas, eps)
        self._z = self._z + dt * zdot

        return x_hat2

    @property
    def state_estimates(self):
        """Return current state estimates [x_hat1, x_hat2]."""
        return self._z.copy()

    def reset(self):
        """Reset observer state to zero."""
        self._z = np.zeros(2)
