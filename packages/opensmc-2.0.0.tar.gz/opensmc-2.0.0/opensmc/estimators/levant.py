"""Levant Differentiator (Levant 2003, IJC).

Arbitrary-order robust exact differentiator with finite-time convergence.

Given a measured signal f(t) with bounded (n+1)-th derivative |f^{(n+1)}| <= L,
the differentiator uses n+1 states z_0, ..., z_n such that z_k -> f^{(k)}
in **finite time**.

Recursive dynamics:
    z_k_dot = -lambda_{n-k} * L^{1/(n-k+1)} * |z_k - phi_k|^{(n-k)/(n-k+1)}
              * sign(z_k - phi_k) + z_{k+1},    for k = 0, ..., n-1

    z_n_dot = -lambda_0 * L * sign(z_n - phi_n)

where phi_0 = f(t) and phi_k = z_k_dot for k > 0 (cascaded structure).

Default gains (Levant 2003, Table 1):
    Order 1: [1.5, 1.1]
    Order 2: [2.0, 1.5, 1.1]
    Order 3: [3.0, 2.0, 1.5, 1.1]
    Order 4: [5.0, 3.0, 2.0, 1.5, 1.1]

Key property: **finite-time exact convergence**, unlike HGO or ICD which
converge only asymptotically.

Reference
---------
Levant, A. (2003). Higher-order sliding modes, differentiation and
    output-feedback control. International Journal of Control,
    76(9-10), 924-941.
"""

import numpy as np
from opensmc.core import Estimator


# Default optimal lambdas from Levant (2003), Table 1
_DEFAULT_LAMBDAS = {
    1: [1.5, 1.1],
    2: [2.0, 1.5, 1.1],
    3: [3.0, 2.0, 1.5, 1.1],
    4: [5.0, 3.0, 2.0, 1.5, 1.1],
}


class LevantDifferentiator(Estimator):
    """Arbitrary-order robust exact differentiator (Levant 2003).

    For order n, maintains n+1 states z[0]..z[n] such that
    z[k] -> f^{(k)} in finite time.

    Parameters
    ----------
    order : int
        Differentiation order (number of derivatives to estimate).
        Default 1.
    L : float
        Lipschitz constant bound on |f^{(n+1)}|. Default 10.0.
    lambdas : list or ndarray or None
        Gain vector of length n+1. If None, uses Levant 2003 Table 1
        defaults (or linearly spaced gains for orders > 4).
    dt : float
        Integration time step for Euler update (default 1e-4).
    """

    def __init__(self, order=1, L=10.0, lambdas=None, dt=1e-4):
        self.order = order
        self.L = L
        self.dt = dt
        n = order

        if lambdas is not None:
            self.lambdas = np.asarray(lambdas, dtype=float)
        elif n in _DEFAULT_LAMBDAS:
            self.lambdas = np.array(_DEFAULT_LAMBDAS[n], dtype=float)
        else:
            self.lambdas = np.linspace(n + 1, 1.1, n + 1)

        if len(self.lambdas) != n + 1:
            raise ValueError(
                f"lambdas length {len(self.lambdas)} != order+1 = {n + 1}"
            )

        # Internal state: z[0..n]
        self._z = np.zeros(n + 1)

    def _step_euler(self, f, dt_step):
        """Advance one Euler step given measured signal f.

        Parameters
        ----------
        f : float
            Current measurement of the signal.
        dt_step : float
            Time step.
        """
        n = self.order
        L = self.L
        lam = self.lambdas
        z = self._z

        zdot = np.zeros(n + 1)
        sigma = z[0] - f  # phi_0 = f

        for k in range(n + 1):
            if k < n:
                alpha_k = (n - k) / (n - k + 1)
                zdot[k] = (-lam[k] * L ** (1.0 / (n - k + 1))
                           * np.abs(sigma) ** alpha_k * np.sign(sigma)
                           + z[k + 1])
            else:
                # Last stage: pure sign correction
                zdot[k] = -lam[k] * L * np.sign(sigma)

            # sigma for next stage: z[k+1] - zdot[k]
            if k < n:
                sigma = z[k + 1] - zdot[k]

        self._z = z + dt_step * zdot

    def estimate(self, t, x, u, y=None, **kwargs):
        """Compute derivative estimates and advance one Euler step.

        Returns the last state (highest derivative estimate).

        Parameters
        ----------
        t : float
            Current time.
        x : ndarray or float
            Plant state (used for signal measurement if y is None).
        u : float or ndarray
            Control input (not used by the differentiator, kept for
            interface compatibility).
        y : float or None
            Measured signal. If None, x[0] is used.
        **kwargs :
            dt : float, optional — override the default time step.

        Returns
        -------
        dhat : float or ndarray
            Highest derivative estimate (z[n]). If order == 1, returns
            scalar. For higher orders, still returns the highest-order
            derivative as a scalar.
        """
        dt = kwargs.get('dt', self.dt)

        if y is None:
            if hasattr(x, '__len__'):
                f = float(x[0])
            else:
                f = float(x)
        else:
            f = float(y)

        # Current estimate (before update)
        dhat = float(self._z[-1])

        # Euler integration
        self._step_euler(f, dt)

        return dhat

    @property
    def derivatives(self):
        """Return all current derivative estimates [f, f', f'', ...]."""
        return self._z.copy()

    def reset(self):
        """Reset differentiator state to zero."""
        self._z = np.zeros(self.order + 1)
