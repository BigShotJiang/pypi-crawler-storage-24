"""Extended State Observer (Han 2009, Liu & Wang 2012 Ch 8.3-8.4).

Estimates both unmeasured states and the lumped uncertainty (total
disturbance) from output measurements alone.

Plant (2nd order):
    x1_dot = x2
    x2_dot = f(x) + b*u + d(t)

Lumped uncertainty: sigma = f(x) + d(t), treated as an extended state.

ESO formulation:
    x_hat1_dot = x_hat2 + (alpha1 / eps) * (y - x_hat1)
    x_hat2_dot = b*u + sigma_hat + (alpha2 / eps^2) * (y - x_hat1)
    sigma_hat_dot = (alpha3 / eps^3) * (y - x_hat1)

Default gains alpha1=6, alpha2=11, alpha3=6 correspond to the Hurwitz
polynomial (s+1)(s+2)(s+3).

References
----------
Han, J. (2009). From PID to Active Disturbance Rejection Control.
    IEEE Trans. Industrial Electronics, 56(3), 900-906.
Liu, J. & Wang, X. (2012). Advanced Sliding Mode Control for Mechanical
    Systems, Ch 8.3-8.4, Springer.
"""

import numpy as np
from opensmc.core import Estimator


class ExtendedStateObserver(Estimator):
    """Extended State Observer for 2nd-order systems.

    Parameters
    ----------
    alpha1 : float
        Observer gain 1 (default 6.0).
    alpha2 : float
        Observer gain 2 (default 11.0).
    alpha3 : float
        Observer gain 3 (default 6.0).
    epsilon : float
        Bandwidth parameter; smaller => faster but more peaking (default 0.01).
    b_input : float
        Input gain of the plant (default 1.0).
    dt : float
        Integration time step for Euler update (default 1e-4).
    """

    def __init__(self, alpha1=6.0, alpha2=11.0, alpha3=6.0,
                 epsilon=0.01, b_input=1.0, dt=1e-4):
        self.alpha1 = alpha1
        self.alpha2 = alpha2
        self.alpha3 = alpha3
        self.epsilon = epsilon
        self.b_input = b_input
        self.dt = dt

        # Internal state: [x_hat1, x_hat2, sigma_hat]
        self._z = np.zeros(3)

    def _dynamics(self, z, y, u, eps):
        """Compute dz/dt for the ESO.

        Parameters
        ----------
        z : ndarray (3,)
            Observer state [x_hat1, x_hat2, sigma_hat].
        y : float
            Measured output (x1).
        u : float
            Control input.
        eps : float
            Current bandwidth parameter.

        Returns
        -------
        zdot : ndarray (3,)
        """
        x_hat1, x_hat2, sigma_hat = z
        e_obs = y - x_hat1  # output estimation error

        x_hat1_dot = x_hat2 + (self.alpha1 / eps) * e_obs
        x_hat2_dot = (self.b_input * u + sigma_hat
                      + (self.alpha2 / eps**2) * e_obs)
        sigma_hat_dot = (self.alpha3 / eps**3) * e_obs

        return np.array([x_hat1_dot, x_hat2_dot, sigma_hat_dot])

    def estimate(self, t, x, u, y=None, **kwargs):
        """Compute lumped uncertainty estimate and advance one Euler step.

        Parameters
        ----------
        t : float
            Current time.
        x : ndarray
            Plant state (used for output measurement if y is None).
        u : float or ndarray
            Control input (scalar).
        y : float or None
            Measured output. If None, x[0] is used.
        **kwargs :
            dt : float, optional — override the default time step.
            epsilon : float, optional — override bandwidth parameter.

        Returns
        -------
        dhat : float
            Estimated lumped uncertainty (sigma_hat = f(x) + d).
        """
        dt = kwargs.get('dt', self.dt)
        eps = kwargs.get('epsilon', self.epsilon)

        if y is None:
            y_meas = float(x[0]) if hasattr(x, '__len__') else float(x)
        else:
            y_meas = float(y)

        u_val = float(u) if hasattr(u, '__len__') else float(u)

        # Current estimate (before update)
        dhat = float(self._z[2])

        # Euler integration
        zdot = self._dynamics(self._z, y_meas, u_val, eps)
        self._z = self._z + dt * zdot

        return dhat

    @property
    def state_estimates(self):
        """Return current state estimates [x_hat1, x_hat2, sigma_hat]."""
        return self._z.copy()

    def reset(self):
        """Reset observer state to zero."""
        self._z = np.zeros(3)
