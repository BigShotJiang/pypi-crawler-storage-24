"""Disturbance Observer (Liu & Wang 2012, Ch 8.7-8.8).

Estimates a slowly varying disturbance d(t) entering a 2nd-order plant:

    J * x2_dot = u + d - b * x2

Observer states z = [d_hat, omega_hat]:

    d_hat_dot     = -k1 * (omega_hat - x2)
    omega_hat_dot =  a * d_hat + a * u - k2 * (omega_hat - x2) - b_obs * x2

where a = 1/J, b_obs = b/J.

Error dynamics:
    [e_w; e_d]' = [[-k2, a]; [-k1, 0]] * [e_w; e_d]

Eigenvalues: lambda^2 + k2*lambda + a*k1 = 0.

Reference
---------
Liu, J. & Wang, X. (2012). Advanced Sliding Mode Control for Mechanical
    Systems, Ch 8.7-8.8, Springer.
"""

import numpy as np
from opensmc.core import Estimator


class DisturbanceObserver(Estimator):
    """Disturbance observer for 2nd-order mechanical systems.

    Parameters
    ----------
    J : float
        Inertia (default 2.0).
    b : float
        Damping coefficient (default 0.15).
    k1 : float
        Disturbance estimation gain (default 5000.0).
    k2 : float
        Velocity estimation gain (default 200.0).
    dt : float
        Integration time step for Euler update (default 1e-4).
    """

    def __init__(self, J=2.0, b=0.15, k1=5000.0, k2=200.0, dt=1e-4):
        self.J = J
        self.b = b
        self.k1 = k1
        self.k2 = k2
        self.dt = dt

        # Derived parameters
        self.a = 1.0 / J       # input gain
        self.b_obs = b / J     # damping ratio

        # Internal state: [d_hat, omega_hat]
        self._z = np.zeros(2)

    def _dynamics(self, z, u, x2):
        """Compute dz/dt for the observer.

        Parameters
        ----------
        z : ndarray (2,)
            Observer state [d_hat, omega_hat].
        u : float
            Control input.
        x2 : float
            Measured velocity (second state of the plant).

        Returns
        -------
        zdot : ndarray (2,)
        """
        d_hat, omega_hat = z
        err = omega_hat - x2
        d_hat_dot = -self.k1 * err
        omega_hat_dot = (self.a * d_hat + self.a * u
                         - self.k2 * err - self.b_obs * x2)
        return np.array([d_hat_dot, omega_hat_dot])

    def estimate(self, t, x, u, y=None, **kwargs):
        """Compute disturbance estimate and advance one Euler step.

        Parameters
        ----------
        t : float
            Current time.
        x : ndarray
            Plant state; x[1] is used as the velocity measurement.
        u : float or ndarray
            Control input (scalar).
        y : ignored
        **kwargs :
            dt : float, optional — override the default time step.

        Returns
        -------
        dhat : float
            Estimated disturbance.
        """
        dt = kwargs.get('dt', self.dt)
        x2 = float(x[1]) if hasattr(x, '__len__') else float(x)
        u_val = float(u) if hasattr(u, '__len__') else float(u)

        # Current estimate (before update)
        dhat = float(self._z[0])

        # Euler integration
        zdot = self._dynamics(self._z, u_val, x2)
        self._z = self._z + dt * zdot

        return dhat

    def reset(self):
        """Reset observer state to zero."""
        self._z = np.zeros(2)
