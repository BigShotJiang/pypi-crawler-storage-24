"""Integral Chain Differentiator (Liu & Wang 2012, Ch 8.5-8.6).

A high-gain observer that estimates derivatives of a measured signal y(t)
without requiring a plant model. For order n (estimating up to the n-th
derivative), the observer has n+1 states.

For n=2, the equations are:

    x_hat1_dot = x_hat2
    x_hat2_dot = x_hat3
    x_hat3_dot = -(a1/eps^3)*(x_hat1 - y) - (a2/eps^2)*x_hat2 - (a3/eps)*x_hat3

As eps -> 0:
    x_hat1 -> y        (signal tracking)
    x_hat2 -> y_dot    (1st derivative)
    x_hat3 -> y_ddot   (2nd derivative / lumped uncertainty)

Default Hurwitz coefficients: [1, 3, 3] for (s+1)^3.

General n-th order structure (n+1 states, n+1 Hurwitz coefficients):
    x_hat_i_dot = x_hat_{i+1}     for i = 1..n
    x_hat_{n+1}_dot = -sum_{j=1}^{n+1} (a_j / eps^{n+1-j+1}) * phi_j

    where phi_1 = (x_hat_1 - y), phi_j = x_hat_j for j >= 2.

Reference
---------
Liu, J. & Wang, X. (2012). Advanced Sliding Mode Control for Mechanical
    Systems, Ch 8.5-8.6, Springer.
"""

import numpy as np
from opensmc.core import Estimator


class IntegralChainDifferentiator(Estimator):
    """Integral Chain Differentiator for arbitrary-order derivative estimation.

    Parameters
    ----------
    order : int
        Differentiation order (number of derivatives to estimate).
        The observer will have order+1 states (default 2).
    a_coeffs : list or ndarray or None
        Hurwitz coefficients [a1, a2, ..., a_{n+1}].
        If None, uses coefficients of (s+1)^{n+1} (default).
    epsilon : float
        Bandwidth parameter; smaller => more accurate but more peaking
        (default 0.005).
    dt : float
        Integration time step for Euler update (default 1e-4).
    """

    def __init__(self, order=2, a_coeffs=None, epsilon=0.005, dt=1e-4):
        self.order = order
        self.epsilon = epsilon
        self.dt = dt

        n_states = order + 1

        if a_coeffs is not None:
            self.a_coeffs = np.asarray(a_coeffs, dtype=float)
        else:
            # Coefficients of (s+1)^{n+1} (binomial coefficients, reversed)
            self.a_coeffs = np.array(
                [float(_binom(n_states, k)) for k in range(n_states)],
                dtype=float
            )

        if len(self.a_coeffs) != n_states:
            raise ValueError(
                f"a_coeffs length {len(self.a_coeffs)} != order+1 = {n_states}"
            )

        # Internal state
        self._z = np.zeros(n_states)

    def _dynamics(self, z, y, eps):
        """Compute dz/dt for the ICD.

        Parameters
        ----------
        z : ndarray (n+1,)
            Observer state vector.
        y : float
            Measured signal.
        eps : float
            Current bandwidth parameter.

        Returns
        -------
        zdot : ndarray (n+1,)
        """
        n_states = len(z)
        zdot = np.zeros(n_states)

        # Chain: z_i_dot = z_{i+1} for i = 0..n-1
        for i in range(n_states - 1):
            zdot[i] = z[i + 1]

        # Last state: correction term
        correction = 0.0
        for j in range(n_states):
            power = n_states - j  # eps^(n+1-j) for 0-indexed j
            if j == 0:
                correction += (self.a_coeffs[j] / eps**power) * (z[0] - y)
            else:
                correction += (self.a_coeffs[j] / eps**power) * z[j]

        zdot[n_states - 1] = -correction

        return zdot

    def estimate(self, t, x, u, y=None, **kwargs):
        """Compute derivative estimates and advance one Euler step.

        Returns the last state (highest derivative estimate), which
        corresponds to the lumped uncertainty estimate in a 2nd-order
        plant context.

        Parameters
        ----------
        t : float
            Current time.
        x : ndarray or float
            Plant state (used for signal measurement if y is None).
        u : float or ndarray
            Control input (not used by the ICD, kept for interface).
        y : float or None
            Measured signal. If None, x[0] is used.
        **kwargs :
            dt : float, optional — override the default time step.
            epsilon : float, optional — override bandwidth parameter.

        Returns
        -------
        dhat : float
            Highest derivative estimate (last observer state).
        """
        dt = kwargs.get('dt', self.dt)
        eps = kwargs.get('epsilon', self.epsilon)

        if y is None:
            if hasattr(x, '__len__'):
                y_meas = float(x[0])
            else:
                y_meas = float(x)
        else:
            y_meas = float(y)

        # Current estimate (before update)
        dhat = float(self._z[-1])

        # Euler integration
        zdot = self._dynamics(self._z, y_meas, eps)
        self._z = self._z + dt * zdot

        return dhat

    @property
    def derivatives(self):
        """Return all current derivative estimates [y, y', y'', ...]."""
        return self._z.copy()

    def reset(self):
        """Reset observer state to zero."""
        self._z = np.zeros(self.order + 1)


def _binom(n, k):
    """Compute binomial coefficient C(n, k)."""
    if k < 0 or k > n:
        return 0
    if k == 0 or k == n:
        return 1
    # Use symmetry
    k = min(k, n - k)
    result = 1
    for i in range(k):
        result = result * (n - i) // (i + 1)
    return result
