"""OpenSMC — A modular sliding mode control toolbox for Python.

Usage
-----
>>> import opensmc
>>> from opensmc.surfaces import LinearSurface
>>> from opensmc.reaching import ConstantRate
>>> from opensmc.controllers import ClassicalSMC
>>> from opensmc.plants import DoubleIntegrator
>>> from opensmc.simulator import Simulator
>>> from opensmc import metrics
"""

__version__ = "2.0.0"
__author__ = "Ali Al Ghanimi"
__license__ = "MIT"

from . import core
from . import simulator
from . import metrics
from . import utils
