"""Quadrotor 6DOF plant (Newton-Euler formulation).

Reference
---------
Standard Newton-Euler rigid-body quadrotor dynamics as used in the
OpenSMC validation notebook #38.

Euler angle convention: ZYX (yaw-pitch-roll), with the rotation
matrix mapping from body frame to inertial (NED) frame.
"""

import numpy as np
from opensmc.core import Plant


class Quadrotor6DOF(Plant):
    """12-state rigid-body quadrotor with Newton-Euler dynamics.

    States: x = [x, y, z, phi, theta, psi, vx, vy, vz, p, q, r]
        - (x, y, z): inertial position
        - (phi, theta, psi): Euler angles (roll, pitch, yaw)
        - (vx, vy, vz): inertial velocity
        - (p, q, r): body angular rates

    Inputs: u = [U1, U2, U3, U4]
        - U1: total thrust [N]
        - U2: roll torque [N*m]
        - U3: pitch torque [N*m]
        - U4: yaw torque [N*m]

    Outputs: y = [x, y, z, phi, theta, psi]

    Translational dynamics
    ----------------------
    ax = (cos(phi)*sin(theta)*cos(psi) + sin(phi)*sin(psi)) * U1/m
    ay = (cos(phi)*sin(theta)*sin(psi) - sin(phi)*cos(psi)) * U1/m
    az = -g + cos(phi)*cos(theta) * U1/m

    Rotational dynamics (Euler equations)
    -------------------------------------
    pdot = ((Iyy - Izz)*q*r + U2) / Ixx
    qdot = ((Izz - Ixx)*p*r + U3) / Iyy
    rdot = ((Ixx - Iyy)*p*q + U4) / Izz

    Euler angle kinematics
    ----------------------
    phi_dot   = p + q*sin(phi)*tan(theta) + r*cos(phi)*tan(theta)
    theta_dot = q*cos(phi) - r*sin(phi)
    psi_dot   = (q*sin(phi) + r*cos(phi)) / cos(theta)

    Parameters
    ----------
    mass : float
        Total mass [kg] (default 0.468).
    g : float
        Gravitational acceleration [m/s^2] (default 9.81).
    Ixx : float
        Roll moment of inertia [kg*m^2] (default 4.856e-3).
    Iyy : float
        Pitch moment of inertia [kg*m^2] (default 4.856e-3).
    Izz : float
        Yaw moment of inertia [kg*m^2] (default 8.801e-3).
    arm_length : float
        Motor arm length [m] (default 0.225).
    """

    def __init__(self, mass=0.468, g=9.81, Ixx=4.856e-3, Iyy=4.856e-3,
                 Izz=8.801e-3, arm_length=0.225):
        super().__init__(n_states=12, n_inputs=4, n_outputs=6,
                         name="Quadrotor6DOF")
        self.mass = mass
        self.g = g
        self.Ixx = Ixx
        self.Iyy = Iyy
        self.Izz = Izz
        self.arm_length = arm_length

    def dynamics(self, t, x, u, d=None):
        """Compute state derivatives.

        Parameters
        ----------
        t : float
            Time.
        x : ndarray (12,)
            State vector.
        u : ndarray (4,)
            Inputs [U1, U2, U3, U4].
        d : ndarray (12,) or None
            Additive disturbance on state derivatives. Default 0.

        Returns
        -------
        xdot : ndarray (12,)
        """
        u = np.asarray(u, dtype=float).ravel()
        if d is None:
            d = np.zeros(12)
        else:
            d = np.asarray(d, dtype=float).ravel()

        # Unpack state
        phi, theta, psi = x[3], x[4], x[5]
        vx, vy, vz = x[6], x[7], x[8]
        p, q, r = x[9], x[10], x[11]

        # Unpack inputs
        U1, U2, U3, U4 = u[0], u[1], u[2], u[3]

        # Trig
        cphi = np.cos(phi);   sphi = np.sin(phi)
        cth  = np.cos(theta); sth  = np.sin(theta)
        cpsi = np.cos(psi);   spsi = np.sin(psi)
        tth  = np.tan(theta)

        mass = self.mass
        g = self.g
        Ixx, Iyy, Izz = self.Ixx, self.Iyy, self.Izz

        # Translational accelerations
        ax = (cphi * sth * cpsi + sphi * spsi) * U1 / mass
        ay = (cphi * sth * spsi - sphi * cpsi) * U1 / mass
        az = -g + cphi * cth * U1 / mass

        # Rotational dynamics (Euler equations)
        pdot = ((Iyy - Izz) * q * r + U2) / Ixx
        qdot = ((Izz - Ixx) * p * r + U3) / Iyy
        rdot = ((Ixx - Iyy) * p * q + U4) / Izz

        # Euler angle kinematics
        phi_dot = p + q * sphi * tth + r * cphi * tth
        theta_dot = q * cphi - r * sphi
        psi_dot = (q * sphi + r * cphi) / cth

        xdot = np.array([
            vx, vy, vz,
            phi_dot, theta_dot, psi_dot,
            ax, ay, az,
            pdot, qdot, rdot
        ])

        return xdot + d

    def output(self, x):
        """Output y = [x, y, z, phi, theta, psi]."""
        return x[:6]

    def get_default_x0(self):
        """Default: hover at origin with zero attitude and velocity."""
        return np.zeros(12)

    def hover_input(self):
        """Return the input that maintains hover equilibrium.

        Returns
        -------
        u_hover : ndarray (4,)
            [mass*g, 0, 0, 0]
        """
        return np.array([self.mass * self.g, 0.0, 0.0, 0.0])
