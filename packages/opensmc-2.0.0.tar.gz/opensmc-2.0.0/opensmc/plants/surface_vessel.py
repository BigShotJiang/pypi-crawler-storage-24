"""3-DOF Surface Vessel plant.

Reference
---------
Fossen, T.I. (2011). Handbook of Marine Craft Hydrodynamics and Motion
    Control. Wiley.

Body-fixed 3-DOF model: surge, sway, yaw with linear + quadratic damping.
"""

import numpy as np
from opensmc.core import Plant


class SurfaceVessel(Plant):
    """3-DOF marine surface vessel in body-fixed frame (Fossen 2011).

    States: x = [x_n, y_n, psi, u_b, v_b, r]
        - (x_n, y_n, psi): inertial (NED) position and heading [m, m, rad]
        - (u_b, v_b, r): body-fixed surge, sway, yaw rate [m/s, m/s, rad/s]

    Inputs: tau = [tau_u, tau_v, tau_r]
        - tau_u: surge force [N]
        - tau_v: sway force [N]
        - tau_r: yaw moment [N*m]

    Outputs: y = [x_n, y_n, psi]

    Dynamics
    --------
    Kinematics: eta_dot = R(psi) * nu
    Kinetics:   M * nu_dot = tau - C(nu)*nu - D(nu)*nu

    where R(psi) is the 2D rotation matrix, M is the rigid-body + added
    mass matrix, C is the Coriolis matrix, and D contains linear +
    quadratic damping.

    Parameters
    ----------
    m : float
        Vessel mass [kg] (default 23.8).
    Iz : float
        Yaw moment of inertia [kg*m^2] (default 1.76).
    xg : float
        CG offset from CO [m] (default 0.046).
    Xu : float
        Surge linear damping (default -0.72).
    Yv : float
        Sway linear damping (default -0.89).
    Nr : float
        Yaw linear damping (default -1.90).
    Xuu : float
        Surge quadratic damping (default -1.33).
    Yvv : float
        Sway quadratic damping (default -36.5).
    Nrr : float
        Yaw quadratic damping (default -0.75).
    Xudot : float
        Surge added mass (default -2.0).
    Yvdot : float
        Sway added mass (default -10.0).
    Nrdot : float
        Yaw added inertia (default -1.0).
    """

    def __init__(self, m=23.8, Iz=1.76, xg=0.046,
                 Xu=-0.72, Yv=-0.89, Nr=-1.90,
                 Xuu=-1.33, Yvv=-36.5, Nrr=-0.75,
                 Xudot=-2.0, Yvdot=-10.0, Nrdot=-1.0):
        super().__init__(n_states=6, n_inputs=3, n_outputs=3,
                         name="SurfaceVessel")
        self.m = m
        self.Iz = Iz
        self.xg = xg
        self.Xu = Xu
        self.Yv = Yv
        self.Nr = Nr
        self.Xuu = Xuu
        self.Yvv = Yvv
        self.Nrr = Nrr
        self.Xudot = Xudot
        self.Yvdot = Yvdot
        self.Nrdot = Nrdot

        # Mass matrix diagonal elements
        self.m11 = m - Xudot
        self.m22 = m - Yvdot
        self.m33 = Iz - Nrdot
        self.m23 = m * xg

    @staticmethod
    def rotation_matrix(psi):
        """2D rotation matrix R(psi): body -> NED.

        Parameters
        ----------
        psi : float
            Heading angle [rad].

        Returns
        -------
        R : ndarray (3, 3)
        """
        cp = np.cos(psi)
        sp = np.sin(psi)
        return np.array([
            [cp, -sp, 0.0],
            [sp,  cp, 0.0],
            [0.0, 0.0, 1.0]
        ])

    def dynamics(self, t, x, u, d=None):
        """Compute state derivatives.

        Parameters
        ----------
        t : float
            Time.
        x : ndarray (6,)
            State [x_n, y_n, psi, u_b, v_b, r].
        u : ndarray (3,)
            Inputs [tau_u, tau_v, tau_r].
        d : ndarray (3,) or None
            Additive disturbance forces/moment. Default 0.

        Returns
        -------
        xdot : ndarray (6,)
        """
        u_in = np.asarray(u, dtype=float).ravel()
        if d is None:
            d_vec = np.zeros(3)
        else:
            d_vec = np.asarray(d, dtype=float).ravel()

        tau = u_in + d_vec

        psi = x[2]
        ub  = x[3]
        vb  = x[4]
        r   = x[5]

        # Kinematics: eta_dot = R(psi) * nu
        R = self.rotation_matrix(psi)
        eta_dot = R @ np.array([ub, vb, r])

        m = self.m
        m11, m22, m33 = self.m11, self.m22, self.m33

        # Coriolis + centripetal
        c13 = -(m - self.Yvdot) * vb - m * self.xg * r
        c23 = (m - self.Xudot) * ub

        # Damping: linear + quadratic
        d1 = -self.Xu * ub - self.Xuu * abs(ub) * ub
        d2 = -self.Yv * vb - self.Yvv * abs(vb) * vb
        d3 = -self.Nr * r  - self.Nrr * abs(r) * r

        # Kinetics (simplified decoupled form)
        rhs1 = tau[0] + c13 * r - d1
        rhs2 = tau[1] + c23 * r - d2
        rhs3 = tau[2]           - d3

        nu_dot = np.array([rhs1 / m11,
                           rhs2 / m22,
                           rhs3 / m33])

        return np.concatenate([eta_dot, nu_dot])

    def output(self, x):
        """Output y = [x_n, y_n, psi]."""
        return x[:3]

    def get_default_x0(self):
        """Default: at origin, heading north, at rest."""
        return np.zeros(6)
