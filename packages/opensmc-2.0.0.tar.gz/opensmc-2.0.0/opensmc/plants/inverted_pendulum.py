"""Inverted Pendulum (Cart-Pole) plant.

Reference
---------
Khalil, H. K. (2015). Nonlinear Systems (3rd ed.). Pearson.
Spong, M. W., Hutchinson, S., & Vidyasagar, M. (2005). Robot Modeling
    and Control. Wiley.

Convention: theta=0 is the upward (inverted) position; theta=pi is
the downward (natural hanging) position.
"""

import numpy as np
from opensmc.core import Plant


class InvertedPendulum(Plant):
    """Cart-pole inverted pendulum with 4 states.

    States: x = [x_cart, x_cart_dot, theta, theta_dot]
    Input:  u (scalar horizontal force on cart)
    Output: y = [x_cart, theta]

    Dynamics
    --------
    M_total = M + m - m * cos^2(theta)

    x_cart_ddot = (u - b*x_cart_dot + m*l*theta_dot^2*sin(theta)
                   - m*g*sin(theta)*cos(theta)) / M_total

    theta_ddot  = (-u*cos(theta) + b*x_cart_dot*cos(theta)
                   - m*l*theta_dot^2*sin(theta)*cos(theta)
                   + (M+m)*g*sin(theta)) / (l * M_total)

    Parameters
    ----------
    M : float
        Cart mass [kg] (default 1.0).
    m : float
        Pendulum mass [kg] (default 0.1).
    l : float
        Pendulum half-length [m] (default 0.5).
    g : float
        Gravitational acceleration [m/s^2] (default 9.81).
    b : float
        Cart friction coefficient (default 0.1).
    """

    def __init__(self, M=1.0, m=0.1, l=0.5, g=9.81, b=0.1):
        super().__init__(n_states=4, n_inputs=1, n_outputs=2,
                         name="InvertedPendulum")
        self.M = M
        self.m = m
        self.l = l
        self.g = g
        self.b = b

    def dynamics(self, t, x, u, d=None):
        """Compute state derivatives.

        Parameters
        ----------
        t : float
            Time.
        x : ndarray (4,)
            State [x_cart, x_cart_dot, theta, theta_dot].
        u : float
            Horizontal force on cart [N].
        d : float or ndarray or None
            External disturbance (added to force). Default 0.

        Returns
        -------
        xdot : ndarray (4,)
        """
        if d is None:
            d = 0.0
        u_val = float(u) if np.ndim(u) > 0 else u
        d_val = float(d) if np.ndim(d) > 0 else d
        u_total = u_val + d_val

        xc, xcd, th, thd = x
        M, m, l, g, b = self.M, self.m, self.l, self.g, self.b

        cth = np.cos(th)
        sth = np.sin(th)
        M_tot = M + m - m * cth**2

        xc_ddot = (u_total - b * xcd + m * l * thd**2 * sth
                   - m * g * sth * cth) / M_tot

        th_ddot = (-u_total * cth + b * xcd * cth
                   - m * l * thd**2 * sth * cth
                   + (M + m) * g * sth) / (l * M_tot)

        return np.array([xcd, xc_ddot, thd, th_ddot])

    def output(self, x):
        """Output y = [x_cart, theta]."""
        return np.array([x[0], x[2]])

    def get_default_x0(self):
        """Default: cart at origin, pendulum inverted upright (theta=0)."""
        return np.zeros(4)
