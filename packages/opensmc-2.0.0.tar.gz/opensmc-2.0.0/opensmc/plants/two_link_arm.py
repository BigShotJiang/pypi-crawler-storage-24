"""Two-Link Robot Arm plant (Euler-Lagrange formulation).

Reference
---------
Slotine, J.J. & Li, W. (1991). Applied Nonlinear Control. Prentice-Hall,
    Chapter 9.
Spong, M.W., Hutchinson, S., & Vidyasagar, M. (2006). Robot Modeling
    and Control. Wiley, Chapter 6.

Euler-Lagrange dynamics: M(q)*qddot + C(q,qdot)*qdot + G(q) = tau
"""

import numpy as np
from opensmc.core import Plant


class TwoLinkArm(Plant):
    """2-DOF planar robot manipulator (fully actuated).

    States: x = [q1, q1_dot, q2, q2_dot]
        - (q1, q1_dot): joint 1 angle and angular velocity [rad, rad/s]
        - (q2, q2_dot): joint 2 angle and angular velocity [rad, rad/s]

    Inputs: tau = [tau1, tau2] (joint torques [N*m])
    Outputs: y = [q1, q2] (joint angles)

    Dynamics
    --------
    M(q) * qddot + C(q, qdot) * qdot + G(q) = tau + d

    where M is the inertia matrix, C is the Coriolis/centrifugal vector,
    and G is the gravity vector.

    Parameters
    ----------
    m1 : float
        Link 1 mass [kg] (default 1.0).
    m2 : float
        Link 2 mass [kg] (default 1.0).
    l1 : float
        Link 1 length [m] (default 1.0).
    l2 : float
        Link 2 length [m] (default 1.0).
    lc1 : float
        Link 1 center-of-mass distance [m] (default 0.5).
    lc2 : float
        Link 2 center-of-mass distance [m] (default 0.5).
    I1 : float
        Link 1 rotational inertia [kg*m^2] (default 0.083).
    I2 : float
        Link 2 rotational inertia [kg*m^2] (default 0.083).
    g : float
        Gravitational acceleration [m/s^2] (default 9.81).
    b1 : float
        Joint 1 viscous friction [N*m*s/rad] (default 0.0).
    b2 : float
        Joint 2 viscous friction [N*m*s/rad] (default 0.0).
    """

    def __init__(self, m1=1.0, m2=1.0, l1=1.0, l2=1.0,
                 lc1=0.5, lc2=0.5, I1=0.083, I2=0.083,
                 g=9.81, b1=0.0, b2=0.0):
        super().__init__(n_states=4, n_inputs=2, n_outputs=2,
                         name="TwoLinkArm")
        self.m1 = m1
        self.m2 = m2
        self.l1 = l1
        self.l2 = l2
        self.lc1 = lc1
        self.lc2 = lc2
        self.I1 = I1
        self.I2 = I2
        self.g = g
        self.b1 = b1
        self.b2 = b2

    def mass_matrix(self, q1, q2):
        """Compute 2x2 inertia matrix M(q).

        Parameters
        ----------
        q1, q2 : float
            Joint angles [rad].

        Returns
        -------
        M : ndarray (2, 2)
            Symmetric positive-definite inertia matrix.
        """
        m1, m2 = self.m1, self.m2
        l1 = self.l1
        lc1, lc2 = self.lc1, self.lc2
        I1, I2 = self.I1, self.I2

        c2 = np.cos(q2)

        M11 = m1 * lc1**2 + I1 + m2 * (l1**2 + lc2**2 + 2 * l1 * lc2 * c2) + I2
        M12 = m2 * (lc2**2 + l1 * lc2 * c2) + I2
        M22 = m2 * lc2**2 + I2

        return np.array([[M11, M12],
                         [M12, M22]])

    def coriolis_vector(self, q1, q2, q1dot, q2dot):
        """Compute Coriolis/centrifugal vector C(q, qdot)*qdot.

        Parameters
        ----------
        q1, q2 : float
            Joint angles [rad].
        q1dot, q2dot : float
            Joint angular velocities [rad/s].

        Returns
        -------
        Cv : ndarray (2,)
            Coriolis/centrifugal terms.
        """
        s2 = np.sin(q2)
        h = self.m2 * self.l1 * self.lc2 * s2

        c1 = -2 * h * q1dot * q2dot - h * q2dot**2
        c2 = h * q1dot**2

        return np.array([c1, c2])

    def coriolis_matrix(self, q1, q2, q1dot, q2dot):
        """Compute 2x2 Coriolis matrix C(q, qdot) using Christoffel symbols.

        This is the unique C matrix satisfying the skew-symmetry property:
        Mdot - 2C is skew-symmetric (Slotine & Li, Property 7.1).

        Parameters
        ----------
        q1, q2 : float
            Joint angles [rad].
        q1dot, q2dot : float
            Joint angular velocities [rad/s].

        Returns
        -------
        C : ndarray (2, 2)
        """
        s2 = np.sin(q2)
        h = self.m2 * self.l1 * self.lc2 * s2

        C11 = -h * q2dot
        C12 = -h * (q1dot + q2dot)
        C21 = h * q1dot
        C22 = 0.0

        return np.array([[C11, C12],
                         [C21, C22]])

    def gravity_vector(self, q1, q2):
        """Compute gravity vector G(q).

        Parameters
        ----------
        q1, q2 : float
            Joint angles [rad].

        Returns
        -------
        G : ndarray (2,)
        """
        m1, m2 = self.m1, self.m2
        l1 = self.l1
        lc1, lc2 = self.lc1, self.lc2
        g = self.g

        c1 = np.cos(q1)
        c12 = np.cos(q1 + q2)

        g1 = (m1 * lc1 + m2 * l1) * g * c1 + m2 * lc2 * g * c12
        g2 = m2 * lc2 * g * c12

        return np.array([g1, g2])

    def dynamics(self, t, x, u, d=None):
        """Compute state derivatives.

        M(q)*qddot = tau - C(q,qdot)*qdot - G(q) - friction + d

        Parameters
        ----------
        t : float
            Time.
        x : ndarray (4,)
            State [q1, q1_dot, q2, q2_dot].
        u : ndarray (2,)
            Joint torques [tau1, tau2].
        d : ndarray (4,) or None
            Disturbance. If provided, d[1] and d[3] are added as
            torque disturbances on joints 1 and 2 respectively. Default 0.

        Returns
        -------
        xdot : ndarray (4,)
        """
        u = np.asarray(u, dtype=float).ravel()
        if d is None:
            d = np.zeros(4)
        else:
            d = np.asarray(d, dtype=float).ravel()

        q1, q1dot, q2, q2dot = x

        M = self.mass_matrix(q1, q2)
        Cv = self.coriolis_vector(q1, q2, q1dot, q2dot)
        G = self.gravity_vector(q1, q2)

        friction = np.array([self.b1 * q1dot, self.b2 * q2dot])

        # tau + disturbance - Coriolis - gravity - friction
        rhs = u - Cv - G - friction + d[[1, 3]]
        qddot = np.linalg.solve(M, rhs)

        return np.array([q1dot, qddot[0], q2dot, qddot[1]])

    def output(self, x):
        """Output y = [q1, q2]."""
        return np.array([x[0], x[2]])

    def get_default_x0(self):
        """Default: both joints at zero angle, at rest."""
        return np.zeros(4)
