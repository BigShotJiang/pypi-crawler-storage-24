"""Dual-Stage Nanopositioner plant.

Reference
---------
Fleming, A.J. (2009). Dual-stage PZT nanopositioner model.
Al Ghanimi, A. (2026). Nonsingular Fast Terminal Sliding Mode Control
    for Vibration Suppression in Dual-Stage Nanopositioners.
    Mechatronics (submitted).

Two resonant vibratory modes driven by a single piezo voltage input.
"""

import numpy as np
from opensmc.core import Plant


class DualStageNanopositioner(Plant):
    """Piezoelectric fine stage with two resonant modes.

    States: x = [x1, x1_dot, x2, x2_dot]
        - (x1, x1_dot): mode 1 displacement and velocity [m, m/s]
        - (x2, x2_dot): mode 2 displacement and velocity [m, m/s]

    Input:  u (scalar voltage [V], clamped to [-u_max, u_max])
    Output: y = x1 + x2 (total displacement [m])

    Dynamics (per mode k)
    ---------------------
    x_k_ddot = -wn_k^2 * x_k - 2*zeta_k*wn_k * x_k_dot + Kp_k*wn_k^2 * u

    Transfer function per mode:
    G_k(s) = Kp_k * wn_k^2 / (s^2 + 2*zeta_k*wn_k*s + wn_k^2)

    Parameters
    ----------
    fn1 : float
        Mode 1 natural frequency [Hz] (default 780).
    fn2 : float
        Mode 2 natural frequency [Hz] (default 2340).
    zeta1 : float
        Mode 1 damping ratio (default 0.012).
    zeta2 : float
        Mode 2 damping ratio (default 0.008).
    Kp1 : float
        Mode 1 DC gain [m/V] (default 0.145e-6).
    Kp2 : float
        Mode 2 DC gain [m/V] (default 0.015e-6).
    u_max : float
        Maximum voltage magnitude [V] (default 20.0).
    """

    def __init__(self, fn1=780.0, fn2=2340.0, zeta1=0.012, zeta2=0.008,
                 Kp1=0.145e-6, Kp2=0.015e-6, u_max=20.0):
        super().__init__(n_states=4, n_inputs=1, n_outputs=1,
                         name="DualStageNanopositioner")
        self.fn1 = fn1
        self.fn2 = fn2
        self.zeta1 = zeta1
        self.zeta2 = zeta2
        self.Kp1 = Kp1
        self.Kp2 = Kp2
        self.u_max = u_max

        # Derived angular frequencies
        self.wn1 = 2.0 * np.pi * fn1
        self.wn2 = 2.0 * np.pi * fn2

    def dynamics(self, t, x, u, d=None):
        """Compute state derivatives.

        Parameters
        ----------
        t : float
            Time.
        x : ndarray (4,)
            State [x1, x1_dot, x2, x2_dot].
        u : float
            Input voltage [V] (clamped to [-u_max, u_max]).
        d : float or None
            Additive disturbance on voltage. Default 0.

        Returns
        -------
        xdot : ndarray (4,)
        """
        if d is None:
            d = 0.0
        u_val = float(u) if np.ndim(u) > 0 else u
        d_val = float(d) if np.ndim(d) > 0 else d
        u_clamped = np.clip(u_val + d_val, -self.u_max, self.u_max)

        wn1, wn2 = self.wn1, self.wn2
        z1, z2 = self.zeta1, self.zeta2
        Kp1, Kp2 = self.Kp1, self.Kp2

        x1, x1d, x2, x2d = x

        x1_ddot = -wn1**2 * x1 - 2 * z1 * wn1 * x1d + Kp1 * wn1**2 * u_clamped
        x2_ddot = -wn2**2 * x2 - 2 * z2 * wn2 * x2d + Kp2 * wn2**2 * u_clamped

        return np.array([x1d, x1_ddot, x2d, x2_ddot])

    def output(self, x):
        """Output y = x1 + x2 (total displacement)."""
        return np.array([x[0] + x[2]])

    def get_default_x0(self):
        """Default: zero displacement, zero velocity for both modes."""
        return np.zeros(4)

    def dc_gain(self):
        """Return the total DC gain Kp1 + Kp2 [m/V]."""
        return self.Kp1 + self.Kp2

    def state_space_matrices(self):
        """Return (A, B, C, D) state-space matrices.

        Returns
        -------
        A : ndarray (4, 4)
        B : ndarray (4, 1)
        C : ndarray (1, 4)
        D : ndarray (1, 1)
        """
        wn1, wn2 = self.wn1, self.wn2
        z1, z2 = self.zeta1, self.zeta2
        Kp1, Kp2 = self.Kp1, self.Kp2

        A = np.array([
            [0.0,         1.0,         0.0,         0.0],
            [-wn1**2,    -2*z1*wn1,    0.0,         0.0],
            [0.0,         0.0,         0.0,         1.0],
            [0.0,         0.0,        -wn2**2,     -2*z2*wn2]
        ])

        B = np.array([
            [0.0],
            [Kp1 * wn1**2],
            [0.0],
            [Kp2 * wn2**2]
        ])

        C = np.array([[1.0, 0.0, 1.0, 0.0]])

        D = np.array([[0.0]])

        return A, B, C, D
