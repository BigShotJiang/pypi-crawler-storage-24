"""Overhead Crane plants (single and double pendulum).

Reference
---------
Qian, D. & Yi, J. (2015). Hierarchical Sliding Mode Control for
    Under-actuated Cranes. Springer, Ch 2.

SinglePendulumCrane: Eq. 2.16 (4 states)
DoublePendulumCrane: Eq. 2.46 (6 states, Lagrangian formulation)
"""

import numpy as np
from opensmc.core import Plant


class SinglePendulumCrane(Plant):
    """Single-pendulum overhead crane (Qian & Yi 2015, Eq. 2.16).

    States: x = [x_trolley, x_trolley_dot, phi, phi_dot]
    Input:  u (scalar horizontal force on trolley) [N]
    Output: y = [x_trolley, phi]

    Dynamics
    --------
    A_ = M + m,  B_ = m * l * cos(phi)
    den1 = A_ * l - B_ * cos(phi)
    den2 = B_ * cos(phi) - A_ * l  (= -den1)

    x_trolley_ddot = ((u + m*l*phi_dot^2*sin(phi)) * l
                      + g * B_ * sin(phi)) / den1

    phi_ddot = ((u + m*l*phi_dot^2*sin(phi)) * cos(phi)
                + g * A_ * sin(phi)) / den2

    Parameters
    ----------
    M : float
        Trolley mass [kg] (default 1.0).
    m : float
        Payload mass [kg] (default 0.8).
    l : float
        Cable length [m] (default 0.305).
    g : float
        Gravitational acceleration [m/s^2] (default 9.81).
    """

    def __init__(self, M=1.0, m=0.8, l=0.305, g=9.81):
        super().__init__(n_states=4, n_inputs=1, n_outputs=2,
                         name="SinglePendulumCrane")
        self.M = M
        self.m = m
        self.l = l
        self.g = g

    def dynamics(self, t, x, u, d=None):
        """Compute state derivatives.

        Parameters
        ----------
        t : float
            Time.
        x : ndarray (4,)
            State [x_trolley, x_trolley_dot, phi, phi_dot].
        u : float
            Horizontal force on trolley [N].
        d : float or None
            External disturbance (added to force). Default 0.

        Returns
        -------
        xdot : ndarray (4,)
        """
        if d is None:
            d = 0.0
        u_val = float(u) if np.ndim(u) > 0 else u
        d_val = float(d) if np.ndim(d) > 0 else d
        u_total = u_val + d_val

        dx = x[1]
        phi = x[2]
        dphi = x[3]

        M, m, l, g = self.M, self.m, self.l, self.g

        st = np.sin(phi)
        ct = np.cos(phi)

        A_ = M + m
        B_ = m * l * ct

        den1 = A_ * l - B_ * ct      # (M+m)*l - m*l*cos^2(phi)
        den2 = B_ * ct - A_ * l      # -den1

        xddot = ((u_total + m * l * dphi**2 * st) * l
                 + g * B_ * st) / den1

        phiddot = ((u_total + m * l * dphi**2 * st) * ct
                   + g * A_ * st) / den2

        return np.array([dx, xddot, dphi, phiddot])

    def get_dynamics_components(self, x):
        """Decompose dynamics into affine-in-u form.

        x_ddot   = f1(x) + b1(x) * u
        phi_ddot = f2(x) + b2(x) * u

        Returns
        -------
        f1, b1, f2, b2 : float
            Drift and input-gain components.
        """
        phi = x[2]
        dphi = x[3]

        M, m, l, g = self.M, self.m, self.l, self.g

        st = np.sin(phi)
        ct = np.cos(phi)

        A_ = M + m
        B_ = m * l * ct
        D_ = m * l * st

        den1 = A_ * l - B_ * ct
        den2 = B_ * ct - A_ * l

        f1 = (D_ * dphi**2 * l + g * B_ * st) / den1
        b1 = l / den1

        f2 = (D_ * dphi**2 * ct + g * A_ * st) / den2
        b2 = ct / den2

        return f1, b1, f2, b2

    def output(self, x):
        """Output y = [x_trolley, phi]."""
        return np.array([x[0], x[2]])

    def get_default_x0(self):
        """Default: trolley at origin, no swing."""
        return np.zeros(4)


class DoublePendulumCrane(Plant):
    """Double-pendulum overhead crane (Qian & Yi 2015, Eq. 2.46).

    Lagrangian formulation: M(q)*qddot + C(q,qdot)*qdot + G(q) = [u; 0; 0]
    where q = [x_trolley, phi, theta].

    States: x = [x_trolley, x_dot, phi, phi_dot, theta, theta_dot]
    Input:  u (scalar horizontal force on trolley) [N]
    Output: y = [x_trolley, phi, theta]

    Parameters
    ----------
    M : float
        Trolley mass [kg] (default 50.0).
    m1 : float
        Hook mass [kg] (default 10.0).
    m2 : float
        Payload (cargo) mass [kg] (default 2.0).
    l1 : float
        Upper cable length [m] (default 3.0).
    l2 : float
        Lower cable length [m] (default 0.3).
    b : float
        Trolley friction [N*s/m] (default 0.0).
    g : float
        Gravitational acceleration [m/s^2] (default 9.81).
    """

    def __init__(self, M=50.0, m1=10.0, m2=2.0, l1=3.0, l2=0.3,
                 b=0.0, g=9.81):
        super().__init__(n_states=6, n_inputs=1, n_outputs=3,
                         name="DoublePendulumCrane")
        self.M = M
        self.m1 = m1   # hook mass (mh in the notebook)
        self.m2 = m2    # payload mass (mc in the notebook)
        self.l1 = l1
        self.l2 = l2
        self.b = b
        self.g = g

    def mass_matrix(self, phi, theta):
        """Mass matrix M(q) -- 3x3, symmetric, positive definite."""
        M_t = self.M
        mh, mc = self.m1, self.m2
        l1, l2 = self.l1, self.l2

        cphi = np.cos(phi)
        ctheta = np.cos(theta)
        cpt = np.cos(phi - theta)

        M_mat = np.array([
            [M_t + mh + mc,
             -(mh + mc) * l1 * cphi,
             -mc * l2 * ctheta],
            [-(mh + mc) * l1 * cphi,
             (mh + mc) * l1**2,
             mc * l1 * l2 * cpt],
            [-mc * l2 * ctheta,
             mc * l1 * l2 * cpt,
             mc * l2**2]
        ])
        return M_mat

    def coriolis_matrix(self, phi, theta, dphi, dtheta):
        """Coriolis/centripetal matrix C(q, qdot) -- 3x3."""
        mh, mc = self.m1, self.m2
        l1, l2 = self.l1, self.l2

        sphi = np.sin(phi)
        stheta = np.sin(theta)
        spt = np.sin(phi - theta)

        C_mat = np.array([
            [self.b,
             (mh + mc) * l1 * sphi * dphi,
             mc * l2 * stheta * dtheta],
            [0.0,
             0.0,
             -mc * l1 * l2 * spt * dtheta],
            [0.0,
             mc * l1 * l2 * spt * dphi,
             0.0]
        ])
        return C_mat

    def gravity_vector(self, phi, theta):
        """Gravity vector G(q) -- (3,)."""
        mh, mc = self.m1, self.m2
        l1, l2 = self.l1, self.l2
        g = self.g

        return np.array([
            0.0,
            (mh + mc) * g * l1 * np.sin(phi),
            mc * g * l2 * np.sin(theta)
        ])

    def get_dynamics_components(self, x):
        """Decompose into affine-in-u form for each generalized coordinate.

        qddot = M^{-1} * ([u;0;0] - G - C*qdot)

        At the current state, returns f_vec, b_vec such that:
            qddot = f_vec + b_vec * u

        Returns
        -------
        f_vec : ndarray (3,)
            Drift terms (gravity + Coriolis, no input).
        b_vec : ndarray (3,)
            Input gain column (first column of M^{-1}).
        """
        dx = x[1]
        phi = x[2]
        dphi = x[3]
        theta = x[4]
        dtheta = x[5]

        dq = np.array([dx, dphi, dtheta])

        M_mat = self.mass_matrix(phi, theta)
        C_mat = self.coriolis_matrix(phi, theta, dphi, dtheta)
        G_vec = self.gravity_vector(phi, theta)

        M_inv = np.linalg.inv(M_mat)

        # f_vec = M^{-1} * (-G - C*dq)
        f_vec = M_inv @ (-G_vec - C_mat @ dq)

        # b_vec = M^{-1} * [1; 0; 0]
        b_vec = M_inv[:, 0]

        return f_vec, b_vec

    def dynamics(self, t, x, u, d=None):
        """Compute state derivatives.

        Parameters
        ----------
        t : float
            Time.
        x : ndarray (6,)
            State [x_trolley, x_dot, phi, phi_dot, theta, theta_dot].
        u : float
            Horizontal force on trolley [N].
        d : float or None
            External disturbance (added to force). Default 0.

        Returns
        -------
        xdot : ndarray (6,)
        """
        if d is None:
            d = 0.0
        u_val = float(u) if np.ndim(u) > 0 else u
        d_val = float(d) if np.ndim(d) > 0 else d
        u_total = u_val + d_val

        dx = x[1]
        phi = x[2]
        dphi = x[3]
        theta = x[4]
        dtheta = x[5]

        dq = np.array([dx, dphi, dtheta])

        M_mat = self.mass_matrix(phi, theta)
        C_mat = self.coriolis_matrix(phi, theta, dphi, dtheta)
        G_vec = self.gravity_vector(phi, theta)

        U_vec = np.array([u_total, 0.0, 0.0])

        # Solve M * qddot = U - G - C*dq
        ddq = np.linalg.solve(M_mat, U_vec - G_vec - C_mat @ dq)

        return np.array([dx, ddq[0], dphi, ddq[1], dtheta, ddq[2]])

    def output(self, x):
        """Output y = [x_trolley, phi, theta]."""
        return np.array([x[0], x[2], x[4]])

    def get_default_x0(self):
        """Default: trolley at origin, both pendulums hanging straight down."""
        return np.zeros(6)
