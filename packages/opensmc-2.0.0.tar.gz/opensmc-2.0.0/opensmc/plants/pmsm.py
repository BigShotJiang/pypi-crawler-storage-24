"""Permanent Magnet Synchronous Motor (PMSM) plant.

Reference
---------
Krause, P.C. et al. (2013). Analysis of Electric Machinery and Drive
    Systems (3rd ed.). Wiley-IEEE Press.

Surface-mounted PMSM in the dq-frame (Park transform).
"""

import numpy as np
from opensmc.core import Plant


class PMSM(Plant):
    """Surface-mounted PMSM in dq-frame with 4 states.

    States: x = [i_d, i_q, omega, theta]
        - i_d, i_q: d-axis and q-axis stator currents [A]
        - omega: electrical rotor speed [rad/s]
        - theta: electrical rotor position [rad]

    Inputs: u = [v_d, v_q] (dq-frame voltages [V], clamped to [-V_max, V_max])
    Outputs: y = [omega, theta] (speed and position)

    Dynamics
    --------
    L_d * di_d/dt = v_d - R_s*i_d + p*omega*L_q*i_q
    L_q * di_q/dt = v_q - R_s*i_q - p*omega*(L_d*i_d + psi_f)
    J * domega/dt = T_e - B*omega - T_L
    dtheta/dt = omega

    Electromagnetic torque:
    T_e = (3/2) * p * (psi_f*i_q + (L_d - L_q)*i_d*i_q)
    For surface-mounted (L_d = L_q): T_e = (3/2)*p*psi_f*i_q

    Parameters
    ----------
    Rs : float
        Stator resistance [Ohm] (default 1.2).
    Ld : float
        d-axis inductance [H] (default 6.8e-3).
    Lq : float
        q-axis inductance [H] (default 6.8e-3).
    psi_f : float
        PM flux linkage [Wb] (default 0.175).
    pp : int
        Number of pole pairs (default 4).
    J : float
        Rotor inertia [kg*m^2] (default 0.003).
    B : float
        Viscous friction coefficient [N*m*s/rad] (default 0.001).
    TL : float
        Nominal load torque [N*m] (default 0.0).
    V_max : float
        DC bus voltage limit [V] (default 48.0).
    """

    def __init__(self, Rs=1.2, Ld=6.8e-3, Lq=6.8e-3, psi_f=0.175,
                 pp=4, J=0.003, B=0.001, TL=0.0, V_max=48.0):
        super().__init__(n_states=4, n_inputs=2, n_outputs=2,
                         name="PMSM")
        self.Rs = Rs
        self.Ld = Ld
        self.Lq = Lq
        self.psi_f = psi_f
        self.pp = pp
        self.J = J
        self.B = B
        self.TL = TL
        self.V_max = V_max

    def electromagnetic_torque(self, i_d, i_q):
        """Compute electromagnetic torque T_e.

        Parameters
        ----------
        i_d, i_q : float
            dq-axis currents [A].

        Returns
        -------
        T_e : float
            Electromagnetic torque [N*m].
        """
        return 1.5 * self.pp * (self.psi_f * i_q
                                + (self.Ld - self.Lq) * i_d * i_q)

    def torque_constant(self):
        """Return torque constant Kt = 1.5 * pp * psi_f [N*m/A].

        Valid for surface-mounted PMSM (Ld = Lq).
        """
        return 1.5 * self.pp * self.psi_f

    def electrical_time_constant(self):
        """Return electrical time constant L/R [s]."""
        return self.Ld / self.Rs

    def dynamics(self, t, x, u, d=None):
        """Compute state derivatives.

        Parameters
        ----------
        t : float
            Time.
        x : ndarray (4,)
            State [i_d, i_q, omega, theta].
        u : ndarray (2,)
            dq-frame voltages [v_d, v_q] [V].
        d : float or None
            Load torque disturbance (added to TL). Default 0.

        Returns
        -------
        xdot : ndarray (4,)
        """
        u = np.asarray(u, dtype=float).ravel()
        if d is None:
            d_val = 0.0
        else:
            d_val = float(d) if np.ndim(d) == 0 else float(np.asarray(d).ravel()[0])

        i_d, i_q, omega, theta = x

        # Clamp voltages to DC bus limit
        vd = np.clip(u[0], -self.V_max, self.V_max)
        vq = np.clip(u[1], -self.V_max, self.V_max)

        Rs = self.Rs
        Ld, Lq = self.Ld, self.Lq
        psi_f = self.psi_f
        pp = self.pp
        J, B = self.J, self.B
        TL = self.TL + d_val

        # Electrical dynamics
        did_dt = (vd - Rs * i_d + pp * omega * Lq * i_q) / Ld
        diq_dt = (vq - Rs * i_q - pp * omega * (Ld * i_d + psi_f)) / Lq

        # Electromagnetic torque
        Te = self.electromagnetic_torque(i_d, i_q)

        # Mechanical dynamics
        domega_dt = (Te - B * omega - TL) / J
        dtheta_dt = omega

        return np.array([did_dt, diq_dt, domega_dt, dtheta_dt])

    def output(self, x):
        """Output y = [omega, theta]."""
        return np.array([x[2], x[3]])

    def get_default_x0(self):
        """Default: zero currents, at rest."""
        return np.zeros(4)
