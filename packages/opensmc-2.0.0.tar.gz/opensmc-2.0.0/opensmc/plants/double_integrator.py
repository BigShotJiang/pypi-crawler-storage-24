"""Double Integrator plant.

Reference
---------
Liu, J. (2017). Sliding Mode Control Using MATLAB. Academic Press, Ch 1.
    Eq. 1.1: J * theta_ddot = u + d

The simplest second-order plant for SMC validation.
"""

import numpy as np
from opensmc.core import Plant


class DoubleIntegrator(Plant):
    """Double integrator: xddot = (u + d) / J.

    States: x = [position, velocity]
    Input:  u (scalar force/torque)
    Output: y = position

    Parameters
    ----------
    J : float
        Inertia (default 1.0). Liu (2017) uses J=2.
    """

    def __init__(self, J=1.0):
        super().__init__(n_states=2, n_inputs=1, n_outputs=1,
                         name="DoubleIntegrator")
        self.J = J

    def dynamics(self, t, x, u, d=None):
        """Compute xdot = [velocity, (u + d) / J].

        Parameters
        ----------
        t : float
            Time.
        x : ndarray (2,)
            State [position, velocity].
        u : float
            Control input (force or torque).
        d : float or None
            External disturbance (default 0).

        Returns
        -------
        xdot : ndarray (2,)
        """
        if d is None:
            d = 0.0
        u_scalar = float(np.ravel(u)[0]) if np.ndim(u) > 0 else float(u)
        # Disturbance acts on acceleration (index 1) if array, else scalar
        if np.ndim(d) > 0:
            d_scalar = float(d[1]) if len(d) > 1 else float(d[0])
        else:
            d_scalar = float(d)

        position_dot = x[1]
        velocity_dot = (u_scalar + d_scalar) / self.J

        return np.array([position_dot, velocity_dot])

    def output(self, x):
        """Output y = position."""
        return x[:1]

    def get_default_x0(self):
        """Default initial state: origin at rest."""
        return np.zeros(2)
