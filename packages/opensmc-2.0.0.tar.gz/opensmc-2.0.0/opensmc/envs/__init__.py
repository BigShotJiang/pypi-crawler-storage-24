"""OpenSMC Gymnasium Environments — RL-ready wrappers for plants.

Usage:
    import gymnasium as gym
    import opensmc  # registers environments

    env = gym.make("OpenSMC/DoubleIntegrator-v0")
    obs, info = env.reset()
    obs, reward, terminated, truncated, info = env.step(action)

Or directly:
    from opensmc.envs import DoubleIntegratorEnv
    env = DoubleIntegratorEnv()

Requires gymnasium: pip install opensmc[rl]
"""

try:
    import gymnasium as gym
    HAS_GYM = True
except ImportError:
    HAS_GYM = False

from .double_integrator_env import DoubleIntegratorEnv
from .crane_env import CraneEnv
from .quadrotor_env import QuadrotorEnv
from .inverted_pendulum_env import InvertedPendulumEnv
from .pmsm_env import PMSMEnv

__all__ = [
    'DoubleIntegratorEnv',
    'CraneEnv',
    'QuadrotorEnv',
    'InvertedPendulumEnv',
    'PMSMEnv',
]

# ── Gymnasium registration ──────────────────────────────────────────────
# Registered when this module is imported (e.g. `import opensmc`).
# Users can then do: env = gym.make("OpenSMC/DoubleIntegrator-v0")

if HAS_GYM:
    _ENV_SPECS = [
        ("OpenSMC/DoubleIntegrator-v0", "opensmc.envs.double_integrator_env:DoubleIntegratorEnv"),
        ("OpenSMC/Crane-v0", "opensmc.envs.crane_env:CraneEnv"),
        ("OpenSMC/Quadrotor-v0", "opensmc.envs.quadrotor_env:QuadrotorEnv"),
        ("OpenSMC/InvertedPendulum-v0", "opensmc.envs.inverted_pendulum_env:InvertedPendulumEnv"),
        ("OpenSMC/PMSM-v0", "opensmc.envs.pmsm_env:PMSMEnv"),
    ]

    for _env_id, _entry_point in _ENV_SPECS:
        if _env_id not in gym.envs.registry:
            gym.register(id=_env_id, entry_point=_entry_point)
