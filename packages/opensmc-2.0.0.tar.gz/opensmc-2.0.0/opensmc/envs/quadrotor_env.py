"""Gymnasium environment for the 6-DOF Quadrotor.

12-state rigid body with 4 inputs (thrust + 3 torques).
The RL agent must learn attitude control and trajectory tracking.

State: [x,y,z, phi,theta,psi, vx,vy,vz, p,q,r]
Action: [U1, U2, U3, U4] (thrust + torques)
Reward: -(position_error^2 + attitude_penalty + r_u * ||u||^2)
"""

import numpy as np

try:
    import gymnasium as gym
    from gymnasium import spaces
    HAS_GYM = True
except ImportError:
    HAS_GYM = False


if HAS_GYM:
    class QuadrotorEnv(gym.Env):
        """Gymnasium env wrapping opensmc Quadrotor6DOF.

        Observation: 12-dim state vector
        Action: [U1, U2, U3, U4], continuous

        Parameters
        ----------
        mass : float — quadrotor mass (kg)
        dt : float — integration step
        T_max : float — episode length
        z_target : float — target altitude
        """

        metadata = {"render_modes": []}

        def __init__(self, mass=0.468, dt=1e-3, T_max=10.0, z_target=1.0,
                     r_u=0.001):
            super().__init__()
            self.mass = mass
            self.g = 9.81
            self.Ixx = 4.856e-3
            self.Iyy = 4.856e-3
            self.Izz = 8.801e-3
            self.dt = dt
            self.T_max = T_max
            self.z_target = z_target
            self.r_u = r_u

            self.observation_space = spaces.Box(
                low=-np.inf, high=np.inf, shape=(12,), dtype=np.float32)
            # Action: [U1 (thrust), U2 (roll torque), U3 (pitch), U4 (yaw)]
            self.action_space = spaces.Box(
                low=np.array([0, -0.5, -0.5, -0.5], dtype=np.float32),
                high=np.array([2 * mass * 9.81, 0.5, 0.5, 0.5], dtype=np.float32),
                dtype=np.float32)

            self._state = np.zeros(12, dtype=np.float64)
            self._step_count = 0
            self._max_steps = int(T_max / dt)

        def _dynamics(self, x, u):
            mass = self.mass
            g = self.g
            phi, theta, psi = x[3], x[4], x[5]
            vx, vy, vz = x[6], x[7], x[8]
            p, q, r = x[9], x[10], x[11]
            U1, U2, U3, U4 = u[0], u[1], u[2], u[3]

            cphi, sphi = np.cos(phi), np.sin(phi)
            cth, sth = np.cos(theta), np.sin(theta)
            cpsi, spsi = np.cos(psi), np.sin(psi)
            tth = np.tan(theta)

            ax = (cphi * sth * cpsi + sphi * spsi) * U1 / mass
            ay = (cphi * sth * spsi - sphi * cpsi) * U1 / mass
            az = -g + cphi * cth * U1 / mass

            pdot = ((self.Iyy - self.Izz) * q * r + U2) / self.Ixx
            qdot = ((self.Izz - self.Ixx) * p * r + U3) / self.Iyy
            rdot = ((self.Ixx - self.Iyy) * p * q + U4) / self.Izz

            phi_dot = p + q * sphi * tth + r * cphi * tth
            theta_dot = q * cphi - r * sphi
            psi_dot = (q * sphi + r * cphi) / (cth + 1e-10)

            return np.array([vx, vy, vz, phi_dot, theta_dot, psi_dot,
                             ax, ay, az, pdot, qdot, rdot])

        def reset(self, seed=None, options=None):
            super().reset(seed=seed)
            self._state = np.zeros(12, dtype=np.float64)
            self._step_count = 0
            return self._state.astype(np.float32), {}

        def step(self, action):
            u = np.clip(action.ravel()[:4], self.action_space.low, self.action_space.high)
            x = self._state
            dt = self.dt

            k1 = self._dynamics(x, u)
            k2 = self._dynamics(x + dt / 2 * k1, u)
            k3 = self._dynamics(x + dt / 2 * k2, u)
            k4 = self._dynamics(x + dt * k3, u)
            self._state = x + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

            self._step_count += 1

            # Reward
            e_z = self._state[2] - self.z_target
            e_xy = self._state[0] ** 2 + self._state[1] ** 2
            e_att = self._state[3] ** 2 + self._state[4] ** 2  # phi, theta
            u_cost = np.sum(u ** 2) * self.r_u
            reward = float(-(e_z ** 2 + 0.1 * e_xy + 0.5 * e_att + u_cost))

            truncated = self._step_count >= self._max_steps
            obs = self._state.astype(np.float32)
            info = {'e_z': e_z}

            return obs, reward, False, truncated, info

else:
    class QuadrotorEnv:
        def __init__(self, **kwargs):
            raise ImportError(
                "gymnasium is required. Install with: pip install opensmc[rl]")
