"""Gymnasium environment for the Double Integrator plant.

The simplest OpenSMC environment — ideal for prototyping RL controllers
and for quick sanity checks before moving to more complex plants.

State: [position, velocity]
Action: force (scalar, continuous)
Reward: -e^2 (negative squared error from reference)
"""

import numpy as np

try:
    import gymnasium as gym
    from gymnasium import spaces
    HAS_GYM = True
except ImportError:
    HAS_GYM = False


if HAS_GYM:
    class DoubleIntegratorEnv(gym.Env):
        """Gymnasium env wrapping opensmc DoubleIntegrator.

        Observation: [position, velocity] (2,)
        Action: force (1,), continuous in [-u_max, u_max]
        Reward: -(e^2 + r_u * u^2) per step
        Done: when T_max reached

        Parameters
        ----------
        dt : float
            Integration time step.
        T_max : float
            Episode length in seconds.
        u_max : float
            Maximum control force.
        x_ref : float
            Target position (default 0 = regulation).
        r_u : float
            Control effort penalty weight in reward.
        x0_range : float
            Initial state sampled from [-x0_range, x0_range].
        disturbance : float
            Amplitude of random disturbance (0 = none).
        """

        metadata = {"render_modes": []}

        def __init__(self, dt=1e-3, T_max=5.0, u_max=10.0, x_ref=0.0,
                     r_u=0.01, x0_range=3.0, disturbance=0.0):
            super().__init__()
            self.dt = dt
            self.T_max = T_max
            self.u_max = u_max
            self.x_ref = x_ref
            self.r_u = r_u
            self.x0_range = x0_range
            self.disturbance = disturbance

            self.observation_space = spaces.Box(
                low=np.array([-np.inf, -np.inf], dtype=np.float32),
                high=np.array([np.inf, np.inf], dtype=np.float32),
                dtype=np.float32,
            )
            self.action_space = spaces.Box(
                low=np.array([-u_max], dtype=np.float32),
                high=np.array([u_max], dtype=np.float32),
                dtype=np.float32,
            )

            self._state = np.zeros(2, dtype=np.float64)
            self._t = 0.0
            self._step_count = 0
            self._max_steps = int(T_max / dt)

        def reset(self, seed=None, options=None):
            super().reset(seed=seed)
            r = self.x0_range
            self._state = self.np_random.uniform(
                low=[-r, -r], high=[r, r]
            ).astype(np.float64)
            self._t = 0.0
            self._step_count = 0
            obs = self._state.astype(np.float32)
            return obs, {}

        def step(self, action):
            u = float(np.clip(action, -self.u_max, self.u_max).ravel()[0])

            # Disturbance
            d = 0.0
            if self.disturbance > 0:
                d = self.np_random.uniform(-self.disturbance, self.disturbance)

            # RK4 integration of xddot = u + d
            x = self._state
            dt = self.dt

            def f(x_):
                return np.array([x_[1], u + d])

            k1 = f(x)
            k2 = f(x + dt / 2 * k1)
            k3 = f(x + dt / 2 * k2)
            k4 = f(x + dt * k3)
            self._state = x + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

            self._t += dt
            self._step_count += 1

            # Reward: penalize error and control effort
            e = self._state[0] - self.x_ref
            reward = float(-(e ** 2 + self.r_u * u ** 2))

            terminated = False
            truncated = self._step_count >= self._max_steps

            obs = self._state.astype(np.float32)
            info = {'e': e, 't': self._t}

            return obs, reward, terminated, truncated, info

else:
    # Stub when gymnasium is not installed
    class DoubleIntegratorEnv:
        def __init__(self, **kwargs):
            raise ImportError(
                "gymnasium is required for OpenSMC environments. "
                "Install with: pip install opensmc[rl]"
            )
