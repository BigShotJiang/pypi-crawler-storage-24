"""Gymnasium environment for the Permanent Magnet Synchronous Motor (PMSM).

An industrially-relevant plant for motor speed/position control.
The RL agent controls dq-frame voltages to track a reference speed.

State: [i_d, i_q, omega, theta]
Action: [v_d, v_q] (dq-frame voltages)
Reward: -(speed_error^2 + current_penalty * i_d^2 + r_u * ||u||^2)
"""

import numpy as np

try:
    import gymnasium as gym
    from gymnasium import spaces
    HAS_GYM = True
except ImportError:
    HAS_GYM = False


if HAS_GYM:
    class PMSMEnv(gym.Env):
        """Gymnasium env wrapping opensmc PMSM.

        Observation: [i_d, i_q, omega, theta, omega_ref] (5,)
        Action: [v_d, v_q] (2,), continuous in [-V_max, V_max]

        Parameters
        ----------
        Rs : float — stator resistance (Ohm)
        Ld : float — d-axis inductance (H)
        Lq : float — q-axis inductance (H)
        psi_f : float — PM flux linkage (Wb)
        pp : int — pole pairs
        J : float — rotor inertia (kg*m^2)
        B : float — viscous friction (N*m*s/rad)
        V_max : float — DC bus voltage limit (V)
        dt : float — integration step
        T_max : float — episode length
        omega_ref : float — target speed (rad/s)
        current_penalty : float — weight on i_d in reward
        r_u : float — control effort penalty weight
        load_disturbance : float — random load torque amplitude (N*m)
        """

        metadata = {"render_modes": []}

        def __init__(self, Rs=1.2, Ld=6.8e-3, Lq=6.8e-3, psi_f=0.175,
                     pp=4, J=0.003, B=0.001, V_max=48.0, dt=1e-4,
                     T_max=2.0, omega_ref=100.0, current_penalty=0.01,
                     r_u=1e-4, load_disturbance=0.0):
            super().__init__()
            self.Rs, self.Ld, self.Lq = Rs, Ld, Lq
            self.psi_f, self.pp = psi_f, pp
            self.J, self.B = J, B
            self.V_max = V_max
            self.dt = dt
            self.T_max = T_max
            self.omega_ref = omega_ref
            self.current_penalty = current_penalty
            self.r_u = r_u
            self.load_disturbance = load_disturbance

            # Observation: [i_d, i_q, omega, theta, omega_ref]
            self.observation_space = spaces.Box(
                low=-np.inf, high=np.inf, shape=(5,), dtype=np.float32)
            # Action: [v_d, v_q]
            self.action_space = spaces.Box(
                low=np.array([-V_max, -V_max], dtype=np.float32),
                high=np.array([V_max, V_max], dtype=np.float32),
                dtype=np.float32)

            self._state = np.zeros(4, dtype=np.float64)
            self._step_count = 0
            self._max_steps = int(T_max / dt)

        def _dynamics(self, x, u, TL):
            Rs, Ld, Lq = self.Rs, self.Ld, self.Lq
            psi_f, pp = self.psi_f, self.pp
            J, B = self.J, self.B

            i_d, i_q, omega, theta = x
            vd = np.clip(u[0], -self.V_max, self.V_max)
            vq = np.clip(u[1], -self.V_max, self.V_max)

            did_dt = (vd - Rs * i_d + pp * omega * Lq * i_q) / Ld
            diq_dt = (vq - Rs * i_q - pp * omega * (Ld * i_d + psi_f)) / Lq

            Te = 1.5 * pp * (psi_f * i_q + (Ld - Lq) * i_d * i_q)
            domega_dt = (Te - B * omega - TL) / J
            dtheta_dt = omega

            return np.array([did_dt, diq_dt, domega_dt, dtheta_dt])

        def reset(self, seed=None, options=None):
            super().reset(seed=seed)
            self._state = np.zeros(4, dtype=np.float64)
            self._step_count = 0
            obs = np.append(self._state, self.omega_ref).astype(np.float32)
            return obs, {}

        def step(self, action):
            u = np.clip(action.ravel()[:2],
                        self.action_space.low, self.action_space.high)

            TL = 0.0
            if self.load_disturbance > 0:
                TL = self.np_random.uniform(-self.load_disturbance,
                                            self.load_disturbance)

            x = self._state
            dt = self.dt

            k1 = self._dynamics(x, u, TL)
            k2 = self._dynamics(x + dt / 2 * k1, u, TL)
            k3 = self._dynamics(x + dt / 2 * k2, u, TL)
            k4 = self._dynamics(x + dt * k3, u, TL)
            self._state = x + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

            self._step_count += 1

            omega = self._state[2]
            i_d = self._state[0]
            e_omega = omega - self.omega_ref

            reward = float(-(e_omega**2
                             + self.current_penalty * i_d**2
                             + self.r_u * np.sum(u**2)))

            truncated = self._step_count >= self._max_steps
            obs = np.append(self._state, self.omega_ref).astype(np.float32)
            info = {'omega': omega, 'e_omega': e_omega, 'i_d': i_d}

            return obs, reward, False, truncated, info

else:
    class PMSMEnv:
        def __init__(self, **kwargs):
            raise ImportError(
                "gymnasium is required. Install with: pip install opensmc[rl]")
