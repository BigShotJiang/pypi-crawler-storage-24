"""Gymnasium environment for the Inverted Pendulum (Cart-Pole).

The classic RL benchmark plant — an underactuated system with 1 input
(cart force) and 2 DOF (cart position + pendulum angle).

State: [x_cart, x_cart_dot, theta, theta_dot]
Action: cart force (scalar, continuous)
Reward: -(theta^2 + position_penalty * x^2 + r_u * u^2)

Convention: theta=0 is upright (inverted).
"""

import numpy as np

try:
    import gymnasium as gym
    from gymnasium import spaces
    HAS_GYM = True
except ImportError:
    HAS_GYM = False


if HAS_GYM:
    class InvertedPendulumEnv(gym.Env):
        """Gymnasium env wrapping opensmc InvertedPendulum.

        Observation: [x_cart, x_cart_dot, theta, theta_dot] (4,)
        Action: cart force (1,), continuous in [-u_max, u_max]

        Parameters
        ----------
        M : float — cart mass (kg)
        m : float — pendulum mass (kg)
        l : float — pendulum half-length (m)
        b : float — cart friction coefficient
        dt : float — integration step
        T_max : float — episode length
        u_max : float — max force
        theta_threshold : float — episode terminates if |theta| exceeds this
        x_threshold : float — episode terminates if |x| exceeds this
        position_penalty : float — weight on cart position in reward
        r_u : float — control effort penalty weight
        x0_range : float — initial state range for theta
        disturbance : float — disturbance amplitude (0 = none)
        """

        metadata = {"render_modes": []}

        def __init__(self, M=1.0, m=0.1, l=0.5, b=0.1, dt=2e-3,
                     T_max=10.0, u_max=30.0, theta_threshold=0.5,
                     x_threshold=5.0, position_penalty=0.1, r_u=0.001,
                     x0_range=0.2, disturbance=0.0):
            super().__init__()
            self.M, self.m, self.l, self.b = M, m, l, b
            self.g = 9.81
            self.dt = dt
            self.T_max = T_max
            self.u_max = u_max
            self.theta_threshold = theta_threshold
            self.x_threshold = x_threshold
            self.position_penalty = position_penalty
            self.r_u = r_u
            self.x0_range = x0_range
            self.disturbance = disturbance

            self.observation_space = spaces.Box(
                low=-np.inf, high=np.inf, shape=(4,), dtype=np.float32)
            self.action_space = spaces.Box(
                low=np.array([-u_max], dtype=np.float32),
                high=np.array([u_max], dtype=np.float32),
                dtype=np.float32)

            self._state = np.zeros(4, dtype=np.float64)
            self._step_count = 0
            self._max_steps = int(T_max / dt)

        def _dynamics(self, x, u):
            M, m, l, g, b = self.M, self.m, self.l, self.g, self.b
            xc, xcd, th, thd = x
            cth = np.cos(th)
            sth = np.sin(th)
            M_tot = M + m - m * cth**2

            xc_ddot = (u - b * xcd + m * l * thd**2 * sth
                       - m * g * sth * cth) / M_tot
            th_ddot = (-u * cth + b * xcd * cth
                       - m * l * thd**2 * sth * cth
                       + (M + m) * g * sth) / (l * M_tot)

            return np.array([xcd, xc_ddot, thd, th_ddot])

        def reset(self, seed=None, options=None):
            super().reset(seed=seed)
            r = self.x0_range
            self._state = self.np_random.uniform(
                low=[-0.1, -0.1, -r, -r],
                high=[0.1, 0.1, r, r]
            ).astype(np.float64)
            self._step_count = 0
            return self._state.astype(np.float32), {}

        def step(self, action):
            u = float(np.clip(action, -self.u_max, self.u_max).ravel()[0])

            # Disturbance
            if self.disturbance > 0:
                u += self.np_random.uniform(-self.disturbance, self.disturbance)

            x = self._state
            dt = self.dt

            k1 = self._dynamics(x, u)
            k2 = self._dynamics(x + dt / 2 * k1, u)
            k3 = self._dynamics(x + dt / 2 * k2, u)
            k4 = self._dynamics(x + dt * k3, u)
            self._state = x + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

            self._step_count += 1

            th = self._state[2]
            xc = self._state[0]

            # Reward: penalize angle deviation, position, and control effort
            reward = float(-(th**2 + self.position_penalty * xc**2
                             + self.r_u * u**2))

            # Terminate if pendulum falls too far or cart out of bounds
            terminated = bool(abs(th) > self.theta_threshold
                              or abs(xc) > self.x_threshold)
            truncated = self._step_count >= self._max_steps

            obs = self._state.astype(np.float32)
            info = {'theta': th, 'x_cart': xc}

            return obs, reward, terminated, truncated, info

else:
    class InvertedPendulumEnv:
        def __init__(self, **kwargs):
            raise ImportError(
                "gymnasium is required. Install with: pip install opensmc[rl]")
