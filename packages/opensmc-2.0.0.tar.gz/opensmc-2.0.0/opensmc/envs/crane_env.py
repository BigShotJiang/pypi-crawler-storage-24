"""Gymnasium environment for the Single-Pendulum Crane.

An underactuated system: 1 input (trolley force), 2 DOF (trolley + pendulum).
The challenge is to move the trolley while suppressing payload swing.

State: [x_trolley, x_dot, phi, phi_dot]
Action: trolley force (scalar)
Reward: -(position_error^2 + swing_penalty * phi^2 + r_u * u^2)
"""

import numpy as np

try:
    import gymnasium as gym
    from gymnasium import spaces
    HAS_GYM = True
except ImportError:
    HAS_GYM = False


if HAS_GYM:
    class CraneEnv(gym.Env):
        """Gymnasium env wrapping opensmc SinglePendulumCrane.

        Observation: [x_trolley, x_dot, phi, phi_dot] (4,)
        Action: trolley force (1,), continuous in [-u_max, u_max]

        Parameters
        ----------
        M : float — trolley mass (kg)
        m : float — payload mass (kg)
        l : float — cable length (m)
        dt : float — integration step
        T_max : float — episode length
        u_max : float — max force
        x_target : float — target trolley position
        swing_penalty : float — weight on swing angle in reward
        """

        metadata = {"render_modes": []}

        def __init__(self, M=1.0, m=0.8, l=0.305, dt=1e-3, T_max=10.0,
                     u_max=50.0, x_target=0.5, swing_penalty=10.0, r_u=0.001):
            super().__init__()
            self.M, self.m, self.l = M, m, l
            self.g = 9.81
            self.dt = dt
            self.T_max = T_max
            self.u_max = u_max
            self.x_target = x_target
            self.swing_penalty = swing_penalty
            self.r_u = r_u

            self.observation_space = spaces.Box(
                low=-np.inf, high=np.inf, shape=(4,), dtype=np.float32)
            self.action_space = spaces.Box(
                low=np.array([-u_max], dtype=np.float32),
                high=np.array([u_max], dtype=np.float32),
                dtype=np.float32)

            self._state = np.zeros(4, dtype=np.float64)
            self._step_count = 0
            self._max_steps = int(T_max / dt)

        def _dynamics(self, x, u):
            M, m, l, g = self.M, self.m, self.l, self.g
            phi, dphi = x[2], x[3]
            st, ct = np.sin(phi), np.cos(phi)
            A_ = M + m
            B_ = m * l * ct
            den1 = A_ * l - B_ * ct
            den2 = B_ * ct - A_ * l
            xddot = ((u + m * l * dphi ** 2 * st) * l + g * B_ * st) / den1
            phiddot = ((u + m * l * dphi ** 2 * st) * ct + g * A_ * st) / den2
            return np.array([x[1], xddot, dphi, phiddot])

        def reset(self, seed=None, options=None):
            super().reset(seed=seed)
            self._state = np.zeros(4, dtype=np.float64)
            self._step_count = 0
            return self._state.astype(np.float32), {}

        def step(self, action):
            u = float(np.clip(action, -self.u_max, self.u_max).ravel()[0])
            x = self._state
            dt = self.dt

            k1 = self._dynamics(x, u)
            k2 = self._dynamics(x + dt / 2 * k1, u)
            k3 = self._dynamics(x + dt / 2 * k2, u)
            k4 = self._dynamics(x + dt * k3, u)
            self._state = x + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

            self._step_count += 1

            e_pos = self._state[0] - self.x_target
            phi = self._state[2]
            reward = float(-(e_pos ** 2 + self.swing_penalty * phi ** 2
                             + self.r_u * u ** 2))

            truncated = self._step_count >= self._max_steps
            obs = self._state.astype(np.float32)
            info = {'e_pos': e_pos, 'phi': phi}

            return obs, reward, False, truncated, info

else:
    class CraneEnv:
        def __init__(self, **kwargs):
            raise ImportError(
                "gymnasium is required. Install with: pip install opensmc[rl]")
