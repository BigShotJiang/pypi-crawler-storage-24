"""Dynamic Sliding Mode Controller.

Reference: Liu, J. & Wang, X. (2012). Advanced Sliding Mode Control
           for Mechanical Systems, Ch 5, Springer.

Key idea: shift the discontinuity from u to udot. The dynamic sliding
variable sigma = sdot + lambda*s is driven to zero. Because u = int(udot),
the control signal is continuous — eliminating chattering structurally.

For a 2nd-order system with surface s = c*e + edot:
  sigma = u + (c + lambda)*xdot + lambda*c*x
  sigma_dot = udot + (c + lambda)*(u + d) + lambda*c*xdot
  udot = -K*sign(sigma) - q*sigma - (c+lambda)*u - lambda*c*xdot
"""

import numpy as np
from opensmc.core import Controller


class DynamicSMC(Controller):
    """Dynamic SMC — continuous control via integrated udot.

    Parameters
    ----------
    surface : SlidingSurface or None
        Pluggable surface. If None, uses s = c*e + edot.
    reaching : ReachingLaw or None
        If provided, used for the sigma-level reaching.
    c : float
        Surface slope.
    K : float
        Switching gain on sigma (lives in udot, not u).
    lam : float
        Dynamic surface parameter (sigma = sdot + lam*s).
    q : float
        Proportional gain on sigma.
    u_max : float
        Control saturation limit.
    dt : float
        Integration timestep for u update.
    """

    def __init__(self, surface=None, reaching=None,
                 c=10.0, K=20.0, lam=10.0, q=5.0,
                 u_max=500.0, dt=1e-4):
        super().__init__(surface=surface, reaching=reaching)
        self.c = c
        self.K = K
        self.lam = lam
        self.q = q
        self.u_max = u_max
        self.dt = dt
        self._u = 0.0

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute dynamic SMC control.

        Parameters
        ----------
        t : float
        x : array [x1, x2]
        xref : array [xref1, xref2]
        plant : Plant or None

        Returns
        -------
        u : float
        info : dict with keys 's', 'sigma', 'udot'
        """
        e = xref[0] - x[0]
        edot = xref[1] - x[1] if len(xref) > 1 else -x[1]

        # Sliding variable
        if self.surface is not None:
            s = self.surface.compute(e, edot, t=t, **kwargs)
        else:
            s = self.c * e + edot

        # Dynamic sliding variable:
        #   sigma = u + (c + lam)*x[1] + lam*c*x[0]
        # This is derived from sigma = sdot + lam*s where
        #   sdot = c*edot + eddot = c*(-x[1]) + (u + d - xref_ddot)
        # For regulation (xref=0): sigma = u + (c+lam)*x[1] + lam*c*x[0]
        sigma = self._u + (self.c + self.lam) * x[1] + self.lam * self.c * x[0]

        # udot: discontinuity lives here, not in u
        #   udot = -K*sign(sigma) - q*sigma - (c+lam)*u - lam*c*x[1]
        udot = (-self.K * np.sign(sigma)
                - self.q * sigma
                - (self.c + self.lam) * self._u
                - self.lam * self.c * x[1])

        # Integrate u (forward Euler)
        self._u = np.clip(self._u + self.dt * udot,
                          -self.u_max, self.u_max)

        info = {
            's': s,
            'sigma': sigma,
            'udot': udot,
            'e': e,
            'edot': edot,
        }
        return self._u, info

    def reset(self):
        """Reset internal control state."""
        super().reset()
        self._u = 0.0
