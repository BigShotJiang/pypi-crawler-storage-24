"""Fixed-Time Sliding Mode Controller (Polyakov 2012).

Reference: Polyakov, A. (2012). "Nonlinear feedback design for fixed-time
           stabilization of linear control systems."
           IEEE Trans. Automatic Control, 57(8), 2106-2110.

Bi-power reaching law:
  sdot = -alpha*|s|^p*sign(s) - beta*|s|^q*sign(s)
with 0 < p < 1 < q.

Settling time bound (independent of initial conditions):
  T_max <= 1/(alpha*(1-p)) + 1/(beta*(q-1))

For a 2nd-order system with surface s = c*e + edot:
  sdot = c*edot + eddot = c*edot + (u + d - xref_ddot)
  u = -c*edot - alpha*|s|^p*sign(s) - beta*|s|^q*sign(s)
"""

import numpy as np
from opensmc.core import Controller


class FixedTimeSMC(Controller):
    """Fixed-time SMC with bi-power reaching law.

    Parameters
    ----------
    surface : SlidingSurface or None
        Pluggable surface. If None, uses s = c*e + edot.
    reaching : ReachingLaw or None
        If provided, overrides bi-power reaching.
    c : float
        Surface slope.
    alpha : float
        Sub-linear reaching gain (handles small |s|).
    beta : float
        Super-linear reaching gain (handles large |s|).
    p : float
        Sub-linear power, 0 < p < 1.
    q : float
        Super-linear power, q > 1.
    """

    def __init__(self, surface=None, reaching=None,
                 c=10.0, alpha=5.0, beta=5.0, p=0.5, q=1.5):
        super().__init__(surface=surface, reaching=reaching)
        self.c = c
        self.alpha = alpha
        self.beta = beta
        self.p = p
        self.q = q

    @property
    def T_max(self):
        """Upper bound on settling time (independent of IC)."""
        return 1.0 / (self.alpha * (1.0 - self.p)) + \
               1.0 / (self.beta * (self.q - 1.0))

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute fixed-time SMC control.

        Parameters
        ----------
        t : float
        x : array [x1, x2]
        xref : array [xref1, xref2]
        plant : Plant or None

        Returns
        -------
        u : float
        info : dict with 's', 'u_eq', 'u_ft', 'T_max'
        """
        e = xref[0] - x[0]
        edot = xref[1] - x[1] if len(xref) > 1 else -x[1]

        # Sliding variable
        if self.surface is not None:
            s = self.surface.compute(e, edot, t=t, **kwargs)
        else:
            s = self.c * e + edot

        # Equivalent control: from sdot = c*edot + eddot, with eddot = -u
        # for double integrator xddot = u => u_eq = c*edot
        u_eq = self.c * edot

        # Bi-power reaching: sdot = -alpha*|s|^p*sign(s) - beta*|s|^q*sign(s)
        # u = c*edot - sdot = c*edot + alpha*|s|^p*sign(s) + beta*|s|^q*sign(s)
        # Clip |s| to avoid overflow in |s|^q when s is large
        s_clipped = np.clip(np.abs(s), 0.0, 1e6)
        if self.reaching is not None:
            u_ft = -self.reaching.compute(s, t=t, **kwargs)
        else:
            u_ft = (self.alpha * s_clipped ** self.p * np.sign(s)
                    + self.beta * s_clipped ** self.q * np.sign(s))

        u = u_eq + u_ft

        info = {
            's': s,
            'u_eq': u_eq,
            'u_ft': u_ft,
            'T_max': self.T_max,
            'e': e,
            'edot': edot,
        }
        return u, info
