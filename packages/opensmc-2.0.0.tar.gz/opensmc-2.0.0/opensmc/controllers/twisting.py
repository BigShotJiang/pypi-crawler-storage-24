"""Twisting Controller — 2nd-Order Sliding Mode.

The historically first 2-sliding mode controller. Drives both σ and σ̇
to zero in finite time using discontinuous control in both variables.

Reference
---------
Levant, A. (1993). Sliding order and sliding accuracy in sliding mode control.
    Int. J. Control, 58(6), 1247-1263.
Shtessel, Y. et al. (2014). Sliding Mode Control and Observation,
    Sec 4.2.1, Eq 4.13, Theorem 4.1.

Formula
-------
For a system with relative degree 2 w.r.t. sliding variable σ:

    σ̈ ∈ [-C, C] + [Km, KM] · u

The twisting controller is:

    u = -(r1 · sign(σ) + r2 · sign(σ̇))

where r1 > r2 > 0 and the sufficient conditions for finite-time
convergence are (Eq 4.14):

    (r1 + r2) · Km - C > (r1 - r2) · KM + C
    (r1 - r2) · Km > C

The name "twisting" comes from the spiral-like trajectory in the
(σ, σ̇) phase plane (see Fig 4.4).

Properties
----------
- Discontinuous in both σ and σ̇
- Finite-time convergence to σ = σ̇ = 0
- Requires measurement of σ̇ (or estimation via differentiator)
- Higher chattering than quasi-continuous alternatives
- Sliding accuracy O(τ²) with sampling interval τ
"""

import numpy as np
from opensmc.core import Controller


class TwistingSMC(Controller):
    """Twisting 2-sliding mode controller (Levant 1993, Shtessel Eq 4.13).

    u = -(r1 · sign(σ) + r2 · sign(σ̇))

    For a 2nd-order system x = [x1, x2], with σ = c·e + edot (or any
    pluggable surface), and σ̇ available from the state.

    Parameters
    ----------
    r1 : float
        Gain on sign(σ). Must satisfy r1 > r2 > 0.
    r2 : float
        Gain on sign(σ̇). Must satisfy r2 > 0.
    c : float
        Surface slope (used when no surface is provided): σ = c·e + edot.
    surface : SlidingSurface or None
        Optional pluggable surface for σ computation.
    """

    def __init__(self, r1=10.0, r2=5.0, c=1.0, surface=None, g_sign=-1.0):
        super().__init__(surface=surface)
        if r2 <= 0:
            raise ValueError(f"r2 must be positive, got {r2}")
        if r1 <= r2:
            raise ValueError(f"r1 must be > r2, got r1={r1}, r2={r2}")
        self.r1 = r1
        self.r2 = r2
        self.c = c
        # g_sign: sign of the input gain in σ̈ = h + g·u.
        # For σ = e = xref - x on DoubleIntegrator (xddot=u):
        #   σ̈ = -u, so g = -1 → g_sign = -1 (default).
        # For σ = x on DoubleIntegrator: σ̈ = u, g = +1 → g_sign = +1.
        self.g_sign = np.sign(g_sign) if g_sign != 0 else -1.0

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute twisting control.

        Parameters
        ----------
        t : float
            Current time.
        x : ndarray
            State vector. For 2nd-order: [x1, x2].
        xref : ndarray
            Reference. For 2nd-order: [xref1, xref2].
        plant : Plant or None
            Not used (model-free controller).

        Returns
        -------
        u : float
            Control signal.
        info : dict
            Contains 's' (σ), 'sdot' (σ̇), 'e', 'edot'.
        """
        # Tracking errors
        e = xref[0] - x[0]
        edot = (xref[1] - x[1]) if len(xref) > 1 else -x[1]

        # Sliding variable σ
        if self.surface is not None:
            sigma = self.surface.compute(e, edot, t=t, **kwargs)
        else:
            sigma = self.c * e + edot

        # σ̇ for linear surface σ = c·e + edot:
        # σ̇ = c·edot + eddot
        # For the double integrator eddot = xref_ddot - u,
        # but the twisting controller doesn't need the exact σ̇ —
        # it uses the state-based estimate.
        # For σ = c·e + edot, σ̇ ≈ c·edot + (acceleration difference)
        # In practice, with full-state measurement on 2nd-order systems,
        # σ̇ can be computed as c·edot (neglecting acceleration term
        # which is what the controller produces).
        #
        # However, the textbook formulation (Eq 4.11) assumes σ̈ = h + g·u,
        # and the controller acts on the (σ, σ̇) plane. For a double
        # integrator with σ = e (position error), σ̇ = edot.
        #
        # Standard approach: use σ̇ = c·edot for linear surface.
        sigma_dot = self.c * edot

        # Twisting control law (Eq 4.13)
        # The textbook assumes σ̈ = h + g·u with g > 0.
        # For g < 0 (e.g., σ=e on DI where σ̈=-u), we flip the sign.
        v = -(self.r1 * np.sign(sigma) + self.r2 * np.sign(sigma_dot))
        u = v / self.g_sign  # u = v/g_sign

        info = {
            's': sigma,
            'sdot': sigma_dot,
            'e': e,
            'edot': edot,
        }
        return u, info
