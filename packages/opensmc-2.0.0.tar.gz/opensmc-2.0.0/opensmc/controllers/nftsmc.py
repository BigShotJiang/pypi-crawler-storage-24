"""Nonsingular Fast Terminal Sliding Mode Controller (NFTSMC).

Reference: Al Ghanimi, A. (2026). Nonsingular Fast Terminal Sliding Mode
           Controller for Nanopositioner Systems. Mechatronics (submitted).

Surface (singularity-free, 1 < gamma < 2):
  s = edot + alpha*e + beta*|e|^gamma*sign(e)

Control law:
  ds = beta*gamma*|e|^(gamma-1)*edot
  sn = s / (|s| + delta)                   [continuous sign approximation]
  u  = (-alpha*edot - ds - k1*s - k2*|s|^rho*sign(s) - eta*sn) / g_input

With 1 < gamma < 2, the derivative gamma*|e|^(gamma-1) -> 0 at e=0
(not infinity), eliminating the singularity problem of classical TSMC.

Optional integral action:
  u_total = u - kI * integral(e dt)
"""

import numpy as np
from opensmc.core import Controller


class NFTSMC(Controller):
    """Nonsingular Fast Terminal SMC (Al Ghanimi 2026).

    Parameters
    ----------
    surface : SlidingSurface or None
        If provided, overrides the built-in NFTSMC surface.
    reaching : ReachingLaw or None
        If provided, overrides the built-in reaching law.
    alpha : float
        Linear error gain.
    beta : float
        Terminal error gain.
    gamma : float
        Terminal power (1 < gamma < 2, singularity-free).
    k1 : float
        Proportional reaching gain.
    k2 : float
        Power reaching gain.
    rho : float
        Reaching power (typically ~5/7).
    eta : float
        Continuous switching gain.
    delta : float
        Smoothing parameter for sn = s/(|s|+delta).
    kI : float
        Integral action gain (0 = disabled).
    g_input : float
        Input gain (for xddot = f + g*u, default g=1).
    dt : float
        Timestep for integral state update.
    """

    def __init__(self, surface=None, reaching=None,
                 alpha=5.0, beta=2.0, gamma=1.4,
                 k1=10.0, k2=3.0, rho=0.714,
                 eta=1.0, delta=1e-6,
                 kI=0.0, g_input=1.0, dt=1e-4):
        super().__init__(surface=surface, reaching=reaching)
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        self.k1 = k1
        self.k2 = k2
        self.rho = rho
        self.eta = eta
        self.delta = delta
        self.kI = kI
        self.g_input = g_input
        self.dt = dt
        self._e_int = 0.0  # integral of error for integral action

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute NFTSMC control.

        Parameters
        ----------
        t : float
        x : array [x1, x2]
        xref : array [xref1, xref2] — reference (constant or slow-varying)
        plant : Plant or None
        **kwargs :
            f_plant : float — plant nonlinearity f(x) if known (default 0)

        Returns
        -------
        u : float
        info : dict with 's', 'ds', 'sn', 'e', 'edot', 'e_int'
        """
        # Error convention: e = x - xref (for NFTSMC, per notebook)
        # The surface drives e -> 0 from above/below
        e = x[0] - xref[0]
        edot = x[1] - (xref[1] if len(xref) > 1 else 0.0)

        # Plant nonlinearity
        f_plant = kwargs.get('f_plant', 0.0)

        # NFTSMC surface: s = edot + alpha*e + beta*|e|^gamma*sign(e)
        if self.surface is not None:
            s = self.surface.compute(e, edot, t=t, **kwargs)
        else:
            s = (edot
                 + self.alpha * e
                 + self.beta * np.abs(e) ** self.gamma * np.sign(e))

        # Surface derivative term: ds = beta*gamma*|e|^(gamma-1)*edot
        ds = (self.beta * self.gamma
              * (np.abs(e) + 1e-15) ** (self.gamma - 1.0) * edot)

        # Continuous sign approximation: sn = s / (|s| + delta)
        sn = s / (np.abs(s) + self.delta)

        # Control law:
        #   u = (-alpha*edot - ds - k1*s - k2*|s|^rho*sign(s) - eta*sn) / g
        if self.reaching is not None:
            u_rob = self.reaching.compute(s, t=t, **kwargs)
            u = (-self.alpha * edot - ds + u_rob) / self.g_input
        else:
            u = (-self.alpha * edot
                 - ds
                 - self.k1 * s
                 - self.k2 * np.abs(s) ** self.rho * np.sign(s)
                 - self.eta * sn) / self.g_input

        # Integral action (optional)
        if self.kI > 0:
            self._e_int += e * self.dt
            u -= self.kI * self._e_int

        info = {
            's': s,
            'ds': ds,
            'sn': sn,
            'e': e,
            'edot': edot,
            'e_int': self._e_int,
        }
        return u, info

    def reset(self):
        """Reset integral state."""
        super().reset()
        self._e_int = 0.0
