"""LQR Controller — Linear Quadratic Regulator baseline.

Computes the optimal state-feedback gain K by solving the continuous-time
algebraic Riccati equation (CARE):

    A'P + PA - PBR^{-1}B'P + Q = 0
    K = R^{-1} B' P
    u = -K (x - xref)

This serves as an optimal linear baseline. Showing that SMC outperforms
LQR under disturbances demonstrates the value of robust control.

Note
----
This is NOT a sliding mode controller. It is included in OpenSMC
solely for benchmark comparison purposes. Requires scipy.
"""

import numpy as np
from opensmc.core import Controller


class LQR(Controller):
    """Linear Quadratic Regulator for benchmark comparison.

    u = -K @ (x - xref)

    where K = R^{-1} B^T P and P solves the CARE.

    Parameters
    ----------
    A : ndarray (n, n)
        State matrix of the linearized system.
    B : ndarray (n, m)
        Input matrix.
    Q : ndarray (n, n) or None
        State cost matrix. If None, uses identity.
    R : ndarray (m, m) or None
        Input cost matrix. If None, uses identity.
    u_max : float or None
        Control saturation limit.

    Example
    -------
    For a double integrator (xddot = u):
        A = [[0, 1], [0, 0]]
        B = [[0], [1]]
        Q = [[10, 0], [0, 1]]  (penalize position more)
        R = [[1]]
    """

    def __init__(self, A, B, Q=None, R=None, u_max=None):
        super().__init__()
        self.A = np.atleast_2d(A).astype(float)
        self.B = np.atleast_2d(B).astype(float)
        n = self.A.shape[0]
        m = self.B.shape[1]

        if Q is None:
            self.Q = np.eye(n)
        else:
            self.Q = np.atleast_2d(Q).astype(float)

        if R is None:
            self.R = np.eye(m)
        else:
            self.R = np.atleast_2d(R).astype(float)

        self.u_max = u_max
        self._n = n
        self._m = m

        # Solve CARE and compute gain
        self.P, self.K = self._solve_care()

    def _solve_care(self):
        """Solve the continuous algebraic Riccati equation."""
        try:
            from scipy.linalg import solve_continuous_are
            P = solve_continuous_are(self.A, self.B, self.Q, self.R)
        except ImportError:
            # Fallback: simple pole placement for 2nd-order systems
            # This is a rough approximation, not true LQR
            n = self._n
            P = np.eye(n) * 10
        K = np.linalg.solve(self.R, self.B.T @ P)
        return P, K

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute LQR control: u = -K @ (x - xref).

        Parameters
        ----------
        t : float
        x : ndarray (n,)
        xref : ndarray (n,) — reference state (regulation target)

        Returns
        -------
        u : float or ndarray
        info : dict with 's' (= position error), 'K'
        """
        x_arr = np.atleast_1d(x[:self._n]).astype(float)
        xref_arr = np.atleast_1d(xref[:self._n]).astype(float)

        # Pad xref if shorter than state
        if len(xref_arr) < self._n:
            xref_arr = np.concatenate([xref_arr, np.zeros(self._n - len(xref_arr))])

        e_state = x_arr - xref_arr
        u = -self.K @ e_state

        if self.u_max is not None:
            u = np.clip(u, -self.u_max, self.u_max)

        # Return scalar for single-input
        if self._m == 1:
            u = float(u.ravel()[0])

        info = {
            's': float(xref_arr[0] - x_arr[0]),
            'e_state': e_state,
        }
        return u, info
