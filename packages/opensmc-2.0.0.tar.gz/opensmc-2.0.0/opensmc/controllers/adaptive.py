"""Adaptive Sliding Mode Controller.

Reference: Liu, J. & Wang, X. (2012). Advanced Sliding Mode Control
           for Mechanical Systems, Ch 6, Springer.

Key idea: the switching gain eta adapts online so we don't need to
know the disturbance bound a priori.

  Adaptation law: eta_dot = gamma * |s|   (if |s| > threshold)
  Control: u = u_eq - eta * sign(s) - lam * s

The gain eta grows monotonically until it exceeds the disturbance bound,
at which point sliding is achieved and |s| becomes small.
"""

import numpy as np
from opensmc.core import Controller


class AdaptiveSMC(Controller):
    """Adaptive SMC with online gain adaptation.

    Parameters
    ----------
    surface : SlidingSurface or None
        Pluggable surface. If None, uses s = c*e + edot.
    reaching : ReachingLaw or None
        Pluggable reaching law (overrides internal logic if provided).
    c : float
        Surface slope.
    gamma : float
        Adaptation rate (eta_dot = gamma * |s|).
    eta0 : float
        Initial switching gain.
    eta_max : float
        Upper bound on eta (projection).
    lam : float
        Proportional sliding gain.
    dt : float
        Integration timestep for eta update (forward Euler).
    threshold : float
        Adaptation dead-zone: eta only adapts when |s| > threshold.
    """

    def __init__(self, surface=None, reaching=None,
                 c=10.0, gamma=100.0, eta0=0.1, eta_max=100.0,
                 lam=5.0, dt=1e-4, threshold=0.0):
        super().__init__(surface=surface, reaching=reaching)
        self.c = c
        self.gamma = gamma
        self.eta0 = eta0
        self.eta_max = eta_max
        self.lam = lam
        self.dt = dt
        self.threshold = threshold
        self._eta = eta0

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute adaptive SMC control.

        Parameters
        ----------
        t : float
        x : array [x1, x2]
        xref : array [xref1, xref2]
        plant : Plant or None

        Returns
        -------
        u : float
        info : dict with keys 's', 'eta', 'u_eq', 'u_rob'
        """
        e = xref[0] - x[0]
        edot = xref[1] - x[1] if len(xref) > 1 else -x[1]

        # Sliding variable
        if self.surface is not None:
            s = self.surface.compute(e, edot, t=t, **kwargs)
        else:
            s = self.c * e + edot

        # Adaptation law: eta_dot = gamma * |s| (with projection)
        if np.abs(s) > self.threshold:
            self._eta += self.dt * self.gamma * np.abs(s)
        self._eta = min(self._eta, self.eta_max)

        # Equivalent control: from sdot = c*edot + eddot, with eddot = -u
        # for double integrator (xddot = u), sdot = c*edot - u + u_eq
        # Setting sdot = 0 => u_eq = c*edot = -c*x[1] when xref = 0
        # But we want u = u_eq - sdot_desired, and for eddot = -u:
        #   sdot = c*edot - u, so u = c*edot - sdot
        # If we want sdot = -eta*sign(s) - lam*s, then:
        #   u = c*edot + eta*sign(s) + lam*s
        u_eq = -self.c * x[1]

        # Robust control (positive sign drives sdot negative when s > 0)
        if self.reaching is not None:
            u_rob = -self.reaching.compute(s, t=t, **kwargs)
        else:
            u_rob = self._eta * np.sign(s) + self.lam * s

        u = u_eq + u_rob

        info = {
            's': s,
            'eta': self._eta,
            'u_eq': u_eq,
            'u_rob': u_rob,
            'e': e,
            'edot': edot,
        }
        return u, info

    def reset(self):
        """Reset adaptive gain to initial value."""
        super().reset()
        self._eta = self.eta0
