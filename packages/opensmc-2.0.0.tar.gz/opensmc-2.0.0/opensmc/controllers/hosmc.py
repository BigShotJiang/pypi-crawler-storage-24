"""Arbitrary-Order Higher-Order Sliding Mode Controllers.

Two families of r-sliding controllers from Levant (2003, 2005):

1. **NestedHOSMC** (Sec 6.6.1): Nested sign-based controller.
   Discontinuous, uses recursive sign structure.

2. **QuasiContinuousHOSMC** (Sec 6.6.2): Quasi-continuous controller.
   Continuous everywhere except at the r-sliding manifold.
   Preferred in practice due to significantly less chattering.

Both require σ, σ̇, ..., σ^{(r-1)} as inputs (r = relative degree).

Reference
---------
Levant, A. (2003). Higher-order sliding modes, differentiation and
    output-feedback control. IJC, 76(9-10), 924-941.
Levant, A. (2005). Quasi-continuous high-order sliding-mode controllers.
    IEEE TAC, 50(11), 1812-1816.
Shtessel, Y. et al. (2014). Sliding Mode Control and Observation,
    Sec 6.6, Eqs 6.22-6.27.
"""

import numpy as np
from math import lcm as _lcm
from opensmc.core import Controller


def _compute_lcm(values):
    """Compute LCM of a list of positive integers."""
    result = 1
    for v in values:
        result = _lcm(result, v)
    return result


class NestedHOSMC(Controller):
    """Nested r-sliding mode controller (Levant 2003, Shtessel Sec 6.6.1).

    Recursive definition:
        N_{i,r} = (Σ_{j=0}^{i-1} |σ^{(j)}|^{q/(r-j)})^{1/q}
        Ψ_{0,r} = sign(σ)
        Ψ_{i,r} = sign(σ^{(i)} + β_i · N_{i,r} · Ψ_{i-1,r})
        u = -α · Ψ_{r-1,r}

    where q = lcm(1, 2, ..., r) ensures integer exponents.

    Special cases:
        r=1: u = -α · sign(σ)               (relay control)
        r=2: u = -α · sign(σ̇ + β|σ|^½·sign(σ))  (prescribed convergence)

    Parameters
    ----------
    order : int
        Sliding mode order r (= relative degree of the system).
    alpha : float
        Control magnitude. Must be large enough for convergence.
    betas : list of float or None
        Gains [β_1, ..., β_{r-1}]. Length must be r-1.
        If None, uses [1.0, 2.0, 3.0, ...] (heuristic defaults).
    c : float
        Surface slope for computing σ = c·e + edot when order=2
        and no explicit sigma_derivs are provided.
    g_sign : float
        Sign of the input gain in σ^{(r)} = h + g·u.
        Default -1 for σ=e on standard plants where σ̈=-u.
    """

    def __init__(self, order=2, alpha=10.0, betas=None, c=1.0, g_sign=-1.0):
        super().__init__()
        if order < 1:
            raise ValueError(f"order must be >= 1, got {order}")
        self.order = order
        self.alpha = alpha
        self.c = c
        self.g_sign = np.sign(g_sign) if g_sign != 0 else -1.0

        # Default betas
        if betas is None:
            self.betas = [float(i) for i in range(1, order)]
        else:
            if len(betas) != order - 1:
                raise ValueError(
                    f"betas length {len(betas)} != order-1 = {order-1}")
            self.betas = list(betas)

        # Precompute q = lcm(1, ..., r)
        self._q = _compute_lcm(range(1, order + 1)) if order > 1 else 1

    def _compute_psi(self, sigma_derivs):
        """Compute Ψ_{r-1,r} from the derivative vector."""
        r = self.order
        q = self._q

        psi = np.sign(sigma_derivs[0])  # Ψ_{0,r}

        for i in range(1, r):
            # N_{i,r} = (Σ_{j=0}^{i-1} |σ^{(j)}|^{q/(r-j)})^{1/q}
            terms = 0.0
            for j in range(i):
                exp = q / (r - j)
                terms += np.abs(sigma_derivs[j]) ** exp
            N_i = terms ** (1.0 / q) if terms > 1e-30 else 0.0

            # Ψ_{i,r} = sign(σ^{(i)} + β_i · N_{i,r} · Ψ_{i-1,r})
            psi = np.sign(sigma_derivs[i] + self.betas[i-1] * N_i * psi)

        return psi

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute nested HOSMC control.

        Parameters
        ----------
        t : float
        x : ndarray — state vector
        xref : ndarray — reference
        sigma_derivs : list of float, optional
            [σ, σ̇, ..., σ^{(r-1)}]. If not provided, computed from
            (x, xref) assuming 2nd-order system with σ = c·e + edot.

        Returns
        -------
        u : float
        info : dict with 's', 'psi'
        """
        sigma_derivs = kwargs.get('sigma_derivs', None)

        if sigma_derivs is None:
            # Default: 2nd-order system, σ = c·e + edot, σ̇ = c·edot
            e = xref[0] - x[0]
            edot = (xref[1] - x[1]) if len(xref) > 1 else -x[1]
            sigma = self.c * e + edot
            sigma_dot = self.c * edot
            sigma_derivs = [sigma, sigma_dot]

        psi = self._compute_psi(sigma_derivs)
        v = -self.alpha * psi
        u = v / self.g_sign

        info = {
            's': sigma_derivs[0],
            'psi': psi,
        }
        return u, info


class QuasiContinuousHOSMC(Controller):
    """Quasi-continuous r-sliding mode controller (Levant 2005, Shtessel Sec 6.6.2).

    Recursive definition:
        φ_{0,r} = σ, N_{0,r} = |σ|, Ψ_{0,r} = sign(σ)
        φ_{i,r} = σ^{(i)} + β_i · N_{i-1,r}^{(r-i)/(r-i+1)} · Ψ_{i-1,r}
        N_{i,r} = |σ^{(i)}| + β_i · N_{i-1,r}^{(r-i)/(r-i+1)}
        Ψ_{i,r} = φ_{i,r} / N_{i,r}
        u = -α · Ψ_{r-1,r}

    The controller is continuous everywhere except at σ = σ̇ = ... = σ^{(r-1)} = 0.
    In practice (with noise and discrete sampling), the control is always continuous.

    Special cases:
        r=1: u = -α · sign(σ)
        r=2: u = -α · (σ̇+β|σ|^½sign(σ)) / (|σ̇|+β|σ|^½)  (QC 2-SM, Eq 4.30)

    Properties:
        - |u| ≤ α (bounded by design)
        - Significantly reduced chattering compared to nested
        - Same convergence guarantees (Theorem 6.3)
        - Preferred by textbook authors (p.228)

    Parameters
    ----------
    order : int
        Sliding mode order r (= relative degree).
    alpha : float
        Control magnitude bound.
    betas : list of float or None
        Gains [β_1, ..., β_{r-1}]. Length must be r-1.
        If None, uses [1.0, 2.0, 3.0, ...] (heuristic defaults).
    c : float
        Surface slope for default σ computation.
    g_sign : float
        Sign of input gain. Default -1 for σ=e systems.
    epsilon : float
        Small constant to avoid division by zero.
    """

    def __init__(self, order=2, alpha=10.0, betas=None, c=1.0,
                 g_sign=-1.0, epsilon=1e-10):
        super().__init__()
        if order < 1:
            raise ValueError(f"order must be >= 1, got {order}")
        self.order = order
        self.alpha = alpha
        self.c = c
        self.g_sign = np.sign(g_sign) if g_sign != 0 else -1.0
        self.epsilon = epsilon

        if betas is None:
            self.betas = [float(i) for i in range(1, order)]
        else:
            if len(betas) != order - 1:
                raise ValueError(
                    f"betas length {len(betas)} != order-1 = {order-1}")
            self.betas = list(betas)

    def _compute_psi(self, sigma_derivs):
        """Compute Ψ_{r-1,r} from the derivative vector."""
        r = self.order
        eps = self.epsilon

        # Level 0
        phi = sigma_derivs[0]
        N = np.abs(sigma_derivs[0])
        psi = phi / (N + eps)  # ≈ sign(σ)

        for i in range(1, r):
            exp = (r - i) / (r - i + 1)
            N_pow = (N + eps) ** exp

            phi = sigma_derivs[i] + self.betas[i-1] * N_pow * psi
            N = np.abs(sigma_derivs[i]) + self.betas[i-1] * N_pow
            psi = phi / (N + eps)

        return psi

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute quasi-continuous HOSMC control.

        Parameters
        ----------
        t : float
        x : ndarray — state vector
        xref : ndarray — reference
        sigma_derivs : list of float, optional
            [σ, σ̇, ..., σ^{(r-1)}]. If not provided, defaults to
            2nd-order system with σ = c·e + edot, σ̇ = c·edot.

        Returns
        -------
        u : float, bounded by |u| ≤ α
        info : dict with 's', 'psi'
        """
        sigma_derivs = kwargs.get('sigma_derivs', None)

        if sigma_derivs is None:
            e = xref[0] - x[0]
            edot = (xref[1] - x[1]) if len(xref) > 1 else -x[1]
            sigma = self.c * e + edot
            sigma_dot = self.c * edot
            sigma_derivs = [sigma, sigma_dot]

        psi = self._compute_psi(sigma_derivs)
        v = -self.alpha * psi
        u = v / self.g_sign

        info = {
            's': sigma_derivs[0],
            'psi': psi,
        }
        return u, info
