"""Discrete-Time Sliding Mode Controller (Gao 1995).

Reference: Gao, W., Wang, Y., & Homaifa, A. (1995).
           "Discrete-time variable structure control systems."
           IEEE Trans. Industrial Electronics, 42(2), 117-122.

Discrete reaching law:
  s(k+1) = (1 - q*Ts)*s(k) - epsilon*Ts*sign(s(k))

Quasi-sliding mode band:
  |s| <= epsilon*Ts / (2 - q*Ts)

Control for double integrator (xddot = u):
  Surface: s = x2 + c*x1
  From s(k+1) = s(k) + c*Ts*x2(k) + g*u(k), where g = Ts + c*Ts^2/2:
  u = -(q*Ts*s + epsilon*Ts*sign(s) + c*Ts*x2) / g
"""

import numpy as np
from opensmc.core import Controller


class DiscreteSMC(Controller):
    """Discrete-time SMC with Gao reaching law.

    Parameters
    ----------
    surface : SlidingSurface or None
        Pluggable surface. If None, uses s = c*e + edot.
    reaching : ReachingLaw or None
        If provided, overrides internal Gao reaching law.
    c : float
        Surface slope.
    q_rate : float
        Exponential reaching rate (must satisfy q*Ts < 1).
    epsilon : float
        Constant reaching gain.
    Ts : float
        Sampling period.
    u_max : float
        Control saturation.
    """

    def __init__(self, surface=None, reaching=None,
                 c=10.0, q_rate=10.0, epsilon=5.0, Ts=0.01,
                 u_max=500.0):
        super().__init__(surface=surface, reaching=reaching)
        self.c = c
        self.q_rate = q_rate
        self.epsilon = epsilon
        self.Ts = Ts
        self.u_max = u_max
        # Input-to-surface gain for double integrator with ZOH:
        #   g = Ts + c * Ts^2 / 2
        self._g = Ts + c * Ts**2 / 2.0

    @property
    def quasi_sliding_band(self):
        """Theoretical quasi-sliding band width."""
        return self.epsilon * self.Ts / (2.0 - self.q_rate * self.Ts)

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute discrete SMC control.

        Parameters
        ----------
        t : float — current discrete time
        x : array [x1, x2] — current state
        xref : array [xref1, xref2] — reference state
        plant : Plant or None

        Returns
        -------
        u : float
        info : dict with 's', 'band'
        """
        e = xref[0] - x[0]
        edot = xref[1] - x[1] if len(xref) > 1 else -x[1]

        # Sliding variable
        if self.surface is not None:
            s = self.surface.compute(e, edot, t=t, **kwargs)
        else:
            s = self.c * e + edot

        # Discrete reaching law control:
        #   s(k+1) = (1-q*Ts)*s(k) - eps*Ts*sign(s(k))
        # Requires: u = -(q*Ts*s + eps*Ts*sign(s) + c*Ts*x2) / g
        if self.reaching is not None:
            u_rob = -self.reaching.compute(s, t=t, **kwargs)
            u = u_rob
        else:
            # For double integrator xddot = u, the discrete reaching law gives:
            #   s(k+1) - s(k) = c*Ts*edot + Ts*eddot ≈ c*Ts*edot - g*u
            # Setting s(k+1) = (1-q*Ts)*s - eps*Ts*sign(s):
            #   u = (q*Ts*s + eps*Ts*sign(s) + c*Ts*edot) / g
            u = (self.q_rate * self.Ts * s
                 + self.epsilon * self.Ts * np.sign(s)
                 + self.c * self.Ts * edot) / self._g

        u = np.clip(u, -self.u_max, self.u_max)

        info = {
            's': s,
            'band': self.quasi_sliding_band,
            'e': e,
            'edot': edot,
        }
        return u, info
