"""Fuzzy Sliding Mode Controller.

Reference: Khanesar, M.A. et al. (2021). Sliding-Mode Fuzzy Controllers.
           Springer.

Key idea: replace sign(s) with a Mamdani fuzzy inference system.
Two inputs (s, sdot), 5 x 3 = 15 rules, output k_fuzzy in [-1, 1].
  u = u_eq - k * k_fuzzy(s, sdot)

This eliminates chattering without a boundary layer, producing smooth
control signals while maintaining sliding mode robustness.

Membership functions:
  s:    5 triangular MFs (NB, NS, ZE, PS, PB) on [-1, 1] (normalized)
  sdot: 3 triangular MFs (N, Z, P) on [-1, 1] (normalized)

Rule table (5x3, output consequents):
  NB: [-1.0, -0.5, -0.25]
  NS: [-0.5, -0.25, 0.0]
  ZE: [-0.25, 0.0, 0.25]
  PS: [0.0, 0.25, 0.5]
  PB: [0.25, 0.5, 1.0]
"""

import numpy as np
from opensmc.core import Controller


def _trimf(x, abc):
    """Triangular membership function with shoulder support.

    Parameters
    ----------
    x : float — input value
    abc : tuple (a, b, c) — triangle vertices
        a==b: left-shoulder (flat top on left)
        b==c: right-shoulder (flat top on right)

    Returns
    -------
    mu : float in [0, 1]
    """
    a, b, c = abc
    if a == b:
        left = 1.0
    else:
        left = (x - a) / (b - a)
    if b == c:
        right = 1.0
    else:
        right = (c - x) / (c - b)
    return max(0.0, min(left, right))


def _fuzzy_inference(s_val, sdot_val, s_range=1.0, sdot_range=5.0):
    """Mamdani fuzzy inference: (s, sdot) -> k_fuzzy in [-1, 1].

    Parameters
    ----------
    s_val : float — sliding variable
    sdot_val : float — sliding variable derivative
    s_range : float — normalization range for s
    sdot_range : float — normalization range for sdot

    Returns
    -------
    k_fuzzy : float in [-1, 1]
    """
    # Normalize inputs to [-1, 1]
    sn = np.clip(s_val / s_range, -1.0, 1.0)
    sdn = np.clip(sdot_val / sdot_range, -1.0, 1.0)

    # Membership functions for s (5 MFs)
    s_mf_params = [
        (-1.0, -1.0, -0.5),   # NB (left shoulder)
        (-1.0, -0.5, 0.0),    # NS
        (-0.5, 0.0, 0.5),     # ZE
        (0.0, 0.5, 1.0),      # PS
        (0.5, 1.0, 1.0),      # PB (right shoulder)
    ]
    mu_s = [_trimf(sn, p) for p in s_mf_params]

    # Membership functions for sdot (3 MFs)
    sd_mf_params = [
        (-1.0, -1.0, 0.0),    # N (left shoulder)
        (-1.0, 0.0, 1.0),     # Z
        (0.0, 1.0, 1.0),      # P (right shoulder)
    ]
    mu_sd = [_trimf(sdn, p) for p in sd_mf_params]

    # Rule consequents (5 s-rules x 3 sdot-rules)
    rules = [
        [-1.0, -0.5, -0.25],   # NB row
        [-0.5, -0.25, 0.0],    # NS row
        [-0.25, 0.0, 0.25],    # ZE row
        [0.0, 0.25, 0.5],      # PS row
        [0.25, 0.5, 1.0],      # PB row
    ]

    # Weighted average defuzzification
    num = 0.0
    den = 0.0
    for i in range(5):
        for j in range(3):
            w = min(mu_s[i], mu_sd[j])  # AND = min
            num += w * rules[i][j]
            den += w

    if den > 1e-12:
        return num / den
    else:
        return np.sign(s_val)


class FuzzySMC(Controller):
    """Fuzzy SMC — smooth gain modulation via Mamdani inference.

    Parameters
    ----------
    surface : SlidingSurface or None
        Pluggable surface. If None, uses s = c*e + edot.
    reaching : ReachingLaw or None
        If provided, overrides fuzzy reaching.
    c : float
        Surface slope.
    k : float
        Maximum switching gain.
    s_range : float
        Normalization range for s in fuzzy inference.
    sdot_range : float
        Normalization range for sdot in fuzzy inference.
    dt : float
        Timestep for numerical sdot estimation.
    """

    def __init__(self, surface=None, reaching=None,
                 c=10.0, k=15.0, s_range=1.0, sdot_range=5.0,
                 dt=1e-4):
        super().__init__(surface=surface, reaching=reaching)
        self.c = c
        self.k = k
        self.s_range = s_range
        self.sdot_range = sdot_range
        self.dt = dt
        self._s_prev = 0.0
        self._first_call = True

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute fuzzy SMC control.

        Parameters
        ----------
        t : float
        x : array [x1, x2]
        xref : array [xref1, xref2]
        plant : Plant or None

        Returns
        -------
        u : float
        info : dict with 's', 'k_fuzzy', 'sdot'
        """
        e = xref[0] - x[0]
        edot = xref[1] - x[1] if len(xref) > 1 else -x[1]

        # Sliding variable
        if self.surface is not None:
            s = self.surface.compute(e, edot, t=t, **kwargs)
        else:
            s = self.c * e + edot

        # Estimate sdot numerically
        if self._first_call:
            sdot = 0.0
            self._first_call = False
        else:
            sdot = (s - self._s_prev) / self.dt
        self._s_prev = s

        # Fuzzy inference: k_fuzzy in [-1, 1]
        k_fuzzy = _fuzzy_inference(s, sdot,
                                   s_range=self.s_range,
                                   sdot_range=self.sdot_range)

        # Equivalent control: for xddot=u with s = c*e + edot,
        # sdot = c*edot + eddot = c*edot - u => u_eq = c*edot
        u_eq = self.c * edot

        # Fuzzy reaching control: u_rob replaces sign(s) with k_fuzzy
        if self.reaching is not None:
            u_rob = -self.reaching.compute(s, t=t, **kwargs)
        else:
            u_rob = self.k * k_fuzzy

        u = u_eq + u_rob

        info = {
            's': s,
            'k_fuzzy': k_fuzzy,
            'sdot': sdot,
            'e': e,
            'edot': edot,
        }
        return u, info

    def reset(self):
        """Reset internal state."""
        super().reset()
        self._s_prev = 0.0
        self._first_call = True
