"""OpenSMC Controllers — 15 SMC + 2 baselines (PID, LQR)."""

from .classical import ClassicalSMC
from .adaptive import AdaptiveSMC
from .dynamic import DynamicSMC
from .hsmc import AggregatedHSMC, IncrementalHSMC, CombiningHSMC
from .discrete import DiscreteSMC
from .fixed_time import FixedTimeSMC
from .fuzzy import FuzzySMC
from .itsmc import ITSMC
from .nftsmc import NFTSMC
from .twisting import TwistingSMC
from .quasi_continuous import QuasiContinuous2SMC
from .hosmc import NestedHOSMC, QuasiContinuousHOSMC
from .pid import PID
from .lqr import LQR

__all__ = [
    # Original SMC (11)
    'ClassicalSMC', 'AdaptiveSMC', 'DynamicSMC',
    'AggregatedHSMC', 'IncrementalHSMC', 'CombiningHSMC',
    'DiscreteSMC', 'FixedTimeSMC', 'FuzzySMC',
    'ITSMC', 'NFTSMC',
    # HOSMC (4)
    'TwistingSMC', 'QuasiContinuous2SMC',
    'NestedHOSMC', 'QuasiContinuousHOSMC',
    # Baselines (2)
    'PID', 'LQR',
]
