"""Classical Sliding Mode Controller.

Reference: Liu, J. (2017). Sliding Mode Control Using MATLAB.
           Academic Press, Ch 1, Sec 1.1, Eq 1.1-1.4.

For a 2nd-order system xddot = (1/J)(u + d):
  Surface: s = c*e + edot
  Control: u = u_eq + u_rob
    u_eq = J*(-c*edot + xref_ddot)       [equivalent control]
    u_rob = reaching_law(s)               [from pluggable reaching law]

If no reaching law is provided, defaults to:
    u_rob = -k*s - eta*sign(s)
"""

import numpy as np
from opensmc.core import Controller


class ClassicalSMC(Controller):
    """Classical SMC — generic surface + reaching law composition.

    Parameters
    ----------
    surface : SlidingSurface or None
        Pluggable sliding surface. If None, uses s = c*e + edot.
    reaching : ReachingLaw or None
        Pluggable reaching law. If None, uses -k*s - eta*sign(s).
    c : float
        Surface slope (used when surface is None).
    k : float
        Exponential reaching gain (used when reaching is None).
    eta : float
        Switching gain (used when reaching is None).
    J : float
        Inertia / plant gain (u_eq = J*(-c*edot + xref_ddot)).
        Set J=1 for a unit double integrator.
    """

    def __init__(self, surface=None, reaching=None,
                 c=10.0, k=10.0, eta=1.1, J=1.0):
        super().__init__(surface=surface, reaching=reaching)
        self.c = c
        self.k = k
        self.eta = eta
        self.J = J

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute classical SMC control.

        Parameters
        ----------
        t : float
        x : array [x1, x2] — current state
        xref : array [xref1, xref2] or [xref1, xref2, xref_ddot]
        plant : Plant or None
        **kwargs :
            xref_ddot : float — reference acceleration (default 0)

        Returns
        -------
        u : float
        info : dict with keys 's', 'u_eq', 'u_rob', 'e', 'edot'
        """
        # Error: e = xref - x (desired minus actual)
        e = xref[0] - x[0]
        edot = xref[1] - x[1] if len(xref) > 1 else -x[1]

        # Reference acceleration
        xref_ddot = 0.0
        if len(xref) > 2:
            xref_ddot = xref[2]
        xref_ddot = kwargs.get('xref_ddot', xref_ddot)

        # Sliding variable
        if self.surface is not None:
            s = self.surface.compute(e, edot, t=t, **kwargs)
        else:
            s = self.c * e + edot

        # Equivalent control: from sdot = eddot + c*edot = (xref_ddot - u/J) + c*edot
        # Setting sdot = 0: u_eq = J*(xref_ddot + c*edot)
        if self.surface is not None:
            # When using pluggable surface, u_eq = 0 (user handles model-based terms)
            u_eq = 0.0
        else:
            u_eq = self.J * (xref_ddot + self.c * edot)

        # Reaching / robust control
        # For sdot = -reaching(s), we need u_rob = +reaching output
        # since reaching laws return NEGATIVE values (e.g., -k*sign(s))
        # and we need sdot = reaching(s) < 0 when s > 0
        # From sdot = (xref_ddot + c*edot - u/J), sdot = reaching(s)
        # => u = J*(xref_ddot + c*edot - reaching(s)) = u_eq - J*reaching(s)
        if self.reaching is not None:
            u_rob = -self.J * self.reaching.compute(s, t=t, **kwargs)
        else:
            u_rob = self.J * (self.k * s + self.eta * np.sign(s))

        u = u_eq + u_rob

        info = {
            's': s,
            'u_eq': u_eq,
            'u_rob': u_rob,
            'e': e,
            'edot': edot,
        }
        return u, info
