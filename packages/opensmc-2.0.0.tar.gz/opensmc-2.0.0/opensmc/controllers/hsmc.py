"""Hierarchical Sliding Mode Controllers for underactuated cranes.

Reference: Qian, D. & Yi, J. (2015). Hierarchical Sliding Mode Control
           for Under-actuated Cranes. Springer.

Three variants from Sections 4.2, 4.3, and 4.4:
  - AggregatedHSMC:   S = alpha*s1 + s2           (Sec 4.2)
  - IncrementalHSMC:  s3 = c3*e4 + s2, cascaded   (Sec 4.3)
  - CombiningHSMC:    z = e1 + c*e3, S = alpha*z + zdot  (Sec 4.4)

All three require crane-like dynamics decomposition:
  xdd = f1 + b1*u,  thdd = f2 + b2*u
The plant must provide a get_fb(x) method or the user passes f1,f2,b1,b2.
"""

import numpy as np
from opensmc.core import Controller


def _get_fb(x, plant):
    """Extract f1, f2, b1, b2 from plant.

    The plant should expose get_fb(x) -> (f1, f2, b1, b2) where:
      xdd  = f1 + b1*u
      thdd = f2 + b2*u
    """
    if plant is not None and hasattr(plant, 'get_fb'):
        return plant.get_fb(x)
    # Default crane parameters (M=1, m=0.8, l=0.305, g=9.81)
    M, m, l, g = 1.0, 0.8, 0.305, 9.81
    th = x[2]; dth = x[3]
    st, ct = np.sin(th), np.cos(th)
    A_ = M + m
    B_ = m * l * ct
    D_ = m * l * st
    d1 = A_ * l - B_ * ct
    d2 = B_ * ct - A_ * l
    f1 = (D_ * dth**2 * l + g * B_ * st) / d1
    f2 = (D_ * dth**2 * ct + g * A_ * st) / d2
    b1 = l / d1
    b2 = ct / d2
    return f1, f2, b1, b2


class AggregatedHSMC(Controller):
    """Aggregated Hierarchical SMC (Qian & Yi 2015, Sec 4.2).

    Surfaces:
      s1 = c1*e1 + e2     (trolley subsystem)
      s2 = c2*e3 + e4     (swing subsystem)
      S  = alpha*s1 + s2   (hierarchical combination)

    Control:
      ueq1 = -(c1*xdot + f1) / b1
      ueq2 = -(c2*thetadot + f2) / b2
      den  = alpha*b1 + b2
      u = (alpha*b1*ueq1 + b2*ueq2 + kappa*S + eta*sign(S)) / den

    Parameters
    ----------
    c1 : float — trolley surface slope
    c2 : float — swing surface slope
    alpha : float — hierarchical weighting
    kappa : float — proportional reaching gain
    eta : float — switching gain
    u_max : float — control saturation
    """

    def __init__(self, surface=None, reaching=None,
                 c1=0.7, c2=8.2, alpha=-2.3, kappa=3.0, eta=0.1,
                 u_max=50.0):
        super().__init__(surface=surface, reaching=reaching)
        self.c1 = c1
        self.c2 = c2
        self.alpha = alpha
        self.kappa = kappa
        self.eta = eta
        self.u_max = u_max

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute aggregated HSMC control.

        Parameters
        ----------
        t : float
        x : array [x_trolley, xdot, theta, thetadot]
        xref : array [xref, xdot_ref, theta_ref, thetadot_ref]
        plant : Plant with get_fb(x) method or None

        Returns
        -------
        u : float
        info : dict with 's', 's1', 's2'
        """
        e = xref - x
        s1 = self.c1 * e[0] + e[1]
        s2 = self.c2 * e[2] + e[3]
        S = self.alpha * s1 + s2

        f1, f2, b1, b2 = _get_fb(x, plant)

        ueq1 = -(self.c1 * x[1] + f1) / b1
        ueq2 = -(self.c2 * x[3] + f2) / b2
        den = self.alpha * b1 + b2

        u = (self.alpha * b1 * ueq1 + b2 * ueq2
             + self.kappa * S + self.eta * np.sign(S)) / den
        u = np.clip(u, -self.u_max, self.u_max)

        info = {
            's': S,
            's1': s1,
            's2': s2,
            'e': e,
        }
        return u, info


class IncrementalHSMC(Controller):
    """Incremental Hierarchical SMC (Qian & Yi 2015, Sec 4.3).

    Three-layer incremental hierarchical sliding surface:
      Layer 1: s1 = c1*e1 + e2
      Layer 2: s2 = c2_eff*e3 + s1
      Layer 3: s3 = c3*e4 + s2

    Sign-switching rule (Eq 4.34):
      c2_eff = +|c2| if x[2]*s1 <= 0
      c2_eff = -|c2| if x[2]*s1 > 0

    Control (derived from sdot3 = 0):
      ueq = -(c3*f2 + f1 + c2_eff*thetadot + c1*xdot) / (c3*b2 + b1)
      usw = +(kappa*s3 + eta*sign(s3)) / (c3*b2 + b1)
      u = ueq + usw

    Parameters
    ----------
    c1 : float — layer 1 slope
    c2 : float — layer 2 coupling (absolute value; sign switches)
    c3 : float — layer 3 slope
    kappa : float — reaching gain
    eta : float — switching gain
    u_max : float — control saturation
    """

    def __init__(self, surface=None, reaching=None,
                 c1=0.7, c2=2.0, c3=0.3, kappa=5.0, eta=0.5,
                 u_max=50.0):
        super().__init__(surface=surface, reaching=reaching)
        self.c1 = c1
        self.c2 = c2
        self.c3 = c3
        self.kappa = kappa
        self.eta = eta
        self.u_max = u_max

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute incremental HSMC control.

        Parameters
        ----------
        t : float
        x : array [x_trolley, xdot, theta, thetadot]
        xref : array [xref, xdot_ref, theta_ref, thetadot_ref]
        plant : Plant with get_fb(x) or None

        Returns
        -------
        u : float
        info : dict with 's' (=s3), 's1', 's2', 'c2_eff'
        """
        e = xref - x

        # Layer 1
        s1 = self.c1 * e[0] + e[1]

        # Sign-switching (Eq 4.34)
        c2_abs = np.abs(self.c2)
        c2_eff = c2_abs if x[2] * s1 <= 0 else -c2_abs

        # Layer 2
        s2 = c2_eff * e[2] + s1

        # Layer 3
        s3 = self.c3 * e[3] + s2

        # Plant dynamics decomposition
        f1, f2, b1, b2 = _get_fb(x, plant)
        den = self.c3 * b2 + b1

        # Equivalent control (uses STATES, not errors)
        ueq = -(self.c3 * f2 + f1 + c2_eff * x[3] + self.c1 * x[1]) / den

        # Switching control (positive sign because den < 0 for crane)
        usw = (self.kappa * s3 + self.eta * np.sign(s3)) / den

        u = np.clip(ueq + usw, -self.u_max, self.u_max)

        info = {
            's': s3,
            's1': s1,
            's2': s2,
            'c2_eff': c2_eff,
            'e': e,
        }
        return u, info


class CombiningHSMC(Controller):
    """Combining Hierarchical SMC (Qian & Yi 2015, Sec 4.4).

    Intermediate variable with sign-switching (Eq 4.58):
      c_eff = |c| if e1*e3 >= 0, else -|c|
      z    = e1 + c_eff * e3
      zdot = e2 + c_eff * e4
      s    = alpha * z + zdot

    Control:
      ueq = (alpha*(e2 + c_eff*e4) - (f1 + c_eff*f2)) / (b1 + c_eff*b2)
      usw = (kappa*s + eta*sign(s)) / (b1 + c_eff*b2)
      u = ueq + usw

    Tuning note: c must satisfy c << l (cable length) to avoid
    denominator discontinuity. For l=0.305, c=0.01 is stable.

    Parameters
    ----------
    c : float — combining coefficient (|c| << cable length)
    alpha : float — surface parameter
    kappa : float — reaching gain
    eta : float — switching gain
    u_max : float — control saturation
    """

    def __init__(self, surface=None, reaching=None,
                 c=0.010, alpha=0.280, kappa=1.0, eta=0.025,
                 u_max=50.0):
        super().__init__(surface=surface, reaching=reaching)
        self.c = c
        self.alpha = alpha
        self.kappa = kappa
        self.eta = eta
        self.u_max = u_max

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute combining HSMC control.

        Parameters
        ----------
        t : float
        x : array [x_trolley, xdot, theta, thetadot]
        xref : array [xref, xdot_ref, theta_ref, thetadot_ref]
        plant : Plant with get_fb(x) or None

        Returns
        -------
        u : float
        info : dict with 's', 'z', 'c_eff'
        """
        e = xref - x
        e1, e2, e3, e4 = e[0], e[1], e[2], e[3]
        c_abs = np.abs(self.c)

        # Sign-switching (Eq 4.58)
        c_eff = c_abs if e1 * e3 >= 0 else -c_abs

        # Intermediate variable
        z = e1 + c_eff * e3
        zdot = e2 + c_eff * e4
        s = self.alpha * z + zdot

        # Plant dynamics decomposition
        f1, f2, b1, b2 = _get_fb(x, plant)
        den = b1 + c_eff * b2

        # Avoid division by zero
        if np.abs(den) < 1e-10:
            den = np.sign(den) * 1e-10 if den != 0 else 1e-10

        # Equivalent control
        ueq = (self.alpha * (e2 + c_eff * e4) - (f1 + c_eff * f2)) / den

        # Switching control
        usw = (self.kappa * s + self.eta * np.sign(s)) / den

        u = np.clip(ueq + usw, -self.u_max, self.u_max)

        info = {
            's': s,
            'z': z,
            'c_eff': c_eff,
            'e': e,
        }
        return u, info
