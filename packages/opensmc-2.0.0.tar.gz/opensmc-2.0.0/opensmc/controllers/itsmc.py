"""Integral Terminal Sliding Mode Controller (ITSMC).

Reference: Al Ghanimi, A. (2026). Integral Terminal Sliding Mode
           Controller for quadrotor attitude control.

Surface:
  s = edot + c1*e + c2 * integral(|e|^(p/q) * sign(e) dt)

where p < q ensures finite-time convergence on the sliding manifold.

Control law (from sdot = 0):
  u_eq  = xref_ddot + c1*edot + c2*|e|^(p/q)*sign(e)
  u_rob = K*sat(s/phi) + lambda_s*s
  u     = u_eq + u_rob

The integral terminal term provides finite-time convergence of the
tracking error to zero, improving upon the exponential convergence
of linear sliding surfaces.
"""

import numpy as np
from opensmc.core import Controller


def _sat(y):
    """Saturation function: sat(y) = y if |y| <= 1, sign(y) otherwise."""
    return np.clip(y, -1.0, 1.0)


def _fractional_sign(e, p, q):
    """Compute |e|^(p/q) * sign(e), handling e=0 gracefully."""
    return np.abs(e) ** (p / q) * np.sign(e)


class ITSMC(Controller):
    """Integral Terminal SMC (Al Ghanimi 2026).

    Parameters
    ----------
    surface : SlidingSurface or None
        If provided, overrides the built-in ITSMC surface.
    reaching : ReachingLaw or None
        If provided, overrides the built-in reaching law.
    c1 : float
        Linear error gain.
    c2 : float
        Integral terminal gain.
    p : int
        Numerator of fractional power (p < q).
    q : int
        Denominator of fractional power.
    K : float
        Saturation-based switching gain.
    lambda_s : float
        Proportional sliding gain.
    phi : float
        Boundary layer thickness for saturation.
    dt : float
        Integration timestep for integral state E.
    """

    def __init__(self, surface=None, reaching=None,
                 c1=5.0, c2=2.0, p=5, q=7,
                 K=5.0, lambda_s=3.0, phi=0.05, dt=1e-4):
        super().__init__(surface=surface, reaching=reaching)
        self.c1 = c1
        self.c2 = c2
        self.p = p
        self.q = q
        self.K = K
        self.lambda_s = lambda_s
        self.phi = phi
        self.dt = dt
        self._E = 0.0  # integral state: int(|e|^(p/q)*sign(e)) dt

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute ITSMC control.

        Parameters
        ----------
        t : float
        x : array [x1, x2]
        xref : array [xref1, xref2] or [xref1, xref2, xref_ddot]
        plant : Plant or None
        **kwargs :
            xref_ddot : float — reference acceleration (default 0)

        Returns
        -------
        u : float
        info : dict with 's', 'E', 'u_eq', 'u_rob', 'e', 'edot'
        """
        e = xref[0] - x[0]
        edot = xref[1] - x[1] if len(xref) > 1 else -x[1]

        # Reference acceleration
        xref_ddot = 0.0
        if len(xref) > 2:
            xref_ddot = xref[2]
        xref_ddot = kwargs.get('xref_ddot', xref_ddot)

        # ITSMC surface: s = edot + c1*e + c2*E
        if self.surface is not None:
            s = self.surface.compute(e, edot, t=t,
                                     E=self._E, **kwargs)
        else:
            s = edot + self.c1 * e + self.c2 * self._E

        # Equivalent control:
        #   From sdot = (xref_ddot - u - d) + c1*edot + c2*|e|^(p/q)*sign(e) = 0
        #   u_eq = xref_ddot + c1*edot + c2*|e|^(p/q)*sign(e)
        frac_e = _fractional_sign(e, self.p, self.q)
        u_eq = xref_ddot + self.c1 * edot + self.c2 * frac_e

        # Robust control: u_rob = K*sat(s/phi) + lambda_s*s
        if self.reaching is not None:
            u_rob = self.reaching.compute(s, t=t, **kwargs)
        else:
            u_rob = self.K * _sat(s / self.phi) + self.lambda_s * s

        u = u_eq + u_rob

        # Update integral state (forward Euler)
        self._E += frac_e * self.dt

        info = {
            's': s,
            'E': self._E,
            'u_eq': u_eq,
            'u_rob': u_rob,
            'e': e,
            'edot': edot,
        }
        return u, info

    def reset(self):
        """Reset integral state."""
        super().reset()
        self._E = 0.0
