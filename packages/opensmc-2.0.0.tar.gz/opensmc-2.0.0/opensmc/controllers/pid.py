"""PID Controller — Classical baseline for benchmarking against SMC.

A standard Proportional-Integral-Derivative controller:

    u = Kp * e + Kd * edot + Ki * integral(e * dt)

This serves as a non-SMC baseline in benchmark comparisons. Every
engineer knows PID, so showing SMC outperforms PID is meaningful.

Note
----
This is NOT a sliding mode controller. It is included in OpenSMC
solely for benchmark comparison purposes.
"""

import numpy as np
from opensmc.core import Controller


class PID(Controller):
    """Standard PID controller for benchmark comparison.

    u = Kp * e + Kd * edot + Ki * integral(e)

    For multi-input systems (n_inputs > 1), applies independent PID
    per channel using diagonal gain matrices.

    Parameters
    ----------
    Kp : float or ndarray
        Proportional gain.
    Kd : float or ndarray
        Derivative gain.
    Ki : float or ndarray
        Integral gain (default 0 = PD controller).
    dt : float
        Time step for integral accumulation.
    u_max : float or None
        Control saturation limit. If None, no saturation.
    n_channels : int
        Number of independent control channels (default 1).
    """

    def __init__(self, Kp=10.0, Kd=5.0, Ki=0.0, dt=1e-4,
                 u_max=None, n_channels=1):
        super().__init__()
        self.Kp = np.atleast_1d(Kp).astype(float)
        self.Kd = np.atleast_1d(Kd).astype(float)
        self.Ki = np.atleast_1d(Ki).astype(float)
        self.dt = dt
        self.u_max = u_max
        self.n_channels = n_channels
        self._e_int = np.zeros(n_channels)

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute PID control.

        For a 2nd-order single-channel system:
            e = xref[0] - x[0], edot = xref[1] - x[1]

        For multi-channel (e.g., 2-link arm):
            e = [xref[0]-x[0], xref[2]-x[2]], edot = [xref[1]-x[1], xref[3]-x[3]]

        Returns
        -------
        u : float or ndarray
        info : dict with 's' (= e for PID), 'e', 'edot'
        """
        nc = self.n_channels

        if nc == 1:
            e = xref[0] - x[0]
            edot = (xref[1] - x[1]) if len(xref) > 1 else -x[1]

            self._e_int[0] += e * self.dt
            u = float(self.Kp[0] * e + self.Kd[0] * edot + self.Ki[0] * self._e_int[0])

            if self.u_max is not None:
                u = np.clip(u, -self.u_max, self.u_max)

            info = {'s': e, 'e': e, 'edot': edot}
            return u, info
        else:
            # Multi-channel: extract position/velocity pairs
            e = np.zeros(nc)
            edot = np.zeros(nc)
            for ch in range(nc):
                pos_idx = 2 * ch
                vel_idx = 2 * ch + 1
                if pos_idx < len(xref):
                    e[ch] = xref[pos_idx] - x[pos_idx]
                if vel_idx < len(xref):
                    edot[ch] = xref[vel_idx] - x[vel_idx]
                elif vel_idx < len(x):
                    edot[ch] = -x[vel_idx]

            self._e_int += e * self.dt

            Kp = self.Kp if len(self.Kp) == nc else np.full(nc, self.Kp[0])
            Kd = self.Kd if len(self.Kd) == nc else np.full(nc, self.Kd[0])
            Ki = self.Ki if len(self.Ki) == nc else np.full(nc, self.Ki[0])

            u = Kp * e + Kd * edot + Ki * self._e_int

            if self.u_max is not None:
                u = np.clip(u, -self.u_max, self.u_max)

            info = {'s': e[0], 'e': e, 'edot': edot}
            return u, info

    def reset(self):
        """Reset integral accumulator."""
        self._e_int = np.zeros(self.n_channels)
